"""Contract and preparation tests for the Regge record-length study."""
from __future__ import annotations

import hashlib
import csv
import json
from dataclasses import replace
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace

import numpy as np
import pytest


PROJECT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT / "python"))

from regge_record_length_study import prepare as preparation
from regge_record_length_study import calibration
from regge_record_length_study import audit as study_audit
from regge_record_length_study import report as study_report
from regge_record_length_study import hpc_calibration
from regge_record_length_study import selection as study_selection
from regge_record_length_study import run as stage_runner
from regge_record_length_study.calibration import (
    bind_calibration_inputs,
    missing_calibration_specs,
)
from regge_record_length_study.contract import (
    FIXED_INITIAL_COVARIANCE_SHA256,
    common_warmup_state_masks,
    evaluation_period_specs,
    fixed_initial_covariance,
    load_inputs,
    state_preparation_specs,
    window_specs,
)


def test_window_lengths_origins_and_nesting():
    specs = window_specs()
    assert [(s["endpoint"], s["months"], s["hours"], s["selection_origins"]) for s in specs] == [
        ("E1", 3, 2208, 87), ("E1", 6, 4416, 179),
        ("E1", 12, 8760, 360), ("E1", 24, 17544, 726),
        ("E2", 3, 2184, 86), ("E2", 6, 4344, 176),
        ("E2", 12, 8760, 360), ("E2", 24, 17520, 725),
        ("E3", 3, 2208, 87), ("E3", 6, 4416, 179),
        ("E3", 12, 8760, 360), ("E3", 24, 17520, 725),
    ]
    assert [s["exp_id"] for s in specs] == [
        f"RL-{endpoint}-M{months:02d}"
        for endpoint in ("E1", "E2", "E3")
        for months in (3, 6, 12, 24)
    ]
    for endpoint in ("E1", "E2", "E3"):
        rows = [s for s in specs if s["endpoint"] == endpoint]
        assert len({s["stop"] for s in rows}) == 1
        for short, long in zip(rows, rows[1:]):
            assert long["start"] < short["start"] < short["stop"] == long["stop"]


def test_window_specs_are_returned_as_defensive_copies():
    first = window_specs()
    first[0]["hours"] = -1
    assert window_specs()[0]["hours"] == 2208


def test_common_state_preparation_and_evaluation_counts():
    assert [(s["endpoint"], s["start"], s["stop"], s["hours"]) for s in state_preparation_specs()] == [
        ("E1", "2001-10-01T00", "2002-01-01T00", 2208),
        ("E2", "2002-04-01T00", "2002-07-01T00", 2184),
        ("E3", "2003-10-01T00", "2004-01-01T00", 2208),
    ]
    periods = evaluation_period_specs()
    assert [p["origin_count"] for p in periods] == [
        360, 360, 361, 360, 360, 360, 361, 360, 360, 2161,
    ]
    assert [p["period_id"] for p in periods[:3]] == [
        "RECENT-E1", "RECENT-E2", "RECENT-E3",
    ]
    assert periods[-1]["period_id"] == "COMMON-2005-2010"


def test_fixed_initial_covariance_is_exact_and_defensive():
    expected = np.diag((0.001 * np.array([140, 1000, 4, 1200, 0.1])) ** 2)
    actual = fixed_initial_covariance()
    np.testing.assert_array_equal(actual, expected)
    assert hashlib.sha256(np.ascontiguousarray(actual).tobytes()).hexdigest() == FIXED_INITIAL_COVARIANCE_SHA256
    actual[0, 0] = -1
    assert fixed_initial_covariance()[0, 0] == expected[0, 0]


def test_reference_level_gate_uses_numerical_bounds():
    passed = study_audit.gate(
        method=(1.00, 0.001), reference=(1.00, 0.001),
        persistence=(1.20, 0.0),
    )
    assert passed["status"] == "pass"
    uncertain = study_audit.gate(
        method=(1.05, 0.001), reference=(1.00, 0.001),
        persistence=(1.20, 0.0),
    )
    assert uncertain["status"] == "numerical_boundary_uncertain"
    failed = study_audit.gate(
        method=(1.06, 0.001), reference=(1.00, 0.001),
        persistence=(1.20, 0.0),
    )
    assert failed["status"] == "fail"


def test_invalid_or_zero_reference_never_passes_and_bad_reference_is_named():
    assert study_audit.gate(
        method=(1.0, 0.0), reference=(0.0, 0.0),
        persistence=(1.2, 0.0),
    )["status"] == "invalid"
    assert study_audit.gate(
        method=(1.0, 0.0), reference=(np.nan, 0.0),
        persistence=(1.2, 0.0),
    )["status"] == "invalid"
    assert study_audit.gate(
        method=(0.8, 0.0), reference=(1.0, 0.0),
        persistence=(1.01, 0.0),
    )["status"] == "reference_quality_fail"


def test_metric_values_and_reconstruction_difference_are_hand_calculable():
    leads = np.arange(120, dtype=np.float64)
    truth = np.vstack([leads, leads + 1.0, leads + 2.0])
    predictions = truth + 1.0
    values = study_audit.metric_values(predictions, truth)
    np.testing.assert_array_equal(
        values["root_mean_square_error"], np.ones(120),
    )
    np.testing.assert_array_equal(
        values["mean_absolute_error"], np.ones(120),
    )
    np.testing.assert_allclose(
        values["nash_efficiency"], np.full(120, -0.5), rtol=0, atol=1e-14,
    )
    reconstructed = predictions + 0.25
    np.testing.assert_array_equal(
        study_audit.reconstruction_difference(predictions, reconstructed),
        np.full(120, 0.25),
    )


def test_independent_two_lead_ranking_uses_parameter_best_then_global_best():
    parameter_ids = np.asarray([1, 1, 2, 2, 3, 4, 5], dtype=np.int64)
    noise_ids = np.asarray([0, 1, 0, 1, 0, 0, 0], dtype=np.int64)
    scalar_scores = np.asarray([0.8, 0.4, 0.7, 0.3, 0.2, 0.1, 0.05])
    errors = np.ones((7, 4), dtype=np.float64)
    errors[:, 2] = scalar_scores
    errors[:, 3] = scalar_scores
    ranked = study_audit._rank_joint(
        parameter_ids, noise_ids, errors, np.ones(4),
        np.ones(7, dtype=np.bool_),
    )
    assert ranked["best_row"] == 6
    assert ranked["complete_order"].tolist() == [6, 5, 4, 3, 1, 2, 0]
    assert ranked["parameter_best_order"].tolist() == [6, 5, 4, 3, 1]


def test_independent_numpy_forecast_matches_production_equations():
    import torch
    from regge_record_length_study import assessment

    parameters = {
        "cw": 413.6718976768621, "cv": 45.0,
        "cg": 16749666.3692294, "cq": 3.89027632718506,
        "cs": 0.2, "cd": 2450.0, "as_": 0.01, "ag": 0.99,
        "b": 4.38, "psi_ae": 90.0, "theta_s": 0.41,
        "zeta1": 0.02, "zeta2": 400.0, "exps": 1.5, "min_h": 0.001,
    }
    states = np.asarray([
        [140.0, 1000.0, 4.0, 1200.0, 0.1],
        [160.0, 950.0, 2.0, 1100.0, 0.05],
    ], dtype=np.float64)
    forcing = np.asarray([[0.3, 0.02], [1.1, 0.04]], dtype=np.float64)
    independent = study_audit._numpy_walrus_step(states, forcing, parameters)
    core = assessment._load_assessment_core()
    production = core["walrus_step"](
        torch.from_numpy(states), torch.from_numpy(forcing),
        [parameters, parameters],
    ).detach().numpy()
    np.testing.assert_allclose(independent, production, rtol=0, atol=1e-12)


def _small_selection_arrays():
    shortlist = np.arange(16, dtype=np.int64)
    origins = np.asarray([0, 24], dtype=np.int64)
    targets = origins[:, None] + np.asarray([1, 24, 48, 120], dtype=np.int64)
    return {
        "parameter_ids": np.arange(2048, dtype=np.int64),
        "parameter_values": np.zeros((2048, 5), dtype=np.float64),
        "noise_design": np.zeros((128, 5), dtype=np.float64),
        "calibration_observations": np.zeros(5, dtype=np.float64),
        "hydrologic_predictions": np.zeros((2048, 5), dtype=np.float64),
        "hydrologic_alive": np.ones(2048, dtype=np.bool_),
        "hydrologic_completed": np.ones(2048, dtype=np.bool_),
        "shortlist_parameter_ids": shortlist,
        "origin_indices": origins,
        "target_indices": targets,
        "target_observations": np.zeros((2, 4), dtype=np.float64),
        "persistence_predictions": np.zeros((2, 4), dtype=np.float64),
        "reference_errors": np.ones(4, dtype=np.float64),
        "joint_parameter_ids": np.repeat(shortlist, 128),
        "joint_noise_ids": np.tile(np.arange(128, dtype=np.int64), 16),
        "joint_predictions": np.zeros((2048, 2, 4), dtype=np.float64),
        "joint_alive": np.ones(2048, dtype=np.bool_),
        "joint_completed": np.ones(2048, dtype=np.bool_),
        "joint_errors": np.zeros((2048, 4), dtype=np.float64),
        "joint_valid": np.ones(2048, dtype=np.bool_),
    }


def test_independent_selection_contract_requires_complete_joint_grid_and_four_leads():
    spec = {"hours": 5, "selection_origins": 2}
    arrays = _small_selection_arrays()
    study_audit._validate_selection_array_contract(arrays, spec)

    broken_grid = dict(arrays)
    broken_grid["joint_noise_ids"] = arrays["joint_noise_ids"].copy()
    broken_grid["joint_noise_ids"][128] = 127
    with pytest.raises(ValueError, match="complete 16-parameter by 128-noise grid"):
        study_audit._validate_selection_array_contract(broken_grid, spec)

    broken_targets = dict(arrays)
    broken_targets["target_indices"] = arrays["target_indices"].copy()
    broken_targets["target_indices"][0, 2] += 1
    with pytest.raises(ValueError, match="1, 24, 48, and 120"):
        study_audit._validate_selection_array_contract(broken_targets, spec)

    broken_shape = dict(arrays)
    broken_shape["joint_predictions"] = arrays["joint_predictions"][:-1]
    with pytest.raises(ValueError, match="joint_predictions"):
        study_audit._validate_selection_array_contract(broken_shape, spec)


def _synthetic_full_raw_inputs():
    dates = np.arange(
        np.datetime64("1999-01-01T01", "h"),
        np.datetime64("2011-01-01T00", "h"),
        np.timedelta64(1, "h"),
    )
    values = np.arange(len(dates), dtype=np.float64)
    forcing = np.column_stack((values * 1e-5, values * 2e-6))
    observations = 1.0 + values * 1e-6
    return dates, forcing, observations


def test_assessment_audit_rebuilds_future_forcing_truth_and_year_codes_from_raw():
    dates, forcing, observations = _synthetic_full_raw_inputs()
    spec = {"exp_id": "RL-E1-M03", "endpoint": "E1"}
    expected = study_audit._expected_assessment_source(
        "E1", dates, forcing, observations,
    )
    arrays = {
        name: np.array(expected[name], copy=True)
        for name in (
            "timestamps", "forcing", "observations", "origins",
            "target_indices", "truth", "forecast_forcing", "persistence",
            "period_codes",
        )
    }
    study_audit._verify_assessment_arrays_against_raw(
        arrays, spec, dates, forcing, observations,
    )

    arrays["forecast_forcing"][0, 0, 0] += 1.0
    with pytest.raises(RuntimeError, match="forecast_forcing"):
        study_audit._verify_assessment_arrays_against_raw(
            arrays, spec, dates, forcing, observations,
        )
    arrays["forecast_forcing"] = np.array(
        expected["forecast_forcing"], copy=True,
    )
    arrays["period_codes"] = arrays["period_codes"][::-1].copy()
    with pytest.raises(RuntimeError, match="period_codes"):
        study_audit._verify_assessment_arrays_against_raw(
            arrays, spec, dates, forcing, observations,
        )


def test_chain_completion_rejects_receipt_count_tampering():
    expected = {
        "start": 7,
        "stop": 17,
        "last_valid_hour": 16,
        "processed_hour_count": 10,
    }
    metadata = {
        "start": 7, "stop": 17, "last_valid_hour": 16,
        "processed_hour_count": 10, "completed_origins": 2,
        "deterministic_forecast_steps": 240, "state_reset_count": 0,
    }
    receipt = {
        "processed_hour_count": 10, "completed_origins": 2,
        "deterministic_forecast_steps": 240,
    }
    assert study_audit._validate_chain_completion(
        metadata, receipt, expected, 2, "A",
    )["processed_hour_count"] == 10
    receipt["processed_hour_count"] = 9
    with pytest.raises(RuntimeError, match="receipt completion"):
        study_audit._validate_chain_completion(
            metadata, receipt, expected, 2, "A",
        )


def test_decisions_use_six_recent_and_thirty_six_annual_cells_not_pooled():
    rows = []
    for months in (3, 6, 12, 24):
        for endpoint in ("E1", "E2", "E3"):
            for lead in (48, 120):
                rows.append({
                    "months": months, "endpoint": endpoint,
                    "period_kind": "recent", "lead_hour": lead,
                    "gate_status": "pass",
                })
            for year in range(2005, 2011):
                for lead in (48, 120):
                    rows.append({
                        "months": months, "endpoint": endpoint,
                        "period_kind": "annual", "lead_hour": lead,
                        "gate_status": "pass",
                    })
            for lead in (48, 120):
                rows.append({
                    "months": months, "endpoint": endpoint,
                    "period_kind": "pooled", "lead_hour": lead,
                    "gate_status": "fail",
                })
    ranking = [
        {
            "months": months, "endpoint": endpoint,
            "parameter_id": months, "noise_id": index,
        }
        for months in (3, 6, 12, 24)
        for index, endpoint in enumerate(("E1", "E2", "E3"))
    ]
    result = study_audit._decision_summary(rows, ranking)
    assert result["primary_recent_shortest_tested_length"]["shortest_months"] == 3
    assert result["secondary_yearly_stable_shortest_tested_length"]["shortest_months"] == 3
    assert result["primary_recent_shortest_tested_length"]["by_length"]["3"]["cell_count"] == 6
    assert result["secondary_yearly_stable_shortest_tested_length"]["by_length"]["3"]["cell_count"] == 36
    assert result["pooled_period_used_for_primary_or_secondary_decision"] is False


def test_historical_reproduction_audit_checks_all_old_hashes_identities_and_exclusion(
        tmp_path):
    common_origins = np.arange(10000, 10000 + 2161 * 24, 24, dtype=np.int64)
    targets = common_origins[:, None] + np.arange(1, 121, dtype=np.int64)[None, :]
    locked = {}
    checks = []
    selections = {}
    difference_names = (
        "target_indices", "posterior_states", "posterior_covariances",
        "member_states", "member_covariances", "probabilities", "predictions",
    )
    for index, endpoint in enumerate(("E1", "E2", "E3")):
        arrays_path = tmp_path / f"{endpoint}_arrays.npz"
        metadata_path = tmp_path / f"{endpoint}_metadata.json"
        np.savez(
            arrays_path,
            origin_indices=common_origins,
            target_indices=targets,
            global_states=np.zeros((2161, 5), dtype=np.float64),
            global_covariances=np.zeros((2161, 5, 5), dtype=np.float64),
            member_states=np.zeros((2161, 1, 5), dtype=np.float64),
            member_covariances=np.zeros((2161, 1, 5, 5), dtype=np.float64),
            probabilities=np.ones((2161, 1), dtype=np.float64),
            fixed_predictions=np.zeros((2161, 120), dtype=np.float64),
        )
        metadata_path.write_text("{}", encoding="utf-8")
        parameter_id, noise_id = 10 + index, 20 + index
        locked[endpoint] = {
            "arrays_path": arrays_path,
            "metadata_path": metadata_path,
            "arrays_sha256": preparation.sha256(arrays_path),
            "metadata_sha256": preparation.sha256(metadata_path),
            "parameter_id": parameter_id,
            "noise_id": noise_id,
        }
        exp_id = f"RL-{endpoint}-M03"
        selections[exp_id] = {
            "parameter_id": parameter_id, "noise_id": noise_id,
        }
        checks.append({
            "endpoint": endpoint,
            "experiment_id": exp_id,
            "old_arrays": str(arrays_path),
            "old_arrays_sha256": locked[endpoint]["arrays_sha256"],
            "old_metadata": str(metadata_path),
            "old_metadata_sha256": locked[endpoint]["metadata_sha256"],
            "parameter_id": parameter_id,
            "noise_id": noise_id,
            "verified_origin_count": 2161,
            "max_absolute_differences": {
                name: 0.0 for name in difference_names
            },
        })
    historical = {
        "schema": "regge_record_length_three_month_reproduction_v01",
        "passed": True,
        "verified_methods": 3,
        "absolute_tolerance": 1e-8,
        "relative_tolerance": 0.0,
        "checks": checks,
        "twenty_four_month_historical_equality_required": False,
    }
    result = study_audit._validate_historical_reproduction_record(
        historical, locked, selections, common_origins,
    )
    assert result["verified_methods"] == 3
    assert result["twenty_four_month_historical_equality_required"] is False

    historical["checks"][0]["old_arrays_sha256"] = "0" * 64
    with pytest.raises(RuntimeError, match="hash or identity"):
        study_audit._validate_historical_reproduction_record(
            historical, locked, selections, common_origins,
        )
    historical["checks"][0]["old_arrays_sha256"] = locked["E1"][
        "arrays_sha256"
    ]
    historical["twenty_four_month_historical_equality_required"] = True
    with pytest.raises(RuntimeError, match="header"):
        study_audit._validate_historical_reproduction_record(
            historical, locked, selections, common_origins,
        )


def test_assessment_stage_count_audit_sums_every_chain_and_rejects_one_tamper(
        tmp_path):
    assessments = []
    completed = []
    for spec in window_specs():
        endpoint = spec["endpoint"]
        origins = 2161 + {"E1": 360, "E2": 360, "E3": 361}[endpoint]
        hours = {"E1": 81096, "E2": 76728, "E3": 63576}[endpoint]
        assessment_id = f"{spec['exp_id']}-MATCHED3"
        counts = {
            "processed_hour_count": hours,
            "completed_origins": origins,
            "deterministic_forecast_steps": origins * 120,
        }
        assessment_row = {
            "assessment_id": assessment_id,
            "completion_counts": counts,
            "assessment_arrays_sha256": f"arrays-{assessment_id}",
            "assessment_metadata_sha256": f"metadata-{assessment_id}",
            "assessment_receipt_sha256": f"receipt-{assessment_id}",
        }
        assessments.append(assessment_row)
        completed.append({
            "experiment_id": spec["exp_id"],
            "assessment_id": assessment_id,
            "valid": True,
            **counts,
            "arrays_sha256": assessment_row["assessment_arrays_sha256"],
            "metadata_sha256": assessment_row["assessment_metadata_sha256"],
            "receipt_sha256": assessment_row["assessment_receipt_sha256"],
        })
    receipt = {
        "status": "complete", "passed": True,
        "assessment_count": 12, "valid_assessment_count": 12,
        "processed_filter_hours": 885600,
        "completed_origins": 30256,
        "production_forecast_steps": 3630720,
        "state_reset_count": 0,
        "completed": completed,
    }
    path = tmp_path / "assessment_receipt.json"
    path.write_text(json.dumps(receipt), encoding="utf-8")
    totals = study_audit._verify_assessment_stage_receipt(
        tmp_path, assessments,
    )
    assert totals["processed_filter_hours"] == 885600
    receipt["completed"][0]["processed_hour_count"] -= 1
    path.write_text(json.dumps(receipt), encoding="utf-8")
    with pytest.raises(RuntimeError, match="per-chain record"):
        study_audit._verify_assessment_stage_receipt(tmp_path, assessments)


def test_audit_refuses_overwrite_and_preserves_failure_receipt(tmp_path, monkeypatch):
    occupied = tmp_path / "occupied"
    occupied.mkdir()
    marker = occupied / "audit_started.json"
    marker.write_text("keep", encoding="utf-8")
    monkeypatch.setattr(study_audit.preparation, "OUTPUT", occupied)
    with pytest.raises(FileExistsError, match="cannot overwrite"):
        study_audit.audit_all(occupied)
    assert marker.read_text(encoding="utf-8") == "keep"

    failed = tmp_path / "failed"
    failed.mkdir()
    monkeypatch.setattr(study_audit.preparation, "OUTPUT", failed)
    monkeypatch.setattr(
        study_audit, "_verify_stage_inputs",
        lambda _root: (_ for _ in ()).throw(RuntimeError("forced audit gate")),
    )
    with pytest.raises(RuntimeError, match="forced audit gate"):
        study_audit.audit_all(failed)
    receipt = json.loads((failed / "audit_failed.json").read_text(encoding="utf-8"))
    assert receipt["passed"] is False
    assert receipt["automatic_retry"] is False
    assert receipt["error"]["reason"] == "forced audit gate"


def _synthetic_report_rows():
    rows = []
    for endpoint in ("E1", "E2", "E3"):
        for months in (3, 6, 12, 24):
            assessment_id = f"RL-{endpoint}-M{months:02d}-MATCHED3"
            periods = [("recent", f"RECENT-{endpoint}", 360)]
            periods.extend(
                ("annual", f"YEAR-{year}", 360)
                for year in range(2005, 2011)
            )
            periods.append(("pooled", "COMMON-2005-2010", 2161))
            for kind, period_id, origin_count in periods:
                for lead in range(1, 121):
                    rows.append({
                        "assessment_id": assessment_id,
                        "endpoint": endpoint,
                        "months": months,
                        "period_kind": kind,
                        "period_id": period_id,
                        "lead_hour": lead,
                        "origin_count": origin_count,
                        "root_mean_square_error": 0.9,
                        "nash_efficiency": -0.5 + lead / 100.0,
                        "mean_absolute_error": 0.7,
                        "reconstruction_difference": 0.001,
                        "root_mean_square_error_lower_bound": 0.899,
                        "root_mean_square_error_upper_bound": 0.901,
                        "reference_assessment_id": f"RL-{endpoint}-M24-MATCHED3",
                        "reference_root_mean_square_error": 1.0,
                        "reference_reconstruction_difference": 0.001,
                        "persistence_root_mean_square_error": 1.2,
                        "persistence_reconstruction_difference": 0.0,
                        "nominal_reference_ratio": 0.9,
                        "nominal_persistence_ratio": 0.75,
                        "reference_persistence_ratio": 1.0 / 1.2,
                        "gate_method_reference": "pass",
                        "gate_method_persistence": "pass",
                        "gate_reference_persistence": "pass",
                        "gate_status": "pass",
                    })
    assert len(rows) == 11520
    return rows


def _synthetic_comparisons():
    zero_counts = {
        status: (6 if status == "pass" else 0)
        for status in study_audit.ALL_STATUSES
    }
    annual_counts = {
        status: (36 if status == "pass" else 0)
        for status in study_audit.ALL_STATUSES
    }
    return {
        "primary_recent_shortest_tested_length": {
            "shortest_months": 3,
            "recent_endpoint_pass_counts_out_of_three": {
                str(months): 3 for months in (3, 6, 12)
            },
            "by_length": {
                str(months): {
                    "cell_count": 6, "status_counts": dict(zero_counts),
                    "all_cells_pass": True,
                }
                for months in (3, 6, 12)
            },
        },
        "secondary_yearly_stable_shortest_tested_length": {
            "shortest_months": 3,
            "by_length": {
                str(months): {
                    "cell_count": 36, "status_counts": dict(annual_counts),
                    "all_cells_pass": True,
                }
                for months in (3, 6, 12)
            },
        },
        "all_metric_row_status_counts": {
            status: (11520 if status == "pass" else 0)
            for status in study_audit.ALL_STATUSES
        },
        "pooled_period_used_for_primary_or_secondary_decision": False,
    }


def _synthetic_identities():
    return [
        {
            "experiment_id": f"RL-{endpoint}-M{months:02d}",
            "assessment_id": f"RL-{endpoint}-M{months:02d}-MATCHED3",
            "endpoint": endpoint,
            "months": months,
            "parameter_id": index,
            "noise_id": index + 1,
            "selection_score": 0.5,
            "calibration_raw_sha256": "a" * 64,
            "calibration_result_sha256": "b" * 64,
            "independent_complete_rank_order_sha256": "c" * 64,
            "independent_parameter_best_order_sha256": "d" * 64,
        }
        for index, (endpoint, months) in enumerate(
            (endpoint, months)
            for endpoint in ("E1", "E2", "E3")
            for months in (3, 6, 12, 24)
        )
    ]


def _visual_inspection_record():
    return {
        "inspector": "Codex visual inspection",
        "checks": {
            "legend": True,
            "line_colors": True,
            "axes": True,
            "Chinese_glyphs": True,
            "negative_nash_values": True,
            "threshold_1.05": True,
        },
        "figures": list(study_report.FIGURE_NAMES),
        "note": "All five rendered figures were inspected.",
    }


def _generate_synthetic_pending_report(tmp_path, monkeypatch):
    rows = _synthetic_report_rows()
    identities = _synthetic_identities()
    comparisons = _synthetic_comparisons()
    for name, contents in {
        "metrics_1_to_120_hours.csv": "synthetic audited source",
        "audit.json": "synthetic audit",
        "comparisons.json": "synthetic comparisons",
        "selected_identities.csv": "synthetic identities",
    }.items():
        (tmp_path / name).write_text(contents, encoding="utf-8")
    monkeypatch.setattr(
        study_report, "_read_audited_rows",
        lambda _root: (
            rows,
            {"maximum_absolute_reconstruction_difference": 1e-10},
            comparisons,
            identities,
        ),
    )
    monkeypatch.setattr(
        study_report, "_configure_chinese_font",
        lambda: (None, tmp_path / "bound-font.ttf", "f" * 64),
    )

    def fake_plot(_rows, target, *args):
        Path(target).write_bytes(b"audited-figure")

    monkeypatch.setattr(study_report, "_plot_primary", fake_plot)
    monkeypatch.setattr(
        study_report, "_plot_endpoint_curve",
        lambda _rows, _endpoint, target: fake_plot(_rows, target),
    )
    monkeypatch.setattr(study_report, "_plot_annual_heatmap", fake_plot)
    monkeypatch.setattr(
        study_report, "_image_checks",
        lambda path: {
            "sha256": preparation.sha256(path),
            "width_pixels": 2400, "height_pixels": 1600,
            "rgb_standard_deviation": 10.0,
        },
    )
    assert study_report.generate_report(tmp_path) == tmp_path
    return rows, identities, comparisons


def test_report_reads_exact_audited_rows_and_binds_no_pooled_decision_marks(
        tmp_path):
    rows = _synthetic_report_rows()
    metrics_path = tmp_path / "metrics_1_to_120_hours.csv"
    with metrics_path.open("w", encoding="utf-8", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=study_audit.METRIC_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)
    comparisons_path = tmp_path / "comparisons.json"
    comparisons_path.write_text(
        json.dumps(_synthetic_comparisons()), encoding="utf-8",
    )
    identities_path = tmp_path / "selected_identities.csv"
    identities = _synthetic_identities()
    with identities_path.open("w", encoding="utf-8", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=study_audit.IDENTITY_COLUMNS)
        writer.writeheader()
        writer.writerows(identities)
    audit_path = tmp_path / "audit.json"
    audit_path.write_text(json.dumps({
        "passed": True,
        "metric_row_count": 11520,
        "files": {
            metrics_path.name: preparation.sha256(metrics_path),
            comparisons_path.name: preparation.sha256(comparisons_path),
            identities_path.name: preparation.sha256(identities_path),
        },
    }), encoding="utf-8")
    parsed, _, _, parsed_identities = study_report._read_audited_rows(tmp_path)
    assert len(parsed) == 11520
    assert len(parsed_identities) == 12
    binding = study_report.build_figure_data_binding(
        parsed, preparation.sha256(metrics_path),
    )
    key_to_kind = {
        study_report._row_key(row): row["period_kind"] for row in parsed
    }
    assert binding["figure_count"] == 5
    assert all(
        key_to_kind[key] != "pooled"
        for figure in binding["figures"].values()
        for key in figure["row_keys"]
    )


def test_report_stops_for_real_visual_inspection_then_seals_complete_manifest(
        tmp_path, monkeypatch):
    _generate_synthetic_pending_report(tmp_path, monkeypatch)
    assert (tmp_path / "report_pending_inspection.json").is_file()
    assert not (tmp_path / "report_receipt.json").exists()
    assert not (tmp_path / "manifest.json").exists()
    report_text = (tmp_path / "report.md").read_text(encoding="utf-8")
    assert "六年合并结果只作描述，不参与最短长度判定" in report_text
    assert "纳什效率系数" in report_text

    with pytest.raises(ValueError, match="incomplete"):
        study_report.seal_report_after_visual_inspection(
            {"inspector": "Codex visual inspection", "checks": {}}, tmp_path,
        )
    inspection = _visual_inspection_record()
    assert study_report.seal_report_after_visual_inspection(
        inspection, tmp_path,
    ) == tmp_path
    manifest = json.loads((tmp_path / "manifest.json").read_text(encoding="utf-8"))
    receipt = json.loads(
        (tmp_path / "report_receipt.json").read_text(encoding="utf-8")
    )
    assert manifest["status"] == "content_verified"
    assert manifest["is_completion_receipt"] is False
    assert receipt["passed"] is True and receipt["status"] == "complete"
    assert receipt["manifest_sha256"] == preparation.sha256(tmp_path / "manifest.json")
    assert "report_receipt.json" not in manifest["files"]
    assert all(
        f"figures/{name}" in manifest["files"]
        for name in study_report.FIGURE_NAMES
    )


@pytest.mark.parametrize("changed_name", [
    "report.md",
    "figure_data_binding.json",
    "audit.json",
    "metrics_1_to_120_hours.csv",
    "comparisons.json",
    "selected_identities.csv",
])
def test_report_seal_rejects_any_bound_evidence_change(
        tmp_path, monkeypatch, changed_name):
    _generate_synthetic_pending_report(tmp_path, monkeypatch)
    changed = tmp_path / changed_name
    changed.write_bytes(changed.read_bytes() + b"\nchanged-after-inspection-request")
    with pytest.raises(RuntimeError, match="changed after inspection request"):
        study_report.seal_report_after_visual_inspection(
            _visual_inspection_record(), tmp_path,
        )
    assert not (tmp_path / "report_receipt.json").exists()
    failure = json.loads(
        (tmp_path / "report_seal_failed.json").read_text(encoding="utf-8")
    )
    assert failure["passed"] is False
    assert failure["successful_receipt_exists"] is False
    assert failure["automatic_retry"] is False


@pytest.mark.parametrize("failure_point", [
    "event_write",
    "manifest_write",
    "manifest_hash_verification",
])
def test_report_seal_failure_never_leaves_success_receipt(
        tmp_path, monkeypatch, failure_point):
    _generate_synthetic_pending_report(tmp_path, monkeypatch)
    if failure_point == "event_write":
        monkeypatch.setattr(
            study_report, "_event",
            lambda *_args, **_kwargs: (_ for _ in ()).throw(
                RuntimeError("injected event write failure")
            ),
        )
    elif failure_point == "manifest_write":
        original_write = study_report.write_json_new

        def fail_manifest(path, payload):
            if Path(path).name == "manifest.staging.json":
                raise RuntimeError("injected manifest write failure")
            return original_write(path, payload)

        monkeypatch.setattr(study_report, "write_json_new", fail_manifest)
    else:
        monkeypatch.setattr(
            study_report, "_verify_content_manifest",
            lambda *_args, **_kwargs: (_ for _ in ()).throw(
                RuntimeError("injected manifest hash verification failure")
            ),
        )
    with pytest.raises(RuntimeError, match="injected"):
        study_report.seal_report_after_visual_inspection(
            _visual_inspection_record(), tmp_path,
        )
    assert not (tmp_path / "report_receipt.json").exists()
    failure = json.loads(
        (tmp_path / "report_seal_failed.json").read_text(encoding="utf-8")
    )
    assert failure["passed"] is False
    assert failure["successful_receipt_exists"] is False
    assert failure["stage"] in {
        "write_seal_event", "write_and_verify_content_manifest",
    }


def test_real_report_plot_code_preserves_frozen_visual_contract(
        tmp_path, monkeypatch):
    from matplotlib import pyplot as plt

    plt.switch_backend("Agg")
    if Path("C:/Windows/Fonts/simhei.ttf").is_file():
        study_report._configure_chinese_font()
    rows = _synthetic_report_rows()
    captured = {}

    def capture_figure(fig, path):
        fig.canvas.draw()
        captured[Path(path).name] = {
            "axes": [
                {
                    "title": axis.get_title(),
                    "xlabel": axis.get_xlabel(),
                    "ylabel": axis.get_ylabel(),
                    "xlim": tuple(axis.get_xlim()),
                    "ylim": tuple(axis.get_ylim()),
                    "lines": [
                        {
                            "x": np.asarray(line.get_xdata()).copy(),
                            "y": np.asarray(line.get_ydata()).copy(),
                            "color": line.get_color(),
                            "label": line.get_label(),
                        }
                        for line in axis.lines
                    ],
                    "images": [
                        {
                            "array": np.asarray(image.get_array()).copy(),
                            "cmap": image.get_cmap().name,
                            "colors": tuple(getattr(image.get_cmap(), "colors", ())),
                        }
                        for image in axis.images
                    ],
                }
                for axis in fig.axes
            ],
            "texts": [text.get_text() for text in fig.texts],
        }

    monkeypatch.setattr(study_report, "_save_figure", capture_figure)
    study_report._plot_primary(rows, tmp_path / study_report.FIGURE_NAMES[0])
    for endpoint, name in study_report.ENDPOINT_FILE_NAMES.items():
        study_report._plot_endpoint_curve(rows, endpoint, tmp_path / name)
    study_report._plot_annual_heatmap(
        rows, tmp_path / study_report.FIGURE_NAMES[-1],
    )
    assert set(captured) == set(study_report.FIGURE_NAMES)

    primary = captured[study_report.FIGURE_NAMES[0]]["axes"][:4]
    assert {axis["title"] for axis in primary[:2]} == {
        "近期评价：提前48小时", "近期评价：提前120小时",
    }
    assert all(axis["ylabel"] == "均方根误差比（越低越好）" for axis in primary[:2])
    assert all(axis["ylabel"] == "纳什效率系数（越高越好）" for axis in primary[2:])
    assert all(axis["xlabel"] == "资料长度（月）" for axis in primary[2:])
    assert all(any(np.allclose(line["y"], 1.05) for line in axis["lines"])
               for axis in primary[:2])
    assert any(
        np.min(line["y"]) < 0
        for axis in primary[2:] for line in axis["lines"] if line["y"].size
    )
    primary_colors = {
        line["color"] for line in primary[0]["lines"] if line["x"].size == 4
    }
    assert set(study_report.ENDPOINT_COLORS.values()).issubset(primary_colors)

    for endpoint, name in study_report.ENDPOINT_FILE_NAMES.items():
        axes = captured[name]["axes"][:2]
        data_lines = [line for line in axes[0]["lines"] if line["x"].size == 120]
        assert len(data_lines) == 4
        assert all(np.array_equal(line["x"], np.arange(1, 121)) for line in data_lines)
        assert {line["color"] for line in data_lines} == set(
            study_report.LENGTH_COLORS.values()
        )
        assert any(np.allclose(line["y"], 1.05) for line in axes[0]["lines"])
        assert axes[0]["title"] == f"{study_report.ENDPOINT_LABELS[endpoint]}：近期评价"
        assert axes[1]["xlabel"] == "提前时间（小时）"
        assert axes[1]["xlim"] == pytest.approx((1.0, 120.0))
        assert any(
            np.min(line["y"]) < 0
            for line in axes[1]["lines"] if line["y"].size == 120
        )

    heatmap = captured[study_report.FIGURE_NAMES[-1]]["axes"][:3]
    arrays = [axis["images"][0]["array"] for axis in heatmap]
    assert all(array.shape == (24, 6) for array in arrays)
    assert np.min(arrays[1]) < 0
    assert set(np.unique(arrays[2])) == {0}
    assert heatmap[0]["images"][0]["cmap"] == "RdYlBu_r"
    assert heatmap[1]["images"][0]["cmap"] == "RdYlBu"
    assert tuple(study_report.STATUS_LABELS.values()) == (
        "明确通过", "明确失败", "数值边界无法确定",
        "24个月参考质量失败", "无效",
    )
    assert [axis["title"] for axis in heatmap] == [
        "均方根误差比（越低越好）",
        "纳什效率系数（越高越好）",
        "预设门槛状态",
    ]


def _write_synthetic_hpc_worker(destination, stdout_path, stderr_path, exp_id):
    destination = Path(destination)
    destination.mkdir(parents=True)
    Path(stdout_path).parent.mkdir(parents=True, exist_ok=True)
    Path(stdout_path).write_text(f"completed {exp_id}\n", encoding="utf-8")
    Path(stderr_path).write_text("", encoding="utf-8")
    (destination / "raw.npz").write_bytes(f"raw-{exp_id}".encode())
    (destination / "events.jsonl").write_text(
        json.dumps({"event": "calibration_completed", "exp_id": exp_id}) + "\n",
        encoding="utf-8",
    )
    (destination / "result.json").write_text(json.dumps({
        "status": "complete", "exp_id": exp_id,
    }), encoding="utf-8")
    input_hashes = {
        "raw_data": hpc_calibration.RAW_DATA_SHA256,
        "warmup_timestamps": "1" * 64,
        "warmup_forcing": "2" * 64,
        "calibration_timestamps": "3" * 64,
        "calibration_forcing": "4" * 64,
        "calibration_observations": "5" * 64,
    }
    environment = {
        "versions": dict(hpc_calibration.EXPECTED_VERSIONS),
        "dtype_required": "float64", "device_required": "cpu",
        "gradients_observed": False,
        "thread_settings": {"torch_threads_observed": 1},
    }
    receipt = {
        "schema": "regge_record_length_calibration_receipt_v01",
        "status": "complete", "passed": True, "exp_id": exp_id,
        "exit_code": 0, "environment": environment,
        "input_source_hashes": input_hashes,
        "files": {
            name: preparation.sha256(destination / name)
            for name in ("raw.npz", "result.json", "events.jsonl")
        },
    }
    (destination / "receipt.json").write_text(
        json.dumps(receipt), encoding="utf-8",
    )
    process = {
        "schema": "regge_record_length_calibration_process_v01",
        "exp_id": exp_id, "exit_code": 0,
        "stdout_sha256": preparation.sha256(Path(stdout_path)),
        "stderr_sha256": preparation.sha256(Path(stderr_path)),
    }
    (destination / "process.json").write_text(
        json.dumps(process), encoding="utf-8",
    )


def _stub_full_hpc_scientific_validation(monkeypatch):
    def validate(_directory, exp_id, *, receipt_sha256, process_sha256):
        assert len(receipt_sha256) == 64 and len(process_sha256) == 64
        return {
            "experiment_id": exp_id,
            "parameter_id": 17,
            "noise_id": 23,
            "score": 0.75,
            "source_hashes": {
                "receipt_json": receipt_sha256,
                "process_json": process_sha256,
            },
        }

    monkeypatch.setattr(
        study_selection, "validate_new_calibration_artifact", validate,
    )


def test_hpc_worker_rejects_self_hashed_non_npz_and_incomplete_result(tmp_path):
    exp_id = hpc_calibration._expected_ids()[0]
    destination = tmp_path / "calibration" / exp_id
    stdout_path = tmp_path / "logs" / f"{exp_id}.stdout.log"
    stderr_path = tmp_path / "logs" / f"{exp_id}.stderr.log"
    _write_synthetic_hpc_worker(
        destination, stdout_path, stderr_path, exp_id,
    )
    with pytest.raises((ValueError, RuntimeError, KeyError, OSError)):
        hpc_calibration._verify_worker(
            destination, exp_id, stdout_path, stderr_path,
        )


def test_hpc_slurm_entrypoints_are_bytecode_safe_and_attempt_scoped():
    calibration_text = hpc_calibration.HPC_CALIBRATION_SLURM.read_text(
        encoding="utf-8"
    )
    package_text = hpc_calibration.HPC_PACKAGE_SLURM.read_text(
        encoding="utf-8"
    )
    for text in (calibration_text, package_text):
        assert "export PYTHONDONTWRITEBYTECODE=1" in text
        assert '\"$PYTHON\" -B -u' in text
        assert "formal_calibration_capsule_004" in text
        assert "formal_calibration_capsule_001" not in text
        assert "formal_calibration_capsule_002" not in text
        assert "formal_calibration_capsule_003" not in text
    assert "regge_rl_cal_004" in calibration_text
    assert "formal_calibration_004" in calibration_text
    assert "formal_calibration_001" not in calibration_text
    assert "formal_calibration_002" not in calibration_text
    assert "transport_package_004" in package_text
    assert "transport_credentials_004" in package_text
    assert "formal_calibration_001" not in package_text
    assert "formal_calibration_002" not in package_text


def test_hpc_remote_runtime_paths_are_posix_on_the_windows_builder():
    paths = (
        str(hpc_calibration.REMOTE_RUNTIME_ROOT),
        str(hpc_calibration.REMOTE_RUNTIME_EVIDENCE_ROOT),
        str(hpc_calibration.REMOTE_RUNTIME_EVIDENCE_ROOT / "runtime_ready.json"),
        str(hpc_calibration.REMOTE_RUNTIME_EVIDENCE_ROOT / "pip_freeze.txt"),
    )
    assert all(value.startswith("/data1/") for value in paths)
    assert all("\\" not in value for value in paths)


def test_hpc_remote_batch_runs_exact_six_workers_without_retry(
        tmp_path, monkeypatch):
    _stub_full_hpc_scientific_validation(monkeypatch)
    capsule = tmp_path / "capsule"
    capsule.mkdir()
    (capsule / hpc_calibration.AUTHORIZATION_NAME).write_text(
        "{}", encoding="utf-8",
    )
    (capsule / hpc_calibration.CAPSULE_MANIFEST_NAME).write_text(
        "{}", encoding="utf-8",
    )
    (capsule / "project").mkdir()
    output = tmp_path / "remote-batch"
    monkeypatch.setattr(
        hpc_calibration, "verify_capsule",
        lambda _root: {"expected_experiments": hpc_calibration._expected_ids()},
    )
    monkeypatch.setattr(
        hpc_calibration, "_verify_runtime_environment",
        lambda _authorization: {
            "python": "3.11.5", "numpy": "1.26.4", "torch": "2.2.2",
            "torch_threads": 1, "cuda_available": False,
            "slurm_job_id": "123456", "slurm_job_name":
                hpc_calibration.EXPECTED_SLURM["job_name"],
            "slurm_cpus_per_task": "4", "hostname": "compute-node",
        },
    )
    called = []

    def fake_run(command, cwd, check):
        assert check is False and Path(cwd) == capsule / "project"
        assert command[0] == sys.executable and command[1] == "-B"
        exp_id = command[command.index("--exp-id") + 1]
        destination = Path(command[command.index("--destination") + 1])
        stdout_path = Path(command[command.index("--stdout") + 1])
        stderr_path = Path(command[command.index("--stderr") + 1])
        called.append(exp_id)
        _write_synthetic_hpc_worker(
            destination, stdout_path, stderr_path, exp_id,
        )
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(hpc_calibration.subprocess, "run", fake_run)
    assert hpc_calibration.run_remote_batch(capsule, output) == output
    assert called == hpc_calibration._expected_ids()
    receipt = json.loads((output / "batch_receipt.json").read_text(encoding="utf-8"))
    assert receipt["passed"] is True
    assert [row["exp_id"] for row in receipt["completed"]] == called
    assert all(row["status"] == "complete" for row in receipt["attempts"])
    assert not (output / "batch_failed.json").exists()


def test_hpc_remote_batch_stops_at_first_failure_and_keeps_failure_receipt(
        tmp_path, monkeypatch):
    capsule = tmp_path / "capsule"
    capsule.mkdir()
    (capsule / hpc_calibration.AUTHORIZATION_NAME).write_text(
        "{}", encoding="utf-8",
    )
    (capsule / hpc_calibration.CAPSULE_MANIFEST_NAME).write_text(
        "{}", encoding="utf-8",
    )
    (capsule / "project").mkdir()
    output = tmp_path / "failed-remote-batch"
    monkeypatch.setattr(hpc_calibration, "verify_capsule", lambda _root: {})
    monkeypatch.setattr(
        hpc_calibration, "_verify_runtime_environment", lambda _authorization: {
            "python": "3.11.5", "numpy": "1.26.4", "torch": "2.2.2",
            "cuda_available": False, "slurm_job_id": "123456",
            "slurm_job_name": hpc_calibration.EXPECTED_SLURM["job_name"],
            "slurm_cpus_per_task": "4",
        },
    )
    called = []

    def fail_first(command, cwd, check):
        assert command[0] == sys.executable and command[1] == "-B"
        called.append(command[command.index("--exp-id") + 1])
        return SimpleNamespace(returncode=17)

    monkeypatch.setattr(hpc_calibration.subprocess, "run", fail_first)
    with pytest.raises(RuntimeError, match="returncode=17"):
        hpc_calibration.run_remote_batch(capsule, output)
    assert called == [hpc_calibration._expected_ids()[0]]
    assert not (output / "batch_receipt.json").exists()
    failure = json.loads((output / "batch_failed.json").read_text(encoding="utf-8"))
    assert failure["passed"] is False
    assert failure["automatic_retry"] is False
    assert failure["current_experiment"] == called[0]


def test_hpc_remote_preflight_failure_is_structured_and_not_retried(
        tmp_path, monkeypatch):
    capsule = tmp_path / "invalid-capsule"
    capsule.mkdir()
    output = tmp_path / "failed-preflight"

    def reject_capsule(_root):
        raise RuntimeError("capsule rejected")

    monkeypatch.setattr(hpc_calibration, "verify_capsule", reject_capsule)
    with pytest.raises(RuntimeError, match="capsule rejected"):
        hpc_calibration.run_remote_batch(capsule, output)
    failure = json.loads(
        (output / "batch_failed.json").read_text(encoding="utf-8")
    )
    assert failure["passed"] is False
    assert failure["automatic_retry"] is False
    assert failure["attempts"] == [] and failure["completed"] == []


def test_hpc_batch_manifest_binds_nested_reserved_filenames(tmp_path):
    (tmp_path / "batch_manifest.json").write_text("root manifest", encoding="utf-8")
    (tmp_path / "batch_receipt.json").write_text("root receipt", encoding="utf-8")
    nested = tmp_path / "calibration" / "RL-E1-M06" / "batch_receipt.json"
    nested.parent.mkdir(parents=True)
    nested.write_text("nested evidence", encoding="utf-8")
    manifest = hpc_calibration._batch_manifest_files(tmp_path)
    assert set(manifest) == {"calibration/RL-E1-M06/batch_receipt.json"}
    nested.write_text("changed nested evidence", encoding="utf-8")
    assert hpc_calibration._batch_manifest_files(tmp_path) != manifest


def test_hpc_runtime_gate_requires_slurm_identity_resources_and_bound_evidence(
        tmp_path, monkeypatch):
    ready = tmp_path / "runtime_ready.json"
    freeze = tmp_path / "pip_freeze.txt"
    ready.write_text("{}\n", encoding="utf-8")
    freeze.write_text("packages\n", encoding="utf-8")
    authorization = {
        "runtime_root": str(Path(sys.prefix).resolve()),
        "python_bytecode_policy": dict(
            hpc_calibration.EXPECTED_BYTECODE_POLICY
        ),
        "runtime_ready_path": str(ready),
        "runtime_ready_sha256": preparation.sha256(ready),
        "runtime_freeze_path": str(freeze),
        "runtime_freeze_sha256": preparation.sha256(freeze),
    }
    observed = {
        "python": hpc_calibration.EXPECTED_VERSIONS["python"],
        "numpy": hpc_calibration.EXPECTED_VERSIONS["numpy"],
        "torch": hpc_calibration.EXPECTED_VERSIONS["torch"],
        "torch_threads": 1, "cuda_available": False,
        "slurm_job_id": "123456", "slurm_job_name":
            hpc_calibration.EXPECTED_SLURM["job_name"],
        "slurm_cpus_per_task": "4",
        "python_prefix": str(Path(sys.prefix).resolve()),
        "python_dont_write_bytecode_flag": True,
        "python_dont_write_bytecode_environment": "1",
        "thread_environment": {
            name: "1" for name in hpc_calibration._THREAD_ENVIRONMENT
        },
        "mkl_threading_layer": "GNU", "mkl_service_force_intel": "1",
        "hostname": "compute-node",
    }
    import pandas
    import psutil
    import threadpoolctl
    monkeypatch.setattr(pandas, "__version__", "2.3.2")
    monkeypatch.setattr(psutil, "__version__", "5.9.0")
    monkeypatch.setattr(pytest, "__version__", "9.1.1")
    monkeypatch.setattr(threadpoolctl, "__version__", "3.6.0")
    monkeypatch.setattr(hpc_calibration, "_observed_environment", lambda: dict(observed))
    monkeypatch.setattr(threadpoolctl, "threadpool_info", lambda: [{"num_threads": 1}])
    monkeypatch.setattr(hpc_calibration.torch, "cuda", SimpleNamespace(
        is_available=lambda: False,
    ))
    monkeypatch.setattr(hpc_calibration.torch, "get_num_threads", lambda: 1)
    result = hpc_calibration._verify_runtime_environment(authorization)
    assert result["slurm_job_id"] == "123456"
    observed["python_dont_write_bytecode_flag"] = False
    with pytest.raises(RuntimeError, match="bytecode contract"):
        hpc_calibration._verify_runtime_environment(authorization)
    observed["python_dont_write_bytecode_flag"] = True
    observed["python_dont_write_bytecode_environment"] = "0"
    with pytest.raises(RuntimeError, match="bytecode contract"):
        hpc_calibration._verify_runtime_environment(authorization)
    observed["python_dont_write_bytecode_environment"] = "1"
    observed["slurm_job_name"] = "wrong_job"
    with pytest.raises(RuntimeError, match="Slurm allocation"):
        hpc_calibration._verify_runtime_environment(authorization)


def test_hpc_import_is_exclusive_and_selection_compatible(
        tmp_path, monkeypatch):
    _stub_full_hpc_scientific_validation(monkeypatch)
    remote = tmp_path / "returned-batch"
    formal = tmp_path / "formal"
    remote.mkdir()
    formal.mkdir()
    deployment_binding = formal / hpc_calibration.FORMAL_DEPLOYMENT_BINDING_NAME
    deployment_binding.write_text("{}\n", encoding="utf-8")
    (formal / "events.jsonl").write_text("", encoding="utf-8")
    for name in (
            hpc_calibration.AUTHORIZATION_NAME, "batch_started.json",
            "events.jsonl", "batch_manifest.json", "batch_receipt.json"):
        (remote / name).write_text(
            json.dumps({"name": name}) + "\n", encoding="utf-8",
        )
    completed = []
    attempts = []
    for exp_id in hpc_calibration._expected_ids():
        stdout_path = remote / "calibration_process_logs" / f"{exp_id}.stdout.log"
        stderr_path = remote / "calibration_process_logs" / f"{exp_id}.stderr.log"
        destination = remote / "calibration" / exp_id
        _write_synthetic_hpc_worker(
            destination, stdout_path, stderr_path, exp_id,
        )
        completed.append(hpc_calibration._verify_worker(
            destination, exp_id, stdout_path, stderr_path,
        ))
        attempts.append({
            "exp_id": exp_id, "status": "complete", "returncode": 0,
            "process_evidence_present": True,
            "receipt_evidence_present": True,
            "stdout_present": True, "stderr_present": True,
        })
    remote_receipt = {
        "attempts": attempts,
        "completed": completed,
        "elapsed_seconds": 123.0,
        "environment": {"slurm_job_id": "123456"},
    }
    monkeypatch.setattr(hpc_calibration, "FORMAL_OUTPUT", formal)
    monkeypatch.setattr(
        hpc_calibration, "verify_remote_batch",
        lambda _remote, _formal: {
            "receipt": remote_receipt,
            "manifest_sha256": "a" * 64,
            "authorization_sha256": "b" * 64,
            "capsule_manifest_sha256": "c" * 64,
            "deployment_binding_sha256": preparation.sha256(
                deployment_binding
            ),
            "batch_started_sha256": preparation.sha256(
                remote / "batch_started.json"
            ),
            "transport_verification_receipt_sha256": "d" * 64,
            "completed": completed,
        },
    )
    assert hpc_calibration.import_remote_batch(remote, formal) == formal
    verified = __import__(
        "regge_record_length_study.selection", fromlist=["_verify_new_calibration_stage"]
    )._verify_new_calibration_stage(formal)
    assert list(verified) == hpc_calibration._expected_ids()
    receipt = json.loads(
        (formal / "calibration_receipt.json").read_text(encoding="utf-8")
    )
    assert receipt["passed"] is True
    assert receipt["execution_location"] == "hpc"
    assert receipt["remote_job_id"] == "123456"
    assert set(receipt["remote_evidence"]) == {
        hpc_calibration.AUTHORIZATION_NAME, "batch_started.json",
        "events.jsonl", "batch_manifest.json", "batch_receipt.json",
    }
    with pytest.raises(FileExistsError, match="not empty"):
        hpc_calibration.import_remote_batch(remote, formal)


def test_hpc_import_cannot_skip_local_signed_transport_receipt(
        tmp_path, monkeypatch):
    remote = tmp_path / "returned-batch"
    formal = tmp_path / "formal"
    remote.mkdir()
    formal.mkdir()
    (formal / "events.jsonl").write_text("", encoding="utf-8")
    binding = formal / hpc_calibration.FORMAL_DEPLOYMENT_BINDING_NAME
    binding.write_text("{}\n", encoding="utf-8")
    monkeypatch.setattr(hpc_calibration, "FORMAL_OUTPUT", formal)
    with pytest.raises(FileNotFoundError, match="transport verification"):
        hpc_calibration.import_remote_batch(remote, formal)
    assert not (formal / "calibration_receipt.json").exists()
    failure = json.loads(
        (formal / "calibration_failed.json").read_text(encoding="utf-8")
    )
    assert failure["passed"] is False


def _write_fake_authenticated_return(tmp_path):
    package = tmp_path / "package"
    source = tmp_path / "source"
    capsule = tmp_path / "capsule"
    package.mkdir()
    source.mkdir()
    capsule.mkdir()
    (package / hpc_calibration.RETURN_ARCHIVE_NAME).write_bytes(
        b"compressed-plain-batch"
    )
    (package / hpc_calibration.RETURN_ENCRYPTED_NAME).write_bytes(
        b"authenticated-encrypted-batch"
    )
    (capsule / hpc_calibration.CAPSULE_MANIFEST_NAME).write_text(
        "capsule-manifest\n", encoding="utf-8",
    )
    (capsule / hpc_calibration.AUTHORIZATION_NAME).write_text(
        "authorization\n", encoding="utf-8",
    )
    capsule_hash = preparation.sha256(
        capsule / hpc_calibration.CAPSULE_MANIFEST_NAME
    )
    authorization_hash = preparation.sha256(
        capsule / hpc_calibration.AUTHORIZATION_NAME
    )
    (source / hpc_calibration.AUTHORIZATION_NAME).write_bytes(
        (capsule / hpc_calibration.AUTHORIZATION_NAME).read_bytes()
    )
    started = {
        "capsule_manifest_sha256": capsule_hash,
        "authorization_sha256": authorization_hash,
    }
    (source / "batch_started.json").write_text(
        json.dumps(started), encoding="utf-8",
    )
    (source / "batch_manifest.json").write_text(
        json.dumps({"files": {}}), encoding="utf-8",
    )
    receipt = {
        "passed": True,
        "capsule_manifest_sha256": capsule_hash,
        "authorization_sha256": authorization_hash,
        "batch_started_sha256": preparation.sha256(
            source / "batch_started.json"
        ),
        "manifest_sha256": preparation.sha256(
            source / "batch_manifest.json"
        ),
        "environment": {"slurm_job_id": "123456"},
    }
    (source / "batch_receipt.json").write_text(
        json.dumps(receipt), encoding="utf-8",
    )
    return package, source, capsule


def test_hpc_return_manifest_binds_authenticated_ciphertext_and_source(tmp_path):
    package, source, capsule = _write_fake_authenticated_return(tmp_path)
    path = hpc_calibration.write_encrypted_return_manifest(
        package, source, capsule,
    )
    manifest = json.loads(path.read_text(encoding="utf-8"))
    assert manifest["encryption"] == "CMS-AuthEnvelopedData-AES-256-GCM"
    assert manifest["signature"] == "RSA-PSS-SHA256"
    assert manifest["upload_only"] == [
        hpc_calibration.RETURN_ENCRYPTED_NAME,
        "transport_manifest.json",
        "transport_manifest.sig",
    ]
    assert all("passphrase" not in name for name in manifest["files"])
    assert manifest["files"][hpc_calibration.RETURN_ENCRYPTED_NAME]["sha256"] == (
        preparation.sha256(package / hpc_calibration.RETURN_ENCRYPTED_NAME)
    )
    assert manifest["source"]["capsule_manifest_sha256"] == preparation.sha256(
        capsule / hpc_calibration.CAPSULE_MANIFEST_NAME
    )


@pytest.mark.skipif(shutil.which("openssl") is None, reason="OpenSSL unavailable")
def test_hpc_return_signature_is_pinned_and_rejects_ciphertext_change(tmp_path):
    package, source, capsule = _write_fake_authenticated_return(tmp_path)
    manifest_path = hpc_calibration.write_encrypted_return_manifest(
        package, source, capsule,
    )
    private_key = tmp_path / "signing_private.pem"
    public_key = tmp_path / "signing_public.pem"
    subprocess.run([
        "openssl", "genpkey", "-algorithm", "RSA", "-pkeyopt",
        "rsa_keygen_bits:2048", "-out", str(private_key),
    ], check=True, capture_output=True)
    subprocess.run([
        "openssl", "pkey", "-in", str(private_key), "-pubout",
        "-out", str(public_key),
    ], check=True, capture_output=True)
    signature = package / "transport_manifest.sig"
    subprocess.run([
        "openssl", "dgst", "-sha256", "-sign", str(private_key),
        "-sigopt", "rsa_padding_mode:pss",
        "-sigopt", "rsa_pss_saltlen:-1", "-out", str(signature),
        str(manifest_path),
    ], check=True, capture_output=True)

    formal = tmp_path / "formal"
    formal.mkdir()
    preparation_receipt = formal / "preparation_receipt.json"
    preparation_receipt.write_text("{}\n", encoding="utf-8")
    binding_path = formal / hpc_calibration.FORMAL_DEPLOYMENT_BINDING_NAME
    binding_path.write_text(json.dumps({
        "schema": "regge_record_length_hpc_deployment_binding_v01",
        "formal_attempt": hpc_calibration.FORMAL_ATTEMPT,
        "formal_attempt_relative": hpc_calibration.FORMAL_ATTEMPT_RELATIVE,
        "plan_sha256": preparation.sha256(hpc_calibration.PLAN),
        "raw_data_sha256": hpc_calibration.RAW_DATA_SHA256,
        "runtime_ready_sha256": hpc_calibration.REMOTE_RUNTIME_READY_SHA256,
        "runtime_freeze_sha256": hpc_calibration.REMOTE_RUNTIME_FREEZE_SHA256,
        "retry_policy": "none",
        "preparation_receipt_sha256": preparation.sha256(preparation_receipt),
        "capsule_manifest_sha256": preparation.sha256(
            capsule / hpc_calibration.CAPSULE_MANIFEST_NAME
        ),
        "authorization_sha256": preparation.sha256(
            capsule / hpc_calibration.AUTHORIZATION_NAME
        ),
        "capsule_archive_sha256": "a" * 64,
        "capsule_archive_bytes": 1,
        "hpc_signing_public_key_sha256": preparation.sha256(public_key),
        "output_recipient_certificate_sha256": "b" * 64,
    }), encoding="utf-8")
    verified = hpc_calibration.verify_return_package(
        package, binding_path, public_key, formal,
    )
    assert verified["manifest_sha256"] == preparation.sha256(manifest_path)

    transport_receipt = hpc_calibration.record_return_transport_verification(
        package, package / hpc_calibration.RETURN_ARCHIVE_NAME, source,
        public_key, formal,
    )
    assert json.loads(transport_receipt.read_text(encoding="utf-8"))["passed"] is True
    assert hpc_calibration._verify_transport_verification_receipt(
        source, formal,
    )["signature_verified_with_pinned_hpc_key"] is True
    original_batch_receipt = (source / "batch_receipt.json").read_bytes()
    (source / "batch_receipt.json").write_bytes(b"changed-returned-batch")
    with pytest.raises(RuntimeError, match="differs from verified transport"):
        hpc_calibration._verify_transport_verification_receipt(source, formal)
    (source / "batch_receipt.json").write_bytes(original_batch_receipt)

    (package / hpc_calibration.RETURN_ENCRYPTED_NAME).write_bytes(
        b"changed-after-signature"
    )
    with pytest.raises(RuntimeError, match="manifest differs"):
        hpc_calibration.verify_return_package(
            package, binding_path, public_key, formal,
        )


@pytest.mark.skipif(shutil.which("openssl") is None, reason="OpenSSL unavailable")
def test_cms_return_encryption_is_authenticated_aes_256_gcm(tmp_path):
    private_key = tmp_path / "recipient_private.pem"
    certificate = tmp_path / "recipient_certificate.pem"
    config = tmp_path / "recipient.cnf"
    config.write_text(
        "[req]\ndistinguished_name=dn\nprompt=no\n"
        "x509_extensions=ext\n[dn]\nCN=Regge Test Recipient\n"
        "[ext]\nbasicConstraints=critical,CA:false\n"
        "keyUsage=critical,keyEncipherment\n",
        encoding="utf-8",
    )
    subprocess.run([
        "openssl", "genpkey", "-algorithm", "RSA", "-pkeyopt",
        "rsa_keygen_bits:2048", "-out", str(private_key),
    ], check=True, capture_output=True)
    subprocess.run([
        "openssl", "req", "-new", "-x509", "-sha256", "-days", "2",
        "-key", str(private_key), "-config", str(config),
        "-out", str(certificate),
    ], check=True, capture_output=True)
    plaintext = tmp_path / "payload.tar.zst"
    encrypted = tmp_path / "payload.cms"
    decrypted = tmp_path / "payload.decrypted.tar.zst"
    plaintext.write_bytes(b"authenticated payload" * 100)
    subprocess.run([
        "openssl", "cms", "-encrypt", "-binary", "-aes-256-gcm",
        "-outform", "DER", "-in", str(plaintext), "-out", str(encrypted),
        str(certificate),
    ], check=True, capture_output=True)
    structure = subprocess.run([
        "openssl", "cms", "-cmsout", "-inform", "DER", "-in",
        str(encrypted), "-print",
    ], check=True, capture_output=True, text=True).stdout
    assert "authEnvelopedData" in structure and "aes-256-gcm" in structure
    subprocess.run([
        "openssl", "cms", "-decrypt", "-binary", "-inform", "DER",
        "-in", str(encrypted), "-inkey", str(private_key), "-recip",
        str(certificate), "-out", str(decrypted),
    ], check=True, capture_output=True)
    assert decrypted.read_bytes() == plaintext.read_bytes()


def test_common_warmup_state_masks_match_bound_sources():
    masks = common_warmup_state_masks()
    assert [int(masks[e].sum()) for e in ("E1", "E2", "E3")] == [1699, 1699, 1695]
    assert all(masks[e].shape == (2048,) and masks[e].dtype == np.bool_ for e in masks)
    assert all(masks[e][pid] for e, pid in (
        ("E1", 67), ("E1", 1944), ("E2", 1072),
        ("E2", 1944), ("E3", 1926), ("E3", 712),
    ))


def test_source_inputs_have_continuous_axis_and_frozen_prefix():
    dates, forcing, flow, checks = load_inputs()
    assert dates.shape == (105191,)
    assert forcing.shape == (105191, 2)
    assert flow.shape == (105191,)
    assert dates[0] == np.datetime64("1999-01-01T01", "h")
    assert dates[-1] == np.datetime64("2010-12-31T23", "h")
    assert np.all(np.diff(dates) == np.timedelta64(1, "h"))
    assert checks["archived_prefix_hours"] == 52607
    assert checks["archived_prefix_exact"] is True
    assert checks["raw_data_sha256"] == "64e9b1b3d47655e2008dd4dbb380d7a198811dd79b0094f1632467c0e6f605fa"


def _stub_successful_preparation_gates(monkeypatch):
    monkeypatch.setattr(preparation, "_source_hashes", lambda: {})
    monkeypatch.setattr(preparation, "_verify_bound_sources", lambda: {})
    monkeypatch.setattr(preparation, "load_inputs", lambda: (
        np.asarray([np.datetime64("1999-01-01T01", "h")]),
        np.zeros((1, 2), dtype=np.float64),
        np.zeros(1, dtype=np.float64),
        {},
    ))
    monkeypatch.setattr(preparation, "origin_arrays", lambda _dates: {})
    monkeypatch.setattr(preparation, "common_warmup_state_masks", lambda: {
        endpoint: np.ones(1, dtype=np.bool_) for endpoint in ("E1", "E2", "E3")
    })
    monkeypatch.setattr(preparation, "_resource_plan", lambda _root: {"passed": True})
    monkeypatch.setattr(preparation, "_snapshot_sources", lambda _root, _hashes: {})
    monkeypatch.setattr(preparation, "_registry", lambda _root: [])


def test_prepare_refuses_an_existing_attempt_without_mutating_it(tmp_path, monkeypatch):
    root = tmp_path / "occupied"
    root.mkdir()
    marker = root / "keep.txt"
    marker.write_text("unchanged", encoding="utf-8")
    monkeypatch.setattr(preparation, "OUTPUT", root)
    with pytest.raises(FileExistsError, match="already exists"):
        preparation.prepare()
    assert marker.read_text(encoding="utf-8") == "unchanged"
    assert list(root.iterdir()) == [marker]


def test_prepare_gate_failure_keeps_failure_and_event_receipts(tmp_path, monkeypatch):
    root = tmp_path / "failed-attempt"
    monkeypatch.setattr(preparation, "OUTPUT", root)

    def reject_version():
        raise RuntimeError("version gate rejected")

    monkeypatch.setattr(preparation, "_versions", reject_version)
    with pytest.raises(RuntimeError, match="version gate rejected"):
        preparation.prepare()
    failure = preparation.read_json(root / "preparation_failed.json")
    assert failure["passed"] is False
    assert failure["error_type"] == "RuntimeError"
    assert failure["error"] == "version gate rejected"
    events = [preparation.json.loads(line)
              for line in (root / "events.jsonl").read_text(encoding="utf-8").splitlines()]
    assert [row["event"] for row in events] == ["prepare_started", "prepare_failed"]
    assert not (root / "preparation_receipt.json").exists()


def test_prepare_completion_event_failure_cannot_publish_success(tmp_path, monkeypatch):
    root = tmp_path / "completion-event-failed"
    monkeypatch.setattr(preparation, "OUTPUT", root)
    _stub_successful_preparation_gates(monkeypatch)
    original_event = preparation._event

    def fail_completion_event(event_root, event_name, **fields):
        if event_name == "prepare_completed":
            raise RuntimeError("completion event write failed")
        return original_event(event_root, event_name, **fields)

    monkeypatch.setattr(preparation, "_event", fail_completion_event)
    with pytest.raises(RuntimeError, match="completion event write failed"):
        preparation.prepare()
    assert not (root / "preparation_receipt.json").exists()
    assert preparation.read_json(root / "preparation_failed.json")["passed"] is False
    events = [preparation.json.loads(line)
              for line in (root / "events.jsonl").read_text(encoding="utf-8").splitlines()]
    assert [row["event"] for row in events] == ["prepare_started", "prepare_failed"]


def test_prepare_final_receipt_failure_cannot_publish_success(tmp_path, monkeypatch):
    root = tmp_path / "success-marker-failed"
    monkeypatch.setattr(preparation, "OUTPUT", root)
    _stub_successful_preparation_gates(monkeypatch)

    def reject_success_marker(_root, _record):
        raise RuntimeError("atomic success marker failed")

    monkeypatch.setattr(preparation, "_write_success_receipt_atomic", reject_success_marker)
    with pytest.raises(RuntimeError, match="atomic success marker failed"):
        preparation.prepare()
    assert not (root / "preparation_receipt.json").exists()
    assert preparation.read_json(root / "preparation_failed.json")["passed"] is False
    events = [preparation.json.loads(line)
              for line in (root / "events.jsonl").read_text(encoding="utf-8").splitlines()]
    assert [row["event"] for row in events] == [
        "prepare_started", "prepare_completed", "prepare_failed",
    ]


def test_resource_plan_is_derived_from_explicit_array_shapes(tmp_path):
    plan = preparation._resource_plan(tmp_path / "attempt")
    estimates = plan["array_shape_estimates"]
    raw = estimates["new_calibration_raw_arrays"]
    assert len(raw) == 6
    assert raw["RL-E1-M06"]["arrays"]["hydrologic_predictions"] == {
        "shape": [2048, 4416], "dtype": "float64", "elements": 9043968,
        "bytes": 2048 * 4416 * 8,
    }
    assert raw["RL-E3-M12"]["warmup_hours"] == 35063
    assert estimates["state_checkpoints"]["RL-E1-M03"]["checkpoint_count"] == 113
    assert estimates["prediction_blocks"]["RL-E1-M03"]["layouts_by_origin_count"]["30"]["file_count"] == 84
    assert estimates["prediction_blocks"]["RL-E1-M03"]["layouts_by_origin_count"]["1"]["file_count"] == 1
    assert estimates["independent_reconstruction"]["arrays"]["reconstructed_predictions"]["shape"] == [30256, 120]
    assert plan["estimated_total_output_bytes"] == sum(plan["persistent_components"].values())
    assert plan["estimated_temporary_disk_bytes"] == sum(plan["temporary_components"].values())
    assert plan["estimated_peak_disk_bytes"] == (
        plan["estimated_total_output_bytes"] + plan["estimated_temporary_disk_bytes"]
    )
    assert all(value > 0 for value in plan["temporary_components"].values())
    assert plan["upstream_resource_receipt_sha256"] == "be28bd2e2e6be9e624096bb890b4835973a9f15b08bf4677cd68a9001df27b8f"
    assert plan["required_memory_bytes"] == max(4 * 1024**3, 2 * plan["estimated_peak_memory_bytes"])
    assert plan["required_disk_bytes"] == max(20 * 1024**3, 2 * plan["estimated_peak_disk_bytes"])


def test_resource_receipt_is_not_read_before_manifest_fingerprint(tmp_path, monkeypatch):
    archive = tmp_path / "untrusted-archive"
    archive.mkdir()
    (archive / "manifest.json").write_text("{}", encoding="utf-8")
    (archive / "formal_resource_receipt.json").write_text("not json", encoding="utf-8")
    monkeypatch.setattr(preparation, "ARCHIVE", archive)
    with pytest.raises(RuntimeError, match="manifest changed before resource receipt read"):
        preparation._verified_upstream_resource_receipt()


def test_both_numerical_core_directories_have_required_files():
    records = preparation._validate_numerical_core_directories()
    assert set(records) == {"repaired", "sealed"}
    assert "noise_search.py" in preparation._NUMERICAL_ENTRYPOINT_DIRECT_DEPENDENCIES[
        "short_record_calibration.py"
    ]
    assert "noise_search.py" in preparation._CORE_REQUIRED_FILES
    assert all(set(row["required_files"]) == set(preparation._CORE_REQUIRED_FILES)
               for row in records.values())


@pytest.mark.parametrize("attribute", ["REPAIRED_NUMERICAL_CORE", "SEALED_NUMERICAL_CORE"])
def test_missing_numerical_core_directory_is_rejected(tmp_path, monkeypatch, attribute):
    monkeypatch.setattr(preparation, attribute, tmp_path / f"missing-{attribute.lower()}")
    with pytest.raises(RuntimeError, match="numerical core directory is missing"):
        preparation._validate_numerical_core_directories()


def test_numerical_core_directory_missing_expected_files_is_rejected(tmp_path, monkeypatch):
    incomplete = tmp_path / "incomplete-core"
    incomplete.mkdir()
    monkeypatch.setattr(preparation, "REPAIRED_NUMERICAL_CORE", incomplete)
    with pytest.raises(RuntimeError, match="numerical core files are missing"):
        preparation._validate_numerical_core_directories()


def test_prepare_rejects_missing_noise_search_direct_dependency(tmp_path, monkeypatch):
    incomplete = tmp_path / "core-without-noise-search"
    for relative in preparation._CORE_REQUIRED_FILES:
        if relative == "noise_search.py":
            continue
        path = incomplete / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("# test placeholder\n", encoding="utf-8")
    root = tmp_path / "missing-dependency-attempt"
    monkeypatch.setattr(preparation, "REPAIRED_NUMERICAL_CORE", incomplete)
    monkeypatch.setattr(preparation, "OUTPUT", root)
    with pytest.raises(RuntimeError, match="noise_search.py"):
        preparation.prepare()
    assert not (root / "preparation_receipt.json").exists()
    failure = preparation.read_json(root / "preparation_failed.json")
    assert failure["passed"] is False
    assert "noise_search.py" in failure["error"]


def test_prepare_and_verify_freeze_contract_in_temporary_attempt(tmp_path, monkeypatch):
    formal_output_existed = preparation.FORMAL_OUTPUT.exists()
    root = tmp_path / "prepared-attempt"
    monkeypatch.setattr(preparation, "OUTPUT", root)
    assert preparation.prepare() == root
    verified = preparation.verify_prepared()
    assert verified["schema"] == "regge_record_length_study_v01"
    assert len(verified["registry"]) == 24
    assert sum(row["record_type"] == "selection" for row in verified["registry"]) == 12
    assert sum(row["record_type"] == "assessment" for row in verified["registry"]) == 12
    assert all(row["assessment_id"].endswith("-MATCHED3")
               for row in verified["registry"] if row["record_type"] == "assessment")
    assert (root / "config.json").is_file()
    assert (root / "source_binding.json").is_file()
    assert (root / "origin_manifest.npz").is_file()
    assert (root / "preparation_receipt.json").is_file()
    receipt = preparation.read_json(root / "preparation_receipt.json")
    assert "events.jsonl" not in receipt["files"]
    events = [preparation.json.loads(line)
              for line in (root / "events.jsonl").read_text(encoding="utf-8").splitlines()]
    assert events[-1]["event"] == "prepare_completed"
    preparation._event(root, "calibrate_started", stage="calibrate")
    assert preparation.verify_prepared()["schema"] == "regge_record_length_study_v01"

    config_path = root / "config.json"
    frozen_config = config_path.read_bytes()
    config_path.write_bytes(frozen_config + b"\n")
    with pytest.raises(RuntimeError, match="frozen preparation artifact changed: config.json"):
        preparation.verify_prepared()
    config_path.write_bytes(frozen_config)

    preparation.write_json_new(root / "preparation_failed.json", {"passed": False})
    with pytest.raises(RuntimeError, match="failure receipt coexists"):
        preparation.verify_prepared()
    assert preparation.FORMAL_OUTPUT.exists() is formal_output_existed


@pytest.fixture(scope="module")
def full_inputs():
    return load_inputs()


def test_only_six_and_twelve_month_windows_are_computed():
    assert [spec["exp_id"] for spec in missing_calibration_specs()] == [
        "RL-E1-M06", "RL-E1-M12", "RL-E2-M06",
        "RL-E2-M12", "RL-E3-M06", "RL-E3-M12",
    ]


def test_post_cutoff_flow_is_absent_from_calibration_inputs(full_inputs):
    bound = bind_calibration_inputs(full_inputs, "RL-E1-M06")
    assert bound.calibration_timestamps[-1] == np.datetime64("2001-12-31T23", "h")
    assert bound.calibration_observations.shape == (4416,)
    assert not bound.calibration_observations.flags.writeable


def test_adapter_binds_exact_new_window_and_runtime(full_inputs):
    bound = bind_calibration_inputs(full_inputs, "RL-E2-M12")
    assert bound.meta["exp_id"] == "RL-E2-M12"
    assert bound.meta["warmup_start"] == "1999-01-01T01"
    assert bound.meta["calibration_start"] == "2001-07-01T00"
    assert bound.meta["calibration_stop"] == "2002-07-01T00"
    assert bound.meta["parameter_count"] == 2048
    assert bound.meta["noise_count"] == 128
    assert bound.meta["dtype"] == "float64"


def test_actual_slice_future_flow_is_byte_isolated(full_inputs):
    dates, forcing, flow, checks = full_inputs
    changed = flow.copy()
    changed[dates >= np.datetime64("2002-01-01T00", "h")] += 12345.0
    original = bind_calibration_inputs(full_inputs, "RL-E1-M06")
    altered = bind_calibration_inputs((dates, forcing, changed, checks), "RL-E1-M06")
    np.testing.assert_array_equal(original.calibration_observations, altered.calibration_observations)
    assert original.meta["source_hashes"] == altered.meta["source_hashes"]


def test_adapter_rejects_shifted_start_warmup_gap_and_non_double(full_inputs):
    bound = bind_calibration_inputs(full_inputs, "RL-E1-M06")
    shifted = replace(bound, calibration_timestamps=bound.calibration_timestamps + np.timedelta64(1, "h"))
    with pytest.raises(ValueError, match="calibration timestamps"):
        calibration._validated_core_inputs(shifted, "RL-E1-M06")
    gap = replace(
        bound,
        warmup_timestamps=np.delete(bound.warmup_timestamps, 10),
        warmup_forcing=np.delete(bound.warmup_forcing, 10, axis=0),
    )
    with pytest.raises(ValueError, match="warmup timestamps"):
        calibration._validated_core_inputs(gap, "RL-E1-M06")
    wrong_dtype = replace(bound, calibration_forcing=bound.calibration_forcing.astype(np.float32))
    with pytest.raises(ValueError, match="float64"):
        calibration._validated_core_inputs(wrong_dtype, "RL-E1-M06")


def test_changed_seed_and_unsealed_source_are_rejected_before_execution():
    contract, core, _ = calibration._load_sealed_core()
    config = contract.proposed_config()
    config["parameter_design"]["seed"] += 1
    with pytest.raises(ValueError, match="parameter-design seed"):
        calibration._validate_scientific_config(config, contract, core)

    class WrongModule:
        __file__ = str(PROJECT / "python" / "some_other_core.py")

    with pytest.raises(RuntimeError, match="sealed runtime"):
        calibration._assert_sealed_module_paths(WrongModule)


def test_production_execute_bound_path_matches_sealed_synthetic_core(
        full_inputs, monkeypatch):
    contract, core, noise = calibration._load_sealed_core()
    config = contract.proposed_config()
    records = [
        dict(config["fixed_fields"], cw=450.0 + index, cv=100.0, cg=1e7, cq=10.0, cs=0.2)
        for index in range(16)
    ]
    design = noise.build_noise_design()[:3]
    dates = np.arange(
        np.datetime64("2000-01-01T00"),
        np.datetime64("2000-01-02T08"),
        np.timedelta64(1, "h"),
    )
    inputs = dict(
        warmup_timestamps=dates[:8],
        warmup_forcing=np.ones((8, 2), dtype=np.float64) * 0.01,
        calibration_timestamps=dates[8:],
        calibration_forcing=np.ones((24, 2), dtype=np.float64) * 0.01,
        calibration_observations=np.linspace(0.01, 0.03, 24, dtype=np.float64),
    )
    expected = core._calibrate_synthetic_for_test(
        inputs, records, design, leads=(1, 2, 3, 4),
    )
    portable_generated = calibration._canonical_design(
        calibration.CANONICAL_NOISE_DESIGN,
        file_sha256=calibration.CANONICAL_NOISE_FILE_SHA256,
        array_sha256_expected=calibration.NOISE_DESIGN_SHA256,
        shape=(128, 5),
        label="noise",
    ).copy()
    for _ in range(15):
        portable_generated[48, 1] = np.nextafter(
            portable_generated[48, 1], -np.inf,
        )
    monkeypatch.setattr(
        noise, "build_noise_design",
        lambda seed=909001: portable_generated.copy(),
    )
    original_execute = core._execute
    calls = []

    def bounded_execute(production_inputs, production_records, production_design,
                        parameter_values, leads, record_event, *, synthetic):
        calls.append({
            "input_lengths": (
                len(production_inputs["warmup_timestamps"]),
                len(production_inputs["calibration_timestamps"]),
            ),
            "parameter_count": len(production_records),
            "noise_count": len(production_design),
            "parameter_shape": parameter_values.shape,
            "parameter_sha256": preparation.array_sha256(parameter_values),
            "noise_sha256": preparation.array_sha256(production_design),
            "leads": leads,
            "synthetic": synthetic,
        })
        return original_execute(
            inputs,
            records,
            design,
            np.asarray([[record[key] for key in ("cw", "cv", "cg", "cq", "cs")]
                        for record in records]),
            (1, 2, 3, 4),
            record_event,
            synthetic=True,
        )

    monkeypatch.setattr(core, "_execute", bounded_execute)
    bound = bind_calibration_inputs(full_inputs, "RL-E1-M06")
    actual = calibration._execute_bound_calibration(
        bound, "RL-E1-M06", lambda *args, **kwargs: None,
    )
    assert calls == [{
        "input_lengths": (21887, 4416),
        "parameter_count": 2048,
        "noise_count": 128,
        "parameter_shape": (2048, 5),
        "parameter_sha256": calibration.PARAMETER_DESIGN_SHA256,
        "noise_sha256": calibration.NOISE_DESIGN_SHA256,
        "leads": (1, 24, 48, 120),
        "synthetic": False,
    }]
    assert actual["status"] == expected["status"]
    assert actual["selected"] == expected["selected"]
    assert actual["array_hashes"] == expected["array_hashes"]
    assert actual["design_binding"]["noise"]["maximum_float64_steps"] == 15
    assert actual["design_binding"]["noise"]["generated_array_sha256"] == (
        preparation.array_sha256(portable_generated)
    )
    assert actual["design_binding"]["noise"]["canonical_bytes_used_for_execution"] is True
    assert actual["raw"].keys() == expected["raw"].keys()
    for name in actual["raw"]:
        if isinstance(actual["raw"][name], np.ndarray):
            np.testing.assert_array_equal(actual["raw"][name], expected["raw"][name])


def test_partial_metadata_requires_identity_and_original_exception(full_inputs):
    bound = bind_calibration_inputs(full_inputs, "RL-E1-M06")
    partial = {
        "status": "engineering_failed",
        "partial": True,
        "raw": {"reached": np.arange(3)},
        "engineering_error": {"type": "RuntimeError", "reason": "boom"},
    }
    with pytest.raises(ValueError, match="experiment identity"):
        calibration._validate_result_metadata(partial, bound, require_partial=True)
    error = RuntimeError("boom")
    annotated = calibration._annotate_result(partial, bound, "RL-E1-M06", error=error)
    assert annotated["exp_id"] == "RL-E1-M06"
    assert annotated["partial"] is True
    assert annotated["original_exception"] == {"type": "RuntimeError", "reason": "boom"}
    assert annotated["reached_array_counts"] == {"reached": 3}
    calibration._validate_result_metadata(annotated, bound, require_partial=True)


def test_calibrate_one_writes_complete_exclusive_evidence(
        full_inputs, tmp_path, monkeypatch):
    import regge_record_length_study.contract as study_contract

    monkeypatch.setattr(study_contract, "load_inputs", lambda: full_inputs)

    def fake_execute(bound, exp_id, record_event):
        record_event("fake_core_reached")
        return calibration._annotate_result({
            "status": "complete",
            "partial": False,
            "raw": {"reached": np.arange(3, dtype=np.int64)},
        }, bound, exp_id)

    monkeypatch.setattr(calibration, "_execute_bound_calibration", fake_execute)
    spec = missing_calibration_specs()[0]
    destination = tmp_path / spec["exp_id"]
    assert calibration.calibrate_one(spec, destination) == destination
    assert {path.name for path in destination.iterdir()} == {
        "raw.npz", "result.json", "events.jsonl", "receipt.json",
    }
    result = preparation.read_json(destination / "result.json")
    receipt = preparation.read_json(destination / "receipt.json")
    assert result["exp_id"] == spec["exp_id"]
    assert result["reached_array_counts"] == {"reached": 3}
    assert receipt["passed"] is True and receipt["exit_code"] == 0
    with pytest.raises(FileExistsError):
        calibration.calibrate_one(spec, destination)


def test_calibrate_one_preserves_partial_result_and_raises_nonzero(
        full_inputs, tmp_path, monkeypatch):
    import regge_record_length_study.contract as study_contract

    monkeypatch.setattr(study_contract, "load_inputs", lambda: full_inputs)

    def fake_partial(bound, exp_id, record_event):
        error = RuntimeError("sealed core stopped")
        partial = {
            "status": "engineering_failed",
            "partial": True,
            "raw": {"reached": np.arange(5, dtype=np.int64)},
            "engineering_error": {"type": "RuntimeError", "reason": str(error)},
        }
        error.short_record_partial_result = calibration._annotate_result(
            partial, bound, exp_id, error=error,
        )
        raise error

    monkeypatch.setattr(calibration, "_execute_bound_calibration", fake_partial)
    spec = missing_calibration_specs()[1]
    destination = tmp_path / spec["exp_id"]
    with pytest.raises(RuntimeError, match="sealed core stopped"):
        calibration.calibrate_one(spec, destination)
    result = preparation.read_json(destination / "result.json")
    receipt = preparation.read_json(destination / "receipt.json")
    assert result["partial"] is True
    assert result["original_exception"] == {
        "type": "RuntimeError", "reason": "sealed core stopped",
    }
    assert result["reached_array_counts"] == {"reached": 5}
    assert receipt["passed"] is False and receipt["exit_code"] == 1


def test_preflight_failure_records_known_environment_sources_and_stage(
        tmp_path, monkeypatch):
    import regge_record_length_study.contract as study_contract

    monkeypatch.setattr(
        study_contract, "load_inputs",
        lambda: (_ for _ in ()).throw(RuntimeError("loader stopped")),
    )
    spec = missing_calibration_specs()[0]
    destination = tmp_path / spec["exp_id"]
    with pytest.raises(RuntimeError, match="loader stopped"):
        calibration.calibrate_one(spec, destination)
    result = preparation.read_json(destination / "result.json")
    receipt = preparation.read_json(destination / "receipt.json")
    assert result["failure_stage"] == "input_loading"
    assert result["environment"]["versions"] == calibration.EXPECTED_VERSIONS
    assert result["environment"]["thread_settings"]["torch_threads_observed"] >= 1
    assert result["environment"]["thread_settings"]["cpu_threads_required"] == 1
    assert result["input_source_hashes"]["raw_data"] == calibration.RAW_DATA_SHA256
    assert result["input_source_hashes"]["calibration_observations"] is None
    assert receipt["failure_stage"] == "input_loading"
    assert receipt["environment"] == result["environment"]
    assert receipt["input_source_hashes"] == result["input_source_hashes"]


def test_worker_preflight_failure_repeats_context_in_process_evidence(
        tmp_path, monkeypatch):
    import regge_record_length_study.contract as study_contract

    monkeypatch.setattr(
        study_contract, "load_inputs",
        lambda: (_ for _ in ()).throw(RuntimeError("loader stopped")),
    )
    spec = missing_calibration_specs()[0]
    destination = tmp_path / "calibration" / spec["exp_id"]
    stdout_path = tmp_path / "logs" / "stdout.log"
    stderr_path = tmp_path / "logs" / "stderr.log"
    assert stage_runner.calibration_worker(
        spec["exp_id"], destination, stdout_path, stderr_path,
    ) == 1
    process = preparation.read_json(destination / "process.json")
    result = preparation.read_json(destination / "result.json")
    assert process["exit_code"] == 1
    assert process["failure_stage"] == "input_loading"
    assert process["environment"] == result["environment"]
    assert process["input_source_hashes"] == result["input_source_hashes"]


def test_worker_refuses_existing_destination_without_mutating_it(tmp_path):
    spec = missing_calibration_specs()[0]
    destination = tmp_path / "calibration" / spec["exp_id"]
    destination.mkdir(parents=True)
    marker = destination / "keep.txt"
    marker.write_text("unchanged", encoding="utf-8")
    stdout_path = tmp_path / "logs" / "stdout.log"
    stderr_path = tmp_path / "logs" / "stderr.log"
    with pytest.raises(FileExistsError):
        stage_runner.calibration_worker(
            spec["exp_id"], destination, stdout_path, stderr_path,
        )
    assert list(destination.iterdir()) == [marker]
    assert marker.read_text(encoding="utf-8") == "unchanged"
    assert not stdout_path.exists() and not stderr_path.exists()


def _prepared_registry_for_stage_test():
    return {
        "registry": [
            {
                "record_type": "selection",
                "selection_id": spec["exp_id"],
                "calibration_source": "new",
            }
            for spec in missing_calibration_specs()
        ]
    }


def test_parent_preserves_external_kill_without_child_process_json(
        tmp_path, monkeypatch):
    root = tmp_path / "prepared"
    root.mkdir()
    (root / "events.jsonl").touch()
    monkeypatch.setattr(
        stage_runner, "_verify_prepared_root",
        lambda supplied: _prepared_registry_for_stage_test(),
    )
    monkeypatch.setattr(
        stage_runner.subprocess, "run",
        lambda *args, **kwargs: SimpleNamespace(returncode=-9),
    )
    with pytest.raises(RuntimeError, match="externally|evidence|failed"):
        stage_runner.run_calibrations(root)
    failure = preparation.read_json(root / "calibration_failed.json")
    expected_ids = [spec["exp_id"] for spec in missing_calibration_specs()]
    assert failure["status"] == "failed" and failure["passed"] is False
    assert failure["started_experiments"] == [expected_ids[0]]
    assert failure["failed_experiment"] == expected_ids[0]
    assert failure["attempts"][0]["returncode"] == -9
    assert failure["attempts"][0]["process_evidence_present"] is False
    assert failure["completed"] == []
    assert failure["unstarted"] == expected_ids[1:]
    assert (root / "calibration_started.json").is_file()
    assert not (root / "calibration_receipt.json").exists()


def test_stage_initialization_failure_keeps_exclusive_start_and_failure_receipts(
        tmp_path, monkeypatch):
    root = tmp_path / "prepared"
    root.mkdir()
    (root / "events.jsonl").touch()
    logs = root / "calibration_process_logs"
    logs.mkdir()
    marker = logs / "keep.txt"
    marker.write_text("unchanged", encoding="utf-8")
    monkeypatch.setattr(
        stage_runner, "_verify_prepared_root",
        lambda supplied: _prepared_registry_for_stage_test(),
    )
    with pytest.raises(FileExistsError):
        stage_runner.run_calibrations(root)
    started = preparation.read_json(root / "calibration_started.json")
    failed = preparation.read_json(root / "calibration_failed.json")
    assert started["status"] == "started"
    assert failed["failure_stage"] == "stage_initialization"
    assert failed["started_experiments"] == []
    assert failed["unstarted"] == [spec["exp_id"] for spec in missing_calibration_specs()]
    assert marker.read_text(encoding="utf-8") == "unchanged"
    with pytest.raises(FileExistsError, match="already has"):
        stage_runner.run_calibrations(root)


def test_start_receipt_creation_failure_is_captured_without_overwrite(
        tmp_path, monkeypatch):
    root = tmp_path / "prepared"
    root.mkdir()
    (root / "events.jsonl").touch()
    monkeypatch.setattr(
        stage_runner, "_verify_prepared_root",
        lambda supplied: _prepared_registry_for_stage_test(),
    )
    original_write = stage_runner.write_json_new
    failed_once = {"value": False}

    def fail_first_start(path, value):
        if Path(path).name == "calibration_started.json" and not failed_once["value"]:
            failed_once["value"] = True
            raise OSError("simulated start receipt failure")
        return original_write(path, value)

    monkeypatch.setattr(stage_runner, "write_json_new", fail_first_start)
    with pytest.raises(OSError, match="start receipt"):
        stage_runner.run_calibrations(root)
    assert (root / "calibration_started.json").is_file()
    failure = preparation.read_json(root / "calibration_failed.json")
    assert failure["failure_stage"] == "stage_initialization"
    assert failure["start_receipt_written_initially"] is False
    assert failure["started_experiments"] == []


def test_success_receipt_is_last_and_finalization_failure_is_preserved(
        tmp_path, monkeypatch):
    root = tmp_path / "prepared"
    root.mkdir()
    (root / "events.jsonl").touch()
    monkeypatch.setattr(
        stage_runner, "_verify_prepared_root",
        lambda supplied: _prepared_registry_for_stage_test(),
    )

    def successful_child(command, **kwargs):
        destination = Path(command[command.index("--destination") + 1])
        destination.mkdir(parents=True)
        preparation.write_json_new(destination / "process.json", {"exit_code": 0})
        preparation.write_json_new(destination / "receipt.json", {
            "status": "complete", "passed": True,
        })
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(stage_runner.subprocess, "run", successful_child)
    original_event = stage_runner._append_root_event

    def fail_completion_event(event_root, event, **fields):
        if event == "calibration_stage_completed":
            raise OSError("completion event stopped")
        return original_event(event_root, event, **fields)

    monkeypatch.setattr(stage_runner, "_append_root_event", fail_completion_event)
    with pytest.raises(OSError, match="completion event"):
        stage_runner.run_calibrations(root)
    failure = preparation.read_json(root / "calibration_failed.json")
    assert failure["failure_stage"] == "stage_finalization"
    assert len(failure["completed"]) == 6
    assert failure["unstarted"] == []
    assert not (root / "calibration_receipt.json").exists()


def test_parent_does_not_count_a_failed_child_as_completed(
        tmp_path, monkeypatch):
    root = tmp_path / "prepared"
    root.mkdir()
    (root / "events.jsonl").touch()
    monkeypatch.setattr(
        stage_runner, "_verify_prepared_root",
        lambda supplied: _prepared_registry_for_stage_test(),
    )

    def failed_child(command, **kwargs):
        destination = Path(command[command.index("--destination") + 1])
        destination.mkdir(parents=True)
        preparation.write_json_new(destination / "process.json", {"exit_code": 1})
        preparation.write_json_new(destination / "receipt.json", {
            "status": "failed", "passed": False,
        })
        return SimpleNamespace(returncode=1)

    monkeypatch.setattr(stage_runner.subprocess, "run", failed_child)
    with pytest.raises(RuntimeError, match="process failed"):
        stage_runner.run_calibrations(root)
    failure = preparation.read_json(root / "calibration_failed.json")
    expected_ids = [spec["exp_id"] for spec in missing_calibration_specs()]
    assert failure["failed_experiment"] == expected_ids[0]
    assert failure["completed"] == []
    assert failure["unstarted"] == expected_ids[1:]


@pytest.fixture(scope="module")
def existing_selection_records():
    from regge_record_length_study.selection import reconstruct_existing_selections

    return reconstruct_existing_selections()


def test_existing_three_and_twenty_four_month_rank_one_identities(
        existing_selection_records):
    selected = existing_selection_records
    identities = (
        "RL-E1-M03", "RL-E1-M24", "RL-E2-M03",
        "RL-E2-M24", "RL-E3-M03", "RL-E3-M24",
    )
    assert [(selected[key]["parameter_id"], selected[key]["noise_id"])
            for key in identities] == [
        (67, 84), (1944, 19), (1072, 97),
        (1944, 70), (1926, 84), (712, 7),
    ]
    for key in identities:
        record = selected[key]
        assert record["array_contract_reproduced"] is True
        assert record["hydrologic_shortlist_reproduced"] is True
        assert record["four_lead_rank_reproduced"] is True
        assert record["selection_leads"] == [48, 120]
        assert len(record["top_16_parameter_ids"]) == 16
        assert len(record["complete_rank_order_sha256"]) == 64


def test_selection_is_isolated_from_every_post_cutoff_flow_copy(
        existing_selection_records, full_inputs, monkeypatch):
    from regge_record_length_study import selection
    import regge_record_length_study.contract as study_contract

    dates, forcing, flow, checks = full_inputs
    sources = selection._existing_sources(selection._archive_manifest())
    for spec in window_specs():
        if spec["months"] not in (3, 24):
            continue
        changed = flow.copy()
        cutoff = np.datetime64(spec["stop"], "h")
        changed[dates >= cutoff] += 12345.0
        assert np.array_equal(changed[dates < cutoff], flow[dates < cutoff])
        assert np.any(changed[dates >= cutoff] != flow[dates >= cutoff])
        monkeypatch.setattr(
            study_contract, "load_inputs",
            lambda changed=changed: (dates, forcing, changed, checks),
        )
        replayed = selection._reconstruct_source(sources[spec["exp_id"]])
        expected = existing_selection_records[spec["exp_id"]]
        assert (replayed["parameter_id"], replayed["noise_id"]) == (
            expected["parameter_id"], expected["noise_id"],
        )
        assert np.float64(replayed["score"]).tobytes() == np.float64(
            expected["score"]
        ).tobytes()


def test_selection_rejects_any_non_calibration_array_key():
    from regge_record_length_study import selection

    selection._validate_allowed_keys(selection.ALLOWED_CALIBRATION_ARRAYS)
    with pytest.raises(ValueError, match="forbidden selection inputs"):
        selection._validate_allowed_keys(
            selection.ALLOWED_CALIBRATION_ARRAYS | {"assessment_predictions"}
        )
    with pytest.raises(ValueError, match="incomplete calibration arrays"):
        selection._validate_allowed_keys(
            selection.ALLOWED_CALIBRATION_ARRAYS - {"joint_predictions"}
        )


def test_two_lead_ranking_does_not_accept_common_warmup_mask():
    from regge_record_length_study import selection

    parameter_ids = np.repeat(np.asarray([10, 20, 30, 40, 50], dtype=np.int64), 2)
    noise_ids = np.tile(np.asarray([0, 1], dtype=np.int64), 5)
    errors = np.asarray([
        [9.0, 9.0, 1.0, 1.0],
        [0.1, 0.1, 2.0, 2.0],
        [9.0, 9.0, 1.5, 1.5],
        [0.1, 0.1, 3.0, 3.0],
        [9.0, 9.0, 4.0, 4.0], [0.1, 0.1, 5.0, 5.0],
        [9.0, 9.0, 6.0, 6.0], [0.1, 0.1, 7.0, 7.0],
        [9.0, 9.0, 8.0, 8.0], [0.1, 0.1, 9.0, 9.0],
    ], dtype=np.float64)
    reference = np.ones(4, dtype=np.float64)
    valid = np.ones(10, dtype=np.bool_)
    ranked = selection._rank_two_lead(
        parameter_ids, noise_ids, errors, reference, valid,
    )
    assert ranked["best_row"] == 0
    assert ranked["parameter_best_rows"].tolist() == [0, 2, 4, 6, 8]
    assert "mask" not in ranked


def test_missing_new_calibration_fails_without_fallback(
        tmp_path, monkeypatch):
    from regge_record_length_study import selection

    root = tmp_path / "prepared"
    root.mkdir()
    (root / "events.jsonl").touch()
    monkeypatch.setattr(
        selection, "_verify_prepared_root",
        lambda supplied: {"windows": list(window_specs())},
    )
    with pytest.raises(FileNotFoundError, match="calibration stage receipt"):
        selection.select_all(root)
    failure = preparation.read_json(root / "selection_failed.json")
    assert failure["passed"] is False
    assert failure["frozen_identity_count"] == 0
    assert not (root / "selections.json").exists()
    assert not (root / "selection_receipt.json").exists()


def test_select_all_freezes_exactly_twelve_before_success(
        tmp_path, monkeypatch):
    from regge_record_length_study import selection

    root = tmp_path / "prepared"
    root.mkdir()
    (root / "events.jsonl").touch()
    preparation.write_json_new(root / "preparation_receipt.json", {"passed": True})
    preparation.write_json_new(root / "calibration_receipt.json", {"passed": True})
    monkeypatch.setattr(
        selection, "_verify_prepared_root",
        lambda supplied: {"windows": list(window_specs())},
    )
    frozen = {
        spec["exp_id"]: {
            "experiment_id": spec["exp_id"],
            "selected_identity_eligible": True,
            "source_hashes": {
                "raw_npz": "0" * 64,
                "result_json": "1" * 64,
                "receipt_json": None,
                "process_json": None,
                "raw_arrays": {},
            },
        }
        for spec in window_specs()
    }
    monkeypatch.setattr(selection, "_build_all_records", lambda supplied: frozen)
    assert selection.select_all(root) == root
    saved = preparation.read_json(root / "selections.json")
    receipt = preparation.read_json(root / "selection_receipt.json")
    manifest = preparation.read_json(root / "selection_manifest.json")
    assert list(saved) == [spec["exp_id"] for spec in window_specs()]
    assert len(saved) == receipt["selection_count"] == manifest["selection_count"] == 12
    assert receipt["passed"] is True
    assert not (root / "selection_failed.json").exists()
    with pytest.raises(FileExistsError, match="cannot overwrite"):
        selection.select_all(root)


def test_ineligible_rank_one_is_frozen_then_fails_without_promotion(
        tmp_path, monkeypatch):
    from regge_record_length_study import selection

    root = tmp_path / "prepared"
    root.mkdir()
    (root / "events.jsonl").touch()
    preparation.write_json_new(root / "preparation_receipt.json", {"passed": True})
    preparation.write_json_new(root / "calibration_receipt.json", {"passed": True})
    monkeypatch.setattr(
        selection, "_verify_prepared_root",
        lambda supplied: {"windows": list(window_specs())},
    )
    frozen = {
        spec["exp_id"]: {
            "experiment_id": spec["exp_id"],
            "parameter_id": index,
            "selected_identity_eligible": index != 5,
            "source_hashes": {
                "raw_npz": "0" * 64, "result_json": "1" * 64,
                "receipt_json": None, "process_json": None, "raw_arrays": {},
            },
        }
        for index, spec in enumerate(window_specs())
    }
    monkeypatch.setattr(selection, "_build_all_records", lambda supplied: frozen)
    with pytest.raises(RuntimeError, match="finite common warmup"):
        selection.select_all(root)
    saved = preparation.read_json(root / "selections.json")
    failure = preparation.read_json(root / "selection_failed.json")
    assert len(saved) == 12
    assert saved["RL-E2-M06"]["parameter_id"] == 5
    assert failure["frozen_identity_count"] == 12
    assert failure["fallback_used"] is False
    assert not (root / "selection_receipt.json").exists()


def test_command_line_select_is_registered_and_dispatches_without_computation(
        monkeypatch):
    import run_regge_record_length_study as command_line

    dispatched = []
    monkeypatch.setattr(
        command_line, "run_stage", lambda stage: dispatched.append(stage),
    )
    assert command_line.main(["select"]) == 0
    assert dispatched == ["select"]


def _e1_spec(months: int) -> dict:
    return next(
        dict(spec) for spec in window_specs()
        if spec["endpoint"] == "E1" and spec["months"] == months
    )


def test_four_lengths_share_the_frozen_three_month_state_preparation_history(
        full_inputs):
    from regge_record_length_study import assessment

    dates, _, _, _ = full_inputs
    contracts = [
        assessment.assessment_contract(_e1_spec(months), dates)
        for months in (3, 6, 12, 24)
    ]
    assert {row["assimilation_start"] for row in contracts} == {"2001-10-01T00"}
    assert {row["evaluation_start"] for row in contracts} == {"2002-01-01T00"}
    assert {row["pre_evaluation_assimilation_hours"] for row in contracts} == {2208}
    assert {row["initial_covariance_hash"] for row in contracts} == {
        FIXED_INITIAL_COVARIANCE_SHA256
    }
    assert {row["state_reset_count"] for row in contracts} == {0}


def test_one_chain_origin_contract_contains_recent_and_all_six_years(
        full_inputs):
    from regge_record_length_study import assessment

    dates, _, _, _ = full_inputs
    origins, period_codes, labels = assessment.assessment_origins_for_endpoint(
        "E1", dates,
    )
    assert len(origins) == 360 + 2161
    assert labels == {
        0: "immediate", 1: "2005", 2: "2006", 3: "2007",
        4: "2008", 5: "2009", 6: "2010",
    }
    assert {labels[int(code)] for code in np.unique(period_codes)} == {
        "immediate", "2005", "2006", "2007", "2008", "2009", "2010",
    }
    assert np.all(np.diff(origins) > 0)


def test_assessment_result_is_immutable_at_its_public_boundary():
    from regge_record_length_study.assessment import AssessmentResult

    result = AssessmentResult(
        meta={"valid": True, "nested": {"value": 1}, "items": [1]},
        arrays={"state": np.asarray([1.0], dtype=np.float64)},
    )
    with pytest.raises(TypeError, match="immutable"):
        result.meta["valid"] = False
    with pytest.raises(TypeError, match="immutable"):
        result.arrays["other"] = np.asarray([2.0])
    with pytest.raises(TypeError, match="immutable"):
        result.meta["nested"]["value"] = 2
    with pytest.raises(TypeError, match="immutable"):
        result.meta["items"].append(2)
    with pytest.raises(ValueError, match="read-only"):
        result.arrays["state"][0] = 2.0


def test_assessment_array_contract_keeps_every_forecast_state():
    from regge_record_length_study import assessment

    dates = np.arange(
        np.datetime64("2000-01-01T00", "h"),
        np.datetime64("2000-01-07T00", "h"),
        np.timedelta64(1, "h"),
    )
    forcing = np.zeros((len(dates), 2), dtype=np.float64)
    observations = np.zeros(len(dates), dtype=np.float64)
    arrays = assessment._empty_arrays(
        dates=dates, forcing=forcing, observations=observations,
        start=0, stop=2, origins=np.asarray([1], dtype=np.int64),
        period_codes=np.asarray([0], dtype=np.int8),
        parameter_id=67, noise_id=84,
    )
    assert arrays["forecast_states"].shape == (1, 120, 5)
    assert arrays["predictions"].shape == (1, 120)


def test_assessment_checkpoint_binds_experiment_and_source_identity(tmp_path):
    import torch
    from regge_record_length_study import assessment

    writer = assessment._ArtifactWriter(tmp_path)
    writer.bind_identity({
        "experiment_id": "RL-E1-M03",
        "assessment_id": "RL-E1-M03-MATCHED3",
        "parameter_id": 67,
        "noise_id": 84,
        "source_hashes": {"raw_data": "a" * 64},
    })
    state = SimpleNamespace(
        states=torch.zeros((1, 1, 5), dtype=torch.float64),
        covariances=torch.eye(5, dtype=torch.float64).reshape(1, 1, 5, 5),
        probabilities=torch.ones((1, 1), dtype=torch.float64),
    )
    writer.checkpoint("periodic", 10, state, np.zeros(5), 2)
    metadata_path = next((tmp_path / "checkpoints").glob("*.json"))
    saved = preparation.read_json(metadata_path)
    assert saved["experiment_id"] == "RL-E1-M03"
    assert saved["assessment_id"] == "RL-E1-M03-MATCHED3"
    assert saved["parameter_id"] == 67 and saved["noise_id"] == 84
    assert saved["source_hashes"] == {"raw_data": "a" * 64}
    assert saved["last_valid_hour"] == 10 and saved["next_hour"] == 11
    assert saved["completed_origins"] == 2


def test_common_warmup_state_is_read_by_full_parameter_identity(
        existing_selection_records):
    from regge_record_length_study.assessment import load_common_warmup_state

    selected = existing_selection_records["RL-E1-M03"]
    state = load_common_warmup_state("E1", 67)
    np.testing.assert_array_equal(state, selected["common_warmup_state"])
    assert state.dtype == np.float64 and state.shape == (5,)
    assert state.flags.writeable is False
    with pytest.raises((ValueError, IndexError), match="parameter|identity"):
        load_common_warmup_state("E1", 2048)


def test_shifted_common_start_and_other_parameter_warmup_are_rejected(
        tmp_path, existing_selection_records, full_inputs):
    from regge_record_length_study import assessment

    dates, _, _, _ = full_inputs
    spec = _e1_spec(3)
    shifted = dict(spec, common_start="2001-10-01T01")
    with pytest.raises(ValueError, match="common|preparation|start"):
        assessment.assessment_contract(shifted, dates)

    selection = dict(existing_selection_records["RL-E1-M03"])
    selection["common_warmup_state"] = assessment.load_common_warmup_state(
        "E1", 1944,
    ).tolist()
    with pytest.raises(ValueError, match="warmup|state|identity"):
        assessment.validate_selected_identity(spec, selection)

    dates, forcing, flow, _ = full_inputs
    start = int(np.flatnonzero(dates == np.datetime64("2001-10-01T00", "h"))[0])
    selected = existing_selection_records["RL-E1-M03"]
    wrong_warmup = assessment.load_common_warmup_state("E1", 1944)
    for supplied_start, supplied_warmup, name in (
            (start + 1, assessment.load_common_warmup_state("E1", 67), "shifted"),
            (start, wrong_warmup, "wrong-warmup")):
        with pytest.raises(ValueError, match="frozen|budget|prefix"):
            assessment.run_continuous_prefix(
                spec=spec, selection=selected, dates=dates, forcing=forcing,
                observations=flow, start=supplied_start,
                stop=supplied_start + 240,
                origins=np.asarray(
                    [supplied_start + 120, supplied_start + 144], dtype=np.int64,
                ),
                warmup_state=supplied_warmup,
                destination=tmp_path / name,
            )
        assert not (tmp_path / name).exists()


def _run_stub_assessment_finalization_failure(
        *, tmp_path, monkeypatch, full_inputs, failure_kind):
    import torch
    from regge_record_length_study import assessment

    dates, forcing, flow, _ = full_inputs
    spec = _e1_spec(3)
    frozen = assessment.assessment_contract(spec, dates)
    start, stop = frozen["start"], frozen["start"] + 2
    origins = np.asarray([start], dtype=np.int64)
    contract = {**frozen, "start": start, "stop": stop}

    class StubState:
        def __init__(self, states, covariances, probabilities):
            self.states = states
            self.covariances = covariances
            self.probabilities = probabilities

    class StubAdapter:
        def __init__(self, *args, **kwargs):
            pass

    def stub_filter_step(adapter, state, forcing_value, observation_value,
                         matrix, alive):
        next_state = StubState(
            state.states + 0.01,
            state.covariances + torch.eye(5, dtype=torch.float64).reshape(
                1, 1, 5, 5,
            ) * 1e-6,
            state.probabilities.clone(),
        )
        return {
            "state": next_state,
            "alive": np.asarray([True], dtype=np.bool_),
            "failures": [],
            "global_states": next_state.states[:, 0],
            "global_covariances": next_state.covariances[:, 0],
        }

    def stub_walrus_step(state, forcing_value, parameters):
        return state + 0.001

    identity = {
        "parameter_id": 67,
        "noise_id": 84,
        "parameters": {"fixed": 1.0},
        "noise_diagonal": np.zeros(5, dtype=np.float64),
        "warmup_state": np.ones(5, dtype=np.float64),
        "common_warmup_raw_sha256": "a" * 64,
        "common_warmup_states_sha256": "b" * 64,
        "selection_source_hashes": {
            "raw_npz": "c" * 64, "result_json": "d" * 64,
        },
    }
    core = {
        "BatchedNoiseFilters": StubAdapter,
        "FilterState": StubState,
        "short_record": SimpleNamespace(isolated_filter_step=stub_filter_step),
        "walrus_step": stub_walrus_step,
    }
    monkeypatch.setattr(assessment, "assessment_contract", lambda *args: contract)
    monkeypatch.setattr(
        assessment, "assessment_origins_for_endpoint",
        lambda *args: (
            origins,
            np.asarray([0], dtype=np.int8),
            {
                0: "immediate", 1: "2005", 2: "2006", 3: "2007",
                4: "2008", 5: "2009", 6: "2010",
            },
        ),
    )
    monkeypatch.setattr(assessment, "validate_selected_identity", lambda *args: identity)
    monkeypatch.setattr(assessment, "_load_assessment_core", lambda: core)
    monkeypatch.setattr(assessment, "_validate_core_selected_identity", lambda *args: None)
    monkeypatch.setattr(assessment, "_replay_common_warmup", lambda **kwargs: {
        "replayed_state": identity["warmup_state"].copy(),
        "max_absolute_difference": 0.0,
        "absolute_tolerance": 1e-8,
        "relative_tolerance": 0.0,
        "replay_hours": start,
        "interpretation": "stub provenance replay",
        "independent_implementation": False,
    })
    if failure_kind == "prediction_block":
        monkeypatch.setattr(
            assessment._ArtifactWriter, "prediction_block",
            lambda *args, **kwargs: (_ for _ in ()).throw(
                OSError("final prediction block failed"),
            ),
        )
        expected_error = "final prediction block failed"
    else:
        original_checkpoint = assessment._ArtifactWriter.checkpoint

        def fail_final_checkpoint(self, kind, *args, **kwargs):
            if kind == "final":
                raise OSError("final checkpoint failed")
            return original_checkpoint(self, kind, *args, **kwargs)

        monkeypatch.setattr(
            assessment._ArtifactWriter, "checkpoint", fail_final_checkpoint,
        )
        expected_error = "final checkpoint failed"

    destination = tmp_path / failure_kind
    with pytest.raises(OSError, match=expected_error):
        assessment.assess_one(
            spec, {}, origins, destination,
            _inputs=(dates, forcing, flow, {"raw_data_sha256": "e" * 64}),
        )
    return destination, start, stop


def test_final_prediction_block_failure_preserves_exact_partial_progress(
        tmp_path, monkeypatch, full_inputs):
    destination, start, stop = _run_stub_assessment_finalization_failure(
        tmp_path=tmp_path, monkeypatch=monkeypatch, full_inputs=full_inputs,
        failure_kind="prediction_block",
    )
    failure = preparation.read_json(destination / "failure.json")
    partial = preparation.read_json(destination / "partial_metadata.json")
    assert failure["last_valid_hour"] == stop - 1
    assert failure["completed_origins"] == 1
    assert partial["last_valid_hour"] == stop - 1
    assert partial["completed_origins"] == 1
    assert partial["processed_hour_count"] == stop - start
    assert not (destination / "receipt.json").exists()


def test_final_checkpoint_failure_preserves_exact_partial_progress(
        tmp_path, monkeypatch, full_inputs):
    destination, start, stop = _run_stub_assessment_finalization_failure(
        tmp_path=tmp_path, monkeypatch=monkeypatch, full_inputs=full_inputs,
        failure_kind="checkpoint",
    )
    failure = preparation.read_json(destination / "failure.json")
    partial = preparation.read_json(destination / "partial_metadata.json")
    assert failure["last_valid_hour"] == stop - 1
    assert failure["completed_origins"] == 1
    assert partial["last_valid_hour"] == stop - 1
    assert partial["completed_origins"] == 1
    assert partial["processed_hour_count"] == stop - start
    assert not (destination / "receipt.json").exists()


def test_prefix_controls_share_one_filter_loop_and_two_forecast_calls_with_stub(
        tmp_path, full_inputs):
    import torch
    from regge_record_length_study import assessment

    class StubState:
        def __init__(self, states, covariances, probabilities):
            self.states = states
            self.covariances = covariances
            self.probabilities = probabilities

    class StubAdapter:
        def __init__(self, *args, **kwargs):
            pass

    calls = {"filter": 0, "forecast": 0}

    def stub_filter_step(adapter, state, forcing_value, observation_value,
                         matrix, alive):
        calls["filter"] += 1
        next_state = StubState(
            state.states + 0.01,
            state.covariances + torch.eye(5, dtype=torch.float64).reshape(
                1, 1, 5, 5,
            ) * 1e-6,
            state.probabilities.clone(),
        )
        return {
            "state": next_state,
            "alive": np.ones(len(alive), dtype=np.bool_),
            "failures": [],
            "global_states": next_state.states[:, 0],
            "global_covariances": next_state.covariances[:, 0],
        }

    def stub_walrus_step(state, forcing_value, parameters):
        calls["forecast"] += 1
        return state + 0.001

    dates, forcing, flow, _ = full_inputs
    spec = _e1_spec(3)
    start = assessment.assessment_contract(spec, dates)["start"]
    stop = start + 3
    origins = np.asarray([start, start + 1], dtype=np.int64)
    identity = {
        "parameter_id": 67, "noise_id": 84,
        "parameters": {"fixed": 1.0},
        "noise_diagonal": np.zeros(5, dtype=np.float64),
    }
    destination = tmp_path / "stub-prefix-controls"
    destination.mkdir()
    writer = assessment._ArtifactWriter(destination)
    writer.bind_identity({
        "experiment_id": "RL-E1-M03",
        "assessment_id": "RL-E1-M03-MATCHED3",
        "parameter_id": 67,
        "noise_id": 84,
        "source_hashes": {"stub": "a" * 64},
    })
    result = assessment._run_continuous_chain(
        spec=spec, identity=identity, dates=dates, forcing=forcing,
        observations=flow, start=start, stop=stop, origins=origins,
        period_codes=np.asarray([-1, -1], dtype=np.int8),
        warmup_state=np.ones(5, dtype=np.float64), writer=writer,
        core={
            "BatchedNoiseFilters": StubAdapter,
            "FilterState": StubState,
            "short_record": SimpleNamespace(isolated_filter_step=stub_filter_step),
            "walrus_step": stub_walrus_step,
        },
        prefix_controls=True,
    )
    assert calls == {"filter": 3, "forecast": 240}
    assert result.meta["parallel_reproduction_verified"] is True
    assert result.meta["second_origin_noninterference_verified"] is True
    assert result.meta["post_origin_flow_control_verified"] is True
    np.testing.assert_array_equal(
        result.arrays["posterior_states"],
        result.arrays["parallel_reproduction_states"],
    )
    np.testing.assert_array_equal(
        result.arrays["posterior_covariances"],
        result.arrays["parallel_reproduction_covariances"],
    )


def _build_fake_historical_authority(tmp_path, monkeypatch, assessment):
    repaired = tmp_path / "repaired"
    historical = tmp_path / "historical"
    repaired.mkdir()
    identities = {
        "E1": ("year_end_origin_one", 67, 84),
        "E2": ("midyear_origin", 1072, 97),
        "E3": ("year_end_origin_two", 1926, 84),
    }
    records = []
    paths = {}
    for endpoint, (window, parameter_id, noise_id) in identities.items():
        base = historical / "methods" / window
        base.mkdir(parents=True)
        arrays_path = base / "updated__01__independent_single_model_rank_1__complete.npz"
        metadata_path = arrays_path.with_suffix(".json")
        np.savez(arrays_path, marker=np.asarray([parameter_id, noise_id]))
        metadata = {
            "valid": True,
            "window": window,
            "method_kind": "updated",
            "rank": 1,
            "member_parameter_ids": [parameter_id],
            "member_noise_ids": [noise_id],
            "forecast_form": "fixed_posterior_probability_single_global_state",
            "arm": {"name": "independent_single_model_rank_1"},
        }
        metadata_path.write_text(
            json.dumps(metadata, indent=2) + "\n", encoding="utf-8",
        )
        records.append({
            "valid": True,
            "window": window,
            "kind": "updated",
            "rank": 1,
            "method": "independent_single_model_rank_1",
            "repaired": False,
            "source_arrays": str(arrays_path),
            "source_arrays_sha256": preparation.sha256(arrays_path),
            "metadata": str(metadata_path),
            "metadata_sha256": preparation.sha256(metadata_path),
        })
        paths[endpoint] = (arrays_path, metadata_path)

    audit_path = repaired / "audit.json"
    manifest_path = repaired / "manifest.json"

    def reseal():
        audit_path.write_text(
            json.dumps({"passed": True, "methods": records}, indent=2) + "\n",
            encoding="utf-8",
        )
        manifest_path.write_text(
            json.dumps({
                "files": {"audit.json": preparation.sha256(audit_path)},
                "excluded": ["manifest.json"],
            }, indent=2) + "\n",
            encoding="utf-8",
        )
        monkeypatch.setattr(assessment, "REPAIRED", repaired)
        monkeypatch.setattr(assessment, "HISTORICAL_ROOT", historical)
        monkeypatch.setattr(
            assessment, "REPAIRED_AUDIT_SHA256", preparation.sha256(audit_path),
        )
        monkeypatch.setattr(
            assessment, "REPAIRED_MANIFEST_SHA256",
            preparation.sha256(manifest_path),
        )

    reseal()
    return records, paths, reseal


def test_historical_authority_locks_actual_paths_hashes_and_identities():
    from regge_record_length_study import assessment

    locked = assessment._locked_historical_single_model_sources()
    assert {
        endpoint: (row["parameter_id"], row["noise_id"])
        for endpoint, row in locked.items()
    } == {"E1": (67, 84), "E2": (1072, 97), "E3": (1926, 84)}
    for row in locked.values():
        assert preparation.sha256(row["arrays_path"]) == row["arrays_sha256"]
        assert preparation.sha256(row["metadata_path"]) == row["metadata_sha256"]


@pytest.mark.parametrize("tamper", ["metadata", "arrays", "identity"])
def test_historical_authority_rejects_metadata_arrays_and_identity_tampering(
        tmp_path, monkeypatch, tamper):
    from regge_record_length_study import assessment

    records, paths, reseal = _build_fake_historical_authority(
        tmp_path, monkeypatch, assessment,
    )
    arrays_path, metadata_path = paths["E1"]
    if tamper == "metadata":
        metadata = preparation.read_json(metadata_path)
        metadata["tampered"] = True
        metadata_path.write_text(json.dumps(metadata) + "\n", encoding="utf-8")
    elif tamper == "arrays":
        np.savez(arrays_path, marker=np.asarray([-1, -1]))
    else:
        metadata = preparation.read_json(metadata_path)
        metadata["member_parameter_ids"] = [67, 68]
        metadata_path.write_text(json.dumps(metadata) + "\n", encoding="utf-8")
        record = next(row for row in records if row["window"] == "year_end_origin_one")
        record["metadata_sha256"] = preparation.sha256(metadata_path)
        reseal()
    with pytest.raises(RuntimeError, match="historical|identity|metadata|array|hash"):
        assessment._locked_historical_single_model_sources()


def test_historical_reproduction_rejects_new_identity_before_array_comparison(
        tmp_path, monkeypatch):
    from regge_record_length_study import assessment

    monkeypatch.setattr(
        assessment, "_locked_historical_single_model_sources",
        lambda: {
            "E1": {"parameter_id": 67, "noise_id": 84},
            "E2": {"parameter_id": 1072, "noise_id": 97},
            "E3": {"parameter_id": 1926, "noise_id": 84},
        },
    )
    destination = (
        tmp_path / "assessment" / "RL-E1-M03-MATCHED3"
    )
    destination.mkdir(parents=True)
    preparation.write_json_new(destination / "metadata.json", {
        "parameter_id": 68,
        "noise_id": 84,
        "start": 0,
    })
    with pytest.raises(RuntimeError, match="identity"):
        assessment.verify_three_month_historical_reproduction(tmp_path)


@pytest.fixture(scope="module")
def real_e1_assessment_prefix(
        tmp_path_factory, existing_selection_records, full_inputs):
    """The suite's only real Task-4 compute: 240 filter + 240 forecast steps."""
    from regge_record_length_study import assessment

    dates, forcing, flow, _ = full_inputs
    spec = _e1_spec(3)
    selection = existing_selection_records["RL-E1-M03"]
    start = int(np.flatnonzero(dates == np.datetime64("2001-10-01T00", "h"))[0])
    stop = start + 240
    origins = np.asarray([start + 120, start + 144], dtype=np.int64)
    warmup = assessment.load_common_warmup_state("E1", 67)
    destination = tmp_path_factory.mktemp("record_length_real_prefix")
    result = assessment.run_continuous_prefix(
        spec=spec,
        selection=selection,
        dates=dates,
        forcing=forcing,
        observations=flow,
        start=start,
        stop=stop,
        origins=origins,
        warmup_state=warmup,
        destination=destination,
    )
    return result, destination, start, stop, origins


def test_real_e1_prefix_controls_flow_origin_noninterference_and_reproducibility(
        real_e1_assessment_prefix):
    import inspect
    from regge_record_length_study import assessment

    result, destination, start, stop, origins = real_e1_assessment_prefix
    assert result.meta["experiment_id"] == "RL-E1-M03"
    assert result.meta["parameter_id"] == 67
    assert result.meta["noise_id"] == 84
    assert result.meta["start"] == start and result.meta["stop"] == stop
    assert result.meta["processed_hour_count"] == 240
    assert result.meta["deterministic_forecast_steps"] == 240
    assert result.meta["completed_origins"] == 2
    assert result.meta["state_reset_count"] == 0
    assert result.meta["last_valid_hour"] == stop - 1
    assert result.meta["forecast_observation_input_count"] == 0
    assert result.meta["forecast_covariance_propagation_count"] == 0
    assert result.meta["forecast_sigma_point_propagation_count"] == 0
    assert result.meta["forecast_state_noninterference_checks"] == 2
    assert result.meta["parallel_reproduction_filter_hours"] == 240
    assert result.meta["parallel_reproduction_absolute_tolerance"] == 1e-8
    assert result.meta["parallel_reproduction_relative_tolerance"] == 0.0
    assert result.meta["parallel_reproduction_max_state_difference"] <= 1e-8
    assert result.meta["parallel_reproduction_max_covariance_difference"] <= 1e-8
    assert result.meta["second_origin_noninterference_verified"] is True
    assert result.meta["post_origin_flow_control_verified"] is True
    np.testing.assert_array_equal(result.arrays["origins"], origins)
    assert result.arrays["posterior_states"].shape == (240, 5)
    assert result.arrays["posterior_covariances"].shape == (240, 5, 5)
    assert result.arrays["parallel_reproduction_states"].shape == (240, 5)
    assert result.arrays["parallel_reproduction_covariances"].shape == (240, 5, 5)
    assert result.arrays["forecast_states"].shape == (2, 120, 5)
    assert result.arrays["predictions"].shape == (2, 120)
    assert np.isfinite(result.arrays["posterior_states"]).all()
    assert np.isfinite(result.arrays["posterior_covariances"]).all()
    assert np.isfinite(result.arrays["forecast_states"]).all()
    assert np.isfinite(result.arrays["predictions"]).all()
    np.testing.assert_array_equal(
        result.arrays["predictions"], result.arrays["forecast_states"][:, :, 4],
    )
    np.testing.assert_allclose(
        result.arrays["posterior_states"],
        result.arrays["parallel_reproduction_states"], atol=1e-8, rtol=0,
    )
    np.testing.assert_allclose(
        result.arrays["posterior_covariances"],
        result.arrays["parallel_reproduction_covariances"], atol=1e-8, rtol=0,
    )
    second_origin_row = int(origins[1] - start)
    np.testing.assert_allclose(
        result.arrays["posterior_states"][second_origin_row:],
        result.arrays["parallel_reproduction_states"][second_origin_row:],
        atol=1e-8, rtol=0,
    )
    assert not np.array_equal(
        result.arrays["post_origin_flow_original"],
        result.arrays["post_origin_flow_changed"],
    )
    np.testing.assert_array_equal(
        result.arrays["post_origin_flow_control_predictions"],
        result.arrays["predictions"][0],
    )
    signature = inspect.signature(assessment.deterministic_state_forecast)
    assert "observations" not in signature.parameters
    assert "covariance" not in signature.parameters
    assert result.meta["forecast_input_fields"] == [
        "single_posterior_state", "future_forcing", "fixed_parameters",
    ]
    assert origins[-1] < stop - 1
    assert result.meta["last_valid_hour"] > int(origins[-1])
    assert result.meta["all_forecast_state_inputs_byte_unchanged"] is True
    final_path = destination / "arrays.npz"
    metadata_path = destination / "metadata.json"
    receipt_path = destination / "receipt.json"
    assert final_path.is_file() and metadata_path.is_file() and receipt_path.is_file()
    with np.load(final_path, allow_pickle=False) as saved:
        assert set(saved.files) == set(result.arrays)
        for name, expected in result.arrays.items():
            np.testing.assert_array_equal(saved[name], expected)
    metadata = preparation.read_json(metadata_path)
    receipt = preparation.read_json(receipt_path)
    assert metadata["last_valid_hour"] == stop - 1
    assert receipt["passed"] is True and receipt["status"] == "complete"
    checkpoints = sorted((destination / "checkpoints").glob("*.npz"))
    assert checkpoints
    with np.load(checkpoints[-1], allow_pickle=False) as saved:
        assert saved["member_states"].shape == (1, 1, 5)
        assert saved["member_covariances"].shape == (1, 1, 5, 5)
        assert saved["probabilities"].tolist() == [[1.0]]


def test_assessment_failure_preserves_receipt_and_never_publishes_success(
        tmp_path, monkeypatch, existing_selection_records, full_inputs):
    from regge_record_length_study import assessment

    destination = tmp_path / "failed-assessment"
    monkeypatch.setattr(
        assessment, "_replay_common_warmup",
        lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("replay stopped")),
    )
    dates, _, _, _ = full_inputs
    origins, _, _ = assessment.assessment_origins_for_endpoint("E1", dates)
    with pytest.raises(RuntimeError, match="replay stopped"):
        assessment.assess_one(
            _e1_spec(3), existing_selection_records["RL-E1-M03"], origins,
            destination,
        )
    assert (destination / "started.json").is_file()
    failure = preparation.read_json(destination / "failure.json")
    assert failure["passed"] is False and failure["status"] == "failed"
    assert not (destination / "receipt.json").exists()
    with pytest.raises(FileExistsError, match="exists|overwrite|attempt"):
        assessment.assess_one(
            _e1_spec(3), existing_selection_records["RL-E1-M03"], origins,
            destination,
        )


def test_assessment_stage_dispatches_twelve_frozen_identities_without_computation(
        tmp_path, monkeypatch):
    from regge_record_length_study import assessment

    root = tmp_path / "prepared"
    root.mkdir()
    (root / "events.jsonl").touch()
    selections = {
        spec["exp_id"]: {
            "experiment_id": spec["exp_id"], "endpoint": spec["endpoint"],
            "months": spec["months"], "parameter_id": 1, "noise_id": 2,
            "selected_identity_eligible": True,
        }
        for spec in window_specs()
    }
    preparation.write_json_new(root / "selections.json", selections)
    preparation.write_json_new(root / "selection_manifest.json", {
        "selections_sha256": preparation.sha256(root / "selections.json"),
    })
    preparation.write_json_new(root / "selection_receipt.json", {
        "status": "complete", "passed": True, "selection_count": 12,
        "files": {
            "selections.json": preparation.sha256(root / "selections.json"),
            "selection_manifest.json": preparation.sha256(root / "selection_manifest.json"),
        },
    })
    monkeypatch.setattr(
        assessment, "_verify_assessment_stage_inputs",
        lambda supplied: selections,
    )
    dates = np.arange(
        np.datetime64("1999-01-01T01", "h"),
        np.datetime64("2011-01-01T00", "h"),
        np.timedelta64(1, "h"),
    )
    forcing = np.zeros((len(dates), 2), dtype=np.float64)
    flow = np.zeros(len(dates), dtype=np.float64)
    monkeypatch.setattr(
        assessment, "load_inputs", lambda: (dates, forcing, flow, {}),
    )
    calls = []

    def fake_assess(spec, selection, origins, destination, **kwargs):
        destination.mkdir(parents=True)
        arrays = {"origins": np.asarray(origins, dtype=np.int64)}
        processed_hours = {
            "E1": 81096, "E2": 76728, "E3": 63576,
        }[spec["endpoint"]]
        meta = {
            "valid": True,
            "processed_hour_count": processed_hours,
            "completed_origins": len(origins),
            "deterministic_forecast_steps": len(origins) * 120,
        }
        preparation.save_npz_new(destination / "arrays.npz", **arrays)
        preparation.write_json_new(destination / "metadata.json", meta)
        preparation.write_json_new(destination / "receipt.json", {
            "status": "complete", "passed": True,
        })
        calls.append((spec["exp_id"], len(origins), destination.name))
        return assessment.AssessmentResult(
            meta=meta, arrays=arrays,
        )

    monkeypatch.setattr(assessment, "assess_one", fake_assess)
    monkeypatch.setattr(
        assessment, "verify_three_month_historical_reproduction",
        lambda supplied: {"passed": True, "verified_methods": 3},
    )
    assert assessment.assess_all(root) == root
    assert [row[0] for row in calls] == [spec["exp_id"] for spec in window_specs()]
    assert [row[2] for row in calls] == [
        f"{spec['exp_id']}-MATCHED3" for spec in window_specs()
    ]
    receipt = preparation.read_json(root / "assessment_receipt.json")
    assert receipt["passed"] is True
    assert receipt["assessment_count"] == 12
    assert receipt["processed_filter_hours"] == 885600
    assert receipt["completed_origins"] == 30256


def test_command_line_assess_is_registered_and_dispatches_without_computation(
        monkeypatch):
    import run_regge_record_length_study as command_line

    dispatched = []
    monkeypatch.setattr(
        command_line, "run_stage", lambda stage: dispatched.append(stage),
    )
    assert command_line.main(["assess"]) == 0
    assert dispatched == ["assess"]


def test_command_line_audit_is_registered_and_dispatches_without_computation(
        monkeypatch):
    import run_regge_record_length_study as command_line

    dispatched = []
    monkeypatch.setattr(
        command_line, "run_stage", lambda stage: dispatched.append(stage),
    )
    assert command_line.main(["audit"]) == 0
    assert dispatched == ["audit"]
