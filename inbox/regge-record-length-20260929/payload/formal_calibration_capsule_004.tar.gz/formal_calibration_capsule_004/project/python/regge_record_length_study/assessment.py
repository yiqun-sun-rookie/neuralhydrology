"""Matched three-month state preparation and continuous one-model assessment."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import importlib
import json
from pathlib import Path
import time
import traceback
from typing import Callable, Mapping

import numpy as np
import torch

from . import calibration
from . import prepare as preparation
from .common import (
    ARCHIVE,
    FORMAL_OUTPUT,
    PROJECT,
    REPAIRED,
    array_sha256,
    read_json,
    save_npz_new,
    sha256,
    write_json_new,
)
from .contract import (
    ARCHIVE_AUDIT_SHA256,
    ARCHIVE_MANIFEST_SHA256,
    FIXED_INITIAL_COVARIANCE_SHA256,
    RAW_DATA_SHA256,
    fixed_initial_covariance,
    index_at,
    load_inputs,
    origin_arrays,
    state_preparation_specs,
    validate_hour_axis,
    window_specs,
)


ASSESSMENT_ROOT = FORMAL_OUTPUT / "assessment"
CHAIN_STOP = "2011-01-01T00"
FORECAST_HOURS = 120
OBSERVATION_VARIANCE = 0.000015
REPLAY_ABSOLUTE_TOLERANCE = 1e-8
REPAIRED_MANIFEST_SHA256 = "ababef8cdb2e1d288b43bd15c64ba82c58879e09c551a51a21e23de1f00d8678"
REPAIRED_AUDIT_SHA256 = "93d4e4d6d87bebfafd9440952aee7b3736a2a862a572355afbae534a9c809d95"
HISTORICAL_ROOT = (
    PROJECT
    / "output/regge_multiyear_validation/20260928-regge-fixed-bank-six-year-001"
)

_COMMON_WARMUP_RAW = {
    "E1": "calibration/year_end_origin_one__3/raw.npz",
    "E2": "calibration/midyear_origin__3/raw.npz",
    "E3": "calibration/year_end_origin_two__3/raw.npz",
}
_HISTORICAL_WINDOWS = {
    "E1": "year_end_origin_one",
    "E2": "midyear_origin",
    "E3": "year_end_origin_two",
}
_PERIOD_LABELS = {
    0: "immediate", 1: "2005", 2: "2006", 3: "2007",
    4: "2008", 5: "2009", 6: "2010",
}


class _FrozenDict(dict):
    """A JSON-serializable mapping that rejects all top-level mutation."""

    def _immutable(self, *args, **kwargs):
        raise TypeError("assessment result mappings are immutable")

    __setitem__ = _immutable
    __delitem__ = _immutable
    clear = _immutable
    pop = _immutable
    popitem = _immutable
    setdefault = _immutable
    update = _immutable
    __ior__ = _immutable


class _FrozenList(list):
    """A JSON-serializable sequence that rejects in-place mutation."""

    def _immutable(self, *args, **kwargs):
        raise TypeError("assessment result mappings are immutable")

    __setitem__ = _immutable
    __delitem__ = _immutable
    append = _immutable
    clear = _immutable
    extend = _immutable
    insert = _immutable
    pop = _immutable
    remove = _immutable
    reverse = _immutable
    sort = _immutable
    __iadd__ = _immutable
    __imul__ = _immutable


def _freeze_metadata(value):
    if isinstance(value, Mapping):
        return _FrozenDict({key: _freeze_metadata(item) for key, item in value.items()})
    if isinstance(value, list):
        return _FrozenList(_freeze_metadata(item) for item in value)
    if isinstance(value, tuple):
        return tuple(_freeze_metadata(item) for item in value)
    return value


@dataclass(frozen=True)
class AssessmentResult:
    """A completed result whose array values cannot be edited in place."""

    meta: dict
    arrays: dict[str, np.ndarray]

    def __post_init__(self) -> None:
        copied = {}
        for name, values in self.arrays.items():
            array = np.array(values, copy=True)
            array.flags.writeable = False
            copied[name] = array
        object.__setattr__(self, "meta", _freeze_metadata(self.meta))
        object.__setattr__(self, "arrays", _FrozenDict(copied))


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _root_event(root: Path, event: str, **fields) -> None:
    row = {"utc": _utc(), "event": event, **fields}
    with (Path(root) / "events.jsonl").open("a", encoding="utf-8") as target:
        target.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")


def _archive_manifest() -> dict:
    manifest_path = ARCHIVE / "manifest.json"
    audit_path = ARCHIVE / "audit.json"
    if not manifest_path.is_file() or sha256(manifest_path) != ARCHIVE_MANIFEST_SHA256:
        raise RuntimeError("archived calibration manifest changed")
    if not audit_path.is_file() or sha256(audit_path) != ARCHIVE_AUDIT_SHA256:
        raise RuntimeError("archived calibration audit changed")
    if read_json(audit_path).get("passed") is not True:
        raise RuntimeError("archived calibration audit did not pass")
    return read_json(manifest_path)


def _common_warmup_record(endpoint: str) -> dict:
    if endpoint not in _COMMON_WARMUP_RAW:
        raise ValueError(f"unknown endpoint identity: {endpoint}")
    relative = _COMMON_WARMUP_RAW[endpoint]
    path = ARCHIVE / relative
    expected = _archive_manifest().get("files", {}).get(relative)
    if not isinstance(expected, str) or not path.is_file() or sha256(path) != expected:
        raise RuntimeError(f"common warmup source changed: {endpoint}")
    with np.load(path, allow_pickle=False) as saved:
        required = {
            "parameter_ids", "parameter_values", "warmup_states",
            "warmup_completed", "warmup_timestamps", "warmup_forcing",
        }
        if not required.issubset(saved.files):
            raise RuntimeError(f"common warmup source fields are incomplete: {endpoint}")
        values = {name: saved[name] for name in required}
    if (values["parameter_ids"].shape != (2048,)
            or not np.array_equal(values["parameter_ids"], np.arange(2048))
            or values["parameter_values"].shape != (2048, 5)
            or values["parameter_values"].dtype != np.float64
            or values["warmup_states"].shape != (2048, 5)
            or values["warmup_states"].dtype != np.float64
            or values["warmup_completed"].shape != (2048,)
            or values["warmup_completed"].dtype != np.bool_
            or not values["warmup_completed"].all()):
        raise RuntimeError(f"common warmup source structure differs: {endpoint}")
    return {
        **values,
        "path": path,
        "raw_sha256": expected,
        "warmup_states_sha256": array_sha256(values["warmup_states"]),
    }


def load_common_warmup_state(endpoint: str, parameter_id: int) -> np.ndarray:
    """Read one complete five-state warmup by its full 0--2047 identity."""
    if not isinstance(parameter_id, (int, np.integer)):
        raise ValueError("parameter identity must be an integer")
    parameter_id = int(parameter_id)
    if not 0 <= parameter_id < 2048:
        raise IndexError("parameter identity is outside 0--2047")
    record = _common_warmup_record(endpoint)
    state = np.array(record["warmup_states"][parameter_id], dtype=np.float64, copy=True)
    if not record["warmup_completed"][parameter_id] or not np.isfinite(state).all():
        raise ValueError(
            f"parameter identity {parameter_id} lacks a finite common warmup state"
        )
    state.flags.writeable = False
    return state


def _literal_spec(spec: Mapping) -> dict:
    if not isinstance(spec, Mapping):
        raise TypeError("assessment specification must be a mapping")
    exp_id = spec.get("exp_id")
    matches = [row for row in window_specs() if row["exp_id"] == exp_id]
    if len(matches) != 1:
        raise ValueError(f"unknown assessment experiment identity: {exp_id}")
    expected = matches[0]
    for field in (
        "endpoint", "months", "start", "stop", "hours",
        "selection_origins", "calibration_source",
    ):
        if spec.get(field) != expected[field]:
            raise ValueError(f"assessment specification differs at {field}")
    return dict(expected)


def assessment_contract(spec: Mapping, dates: np.ndarray) -> dict:
    """Resolve the fixed matched-history chronology without running a filter."""
    expected = _literal_spec(spec)
    hours = validate_hour_axis(np.asarray(dates))
    preparation_rows = {
        row["endpoint"]: row for row in state_preparation_specs()
    }
    preparation_spec = preparation_rows[expected["endpoint"]]
    supplied_start = spec.get("common_start", preparation_spec["start"])
    if supplied_start != preparation_spec["start"]:
        raise ValueError("common state-preparation start differs from the frozen contract")
    start = index_at(hours, preparation_spec["start"])
    evaluation_start = index_at(hours, expected["stop"])
    stop = index_at(hours, CHAIN_STOP)
    if evaluation_start - start != preparation_spec["hours"]:
        raise RuntimeError("three-month state-preparation hour count differs")
    expected_chain_hours = {"E1": 81096, "E2": 76728, "E3": 63576}[
        expected["endpoint"]
    ]
    if stop - start != expected_chain_hours:
        raise RuntimeError("continuous assessment-chain hour count differs")
    return {
        "assessment_id": f"{expected['exp_id']}-MATCHED3",
        "experiment_id": expected["exp_id"],
        "endpoint": expected["endpoint"],
        "months": expected["months"],
        "assimilation_start": preparation_spec["start"],
        "evaluation_start": expected["stop"],
        "assimilation_stop": CHAIN_STOP,
        "start": start,
        "evaluation_start_index": evaluation_start,
        "stop": stop,
        "pre_evaluation_assimilation_hours": preparation_spec["hours"],
        "processed_hour_count": stop - start,
        "initial_covariance_hash": FIXED_INITIAL_COVARIANCE_SHA256,
        "initial_model_probability": 1.0,
        "state_reset_count": 0,
    }


def assessment_origins_for_endpoint(
        endpoint: str, dates: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, dict[int, str]]:
    """Return the recent origins followed by the six disjoint annual blocks."""
    if endpoint not in _COMMON_WARMUP_RAW:
        raise ValueError(f"unknown endpoint identity: {endpoint}")
    arrays = origin_arrays(validate_hour_axis(np.asarray(dates)))
    recent = arrays[f"evaluation_RECENT_{endpoint}"]
    yearly = [arrays[f"evaluation_YEAR_{year}"] for year in range(2005, 2011)]
    origins = np.concatenate([recent, *yearly]).astype(np.int64, copy=False)
    codes = np.concatenate([
        np.zeros(len(recent), dtype=np.int8),
        *[
            np.full(len(values), code, dtype=np.int8)
            for code, values in enumerate(yearly, start=1)
        ],
    ])
    expected = 2161 + {"E1": 360, "E2": 360, "E3": 361}[endpoint]
    if (len(origins) != expected or len(codes) != expected
            or np.any(np.diff(origins) <= 0)):
        raise RuntimeError(f"assessment-origin contract differs: {endpoint}")
    return origins, codes, dict(_PERIOD_LABELS)


def validate_selected_identity(spec: Mapping, selection: Mapping) -> dict:
    """Bind a frozen selection to its exact common-date archived warmup row."""
    expected = _literal_spec(spec)
    if not isinstance(selection, Mapping):
        raise TypeError("selection must be a mapping")
    required = {
        "experiment_id", "endpoint", "months", "parameter_id", "parameter_values",
        "parameters", "noise_id", "noise_diagonal", "selected_identity_eligible",
        "common_warmup_state", "common_warmup_state_sha256",
        "common_warmup_state_source_exp_id",
        "common_warmup_state_source_parameter_id",
        "common_warmup_state_source_hashes",
        "source_hashes",
    }
    missing = required - set(selection)
    if missing:
        raise ValueError(f"selected identity fields are missing: {sorted(missing)}")
    if (selection["experiment_id"] != expected["exp_id"]
            or selection["endpoint"] != expected["endpoint"]
            or int(selection["months"]) != expected["months"]):
        raise ValueError("selected identity does not match the assessment experiment")
    parameter_id = int(selection["parameter_id"])
    noise_id = int(selection["noise_id"])
    if not 0 <= parameter_id < 2048 or not 0 <= noise_id < 128:
        raise ValueError("selected parameter or noise identity is outside the frozen design")
    if selection["selected_identity_eligible"] is not True:
        raise ValueError("selected identity is not eligible for common initialization")
    source = _common_warmup_record(expected["endpoint"])
    state = load_common_warmup_state(expected["endpoint"], parameter_id)
    parameter_values = np.asarray(selection["parameter_values"])
    if (parameter_values.dtype != np.float64 or parameter_values.shape != (5,)
            or not np.array_equal(parameter_values, source["parameter_values"][parameter_id])):
        raise ValueError("selected physical-parameter values differ from the archived identity")
    supplied_state = np.asarray(selection["common_warmup_state"])
    if (supplied_state.dtype != np.float64 or supplied_state.shape != (5,)
            or not np.array_equal(supplied_state, state)
            or selection["common_warmup_state_sha256"] != array_sha256(state)):
        raise ValueError("selected common warmup state differs from its parameter identity")
    if (selection["common_warmup_state_source_exp_id"]
            != f"RL-{expected['endpoint']}-M03"
            or int(selection["common_warmup_state_source_parameter_id"]) != parameter_id):
        raise ValueError("selected common warmup source identity differs")
    expected_source_hashes = {
        "raw_npz": source["raw_sha256"],
        "warmup_states": source["warmup_states_sha256"],
    }
    if dict(selection["common_warmup_state_source_hashes"]) != expected_source_hashes:
        raise ValueError("selected common warmup source hashes differ")
    noise = np.asarray(selection["noise_diagonal"])
    if (noise.dtype != np.float64 or noise.shape != (5,)
            or not np.isfinite(noise).all() or np.any(noise < 0)):
        raise ValueError("selected process-noise diagonal is invalid")
    parameters = selection["parameters"]
    if not isinstance(parameters, Mapping) or not parameters:
        raise ValueError("selected complete physical-parameter mapping is absent")
    try:
        parameter_scalars = np.asarray(
            [float(value) for value in parameters.values()], dtype=np.float64,
        )
    except (TypeError, ValueError) as error:
        raise ValueError("selected complete physical parameters are not numeric") from error
    if not np.isfinite(parameter_scalars).all():
        raise ValueError("selected complete physical parameters are nonfinite")
    return {
        "parameter_id": parameter_id,
        "noise_id": noise_id,
        "parameters": {key: float(value) for key, value in parameters.items()},
        "noise_diagonal": noise.astype(np.float64, copy=True),
        "warmup_state": np.array(state, copy=True),
        "common_warmup_raw_sha256": source["raw_sha256"],
        "common_warmup_states_sha256": source["warmup_states_sha256"],
        "selection_source_hashes": dict(selection["source_hashes"]),
    }


def _load_assessment_core() -> dict[str, object]:
    contract, short_record, noise_search = calibration._load_sealed_core()
    filter_module = importlib.import_module("walrus_history_conditioned_imm.filter")
    adapter_module = importlib.import_module("walrus_history_conditioned_imm.noise_filter")
    walrus_module = importlib.import_module("walrus_history_conditioned_imm.walrus")
    calibration._assert_sealed_module_paths(
        contract, short_record, noise_search, filter_module, adapter_module,
        walrus_module,
    )
    return {
        "contract": contract,
        "short_record": short_record,
        "noise_search": noise_search,
        "FilterState": filter_module.FilterState,
        "BatchedNoiseFilters": adapter_module.BatchedNoiseFilters,
        "walrus_step": walrus_module.walrus_step,
    }


def _validate_core_selected_identity(identity: dict, core: dict[str, object]) -> None:
    config = read_json(calibration.BASE_CONFIG)
    validated = calibration._validate_scientific_config(
        config, core["contract"], core["short_record"],
    )
    parameter_id = identity["parameter_id"]
    expected_parameters = {
        key: float(value)
        for key, value in validated["records"][parameter_id].items()
    }
    if identity["parameters"] != expected_parameters:
        raise ValueError("selected complete physical parameters differ from the frozen design")
    design = calibration._canonical_design(
        calibration.CANONICAL_NOISE_DESIGN,
        file_sha256=calibration.CANONICAL_NOISE_FILE_SHA256,
        array_sha256_expected=calibration.NOISE_DESIGN_SHA256,
        shape=(128, 5),
        label="noise",
    )
    if not np.array_equal(
            identity["noise_diagonal"], design[identity["noise_id"]]):
        raise ValueError("selected process-noise identity differs from the frozen design")


def _replay_common_warmup(
        *, forcing: np.ndarray, stop: int, fixed_parameters: Mapping,
        expected_state: np.ndarray, walrus_step: Callable,
) -> dict:
    """Replay the same sealed weather-only equations; this is provenance only."""
    state = torch.tensor(
        [[140.0, 1000.0, 4.0, 1200.0, 0.1]], dtype=torch.float64,
    )
    with torch.no_grad():
        for hour in range(stop):
            state = walrus_step(
                state,
                torch.as_tensor(forcing[hour:hour + 1], dtype=torch.float64),
                fixed_parameters,
            )
            if not bool(torch.isfinite(state).all()):
                raise RuntimeError(
                    f"weather-only provenance replay became nonfinite at hour {hour}"
                )
    replayed = state[0].detach().numpy().copy()
    difference = float(np.max(np.abs(replayed - expected_state)))
    if not np.isfinite(difference) or difference > REPLAY_ABSOLUTE_TOLERANCE:
        raise RuntimeError(
            "common warmup provenance replay differs from the archived parameter row: "
            f"max_abs_difference={difference}"
        )
    return {
        "replayed_state": replayed,
        "max_absolute_difference": difference,
        "absolute_tolerance": REPLAY_ABSOLUTE_TOLERANCE,
        "relative_tolerance": 0.0,
        "replay_hours": int(stop),
        "interpretation": "same sealed hydrologic equations used for provenance replay",
        "independent_implementation": False,
    }


def _forecast_states(
        initial_state: np.ndarray,
        future_forcing: np.ndarray,
        fixed_parameters: Mapping,
        walrus_step: Callable,
) -> np.ndarray:
    initial = np.asarray(initial_state)
    forcing = np.asarray(future_forcing)
    if (initial.dtype != np.float64 or initial.shape != (5,)
            or forcing.dtype != np.float64
            or forcing.shape != (FORECAST_HOURS, 2)
            or not np.isfinite(initial).all() or not np.isfinite(forcing).all()):
        raise ValueError("deterministic forecast state or forcing contract differs")
    before = initial.tobytes()
    state = torch.from_numpy(initial.copy()[None])
    propagated = np.full((FORECAST_HOURS, 5), np.nan, dtype=np.float64)
    with torch.no_grad():
        for lead in range(FORECAST_HOURS):
            state = walrus_step(
                state, torch.from_numpy(forcing[lead:lead + 1]), fixed_parameters,
            )
            if not bool(torch.isfinite(state).all()):
                raise RuntimeError(
                    f"deterministic forecast has a nonfinite complete state at lead {lead + 1}"
                )
            propagated[lead] = state[0].detach().numpy()
    if initial.tobytes() != before:
        raise RuntimeError("deterministic forecast changed its input posterior state")
    return propagated


def deterministic_state_forecast(
        initial_state: np.ndarray,
        future_forcing: np.ndarray,
        fixed_parameters: Mapping,
) -> np.ndarray:
    """Advance one copied state for 120 hours; no covariance or flow is accepted."""
    core = _load_assessment_core()
    return _forecast_states(
        initial_state, future_forcing, fixed_parameters, core["walrus_step"],
    )


class _ArtifactWriter:
    def __init__(self, destination: Path):
        self.destination = Path(destination)
        self.checkpoints = self.destination / "checkpoints"
        self.blocks = self.destination / "prediction_blocks"
        self.checkpoints.mkdir(exist_ok=False)
        self.blocks.mkdir(exist_ok=False)
        self.checkpoint_count = 0
        self.block_count = 0
        self.identity: dict | None = None

    def bind_identity(self, identity: dict) -> None:
        if self.identity is not None:
            raise RuntimeError("assessment artifact identity is already bound")
        required = {
            "experiment_id", "assessment_id", "parameter_id", "noise_id",
            "source_hashes",
        }
        if set(identity) != required or not isinstance(identity["source_hashes"], dict):
            raise ValueError("assessment artifact identity is incomplete")
        self.identity = dict(identity)

    def event(self, event: str, **fields) -> None:
        row = {"utc": _utc(), "event": event, **fields}
        with (self.destination / "events.jsonl").open("a", encoding="utf-8") as target:
            target.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")

    def checkpoint(
            self, kind: str, hour: int, state, global_state: np.ndarray,
            completed_origins: int,
    ) -> None:
        if self.identity is None:
            raise RuntimeError("assessment artifact identity was not bound")
        self.checkpoint_count += 1
        stem = (
            f"{self.checkpoint_count:04d}_{kind}_state_at_{int(hour):06d}"
        )
        arrays_path = self.checkpoints / f"{stem}.npz"
        metadata_path = self.checkpoints / f"{stem}.json"
        save_npz_new(
            arrays_path,
            member_states=state.states.detach().numpy().copy(),
            member_covariances=state.covariances.detach().numpy().copy(),
            probabilities=state.probabilities.detach().numpy().copy(),
            global_state=np.asarray(global_state, dtype=np.float64).reshape(1, 5),
            hour_index=np.asarray([hour], dtype=np.int64),
        )
        write_json_new(metadata_path, {
            "schema": "regge_record_length_assessment_checkpoint_v01",
            "kind": kind,
            "last_valid_hour": int(hour),
            "next_hour": int(hour + 1),
            "completed_origins": int(completed_origins),
            "arrays_sha256": sha256(arrays_path),
            "utc": _utc(),
            **self.identity,
        })
        self.event(
            "assessment_checkpoint", kind=kind, last_valid_hour=int(hour),
            completed_origins=int(completed_origins),
        )

    def prediction_block(
            self, first: int, last: int, arrays: dict[str, np.ndarray],
    ) -> None:
        self.block_count += 1
        target = self.blocks / f"block_{first:04d}_{last:04d}.npz"
        save_npz_new(
            target,
            origins=arrays["origins"][first:last + 1],
            truth=arrays["truth"][first:last + 1],
            forecast_forcing=arrays["forecast_forcing"][first:last + 1],
            persistence=arrays["persistence"][first:last + 1],
            forecast_states=arrays["forecast_states"][first:last + 1],
            predictions=arrays["predictions"][first:last + 1],
        )
        self.event(
            "assessment_prediction_block", first_row=int(first),
            last_row=int(last), arrays_sha256=sha256(target),
        )


def _empty_arrays(
        *, dates: np.ndarray, forcing: np.ndarray, observations: np.ndarray,
        start: int, stop: int, origins: np.ndarray, period_codes: np.ndarray,
        parameter_id: int, noise_id: int,
) -> dict[str, np.ndarray]:
    targets = origins[:, None] + np.arange(1, FORECAST_HOURS + 1)[None, :]
    return {
        "timestamps": dates[start:stop].copy(),
        "forcing": forcing[start:stop].copy(),
        "observations": observations[start:stop].copy(),
        "posterior_states": np.full((stop - start, 5), np.nan, dtype=np.float64),
        "posterior_covariances": np.full(
            (stop - start, 5, 5), np.nan, dtype=np.float64,
        ),
        "origins": origins.copy(),
        "target_indices": targets.astype(np.int64, copy=False),
        "truth": observations[targets].copy(),
        "forecast_forcing": forcing[targets].copy(),
        "persistence": np.broadcast_to(
            observations[origins, None], targets.shape,
        ).copy(),
        "forecast_states": np.full(
            (len(origins), FORECAST_HOURS, 5), np.nan, dtype=np.float64,
        ),
        "predictions": np.full(
            (len(origins), FORECAST_HOURS), np.nan, dtype=np.float64,
        ),
        "period_codes": period_codes.copy(),
        "selected_parameter_id": np.asarray([parameter_id], dtype=np.int64),
        "selected_noise_id": np.asarray([noise_id], dtype=np.int64),
    }


def _partial_result(
        *, spec: dict, identity: dict, contract: dict, arrays: dict,
        last_valid_hour: int, completed_origins: int,
        forecast_steps: int, noninterference_checks: int, valid: bool,
        control_meta: Mapping | None = None,
) -> AssessmentResult:
    processed = max(0, last_valid_hour - contract["start"] + 1)
    meta = {
        **contract,
        "experiment_id": spec["exp_id"],
        "assessment_id": f"{spec['exp_id']}-MATCHED3",
        "parameter_id": identity["parameter_id"],
        "noise_id": identity["noise_id"],
        "selected_parameters": dict(identity["parameters"]),
        "selected_noise_diagonal": identity["noise_diagonal"].tolist(),
        "valid": bool(valid),
        "last_valid_hour": int(last_valid_hour),
        "processed_hour_count": int(processed),
        "completed_origins": int(completed_origins),
        "deterministic_forecast_steps": int(forecast_steps),
        "state_reset_count": 0,
        "forecast_form": "single_posterior_state_deterministic_fixed_parameters",
        "forecast_input_fields": [
            "single_posterior_state", "future_forcing", "fixed_parameters",
        ],
        "forecast_observation_input_count": 0,
        "forecast_covariance_propagation_count": 0,
        "forecast_sigma_point_propagation_count": 0,
        "forecast_state_noninterference_checks": int(noninterference_checks),
        "all_forecast_state_inputs_byte_unchanged": (
            noninterference_checks == completed_origins
        ),
        "period_labels": dict(_PERIOD_LABELS),
        "complete_filter_state_saved_each_hour": True,
        "complete_forecast_state_saved_each_lead": True,
        "annual_state_resets": 0,
        "model_probability": 1.0,
        **(dict(control_meta) if control_meta is not None else {}),
    }
    return AssessmentResult(meta=meta, arrays=arrays)


def _run_continuous_chain(
        *, spec: dict, identity: dict, dates: np.ndarray, forcing: np.ndarray,
        observations: np.ndarray, start: int, stop: int, origins: np.ndarray,
        period_codes: np.ndarray, warmup_state: np.ndarray,
        writer: _ArtifactWriter, core: dict[str, object],
        prefix_controls: bool = False,
) -> AssessmentResult:
    dates = validate_hour_axis(np.asarray(dates))
    forcing = np.asarray(forcing)
    observations = np.asarray(observations)
    origins = np.asarray(origins)
    period_codes = np.asarray(period_codes)
    warmup_state = np.asarray(warmup_state)
    if (forcing.dtype != np.float64 or observations.dtype != np.float64
            or forcing.shape != (len(dates), 2)
            or observations.shape != (len(dates),)
            or not np.isfinite(forcing).all()
            or not np.isfinite(observations).all()):
        raise ValueError("assessment forcing or observations differ from the float64 contract")
    if (warmup_state.dtype != np.float64 or warmup_state.shape != (5,)
            or not np.isfinite(warmup_state).all()):
        raise ValueError("common warmup state differs from the finite five-state contract")
    if (not 0 <= start < stop <= len(dates)
            or origins.ndim != 1 or origins.dtype != np.int64 or len(origins) == 0
            or np.any(np.diff(origins) <= 0)
            or origins[0] < start or origins[-1] >= stop
            or origins[-1] + FORECAST_HOURS >= len(dates)
            or period_codes.shape != origins.shape or period_codes.dtype != np.int8):
        raise ValueError("assessment chain or origin bounds differ")

    arrays = _empty_arrays(
        dates=dates, forcing=forcing, observations=observations,
        start=start, stop=stop, origins=origins, period_codes=period_codes,
        parameter_id=identity["parameter_id"], noise_id=identity["noise_id"],
    )
    batch_size = 2 if prefix_controls else 1
    if prefix_controls:
        arrays.update({
            "parallel_reproduction_states": np.full(
                (stop - start, 5), np.nan, dtype=np.float64,
            ),
            "parallel_reproduction_covariances": np.full(
                (stop - start, 5, 5), np.nan, dtype=np.float64,
            ),
            "post_origin_flow_original": observations[
                origins[0] + 1:origins[0] + FORECAST_HOURS + 1
            ].copy(),
            "post_origin_flow_changed": np.full(
                FORECAST_HOURS, np.nan, dtype=np.float64,
            ),
            "post_origin_flow_control_predictions": np.full(
                FORECAST_HOURS, np.nan, dtype=np.float64,
            ),
        })
        arrays["post_origin_flow_changed"][:] = (
            arrays["post_origin_flow_original"]
            + np.maximum(
                1.0, np.abs(arrays["post_origin_flow_original"]) * 0.25 + 0.5,
            )
        )
    Adapter = core["BatchedNoiseFilters"]
    FilterState = core["FilterState"]
    adapter = Adapter(
        [[identity["parameters"]] for _ in range(batch_size)],
        np.broadcast_to(
            identity["noise_diagonal"].reshape(1, 1, 5),
            (batch_size, 1, 5),
        ).copy(),
        observation_variance=OBSERVATION_VARIANCE,
        interaction_groups=[[0] for _ in range(batch_size)],
    )
    covariance = fixed_initial_covariance()
    state = FilterState(
        torch.from_numpy(np.broadcast_to(
            warmup_state.reshape(1, 1, 5), (batch_size, 1, 5),
        ).copy()),
        torch.from_numpy(np.broadcast_to(
            covariance.reshape(1, 1, 5, 5), (batch_size, 1, 5, 5),
        ).copy()),
        torch.ones((batch_size, 1), dtype=torch.float64),
    )
    global_state = warmup_state.copy()
    rows = {int(origin): row for row, origin in enumerate(origins)}
    alive = np.ones(batch_size, dtype=np.bool_)
    last_valid_hour = start - 1
    completed_origins = 0
    forecast_steps = 0
    noninterference_checks = 0
    maximum_reproduction_state_difference = 0.0
    maximum_reproduction_covariance_difference = 0.0
    last_checkpoint_hour = start - 1
    next_wall_checkpoint = time.monotonic() + 1800
    def checkpoint_state(current):
        if not prefix_controls:
            return current
        return FilterState(
            current.states[:1].clone(), current.covariances[:1].clone(),
            current.probabilities[:1].clone(),
        )

    def current_control_meta(*, complete: bool) -> dict:
        if not prefix_controls:
            return {}
        second_row = int(origins[1] - start) if len(origins) > 1 else stop - start
        reproduction_complete = (
            last_valid_hour == stop - 1
            and np.isfinite(arrays["parallel_reproduction_states"]).all()
            and np.isfinite(arrays["parallel_reproduction_covariances"]).all()
        )
        second_origin_verified = (
            complete and len(origins) == 2
            and np.allclose(
                arrays["posterior_states"][second_row:],
                arrays["parallel_reproduction_states"][second_row:],
                atol=REPLAY_ABSOLUTE_TOLERANCE, rtol=0,
            )
            and np.allclose(
                arrays["posterior_covariances"][second_row:],
                arrays["parallel_reproduction_covariances"][second_row:],
                atol=REPLAY_ABSOLUTE_TOLERANCE, rtol=0,
            )
        )
        flow_verified = (
            complete
            and not np.array_equal(
                arrays["post_origin_flow_original"],
                arrays["post_origin_flow_changed"],
            )
            and np.array_equal(
                arrays["post_origin_flow_control_predictions"],
                arrays["predictions"][0],
            )
        )
        return {
            "parallel_reproduction_mode": (
                "isolated_second_filter_copy_with_identical_inputs_in_one_240_hour_batch"
            ),
            "parallel_reproduction_filter_hours": int(stop - start),
            "parallel_reproduction_absolute_tolerance": REPLAY_ABSOLUTE_TOLERANCE,
            "parallel_reproduction_relative_tolerance": 0.0,
            "parallel_reproduction_max_state_difference": float(
                maximum_reproduction_state_difference
            ),
            "parallel_reproduction_max_covariance_difference": float(
                maximum_reproduction_covariance_difference
            ),
            "parallel_reproduction_verified": bool(
                complete and reproduction_complete
                and maximum_reproduction_state_difference
                <= REPLAY_ABSOLUTE_TOLERANCE
                and maximum_reproduction_covariance_difference
                <= REPLAY_ABSOLUTE_TOLERANCE
            ),
            "second_origin_noninterference_mode": (
                "primary_copy_issues_two_forecasts_duplicate_copy_issues_none"
            ),
            "second_origin_noninterference_verified": bool(second_origin_verified),
            "post_origin_flow_control_mode": (
                "counterfactual_future_flow_excluded_from_forecast_inputs"
            ),
            "post_origin_flow_control_verified": bool(flow_verified),
        }

    writer.checkpoint(
        "start", last_valid_hour, checkpoint_state(state), global_state, 0,
    )
    try:
        for hour in range(start, stop):
            update = core["short_record"].isolated_filter_step(
                adapter,
                state,
                np.repeat(forcing[hour:hour + 1], batch_size, axis=0),
                np.repeat(observations[hour:hour + 1], batch_size, axis=0),
                np.ones((1, 1), dtype=np.float64),
                alive,
            )
            if update["failures"] or not bool(np.asarray(update["alive"]).all()):
                reason = update["failures"][0]["reason"] if update["failures"] else "unknown"
                raise RuntimeError(
                    f"single-model filter failed at hour {hour}: {reason}"
                )
            state = update["state"]
            alive = update["alive"]
            global_state = update["global_states"][0].detach().numpy().copy()
            global_covariance = (
                update["global_covariances"][0].detach().numpy().copy()
            )
            if not np.array_equal(
                    state.probabilities.detach().numpy(),
                    np.ones((batch_size, 1), dtype=np.float64)):
                raise RuntimeError("single-model posterior probability differs from one")
            chain_row = hour - start
            arrays["posterior_states"][chain_row] = global_state
            arrays["posterior_covariances"][chain_row] = global_covariance
            if prefix_controls:
                reproduced_state = update["global_states"][1].detach().numpy().copy()
                reproduced_covariance = (
                    update["global_covariances"][1].detach().numpy().copy()
                )
                arrays["parallel_reproduction_states"][chain_row] = reproduced_state
                arrays["parallel_reproduction_covariances"][chain_row] = (
                    reproduced_covariance
                )
                state_difference = float(np.max(np.abs(
                    global_state - reproduced_state,
                )))
                covariance_difference = float(np.max(np.abs(
                    global_covariance - reproduced_covariance,
                )))
                maximum_reproduction_state_difference = max(
                    maximum_reproduction_state_difference, state_difference,
                )
                maximum_reproduction_covariance_difference = max(
                    maximum_reproduction_covariance_difference,
                    covariance_difference,
                )
                if (not np.allclose(
                        global_state, reproduced_state,
                        atol=REPLAY_ABSOLUTE_TOLERANCE, rtol=0,
                    ) or not np.allclose(
                        global_covariance, reproduced_covariance,
                        atol=REPLAY_ABSOLUTE_TOLERANCE, rtol=0,
                    )):
                    raise RuntimeError(
                        "parallel repetition differs from the primary prefix"
                    )
            last_valid_hour = hour

            origin_row = rows.get(hour)
            if origin_row is not None:
                tensor_bytes_before = tuple(
                    value.detach().numpy().tobytes()
                    for value in (
                        state.states, state.covariances, state.probabilities,
                    )
                )
                state_bytes_before = global_state.tobytes()
                forecast_states = _forecast_states(
                    global_state.copy(),
                    arrays["forecast_forcing"][origin_row],
                    identity["parameters"],
                    core["walrus_step"],
                )
                tensor_bytes_after = tuple(
                    value.detach().numpy().tobytes()
                    for value in (
                        state.states, state.covariances, state.probabilities,
                    )
                )
                if (tensor_bytes_after != tensor_bytes_before
                        or global_state.tobytes() != state_bytes_before):
                    raise RuntimeError("forecast changed the continuous filter state")
                arrays["forecast_states"][origin_row] = forecast_states
                arrays["predictions"][origin_row] = forecast_states[:, 4]
                if prefix_controls and origin_row == 0:
                    arrays["post_origin_flow_control_predictions"][:] = (
                        forecast_states[:, 4]
                    )
                noninterference_checks += 1
                completed_origins = origin_row + 1
                forecast_steps += FORECAST_HOURS
                if completed_origins % 30 == 0:
                    writer.prediction_block(
                        completed_origins - 30, completed_origins - 1, arrays,
                    )

            now = time.monotonic()
            if hour - last_checkpoint_hour >= 720 or now >= next_wall_checkpoint:
                writer.checkpoint(
                    "periodic", hour, checkpoint_state(state), global_state,
                    completed_origins,
                )
                last_checkpoint_hour = hour
                next_wall_checkpoint = now + 1800

        if completed_origins % 30:
            first = completed_origins - (completed_origins % 30)
            writer.prediction_block(first, completed_origins - 1, arrays)
        if last_checkpoint_hour != last_valid_hour:
            writer.checkpoint(
                "final", last_valid_hour, checkpoint_state(state), global_state,
                completed_origins,
            )
        valid = (
            last_valid_hour == stop - 1
            and completed_origins == len(origins)
            and forecast_steps == len(origins) * FORECAST_HOURS
            and np.isfinite(arrays["posterior_states"]).all()
            and np.isfinite(arrays["posterior_covariances"]).all()
            and np.isfinite(arrays["forecast_states"]).all()
            and np.isfinite(arrays["predictions"]).all()
            and (
                not prefix_controls
                or (
                    current_control_meta(complete=True)[
                        "parallel_reproduction_verified"
                    ]
                    and current_control_meta(complete=True)[
                        "second_origin_noninterference_verified"
                    ]
                    and current_control_meta(complete=True)[
                        "post_origin_flow_control_verified"
                    ]
                )
            )
        )
        if not valid:
            raise RuntimeError("continuous assessment chain is incomplete")
    except BaseException as error:
        try:
            writer.checkpoint(
                "failure", last_valid_hour, checkpoint_state(state), global_state,
                completed_origins,
            )
        except BaseException as checkpoint_error:
            error.add_note(
                "failure checkpoint also failed: "
                f"{type(checkpoint_error).__name__}: {checkpoint_error}"
            )
        partial = _partial_result(
            spec=spec, identity=identity,
            contract={
                **assessment_contract(spec, dates), "start": start, "stop": stop,
            },
            arrays=arrays, last_valid_hour=last_valid_hour,
            completed_origins=completed_origins, forecast_steps=forecast_steps,
            noninterference_checks=noninterference_checks, valid=False,
            control_meta=current_control_meta(complete=False),
        )
        error.assessment_partial_result = partial
        raise

    return _partial_result(
        spec=spec, identity=identity,
        contract={
            **assessment_contract(spec, dates), "start": start, "stop": stop,
        },
        arrays=arrays, last_valid_hour=last_valid_hour,
        completed_origins=completed_origins, forecast_steps=forecast_steps,
        noninterference_checks=noninterference_checks, valid=True,
        control_meta=current_control_meta(complete=True),
    )


def _save_completed_result(
        destination: Path, result: AssessmentResult, writer: _ArtifactWriter,
        extra_receipt: dict | None = None,
) -> None:
    arrays_path = destination / "arrays.npz"
    metadata_path = destination / "metadata.json"
    save_npz_new(arrays_path, **result.arrays)
    write_json_new(metadata_path, result.meta)
    files = {
        "arrays.npz": sha256(arrays_path),
        "metadata.json": sha256(metadata_path),
    }
    write_json_new(destination / "receipt.json", {
        "schema": "regge_record_length_assessment_receipt_v01",
        "status": "complete", "passed": True,
        "experiment_id": result.meta["experiment_id"],
        "assessment_id": result.meta["assessment_id"],
        "processed_hour_count": result.meta["processed_hour_count"],
        "completed_origins": result.meta["completed_origins"],
        "deterministic_forecast_steps": result.meta[
            "deterministic_forecast_steps"
        ],
        "checkpoint_count": writer.checkpoint_count,
        "prediction_block_count": writer.block_count,
        "files": files,
        **(extra_receipt or {}),
    })


def _artifact_identity(spec: dict, identity: dict, raw_data_sha256: str) -> dict:
    calibration_sources = identity["selection_source_hashes"]
    return {
        "experiment_id": spec["exp_id"],
        "assessment_id": f"{spec['exp_id']}-MATCHED3",
        "parameter_id": identity["parameter_id"],
        "noise_id": identity["noise_id"],
        "source_hashes": {
            "raw_data": raw_data_sha256,
            "common_warmup_raw": identity["common_warmup_raw_sha256"],
            "common_warmup_states": identity["common_warmup_states_sha256"],
            "selection_calibration_raw": calibration_sources.get("raw_npz"),
            "selection_calibration_result": calibration_sources.get("result_json"),
            "sealed_runtime_binding": sha256(calibration.SEALED_SOURCE_BINDING),
        },
    }


def run_continuous_prefix(
        *, spec: dict, selection: dict, dates: np.ndarray, forcing: np.ndarray,
        observations: np.ndarray, start: int, stop: int, origins: np.ndarray,
        warmup_state: np.ndarray, destination: Path,
) -> AssessmentResult:
    """Run the one authorized 240-hour real-core test prefix."""
    expected = _literal_spec(spec)
    identity = validate_selected_identity(expected, selection)
    supplied_warmup = np.asarray(warmup_state)
    frozen_start = assessment_contract(expected, np.asarray(dates))["start"]
    if (expected["exp_id"] != "RL-E1-M03"
            or identity["parameter_id"] != 67 or identity["noise_id"] != 84
            or start != frozen_start
            or stop - start != 240
            or not np.array_equal(
                np.asarray(origins), np.asarray([start + 120, start + 144]),
            )
            or supplied_warmup.dtype != np.float64
            or supplied_warmup.shape != (5,)
            or not np.array_equal(supplied_warmup, identity["warmup_state"])):
        raise ValueError("real-prefix test is outside the frozen 240+240 budget")
    destination = Path(destination)
    if destination.exists():
        if not destination.is_dir() or any(destination.iterdir()):
            raise FileExistsError("real-prefix test destination is not empty")
    else:
        destination.mkdir(parents=True, exist_ok=False)
    write_json_new(destination / "started.json", {
        "schema": "regge_record_length_real_prefix_start_v01",
        "status": "started", "filter_hours": 240,
        "forecast_origins": 2, "forecast_hours_per_origin": 120,
    })
    writer = _ArtifactWriter(destination)
    core = _load_assessment_core()
    _validate_core_selected_identity(identity, core)
    writer.bind_identity(_artifact_identity(expected, identity, RAW_DATA_SHA256))
    codes = np.full(2, -1, dtype=np.int8)
    try:
        with calibration._one_thread_no_grad():
            result = _run_continuous_chain(
                spec=expected, identity=identity, dates=dates, forcing=forcing,
                observations=observations, start=start, stop=stop,
                origins=np.asarray(origins, dtype=np.int64), period_codes=codes,
                warmup_state=supplied_warmup,
                writer=writer, core=core, prefix_controls=True,
            )
        meta = dict(result.meta)
        meta.update(
            test_prefix_only=True,
            provenance_replay_performed=False,
            formal_assessment=False,
        )
        result = AssessmentResult(meta=meta, arrays=result.arrays)
        _save_completed_result(
            destination, result, writer,
            extra_receipt={
                "test_prefix_only": True,
                "formal_output_created": False,
                "filter_budget": 240,
                "forecast_budget": 240,
            },
        )
        return result
    except BaseException as error:
        if not (destination / "failure.json").exists():
            write_json_new(destination / "failure.json", {
                "schema": "regge_record_length_real_prefix_failure_v01",
                "status": "failed", "passed": False,
                "error": {"type": type(error).__name__, "reason": str(error)},
                "traceback": traceback.format_exc(),
            })
        raise


def assess_one(
        spec: dict, selection: dict, origins: np.ndarray, destination: Path,
        *, _inputs: tuple | None = None,
) -> AssessmentResult:
    """Run one immutable matched-history chain and preserve every failure."""
    destination = Path(destination)
    if destination.exists():
        raise FileExistsError(f"assessment attempt already exists: {destination}")
    destination.mkdir(parents=True, exist_ok=False)
    started = time.perf_counter()
    writer: _ArtifactWriter | None = None
    result: AssessmentResult | None = None
    try:
        expected = _literal_spec(spec)
        write_json_new(destination / "started.json", {
            "schema": "regge_record_length_assessment_start_v01",
            "status": "started", "started_utc": _utc(),
            "experiment_id": expected["exp_id"],
            "assessment_id": f"{expected['exp_id']}-MATCHED3",
            "restart_policy": "none",
        })
        writer = _ArtifactWriter(destination)
        writer.event("assessment_started", experiment_id=expected["exp_id"])
        dates, forcing, observations, input_checks = (
            load_inputs() if _inputs is None else _inputs
        )
        dates = validate_hour_axis(np.asarray(dates))
        forcing = np.asarray(forcing)
        observations = np.asarray(observations)
        contract = assessment_contract(expected, dates)
        expected_origins, period_codes, labels = assessment_origins_for_endpoint(
            expected["endpoint"], dates,
        )
        supplied_origins = np.asarray(origins)
        if (supplied_origins.dtype != np.int64
                or not np.array_equal(supplied_origins, expected_origins)):
            raise ValueError("assessment origins differ from the frozen recent-plus-yearly union")
        if labels != _PERIOD_LABELS:
            raise RuntimeError("assessment period labels differ")
        identity = validate_selected_identity(expected, selection)
        core = _load_assessment_core()
        _validate_core_selected_identity(identity, core)
        writer.bind_identity(_artifact_identity(
            expected, identity,
            str(input_checks.get("raw_data_sha256", RAW_DATA_SHA256)),
        ))
        replay = _replay_common_warmup(
            forcing=forcing, stop=contract["start"],
            fixed_parameters=identity["parameters"],
            expected_state=identity["warmup_state"],
            walrus_step=core["walrus_step"],
        )
        writer.event(
            "common_warmup_provenance_replayed",
            replay_hours=replay["replay_hours"],
            max_absolute_difference=replay["max_absolute_difference"],
        )
        with calibration._one_thread_no_grad():
            result = _run_continuous_chain(
                spec=expected, identity=identity, dates=dates, forcing=forcing,
                observations=observations, start=contract["start"],
                stop=contract["stop"], origins=expected_origins,
                period_codes=period_codes, warmup_state=identity["warmup_state"],
                writer=writer, core=core,
            )
        meta = dict(result.meta)
        meta.update(
            provenance_replay={
                key: value for key, value in replay.items()
                if key != "replayed_state"
            },
            provenance_replayed_state_sha256=array_sha256(
                replay["replayed_state"],
            ),
            common_warmup_raw_sha256=identity["common_warmup_raw_sha256"],
            common_warmup_states_sha256=identity[
                "common_warmup_states_sha256"
            ],
            forcing_sha256=array_sha256(forcing[contract["start"]:contract["stop"]]),
            observed_flow_sha256=array_sha256(
                observations[contract["start"]:contract["stop"]],
            ),
            input_checks=dict(input_checks),
            elapsed_seconds=time.perf_counter() - started,
            test_prefix_only=False,
            formal_assessment=True,
        )
        result = AssessmentResult(meta=meta, arrays=result.arrays)
        writer.event(
            "assessment_completed", processed_hours=meta["processed_hour_count"],
            completed_origins=meta["completed_origins"],
        )
        _save_completed_result(
            destination, result, writer,
            extra_receipt={
                "selection_parameter_id": identity["parameter_id"],
                "selection_noise_id": identity["noise_id"],
                "provenance_replay_max_absolute_difference": replay[
                    "max_absolute_difference"
                ],
                "elapsed_seconds": time.perf_counter() - started,
            },
        )
        return result
    except BaseException as error:
        partial = getattr(error, "assessment_partial_result", None)
        if not isinstance(partial, AssessmentResult) and isinstance(result, AssessmentResult):
            partial = result
        files = {}
        if isinstance(partial, AssessmentResult):
            try:
                save_npz_new(destination / "partial_arrays.npz", **partial.arrays)
                write_json_new(destination / "partial_metadata.json", partial.meta)
                files = {
                    "partial_arrays.npz": sha256(destination / "partial_arrays.npz"),
                    "partial_metadata.json": sha256(destination / "partial_metadata.json"),
                }
            except BaseException as partial_error:
                error.add_note(
                    "partial assessment evidence also failed: "
                    f"{type(partial_error).__name__}: {partial_error}"
                )
        if not (destination / "failure.json").exists():
            try:
                write_json_new(destination / "failure.json", {
                    "schema": "regge_record_length_assessment_failure_v01",
                    "status": "failed", "passed": False,
                    "error": {"type": type(error).__name__, "reason": str(error)},
                    "traceback": traceback.format_exc(),
                    "last_valid_hour": (
                        partial.meta.get("last_valid_hour")
                        if isinstance(partial, AssessmentResult) else None
                    ),
                    "completed_origins": (
                        partial.meta.get("completed_origins", 0)
                        if isinstance(partial, AssessmentResult) else 0
                    ),
                    "files": files,
                    "elapsed_seconds": time.perf_counter() - started,
                    "automatic_retry": False,
                })
            except BaseException as receipt_error:
                error.add_note(
                    "assessment failure receipt also failed: "
                    f"{type(receipt_error).__name__}: {receipt_error}"
                )
        if writer is not None:
            try:
                writer.event(
                    "assessment_failed", error_type=type(error).__name__,
                    error=str(error),
                )
            except BaseException as event_error:
                error.add_note(
                    "assessment failure event also failed: "
                    f"{type(event_error).__name__}: {event_error}"
                )
        raise


def _verify_assessment_stage_inputs(root: Path) -> dict[str, dict]:
    root = Path(root)
    if root.resolve() != Path(preparation.OUTPUT).resolve():
        raise ValueError("assessment root differs from the prepared formal attempt")
    frozen = preparation.verify_prepared()
    if frozen.get("windows") != list(window_specs()):
        raise RuntimeError("prepared window registry differs")
    receipt_path = root / "selection_receipt.json"
    manifest_path = root / "selection_manifest.json"
    selections_path = root / "selections.json"
    if (not receipt_path.is_file() or not manifest_path.is_file()
            or not selections_path.is_file()):
        raise FileNotFoundError("completed frozen selection evidence is missing")
    if (root / "selection_failed.json").exists():
        raise RuntimeError("selection failure receipt coexists with assessment input")
    receipt = read_json(receipt_path)
    manifest = read_json(manifest_path)
    if (receipt.get("status") != "complete" or receipt.get("passed") is not True
            or receipt.get("selection_count") != 12):
        raise RuntimeError("selection stage did not complete with 12 identities")
    if (receipt.get("files", {}).get("selections.json") != sha256(selections_path)
            or receipt.get("files", {}).get("selection_manifest.json")
            != sha256(manifest_path)
            or manifest.get("selections_sha256") != sha256(selections_path)):
        raise RuntimeError("frozen selection hashes differ")
    selections = read_json(selections_path)
    expected_ids = [spec["exp_id"] for spec in window_specs()]
    if (list(selections) != expected_ids
            or any(
                selections[exp_id].get("selected_identity_eligible") is not True
                for exp_id in expected_ids
            )):
        raise RuntimeError("frozen selection identities or eligibility differ")
    return selections


def _locked_historical_single_model_sources() -> dict[str, dict]:
    """Resolve the three old single-model sources only through sealed audit evidence."""
    manifest_path = REPAIRED / "manifest.json"
    audit_path = REPAIRED / "audit.json"
    if (not manifest_path.is_file()
            or sha256(manifest_path) != REPAIRED_MANIFEST_SHA256):
        raise RuntimeError("repaired historical manifest hash differs")
    manifest = read_json(manifest_path)
    if (not audit_path.is_file()
            or sha256(audit_path) != REPAIRED_AUDIT_SHA256
            or manifest.get("files", {}).get("audit.json")
            != REPAIRED_AUDIT_SHA256):
        raise RuntimeError("repaired historical audit hash differs from its manifest")
    audit = read_json(audit_path)
    methods = audit.get("methods")
    if audit.get("passed") is not True or not isinstance(methods, list):
        raise RuntimeError("repaired historical audit is not a passed method registry")

    locked = {}
    used_paths = set()
    historical_root = HISTORICAL_ROOT.resolve()
    for endpoint, window in _HISTORICAL_WINDOWS.items():
        matches = [
            row for row in methods
            if isinstance(row, Mapping)
            and row.get("window") == window
            and row.get("kind") == "updated"
            and row.get("rank") == 1
            and row.get("method") == "independent_single_model_rank_1"
        ]
        if len(matches) != 1:
            raise RuntimeError(
                f"historical audit does not identify exactly one rank-one source: {endpoint}"
            )
        record = dict(matches[0])
        if record.get("valid") is not True or record.get("repaired") is not False:
            raise RuntimeError(f"historical audit source validity differs: {endpoint}")
        try:
            arrays_path = Path(record["source_arrays"]).resolve()
            metadata_path = Path(record["metadata"]).resolve()
            arrays_hash = str(record["source_arrays_sha256"])
            metadata_hash = str(record["metadata_sha256"])
        except (KeyError, TypeError, ValueError) as error:
            raise RuntimeError(
                f"historical audit source fields are incomplete: {endpoint}"
            ) from error
        try:
            arrays_path.relative_to(historical_root)
            metadata_path.relative_to(historical_root)
        except ValueError as error:
            raise RuntimeError(
                f"historical audit source leaves its frozen result root: {endpoint}"
            ) from error
        if ((arrays_path, metadata_path) in used_paths
                or not arrays_path.is_file() or not metadata_path.is_file()
                or sha256(arrays_path) != arrays_hash
                or sha256(metadata_path) != metadata_hash):
            raise RuntimeError(
                f"historical array or metadata hash differs: {endpoint}"
            )
        used_paths.add((arrays_path, metadata_path))
        metadata = read_json(metadata_path)
        parameter_ids = metadata.get("member_parameter_ids")
        noise_ids = metadata.get("member_noise_ids")
        arm = metadata.get("arm")
        if (metadata.get("valid") is not True
                or metadata.get("window") != window
                or metadata.get("method_kind") != "updated"
                or metadata.get("rank") != 1
                or metadata.get("forecast_form")
                != "fixed_posterior_probability_single_global_state"
                or not isinstance(arm, Mapping)
                or arm.get("name") != "independent_single_model_rank_1"
                or not isinstance(parameter_ids, list) or len(parameter_ids) != 1
                or not isinstance(noise_ids, list) or len(noise_ids) != 1):
            raise RuntimeError(f"historical single-model identity differs: {endpoint}")
        parameter_id = parameter_ids[0]
        noise_id = noise_ids[0]
        if (not isinstance(parameter_id, int) or isinstance(parameter_id, bool)
                or not 0 <= parameter_id < 2048
                or not isinstance(noise_id, int) or isinstance(noise_id, bool)
                or not 0 <= noise_id < 128):
            raise RuntimeError(f"historical parameter or noise identity differs: {endpoint}")
        locked[endpoint] = {
            "window": window,
            "arrays_path": arrays_path,
            "metadata_path": metadata_path,
            "arrays_sha256": arrays_hash,
            "metadata_sha256": metadata_hash,
            "parameter_id": parameter_id,
            "noise_id": noise_id,
            "metadata": metadata,
        }
    if set(locked) != set(_HISTORICAL_WINDOWS):
        raise RuntimeError("historical source registry is incomplete")
    return locked


def verify_three_month_historical_reproduction(root: Path) -> dict:
    """Compare only the three unchanged three-month common-period methods."""
    sources = _locked_historical_single_model_sources()
    checks = []
    for endpoint, legacy in _HISTORICAL_WINDOWS.items():
        exp_id = f"RL-{endpoint}-M03"
        destination = Path(root) / "assessment" / f"{exp_id}-MATCHED3"
        meta = read_json(destination / "metadata.json")
        source = sources[endpoint]
        if (meta.get("parameter_id") != source["parameter_id"]
                or meta.get("noise_id") != source["noise_id"]):
            raise RuntimeError(
                f"new three-month assessment identity differs from historical source: {endpoint}"
            )
        with np.load(destination / "arrays.npz", allow_pickle=False) as saved:
            new = {name: saved[name] for name in saved.files}
        selected_parameter = new.get("selected_parameter_id")
        selected_noise = new.get("selected_noise_id")
        if (selected_parameter is None or selected_noise is None
                or selected_parameter.dtype != np.int64
                or selected_noise.dtype != np.int64
                or not np.array_equal(
                    selected_parameter,
                    np.asarray([source["parameter_id"]], dtype=np.int64),
                )
                or not np.array_equal(
                    selected_noise,
                    np.asarray([source["noise_id"]], dtype=np.int64),
                )):
            raise RuntimeError(
                f"new three-month assessment array identity differs: {endpoint}"
            )
        old_path = source["arrays_path"]
        old_meta_path = source["metadata_path"]
        with np.load(old_path, allow_pickle=False) as saved:
            old = {name: saved[name] for name in saved.files}
        common = new["period_codes"] > 0
        origins = new["origins"][common]
        if len(origins) != 2161 or not np.array_equal(origins, old["origin_indices"]):
            raise RuntimeError(f"historical origin indices differ: {endpoint}")
        chain_rows = origins - int(meta["start"])
        comparisons = {
            "target_indices": (new["target_indices"][common], old["target_indices"]),
            "posterior_states": (
                new["posterior_states"][chain_rows], old["global_states"],
            ),
            "posterior_covariances": (
                new["posterior_covariances"][chain_rows],
                old["global_covariances"],
            ),
            "member_states": (
                new["posterior_states"][chain_rows, None, :], old["member_states"],
            ),
            "member_covariances": (
                new["posterior_covariances"][chain_rows, None, :, :],
                old["member_covariances"],
            ),
            "probabilities": (
                np.ones((2161, 1), dtype=np.float64), old["probabilities"],
            ),
            "predictions": (new["predictions"][common], old["fixed_predictions"]),
        }
        differences = {}
        for name, (actual, expected) in comparisons.items():
            if actual.shape != expected.shape:
                raise RuntimeError(
                    f"historical {name} shape differs: {endpoint}"
                )
            if np.issubdtype(actual.dtype, np.integer):
                if not np.array_equal(actual, expected):
                    raise RuntimeError(f"historical {name} differs: {endpoint}")
                difference = 0.0
            else:
                difference = float(np.max(np.abs(actual - expected)))
                if (not np.isfinite(difference)
                        or not np.allclose(
                            actual, expected, atol=REPLAY_ABSOLUTE_TOLERANCE,
                            rtol=0,
                        )):
                    raise RuntimeError(
                        f"historical {name} differs: {endpoint}; "
                        f"max_abs_difference={difference}"
                    )
            differences[name] = difference
        checks.append({
            "endpoint": endpoint,
            "experiment_id": exp_id,
            "old_arrays": str(old_path),
            "old_arrays_sha256": source["arrays_sha256"],
            "old_metadata": str(old_meta_path),
            "old_metadata_sha256": source["metadata_sha256"],
            "parameter_id": source["parameter_id"],
            "noise_id": source["noise_id"],
            "verified_origin_count": 2161,
            "max_absolute_differences": differences,
        })
    return {
        "schema": "regge_record_length_three_month_reproduction_v01",
        "passed": True,
        "verified_methods": 3,
        "absolute_tolerance": REPLAY_ABSOLUTE_TOLERANCE,
        "relative_tolerance": 0.0,
        "checks": checks,
        "twenty_four_month_historical_equality_required": False,
        "twenty_four_month_reason": (
            "matched three-month preparation intentionally excludes the old extra "
            "twenty-one months of flow assimilation"
        ),
    }


def assess_all(root: Path = FORMAL_OUTPUT) -> Path:
    """Run exactly 12 frozen matched-history chains, stopping after any failure."""
    root = Path(root)
    stage_paths = {
        "started": root / "assessment_started.json",
        "receipt": root / "assessment_receipt.json",
        "failed": root / "assessment_failed.json",
        "historical": root / "assessment_historical_reproduction.json",
    }
    if any(path.exists() for path in stage_paths.values()):
        raise FileExistsError("assessment stage already has an artifact and cannot overwrite it")
    if not root.is_dir():
        raise FileNotFoundError("prepared assessment root does not exist")
    destination_root = root / "assessment"
    if destination_root.exists():
        raise FileExistsError("assessment destination root already exists")
    started = time.perf_counter()
    completed = []
    current = None
    expected_specs = list(window_specs())
    try:
        write_json_new(stage_paths["started"], {
            "schema": "regge_record_length_assessment_stage_start_v01",
            "status": "started", "started_utc": _utc(),
            "ordered_experiments": [row["exp_id"] for row in expected_specs],
            "assessment_suffix": "MATCHED3",
            "retry_policy": "none",
        })
        selections = _verify_assessment_stage_inputs(root)
        dates, forcing, observations, checks = load_inputs()
        destination_root.mkdir(exist_ok=False)
        _root_event(root, "assessment_stage_started", assessment_count=12)
        for spec in expected_specs:
            current = spec["exp_id"]
            origins, _, _ = assessment_origins_for_endpoint(spec["endpoint"], dates)
            destination = destination_root / f"{current}-MATCHED3"
            _root_event(root, "assessment_method_started", experiment_id=current)
            item_started = time.perf_counter()
            result = assess_one(
                spec, selections[current], origins, destination,
                _inputs=(dates, forcing, observations, checks),
            )
            row = {
                "experiment_id": current,
                "assessment_id": f"{current}-MATCHED3",
                "valid": result.meta["valid"],
                "processed_hour_count": result.meta["processed_hour_count"],
                "completed_origins": result.meta["completed_origins"],
                "deterministic_forecast_steps": result.meta[
                    "deterministic_forecast_steps"
                ],
                "arrays_sha256": sha256(destination / "arrays.npz"),
                "metadata_sha256": sha256(destination / "metadata.json"),
                "receipt_sha256": sha256(destination / "receipt.json"),
                "elapsed_seconds": time.perf_counter() - item_started,
            }
            completed.append(row)
            _root_event(
                root, "assessment_method_completed", experiment_id=current,
                completed=len(completed), total=12,
            )
        current = None
        historical = verify_three_month_historical_reproduction(root)
        write_json_new(stage_paths["historical"], historical)
        filter_hours = sum(row["processed_hour_count"] for row in completed)
        origins = sum(row["completed_origins"] for row in completed)
        forecast_steps = sum(
            row["deterministic_forecast_steps"] for row in completed
        )
        if (len(completed) != 12 or not all(row["valid"] for row in completed)
                or filter_hours != 885600 or origins != 30256
                or forecast_steps != 3630720):
            raise RuntimeError("formal assessment completion counts differ")
        _root_event(
            root, "assessment_stage_completed", assessment_count=12,
            processed_filter_hours=filter_hours, completed_origins=origins,
        )
        write_json_new(stage_paths["receipt"], {
            "schema": "regge_record_length_assessment_stage_receipt_v01",
            "status": "complete", "passed": True,
            "assessment_count": 12,
            "valid_assessment_count": 12,
            "processed_filter_hours": filter_hours,
            "completed_origins": origins,
            "production_forecast_steps": forecast_steps,
            "state_reset_count": 0,
            "three_month_historical_reproduction_sha256": sha256(
                stage_paths["historical"],
            ),
            "completed": completed,
            "elapsed_seconds": time.perf_counter() - started,
        })
        return root
    except BaseException as error:
        failure = {
            "schema": "regge_record_length_assessment_stage_failure_v01",
            "status": "failed", "passed": False,
            "error": {"type": type(error).__name__, "reason": str(error)},
            "traceback": traceback.format_exc(),
            "failed_experiment": current,
            "completed": completed,
            "completed_count": len(completed),
            "unstarted": [
                row["exp_id"] for row in expected_specs[
                    len(completed) + (1 if current is not None else 0):
                ]
            ],
            "automatic_retry": False,
            "elapsed_seconds": time.perf_counter() - started,
        }
        if not stage_paths["failed"].exists():
            try:
                write_json_new(stage_paths["failed"], failure)
            except BaseException as receipt_error:
                error.add_note(
                    "assessment-stage failure receipt also failed: "
                    f"{type(receipt_error).__name__}: {receipt_error}"
                )
        try:
            _root_event(
                root, "assessment_stage_failed", completed=len(completed),
                failed_experiment=current, error_type=type(error).__name__,
                error=str(error),
            )
        except BaseException as event_error:
            error.add_note(
                "assessment-stage failure event also failed: "
                f"{type(event_error).__name__}: {event_error}"
            )
        raise
