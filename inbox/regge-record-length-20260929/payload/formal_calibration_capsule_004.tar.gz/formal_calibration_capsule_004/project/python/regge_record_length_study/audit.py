"""Independent ranking, deterministic-forecast, metric, and decision audit."""
from __future__ import annotations

from collections import Counter
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import time
import traceback
from typing import Mapping, Sequence

import numpy as np

from . import prepare as preparation
from .common import (
    ARCHIVE,
    FORMAL_OUTPUT,
    PROJECT,
    REPAIRED,
    array_sha256,
    read_json,
    save_npz_new,
    sha256,
    write_json_new,
)
from .contract import load_inputs, window_specs


FORECAST_HOURS = 120
RECONSTRUCTION_TOLERANCE = 1e-8
SHORT_LENGTHS = (3, 6, 12)
HISTORICAL_ROOT = (
    PROJECT / "output/regge_multiyear_validation/20260928-regge-fixed-bank-six-year-001"
)
_CHAIN_STARTS = {
    "E1": "2001-10-01T00",
    "E2": "2002-04-01T00",
    "E3": "2003-10-01T00",
}
_RECENT_PERIODS = {
    "E1": ("2002-01-01T00", "2003-01-01T00"),
    "E2": ("2002-07-01T00", "2003-07-01T00"),
    "E3": ("2004-01-01T00", "2005-01-01T00"),
}
_CHAIN_STOP = "2011-01-01T00"
_ANNUAL_PERIODS = tuple(
    (f"{year}-01-01T00", f"{year + 1}-01-01T00")
    for year in range(2005, 2011)
)
_EXPECTED_CHAIN_HOURS = {"E1": 81096, "E2": 76728, "E3": 63576}
_EXPECTED_RECENT_ORIGINS = {"E1": 360, "E2": 360, "E3": 361}
_HISTORICAL_WINDOWS = {
    "E1": "year_end_origin_one",
    "E2": "midyear_origin",
    "E3": "year_end_origin_two",
}
_REPAIRED_MANIFEST_SHA256 = (
    "ababef8cdb2e1d288b43bd15c64ba82c58879e09c551a51a21e23de1f00d8678"
)
_REPAIRED_AUDIT_SHA256 = (
    "93d4e4d6d87bebfafd9440952aee7b3736a2a862a572355afbae534a9c809d95"
)
ALL_STATUSES = (
    "pass",
    "fail",
    "numerical_boundary_uncertain",
    "reference_quality_fail",
    "invalid",
)
METRIC_COLUMNS = (
    "assessment_id",
    "endpoint",
    "months",
    "period_kind",
    "period_id",
    "lead_hour",
    "origin_count",
    "root_mean_square_error",
    "nash_efficiency",
    "mean_absolute_error",
    "reconstruction_difference",
    "root_mean_square_error_lower_bound",
    "root_mean_square_error_upper_bound",
    "reference_assessment_id",
    "reference_root_mean_square_error",
    "reference_reconstruction_difference",
    "persistence_root_mean_square_error",
    "persistence_reconstruction_difference",
    "nominal_reference_ratio",
    "nominal_persistence_ratio",
    "reference_persistence_ratio",
    "gate_method_reference",
    "gate_method_persistence",
    "gate_reference_persistence",
    "gate_status",
)
IDENTITY_COLUMNS = (
    "experiment_id",
    "assessment_id",
    "endpoint",
    "months",
    "parameter_id",
    "noise_id",
    "selection_score",
    "calibration_raw_sha256",
    "calibration_result_sha256",
    "independent_complete_rank_order_sha256",
    "independent_parameter_best_order_sha256",
)


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _event(root: Path, event: str, **fields) -> None:
    with (Path(root) / "events.jsonl").open("a", encoding="utf-8") as target:
        target.write(json.dumps(
            {"utc": _utc(), "event": event, **fields},
            ensure_ascii=False, allow_nan=False,
        ) + "\n")


def _numeric_pair(value: Sequence[float], *, positive_error: bool) -> tuple[float, float] | None:
    try:
        if len(value) != 2:
            return None
        error, difference = float(value[0]), float(value[1])
    except (TypeError, ValueError):
        return None
    if (not np.isfinite(error) or not np.isfinite(difference)
            or error < 0 or difference < 0
            or (positive_error and error <= 0)):
        return None
    return error, difference


def _bounds(value: tuple[float, float]) -> tuple[float, float]:
    error, difference = value
    return max(0.0, error - difference), error + difference


def _bounded_condition(left: tuple[float, float], factor: float,
                       right: tuple[float, float]) -> str:
    left_low, left_high = _bounds(left)
    right_low, right_high = _bounds(right)
    if left_high <= factor * right_low:
        return "pass"
    if left_low > factor * right_high:
        return "fail"
    return "uncertain"


def gate(method: tuple[float, float], reference: tuple[float, float],
         persistence: tuple[float, float]) -> dict:
    """Apply the frozen five-percent rules using reconstruction bounds."""
    checked_method = _numeric_pair(method, positive_error=False)
    checked_reference = _numeric_pair(reference, positive_error=True)
    checked_persistence = _numeric_pair(persistence, positive_error=True)
    if None in (checked_method, checked_reference, checked_persistence):
        return {
            "status": "invalid",
            "method_reference": "invalid",
            "method_persistence": "invalid",
            "reference_persistence": "invalid",
        }
    assert checked_method is not None
    assert checked_reference is not None
    assert checked_persistence is not None
    method_reference = _bounded_condition(
        checked_method, 1.05, checked_reference,
    )
    method_persistence = _bounded_condition(
        checked_method, 0.95, checked_persistence,
    )
    reference_persistence = _bounded_condition(
        checked_reference, 0.95, checked_persistence,
    )
    if reference_persistence == "fail":
        status = "reference_quality_fail"
    elif "fail" in (method_reference, method_persistence):
        status = "fail"
    elif (method_reference == "pass"
          and method_persistence == "pass"
          and reference_persistence == "pass"):
        status = "pass"
    else:
        status = "numerical_boundary_uncertain"
    method_low, method_high = _bounds(checked_method)
    reference_low, reference_high = _bounds(checked_reference)
    persistence_low, persistence_high = _bounds(checked_persistence)
    return {
        "status": status,
        "method_reference": method_reference,
        "method_persistence": method_persistence,
        "reference_persistence": reference_persistence,
        "method_lower_bound": method_low,
        "method_upper_bound": method_high,
        "reference_lower_bound": reference_low,
        "reference_upper_bound": reference_high,
        "persistence_lower_bound": persistence_low,
        "persistence_upper_bound": persistence_high,
        "nominal_reference_ratio": checked_method[0] / checked_reference[0],
        "nominal_persistence_ratio": checked_method[0] / checked_persistence[0],
        "reference_persistence_ratio": checked_reference[0] / checked_persistence[0],
    }


def metric_values(predictions: np.ndarray, truth: np.ndarray) -> dict[str, np.ndarray]:
    """Return one value per lead without hiding invalid Nash denominators."""
    predictions = np.asarray(predictions)
    truth = np.asarray(truth)
    if (predictions.shape != truth.shape or predictions.ndim != 2
            or predictions.dtype != np.float64 or truth.dtype != np.float64
            or predictions.shape[1] != FORECAST_HOURS
            or not np.isfinite(predictions).all()
            or not np.isfinite(truth).all()):
        raise ValueError("metric arrays must be aligned finite float64 forecasts")
    residual = predictions - truth
    squared = residual * residual
    rmse = np.sqrt(np.mean(squared, axis=0))
    mae = np.mean(np.abs(residual), axis=0)
    centered = truth - np.mean(truth, axis=0, keepdims=True)
    denominator = np.sum(centered * centered, axis=0)
    if np.any(denominator <= 0) or not np.isfinite(denominator).all():
        raise ValueError("Nash efficiency denominator is invalid")
    nash = 1.0 - np.sum(squared, axis=0) / denominator
    if not all(np.isfinite(values).all() for values in (rmse, mae, nash)):
        raise ValueError("one or more recomputed metrics are nonfinite")
    return {
        "root_mean_square_error": rmse,
        "mean_absolute_error": mae,
        "nash_efficiency": nash,
    }


def reconstruction_difference(production: np.ndarray,
                              reconstruction: np.ndarray) -> np.ndarray:
    production = np.asarray(production)
    reconstruction = np.asarray(reconstruction)
    if (production.shape != reconstruction.shape or production.ndim != 2
            or production.dtype != np.float64
            or reconstruction.dtype != np.float64
            or not np.isfinite(production).all()
            or not np.isfinite(reconstruction).all()):
        raise ValueError("reconstruction arrays are misaligned or nonfinite")
    return np.sqrt(np.mean((production - reconstruction) ** 2, axis=0))


def _row_rmse(predictions: np.ndarray, targets: np.ndarray,
              valid: np.ndarray) -> np.ndarray:
    predictions = np.asarray(predictions)
    targets = np.asarray(targets)
    valid = np.asarray(valid, dtype=np.bool_)
    errors = np.full((len(predictions), *predictions.shape[2:]), np.inf)
    rows = np.flatnonzero(valid)
    for start in range(0, len(rows), 128):
        batch = rows[start:start + 128]
        with np.errstate(over="ignore", invalid="ignore"):
            values = np.sqrt(np.mean(
                (predictions[batch] - targets) ** 2, axis=1,
            ))
        errors[batch] = values
    errors[~np.isfinite(errors)] = np.inf
    return errors


def _rank_joint(parameter_ids: np.ndarray, noise_ids: np.ndarray,
                errors: np.ndarray, reference: np.ndarray,
                valid: np.ndarray) -> dict:
    parameter_ids = np.asarray(parameter_ids)
    noise_ids = np.asarray(noise_ids)
    errors = np.asarray(errors)
    reference = np.asarray(reference)
    valid = np.asarray(valid, dtype=np.bool_)
    if (parameter_ids.ndim != 1 or noise_ids.shape != parameter_ids.shape
            or errors.shape != (len(parameter_ids), 4)
            or reference.shape != (4,) or valid.shape != parameter_ids.shape
            or not np.isfinite(reference).all() or np.any(reference <= 0)):
        raise ValueError("independent ranking inputs are invalid")
    scores = np.full(len(parameter_ids), np.inf, dtype=np.float64)
    scores[valid] = 0.5 * (
        errors[valid, 2] / reference[2]
        + errors[valid, 3] / reference[3]
    )
    if not np.isfinite(scores[valid]).all():
        raise ValueError("independent ranking score is nonfinite")
    order = np.asarray(sorted(
        np.flatnonzero(valid).tolist(),
        key=lambda row: (
            float(scores[row]), int(parameter_ids[row]), int(noise_ids[row]),
        ),
    ), dtype=np.int64)
    best_by_parameter: dict[int, int] = {}
    for row in order:
        best_by_parameter.setdefault(int(parameter_ids[row]), int(row))
    parameter_best = np.asarray(sorted(
        best_by_parameter.values(),
        key=lambda row: (
            float(scores[row]), int(parameter_ids[row]), int(noise_ids[row]),
        ),
    ), dtype=np.int64)
    if len(parameter_best) < 5:
        raise ValueError("fewer than five physical parameters remain valid")
    return {
        "scores": scores,
        "complete_order": order,
        "parameter_best_order": parameter_best,
        "best_row": int(parameter_best[0]),
    }


def _validate_joint_layout(shortlist: np.ndarray, parameter_ids: np.ndarray,
                           noise_ids: np.ndarray) -> None:
    shortlist = np.asarray(shortlist)
    parameter_ids = np.asarray(parameter_ids)
    noise_ids = np.asarray(noise_ids)
    if (shortlist.shape != (16,) or shortlist.dtype != np.int64
            or parameter_ids.shape != (2048,) or parameter_ids.dtype != np.int64
            or noise_ids.shape != (2048,) or noise_ids.dtype != np.int64
            or not np.array_equal(parameter_ids, np.repeat(shortlist, 128))
            or not np.array_equal(
                noise_ids, np.tile(np.arange(128, dtype=np.int64), 16),
            )):
        raise ValueError(
            "joint candidates are not the complete 16-parameter by 128-noise grid"
        )


def _validate_four_lead_targets(origins: np.ndarray,
                                targets: np.ndarray) -> None:
    origins = np.asarray(origins)
    targets = np.asarray(targets)
    expected = origins[:, None] + np.asarray([1, 24, 48, 120], dtype=np.int64)
    if (origins.ndim != 1 or origins.dtype != np.int64
            or targets.dtype != np.int64
            or targets.shape != expected.shape
            or not np.array_equal(targets, expected)):
        raise ValueError("candidate target columns are not 1, 24, 48, and 120 hours")


def _validate_selection_array_contract(arrays: Mapping[str, np.ndarray],
                                       spec: Mapping) -> None:
    """Validate every array used by the independent two-lead reconstruction."""
    hours = int(spec["hours"])
    origins = int(spec["selection_origins"])
    expected = {
        "parameter_ids": ((2048,), np.dtype("int64")),
        "parameter_values": ((2048, 5), np.dtype("float64")),
        "noise_design": ((128, 5), np.dtype("float64")),
        "calibration_observations": ((hours,), np.dtype("float64")),
        "hydrologic_predictions": ((2048, hours), np.dtype("float64")),
        "hydrologic_alive": ((2048,), np.dtype("bool")),
        "hydrologic_completed": ((2048,), np.dtype("bool")),
        "shortlist_parameter_ids": ((16,), np.dtype("int64")),
        "origin_indices": ((origins,), np.dtype("int64")),
        "target_indices": ((origins, 4), np.dtype("int64")),
        "target_observations": ((origins, 4), np.dtype("float64")),
        "persistence_predictions": ((origins, 4), np.dtype("float64")),
        "reference_errors": ((4,), np.dtype("float64")),
        "joint_parameter_ids": ((2048,), np.dtype("int64")),
        "joint_noise_ids": ((2048,), np.dtype("int64")),
        "joint_predictions": ((2048, origins, 4), np.dtype("float64")),
        "joint_alive": ((2048,), np.dtype("bool")),
        "joint_completed": ((2048,), np.dtype("bool")),
        "joint_errors": ((2048, 4), np.dtype("float64")),
        "joint_valid": ((2048,), np.dtype("bool")),
    }
    for name, (shape, dtype) in expected.items():
        values = np.asarray(arrays[name])
        if values.shape != shape or values.dtype != dtype:
            raise ValueError(
                f"selection array shape or type differs: {name}: "
                f"{values.shape}/{values.dtype}"
            )
    _validate_four_lead_targets(
        arrays["origin_indices"], arrays["target_indices"],
    )
    _validate_joint_layout(
        arrays["shortlist_parameter_ids"],
        arrays["joint_parameter_ids"], arrays["joint_noise_ids"],
    )


def _calibration_paths(root: Path, spec: Mapping) -> tuple[Path, Path]:
    if int(spec["months"]) in (6, 12):
        directory = Path(root) / "calibration" / str(spec["exp_id"])
    else:
        directory = ARCHIVE / "calibration" / (
            f"{spec['legacy_window']}__{int(spec['months'])}"
        )
    return directory / "raw.npz", directory / "result.json"


def _check_array_hash(result: Mapping, name: str, values: np.ndarray,
                      selection: Mapping) -> None:
    digest = array_sha256(values)
    metadata = result.get("array_hashes", {}).get(name)
    expected = {
        "sha256": digest,
        "dtype": str(values.dtype),
        "shape": list(values.shape),
    }
    if metadata != expected:
        raise RuntimeError(f"calibration array metadata differs: {name}")
    frozen = selection.get("source_hashes", {}).get("raw_arrays", {}).get(name)
    if frozen != digest:
        raise RuntimeError(f"frozen selection source array differs: {name}")


def _independent_selection(root: Path, spec: Mapping,
                           selection: Mapping) -> dict:
    raw_path, result_path = _calibration_paths(root, spec)
    frozen_sources = selection.get("source_hashes", {})
    if (not raw_path.is_file() or sha256(raw_path) != frozen_sources.get("raw_npz")
            or not result_path.is_file()
            or sha256(result_path) != frozen_sources.get("result_json")):
        raise RuntimeError(f"calibration source identity differs: {spec['exp_id']}")
    result = read_json(result_path)
    with np.load(raw_path, allow_pickle=False) as saved:
        required = {
            "parameter_ids", "parameter_values", "noise_design",
            "calibration_observations", "hydrologic_predictions",
            "hydrologic_alive", "hydrologic_completed",
            "shortlist_parameter_ids", "target_observations",
            "origin_indices", "target_indices", "persistence_predictions",
            "reference_errors",
            "joint_parameter_ids", "joint_noise_ids", "joint_predictions",
            "joint_alive", "joint_completed", "joint_errors", "joint_valid",
        }
        if not required.issubset(saved.files):
            raise RuntimeError(f"calibration ranking arrays are incomplete: {spec['exp_id']}")
        arrays = {name: saved[name] for name in required}
    for name, values in arrays.items():
        _check_array_hash(result, name, values, selection)

    _validate_selection_array_contract(arrays, spec)
    if selection.get("selection_leads") != [48, 120]:
        raise RuntimeError(
            f"frozen selection leads are not exactly 48 and 120 hours: {spec['exp_id']}"
        )

    if (not np.array_equal(arrays["parameter_ids"], np.arange(2048))
            or not arrays["hydrologic_completed"].all()):
        raise RuntimeError("independent parameter catalogue structure differs")
    hydrologic_errors = _row_rmse(
        arrays["hydrologic_predictions"], arrays["calibration_observations"],
        arrays["hydrologic_alive"],
    )
    finite = np.flatnonzero(np.isfinite(hydrologic_errors))
    shortlist = np.asarray(sorted(
        finite.tolist(),
        key=lambda row: (float(hydrologic_errors[row]), int(row)),
    )[:16], dtype=np.int64)
    if (len(shortlist) != 16
            or not np.array_equal(shortlist, arrays["shortlist_parameter_ids"])):
        raise RuntimeError("independent physical-parameter shortlist differs")

    truth = arrays["target_observations"]
    persistence = arrays["persistence_predictions"]
    reference = np.sqrt(np.mean((persistence - truth) ** 2, axis=0))
    if not np.array_equal(reference, arrays["reference_errors"]):
        raise RuntimeError("independent persistence errors differ")
    joint_errors = _row_rmse(
        arrays["joint_predictions"], truth,
        arrays["joint_alive"] & arrays["joint_completed"],
    )
    if not np.array_equal(joint_errors, arrays["joint_errors"]):
        raise RuntimeError("independent joint-candidate errors differ")
    valid = (
        arrays["joint_alive"] & arrays["joint_completed"]
        & np.isfinite(joint_errors).all(axis=1)
    )
    if not np.array_equal(valid, arrays["joint_valid"]):
        raise RuntimeError("independent joint-candidate validity differs")
    ranked = _rank_joint(
        arrays["joint_parameter_ids"], arrays["joint_noise_ids"],
        joint_errors, reference, valid,
    )
    row = ranked["best_row"]
    parameter_id = int(arrays["joint_parameter_ids"][row])
    noise_id = int(arrays["joint_noise_ids"][row])
    score = float(ranked["scores"][row])
    if (parameter_id != int(selection.get("parameter_id", -1))
            or noise_id != int(selection.get("noise_id", -1))
            or score != float(selection.get("score", np.nan))
            or not np.array_equal(
                arrays["parameter_values"][parameter_id],
                np.asarray(selection.get("parameter_values"), dtype=np.float64),
            )
            or not np.array_equal(
                arrays["noise_design"][noise_id],
                np.asarray(selection.get("noise_diagonal"), dtype=np.float64),
            )):
        raise RuntimeError(f"independent selected identity differs: {spec['exp_id']}")
    if (selection.get("top_16_parameter_ids") != shortlist.tolist()
            or selection.get("complete_rank_order_sha256")
            != array_sha256(ranked["complete_order"])
            or selection.get("parameter_best_rank_order_sha256")
            != array_sha256(ranked["parameter_best_order"])
            or selection.get("two_lead_scores_sha256")
            != array_sha256(ranked["scores"])):
        raise RuntimeError(f"independent selection ranking differs: {spec['exp_id']}")
    return {
        "experiment_id": spec["exp_id"],
        "endpoint": spec["endpoint"],
        "months": int(spec["months"]),
        "parameter_id": parameter_id,
        "noise_id": noise_id,
        "selection_score": score,
        "calibration_raw": str(raw_path.resolve()),
        "calibration_raw_sha256": sha256(raw_path),
        "calibration_result": str(result_path.resolve()),
        "calibration_result_sha256": sha256(result_path),
        "valid_joint_candidate_count": int(valid.sum()),
        "independent_complete_rank_order_sha256": array_sha256(
            ranked["complete_order"],
        ),
        "independent_parameter_best_order_sha256": array_sha256(
            ranked["parameter_best_order"],
        ),
    }


def _numpy_walrus_step(states: np.ndarray, forcing: np.ndarray,
                       parameters: Mapping[str, float]) -> np.ndarray:
    """Independent NumPy form of the five-state deterministic equations."""
    states = np.asarray(states, dtype=np.float64)
    forcing = np.asarray(forcing, dtype=np.float64)
    if states.ndim != 2 or states.shape[1] != 5 or forcing.shape != (len(states), 2):
        raise ValueError("independent forecast state or forcing shape differs")
    p = {name: float(parameters[name]) for name in (
        "cw", "cv", "cg", "cq", "cs", "cd", "as_", "ag", "b",
        "psi_ae", "theta_s", "zeta1", "zeta2", "exps", "min_h",
    )}
    dv0 = states[:, 0]
    dg0 = states[:, 1]
    hq0 = np.maximum(states[:, 2], 0.0)
    hs0 = states[:, 3]
    q0 = np.maximum(states[:, 4], 0.0)
    precipitation = forcing[:, 0]
    etpot = forcing[:, 1]
    wetness = 0.5 * np.cos(
        np.minimum(np.maximum(dv0, 0.0), p["cw"]) * np.pi / p["cw"]
    ) + 0.5
    equilibrium = np.zeros(len(states), dtype=np.float64)
    deep = dg0 > p["psi_ae"]
    deep_values = dg0[deep]
    equilibrium[deep] = (
        deep_values - p["psi_ae"] / (1.0 - p["b"])
        - deep_values ** (1.0 - 1.0 / p["b"])
        * p["psi_ae"] ** (1.0 / p["b"])
        / (1.0 - 1.0 / p["b"])
    ) * p["theta_s"]
    negative_groundwater = dg0 < 0.0
    equilibrium[negative_groundwater] = dg0[negative_groundwater]
    pq = precipitation * wetness * p["ag"]
    pv = precipitation * (1.0 - wetness) * p["ag"]
    ps = precipitation * p["as_"]
    beta = 0.5 * (
        1.0 - np.tanh(0.5 * p["zeta1"] * (dv0 - p["zeta2"]))
    )
    etv = etpot * beta * p["ag"]
    ets = np.where(hs0 < p["min_h"] * 1e3, 0.0, etpot * p["as_"])
    fqs = hq0 / p["cq"]
    fgs = (
        (p["cd"] - dg0 - hs0) * np.maximum(p["cd"] - dg0, hs0)
        / p["cg"]
    )
    dv = dv0 - (pv - etv - fgs) / p["ag"]
    dg = dg0 + (dv0 - equilibrium) / p["cv"]
    hq = hq0 + (pq - fqs) / p["ag"]
    hs = hs0 + (ps - ets + fgs + fqs - q0) / p["as_"]
    discharge = np.zeros(len(states), dtype=np.float64)
    channel = (hs > 0.0) & (hs <= p["cd"])
    discharge[channel] = p["cs"] * (hs[channel] / p["cd"]) ** p["exps"]
    flooded = hs > p["cd"]
    discharge[flooded] = p["cs"] + p["cs"] * (
        (hs[flooded] - p["cd"]) / p["cd"]
    ) ** p["exps"]
    active = (dv < 0.0) | (hs > p["cd"])
    pond = active & (dv < 0.0) & (hs <= p["cd"])
    hs[pond] = hs[pond] + (-dv[pond]) * p["ag"] / p["as_"]
    dv[pond] = 0.0
    flood = active & (dv >= 0.0) & (hs > p["cd"])
    dv[flood] = dv[flood] - (hs[flood] - p["cd"]) * p["as_"] / p["ag"]
    hs[flood] = p["cd"]
    both = active & (dv <= 0.0) & (hs >= p["cd"])
    dv[both] = dv[both] * p["ag"] - (hs[both] - p["cd"]) * p["as_"]
    hs[both] = p["cd"] - dv[both]
    remaining_ponding = active & (dv < 0.0)
    dg[remaining_ponding] = dv[remaining_ponding]
    invalid_surface = hs < -0.001
    invalid_quickflow = (~invalid_surface) & (hq < -0.001)
    hq[invalid_quickflow] = 0.001
    hs[invalid_surface] = 0.1
    return np.column_stack([
        dv, dg, hq, hs, np.maximum(discharge, 0.0),
    ])


def reconstruct_deterministic_forecasts(
        origin_states: np.ndarray, forecast_forcing: np.ndarray,
        parameters: Mapping[str, float]) -> tuple[np.ndarray, np.ndarray]:
    origin_states = np.asarray(origin_states)
    forecast_forcing = np.asarray(forecast_forcing)
    if (origin_states.dtype != np.float64
            or origin_states.ndim != 2 or origin_states.shape[1] != 5
            or forecast_forcing.dtype != np.float64
            or forecast_forcing.shape != (len(origin_states), FORECAST_HOURS, 2)
            or not np.isfinite(origin_states).all()
            or not np.isfinite(forecast_forcing).all()):
        raise ValueError("independent forecast inputs are invalid")
    states = origin_states.copy()
    trajectories = np.empty(
        (len(states), FORECAST_HOURS, 5), dtype=np.float64,
    )
    for lead in range(FORECAST_HOURS):
        states = _numpy_walrus_step(
            states, forecast_forcing[:, lead], parameters,
        )
        trajectories[:, lead] = states
    if not np.isfinite(trajectories).all():
        raise RuntimeError("independent deterministic forecast is nonfinite")
    return trajectories, trajectories[:, :, 4].copy()


def _period_masks(endpoint: str, codes: np.ndarray) -> list[tuple[str, str, np.ndarray]]:
    records = [("recent", f"RECENT-{endpoint}", codes == 0)]
    records.extend(
        ("annual", f"YEAR-{year}", codes == code)
        for code, year in enumerate(range(2005, 2011), start=1)
    )
    records.append(("pooled", "COMMON-2005-2010", codes > 0))
    expected = [360 if endpoint != "E3" else 361, 360, 360, 360, 361, 360, 360, 2161]
    counts = [int(mask.sum()) for _, _, mask in records]
    if counts != expected:
        raise RuntimeError(f"assessment period counts differ: {endpoint}: {counts}")
    return records


def _raw_index(dates: np.ndarray, timestamp: str) -> int:
    value = np.datetime64(timestamp, "h")
    offset = int((value - dates[0]) / np.timedelta64(1, "h"))
    if offset == len(dates) and value == dates[-1] + np.timedelta64(1, "h"):
        return offset
    if offset < 0 or offset >= len(dates) or dates[offset] != value:
        raise ValueError(f"independent raw boundary is absent: {timestamp}")
    return offset


def _independent_daily_origins(dates: np.ndarray, start: int,
                               stop: int) -> np.ndarray:
    candidates = np.arange(start, stop, dtype=np.int64)
    candidates = candidates[
        dates[candidates] == dates[candidates].astype("datetime64[D]")
    ]
    candidates = candidates[candidates + FORECAST_HOURS < stop]
    if len(candidates) and not np.array_equal(
            dates[candidates + FORECAST_HOURS],
            dates[candidates] + np.timedelta64(FORECAST_HOURS, "h")):
        raise RuntimeError("independent raw forecast targets are not continuous")
    return candidates


def _expected_assessment_source(
        endpoint: str, dates: np.ndarray, forcing: np.ndarray,
        observations: np.ndarray) -> dict[str, np.ndarray | int]:
    """Rebuild one assessment's chronology and targets from frozen raw inputs."""
    dates = np.asarray(dates)
    forcing = np.asarray(forcing)
    observations = np.asarray(observations)
    if (endpoint not in _CHAIN_STARTS or dates.ndim != 1 or len(dates) < 2
            or not np.issubdtype(dates.dtype, np.datetime64)):
        raise ValueError("independent raw date input is invalid")
    dates = dates.astype("datetime64[h]")
    if (np.isnat(dates).any()
            or np.any(np.diff(dates) != np.timedelta64(1, "h"))
            or forcing.dtype != np.float64 or forcing.shape != (len(dates), 2)
            or observations.dtype != np.float64
            or observations.shape != (len(dates),)
            or not np.isfinite(forcing).all()
            or not np.isfinite(observations).all()):
        raise ValueError("independent raw time series is misaligned or nonfinite")
    start = _raw_index(dates, _CHAIN_STARTS[endpoint])
    stop = _raw_index(dates, _CHAIN_STOP)
    recent_start, recent_stop = _RECENT_PERIODS[endpoint]
    recent = _independent_daily_origins(
        dates, _raw_index(dates, recent_start), _raw_index(dates, recent_stop),
    )
    annual = [
        _independent_daily_origins(
            dates, _raw_index(dates, period_start),
            _raw_index(dates, period_stop),
        )
        for period_start, period_stop in _ANNUAL_PERIODS
    ]
    origins = np.concatenate([recent, *annual]).astype(np.int64, copy=False)
    codes = np.concatenate([
        np.zeros(len(recent), dtype=np.int8),
        *[
            np.full(len(values), code, dtype=np.int8)
            for code, values in enumerate(annual, start=1)
        ],
    ])
    targets = origins[:, None] + np.arange(
        1, FORECAST_HOURS + 1, dtype=np.int64,
    )[None, :]
    expected_origins = _EXPECTED_RECENT_ORIGINS[endpoint] + 2161
    if (stop - start != _EXPECTED_CHAIN_HOURS[endpoint]
            or len(origins) != expected_origins
            or len(codes) != expected_origins
            or np.any(np.diff(origins) <= 0)
            or targets.max(initial=-1) >= len(dates)):
        raise RuntimeError(f"independent assessment chronology differs: {endpoint}")
    return {
        "start": start,
        "stop": stop,
        "last_valid_hour": stop - 1,
        "processed_hour_count": stop - start,
        "timestamps": dates[start:stop].copy(),
        "forcing": forcing[start:stop].copy(),
        "observations": observations[start:stop].copy(),
        "origins": origins,
        "target_indices": targets,
        "truth": observations[targets].copy(),
        "forecast_forcing": forcing[targets].copy(),
        "persistence": np.broadcast_to(
            observations[origins, None], targets.shape,
        ).copy(),
        "period_codes": codes,
    }


def _verify_assessment_arrays_against_raw(
        arrays: Mapping[str, np.ndarray], spec: Mapping,
        dates: np.ndarray, forcing: np.ndarray,
        observations: np.ndarray) -> dict[str, np.ndarray | int]:
    expected = _expected_assessment_source(
        str(spec["endpoint"]), dates, forcing, observations,
    )
    names = (
        "timestamps", "forcing", "observations", "origins", "target_indices",
        "truth", "forecast_forcing", "persistence", "period_codes",
    )
    for name in names:
        actual = np.asarray(arrays[name])
        wanted = np.asarray(expected[name])
        if (actual.shape != wanted.shape or actual.dtype != wanted.dtype
                or not np.array_equal(actual, wanted)):
            raise RuntimeError(
                f"assessment {name} differs from independently loaded raw data: "
                f"{spec['exp_id']}"
            )
    return expected


def _validate_chain_completion(
        metadata: Mapping, receipt: Mapping,
        expected: Mapping[str, np.ndarray | int], origin_count: int,
        assessment_id: str) -> dict[str, int]:
    processed = int(expected["processed_hour_count"])
    start = int(expected["start"])
    stop = int(expected["stop"])
    forecast_steps = origin_count * FORECAST_HOURS
    metadata_expected = {
        "start": start,
        "stop": stop,
        "last_valid_hour": stop - 1,
        "processed_hour_count": processed,
        "completed_origins": origin_count,
        "deterministic_forecast_steps": forecast_steps,
        "state_reset_count": 0,
    }
    receipt_expected = {
        "processed_hour_count": processed,
        "completed_origins": origin_count,
        "deterministic_forecast_steps": forecast_steps,
    }
    for name, value in metadata_expected.items():
        if metadata.get(name) != value:
            raise RuntimeError(
                f"assessment metadata completion differs: {assessment_id}: {name}"
            )
    for name, value in receipt_expected.items():
        if receipt.get(name) != value:
            raise RuntimeError(
                f"assessment receipt completion differs: {assessment_id}: {name}"
            )
    return {
        "start": start,
        "stop": stop,
        "last_valid_hour": stop - 1,
        "processed_hour_count": processed,
        "completed_origins": origin_count,
        "deterministic_forecast_steps": forecast_steps,
    }


def _load_assessment(root: Path, spec: Mapping, selection: Mapping,
                     reconstruction_root: Path, dates: np.ndarray,
                     forcing: np.ndarray, observations: np.ndarray) -> dict:
    assessment_id = f"{spec['exp_id']}-MATCHED3"
    directory = Path(root) / "assessment" / assessment_id
    arrays_path = directory / "arrays.npz"
    metadata_path = directory / "metadata.json"
    receipt_path = directory / "receipt.json"
    if not all(path.is_file() for path in (arrays_path, metadata_path, receipt_path)):
        raise FileNotFoundError(f"completed assessment is missing: {assessment_id}")
    receipt = read_json(receipt_path)
    metadata = read_json(metadata_path)
    if (receipt.get("status") != "complete" or receipt.get("passed") is not True
            or receipt.get("assessment_id") != assessment_id
            or receipt.get("experiment_id") != spec["exp_id"]
            or metadata.get("valid") is not True
            or receipt.get("files", {}).get("arrays.npz") != sha256(arrays_path)
            or receipt.get("files", {}).get("metadata.json") != sha256(metadata_path)
            or metadata.get("assessment_id") != assessment_id
            or metadata.get("experiment_id") != spec["exp_id"]
            or metadata.get("endpoint") != spec["endpoint"]
            or metadata.get("months") != int(spec["months"])
            or int(metadata.get("parameter_id", -1)) != int(selection["parameter_id"])
            or int(metadata.get("noise_id", -1)) != int(selection["noise_id"])):
        raise RuntimeError(f"assessment identity or receipt differs: {assessment_id}")
    with np.load(arrays_path, allow_pickle=False) as saved:
        required = {
            "timestamps", "forcing", "observations", "origins",
            "target_indices", "truth", "forecast_forcing", "persistence",
            "posterior_states", "posterior_covariances", "predictions",
            "period_codes",
            "selected_parameter_id", "selected_noise_id",
        }
        if not required.issubset(saved.files):
            raise RuntimeError(f"assessment arrays are incomplete: {assessment_id}")
        arrays = {name: saved[name] for name in required}
    expected = _verify_assessment_arrays_against_raw(
        arrays, spec, dates, forcing, observations,
    )
    origins = np.asarray(expected["origins"])
    rows = origins - int(expected["start"])
    if (origins.dtype != np.int64 or len(rows) == 0 or int(rows.min()) < 0
            or int(rows.max()) >= len(arrays["posterior_states"])
            or arrays["posterior_states"].dtype != np.float64
            or arrays["posterior_states"].shape
            != (int(expected["processed_hour_count"]), 5)
            or arrays["posterior_covariances"].dtype != np.float64
            or arrays["posterior_covariances"].shape
            != (int(expected["processed_hour_count"]), 5, 5)
            or arrays["truth"].dtype != np.float64
            or arrays["truth"].shape != (len(origins), FORECAST_HOURS)
            or arrays["predictions"].dtype != np.float64
            or arrays["predictions"].shape != arrays["truth"].shape
            or arrays["persistence"].dtype != np.float64
            or arrays["persistence"].shape != arrays["truth"].shape
            or arrays["forecast_forcing"].dtype != np.float64
            or arrays["forecast_forcing"].shape != (len(origins), FORECAST_HOURS, 2)
            or arrays["period_codes"].dtype != np.int8
            or arrays["period_codes"].shape != origins.shape
            or not all(np.isfinite(arrays[name]).all() for name in (
                "truth", "forecast_forcing", "persistence",
                "posterior_states", "posterior_covariances", "predictions",
            ))):
        raise RuntimeError(f"assessment array contract differs: {assessment_id}")
    if (not np.array_equal(
            arrays["selected_parameter_id"],
            np.asarray([selection["parameter_id"]], dtype=np.int64),
        ) or not np.array_equal(
            arrays["selected_noise_id"],
            np.asarray([selection["noise_id"]], dtype=np.int64),
        )):
        raise RuntimeError(f"assessment selected identity differs: {assessment_id}")
    counts = _validate_chain_completion(
        metadata, receipt, expected, len(origins), assessment_id,
    )
    if (metadata.get("forcing_sha256")
            != array_sha256(np.asarray(expected["forcing"]))
            or metadata.get("observed_flow_sha256")
            != array_sha256(np.asarray(expected["observations"]))):
        raise RuntimeError(
            f"assessment raw forcing or flow hash differs: {assessment_id}"
        )
    states, predictions = reconstruct_deterministic_forecasts(
        arrays["posterior_states"][rows],
        np.asarray(expected["forecast_forcing"]),
        selection["parameters"],
    )
    maximum = float(np.max(np.abs(predictions - arrays["predictions"])))
    if not np.isfinite(maximum) or maximum > RECONSTRUCTION_TOLERANCE:
        raise RuntimeError(
            f"independent forecast reconstruction differs: {assessment_id}; "
            f"max_abs_difference={maximum}"
        )
    reconstruction_path = reconstruction_root / f"{assessment_id}.npz"
    save_npz_new(
        reconstruction_path,
        origins=origins,
        reconstructed_forecast_states=states,
        reconstructed_predictions=predictions,
    )
    return {
        "assessment_id": assessment_id,
        "experiment_id": spec["exp_id"],
        "endpoint": spec["endpoint"],
        "months": int(spec["months"]),
        "metadata": metadata,
        "receipt": receipt,
        "completion_counts": counts,
        "origins": origins,
        "truth": np.asarray(expected["truth"]),
        "persistence": np.asarray(expected["persistence"]),
        "production": arrays["predictions"],
        "reconstruction": predictions,
        "period_codes": np.asarray(expected["period_codes"]),
        "maximum_absolute_reconstruction_difference": maximum,
        "assessment_arrays_sha256": sha256(arrays_path),
        "assessment_metadata_sha256": sha256(metadata_path),
        "assessment_receipt_sha256": sha256(receipt_path),
        "reconstruction_path": reconstruction_path,
        "reconstruction_sha256": sha256(reconstruction_path),
    }


def _preliminary_metric_rows(assessments: Sequence[dict]) -> list[dict]:
    rows: list[dict] = []
    for assessment in assessments:
        for kind, period_id, mask in _period_masks(
                assessment["endpoint"], assessment["period_codes"]):
            production = assessment["production"][mask]
            truth = assessment["truth"][mask]
            persistence = assessment["persistence"][mask]
            reconstruction = assessment["reconstruction"][mask]
            method_metrics = metric_values(production, truth)
            persistence_metrics = metric_values(persistence, truth)
            differences = reconstruction_difference(production, reconstruction)
            for lead in range(FORECAST_HOURS):
                error = float(method_metrics["root_mean_square_error"][lead])
                difference = float(differences[lead])
                rows.append({
                    "assessment_id": assessment["assessment_id"],
                    "endpoint": assessment["endpoint"],
                    "months": assessment["months"],
                    "period_kind": kind,
                    "period_id": period_id,
                    "lead_hour": lead + 1,
                    "origin_count": int(mask.sum()),
                    "root_mean_square_error": error,
                    "nash_efficiency": float(
                        method_metrics["nash_efficiency"][lead]
                    ),
                    "mean_absolute_error": float(
                        method_metrics["mean_absolute_error"][lead]
                    ),
                    "reconstruction_difference": difference,
                    "root_mean_square_error_lower_bound": max(
                        0.0, error - difference,
                    ),
                    "root_mean_square_error_upper_bound": error + difference,
                    "persistence_root_mean_square_error": float(
                        persistence_metrics["root_mean_square_error"][lead]
                    ),
                    "persistence_reconstruction_difference": 0.0,
                })
    if len(rows) != 11520:
        raise RuntimeError(f"metric-row count differs before gates: {len(rows)}")
    return rows


def _add_reference_gates(rows: list[dict]) -> None:
    references = {
        (row["endpoint"], row["period_id"], row["lead_hour"]): row
        for row in rows if row["months"] == 24
    }
    if len(references) != 3 * 8 * FORECAST_HOURS:
        raise RuntimeError("twenty-four-month reference registry is incomplete")
    for row in rows:
        reference = references[(
            row["endpoint"], row["period_id"], row["lead_hour"],
        )]
        if (row["origin_count"] != reference["origin_count"]
                or row["persistence_root_mean_square_error"]
                != reference["persistence_root_mean_square_error"]):
            raise RuntimeError("matched metric truth or persistence differs")
        decision = gate(
            (
                row["root_mean_square_error"],
                row["reconstruction_difference"],
            ),
            (
                reference["root_mean_square_error"],
                reference["reconstruction_difference"],
            ),
            (row["persistence_root_mean_square_error"], 0.0),
        )
        row.update({
            "reference_assessment_id": reference["assessment_id"],
            "reference_root_mean_square_error": reference[
                "root_mean_square_error"
            ],
            "reference_reconstruction_difference": reference[
                "reconstruction_difference"
            ],
            "nominal_reference_ratio": decision.get(
                "nominal_reference_ratio", np.nan,
            ),
            "nominal_persistence_ratio": decision.get(
                "nominal_persistence_ratio", np.nan,
            ),
            "reference_persistence_ratio": decision.get(
                "reference_persistence_ratio", np.nan,
            ),
            "gate_method_reference": decision["method_reference"],
            "gate_method_persistence": decision["method_persistence"],
            "gate_reference_persistence": decision["reference_persistence"],
            "gate_status": decision["status"],
        })
        if not all(np.isfinite(float(row[name])) for name in (
            "root_mean_square_error", "nash_efficiency", "mean_absolute_error",
            "reconstruction_difference", "root_mean_square_error_lower_bound",
            "root_mean_square_error_upper_bound", "reference_root_mean_square_error",
            "reference_reconstruction_difference",
            "persistence_root_mean_square_error",
            "persistence_reconstruction_difference",
            "nominal_reference_ratio", "nominal_persistence_ratio",
            "reference_persistence_ratio",
        )):
            raise RuntimeError("audited metric or ratio is nonfinite")


def _status_counts(rows: Sequence[Mapping]) -> dict[str, int]:
    counts = Counter(str(row["gate_status"]) for row in rows)
    unknown = set(counts) - set(ALL_STATUSES)
    if unknown:
        raise RuntimeError(f"unknown gate statuses: {sorted(unknown)}")
    return {status: int(counts.get(status, 0)) for status in ALL_STATUSES}


def _decision_summary(rows: Sequence[dict], ranking: Sequence[dict]) -> dict:
    primary_by_length = {}
    stability_by_length = {}
    endpoint_pass_counts = {}
    for months in SHORT_LENGTHS:
        primary = [
            row for row in rows
            if row["months"] == months and row["period_kind"] == "recent"
            and row["lead_hour"] in (48, 120)
        ]
        stability = [
            row for row in rows
            if row["months"] == months and row["period_kind"] == "annual"
            and row["lead_hour"] in (48, 120)
        ]
        if len(primary) != 6 or len(stability) != 36:
            raise RuntimeError("frozen decision-cell count differs")
        primary_by_length[str(months)] = {
            "cell_count": 6,
            "status_counts": _status_counts(primary),
            "all_cells_pass": all(row["gate_status"] == "pass" for row in primary),
        }
        stability_by_length[str(months)] = {
            "cell_count": 36,
            "status_counts": _status_counts(stability),
            "all_cells_pass": all(row["gate_status"] == "pass" for row in stability),
        }
        endpoints = 0
        for endpoint in ("E1", "E2", "E3"):
            cells = [row for row in primary if row["endpoint"] == endpoint]
            endpoints += int(
                len(cells) == 2
                and all(row["gate_status"] == "pass" for row in cells)
            )
        endpoint_pass_counts[str(months)] = endpoints
    primary_eligible = [
        months for months in SHORT_LENGTHS
        if primary_by_length[str(months)]["all_cells_pass"]
    ]
    stability_eligible = [
        months for months in SHORT_LENGTHS
        if stability_by_length[str(months)]["all_cells_pass"]
    ]
    identities = {}
    for months in (3, 6, 12, 24):
        selected = [row for row in ranking if row["months"] == months]
        identities[str(months)] = {
            "parameter_ids": [row["parameter_id"] for row in selected],
            "noise_ids": [row["noise_id"] for row in selected],
            "unique_parameter_count": len({row["parameter_id"] for row in selected}),
            "unique_noise_count": len({row["noise_id"] for row in selected}),
        }
    return {
        "schema": "regge_record_length_comparisons_v01",
        "primary_recent_shortest_tested_length": {
            "eligible_lengths_months": primary_eligible,
            "shortest_months": min(primary_eligible) if primary_eligible else None,
            "candidate_lengths_months": list(SHORT_LENGTHS),
            "required_cells_per_length": 6,
            "by_length": primary_by_length,
            "recent_endpoint_pass_counts_out_of_three": endpoint_pass_counts,
        },
        "secondary_yearly_stable_shortest_tested_length": {
            "eligible_lengths_months": stability_eligible,
            "shortest_months": min(stability_eligible) if stability_eligible else None,
            "candidate_lengths_months": list(SHORT_LENGTHS),
            "required_cells_per_length": 36,
            "by_length": stability_by_length,
        },
        "all_metric_row_status_counts": _status_counts(rows),
        "pooled_period_used_for_primary_or_secondary_decision": False,
        "selected_identity_stability": identities,
    }


def _write_csv_new(path: Path, fieldnames: Sequence[str], rows: Sequence[Mapping]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=fieldnames, extrasaction="raise")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def _locked_historical_records(
        *, repaired_root: Path | None = None,
        historical_root: Path | None = None) -> dict[str, dict]:
    """Independently bind the three old rank-one single-model sources."""
    repaired_root = REPAIRED if repaired_root is None else Path(repaired_root)
    historical_root = (
        HISTORICAL_ROOT if historical_root is None else Path(historical_root)
    ).resolve()
    manifest_path = repaired_root / "manifest.json"
    audit_path = repaired_root / "audit.json"
    if (sha256(manifest_path) != _REPAIRED_MANIFEST_SHA256
            or sha256(audit_path) != _REPAIRED_AUDIT_SHA256):
        raise RuntimeError("sealed historical manifest or audit hash differs")
    manifest = read_json(manifest_path)
    audit = read_json(audit_path)
    methods = audit.get("methods")
    if (manifest.get("files", {}).get("audit.json") != _REPAIRED_AUDIT_SHA256
            or audit.get("passed") is not True
            or not isinstance(methods, list)):
        raise RuntimeError("sealed historical source registry is invalid")
    locked: dict[str, dict] = {}
    used_paths: set[tuple[Path, Path]] = set()
    for endpoint, window in _HISTORICAL_WINDOWS.items():
        matches = [
            row for row in methods
            if isinstance(row, Mapping)
            and row.get("window") == window
            and row.get("kind") == "updated"
            and row.get("rank") == 1
            and row.get("method") == "independent_single_model_rank_1"
        ]
        if len(matches) != 1:
            raise RuntimeError(
                f"sealed historical source is not unique: {endpoint}"
            )
        row = matches[0]
        arrays_path = Path(str(row.get("source_arrays"))).resolve()
        metadata_path = Path(str(row.get("metadata"))).resolve()
        try:
            arrays_path.relative_to(historical_root)
            metadata_path.relative_to(historical_root)
        except ValueError as error:
            raise RuntimeError(
                f"sealed historical source leaves its fixed root: {endpoint}"
            ) from error
        pair = (arrays_path, metadata_path)
        arrays_digest = str(row.get("source_arrays_sha256"))
        metadata_digest = str(row.get("metadata_sha256"))
        if (pair in used_paths or row.get("valid") is not True
                or row.get("repaired") is not False
                or sha256(arrays_path) != arrays_digest
                or sha256(metadata_path) != metadata_digest):
            raise RuntimeError(f"sealed historical source differs: {endpoint}")
        used_paths.add(pair)
        metadata = read_json(metadata_path)
        parameter_ids = metadata.get("member_parameter_ids")
        noise_ids = metadata.get("member_noise_ids")
        arm = metadata.get("arm")
        if (metadata.get("valid") is not True
                or metadata.get("window") != window
                or metadata.get("method_kind") != "updated"
                or metadata.get("rank") != 1
                or metadata.get("forecast_form")
                != "fixed_posterior_probability_single_global_state"
                or not isinstance(arm, Mapping)
                or arm.get("name") != "independent_single_model_rank_1"
                or not isinstance(parameter_ids, list) or len(parameter_ids) != 1
                or not isinstance(noise_ids, list) or len(noise_ids) != 1
                or not isinstance(parameter_ids[0], int)
                or not isinstance(noise_ids[0], int)):
            raise RuntimeError(f"sealed historical identity differs: {endpoint}")
        locked[endpoint] = {
            "arrays_path": arrays_path,
            "metadata_path": metadata_path,
            "arrays_sha256": arrays_digest,
            "metadata_sha256": metadata_digest,
            "parameter_id": parameter_ids[0],
            "noise_id": noise_ids[0],
        }
    return locked


def _validate_historical_reproduction_record(
        historical: Mapping, locked: Mapping[str, Mapping],
        selections: Mapping[str, Mapping],
        common_origins: np.ndarray) -> dict:
    checks = historical.get("checks")
    if (historical.get("schema")
            != "regge_record_length_three_month_reproduction_v01"
            or historical.get("passed") is not True
            or historical.get("verified_methods") != 3
            or historical.get("absolute_tolerance") != RECONSTRUCTION_TOLERANCE
            or historical.get("relative_tolerance") != 0.0
            or historical.get("twenty_four_month_historical_equality_required")
            is not False
            or not isinstance(checks, list) or len(checks) != 3):
        raise RuntimeError("historical reproduction header differs")
    common_origins = np.asarray(common_origins)
    if (common_origins.dtype != np.int64 or common_origins.shape != (2161,)):
        raise RuntimeError("independent common-period origins differ")
    expected_difference_names = {
        "target_indices", "posterior_states", "posterior_covariances",
        "member_states", "member_covariances", "probabilities", "predictions",
    }
    summaries = []
    seen = set()
    for check in checks:
        endpoint = check.get("endpoint") if isinstance(check, Mapping) else None
        if endpoint not in _HISTORICAL_WINDOWS or endpoint in seen:
            raise RuntimeError("historical endpoint registry differs")
        seen.add(endpoint)
        exp_id = f"RL-{endpoint}-M03"
        source = locked[endpoint]
        selection = selections[exp_id]
        arrays_path = Path(str(check.get("old_arrays"))).resolve()
        metadata_path = Path(str(check.get("old_metadata"))).resolve()
        differences = check.get("max_absolute_differences")
        if (check.get("experiment_id") != exp_id
                or arrays_path != Path(source["arrays_path"]).resolve()
                or metadata_path != Path(source["metadata_path"]).resolve()
                or check.get("old_arrays_sha256") != source["arrays_sha256"]
                or check.get("old_metadata_sha256") != source["metadata_sha256"]
                or sha256(arrays_path) != source["arrays_sha256"]
                or sha256(metadata_path) != source["metadata_sha256"]
                or check.get("parameter_id") != source["parameter_id"]
                or check.get("noise_id") != source["noise_id"]
                or check.get("parameter_id") != selection.get("parameter_id")
                or check.get("noise_id") != selection.get("noise_id")
                or check.get("verified_origin_count") != 2161
                or not isinstance(differences, Mapping)
                or set(differences) != expected_difference_names):
            raise RuntimeError(
                f"historical source hash or identity differs: {endpoint}"
            )
        for name, value in differences.items():
            numeric = float(value)
            if (not np.isfinite(numeric) or numeric < 0
                    or numeric > RECONSTRUCTION_TOLERANCE):
                raise RuntimeError(
                    f"historical reproduction difference is invalid: {endpoint}: {name}"
                )
        with np.load(arrays_path, allow_pickle=False) as saved:
            required = {
                "origin_indices", "target_indices", "global_states",
                "global_covariances", "member_states", "member_covariances",
                "probabilities", "fixed_predictions",
            }
            if not required.issubset(saved.files):
                raise RuntimeError(
                    f"historical source arrays are incomplete: {endpoint}"
                )
            arrays = {name: saved[name] for name in required}
        expected_shapes = {
            "origin_indices": ((2161,), np.dtype("int64")),
            "target_indices": ((2161, 120), np.dtype("int64")),
            "global_states": ((2161, 5), np.dtype("float64")),
            "global_covariances": ((2161, 5, 5), np.dtype("float64")),
            "member_states": ((2161, 1, 5), np.dtype("float64")),
            "member_covariances": ((2161, 1, 5, 5), np.dtype("float64")),
            "probabilities": ((2161, 1), np.dtype("float64")),
            "fixed_predictions": ((2161, 120), np.dtype("float64")),
        }
        for name, (shape, dtype) in expected_shapes.items():
            if arrays[name].shape != shape or arrays[name].dtype != dtype:
                raise RuntimeError(
                    f"historical source array structure differs: {endpoint}: {name}"
                )
        expected_targets = common_origins[:, None] + np.arange(
            1, 121, dtype=np.int64,
        )[None, :]
        if (not np.array_equal(arrays["origin_indices"], common_origins)
                or not np.array_equal(arrays["target_indices"], expected_targets)
                or not all(np.isfinite(arrays[name]).all() for name in (
                    "global_states", "global_covariances", "member_states",
                    "member_covariances", "probabilities", "fixed_predictions",
                ))):
            raise RuntimeError(
                f"historical source chronology or numeric values differ: {endpoint}"
            )
        summaries.append({
            "endpoint": endpoint,
            "experiment_id": exp_id,
            "parameter_id": int(source["parameter_id"]),
            "noise_id": int(source["noise_id"]),
            "old_arrays_sha256": str(source["arrays_sha256"]),
            "old_metadata_sha256": str(source["metadata_sha256"]),
        })
    if seen != set(_HISTORICAL_WINDOWS):
        raise RuntimeError("historical reproduction endpoints are incomplete")
    return {
        "passed": True,
        "verified_methods": 3,
        "checks": summaries,
        "twenty_four_month_historical_equality_required": False,
    }


def _verify_historical_reproduction(
        root: Path, selections: Mapping[str, Mapping],
        common_origins: np.ndarray) -> dict:
    historical_path = Path(root) / "assessment_historical_reproduction.json"
    locked = _locked_historical_records()
    return _validate_historical_reproduction_record(
        read_json(historical_path), locked, selections, common_origins,
    )


def _verify_assessment_stage_receipt(
        root: Path, assessments: Sequence[Mapping]) -> dict[str, int]:
    receipt = read_json(Path(root) / "assessment_receipt.json")
    completed = receipt.get("completed")
    if (receipt.get("status") != "complete" or receipt.get("passed") is not True
            or receipt.get("assessment_count") != 12
            or receipt.get("valid_assessment_count") != 12
            or receipt.get("state_reset_count") != 0
            or not isinstance(completed, list) or len(completed) != 12):
        raise RuntimeError("assessment-stage completion registry differs")
    expected_ids = [spec["exp_id"] for spec in window_specs()]
    if [row.get("experiment_id") for row in completed] != expected_ids:
        raise RuntimeError("assessment-stage completion order differs")
    totals = {
        "processed_filter_hours": 0,
        "completed_origins": 0,
        "production_forecast_steps": 0,
    }
    for assessment, row in zip(assessments, completed):
        counts = assessment["completion_counts"]
        if (row.get("assessment_id") != assessment["assessment_id"]
                or row.get("valid") is not True
                or row.get("processed_hour_count")
                != counts["processed_hour_count"]
                or row.get("completed_origins") != counts["completed_origins"]
                or row.get("deterministic_forecast_steps")
                != counts["deterministic_forecast_steps"]
                or row.get("arrays_sha256")
                != assessment["assessment_arrays_sha256"]
                or row.get("metadata_sha256")
                != assessment["assessment_metadata_sha256"]
                or row.get("receipt_sha256")
                != assessment["assessment_receipt_sha256"]):
            raise RuntimeError(
                f"assessment-stage per-chain record differs: {assessment['assessment_id']}"
            )
        totals["processed_filter_hours"] += counts["processed_hour_count"]
        totals["completed_origins"] += counts["completed_origins"]
        totals["production_forecast_steps"] += counts[
            "deterministic_forecast_steps"
        ]
    if (totals != {
            "processed_filter_hours": 885600,
            "completed_origins": 30256,
            "production_forecast_steps": 3630720,
    } or any(receipt.get(name) != value for name, value in totals.items())):
        raise RuntimeError("independently summed assessment-stage counts differ")
    return totals


def _verify_stage_inputs(root: Path) -> dict:
    if Path(root).resolve() != Path(preparation.OUTPUT).resolve():
        raise ValueError("audit root differs from the prepared formal attempt")
    preparation.verify_prepared()
    if (root / "selection_failed.json").exists() or (root / "assessment_failed.json").exists():
        raise RuntimeError("failed selection or assessment coexists with audit input")
    selection_receipt = read_json(root / "selection_receipt.json")
    assessment_receipt = read_json(root / "assessment_receipt.json")
    historical_path = root / "assessment_historical_reproduction.json"
    if (selection_receipt.get("status") != "complete"
            or selection_receipt.get("passed") is not True
            or selection_receipt.get("selection_count") != 12
            or assessment_receipt.get("status") != "complete"
            or assessment_receipt.get("passed") is not True
            or assessment_receipt.get("assessment_count") != 12
            or assessment_receipt.get("valid_assessment_count") != 12
            or assessment_receipt.get("state_reset_count") != 0
            or not historical_path.is_file()
            or assessment_receipt.get(
                "three_month_historical_reproduction_sha256"
            ) != sha256(historical_path)
            ):
        raise RuntimeError("completed upstream stage identity or evidence differs")
    selections_path = root / "selections.json"
    if (selection_receipt.get("files", {}).get("selections.json")
            != sha256(selections_path)):
        raise RuntimeError("frozen selections changed before audit")
    selections = read_json(selections_path)
    expected = [spec["exp_id"] for spec in window_specs()]
    if list(selections) != expected:
        raise RuntimeError("frozen selection order differs before audit")
    return selections


def audit_all(root: Path = FORMAL_OUTPUT) -> Path:
    """Run the exclusive audit stage and seal only independently checked values."""
    root = Path(root)
    paths = {
        "started": root / "audit_started.json",
        "audit": root / "audit.json",
        "failed": root / "audit_failed.json",
        "metrics": root / "metrics_1_to_120_hours.csv",
        "comparisons": root / "comparisons.json",
        "identities": root / "selected_identities.csv",
        "reconstruction": root / "audit_reconstruction",
    }
    if any(path.exists() for path in paths.values()):
        raise FileExistsError("audit stage already has an artifact and cannot overwrite it")
    if not root.is_dir():
        raise FileNotFoundError("prepared audit root does not exist")
    started = time.perf_counter()
    completed_rankings: list[dict] = []
    completed_reconstructions: list[dict] = []
    try:
        write_json_new(paths["started"], {
            "schema": "regge_record_length_audit_start_v01",
            "status": "started",
            "started_utc": _utc(),
            "selection_count": 12,
            "assessment_count": 12,
            "retry_policy": "none",
        })
        selections = _verify_stage_inputs(root)
        dates, raw_forcing, raw_observations, raw_input_checks = load_inputs()
        _event(root, "record_length_audit_started")
        for spec in window_specs():
            check = _independent_selection(
                root, spec, selections[spec["exp_id"]],
            )
            completed_rankings.append(check)
            _event(
                root, "selection_independently_reconstructed",
                experiment_id=spec["exp_id"],
            )
        identity_rows = [{
            **{name: row[name] for name in IDENTITY_COLUMNS if name in row},
            "assessment_id": f"{row['experiment_id']}-MATCHED3",
        } for row in completed_rankings]
        _write_csv_new(paths["identities"], IDENTITY_COLUMNS, identity_rows)

        paths["reconstruction"].mkdir(exist_ok=False)
        assessments = []
        for spec in window_specs():
            assessment = _load_assessment(
                root, spec, selections[spec["exp_id"]],
                paths["reconstruction"], dates, raw_forcing,
                raw_observations,
            )
            assessments.append(assessment)
            completed_reconstructions.append({
                "assessment_id": assessment["assessment_id"],
                "origin_count": len(assessment["origins"]),
                "prediction_count": int(assessment["production"].size),
                "maximum_absolute_difference": assessment[
                    "maximum_absolute_reconstruction_difference"
                ],
                "assessment_arrays_sha256": assessment[
                    "assessment_arrays_sha256"
                ],
                "assessment_metadata_sha256": assessment[
                    "assessment_metadata_sha256"
                ],
                "assessment_receipt_sha256": assessment[
                    "assessment_receipt_sha256"
                ],
                "processed_filter_hours": assessment[
                    "completion_counts"
                ]["processed_hour_count"],
                "reconstruction_sha256": assessment["reconstruction_sha256"],
            })
            _event(
                root, "deterministic_forecast_independently_reconstructed",
                assessment_id=assessment["assessment_id"],
            )

        for endpoint in ("E1", "E2", "E3"):
            group = [row for row in assessments if row["endpoint"] == endpoint]
            if len(group) != 4:
                raise RuntimeError(f"matched endpoint assessment count differs: {endpoint}")
            for field in (
                "assimilation_start", "evaluation_start", "assimilation_stop",
                "forcing_sha256", "observed_flow_sha256",
                "common_warmup_raw_sha256", "common_warmup_states_sha256",
            ):
                if len({str(row["metadata"].get(field)) for row in group}) != 1:
                    raise RuntimeError(
                        f"matched state-preparation evidence differs: {endpoint}: {field}"
                    )
            first = group[0]
            if any(
                not np.array_equal(first["origins"], row["origins"])
                or not np.array_equal(first["truth"], row["truth"])
                or not np.array_equal(first["persistence"], row["persistence"])
                for row in group[1:]
            ):
                raise RuntimeError(f"matched evaluation arrays differ: {endpoint}")

        stage_counts = _verify_assessment_stage_receipt(root, assessments)
        common_origins = assessments[0]["origins"][
            assessments[0]["period_codes"] > 0
        ]
        historical_check = _verify_historical_reproduction(
            root, selections, common_origins,
        )

        metric_rows = _preliminary_metric_rows(assessments)
        _add_reference_gates(metric_rows)
        _write_csv_new(paths["metrics"], METRIC_COLUMNS, metric_rows)
        comparisons = _decision_summary(metric_rows, completed_rankings)
        write_json_new(paths["comparisons"], comparisons)

        total_origins = sum(len(row["origins"]) for row in assessments)
        total_filter_hours = sum(
            row["completion_counts"]["processed_hour_count"]
            for row in assessments
        )
        production_predictions = sum(row["production"].size for row in assessments)
        reconstructed_predictions = sum(
            row["reconstruction"].size for row in assessments
        )
        if (len(completed_rankings) != 12 or len(assessments) != 12
                or total_filter_hours != 885600
                or total_origins != 30256
                or production_predictions != 3630720
                or reconstructed_predictions != 3630720
                or len(metric_rows) != 11520):
            raise RuntimeError("final audit counts differ")
        historical_path = root / "assessment_historical_reproduction.json"
        _event(
            root, "record_length_audit_completed",
            metric_rows=len(metric_rows), completed_origins=total_origins,
        )
        files = {
            "metrics_1_to_120_hours.csv": sha256(paths["metrics"]),
            "comparisons.json": sha256(paths["comparisons"]),
            "selected_identities.csv": sha256(paths["identities"]),
            "assessment_historical_reproduction.json": sha256(historical_path),
            **{
                f"audit_reconstruction/{path.name}": sha256(path)
                for path in sorted(paths["reconstruction"].glob("*.npz"))
            },
        }
        audit = {
            "schema": "regge_record_length_audit_v01",
            "status": "complete",
            "passed": True,
            "selection_count": 12,
            "valid_assessment_count": 12,
            "processed_filter_hours": total_filter_hours,
            "completed_origins": total_origins,
            "production_prediction_count": production_predictions,
            "reconstructed_prediction_count": reconstructed_predictions,
            "metric_row_count": len(metric_rows),
            "scoring_nan_count": 0,
            "reconstruction_absolute_tolerance": RECONSTRUCTION_TOLERANCE,
            "maximum_absolute_reconstruction_difference": max(
                row["maximum_absolute_difference"]
                for row in completed_reconstructions
            ),
            "status_counts": comparisons["all_metric_row_status_counts"],
            "ranking_checks": completed_rankings,
            "forecast_reconstruction_checks": completed_reconstructions,
            "assessment_stage_count_check": stage_counts,
            "historical_reproduction_check": historical_check,
            "raw_input_checks": raw_input_checks,
            "evidence_levels": {
                "selection_ranking": "independently_reconstructed_from_frozen_calibration_arrays",
                "deterministic_forecast": "independently_reconstructed_with_numpy_five_state_equations",
                "three_month_historical_result": "engineering_reproduction_against_sealed_prior_result",
                "continuous_filter_history": "production_core_output_checked_for_contract_and_integrity_not_independently_reimplemented",
            },
            "twenty_four_month_old_full_history_equality_required": False,
            "pooled_period_used_for_primary_or_secondary_decision": False,
            "technical_completion_implies_positive_scientific_result": False,
            "files": files,
            "elapsed_seconds": time.perf_counter() - started,
        }
        write_json_new(paths["audit"], audit)
        return root
    except BaseException as error:
        failure = {
            "schema": "regge_record_length_audit_failure_v01",
            "status": "failed",
            "passed": False,
            "error": {"type": type(error).__name__, "reason": str(error)},
            "traceback": traceback.format_exc(),
            "completed_independent_rankings": completed_rankings,
            "completed_forecast_reconstructions": completed_reconstructions,
            "automatic_retry": False,
            "elapsed_seconds": time.perf_counter() - started,
        }
        if not paths["failed"].exists():
            try:
                write_json_new(paths["failed"], failure)
            except BaseException as receipt_error:
                error.add_note(
                    "audit failure receipt also failed: "
                    f"{type(receipt_error).__name__}: {receipt_error}"
                )
        try:
            _event(
                root, "record_length_audit_failed",
                error_type=type(error).__name__, error=str(error),
            )
        except BaseException as event_error:
            error.add_note(
                "audit failure event also failed: "
                f"{type(event_error).__name__}: {event_error}"
            )
        raise
