"""Audited-only figures, bounded conclusions, and final evidence manifest."""
from __future__ import annotations

import csv
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import time
import traceback
from typing import Mapping, Sequence

import numpy as np

from .audit import ALL_STATUSES, IDENTITY_COLUMNS, METRIC_COLUMNS
from .common import FORMAL_OUTPUT, read_json, sha256, write_json_new


FIGURE_NAMES = (
    "record_length_rmse_ratio_48_120.png",
    "ending_time_one_lead_curve.png",
    "ending_time_two_lead_curve.png",
    "ending_time_three_lead_curve.png",
    "annual_nash_efficiency_heatmap.png",
)
ENDPOINT_LABELS = {
    "E1": "结束时刻一（2002年1月）",
    "E2": "结束时刻二（2002年7月）",
    "E3": "结束时刻三（2004年1月）",
}
ENDPOINT_FILE_NAMES = {
    "E1": "ending_time_one_lead_curve.png",
    "E2": "ending_time_two_lead_curve.png",
    "E3": "ending_time_three_lead_curve.png",
}
LENGTH_COLORS = {
    3: "#000000",
    6: "#E69F00",
    12: "#56B4E9",
    24: "#009E73",
}
ENDPOINT_COLORS = {
    "E1": "#0072B2",
    "E2": "#D55E00",
    "E3": "#CC79A7",
}
REQUIRED_CHINESE_LABELS = (
    "资料长度（月）",
    "结束时刻",
    "提前时间（小时）",
    "均方根误差比（越低越好）",
    "纳什效率系数（越高越好）",
    "近期评价",
)
STATUS_LABELS = {
    "pass": "明确通过",
    "fail": "明确失败",
    "numerical_boundary_uncertain": "数值边界无法确定",
    "reference_quality_fail": "24个月参考质量失败",
    "invalid": "无效",
}
PENDING_BOUND_FILES = (
    "audit.json",
    "metrics_1_to_120_hours.csv",
    "comparisons.json",
    "selected_identities.csv",
    "report_started.json",
    "report.md",
    "figure_data_binding.json",
    "events.jsonl",
)


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _event(root: Path, event: str, **fields) -> None:
    with (Path(root) / "events.jsonl").open("a", encoding="utf-8") as target:
        target.write(json.dumps(
            {"utc": _utc(), "event": event, **fields},
            ensure_ascii=False, allow_nan=False,
        ) + "\n")


def _read_audited_rows(root: Path) -> tuple[list[dict], dict, dict, list[dict]]:
    audit_path = root / "audit.json"
    metrics_path = root / "metrics_1_to_120_hours.csv"
    comparisons_path = root / "comparisons.json"
    identities_path = root / "selected_identities.csv"
    if not all(path.is_file() for path in (
            audit_path, metrics_path, comparisons_path, identities_path)):
        raise FileNotFoundError("completed audited report inputs are missing")
    audit = read_json(audit_path)
    if (audit.get("passed") is not True or audit.get("metric_row_count") != 11520
            or audit.get("files", {}).get(metrics_path.name) != sha256(metrics_path)
            or audit.get("files", {}).get(comparisons_path.name) != sha256(comparisons_path)
            or audit.get("files", {}).get(identities_path.name) != sha256(identities_path)):
        raise RuntimeError("audited report input identity or counts differ")
    comparisons = read_json(comparisons_path)
    if comparisons.get("pooled_period_used_for_primary_or_secondary_decision") is not False:
        raise RuntimeError("pooled metrics entered a frozen shortest-length decision")
    with metrics_path.open("r", encoding="utf-8", newline="") as source:
        reader = csv.DictReader(source)
        if tuple(reader.fieldnames or ()) != METRIC_COLUMNS:
            raise RuntimeError("audited metric columns differ")
        raw_rows = list(reader)
    with identities_path.open("r", encoding="utf-8", newline="") as source:
        identity_reader = csv.DictReader(source)
        if tuple(identity_reader.fieldnames or ()) != IDENTITY_COLUMNS:
            raise RuntimeError("audited identity columns differ")
        identity_rows = list(identity_reader)
    if len(raw_rows) != 11520 or len(identity_rows) != 12:
        raise RuntimeError("audited report row counts differ")
    integer_fields = {"months", "lead_hour", "origin_count"}
    float_fields = {
        "root_mean_square_error", "nash_efficiency", "mean_absolute_error",
        "reconstruction_difference", "root_mean_square_error_lower_bound",
        "root_mean_square_error_upper_bound",
        "reference_root_mean_square_error",
        "reference_reconstruction_difference",
        "persistence_root_mean_square_error",
        "persistence_reconstruction_difference",
        "nominal_reference_ratio", "nominal_persistence_ratio",
        "reference_persistence_ratio",
    }
    rows = []
    for raw in raw_rows:
        row = dict(raw)
        for field in integer_fields:
            row[field] = int(row[field])
        for field in float_fields:
            row[field] = float(row[field])
        if (row["gate_status"] not in ALL_STATUSES
                or not all(np.isfinite(row[field]) for field in float_fields)):
            raise RuntimeError("audited report metric contains invalid values")
        rows.append(row)
    keys = [
        (row["assessment_id"], row["period_id"], row["lead_hour"])
        for row in rows
    ]
    if len(set(keys)) != 11520:
        raise RuntimeError("audited metric keys are not one-to-one")
    expected_identity_pairs = {
        (endpoint, months)
        for endpoint in ("E1", "E2", "E3")
        for months in (3, 6, 12, 24)
    }
    actual_identity_pairs = []
    experiment_ids = []
    assessment_ids = []
    for row in identity_rows:
        try:
            endpoint = row["endpoint"]
            months = int(row["months"])
            parameter_id = int(row["parameter_id"])
            noise_id = int(row["noise_id"])
            selection_score = float(row["selection_score"])
        except (KeyError, TypeError, ValueError) as error:
            raise RuntimeError("audited identity values differ") from error
        experiment_id = f"RL-{endpoint}-M{months:02d}"
        assessment_id = f"{experiment_id}-MATCHED3"
        if (row["experiment_id"] != experiment_id
                or row["assessment_id"] != assessment_id
                or parameter_id < 0 or noise_id < 0
                or not np.isfinite(selection_score)):
            raise RuntimeError("audited identity structure differs")
        actual_identity_pairs.append((endpoint, months))
        experiment_ids.append(row["experiment_id"])
        assessment_ids.append(row["assessment_id"])
    if (set(actual_identity_pairs) != expected_identity_pairs
            or len(set(actual_identity_pairs)) != 12
            or len(set(experiment_ids)) != 12
            or len(set(assessment_ids)) != 12
            or set(assessment_ids) != {row["assessment_id"] for row in rows}):
        raise RuntimeError("audited identities do not map one-to-one to metrics")
    return rows, audit, comparisons, identity_rows


def _row_key(row: Mapping) -> str:
    return "|".join((
        str(row["assessment_id"]), str(row["period_id"]),
        str(row["lead_hour"]),
    ))


def _select(rows: Sequence[dict], **criteria) -> list[dict]:
    selected = [
        row for row in rows
        if all(row.get(field) == value for field, value in criteria.items())
    ]
    return sorted(
        selected,
        key=lambda row: (
            row["endpoint"], row["months"], row["period_id"],
            row["lead_hour"],
        ),
    )


def build_figure_data_binding(rows: Sequence[dict], metrics_sha256: str) -> dict:
    """Bind every plotted mark to exactly one audited comma-separated row."""
    keys = {_row_key(row) for row in rows}
    if len(keys) != len(rows):
        raise ValueError("audited metric row keys are duplicated")
    figures = {}
    primary = [
        row for row in rows
        if row["period_kind"] == "recent" and row["lead_hour"] in (48, 120)
    ]
    if len(primary) != 24:
        raise RuntimeError("primary figure row count differs")
    figures[FIGURE_NAMES[0]] = {
        "row_keys": [_row_key(row) for row in primary],
        "plotted_fields": [
            "nominal_reference_ratio",
            "root_mean_square_error_lower_bound",
            "root_mean_square_error_upper_bound",
            "reference_root_mean_square_error",
            "reference_reconstruction_difference",
            "nash_efficiency",
        ],
        "period_scope": "recent_only",
    }
    for endpoint, filename in ENDPOINT_FILE_NAMES.items():
        selected = [
            row for row in rows
            if row["endpoint"] == endpoint and row["period_kind"] == "recent"
        ]
        if len(selected) != 4 * 120:
            raise RuntimeError(f"lead-curve row count differs: {endpoint}")
        figures[filename] = {
            "row_keys": [_row_key(row) for row in selected],
            "plotted_fields": ["nominal_reference_ratio", "nash_efficiency"],
            "period_scope": "recent_only",
        }
    annual = [
        row for row in rows
        if row["period_kind"] == "annual" and row["lead_hour"] in (48, 120)
    ]
    if len(annual) != 3 * 4 * 6 * 2:
        raise RuntimeError("annual heatmap row count differs")
    figures[FIGURE_NAMES[-1]] = {
        "row_keys": [_row_key(row) for row in annual],
        "plotted_fields": [
            "nominal_reference_ratio", "nash_efficiency", "gate_status",
        ],
        "period_scope": "annual_2005_to_2010_only",
    }
    bound_keys = [key for item in figures.values() for key in item["row_keys"]]
    if not set(bound_keys).issubset(keys):
        raise RuntimeError("one or more plotted rows lack an audited source")
    return {
        "schema": "regge_record_length_figure_data_binding_v01",
        "metrics_csv_sha256": metrics_sha256,
        "figure_count": len(figures),
        "figures": figures,
        "all_plot_rows_have_exactly_one_audited_source": True,
    }


def _configure_chinese_font():
    from matplotlib import font_manager, rcParams

    candidates = []
    supplied = os.environ.get("REGGE_CJK_FONT")
    if supplied:
        candidates.append(Path(supplied))
    candidates.extend([
        Path("C:/Windows/Fonts/simhei.ttf"),
        Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
        Path("/usr/share/fonts/opentype/noto/NotoSansCJKsc-Regular.otf"),
        Path("/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"),
    ])
    selected = next((path for path in candidates if path.is_file()), None)
    if selected is None:
        raise RuntimeError(
            "a Chinese font file is required; set REGGE_CJK_FONT to a bound file"
        )
    font_manager.fontManager.addfont(str(selected))
    prop = font_manager.FontProperties(fname=str(selected))
    rcParams["font.family"] = prop.get_name()
    rcParams["axes.unicode_minus"] = False
    return prop, selected.resolve(), sha256(selected)


def _ratio_interval(row: Mapping) -> tuple[float, float, float]:
    method_low = float(row["root_mean_square_error_lower_bound"])
    method_high = float(row["root_mean_square_error_upper_bound"])
    reference = float(row["reference_root_mean_square_error"])
    difference = float(row["reference_reconstruction_difference"])
    reference_low = max(0.0, reference - difference)
    reference_high = reference + difference
    if reference_low <= 0 or reference_high <= 0:
        raise RuntimeError("reference interval is invalid for plotting")
    return (
        float(row["nominal_reference_ratio"]),
        method_low / reference_high,
        method_high / reference_low,
    )


def _save_figure(fig, path: Path) -> None:
    fig.savefig(
        path, dpi=300, bbox_inches="tight", facecolor="white",
        metadata={"Software": "Regge record-length audited report"},
    )


def _plot_primary(rows: Sequence[dict], target: Path) -> None:
    from matplotlib import pyplot as plt

    fig, axes = plt.subplots(2, 2, figsize=(13.5, 9.5), sharex="col")
    lengths = np.asarray([3, 6, 12, 24])
    for column, lead in enumerate((48, 120)):
        for endpoint in ("E1", "E2", "E3"):
            selected = _select(
                rows, endpoint=endpoint, period_kind="recent", lead_hour=lead,
            )
            if [row["months"] for row in selected] != lengths.tolist():
                raise RuntimeError("primary figure length rows differ")
            ratios = np.asarray([_ratio_interval(row) for row in selected])
            yerr = np.vstack([
                ratios[:, 0] - ratios[:, 1],
                ratios[:, 2] - ratios[:, 0],
            ])
            axes[0, column].errorbar(
                lengths, ratios[:, 0], yerr=yerr,
                marker="o", linewidth=2, capsize=3,
                color=ENDPOINT_COLORS[endpoint], label=ENDPOINT_LABELS[endpoint],
            )
            axes[1, column].plot(
                lengths, [row["nash_efficiency"] for row in selected],
                marker="o", linewidth=2, color=ENDPOINT_COLORS[endpoint],
                label=ENDPOINT_LABELS[endpoint],
            )
        axes[0, column].axhline(1.05, color="#B2182B", linestyle="--", linewidth=1.5)
        axes[0, column].axhline(1.0, color="#666666", linestyle=":", linewidth=1)
        axes[0, column].set_title(f"近期评价：提前{lead}小时")
        axes[0, column].set_ylabel("均方根误差比（越低越好）")
        axes[0, column].grid(alpha=0.25)
        axes[1, column].axhline(0.0, color="#666666", linestyle=":", linewidth=1)
        axes[1, column].set_ylabel("纳什效率系数（越高越好）")
        axes[1, column].set_xlabel("资料长度（月）")
        axes[1, column].set_xticks(lengths)
        axes[1, column].grid(alpha=0.25)
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, title="结束时刻", loc="upper center", ncol=3,
               bbox_to_anchor=(0.5, 0.99))
    fig.suptitle(
        "不同资料长度的近期评价：误差比与纳什效率系数",
        fontsize=15, y=1.035,
    )
    fig.text(
        0.5, 0.005,
        "误差比低于1.05是必要条件；误差线表示数值重建边界，不是统计置信区间。",
        ha="center", fontsize=10,
    )
    fig.tight_layout(rect=(0, 0.035, 1, 0.95))
    _save_figure(fig, target)
    plt.close(fig)


def _plot_endpoint_curve(rows: Sequence[dict], endpoint: str, target: Path) -> None:
    from matplotlib import pyplot as plt

    fig, axes = plt.subplots(2, 1, figsize=(12.5, 9), sharex=True)
    for months in (3, 6, 12, 24):
        selected = _select(
            rows, endpoint=endpoint, months=months, period_kind="recent",
        )
        if [row["lead_hour"] for row in selected] != list(range(1, 121)):
            raise RuntimeError(f"lead curve is incomplete: {endpoint}, {months}")
        leads = np.asarray([row["lead_hour"] for row in selected])
        axes[0].plot(
            leads, [row["nominal_reference_ratio"] for row in selected],
            color=LENGTH_COLORS[months], linewidth=2,
            label=f"{months}个月",
        )
        axes[1].plot(
            leads, [row["nash_efficiency"] for row in selected],
            color=LENGTH_COLORS[months], linewidth=2,
            label=f"{months}个月",
        )
    axes[0].axhline(1.05, color="#B2182B", linestyle="--", linewidth=1.5,
                    label="误差比门槛1.05")
    axes[0].axhline(1.0, color="#666666", linestyle=":", linewidth=1)
    axes[0].set_ylabel("均方根误差比（越低越好）")
    axes[0].set_title(f"{ENDPOINT_LABELS[endpoint]}：近期评价")
    axes[0].grid(alpha=0.25)
    axes[1].axhline(0.0, color="#666666", linestyle=":", linewidth=1)
    axes[1].set_ylabel("纳什效率系数（越高越好）")
    axes[1].set_xlabel("提前时间（小时）")
    axes[1].set_xlim(1, 120)
    axes[1].set_xticks([1, 24, 48, 72, 96, 120])
    axes[1].grid(alpha=0.25)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, title="资料长度", loc="upper center", ncol=5,
               bbox_to_anchor=(0.5, 0.99))
    fig.text(
        0.5, 0.01,
        "每条线使用同一结束时刻、同一三个月状态准备和同一近期评价起报。",
        ha="center", fontsize=10,
    )
    fig.tight_layout(rect=(0, 0.035, 1, 0.94))
    _save_figure(fig, target)
    plt.close(fig)


def _two_slope_norm(values: np.ndarray, center: float):
    from matplotlib.colors import TwoSlopeNorm

    low = float(np.nanmin(values))
    high = float(np.nanmax(values))
    span = max(abs(low - center), abs(high - center), 1e-6)
    return TwoSlopeNorm(vmin=min(low, center - 0.05 * span), vcenter=center,
                        vmax=max(high, center + 0.05 * span))


def _plot_annual_heatmap(rows: Sequence[dict], target: Path) -> None:
    from matplotlib import pyplot as plt
    from matplotlib.colors import BoundaryNorm, ListedColormap
    from matplotlib.patches import Patch

    years = [f"YEAR-{year}" for year in range(2005, 2011)]
    row_specs = [
        (endpoint, months, lead)
        for endpoint in ("E1", "E2", "E3")
        for months in (3, 6, 12, 24)
        for lead in (48, 120)
    ]
    ratio = np.empty((len(row_specs), len(years)))
    nash = np.empty_like(ratio)
    status = np.empty_like(ratio, dtype=np.int64)
    status_order = {
        "pass": 0, "numerical_boundary_uncertain": 1, "fail": 2,
        "reference_quality_fail": 3, "invalid": 4,
    }
    for row_index, (endpoint, months, lead) in enumerate(row_specs):
        for column, period_id in enumerate(years):
            selected = _select(
                rows, endpoint=endpoint, months=months,
                period_kind="annual", period_id=period_id, lead_hour=lead,
            )
            if len(selected) != 1:
                raise RuntimeError("annual heatmap cell lacks one audited row")
            item = selected[0]
            ratio[row_index, column] = item["nominal_reference_ratio"]
            nash[row_index, column] = item["nash_efficiency"]
            status[row_index, column] = status_order[item["gate_status"]]
    fig, axes = plt.subplots(
        1, 3, figsize=(18, 12.5), sharey=True,
        gridspec_kw={"width_ratios": [1, 1, 0.9]},
    )
    ratio_image = axes[0].imshow(
        ratio, aspect="auto", cmap="RdYlBu_r", norm=_two_slope_norm(ratio, 1.05),
    )
    nash_image = axes[1].imshow(
        nash, aspect="auto", cmap="RdYlBu", norm=_two_slope_norm(nash, 0.0),
    )
    status_colors = ["#009E73", "#F0E442", "#D55E00", "#CC79A7", "#999999"]
    status_image = axes[2].imshow(
        status, aspect="auto", cmap=ListedColormap(status_colors),
        norm=BoundaryNorm(np.arange(-0.5, 5.5, 1), 5),
    )
    ylabels = [
        f"{ENDPOINT_LABELS[endpoint]}｜{months}个月｜提前{lead}小时"
        for endpoint, months, lead in row_specs
    ]
    for axis, title in zip(axes, (
            "均方根误差比（越低越好）",
            "纳什效率系数（越高越好）",
            "预设门槛状态",
    )):
        axis.set_title(title)
        axis.set_xticks(range(6), [str(year) for year in range(2005, 2011)])
        axis.set_xlabel("评价年份")
        axis.set_yticks(range(len(row_specs)), ylabels, fontsize=7)
        axis.set_xticks(np.arange(-0.5, 6, 1), minor=True)
        axis.set_yticks(np.arange(-0.5, len(row_specs), 1), minor=True)
        axis.grid(which="minor", color="white", linewidth=0.5)
        axis.tick_params(which="minor", bottom=False, left=False)
    for i in range(len(row_specs)):
        for j in range(6):
            axes[0].text(j, i, f"{ratio[i, j]:.2f}", ha="center", va="center", fontsize=5)
            axes[1].text(j, i, f"{nash[i, j]:.2f}", ha="center", va="center", fontsize=5)
            axes[2].text(j, i, ("过", "界", "败", "参", "无")[status[i, j]],
                         ha="center", va="center", fontsize=7)
    fig.colorbar(ratio_image, ax=axes[0], fraction=0.025, pad=0.02)
    fig.colorbar(nash_image, ax=axes[1], fraction=0.025, pad=0.02)
    axes[2].legend(
        handles=[
            Patch(facecolor=color, label=label)
            for color, label in zip(status_colors, (
                "明确通过", "数值边界无法确定", "明确失败",
                "24个月参考质量失败", "无效",
            ))
        ],
        loc="upper center", bbox_to_anchor=(0.5, -0.035), ncol=1,
        title="门槛状态",
    )
    fig.suptitle(
        "2005—2010年逐年评价：提前48与120小时",
        fontsize=15, y=0.995,
    )
    fig.tight_layout(rect=(0, 0.03, 1, 0.975))
    _save_figure(fig, target)
    plt.close(fig)


def _conclusion_phrase(months) -> str:
    if months is None:
        return "3、6、12个月中没有满足预设标准的长度"
    return f"{int(months)}个月是满足预设标准的最短已测长度"


def _write_report(path: Path, rows: Sequence[dict], audit: Mapping,
                  comparisons: Mapping, identities: Sequence[Mapping]) -> None:
    primary = comparisons["primary_recent_shortest_tested_length"]
    secondary = comparisons["secondary_yearly_stable_shortest_tested_length"]
    pooled = [
        row for row in rows
        if row["period_kind"] == "pooled" and row["lead_hour"] in (48, 120)
    ]
    lines = [
        "# 不同选参资料长度的结果",
        "",
        "## 结论",
        "",
        f"- 近期达标的最短已测长度：{_conclusion_phrase(primary['shortest_months'])}。",
        f"- 多年逐年稳定的最短已测长度：{_conclusion_phrase(secondary['shortest_months'])}。",
        "- 这两个结论彼此独立；2005—2010年六年合并结果只作描述，不参与最短长度判定。",
        "",
        "## 近期评价",
        "",
    ]
    for months in (3, 6, 12):
        passed = primary["recent_endpoint_pass_counts_out_of_three"][str(months)]
        counts = primary["by_length"][str(months)]["status_counts"]
        lines.append(
            f"- {months}个月：三个结束时刻中有{passed}/3个在48和120小时均明确通过；"
            f"6个单元状态为通过{counts['pass']}、失败{counts['fail']}、"
            f"数值边界无法确定{counts['numerical_boundary_uncertain']}、"
            f"参考质量失败{counts['reference_quality_fail']}、无效{counts['invalid']}。"
        )
    lines.extend([
        "",
        "## 2005—2010年六年合并描述",
        "",
        "| 结束时刻 | 资料长度 | 提前时间 | 均方根误差比 | 纳什效率系数 | 门槛状态 |",
        "|---|---:|---:|---:|---:|---|",
    ])
    for row in pooled:
        lines.append(
            f"| {ENDPOINT_LABELS[row['endpoint']]} | {row['months']}个月 | "
            f"{row['lead_hour']}小时 | {row['nominal_reference_ratio']:.4f} | "
            f"{row['nash_efficiency']:.4f} | {STATUS_LABELS[row['gate_status']]} |"
        )
    lines.extend([
        "",
        "## 所选参数与过程噪声",
        "",
        "| 结束时刻 | 资料长度 | 物理参数编号 | 过程噪声编号 | 48/120小时选择分数 |",
        "|---|---:|---:|---:|---:|",
    ])
    for row in identities:
        lines.append(
            f"| {ENDPOINT_LABELS[row['endpoint']]} | {int(row['months'])}个月 | "
            f"{int(row['parameter_id'])} | {int(row['noise_id'])} | "
            f"{float(row['selection_score']):.6f} |"
        )
    status = comparisons["all_metric_row_status_counts"]
    lines.extend([
        "",
        "## 数值与证据边界",
        "",
        f"- 全部11,520行中：明确通过{status['pass']}行、明确失败{status['fail']}行、"
        f"数值边界无法确定{status['numerical_boundary_uncertain']}行、"
        f"24个月参考质量失败{status['reference_quality_fail']}行、无效{status['invalid']}行。",
        f"- 生产预报与独立重建的最大绝对差为"
        f"{float(audit['maximum_absolute_reconstruction_difference']):.3e}；"
        "每个单元保存的重建均方根差已经进入误差上下界。",
        "- 排序由审核程序从率定原始数组独立重算；确定性预报由纯数值五状态方程独立重建。",
        "- 连续资料同化状态链使用生产滤波核心，审核只核对合同、完整性和历史三个月工程复现，"
        "没有用另一套滤波器重新实现整条状态链。",
        "",
        "## 适用范围",
        "",
        "- 三个结束时刻来自同一个流域，不是三个独立流域；前两个近期评价重叠六个月。",
        "- 四种资料长度在同一结束时刻共享匹配的三个月状态准备，但所选固定物理参数和过程噪声可以不同。",
        "- 每个起报使用实测未来降雨与潜在蒸散发；起报之后仍继续用观测流量更新下一次起报状态。",
        "- 本试验不比较完全交互多模型方法与不进行状态混合的方法，也不归因物理参数和过程噪声各自贡献。",
        "- 技术完成不等于科学结果为正；失败、参考质量失败和数值边界无法确定均按预设规则保留。",
        "",
    ])
    path.write_text("\n".join(lines), encoding="utf-8")


def _image_checks(path: Path) -> dict:
    from PIL import Image

    with Image.open(path) as image:
        image.load()
        array = np.asarray(image.convert("RGB"))
        width, height = image.size
    if width < 1800 or height < 1200 or array.std() <= 2:
        raise RuntimeError(f"rendered figure is empty or too small: {path.name}")
    return {
        "sha256": sha256(path),
        "width_pixels": width,
        "height_pixels": height,
        "rgb_standard_deviation": float(array.std()),
    }


def _bound_file_hashes(root: Path) -> dict[str, str]:
    files = {name: root / name for name in PENDING_BOUND_FILES}
    missing = [name for name, path in files.items() if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"pending report bound files are missing: {missing}")
    return {name: sha256(path) for name, path in files.items()}


def _verify_pending_evidence(root: Path, pending: Mapping) -> tuple[list[dict], dict]:
    if (pending.get("schema") != "regge_record_length_report_pending_inspection_v02"
            or pending.get("status") != "pending_visual_inspection"
            or pending.get("figure_count") != len(FIGURE_NAMES)
            or set(pending.get("bound_files", {})) != set(PENDING_BOUND_FILES)):
        raise RuntimeError("pending visual-inspection evidence contract differs")
    if _bound_file_hashes(root) != pending["bound_files"]:
        raise RuntimeError("report inputs or outputs changed after inspection request")
    rows, _audit, _comparisons, _identities = _read_audited_rows(root)
    current_binding = read_json(root / "figure_data_binding.json")
    recomputed_binding = build_figure_data_binding(
        rows, sha256(root / "metrics_1_to_120_hours.csv"),
    )
    if current_binding != recomputed_binding:
        raise RuntimeError("figure data binding no longer matches audited rows")
    return rows, current_binding


def _verify_staged_json(path: Path, expected: Mapping) -> None:
    if read_json(path) != dict(expected):
        raise RuntimeError(f"staged JSON verification failed: {path.name}")


def _verify_content_manifest(root: Path, manifest: Mapping) -> None:
    _verify_staged_json(root / "manifest.staging.json", manifest)
    if any(
        not (root / relative).is_file() or sha256(root / relative) != digest
        for relative, digest in manifest["files"].items()
    ):
        raise RuntimeError("content manifest hash verification failed")


def _write_seal_failure(root: Path, error: BaseException, started: float,
                        stage: str) -> None:
    failure_path = root / "report_seal_failed.json"
    if failure_path.exists():
        return
    write_json_new(failure_path, {
        "schema": "regge_record_length_report_seal_failure_v01",
        "status": "failed", "passed": False,
        "failed_utc": _utc(), "stage": stage,
        "error": {"type": type(error).__name__, "reason": str(error)},
        "traceback": traceback.format_exc(),
        "successful_receipt_exists": (root / "report_receipt.json").exists(),
        "automatic_retry": False,
        "elapsed_seconds": time.perf_counter() - started,
    })


def generate_report(root: Path = FORMAL_OUTPUT) -> Path:
    """Generate audited-only artifacts and stop for actual visual inspection."""
    root = Path(root)
    figures = root / "figures"
    outputs = [
        root / "report_started.json", root / "report.md",
        root / "figure_data_binding.json", root / "report_pending_inspection.json",
        root / "report_failed.json", root / "report_seal_failed.json",
        root / "report_receipt.json", root / "report_receipt.staging.json",
        root / "manifest.json", root / "manifest.staging.json", figures,
    ]
    if any(path.exists() for path in outputs):
        raise FileExistsError("report stage already has an artifact and cannot overwrite it")
    if not root.is_dir():
        raise FileNotFoundError("audited report root does not exist")
    started = time.perf_counter()
    try:
        write_json_new(root / "report_started.json", {
            "schema": "regge_record_length_report_start_v01",
            "status": "started", "started_utc": _utc(),
            "expected_figures": list(FIGURE_NAMES),
        })
        rows, audit, comparisons, identities = _read_audited_rows(root)
        font, font_path, font_hash = _configure_chinese_font()
        del font
        figures.mkdir(exist_ok=False)
        _plot_primary(rows, figures / FIGURE_NAMES[0])
        for endpoint, filename in ENDPOINT_FILE_NAMES.items():
            _plot_endpoint_curve(rows, endpoint, figures / filename)
        _plot_annual_heatmap(rows, figures / FIGURE_NAMES[-1])
        binding = build_figure_data_binding(
            rows, sha256(root / "metrics_1_to_120_hours.csv"),
        )
        write_json_new(root / "figure_data_binding.json", binding)
        _write_report(root / "report.md", rows, audit, comparisons, identities)
        checks = {
            name: _image_checks(figures / name) for name in FIGURE_NAMES
        }
        _event(root, "report_generated_pending_visual_inspection", figure_count=5)
        write_json_new(root / "report_pending_inspection.json", {
            "schema": "regge_record_length_report_pending_inspection_v02",
            "status": "pending_visual_inspection",
            "generated_utc": _utc(),
            "figure_count": 5,
            "figures": checks,
            "bound_files": _bound_file_hashes(root),
            "font_path": str(font_path),
            "font_sha256": font_hash,
            "required_manual_checks": [
                "legend", "line_colors", "axes", "Chinese_glyphs",
                "negative_nash_values", "threshold_1.05",
            ],
            "elapsed_seconds": time.perf_counter() - started,
        })
        return root
    except BaseException as error:
        if not (root / "report_failed.json").exists():
            try:
                write_json_new(root / "report_failed.json", {
                    "schema": "regge_record_length_report_failure_v01",
                    "status": "failed", "passed": False,
                    "error": {"type": type(error).__name__, "reason": str(error)},
                    "traceback": traceback.format_exc(),
                    "automatic_retry": False,
                    "elapsed_seconds": time.perf_counter() - started,
                })
            except BaseException as receipt_error:
                error.add_note(
                    "report failure receipt also failed: "
                    f"{type(receipt_error).__name__}: {receipt_error}"
                )
        raise


def seal_report_after_visual_inspection(
        inspection: Mapping, root: Path = FORMAL_OUTPUT) -> Path:
    """Seal the result only after a caller records inspection of all five images."""
    root = Path(root)
    pending_path = root / "report_pending_inspection.json"
    receipt_path = root / "report_receipt.json"
    manifest_path = root / "manifest.json"
    manifest_staging_path = root / "manifest.staging.json"
    receipt_staging_path = root / "report_receipt.staging.json"
    if any(path.exists() for path in (
            receipt_path, manifest_path, manifest_staging_path,
            receipt_staging_path)):
        raise FileExistsError("report is already sealed or partly sealed")
    if ((root / "report_failed.json").exists()
            or (root / "report_seal_failed.json").exists()):
        raise RuntimeError("failed report attempt cannot be sealed")
    if not pending_path.is_file():
        raise FileNotFoundError("pending visual-inspection record is missing")
    expected_checks = {
        "legend", "line_colors", "axes", "Chinese_glyphs",
        "negative_nash_values", "threshold_1.05",
    }
    if (not isinstance(inspection, Mapping)
            or inspection.get("inspector") != "Codex visual inspection"
            or set(inspection.get("checks", {})) != expected_checks
            or not all(value is True for value in inspection["checks"].values())
            or inspection.get("figures") != list(FIGURE_NAMES)
            or not str(inspection.get("note", "")).strip()):
        raise ValueError("visual inspection record is incomplete")
    started = time.perf_counter()
    stage = "verify_pending_evidence"
    try:
        pending = read_json(pending_path)
        _rows, current_binding = _verify_pending_evidence(root, pending)
        current_checks = {
            name: _image_checks(root / "figures" / name) for name in FIGURE_NAMES
        }
        if any(
            current_checks[name]["sha256"] != pending["figures"][name]["sha256"]
            for name in FIGURE_NAMES
        ):
            raise RuntimeError("one or more figures changed after inspection request")

        stage = "write_seal_event"
        _event(root, "report_visual_inspection_verified", figure_count=5)
        stage = "write_and_verify_content_manifest"
        excluded_names = {
            "manifest.json", "manifest.staging.json",
            "report_receipt.json", "report_receipt.staging.json",
            "report_seal_failed.json",
        }
        files = {
            path.relative_to(root).as_posix(): sha256(path)
            for path in sorted(root.rglob("*"))
            if path.is_file() and path.name not in excluded_names
        }
        manifest = {
            "schema": "regge_record_length_content_manifest_v02",
            "status": "content_verified",
            "is_completion_receipt": False,
            "created_utc": _utc(),
            "file_count": len(files),
            "files": files,
            "completion_marker": "report_receipt.json",
            "technical_completion_implies_positive_scientific_result": False,
        }
        write_json_new(manifest_staging_path, manifest)
        _verify_content_manifest(root, manifest)
        os.replace(manifest_staging_path, manifest_path)

        stage = "write_and_verify_success_receipt_staging"
        receipt = {
            "schema": "regge_record_length_report_receipt_v02",
            "status": "complete", "passed": True,
            "sealed_utc": _utc(),
            "visual_inspection": dict(inspection),
            "figures": current_checks,
            "manifest_sha256": sha256(manifest_path),
            "all_plotted_values_bound_to_audited_rows": current_binding.get(
                "all_plot_rows_have_exactly_one_audited_source"
            ),
            "technical_completion_implies_positive_scientific_result": False,
        }
        write_json_new(receipt_staging_path, receipt)
        _verify_staged_json(receipt_staging_path, receipt)
        if sha256(manifest_path) != receipt["manifest_sha256"]:
            raise RuntimeError("content manifest changed before final receipt")

        stage = "publish_success_receipt"
        if receipt_path.exists():
            raise FileExistsError("success receipt appeared during sealing")
        os.replace(receipt_staging_path, receipt_path)
        return root
    except BaseException as error:
        if not receipt_path.exists():
            try:
                _write_seal_failure(root, error, started, stage)
            except BaseException as failure_error:
                error.add_note(
                    "seal failure receipt also failed: "
                    f"{type(failure_error).__name__}: {failure_error}"
                )
        raise
