"""Regge record-length study package."""
