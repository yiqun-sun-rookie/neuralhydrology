"""Frozen chronology, input, covariance, and warmup-state contracts."""
from __future__ import annotations

from pathlib import Path

import numpy as np

from .common import ARCHIVE, RAW_DATA, array_sha256, read_json, sha256


RAW_DATA_SHA256 = "64e9b1b3d47655e2008dd4dbb380d7a198811dd79b0094f1632467c0e6f605fa"
ARCHIVE_MANIFEST_SHA256 = "bda9b970413173c8610e70f36619d0c3508822849b66cb5cc9f476c5f782c44a"
ARCHIVE_AUDIT_SHA256 = "9765b8e201f15b5ba620442d778e829534f07b6f53298defc0013adcd5b63c02"
FIXED_INITIAL_COVARIANCE_SHA256 = "698e8102ef20d92d092dbbb9a819a8ec3c28264ac500d25a3db73fe09dec3d09"

_ENDPOINT_NAMES = {
    "E1": "year_end_origin_one",
    "E2": "midyear_origin",
    "E3": "year_end_origin_two",
}

_WINDOW_ROWS = (
    ("E1", 3, "2001-10-01T00", "2002-01-01T00", 2208, 87),
    ("E1", 6, "2001-07-01T00", "2002-01-01T00", 4416, 179),
    ("E1", 12, "2001-01-01T00", "2002-01-01T00", 8760, 360),
    ("E1", 24, "2000-01-01T00", "2002-01-01T00", 17544, 726),
    ("E2", 3, "2002-04-01T00", "2002-07-01T00", 2184, 86),
    ("E2", 6, "2002-01-01T00", "2002-07-01T00", 4344, 176),
    ("E2", 12, "2001-07-01T00", "2002-07-01T00", 8760, 360),
    ("E2", 24, "2000-07-01T00", "2002-07-01T00", 17520, 725),
    ("E3", 3, "2003-10-01T00", "2004-01-01T00", 2208, 87),
    ("E3", 6, "2003-07-01T00", "2004-01-01T00", 4416, 179),
    ("E3", 12, "2003-01-01T00", "2004-01-01T00", 8760, 360),
    ("E3", 24, "2002-01-01T00", "2004-01-01T00", 17520, 725),
)

_STATE_PREPARATION_ROWS = (
    ("E1", "2001-10-01T00", "2002-01-01T00", 2208),
    ("E2", "2002-04-01T00", "2002-07-01T00", 2184),
    ("E3", "2003-10-01T00", "2004-01-01T00", 2208),
)

_EVALUATION_ROWS = (
    ("RECENT-E1", "recent", "E1", "2002-01-01T00", "2003-01-01T00", 360),
    ("RECENT-E2", "recent", "E2", "2002-07-01T00", "2003-07-01T00", 360),
    ("RECENT-E3", "recent", "E3", "2004-01-01T00", "2005-01-01T00", 361),
    ("YEAR-2005", "annual", None, "2005-01-01T00", "2006-01-01T00", 360),
    ("YEAR-2006", "annual", None, "2006-01-01T00", "2007-01-01T00", 360),
    ("YEAR-2007", "annual", None, "2007-01-01T00", "2008-01-01T00", 360),
    ("YEAR-2008", "annual", None, "2008-01-01T00", "2009-01-01T00", 361),
    ("YEAR-2009", "annual", None, "2009-01-01T00", "2010-01-01T00", 360),
    ("YEAR-2010", "annual", None, "2010-01-01T00", "2011-01-01T00", 360),
    ("COMMON-2005-2010", "pooled", None, "2005-01-01T00", "2011-01-01T00", 2161),
)

_WARMUP_RAW = {
    "E1": "calibration/year_end_origin_one__3/raw.npz",
    "E2": "calibration/midyear_origin__3/raw.npz",
    "E3": "calibration/year_end_origin_two__3/raw.npz",
}
_EXPECTED_FINITE_WARMUPS = {"E1": 1699, "E2": 1699, "E3": 1695}
_KNOWN_SELECTED_PARAMETERS = {
    "E1": (67, 1944),
    "E2": (1072, 1944),
    "E3": (1926, 712),
}


def window_specs() -> tuple[dict, ...]:
    """Return defensive copies of the twelve literal selection windows."""
    records = tuple(dict(
        exp_id=f"RL-{endpoint}-M{months:02d}",
        endpoint=endpoint,
        legacy_window=_ENDPOINT_NAMES[endpoint],
        months=months,
        start=start,
        stop=stop,
        hours=hours,
        selection_origins=origins,
        calibration_source="reuse" if months in (3, 24) else "new",
    ) for endpoint, months, start, stop, hours, origins in _WINDOW_ROWS)
    for record in records:
        if _hours_between(record["start"], record["stop"]) != record["hours"]:
            raise RuntimeError(f"literal window length differs: {record['exp_id']}")
        axis = np.arange(np.datetime64(record["start"], "h"),
                         np.datetime64(record["stop"], "h"), np.timedelta64(1, "h"))
        if len(complete_daily_origins(axis, 0, len(axis))) != record["selection_origins"]:
            raise RuntimeError(f"literal selection-origin count differs: {record['exp_id']}")
    return records


def state_preparation_specs() -> tuple[dict, ...]:
    """Return the common three-month observation histories for each endpoint."""
    return tuple(dict(endpoint=endpoint, start=start, stop=stop, hours=hours,
                      source_exp_id=f"RL-{endpoint}-M03")
                 for endpoint, start, stop, hours in _STATE_PREPARATION_ROWS)


def evaluation_period_specs() -> tuple[dict, ...]:
    """Return three recent, six annual, and one pooled evaluation period."""
    return tuple(dict(period_id=period_id, kind=kind, endpoint=endpoint,
                      start=start, stop=stop, origin_count=count)
                 for period_id, kind, endpoint, start, stop, count in _EVALUATION_ROWS)


def fixed_initial_covariance() -> np.ndarray:
    """Return a new copy of the frozen five-state initial covariance."""
    initial_state = np.asarray([140.0, 1000.0, 4.0, 1200.0, 0.1], dtype=np.float64)
    covariance = np.diag((0.001 * initial_state) ** 2)
    if array_sha256(covariance) != FIXED_INITIAL_COVARIANCE_SHA256:
        raise RuntimeError("fixed initial covariance differs")
    return covariance


def _hours_between(start: str, stop: str) -> int:
    return int((np.datetime64(stop, "h") - np.datetime64(start, "h")) / np.timedelta64(1, "h"))


def validate_hour_axis(timestamps: np.ndarray) -> np.ndarray:
    values = np.asarray(timestamps)
    if values.ndim != 1 or not np.issubdtype(values.dtype, np.datetime64):
        raise ValueError("timestamps must be a one-dimensional datetime array")
    hours = values.astype("datetime64[h]")
    if np.isnat(hours).any() or np.any(values != hours):
        raise ValueError("timestamps must be finite exact hours")
    if len(hours) > 1 and np.any(np.diff(hours) != np.timedelta64(1, "h")):
        raise ValueError("hourly axis has gaps or duplicates")
    return hours


def index_at(dates: np.ndarray, timestamp: str) -> int:
    hours = validate_hour_axis(dates)
    value = np.datetime64(timestamp, "h")
    offset = int((value - hours[0]) / np.timedelta64(1, "h"))
    if offset == len(hours) and value == hours[-1] + np.timedelta64(1, "h"):
        return offset
    if offset < 0 or offset >= len(hours) or hours[offset] != value:
        raise ValueError(f"missing time boundary: {timestamp}")
    return offset


def complete_daily_origins(dates: np.ndarray, start: int, stop: int) -> np.ndarray:
    """Midnight origins whose complete 1--120 hour target is within bounds."""
    hours = validate_hour_axis(dates)
    if not (0 <= start < stop <= len(hours)):
        raise ValueError("invalid origin bounds")
    candidates = np.arange(start, stop, dtype=np.int64)
    midnight = hours[candidates] == hours[candidates].astype("datetime64[D]")
    candidates = candidates[midnight]
    candidates = candidates[candidates + 120 < stop]
    if len(candidates) and np.any(hours[candidates + 120] != hours[candidates] + np.timedelta64(120, "h")):
        raise ValueError("origin targets are not continuous")
    return candidates


def origin_arrays(dates: np.ndarray) -> dict[str, np.ndarray]:
    """Build and validate every selection and evaluation origin array."""
    hours = validate_hour_axis(dates)
    arrays: dict[str, np.ndarray] = {}
    for spec in window_specs():
        start, stop = index_at(hours, spec["start"]), index_at(hours, spec["stop"])
        found = complete_daily_origins(hours, start, stop)
        if len(found) != spec["selection_origins"]:
            raise RuntimeError(f"selection origins differ: {spec['exp_id']}")
        arrays[f"selection_{spec['exp_id'].replace('-', '_')}"] = found
    annual_arrays = []
    for spec in evaluation_period_specs():
        start, stop = index_at(hours, spec["start"]), index_at(hours, spec["stop"])
        if spec["kind"] == "pooled":
            found = np.concatenate(annual_arrays)
        else:
            found = complete_daily_origins(hours, start, stop)
            if spec["kind"] == "annual":
                annual_arrays.append(found)
        if len(found) != spec["origin_count"]:
            raise RuntimeError(f"evaluation origins differ: {spec['period_id']}")
        arrays[f"evaluation_{spec['period_id'].replace('-', '_')}"] = found
    return arrays


def _verified_archive_manifest() -> dict:
    manifest_path = ARCHIVE / "manifest.json"
    audit_path = ARCHIVE / "audit.json"
    if sha256(manifest_path) != ARCHIVE_MANIFEST_SHA256:
        raise RuntimeError("archived calibration manifest changed")
    if sha256(audit_path) != ARCHIVE_AUDIT_SHA256:
        raise RuntimeError("archived calibration audit changed")
    if read_json(audit_path).get("passed") is not True:
        raise RuntimeError("archived calibration audit did not pass")
    return read_json(manifest_path)


def common_warmup_state_masks() -> dict[str, np.ndarray]:
    """Return finite-state qualification masks from the three bound raw arrays."""
    manifest = _verified_archive_manifest()
    files = manifest.get("files", {})
    masks: dict[str, np.ndarray] = {}
    for endpoint, relative in _WARMUP_RAW.items():
        path = ARCHIVE / relative
        expected = files.get(relative)
        if not isinstance(expected, str) or sha256(path) != expected:
            raise RuntimeError(f"archived warmup array changed: {endpoint}")
        with np.load(path, allow_pickle=False) as saved:
            required = {"parameter_ids", "warmup_states", "warmup_completed"}
            if not required.issubset(saved.files):
                raise RuntimeError(f"archived warmup fields missing: {endpoint}")
            parameter_ids = saved["parameter_ids"]
            states = saved["warmup_states"]
            completed = saved["warmup_completed"]
        if parameter_ids.shape != (2048,) or not np.array_equal(parameter_ids, np.arange(2048)):
            raise RuntimeError(f"archived parameter identity differs: {endpoint}")
        if states.shape != (2048, 5) or completed.shape != (2048,):
            raise RuntimeError(f"archived warmup shape differs: {endpoint}")
        if completed.dtype != np.bool_ or not completed.all():
            raise RuntimeError(f"archived warmup completion differs: {endpoint}")
        mask = completed & np.isfinite(states).all(axis=1)
        if int(mask.sum()) != _EXPECTED_FINITE_WARMUPS[endpoint]:
            raise RuntimeError(f"finite warmup count differs: {endpoint}")
        if not all(mask[parameter_id] for parameter_id in _KNOWN_SELECTED_PARAMETERS[endpoint]):
            raise RuntimeError(f"known selected parameter lacks a finite warmup: {endpoint}")
        masks[endpoint] = mask.copy()
    return masks


def load_inputs() -> tuple[np.ndarray, np.ndarray, np.ndarray, dict]:
    """Load the complete input record and verify the frozen historical prefix."""
    from imm_da import data_loader

    if sha256(RAW_DATA) != RAW_DATA_SHA256:
        raise RuntimeError("raw Regge input changed")
    raw = data_loader.load_peq_data(str(RAW_DATA), 1999010101, 2010123123)
    if raw.empty or not np.isfinite(raw.to_numpy(dtype=float)).all():
        raise ValueError("raw Regge input is empty or nonfinite")
    cumulative, rain, evaporation, discharge = data_loader.load_and_preprocess(
        str(RAW_DATA), 1999010101, 2010123123
    )
    dates = validate_hour_axis(cumulative.output_date[:-1].astype("datetime64[s]"))
    if (dates.shape != (105191,) or dates[0] != np.datetime64("1999-01-01T01", "h")
            or dates[-1] != np.datetime64("2010-12-31T23", "h")):
        raise RuntimeError("full Regge time axis differs")
    forcing = np.stack((rain, evaporation), axis=-1).astype(np.float64)
    flow = np.asarray(discharge, dtype=np.float64)
    if forcing.shape != (len(dates), 2) or flow.shape != (len(dates),):
        raise RuntimeError("full Regge inputs have unexpected shapes")
    for actual, field in ((rain, "P"), (evaporation, "ETpot"), (flow, "Q")):
        if not np.allclose(actual, raw[field].to_numpy(), rtol=0, atol=1e-10):
            raise RuntimeError(f"legacy preprocessing differs from raw {field}")
    frozen_path = ARCHIVE / "inputs.npz"
    manifest = _verified_archive_manifest()
    expected = manifest.get("files", {}).get("inputs.npz")
    if not isinstance(expected, str) or sha256(frozen_path) != expected:
        raise RuntimeError("archived input array changed")
    with np.load(frozen_path, allow_pickle=False) as saved:
        old_dates = saved["timestamps"].astype("datetime64[h]")
        old_forcing = saved["forcing"]
        old_flow = saved["observations"]
    prefix = len(old_dates)
    if prefix != 52607 or not np.array_equal(dates[:prefix], old_dates):
        raise RuntimeError("archived timestamp prefix differs")
    if not np.array_equal(forcing[:prefix], old_forcing) or not np.array_equal(flow[:prefix], old_flow):
        raise RuntimeError("archived forcing or flow prefix differs")
    return dates, forcing, flow, dict(
        raw_data_sha256=RAW_DATA_SHA256,
        archived_inputs_sha256=expected,
        archived_prefix_hours=prefix,
        archived_prefix_exact=True,
        full_hours=len(dates),
    )
