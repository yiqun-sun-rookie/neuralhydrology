"""Reconstruct calibration rankings and freeze all selected identities."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import json
from pathlib import Path
import time
import traceback
from typing import Mapping

import numpy as np

from . import prepare as preparation
from .calibration import missing_calibration_specs
from .common import (
    ARCHIVE,
    FORMAL_OUTPUT,
    array_sha256,
    read_json,
    sha256,
    write_json_new,
)
from .contract import (
    ARCHIVE_AUDIT_SHA256,
    ARCHIVE_MANIFEST_SHA256,
    common_warmup_state_masks,
    window_specs,
)


ALLOWED_CALIBRATION_ARRAYS = frozenset({
    "parameter_values", "parameter_ids", "noise_design", "warmup_timestamps",
    "warmup_forcing", "calibration_timestamps", "calibration_forcing",
    "calibration_observations", "calibration_indices", "hydrologic_predictions",
    "warmup_states", "hydrologic_alive", "hydrologic_completed",
    "hydrologic_last_states", "warmup_completed", "hydrologic_valid",
    "hydrologic_prediction_mask", "hydrologic_errors", "shortlist_parameter_ids",
    "origin_indices", "target_indices", "origin_timestamps", "target_timestamps",
    "target_observations", "persistence_predictions", "persistence_mask",
    "reference_errors", "joint_parameter_ids", "joint_noise_ids",
    "joint_predictions", "joint_origin_global_states", "joint_origin_probabilities",
    "joint_valid", "joint_alive", "joint_completed", "joint_last_member_states",
    "joint_last_member_covariances", "joint_last_probabilities",
    "joint_prediction_mask", "joint_errors", "joint_scores", "joint_rank_order",
})

_DTYPES = {
    "parameter_values": "float64", "parameter_ids": "int64", "noise_design": "float64",
    "warmup_timestamps": "datetime64[h]", "warmup_forcing": "float64",
    "calibration_timestamps": "datetime64[h]", "calibration_forcing": "float64",
    "calibration_observations": "float64", "calibration_indices": "int64",
    "hydrologic_predictions": "float64", "warmup_states": "float64",
    "hydrologic_alive": "bool", "hydrologic_completed": "bool",
    "hydrologic_last_states": "float64", "warmup_completed": "bool",
    "hydrologic_valid": "bool", "hydrologic_prediction_mask": "bool",
    "hydrologic_errors": "float64", "shortlist_parameter_ids": "int64",
    "origin_indices": "int64", "target_indices": "int64",
    "origin_timestamps": "datetime64[h]", "target_timestamps": "datetime64[h]",
    "target_observations": "float64", "persistence_predictions": "float64",
    "persistence_mask": "bool", "reference_errors": "float64",
    "joint_parameter_ids": "int64", "joint_noise_ids": "int64",
    "joint_predictions": "float64", "joint_origin_global_states": "float64",
    "joint_origin_probabilities": "float64", "joint_valid": "bool",
    "joint_alive": "bool", "joint_completed": "bool",
    "joint_last_member_states": "float64",
    "joint_last_member_covariances": "float64",
    "joint_last_probabilities": "float64", "joint_prediction_mask": "bool",
    "joint_errors": "float64", "joint_scores": "float64",
    "joint_rank_order": "int64",
}

_RANK_ARRAYS = frozenset({
    "parameter_values", "parameter_ids", "noise_design", "warmup_timestamps",
    "calibration_timestamps", "calibration_observations", "calibration_indices",
    "hydrologic_predictions", "warmup_states", "hydrologic_alive",
    "hydrologic_completed", "warmup_completed", "hydrologic_valid",
    "hydrologic_prediction_mask", "hydrologic_errors", "shortlist_parameter_ids",
    "origin_indices", "target_indices", "origin_timestamps", "target_timestamps",
    "target_observations", "persistence_predictions", "persistence_mask",
    "reference_errors", "joint_parameter_ids", "joint_noise_ids",
    "joint_predictions", "joint_valid", "joint_alive", "joint_completed",
    "joint_prediction_mask", "joint_errors", "joint_scores", "joint_rank_order",
})

_SOURCE_ARRAY_NAMES = (
    "parameter_values", "noise_design", "warmup_forcing", "calibration_forcing",
    "calibration_observations", "calibration_timestamps",
)

_ARCHIVE_DIRECTORIES = {
    ("E1", 3): "year_end_origin_one__3",
    ("E1", 24): "year_end_origin_one__24",
    ("E2", 3): "midyear_origin__3",
    ("E2", 24): "midyear_origin__24",
    ("E3", 3): "year_end_origin_two__3",
    ("E3", 24): "year_end_origin_two__24",
}


@dataclass(frozen=True)
class _CalibrationSource:
    spec: dict
    directory: Path
    raw_path: Path
    result_path: Path
    raw_sha256: str
    result_sha256: str
    source_kind: str
    receipt_sha256: str | None = None
    process_sha256: str | None = None


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _event(root: Path, event: str, **fields) -> None:
    with (Path(root) / "events.jsonl").open("a", encoding="utf-8") as target:
        target.write(json.dumps(
            {"utc": _utc(), "event": event, **fields},
            ensure_ascii=False, allow_nan=False,
        ) + "\n")


def _validate_allowed_keys(keys) -> None:
    names = set(keys)
    unknown = names - ALLOWED_CALIBRATION_ARRAYS
    if unknown:
        raise ValueError(f"forbidden selection inputs: {sorted(unknown)}")
    missing = ALLOWED_CALIBRATION_ARRAYS - names
    if missing:
        raise ValueError(f"incomplete calibration arrays: {sorted(missing)}")


def _expected_shapes(spec: dict) -> dict[str, tuple[int, ...]]:
    hours = int(spec["hours"])
    origins = int(spec["selection_origins"])
    warmup_hours = int(
        (np.datetime64(spec["start"], "h") - np.datetime64("1999-01-01T01", "h"))
        / np.timedelta64(1, "h")
    )
    parameters, noises, shortlist, joint, leads = 2048, 128, 16, 2048, 4
    return {
        "parameter_values": (parameters, 5), "parameter_ids": (parameters,),
        "noise_design": (noises, 5), "warmup_timestamps": (warmup_hours,),
        "warmup_forcing": (warmup_hours, 2), "calibration_timestamps": (hours,),
        "calibration_forcing": (hours, 2), "calibration_observations": (hours,),
        "calibration_indices": (hours,), "hydrologic_predictions": (parameters, hours),
        "warmup_states": (parameters, 5), "hydrologic_alive": (parameters,),
        "hydrologic_completed": (parameters,), "hydrologic_last_states": (parameters, 5),
        "warmup_completed": (parameters,), "hydrologic_valid": (parameters,),
        "hydrologic_prediction_mask": (parameters, hours),
        "hydrologic_errors": (parameters,), "shortlist_parameter_ids": (shortlist,),
        "origin_indices": (origins,), "target_indices": (origins, leads),
        "origin_timestamps": (origins,), "target_timestamps": (origins, leads),
        "target_observations": (origins, leads),
        "persistence_predictions": (origins, leads), "persistence_mask": (origins, leads),
        "reference_errors": (leads,), "joint_parameter_ids": (joint,),
        "joint_noise_ids": (joint,), "joint_predictions": (joint, origins, leads),
        "joint_origin_global_states": (joint, origins, 5),
        "joint_origin_probabilities": (joint, origins, 1), "joint_valid": (joint,),
        "joint_alive": (joint,), "joint_completed": (joint,),
        "joint_last_member_states": (joint, 1, 5),
        "joint_last_member_covariances": (joint, 1, 5, 5),
        "joint_last_probabilities": (joint, 1),
        "joint_prediction_mask": (joint, origins, leads), "joint_errors": (joint, leads),
        "joint_scores": (joint,),
    }


def _array_names(raw: Mapping[str, np.ndarray]) -> set[str]:
    if hasattr(raw, "files"):
        return set(raw.files)
    return set(raw)


def _validate_arrays_and_cache(raw, result: dict, spec: dict) -> tuple[dict, dict[str, str]]:
    names = _array_names(raw)
    _validate_allowed_keys(names)
    metadata = result.get("array_hashes")
    if not isinstance(metadata, dict) or set(metadata) != ALLOWED_CALIBRATION_ARRAYS:
        raise ValueError("calibration array metadata is incomplete or contains extra keys")
    shapes = _expected_shapes(spec)
    cache: dict[str, np.ndarray] = {}
    hashes: dict[str, str] = {}
    for name in sorted(ALLOWED_CALIBRATION_ARRAYS):
        values = np.asarray(raw[name])
        if str(values.dtype) != _DTYPES[name]:
            raise ValueError(f"calibration array dtype differs: {name}")
        if name == "joint_rank_order":
            if values.ndim != 1 or len(values) > 2048:
                raise ValueError("calibration rank-order shape differs")
        elif values.shape != shapes[name]:
            raise ValueError(f"calibration array shape differs: {name}")
        digest = array_sha256(values)
        expected = metadata[name]
        if not isinstance(expected, dict) or expected != {
            "sha256": digest,
            "dtype": str(values.dtype),
            "shape": list(values.shape),
        }:
            raise ValueError(f"calibration array hash, shape, or dtype differs: {name}")
        hashes[name] = digest
        if name in _RANK_ARRAYS:
            cache[name] = values
    return cache, hashes


def _rmse_errors(predictions: np.ndarray, targets: np.ndarray,
                 valid: np.ndarray) -> np.ndarray:
    """Reproduce the frozen row-wise error arithmetic with bounded memory."""
    predictions = np.asarray(predictions)
    targets = np.asarray(targets)
    valid = np.asarray(valid, dtype=np.bool_)
    errors = np.full((len(predictions), *predictions.shape[2:]), np.inf, dtype=np.float64)
    rows = np.flatnonzero(valid)
    for start in range(0, len(rows), 128):
        batch = rows[start:start + 128]
        try:
            with np.errstate(over="raise", invalid="raise"):
                errors[batch] = np.sqrt(
                    np.mean((predictions[batch] - targets) ** 2, axis=1)
                )
        except FloatingPointError:
            for row in batch:
                try:
                    with np.errstate(over="raise", invalid="raise"):
                        errors[row] = np.sqrt(
                            np.mean((predictions[row] - targets) ** 2, axis=0)
                        )
                except FloatingPointError:
                    pass
    return errors


def _all_lead_scores(errors: np.ndarray, reference: np.ndarray) -> np.ndarray:
    scores = np.full(len(errors), np.inf, dtype=np.float64)
    for row in np.flatnonzero(np.isfinite(errors).all(axis=1)):
        try:
            with np.errstate(over="raise", invalid="raise", divide="raise"):
                scores[row] = (errors[row] / reference).mean()
        except FloatingPointError:
            pass
    return scores


def _ordered_rows(parameter_ids: np.ndarray, noise_ids: np.ndarray,
                  scores: np.ndarray, valid: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    order = np.asarray(sorted(
        np.flatnonzero(valid).tolist(),
        key=lambda row: (
            float(scores[row]), int(parameter_ids[row]), int(noise_ids[row]),
        ),
    ), dtype=np.int64)
    best_by_parameter: dict[int, int] = {}
    for row in order:
        best_by_parameter.setdefault(int(parameter_ids[row]), int(row))
    parameter_best = np.asarray(sorted(
        best_by_parameter.values(),
        key=lambda row: (
            float(scores[row]), int(parameter_ids[row]), int(noise_ids[row]),
        ),
    ), dtype=np.int64)
    return order, parameter_best


def _rank_two_lead(parameter_ids: np.ndarray, noise_ids: np.ndarray,
                   errors: np.ndarray, reference_errors: np.ndarray,
                   original_valid: np.ndarray) -> dict:
    """Rank only by 48 and 120 hours; no evaluation-state mask is accepted."""
    parameter_ids = np.asarray(parameter_ids)
    noise_ids = np.asarray(noise_ids)
    errors = np.asarray(errors, dtype=np.float64)
    reference = np.asarray(reference_errors, dtype=np.float64)
    valid = np.asarray(original_valid, dtype=np.bool_)
    if parameter_ids.ndim != 1 or noise_ids.shape != parameter_ids.shape:
        raise ValueError("candidate identity arrays are misaligned")
    if errors.shape != (len(parameter_ids), 4) or valid.shape != parameter_ids.shape:
        raise ValueError("candidate error arrays are misaligned")
    if not np.issubdtype(parameter_ids.dtype, np.integer) or not np.issubdtype(noise_ids.dtype, np.integer):
        raise ValueError("candidate identifiers must be integers")
    if (np.any(parameter_ids < 0) or np.any(noise_ids < 0)
            or len(set(zip(parameter_ids.tolist(), noise_ids.tolist()))) != len(parameter_ids)):
        raise ValueError("candidate identifiers are invalid or duplicated")
    if reference.shape != (4,) or not np.isfinite(reference).all() or np.any(reference <= 0):
        raise ValueError("persistence errors are invalid")
    if not np.isfinite(errors[valid]).all() or np.any(errors[valid] < 0):
        raise ValueError("a valid candidate has an invalid error")
    scores = np.full(len(parameter_ids), np.inf, dtype=np.float64)
    with np.errstate(over="raise", divide="raise", invalid="raise"):
        scores[valid] = 0.5 * (
            errors[valid, 2] / reference[2]
            + errors[valid, 3] / reference[3]
        )
    if not np.isfinite(scores[valid]).all():
        raise ValueError("two-lead selection score is nonfinite")
    order, parameter_best = _ordered_rows(
        parameter_ids, noise_ids, scores, valid,
    )
    if len(parameter_best) < 5:
        raise ValueError("fewer than five physical parameters have a valid process noise")
    return {
        "scores": scores,
        "complete_order": order,
        "parameter_best_rows": parameter_best,
        "best_row": int(parameter_best[0]),
    }


def _validate_result_header(result: dict, spec: dict) -> None:
    if (result.get("status") != "complete" or result.get("partial") is not False
            or result.get("phase") != "complete" or result.get("selection_failure") is not None):
        raise ValueError(f"calibration result is not complete: {spec['exp_id']}")
    if result.get("leads") != [1, 24, 48, 120]:
        raise ValueError("calibration lead order differs")
    window = result.get("window")
    if not isinstance(window, dict):
        raise ValueError("calibration window metadata is absent")
    if (window.get("calibration_start") != spec["start"]
            or window.get("calibration_stop") != spec["stop"]
            or int(window.get("expected_calibration_hours", -1)) != spec["hours"]):
        raise ValueError(f"calibration window metadata differs: {spec['exp_id']}")
    if "exp_id" in result and result["exp_id"] != spec["exp_id"]:
        raise ValueError("new calibration experiment identity differs")


def _validate_parameter_catalogue(result: dict, arrays: dict) -> list[dict]:
    catalogue = result.get("parameters")
    if not isinstance(catalogue, list) or len(catalogue) != 2048:
        raise ValueError("physical-parameter catalogue is incomplete")
    try:
        rebuilt = np.asarray([
            [record[field] for field in ("cw", "cv", "cg", "cq", "cs")]
            for record in catalogue
        ], dtype=np.float64)
    except (KeyError, TypeError, ValueError) as error:
        raise ValueError("physical-parameter catalogue is malformed") from error
    if not np.array_equal(rebuilt, arrays["parameter_values"]):
        raise ValueError("physical-parameter catalogue differs from the raw array")
    return catalogue


def _reconstruct_source(source: _CalibrationSource) -> dict:
    spec = source.spec
    if not source.raw_path.is_file() or sha256(source.raw_path) != source.raw_sha256:
        raise RuntimeError(f"calibration raw archive changed: {spec['exp_id']}")
    if not source.result_path.is_file() or sha256(source.result_path) != source.result_sha256:
        raise RuntimeError(f"calibration result metadata changed: {spec['exp_id']}")
    result = read_json(source.result_path)
    _validate_result_header(result, spec)
    with np.load(source.raw_path, allow_pickle=False) as raw:
        arrays, array_hashes = _validate_arrays_and_cache(raw, result, spec)

    expected_parameter_ids = np.arange(2048, dtype=np.int64)
    if not np.array_equal(arrays["parameter_ids"], expected_parameter_ids):
        raise ValueError("physical-parameter identities differ")
    expected_warmup = np.arange(
        np.datetime64("1999-01-01T01", "h"), np.datetime64(spec["start"], "h"),
        np.timedelta64(1, "h"),
    )
    expected_calibration = np.arange(
        np.datetime64(spec["start"], "h"), np.datetime64(spec["stop"], "h"),
        np.timedelta64(1, "h"),
    )
    if not np.array_equal(arrays["warmup_timestamps"], expected_warmup):
        raise ValueError("weather-only warmup chronology differs")
    if not np.array_equal(arrays["calibration_timestamps"], expected_calibration):
        raise ValueError("calibration chronology differs")
    if not np.array_equal(arrays["calibration_indices"], np.arange(spec["hours"])):
        raise ValueError("calibration indices differ")
    if not arrays["warmup_completed"].all() or not arrays["hydrologic_completed"].all():
        raise ValueError("complete calibration lacks a completed hydrologic candidate")
    if not np.array_equal(
        arrays["hydrologic_prediction_mask"],
        np.isfinite(arrays["hydrologic_predictions"]),
    ):
        raise ValueError("hydrologic prediction mask differs")
    hydrologic_errors = _rmse_errors(
        arrays["hydrologic_predictions"], arrays["calibration_observations"],
        arrays["hydrologic_alive"],
    )
    if not np.array_equal(hydrologic_errors, arrays["hydrologic_errors"]):
        raise ValueError("hydrologic error reconstruction differs")
    expected_hydrologic_valid = arrays["hydrologic_alive"] & np.isfinite(hydrologic_errors)
    if not np.array_equal(expected_hydrologic_valid, arrays["hydrologic_valid"]):
        raise ValueError("hydrologic validity reconstruction differs")
    finite_hydrologic = np.flatnonzero(np.isfinite(hydrologic_errors))
    if len(finite_hydrologic) < 16:
        raise ValueError("fewer than 16 hydrologic candidates are valid")
    shortlist = np.asarray(sorted(
        finite_hydrologic.tolist(),
        key=lambda row: (float(hydrologic_errors[row]), int(row)),
    )[:16], dtype=np.int64)
    if not np.array_equal(shortlist, arrays["shortlist_parameter_ids"]):
        raise ValueError("top-16 physical-parameter shortlist differs")

    origins = arrays["origin_indices"]
    expected_origins = np.arange(spec["hours"], dtype=np.int64)
    midnight = arrays["calibration_timestamps"] == arrays["calibration_timestamps"].astype("datetime64[D]")
    expected_origins = expected_origins[midnight]
    expected_origins = expected_origins[expected_origins + 120 < spec["hours"]]
    if not np.array_equal(origins, expected_origins):
        raise ValueError("selection origins differ")
    expected_targets = origins[:, None] + np.asarray([1, 24, 48, 120], dtype=np.int64)
    if not np.array_equal(arrays["target_indices"], expected_targets):
        raise ValueError("selection targets differ")
    if not np.array_equal(
        arrays["origin_timestamps"], arrays["calibration_timestamps"][origins],
    ):
        raise ValueError("selection origin timestamps differ")
    if not np.array_equal(
        arrays["target_timestamps"], arrays["calibration_timestamps"][expected_targets],
    ):
        raise ValueError("selection target timestamps differ")
    target_observations = arrays["calibration_observations"][expected_targets]
    if not np.array_equal(arrays["target_observations"], target_observations):
        raise ValueError("selection observations differ")
    expected_persistence = np.broadcast_to(
        arrays["calibration_observations"][origins, None], expected_targets.shape,
    )
    if not np.array_equal(arrays["persistence_predictions"], expected_persistence):
        raise ValueError("persistence predictions differ")
    if not np.array_equal(arrays["persistence_mask"], np.isfinite(expected_persistence)):
        raise ValueError("persistence mask differs")
    if not arrays["persistence_mask"].all() or not np.isfinite(target_observations).all():
        raise ValueError("selection targets or persistence are incomplete")
    reference = np.sqrt(np.mean((expected_persistence - target_observations) ** 2, axis=0))
    if not np.array_equal(reference, arrays["reference_errors"]):
        raise ValueError("persistence error reconstruction differs")
    if not np.isfinite(reference).all() or np.any(reference <= 0):
        raise ValueError("persistence error is invalid")

    expected_joint_parameter_ids = np.repeat(shortlist, 128)
    expected_joint_noise_ids = np.tile(np.arange(128, dtype=np.int64), 16)
    if not np.array_equal(arrays["joint_parameter_ids"], expected_joint_parameter_ids):
        raise ValueError("joint physical-parameter identities differ")
    if not np.array_equal(arrays["joint_noise_ids"], expected_joint_noise_ids):
        raise ValueError("joint process-noise identities differ")
    if not arrays["joint_completed"].all():
        raise ValueError("complete calibration lacks a completed joint candidate")
    if not np.array_equal(
        arrays["joint_prediction_mask"], np.isfinite(arrays["joint_predictions"]),
    ):
        raise ValueError("joint prediction mask differs")
    joint_errors = _rmse_errors(
        arrays["joint_predictions"], target_observations,
        arrays["joint_alive"] & arrays["joint_completed"],
    )
    if not np.array_equal(joint_errors, arrays["joint_errors"]):
        raise ValueError("four-lead candidate error reconstruction differs")
    old_scores = _all_lead_scores(joint_errors, reference)
    if not np.array_equal(old_scores, arrays["joint_scores"]):
        raise ValueError("archived four-lead score reconstruction differs")
    expected_joint_valid = (
        arrays["joint_alive"] & arrays["joint_completed"]
        & np.isfinite(joint_errors).all(axis=1) & np.isfinite(old_scores)
    )
    if not np.array_equal(expected_joint_valid, arrays["joint_valid"]):
        raise ValueError("joint validity reconstruction differs")
    old_order, old_parameter_best = _ordered_rows(
        arrays["joint_parameter_ids"], arrays["joint_noise_ids"],
        old_scores, expected_joint_valid,
    )
    if not np.array_equal(old_order, arrays["joint_rank_order"]):
        raise ValueError("archived four-lead rank order differs")
    if len(old_parameter_best) < 5:
        raise ValueError("archived ranking has fewer than five physical parameters")
    old_identities = [
        (int(arrays["joint_parameter_ids"][row]), int(arrays["joint_noise_ids"][row]))
        for row in old_parameter_best[:5]
    ]
    selected_metadata = result.get("selected")
    if not isinstance(selected_metadata, dict):
        raise ValueError("archived selected metadata is absent")
    saved_members = selected_metadata.get("members")
    if not isinstance(saved_members, list) or len(saved_members) < 5:
        raise ValueError("archived selected members are incomplete")
    if old_identities != [
        (int(member["parameter_id"]), int(member["noise_id"]))
        for member in saved_members[:5]
    ]:
        raise ValueError("archived four-lead selected members differ")
    if (int(selected_metadata.get("prespecified_single_parameter_id", -1)),
            int(selected_metadata.get("prespecified_single_noise_id", -1))) != old_identities[0]:
        raise ValueError("archived prespecified single model differs")
    source_array_hashes = selected_metadata.get("source_hashes")
    expected_source_hashes = {name: array_hashes[name] for name in _SOURCE_ARRAY_NAMES}
    if source_array_hashes != expected_source_hashes:
        raise ValueError("archived selected source-array hashes differ")

    two_lead = _rank_two_lead(
        arrays["joint_parameter_ids"], arrays["joint_noise_ids"],
        joint_errors, reference, expected_joint_valid,
    )
    row = two_lead["best_row"]
    parameter_id = int(arrays["joint_parameter_ids"][row])
    noise_id = int(arrays["joint_noise_ids"][row])
    catalogue = _validate_parameter_catalogue(result, arrays)
    window_warmup_state = arrays["warmup_states"][parameter_id]
    if (not arrays["warmup_completed"][parameter_id]
            or not arrays["hydrologic_valid"][parameter_id]
            or not np.isfinite(window_warmup_state).all()):
        raise ValueError("rank-one physical parameter lacks its selection-window warmup state")
    record = {
        "experiment_id": spec["exp_id"],
        "endpoint": spec["endpoint"],
        "months": int(spec["months"]),
        "calibration_start": spec["start"],
        "calibration_stop": spec["stop"],
        "parameter_id": parameter_id,
        "parameter_values": arrays["parameter_values"][parameter_id].tolist(),
        "parameters": catalogue[parameter_id],
        "noise_id": noise_id,
        "noise_diagonal": arrays["noise_design"][noise_id].tolist(),
        "score": float(two_lead["scores"][row]),
        "selection_leads": [48, 120],
        "top_16_parameter_ids": shortlist.tolist(),
        "valid_joint_candidate_count": int(expected_joint_valid.sum()),
        "complete_rank_order_count": int(len(two_lead["complete_order"])),
        "complete_rank_order_sha256": array_sha256(two_lead["complete_order"]),
        "parameter_best_rank_order_sha256": array_sha256(two_lead["parameter_best_rows"]),
        "two_lead_scores_sha256": array_sha256(two_lead["scores"]),
        "old_four_lead_rank_order_sha256": array_sha256(old_order),
        "old_four_lead_rank_one": {
            "parameter_id": old_identities[0][0], "noise_id": old_identities[0][1],
        },
        "selection_window_warmup_state": window_warmup_state.tolist(),
        "selection_window_warmup_state_sha256": array_sha256(window_warmup_state),
        "array_contract_reproduced": True,
        "hydrologic_shortlist_reproduced": True,
        "four_lead_rank_reproduced": True,
        "source_kind": source.source_kind,
        "source_hashes": {
            "raw_npz": source.raw_sha256,
            "result_json": source.result_sha256,
            "receipt_json": source.receipt_sha256,
            "process_json": source.process_sha256,
            "raw_arrays": array_hashes,
        },
    }
    return record


def validate_new_calibration_artifact(
        directory: Path, exp_id: str, *, receipt_sha256: str,
        process_sha256: str) -> dict:
    """Fully reconstruct one new calibration without publishing a selection.

    This is the import boundary used by the high-performance-computing bridge.
    It deliberately reuses the same numerical reconstruction as the selection
    stage, while returning only an in-memory audit record.
    """
    from . import calibration
    from .contract import load_inputs

    matches = [
        dict(spec) for spec in missing_calibration_specs()
        if spec["exp_id"] == exp_id
    ]
    if len(matches) != 1:
        raise ValueError(f"unknown new calibration experiment: {exp_id}")
    spec = matches[0]
    directory = Path(directory)
    receipt_path = directory / "receipt.json"
    process_path = directory / "process.json"
    raw_path = directory / "raw.npz"
    result_path = directory / "result.json"
    if (not receipt_path.is_file()
            or sha256(receipt_path) != receipt_sha256):
        raise RuntimeError(f"new calibration receipt changed: {exp_id}")
    if (not process_path.is_file()
            or sha256(process_path) != process_sha256):
        raise RuntimeError(f"new calibration process record changed: {exp_id}")
    receipt = read_json(receipt_path)
    result = read_json(result_path)

    bound = calibration.bind_calibration_inputs(load_inputs(), exp_id)
    expected_inputs = dict(bound.meta["source_hashes"])
    if (receipt.get("input_source_hashes") != expected_inputs
            or result.get("input_source_hashes") != expected_inputs):
        raise ValueError(f"frozen calibration inputs differ: {exp_id}")
    environment = result.get("environment")
    if not isinstance(environment, dict) or receipt.get("environment") != environment:
        raise ValueError(f"calibration environment evidence differs: {exp_id}")
    if environment.get("sealed_source_hashes") != calibration._verify_sealed_sources():
        raise ValueError(f"sealed numerical source differs: {exp_id}")
    thread_settings = environment.get("thread_settings", {})
    pools = thread_settings.get("loaded_threadpools_observed")
    if (thread_settings.get("threadpool_observation_error") is not None
            or not isinstance(pools, list)
            or any(int(pool.get("num_threads", -1)) != 1 for pool in pools)):
        raise ValueError(f"calibration thread evidence differs: {exp_id}")

    design_binding = result.get("design_binding")
    expected_designs = {
        "parameter": (calibration.PARAMETER_DESIGN_SHA256, 2048 * 5),
        "noise": (calibration.NOISE_DESIGN_SHA256, 128 * 5),
    }
    if not isinstance(design_binding, dict):
        raise ValueError(f"calibration design binding is absent: {exp_id}")
    for name, (expected_hash, maximum_values) in expected_designs.items():
        binding = design_binding.get(name)
        if not isinstance(binding, dict):
            raise ValueError(f"calibration {name} design binding is absent: {exp_id}")
        different = binding.get("different_value_count")
        steps = binding.get("maximum_float64_steps")
        if (binding.get("canonical_array_sha256") != expected_hash
                or binding.get("canonical_bytes_used_for_execution") is not True
                or not isinstance(binding.get("generated_array_sha256"), str)
                or len(binding["generated_array_sha256"]) != 64
                or not isinstance(different, int)
                or different < 0 or different > maximum_values
                or steps not in (0, 1)
                or (different == 0) != (steps == 0)):
            raise ValueError(f"calibration {name} design binding differs: {exp_id}")

    with np.load(raw_path, allow_pickle=False) as raw:
        for name in (
                "warmup_timestamps", "warmup_forcing",
                "calibration_timestamps", "calibration_forcing",
                "calibration_observations"):
            if array_sha256(np.asarray(raw[name])) != expected_inputs[name]:
                raise ValueError(f"frozen calibration array differs: {exp_id}: {name}")
        if (array_sha256(np.asarray(raw["parameter_values"]))
                != calibration.PARAMETER_DESIGN_SHA256):
            raise ValueError(f"canonical parameter design differs: {exp_id}")
        if (array_sha256(np.asarray(raw["noise_design"]))
                != calibration.NOISE_DESIGN_SHA256):
            raise ValueError(f"canonical noise design differs: {exp_id}")

    files = receipt.get("files", {})
    source = _CalibrationSource(
        spec=spec, directory=directory, raw_path=raw_path,
        result_path=result_path, raw_sha256=files.get("raw.npz", ""),
        result_sha256=files.get("result.json", ""),
        source_kind="new_calibration", receipt_sha256=receipt_sha256,
        process_sha256=process_sha256,
    )
    return _reconstruct_source(source)


def _archive_manifest() -> dict:
    manifest_path = ARCHIVE / "manifest.json"
    audit_path = ARCHIVE / "audit.json"
    if not manifest_path.is_file() or sha256(manifest_path) != ARCHIVE_MANIFEST_SHA256:
        raise RuntimeError("archived calibration manifest changed")
    if not audit_path.is_file() or sha256(audit_path) != ARCHIVE_AUDIT_SHA256:
        raise RuntimeError("archived calibration audit changed")
    if read_json(audit_path).get("passed") is not True:
        raise RuntimeError("archived calibration audit did not pass")
    return read_json(manifest_path)


def _existing_sources(manifest: dict) -> dict[str, _CalibrationSource]:
    files = manifest.get("files", {})
    sources = {}
    for spec in window_specs():
        if spec["months"] not in (3, 24):
            continue
        relative = f"calibration/{_ARCHIVE_DIRECTORIES[(spec['endpoint'], spec['months'])]}"
        raw_relative = f"{relative}/raw.npz"
        result_relative = f"{relative}/result.json"
        raw_digest, result_digest = files.get(raw_relative), files.get(result_relative)
        if not isinstance(raw_digest, str) or not isinstance(result_digest, str):
            raise RuntimeError(f"archived calibration is absent from the manifest: {spec['exp_id']}")
        directory = ARCHIVE / relative
        sources[spec["exp_id"]] = _CalibrationSource(
            spec=dict(spec), directory=directory, raw_path=directory / "raw.npz",
            result_path=directory / "result.json", raw_sha256=raw_digest,
            result_sha256=result_digest, source_kind="read_only_archived_calibration",
        )
    return sources


def _verify_new_calibration_stage(root: Path) -> dict[str, dict]:
    root = Path(root)
    stage_receipt = root / "calibration_receipt.json"
    if not stage_receipt.is_file():
        raise FileNotFoundError("completed calibration stage receipt is missing")
    if (root / "calibration_failed.json").exists():
        raise RuntimeError("calibration failure receipt coexists with selection input")
    stage = read_json(stage_receipt)
    if stage.get("passed") is not True or stage.get("status") != "complete":
        raise RuntimeError("new calibration stage did not complete")
    expected_ids = [spec["exp_id"] for spec in missing_calibration_specs()]
    completed = stage.get("completed")
    if (not isinstance(completed, list)
            or [row.get("exp_id") for row in completed] != expected_ids):
        raise RuntimeError("new calibration completion list differs")
    attempts = stage.get("attempts")
    if (stage.get("started_experiments") != expected_ids
            or not isinstance(attempts, list)
            or [row.get("exp_id") for row in attempts] != expected_ids
            or any(row.get("status") != "complete" or row.get("returncode") != 0
                   or row.get("process_evidence_present") is not True
                   or row.get("receipt_evidence_present") is not True
                   for row in attempts)):
        raise RuntimeError("new calibration process-attempt evidence differs")
    records = {}
    for expected, row in zip(expected_ids, completed):
        directory = root / "calibration" / expected
        receipt_path = directory / "receipt.json"
        process_path = directory / "process.json"
        if not receipt_path.is_file() or sha256(receipt_path) != row.get("receipt_sha256"):
            raise RuntimeError(f"new calibration receipt changed: {expected}")
        if not process_path.is_file() or sha256(process_path) != row.get("process_sha256"):
            raise RuntimeError(f"new calibration process evidence changed: {expected}")
        receipt = read_json(receipt_path)
        process = read_json(process_path)
        if (receipt.get("passed") is not True or receipt.get("status") != "complete"
                or receipt.get("exp_id") != expected or receipt.get("exit_code") != 0
                or process.get("exit_code") != 0):
            raise RuntimeError(f"new calibration did not complete successfully: {expected}")
        files = receipt.get("files", {})
        raw_digest, result_digest = files.get("raw.npz"), files.get("result.json")
        if not isinstance(raw_digest, str) or not isinstance(result_digest, str):
            raise RuntimeError(f"new calibration file hashes are incomplete: {expected}")
        records[expected] = {
            "directory": directory,
            "raw_sha256": raw_digest,
            "result_sha256": result_digest,
            "receipt_sha256": row["receipt_sha256"],
            "process_sha256": row["process_sha256"],
        }
    return records


def _new_sources(root: Path, records: dict[str, dict]) -> dict[str, _CalibrationSource]:
    sources = {}
    for spec in missing_calibration_specs():
        source = records[spec["exp_id"]]
        directory = source["directory"]
        sources[spec["exp_id"]] = _CalibrationSource(
            spec=dict(spec), directory=directory, raw_path=directory / "raw.npz",
            result_path=directory / "result.json", raw_sha256=source["raw_sha256"],
            result_sha256=source["result_sha256"], source_kind="new_calibration",
            receipt_sha256=source["receipt_sha256"],
            process_sha256=source["process_sha256"],
        )
    return sources


def _annotate_common_initialization(records: dict[str, dict], manifest: dict) -> None:
    """Add eligibility only after every selection identity has been ranked."""
    if set(records) not in (
        {spec["exp_id"] for spec in window_specs() if spec["months"] in (3, 24)},
        {spec["exp_id"] for spec in window_specs()},
    ):
        raise ValueError("selection identities must all be frozen before eligibility annotation")
    masks = common_warmup_state_masks()
    files = manifest.get("files", {})
    endpoint_sources = {}
    for endpoint in ("E1", "E2", "E3"):
        directory_name = _ARCHIVE_DIRECTORIES[(endpoint, 3)]
        relative = f"calibration/{directory_name}/raw.npz"
        path = ARCHIVE / relative
        expected = files.get(relative)
        if not isinstance(expected, str) or not path.is_file() or sha256(path) != expected:
            raise RuntimeError(f"common warmup source changed: {endpoint}")
        with np.load(path, allow_pickle=False) as raw:
            parameter_ids = raw["parameter_ids"]
            states = raw["warmup_states"]
            completed = raw["warmup_completed"]
        if (not np.array_equal(parameter_ids, np.arange(2048))
                or states.shape != (2048, 5) or completed.shape != (2048,)
                or completed.dtype != np.bool_ or not completed.all()):
            raise RuntimeError(f"common warmup source structure differs: {endpoint}")
        endpoint_sources[endpoint] = (states, expected, array_sha256(states))

    for exp_id, original in tuple(records.items()):
        record = dict(original)
        endpoint = record["endpoint"]
        parameter_id = int(record["parameter_id"])
        states, raw_digest, states_digest = endpoint_sources[endpoint]
        state = np.asarray(states[parameter_id], dtype=np.float64)
        eligible = bool(masks[endpoint][parameter_id])
        if eligible != bool(np.isfinite(state).all()):
            raise RuntimeError(f"common warmup mask and state differ: {exp_id}")
        record.update(
            common_initialization_mask_sha256=array_sha256(masks[endpoint]),
            selected_identity_eligible=eligible,
            common_warmup_state=state.tolist() if eligible else None,
            common_warmup_state_sha256=array_sha256(state),
            common_warmup_state_source_exp_id=f"RL-{endpoint}-M03",
            common_warmup_state_source_parameter_id=parameter_id,
            common_warmup_state_source_hashes={
                "raw_npz": raw_digest,
                "warmup_states": states_digest,
            },
        )
        records[exp_id] = record


def reconstruct_existing_selections() -> dict[str, dict]:
    """Strictly reconstruct the six archived 3- and 24-month rankings."""
    manifest = _archive_manifest()
    sources = _existing_sources(manifest)
    records = {
        spec["exp_id"]: _reconstruct_source(sources[spec["exp_id"]])
        for spec in window_specs() if spec["months"] in (3, 24)
    }
    _annotate_common_initialization(records, manifest)
    return records


def _build_all_records(root: Path) -> dict[str, dict]:
    # Verify all six required new inputs before reading or ranking any window.
    new_records = _verify_new_calibration_stage(root)
    manifest = _archive_manifest()
    sources = _existing_sources(manifest)
    sources.update(_new_sources(root, new_records))
    records = {}
    for spec in window_specs():
        source = sources.get(spec["exp_id"])
        if source is None:
            raise FileNotFoundError(f"no exact calibration source exists: {spec['exp_id']}")
        records[spec["exp_id"]] = _reconstruct_source(source)
    if len(records) != 12:
        raise RuntimeError("all 12 selection identities were not reconstructed")
    _annotate_common_initialization(records, manifest)
    return records


def _verify_prepared_root(root: Path) -> dict:
    root = Path(root)
    if root.resolve() != Path(preparation.OUTPUT).resolve():
        raise ValueError("selection root differs from the prepared formal attempt")
    return preparation.verify_prepared()


def select_all(root: Path = FORMAL_OUTPUT) -> Path:
    """Freeze exactly 12 identities, then check common-state eligibility."""
    root = Path(root)
    stage_paths = {
        "started": root / "selection_started.json",
        "selections": root / "selections.json",
        "manifest": root / "selection_manifest.json",
        "receipt": root / "selection_receipt.json",
        "failed": root / "selection_failed.json",
    }
    if any(path.exists() for path in stage_paths.values()):
        raise FileExistsError("selection stage already has an artifact and cannot overwrite it")
    if not root.is_dir():
        raise FileNotFoundError("prepared selection root does not exist")
    started = time.perf_counter()
    records: dict[str, dict] | None = None
    files_written: dict[str, str] = {}
    try:
        write_json_new(stage_paths["started"], {
            "schema": "regge_record_length_selection_start_v01",
            "status": "started", "started_utc": _utc(),
            "ordered_experiments": [spec["exp_id"] for spec in window_specs()],
            "fallback_policy": "none",
        })
        config = _verify_prepared_root(root)
        if config.get("windows") != list(window_specs()):
            raise RuntimeError("prepared window registry differs from the frozen selection windows")
        _event(root, "selection_stage_started", selection_count=12)
        records = _build_all_records(root)
        expected_ids = [spec["exp_id"] for spec in window_specs()]
        if list(records) != expected_ids:
            raise RuntimeError("selection record order or identity differs")
        write_json_new(stage_paths["selections"], records)
        files_written["selections.json"] = sha256(stage_paths["selections"])
        source_files = {
            exp_id: {
                key: value for key, value in record["source_hashes"].items()
                if key != "raw_arrays"
            }
            for exp_id, record in records.items()
        }
        write_json_new(stage_paths["manifest"], {
            "schema": "regge_record_length_selection_manifest_v01",
            "selection_count": len(records),
            "ordered_experiments": expected_ids,
            "selections_sha256": files_written["selections.json"],
            "preparation_receipt_sha256": sha256(root / "preparation_receipt.json"),
            "calibration_receipt_sha256": sha256(root / "calibration_receipt.json"),
            "calibration_sources": source_files,
            "ranking_inputs": "calibration arrays only",
            "common_initialization_mask_used_for_ranking": False,
        })
        files_written["selection_manifest.json"] = sha256(stage_paths["manifest"])
        ineligible = [
            exp_id for exp_id, record in records.items()
            if record["selected_identity_eligible"] is not True
        ]
        if ineligible:
            raise RuntimeError(
                "one or more frozen rank-one identities lack a finite common warmup state: "
                + ", ".join(ineligible)
            )
        _event(root, "selection_stage_completed", selection_count=12)
        write_json_new(stage_paths["receipt"], {
            "schema": "regge_record_length_selection_receipt_v01",
            "status": "complete", "passed": True,
            "selection_count": 12,
            "all_selected_identities_eligible": True,
            "files": files_written,
            "elapsed_seconds": time.perf_counter() - started,
        })
        return root
    except BaseException as error:
        if not stage_paths["failed"].exists():
            frozen_count = len(records) if stage_paths["selections"].is_file() and records else 0
            failure = {
                "schema": "regge_record_length_selection_failure_v01",
                "status": "failed", "passed": False,
                "error": {"type": type(error).__name__, "reason": str(error)},
                "traceback": traceback.format_exc(),
                "frozen_identity_count": frozen_count,
                "files_written": files_written,
                "fallback_used": False,
                "elapsed_seconds": time.perf_counter() - started,
            }
            try:
                write_json_new(stage_paths["failed"], failure)
            except BaseException as receipt_error:
                error.add_note(
                    "selection failure receipt also failed: "
                    f"{type(receipt_error).__name__}: {receipt_error}"
                )
        try:
            _event(root, "selection_stage_failed", error_type=type(error).__name__, error=str(error))
        except BaseException as event_error:
            error.add_note(
                "selection failure event also failed: "
                f"{type(event_error).__name__}: {event_error}"
            )
        raise
