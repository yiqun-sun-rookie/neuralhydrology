"""Stage dispatcher and one-process-per-window calibration supervision."""
from __future__ import annotations

from contextlib import redirect_stderr, redirect_stdout
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import time
import traceback

from . import prepare as preparation
from .assessment import assess_all
from .audit import audit_all
from .calibration import CALIBRATION_ROOT, calibrate_one, missing_calibration_specs
from .common import FORMAL_OUTPUT, PROJECT, read_json, sha256, write_json_new
from .selection import select_all
from .report import generate_report


ENTRY = PROJECT / "python/run_regge_record_length_study.py"


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _append_root_event(root: Path, event: str, **fields) -> None:
    row = {"utc": _utc(), "event": event, **fields}
    with (root / "events.jsonl").open("a", encoding="utf-8") as target:
        target.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")


def _verify_prepared_root(root: Path) -> dict:
    if root.resolve() != Path(preparation.OUTPUT).resolve():
        raise ValueError("calibration root differs from the prepared formal attempt")
    return preparation.verify_prepared()


def calibration_worker(exp_id: str, destination: Path,
                       stdout_path: Path, stderr_path: Path) -> int:
    """Child-process entry that records its own intended process exit."""
    spec_matches = [spec for spec in missing_calibration_specs() if spec["exp_id"] == exp_id]
    if len(spec_matches) != 1:
        raise ValueError(f"unknown calibration worker identity: {exp_id}")
    destination = Path(destination)
    if destination.exists():
        raise FileExistsError(f"calibration destination already exists: {destination}")
    stdout_path, stderr_path = Path(stdout_path), Path(stderr_path)
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    started_utc = _utc()
    started = time.perf_counter()
    exit_code = 1
    error = None
    with stdout_path.open("x", encoding="utf-8") as stdout, stderr_path.open("x", encoding="utf-8") as stderr:
        with redirect_stdout(stdout), redirect_stderr(stderr):
            try:
                calibrate_one(spec_matches[0], destination)
                exit_code = 0
            except BaseException as caught:
                error = {"type": type(caught).__name__, "reason": str(caught)}
                traceback.print_exc()
    if destination.is_dir():
        try:
            result_context = {}
            result_path = destination / "result.json"
            if result_path.is_file():
                saved_result = read_json(result_path)
                result_context = {
                    "failure_stage": saved_result.get("failure_stage"),
                    "environment": saved_result.get("environment"),
                    "input_source_hashes": saved_result.get("input_source_hashes"),
                }
            write_json_new(destination / "process.json", {
                "schema": "regge_record_length_calibration_process_v01",
                "exp_id": exp_id,
                "started_utc": started_utc,
                "finished_utc": _utc(),
                "elapsed_seconds": time.perf_counter() - started,
                "exit_code": exit_code,
                "error": error,
                "stdout": str(stdout_path),
                "stderr": str(stderr_path),
                "stdout_sha256": sha256(stdout_path),
                "stderr_sha256": sha256(stderr_path),
                **result_context,
            })
        except BaseException:
            traceback.print_exc(file=sys.stderr)
            return 1
    return exit_code


def run_calibrations(root: Path = FORMAL_OUTPUT) -> Path:
    """Launch six independent child processes sequentially with no retry."""
    root = Path(root)
    expected_ids = [spec["exp_id"] for spec in missing_calibration_specs()]
    stage_paths = [
        root / "calibration_started.json",
        root / "calibration_receipt.json",
        root / "calibration_failed.json",
    ]
    if any(path.exists() for path in stage_paths):
        raise FileExistsError("calibration stage already has a start, success, or failure receipt")
    if not root.is_dir():
        raise FileNotFoundError("prepared calibration root does not exist")
    started = time.perf_counter()
    destinations = [root / "calibration" / exp_id for exp_id in expected_ids]
    logs = root / "calibration_process_logs"
    completed: list[dict] = []
    attempts: list[dict] = []
    started_experiments: list[str] = []
    failure_stage = "stage_initialization"
    initialization_complete = False
    start_receipt_written_initially = False
    try:
        write_json_new(stage_paths[0], {
            "schema": "regge_record_length_calibration_stage_start_v01",
            "status": "started",
            "started_utc": _utc(),
            "ordered_experiments": expected_ids,
            "retry_policy": "none",
            "processes": "sequential_one_window_per_process",
        })
        start_receipt_written_initially = True
        config = _verify_prepared_root(root)
        frozen_new = [row["selection_id"] for row in config["registry"]
                      if row["record_type"] == "selection"
                      and row["calibration_source"] == "new"]
        if frozen_new != expected_ids:
            raise RuntimeError("prepared registry does not contain the six frozen new calibrations")
        if any(path.exists() for path in destinations):
            raise FileExistsError("one or more calibration destinations already exist")
        logs.mkdir(exist_ok=False)
        _append_root_event(root, "calibration_stage_started", ordered_experiments=expected_ids)
        initialization_complete = True
        failure_stage = "child_process_supervision"
        for spec, destination in zip(missing_calibration_specs(), destinations):
            exp_id = spec["exp_id"]
            stdout_path = logs / f"{exp_id}.stdout.log"
            stderr_path = logs / f"{exp_id}.stderr.log"
            attempt = {
                "exp_id": exp_id,
                "started_utc": _utc(),
                "returncode": None,
                "process_evidence_present": False,
                "receipt_evidence_present": False,
                "stdout_present": False,
                "stderr_present": False,
                "status": "started",
            }
            attempts.append(attempt)
            started_experiments.append(exp_id)
            command = [
                sys.executable,
                str(ENTRY),
                "_calibrate-one",
                "--exp-id", exp_id,
                "--destination", str(destination),
                "--stdout", str(stdout_path),
                "--stderr", str(stderr_path),
            ]
            _append_root_event(root, "calibration_process_started", exp_id=exp_id)
            process = subprocess.run(command, cwd=PROJECT, check=False)
            attempt.update(
                returncode=int(process.returncode),
                finished_utc=_utc(),
                stdout_present=stdout_path.is_file(),
                stderr_present=stderr_path.is_file(),
                stdout_sha256=sha256(stdout_path) if stdout_path.is_file() else None,
                stderr_sha256=sha256(stderr_path) if stderr_path.is_file() else None,
            )
            process_path = destination / "process.json"
            receipt_path = destination / "receipt.json"
            attempt["process_evidence_present"] = process_path.is_file()
            attempt["receipt_evidence_present"] = receipt_path.is_file()
            if not destination.is_dir() or not process_path.is_file():
                attempt["status"] = "externally_terminated_or_missing_process_evidence"
                raise RuntimeError(
                    "calibration process was externally terminated or process evidence "
                    f"is missing: {exp_id}; returncode={process.returncode}"
                )
            process_record = read_json(process_path)
            if process.returncode != process_record.get("exit_code"):
                attempt["status"] = "exit_evidence_mismatch"
                raise RuntimeError(f"calibration process exit evidence differs: {exp_id}")
            if not receipt_path.is_file():
                attempt["status"] = "missing_window_receipt"
                raise RuntimeError(f"calibration window receipt is missing: {exp_id}")
            receipt = read_json(receipt_path)
            completion_record = {
                "exp_id": exp_id,
                "returncode": process.returncode,
                "receipt_status": receipt.get("status"),
                "receipt_sha256": sha256(receipt_path),
                "process_sha256": sha256(process_path),
            }
            if process.returncode != 0 or receipt.get("passed") is not True:
                attempt["status"] = "failed"
                raise RuntimeError(f"calibration process failed: {exp_id}")
            completed.append(completion_record)
            attempt["status"] = "complete"
            _append_root_event(root, "calibration_process_completed", exp_id=exp_id)
        failure_stage = "stage_finalization"
        _append_root_event(root, "calibration_stage_completed", completed=len(completed))
        write_json_new(stage_paths[1], {
            "schema": "regge_record_length_calibration_stage_receipt_v01",
            "status": "complete",
            "passed": True,
            "started_experiments": started_experiments,
            "attempts": attempts,
            "completed": completed,
            "elapsed_seconds": time.perf_counter() - started,
        })
        return root
    except BaseException as error:
        if not stage_paths[0].exists():
            try:
                write_json_new(stage_paths[0], {
                    "schema": "regge_record_length_calibration_stage_start_v01",
                    "status": "initialization_failed",
                    "started_utc": _utc(),
                    "ordered_experiments": expected_ids,
                    "retry_policy": "none",
                    "processes": "sequential_one_window_per_process",
                    "recovered_after_initial_write_failure": True,
                })
            except BaseException as start_error:
                error.add_note(
                    "recovery of the stage start receipt also failed: "
                    f"{type(start_error).__name__}: {start_error}"
                )
        failed_experiment = None
        if attempts and attempts[-1].get("status") != "complete":
            failed_experiment = attempts[-1]["exp_id"]
        failure = {
            "schema": "regge_record_length_calibration_stage_failure_v01",
            "status": "failed",
            "passed": False,
            "failure_stage": failure_stage,
            "initialization_complete": initialization_complete,
            "start_receipt_written_initially": start_receipt_written_initially,
            "start_receipt_present": stage_paths[0].is_file(),
            "error": {"type": type(error).__name__, "reason": str(error)},
            "started_experiments": started_experiments,
            "failed_experiment": failed_experiment,
            "attempts": attempts,
            "completed": completed,
            "unstarted": expected_ids[len(started_experiments):],
            "elapsed_seconds": time.perf_counter() - started,
        }
        try:
            write_json_new(stage_paths[2], failure)
        except BaseException as receipt_error:
            error.add_note(
                "stage failure receipt also failed: "
                f"{type(receipt_error).__name__}: {receipt_error}"
            )
        try:
            _append_root_event(root, "calibration_stage_failed",
                               error_type=type(error).__name__, error=str(error))
        except BaseException as event_error:
            error.add_note(
                "stage failure event also failed: "
                f"{type(event_error).__name__}: {event_error}"
            )
        raise


def run_stage(stage: str) -> Path:
    if stage == "prepare":
        return preparation.prepare()
    if stage == "calibrate":
        return run_calibrations()
    if stage == "select":
        return select_all()
    if stage == "assess":
        return assess_all()
    if stage == "audit":
        return audit_all()
    if stage == "report":
        return generate_report()
    raise ValueError(f"stage is not implemented: {stage}")
