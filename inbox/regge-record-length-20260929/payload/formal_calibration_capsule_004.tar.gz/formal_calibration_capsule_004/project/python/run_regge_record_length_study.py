"""Command-line entry for the staged Regge record-length study."""
from __future__ import annotations

import argparse
from pathlib import Path

from regge_record_length_study.common import read_json
from regge_record_length_study.report import seal_report_after_visual_inspection
from regge_record_length_study.run import calibration_worker, run_stage


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run one frozen record-length study stage")
    subparsers = parser.add_subparsers(dest="stage", required=True)
    subparsers.add_parser("prepare")
    subparsers.add_parser("calibrate")
    subparsers.add_parser("select")
    subparsers.add_parser("assess")
    subparsers.add_parser("audit")
    subparsers.add_parser("report")
    seal = subparsers.add_parser("seal-report")
    seal.add_argument("--inspection-json", type=Path, required=True)
    worker = subparsers.add_parser("_calibrate-one", help=argparse.SUPPRESS)
    worker.add_argument("--exp-id", required=True)
    worker.add_argument("--destination", type=Path, required=True)
    worker.add_argument("--stdout", type=Path, required=True)
    worker.add_argument("--stderr", type=Path, required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if args.stage == "_calibrate-one":
        return calibration_worker(
            args.exp_id, args.destination, args.stdout, args.stderr,
        )
    if args.stage == "seal-report":
        seal_report_after_visual_inspection(read_json(args.inspection_json))
        return 0
    run_stage(args.stage)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
