"""
IMM-MUKF Data Assimilation Package for Hydrological Forecasting.

Modules:
    walrus       - WALRUS hydrological model (state-space formulation)
    ukf          - Unscented Kalman Filter (predict/update)
    imm          - Interacting Multiple Model framework
    data_loader  - Data loading and preprocessing
    metrics      - Performance metrics (RMSE, NSE, MAE, KGE)
    experiment   - Experiment runner (update + forecast pipeline)
    plotting     - Visualization utilities

Optional (requires torch):
    regime_da    - Regime-aware sequential DA pilot models. Import explicitly
                   via `from imm_da.regime_da import ...` when needed.
"""

__version__ = "0.1.0"
