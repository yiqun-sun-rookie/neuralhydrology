"""
Data loading and preprocessing for WALRUS model input.

Handles loading the PEQ_Regge_hour.txt data file and performing
the cumulative-sum preprocessing required by the WALRUS model.
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Optional, Tuple
from pathlib import Path


@dataclass
class CumsumData:
    """Container for preprocessed WALRUS cumulative-sum forcing data.

    All cumulative series have length T+1 (prepended with 0).
    output_date has length T+1 (in seconds since 1970-01-01).

    Attributes:
        p: Cumulative precipitation [mm].
        etpot: Cumulative potential ET [mm].
        q: Cumulative observed discharge [mm].
        fxg: Cumulative external groundwater flux [mm].
        fxs: Cumulative external surface water flux [mm].
        hs_min: Minimum surface water level series [mm].
        dg_obs: Observed groundwater depth series [mm].
        output_date: Timestamps in seconds since epoch.
    """
    p: np.ndarray
    etpot: np.ndarray
    q: np.ndarray
    fxg: np.ndarray
    fxs: np.ndarray
    hs_min: np.ndarray
    dg_obs: np.ndarray
    output_date: np.ndarray


def load_peq_data(filepath: str, date_start: int = 1999010101,
                  date_end: int = 2010010101) -> pd.DataFrame:
    """Load the PEQ (Precipitation-Evaporation-Discharge) data file.

    The file has columns: date, P, ETpot, Q, T
    with date in format YYYYMMDDhh.

    Parameters:
        filepath: Path to the PEQ_Regge_hour.txt file.
        date_start: Start date as integer YYYYMMDDhh (inclusive).
        date_end: End date as integer YYYYMMDDhh (inclusive).

    Returns:
        DataFrame with columns [date, P, ETpot, Q, T].
    """
    df = pd.read_csv(filepath, sep=r"\s+")
    # Filter date range
    df = df[(df["date"] >= date_start) & (df["date"] <= date_end)].copy()
    df.reset_index(drop=True, inplace=True)
    return df


def preprocess_walrus(df: pd.DataFrame, dt: int = 1) -> CumsumData:
    """Convert raw PEQ data into WALRUS cumulative-sum format.

    Mimics the MATLAB walrus_preprocessing function.

    Parameters:
        df: DataFrame with columns [date, P, ETpot, Q].
        dt: Timestep multiplier (1 = hourly).

    Returns:
        CumsumData instance.
    """
    # Parse dates: format YYYYMMDDhh
    # Hydro data uses hour 1-24 (hour 24 = midnight next day), but
    # strptime only accepts 00-23. Convert hour 24 → hour 00 + 1 day.
    date_strs = df["date"].astype(str).values
    parsed_dates = []
    for ds in date_strs:
        hh = int(ds[-2:])
        base = ds[:-2]
        if hh == 24:
            d = pd.Timestamp(base) + pd.Timedelta(days=1)
        else:
            d = pd.to_datetime(ds, format="%Y%m%d%H")
        parsed_dates.append(d)
    dates = pd.DatetimeIndex(parsed_dates)

    # Fill missing values
    p_raw = df["P"].copy()
    etpot_raw = df["ETpot"].copy()
    q_raw = df["Q"].copy()

    if p_raw.isna().any():
        p_raw = p_raw.fillna(0.0)
    if etpot_raw.isna().any():
        etpot_raw = etpot_raw.interpolate(method="linear")
    if q_raw.isna().any():
        q_raw = q_raw.interpolate(method="linear")

    # External fluxes (zero by default)
    n = len(df)
    fxg = np.zeros(n)
    fxs = np.zeros(n)
    hs_min = np.zeros(n)
    dg_obs = np.zeros(n)

    # Cumulative sums (prepend 0)
    p_cum = np.concatenate([[0.0], np.cumsum(p_raw.values)])
    etpot_cum = np.concatenate([[0.0], np.cumsum(etpot_raw.values)])
    q_cum = np.concatenate([[0.0], np.cumsum(q_raw.values)])
    fxg_cum = np.concatenate([[0.0], np.cumsum(fxg)])
    fxs_cum = np.concatenate([[0.0], np.cumsum(fxs)])
    hs_min_series = np.concatenate([hs_min, [hs_min[-1]]])
    dg_obs_series = np.concatenate([dg_obs, [hs_min[-1]]])

    # Convert dates to seconds since epoch (1970-01-01)
    epoch = pd.Timestamp("1970-01-01")
    date_seconds = (dates - epoch).total_seconds().values

    # Create output date vector (with trailing date added)
    last_dt_sec = date_seconds[-1] - date_seconds[-2]
    forcing_date = np.concatenate([date_seconds,
                                   [date_seconds[-1] + last_dt_sec * dt]])

    # Subsample at the given dt
    nr = (len(forcing_date) - 1) // dt
    idx = np.concatenate([[0], np.arange(1, nr * dt + 1, dt)])
    output_date = forcing_date[idx]

    return CumsumData(
        p=p_cum,
        etpot=etpot_cum,
        q=q_cum,
        fxg=fxg_cum,
        fxs=fxs_cum,
        hs_min=hs_min_series,
        dg_obs=dg_obs_series,
        output_date=output_date,
    )


def get_inputs_t(data: CumsumData) -> Tuple[np.ndarray, np.ndarray]:
    """Extract per-timestep precipitation and ET from cumulative data.

    Computes the incremental values by differencing consecutive entries
    at the output dates.

    Parameters:
        data: CumsumData instance.

    Returns:
        Tuple (p_t, etpot_t) of per-timestep arrays, each of length T.
    """
    od = data.output_date
    # Interpolate cumulative values at output dates
    t1 = od[:-1]
    t2 = od[1:]

    p_t = np.interp(t2, od, data.p) - np.interp(t1, od, data.p)
    etpot_t = np.interp(t2, od, data.etpot) - np.interp(t1, od, data.etpot)

    return p_t, etpot_t


def get_q_obs(data: CumsumData) -> np.ndarray:
    """Extract per-timestep observed discharge from cumulative data.

    Parameters:
        data: CumsumData instance.

    Returns:
        Array of per-timestep observed discharge, length T.
    """
    od = data.output_date
    t1 = od[:-1]
    t2 = od[1:]
    q_obs = np.interp(t2, od, data.q) - np.interp(t1, od, data.q)
    return q_obs


def load_and_preprocess(filepath: str,
                        date_start: int = 1999010101,
                        date_end: int = 2010010101,
                        dt: int = 1
                        ) -> Tuple[CumsumData, np.ndarray, np.ndarray, np.ndarray]:
    """Load data and return everything needed for a WALRUS experiment.

    Parameters:
        filepath: Path to PEQ_Regge_hour.txt.
        date_start, date_end: Date range as YYYYMMDDhh integers.
        dt: Timestep multiplier.

    Returns:
        Tuple (data_cumsum, p_t, etpot_t, q_obs):
            data_cumsum: Preprocessed cumulative-sum data.
            p_t: Per-timestep precipitation, length T.
            etpot_t: Per-timestep potential ET, length T.
            q_obs: Per-timestep observed discharge, length T.
    """
    df = load_peq_data(filepath, date_start, date_end)
    data_cumsum = preprocess_walrus(df, dt)
    p_t, etpot_t = get_inputs_t(data_cumsum)
    q_obs = get_q_obs(data_cumsum)
    return data_cumsum, p_t, etpot_t, q_obs
