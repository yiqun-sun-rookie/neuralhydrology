"""Auditable high-performance-computing transport for the six new calibrations.

Only the six expensive six- and twelve-month calibration workers run remotely.
The full preparation gate and every downstream scientific stage remain in the
formal local attempt.  Remote products enter that attempt only through the
exclusive importer in this module.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import shutil
import subprocess
import sys
import time
import traceback
from typing import Mapping

import numpy as np
import torch

from . import prepare as preparation
from .calibration import (
    CANONICAL_NOISE_DESIGN,
    CANONICAL_NOISE_FILE_SHA256,
    CANONICAL_PARAMETER_DESIGN,
    CANONICAL_PARAMETER_FILE_SHA256,
    EXPECTED_VERSIONS,
    missing_calibration_specs,
)
from .common import (
    ARCHIVE,
    FORMAL_ATTEMPT,
    FORMAL_OUTPUT,
    HPC_CALIBRATION_SLURM,
    HPC_PACKAGE_SLURM,
    PACKAGE,
    PLAN,
    PROJECT,
    RAW_DATA,
    REPAIRED,
    TEST,
    read_json,
    sha256,
    write_json_new,
)
from .contract import (
    ARCHIVE_AUDIT_SHA256,
    ARCHIVE_MANIFEST_SHA256,
    RAW_DATA_SHA256,
)


AUTHORIZATION_NAME = "calibration_authorization.json"
CAPSULE_MANIFEST_NAME = "capsule_manifest.json"
FORMAL_DEPLOYMENT_BINDING_NAME = "hpc_deployment_binding.json"
TRANSPORT_RECEIPT_NAME = "hpc_transport_verification_receipt.json"
TRANSPORT_FAILURE_NAME = "hpc_transport_verification_failed.json"
TRANSPORT_EVIDENCE_DIRECTORY = "hpc_transport_evidence"
REMOTE_SCHEMA = "regge_record_length_hpc_calibration_batch_v02"
FORMAL_ATTEMPT_RELATIVE = f"output/regge_length/{FORMAL_ATTEMPT}"
REMOTE_CALIBRATION_NAME = "formal_calibration_003"
RETURN_ARCHIVE_NAME = f"{REMOTE_CALIBRATION_NAME}.tar.zst"
RETURN_ENCRYPTED_NAME = f"{RETURN_ARCHIVE_NAME}.cms"
REMOTE_RUNTIME_ROOT = PurePosixPath(
    "/data1/home/sunyiq/regge_record_length_20260929_001/runtime_probe_005"
)
REMOTE_RUNTIME_EVIDENCE_ROOT = PurePosixPath(
    "/data1/home/sunyiq/regge_record_length_20260929_001/runtime_stage_005"
)
REMOTE_RUNTIME_READY_SHA256 = (
    "93229f625533fbec6b0a04ddb70b3b47c3c725cab4a9f99aa4f97c1c9280f463"
)
REMOTE_RUNTIME_FREEZE_SHA256 = (
    "15fd95da01a1f5884aa4a225165942b43f5db405a4f0d75fd400dac6468a82ac"
)
EXPECTED_AUXILIARY_VERSIONS = {
    "pandas": "2.3.2", "psutil": "5.9.0",
    "threadpoolctl": "3.6.0", "pytest": "9.1.1",
}
EXPECTED_SLURM = {
    "job_name": "regge_rl_cal_003", "cpus_per_task": "4",
}
EXPECTED_BYTECODE_POLICY = {
    "command_flag": "-B",
    "environment_variable": "PYTHONDONTWRITEBYTECODE=1",
}
_THREAD_ENVIRONMENT = (
    "OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS",
)
_PREPARATION_FILES = (
    "config.json",
    "source_binding.json",
    "origin_manifest.npz",
    "resource_plan.json",
    "preparation_receipt.json",
)


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _event(path: Path, event: str, **fields) -> None:
    with Path(path).open("a", encoding="utf-8") as target:
        target.write(json.dumps(
            {"utc": _utc(), "event": event, **fields},
            ensure_ascii=False, allow_nan=False,
        ) + "\n")


def _copy_file_new(source: Path, target: Path) -> None:
    source, target = Path(source), Path(target)
    if not source.is_file():
        raise FileNotFoundError(source)
    target.parent.mkdir(parents=True, exist_ok=True)
    with source.open("rb") as opened, target.open("xb") as saved:
        shutil.copyfileobj(opened, saved, length=1024 * 1024)
    if sha256(target) != sha256(source):
        raise RuntimeError(f"copied file differs: {source}")


def _write_success_atomic(path: Path, payload: Mapping) -> None:
    path = Path(path)
    if path.exists():
        raise FileExistsError(path)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{time.time_ns()}.tmp")
    data = (json.dumps(
        dict(payload), ensure_ascii=False, indent=2, allow_nan=False,
    ) + "\n").encode("utf-8")
    try:
        with temporary.open("xb") as target:
            target.write(data)
            target.flush()
            os.fsync(target.fileno())
        if json.loads(temporary.read_text(encoding="utf-8")) != dict(payload):
            raise RuntimeError("staged success receipt differs")
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def _expected_ids() -> list[str]:
    return [row["exp_id"] for row in missing_calibration_specs()]


def _batch_manifest_files(root: Path) -> dict[str, str]:
    """Hash every batch file except the two root-level self-references."""
    root = Path(root)
    excluded = {
        root / "batch_manifest.json",
        root / "batch_receipt.json",
    }
    return {
        path.relative_to(root).as_posix(): sha256(path)
        for path in sorted(root.rglob("*"))
        if path.is_file() and path not in excluded
    }


def _authorization_payload(
        formal_root: Path, output_recipient_certificate: Path,
        hpc_signing_public_key: Path) -> dict:
    formal_root = Path(formal_root)
    output_recipient_certificate = Path(output_recipient_certificate)
    hpc_signing_public_key = Path(hpc_signing_public_key)
    if formal_root.resolve() != FORMAL_OUTPUT.resolve():
        raise ValueError("authorization root is not the frozen formal attempt")
    preparation.verify_prepared()
    if not output_recipient_certificate.is_file():
        raise FileNotFoundError("output recipient certificate is missing")
    if not hpc_signing_public_key.is_file():
        raise FileNotFoundError("HPC signing public key is missing")
    receipt = read_json(formal_root / "preparation_receipt.json")
    if set(receipt.get("files", {})) != set(_PREPARATION_FILES[:-1]):
        raise RuntimeError("preparation receipt frozen-file set differs")
    return {
        "schema": "regge_record_length_hpc_calibration_authorization_v02",
        "formal_attempt": FORMAL_ATTEMPT,
        "formal_attempt_relative": FORMAL_ATTEMPT_RELATIVE,
        "authorized_remote_scope": "six_new_calibration_workers_only",
        "expected_experiments": _expected_ids(),
        "retry_policy": "none",
        "remote_execution_order": "sequential_one_process_per_window",
        "scientific_device": "cpu",
        "scientific_cpu_threads": 1,
        "graphics_processor_required": False,
        "versions": dict(EXPECTED_VERSIONS),
        "auxiliary_versions": dict(EXPECTED_AUXILIARY_VERSIONS),
        "scheduler_contract": dict(EXPECTED_SLURM),
        "python_bytecode_policy": dict(EXPECTED_BYTECODE_POLICY),
        "runtime_root": str(REMOTE_RUNTIME_ROOT),
        "runtime_ready_path": str(
            REMOTE_RUNTIME_EVIDENCE_ROOT / "runtime_ready.json"
        ),
        "runtime_ready_sha256": REMOTE_RUNTIME_READY_SHA256,
        "runtime_freeze_path": str(
            REMOTE_RUNTIME_EVIDENCE_ROOT / "pip_freeze.txt"
        ),
        "runtime_freeze_sha256": REMOTE_RUNTIME_FREEZE_SHA256,
        "preparation_receipt_sha256": sha256(
            formal_root / "preparation_receipt.json"
        ),
        "preparation_frozen_files": dict(receipt["files"]),
        "plan_sha256": sha256(PLAN),
        "raw_data_sha256": RAW_DATA_SHA256,
        "archive_manifest_sha256": ARCHIVE_MANIFEST_SHA256,
        "archive_audit_sha256": ARCHIVE_AUDIT_SHA256,
        "canonical_parameter_design_file_sha256":
            CANONICAL_PARAMETER_FILE_SHA256,
        "canonical_noise_design_file_sha256": CANONICAL_NOISE_FILE_SHA256,
        "output_recipient_certificate_sha256": sha256(
            output_recipient_certificate
        ),
        "hpc_signing_public_key_sha256": sha256(hpc_signing_public_key),
        "remote_success_is_not_formal_import": True,
        "formal_import_required_before_selection": True,
    }


def _capsule_sources(
        formal_root: Path, output_recipient_certificate: Path,
        hpc_signing_public_key: Path) -> list[tuple[Path, str]]:
    records: list[tuple[Path, str]] = []
    for source in sorted(PACKAGE.glob("*.py")) + sorted(PACKAGE.glob("*.npy")):
        records.append((source, f"project/python/regge_record_length_study/{source.name}"))
    runtime = PROJECT / "python/regge_zero_probability_repair/runtime"
    for source in sorted(runtime.rglob("*")):
        if source.is_file() and source.suffix in (".py", ".json"):
            relative = source.relative_to(runtime).as_posix()
            records.append((source, f"project/python/regge_zero_probability_repair/runtime/{relative}"))
    for name in ("__init__.py", "data_loader.py"):
        source = PROJECT / "python/imm_da" / name
        records.append((source, f"project/python/imm_da/{name}"))
    records.extend([
        (PROJECT / "python/run_regge_record_length_study.py",
         "project/python/run_regge_record_length_study.py"),
        (PROJECT / "python/run_regge_record_length_hpc_calibration.py",
         "project/python/run_regge_record_length_hpc_calibration.py"),
        (RAW_DATA, "project/forecast/data/PEQ_Regge_hour.txt"),
        (REPAIRED / "source_binding.json",
         "project/output/regge_zero_prob/20260929-002/source_binding.json"),
        (PLAN,
         "project/docs/superpowers/plans/2026-09-29-regge-record-length-effect-v02.md"),
        (TEST, "project/python/tests/test_regge_record_length_study.py"),
        (ARCHIVE / "manifest.json",
         "core/results/regge_short_record_calibration_v03_recovery/"
         "20260920-regge-short-record-recovery-v03-001/manifest.json"),
        (ARCHIVE / "audit.json",
         "core/results/regge_short_record_calibration_v03_recovery/"
         "20260920-regge-short-record-recovery-v03-001/audit.json"),
        (ARCHIVE / "inputs.npz",
         "core/results/regge_short_record_calibration_v03_recovery/"
         "20260920-regge-short-record-recovery-v03-001/inputs.npz"),
        (output_recipient_certificate, "output_recipient_certificate.pem"),
        (hpc_signing_public_key, "hpc_signing_public_key.pem"),
    ])
    for source in (HPC_CALIBRATION_SLURM, HPC_PACKAGE_SLURM):
        records.append((source, f"hpc/{source.name}"))
    for name in _PREPARATION_FILES:
        records.append((
            Path(formal_root) / name,
            f"project/{FORMAL_ATTEMPT_RELATIVE}/{name}",
        ))
    destinations = [relative for _source, relative in records]
    if len(destinations) != len(set(destinations)):
        raise RuntimeError("capsule destination list contains duplicates")
    return records


def build_capsule(
        capsule_root: Path, output_recipient_certificate: Path,
        hpc_signing_public_key: Path,
        formal_root: Path = FORMAL_OUTPUT) -> Path:
    """Build one exclusive, content-addressed, calibration-only capsule."""
    capsule_root = Path(capsule_root)
    if capsule_root.exists():
        raise FileExistsError(capsule_root)
    capsule_root.parent.mkdir(parents=True, exist_ok=True)
    capsule_root.mkdir(exist_ok=False)
    try:
        authorization = _authorization_payload(
            formal_root, output_recipient_certificate, hpc_signing_public_key,
        )
        for source, relative in _capsule_sources(
                formal_root, output_recipient_certificate,
                hpc_signing_public_key):
            _copy_file_new(source, capsule_root / relative)
        write_json_new(capsule_root / AUTHORIZATION_NAME, authorization)
        files = {
            path.relative_to(capsule_root).as_posix(): sha256(path)
            for path in sorted(capsule_root.rglob("*")) if path.is_file()
        }
        write_json_new(capsule_root / CAPSULE_MANIFEST_NAME, {
            "schema": "regge_record_length_hpc_capsule_manifest_v02",
            "file_count": len(files),
            "files": files,
            "authorization_sha256": sha256(capsule_root / AUTHORIZATION_NAME),
            "contains_historical_three_or_twenty_four_month_raw_arrays": False,
            "scope": (
                "calibration code, frozen numerical runtime, preparation "
                "evidence, test, plan, and transport public credentials"
            ),
        })
        verify_capsule(capsule_root)
        return capsule_root
    except BaseException:
        try:
            write_json_new(capsule_root / "capsule_build_failed.json", {
                "schema": "regge_record_length_hpc_capsule_failure_v01",
                "passed": False,
                "error": traceback.format_exc(),
                "automatic_retry": False,
            })
        finally:
            raise


def verify_capsule(capsule_root: Path) -> dict:
    capsule_root = Path(capsule_root)
    manifest_path = capsule_root / CAPSULE_MANIFEST_NAME
    manifest = read_json(manifest_path)
    if (manifest.get("schema")
            != "regge_record_length_hpc_capsule_manifest_v02"):
        raise RuntimeError("capsule manifest schema differs")
    actual = {
        path.relative_to(capsule_root).as_posix(): sha256(path)
        for path in sorted(capsule_root.rglob("*"))
        if path.is_file() and path.name != CAPSULE_MANIFEST_NAME
    }
    if (actual != manifest.get("files")
            or len(actual) != manifest.get("file_count")):
        raise RuntimeError("capsule file set or hashes differ")
    authorization_path = capsule_root / AUTHORIZATION_NAME
    if sha256(authorization_path) != manifest.get("authorization_sha256"):
        raise RuntimeError("capsule authorization changed")
    authorization = read_json(authorization_path)
    if (authorization.get("schema")
            != "regge_record_length_hpc_calibration_authorization_v02"
            or authorization.get("expected_experiments") != _expected_ids()
            or authorization.get("versions") != EXPECTED_VERSIONS
            or authorization.get("auxiliary_versions")
            != EXPECTED_AUXILIARY_VERSIONS
            or authorization.get("scheduler_contract") != EXPECTED_SLURM
            or authorization.get("python_bytecode_policy")
            != EXPECTED_BYTECODE_POLICY
            or authorization.get("runtime_root") != str(REMOTE_RUNTIME_ROOT)
            or authorization.get("runtime_ready_sha256")
            != REMOTE_RUNTIME_READY_SHA256
            or authorization.get("runtime_freeze_sha256")
            != REMOTE_RUNTIME_FREEZE_SHA256
            or authorization.get("raw_data_sha256") != RAW_DATA_SHA256
            or authorization.get("retry_policy") != "none"):
        raise RuntimeError("capsule authorization contract differs")
    project = capsule_root / "project"
    prepared = project / FORMAL_ATTEMPT_RELATIVE
    receipt_path = prepared / "preparation_receipt.json"
    if sha256(receipt_path) != authorization["preparation_receipt_sha256"]:
        raise RuntimeError("capsule preparation receipt differs")
    receipt = read_json(receipt_path)
    for name, digest in authorization["preparation_frozen_files"].items():
        if sha256(prepared / name) != digest:
            raise RuntimeError(f"capsule frozen preparation file differs: {name}")
    checks = {
        project / "forecast/data/PEQ_Regge_hour.txt": RAW_DATA_SHA256,
        capsule_root / "core/results/regge_short_record_calibration_v03_recovery/"
        "20260920-regge-short-record-recovery-v03-001/manifest.json":
            ARCHIVE_MANIFEST_SHA256,
        capsule_root / "core/results/regge_short_record_calibration_v03_recovery/"
        "20260920-regge-short-record-recovery-v03-001/audit.json":
            ARCHIVE_AUDIT_SHA256,
        project / "python/regge_record_length_study/canonical_parameter_design.npy":
            CANONICAL_PARAMETER_FILE_SHA256,
        project / "python/regge_record_length_study/canonical_noise_design.npy":
            CANONICAL_NOISE_FILE_SHA256,
        capsule_root / "output_recipient_certificate.pem":
            authorization["output_recipient_certificate_sha256"],
        capsule_root / "hpc_signing_public_key.pem":
            authorization["hpc_signing_public_key_sha256"],
    }
    for path, digest in checks.items():
        if not path.is_file() or sha256(path) != digest:
            raise RuntimeError(f"capsule scientific input differs: {path}")
    if receipt.get("passed") is not True:
        raise RuntimeError("capsule preparation receipt did not pass")
    return authorization


def write_deployment_binding(
        capsule_root: Path, capsule_archive: Path,
        hpc_signing_public_key: Path, destination: Path,
        formal_root: Path = FORMAL_OUTPUT) -> Path:
    """Write the exclusive local trust anchor before anything is deployed."""
    capsule_root = Path(capsule_root)
    capsule_archive = Path(capsule_archive)
    hpc_signing_public_key = Path(hpc_signing_public_key)
    destination = Path(destination)
    expected_destination = Path(formal_root) / FORMAL_DEPLOYMENT_BINDING_NAME
    if destination.resolve() != expected_destination.resolve():
        raise ValueError("deployment binding must use the fixed formal-attempt path")
    authorization = verify_capsule(capsule_root)
    if not capsule_archive.is_file():
        raise FileNotFoundError(capsule_archive)
    if (not hpc_signing_public_key.is_file()
            or sha256(hpc_signing_public_key)
            != authorization["hpc_signing_public_key_sha256"]):
        raise RuntimeError("deployment signing public key differs from capsule")
    payload = {
        "schema": "regge_record_length_hpc_deployment_binding_v01",
        "formal_attempt": FORMAL_ATTEMPT,
        "formal_attempt_relative": FORMAL_ATTEMPT_RELATIVE,
        "created_utc": _utc(),
        "capsule_manifest_sha256": sha256(
            capsule_root / CAPSULE_MANIFEST_NAME
        ),
        "authorization_sha256": sha256(capsule_root / AUTHORIZATION_NAME),
        "capsule_archive_sha256": sha256(capsule_archive),
        "capsule_archive_bytes": capsule_archive.stat().st_size,
        "hpc_signing_public_key_sha256": sha256(hpc_signing_public_key),
        "output_recipient_certificate_sha256": authorization[
            "output_recipient_certificate_sha256"
        ],
        "preparation_receipt_sha256": authorization[
            "preparation_receipt_sha256"
        ],
        "plan_sha256": authorization["plan_sha256"],
        "raw_data_sha256": authorization["raw_data_sha256"],
        "runtime_ready_sha256": authorization["runtime_ready_sha256"],
        "runtime_freeze_sha256": authorization["runtime_freeze_sha256"],
        "retry_policy": "none",
    }
    write_json_new(destination, payload)
    return destination


def _verify_deployment_binding(
        binding_path: Path, formal_root: Path = FORMAL_OUTPUT) -> dict:
    binding_path, formal_root = Path(binding_path), Path(formal_root)
    if formal_root.resolve() == FORMAL_OUTPUT.resolve():
        preparation.verify_prepared()
    binding = read_json(binding_path)
    required = {
        "schema": "regge_record_length_hpc_deployment_binding_v01",
        "formal_attempt": FORMAL_ATTEMPT,
        "formal_attempt_relative": FORMAL_ATTEMPT_RELATIVE,
        "plan_sha256": sha256(PLAN),
        "raw_data_sha256": RAW_DATA_SHA256,
        "runtime_ready_sha256": REMOTE_RUNTIME_READY_SHA256,
        "runtime_freeze_sha256": REMOTE_RUNTIME_FREEZE_SHA256,
        "retry_policy": "none",
    }
    if any(binding.get(name) != value for name, value in required.items()):
        raise RuntimeError("local deployment binding differs from frozen contract")
    receipt_path = formal_root / "preparation_receipt.json"
    if (not receipt_path.is_file()
            or sha256(receipt_path) != binding.get("preparation_receipt_sha256")):
        raise RuntimeError("local deployment binding preparation receipt differs")
    for name in (
            "capsule_manifest_sha256", "authorization_sha256",
            "capsule_archive_sha256", "hpc_signing_public_key_sha256",
            "output_recipient_certificate_sha256"):
        value = binding.get(name)
        if (not isinstance(value, str) or len(value) != 64
                or any(character not in "0123456789abcdef" for character in value)):
            raise RuntimeError(f"local deployment binding hash is invalid: {name}")
    if not isinstance(binding.get("capsule_archive_bytes"), int) \
            or binding["capsule_archive_bytes"] <= 0:
        raise RuntimeError("local deployment archive size is invalid")
    return binding


def _observed_environment() -> dict:
    return {
        "python": platform.python_version(),
        "numpy": np.__version__,
        "torch": torch.__version__,
        "torch_threads": torch.get_num_threads(),
        "cuda_available": torch.cuda.is_available(),
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        "slurm_job_name": os.environ.get("SLURM_JOB_NAME"),
        "slurm_cpus_per_task": os.environ.get("SLURM_CPUS_PER_TASK"),
        "python_prefix": str(Path(sys.prefix).resolve()),
        "python_dont_write_bytecode_flag": bool(
            sys.flags.dont_write_bytecode
        ),
        "python_dont_write_bytecode_environment": os.environ.get(
            "PYTHONDONTWRITEBYTECODE"
        ),
        "thread_environment": {
            name: os.environ.get(name) for name in _THREAD_ENVIRONMENT
        },
        "mkl_threading_layer": os.environ.get("MKL_THREADING_LAYER"),
        "mkl_service_force_intel": os.environ.get("MKL_SERVICE_FORCE_INTEL"),
        "hostname": platform.node(),
    }


def _verify_runtime_environment(authorization: Mapping) -> dict:
    import pandas
    import psutil
    import pytest
    import threadpoolctl

    observed = _observed_environment()
    if authorization.get("python_bytecode_policy") != EXPECTED_BYTECODE_POLICY:
        raise RuntimeError("authorized Python bytecode policy differs")
    versions = {name: observed[name] for name in ("python", "numpy", "torch")}
    if versions != EXPECTED_VERSIONS:
        raise RuntimeError(f"remote environment versions differ: {versions}")
    auxiliary = {
        "pandas": pandas.__version__, "psutil": psutil.__version__,
        "threadpoolctl": threadpoolctl.__version__, "pytest": pytest.__version__,
    }
    observed["auxiliary_versions"] = auxiliary
    observed["loaded_threadpools"] = threadpoolctl.threadpool_info()
    job_id = observed.get("slurm_job_id")
    if (not isinstance(job_id, str) or not job_id.isdecimal()
            or observed.get("slurm_job_name") != EXPECTED_SLURM["job_name"]
            or observed.get("slurm_cpus_per_task")
            != EXPECTED_SLURM["cpus_per_task"]):
        raise RuntimeError("remote execution is not the authorized Slurm allocation")
    if Path(sys.prefix).resolve() != Path(authorization["runtime_root"]):
        raise RuntimeError("remote Python runtime prefix differs")
    if auxiliary != EXPECTED_AUXILIARY_VERSIONS:
        raise RuntimeError(f"remote auxiliary versions differ: {auxiliary}")
    for path_key, hash_key in (
            ("runtime_ready_path", "runtime_ready_sha256"),
            ("runtime_freeze_path", "runtime_freeze_sha256")):
        evidence = Path(authorization[path_key])
        if not evidence.is_file() or sha256(evidence) != authorization[hash_key]:
            raise RuntimeError(f"remote runtime evidence differs: {path_key}")
    if (torch.cuda.is_available() or torch.get_num_threads() != 1
            or observed["python_dont_write_bytecode_flag"] is not True
            or observed["python_dont_write_bytecode_environment"] != "1"
            or any(value != "1" for value in observed["thread_environment"].values())
            or any(int(pool.get("num_threads", -1)) != 1
                   for pool in observed["loaded_threadpools"])
            or observed["mkl_threading_layer"] != "GNU"
            or observed["mkl_service_force_intel"] != "1"):
        raise RuntimeError(
            "remote CPU, graphics-processor, thread, or bytecode contract differs"
        )
    return observed


def _verify_worker(directory: Path, exp_id: str,
                   stdout_path: Path, stderr_path: Path) -> dict:
    directory = Path(directory)
    receipt_path = directory / "receipt.json"
    process_path = directory / "process.json"
    if not all(path.is_file() for path in (
            receipt_path, process_path, stdout_path, stderr_path)):
        raise RuntimeError(f"remote worker evidence is incomplete: {exp_id}")
    receipt = read_json(receipt_path)
    process = read_json(process_path)
    if (receipt.get("schema") != "regge_record_length_calibration_receipt_v01"
            or receipt.get("status") != "complete"
            or receipt.get("passed") is not True
            or receipt.get("exp_id") != exp_id
            or receipt.get("exit_code") != 0
            or process.get("exp_id") != exp_id
            or process.get("exit_code") != 0
            or process.get("stdout_sha256") != sha256(stdout_path)
            or process.get("stderr_sha256") != sha256(stderr_path)):
        raise RuntimeError(f"remote worker success evidence differs: {exp_id}")
    files = receipt.get("files")
    if not isinstance(files, Mapping) or set(files) != {
            "raw.npz", "result.json", "events.jsonl"}:
        raise RuntimeError(f"remote worker file receipt differs: {exp_id}")
    for name, digest in files.items():
        if not (directory / name).is_file() or sha256(directory / name) != digest:
            raise RuntimeError(f"remote worker output changed: {exp_id}: {name}")
    result = read_json(directory / "result.json")
    environment = receipt.get("environment", {})
    input_hashes = receipt.get("input_source_hashes", {})
    if (result.get("status") != "complete"
            or result.get("exp_id") != exp_id
            or environment.get("versions") != EXPECTED_VERSIONS
            or environment.get("dtype_required") != "float64"
            or environment.get("device_required") != "cpu"
            or environment.get("gradients_observed") is not False
            or environment.get("thread_settings", {}).get(
                "torch_threads_observed") != 1
            or input_hashes.get("raw_data") != RAW_DATA_SHA256
            or any(not isinstance(input_hashes.get(name), str)
                   for name in (
                       "warmup_timestamps", "warmup_forcing",
                       "calibration_timestamps", "calibration_forcing",
                       "calibration_observations",
                   ))):
        raise RuntimeError(f"remote worker scientific contract differs: {exp_id}")
    from .selection import validate_new_calibration_artifact
    scientific_record = validate_new_calibration_artifact(
        directory, exp_id,
        receipt_sha256=sha256(receipt_path),
        process_sha256=sha256(process_path),
    )
    scientific_payload = json.dumps(
        scientific_record, sort_keys=True, separators=(",", ":"),
        ensure_ascii=False, allow_nan=False,
    ).encode("utf-8")
    return {
        "exp_id": exp_id,
        "returncode": 0,
        "receipt_status": "complete",
        "receipt_sha256": sha256(receipt_path),
        "process_sha256": sha256(process_path),
        "raw_sha256": files["raw.npz"],
        "result_sha256": files["result.json"],
        "stdout_sha256": sha256(stdout_path),
        "stderr_sha256": sha256(stderr_path),
        "scientific_validation": "full_reconstruction_passed",
        "scientific_validation_sha256": hashlib.sha256(
            scientific_payload
        ).hexdigest(),
        "selected_parameter_id": scientific_record["parameter_id"],
        "selected_noise_id": scientific_record["noise_id"],
    }


def run_remote_batch(capsule_root: Path, output_root: Path) -> Path:
    """Run six child processes sequentially and never retry a failed window."""
    capsule_root, output_root = Path(capsule_root), Path(output_root)
    if output_root.exists():
        raise FileExistsError(output_root)
    expected_ids = _expected_ids()
    started = time.perf_counter()
    output_root.parent.mkdir(parents=True, exist_ok=True)
    output_root.mkdir(exist_ok=False)
    events = output_root / "events.jsonl"
    events.touch(exist_ok=False)
    attempts: list[dict] = []
    completed: list[dict] = []
    current = None
    try:
        authorization = verify_capsule(capsule_root)
        _copy_file_new(capsule_root / AUTHORIZATION_NAME,
                       output_root / AUTHORIZATION_NAME)
        environment = _verify_runtime_environment(authorization)
        capsule_manifest_sha256 = sha256(
            capsule_root / CAPSULE_MANIFEST_NAME
        )
        batch_started_path = output_root / "batch_started.json"
        write_json_new(batch_started_path, {
            "schema": f"{REMOTE_SCHEMA}_start",
            "status": "started",
            "started_utc": _utc(),
            "expected_experiments": expected_ids,
            "retry_policy": "none",
            "environment": environment,
            "capsule_manifest_sha256": capsule_manifest_sha256,
            "authorization_sha256": sha256(
                capsule_root / AUTHORIZATION_NAME
            ),
        })
        _event(events, "remote_calibration_batch_started", count=6)
        project = capsule_root / "project"
        entry = project / "python/run_regge_record_length_study.py"
        calibration_root = output_root / "calibration"
        logs = output_root / "calibration_process_logs"
        logs.mkdir(exist_ok=False)
        for spec in missing_calibration_specs():
            current = spec["exp_id"]
            destination = calibration_root / current
            stdout_path = logs / f"{current}.stdout.log"
            stderr_path = logs / f"{current}.stderr.log"
            attempt = {
                "exp_id": current, "status": "started",
                "started_utc": _utc(), "returncode": None,
                "process_evidence_present": False,
                "receipt_evidence_present": False,
                "stdout_present": False, "stderr_present": False,
            }
            attempts.append(attempt)
            _event(events, "remote_calibration_worker_started", exp_id=current)
            command = [
                sys.executable, "-B", str(entry), "_calibrate-one",
                "--exp-id", current,
                "--destination", str(destination),
                "--stdout", str(stdout_path),
                "--stderr", str(stderr_path),
            ]
            process = subprocess.run(command, cwd=project, check=False)
            attempt.update(
                returncode=int(process.returncode),
                finished_utc=_utc(),
                process_evidence_present=(destination / "process.json").is_file(),
                receipt_evidence_present=(destination / "receipt.json").is_file(),
                stdout_present=stdout_path.is_file(),
                stderr_present=stderr_path.is_file(),
            )
            if process.returncode != 0:
                attempt["status"] = "failed"
                raise RuntimeError(
                    f"remote calibration worker failed: {current}; "
                    f"returncode={process.returncode}"
                )
            record = _verify_worker(
                destination, current, stdout_path, stderr_path,
            )
            completed.append(record)
            attempt.update(
                status="complete",
                stdout_sha256=record["stdout_sha256"],
                stderr_sha256=record["stderr_sha256"],
            )
            _event(events, "remote_calibration_worker_completed", exp_id=current)
        _event(events, "remote_calibration_batch_completed", count=6)
        manifest_files = _batch_manifest_files(output_root)
        write_json_new(output_root / "batch_manifest.json", {
            "schema": f"{REMOTE_SCHEMA}_manifest",
            "file_count": len(manifest_files),
            "files": manifest_files,
        })
        manifest = read_json(output_root / "batch_manifest.json")
        if any(
            not (output_root / relative).is_file()
            or sha256(output_root / relative) != digest
            for relative, digest in manifest["files"].items()
        ):
            raise RuntimeError("remote calibration batch manifest verification failed")
        _write_success_atomic(output_root / "batch_receipt.json", {
            "schema": f"{REMOTE_SCHEMA}_receipt",
            "status": "complete", "passed": True,
            "finished_utc": _utc(),
            "expected_experiments": expected_ids,
            "started_experiments": expected_ids,
            "attempts": attempts,
            "completed": completed,
            "manifest_sha256": sha256(output_root / "batch_manifest.json"),
            "authorization_sha256": sha256(output_root / AUTHORIZATION_NAME),
            "capsule_manifest_sha256": capsule_manifest_sha256,
            "batch_started_sha256": sha256(batch_started_path),
            "environment": environment,
            "elapsed_seconds": time.perf_counter() - started,
            "remote_success_is_not_formal_import": True,
        })
        return output_root
    except BaseException as error:
        if not (output_root / "batch_failed.json").exists():
            try:
                write_json_new(output_root / "batch_failed.json", {
                    "schema": f"{REMOTE_SCHEMA}_failure",
                    "status": "failed", "passed": False,
                    "failed_utc": _utc(),
                    "current_experiment": current,
                    "attempts": attempts,
                    "completed": completed,
                    "environment": _observed_environment(),
                    "capsule_manifest_sha256": (
                        sha256(capsule_root / CAPSULE_MANIFEST_NAME)
                        if (capsule_root / CAPSULE_MANIFEST_NAME).is_file()
                        else None
                    ),
                    "error": {"type": type(error).__name__, "reason": str(error)},
                    "traceback": traceback.format_exc(),
                    "automatic_retry": False,
                    "elapsed_seconds": time.perf_counter() - started,
                })
            except BaseException as receipt_error:
                error.add_note(
                    "remote batch failure receipt also failed: "
                    f"{type(receipt_error).__name__}: {receipt_error}"
                )
        raise


def write_encrypted_return_manifest(
        package_root: Path, source_root: Path, capsule_root: Path) -> Path:
    """Bind the authenticated encrypted return and its scientific source."""
    package_root, source_root = Path(package_root), Path(source_root)
    capsule_root = Path(capsule_root)
    names = (RETURN_ARCHIVE_NAME, RETURN_ENCRYPTED_NAME)
    if not package_root.is_dir() or not all(
            (package_root / name).is_file() for name in names):
        raise FileNotFoundError("authenticated encrypted return package is incomplete")
    receipt_path = source_root / "batch_receipt.json"
    manifest_path = source_root / "batch_manifest.json"
    started_path = source_root / "batch_started.json"
    receipt = read_json(receipt_path)
    started = read_json(started_path)
    capsule_manifest_sha256 = sha256(
        capsule_root / CAPSULE_MANIFEST_NAME
    )
    authorization_sha256 = sha256(capsule_root / AUTHORIZATION_NAME)
    if (receipt.get("passed") is not True
            or receipt.get("capsule_manifest_sha256")
            != capsule_manifest_sha256
            or receipt.get("authorization_sha256") != authorization_sha256
            or receipt.get("manifest_sha256") != sha256(manifest_path)
            or receipt.get("batch_started_sha256") != sha256(started_path)
            or started.get("capsule_manifest_sha256")
            != capsule_manifest_sha256
            or started.get("authorization_sha256") != authorization_sha256):
        raise RuntimeError("return package source binding differs")
    transport_path = package_root / "transport_manifest.json"
    write_json_new(transport_path, {
        "schema": "regge_record_length_authenticated_return_v02",
        "encryption": "CMS-AuthEnvelopedData-AES-256-GCM",
        "signature": "RSA-PSS-SHA256",
        "source": {
            "capsule_manifest_sha256": capsule_manifest_sha256,
            "authorization_sha256": authorization_sha256,
            "batch_started_sha256": sha256(started_path),
            "batch_manifest_sha256": sha256(manifest_path),
            "batch_receipt_sha256": sha256(receipt_path),
            "slurm_job_id": receipt.get("environment", {}).get(
                "slurm_job_id"
            ),
        },
        "files": {
            name: {
                "sha256": sha256(package_root / name),
                "bytes": (package_root / name).stat().st_size,
            }
            for name in names
        },
        "upload_only": [
            RETURN_ENCRYPTED_NAME,
            "transport_manifest.json",
            "transport_manifest.sig",
        ],
    })
    return transport_path


def verify_return_package(
        package_root: Path, deployment_binding_path: Path,
        hpc_signing_public_key: Path,
        formal_root: Path = FORMAL_OUTPUT) -> dict:
    """Verify the pinned HPC signature before any return data is decrypted."""
    package_root = Path(package_root)
    hpc_signing_public_key = Path(hpc_signing_public_key)
    binding = _verify_deployment_binding(deployment_binding_path, formal_root)
    if (not hpc_signing_public_key.is_file()
            or sha256(hpc_signing_public_key)
            != binding["hpc_signing_public_key_sha256"]):
        raise RuntimeError("return signing key does not match local deployment binding")
    manifest_path = package_root / "transport_manifest.json"
    signature_path = package_root / "transport_manifest.sig"
    encrypted_path = package_root / RETURN_ENCRYPTED_NAME
    if not all(path.is_file() for path in (
            manifest_path, signature_path, encrypted_path)):
        raise FileNotFoundError("signed encrypted return package is incomplete")
    verified = subprocess.run([
        "openssl", "dgst", "-sha256", "-verify",
        str(hpc_signing_public_key), "-signature", str(signature_path),
        "-sigopt", "rsa_padding_mode:pss",
        "-sigopt", "rsa_pss_saltlen:-1", str(manifest_path),
    ], check=False, capture_output=True, text=True)
    if verified.returncode != 0 or "Verified OK" not in verified.stdout:
        raise RuntimeError(
            "HPC return signature verification failed: "
            f"{verified.stdout.strip()} {verified.stderr.strip()}"
        )
    manifest = read_json(manifest_path)
    expected_source = {
        "capsule_manifest_sha256": binding["capsule_manifest_sha256"],
        "authorization_sha256": binding["authorization_sha256"],
    }
    source = manifest.get("source", {})
    encrypted = manifest.get("files", {}).get(encrypted_path.name, {})
    if (manifest.get("schema")
            != "regge_record_length_authenticated_return_v02"
            or manifest.get("encryption")
            != "CMS-AuthEnvelopedData-AES-256-GCM"
            or manifest.get("signature") != "RSA-PSS-SHA256"
            or any(source.get(name) != value
                   for name, value in expected_source.items())
            or manifest.get("upload_only") != [
                RETURN_ENCRYPTED_NAME,
                "transport_manifest.json", "transport_manifest.sig",
            ]
            or encrypted.get("sha256") != sha256(encrypted_path)
            or encrypted.get("bytes") != encrypted_path.stat().st_size):
        raise RuntimeError("signed HPC return manifest differs")
    return {
        "manifest": manifest,
        "manifest_sha256": sha256(manifest_path),
        "signature_sha256": sha256(signature_path),
        "encrypted_payload_sha256": sha256(encrypted_path),
        "deployment_binding_sha256": sha256(deployment_binding_path),
    }


def verify_decrypted_archive(archive_path: Path, transport_manifest: Path) -> dict:
    """Verify authenticated plaintext after CMS decryption and before extraction."""
    archive_path, transport_manifest = Path(archive_path), Path(transport_manifest)
    manifest = read_json(transport_manifest)
    expected = manifest.get("files", {}).get(RETURN_ARCHIVE_NAME, {})
    if (not archive_path.is_file()
            or expected.get("sha256") != sha256(archive_path)
            or expected.get("bytes") != archive_path.stat().st_size):
        raise RuntimeError("decrypted calibration archive differs from signed manifest")
    return {
        "archive_sha256": sha256(archive_path),
        "archive_bytes": archive_path.stat().st_size,
    }


def record_return_transport_verification(
        package_root: Path, decrypted_archive: Path, remote_root: Path,
        hpc_signing_public_key: Path,
        formal_root: Path = FORMAL_OUTPUT) -> Path:
    """Persist the non-skippable local gate between transport and import."""
    package_root, remote_root = Path(package_root), Path(remote_root)
    formal_root = Path(formal_root)
    binding_path = formal_root / FORMAL_DEPLOYMENT_BINDING_NAME
    receipt_path = formal_root / TRANSPORT_RECEIPT_NAME
    failure_path = formal_root / TRANSPORT_FAILURE_NAME
    evidence_root = formal_root / TRANSPORT_EVIDENCE_DIRECTORY
    if any(path.exists() for path in (receipt_path, failure_path, evidence_root)):
        raise FileExistsError("formal transport verification target is not empty")
    started = time.perf_counter()
    try:
        signed = verify_return_package(
            package_root, binding_path, hpc_signing_public_key, formal_root,
        )
        plaintext = verify_decrypted_archive(
            decrypted_archive, package_root / "transport_manifest.json",
        )
        if (remote_root / "batch_failed.json").exists():
            raise RuntimeError("returned calibration contains a batch failure receipt")
        source = signed["manifest"].get("source", {})
        remote_files = {
            "authorization_sha256": remote_root / AUTHORIZATION_NAME,
            "batch_started_sha256": remote_root / "batch_started.json",
            "batch_manifest_sha256": remote_root / "batch_manifest.json",
            "batch_receipt_sha256": remote_root / "batch_receipt.json",
        }
        for field, path in remote_files.items():
            if not path.is_file() or source.get(field) != sha256(path):
                raise RuntimeError(
                    f"extracted return differs from signed transport: {field}"
                )
        evidence_root.mkdir(exist_ok=False)
        evidence_sources = {
            "transport_manifest.json": package_root / "transport_manifest.json",
            "transport_manifest.sig": package_root / "transport_manifest.sig",
            "hpc_signing_public.pem": Path(hpc_signing_public_key),
        }
        for name, path in evidence_sources.items():
            _copy_file_new(path, evidence_root / name)
        binding = _verify_deployment_binding(binding_path, formal_root)
        payload = {
            "schema": "regge_record_length_transport_verification_receipt_v01",
            "status": "complete", "passed": True,
            "verified_utc": _utc(),
            "deployment_binding_sha256": sha256(binding_path),
            "capsule_manifest_sha256": binding["capsule_manifest_sha256"],
            "authorization_sha256": binding["authorization_sha256"],
            "transport_manifest_sha256": signed["manifest_sha256"],
            "transport_signature_sha256": signed["signature_sha256"],
            "encrypted_payload_sha256": signed[
                "encrypted_payload_sha256"
            ],
            "decrypted_archive_sha256": plaintext["archive_sha256"],
            "decrypted_archive_bytes": plaintext["archive_bytes"],
            "signed_source": dict(source),
            "formal_transport_evidence": {
                name: sha256(evidence_root / name)
                for name in evidence_sources
            },
            "signature_verified_with_pinned_hpc_key": True,
            "authenticated_encryption_plaintext_verified": True,
            "extracted_batch_identity_verified": True,
            "automatic_retry": False,
            "elapsed_seconds": time.perf_counter() - started,
        }
        _write_success_atomic(receipt_path, payload)
        return receipt_path
    except BaseException as error:
        if not failure_path.exists():
            try:
                write_json_new(failure_path, {
                    "schema": "regge_record_length_transport_verification_failure_v01",
                    "status": "failed", "passed": False,
                    "failed_utc": _utc(),
                    "error": {"type": type(error).__name__, "reason": str(error)},
                    "traceback": traceback.format_exc(),
                    "automatic_retry": False,
                    "elapsed_seconds": time.perf_counter() - started,
                })
            except BaseException as receipt_error:
                error.add_note(
                    "transport verification failure receipt also failed: "
                    f"{type(receipt_error).__name__}: {receipt_error}"
                )
        raise


def _verify_transport_verification_receipt(
        remote_root: Path, formal_root: Path = FORMAL_OUTPUT) -> dict:
    """Recheck the fixed local trust receipt before opening the import gate."""
    remote_root, formal_root = Path(remote_root), Path(formal_root)
    binding_path = formal_root / FORMAL_DEPLOYMENT_BINDING_NAME
    receipt_path = formal_root / TRANSPORT_RECEIPT_NAME
    failure_path = formal_root / TRANSPORT_FAILURE_NAME
    evidence_root = formal_root / TRANSPORT_EVIDENCE_DIRECTORY
    if failure_path.exists():
        raise RuntimeError("transport verification has a failure receipt")
    if not receipt_path.is_file():
        raise FileNotFoundError("transport verification success receipt is missing")
    binding = _verify_deployment_binding(binding_path, formal_root)
    receipt = read_json(receipt_path)
    evidence = receipt.get("formal_transport_evidence", {})
    expected_evidence = {
        "transport_manifest.json", "transport_manifest.sig",
        "hpc_signing_public.pem",
    }
    if (receipt.get("schema")
            != "regge_record_length_transport_verification_receipt_v01"
            or receipt.get("status") != "complete"
            or receipt.get("passed") is not True
            or receipt.get("deployment_binding_sha256") != sha256(binding_path)
            or receipt.get("capsule_manifest_sha256")
            != binding["capsule_manifest_sha256"]
            or receipt.get("authorization_sha256")
            != binding["authorization_sha256"]
            or set(evidence) != expected_evidence
            or any(not (evidence_root / name).is_file()
                   or sha256(evidence_root / name) != digest
                   for name, digest in evidence.items())):
        raise RuntimeError("formal transport verification receipt differs")
    manifest_path = evidence_root / "transport_manifest.json"
    signature_path = evidence_root / "transport_manifest.sig"
    signing_key = evidence_root / "hpc_signing_public.pem"
    if (sha256(manifest_path) != receipt.get("transport_manifest_sha256")
            or sha256(signature_path) != receipt.get("transport_signature_sha256")
            or sha256(signing_key) != binding["hpc_signing_public_key_sha256"]):
        raise RuntimeError("formal transport cryptographic evidence differs")
    verified = subprocess.run([
        "openssl", "dgst", "-sha256", "-verify", str(signing_key),
        "-signature", str(signature_path),
        "-sigopt", "rsa_padding_mode:pss",
        "-sigopt", "rsa_pss_saltlen:-1", str(manifest_path),
    ], check=False, capture_output=True, text=True)
    if verified.returncode != 0 or "Verified OK" not in verified.stdout:
        raise RuntimeError("formal transport signature re-verification failed")
    manifest = read_json(manifest_path)
    source = manifest.get("source", {})
    if source != receipt.get("signed_source"):
        raise RuntimeError("formal signed transport source differs")
    remote_files = {
        "authorization_sha256": remote_root / AUTHORIZATION_NAME,
        "batch_started_sha256": remote_root / "batch_started.json",
        "batch_manifest_sha256": remote_root / "batch_manifest.json",
        "batch_receipt_sha256": remote_root / "batch_receipt.json",
    }
    if any(not path.is_file() or source.get(field) != sha256(path)
           for field, path in remote_files.items()):
        raise RuntimeError("returned batch differs from verified transport receipt")
    return receipt


def verify_remote_batch(
        remote_root: Path, formal_root: Path = FORMAL_OUTPUT) -> dict:
    remote_root, formal_root = Path(remote_root), Path(formal_root)
    transport_receipt = _verify_transport_verification_receipt(
        remote_root, formal_root,
    )
    deployment_binding_path = formal_root / FORMAL_DEPLOYMENT_BINDING_NAME
    binding = _verify_deployment_binding(deployment_binding_path, formal_root)
    if (remote_root / "batch_failed.json").exists():
        raise RuntimeError("remote calibration batch has a failure receipt")
    receipt_path = remote_root / "batch_receipt.json"
    manifest_path = remote_root / "batch_manifest.json"
    started_path = remote_root / "batch_started.json"
    if not all(path.is_file() for path in (
            receipt_path, manifest_path, started_path)):
        raise FileNotFoundError("remote calibration success evidence is missing")
    receipt = read_json(receipt_path)
    manifest = read_json(manifest_path)
    started = read_json(started_path)
    if (receipt.get("schema") != f"{REMOTE_SCHEMA}_receipt"
            or receipt.get("status") != "complete"
            or receipt.get("passed") is not True
            or receipt.get("expected_experiments") != _expected_ids()
            or receipt.get("started_experiments") != _expected_ids()
            or receipt.get("manifest_sha256") != sha256(manifest_path)
            or receipt.get("batch_started_sha256") != sha256(started_path)
            or receipt.get("capsule_manifest_sha256")
            != binding["capsule_manifest_sha256"]
            or manifest.get("schema") != f"{REMOTE_SCHEMA}_manifest"):
        raise RuntimeError("remote calibration batch receipt differs")
    actual = _batch_manifest_files(remote_root)
    if (actual != manifest.get("files")
            or len(actual) != manifest.get("file_count")):
        raise RuntimeError("remote calibration batch file set or hashes differ")
    authorization_path = remote_root / AUTHORIZATION_NAME
    if (sha256(authorization_path) != binding["authorization_sha256"]
            or receipt.get("authorization_sha256")
            != binding["authorization_sha256"]):
        raise RuntimeError("remote batch authorization hash differs")
    environment = receipt.get("environment", {})
    if (started.get("schema") != f"{REMOTE_SCHEMA}_start"
            or started.get("expected_experiments") != _expected_ids()
            or started.get("retry_policy") != "none"
            or started.get("capsule_manifest_sha256")
            != binding["capsule_manifest_sha256"]
            or started.get("authorization_sha256")
            != binding["authorization_sha256"]
            or started.get("environment") != environment
            or not str(environment.get("slurm_job_id", "")).isdecimal()
            or environment.get("slurm_job_name") != EXPECTED_SLURM["job_name"]
            or environment.get("slurm_cpus_per_task")
            != EXPECTED_SLURM["cpus_per_task"]):
        raise RuntimeError("remote batch start or scheduler evidence differs")
    completed = receipt.get("completed")
    attempts = receipt.get("attempts")
    if (not isinstance(completed, list)
            or [row.get("exp_id") for row in completed] != _expected_ids()
            or not isinstance(attempts, list)
            or [row.get("exp_id") for row in attempts] != _expected_ids()
            or any(row.get("status") != "complete" or row.get("returncode") != 0
                   for row in attempts)):
        raise RuntimeError("remote calibration completion registry differs")
    verified = []
    for exp_id, record in zip(_expected_ids(), completed):
        directory = remote_root / "calibration" / exp_id
        stdout_path = remote_root / "calibration_process_logs" / f"{exp_id}.stdout.log"
        stderr_path = remote_root / "calibration_process_logs" / f"{exp_id}.stderr.log"
        actual_record = _verify_worker(
            directory, exp_id, stdout_path, stderr_path,
        )
        if actual_record != record:
            raise RuntimeError(f"remote completed record differs: {exp_id}")
        verified.append(actual_record)
    return {
        "receipt": receipt,
        "manifest_sha256": sha256(manifest_path),
        "authorization_sha256": sha256(remote_root / AUTHORIZATION_NAME),
        "capsule_manifest_sha256": binding["capsule_manifest_sha256"],
        "deployment_binding_sha256": sha256(deployment_binding_path),
        "transport_verification_receipt_sha256": sha256(
            formal_root / TRANSPORT_RECEIPT_NAME
        ),
        "transport_verification": transport_receipt,
        "batch_started_sha256": sha256(started_path),
        "completed": verified,
    }


def import_remote_batch(
        remote_root: Path, formal_root: Path = FORMAL_OUTPUT) -> Path:
    """Exclusively add a verified remote batch to the prepared formal attempt."""
    remote_root, formal_root = Path(remote_root), Path(formal_root)
    if formal_root.resolve() != FORMAL_OUTPUT.resolve():
        raise ValueError("import destination is not the frozen formal attempt")
    stage_paths = {
        "started": formal_root / "calibration_started.json",
        "receipt": formal_root / "calibration_receipt.json",
        "failed": formal_root / "calibration_failed.json",
    }
    destinations = [
        formal_root / "calibration",
        formal_root / "calibration_process_logs",
        formal_root / "hpc_remote_evidence",
    ]
    if any(path.exists() for path in (*stage_paths.values(), *destinations)):
        raise FileExistsError("formal calibration import target is not empty")
    started = time.perf_counter()
    verified = None
    copied_files: list[str] = []
    try:
        write_json_new(stage_paths["started"], {
            "schema": "regge_record_length_calibration_stage_start_v01",
            "status": "started",
            "started_utc": _utc(),
            "ordered_experiments": _expected_ids(),
            "retry_policy": "none",
            "processes": "sequential_one_window_per_process_on_hpc",
            "import_source": str(remote_root.resolve()),
            "deployment_binding_sha256": sha256(
                formal_root / FORMAL_DEPLOYMENT_BINDING_NAME
            ),
        })
        verified = verify_remote_batch(remote_root, formal_root)
        for source_root_name in ("calibration", "calibration_process_logs"):
            source_root = remote_root / source_root_name
            for source in sorted(source_root.rglob("*")):
                if source.is_file():
                    relative = source.relative_to(remote_root)
                    target = formal_root / relative
                    _copy_file_new(source, target)
                    copied_files.append(relative.as_posix())
        evidence_root = formal_root / "hpc_remote_evidence"
        evidence_names = (
            AUTHORIZATION_NAME, "batch_started.json", "events.jsonl",
            "batch_manifest.json", "batch_receipt.json",
        )
        for name in evidence_names:
            source = remote_root / name
            target = evidence_root / name
            _copy_file_new(source, target)
            copied_files.append(target.relative_to(formal_root).as_posix())
        copied_set = set(copied_files)
        expected_set = {
            path.relative_to(remote_root).as_posix()
            for name in ("calibration", "calibration_process_logs")
            for path in (remote_root / name).rglob("*") if path.is_file()
        }
        expected_set.update({
            f"hpc_remote_evidence/{name}" for name in evidence_names
        })
        if copied_set != expected_set:
            raise RuntimeError("formal calibration import file set differs")
        receipt = verified["receipt"]
        attempts = receipt["attempts"]
        completed = [
            {
                "exp_id": row["exp_id"],
                "returncode": 0,
                "receipt_status": "complete",
                "receipt_sha256": row["receipt_sha256"],
                "process_sha256": row["process_sha256"],
            }
            for row in verified["completed"]
        ]
        _event(
            formal_root / "events.jsonl",
            "hpc_calibration_batch_imported",
            experiment_count=6,
            remote_manifest_sha256=verified["manifest_sha256"],
            remote_job_id=receipt.get("environment", {}).get("slurm_job_id"),
        )
        formal_receipt = {
            "schema": "regge_record_length_calibration_stage_receipt_v01",
            "status": "complete", "passed": True,
            "started_experiments": _expected_ids(),
            "attempts": attempts,
            "completed": completed,
            "elapsed_seconds": receipt.get("elapsed_seconds"),
            "execution_location": "hpc",
            "remote_manifest_sha256": verified["manifest_sha256"],
            "remote_authorization_sha256": verified["authorization_sha256"],
            "remote_capsule_manifest_sha256": verified[
                "capsule_manifest_sha256"
            ],
            "deployment_binding_sha256": verified[
                "deployment_binding_sha256"
            ],
            "remote_batch_started_sha256": verified[
                "batch_started_sha256"
            ],
            "transport_verification_receipt_sha256": verified[
                "transport_verification_receipt_sha256"
            ],
            "remote_evidence": {
                name: sha256(evidence_root / name) for name in evidence_names
            },
            "remote_job_id": receipt.get("environment", {}).get("slurm_job_id"),
            "import_elapsed_seconds": time.perf_counter() - started,
        }
        for row in completed:
            exp_id = row["exp_id"]
            stdout_path = (
                formal_root / "calibration_process_logs" / f"{exp_id}.stdout.log"
            )
            stderr_path = (
                formal_root / "calibration_process_logs" / f"{exp_id}.stderr.log"
            )
            imported = _verify_worker(
                formal_root / "calibration" / exp_id,
                exp_id, stdout_path, stderr_path,
            )
            expected = next(
                item for item in verified["completed"]
                if item["exp_id"] == exp_id
            )
            if imported != expected:
                raise RuntimeError(
                    f"formal imported worker differs from remote evidence: {exp_id}"
                )
        # This atomic receipt follows two complete scientific reconstructions:
        # one on the returned batch and one on the imported copies.
        _write_success_atomic(stage_paths["receipt"], formal_receipt)
        return formal_root
    except BaseException as error:
        if not stage_paths["failed"].exists():
            try:
                write_json_new(stage_paths["failed"], {
                    "schema": "regge_record_length_calibration_import_failure_v01",
                    "status": "failed", "passed": False,
                    "error": {"type": type(error).__name__, "reason": str(error)},
                    "traceback": traceback.format_exc(),
                    "copied_file_count": len(copied_files),
                    "remote_verification_completed": verified is not None,
                    "automatic_retry": False,
                    "elapsed_seconds": time.perf_counter() - started,
                })
            except BaseException as receipt_error:
                error.add_note(
                    "formal import failure receipt also failed: "
                    f"{type(receipt_error).__name__}: {receipt_error}"
                )
        raise

