"""Small, overwrite-safe helpers and frozen paths for the record-length study."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

import numpy as np


PROJECT = Path(__file__).resolve().parents[2]
PACKAGE = Path(__file__).resolve().parent
CORE = Path(os.environ.get("REGGE_CORE_ROOT", "G:/wt/id23-readout")).resolve()
ARCHIVE = CORE / "results/regge_short_record_calibration_v03_recovery/20260920-regge-short-record-recovery-v03-001"
LONG_SELECTION = CORE / "results/regge_short_record_long_lead_selection/20260927-regge-short-record-selection-development-001"
REPAIRED = PROJECT / "output/regge_zero_prob/20260929-002"
RAW_DATA = PROJECT / "forecast/data/PEQ_Regge_hour.txt"
PLAN = PROJECT / "docs/superpowers/plans/2026-09-29-regge-record-length-effect-v02.md"
TEST = PROJECT / "python/tests/test_regge_record_length_study.py"
FORMAL_ATTEMPT = "20260929-003"
FORMAL_OUTPUT = PROJECT / f"output/regge_length/{FORMAL_ATTEMPT}"
HPC_CALIBRATION_SLURM = (
    PROJECT / "hpc/regge_record_length_calibration_20260929_003.slurm"
)
HPC_PACKAGE_SLURM = (
    PROJECT / "hpc/regge_record_length_package_20260929_003.slurm"
)


def sha256(path: Path) -> str:
    """Return the SHA-256 of a file without loading it all into memory."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def array_sha256(values: np.ndarray) -> str:
    """Hash an array using the byte convention of the frozen calibration."""
    return hashlib.sha256(np.ascontiguousarray(values).tobytes()).hexdigest()


def read_json(path: Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json_new(path: Path, value: dict | list) -> None:
    """Write JSON only when the target does not already exist."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as target:
        json.dump(value, target, ensure_ascii=False, indent=2, allow_nan=False)
        target.write("\n")


def save_npz_new(path: Path, **arrays: np.ndarray) -> None:
    """Write a NumPy archive without permitting replacement."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as target:
        np.savez(target, **arrays)
