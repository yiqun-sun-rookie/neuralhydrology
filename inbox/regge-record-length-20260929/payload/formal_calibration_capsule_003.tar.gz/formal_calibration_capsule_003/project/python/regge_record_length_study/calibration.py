"""Bounded six- and twelve-month calibration adapter with durable evidence."""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import importlib
import json
from pathlib import Path
import platform
import sys
import time
import traceback
from types import MappingProxyType, ModuleType
from typing import Mapping

import numpy as np
import torch

from .common import (
    FORMAL_OUTPUT,
    PACKAGE,
    PROJECT,
    RAW_DATA,
    REPAIRED,
    array_sha256,
    read_json,
    save_npz_new,
    sha256,
    write_json_new,
)
from .contract import (
    FIXED_INITIAL_COVARIANCE_SHA256,
    RAW_DATA_SHA256,
    fixed_initial_covariance,
    index_at,
    validate_hour_axis,
    window_specs,
)


SEALED_RUNTIME = (PROJECT / "python/regge_zero_probability_repair/runtime").resolve()
SEALED_PACKAGE = (SEALED_RUNTIME / "walrus_history_conditioned_imm").resolve()
SEALED_SOURCE_BINDING = REPAIRED / "source_binding.json"
BASE_CONFIG = SEALED_PACKAGE / "configs/regge_short_record_v01.json"
EXPECTED_VERSIONS = {"python": "3.11.5", "numpy": "1.26.4", "torch": "2.2.2"}
PARAMETER_DESIGN_SHA256 = "fa7a7a2625c20dc779aeb6df008da2d208af9fbe4c427446e5e96dc4a4128d6b"
NOISE_DESIGN_SHA256 = "e30047bf3fb5b240aaf6ede664e9c89d72257aa1b717cb486de55477d6173d8b"
BASE_CONFIG_SHA256 = "5f175b2f09613b2090c379f57378cffd84daffb46d2a26b95fa3ec4bb2b1de0c"
CANONICAL_PARAMETER_DESIGN = PACKAGE / "canonical_parameter_design.npy"
CANONICAL_NOISE_DESIGN = PACKAGE / "canonical_noise_design.npy"
CANONICAL_PARAMETER_FILE_SHA256 = "0f338906ba21ae41185e5812176459d7013e519c3ce194c6a43f12247fea2c14"
CANONICAL_NOISE_FILE_SHA256 = "0d17f50a7db2d2f8a97e07cb1b38debcb76bcadd77caceec3061681c2e64d8ac"
CALIBRATION_ROOT = FORMAL_OUTPUT / "calibration"

_SCIENTIFIC_EXPECTATIONS = {
    "parameter_design": {"method": "log_scale_stratified", "seed": 915031,
                         "count": 2048, "shortlist_count": 16,
                         "prefix_diagnostics": [512, 1024, 2048]},
    "noise_design": {"seed": 909001, "count": 128,
                     "hash_sha256": NOISE_DESIGN_SHA256, "top_per_parameter": 3},
    "leads": [1, 24, 48, 120],
    "initial_state": [140, 1000, 4, 1200, 0.1],
    "initial_covariance_fraction": 0.001,
    "observation_variance": 0.000015,
    "sigma_points": {"alpha": 0.6874, "beta": 2, "kappa": -2},
    "transition_diagonal": 0.99,
    "dtype": "float64",
    "cpu_threads": 1,
}

_INPUT_HASH_KEYS = (
    "raw_data",
    "warmup_timestamps",
    "warmup_forcing",
    "calibration_timestamps",
    "calibration_forcing",
    "calibration_observations",
)


@dataclass(frozen=True)
class BoundCalibrationInputs:
    """Only weather warmup and stop-exclusive calibration observations."""

    warmup_timestamps: np.ndarray
    warmup_forcing: np.ndarray
    calibration_timestamps: np.ndarray
    calibration_forcing: np.ndarray
    calibration_observations: np.ndarray
    meta: Mapping[str, object]


def missing_calibration_specs() -> tuple[dict, ...]:
    """Return defensive copies of the six windows that must be computed."""
    return tuple(dict(spec) for spec in window_specs() if spec["months"] in (6, 12))


def _spec(exp_id: str) -> dict:
    matches = [spec for spec in missing_calibration_specs() if spec["exp_id"] == exp_id]
    if len(matches) != 1:
        raise ValueError(f"experiment is not an authorized new calibration: {exp_id}")
    return matches[0]


def _readonly_copy(values: np.ndarray, *, dtype=None) -> np.ndarray:
    result = np.array(values, dtype=dtype, copy=True)
    result.flags.writeable = False
    return result


def _frozen_meta(values: dict) -> Mapping[str, object]:
    frozen = dict(values)
    if "source_hashes" in frozen:
        frozen["source_hashes"] = MappingProxyType(dict(frozen["source_hashes"]))
    return MappingProxyType(frozen)


def bind_calibration_inputs(full_inputs: tuple, exp_id: str) -> BoundCalibrationInputs:
    """Copy exactly one authorized window; post-cutoff flow is never retained."""
    if not isinstance(full_inputs, tuple) or len(full_inputs) != 4:
        raise TypeError("full_inputs must be the four-item output of load_inputs")
    dates, forcing, observations, checks = full_inputs
    dates = validate_hour_axis(np.asarray(dates))
    forcing = np.asarray(forcing)
    observations = np.asarray(observations)
    if forcing.dtype != np.float64 or observations.dtype != np.float64:
        raise ValueError("full forcing and observations must use float64")
    if forcing.shape != (len(dates), 2) or observations.shape != (len(dates),):
        raise ValueError("full timestamps, forcing, and observations are misaligned")
    if not np.isfinite(forcing).all() or not np.isfinite(observations).all():
        raise ValueError("full forcing and observations must be finite")
    if dates[0] != np.datetime64("1999-01-01T01", "h"):
        raise ValueError("full input must start at 1999-01-01T01")
    if not isinstance(checks, dict) or checks.get("raw_data_sha256") != RAW_DATA_SHA256:
        raise ValueError("full input raw-data identity differs")
    if sha256(RAW_DATA) != RAW_DATA_SHA256:
        raise RuntimeError("raw Regge input changed")

    spec = _spec(exp_id)
    start = index_at(dates, spec["start"])
    stop = index_at(dates, spec["stop"])
    if stop - start != spec["hours"] or start <= 0:
        raise ValueError("literal calibration bounds differ from the frozen window")
    warm_dates = _readonly_copy(dates[:start].astype("datetime64[h]"))
    warm_forcing = _readonly_copy(forcing[:start], dtype=np.float64)
    calibration_dates = _readonly_copy(dates[start:stop].astype("datetime64[h]"))
    calibration_forcing = _readonly_copy(forcing[start:stop], dtype=np.float64)
    calibration_observations = _readonly_copy(observations[start:stop], dtype=np.float64)
    source_hashes = {
        "raw_data": RAW_DATA_SHA256,
        "warmup_timestamps": array_sha256(warm_dates),
        "warmup_forcing": array_sha256(warm_forcing),
        "calibration_timestamps": array_sha256(calibration_dates),
        "calibration_forcing": array_sha256(calibration_forcing),
        "calibration_observations": array_sha256(calibration_observations),
    }
    meta = _frozen_meta({
        "exp_id": exp_id,
        "endpoint": spec["endpoint"],
        "months": spec["months"],
        "warmup_start": str(warm_dates[0]),
        "warmup_stop": spec["start"],
        "warmup_hours": len(warm_dates),
        "calibration_start": spec["start"],
        "calibration_stop": spec["stop"],
        "calibration_hours": spec["hours"],
        "selection_origins": spec["selection_origins"],
        "parameter_design_seed": 915031,
        "parameter_count": 2048,
        "shortlist_count": 16,
        "noise_design_seed": 909001,
        "noise_count": 128,
        "leads": (1, 24, 48, 120),
        "dtype": "float64",
        "device": "cpu",
        "cpu_threads": 1,
        "gradients": False,
        "source_hashes": source_hashes,
    })
    bound = BoundCalibrationInputs(
        warm_dates, warm_forcing, calibration_dates, calibration_forcing,
        calibration_observations, meta,
    )
    _validated_core_inputs(bound, exp_id)
    return bound


def _validated_core_inputs(bound: BoundCalibrationInputs, exp_id: str) -> dict[str, np.ndarray]:
    """Fail closed before exposing a bound slice to the numerical core."""
    if not isinstance(bound, BoundCalibrationInputs):
        raise TypeError("bound inputs must be BoundCalibrationInputs")
    spec = _spec(exp_id)
    if bound.meta.get("exp_id") != exp_id:
        raise ValueError("bound experiment identity differs")
    warm_dates = np.asarray(bound.warmup_timestamps)
    calibration_dates = np.asarray(bound.calibration_timestamps)
    expected_warm = np.arange(
        np.datetime64("1999-01-01T01", "h"), np.datetime64(spec["start"], "h"),
        np.timedelta64(1, "h"),
    )
    expected_calibration = np.arange(
        np.datetime64(spec["start"], "h"), np.datetime64(spec["stop"], "h"),
        np.timedelta64(1, "h"),
    )
    if warm_dates.dtype != np.dtype("datetime64[h]") or not np.array_equal(warm_dates, expected_warm):
        raise ValueError("warmup timestamps differ from the exact continuous frozen interval")
    if (calibration_dates.dtype != np.dtype("datetime64[h]")
            or not np.array_equal(calibration_dates, expected_calibration)):
        raise ValueError("calibration timestamps differ from the exact stop-exclusive frozen interval")
    arrays = {
        "warmup_forcing": np.asarray(bound.warmup_forcing),
        "calibration_forcing": np.asarray(bound.calibration_forcing),
        "calibration_observations": np.asarray(bound.calibration_observations),
    }
    if arrays["warmup_forcing"].shape != (len(warm_dates), 2):
        raise ValueError("warmup forcing shape differs")
    if arrays["calibration_forcing"].shape != (spec["hours"], 2):
        raise ValueError("calibration forcing shape differs")
    if arrays["calibration_observations"].shape != (spec["hours"],):
        raise ValueError("calibration observations shape differs")
    if any(values.dtype != np.float64 for values in arrays.values()):
        raise ValueError("all scientific numeric inputs must use float64")
    if not all(np.isfinite(values).all() for values in arrays.values()):
        raise ValueError("bound scientific inputs must be finite")
    source_hashes = dict(bound.meta.get("source_hashes", {}))
    actual_hashes = {
        "raw_data": RAW_DATA_SHA256,
        "warmup_timestamps": array_sha256(warm_dates),
        "warmup_forcing": array_sha256(arrays["warmup_forcing"]),
        "calibration_timestamps": array_sha256(calibration_dates),
        "calibration_forcing": array_sha256(arrays["calibration_forcing"]),
        "calibration_observations": array_sha256(arrays["calibration_observations"]),
    }
    if source_hashes != actual_hashes:
        raise ValueError("bound calibration source hashes differ")
    return {
        "warmup_timestamps": warm_dates.copy(),
        "warmup_forcing": arrays["warmup_forcing"].copy(),
        "calibration_timestamps": calibration_dates.copy(),
        "calibration_forcing": arrays["calibration_forcing"].copy(),
        "calibration_observations": arrays["calibration_observations"].copy(),
    }


def _sealed_expected_hashes() -> dict[str, str]:
    binding = read_json(SEALED_SOURCE_BINDING)
    marker = "regge_zero_probability_repair/runtime/walrus_history_conditioned_imm/"
    expected: dict[str, str] = {}
    for source, digest in binding.get("source_hashes", {}).items():
        normalized = source.replace("\\", "/")
        if marker in normalized:
            expected[normalized.split(marker, 1)[1]] = digest
    if not expected:
        raise RuntimeError("repaired source binding contains no sealed runtime files")
    return expected


def _verify_sealed_sources() -> dict[str, str]:
    expected = _sealed_expected_hashes()
    actual_files = {
        path.relative_to(SEALED_PACKAGE).as_posix(): path
        for path in SEALED_PACKAGE.rglob("*")
        if path.is_file() and (path.suffix == ".py" or path.suffix == ".json")
    }
    if set(actual_files) != set(expected):
        raise RuntimeError("sealed runtime file set differs from the repaired source binding")
    for relative, path in actual_files.items():
        if sha256(path) != expected[relative]:
            raise RuntimeError(f"sealed runtime source changed: {relative}")
    if sha256(BASE_CONFIG) != BASE_CONFIG_SHA256:
        raise RuntimeError("sealed scientific configuration file changed")
    return dict(expected)


def _assert_sealed_module_paths(*modules: ModuleType) -> None:
    for module in modules:
        module_path = Path(getattr(module, "__file__", "")).resolve()
        if not module_path.is_file() or not module_path.is_relative_to(SEALED_PACKAGE):
            raise RuntimeError(f"module was not imported from the sealed runtime: {module_path}")


def _load_sealed_core() -> tuple[ModuleType, ModuleType, ModuleType]:
    """Import the repaired package first and reject any prior foreign import."""
    _verify_sealed_sources()
    prefix = "walrus_history_conditioned_imm"
    for name, module in tuple(sys.modules.items()):
        if name == prefix or name.startswith(prefix + "."):
            _assert_sealed_module_paths(module)
    runtime_text = str(SEALED_RUNTIME)
    if runtime_text in sys.path:
        sys.path.remove(runtime_text)
    sys.path.insert(0, runtime_text)
    contract = importlib.import_module(f"{prefix}.short_record_contract")
    core = importlib.import_module(f"{prefix}.short_record_calibration")
    noise = importlib.import_module(f"{prefix}.noise_search")
    _assert_sealed_module_paths(contract, core, noise)
    return contract, core, noise


def _validate_scientific_config(config: dict, contract: ModuleType, core: ModuleType) -> dict:
    """Check readable fields before the core's independent fingerprint gate."""
    if config.get("parameter_design", {}).get("seed") != 915031:
        raise ValueError("parameter-design seed differs from 915031")
    if config.get("noise_design", {}).get("seed") != 909001:
        raise ValueError("noise-design seed differs from 909001")
    for key, expected in _SCIENTIFIC_EXPECTATIONS.items():
        if config.get(key) != expected:
            raise ValueError(f"frozen scientific setting differs: {key}")
    contract.validate_config(config)
    generated_records, generated_values = core.build_parameter_design(
        config, config["fixed_fields"],
    )
    if generated_values.shape != (2048, 5) or generated_values.dtype != np.float64:
        raise ValueError("parameter design shape or dtype differs")
    if len(generated_records) != 2048:
        raise ValueError("parameter design record count differs")
    parameter_values = _canonical_design(
        CANONICAL_PARAMETER_DESIGN,
        file_sha256=CANONICAL_PARAMETER_FILE_SHA256,
        array_sha256_expected=PARAMETER_DESIGN_SHA256,
        shape=(2048, 5),
        label="parameter",
    )
    parameter_binding = _require_at_most_one_float64_step(
        generated_values, parameter_values, label="parameter design",
    )
    records = [
        dict(
            config["fixed_fields"],
            **dict(zip(config["parameter_fields"], row.tolist())),
        )
        for row in parameter_values
    ]
    covariance = fixed_initial_covariance()
    if array_sha256(covariance) != FIXED_INITIAL_COVARIANCE_SHA256:
        raise ValueError("fixed initial covariance differs")
    _assert_sealed_module_paths(contract, core)
    return {
        "records": records,
        "parameter_values": parameter_values,
        "parameter_design_binding": parameter_binding,
    }


def _canonical_design(path: Path, *, file_sha256: str,
                      array_sha256_expected: str, shape: tuple[int, ...],
                      label: str) -> np.ndarray:
    """Load one byte-frozen design that is portable across math libraries."""
    path = Path(path)
    if not path.is_file() or sha256(path) != file_sha256:
        raise RuntimeError(f"canonical {label} design file changed")
    values = np.load(path, allow_pickle=False)
    if (not isinstance(values, np.ndarray) or values.shape != shape
            or values.dtype != np.float64 or not np.isfinite(values).all()
            or array_sha256(values) != array_sha256_expected):
        raise RuntimeError(f"canonical {label} design array changed")
    result = np.array(values, dtype=np.float64, copy=True, order="C")
    result.flags.writeable = False
    return result


def _require_at_most_one_float64_step(generated: np.ndarray,
                                      canonical: np.ndarray, *, label: str) -> dict:
    """Accept only the known one-step libm drift, then retain canonical bytes."""
    actual = np.asarray(generated)
    expected = np.asarray(canonical)
    if (actual.shape != expected.shape or actual.dtype != np.float64
            or expected.dtype != np.float64 or not np.isfinite(actual).all()
            or not np.isfinite(expected).all()):
        raise ValueError(f"generated {label} structure differs")
    lower = np.nextafter(expected, -np.inf)
    upper = np.nextafter(expected, np.inf)
    if np.any((actual < lower) | (actual > upper)):
        raise ValueError(f"generated {label} differs by more than one float64 step")
    different = int(np.count_nonzero(actual != expected))
    return {
        "canonical_array_sha256": array_sha256(expected),
        "generated_array_sha256": array_sha256(actual),
        "different_value_count": different,
        "maximum_float64_steps": 1 if different else 0,
        "canonical_bytes_used_for_execution": True,
    }


def _version_identity() -> dict[str, str]:
    versions = {
        "python": platform.python_version(),
        "numpy": np.__version__,
        "torch": torch.__version__,
    }
    if versions != EXPECTED_VERSIONS:
        raise RuntimeError(f"environment versions differ: {versions}")
    return versions


def _observed_environment() -> dict:
    """Return evidence without enforcing the environment, for failure paths."""
    try:
        from threadpoolctl import threadpool_info
        pools = threadpool_info()
        pool_error = None
    except BaseException as error:
        pools = None
        pool_error = {"type": type(error).__name__, "reason": str(error)}
    return {
        "versions": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "torch": torch.__version__,
        },
        "dtype_required": "float64",
        "device_required": "cpu",
        "gradients_observed": torch.is_grad_enabled(),
        "gradients_required": False,
        "thread_settings": {
            "cpu_threads_required": 1,
            "torch_threads_observed": torch.get_num_threads(),
            "loaded_threadpools_observed": pools,
            "threadpool_observation_error": pool_error,
        },
        "sealed_runtime": str(SEALED_PACKAGE),
    }


def _known_input_source_hashes(bound: BoundCalibrationInputs | None = None) -> dict:
    values = {name: None for name in _INPUT_HASH_KEYS}
    try:
        if RAW_DATA.is_file():
            values["raw_data"] = sha256(RAW_DATA)
    except OSError:
        pass
    if bound is not None:
        for name, digest in dict(bound.meta.get("source_hashes", {})).items():
            if name in values:
                values[name] = digest
    return values


@contextmanager
def _one_thread_no_grad():
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    try:
        from threadpoolctl import threadpool_info, threadpool_limits
        with threadpool_limits(limits=1), torch.no_grad():
            if torch.get_num_threads() != 1 or torch.is_grad_enabled():
                raise RuntimeError("calibration must use one CPU thread with gradients disabled")
            pools = threadpool_info()
            if any(int(pool.get("num_threads", 1)) != 1 for pool in pools):
                raise RuntimeError("loaded numeric threadpool is not limited to one thread")
            yield pools
    finally:
        torch.set_num_threads(previous)


def _runtime_identity(*, threadpools: list | None = None) -> dict:
    environment = _observed_environment()
    environment["versions"] = _version_identity()
    environment["dtype"] = "float64"
    environment["device"] = "cpu"
    environment["cpu_threads"] = 1
    environment["gradients"] = False
    environment["sealed_source_hashes"] = _verify_sealed_sources()
    if threadpools is not None:
        environment["thread_settings"]["loaded_threadpools_observed"] = threadpools
    return environment


def _reached_array_counts(raw: dict) -> dict[str, int]:
    return {name: int(value.size) for name, value in raw.items() if isinstance(value, np.ndarray)}


def _annotate_result(result: dict, bound: BoundCalibrationInputs, exp_id: str,
                     *, error: BaseException | None = None,
                     environment: dict | None = None) -> dict:
    annotated = dict(result)
    raw = annotated.get("raw")
    if not isinstance(raw, dict):
        raise ValueError("calibration result must retain reached raw arrays")
    spec = _spec(exp_id)
    annotated.update(
        exp_id=exp_id,
        window={
            "exp_id": exp_id,
            "endpoint": spec["endpoint"],
            "months": spec["months"],
            "calibration_start": spec["start"],
            "calibration_stop": spec["stop"],
            "expected_calibration_hours": spec["hours"],
        },
        input_source_hashes=dict(bound.meta["source_hashes"]),
        environment=environment or _runtime_identity(),
        reached_array_counts=_reached_array_counts(raw),
    )
    if error is not None:
        annotated["partial"] = True
        annotated["original_exception"] = {
            "type": type(error).__name__,
            "reason": str(error),
        }
    _validate_result_metadata(annotated, bound, require_partial=error is not None)
    return annotated


def _validate_result_metadata(result: dict, bound: BoundCalibrationInputs,
                              *, require_partial: bool = False) -> None:
    exp_id = bound.meta["exp_id"]
    spec = _spec(str(exp_id))
    if result.get("exp_id") != exp_id:
        raise ValueError("calibration result lacks the exact experiment identity")
    window = result.get("window", {})
    if (window.get("calibration_start") != spec["start"]
            or window.get("calibration_stop") != spec["stop"]
            or window.get("exp_id") != exp_id):
        raise ValueError("calibration result timestamps or identity differ")
    if result.get("input_source_hashes") != dict(bound.meta["source_hashes"]):
        raise ValueError("calibration result source hashes differ")
    environment = result.get("environment", {})
    if environment.get("versions") != EXPECTED_VERSIONS:
        raise ValueError("calibration result environment differs")
    raw = result.get("raw")
    if not isinstance(raw, dict) or result.get("reached_array_counts") != _reached_array_counts(raw):
        raise ValueError("calibration result reached-array counts differ")
    if require_partial:
        error = result.get("original_exception")
        if result.get("partial") is not True or not isinstance(error, dict):
            raise ValueError("partial calibration lacks the original exception")
        if not error.get("type") or "reason" not in error:
            raise ValueError("partial calibration original exception is incomplete")


def _execute_bound_calibration(bound: BoundCalibrationInputs, exp_id: str,
                               record_event) -> dict:
    contract, core, noise = _load_sealed_core()
    config = contract.proposed_config()
    validated = _validate_scientific_config(config, contract, core)
    generated_design = noise.build_noise_design(config["noise_design"]["seed"])
    if generated_design.shape != (128, 5) or generated_design.dtype != np.float64:
        raise ValueError("noise design shape or dtype differs")
    design = _canonical_design(
        CANONICAL_NOISE_DESIGN,
        file_sha256=CANONICAL_NOISE_FILE_SHA256,
        array_sha256_expected=NOISE_DESIGN_SHA256,
        shape=(128, 5),
        label="noise",
    )
    noise_binding = _require_at_most_one_float64_step(
        generated_design, design, label="noise design",
    )
    design_binding = {
        "parameter": validated["parameter_design_binding"],
        "noise": noise_binding,
    }
    environment = None
    try:
        inputs = _validated_core_inputs(bound, exp_id)
        with _one_thread_no_grad() as pools:
            environment = _runtime_identity(threadpools=pools)
            result = core._execute(
                inputs,
                validated["records"],
                design,
                validated["parameter_values"],
                (1, 24, 48, 120),
                record_event,
                synthetic=False,
            )
    except BaseException as error:
        error.regge_record_length_design_binding = design_binding
        partial = getattr(error, "short_record_partial_result", None)
        if partial is not None:
            partial = dict(partial)
            partial["design_binding"] = design_binding
            error.short_record_partial_result = _annotate_result(
                partial, bound, exp_id, error=error, environment=environment,
            )
        raise
    result = dict(result)
    result["design_binding"] = design_binding
    return _annotate_result(result, bound, exp_id, environment=environment)


def _jsonable(value):
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if isinstance(value, np.ndarray):
        return _jsonable(value.tolist())
    if isinstance(value, np.generic):
        return _jsonable(value.item())
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


def _event(path: Path, event: str, **fields) -> None:
    row = {
        "utc": datetime.now(timezone.utc).isoformat(),
        "event": event,
        **_jsonable(fields),
    }
    with path.open("a", encoding="utf-8") as target:
        target.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")


def _persist_result(destination: Path, result: dict) -> dict[str, str]:
    raw = result.get("raw", {})
    if not isinstance(raw, dict):
        raise ValueError("result raw evidence must be a dictionary")
    save_npz_new(destination / "raw.npz", **{
        name: value for name, value in raw.items() if isinstance(value, np.ndarray)
    })
    write_json_new(destination / "result.json", _jsonable({
        name: value for name, value in result.items() if name != "raw"
    }))
    return {
        "raw.npz": sha256(destination / "raw.npz"),
        "result.json": sha256(destination / "result.json"),
    }


def _failure_result(spec: dict, error: BaseException, *, failure_stage: str,
                    bound: BoundCalibrationInputs | None) -> dict:
    established_binding = getattr(
        error, "regge_record_length_design_binding", None,
    )
    design_binding = (
        dict(established_binding)
        if isinstance(established_binding, Mapping)
        else {
            "status": "not_established",
            "failure_stage": failure_stage,
        }
    )
    return {
        "status": "engineering_failed",
        "partial": False,
        "failure_stage": failure_stage,
        "exp_id": spec["exp_id"],
        "window": {
            "exp_id": spec["exp_id"],
            "endpoint": spec["endpoint"],
            "months": spec["months"],
            "calibration_start": spec["start"],
            "calibration_stop": spec["stop"],
            "expected_calibration_hours": spec["hours"],
        },
        "original_exception": {"type": type(error).__name__, "reason": str(error)},
        "traceback": traceback.format_exc(),
        "environment": _observed_environment(),
        "input_source_hashes": _known_input_source_hashes(bound),
        "design_binding": design_binding,
        "raw": {},
        "reached_array_counts": {},
    }


def calibrate_one(spec: dict, destination: Path) -> Path:
    """Run one exclusive new window and preserve success or failure evidence."""
    expected = _spec(str(spec.get("exp_id")) if isinstance(spec, dict) else "")
    if spec != expected:
        raise ValueError("calibration spec differs from the frozen window record")
    destination = Path(destination)
    if len(str(destination.resolve())) >= 240:
        raise ValueError("calibration destination path is too long")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.mkdir(exist_ok=False)
    events = destination / "events.jsonl"
    events.touch(exist_ok=False)
    started = time.perf_counter()
    _event(events, "calibration_started", exp_id=expected["exp_id"])
    bound = None
    failure_stage = "input_loading"
    try:
        full_inputs = __import__(
            "regge_record_length_study.contract", fromlist=["load_inputs"]
        ).load_inputs()
        failure_stage = "input_binding"
        bound = bind_calibration_inputs(full_inputs, expected["exp_id"])
        failure_stage = "scientific_preflight_and_execution"
        result = _execute_bound_calibration(
            bound, expected["exp_id"],
            lambda event, **fields: _event(events, event, exp_id=expected["exp_id"], **fields),
        )
    except BaseException as error:
        partial = getattr(error, "short_record_partial_result", None)
        if isinstance(partial, dict):
            result = dict(partial)
            result.setdefault("failure_stage", failure_stage)
            result.setdefault("environment", _observed_environment())
            result.setdefault("input_source_hashes", _known_input_source_hashes(bound))
            result.setdefault(
                "design_binding",
                getattr(error, "regge_record_length_design_binding", {
                    "status": "not_established",
                    "failure_stage": failure_stage,
                }),
            )
        else:
            result = _failure_result(
                expected, error, failure_stage=failure_stage, bound=bound,
            )
        try:
            files = _persist_result(destination, result)
            _event(events, "calibration_failed", exp_id=expected["exp_id"],
                   error_type=type(error).__name__, error=str(error))
            files["events.jsonl"] = sha256(events)
            write_json_new(destination / "receipt.json", {
                "schema": "regge_record_length_calibration_receipt_v01",
                "status": "failed",
                "passed": False,
                "exp_id": expected["exp_id"],
                "exit_code": 1,
                "elapsed_seconds": time.perf_counter() - started,
                "failure_stage": result.get("failure_stage"),
                "environment": result.get("environment"),
                "input_source_hashes": result.get("input_source_hashes"),
                "design_binding": result.get("design_binding"),
                "error": {"type": type(error).__name__, "reason": str(error)},
                "files": files,
            })
        except BaseException as checkpoint_error:
            error.add_note(
                "calibration failure checkpoint also failed: "
                f"{type(checkpoint_error).__name__}: {checkpoint_error}"
            )
        raise

    files = _persist_result(destination, result)
    complete = result.get("status") == "complete"
    final_event = "calibration_completed" if complete else "calibration_scientifically_failed"
    _event(events, final_event, exp_id=expected["exp_id"], status=result.get("status"))
    files["events.jsonl"] = sha256(events)
    write_json_new(destination / "receipt.json", {
        "schema": "regge_record_length_calibration_receipt_v01",
        "status": "complete" if complete else "failed",
        "passed": complete,
        "exp_id": expected["exp_id"],
        "exit_code": 0 if complete else 1,
        "elapsed_seconds": time.perf_counter() - started,
        "failure_stage": None if complete else "scientific_selection",
        "environment": result.get("environment"),
        "input_source_hashes": result.get("input_source_hashes"),
        "files": files,
    })
    if not complete:
        raise RuntimeError(f"calibration did not complete scientifically: {expected['exp_id']}")
    return destination
