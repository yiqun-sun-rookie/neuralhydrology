"""Exclusive, source-bound preparation for the Regge record-length study."""
from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import shutil
import time
import traceback

import numpy as np
import psutil
import torch

from .common import (
    ARCHIVE,
    FORMAL_OUTPUT,
    HPC_CALIBRATION_SLURM,
    HPC_PACKAGE_SLURM,
    LONG_SELECTION,
    PACKAGE,
    PLAN,
    PROJECT,
    RAW_DATA,
    REPAIRED,
    TEST,
    array_sha256,
    read_json,
    save_npz_new,
    sha256,
    write_json_new,
)
from .contract import (
    ARCHIVE_AUDIT_SHA256,
    ARCHIVE_MANIFEST_SHA256,
    FIXED_INITIAL_COVARIANCE_SHA256,
    RAW_DATA_SHA256,
    common_warmup_state_masks,
    evaluation_period_specs,
    fixed_initial_covariance,
    load_inputs,
    origin_arrays,
    state_preparation_specs,
    window_specs,
)


OUTPUT = FORMAL_OUTPUT
LONG_SELECTION_MANIFEST_SHA256 = "462a9d598c2bf1e2b99357a9d940e6122cf104bce357d51461610931c77eaf53"
LONG_SELECTION_FILE_SHA256 = "6e0200a7f8cff6eedc14179ecd7a347a99e5b4c807419bc458abecfc1a58d2ac"
REPAIRED_MANIFEST_SHA256 = "ababef8cdb2e1d288b43bd15c64ba82c58879e09c551a51a21e23de1f00d8678"
REPAIRED_AUDIT_SHA256 = "93d4e4d6d87bebfafd9440952aee7b3736a2a862a572355afbae534a9c809d95"
EXPECTED_VERSIONS = {"python": "3.11.5", "numpy": "1.26.4", "torch": "2.2.2"}
REPAIRED_NUMERICAL_CORE = PROJECT / "python/regge_zero_probability_repair/runtime/walrus_history_conditioned_imm"
SEALED_NUMERICAL_CORE = ARCHIVE.parents[2] / "src/walrus_history_conditioned_imm"
_NUMERICAL_ENTRYPOINT_DIRECT_DEPENDENCIES = {
    "short_record_calibration.py": (
        "filter.py",
        "noise_filter.py",
        "noise_search.py",
        "short_record_contract.py",
        "walrus.py",
    ),
}
_CORE_REQUIRED_FILES = tuple(dict.fromkeys((
    "__init__.py",
    *_NUMERICAL_ENTRYPOINT_DIRECT_DEPENDENCIES,
    *(dependency
      for dependencies in _NUMERICAL_ENTRYPOINT_DIRECT_DEPENDENCIES.values()
      for dependency in dependencies),
    "forecast.py",
    "configs/regge_short_record_v01.json",
)))
_NPZ_MEMBER_OVERHEAD_BYTES = 512
_NPZ_FILE_OVERHEAD_BYTES = 4096

_HISTORICAL_WINDOWS = (
    "year_end_origin_one__3", "year_end_origin_one__24",
    "midyear_origin__3", "midyear_origin__24",
    "year_end_origin_two__3", "year_end_origin_two__24",
)


def _event(root: Path, event: str, **fields) -> None:
    row = dict(utc=datetime.now(timezone.utc).isoformat(), event=event, **fields)
    with (root / "events.jsonl").open("a", encoding="utf-8") as target:
        target.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")


def _versions() -> dict[str, str]:
    values = {"python": platform.python_version(), "numpy": np.__version__, "torch": torch.__version__}
    if values != EXPECTED_VERSIONS:
        raise RuntimeError(f"environment versions differ: {values}")
    return values


def _validate_numerical_core_directories() -> dict[str, dict]:
    records = {}
    for label, folder in (
        ("repaired", Path(REPAIRED_NUMERICAL_CORE)),
        ("sealed", Path(SEALED_NUMERICAL_CORE)),
    ):
        if not folder.is_dir():
            raise RuntimeError(f"required {label} numerical core directory is missing: {folder}")
        missing = [relative for relative in _CORE_REQUIRED_FILES if not (folder / relative).is_file()]
        if missing:
            raise RuntimeError(f"required {label} numerical core files are missing: {missing}")
        records[label] = dict(
            path=str(folder.resolve()),
            required_files={relative: sha256(folder / relative) for relative in _CORE_REQUIRED_FILES},
        )
    return records


def _source_files() -> list[Path]:
    _validate_numerical_core_directories()
    canonical_designs = [
        PACKAGE / "canonical_parameter_design.npy",
        PACKAGE / "canonical_noise_design.npy",
    ]
    files = (
        sorted(PACKAGE.glob("*.py")) + canonical_designs
        + [
            PLAN,
            TEST,
            PROJECT / "python/imm_da/data_loader.py",
            HPC_CALIBRATION_SLURM,
            HPC_PACKAGE_SLURM,
        ]
    )
    for name in (
        "run_regge_record_length_study.py",
        "run_regge_record_length_hpc_calibration.py",
    ):
        entry = PROJECT / "python" / name
        if entry.is_file():
            files.append(entry)
    for folder in (Path(REPAIRED_NUMERICAL_CORE), Path(SEALED_NUMERICAL_CORE)):
        files.extend(sorted(folder.glob("*.py")))
        files.extend(sorted((folder / "configs").glob("*.json")))
    files = [path.resolve() for path in files]
    if not all(path.is_file() for path in files) or len(files) != len(set(files)):
        raise RuntimeError("required preparation source is missing or duplicated")
    return files


def _source_hashes() -> dict[str, str]:
    return {str(path): sha256(path) for path in _source_files()}


def _verify_bound_sources() -> dict:
    numerical_cores = _validate_numerical_core_directories()
    expected = {
        ARCHIVE / "manifest.json": ARCHIVE_MANIFEST_SHA256,
        ARCHIVE / "audit.json": ARCHIVE_AUDIT_SHA256,
        LONG_SELECTION / "manifest.json": LONG_SELECTION_MANIFEST_SHA256,
        LONG_SELECTION / "selection.json": LONG_SELECTION_FILE_SHA256,
        REPAIRED / "manifest.json": REPAIRED_MANIFEST_SHA256,
        REPAIRED / "audit.json": REPAIRED_AUDIT_SHA256,
        RAW_DATA: RAW_DATA_SHA256,
    }
    for path, digest in expected.items():
        if not path.is_file() or sha256(path) != digest:
            raise RuntimeError(f"bound source changed or is missing: {path}")
    selection_manifest = read_json(LONG_SELECTION / "manifest.json")
    selection_audit = LONG_SELECTION / "audit.json"
    if sha256(selection_audit) != selection_manifest.get("files", {}).get("audit.json"):
        raise RuntimeError("long-lead selection audit changed")
    for audit in (ARCHIVE / "audit.json", selection_audit, REPAIRED / "audit.json"):
        if read_json(audit).get("passed") is not True:
            raise RuntimeError(f"bound audit did not pass: {audit}")
    archive_manifest = read_json(ARCHIVE / "manifest.json")
    manifest_files = archive_manifest.get("files", {})
    historical = {}
    for window in _HISTORICAL_WINDOWS:
        for name in ("raw.npz", "result.json"):
            relative = f"calibration/{window}/{name}"
            path = ARCHIVE / relative
            recorded = manifest_files.get(relative)
            if not isinstance(recorded, str) or not path.is_file() or sha256(path) != recorded:
                raise RuntimeError(f"historical calibration artifact changed: {relative}")
            historical[relative] = recorded
    return dict(
        fixed_files={str(path): digest for path, digest in expected.items()},
        historical_calibration_files=historical,
        archive_audit_passed=True,
        long_selection_audit_passed=True,
        repaired_audit_passed=True,
        numerical_cores=numerical_cores,
    )


def _verified_upstream_resource_receipt() -> tuple[dict, str]:
    manifest_path = ARCHIVE / "manifest.json"
    if not manifest_path.is_file() or sha256(manifest_path) != ARCHIVE_MANIFEST_SHA256:
        raise RuntimeError("upstream manifest changed before resource receipt read")
    manifest = read_json(manifest_path)
    expected = manifest.get("files", {}).get("formal_resource_receipt.json")
    receipt_path = ARCHIVE / "formal_resource_receipt.json"
    if not isinstance(expected, str) or not receipt_path.is_file() or sha256(receipt_path) != expected:
        raise RuntimeError("upstream resource receipt changed")
    return read_json(receipt_path), expected


def _array_layout(shape: tuple[int, ...], dtype: str) -> dict:
    normalized = np.dtype(dtype)
    count = int(np.prod(shape, dtype=np.int64))
    return dict(shape=list(shape), dtype=str(normalized), elements=count,
                bytes=count * normalized.itemsize)


def _array_file(arrays: dict[str, tuple[tuple[int, ...], str]], file_count: int = 1) -> dict:
    layouts = {name: _array_layout(shape, dtype) for name, (shape, dtype) in arrays.items()}
    payload_per_file = sum(row["bytes"] for row in layouts.values())
    overhead_per_file = _NPZ_FILE_OVERHEAD_BYTES + len(layouts) * _NPZ_MEMBER_OVERHEAD_BYTES
    return dict(
        file_count=file_count,
        arrays=layouts,
        payload_bytes=payload_per_file * file_count,
        container_overhead_bytes=overhead_per_file * file_count,
        estimated_file_bytes=(payload_per_file + overhead_per_file) * file_count,
    )


def _raw_calibration_layout(spec: dict) -> dict:
    parameter_count, noise_count = 2048, 128
    shortlist_count = 16
    joint_count = shortlist_count * noise_count
    hours, origins = spec["hours"], spec["selection_origins"]
    warmup_hours = int((np.datetime64(spec["start"], "h") - np.datetime64("1999-01-01T01", "h")) /
                       np.timedelta64(1, "h"))
    arrays = {
        "parameter_values": ((parameter_count, 5), "float64"),
        "parameter_ids": ((parameter_count,), "int64"),
        "noise_design": ((noise_count, 5), "float64"),
        "warmup_timestamps": ((warmup_hours,), "datetime64[h]"),
        "warmup_forcing": ((warmup_hours, 2), "float64"),
        "calibration_timestamps": ((hours,), "datetime64[h]"),
        "calibration_forcing": ((hours, 2), "float64"),
        "calibration_observations": ((hours,), "float64"),
        "calibration_indices": ((hours,), "int64"),
        "hydrologic_predictions": ((parameter_count, hours), "float64"),
        "warmup_states": ((parameter_count, 5), "float64"),
        "hydrologic_alive": ((parameter_count,), "bool"),
        "hydrologic_completed": ((parameter_count,), "bool"),
        "hydrologic_last_states": ((parameter_count, 5), "float64"),
        "warmup_completed": ((parameter_count,), "bool"),
        "hydrologic_valid": ((parameter_count,), "bool"),
        "hydrologic_prediction_mask": ((parameter_count, hours), "bool"),
        "hydrologic_errors": ((parameter_count,), "float64"),
        "shortlist_parameter_ids": ((shortlist_count,), "int64"),
        "origin_indices": ((origins,), "int64"),
        "target_indices": ((origins, 4), "int64"),
        "origin_timestamps": ((origins,), "datetime64[h]"),
        "target_timestamps": ((origins, 4), "datetime64[h]"),
        "target_observations": ((origins, 4), "float64"),
        "persistence_predictions": ((origins, 4), "float64"),
        "persistence_mask": ((origins, 4), "bool"),
        "reference_errors": ((4,), "float64"),
        "joint_parameter_ids": ((joint_count,), "int64"),
        "joint_noise_ids": ((joint_count,), "int64"),
        "joint_predictions": ((joint_count, origins, 4), "float64"),
        "joint_origin_global_states": ((joint_count, origins, 5), "float64"),
        "joint_origin_probabilities": ((joint_count, origins, 1), "float64"),
        "joint_valid": ((joint_count,), "bool"),
        "joint_alive": ((joint_count,), "bool"),
        "joint_completed": ((joint_count,), "bool"),
        "joint_last_member_states": ((joint_count, 1, 5), "float64"),
        "joint_last_member_covariances": ((joint_count, 1, 5, 5), "float64"),
        "joint_last_probabilities": ((joint_count, 1), "float64"),
        "joint_prediction_mask": ((joint_count, origins, 4), "bool"),
        "joint_errors": ((joint_count, 4), "float64"),
        "joint_scores": ((joint_count,), "float64"),
        "joint_rank_order": ((joint_count,), "int64"),
    }
    record = _array_file(arrays)
    record.update(warmup_hours=warmup_hours, calibration_hours=hours,
                  selection_origins=origins)
    return record


def _assessment_final_layout(spec: dict) -> dict:
    chain_hours = {"E1": 81096, "E2": 76728, "E3": 63576}[spec["endpoint"]]
    origins = 2161 + {"E1": 360, "E2": 360, "E3": 361}[spec["endpoint"]]
    arrays = {
        "timestamps": ((chain_hours,), "datetime64[h]"),
        "forcing": ((chain_hours, 2), "float64"),
        "observations": ((chain_hours,), "float64"),
        "posterior_states": ((chain_hours, 5), "float64"),
        "posterior_covariances": ((chain_hours, 5, 5), "float64"),
        "origins": ((origins,), "int64"),
        "target_indices": ((origins, 120), "int64"),
        "truth": ((origins, 120), "float64"),
        "forecast_forcing": ((origins, 120, 2), "float64"),
        "persistence": ((origins, 120), "float64"),
        "predictions": ((origins, 120), "float64"),
        "period_codes": ((origins,), "int8"),
        "selected_parameter_id": ((1,), "int64"),
        "selected_noise_id": ((1,), "int64"),
    }
    record = _array_file(arrays)
    record.update(chain_hours=chain_hours, origins=origins)
    return record


def _state_checkpoint_layout(spec: dict) -> dict:
    chain_hours = {"E1": 81096, "E2": 76728, "E3": 63576}[spec["endpoint"]]
    count = (chain_hours + 719) // 720
    record = _array_file({
        "member_states": ((1, 1, 5), "float64"),
        "member_covariances": ((1, 1, 5, 5), "float64"),
        "probabilities": ((1, 1), "float64"),
        "global_state": ((1, 5), "float64"),
        "hour_index": ((1,), "int64"),
    }, file_count=count)
    record.update(checkpoint_count=count, checkpoint_interval_hours=720)
    return record


def _prediction_block_layout(spec: dict) -> dict:
    origins = 2161 + {"E1": 360, "E2": 360, "E3": 361}[spec["endpoint"]]
    full, remainder = divmod(origins, 30)
    sizes = {30: full}
    if remainder:
        sizes[remainder] = 1
    layouts, total = {}, 0
    for size, count in sizes.items():
        row = _array_file({
            "origins": ((size,), "int64"),
            "truth": ((size, 120), "float64"),
            "forecast_forcing": ((size, 120, 2), "float64"),
            "persistence": ((size, 120), "float64"),
            "predictions": ((size, 120), "float64"),
        }, file_count=count)
        layouts[str(size)] = row
        total += row["estimated_file_bytes"]
    return dict(origin_count=origins, block_size=30, block_count=sum(sizes.values()),
                layouts_by_origin_count=layouts, estimated_file_bytes=total)


def _resource_plan(root: Path) -> dict:
    upstream, upstream_sha256 = _verified_upstream_resource_receipt()
    new_specs = [spec for spec in window_specs() if spec["months"] in (6, 12)]
    all_specs = list(window_specs())
    raw_layouts = {spec["exp_id"]: _raw_calibration_layout(spec) for spec in new_specs}
    final_layouts = {spec["exp_id"]: _assessment_final_layout(spec) for spec in all_specs}
    checkpoint_layouts = {spec["exp_id"]: _state_checkpoint_layout(spec) for spec in all_specs}
    block_layouts = {spec["exp_id"]: _prediction_block_layout(spec) for spec in all_specs}
    reconstruction = _array_file({
        "reconstructed_predictions": ((30256, 120), "float64"),
        "production_predictions_copy": ((30256, 120), "float64"),
        "absolute_differences": ((30256, 120), "float64"),
        "valid_mask": ((30256, 120), "bool"),
    })
    source_snapshot_bytes = sum(path.stat().st_size for path in _source_files())
    metadata_and_log_overhead = 4096 * (
        5 * len(new_specs) + 5 * len(all_specs)
        + sum(row["checkpoint_count"] for row in checkpoint_layouts.values())
        + sum(row["block_count"] for row in block_layouts.values())
        + 32
    )
    persistent_components = dict(
        new_calibration_raw_arrays=sum(row["estimated_file_bytes"] for row in raw_layouts.values()),
        assessment_final_arrays=sum(row["estimated_file_bytes"] for row in final_layouts.values()),
        state_checkpoint_files=sum(row["estimated_file_bytes"] for row in checkpoint_layouts.values()),
        prediction_block_files=sum(row["estimated_file_bytes"] for row in block_layouts.values()),
        independent_reconstruction_arrays=reconstruction["estimated_file_bytes"],
        source_snapshots=source_snapshot_bytes,
        metadata_and_logs=metadata_and_log_overhead,
    )
    largest_raw = max(row["estimated_file_bytes"] for row in raw_layouts.values())
    largest_assessment = max(row["estimated_file_bytes"] for row in final_layouts.values())
    largest_block = max(
        layout["estimated_file_bytes"]
        for row in block_layouts.values()
        for layout in row["layouts_by_origin_count"].values()
    )
    temporary_components = dict(
        largest_raw_archive_copy=largest_raw,
        largest_assessment_array_copy=largest_assessment,
        largest_prediction_block_copy=largest_block,
        reconstruction_prediction_copy=30256 * 120 * np.dtype("float64").itemsize,
    )
    persistent_output = sum(persistent_components.values())
    temporary_bytes = sum(temporary_components.values())
    estimated_peak_disk = persistent_output + temporary_bytes
    upstream_measurements = upstream.get("preflight_measurements", {})
    upstream_baseline = int(upstream_measurements.get("baseline_rss_bytes", 0))
    upstream_estimated_peak = int(upstream.get("estimated_peak_rss_bytes", 0))
    largest_working_payload = max(
        max(row["payload_bytes"] for row in raw_layouts.values()),
        max(row["payload_bytes"] for row in final_layouts.values()),
        reconstruction["payload_bytes"],
    )
    memory_temporary_copy = largest_working_payload
    estimated_peak = max(upstream_estimated_peak,
                         upstream_baseline + largest_working_payload + memory_temporary_copy)
    required_memory = max(4 * 1024**3, 2 * estimated_peak)
    required_disk = max(20 * 1024**3, 2 * estimated_peak_disk)
    available_memory = psutil.virtual_memory().available
    disk_parent = root.parent if root.parent.exists() else PROJECT
    available_disk = shutil.disk_usage(disk_parent).free
    longest = root / "calibration" / "RL-E3-M12" / "progress" / "joint_forecast_chunk_000003305472_complete.npz"
    maximum_path = len(str(longest))
    if maximum_path >= 240:
        raise RuntimeError(f"expected output path is too long: {maximum_path}")
    passed = available_memory >= required_memory and available_disk >= required_disk
    return dict(
        passed=passed,
        available_memory_bytes=available_memory,
        required_memory_bytes=required_memory,
        estimated_peak_memory_bytes=estimated_peak,
        largest_shape_driven_working_payload_bytes=largest_working_payload,
        memory_temporary_copy_bytes=memory_temporary_copy,
        available_disk_bytes=available_disk,
        required_disk_bytes=required_disk,
        estimated_total_output_bytes=persistent_output,
        estimated_temporary_disk_bytes=temporary_bytes,
        estimated_peak_disk_bytes=estimated_peak_disk,
        persistent_components=persistent_components,
        temporary_components=temporary_components,
        array_shape_estimates=dict(
            new_calibration_raw_arrays=raw_layouts,
            assessment_final_arrays=final_layouts,
            state_checkpoints=checkpoint_layouts,
            prediction_blocks=block_layouts,
            independent_reconstruction=reconstruction,
        ),
        upstream_resource_receipt_sha256=upstream_sha256,
        upstream_estimated_peak_rss_bytes=upstream_estimated_peak,
        maximum_output_path_characters=maximum_path,
        recalibrations=6,
        selection_windows=12,
        assessment_chains=12,
        calibration_hydrologic_steps=412766208,
        calibration_filter_member_hours=80805888,
        calibration_origins=3305472,
        calibration_forecast_steps=396656640,
        assessment_filter_hours=885600,
        assessment_origins=30256,
        production_forecast_steps=3630720,
        reconstruction_forecast_steps=3630720,
    )


def _registry(root: Path) -> list[dict]:
    state_specs = {row["endpoint"]: row for row in state_preparation_specs()}
    records = []
    fixed = (
        "candidate budgets, seeds, observed forcing, selection score, endpoint, "
        "three-month state preparation rule, evaluation origins, filter settings"
    )
    for spec in window_specs():
        common = dict(
            selection_id=spec["exp_id"],
            hypothesis="selection record length changes the quality of one fixed parameter-noise model",
            data_start=spec["start"],
            data_stop=spec["stop"],
            state_preparation_start=state_specs[spec["endpoint"]]["start"],
            state_preparation_stop=state_specs[spec["endpoint"]]["stop"],
            changed_factor="selection record length: 3, 6, 12, or 24 calendar months",
            fixed_factors=fixed,
            seeds={"parameter_design": 915031, "noise_design": 909001},
            calibration_source=spec["calibration_source"],
            status="prepared",
            run_dir=str(root),
            metrics_path=str(root / "curves_1_to_120_hours.csv"),
            paper_name="single-model selection record-length comparison",
        )
        records.append(dict(record_type="selection", assessment_id=None, **common))
        records.append(dict(record_type="assessment",
                            assessment_id=f"{spec['exp_id']}-MATCHED3", **common))
    return records


def _snapshot_sources(root: Path, hashes: dict[str, str]) -> dict[str, str]:
    snapshots = {}
    for index, (path_text, expected) in enumerate(hashes.items()):
        source = Path(path_text)
        target = root / "source_snapshot" / f"{index:03d}_{source.name}"
        target.parent.mkdir(parents=True, exist_ok=True)
        with source.open("rb") as original, target.open("xb") as saved:
            shutil.copyfileobj(original, saved)
        if sha256(target) != expected:
            raise RuntimeError(f"source snapshot differs: {source}")
        snapshots[path_text] = target.relative_to(root).as_posix()
    return snapshots


def _write_success_receipt_atomic(root: Path, record: dict) -> None:
    """Publish the success receipt atomically as the final preparation write."""
    target = root / "preparation_receipt.json"
    if target.exists():
        raise FileExistsError(f"success receipt already exists: {target}")
    temporary = root / f".preparation_receipt.{os.getpid()}.{time.time_ns()}.tmp"
    payload = (json.dumps(record, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")
    try:
        with temporary.open("xb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        if target.exists():
            raise FileExistsError(f"success receipt appeared during finalization: {target}")
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()


def prepare() -> Path:
    """Verify all inputs, then create one exclusive frozen preparation attempt."""
    root = Path(OUTPUT)
    if root.exists():
        raise FileExistsError(f"exclusive result directory already exists: {root}")
    started = time.perf_counter()
    root.parent.mkdir(parents=True, exist_ok=True)
    root.mkdir(exist_ok=False)
    try:
        (root / "events.jsonl").touch(exist_ok=False)
        _event(root, "prepare_started", selection_windows=12, assessment_chains=12)
        versions = _versions()
        before = _source_hashes()
        bound = _verify_bound_sources()
        dates, _, _, input_checks = load_inputs()
        origins = origin_arrays(dates)
        masks = common_warmup_state_masks()
        covariance = fixed_initial_covariance()
        resource = _resource_plan(root)
        if not resource["passed"]:
            raise RuntimeError("available memory or disk does not meet the frozen resource gate")
        if _source_hashes() != before:
            raise RuntimeError("source changed during preparation checks")
        snapshots = _snapshot_sources(root, before)
        registry = _registry(root)
        config = dict(
            schema="regge_record_length_study_v01",
            windows=list(window_specs()),
            state_preparation=list(state_preparation_specs()),
            evaluation_periods=list(evaluation_period_specs()),
            registry=registry,
            parameter_design_seed=915031,
            parameter_design_count=2048,
            shortlist_count=16,
            noise_design_seed=909001,
            noise_design_count=128,
            selection_leads=[48, 120],
            selection_score="0.5*(RMSE48/persistence_RMSE48+RMSE120/persistence_RMSE120)",
            forecast_leads=list(range(1, 121)),
            observation_variance=0.000015,
            initial_state=[140.0, 1000.0, 4.0, 1200.0, 0.1],
            initial_covariance_sha256=FIXED_INITIAL_COVARIANCE_SHA256,
            initial_covariance=covariance.tolist(),
            numerical_reconstruction_tolerance=1e-8,
            relative_tolerance=0,
            short_to_reference_limit=1.05,
            method_to_persistence_limit=0.95,
            state_checkpoint_hours=720,
            state_checkpoint_wall_seconds=1800,
            forecast_chunk_origins=30,
            dtype="float64",
            device="cpu",
            cpu_threads=1,
            gradients=False,
            versions=versions,
            source_plan_sha256=sha256(PLAN),
        )
        write_json_new(root / "config.json", config)
        mask_arrays = {f"warmup_finite_{endpoint}": mask for endpoint, mask in masks.items()}
        save_npz_new(root / "origin_manifest.npz", **origins, **mask_arrays)
        write_json_new(root / "resource_plan.json", resource)
        binding = dict(
            schema="regge_record_length_source_binding_v01",
            **bound,
            source_hashes=before,
            source_snapshots=snapshots,
            input_checks=input_checks,
            warmup_masks={endpoint: dict(count=int(mask.sum()), sha256=array_sha256(mask))
                          for endpoint, mask in masks.items()},
            initial_covariance_sha256=FIXED_INITIAL_COVARIANCE_SHA256,
            versions=versions,
        )
        write_json_new(root / "source_binding.json", binding)
        if _source_hashes() != before:
            raise RuntimeError("source changed while writing the preparation")
        _event(root, "prepare_completed", elapsed_seconds=time.perf_counter() - started)
        # The root event log is intentionally append-only across later stages.
        # The completion event is written before this final atomic marker, but
        # only immutable preparation artifacts belong to the frozen hash set.
        frozen = ("config.json", "source_binding.json", "origin_manifest.npz",
                  "resource_plan.json")
        _write_success_receipt_atomic(root, dict(
            schema="regge_record_length_preparation_receipt_v01",
            status="complete",
            passed=True,
            elapsed_seconds=time.perf_counter() - started,
            files={name: sha256(root / name) for name in frozen},
        ))
        return root
    except Exception as error:
        try:
            write_json_new(root / "preparation_failed.json", dict(
                schema="regge_record_length_preparation_failure_v01",
                passed=False,
                error_type=type(error).__name__,
                error=str(error),
                traceback=traceback.format_exc(),
                elapsed_seconds=time.perf_counter() - started,
            ))
            _event(root, "prepare_failed", error_type=type(error).__name__, error=str(error))
        finally:
            raise


def verify_prepared() -> dict:
    """Verify the frozen attempt and return its immutable configuration."""
    root = Path(OUTPUT)
    if (root / "preparation_failed.json").exists():
        raise RuntimeError("failure receipt coexists with preparation success state")
    receipt = read_json(root / "preparation_receipt.json")
    if receipt.get("passed") is not True or receipt.get("status") != "complete":
        raise RuntimeError("preparation did not complete")
    for name, expected in receipt.get("files", {}).items():
        if sha256(root / name) != expected:
            raise RuntimeError(f"frozen preparation artifact changed: {name}")
    binding = read_json(root / "source_binding.json")
    if _source_hashes() != binding.get("source_hashes"):
        raise RuntimeError("preparation source changed after freezing")
    for path, relative in binding.get("source_snapshots", {}).items():
        if sha256(root / relative) != binding["source_hashes"][path]:
            raise RuntimeError(f"source snapshot changed: {path}")
    current_bound = _verify_bound_sources()
    if current_bound != {key: binding[key] for key in current_bound}:
        raise RuntimeError("bound source set differs from preparation")
    with np.load(root / "origin_manifest.npz", allow_pickle=False) as saved:
        masks = {endpoint: saved[f"warmup_finite_{endpoint}"] for endpoint in ("E1", "E2", "E3")}
    for endpoint, mask in masks.items():
        record = binding["warmup_masks"][endpoint]
        if int(mask.sum()) != record["count"] or array_sha256(mask) != record["sha256"]:
            raise RuntimeError(f"frozen warmup mask changed: {endpoint}")
    return read_json(root / "config.json")
