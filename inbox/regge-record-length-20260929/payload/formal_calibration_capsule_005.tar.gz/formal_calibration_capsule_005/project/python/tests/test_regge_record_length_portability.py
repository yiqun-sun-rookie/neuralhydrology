"""Cross-platform locks for the record-length calibration designs."""
from __future__ import annotations

from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import pytest


PROJECT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT / "python"))

from regge_record_length_study import calibration
from regge_record_length_study import prepare as preparation
from regge_record_length_study.common import array_sha256, read_json, sha256


@pytest.mark.parametrize(
    ("path", "file_digest", "array_digest", "shape", "label"),
    [
        (
            calibration.CANONICAL_PARAMETER_DESIGN,
            calibration.CANONICAL_PARAMETER_FILE_SHA256,
            calibration.PARAMETER_DESIGN_SHA256,
            (2048, 5),
            "parameter",
        ),
        (
            calibration.CANONICAL_NOISE_DESIGN,
            calibration.CANONICAL_NOISE_FILE_SHA256,
            calibration.NOISE_DESIGN_SHA256,
            (128, 5),
            "noise",
        ),
    ],
)
def test_canonical_design_files_are_byte_locked_and_read_only(
        path, file_digest, array_digest, shape, label):
    assert sha256(path) == file_digest
    values = calibration._canonical_design(
        path,
        file_sha256=file_digest,
        array_sha256_expected=array_digest,
        shape=shape,
        label=label,
    )
    assert values.shape == shape
    assert values.dtype == np.float64
    assert values.flags.c_contiguous
    assert not values.flags.writeable
    assert array_sha256(values) == array_digest
    with pytest.raises(ValueError):
        values.flat[0] = values.flat[0]


@pytest.mark.parametrize(
    ("path", "file_digest", "array_digest", "shape", "label"),
    [
        (
            calibration.CANONICAL_PARAMETER_DESIGN,
            calibration.CANONICAL_PARAMETER_FILE_SHA256,
            calibration.PARAMETER_DESIGN_SHA256,
            (2048, 5),
            "parameter design",
        ),
        (
            calibration.CANONICAL_NOISE_DESIGN,
            calibration.CANONICAL_NOISE_FILE_SHA256,
            calibration.NOISE_DESIGN_SHA256,
            (128, 5),
            "noise design",
        ),
    ],
)
def test_one_float64_step_is_accepted_but_canonical_bytes_remain_authoritative(
        path, file_digest, array_digest, shape, label):
    canonical = calibration._canonical_design(
        path,
        file_sha256=file_digest,
        array_sha256_expected=array_digest,
        shape=shape,
        label=label,
    )
    generated = canonical.copy()
    generated.flat[0] = np.nextafter(generated.flat[0], np.inf)
    binding = calibration._require_at_most_one_float64_step(
        generated, canonical, label=label,
    )
    assert binding == {
        "canonical_array_sha256": array_digest,
        "generated_array_sha256": array_sha256(generated),
        "different_value_count": 1,
        "maximum_float64_steps": 1,
        "canonical_bytes_used_for_execution": True,
    }
    assert array_sha256(canonical) == array_digest
    assert array_sha256(generated) != array_digest


@pytest.mark.parametrize(
    ("path", "file_digest", "array_digest", "shape", "label"),
    [
        (
            calibration.CANONICAL_PARAMETER_DESIGN,
            calibration.CANONICAL_PARAMETER_FILE_SHA256,
            calibration.PARAMETER_DESIGN_SHA256,
            (2048, 5),
            "parameter design",
        ),
        (
            calibration.CANONICAL_NOISE_DESIGN,
            calibration.CANONICAL_NOISE_FILE_SHA256,
            calibration.NOISE_DESIGN_SHA256,
            (128, 5),
            "noise design",
        ),
    ],
)
def test_two_float64_steps_are_rejected_for_both_designs(
        path, file_digest, array_digest, shape, label):
    canonical = calibration._canonical_design(
        path,
        file_sha256=file_digest,
        array_sha256_expected=array_digest,
        shape=shape,
        label=label,
    )
    generated = canonical.copy()
    one_step = np.nextafter(generated.flat[0], np.inf)
    generated.flat[0] = np.nextafter(one_step, np.inf)
    with pytest.raises(ValueError, match="more than one float64 step"):
        calibration._require_at_most_one_float64_step(
            generated, canonical, label=label,
        )


def test_noise_binding_accepts_observed_portable_drift_and_keeps_canonical_bytes():
    canonical = calibration._canonical_design(
        calibration.CANONICAL_NOISE_DESIGN,
        file_sha256=calibration.CANONICAL_NOISE_FILE_SHA256,
        array_sha256_expected=calibration.NOISE_DESIGN_SHA256,
        shape=(128, 5),
        label="noise",
    )
    generated = canonical.copy()
    for _ in range(15):
        generated[48, 1] = np.nextafter(generated[48, 1], -np.inf)
    binding = calibration._bind_portable_noise_design(generated, canonical)
    assert binding["different_value_count"] == 1
    assert binding["maximum_float64_steps"] == 15
    assert binding["generated_matches_canonical_bytes"] is False
    assert binding["canonical_bytes_used_for_execution"] is True
    assert binding["maximum_relative_difference"] <= binding["relative_tolerance"]
    assert array_sha256(canonical) == calibration.NOISE_DESIGN_SHA256


@pytest.mark.parametrize("column", range(5))
@pytest.mark.parametrize("extreme", ("minimum", "maximum"))
@pytest.mark.parametrize("direction", (-1, 1))
@pytest.mark.parametrize("step_count", (1, 15))
def test_noise_binding_accepts_portable_drift_across_columns_and_extremes(
        column, extreme, direction, step_count):
    canonical = calibration._canonical_design(
        calibration.CANONICAL_NOISE_DESIGN,
        file_sha256=calibration.CANONICAL_NOISE_FILE_SHA256,
        array_sha256_expected=calibration.NOISE_DESIGN_SHA256,
        shape=(128, 5),
        label="noise",
    )
    candidates = np.flatnonzero(canonical[1:, column] > 0.0) + 1
    values = canonical[candidates, column]
    row = int(candidates[np.argmin(values) if extreme == "minimum" else np.argmax(values)])
    generated = canonical.copy()
    target = -np.inf if direction < 0 else np.inf
    for _ in range(step_count):
        generated[row, column] = np.nextafter(generated[row, column], target)
    binding = calibration._bind_portable_noise_design(generated, canonical)
    assert binding["different_value_count"] == 1
    assert binding["maximum_float64_steps"] == step_count
    assert binding["canonical_array_sha256"] == calibration.NOISE_DESIGN_SHA256
    assert binding["generated_array_sha256"] == array_sha256(generated)
    calibration.validate_design_binding(binding, name="noise")


def test_noise_binding_exact_match_records_zero_drift():
    canonical = calibration._canonical_design(
        calibration.CANONICAL_NOISE_DESIGN,
        file_sha256=calibration.CANONICAL_NOISE_FILE_SHA256,
        array_sha256_expected=calibration.NOISE_DESIGN_SHA256,
        shape=(128, 5),
        label="noise",
    )
    binding = calibration._bind_portable_noise_design(canonical.copy(), canonical)
    assert binding["generated_matches_canonical_bytes"] is True
    assert binding["different_value_count"] == 0
    assert binding["maximum_float64_steps"] == 0
    assert binding["maximum_absolute_difference"] == 0.0
    assert binding["maximum_relative_difference"] == 0.0


def test_noise_binding_enforces_relative_tolerance_boundary():
    canonical = calibration._canonical_design(
        calibration.CANONICAL_NOISE_DESIGN,
        file_sha256=calibration.CANONICAL_NOISE_FILE_SHA256,
        array_sha256_expected=calibration.NOISE_DESIGN_SHA256,
        shape=(128, 5),
        label="noise",
    )
    row, column = 48, 1
    value = canonical[row, column]
    accepted = value
    for _ in range(256):
        candidate = np.nextafter(accepted, np.inf)
        if abs(candidate - value) / value > calibration.NOISE_REPRODUCTION_RELATIVE_TOLERANCE:
            rejected = candidate
            break
        accepted = candidate
    else:
        raise AssertionError("relative-tolerance boundary was not reached")
    accepted_design = canonical.copy()
    accepted_design[row, column] = accepted
    rejected_design = canonical.copy()
    rejected_design[row, column] = rejected
    accepted_binding = calibration._bind_portable_noise_design(
        accepted_design, canonical,
    )
    assert accepted_binding["maximum_relative_difference"] <= (
        calibration.NOISE_REPRODUCTION_RELATIVE_TOLERANCE
    )
    with pytest.raises(ValueError, match="portable relative tolerance"):
        calibration._bind_portable_noise_design(rejected_design, canonical)


def test_noise_binding_rejects_material_drift_and_changed_zero_pattern():
    canonical = calibration._canonical_design(
        calibration.CANONICAL_NOISE_DESIGN,
        file_sha256=calibration.CANONICAL_NOISE_FILE_SHA256,
        array_sha256_expected=calibration.NOISE_DESIGN_SHA256,
        shape=(128, 5),
        label="noise",
    )
    material = canonical.copy()
    material[48, 1] *= (
        1.0 + 4.0 * calibration.NOISE_REPRODUCTION_RELATIVE_TOLERANCE
    )
    with pytest.raises(ValueError, match="portable relative tolerance"):
        calibration._bind_portable_noise_design(material, canonical)

    changed_zero = canonical.copy()
    changed_zero[1, 4] = np.nextafter(0.0, np.inf)
    with pytest.raises(ValueError, match="zero pattern"):
        calibration._bind_portable_noise_design(changed_zero, canonical)

    removed_positive = canonical.copy()
    removed_positive[48, 1] = 0.0
    with pytest.raises(ValueError, match="positive pattern"):
        calibration._bind_portable_noise_design(removed_positive, canonical)

    changed_original = canonical.copy()
    changed_original[0, 0] = np.nextafter(changed_original[0, 0], np.inf)
    with pytest.raises(ValueError, match="unchanged original row"):
        calibration._bind_portable_noise_design(changed_original, canonical)

    signed_zero_original = canonical.copy()
    signed_zero_original[0, 4] = -0.0
    with pytest.raises(ValueError, match="unchanged original row"):
        calibration._bind_portable_noise_design(signed_zero_original, canonical)

    signed_zero_branch = canonical.copy()
    signed_zero_branch[1, 4] = -0.0
    with pytest.raises(ValueError, match="zero pattern"):
        calibration._bind_portable_noise_design(signed_zero_branch, canonical)


@pytest.mark.parametrize("failure_kind", (
    "shape", "dtype", "nan", "positive_infinity", "negative", "row_order",
    "column_order", "different_seed",
))
def test_noise_binding_rejects_structural_or_semantic_changes(failure_kind):
    canonical = calibration._canonical_design(
        calibration.CANONICAL_NOISE_DESIGN,
        file_sha256=calibration.CANONICAL_NOISE_FILE_SHA256,
        array_sha256_expected=calibration.NOISE_DESIGN_SHA256,
        shape=(128, 5),
        label="noise",
    )
    if failure_kind == "shape":
        changed = canonical[:-1].copy()
        match = "structure"
    elif failure_kind == "dtype":
        changed = canonical.astype(np.float32)
        match = "structure"
    elif failure_kind == "nan":
        changed = canonical.copy()
        changed[48, 1] = np.nan
        match = "structure"
    elif failure_kind == "positive_infinity":
        changed = canonical.copy()
        changed[48, 1] = np.inf
        match = "structure"
    elif failure_kind == "negative":
        changed = canonical.copy()
        changed[48, 1] *= -1.0
        match = "negative"
    elif failure_kind == "row_order":
        changed = canonical.copy()
        changed[[1, 2]] = changed[[2, 1]]
        match = "portable relative tolerance"
    elif failure_kind == "column_order":
        changed = canonical[:, [1, 0, 2, 3, 4]].copy()
        match = "unchanged original row"
    else:
        _, _, noise = calibration._load_sealed_core()
        changed = noise.build_noise_design(seed=909002)
        match = "portable relative tolerance"
    with pytest.raises(ValueError, match=match):
        calibration._bind_portable_noise_design(changed, canonical)


def test_canonical_noise_file_tampering_is_rejected(tmp_path):
    changed = tmp_path / "canonical_noise_design.npy"
    payload = bytearray(calibration.CANONICAL_NOISE_DESIGN.read_bytes())
    payload[-1] ^= 1
    changed.write_bytes(payload)
    with pytest.raises(RuntimeError, match="canonical noise design file changed"):
        calibration._canonical_design(
            changed,
            file_sha256=calibration.CANONICAL_NOISE_FILE_SHA256,
            array_sha256_expected=calibration.NOISE_DESIGN_SHA256,
            shape=(128, 5),
            label="noise",
        )


def _failure_test_bound(exp_id: str) -> calibration.BoundCalibrationInputs:
    empty_dates = np.empty(0, dtype="datetime64[h]")
    empty_forcing = np.empty((0, 2), dtype=np.float64)
    empty_flow = np.empty(0, dtype=np.float64)
    return calibration.BoundCalibrationInputs(
        empty_dates, empty_forcing, empty_dates.copy(), empty_forcing.copy(),
        empty_flow,
        {"exp_id": exp_id, "source_hashes": {"raw_data": "test-source"}},
    )


def test_ordinary_execution_failure_preserves_established_design_binding(
        tmp_path, monkeypatch):
    import regge_record_length_study.contract as study_contract

    spec = calibration.missing_calibration_specs()[0]
    bound = _failure_test_bound(spec["exp_id"])
    binding = {
        "parameter": {"canonical_bytes_used_for_execution": True},
        "noise": {"canonical_bytes_used_for_execution": True},
    }
    monkeypatch.setattr(study_contract, "load_inputs", lambda: object())
    monkeypatch.setattr(
        calibration, "bind_calibration_inputs", lambda *_args: bound,
    )

    def fail_after_binding(*_args, **_kwargs):
        error = RuntimeError("core stopped after design binding")
        error.regge_record_length_design_binding = binding
        raise error

    monkeypatch.setattr(calibration, "_execute_bound_calibration", fail_after_binding)
    destination = tmp_path / spec["exp_id"]
    with pytest.raises(RuntimeError, match="core stopped after design binding"):
        calibration.calibrate_one(spec, destination)
    result = read_json(destination / "result.json")
    receipt = read_json(destination / "receipt.json")
    assert result["design_binding"] == binding
    assert receipt["design_binding"] == binding


def test_post_binding_pre_core_failure_carries_both_design_bindings(monkeypatch):
    spec = calibration.missing_calibration_specs()[0]
    bound = _failure_test_bound(spec["exp_id"])

    def fail_input_recheck(*_args, **_kwargs):
        raise RuntimeError("post-binding input recheck stopped")

    monkeypatch.setattr(
        calibration, "_validated_core_inputs", fail_input_recheck,
    )
    with pytest.raises(RuntimeError, match="post-binding input recheck") as caught:
        calibration._execute_bound_calibration(
            bound, spec["exp_id"], lambda *_args, **_kwargs: None,
        )
    binding = caught.value.regge_record_length_design_binding
    assert set(binding) == {"parameter", "noise"}
    assert binding["parameter"]["canonical_bytes_used_for_execution"] is True
    assert binding["noise"]["canonical_bytes_used_for_execution"] is True
    assert binding["parameter"]["canonical_array_sha256"] == (
        calibration.PARAMETER_DESIGN_SHA256
    )
    assert binding["noise"]["canonical_array_sha256"] == (
        calibration.NOISE_DESIGN_SHA256
    )


def test_failure_before_design_binding_records_unestablished_stage(
        tmp_path, monkeypatch):
    import regge_record_length_study.contract as study_contract

    spec = calibration.missing_calibration_specs()[0]
    monkeypatch.setattr(
        study_contract, "load_inputs",
        lambda: (_ for _ in ()).throw(RuntimeError("input unavailable")),
    )
    destination = tmp_path / spec["exp_id"]
    with pytest.raises(RuntimeError, match="input unavailable"):
        calibration.calibrate_one(spec, destination)
    result = read_json(destination / "result.json")
    assert result["design_binding"] == {
        "status": "not_established",
        "failure_stage": "input_loading",
    }


def test_preparation_source_list_contains_both_canonical_designs():
    sources = set(preparation._source_files())
    assert calibration.CANONICAL_PARAMETER_DESIGN.resolve() in sources
    assert calibration.CANONICAL_NOISE_DESIGN.resolve() in sources


def test_assessment_identity_uses_canonical_noise_without_regeneration(monkeypatch):
    from regge_record_length_study import assessment

    canonical = calibration._canonical_design(
        calibration.CANONICAL_NOISE_DESIGN,
        file_sha256=calibration.CANONICAL_NOISE_FILE_SHA256,
        array_sha256_expected=calibration.NOISE_DESIGN_SHA256,
        shape=(128, 5),
        label="noise",
    )
    records = [{"cw": 100.0, "cv": 20.0, "cg": 1e6, "cq": 2.0, "cs": 0.1}]
    monkeypatch.setattr(
        calibration,
        "_validate_scientific_config",
        lambda *_args, **_kwargs: {"records": records},
    )

    def forbidden_regeneration(*_args, **_kwargs):
        raise AssertionError("assessment must not regenerate the frozen noise design")

    core = {
        "contract": object(),
        "short_record": object(),
        "noise_search": SimpleNamespace(build_noise_design=forbidden_regeneration),
    }
    identity = {
        "parameter_id": 0,
        "noise_id": 84,
        "parameters": records[0],
        "noise_diagonal": canonical[84].copy(),
    }
    assessment._validate_core_selected_identity(identity, core)
    wrong_row = dict(identity, noise_diagonal=canonical[85].copy())
    with pytest.raises(ValueError, match="process-noise identity"):
        assessment._validate_core_selected_identity(wrong_row, core)
    modified = canonical[84].copy()
    modified[0] = np.nextafter(modified[0], np.inf)
    with pytest.raises(ValueError, match="process-noise identity"):
        assessment._validate_core_selected_identity(
            dict(identity, noise_diagonal=modified), core,
        )
