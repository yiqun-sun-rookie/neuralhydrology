"""Production binding/persistence -> real artifact acceptance regression tests.

Only the costly numerical search is substituted with explicitly synthetic,
full-shape arrays. Input binding, design gates, persistence, file receipts,
worker acceptance and numerical ranking reconstruction are not mocked.
"""
from __future__ import annotations

import json
from pathlib import Path
import shutil
import sys

import numpy as np
import pytest

PROJECT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT / "python"))

from regge_record_length_study import calibration, hpc_calibration, selection
from regge_record_length_study import prepare as preparation
from regge_record_length_study.common import array_sha256, read_json, sha256


def _canonical_noise():
    return calibration._canonical_design(
        calibration.CANONICAL_NOISE_DESIGN,
        file_sha256=calibration.CANONICAL_NOISE_FILE_SHA256,
        array_sha256_expected=calibration.NOISE_DESIGN_SHA256,
        shape=(128, 5), label="noise",
    )


def test_preparation_and_capsule_bind_acceptance_regression_sources(tmp_path):
    bound_sources = set(preparation._source_files())
    capsule_sources = dict((relative, source) for source, relative in hpc_calibration._capsule_sources(
        tmp_path / "formal", tmp_path / "recipient.pem", tmp_path / "signer.pem",
    ))
    for relative in (
        "python/tests/test_regge_record_length_acceptance.py",
        "python/tests/fixtures/regge_record_length_fourth_worker_binding.json",
    ):
        source = (PROJECT / relative).resolve()
        assert source in bound_sources
        assert capsule_sources[f"project/{relative}"] == source


def _drifting_noise(steps=15):
    generated = _canonical_noise().copy()
    for _ in range(steps):
        generated[48, 1] = np.nextafter(generated[48, 1], -np.inf)
    return generated


def _synthetic_completed_search(core, spec, inputs, records, design, parameters):
    """Cheap full-budget fixture, not model output or scientific evidence."""
    shapes = selection._expected_shapes(spec)
    raw = {
        name: np.ones(shape, dtype=selection._DTYPES[name])
        for name, shape in shapes.items()
    }
    raw.update({name: values.copy() for name, values in inputs.items()})
    raw.update(
        parameter_values=parameters.copy(), parameter_ids=np.arange(2048, dtype=np.int64),
        noise_design=design.copy(), calibration_indices=np.arange(spec["hours"], dtype=np.int64),
    )
    observations = raw["calibration_observations"]
    # Deliberately unequal errors make shortlist and rank reconstruction useful.
    raw["hydrologic_predictions"] = (
        observations[None, :] + (np.arange(2048)[:, None] + 1) * 1e-5
    )
    raw["hydrologic_errors"] = core._errors(
        raw["hydrologic_predictions"], observations, raw["hydrologic_alive"],
    )
    shortlist = core.hydrologic_shortlist(raw["hydrologic_errors"])
    raw["shortlist_parameter_ids"] = np.asarray(shortlist, dtype=np.int64)
    dates = raw["calibration_timestamps"]
    origins = core.complete_origins(dates, 0, len(dates), (1, 24, 48, 120))
    targets = origins[:, None] + np.asarray([1, 24, 48, 120])
    raw.update(
        origin_indices=origins, target_indices=targets,
        origin_timestamps=dates[origins], target_timestamps=dates[targets],
        target_observations=observations[targets],
        persistence_predictions=np.broadcast_to(
            observations[origins, None], targets.shape,
        ).copy(),
    )
    raw["reference_errors"] = core._errors(
        raw["persistence_predictions"][None], raw["target_observations"],
        np.array([True]),
    )[0]
    pids, nids = core.joint_candidate_ids(shortlist, 128)
    raw.update(joint_parameter_ids=pids, joint_noise_ids=nids)
    raw["joint_predictions"] = (
        raw["target_observations"][None] + (np.arange(2048)[:, None, None] + 1) * 1e-5
    )
    raw["joint_errors"] = core._errors(
        raw["joint_predictions"], raw["target_observations"], raw["joint_valid"],
    )
    raw["joint_scores"] = core._selection_scores(
        raw["joint_errors"], raw["reference_errors"],
    )
    ranked = core.rank_joint_candidates(
        pids, nids, raw["joint_errors"], raw["reference_errors"],
    )
    raw["joint_rank_order"] = ranked["order"]
    members = [
        {"parameter_id": int(pid),
         "noise_id": int(nids[ranked["noise_rows_by_parameter"][pid][0]])}
        for pid in ranked["member_parameter_ids"]
    ]
    return {
        "status": "complete", "phase": "complete", "partial": False,
        "selection_failure": None, "evidence": "synthetic_test_only",
        "parameters": records, "leads": [1, 24, 48, 120], "raw": raw,
        "selected": {
            "members": members,
            "prespecified_single_parameter_id": members[0]["parameter_id"],
            "prespecified_single_noise_id": members[0]["noise_id"],
            "source_hashes": {
                name: array_sha256(raw[name]) for name in selection._SOURCE_ARRAY_NAMES
            },
        },
        "array_hashes": {
            name: {"sha256": array_sha256(values), "dtype": str(values.dtype),
                   "shape": list(values.shape)}
            for name, values in raw.items()
        },
    }


@pytest.fixture(scope="module")
def produced_worker(tmp_path_factory):
    """Exercise the real production wrapper and its actual saved artifacts."""
    directory = tmp_path_factory.mktemp("rl_accept") / "worker"
    stdout = directory.parent / "stdout.log"
    stderr = directory.parent / "stderr.log"
    spec = calibration.missing_calibration_specs()[0]
    _, core, noise = calibration._load_sealed_core()
    calls = []

    def synthetic_search(inputs, records, design, parameters, leads,
                         record_event, *, synthetic):
        assert synthetic is False
        assert leads == (1, 24, 48, 120)
        assert array_sha256(parameters) == calibration.PARAMETER_DESIGN_SHA256
        assert array_sha256(design) == calibration.NOISE_DESIGN_SHA256
        calls.append(True)
        return _synthetic_completed_search(core, spec, inputs, records, design, parameters)

    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(noise, "build_noise_design", lambda seed: _drifting_noise())
        patch.setattr(core, "_execute", synthetic_search)
        calibration.calibrate_one(spec, directory)
    assert calls == [True]
    stdout.write_text("synthetic integration fixture only\n", encoding="utf-8")
    stderr.write_text("", encoding="utf-8")
    (directory / "process.json").write_text(json.dumps({
        "schema": "regge_record_length_calibration_process_v01",
        "exp_id": spec["exp_id"], "exit_code": 0,
        "stdout_sha256": sha256(stdout), "stderr_sha256": sha256(stderr),
    }), encoding="utf-8")
    return directory, spec["exp_id"], stdout, stderr


def test_produced_portable_worker_passes_real_full_artifact_acceptance(produced_worker):
    directory, exp_id, stdout, stderr = produced_worker
    result = read_json(directory / "result.json")
    assert result["design_binding"]["noise"]["maximum_float64_steps"] == 15
    accepted = hpc_calibration._verify_worker(directory, exp_id, stdout, stderr)
    assert accepted["scientific_validation"] == "full_reconstruction_passed"
    assert accepted["selected_parameter_id"] == 0
    assert accepted["selected_noise_id"] == 0


@pytest.mark.parametrize("steps", [0, 1, 15])
def test_noise_producer_and_consumer_share_the_same_diagnostic_contract(steps):
    binding = calibration._bind_portable_noise_design(_drifting_noise(steps), _canonical_noise())
    calibration.validate_design_binding(binding, name="noise")


def test_observed_fourth_worker_binding_is_accepted_without_altering_evidence():
    evidence = read_json(Path(__file__).parent / "fixtures" / "regge_record_length_fourth_worker_binding.json")
    assert evidence["result_sha256"] == "a715b735fc401a51a7cc1837bef8b045fb72039f39f46878113695f90dd6cb2f"
    bindings = evidence["design_binding"]
    noise = bindings["noise"]
    assert noise["different_value_count"] == 281
    assert noise["maximum_float64_steps"] == 15
    assert noise["maximum_relative_difference"] == 1.928894053716072e-15
    # This is the ONLY old acceptance predicate the observed noise violated.
    assert noise["canonical_array_sha256"] == calibration.NOISE_DESIGN_SHA256
    assert noise["canonical_bytes_used_for_execution"] is True
    assert isinstance(noise["generated_array_sha256"], str)
    assert len(noise["generated_array_sha256"]) == 64
    assert isinstance(noise["different_value_count"], int)
    assert 0 <= noise["different_value_count"] <= 640
    assert (noise["different_value_count"] == 0) == (noise["maximum_float64_steps"] == 0)
    assert noise["maximum_float64_steps"] not in (0, 1)
    for name, binding in bindings.items():
        calibration.validate_design_binding(binding, name=name)


def test_noise_relative_tolerance_boundary_is_accepted_by_both_gates():
    generated = _canonical_noise().copy()
    value = generated[48, 1]
    for _ in range(256):
        changed = np.nextafter(generated[48, 1], -np.inf)
        if abs(changed - value) / value > calibration.NOISE_REPRODUCTION_RELATIVE_TOLERANCE:
            break
        generated[48, 1] = changed
    else:
        raise AssertionError("tolerance boundary not reached")
    binding = calibration._bind_portable_noise_design(generated, _canonical_noise())
    calibration.validate_design_binding(binding, name="noise")
    generated[48, 1] = changed
    with pytest.raises(ValueError, match="portable relative tolerance"):
        calibration._bind_portable_noise_design(generated, _canonical_noise())


@pytest.mark.parametrize(("field", "value"), [
    ("canonical_array_sha256", "0" * 64),
    ("generated_array_sha256", "z" * 64),
    ("generated_array_sha256", calibration.NOISE_DESIGN_SHA256),
    ("canonical_bytes_used_for_execution", False),
    ("generated_matches_canonical_bytes", True),
    ("zero_pattern_preserved", False),
    ("different_value_count", True), ("different_value_count", -1),
    ("different_value_count", 641), ("different_value_count", 0),
    ("maximum_float64_steps", True), ("maximum_float64_steps", 0),
    ("maximum_float64_steps", -1), ("maximum_float64_steps", 129),
    ("maximum_absolute_difference", 0.0), ("maximum_absolute_difference", -1.0),
    ("maximum_absolute_difference", np.inf), ("maximum_absolute_difference", np.nan),
    ("maximum_relative_difference", 0.0), ("maximum_relative_difference", -1.0),
    ("maximum_relative_difference", np.inf), ("maximum_relative_difference", np.nan),
    ("maximum_relative_difference", 2 * calibration.NOISE_REPRODUCTION_RELATIVE_TOLERANCE),
    ("relative_tolerance", 2 * calibration.NOISE_REPRODUCTION_RELATIVE_TOLERANCE),
    ("tolerance_basis", "relaxed_after_observing_scores"),
])
def test_saved_noise_diagnostic_tampering_is_rejected(field, value):
    binding = calibration._bind_portable_noise_design(_drifting_noise(), _canonical_noise())
    binding[field] = value
    with pytest.raises(ValueError, match="noise design binding differs"):
        calibration.validate_design_binding(binding, name="noise")


@pytest.mark.parametrize("missing_field", [
    "maximum_absolute_difference", "maximum_relative_difference", "relative_tolerance",
    "tolerance_basis", "zero_pattern_preserved", "generated_matches_canonical_bytes",
])
def test_saved_noise_diagnostic_requires_portability_evidence(missing_field):
    binding = calibration._bind_portable_noise_design(_drifting_noise(), _canonical_noise())
    del binding[missing_field]
    with pytest.raises(ValueError, match="noise design binding differs"):
        calibration.validate_design_binding(binding, name="noise")


@pytest.mark.parametrize("mutation", [
    "noise_tolerance", "parameter_two_steps", "canonical_noise", "canonical_parameters",
    "joint_errors", "joint_rank_order",
])
def test_real_worker_acceptance_rejects_resigned_tampering(
        produced_worker, tmp_path, mutation):
    original, exp_id, stdout, stderr = produced_worker
    directory = tmp_path / "tampered"
    shutil.copytree(original, directory)
    result = read_json(directory / "result.json")
    expected = {
        "noise_tolerance": "noise design binding differs",
        "parameter_two_steps": "parameter design binding differs",
        "canonical_noise": "canonical noise design differs",
        "canonical_parameters": "canonical parameter design differs",
        "joint_errors": "candidate error reconstruction differs",
        "joint_rank_order": "rank order differs",
    }[mutation]
    if mutation == "noise_tolerance":
        result["design_binding"]["noise"]["relative_tolerance"] *= 2
    elif mutation == "parameter_two_steps":
        result["design_binding"]["parameter"].update(
            maximum_float64_steps=2, different_value_count=1,
            generated_array_sha256="0" * 64,
        )
    else:
        with np.load(directory / "raw.npz", allow_pickle=False) as saved:
            raw = {name: saved[name] for name in saved.files}
        field = {"canonical_noise": "noise_design", "canonical_parameters": "parameter_values"}.get(
            mutation, mutation,
        )
        if mutation == "joint_rank_order":
            raw[field][[0, 1]] = raw[field][[1, 0]]
        else:
            raw[field].flat[0] = np.nextafter(raw[field].flat[0], np.inf)
        np.savez_compressed(directory / "raw.npz", **raw)
        result["array_hashes"][field]["sha256"] = array_sha256(raw[field])
        if field in result["selected"]["source_hashes"]:
            result["selected"]["source_hashes"][field] = array_sha256(raw[field])
    (directory / "result.json").write_text(json.dumps(result), encoding="utf-8")
    receipt = read_json(directory / "receipt.json")
    for name in ("result.json", "raw.npz"):
        receipt["files"][name] = sha256(directory / name)
    (directory / "receipt.json").write_text(json.dumps(receipt), encoding="utf-8")
    # Updating checksums cannot authorize changed candidates, scores or rankings.
    with pytest.raises(ValueError, match=expected):
        hpc_calibration._verify_worker(directory, exp_id, stdout, stderr)
