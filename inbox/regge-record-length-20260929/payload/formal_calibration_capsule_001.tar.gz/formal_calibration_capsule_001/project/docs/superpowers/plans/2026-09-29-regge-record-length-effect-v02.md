# Regge资料长度影响试验实施计划（独立审核后修订版）

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在参数候选、过程噪声候选、选择指标、评价前状态准备历史和评价资料全部匹配的条件下，比较3、6、12、24个月资料对单模型物理参数与过程噪声选择及后续预报效果的影响。

**Architecture:** 设置三个固定的资料结束时刻；每个结束时刻向前构造四个嵌套资料段。复用已审计的3个月与24个月率定数组，新增6个月与12个月率定。选择身份全部冻结后，同一结束时刻的四个模型都从结束时刻前3个月的共同日期开始状态准备：各自使用所选物理参数对应的气象暖机状态、同一初始协方差和同一段逐小时观测流量，之后连续运行至2010年底。紧接资料期的一年决定“近期达标的最短已测长度”；共同的2005—2010年逐年结果只决定另一项“多年逐年稳定的最短已测长度”。独立审核程序重新选择组合、重建确定性预报、计算数值误差边界并重算全部指标。

**Tech Stack:** Windows、Python 3.11.5、NumPy 1.26.4、PyTorch 2.2.2、pytest；双精度、中央处理器单线程、不计算梯度。

## Global Constraints

- 本计划只比较“单模型逐时吸收观测流量更新状态”；多模型完全交互和不混合状态留给资料长度结论形成后的另一项试验。
- 资料长度是选择阶段唯一主动改变的因素。2,048套物理参数、128套五维过程噪声、16套物理参数初筛数量、观测噪声方差0.000015、初始协方差、无迹变换设置和48／120小时等权选择指标全部固定。共同日期状态的有限性只作冻结身份后的评价资格检查，不能反向改变16套初筛或把第二名提升为第一名。
- 三个结束时刻内的3、6、12、24个月资料段严格共用结束时刻，且短资料段是长资料段的尾部子集。
- 选择只能访问资料结束时刻以前的流量。紧接资料期的一年和2005—2010年的流量仅用于之后的逐时状态更新与评分，不能反向改变候选、排序、噪声或门槛。
- 同一结束时刻的四条评价流程都从该结束时刻前3个月的共同日期开始，使用各自所选物理参数对应的气象暖机状态，再吸收完全相同的3个月历史流量形成评价初始状态；随后逐小时连续运行至2010-12-31 23时，跨年不重置状态。四个模型的状态数值可以不同，但准备规则、起止日期和所用流量完全相同。
- 每次120小时预报只使用起报后的实测降雨和潜在蒸散发，不使用未来流量；增加或删除预报起报点不得改变连续状态链，预报函数也不得回写状态。
- 本试验同时改变了用于选择物理参数和过程噪声的资料量，因此结论对象是“参数与过程噪声的联合选择流程”；不能把差异单独归因于物理参数。
- 2002—2010年的资料在既往研究中已经查看；本试验属于同流域回溯分析，不称为真正未见资料的独立验证。
- 所有原始率定、旧选择、旧六年结果、零概率诊断和失败尝试保持原样。新输出使用排他目录；任何阶段失败后保留收据并换新尝试编号。
- 使用已完成零概率修复并封存的数值核心。单模型本身不会触发跨成员状态混合，但统一绑定该版本可避免不同试验使用不同源码。
- 同一源码和同一输入的工程重放使用绝对容差1e-8、相对容差0。新匹配状态流程中的3个月结果应与既有同起点流程逐元素一致；24个月结果因状态准备历史被有意改为3个月，不要求等于旧24个月结果。
- 生产预报与独立重建即使相差不超过1e-8，也必须把该差异传入门槛边界；边界重叠时记为“数值边界无法确定”，不能按名义比值直接通过。

---

## 1. 研究问题、固定比较和判断标准

### 1.1 嵌套资料段

所有区间含起点、不含终点。选择起报点是资料段内的每日0时，且完整120小时目标仍位于资料段内。

| 结束时刻 | 资料长度 | 资料起点 | 小时数 | 选择起报数 | 稳定试验编号 |
|---|---:|---|---:|---:|---|
| 2002-01-01 00时 | 3个月 | 2001-10-01 00时 | 2,208 | 87 | RL-E1-M03 |
| 同上 | 6个月 | 2001-07-01 00时 | 4,416 | 179 | RL-E1-M06 |
| 同上 | 12个月 | 2001-01-01 00时 | 8,760 | 360 | RL-E1-M12 |
| 同上 | 24个月 | 2000-01-01 00时 | 17,544 | 726 | RL-E1-M24 |
| 2002-07-01 00时 | 3个月 | 2002-04-01 00时 | 2,184 | 86 | RL-E2-M03 |
| 同上 | 6个月 | 2002-01-01 00时 | 4,344 | 176 | RL-E2-M06 |
| 同上 | 12个月 | 2001-07-01 00时 | 8,760 | 360 | RL-E2-M12 |
| 同上 | 24个月 | 2000-07-01 00时 | 17,520 | 725 | RL-E2-M24 |
| 2004-01-01 00时 | 3个月 | 2003-10-01 00时 | 2,208 | 87 | RL-E3-M03 |
| 同上 | 6个月 | 2003-07-01 00时 | 4,416 | 179 | RL-E3-M06 |
| 同上 | 12个月 | 2003-01-01 00时 | 8,760 | 360 | RL-E3-M12 |
| 同上 | 24个月 | 2002-01-01 00时 | 17,520 | 725 | RL-E3-M24 |

### 1.2 固定选择规则

每个资料段执行同一有限预算流程：

1. 用相同随机种子915031生成相同2,048套物理参数。
2. 从1999-01-01 01时至各资料起点只用气象驱动暖机；在资料段内先计算2,048套物理参数的水文模拟均方根误差，按误差、物理参数编号排序，保留16套。
3. 对16套物理参数分别使用相同随机种子909001生成的128套五维过程噪声，共2,048个参数—噪声组合；每个组合在资料段内逐时吸收流量并生成1、24、48、120小时预报。
4. 只用48和120小时误差排序：

   `score = 0.5 × (RMSE48 / persistence_RMSE48 + RMSE120 / persistence_RMSE120)`。

5. 每套物理参数只保留分数最低的过程噪声，再按分数、物理参数编号、过程噪声编号排序；第一名是该资料长度唯一拟进入后续评价的模型。

12个第一名全部冻结后，才逐一检查其物理参数在对应共同日期的五个暖机状态是否完整有限。任何第一名不合格都记为技术失败并停止正式评价；不重新选择第二名、不缩小候选、不改变资料长度。

评价期表现、评价后五个模型中的最好者以及2005—2010年结果均不参与选择。

### 1.3 匹配状态准备与两层评价

同一结束时刻的四种资料长度共用以下评价准备合同：

1. 共同状态准备起点固定为资料结束时刻前3个月，即对应`RL-E*-M03`的资料起点；
2. 从已审计3个月率定原始数组中，按每个模型自己选中的完整物理参数编号提取该共同日期的气象暖机状态；该数组包含全部2,048套物理参数，不要求该参数进入3个月试验的16套初筛名单，但冻结后的所选参数必须通过§1.2末尾的评价资格检查；
3. 另行用同一冻结水文模型和气象驱动从1999-01-01 01时重放到共同日期，核对所取状态完整、有限且最大绝对差不超过1e-8；这属于来源复核，不称为另一套模型实现的独立重建；缺失、非有限或身份不符即停止，不借用其他物理参数的状态；
4. 在共同日期为四个模型设置同一个固定初始协方差，模型概率固定为1，再分别使用各自选中的物理参数与过程噪声吸收完全相同的3个月逐小时观测流量；
5. 到资料结束时刻后不重置，继续逐小时吸收流量并连续运行至2010-12-31 23时。

因此，同一结束时刻内四种长度的状态准备日期、流量历史、初始协方差和计算规则相同；参数与过程噪声不同所导致的状态差异属于选择结果本身。原先“从各自资料起点开始吸收流量”的完整流程不进入本试验的科学比较，留作另一项实际流程敏感性试验。

每个试验编号保存两类起报：

- **近期评价：** 从资料结束时刻开始的一整年；三个结束时刻分别评价2002年、2002-07-01至2003-07-01、2004年，共360、360、361个每日起报。每个结束时刻内四种长度具有完全相同的起报和目标。
- **共同多年评价：** 2005-01-01至2011-01-01内目标不跨年的2,161个每日起报，分别形成2005—2010年六个年度结果及一个六年合并结果。

近期评价回答“用不同长度资料选出的固定模型，经过相同3个月状态准备后，紧接选择期的预报是否达到24个月参考”；共同多年逐年评价回答“同一结论在较远的六个年份是否每年都保持”。六年合并结果只描述平均表现，不决定任何“稳定”称号。

### 1.4 唯一门槛、数值边界和两个预先命名的结论

主比较以匹配状态准备后的24个月模型为每个结束时刻、评价期间和提前时间的参考。对资料长度`L∈{3,6,12}`、结束时刻`e`、评价期间`p`、提前时间`h∈{48,120}`，保存生产预报均方根误差`E`、生产预报与独立重建预报的均方根差`d`，并定义：

- 误差下界：`E_low = max(0, E - d)`；
- 误差上界：`E_high = E + d`。

这些上下界只是数值重建误差范围，不是统计置信区间。非有限误差、非有限边界或不为正的24个月参考误差不计算比值，技术状态记为无效。

某一资料长度在一个`(e,p,h)`单元明确通过，必须同时满足：

1. 该长度上界不超过`1.05 × 24个月参考下界`；
2. 该长度上界不超过`0.95 × 保持起报流量不变的误差下界`；
3. 24个月参考上界不超过`0.95 × 保持起报流量不变的误差下界`；
4. 选择、连续状态链和预报全部技术有效。

任一条件被相反的严格边界证实时记为失败；没有明确通过、也没有明确失败时记为“数值边界无法确定”。例如，资料长度相对24个月参考的条件只有在`method_high <= 1.05 × reference_low`时通过；只有在`method_low > 1.05 × reference_high`时失败；中间区域无法确定。保持起报流量不变的比较采用相同规则。严格最短长度只接纳明确通过，不把无法确定当作通过。

预先冻结两个不同结论，读取新结果后不得互换：

- **近期达标的最短已测长度（唯一主结论）：** 在三个近期评价期间的48和120小时共6个单元全部明确通过的`3、6、12个月`中的最短者。
- **多年逐年稳定的最短已测长度（次要稳健性结论）：** 在三个结束时刻、2005—2010年六个年度、48和120小时共36个单元全部明确通过的`3、6、12个月`中的最短者。

若没有短长度满足，对应结论写为“3、6、12个月中没有满足预设标准的长度”。“最短”只限已测的3、6、12个月，不能推断4、5或其他月份，也不假定性能随长度单调变化。24个月参考自身未达到保持起报流量不变的5%改善时，单列为“参考质量门槛失败”，不能解释成所有短长度本身无效。

六年合并指标、每种长度近期通过的结束时刻数`0/3`至`3/3`、每日误差和纳什效率系数都只作描述性结果。三个结束时刻并非三个独立流域，前两个近期评价重叠六个月；不对它们做普通显著性检验。

## 2. 正式来源与新输出

必须在准备阶段逐文件核对并写入`source_binding.json`：

- 原始逐小时资料：`forecast/data/PEQ_Regge_hour.txt`，SHA-256为`64e9b1b3d47655e2008dd4dbb380d7a198811dd79b0094f1632467c0e6f605fa`。
- 已审计3／24个月率定：`G:/wt/id23-readout/results/regge_short_record_calibration_v03_recovery/20260920-regge-short-record-recovery-v03-001`；清单SHA-256为`bda9b970413173c8610e70f36619d0c3508822849b66cb5cc9f476c5f782c44a`，审核SHA-256为`9765b8e201f15b5ba620442d778e829534f07b6f53298defc0013adcd5b63c02`。
- 48／120小时重排实现及3个月选择：`G:/wt/id23-readout/results/regge_short_record_long_lead_selection/20260927-regge-short-record-selection-development-001`；清单SHA-256为`462a9d598c2bf1e2b99357a9d940e6122cf104bce357d51461610931c77eaf53`，选择文件SHA-256为`6e0200a7f8cff6eedc14179ecd7a347a99e5b4c807419bc458abecfc1a58d2ac`。
- 已修复并完成六年审核的3／24个月单模型来源：`output/regge_zero_prob/20260929-002`；清单SHA-256为`ababef8cdb2e1d288b43bd15c64ba82c58879e09c551a51a21e23de1f00d8678`，审核SHA-256为`93d4e4d6d87bebfafd9440952aee7b3736a2a862a572355afbae534a9c809d95`。

准备计划时只读核对三个3个月`raw.npz`：`warmup_states`形状均为`(2048, 5)`，`warmup_completed`均有2,048个真值，但五个状态全部有限的行数依次为E1的1,699、E2的1,699、E3的1,695。六个已知3／24个月第一名物理参数在各自共同日期均有限。准备阶段必须重新核对并保存三个资格掩码及摘要；不能把“数组有2,048行”误写成“2,048个状态都有限”。

新代码根目录：`python/regge_record_length_study/`。

| 文件 | 单一职责 |
|---|---|
| `contract.py` | 固定12个资料段、3个共同状态准备段、8类评价期间、起报清单、试验编号、门槛与路径长度检查 |
| `calibration.py` | 验证新窗口绑定后只执行6个新增6／12个月率定，保存原始数组、结果、日志和失败收据 |
| `selection.py` | 从6个复用率定和6个新增率定中独立重建48／120小时排序并冻结12个第一名 |
| `assessment.py` | 对12个第一名单模型使用匹配的3个月状态准备历史，各运行一条连续状态链并读取两层评价起报 |
| `audit.py` | 独立重建选择与确定性预报，计算数值误差边界、期间明确的门槛和工程一致性 |
| `report.py` | 生成资料长度曲线、年度图、组合身份表和结论边界 |
| `common.py` | 排他写入、SHA-256、数组保存、事件日志及修复核心路径激活 |
| `prepare.py` | 核对来源、版本、资源与输出路径，冻结配置及源码快照 |
| `run.py` | `calibrate`、`select`、`assess`、`audit`、`report`阶段调度 |
| `__init__.py` | 空包入口 |

入口：`python/run_regge_record_length_study.py`。

测试：`python/tests/test_regge_record_length_study.py`。

排他结果根目录：`output/regge_length/20260929-001`。只有`prepare`阶段可以排他创建结果根目录；目录已存在时`prepare`立即停止。后续阶段必须进入这个已准备目录，核对上一阶段成功收据及清单摘要，并在本阶段启动、成功或失败收据均不存在时才开始。本阶段存在启动残留、成功或失败收据时都拒绝覆盖；失败后使用新的尝试编号，不在原目录自动续跑。准备阶段计算最长预期路径，必须小于240字符。

注册表使用`RL-E1-M03`至`RL-E3-M24`作为稳定选择编号，并使用`<exp_id>-MATCHED3`作为评价编号；`MATCHED3`明确表示“匹配的3个月状态准备历史”。每行至少记录：选择编号、评价编号、假设、资料起止、共同状态准备起止、改变因素、固定因素、种子、率定来源、新增或复用、阶段运行状态、结果目录、指标文件和论文拟用名称。

## 3. 计算预算与停止条件

新增率定只有6个：三个结束时刻的6个月和12个月。3个月及24个月率定数组只读复用。

| 新增率定 | 暖机小时 | 资料小时 | 选择起报 | 水文暖机、资料推进及滤波合计步数 |
|---|---:|---:|---:|---:|
| RL-E1-M06 | 21,887 | 4,416 | 179 | 62,912,512 |
| RL-E1-M12 | 17,543 | 8,760 | 360 | 71,809,024 |
| RL-E2-M06 | 26,303 | 4,344 | 176 | 71,661,568 |
| RL-E2-M12 | 21,887 | 8,760 | 360 | 80,705,536 |
| RL-E3-M06 | 39,407 | 4,416 | 179 | 98,793,472 |
| RL-E3-M12 | 35,063 | 8,760 | 360 | 107,689,984 |

六次新增率定合计：

- 物理参数暖机与水文资料推进412,766,208步；
- 单模型滤波80,805,888个成员小时；
- 选择起报3,305,472个，每个最多推进120小时，共396,656,640个确定性预报步；
- 原始率定数组预计约0.95 GB，按现有3／24个月文件大小线性估计，不作为精确存储承诺。

12条正式单模型连续链采用匹配的3个月状态准备历史：

| 结束时刻 | 共同状态准备起点 | 每条链滤波小时 | 四种长度合计 |
|---|---|---:|---:|
| 2002-01-01 00时 | 2001-10-01 00时 | 81,096 | 324,384 |
| 2002-07-01 00时 | 2002-04-01 00时 | 76,728 | 306,912 |
| 2004-01-01 00时 | 2003-10-01 00时 | 63,576 | 254,304 |
| 合计 | — | — | 885,600 |

近期评价加共同多年评价共30,256个起报，生产确定性预报3,630,720步，独立重建另3,630,720步。每个方法输出近期、2005—2010年六个年度和六年合并共8个期间，完整1—120小时指标表应有`12 × 8 × 120 = 11,520`行。

历史同机记录中，一个3个月窗口用8,022秒，一个24个月窗口用7,667秒。由此推得的13—14小时仅指六个新增率定的调度估计，不包含12条评价链、独立重建、审核和制图，也不保证候选存活比例相同时耗一致。0.95 GB仅指新增率定原始数组；准备阶段还要按实际数组形状估算快照、预测块、重建数组和临时副本。资源门槛取“可用内存至少4 GiB且不少于预计峰值的2倍”“结果盘空闲至少20 GiB且不少于预计总产物的2倍”两者中更严格者，并要求最长输出路径少于240字符、Python／NumPy／PyTorch版本完全匹配、源文件和输入摘要全部通过。

每个率定窗口是单独进程和单独目录；保存标准输出、错误输出、退出码、开始／结束时间及核心事件。未知异常或共享输入错误停止整个批次；单候选已识别的数值失败保留并由原有效性规则排除。率定窗口失败后不自动重试，不缩小候选、不改变资料长度、不复写目录。

正式连续链每720个模拟小时或30分钟实际时间先到即保存完整状态；每30个评价起报保存预测块；开始、结束、可捕获失败及异常均保存收据。成功收据要求12条全部技术有效；若任一链失败，仍输出失败清单和失败报告，明确已完成、失败与未运行项目，然后停止。科学门槛不满足不触发技术重跑。快照仅作证据，不在同一尝试自动续跑。

### 3.1 高性能计算集群执行边界

历史同机耗时表明六个新增率定串行需约13—14小时，超过本任务预设的6小时本地运行门槛，因此只把这六个率定送至高性能计算集群。完整来源准备、12个身份选择、12条连续评价链、独立审核、制图和人工看图封存仍在本地正式目录执行。

- 集群使用`hgpu2p`分区的中央处理器，不申请图形处理器；作业申请4个中央处理器作为调度资源，但每个科学进程强制单线程、双精度且关闭梯度，六个窗口按冻结顺序串行运行。
- 集群胶囊包含六个新增率定所需的原始资料、既有输入前缀、冻结数值核心、候选数组、正式准备证据、源码、测试、计划和传输公钥；不上传约1.5 GB的旧3／24个月率定原始数组，也不在集群执行选择阶段。胶囊清单、压缩包、完整授权文件和集群签名公钥的摘要在部署前排他保存为本地信任记录。
- 每个窗口仍是独立子进程和独立目录，失败后立即停止余下窗口并保存失败收据，不自动重试。启动前、运行时和返回打包任一阶段失败都必须保存`passed=false`且`automatic_retry=false`的结构化收据。集群批次成功只表示六个远程率定完成，不等于已进入正式试验。
- 每个远程窗口结束后即打开原始数组，核对精确键、形状、类型、逐数组摘要、冻结气象和流量、参数与噪声设计，并独立重算误差及排序；返回本地后、正式导入成功收据写入前，对六个窗口再次完成同一复核，不提前发布选择结果。
- 远程返回包使用高级加密标准256位伽罗瓦计数模式的认证加密，并由只保留在集群的私钥签署根清单；本地必须先用部署前固定的集群公钥验签，再解密、核对明文摘要及解包后批次身份，并在正式目录固定位置排他写入传输验证成功收据。导入入口只接受该固定部署记录和传输验证收据，不接受调用方另传任意绑定文件。部署记录、传输清单、签名、公钥、远程授权、批次启动记录、事件、清单和收据一并保存在正式证据目录。正式导入成功收据是最后一个原子写入；任何失败都不得留下成功收据。
- 远程根目录固定使用新的`/data1/home/sunyiq/regge_record_length_20260929_001/formal_calibration_001`；环境探测、失败尝试和正式率定分别使用不同目录，禁止覆盖或复用现有实验目录。
- 数值核心仍严格使用Python 3.11.5、NumPy 1.26.4和PyTorch 2.2.2。辅助环境固定为Pandas 2.3.2、psutil 5.9.0、threadpoolctl 3.6.0和pytest 9.1.1，并绑定运行时清单摘要；正式入口必须验证有效的Slurm作业编号、指定作业名、4个调度处理器、无图形处理器以及全部数值线程为1。输入数组摘要再次确认读取结果未变。

## Task 1: 建立资料段合同、来源绑定和准备门槛

**Files:**
- Create: `python/regge_record_length_study/contract.py`
- Create: `python/regge_record_length_study/common.py`
- Create: `python/regge_record_length_study/prepare.py`
- Create: `python/regge_record_length_study/__init__.py`
- Test: `python/tests/test_regge_record_length_study.py`

**Interfaces:**
- Produces: `window_specs() -> tuple[dict, ...]`、`state_preparation_specs() -> tuple[dict, ...]`、`evaluation_period_specs() -> tuple[dict, ...]`、`common_warmup_state_masks() -> dict[str, np.ndarray]`、`fixed_initial_covariance() -> np.ndarray`、`FIXED_INITIAL_COVARIANCE_SHA256: str`、`load_inputs() -> tuple[np.ndarray, np.ndarray, np.ndarray, dict]`、`prepare() -> Path`、`verify_prepared() -> dict`。
- Consumes later: all later phases read only `config.json`、`source_binding.json`、`origin_manifest.npz` and `preparation_receipt.json` created here.

- [ ] **Step 1: Write exact window and nesting tests**

```python
def test_window_lengths_origins_and_nesting():
    specs = window_specs()
    assert [(s["endpoint"], s["months"], s["hours"], s["selection_origins"]) for s in specs] == [
        ("E1", 3, 2208, 87), ("E1", 6, 4416, 179),
        ("E1", 12, 8760, 360), ("E1", 24, 17544, 726),
        ("E2", 3, 2184, 86), ("E2", 6, 4344, 176),
        ("E2", 12, 8760, 360), ("E2", 24, 17520, 725),
        ("E3", 3, 2208, 87), ("E3", 6, 4416, 179),
        ("E3", 12, 8760, 360), ("E3", 24, 17520, 725),
    ]
    for endpoint in ("E1", "E2", "E3"):
        rows = [s for s in specs if s["endpoint"] == endpoint]
        assert len({s["stop"] for s in rows}) == 1
        for short, long in zip(rows, rows[1:]):
            assert long["start"] < short["start"] < short["stop"] == long["stop"]

def test_common_state_preparation_and_evaluation_counts():
    assert [(s["endpoint"], s["start"], s["stop"], s["hours"]) for s in state_preparation_specs()] == [
        ("E1", "2001-10-01T00", "2002-01-01T00", 2208),
        ("E2", "2002-04-01T00", "2002-07-01T00", 2184),
        ("E3", "2003-10-01T00", "2004-01-01T00", 2208),
    ]
    assert [p["origin_count"] for p in evaluation_period_specs()] == [360, 360, 361, 360, 360, 360, 361, 360, 360, 2161]

def test_common_warmup_state_masks_match_bound_sources():
    masks = common_warmup_state_masks()
    assert [int(masks[e].sum()) for e in ("E1", "E2", "E3")] == [1699, 1699, 1695]
    assert all(masks[e][pid] for e, pid in (
        ("E1", 67), ("E1", 1944), ("E2", 1072),
        ("E2", 1944), ("E3", 1926), ("E3", 712),
    ))
```

- [ ] **Step 2: Run the new contract test and confirm it fails before implementation**

Run: `python -m pytest -q python/tests/test_regge_record_length_study.py::test_window_lengths_origins_and_nesting`

Expected: FAIL because `regge_record_length_study.contract` does not exist.

- [ ] **Step 3: Implement explicit immutable window records and input validation**

Use literal start and stop timestamps from §1.1; do not calculate calendar months by subtracting a fixed number of days. Generate exact daily origins from the continuous hourly axis, bind the raw input SHA-256, and assert the two evaluation-origin sets contain 360／360／361 and 2,161 origins respectively.

- [ ] **Step 4: Implement source, version, resource and path gates**

`prepare()` must refuse an existing output root, verify all hashes in §2, verify the repaired run audit passed, confirm the six historical3／24个月率定文件及三个3个月全参数暖机数组存在于清单，核对每个暖机数组形状为`(2048, 5)`并逐行生成有限状态资格掩码，要求资格数精确重现1,699／1,699／1,695及六个已知第一名均合格，冻结掩码作为后续评价资格检查而不送入率定排序，同时冻结所有新源码摘要，并在任何新增率定前写入12条选择记录和12条`MATCHED3`评价记录。

- [ ] **Step 5: Run contract tests**

Run: `python -m pytest -q python/tests/test_regge_record_length_study.py -k "window or source or prepare"`

Expected: PASS with no output root created by unit tests.

- [ ] **Step 6: Commit this task only**

```bash
git add python/regge_record_length_study/__init__.py python/regge_record_length_study/common.py python/regge_record_length_study/contract.py python/regge_record_length_study/prepare.py python/tests/test_regge_record_length_study.py
git commit -m "feat: define Regge record-length study contract"
```

## Task 2: 新增6／12个月率定并保留完整失败证据

**Files:**
- Create: `python/regge_record_length_study/calibration.py`
- Create: `python/regge_record_length_study/run.py`
- Create: `python/run_regge_record_length_study.py`
- Test: `python/tests/test_regge_record_length_study.py`

**Interfaces:**
- Consumes: `window_specs()` and frozen base scientific configuration.
- Produces: immutable`BoundCalibrationInputs`with fields`warmup_timestamps, warmup_forcing, calibration_timestamps, calibration_forcing, calibration_observations, meta`; `missing_calibration_specs() -> tuple[dict, ...]`; `bind_calibration_inputs(full_inputs: tuple, exp_id: str) -> BoundCalibrationInputs`; `calibrate_one(spec: dict, destination: Path) -> Path`; and six`calibration/<exp_id>/{raw.npz,result.json,events.jsonl,receipt.json}`directories.

- [ ] **Step 1: Write tests that constrain the new adapter**

```python
def test_only_six_and_twelve_month_windows_are_computed():
    assert [s["exp_id"] for s in missing_calibration_specs()] == [
        "RL-E1-M06", "RL-E1-M12", "RL-E2-M06",
        "RL-E2-M12", "RL-E3-M06", "RL-E3-M12",
    ]

def test_post_cutoff_flow_is_absent_from_calibration_inputs(full_inputs):
    bound = bind_calibration_inputs(full_inputs, "RL-E1-M06")
    assert bound.calibration_timestamps[-1] == np.datetime64("2001-12-31T23", "h")
    assert bound.calibration_observations.shape == (4416,)

def test_adapter_binds_exact_new_window_and_runtime(full_inputs):
    bound = bind_calibration_inputs(full_inputs, "RL-E2-M12")
    assert bound.meta["warmup_start"] == "1999-01-01T01"
    assert bound.meta["calibration_start"] == "2001-07-01T00"
    assert bound.meta["calibration_stop"] == "2002-07-01T00"
    assert bound.meta["parameter_count"] == 2048
    assert bound.meta["noise_count"] == 128
    assert bound.meta["dtype"] == "float64"
```

- [ ] **Step 2: Run the adapter tests and confirm they fail**

Run: `python -m pytest -q python/tests/test_regge_record_length_study.py -k "six_and_twelve or post_cutoff"`

Expected: FAIL because `calibration.py` is absent.

- [ ] **Step 3: Implement a complete validation wrapper around the frozen numerical engine**

The wrapper first validates the unchanged base scientific configuration, then explicitly binds the stable experiment ID to the literal new start and stop timestamps. It requires warmup from`1999-01-01T01`to the hour immediately before the calibration slice, and requires the calibration timestamps to be hourly, continuous and exactly stop-exclusive. It verifies the raw-data hash, fixed initial state, fixed initial covariance, observation-noise variance, unscented-transform parameters, lead set, 2,048-parameter design and hash, 128-noise design and hash, 16-parameter shortlist budget, random seeds and source paths. It also asserts Python／NumPy／PyTorch versions, double precision, central processor, one thread and no-gradient execution.

Only after those checks may it call the sealed `_execute(..., leads=(1,24,48,120), synthetic=False)` with the custom window slice. It does not edit`walrus_history_conditioned_imm`or relax its numerical checks. A normal result and a carried`short_record_partial_result`must both contain the new experiment ID, exact timestamps, source hashes, environment and reached-array counts; the latter must also save the original exception and exit nonzero.

- [ ] **Step 4: Add one-window process supervision and exclusive receipts**

The top-level `calibrate` stage launches windows sequentially in the frozen order. Each child process imports the repaired runtime before any same-named module, asserts the loaded paths, records exact versions and one-thread settings, and never starts the next window after a shared error.

- [ ] **Step 5: Run bounded synthetic and real-slice adapter tests**

Run: `python -m pytest -q python/tests/test_regge_record_length_study.py::test_custom_window_adapter_matches_sealed_synthetic_core`

Expected: PASS; arrays and failures equal the sealed small synthetic entry exactly.

Run: `python -m pytest -q python/tests/test_regge_record_length_study.py -k "adapter_binds or actual_slice_future_flow or partial_metadata"`

Expected: PASS. The real-slice test loads the actual Regge input through the production loader, constructs`RL-E1-M06`, changes every flow value at and after`2002-01-01T00`, and requires the exact arrays and hashes passed to`_execute`to remain byte-identical. Negative cases for a one-hour start shift, a warmup gap, changed seed, changed source path, non-double dtype and missing partial-result identity must all be rejected before scientific computation.

- [ ] **Step 6: Commit this task only**

```bash
git add python/regge_record_length_study/calibration.py python/regge_record_length_study/run.py python/run_regge_record_length_study.py python/tests/test_regge_record_length_study.py
git commit -m "feat: add bounded record-length calibration stage"
```

## Task 3: 独立重建12个选择并在评价前冻结身份

**Files:**
- Create: `python/regge_record_length_study/selection.py`
- Modify: `python/regge_record_length_study/run.py`
- Test: `python/tests/test_regge_record_length_study.py`

**Interfaces:**
- Produces: `reconstruct_existing_selections() -> dict[str, dict]`, `select_all() -> Path` and `selections.json` containing exactly 12 records.
- Each record contains: experiment ID, parameter ID and full values, noise ID and diagonal, score, endpoint-specific common-initialization mask hash and selected-identity eligibility, top-16 physical shortlist, complete rank-order hash, warmup state and source hashes.

- [ ] **Step 1: Write known 3／24-month identity tests**

```python
def test_existing_three_and_twenty_four_month_rank_one_identities():
    selected = reconstruct_existing_selections()
    assert [(selected[k]["parameter_id"], selected[k]["noise_id"]) for k in (
        "RL-E1-M03", "RL-E1-M24", "RL-E2-M03",
        "RL-E2-M24", "RL-E3-M03", "RL-E3-M24",
    )] == [(67, 84), (1944, 19), (1072, 97), (1944, 70), (1926, 84), (712, 7)]
```

- [ ] **Step 2: Run the identity test and confirm it fails**

Run: `python -m pytest -q python/tests/test_regge_record_length_study.py::test_existing_three_and_twenty_four_month_rank_one_identities`

Expected: FAIL because selection reconstruction is absent.

- [ ] **Step 3: Implement full raw-array validation and 48／120-hour ranking**

Recalculate persistence errors, candidate errors, old four-lead scores and archived rank order before applying the two-lead formula. Require all saved array hashes, shapes and dtypes to match. Use only calibration arrays listed by an allow-list; reject assessment arrays or any key not produced by calibration. The common-state finite mask must not enter either shortlist or score calculation.

- [ ] **Step 4: Freeze all 12 identities before assessment**

Write `selections.json`, `selection_manifest.json` and `selection_receipt.json` with exclusive creation. The assessment stage requires their hashes and refuses any edit. A missing or failed new calibration stops selection; it cannot fall back to the nearest length. After all12 identities are frozen, annotate whether each selected parameter passes the already frozen common-initialization mask. Any failure, or any later provenance replay disagreement, produces a technical failure receipt and stops assessment without promoting the next-ranked model.

- [ ] **Step 5: Test flow isolation**

Create an in-memory copy with all flow values after each selection cutoff changed. Reconstruct selection from the unchanged allowed calibration arrays and assert byte-identical identities and scores. This checks data access boundaries; it does not run new forecasts.

- [ ] **Step 6: Commit this task only**

```bash
git add python/regge_record_length_study/selection.py python/regge_record_length_study/run.py python/tests/test_regge_record_length_study.py
git commit -m "feat: freeze matched record-length selections"
```

## Task 4: 用匹配的3个月状态准备历史连续运行12个单模型资料同化流程

**Files:**
- Create: `python/regge_record_length_study/assessment.py`
- Modify: `python/regge_record_length_study/run.py`
- Test: `python/tests/test_regge_record_length_study.py`

**Interfaces:**
- Produces: immutable`AssessmentResult`with`meta: dict`and`arrays: dict[str, np.ndarray]`; `load_common_warmup_state(endpoint: str, parameter_id: int) -> np.ndarray`; `assess_one(spec: dict, selection: dict, origins: np.ndarray, destination: Path) -> AssessmentResult`.
- Saves: one`MATCHED3`state chain per experiment; arrays include common preparation timestamps, origins, targets, truth, forcing, persistence, every propagation state, posterior covariance, selected identity and 120-hour predictions.

- [ ] **Step 1: Write chronology and no-reset tests with the real core**

```python
def test_four_lengths_share_state_preparation_history(real_short_fixture):
    results = [assess_one_fixture(real_short_fixture, months=m) for m in (3, 6, 12, 24)]
    assert {r.meta["assimilation_start"] for r in results} == {"2001-10-01T00"}
    assert {r.meta["evaluation_start"] for r in results} == {"2002-01-01T00"}
    assert {r.meta["pre_evaluation_assimilation_hours"] for r in results} == {2208}
    assert {r.meta["initial_covariance_hash"] for r in results} == {FIXED_INITIAL_COVARIANCE_SHA256}
    for result in results:
        assert result.meta["state_reset_count"] == 0
        assert result.meta["last_valid_hour"] == result.meta["stop"] - 1

def test_one_chain_contains_both_assessments_without_reset(real_short_fixture):
    result = assess_one_fixture(real_short_fixture, months=3)
    assert result.meta["state_reset_count"] == 0
    assert result.meta["processed_hour_count"] == result.meta["stop"] - result.meta["start"]
    assert result.meta["last_valid_hour"] == result.meta["stop"] - 1
    assert set(np.unique(result.arrays["period"])) == {"immediate", "2005", "2006", "2007", "2008", "2009", "2010"}
```

- [ ] **Step 2: Run the matched-history and chronology tests and confirm they fail**

Run: `python -m pytest -q python/tests/test_regge_record_length_study.py -k "share_state_preparation or one_chain_contains"`

Expected: FAIL because `assessment.py` is absent.

- [ ] **Step 3: Implement common warmup-state retrieval and a one-member continuous runner**

For each endpoint, read only its existing3-month calibration raw array. Retrieve the state by the selected full physical-parameter ID, verify the saved parameter values exactly match`selections.json`, and separately replay weather-only forcing with the same frozen hydrologic model from`1999-01-01T01`to the common start. Require complete finite state and maximum absolute difference at most1e-8. Label this as a provenance replay, not an independent model implementation. Initialize the fixed original covariance and model probability1 at the common date; do not import a covariance or posterior state from any 6／12／24-month run.

Assimilate every hourly flow from that common date through`2010-12-31T23`. Read out the union of immediate and common-year origins; deterministic forecasts start from the single posterior state and advance one state for120 hours with fixed selected parameters. The runner takes an immutable state copy for every forecast and never propagates covariance or sigma points in the deterministic forecast.

- [ ] **Step 4: Add durable progress and failure receipts**

Use the checkpoint and chunk rules in §3. Save every complete state used by propagation, the posterior covariance, last valid hour, next hour, completed origins, source hashes and experiment ID. Any forecast or filter failure makes that experiment invalid and stops the batch after preserving evidence.

- [ ] **Step 5: Run fixed real-prefix chronology and non-interference tests**

Use actual input, endpoint`E1`, physical parameter67, process-noise design84, fixed initial covariance, common start`2001-10-01T00`, a240-hour state-chain prefix and origins at hours120 and144. This test budget is exactly240 filter hours plus two120-hour deterministic forecasts; it creates only a temporary test directory and never writes to the formal result root.

Require: changing flow after an origin does not change that origin's120-hour forecast; adding the second origin does not change any later posterior state; a forecast call leaves the input state byte-identical; rerunning the same prefix reproduces every state and covariance within absolute tolerance1e-8 and relative tolerance0. Negative cases with a one-hour common-start shift or another parameter's warmup state must be rejected.

- [ ] **Step 6: Keep historical reproduction separate from the new scientific arm**

For the three3-month identities, subset the new`MATCHED3`arrays to the2,161 common origins and compare source-aligned indices, states, covariances and predictions with the repaired six-year result; their preparation history is unchanged and must agree within absolute tolerance1e-8 and relative tolerance0. Do not require the three24-month`MATCHED3`results to equal old24-month arrays, because the old chains absorbed21additional months of historical flow. Record that difference as intentional, not as an audit failure.

- [ ] **Step 7: Commit this task only**

```bash
git add python/regge_record_length_study/assessment.py python/regge_record_length_study/run.py python/tests/test_regge_record_length_study.py
git commit -m "feat: run continuous single-model record-length assessments"
```

## Task 5: 独立审核选择、预报与资料长度效应

**Files:**
- Create: `python/regge_record_length_study/audit.py`
- Modify: `python/regge_record_length_study/run.py`
- Test: `python/tests/test_regge_record_length_study.py`

**Interfaces:**
- Produces: `audit.json`、`metrics_1_to_120_hours.csv`、`comparisons.json`、`selected_identities.csv` and `audit_reconstruction/<assessment_id>.npz`.
- Produces pure function`gate(method: tuple[float, float], reference: tuple[float, float], persistence: tuple[float, float]) -> dict`, where every tuple is`(root_mean_square_error, reconstruction_difference)`.
- `metrics_1_to_120_hours.csv` has one row per method—period—lead and uses explicit fields`assessment_id, endpoint, months, period_kind, period_id, lead_hour, root_mean_square_error, nash_efficiency, mean_absolute_error, reconstruction_difference, root_mean_square_error_lower_bound, root_mean_square_error_upper_bound`.

- [ ] **Step 1: Write metric and gate tests with hand-calculated arrays**

```python
def test_reference_level_gate_uses_numerical_bounds():
    passed = gate(method=(1.00, 0.001), reference=(1.00, 0.001), persistence=(1.20, 0.0))
    assert passed["status"] == "pass"
    uncertain = gate(method=(1.05, 0.001), reference=(1.00, 0.001), persistence=(1.20, 0.0))
    assert uncertain["status"] == "numerical_boundary_uncertain"
    failed = gate(method=(1.06, 0.001), reference=(1.00, 0.001), persistence=(1.20, 0.0))
    assert failed["status"] == "fail"

def test_invalid_or_zero_reference_never_passes():
    assert gate(method=(1.0, 0.0), reference=(0.0, 0.0), persistence=(1.2, 0.0))["status"] == "invalid"
    assert gate(method=(1.0, 0.0), reference=(np.nan, 0.0), persistence=(1.2, 0.0))["status"] == "invalid"
```

- [ ] **Step 2: Run metric tests and confirm they fail**

Run: `python -m pytest -q python/tests/test_regge_record_length_study.py -k "metric or reference_level_gate"`

Expected: FAIL because audit functions are absent.

- [ ] **Step 3: Rebuild every selection without importing production selection helpers**

Read only the frozen calibration arrays, independently derive the16-parameter shortlist, 2,048 joint candidate errors,48／120 scores, per-parameter best noise and global first place. Compare full identity and score with `selections.json`.

- [ ] **Step 4: Rebuild every deterministic forecast with the scalar NumPy WALRUS implementation**

For all30,256 origins, start from the saved posterior state and selected parameters, advance120 observed-forcing hours, and require maximum absolute discharge difference at most1e-8. Do not propagate covariance or sigma points in this deterministic reconstruction. Save the root mean square difference`d`for every method, period and lead; do not silently replace a nonzero`d`with zero.

- [ ] **Step 5: Recompute all metrics, numerical bounds and the two frozen conclusions**

Produce root mean square error, Nash efficiency coefficient and mean absolute error for leads1—120, separately for each immediate period, each year2005—2010 and six-year pooled. Require exactly11,520 method—period—lead rows. Store absolute values, numerical reconstruction difference, lower and upper bounds, nominal ratios, gate components and final status.

Derive the unique primary result only from the three immediate periods and leads48／120; derive the secondary yearly-stability result only from the18 endpoint—year cells and leads48／120. The six-year pooled rows cannot enter either decision. Save separate status counts for`pass`、`fail`、`numerical_boundary_uncertain`、`reference_quality_fail`and`invalid`.

- [ ] **Step 6: Verify counts, matched histories and historical engineering evidence**

Require12 valid selections,12 valid`MATCHED3`continuous chains,885,600 processed filter hours,30,256 complete origins,3,630,720 production predictions,3,630,720 reconstructed predictions,11,520 metric rows and no scoring NaN. Require the four lengths within an endpoint to share the state-preparation timestamps, forcing and observed-flow hash. Verify the three existing3-month common-year results as stated in Task4; explicitly exclude the old24-month full-history results from equality validation.

The final audit must separately label its evidence levels: independent ranking reconstruction, independent scalar deterministic-forecast reconstruction, historical3-month engineering reproduction, and production-core continuous filtering. It must not call the full filtering history “independently reproduced,” because the audit does not reimplement that filter.

- [ ] **Step 7: Commit this task only**

```bash
git add python/regge_record_length_study/audit.py python/regge_record_length_study/run.py python/tests/test_regge_record_length_study.py
git commit -m "feat: independently audit record-length effects"
```

## Task 6: 生成可判读图表和结论受限报告

**Files:**
- Create: `python/regge_record_length_study/report.py`
- Modify: `python/regge_record_length_study/run.py`
- Test: `python/tests/test_regge_record_length_study.py`

**Interfaces:**
- Produces: `report.md`、`figures/record_length_rmse_ratio_48_120.png`、三个`figures/<endpoint>_lead_curve.png`、`figures/annual_nash_efficiency_heatmap.png` and final `manifest.json`.

- [ ] **Step 1: Test report inputs and labels**

Assert each plotted value maps to one audited CSV row; Chinese labels must spell out资料长度、结束时刻、提前时间 and metric direction. Negative Nash efficiency values remain visible.

- [ ] **Step 2: Implement the primary immediate-period length-effect figure**

Only use the three immediate one-year periods. Use资料长度3、6、12、24个月为横轴，分面显示48和120小时；三条线表示三个结束时刻。上半图画对匹配状态24个月参考的均方根误差比及数值边界，并标出1.05门槛；下半图画绝对纳什效率系数。图题和图注必须写“近期评价”，不要用六年合并结果替代三个结束时刻。

- [ ] **Step 3: Implement period-explicit full lead-time and annual figures**

每个结束时刻一张近期评价的1—120小时曲线，四条线代表资料长度；第五张年度热图逐年显示2005—2010年48／120小时纳什效率系数、均方根误差比和门槛状态。统一色标、保留负值并在无效或数值边界无法确定处写明原因。六年合并值只进入报告表格，不另作主图。

- [ ] **Step 4: Write the report from audited files only**

报告先回答“近期达标的最短已测长度”，再单独回答“多年逐年稳定的最短已测长度”；不得用六年合并表现替换逐年结论。随后报告`k/3`、六年合并描述、数值边界状态和所选物理参数／过程噪声身份是否稳定。明确三结束时刻重叠、同流域回溯、匹配的3个月状态准备、实测未来气象及持续流量状态更新的边界。

- [ ] **Step 5: Render and inspect every figure**

Open all five figures at full resolution. Check legend, line colors, axes, Chinese glyphs, negative values and 1.05 threshold. Record visual inspection in `report_receipt.json`.

- [ ] **Step 6: Seal the final manifest after all events are written**

Hash every file except `manifest.json`; reread and verify every hash. The manifest states that technical completion does not imply a positive scientific result.

- [ ] **Step 7: Commit this task only**

```bash
git add python/regge_record_length_study/report.py python/regge_record_length_study/run.py python/tests/test_regge_record_length_study.py
git commit -m "feat: report Regge record-length effects"
```

## Task 7: 正式执行顺序与最终交接

**Files:**
- Modify only if a tested engineering defect is found: files created in Tasks1—6
- Create during execution: `output/regge_length/<new-exclusive-attempt>/...`

**Interfaces:**
- Consumes all prior stages.
- Produces a complete, immutable result root or a preserved failed attempt.

- [ ] **Step 1: Run all unit, negative-case and fixed real-prefix tests**

Run: `python -m pytest -q python/tests/test_regge_record_length_study.py`

Expected: all tests pass; the fixed real-prefix budget is240 filter hours plus240 forecast steps; no formal calibration output is created by tests.

- [ ] **Step 2: Prepare and reread the frozen attempt**

Run: `python python/run_regge_record_length_study.py prepare`

Expected: source, input, version, resource and path gates pass; exactly12 selection rows、12`MATCHED3`evaluation rows and6 missing-calibration rows are frozen. A second`prepare`against the same directory must refuse to run.

- [ ] **Step 3: Execute six calibrations sequentially**

Run: `python python/run_regge_record_length_study.py calibrate`

Expected: six complete receipts, six raw arrays, no silent retry.

- [ ] **Step 4: Freeze selection identities**

Run: `python python/run_regge_record_length_study.py select`

Expected:12 identities fixed before evaluation; existing six identities match the known records in Task3.

- [ ] **Step 5: Execute 12 matched-history continuous single-model chains**

Run: `python python/run_regge_record_length_study.py assess`

Expected:12 valid methods,885,600 processed filter hours, no annual state reset, four lengths within each endpoint share the same3-month state-preparation interval, and the three existing3-month common-period results satisfy the engineering reproduction check. Old24-month full-history equality is not required.

- [ ] **Step 6: Independently audit and generate the report**

Run: `python python/run_regge_record_length_study.py audit`

Run: `python python/run_regge_record_length_study.py report`

Expected: all counts in Task5 pass, including30,256 origins、3,630,720 production predictions、3,630,720 reconstructions and11,520 metric rows; final report and five figures bind only audited values.

- [ ] **Step 7: Write the handoff**

Create `docs/handoff-<date>-regge-record-length-effect.md` with the result root, manifest and audit hashes, selected identities, the separately named immediate and yearly-stability shortest-length outcomes, numerical-boundary or reference-quality failures, adverse results, failed attempts, exact tests, evidence limits and work deliberately left for later full-workflow and interaction experiments.

## 4. 本计划不回答的问题

- 不比较完全交互与不混合状态；资料长度效应明确后另做相同五成员银行的交互试验。
- 不比较“从各自选择资料起点开始吸收流量”的完整实际流程；本试验为隔离选择资料长度，统一使用结束时刻前3个月的状态准备历史。完整流程敏感性另立试验。
- 不把参数和过程噪声贡献拆开；若需归因，要另做固定参数换噪声、固定噪声换参数的因子试验。
- 不增加候选预算，不从评价期反向补选组合，不根据图形更改1.05与5%门槛。
- 不证明其他流域、实际气象预报或无后续流量观测条件下的效果。

## 5. 独立审核问题处理表与修订版自查

独立审核对象是第一版计划，第一版SHA-256为`07a079f0b044979feb5b2aed184da36a79328f2086fca811906ade754deb5549`。独立审核报告为`docs/superpowers/plans/2026-09-29-regge-record-length-effect-independent-review-v01.md`，SHA-256为`93b402bea0a85ee512d96e2c5e09dde3027b77aaafbd8a99095464061b39909f`，正式结论是“不通过，修订后才具备实施条件”。本表是修订响应，不把第二版冒充为已获独立通过。

| 独立审核必须项 | 修订处理 | 实施前状态 |
|---|---|---|
| 不同资料长度使用了不同流量状态准备历史 | 三个结束时刻分别统一为结束前3个月的同日起跑；从3个月原始数组按完整参数编号取气象暖机状态并独立重放核验 | 已在计划中关闭 |
| “最短长度”没有唯一评价集合 | 主结论只用三个近期期间共6个单元；次要逐年稳定结论只用36个年度单元；六年合并仅描述 | 已在计划中关闭 |
| 1e-8重建差异没有进入门槛 | 为方法、24个月参考和保持起报流量不变基准保存误差上下界；增加无法确定与零参考测试 | 已在计划中关闭 |
| 内部执行函数适配器绕过公开入口验证 | 显式验证窗口、暖机连续性、数据来源、固定设置、环境和部分失败元数据；增加真实切片未来流量隔离与负例 | 已在计划中关闭 |

其他审核建议也已落实：只把13—14小时称为新增率定估计；同时设置内存和磁盘安全余量；失败仍生成完整失败说明；指标表冻结为11,520行；后续阶段进入已准备目录而不重复创建；独立审核范围拆分为排序重算、确定性预报重建、3个月历史工程重现和生产核心连续滤波。

修订版的事实边界如下：

- 12个资料窗口、6个新增率定、率定计算预算、30,256个评价起报和3,630,720个生产预报值已由独立审核复核；匹配状态后12条评价链预算为885,600个滤波小时。
- 本计划没有运行新增率定、连续滤波、预报或评分，当前无法确定6个月或12个月能否达标。
- 第一版计划和“不通过”的独立审核报告永久保留；本修订版不把该审核改写为已通过，而是逐项关闭其实施阻塞。正式执行前先完成全部测试和准备门槛。
