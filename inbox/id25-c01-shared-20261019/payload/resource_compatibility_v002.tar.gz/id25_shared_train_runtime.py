"""C01 job authorization, lightweight checkpoint inspection, and result receipt."""
import argparse
import hashlib
import importlib.metadata
import ast
import json
import os
from pathlib import Path
import struct
import subprocess
import zipfile

FINGERPRINT = "1622a60017558c111defebde26a62007a61bb9db320a7dc12c1df12dc7d5e612"


def read_json(path):
    return json.loads(path.read_text())


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_name(path.name + ".pending")
    pending.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    pending.replace(path)


def authorize(root):
    job_id = os.environ["SLURM_JOB_ID"]
    policy = read_json(root / "authorization_policy.json")
    adaptation = read_json(root / "package/resource_adaptation.json")
    if policy.get("full_training_authorized") is not True:
        raise PermissionError("Full training is not authorized")
    expected = adaptation["execution_files_sha256"]
    actual = {n: hashlib.sha256((root / "package" / n).read_bytes()).hexdigest() for n in expected}
    execution = hashlib.sha256(json.dumps(actual, sort_keys=True).encode()).hexdigest()
    if actual != expected or execution != adaptation["execution_fingerprint"]:
        raise RuntimeError("Execution adaptation identity changed")
    if adaptation["base_fingerprint"] != FINGERPRINT:
        raise RuntimeError("Adaptation refers to another scientific core")
    accepted = read_json(root / "provenance/gpu_preflight.json")
    if accepted.get("state") != "GPU_PREFLIGHT_PASS" or accepted["fingerprint"] != FINGERPRINT:
        raise RuntimeError("Original accepted GPU receipt changed")
    gpu_ids = [x.strip() for x in os.environ.get("SLURM_JOB_GPUS", "").split(",") if x.strip()]
    if len(gpu_ids) != 1:
        raise RuntimeError("Exactly one Slurm-allocated GPU is required")
    result = subprocess.run(
        ["nvidia-smi", "-i", gpu_ids[0], "--query-gpu=uuid,name,memory.total,driver_version,compute_cap",
         "--format=csv,noheader,nounits"], capture_output=True, text=True, check=True, timeout=10)
    uuid, name, memory, driver, capability = [x.strip() for x in result.stdout.strip().split(",")]
    version = lambda value: tuple(int(x) for x in value.split("."))
    glibc = os.confstr("CS_GNU_LIBC_VERSION").split()[-1]
    libraries = {n: importlib.metadata.version(n) for n in ("tensorflow", "numpy", "nvidia-cuda-runtime-cu12", "nvidia-cudnn-cu12")}
    if (name != adaptation["gpu_model"] or capability != adaptation["compute_capability"] or
            float(memory) < adaptation["minimum_memory_MiB"] or
            version(driver) < version(adaptation["minimum_driver"]) or
            version(glibc) < version(adaptation["minimum_glibc"]) or
            libraries["tensorflow"] != "2.15.1" or os.sys.version_info[:2] != (3, 11)):
        raise RuntimeError("Allocated GPU or software runtime differs from the compatible RTX3090 profile")
    runtime = dict(job_id=job_id, node=os.environ.get("SLURMD_NODENAME"), slurm_job_gpus=gpu_ids,
                   gpu_uuid=uuid, gpu_name=name, compute_capability=capability,
                   memory_MiB=float(memory), driver=driver, glibc=glibc, libraries=libraries,
                   cpu_preflight_repeated=False, gpu_preflight_repeated=False, full_training_authorized=True,
                   reviewed_fingerprint=FINGERPRINT, execution_fingerprint=execution,
                   gpu_preflight_uuid=accepted["gpu_uuid"], gpu_compatibility_state="COMPATIBLE_RTX3090_PROFILE",
                   python=os.sys.executable)
    write_json(root / "attempts" / job_id / "allocation.json", runtime)
    write_json(root / "runtime.json", runtime)
    approval = dict(full_training_authorized=True, preflight_gpu_authorized=False,
                    gpu_reserved_exclusively=True, other_gpu_experiments_stopped=True,
                    independent_review_accepted=True, reviewed_fingerprint=FINGERPRINT,
                    execution_fingerprint=execution, execution_adaptation_user_authorized=True,
                    approved_gpu_uuid=uuid, approved_wall_seconds=policy["worker_wall_seconds"],
                    slurm_job_id=job_id, reservation_provider="Slurm",
                    reservation_scope="Only the GPU allocated to this job",
                    other_gpu_experiments_stopped_scope="No competing process on this allocated GPU",
                    stopped_or_modified_other_jobs=[], billing_confirmation_required=False,
                    notes="Original independent review covers unchanged scientific core; user authorized execution-only GPU compatibility adaptation")
    write_json(root / "attempts" / job_id / "authorization.json", approval)
    print(json.dumps(runtime), flush=True)


def checkpoint_metadata(path):
    # Read only the small JSON metadata member, without importing NumPy or weights.
    with zipfile.ZipFile(path) as archive:
        data = archive.read("metadata.npy")
    if data[:6] != b"\x93NUMPY":
        raise ValueError("Invalid metadata NPY member")
    major = data[6]
    if major == 1:
        length = struct.unpack("<H", data[8:10])[0]
        start = 10
    elif major in (2, 3):
        length = struct.unpack("<I", data[8:12])[0]
        start = 12
    else:
        raise ValueError("Unsupported NPY metadata version")
    header = ast.literal_eval(data[start:start + length].decode("latin1"))
    if header["shape"] != () or header["descr"][:2] not in ("<U", ">U"):
        raise ValueError("Expected scalar Unicode JSON metadata")
    encoding = "utf-32-le" if header["descr"].startswith("<") else "utf-32-be"
    return json.loads(data[start + length:].decode(encoding).rstrip("\0"))


def inspect(root):
    result = {}
    for name in ("runtime.json", "output/status.json", "output/selection.json", "report.json"):
        path = root / name
        if path.is_file():
            result[name] = read_json(path)
    last = root / "output/last.npz"
    if last.is_file():
        result["last_checkpoint_metadata"] = checkpoint_metadata(last)
    epochs = sorted((root / "output/epochs").glob("*.json"))
    if epochs:
        result["latest_epoch"] = read_json(epochs[-1])
    print(json.dumps(result, allow_nan=False))


def report(root):
    status = read_json(root / "output/status.json")
    selection = read_json(root / "output/selection.json")
    scores = read_json(root / "comparison/acceptance_metrics.json")
    if status["state"] != "COMPLETED" or selection["state"] != "FROZEN" or scores["state"] != "SCORED":
        raise ValueError("Frozen predictions and scores are required")
    result = dict(state="RESULTS_READY", experiment_id="C01_SHARED_AUTHOR_LSTM_20261019",
                  regions=119, seed=20261015, shared_weights=True, fixed_rds01=True,
                  reviewed_fingerprint=FINGERPRINT, execution_fingerprint=selection["fingerprint"], completed_epochs=selection["completed_epochs"],
                  best_epoch=selection["best_epoch"], stop_reason=selection["stop_reason"],
                  optimizer_steps=status["optimizer_steps"], development_only=True,
                  cpu_preflight_repeated=False, gpu_preflight_repeated=False,
                  selection_frozen=True, metrics=scores)
    write_json(root / "report.json", result)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("authorize", "inspect", "report"))
    parser.add_argument("root", type=Path)
    args = parser.parse_args()
    {"authorize": authorize, "inspect": inspect, "report": report}[args.action](args.root)
