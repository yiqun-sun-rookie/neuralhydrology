"""Independent C01 runner. CPU checks are default-safe; GPU modes require separate explicit approval.

GPU code is prepared for review, not validated by the CPU suite. No application
labels are read by training or resource preflight. No Slurm submission is provided.
"""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import secrets
import select
import signal
import stat
import subprocess
import sys
import time
from types import SimpleNamespace

import numpy as np
import shared_endpoint as c

HERE = Path(__file__).resolve().parent


def code_fingerprint():
    names = ['config.json','scaler_manifest.json','author_model.py','shared_endpoint.py','run_control.py','score_saved.py','requirements-linux.txt']
    values = {n:c.sha256(HERE/n) for n in names}
    return hashlib.sha256(json.dumps(values,sort_keys=True).encode()).hexdigest()


def receipt_fingerprint_matches(fingerprint):
    current=code_fingerprint()
    if fingerprint==current:return True
    policy=json.loads((HERE/'resource_adaptation.json').read_text())
    names=['config.json','scaler_manifest.json','author_model.py','shared_endpoint.py','run_control.py','score_saved.py','requirements-linux.txt']
    actual={n:c.sha256(HERE/n) for n in names}
    base=policy['base_files_sha256']
    return (policy.get('state')=='EXECUTION_ONLY_GPU_COMPATIBILITY_ADAPTATION' and
            fingerprint==policy['base_fingerprint'] and
            hashlib.sha256(json.dumps(base,sort_keys=True).encode()).hexdigest()==fingerprint and
            current==policy['execution_fingerprint'] and actual==policy['execution_files_sha256'] and
            all(actual[n]==base[n] for n in names if n!='run_control.py'))


def cpu_check(root, out, config):
    started = time.perf_counter()
    data = c.prepare(root,config)
    batches = c.epoch_batches(119,np.flatnonzero(data['fit']),32,config['seed'],1)
    seen = np.zeros((119,78),dtype=int)
    sizes, peaks = [], []
    for r, indices in batches:
        x = c.pad_prefixes(data['features'][r],data['lengths'][indices],config['padding_value'])
        mask = ~np.all(x == np.float32(config['padding_value']),axis=-1)
        np.testing.assert_array_equal(mask,np.arange(x.shape[1])[None,:]<data['lengths'][indices,None])
        seen[r,indices] += 1
        sizes.append(len(indices));peaks.append(x.nbytes)
    np.testing.assert_array_equal(seen[:,data['fit']],np.ones((119,66),dtype=int))
    assert not seen[:,~data['fit']].any()
    assert len(batches)==357 and sum(sizes)==7854
    report=dict(state='CPU_CONTRACT_PASS',fingerprint=code_fingerprint(),regions=119,
                fit_windows=66,selection_windows=12,batches=357,region_window_samples=7854,
                tail_batches_size2=sizes.count(2),all_scalers_roundtrip=True,all_padding_masks_match=True,
                longest_fit_prefix=int(data['lengths'][data['fit']].max()),
                longest_validation_prefix=int(data['lengths'][~data['fit']].max()),
                feature_host_bytes=sum(x.nbytes for x in data['features']),largest_built_batch_bytes=max(peaks),
                elapsed_seconds=time.perf_counter()-started,application_inputs_opened=False,
                application_targets_opened=False,tensorflow_imported='tensorflow' in sys.modules,
                gpu_context_created=False,optimizer_steps=0)
    c.write_json(out/'cpu_contract.json',report)
    print(json.dumps(report))


def gpu_gate(approval, mode):
    c.require_gpu_permission(approval,mode)
    if approval.get('independent_review_accepted') is not True:
        raise PermissionError('Independent code review has not been accepted')
    if (not receipt_fingerprint_matches(approval.get('reviewed_fingerprint')) or
            approval.get('execution_fingerprint',code_fingerprint())!=code_fingerprint()):
        raise PermissionError('Independent review fingerprint does not match current code/configuration')
    if sys.platform != 'linux':
        raise RuntimeError('Frozen TensorFlow 2.15.1 GPU runtime requires Linux/WSL2; no native-Windows fallback')
    wanted = approval.get('approved_gpu_uuid')
    if not wanted:
        raise PermissionError('One explicitly reserved GPU UUID is required')
    result = subprocess.run(['nvidia-smi','--query-gpu=uuid','--format=csv,noheader'],capture_output=True,text=True,check=True,timeout=10)
    if wanted not in [s.strip() for s in result.stdout.splitlines()]:
        raise RuntimeError('Reserved GPU UUID is unavailable')
    result = subprocess.run(['nvidia-smi','-i',wanted,'--query-compute-apps=pid','--format=csv,noheader'],capture_output=True,text=True,check=True,timeout=10)
    if result.stdout.strip():
        raise RuntimeError('Compute process exists or occupancy is unavailable; do not compete for GPU')
    return wanted


def arm_linux_parent_death(parent_pid):
    """Fail closed if the launching parent dies before or during prctl setup."""
    if sys.platform!='linux' or os.getppid()!=parent_pid:
        raise PermissionError('Worker has no live Linux supervisor parent')
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(1,signal.SIGKILL,0,0,0)!=0:  # PR_SET_PDEATHSIG
        raise OSError(ctypes.get_errno(),'Cannot arm worker parent-death signal')
    if os.getppid()!=parent_pid:
        raise PermissionError('Supervisor exited during parent-death setup')


def require_worker_supervision(config,mode,approval):
    """An inherited control pipe, parent identity and reservation bind this worker."""
    try:
        parent_pid=int(os.environ['C01_SUPERVISOR_PID'])
        control_fd=int(os.environ['C01_CONTROL_FD'])
        token=os.environ['C01_SUPERVISION_TOKEN']
    except (KeyError,ValueError) as error:
        raise PermissionError('Internal worker requires an inherited supervisor control channel') from error
    if mode=='cpu-check' or not token or not stat.S_ISFIFO(os.fstat(control_fd).st_mode):
        raise PermissionError('Invalid supervisor control channel')
    arm_linux_parent_death(parent_pid)
    message=b''
    handshake_deadline=time.monotonic()+2
    while not message.endswith(b'\n') and len(message)<4096:
        remaining=handshake_deadline-time.monotonic()
        if remaining<=0 or not select.select([control_fd],[],[],remaining)[0]:
            raise PermissionError('Supervisor handshake timed out')
        part=os.read(control_fd,4096-len(message))
        if not part:raise PermissionError('Supervisor control channel closed')
        message+=part
    try:
        record=json.loads(message)
        reservation=json.loads((HERE/'.gpu_reservation.lock').read_text())
        limit=config['preflight']['hard_wall_seconds'] if mode=='preflight' else approval['approved_wall_seconds']
        remaining=record['deadline_monotonic']-time.monotonic()
        valid=(record['token']==token==reservation['token'] and
               record['parent_pid']==parent_pid==reservation['parent_pid']==os.getppid() and
               record['child_pid']==os.getpid()==reservation['child_pid'] and
               record['mode']==mode and record['fingerprint']==code_fingerprint() and
               0<record['timeout_seconds']<=limit and 0<remaining<=record['timeout_seconds'])
    except (KeyError,TypeError,ValueError,OSError) as error:
        raise PermissionError('Invalid supervisor handshake') from error
    if not valid:raise PermissionError('Worker is not bound to a live matching supervisor')
    # Independent Linux deadline remains bounded even if the parent's wait is interrupted.
    signal.signal(signal.SIGALRM,signal.SIG_DFL)
    signal.setitimer(signal.ITIMER_REAL,remaining)


class SupervisorSignal(KeyboardInterrupt):
    def __init__(self,signum):
        self.signum=signum
        super().__init__('Supervisor received signal '+str(signum))


def reap_owned_child(child,force=False):
    """Touch only this Popen child; never signal by process name or GPU inventory."""
    if child.poll() is None:
        if force:child.kill()
        else:child.terminate()
        try:child.wait(timeout=2)
        except subprocess.TimeoutExpired:
            child.kill();child.wait(timeout=5)
    else:child.wait(timeout=0)
    return child.poll() is not None


def supervise_worker(cmd,out,timeout,mode,stdout,stderr):
    """Own the reservation until our child has been reaped, including all exits."""
    started=time.perf_counter();deadline=time.monotonic()+timeout
    lock=HERE/'.gpu_reservation.lock';token=secrets.token_hex(24)
    child=None;read_fd=None;write_fd=None;lock_owned=False
    confirmed=False;released=False;code=1;state='FAILED';failure=None;cleanup_error=None
    previous_handlers={}

    def interrupted(signum,_frame):raise SupervisorSignal(signum)

    try:
        fd=os.open(lock,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        lock_owned=True
        with os.fdopen(fd,'w') as handle:
            json.dump(dict(token=token,parent_pid=os.getpid(),child_pid=None),handle)
        for signum in [signal.SIGINT,signal.SIGTERM]:
            previous_handlers[signum]=signal.signal(signum,interrupted)
        read_fd,write_fd=os.pipe()
        env=dict(os.environ,C01_SUPERVISOR_PID=str(os.getpid()),C01_CONTROL_FD=str(read_fd),C01_SUPERVISION_TOKEN=token)
        child=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,env=env,pass_fds=(read_fd,))
        os.close(read_fd);read_fd=None
        record=dict(token=token,parent_pid=os.getpid(),child_pid=child.pid,mode=mode,
                    timeout_seconds=timeout,deadline_monotonic=deadline,fingerprint=code_fingerprint())
        c.write_json(lock,record)
        payload=(json.dumps(record)+'\n').encode()
        if os.write(write_fd,payload)!=len(payload):raise RuntimeError('Incomplete supervisor handshake')
        code=child.wait(timeout=max(0,deadline-time.monotonic()))
        state='EXITED' if code==0 else 'TIME_LIMIT' if code==-signal.SIGALRM else 'FAILED'
        if state=='TIME_LIMIT':code=124
    except subprocess.TimeoutExpired:
        code=124;state='TIME_LIMIT'
    except BaseException as error:
        failure=type(error).__name__+': '+str(error)
        code=128+error.signum if isinstance(error,SupervisorSignal) else 130 if isinstance(error,KeyboardInterrupt) else 1
        state='INTERRUPTED' if isinstance(error,KeyboardInterrupt) else 'FAILED'
    finally:
        # A second catchable signal must not interrupt kill/wait and release a live reservation.
        for signum in previous_handlers:signal.signal(signum,signal.SIG_IGN)
        try:
            confirmed=child is None or reap_owned_child(child,force=state=='TIME_LIMIT')
        except BaseException as error:
            cleanup_error=type(error).__name__+': '+str(error)
        for fd in [read_fd,write_fd]:
            if fd is not None:os.close(fd)
        if lock_owned and confirmed:
            try:
                current=json.loads(lock.read_text())
                if current.get('token')==token and current.get('parent_pid')==os.getpid():
                    lock.unlink();released=True
            except (OSError,ValueError):pass
        if not confirmed:code=125;state='CLEANUP_UNCONFIRMED'
        try:
            c.write_json(out/'supervisor.json',dict(exit_code=code,wall_limit_seconds=timeout,
                        elapsed_seconds=time.perf_counter()-started,state=state,failure=failure,cleanup_error=cleanup_error,
                        child_pid=None if child is None else child.pid,child_exit_confirmed=confirmed,lock_released=released,
                        automatic_retry=False,full_training_authorized_by_preflight=False))
        finally:
            for signum,handler in previous_handlers.items():signal.signal(signum,handler)
    return code


def tensorflow_model(config, gpu_uuid):
    if c.sha256(HERE/'author_model.py') != config['author_module_sha256']:
        raise ValueError('Author model snapshot changed')
    os.environ.update(CUDA_VISIBLE_DEVICES=gpu_uuid,TF_ENABLE_ONEDNN_OPTS='0',TF_CPP_MIN_LOG_LEVEL='2',
                      OMP_NUM_THREADS=str(config['threads']),CUBLAS_WORKSPACE_CONFIG=':4096:8')
    import tensorflow as tf
    if tf.__version__ != config['tensorflow_version']:
        raise RuntimeError('Frozen TensorFlow version differs')
    tf.config.threading.set_inter_op_parallelism_threads(1)
    tf.config.threading.set_intra_op_parallelism_threads(config['threads'])
    devices=tf.config.list_physical_devices('GPU')
    if len(devices)!=1:raise RuntimeError('Exactly one reserved GPU is required')
    tf.config.set_logical_device_configuration(devices[0],[tf.config.LogicalDeviceConfiguration(memory_limit=config['preflight']['gpu_memory_limit_MiB'])])
    tf.config.experimental.enable_op_determinism()
    tf.config.experimental.enable_tensor_float_32_execution(False)
    tf.keras.utils.set_random_seed(config['seed'])
    from author_model import model_config
    hp=SimpleNamespace(units_in=config['lstm_units'],units_lay1=config['dense_units'],units_lay2=0,window=None,l_rate=config['learning_rate'])
    with tf.device('/GPU:0'):
        model=model_config(hp,list(range(11)),pidx=0,model_type='LSTM',padding_value=config['padding_value'])
    if model.count_params()!=6177:raise ValueError('Author parameter count differs')
    optimizer=model.optimizer;optimizer.build(model.trainable_variables)

    @tf.function(input_signature=[tf.TensorSpec([None,None,11],tf.float32),tf.TensorSpec([None,1],tf.float32)])
    def update(x,y):
        with tf.GradientTape() as tape:
            loss=tf.reduce_mean(tf.square(model(x,training=True)-y))
        gradients=tape.gradient(loss,model.trainable_variables)
        tf.debugging.assert_all_finite(loss,'Nonfinite loss')
        for g in gradients:tf.debugging.assert_all_finite(g,'Nonfinite gradient')
        optimizer.apply_gradients(zip(gradients,model.trainable_variables))
        return loss,tf.linalg.global_norm(gradients)
    return tf,model,optimizer,update


def optimizer_values(optimizer):
    values=optimizer.variables
    return list(values() if callable(values) else values)


def checkpoint_arrays(model,optimizer,best):
    arrays={f'w_{i}':v for i,v in enumerate(model.get_weights())}
    arrays.update({f'o_{i}':v.numpy() for i,v in enumerate(optimizer_values(optimizer))})
    arrays.update({f'b_{i}':v for i,v in enumerate(best)})
    return arrays


def restore_arrays(model,optimizer,arrays):
    model.set_weights([arrays[f'w_{i}'] for i in range(len(model.get_weights()))])
    for i,v in enumerate(optimizer_values(optimizer)):v.assign(arrays[f'o_{i}'])
    return [arrays[f'b_{i}'].copy() for i in range(len(model.get_weights()))]


def predict_region(model,x,lengths,config):
    values=[]
    for start in range(0,len(lengths),32):
        batch=c.pad_prefixes(x,lengths[start:start+32],config['padding_value'])
        values.append(model(batch,training=False).numpy().reshape(-1))
    return np.concatenate(values)


def history_predictions(model,data,config):
    raw=np.empty((78,119),dtype=float)
    for r in range(119):
        # Preserve original B04 fit 32/32/2 and validation 12 forward grouping.
        for mask in [data['fit'],~data['fit']]:
            z=predict_region(model,data['features'][r],data['lengths'][mask],config)
            raw[mask,r]=c.target_inverse(z,data['scalers'][r])
    return raw


def gpu_preflight(root,out,config,gpu_uuid):
    preflight_start=time.perf_counter()
    data=c.prepare(root,config)
    tf,model,optimizer,update=tensorflow_model(config,gpu_uuid)
    initialization_seconds=time.perf_counter()-preflight_start
    r=config['preflight']['fixed_region_index'];x=data['features'][r]
    fit_idx=np.flatnonzero(data['fit']);lengths=data['lengths']
    # Fixed lexicographically first region; time indices depend only on support length.
    idx32=fit_idx[np.linspace(0,65,32,dtype=int)]
    idx2=fit_idx[[0,-1]]
    batches={'train32':(c.pad_prefixes(x,lengths[idx32],config['padding_value']),data['scaled_targets'][idx32,r,None]),
             'train2':(c.pad_prefixes(x,lengths[idx2],config['padding_value']),data['scaled_targets'][idx2,r,None])}
    infer_idx=np.linspace(0,77,32,dtype=int)
    batches.update(infer32=(c.pad_prefixes(x,lengths[infer_idx],config['padding_value']),None),
                   infer2=(c.pad_prefixes(x,lengths[[0,-1]],config['padding_value']),None),
                   infer12=(c.pad_prefixes(x,lengths[~data['fit']],config['padding_value']),None))
    synthetic=np.concatenate([x,np.repeat(x[-1:],730,axis=0)],axis=0)
    batches['infer_application_stress32']=(c.pad_prefixes(synthetic,np.full(32,4536),config['padding_value']),None)
    # One real mask/readout check, before timed operations.
    probe=c.pad_prefixes(x,lengths[:2],config['padding_value'])
    actual=model.get_layer('input_padding').compute_mask(tf.convert_to_tensor(probe)).numpy()
    np.testing.assert_array_equal(actual,np.arange(probe.shape[1])[None,:]<lengths[:2,None])
    padded_output=model(probe,training=False).numpy()
    if padded_output.shape!=(2,1):raise ValueError('Author endpoint output is not one scalar per prefix')
    padded=padded_output.reshape(-1)
    separate=np.array([float(model(x[:end][None],training=False).numpy()[0,0]) for end in lengths[:2]])
    np.testing.assert_allclose(padded,separate,atol=1e-5,rtol=1e-5)
    timings={};shapes={}
    for name,(batch,y) in batches.items():
        def operation():
            if y is None:
                values=model(batch,training=False).numpy()
                if not np.isfinite(values).all():raise FloatingPointError('Nonfinite probe output')
            else:
                loss,norm=update(batch,y);float(loss.numpy());float(norm.numpy())
        operation()  # one warmup, not included in steady-state estimate
        durations=[]
        for _ in range(3):
            start=time.perf_counter();operation();durations.append(time.perf_counter()-start)
        timings[name]={'seconds':durations,'median':float(np.median(durations)),'max':max(durations)}
        shapes[name]=list(batch.shape)
    # Real optimizer/weight/cursor roundtrip plus identical next update, discarded.
    arrays=checkpoint_arrays(model,optimizer,model.get_weights())
    metadata=dict(fingerprint=code_fingerprint(),next_batch=1,epoch=1)
    start=time.perf_counter();c.save_checkpoint(out/'probe_state.npz',metadata,arrays);save_seconds=time.perf_counter()-start
    update(*batches['train2']);expected=checkpoint_arrays(model,optimizer,model.get_weights())
    _,restored=c.load_checkpoint(out/'probe_state.npz',code_fingerprint())
    restore_arrays(model,optimizer,restored);update(*batches['train2'])
    actual=checkpoint_arrays(model,optimizer,model.get_weights())
    for key in expected:np.testing.assert_allclose(actual[key],expected[key],atol=1e-6,rtol=1e-5)
    peak=tf.config.experimental.get_memory_info('GPU:0')
    padding_seconds=[]
    for _ in range(3):
        start=time.perf_counter();c.pad_prefixes(x,lengths[infer_idx],config['padding_value'])
        padding_seconds.append(time.perf_counter()-start)
    # 3 training batches + 4 frozen-weight evaluation batches per region per epoch.
    assembly_bound=119*7*max(padding_seconds)
    med=c.epoch_seconds_bound(119,{k:v['median'] for k,v in timings.items()},save_seconds)+assembly_bound
    high=(c.epoch_seconds_bound(119,{k:v['max'] for k,v in timings.items()},save_seconds)+assembly_bound)*1.5
    import resource
    finalization_bound=119*(2*timings['infer32']['max']+timings['infer2']['max']+timings['infer12']['max']+timings['infer_application_stress32']['max'])
    c.write_json(out/'gpu_preflight.json',dict(state='GPU_PREFLIGHT_PASS',fingerprint=code_fingerprint(),gpu_uuid=gpu_uuid,
        generated_at_unix=time.time(),initialization_seconds=initialization_seconds,preflight_elapsed_seconds=time.perf_counter()-preflight_start,
        fixed_region_id=str(data['ids'][r]),region_selection='lexicographic index 0, no performance selection',
        shapes=shapes,timings=timings,checkpoint_write_seconds=save_seconds,tf_memory=peak,
        cpu_padding_seconds=padding_seconds,host_peak_RSS_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        estimated_epoch_seconds=med,conservative_epoch_seconds=high,
        finalization_seconds_bound=finalization_bound,
        estimates_hours={str(e):{'central':(initialization_seconds+e*med+finalization_bound)/3600,'conservative':(initialization_seconds+e*high+1.5*finalization_bound)/3600} for e in [31,86,300,1000]},
        parameter_count=model.count_params(),mask_and_padding_invariance='PASS',real_optimizer_resume='PASS',
        application_data_opened=False,application_stress_synthetic=True,scientific_scores_computed=False,
        probe_weights_forbidden_for_training=True,finite_updates=True,
        caveat='Upper-length synthetic timing estimate, not measured full-run time; memory excludes some driver/display allocation'))


def train(root,out,config,gpu_uuid,preflight):
    if out.resolve()==Path(preflight).resolve().parent:
        raise ValueError('Training must use a separate output directory from the disposable probe')
    receipt=json.loads(Path(preflight).read_text())
    if receipt.get('state')!='GPU_PREFLIGHT_PASS' or not receipt_fingerprint_matches(receipt['fingerprint']):
        raise ValueError('Accepted scientific-core GPU preflight is required')
    if receipt['gpu_uuid']!=gpu_uuid or receipt['fingerprint']!=code_fingerprint():
        allocation=json.loads((HERE.parent/'runtime.json').read_text())
        if (allocation.get('gpu_compatibility_state')!='COMPATIBLE_RTX3090_PROFILE' or
                allocation.get('gpu_uuid')!=gpu_uuid or
                allocation.get('gpu_preflight_uuid')!=receipt['gpu_uuid'] or
                allocation.get('execution_fingerprint')!=code_fingerprint()):
            raise ValueError('Current Slurm allocation has no compatible hardware receipt')
    data=c.prepare(root,config)
    tf,model,optimizer,update=tensorflow_model(config,gpu_uuid)
    fingerprint=code_fingerprint()
    state=dict(fingerprint=fingerprint,epoch=1,next_batch=0,completed_epochs=0,optimizer_steps=0,
               wait=0,best_epoch=0,best_score=None,best_reference=None,partial_loss_sum=0.,partial_count=0)
    best=model.get_weights()
    if (out/'last.npz').exists():
        state,arrays=c.load_checkpoint(out/'last.npz',fingerprint)
        best=restore_arrays(model,optimizer,arrays)
    while state['completed_epochs']<config['max_epochs'] and state['wait']<config['patience']:
        started=time.perf_counter()
        batches=c.epoch_batches(119,np.flatnonzero(data['fit']),32,config['seed'],state['epoch'])
        for k in range(state['next_batch'],len(batches)):
            r,idx=batches[k]
            x=c.pad_prefixes(data['features'][r],data['lengths'][idx],config['padding_value'])
            loss,norm=update(x,data['scaled_targets'][idx,r,None])
            value=float(loss.numpy());gradient=float(norm.numpy())
            state.update(next_batch=k+1,optimizer_steps=int(optimizer.iterations.numpy()),
                         partial_loss_sum=state['partial_loss_sum']+value*len(idx),
                         partial_count=state['partial_count']+len(idx),last_gradient_norm=gradient)
            c.save_checkpoint(out/'last.npz',state,checkpoint_arrays(model,optimizer,best))
        raw=history_predictions(model,data,config)
        mse,pref,_=c.selection_score(raw,data['targets_cm'],data['fit'],data['y_ref'])
        if state['best_score'] is None or mse<state['best_score']:
            best=model.get_weights()
            state.update(best_score=mse,best_epoch=state['epoch'],best_reference=pref.tolist(),wait=0)
        else:state['wait']+=1
        completed=state['epoch']
        metrics=dict(epoch=completed,train_scaled_mse=state['partial_loss_sum']/state['partial_count'],
                     val_ref_mse_cm2=mse,best_epoch=state['best_epoch'],wait=state['wait'],
                     optimizer_steps=state['optimizer_steps'],invocation_epoch_seconds=time.perf_counter()-started)
        state.update(completed_epochs=completed,epoch=completed+1,next_batch=0,partial_loss_sum=0.,partial_count=0)
        # Epoch file may be safely recreated after interruption; no duplicated append rows.
        c.write_json(out/'epochs'/f'{completed:04d}.json',metrics)
        c.save_checkpoint(out/'last.npz',state,checkpoint_arrays(model,optimizer,best))
        c.write_json(out/'status.json',dict(state='TRAINING',**state))
    model.set_weights(best)
    raw=history_predictions(model,data,config)
    score,pref,history=c.selection_score(raw,data['targets_cm'],data['fit'],data['y_ref'])
    np.testing.assert_allclose(pref,state['best_reference'],atol=1e-5,rtol=1e-5)
    np.testing.assert_allclose(score,state['best_score'],atol=1e-5,rtol=1e-5)
    model.save(out/'best.keras')
    c.write_json(out/'selection.json',dict(state='FROZEN',fingerprint=fingerprint,best_epoch=state['best_epoch'],
                 best_val_mse_cm2=score,completed_epochs=state['completed_epochs'],
                 stop_reason='PATIENCE' if state['wait']>=30 else 'MAX_EPOCHS',
                 prediction_reference_cm=pref.tolist(),observation_reference_cm=data['y_ref'].tolist(),
                 application_targets_read=False))
    path=Path(root)/config['sources']['application']
    if c.sha256(path)!=config['sources']['application_sha256']:raise ValueError('Application fingerprint changed')
    with np.load(path,allow_pickle=False) as z:app={k:z[k].copy() for k in z.files}
    np.testing.assert_array_equal(app['region_ids'].astype(str),data['ids'])
    if str(app['dates'][0])!='2009-01-01' or str(app['dates'][-1])!='2010-12-31' or np.any(np.diff(app['dates']).astype(int)!=1):
        raise ValueError('Application calendar changed')
    application=np.empty((24,119),dtype=float)
    for r in range(119):
        newx=c.features(app['dynamic'][:,r],data['static_features'][r],data['scalers'][r],config['padding_value'])
        x=np.concatenate([data['features'][r],newx],axis=0)
        z=predict_region(model,x,3806+c.prefix_lengths(app['sampling_weights']),config)
        application[:,r]=c.target_inverse(z,data['scalers'][r])-pref[r]
    if not np.isfinite(application).all():raise FloatingPointError('Application prediction nonfinite')
    np.savez_compressed(out/'predictions.npz',support_ids=data['ids'],solution_ids=np.r_[data['solution_ids'],app['solution_ids']],
                       fit_mask=data['fit'],history_anomaly_cm=history,application_anomaly_cm=application)
    c.write_json(out/'status.json',dict(state='COMPLETED',fingerprint=fingerprint,regions=119,application_windows=24,
                                       application_targets_read=False,optimizer_steps=state['optimizer_steps']))


def main():
    p=argparse.ArgumentParser()
    p.add_argument('mode',choices=['cpu-check','preflight','train'])
    p.add_argument('--source-root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--authorization',type=Path,default=HERE/'authorization.json')
    p.add_argument('--preflight-receipt',type=Path)
    p.add_argument('--cpu-receipt',type=Path)
    p.add_argument('--_worker',action='store_true',help=argparse.SUPPRESS)
    args=p.parse_args()
    config=json.loads((HERE/'config.json').read_text())
    approval=None
    if args._worker:
        approval=json.loads(args.authorization.read_text())
        require_worker_supervision(config,args.mode,approval)  # before GPU gate or context creation
    root,out=args.source_root.resolve(),args.output.resolve()
    if out==root or root in out.parents:raise ValueError('Output must be outside frozen worktree')
    if args.mode=='cpu-check':
        os.environ['CUDA_VISIBLE_DEVICES']='-1'
        out.mkdir(parents=True,exist_ok=False);cpu_check(root,out,config);return
    if approval is None:approval=json.loads(args.authorization.read_text())
    gpu_uuid=gpu_gate(approval,args.mode)  # before output creation, TF import or GPU work
    if not args.cpu_receipt:
        raise PermissionError('A matching CPU contract receipt is required')
    cpu_receipt=json.loads(args.cpu_receipt.read_text())
    if cpu_receipt.get('state')!='CPU_CONTRACT_PASS' or not receipt_fingerprint_matches(cpu_receipt['fingerprint']):
        raise ValueError('CPU contract receipt is stale or failed')
    if args.mode=='train' and (not args.preflight_receipt or not isinstance(approval.get('approved_wall_seconds'),int) or approval['approved_wall_seconds']<=0):
        raise PermissionError('Training requires a separate wall-time budget and GPU preflight receipt')
    if args._worker:
        if args.mode=='preflight':gpu_preflight(root,out,config,gpu_uuid)
        else:train(root,out,config,gpu_uuid,args.preflight_receipt)
        return
    out.mkdir(parents=True,exist_ok=args.mode=='train')
    if args.mode=='train':(out/'epochs').mkdir(exist_ok=True)
    timeout=config['preflight']['hard_wall_seconds'] if args.mode=='preflight' else approval['approved_wall_seconds']
    cmd=[sys.executable,str(Path(__file__).resolve()),*sys.argv[1:],'--_worker']
    with (out/'stdout.log').open('a') as stdout,(out/'stderr.log').open('a') as stderr:
        code=supervise_worker(cmd,out,timeout,args.mode,stdout,stderr)
    if code:raise SystemExit(code)


if __name__=='__main__':
    main()
