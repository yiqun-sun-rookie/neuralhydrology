"""Apply C01 resource compatibility while retaining its one pending Slurm job."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess


ROOT = Path('/data1/home/sunyiq/id25_graice_shared_c01_20261019_001')
JOB = '245242'
STAGE = ROOT / 'resource_adaptation_v002'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(*args):
    result = subprocess.run(args, text=True, capture_output=True, timeout=30, check=True)
    if result.stdout:
        print(result.stdout, flush=True)
    return result.stdout.strip()


def job():
    raw = run('scontrol', '-o', 'show', 'job', JOB)
    return raw, dict(re.findall(r'\b([A-Za-z][A-Za-z0-9:/]*)=([^ ]*)', raw))


def atomic(path, data):
    pending = path.with_name(path.name + '.resource_v002_pending')
    pending.write_bytes(data)
    pending.replace(path)


def main():
    policy = json.loads((STAGE / 'resource_adaptation.json').read_text())
    result_path = STAGE / 'apply_result.json'
    if result_path.exists():
        raise RuntimeError('Adaptation outcome exists; query it rather than replaying mutation')
    with (ROOT / 'submission.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        before_raw, before = job()
        if before.get('JobId') != JOB or before.get('JobState') != 'PENDING':
            raise RuntimeError('Original job is no longer pending; no adaptation applied')
        if before.get('Reason', '').startswith('JobHeld') or before.get('UserId', '').split('(')[0] != 'sunyiq':
            raise RuntimeError('Unexpected owner or an existing hold; no adaptation applied')
        if (ROOT / 'job_id.txt').read_text().strip() != JOB:
            raise RuntimeError('Experiment job identity changed')
        if (ROOT / 'output/last.npz').exists() or list((ROOT / 'output/epochs').glob('*.json')):
            raise RuntimeError('Training has updates; no fingerprint migration or reset allowed')
        for name, digest in policy['base_files_sha256'].items():
            if sha(ROOT / 'package' / name) != digest:
                raise RuntimeError('Original reviewed file changed: ' + name)
        if sha(ROOT / 'ops/id25_shared_train_runtime.py') != 'f66b3310af6e20c2985e6d90be69a0e53bb02453180f224c869c92a43e70c287':
            raise RuntimeError('Original execution helper changed')
        protected = ['submissions.tsv', 'provenance/cpu_contract.json', 'provenance/gpu_preflight.json']
        protected_hashes = {name: sha(ROOT / name) for name in protected}
        targets = {
            'package/run_control.py': 'run_control.py',
            'package/resource_adaptation.json': 'resource_adaptation.json',
            'ops/id25_shared_train_runtime.py': 'id25_shared_train_runtime.py',
            'hpc/graice_shared_c01_20261019.slurm': 'graice_shared_c01_20261019.slurm',
        }
        backup = STAGE / 'original'
        backup.mkdir(exist_ok=False)
        for target in targets:
            path = ROOT / target
            if path.exists():
                dest = backup / target
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, dest)
        (STAGE / 'job_before.txt').write_text(before_raw + '\n')
        held = False
        files_changed = False
        scheduler_changed = False
        try:
            run('scontrol', 'hold', JOB)
            held = True
            _, current = job()
            if current.get('JobState') != 'PENDING':
                raise RuntimeError('Job started while obtaining hold; leave training intact')
            for target, source in targets.items():
                files_changed = True
                atomic(ROOT / target, (STAGE / source).read_bytes())
            for name, digest in policy['execution_files_sha256'].items():
                if sha(ROOT / 'package' / name) != digest:
                    raise RuntimeError('Adapted execution file hash differs: ' + name)
            if sha(ROOT / 'ops/id25_shared_train_runtime.py') != policy['runtime_sha256']:
                raise RuntimeError('Adapted runtime hash differs')
            scheduler_changed = True
            run('scontrol', 'update', 'JobId=' + JOB, 'ReqNodeList=', 'Partition=hgpu2p,hgpu2')
            _, current = job()
            if current.get('ReqNodeList') not in ('(null)', ''):
                raise RuntimeError('Fixed required node was not cleared')
            if set(current.get('Partition', '').split(',')) != {'hgpu2p', 'hgpu2'}:
                raise RuntimeError('Compatible partition list was not applied')
            if current.get('NumCPUs') != before.get('NumCPUs') or current.get('TresPerNode') != before.get('TresPerNode'):
                raise RuntimeError('CPU/GPU quantity changed unexpectedly')
            if current.get('SubmitTime') != before.get('SubmitTime') or current.get('TimeLimit') != before.get('TimeLimit'):
                raise RuntimeError('Original submission identity or time budget changed')
            if {name: sha(ROOT / name) for name in protected} != protected_hashes:
                raise RuntimeError('Original receipts or submission ledger changed')
        except BaseException as error:
            if scheduler_changed:
                run('scontrol', 'update', 'JobId=' + JOB, 'ReqNodeList=' + before['ReqNodeList'],
                    'Partition=' + before['Partition'])
            if files_changed:
                for target in targets:
                    saved = backup / target
                    if saved.exists():
                        atomic(ROOT / target, saved.read_bytes())
                    elif (ROOT / target).exists():
                        (ROOT / target).unlink()
            result_path.write_text(json.dumps(dict(state='ADAPTATION_FAILED_ROLLED_BACK',
                job_id=JOB, error=repr(error), no_cancellation=True, no_new_submission=True), indent=2) + '\n')
            raise
        finally:
            if held:
                run('scontrol', 'release', JOB)
        after_raw, after = job()
        (STAGE / 'job_after.txt').write_text(after_raw + '\n')
        result = dict(state='RESOURCE_COMPATIBILITY_APPLIED', job_id=JOB,
            original_submit_time=before['SubmitTime'], current_submit_time=after['SubmitTime'],
            original_required_node=before['ReqNodeList'], required_node=after.get('ReqNodeList'),
            partitions=after['Partition'], job_state=after['JobState'], reason=after.get('Reason'),
            gpus=1, cpus=4, original_receipts_and_submission_ledger_unchanged=True,
            base_fingerprint=policy['base_fingerprint'], execution_fingerprint=policy['execution_fingerprint'],
            no_cancellation=True, no_new_submission=True, model_preflight_repeated=False,
            other_jobs_modified=[], protected_hashes=protected_hashes)
        result_path.write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
