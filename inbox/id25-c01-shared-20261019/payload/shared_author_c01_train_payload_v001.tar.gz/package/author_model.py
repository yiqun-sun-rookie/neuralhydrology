"""Extracted from PalIre/GRAiCE 03_model_training.py lines 470-518.
Commit beef77f1583fdbb32bd761b64eeb153e079a2581.
Compatibility and input/mask patch only; see author_model_config.diff.
"""
import tensorflow
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Input, Masking, LSTM, Dense
from tensorflow.keras.optimizers import Adam

def model_config(hyppar, input_cols, pidx, model_type='LSTM', padding_value=-1e9):
    
    # Slurm device setup is performed once by the caller.
    model = Sequential()
    model.add(Input(shape=(hyppar.window, len(input_cols))))
    model.add(Masking(mask_value=padding_value, name='input_padding'))
    
    if model_type == "LSTM":
        ### LSTM model 
        model.add(LSTM(hyppar.units_in, name="author_lstm"))
    else:
        ### Bidirectional LSTM model 
        raise ValueError("This frozen adaptation uses the author unidirectional branch")
    
    if hyppar.units_lay1 > 0 and hyppar.units_lay2 == 0:
        model.add(Dense(hyppar.units_lay1, activation = "tanh"))
    elif hyppar.units_lay2 > 0:
        model.add(Dense(hyppar.units_lay1, activation = "tanh"))
        model.add(Dense(hyppar.units_lay2, activation = "tanh"))
    model.add(Dense(1, activation = None))

    """
    Configure the model for training:
        - optimized w/ the efficient Adam version of sthocastic gradient descent method;
        - mean absolute error (MAE) regression metric during training and testing;
        - mean squared error loss function.
    """
    
    opt = Adam(learning_rate = hyppar.l_rate)
    
    model.compile(loss = tensorflow.keras.losses.MeanSquaredError(),
                    optimizer = opt, 
                    metrics = [tensorflow.keras.metrics.MeanAbsoluteError()])
    
    # Show a summary of model
    model.summary()
        
    return model
