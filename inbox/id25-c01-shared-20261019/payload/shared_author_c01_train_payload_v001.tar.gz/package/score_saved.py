"""Fixed all-region acceptance metrics. Reads application targets only after selection is frozen."""
import argparse
import json
from pathlib import Path
import numpy as np
import shared_endpoint as c


def metrics(prediction, observation, fit_sd, month_reference):
    if prediction.shape != observation.shape or prediction.shape[0] != 24:
        raise ValueError('Exactly 24 paired application windows required')
    if not np.isfinite(prediction).all() or not np.isfinite(observation).all() or np.any(fit_sd<=0):
        raise ValueError('Invalid data/fit variance')
    errors=(prediction-observation)**2
    regional=np.sqrt(errors.mean(0))
    change=(prediction[12:]-prediction[:12])-(observation[12:]-observation[:12])
    reference_mse=float(np.mean((month_reference-observation)**2))
    return dict(pooled_rmse_cm=float(np.sqrt(errors.mean())),regional_median_rmse_cm=float(np.median(regional)),
                fit_sd_normalized_rmse=float(np.sqrt(np.mean(errors/fit_sd**2))),
                year_on_year_rmse_cm=float(np.sqrt(np.mean(change**2))),
                mse_skill_vs_fit_month_reference=1-float(errors.mean())/reference_mse if reference_mse else None,
                regional_rmse_cm=regional.tolist(),regional_year_on_year_mse=(change**2).mean(0).tolist())


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--run',type=Path,required=True);parser.add_argument('--source-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    selection=json.loads((args.run/'selection.json').read_text())
    status=json.loads((args.run/'status.json').read_text())
    if selection.get('state')!='FROZEN' or status.get('state')!='COMPLETED':raise ValueError('A completed frozen run is required')
    config=json.loads((Path(__file__).parent/'config.json').read_text())
    path=args.source_root/config['sources']['reference']
    if c.sha256(path)!=config['sources']['reference_sha256']:raise ValueError('Reference changed')
    with np.load(path,allow_pickle=False) as z:ref={k:z[k].copy() for k in z.files}
    with np.load(args.run/'predictions.npz',allow_pickle=False) as z:pred={k:z[k].copy() for k in z.files}
    np.testing.assert_array_equal(pred['support_ids'],ref['support_ids'])
    np.testing.assert_array_equal(pred['solution_ids'],ref['solution_ids'])
    if pred['application_anomaly_cm'].shape!=(24,119) or pred['fit_mask'].sum()!=66:raise ValueError('Cohort/split changed')
    fit=pred['fit_mask'].astype(bool);yfit=ref['observed_history_anomaly_cm'][fit].astype(float)
    months=np.array([int(s[-2:]) for s in pred['solution_ids'].astype(str)])
    history_months=months[:78][fit]
    reference=np.stack([yfit[history_months==m].mean(0) for m in months[-24:]])
    result=metrics(pred['application_anomaly_cm'],ref['observed_application_anomaly_cm'],yfit.std(0),reference)
    baseline=metrics(ref['rds_application_anomaly_cm'],ref['observed_application_anomaly_cm'],yfit.std(0),reference)
    b04root=args.source_root/'results/25_global_flood_hierarchy/regional_graice_author_matched_b04_20261016_001/retrieved_v001'
    with np.load(b04root/'predictions.npz',allow_pickle=False) as z:
        np.testing.assert_array_equal(z['support_ids'],pred['support_ids'])
        np.testing.assert_array_equal(z['solution_ids'],pred['solution_ids'])
        b04=metrics(z['application_anomaly_cm'],ref['observed_application_anomaly_cm'],yfit.std(0),reference)
    result['wins_vs_b04']=int(np.sum(np.array(result['regional_rmse_cm'])<b04['regional_rmse_cm']))
    result['wins_vs_rds01']=int(np.sum(np.array(result['regional_rmse_cm'])<baseline['regional_rmse_cm']))
    args.output.mkdir(parents=True,exist_ok=False)
    c.write_json(args.output/'acceptance_metrics.json',dict(state='SCORED',cohort=119,windows=24,development_only=True,
        C01=result,B04=b04,RDS01=baseline,decision='Report both level and change metrics; no automatic next experiment'))


if __name__=='__main__':main()
