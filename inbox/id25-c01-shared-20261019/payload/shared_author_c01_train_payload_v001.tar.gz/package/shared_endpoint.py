"""CPU-only contracts and data preparation for the shared author endpoint control."""
import hashlib
import json
from pathlib import Path

import numpy as np


def sha256(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(path, value):
    path = Path(path)
    pending = path.with_name(path.name + '.pending')
    pending.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
    pending.replace(path)


def epoch_batches(regions, fit_indices, batch_size, seed, epoch):
    fit_indices = np.asarray(fit_indices, dtype=int)
    if regions < 1 or batch_size < 1 or len(fit_indices) != len(set(fit_indices)) or not len(fit_indices):
        raise ValueError('Nonempty unique samples and positive dimensions required')
    # B04 used this same within-region permutation in all regions for each epoch.
    order = np.random.default_rng(np.random.SeedSequence([seed, epoch])).permutation(len(fit_indices))
    batches = [(r, fit_indices[order[start:start + batch_size]])
               for r in range(regions) for start in range(0, len(order), batch_size)]
    shuffle = np.random.default_rng(np.random.SeedSequence([seed, epoch, 119])).permutation(len(batches))
    return [batches[i] for i in shuffle]


def dynamic_inputs(forcing):
    z = np.asarray(forcing, dtype=np.float32)
    if z.shape[-1] != 6 or not np.isfinite(z).all():
        raise ValueError('Six finite source columns required')
    return np.stack([z[..., 0], .5 * (z[..., 3] + z[..., 4]), z[..., 1], z[..., 5]], axis=-1)


def features(dynamic, static, scaler, sentinel):
    scale = np.asarray(scaler['x_scale'])
    if np.any(scale <= 0) or not np.isfinite(scale).all():
        raise ValueError('Invalid saved dynamic scales')
    normalized = (np.asarray(dynamic) - np.asarray(scaler['x_center'])) / scale
    x = np.concatenate([normalized, np.broadcast_to(static, (len(dynamic), 7))], axis=1).astype(np.float32)
    if x.shape[1] != 11 or not np.isfinite(x).all() or np.any(np.all(x == np.float32(sentinel), axis=1)):
        raise ValueError('Invalid features or padding collision')
    return x


def target_scale(y, scaler):
    if scaler['y_scale'] <= 0:
        raise ValueError('Invalid target scale')
    return ((np.asarray(y) - scaler['observation_reference_cm'] - scaler['y_center']) / scaler['y_scale']).astype(np.float32)


def target_inverse(y, scaler):
    # Like B04: this returns anomaly relative to y_ref; do not add y_ref again.
    return np.asarray(y, dtype=np.float64).reshape(-1) * scaler['y_scale'] + scaler['y_center']


def prefix_lengths(weights):
    if weights.ndim != 2 or not np.isfinite(weights).all() or np.any(weights < 0):
        raise ValueError('Invalid weights')
    if not np.allclose(weights.sum(1), 1, atol=1e-6):
        raise ValueError('Incomplete window support')
    ends = np.array([np.flatnonzero(row > 0)[-1] + 1 for row in weights], dtype=int)
    if len(ends) != len(set(ends)):
        raise ValueError('Duplicate endpoints cannot represent distinct target supports')
    return ends


def pad_prefixes(x, lengths, sentinel):
    lengths = np.asarray(lengths, dtype=int)
    if not len(lengths) or lengths.min() <= 0 or lengths.max() > len(x):
        raise ValueError('Invalid prefix length')
    batch = np.full((len(lengths), int(lengths.max()), 11), np.float32(sentinel), dtype=np.float32)
    for i, end in enumerate(lengths):
        batch[i, :end] = x[:end]
    return batch


def selection_score(raw, targets, fit, y_ref):
    raw = np.asarray(raw, dtype=float)
    if raw.shape != targets.shape or not np.isfinite(raw).all() or not np.isfinite(targets).all():
        raise ValueError('Finite complete prediction and target matrices required')
    fit = np.asarray(fit, dtype=bool)
    if not fit.any() or fit.all():
        raise ValueError('Both fit and selection windows required')
    pref = raw[fit].mean(0)
    centered = raw - pref
    mse = float(np.mean((centered[~fit] - (targets[~fit] - y_ref))**2))
    return mse, pref, centered


def save_checkpoint(path, metadata, arrays):
    path = Path(path)
    pending = path.with_name(path.name + '.pending')
    with pending.open('wb') as stream:
        np.savez_compressed(stream, metadata=np.array(json.dumps(metadata, allow_nan=False)), **arrays)
    pending.replace(path)


def load_checkpoint(path, fingerprint):
    with np.load(path, allow_pickle=False) as data:
        meta = json.loads(str(data['metadata']))
        if meta['fingerprint'] != fingerprint:
            raise ValueError('Checkpoint fingerprint differs')
        return meta, {key: data[key].copy() for key in data.files if key != 'metadata'}


def require_gpu_permission(approval, mode):
    key = {'preflight': 'preflight_gpu_authorized', 'train': 'full_training_authorized'}[mode]
    if approval.get(key) is not True:
        raise PermissionError('GPU action is not authorized: ' + mode)
    if not (approval.get('gpu_reserved_exclusively') is True and approval.get('other_gpu_experiments_stopped') is True):
        raise PermissionError('Explicit exclusive reservation and no competing GPU experiment required')


def epoch_seconds_bound(regions, timings, save_seconds):
    return regions * (2 * timings['train32'] + timings['train2'] + 2 * timings['infer32'] +
                      timings['infer2'] + timings['infer12'] + 3 * save_seconds)


def prepare(source_root, config):
    """Open history/scalers only. Never opens application inputs or reference targets."""
    root = Path(source_root)
    history = root / config['sources']['history']
    if sha256(history) != config['sources']['history_sha256']:
        raise ValueError('History fingerprint changed')
    with np.load(history, allow_pickle=False) as z:
        data = {k: z[k].copy() for k in z.files}
    ids = data['support_ids'].astype(str)
    fit = data['fit_mask'].astype(bool)
    days = data['dates'].astype('datetime64[D]')
    if len(ids) != len(set(ids)) or len(ids) != 119 or fit.sum() != 66 or (~fit).sum() != 12:
        raise ValueError('Frozen region/window split differs')
    if str(days[0]) != '1998-08-01' or str(days[-1]) != '2008-12-31' or np.any(np.diff(days).astype(int) != 1):
        raise ValueError('Historical daily calendar changed')
    if data['targets_cm'].shape != (78,119) or not np.isfinite(data['targets_cm']).all():
        raise ValueError('Historical labels incomplete')
    lengths = prefix_lengths(data['sampling_weights'])
    if np.any(days[lengths[fit]-1] >= np.datetime64('2008-01-01')) or np.any(days[lengths[~fit]-1] < np.datetime64('2008-01-01')):
        raise ValueError('Observation cutoff crosses split')
    dynamic = dynamic_inputs(data['forcing'])
    if dynamic.shape != (3806,119,4) or data['static_features'].shape != (119,7):
        raise ValueError('Predictor shape changed')
    scaler_manifest = json.loads((Path(__file__).parent/'scaler_manifest.json').read_text())
    scalers, prepared = [], []
    for j, rid in enumerate(ids):
        path = root/config['sources']['scalers']/rid/'scalers.json'
        if sha256(path) != scaler_manifest[rid]:
            raise ValueError('Frozen scaler differs: '+rid)
        sc = json.loads(path.read_text())
        if sc['fit_sample_count'] != 66 or sc['x_fit_unique_days'] != 2191:
            raise ValueError('Scaler fit period differs')
        scalers.append(sc)
        prepared.append(features(dynamic[:,j],data['static_features'][j],sc,config['padding_value']))
        np.testing.assert_allclose(target_inverse(target_scale(data['targets_cm'][fit,j],sc),sc),
                                   data['targets_cm'][fit,j]-sc['observation_reference_cm'],atol=1e-5)
    data.update(ids=ids,fit=fit,lengths=lengths,features=prepared,scalers=scalers)
    data['scaled_targets'] = np.stack([target_scale(data['targets_cm'][:,j],sc) for j,sc in enumerate(scalers)],axis=1)
    data['y_ref'] = np.array([sc['observation_reference_cm'] for sc in scalers])
    return data
