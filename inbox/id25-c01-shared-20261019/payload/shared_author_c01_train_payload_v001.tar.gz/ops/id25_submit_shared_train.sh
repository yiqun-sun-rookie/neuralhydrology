#!/bin/bash
set -euo pipefail
root=/data1/home/sunyiq/id25_graice_shared_c01_20261019_001
mode=${1:-initial}
case "$mode" in initial|resume) ;; *) echo INVALID_SUBMISSION_MODE; exit 1;; esac
exec 9>"$root/submission.lock"
flock -n 9 || { echo SUBMISSION_LOCKED; exit 70; }
queue=$(timeout 30 squeue -h -u sunyiq -n id25_c01_shared_261019 -o '%i|%j|%T')
if test -n "$queue"; then printf '%s\n' "$queue"; echo EXISTING_ACTIVE_JOB_NO_SUBMISSION; exit 71; fi
if test "$mode" = initial; then
    test ! -e "$root/job_id.txt"
    test ! -e "$root/submission_intent_initial.json"
    history=$(timeout 30 sacct -X -S 2026-10-18 -u sunyiq --name=id25_c01_shared_261019 --format=JobIDRaw,JobName%32,State,ExitCode -n -P)
    if test -n "$history"; then printf '%s\n' "$history"; echo EXISTING_JOB_HISTORY_NO_INITIAL_SUBMISSION; exit 72; fi
    tag=initial
else
    previous=$(tr -d '\r\n' < "$root/job_id.txt")
    case "$previous" in ''|*[!0-9]*) echo INVALID_PREVIOUS_JOB; exit 73;; esac
    previous_state=$(timeout 30 sacct -X -S 2026-10-18 -j "$previous" --format=JobIDRaw,State -n -P | awk -F'|' -v j="$previous" '$1==j {print $2}')
    case "$previous_state" in FAILED|TIMEOUT|OUT_OF_MEMORY|NODE_FAIL|PREEMPTED|BOOT_FAIL|DEADLINE|COMPLETED|CANCELLED*) ;; *) echo "PREVIOUS_STATE_NOT_TERMINAL=$previous_state"; exit 74;; esac
    if test ! -f "$root/output/last.npz" && compgen -G "$root/output/epochs/*.json" > /dev/null; then
        echo CHECKPOINT_MISSING_AFTER_UPDATES_NO_RESET; exit 75
    fi
    if test -f "$root/report.json"; then echo RESULTS_ALREADY_READY_NO_TRAINING_RESUBMISSION; exit 76; fi
    tag="resume_after_$previous"
    test ! -e "$root/submission_intent_$tag.json"
fi
intent="$root/submission_intent_$tag.json"
printf '{"mode":"%s","job_name":"id25_c01_shared_261019","created_utc":"%s"}\n' "$mode" "$(date -u +%FT%TZ)" > "$intent"
set +e
sbatch --parsable "$root/hpc/graice_shared_c01_20261019.slurm" > "$root/sbatch_${tag}_reply.txt" 2> "$root/sbatch_${tag}_error.txt"
rc=$?
set -e
cat "$root/sbatch_${tag}_reply.txt"
cat "$root/sbatch_${tag}_error.txt"
if test "$rc" -ne 0; then echo "SBATCH_EXIT=$rc; intent preserved, reconcile before retry"; exit "$rc"; fi
job_id=$(cut -d';' -f1 "$root/sbatch_${tag}_reply.txt" | tr -d '\r\n')
case "$job_id" in ''|*[!0-9]*) echo AMBIGUOUS_SBATCH_REPLY_NO_REPLAY; exit 77;; esac
printf '%s\n' "$job_id" > "$root/job_id.txt.pending"
mv "$root/job_id.txt.pending" "$root/job_id.txt"
printf '%s\t%s\t%s\n' "$(date -u +%FT%TZ)" "$job_id" "$tag" >> "$root/submissions.tsv"
printf 'JOB_ID=%s\n' "$job_id"
timeout 30 squeue -j "$job_id" -o '%i|%j|%T|%R'
