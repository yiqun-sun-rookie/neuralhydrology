区域水文＋TWS B04：监督边界定点复核（2026-10-18）

**结论：原唯一P1阻断已闭合，无新增阻断。** 本次仅复核监督差异和指定8项无GPU回归，不重新审核科学合同。结论适用于代码指纹 `1622a60017558c111defebde26a62007a61bb9db320a7dc12c1df12dc7d5e612`。

- 孤立 `--_worker` 在GPU门禁前须通过继承管道、父子PID、会话标记、锁、模式、指纹和期限核验；原直接入口绕过监督的问题已修复。见 [run_control.py:92](C:/Users/yiqun/Documents/Codex/2026-10-18/task-5/regional_b04_control_20261018_v001/run_control.py:92)、[main:438](C:/Users/yiqun/Documents/Codex/2026-10-18/task-5/regional_b04_control_20261018_v001/run_control.py:438)。
- Linux父死亡联动在设置前后核验父PID，worker另设同一截止时间的默认终止闹钟。父监督超时/中断/异常均回收自身Popen子进程，确认退出后才释放锁；未确认时保留锁并记录 `CLEANUP_UNCONFIRMED`。见 [父死亡设置](C:/Users/yiqun/Documents/Codex/2026-10-18/task-5/regional_b04_control_20261018_v001/run_control.py:81)、[回收与监督](C:/Users/yiqun/Documents/Codex/2026-10-18/task-5/regional_b04_control_20261018_v001/run_control.py:136)。未发现会按进程名称或GPU占用清理其他实验的路径。
- 在task-9解压副本独立重跑 `tests/test_supervision_boundary.py` 和 `tests/test_entrypoint.py`：**8 passed，0失败、0跳过**。仅使用CPU替身；未执行真实Linux prctl/闹钟、GPU探针或训练，未将这些回归表述为Linux/GPU实测通过。
- 所给diff与v001→v002实际差异完全一致。AST比较确认原有函数仅 `main` 改动、`local_lock` 被替换；科学函数未变，作者模型、冻结配置、缩放/计分代码及授权文件散列未变。新CPU回执和包清单均匹配上述指纹。

实际证据：[独立回归XML](C:/Users/yiqun/Documents/Codex/2026-10-18/task-9/supervision_review_v002.xml)、[指纹/差异/回收回执核验JSON](C:/Users/yiqun/Documents/Codex/2026-10-18/task-9/supervision_fix_review_evidence_v002.json)、[核验脚本](C:/Users/yiqun/Documents/Codex/2026-10-18/task-9/verify_supervision_fix_v002.py)。本次v002 ZIP的SHA256为 `88007c35f67539798ae09444858aed558fa706e1e74e36b57177256561b1a7cd`。

此结论仅闭合代码审核阻断。兼容TF运行环境、动态降水实验结束后的独占时段及单独GPU预检授权仍须落实；本次未调查或解决环境、安装软件、修改授权或原包、运行GPU、提交HPC。
