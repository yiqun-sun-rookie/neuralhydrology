"""One initialization-only comparison: independent arms, no gradient or optimizer step."""
import os, sys, io, json, hashlib, time, datetime, traceback
from pathlib import Path


def main():
    base = Path(__file__).resolve().parent
    import safe_io as s
    assert os.environ.get('SLURM_JOB_ID', '').isdigit()
    assert json.loads(sys.stdin.readline())['resources_configured']
    raw_plan = s.read_checked(base/'probe_contract.json'); plan = json.loads(raw_plan)
    auth = json.loads(s.read_checked(base/'execution_authorization.json'))
    assert auth['status']=='AUTHORIZED' and plan['optimizer_calls_per_arm']==0 and plan['basins'][0]['basin']=='04105700'
    for row in auth['files']: s.read_checked(base/row['path'], row['sha256'])
    template = base.parents[1]/'template'
    manifest = json.loads(s.read_checked(template/'bundle_manifest.json', auth['template_manifest_sha256']))
    for row in manifest['files']: s.read_checked(template/row['path'], row['sha256'])
    import numpy as np
    import torch
    import random
    from baseline_reducer import proxy_score, compare_baselines
    from evidence_writer import EvidenceWriter
    torch.set_num_threads(1); torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    random.seed(plan['seed']); np.random.seed(plan['seed']); torch.manual_seed(plan['seed'])
    basin = os.environ['HPC_BASIN']; conf = next(x for x in plan['basins'] if x['basin']==basin)
    assert basin=='04105700'
    coordinate = conf['output_row']; out = sys.argv[1]; began = time.monotonic()
    os.chdir(template); sys.path.insert(0,str(template/'recipe')); os.environ['KNET_BASIN']='04105700'
    import common as C
    from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
    from global_hydrology.experiments import daily_camels_ukf_knet_parity_runner as parity
    from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
    from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import AccessLedger, CAUSAL_SHARED_SPINUP_MODE
    def arr(x): return x.detach().cpu().numpy().copy()
    def plain(v):
        if isinstance(v,dict): return {str(k):plain(x) for k,x in v.items()}
        if isinstance(v,(list,tuple)): return [plain(x) for x in v]
        if isinstance(v,np.ndarray): return v.tolist()
        if isinstance(v,np.generic): return v.item()
        return v
    def put(name,value): return s.create(out+'/'+name,value if isinstance(value,bytes) else plain(value))
    def np_save(name,value):
        stream=io.BytesIO();np.savez_compressed(stream,**value);return put(name,stream.getvalue())
    def pt_save(name,value):
        stream=io.BytesIO();torch.save(value,stream);return put(name,stream.getvalue())
    def load_np(name):
        with np.load(io.BytesIO(s.read_checked(base/'inputs'/basin/name)),allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
    def emit(event,**values):
        entry=dict(event=event,basin=basin,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-began)
        entry.update(plain(values));print(json.dumps(entry,allow_nan=False),flush=True)
    digest=C.helpers.digest_tree
    cp=torch.load(io.BytesIO(s.read_checked(base/'inputs'/basin/'initial.pt',conf['initial_checkpoint_sha256'])),weights_only=True,map_location='cpu')
    assert cp['epoch']==cp['optimizer_steps']==0 and not cp['optimizer']['state']
    assert cp['seed']==plan['seed']
    runtime=per.load_per_basin_development_runtime(get_development_basin_specification(basin),ledger=AccessLedger(),initialization_mode=CAUSAL_SHARED_SPINUP_MODE,device='cpu')
    assert runtime.training_days==2557 and len(runtime.dates)==3288
    states=parity.training_open_loop_states(runtime)
    scales=parity.fit_training_feature_scales(runtime,floor=.1)
    per.fit_training_feature_scales=lambda r,*,floor=.1:scales
    advance=parity._advance_open_loop
    parity._advance_open_loop=lambda context,forcing,*,end_exclusive:states[-1].clone() if context is runtime.context and end_exclusive==2557 else advance(context,forcing,end_exclusive=end_exclusive)
    window=parity.select_window(runtime,'recovery');TT=float(runtime.context.plain_model.params['parTT'])
    observations=arr(runtime.observations).reshape(-1);forcing=arr(runtime.forcing)
    dates=runtime.dates.astype('datetime64[ns]').astype('int64');issues=np.arange(2557,3285)
    targets=observations[issues[:,None]+np.arange(1,4)]
    thresholds=np.quantile(observations[:2557],[.5,.9,.99],method='linear')
    ref=load_np('reference.npz' if basin=='02092500' else 'main.npz')
    assert np.array_equal(targets,ref['target']) and np.array_equal(issues,ref['issue_indices'])
    assert np.array_equal(dates[issues[:,None]+np.arange(1,4)],ref['target_dates_ns'])
    np_save('input_snapshot.npz',dict(observations=observations,forcing=forcing,dates_ns=dates,thresholds=thresholds,training_open_loop=arr(states),initial_validation_state=arr(window.initial_state)))
    def groups(y):return [np.ones(y.shape,dtype=bool),y<=thresholds[0],(y>thresholds[0])&(y<=thresholds[1]),y>thresholds[1]]
    training_counts=sum((np.array([m.sum() for m in groups(observations[start+np.arange(695,797)[:,None]+np.arange(1,4)])]) for start in plan['base_starts']),start=np.zeros(4,dtype=np.int64))
    assert training_counts[0]==7650 and np.all(training_counts>0)
    arms={};initial_hashes={};initial_snapshots={}
    for arm in plan['arms']:
        net=per.build_exact_dimension_kalman_net(runtime,zero_gain=False,seed=plan['seed'],gain_initialization='near_zero_fc2_head',hidden=24,input_multiplier=10,output_multiplier=10,feature_scale_floor=.1,normalized_feature_guard=10.,correction_cap_in_state_scale_units=3.)
        net.load_state_dict(cp['network'],strict=True)
        assert parity.parameter_sha256(net)==conf['initial_parameter_sha256']
        for p in net.parameters():p.requires_grad_(True)
        params=list(net.parameters());names=[n for n,p in net.named_parameters()]
        opt=torch.optim.Adam(params,lr=.0005,weight_decay=0.,betas=(.9,.999),eps=1e-8)
        opt.load_state_dict(cp['optimizer']);assert not opt.state
        state=dict(arm=arm,net=net,parameters=params,names=names,optimizer=opt,calls=0,effective=0,history=[],rng=cp['torch_rng_state'].clone(),trace=None,count=0,step=0,phase='initialization')
        native=net.analysis_step
        def wrapped(native,net,state):
            def update(y,u):
                previous=net.m1x_posterior;post=native(y,u);i=state['count'];state['count']+=1
                if state.get('phase')=='validation' and (state['count']%100==0 or state['count']==731):
                    emit('validation_day_progress',arm=state['arm'],step=0,days=state['count'],total=731,optimizer_calls=0,effective_nonzero_steps=0)
                if i==650:
                    state['boundary']={k:bool(getattr(net,k).grad_fn is not None) for k in C.probe.RECURRENCE_FIELDS}
                if state['trace'] is not None and i>=state['record_after']:
                    state['trace'].append(dict(prior=net.m1x_prior,posterior=post,previous=previous,requested=net.last_correction,prior_flow=net.m1y.reshape(())))
                return post
            return update
        net.analysis_step=wrapped(native,net,state)
        snapshots=[]
        for start in [*plan['base_starts'],2557]:
            initial=runtime.context.initial_state.clone() if start==0 else states[start-1].clone()
            previous=None if start==0 else runtime.observations[start-1:start].clone()
            net.initialize_filter(initial,731 if start==2557 else 800,previous_observation=previous)
            snapshots.append({k:digest(getattr(net,k)) for k in C.probe.RECURRENCE_FIELDS})
        initial_snapshots[arm]=snapshots
        initial_hashes[arm]=dict(network=digest(net.state_dict()),optimizer=digest(opt.state_dict()),rng=digest(state['rng']))
        arms[arm]=state
    assert initial_hashes['original']==initial_hashes['state_constrained']
    assert initial_snapshots['original']==initial_snapshots['state_constrained']
    put('initialization_gate.json',dict(status='PASS',checkpoint_epoch=0,hashes=initial_hashes,initial_snapshots=initial_snapshots,trainable_names=names,trainable_parameter_count=sum(p.numel() for p in params),all_network_parameters_trainable=True))
    def state_mask(trace,start):
        previous=np.stack([arr(r['previous']).reshape(-1) for r in trace]);prior=np.stack([arr(r['prior']).reshape(-1) for r in trace]);ix=np.arange(start,start+len(trace))
        if coordinate==0:return (forcing[ix,0,1]>=TT)&(prior[:,0]<=0)
        return (forcing[ix,0,0]==0)&(previous[:,0]<=0)&(previous[:,1]<=0)&(observations[ix]<=thresholds[0])&(observations[ix]<=observations[ix-1])
    def state_values(trace,start,state):
        if coordinate==0:
            values=torch.stack([torch.relu((r['posterior']-r['prior'])[0,0]) for r in trace]);scale=float(state['net'].state_feature_scale[0,0])
        else:
            pf=torch.stack([r['prior_flow'] for r in trace]);values=torch.relu(pf-torch.as_tensor(observations[start:start+len(trace)],dtype=pf.dtype));scale=float(state['net'].observation_feature_scale.reshape(()))
        return values/scale
    masks={};state_count=0;validation_mask=None
    def training(state,freeze_masks=False):
        nonlocal state_count
        state['phase']='training';emit('phase_start',arm=state['arm'],phase='training',optimizer_calls=0,effective_nonzero_steps=0)
        net=state['net'];net.train();scores=np.zeros(9);predictions=[];proxy=[]
        for number,start in enumerate(plan['base_starts']):
            initial=runtime.context.initial_state.clone() if start==0 else states[start-1].clone()
            context=parity._context_with_initial_state(runtime.context,initial)
            batch=parity.WindowBatch(purpose='training_segment',global_start=start,global_end_exclusive=start+800,context=context,forcing=runtime.forcing[start:start+800],observations=runtime.observations[start:start+800],dates=runtime.dates[start:start+800],initial_state=initial,issue_start_local=695,issue_end_local=797)
            state['trace']=[];state['count']=0;state['record_after']=650
            with torch.no_grad():
                filtered=parity.run_knet_filter(net,batch,previous_observation=parity.previous_observation_before_window(runtime,batch))
                assert state['count']==800 and len(state['trace'])==150
                raw=runtime.tukf06_module.multilead_torch(batch.context.plain_model,filtered.posterior_states[:,0,:],batch.forcing)
                pred=torch.stack([raw[k][0][695:797] for k in (1,2,3)],dim=1)
                y=runtime.observations[start+torch.arange(695,797)[:,None]+torch.arange(1,4),0];error=pred-y;losses=[]
                for group,denom in zip(groups(arr(y)),training_counts):
                    selected=error[torch.as_tensor(group)];losses.extend([selected.square().sum()/int(denom),selected.abs().sum()/int(denom)])
                scores[:8]+=np.array([float(x.detach()) for x in losses])
                if freeze_masks:masks[start]=state_mask(state['trace'],start+650);state_count+=int(masks[start].sum())
                values=state_values(state['trace'],start+650,state)
                predictions.append(arr(pred));proxy.append(arr(values))
            state['trace']=None
            emit('training_segment_progress',arm=state['arm'],step=0,label='initialization',segments=number+1,total=25,gradient=False,optimizer_calls=0,effective_nonzero_steps=0)
        assert state_count>0
        mask=np.stack([masks[x] for x in plan['base_starts']]);values=np.stack(proxy)
        scores[8]=proxy_score(values,mask)
        assert np.isfinite(scores).all()
        return scores,dict(prediction=np.stack(predictions),state_proxy_values=values,state_mask=mask,scores=scores)
    def validation(state,freeze_mask=False):
        nonlocal validation_mask
        state['phase']='validation';emit('phase_start',arm=state['arm'],phase='validation',optimizer_calls=0,effective_nonzero_steps=0)
        net=state['net'];net.eval();state['trace']=[];state['count']=0;state['record_after']=0
        with torch.no_grad():
            trace=parity.run_knet_filter(net,window,previous_observation=parity.previous_observation_before_window(runtime,window))
            fc=parity.aligned_forecasts_from_posterior(runtime,window,trace.posterior_states)
            pairs=parity.forecast_pairs(window.observations,fc,issue_start=0,issue_end=728,leads=(1,2,3))
            pred=np.stack([pairs.predictions[k] for k in (1,2,3)],axis=1)
            if freeze_mask:validation_mask=state_mask(state['trace'],2557)
            assert validation_mask is not None and validation_mask.any()
            values=arr(state_values(state['trace'],2557,state))
            scores=[];e=pred-targets
            for mask in groups(targets):scores.extend([float(np.mean(e[mask]**2)),float(np.mean(np.abs(e[mask])))])
            scores.append(proxy_score(values,validation_mask))
            data={k:np.stack([arr(row[k]).reshape(-1) for row in state['trace']]) for k in state['trace'][0]}
        data.update(prediction=pred,target=targets,issue_indices=issues,target_dates_ns=dates[issues[:,None]+np.arange(1,4)],state_mask=validation_mask,state_proxy_values=values,scores=np.array(scores))
        state['trace']=None
        assert np.isfinite(pred).all() and np.isfinite(scores).all()
        return np.array(scores),data
    def checkpoint(state):
        return dict(basin=basin,arm=state['arm'],optimizer_calls=state['calls'],effective_nonzero_steps=state['effective'],network={k:v.detach().cpu().clone() for k,v in state['net'].state_dict().items()},optimizer=state['optimizer'].state_dict(),torch_rng_state=state['rng'].clone(),parameter_sha256=parity.parameter_sha256(state['net']),contract_sha256=hashlib.sha256(raw_plan).hexdigest(),initial_parameter_sha256=conf['initial_parameter_sha256'])
    records={};saved={};identities={};active_arm=None
    try:
        for arm,state in arms.items():
            active_arm=arm;torch.set_rng_state(state['rng']);state['phase']='initialization_baseline'
            identity=dict(initial=initial_hashes[arm],history=initial_snapshots[arm],checkpoint_sha256=conf['initial_checkpoint_sha256'])
            identities[arm]=identity
            # Both arms' state and raw outputs survive any subsequent comparison failure.
            files=[pt_save(arm+'/state_before_000.pt',checkpoint(state))]
            train,data=training(state,freeze_masks=arm=='original')
            files.append(np_save(arm+'/training_000.npz',data))
            emit('phase_complete',arm=arm,phase='training',segments=25,optimizer_calls=0,effective_nonzero_steps=0)
            val,vd=validation(state,freeze_mask=arm=='original')
            files.append(np_save(arm+'/validation_000.npz',vd))
            emit('phase_complete',arm=arm,phase='validation',days=731,optimizer_calls=0,effective_nonzero_steps=0)
            files.append(pt_save(arm+'/checkpoint_000.pt',checkpoint(state)))
            assert digest(state['net'].state_dict())==initial_hashes[arm]['network']
            assert digest(state['optimizer'].state_dict())==initial_hashes[arm]['optimizer'] and not state['optimizer'].state
            assert parity.parameter_sha256(state['net'])==conf['initial_parameter_sha256']
            assert digest(torch.get_rng_state())==digest(state['rng']),'Baseline consumed stochastic RNG'
            writer=EvidenceWriter(out+'/'+arm)
            commit=writer.commit(0,files,dict(optimizer_calls=0,effective_nonzero_steps=0))
            saved[arm]=dict(training=data,validation=vd)
            records[arm]=dict(optimizer_calls=0,effective_nonzero_steps=0,training_scores=train.tolist(),validation_scores=val.tolist(),commit=commit)
        # Freeze and persist masks before comparing the independent trajectories.
        np_save('fixed_training_masks.npz',{str(k):v for k,v in masks.items()})
        np_save('fixed_validation_mask.npz',dict(mask=validation_mask))
        report={mode:compare_baselines(saved['original'][mode],saved['state_constrained'][mode],identities['original'],identities['state_constrained']) for mode in ('training','validation')}
        put('comparison.json',dict(status='PASS',arrays=report,identities=identities,training_mask_events=state_count,validation_mask_events=int(validation_mask.sum()),no_copied_constrained_trajectory=True))
        result=dict(status='INITIALIZATION_ONLY_PASS',experiment_id=base.name,basin=basin,arms=records,total_optimizer_calls=0,total_effective_nonzero_steps=0,backward_calls=0,qp_solves=0,model_scope='two independent untrained baseline trajectories only',elapsed_seconds=time.monotonic()-began)
        put('result.json',result);emit('initialization_only_complete',**result)
    except BaseException as error:
        failure=dict(status='FAILED',type=type(error).__name__,message=str(error),traceback=traceback.format_exc(),arm=active_arm,records=records,total_optimizer_calls=0,total_effective_nonzero_steps=0)
        put('failure.json',failure);put('result.json',failure);raise

if __name__=='__main__':main()
