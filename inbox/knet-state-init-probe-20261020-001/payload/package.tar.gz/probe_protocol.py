"""Pure scheduling and observation rules; no model or network imports."""
import re

MEMORY_ENV = ('SBATCH_MEM_PER_NODE', 'SBATCH_MEM_PER_CPU', 'SBATCH_MEM_PER_GPU')
TERMINAL = {'COMPLETED','FAILED','TIMEOUT','CANCELLED','OUT_OF_MEMORY','NODE_FAIL','PREEMPTED','BOOT_FAIL','DEADLINE','REVOKED'}

def submission_env(source):
    return {k:v for k,v in source.items() if k not in MEMORY_ENV}

def duration(value):
    match=re.fullmatch(r'(?:(\d+)-)?(\d+):(\d+):(\d+)',value)
    if not match: raise ValueError('Missing scheduler duration: '+value)
    d,h,m,s=(int(x or 0) for x in match.groups())
    return d*86400+h*3600+m*60+s

def progress_key(event):
    if event.get('event')=='training_segment_progress':return (event['arm'],'training',event['segments'])
    if event.get('event')=='validation_day_progress':return (event['arm'],'validation',event['days'])
    if event.get('event')=='phase_complete':return (event['arm'],event['phase'],event.get('segments',event.get('days')))
    return None

def assess(row, upper):
    if row['terminal']:return dict(status='TERMINAL_READY_FOR_COLLECTION',healthy=False)
    if row.get('progress_regressions'):return dict(status='MONITOR_FAILED',healthy=False,reason='Progress counter regressed')
    fields=row['scheduler_fields'];state=fields.get('JobState')
    if state=='PENDING' and fields.get('Reason') in ('Priority','Resources','JobArrayTaskLimit'):
        return dict(status='VERIFIED_QUEUED' if upper<=600 else 'MONITOR_FAILED',healthy=upper<=600)
    if state!='RUNNING':return dict(status='MONITOR_FAILED',healthy=False,reason='Unknown scheduler state')
    c,w=row.get('controller'),row.get('worker');res=row.get('latest_resource');stat=row.get('resource')
    identity=bool(c and w and c['job_id']==w['job_id']==row['job_id'] and c['node']==w['node']==fields.get('NodeList') and c['worker_pid']==w['pid'] and c['contract_sha256']==w['contract_sha256']==row['contract_sha256'] and fields.get('Command')==row['script_path'] and fields.get('WorkDir')==row['remote_root'])
    identity=identity and bool(stat and stat['returncode']==0 and stat['stdout'].strip())
    if not identity or not res:return dict(status='MONITOR_FAILED',healthy=False,reason='Identity or resource evidence missing')
    clock_upper=duration(fields['RunTime'])+row['control_rpc_seconds']+1
    sample_age=clock_upper-res['allocation_elapsed_lower_seconds']
    resource_ok=0<=sample_age and upper+sample_age<=600 and res['combined_rss_bytes']<=6442450944 and res['free_bytes']>=2147483648
    event=row.get('latest_progress')
    age=None if not event else clock_upper-event['allocation_elapsed_lower_seconds']
    startup=not event and clock_upper<=120
    healthy=bool(resource_ok and upper<=600 and (startup or age is not None and age>=0 and upper+age<=600))
    return dict(status='VERIFIED_INITIALIZING' if healthy else 'MONITOR_FAILED',healthy=healthy,progress_age_upper_seconds=age,resource_age_upper_seconds=sample_age,startup_transition=startup,identity_verified=identity)
