"""Read only the owned job and progress; file export is a separate command."""
import sys,json,datetime,subprocess,re,time,socket,hashlib
from pathlib import Path
import safe_io as s
from probe_protocol import TERMINAL,progress_key
BASE=Path(__file__).resolve().parent
def command(args):
    try:
        p=subprocess.run(args,capture_output=True,text=True,timeout=15);return dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
    except subprocess.TimeoutExpired:return dict(returncode=124,stdout='',stderr='scheduler timeout')
def load(path):return json.loads(s.read_checked(path)) if path.is_file() else None
def query(job):
    identity=load(BASE/'submission.json');assert identity and identity['job_id']==job and identity['remote_root']==str(BASE)
    queue=command(['squeue','-j',job,'-h','-o','%i|%j|%T|%M|%R']);q0=time.monotonic();control=command(['scontrol','-o','show','job',job]);rpc=time.monotonic()-q0
    fields=dict(re.findall(r'(\w+)=([^\s]+)',control['stdout']))
    supported=command(['sacct','--helpformat']);wanted=['JobID','State','ExitCode','ElapsedRaw','AllocCPUS','NodeList','Start','End','WorkDir','ReqMem']
    assert supported['returncode']==0 and all(x in supported['stdout'].split() for x in wanted)
    acct=command(['sacct','-j',job,'--noheader','--parsable2','--format='+','.join(wanted)])
    rows=[dict(zip(wanted,line.split('|'))) for line in acct['stdout'].splitlines() if line];own=[r for r in rows if r['JobID']==job]
    terminal=bool(own and own[0]['State'].split()[0].rstrip('+') in TERMINAL)
    folder=BASE/'runs/04105700/attempt_001';log=BASE/'logs'/('probe-'+job+'.out');events=[]
    if log.exists():
        for line in s.read_checked(log).decode(errors='replace').splitlines():
            try:record=json.loads(line)
            except ValueError:continue
            if isinstance(record,dict) and 'event' in record:events.append(record)
    latest={};last=None;regressions=[]
    for event in events:
        key=progress_key(event)
        if key:
            pair=key[:2]
            if pair in latest and key[2]<progress_key(latest[pair])[2]:regressions.append(event)
            if pair not in latest or key[2]>progress_key(latest[pair])[2]:latest[pair]=event;last=event
    resources=[e for e in events if e['event']=='resource_sample']
    stat=command(['sstat','-j',job+'.batch','--noheader','--parsable2','--format=JobID,AveCPU,MaxRSS']) if fields.get('JobState')=='RUNNING' else None
    return dict(job_id=job,identity=identity,remote_root=str(BASE),script_path=str(BASE/'probe.slurm'),contract_sha256=hashlib.sha256(s.read_checked(BASE/'probe_contract.json')).hexdigest(),queried_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),query_host=socket.gethostname(),queue=queue,scontrol=control,control_rpc_seconds=rpc,scheduler_fields=fields,accounting=acct,accounting_fields=wanted,native_job_row=own,terminal=terminal,controller=load(folder/'controller_started.json'),worker=load(folder/'scientific_started.json'),receipt=load(folder/'receipt.json'),result=load(folder/'result.json'),latest_progress=last,progress_by_phase=list(latest.values()),progress_regressions=regressions,latest_resource=resources[-1] if resources else None,resource=stat)
if __name__=='__main__':print('PROBE_STATUS_JSON='+json.dumps(query(sys.argv[1])),flush=True)
