"""One immutable terminal archive, exported in 8 MiB pieces."""
import sys,json,hashlib,tarfile,io,base64,os,datetime
from pathlib import Path
import safe_io as s
BASE=Path(__file__).resolve().parent
identity=json.loads(s.read_checked(BASE/'execution_identity.json'));part=int(sys.argv[1]);assert identity['remote_root']==str(BASE)
if identity['status']=='SUBMITTED':
    from query_probe import query
    status=query(identity['job_id']);assert status['terminal'],'Native terminal required'
else:
    assert identity['status']=='SUBMISSION_REJECTED';status=dict(terminal=True,submission_rejected=True,job_id=None,identity=identity)
print('PROBE_STATUS_JSON='+json.dumps(status),flush=True)
folder=BASE/'transport_archive';folder.mkdir(exist_ok=True);index_path=folder/'index.json';archive=folder/'archive.tar.gz'
if not index_path.exists():
    assert not archive.exists(),'Unindexed archive requires file-only diagnosis'
    manifest=json.loads(s.read_checked(BASE/'deployment_manifest.json'))
    files={BASE/row['path'] for row in manifest['files']}
    files.add(BASE/'deployment_manifest.json')
    for name in ['execution_identity.json','submission.json','submission_started.json','submission_reply.json','submission_stdout.txt','submission_scontrol.json','remote_preflight.json']:
        if (BASE/name).is_file():files.add(BASE/name)
    for name in ['logs','runs/04105700/attempt_001','runs/04105700/attempt_001/original','runs/04105700/attempt_001/state_constrained']:
        folder2=s.checked_path(BASE/name,False)
        if folder2.is_dir():
            for f in folder2.iterdir():
                s.checked_path(f)
                if f.is_file():files.add(f)
    rows=[];partial=folder/'archive_incomplete.tar.gz'
    with partial.open('xb') as output:
        with tarfile.open(fileobj=output,mode='w:gz') as tar:
            for f in sorted(files):
                raw=s.read_checked(f);name=f.relative_to(BASE).as_posix();entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mtime=0;tar.addfile(entry,io.BytesIO(raw));rows.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
            metadata=dict(identity=identity,native_status=status,files=rows,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
            raw=(json.dumps(metadata,indent=2)+'\n').encode();entry=tarfile.TarInfo('collection_manifest.json');entry.size=len(raw);entry.mtime=0;tar.addfile(entry,io.BytesIO(raw))
        output.flush();os.fsync(output.fileno())
    partial.rename(archive);parts=[];size=0;digest=hashlib.sha256()
    with archive.open('rb') as f:
        for raw in iter(lambda:f.read(8*1024**2),b''):
            parts.append(dict(part=len(parts),offset=size,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()));size+=len(raw);digest.update(raw)
    s.create('transport_archive/index.json',dict(identity=identity,job_id=identity['job_id'],archive_bytes=size,archive_sha256=digest.hexdigest(),chunk_size=8*1024**2,parts=parts,files=len(rows)+1))
index=json.loads(s.read_checked(index_path));assert index['identity']==identity
print('ARTIFACT_COLLECTION_INDEX='+json.dumps(index),flush=True)
if part>=0:
    row=index['parts'][part]
    with archive.open('rb') as f:f.seek(row['offset']);raw=f.read(row['bytes'])
    assert hashlib.sha256(raw).hexdigest()==row['sha256']
    print('ARTIFACT_PART_METADATA='+json.dumps(dict(row,job_id=identity['job_id'],archive_sha256=index['archive_sha256'])),flush=True)
    print('ARTIFACT_PART_BASE64='+base64.b64encode(raw).decode(),flush=True)
