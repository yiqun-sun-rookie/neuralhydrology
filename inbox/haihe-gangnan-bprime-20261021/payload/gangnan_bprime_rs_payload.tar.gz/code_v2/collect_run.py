"""
把一个 run 的尾段 (epoch 25-30) 测试期预测抽成一个小 npz, 供 aggregate.py 汇总。
残差臂 (任务名含 _rs_, 目标 dINQ_{h}h) 在这里加回 INQ_rep(t) 并裁零, 存成与其他臂同口径的 INQ(t+h)。
用法: python collect_run.py <run_dir> <task_name> <out_dir> [nc_path, 残差臂必需]
环境变量 COLLECT_EPOCHS (逗号分隔) 可覆盖尾段轮次, 仅供本地测试。
"""

import os
import pickle
import sys
from pathlib import Path

import numpy as np

TAIL_EPOCHS = [int(e) for e in os.environ.get("COLLECT_EPOCHS", "25,26,27,28,29,30").split(",")]


def main():
    run_dir, name, out_dir = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
    lead = int(name.split("_")[1].rstrip("h"))
    residual = "_rs_" in name
    var = f"dINQ_{lead}h" if residual else f"INQ_{lead}h"
    dates, obs, sims = None, None, []
    for ep in TAIL_EPOCHS:
        p = run_dir / "test" / f"model_epoch{ep:03d}" / "test_results.p"
        with open(p, "rb") as f:
            res = pickle.load(f)
        basin = next(iter(res))
        x = res[basin][next(iter(res[basin]))]["xr"]
        d = x["date"].values.astype("datetime64[ns]").astype("int64")
        o = np.asarray(x[f"{var}_obs"].values, float).reshape(len(d), -1)[:, -1]
        s = np.asarray(x[f"{var}_sim"].values, float).reshape(len(d), -1)[:, -1]
        if dates is None:
            dates, obs = d, o
        elif not np.array_equal(dates, d):
            raise SystemExit(f"date axis differs at epoch {ep}")
        sims.append(s)
    sims = np.stack(sims)
    if residual:
        import xarray as xr
        with xr.open_dataset(sys.argv[4]) as ds:
            rep = ds["INQ_rep"].to_series().reindex(dates.astype("datetime64[ns]")).values.astype(float)
        obs = obs + rep
        sims = np.clip(sims + rep[None, :], 0.0, None)
    out_dir.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out_dir / f"{name}.npz", dates=dates, obs=obs.astype("float32"),
                        sims=sims.astype("float32"), epochs=np.array(TAIL_EPOCHS))
    print(f"collected {name}: {len(dates)} steps x {len(sims)} epochs (residual={residual})")


if __name__ == "__main__":
    main()
