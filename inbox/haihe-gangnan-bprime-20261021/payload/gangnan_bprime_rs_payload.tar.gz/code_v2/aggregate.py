"""
汇总 B' 实验: 每 (预见期, 臂) 6 种子 × 尾段 6 轮 = 36 成员集成, 逐年报 (2023 / 2024 / 2025)。
门槛 = 已报持续性 (INQ_rep(t) 当 INQ(t+h) 的预报), 在同一批时刻上算。
同时报每个种子各自的尾段集成, 看种子间离散。
臂: base / bp / rs (残差臂, collect_run.py 已加回 INQ_rep), 有哪个报哪个, 共用同一批时刻。
用法: python aggregate.py <collected_dir> <nc_path> <out_csv>
"""

import csv
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import xarray as xr

sys.path.insert(0, str(Path(__file__).resolve().parent))
import forecast_metrics as fm  # noqa: E402

YEARS = (2023, 2024, 2025)


def scores(o, s):
    return {"nse": fm.nse(o, s), "kge": fm.kge(o, s),
            "top1": fm.topn_peak_ratio(o, s, 1), "top10": fm.topn_peak_ratio(o, s, 10),
            "evt10": fm.event_separated_peaks(o, s, 10)["mean_ratio"]}


def main():
    cdir, nc_path, out_csv = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
    with xr.open_dataset(nc_path) as ds:
        inq_rep = ds["INQ_rep"].to_series()

    groups = defaultdict(dict)  # (lead, arm) -> {seed: npz}
    for f in sorted(cdir.glob("bp_*.npz")):
        _, lead, arm, seed = f.stem.split("_")
        groups[(int(lead.rstrip("h")), arm)][seed] = np.load(f)

    rows = []
    for lead in sorted({k[0] for k in groups}):
        arms = {arm: groups[(lead, arm)] for arm in ("base", "bp", "rs") if (lead, arm) in groups}
        ref = next(iter(next(iter(arms.values())).values()))
        dates = ref["dates"]
        obs = ref["obs"].astype(float)
        # 同一批时刻: 各臂各种子集成都有值、观测有值、已报持续性有值
        ens, per_seed = {}, {}
        mask = np.isfinite(obs)
        for arm, seeds in arms.items():
            for seed, z in seeds.items():
                if not np.array_equal(z["dates"], dates):
                    raise SystemExit(f"date axis differs: {lead}h {arm} {seed}")
            per_seed[arm] = {seed: np.nanmean(z["sims"].astype(float), 0) for seed, z in seeds.items()}
            ens[arm] = np.nanmean(np.stack(list(per_seed[arm].values())), 0)
            mask &= np.isfinite(ens[arm])
        idx = dates.astype("datetime64[ns]")
        persist = inq_rep.reindex(idx).values.astype(float)
        mask &= np.isfinite(persist)
        years = idx.astype("datetime64[Y]").astype(int) + 1970

        for y in YEARS:
            m = mask & (years == y)
            if m.sum() == 0:
                continue
            o = obs[m]
            cand = {"persist_rep": persist[m]}
            for arm in arms:
                cand[f"{arm}_ens36"] = ens[arm][m]
            for name, s in cand.items():
                sc = scores(o, s)
                row = {"lead": f"{lead}h", "year": y, "model": name, "n_hours": int(m.sum()),
                       "n_seeds": len(arms[name.split("_")[0]]) if name != "persist_rep" else 0}
                row.update({k: round(v, 3) for k, v in sc.items()})
                if name != "persist_rep":
                    arm = name.split("_")[0]
                    seed_nse = [fm.nse(o, v[m]) for v in per_seed[arm].values()]
                    row["seed_nse_min"] = round(min(seed_nse), 3)
                    row["seed_nse_max"] = round(max(seed_nse), 3)
                rows.append(row)

    fields = ["lead", "year", "model", "n_hours", "n_seeds", "nse", "kge", "top1", "top10", "evt10",
              "seed_nse_min", "seed_nse_max"]
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    for r in rows:
        print(",".join(str(r.get(k, "")) for k in fields))


if __name__ == "__main__":
    main()
