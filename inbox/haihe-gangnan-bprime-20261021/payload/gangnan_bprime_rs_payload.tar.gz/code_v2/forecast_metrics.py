"""Pure peak-aware metric functions for Gangnan inflow forecast evaluation. No IO."""
import numpy as np


def align_valid(obs, sim):
    obs = np.asarray(obs, dtype=float).squeeze()
    sim = np.asarray(sim, dtype=float).squeeze()
    mask = np.isfinite(obs) & np.isfinite(sim)
    return obs[mask], sim[mask], mask


def nse(obs, sim):
    o, s, _ = align_valid(obs, sim)
    denom = np.sum((o - o.mean()) ** 2)
    if denom == 0:
        return float("nan")
    return float(1 - np.sum((s - o) ** 2) / denom)


def rmse(obs, sim):
    o, s, _ = align_valid(obs, sim)
    return float(np.sqrt(np.mean((s - o) ** 2)))


def kge(obs, sim):
    o, s, _ = align_valid(obs, sim)
    if o.std() == 0 or s.std() == 0 or o.mean() == 0:
        return float("nan")
    r = float(np.corrcoef(o, s)[0, 1])
    alpha = s.std() / o.std()
    beta = s.mean() / o.mean()
    return float(1 - np.sqrt((r - 1) ** 2 + (alpha - 1) ** 2 + (beta - 1) ** 2))


def topn_peak_ratio(obs, sim, n):
    o, s, _ = align_valid(obs, sim)
    n = min(n, len(o))
    idx = np.argsort(o)[-n:][::-1]
    return float(np.mean(s[idx] / o[idx]))


def event_separated_peaks(obs, sim, n=10, sep=48):
    o, s, _ = align_valid(obs, sim)
    order = np.argsort(o)[::-1]
    used = np.zeros(len(o), dtype=bool)
    peaks = []
    for i in order:
        if len(peaks) >= n:
            break
        if used[i]:
            continue
        peaks.append(i)
        used[max(0, i - sep):min(len(o), i + sep + 1)] = True
    peaks = np.array(peaks, dtype=int)
    ratios = s[peaks] / o[peaks]
    return {
        "n": len(peaks),
        "mean_ratio": float(ratios.mean()),
        "obs_peaks": o[peaks],
        "sim_peaks": s[peaks],
    }
