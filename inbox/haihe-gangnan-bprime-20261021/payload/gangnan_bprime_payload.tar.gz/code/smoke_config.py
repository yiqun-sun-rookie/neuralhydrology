"""
冒烟测试: 取任务清单中第一个 B' 臂配置, 改成 1 轮、独立实验名, 写到 <out_yml>。
训练完后用 smoke_check 模式核对测试结果能读、变量齐全。
用法:
  python smoke_config.py make <configs_dir> <out_yml>
  python smoke_config.py check <run_dir>
"""

import pickle
import sys
from pathlib import Path

import numpy as np
import yaml


def make(cfg_dir: Path, out: Path):
    tasks = (cfg_dir / "tasks.txt").read_text(encoding="utf-8").split()
    first = next(t for t in tasks if "_bp_" in t)  # B' 臂含新增输入, 冒烟测它
    cfg = yaml.safe_load((cfg_dir / f"{first}.yml").read_text(encoding="utf-8"))
    cfg.update({"epochs": 1, "experiment_name": "bp_smoke", "learning_rate": {0: 0.001}})
    out.write_text(yaml.safe_dump(cfg, sort_keys=False), encoding="utf-8")
    print(f"smoke config from {first} -> {out}; inputs={cfg['dynamic_inputs']}")


def check(run_dir: Path):
    p = run_dir / "test" / "model_epoch001" / "test_results.p"
    with open(p, "rb") as f:
        res = pickle.load(f)
    basin = next(iter(res))
    x = res[basin][next(iter(res[basin]))]["xr"]
    var = [v for v in x.data_vars if v.endswith("_obs")][0].replace("_obs", "")
    o = np.asarray(x[f"{var}_obs"].values, float).ravel()
    s = np.asarray(x[f"{var}_sim"].values, float).ravel()
    m = np.isfinite(o) & np.isfinite(s)
    nse = 1 - ((o[m] - s[m]) ** 2).sum() / ((o[m] - o[m].mean()) ** 2).sum()
    d = x["date"].values
    print(f"SMOKE_OK var={var} steps={len(d)} first={d[0]} last={d[-1]} valid={m.sum()} nse_ep1={nse:.3f}")


if __name__ == "__main__":
    if sys.argv[1] == "make":
        make(Path(sys.argv[2]), Path(sys.argv[3]))
    else:
        check(Path(sys.argv[2]))
