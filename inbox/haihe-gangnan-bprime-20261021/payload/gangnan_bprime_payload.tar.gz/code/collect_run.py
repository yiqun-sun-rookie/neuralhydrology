"""
把一个 run 的尾段 (epoch 25-30) 测试期预测抽成一个小 npz, 供 aggregate.py 汇总。
用法: python collect_run.py <run_dir> <task_name> <out_dir>
"""

import pickle
import sys
from pathlib import Path

import numpy as np

TAIL_EPOCHS = [25, 26, 27, 28, 29, 30]


def main():
    run_dir, name, out_dir = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
    lead = int(name.split("_")[1].rstrip("h"))
    var = f"INQ_{lead}h"
    dates, obs, sims = None, None, []
    for ep in TAIL_EPOCHS:
        p = run_dir / "test" / f"model_epoch{ep:03d}" / "test_results.p"
        with open(p, "rb") as f:
            res = pickle.load(f)
        basin = next(iter(res))
        x = res[basin][next(iter(res[basin]))]["xr"]
        d = x["date"].values.astype("datetime64[ns]").astype("int64")
        o = np.asarray(x[f"{var}_obs"].values, float).reshape(len(d), -1)[:, -1]
        s = np.asarray(x[f"{var}_sim"].values, float).reshape(len(d), -1)[:, -1]
        if dates is None:
            dates, obs = d, o
        elif not np.array_equal(dates, d):
            raise SystemExit(f"date axis differs at epoch {ep}")
        sims.append(s)
    out_dir.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out_dir / f"{name}.npz", dates=dates, obs=obs.astype("float32"),
                        sims=np.stack(sims).astype("float32"), epochs=np.array(TAIL_EPOCHS))
    print(f"collected {name}: {len(dates)} steps x {len(sims)} epochs")


if __name__ == "__main__":
    main()
