"""Same-history current-day correction diagnostic; no neural forward or update."""
import os,sys,json,io,math,hashlib,datetime,importlib.util,traceback
from pathlib import Path
BASE=Path(__file__).resolve().parent;TEMPLATE=BASE.parents[1]/'template'
sp=importlib.util.spec_from_file_location('safe_io',BASE/'safe_io.py');s=importlib.util.module_from_spec(sp);sys.modules['safe_io']=s;sp.loader.exec_module(s)
handshake=json.loads(sys.stdin.readline())
if not handshake.get('resources_configured') or not os.environ.get('SLURM_JOB_ID','').isdigit():raise RuntimeError('Slurm resource handshake required')
ATTEMPT=sys.argv[1];OUT='runs/'+ATTEMPT;AUTH=json.loads(s.read_checked(BASE/'execution_authorization.json'))
if AUTH['status']!='AUTHORIZED' or AUTH['new_training_updates']!=0:raise RuntimeError('scope differs')
for row in AUTH['files']:s.read_checked(BASE/row['path'],row['sha256'])
contract_sha=hashlib.sha256(s.read_checked(BASE/'plan_contract.json')).hexdigest()
bundle=json.loads(s.read_checked(TEMPLATE/'bundle_manifest.json',AUTH['template_manifest_sha256']))
for row in bundle['files']:s.read_checked(TEMPLATE/row['path'],row['sha256'])
os.chdir(TEMPLATE);RECIPE=TEMPLATE/'recipe';os.environ['KNET_BASIN']='04105700';sys.path.insert(0,str(RECIPE))
import numpy as np,torch,psutil,importlib.metadata
torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
import common as C
for name in ['execution_sources.json','evaluation_sources.json']:
 manifest=json.loads(s.read_checked(RECIPE/name));C.DIGESTS.update({str(Path(x['path']).resolve()).lower():x['sha256'] for x in manifest['files']})
E=C.checked_source('correction_diagnostic_helpers',RECIPE/'evaluate.py')
from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import AccessLedger,CAUSAL_SHARED_SPINUP_MODE
registry=json.loads(s.read_checked(BASE/'inputs/main_registry.json'))
def emit(event,**data):print(json.dumps({'event':event,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**data},ensure_ascii=False,allow_nan=False),flush=True)
actual=psutil.Process()
emit('runtime_ready',job_id=os.environ['SLURM_JOB_ID'],node=os.uname().nodename,pid=actual.pid,creation_time=actual.create_time(),affinity=actual.cpu_affinity(),priority_nice=actual.nice(),torch_threads=torch.get_num_threads(),torch_interop_threads=torch.get_num_interop_threads(),versions={k:importlib.metadata.version(k) for k in ['torch','numpy','psutil']})
def obj(identity):return json.loads(s.read_checked(BASE/identity['path'],identity['sha256']))
def load(identity):
 with np.load(io.BytesIO(s.read_checked(BASE/identity['path'],identity['sha256'])),allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
def tensors(identity):return torch.load(io.BytesIO(s.read_checked(BASE/identity['path'],identity['sha256'])),weights_only=True,map_location='cpu')
def put(name,value):return s.create(OUT+'/'+name,value)
def put_np(name,values):
 stream=io.BytesIO();np.savez_compressed(stream,**values);return put(name,stream.getvalue())
def score(pred,target):
 if not np.isfinite(pred).all():return {'finite':False,'mean_mse':None,'mse_by_lead':[None]*3,'count_per_lead':len(target)}
 vals=[float(np.mean(np.square(pred[:,i]-target[:,i]))) for i in range(3)]
 return {'finite':True,'mean_mse':math.fsum(vals)/3,'mse_by_lead':vals,'count_per_lead':len(target)}
def cached(name):
 for folder in sorted((BASE/'runs').iterdir()):
  path=folder/name
  if path.is_file():
   value=json.loads(s.read_checked(path))
   if value.get('contract_sha256')!=contract_sha:raise RuntimeError('cached contract differs')
   for identity in value.get('artifacts',[]):s.read_checked(BASE/identity['path'],identity['sha256'])
   emit('completed_stage_reused',stage=name,source=str(path.relative_to(BASE)));return value
 return None
results=[];physics_calls=0
for spec in registry['basins']:
 basin=spec['basin'];saved=cached('basin_'+basin+'.json')
 if saved is not None:results.append(saved);continue
 data=load(spec['main']);cp=tensors(spec['checkpoint']);assert cp['epoch']==spec['selected_epoch']
 if C.helpers.digest_tree(cp['network'])!=cp['network_sha256']:raise RuntimeError('checkpoint network hash differs')
 net=cp['network'];lower=net['state_lower_bound'].to(dtype=torch.float64);upper=net['state_upper_bound'].to(dtype=torch.float64)
 prior=torch.from_numpy(data['prior'][:728,0,:]).to(dtype=torch.float64);correction=torch.from_numpy(data['correction'][:728,0,:]).to(dtype=torch.float64)
 original_state=data['posterior'][:728,0,:]
 runtime=per.load_per_basin_development_runtime(get_development_basin_specification(basin),ledger=AccessLedger(),initialization_mode=CAUSAL_SHARED_SPINUP_MODE,device='cpu')
 assert runtime.context.dimension==spec['state_dimension'] and runtime.training_days==2557
 issue=data['issue_indices'];dates=runtime.dates.astype('datetime64[ns]').astype('int64')
 assert np.array_equal(issue,np.arange(2557,3285)) and np.array_equal(data['target_dates_ns'],dates[data['target_indices']])
 assert np.array_equal(data['target'],runtime.observations.detach().cpu().numpy().reshape(-1)[data['target_indices']])
 predictions={};projection_error=None
 with torch.no_grad():
  for alpha,label in [(1.,'1'),(.5,'0p5'),(0.,'0')]:
   state=torch.maximum(torch.minimum(prior+alpha*correction,upper),lower)
   if alpha==1.:
    projection_error=float(np.max(np.abs(state.numpy()-original_state)))
    if projection_error>1e-12:raise RuntimeError('alpha1 state reconstruction failed '+basin+' '+str(projection_error))
   values=[]
   for lead in [1,2,3]:
    state=runtime.context.plain_model.f(state,runtime.forcing[issue+lead,0,:]);values.append(runtime.context.plain_model.h(state)[:,0]);physics_calls+=1
   predictions[label]=torch.stack(values,dim=1).cpu().numpy()
   if alpha==1.:
    forecast_error=float(np.max(np.abs(predictions[label]-data['prediction'])))
    if not np.isfinite(predictions[label]).all() or forecast_error>1e-12:raise RuntimeError('alpha1 forecast reconstruction failed '+basin+' '+str(forecast_error))
    predictions[label]=data['prediction'].copy()
    emit('alpha1_reconstruction_pass',basin=basin,state_max_absolute_error=projection_error,forecast_max_absolute_error=forecast_error)
   else:emit('counterfactual_forecasts_complete',basin=basin,alpha=alpha,origins=728,leads=3)
 arrays={'target':data['target'],'issue_indices':issue,'target_indices':data['target_indices'],'issue_dates_ns':data['issue_dates_ns'],'target_dates_ns':data['target_dates_ns'],'physical_prediction':data['physical_prediction'],'ukf_prediction':data['ukf_prediction']}
 arrays.update({'prediction_alpha_'+label:pred for label,pred in predictions.items()})
 artifact=put_np('branches_'+basin+'.npz',arrays);stored=load(artifact);rows=[]
 original_error=np.mean(np.square(stored['prediction_alpha_1']-stored['target']),axis=1)
 for alpha,label in [(0.,'0'),(.5,'0p5'),(1.,'1')]:
  pred=stored['prediction_alpha_'+label];metric=score(pred,stored['target']);reference_metric=E.metric(pred,stored['target'])
  if metric['finite'] and abs(metric['mean_mse']-reference_metric['mean_mse'])>1e-12:raise RuntimeError('saved score reconstruction failed')
  delta=np.mean(np.square(pred-stored['target']),axis=1)-original_error
  finite=np.isfinite(delta)
  rows.append({'alpha':alpha,'label':label,'score':metric,'mean_daily_error_difference':float(np.mean(delta)) if finite.all() else None,'improved_days':int(np.sum(finite&(delta<-1e-12))),'worsened_days':int(np.sum(finite&(delta>1e-12))),'tied_days':int(np.sum(finite&(np.abs(delta)<=1e-12))),'nonfinite_days':int(np.sum(~finite)),'improvement_sum':float(np.sum(delta[finite&(delta<0)])),'worsening_sum':float(np.sum(delta[finite&(delta>0)])),'score_verification':'saved arrays independently recomputed once, abs tolerance1e-12'})
 main_diagnostics,extra=E.correction_diagnostics(data,{'prediction':data['physical_prediction'],'target':data['target']},0,net['state_feature_scale'].cpu().numpy().reshape(-1))
 diag_artifact=put_np('main_corrections_'+basin+'.npz',extra)
 row={'basin':basin,'selected_epoch':spec['selected_epoch'],'contract_sha256':contract_sha,'reconstruction':{'status':'PASS','state_max_absolute_error':projection_error,'forecast_max_absolute_error':forecast_error,'absolute_tolerance':1e-12},'alpha_rows':rows,'physical':score(data['physical_prediction'],data['target']),'ukf':score(data['ukf_prediction'],data['target']),'main_cumulative_diagnostics':main_diagnostics,'source_checkpoint':spec['source_checkpoint'],'artifacts':[artifact,diag_artifact],'original_history_preserved':True,'new_neural_assimilation_steps':0,'new_training_updates':0}
 put('basin_'+basin+'.json',row);results.append(row);emit('basin_diagnostic_complete',basin=basin,alpha_mean_mse={str(x['alpha']):x['score']['mean_mse'] for x in rows})
cumulative=cached('cumulative_cases.json')
if cumulative is None:
 cumulative_rows=[];artifacts=[]
 for entry in registry['reference_cold_cases']:
  a=load(entry['artifact']);cp=tensors(entry['checkpoint']);scales=cp['network']['state_feature_scale'].cpu().numpy().reshape(-1)
  diagnostics,extra=E.correction_diagnostics(a,{'prediction':a['physical_prediction'],'target':a['target']},365,scales)
  assert len(a['prediction'])-365==entry['count_per_lead']
  artifact=put_np('reference_cumulative_'+str(entry['epoch'])+'_'+str(entry['start'])+'.npz',extra);artifacts.append(artifact)
  cumulative_rows.append({'basin':'02092500','epoch':entry['epoch'],'start':entry['start'],'warmup':365,'count_per_lead':entry['count_per_lead'],'diagnostics':diagnostics,'source_artifact':entry['source_artifact'],'new_continuous_assimilation':False})
 for identity in registry['reused_new_basin_metric_files']:
  source=obj(identity)
  for epoch,rows in source['evaluated'].items():
   for row in rows:cumulative_rows.append({'basin':source['basin'],'epoch':int(epoch),'start':row['start'],'warmup':row['warmup'],'count_per_lead':row['score']['count_per_lead'],'diagnostics':row['diagnostics'],'source_artifact':row['artifact'],'reused_verified_metric':True,'new_continuous_assimilation':False})
 assert len(cumulative_rows)==56
 cumulative={'contract_sha256':contract_sha,'rows':cumulative_rows,'artifacts':artifacts,'case_count':56,'reference_metrics_computed_from_existing_arrays':14,'new_basin_verified_metrics_reused':42}
 put('cumulative_cases.json',cumulative)
 emit('cumulative_diagnostics_complete',cases=56,new_neural_assimilation_steps=0)
result={'status':'DIAGNOSTIC_COMPLETE','experiment_id':AUTH['experiment_id'],'contract_sha256':contract_sha,'job_id':os.environ['SLURM_JOB_ID'],'node':os.uname().nodename,'basins':results,'basin_denominator':4,'counterfactual_combinations':12,'cumulative_cases':56,'new_physics_batch_calls_this_attempt':physics_calls,'forecast_values_per_full_attempt':26208,'new_counterfactual_forecast_values':17472,'new_neural_assimilation_steps':0,'new_training_updates':0,'scientific_failures_retained':True,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'limits':'Same-history current-day diagnostic; no proof of multi-year strategy superiority, true hidden states or all-CAMELS generalization.'}
put('result.json',result);emit('diagnostic_finished',status=result['status'],basins=4,groups=12)
