"""Observation-only hooks on actual native graph nodes; no model imports."""
from contextlib import contextmanager
import sys

SOURCE_SHA256 = '3eb80fc1346a3e86170cac28fecad29951fe938193967e6a8cf6ae705edc22da'
RECURRENCE_FIELDS = ('m1x_posterior', 'm1x_posterior_previous',
    'm1x_prior_previous', 'y_previous', 'h_Q', 'c_Q', 'h_Sigma',
    'c_Sigma', 'h_S', 'c_S')

def detach_recurrence(net):
    """All ten fields belong to the native net, including inherited LSTM fields."""
    for name in RECURRENCE_FIELDS:
        value = getattr(net, name)
        setattr(net, name, value.detach())

def retain(node):
    if node.requires_grad:
        node.retain_grad()
    return node

def make_tracer(net, filename, records, cores, capture_line=416):
    """Track each matching invocation independently, including exception unwind."""
    pending = {}
    def tracer(frame, event, arg):
        if frame.f_code.co_name != 'analysis_step' or frame.f_code.co_filename.replace('\\', '/').lower() != filename or frame.f_locals.get('self') is not net:
            return None
        if event == 'call':
            pending[id(frame)] = dict(record=None, failed=False)
        call = pending.get(id(frame))
        if call is None:
            return tracer
        if event == 'exception':
            call['failed'] = True
        if event == 'line' and frame.f_lineno == capture_line:
            if not cores:
                raise RuntimeError('FC2 node absent at raw capture')
            record=dict(core=cores[-1], gain=retain(net.KGain),
                raw=retain(frame.f_locals['correction_in_scale_units']))
            records.append(record); call['record']=record
        if event == 'return':
            if not call['failed'] and call['record'] is not None and arg is not None:
                call['record'].update(actual=retain(net.last_correction), posterior=retain(net.m1x_posterior))
            pending.pop(id(frame),None)
        return tracer
    return tracer

@contextmanager
def native_nodes(net, source, read_checked):
    lines = read_checked(source, SOURCE_SHA256).decode('utf-8').splitlines()
    if lines[414].strip() != 'correction_in_scale_units = self.KGain.squeeze(-1) * normalized_innovation' or lines[415].strip() != 'cap = self.correction_cap_by_state_scale_units':
        raise RuntimeError('frozen raw-node source location differs')
    records, cores = [], []
    def hook(module, inputs, output):
        cores.append(retain(output))
    handle = net.FC2.register_forward_hook(hook)
    previous = sys.gettrace()
    filename = str(source).replace('\\', '/').lower()
    tracer=make_tracer(net,filename,records,cores)
    sys.settrace(tracer)
    try:
        yield records
    finally:
        sys.settrace(previous)
        handle.remove()
        if len(cores)>len(records):
            records.extend(dict(core=node) for node in cores[len(records):])
