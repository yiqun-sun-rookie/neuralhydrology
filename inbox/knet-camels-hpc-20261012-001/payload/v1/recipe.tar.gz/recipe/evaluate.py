"""Post-selection cases, aligned baselines and correction diagnostics; no training."""
import io,json,math,traceback,hashlib,time
from pathlib import Path
import numpy as np
import torch
import common as C
from evaluation_loops import native_filter,available_forecasts
from training_common import digest_tree,numerical_exception
STARTS=(366,731,1096,1461,1827,2192,2557)
COUNTS=(2554,2189,1824,1459,1093,728,363)
STORE=C.Store()

def arr(x):return x.detach().cpu().numpy().copy() if isinstance(x,torch.Tensor) else np.asarray(x).copy()
def load_np(identity):return STORE.load_arrays(identity)
def metric(pred,target,warmup=0):
 p=np.asarray(pred)[warmup:];t=np.asarray(target)[warmup:]
 assert p.shape==t.shape and p.ndim==2 and p.shape[1]==3
 if not np.isfinite(p).all() or not np.isfinite(t).all():return dict(mean_mse=None,mse_by_lead=None,nse_by_lead=None,mean_nse=None,count_per_lead=len(t),finite=False)
 with np.errstate(over='ignore',invalid='ignore'):
  mse=np.mean((p-t)**2,axis=0);denom=np.sum((t-np.mean(t,axis=0))**2,axis=0);nse=np.where(denom>0,1-np.sum((p-t)**2,axis=0)/denom,np.nan)
 return dict(mean_mse=math.fsum(map(float,mse))/3,mse_by_lead={str(i+1):float(v) for i,v in enumerate(mse)},nse_by_lead={str(i+1):float(v) for i,v in enumerate(nse)},mean_nse=float(np.mean(nse)),count_per_lead=len(t),finite=bool(np.isfinite(mse).all()))
def main_vectors(a,label='728'):
 return np.column_stack([a[label+'_lead'+str(k)+'_forecast'] for k in (1,2,3)]),np.column_stack([a[label+'_lead'+str(k)+'_target'] for k in (1,2,3)])
def require_close(a,b,label):
 if a is None or b is None:
  if a is not b:raise RuntimeError(label+' finite status differs')
 elif not abs(float(a)-float(b))<=1e-12:raise RuntimeError(label+' saved score mismatch')
def verify_saved(a,ident,score,warmup):
 saved=load_np(ident)
 # One offline recomputation, column by column, independent of the matrix reduction.
 p=saved['prediction'][warmup:];t=saved['target'][warmup:]
 if np.isfinite(p).all() and np.isfinite(t).all():
  mse=[float(np.mean(np.square(p[:,i]-t[:,i]))) for i in range(3)]
  require_close(math.fsum(mse)/3,score['mean_mse'],'mean MSE')
  for i in range(3):require_close(mse[i],score['mse_by_lead'][str(i+1)],'lead MSE')
 for k in ('issue_indices','target_indices','issue_dates_ns','target_dates_ns'):
  if not np.array_equal(saved[k],a[k]):raise RuntimeError('saved alignment differs '+k)
 return dict(status='PASS',absolute_tolerance=1e-12,offline_recomputations=1)
def longest(mask):
 best=run=0;beststart=None
 for i,x in enumerate(mask):
  run=run+1 if x else 0
  if run>best:best=run;beststart=i-run+1
 return dict(days=best,start_local=beststart,end_local=None if beststart is None else beststart+best-1)
def rolling_sum(x,n):
 x=np.asarray(x,dtype=np.float64)
 if len(x)<n:return np.empty((0,)+x.shape[1:])
 # Convolution avoids subtracting large cumulative totals in the diagnostic.
 if x.ndim==1:return np.convolve(x,np.ones(n),mode='valid')
 return np.column_stack([np.convolve(x[:,j],np.ones(n),mode='valid') for j in range(x.shape[1])])
def correction_diagnostics(a,physical,warmup,scale):
 requested=a['correction'][:,0,:];realized=a['posterior'][:,0,:]-a['prior'][:,0,:]
 q=requested[warmup:];z=realized[warmup:];states=a['posterior'][warmup:,0,:]
 if not len(q):return dict(status='NO_FINITE_STATE_TRACE'),{}
 finite=np.isfinite(q).all() and np.isfinite(z).all() and np.isfinite(states).all()
 if not finite:return dict(status='NONFINITE_STATE_TRACE'),{}
 upper=3;positive=longest(q[:,upper]>0);positive_realized=longest(z[:,upper]>0)
 for run in (positive,positive_realized):
  if run['start_local'] is not None:
   run['start_global']=int(a['state_global_indices'][warmup+run['start_local']]);run['end_global']=int(a['state_global_indices'][warmup+run['end_local']])
 hit=q[:,upper]>=3*scale[upper]*(1-1e-9)
 result=dict(status='COMPLETE',scoring_warmup_days=warmup,state_dimension=q.shape[1],upper_groundwater_index=3,
  proposal_definition='native last_correction after existing cap, before physical-state projection',
  requested_total_by_state=np.sum(q,axis=0).tolist(),realized_total_by_state=np.sum(z,axis=0).tolist(),
  state_min_by_state=np.min(states,axis=0).tolist(),state_max_by_state=np.max(states,axis=0).tolist(),
  upper_positive_run=positive,upper_realized_positive_run=positive_realized,
  upper_positive_cap_hit_days=int(hit.sum()),upper_positive_cap_hit_fraction=float(hit.mean()),
  upper_positive_cap_hit_longest=longest(hit),routing_channels_reported_separately=True)
 extra={}
 for width in (30,90):
  for name,v in [('requested',q),('realized',z)]:
   values=rolling_sum(v,width);extra[f'{name}_cumulative_{width}_by_state']=values
   result[f'{name}_{width}_upper_min']=None if not len(values) else float(values[:,upper].min())
   result[f'{name}_{width}_upper_max']=None if not len(values) else float(values[:,upper].max())
 error=np.mean((a['prediction']-a['target'])**2,axis=1)[warmup:]
 control=np.mean((physical['prediction']-physical['target'])**2,axis=1)[warmup:]
 rolling=rolling_sum(error,30)/30;control_rolling=rolling_sum(control,30)/30
 flag=np.isfinite(rolling)&np.isfinite(control_rolling)&(rolling>10)&(rolling>10*control_rolling)
 sustained=longest(flag);j=None;run=0
 for i,value in enumerate(flag):
  run=run+1 if value else 0
  if run==30:j=i-29;break
 issue=a['issue_indices'][warmup:];extra.update(rolling30_mean_forecast_mse=rolling,rolling30_physical_mse=control_rolling,rolling30_high_error_flag=flag,
  rolling30_window_start_global=issue[:len(rolling)],rolling30_window_end_global=issue[29:29+len(rolling)])
 result['sustained_high_error']=dict(present=j is not None,longest_flagged_windows=sustained['days'],
  threshold='30-origin mean three-lead MSE > 10 and > 10 times physical; 30 successive windows',
  first_window_start_global=None if j is None else int(issue[j]),first_window_end_global=None if j is None else int(issue[j+29]),
  confirmed_by_origin_global=None if j is None else int(issue[j+58]),interpretation='retrospective diagnostic; target observations arrive after each origin')
 # Save exact coupled error and correction arrays, without claiming causal attribution.
 q30=rolling_sum(q[:len(error),upper],30);z30=rolling_sum(z[:len(error),upper],30)
 n=min(len(rolling),len(q30));extra['coupled30_upper_requested']=q30[:n];extra['coupled30_upper_realized']=z30[:n];extra['coupled30_forecast_mse']=rolling[:n]
 result['coupled30_windows']=n
 return result,extra

def forecast_arrays(runtime,posts,forcing,start):
 prediction,errors=available_forecasts(runtime.context.plain_model,posts,forcing)
 issue=np.arange(start,start+len(forcing)-3);targets=issue[:,None]+np.arange(1,4)
 dates=runtime.dates.astype('datetime64[ns]').astype('int64');obs=arr(runtime.observations).reshape(-1)
 assert np.array_equal(targets-issue[:,None],np.broadcast_to(np.arange(1,4),targets.shape))
 return dict(prediction=prediction,target=obs[targets],issue_indices=issue,target_indices=targets,
  issue_dates_ns=dates[issue],target_dates_ns=dates[targets],state_global_indices=np.arange(start,start+len(posts))),errors

def baseline(runtime,parity,pair,theta,method,start,initial,warmup):
 forcing=runtime.forcing[start:];observations=runtime.observations[start:];failure=None
 try:
  with torch.no_grad():
   if method=='physical':
    states=pair.physical_posts(runtime,forcing,initial);priors=states
   else:
    context=parity._context_with_initial_state(runtime.context,initial.clone())
    result=runtime.tukf06_module.run_parameterized_filter(context,forcing,observations,theta,runtime.tukf06_contract)
    states=result['posterior_state'].reshape(-1,1,runtime.context.dimension);priors=result['prior_state'].reshape_as(states)
   a,errors=forecast_arrays(runtime,list(states),forcing,start)
 except Exception as e:
  if not numerical_exception(e):raise
  failure=dict(type=type(e).__name__,message=str(e),traceback=traceback.format_exc());states=torch.empty((0,1,runtime.context.dimension));priors=states
  a,errors=forecast_arrays(runtime,[],forcing,start)
 a.update(posterior=arr(states),prior=arr(priors),correction=arr(states-priors))
 score=metric(a['prediction'],a['target'],warmup)
 name=f'evaluation/baselines/{method}_{start}_{warmup}'
 artifact=C.save_arrays(name+'.npz',a);check=verify_saved(a,artifact,score,warmup)
 row=dict(method=method,start=start,warmup=warmup,score=score,artifact=artifact,failure=failure,forecast_errors=errors,verification=check)
 C.save(name+'.json',row);return row,a

def knet_case(net,cp,runtime,start,count,physical,scale):
 forcing=runtime.forcing[start:];observations=runtime.observations[start:];partial={};before=digest_tree(net.state_dict());rng=torch.get_rng_state().clone()
 with torch.no_grad():
  posts,priors,corrections,hits,failure=native_filter(net,forcing,observations,runtime.context.initial_state,None,allow_failure=True,evidence=partial)
  a,errors=forecast_arrays(runtime,posts,forcing,start)
 assert digest_tree(net.state_dict())==before and torch.equal(rng,torch.get_rng_state())
 m=runtime.context.dimension
 stack=lambda values:arr(torch.stack(values)) if values else np.empty((0,1,m))
 a.update(posterior=stack(posts),prior=stack(priors),correction=stack(corrections),cap_hits=stack(hits))
 if failure:
  failure=dict(failure);failed=failure.pop('available_state',{})
  a.update({'failed_state_'+name:arr(value) for name,value in failed.items()})
  failure.update(global_day=start+failure['day'])
 score=metric(a['prediction'],a['target'],365);assert score['count_per_lead']==count
 diagnostics,extra=correction_diagnostics(a,physical,365,scale);a.update(extra)
 pscore=metric(physical['prediction'],physical['target'],365)
 severe=not score['finite'] or bool(failure) or bool(errors) or score['mean_mse']>100*pscore['mean_mse']
 name=f'evaluation/knet/epoch_{cp["epoch"]:03d}_{start}'
 artifact=C.save_arrays(name+'.npz',a);check=verify_saved(a,artifact,score,365)
 row=dict(epoch=cp['epoch'],parameter_sha256=cp['parameter_sha256'],start=start,warmup=365,score=score,
  physical_score=pscore,severe=severe,numeric_failure=failure,forecast_errors=errors,diagnostics=diagnostics,artifact=artifact,verification=check)
 C.save(name+'.json',row)
 print(json.dumps(C.helpers.safe(dict(event='case_complete',basin=C.BASIN,epoch=cp['epoch'],start=start,mean_mse=score['mean_mse'],severe=severe,sustained_high_error=diagnostics.get('sustained_high_error',{}).get('present')))),flush=True)
 return row

def verified_main(row,label):
 a=load_np(row['validation']['artifacts']['arrays']);p,t=main_vectors(a)
 score=metric(p,t);assert score['count_per_lead']==728
 require_close(score['mean_mse'],row['validation']['objective_728'],'saved validation objective')
 for k in ('1','2','3'):require_close(score['mse_by_lead'][k],row['validation']['mse_by_lead_728'][k],'saved validation lead')
 expected=np.arange(2557,3285)
 for k in (1,2,3):
  prefix='728_lead'+str(k);assert np.array_equal(a[prefix+'_issue_indices'],expected);assert np.array_equal(a[prefix+'_target_indices'],expected+k)
 return dict(method=label,score=score,reported_712=metric(*main_vectors(a,'712')),artifact=row['validation']['artifacts']['arrays'],verification=dict(status='PASS',absolute_tolerance=1e-12,offline_recomputations=1)),a

def main():
 started=time.monotonic();summary=C.obj('long/summary.json');history=C.obj('long/history.json')
 selected=next(row for row in history if row['epoch']==summary['best_epoch']);last=history[-1]
 eligible=selected.get('validation') is not None and not selected.get('failure')
 epochs=list(dict.fromkeys([selected['epoch'],last['epoch']]))
 C.save('evaluation/selection_frozen.json',dict(selected_epoch=selected['epoch'],selected_eligible=eligible,last_epoch=last['epoch'],evaluated_epochs=epochs,
  selected_checkpoint=selected['checkpoint'],last_checkpoint=last['checkpoint'],selection_used_continuous_cases=False,training_summary_sha256=hashlib.sha256(C.read_checked(C.HERE/'long/summary.json')).hexdigest()))
 runtime,per,parity,settings=C.setup();pair=C.checked_source('evaluation_pair_functions',C.RUN/'pair_functions.py')
 theta_array,selection_record=per.load_selected_unscented_kalman_filter_parameters(runtime.contract,method='backpropagation');theta=torch.tensor(theta_array,dtype=torch.float64)
 C.save('evaluation/ukf_parameters.json',dict(basin=C.BASIN,method='backpropagation',theta_log=theta_array.tolist(),selection_sha256=runtime.contract.selection_sha256))
 physical_main=C.obj('baselines/physical_validation.json');physical_arrays=load_np(physical_main['artifact']);physical_score=metric(*main_vectors(physical_arrays));require_close(physical_score['mean_mse'],physical_main['objective_728'],'physical main objective')
 window=parity.select_window(runtime,'recovery')
 ukf_main,ukf_main_arrays=baseline(runtime,parity,pair,theta,'ukf',2557,window.initial_state,0)
 main_knet,main_arrays=verified_main(selected,'knet') if selected.get('validation') else (dict(method='knet',score=None,unavailable_reason='no finite selected validation'),None)
 main_table=dict(knet=main_knet,physical=dict(method='physical',score=physical_score,artifact=physical_main['artifact']),ukf=ukf_main)
 C.save('evaluation/main_validation.json',main_table)
 physical_cases={};baseline_rows=[]
 for start,count in zip(STARTS,COUNTS):
  for method in ('physical','ukf'):
   row,a=baseline(runtime,parity,pair,theta,method,start,runtime.context.initial_state,365)
   assert row['score']['count_per_lead']==count;baseline_rows.append(row)
   if method=='physical':physical_cases[start]=a
 evaluated={}
 for epoch in epochs:
  row=next(x for x in history if x['epoch']==epoch);cp=STORE.load_tensors(row['checkpoint'])
  assert cp['epoch']==epoch and digest_tree(cp['network'])==cp['network_sha256']
  net=C.build(runtime,per,parity,settings,requires_grad=False);net.load_state_dict(cp['network'],strict=True)
  assert parity.parameter_sha256(net)==cp['parameter_sha256'];torch.set_rng_state(cp['torch_rng_state'])
  scale=arr(net.state_feature_scale).reshape(-1)
  evaluated[str(epoch)]=[knet_case(net,cp,runtime,start,count,physical_cases[start],scale) for start,count in zip(STARTS,COUNTS)]
  if epoch==selected['epoch'] and main_arrays is not None:
   a=dict(prediction=main_vectors(main_arrays)[0],target=main_vectors(main_arrays)[1],posterior=main_arrays['states'],prior=main_arrays['priors'],correction=main_arrays['requested_corrections'],issue_indices=np.arange(2557,3285),state_global_indices=np.arange(2557,3288))
   p=dict(prediction=main_vectors(physical_arrays)[0],target=main_vectors(physical_arrays)[1])
   diagnostics,extra=correction_diagnostics(a,p,0,scale)
   ident=C.save_arrays('evaluation/main_correction_diagnostics.npz',extra);C.save('evaluation/main_correction_diagnostics.json',dict(diagnostics,artifact=ident))
 result=dict(status='COMPLETE',basin=C.BASIN,state_dimension=runtime.context.dimension,training_status=summary['scientific_training_status'],training_stop=summary['stop_reason'],
  selected_epoch=selected['epoch'],selected_eligible=eligible,last_epoch=last['epoch'],optimizer_steps=summary['optimizer_steps'],large_increase_history=summary['large_increase_history'],
  main_validation=main_table,baselines=baseline_rows,evaluated=evaluated,
  selected_cold_severe_count=sum(row['severe'] for row in evaluated[str(selected['epoch'])]),
  selected_sustained_high_error_count=sum(bool(row['diagnostics'].get('sustained_high_error',{}).get('present')) for row in evaluated[str(selected['epoch'])]),
  distinct_checkpoint_count=len(epochs),new_knet_continuous_trajectories=7*len(epochs),new_physical_continuous_trajectories=7,new_ukf_continuous_trajectories=7,new_ukf_main_trajectories=1,
  wall_seconds=time.monotonic()-started,selection_fixed_before_continuous_scoring=True,verification='saved-array scores recomputed once, absolute tolerance 1e-12')
 C.save('evaluation/result.json',result)
 if C.BASIN=='09035800':
  from finalize import finish
  finish()
 print(json.dumps(dict(event='evaluation_finished',basin=C.BASIN,selected_epoch=selected['epoch'],status='COMPLETE')),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException as error:
  C.save('evaluation/technical_failure.json',dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc()))
  raise
