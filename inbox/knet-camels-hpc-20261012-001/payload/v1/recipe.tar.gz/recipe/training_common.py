"""Pure evidence/geometry utilities; import never initializes a real model.

digest_tree serialization: tensors have literal tensor:, dtype, JSON shape,
then contiguous CPU NumPy bytes. Dictionaries have dict: followed by sorted
(type name, str key) keys/values. Lists/tuples have type:, length:, entries.
Other values have type:, repr UTF-8, NUL. Matches the independent reference.
"""
import hashlib
import importlib.util
import json
import math
import sys
import torch


def digest_tree(value):
    sha = hashlib.sha256()
    def visit(item):
        if isinstance(item, torch.Tensor):
            sha.update(b'tensor:')
            sha.update(str(item.dtype).encode())
            sha.update(json.dumps(list(item.shape)).encode())
            sha.update(item.detach().cpu().contiguous().numpy().tobytes())
        elif isinstance(item, dict):
            sha.update(b'dict:')
            for key in sorted(item, key=lambda key: (type(key).__name__, str(key))):
                visit(key)
                visit(item[key])
        elif isinstance(item, (tuple, list)):
            sha.update(type(item).__name__.encode() + b':')
            sha.update(str(len(item)).encode() + b':')
            for entry in item:
                visit(entry)
        else:
            sha.update(type(item).__name__.encode() + b':')
            sha.update(repr(item).encode('utf-8') + b'\0')
    visit(value)
    return sha.hexdigest()


def safe(value):
    if isinstance(value, dict):
        return {str(k): safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [safe(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def gradient_evidence(net):
    tree = {n: None if p.grad is None else p.grad.detach() for n, p in net.named_parameters()}
    rows = {}
    for name, p in net.named_parameters():
        g = tree[name]
        rows[name] = {'shape': list(p.shape), 'dtype': str(p.dtype), 'is_none': g is None,
            'sha256': None if g is None else hashlib.sha256(g.cpu().contiguous().numpy().tobytes()).hexdigest(),
            'finite': None if g is None else bool(torch.isfinite(g).all()),
            'nonzero': None if g is None else bool(torch.count_nonzero(g))}
    return {'parameters': rows, 'tree_sha256': digest_tree(tree)}


def segment_kwargs(plan, arm, base):
    config = plan['arms'][arm]
    return {'start': int(base) + config['start_offset'],
        'segment_days': config['segment_days'], 'filter_warmup_days': config['filter_warmup_days']}


def verify_geometry(plan):
    assert len(plan['base_starts']) == 25
    issue_sets = {}
    for arm in ('short', 'long'):
        issues = []
        for base in plan['base_starts']:
            args = segment_kwargs(plan, arm, base)
            count = args['segment_days'] - 3 - args['filter_warmup_days']
            assert count == 102 and args['start'] + args['segment_days'] <= 2557
            issues.extend(range(args['start'] + args['filter_warmup_days'],
                                args['start'] + args['segment_days'] - 3))
        assert len(issues) * 3 == 7650 and len(set(issues)) == 1859
        issue_sets[arm] = issues
    assert issue_sets['short'] == issue_sets['long']


class Selection:
    def __init__(self):
        self.epoch, self.objective, self.patience = 0, math.inf, 0

    def update(self, epoch, objective, eligible=True):
        improved = bool(eligible and objective is not None and math.isfinite(objective)
                        and objective < self.objective)
        if improved:
            self.epoch, self.objective, self.patience = epoch, objective, 0
        elif epoch:
            self.patience += 1
        return improved


KNOWN_CORE_NONFINITE = frozenset(('NaN detected in output of in_FC5',
    'NaN detected in output of out_FC5',
    *('NaN detected in output of '+name for name in ('adjusted_in_Q','out_Q','out_FC6','in_Sigma',
        'out_Sigma','adjusted_in_Sigma','out_FC1','in_FC1','adjusted_in_S','out_S')),
    'NaN detected in input to the linear layer', 'in_FC2 contains Inf values.'))


def numerical_exception(exc):
    if isinstance(exc, FloatingPointError):
        return True
    if type(exc) is ValueError and str(exc) in KNOWN_CORE_NONFINITE:
        tb = exc.__traceback__
        while tb is not None:
            if tb.tb_frame.f_code.co_filename.replace('\\', '/').endswith('/workspace/knet/dl/nn_kalman_clamp_5.py'):
                return True
            tb = tb.tb_next
    return False


def load_checked_module(name, path, read_checked, digest=None):
    raw = read_checked(path, digest)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def stop_status(reason):
    return 'FAILED' if reason == 'DIVERGED' else 'TECHNICAL_FAILURE' if reason == 'TECHNICAL_FAILURE' else 'COMPLETED'


def filter_failure_location(exc, verified_filter=None):
    """Read only the exact checked original function's traceback frame.

    Function-code identity excludes similarly named functions and forged paths.
    The caller supplies the original function only after source SHA verification.
    """
    unavailable = {'filter_local_day': None, 'filter_global_index': None,
        'filter_date': None, 'filter_day_unavailable_reason': 'exception outside verified original filter daily loop'}
    if verified_filter is None:
        unavailable['filter_day_unavailable_reason'] = 'verified original filter not available'
        return unavailable
    tb = exc.__traceback__
    while tb is not None:
        if tb.tb_frame.f_code is verified_filter.__code__:
            local = tb.tb_frame.f_locals
            day, window = local.get('day'), local.get('window')
            if type(day) is not int or window is None:
                unavailable['filter_day_unavailable_reason'] = 'verified filter failed outside its daily iteration'
                return unavailable
            try:
                return {'filter_local_day': day, 'filter_global_index': int(window.global_start) + day,
                    'filter_date': str(window.dates[day]), 'filter_day_unavailable_reason': None}
            except Exception as error:
                return {**unavailable, 'filter_local_day': day,
                    'filter_day_unavailable_reason': 'verified filter window date/index unavailable: '+type(error).__name__}
        tb = tb.tb_next
    return unavailable


def best_effort_failure_save(save, name, value, persistence_errors):
    """Exclusive write failure never replaces the original exception."""
    try:
        return save(name, value)
    except BaseException as error:
        persistence_errors.append({'artifact': name, 'error_type': type(error).__name__, 'error': str(error)})
        return None
