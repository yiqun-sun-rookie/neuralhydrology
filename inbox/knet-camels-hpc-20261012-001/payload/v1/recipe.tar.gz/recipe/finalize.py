"""Reuse reference forecasts; one allowed UKF main trajectory; four-basin report."""
import json,hashlib,time
from pathlib import Path
import numpy as np
import torch
import common as C

def finish():
 # evaluate.py runs as __main__; reuse its definitions without a second import/run.
 import __main__
 # The verified worker uses an explicit execution namespace, so definitions are passed
 # through the already-loaded source once as an inert module for shared scoring helpers.
 import evaluate as E
 binding=json.loads(C.read_checked(C.RUN/'reference_inputs.json'))
 for row in binding['reference_inputs']:
  C.read_checked(Path(row['path']),row['sha256']);C.DIGESTS[str(Path(row['path']).resolve()).lower()]=row['sha256']
 from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
 from global_hydrology.experiments import daily_camels_ukf_knet_parity_runner as parity
 from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
 from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import AccessLedger,CAUSAL_SHARED_SPINUP_MODE
 original_here=C.HERE
 try:
  C.HERE=C.RUN/'02092500'
  spec=get_development_basin_specification('02092500')
  runtime=per.load_per_basin_development_runtime(spec,ledger=AccessLedger(),initialization_mode=CAUSAL_SHARED_SPINUP_MODE,device='cpu')
  knet=E.load_np(binding['knet_main']);physical=E.load_np(binding['physical_main'])
  ks=E.metric(knet['prediction'],knet['target']);ps=E.metric(physical['prediction'],physical['target'])
  E.require_close(ks['mean_mse'],binding['known_main_mse'],'reference Knet MSE');E.require_close(ps['mean_mse'],binding['known_physical_mse'],'reference physical MSE')
  for a in (knet,physical):
   assert np.array_equal(a['issue_indices'],np.arange(2557,3285));assert np.array_equal(a['target_indices'],np.arange(2557,3285)[:,None]+np.arange(1,4))
   assert np.array_equal(a['target_dates_ns'],runtime.dates[a['target_indices']].astype('datetime64[ns]').astype('int64'))
  theta,record=per.load_selected_unscented_kalman_filter_parameters(spec,method='backpropagation')
  pair=C.checked_source('reference_pair_functions',C.RUN/'pair_functions.py')
  ur,ua=E.baseline(runtime,parity,pair,torch.tensor(theta,dtype=torch.float64),'ukf',2557,torch.tensor(physical['initial_state'],dtype=torch.float64),0)
  reference=dict(basin='02092500',role='existing_reference',selected_epoch=binding['selected_epoch'],selected_cold_severe_count=binding['cold_severe_count'],
   main_validation=dict(knet=dict(score=ks,artifact=binding['knet_main']),physical=dict(score=ps,artifact=binding['physical_main']),ukf=ur),
   new_training_runs=0,reused_knet_and_physical_predictions=True,new_ukf_main_trajectories=1)
  C.save('reference_result.json',reference)
 finally:C.HERE=original_here
 new=[json.loads(C.read_checked(C.RUN/b/'evaluation/result.json')) for b in ('04105700','08070200','09035800')]
 table=[]
 for result in [reference]+new:
  row=dict(basin=result['basin'],role=result.get('role','new_basin'),selected_epoch=result['selected_epoch'],severe_cold=result['selected_cold_severe_count'],scores={})
  for method in ('knet','physical','ukf'):row['scores'][method]=result['main_validation'][method].get('score')
  ks=row['scores']['knet'];km=None if ks is None else ks['mean_mse']
  row['relative_mse_improvement']={}
  for method in ('physical','ukf'):
   base=row['scores'][method];bm=None if base is None else base['mean_mse']
   row['relative_mse_improvement'][method]=None if km is None or bm is None or bm<=0 else (bm-km)/bm
  table.append(row)
 aggregate={}
 for method in ('physical','ukf'):
  values=[t['relative_mse_improvement'][method] for t in table[1:]]
  eligible=[bool(x.get('selected_eligible')) and x['training_status']=='COMPLETED' for x in new]
  paired=[v for v in values if v is not None]
  aggregate[method]=dict(improved_count=sum(v is not None and v>0 and ok for v,ok in zip(values,eligible)),denominator=3,
   median_relative_mse_improvement=None if not paired else float(np.median(paired)),finite_pairs=len(paired),scientific_training_failures=sum(not x for x in eligible))
 result=dict(status='SCIENTIFIC_OUTPUTS_COMPLETE',four_basin_table=table,new_basin_aggregate=aggregate,
  new_basins=[r['basin'] for r in new],scope='three selected historical pilots, basin-specific fresh training on development split',
  new_training_attempts=3,new_continuous_knet_trajectories=sum(r['new_knet_continuous_trajectories'] for r in new),
  new_continuous_physical_trajectories=21,new_continuous_ukf_trajectories=21,new_main_ukf_trajectories=4,
  selected_cold_severe_counts={r['basin']:r['selected_cold_severe_count'] for r in new},
  selected_sustained_high_error_counts={r['basin']:r['selected_sustained_high_error_count'] for r in new},
  final_resource_receipt='supervisor_result.json',final_resource_receipt_pending=True)
 def put(name,value):return C.create(str((C.RUN/name).relative_to(C.ROOT)),C.helpers.safe(value))
 put('four_basin_comparison.json',result)
 fmt=lambda v:'不可用' if v is None else f'{v:.6f}'
 pct=lambda v:'不可用' if v is None else f'{100*v:.1f}%'
 text=['# 三个新增流域训练与比较结果','',f"新增 3 个流域中，相对无同化模型改善 {aggregate['physical']['improved_count']}/3，相对固定 UKF 改善 {aggregate['ukf']['improved_count']}/3。",'',
 '| 流域 | 所选轮次 | Knet MSE | 无同化 MSE | UKF MSE | 相对无同化改善 | 相对 UKF 改善 | 严重失稳案例 |',
 '|---|---:|---:|---:|---:|---:|---:|---:|']
 for row in table:
  means=[None if row['scores'][m] is None else row['scores'][m]['mean_mse'] for m in ('knet','physical','ukf')]
  text.append('| '+ ' | '.join([row['basin']+('（原参照）' if row['role']=='existing_reference' else ''),str(row['selected_epoch']),*[fmt(v) for v in means],pct(row['relative_mse_improvement']['physical']),pct(row['relative_mse_improvement']['ukf']),str(row['severe_cold'])+'/7'])+' |')
 text+=['','主表使用相同的 728 个预报起点、1—3 天提前期，MSE 为三个提前期的平均值；改善百分比为正表示误差下降。712 起点结果单列。','',
 '| 流域 | Knet 平均 NSE | 无同化平均 NSE | UKF 平均 NSE |','|---|---:|---:|---:|']
 for row in table:text.append('| '+' | '.join([row['basin']]+[fmt(None if row['scores'][m] is None else row['scores'][m]['mean_nse']) for m in ('knet','physical','ukf')])+' |')
 text+=['',f"新增流域相对无同化的误差改善中位数为 {pct(aggregate['physical']['median_relative_mse_improvement'])}；相对 UKF 为 {pct(aggregate['ukf']['median_relative_mse_improvement'])}。",'','训练与修正诊断：']
 for x in new:
  text.append(f"- {x['basin']}：实际更新 {x['optimizer_steps']} 次，结束原因 {x['training_stop']}；训练汇总误差翻倍 {x['large_increase_history']['training']['count']} 次，验证误差翻倍 {x['large_increase_history']['validation728']['count']} 次；所选模型持续高误差 {x['selected_sustained_high_error_count']}/7。各状态修正量、30/90 天累积和连续正修正见该流域 evaluation 目录。")
 text+=['','三个流域分别从新网络训练，所选权重与最后到达权重均按计划检查，全部训练失败也保留在分母中。本次案例来自既有开发流域，结果支持的范围是这些流域和这套设置，不能据此推断所有 CAMELS 流域。','',
 '白话总结：先看预报是否更准，再看长时间运行是否出问题；单日修正有限幅，仍需结合累积修正与预报误差判断。']
 put('四流域结果说明.md','\n'.join(text).encode('utf-8'))
