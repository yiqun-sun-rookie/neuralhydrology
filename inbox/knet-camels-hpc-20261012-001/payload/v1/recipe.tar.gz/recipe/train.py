"""Matched fresh training. Execution belongs exclusively to reviewed controller.

Import is inert. Each attempt is exclusive; there is intentionally no resume.
"""
import hashlib
import io
import json
import math
import sys
import time
import traceback
import torch
from training_support import (digest_tree, gradient_evidence, load_checked_module,
    numerical_exception, safe, segment_kwargs, Selection, stop_status, verify_geometry,
    filter_failure_location, best_effort_failure_save, capture_segment, training_arrays,
    segment_metadata, capture_validation, compare_validation, verify_fresh, compare_initial_training, update_events, event_history)


def main(arm):
    from common import HERE, ROOT, RUN, PLAN, save, tensor_save, save_arrays, obj, read_checked, setup, build, open_states, checked_source, source_digest, probe, Store, startup_evidence, physical_validation
    if arm != 'long':
        raise ValueError('only long fresh training is authorized')
    assert PLAN['variant'] == '800_day_forward_150_day_backward'
    assert (PLAN['segment_days'], PLAN['cut_before_local_day'], PLAN['backpropagation_days']) == (800,650,150)
    assert PLAN['full_retraining'] is True and PLAN['trained_checkpoint_as_initialization'] is False
    assert (PLAN['learning_rate'], PLAN['weight_decay'], PLAN['gradient_maximum_norm']) == (.0005,0,10)
    assert (PLAN['maximum_updates'],PLAN['early_stop_patience']) == (200,40)
    assert (PLAN['update_loss_post_pre_divergence_ratio'],PLAN['validation_divergence_ratio_vs_physics']) == (100,100)
    launch_manifest = obj('phases/train/source_manifest.json')
    for source in launch_manifest['files']:
        read_checked(HERE/source['path'], source['sha256'])
    verify_geometry(PLAN)
    if (HERE / arm).exists():
        raise FileExistsError('arm output already exists; no overwrite or resume')
    # The exclusive attempt marker is written before any model initialization.
    save(f'{arm}/attempt.json', {'arm': arm, 'status': 'ATTEMPT_STARTED', 'resumable': False})
    plan_sha = hashlib.sha256(read_checked(HERE / 'plan.json')).hexdigest()
    history, steps, net, optimizer, initial_hash = [], 0, None, None, PLAN['initial_parameters_sha256']
    selection = Selection()
    started = time.perf_counter()
    phase, segment_index, segment_start, epoch = 'initialization', None, None, 0
    verified_filter = None
    pre_rows, post_rows, active = [], [], {}
    store = Store()

    def emit(event, **data):
        print(json.dumps(safe({'arm': arm, 'event': event,
            'elapsed_seconds': round(time.perf_counter()-started, 3), **data}),
            ensure_ascii=False, allow_nan=False), flush=True)

    def payload(current_epoch, update_evidence):
        network = {k: v.detach().cpu().clone() for k, v in net.state_dict().items()}
        opt = optimizer.state_dict()
        rng = torch.get_rng_state().clone()
        return {'arm': arm, 'epoch': current_epoch, 'optimizer_steps': steps,
            'seed': PLAN['scope']['seed'], 'network': network, 'optimizer': opt, 'torch_rng_state': rng,
            'parameter_names': [n for n, _ in sorted(net.named_parameters())],
            'parameter_sha256': parity.parameter_sha256(net), 'initial_parameter_sha256': initial_hash,
            'network_sha256': digest_tree(network), 'optimizer_sha256': digest_tree(opt),
            'torch_rng_sha256': digest_tree(rng), 'frozen_plan_sha256': plan_sha,
            'update_evidence': safe(update_evidence), 'update_evidence_sha256': digest_tree(safe(update_evidence)),
            'initialization': 'fresh_basin_specific_network_seed20260922'}

    def record(row):
        # Checkpoint follows validation: its buffers and RNG match the evidence
        # actually bound here, never a subsequently mutated serialized row.
        bound = safe({key: row.get(key) for key in ('epoch', 'optimizer_steps', 'applied_update',
            'training', 'training_arrays', 'pre_segments', 'post_segments', 'large_increase_events', 'selection', 'gradient_norm_before_clip', 'preclip_gradients', 'previous_parameter_sha256',
            'parameter_sha256', 'parameter_maximum_absolute_change', 'phase_at_completion',
            'post_update_training_objective', 'post_update_training_ratio', 'validation', 'failure',
            'numerical_errors', 'failure_location', 'failure_current_state', 'geometry')})
        if row['epoch']:
            row['training_arrays'] = save_arrays(f'{arm}/arrays/epoch_{row["epoch"]:03d}.npz', training_arrays(pre_rows, post_rows, PLAN['base_starts']))
            row['pre_segments'], row['post_segments'] = segment_metadata(pre_rows), segment_metadata(post_rows)
        row['selection'] = {'epoch':selection.epoch,'objective':selection.objective,'patience':selection.patience}
        if row.get('failure'):
            from common import probe
            persistence_errors=[]
            try:
                state={name:getattr(net,name).detach().cpu().clone() for name in
                    (*probe.RECURRENCE_FIELDS,'m1x_prior','KGain','last_correction')
                    if isinstance(getattr(net,name,None),torch.Tensor)}
                row['failure_current_state']=best_effort_failure_save(tensor_save,
                    f'{arm}/failures/epoch_{row["epoch"]:03d}_terminal_state.pt',state,persistence_errors)
            except BaseException as secondary:
                persistence_errors.append({'artifact':'terminal state construction','error':repr(secondary)})
            row['failure_state_persistence_errors']=persistence_errors
        bound = safe({key:row.get(key) for key in bound})
        cp = payload(row['epoch'], bound)
        row['checkpoint_digests'] = {k: cp[k] for k in ('network_sha256', 'optimizer_sha256',
            'torch_rng_sha256', 'frozen_plan_sha256', 'update_evidence_sha256')}
        row['update_evidence_keys'] = list(bound)
        row['checkpoint'] = tensor_save(f'{arm}/checkpoints/epoch_{row["epoch"]:03d}.pt', cp)
        row = safe(row)
        save(f'{arm}/epochs/epoch_{row["epoch"]:03d}.json', row)
        history.append(row)
        emit('epoch_complete', epoch=row['epoch'], optimizer_steps=steps,
            training_objective=(row.get('training') or {}).get('training_objective'),
            validation_objective_728=(row.get('validation') or {}).get('objective_728'),
            best_epoch=selection.epoch, epochs_without_improvement=selection.patience,
            failure=row.get('failure'))

    def checked_validation():
        score = capture_validation(net, runtime, parity, pair, store, f'{arm}/validation/epoch_{epoch:03d}', active, helpers_module=helpers)
        if not all(math.isfinite(float(score[k])) for k in ('objective_728', 'objective_712')):
            raise FloatingPointError('nonfinite validation objective')
        return score

    def numerical_call(operation, failures, label, errors):
        try:
            return operation()
        except Exception as error:
            if not numerical_exception(error):
                raise
            failures.append(label)
            available = {name: getattr(net, name).detach().cpu().clone() for name in
                ('m1x_prior', 'm1x_posterior', 'KGain', 'last_correction')
                if isinstance(getattr(net, name, None), torch.Tensor)}
            persistence_errors = []
            snapshot = best_effort_failure_save(tensor_save,
                f'{arm}/failures/epoch_{epoch:03d}_{len(errors):02d}.pt', available, persistence_errors)
            errors.append({'phase': phase, 'segment_index': segment_index, 'segment_start': segment_start,
                'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc(),
                'available_segment_state': snapshot, 'persistence_errors': persistence_errors,
                **filter_failure_location(error, verified_filter)})
            return None

    def failure_location(failures, errors):
        if not failures:
            return None
        if errors:
            return {key: errors[-1][key] for key in ('filter_local_day', 'filter_global_index',
                'filter_date', 'filter_day_unavailable_reason')}
        return filter_failure_location(FloatingPointError('algorithm check outside filter loop'), verified_filter)

    try:
        helpers=checked_source('basin_original_training_helpers',RUN/'original_training_helpers.py')
        pair=checked_source('basin_pair_functions',RUN/'pair_functions.py')
        runtime,per,parity,settings=setup()
        verified_filter=parity.run_knet_filter
        net=build(runtime,per,parity,settings,epoch=0,requires_grad=True)
        initial_hash=parity.parameter_sha256(net)
        optimizer=torch.optim.Adam(net.parameters(),lr=PLAN['learning_rate'],weight_decay=PLAN['weight_decay'])
        identity=startup_evidence(net,optimizer)
        save(f'{arm}/startup_identity.json',dict(identity,frozen_plan_sha256=plan_sha))
        tensor_save(f'{arm}/initial.pt',payload(0,{'applied_update':False,'phase':'before_validation'}))
        states=open_states()
        val_window=parity.select_window(runtime,'recovery')
        physics=physical_validation(runtime,parity,pair)
        assert math.isfinite(physics['objective_728']) and physics['objective_728']>=0
        emit('fresh_training_started',**identity,maximum_updates=PLAN['maximum_updates'])
        phase = 'initial_validation'
        failures, errors = [], []
        score = numerical_call(checked_validation, failures, 'nonfinite_validation', errors)
        if score and score['objective_728'] > PLAN['validation_divergence_ratio_vs_physics'] * physics['objective_728']:
            failures.append('validation_ratio_vs_open_loop')
        selection.update(0, None if score is None else score['objective_728'], eligible=not failures)
        record({'epoch': 0, 'optimizer_steps': 0, 'applied_update': False, 'validation': score,
            'parameter_sha256': initial_hash, 'previous_parameter_sha256': initial_hash,
            'geometry': PLAN['arms'][arm], 'is_best': not failures, 'epochs_without_improvement': 0,
            'failure': failures, 'numerical_errors': errors, 'failure_location': failure_location(failures, errors)})
        stop_reason = 'DIVERGED' if failures else None
        for epoch in range(1, PLAN['maximum_updates'] + 1):
            if stop_reason:
                break
            epoch_started = time.perf_counter()
            pre_rows, post_rows, active = [], [], {}
            previous_validation = history[-1].get('validation')
            before_hash = parity.parameter_sha256(net)
            before_parameters = {n: p.detach().clone() for n, p in net.named_parameters()}
            net.train()
            optimizer.zero_grad(set_to_none=True)
            failures, errors = [], []
            phase, segment_index, segment_start = 'gradient', 0, None
            completed = 0

            def segment(base):
                nonlocal completed, segment_index, segment_start
                segment_index = completed
                args = segment_kwargs(PLAN, arm, base)
                segment_start = args['start']
                result = capture_segment(net, runtime, parity, args, states,
                    pre_rows if phase == 'gradient' else post_rows, active, training=phase == 'gradient',
                    store=store, prefix=f'{arm}/failures/epoch_{epoch:03d}_{phase}_segment_{segment_index:02d}')
                if any(int(result.target_count_by_lead[k]) != 102 for k in (1, 2, 3)):
                    raise RuntimeError('segment target geometry changed')
                completed += 1
                if completed % 5 == 0:
                    emit('segment_progress', epoch=epoch, phase=phase, completed=completed, total=25)
                return result

            training, saturation, replay_saturation, score = {}, {}, {}, None
            norm, post_objective, post_ratio, applied = None, None, None, False
            result = numerical_call(lambda: helpers._run_with_saturation_tracker(network=net, cap=3.,
                operation=lambda: helpers.backward_equal_segment_objective(starts=PLAN['base_starts'],
                    segment_builder=segment, leads=(1, 2, 3), torch_module=torch)),
                failures, 'nonfinite_training_forward', errors)
            if result is not None:
                training, saturation = result
                assert training['training_forecast_error_events'] == 7650
                if epoch == 1:
                    save(f'{arm}/first_training_forward_identity.json',dict(basin_id=PLAN['scope']['basin'],
                        training_forecast_error_events=7650,actual_update_used=True,duplicate_preflight_update=False,
                        segments=segment_metadata(pre_rows)))
            gradient_tree = {n:None if p.grad is None else p.grad.detach().cpu().clone() for n,p in net.named_parameters()}
            gradient_artifact = tensor_save(f'{arm}/gradients/epoch_{epoch:03d}.pt', gradient_tree)
            gradients = gradient_evidence(net)
            gradients['artifact'] = gradient_artifact
            assert gradients['tree_sha256'] == digest_tree(gradient_tree)
            assert len(gradients['parameters']) == len(list(net.parameters()))
            nonfinite = [n for n, g in gradients['parameters'].items() if g['finite'] is False]
            nonzero = [n for n, g in gradients['parameters'].items() if g['finite'] and g['nonzero']]
            if nonfinite:
                failures.append('nonfinite_gradient')
            if not failures and not nonzero:
                raise RuntimeError('no nonzero gradient')
            if not failures:
                norm = float(torch.nn.utils.clip_grad_norm_(net.parameters(), PLAN['gradient_maximum_norm'],
                    error_if_nonfinite=False).detach().cpu())
                if not math.isfinite(norm):
                    failures.append('nonfinite_gradient_norm')
            if not failures:
                phase = 'optimizer_step'
                optimizer.step()
                steps += 1
                applied = True
                if any(not bool(torch.isfinite(p).all()) for p in net.parameters()):
                    failures.append('nonfinite_parameter')
            if not failures:
                phase, completed = 'post_update_replay', 0
                def replay():
                    with torch.no_grad():
                        return helpers._run_with_saturation_tracker(network=net, cap=3.,
                            operation=lambda: helpers._evaluate_equal_segment_objective(starts=PLAN['base_starts'],
                                segment_builder=segment, allow_nonfinite=True))
                result = numerical_call(replay, failures, 'nonfinite_post_step', errors)
                if result is not None:
                    post_objective, replay_saturation = result
                    if not math.isfinite(post_objective):
                        failures.append('nonfinite_post_step')
                    elif training['training_objective'] > 0:
                        post_ratio = post_objective / training['training_objective']
                        if post_ratio > PLAN['update_loss_post_pre_divergence_ratio']:
                            failures.append('post_step_ratio')
            if not failures:
                phase = 'validation'
                score = numerical_call(checked_validation, failures, 'nonfinite_validation', errors)
                if score and score['objective_728'] > PLAN['validation_divergence_ratio_vs_physics'] * physics['objective_728']:
                    failures.append('validation_ratio_vs_open_loop')
            is_best = selection.update(epoch, None if score is None else score['objective_728'], eligible=not failures)
            after_hash = parity.parameter_sha256(net)
            maximum_change = max(float((p.detach()-before_parameters[n]).abs().max()) for n, p in net.named_parameters())
            record({'epoch': epoch, 'optimizer_steps': steps, 'applied_update': applied,
                'geometry': {**PLAN['arms'][arm], 'base_starts': PLAN['base_starts']},
                'training': training, 'gradient_norm_before_clip': norm, 'preclip_gradients': gradients,
                'finite_gradient_parameter_count': sum(g['finite'] is True for g in gradients['parameters'].values()),
                'nonzero_gradient_parameter_count': len(nonzero), 'nonfinite_gradient_names': nonfinite,
                'training_saturation': saturation, 'post_update_training_objective': post_objective,
                'post_update_training_ratio': post_ratio, 'post_update_saturation': replay_saturation,
                'validation': score, 'parameter_sha256': after_hash, 'previous_parameter_sha256': before_hash,
                'parameter_maximum_absolute_change': maximum_change, 'parameters_changed': after_hash != before_hash,
                'is_best': is_best, 'epochs_without_improvement': selection.patience,
                'failure': failures, 'numerical_errors': errors, 'failure_location': failure_location(failures, errors),
                'large_increase_events': update_events(training, post_objective, pre_rows, post_rows, previous_validation, score),
                'phase_at_completion': phase, 'epoch_seconds': time.perf_counter()-epoch_started})
            if failures:
                stop_reason = 'DIVERGED'
            elif selection.patience >= PLAN['early_stop_patience']:
                stop_reason = 'EARLY_STOP'
        stop_reason = stop_reason or 'CEILING'
        best = next(row for row in history if row['epoch'] == selection.epoch)
        summary = {'arm': arm, 'stop_reason': stop_reason, 'optimizer_steps': steps,
            'last_epoch': history[-1]['epoch'], 'best_epoch': selection.epoch,
            'best_validation': best['validation'], 'best_checkpoint': best['checkpoint'],
            'best_parameter_sha256': best['parameter_sha256'], 'initial_parameter_sha256': initial_hash,
            'selected_parameters_changed': best['parameter_sha256'] != initial_hash,
            'last_parameter_sha256': parity.parameter_sha256(net), 'wall_seconds': time.perf_counter()-started,
            'terminal_failure': history[-1]['failure'], 'scientific_training_status': stop_status(stop_reason),
            'large_increase_history':event_history(history), 'variant':PLAN['variant'],
            'old_checkpoint_used': False, 'cold_start_cases_used_for_selection': False,
            'frozen_plan_sha256': plan_sha, 'validation_reconstruction': {
                'runtime': 'common.setup frozen development runtime', 'window': 'parity.select_window recovery',
                'initial': 'window.initial_state', 'previous_observation': 'parity.previous_observation_before_window',
                'date_source': 'runtime.dates; frozen source_manifest.json', 'main_score_source': 'actual saved validation forecast arrays'}}
        save(f'{arm}/history.json', history)
        save(f'{arm}/summary.json', safe(summary))
        emit('training_finished', **summary)
    except BaseException as error:
        failure = {'arm': arm, 'status': 'TECHNICAL_FAILURE', 'scientific_training_status': 'TECHNICAL_FAILURE',
            'optimizer_steps': steps, 'attempted_epoch': epoch, 'phase': phase,
            'segment_index': segment_index, 'segment_start': segment_start,
            'error_type': type(error).__name__, 'error': str(error), 'traceback': traceback.format_exc(),
            'last_completed_epoch': history[-1]['epoch'] if history else None,
            **filter_failure_location(error, verified_filter)}
        persistence_errors = []
        if pre_rows or post_rows:
            try:
                best_effort_failure_save(save_arrays, f'{arm}/technical_failure_arrays.npz',
                    training_arrays(pre_rows,post_rows,PLAN['base_starts']), persistence_errors)
                best_effort_failure_save(save, f'{arm}/technical_failure_segments.json',
                    safe({'pre':segment_metadata(pre_rows),'post':segment_metadata(post_rows),'active':active}), persistence_errors)
            except BaseException as secondary:
                persistence_errors.append({'artifact':'partial array construction','error':repr(secondary)})
        # Save small original metadata first; checkpoint serialization may fail.
        best_effort_failure_save(save, f'{arm}/technical_failure.json', dict(failure), persistence_errors)
        # Each construction is independent of checkpoint/payload construction.
        # Missing capture entries have explicit errors; they are never relabelled None.
        current_evidence = {'gradients': {}, 'recurrence': {}}
        if net is not None:
            try:
                for name, parameter in net.named_parameters():
                    try:
                        current_evidence['gradients'][name] = (
                            None if parameter.grad is None else parameter.grad.detach().cpu().clone())
                    except BaseException as secondary:
                        persistence_errors.append({'artifact':'current gradient '+name,
                            'error_type':type(secondary).__name__,'error':str(secondary)})
            except BaseException as secondary:
                persistence_errors.append({'artifact':'current named parameter enumeration',
                    'error_type':type(secondary).__name__,'error':str(secondary)})
            for name in dict.fromkeys((*probe.RECURRENCE_FIELDS,'m1x_prior','KGain','last_correction')):
                try:
                    value = getattr(net,name)
                    if not isinstance(value,torch.Tensor):
                        raise TypeError('current recurrence/extra field is not a tensor')
                    current_evidence['recurrence'][name] = value.detach().cpu().clone()
                except BaseException as secondary:
                    persistence_errors.append({'artifact':'current recurrence '+name,
                        'error_type':type(secondary).__name__,'error':str(secondary)})
        try:
            current_evidence['torch_rng_state'] = torch.get_rng_state().clone()
        except BaseException as secondary:
            persistence_errors.append({'artifact':'current torch random state',
                'error_type':type(secondary).__name__,'error':str(secondary)})
        failure['current_failed_state'] = best_effort_failure_save(tensor_save,
            f'{arm}/technical_failure_evidence.pt', current_evidence, persistence_errors)
        if net is not None and optimizer is not None:
            try:
                current = payload(epoch, {'applied_update': steps > (history[-1]['optimizer_steps'] if history else 0),
                    'phase': phase, 'incomplete_attempt': True})
                failure['current_checkpoint'] = best_effort_failure_save(tensor_save,
                    f'{arm}/technical_failure_current.pt', current, persistence_errors)
                available = {name: getattr(net, name).detach().cpu().clone() for name in
                    ('m1x_prior', 'm1x_posterior', 'KGain', 'last_correction')
                    if isinstance(getattr(net, name, None), torch.Tensor)}
                failure['available_segment_state'] = best_effort_failure_save(tensor_save,
                    f'{arm}/technical_failure_segment.pt', available, persistence_errors)
            except BaseException as secondary:
                persistence_errors.append({'artifact': 'current checkpoint construction',
                    'error_type': type(secondary).__name__, 'error': str(secondary)})
        # Technical-specific paths always preserve canonical completed evidence.
        best_effort_failure_save(save, f'{arm}/technical_failure_history.json', history, persistence_errors)
        for name, value in (('history.json', history), ('summary.json', dict(failure))):
            try:
                if not (HERE / arm / name).exists():
                    best_effort_failure_save(save, f'{arm}/{name}', value, persistence_errors)
            except BaseException as secondary:
                persistence_errors.append({'artifact': name+' existence check',
                    'error_type': type(secondary).__name__, 'error': str(secondary)})
        failure['persistence_errors'] = persistence_errors
        best_effort_failure_save(save, f'{arm}/technical_failure_details.json', dict(failure), persistence_errors)
        best_effort_failure_save(save, f'{arm}/technical_failure_summary.json', dict(failure), persistence_errors)
        try:
            emit('technical_failure', error=failure['error'], error_type=failure['error_type'])
        except BaseException:
            pass
        raise


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('usage: train.py long')
    main('long')
