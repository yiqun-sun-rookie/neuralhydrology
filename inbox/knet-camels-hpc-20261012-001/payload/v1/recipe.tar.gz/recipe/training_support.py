"""Pure added training semantics and scoped original observation utilities."""
from contextlib import contextmanager
import json, math
import numpy as np
import torch
from common import helpers, diag, probe

# Reuse the checked proven original implementations without altered arithmetic.
digest_tree = helpers.digest_tree
gradient_evidence = helpers.gradient_evidence
load_checked_module = helpers.load_checked_module
numerical_exception = helpers.numerical_exception
safe = helpers.safe
segment_kwargs = helpers.segment_kwargs
Selection = helpers.Selection
stop_status = helpers.stop_status
verify_geometry = helpers.verify_geometry
filter_failure_location = helpers.filter_failure_location
best_effort_failure_save = helpers.best_effort_failure_save

@contextmanager
def validation_observer(parity):
    """Observe original results and actual score input pairs, without alteration."""
    names = ('run_knet_filter', 'aligned_forecasts_from_posterior', 'forecast_pairs')
    originals = {name: getattr(parity,name) for name in names}
    captured = {name: [] for name in names}
    captured['_inputs'] = {name: [] for name in names}
    captured['_failed'] = {}
    def wrap(name):
        def observe(*args, **kwargs):
            captured['_inputs'][name].append((args, kwargs))
            try:
                result = originals[name](*args, **kwargs)
            except BaseException as error:
                try:
                    captured['_failed'][name] = exception_locals(error, originals[name],
                        ('day','priors','posteriors','requested_corrections','realized_corrections',
                         'valid_updates','posterior','controls','observation'))
                except BaseException:
                    pass
                raise
            captured[name].append(result)
            return result
        return observe
    try:
        for name in names: setattr(parity,name,wrap(name))
        yield captured
    finally:
        for name in names: setattr(parity,name,originals[name])


def exception_locals(error, function, names):
    """Observe only the failing original function's actual traceback frame."""
    code = getattr(function, '__code__', None)
    tb = error.__traceback__
    while tb is not None:
        if tb.tb_frame.f_code is code:
            return {name: tb.tb_frame.f_locals[name] for name in names if name in tb.tb_frame.f_locals}
        tb = tb.tb_next
    return {}


def failure_write(store, name, value, artifacts, errors, arrays=False, tensors=False):
    """Evidence recording cannot replace a pending original exception."""
    try:
        operation = store.arrays if arrays else store.tensors if tensors else store.json
        artifacts[name] = operation(name,value)
    except BaseException as secondary:
        try:
            errors.append(dict(artifact=name,type=type(secondary).__name__,message=str(secondary)))
            print(json.dumps(dict(event='partial_evidence_persistence_failure',artifact=name,
                                  secondary_error=repr(secondary))),flush=True)
        except BaseException:
            pass


def persist_validation_partial(capture, window, runtime, rng_before, store, prefix, error):
    """Save observed arrays only; never rerun filtering, alignment or scoring."""
    arrays = dict(dates=np.asarray(window.dates).astype('datetime64[ns]').astype(np.int64),
        global_indices=np.arange(window.global_start,window.global_start+len(window.dates)),
        observations=window.observations.detach().cpu().numpy().copy())
    tensors = dict(torch_rng_before=rng_before,torch_rng_after=torch.get_rng_state(),partial_filter={})
    for index,trace in enumerate(capture['run_knet_filter']):
        for field in ('prior_states','posterior_states','requested_corrections','corrections','valid_updates'):
            value=getattr(trace,field,None)
            if isinstance(value,torch.Tensor): arrays[f'trace_{index}_{field}']=value.detach().cpu().numpy().copy()
    partial=capture['_failed'].get('run_knet_filter',{})
    for field,value in partial.items():
        if isinstance(value,torch.Tensor):
            tensors['partial_filter'][field]=value.detach().cpu().clone()
            arrays['partial_filter_'+field]=value.detach().cpu().numpy().copy()
        elif isinstance(value,list):
            tensors['partial_filter'][field]=[x.detach().cpu().clone() if isinstance(x,torch.Tensor) else x for x in value]
            if value:
                arrays['partial_filter_'+field]=np.stack([x.detach().cpu().numpy() if isinstance(x,torch.Tensor) else x for x in value])
        elif isinstance(value,(int,bool)): tensors['partial_filter'][field]=value
    for index,predictions in enumerate(capture['aligned_forecasts_from_posterior']):
        for lead,value in predictions.items(): arrays[f'aligned_{index}_lead{lead}']=np.asarray(value).copy()
    input_meta=[]
    for index,(args,kwargs) in enumerate(capture['_inputs']['forecast_pairs']):
        observations,predictions=args[:2]
        observations=(observations.detach().cpu().numpy() if isinstance(observations,torch.Tensor) else np.asarray(observations))
        arrays[f'pair_input_{index}_observations']=observations.copy()
        for lead,value in predictions.items(): arrays[f'pair_input_{index}_aligned_lead{lead}']=np.asarray(value).copy()
        input_meta.append(dict(index=index,issue_start=kwargs.get('issue_start'),issue_end=kwargs.get('issue_end'),
                               leads=list(kwargs.get('leads',(1,2,3)))))
    for index,pairs in enumerate(capture['forecast_pairs']):
        for field in ('predictions','targets','issue_indices','target_indices','finite_masks'):
            for lead,value in getattr(pairs,field).items():
                arrays[f'pair_result_{index}_{field}_lead{lead}']=np.asarray(value).copy()
    artifacts,errors={},[]
    failure_write(store,prefix+'_partial.npz',arrays,artifacts,errors,arrays=True)
    failure_write(store,prefix+'_partial.pt',tensors,artifacts,errors,tensors=True)
    metadata=dict(status='ORIGINAL_VALIDATION_EXCEPTION',exception_type=type(error).__name__,
        exception_message=str(error),global_start=window.global_start,dates_count=len(window.dates),
        filter_local_day=partial.get('day'),
        filter_global_day=None if partial.get('day') is None else window.global_start+partial['day'],
        filter_date=None if partial.get('day') is None else str(window.dates[partial['day']]),
        completed_calls={name:len(capture[name]) for name in
                         ('run_knet_filter','aligned_forecasts_from_posterior','forecast_pairs')},
        failed_functions=list(capture['_failed']),pair_inputs=input_meta,artifacts=dict(artifacts),persistence_errors=errors,
        interpretation='Original returned traces, original failed-filter locals and exact pairing inputs; no replacement forecast or score.')
    failure_write(store,prefix+'_partial.json',metadata,artifacts,errors)
    return dict(artifacts=artifacts,persistence_errors=errors)


def capture_validation(net, runtime, parity, pair, store, prefix, active=None, helpers_module=None):
    window = parity.select_window(runtime, 'recovery')
    rng_before = torch.get_rng_state().clone()
    capture=None
    try:
        with validation_observer(parity) as capture:
            score = pair.validation(net,runtime,parity,window,helpers_module)
    except BaseException as error:
        try:
            result=persist_validation_partial(capture,window,runtime,rng_before,store,prefix,error)
            if active is not None: active['validation_failure_evidence']=result
        except BaseException as secondary:
            try:
                if active is not None: active['validation_persistence_error']=repr(secondary)
                print(json.dumps(dict(event='validation_partial_capture_failure',secondary_error=repr(secondary))),flush=True)
            except BaseException:
                pass
        raise
    assert [len(capture[n]) for n in ('run_knet_filter','aligned_forecasts_from_posterior','forecast_pairs')] == [1,1,2], 'original validation call coverage differs'
    trace = capture['run_knet_filter'][0]
    arrays = dict(states=trace.posterior_states.detach().cpu().numpy().copy(),
                  priors=trace.prior_states.detach().cpu().numpy().copy(),
                  corrections=trace.corrections.detach().cpu().numpy().copy(),
                  requested_corrections=trace.requested_corrections.detach().cpu().numpy().copy(),
                  dates=np.asarray(window.dates).astype('datetime64[ns]').astype(np.int64))
    for label, pairs, count in zip(('728','712'), capture['forecast_pairs'], (728,712)):
        for lead in (1,2,3):
            key=label+'_lead'+str(lead)
            assert len(pairs.predictions[lead]) == count and pairs.finite_masks[lead].all()
            arrays[key+'_forecast'] = pairs.predictions[lead].copy()
            arrays[key+'_target'] = pairs.targets[lead].copy()
            issue=pairs.issue_indices[lead]+window.global_start
            target=pairs.target_indices[lead]+window.global_start
            arrays[key+'_issue_indices'], arrays[key+'_target_indices'] = issue, target
            arrays[key+'_issue_dates'] = np.asarray(runtime.dates)[issue].astype('datetime64[ns]').astype(np.int64)
            arrays[key+'_target_dates'] = np.asarray(runtime.dates)[target].astype('datetime64[ns]').astype(np.int64)
    score['artifacts'] = dict(arrays=store.arrays(prefix+'.npz',arrays),
        state=store.tensors(prefix+'.pt',dict(network=net.state_dict(),torch_rng_before=rng_before,
            torch_rng_after=torch.get_rng_state(),recurrence={n:getattr(net,n).detach().cpu().clone() for n in probe.RECURRENCE_FIELDS})))
    store.json(prefix+'.json',score)
    return score


def compare_validation(actual, expected):
    for key in ('objective_728','objective_712'):
        assert math.isfinite(actual[key]) and abs(actual[key]-expected[key]) <= 1e-12, 'validation identity mismatch: '+key
    for key in ('mse_by_lead_728','mse_by_lead_712','count_by_lead_728','count_by_lead_712','nse_by_lead_712'):
        for lead,value in expected[key].items():
            assert abs(actual[key][lead]-value) <= 1e-12, 'validation component mismatch: '+key


def verify_fresh(net, optimizer, rng, checkpoint, parameter_hash, expected_hash):
    if checkpoint.get('epoch') != 0 or checkpoint.get('optimizer_steps') != 0:
        raise RuntimeError('original reference is not untrained epoch zero')
    if optimizer.state_dict()['state'] or checkpoint['optimizer']['state']:
        raise RuntimeError('fresh optimizer must have empty moments')
    for label, actual, expected in (
        ('network', net.state_dict(), checkpoint['network']),
        ('optimizer', optimizer.state_dict(), checkpoint['optimizer']),
        ('torch_rng', rng, checkpoint['torch_rng_state'])):
        if digest_tree(actual) != digest_tree(expected):
            raise RuntimeError('fresh '+label+' differs from original untrained start')
    if parameter_hash != expected_hash:
        raise RuntimeError('fresh initial parameter hash differs')


def compare_initial_training(actual, expected):
    differences = {'training_objective':abs(actual['training_objective']-expected['training_objective'])}
    for lead in ('1','2','3'):
        differences['lead'+lead] = abs(actual['training_mse_by_lead'][lead]-expected['training_mse_by_lead'][lead])
    if any(not math.isfinite(value) or value>1e-12 for value in differences.values()):
        raise RuntimeError('initial25-segment forward objective differs from original: '+repr(differences))
    for key in ('training_target_count_by_lead','training_forecast_error_events','segment_count'):
        if actual[key] != expected[key]:
            raise RuntimeError('initial training geometry differs: '+key)
    return {'absolute_tolerance':1e-12,'absolute_differences':differences,
            'actual':actual,'expected':expected,'verified_before_first_optimizer_step':True}


@contextmanager
def checked_cut(net, start, dates, active, cut=True):
    """Checked original ten-field cut, once before local day650; no value reset."""
    status = {'steps': 0, 'cut_invocations': 0, 'cut_local_day': None}
    def detach(network):
        if status['steps'] != 650 or status['cut_invocations']:
            raise RuntimeError('cut invocation differs from day650 once')
        probe.detach_recurrence(network)
        status['cut_invocations'] += 1
        status['cut_local_day'] = status['steps']
    def after_step(network):
        status['steps'] += 1
    with diag.analysis_observer(net, 650 if cut else -1, detach, active, start, dates, after_step):
        yield status
    # An original exception is propagated before coverage checks.
    if status['steps'] != 800 or status['cut_invocations'] != int(cut):
        raise RuntimeError('actual segment step/cut coverage differs: '+repr(status))


@contextmanager
def actual_segment_forecasts(runtime, args, row):
    """Record exact returned original multilead_torch values, before its score guards."""
    module = runtime.tukf06_module
    original = module.multilead_torch
    calls = 0
    start, warmup, end = args['start'], args['filter_warmup_days'], args['segment_days']-3
    def observed(*positional, **keywords):
        nonlocal calls
        raw = original(*positional, **keywords)
        calls += 1
        if calls != 1:
            raise RuntimeError('actual training forecast called repeatedly')
        predictions, targets, target_indices = [], [], []
        for lead in (1, 2, 3):
            forecast, indices = raw[lead]
            idx = indices[warmup:end]
            predictions.append(forecast[warmup:end].detach().cpu().numpy().copy())
            targets.append(runtime.observations[start+idx, 0].detach().cpu().numpy().copy())
            target_indices.append(idx.detach().cpu().numpy().copy()+start)
        row['forecasts'] = np.stack(predictions, axis=1)
        row['targets'] = np.stack(targets, axis=1)
        row['target_indices'] = np.stack(target_indices, axis=1)
        row['issue_indices'] = np.arange(start+warmup, start+end, dtype=np.int64)
        if row['forecasts'].shape != (102, 3) or row['targets'].shape != (102, 3):
            raise RuntimeError('actual segment forecast geometry differs')
        expected = row['issue_indices'][:, None]+np.arange(1,4)[None,:]
        if not np.array_equal(row['target_indices'], expected):
            raise RuntimeError('original forecast target indices differ')
        dates = np.asarray(runtime.dates).astype('datetime64[ns]').astype(np.int64)
        row['issue_dates'] = dates[row['issue_indices']].copy()
        row['target_dates'] = dates[row['target_indices']].copy()
        return raw
    module.multilead_torch = observed
    try:
        yield
    finally:
        module.multilead_torch = original


def capture_segment(net, runtime, parity, args, states, rows, active, training, store=None, prefix=None):
    row = {'start': args['start'], 'index': len(rows), 'objective': None,
           'mse_by_lead': None, 'count_by_lead': None}
    rows.append(row)
    coverage = None
    try:
        with checked_cut(net, args['start'], runtime.dates[args['start']:args['start']+800], active, cut=training) as coverage:
            with actual_segment_forecasts(runtime, args, row):
                result = parity.segment_multilead_mse(net, runtime, **args, open_loop_states=states)
        if 'forecasts' not in row:
            raise RuntimeError('missing original forecast observation')
        row.update(objective=float(result.objective.detach().cpu()),
                   mse_by_lead={str(k):float(result.mse_by_lead[k].detach().cpu()) for k in (1,2,3)},
                   count_by_lead={str(k):int(result.target_count_by_lead[k]) for k in (1,2,3)})
        return result
    except BaseException as error:
        row['exception'] = {'type':type(error).__name__, 'message':str(error)}
        if store is not None:
            artifacts, persistence_errors = {}, []
            try:
                def clone(value):
                    if isinstance(value,torch.Tensor): return value.detach().cpu().clone()
                    if isinstance(value,list): return [clone(v) for v in value]
                    return value
                partial = exception_locals(error,parity.run_knet_filter,
                    ('day','priors','posteriors','requested_corrections','realized_corrections','valid_updates'))
                snapshot = {'actual_filter_partial':{k:clone(v) for k,v in partial.items()},
                            'recurrence':{n:clone(getattr(net,n)) for n in probe.RECURRENCE_FIELDS},
                            'gradients':{n:None if p.grad is None else clone(p.grad) for n,p in net.named_parameters()},
                            'torch_rng_state':torch.get_rng_state().clone()}
                failure_write(store,prefix+'_partial.pt',snapshot,artifacts,persistence_errors,tensors=True)
                failure_write(store,prefix+'_partial.npz',
                    {k:v for k,v in row.items() if isinstance(v,np.ndarray)},artifacts,persistence_errors,arrays=True)
            except BaseException as secondary:
                persistence_errors.append({'artifact':'partial segment construction','error':repr(secondary)})
            row['failure_artifacts'],row['persistence_errors'] = artifacts,persistence_errors
        raise
    finally:
        row['coverage'] = dict(coverage or {})


def segment_metadata(rows):
    return [{key:value for key,value in row.items() if not isinstance(value,np.ndarray)} for row in rows]


def training_arrays(pre, post, starts):
    """Incomplete segments retain explicit masks and any actually returned arrays."""
    bundle = {'starts':np.asarray(starts,dtype=np.int64), 'leads':np.arange(1,4,dtype=np.int64)}
    fields = ('forecasts','targets','target_indices','issue_indices','issue_dates','target_dates')
    for phase, rows in (('pre',pre),('post',post)):
        bundle[phase+'_observed'] = np.asarray(['forecasts' in r for r in rows]+[False]*(25-len(rows)),dtype=bool)
        bundle[phase+'_scored'] = np.asarray([r.get('objective') is not None for r in rows]+[False]*(25-len(rows)),dtype=bool)
        for field in fields:
            shape = (25,102) if field in ('issue_indices','issue_dates') else (25,102,3)
            integer = field not in ('forecasts','targets')
            values = np.full(shape,-1 if integer else np.nan,dtype=np.int64 if integer else np.float64)
            for index,row in enumerate(rows):
                if field in row: values[index] = row[field]
            bundle[phase+'_'+field] = values
    return bundle


def descriptive_change(before, after):
    if before is None or after is None or not math.isfinite(before) or not math.isfinite(after):
        return {'before':before,'after':after,'ratio':None,'large_increase':False,'available':False}
    ratio = None if before == 0 else after/before
    return {'before':before,'after':after,'ratio':ratio,'available':True,
            'zero_baseline_positive_after':bool(before==0 and after>0),
            'large_increase':bool(after>0 if before==0 else ratio>=2)}


def update_events(training, post, pre_rows, post_rows, previous_validation, score):
    aggregate = descriptive_change(training.get('training_objective'), post)
    segments = [{'index':a['index'],'start':a['start'],
                 **descriptive_change(a.get('objective'),b.get('objective'))}
                for a,b in zip(pre_rows,post_rows)]
    validation = {label:descriptive_change(None if previous_validation is None else previous_validation['objective_'+label],
                    None if score is None else score['objective_'+label]) for label in ('728','712')}
    return {'training':aggregate,'segments':segments,'validation':validation,
            'descriptive_only':True,'threshold_ratio':2.0}


def event_history(history):
    results = {}
    for category in ('training','segments','validation728','validation712'):
        seen=[]
        for row in history:
            events=row.get('large_increase_events') or {}
            values=events.get('segments',[]) if category=='segments' else [events.get('validation',{}).get(category[10:],{})] if category.startswith('validation') else [events.get(category,{})]
            for value in values:
                if value.get('available'):
                    seen.append({'epoch':row['epoch'],**value})
        flagged=[r for r in seen if r['large_increase']]
        finite=[r for r in seen if r.get('ratio') is not None]
        results[category]={'count':len(flagged),'first':flagged[0] if flagged else None,
                           'maximum_ratio':max(finite,key=lambda r:r['ratio']) if finite else None}
    return results

