from __future__ import annotations
import math
from typing import Any, Callable, Mapping, Sequence

def backward_equal_segment_objective(
    *,
    starts: Sequence[int],
    segment_builder: Callable[[int], Any],
    leads: Sequence[int],
    torch_module: Any,
) -> Mapping[str, Any]:
    """Accumulate equal segment gradients without adding optimizer updates."""

    ordered_starts = tuple(int(value) for value in starts)
    ordered_leads = tuple(int(value) for value in leads)
    if not ordered_starts or not ordered_leads:
        raise ValueError("gradient accumulation requires segments and leads")
    segment_objectives: list[float] = []
    mse_by_lead: dict[int, list[float]] = {lead: [] for lead in ordered_leads}
    counts_by_lead: dict[int, int] = {lead: 0 for lead in ordered_leads}
    for start in ordered_starts:
        segment = segment_builder(start)
        if set(segment.mse_by_lead) != set(ordered_leads) or set(
            segment.target_count_by_lead
        ) != set(ordered_leads):
            raise ValueError("segment lead geometry changed")
        if not bool(torch_module.isfinite(segment.objective)):
            raise FloatingPointError("segment objective is non-finite")
        objective = float(segment.objective.detach().cpu())
        segment_objectives.append(objective)
        for lead in ordered_leads:
            count = int(segment.target_count_by_lead[lead])
            if count <= 0:
                raise ValueError("segment contains no finite target")
            counts_by_lead[lead] += count
            mse_by_lead[lead].append(
                float(segment.mse_by_lead[lead].detach().cpu())
            )
        (segment.objective / len(ordered_starts)).backward()
        del segment
    return {
        "training_objective": math.fsum(segment_objectives)
        / len(segment_objectives),
        "training_mse_by_lead": {
            str(lead): math.fsum(mse_by_lead[lead]) / len(mse_by_lead[lead])
            for lead in ordered_leads
        },
        "training_target_count_by_lead": {
            str(lead): counts_by_lead[lead] for lead in ordered_leads
        },
        "training_forecast_error_events": sum(counts_by_lead.values()),
        "segment_count": len(ordered_starts),
    }

def _evaluate_equal_segment_objective(
    *,
    starts: Sequence[int],
    segment_builder: Callable[[int], Any],
    allow_nonfinite: bool = False,
) -> float:
    values: list[float] = []
    for start in starts:
        segment = segment_builder(int(start))
        value = float(segment.objective.detach().cpu())
        if not math.isfinite(value) and not allow_nonfinite:
            raise FloatingPointError("post-step segment objective is non-finite")
        values.append(value)
    return math.fsum(values) / len(values)

class CorrectionSaturationTracker:
    """Count capped state-step pairs without modifying the wrapped analysis graph."""

    def __init__(self, *, network: Any, cap_in_state_scale_units: float) -> None:
        cap = float(cap_in_state_scale_units)
        if not math.isfinite(cap) or cap <= 0.0:
            raise ValueError("correction cap must be positive and finite")
        dimension = int(network.state_feature_scale.numel())
        self.network = network
        self.cap = cap
        self.count_by_state = [0] * dimension
        self.analysis_step_count = 0

    def reset(self) -> None:
        self.count_by_state = [0] * len(self.count_by_state)
        self.analysis_step_count = 0

    def wrap_analysis_step(self, analysis_step: Callable[..., Any]) -> Callable[..., Any]:
        def wrapped(*args: Any, **kwargs: Any) -> Any:
            result = analysis_step(*args, **kwargs)
            correction = self.network.last_correction.detach()
            scale = getattr(self.network, "state_correction_scale", self.network.state_feature_scale).detach()
            saturated = (
                (correction / scale).abs() >= self.cap * (1.0 - 1e-9)
            ).reshape(-1, len(self.count_by_state))
            counts = saturated.sum(dim=0).cpu().tolist()
            self.count_by_state = [
                current + int(increment)
                for current, increment in zip(self.count_by_state, counts, strict=True)
            ]
            self.analysis_step_count += int(saturated.shape[0])
            return result

        return wrapped

    def snapshot(self) -> dict[str, object]:
        total = sum(self.count_by_state)
        denominator = self.analysis_step_count * len(self.count_by_state)
        return {
            "saturation_count_by_state": list(self.count_by_state),
            "saturation_count": total,
            "analysis_step_count": self.analysis_step_count,
            "saturation_denominator": denominator,
            "saturation_fraction": total / denominator if denominator else 0.0,
        }

def _run_with_saturation_tracker(
    *, network: Any, cap: float, operation: Callable[[], Any]
) -> tuple[Any, dict[str, object]]:
    tracker = CorrectionSaturationTracker(
        network=network, cap_in_state_scale_units=cap
    )
    original = network.analysis_step
    network.analysis_step = tracker.wrap_analysis_step(original)
    try:
        result = operation()
    finally:
        network.analysis_step = original
    return result, tracker.snapshot()

