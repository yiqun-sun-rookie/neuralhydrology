"""Frozen development-only identities for the three per-basin KalmanNet pilots."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import PurePosixPath

from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import (
    ALLOWED_ARCHIVE_MEMBERS,
    CAUSAL_SHARED_SPINUP_MODE,
)


PILOT_BASIN_ORDER = ("04105700", "08070200", "09035800")
DEVELOPMENT_EXPERIMENT_FAMILY = (
    "DAILY_CAMELS_KNET_PER_BASIN_21_DEVELOPMENT_V2_20260908"
)
DEVELOPMENT_BASIN_ORDER = (
    "04105700",
    "08190500",
    "02102908",
    "12447390",
    "01487000",
    "02178400",
    "08070200",
    "09513780",
    "06803510",
    "03076600",
    "12175500",
    "09035800",
    "04027000",
    "08109700",
    "08086290",
    "01440400",
    "05503800",
    "03049000",
    "01435000",
    "02092500",
    "14185900",
)
DEVELOPMENT_TRAINING_BASIN_ORDER = tuple(
    basin_id
    for basin_id in DEVELOPMENT_BASIN_ORDER
    if basin_id not in PILOT_BASIN_ORDER
)
ALLOWED_STATE_DIMENSIONS = (7, 11, 18)
DEVELOPMENT_START = "1999-10-01"
DEVELOPMENT_END = "2008-09-30"
TRAINING_END = "2006-09-30"
VALIDATION_START = "2006-10-01"
EXPECTED_DAYS = 3288
TRAINING_DAYS = 2557
LEADS = (1, 2, 3)
FILTER_WARMUP_DAYS = 16
VALIDATION_DAYS = 731
CHECKPOINT_TARGET_COUNT_PER_LEAD = 728
REPORTING_TARGET_COUNT_PER_LEAD = 712
OFFICIAL_KALMANNET_SOURCE = "knet/dl/nn_kalman_clamp_5.py"
OFFICIAL_KALMANNET_SHA256 = (
    "934570d3c840e9d57b8fbddf3a018dc29e190cdd712fc9daaf442e383f74d843"
)
FULL_STATE_ADAPTER = "src/global_hydrology/models/knet_native_hbvlite_full_state.py"
FULL_STATE_ADAPTER_SHA256 = (
    "3eb80fc1346a3e86170cac28fecad29951fe938193967e6a8cf6ae705edc22da"
)


@dataclass(frozen=True)
class PilotBasinSpecification:
    """One immutable basin, input, selection, and exact-state contract."""

    basin_id: str
    state_dimension: int
    archive_path: str
    archive_size_bytes: int
    archive_sha256: str
    selection_path: str
    selection_size_bytes: int
    selection_sha256: str
    historical_evaluation_access_authorized: bool = False
    development_start: str = DEVELOPMENT_START
    development_end: str = DEVELOPMENT_END
    expected_days: int = EXPECTED_DAYS
    training_days: int = TRAINING_DAYS
    leads: tuple[int, ...] = LEADS
    archive_members: tuple[str, ...] = tuple(sorted(ALLOWED_ARCHIVE_MEMBERS))
    diagnostic_window_days: int = 128
    recovery_window_days: int = VALIDATION_DAYS
    filter_warmup_days: int = FILTER_WARMUP_DAYS
    expected_diagnostic_target_count_per_lead: int = 109
    expected_recovery_target_count_per_lead: int = REPORTING_TARGET_COUNT_PER_LEAD
    scientific_initialization_mode: str = CAUSAL_SHARED_SPINUP_MODE
    archive_array_content_sha256: str | None = None

    def __post_init__(self) -> None:
        if self.basin_id not in DEVELOPMENT_BASIN_ORDER:
            raise ValueError("basin is not in the registered pilot/development union")
        if self.state_dimension not in ALLOWED_STATE_DIMENSIONS:
            raise ValueError("state dimension must be exactly 7, 11, or 18")
        if self.historical_evaluation_access_authorized:
            raise PermissionError("historical evaluation access must remain unauthorized")
        if (self.development_start, self.development_end) != (
            DEVELOPMENT_START,
            DEVELOPMENT_END,
        ):
            raise ValueError("development dates changed")
        if self.expected_days != EXPECTED_DAYS or self.training_days != TRAINING_DAYS:
            raise ValueError("development or training length changed")
        if self.leads != LEADS:
            raise ValueError("forecast leads must remain 1, 2, and 3 days")
        if self.filter_warmup_days != FILTER_WARMUP_DAYS:
            raise ValueError("filter warm-up must remain 16 days")
        if self.expected_recovery_target_count_per_lead != REPORTING_TARGET_COUNT_PER_LEAD:
            raise ValueError("reporting geometry must retain 712 targets per lead")
        if frozenset(self.archive_members) != ALLOWED_ARCHIVE_MEMBERS:
            raise ValueError("development archive members changed")
        if self.archive_size_bytes <= 0 or self.selection_size_bytes <= 0:
            raise ValueError("registered source sizes must be positive")
        for digest in (self.archive_sha256, self.selection_sha256):
            if len(digest) != 64 or any(character not in "0123456789abcdef" for character in digest):
                raise ValueError("registered SHA-256 must be lowercase hexadecimal")
        if self.archive_array_content_sha256 is not None:
            digest = self.archive_array_content_sha256
            if len(digest) != 64 or any(
                character not in "0123456789abcdef" for character in digest
            ):
                raise ValueError(
                    "registered archive array-content SHA-256 must be lowercase hexadecimal"
                )
        for path in (self.archive_path, self.selection_path):
            relative = PurePosixPath(path)
            if relative.is_absolute() or ".." in relative.parts:
                raise ValueError("registered paths must be safe relative paths")
            lowered = tuple(part.lower().replace("_", "-") for part in relative.parts)
            if any("heldout" in part or "reserved" in part or "formal-evaluation" in part for part in lowered):
                raise PermissionError("registered pilot paths must exclude evaluation material")


_COMMON_ARCHIVE_ROOT = (
    "results/tukf06_full_diagonal_search_head_to_head_v1/selection_inputs"
)
_COMMON_SELECTION_ROOT = "results/tukf06_full_diagonal_search_head_to_head_v1/selection"


_SPECIFICATIONS = {
    "04105700": PilotBasinSpecification(
        basin_id="04105700",
        state_dimension=7,
        archive_path=f"{_COMMON_ARCHIVE_ROOT}/basin_04105700.npz",
        archive_size_bytes=64438,
        archive_sha256="08d7e8930cd4df624efaf578bedd9615d238f51901ee2a1054bd0e8503e0f82e",
        selection_path=f"{_COMMON_SELECTION_ROOT}/basin_04105700.json",
        selection_size_bytes=7895,
        selection_sha256="f7e136632f840b0825a519b25de2b670b6bd0bf936d710489099273f14540180",
    ),
    "08070200": PilotBasinSpecification(
        basin_id="08070200",
        state_dimension=11,
        archive_path=f"{_COMMON_ARCHIVE_ROOT}/basin_08070200.npz",
        archive_size_bytes=69757,
        archive_sha256="800897372294941e87fddb363e688972fd456904d9f06fa60c4743a291abcc49",
        selection_path=f"{_COMMON_SELECTION_ROOT}/basin_08070200.json",
        selection_size_bytes=9289,
        selection_sha256="1ef14c86c0ef7ad4207809e95b5449edccb2877000022ad0f487ead69bb8709e",
    ),
    "09035800": PilotBasinSpecification(
        basin_id="09035800",
        state_dimension=18,
        archive_path=f"{_COMMON_ARCHIVE_ROOT}/basin_09035800.npz",
        archive_size_bytes=57411,
        archive_sha256="71e6d163507ae405204bedf63d2c6c06e2c3ea303cea1a0481cfa4d5f280f5fd",
        selection_path=f"{_COMMON_SELECTION_ROOT}/basin_09035800.json",
        selection_size_bytes=12327,
        selection_sha256="8b4888a62052f8d9f0018e907c665d30a72c4c7c29081763db0f4d46904ec3a2",
    ),
}


_DEVELOPMENT_SPECIFICATION_ROWS = (
    ("04105700", 7, 64438, "08d7e8930cd4df624efaf578bedd9615d238f51901ee2a1054bd0e8503e0f82e", "0b4d18b5ba88ea4f03f3bf8594e037872565390b73f744784cb171a349328857", 7895, "f7e136632f840b0825a519b25de2b670b6bd0bf936d710489099273f14540180"),
    ("08190500", 7, 66573, "7f51dded242e11025866260811510af26da42b3847241613b563dcc0c94385a5", "d3a3ae1941a6dbc080a7d52ae671b65c4a68676cebfb5b663c0f11146a7a57e5", 7934, "e37c80968ba9f8743272746c6e1d8f0f15f8fb545597b071cf67847e1cb9bb7e"),
    ("02102908", 7, 66657, "2c7faecea3acc06d56f2e5d66ab308be4c13d32b1289099577286caf1c2fbd4d", "6bcc95ad8048199ddbf6472a9f3f1d2b1fbc3adf7e2bedb5cf9219a6268df4f4", 7839, "084750c91831376db6f78eddebed1a0157ca2d89d7687fe793b9d506c8e801fe"),
    ("12447390", 7, 58385, "d84d76ba32b30f39f57feeaec374c48ab2d77231e50b8a6b1d65ee3e6004b657", "4fef9ed220f5c452cbcf000ff934056edb1c4c467f6b2fc73313246d1acb63ea", 7832, "e0849c962a3bb438285edec8193a7ff026e3c2331ec2c4bb9e5c62e98dce93fc"),
    ("01487000", 7, 67658, "321c66b0c3b128f1c0b02ac495eff4be357ca9b0840757ef5a62f86272e193c8", "1944d9b4fbfa6938f11d86b0e122c1f50b83c2a4a2c82860824025bdd15a655b", 7749, "9e950d3d4daf69d2c5b8cc5e73be779bd70bbd44dadf4727555d0dd3b2df24b2"),
    ("02178400", 7, 69153, "54ee7f3ddd507791d27b00806935783a43661559ac8486d0e8ce219616fbb336", "941d14bd6677c95b4329b77151ae24f23f6bcee7192b3e140c08d2dd66b64a74", 7668, "9bedb0b955a4bef2e53cd32f77ced7cab45365ae724dda0a25642d2a3d835e6a"),
    ("08070200", 11, 69757, "800897372294941e87fddb363e688972fd456904d9f06fa60c4743a291abcc49", "533f16de2184f3b3bbc1a93230ca7f2003a82eb1c31afbc7d7384a4ea0e0b8dd", 9289, "1ef14c86c0ef7ad4207809e95b5449edccb2877000022ad0f487ead69bb8709e"),
    ("09513780", 7, 62922, "56014ef6d1e6ac132833f21a596874bc9b84466e1fc12ff29f533662154c45df", "376317a29bfc3b08a2636c870672e6dbef4b179ae7b05f9e698f7086ffdf5e43", 7747, "b2c273c801456f46bb036812aacbc42fbc178914c2ba339b200b53f8f2a393d7"),
    ("06803510", 7, 64580, "f5155c3206cb9517d17cde145a902296afd35a8262cd13f3495da16eae4032a2", "c939fba062234b5cc2689a774bb7aec4964b6316617a0f7869aeb8c87c046d9b", 7870, "b494fb41c5f989b34e759394104870056aa4afee5bab4634979b67d151e9cd49"),
    ("03076600", 7, 67706, "d65f605c07443269461a1fedfe9fb945187ee72adaace669b383ad39e7c2998c", "9024f18bfefd1ad9c0297224d30b33aa80fc33b20c71ffb5332ceaf8f0c7e3bb", 7795, "3e923bc019aa3e2c9924faaee9799f93388d8d9fa01cba231fb9236689a4779f"),
    ("12175500", 7, 66991, "a828925b6b7094938772a33be1f2f4c789baf340b019966a3738d1dae6ddda75", "bf9ca45eefcc62cc9d175108ac7c14c2b281b47b1d4052b4ca6b416a140f3ce2", 7688, "d71c876ce8c1fabca4d9bc73fd849d222bc9a57ff46735731254d4a1c9353be1"),
    ("09035800", 18, 57411, "71e6d163507ae405204bedf63d2c6c06e2c3ea303cea1a0481cfa4d5f280f5fd", "8058251e833280d9fb8628f6ba444d011775239c4235939dbd0cde003fbc1e34", 12327, "8b4888a62052f8d9f0018e907c665d30a72c4c7c29081763db0f4d46904ec3a2"),
    ("04027000", 11, 66004, "cde00f5e2a013625c474a337e7b7becc04d2bbc8507d29f12b88f9eadc951af1", "0d0fad29df64858769aaacdfbc9deaf9ed4e85f2701359ac45332381f8eba560", 9524, "40305171ebf37f3baac8fc9405dc7e909ae5ee59306c05e373ad846b17d262d8"),
    ("08109700", 11, 68415, "d8e8d1a22afbc9c830852b96418c1bb8dd0ae05bc3b25e5b1c3c486afbfabbbc", "1376a881dda56d66bc1cc7f31c5bab2605fd25ddce7dd9a28d87a64dcdc75d60", 9566, "66c9e830547f6ae049937d8b2bcc81b7aa0ce01b2cac5fefcaff773be2895a9c"),
    ("08086290", 7, 65112, "74cf7cb48633fe1f2be1ea2580164cbffbb92fea70e67107613155e334ae43ec", "dd7be2599c2e75d76b9978738d297edbedae2bac05e4fed2573a5831c102fca3", 7912, "64fe3f48a41006bb389347c9dc3cf146a88385b76421fef1d59b9a0533410dbd"),
    ("01440400", 7, 67873, "09e648d19a442cd31093435f1eec35f83ebdbab6c13297bd556f6f82287a1451", "33a5077d174ee0300f434e3ae77cc9f6eef1e5dbd47b17e912603bff246323c4", 7662, "22495d5c1c646c9a6f24aeb4f42700da57fa72de4f415df14fa715248a927d37"),
    ("05503800", 7, 66813, "1b4873087dc943b664dce8da6394eabe8819be4e012732baba47466e50bc5b25", "0b2c65045d5d28a3c74ad13853c5aa50bd66aa2eedefbb56dc943cb691b44a9d", 7851, "96f58c0b90fd109da1ea580dd95c2a31dd416b1a6dbada65d8b04bec13c25441"),
    ("03049000", 7, 68894, "e371f9ff95fedbd545b3a5aebc5319194400aeac4a3246fb273859b4cbac55b7", "da0a65c67498f32a13e0720ed46f14b220da58240a7841e53a9d900690f378e1", 7871, "be529e6d4a9f4221cdd6470466caa1ead462be48bd1ab711dd3edefd9f2a1853"),
    ("01435000", 7, 67158, "d2c0d1072dcc5f63b7a972cefcfc64dfcd85d545eb5b2f946f125c1c05cfcf67", "7fc165c5f6d3544de521e1d20db93c00561e6610b98afc551bcdc4b55b3bcc5f", 7858, "7c363d155b8dcb0bf6ff69c9e88bff3d2033ff0b72b9086101b18822ed64099f"),
    ("02092500", 11, 70808, "453d57eab87b0d774d5895f143d51c40644f9b92fd8702ce646a6f4841378eb6", "0aa296fa17e35c8446fac5c40b57b55c9283252dbaec77926ce61a1086ec0173", 9598, "1d888ac7e396def5d6d435574ad4af91a8adb89bf17845c87f15c5a2f2f4b0a3"),
    ("14185900", 7, 71426, "ff87a153cc437da04995d57f1d45734130868d24938af3b6f6e071ef14ed1047", "87490b3d28f29ecb09d1dab648c3439fcee395543394d72b6f520b9328855af2", 7686, "0f806426c052c1a20b69d939673c9d5f24a2e9667a863c40f218ef3e0fd08d33"),
)

_DEVELOPMENT_SPECIFICATIONS = {
    basin_id: PilotBasinSpecification(
        basin_id=basin_id,
        state_dimension=state_dimension,
        archive_path=f"{_COMMON_ARCHIVE_ROOT}/basin_{basin_id}.npz",
        archive_size_bytes=archive_size_bytes,
        archive_sha256=archive_sha256,
        archive_array_content_sha256=archive_array_content_sha256,
        selection_path=f"{_COMMON_SELECTION_ROOT}/basin_{basin_id}.json",
        selection_size_bytes=selection_size_bytes,
        selection_sha256=selection_sha256,
    )
    for (
        basin_id,
        state_dimension,
        archive_size_bytes,
        archive_sha256,
        archive_array_content_sha256,
        selection_size_bytes,
        selection_sha256,
    ) in _DEVELOPMENT_SPECIFICATION_ROWS
}


def get_pilot_basin_specification(basin_id: str) -> PilotBasinSpecification:
    """Return the immutable specification or fail closed for another basin."""

    try:
        return _SPECIFICATIONS[str(basin_id)]
    except KeyError as error:
        raise KeyError(f"{basin_id} is not a registered pilot basin") from error


def get_development_basin_specification(
    basin_id: str,
) -> PilotBasinSpecification:
    """Return one immutable member of the fixed 21-basin development registry."""

    try:
        return _DEVELOPMENT_SPECIFICATIONS[str(basin_id)]
    except KeyError as error:
        raise KeyError(f"{basin_id} is not a registered development basin") from error


def development_experiment_id(basin_id: str) -> str:
    """Return the exact new-family identity for one of the 18 training basins."""

    normalized = str(basin_id)
    if normalized not in DEVELOPMENT_TRAINING_BASIN_ORDER:
        raise KeyError(f"{basin_id} is not a registered development training basin")
    return f"{DEVELOPMENT_EXPERIMENT_FAMILY}_BASIN_{normalized}"
