"""Exact-dimension development primitives for per-basin daily KalmanNet pilots."""

from __future__ import annotations

from hashlib import sha256
import json
import math
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Mapping

import numpy as np
import torch

import scripts.tukf06_full_diagonal_common as _tukf06_common
from global_hydrology.experiments.daily_camels_knet_per_basin_contract import (
    ALLOWED_STATE_DIMENSIONS,
    DEVELOPMENT_END,
    DEVELOPMENT_START,
    TRAINING_DAYS,
    PilotBasinSpecification,
)
from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import (
    ALLOWED_ARCHIVE_MEMBERS,
    CAUSAL_SHARED_SPINUP_MODE,
    EXACT_TUKF06_DIAGNOSTIC_MODE,
    NATIVE_DEFAULT_GAIN_INITIALIZATION,
    NEAR_ZERO_FC2_HEAD_GAIN_INITIALIZATION,
    AccessLedger,
    validate_initialization_usage,
)
from global_hydrology.experiments.daily_camels_ukf_knet_parity_runner import (
    ScoreSummary,
    ParityRuntime,
    _causal_default_storage,
    _require_shape,
    _state_bounds,
    aligned_forecasts_from_posterior,
    apply_gain_initialization,
    evaluate_knet,
    fit_training_feature_scales,
    forecast_pairs,
    physical_multilead_mse,
    previous_observation_before_window,
    run_knet_filter,
    score_forecast_pairs,
)
from global_hydrology.models.differentiable_hbv_lite import PARAM_NAMES
from global_hydrology.models.knet_native_hbvlite_full_state import (
    NativeHBVFullStateKalmanNet,
)


ROOT = Path(__file__).resolve().parents[3]


class ExactDimensionNativeHBVFullStateKalmanNet(NativeHBVFullStateKalmanNet):
    """Keep the archived gain core's implicit work tensors in its native dtype."""

    def KGain_step(self, *inputs: torch.Tensor) -> torch.Tensor:  # noqa: N802
        network_dtype = next(self.parameters()).dtype
        if network_dtype != torch.float32:
            raise RuntimeError("the unchanged KalmanNet gain core must remain float32")
        previous_default_dtype = torch.get_default_dtype()
        try:
            torch.set_default_dtype(network_dtype)
            return super().KGain_step(*inputs)
        finally:
            torch.set_default_dtype(previous_default_dtype)


def _sha256_file(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _registered_path(relative: str) -> Path:
    path = (ROOT / relative).resolve()
    try:
        path.relative_to(ROOT.resolve())
    except ValueError as error:
        raise ValueError("registered path escapes the isolated source root") from error
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def exact_active_state_correction_mask(
    state_dimension: int,
    *,
    dtype: torch.dtype = torch.float64,
    device: str | torch.device = "cpu",
) -> torch.Tensor:
    """Authorize every coordinate of one exact active state, with no padding."""

    dimension = int(state_dimension)
    if dimension not in ALLOWED_STATE_DIMENSIONS:
        raise ValueError("exact active state dimension must be 7, 11, or 18")
    return torch.ones(1, dimension, dtype=dtype, device=device)


def correction_saturation_snapshot(
    *,
    correction: torch.Tensor,
    state_feature_scale: torch.Tensor,
    cap_in_state_scale_units: float,
) -> dict[str, Any]:
    """Summarize cap saturation for the supplied analysis-step corrections."""

    cap = float(cap_in_state_scale_units)
    if not math.isfinite(cap) or cap <= 0.0:
        raise ValueError("correction cap must be positive and finite")
    if correction.ndim == 0:
        raise ValueError("correction must include a state dimension")
    state_dimension = int(correction.shape[-1])
    if state_dimension <= 0:
        raise ValueError("correction must include at least one state")
    try:
        scale = torch.broadcast_to(state_feature_scale, correction.shape)
    except RuntimeError as error:
        raise ValueError(
            "state feature scale must broadcast to the correction shape"
        ) from error
    if not bool(torch.isfinite(scale).all()) or bool((scale <= 0.0).any()):
        raise ValueError("state feature scales must be positive and finite")
    if not bool(torch.isfinite(correction).all()):
        raise FloatingPointError("correction must be finite")
    saturated = torch.abs(correction / scale) >= cap * (1.0 - 1e-9)
    flattened = saturated.reshape(-1, state_dimension)
    count_by_state = flattened.sum(dim=0, dtype=torch.int64)
    count = int(count_by_state.sum().item())
    analysis_step_count = int(flattened.shape[0])
    denominator = analysis_step_count * state_dimension
    if denominator <= 0:
        raise ValueError("correction must include at least one analysis step")
    return {
        "saturation_count_by_state": [int(value) for value in count_by_state.tolist()],
        "saturation_count": count,
        "analysis_step_count": analysis_step_count,
        "saturation_denominator": denominator,
        "saturation_fraction": float(count / denominator),
    }


def load_per_basin_development_runtime(
    specification: PilotBasinSpecification,
    *,
    ledger: AccessLedger,
    initialization_mode: str,
    device: str | torch.device = "cpu",
    tukf06_module: Any | None = None,
) -> ParityRuntime:
    """Load one registered development archive and rebuild its exact HBV state."""

    module = _tukf06_common if tukf06_module is None else tukf06_module
    selected_device = torch.device(device)
    archive_path = _registered_path(specification.archive_path)
    if archive_path.stat().st_size != specification.archive_size_bytes:
        raise RuntimeError("development archive byte size differs from the registry")
    archive_hash = _sha256_file(archive_path)
    if archive_hash != specification.archive_sha256:
        raise RuntimeError("development archive SHA-256 differs from the registry")

    common_members = {
        "dates_ns",
        "forcing",
        "observations",
        "parameters",
        "base_observation_variance",
        "state_dimension",
    }
    if initialization_mode == EXACT_TUKF06_DIAGNOSTIC_MODE:
        members_to_read = set(ALLOWED_ARCHIVE_MEMBERS)
    elif initialization_mode == CAUSAL_SHARED_SPINUP_MODE:
        members_to_read = common_members
    else:
        raise ValueError(f"unknown initialization mode: {initialization_mode}")

    arrays: dict[str, np.ndarray] = {}
    with np.load(archive_path, allow_pickle=False) as archive:
        if set(archive.files) != set(specification.archive_members):
            raise RuntimeError("development archive member set differs from the registry")
        for name in sorted(members_to_read):
            ledger.record_archive_member(name)
            arrays[name] = np.asarray(archive[name]).copy()

    dates_ns = np.asarray(arrays["dates_ns"], dtype=np.int64)
    forcing_array = np.asarray(arrays["forcing"], dtype=np.float64)
    observation_array = np.asarray(arrays["observations"], dtype=np.float64)
    parameter_array = np.asarray(arrays["parameters"], dtype=np.float64)
    base_variance_array = np.asarray(
        arrays["base_observation_variance"], dtype=np.float64
    )
    dimension_array = np.asarray(arrays["state_dimension"], dtype=np.int64)
    _require_shape(dates_ns, (specification.expected_days,), "dates_ns")
    _require_shape(forcing_array, (specification.expected_days, 3), "forcing")
    _require_shape(observation_array, (specification.expected_days,), "observations")
    _require_shape(parameter_array, (1, len(PARAM_NAMES)), "parameters")
    _require_shape(base_variance_array, (1,), "base_observation_variance")
    _require_shape(dimension_array, (1,), "state_dimension")
    if int(dimension_array[0]) != specification.state_dimension:
        raise RuntimeError("archive state dimension differs from the registry")
    if not np.isfinite(forcing_array).all() or not np.isfinite(parameter_array).all():
        raise FloatingPointError("archive forcing and parameters must be finite")
    if not np.isfinite(base_variance_array).all() or float(base_variance_array[0]) <= 0:
        raise FloatingPointError("archive observation variance must be finite and positive")

    dates = dates_ns.astype("datetime64[ns]")
    if np.any(dates[1:] <= dates[:-1]):
        raise ValueError("development dates must be strictly increasing")
    if str(dates[0].astype("datetime64[D]")) != DEVELOPMENT_START:
        raise RuntimeError("development start date changed")
    if str(dates[-1].astype("datetime64[D]")) != DEVELOPMENT_END:
        raise RuntimeError("development end date changed")
    if str(dates[TRAINING_DAYS].astype("datetime64[D]")) != "2006-10-01":
        raise RuntimeError("training and validation boundary changed")
    ledger.record_date_request(DEVELOPMENT_START, DEVELOPMENT_END)

    forcing = torch.as_tensor(
        forcing_array, dtype=torch.float64, device=selected_device
    ).unsqueeze(1)
    observations = torch.as_tensor(
        observation_array, dtype=torch.float64, device=selected_device
    ).unsqueeze(1)
    parameters = torch.as_tensor(
        parameter_array, dtype=torch.float64, device=selected_device
    )
    if initialization_mode == EXACT_TUKF06_DIAGNOSTIC_MODE:
        archived_storage = np.asarray(arrays["initial_storage_state"], dtype=np.float64)
        _require_shape(archived_storage, (1, 5), "initial_storage_state")
        initial_storage = torch.as_tensor(
            archived_storage, dtype=torch.float64, device=selected_device
        )
    else:
        initial_storage = _causal_default_storage(parameters)

    prior = SimpleNamespace(
        basin_ids=[specification.basin_id],
        param_table=parameters,
        x0_table=initial_storage,
    )
    tukf06_contract = module.load_contract()
    context = module.build_basin_context(
        prior,
        specification.basin_id,
        observations[:TRAINING_DAYS],
        tukf06_contract,
        device=selected_device,
    )
    if int(context.dimension) != specification.state_dimension:
        raise RuntimeError("rebuilt physical state dimension differs from the registry")
    lag = float(context.parameters[0, PARAM_NAMES.index("lag_time")])
    exact_dimension = 5 + max(1, math.ceil(lag))
    if exact_dimension != specification.state_dimension:
        raise RuntimeError("registered dimension is not the exact active routed-state length")

    comparisons: dict[str, np.ndarray] = {
        "parameters": context.parameters.detach().cpu().numpy(),
        "base_observation_variance": np.asarray(
            [context.base_observation_variance], dtype=np.float64
        ),
        "state_dimension": np.asarray([context.dimension], dtype=np.int64),
    }
    if initialization_mode == EXACT_TUKF06_DIAGNOSTIC_MODE:
        comparisons.update(
            {
                "initial_storage_state": context.initial_storage_state.detach()
                .cpu()
                .numpy(),
                "initial_state": context.initial_state.detach().cpu().numpy(),
                "initial_covariance": context.initial_covariance.detach()
                .cpu()
                .numpy(),
            }
        )
    for name, rebuilt in comparisons.items():
        if not np.array_equal(np.asarray(arrays[name]), rebuilt):
            raise RuntimeError(f"rebuilt context differs from archive member {name}")

    evidence = validate_initialization_usage(
        initialization_mode, used_archive_members=set(members_to_read)
    )
    return ParityRuntime(
        contract=specification,  # type: ignore[arg-type]
        tukf06_contract=tukf06_contract,
        context=context,
        forcing=forcing,
        observations=observations,
        dates=dates,
        training_days=TRAINING_DAYS,
        initialization_evidence=evidence,
        ledger=ledger,
        archive_path=archive_path,
        archive_sha256=archive_hash,
        tukf06_module=module,
    )


def load_selected_unscented_kalman_filter_parameters(
    specification: PilotBasinSpecification,
    *,
    method: str = "backpropagation",
) -> tuple[np.ndarray, Mapping[str, Any]]:
    """Load one development-selected filter vector after full identity checks."""

    path = _registered_path(specification.selection_path)
    if path.stat().st_size != specification.selection_size_bytes:
        raise RuntimeError("selection record byte size differs from the registry")
    if _sha256_file(path) != specification.selection_sha256:
        raise RuntimeError("selection record SHA-256 differs from the registry")
    record = json.loads(path.read_text(encoding="utf-8"))
    if record.get("experiment_id") != _tukf06_common.EXPERIMENT_ID:
        raise RuntimeError("selection record is not from the frozen TUKF06 experiment")
    if record.get("basin_id") != specification.basin_id:
        raise RuntimeError("selection record basin differs from the registry")
    if record.get("evaluation_period_read") is not False:
        raise RuntimeError("selection record reports historical-evaluation access")
    if int(record.get("training_days", -1)) != TRAINING_DAYS:
        raise RuntimeError("selection training length changed")
    if int(record.get("state_dimension", -1)) != specification.state_dimension:
        raise RuntimeError("selection state dimension differs from the registry")
    if method not in {"backpropagation", "sampling_search"}:
        raise ValueError("selection method must be backpropagation or sampling_search")
    theta = np.asarray(record[method]["selected"]["theta_log"], dtype=np.float64)
    if theta.shape != (specification.state_dimension + 1,):
        raise ValueError("selected filter vector has the wrong state dimension")
    if not np.isfinite(theta).all():
        raise FloatingPointError("selected filter vector is non-finite")
    return theta, record


def build_exact_dimension_kalman_net(
    runtime: ParityRuntime,
    *,
    zero_gain: bool,
    seed: int,
    gain_initialization: str = NEAR_ZERO_FC2_HEAD_GAIN_INITIALIZATION,
    hidden: int = 24,
    input_multiplier: int = 10,
    output_multiplier: int = 10,
    feature_scale_floor: float = 0.1,
    normalized_feature_guard: float | None = 10.0,
    correction_cap_in_state_scale_units: float | None = None,
) -> NativeHBVFullStateKalmanNet:
    """Bind the unchanged KalmanNet core to one exact active physical state."""

    dimension = int(runtime.context.dimension)
    if dimension != int(runtime.contract.state_dimension):
        raise RuntimeError("physical and registered state dimensions differ")
    torch.manual_seed(int(seed))
    if runtime.context.device.type == "cuda":
        torch.cuda.manual_seed_all(int(seed))
    scales = fit_training_feature_scales(runtime, floor=feature_scale_floor)
    mask = exact_active_state_correction_mask(
        dimension, dtype=runtime.context.dtype, device=runtime.context.device
    )
    lower, upper = _state_bounds(runtime)
    cap = (
        None
        if correction_cap_in_state_scale_units is None
        else float(correction_cap_in_state_scale_units)
    )
    correction_cap_by_state_scale_units = (
        None
        if cap is None
        else torch.full(
            (1, dimension),
            cap,
            dtype=runtime.context.dtype,
            device=runtime.context.device,
        )
    )
    previous_default_dtype = torch.get_default_dtype()
    try:
        torch.set_default_dtype(torch.float32)
        network = ExactDimensionNativeHBVFullStateKalmanNet(
            runtime.context.plain_model,
            correction_mask=mask,
            state_lower_bound=lower,
            state_upper_bound=upper,
            device=runtime.context.device,
            hidden=int(hidden),
            in_mult=int(input_multiplier),
            out_mult=int(output_multiplier),
            correction_cap_in_state_scale_units=cap,
        ).to(device=runtime.context.device)
    finally:
        torch.set_default_dtype(previous_default_dtype)
    if {parameter.dtype for parameter in network.parameters()} != {torch.float32}:
        raise RuntimeError("the unchanged KalmanNet gain core must remain float32")
    network.set_basin_adaptation(
        system=runtime.context.plain_model,
        correction_mask=mask,
        state_lower_bound=lower,
        state_upper_bound=upper,
        observation_feature_scale=scales.observation_feature_scale,
        state_feature_scale=scales.state_feature_scale,
        correction_cap_by_state_scale_units=correction_cap_by_state_scale_units,
        normalized_feature_guard=normalized_feature_guard,
    )
    if zero_gain:
        if gain_initialization != NATIVE_DEFAULT_GAIN_INITIALIZATION:
            raise ValueError("strict zero gain requires native_default initialization")
        with torch.no_grad():
            network.FC2[-1].weight.zero_()
            network.FC2[-1].bias.zero_()
    else:
        apply_gain_initialization(network, gain_initialization)
    return network


def replay_selected_unscented_kalman_filter(
    runtime: ParityRuntime,
    window: Any,
    specification: PilotBasinSpecification,
    *,
    method: str = "backpropagation",
) -> ScoreSummary:
    """Replay one registered per-basin filter on the exact reporting geometry."""

    theta, selection = load_selected_unscented_kalman_filter_parameters(
        specification, method=method
    )
    forecasts = runtime.tukf06_module.filter_forecasts(
        window.context,
        window.forcing,
        window.observations,
        theta,
        runtime.tukf06_contract,
    )
    pairs = forecast_pairs(
        window.observations,
        forecasts,
        issue_start=window.issue_start_local,
        issue_end=window.issue_end_local,
        leads=runtime.contract.leads,
    )
    score = score_forecast_pairs(pairs)
    if any(
        score.target_count_by_lead[lead]
        != specification.expected_recovery_target_count_per_lead
        for lead in specification.leads
    ):
        raise RuntimeError("selected filter reporting target geometry changed")
    theta_tensor = torch.as_tensor(
        theta, dtype=window.context.dtype, device=window.context.device
    )
    no_warmup = runtime.tukf06_module.multilead_objective(
        window.context,
        window.forcing,
        window.observations,
        theta_tensor,
        False,
        runtime.tukf06_contract,
    )
    no_warmup_pairs = forecast_pairs(
        window.observations,
        forecasts,
        issue_start=0,
        issue_end=len(window.observations) - max(specification.leads),
        leads=specification.leads,
    )
    no_warmup_score = score_forecast_pairs(no_warmup_pairs)
    if not math.isclose(
        float(no_warmup.detach().cpu()),
        no_warmup_score.objective,
        rel_tol=0.0,
        abs_tol=1e-12,
    ):
        raise RuntimeError("selected filter objective differs from explicit forecast pairs")
    from dataclasses import replace

    return replace(
        score,
        full_objective_without_warmup=no_warmup_score.objective,
        full_target_count_by_lead_without_warmup=dict(
            no_warmup_score.target_count_by_lead
        ),
        metadata={
            "method": method,
            "theta_log": theta.tolist(),
            "selection_path": specification.selection_path,
            "selection_validation_objective": float(
                selection[method]["selected"]["validation_objective"]
            ),
            "initialization_mode": runtime.initialization_evidence.mode,
        },
    )


def evaluate_exact_zero_gain_open_loop(
    runtime: ParityRuntime,
    window: Any,
    *,
    seed: int = 20260824,
    hidden: int = 24,
    input_multiplier: int = 10,
    output_multiplier: int = 10,
    feature_scale_floor: float = 0.1,
    normalized_feature_guard: float | None = 10.0,
    correction_cap_in_state_scale_units: float | None = None,
) -> ScoreSummary:
    """Prove exact zero gain equals the shared point-state physical open loop."""

    network = build_exact_dimension_kalman_net(
        runtime,
        zero_gain=True,
        seed=seed,
        gain_initialization=NATIVE_DEFAULT_GAIN_INITIALIZATION,
        hidden=hidden,
        input_multiplier=input_multiplier,
        output_multiplier=output_multiplier,
        feature_scale_floor=feature_scale_floor,
        normalized_feature_guard=normalized_feature_guard,
        correction_cap_in_state_scale_units=correction_cap_in_state_scale_units,
    )
    network.eval()
    with torch.no_grad():
        trace = run_knet_filter(
            network,
            window,
            previous_observation=previous_observation_before_window(runtime, window),
        )
        predictions = aligned_forecasts_from_posterior(
            runtime, window, trace.posterior_states
        )
        open_loop = runtime.tukf06_module.open_loop_prediction(
            window.context, window.forcing
        )
    reporting_pairs = forecast_pairs(
        window.observations,
        predictions,
        issue_start=window.issue_start_local,
        issue_end=window.issue_end_local,
        leads=runtime.contract.leads,
    )
    score = score_forecast_pairs(reporting_pairs)
    no_warmup_pairs = forecast_pairs(
        window.observations,
        predictions,
        issue_start=0,
        issue_end=len(window.observations) - max(runtime.contract.leads),
        leads=runtime.contract.leads,
    )
    no_warmup_score = score_forecast_pairs(no_warmup_pairs)
    differences: list[float] = []
    for lead in runtime.contract.leads:
        target_indices = np.arange(
            lead,
            len(window.observations) - max(runtime.contract.leads) + lead,
            dtype=np.int64,
        )
        differences.extend(
            np.abs(predictions[lead][target_indices] - open_loop[target_indices]).tolist()
        )
    maximum_difference = float(np.max(differences)) if differences else 0.0
    if maximum_difference != 0.0:
        raise RuntimeError("zero-gain KalmanNet differs from the physical open loop")
    from dataclasses import replace

    return replace(
        score,
        full_objective_without_warmup=no_warmup_score.objective,
        full_target_count_by_lead_without_warmup=dict(
            no_warmup_score.target_count_by_lead
        ),
        posterior_states=trace.posterior_states.detach().cpu().numpy(),
        open_loop=open_loop,
        maximum_open_loop_difference=maximum_difference,
        metadata={
            "zero_gain": True,
            "state_dimension": runtime.context.dimension,
            "initialization_mode": runtime.initialization_evidence.mode,
        },
    )


def simple_time_series_scores(
    runtime: ParityRuntime,
    window: Any,
) -> tuple[ScoreSummary, ScoreSummary]:
    """Score persistence and second-order autoregression on the same issues."""

    observations = window.observations.detach().cpu().numpy().reshape(-1)
    training_observations = (
        runtime.observations[: runtime.training_days]
        .detach()
        .cpu()
        .numpy()
        .reshape(-1)
    )
    persistence = runtime.tukf06_module.persistence_predictions(observations)
    autoregression = runtime.tukf06_module.second_order_autoregression_predictions(
        training_observations, observations
    )
    scores: list[ScoreSummary] = []
    for predictions in (persistence, autoregression):
        pairs = forecast_pairs(
            observations,
            predictions,
            issue_start=window.issue_start_local,
            issue_end=window.issue_end_local,
            leads=runtime.contract.leads,
        )
        scores.append(score_forecast_pairs(pairs))
    return scores[0], scores[1]
