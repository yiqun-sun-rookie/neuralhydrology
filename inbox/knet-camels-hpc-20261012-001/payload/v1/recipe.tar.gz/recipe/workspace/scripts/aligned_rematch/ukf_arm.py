"""Differentiable-UKF arm of contract A.

Learns theta = (ln q_1..q_m, ln r_b) with Adam (lr 0.05) on the natural-log coordinates, exactly as
the frozen TUKF06 back-propagation did (``Parameter`` + ``backward`` + ``optimizer.step`` +
``clamp_`` to the box), with the contract-A changes: seeded start = neutral anchor x exp(N(0,1))
per coordinate, box upper bounds raised to q <= 10 and r_b <= 1.0, and the training objective
replaced by the KalmanNet-identical 25 fixed 150-day segments (segment initial state = open-loop
state before the segment, segment initial covariance = 0.001 I, 45-day warm-up, leads 1-3 equal
weight, segments equal weight). The validation objective is the continuous 731-day recovery
window (728 targets per lead), the same window the KalmanNet arm uses for checkpoint selection.

The engine ``run_hbvlite_corrected_ukf`` is called directly (read-only reuse); TUKF06's
``decode_theta`` is not used because it enforces the old box.
"""
from __future__ import annotations

import math
from typing import Any, Mapping

import numpy as np
import torch

import scripts.tukf06_full_diagonal_common as tukf06
from scripts.aligned_rematch import contract as C
from scripts.aligned_rematch.knet_arm import validation_score_from_predictions
from scripts.aligned_rematch.ledger import ENGINE_ERRORS, StepDiagnostic, ValidationScore
from scripts.differentiable_ukf_hbvlite import run_hbvlite_corrected_ukf
from global_hydrology.experiments.daily_camels_knet_per_basin_contract import (
    LEADS,
    TRAINING_DAYS,
    get_development_basin_specification,
)
from global_hydrology.experiments.daily_camels_knet_per_basin_runner import (
    load_per_basin_development_runtime,
)
from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import (
    AccessLedger,
    CAUSAL_SHARED_SPINUP_MODE,
)
from global_hydrology.experiments.daily_camels_ukf_knet_parity_runner import (
    _physical_state_before_segment,
    select_window,
    training_open_loop_states,
)
from global_hydrology.models.hbvlite_ukf_adapter import RoutedHBVLiteUKFAdapter


def seeded_start(state_dimension: int, seed: int) -> dict[str, Any]:
    """theta0 = ln(anchor) + N(0, 1) per coordinate (NumPy PCG64 seeded with the run seed), projected into the box."""
    m = int(state_dimension)
    anchor = torch.tensor(C.ukf_anchor_log(m), dtype=torch.float64)
    # NumPy PCG64 (default_rng) is bit-stable across NumPy 1.17+ / 2.x; torch.randn is not stable across
    # torch versions for lengths >= 16 (vectorised path), which the E1 probe exposed on the 18-state basin.
    rng = np.random.default_rng(int(seed))
    z = torch.as_tensor(rng.standard_normal(m + 1), dtype=torch.float64) * C.UKF_START_LOG_PERTURBATION_STD
    raw = anchor + z
    lower_list, upper_list = C.ukf_log_bounds(m)
    lower = torch.tensor(lower_list, dtype=torch.float64)
    upper = torch.tensor(upper_list, dtype=torch.float64)
    projected = torch.maximum(torch.minimum(raw, upper), lower)
    farthest = torch.maximum(projected - lower, upper - projected)  # per coordinate distance to the far bound
    anchor_farthest = torch.maximum(anchor - lower, upper - anchor)
    return {
        "seed": int(seed),
        "anchor_log": anchor.tolist(),
        "perturbation_z": z.tolist(),
        "theta0_raw_log": raw.tolist(),
        "theta0_log": projected.tolist(),
        "projected_at_start": bool(torch.any(raw != projected)),
        "reachability_budget_log_units": float(C.UKF_REACHABILITY_BUDGET_LOG_UNITS),
        "reachability_max_log_distance_from_start": float(farthest.max()),
        "reachability_passed_from_start": bool(float(farthest.max()) <= C.UKF_REACHABILITY_BUDGET_LOG_UNITS),
        "reachability_max_log_distance_from_anchor": float(anchor_farthest.max()),
        "reachability_passed_from_anchor": bool(float(anchor_farthest.max()) <= C.UKF_REACHABILITY_BUDGET_LOG_UNITS),
        # user decision (B), 2026-09-17: the contract's check is evaluated at the anchor; the start distance is disclosed
        "reachability_rule": C.UKF_REACHABILITY_RULE,
        "reachability_passed": bool(float(anchor_farthest.max()) <= C.UKF_REACHABILITY_BUDGET_LOG_UNITS),
    }


def boundary_report(theta: np.ndarray, state_dimension: int) -> dict[str, Any]:
    """Contract v2 section 3: boundary hits by parameter class (storage q / routing q / r_b), exact and outer 5%."""
    m = int(state_dimension)
    lower_list, upper_list = C.ukf_log_bounds(m)
    lower = np.asarray(lower_list)
    upper = np.asarray(upper_list)
    array = np.asarray(theta, dtype=np.float64)
    position = (array - lower) / (upper - lower)
    exact_lower = np.isclose(array, lower, atol=1e-12, rtol=0.0)
    exact_upper = np.isclose(array, upper, atol=1e-12, rtol=0.0)
    outer = (position <= C.UKF_BOUNDARY_OUTER_FRACTION) | (position >= 1.0 - C.UKF_BOUNDARY_OUTER_FRACTION)
    classes = {
        "storage_q": list(range(0, C.UKF_HBV_STORAGE_STATE_COUNT)),
        "routing_q": list(range(C.UKF_HBV_STORAGE_STATE_COUNT, m)),
        "r_b": [m],
    }
    report: dict[str, Any] = {"normalized_log_position": position.tolist()}
    for name, indices in classes.items():
        idx = np.asarray(indices, dtype=np.int64)
        report[name] = {
            "count": int(len(idx)),
            "exact_lower_count": int(exact_lower[idx].sum()),
            "exact_upper_count": int(exact_upper[idx].sum()),
            "outer_five_percent_count": int(outer[idx].sum()),
        }
    report["exact_count_total"] = int(exact_lower.sum() + exact_upper.sum())
    report["outer_five_percent_count_total"] = int(outer.sum())
    return report


class DifferentiableUKFArm:
    name = "ukf"

    def __init__(self, *, basin_id: str, seed: int, device: str | torch.device = "cpu") -> None:
        self.basin_id = str(basin_id)
        self.seed = int(seed)
        self.device = torch.device(device)
        torch.manual_seed(self.seed)
        np.random.seed(self.seed)
        self.specification = get_development_basin_specification(self.basin_id)
        self.ledger = AccessLedger()
        self.runtime = load_per_basin_development_runtime(
            self.specification, ledger=self.ledger, initialization_mode=CAUSAL_SHARED_SPINUP_MODE, device=self.device
        )
        self.context = self.runtime.context
        self.dimension = int(self.context.dimension)
        self.recovery = select_window(self.runtime, "recovery")
        self.open_loop_states = training_open_loop_states(self.runtime)
        lower_list, upper_list = C.ukf_log_bounds(self.dimension)
        self.lower = torch.tensor(lower_list, dtype=torch.float64, device=self.device)
        self.upper = torch.tensor(upper_list, dtype=torch.float64, device=self.device)
        self.start = seeded_start(self.dimension, self.seed)
        self.theta = torch.nn.Parameter(torch.tensor(self.start["theta0_log"], dtype=torch.float64, device=self.device))
        self.optimizer = torch.optim.Adam([self.theta], lr=C.UKF_LEARNING_RATE)
        self.segment_count = len(C.FIXED_TRAINING_SEGMENT_STARTS)
        self._segments = self._build_segment_batch()
        self._batched_adapter = RoutedHBVLiteUKFAdapter(
            self.context.parameters.repeat(self.segment_count, 1),
            self.context.adapter._weights.repeat(self.segment_count, 1),
            device=self.device,
            dtype=self.context.dtype,
            clamp_storage=True,
        )
        self._open_loop_score: ValidationScore | None = None
        self._last_gradient: list[float] | None = None

    # ------------------------------------------------------------------ segments
    def _build_segment_batch(self) -> dict[str, torch.Tensor]:
        starts = C.FIXED_TRAINING_SEGMENT_STARTS
        days = C.SEGMENT_DAYS
        forcing = torch.stack([self.runtime.forcing[s:s + days, 0, :] for s in starts], dim=1)          # [150, 25, 3]
        observations = torch.stack([self.runtime.observations[s:s + days, 0] for s in starts], dim=1)   # [150, 25]
        initial = torch.cat([_physical_state_before_segment(self.runtime, self.open_loop_states, s) for s in starts], dim=0)  # [25, m]
        eye = torch.eye(self.dimension, dtype=self.context.dtype, device=self.device)
        covariance = eye.unsqueeze(0).repeat(len(starts), 1, 1) * C.UKF_SEGMENT_INITIAL_COVARIANCE_DIAGONAL
        if not (covariance[0] == self.context.initial_covariance[0]).all():
            raise RuntimeError("segment initial covariance differs from the frozen initial covariance")
        if int(starts[-1]) + days > TRAINING_DAYS:
            raise RuntimeError("training segment extends beyond the pre-validation period")
        return {"forcing": forcing, "observations": observations, "initial": initial, "covariance": covariance}

    def _decode(self, theta: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        if not bool(torch.isfinite(theta).all()):
            raise FloatingPointError("theta is non-finite")
        actual = torch.exp(theta)
        return actual[: self.dimension], actual[self.dimension]

    def segmented_objective(self, theta: torch.Tensor, *, grad: bool) -> dict[str, Any]:
        """Batched 25-segment objective; equal segment weight, equal lead weight, 45-day warm-up excluded."""
        seg = self._segments
        q_diag, r_b = self._decode(theta)
        manager = torch.enable_grad() if grad else torch.no_grad()
        with manager:
            result = run_hbvlite_corrected_ukf(
                self._batched_adapter,
                seg["forcing"],
                seg["observations"],
                seg["initial"],
                seg["covariance"],
                q_diag.unsqueeze(0).expand(self.segment_count, -1),
                base_observation_variance=self.context.base_observation_variance,
                r_b=r_b,
                project_mean=self.context.project_mean,
            )
            posterior = result["posterior_state"]                           # [150, 25, m]
            days, batch, m = posterior.shape
            starts = days - max(LEADS)                                        # 147
            warmup = C.SEGMENT_FILTER_WARMUP_DAYS
            state = posterior[:starts].reshape(starts * batch, m)
            per_lead: dict[int, torch.Tensor] = {}
            for lead in LEADS:
                forcing = seg["forcing"][lead:starts + lead].reshape(starts * batch, 3)
                state = self.context.plain_model.f(state, forcing)
                forecast = self.context.plain_model.h(state)[:, 0].reshape(starts, batch)
                target = seg["observations"][lead:starts + lead]             # [147, 25]
                forecast_window = forecast[warmup:]
                target_window = target[warmup:]
                finite = torch.isfinite(target_window)
                if not bool(torch.isfinite(forecast_window).all()):
                    raise FloatingPointError(f"training segment contains a non-finite lead-{lead} forecast")
                counts = finite.sum(dim=0)
                if bool((counts < 1).any()):
                    raise ValueError(f"a training segment has no finite lead-{lead} target")
                squared = torch.where(finite, (forecast_window - torch.nan_to_num(target_window)) ** 2, torch.zeros_like(forecast_window))
                per_lead[lead] = squared.sum(dim=0) / counts                  # [25] per-segment MSE for this lead
            per_segment = torch.stack([per_lead[lead] for lead in LEADS], dim=0).mean(dim=0)  # [25]
            objective = per_segment.mean()
        if not bool(torch.isfinite(objective)):
            raise FloatingPointError("segmented training objective is non-finite")
        return {
            "objective": objective,
            "mse_by_lead": {str(lead): float(per_lead[lead].mean().detach()) for lead in LEADS},
            "per_segment_objective": per_segment.detach().cpu().numpy().tolist(),
            "target_count_by_lead": {str(lead): int(counts.sum()) for lead in LEADS},
        }

    def segmented_objective_sequential(self, theta: torch.Tensor) -> float:
        """Reference implementation (one segment at a time) for the batch-parity test."""
        values: list[float] = []
        seg = self._segments
        with torch.no_grad():
            q_diag, r_b = self._decode(theta)
            for b in range(self.segment_count):
                result = run_hbvlite_corrected_ukf(
                    self.context.adapter,
                    seg["forcing"][:, b:b + 1, :],
                    seg["observations"][:, b:b + 1],
                    seg["initial"][b:b + 1],
                    seg["covariance"][b:b + 1],
                    q_diag,
                    base_observation_variance=self.context.base_observation_variance,
                    r_b=r_b,
                    project_mean=self.context.project_mean,
                )
                raw = tukf06.multilead_torch(self.context.plain_model, result["posterior_state"][:, 0, :], seg["forcing"][:, b:b + 1, :])
                total = 0.0
                for lead in LEADS:
                    forecast, indices = raw[lead]
                    forecast = forecast[C.SEGMENT_FILTER_WARMUP_DAYS:]
                    target = seg["observations"][indices[C.SEGMENT_FILTER_WARMUP_DAYS:], b]
                    finite = torch.isfinite(target)
                    total += float(torch.mean((forecast[finite] - target[finite]) ** 2))
                values.append(total / len(LEADS))
        return float(np.mean(values))

    def continuous_training_objective(self, theta: torch.Tensor) -> float:
        """TUKF06-style continuous objective over the whole training period (for the E1 segmented-vs-continuous report)."""
        with torch.no_grad():
            q_diag, r_b = self._decode(theta)
            forcing = self.runtime.forcing[:TRAINING_DAYS]
            observations = self.runtime.observations[:TRAINING_DAYS]
            result = run_hbvlite_corrected_ukf(
                self.context.adapter, forcing, observations, self.context.initial_state, self.context.initial_covariance, q_diag,
                base_observation_variance=self.context.base_observation_variance, r_b=r_b, project_mean=self.context.project_mean,
            )
            raw = tukf06.multilead_torch(self.context.plain_model, result["posterior_state"][:, 0, :], forcing)
            total = 0.0
            for lead in LEADS:
                forecast, indices = raw[lead]
                target = observations[indices, 0]
                finite = torch.isfinite(target)
                total += float(torch.mean((forecast[finite] - target[finite]) ** 2))
        return total / len(LEADS)

    # ------------------------------------------------------------------ validation
    def _predictions(self, theta: torch.Tensor, window: Any) -> dict[int, np.ndarray]:
        with torch.no_grad():
            q_diag, r_b = self._decode(theta)
            result = run_hbvlite_corrected_ukf(
                window.context.adapter,
                window.forcing,
                window.observations,
                window.context.initial_state,
                window.context.initial_covariance,
                q_diag,
                base_observation_variance=window.context.base_observation_variance,
                r_b=r_b,
                project_mean=window.context.project_mean,
            )
            posterior = result["posterior_state"][:, 0, :]
            if not bool(torch.isfinite(posterior).all()):
                raise FloatingPointError("non-finite validation posterior state")
            raw = tukf06.multilead_torch(window.context.plain_model, posterior, window.forcing)
        aligned: dict[int, np.ndarray] = {}
        for lead, (forecast, indices) in raw.items():
            values = np.full(len(window.observations), np.nan, dtype=np.float64)
            values[indices.detach().cpu().numpy()] = forecast.detach().cpu().numpy()
            aligned[int(lead)] = values
        return aligned

    def open_loop_validation(self) -> ValidationScore:
        if self._open_loop_score is None:
            window = self.recovery
            with torch.no_grad():
                open_loop = tukf06.open_loop_prediction(window.context, window.forcing)
            predictions = {int(lead): np.asarray(open_loop, dtype=np.float64) for lead in LEADS}
            # the open loop is lead-independent under perfect future forcing: lead-k forecast at target t is the open-loop value at t
            self._open_loop_score = validation_score_from_predictions(window, predictions, extra={"source": "tukf06.open_loop_prediction"})
        return self._open_loop_score

    def validate(self) -> ValidationScore:
        predictions = self._predictions(self.theta.detach(), self.recovery)
        return validation_score_from_predictions(self.recovery, predictions)

    # ------------------------------------------------------------------ protocol
    def parameter_count(self) -> int:
        return int(self.theta.numel())

    def parameter_vector(self) -> np.ndarray:
        return self.theta.detach().cpu().numpy().astype(np.float64).copy()

    def step(self) -> StepDiagnostic:
        self.optimizer.zero_grad(set_to_none=True)
        try:
            training = self.segmented_objective(self.theta, grad=True)
            objective = training["objective"]
            objective.backward()
        except FloatingPointError as error:
            return StepDiagnostic(None, None, None, filter_passes=self.segment_count, divergence_kinds=("nonfinite_training_forward",), extra={"error": str(error)})
        except ENGINE_ERRORS as error:
            # E9 Important 1: an engine failure (Cholesky / LinAlgError / invalid state) is the frozen rule's
            # "filter state non-finite" case; it is recorded as a divergence, never as a crashed run.
            return StepDiagnostic(None, None, None, filter_passes=self.segment_count, divergence_kinds=("nonfinite_filter_state",),
                                  extra={"error": f"{type(error).__name__}: {error}"})
        grad = self.theta.grad
        if grad is None or not bool(torch.isfinite(grad).all()):
            return StepDiagnostic(float(objective.detach()), training["mse_by_lead"], None, filter_passes=self.segment_count,
                                  divergence_kinds=("nonfinite_gradient",), extra={"ukf_per_segment_objective": training["per_segment_objective"]})
        gradient_norm = float(torch.linalg.norm(grad.detach()))
        self._last_gradient = grad.detach().cpu().numpy().tolist()
        self.optimizer.step()
        with torch.no_grad():
            self.theta.clamp_(min=self.lower, max=self.upper)
        return StepDiagnostic(
            float(objective.detach()),
            training["mse_by_lead"],
            gradient_norm,
            filter_passes=self.segment_count,
            divergence_kinds=(),
            extra={"ukf_per_segment_objective": training["per_segment_objective"], "ukf_gradient_log": self._last_gradient},
        )

    def epoch_extra(self) -> dict[str, Any]:
        theta = self.parameter_vector()
        return {
            "device_name": "cpu" if self.device.type == "cpu" else str(torch.cuda.get_device_name(0)),
            "torch_num_threads": int(torch.get_num_threads()),
            "ukf_theta_log": theta.tolist(),
            "ukf_q_diagonal": np.exp(theta[: self.dimension]).tolist(),
            "ukf_r_b": float(np.exp(theta[self.dimension])),
            "ukf_boundary": boundary_report(theta, self.dimension),
            "ukf_start": dict(self.start),
            "access_ledger": {
                "archive_member_reads": dict(self.ledger.archive_member_reads),
                "date_requests": int(self.ledger.date_requests),
                "evaluation_array_reads": int(self.ledger.evaluation_array_reads),
                "evaluation_prediction_count": int(self.ledger.evaluation_prediction_count),
                "evaluation_metric_count": int(self.ledger.evaluation_metric_count),
                "evaluation_output_count": int(self.ledger.evaluation_output_count),
            },
        }

    def checkpoint_state(self) -> dict[str, Any]:
        return {"theta": self.theta.detach().cpu().clone(), "optimizer": self.optimizer.state_dict()}

    def load_checkpoint_state(self, state: Mapping[str, Any]) -> None:
        with torch.no_grad():
            self.theta.copy_(torch.as_tensor(state["theta"], dtype=torch.float64, device=self.device))
        self.optimizer.load_state_dict(state["optimizer"])

    def parameter_checkpoint(self) -> dict[str, Any]:
        return {"theta": self.theta.detach().cpu().clone(), "state_dimension": self.dimension}
