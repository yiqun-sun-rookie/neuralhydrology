"""Contract A (aligned rematch) trainer package; see docs/plans/v3_aligned_rematch_regional_20260916/plan.md."""
