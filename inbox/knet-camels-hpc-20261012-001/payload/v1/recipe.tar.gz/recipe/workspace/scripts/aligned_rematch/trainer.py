"""The aligned training loop shared by the KalmanNet arm and the differentiable-UKF arm.

Contract v2 section 3: <= 200 updates (one per epoch), early stopping after 40 epochs without
improvement of the validation objective, divergence when the validation objective is non-finite
or exceeds 100 x the open-loop validation objective, one selected checkpoint per run (strictly
smallest validation objective, earliest epoch on ties), and a ledger with identical members
for both arms. The loop persists a parameter checkpoint every epoch and a resumable ``last.pt``.
"""
from __future__ import annotations

import hashlib
import json
import math
import time
from pathlib import Path
from typing import Any, Mapping, Protocol

import numpy as np
import torch

from scripts.aligned_rematch import contract as C
from scripts.aligned_rematch.ledger import (
    ENGINE_ERRORS,
    LEDGER_ROW_MEMBERS,
    StepDiagnostic,
    ValidationScore,
    classify_failure_form,
    finite_or_none,
    learned_flag,
    make_row,
)


class Arm(Protocol):
    name: str

    def parameter_count(self) -> int: ...
    def parameter_vector(self) -> np.ndarray: ...
    def open_loop_validation(self) -> ValidationScore: ...
    def validate(self) -> ValidationScore: ...          # raises FloatingPointError when non-finite
    def step(self) -> StepDiagnostic: ...
    def epoch_extra(self) -> dict[str, Any]: ...
    def checkpoint_state(self) -> dict[str, Any]: ...    # parameters + optimizer + arm RNG
    def load_checkpoint_state(self, state: Mapping[str, Any]) -> None: ...
    def parameter_checkpoint(self) -> dict[str, Any]: ...  # parameters only (for selection / unsealing)


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _write_json(path: Path, value: Any) -> str:
    data = (json.dumps(value, indent=1, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_bytes(data)
    tmp.replace(path)
    return _sha256_bytes(data)


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    if isinstance(value, (np.floating, float)):
        number = float(value)
        return number if math.isfinite(number) else None
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, np.ndarray):
        return _json_safe(value.tolist())
    return value


def _save_torch(path: Path, payload: Mapping[str, Any]) -> str:
    tmp = path.with_name(path.name + ".tmp")
    torch.save(dict(payload), tmp)
    tmp.replace(path)
    return _sha256_bytes(path.read_bytes())


def parameter_sha256(vector: np.ndarray) -> str:
    array = np.ascontiguousarray(np.asarray(vector))
    digest = hashlib.sha256()
    digest.update(str(array.dtype).encode("ascii"))
    digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
    digest.update(array.tobytes())
    return digest.hexdigest()


def displacement(before: np.ndarray, after: np.ndarray) -> tuple[float | None, float | None]:
    before64 = np.asarray(before, dtype=np.float64)
    after64 = np.asarray(after, dtype=np.float64)
    delta = after64 - before64
    norm_before = float(np.linalg.norm(before64))
    relative = float(np.linalg.norm(delta) / norm_before) if norm_before > 0 else None
    return relative, (float(np.max(np.abs(delta))) if delta.size else None)


class AlignedTrainer:
    """Run (or resume) one aligned training run of one arm inside ``run_directory``."""

    def __init__(
        self,
        arm: Arm,
        *,
        run_directory: Path,
        identity: Mapping[str, Any],
        epoch_ceiling: int = C.UPDATE_CEILING,
        patience: int = C.EARLY_STOPPING_PATIENCE,
        divergence_ratio: float = C.DIVERGENCE_RATIO_VS_OPEN_LOOP,
        clock=time.perf_counter,
    ) -> None:
        self.arm = arm
        self.run_directory = Path(run_directory)
        self.identity = dict(identity)
        self.epoch_ceiling = int(epoch_ceiling)
        self.patience = int(patience)
        self.divergence_ratio = float(divergence_ratio)
        self.clock = clock
        self.rows: list[dict[str, Any]] = []
        self.open_loop: ValidationScore | None = None
        self.best_epoch = 0
        self.best_objective = math.inf
        self.best_score: ValidationScore | None = None
        self.epochs_since_improvement = 0
        self.optimizer_steps = 0
        self.filter_passes = 0
        self.cumulative_wall = 0.0
        self.stop_reason: str | None = None
        self.divergence_kinds: tuple[str, ...] = ()
        self.divergence_epoch: int | None = None
        self.resumed_from_epoch: int | None = None
        self.last_validation_error: str | None = None

    # ------------------------------------------------------------------ persistence
    @property
    def checkpoints(self) -> Path:
        return self.run_directory / "checkpoints"

    @property
    def last_path(self) -> Path:
        return self.checkpoints / "last.pt"

    def _persist_ledger(self) -> None:
        _write_json(self.run_directory / "epoch_history.json", _json_safe(self.rows))

    def _persist_last(self, epoch: int) -> None:
        payload = {
            "schema_version": C.SCHEMA_VERSION,
            "identity": self.identity,
            "epoch": int(epoch),
            "arm_state": self.arm.checkpoint_state(),
            "rows": _json_safe(self.rows),
            "best_epoch": self.best_epoch,
            "best_objective": self.best_objective,
            "best_score": self.best_score.as_dict() if self.best_score is not None else None,
            "open_loop": self.open_loop.as_dict() if self.open_loop is not None else None,
            "epochs_since_improvement": self.epochs_since_improvement,
            "optimizer_steps": self.optimizer_steps,
            "filter_passes": self.filter_passes,
            "cumulative_wall_seconds": self.cumulative_wall,
            "stop_reason": self.stop_reason,
            "divergence_kinds": list(self.divergence_kinds),
            "divergence_epoch": self.divergence_epoch,
            "torch_rng_state": torch.get_rng_state(),
            "numpy_rng_state": np.random.get_state(),
        }
        _save_torch(self.last_path, payload)

    def _persist_parameter_checkpoint(self, epoch: int) -> tuple[str, str]:
        path = self.checkpoints / f"epoch_{epoch:03d}.pt"
        digest = _save_torch(
            path,
            {
                "schema_version": C.SCHEMA_VERSION,
                "identity": self.identity,
                "epoch": int(epoch),
                **self.arm.parameter_checkpoint(),
            },
        )
        return path.relative_to(self.run_directory).as_posix(), digest

    def _try_resume(self) -> int | None:
        if not self.last_path.is_file():
            return None
        payload = torch.load(self.last_path, map_location="cpu", weights_only=False)
        if payload.get("schema_version") != C.SCHEMA_VERSION or payload.get("identity") != self.identity:
            raise RuntimeError("last.pt identity differs from this run; refusing to resume")
        self.arm.load_checkpoint_state(payload["arm_state"])
        self.rows = [dict(row) for row in payload["rows"]]
        self.best_epoch = int(payload["best_epoch"])
        self.best_objective = float(payload["best_objective"])
        self.best_score = ValidationScore(**payload["best_score"]) if payload["best_score"] else None
        self.open_loop = ValidationScore(**payload["open_loop"]) if payload["open_loop"] else None
        self.epochs_since_improvement = int(payload["epochs_since_improvement"])
        self.optimizer_steps = int(payload["optimizer_steps"])
        self.filter_passes = int(payload["filter_passes"])
        self.cumulative_wall = float(payload["cumulative_wall_seconds"])
        self.stop_reason = payload.get("stop_reason")
        self.divergence_kinds = tuple(payload.get("divergence_kinds") or ())
        self.divergence_epoch = payload.get("divergence_epoch")
        torch.set_rng_state(payload["torch_rng_state"])
        np.random.set_state(payload["numpy_rng_state"])
        self.resumed_from_epoch = int(payload["epoch"])
        return int(payload["epoch"])

    # ------------------------------------------------------------------ helpers
    def _score_row(self, score: ValidationScore | None, status: str) -> dict[str, Any]:
        if score is None:
            return {
                "validation_status": status,
                "validation_objective_728": None,
                "validation_reporting_objective_712": None,
                "validation_mse_by_lead_712": None,
                "validation_nse_by_lead_712": None,
                "validation_mse_by_lead_728": None,
                "validation_ratio_vs_open_loop": None,
            }
        ratio = None
        if self.open_loop is not None and self.open_loop.objective_728 > 0:
            ratio = float(score.objective_728 / self.open_loop.objective_728)
        return {
            "validation_status": "FINITE",
            "validation_objective_728": float(score.objective_728),
            "validation_reporting_objective_712": float(score.reporting_objective_712),
            "validation_mse_by_lead_712": dict(score.mse_by_lead_712),
            "validation_nse_by_lead_712": dict(score.nse_by_lead_712),
            "validation_mse_by_lead_728": dict(score.mse_by_lead_728),
            "validation_ratio_vs_open_loop": ratio,
        }

    def _validate_safely(self) -> tuple[ValidationScore | None, str]:
        self.last_validation_error = None
        try:
            score = self.arm.validate()
        except FloatingPointError as error:
            self.last_validation_error = f"{type(error).__name__}: {error}"
            return None, "NONFINITE"
        except ENGINE_ERRORS as error:
            # E9 Important 1: an engine failure while filtering the validation window is the frozen rule's
            # "filter state non-finite" case; the epoch is recorded as DIVERGED_AT_VALIDATION, not as a crash.
            self.last_validation_error = f"{type(error).__name__}: {error}"
            return None, "NONFINITE"
        values = [
            score.objective_728,
            score.reporting_objective_712,
            *score.mse_by_lead_712.values(),
            *score.mse_by_lead_728.values(),
        ]
        if not all(math.isfinite(float(v)) for v in values):
            return None, "NONFINITE"
        return score, "FINITE"

    def _update_best(self, epoch: int, score: ValidationScore | None) -> bool:
        if score is not None and float(score.objective_728) < self.best_objective:
            self.best_objective = float(score.objective_728)
            self.best_epoch = int(epoch)
            self.best_score = score
            self.epochs_since_improvement = 0
            return True
        if epoch > 0:
            self.epochs_since_improvement += 1
        return False

    # ------------------------------------------------------------------ main loop
    def run(self) -> dict[str, Any]:
        self.run_directory.mkdir(parents=True, exist_ok=True)
        self.checkpoints.mkdir(exist_ok=True)
        resumed_epoch = self._try_resume()
        started = self.clock()
        if resumed_epoch is None:
            self.open_loop = self.arm.open_loop_validation()
            score, status = self._validate_safely()
            if score is None:
                raise FloatingPointError("epoch-zero validation is non-finite")
            vector = self.arm.parameter_vector()
            self.filter_passes += 1
            path, digest = self._persist_parameter_checkpoint(0)
            self._update_best(0, score)
            elapsed = self.clock() - started
            self.cumulative_wall += elapsed
            self.rows.append(
                make_row(
                    epoch=0,
                    epoch_status="EPOCH_ZERO",
                    wall_seconds=float(elapsed),
                    cumulative_wall_seconds=float(self.cumulative_wall),
                    optimizer_steps=0,
                    filter_passes=self.filter_passes,
                    training_objective=None,
                    training_mse_by_lead=None,
                    gradient_norm=None,
                    parameter_relative_displacement=None,
                    parameter_max_abs_displacement=None,
                    parameter_sha256=parameter_sha256(vector),
                    **self._score_row(score, status),
                    is_best_so_far=True,
                    epochs_since_improvement=0,
                    divergence_kinds=[],
                    checkpoint=path,
                    checkpoint_sha256=digest,
                    arm_extra=_json_safe(self.arm.epoch_extra()),
                )
            )
            self._persist_ledger()
            self._persist_last(0)
            next_epoch = 1
        else:
            next_epoch = resumed_epoch + 1
            if self.stop_reason is not None:
                next_epoch = self.epoch_ceiling + 1  # terminal state already reached: finalize only
            elif self.epochs_since_improvement >= self.patience:
                self.stop_reason = "EARLY_STOP"
                next_epoch = self.epoch_ceiling + 1

        for epoch in range(next_epoch, self.epoch_ceiling + 1):
            epoch_started = self.clock()
            before = self.arm.parameter_vector()
            diagnostic = self.arm.step()
            self.filter_passes += int(diagnostic.filter_passes)
            if diagnostic.divergence_kinds:
                # fourth-draft triggers before validation (non-finite gradient / post-step ratio):
                # no new parameters are accepted; the previous checkpoint is the terminal state.
                elapsed = self.clock() - epoch_started
                self.cumulative_wall += elapsed
                self.rows.append(
                    make_row(
                        epoch=epoch,
                        epoch_status="DIVERGED_BEFORE_VALIDATION",
                        wall_seconds=float(elapsed),
                        cumulative_wall_seconds=float(self.cumulative_wall),
                        optimizer_steps=self.optimizer_steps,
                        filter_passes=self.filter_passes,
                        training_objective=finite_or_none(diagnostic.training_objective),
                        training_mse_by_lead=diagnostic.training_mse_by_lead,
                        gradient_norm=finite_or_none(diagnostic.gradient_norm),
                        parameter_relative_displacement=None,
                        parameter_max_abs_displacement=None,
                        parameter_sha256=parameter_sha256(before),
                        **self._score_row(None, "NOT_EVALUATED"),
                        is_best_so_far=False,
                        epochs_since_improvement=self.epochs_since_improvement,
                        divergence_kinds=list(diagnostic.divergence_kinds),
                        checkpoint=None,
                        checkpoint_sha256=None,
                        arm_extra=_json_safe({**self.arm.epoch_extra(), **diagnostic.extra}),
                    )
                )
                self.stop_reason = "DIVERGED"
                self.divergence_kinds = tuple(diagnostic.divergence_kinds)
                self.divergence_epoch = epoch
                self._persist_ledger()
                self._persist_last(epoch)
                break
            self.optimizer_steps += C.UPDATES_PER_EPOCH
            after = self.arm.parameter_vector()
            relative, max_abs = displacement(before, after)
            path, digest = self._persist_parameter_checkpoint(epoch)
            score, status = self._validate_safely()
            self.filter_passes += 1
            kinds: list[str] = []
            if score is None:
                kinds.append("nonfinite_validation")
            elif self.open_loop is not None and float(score.objective_728) > self.divergence_ratio * float(
                self.open_loop.objective_728
            ):
                kinds.append("validation_ratio_vs_open_loop")
            is_best = self._update_best(epoch, score) if not kinds else False
            if kinds:
                # a diverged epoch is never an improvement (E9 Important 2: same rule whether or not a score exists,
                # so the independent verifier's recount agrees with the ledger)
                self.epochs_since_improvement += 1
            validation_extra = {"validation_error": self.last_validation_error} if self.last_validation_error else {}
            elapsed = self.clock() - epoch_started
            self.cumulative_wall += elapsed
            self.rows.append(
                make_row(
                    epoch=epoch,
                    epoch_status="DIVERGED_AT_VALIDATION" if kinds else "TRAINED",
                    wall_seconds=float(elapsed),
                    cumulative_wall_seconds=float(self.cumulative_wall),
                    optimizer_steps=self.optimizer_steps,
                    filter_passes=self.filter_passes,
                    training_objective=finite_or_none(diagnostic.training_objective),
                    training_mse_by_lead=diagnostic.training_mse_by_lead,
                    gradient_norm=finite_or_none(diagnostic.gradient_norm),
                    parameter_relative_displacement=relative,
                    parameter_max_abs_displacement=max_abs,
                    parameter_sha256=parameter_sha256(after),
                    **self._score_row(score, status),
                    is_best_so_far=is_best,
                    epochs_since_improvement=self.epochs_since_improvement,
                    divergence_kinds=kinds,
                    checkpoint=path,
                    checkpoint_sha256=digest,
                    arm_extra=_json_safe({**self.arm.epoch_extra(), **diagnostic.extra, **validation_extra}),
                )
            )
            if kinds:
                self.stop_reason = "DIVERGED"
                self.divergence_kinds = tuple(kinds)
                self.divergence_epoch = epoch
            elif self.epochs_since_improvement >= self.patience:
                self.stop_reason = "EARLY_STOP"
            self._persist_ledger()
            self._persist_last(epoch)
            if self.stop_reason is not None:
                break
        if self.stop_reason is None:
            self.stop_reason = "CEILING"
            self._persist_last(self.epoch_ceiling)
        return self.finalize()

    # ------------------------------------------------------------------ summary
    def finalize(self) -> dict[str, Any]:
        if self.open_loop is None or self.best_score is None:
            raise RuntimeError("cannot finalize without open-loop and best scores")
        learned = learned_flag(self.best_score, self.open_loop)
        completed = max(int(row["epoch"]) for row in self.rows if row["epoch_status"] in ("EPOCH_ZERO", "TRAINED"))
        best_row = next((row for row in self.rows if int(row["epoch"]) == self.best_epoch), None)
        summary = {
            "schema_version": C.SCHEMA_VERSION,
            "experiment_family": C.EXPERIMENT_FAMILY,
            "identity": self.identity,
            "arm": self.arm.name,
            "trainable_parameter_count": int(self.arm.parameter_count()),
            "stop_reason": self.stop_reason,
            "completed_epochs": int(completed),
            "gradient_updates": int(self.optimizer_steps),
            "filter_passes": int(self.filter_passes),
            "cumulative_wall_seconds": float(self.cumulative_wall),
            "resumed_from_epoch": self.resumed_from_epoch,
            "divergence_kinds": list(self.divergence_kinds),
            "divergence_epoch": self.divergence_epoch,
            "best_epoch": int(self.best_epoch),
            "best_checkpoint": best_row["checkpoint"] if best_row else None,
            "best_checkpoint_sha256": best_row["checkpoint_sha256"] if best_row else None,
            "best_validation": self.best_score.as_dict(),
            "open_loop_validation": self.open_loop.as_dict(),
            "epoch_zero_validation_objective_728": float(self.rows[0]["validation_objective_728"]),
            "learned": bool(learned),
            "failure_form": classify_failure_form(
                stop_reason=str(self.stop_reason), learned=learned, best_epoch=self.best_epoch, rows=self.rows
            ),
            "ledger_members": list(LEDGER_ROW_MEMBERS),
            "epoch_history": "epoch_history.json",
            "arm_summary": _json_safe(self.arm.epoch_extra()),
        }
        _write_json(self.run_directory / "result_summary.json", _json_safe(summary))
        return summary
