"""Frozen constants of contract A (aligned rematch), 2026-09-16 contract v2 sections 3-5.

Everything here is a transcription of the frozen contract. Nothing is tunable. The two arms
share the optimizer budget, the early-stopping rule, the seed set, the selection rule, the
"learned" and "diverged" definitions, and the ledger schema.
"""
from __future__ import annotations

import math

EXPERIMENT_FAMILY = "DAILY_CAMELS_KNET_ALIGNED_REMATCH_V3_20260916"
SCHEMA_VERSION = "daily_camels_knet_aligned_rematch_v3"
CONTRACT_DOCUMENT = "docs/plans/2026-09-16-daily-camels-knet-aligned-rematch-and-regional-contract-draft-v2.md"
CONTRACT_SHA256 = "d36bbe086917dbc92deb2e913e60414f616ea635d1c267d8b2b6d26b8591196d"

ARMS = ("knet", "ukf")
SEEDS = (20260824, 20260901, 20260908, 20260915, 20260922)

# --- shared optimisation protocol (contract section 3) ---
UPDATE_CEILING = 200                 # <= 200 gradient updates, one per epoch
UPDATES_PER_EPOCH = 1
EARLY_STOPPING_PATIENCE = 40         # validation objective not improved for 40 consecutive epochs -> stop
DIVERGENCE_RATIO_VS_OPEN_LOOP = 100.0  # validation objective > 100 x open-loop validation objective -> DIVERGED
OPTIMIZER = "Adam"
LEADS = (1, 2, 3)
LEAD_WEIGHTS = (1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0)
SEGMENT_DAYS = 150
SEGMENT_FILTER_WARMUP_DAYS = 45
FIXED_TRAINING_SEGMENT_STARTS = (
    0, 100, 201, 301, 401, 501, 602, 702, 802, 903, 1003, 1103, 1204,
    1304, 1404, 1504, 1605, 1705, 1805, 1906, 2006, 2106, 2207, 2307, 2407,
)
FIXED_TRAINING_SEGMENT_COUNT = 25
CHECKPOINT_OBJECTIVE = "physical_unit_multilead_mse_728"   # 731-day recovery window, no warm-up, 728 targets per lead
REPORTING_OBJECTIVE = "physical_unit_multilead_mse_712"    # same window after the 16-day filter warm-up
STOP_REASONS = ("EARLY_STOP", "CEILING", "DIVERGED")
FAILURE_FORMS = ("LEARNED", "NOT_BETTER_THAN_OPEN_LOOP", "WEAK_THEN_DEGRADED", "DIVERGED")
WEAK_THEN_DEGRADED_RATIO = 1.5       # after the best epoch the validation objective rose to >= 1.5 x best

# --- KalmanNet arm (unchanged from the fourth-draft contract) ---
KNET_LEARNING_RATE = 0.0005
KNET_WEIGHT_DECAY = 0.0
KNET_GRADIENT_MAXIMUM_NORM = 10.0
KNET_HIDDEN_DIMENSION = 24
KNET_INPUT_MULTIPLIER = 10
KNET_OUTPUT_MULTIPLIER = 10
KNET_FEATURE_SCALE_FLOOR = 0.1
KNET_NORMALIZED_FEATURE_GUARD = 10.0
KNET_CORRECTION_CAP_IN_STATE_SCALE_UNITS = 3.0
KNET_GAIN_INITIALIZATION = "near_zero_fc2_head"
KNET_POST_STEP_RATIO_TRIGGER = 100.0   # fourth-draft trigger two (same-segment post-step objective vs pre-step)
KNET_REQUIRED_GPU_NAME = "NVIDIA A40"   # applies only when the KalmanNet arm runs on a GPU
KNET_TRAINING_FORECAST_ERROR_EVENTS_PER_EPOCH = 25 * 3 * (150 - 45 - 3)  # 7650

# --- user decisions of 2026-09-17 ("按建议继续"), recorded in authorization.md item 5 ---
# (A) KalmanNet arm hardware: contract v2 section 3 default was hgpu4 shared A40; changed by the user to
#     hcpu48 single-thread CPU workers after the E1 probes (A40 52-54 s/epoch but one free card all day;
#     icn CPU 31 s/epoch, single-thread saturated). Science unchanged; E8 becomes CPU-vs-A40 (disclosed).
KNET_EXECUTION_PARTITION = "hcpu48"
KNET_EXECUTION_DEVICE = "cpu"
KNET_EXECUTION_THREADS = 1
UKF_EXECUTION_PARTITION = "hcpu48"
# (B) reachability rule: the contract's arithmetic ln(10/0.001)=9.2 < 200*0.05=10 is evaluated at the
#     neutral anchor; the per-seed distance from the actual perturbed start is disclosed, not gated.
UKF_REACHABILITY_RULE = "anchor"

# --- differentiable UKF arm (contract v2 section 3 changes) ---
UKF_LEARNING_RATE = 0.05             # Adam on natural-log coordinates
UKF_ANCHOR_STORAGE_Q = 0.001         # neutral anchor: every process-noise diagonal element
UKF_ANCHOR_ROUTING_Q = 0.001
UKF_ANCHOR_R_B = 0.02
UKF_START_LOG_PERTURBATION_STD = 1.0  # theta0 = ln(anchor) + N(0, 1^2) per coordinate, seeded
UKF_PROCESS_Q_LOWER = 1e-5           # box: lower bounds unchanged, upper bounds raised
UKF_PROCESS_Q_UPPER = 10.0
UKF_R_B_LOWER = 0.0025
UKF_R_B_UPPER = 1.0
UKF_SEGMENT_INITIAL_COVARIANCE_DIAGONAL = 0.001
UKF_BOUNDARY_OUTER_FRACTION = 0.05
UKF_REACHABILITY_BUDGET_LOG_UNITS = UPDATE_CEILING * UKF_LEARNING_RATE   # 10.0
UKF_HBV_STORAGE_STATE_COUNT = 5      # states 0..4 are storages, 5.. are routing buffer entries
SOBOL_REFERENCE_CANDIDATE_COUNT = 256

# --- validation geometry (unchanged) ---
VALIDATION_DAYS = 731
CHECKPOINT_TARGET_COUNT_PER_LEAD = 728
REPORTING_TARGET_COUNT_PER_LEAD = 712
FILTER_WARMUP_DAYS = 16

BASIN_ORDER = (
    "04105700", "08190500", "02102908", "12447390", "01487000", "02178400", "08070200",
    "09513780", "06803510", "03076600", "12175500", "09035800", "04027000", "08109700",
    "08086290", "01440400", "05503800", "03049000", "01435000", "02092500", "14185900",
)


def ukf_log_bounds(state_dimension: int) -> tuple[list[float], list[float]]:
    """Natural-log box of contract A: process diagonal [1e-5, 10], r_b [0.0025, 1.0]."""
    m = int(state_dimension)
    lower = [math.log(UKF_PROCESS_Q_LOWER)] * m + [math.log(UKF_R_B_LOWER)]
    upper = [math.log(UKF_PROCESS_Q_UPPER)] * m + [math.log(UKF_R_B_UPPER)]
    return lower, upper


def ukf_anchor_log(state_dimension: int) -> list[float]:
    m = int(state_dimension)
    storages = [math.log(UKF_ANCHOR_STORAGE_Q)] * UKF_HBV_STORAGE_STATE_COUNT
    routing = [math.log(UKF_ANCHOR_ROUTING_Q)] * (m - UKF_HBV_STORAGE_STATE_COUNT)
    return storages + routing + [math.log(UKF_ANCHOR_R_B)]


def run_id(arm: str, basin_id: str, seed: int) -> str:
    if arm not in ARMS:
        raise ValueError(f"unknown arm {arm!r}")
    if basin_id not in BASIN_ORDER:
        raise ValueError(f"unknown basin {basin_id!r}")
    if int(seed) not in SEEDS:
        raise ValueError(f"unknown seed {seed!r}")
    return f"{EXPERIMENT_FAMILY}_{arm.upper()}_BASIN_{basin_id}_SEED_{int(seed)}"


def sobol_reference_id(basin_id: str) -> str:
    if basin_id not in BASIN_ORDER:
        raise ValueError(f"unknown basin {basin_id!r}")
    return f"{EXPERIMENT_FAMILY}_SOBOL_REFERENCE_BASIN_{basin_id}"
