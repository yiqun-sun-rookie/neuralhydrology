"""KalmanNet arm of contract A.

The training step is the second-version step, function for function
(``backward_equal_segment_objective`` over the 25 frozen segments, finite/non-zero gradient
check, ``clip_grad_norm_(10.0)``, ``Adam(5e-4)``, same-segment post-step diagnostic, correction
cap 3.0 with saturation tracking). Only the outer loop (200-update ceiling, patience 40, seeds,
open-loop-referenced divergence, ledger) differs; that loop lives in ``trainer.py``.
"""
from __future__ import annotations

import math
from typing import Any, Mapping

import numpy as np
import torch

from scripts.aligned_rematch import contract as C
from scripts.aligned_rematch.ledger import ENGINE_ERRORS, StepDiagnostic, ValidationScore
from scripts.run_daily_camels_knet_per_basin_pilot import (
    FIXED_TRAINING_SEGMENT_STARTS,
    _evaluate_equal_segment_objective,
    _run_with_saturation_tracker,
    backward_equal_segment_objective,
)
from global_hydrology.experiments.daily_camels_knet_per_basin_contract import (
    CHECKPOINT_TARGET_COUNT_PER_LEAD,
    LEADS,
    REPORTING_TARGET_COUNT_PER_LEAD,
    get_development_basin_specification,
)
from global_hydrology.experiments.daily_camels_knet_per_basin_runner import (
    build_exact_dimension_kalman_net,
    evaluate_exact_zero_gain_open_loop,
    load_per_basin_development_runtime,
)
from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import (
    AccessLedger,
    CAUSAL_SHARED_SPINUP_MODE,
)
from global_hydrology.experiments.daily_camels_ukf_knet_parity_runner import (
    aligned_forecasts_from_posterior,
    forecast_pairs,
    run_knet_filter,
    previous_observation_before_window,
    score_forecast_pairs,
    segment_multilead_mse,
    select_window,
    training_open_loop_states,
)

assert tuple(FIXED_TRAINING_SEGMENT_STARTS) == C.FIXED_TRAINING_SEGMENT_STARTS


def validation_score_from_predictions(window: Any, predictions: Mapping[int, np.ndarray], *, extra: dict[str, Any] | None = None) -> ValidationScore:
    """712 reporting metrics (after the 16-day warm-up) and the 728-target checkpoint objective."""
    reporting = score_forecast_pairs(
        forecast_pairs(window.observations, predictions, issue_start=window.issue_start_local, issue_end=window.issue_end_local, leads=LEADS)
    )
    full = score_forecast_pairs(
        forecast_pairs(window.observations, predictions, issue_start=0, issue_end=len(window.observations) - max(LEADS), leads=LEADS)
    )
    if any(reporting.target_count_by_lead[lead] != REPORTING_TARGET_COUNT_PER_LEAD for lead in LEADS):
        raise RuntimeError("reporting target geometry changed")
    if any(full.target_count_by_lead[lead] != CHECKPOINT_TARGET_COUNT_PER_LEAD for lead in LEADS):
        raise RuntimeError("checkpoint target geometry changed")
    return ValidationScore(
        objective_728=float(full.objective),
        reporting_objective_712=float(reporting.objective),
        mse_by_lead_712={str(lead): float(reporting.mse_by_lead[lead]) for lead in LEADS},
        nse_by_lead_712={str(lead): float(reporting.nse_by_lead[lead]) for lead in LEADS},
        mse_by_lead_728={str(lead): float(full.mse_by_lead[lead]) for lead in LEADS},
        target_count_by_lead_712={str(lead): int(reporting.target_count_by_lead[lead]) for lead in LEADS},
        target_count_by_lead_728={str(lead): int(full.target_count_by_lead[lead]) for lead in LEADS},
        extra=dict(extra or {}),
    )


class KalmanNetArm:
    name = "knet"

    def __init__(
        self,
        *,
        basin_id: str,
        seed: int,
        device: str | torch.device,
        required_gpu_name: str | None = C.KNET_REQUIRED_GPU_NAME,
    ) -> None:
        self.basin_id = str(basin_id)
        self.seed = int(seed)
        self.device = torch.device(device)
        if self.device.type == "cuda":
            if not torch.cuda.is_available() or int(torch.cuda.device_count()) != 1:
                raise RuntimeError("exactly one visible CUDA device is required")
            actual = str(torch.cuda.get_device_name(0))
            if required_gpu_name is not None and actual != required_gpu_name:
                raise RuntimeError(f"required GPU {required_gpu_name!r}, found {actual!r}")
            self.device_name = actual
            torch.cuda.reset_peak_memory_stats(self.device)
        else:
            self.device_name = "cpu"
        self.cap = float(C.KNET_CORRECTION_CAP_IN_STATE_SCALE_UNITS)
        torch.manual_seed(self.seed)
        if self.device.type == "cuda":
            torch.cuda.manual_seed_all(self.seed)
        np.random.seed(self.seed)

        self.specification = get_development_basin_specification(self.basin_id)
        self.ledger = AccessLedger()
        self.runtime = load_per_basin_development_runtime(
            self.specification, ledger=self.ledger, initialization_mode=CAUSAL_SHARED_SPINUP_MODE, device=self.device
        )
        self.recovery = select_window(self.runtime, "recovery")
        self.network = build_exact_dimension_kalman_net(
            self.runtime,
            zero_gain=False,
            seed=self.seed,
            gain_initialization=C.KNET_GAIN_INITIALIZATION,
            hidden=C.KNET_HIDDEN_DIMENSION,
            input_multiplier=C.KNET_INPUT_MULTIPLIER,
            output_multiplier=C.KNET_OUTPUT_MULTIPLIER,
            feature_scale_floor=C.KNET_FEATURE_SCALE_FLOOR,
            normalized_feature_guard=C.KNET_NORMALIZED_FEATURE_GUARD,
            correction_cap_in_state_scale_units=self.cap,
        )
        self.optimizer = torch.optim.Adam(
            self.network.parameters(), lr=C.KNET_LEARNING_RATE, weight_decay=C.KNET_WEIGHT_DECAY
        )
        self.open_loop_states = training_open_loop_states(self.runtime)
        self._open_loop_score: ValidationScore | None = None
        self._last_validation_saturation: dict[str, Any] | None = None
        self._last_step_saturation: dict[str, Any] = {}

    # ------------------------------------------------------------------ protocol
    def parameter_count(self) -> int:
        return int(sum(p.numel() for p in self.network.parameters() if p.requires_grad))

    def parameter_vector(self) -> np.ndarray:
        with torch.no_grad():
            return torch.cat([p.detach().reshape(-1) for _, p in sorted(self.network.named_parameters())]).cpu().numpy().astype(np.float64)

    def open_loop_validation(self) -> ValidationScore:
        if self._open_loop_score is None:
            zero = evaluate_exact_zero_gain_open_loop(
                self.runtime,
                self.recovery,
                seed=self.seed,
                hidden=C.KNET_HIDDEN_DIMENSION,
                input_multiplier=C.KNET_INPUT_MULTIPLIER,
                output_multiplier=C.KNET_OUTPUT_MULTIPLIER,
                feature_scale_floor=C.KNET_FEATURE_SCALE_FLOOR,
                normalized_feature_guard=C.KNET_NORMALIZED_FEATURE_GUARD,
                correction_cap_in_state_scale_units=self.cap,
            )
            posterior = torch.as_tensor(zero.posterior_states, device=self.device)
            predictions = aligned_forecasts_from_posterior(self.runtime, self.recovery, posterior)
            self._open_loop_score = validation_score_from_predictions(
                self.recovery, predictions, extra={"maximum_open_loop_difference": float(zero.maximum_open_loop_difference)}
            )
        return self._open_loop_score

    def _validate_operation(self) -> ValidationScore:
        self.network.eval()
        with torch.no_grad():
            trace = run_knet_filter(
                self.network, self.recovery, previous_observation=previous_observation_before_window(self.runtime, self.recovery)
            )
            predictions = aligned_forecasts_from_posterior(self.runtime, self.recovery, trace.posterior_states)
        return validation_score_from_predictions(self.recovery, predictions)

    def validate(self) -> ValidationScore:
        score, saturation = _run_with_saturation_tracker(network=self.network, cap=self.cap, operation=self._validate_operation)
        self._last_validation_saturation = dict(saturation)
        return ValidationScore(**{**score.as_dict(), "extra": {**score.extra, "validation_saturation": dict(saturation)}})

    def _segment_builder(self, start: int) -> Any:
        return segment_multilead_mse(
            self.network,
            self.runtime,
            start=int(start),
            segment_days=C.SEGMENT_DAYS,
            filter_warmup_days=C.SEGMENT_FILTER_WARMUP_DAYS,
            open_loop_states=self.open_loop_states,
        )

    def step(self) -> StepDiagnostic:
        self.network.train()
        self.optimizer.zero_grad(set_to_none=True)
        try:
            training_diagnostic, optimization_saturation = _run_with_saturation_tracker(
                network=self.network,
                cap=self.cap,
                operation=lambda: backward_equal_segment_objective(
                    starts=FIXED_TRAINING_SEGMENT_STARTS, segment_builder=self._segment_builder, leads=LEADS, torch_module=torch
                ),
            )
        except FloatingPointError as error:
            return StepDiagnostic(None, None, None, filter_passes=25, divergence_kinds=("nonfinite_training_forward",), extra={"error": str(error)})
        if int(training_diagnostic["training_forecast_error_events"]) != C.KNET_TRAINING_FORECAST_ERROR_EVENTS_PER_EPOCH:
            raise RuntimeError("epoch training forecast-error count changed")
        nonzero: list[str] = []
        nonfinite: list[str] = []
        for name, parameter in self.network.named_parameters():
            if parameter.grad is None:
                continue
            if not bool(torch.isfinite(parameter.grad).all()):
                nonfinite.append(name)
            elif bool(torch.count_nonzero(parameter.grad)):
                nonzero.append(name)
        training_objective = float(training_diagnostic["training_objective"])
        training_mse = {str(k): float(v) for k, v in training_diagnostic["training_mse_by_lead"].items()}
        extra_base = {
            "knet_optimization_forward_saturation": dict(optimization_saturation),
            "knet_nonzero_gradient_parameter_count": len(nonzero),
        }
        if nonfinite:
            return StepDiagnostic(training_objective, training_mse, None, filter_passes=25, divergence_kinds=("nonfinite_gradient",),
                                  extra={**extra_base, "knet_nonfinite_gradient_parameter_names": nonfinite})
        if not nonzero:
            raise RuntimeError("optimizer update has no nonzero gradient")
        gradient_norm = float(
            torch.nn.utils.clip_grad_norm_(self.network.parameters(), C.KNET_GRADIENT_MAXIMUM_NORM, error_if_nonfinite=False).detach().cpu()
        )
        if not math.isfinite(gradient_norm):
            return StepDiagnostic(training_objective, training_mse, gradient_norm, filter_passes=25,
                                  divergence_kinds=("nonfinite_gradient_norm",), extra=extra_base)
        self.optimizer.step()
        replay_error: str | None = None
        try:
            with torch.no_grad():
                post_step_objective, post_step_saturation = _run_with_saturation_tracker(
                    network=self.network,
                    cap=self.cap,
                    operation=lambda: _evaluate_equal_segment_objective(
                        starts=FIXED_TRAINING_SEGMENT_STARTS, segment_builder=self._segment_builder, allow_nonfinite=True
                    ),
                )
        except (FloatingPointError, *ENGINE_ERRORS) as error:
            # E9 Important 1: a replay that raises (instead of returning a non-finite objective) is the same
            # fourth-draft trigger; the updated parameters are still handed to the trainer, which stops before validation.
            post_step_objective, post_step_saturation = float("nan"), {}
            replay_error = f"{type(error).__name__}: {error}"
        kinds: list[str] = []
        post_ratio = None
        if not math.isfinite(float(post_step_objective)):
            kinds.append("nonfinite_post_step")
            if replay_error is not None:
                extra_base = {**extra_base, "knet_post_step_replay_error": replay_error}
        else:
            post_ratio = float(post_step_objective) / training_objective if training_objective > 0 else None
            if post_ratio is not None and post_ratio > C.KNET_POST_STEP_RATIO_TRIGGER:
                kinds.append("post_step_ratio")
        self._last_step_saturation = {
            "knet_optimization_forward_saturation": dict(optimization_saturation),
            "knet_post_step_replay_saturation": dict(post_step_saturation),
        }
        return StepDiagnostic(
            training_objective,
            training_mse,
            gradient_norm,
            filter_passes=50,
            divergence_kinds=tuple(kinds),
            extra={
                **extra_base,
                "knet_post_step_replay_saturation": dict(post_step_saturation),
                "knet_same_segment_post_step_objective": float(post_step_objective) if math.isfinite(float(post_step_objective)) else None,
                "knet_post_step_ratio": post_ratio,
            },
        )

    def epoch_extra(self) -> dict[str, Any]:
        extra: dict[str, Any] = {
            "device_name": self.device_name,
            "correction_cap_in_state_scale_units": self.cap,
            "knet_validation_saturation": self._last_validation_saturation,
            "access_ledger": {
                "archive_member_reads": dict(self.ledger.archive_member_reads),
                "date_requests": int(self.ledger.date_requests),
                "evaluation_array_reads": int(self.ledger.evaluation_array_reads),
                "evaluation_prediction_count": int(self.ledger.evaluation_prediction_count),
                "evaluation_metric_count": int(self.ledger.evaluation_metric_count),
                "evaluation_output_count": int(self.ledger.evaluation_output_count),
            },
        }
        if self.device.type == "cuda":
            extra["gpu_peak_allocated_bytes"] = int(torch.cuda.max_memory_allocated(self.device))
            extra["gpu_peak_reserved_bytes"] = int(torch.cuda.max_memory_reserved(self.device))
        return extra

    def checkpoint_state(self) -> dict[str, Any]:
        state = {
            "network": {k: v.detach().cpu().clone() for k, v in self.network.state_dict().items()},
            "optimizer": self.optimizer.state_dict(),
            "torch_cuda_rng_state": torch.cuda.get_rng_state_all() if self.device.type == "cuda" else None,
        }
        return state

    def load_checkpoint_state(self, state: Mapping[str, Any]) -> None:
        self.network.load_state_dict({k: v.to(self.device) for k, v in state["network"].items()})
        self.optimizer.load_state_dict(state["optimizer"])
        if self.device.type == "cuda" and state.get("torch_cuda_rng_state") is not None:
            torch.cuda.set_rng_state_all(state["torch_cuda_rng_state"])

    def parameter_checkpoint(self) -> dict[str, Any]:
        return {
            "network": {k: v.detach().cpu().clone() for k, v in self.network.state_dict().items()},
            # sorted trainable parameter names: lets the verifier recompute parameter_sha256 without a model
            "parameter_names": [name for name, _ in sorted(self.network.named_parameters())],
        }
