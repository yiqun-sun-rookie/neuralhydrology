"""Verified entry; resource handshake precedes scientific library import."""
import sys,os,json,importlib.util
from pathlib import Path
RUN=Path(__file__).resolve().parent;ROOT=RUN.parent
sp=importlib.util.spec_from_file_location('safe_io',ROOT/'safe_io.py');s=importlib.util.module_from_spec(sp);sys.modules['safe_io']=s;sp.loader.exec_module(s)
s.read_checked(ROOT/'safe_io.py','a6d8e8c1b1582f56cb5869231d156c300ed380403a1b7886b5b586536ef3850c')
phase,basin=sys.argv[1:3];os.environ['KNET_BASIN']=basin
manifest=json.loads(s.read_checked(RUN/('execution_sources.json' if phase in ('imports','train') else 'evaluation_sources.json')))
for row in manifest['files']:s.read_checked(Path(row['path']),row['sha256'])
if phase!='imports':
 receipt=json.loads(sys.stdin.readline())
 if receipt.get('resources_configured') is not True:raise RuntimeError('resource handshake absent')
if phase=='imports':
 import common,training_support
 from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
 from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
 assert [(b,get_development_basin_specification(b).state_dimension) for b in ('04105700','08070200','09035800')]==[('04105700',7),('08070200',11),('09035800',18)]
 print(json.dumps(dict(status='IMPORTS_AND_REGISTRY_PASS',scientific_forwards=0,optimizer_updates=0)),flush=True)
else:
 sys.argv=[sys.argv[0],basin]
 name='train.py' if phase=='train' else 'evaluate.py'
 raw=s.read_checked(RUN/name,next(r['sha256'] for r in manifest['files'] if Path(r['path'])==RUN/name))
 exec(compile(raw,str(RUN/name),'exec'),{'__name__':'__main__','__file__':str(RUN/name)})
