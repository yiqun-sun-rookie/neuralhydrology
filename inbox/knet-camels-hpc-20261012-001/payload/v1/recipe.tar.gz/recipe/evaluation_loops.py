import math,traceback
import numpy as np
import torch
from training_common import numerical_exception
TOL=1e-12

def native_filter(net, forcing, observations, initial, previous, allow_failure=False, evidence=None):
    net.initialize_filter(initial.clone(),sequence_length=len(forcing),previous_observation=previous)
    posts=[]; priors=[]; corrections=[]; hits=[]; failure=None
    scale=getattr(net,'state_correction_scale',net.state_feature_scale)
    for day in range(len(forcing)):
        if evidence is not None: evidence.update(day=day,posts=posts,priors=priors,corrections=corrections,hits=hits)
        try:
            post=net.analysis_step(observations[day,0].reshape(1,1),forcing[day,0].reshape(1,3))
            posts.append(post.clone()); priors.append(net.m1x_prior.clone())
            correction=net.last_correction.clone(); corrections.append(correction)
            hits.append((correction/scale).abs()>=3*(1-1e-9))
            if not bool(torch.isfinite(net.m1x_prior).all()) or not bool(torch.isfinite(post).all()):
                raise FloatingPointError(f'non-finite KalmanNet state at local day {day}')
            if not bool((correction.abs()<=3*scale+TOL).all()): raise RuntimeError('correction cap changed')
        except Exception as error:
            available={name:getattr(net,name).detach().cpu().clone() for name in
                ('m1x_prior','m1x_posterior','KGain','last_correction')
                if isinstance(getattr(net,name,None),torch.Tensor)}
            if evidence is not None: evidence['failed_state']=available
            if not allow_failure or not numerical_exception(error): raise
            failure={'day':day,'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc(),
                'available_state':available}
            break
    return posts,priors,corrections,hits,failure

def available_forecasts(model,posts,forcing,evidence=None):
    """Use the original full case forcing for every finite available origin.

    The score contract's common origin end is retained. A failed assimilation
    does not remove future meteorology for earlier posterior states.
    """
    n=len(forcing)-3
    prediction=np.full((n,3),np.nan)
    if evidence is not None: evidence['partial_prediction']=prediction
    if not posts: return prediction,[]
    origins=np.arange(min(len(posts),n))
    state=torch.stack(posts)[:len(origins),0,:]
    valid=torch.isfinite(state).all(dim=1)
    origins=origins[valid.detach().cpu().numpy()]
    state=state[valid]
    failures=[]
    if evidence is not None: evidence['forecast_exceptions']=failures
    if not len(origins): return prediction,failures
    for lead in (1,2,3):
        try:
            state=model.f(state,forcing[origins+lead,0,:])
            values=model.h(state)[:,0]
            prediction[origins,lead-1]=values.detach().cpu().numpy()
            if not bool(torch.isfinite(values).all()):
                failures.append({'phase':'forecast','lead':lead,'type':'FloatingPointError',
                    'message':'nonfinite future meteorological forecast','traceback':None})
        except Exception as error:
            if not numerical_exception(error): raise
            failures.append({'phase':'forecast','lead':lead,'type':type(error).__name__,
                'message':str(error),'traceback':traceback.format_exc()})
            break
    return prediction,failures