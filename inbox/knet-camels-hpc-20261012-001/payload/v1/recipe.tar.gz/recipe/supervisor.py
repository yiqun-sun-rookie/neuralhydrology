"""Single scientific process; immutable receipts, capped resources, no resume."""
import sys,os,json,time,subprocess,threading,datetime,traceback,importlib.util
from pathlib import Path
import psutil
RUN=Path(__file__).resolve().parent;ROOT=RUN.parent
sp=importlib.util.spec_from_file_location('safe_io',ROOT/'safe_io.py');s=importlib.util.module_from_spec(sp);sys.modules['safe_io']=s;sp.loader.exec_module(s)
def put(name,obj):return s.create(str((RUN/name).relative_to(ROOT)),obj)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
 plan=json.loads(s.read_checked(RUN/'approved_plan.json'));limits=plan['resource_limits'];started=time.monotonic();receipts=[]
 put('supervisor_started.json',dict(pid=os.getpid(),created_utc=now(),process_creation_time=psutil.Process().create_time(),limits=limits))
 env=dict(os.environ)
 for key in list(env):
  if key.startswith('PYTHON'):env.pop(key)
 env.update(PYTHONPATH=str(ROOT/'deps'),PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',ATEN_CPU_CAPABILITY='default')
 parent=psutil.Process();parent.cpu_affinity([2]);parent.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
 stop=None
 for basin in plan['basin_order']:
  for phase in ('train','evaluate'):
   if time.monotonic()-started>=limits['total_training_evaluation_wall_seconds']:stop='TOTAL_WALL_LIMIT';break
   manifest=RUN/('execution_sources.json' if phase=='train' else 'evaluation_sources.json')
   if not manifest.exists():stop='MISSING_PHASE_SOURCE_MANIFEST';break
   binding=json.loads(s.read_checked(manifest))
   for row in binding['files']:s.read_checked(Path(row['path']),row['sha256'])
   put(basin+'/phases/'+phase+'/source_manifest.json',binding)
   command=[r'C:/Users/yiqun/anaconda3/envs/knet_clean/python.exe','-X','utf8','-B',str(RUN/'worker.py'),phase,basin]
   chunks=[];began=time.monotonic();rss_peak=0;free_min=None;samples=0;resource_stop=None
   child=psutil.Popen(command,cwd=str(RUN),env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
   child.cpu_affinity([2]);child.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
   assert child.cpu_affinity()==[2] and child.nice()==16384
   put(basin+'/phases/'+phase+'/started.json',dict(started_utc=now(),pid=child.pid,create_time=child.create_time(),command=command,cpu_affinity=[2],priority=16384))
   def consume():
    for line in iter(child.stdout.readline,b''):
     chunks.append(line)
     print(basin,phase,line.decode('utf-8',errors='replace').rstrip(),flush=True)
   reader=threading.Thread(target=consume,daemon=True);reader.start()
   child.stdin.write(b'{"resources_configured":true}\n');child.stdin.flush();child.stdin.close()
   while child.poll() is None:
    try:
     rss=sum(p.memory_info().rss for p in [parent,child]+child.children(recursive=True));free=psutil.virtual_memory().available
     rss_peak=max(rss_peak,rss);free_min=free if free_min is None else min(free_min,free);samples+=1
     budget=limits['training_wall_seconds_per_basin' if phase=='train' else 'evaluation_wall_seconds_per_basin']
     if rss>limits['combined_working_set_bytes']:resource_stop='WORKING_SET_LIMIT'
     elif free<limits['minimum_system_free_bytes']:resource_stop='SYSTEM_FREE_MEMORY_LIMIT'
     elif time.monotonic()-began>budget:resource_stop='PHASE_WALL_LIMIT'
     elif time.monotonic()-started>limits['total_training_evaluation_wall_seconds']:resource_stop='TOTAL_WALL_LIMIT'
     if resource_stop:child.terminate();break
    except psutil.NoSuchProcess:pass
    time.sleep(1)
   child.wait();reader.join()
   log=put(basin+'/phases/'+phase+'/stdout.log',b''.join(chunks))
   receipt=dict(basin=basin,phase=phase,exit_code=child.returncode,resource_stop=resource_stop,wall_seconds=time.monotonic()-began,rss_peak=rss_peak,system_free_min=free_min,samples=samples,log=log,ended_utc=now())
   put(basin+'/phases/'+phase+'/receipt.json',receipt);receipts.append(receipt)
   if resource_stop or child.returncode!=0:stop=resource_stop or 'TECHNICAL_FAILURE';break
  if stop:break
 result=dict(status='TECHNICAL_INCOMPLETE' if stop else 'PHASES_COMPLETE',stop_reason=stop,receipts=receipts,wall_seconds=time.monotonic()-started,ended_utc=now())
 put('supervisor_result.json',result)
 print(json.dumps(result),flush=True)
 return 1 if stop else 0
if __name__=='__main__':raise SystemExit(main())
