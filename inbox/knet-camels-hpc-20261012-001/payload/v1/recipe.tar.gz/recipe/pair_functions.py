import torch


def physical_posts(runtime, forcing, initial):
    state = initial.clone()
    posts = []
    with torch.no_grad():
        for day in range(len(forcing)):
            state = runtime.context.plain_model.f(state, forcing[day, 0].reshape(1, 3))
            if not bool(torch.isfinite(state).all()):
                raise FloatingPointError('nonfinite physical state')
            posts.append(state.clone())
    return torch.stack(posts)

def validation(net, runtime, parity, window, helpers=None):
    def operation():
        net.eval()
        with torch.no_grad():
            trace = parity.run_knet_filter(net, window,
                previous_observation=parity.previous_observation_before_window(runtime, window))
            predictions = parity.aligned_forecasts_from_posterior(runtime, window, trace.posterior_states)
        full = parity.score_forecast_pairs(parity.forecast_pairs(window.observations, predictions,
            issue_start=0, issue_end=len(window.observations)-3, leads=(1, 2, 3)))
        reported = parity.score_forecast_pairs(parity.forecast_pairs(window.observations, predictions,
            issue_start=window.issue_start_local, issue_end=window.issue_end_local, leads=(1, 2, 3)))
        if any(full.target_count_by_lead[k] != 728 or reported.target_count_by_lead[k] != 712 for k in (1, 2, 3)):
            raise RuntimeError('validation dates changed')
        return {'objective_728': float(full.objective), 'objective_712': float(reported.objective),
            'mse_by_lead_728': {str(k): float(full.mse_by_lead[k]) for k in (1, 2, 3)},
            'mse_by_lead_712': {str(k): float(reported.mse_by_lead[k]) for k in (1, 2, 3)},
            'nse_by_lead_712': {str(k): float(reported.nse_by_lead[k]) for k in (1, 2, 3)},
            'count_by_lead_728': {str(k): int(full.target_count_by_lead[k]) for k in (1, 2, 3)},
            'count_by_lead_712': {str(k): int(reported.target_count_by_lead[k]) for k in (1, 2, 3)}}
    if helpers is None:
        return operation()
    result, saturation = helpers._run_with_saturation_tracker(network=net, cap=3.0, operation=operation)
    result['saturation'] = saturation
    return result