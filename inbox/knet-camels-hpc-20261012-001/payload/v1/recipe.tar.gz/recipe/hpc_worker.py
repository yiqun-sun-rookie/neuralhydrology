"""Portable entry. Real experiments need a separate explicit execution contract."""
import datetime
import importlib.util
import json
import os
from pathlib import Path
import sys

RUN = Path(__file__).resolve().parent
ROOT = RUN.parent
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))
spec = importlib.util.spec_from_file_location('safe_io', ROOT / 'safe_io.py')
s = importlib.util.module_from_spec(spec)
sys.modules['safe_io'] = s
spec.loader.exec_module(s)
phase, basin = sys.argv[1:3]
if phase not in ('imports', 'train', 'evaluate'):
    raise ValueError('unsupported phase')
if not os.environ.get('SLURM_JOB_ID', '').isdigit():
    raise RuntimeError('compute job required')
os.environ['KNET_BASIN'] = basin
if phase != 'imports':
    contract = json.loads(s.read_checked(ROOT / 'execution_authorization.json'))
    if contract.get('status') != 'AUTHORIZED' or phase not in contract.get('phases', []) or basin not in contract.get('basins', []):
        raise PermissionError('this preparation has no real experiment authorization')
    if contract.get('current_local_run_repeated') is not False:
        raise PermissionError('completed local experiment cannot be repeated implicitly')
manifest = json.loads(s.read_checked(RUN / ('execution_sources.json' if phase in ('imports', 'train') else 'evaluation_sources.json')))
for row in manifest['files']:
    s.read_checked(ROOT / row['path'], row['sha256'])
for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    if os.environ.get(key) != '1':
        raise RuntimeError('single-thread environment required')
import psutil
process = psutil.Process()
allocated = process.cpu_affinity()
process.cpu_affinity([min(allocated)])
process.nice(10)
import torch
torch.set_num_threads(1)
if phase == 'imports':
    torch.set_num_interop_threads(1)
torch.use_deterministic_algorithms(True)
if phase == 'imports':
    import common
    import training_support
    from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
    from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
    dimensions = [(b, get_development_basin_specification(b).state_dimension) for b in ('04105700', '08070200', '09035800')]
    assert dimensions == [('04105700', 7), ('08070200', 11), ('09035800', 18)]
    print(json.dumps({'status': 'IMPORTS_AND_REGISTRY_PASS', 'scientific_forwards': 0,
                      'optimizer_updates': 0, 'dimensions': dimensions, 'torch_threads': torch.get_num_threads(),
                      'torch_interop_threads': torch.get_num_interop_threads(), 'affinity': process.cpu_affinity(),
                      'priority_nice': process.nice(), 'python': sys.version.split()[0]}), flush=True)
else:
    name = 'train.py' if phase == 'train' else 'evaluate.py'
    digest = next(row['sha256'] for row in manifest['files'] if row['path'] == 'recipe/' + name)
    raw = s.read_checked(RUN / name, digest)
    sys.argv = [str(RUN / name), basin]
    exec(compile(raw, str(RUN / name), 'exec'), {'__name__': '__main__', '__file__': str(RUN / name)})
