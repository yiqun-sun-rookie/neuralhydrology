"""Basin-specific checked inputs, fresh initialization and exclusive evidence outputs."""
import os,sys,io,json,hashlib,threading,importlib.util,importlib.machinery,builtins
from pathlib import Path
import numpy as np
import torch
RUN=Path(__file__).resolve().parent
ROOT=RUN.parent
BASIN=os.environ['KNET_BASIN']
if BASIN not in ('04105700','08070200','09035800','02092500'):raise ValueError('unregistered execution basin')
HERE=RUN/BASIN
WORKSPACE=RUN/'workspace'
sys.path.insert(0,str(ROOT))
from safe_io import read_checked,checked_path,create
PLAN=json.loads(read_checked(HERE/'plan.json'))
CATALOG=json.loads(read_checked(RUN/'input_catalog.json'))
DIGESTS={str((RUN/r['path']).resolve()).lower():r['sha256'] for r in CATALOG['files']}
LOCAL=threading.local()
_original_builtin_open=builtins.open
_original_io_open=io.open
_original_get_code=importlib.machinery.SourceFileLoader.get_code

def source_digest(path):
 key=str(Path(path).resolve()).lower()
 if key in DIGESTS:return DIGESTS[key]
 catalog=json.loads(read_checked(RUN/'execution_sources.json'))
 return next(r['sha256'] for r in catalog['files'] if str(Path(r['path']).resolve()).lower()==key)
def source_bytes(path):
 LOCAL.reading=True
 try:return read_checked(Path(path).resolve(),source_digest(path))
 finally:LOCAL.reading=False

def checked_open(original,file,mode='r',*args,**kwargs):
 if getattr(LOCAL,'reading',False) or not isinstance(file,(str,bytes,os.PathLike)):return original(file,mode,*args,**kwargs)
 path=Path(os.fsdecode(file)).absolute()
 if path.is_relative_to(WORKSPACE):
  if any(k in mode for k in 'wax+'):raise PermissionError('immutable workspace')
  stream=io.BytesIO(source_bytes(path))
  if 'b' in mode:return stream
  encoding=kwargs.get('encoding') or (args[1] if len(args)>1 else None) or 'utf-8'
  return io.TextIOWrapper(stream,encoding=encoding,errors=kwargs.get('errors'),newline=kwargs.get('newline'))
 return original(file,mode,*args,**kwargs)
def get_code(loader,fullname):
 path=Path(loader.path).absolute()
 if path.is_relative_to(WORKSPACE):return compile(source_bytes(path),str(path),'exec')
 return _original_get_code(loader,fullname)
builtins.open=lambda file,mode='r',*a,**kw:checked_open(_original_builtin_open,file,mode,*a,**kw)
io.open=lambda file,mode='r',*a,**kw:checked_open(_original_io_open,file,mode,*a,**kw)
importlib.machinery.SourceFileLoader.get_code=get_code
sys.dont_write_bytecode=True
sys.path[:0]=[str(WORKSPACE/'src'),str(WORKSPACE)]

def checked_source(name,path):
 path=Path(path);raw=source_bytes(path)
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);sys.modules[name]=module
 exec(compile(raw,str(path),'exec'),module.__dict__);return module
helpers=checked_source('exp_training_common',RUN/'training_common.py')
diag=checked_source('exp_diagnosis_common',RUN/'diagnosis_common.py')
probe=checked_source('exp_source_probe',RUN/'source_probe.py')

def obj(path):
 p=Path(path);return json.loads(read_checked(p if p.is_absolute() else HERE/p))
def save(name,value):
 path=checked_path(HERE/str(name),False)
 if not path.is_relative_to(HERE):raise PermissionError('output escapes basin')
 return create(str(path.relative_to(ROOT)),helpers.safe(value))
def tensor_save(name,value):
 stream=io.BytesIO();torch.save(value,stream);return save(name,stream.getvalue())
def save_arrays(name,arrays):
 stream=io.BytesIO();np.savez_compressed(stream,**arrays);return save(name,stream.getvalue())
class Store:
 json=staticmethod(save);tensors=staticmethod(tensor_save);arrays=staticmethod(save_arrays);read_checked=staticmethod(read_checked)
 def load_arrays(self,identity):
  with np.load(io.BytesIO(read_checked(ROOT/identity['path'],identity['sha256'])),allow_pickle=False) as data:return {k:data[k].copy() for k in data.files}
 def load_tensors(self,identity):return torch.load(io.BytesIO(read_checked(ROOT/identity['path'],identity['sha256'])),map_location='cpu',weights_only=True)
_runtime=None
_states=None
_scales=None

def setup():
 global _runtime,_states,_scales
 if _runtime is not None:return _runtime
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
 from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
 from global_hydrology.experiments import daily_camels_ukf_knet_parity_runner as parity
 from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
 from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import AccessLedger,CAUSAL_SHARED_SPINUP_MODE
 specification=get_development_basin_specification(BASIN)
 runtime=per.load_per_basin_development_runtime(specification,ledger=AccessLedger(),initialization_mode=CAUSAL_SHARED_SPINUP_MODE,device='cpu')
 assert runtime.context.basin_id==BASIN and runtime.training_days==2557
 assert runtime.context.dimension=={'04105700':7,'08070200':11,'09035800':18,'02092500':11}[BASIN]
 assert tuple(runtime.forcing.shape)==(3288,1,3) and np.isfinite(runtime.observations.cpu().numpy()).all()
 assert str(runtime.dates[2556].astype('datetime64[D]'))=='2006-09-30'
 assert np.all(np.diff(runtime.dates.astype('datetime64[D]').astype('int64'))==1)
 _states=parity.training_open_loop_states(runtime)
 original_states=parity.training_open_loop_states
 parity.training_open_loop_states=lambda r:_states if r is runtime else original_states(r)
 _scales=parity.fit_training_feature_scales(runtime,floor=.1)
 original_scales=per.fit_training_feature_scales
 per.fit_training_feature_scales=lambda r,*,floor=.1:_scales if r is runtime and floor==.1 else original_scales(r,floor=floor)
 original_advance=parity._advance_open_loop
 parity._advance_open_loop=lambda context,forcing,*,end_exclusive:_states[-1].clone() if context is runtime.context and end_exclusive==2557 else original_advance(context,forcing,end_exclusive=end_exclusive)
 _runtime=runtime,per,parity,dict(seed=20260922)
 return _runtime

def open_states():
 setup();return _states

def build(runtime,per,parity,settings,epoch=0,requires_grad=False):
 if epoch!=0:raise ValueError('fresh build only')
 net=per.build_exact_dimension_kalman_net(runtime,zero_gain=False,seed=20260922,gain_initialization='near_zero_fc2_head',hidden=24,input_multiplier=10,output_multiplier=10,feature_scale_floor=.1,normalized_feature_guard=10.,correction_cap_in_state_scale_units=3.)
 for p in net.parameters():p.requires_grad_(requires_grad)
 net.eval();return net

def startup_evidence(net,optimizer):
 runtime,per,parity,settings=setup()
 assert len(optimizer.state)==0
 assert net.state_feature_scale.shape==(1,runtime.context.dimension)
 return dict(basin_id=BASIN,state_dimension=runtime.context.dimension,seed=20260922,
  parameter_tensors=len(list(net.parameters())),parameter_elements=sum(p.numel() for p in net.parameters()),
  network_sha256=helpers.digest_tree(net.state_dict()),parameter_sha256=parity.parameter_sha256(net),
  optimizer_state_empty=True,weights_loaded_from_another_basin=False,scale_fit_start=0,scale_fit_end_exclusive=2557,
  state_feature_scale=net.state_feature_scale.tolist(),observation_feature_scale=net.observation_feature_scale.tolist(),
  training_start=str(runtime.dates[0]),training_end=str(runtime.dates[2556]),validation_start=str(runtime.dates[2557]),development_end=str(runtime.dates[-1]),
  archive_sha256=runtime.archive_sha256,archive_members=runtime.ledger.archive_member_reads)

def physical_validation(runtime,parity,pair):
 window=parity.select_window(runtime,'recovery')
 states=pair.physical_posts(runtime,window.forcing,window.initial_state)
 with torch.no_grad():predictions=parity.aligned_forecasts_from_posterior(runtime,window,states)
 arrays={'states':states.cpu().numpy(),'dates':window.dates.astype('datetime64[ns]').astype('int64')}
 result={}
 for label,start in [('728',0),('712',16)]:
  pairs=parity.forecast_pairs(window.observations,predictions,issue_start=start,issue_end=728,leads=(1,2,3))
  score=parity.score_forecast_pairs(pairs);result['objective_'+label]=float(score.objective)
  for field in ('mse_by_lead','nse_by_lead','target_count_by_lead'):result[field+'_'+label]={str(k):float(v) for k,v in getattr(score,field).items()}
  for lead in (1,2,3):
   key=label+'_lead'+str(lead)
   arrays[key+'_forecast']=pairs.predictions[lead];arrays[key+'_target']=pairs.targets[lead]
   for kind in ('issue','target'):
    indices=getattr(pairs,kind+'_indices')[lead]+2557;arrays[key+'_'+kind+'_indices']=indices;arrays[key+'_'+kind+'_dates']=runtime.dates[indices].astype('datetime64[ns]').astype('int64')
 result['artifact']=save_arrays('baselines/physical_validation.npz',arrays)
 save('baselines/physical_validation.json',result)
 return result
