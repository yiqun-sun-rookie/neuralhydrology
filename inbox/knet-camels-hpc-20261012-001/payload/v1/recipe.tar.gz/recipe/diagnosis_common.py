"""Pure diagnostic helpers. Import never opens model inputs or starts a process."""
from contextlib import contextmanager
import math
import numpy as np
import torch

KINDS = ('core', 'gain', 'raw', 'actual', 'posterior')
STATUS = {'disconnected': 0, 'finite_zero': 1, 'finite_nonzero': 2, 'nonfinite': 3}


def bitmatch(a, b):
    return a.shape == b.shape and a.dtype == b.dtype and a.tobytes() == b.tobytes()


def classify(gradient, shape):
    if gradient is None:
        return np.zeros(shape, dtype=np.uint8)
    a = gradient.detach().cpu().numpy()
    return np.where(~np.isfinite(a), 3, np.where(a == 0, 1, 2)).astype(np.uint8)


def parameter_layout(net):
    rows, offset = [], 0
    for name, parameter in net.named_parameters():
        end = offset + parameter.numel()
        rows.append(dict(name=name, shape=list(parameter.shape), dtype=str(parameter.dtype),
                         offset=offset, end_offset=end, group=name.split('.')[0]))
        offset = end
    return rows


def copy_gradients(net):
    return {name: None if p.grad is None else p.grad.detach().cpu().clone()
            for name, p in net.named_parameters()}


@contextmanager
def observe_rollout(module):
    """Save the actual gradient-enabled forecast tensor, returning it unchanged."""
    original=module.rollout
    recorded=[]
    def observer(*args,**kwargs):
        result=original(*args,**kwargs)
        recorded.append(result)
        return result
    module.rollout=observer
    try:
        yield recorded
    finally:
        module.rollout=original


@contextmanager
def incoming_gradients(net):
    """Observe the actual leaf input, without modifying it or accumulated .grad."""
    values = {name: None for name, _ in net.named_parameters()}
    calls = {name: 0 for name in values}
    handles = []
    def make_hook(name):
        def hook(gradient):
            calls[name] += 1
            # One backward per segment must call each used leaf exactly once.
            if calls[name] != 1:
                raise RuntimeError('multiple incoming leaf calls: ' + name)
            values[name] = gradient.detach().cpu().clone()
            return None
        return hook
    try:
        for name, parameter in net.named_parameters():
            handles.append(parameter.register_hook(make_hook(name)))
        yield values, calls
    finally:
        for handle in handles:
            handle.remove()


def vector_arrays(tree, layout):
    """Missing entries remain NaN with an explicit per-tensor None mask."""
    values, status, none = [], [], []
    for row in layout:
        g = tree[row['name']]
        shape = tuple(row['shape'])
        none.append(g is None)
        values.append(np.full(row['end_offset']-row['offset'], np.nan, dtype=np.float32)
                      if g is None else g.numpy().reshape(-1).copy())
        status.append(classify(g, shape).reshape(-1))
    return dict(parameter_vector=np.concatenate(values),
                parameter_status=np.concatenate(status), parameter_is_none=np.asarray(none))


def contribution(tree, layout):
    """Float64 arithmetic: disconnected paths contribute no derivative, mask retained elsewhere."""
    return np.concatenate([np.zeros(r['end_offset']-r['offset'], dtype=np.float64)
                           if tree[r['name']] is None else tree[r['name']].numpy().reshape(-1).astype(np.float64)
                           for r in layout])


def vector_relation(a, b):
    a, b = np.asarray(a, dtype=np.float64), np.asarray(b, dtype=np.float64)
    if not np.isfinite(a).all() or not np.isfinite(b).all():
        return dict(finite=False, a_l2=None, b_l2=None, difference_l2=None, dot=None, cosine=None)
    na, nb, nd = (float(np.linalg.norm(x)) for x in (a, b, a-b))
    dot = float(np.dot(a, b))
    cosine = None if na == 0 or nb == 0 else max(-1., min(1., dot/(na*nb)))
    return dict(finite=True, a_l2=na, b_l2=nb, difference_l2=nd, dot=dot, cosine=cosine,
                relative_difference=None if na == 0 else nd/na)


def group_norms(vector, layout):
    groups = {}
    for row in layout:
        values = np.asarray(vector[row['offset']:row['end_offset']], dtype=np.float64)
        groups.setdefault(row['group'], []).append(values)
    return {name: float(np.linalg.norm(np.concatenate(values))) for name, values in groups.items()}


def rank_segments(rows):
    if not rows or any(r['weighted_l2'] is None or not math.isfinite(r['weighted_l2']) for r in rows):
        raise FloatingPointError('cannot rank nonfinite or missing segment gradients')
    return sorted(rows, key=lambda r: (-r['weighted_l2'], r['start']))


def target_geometry(start, days=800, warmup=695):
    issues = np.arange(start+warmup, start+days-3, dtype=np.int64)
    indices = issues[:, None] + np.arange(1, 4, dtype=np.int64)
    if len(issues) != 102 or indices.shape != (102, 3):
        raise ValueError('expected 102 issue/target dates per lead')
    return issues, indices


@contextmanager
def analysis_observer(net, cut_day, detach, active, start, dates, after_step=None):
    """Same native_filter operations; cut all recurrence immediately before one step."""
    original = net.analysis_step
    had_override = 'analysis_step' in net.__dict__
    day = 0
    def observed(observation, controls):
        nonlocal day
        active.update(local_day=day, global_day=start+day, date=str(dates[day]))
        if day == cut_day:
            detach(net)
        result = original(observation, controls)
        if after_step is not None:
            after_step(net)
        day += 1
        return result
    net.analysis_step = observed
    try:
        yield
    finally:
        if had_override:
            net.analysis_step = original
        else:
            del net.analysis_step


def distribution(values):
    a = np.asarray(values, dtype=np.float64)
    finite = a[np.isfinite(a)]
    return dict(count=int(a.size), finite_count=int(finite.size), nonfinite_count=int(a.size-finite.size),
                maximum=None if not finite.size else float(finite.max()),
                percentiles=None if not finite.size else dict(zip(('p0','p25','p50','p75','p95','p99','p100'),
                    map(float, np.percentile(finite, [0,25,50,75,95,99,100])))))


def node_summary(gradient, statuses, dates, labels):
    """Never relabel None as zero; block L2 is over connected entries only."""
    connected = statuses != STATUS['disconnected']
    finite_rows = connected.any(axis=1) & ((~connected) | np.isfinite(gradient)).all(axis=1)
    # Zero for disconnected contributions is used only inside a stated L2 calculation.
    contribution_values = np.where(connected, gradient, 0.)
    daily = np.linalg.norm(contribution_values, axis=1)
    daily[~finite_rows] = np.nan
    blocks = {}
    for begin, end in ((0,200),(200,400),(400,650),(650,695),(695,797),(797,800)):
        sl = slice(begin, end); present = connected[sl]
        values = gradient[sl][present]
        blocks[f'{begin}:{end}'] = dict(
            connected_l2=float(np.linalg.norm(values)) if np.isfinite(values).all() else None,
            counts={name: int((statuses[sl] == code).sum()) for name, code in STATUS.items()},
            day_norm_distribution=distribution(daily[sl]))
    states = []
    for index, label in enumerate(labels):
        values = gradient[:, index]; mask = connected[:, index] & np.isfinite(values)
        peak = None if not mask.any() else int(np.where(mask, np.abs(values), -np.inf).argmax())
        states.append(dict(index=index, label=label,
                           absolute_gradient_distribution=distribution(np.abs(values[connected[:, index]])),
                           peak_local_day=peak, peak_date=None if peak is None else str(dates[peak]),
                           peak_signed_gradient=None if peak is None else float(values[peak]),
                           counts={name:int((statuses[:, index]==code).sum()) for name,code in STATUS.items()}))
    peak = None if not finite_rows.any() else int(np.where(finite_rows, daily, -np.inf).argmax())
    return dict(day_norm_distribution=distribution(daily), time_blocks=blocks, states=states,
                peak_local_day=peak, peak_date=None if peak is None else str(dates[peak]),
                peak_day_l2=None if peak is None else float(daily[peak]),
                norm_missing_policy='disconnected entries contribute no derivative to L2; disconnected-only dates are unavailable')
