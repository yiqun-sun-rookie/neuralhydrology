"""Two frozen component ablations plus one exact archived original replay."""
import os, sys, io, json, hashlib, datetime, importlib.util
from pathlib import Path


def main():
    base = Path(__file__).resolve().parent
    template = base.parents[1] / 'template'
    spec = importlib.util.spec_from_file_location('safe_io', base/'safe_io.py')
    s = importlib.util.module_from_spec(spec); sys.modules['safe_io'] = s; spec.loader.exec_module(s)
    assert os.environ.get('SLURM_JOB_ID', '').isdigit()
    assert json.loads(sys.stdin.readline())['resources_configured']
    planraw = s.read_checked(base/'plan_contract.json'); plan = json.loads(planraw)
    auth = json.loads(s.read_checked(base/'execution_authorization.json'))
    assert auth['status'] == 'AUTHORIZED' and auth['new_training_updates'] == 0
    for entry in auth['files']: s.read_checked(base/entry['path'], entry['sha256'])
    manifest = json.loads(s.read_checked(template/'bundle_manifest.json', auth['template_manifest_sha256']))
    for entry in manifest['files']: s.read_checked(template/entry['path'], entry['sha256'])
    import numpy as np
    import torch
    from frozen_rule import apply_rule
    torch.set_num_threads(1); torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True); torch.set_grad_enabled(False)
    os.chdir(template); sys.path.insert(0, str(template/'recipe')); os.environ['KNET_BASIN'] = '04105700'
    import common as C
    for name in ['execution_sources.json', 'evaluation_sources.json']:
        entries = json.loads(s.read_checked(template/'recipe'/name))['files']
        C.DIGESTS.update({str(Path(e['path']).resolve()).lower(): e['sha256'] for e in entries})
    from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
    from global_hydrology.experiments import daily_camels_ukf_knet_parity_runner as parity
    from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
    from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import AccessLedger, CAUSAL_SHARED_SPINUP_MODE
    out = 'runs/' + sys.argv[1]
    def arr(x): return x.detach().cpu().numpy().copy()
    def put(name, value): return s.create(out+'/'+name, value)
    def save_np(name, value):
        stream = io.BytesIO(); np.savez_compressed(stream, **value); return put(name, stream.getvalue())
    def load(name):
        with np.load(io.BytesIO(s.read_checked(base/'inputs'/name)), allow_pickle=False) as z:
            return {k:z[k].copy() for k in z.files}
    def emit(event, **kw): print(json.dumps(dict(event=event, utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), **kw)), flush=True)
    original = load('original.npz'); combined = load('combined.npz'); ref = load('reference.npz')
    runtime = per.load_per_basin_development_runtime(get_development_basin_specification('02092500'), ledger=AccessLedger(), initialization_mode=CAUSAL_SHARED_SPINUP_MODE, device='cpu')
    assert runtime.training_days == 2557 and runtime.context.dimension == 11
    model = runtime.context.plain_model
    TT = float(model.params['parTT'].item()); K2 = float(model.params['parK2'].item())
    initial = parity.training_open_loop_states(runtime)[-1].clone()
    previous = runtime.observations[2556:2557].clone()
    cp = torch.load(io.BytesIO(s.read_checked(base/'inputs/selected_checkpoint.pt')), weights_only=True, map_location='cpu')
    assert cp['epoch'] == 81 and C.helpers.digest_tree(cp['network']) == cp['network_sha256']
    net = per.build_exact_dimension_kalman_net(runtime, zero_gain=False, seed=plan['seed'], gain_initialization='near_zero_fc2_head', hidden=24, input_multiplier=10, output_multiplier=10, feature_scale_floor=.1, normalized_feature_guard=10., correction_cap_in_state_scale_units=3.)
    net.load_state_dict(cp['network'], strict=True); net.eval()
    for p in net.parameters(): p.requires_grad_(False)
    network_hash = C.helpers.digest_tree(net.state_dict())
    issue = np.arange(2557,3285); indices = np.arange(2557,3288)
    dates = runtime.dates.astype('datetime64[ns]').astype('int64')
    obs = arr(runtime.observations).reshape(-1)
    target = obs[issue[:,None]+np.arange(1,4)]
    target_dates = dates[issue[:,None]+np.arange(1,4)]
    input_checks = {
        'issue':np.array_equal(issue, ref['issue_indices']),
        'target':np.array_equal(target, ref['target']),
        'target_dates':np.array_equal(target_dates, ref['target_dates_ns']),
        'forcing':np.array_equal(arr(runtime.forcing)[2557:3288,0,:], ref['forcing']),
        'observations':np.array_equal(obs[2557:3288], ref['observations']),
        'initial':np.array_equal(arr(initial).reshape(-1), ref['initial_state']),
        'thresholds':np.array_equal(np.quantile(obs[:2557],[.5,.9,.99],method='linear'), ref['thresholds']),
        'TT_K2':TT == float(ref['TT']) and K2 == float(ref['K2']),
    }
    put('input_gate.json', {k:bool(v) for k,v in input_checks.items()})
    assert all(input_checks.values()), 'frozen input gate failed'
    def forecasts(post):
        state = torch.from_numpy(post[:728].copy()); predictions = []
        for lead in (1,2,3):
            state = model.f(state, runtime.forcing[issue+lead,0,:])
            predictions.append(arr(model.h(state)[:,0]))
        return np.stack(predictions, axis=1)
    def score(p,t):
        error = p-t
        return dict(count=int(error.size), mse=float(np.mean(error**2)), mae=float(np.mean(np.abs(error))), bias=float(np.mean(error)))
    results = {}; artifacts = []; steps = 0; initial_checks = {}
    snapshots = ['m1x_posterior','m1x_posterior_previous','m1x_prior_previous','y_previous','h_Q','c_Q','h_Sigma','c_Sigma','h_S','c_S']
    for arm, snow_on, lower_on in [('original_control',False,False),('snow_only',True,False),('lower_only',False,True)]:
        net.initialize_filter(initial.clone(), 731, previous_observation=previous.clone())
        snapshot = {k:arr(getattr(net,k)) for k in snapshots}
        initial_checks[arm] = {k:bool(np.array_equal(snapshot[k], original['initial_snapshot__'+k])) for k in snapshots}
        put('initial_gate__'+arm+'.json', initial_checks[arm])
        assert all(initial_checks[arm].values()), 'initial state/history/memory differs'
        histories = {k:[] for k in ['posterior','prior','native_posterior','requested_correction','realized_correction','innovation','gain','rule_events','blocked_by_source']}
        for day in range(2557,3288):
            y = runtime.observations[day,0].reshape(1,1); u = runtime.forcing[day,0].reshape(1,3)
            native = net.analysis_step(y,u); prior = net.m1x_prior
            requested = net.last_correction.clone(); innovation = float(y[0,0]-net.m1y[0,0])
            full, adjusted, transfer, snow_gate = apply_rule(net,y,u,prior,requested,innovation,TT,K2)
            # The frozen combined rule changes only snow[0] and lower storage[4].
            # Each ablation retains exactly one of those two coordinate changes.
            post = native
            if snow_on or lower_on:
                post = native.clone()
                if snow_on: post[:,0] = full[:,0]
                if lower_on: post[:,4] = full[:,4]
                net.m1x_posterior = post; net.last_correction = post-prior
            blocked = [float(torch.clamp((native-prior)[0,j]-requested[0,j], min=0.)) if innovation<0 and float(requested[0,j])<0 else 0. for j in (0,3)]
            assert bool(torch.isfinite(post).all()) and not bool((post<0).any())
            values = dict(posterior=arr(post)[0], prior=arr(prior)[0], native_posterior=arr(native)[0], requested_correction=arr(requested)[0], realized_correction=arr(post-prior)[0], innovation=innovation, gain=arr(net.KGain).reshape(-1), rule_events=[int(snow_on and snow_gate and float(requested[0,0])>0),transfer if lower_on else 0.], blocked_by_source=blocked)
            for k,v in values.items(): histories[k].append(v)
            steps += 1
        data = {k:np.asarray(v) for k,v in histories.items()}
        data.update(prediction=forecasts(data['posterior']),target=target,target_dates_ns=target_dates,issue_indices=issue,state_indices=indices,initial_state=arr(initial).reshape(-1),**{'initial_snapshot__'+k:v for k,v in snapshot.items()})
        artifact = save_np('trace__'+arm+'.npz', data); artifacts.append(artifact)
        if arm == 'original_control':
            differences = {k:float(np.max(np.abs(data[k]-original[k]))) for k in ['posterior','prior','prediction','requested_correction','innovation','gain']}
            put('original_replay_gate.json', dict(differences=differences,passed=max(differences.values())<=1e-12))
            assert max(differences.values())<=1e-12, 'exact original replay failed; no ablations allowed'
        results[arm] = dict(artifact=artifact, score=score(data['prediction'],target), snow_gate_days=int(data['rule_events'][:,0].sum()), transfer_days=int(np.count_nonzero(data['rule_events'][:,1])), transferred_mm=float(data['rule_events'][:,1].sum()))
        assert C.helpers.digest_tree(net.state_dict()) == network_hash, 'weights changed'
        emit('arm_complete',arm=arm,steps=steps,**results[arm]['score'])
    assert steps == plan['new_neural_assimilation_steps'] == 2193
    result = dict(status='COMPLETE',experiment_id=plan['experiment_id'],basin='02092500',selected_epoch=81,job_id=os.environ['SLURM_JOB_ID'],contract_sha256=hashlib.sha256(planraw).hexdigest(),rule_sha256=auth['rule_sha256'],network_sha256=network_hash,arms=results,reused_combined_score=score(combined['prediction'],target),new_neural_assimilation_steps=steps,new_training_updates=0,ukf_refit=False,initial_checks=initial_checks,runtime_versions=dict(torch=torch.__version__,numpy=np.__version__,python=sys.version))
    put('result.json',result); put('trace_manifest.json',dict(files=artifacts)); emit('ablation_complete',steps=steps)


if __name__ == '__main__': main()
