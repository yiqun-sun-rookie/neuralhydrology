"""Frozen small diagnostic of snow/slow-storage correction allocation; Slurm only."""
import os,sys,json,io,hashlib,datetime,importlib.util
from pathlib import Path

def main():
 base=Path(__file__).resolve().parent;template=base.parents[1]/'template'
 sp=importlib.util.spec_from_file_location('safe_io',base/'safe_io.py');s=importlib.util.module_from_spec(sp);sys.modules['safe_io']=s;sp.loader.exec_module(s)
 assert json.loads(sys.stdin.readline())['resources_configured'] and os.environ.get('SLURM_JOB_ID','').isdigit()
 out='runs/'+sys.argv[1];auth=json.loads(s.read_checked(base/'execution_authorization.json'));planraw=s.read_checked(base/'plan_contract.json');plan=json.loads(planraw)
 assert auth['status']=='AUTHORIZED' and auth['new_training_updates']==0
 for x in auth['files']:s.read_checked(base/x['path'],x['sha256'])
 bundle=json.loads(s.read_checked(template/'bundle_manifest.json',auth['template_manifest_sha256']))
 for x in bundle['files']:s.read_checked(template/x['path'],x['sha256'])
 import numpy as np
 import torch
 import metrics as M
 torch.set_num_threads(1);torch.use_deterministic_algorithms(True);torch.set_grad_enabled(False)
 os.chdir(template);os.environ['KNET_BASIN']='04105700';recipe=template/'recipe';sys.path.insert(0,str(recipe))
 import common as C
 for name in ['execution_sources.json','evaluation_sources.json']:
  manifest=json.loads(s.read_checked(recipe/name));C.DIGESTS.update({str(Path(x['path']).resolve()).lower():x['sha256'] for x in manifest['files']})
 def arr(x):return x.detach().cpu().numpy().copy()
 def emit(event,**kw):print(json.dumps(dict(event=event,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw),allow_nan=False),flush=True)
 def put(name,value):return s.create(out+'/'+name,value)
 def npz(name,value):
  b=io.BytesIO();np.savez_compressed(b,**value);return put(name,b.getvalue())
 old=Path(plan['previous_remote_root']);identities=json.loads(s.read_checked(base/'prior_trace_identities.json'))
 def load_old(label):
  identity=identities[label]
  with np.load(io.BytesIO(s.read_checked(old/identity['path'],identity['sha256'])),allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
 cp=torch.load(io.BytesIO(s.read_checked(old/'inputs/selected_checkpoint.pt',plan['checkpoint_sha256'])),map_location='cpu',weights_only=True)
 assert cp['epoch']==26 and C.helpers.digest_tree(cp['network'])==cp['network_sha256']
 runtime,per,parity,settings=C.setup();net=C.build(runtime,per,parity,settings);net.load_state_dict(cp['network'],strict=True);net.eval()
 model=runtime.context.plain_model;scales=arr(net.state_feature_scale).reshape(-1);network_hash=C.helpers.digest_tree(net.state_dict())
 obs=arr(runtime.observations).reshape(-1);dates=runtime.dates.astype('datetime64[ns]').astype('int64');forcing=arr(runtime.forcing)[:,0,:]
 thresholds=np.quantile(obs[:2557],[.5,.9,.99],method='linear');seasons={'DJF':[12,1,2],'MAM':[3,4,5],'JJA':[6,7,8],'SON':[9,10,11]}
 K2=float(model.params['parK2'].item());TT=float(model.params['parTT'].item());weights=arr(model.lag_weights).reshape(-1)
 cold=runtime.context.initial_state.clone();warm=cold.clone();warm[:,4]=C.open_states()[-1][:,4];main_initial=C.open_states()[-1].clone()
 initials={'cold':cold,'warm':warm,'main':main_initial};fields=['h_Q','c_Q','h_Sigma','c_Sigma','h_S','c_S']
 traces={};rows={};gates=[];trace_manifest=[];steps=0
 def forecast(post,indices):
  state=torch.from_numpy(post.copy());values=[]
  for lead in (1,2,3):
   state=model.f(state,runtime.forcing[indices+lead,0,:]);values.append(arr(model.h(state)[:,0]))
  return np.stack(values,axis=1)
 def windows(pred,target,issue):
  output={}
  for name,mask in [('first365',issue<2922),('common363',issue>=2922),('main728',issue>=2557)]:
   if not mask.any():continue
   # M.paired's reference is the unmodified warm trajectory, not UKF.
   reference=traces['warm_base']['prediction'][mask] if 'warm_base' in traces else pred[mask]
   output[name]=M.decompose(pred[mask],reference,target[mask],dates[issue[mask,None]+np.arange(1,4)],thresholds,seasons)
  return output
 for spec in plan['trajectories']:
  label=spec['label'];family=spec['initial'];policy=spec['policy'];initial=initials[family]
  previous=runtime.observations[2556:2557] if family=='main' else None
  net.initialize_filter(initial.clone(),731,previous_observation=previous)
  start_snapshot={k:arr(getattr(net,k)) for k in fields+['m1x_posterior','m1x_posterior_previous','m1x_prior_previous','y_previous']}
  posts=[];priors=[];requested=[];applied=[];gains=[];innovations=[];native_posts=[];active=[];carry=[]
  for day in range(2557,3288):
   y=runtime.observations[day,0].reshape(1,1);u=runtime.forcing[day,0].reshape(1,3)
   native=net.analysis_step(y,u);prior=net.m1x_prior;correction=net.last_correction.clone();innovation=float(y[0,0]-net.m1y[0,0]);adjusted=correction.clone()
   snow_gate=bool(float(u[0,1])>=TT and float(prior[0,0])<=0.)
   if policy in ('snow_gate','both') and snow_gate:adjusted[:,0]=torch.minimum(adjusted[:,0],torch.zeros_like(adjusted[:,0]))
   if policy=='no_snow_update':adjusted[:,0]=0.
   if policy=='no_lower_update':adjusted[:,4]=0.
   post=net._project_state(prior+adjusted)
   before_cap=float(post[0,4]);cap=float(y[0,0])/K2
   if policy in ('baseflow_cap','both'):post[:,4]=torch.minimum(post[:,4],torch.full_like(post[:,4],cap))
   # Same recurrent gain calculation and previous-state caches; replace only current posterior.
   net.m1x_posterior=post;net.last_correction=post-prior
   assert bool(torch.isfinite(post).all()) and bool((post>=0).all())
   posts.append(arr(post)[0]);priors.append(arr(prior)[0]);requested.append(arr(correction)[0]);applied.append(arr(post-prior)[0]);native_posts.append(arr(native)[0]);gains.append(arr(net.KGain).reshape(-1));innovations.append(innovation)
   active.append([snow_gate and float(correction[0,0])>0 and policy in ('snow_gate','both'),policy in ('baseflow_cap','both') and before_cap>cap]);steps+=1
  post=np.stack(posts);prior=np.stack(priors);issue=np.arange(2557,3285);pred=forecast(post[:728],issue);target=obs[issue[:,None]+np.arange(1,4)]
  data=dict(state_indices=np.arange(2557,3288),issue_indices=issue,prediction=pred,target=target,posterior=post,prior=prior,requested_correction=np.stack(requested),realized_correction=np.stack(applied),native_posterior=np.stack(native_posts),gain=np.stack(gains),innovation=np.array(innovations),policy_active=np.array(active,dtype=np.int8),initial_state=arr(initial).reshape(-1),**{'initial_cache__'+k:v for k,v in start_snapshot.items()})
  if policy=='base':
   ref=load_old({'cold':'anchor_cold','warm':'init_only_lower','main':'anchor_main'}[family]);checks={k:float(np.max(np.abs(data[k]-ref[k]))) for k in ['posterior','prior','prediction','requested_correction','innovation']};passed=max(checks.values())<=1e-12
   gate=dict(label=label,passed=passed,checks=checks);gates.append(gate);put('gate_'+label+'.json',gate)
   if not passed:raise RuntimeError('same-platform anchor differs; stop before interventions')
  traces[label]=data;artifact=npz('trace__'+label+'.npz',data);trace_manifest.append(artifact)
  row=dict(**spec,windows=windows(pred,target,issue),active_counts=np.sum(active,axis=0).tolist(),initial_state=arr(initial).reshape(-1).tolist(),mean_realized_snow_lower=(post-prior)[:,[0,4]].mean(axis=0).tolist(),artifact=artifact)
  rows[label]=row;emit('trajectory_complete',label=label,steps=steps,common_mse=row['windows']['common363']['overall']['knet']['mse'])
 # Two-component state exchanges at every issue, no assimilation; same valid meteorology.
 cold=traces['cold_base'];warm=traces['warm_base'];hybrids={};hybrid_arrays={}
 for bits in ('00','10','01','11'):
  states=warm['posterior'][:728].copy()
  if bits[0]=='1':states[:,0]=cold['posterior'][:728,0]
  if bits[1]=='1':states[:,4]=cold['posterior'][:728,4]
  pred=forecast(states,issue);hybrids[bits]=windows(pred,target,issue);hybrid_arrays['prediction_'+bits]=pred
 assert np.max(np.abs(hybrid_arrays['prediction_00']-warm['prediction']))<=1e-12
 npz('state_exchange_predictions.npz',dict(issue_indices=issue,target=target,**hybrid_arrays))
 # Exact conservative future runoff floor from the current lower store only; known routing carry is omitted.
 floor_coeff=np.array([sum(weights[j]*K2*(1-K2)**(h-j-1) for j in range(min(h,len(weights)))) for h in (1,2,3)])
 ancillary=dict(dates=dates[2557:3288],observations=obs[2557:3288],forcing=forcing[2557:3288],thresholds=thresholds,scales=scales,routing_weights=weights,lower_floor_coefficients=floor_coeff)
 npz('ancillary.npz',ancillary)
 assert steps==plan['new_neural_assimilation_steps'] and C.helpers.digest_tree(net.state_dict())==network_hash
 put('trace_manifest.json',dict(files=trace_manifest));put('result.json',dict(status='DIAGNOSTIC_COMPLETE',experiment_id=plan['experiment_id'],contract_sha256=hashlib.sha256(planraw).hexdigest(),job_id=os.environ['SLURM_JOB_ID'],checkpoint_sha256=plan['checkpoint_sha256'],network_sha256=network_hash,runtime_versions=dict(torch=torch.__version__,numpy=np.__version__,python=sys.version),K2=K2,TT=TT,routing_weights=weights.tolist(),thresholds=thresholds.tolist(),cases=rows,gates=gates,state_exchange=hybrids,new_training_updates=0,new_neural_assimilation_steps=steps,trajectories=len(rows),forecast_state_exchange_count=4*728*3,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
 emit('diagnostic_complete',trajectories=len(rows),steps=steps,new_training_updates=0)

if __name__=='__main__':main()
