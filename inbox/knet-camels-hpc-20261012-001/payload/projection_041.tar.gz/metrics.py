"""Paired archived-forecast summaries; no model or file operations."""
import math
import itertools
import numpy as np


def score(prediction, target):
    p = np.asarray(prediction, dtype=np.float64).reshape(-1)
    t = np.asarray(target, dtype=np.float64).reshape(-1)
    assert p.shape == t.shape and np.isfinite(p).all() and np.isfinite(t).all()
    if not len(p):
        return dict(count=0, sse=0., mse=None, mae=None, bias=None, nse=None)
    error = p - t
    sse = math.fsum(float(x) ** 2 for x in error)
    mean = math.fsum(map(float, t)) / len(t)
    sst = math.fsum((float(x) - mean) ** 2 for x in t)
    return dict(count=len(p), sse=sse, mse=sse / len(p),
                mae=math.fsum(abs(float(x)) for x in error) / len(p),
                bias=math.fsum(map(float, error)) / len(p),
                nse=None if sst == 0 else 1 - sse / sst)


def paired(knet, ukf, target):
    k, u = score(knet, target), score(ukf, target)
    delta_sse = k['sse'] - u['sse']
    if not k['count']:
        return dict(knet=k, ukf=u, delta_sse=0., delta_mse=None,
                    improved=0, worsened=0, tied=0)
    delta = (np.asarray(knet) - target) ** 2 - (np.asarray(ukf) - target) ** 2
    if delta.ndim == 2:
        delta = delta.mean(axis=1)
    return dict(knet=k, ukf=u, delta_sse=delta_sse,
                delta_mse=delta_sse / k['count'],
                improved=int(np.sum(delta < -1e-12)),
                worsened=int(np.sum(delta > 1e-12)),
                tied=int(np.sum(np.abs(delta) <= 1e-12)))


def decompose(knet, ukf, target, target_dates, thresholds, seasons):
    total = paired(knet, ukf, target)
    by_lead = [dict(lead=i + 1, **paired(knet[:, i], ukf[:, i], target[:, i]))
               for i in range(3)]
    month = np.asarray(target_dates).astype('datetime64[ns]').astype('datetime64[M]').astype(int) % 12 + 1
    masks = {name: np.isin(month, months) for name, months in seasons.items()}
    q50, q90, q99 = thresholds
    flow = {'low_le_q50': target <= q50,
            'middle_q50_q90': (target > q50) & (target <= q90),
            'high_q90_q99': (target > q90) & (target <= q99),
            'extreme_gt_q99': target > q99}
    output = dict(overall=total, by_lead=by_lead)
    for label, groups in [('season', masks), ('flow', flow)]:
        rows = []
        for name, mask in groups.items():
            row = dict(group=name, **paired(knet[mask], ukf[mask], target[mask]))
            row['fraction_of_total_delta_sse'] = (None if abs(total['delta_sse']) <= 1e-12
                                                else row['delta_sse'] / total['delta_sse'])
            rows.append(row)
        assert sum(row['knet']['count'] for row in rows) == target.size
        assert math.isclose(math.fsum(row['delta_sse'] for row in rows), total['delta_sse'], rel_tol=1e-12, abs_tol=1e-10)
        output['by_' + label] = rows
    return output


def history_spread(predictions, states, scales, labels):
    predictions, states = np.stack(predictions), np.stack(states)
    pairs = []
    for i, j in itertools.combinations(range(len(labels)), 2):
        dp = predictions[i] - predictions[j]
        ds = (states[i] - states[j]) / scales
        pairs.append(dict(first=labels[i], second=labels[j],
                          forecast_rms=float(np.sqrt(np.mean(dp ** 2))),
                          forecast_rms_by_lead=np.sqrt(np.mean(dp ** 2, axis=0)).tolist(),
                          normalized_state_rms_by_coordinate=np.sqrt(np.mean(ds ** 2, axis=0)).tolist()))
    return dict(cases=len(labels), origins_per_case=predictions.shape[1], pairs=pairs,
                median_pairwise_forecast_rms=float(np.median([x['forecast_rms'] for x in pairs])),
                maximum_pairwise_forecast_rms=max(x['forecast_rms'] for x in pairs),
                maximum_prediction_range=float(np.max(np.ptp(predictions, axis=0))),
                maximum_normalized_state_range_by_coordinate=np.max(np.ptp(states, axis=0) / scales, axis=0).tolist())
