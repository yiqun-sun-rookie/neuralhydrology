"""Verbatim executed rule block; policy frozen to snow plus upper-store redistribution."""
import torch

def apply_rule(net,y,u,prior,correction,innovation,TT,K2):
 policy="reallocate_snow_upper"
 adjusted=correction.clone()
 snow_gate=bool(float(u[0,1])>=TT and float(prior[0,0])<=0.)
 if policy in ('snow_gate','both','reallocate_snow','reallocate_snow_upper') and snow_gate:adjusted[:,0]=torch.minimum(adjusted[:,0],torch.zeros_like(adjusted[:,0]))
 if policy=='no_snow_update':adjusted[:,0]=0.
 if policy=='no_lower_update':adjusted[:,4]=0.
 post=net._project_state(prior+adjusted)
 before_cap=float(post[0,4]);cap=float(y[0,0])/K2
 if policy in ('baseflow_cap','both'):post[:,4]=torch.minimum(post[:,4],torch.full_like(post[:,4],cap))
 transferred=0.
 if policy in ('reallocate_snow','reallocate_snow_upper') and innovation<0:
  indices=[0] if policy=='reallocate_snow' else [0,3]
  realized=post-prior
  blocked=sum(float(torch.clamp(realized[0,j]-adjusted[0,j],min=0.)) for j in indices if float(adjusted[0,j])<0.)
  before=float(post[0,4]);post[:,4]=torch.clamp(post[:,4]-blocked,min=0.);transferred=before-float(post[0,4])
 return post,adjusted,float(transferred),bool(snow_gate)
