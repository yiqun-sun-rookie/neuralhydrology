"""Read the one owned job and collect only bounded evidence, never rerun science."""
import sys,json,datetime,subprocess,hashlib,tarfile,io,base64,importlib.util
from pathlib import Path
base=Path(sys.argv[1]);job=sys.argv[2]
assert job.isdigit()
sp=importlib.util.spec_from_file_location('safe_io',base/'safe_io.py');s=importlib.util.module_from_spec(sp);sp.loader.exec_module(s)
accounting=subprocess.run(['sacct','-j',job,'--noheader','--parsable2',
    '--format=JobID,JobName,State,ExitCode,Elapsed,AllocCPUS,Partition,NodeList,Start,End'],
    capture_output=True,text=True,check=True).stdout.splitlines()
files=set();attempts=[];progress=[]
log=base/'logs'/('diagnostic-'+job+'.out');error=base/'logs'/('diagnostic-'+job+'.err')
for path in [log,error]:
    if path.is_file():files.add(path)
if log.is_file():
    # The file grows while running; this read is observational, not frozen evidence.
    text=log.read_text(encoding='utf-8',errors='replace')
    for line in text.splitlines():
        try:row=json.loads(line)
        except ValueError:continue
        if 'event' in row:progress.append(row)
else:text=''
if (base/'runs').is_dir():
    for folder in sorted((base/'runs').iterdir()):
        if not folder.is_dir() or not folder.name.startswith('attempt_'):continue
        receipt=folder/'receipt.json'
        attempts.append(dict(name=folder.name,receipt=json.loads(s.read_checked(receipt)) if receipt.is_file() else None))
        for path in folder.iterdir():
            if path.is_file():files.add(path)
        for arm in ['original','snow_training']:
            d=folder/arm
            if not d.is_dir():continue
            for name in ['history.json','first_gradient_gate.json','first_gradients.pt','failure_checkpoint.pt']:
                if (d/name).is_file():files.add(d/name)
            if (d/'epochs').is_dir():
                files.update(x for x in (d/'epochs').iterdir() if x.is_file() and x.suffix=='.json')
        result=folder/'result.json'
        if result.is_file():
            obj=json.loads(s.read_checked(result))
            for arm in obj['arms'].values():
                for key in ['selected','last']:
                    row=arm.get(key)
                    if row:
                        for field in ['checkpoint','trace']:
                            if field in row:files.add(base/row[field]['path'])
status=dict(job_id=job,queried_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    accounting=accounting,attempts=attempts,progress=progress[-8:],job_log_last_lines=text.splitlines()[-12:])
print('JOB_STATUS_JSON='+json.dumps(status))
terminal=any(line.split('|')[0]==job and line.split('|')[2].split()[0] in
    ['COMPLETED','FAILED','CANCELLED','TIMEOUT','NODE_FAIL','OUT_OF_MEMORY'] for line in accounting)
if terminal:
    stream=io.BytesIO();manifest=[]
    with tarfile.open(fileobj=stream,mode='w:gz') as tar:
        for path in sorted(files):
            raw=s.read_checked(path);name=path.relative_to(base).as_posix()
            item=tarfile.TarInfo(name);item.size=len(raw);item.mode=0o644;item.mtime=0
            tar.addfile(item,io.BytesIO(raw));manifest.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
        raw=(json.dumps(dict(job_id=job,accounting=accounting,files=manifest,captured_utc=status['queried_utc']),indent=2)+'\n').encode()
        item=tarfile.TarInfo('collection_manifest_'+job+'.json');item.size=len(raw);item.mode=0o644;item.mtime=0;tar.addfile(item,io.BytesIO(raw))
    payload=stream.getvalue()
    print('ARTIFACT_ARCHIVE_METADATA='+json.dumps(dict(job_id=job,files=len(files)+1,bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest())))
    print('ARTIFACT_ARCHIVE_BASE64='+base64.b64encode(payload).decode())
