"""One paired, fixed-update training contrast on the existing development data."""
import os, sys, io, json, hashlib, time, datetime, importlib.util, traceback
from pathlib import Path


def main():
    base = Path(__file__).resolve().parent
    template = base.parents[1] / 'template'
    spec = importlib.util.spec_from_file_location('safe_io', base/'safe_io.py')
    s = importlib.util.module_from_spec(spec); sys.modules['safe_io'] = s; spec.loader.exec_module(s)
    assert os.environ.get('SLURM_JOB_ID', '').isdigit()
    assert json.loads(sys.stdin.readline())['resources_configured']
    plan_raw = s.read_checked(base/'plan_contract.json'); plan = json.loads(plan_raw)
    auth = json.loads(s.read_checked(base/'execution_authorization.json'))
    assert auth['status'] == 'AUTHORIZED' and plan['updates_per_arm'] == 121
    for row in auth['files']: s.read_checked(base/row['path'], row['sha256'])
    manifest = json.loads(s.read_checked(template/'bundle_manifest.json', auth['template_manifest_sha256']))
    for row in manifest['files']: s.read_checked(template/row['path'], row['sha256'])
    import numpy as np
    import torch
    import random
    from snow_constraint import constrain_snow
    torch.set_num_threads(1); torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    random.seed(plan['seed']); np.random.seed(plan['seed']); torch.manual_seed(plan['seed'])
    os.chdir(template); sys.path.insert(0, str(template/'recipe')); os.environ['KNET_BASIN'] = '04105700'
    import common as C
    for name in ['execution_sources.json', 'evaluation_sources.json']:
        entries = json.loads(s.read_checked(template/'recipe'/name))['files']
        C.DIGESTS.update({str(Path(e['path']).resolve()).lower(): e['sha256'] for e in entries})
    helpers = C.checked_source('paired_original_helpers', template/'recipe/original_training_helpers.py')
    from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
    from global_hydrology.experiments import daily_camels_ukf_knet_parity_runner as parity
    from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
    from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import AccessLedger, CAUSAL_SHARED_SPINUP_MODE
    from contextlib import contextmanager
    out = 'runs/' + sys.argv[1]; began = time.monotonic()
    def arr(x): return x.detach().cpu().numpy().copy()
    def put(name, value): return s.create(out+'/'+name, value)
    def save_np(name, value):
        stream = io.BytesIO(); np.savez_compressed(stream, **value); return put(name, stream.getvalue())
    def save_pt(name, value):
        stream = io.BytesIO(); torch.save(value, stream); return put(name, stream.getvalue())
    def load_np(name):
        with np.load(io.BytesIO(s.read_checked(base/'inputs'/name)), allow_pickle=False) as z:
            return {k:z[k].copy() for k in z.files}
    def emit(event, **kw):
        print(json.dumps(dict(event=event,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            elapsed_seconds=time.monotonic()-began, **kw),allow_nan=False),flush=True)
    def digest(x): return C.helpers.digest_tree(x)
    reference = load_np('reference.npz')
    cp = torch.load(io.BytesIO(s.read_checked(base/'inputs/initial.pt')),weights_only=True,map_location='cpu')
    assert cp['epoch'] == cp['optimizer_steps'] == 0 and not cp['optimizer']['state']
    runtime = per.load_per_basin_development_runtime(get_development_basin_specification('02092500'),
        ledger=AccessLedger(), initialization_mode=CAUSAL_SHARED_SPINUP_MODE, device='cpu')
    assert runtime.training_days == 2557 and runtime.context.dimension == 11
    states = parity.training_open_loop_states(runtime)
    scales = parity.fit_training_feature_scales(runtime, floor=.1)
    per.fit_training_feature_scales = lambda r, *, floor=.1: scales
    original_advance = parity._advance_open_loop
    parity._advance_open_loop = lambda context,forcing,*,end_exclusive: states[-1].clone() if context is runtime.context and end_exclusive == 2557 else original_advance(context,forcing,end_exclusive=end_exclusive)
    window = parity.select_window(runtime,'recovery')
    model = runtime.context.plain_model; TT = float(model.params['parTT'])
    issue = np.arange(2557,3285); dates = runtime.dates.astype('datetime64[ns]').astype('int64')
    observations = arr(runtime.observations).reshape(-1)
    targets = observations[issue[:,None]+np.arange(1,4)]
    thresholds = np.quantile(observations[:2557],[.5,.9,.99],method='linear')
    checks = dict(target=np.array_equal(targets,reference['target']),
        forcing=np.array_equal(arr(runtime.forcing)[2557:3288,0,:],reference['forcing']),
        observations=np.array_equal(observations[2557:3288],reference['observations']),
        initial_state=np.array_equal(arr(window.initial_state).reshape(-1),reference['initial_state']),
        thresholds=np.array_equal(thresholds,reference['thresholds']), TT=TT==float(reference['TT']))
    assert all(checks.values())
    save_np('input_snapshot.npz',dict(forcing=arr(runtime.forcing),observations=observations,dates_ns=dates,
        training_open_loop=arr(states),thresholds=thresholds,issue_indices=issue,target=targets))
    put('input_gate.json',dict(checks=checks,archive_sha256=runtime.archive_sha256,
        training_days=2557,validation_days=731,thresholds=thresholds.tolist(),TT=TT))

    # One small compute-node check of the new operator and its actual derivatives.
    fake = type('Bounds',(),{})()
    fake.state_lower_bound = torch.zeros((1,2),dtype=torch.float64)
    fake.state_upper_bound = torch.full((1,2),torch.inf,dtype=torch.float64)
    prior = torch.tensor([[0.,2.],[0.,2.],[1.,2.],[0.,2.]],dtype=torch.float64)
    raw = torch.tensor([[2.,.5],[2.,.5],[2.,.5],[-2.,.5]],dtype=torch.float64,requires_grad=True)
    controls = torch.tensor([[0.,TT+1,0.],[0.,TT-1,0.],[0.,TT+1,0.],[0.,TT+1,0.]],dtype=torch.float64)
    native = torch.maximum(prior+raw,torch.zeros_like(prior))
    post,adjusted,gate = constrain_snow(fake,controls,native,prior,raw,TT)
    post.sum().backward()
    assert torch.equal(post[:,0],torch.tensor([0.,2.,3.,0.],dtype=torch.float64))
    assert torch.equal(raw.grad[:,0],torch.tensor([0.,1.,1.,0.],dtype=torch.float64))
    assert torch.equal(post[:,1],native[:,1]) and torch.equal(raw.grad[:,1],torch.ones(4,dtype=torch.float64))
    put('operator_check.json',dict(status='PASS',snow_values=arr(post[:,0]).tolist(),
        snow_gradients=arr(raw.grad[:,0]).tolist(),other_coordinate_unchanged=True,
        blocked_positive_snow_gradient_zero=True,synthetic_cases=4))

    snapshots = list(C.probe.RECURRENCE_FIELDS)
    initial_snapshots = {}; arms = {}; initial_hashes = {}
    for arm in plan['arms']:
        net = per.build_exact_dimension_kalman_net(runtime,zero_gain=False,seed=plan['seed'],
            gain_initialization='near_zero_fc2_head',hidden=24,input_multiplier=10,output_multiplier=10,
            feature_scale_floor=.1,normalized_feature_guard=10.,correction_cap_in_state_scale_units=3.)
        net.load_state_dict(cp['network'],strict=True)
        for parameter in net.parameters(): parameter.requires_grad_(True)
        optimizer = torch.optim.Adam(net.parameters(),lr=plan['learning_rate'],weight_decay=0)
        optimizer.load_state_dict(cp['optimizer'])
        assert optimizer.param_groups[0]['lr'] == plan['learning_rate'] and not optimizer.state
        torch.set_rng_state(cp['torch_rng_state'].clone())
        identities = dict(network=digest(net.state_dict()),parameter=parity.parameter_sha256(net),
            optimizer=digest(optimizer.state_dict()),rng=digest(torch.get_rng_state()))
        assert identities['parameter'] == plan['initial_parameters_sha256']
        assert identities['network'] == digest(cp['network'])
        assert identities['optimizer'] == digest(cp['optimizer'])
        initial_hashes[arm] = identities
        init_rows = []
        for start in [*plan['base_starts'],2557]:
            initial = runtime.context.initial_state.clone() if start == 0 else states[start-1].clone()
            previous = None if start == 0 else runtime.observations[start-1:start].clone()
            net.initialize_filter(initial,731 if start==2557 else 800,previous_observation=previous)
            row = {key:arr(getattr(net,key)) for key in snapshots}
            init_rows.append({key:hashlib.sha256(value.tobytes()).hexdigest() for key,value in row.items()})
        initial_snapshots[arm] = init_rows
        arms[arm] = dict(net=net,optimizer=optimizer,rng=cp['torch_rng_state'].clone(),
            history=[],best=None,updates=0,steps=0,phase='initialization',stats={},trace=None)
        native_analysis = net.analysis_step
        def wrap(native_analysis,net,state,enabled):
            def update(y,u):
                native = native_analysis(y,u); prior = net.m1x_prior; requested = net.last_correction
                posterior,adjusted,gate = constrain_snow(net,u,native,prior,requested,TT) if enabled else (native,requested,torch.zeros(len(u),dtype=torch.bool))
                if enabled:
                    net.m1x_posterior = posterior
                    net.last_correction = adjusted
                state['steps'] += 1
                stat = state['stats']; stat['steps'] = stat.get('steps',0)+1
                blocked = native[:,0]-posterior[:,0]
                stat['blocked_days'] = stat.get('blocked_days',0)+int((blocked.detach()>0).sum())
                stat['blocked_mm'] = stat.get('blocked_mm',0.)+float(blocked.detach().sum())
                if state['trace'] is not None:
                    state['trace'].append(dict(prior=arr(prior)[0],posterior=arr(posterior)[0],
                        native=arr(native)[0],requested=arr(requested)[0],adjusted=arr(adjusted)[0],
                        gain=arr(net.KGain).reshape(-1)))
                return posterior
            return update
        net.analysis_step = wrap(native_analysis,net,arms[arm],arm=='snow_training')
    assert initial_hashes['original'] == initial_hashes['snow_training']
    assert initial_snapshots['original'] == initial_snapshots['snow_training']
    put('initialization_gate.json',dict(status='PASS',hashes=initial_hashes,
        initialization_snapshots=initial_snapshots,initialization_count_per_arm=26,
        recurrent_fields=snapshots,all_paired_initial_values_exact=True))

    @contextmanager
    def cut_at_650(net,start):
        active = {}; count={'cut':0}
        def detach(network): C.probe.detach_recurrence(network); count['cut'] += 1
        with C.diag.analysis_observer(net,650,detach,active,start,runtime.dates[start:start+800]):
            yield
        assert count['cut']==1

    def scores(prediction):
        error=prediction-targets
        masks=dict(overall=np.ones(targets.shape,dtype=bool),low=targets<=thresholds[0],
            middle=(targets>thresholds[0])&(targets<=thresholds[1]),high=targets>thresholds[1])
        result={}
        for group,mask in masks.items():
            e=error[mask]; t=targets[mask]; den=float(np.sum((t-t.mean())**2))
            result[group]=dict(count=int(e.size),mse=float(np.mean(e**2)),mae=float(np.mean(np.abs(e))),
                bias=float(np.mean(e)),nse=None if den==0 else 1-float(np.sum(e**2))/den)
        result['by_lead']={str(k+1):dict(mse=float(np.mean(error[:,k]**2)),mae=float(np.mean(np.abs(error[:,k])))) for k in range(3)}
        return result

    def validate(state):
        net=state['net'];net.eval();state['phase']='validation';state['stats']={};state['trace']=[]
        with torch.no_grad():
            trace=parity.run_knet_filter(net,window,previous_observation=parity.previous_observation_before_window(runtime,window))
            forecasts=parity.aligned_forecasts_from_posterior(runtime,window,trace.posterior_states)
            pairs=parity.forecast_pairs(window.observations,forecasts,issue_start=0,issue_end=728,leads=(1,2,3))
        prediction=np.stack([pairs.predictions[k] for k in (1,2,3)],axis=1)
        assert np.array_equal(np.stack([pairs.targets[k] for k in (1,2,3)],axis=1),targets)
        arrays={key:np.stack([row[key] for row in state['trace']]) for key in state['trace'][0]}
        state['trace']=None
        arrays.update(prediction=prediction,target=targets,issue_indices=issue,
            target_dates_ns=dates[issue[:,None]+np.arange(1,4)])
        return scores(prediction),arrays,dict(state['stats'])

    def checkpoint(arm,epoch):
        state=arms[arm];net=state['net'];opt=state['optimizer']
        return dict(arm=arm,epoch=epoch,optimizer_steps=state['updates'],seed=plan['seed'],
            network={k:v.detach().cpu().clone() for k,v in net.state_dict().items()},
            optimizer=opt.state_dict(),torch_rng_state=state['rng'].clone(),
            parameter_sha256=parity.parameter_sha256(net),network_sha256=digest(net.state_dict()),
            initial_parameters_sha256=plan['initial_parameters_sha256'],
            contract_sha256=hashlib.sha256(plan_raw).hexdigest())

    def record(arm,epoch,training=None,post_training=None,norm=None,train_stats=None):
        state=arms[arm];metrics,arrays,stats=validate(state)
        assert np.isfinite(arrays['prediction']).all()
        if metrics['overall']['mse'] > plan['validation_divergence_ratio_vs_physics'] * plan['physical_validation_mse']:
            raise FloatingPointError('validation divergence versus frozen physical baseline')
        state['rng']=torch.get_rng_state().clone()
        cp_id=save_pt(f'{arm}/checkpoints/epoch_{epoch:03d}.pt',checkpoint(arm,epoch))
        improved=state['best'] is None or metrics['overall']['mse']<state['best']['metrics']['overall']['mse']
        row=dict(arm=arm,epoch=epoch,optimizer_updates=state['updates'],training=training,
            post_update_training=post_training,gradient_norm_before_clip=norm,
            training_snow_statistics=train_stats,validation_snow_statistics=stats,
            metrics=metrics,checkpoint=cp_id,selected_so_far=improved,
            elapsed_seconds=time.monotonic()-began)
        if improved or epoch==plan['updates_per_arm']:
            row['trace']=save_np(f'{arm}/traces/epoch_{epoch:03d}.npz',arrays)
        if improved:state['best']=row
        put(f'{arm}/epochs/epoch_{epoch:03d}.json',row);state['history'].append(row)
        emit('epoch_complete',arm=arm,epoch=epoch,optimizer_updates=state['updates'],
            training_mse=None if training is None else training['training_objective'],
            validation_mse=metrics['overall']['mse'],best_epoch=state['best']['epoch'],
            validation_snow_blocked_days=stats['blocked_days'])

    failure=None;current_arm=None;current_epoch=0
    try:
        for current_arm,state in arms.items():
            torch.set_rng_state(state['rng']);record(current_arm,0)
        for current_epoch in range(1,plan['updates_per_arm']+1):
            for current_arm,state in arms.items():
                torch.set_rng_state(state['rng']);net=state['net'];optimizer=state['optimizer']
                net.train();optimizer.zero_grad(set_to_none=True)
                state['phase']='training';state['stats']={};segment_count=0
                def segment(start):
                    nonlocal segment_count
                    with cut_at_650(net,start):
                        result=parity.segment_multilead_mse(net,runtime,start=start,segment_days=800,
                            filter_warmup_days=695,open_loop_states=states)
                    assert all(result.target_count_by_lead[k]==102 for k in (1,2,3))
                    segment_count+=1
                    if current_epoch==1 and segment_count%5==0:
                        emit('first_epoch_segment',arm=current_arm,completed=segment_count,total=25)
                    return result
                training=helpers.backward_equal_segment_objective(starts=plan['base_starts'],
                    segment_builder=segment,leads=(1,2,3),torch_module=torch)
                assert training['training_forecast_error_events']==7650
                train_stats=dict(state['stats'])
                gradients={name:None if p.grad is None else p.grad.detach().cpu().clone() for name,p in net.named_parameters()}
                if any(g is not None and not bool(torch.isfinite(g).all()) for g in gradients.values()):
                    raise FloatingPointError('nonfinite gradient')
                if not any(g is not None and bool(torch.count_nonzero(g)) for g in gradients.values()):
                    raise FloatingPointError('all parameter gradients zero or absent')
                norm=float(torch.nn.utils.clip_grad_norm_(net.parameters(),plan['gradient_norm_cap'],error_if_nonfinite=True))
                if current_epoch==1:
                    save_pt(f'{current_arm}/first_gradients.pt',gradients)
                    put(f'{current_arm}/first_gradient_gate.json',dict(status='PASS',gradient_sha256=digest(gradients),
                        finite=True,nonzero=True,stats=train_stats,cut_before_local_day=650,backward_days=150))
                state['phase']='optimizer';optimizer.step();state['updates']+=1
                if not all(bool(torch.isfinite(p).all()) for p in net.parameters()):
                    raise FloatingPointError('nonfinite updated parameters')
                state['phase']='post_update_replay';state['stats']={}
                with torch.no_grad():
                    post_training=helpers._evaluate_equal_segment_objective(starts=plan['base_starts'],
                        segment_builder=lambda start:parity.segment_multilead_mse(net,runtime,start=start,
                            segment_days=800,filter_warmup_days=695,open_loop_states=states))
                if not np.isfinite(post_training) or post_training > plan['update_loss_post_pre_divergence_ratio']*training['training_objective']:
                    raise FloatingPointError('post-update training divergence')
                record(current_arm,current_epoch,training,post_training,norm,train_stats)
    except BaseException as error:
        failure=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc(),
            arm=current_arm,epoch=current_epoch,phase=None if current_arm is None else arms[current_arm]['phase'])
        put('failure.json',failure)
        for arm,state in arms.items():
            state['rng']=torch.get_rng_state().clone() if arm==current_arm else state['rng']
            save_pt(f'{arm}/failure_checkpoint.pt',checkpoint(arm,current_epoch))
        emit('training_failure',**{k:failure[k] for k in ['type','message','arm','epoch','phase']})

    result_arms={}
    for arm,state in arms.items():
        put(f'{arm}/history.json',state['history'])
        result_arms[arm]=dict(optimizer_updates=state['updates'],neural_steps=state['steps'],
            selected=state['best'],last=state['history'][-1] if state['history'] else None)
    complete=failure is None and all(state['updates']==121 for state in arms.values())
    result=dict(status='COMPLETE' if complete else 'FAILED',experiment_id=plan['experiment_id'],
        job_id=os.environ['SLURM_JOB_ID'],arms=result_arms,initialization_exact=True,
        contract_sha256=hashlib.sha256(plan_raw).hexdigest(),failure=failure,
        total_optimizer_updates=sum(state['updates'] for state in arms.values()),
        elapsed_seconds=time.monotonic()-began,
        versions=dict(torch=torch.__version__,numpy=np.__version__,python=sys.version))
    if complete:
        result['selected_mse_change_percent']={group:100*(result_arms['snow_training']['selected']['metrics'][group]['mse']/result_arms['original']['selected']['metrics'][group]['mse']-1) for group in ['overall','low','middle','high']}
    put('result.json',result);emit('paired_training_terminal',status=result['status'],total_optimizer_updates=result['total_optimizer_updates'])
    if failure:raise RuntimeError('paired training failed; original failure preserved')


if __name__=='__main__':main()
