"""The previously frozen snow gate, applied inside the training graph."""
import torch


def constrain_snow(net, controls, native, prior, requested, threshold):
    gate = (controls[:, 1] >= threshold) & (prior[:, 0] <= 0.)
    adjusted_snow = torch.where(
        gate, torch.minimum(requested[:, 0], torch.zeros_like(requested[:, 0])),
        requested[:, 0])
    snow = torch.maximum(torch.minimum(prior[:, 0] + adjusted_snow,
        net.state_upper_bound[:, 0]), net.state_lower_bound[:, 0])
    # Construct a new tensor: do not edit autograd inputs in place or detach them.
    posterior = torch.cat((snow[:, None], native[:, 1:]), dim=1)
    adjusted = torch.cat((adjusted_snow[:, None], requested[:, 1:]), dim=1)
    return posterior, adjusted, gate
