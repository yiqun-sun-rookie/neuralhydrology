"""Fixed 04105700 archived-history and posterior-component diagnostic."""
import os
import sys
import json
import io
import hashlib
import datetime
import importlib.util
from pathlib import Path


def main():
    base = Path(__file__).resolve().parent
    template = base.parents[1] / 'template'
    spec = importlib.util.spec_from_file_location('safe_io', base / 'safe_io.py')
    safety = importlib.util.module_from_spec(spec)
    sys.modules['safe_io'] = safety
    spec.loader.exec_module(safety)
    handshake = json.loads(sys.stdin.readline())
    assert handshake.get('resources_configured') and os.environ.get('SLURM_JOB_ID', '').isdigit()
    attempt = sys.argv[1]
    out = 'runs/' + attempt
    authorization = json.loads(safety.read_checked(base / 'execution_authorization.json'))
    assert authorization['status'] == 'AUTHORIZED' and authorization['new_training_updates'] == 0
    for entry in authorization['files']:
        safety.read_checked(base / entry['path'], entry['sha256'])
    contract_raw = safety.read_checked(base / 'plan_contract.json')
    contract = json.loads(contract_raw)
    contract_hash = hashlib.sha256(contract_raw).hexdigest()
    bundle = json.loads(safety.read_checked(template / 'bundle_manifest.json', authorization['template_manifest_sha256']))
    for entry in bundle['files']:
        safety.read_checked(template / entry['path'], entry['sha256'])
    import numpy as np
    import torch
    import psutil
    import metrics as M
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    os.chdir(template)
    os.environ['KNET_BASIN'] = '04105700'
    recipe = template / 'recipe'
    sys.path.insert(0, str(recipe))
    import common as C
    for name in ['execution_sources.json', 'evaluation_sources.json']:
        manifest = json.loads(safety.read_checked(recipe / name))
        C.DIGESTS.update({str(Path(x['path']).resolve()).lower(): x['sha256'] for x in manifest['files']})
    from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
    from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
    from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import AccessLedger, CAUSAL_SHARED_SPINUP_MODE

    def emit(event, **values):
        print(json.dumps(dict(event=event, utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), **values), allow_nan=False), flush=True)

    def load(identity):
        with np.load(io.BytesIO(safety.read_checked(base / identity['path'], identity['sha256'])), allow_pickle=False) as z:
            return {key: z[key].copy() for key in z.files}

    def put(name, value):
        return safety.create(out + '/' + name, value)

    def put_arrays(name, values):
        stream = io.BytesIO()
        np.savez_compressed(stream, **values)
        return put(name, stream.getvalue())

    registry = json.loads(safety.read_checked(base / 'inputs/registry.json'))
    cp_entry = registry['checkpoint']
    cp = torch.load(io.BytesIO(safety.read_checked(base / cp_entry['path'], cp_entry['sha256'])), weights_only=True, map_location='cpu')
    assert cp['epoch'] == 26 and C.helpers.digest_tree(cp['network']) == cp['network_sha256']
    scales = cp['network']['state_feature_scale'].numpy().reshape(-1)
    runtime = per.load_per_basin_development_runtime(get_development_basin_specification('04105700'), ledger=AccessLedger(), initialization_mode=CAUSAL_SHARED_SPINUP_MODE, device='cpu')
    assert runtime.training_days == 2557 and runtime.context.dimension == 7
    dates = runtime.dates.astype('datetime64[ns]').astype('int64')
    observations = runtime.observations.numpy().reshape(-1)
    thresholds = np.quantile(observations[:2557], [.5, .9, .99], method='linear')
    groups = contract['state_groups']
    assert sorted(i for group in groups for i in group['indices']) == list(range(7))
    process = psutil.Process()
    emit('runtime_ready', job_id=os.environ['SLURM_JOB_ID'], node=os.uname().nodename,
         pid=process.pid, affinity=process.cpu_affinity(), nice=process.nice(),
         torch_version=torch.__version__, numpy_version=np.__version__,
         threads=torch.get_num_threads(), training_flow_thresholds=thresholds.tolist())
    physics_calls = 0

    def forecast(state, issue):
        nonlocal physics_calls
        state = torch.from_numpy(np.ascontiguousarray(state)).to(dtype=torch.float64)
        values = []
        with torch.no_grad():
            for lead in (1, 2, 3):
                state = runtime.context.plain_model.f(state, runtime.forcing[issue + lead, 0, :])
                values.append(runtime.context.plain_model.h(state)[:, 0])
                physics_calls += 1
        prediction = torch.stack(values, dim=1).numpy()
        assert np.isfinite(prediction).all()
        return prediction

    case_rows, artifacts, hybrids_all = [], [], []
    history = {method: dict(predictions=[], states=[]) for method in ('knet', 'ukf')}
    history_labels = []
    for entry in registry['cases']:
        data = load(entry['artifact'])
        issue = data['issue_indices']
        assert np.array_equal(data['target_indices'], issue[:, None] + np.arange(1, 4))
        assert np.array_equal(data['target_dates_ns'], dates[data['target_indices']])
        assert np.array_equal(data['target'], observations[data['target_indices']])
        warmup = entry['warmup']
        full_mask = np.arange(len(issue)) >= warmup
        descriptions = {}
        for label, mask in [('full_scoring', full_mask), ('common363', (issue >= 2922) & (issue < 3285))]:
            if label == 'common363':
                assert int(mask.sum()) == 363
            else:
                assert int(mask.sum()) == entry['count_per_lead']
            descriptions[label] = M.decompose(data['knet_prediction'][mask], data['ukf_prediction'][mask], data['target'][mask], data['target_dates_ns'][mask], thresholds, contract['groups']['season_by_target_month'])
            descriptions[label]['physical'] = M.score(data['physical_prediction'][mask], data['target'][mask])
        for method in ('knet', 'ukf', 'physical'):
            actual = (descriptions['full_scoring']['overall'][method]['mse'] if method != 'physical'
                      else descriptions['full_scoring']['physical']['mse'])
            assert abs(actual - entry['saved_mean_mse'][method]) <= 1e-12, (entry['label'], method, actual)
        mask = full_mask if entry['role'] == 'main' else (issue >= 2922) & (issue < 3285)
        origins = issue[mask]
        state_rows = np.searchsorted(data['state_indices'], origins)
        assert np.array_equal(data['state_indices'][state_rows], origins)
        kstate = data['knet_posterior'][state_rows]
        ustate = data['ukf_posterior'][state_rows]
        kpred, upred = data['knet_prediction'][mask], data['ukf_prediction'][mask]
        target = data['target'][mask]
        reconstruction = {}
        for name, state, reference in [('knet', kstate, kpred), ('ukf', ustate, upred)]:
            error = float(np.max(np.abs(forecast(state, origins) - reference)))
            assert error <= 1e-12, (entry['label'], name, error)
            reconstruction[name] = error
        if entry['role'] == 'cold':
            history_labels.append(entry['label'])
            for method, prediction, state in [('knet', kpred, kstate), ('ukf', upred, ustate)]:
                history[method]['predictions'].append(prediction)
                history[method]['states'].append(state)
        baseline = M.paired(kpred, upred, target)
        predictions = dict(knet=kpred, ukf=upred, target=target, issue_indices=origins,
                           target_indices=data['target_indices'][mask], target_dates_ns=data['target_dates_ns'][mask])
        rows = []
        for group in groups:
            state = kstate.copy()
            state[:, group['indices']] = ustate[:, group['indices']]
            pred = forecast(state, origins)
            predictions['hybrid_' + group['name']] = pred
            metrics = M.score(pred, target)
            improvement = baseline['knet']['mse'] - metrics['mse']
            gap = baseline['delta_mse']
            row = dict(case=entry['label'], role=entry['role'], state_group=group['name'],
                       origins=len(origins), hybrid=metrics, knet_mse=baseline['knet']['mse'],
                       ukf_mse=baseline['ukf']['mse'], mse_improvement_over_knet=improvement,
                       gap_closure_fraction=None if abs(gap) <= 1e-12 else improvement / gap,
                       mse_by_lead=[M.score(pred[:, i], target[:, i])['mse'] for i in range(3)])
            rows.append(row)
            hybrids_all.append(row)
        realized_k = data['knet_posterior'][state_rows] - data['knet_prior'][state_rows]
        realized_u = data['ukf_posterior'][state_rows] - data['ukf_prior'][state_rows]
        state_comparison = dict(knet_mean=kstate.mean(axis=0).tolist(), ukf_mean=ustate.mean(axis=0).tolist(),
                                mean_knet_minus_ukf=(kstate-ustate).mean(axis=0).tolist(),
                                normalized_difference_rms=np.sqrt(np.mean(((kstate-ustate)/scales)**2, axis=0)).tolist(),
                                knet_mean_realized_correction=realized_k.mean(axis=0).tolist(),
                                ukf_mean_realized_correction=realized_u.mean(axis=0).tolist())
        artifact = put_arrays('predictions_' + entry['label'] + '.npz', predictions)
        artifacts.append(artifact)
        row = dict(case=entry['label'], role=entry['role'], source=entry,
                   decompositions=descriptions, reconstruction=reconstruction,
                   substitution_window='main728' if entry['role']=='main' else 'common363',
                   state_comparison=state_comparison, substitutions=rows, artifact=artifact)
        case_rows.append(row)
        artifacts.append(put('case_' + entry['label'] + '.json', row))
        emit('case_complete', case=entry['label'], full_gap=descriptions['full_scoring']['overall']['delta_mse'],
             common_gap=descriptions['common363']['overall']['delta_mse'], reconstruction=reconstruction,
             closure={x['state_group']: x['gap_closure_fraction'] for x in rows})
    assert len(case_rows) == 8 and len(hybrids_all) == 48 and physics_calls == 192
    spread = {method: M.history_spread(values['predictions'], values['states'], scales, history_labels)
              for method, values in history.items()}
    artifacts.append(put('history_spread.json', spread))
    result = dict(status='DIAGNOSTIC_COMPLETE', experiment_id=contract['experiment_id'],
                  contract_sha256=contract_hash, job_id=os.environ['SLURM_JOB_ID'],
                  basin='04105700', selected_epoch=26, seed=20260922,
                  training_flow_thresholds=thresholds.tolist(), state_scales=scales.tolist(),
                  cases=case_rows, history_spread=spread, substitution_rows=48,
                  physical_batch_calls=physics_calls, new_hybrid_forecast_values=58842,
                  new_neural_assimilation_steps=0, new_training_updates=0,
                  maximum_reconstruction_error=max(max(x['reconstruction'].values()) for x in case_rows),
                  artifacts=artifacts, interpretation_limits=contract['interpretation_limits'],
                  completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    put('result.json', result)
    emit('diagnostic_complete', cases=8, substitutions=48, physics_calls=physics_calls,
         new_training_updates=0, maximum_reconstruction_error=result['maximum_reconstruction_error'])


if __name__ == '__main__':
    main()
