"""One Slurm scientific child, true memory receipt, bounded cumulative attempts."""
import os,sys,json,time,threading,datetime,subprocess,importlib.util,traceback,re
from pathlib import Path
import psutil
BASE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('safe_io',BASE/'safe_io.py');s=importlib.util.module_from_spec(sp);sys.modules['safe_io']=s;sp.loader.exec_module(s)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
if not os.environ.get('SLURM_JOB_ID','').isdigit():raise RuntimeError('Slurm compute job required')
auth=json.loads(s.read_checked(BASE/'execution_authorization_r2.json'));plan=json.loads(s.read_checked(BASE/'plan_contract.json'));limits=plan['resource_limits']
spent=0.
if (BASE/'runs').is_dir():
 for folder in (BASE/'runs').iterdir():
  path=folder/'receipt.json'
  if path.is_file():spent+=json.loads(s.read_checked(path))['wall_seconds']
remaining=limits['cumulative_compute_wall_seconds']-spent
if remaining<=0:raise RuntimeError('cumulative compute budget exhausted')
number=1
while (BASE/'runs'/('attempt_'+str(number).zfill(3))).exists():number+=1
attempt='attempt_'+str(number).zfill(3);out='runs/'+attempt
info=subprocess.run(['scontrol','-d','show','job',os.environ['SLURM_JOB_ID']],capture_output=True,text=True,check=True)
allocated=set()
for field in re.findall(r'CPU_IDs=([0-9,-]+)',info.stdout):
 for item in field.split(','):
  if '-' in item:
   first,last=map(int,item.split('-'));allocated.update(range(first,last+1))
  else:allocated.add(int(item))
proc=psutil.Process();allowed=proc.cpu_affinity();eligible=sorted(allocated.intersection(allowed))
if not eligible:raise RuntimeError('cannot bind a verified allocated CPU')
proc.cpu_affinity([eligible[0]]);proc.nice(10)
s.create(out+'/controller_started.json',{'utc':now(),'pid':proc.pid,'creation_time':proc.create_time(),'job_id':os.environ['SLURM_JOB_ID'],'node':os.uname().nodename,'allowed_affinity':allowed,'slurm_allocated_cpu_ids':sorted(allocated),'bound_affinity':proc.cpu_affinity(),'priority_nice':proc.nice(),'remaining_wall_seconds':remaining,'scontrol_details':info.stdout})
began=time.monotonic();chunks=[];peak=0;free_min=None;cpu_last=0;samples=0;stop=None
child=psutil.Popen([sys.executable,'-u','-B',str(BASE/'worker_r2.py'),attempt],cwd=str(BASE),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
child.cpu_affinity(proc.cpu_affinity());child.nice(10)
s.create(out+'/scientific_started.json',{'utc':now(),'pid':child.pid,'creation_time':child.create_time(),'parent_pid':proc.pid,'job_id':os.environ['SLURM_JOB_ID'],'affinity':child.cpu_affinity(),'priority_nice':child.nice()})
def consume():
 for line in iter(child.stdout.readline,b''):
  chunks.append(line);print(line.decode('utf-8',errors='replace').rstrip(),flush=True)
reader=threading.Thread(target=consume,daemon=True);reader.start();child.stdin.write(b'{"resources_configured":true}\n');child.stdin.flush();child.stdin.close()
while child.poll() is None:
 try:
  rss=sum(x.memory_info().rss for x in [proc,child]+child.children(recursive=True));free=psutil.virtual_memory().available;ct=child.cpu_times();cpu_last=ct.user+ct.system
  peak=max(peak,rss);free_min=free if free_min is None else min(free_min,free);samples+=1
  if rss>limits['combined_rss_limit_bytes']:stop='COMBINED_RSS_LIMIT'
  elif free<limits['minimum_free_bytes']:stop='SYSTEM_FREE_LIMIT'
  elif time.monotonic()-began>remaining:stop='CUMULATIVE_WALL_LIMIT'
  if stop:child.terminate();break
 except psutil.NoSuchProcess:pass
 time.sleep(.25)
child.wait();reader.join();log=s.create(out+'/stdout.log',b''.join(chunks));wall=time.monotonic()-began
result_path=BASE/out/'result.json';result_present=result_path.is_file()
receipt={'status':'COMPLETED' if child.returncode==0 and stop is None and result_present else 'TECHNICAL_FAILURE','job_id':os.environ['SLURM_JOB_ID'],'node':os.uname().nodename,'attempt':attempt,'exit_code':child.returncode,'resource_stop':stop,'wall_seconds':wall,'prior_attempt_wall_seconds':spent,'cumulative_wall_seconds':spent+wall,'combined_python_rss_peak_bytes':peak,'system_free_min_bytes':free_min,'child_cpu_seconds_last_observation':cpu_last,'resource_samples':samples,'scientific_affinity':proc.cpu_affinity(),'priority_nice':proc.nice(),'mathematical_threads':1,'gpu_requested':0,'new_training_updates':0,'log':log,'result_present':result_present,'ended_utc':now()}
s.create(out+'/receipt.json',receipt);print(json.dumps(receipt),flush=True)
raise SystemExit(0 if receipt['status']=='COMPLETED' else 1)
