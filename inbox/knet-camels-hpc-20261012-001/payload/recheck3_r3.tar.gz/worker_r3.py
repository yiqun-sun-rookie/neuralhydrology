"""Frozen selected-checkpoint recheck of one rule on three existing development basins."""
import sys,os,json,io,hashlib,datetime,importlib.util
from pathlib import Path

def main():
 base=Path(__file__).resolve().parent;template=base.parents[1]/'template'
 sp=importlib.util.spec_from_file_location('safe_io',base/'safe_io.py');s=importlib.util.module_from_spec(sp);sys.modules['safe_io']=s;sp.loader.exec_module(s)
 assert os.environ.get('SLURM_JOB_ID','').isdigit() and json.loads(sys.stdin.readline())['resources_configured']
 out='runs/'+sys.argv[1];planraw=s.read_checked(base/'plan_contract_r3.json');plan=json.loads(planraw);auth=json.loads(s.read_checked(base/'execution_authorization_r3.json'))
 assert auth['status']=='AUTHORIZED' and auth['new_training_updates']==0
 for e in auth['files']:s.read_checked(base/e['path'],e['sha256'])
 bundle=json.loads(s.read_checked(template/'bundle_manifest.json',auth['template_manifest_sha256']))
 for e in bundle['files']:s.read_checked(template/e['path'],e['sha256'])
 import numpy as np
 import torch
 import metrics as M
 from frozen_rule import apply_rule
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True);torch.set_grad_enabled(False)
 os.chdir(template);recipe=template/'recipe';sys.path.insert(0,str(recipe));os.environ['KNET_BASIN']='04105700'
 import common as C
 for name in ['execution_sources.json','evaluation_sources.json']:
  m=json.loads(s.read_checked(recipe/name));C.DIGESTS.update({str(Path(e['path']).resolve()).lower():e['sha256'] for e in m['files']})
 from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
 from global_hydrology.experiments import daily_camels_ukf_knet_parity_runner as parity
 from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
 from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import AccessLedger,CAUSAL_SHARED_SPINUP_MODE
 def arr(x):return x.detach().cpu().numpy().copy()
 def emit(event,**kw):print(json.dumps(dict(event=event,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw),allow_nan=False),flush=True)
 def put(name,value):return s.create(out+'/'+name,value)
 def save_np(name,values):
  b=io.BytesIO();np.savez_compressed(b,**values);return put(name,b.getvalue())
 def load(identity):
  with np.load(io.BytesIO(s.read_checked(base/identity['path'],identity['sha256'])),allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
 seeds=plan['seed'];issue=np.arange(2557,3285);state_indices=np.arange(2557,3288);rows={};gates=[];manifest=[];steps=0
 cached=json.loads(s.read_checked(base/'cached_sources.json'))
 for specification in plan['basins']:
  if specification['basin'] in cached:
   basin=specification['basin'];entry=cached[basin]
   for identity in entry['files']:s.read_checked(base/identity['path'],identity['sha256'])
   row=json.loads(s.read_checked(base/entry['row']['path'],entry['row']['sha256']));rows[basin]=row
   gate=json.loads(s.read_checked(base/('runs/attempt_002/original_gate_'+basin+'.json')));assert gate['passed'];gate['comparison_eligible']=True;gates.append(gate)
   for arm in row['arms'].values():manifest.append(arm['artifact'])
   manifest.append(row['reference_artifact']);emit('completed_basin_reused',basin=basin,source_attempt='attempt_002',no_new_neural_steps=True)
   continue
  basin=specification['basin'];archived=load(specification['main']);cp=torch.load(io.BytesIO(s.read_checked(base/specification['checkpoint']['path'],specification['checkpoint']['sha256'])),weights_only=True,map_location='cpu')
  assert cp['epoch']==specification['selected_epoch'] and C.helpers.digest_tree(cp['network'])==cp['network_sha256']
  runtime=per.load_per_basin_development_runtime(get_development_basin_specification(basin),ledger=AccessLedger(),initialization_mode=CAUSAL_SHARED_SPINUP_MODE,device='cpu')
  assert runtime.context.dimension==specification['state_dimension'] and runtime.training_days==2557
  assert tuple(runtime.forcing.shape)==(3288,1,3)
  model=runtime.context.plain_model;TT=float(model.params['parTT'].item());K2=float(model.params['parK2'].item());assert K2>0
  initial=parity.training_open_loop_states(runtime)[-1].clone();previous=runtime.observations[2556:2557].clone()
  net=per.build_exact_dimension_kalman_net(runtime,zero_gain=False,seed=seeds,gain_initialization='near_zero_fc2_head',hidden=24,input_multiplier=10,output_multiplier=10,feature_scale_floor=.1,normalized_feature_guard=10.,correction_cap_in_state_scale_units=3.)
  net.load_state_dict(cp['network'],strict=True);net.eval()
  for parameter in net.parameters():parameter.requires_grad_(False)
  network_hash=C.helpers.digest_tree(net.state_dict());scales=arr(net.state_feature_scale).reshape(-1)
  dates=runtime.dates.astype('datetime64[ns]').astype('int64');obs=arr(runtime.observations).reshape(-1);thresholds=np.quantile(obs[:2557],[.5,.9,.99],method='linear')
  target=obs[issue[:,None]+np.arange(1,4)];target_dates=dates[issue[:,None]+np.arange(1,4)]
  assert np.array_equal(archived['issue_indices'],issue) and np.array_equal(archived['target'],target) and np.array_equal(archived['target_dates_ns'],target_dates)
  assert archived['prior'].shape==archived['posterior'].shape==(731,1,runtime.context.dimension)
  seasons={'DJF':[12,1,2],'MAM':[3,4,5],'JJA':[6,7,8],'SON':[9,10,11]};traces={};initial_snapshots={};arm_rows={}
  def forecasts(post):
   state=torch.from_numpy(post[:728].copy());pred=[]
   for lead in (1,2,3):
    state=model.f(state,runtime.forcing[issue+lead,0,:]);pred.append(arr(model.h(state)[:,0]))
   return np.stack(pred,axis=1)
  for arm in ['original','exact_control','modified']:
   net.initialize_filter(initial.clone(),731,previous_observation=previous.clone())
   snapshot={k:getattr(net,k).detach().clone() for k in ['m1x_posterior','m1x_posterior_previous','m1x_prior_previous','y_previous','h_Q','c_Q','h_Sigma','c_Sigma','h_S','c_S']}
   initial_snapshots[arm]=C.helpers.digest_tree(snapshot)
   if arm!='original':assert initial_snapshots[arm]==initial_snapshots['original']
   posts=[];priors=[];requested=[];realized=[];native_posts=[];innovations=[];rule_events=[];gains=[]
   for day in range(2557,3288):
    y=runtime.observations[day,0].reshape(1,1);u=runtime.forcing[day,0].reshape(1,3)
    native=net.analysis_step(y,u);prior=net.m1x_prior;correction=net.last_correction.clone();innovation=float(y[0,0]-net.m1y[0,0]);post=native
    snow_gate=False;transferred=0.
    if arm=='modified':
     post,adjusted,transferred,snow_gate=apply_rule(net,y,u,prior,correction,innovation,TT,K2)
     net.m1x_posterior=post;net.last_correction=post-prior
    if not bool(torch.isfinite(post).all()) or bool((post<0).any()):raise FloatingPointError('nonfinite/negative '+basin+' '+arm+' day '+str(day))
    posts.append(arr(post)[0]);priors.append(arr(prior)[0]);requested.append(arr(correction)[0]);realized.append(arr(post-prior)[0]);native_posts.append(arr(native)[0]);innovations.append(innovation);gains.append(arr(net.KGain).reshape(-1));rule_events.append([int(snow_gate and float(correction[0,0])>0),float(transferred)])
    steps+=1
   posterior=np.stack(posts);prior=np.stack(priors);prediction=forecasts(posterior);assert np.isfinite(prediction).all()
   data=dict(issue_indices=issue,state_indices=state_indices,prediction=prediction,target=target,target_dates_ns=target_dates,posterior=posterior,prior=prior,requested_correction=np.stack(requested),realized_correction=np.stack(realized),native_posterior=np.stack(native_posts),innovation=np.array(innovations),gain=np.stack(gains),rule_events=np.array(rule_events),initial_state=arr(initial).reshape(-1),**{'initial_snapshot__'+k:arr(v) for k,v in snapshot.items()})
   if arm=='original':
    checks={}
    for field in ['posterior','prior','prediction']:
     reference=archived[field][:,0,:] if field!='prediction' else archived[field];current=data[field]
     legacy=bool(np.allclose(current,reference,atol=1e-8,rtol=1e-6));normalized=float(np.max(np.abs(current-reference)/scales)) if field!='prediction' else None
     passed=normalized<=plan['portability_gates']['state_training_scale_limit'] if normalized is not None else legacy
     checks[field]=dict(passed=passed,legacy_elementwise_passed=legacy,max_absolute_difference=float(np.max(np.abs(current-reference))),max_training_scale_difference=normalized)
    original_mse=M.score(prediction,target)['mse'];reference_mse=M.score(archived['prediction'],target)['mse'];checks['mse']=dict(passed=abs(original_mse-reference_mse)<=1e-8+1e-5*abs(reference_mse),replayed=original_mse,archived=reference_mse)
    gate=dict(basin=basin,checks=checks,passed=all(v['passed'] for v in checks.values()));gates.append(gate);put('original_gate_'+basin+'.json',gate)
    if not checks['prediction']['passed'] or not checks['mse']['passed']:raise RuntimeError('unchanged forecast/MSE portability gates failed '+basin)
    gate['comparison_eligible']=False
   if arm=='exact_control':
    deviations={key:float(np.max(np.abs(data[key]-traces['original'][key]))) for key in ['posterior','prior','prediction','requested_correction','innovation']}
    exact_gate=dict(basin=basin,checks=deviations,passed=max(deviations.values())<=1e-12)
    put('exact_control_'+basin+'.json',exact_gate)
    if not exact_gate['passed']:raise RuntimeError('same-platform exact control failed; stop before modified')
    gate['exact_same_platform_control']=exact_gate;gate['comparison_eligible']=True
   artifacts=save_np('trace__'+basin+'__'+arm+'.npz',data);manifest.append(artifacts);traces[arm]=data
   windows={}
   for label,mask in [('main728',issue>=2557),('first365',issue<2922),('later363',issue>=2922)]:
    windows[label]=M.decompose(prediction[mask],archived['ukf_prediction'][mask],target[mask],target_dates[mask],thresholds,seasons)
   arm_rows[arm]=dict(windows=windows,artifact=artifacts,snow_gate_positive_days=int(np.sum(np.array(rule_events)[:,0])),transferred_days=int(np.sum(np.array(rule_events)[:,1]>0)),transferred_total=float(np.sum(np.array(rule_events)[:,1])),transferred_daily_max=float(np.max(np.array(rule_events)[:,1])),maximum_total_lower_change=float(np.max(np.abs(data['realized_correction'][:,4]))))
   assert C.helpers.digest_tree(net.state_dict())==network_hash
   emit('arm_complete',basin=basin,arm=arm,steps=steps,mse=windows['main728']['overall']['knet']['mse'],snow_gate_days=arm_rows[arm]['snow_gate_positive_days'],transfer_days=arm_rows[arm]['transferred_days'])
  # All three methods are scored on exactly the same pairs; UKF predictions are archived, not refit.
  comparison={}
  for label,mask in [('main728',issue>=2557),('first365',issue<2922),('later363',issue>=2922)]:
   original=traces['original']['prediction'][mask];modified=traces['modified']['prediction'][mask];reference=archived['ukf_prediction'][mask];truth=target[mask]
   flow_masks={'low_le_q50':truth<=thresholds[0],'middle_q50_q90':(truth>thresholds[0])&(truth<=thresholds[1]),'high_gt_q90':truth>thresholds[1],'high_q90_q99':(truth>thresholds[1])&(truth<=thresholds[2]),'extreme_gt_q99':truth>thresholds[2],'all':np.ones_like(truth,dtype=bool)}
   comparison[label]={}
   for group,m in flow_masks.items():
    original_score=M.score(original[m],truth[m]);modified_score=M.score(modified[m],truth[m]);ukf_score=M.score(reference[m],truth[m])
    comparison[label][group]=dict(original=original_score,modified=modified_score,ukf=ukf_score,modified_minus_original_mse=None if not m.any() else modified_score['mse']-original_score['mse'],relative_modified_improvement=None if not m.any() or original_score['mse']==0 else (original_score['mse']-modified_score['mse'])/original_score['mse'])
  ref_artifact=save_np('reference__'+basin+'.npz',dict(issue_indices=issue,target=target,target_dates_ns=target_dates,ukf_prediction=archived['ukf_prediction'],archived_knet_prediction=archived['prediction'],dates=dates[2557:3288],observations=obs[2557:3288],forcing=arr(runtime.forcing)[2557:3288,0,:],thresholds=thresholds,initial_state=arr(initial).reshape(-1),TT=np.array(TT),K2=np.array(K2),state_scales=scales,observation_scale=arr(net.observation_feature_scale).reshape(-1)))
  manifest.append(ref_artifact)
  row=dict(basin=basin,selected_epoch=specification['selected_epoch'],state_dimension=runtime.context.dimension,checkpoint_sha256=specification['checkpoint']['sha256'],network_sha256=network_hash,initial_snapshot_sha256=initial_snapshots,thresholds=thresholds.tolist(),TT=TT,K2=K2,arms={k:v for k,v in arm_rows.items() if k!='exact_control'},exact_control=arm_rows['exact_control'],comparison=comparison,reference_artifact=ref_artifact,new_training_updates=0,new_neural_assimilation_steps=1462)
  rows[basin]=row;put('basin_'+basin+'.json',row);emit('basin_complete',basin=basin,steps=steps)
 assert steps==plan['new_neural_assimilation_steps_this_attempt'] and len(rows)==3
 put('trace_manifest.json',dict(files=manifest));put('result.json',dict(status='RECHECK_COMPLETE',experiment_id=plan['experiment_id'],job_id=os.environ['SLURM_JOB_ID'],contract_sha256=hashlib.sha256(planraw).hexdigest(),rule_sha256=auth['rule_sha256'],rule_provenance=plan['rule_provenance'],basins=rows,original_gates=gates,trajectories=6,auxiliary_control_trajectories=1,new_neural_assimilation_steps=4386,new_neural_assimilation_steps_this_attempt=steps,reused_neural_assimilation_steps=2924,auxiliary_exact_control_steps=731,total_neural_steps_all_attempts=5848,archive_state_portability_failure_retained=['09035800'],protocol_revision=plan['protocol_revision'],new_training_updates=0,ukf_refit=False,runtime_versions=dict(torch=torch.__version__,numpy=np.__version__,python=sys.version),completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
 emit('recheck_complete',trajectories=6,steps=steps,new_training_updates=0)

if __name__=='__main__':main()
