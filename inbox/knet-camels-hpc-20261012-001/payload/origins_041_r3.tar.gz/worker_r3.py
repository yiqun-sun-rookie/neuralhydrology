"""Frozen physical-state / history-feature / recurrent-memory diagnostic; CPU Slurm only."""
import os,sys,json,io,hashlib,datetime,importlib.util,itertools,traceback
from pathlib import Path

def main():
 base=Path(__file__).resolve().parent; template=base.parents[1]/'template'
 spec=importlib.util.spec_from_file_location('safe_io',base/'safe_io.py'); s=importlib.util.module_from_spec(spec);sys.modules['safe_io']=s;spec.loader.exec_module(s)
 handshake=json.loads(sys.stdin.readline());assert handshake.get('resources_configured') and os.environ.get('SLURM_JOB_ID','').isdigit()
 out='runs/'+sys.argv[1]
 auth=json.loads(s.read_checked(base/'execution_authorization_r3.json'))
 assert auth['status']=='AUTHORIZED' and auth['new_training_updates']==0
 for x in auth['files']:s.read_checked(base/x['path'],x['sha256'])
 planraw=s.read_checked(base/'plan_contract_r3.json');plan=json.loads(planraw)
 bundle=json.loads(s.read_checked(template/'bundle_manifest.json',auth['template_manifest_sha256']))
 for x in bundle['files']:s.read_checked(template/x['path'],x['sha256'])
 import numpy as np
 import torch
 import metrics as M
 torch.set_num_threads(1);torch.use_deterministic_algorithms(True);torch.set_grad_enabled(False)
 os.chdir(template);os.environ['KNET_BASIN']='04105700';recipe=template/'recipe';sys.path.insert(0,str(recipe))
 import common as C
 for name in ['execution_sources.json','evaluation_sources.json']:
  manifest=json.loads(s.read_checked(recipe/name));C.DIGESTS.update({str(Path(x['path']).resolve()).lower():x['sha256'] for x in manifest['files']})
 def emit(event,**kw):print(json.dumps(dict(event=event,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw),allow_nan=False),flush=True)
 def put(name,obj):return s.create(out+'/'+name,obj)
 def npz(name,a):
  b=io.BytesIO();np.savez_compressed(b,**a);return put(name,b.getvalue())
 def arr(x):return x.detach().cpu().numpy().copy()
 reg=json.loads(s.read_checked(base/'inputs/registry.json'));cpentry=reg['checkpoint']
 cp=torch.load(io.BytesIO(s.read_checked(base/cpentry['path'],cpentry['sha256'])),weights_only=True,map_location='cpu')
 assert cp['epoch']==26 and C.helpers.digest_tree(cp['network'])==cp['network_sha256']
 runtime,per,parity,settings=C.setup();net=C.build(runtime,per,parity,settings);net.load_state_dict(cp['network'],strict=True);net.eval()
 model=runtime.context.plain_model;scales=arr(net.state_feature_scale).reshape(-1);network_hash=C.helpers.digest_tree(net.state_dict())
 obs=arr(runtime.observations).reshape(-1);dates=runtime.dates.astype('datetime64[ns]').astype('int64')
 thresholds=np.quantile(obs[:2557],[.5,.9,.99],method='linear');seasons={'DJF':[12,1,2],'MAM':[3,4,5],'JJA':[6,7,8],'SON':[9,10,11]}
 archived={}
 for e in reg['cases']:
  ident=e['artifact']
  with np.load(io.BytesIO(s.read_checked(base/ident['path'],ident['sha256'])),allow_pickle=False) as z:archived[e['label']]={k:z[k].copy() for k in z.files}
 fields=tuple(plan['interventions']['R']);snapshots={};traces={};rows={};trace_manifest=[];gates=[];filter_days=0
 compact={'issue_indices':np.arange(2922,3285),'target':obs[np.arange(2922,3285)[:,None]+np.arange(1,4)]}
 def capture():
  x=net.m1x_posterior.detach().clone()
  return dict(S=x,H_e=x-net.m1x_posterior_previous,H_u=x-net.m1x_prior_previous,H_y=net.y_previous.detach().clone(),**{k:getattr(net,k).detach().clone() for k in fields})
 def clone(z):return {k:v.detach().clone() for k,v in z.items()}
 def restore(z,start):
  net.initialize_filter(z['S'].clone(),3288-start,previous_observation=z['H_y'].clone())
  net.m1x_posterior_previous=z['S']-z['H_e'];net.m1x_prior_previous=z['S']-z['H_u']
  for k in fields:setattr(net,k,z[k].clone())
  back=capture()
  for k in z:assert float(torch.max(torch.abs(back[k]-z[k])))<=1e-12,('snapshot_restore',k)
 def fresh(initial,previous):
  net.initialize_filter(initial.clone(),731,previous_observation=previous);return capture()
 cold_init=fresh(runtime.context.initial_state,None)
 main_init=fresh(C.open_states()[-1],runtime.observations[2556:2557])
 long_init=fresh(runtime.context.initial_state,None)
 def forecast(posts,start):
  issue=np.arange(start,3285);state=torch.from_numpy(posts[:len(issue)].copy());pred=[]
  for lead in (1,2,3):
   state=model.f(state,runtime.forcing[issue+lead,0,:]);pred.append(arr(model.h(state)[:,0]))
  values=np.stack(pred,axis=1);assert np.isfinite(values).all();return issue,values
 def run(label,start,z,source,role,extra=None):
  nonlocal filter_days
  restore(z,start);posts=[];priors=[];requested=[];gains=[];innovations=[];saved={}
  for day in range(start,3288):
   if day in (2557,2922):saved[day]=capture()
   x=net.analysis_step(runtime.observations[day,0].reshape(1,1),runtime.forcing[day,0].reshape(1,3))
   if not bool(torch.isfinite(x).all()):raise FloatingPointError('nonfinite '+label+' day '+str(day))
   posts.append(arr(x)[0]);priors.append(arr(net.m1x_prior)[0]);requested.append(arr(net.last_correction)[0]);gains.append(arr(net.KGain).reshape(-1));innovations.append(float(runtime.observations[day,0]-net.m1y[0,0]))
   filter_days+=1
   if (day-start+1)%1000==0:emit('trajectory_progress',label=label,days=day-start+1,filter_days=filter_days)
  post=np.stack(posts);prior=np.stack(priors);requested=np.stack(requested);gain=np.stack(gains);innovation=np.array(innovations)
  issue,pred=forecast(post,start);target=obs[issue[:,None]+np.arange(1,4)];a=archived[source];ix=np.searchsorted(a['issue_indices'],issue);assert np.array_equal(a['issue_indices'][ix],issue)
  windows={}
  for name,begin in [('main728',2557),('common363',2922)]:
   if start>begin:continue
   mask=issue>=begin
   windows[name]=M.decompose(pred[mask],a['ukf_prediction'][ix[mask]],target[mask],dates[issue[mask,None]+np.arange(1,4)],thresholds,seasons)
  mask=issue>=2922;compact[label+'__prediction']=pred[mask];compact[label+'__snow_lower']=post[2922-start:3285-start][:,[0,4]]
  baselinepost=a['knet_posterior'][np.searchsorted(a['state_indices'],np.arange(start,3288))]
  blocks=[]
  for lo,hi in [(0,7),(7,30),(30,90),(90,365),(365,3288-start)]:
   end=min(hi,3288-start)
   if lo>=end:continue
   mask=(issue-start>=lo)&(issue-start<end)
   block=dict(age_start=lo,age_end_exclusive=end,snow_lower_mean=post[lo:end][:,[0,4]].mean(axis=0).tolist(),state_rms_vs_original_receiver=np.sqrt(np.mean((post[lo:end][:,[0,4]]-baselinepost[lo:end][:,[0,4]])**2,axis=0)).tolist(),mean_realized_correction=(post-prior)[lo:end][:,[0,4]].mean(axis=0).tolist(),cap_fraction=(np.abs(requested[lo:end][:,[0,4]])>=3*scales[[0,4]]*(1-1e-9)).mean(axis=0).tolist())
   if mask.any():block['score']=M.score(pred[mask],target[mask])
   blocks.append(block)
  data=dict(state_indices=np.arange(start,3288),issue_indices=issue,prediction=pred,target=target,posterior=post,prior=prior,requested_correction=requested,gain=gain,innovation=innovation)
  artifact=npz('trace__'+label+'.npz',data);trace_manifest.append(artifact)
  row=dict(label=label,role=role,start=start,filter_days=3288-start,source_ukf_and_state_reference=source,windows=windows,age_blocks=blocks,initial_state=arr(z['S']).reshape(-1).tolist(),initial_history={k:arr(z[k]).reshape(-1).tolist() for k in ['H_e','H_u','H_y']},initial_snapshot_sha256=C.helpers.digest_tree(z),artifact=artifact,**(extra or {}))
  rows[label]=row;traces[label]=data;snapshots[label]=saved
  emit('trajectory_complete',label=label,role=role,filter_days=filter_days,common_mse=windows['common363']['overall']['knet']['mse'])
  return row,data
 anchors=[('long',366,long_init,'cold_366'),('cold',2557,cold_init,'cold_2557'),('main',2557,main_init,'main728')]
 for name,start,z,archive in anchors:
  row,data=run('anchor_'+name,start,z,archive,'anchor');ref=archived[archive];gate={}
  for field,key in [('posterior','knet_posterior'),('prior','knet_prior'),('prediction','knet_prediction')]:
   x,y=data[field],ref[key];assert x.shape==y.shape
   passed=bool(np.allclose(x,y,atol=plan['anchor_gates']['state_and_prediction_atol'],rtol=plan['anchor_gates']['state_and_prediction_rtol']))
   legacy_passed=passed
   normalized=None
   if field in ('posterior','prior'):
    normalized=float(np.max(np.abs(x-y)/scales))
    passed=normalized<=plan['anchor_gates']['training_scale_normalized_state_limit']
   gate[field]=dict(passed=passed,legacy_elementwise_passed=legacy_passed,max_absolute_difference=float(np.max(np.abs(x-y))),maximum_training_scale_normalized_difference=normalized)
  x=M.score(data['prediction'],data['target'])['mse'];y=M.score(ref['knet_prediction'],ref['target'])['mse']
  gate['mse']=dict(passed=abs(x-y)<=plan['anchor_gates']['mse_absolute_tolerance']+plan['anchor_gates']['mse_relative_tolerance']*abs(y),actual=x,archived=y)
  record=dict(anchor=name,checks=gate,passed=all(v['passed'] for v in gate.values()));gates.append(record);put('anchor_gate_'+name+'.json',record)
  if not record['passed']:raise RuntimeError('archived anchor replay mismatch; intervention not started')
 emit('all_anchor_gates_passed',anchors=3)
 budget_data={};budget_rows={}
 for name,start,z,archive in anchors:
  t=traces['anchor_'+name];a=archived[archive];kp=t['posterior'];kprior=t['prior'];up=a['ukf_posterior'];uprior=a['ukf_prior'];initial=arr(z['S']).reshape(-1)
  kprev=np.vstack([initial,kp[:-1]]);uprev=np.vstack([initial,up[:-1]])
  process=(kprior-kprev)-(uprior-uprev);analysis=(kp-kprior)-(up-uprior);cprocess=np.cumsum(process,axis=0);canalysis=np.cumsum(analysis,axis=0);delta=kp-up
  error=float(np.max(np.abs(delta-cprocess-canalysis)));assert error<=1e-8
  checkpoints=[]
  for age in sorted(set([0,6,29,89,364,len(kp)-1])):
   if age>=len(kp):continue
   checkpoints.append(dict(age=age,date=str(runtime.dates[start+age].astype('datetime64[D]')),snow_lower_difference=delta[age,[0,4]].tolist(),cumulative_process_difference=cprocess[age,[0,4]].tolist(),cumulative_analysis_difference=canalysis[age,[0,4]].tolist()))
  budget_rows[name]=dict(initial_difference=[0.,0.],closure_max_error=error,checkpoints=checkpoints,mean_state_difference=delta[:,[0,4]].mean(axis=0).tolist(),mean_process_difference=process[:,[0,4]].mean(axis=0).tolist(),mean_analysis_difference=analysis[:,[0,4]].mean(axis=0).tolist())
  for field,value in [('dates',dates[np.arange(start,3288)]),('difference',delta[:,[0,4]]),('process',process[:,[0,4]]),('analysis',analysis[:,[0,4]]),('k_gain',t['gain'][:,[0,4]]),('innovation',t['innovation']),('k_requested',t['requested_correction'][:,[0,4]])]:budget_data[name+'__'+field]=value
 put('storage_budget.json',budget_rows);npz('storage_budget_daily.npz',budget_data)
 # Initial-state/one-observation factorial off-diagonal cells, then two initial-component probes.
 off=clone(cold_init);off['H_y']=main_init['H_y'].clone();run('init_cold_actual_previous',2557,off,'cold_2557','initial_factorial',{'physical_initial':'cold','previous_observation':'actual'})
 off=clone(main_init);off['H_y']=cold_init['H_y'].clone();run('init_main_cold_previous',2557,off,'main728','initial_factorial',{'physical_initial':'main','previous_observation':'cold'})
 for name,index in [('snow',0),('lower',4)]:
  off=clone(cold_init);off['S'][:,index]=main_init['S'][:,index];run('init_only_'+name,2557,off,'cold_2557','initial_component',{'changed_indices':[index]})
 factor_tables=[];continuation=[]
 for cut in (2557,2922):
  donor=snapshots['anchor_long'][cut]
  for receiver in ('cold','main'):
   rec=snapshots['anchor_'+receiver][cut];matrix={}
   for bits in itertools.product((0,1),repeat=3):
    key=''.join(map(str,bits));z=clone(rec)
    if bits[0]:z['S']=donor['S'].clone()
    if bits[1]:
     for k in ('H_e','H_u','H_y'):z[k]=donor[k].clone()
    if bits[2]:
     for k in fields:z[k]=donor[k].clone()
    label=f'bridge_{cut}_{receiver}_{key}';row,data=run(label,cut,z,'cold_2557' if receiver=='cold' else 'main728','factorial',{'cut':cut,'receiver':receiver,'donor':'long','bits':key})
    matrix[key]=label
    if key in ('000','111'):
     ref=traces['anchor_'+(receiver if key=='000' else 'long')];offset=cut-int(ref['state_indices'][0]);ep=float(np.max(np.abs(data['posterior']-ref['posterior'][offset:])));ef=float(np.max(np.abs(data['prediction']-ref['prediction'][offset:])))
     gate=dict(label=label,max_state_error=ep,max_prediction_error=ef,passed=max(ep,ef)<=plan['continuation_gate_absolute_tolerance']);continuation.append(gate);put('continuation_'+label+'.json',gate)
     if not gate['passed']:raise RuntimeError('continuation gate mismatch')
   effects={}
   for window in ('main728','common363'):
    if window not in rows[matrix['000']]['windows']:continue
    metrics={k:rows[v]['windows'][window]['overall']['knet'] for k,v in matrix.items()};effects[window]={}
    for measure in ('mse','mae','bias'):
     values={k:v[measure] for k,v in metrics.items()};isolated={};averaged={};interactions={}
     for j,factor in enumerate(('S','H','R')):
      key=['0']*3;key[j]='1';isolated[factor]=values[''.join(key)]-values['000'];diff=[]
      for bits in itertools.product((0,1),repeat=3):
       if bits[j]:continue
       a=''.join(map(str,bits));b=list(a);b[j]='1';diff.append(values[''.join(b)]-values[a])
      averaged[factor]=float(np.mean(diff))
     for key in ('110','101','011','111'):
      active=[j for j,b in enumerate(key) if b=='1'];value=0.
      for flags in itertools.product((0,1),repeat=len(active)):
       term=['0']*3
       for j,flag in zip(active,flags):term[j]=str(flag)
       value+=(-1)**(len(active)-sum(flags))*values[''.join(term)]
      interactions[key]=value
     assert abs(sum(isolated.values())+sum(interactions.values())-(values['111']-values['000']))<1e-10
     effects[window][measure]=dict(cells=values,isolated_effects=isolated,average_conditional_effects=averaged,interactions=interactions,total=values['111']-values['000'])
   factor_tables.append(dict(cut=cut,receiver=receiver,matrix=matrix,effects=effects))
  emit('cut_complete',cut=cut,trajectories=len(rows),filter_days=filter_days)
 assert filter_days==plan['interventions']['filter_day_count'] and len(rows)==39 and len(continuation)==8
 assert C.helpers.digest_tree(net.state_dict())==network_hash
 snapshot_arrays={}
 for label in ('anchor_long','anchor_cold','anchor_main'):
  for cut,z in snapshots[label].items():
   for key,value in z.items():snapshot_arrays[f'{label}__{cut}__{key}']=arr(value)
 npz('boundary_snapshots.npz',snapshot_arrays);npz('common363_predictions_states.npz',compact)
 put('trace_manifest.json',dict(files=trace_manifest,remote_root=plan['remote_root'],fields='full states, priors, requested corrections, gains, innovations and all forecasts',local_compact_delivery='common363_predictions_states.npz'))
 result=dict(status='DIAGNOSTIC_COMPLETE',experiment_id=plan['experiment_id'],job_id=os.environ['SLURM_JOB_ID'],contract_sha256=hashlib.sha256(planraw).hexdigest(),basin='04105700',selected_epoch=26,seed=20260922,checkpoint_sha256=cpentry['sha256'],runtime_versions=dict(torch=torch.__version__,numpy=np.__version__,python=sys.version),protocol_revision=plan['protocol_revision'],network_sha256=network_hash,thresholds=thresholds.tolist(),anchor_gates=gates,continuation_gates=continuation,trajectories=len(rows),new_neural_assimilation_steps=filter_days,new_training_updates=0,cases=rows,factorial_tables=factor_tables,storage_budget=budget_rows,interpretation_limits=plan['interpretation_limits'],completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put('result.json',result);emit('diagnostic_complete',trajectories=len(rows),filter_days=filter_days,new_training_updates=0)

if __name__=='__main__':main()
