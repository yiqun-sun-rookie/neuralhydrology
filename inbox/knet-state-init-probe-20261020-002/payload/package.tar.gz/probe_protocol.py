"""Clock and observation rules, independent of cross-host wall time."""
import re

MEMORY_ENV = ('SBATCH_MEM_PER_NODE', 'SBATCH_MEM_PER_CPU', 'SBATCH_MEM_PER_GPU')
TERMINAL = {'COMPLETED','FAILED','TIMEOUT','CANCELLED','OUT_OF_MEMORY','NODE_FAIL','PREEMPTED','BOOT_FAIL','DEADLINE','REVOKED'}

def submission_env(source):
    return {k:v for k,v in source.items() if k not in MEMORY_ENV}

def process_start_lower(proc_stat, ticks_per_second):
    # Fields after the final ') ' start at field 3; starttime is field 22.
    fields=proc_stat.rsplit(') ',1)[1].split()
    assert ticks_per_second>0
    return int(fields[19])/ticks_per_second

def batch_elapsed(boot_now, start_lower, ticks_per_second):
    lower=boot_now-start_lower-1/ticks_per_second
    upper=boot_now-start_lower
    if lower<0 or upper<lower:raise ValueError('Invalid same-node batch clock')
    return lower,upper

def progress_key(event):
    if event.get('event')=='training_segment_progress':return (event['arm'],'training',event['segments'])
    if event.get('event')=='validation_day_progress':return (event['arm'],'validation',event['days'])
    if event.get('event')=='phase_complete':return (event['arm'],event['phase'],event.get('segments',event.get('days')))
    return None

def assess(row, upper):
    if row['terminal']:return dict(status='TERMINAL_READY_FOR_COLLECTION',healthy=False)
    fields=row['scheduler_fields'];state=fields.get('JobState')
    if state=='PENDING' and fields.get('Reason') in ('Priority','Resources','JobArrayTaskLimit'):
        return dict(status='VERIFIED_QUEUED' if upper<=600 else 'MONITOR_FAILED',healthy=upper<=600)
    if state!='RUNNING':return dict(status='MONITOR_FAILED',healthy=False,reason='Unknown scheduler state')
    c,w,snap=row.get('controller'),row.get('worker'),row.get('fresh_snapshot')
    identity=bool(c and w and snap and c['job_id']==w['job_id']==snap['job_id']==row['job_id'] and c['node']==w['node']==snap['node']==fields.get('NodeList') and c['worker_pid']==w['pid']==snap['worker_pid'] and c['pid']==snap['controller_pid'] and c['contract_sha256']==w['contract_sha256']==snap['contract_sha256']==row['contract_sha256'] and fields.get('Command')==row['script_path'] and fields.get('WorkDir')==row['remote_root'] and snap['nonce']==row.get('snapshot_nonce'))
    if not identity:return dict(status='MONITOR_FAILED',healthy=False,reason='Fresh nonce or identity evidence missing')
    stat=row.get('resource');resource=snap.get('resource')
    resource_ok=bool(stat and stat['returncode']==0 and stat['stdout'].strip() and resource and 0<=snap['resource_age_upper_seconds'] and upper+snap['resource_age_upper_seconds']<=600 and resource['combined_rss_bytes']<=6442450944 and resource['free_bytes']>=2147483648 and resource['child_cpu_seconds']>=0 and len(resource['affinity'])==1)
    age=snap.get('progress_age_upper_seconds');startup=not snap.get('latest_progress') and snap['batch_elapsed_upper_seconds']<=120
    regressed=bool(snap.get('progress_regressions'))
    healthy=bool(not regressed and resource_ok and 0<=upper<=600 and (startup or age is not None and age>=0 and upper+age<=600))
    return dict(status='VERIFIED_INITIALIZING' if healthy else 'MONITOR_FAILED',healthy=healthy,progress_age_upper_seconds=age,startup_transition=startup,identity_verified=identity,clock_source='same-node monotonic nonce response',resource_verified=resource_ok,progress_regressions=snap.get('progress_regressions',[]))
