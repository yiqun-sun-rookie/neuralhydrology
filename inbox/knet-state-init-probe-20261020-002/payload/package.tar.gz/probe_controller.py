"""One zero-call worker with batch-shell clock and fresh progress snapshots."""
import os,sys,json,time,threading,datetime,subprocess,re,signal,hashlib,traceback
from pathlib import Path
import psutil
import safe_io as s
from probe_protocol import process_start_lower,batch_elapsed,progress_key
BASE=Path(__file__).resolve().parent
OUT='runs/04105700/attempt_001'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def boot():return time.clock_gettime(time.CLOCK_BOOTTIME)

def main():
    child=None;stop=None;peak=0;minimum=None;cpu=0.;wall=None;job=os.environ.get('SLURM_JOB_ID');node=os.uname().nodename
    contract_raw=s.read_checked(BASE/'probe_contract.json');contract=json.loads(contract_raw);sha=hashlib.sha256(contract_raw).hexdigest();limits=contract['resource_limits']
    assert job and job.isdigit() and not os.environ.get('SLURM_ARRAY_TASK_ID')
    assert not (BASE/OUT).exists(),'One attempt only'
    assert contract['total_optimizer_calls']==0 and limits['total_wall_seconds']==1800
    proc=psutil.Process();chunks=[];reader=None;result=None;clock=None;error=None
    try:
        shell=int(os.environ['HPC_BATCH_SHELL_PID'])
        assert shell in [proc.pid]+[p.pid for p in proc.parents()]
        hz=os.sysconf('SC_CLK_TCK');shell_stat=s.read_checked(Path('/proc')/str(shell)/'stat').decode()
        origin=process_start_lower(shell_stat,hz)
        def elapsed():return batch_elapsed(boot(),origin,hz)
        lower,upper=elapsed()
        clock=dict(source='batch shell /proc start ticks and same-node CLOCK_BOOTTIME',scope='batch shell creation including environment activation; full allocation limited independently by Slurm',shell_pid=shell,proc_stat=shell_stat,ticks_per_second=hz,start_lower_boottime_seconds=origin,node_utc=now(),boot_id=s.read_checked(Path('/proc/sys/kernel/random/boot_id')).decode().strip(),initial_lower_seconds=lower,initial_upper_seconds=upper)
        s.create(OUT+'/batch_clock.json',clock)
        q0=boot();details=subprocess.run(['scontrol','-d','show','job',job],capture_output=True,text=True,timeout=15);q1=boot()
        s.create(OUT+'/scheduler_before_worker.json',dict(returncode=details.returncode,stdout=details.stdout,stderr=details.stderr,node_utc=now(),rpc_seconds=q1-q0,batch_elapsed_upper_seconds=elapsed()[1]))
        assert details.returncode==0,'scontrol failed; raw response preserved'
        fields=dict(re.findall(r'(\w+)=([^\s]+)',details.stdout))
        clock.update(raw_start=fields.get('StartTime'),raw_runtime=fields.get('RunTime'),rpc_seconds=q1-q0)
        # RunTime may be INVALID on this cluster. It is preserved, never used as a number.
        assert fields['JobId']==job and fields['Command']==str(BASE/'probe.slurm') and fields['WorkDir']==str(BASE)
        assert fields['JobState']=='RUNNING' and fields['NodeList']==node
        allocated=set()
        for field in re.findall(r'CPU_IDs=([0-9,-]+)',details.stdout):
            for item in field.split(','):
                if '-' in item:
                    a,b=map(int,item.split('-'));allocated.update(range(a,b+1))
                else:allocated.add(int(item))
        eligible=sorted(allocated.intersection(proc.cpu_affinity()));assert eligible,'No allocated CPU identity'
        proc.cpu_affinity([eligible[0]]);proc.nice(10);os.environ['HPC_BASIN']='04105700'
        rss=proc.memory_info().rss;available=psutil.virtual_memory().available;peak=rss;minimum=available
        s.create(OUT+'/resource_preflight.json',dict(job_id=job,node=node,utc=now(),rss_bytes=rss,available_bytes=available,clock=clock,affinity=proc.cpu_affinity()))
        if rss>limits['combined_rss_limit_bytes']:stop='RSS_LIMIT_BEFORE_WORKER'
        elif available<limits['minimum_free_bytes']:stop='SYSTEM_FREE_LIMIT_BEFORE_WORKER'
        elif elapsed()[1]>=1740:stop='WORK_CUTOFF_BEFORE_WORKER'
        if stop:raise RuntimeError(stop)
        interrupted=[]
        def interrupt(signum,frame):
            interrupted.append(signum)
            if child is not None and child.poll() is None:child.terminate()
        signal.signal(signal.SIGTERM,interrupt);signal.signal(signal.SIGINT,interrupt)
        child=psutil.Popen([sys.executable,'-u','-B',str(BASE/'initializer_probe.py'),OUT],cwd=str(BASE),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        child.cpu_affinity(proc.cpu_affinity());child.nice(10)
        child_start_lower=process_start_lower(s.read_checked(Path('/proc')/str(child.pid)/'stat').decode(),hz)
        controller=dict(utc=now(),pid=proc.pid,creation_time=proc.create_time(),job_id=job,node=node,contract_sha256=sha,worker_pid=child.pid,clock=clock,affinity=proc.cpu_affinity(),priority_nice=proc.nice(),scontrol=details.stdout)
        worker=dict(utc=now(),pid=child.pid,creation_time=child.create_time(),job_id=job,node=node,contract_sha256=sha,affinity=child.cpu_affinity(),priority_nice=child.nice(),start_lower_boottime_seconds=child_start_lower)
        s.create(OUT+'/controller_started.json',controller);s.create(OUT+'/scientific_started.json',worker)
        guard=threading.Lock();progress={};latest=None;regressions=[]
        def consume():
            nonlocal latest
            for line in iter(child.stdout.readline,b''):
                chunks.append(line)
                try:record=json.loads(line)
                except (ValueError,UnicodeDecodeError):print(line.decode(errors='replace').rstrip(),flush=True);continue
                if isinstance(record,dict):
                    lower,upper=elapsed();record.update(batch_elapsed_lower_seconds=lower,batch_elapsed_upper_seconds=upper,job_id=job,worker_pid=child.pid,node=node)
                    key=progress_key(record)
                    if key:
                        with guard:
                            previous=progress.get(key[:2])
                            if previous is not None and key[2]<progress_key(previous)[2]:regressions.append(record)
                            if previous is None or key[2]>progress_key(previous)[2]:progress[key[:2]]=record;latest=record
                print(json.dumps(record),flush=True)
        reader=threading.Thread(target=consume,daemon=True);reader.start()
        child.stdin.write(b'{"resources_configured":true}\n');child.stdin.flush();child.stdin.close();last=-30;answered=set()
        while child.poll() is None:
            lower,upper=elapsed()
            try:
                sample_lower=boot();rss=sum(p.memory_info().rss for p in [proc,child]+child.children(recursive=True));available=psutil.virtual_memory().available;ct=child.cpu_times();cpu=ct.user+ct.system
                peak=max(peak,rss);minimum=min(minimum,available)
                resource=dict(child_cpu_seconds=cpu,combined_rss_bytes=rss,free_bytes=available,affinity=child.cpu_affinity())
                if upper-last>=30:
                    print(json.dumps(dict(event='resource_sample',utc=now(),job_id=job,node=node,worker_pid=child.pid,batch_elapsed_lower_seconds=lower,batch_elapsed_upper_seconds=upper,**resource)),flush=True);last=upper
                for request in sorted((BASE/'monitor_exchange').glob('monitor_request_*.json')):
                    if request.name in answered:continue
                    req=json.loads(s.read_checked(request));nonce=req['nonce']
                    assert re.fullmatch('[0-9a-f]{32}',nonce) and request.name=='monitor_request_'+nonce+'.json' and req['job_id']==job
                    with guard:
                        event=latest;by_phase=list(progress.values());bad=list(regressions)
                    # Worker elapsed starts after process creation. Using process start plus
                    # event elapsed is a LOWER bound on event time, so age is conservative.
                    age=None if event is None else boot()-(child_start_lower+float(event['elapsed_seconds']))
                    response=dict(nonce=nonce,job_id=job,node=node,controller_pid=proc.pid,worker_pid=child.pid,contract_sha256=sha,utc=now(),batch_elapsed_upper_seconds=elapsed()[1],progress_age_upper_seconds=age,resource_age_upper_seconds=boot()-sample_lower,latest_progress=event,progress_by_phase=by_phase,progress_regressions=bad,resource=resource,optimizer_calls=0,effective_nonzero_steps=0)
                    s.create(OUT+'/monitor_response_'+nonce+'.json',response);answered.add(request.name)
                if rss>limits['combined_rss_limit_bytes']:stop='RSS_LIMIT'
                elif available<limits['minimum_free_bytes']:stop='SYSTEM_FREE_LIMIT'
                elif upper>=1740:stop='WORK_CUTOFF_1740'
                elif interrupted:stop='EXTERNAL_SIGNAL'
                if stop:child.terminate();break
            except psutil.NoSuchProcess:pass
            time.sleep(.25)
        try:child.wait(timeout=min(10,max(.1,1790-elapsed()[1])))
        except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
        reader.join(timeout=5);s.create(OUT+'/stdout.log',b''.join(chunks))
        if (BASE/OUT/'result.json').exists():result=json.loads(s.read_checked(BASE/OUT/'result.json'))
        wall=elapsed()[1]
    except BaseException as exc:
        error=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc())
        if child is not None and child.poll() is None:child.terminate();child.wait(timeout=10)
        if clock:wall=elapsed()[1]
        if chunks and not (BASE/OUT/'stdout.log').exists():s.create(OUT+'/stdout.log',b''.join(chunks))
        s.create(OUT+'/controller_failure.json',error)
    passed=bool(not error and child is not None and child.returncode==0 and stop is None and result and result['status']=='INITIALIZATION_ONLY_PASS' and wall<=1800 and peak<=limits['combined_rss_limit_bytes'] and minimum>=limits['minimum_free_bytes'])
    receipt=dict(status='COMPLETED' if passed else 'FAILED',job_id=job,node=node,contract_sha256=sha,worker_started=child is not None,exit_code=None if child is None else child.returncode,resource_stop=stop,error=error,clock=clock,wall_seconds_upper=wall,wall_scope='batch shell creation; allocation total independently checked in native ElapsedRaw',budget_pass=wall is not None and wall<=1800,combined_rss_peak_bytes=peak,system_free_min_bytes=minimum,child_cpu_seconds=cpu,affinity=proc.cpu_affinity(),mathematical_threads=1,total_optimizer_calls=0 if child is None else None if result is None else result['total_optimizer_calls'],total_effective_nonzero_steps=0 if child is None else None if result is None else result['total_effective_nonzero_steps'],result_present=result is not None,ended_utc=now())
    s.create(OUT+'/receipt.json',receipt);print('PROBE_RECEIPT='+json.dumps(receipt),flush=True)
    return 0 if passed else 1

if __name__=='__main__':raise SystemExit(main())
