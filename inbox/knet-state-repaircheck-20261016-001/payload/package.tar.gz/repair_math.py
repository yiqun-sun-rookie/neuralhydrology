"""Certified small QPs and a conservative float32 installation guard; no model imports."""
import itertools
import numpy as np


def project_qp(displacement, gradients, bounds=None, tolerance=1e-10):
    d = np.asarray(displacement, dtype=np.float64)
    g = np.asarray(gradients, dtype=np.float64)
    assert np.isfinite(d).all() and np.isfinite(g).all()
    norms = np.linalg.norm(g, axis=1)
    keep = norms > 0
    a = g[keep] / norms[keep, None]
    rhs = np.zeros(len(a)) if bounds is None else np.asarray(bounds, dtype=float)[keep]
    best = None
    for size in range(len(a) + 1):
        for active in itertools.combinations(range(len(a)), size):
            if active:
                b = a[list(active)]
                lam = np.linalg.lstsq(b @ b.T, b @ d-rhs[list(active)], rcond=None)[0]
                x = d-b.T @ lam
                equality = float(np.max(np.abs(b @ x-rhs[list(active)])))
                dual = max(0., float(-lam.min()))
                stationarity = float(np.linalg.norm(x-d+b.T @ lam))
            else:
                lam = np.zeros(0); x = d.copy()
                equality = dual = stationarity = 0.
            primal = max(0., float(np.max(a @ x-rhs))) if len(a) else 0.
            if max(equality, dual, stationarity, primal) > tolerance:
                continue
            objective = float(np.sum((x-d)**2))
            if best is None or objective < best[0]:
                best = (objective, x, dict(active=np.flatnonzero(keep)[list(active)].tolist(),
                    multipliers=lam.tolist(), equality_residual=equality, dual_residual=dual,
                    stationarity_residual=stationarity, primal_residual=primal))
    if best is None:
        return None, dict(status='UNRESOLVED', active_sets_examined=2**len(a))
    objective, x, record = best
    record.update(status='KKT_VERIFIED', active_sets_examined=2**len(a), squared_distance=objective,
        displacement_norm=float(np.linalg.norm(x)), normalized_bounds=rhs.tolist(),
        linear_changes=(g @ x).tolist())
    return x, record


def installed(before, displacement):
    return (np.asarray(before)+np.asarray(displacement)).astype(np.float32).astype(np.float64)-before


def actual_check(gradients, displacement, tolerance=1e-10):
    g = np.asarray(gradients, dtype=float); norms = np.linalg.norm(g, axis=1)
    products = g @ displacement
    violation = max(0., float(np.max(products[norms > 0]/norms[norms > 0])))
    return dict(maximum_normalized_violation=violation, linear_feasible=violation <= tolerance,
        state_directional_derivative=float(products[-1]),
        state_strict_descent=bool(products[-1] < 0), displacement_norm=float(np.linalg.norm(displacement)))


def guarded_candidate(before, nominal, gradients, radius, tolerance=1e-10):
    """Cover rounding over a fixed box, solve once, then check the actual cast vector.

    No score-informed retries, smaller factors, or relaxed scientific tolerance.
    A vector outside the precomputed box is rejected, never silently re-bounded.
    """
    before = np.asarray(before, dtype=np.float64)
    g = np.asarray(gradients, dtype=np.float64)
    lo = (before-radius).astype(np.float32)
    hi = (before+radius).astype(np.float32)
    with np.errstate(over='raise', invalid='raise'):
        gaps = np.maximum(np.abs(np.nextafter(lo, -np.inf, dtype=np.float32).astype(float)-lo),
                          np.abs(np.nextafter(hi, np.inf, dtype=np.float32).astype(float)-hi))
    error_bound = .5*gaps
    norms = np.linalg.norm(g, axis=1)
    bounds = np.zeros(len(g))
    bounds[norms > 0] = -(np.abs(g[norms > 0])/norms[norms > 0, None]) @ error_bound
    x, certificate = project_qp(nominal, g, bounds, tolerance)
    if x is None:
        return None, dict(status='GUARD_QP_UNRESOLVED', certificate=certificate)
    actual = installed(before, x)
    check = actual_check(g, actual, tolerance)
    inside = bool(np.max(np.abs(x)) <= radius)
    valid = inside and check['linear_feasible'] and check['state_strict_descent'] and np.any(actual)
    record = dict(status='CERTIFIED_NONZERO' if valid else 'REJECTED_INSTALLATION',
        certificate=certificate, rounding_box_radius=radius, rounding_error_bound=error_bound.tolist(),
        normalized_bounds=bounds.tolist(), inside_rounding_box=inside, actual=check)
    return (x if valid else None), record
