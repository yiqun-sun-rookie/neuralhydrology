"""Frozen zero-update repair check, executed only in an allocated Slurm worker."""
def run_diagnostic(e):
    import math
    import json
    import numpy as np
    import torch
    from repair_math import project_qp, guarded_candidate, actual_check, installed
    from constrained_step import project_displacement
    C=e['C']; parity=e['parity']; runtime=e['runtime']; plan=e['plan']; basin=e['basin']
    put=e['put']; np_save=e['np_save']; arr=e['arr']; emit=e['emit']
    state=e['arms']['state_constrained']; net=state['net']; coordinate=e['coordinate']
    vector=e['vector']; install=e['install']; before=vector(state)
    masks={int(k):v.astype(bool) for k,v in e['load_np']('fixed_training_masks.npz').items()}
    state_count=sum(int(x.sum()) for x in masks.values())
    assert state_count > 0 and set(masks)==set(plan['base_starts'])
    old=json.loads(e['s'].read_checked(e['base']/'inputs'/basin/'old_first_step.json'))
    reference=json.loads(e['s'].read_checked(e['base']/'inputs'/basin/'old_training_reference.json'))
    old_proposal=e['load_np']('previous_diagnostic_proposal.npz')
    assert np.array_equal(before, old_proposal['before'])
    history='detached650' if basin=='02092500' else 'complete800'
    evaluations=[]; candidates=[]; counts=dict(evaluations=0,parameter_updates=0,optimizer_calls=0)
    def forbidden(*args,**kwargs):raise AssertionError('No optimizer calls authorized')
    for arm in e['arms'].values():arm['optimizer'].step=forbidden

    def run(label, graph, gradients=False):
        counts['evaluations']+=1
        emit('evaluation_started',label=label,graph=graph,path='full',history_gradient=history,optimizer_calls=0)
        torch.set_rng_state(state['rng'].clone());net.train()
        metrics=np.zeros(8);target_sum=0.;positive_sum=0.
        gs=np.zeros((9,len(before))) if gradients else None
        predictions_all=[];truth_all=[];trace_all=[];per_segment=[];targets=[];segment_gradients=[];boundaries=[]
        for number,start in enumerate(plan['base_starts']):
            initial=runtime.context.initial_state.clone() if start==0 else e['states'][start-1].clone()
            context=parity._context_with_initial_state(runtime.context,initial)
            batch=parity.WindowBatch(purpose='training_segment',global_start=start,global_end_exclusive=start+800,
                context=context,forcing=runtime.forcing[start:start+800],observations=runtime.observations[start:start+800],
                dates=runtime.dates[start:start+800],initial_state=initial,issue_start_local=695,issue_end_local=797)
            state['trace']=[];state['prefix']=[];state['capture_prefix']=False
            state['count']=0;state['record_after']=650
            with torch.set_grad_enabled(graph):
                cuts=[]
                def boundary(network):
                    if history=='detached650':C.probe.detach_recurrence(network)
                    cuts.append({k:dict(requires_grad=bool(getattr(network,k).requires_grad),
                        has_grad_fn=getattr(network,k).grad_fn is not None) for k in C.probe.RECURRENCE_FIELDS})
                with C.diag.analysis_observer(net,650,boundary,{},start,batch.dates):
                    filtered=parity.run_knet_filter(net,batch,
                        previous_observation=parity.previous_observation_before_window(runtime,batch))
                assert len(cuts)==1 and state['count']==800 and len(state['trace'])==150
                boundaries.append(cuts[0])
                if gradients and history=='complete800':
                    assert any(v['has_grad_fn'] for v in cuts[0].values()),'History graph disconnected'
                posterior=filtered.posterior_states[:,0,:]
                raw=runtime.tukf06_module.multilead_torch(batch.context.plain_model,posterior,batch.forcing)
                pred=torch.stack([raw[k][0][695:797] for k in (1,2,3)],dim=1)
                y=runtime.observations[start+torch.arange(695,797)[:,None]+torch.arange(1,4),0]
                error=pred-y;losses=[]
                for group,denom in zip(e['groups'](arr(y)),e['training_counts']):
                    selected=error[torch.as_tensor(group)]
                    losses.extend([selected.square().sum()/int(denom),selected.abs().sum()/int(denom)])
                if label=='baseline_nograd':np.testing.assert_array_equal(e['state_mask'](state['trace'],start+650),masks[start])
                target,positive,values=e['state_terms'](state['trace'],masks[start],start+650,state)
                vals=np.array([float(v.detach()) for v in losses]);metrics+=vals
                target_sum+=float(target.detach());positive_sum+=float(positive.detach())
                per_segment.append(vals);targets.append(float(target.detach()))
                if gradients:
                    segment=np.zeros_like(gs)
                    for j,objective in enumerate(losses+[target/state_count]):
                        g=torch.autograd.grad(objective,state['parameters'],retain_graph=j<8,allow_unused=True)
                        segment[j,:-1]=0 if g[0] is None else arr(g[0][coordinate])
                        segment[j,-1]=0 if g[1] is None else float(g[1][coordinate])
                    assert np.isfinite(segment).all();gs+=segment;segment_gradients.append(segment)
                trace_all.append({k:np.stack([arr(t[k]).reshape(-1) for t in state['trace']])
                    for k in ['prior','posterior','previous','requested','prior_flow']})
                predictions_all.append(arr(pred));truth_all.append(arr(y))
            state['trace']=None
            emit('diagnostic_segments',label=label,completed=number+1,total=25,optimizer_calls=0)
        scores=np.concatenate([metrics,[target_sum/state_count]])
        assert np.isfinite(scores).all() and (gs is None or np.isfinite(gs).all())
        data=dict(prediction=np.stack(predictions_all),target=np.stack(truth_all),
            segment_flow=np.stack(per_segment),segment_state_target_sum=np.array(targets),
            state_mask=np.stack([masks[x] for x in plan['base_starts']]),state_count=np.array(state_count),
            scores=scores,positive_sum=np.array(positive_sum),installed_parameters=vector(state))
        for k in trace_all[0]:data[k]=np.stack([t[k] for t in trace_all])
        if gradients:data['segment_gradients']=np.stack(segment_gradients)
        artifact=np_save('evaluations/'+label+'.npz',data)
        record=dict(label=label,graph=graph,path='full',history_gradient=history,scores=scores.tolist(),
            artifact=artifact,optimizer_calls=0)
        put('evaluations/'+label+'.json',record);evaluations.append(record)
        if gradients:put('history_graph_boundary.json',dict(history=history,boundary_index=650,segments=boundaries))
        emit('evaluation_complete',label=label,scores=scores.tolist(),optimizer_calls=0)
        return scores,gs,data

    zero,_,zero_data=run('baseline_nograd',False)
    baseline,gradients,grad_data=run('baseline_gradient',True,True)
    repeat,_,repeat_data=run('baseline_nograd_repeat',False)
    original_reference=np.array(reference['flow_metrics']+[reference['state_target']])
    state_gate=float(old['flow_training_pre']['state_target'])
    repeat_diff={k:float(np.max(np.abs(repeat_data[k]-zero_data[k]))) for k in
        ['prediction','prior','posterior','previous','requested','prior_flow','scores']}
    assert all(v==0 for v in repeat_diff.values()),'Non-deterministic zero control'
    previous_nograd=e['load_np']('previous_zero_nograd.npz')
    zero_diff={k:float(np.max(np.abs(zero_data[k]-previous_nograd[k]))) for k in
        ['prediction','prior','posterior','previous','requested','prior_flow','scores']}
    assert all(v==0 for v in zero_diff.values()),'Original inference behavior changed at zero displacement'
    controls=dict(repeat_differences=repeat_diff,original_nograd_differences=zero_diff,
        graph_minus_nograd=(baseline-zero).tolist(),old_gate_scores=original_reference.tolist(),
        old_state_gate=state_gate,gradient_change_norms=np.linalg.norm(gradients-old_proposal['gradients'],axis=1).tolist(),
        no_mode_drift_counted_as_parameter_gain=True)
    put('zero_displacement_controls.json',controls)
    if basin=='02092500':
        assert np.array_equal(gradients,old_proposal['gradients']),'020 solver-only comparison changed gradients'
    # First empty-state Adam proposal, tensor primitives only; no optimizer.step.
    g=gradients[-1];norm=float(np.linalg.norm(g));clipped=g*min(1.,10./max(norm,1e-300))
    dtype=state['head'].weight.dtype;gt=torch.as_tensor(clipped,dtype=dtype)
    m=torch.zeros_like(gt);v=torch.zeros_like(gt)
    m.lerp_(gt,1-.9);v.mul_(.999).addcmul_(gt,gt,value=1-.999)
    denominator=v.sqrt().div_(math.sqrt(1-.999)).add_(1e-8)
    weights=torch.as_tensor(before,dtype=dtype).clone()
    weights.addcdiv_(m,denominator,value=-(.0005/(1-.9)))
    proposal=arr(weights).astype(float)-before
    nominal,certificate=project_qp(proposal,gradients,tolerance=1e-10)
    legacy,legacy_info=project_displacement(proposal,gradients,max_cycles=200,tolerance=1e-10)
    assert nominal is not None and certificate['status']=='KKT_VERIFIED'
    radius=2*float(np.linalg.norm(proposal))+np.finfo(np.float32).eps
    np_save('first_proposal.npz',dict(before=before,gradients=gradients,proposal=proposal,
        proposal_parameters=arr(weights),clipped_state_gradient=clipped,cast_state_gradient=arr(gt),
        adam_first_moment=arr(m),adam_second_moment=arr(v),exact=nominal,dykstra=legacy,
        previous_gradients=old_proposal['gradients'],reference_scores=original_reference))
    put('projection_diagnostic.json',dict(legacy=legacy_info,exact=certificate,rounding_radius=radius,
        history_gradient=history,original_thresholds_unchanged=True))
    seen={}
    for alpha in [1.,.5,.25,.125]:
        displacement,guard=guarded_candidate(before,alpha*nominal,gradients,radius,tolerance=1e-10)
        naive=installed(before,alpha*nominal)
        record=dict(factor=alpha,guard=guard,unprotected_installation=actual_check(gradients,naive),scores=[],optimizer_calls=0)
        if displacement is None:
            record['status']='NUMERICAL_GUARD_REJECTED';candidates.append(record);continue
        install(state,before+displacement);actual=vector(state)-before
        e['frozen_check'](state)
        assert np.array_equal(actual,installed(before,displacement))
        check=actual_check(gradients,actual);assert check['linear_feasible'] and check['state_strict_descent']
        record['actual']=check
        key=vector(state).astype(np.float32).tobytes()
        if key in seen:record.update(status='IDENTICAL_INSTALLED_PARAMETERS',same_as=seen[key])
        else:
            record['status']='SCORED';seen[key]=alpha
            for graph in (False,True):
                label='guard_'+str(alpha).replace('.','p')+'_'+str(int(graph))
                scores,_,_=run(label,graph)
                origin=baseline if graph else zero
                record['scores'].append(dict(label=label,graph=graph,scores=scores.tolist(),
                    delta_from_same_mode_zero=(scores-origin).tolist(),delta_from_old_gate=(scores-original_reference).tolist(),
                    flow_gate_pass=bool(np.all(scores[:8]<=original_reference[:8]+1e-12)),
                    state_gate_pass=bool(scores[8]<=state_gate+1e-12),
                    strict_state_improvement=bool(scores[8]<origin[8]-1e-12)))
        np_save('candidate_vectors/guard_'+str(alpha).replace('.','p')+'.npz',dict(before=before,
            nominal=alpha*nominal,guarded=displacement,installed=vector(state),actual_displacement=actual))
        candidates.append(record);install(state,before)
    assert np.array_equal(vector(state),before)
    assert all(torch.equal(v,state['frozen'][k]) for k,v in net.state_dict().items())
    assert all(not arm['optimizer'].state for arm in e['arms'].values())
    put('result.json',dict(status='COMPLETE',experiment_id=plan['experiment_id'],basin=basin,
        job_id=e['os'].environ['SLURM_JOB_ID'],array_job_id=e['os'].environ['SLURM_ARRAY_JOB_ID'],
        total_optimizer_calls=0,final_network_equals_initial=True,optimizer_states_empty=True,counts=counts,
        zero_displacement=controls,history_gradient=history,candidates=candidates,evaluations=evaluations,
        scope='Frozen training-window mechanism check; proxies only; no trained model'))
    emit('diagnostic_complete',optimizer_calls=0,evaluations=len(evaluations))
