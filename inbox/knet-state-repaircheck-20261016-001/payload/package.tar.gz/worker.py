"""Zero-update first-proposal diagnostic on two fixed snapshots."""
import os, sys, io, json, hashlib, time, datetime, importlib.util, traceback
from pathlib import Path


def main():
    base = Path(__file__).resolve().parent
    template = base.parents[1] / 'template'
    spec = importlib.util.spec_from_file_location('safe_io', base/'safe_io.py')
    s = importlib.util.module_from_spec(spec); sys.modules['safe_io'] = s; spec.loader.exec_module(s)
    assert os.environ.get('SLURM_JOB_ID', '').isdigit()
    assert json.loads(sys.stdin.readline())['resources_configured']
    raw_plan = s.read_checked(base/'plan_contract.json'); plan = json.loads(raw_plan)
    auth = json.loads(s.read_checked(base/'execution_authorization.json'))
    assert auth['status'] == 'AUTHORIZED' and plan['total_optimizer_calls'] == 0
    for row in auth['files']: s.read_checked(base/row['path'], row['sha256'])
    manifest = json.loads(s.read_checked(template/'bundle_manifest.json', auth['template_manifest_sha256']))
    for row in manifest['files']: s.read_checked(template/row['path'], row['sha256'])
    import numpy as np
    import torch
    import random
    from constrained_step import project_displacement, feasible_scores
    torch.set_num_threads(1); torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    random.seed(plan['seed']); np.random.seed(plan['seed']); torch.manual_seed(plan['seed'])
    basin = os.environ['HPC_BASIN']; conf = next(x for x in plan['basins'] if x['basin']==basin)
    coordinate = conf['output_row']; out = sys.argv[1]; began = time.monotonic()
    os.chdir(template); sys.path.insert(0, str(template/'recipe')); os.environ['KNET_BASIN']='04105700'
    import common as C
    # Restore only the two already-frozen 02092500 registry entries.
    if basin=='02092500':
        known={
            'basin_02092500.npz':'453d57eab87b0d774d5895f143d51c40644f9b92fd8702ce646a6f4841378eb6',
            'basin_02092500.json':'1d888ac7e396def5d6d435574ad4af91a8adb89bf17845c87f15c5a2f2f4b0a3'}
        registered={}
        for entry in json.loads(s.read_checked(template/'recipe/evaluation_sources.json'))['files']:
            source=Path(entry['path'])
            assert not source.is_absolute() and '..' not in source.parts
            path=(template/source).resolve();name=path.name
            if name not in known:continue
            assert path.is_relative_to(template/'recipe/workspace/results')
            assert entry['sha256']==known[name]
            key=str(path.resolve()).lower()
            if key in C.DIGESTS:assert C.DIGESTS[key]==entry['sha256']
            C.DIGESTS[key]=entry['sha256'];registered[name]=entry['sha256']
        assert registered==known
    from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
    from global_hydrology.experiments import daily_camels_ukf_knet_parity_runner as parity
    from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
    from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import AccessLedger, CAUSAL_SHARED_SPINUP_MODE
    def arr(x): return x.detach().cpu().numpy().copy()
    def put(name, value): return s.create(out+'/'+name, value)
    def np_save(name, values):
        stream=io.BytesIO(); np.savez_compressed(stream, **values); return put(name,stream.getvalue())
    def pt_save(name, values):
        stream=io.BytesIO(); torch.save(values,stream); return put(name,stream.getvalue())
    def load_np(name):
        with np.load(io.BytesIO(s.read_checked(base/'inputs'/basin/name)),allow_pickle=False) as z:
            return {k:z[k].copy() for k in z.files}
    def emit(event, **values):
        print(json.dumps(dict(event=event,basin=basin,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            elapsed_seconds=time.monotonic()-began,**values),allow_nan=False),flush=True)
    cp=torch.load(io.BytesIO(s.read_checked(base/'inputs'/basin/'checkpoint.pt',conf['checkpoint_sha256'])),weights_only=True,map_location='cpu')
    runtime=per.load_per_basin_development_runtime(get_development_basin_specification(basin),
        ledger=AccessLedger(),initialization_mode=CAUSAL_SHARED_SPINUP_MODE,device='cpu')
    assert runtime.training_days==2557 and len(runtime.dates)==3288
    states=parity.training_open_loop_states(runtime)
    scales=parity.fit_training_feature_scales(runtime,floor=.1)
    per.fit_training_feature_scales=lambda r,*,floor=.1:scales
    advance=parity._advance_open_loop
    parity._advance_open_loop=lambda context,forcing,*,end_exclusive:states[-1].clone() if context is runtime.context and end_exclusive==2557 else advance(context,forcing,end_exclusive=end_exclusive)
    window=parity.select_window(runtime,'recovery'); TT=float(runtime.context.plain_model.params['parTT'])
    K2=float(runtime.context.plain_model.params['parK2'])
    CFMAX=float(runtime.context.plain_model.params['parCFMAX'])
    observations=arr(runtime.observations).reshape(-1); forcing=arr(runtime.forcing)
    dates=runtime.dates.astype('datetime64[ns]').astype('int64'); issues=np.arange(2557,3285)
    targets=observations[issues[:,None]+np.arange(1,4)]
    thresholds=np.quantile(observations[:2557],[.5,.9,.99],method='linear')
    if basin=='02092500':
        ref=load_np('reference.npz'); old=load_np('original.npz')
        original_prediction=old['prediction']; original_posterior=old['posterior']; ukf=ref['ukf_prediction']
        assert np.array_equal(arr(window.initial_state).reshape(-1),ref['initial_state'])
    else:
        ref=load_np('main.npz'); original_prediction=ref['knet_prediction']
        original_posterior=ref['knet_posterior']; ukf=ref['ukf_prediction']
    assert np.array_equal(targets,ref['target']) and np.array_equal(issues,ref['issue_indices'])
    assert np.array_equal(dates[issues[:,None]+np.arange(1,4)],ref['target_dates_ns'])
    np_save('input_snapshot.npz',dict(observations=observations,forcing=forcing,dates_ns=dates,thresholds=thresholds,
        training_open_loop=arr(states),initial_validation_state=arr(window.initial_state),ukf_prediction=ukf))
    def groups(y):
        return [y==y,y<=thresholds[0],(y>thresholds[0])&(y<=thresholds[1]),y>thresholds[1]]
    training_counts=np.zeros(4,dtype=np.int64)
    for start in plan['base_starts']:
        y=observations[start+np.arange(695,797)[:,None]+np.arange(1,4)]
        training_counts += np.array([m.sum() for m in groups(y)])
    assert training_counts[0]==7650 and np.all(training_counts>0)
    arms={}; initial_hashes={}; initial_snapshots={}
    for arm in plan['arms']:
        net=per.build_exact_dimension_kalman_net(runtime,zero_gain=False,seed=plan['seed'],
            gain_initialization='near_zero_fc2_head',hidden=24,input_multiplier=10,output_multiplier=10,
            feature_scale_floor=.1,normalized_feature_guard=10.,correction_cap_in_state_scale_units=3.)
        net.load_state_dict(cp['network'],strict=True)
        assert parity.parameter_sha256(net)==conf['parameter_sha256']
        for p in net.parameters(): p.requires_grad_(False)
        head=net.FC2[-1]; head.weight.requires_grad_(True); head.bias.requires_grad_(True)
        assert head.out_features==runtime.context.dimension and net.n==1
        hp=[head.weight,head.bias]
        opt=torch.optim.Adam(hp,lr=plan['optimizer']['lr'],weight_decay=0.,betas=(.9,.999),eps=1e-8)
        state=dict(net=net,head=head,parameters=hp,optimizer=opt,calls=0,effective=0,history=[],
            frozen={k:v.detach().clone() for k,v in net.state_dict().items()},trace=None,step=0,
            rng=torch.get_rng_state().clone(),count=0,phase='initialization',record_after=0)
        native=net.analysis_step
        def wrapped(native,net,state):
            def update(y,u):
                previous=net.m1x_posterior
                post=native(y,u); i=state['count']; state['count']+=1
                if state.get('capture_prefix',False) and i<650:
                    state['prefix'].append(post.detach().clone())
                if state['trace'] is not None and i>=state['record_after']:
                    state['trace'].append(dict(prior=net.m1x_prior,posterior=post,previous=previous,
                        requested=net.last_correction,prior_flow=net.m1y.reshape(()),
                        posterior_flow=net.h(post).reshape(()),gain=net.KGain.reshape(-1)))
                return post
            return update
        net.analysis_step=wrapped(native,net,state)
        identities=[]
        for start in [*plan['base_starts'],2557]:
            initial=runtime.context.initial_state.clone() if start==0 else states[start-1].clone()
            previous=None if start==0 else runtime.observations[start-1:start].clone()
            net.initialize_filter(initial,731 if start==2557 else 800,previous_observation=previous)
            identities.append({key:C.helpers.digest_tree(getattr(net,key)) for key in C.probe.RECURRENCE_FIELDS})
        initial_snapshots[arm]=identities
        initial_hashes[arm]=dict(network=C.helpers.digest_tree(net.state_dict()),optimizer=C.helpers.digest_tree(opt.state_dict()),rng=C.helpers.digest_tree(state['rng']))
        arms[arm]=state
    assert initial_hashes['flow_control']==initial_hashes['state_constrained']
    assert initial_snapshots['flow_control']==initial_snapshots['state_constrained']
    head_names=[name for name,p in arms['flow_control']['net'].named_parameters() if any(p is h for h in arms['flow_control']['parameters'])]
    put('initialization_gate.json',dict(status='PASS',basin=basin,checkpoint_epoch=conf['epoch'],hashes=initial_hashes,
        initial_snapshots=initial_snapshots,trainable_tensor_names=head_names,output_row=coordinate,
        trainable_parameter_count=arms['flow_control']['head'].in_features+1))

    def vector(state):
        return np.concatenate([arr(state['head'].weight[coordinate]),arr(state['head'].bias[coordinate:coordinate+1])]).astype(np.float64)
    def install(state,values):
        with torch.no_grad():
            state['head'].weight[coordinate].copy_(torch.as_tensor(values[:-1],dtype=state['head'].weight.dtype))
            state['head'].bias[coordinate].copy_(torch.as_tensor(values[-1],dtype=state['head'].bias.dtype))
    def frozen_check(state):
        for name,value in state['net'].state_dict().items():
            old_value=state['frozen'][name]
            if name in head_names:
                mask=torch.ones(value.shape[0],dtype=torch.bool);mask[coordinate]=False
                assert torch.equal(value[mask],old_value[mask]),'non-target output row changed'
            else: assert torch.equal(value,old_value),'frozen parameter/buffer changed: '+name

    def metric_values(pred,y):
        error=pred-y; result={}
        for label,mask in zip(plan['flow_groups'],groups(y)):
            e=error[mask]; truth=y[mask];den=float(np.sum((truth-truth.mean())**2))
            result[label]=dict(count=int(mask.sum()),mse=float(np.mean(e**2)),mae=float(np.mean(np.abs(e))),
                bias=float(np.mean(e)),nse=None if den==0 else 1-float(np.sum(e**2))/den)
        return result
    def state_mask(trace,start):
        previous=np.stack([arr(r['previous']).reshape(-1) for r in trace])
        prior=np.stack([arr(r['prior']).reshape(-1) for r in trace])
        indices=np.arange(start,start+len(trace))
        if coordinate==0:return (forcing[indices,0,1]>=TT)&(prior[:,0]<=0)
        return ((forcing[indices,0,0]==0)&(previous[:,0]<=0)&(previous[:,1]<=0)&
            (observations[indices]<=thresholds[0])&(observations[indices]<=observations[indices-1]))
    def state_terms(trace,mask,start,state):
        if coordinate==0:
            values=torch.stack([torch.relu((r['posterior']-r['prior'])[0,0]) for r in trace])
            scale=float(state['net'].state_feature_scale[0,0])
        else:
            prior_flow=torch.stack([r['prior_flow'] for r in trace])
            values=torch.relu(prior_flow-torch.as_tensor(observations[start:start+len(trace)],dtype=prior_flow.dtype))
            scale=float(state['net'].observation_feature_scale.reshape(()))
        selected=values[torch.as_tensor(mask,dtype=torch.bool)]
        return (selected/scale).square().sum(), selected.sum(), values

    from repair_body import run_diagnostic
    run_diagnostic(dict(globals(), **locals()))


if __name__=='__main__':
    main()
