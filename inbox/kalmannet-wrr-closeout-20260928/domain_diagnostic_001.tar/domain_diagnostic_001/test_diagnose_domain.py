"""Synthetic tests only; no completed research artifact is opened."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

import numpy as np

import diagnose_domain as diagnostic


HERE = Path(__file__).resolve().parent
BASE_SOURCE = HERE.parent / 'saved_stats_audit_001' / 'audit_saved_statistics.py'
AUDIT_SOURCE = HERE.parent / 'completed_ten_audit_001' / 'audit_completed_ten.py'


def pinned(path, expected, name):
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


BASE = pinned(BASE_SOURCE, diagnostic.BASE_SHA, 'synthetic_base')
AUDIT = pinned(AUDIT_SOURCE, diagnostic.AUDIT_SHA, 'synthetic_audit')


def small_arrays():
    windows, width, leads = 3, 2, 2
    issues = windows + width - 1
    obs = np.arange(1, 6, dtype=np.float32)
    counts = np.array([1, 2, 2, 1])
    y = obs[np.arange(issues)[:, None] + np.arange(leads)].astype(np.float64)
    stats = np.zeros((issues, leads, 8), dtype=np.float64)
    stats[:, :, 0] = counts[:, None]
    stats[:, :, 1] = counts[:, None] * y
    stats[:, :, 2] = counts[:, None] * y * y
    return {'stats': stats, 'observation': obs,
            'issue_hours': np.arange(issues, dtype=np.float64),
            'actual_leads': np.arange(leads, dtype=np.int64)}


class DiagnosticTests(unittest.TestCase):
    def test_rejects_wrong_hash_and_malformed_saved_arrays(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'synthetic.npz'
            arrays = small_arrays()
            np.savez(path, **arrays)
            with self.assertRaisesRegex(ValueError, 'identity mismatch'):
                BASE.saved_arrays(path, '0' * 64, 3, 2, 2, 5)
            expected = diagnostic.sha(path)
            loaded = BASE.saved_arrays(path, expected, 3, 2, 2, 5)
            self.assertEqual(loaded['stats'].shape, (4, 2, 8))
            arrays['stats'] = arrays['stats'][:, :, :7]
            np.savez(path, **arrays)
            with self.assertRaisesRegex(ValueError, 'shape/dtype'):
                BASE.saved_arrays(path, diagnostic.sha(path), 3, 2, 2, 5)

    def test_rejects_wrong_pinned_script_hash_before_import(self):
        with self.assertRaisesRegex(ValueError, 'Pinned script hash mismatch'):
            diagnostic.load_pinned(AUDIT_SOURCE, '0' * 64, 'wrong_audit', HERE.parent)

    def test_forbidden_path_traversal_and_symlink(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            real = root / 'real.txt'
            real.write_text('synthetic', encoding='utf-8')
            self.assertEqual(diagnostic.safe_file(real, root), real)
            with self.assertRaisesRegex(ValueError, 'Forbidden'):
                diagnostic.safe_file(root / 'sub' / '..' / 'real.txt', root)
            with self.assertRaisesRegex(ValueError, 'Forbidden'):
                diagnostic.safe_file(root.parent / 'outside.txt', root)
            link = root / 'link.txt'
            try:
                link.symlink_to(real)
            except (OSError, NotImplementedError):
                return
            with self.assertRaisesRegex(ValueError, 'Symlink'):
                diagnostic.safe_file(link, root)

    def test_exact_domain_discriminates_observation_time_count_and_moment(self):
        arrays = small_arrays()
        stub = types.SimpleNamespace(normalized_domain=lambda a: {
            'issue_hours': a['issue_hours'], 'observation': a['observation'].reshape(-1),
            'actual_leads': a['actual_leads'], 'stats': a['stats'][:, :, :3]})
        for key, index in (('observation', 0), ('issue_hours', 0), ('stats', (0, 0, 0))):
            changed = {name: value.copy() for name, value in arrays.items()}
            changed[key][index] += 1 if key != 'stats' else 1e-12
            result = diagnostic.compare_domain(arrays, changed, stub)
            field = 'n' if key == 'stats' else key
            self.assertFalse(result['exact_same_domain'])
            self.assertEqual(result['fields'][field]['different_cells'], 1)
            self.assertEqual(result['fields'][field]['first_five'][0]['index'],
                             [0, 0] if key == 'stats' else [0])
        changed = {name: value.copy() for name, value in arrays.items()}
        changed['stats'][0, 0, 1] += 1e-12
        result = diagnostic.compare_domain(arrays, changed, stub)
        self.assertFalse(result['exact_same_domain'])
        self.assertGreater(result['fields']['sy']['maximum_absolute'], 0)
        self.assertEqual(result['fields']['sy']['different_cells'], 1)

    def test_shape_mismatch_has_no_broadcast_and_zero_relative_is_finite(self):
        with self.assertRaisesRegex(ValueError, 'Strict shape mismatch'):
            diagnostic.numeric_difference(np.zeros((2, 1)), np.zeros((2,)))
        result = diagnostic.numeric_difference(np.array([0., 0.]), np.array([0., 1.]))
        self.assertEqual(result['maximum_relative'], 1.0)
        self.assertEqual(result['different_cells'], 1)

    def test_reconstruction_reports_per_lead_sums_and_tiny_difference(self):
        arrays = small_arrays()
        result = diagnostic.reconstruct_moments(arrays, 3, 2, 5, 2)
        self.assertTrue(all(result[key]['difference']['exact_equal'] for key in ('n', 'sy', 'sy2')))
        self.assertEqual(len(result['sy']['saved_sum_by_lead']), 2)
        arrays['stats'][0, 0, 2] += 1e-12
        result = diagnostic.reconstruct_moments(arrays, 3, 2, 5, 2)
        self.assertFalse(result['sy2']['difference']['exact_equal'])
        self.assertEqual(result['sy2']['difference']['different_cells'], 1)

    def test_unchanged_seven_metric_arithmetic_and_comparison(self):
        stats = np.zeros((3, 25, 8), dtype=np.float64)
        stats[:] = np.array([3, 6, 14, 7, 19, 16, 2, 1], dtype=np.float64) / 3
        computed = BASE.calculate(stats)
        self.assertEqual(set(computed), set(AUDIT.KEYS))
        self.assertTrue(AUDIT.compare_vectors(computed, computed)['passed'])
        changed = {key: value.copy() for key, value in computed.items()}
        changed['nse'][0] += 1e-5
        self.assertFalse(AUDIT.compare_vectors(computed, changed)['passed'])
        means = AUDIT.scalar_means(computed)
        self.assertEqual(set(means), set(AUDIT.KEYS))

    def test_finite_metrics_with_infinite_relative_diagnostic_are_rejected(self):
        computed = {key: [0.0] for key in AUDIT.KEYS}
        saved = {key: [0.0] for key in AUDIT.KEYS}
        computed['nse'] = [1e308]
        with np.errstate(over='ignore'):
            frozen_result = AUDIT.compare_vectors(computed, saved)
            self.assertTrue(np.isinf(frozen_result['differences']['nse']['maximum_relative']))
            with self.assertRaisesRegex(ValueError, 'Nonfinite.*metric comparison'):
                diagnostic.compare_saved_metrics(computed, saved, AUDIT)

    def test_nonfinite_report_writes_one_complete_failure_json(self):
        with tempfile.TemporaryDirectory() as temp:
            output = diagnostic.exclusive_output(Path(temp) / 'run', Path(temp))
            report = {'state': 'SAVED_DOMAIN_DIAGNOSTIC_COMPLETE_NOT_ACCEPTANCE',
                      'metric_comparison': {'maximum_relative': float('inf')}}
            self.assertFalse(diagnostic.write_result(output, report))
            self.assertEqual([item.name for item in output.iterdir()], ['failure.json'])
            saved = json.loads((output / 'failure.json').read_text(encoding='utf-8'))
            self.assertEqual(saved['state'], 'SAVED_DOMAIN_DIAGNOSTIC_FAILED')
            self.assertIn('Nonfinite', saved['failure']['error'])
            self.assertFalse(saved['accepted'])

    def test_exclusive_output_cannot_overwrite(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            output = root / 'run_001'
            self.assertEqual(diagnostic.exclusive_output(output, root), output)
            with self.assertRaisesRegex(ValueError, 'new direct child'):
                diagnostic.exclusive_output(output, root)
            with self.assertRaisesRegex(ValueError, 'new direct child'):
                diagnostic.exclusive_output(root / 'nested' / 'run', root)

    def test_failed_case_remains_failed_with_diagnostic_error(self):
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / 'synthetic.bin'
            source.write_bytes(b'synthetic')
            binding = {'path': str(source), 'sha256': diagnostic.sha(source)}
            manifest = {'cases': [{'case_id': case_id, 'files': dict.fromkeys(
                ('completion', 'metrics', 'statistics'), binding)}
                for case_id in diagnostic.CASES]}
            arrays = small_arrays()
            stub = types.SimpleNamespace(
                validate_manifest=lambda m, r: None,
                safe_path=lambda p, r: Path(p),
                validate_time=lambda a, g: {'continuous': True},
                normalized_domain=lambda a: {
                    'issue_hours': a['issue_hours'], 'observation': a['observation'].reshape(-1),
                    'actual_leads': a['actual_leads'], 'stats': a['stats'][:, :, :3]},
                compare_vectors=lambda c, s: {'passed': True},
                scalar_means=lambda c: {})
            manifest['geometry'] = {}
            calls = [0]

            def load(*args):
                calls[0] += 1
                if calls[0] == 2:
                    raise ValueError('synthetic malformed array')
                return arrays

            base = types.SimpleNamespace(saved_arrays=load, calculate=lambda s: {'nse': [0.]})
            with patch.object(diagnostic, 'bind_case', return_value=({}, {'metrics': {'nse': [0.]}})), \
                 patch.object(diagnostic, 'reconstruct_moments', return_value={}):
                report = diagnostic.diagnose(manifest, stub, base, Path(temp))
            self.assertEqual(calls[0], 4)
            self.assertEqual(report['state'], 'SAVED_DOMAIN_DIAGNOSTIC_FAILED')
            self.assertIn('synthetic malformed array', report['cases'][diagnostic.CASES[1]]['error'])
            self.assertFalse(report['accepted'])


if __name__ == '__main__':
    unittest.main()
