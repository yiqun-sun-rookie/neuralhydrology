"""Bounded diagnostic of four hash-bound saved domains; grants no acceptance."""
import argparse
import hashlib
import importlib.util
import json
import traceback
from pathlib import Path

import numpy as np


ROOT = Path('/data1/home/sunyiq/kalmannet_wrr_closeout_20260928_v1')
CODE = ROOT / 'domain_diagnostic_001'
AUDIT_ROOT = ROOT / 'completed_ten_audit_001'
MANIFEST = AUDIT_ROOT / 'audit_manifest_001.json'
OUTPUT_ROOT = ROOT / 'domain_diagnostic_output_001'
AUDIT_SHA = 'ba29ec4bc78eadf4554fc8902c160b5019b16e1829b087d6519d5706087b1297'
BASE_SHA = '9c8ab347eb3437b4bcc2f01a5a350a2126209577e77dee3ca796faa309313f34'
CASES = ('main_seed43__original_outlet_original_states',
         'adaptive__original_outlet_original_states',
         'matched_fixed_test', 'matched_selected_test')
FIELDS = ('issue_hours', 'observation', 'actual_leads', 'n', 'sy', 'sy2')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def safe_file(path, root=ROOT):
    """Accept only a real file below root, with no symlink or traversal."""
    path, root = Path(path), Path(root)
    require(path.is_absolute() and root.is_absolute() and '..' not in path.parts
            and path != root and path.is_relative_to(root), 'Forbidden input path')
    for part in (root, *[root.joinpath(*path.relative_to(root).parts[:i])
                          for i in range(1, len(path.relative_to(root).parts) + 1)]):
        require(not part.is_symlink(), 'Symlink input path')
    require(path.is_file() and path.resolve(strict=True).is_relative_to(root.resolve(strict=True)),
            'Missing or escaped input file')
    return path


def exclusive_output(path, root=OUTPUT_ROOT):
    path, root = Path(path), Path(root)
    require(path.is_absolute() and root.is_absolute() and '..' not in path.parts
            and path != root and path.parent == root and not path.exists(),
            'Output must be a new direct child of diagnostic output root')
    require(root.is_dir() and not root.is_symlink() and not path.is_symlink()
            and path.resolve(strict=False).is_relative_to(root.resolve(strict=True)),
            'Unsafe diagnostic output root')
    path.mkdir(exist_ok=False)
    return path


def load_pinned(path, expected, name, root=ROOT):
    path = safe_file(path, root)
    require(sha(path) == expected, 'Pinned script hash mismatch: ' + name)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    require(sha(path) == expected, 'Pinned script changed during import: ' + name)
    return module


def array_description(arrays):
    return {key: {'shape': list(value.shape), 'dtype': str(value.dtype),
                  'all_finite': bool(np.isfinite(value).all())}
            for key, value in sorted(arrays.items())}


def numeric_difference(reference, other):
    """Exact comparison; relative scale is max(abs(both values), 1e-300)."""
    a, b = np.asarray(reference), np.asarray(other)
    require(a.shape == b.shape, 'Strict shape mismatch: ' + str(a.shape) + ' vs ' + str(b.shape))
    require(np.isfinite(a).all() and np.isfinite(b).all(), 'Nonfinite comparison')
    changed = a != b
    delta = np.abs(a.astype(np.float64) - b.astype(np.float64))
    scale = np.maximum(np.maximum(np.abs(a.astype(np.float64)),
                                  np.abs(b.astype(np.float64))), 1e-300)
    require(np.isfinite(delta).all(), 'Nonfinite difference magnitude')
    indices = np.argwhere(changed)[:5]
    return {'exact_equal': bool(not np.any(changed)),
            'different_cells': int(np.count_nonzero(changed)),
            'maximum_absolute': float(np.max(delta, initial=0.0)),
            'maximum_relative': float(np.max(delta / scale, initial=0.0)),
            'first_five': [{'index': index.tolist(),
                            'reference': float(a[tuple(index)]),
                            'other': float(b[tuple(index)])} for index in indices]}


def domain_fields(arrays, audit):
    domain = audit.normalized_domain(arrays)
    require(domain['observation'].shape == (arrays['observation'].size,),
            'Observation normalization shape')
    return {'issue_hours': domain['issue_hours'], 'observation': domain['observation'],
            'actual_leads': domain['actual_leads'],
            **{name: domain['stats'][:, :, i] for i, name in enumerate(('n', 'sy', 'sy2'))}}


def compare_domain(reference, other, audit):
    a, b = domain_fields(reference, audit), domain_fields(other, audit)
    fields = {key: numeric_difference(a[key], b[key]) for key in FIELDS}
    input_equal = all(fields[key]['exact_equal'] for key in
                      ('issue_hours', 'observation', 'actual_leads', 'n'))
    if all(value['exact_equal'] for value in fields.values()):
        interpretation = 'All compared saved-domain fields are exactly equal.'
    elif not input_equal:
        interpretation = ('Saved observation, issue time, lead labels, or integer counts differ; '
                          'moment accumulation rounding alone cannot explain the full mismatch.')
    else:
        interpretation = ('Saved observation, time, lead labels, and counts are equal; '
                          'moment differences are compatible with accumulation rounding or '
                          'different producer arithmetic. The cause is not established.')
    return {'exact_same_domain': all(value['exact_equal'] for value in fields.values()),
            'fields': fields, 'interpretation': interpretation}


def reconstruct_moments(arrays, windows=14981, width=753, observation_hours=15780,
                        expected_leads=25):
    """Independently derive observed moments from the saved observation and window geometry."""
    stats = arrays['stats']
    issues, leads, _ = stats.shape
    observation = arrays['observation'].reshape(-1).astype(np.float64)
    require(issues == windows + width - 1 and leads == expected_leads and
            observation.size == observation_hours, 'Moment geometry mismatch')
    i = np.arange(issues)
    counts = np.minimum.reduce((i + 1, np.full(issues, width),
                                np.full(issues, windows), issues - i))
    y = observation[i[:, None] + np.arange(leads)]
    expected = (np.broadcast_to(counts[:, None], (issues, leads)),
                counts[:, None] * y, counts[:, None] * y * y)
    result = {}
    for j, name in enumerate(('n', 'sy', 'sy2')):
        saved = stats[:, :, j]
        saved_sums = np.sum(saved, axis=0, dtype=np.float64)
        expected_sums = np.sum(expected[j], axis=0, dtype=np.float64)
        delta_sums = np.sum(saved - expected[j], axis=0, dtype=np.float64)
        require(np.isfinite(saved_sums).all() and np.isfinite(expected_sums).all()
                and np.isfinite(delta_sums).all(), 'Nonfinite moment sum')
        result[name] = {
            'difference': numeric_difference(expected[j], saved),
            'saved_sum_by_lead': saved_sums.tolist(),
            'reconstructed_sum_by_lead': expected_sums.tolist(),
            'sum_difference_by_lead': delta_sums.tolist()}
    return result


def compare_saved_metrics(computed, saved, audit):
    result = audit.compare_vectors(computed, saved)
    try:
        json.dumps(result, allow_nan=False)
    except (ValueError, TypeError) as exc:
        raise ValueError('Nonfinite or unsupported metric comparison diagnostic') from exc
    return result


def bind_case(case, manifest, audit, root=ROOT):
    case_id, files = case['case_id'], case['files']
    completion = audit.bound_json(files['completion'], root)
    saved = audit.bound_json(files['metrics'], root)
    require(completion['case_id'] == case_id and
            (case['kind'] != 'matched' or saved['case_id'] == case_id),
            'Case identity mismatch')
    audit.completed_state(completion, case['kind'], case['directory'])
    require(saved['metrics'] == completion['metrics'], 'Metrics and completion differ')
    if case['kind'] == 'original':
        artifacts = {Path(item['path']).name: item for item in completion['artifacts']}
        require(set(artifacts) == {'metrics.json', 'issue_statistics.npz'} and
                artifacts['metrics.json'] == files['metrics'] and
                artifacts['issue_statistics.npz'] == files['statistics'],
                'Original completion artifact binding')
        contract = audit.bound_json(manifest['contract'], root)
        require(completion['manifest_sha256'] == contract['manifest_sha256'] and
                completion['case_fingerprint'] == contract['cases'][case_id]['case_fingerprint'] and
                completion['input_fingerprints'] == contract['input_fingerprints'],
                'Original completion frozen contract binding')
    else:
        selection = audit.bound_json(manifest['selection'], root)
        contract = audit.bound_json(manifest['contract'], root)
        require(selection['state'] == 'ADAPTIVE_VALIDATION_SELECTION_FROZEN' and
                selection['selected_delta_r'] == 0.01 and
                selection['protocol_sha256'] == manifest['protocol_sha256'] and
                selection['test_data_read'] is False, 'Frozen selection mismatch')
        require(completion['split'] == 'test' and
                completion['statistics_sha256'] == files['statistics']['sha256'] and
                completion['metrics_sha256'] == files['metrics']['sha256'] and
                completion['selection_sha256'] == manifest['selection']['sha256'] and
                completion['selection_path'] == manifest['selection']['path'] and
                completion['protocol_sha256'] == manifest['protocol_sha256'],
                'Matched completion binding')
        require({key: item['sha256'] for key, item in
                 completion['input_fingerprints'].items()} == contract['input_fingerprints'],
                'Matched frozen input fingerprints')
    return completion, saved


def diagnose(manifest, audit, base, root=ROOT):
    audit.validate_manifest(manifest, root)
    cases = {case['case_id']: case for case in manifest['cases']}
    require(set(CASES).issubset(cases), 'Diagnostic case missing')
    report = {'state': 'SAVED_DOMAIN_DIAGNOSTIC_FAILED', 'accepted': False,
              'admission_written': False, 'model_calls': 0, 'raw_tensor_reads': 0,
              'source_manifest_sha256': None, 'cases': {}, 'comparisons': {},
              'relative_difference_rule': 'abs(a-b)/max(abs(a),abs(b),1e-300); equal zeros yield 0',
              'limitations': 'Diagnostic arithmetic only; historical, grouped, selection and scientific acceptance were not checked.'}
    loaded = {}
    for case_id in CASES:
        case = cases[case_id]
        files = case['files']
        entry = {'status': 'FAILED', 'source_hashes': {key: files[key]['sha256']
                                                     for key in ('completion', 'metrics', 'statistics')}}
        report['cases'][case_id] = entry
        try:
            completion, saved = bind_case(case, manifest, audit, root)
            path = audit.safe_path(files['statistics']['path'], root)
            arrays = base.saved_arrays(path, files['statistics']['sha256'], 14981, 753, 25, 15780)
            entry['array_description'] = array_description(arrays)
            entry['time'] = audit.validate_time(arrays, manifest['geometry'])
            entry['source_hashes_after_read'] = {key: sha(audit.safe_path(files[key]['path'], root))
                                                 for key in ('completion', 'metrics', 'statistics')}
            require(entry['source_hashes_after_read'] == entry['source_hashes'],
                    'Case sources changed after read')
            entry['reconstructed_observation_moments'] = reconstruct_moments(arrays)
            computed = base.calculate(arrays['stats'])
            metric_comparison = compare_saved_metrics(computed, saved['metrics'], audit)
            entry['computed_metrics'] = computed
            entry['saved_metrics'] = saved['metrics']
            entry['metric_comparison'] = metric_comparison
            entry['means'] = audit.scalar_means(computed)
            entry['status'] = 'SAVED_ARRAYS_AND_ARITHMETIC_COMPLETE'
            loaded[case_id] = arrays
        except Exception as exc:
            entry['error'] = repr(exc)
    reference = loaded.get(CASES[0])
    if reference is not None:
        for case_id in CASES:
            if case_id in loaded:
                report['comparisons'][CASES[0] + '__versus__' + case_id] = compare_domain(
                    reference, loaded[case_id], audit)
    if CASES[2] in loaded and CASES[3] in loaded:
        report['comparisons'][CASES[2] + '__versus__' + CASES[3]] = compare_domain(
            loaded[CASES[2]], loaded[CASES[3]], audit)
    report['cross_case_exact_domain'] = (len(loaded) == 4 and
        all(item['exact_same_domain'] for item in report['comparisons'].values()))
    if len(loaded) == 4 and all(report['cases'][key]['status'] ==
                                'SAVED_ARRAYS_AND_ARITHMETIC_COMPLETE' for key in CASES):
        report['state'] = 'SAVED_DOMAIN_DIAGNOSTIC_COMPLETE_NOT_ACCEPTANCE'
    return report


def write_result(output, report):
    """Serialize completely before exclusive creation of the sole result file."""
    success = report['state'] == 'SAVED_DOMAIN_DIAGNOSTIC_COMPLETE_NOT_ACCEPTANCE'
    try:
        content = json.dumps(report, indent=2, allow_nan=False)
    except (ValueError, TypeError) as exc:
        success = False
        fallback = {'state': 'SAVED_DOMAIN_DIAGNOSTIC_FAILED', 'accepted': False,
                    'admission_written': False, 'model_calls': 0, 'raw_tensor_reads': 0,
                    'failure': {'error': 'Nonfinite or unsupported diagnostic JSON value',
                                'detail': repr(exc)}}
        content = json.dumps(fallback, indent=2, allow_nan=False)
    filename = 'diagnostic.json' if success else 'failure.json'
    with (output / filename).open('x', encoding='utf-8') as stream:
        stream.write(content)
    return success


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    output = exclusive_output(args.output)
    report = {'state': 'SAVED_DOMAIN_DIAGNOSTIC_FAILED', 'accepted': False,
              'admission_written': False, 'model_calls': 0, 'raw_tensor_reads': 0}
    try:
        require(args.manifest == MANIFEST, 'Manifest must be exact deployed audit path')
        audit = load_pinned(CODE / 'audit_completed_ten.py', AUDIT_SHA, 'audit_completed_ten')
        base = load_pinned(CODE / 'audit_saved_statistics.py', BASE_SHA, 'audit_saved_statistics')
        manifest = audit.bound_json({'path': str(audit.safe_path(args.manifest, ROOT)),
                                     'sha256': args.manifest_sha256}, ROOT)
        require(args.manifest_sha256 ==
                'd20262c7638f6d69764f4dce7475879b1d43b83dc7ed1d6f9e8f6f78a557d22a',
                'Frozen manifest hash mismatch')
        report = diagnose(manifest, audit, base)
        report['source_manifest_sha256'] = args.manifest_sha256
        if not write_result(output, report):
            raise SystemExit(1)
        print(report['state'])
    except SystemExit:
        raise
    except Exception as exc:
        report['state'] = 'SAVED_DOMAIN_DIAGNOSTIC_FAILED'
        report['failure'] = {'error': repr(exc), 'traceback': traceback.format_exc()}
        write_result(output, report)
        raise SystemExit(1) from exc


if __name__ == '__main__':
    main()
