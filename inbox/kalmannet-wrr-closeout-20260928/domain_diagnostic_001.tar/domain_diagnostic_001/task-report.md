# 保存统计量计算范围诊断：实现报告

## 结论

状态：DONE_WITH_CONCERNS。只完成了本地诊断程序和合成测试；尚未在计算节点读取四份研究用保存数组，也没有提交调度任务。因此，目前无法确定实际是哪一个字段不同。原独立审计仍为 `REJECTED_INCOMPLETE`，本任务不改变该状态。

## 范围和证据

- 唯一新增的执行文件为 `diagnose_domain.py`、`test_diagnose_domain.py` 和 `diagnose_domain.slurm`；另外新增本报告及 `review.patch`。未改动原审计、原统计助手、清单、模型、协议或论文。
- 原审计报告的失败异常为 `ValueError('Completed case first-three statistics differ')`。原 `same_domain` 函数实际上同时检查问题时间、观测向量、预报时长标签和前三个统计量。因此异常文字不能单独证明哪个字段不同；本程序会逐字段记录。
- 程序只从已绑定哈希的审计清单选取四个指定案例，每例读取完成记录、指标记录和一份压缩保存数组；冻结合同及选择记录仅作为小型、已绑定哈希的身份验证输入。压缩保存数组由冻结助手 `saved_arrays` 读取，时间和七项指标分别由冻结审计 `validate_time`、冻结助手 `calculate`、冻结审计 `compare_vectors` 验证。
- 对每个比较字段记录逐位相等结果、不同单元数、最大绝对差、最大相对差及前五个差异的索引和值。相对差定义为 `abs(a-b)/max(abs(a),abs(b),1e-300)`；两边均为零时结果为零。形状不一致直接报错，绝不隐式广播。观测向量与单列仅按冻结审计的 `normalized_domain` 规范化。
- 独立地按观测值和整数窗口重建计数、观测一次矩、观测二次矩，记录逐单元差异以及每个预报时长的保存总和、重建总和和差值。若观测、时间、标签或计数有差异，不会把差异归因于舍入；若这些字段相同而矩不同，只说明与累积顺序舍入或生成端算术差异相容，根因仍未证实。
- 只有四例数组读取和算术全部完成，输出状态才为 `SAVED_DOMAIN_DIAGNOSTIC_COMPLETE_NOT_ACCEPTANCE`；逐位比较为假仍明确保留为假。读数或算术失败时写独占目录中的 `failure.json` 并返回非零。两个状态都标记 `accepted=false`、`admission_written=false`、`model_calls=0`、`raw_tensor_reads=0`。

## 本地验证

执行命令：

`C:\Users\yiqun\anaconda3\envs\knet_clean\python.exe -B -m unittest -v test_diagnose_domain.py`

结果：9 项合成测试全部通过。覆盖错误脚本或数组哈希、路径越界与符号链接、数组形状错误、观测／时间／计数／矩差异、极小但仍逐位不同的矩、七项冻结指标算术、失败案例保留和输出目录不可覆盖。测试没有打开四份真实研究数组。

冻结的本地输入哈希已在实现前核对：原审计 `ba29ec4bc78eadf4554fc8902c160b5019b16e1829b087d6519d5706087b1297`；审计清单 `d20262c7638f6d69764f4dce7475879b1d43b83dc7ed1d6f9e8f6f78a557d22a`；统计助手 `9c8ab347eb3437b4bcc2f01a5a350a2126209577e77dee3ca796faa309313f34`。

## 待控制端处理

控制端须在新计算节点代码目录中放置哈希固定的原审计脚本、统计助手和 `package_files.sha256`，并独立审查本任务后再决定是否部署。启动文件只规定四个中央处理器核心、十分钟、无图形处理器、无重排队及执行前后包哈希检查；本任务未运行该启动文件、未访问远程计算机、未提交任务。

## 本任务最终内容哈希（SHA-256）

| 文件 | SHA-256 |
| --- | --- |
| `diagnose_domain.py` | `e1b3e7c9b1c536ab0ffffa1b5d88c641c5752d079f8326ba2ebdf8f994f4649e` |
| `test_diagnose_domain.py` | `e26ee1100452bc0119d57039eaba3040dc36159be00019c67ed7331a7a0e81e8` |
| `diagnose_domain.slurm` | `726e60eeaa451dea104f2267c591c12fd832ecc4356d21c1444b63e6de702ed0` |

本报告和包含本报告的新文件补丁不能在自身内容里记录自身的最终哈希；交接时另外提供这两个文件的实际哈希。

## 独立复核后的第一轮定点修复

独立复核指出：冻结指标比较函数对有限的计算值 `1e308` 和保存值 `0`，会给出无穷大的最大相对差。原实现先打开 `diagnostic.json` 再序列化，可能使该文件及随后尝试写的 `failure.json` 都不完整。已仅修改本目录的诊断程序和合成测试；冻结函数、比较阈值、原审计和逐位相等条件均未改变。

现在每例先验证冻结指标比较结果能否写成严格的 JSON。若出现无穷大或不支持的数值，该例记录明确错误，整体诊断失败。最终报告也在打开文件前完整序列化；若仍含不能序列化的值，只写一份包含明确错误说明的有效 `failure.json`，返回非零，不会先创建不完整的 `diagnostic.json`。

复测命令仍为 `C:\Users\yiqun\anaconda3\envs\knet_clean\python.exe -B -m unittest -v test_diagnose_domain.py`；结果为 11 项合成测试全部通过。新增测试直接调用冻结比较函数，确认有限输入可产生无穷大的相对差，并验证诊断程序拒绝该值；另验证最终仅生成可解析且标记失败的 `failure.json`。未读取真实研究数组、未运行模型、未提交调度任务。

上方哈希表属于初次交付快照。第一轮修复后的当前文件哈希（SHA-256）为：

| 文件 | SHA-256 |
| --- | --- |
| `diagnose_domain.py` | `16c955789390df64d7936cf54cbb2af7ed27eb9bbb791b7f2c35606b4a7ad1e5` |
| `test_diagnose_domain.py` | `163ee501abe78da1d821aff3e0240b1caa2b1ff881dc9cf3391aeee40d4a10be` |
| `diagnose_domain.slurm`（未改） | `726e60eeaa451dea104f2267c591c12fd832ecc4356d21c1444b63e6de702ed0` |

初次交付的 `review.patch` 保持原样；第一轮修复相对 `repair_001_before` 的差异单独保存在 `repair_review_001.patch`。这两个补丁都不代表远程部署或研究结果验收。
