"""Read-only independent audit of ten completed saved-statistics cases."""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import traceback

import numpy as np


REMOTE = PurePosixPath('/data1/home/sunyiq/kalmannet_wrr_closeout_20260928_v1')
CONTRACT_SHA = 'ebe69b0c5be9e12c4882dca6142152df458ae35c329be2d3af6c98039003b055'
BASE_SHA = '9c8ab347eb3437b4bcc2f01a5a350a2126209577e77dee3ca796faa309313f34'
ORIGINAL = tuple(x + '__original_outlet_original_states' for x in
                 ('main_seed43', 'main_seed44', 'compact_seed42', 'compact_seed43',
                  'compact_seed44', 'learned_noise', 'hand_tuned', 'adaptive'))
MATCHED = ('matched_fixed_test', 'matched_selected_test')
FAILED = 'main_seed42__original_outlet_original_states'
KEYS = ('nse', 'rmse', 'mae', 'kge', 'correlation', 'variability_ratio', 'bias_ratio')
ERROR_KEYS = ('rmse', 'mae')
CONVERSION = 957000 / 3600


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def safe_path(value, root, *, file=True):
    root = Path(root)
    path = Path(value)
    require(root.is_absolute() and path.is_absolute() and '..' not in path.parts and
            path != root and path.is_relative_to(root), 'Path escapes root')
    require(not root.is_symlink() and
            path.resolve(strict=False).is_relative_to(root.resolve(strict=False)),
            'Resolved path escapes root or root is a symlink')
    for component in (root, *[root.joinpath(*path.relative_to(root).parts[:i])
                              for i in range(1, len(path.relative_to(root).parts) + 1)]):
        require(not component.is_symlink(), 'Symlink refused: ' + str(component))
    if file:
        require(path.is_file(), 'Required file absent: ' + str(path))
    return path


def bound_json(binding, root):
    path = safe_path(binding['path'], root)
    require(sha(path) == binding['sha256'], 'Content hash mismatch: ' + str(path))
    result = json.loads(path.read_text(encoding='utf-8-sig'))
    require(sha(path) == binding['sha256'], 'JSON changed during read: ' + str(path))
    return result


def load_base(path, expected):
    require(sha(path) == expected, 'Base statistics script hash mismatch')
    spec = importlib.util.spec_from_file_location('audit_saved_statistics', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    require(sha(path) == expected, 'Base statistics script changed during import')
    return module


def completed_state(completion, kind, directory):
    require(not (Path(directory) / 'failure.json').exists(), 'Completed case has failure marker')
    expected = ('PLAIN_EVALUATION_COMPLETE' if kind == 'original' else
                'ADAPTIVE_FULL_EVALUATION_COMPLETE_PENDING_SCIENTIFIC_REVIEW')
    require(completion.get('state') == expected, 'Completion state')


def check_output_target(output, root):
    output, root = Path(output), Path(root)
    require(root.is_absolute() and output.is_absolute() and '..' not in output.parts and
            output.is_relative_to(root) and output != root and
            not output.exists() and not output.is_symlink() and not root.is_symlink() and
            output.resolve(strict=False).is_relative_to(root.resolve(strict=False)),
            'Output must be a new exclusive child of root')
    if output.parent != root:
        safe_path(output.parent, root, file=False)
    require(output.parent.is_dir(), 'Output parent absent')
    return output


def expected_directory(root, case_id, kind):
    root = PurePosixPath(root)
    if kind == 'original':
        return root / 'plain_preflight_v1/numerical_impact/runs' / (case_id + '__formal_attempt01')
    return root / 'adaptive_preflight_v1/adaptive_comparison/runs' / (case_id + '__formal_attempt01')


def validate_manifest(manifest, root=REMOTE):
    root = PurePosixPath(root)
    require(manifest.get('schema') == 'completed_ten_saved_statistics_audit_v1', 'Manifest schema')
    require(manifest.get('remote_root') == str(root), 'Remote root changed')
    require(manifest['contract']['sha256'] == CONTRACT_SHA, 'Frozen contract binding changed')
    require(manifest['contract']['path'] == str(root / 'completed_ten_audit_001/expected_formal_contract_001.json')
            and manifest['base_script_sha256'] == BASE_SHA, 'Frozen code/contract path changed')
    require(manifest['selection'] == {'path': str(root / 'adaptive_preflight_v1/adaptive_comparison/selection_attempt01/selection_frozen.json'),
                                      'sha256': '0a7dfba0af56c56b594e631769c940d808798c3596ade52b0e895fd8604f0151'},
            'Frozen selection binding changed')
    require(manifest['protocol_sha256'] == '131182e1e579fb08ea78813c018f552462a77cf57591973d175d0b3d215ce534',
            'Frozen protocol binding changed')
    require(manifest['geometry'] == dict(windows=14981, width=753, leads=25,
                                         issue_hours=15733, observation_hours=15780,
                                         first_hour=343622.0, last_observation_hour=359401.0),
            'Frozen geometry changed')
    require(len(manifest['cases']) == 10 and
            {c['case_id'] for c in manifest['cases']} == set(ORIGINAL + MATCHED), 'Missing/extra/duplicate case')
    directories = []
    for case in manifest['cases']:
        kind = 'original' if case['case_id'] in ORIGINAL else 'matched'
        require(case['kind'] == kind, 'Case kind changed')
        directory = expected_directory(root, case['case_id'], kind)
        require(case['directory'] == str(directory), 'Case directory mismatch')
        directories.append(directory)
        names = {'completion', 'metrics', 'statistics'}
        if kind == 'original':
            names |= {'historical_reproduction', 'archived_metrics'}
            if case['case_id'] != 'adaptive__original_outlet_original_states':
                names.add('archived_statistics')
        require(set(case['files']) == names, 'Case file set changed')
        for key, filename in (('completion', 'completion.json'), ('metrics', 'metrics.json'),
                              ('statistics', 'issue_statistics.npz'),
                              ('historical_reproduction', 'historical_reproduction.json')):
            if key in case['files']:
                require(case['files'][key]['path'] == str(directory / filename), 'File path mismatch')
        for binding in case['files'].values():
            require(len(binding['sha256']) == 64 and
                    all(ch in '0123456789abcdef' for ch in binding['sha256']), 'Invalid hash')
            require(PurePosixPath(binding['path']).is_relative_to(root), 'File path escapes root')
    require(len(set(directories)) == 10, 'Shared case directory')
    failure = manifest['failed_original']
    expected_failed = expected_directory(root, FAILED, 'original')
    require(failure['case_id'] == FAILED and failure['directory'] == str(expected_failed)
            and failure['failure']['path'] == str(expected_failed / 'failure.json')
            and failure['completion_path'] == str(expected_failed / 'completion.json'),
            'Failed ninth case changed')
    require(expected_failed not in directories, 'Failed case was marked completed')
    return True


def compare_vectors(actual, expected, *, units=None, atol=1e-10, rtol=1e-10):
    require(set(actual) == set(expected) == set(KEYS), 'Metric key mismatch')
    differences = {}
    ok = True
    for key in KEYS:
        a, b = np.asarray(actual[key], dtype=float), np.asarray(expected[key], dtype=float)
        require(a.shape == b.shape and a.ndim == 1 and a.size > 0 and
                np.isfinite(a).all() and np.isfinite(b).all(), 'Metric vector shape/domain')
        if units == 'm3/s' and key in ERROR_KEYS:
            a = a * CONVERSION
        delta = np.abs(a - b)
        threshold = atol + rtol * np.abs(b)
        ok &= bool(np.all(delta <= threshold))
        differences[key] = {'maximum_absolute': float(delta.max()),
                            'maximum_relative': float(np.max(delta / np.maximum(np.abs(b), 1e-300))),
                            'passed': bool(np.all(delta <= threshold))}
    return {'passed': bool(ok), 'differences': differences}


def validate_time(arrays, geometry):
    hours = arrays['issue_hours']
    first = geometry['first_hour']
    require(hours[0] == first and hours[-1] == first + geometry['issue_hours'] - 1,
            'Frozen issue time range mismatch')
    require(np.array_equal(hours, first + np.arange(geometry['issue_hours'])),
            'Issue hours shifted or gapped')
    require(first + geometry['observation_hours'] - 1 == geometry['last_observation_hour'],
            'Frozen observation range mismatch')
    return {'first_issue_hour': float(hours[0]), 'last_issue_hour': float(hours[-1]),
            'last_observation_hour': geometry['last_observation_hour'], 'continuous': True,
            'observation_shape': list(arrays['observation'].shape)}


def normalized_domain(arrays):
    """The two saved producers may serialize observations as a vector or column."""
    return {'issue_hours': arrays['issue_hours'],
            'observation': arrays['observation'].reshape(-1),
            'actual_leads': arrays['actual_leads'],
            'stats': arrays['stats'][:, :, :3]}


def json_number(value):
    value = float(value)
    if math.isnan(value):
        return 'NaN'
    if math.isinf(value):
        return '+Infinity' if value > 0 else '-Infinity'
    return value


def grouped_check(arrays, grouping, saved, base):
    require(len(grouping) == len(saved) == 24, 'Grouped lead count')
    stats, observation = arrays['stats'], arrays['observation'].reshape(-1)
    count_max = 0
    metric_max = 0.0
    details = []
    violations = []
    for j, (frozen, recorded) in enumerate(zip(grouping, saved), start=1):
        if frozen['lead_hours'] != recorded['lead_hours'] or frozen['lead_hours'] != j:
            violations.append({'lead': j, 'check': 'lead_label',
                               'frozen': frozen['lead_hours'], 'saved': recorded['lead_hours']})
        if frozen['q25_mmh'] != recorded['q25_mmh'] or frozen['q75_mmh'] != recorded['q75_mmh']:
            violations.append({'lead': j, 'check': 'group_boundaries',
                               'frozen': [frozen['q25_mmh'], frozen['q75_mmh']],
                               'saved': [recorded['q25_mmh'], recorded['q75_mmh']]})
        observed = observation[np.arange(stats.shape[0]) + j]
        q25, q75 = frozen['q25_mmh'], frozen['q75_mmh']
        masks = {'low': observed < q25,
                 'mid': (observed >= q25) & (observed <= q75),
                 'high': observed > q75}
        require(sum(int(mask.sum()) for mask in masks.values()) == len(observed),
                'Group masks do not partition issues')
        for label, mask in masks.items():
            n = int(np.sum(stats[mask, j, 0], dtype=np.int64))
            expected_n = frozen['counts'][label]
            count_max = max(count_max, abs(n - expected_n), abs(n - recorded['groups'][label]['count']))
            totals = np.sum(stats[mask, j, :], axis=0, dtype=np.float64).reshape(1, 1, 8)
            computed = base.calculate(totals)
            comparison = compare_vectors(computed, {k: [v] for k, v in
                                   recorded['groups'][label]['metrics'].items()})
            metric_max = max(metric_max, *(v['maximum_absolute'] for v in comparison['differences'].values()))
            scale = {k: [recorded['groups'][label][k + '_m3s']] for k in ERROR_KEYS}
            for key in ERROR_KEYS:
                calculated_unit = computed[key][0] * CONVERSION
                saved_unit = scale[key][0]
                delta = abs(calculated_unit - saved_unit)
                if math.isfinite(calculated_unit) and math.isfinite(saved_unit) and math.isfinite(delta):
                    metric_max = max(metric_max, delta)
                if (not math.isfinite(calculated_unit) or not math.isfinite(saved_unit) or
                        not math.isfinite(delta) or not delta <= 1e-10 + 1e-10 * abs(saved_unit)):
                    violations.append({'lead': j, 'group': label, 'check': key + '_m3s',
                                       'calculated': json_number(calculated_unit),
                                       'saved': json_number(saved_unit),
                                       'absolute_difference': json_number(delta)})
            if n != expected_n or n != recorded['groups'][label]['count']:
                violations.append({'lead': j, 'group': label, 'check': 'count',
                                   'calculated': n, 'frozen': expected_n,
                                   'saved': recorded['groups'][label]['count']})
            if not comparison['passed']:
                violations.append({'lead': j, 'group': label, 'check': 'metrics',
                                   'differences': comparison['differences']})
            details.append({'lead': j, 'group': label, 'count': n,
                            'metric_differences': comparison['differences']})
    return {'passed': not violations, 'groups_checked': len(details),
            'maximum_count_difference': count_max,
            'maximum_metric_absolute_difference': metric_max,
            'violations': violations, 'details': details}


def scalar_means(metrics):
    return {key: {span: float(np.mean(metrics[key][a:b])) for span, a, b in
                  (('future_1_12', 1, 13), ('future_13_24', 13, 25))} for key in KEYS}


def physical_errors(metrics, saved):
    differences = {}
    for key in ERROR_KEYS:
        recorded = np.asarray(saved[key + '_m3s'], dtype=float)
        calculated = np.asarray(metrics[key], dtype=float) * CONVERSION
        require(recorded.shape == calculated.shape == (25,) and np.isfinite(recorded).all(),
                'Physical error vector shape/domain')
        delta = np.abs(calculated - recorded)
        passed = bool(np.all(delta <= 1e-10 + 1e-10*np.abs(recorded)))
        differences[key] = {'maximum_absolute_m3s': float(delta.max()), 'passed': passed}
    return {'passed': all(row['passed'] for row in differences.values()), 'differences': differences}


def historical_bridge(current, historical, historical_error_units):
    require(historical_error_units in ('mm/hour', 'm3/s'), 'Unknown historical error units')
    require(set(current) == set(historical) == set(KEYS), 'Historical metric keys')
    details = {}
    for key in KEYS:
        a, b = np.asarray(current[key], dtype=float), np.asarray(historical[key], dtype=float)
        require(a.shape == b.shape == (25,) and np.isfinite(a).all() and np.isfinite(b).all(),
                'Historical metric domain')
        if key in ERROR_KEYS:
            a = a * CONVERSION
            if historical_error_units == 'mm/hour':
                b = b * CONVERSION
            limit = 1e-4
            unit = 'm3/s'
        else:
            limit = 1e-6
            unit = 'dimensionless'
        delta = np.abs(a - b)
        details[key] = {'maximum_absolute': float(np.max(delta)),
                        'future_1_12_mean_absolute': float(abs(np.mean(a[1:13]) - np.mean(b[1:13]))),
                        'future_13_24_mean_absolute': float(abs(np.mean(a[13:25]) - np.mean(b[13:25]))),
                        'limit': limit, 'unit': unit, 'passed': bool(np.all(delta <= limit))}
    return {'passed': all(row['passed'] for row in details.values()), 'differences': details}


def initial_report():
    return {'state': 'REJECTED_INCOMPLETE', 'accepted': False, 'cases': {},
            'failed_ninth_original': {'case_id': FAILED, 'status': 'NOT_YET_CHECKED'},
            'array_reads': 0, 'array_read_attempts': 0,
            'historical_limits': {'dimensionless_absolute': 1e-6,
                                  'error_absolute_m3s': 1e-4},
            'training_calls': 0, 'model_calls': 0, 'raw_tensor_reads': 0,
            'checkpoints_opened': 0, 'acceptance_written': False}


def record_check(entry, name, result, message):
    entry[name] = result
    require(result['passed'], message)


def write_failure(output, report, exc):
    report['state'] = 'REJECTED_INCOMPLETE'
    report['accepted'] = False
    report['failure'] = {'error': repr(exc), 'traceback': traceback.format_exc()}
    with (Path(output) / 'failure.json').open('x', encoding='utf-8') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)


def audit(manifest, base, root=REMOTE, progress=None):
    progress = initial_report() if progress is None else progress
    validate_manifest(manifest, root)
    contract = bound_json(manifest['contract'], root)
    require(contract['schema'] == 'plain_original_formal_audit_contract_v1'
            and len(contract['grouping']) == 24, 'Frozen contract schema/grouping')
    require(contract['geometry']['n_windows'] == 14981 and
            contract['geometry']['n_issue_hours'] == 15733 and
            contract['geometry']['issues_per_window'] == 753 and
            contract['geometry']['actual_leads'] == list(range(25)), 'Contract geometry')
    frozen_hours = contract['cases']['adaptive__original_outlet_original_states']['case'][
        'historical_reference']['frozen_missing_array_domain']
    require(frozen_hours == {'first_hour': manifest['geometry']['first_hour'],
                             'last_hour': manifest['geometry']['last_observation_hour']},
            'Frozen time anchor mismatch')
    failed = manifest['failed_original']
    failure = bound_json(failed['failure'], root)
    require(failure['case_id'] == FAILED and failure['stage'] == 'formal', 'Failure receipt identity')
    require(not Path(failed['completion_path']).exists(), 'Failed ninth original now has completion')
    progress['failed_ninth_original'] = {'case_id': FAILED, 'failure': failed['failure'],
                                         'completion_absent': True, 'status': 'FAILED_PRESERVED'}
    reference = None
    results = progress['cases']
    selection = bound_json(manifest['selection'], root)
    require(selection['state'] == 'ADAPTIVE_VALIDATION_SELECTION_FROZEN' and
            selection['selected_delta_r'] == 0.01 and
            selection['protocol_sha256'] == manifest['protocol_sha256'] and
            selection['test_data_read'] is False, 'Frozen matched selection')
    matched_declarations = None
    for case in manifest['cases']:
        case_id, kind, files = case['case_id'], case['kind'], case['files']
        entry = {'kind': kind, 'files': files, 'status': 'INCOMPLETE', 'saved_array_reads': 0}
        results[case_id] = entry
        completion = bound_json(files['completion'], root)
        saved = bound_json(files['metrics'], root)
        require(completion['case_id'] == case_id, 'Completion case identity')
        completed_state(completion, kind, case['directory'])
        if kind == 'original':
            artifacts = {Path(x['path']).name: x for x in completion['artifacts']}
            require(set(artifacts) == {'metrics.json', 'issue_statistics.npz'} and
                    all(artifacts[name]['path'] == files[key]['path'] and
                        artifacts[name]['sha256'] == files[key]['sha256'] for name, key in
                        (('metrics.json', 'metrics'), ('issue_statistics.npz', 'statistics'))),
                    'Completion artifact binding')
            require(completion['manifest_sha256'] == contract['manifest_sha256'] and
                    completion['case_fingerprint'] == contract['cases'][case_id]['case_fingerprint'] and
                    completion['input_fingerprints'] == contract['input_fingerprints'],
                    'Original protocol/case fingerprint mismatch')
            frozen = contract['cases'][case_id]['case']['historical_reference']
            require(files['archived_metrics'] == {'path': frozen['metrics_path'],
                                                  'sha256': frozen['metrics_sha256']},
                    'Frozen archived metrics binding changed')
            if 'archived_statistics' in files:
                require(files['archived_statistics'] == {'path': frozen['statistics_path'],
                                                         'sha256': frozen['statistics_sha256']},
                        'Frozen archived statistics binding changed')
        else:
            require(completion['split'] == 'test' and
                    completion['statistics_sha256'] == files['statistics']['sha256'] and
                    completion['metrics_sha256'] == files['metrics']['sha256'] and
                    completion['selection_sha256'] == manifest['selection']['sha256'] and
                    completion['selection_path'] == manifest['selection']['path'] and
                    completion['protocol_sha256'] == manifest['protocol_sha256'],
                    'Matched selection/protocol/artifact binding')
            require({key: value['sha256'] for key, value in completion['input_fingerprints'].items()} ==
                    contract['input_fingerprints'], 'Matched frozen input fingerprint mismatch')
        progress['array_read_attempts'] += 1
        arrays = base.saved_arrays(files['statistics']['path'], files['statistics']['sha256'],
                                   14981, 753, 25, 15780)
        progress['array_reads'] += 1
        entry['saved_array_reads'] += 1
        time = validate_time(arrays, manifest['geometry'])
        entry['time'] = time
        domain = normalized_domain(arrays)
        if reference is None:
            reference = {k: value.copy() for k, value in domain.items()}
        require(base.same_domain(reference, domain), 'Completed case first-three statistics differ')
        computed = base.calculate(arrays['stats'])
        require(saved['metrics'] == completion['metrics'] and
                (kind == 'original' or saved['case_id'] == case_id), 'Saved metrics/completion mismatch')
        metric_check = compare_vectors(computed, saved['metrics'])
        record_check(entry, 'metric_check', metric_check, 'Saved metric arithmetic mismatch')
        means = scalar_means(computed)
        entry['means'] = means
        recorded_mean = (completion['mean_future_1_12_nse'] if kind == 'matched'
                         else float(np.mean(completion['metrics']['nse'][1:13])))
        entry['future_1_12_mean_absolute_difference'] = abs(means['nse']['future_1_12'] - recorded_mean)
        require(entry['future_1_12_mean_absolute_difference'] <= 1e-10,
                'Future 1-12 mean mismatch')
        if kind == 'original':
            record_check(entry, 'physical_error_conversion', physical_errors(computed, saved),
                         'Physical error-unit mismatch')
            historical_receipt = bound_json(files['historical_reproduction'], root)
            require(historical_receipt == completion['historical_reproduction'] and
                    historical_receipt['passed'] is True, 'Historical receipt mismatch')
            record_check(entry, 'grouped', grouped_check(arrays, contract['grouping'],
                         saved['grouped_metrics'], base), 'Grouped boundary/count/metric mismatch')
            archived_json = bound_json(files['archived_metrics'], root)
            frozen = contract['cases'][case_id]['case']['historical_reference']
            old_metrics = archived_json
            for key in frozen['metric_keys']:
                old_metrics = old_metrics[key]
            frozen_check = compare_vectors(old_metrics, contract['cases'][case_id]['historical_metrics'])
            record_check(entry, 'historical_json_contract', frozen_check,
                         'Historical JSON differs from frozen contract')
            if 'archived_statistics' in files:
                progress['array_read_attempts'] += 1
                old = base.saved_arrays(files['archived_statistics']['path'],
                                        files['archived_statistics']['sha256'], 14981, 753, 25, 15780)
                progress['array_reads'] += 1
                entry['saved_array_reads'] += 1
                validate_time(old, manifest['geometry'])
                require(base.same_domain(normalized_domain(old), domain),
                        'Archived exact observation/time/count domain differs')
                archived_arithmetic = compare_vectors(base.calculate(old['stats']), old_metrics)
                entry['archived_statistics'] = {'exact_domain': True,
                                                'arithmetic': archived_arithmetic}
                require(archived_arithmetic['passed'], 'Archived statistics arithmetic mismatch')
                del old
            else:
                require(case_id == 'adaptive__original_outlet_original_states' and
                        frozen['frozen_missing_array_domain'] == frozen_hours,
                        'Adaptive missing-array domain changed')
                entry['archived_statistics'] = {'available': False,
                                                'limitation': 'Historical adaptive saved arrays unavailable; time range and historical JSON only'}
            bridge = historical_bridge(computed, old_metrics, frozen['error_units'])
            record_check(entry, 'historical_bridge', bridge, 'Frozen historical bridge failed')
        else:
            expected_rate = 0.0 if case_id == MATCHED[0] else 0.01
            require(completion['delta_r'] == expected_rate and saved['delta_r'] == expected_rate and
                    completion['effective_config']['delta_r'] == expected_rate,
                    'Matched selected/fixed rate mismatch')
            declarations = {key: completion[key] for key in
                            ('input_fingerprints', 'observation_fingerprint', 'time_fingerprint',
                             'selection_path', 'selection_sha256', 'protocol_sha256', 'environment')}
            if matched_declarations is None:
                matched_declarations = declarations
            else:
                require(declarations == matched_declarations, 'Matched selection/environment/input declarations differ')
        entry['status'] = 'CHECKS_PASSED_PENDING_INDEPENDENT_REVIEW'
        del arrays
    fixed = results[MATCHED[0]]
    selected = results[MATCHED[1]]
    # Point difference only. Uncertainty belongs to a separate task.
    point = selected['means']['nse']['future_1_12'] - fixed['means']['nse']['future_1_12']
    progress.update(state='PENDING_INDEPENDENT_RESULT_REVIEW', cross_case_exact_domain=True,
                    matched_pair={'fixed_rate': 0.0, 'selected_rate': 0.01,
                                  'future_1_12_nse_point_difference_selected_minus_fixed': point,
                                  'uncertainty_computed': False})
    return progress


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    root = REMOTE
    output = check_output_target(args.output, root)
    output.mkdir(exist_ok=False)
    report = initial_report()
    try:
        manifest_path = safe_path(args.manifest, root)
        require(sha(manifest_path) == args.manifest_sha256, 'Manifest hash mismatch')
        manifest = bound_json({'path': str(manifest_path), 'sha256': args.manifest_sha256}, root)
        validate_manifest(manifest, root)
        base_path = safe_path(Path(__file__).parent / 'audit_saved_statistics.py', root)
        base = load_base(base_path, manifest['base_script_sha256'])
        report = audit(manifest, base, root, report)
        with (output / 'audit.json').open('x', encoding='utf-8') as stream:
            json.dump(report, stream, indent=2, allow_nan=False)
        print(report['state'])
    except BaseException as exc:
        write_failure(output, report, exc)
        raise


if __name__ == '__main__':
    main()
