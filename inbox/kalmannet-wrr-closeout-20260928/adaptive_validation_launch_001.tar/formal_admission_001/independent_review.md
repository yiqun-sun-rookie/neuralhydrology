# Independent actual-preflight acceptance: five validation configurations only

Date: 2026-09-28. Reviewer: `all_comments_coverage`, independent of the adaptive driver/checker author and of the submitting parent agent.

## Decision and allowed next step

**Accept the five named saved validation preflights below for their own registered full-validation evaluation, subject to the unchanged driver's identity/environment gates. Open critical or important findings: 0 for this specific acceptance.** No test configuration, model training, rate selection, corrected physical-model evaluation, historical full-period equivalence, scheduler submission, or manuscript performance conclusion is accepted by this record.

The accepted case identities are `historical_r001_validation`, `historical_r002_validation`, `matched_fixed_validation`, `matched_r001_validation`, and `matched_r002_validation`. They respectively represent two historical noise-adjustment rates, the newly matched fixed-noise comparator, and the same two rates in the matched implementation. Each used the first 128 validation windows twice, with 13 computed and retained positions. Later 48-position test configurations require their own validation-data preflight, frozen validation selection and independent acceptance; these five documents cannot cover them.

## Preserved execution status and failure location

Job **228839 remains FAILED with exit code 127:0, elapsed 305 seconds**. The returned transport receipt records all five completion files, the all-five-complete marker, and an error loading `libreadline.so.6` for the terminal `scontrol` command. The hash-bound scheduler script uses `set -eo pipefail`; all five Python invocations precede that marker, and the only command after it is the failing scheduler-state query. This supports accepting intact, separately verified computation records without rerunning the models. It does **not** convert the job to a successful scheduler exit.

The full transport receipt SHA-256 is `8feb57638acc8c75d18e576c6b35ec5b2f4759fc9b86368c1d9755612ea8f727`; returned archive SHA-256 is `383460cecb5ece35fbf7e64128df277ea6fa5d4b37f5b1c9f73ffeaa77ef7b97`. The reviewer independently verified its decoded transfer bytes and all **45** regular JSON/source members against the returned local files. No extraction or tensor load was needed for that cross-check.

## Evidence and repaired-checker review

- Frozen protocol SHA-256: `131182e1e579fb08ea78813c018f552462a77cf57591973d175d0b3d215ce534`; original independent code-approval SHA-256: `e805aa5ccfeb4fe2bd78f3468c68e8980325c398d78cd239e2ed2842c4d00719`; deployed path-map SHA-256: `55c5b8c8eef1fb0ee3781c20260de45f8775823a746748c83d9c9fb4058f0af5`.
- Reviewed repaired checker SHA-256: `9c2c6b15ab2554f24341063df719f782b4392471f793a03cc44b8fdce4f5252b`; tests SHA-256: `7aefdaee06c0df9ff8e127e4b8179316b0d6491ff2ff232b2823b0d0ac69610a`. Independent test run: **32/32 passed, 13.585 seconds**. The reviewer's four prior negative examples now all reject: empty resources, counted-physics import, contradictory duplicate JSON keys and remote parent traversal. The positive example still passes and the checker itself still issues no acceptance.
- Independently executed actual checker report: `provenance/adaptive_actual_checker_001.json`, SHA-256 `f5d4ac373539dc5cdf7e2b3297fa48d9309bae3d7ade95302e9cd17f4110de44`. All five configurations passed without findings. Additional transport/source/resource cross-check: `provenance/adaptive_preflight_metadata_crosscheck_001.json`, SHA-256 `6523b80bc7d0080264b5173d7f8c26efa7654ead8fde96295631ca175e9454ae`. That file binds every one of the 45 returned member hashes.
- Every source import is hash-bound; counted physical variants are absent. Each case has two distinct generated plain physical files whose bytes agree with the authenticated original physics apart from permitted line endings. Every actual load ledger contains exactly one bound validation source and no test/checkpoint loads. These are frozen-driver/read-guard and receipt checks, not an operating-system-wide access trace.
- Recorded settings agree exactly with the fixed protocol; the matched group differs only in the declared adjustment switch/rate. Both complete repeated state/output/forecast/prediction/observation/time fingerprint sets match. Input, observation and time fingerprints, and all recorded environment fields agree across the five configurations.
- The recorded environment is Python 3.11.13, PyTorch 2.4.0, NumPy 2.3.3, CUDA 12.1, cuDNN 90100, NVIDIA GeForce RTX 3090, float32, batch 128 and seed 42. Evaluation must preserve the accepted environment as enforced by the existing driver.
- Actual recorded configuration durations are 42.5122, 35.1124, 44.6894, 35.1081 and 43.2610 seconds in the identity order above. Maximum allocated graphics memory was **145,463,296 bytes** and maximum reserved memory **192,937,984 bytes**. These are actual preflight measurements, not full-period timing or performance claims.

## Required scientific naming and limits

The matched fixed-noise implementation is **not bitwise identical** to the archived hand-tuned implementation in the 128-window bridge. Maximum prediction difference is **2.7939677238464355e-7 mm/h**; the 13 per-position Nash-efficiency differences range from **4.3644847735890835e-8 to 5.1517998089778416e-8**. Its retained name is `matched fixed-noise implementation`; `full_period_historical_identity_established` remains false. This small recorded difference is neither discarded nor used to rename the new comparator as the old model. It does not prevent the predeclared matched comparison, which keeps both implementations and their purposes distinct.

This review independently inspected saved evidence and source bytes but did not recompute predictions, reopen original tensors, run a model, contact the cluster, or submit a job. Acceptance permits only the named validation stage; later scientific evaluation, rate selection, test access and publication claims remain separate decisions. Companion acceptance JSON files bind this review and each exact remote completion hash; they do not replace the protected frozen protocol.
