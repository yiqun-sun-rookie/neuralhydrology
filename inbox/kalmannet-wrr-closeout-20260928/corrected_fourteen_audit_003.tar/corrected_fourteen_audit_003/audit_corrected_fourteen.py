"""CPU-only audit of twenty-one bound saved-statistics arrays; no model execution."""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import traceback

import numpy as np

from build_manifest import (BASE_SHA, CONTRACT_SHA, MANIFEST_SHA, OLD_AUDIT_SHA, MODELS, REMOTE,
                            TEN_SHA, VARIANTS, expected_ids, require, validate_load_ledger,
                            validate_rows)

KEYS = ('nse', 'rmse', 'mae', 'kge', 'correlation', 'variability_ratio', 'bias_ratio')
ERRORS = ('rmse', 'mae')
ORIGINAL_STATES = '6cf87e4f2cfc86975a33150516df0ffcc29bfde3d055bd0a2500ad65c4474df8'
CORRECTED_STATES = '9a1ac3c04927733bf7d54f297e470f1fe718ab3ccbfe01ebd7852db76a8c3a3c'


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def safe(path, root=REMOTE):
    root, path = Path(root), Path(path)
    require(root.is_absolute() and path.is_absolute() and path != root and
            '..' not in path.parts and path.is_relative_to(root) and
            not root.is_symlink() and
            path.resolve(strict=False).is_relative_to(root.resolve(strict=False)),
            'Path outside runtime root: ' + str(path))
    for p in (root, *path.parents):
        if p == root or p.is_relative_to(root):
            require(not p.is_symlink(), 'Symlink in source path: ' + str(p))
    require(not path.is_symlink() and path.is_file(), 'Missing/linked source: ' + str(path))
    return path


def check_output_target(output, root=REMOTE):
    root, output = Path(root), Path(output)
    require(output == root / 'corrected_fourteen_audit_003/output_001' and
            root.is_absolute() and not root.is_symlink() and
            not output.exists() and not output.is_symlink() and
            output.parent.is_dir() and not output.parent.is_symlink(),
            'Output must be absent exclusive audit directory')
    return output


def bound(binding):
    path = safe(binding['path'])
    require(digest(path) == binding['sha256'], 'Hash mismatch: ' + str(path))
    return path


def bound_json(binding):
    path = bound(binding)
    value = json.loads(path.read_text(encoding='utf-8-sig'))
    require(digest(path) == binding['sha256'], 'JSON changed during read: ' + str(path))
    return value


def load_helper(path, expected, name):
    path = safe(path)
    require(digest(path) == expected, 'Helper hash mismatch: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    require(digest(path) == expected, 'Helper changed during import: ' + str(path))
    return module


def validate_manifest(manifest):
    require(manifest['schema'] == 'corrected_fourteen_saved_statistics_audit_v1' and
            manifest['remote_root'] == str(REMOTE), 'Manifest schema/root')
    require(manifest['deployed_manifest'] ==
            {'path': str(REMOTE / 'plain_preflight_v1/deployed_manifest.json'),
             'sha256': MANIFEST_SHA}, 'Frozen deployed manifest binding')
    require(manifest['contract'] ==
            {'path': str(REMOTE / 'completed_ten_audit_001/expected_formal_contract_001.json'),
             'sha256': CONTRACT_SHA}, 'Frozen contract binding')
    require(manifest['base_script_sha256'] == BASE_SHA and
            manifest['ten_helper_sha256'] == TEN_SHA, 'Frozen helper hashes')
    require(manifest['old_audit_manifest'] ==
            {'path': str(REMOTE / 'completed_ten_audit_001/audit_manifest_001.json'),
             'sha256': OLD_AUDIT_SHA},
            'Historical audit manifest path')
    require(manifest['geometry'] == {'windows': 14981, 'width': 753, 'leads': 25,
            'issue_hours': 15733, 'observation_hours': 15780, 'first_hour': 343622.0,
            'last_observation_hour': 359401.0}, 'Frozen geometry')
    validate_rows(manifest['cases'])
    require([r['case_id'] for r in manifest['cases']] == expected_ids(),
            'Case order changed')
    for row in manifest['cases']:
        case_id = row['case_id']
        expected_dir = REMOTE / 'plain_preflight_v1/numerical_impact/runs' / (case_id + '__formal_attempt01')
        require(row['directory'] == str(expected_dir), 'Wrong case directory: ' + case_id)
        files = row['files']
        required = {'completion', 'metrics', 'statistics'}
        if row['variant'] == VARIANTS[0]:
            required |= {'model_start', 'environment'}
        else:
            required |= {'admission', 'preflight', 'original_receipt', 'original_decision',
                         'review', 'corrected_state_delivery', 'model_start', 'environment',
                         'running', 'import_ledger', 'load_ledger'}
        require(set(files) == required, 'Wrong file bindings: ' + case_id)
        for key, name in [('completion', 'completion.json'), ('metrics', 'metrics.json'),
                          ('statistics', 'issue_statistics.npz')]:
            require(files[key]['path'] == str(expected_dir / name),
                    'Wrong artifact path: ' + case_id + '/' + key)
        for binding in files.values():
            require(len(binding['sha256']) == 64 and
                    all(x in '0123456789abcdef' for x in binding['sha256']) and
                    PurePosixPath(binding['path']).is_relative_to(REMOTE),
                    'Invalid binding: ' + case_id)


def exact_domain(reference, arrays, case_id):
    """Retain a useful failure location; no tolerance or source-specific waiver."""
    for key in ('issue_hours', 'observation', 'actual_leads'):
        a = arrays[key].reshape(-1)
        b = reference[key].reshape(-1)
        require(a.shape == b.shape, 'Domain shape: ' + case_id + '/' + key)
        wrong = np.flatnonzero(a != b)
        require(wrong.size == 0, f'Exact domain {case_id}/{key}: count={wrong.size}, '
                f'first={int(wrong[0]) if wrong.size else -1}')
    a, b = arrays['stats'][:, :, :3], reference['stats']
    require(a.shape == b.shape, 'First-three shape: ' + case_id)
    wrong = np.argwhere(a != b)
    require(wrong.size == 0, f'Exact first-three statistics {case_id}: '
            f'count={len(wrong)}, first={wrong[0].tolist() if len(wrong) else []}, '
            f'actual={float(a[tuple(wrong[0])]) if len(wrong) else 0}, '
            f'reference={float(b[tuple(wrong[0])]) if len(wrong) else 0}')


def signed_contrasts(original, formula, joint):
    result = {}
    for label, left, right in (
        ('formula_only_minus_original', formula, original),
        ('formula_and_initial_minus_formula_only', joint, formula),
        ('joint_minus_original', joint, original),
    ):
        result[label] = {k: [float(a - b) for a, b in zip(left[k], right[k])]
                         for k in KEYS}
        for key in ERRORS:
            result[label][key + '_m3s'] = [float(v * (957000 / 3600))
                                            for v in result[label][key]]
    for key in KEYS:
        a = np.asarray(result['formula_only_minus_original'][key])
        b = np.asarray(result['formula_and_initial_minus_formula_only'][key])
        c = np.asarray(result['joint_minus_original'][key])
        require(bool(np.allclose(a + b, c, atol=1e-14, rtol=0)),
                'Signed contrast algebra: ' + key)
    return result


def group_contrasts(original, formula, joint):
    out = {}
    for label, left, right in (
        ('formula_only_minus_original', formula, original),
        ('formula_and_initial_minus_formula_only', joint, formula),
        ('joint_minus_original', joint, original),
    ):
        out[label] = []
        for i in range(24):
            groups = {}
            for g in ('low', 'mid', 'high'):
                a = left[i]['groups'][g]
                b = right[i]['groups'][g]
                require(a['count'] == b['count'], 'Cross-variant group count')
                groups[g] = {'count': a['count'],
                             'metrics': {k: float(a['metrics'][k] - b['metrics'][k]) for k in KEYS},
                             'rmse_m3s': float(a['rmse_m3s'] - b['rmse_m3s']),
                             'mae_m3s': float(a['mae_m3s'] - b['mae_m3s'])}
            out[label].append({'lead_hours': i + 1, 'groups': groups})
    return out


def ranking(values, key):
    """Competition ranks; exact ties share rank and the next place is skipped."""
    require(key in KEYS, 'Unknown ranking metric')
    score = lambda v: abs(v - 1) if key in ('variability_ratio', 'bias_ratio') else (
        v if key in ERRORS else -v)
    ordered = sorted(values.items(), key=lambda item: (score(item[1]), item[0]))
    ranks, prior, current_rank = [], None, 0
    for place, (model, value) in enumerate(ordered, 1):
        s = score(value)
        if prior is None or s != prior:
            current_rank = place
        ranks.append({'rank': current_rank, 'model': model, 'value': float(value)})
        prior = s
    return ranks


def all_rankings(cases):
    result = {}
    for variant in VARIANTS:
        result[variant] = {}
        for key in KEYS:
            result[variant][key] = {
                'leads_0_24': [ranking({m: cases[f'{m}__{variant}']['metrics'][key][j]
                                       for m in MODELS}, key) for j in range(25)],
                'future_1_12': ranking({m: cases[f'{m}__{variant}']['means'][key]['future_1_12']
                                        for m in MODELS}, key),
                'future_13_24': ranking({m: cases[f'{m}__{variant}']['means'][key]['future_13_24']
                                         for m in MODELS}, key)}
    return result


def validate_saved_record_identity(case_id, saved, completion, files, running=None):
    """Metrics records omit case_id; bind them through completion artifacts."""
    require(completion['case_id'] == case_id and
            (saved.get('case_id', case_id) == case_id),
            'Saved/completion case identity: ' + case_id)
    artifacts = {PurePosixPath(a['path']).name: a for a in completion['artifacts']}
    require(set(artifacts) == {'metrics.json', 'issue_statistics.npz'} and
            artifacts['metrics.json'] == files['metrics'] and
            artifacts['issue_statistics.npz'] == files['statistics'] and
            saved['metrics'] == completion['metrics'] and
            saved['input_fingerprints'] == completion['input_fingerprints'] and
            saved['effective_config'] == completion['effective_config'] and
            all(saved[k] == completion[k] for k in
                ('n_windows', 'n_issue_hours', 'issues_per_window',
                 'pairs_per_lead', 'actual_leads', 'propagation_positions')),
            'Saved metrics/completion artifact identity: ' + case_id)
    if running is not None:
        require(running['case_id'] == case_id and running['stage'] == 'formal' and
                running['manifest_sha256'] == MANIFEST_SHA,
                'Running case/manifest identity: ' + case_id)
    return True


def audit(manifest, base, ten, report):
    validate_manifest(manifest)
    contract = bound_json(manifest['contract'])
    deployed = bound_json(manifest['deployed_manifest'])
    old = bound_json(manifest['old_audit_manifest'])
    old_cases = {row['case_id']: row for row in old['cases']}
    require(len(contract['grouping']) == 24 and deployed['schema'] and
            contract['manifest_sha256'] == MANIFEST_SHA, 'Frozen contract/deployment content')
    frozen = {c['case_id']: c for c in deployed['cases']}
    reference = None
    for row in manifest['cases']:
        case_id, variant, files = row['case_id'], row['variant'], row['files']
        report['current_case'] = case_id
        entry = {'status': 'INCOMPLETE', 'source_bindings': files, 'checks': []}
        report['cases'][case_id] = entry
        report['source_ledger'].setdefault('cases', {})[case_id] = files
        for name, item in files.items():
            bound(item)
        entry['checks'].append('source_hashes_before_read')
        completion, saved = bound_json(files['completion']), bound_json(files['metrics'])
        running = bound_json(files['running']) if variant != VARIANTS[0] else None
        validate_saved_record_identity(case_id, saved, completion, files, running)
        require(completion['state'] == 'PLAIN_EVALUATION_COMPLETE' and
                not (Path(row['directory']) / 'failure.json').exists(),
                'Completion identity/state: ' + case_id)
        require(completion['manifest_sha256'] == MANIFEST_SHA and
                completion['case_fingerprint'] == row['case_fingerprint'] and
                row['case_fingerprint'] == hashlib.sha256(json.dumps(
                    frozen[case_id], sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
                'Completion/frozen identity: ' + case_id)
        require(all(completion.get(k) is True for k in
                    ('inputs_unchanged', 'learned_parameters_unchanged', 'no_instrumentation')) and
                completion.get('training_calls') == 0, 'Completion invariants: ' + case_id)
        require(completion['n_windows'] == 14981 and completion['n_issue_hours'] == 15733 and
                completion['issues_per_window'] == 753 and completion['pairs_per_lead'] == 11280693 and
                completion['actual_leads'] == list(range(25)), 'Completion geometry: ' + case_id)
        if variant == VARIANTS[0]:
            for key in ('completion', 'metrics', 'statistics'):
                require(files[key] == old_cases[case_id]['files'][key],
                        'Historical original audit identity: ' + case_id)
            original_start = bound_json(files['model_start'])
            require(original_start['case_id'] == case_id and
                    original_start['input_fingerprints'] == completion['input_fingerprints'] and
                    bound_json(files['environment']) == completion['environment'],
                    'Original start/environment mismatch: ' + case_id)
        else:
            admission, preflight = bound_json(files['admission']), bound_json(files['preflight'])
            original = bound_json(files['original_receipt'])
            decision = bound_json(files['original_decision'])
            start = bound_json(files['model_start'])
            validate_load_ledger(bound_json(files['load_ledger']), frozen[case_id], deployed)
            require(admission['case_id'] == preflight['case_id'] == start['case_id'] == case_id and
                    admission['state'] == 'PLAIN_EVALUATION_ACCEPTED' and
                    admission['manifest_sha256'] == MANIFEST_SHA and
                    admission['preflight_receipt'] == files['preflight'] and
                    admission['historical_original_receipt'] == files['original_receipt'] and
                    admission['accepted_environment'] == completion['environment'] and
                    preflight['state'] == 'PLAIN_PREFLIGHT_PASS_PENDING_REVIEW' and
                    preflight['case_fingerprint'] == row['case_fingerprint'] and
                    preflight['code_bindings'] == completion['code_bindings'] and
                    preflight['environment'] == completion['environment'] and
                    bound_json(files['environment']) == completion['environment'] and
                    start['input_fingerprints'] == completion['input_fingerprints'] and
                    original['case_id'] == row['model'] + '__' + VARIANTS[0],
                    'Admission/preflight/start mismatch: ' + case_id)
            accepted_rows = [r for r in decision['original_cases'] if
                             r['case_id'] == original['case_id']]
            require(len(accepted_rows) == 1 and accepted_rows[0]['accepted'] is True and
                    accepted_rows[0]['open_critical_count'] == 0 and
                    accepted_rows[0]['open_important_count'] == 0 and
                    admission['original_result_decision']['accepted'] is True,
                    'Independent original acceptance mismatch: ' + case_id)
            require(len(preflight['checks']) == 2 and all(
                check['effective_config'] == completion['effective_config'] and
                check['time_mapping_passed'] is True for check in preflight['checks']),
                'Effective config/preflight repeat mismatch: ' + case_id)
            original_start = bound_json(next(r for r in manifest['cases'] if
                r['case_id'] == original['case_id'])['files']['model_start'])
            require(start['parameter_fingerprints'] == original_start['parameter_fingerprints'] and
                    completion['code_bindings'] == original['code_bindings'],
                    'Parameters/code changed: ' + case_id)
            for field in ('p', 'etpot', 'qobs', 'tm_hours'):
                require(completion['input_fingerprints'][field] == original['input_fingerprints'][field],
                        'Shared input changed: ' + case_id + '/' + field)
            expected_states = ORIGINAL_STATES if variant == VARIANTS[1] else CORRECTED_STATES
            require(completion['input_fingerprints']['states_all'] == expected_states,
                    'Incorrect state input: ' + case_id)
        entry['checks'].append('metadata_invariants')
        arrays = base.saved_arrays(files['statistics']['path'], files['statistics']['sha256'],
                                   14981, 753, 25, 15780)
        entry['saved_array_reads'] = 1
        entry['time'] = ten.validate_time(arrays, manifest['geometry'])
        domain = ten.normalized_domain(arrays)
        if reference is None:
            reference = {k: v.copy() for k, v in domain.items()}
        else:
            exact_domain(reference, domain, case_id)
        entry['checks'].append('exact_observation_time_lead_count_sy_sy2_domain')
        calculated = base.calculate(arrays['stats'])
        metric_check = ten.compare_vectors(calculated, saved['metrics'])
        require(metric_check['passed'], 'Seven saved metrics mismatch: ' + case_id)
        physical = ten.physical_errors(calculated, saved)
        require(physical['passed'], 'Physical error units mismatch: ' + case_id)
        grouped = ten.grouped_check(arrays, contract['grouping'], saved['grouped_metrics'], base)
        require(grouped['passed'], 'Flow grouping mismatch: ' + case_id + ': ' +
                json.dumps(grouped['violations'][:3], allow_nan=False))
        entry['metric_check'] = metric_check
        entry['physical_error_check'] = physical
        entry['group_check'] = {k: v for k, v in grouped.items() if k != 'details'}
        entry['metrics'] = {k: [float(v) for v in calculated[k]] for k in KEYS}
        entry['means'] = ten.scalar_means(calculated)
        entry['current_0'] = {k: float(calculated[k][0]) for k in KEYS}
        entry['grouped_metrics'] = saved['grouped_metrics']
        for item in files.values():
            bound(item)
        entry['checks'].append('source_hashes_after_read')
        entry['status'] = 'ARRAY_CHECKS_PASSED_PENDING_INDEPENDENT_REVIEW'
        del arrays
    for model in MODELS:
        ids = [model + '__' + v for v in VARIANTS]
        a, b, c = [report['cases'][i] for i in ids]
        report['contrasts'][model] = {
            'metrics': signed_contrasts(a['metrics'], b['metrics'], c['metrics']),
            'flow_groups': group_contrasts(a['grouped_metrics'], b['grouped_metrics'],
                                           c['grouped_metrics'])}
    report['rankings'] = all_rankings(report['cases'])
    report['state'] = 'ARRAY_CHECKS_PASSED_PENDING_INDEPENDENT_SCIENTIFIC_ACCEPTANCE'
    report['current_case'] = None
    report['accepted'] = False
    report['uncertainty_computed'] = False
    return report


def summary(report):
    lines = [report['state'], f"Completed case summaries: {sum(c['status'].startswith('ARRAY_CHECKS_PASSED') for c in report['cases'].values())}/21",
             'Point contrasts only; no uncertainty or scientific acceptance.']
    if report['state'].startswith('AUDIT_FAILED'):
        lines.append('Failed check: ' + report.get('failed_check', 'unknown'))
        return '\n'.join(lines) + '\n'
    for model in MODELS:
        c = report['contrasts'][model]['metrics']
        key = 'formula_only_minus_original'
        nse = c[key]['nse']
        lines.append(f'{model}: formula-only minus original future 1-12 NSE mean='
                     f'{float(np.mean(nse[1:13])):+.12g}; future 13-24 mean='
                     f'{float(np.mean(nse[13:25])):+.12g}')
    return '\n'.join(lines) + '\n'


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest', required=True, type=Path)
    p.add_argument('--manifest-sha256', required=True)
    p.add_argument('--base-script', required=True, type=Path)
    p.add_argument('--ten-helper', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    output = check_output_target(args.output)
    output.mkdir(exist_ok=False)
    report = {'state': 'AUDIT_INCOMPLETE', 'accepted': False, 'current_case': None,
              'cases': {}, 'contrasts': {}, 'rankings': {}, 'source_ledger': {}}
    try:
        require(args.manifest == Path(REMOTE / 'corrected_fourteen_audit_003/audit_manifest_001.json'),
                'Manifest path')
        require(digest(safe(args.manifest)) == args.manifest_sha256, 'Manifest hash')
        manifest = json.loads(args.manifest.read_text(encoding='utf-8-sig'))
        report['source_ledger']['manifest'] = {'path': str(args.manifest),
                                                'sha256': args.manifest_sha256}
        validate_manifest(manifest)
        base = load_helper(args.base_script, BASE_SHA, 'frozen_saved_statistics')
        ten = load_helper(args.ten_helper, TEN_SHA, 'frozen_completed_ten')
        report['source_ledger']['helpers'] = {'base': str(args.base_script),
                                               'completed_ten': str(args.ten_helper)}
        audit(manifest, base, ten, report)
        require(digest(args.manifest) == args.manifest_sha256, 'Manifest changed during audit')
        with (output / 'audit.json').open('x', encoding='utf-8') as stream:
            json.dump(report, stream, indent=2, allow_nan=False)
        (output / 'summary.txt').write_text(summary(report), encoding='utf-8')
        print(report['state'])
    except BaseException as exc:
        report['state'] = 'AUDIT_FAILED_PENDING_REVIEW'
        report['accepted'] = False
        report['failed_check'] = str(exc)
        report['diagnostic'] = traceback.format_exc()
        try:
            payload = json.dumps(report, indent=2, allow_nan=False)
        except (TypeError, ValueError):
            payload = json.dumps({'state': report['state'], 'accepted': False,
                'failed_check': report['failed_check'], 'diagnostic': report['diagnostic'],
                'current_case': report['current_case'],
                'source_ledger': report['source_ledger'],
                'completed_cases': [key for key, value in report['cases'].items() if
                                    value['status'].startswith('ARRAY_CHECKS_PASSED')]},
                indent=2, allow_nan=False)
        (output / 'audit.json').write_text(payload + '\n', encoding='utf-8')
        (output / 'failure.json').write_text(payload + '\n', encoding='utf-8')
        (output / 'summary.txt').write_text(summary(report), encoding='utf-8')
        raise


if __name__ == '__main__':
    main()
