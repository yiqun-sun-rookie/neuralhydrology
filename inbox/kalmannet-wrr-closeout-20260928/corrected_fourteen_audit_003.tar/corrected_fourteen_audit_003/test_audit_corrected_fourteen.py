"""Small synthetic arithmetic and identity tests; never open real saved arrays."""
import importlib.util
import json
from copy import deepcopy
import math
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pytest

import audit_corrected_fourteen as audit
import build_manifest as builder

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE_PATH = HERE.parents[1] / 'completed_ten_audit_001/package_002/completed_ten_audit_001/audit_saved_statistics.py'
TEN_PATH = HERE.parents[1] / 'completed_ten_audit_001/audit_completed_ten.py'


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


base = module(BASE_PATH, 'test_frozen_base')
ten = module(TEN_PATH, 'test_frozen_ten')


def stat(y, prediction):
    return [1, y, y*y, prediction, prediction*prediction,
            prediction*y, (prediction-y)**2, abs(prediction-y)]


def test_direct_prediction_observation_arithmetic():
    observed = np.array([1., 2., 3., 4.])
    predicted = np.array([1.1, 1.9, 3.2, 3.8])
    rows = np.array([stat(y, p) for y, p in zip(observed, predicted)])[:, None, :]
    found = base.calculate(rows)
    expected_rmse = math.sqrt(float(np.mean((predicted-observed)**2)))
    expected_nse = 1 - float(np.sum((predicted-observed)**2) /
                             np.sum((observed-observed.mean())**2))
    assert found['rmse'][0] == pytest.approx(expected_rmse, abs=1e-14)
    assert found['nse'][0] == pytest.approx(expected_nse, abs=1e-14)
    assert found['mae'][0] == pytest.approx(float(np.mean(abs(predicted-observed))))


def test_three_signed_contrasts_and_joint_algebra():
    a = {key: [0., 1.] for key in audit.KEYS}
    b = {key: [1., 3.] for key in audit.KEYS}
    c = {key: [4., 8.] for key in audit.KEYS}
    got = audit.signed_contrasts(a, b, c)
    assert got['formula_only_minus_original']['nse'] == [1., 2.]
    assert got['formula_and_initial_minus_formula_only']['nse'] == [3., 5.]
    assert got['joint_minus_original']['nse'] == [4., 7.]


@pytest.mark.parametrize('metric,values,expected', [
    ('rmse', {'a': 2., 'b': 1., 'c': 1.}, [('b', 1), ('c', 1), ('a', 3)]),
    ('nse', {'a': 2., 'b': 1., 'c': 2.}, [('a', 1), ('c', 1), ('b', 3)]),
    ('bias_ratio', {'a': 1.2, 'b': .8, 'c': 1.}, [('c', 1), ('a', 2), ('b', 2)]),
])
def test_ranking_direction_and_ties(metric, values, expected):
    assert [(r['model'], r['rank']) for r in audit.ranking(values, metric)] == expected


@pytest.mark.parametrize('field', ['issue_hours', 'observation', 'actual_leads', 'stats'])
def test_exact_domain_rejects_each_component(field):
    reference = {'issue_hours': np.array([1., 2.]),
                 'observation': np.array([1., 2., 3.]),
                 'actual_leads': np.array([0, 1]),
                 'stats': np.zeros((2, 2, 3))}
    actual = {k: v.copy() for k, v in reference.items()}
    actual[field].flat[0] += 1
    with pytest.raises(ValueError, match='Exact'):
        audit.exact_domain(reference, actual, 'case')


def test_original_and_corrected_state_inputs_are_distinct():
    assert audit.ORIGINAL_STATES != audit.CORRECTED_STATES
    assert builder.VARIANTS[1] != builder.VARIANTS[2]


def test_frozen_real_metadata_manifest_builds_without_saved_array_reads():
    manifest = builder.build(ROOT)
    audit.validate_manifest(manifest)
    assert len(manifest['cases']) == 21
    assert len({x['case_id'] for x in manifest['cases']}) == 21


def test_saved_manifest_matches_current_builder():
    on_disk = json.loads((HERE / 'audit_manifest_001.json').read_text(encoding='utf-8'))
    assert on_disk == builder.build(ROOT)
    audit.validate_manifest(on_disk)


def test_missing_and_duplicate_case_rejected():
    manifest = builder.build(ROOT)
    with pytest.raises(ValueError, match='Missing, extra or duplicate'):
        builder.validate_rows(manifest['cases'][:-1])
    with pytest.raises(ValueError, match='Missing, extra or duplicate'):
        builder.validate_rows(manifest['cases'][:-1] + [manifest['cases'][0]])


def test_wrong_case_and_bad_hash_rejected():
    manifest = builder.build(ROOT)
    manifest['cases'][0]['directory'] += '-wrong'
    with pytest.raises(ValueError, match='Wrong case directory'):
        audit.validate_manifest(manifest)
    manifest = builder.build(ROOT)
    manifest['cases'][0]['files']['completion']['sha256'] = 'x' * 64
    with pytest.raises(ValueError, match='Invalid binding'):
        audit.validate_manifest(manifest)


def test_failed_admission_rejected_by_builder():
    actual_read = builder.read

    def changed(path):
        value = actual_read(path)
        if Path(path).name == 'main_seed43__corrected_outlet_original_states.json':
            value['state'] = 'FAILED'
        return value

    with patch.object(builder, 'read', side_effect=changed):
        with pytest.raises(ValueError, match='Wrong or failed admission'):
            builder.build(ROOT)


def test_failed_completion_rejected_by_builder():
    actual_read = builder.read

    def changed(path):
        value = actual_read(path)
        if (Path(path).name == 'completion.json' and
                'main_seed43__original_outlet_original_states__formal_attempt01' in str(path)):
            value['state'] = 'FAILED'
        return value

    with patch.object(builder, 'read', side_effect=changed):
        with pytest.raises(ValueError, match='Failed or wrong completion'):
            builder.build(ROOT)


def test_wrong_metric_and_nonfinite_statistics_rejected():
    left = {key: [1.] for key in audit.KEYS}
    right = {key: [1.] for key in audit.KEYS}
    right['nse'] = [2.]
    assert not ten.compare_vectors(left, right)['passed']
    bad = np.array([stat(1., 1.), stat(2., math.nan)])[:, None, :]
    with pytest.raises(ValueError):
        base.calculate(bad)


def test_missing_source_and_existing_output_rejected(tmp_path):
    with pytest.raises(ValueError, match='Missing/linked source'):
        audit.safe(tmp_path / 'missing.json', root=tmp_path)
    parent = tmp_path / 'corrected_fourteen_audit_003'
    parent.mkdir()
    out = parent / 'output_001'
    assert audit.check_output_target(out, root=tmp_path) == out
    out.mkdir()
    with pytest.raises(ValueError, match='Output must be absent'):
        audit.check_output_target(out, root=tmp_path)


def test_group_count_mismatch_rejected():
    observation = np.tile(np.arange(6, dtype=float), 6)
    stats = np.zeros((6, 25, 8))
    for lead in range(25):
        for issue in range(6):
            y = observation[issue + lead]
            stats[issue, lead] = stat(y, y + .1)
    arrays = {'stats': stats, 'observation': observation}
    frozen, saved = [], []
    for lead in range(1, 25):
        observed = observation[np.arange(6) + lead]
        masks = {'low': observed < 1.5, 'mid': (observed >= 1.5) & (observed <= 3.5),
                 'high': observed > 3.5}
        groups = {}
        counts = {}
        for name, mask in masks.items():
            metrics = {k: v[0] for k, v in base.calculate(
                np.sum(stats[mask, lead, :], axis=0).reshape(1, 1, 8)).items()}
            groups[name] = {'count': int(mask.sum()), 'metrics': metrics,
                            'rmse_m3s': metrics['rmse'] * ten.CONVERSION,
                            'mae_m3s': metrics['mae'] * ten.CONVERSION}
            counts[name] = int(mask.sum())
        frozen.append({'lead_hours': lead, 'q25_mmh': 1.5, 'q75_mmh': 3.5,
                       'counts': counts})
        saved.append({'lead_hours': lead, 'q25_mmh': 1.5, 'q75_mmh': 3.5,
                      'groups': groups})
    assert ten.grouped_check(arrays, frozen, saved, base)['passed']
    saved[0]['groups']['low']['count'] += 1
    assert not ten.grouped_check(arrays, frozen, saved, base)['passed']


def load_metadata(case_id):
    deployed = builder.read(ROOT / 'hpc/plain_receipts_001/deployed_manifest.json')
    frozen = next(row for row in deployed['cases'] if row['case_id'] == case_id)
    ledger = builder.read(ROOT / 'hpc/corrected_fourteen_receipts_001/numerical_impact/runs' /
                          (case_id + '__formal_attempt01') / 'load_ledger.json')
    return ledger, frozen, deployed


@pytest.mark.parametrize('case_id,roles', [
    ('main_seed43__corrected_outlet_original_states', {'dataset', 'checkpoint'}),
    ('main_seed43__corrected_outlet_corrected_states',
     {'dataset', 'fixed_corrected_initial_states', 'checkpoint'}),
    ('learned_noise__corrected_outlet_corrected_states',
     {'dataset', 'fixed_corrected_initial_states', 'fixed_learned_noise_checkpoint'}),
    ('hand_tuned__corrected_outlet_corrected_states',
     {'dataset', 'fixed_corrected_initial_states'}),
])
def test_actual_load_roles_match_frozen_case(case_id, roles):
    ledger, frozen, deployed = load_metadata(case_id)
    assert {row['role'] for row in ledger} == roles
    assert builder.validate_load_ledger(ledger, frozen, deployed)


def test_false_checkpoint_hash_rejected():
    ledger, frozen, deployed = load_metadata('main_seed43__corrected_outlet_corrected_states')
    next(row for row in ledger if row['role'] == 'checkpoint')['sha256'] = '0' * 64
    with pytest.raises(ValueError, match='Loaded source identity mismatch'):
        builder.validate_load_ledger(ledger, frozen, deployed)


def test_false_initial_state_source_rejected():
    ledger, frozen, deployed = load_metadata('main_seed43__corrected_outlet_corrected_states')
    next(row for row in ledger if row['role'] == 'fixed_corrected_initial_states')['path'] += '.wrong'
    with pytest.raises(ValueError, match='Loaded source identity mismatch'):
        builder.validate_load_ledger(ledger, frozen, deployed)


@pytest.mark.parametrize('mutation', ['missing', 'duplicate', 'extra'])
def test_missing_duplicate_or_extra_loaded_source_rejected(mutation):
    ledger, frozen, deployed = load_metadata('main_seed43__corrected_outlet_corrected_states')
    if mutation == 'missing':
        ledger.pop()
    elif mutation == 'duplicate':
        ledger[-1] = deepcopy(ledger[0])
    else:
        ledger.append({'role': 'unapproved', 'path': '/not/frozen', 'sha256': '0' * 64})
    with pytest.raises(ValueError, match='Missing or extra loaded source|Missing, duplicate or unexpected load role'):
        builder.validate_load_ledger(ledger, frozen, deployed)


def local_case_records(row):
    bucket = ('plain_original_eight_receipts_001' if row['variant'] == builder.VARIANTS[0]
              else 'corrected_fourteen_receipts_001')
    directory = (ROOT / 'hpc' / bucket / 'numerical_impact/runs' /
                 (row['case_id'] + '__formal_attempt01'))
    completion = builder.read(directory / 'completion.json')
    saved = builder.read(directory / 'metrics.json')
    running = (builder.read(directory / 'running.json') if row['variant'] != builder.VARIANTS[0]
               else None)
    assert builder.digest(directory / 'completion.json') == row['files']['completion']['sha256']
    assert builder.digest(directory / 'metrics.json') == row['files']['metrics']['sha256']
    if running is not None:
        assert builder.digest(directory / 'running.json') == row['files']['running']['sha256']
    return completion, saved, running


def test_all_twenty_one_real_metadata_records_before_array_opening():
    manifest = builder.read(HERE / 'audit_manifest_001.json')
    assert len(manifest['cases']) == 21
    for row in manifest['cases']:
        completion, saved, running = local_case_records(row)
        assert 'case_id' not in saved  # Actual producer schema, not a test omission.
        assert audit.validate_saved_record_identity(
            row['case_id'], saved, completion, row['files'], running)


@pytest.mark.parametrize('wrong_source', ['saved', 'running'])
def test_wrong_case_id_is_still_rejected(wrong_source):
    manifest = builder.read(HERE / 'audit_manifest_001.json')
    row = next(r for r in manifest['cases'] if r['variant'] == builder.VARIANTS[1])
    completion, saved, running = local_case_records(row)
    if wrong_source == 'saved':
        saved['case_id'] = 'another_case'
    else:
        running['case_id'] = 'another_case'
    with pytest.raises(ValueError, match='case identity|Running case/manifest identity'):
        audit.validate_saved_record_identity(
            row['case_id'], saved, completion, row['files'], running)
