"""Exercise the saved-array audit entrypoint with the real launcher's arguments."""
import hashlib
import json
from pathlib import Path
import re
import sys

import pytest

import audit_corrected_fourteen as audit


HERE = Path(__file__).resolve().parent
LAUNCHER = HERE / 'run_cpu_audit.sh'
MANIFEST = HERE / 'audit_manifest_001.json'
EXPECTED_SHA = 'f14eb6158b7bfaede081d1189dba7c75046b5edb1d79df661d60f219a8c24536'


def launcher_args(root):
    script = LAUNCHER.read_text(encoding='utf-8')
    def argument(name):
        found = re.search(r'(?m)^\s*--' + re.escape(name) + r'\s+(?:"([^"]+)"|([0-9a-f]{64}))', script)
        assert found, name
        value = found.group(1) or found.group(2)
        return str(root / value.removeprefix('$ROOT/')) if value.startswith('$ROOT/') else value
    entrypoint = re.search(r'exec python -B "([^"]+)"', script)
    assert entrypoint and root / entrypoint.group(1).removeprefix('$ROOT/') == root / 'corrected_fourteen_audit_003/audit_corrected_fourteen.py'
    assert hashlib.sha256(MANIFEST.read_bytes()).hexdigest() == EXPECTED_SHA
    return {key: argument(key) for key in ('manifest', 'manifest-sha256', 'base-script', 'ten-helper', 'output')}


class BoundaryReached(Exception):
    pass


def invoke(monkeypatch, tmp_path, *, changed=None):
    root = tmp_path / 'remote'
    package = root / 'corrected_fourteen_audit_003'
    package.mkdir(parents=True)
    (package / 'audit_manifest_001.json').write_bytes(MANIFEST.read_bytes())
    args = launcher_args(root)
    args.update(changed or {})
    Path(args['output']).parent.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(audit, 'REMOTE', root)
    # Remap the default root for the real production guards, without replacing them.
    monkeypatch.setattr(audit.safe, '__defaults__', (root,))
    monkeypatch.setattr(audit.check_output_target, '__defaults__', (root,))
    monkeypatch.setattr(audit, 'validate_manifest', lambda _: (_ for _ in ()).throw(BoundaryReached()))
    argv = ['audit_corrected_fourteen.py']
    for key, value in args.items():
        argv.extend(('--' + key, value))
    monkeypatch.setattr(sys, 'argv', argv)
    try:
        audit.main()
    except (ValueError, BoundaryReached) as error:
        return error, args
    raise AssertionError('Entrypoint unexpectedly reached scientific array access')


def test_real_launcher_reaches_post_manifest_boundary(monkeypatch, tmp_path):
    error, args = invoke(monkeypatch, tmp_path)
    assert isinstance(error, BoundaryReached), str(error)
    failure = json.loads(Path(args['output'], 'failure.json').read_text(encoding='utf-8'))
    assert failure['failed_check'] == ''


def test_old_or_wrong_output_rejected(monkeypatch, tmp_path):
    root = tmp_path / 'remote'
    for name in ('corrected_fourteen_audit_001', 'wrong'):
        with pytest.raises(ValueError, match='Output must be absent'):
            audit.check_output_target(root / name / 'output_001', root=root)


@pytest.mark.parametrize('directory', ['corrected_fourteen_audit_001', 'wrong'])
def test_old_or_wrong_manifest_path_rejected_at_entrypoint(monkeypatch, tmp_path, directory):
    root = tmp_path / 'remote'
    wrong_manifest = root / directory / 'audit_manifest_001.json'
    error, _ = invoke(monkeypatch, tmp_path, changed={'manifest': str(wrong_manifest)})
    assert isinstance(error, ValueError) and 'Manifest path' in str(error)


def test_wrong_manifest_path_and_hash_rejected(monkeypatch, tmp_path):
    root = tmp_path / 'remote'
    package = root / 'corrected_fourteen_audit_003'
    package.mkdir(parents=True)
    (package / 'audit_manifest_001.json').write_bytes(MANIFEST.read_bytes())
    args = launcher_args(root)
    for name in ('corrected_fourteen_audit_001', 'wrong'):
        assert Path(args['manifest']) != root / name / 'audit_manifest_001.json'
    error, _ = invoke(monkeypatch, tmp_path / 'hash', changed={'manifest-sha256': '0' * 64})
    assert isinstance(error, ValueError) and 'Manifest hash' in str(error)


def test_existing_and_symlink_output_rejected(tmp_path):
    root = tmp_path / 'remote'
    package = root / 'corrected_fourteen_audit_003'
    package.mkdir(parents=True)
    target = package / 'output_001'
    target.mkdir()
    with pytest.raises(ValueError, match='Output must be absent'):
        audit.check_output_target(target, root=root)
    target.rmdir()
    try:
        target.symlink_to(package, target_is_directory=True)
    except (OSError, NotImplementedError):
        pytest.skip('Symlink creation unavailable on this host')
    with pytest.raises(ValueError, match='Output must be absent'):
        audit.check_output_target(target, root=root)
