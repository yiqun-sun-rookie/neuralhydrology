#!/usr/bin/env bash
# Submit only after the controller has installed and hash-checked this package.
# No model, raw data, checkpoint, training, or GPU access.
#SBATCH --job-name=corrected14-saved-audit
#SBATCH --partition=hgpu2p
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --exclude=ngu002
#SBATCH --cpus-per-task=4
#SBATCH --time=00:10:00
#SBATCH --no-requeue
#SBATCH --output=/data1/home/sunyiq/kalmannet_wrr_closeout_20260928_v1/corrected_fourteen_audit_003/audit-%j.out
#SBATCH --error=/data1/home/sunyiq/kalmannet_wrr_closeout_20260928_v1/corrected_fourteen_audit_003/audit-%j.err
set -eo pipefail
ROOT=/data1/home/sunyiq/kalmannet_wrr_closeout_20260928_v1
source /data1/home/sunyiq/miniconda3/etc/profile.d/conda.sh
conda activate nh_final
export MKL_THREADING_LAYER=GNU
export MKL_SERVICE_FORCE_INTEL=1
export OMP_NUM_THREADS=4
export PYTHONDONTWRITEBYTECODE=1
export CUDA_VISIBLE_DEVICES=''
exec python -B "$ROOT/corrected_fourteen_audit_003/audit_corrected_fourteen.py" \
  --manifest "$ROOT/corrected_fourteen_audit_003/audit_manifest_001.json" \
  --manifest-sha256 f14eb6158b7bfaede081d1189dba7c75046b5edb1d79df661d60f219a8c24536 \
  --base-script "$ROOT/completed_ten_audit_001/audit_saved_statistics.py" \
  --ten-helper "$ROOT/completed_ten_audit_001/audit_completed_ten.py" \
  --output "$ROOT/corrected_fourteen_audit_003/output_001"
