# Second and final corrected-array submission review

Decision: **operational change conditionally passes; final package/deployment checks remain required**. Critical / Important / Minor findings: **C=0 / I=0 / M=0**. This is the second and final authorized technical repair of the saved-array audit, not a model rerun or permission for any further failed-attempt retry.

## Exact current script bindings

| File in `hpc/completed_results_continuation_002` | Independently measured SHA-256 |
|---|---|
| `submit_corrected_array_audit_002.sh` | `f7f621df7005f972f3e58c7889dc0020594e0f50137c82296a78e9b82a2aa785` |
| `run_corrected_cpu_audit_002.sh` | `cca1311320f66b0eee3ebf9906500862f278c92d04045cdbfbb7f484210c19cb` |

Reviewed `corrected_operational_002.diff`, the full two current scripts, and the previous `independent_submit_review.md`. The reproducibility-check skill was reused. This review was static only: no remote actions, program edits, model/data reads, or execution tests. The controller reports the second schema repair separately passed independent code review with zero critical, important, and minor findings; that code review was not repeated here.

## Verified operational consistency

The new submission target is `/data1/home/sunyiq/kalmannet_wrr_closeout_20260928_v1/corrected_fourteen_audit_002`, the archive is `corrected_fourteen_audit_002.tar`, and the exclusive job record is `corrected_fourteen_audit_jobid_002.txt`. The launcher's program, manifest, standard output, standard error, and `output_001` all resolve beneath the new target. No changed write target points into `corrected_fourteen_audit_001`; the first failed execution (job 231144, as reported by the controller) and its output remain outside the new write paths.

The submit script executes `$target/run_cpu_audit.sh`. Therefore the archive must install the exact local `run_corrected_cpu_audit_002.sh` bytes under the member name **`corrected_fourteen_audit_002/run_cpu_audit.sh`**. With this explicit packaging mapping, launcher and submission paths agree. Packaging it only under its local filename would not satisfy the submission interface.

The launcher still specifies one node, one task, four CPU cores, partition `hgpu2p`, excluded node `ngu002`, a ten-minute limit, and `--no-requeue`. There is no GPU resource request, `--mem`, or `srun`; `CUDA_VISIBLE_DEVICES` is empty. It uses `set -eo pipefail`, without shell `-u`, activates `nh_final`, preserves the mathematical-library environment settings and `OMP_NUM_THREADS=4`, disables Python bytecode writes, and calls the saved-array audit once. These are launcher properties; the reviewed Python implementation establishes the no-model/no-training behavior.

The manifest content binding is unchanged: `f14eb6158b7bfaede081d1189dba7c75046b5edb1d79df661d60f219a8c24536`. Only its installed directory changes. The two helper paths and SHA-256 values are unchanged. The absent-target/job-record/output checks, empty isolated-task queue check, externally pinned archive check, no-overwrite extraction, complete internal checksum check, exclusive attempt/receipt/job record, and no-retry submission handling remain unchanged.

## Conditions before deployment

1. Bind the final package's candidate code and all required reviews to the independently accepted second schema repair. Preserve the frozen manifest bytes at the SHA-256 above; do not substitute a changed manifest or alter tolerances under this operational approval.
2. Retain the previous review's complete local archive validation: exact regular-file members beneath the new target, no links/special/duplicate/unsafe/unexpected members, and an exact complete `package_files.sha256` inventory matching accepted source/proof/review bytes. Verify the launcher filename mapping above and its exact hash. Exclude old/new execution outputs, submission markers, receipts, and job-id files from the package. Compute and pass the final archive checksum only after these checks.
3. Continue rejecting submission-environment `SBATCH_*` overrides. Confirm the new target/job record/output are absent and serialize this job with every other submission in the isolated root so total concurrent allocation does not exceed four CPU cores. The queue snapshot is not a concurrent-submitter lock.
4. Preserve the first failed execution and all second-attempt evidence. After any terminal failure, ambiguous submission receipt, or downstream reporting failure, inspect retained evidence and stop; do not submit another repair or retry. A successful wrapper exit is not acceptance of runtime audit results or scientific conclusions.

No operational code fix is required within these stated conditions. Final archive validation, actual environment/resource checks, and runtime success remain unverified by this static review.
