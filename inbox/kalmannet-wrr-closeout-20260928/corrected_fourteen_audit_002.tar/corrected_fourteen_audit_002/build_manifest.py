"""Build a fixed, twenty-one-case saved-statistics audit manifest from receipts.

Local metadata is read only. The sole output is a newly created manifest file.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath

REMOTE = PurePosixPath('/data1/home/sunyiq/kalmannet_wrr_closeout_20260928_v1')
MODELS = ('main_seed43', 'main_seed44', 'compact_seed42', 'compact_seed43',
          'compact_seed44', 'learned_noise', 'hand_tuned')
VARIANTS = ('original_outlet_original_states', 'corrected_outlet_original_states',
            'corrected_outlet_corrected_states')
MANIFEST_SHA = 'fe81db8c7bbea43e2f8040ea004e8f8bbf5ddf2107cd5b73369643f3e68c3087'
CONTRACT_SHA = 'ebe69b0c5be9e12c4882dca6142152df458ae35c329be2d3af6c98039003b055'
BASE_SHA = '9c8ab347eb3437b4bcc2f01a5a350a2126209577e77dee3ca796faa309313f34'
TEN_SHA = 'ba29ec4bc78eadf4554fc8902c160b5019b16e1829b087d6519d5706087b1297'
OLD_AUDIT_SHA = 'd20262c7638f6d69764f4dce7475879b1d43b83dc7ed1d6f9e8f6f78a557d22a'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def binding(path, local):
    require(local.is_file(), 'Missing local receipt: ' + str(local))
    return {'path': str(path), 'sha256': digest(local)}


def local_for(remote, root):
    rel = PurePosixPath(remote).relative_to(REMOTE)
    parts = rel.parts
    if parts[:3] == ('plain_preflight_v1', 'numerical_impact', 'runs'):
        run = parts[3]
        bucket = ('plain_original_eight_receipts_001' if '__original_outlet_original_states__formal_attempt01' in run
                  else 'plain_receipts_001')
        return root / 'hpc' / bucket / 'numerical_impact' / 'runs' / Path(*parts[3:])
    if parts[0] == 'corrected_launch_001':
        return root / 'hpc' / Path(*parts)
    raise ValueError('No exact local receipt mapping: ' + str(remote))


def expected_ids():
    return [f'{model}__{variant}' for model in MODELS for variant in VARIANTS]


def validate_rows(rows):
    ids = [row['case_id'] for row in rows]
    require(len(ids) == 21 and len(set(ids)) == 21 and set(ids) == set(expected_ids()),
            'Missing, extra or duplicate case identities')


def validate_load_ledger(ledger, frozen_case, deployed):
    """Check declared loads against frozen metadata; never open loaded files."""
    case_id = frozen_case['case_id']
    expected = {'dataset': deployed['datasets']['test']}
    if frozen_case['variant'] == 'corrected_outlet_corrected_states':
        expected['fixed_corrected_initial_states'] = deployed['corrected_states']['test']
    checkpoint = frozen_case.get('checkpoint')
    checkpoint_sha = frozen_case.get('checkpoint_sha256')
    require((checkpoint is None) == (checkpoint_sha is None),
            'Incomplete frozen checkpoint identity: ' + case_id)
    if checkpoint is not None:
        role = ('fixed_learned_noise_checkpoint' if case_id.startswith('learned_noise__')
                else 'checkpoint')
        expected[role] = {'path': checkpoint, 'sha256': checkpoint_sha}
    require(isinstance(ledger, list) and len(ledger) == len(expected),
            'Missing or extra loaded source: ' + case_id)
    roles = [row.get('role') for row in ledger if isinstance(row, dict)]
    require(len(roles) == len(ledger) and len(set(roles)) == len(roles) and
            set(roles) == set(expected), 'Missing, duplicate or unexpected load role: ' + case_id)
    for row in ledger:
        source = expected[row['role']]
        require(row.get('path') == source['path'] and
                row.get('sha256') == source['sha256'],
                'Loaded source identity mismatch: ' + case_id + '/' + row['role'])
    return True


def build(root, runtime_root=REMOTE):
    root = Path(root)
    require(root.is_dir(), 'Local evidence root absent')
    require(str(runtime_root) == str(REMOTE), 'Unexpected runtime root')
    hpc = root / 'hpc'
    deployed_path = hpc / 'plain_receipts_001/deployed_manifest.json'
    require(digest(deployed_path) == MANIFEST_SHA, 'Frozen deployed manifest hash')
    deployed = read(deployed_path)
    by_id = {c['case_id']: c for c in deployed['cases']}
    require(len(by_id) == len(deployed['cases']), 'Duplicate frozen case')
    old_path = hpc / 'completed_ten_audit_001/audit_manifest_001.json'
    require(digest(old_path) == OLD_AUDIT_SHA, 'Historical audit manifest hash')
    old = read(old_path)
    old_by_id = {c['case_id']: c for c in old['cases']}
    contract_path = hpc / 'completed_ten_audit_001/package_002/completed_ten_audit_001/expected_formal_contract_001.json'
    require(digest(contract_path) == CONTRACT_SHA, 'Frozen contract hash')
    rows = []
    for model in MODELS:
        original_id = f'{model}__{VARIANTS[0]}'
        original_old = old_by_id[original_id]
        require(original_old['kind'] == 'original', 'Original historical audit binding')
        for variant in VARIANTS:
            case_id = f'{model}__{variant}'
            frozen = by_id[case_id]
            require(frozen['variant'] == variant, 'Frozen variant mismatch')
            directory = REMOTE / 'plain_preflight_v1/numerical_impact/runs' / (case_id + '__formal_attempt01')
            local_dir = (hpc / ('plain_original_eight_receipts_001' if variant == VARIANTS[0]
                                else 'corrected_fourteen_receipts_001') /
                         'numerical_impact/runs' / (case_id + '__formal_attempt01'))
            require(local_dir.is_dir(), 'Missing exact local case: ' + case_id)
            completion_path = local_dir / 'completion.json'
            completion = read(completion_path)
            require(completion['case_id'] == case_id and completion['state'] == 'PLAIN_EVALUATION_COMPLETE',
                    'Failed or wrong completion: ' + case_id)
            require(all(completion.get(k) is True for k in
                        ('inputs_unchanged', 'learned_parameters_unchanged', 'no_instrumentation')) and
                    completion.get('training_calls') == 0, 'Completion invariants: ' + case_id)
            require(completion['manifest_sha256'] == MANIFEST_SHA, 'Completion deployed manifest')
            require(completion['case_fingerprint'] == hashlib.sha256(
                json.dumps(frozen, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
                'Frozen case fingerprint: ' + case_id)
            require(not (local_dir / 'failure.json').exists(), 'Failure marker: ' + case_id)
            require(completion['n_windows'] == 14981 and completion['n_issue_hours'] == 15733 and
                    completion['issues_per_window'] == 753 and completion['pairs_per_lead'] == 11280693 and
                    completion['actual_leads'] == list(range(25)), 'Completion geometry: ' + case_id)
            artifacts = {PurePosixPath(a['path']).name: a for a in completion['artifacts']}
            require(set(artifacts) == {'metrics.json', 'issue_statistics.npz'}, 'Completion artifacts')
            files = {}
            for key, name in [('completion', 'completion.json'), ('metrics', 'metrics.json')]:
                files[key] = binding(directory / name, local_dir / name)
            files['statistics'] = {'path': str(directory / 'issue_statistics.npz'),
                                   'sha256': artifacts['issue_statistics.npz']['sha256']}
            for name, key in [('metrics.json', 'metrics'), ('issue_statistics.npz', 'statistics')]:
                require(artifacts[name] == files[key], 'Completion artifact hash/path: ' + case_id)
            require(read(local_dir / 'metrics.json')['metrics'] == completion['metrics'],
                    'Completion metrics mismatch: ' + case_id)
            if variant == VARIANTS[0]:
                for key in ('completion', 'metrics', 'statistics'):
                    require(files[key] == original_old['files'][key], 'Historical original changed: ' + case_id)
                for name in ('model_start.json', 'environment.json'):
                    files[name.removesuffix('.json')] = binding(directory / name, local_dir / name)
                require(read(local_dir / 'model_start.json')['case_id'] == case_id and
                        read(local_dir / 'environment.json') == completion['environment'],
                        'Original start/environment: ' + case_id)
            else:
                admission_path = REMOTE / 'corrected_launch_001/admissions' / (case_id + '.json')
                admission_local = local_for(admission_path, root)
                admission = read(admission_local)
                require(admission['case_id'] == case_id and admission['state'] == 'PLAIN_EVALUATION_ACCEPTED' and
                        admission['manifest_sha256'] == MANIFEST_SHA and
                        admission['open_critical_important_findings'] == 0,
                        'Wrong or failed admission: ' + case_id)
                files['admission'] = binding(admission_path, admission_local)
                for key, name in [('preflight', 'preflight_receipt'),
                                  ('original_receipt', 'historical_original_receipt'),
                                  ('original_decision', 'original_result_decision'),
                                  ('review', 'review_record'),
                                  ('corrected_state_delivery', 'corrected_state_delivery')]:
                    b = admission[name]
                    require(digest(local_for(b['path'], root)) == b['sha256'],
                            'Admission source hash: ' + case_id + '/' + key)
                    files[key] = {'path': b['path'], 'sha256': b['sha256']}
                require(files['original_receipt'] == original_old['files']['completion'],
                        'Wrong same-model original: ' + case_id)
                preflight = read(local_for(files['preflight']['path'], root))
                require(preflight['case_id'] == case_id and
                        preflight['state'] == 'PLAIN_PREFLIGHT_PASS_PENDING_REVIEW' and
                        preflight['case_fingerprint'] == completion['case_fingerprint'] and
                        preflight['code_bindings'] == completion['code_bindings'] and
                        preflight['environment'] == completion['environment'] and
                        preflight['repeat_bitwise_equal'] is True and
                        preflight['time_mapping_passed'] is True and
                        preflight['test_tensor_reads'] == 0 and preflight['training_calls'] == 0,
                        'Own preflight mismatch: ' + case_id)
                require(len(preflight['checks']) == 2 and all(
                    check['effective_config'] == completion['effective_config'] and
                    check['time_mapping_passed'] is True for check in preflight['checks']),
                    'Effective config/preflight repeat mismatch: ' + case_id)
                require(admission['accepted_environment'] == completion['environment'],
                        'Admission environment mismatch: ' + case_id)
                require(admission['original_result_decision']['case_id'] == original_id and
                        admission['original_result_decision']['accepted'] is True and
                        admission['original_result_decision']['open_critical_count'] == 0 and
                        admission['original_result_decision']['open_important_count'] == 0,
                        'Original result not admitted: ' + case_id)
                decision = read(local_for(files['original_decision']['path'], root))
                accepted_rows = [r for r in decision['original_cases'] if r['case_id'] == original_id]
                require(len(accepted_rows) == 1 and accepted_rows[0]['accepted'] is True and
                        accepted_rows[0]['open_critical_count'] == 0 and
                        accepted_rows[0]['open_important_count'] == 0,
                        'Independent original decision mismatch: ' + case_id)
                for name in ('model_start.json', 'environment.json', 'running.json',
                             'import_ledger.json', 'load_ledger.json'):
                    files[name.removesuffix('.json')] = binding(directory / name, local_dir / name)
                validate_load_ledger(read(local_dir / 'load_ledger.json'), frozen, deployed)
                start = read(local_dir / 'model_start.json')
                original_start = read(local_for(str(REMOTE / 'plain_preflight_v1/numerical_impact/runs' /
                    (original_id + '__formal_attempt01') / 'model_start.json'), root))
                original_completion = read(local_for(original_old['files']['completion']['path'], root))
                require(start['case_id'] == case_id and
                        start['parameter_fingerprints'] == original_start['parameter_fingerprints'] and
                        start['input_fingerprints'] == completion['input_fingerprints'],
                        'Model-start identity: ' + case_id)
                require(read(local_dir / 'environment.json') == completion['environment'] and
                        completion['code_bindings'] == original_completion['code_bindings'],
                        'Environment/code mismatch: ' + case_id)
                for field in ('p', 'etpot', 'qobs', 'tm_hours'):
                    require(completion['input_fingerprints'][field] ==
                            original_completion['input_fingerprints'][field],
                            'Shared input mismatch: ' + case_id + '/' + field)
                required_states = ('6cf87e4f2cfc86975a33150516df0ffcc29bfde3d055bd0a2500ad65c4474df8'
                                   if variant == VARIANTS[1] else
                                   '9a1ac3c04927733bf7d54f297e470f1fe718ab3ccbfe01ebd7852db76a8c3a3c')
                require(completion['input_fingerprints']['states_all'] == required_states,
                        'Corrected-state distinction: ' + case_id)
            rows.append({'case_id': case_id, 'model': model, 'variant': variant,
                         'directory': str(directory), 'case_fingerprint': completion['case_fingerprint'],
                         'files': files})
    validate_rows(rows)
    return {'schema': 'corrected_fourteen_saved_statistics_audit_v1', 'remote_root': str(REMOTE),
            'deployed_manifest': {'path': str(REMOTE / 'plain_preflight_v1/deployed_manifest.json'),
                                  'sha256': MANIFEST_SHA},
            'old_audit_manifest': {'path': str(REMOTE / 'completed_ten_audit_001/audit_manifest_001.json'),
                                   'sha256': OLD_AUDIT_SHA},
            'contract': {'path': str(REMOTE / 'completed_ten_audit_001/expected_formal_contract_001.json'),
                         'sha256': CONTRACT_SHA},
            'base_script_sha256': BASE_SHA, 'ten_helper_sha256': TEN_SHA,
            'geometry': old['geometry'], 'cases': rows,
            'excluded': ['main_seed42__original_outlet_original_states',
                         'adaptive__original_outlet_original_states']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--local-root', required=True, type=Path)
    parser.add_argument('--runtime-root', default=str(REMOTE))
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    require(not args.output.exists(), 'Manifest output already exists')
    manifest = build(args.local_root, args.runtime_root)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x', encoding='utf-8') as f:
        json.dump(manifest, f, indent=2, allow_nan=False)
        f.write('\n')
    print(digest(args.output))


if __name__ == '__main__':
    main()
