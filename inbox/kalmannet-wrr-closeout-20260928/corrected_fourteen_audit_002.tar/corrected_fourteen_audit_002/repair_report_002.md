# 保存统计数组审计：第二轮有限修复补充报告

结论：作业231144在第一项修正案例、打开其统计数组之前，因访问指标记录不存在的顶层 `case_id` 字段退出，状态为失败、退出码1:0。这是指标文件结构适配错误；目前不能据此接受十四项修正结果。作业此前已完成一项原设置数组检查，其结果仍仅为该失败作业中保留的部分证据。

失败依据：未改动的 `hpc/corrected_fourteen_audit_receipts_001/failure.json` 与 `audit.json` 均记录 `current_case=main_seed43__corrected_outlet_original_states`、`failed_check='case_id'` 和审计器第232行的 `KeyError`；两份文件的字节指纹均为 `36b16261b2fc86ef9e5d788dda274abfeb31b74c88d2915b1eaaa1af97e9a844`。本地逐案读取清单所指向的二十一份指标记录，二十一份均无顶层 `case_id`，而对应完成记录与运行记录均含正确案例编号。

修复仅涉及 `audit_corrected_fourteen.py` 与其测试：指标记录允许按实际结构省略顶层编号，但若该字段存在必须与具名案例一致；同时要求完成记录的案例编号及所列指标文件、统计数组的路径与字节指纹均匹配清单，保存指标、输入指纹、有效配置和六项几何字段与完成记录一致。修正案例还核对有指纹绑定的 `running.json` 中的案例编号、正式阶段和冻结清单指纹。身份检查未减弱，也未改变后续数组、数值或共同域检查。

修复前本目录十二个顶层文件已复制到新建的 `repair_002_before`，复制前后逐一重算指纹一致；原失败证据、第一轮修复报告和独立复核未修改。现有清单 `audit_manifest_001.json` 指纹仍为 `f14eb6158b7bfaede081d1189dba7c75046b5edb1d79df661d60f219a8c24536`，启动脚本指纹仍为 `54960dc0184262d9c0a77eca6540710de2b8f9976bda57bea964b5b147caf237`，无需更新清单固定值。

测试命令：`python -X utf8 -m pytest -q docs/plans/wrr-hamid-all-comments-completion-20260928-v1/hpc/corrected_fourteen_audit_001/test_audit_corrected_fourteen.py`。最终输出：`31 passed in 0.66s`。保留第一轮28项；新增一项使用二十一份具名完成、指标及运行记录，并逐文件核对指标、完成及运行记录指纹，到统计数组读取前逐案通过；另外两项分别证明错误的可选指标编号和错误运行记录编号会被拒绝。`python -X utf8 -m py_compile` 对审计器及测试通过。首次运行测试时，仅运行记录错误编号负例的异常文本匹配过窄，得到 `1 failed, 30 passed`；修正测试匹配后全数通过，生产检查逻辑未因该测试失败而放宽。

新文件指纹：`audit_corrected_fourteen.py` 为 `f1078493f5a68dee0ee9fb0b3d5c140952096200154e7dc18b6860424164112c`；`test_audit_corrected_fourteen.py` 为 `c94ac8c0ebfd49b87722b487608bd8a78674c1a2bfd2893f1cd9725ed18bb93f`；两文件差异 `repair_002.diff` 为 `464743f3eb95cfafd3bf652a98d38e0ce653befc48796cbbbd6745645198a2e8`，已通过反向应用检查。清单构造器未变，指纹为 `c0bbcc639d92c76ebcfbaf175d39addcefc284829c499515e776a72eb51d778b`。

本轮为既定两次技术修复中的第二次。未重新运行真实数组、远程命令或模型，未提交作业。请先对本次两个文件差异作范围限定的独立审核；若仍发现影响结果的运行错误，应保留失败和当前证据，由控制者重新决定，不再依本方案追加第三次修复或重试。
