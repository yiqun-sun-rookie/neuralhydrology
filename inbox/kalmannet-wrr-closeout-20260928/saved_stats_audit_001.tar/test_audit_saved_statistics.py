import hashlib
from pathlib import Path
import tempfile
import unittest
import zipfile

import numpy as np

from audit_saved_statistics import calculate, metric_difference, saved_arrays, same_domain


class SavedStatisticsTests(unittest.TestCase):
    def setUp(self):
        self.y = np.array([1., 2., 4., 3.])
        self.p = np.array([.5, 2.5, 3.5, 4.])
        self.s = np.stack((np.ones(4), self.y, self.y**2, self.p, self.p**2,
                           self.p*self.y, (self.p-self.y)**2, abs(self.p-self.y)), axis=-1)[:, None, :]

    def test_direct_predictions_all_seven_metrics(self):
        y, p = self.y, self.p
        r = np.corrcoef(p, y)[0, 1]
        alpha, beta = p.std()/y.std(), p.mean()/y.mean()
        expected = dict(nse=[1-((p-y)**2).sum()/((y-y.mean())**2).sum()],
                        rmse=[np.sqrt(((p-y)**2).mean())], mae=[abs(p-y).mean()],
                        correlation=[r], variability_ratio=[alpha], bias_ratio=[beta],
                        kge=[1-np.sqrt((r-1)**2+(alpha-1)**2+(beta-1)**2)])
        self.assertLess(max(metric_difference(calculate(self.s), expected).values()), 1e-14)

    def test_duplicate_samples_invariant(self):
        self.assertLess(max(metric_difference(calculate(self.s), calculate(self.s*7)).values()), 1e-14)

    def test_zero_variance_rejected(self):
        self.s[:, :, 2] = self.s[:, :, 1]**2 / self.s[:, :, 0]
        self.s[:, :, 1:3] = 1
        with self.assertRaises(ValueError):
            calculate(self.s)

    def test_negative_error_rejected(self):
        self.s[:, :, 6] = -1
        with self.assertRaises(ValueError):
            calculate(self.s)

    def test_nonfinite_metric_rejected(self):
        self.s[0, 0, 3] = np.nan
        with self.assertRaises(ValueError):
            calculate(self.s)

    def test_missing_metric_rejected(self):
        with self.assertRaises(ValueError):
            metric_difference({'nse': [1]}, calculate(self.s))

    def test_same_domain_ignores_prediction_but_not_observation(self):
        a = dict(stats=self.s, issue_hours=np.arange(4), observation=self.y, actual_leads=np.array([0]))
        b = {k: v.copy() for k, v in a.items()}
        b['stats'][:, :, 6] += 1
        self.assertTrue(same_domain(a, b))
        b['observation'][0] += 1
        self.assertFalse(same_domain(a, b))

    def npz(self, directory, modification=None):
        arrays = dict(stats=self.s.copy(), observation=self.y.astype(np.float32),
                      issue_hours=np.arange(4, dtype=np.float64), actual_leads=np.array([0], dtype=np.int64))
        if modification:
            modification(arrays)
        path = Path(directory)/'fixture.npz'
        np.savez_compressed(path, **arrays)
        return path, hashlib.sha256(path.read_bytes()).hexdigest()

    def test_npz_positive(self):
        with tempfile.TemporaryDirectory() as temp:
            path, digest = self.npz(temp)
            result = saved_arrays(path, digest, 4, 1, 1, 4)
            self.assertTrue(np.array_equal(result['stats'], self.s))

    def test_npz_identity_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            path, _ = self.npz(temp)
            with self.assertRaises(ValueError):
                saved_arrays(path, '0'*64, 4, 1, 1, 4)

    def test_wrong_observed_moment_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            def change(a):
                a['stats'][0, 0, 1] += .01
            path, digest = self.npz(temp, change)
            with self.assertRaises(ValueError):
                saved_arrays(path, digest, 4, 1, 1, 4)

    def test_wrong_count_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            def change(a):
                a['stats'][0, 0, 0] = 2
            path, digest = self.npz(temp, change)
            with self.assertRaises(ValueError):
                saved_arrays(path, digest, 4, 1, 1, 4)

    def test_object_array_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            path, digest = self.npz(temp, lambda a: a.update(observation=np.array(['x']*4, dtype=object)))
            with self.assertRaises(ValueError):
                saved_arrays(path, digest, 4, 1, 1, 4)

    def test_archive_extra_member_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            path, _ = self.npz(temp)
            with zipfile.ZipFile(path, 'a') as archive:
                archive.writestr('../bad.npy', 'not an array')
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            with self.assertRaises(ValueError):
                saved_arrays(path, digest, 4, 1, 1, 4)


if __name__ == '__main__':
    unittest.main()
