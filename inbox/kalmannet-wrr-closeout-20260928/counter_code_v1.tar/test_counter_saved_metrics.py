import unittest
import numpy as np

from counter_saved_metrics import compare, metric_vector, target_arrays, CONVERSION


def check_identical_arrays_have_zero_differences():
    obs = np.arange(1, 61, dtype=np.float32).reshape(20, 3)
    report = compare(dict(plain_a=obs, counted_a=obs.copy()), obs)
    assert all(value == 0 for value in report['max_absolute_metric_difference'].values())


def check_shift_metrics_match_direct_formula():
    obs = np.arange(1, 61, dtype=np.float32).reshape(20, 3)
    result = metric_vector(obs + 0.25, obs)
    np.testing.assert_allclose(result['rmse_m3s'], 0.25 * CONVERSION)
    np.testing.assert_allclose(result['mae_m3s'], 0.25 * CONVERSION)
    np.testing.assert_allclose(result['nse'], 1 - 20 * 0.25 ** 2 / ((obs - obs.mean(axis=0)) ** 2).sum(axis=0))


def check_prediction_difference_bound():
    obs = np.arange(1, 61, dtype=np.float32).reshape(20, 3)
    result = compare(dict(plain_a=obs, counted_a=obs + 0.125), obs)
    assert result['error_metric_difference_bound_m3s'] == 0.125 * CONVERSION


def check_window_overlap_is_retained():
    target, hours = target_arrays(np.arange(20), np.arange(20), windows=3, issues=4, leads=3)
    assert target.shape == (12, 3)
    assert np.array_equal(target[:, 0], [0, 1, 2, 3, 1, 2, 3, 4, 2, 3, 4, 5])
    assert np.array_equal(target, hours)


def check_wrong_time_mapping_fails():
    with unittest.TestCase().assertRaisesRegex(ValueError, 'Target hour'):
        target_arrays(np.arange(20), np.arange(20) * 2, windows=3, issues=4, leads=3)


def check_nonfinite_values_fail():
    for bad in (np.nan, np.inf):
        obs = np.arange(1, 7, dtype=float).reshape(3, 2)
        pred = obs.copy()
        pred[0, 0] = bad
        with unittest.TestCase().assertRaisesRegex(ValueError, 'Nonfinite'):
            metric_vector(pred, obs)


def check_degenerate_observation_fails():
    with unittest.TestCase().assertRaisesRegex(ValueError, 'Degenerate'):
        metric_vector(np.arange(1, 7).reshape(3, 2), np.ones((3, 2)))


class SavedMetricsTests(unittest.TestCase):
    pass


for _name, _function in tuple(globals().items()):
    if _name.startswith('check_'):
        setattr(SavedMetricsTests, 'test_' + _name[6:], lambda self, function=_function: function())
del _name, _function


if __name__ == '__main__':
    unittest.main()
