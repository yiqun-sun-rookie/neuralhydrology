"""Score only saved validation predictions; never constructs or calls a model."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import pickle
import platform
import sys
import types
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

CONVERSION = 957000 / 3600
PHASES = ('plain_a', 'counted_a')
OLD_ROOT = Path('/data1/home/sunyiq/kalmannet_wrr_counter_diagnosis_20260928_v1')
TRAINING_ROOT = Path('/data1/home/sunyiq/kalmannet_hamid_weights_20260923_v1')
VALIDATION_HASH = '2e195fc974b5cc8cdb35df3cb7fd72a202af033ecc415acc03a87020b00bd403'
DATASET_SOURCE_HASH = '8389e6d1fc24ca46fc395ebe102ab685436409be03dd787ba2b46eca56e79cb4'
PREDICTION_HASHES = {
    'plain_a': '704a3361044861a9134517e3b3ee7da4733e56fa182efe6714bdc35ab2abd194',
    'counted_a': 'd6a712b9de9359b15acdeac8fdaeb5b21dfc14ddb8a65e4f2b7e6d44f55da318',
}
TARGET_HASHES = {
    'target_observations': 'da81e10b8a8a305619c4743a9ec869861898c88a5198d80afa4e6341298d7543',
    'target_hours': 'cbf8765a2e523b37388aa8d6b78f6152bb85299d77e9a4c5bbdf9d9c104515dd',
}


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def metric_vector(prediction, observation):
    p = np.asarray(prediction, dtype=np.float64)
    y = np.asarray(observation, dtype=np.float64)
    if p.shape != y.shape or p.ndim != 2 or p.shape[0] < 2:
        raise ValueError('Matched two-dimensional predictions and observations required')
    if not np.isfinite(p).all() or not np.isfinite(y).all():
        raise ValueError('Nonfinite input')
    pc, yc = p - p.mean(axis=0), y - y.mean(axis=0)
    vp, vy = np.square(pc).sum(axis=0), np.square(yc).sum(axis=0)
    if np.any(vp <= 0) or np.any(vy <= 0) or np.any(y.mean(axis=0) == 0):
        raise ValueError('Degenerate moment; do not silently exclude')
    r = (pc * yc).sum(axis=0) / np.sqrt(vp * vy)
    alpha, beta = np.sqrt(vp / vy), p.mean(axis=0) / y.mean(axis=0)
    error = p - y
    return dict(nse=1 - np.square(error).sum(axis=0) / vy,
                rmse_m3s=np.sqrt(np.square(error).mean(axis=0)) * CONVERSION,
                mae_m3s=np.abs(error).mean(axis=0) * CONVERSION,
                kge=1 - np.sqrt(np.square(r - 1) + np.square(alpha - 1) + np.square(beta - 1)),
                correlation=r, variability_ratio=alpha, bias_ratio=beta)


def target_arrays(observation, hours, windows=256, issues=753, leads=48):
    obs, tm = np.asarray(observation).reshape(-1), np.asarray(hours).reshape(-1)
    ids = (np.arange(windows)[:, None] + np.arange(issues)[None, :]).reshape(-1)
    indexes = ids[:, None] + np.arange(leads)[None, :]
    if indexes.max() >= len(obs) or len(tm) != len(obs):
        raise ValueError('Target outside source timeline')
    target_hours = tm[indexes]
    if not np.all(target_hours.astype(np.float64) - tm[ids, None] == np.arange(leads)[None, :]):
        raise ValueError('Target hour is not issue plus lead')
    return obs[indexes], target_hours


def compare(predictions, observation):
    if set(predictions) != set(PHASES):
        raise ValueError('Expected original and counter phase only')
    if predictions['plain_a'].shape != predictions['counted_a'].shape:
        raise ValueError('Phase shapes differ')
    scored = {phase: metric_vector(p, observation) for phase, p in predictions.items()}
    difference = {k: scored['counted_a'][k] - scored['plain_a'][k] for k in scored['plain_a']}
    maximum = float(np.max(np.abs(predictions['counted_a'].astype(np.float64) - predictions['plain_a'])))
    bound = maximum * CONVERSION
    if any(np.max(np.abs(difference[k])) > bound + 1e-12 for k in ('rmse_m3s', 'mae_m3s')):
        raise ValueError('Error metric exceeds mathematical prediction-difference bound')
    rounding = {}
    for key in difference:
        digits = 3 if key not in ('rmse_m3s', 'mae_m3s') else 2
        rounding[key] = dict(decimal_places=digits, comparison_only_not_claim_of_paper_precision=True,
                             changed_leads=[int(i) for i, (a, b) in enumerate(zip(scored['plain_a'][key], scored['counted_a'][key]))
                                            if format(float(a), f'.{digits}f') != format(float(b), f'.{digits}f')])
    return dict(metrics={p: {k: v.tolist() for k, v in items.items()} for p, items in scored.items()},
                counter_minus_plain={k: v.tolist() for k, v in difference.items()},
                max_absolute_metric_difference={k: float(np.max(np.abs(v))) for k, v in difference.items()},
                max_prediction_difference_mmh=maximum, error_metric_difference_bound_m3s=bound,
                display_sensitivity=rounding)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    sys.dont_write_bytecode = True
    import torch
    if torch.cuda.is_initialized():
        raise ValueError('Saved-array scoring must be CPU only')
    torch.set_num_threads(4)
    formal = TRAINING_ROOT / 'formal_package_v3'
    manifest = read(formal / 'manifest.json')
    dataset_path = formal / 'sources/dataset.py'
    if sha(dataset_path) != DATASET_SOURCE_HASH or manifest['files']['sources/dataset.py'] != DATASET_SOURCE_HASH:
        raise ValueError('Dataset class source changed')
    spec = importlib.util.spec_from_file_location('frozen_saved_metrics_dataset', dataset_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    class Compat(pickle.Unpickler):
        def find_class(self, module_name, class_name):
            if module_name == 'src.modules.data_preprocessor.windowed_time_series' and class_name == 'WindowedTimeSeriesDataset':
                return module.WindowedTimeSeriesDataset
            return super().find_class(module_name, class_name)
    adapter = types.ModuleType('saved_metrics_compat')
    adapter.Unpickler, adapter.load, adapter.loads = Compat, pickle.load, pickle.loads
    val = TRAINING_ROOT / 'data/val_win800_20070527_04-20090314_13.pt'
    if sha(val) != VALIDATION_HASH:
        raise ValueError('Validation source changed')
    ds = torch.load(val, map_location='cpu', weights_only=False, pickle_module=adapter)
    if not isinstance(ds, module.WindowedTimeSeriesDataset) or len(ds.qobs) != 15778:
        raise ValueError('Validation class or row count differs')
    target, target_hours = target_arrays(ds.qobs.numpy(), ds.tm_hours.numpy())
    predictions, bindings = {}, {}
    for phase in PHASES:
        run = OLD_ROOT / 'runs' / phase
        receipt = read(run / 'completion.json')
        mapping = read(run / 'validation_time_mapping.json')
        if receipt['phase'] != phase or receipt['case_id'] != 'main_seed42__original_outlet_original_states':
            raise ValueError('Saved phase identity differs')
        if receipt['state'] != 'HPC_CROSS_ENV_VALIDATION_DIAGNOSTIC_COMPLETE_NOT_LOCAL_ADMISSION' or receipt['source_bindings']['validation'] != VALIDATION_HASH:
            raise ValueError('Saved receipt state or validation identity differs')
        if receipt['model_inference_calls'] != 1 or receipt['training_calls'] != 0 or receipt['test_tensor_reads'] != 0:
            raise ValueError('Saved phase scope differs')
        if not all(receipt.get(k) for k in ('inputs_unchanged', 'parameters_unchanged', 'time_mapping_passed')):
            raise ValueError('Saved phase not accepted')
        for key, arr in (('target_observations', target), ('target_hours', target_hours)):
            record = mapping['arrays'][key]
            if list(arr.shape) != record['shape'] or str(arr.dtype) != record['dtype'] or hashlib.sha256(arr.tobytes()).hexdigest() != TARGET_HASHES[key] or record['sha256'] != TARGET_HASHES[key]:
                raise ValueError('Reconstructed target differs from prior mapping: ' + key)
        path = run / 'predictions.npy'
        expected = receipt['arrays']['predictions']['file_sha256']
        if sha(path) != PREDICTION_HASHES[phase] or expected != PREDICTION_HASHES[phase]:
            raise ValueError('Saved predictions changed')
        prediction = np.load(path, mmap_mode='r', allow_pickle=False)
        if prediction.shape != (256 * 753, 1, 48) or prediction.dtype != np.float32 or not np.isfinite(prediction).all():
            raise ValueError('Prediction dtype/shape/finite check failed')
        predictions[phase] = prediction[:, 0, :25]
        bindings[phase] = dict(predictions_path=str(path), predictions_sha256=expected,
                               completion_sha256=sha(run / 'completion.json'), mapping_sha256=sha(run / 'validation_time_mapping.json'))
    result = compare(predictions, target[:, :25])
    result.update(state='SAVED_VALIDATION_ARRAY_METRICS_COMPLETE', utc=datetime.now(timezone.utc).isoformat(),
                  windows=256, window_hours=800, pair_count_per_lead=256 * 753, leads=list(range(25)),
                  pair_count_interpretation='Overlapping issue-target pairs, not independent samples',
                  software_versions=dict(python=platform.python_version(), numpy=np.__version__, torch=torch.__version__),
                  validation_sha256=VALIDATION_HASH, source_bindings=bindings,
                  model_calls_this_run=0, training_calls_this_run=0, test_tensor_reads_this_run=0,
                  cuda_initialized=torch.cuda.is_initialized(), script_sha256=sha(__file__),
                  limitation='Only these saved validation predictions; no full-test, ranking, significance or true outlet-formula conclusion.')
    with (output / 'metrics.json').open('x', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
    print(json.dumps({k: result[k] for k in ('state', 'max_absolute_metric_difference', 'display_sensitivity', 'model_calls_this_run')}, indent=2))


if __name__ == '__main__':
    main()
