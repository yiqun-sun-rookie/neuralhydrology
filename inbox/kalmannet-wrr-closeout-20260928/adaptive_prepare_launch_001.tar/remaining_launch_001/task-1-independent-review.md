# Independent startup review: adaptive selection and two preflights

Date: 2026-09-28. Scope: local startup code review only.

## Verdicts

- Specification compliance: PASS for the delivered launcher and immutable-input list.
- Code quality and safety: PASS WITH ONE MINOR TEST-COVERAGE NOTE. No critical or important findings; no startup-blocking change identified.
- This is not acceptance of either actual preflight, permission for a formal test evaluation, or a scientific result. Remote deployment identity, resource availability, and actual receipts remain unverified here.

## Evidence and reasoning

The brief, implementation report, review patch, actual launcher, actual checksum list, and actual test file were read completely. The four files represented in the patch match the corresponding current files after line-ending normalization. Actual local SHA-256 values below match the implementation report and the launch manifest where applicable. All five completion-file digests were independently computed from the prescribed local accepted-receipt directory and match the launch manifest.

The launcher calls the frozen driver exactly three times in the required sequence: `freeze-selection` over the five required validation directories, then `preflight` for `matched_fixed_test`, then `preflight` for `matched_selected_test`. Arguments bind the prescribed protocol, path map, code acceptance, newly frozen selection, and exclusive output names. It contains no `run`, `summarize-test`, scheduler query, submission, cleanup, retry, or previous-failure replay command.

The frozen driver's relevant source was inspected without importing or executing it. `freeze_selection` checks five complete validation identities, validates completion-bound metric/statistics hashes, and reads saved validation statistics. `preflight` explicitly loads `datasets['validation']`; its dispatch installs the validation-only load guard. Both bound test configurations specify 48 forecast positions in the protocol. The driver creates output directories with `exist_ok=False` and JSON files with exclusive `x` mode. Therefore the unchanged commands preserve the 48-position, validation-data-only preflight contract; this source finding does not prove a future execution passes it.

The launch manifest binds twelve inputs, including the launcher, original package manifest, driver, protocol, acceptance, path map, saved-statistics review, and five completion files. The launcher checks exact required membership and row count, then checks all listed digests and the original package manifest before its started marker or driver call. The completion files transitively bind metrics and saved statistics through the frozen driver. The controller must retain the reviewed manifest digest during deployment; this is an integrity check with a trusted deployment manifest, not protection against someone deliberately rewriting both files and their manifest.

All three output locations and the started marker are refused before computation, including dangling symbolic links. The marker additionally uses shell `noclobber`, so simultaneous copies of this launcher cannot both pass marker creation. The marker is retained after a computation failure. Direct commands and loop-body driver calls are covered by `set -e`; checksum subprocess errors propagate; `pipefail` is enabled. No conditional wrapper suppresses driver failures. The frozen driver's exclusive directory creation supplies the final output-existence guard.

Scheduler settings request partition `hgpu2p`, one node, one task, four processor cores, one graphics processor, six hours, exclusion of `ngu002`, and no requeue; no memory override appears. Logs point to the required parent isolated-root logs directory. Conda environment and all five environment variables match `validation_five.slurm`, and unset-variable mode is not enabled before Conda.

## Findings

Critical: none. Important: none.

Minor: `test_adaptive_prepare.py`, `test_exact_inventory_and_command_order`, checks membership of the five validation directories by iterating the expected `CASES` tuple. That assertion does not itself detect a reordered, duplicated, or extra validation-directory argument, and the command checks are substring-based rather than full argument-vector comparisons. The actual reviewed launcher has exactly the required five entries in order, and the frozen driver rejects incorrect count/identity. This is a regression-test precision limitation, not a defect in the delivered launch behavior. A future test improvement could compare the complete captured argument vector to the expected list.

## Verification limits

No reported tests were rerun: source inspection and hash/snapshot comparisons resolved the startup questions without model execution. The implementer's report records Bash syntax success and five passing dummy-input shell-harness tests; those execution claims are attributed to that report, not independently reproduced here. The test file was checked to use temporary fixtures and stub Python/Conda, with no model/data imports or remote execution. No research data were deserialized, no remote or mailbox tool was used, and no commit or worktree was created. The only review write is this new report.

Before later formal-test admission, actual completion, load/import ledgers, effective configuration, 48-position outputs, repeated-result equality, environment, and selected-validation bindings still require the existing independent acceptance process.

## Actual SHA-256 values

Paths below are relative to `docs/plans/wrr-hamid-all-comments-completion-20260928-v1`.

| File | SHA-256 |
|---|---|
| hpc/remaining_launch_001/task-1-brief.md | fb79c5faedc47755b17ba1e3a9ff024bf024250a4c9f2aa37ea1806beb0e2f04 |
| hpc/remaining_launch_001/task-1-report.md | 28c831861396ed4eae9aefb2eb435545b4ac6598e7cabaef2b90959e130700af |
| hpc/remaining_launch_001/task-1-review.patch | d98db877e764cbfb6df51d55fcf7ed174f9383eac008826877174f9bbf3088ed |
| hpc/remaining_launch_001/adaptive_prepare.slurm | 9ee712f63833641314af427915bec976b6283ec4db320729ba3919b0ef281ad2 |
| hpc/remaining_launch_001/launch_inputs.sha256 | 379533b0cde6bd48729947f4abc4406b8c5bab4e237727f653de5437f6d44161 |
| hpc/remaining_launch_001/test_adaptive_prepare.py | 3cf9c5e40d04a3f998ebfcba5fe851cde34a8a8c35abe13307e68c1fbc1f3d7a |
| adaptive_comparison/adaptive_driver.py | 9b9c3addbae9ba969df534b27a5968b47a4855b93fff9072923973ae60d839a6 |
| adaptive_comparison/matched_protocol.json | 131182e1e579fb08ea78813c018f552462a77cf57591973d175d0b3d215ce534 |
| adaptive_comparison/code_acceptance.json | e805aa5ccfeb4fe2bd78f3468c68e8980325c398d78cd239e2ed2842c4d00719 |
| hpc/adaptive_preflight_package_001/package_files.sha256 | fdcc10d717bd49c6f8314554e8a123ebbb01988971eb44c160478e9b2df4e15b |
| hpc/adaptive_preflight_package_001/path_map.json | 55c5b8c8eef1fb0ee3781c20260de45f8775823a746748c83d9c9fb4058f0af5 |
| provenance/saved_statistics_and_validation_review_001.md | 77505117c252ed14c1eaf112c0a2d5f49fab3d4b4e6b0ceb9a52c49739032a32 |
| hpc/adaptive_formal_launch_001/validation_five.slurm | 5eb8ca1cb749bf1fae756e388ee04368a28a86c5237550097a79e0a62a5ebd58 |

Completion-file paths below are relative to `hpc/adaptive_formal_receipts_001/adaptive_comparison/runs` within that same root.

| Completion file | SHA-256 |
|---|---|
| historical_r001_validation__formal_attempt01/completion.json | c97632bee2493e96e4944a4e7e7797c0f2134d1d16d82e66c6218fbe6d8d61c2 |
| historical_r002_validation__formal_attempt01/completion.json | bba655e26a1828899e6d539b4bafc8f2c74a3655e72578c5c660eeabb18b8d9b |
| matched_fixed_validation__formal_attempt01/completion.json | 659eede28457b537ca39995ed1168bebed862e4d9de795b0ac09675551ac9b5f |
| matched_r001_validation__formal_attempt01/completion.json | 1dbcd145e0dee7c2caf6051fa2d6d8e315eeabf6ee36236a0619d146b40b0d04 |
| matched_r002_validation__formal_attempt01/completion.json | 5239981fa272b8240a1bbffc601b1d6257641e970c074ade2e62c1729098f375 |
