# 三方法保存统计分析：技术修复第一轮

结论：已只修复独立代码审核指出的两个重要问题和一个次要问题。24项本地合成检查、Python语法检查及启动文件语法检查均通过；**没有读取实际统计数组、提交集群作业或验收科学结果**。修复尚须新的独立聚焦复核。

修复前，已将原分析程序、测试、清单生成器、启动器、运行清单002、任务报告、原完整补丁及独立代码审核原件复制至独占目录 `repair_001_before/`，八份逐一比较安全散列算法256位指纹完全相等。原 `analysis_manifest_002.json`、`proofs/`、追加准入和先前审核均未改动。

## 有界改动

1. 来源核验逐文件直接登记到调用方持有的来源台账。每行先记录路径和预期指纹，再写明 `VERIFIED`、`HASH_MISMATCH`、`MISSING_OR_UNSAFE` 或 `UNREADABLE` 与实际读取结果。第二个文件失败时，首个文件已核验行与第二个失败行都保留。结束时每行单独重算；缺失、不可读或内容变化分别记为 `MISSING`、`UNREADABLE`、`CHANGED`，单个重算异常不会覆盖原始分析错误。失败输出仍为有限数有效 JSON，含原始错误、已完成摘要和来源台账，`accepted=false`，无成功标记。
2. 启动器使用 `set -eo pipefail`，使外部环境激活脚本可引用可选未定义变量；原两个必需参数检查不变，新增具名 `SLURM_JOB_ID` 检查。四核、`hgpu2p`、排除 `ngu002`、十分钟、无显卡、独占目录及其他启动路径未改。
3. 敏感性点指标计算完成后立即登记到调用方报告；每个块长的完整区间摘要也立即登记。后续块长失败仍使整体分析失败，前面完成的摘要进入 `failure.json`；不重抽、不删除坏抽样、不把部分结果写成科学接受。

## 检查与身份

先新增五项针对性检查并观察失败，再作上述最小修改。最终命令输出：

```text
python -m pytest -q test_analyze_three_methods.py
........................                                                 [100%]
24 passed in 1.58s

python -m py_compile analyze_three_methods.py build_analysis_manifest.py test_analyze_three_methods.py
exit 0

bash -n launch_three_methods.slurm
exit 0
```

新增检查涵盖完整失败路径中第二个来源指纹错误且保留前一行、失败处理中来源重读不可读仍写原错误、首块完成后第二块抽样退化仍保留区间与敏感性点指标，以及启动参数/作业编号缺失被拒绝、环境激活的可选未定义变量可通过。原19项仍通过。

| 文件 | 修复后 SHA-256 |
|---|---|
| `analyze_three_methods.py` | `af72024f2abf38330afe9fc27dbfb9c617acd1fc32b1a0e6ad9c3a1aebb7c786` |
| `test_analyze_three_methods.py` | `9a9e967ed140c76bd905e095e3d40021f0afdfb64877431fc57583195ad56586` |
| `build_analysis_manifest.py`（未改） | `5f2954cd6ba6ccda0e874dae5d4372a9f4683b63a6d706c517c874acd0b84de7` |
| `launch_three_methods.slurm` | `c1f188735f86c548ada35bd7460d040076d536af1750820da41a7c1b3e8c253b` |
| 新 `analysis_manifest_003.json` | `4cf03350dc3292851cb81769453b8690ea887a807bc43773431e77adc20ef7b9` |
| 保留的 `analysis_manifest_002.json` | `d99a2edb10b8a4201da4f67d9c310441e8bd96e978c6f9183dfde81817eeb390` |

`analysis_manifest_003.json` 绑定修复后程序、测试、未改的清单生成器及修复后启动器，并继续绑定原三个案例、冻结辅助程序、追加准入及全部证明文件。它只供独立复核后的部署候选使用；实际数组与配对区间仍未生成。修复差异见 `repair_001.patch`。
