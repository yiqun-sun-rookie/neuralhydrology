"""Build one pinned runtime manifest only after the controller's admission exists.

This writes locally in the assigned directory; it does not deploy or submit.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path, PurePosixPath

from analyze_three_methods import (AUDIT_SHA, BASE_SHA, CASE_IDS, DIAGNOSTIC_SHA,
                                   DIAGNOSTIC_REVIEW_SHA, DRAWS_SHA, EXPECTED_GEOMETRY,
                                   PROOF_HASHES, require, sha, validate_admission, write_json)

HERE = Path(__file__).resolve().parent
PLAN = HERE.parents[1]
AUDIT = PLAN / 'hpc/completed_ten_audit_001/audit_manifest_001.json'
LOCAL_PROOFS = HERE / 'proofs'
BASE = PLAN / 'hpc/saved_stats_audit_001/audit_saved_statistics.py'
DRAWS = PLAN.parent / 'wrr-hamid-evaluation-20260927-v1/analyze_evaluation.py'
REMOTE = PurePosixPath('/data1/home/sunyiq/kalmannet_wrr_closeout_20260928_v1')
REMOTE_JOB = REMOTE / 'three_method_analysis_002'
REMOTE_CODE = REMOTE_JOB / 'code'
REMOTE_PROOFS = REMOTE_JOB / 'proofs'


def bound(local, remote, expected=None):
    digest = sha(local)
    if expected is not None:
        require(digest == expected, 'Local frozen source hash changed: ' + str(local))
    return {'path': str(remote), 'sha256': digest}


def build(admission_local, scope_review_local):
    require(sha(AUDIT) == AUDIT_SHA and sha(LOCAL_PROOFS / 'audit_manifest_001.json') == AUDIT_SHA,
            'Frozen audit manifest hash changed')
    audit = json.loads(AUDIT.read_text(encoding='utf-8'))
    require(audit['geometry'] == EXPECTED_GEOMETRY and audit['remote_root'] == str(REMOTE),
            'Frozen audit geometry/root changed')
    review_binding = bound(scope_review_local, REMOTE_PROOFS /
                           'three_method_scope_independent_review_002.md')
    admission = json.loads(Path(admission_local).read_text(encoding='utf-8'))
    validate_admission(admission, AUDIT_SHA, DIAGNOSTIC_SHA, review_binding['path'])
    require(admission['independent_scope_review'] == review_binding,
            'Independent review content hash mismatch in admission')
    cases = [{key: case[key] for key in ('case_id', 'kind', 'directory', 'files')}
             for cid in CASE_IDS for case in audit['cases'] if case['case_id'] == cid]
    require([case['case_id'] for case in cases] == list(CASE_IDS),
            'Frozen audit case identities missing/duplicated')
    proofs = {
        'audit_manifest': bound(LOCAL_PROOFS / 'audit_manifest_001.json',
                                REMOTE_PROOFS / 'audit_manifest_001.json', AUDIT_SHA),
        'audit_saved_statistics': bound(BASE, REMOTE_CODE / 'audit_saved_statistics.py', BASE_SHA),
        'analyze_evaluation': bound(DRAWS, REMOTE_CODE / 'analyze_evaluation.py', DRAWS_SHA),
        'program': bound(HERE / 'analyze_three_methods.py', REMOTE_CODE / 'analyze_three_methods.py'),
        'test': bound(HERE / 'test_analyze_three_methods.py', REMOTE_CODE / 'test_analyze_three_methods.py'),
        'manifest_builder': bound(__file__, REMOTE_CODE / 'build_analysis_manifest.py'),
        'launcher': bound(HERE / 'launch_three_methods.slurm', REMOTE_CODE / 'launch_three_methods.slurm'),
        'historical_acceptance': bound(LOCAL_PROOFS / 'result_acceptance_001.json',
                                       REMOTE_PROOFS / 'result_acceptance_001.json',
                                       PROOF_HASHES['result_acceptance_001.json']),
        'historical_review': bound(LOCAL_PROOFS / 'independent_result_review.md',
                                   REMOTE_PROOFS / 'independent_result_review.md',
                                   PROOF_HASHES['independent_result_review.md']),
        'diagnostic': bound(LOCAL_PROOFS / 'diagnostic.json',
                            REMOTE_PROOFS / 'diagnostic.json', DIAGNOSTIC_SHA),
        'diagnostic_review': bound(LOCAL_PROOFS / 'domain_diagnostic_independent_review_001.md',
                                   REMOTE_PROOFS / 'domain_diagnostic_independent_review_001.md',
                                   DIAGNOSTIC_REVIEW_SHA),
        'audit_failure': bound(LOCAL_PROOFS / 'failure.json', REMOTE_PROOFS / 'failure.json',
                               PROOF_HASHES['failure.json']),
        'additive_brief': bound(LOCAL_PROOFS / 'three_method_analysis_brief_002.md',
                                REMOTE_PROOFS / 'three_method_analysis_brief_002.md',
                                PROOF_HASHES['three_method_analysis_brief_002.md']),
        'admission': bound(admission_local, REMOTE_PROOFS / 'analysis_admission_002.json'),
        'scope_review': review_binding,
    }
    return dict(schema='three_method_analysis_manifest_v2', remote_root=str(REMOTE),
                geometry=EXPECTED_GEOMETRY, selection=audit['selection'],
                cases=cases, proofs=proofs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--admission-local', required=True, type=Path)
    parser.add_argument('--scope-review-local', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    require(args.output.is_absolute() and args.output.parent == HERE and not args.output.exists(),
            'Manifest output must be a new file in the assigned directory')
    write_json(args.output, build(args.admission_local, args.scope_review_local))
    print(sha(args.output))


if __name__ == '__main__':
    main()
