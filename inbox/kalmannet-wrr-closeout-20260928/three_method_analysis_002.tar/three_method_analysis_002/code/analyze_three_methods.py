"""CPU-only, conditionally admitted comparison of three saved-statistics cases.

Import has no model or evaluation side effects. Real inputs are read only by main.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import traceback

import numpy as np

CASE_IDS = ('learned_noise__original_outlet_original_states',
            'matched_fixed_test', 'matched_selected_test')
CONTRASTS = {'learned_minus_fixed': (1, 0),
             'learned_minus_online': (2, 0),
             'online_minus_fixed': (1, 2)}
METRICS = ('nse', 'rmse', 'mae', 'kge', 'correlation', 'variability_ratio', 'bias_ratio')
CONVERSION = 957000 / 3600
REMOTE = Path('/data1/home/sunyiq/kalmannet_wrr_closeout_20260928_v1')
AUDIT_SHA = 'd20262c7638f6d69764f4dce7475879b1d43b83dc7ed1d6f9e8f6f78a557d22a'
BASE_SHA = '9c8ab347eb3437b4bcc2f01a5a350a2126209577e77dee3ca796faa309313f34'
DRAWS_SHA = 'b3bf82f7ae41a4f9cc5d19029c36a97c8fc5e758ae867b30193f76ef9e79539e'
DIAGNOSTIC_SHA = '701b73ce12824a6eecb0a6a5ef4ebe3343a91208fef5d57d9cf9739de8272932'
DIAGNOSTIC_REVIEW_SHA = 'd6535bc2a44385a1eb4e0abe35484ad1f7ef79046430602429c1efe6579a7477'
PROOF_HASHES = {
    'result_acceptance_001.json': 'a35e94a6354f1c9fd7091666c0e59df01ec1c209e8be85e7248c19b8e4411533',
    'independent_result_review.md': '4432c11f5dcdfeb06221cc2d20da8302f0fb892c9c054a25164f8dc92f6031fa',
    'domain_diagnostic_independent_review_001.md': DIAGNOSTIC_REVIEW_SHA,
    'diagnostic.json': DIAGNOSTIC_SHA,
    'failure.json': '6334833e5f2ba2a8d15105914c12786540ed7140c6993641ac8c620cd43462f1',
    'audit_manifest_001.json': AUDIT_SHA,
    'three_method_analysis_brief_002.md': '5adabf1cf2810fc8fbd2ea1e3eb80391785daaa327f5a384503d07b3aa734c22',
    'three_method_scope_independent_review_002.md': '28c44ed8ef6bf4fb9d0542e21a2efabc847b81b048bb50ce3988ed9c4b8f3ace',
}
SY2_MAX_ABS = 2.8421709430404007e-13
SY2_MAX_REL = 7.093118779809176e-15
EXPECTED_GEOMETRY = dict(windows=14981, width=753, leads=25,
                         issue_hours=15733, observation_hours=15780,
                         first_hour=343622.0, last_observation_hour=359401.0)


class AnalysisFailure(ValueError):
    def __init__(self, name, detail=None):
        super().__init__(name)
        self.name, self.detail = name, detail


def require(condition, name, detail=None):
    if not condition:
        raise AnalysisFailure(name, detail)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def safe_file(path, root):
    path, root = Path(path), Path(root)
    require(path.is_absolute() and root.is_absolute() and path != root and
            '..' not in path.parts and path.is_relative_to(root), 'Path outside root')
    require(path.resolve(strict=False).is_relative_to(root.resolve(strict=False)) and
            path.is_file() and not path.is_symlink(), 'Missing/unsafe bound file')
    return path


def checked_json(binding, root):
    path = safe_file(binding['path'], root)
    require(sha(path) == binding['sha256'], 'Content hash mismatch: ' + str(path))
    value = json.loads(path.read_text(encoding='utf-8-sig'))
    require(sha(path) == binding['sha256'], 'Content hash changed during read: ' + str(path))
    return value


def load_frozen(path, digest, name):
    require(sha(path) == digest, name + ' hash mismatch')
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    require(sha(path) == digest, name + ' changed during import')
    return module


def _frozen_paths():
    here = Path(__file__).resolve().parent
    deployed = (here / 'audit_saved_statistics.py', here / 'analyze_evaluation.py')
    if all(path.exists() for path in deployed):
        return deployed
    root = here.parents[1]
    return (root / 'hpc/saved_stats_audit_001/audit_saved_statistics.py',
            root.parent / 'wrr-hamid-evaluation-20260927-v1/analyze_evaluation.py')


def _frozen():
    base_path, draws_path = _frozen_paths()
    return load_frozen(base_path, BASE_SHA, 'audit_saved_statistics'), load_frozen(draws_path, DRAWS_SHA, 'analyze_evaluation')


def _difference(a, b):
    a, b = np.asarray(a), np.asarray(b)
    require(a.shape == b.shape, 'Cross-method domain shape mismatch')
    require(np.isfinite(a).all() and np.isfinite(b).all(), 'Nonfinite cross-method domain')
    different = a != b
    delta = np.abs(a.astype(float) - b.astype(float))
    scale = np.maximum(np.maximum(np.abs(a.astype(float)), np.abs(b.astype(float))), 1e-300)
    relative = np.divide(delta, scale, out=np.full_like(delta, np.inf), where=scale > 0)
    return dict(different_cells=int(np.count_nonzero(different)),
                maximum_absolute=float(np.max(delta)),
                maximum_relative=float(np.max(relative)),
                exact_equal=bool(not np.any(different)),
                first_five=[dict(index=list(map(int, ix)), reference=float(a[tuple(ix)]),
                                 other=float(b[tuple(ix)]))
                            for ix in np.argwhere(different)[:5]])


def compare_domains(cases, *, registered=False):
    """Only the registered cross-method sy2 difference has a bounded exception."""
    require(len(cases) == 3, 'Three case domain required')
    result = {'pairs': {}, 'exact_prior_gate_passed': True}
    for case in cases:
        for key in ('stats', 'observation', 'issue_hours', 'actual_leads'):
            require(np.isfinite(case[key]).all(), 'Nonfinite ' + key)
    for i, j in ((0, 1), (0, 2), (1, 2)):
        left, right = cases[i], cases[j]
        pair = {}
        for key in ('observation', 'issue_hours', 'actual_leads'):
            a, b = left[key], right[key]
            if key == 'observation':
                a, b = np.asarray(a).reshape(-1), np.asarray(b).reshape(-1)
            pair[key] = _difference(a, b)
        for index, key in ((0, 'n'), (1, 'sy'), (2, 'sy2')):
            pair[key] = _difference(left['stats'][:, :, index], right['stats'][:, :, index])
        result['pairs'][CASE_IDS[i] + '__versus__' + CASE_IDS[j]] = pair
        result['exact_prior_gate_passed'] &= pair['sy2']['exact_equal']
    for key in ('observation', 'issue_hours', 'actual_leads', 'n', 'sy', 'sy2'):
        entries = [p[key] for p in result['pairs'].values()]
        result[key] = dict(different_cells=sum(x['different_cells'] for x in entries),
                           maximum_absolute=max(x['maximum_absolute'] for x in entries),
                           maximum_relative=max(x['maximum_relative'] for x in entries))
    for key in ('observation', 'issue_hours', 'actual_leads', 'n', 'sy'):
        require(result[key]['different_cells'] == 0, 'Cross-method domain mismatch: ' + key, result)
    sy2 = result['sy2']
    # The threshold is the registered actual discrepancy, not a general tolerance.
    require(sy2['maximum_absolute'] <= SY2_MAX_ABS and sy2['maximum_relative'] <= SY2_MAX_REL,
            'Cross-method domain mismatch: unregistered sy2 magnitude', result)
    if registered:
        pair_values = list(result['pairs'].values())
        require(all(p['sy2']['different_cells'] == 231903 and
                    p['sy2']['maximum_absolute'] == SY2_MAX_ABS and
                    p['sy2']['maximum_relative'] == SY2_MAX_REL for p in pair_values[:2]) and
                pair_values[2]['sy2']['different_cells'] == 0,
                'Cross-method domain mismatch: registered sy2 pattern', result)
    result['sy2_exception'] = 'REGISTERED_THREE_ARRAYS_ONLY'
    return result


def _metric_vectors(cases):
    base, _ = _frozen()
    values = []
    for case in cases:
        computed = base.calculate(case['stats'])
        values.append({key: np.asarray(computed[key], dtype=float) *
                       (CONVERSION if key in ('rmse', 'mae') else 1) for key in METRICS})
    return values


def _metric_summary(values):
    values = np.asarray(values, dtype=float)
    require(values.shape == (25,) and np.isfinite(values).all(), 'Invalid point metric vector')
    return dict(current_0=float(values[0]), per_lead=values.tolist(),
                future_1_12=float(np.mean(values[1:13])),
                future_13_24=float(np.mean(values[13:25])))


def point_metrics(cases):
    values = _metric_vectors(cases)
    methods = {case_id: {key: _metric_summary(v[key]) for key in METRICS}
               for case_id, v in zip(CASE_IDS, values)}
    contrasts = {name: {key: _metric_summary(values[changed][key] - values[baseline][key])
                        for key in METRICS}
                 for name, (baseline, changed) in CONTRASTS.items()}
    return dict(methods=methods, contrasts=contrasts,
                error_units={'rmse': 'm3/s', 'mae': 'm3/s'})


def _interval(values):
    values = np.asarray(values, dtype=float)
    require(values.ndim == 2 and values.shape[1] == 25 and np.isfinite(values).all(),
            'Invalid draw values')
    per_lead = np.percentile(values, (2.5, 97.5), axis=0).T
    return dict(per_lead=per_lead.tolist(), current_0=per_lead[0].tolist(),
                future_1_12=np.percentile(values[:, 1:13].mean(axis=1), (2.5, 97.5)).tolist(),
                future_13_24=np.percentile(values[:, 13:25].mean(axis=1), (2.5, 97.5)).tolist())


def interval_analysis(cases, block_lengths=(800, 400, 1600), draws=10000,
                      seed=20260915, *, progress=None, archives=None, point_progress=None):
    """Frozen paired_draws, unchanged RNG ordering and circular/tail handling."""
    _, frozen = _frozen()
    native = np.stack([case['stats'] for case in cases], axis=0)
    canonical = native.copy()
    canonical[:, :, :, 2] = native[0, :, :, 2]
    native_points = point_metrics(cases)
    canonical_points = point_metrics([dict(case, stats=canonical[i])
                                     for i, case in enumerate(cases)])
    point_change = max(abs(native_points['contrasts'][name][key]['per_lead'][lead] -
                           canonical_points['contrasts'][name][key]['per_lead'][lead])
                       for name in CONTRASTS for key in METRICS for lead in range(25))
    summaries = progress if progress is not None else {}
    archives = archives if archives is not None else {}
    summaries['canonical_point_metrics'] = canonical_points
    if point_progress is not None:
        point_progress['sensitivity_point_metrics'] = canonical_points
    for length in block_lengths:
        native_draws, starts = frozen.paired_draws(native, length, draws, seed)
        canonical_draws, canonical_starts = frozen.paired_draws(canonical, length, draws, seed)
        require(np.array_equal(starts, canonical_starts), 'Canonical RNG starts changed')
        key = str(length)
        contrast_arrays = {name: native_draws[:, changed] - native_draws[:, baseline]
                           for name, (baseline, changed) in CONTRASTS.items()}
        canonical_contrasts = {name: canonical_draws[:, changed] - canonical_draws[:, baseline]
                               for name, (baseline, changed) in CONTRASTS.items()}
        original_summaries = {name: _interval(a) for name, a in contrast_arrays.items()}
        canonical_summaries = {name: _interval(a) for name, a in canonical_contrasts.items()}
        endpoint_change = max(abs(np.asarray(original_summaries[name][field]) -
                                  np.asarray(canonical_summaries[name][field])).max()
                              for name in CONTRASTS for field in ('per_lead', 'future_1_12', 'future_13_24'))
        summaries[key] = dict(block_hours=length, n_draws=draws, seed=seed,
                              methods={cid: _interval(native_draws[:, i])
                                       for i, cid in enumerate(CASE_IDS)},
                              contrasts=original_summaries,
                              sensitivity=dict(maximum_point_contrast_change=float(point_change),
                                               maximum_interval_endpoint_change=float(endpoint_change),
                                               canonical_contrasts=canonical_summaries))
        archives[key] = dict(starts=starts, canonical_starts=canonical_starts,
                             native_nse=native_draws, canonical_nse=canonical_draws,
                             **{'contrast_' + name: array for name, array in contrast_arrays.items()},
                             **{'canonical_contrast_' + name: array for name, array in canonical_contrasts.items()})
    return summaries, archives


def validate_admission(admission, manifest_sha, diagnostic_sha, review_path):
    require(admission.get('schema') == 'three_method_analysis_admission_v2' and
            admission.get('admitted') is True, 'False or wrong analysis admission')
    require(admission.get('case_ids') == list(CASE_IDS), 'Admission case identities mismatch')
    require(admission.get('source_manifest_sha256') == manifest_sha and
            admission.get('diagnostic_sha256') == diagnostic_sha,
            'Admission source binding mismatch')
    review = admission.get('independent_scope_review', {})
    require(review.get('path') == review_path and isinstance(review.get('sha256'), str) and
            review['sha256'] == PROOF_HASHES['three_method_scope_independent_review_002.md'],
            'Admission review binding mismatch')
    require([case.get('case_id') for case in admission.get('cases', ())] == list(CASE_IDS),
            'Admission case identities mismatch')
    proof_dir = PurePosixPath(review_path).parent
    require(set(admission.get('proofs', {})) == set(PROOF_HASHES) and
            all(admission['proofs'][name] == {'path': str(proof_dir / name), 'sha256': digest}
                for name, digest in PROOF_HASHES.items()), 'Admission proof binding mismatch')
    exception = admission.get('exception', {})
    require(exception.get('field') == 'stats[:,:,2]' and
            exception.get('expected_mismatch_cells') == 231903 and
            exception.get('maximum_absolute_difference') == SY2_MAX_ABS and
            exception.get('maximum_relative_difference') == SY2_MAX_REL and
            exception.get('matched_pair_exact') is True and
            exception.get('exact_fields') == ['observation', 'issue_hours', 'actual_leads',
                                               'stats[:,:,0]', 'stats[:,:,1]'],
            'Admission exception scope changed')
    require(admission.get('excluded') == ['main_seed42__original_outlet_original_states',
                                          'adaptive__original_outlet_original_states'] and
            admission.get('training_calls_authorized') == 0 and
            admission.get('model_calls_authorized') == 0 and
            admission.get('final_result_accepted') is False,
            'Admission exclusion/authority changed')
    return True


def validate_case_bindings(actual, expected):
    require([c['case_id'] for c in actual] == list(CASE_IDS) ==
            [c['case_id'] for c in expected], 'Case identities/binding mismatch')
    require(actual == expected, 'Case source binding mismatch')
    return True


def _jsonable(value):
    if isinstance(value, np.ndarray):
        return _jsonable(value.tolist())
    if isinstance(value, (np.integer, np.floating)):
        return _jsonable(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return 'NONFINITE_' + str(value)
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return value


def write_json(path, payload):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(_jsonable(payload), stream, ensure_ascii=False, indent=2, allow_nan=False)


def validate_selection(selection):
    require(selection.get('state') == 'ADAPTIVE_VALIDATION_SELECTION_FROZEN' and
            selection.get('selected_delta_r') == 0.01 and
            selection.get('test_data_read') is False, 'Frozen validation selection changed')
    return True


def output_target(path, root):
    path, root = Path(path), Path(root)
    require(path.is_absolute() and root.is_absolute() and path != root and
            path.parent == root / 'three_method_analysis_002' and
            '..' not in path.parts and not path.exists() and not path.is_symlink() and
            path.resolve(strict=False).is_relative_to(root.resolve(strict=False)) and
            path.parent.is_dir(), 'Output must be absent exclusive analysis child')
    return path


def _source_ledger(manifest, root, ledger=None):
    ledger = ledger if ledger is not None else {}
    bindings = dict(manifest['proofs'])
    bindings['selection'] = manifest['selection']
    for case in manifest['cases']:
        bindings.update({case['case_id'] + '/' + key: value
                         for key, value in case['files'].items()})
    for name, binding in bindings.items():
        entry = ledger[name] = dict(path=str(binding['path']),
                                    expected_sha256=binding['sha256'], read_state='PENDING')
        try:
            path = safe_file(binding['path'], root)
        except Exception as exc:
            entry.update(read_state='MISSING_OR_UNSAFE', read_error=repr(exc))
            raise
        try:
            digest = sha(path)
        except Exception as exc:
            entry.update(read_state='UNREADABLE', read_error=repr(exc))
            raise
        entry['before_sha256'] = digest
        entry['read_state'] = 'VERIFIED' if digest == binding['sha256'] else 'HASH_MISMATCH'
        require(digest == binding['sha256'], name + ' source hash mismatch')
    return ledger


def _finish_ledger(ledger):
    for value in ledger.values():
        try:
            path = Path(value['path'])
            if not path.is_file():
                value.update(after_sha256=None, after_state='MISSING', unchanged=False)
                continue
            digest = sha(path)
            value['after_sha256'] = digest
            value['unchanged'] = digest == value['expected_sha256']
            value['after_state'] = 'UNCHANGED' if value['unchanged'] else 'CHANGED'
        except Exception as exc:
            value.update(after_sha256=None, after_state='UNREADABLE',
                         after_error=repr(exc), unchanged=False)
    return ledger


def _validate_manifest(manifest, root):
    require(manifest.get('schema') == 'three_method_analysis_manifest_v2' and
            manifest.get('remote_root') == str(root), 'Analysis manifest/root mismatch')
    require(manifest.get('geometry') == EXPECTED_GEOMETRY, 'Frozen geometry changed')
    proofs = manifest['proofs']
    for name, digest in (('audit_manifest', AUDIT_SHA), ('audit_saved_statistics', BASE_SHA),
                         ('analyze_evaluation', DRAWS_SHA), ('diagnostic', DIAGNOSTIC_SHA),
                         ('diagnostic_review', DIAGNOSTIC_REVIEW_SHA)):
        require(proofs[name]['sha256'] == digest, name + ' frozen identity changed')
    require(proofs['program']['path'] == str(Path(__file__).resolve()) and
            proofs['program']['sha256'] == sha(__file__), 'Running program differs from manifest')
    require(proofs['admission']['path'] == str(root / 'three_method_analysis_002/proofs/analysis_admission_002.json') and
            proofs['scope_review']['path'] == str(root / 'three_method_analysis_002/proofs/three_method_scope_independent_review_002.md'),
            'Admission/review deployment path changed')
    audit = checked_json(proofs['audit_manifest'], root)
    require(audit['schema'] == 'completed_ten_saved_statistics_audit_v1' and
            audit['remote_root'] == str(root) and audit['geometry'] == EXPECTED_GEOMETRY,
            'Frozen audit manifest changed')
    expected = [{key: case[key] for key in ('case_id', 'kind', 'directory', 'files')}
                for cid in CASE_IDS for case in audit['cases'] if case['case_id'] == cid]
    validate_case_bindings(manifest['cases'], expected)
    require(audit['selection'] == manifest['selection'], 'Selection source changed')
    return audit


def run(manifest, root, report, archives):
    _source_ledger(manifest, root, report['source_ledger'])
    audit = _validate_manifest(manifest, root)
    proofs = manifest['proofs']
    admission = checked_json(proofs['admission'], root)
    validate_admission(admission, AUDIT_SHA, DIAGNOSTIC_SHA, proofs['scope_review']['path'])
    require([{key: item[key] for key in ('case_id', 'directory', 'files')}
             for item in manifest['cases']] == admission['cases'],
            'Admission case source binding mismatch')
    require(all(proofs[name] == admission['proofs'][filename] for name, filename in
                (('historical_acceptance', 'result_acceptance_001.json'),
                 ('historical_review', 'independent_result_review.md'),
                 ('diagnostic_review', 'domain_diagnostic_independent_review_001.md'),
                 ('diagnostic', 'diagnostic.json'), ('audit_failure', 'failure.json'),
                 ('audit_manifest', 'audit_manifest_001.json'),
                 ('additive_brief', 'three_method_analysis_brief_002.md'),
                 ('scope_review', 'three_method_scope_independent_review_002.md'))),
            'Admission proof source binding mismatch')
    require(admission['independent_scope_review']['sha256'] == proofs['scope_review']['sha256'],
            'Independent scope review hash mismatch')
    historical = checked_json(proofs['historical_acceptance'], root)
    diagnostic = checked_json(proofs['diagnostic'], root)
    old_failure = checked_json(proofs['audit_failure'], root)
    require(old_failure['state'] == 'REJECTED_INCOMPLETE' and
            old_failure['accepted'] is False and
            old_failure['failure']['error'] ==
            "ValueError('Completed case first-three statistics differ')",
            'Prior exact-domain failure evidence changed')
    report['historical_exact_gate_failure'] = dict(preserved=True,
              proof_sha256=proofs['audit_failure']['sha256'],
              error=old_failure['failure']['error'])
    for name in ('historical_review', 'diagnostic_review', 'scope_review', 'test',
                 'audit_saved_statistics', 'analyze_evaluation'):
        binding = proofs[name]
        require(sha(safe_file(binding['path'], root)) == binding['sha256'], name + ' hash mismatch')
    learned = next((case for case in historical['original_cases'] if
                    case['case_id'] == CASE_IDS[0]), None)
    require(learned and learned['accepted'] is True and
            all(learned['source_bindings'][key] == manifest['cases'][0]['files'][key]
                for key in manifest['cases'][0]['files']),
            'Learned-noise original acceptance absent/mismatched')
    require(diagnostic['source_manifest_sha256'] == AUDIT_SHA and
            all(diagnostic['cases'][cid]['status'] == 'SAVED_ARRAYS_AND_ARITHMETIC_COMPLETE'
                for cid in CASE_IDS[1:]), 'Matched diagnostic evidence incomplete')
    selection = checked_json(manifest['selection'], root)
    validate_selection(selection)
    base, frozen = _frozen()
    require(Path(base.__file__).resolve() == Path(proofs['audit_saved_statistics']['path']).resolve() and
            Path(frozen.__file__).resolve() == Path(proofs['analyze_evaluation']['path']).resolve(),
            'Frozen helper deployment path mismatch')
    arrays = []
    matched_declaration = None
    for case in manifest['cases']:
        cid, files = case['case_id'], case['files']
        completion = checked_json(files['completion'], root)
        saved = checked_json(files['metrics'], root)
        require(not (Path(case['directory']) / 'failure.json').exists(), 'Completion failure marker: ' + cid)
        expected_state = ('PLAIN_EVALUATION_COMPLETE' if case['kind'] == 'original' else
                          'ADAPTIVE_FULL_EVALUATION_COMPLETE_PENDING_SCIENTIFIC_REVIEW')
        require(completion['case_id'] == cid and completion['state'] == expected_state and
                completion['metrics'] == saved['metrics'], 'Completion/metrics mismatch: ' + cid)
        if case['kind'] == 'matched':
            rate = 0.0 if cid == CASE_IDS[1] else 0.01
            require(completion['split'] == 'test' and completion['delta_r'] == rate and
                    saved['delta_r'] == rate and completion['effective_config']['delta_r'] == rate and
                    completion['selection_sha256'] == manifest['selection']['sha256'] and
                    completion['statistics_sha256'] == files['statistics']['sha256'] and
                    completion['metrics_sha256'] == files['metrics']['sha256'],
                    'Matched selection/artifact mismatch: ' + cid)
            declaration = {key: completion[key] for key in
                           ('input_fingerprints', 'observation_fingerprint', 'time_fingerprint',
                            'selection_path', 'selection_sha256', 'protocol_sha256', 'environment')}
            require(completion['selection_path'] == manifest['selection']['path'] and
                    completion['protocol_sha256'] == audit['protocol_sha256'] and
                    (matched_declaration is None or declaration == matched_declaration),
                    'Matched frozen input/environment mismatch: ' + cid)
            matched_declaration = declaration
        raw = base.saved_arrays(files['statistics']['path'], files['statistics']['sha256'],
                                14981, 753, 25, 15780)
        require(np.array_equal(raw['issue_hours'], 343622.0 + np.arange(15733)) and
                raw['observation'].reshape(-1).shape == (15780,) and
                np.array_equal(raw['actual_leads'], np.arange(25)),
                'Frozen timeline/domain mismatch: ' + cid)
        observed_shape = list(raw['observation'].shape)
        raw['observation'] = raw['observation'].reshape(-1)
        pair_counts = np.sum(raw['stats'][:, :, 0], axis=0)
        require(np.array_equal(pair_counts, np.full(25, 11280693.0)),
                'Frozen pair counts mismatch: ' + cid)
        computed = base.calculate(raw['stats'])
        differences = {key: float(np.max(np.abs(np.asarray(computed[key]) -
                                                 np.asarray(saved['metrics'][key])))) for key in METRICS}
        require(all(np.allclose(computed[key], saved['metrics'][key], atol=1e-10, rtol=1e-10)
                    for key in METRICS), 'Saved seven-metric arithmetic mismatch: ' + cid, differences)
        # Completion fields and point arithmetic are independently compared for every case.
        report['completed_cases'][cid] = dict(status='SAVED_ARRAY_AND_ARITHMETIC_CHECKED',
                                               source_hashes={name: binding['sha256']
                                                              for name, binding in files.items()},
                                               metric_maximum_absolute_difference=differences,
                                               actual_observation_shape=observed_shape,
                                               pair_counts_per_lead=pair_counts.tolist())
        arrays.append(raw)
    report['domain'] = compare_domains(arrays, registered=True)
    archives['domain_sy2'] = {
        'learned_minus_fixed': arrays[0]['stats'][:, :, 2] - arrays[1]['stats'][:, :, 2],
        'learned_minus_online': arrays[0]['stats'][:, :, 2] - arrays[2]['stats'][:, :, 2],
        'online_minus_fixed': arrays[2]['stats'][:, :, 2] - arrays[1]['stats'][:, :, 2],
    }
    report['domain']['all_sy2_cell_differences_file'] = 'domain_sy2_differences.npz'
    report['point_metrics'] = point_metrics(arrays)
    report['intervals'] = {}
    interval_analysis(arrays, progress=report['intervals'], archives=archives,
                      point_progress=report)
    report['limitations'] = [
        'Original cross-method exact sy2 gate failed; registered finite exception only.',
        'Intervals are conditional on saved models and this test period; NSE only.',
        'No simultaneous, initialization, unseen-period, cross-basin or causal inference.',
        'Learned process/observation covariance differs from online observation-noise-only control.']
    require(all(item['unchanged'] for item in _finish_ledger(report['source_ledger']).values()),
            'Source changed during analysis')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    root = REMOTE
    output = output_target(args.output, root)
    output.mkdir(exist_ok=False)
    report = dict(state='IN_PROGRESS', accepted=False, completed_cases={}, source_ledger={})
    archives = {}
    try:
        manifest = checked_json({'path': str(args.manifest), 'sha256': args.manifest_sha256}, root)
        report['manifest'] = dict(path=str(args.manifest), sha256=args.manifest_sha256)
        report['source_ledger']['analysis_manifest'] = dict(path=str(args.manifest),
                  expected_sha256=args.manifest_sha256, before_sha256=args.manifest_sha256,
                  read_state='VERIFIED')
        run(manifest, root, report, archives)
        for length, values in archives.items():
            name = 'domain_sy2_differences.npz' if length == 'domain_sy2' else 'paired_' + length + '.npz'
            np.savez_compressed(output / name, **values)
        report['archive_hashes'] = {path.name: sha(path) for path in output.glob('*.npz')}
        report['state'] = 'PENDING_INDEPENDENT_SCIENTIFIC_RESULT_REVIEW'
        write_json(output / 'analysis.json', report)
    except BaseException as exc:
        _finish_ledger(report['source_ledger'])
        write_json(output / 'failure.json', dict(state='FAILED', accepted=False,
                   failed_check=exc.name if isinstance(exc, AnalysisFailure) else type(exc).__name__,
                   error=str(exc), detail=exc.detail if isinstance(exc, AnalysisFailure) else None,
                   completed_partial_summaries={key: value for key, value in report.items() if key != 'source_ledger'},
                   source_ledger=report['source_ledger'], traceback=traceback.format_exc()))
        raise


if __name__ == '__main__':
    main()
