"""Independent CPU-only analysis of explicitly controller-admitted saved outputs.

No torch, evaluator imports, input tensors, inference, source mutation or glob
selection. Formal CLI requires a reviewed-code receipt and a frozen manifest.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys
import traceback
import numpy as np

ROOT = Path(__file__).resolve().parent
CONVERSION = 957000 / 3600
METRICS = ('nse','rmse','mae','kge','correlation','variability_ratio','bias_ratio')
VARIANTS = ('original_outlet_original_states','corrected_outlet_original_states','corrected_outlet_corrected_states')
LIMITATION = ('条件区间仅描述固定完成模型在这个已知测试时期的共同时间块抽样；'
              '不证明名义覆盖率、所有时效同时覆盖、初始化总体、未见时期、跨流域泛化、最优权重或因果机制。')


def finite(a, label='array'):
    a = np.asarray(a)
    if not np.issubdtype(a.dtype, np.number) or not np.isfinite(a).all():
        raise ValueError(f'Nonfinite or nonnumeric {label}')
    return a


def metrics(statistics):
    s = finite(np.asarray(statistics, dtype=np.float64), 'sufficient statistics')
    if s.shape[-1] != 8:
        raise ValueError('Expected eight sufficient-statistic fields')
    n, sy, sy2, sp, sp2, spo, sse, ae = np.moveaxis(s, -1, 0)
    if np.any(n < 2) or np.any(n != np.floor(n)) or np.any(sse < 0) or np.any(ae < 0):
        raise ValueError('Invalid counts or error totals')
    vo = sy2 - sy * sy / n
    vp = sp2 - sp * sp / n
    if np.any(vo <= 0) or np.any(vp <= 0) or np.any(sy == 0):
        raise ValueError('Nonpositive variance or zero observation mean; no silent exclusion')
    r = (spo - sp * sy / n) / np.sqrt(vo * vp)
    alpha, beta = np.sqrt(vp / vo), sp / sy
    result = dict(nse=1-sse/vo, rmse=np.sqrt(sse/n), mae=ae/n,
                  kge=1-np.sqrt((r-1)**2+(alpha-1)**2+(beta-1)**2),
                  correlation=r, variability_ratio=alpha, bias_ratio=beta)
    result.update(rmse_m3s=result['rmse']*CONVERSION, mae_m3s=result['mae']*CONVERSION)
    for name, value in result.items(): finite(value, name)
    return result


def circular_totals(values, length):
    a = finite(values)
    if not 1 <= length <= len(a): raise ValueError('Invalid circular block length')
    extended = np.concatenate((a, a[:length-1]), axis=0)
    prefix = np.concatenate((np.zeros_like(a[:1]), np.cumsum(extended, axis=0)), axis=0)
    return prefix[length:] - prefix[:-length]


def paired_draws(model_stats, block_length, n_draws, seed, batch_size=100):
    """Archived RNG ordering; all methods receive exactly the same issue blocks.

    Returns all draw/lead NSE values AND block starts, retaining the sample recipe.
    Uses four sufficient fields and bounded batches, without sampled-hour arrays.
    """
    a = finite(np.asarray(model_stats,dtype=np.float64),'model statistics')
    if a.ndim != 4 or a.shape[-1] != 8: raise ValueError('Expected method/issue/lead/8')
    if min(n_draws,batch_size) < 1: raise ValueError('Positive draw and batch counts required')
    compact = a[..., [0,1,2,6]].transpose(1,0,2,3)
    n = len(compact)
    whole, remainder = divmod(n,block_length)
    full = circular_totals(compact,block_length)
    partial = circular_totals(compact,remainder) if remainder else None
    rng = np.random.default_rng(seed)
    output = np.empty((n_draws,a.shape[0],a.shape[2]),dtype=np.float64)
    starts = np.empty((n_draws,whole+bool(remainder)),dtype=np.int64)
    for begin in range(0,n_draws,batch_size):
        end = min(begin+batch_size,n_draws)
        ix = rng.integers(0,n,size=(end-begin,starts.shape[1]))
        starts[begin:end] = ix
        totals = full[ix[:,:whole]].sum(axis=1)
        if remainder: totals += partial[ix[:,-1]]
        count,sy,sy2,error = np.moveaxis(totals,-1,0)
        if np.any(count < 2) or np.any(error < 0): raise ValueError('Invalid resampled counts/errors')
        denominator = sy2-sy*sy/count
        if not np.isfinite(denominator).all() or np.any(denominator <= 0):
            raise ValueError(f'Degenerate resample in draw batch {begin}:{end}; no silent exclusion')
        output[begin:end] = 1-error/denominator
        finite(output[begin:end],'draws')
    return output,starts


def contrast_summary(draws, pairs, seeds):
    """Pairs are (baseline,changed); signed result is changed minus baseline."""
    if not pairs or len(pairs) != len(seeds): raise ValueError('Empty or mismatched paired seeds')
    per_seed = np.stack([draws[:,b]-draws[:,a] for a,b in pairs],axis=1)
    mean = per_seed.mean(axis=1)
    return dict(seeds=list(seeds),mean_draws=mean,
                interval_per_lead=np.percentile(mean,[2.5,97.5],axis=0),
                interval_1_12=np.percentile(mean[:,1:13].mean(axis=1),[2.5,97.5]),
                interval_13_24=np.percentile(mean[:,13:25].mean(axis=1),[2.5,97.5]),
                per_seed=[dict(seed=seed,interval_per_lead=np.percentile(per_seed[:,i],[2.5,97.5],axis=0),
                               interval_1_12=np.percentile(per_seed[:,i,1:13].mean(axis=1),[2.5,97.5]),
                               interval_13_24=np.percentile(per_seed[:,i,13:25].mean(axis=1),[2.5,97.5]))
                          for i,seed in enumerate(seeds)])


def windows(values):
    a = np.asarray(values)
    return {'1_12':a[...,1:13].mean(axis=-1),'13_24':a[...,13:25].mean(axis=-1)}


def replay_check(current, archived):
    differences = {k:float(np.max(abs(np.asarray(current[k])-archived[k])))*(CONVERSION if k in ('rmse','mae') else 1) for k in METRICS}
    return dict(passed=all(v <= (1e-4 if k in ('rmse','mae') else 1e-6) for k,v in differences.items()),
                maximum_absolute_difference=differences,dimensionless_tolerance=1e-6,
                flow_error_tolerance_m3s=1e-4,scientific_equivalence=False)


def reconstructed_replay(current,paper,method):
    if paper.get('units')!={'rmse':'m3/s','mae':'m3/s'}: raise ValueError('Archived error-unit declaration mismatch')
    if paper.get('n_issue_hours')!=15733 or paper.get('actual_leads')!=list(range(25)) or paper.get('count_per_lead')!=[11280693]*25:
        raise ValueError('Archived reconstruction count/domain mismatch')
    reference=paper['metrics'][method]
    differences={}
    for k in METRICS:
        old=finite(reference[k],k)
        if old.shape!=(25,): raise ValueError('Full historical per-lead metric missing')
        current_value=np.asarray(current[k])*(CONVERSION if k in ('rmse','mae') else 1)
        differences[k]=float(np.max(abs(current_value-old)))
    return dict(passed=all(v<=(1e-4 if k in ('rmse','mae') else 1e-6) for k,v in differences.items()),
                maximum_absolute_difference=differences,dimensionless_tolerance=1e-6,flow_error_tolerance_m3s=1e-4,
                new_recomputation=True,unavailable_original_arrays=['issue_hours','observation','per_issue_counts'],scientific_equivalence=False)


def validate_issue(raw,contract,accumulation_audit=None):
    for name,value in raw.items(): finite(value,name)
    t=contract['time']; stats=raw['stats']; obs=raw['observation']; hours=raw['issue_hours']
    if stats.shape != (t['issue_hours'],25,8) or obs.shape != (t['n_hours'],) or hours.shape != (t['issue_hours'],):
        raise ValueError('Saved shape/domain mismatch')
    if not np.array_equal(raw['actual_leads'],np.arange(25)) or not np.all(np.diff(hours)==1):
        raise ValueError('Saved hourly timeline or lead mismatch')
    count=np.convolve(np.ones(t['n_windows'],dtype=np.int64),np.ones(t['issue_positions_per_window'],dtype=np.int64))
    if not np.array_equal(stats[:,:,0],np.broadcast_to(count[:,None],stats.shape[:2])):
        raise ValueError('Issue multiplicity mismatch')
    if not np.all(stats.sum(0)[:,0]==t['expected_pairs_per_lead']): raise ValueError('Pair total mismatch')
    for lead in range(25):
        y=obs[lead:lead+len(stats)].astype(np.float64)
        # Accumulator repeatedly sums identical observations; float64 sum roundoff is bounded.
        for field,power in ((1,1),(2,2)):
            expected=count*y**power
            bound=8*np.finfo(np.float64).eps*np.maximum(1,count)*np.maximum(1,abs(expected))
            residual=abs(stats[:,lead,field]-expected)
            if accumulation_audit is not None:
                accumulation_audit.setdefault('per_lead',[]).append(dict(lead=lead,field=field,
                    maximum_absolute_residual=float(residual.max()),maximum_bound=float(bound.max()),
                    maximum_fraction_of_bound=float((residual/bound).max()),violations=int((residual>bound).sum())))
            if np.any(residual>bound):
                raise ValueError('Target observation sufficient-statistic mismatch')
    return metrics(stats.sum(0))


def flow_groups(raw,contract):
    records=[]
    for row in contract['flow_definitions']['forecast']['frozen_per_lead_thresholds_and_counts']:
        lead=row['lead_hours']; y=raw['observation'][lead:lead+len(raw['stats'])]
        masks=dict(low=y<row['q25_mmh'],mid=(y>=row['q25_mmh'])&(y<=row['q75_mmh']),high=y>row['q75_mmh'])
        groups={}
        for name,mask in masks.items():
            total=raw['stats'][mask,lead].sum(0)
            if total[0] != row['counts'][name]: raise ValueError('Frozen forecast flow-group count mismatch')
            groups[name]=dict(count=int(total[0]),metrics=metrics(total))
        records.append(dict(lead=lead,groups=groups,thresholds={k:row[k] for k in ('q25_mmh','q75_mmh')}))
    return records


def distribution(a):
    return dict(q25=np.quantile(a,.25,axis=0),median=np.median(a,axis=0),q75=np.quantile(a,.75,axis=0),
                median_absolute=np.median(abs(a),axis=0),positive=(a>0).sum(0),negative=(a<0).sum(0),zero=(a==0).sum(0))


def state_analysis(raw,contract,bounds):
    for name,value in raw.items(): finite(value,name)
    n=contract['counts']['all']
    names=('prior','proposal','posterior','physical_before','physical_after')
    for name in names:
        if raw[name].shape != (n,5) or raw[name].dtype != np.float32: raise ValueError('Original float32 state capture required')
    prior,proposal,post=(raw[k] for k in ('prior','proposal','posterior'))
    residual=(post-prior)-((proposal-prior)+(post-proposal))
    bound=8*np.finfo(np.float32).eps*(1+np.maximum.reduce([abs(prior),abs(proposal),abs(post)]))
    if np.any(abs(residual)>bound): raise ValueError('State decomposition exceeds fixed bound')
    if not np.array_equal(raw['physical_after'],prior): raise ValueError('Physical-after/prior capture mismatch')
    if 'innovation' in raw and not np.array_equal(prior+raw['innovation'],proposal): raise ValueError('Unclamped proposal anchor mismatch')
    obs=raw['observation']; lo=contract['thresholds']['q25']; hi=contract['thresholds']['q75']
    masks=dict(all=np.ones(n,dtype=bool),low=obs<=lo,mid=(obs>lo)&(obs<=hi),high=obs>hi)
    deltas=dict(final_update=post.astype(float)-prior,proposal=proposal.astype(float)-prior,
                posterior_constraint=post.astype(float)-proposal,
                physical_terminal_constraint=raw['physical_after'].astype(float)-raw['physical_before'])
    lower=np.array([bounds[k][0] for k in ('dv','dg','hq','hs','q')],dtype=np.float32)
    upper=np.array([bounds[k][1] for k in ('dv','dg','hq','hs','q')],dtype=np.float32)
    groups={}
    for name,mask in masks.items():
        if mask.sum()!=contract['counts'][name]: raise ValueError('Frozen state flow count mismatch')
        groups[name]=dict(count=int(mask.sum()),deltas={k:dict(native=distribution(v[mask]),fixed_iqr=distribution(v[mask]/contract['scales'])) for k,v in deltas.items()},
                          posterior_at_lower=(post[mask]==lower).sum(0),posterior_at_upper=(post[mask]==upper).sum(0),
                          proposal_below_lower=(proposal[mask]<lower).sum(0),proposal_above_upper=(proposal[mask]>upper).sum(0),
                          physical_changed=(raw['physical_after'][mask]!=raw['physical_before'][mask]).sum(0))
    return dict(states=contract['names'],units=['mm','mm','mm','mm','mm/hour'],fixed_iqr=contract['scales'],groups=groups,
                decomposition=dict(max_absolute_residual=abs(residual).max(0),max_bound=bound.max(0),min_bound=bound.min(0),violations=(abs(residual)>bound).sum(0)),
                limitation='无内部状态真值；不能由提议、边界命中或相关性证明真实水文机制。')


def comparator_state_analysis(raw,physical,contract):
    """Non-neural captures have no network proposal; physical samples stay explicit."""
    n=contract['counts']['all']
    for name,a in {**raw,**physical}.items(): finite(a,name)
    for name in ('prior','posterior'):
        if raw[name].shape!=(n,5) or raw[name].dtype!=np.float32: raise ValueError('Comparator state shape/dtype mismatch')
    before,after=physical['before'],physical['after']
    if before.shape!=after.shape or before.ndim!=3 or before.shape[0]!=n or before.shape[2]!=5 or before.dtype!=np.float32 or after.dtype!=np.float32:
        raise ValueError('Physical [hour,sigma point,state] shape/dtype mismatch')
    expected=before.copy()
    expected[:,:,2:4]=np.maximum(expected[:,:,2:4],np.float32(.001))
    expected[:,:,4]=np.maximum(expected[:,:,4],np.float32(0))
    if expected.tobytes()!=after.tobytes(): raise ValueError('Physical terminal bounds differ from frozen clamp')
    obs=raw['observation']; lo=contract['thresholds']['q25']; hi=contract['thresholds']['q75']
    masks=dict(all=np.ones(n,dtype=bool),low=obs<=lo,mid=(obs>lo)&(obs<=hi),high=obs>hi)
    groups={}
    for name,mask in masks.items():
        if mask.sum()!=contract['counts'][name]: raise ValueError('Frozen comparator state group count mismatch')
        update=raw['posterior'][mask].astype(float)-raw['prior'][mask]
        delta=(after[mask].astype(float)-before[mask]).reshape(-1,5)
        groups[name]=dict(count=int(mask.sum()),update=dict(native=distribution(update),fixed_iqr=distribution(update/contract['scales'])),
                          physical_terminal_constraint=dict(sample_points=len(delta),native=distribution(delta),fixed_iqr=distribution(delta/contract['scales']),
                                                            changed=(before[mask]!=after[mask]).sum(axis=(0,1)),
                                                            quickflow_at_lower=int((after[mask,:,2]==np.float32(.001)).sum()),
                                                            surface_at_lower=int((after[mask,:,3]==np.float32(.001)).sum()),
                                                            discharge_at_lower=int((after[mask,:,4]==0).sum())))
    return dict(states=contract['names'],units=['mm','mm','mm','mm','mm/hour'],groups=groups,proposal_available=False,
                limitation='非神经模型没有网络约束前提议；保留每个实际传播状态，不将多点均值称为真实物理状态。')


def check_preflight(preflight,case_id,neural):
    if neural:
        if case_id not in preflight.get('case_ids',[]): raise ValueError('Preflight does not include admitted case')
        matches=[c for c in preflight['cases'] if c['case_id']==case_id]
        if len(matches)!=1: raise ValueError('Preflight case ambiguous')
        case=matches[0]
        phases={c['phase']:c for c in case['checks']}
        if set(phases)!=set(('pinned_original','capture_off','capture_on')): raise ValueError('Named logging parity checks missing')
        for row in phases.values():
            if row.get('bitwise_equal') is not True: raise ValueError('Logging parity not exact')
            if row.get('real_validation_time_mapping',{}).get('passed') is not True: raise ValueError('Real pre-test time gate missing')
    else:
        if preflight.get('case_id')!=case_id: raise ValueError('Comparator preflight case mismatch')
        case=preflight['case']; phases={c['phase']:c for c in case['checks']}
        if set(phases)!=set(('plain','counters','capture_off','capture_on')): raise ValueError('Comparator logging checks missing')
        if case.get('validation_time_contract_passed') is not True: raise ValueError('Comparator time gate missing')
        for phase,row in phases.items():
            if phase!='plain' and not all(v.get('bitwise_equal') is True for v in row['comparisons'].values()):
                raise ValueError('Comparator logging parity not exact')
    if case.get('status')!='PARITY_PASS': raise ValueError('Preflight parity status not passed')
    return dict(case_id=case_id,logging_parity_passed=True,real_validation_time_passed=True,named_phases=list(phases))


def sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''): h.update(block)
    return h.hexdigest()


def read_json(path):
    with Path(path).open(encoding='utf-8-sig') as stream: return json.load(stream)


def jsonable(x):
    if isinstance(x,np.ndarray): return x.tolist()
    if isinstance(x,np.generic): return x.item()
    if isinstance(x,dict): return {str(k):jsonable(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [jsonable(v) for v in x]
    return x


def write_json(path,data):
    with Path(path).open('x',encoding='utf-8') as stream:
        json.dump(jsonable(data),stream,ensure_ascii=False,indent=2,allow_nan=False)


def bound_file(record,ledger):
    path=Path(record['path']).resolve()
    actual=sha256(path)
    if actual!=record['sha256']: raise ValueError('Input hash mismatch: '+str(path))
    ledger[str(path)]=actual
    return path


def load_npz(path):
    with np.load(path,allow_pickle=False) as archive: return {k:archive[k] for k in archive.files}


def require_hashed_outputs(hashes):
    for name in ('completion.json','issue_statistics.npz','state_diagnostics.npz','metrics.json',
                 'case_registry.json','load_ledger.json','state_summary.json'):
        if name not in hashes: raise ValueError('Missing required hashed output: '+name)


def reviewed_registry(references,ledger):
    result={}
    for ref in references:
        records=read_json(bound_file(ref,ledger))
        if not isinstance(records,list): raise ValueError('Reviewed registry must contain explicit case records')
        for row in records:
            case_id=row['case_id']
            if case_id in result: raise ValueError('Ambiguous case in reviewed registries: '+case_id)
            result[case_id]=row
    return result


def validate_case_identity(registered,authority,preflight_case,completion,saved,neural):
    if registered!=authority: raise ValueError('Case differs from reviewed authoritative registry')
    variant=registered.get('variant')
    if variant not in VARIANTS: raise ValueError('Unregistered variant')
    if registered.get('family')=='new':
        if variant!=VARIANTS[2]: raise ValueError('New models require frozen corrected variant')
        if not registered.get('initial_weight_tensor_sha256'): raise ValueError('Missing frozen initialization identity')
    if neural:
        for name in ('config','config_sha256','checkpoint','checkpoint_sha256'):
            if not registered.get(name): raise ValueError('Missing mandatory model/config binding: '+name)
        if registered['checkpoint_sha256']!=completion.get('checkpoint_sha256') or registered['checkpoint_sha256']!=preflight_case.get('checkpoint_sha256'):
            raise ValueError('Accepted preflight checkpoint identity mismatch')
    capture=[c for c in preflight_case['checks'] if c['phase']=='capture_on']
    if len(capture)!=1: raise ValueError('Accepted capture effective configuration missing')
    accepted=capture[0]['effective_config']
    if saved.get('effective_config')!=accepted or completion.get('effective_config')!=accepted:
        raise ValueError('Accepted effective configuration/bounds mismatch')
    if neural and accepted.get('physics')!=('original' if variant==VARIANTS[0] else 'corrected'):
        raise ValueError('Accepted physics does not match frozen variant')
    if not neural and (accepted.get('variant')!=variant or accepted.get('method')!=registered.get('method')):
        raise ValueError('Comparator effective variant/method mismatch')


def validate_state_slices(specs):
    expected=[[i,0,800] for i in range(0,14981,800)]+[[14980,220,800]]
    if specs!=expected: raise ValueError('State slice indices/order/offsets differ from frozen 20-segment plan')
    ranges=[np.arange(i+s,i+e) for i,s,e in specs]
    if not np.array_equal(np.concatenate(ranges),np.arange(15780)): raise ValueError('State slice coverage has gap/overlap')
    return dict(segments=20,first_hour=0,last_hour=15779,last_slice=expected[-1],ordered_exact_coverage=True)


def verify_comparison_output_tables(row,new_entry,ledger):
    """Bind original output tables before trusting newly written array proofs."""
    tables={}
    for side in ('old','new'):
        ref=row[side+'_output_hashes']
        expected_path=(Path(row[side+'_directory'])/'output_hashes.json').resolve()
        if Path(ref['path']).resolve()!=expected_path: raise ValueError('Comparison output table path differs from original case table')
        if side=='new':
            admitted=new_entry['output_hashes']
            if Path(ref['path']).resolve()!=Path(admitted['path']).resolve() or ref['sha256']!=admitted['sha256']:
                raise ValueError('New output table reference differs from current manifest')
        table=read_json(bound_file(ref,ledger))
        if table.get('completion.json')!=row[side+'_completion_sha256']:
            raise ValueError('Comparison completion differs from original output table')
        for file in row['files']:
            if table.get(file['name'])!=file[side+'_file_sha256']:
                raise ValueError('Comparison array file differs from original output table')
        tables[side]=table
    return tables


def verify_prior_attempts(references,entries,qualification_refs,ledger):
    """Recheck every saved byte, never accepting a bare pass flag or difference."""
    if len(references)!=1: raise ValueError('Exactly one controller six-case comparison receipt required')
    report=read_json(bound_file(references[0],ledger))
    if report.get('state')!='PRIOR_ATTEMPT_ARRAY_COMPARISON_PASSED': raise ValueError('Prior comparison receipt did not pass')
    qualifier=report['qualification']
    if not any(Path(q['path']).resolve()==Path(qualifier['path']).resolve() and q['sha256']==qualifier['sha256'] for q in qualification_refs):
        raise ValueError('Comparison qualification absent from manifest')
    qualification=read_json(bound_file(qualifier,ledger))
    if qualification.get('state')!='PRE_TEST_TIME_GATE_DEVIATION_REQUIRES_FRESH_VERIFIED_EXECUTION': raise ValueError('Wrong qualification decision')
    expected=qualification['completed_cases']
    if len(expected)!=6 or len(set(expected))!=6: raise ValueError('Qualification must name the six prior cases')
    preserved=read_json(bound_file(report['preserved_attempts'],ledger))
    if preserved.get('state')!='PRESERVED_COMPLETED_ATTEMPTS_NOT_FINAL_ACCEPTED_SCIENTIFIC_CASES': raise ValueError('Wrong preserved-attempt status')
    old_by_id={r['case_id']:r for r in preserved['cases']}; new_by_id={r['case_id']:r for r in entries}
    rows=report['comparisons']
    if sorted(r['case_id'] for r in rows)!=sorted(expected) or len(old_by_id)!=len(preserved['cases']) or set(old_by_id)!=set(expected):
        raise ValueError('Prior comparison/preservation must exactly cover six qualified cases')
    for row in rows:
        case_id=row['case_id']
        if case_id not in new_by_id: raise ValueError('Prior comparison case absent from current manifest')
        old,new=old_by_id[case_id],new_by_id[case_id]
        if (Path(row['old_directory']).resolve()!=Path(old['directory']).resolve() or
            Path(row['new_directory']).resolve()!=Path(new['directory']).resolve() or
            row['old_completion_sha256']!=old['receipt_sha256'] or row['new_completion_sha256']!=new['completion_sha256']):
            raise ValueError('Prior comparison refers to another old/new attempt')
        if Path(row['old_directory']).resolve()==Path(row['new_directory']).resolve(): raise ValueError('Fresh attempt required')
        verify_comparison_output_tables(row,new,ledger)
        for side in ('old','new'):
            completion=read_json(bound_file(dict(path=Path(row[side+'_directory'])/'completion.json',sha256=row[side+'_completion_sha256']),ledger))
            if completion.get('state')!='COMPLETE' or completion.get('case_id')!=case_id: raise ValueError('Compared attempt incomplete or wrong case')
        if row.get('all_saved_arrays_bitwise_equal') is not True: raise ValueError('Prior saved-array comparison not equal')
        files=row['files']
        if sorted(f['name'] for f in files)!=['issue_statistics.npz','state_diagnostics.npz']: raise ValueError('Exact two saved array files required')
        for file in files:
            arrays={side:load_npz(bound_file(dict(path=Path(row[side+'_directory'])/file['name'],sha256=file[side+'_file_sha256']),ledger)) for side in ('old','new')}
            records=file['arrays']; keys=[r['key'] for r in records]
            if len(keys)!=len(set(keys)) or set(keys)!=set(arrays['old']) or set(keys)!=set(arrays['new']): raise ValueError('Compared array key coverage differs')
            for record in records:
                key=record['key']; left,right=arrays['old'][key],arrays['new'][key]
                for side,a in (('old',left),('new',right)):
                    finite(a,'prior comparison '+key)
                    if list(a.shape)!=record['shape'] or str(a.dtype)!=record['dtype'] or hashlib.sha256(a.tobytes()).hexdigest()!=record[side+'_array_sha256']:
                        raise ValueError('Compared saved array shape/dtype/bytes hash mismatch')
                if record.get('bitwise_equal') is not True or left.dtype!=right.dtype or left.shape!=right.shape or left.tobytes()!=right.tobytes():
                    raise ValueError('Saved prior/new arrays not bitwise equal; no automatic difference acceptance')
    incidents=[r for r in qualification_refs if Path(r['path']).name=='case_qualification_001.json']
    if len(incidents)!=1: raise ValueError('Resource incident qualification must be retained')
    incident=read_json(bound_file(incidents[0],ledger))
    if len(incident.get('resource_review_pending',[]))!=1: raise ValueError('Named resource incident must remain explicit')
    for affected in incident['resource_review_pending']:
        if affected['case_id'] not in old_by_id or affected['completion_sha256']!=old_by_id[affected['case_id']]['receipt_sha256']:
            raise ValueError('Resource incident missing from saved-array comparison')
    return dict(cases_verified=6,all_saved_arrays_rechecked_equal=True,resource_incident=incident,
                full_overlapping_predictions_saved=False,
                limitation='仅证明保存的逐发布时间统计和不重叠状态逐位相同；完整重叠预测未保存，不能据此证明显卡资源事件全面无影响。')


def load_case(entry,contract,ledger,authorities):
    directory=Path(entry['directory']).resolve()
    completion_path=bound_file(dict(path=directory/'completion.json',sha256=entry['completion_sha256']),ledger)
    completion=read_json(completion_path)
    if completion['state']!='COMPLETE' or completion['case_id']!=entry['case_id']: raise ValueError('Incomplete/wrong admitted case')
    hashes=read_json(bound_file(entry['output_hashes'],ledger))
    for name,digest in hashes.items():
        p=(directory/name).resolve()
        if p.parent!=directory: raise ValueError('Output hash path escape')
        bound_file(dict(path=p,sha256=digest),ledger)
    require_hashed_outputs(hashes)
    acceptance=read_json(bound_file(entry['acceptance'],ledger))
    neural=entry['family'] in ('new','main','compact')
    if acceptance['state']!=('PREFLIGHT_ACCEPTED' if neural else 'COMPARATOR_PREFLIGHT_ACCEPTED') or acceptance.get('open_critical_important_findings')!=0:
        raise ValueError('Case acceptance not passed')
    preflight=read_json(bound_file(acceptance['preflight_receipt'],ledger))
    parity=check_preflight(preflight,entry['case_id'],neural)
    if not neural and acceptance.get('case_id')!=entry['case_id']: raise ValueError('Comparator acceptance case mismatch')
    initial=read_json(bound_file(acceptance['initial_state_receipt'],ledger))
    for field in ('source_bindings','engine_bindings','environment'):
        if completion[field]!=preflight[field]: raise ValueError('Evaluation/preflight binding mismatch: '+field)
    for evidence in acceptance.get('evidence',[]): bound_file(evidence,ledger)
    registry=read_json(directory/'case_registry.json')
    matches=[r for r in registry if r['case_id']==entry['case_id']]
    if len(matches)!=1: raise ValueError('Registry case missing/ambiguous')
    registered=matches[0]
    if entry['case_id'] not in authorities: raise ValueError('Case absent from authoritative reviewed registry')
    saved=read_json(directory/'metrics.json')
    preflight_case=next(c for c in preflight['cases'] if c['case_id']==entry['case_id']) if neural else preflight['case']
    validate_case_identity(registered,authorities[entry['case_id']],preflight_case,completion,saved,neural)
    if not neural and (completion.get('model_identity')!=preflight.get('model_identity') or saved.get('model_identity')!=preflight.get('model_identity')):
        raise ValueError('Comparator model identity differs from accepted preflight')
    if registered.get('family',registered.get('method'))!=entry['family']: raise ValueError('Family mismatch')
    if neural and registered.get('checkpoint_sha256')!=completion.get('checkpoint_sha256'): raise ValueError('Checkpoint binding mismatch')
    if registered.get('config') and registered.get('config_sha256'):
        bound_file(dict(path=registered['config'],sha256=registered['config_sha256']),ledger)
    loads=read_json(directory/'load_ledger.json')
    dataset=[r for r in loads if r['role']=='dataset']
    if len(dataset)!=1 or dataset[0]['sha256']!=contract['time']['test_dataset_sha256'] or dataset[0]['sha256']!=initial['source_dataset']['sha256']:
        raise ValueError('Raw dataset identity receipt mismatch')
    if registered['variant'].endswith('corrected_states'):
        if completion['selected_state_sha256']!=initial['files']['test_corrected_cpu.pt']['tensor']['sha256']:
            raise ValueError('Corrected state tensor identity receipt mismatch')
    elif completion['selected_state_sha256']!=initial['paired']['stored_states']['sha256']:
        raise ValueError('Original stored state identity receipt mismatch')
    if neural:
        checkpoints=[r for r in loads if r['role']=='checkpoint']
        if len(checkpoints)!=1 or checkpoints[0]['sha256']!=registered['checkpoint_sha256']: raise ValueError('Loaded checkpoint receipt mismatch')
    # Actual source and engine files are small read-only inputs. Raw datasets and
    # checkpoints are NOT opened; their preflight/load-ledger bindings are retained.
    for field in ('source_bindings','engine_bindings'):
        for path,digest in completion.get(field,{}).items(): bound_file(dict(path=path,sha256=digest),ledger)
    raw=load_npz(directory/'issue_statistics.npz')
    accumulation_audit={}
    recomputed=validate_issue(raw,contract,accumulation_audit)
    difference={k:float(np.max(abs(recomputed[k]-np.array(saved['metrics'][k])))) for k in METRICS}
    if any(v!=0 for v in difference.values()): raise ValueError('Saved/recomputed metric arithmetic differs')
    states=load_npz(directory/'state_diagnostics.npz')
    if not np.array_equal(states['observation'],raw['observation']): raise ValueError('State/forecast observation mismatch')
    if not np.all(np.diff(states['hours'])==1) or not np.array_equal(states['hours'][:len(raw['issue_hours'])],raw['issue_hours']):
        raise ValueError('State/forecast chronological mismatch')
    for key,column in (('observation','qobs'),('hours','tm_hours')):
        value=states[key]
        if value.dtype!=np.float32 or hashlib.sha256(value.tobytes()).hexdigest()!=initial['paired']['columns_before'][column]['sha256']:
            raise ValueError('Saved full-domain bytes differ from bound input column: '+column)
    if completion['state_hours']!=15780:
        raise ValueError('Nonoverlapping state coverage receipt mismatch')
    if neural:
        slice_receipt=validate_state_slices(completion['state_slices'])
        slice_receipt['basis']='saved explicit state_slices compared to frozen exact plan'
        state_result=state_analysis(states,contract['flow_definitions']['state'],saved['effective_config']['bounds'])
    else:
        state_record=read_json(directory/'state_summary.json'); parts={'before':[],'after':[]}
        # The archived iterator batches 19 complete 800-hour segments together,
        # then the final window14980 offset220 segment of580 hours.
        specs=[[i,0,800] for i in range(0,14981,800)]+[[14980,220,800]]
        slice_receipt=validate_state_slices(specs)
        slice_receipt['basis']='independently reconstructed frozen iterator plan plus ordered physical shapes and exact full saved time bytes; individual source indices not separately saved'
        physical_records=state_record['physical_files']
        if [r['path'] for r in physical_records]!=['physical_propagation_00.npz','physical_propagation_01.npz']:
            raise ValueError('Physical state slice file order/count mismatch')
        for number,record in enumerate(physical_records):
            if record['path'] not in hashes: raise ValueError('Unbound physical capture')
            physical=load_npz(directory/record['path'])
            # Saved layout is [batch*sigma point,hour,state]. Preserve sigma points.
            sigma=1 if registered['method']=='open_loop' else 11
            expected_shape=[19*sigma,800,5] if number==0 else [sigma,580,5]
            if record['shape']!=expected_shape or set(physical)!=set(parts): raise ValueError('Physical state slice metadata shape/keys mismatch')
            for key,a in physical.items():
                finite(a,key)
                if list(a.shape)!=expected_shape: raise ValueError('Physical captured slice shape mismatch')
                parts[key].append(a.reshape(a.shape[0]//sigma,sigma,a.shape[1],5).transpose(0,2,1,3).reshape(-1,sigma,5))
        state_result=comparator_state_analysis(states,{k:np.concatenate(v) for k,v in parts.items()},contract['flow_definitions']['state'])
    summary=dict(case_id=entry['case_id'],family=entry['family'],registry=registered,
                 provenance=dict(completion=entry['completion_sha256'],acceptance=entry['acceptance'],preflight=acceptance['preflight_receipt'],
                                 source_bindings=completion.get('source_bindings'),engine_bindings=completion.get('engine_bindings')),
                 metrics=recomputed,windows={k:windows(v) for k,v in recomputed.items()},
                 observation_accumulation_audit=accumulation_audit,
                 recomputation_max_difference=difference,flow_groups=flow_groups(raw,contract),
                 states=state_result,state_slice_check=slice_receipt,logging_parity_receipt=parity,initial_state_receipt=acceptance['initial_state_receipt'],
                 forecast_counters=completion.get('forecast_counters'),diagnostic_counters=completion.get('diagnostic_counters'))
    if entry.get('archived_reference') and 'paper_values' in entry['archived_reference']:
        paper=read_json(bound_file(entry['archived_reference']['paper_values'],ledger))
        summary['historical_replay']=reconstructed_replay(recomputed,paper,registered['method'])
        if not summary['historical_replay']['passed']: raise ValueError('Historical reconstructed replay exceeds frozen tolerance')
    elif entry.get('archived_reference'):
        reference=entry['archived_reference']
        oldmetrics=read_json(bound_file(reference['metrics'],ledger))['metrics']
        old=load_npz(bound_file(reference['issue_statistics'],ledger))
        for k in ('issue_hours','observation','actual_leads'):
            if not np.array_equal(raw[k],old[k]): raise ValueError('Historical exact domain mismatch')
        if not np.array_equal(raw['stats'][:,:,0],old['stats'][:,:,0]): raise ValueError('Historical exact count mismatch')
        summary['historical_replay']=replay_check(recomputed,oldmetrics)
        if not summary['historical_replay']['passed']: raise ValueError('Historical replay exceeds frozen tolerance')
    elif entry['family']!='new':
        if registered['variant']==VARIANTS[0]: raise ValueError('Original historical replay requires bound archived reference')
        summary['historical_replay']=dict(status='sensitivity variant; assess against admitted original-setting result',scientific_equivalence=False)
    return raw,summary


def comparison_definitions(case_ids,contract,entries):
    index={c:i for i,c in enumerate(case_ids)}
    def cid(w,h,s): return f'objective-current-{w}-highflow-{h}-seed-{s}'
    definitions=[]
    for row in contract['experiment_families']['corrected_weight_comparison']['paired_comparisons']:
        seeds=row['seeds']
        if row['contrast']=='current_weight_0p05_minus_0':
            h=row['fixed_high_flow_multiplier']; pairs=[(cid('0',h,s),cid('0p05',h,s)) for s in seeds]
            name=f'current_0p05_minus_0_highflow_{h}'
        else:
            w='0p05' if row['fixed_current_error_weight']==.05 else '0'
            pairs=[(cid(w,1,s),cid(w,2,s)) for s in seeds]; name=f'highflow_2_minus_1_current_{w}'
        if any(a not in index or b not in index for a,b in pairs): raise ValueError('Missing fixed paired successful case')
        definitions.append(dict(name=name,seeds=seeds,case_pairs=pairs,pairs=[(index[a],index[b]) for a,b in pairs]))
    # Historical sensitivity pairs are included only from explicitly listed cases.
    historical={}
    for e in entries:
        if e['family']!='new': historical.setdefault(e['case_id'].split('__')[0],{})[e['case_id'].split('__')[-1]]=e['case_id']
    for model,variants in historical.items():
        for a,b,label in [(VARIANTS[0],VARIANTS[1],'formula'),(VARIANTS[1],VARIANTS[2],'initialization')]:
            if a in variants and b in variants:
                left,right=variants[a],variants[b]
                definitions.append(dict(name=f'{model}_{label}',seeds=[None],case_pairs=[(left,right)],pairs=[(index[left],index[right])]))
    return definitions


def point_contrast(definition,summaries):
    for a,b in definition['pairs']:
        ra,rb=summaries[a]['registry'],summaries[b]['registry']
        if ra.get('family')=='new' and (ra['seed']!=rb['seed'] or ra['initial_weight_tensor_sha256']!=rb['initial_weight_tensor_sha256']):
            raise ValueError('Paired model initialization identity mismatch')
    result={}
    for key in (*METRICS,'rmse_m3s','mae_m3s'):
        values=np.stack([np.asarray(summaries[b]['metrics'][key])-summaries[a]['metrics'][key] for a,b in definition['pairs']])
        result[key]=dict(per_seed=values,mean=values.mean(0),range_min=values.min(0),range_max=values.max(0),
                         windows_per_seed=windows(values),windows_mean=windows(values.mean(0)),
                         windows_range={w:[v.min(),v.max()] for w,v in windows(values).items()})
    return result


def flow_contrast(definition,summaries):
    result=[]
    for lead_index in range(24):
        groups={}
        for group in ('low','mid','high'):
            by_metric={}
            for metric in (*METRICS,'rmse_m3s','mae_m3s'):
                values=np.array([summaries[b]['flow_groups'][lead_index]['groups'][group]['metrics'][metric]-
                                 summaries[a]['flow_groups'][lead_index]['groups'][group]['metrics'][metric]
                                 for a,b in definition['pairs']])
                by_metric[metric]=dict(per_seed=values,mean=values.mean(),range_min=values.min(),range_max=values.max())
            groups[group]=by_metric
        result.append(dict(lead=lead_index+1,groups=groups))
    return result


def write_tables(output,summary):
    """Long-form native-unit tables retain every model, flow group and lead."""
    def save(name,fields,rows):
        with (output/name).open('x',newline='',encoding='utf-8-sig') as stream:
            writer=csv.DictWriter(stream,fieldnames=fields); writer.writeheader(); writer.writerows(rows)
    rows=[]; flow=[]; states=[]
    for case in summary['cases']:
        cid=case['case_id']
        for metric,values in case['metrics'].items():
            for lead,value in enumerate(values): rows.append(dict(case_id=cid,lead=lead,metric=metric,value=float(value)))
        for record in case['flow_groups']:
            for group,data in record['groups'].items():
                for metric,value in data['metrics'].items(): flow.append(dict(case_id=cid,lead=record['lead'],flow_group=group,count=data['count'],metric=metric,value=float(value)))
        for group,data in case['states']['groups'].items():
            deltas=data.get('deltas',{'final_update':data.get('update'),'physical_terminal_constraint':data.get('physical_terminal_constraint')})
            for component,scales in deltas.items():
                for scale in ('native','fixed_iqr'):
                    for statistic,values in scales[scale].items():
                        for state,value in zip(case['states']['states'],values):
                            states.append(dict(case_id=cid,flow_group=group,state=state,component=component,scale=scale,statistic=statistic,value=float(value)))
    save('case_metrics.csv',['case_id','lead','metric','value'],rows)
    save('flow_metrics.csv',['case_id','lead','flow_group','count','metric','value'],flow)
    save('state_distributions.csv',['case_id','flow_group','state','component','scale','statistic','value'],states)


def training_context(record,ledger):
    path=bound_file(record,ledger); verification=read_json(path)
    if verification['completed_epochs']!=262 or verification['full_epoch_replay_required_events']!=17 or len(verification['failed_models'])!=2:
        raise ValueError('Frozen training totals mismatch')
    models=[]
    for model in verification['completed_models']:
        log=Path(model['checkpoint_local_path']).with_name('events.jsonl')
        relative=log.relative_to(path.parent/'inputs').as_posix()
        digest=verification['member_sha256'].get(relative)
        if digest is None: raise ValueError('Training log absent from retrieved member bindings: '+relative)
        bound_file(dict(path=log,sha256=digest),ledger)
        trajectory=[]; events=[]
        with log.open(encoding='utf-8') as stream:
            for lineno,line in enumerate(stream,1):
                row=json.loads(line)
                if 'learning_rate' in row:
                    rate=row['learning_rate']; finite(rate,'effective learning rate')
                    key=(row.get('epoch'),row.get('attempt'),rate)
                    if not trajectory or key!=tuple(trajectory[-1][k] for k in ('epoch','attempt','learning_rate')):
                        trajectory.append(dict(line=lineno,epoch=key[0],attempt=key[1],learning_rate=rate,event=row.get('event')))
                if row.get('event')!='training_batch': events.append(dict(line=lineno,record=row))
        if sum(e['record'].get('event')=='epoch_complete' for e in events)!=model['epochs_completed']:
            raise ValueError('Training epoch log count differs from receipt')
        if sum(e['record'].get('event')=='FULL_EPOCH_REPLAY_REQUIRED' for e in events)!=model['recovery_events']:
            raise ValueError('Recovery log count differs from receipt')
        models.append(dict(case_id=model['exp_id'],completed_epochs=model['epochs_completed'],recoveries=model['recovery_events'],
                           log_sha256=digest,effective_learning_rate_trajectory=trajectory,non_batch_events=events))
    for failure in verification['failed_models']:
        bound_file(dict(path=failure['local_receipt'],sha256=failure['receipt_sha256']),ledger)
    return dict(completed_epochs=262,recoveries=17,failed_models=verification['failed_models'],models=models,
                limitation='配对比较以成功完成为条件，代表共同恢复规则下的完整训练过程，不能剥离恢复过程解释直接权重作用。')


def analyze(manifest_path,output):
    manifest_path=Path(manifest_path).resolve(); output=Path(output).resolve()
    if ROOT not in output.parents: raise ValueError('Output must be strictly inside execution root')
    if output.exists(): raise FileExistsError('Output must be a fresh nonexisting directory')
    manifest=read_json(manifest_path)
    ledger={str(manifest_path):sha256(manifest_path),str(Path(__file__).resolve()):sha256(__file__)}
    if manifest.get('state')!='ACCEPTED_CASES_FOR_ANALYSIS': raise ValueError('Explicit controller acceptance required')
    review=read_json(bound_file(manifest['analysis_code_acceptance'],ledger))
    if review.get('state')!='ANALYSIS_CODE_ACCEPTED' or review.get('source_sha256')!=sha256(__file__) or review.get('open_critical_important_findings')!=0:
        raise ValueError('Independent analysis-code acceptance required')
    contract=read_json(bound_file(manifest['contract'],ledger))['evaluation_contract']
    registry_refs=manifest['registry'] if isinstance(manifest['registry'],list) else [manifest['registry']]
    authorities=reviewed_registry(registry_refs,ledger)
    for key in ('qualification_evidence','prior_attempt_comparisons'):
        records=manifest[key] if isinstance(manifest[key],list) else [manifest[key]]
        for record in records: bound_file(record,ledger)
    entries=manifest['cases']; ids=[e['case_id'] for e in entries]
    expected=contract['experiment_families']['corrected_weight_comparison']['completed_model_ids']
    if len(set(ids))!=len(ids) or sorted(e['case_id'] for e in entries if e['family']=='new')!=sorted(expected):
        raise ValueError('Explicit manifest must contain each of the ten fixed new models exactly once')
    if not manifest['qualification_evidence'] or not manifest['prior_attempt_comparisons']:
        raise ValueError('Qualification and preserved-attempt comparison receipts required')
    output.mkdir()
    try:
        prior_check=verify_prior_attempts(manifest['prior_attempt_comparisons'],entries,manifest['qualification_evidence'],ledger)
        arrays=[]; summaries=[]; first=None
        for entry in entries:
            raw,summary=load_case(entry,contract,ledger,authorities)
            if first is None: first=raw
            else:
                for k in ('issue_hours','observation','actual_leads'):
                    if not np.array_equal(first[k],raw[k]): raise ValueError('Cross-case exact observation/time mismatch')
                if not np.array_equal(first['stats'][...,0],raw['stats'][...,0]): raise ValueError('Cross-case exact issue counts mismatch')
            arrays.append(raw['stats']); summaries.append(summary)
        training=training_context(manifest['training_evidence'],ledger)
        definitions=comparison_definitions(ids,contract,entries)
        contrasts={d['name']:dict(**d,point_metrics=point_contrast(d,summaries),flow_point_differences=flow_contrast(d,summaries),uncertainty={}) for d in definitions}
        allstats=np.stack(arrays); del arrays
        for length in (800,400,1600):
            print(f'CPU paired circular block length {length}; 10000 draws',flush=True)
            draws,starts=paired_draws(allstats,length,10000,20260915)
            drawfile=output/f'paired_nse_block_{length}.npz'
            with drawfile.open('xb') as stream: np.savez_compressed(stream,nse=draws,block_starts=starts,case_ids=np.array(ids))
            for definition in definitions:
                result=contrast_summary(draws,definition['pairs'],definition['seeds'])
                result.pop('mean_draws')
                result.update(draw_file=drawfile.name,draw_sha256=sha256(drawfile),block_length=length,draws=10000,seed=20260915)
                contrasts[definition['name']]['uncertainty'][str(length)]=result
        comments=read_json(bound_file(manifest['original_comments'],ledger))
        anchors=[c for c in comments['comments'] if c['id'] in (72,80,112,113,115)]
        if len(anchors)!=5: raise ValueError('Missing original collaborator comment anchors')
        summary=dict(state='MACHINE_STATISTICS_ONLY_SCIENTIFIC_INTERPRETATION_OPEN',cases=summaries,comparisons=contrasts,
                     analysis_environment=dict(python=sys.version,numpy=np.__version__,processor='CPU only; no model libraries imported'),
                     training=training,blocked_cases=manifest['blocked_cases'],qualification_evidence=manifest['qualification_evidence'],
                     prior_attempt_comparisons=manifest['prior_attempt_comparisons'],prior_attempt_verification=prior_check,comment_anchors=anchors,
                     limitation=LIMITATION,interaction_complete_seeds=[44],known_test_period=True,
                     manuscript_versions_not_synchronized=True,scientific_interpretation=dict(status='OPEN',
                     required_deliverable='actual_scientific_interpretation.md',
                     required_content='五条原意见逐项实际数字和字段定位、原设置复算差、快速径流方向/边界与流量联合解释；完成后独立科学审核。',
                     fixed_scope_limits=['四组同时完整仅初始化44；不支持稳定交互或最优权重。',
                                         '旧六神经模型未准入；仅一个旧主网络实测记录门槛，不能称六例均实测失败。',
                                         '三种旧滤波方法的九种设置分别未通过记录门槛。']))
        write_json(output/'summary.json',summary)
        write_json(output/'input_ledger.json',ledger)
        write_tables(output,summary)
        report=human_report(summary)
        with (output/'report.md').open('x',encoding='utf-8') as stream: stream.write(report)
        hashes={p.name:sha256(p) for p in output.iterdir() if p.is_file()}
        write_json(output/'output_hashes.json',hashes)
        return summary
    except Exception as exc:
        write_json(output/'failure.json',dict(state='ANALYSIS_FAILED_NO_SILENT_EXCLUSION',error=str(exc),traceback=traceback.format_exc(),inputs=ledger))
        raise


def human_report(summary):
    lines=['# 固定模型评价：机器统计摘要（科学解释尚未完成）','',summary['limitation'],'',
           '本文件只汇总机器统计，不是完整科学解释或已完成的合作者意见回应。实际科学解释交付门槛保持 OPEN；主控须另写 actual_scientific_interpretation.md，并完成独立全流程科学与可靠性审核。','',
           '## 同初始化配对结果','',
           '| 比较（后者减前者） | 初始化 | 未来1—12小时纳什效率差 | 800小时块条件区间 | 未来13—24小时差 | 条件区间 |',
           '|---|---|---:|---|---:|---|']
    for name,c in summary['comparisons'].items():
        p=c['point_metrics']['nse']; u=c['uncertainty']['800']; w=p['windows_mean']
        label={'current_0p05_minus_0_highflow_1':'当前更新误差权重0.05减0，高流量倍数1',
               'current_0p05_minus_0_highflow_2':'当前更新误差权重0.05减0，高流量倍数2',
               'highflow_2_minus_1_current_0':'高流量倍数2减1，当前更新误差权重0',
               'highflow_2_minus_1_current_0p05':'高流量倍数2减1，当前更新误差权重0.05',
               'open_loop_formula':'未同化模型：仅出口公式修正',
               'open_loop_initialization':'未同化模型：在修正出口公式后改变初始化'}.get(name,name)
        lines.append(f"| {label} | {c['seeds']} | {w['1_12']:.9g} | {jsonable(u['interval_1_12'])} | {w['13_24']:.9g} | {jsonable(u['interval_13_24'])} |")
        for i,seed in enumerate(c['seeds']):
            ws=p['windows_per_seed']; us=u['per_seed'][i]
            lines.append(f"| 逐初始化：{label} | {seed} | {ws['1_12'][i]:.9g} | {jsonable(us['interval_1_12'])} | {ws['13_24'][i]:.9g} | {jsonable(us['interval_13_24'])} |")
    lines += ['', '所有时效、七项指标、流量分组、五个状态的原单位与共同尺度、400/1600小时敏感性区间、逐初始化范围均见 summary.json；逐抽样逐时效结果和抽样起点见配套压缩文件。',
              '', '## 训练与证据边界','', '十个完成模型共262个成功训练轮、17次整轮恢复；两组失败保留在 summary.json，逐模型有效学习率轨迹来自绑定的原始日志。比较不能剥离恢复过程。',
              '', '## 待完成的科学解释','',summary['scientific_interpretation']['required_content'],'']
    for text in summary['scientific_interpretation']['fixed_scope_limits']: lines.append('- '+text)
    lines += ['', '## 原意见锚点和后续解释所需证据（不是意见回应完成声明）','']
    response={72:'需解释 comparisons 中实际同初始化差值及区间。',80:'需解释 cases[].states 中原单位状态分布和约束命中数。',112:'需解释带符号中位数、四分位数和正负零计数的实际方向。',113:'需联合解释快速径流提议、约束、最终修改及流量指标的实际数值。',115:'需结合 training 中失败和恢复轨迹说明比较范围。'}
    for c in summary['comment_anchors']:
        lines.append(f"- Hamid Moradkhani 原意见 {c['id']}，原段落 {c['anchor']['paragraph_index']}：{c['anchor']['text']}；待完成：{response[c['id']]}")
    lines += ['', '当前 LaTeX 与第十版 Word 不是同步版本，本轮没有修改或自动同步原稿。',
              '阻断案例和旧新尝试对照回执完整保留于机器汇总；不能因已有新权重结果而宣布旧完整排名成立。','']
    return '\n'.join(lines)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    analyze(args.manifest,args.output)
