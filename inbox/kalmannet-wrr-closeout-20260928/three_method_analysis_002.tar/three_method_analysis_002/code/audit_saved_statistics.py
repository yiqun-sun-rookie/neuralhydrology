"""CPU-only independent arithmetic diagnostic; does not grant model admission.

Reads exactly the saved statistics bound to receipts 13 and 15. No model code,
checkpoint, raw dataset, training, evaluation, selection, or scheduler access.
"""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import zipfile

import numpy as np


CASE_BINDINGS = {
    'historical_r001_validation': 'c97632bee2493e96e4944a4e7e7797c0f2134d1d16d82e66c6218fbe6d8d61c2',
    'historical_r002_validation': 'bba655e26a1828899e6d539b4bafc8f2c74a3655e72578c5c660eeabb18b8d9b',
    'matched_fixed_validation': '659eede28457b537ca39995ed1168bebed862e4d9de795b0ac09675551ac9b5f',
    'matched_r001_validation': '1dbcd145e0dee7c2caf6051fa2d6d8e315eeabf6ee36236a0619d146b40b0d04',
    'matched_r002_validation': '5239981fa272b8240a1bbffc601b1d6257641e970c074ade2e62c1729098f375',
}
FIELDS = ('n', 'sy', 'sy2', 'sp', 'sp2', 'spo', 'sse', 'ae')
KEYS = ('nse', 'rmse', 'mae', 'kge', 'correlation', 'variability_ratio', 'bias_ratio')
ARRAY_KEYS = {'stats', 'issue_hours', 'observation', 'actual_leads'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return digest


def bound_json(path, expected):
    require(sha(path) == expected, 'JSON identity mismatch: ' + str(path))
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def saved_arrays(path, expected, windows, width, leads, observation_hours):
    path = Path(path)
    require(not path.is_symlink() and path.stat().st_size < 50_000_000, 'Unsafe/oversized NPZ')
    require(sha(path) == expected, 'Statistics identity mismatch')
    with zipfile.ZipFile(path) as archive:
        members = archive.infolist()
        require(len(members) == 4 and {m.filename for m in members} ==
                {k + '.npy' for k in ARRAY_KEYS}, 'Unexpected or duplicate NPZ member')
        require(sum(m.file_size for m in members) < 100_000_000, 'Oversized expanded NPZ')
    with np.load(path, allow_pickle=False) as archive:
        arrays = {k: archive[k] for k in ARRAY_KEYS}
    require(sha(path) == expected, 'Statistics changed while reading')
    stats, obs, hours, actual = (arrays[k] for k in
                                ('stats', 'observation', 'issue_hours', 'actual_leads'))
    issues = windows + width - 1
    require(stats.shape == (issues, leads, 8) and stats.dtype == np.float64, 'Statistics shape/dtype')
    require(obs.shape in ((observation_hours,), (observation_hours, 1)) and obs.dtype == np.float32,
            'Observation shape/dtype')
    require(hours.shape == (issues,) and hours.dtype == np.float64, 'Issue-hour shape/dtype')
    require(actual.dtype == np.int64 and np.array_equal(actual, np.arange(leads)), 'Lead labels')
    require(all(np.isfinite(value).all() for value in arrays.values()), 'Nonfinite array')
    obs = obs.reshape(-1)
    i = np.arange(issues)
    counts = np.minimum.reduce((i + 1, np.full(issues, width),
                                np.full(issues, windows), issues - i))
    require(np.array_equal(stats[:, :, 0], np.broadcast_to(counts[:, None], (issues, leads))),
            'Window overlap counts mismatch')
    require(np.all(stats[:, :, (6, 7)] >= 0), 'Negative error statistics')
    # Reconstruct observed sums independently of the evaluation reducer.
    y = obs[i[:, None] + np.arange(leads)].astype(np.float64)
    require(np.allclose(stats[:, :, 1], counts[:, None] * y, rtol=1e-12, atol=1e-12),
            'Observed first moment mismatch')
    require(np.allclose(stats[:, :, 2], counts[:, None] * y * y, rtol=1e-12, atol=1e-12),
            'Observed second moment mismatch')
    return arrays


def calculate(stats, dtype=np.float64):
    """Independent equations from eight sufficient statistics, no project imports."""
    totals = np.sum(stats, axis=0, dtype=dtype)
    n, sy, sy2, sp, sp2, spo, sse, ae = totals.T
    require(np.all(n > 0) and np.all(sse >= 0) and np.all(ae >= 0), 'Invalid metric domain')
    observed_variation = sy2 - sy * sy / n
    predicted_variation = sp2 - sp * sp / n
    require(np.all(observed_variation > 0) and np.all(predicted_variation > 0)
            and np.all(sy != 0), 'Degenerate metric denominator')
    r = (spo - sp * sy / n) / np.sqrt(observed_variation * predicted_variation)
    alpha = np.sqrt(predicted_variation / observed_variation)
    beta = sp / sy
    values = (1 - sse / observed_variation, np.sqrt(sse / n), ae / n,
              1 - np.sqrt((r - 1) ** 2 + (alpha - 1) ** 2 + (beta - 1) ** 2), r, alpha, beta)
    require(all(np.isfinite(value).all() for value in values), 'Nonfinite metric')
    return {k: np.asarray(v, dtype=np.float64).tolist() for k, v in zip(KEYS, values)}


def metric_difference(left, right):
    require(set(left) == set(right) == set(KEYS), 'Incomplete metric set')
    result = {}
    for key in KEYS:
        a, b = np.asarray(left[key], dtype=float), np.asarray(right[key], dtype=float)
        require(a.ndim == 1 and a.shape == b.shape and np.isfinite(a).all() and np.isfinite(b).all(),
                'Invalid metric vector')
        result[key] = float(np.max(np.abs(a - b)))
    return result


def same_domain(left, right):
    return (all(np.array_equal(left[k], right[k]) for k in
                ('issue_hours', 'observation', 'actual_leads')) and
            np.array_equal(left['stats'][:, :, :3], right['stats'][:, :, :3]))


def diagnostic(root):
    adaptive = root / 'adaptive_preflight_v1/adaptive_comparison/runs'
    results, reference = {}, None
    for identifier, completion_sha in CASE_BINDINGS.items():
        directory = adaptive / (identifier + '__formal_attempt01')
        require(not (directory / 'failure.json').exists(), 'Failure marker exists')
        completion = bound_json(directory / 'completion.json', completion_sha)
        require(completion['case_id'] == identifier and completion['split'] == 'validation', 'Wrong case')
        metrics = bound_json(directory / 'metrics.json', completion['metrics_sha256'])
        arrays = saved_arrays(directory / 'issue_statistics.npz', completion['statistics_sha256'],
                              14979, 788, 13, 15778)
        require(reference is None or same_domain(reference, arrays), 'Validation domains differ')
        if reference is None:
            reference = arrays
        calculated = calculate(arrays['stats'])
        difference = metric_difference(calculated, metrics['metrics'])
        require(completion['metrics'] == metrics['metrics'], 'Completion and metrics disagree')
        mean = float(np.mean(calculated['nse'][1:13]))
        mean_difference = abs(mean - completion['mean_future_1_12_nse'])
        # Diagnostic arithmetic tolerance only, never replaces frozen reproduction tolerances.
        require(max(difference.values()) <= 1e-10 and mean_difference <= 1e-10,
                'Saved-statistics arithmetic does not reproduce validation JSON')
        results[identifier] = dict(completion_sha256=completion_sha,
                                  statistics_sha256=completion['statistics_sha256'],
                                  metrics_sha256=completion['metrics_sha256'],
                                  maximum_metric_difference=difference,
                                  mean_future_1_12_nse=mean, mean_difference=mean_difference,
                                  full_observation_moments_reconstructed=True,
                                  longdouble_vs_float64=metric_difference(calculate(arrays['stats'], np.longdouble), calculated))
    plain = root / 'plain_preflight_v1'
    manifest = bound_json(plain / 'deployed_manifest.json',
                         'fe81db8c7bbea43e2f8040ea004e8f8bbf5ddf2107cd5b73369643f3e68c3087')
    identifier = 'main_seed42__original_outlet_original_states'
    case = next(c for c in manifest['cases'] if c['case_id'] == identifier)
    original = case['historical_reference']
    old_json = bound_json(original['metrics_path'], original['metrics_sha256'])
    old = saved_arrays(original['statistics_path'], original['statistics_sha256'], 14981, 753, 25, 15780)
    directory = plain / 'numerical_impact/runs' / (identifier + '__formal_attempt01')
    failed_sha = '63001913fc127e008bd5a35c7cb7c2409f3efc9f5cd107a87c413f7cf93c2dae'
    require((directory / 'failure.json').is_file() and not (directory / 'completion.json').exists(),
            'Failed run status unexpectedly changed')
    new_json = bound_json(directory / 'metrics_before_failed_bridge.json',
                         '2c08cf601a598525f350abc275b17e29e1e5ad5708f7d9a98502fdb015291687')
    new = saved_arrays(directory / 'issue_statistics.npz', failed_sha, 14981, 753, 25, 15780)
    require(same_domain(old, new), 'Original bridge domains differ')
    a, b = calculate(old['stats']), calculate(new['stats'])
    field_differences = {}
    for j, name in enumerate(FIELDS):
        delta = new['stats'][:, :, j] - old['stats'][:, :, j]
        field_differences[name] = dict(nonidentical_cells=int(np.count_nonzero(delta)),
                                       max_abs=float(np.max(np.abs(delta))),
                                       lead13_sum_difference=float(delta[:, 13].sum()))
    old_difference, new_difference = (metric_difference(a, old_json['metrics']),
                                      metric_difference(b, new_json['metrics']))
    require(max(old_difference.values()) <= 1e-10 and max(new_difference.values()) <= 1e-10,
            'Stored JSON arithmetic mismatch; retain failure for diagnostic review')
    bridge = dict(case_id=identifier, original_statistics_sha256=original['statistics_sha256'],
                  failed_statistics_sha256=failed_sha, exact_same_domain=True,
                  original_json_difference=old_difference, failed_json_difference=new_difference,
                  field_differences=field_differences,
                  metrics_max_abs_difference=metric_difference(a, b),
                  lead13={k: dict(original=a[k][13], failed=b[k][13], delta=b[k][13] - a[k][13]) for k in KEYS},
                  original_longdouble_vs_float64=metric_difference(calculate(old['stats'], np.longdouble), a),
                  failed_longdouble_vs_float64=metric_difference(calculate(new['stats'], np.longdouble), b),
                  frozen_bridge_passed=False, model_completion_granted=False,
                  root_cause_not_established=True)
    return dict(state='SAVED_STATISTICS_DIAGNOSTIC_COMPLETE_NOT_SCIENTIFIC_ADMISSION',
                python=platform.python_version(), numpy=np.__version__,
                diagnostic_script_sha256=sha(__file__), new_models=0, training_calls=0,
                validation=results, original_bridge=bridge,
                no_selection_written=True, no_frozen_protocol_changes=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    root, output = args.root.resolve(), args.output.resolve()
    require(output.is_relative_to(root) and output != root, 'Output must be an exclusive child')
    output.mkdir(exist_ok=False)
    try:
        report = diagnostic(root)
        with (output / 'diagnostic.json').open('x', encoding='utf-8') as stream:
            json.dump(report, stream, indent=2, allow_nan=False)
        print(report['state'])
    except BaseException as exc:
        with (output / 'failure.json').open('x', encoding='utf-8') as stream:
            json.dump(dict(state='FAILED', error=repr(exc), diagnostic_script_sha256=sha(__file__)), stream, indent=2)
        raise


if __name__ == '__main__':
    main()
