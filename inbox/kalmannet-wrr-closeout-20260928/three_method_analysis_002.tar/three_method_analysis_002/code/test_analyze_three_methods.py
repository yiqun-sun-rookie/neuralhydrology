"""Small synthetic checks; no saved test arrays or model are opened."""
import copy
import hashlib
import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import pytest

from analyze_three_methods import (
    CASE_IDS, compare_domains, point_metrics, interval_analysis,
    validate_admission, validate_case_bindings, checked_json,
)
import analyze_three_methods as analysis
from build_analysis_manifest import build


def samples(offset=0.0, *, n_issue=5):
    observation = np.arange(1, n_issue + 25, dtype=np.float32)
    stats = np.zeros((n_issue, 25, 8), dtype=np.float64)
    for lead in range(25):
        y = observation[lead:lead + n_issue].astype(float)
        p = y + offset + np.arange(n_issue) * 0.1
        stats[:, lead] = np.column_stack((np.ones(n_issue), y, y*y, p, p*p,
                                          p*y, (p-y)**2, np.abs(p-y)))
    return dict(stats=stats, observation=observation,
                issue_hours=np.arange(n_issue, dtype=float),
                actual_leads=np.arange(25, dtype=np.int64))


def test_only_registered_second_moment_difference_is_disclosed():
    learned, fixed, selected = samples(), samples(0.1), samples(0.2)
    fixed['stats'][1, 2, 2] += 1e-13
    selected['stats'][1, 2, 2] += 1e-13
    result = compare_domains([learned, fixed, selected])
    assert result['sy2']['different_cells'] == 2
    assert result['sy2']['maximum_absolute'] > 0
    assert result['sy2']['maximum_relative'] > 0
    assert result['exact_prior_gate_passed'] is False


def test_actual_run_requires_registered_mismatch_pattern():
    learned, fixed, selected = samples(), samples(), samples()
    fixed['stats'][1, 2, 2] += 1e-13
    selected['stats'][1, 2, 2] += 1e-13
    with pytest.raises(ValueError, match='registered'):
        compare_domains([learned, fixed, selected], registered=True)


@pytest.mark.parametrize('field', ['observation', 'issue_hours', 'actual_leads'])
def test_changed_domain_label_is_rejected(field):
    cases = [samples(), samples(), samples()]
    cases[1][field][0] += 1
    with pytest.raises(ValueError, match='domain'):
        compare_domains(cases)


@pytest.mark.parametrize('field', [0, 1])
def test_count_or_first_observation_moment_change_is_rejected(field):
    cases = [samples(), samples(), samples()]
    cases[1]['stats'][0, 0, field] += 1
    with pytest.raises(ValueError, match='domain'):
        compare_domains(cases)


def test_nonfinite_second_moment_is_not_waived():
    cases = [samples(), samples(), samples()]
    cases[1]['stats'][0, 0, 2] = np.nan
    with pytest.raises(ValueError, match='Nonfinite'):
        compare_domains(cases)


def test_point_metrics_are_from_direct_pairs_and_contrasts_are_signed():
    cases = [samples(), samples(0.2), samples(0.4)]
    result = point_metrics(cases)
    # Five observed values 1..5; fixed predictions add [0.2,0.3,0.4,0.5,0.6].
    assert result['methods']['matched_fixed_test']['nse']['per_lead'][0] == pytest.approx(0.91)
    assert result['contrasts']['learned_minus_fixed']['nse']['per_lead'][0] == pytest.approx(0.06)
    assert result['contrasts']['online_minus_fixed']['nse']['per_lead'][0] < 0
    assert len(result['methods'][CASE_IDS[0]]['rmse']['per_lead']) == 25


def test_identical_methods_produce_exact_zero_draw_contrasts_and_same_starts():
    cases = [samples(), samples(), samples()]
    result, archives = interval_analysis(cases, block_lengths=(4,), draws=7, seed=20260915)
    assert result['4']['contrasts']['learned_minus_fixed']['per_lead'] == [[0.0, 0.0]]*25
    assert np.count_nonzero(archives['4']['contrast_learned_minus_fixed']) == 0
    assert archives['4']['starts'].shape == (7, 2)  # 5 hours: one full block, one tail hour.
    assert archives['4']['starts'].dtype == np.int64
    assert archives['4']['starts'].tolist() == [[2, 3], [4, 2], [0, 0], [2, 3],
                                              [4, 1], [0, 3], [1, 2]]
    # First draw: circular block issues 2,3,4,0 plus one-hour tail issue 3.
    assert archives['4']['native_nse'][0, 0, 0] == pytest.approx(1 - 0.38/9.2)


def test_canonical_sensitivity_reuses_exact_draw_starts():
    cases = [samples(), samples(0.2), samples(0.4)]
    cases[1]['stats'][1, 2, 2] += 1e-13
    result, archives = interval_analysis(cases, block_lengths=(4,), draws=7, seed=20260915)
    assert np.array_equal(archives['4']['starts'], archives['4']['canonical_starts'])
    assert result['4']['sensitivity']['maximum_interval_endpoint_change'] >= 0
    assert result['4']['sensitivity']['maximum_point_contrast_change'] >= 0
    assert not np.array_equal(archives['4']['native_nse'], archives['4']['canonical_nse'])


def test_admission_rejects_false_or_historical_adaptive_substitution():
    admission = json.loads((Path(__file__).parent / 'proofs/analysis_admission_002.json').read_text())
    manifest_sha = admission['source_manifest_sha256']
    diagnostic_sha = admission['diagnostic_sha256']
    review_path = admission['independent_scope_review']['path']
    assert validate_admission(admission, manifest_sha, diagnostic_sha, review_path)
    bad = copy.deepcopy(admission)
    bad['case_ids'][0] = 'adaptive__original_outlet_original_states'
    with pytest.raises(ValueError, match='case identities'):
        validate_admission(bad, manifest_sha, diagnostic_sha, review_path)
    bad = copy.deepcopy(admission)
    bad['admitted'] = False
    with pytest.raises(ValueError, match='admission'):
        validate_admission(bad, manifest_sha, diagnostic_sha, review_path)


def test_admission_rejects_changed_proof_or_exception_scope():
    admission = json.loads((Path(__file__).parent / 'proofs/analysis_admission_002.json').read_text())
    args = (admission['source_manifest_sha256'], admission['diagnostic_sha256'],
            admission['independent_scope_review']['path'])
    bad = copy.deepcopy(admission)
    bad['proofs']['diagnostic.json']['sha256'] = 'f'*64
    with pytest.raises(ValueError, match='proof'):
        validate_admission(bad, *args)
    bad = copy.deepcopy(admission)
    bad['exception']['maximum_absolute_difference'] = 1e-4
    with pytest.raises(ValueError, match='exception'):
        validate_admission(bad, *args)


def test_changed_bound_proof_and_hash_are_rejected(tmp_path):
    path = tmp_path / 'proof.json'
    path.write_text(json.dumps({'ok': True}), encoding='utf-8')
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert checked_json({'path':str(path),'sha256':digest}, tmp_path) == {'ok': True}
    path.write_text(json.dumps({'ok': False}), encoding='utf-8')
    with pytest.raises(ValueError, match='hash'):
        checked_json({'path':str(path),'sha256':digest}, tmp_path)


def test_case_bindings_reject_selection_or_statistics_substitution():
    source = [dict(case_id=cid, files={k:{'path':f'/r/{cid}/{k}', 'sha256':str(i)*64}
                                         for i,k in enumerate(('completion','metrics','statistics'),1)})
              for cid in CASE_IDS]
    assert validate_case_bindings(copy.deepcopy(source), copy.deepcopy(source))
    bad = copy.deepcopy(source)
    bad[2]['files']['statistics']['sha256'] = 'f'*64
    with pytest.raises(ValueError, match='binding'):
        validate_case_bindings(bad, source)


def test_selection_requires_validation_frozen_rate_and_no_test_peek():
    selection = dict(state='ADAPTIVE_VALIDATION_SELECTION_FROZEN',
                     selected_delta_r=0.01, test_data_read=False)
    assert analysis.validate_selection(selection)
    for change in ({'selected_delta_r': 0.02}, {'test_data_read': True},
                   {'state': 'DRAFT'}):
        with pytest.raises(ValueError, match='selection'):
            analysis.validate_selection(dict(selection, **change))


def test_output_rejects_existing_or_outside_child(tmp_path):
    root = tmp_path / 'remote'
    parent = root / 'three_method_analysis_002'
    parent.mkdir(parents=True)
    target = parent / 'run_001'
    assert analysis.output_target(target, root) == target
    target.mkdir()
    with pytest.raises(ValueError, match='Output'):
        analysis.output_target(target, root)
    with pytest.raises(ValueError, match='Output'):
        analysis.output_target(root / 'elsewhere', root)


def test_failure_json_replaces_nonfinite_number_with_explicit_text(tmp_path):
    path = tmp_path / 'failure.json'
    analysis.write_json(path, {'accepted': False, 'difference': float('nan')})
    saved = json.loads(path.read_text(encoding='utf-8'))
    assert saved == {'accepted': False, 'difference': 'NONFINITE_nan'}


def test_manifest_builder_binds_exact_admission_and_three_sources():
    local = Path(__file__).parent / 'proofs'
    manifest = build(local / 'analysis_admission_002.json',
                     local / 'three_method_scope_independent_review_002.md')
    admission = json.loads((local / 'analysis_admission_002.json').read_text())
    assert [case['case_id'] for case in manifest['cases']] == list(CASE_IDS)
    assert manifest['proofs']['admission']['sha256'] == hashlib.sha256(
        (local / 'analysis_admission_002.json').read_bytes()).hexdigest()
    assert manifest['proofs']['scope_review'] == admission['independent_scope_review']
    assert manifest['proofs']['audit_manifest'] == admission['proofs']['audit_manifest_001.json']


def _main_with_fake_run(monkeypatch, root, fake_run):
    (root / 'three_method_analysis_002').mkdir(parents=True)
    manifest_path = root / 'manifest.json'
    manifest_path.write_text('{}', encoding='utf-8')
    output = root / 'three_method_analysis_002/job_synthetic'
    monkeypatch.setattr(analysis, 'REMOTE', root)
    monkeypatch.setattr(analysis, 'run', fake_run)
    monkeypatch.setattr(sys, 'argv', ['analyze_three_methods.py', '--manifest', str(manifest_path),
                                    '--manifest-sha256', hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
                                    '--output', str(output)])
    return output


def test_second_source_failure_keeps_first_and_failing_ledger_rows(monkeypatch, tmp_path):
    root = tmp_path / 'remote'
    root.mkdir()
    first = root / 'first.json'
    second = root / 'second.json'
    first.write_text('first', encoding='utf-8')
    second.write_text('second', encoding='utf-8')
    first_sha = hashlib.sha256(first.read_bytes()).hexdigest()
    source = dict(proofs={'first': {'path': str(first), 'sha256': first_sha},
                          'second': {'path': str(second), 'sha256': '0'*64}},
                  selection={'path': str(first), 'sha256': first_sha}, cases=[])

    def fake_run(_manifest, task_root, report, _archives):
        analysis._source_ledger(source, task_root, report['source_ledger'])

    output = _main_with_fake_run(monkeypatch, root, fake_run)
    with pytest.raises(ValueError, match='second source hash mismatch'):
        analysis.main()
    saved = json.loads((output / 'failure.json').read_text(encoding='utf-8'))
    assert saved['accepted'] is False
    assert saved['source_ledger']['first']['read_state'] == 'VERIFIED'
    assert saved['source_ledger']['second']['read_state'] == 'HASH_MISMATCH'
    assert saved['source_ledger']['second']['expected_sha256'] == '0'*64


def test_unreadable_rehash_does_not_hide_original_failure(monkeypatch, tmp_path):
    root = tmp_path / 'remote'
    root.mkdir()
    proof = root / 'proof.json'
    proof.write_text('proof', encoding='utf-8')
    proof_sha = hashlib.sha256(proof.read_bytes()).hexdigest()
    original_sha = analysis.sha

    def fake_sha(path):
        if Path(path) == proof:
            raise PermissionError('synthetic unreadable input')
        return original_sha(path)

    def fake_run(_manifest, _root, report, _archives):
        report['completed_cases']['synthetic'] = {'status': 'DONE'}
        report['source_ledger']['proof'] = dict(path=str(proof), expected_sha256=proof_sha,
                                                before_sha256=proof_sha, read_state='VERIFIED')
        raise RuntimeError('original analysis failure')

    output = _main_with_fake_run(monkeypatch, root, fake_run)
    monkeypatch.setattr(analysis, 'sha', fake_sha)
    with pytest.raises(RuntimeError, match='original analysis failure'):
        analysis.main()
    saved = json.loads((output / 'failure.json').read_text(encoding='utf-8'))
    assert saved['failed_check'] == 'RuntimeError'
    assert saved['error'] == 'original analysis failure'
    assert saved['source_ledger']['proof']['after_state'] == 'UNREADABLE'
    assert saved['completed_partial_summaries']['completed_cases']['synthetic'] == {'status': 'DONE'}
    assert not (output / 'analysis.json').exists()


def test_completed_first_block_survives_later_draw_failure(monkeypatch):
    base, frozen = analysis._frozen()
    class FailingDraws:
        def paired_draws(self, values, length, draws, seed):
            if length == 3:
                raise ValueError('degenerate synthetic second block')
            return frozen.paired_draws(values, length, draws, seed)
    monkeypatch.setattr(analysis, '_frozen', lambda: (base, FailingDraws()))
    progress, archive, owner = {}, {}, {}
    with pytest.raises(ValueError, match='second block'):
        interval_analysis([samples(), samples(0.2), samples(0.4)],
                          block_lengths=(4, 3), draws=7, seed=20260915,
                          progress=progress, archives=archive, point_progress=owner)
    assert progress['4']['n_draws'] == 7
    assert '3' not in progress
    assert '4' in archive
    assert owner['sensitivity_point_metrics']['methods'][CASE_IDS[0]]['nse']['per_lead'][0] == pytest.approx(0.97)


def test_second_block_failure_json_retains_first_interval(monkeypatch, tmp_path):
    base, frozen = analysis._frozen()
    class FailingDraws:
        def paired_draws(self, values, length, draws, seed):
            if length == 3:
                raise ValueError('degenerate synthetic second block')
            return frozen.paired_draws(values, length, draws, seed)
    monkeypatch.setattr(analysis, '_frozen', lambda: (base, FailingDraws()))
    cases = [samples(), samples(0.2), samples(0.4)]

    def fake_run(_manifest, _root, report, archives):
        report['point_metrics'] = point_metrics(cases)
        report['intervals'] = {}
        interval_analysis(cases, block_lengths=(4, 3), draws=7,
                          progress=report['intervals'], archives=archives,
                          point_progress=report)

    root = tmp_path / 'remote'
    root.mkdir()
    output = _main_with_fake_run(monkeypatch, root, fake_run)
    with pytest.raises(ValueError, match='second block'):
        analysis.main()
    saved = json.loads((output / 'failure.json').read_text(encoding='utf-8'))
    assert saved['state'] == 'FAILED' and saved['accepted'] is False
    assert saved['completed_partial_summaries']['intervals']['4']['n_draws'] == 7
    assert '3' not in saved['completed_partial_summaries']['intervals']
    assert 'sensitivity_point_metrics' in saved['completed_partial_summaries']
    assert not (output / 'analysis.json').exists()


def test_launcher_requires_inputs_and_allows_unset_conda_variable(tmp_path):
    def bash_path(path):
        path = Path(path)
        return '/mnt/' + path.drive[0].lower() + '/' + str(path.relative_to(path.anchor)).replace('\\', '/')

    launcher = Path(__file__).parent / 'launch_three_methods.slurm'
    missing = subprocess.run(['bash', bash_path(launcher)], capture_output=True, text=True,
                             encoding='utf-8')
    assert missing.returncode != 0
    task_root = tmp_path / 'task_root'
    code = task_root / 'three_method_analysis_002/code'
    code.mkdir(parents=True)
    manifest = task_root / 'manifest.json'
    manifest.write_text('{}', encoding='utf-8')
    conda = tmp_path / 'conda.sh'
    conda.write_bytes(b'conda() { : "${SYNTHETIC_OPTIONAL_CONDA_VAR}"; }\n')
    script = launcher.read_text(encoding='utf-8')
    script = script.replace('/data1/home/sunyiq/kalmannet_wrr_closeout_20260928_v1',
                            bash_path(task_root))
    script = script.replace('/data1/home/sunyiq/miniconda3/etc/profile.d/conda.sh',
                            bash_path(conda))
    script = script.split('python -B -u analyze_three_methods.py')[0] + "printf 'launched\\n'\n"
    fake_launcher = tmp_path / 'launcher.sh'
    fake_launcher.write_bytes(script.encode('utf-8'))
    missing_job = subprocess.run(['bash', bash_path(fake_launcher), bash_path(manifest), 'a'*64],
                                 capture_output=True, text=True, encoding='utf-8')
    assert missing_job.returncode != 0
    wrapper = tmp_path / 'job_wrapper.sh'
    wrapper.write_bytes(b'export SLURM_JOB_ID=123\nexec bash "$@"\n')
    missing_hash = subprocess.run(['bash', bash_path(wrapper), bash_path(fake_launcher),
                                   bash_path(manifest)], capture_output=True,
                                  text=True, encoding='utf-8')
    assert missing_hash.returncode != 0
    ok = subprocess.run(['bash', bash_path(wrapper), bash_path(fake_launcher),
                         bash_path(manifest), 'a'*64],
                        capture_output=True, text=True, encoding='utf-8')
    assert ok.returncode == 0, ok.stderr
    assert 'launched' in ok.stdout
