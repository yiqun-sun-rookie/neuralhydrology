# Independent operational submission review

Decision: **conditionally acceptable operational wrappers; deployment is not yet accepted**. Critical / Important / Minor findings: **C=0 / I=0 / M=0**, conditional on the controller checks below. The corrected-array implementation review and the three-method implementation repair/review remain pending; this report does not replace them or authorize submission.

## Exact reviewed bindings

| New script | SHA-256 verified from the full local file |
|---|---|
| `submit_corrected_array_audit.sh` | `04e302ae865ddc44b77e94d996dead6de4e5605cd1c65221e88e315984a656f0` |
| `submit_three_method_035.sh` | `90ecf726648d3b3156359ad1a35d55065133d692c109fceccd6e0ba0bef1f9a2` |

Both files are under `hpc/completed_results_continuation_002/` in `docs/plans/wrr-hamid-all-comments-completion-20260928-v1`. Any script change invalidates this binding. Review used the reproducibility-check skill and the two corresponding implementation briefs. This was one static pass; no shell execution of either script, remote action, raw-array inspection, full code test suite, or synthetic execution was performed. Both `bash -n` passes were reported by the controller and were not independently rerun.

## Evidence and limits

Each script validates externally supplied lowercase SHA-256 arguments, refuses an existing or dangling-symlink target and job-id file, requires no active job whose working directory is inside the isolated task root, and verifies the archive checksum before extraction. Pipeline failures propagate through `set -eo pipefail`; failure to obtain the queue listing does not silently become an empty queue. Extraction uses `--keep-old-files`, followed by a real-directory check and internal package checksum verification.

The corrected-array wrapper also pins the two previously frozen helper files and requires its output directory to be absent. The three-method wrapper separately pins its analysis manifest and requires both review files and the admission proof to be nonempty. These existence checks do not establish favorable review conclusions or correct proof contents; admission depends on the controller and the separately reviewed implementation.

Each wrapper contains exactly one `sbatch` invocation, exclusively creates an attempt marker before calling it, captures its output and exit status, exclusively preserves the receipt, and records a job number only after success and an exact submission-message match. There is no retry, cancellation, model invocation, training invocation, or GPU request in these wrappers. Resources and actual job behavior are delegated to their packaged launchers. A post-submission receipt, parsing, accounting, or queue failure must be treated as potentially already submitted; it does not authorize rerunning the wrapper. The retained target and attempt marker support that boundary.

## Required controller checks before publishing or submitting

1. Finish and accept the corrected-array code review and the three-method repair/code reviews for the exact source revisions. Verify their conclusions, unresolved-finding counts, source hash bindings, admission proof, and prerequisite reviews. Merely packaging nonempty Markdown is insufficient. Preserve the historical failed evidence and the three-method exception's expressly limited scope.
2. Inspect each final archive locally as an archive, not only as an extracted directory. Establish the exact complete set of regular-file members, all beneath its one expected target directory; reject links, special entries, duplicate members, absolute paths, parent traversal, and unexpected members. Bind each member's bytes to the accepted local source/proof/review file. Exclude runtime attempt markers, submission receipts, job-id files, and output artifacts. The three-method `tar -tf ... | sort > /dev/null` is a readability check, not a membership validator.
3. Verify `package_files.sha256` locally as an exact complete inventory of all packaged files other than the checksum manifest itself: no missing, extra, duplicate, or unsafe entries; all entries match the accepted source bytes. The external archive checksum binds the checksum manifest itself. Record the final archive SHA-256 only after these checks and pass that exact value to the corresponding wrapper. For the three-method job, independently record and pass the SHA-256 of the packaged `analysis_manifest_003.json`. Retain this evidence together with the script hashes above.
4. Check the accepted packaged launchers and manifests enforce a single CPU-only job using at most four CPU cores, the prescribed partition/excluded node/time limit, no GPU allocation, no model or training execution, no requeue, and an exclusive absent output directory. Confirm the actual submission environment does not supply `SBATCH_*` overrides that change those resource or execution settings. These properties cannot be established from the wrappers alone.
5. Keep submission serialized within this isolated task root, with no other controller submitting concurrently. The queue check is a snapshot, not a reservation or cross-script lock. Submit the second job only after the first has a terminal state and the task queue is empty; this preserves the total four-core ceiling. Confirm the isolated parent and published archive remain stable between validation and use. Preserve the attempt, receipt, and any job-id evidence after every outcome; inspect status without retrying if submission success is ambiguous.

These are explicit trust and operating conditions, not evidence that the pending implementation, package, runtime, or scientific result has already passed. No wrapper repair is required within the stated controller-validated, serialized workflow. Missing any required check leaves deployment unaccepted.
