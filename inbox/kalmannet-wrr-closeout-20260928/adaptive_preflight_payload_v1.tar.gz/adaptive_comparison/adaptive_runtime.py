"""Historical and matched observation-noise adaptation; no access at import.

Only the matched family's sigma-point kappa and per-window initial covariance
change from the bound historical adaptive model. All matched cases share one
core and differ only in whether/how quickly observation variance is adapted.
"""
import copy
from dataclasses import replace
from types import MethodType, SimpleNamespace

RT = CR = None


def bind(runtime, comparator):
    global RT, CR
    RT, CR = runtime, comparator


def matched_reset(self, x0_sequence, seq_len=None):
    """Exactly the archived hand-tuned per-window covariance, without jitter."""
    import torch
    del seq_len
    self._flush_validation_diagnostics()
    x0 = x0_sequence.detach().clone().to(self.device)
    self.batch_size = int(x0.shape[0])
    self.base_filter.batch_size = self.batch_size
    self.core.reset(x0, torch.diag_embed(0.1 * x0.clone()))


def build_runtime(case, output, device='cuda'):
    import torch
    import yaml
    if RT is None or CR is None:
        raise RuntimeError('Bind the authenticated legacy runtime first')
    CR.seal_imports('adaptive')
    physical_case = dict(method='adaptive', variant='original_outlet_original_states',
                         batch_size=case['batch_size'])
    path, proof = CR.physical_source(physical_case, output, 'plain')
    RT.load_module(path, 'probe_walrus_observed')
    RT.load_module(RT.FORMAL / 'sources/system_model.py', 'probe_system_model')
    RT.load_module(RT.FORMAL / 'sources/params.py', 'probe_params')
    initial = RT.load_module(RT.FORMAL / 'sources/initializer.py')
    system, hydro = initial.initialize_system_model(800, 800, device=device)
    cfg = yaml.safe_load(CR.ADAPT_CONFIG.read_text(encoding='utf-8'))
    cfg = copy.deepcopy(cfg)
    matched = case['family'] == 'matched'
    if matched:
        cfg['sigma_points']['kappa'] = -2.0
    enabled = case['mode'] != 'fixed'
    cfg['adaptive_covariance']['adapt_q'] = False
    cfg['adaptive_covariance']['adapt_r'] = enabled
    cfg['training']['forecast_lead_time'] = case['forecast_positions']
    cfg['dataloader']['batch_size'] = case['batch_size']
    args = CR.builders('adaptive').build_args(cfg, torch.zeros(800), torch.zeros(800))
    args.device = device
    rate = case['delta_r']
    model = CR.adaptive_builder()(cfg, system, args, 1.0 / (rate or 0.01)).to(device)
    if not enabled:
        model.core.config = replace(model.core.config, delta_r=0.0)
    if matched:
        model.init_sequence = MethodType(matched_reset, model)
    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    effective = dict(
        family=case['family'], mode=case['mode'], delta_r=float(rate),
        sigma_points=cfg['sigma_points'],
        initial_covariance='diag(0.1 * window initial state); no added jitter' if matched
        else 'diag([14,100,0.4,120,0.01]) + 1e-6 I',
        Q=[0.14, 1.0, 0.004, 1.2, 0.0], R_initial=1.5e-5,
        adaptive_config={k: v for k, v in model.core._config_state().items() if k != 'q_basis'},
        physics='original archived outlet; no outlet counters/state recording',
        original_physics_sha256=RT.sha(RT.PROBE / 'sources/walrus.py'),
        numerical_safeguards_unchanged=True,
        matched_core_identity_not_assumed_equal_to_historical_hand_tuned=True,
        instrumentation=proof,
    )
    return SimpleNamespace(case=case, model=model, args=args, system=system,
                           hydro=hydro, core=RT.load_core(), device=device,
                           mode='plain', effective=effective)


def infer(runtime, batch, forecast_positions=None):
    import torch
    count = forecast_positions or runtime.case['forecast_positions']
    prepare = RT.load_module(RT.FORMAL / 'sources/prepare.py').prepare_batch_data
    p, ep, obs, states, hours = prepare(batch, runtime.device)
    model = runtime.model
    model.batch_size = obs.shape[0]
    model.update_mode = True
    model.init_hidden_KNet()
    model.init_sequence(states[:, :, 0], obs.shape[-1])
    updated, outputs = runtime.core.forward_sequence(
        SimpleNamespace(knet_model=model, sys_model=runtime.system, args=runtime.args),
        obs, torch.cat((p, ep), dim=1))
    forecasts, predictions = runtime.core.system_model_forecast(
        runtime.system, p, ep, updated, count)
    return dict(updated=updated, outputs=outputs, forecast_states=forecasts,
                predictions=predictions, observation=obs, hours=hours)


def historical_hand_infer(runtime, batch, forecast_positions):
    """Exact extracted archived hand-tuned batch, with configurable horizon.

    No wrapper hooks, outlet counters or state records. This is a validation
    bridge only, not an extra full-period scientific evaluation configuration.
    """
    import torch
    from filters.filter.non_batch.kalman import MerweScaledSigmaPoints
    from filters.filter.batch.my_version.batch_unscentedkalmanfilter_gpu import BatchUnscentedKalmanFilterGPU
    from filters.da_coupler.walrus_batch import fx_walrus_batch, hx_walrus_batch
    core = runtime.core
    ns = dict(torch=torch,
              prepare_batch_data=RT.load_module(RT.FORMAL / 'sources/prepare.py').prepare_batch_data,
              system_model_forecast=core.system_model_forecast,
              rearrange_data_unfold=core.rearrange_data_unfold,
              lead_time=forecast_positions, MerweScaledSigmaPoints=MerweScaledSigmaPoints,
              BatchUnscentedKalmanFilterGPU=BatchUnscentedKalmanFilterGPU,
              fx_walrus_batch=fx_walrus_batch, hx_walrus_batch=hx_walrus_batch,
              HANDTUNED_Q=[0.14, 1.0, 0.004, 1.2, 0.0], HANDTUNED_R=[1.5e-5])
    source, proof = CR.manual_adapter_source('hand_tuned')
    if not proof['retained_computation_exact_ast']:
        raise ValueError('Historical batch extraction changed computation')
    exec(compile(source, str(CR.PAPER) + '#exact_hand_batch', 'exec'), ns)
    result = ns['execute'](batch, runtime.device, runtime.system, runtime.hydro, None)
    result['predictions'] = result['predictions'].reshape(-1, 1, forecast_positions)
    return result
