# 在线观测噪声公平比较：执行准备与交付边界

状态：`PREPARED_PENDING_INDEPENDENT_CODE_REVIEW`。本目录已准备可执行代码及 7 个配置；**尚未开始真实模型计算，不是实验结果或准入通过证明**。仅本目录可写，旧代码、旧结果和手稿保持不变。

## 已冻结范围

| 配置标识 | 分期与用途 | 在线观测方差调整 |
| --- | --- | --- |
| historical_r001_validation | 历史候选按统一目标重新评分，只审计选择规则 | 平滑率 0.01 |
| historical_r002_validation | 同上 | 平滑率 0.02 |
| matched_fixed_validation | 同核心固定组验证 | 关闭 |
| matched_r001_validation | 同核心在线组验证 | 平滑率 0.01 |
| matched_r002_validation | 同上 | 平滑率 0.02 |
| matched_fixed_test | 验证选择冻结后的固定组测试 | 关闭 |
| matched_selected_test | 验证选择冻结后的选中在线组测试 | 待验证选择，不能预填 |

不训练、不增加候选率、不增加滤波家族。前 5 个完整验证配置缺一不可，失败时不能从幸存候选中选择；保留失败记录并按总计划决定限制性回应。历史重排不是匹配组选择，历史胜者变化不增加一个历史测试配置，也不把旧测试分数转嫁给新胜者。

匹配组在查看新验证和测试结果前冻结为原物理出口实现及原保存初态，理由是与当前主表实现相连，而非根据测试优劣挑选。所有匹配组使用同一个归档滤波核心：确定性取样参数 `alpha=0.6874, beta=2, kappa=-2`；每窗口初始协方差 `diag(0.1 * x0)`，不加额外扰动；固定过程协方差对角 `[0.14, 1, 0.004, 1.2, 0]`；初始观测方差 `0.000015`；过程噪声不在线调整；数值保护、重置、物理传播与评分路径相同。关闭/开启只改变观测方差更新开关和已列明的平滑率。

历史候选保留其归档设置：`kappa=0`，初始协方差 `diag([14,100,0.4,120,0.01]) + 1e-6 I`。不得把这两个初始化设置不同的家族称作只差在线开关的消融。

## 来源与可复用边界

`matched_protocol.json` 绑定 487 个源码/元数据文件；`deployment_inputs.json` 枚举这些文件、两个数据路径及协议，共 490 项。每项有绝对本地路径、摘要和用途，可与原结果影响工作包去重部署。真实数据摘要继承已核证历史配置，**本次准备未读取、重新哈希或反序列化任何真实张量**。

- 历史选型记录：`artifacts/regge_adaptive_covariance_ukf_v1_validation/selection.json`，摘要 `f4dbca35ee4adc2487a506d6b95d93e18646e50f0a7a4d2881a652b5ae9da0a8`。候选率 0.02、0.01 的旧验证纳什效率分别为 `-0.035117275899987296`、`0.1514296324`（后者此处显示截断值，以来源 JSON 为准），旧选择 0.01。
- 旧目标按批次平均当前至未来 11 小时，不能当作本次“先汇总每时效、再平均未来 1—12 小时”的选择成绩。登记的验证目录只有选型记录，没有可直接恢复本次目标的逐发布时间充分统计；因此两个历史验证候选仍待重新计算，不能声称找回了缺失统计。
- 旧自适应测试目录的 `batch_sufficient_statistics.npz` 只用于历史测试追溯，不能用来验证选率；本次未打开它。旧手调完整 `artifacts/wrr_selected_model_results_20260920_v1/run_003/hand_tuned/issue_statistics.npz` 可供后续同域审计，当前未打开。
- 固定匹配包装先在验证样本上与旧手调逐计算语句桥接，保存轨迹摘要、预测最大绝对差及逐时效纳什效率差。即使样本逐位相等，也不宣称全期同一；不同则命名为“匹配固定噪声实现”，旧手调模型不被覆盖或重命名。
- 旧带计数/状态记录的准入结果不能替代此新无记录计算路径的准入。新高性能计算环境记录并单独验收，不宣称与旧本机环境逐位一致。

## 部署与依赖

由主控按 `deployment_inputs.json` 复制精确字节到已授权独占目录。本包不连接远端、不提交任务。需要 Python、NumPy、PyTorch（正式计算需可用图形处理器）、PyYAML，以及清单中的冻结工程源。`unittest` 属于标准库，不需安装 pytest。

目录迁移通过 `--path-map path_map.json` 完成，不改原协议或归档源码中的路径。文件内容形式是如下列表；目标路径由主控核实，不能原样使用示意占位符：

```json
[
  {"source": "G:/github/pycharm/projects/kalmannet/data/processed/high_flow_aug/val_win800_20070527_04-20090314_13.pt", "target": "/verified/read-only/validation.pt"},
  {"source": "G:/github/pycharm/projects/kalmannet/data/processed/high_flow_aug/test_win800_20090314_14-20110101_01.pt", "target": "/verified/read-only/test.pt"},
  {"source": "G:/github/pycharm/projects/kalmannet", "target": "/verified/new-root/project"},
  {"source": "C:/Users/yiqun/.codex/worktrees/c7a4/kalmannet", "target": "/verified/new-root/archived-c7a4"}
]
```

最长前缀优先，因此可把大数据映射到已核验只读文件、其余源码映射到独占新根。协议仍以原字节摘要核验，源码复制后逐文件核验。另复制本目录测试及说明文档，便于审计，但它们不参与数值推断。主控可按授权哈希及传输原测试文件，不得在验证选择前反序列化或评分它。

## 运行顺序

以下命令以本目录为工作目录，`python` 由主控绑定目标环境，所有输出必须是本目录下不存在的新目录。失败目录保留，不能重用。每个命令单独启动新进程。

1. 独立审核源码/协议，生成真实审核准入回执。示意字段如下，不能将示例当作通过记录：

```json
{"state":"ADAPTIVE_CODE_ACCEPTED_FOR_PREFLIGHT","open_critical_important_findings":0,"protocol_sha256":"<实际协议摘要>","reviewer":"<真实独立审核身份>","review_path":"<真实审核报告绝对路径>","review_sha256":"<该报告摘要>"}
```

2. 对前 5 个验证配置分别执行前 128 个验证窗口的两遍准入；不会读取测试文件。该样本量已冻结，不能放大超过 256。

```text
python -B adaptive_driver.py preflight --case-id matched_fixed_validation --output runs/matched_fixed_validation/preflight_001 --code-acceptance code_acceptance.json --path-map path_map.json
```

3. 独立审核每个准入结果，确认两次轨迹逐位相等、时间与目标映射无误、输入未改、来源/环境一致及固定组桥接解释。生成逐配置真实回执：

```json
{"state":"ADAPTIVE_PREFLIGHT_ACCEPTED","open_critical_important_findings":0,"case_id":"matched_fixed_validation","protocol_sha256":"<实际协议摘要>","completion_path":"<准入 completion.json 绝对路径>","completion_sha256":"<其摘要>","reviewer":"<真实独立审核身份>","review_path":"<真实报告绝对路径>","review_sha256":"<其摘要>"}
```

4. 对已单独准入的 5 个验证配置各完整计算一次；正式环境必须与该配置准入完全相同，且五配置间也须一致。

```text
python -B adaptive_driver.py run --case-id matched_fixed_validation --output runs/matched_fixed_validation/full_001 --code-acceptance code_acceptance.json --preflight-acceptance matched_fixed_validation_acceptance.json --path-map path_map.json
```

5. 五配置齐全后冻结选择，命令只读保存数组。逐发布计数、观测和、观测平方和、观测序列和时间必须相同；目标为先汇总每时效再平均未来 1—12 小时纳什效率，较大者入选、完全相同则选 0.01。历史与匹配分别重排，只把匹配胜者传入新测试。

```text
python -B adaptive_driver.py freeze-selection --output selections/selection_001 --validation-results runs/historical_r001_validation/full_001 runs/historical_r002_validation/full_001 runs/matched_fixed_validation/full_001 runs/matched_r001_validation/full_001 runs/matched_r002_validation/full_001 --path-map path_map.json
```

产出 `selection_frozen.json`、`historical_selection.json`；协议和五个真实结果绑定于摘要，不新增模型配置。主控把本轮版本化路径登记到总清单中的规范交付项，不覆盖旧版本。

6. 两个测试配置也先以**验证数据**完成相同重复准入（此时采用 48 个计算位置），再由独立审核员逐配置准入后完整测试。两步都须带同一 `--selection selections/selection_001/selection_frozen.json`；未有选择记录会在数据加载前拒绝。

```text
python -B adaptive_driver.py preflight --case-id matched_selected_test --output runs/matched_selected_test/preflight_001 --selection selections/selection_001/selection_frozen.json --code-acceptance code_acceptance.json --path-map path_map.json
python -B adaptive_driver.py run --case-id matched_selected_test --output runs/matched_selected_test/full_001 --selection selections/selection_001/selection_frozen.json --code-acceptance code_acceptance.json --preflight-acceptance matched_selected_test_acceptance.json --path-map path_map.json
```

测试固定组同理。计算位置 0—47，只留 0—24；发布起点仍按 48 个计算位置限定，不把 25 个保留位置当作更长的发布域。

7. 两组完成后只从保存统计汇总，不重跑模型、不重开原测试数据：

```text
python -B adaptive_driver.py summarize-test --output summaries/summary_001 --selection selections/selection_001/selection_frozen.json --test-results runs/matched_fixed_test/full_001 runs/matched_selected_test/full_001 --path-map path_map.json
```

生成 `results.json` 和 `readout.md`，含逐时效七指标和未来 1—12/13—24 小时纳什效率差。该汇总仍标为待科学独立审核；与学习噪声方法的实际差异需在主控证据整合中连接原结果影响工作包的**同域已准入原实现结果**，不能仅凭这两组声称已完成全部方法比较，也不能从单一观测方差调整推广到所有自适应协方差方法。

## 合成测试与尚缺证据

2026-09-28 已运行：

```text
C:\Users\yiqun\anaconda3\envs\knet_clean\python.exe -B -m unittest -v test_adaptive_preparation
```

20 项全部通过，测试内部用时 0.638 秒。包括真实归档滤波核心在人工系统上的关闭包装/直调一致性、调整只作用于下一时步、窗口重置、13/48 位置的独立直接评分参考、时间错位和非有限值拒绝、缺候选/测试选率/缺选择记录拒绝、已冻结验证结果被改动拒绝、保存测试结果汇总，以及路径迁移规则。

仍缺：真实图形处理器路径准入及固定组桥接结果；五个完整验证结果及选中率；两个完整测试结果；最终同域学习噪声比较和科学独立验收。计算时间及所需显存目前无法确定，应从目标设备准入记录估计，不能拿本次合成测试的秒数推算真实评价时间。
