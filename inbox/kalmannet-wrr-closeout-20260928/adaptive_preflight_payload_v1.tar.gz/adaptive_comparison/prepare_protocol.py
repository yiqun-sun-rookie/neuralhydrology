"""Freeze metadata/source identities only; never load/hash data tensors."""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
LEGACY = HERE.parent.parent / 'wrr-hamid-evaluation-20260927-v1'
REPO = HERE.parents[3]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_new(path, data):
    with Path(path).open('x', encoding='utf-8') as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False, allow_nan=False)
        handle.write('\n')


def cases():
    rows = []
    for family, modes in [('historical', [('r001', .01), ('r002', .02)]),
                          ('matched', [('fixed', 0.), ('r001', .01), ('r002', .02)])]:
        for mode, rate in modes:
            rows.append(dict(case_id=f'{family}_{mode}_validation', family=family,
                             mode=mode, delta_r=rate, split='validation', batch_size=128,
                             forecast_positions=13, retain_positions=13,
                             full_window_count=14979, source_hour_count=15778,
                             issue_count=15766, pairs_per_lead=11803452,
                             purpose='selection-rule audit' if family == 'historical' else 'matched validation',
                             state='PREPARED_NOT_RUN', training=False))
    for mode, rate in [('fixed', 0.), ('selected', None)]:
        rows.append(dict(case_id=f'matched_{mode}_test', family='matched', mode=mode,
                         delta_r=rate, split='test', batch_size=128,
                         forecast_positions=48, retain_positions=25,
                         full_window_count=14981, source_hour_count=15780,
                         issue_count=15733, pairs_per_lead=11280693,
                         purpose='matched fixed-versus-selected adaptive test',
                         state='WAITING_FOR_FROZEN_VALIDATION_SELECTION', training=False))
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=HERE / 'matched_protocol.json')
    args = parser.parse_args()
    if args.output.resolve().parent != HERE:
        raise ValueError('Protocol must be a new file in this package')
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(LEGACY))
    rt = importlib.import_module('neural_runtime')
    cr = importlib.import_module('comparator_runtime')
    bindings, proof = cr.verify_sources()
    selection = rt.read_json(cr.SELECTION)
    if sorted(float(c['delta_r']) for c in selection['candidates']) != [.01, .02]:
        raise ValueError('Historical rate identity is not exactly .01/.02')
    legacy_names = ['neural_runtime.py', 'comparator_runtime.py', 'evaluate_neural.py',
                    'prepare_test_states.py', 'diagnostic_capture.py']
    for name in legacy_names:
        bindings[str(LEGACY / name)] = digest(LEGACY / name)
    source_rows = rt.read_json(rt.MAIN / 'source_manifest.json')
    for row in source_rows:
        bindings[row['path']] = rt.verify(row['path'], row['sha256'])
    for path in (HERE / 'adaptive_runtime.py', HERE / 'adaptive_driver.py', Path(__file__)):
        bindings[str(path)] = digest(path)
    # Data fingerprints are inherited from the authenticated historical config;
    # this metadata preparation does not read either validation or test tensors.
    datasets = dict(
        validation=dict(path=str(REPO / 'data/processed/high_flow_aug/val_win800_20070527_04-20090314_13.pt'),
                        sha256='2e195fc974b5cc8cdb35df3cb7fd72a202af033ecc415acc03a87020b00bd403'),
        test=dict(path=str(REPO / 'data/processed/high_flow_aug/test_win800_20090314_14-20110101_01.pt'),
                  sha256='df18203c073314c5a15c6df77411cb972a0a3f983d97cc468760ff12dbd6908a'))
    paths = {name: str(getattr(rt, name)) for name in ['ROOT', 'REPO', 'FORMAL', 'PROBE', 'MAIN', 'COMPACT', 'SOURCE', 'RULES']}
    paths.update(ARCHIVE=str(cr.ARCHIVE), REFRESH=str(cr.REFRESH), PAPER=str(cr.PAPER),
                 SELECTION=str(cr.SELECTION), ADAPT_CONFIG=str(cr.ADAPT_CONFIG))
    protocol = dict(
        schema='hamid_matched_adaptive_protocol_v1', state='PREPARED_PENDING_INDEPENDENT_CODE_REVIEW',
        family='historical_selection_audit_and_matched_observation_noise_adaptation',
        created_from_plan=str(HERE.parent / 'plan.md'), plan_sha256=digest(HERE.parent / 'plan.md'),
        output_root=str(HERE), physics='original', initial_states='original saved dataset states',
        physics_reason='Match archived manuscript implementation; chosen before any new validation/test evaluation.',
        original_physics_sha256='703adbb37c7bd3804f7f218664c9636f4a3c5a303687fdbb33fc6172b0daffd2',
        delta_r_candidates=[.01, .02], matched_fixed_delta_r=0.,
        matched_sigma=dict(alpha=.6874, beta=2., kappa=-2.),
        matched_initial_covariance='diag(0.1 * window initial state), no added jitter',
        historical_sigma=dict(alpha=.6874, beta=2., kappa=0.),
        historical_initial_covariance='diag([14,100,0.4,120,0.01]) + 1e-6 I',
        Q=[.14, 1., .004, 1.2, 0.], R_initial=1.5e-5, adapt_q=False,
        selection=dict(metric='pooled per-lead NSE averaged over future positions 1..12',
                       direction='maximize', tie_break='smaller delta_r',
                       fail_policy='Both rate candidates must complete; do not select among survivors.',
                       test_access_before_selection=False, historical_rerank_only=True),
        bridge=dict(scope='fixed matched vs exact archived hand-tuned validation batch',
                    acceptance='Report bitwise and per-lead metrics; differing output is a separately named matched fixed implementation, never an old hand-tuned identity.',
                    historical_complete_test_statistics=str(rt.MAIN / 'run_003/hand_tuned/issue_statistics.npz')),
        preflight=dict(first_validation_windows=128, maximum=256, repetitions=2,
                       outputs=['updated', 'outputs', 'forecast_states', 'predictions'],
                       same_environment_required=True, independent_acceptance_required=True),
        maximum_full_configurations=7, new_training_units=0,
        cases=cases(), datasets=datasets, legacy_paths=paths, source_bindings=bindings,
        sealed_source_records=source_rows, archive_equivalents=proof['relocations'],
        historical_selection=dict(path=str(cr.SELECTION), sha256=cr.SELECTION_SHA,
                                  chosen_delta_r=selection['selected']['delta_r'],
                                  old_metric='batch-averaged validation NSE over current plus future 1..11',
                                  candidates=selection['candidates'],
                                  saved_pooled_validation_arrays='not present in registered validation directory; new recomputation required'),
        reusable_artifacts=dict(selection_record='audit identity only; not pooled future 1..12 selection',
                                historical_test_batch_statistics='not validation data; not used for selection',
                                previous_comparator_preflights='blocked instrumented path; not accepted for this new path'),
        runtime_policy='new environment recorded at preflight and exactly bound to each execution; no claim of historical local bitwise parity',
        limitation='Matched fixed and adaptive arms share the adaptive wrapper; its fixed arm must be bridged and may need a separate name.',
    )
    if any(Path(p).suffix.lower() in ('.pt', '.pth', '.npz') for p in bindings):
        raise ValueError('Protocol preparation unexpectedly bound tensor by reading it')
    write_new(args.output, protocol)
    transfer = [dict(path=p, sha256=s, role='authenticated_source_or_metadata',
                     preparation_read=True, preparation_deserialized=False)
                for p, s in sorted(bindings.items())]
    for split, row in datasets.items():
        transfer.append(dict(**row, role=split + '_dataset', preparation_read=False,
                             preparation_deserialized=False,
                             sha256_origin='frozen historical evidence; not rehashed in this preparation'))
    transfer.append(dict(path=str(args.output.resolve()), sha256=digest(args.output),
                         role='frozen_protocol', preparation_read=True, preparation_deserialized=False))
    write_new(HERE / 'deployment_inputs.json', dict(
        schema='adaptive_comparison_local_deployment_inputs_v1', protocol_sha256=digest(args.output),
        files=transfer, original_paths_retained=True,
        relocation='Use --path-map JSON prefix mappings; copied files must retain exact hashes.',
        tensor_policy='Preparation opens no .pt/.pth/.npz. Test may be hashed/transferred by the authorized deployment controller, never deserialized before validation selection.',
        additional_new_receipts_required=['code acceptance', 'per-configuration preflight acceptance']))
    print(json.dumps(dict(state=protocol['state'], configurations=len(protocol['cases']),
                          source_files=len(bindings), tensor_reads=0, tensor_hashes=0)))


if __name__ == '__main__':
    main()
