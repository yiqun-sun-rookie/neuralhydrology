"""CPU-only synthetic tests; never deserialize real hydrology datasets."""
import importlib.util
import math
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest

import numpy as np
import torch

import adaptive_driver as driver
import adaptive_runtime as runtime
from prepare_protocol import cases

ROOT = Path(__file__).resolve().parents[4]
torch.set_num_threads(1)


def load_source(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class SyntheticDataset:
    def __init__(self, hours=805):
        self.qobs = (torch.arange(hours, dtype=torch.float32) / 1000 + 0.1).reshape(-1, 1)
        self.tm_hours = torch.arange(hours, dtype=torch.float32).reshape(-1, 1)
        self.p = self.etpot = self.qobs.clone()
        self.states_all = self.qobs.repeat(1, 5)

    def __len__(self):
        return len(self.qobs) - 799

    def __getitem__(self, index):
        return {key: value[index:index + 800].T for key, value in
                dict(qobs=self.qobs, tm_hours=self.tm_hours, p=self.p,
                     etpot=self.etpot, state0=self.states_all).items()}


def unfold(value, positions):
    return value[:, 0, :].unfold(-1, positions, 1)


def toy_infer(rt, batch, positions):
    obs = batch['qobs']
    target = unfold(obs, positions).reshape(-1, 1, positions)
    return dict(updated=batch['state0'].clone(), outputs=obs.clone(),
                forecast_states=target.repeat(1, 5, 1), predictions=target * 1.01,
                observation=obs, hours=batch['tm_hours'])


class SelectionTests(unittest.TestCase):
    def rows(self, a=.8, b=.7):
        return [dict(delta_r=.01, split='validation', mean_future_1_12_nse=a),
                dict(delta_r=.02, split='validation', mean_future_1_12_nse=b)]

    def test_larger_score_selected_without_preference_for_old_rate(self):
        self.assertEqual(driver.choose_rate(self.rows(.7, .8))['delta_r'], .02)

    def test_equal_scores_use_smaller_declared_rate(self):
        self.assertEqual(driver.choose_rate(self.rows(.8, .8))['delta_r'], .01)

    def test_missing_candidate_cannot_select_survivor(self):
        with self.assertRaises(ValueError):
            driver.choose_rate(self.rows()[:1])

    def test_test_scores_cannot_select(self):
        rows = self.rows()
        rows[0]['split'] = 'test'
        with self.assertRaises(ValueError):
            driver.choose_rate(rows)

    def test_nonfinite_score_rejected(self):
        with self.assertRaises(ValueError):
            driver.choose_rate(self.rows(float('nan'), .8))

    def test_seven_cases_and_unselected_test_placeholder(self):
        rows = cases()
        self.assertEqual(len(rows), 7)
        self.assertEqual(sum(r['split'] == 'validation' for r in rows), 5)
        self.assertIsNone(next(r for r in rows if r['mode'] == 'selected')['delta_r'])

    def test_test_case_forbidden_without_frozen_selection(self):
        with self.assertRaisesRegex(ValueError, 'frozen validation'):
            driver.resolve_case({'cases': cases()}, 'matched_fixed_test')

    def test_environment_missing_field_rejected(self):
        e = {k: False for k in driver.ENV_FIELDS}
        other = dict(e)
        other.pop('numpy')
        with self.assertRaises(ValueError):
            driver.same_environment(e, other)

    def test_relocation_longest_prefix_and_dictionary_keys(self):
        before = driver.PATH_MAPPINGS
        driver.PATH_MAPPINGS = [('G:/repo/data/file.pt', '/readonly/file.pt'), ('G:/repo', '/new/repo')]
        try:
            result = driver.relocate({'G:\\repo\\data\\file.pt': 'G:/repo/code.py'})
            self.assertEqual(result, {'/readonly/file.pt': '/new/repo/code.py'})
            self.assertEqual(driver.relocate('G:/repo_other/file'), 'G:/repo_other/file')
        finally:
            driver.PATH_MAPPINGS = before


class StatisticsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.statistics = load_source(ROOT / 'artifacts/wrr_selected_model_results_20260920_v1/source/protocol/statistics_core.py', '_synthetic_stats')

    def setUp(self):
        self.data = SyntheticDataset()
        self.runtime = SimpleNamespace(core=SimpleNamespace(rearrange_data_unfold=unfold), case={'case_id': 'synthetic'})

    def test_validation_and_test_windows_match_explicit_reference(self):
        for positions, retain in [(13, 13), (48, 25)]:
            with self.subTest(positions=positions):
                stats = driver.score_dataset(self.runtime, self.data, toy_infer,
                                             self.statistics, 2, positions, retain)
                predictions = []
                targets = []
                for window in range(len(self.data)):
                    q = self.data.qobs[window:window + 800, 0].numpy()
                    for issue in range(801 - positions):
                        target = q[issue:issue + retain]
                        targets.append(target)
                        # Multiplication must occur at float32, as in toy inference.
                        predictions.append((target * np.float32(1.01)).astype(np.float32))
                pp, oo = np.asarray(predictions, dtype=np.float64), np.asarray(targets, dtype=np.float64)
                expected_nse = 1 - ((pp - oo) ** 2).sum(0) / ((oo - oo.mean(0)) ** 2).sum(0)
                np.testing.assert_allclose(self.statistics.metrics(stats.sum(0))['nse'], expected_nse, rtol=0, atol=1e-12)
                self.assertEqual(stats.shape, (len(self.data) + 800 - positions, retain, 8))

    def test_shifted_target_time_rejected(self):
        batch = torch.utils.data.default_collate([self.data[0]])
        result = toy_infer(self.runtime, batch, 13)
        result['hours'] = result['hours'] + 1
        with self.assertRaisesRegex(ValueError, 'target-hour'):
            driver.validate_result(result, self.data, self.runtime.core, [0], 13, 13)

    def test_nonfinite_prediction_rejected(self):
        batch = torch.utils.data.default_collate([self.data[0]])
        result = toy_infer(self.runtime, batch, 13)
        result['predictions'][0, 0, 0] = float('inf')
        with self.assertRaises(ValueError):
            driver.validate_result(result, self.data, self.runtime.core, [0], 13, 13)

    def test_dataset_count_gate(self):
        with self.assertRaises(ValueError):
            driver.validate_dataset(self.data, dict(full_window_count=10, source_hour_count=805))


class MatchedCoreTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.shared = load_source(ROOT / 'artifacts/wrr_selected_model_results_20260920_v1/source/kalmannet/src/shared/adaptive_covariance_ukf.py', '_synthetic_adaptive_core')
        cls.base = load_source(ROOT / 'artifacts/wrr_selected_model_results_20260920_v1/source/filters/filters/filter/batch/my_version/batch_unscentedkalmanfilter_gpu.py', '_synthetic_batch_filter')

    def build(self, enabled):
        points = SimpleNamespace(c=2., Wm=[0., .25, .25, .25, .25], Wc=[2., .25, .25, .25, .25])
        base = self.base.BatchUnscentedKalmanFilterGPU(2, 1, 1.,
                   hx=lambda x: x[..., 1:2], fx=lambda x, dt: x * .99,
                   points=points, batch_size=2, device='cpu')
        base.x = torch.tensor([[2., 3.], [3., 4.]])
        base.P = torch.diag_embed(.1 * base.x)
        config = self.shared.AdaptiveNoiseConfig(q_basis=torch.diag(torch.tensor([.14, .001])),
                    initial_r_variance=.01, initial_q_scale=1., delta_q=0.,
                    delta_r=.01 if enabled else 0., adapt_q=False, adapt_r=enabled,
                    q_min=1e-6, q_max=100., r_min=1e-8, r_max=1., covariance_epsilon=1e-5)
        return self.shared.InnovationCorrelationAdaptiveUKF(base, config)

    def test_fixed_wrapper_matches_direct_filter_on_synthetic_system(self):
        wrapped, direct = self.build(False), self.build(False)
        for t in range(5):
            observation = torch.tensor([[2.8 + .02 * t], [3.8 + .02 * t]])
            direct.flt.predict()
            direct.flt.update(observation)
            wrapped.step(observation)
            torch.testing.assert_close(wrapped.x, direct.x, rtol=0, atol=0)
            torch.testing.assert_close(wrapped.P, direct.P, rtol=0, atol=0)

    def test_adaptation_applies_after_first_update(self):
        fixed, adaptive = self.build(False), self.build(True)
        observation = torch.tensor([[2.8], [3.8]])
        first = adaptive.step(observation)
        fixed.step(observation)
        torch.testing.assert_close(adaptive.x, fixed.x, rtol=0, atol=0)
        torch.testing.assert_close(first.r_used, torch.full((2,), .01), rtol=0, atol=0)
        self.assertFalse(torch.equal(first.r_after, first.r_used))
        second = adaptive.step(observation)
        torch.testing.assert_close(second.r_used, first.r_after, rtol=0, atol=0)

    def test_matched_reset_uses_each_window_state_and_resets_history(self):
        adaptive = self.build(True)
        adaptive.step(torch.tensor([[2.8], [3.8]]))
        adapter = SimpleNamespace(device='cpu', base_filter=adaptive.flt, core=adaptive,
                                  _flush_validation_diagnostics=lambda: None)
        states = torch.tensor([[5., 8.], [6., 9.]])
        runtime.matched_reset(adapter, states)
        torch.testing.assert_close(adaptive.P, torch.diag_embed(.1 * states), rtol=0, atol=0)
        self.assertEqual(adaptive.time_index, 0)
        torch.testing.assert_close(adaptive.r_variance, torch.full((2,), .01), rtol=0, atol=0)


class SerializedGateTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='synthetic_', dir=Path(__file__).parent)
        self.root = Path(self.temporary.name)
        self.protocol = self.root / 'protocol.json'
        driver.write_json(self.protocol, {'cases': cases()})
        self.environment = {k: False for k in driver.ENV_FIELDS}
        self.results = []
        for identifier in sorted(driver.VALIDATION_IDS):
            rate = .01 if 'r001' in identifier else .02 if 'r002' in identifier else 0.
            self.results.append(self.make_result(identifier, 'validation', rate, .7 + rate))

    def tearDown(self):
        self.temporary.cleanup()

    def make_result(self, identifier, split, rate, score, selection=None):
        out = self.root / identifier
        out.mkdir()
        leads = 13 if split == 'validation' else 25
        np.savez_compressed(out / 'issue_statistics.npz', stats=np.ones((8, leads, 8)),
                            issue_hours=np.arange(8), observation=np.arange(40), actual_leads=np.arange(leads))
        metrics = dict(case_id=identifier, split=split, delta_r=rate,
                       mean_future_1_12_nse=score, metrics={'nse': [score] * leads})
        driver.write_json(out / 'metrics.json', metrics)
        completion = dict(**metrics, environment=self.environment,
                          state='ADAPTIVE_FULL_EVALUATION_COMPLETE_PENDING_SCIENTIFIC_REVIEW',
                          protocol_sha256=driver.sha(self.protocol), metrics_sha256=driver.sha(out / 'metrics.json'),
                          statistics_sha256=driver.sha(out / 'issue_statistics.npz'))
        if selection is not None:
            completion['selection_sha256'] = driver.sha(selection)
        driver.write_json(out / 'completion.json', completion)
        return out

    def freeze(self):
        out = self.root / 'selection'
        out.mkdir()
        driver.freeze_selection(self.results, self.protocol, out)
        return out / 'selection_frozen.json'

    def test_five_validation_results_freeze_and_resolve_selected_test(self):
        selected = self.freeze()
        case = driver.resolve_case({'cases': cases()}, 'matched_selected_test', selected, self.protocol)
        self.assertEqual(case['delta_r'], .02)
        self.assertFalse(driver.read_json(selected)['test_data_read'])

    def test_tampered_validation_metrics_rejected_after_freeze(self):
        selected = self.freeze()
        path = self.results[0] / 'metrics.json'
        with path.open('a', encoding='utf-8') as handle:
            handle.write(' ')
        with self.assertRaisesRegex(ValueError, 'Hash mismatch'):
            driver.resolve_case({'cases': cases()}, 'matched_selected_test', selected, self.protocol)

    def test_missing_validation_binding_rejected_after_freeze(self):
        selected = self.freeze()
        record = driver.read_json(selected)
        record['frozen_validation_results'].pop()
        invalid = self.root / 'invalid_selection.json'
        driver.write_json(invalid, record)
        with self.assertRaisesRegex(ValueError, 'five validation'):
            driver.resolve_case({'cases': cases()}, 'matched_selected_test', invalid, self.protocol)

    def test_saved_test_summary_requires_frozen_selection_and_matching_domain(self):
        selected = self.freeze()
        fixed = self.make_result('matched_fixed_test', 'test', 0., .8, selected)
        online = self.make_result('matched_selected_test', 'test', .02, .7, selected)
        out = self.root / 'summary'
        out.mkdir()
        summary = driver.summarize_test([fixed, online], self.protocol, selected, out)
        self.assertAlmostEqual(summary['mean_future_1_12_nse_difference'], -.1)
        self.assertEqual(summary['raw_test_reads'], 0)
        self.assertTrue((out / 'readout.md').is_file())


if __name__ == '__main__':
    unittest.main(verbosity=2)
