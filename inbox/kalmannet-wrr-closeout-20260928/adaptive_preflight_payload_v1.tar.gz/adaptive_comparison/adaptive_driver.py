"""Seven bounded evaluation configurations; validation selection precedes test.

No computation or data loading at import. Each command writes a new exclusive
directory, preserves failures, and requires independent code/preflight receipts.
"""
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import platform
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
ENV_FIELDS = ('python', 'executable', 'torch', 'numpy', 'cuda', 'cudnn', 'device', 'dtype', 'batch_size',
              'seed', 'cudnn_benchmark', 'matmul_precision', 'cudnn_enabled',
              'cudnn_deterministic', 'deterministic_algorithms', 'cuda_matmul_allow_tf32',
              'cudnn_allow_tf32', 'autocast_enabled', 'grad_enabled')
RESULT_KEYS = ('updated', 'outputs', 'forecast_states', 'predictions', 'observation', 'hours')
VALIDATION_IDS = {'historical_r001_validation', 'historical_r002_validation',
                  'matched_fixed_validation', 'matched_r001_validation', 'matched_r002_validation'}
PATH_MAPPINGS = []


def relocate(value):
    """Explicit host relocation, preserving authenticated original JSON bytes."""
    if isinstance(value, dict):
        return {relocate(k): relocate(v) for k, v in value.items()}
    if isinstance(value, list):
        return [relocate(v) for v in value]
    if isinstance(value, str):
        normalized = value.replace('\\', '/')
        for source, target in PATH_MAPPINGS:
            if normalized == source or normalized.startswith(source + '/'):
                return target + normalized[len(source):]
    return value


def read_json(path):
    return relocate(json.loads(Path(path).read_text(encoding='utf-8-sig')))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def verify(path, expected):
    got = sha(path)
    if got != expected:
        raise ValueError('Hash mismatch: ' + str(path))
    return got


def write_json(path, value):
    with Path(path).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.write('\n')


def safe_output(path):
    path = Path(path).resolve()
    if not path.is_relative_to(HERE) or path == HERE:
        raise ValueError('Output must be an exclusive child of adaptive_comparison')
    path.mkdir(parents=True, exist_ok=False)
    return path


def validate_protocol(p):
    if p['schema'] != 'hamid_matched_adaptive_protocol_v1':
        raise ValueError('Wrong protocol schema')
    if p['physics'] != 'original' or p['initial_states'] != 'original saved dataset states':
        raise ValueError('Physics/initial states changed after predeclaration')
    if p['delta_r_candidates'] != [.01, .02] or p['new_training_units'] != 0:
        raise ValueError('Expanded candidate/training scope')
    expected = {'historical_r001_validation', 'historical_r002_validation',
                'matched_fixed_validation', 'matched_r001_validation', 'matched_r002_validation',
                'matched_fixed_test', 'matched_selected_test'}
    if len(p['cases']) != 7 or {c['case_id'] for c in p['cases']} != expected:
        raise ValueError('Expected exactly seven unique configuration identities')
    return True


def require_code_review(path, protocol_path):
    review = read_json(path)
    if review.get('state') != 'ADAPTIVE_CODE_ACCEPTED_FOR_PREFLIGHT' or review.get('open_critical_important_findings') != 0:
        raise ValueError('Independent code review acceptance required')
    if review.get('protocol_sha256') != sha(protocol_path):
        raise ValueError('Code review does not bind this protocol')
    if not review.get('reviewer') or not review.get('review_path'):
        raise ValueError('Code review provenance missing')
    verify(review['review_path'], review['review_sha256'])
    return review


def bind_legacy(p):
    """Authenticate all source bytes before importing archived project modules."""
    for path, digest in p['source_bindings'].items():
        if Path(path).suffix.lower() in ('.pt', '.pth', '.npz'):
            raise ValueError('Source manifest must not include tensor reads')
        verify(path, digest)
    legacy = Path(p['legacy_paths']['ROOT'])
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(legacy))
    for name in ('neural_runtime', 'comparator_runtime', 'evaluate_neural'):
        if name in sys.modules and Path(sys.modules[name].__file__).resolve() != (legacy / (name + '.py')).resolve():
            raise RuntimeError('Unrelated previously loaded legacy runtime: ' + name)
    rt = importlib.import_module('neural_runtime')
    cr = importlib.import_module('comparator_runtime')
    for key, value in p['legacy_paths'].items():
        if hasattr(rt, key):
            setattr(rt, key, Path(value))
        if hasattr(cr, key):
            setattr(cr, key, Path(value))
    cr._ARCHIVE_MAP = {r['relative']: Path(r['actual']) for r in p['archive_equivalents']}
    if any(n == 'filters' or n.startswith('filters.') or n == 'src' or n.startswith('src.') for n in sys.modules):
        raise RuntimeError('Run in a fresh process: project imports must be sealed')
    records = {str(Path(r['path']).resolve()): r['sha256'] for r in p['sealed_source_records']}
    overrides = {}
    for row in p['archive_equivalents']:
        requested = (rt.MAIN / 'source' / row['relative']).resolve()
        actual = Path(row['actual']).resolve()
        overrides[str(requested)] = actual
        records[str(actual)] = row['sha256']
    cr._SEALED = cr.SealedFinder(records, overrides)
    sys.meta_path.insert(0, cr._SEALED)
    import adaptive_runtime as ar
    ar.bind(rt, cr)
    return rt, cr, ar


def setup_environment(output, batch_size):
    for name in ('TEMP', 'TMP', 'TORCH_HOME', 'TORCH_EXTENSIONS_DIR', 'MPLCONFIGDIR', 'XDG_CACHE_HOME', 'NUMBA_CACHE_DIR'):
        path = output / 'cache' / name
        path.mkdir(parents=True)
        os.environ[name] = str(path)
    sys.dont_write_bytecode = True
    for name in ('KF_DEBUG_CHECKS', 'FORECAST_START_LEAD', 'FORECAST_INCLUDE_CURRENT'):
        os.environ.pop(name, None)
    import numpy as np
    import torch
    if not torch.cuda.is_available() or torch.get_default_dtype() != torch.float32:
        raise RuntimeError('Actual hydrological evaluation requires CUDA float32')
    torch.manual_seed(42)
    torch.backends.cudnn.benchmark = False
    torch.set_grad_enabled(False)
    torch.cuda.reset_peak_memory_stats()
    def forbidden(*a, **kw):
        raise RuntimeError('Training/optimizer/backward forbidden')
    torch.Tensor.backward = forbidden
    torch.autograd.backward = forbidden
    torch.optim.Optimizer.__init__ = forbidden
    for cls in vars(torch.optim).values():
        if isinstance(cls, type) and issubclass(cls, torch.optim.Optimizer):
            cls.step = forbidden
    return dict(python=platform.python_version(), executable=sys.executable,
                torch=str(torch.__version__), numpy=np.__version__, cuda=torch.version.cuda,
                cudnn=torch.backends.cudnn.version(), device=torch.cuda.get_device_name(0),
                dtype='float32', batch_size=batch_size, seed=42,
                cudnn_benchmark=torch.backends.cudnn.benchmark,
                matmul_precision=torch.get_float32_matmul_precision(),
                cudnn_enabled=torch.backends.cudnn.enabled,
                cudnn_deterministic=torch.backends.cudnn.deterministic,
                deterministic_algorithms=torch.are_deterministic_algorithms_enabled(),
                cuda_matmul_allow_tf32=torch.backends.cuda.matmul.allow_tf32,
                cudnn_allow_tf32=torch.backends.cudnn.allow_tf32,
                autocast_enabled=torch.is_autocast_enabled(), grad_enabled=torch.is_grad_enabled())


def same_environment(actual, reference):
    missing = [k for k in ENV_FIELDS if k not in actual or k not in reference]
    diffs = [k for k in ENV_FIELDS if actual.get(k) != reference.get(k)]
    if missing or diffs:
        raise ValueError('Accepted numerical environment differs: ' + ','.join(missing + diffs))


def fingerprint(value):
    a = value.detach().cpu().contiguous().numpy()
    return dict(shape=list(a.shape), dtype=str(a.dtype), sha256=hashlib.sha256(a.tobytes()).hexdigest())


def fingerprints(result):
    return {k: fingerprint(result[k]) for k in RESULT_KEYS}


def validate_result(result, dataset, core, windows, forecast_positions, retain_positions):
    import numpy as np
    import torch
    windows = np.asarray(windows, dtype=np.int64)
    n, issue_per_window = len(windows), 801 - forecast_positions
    shapes = dict(updated=(n, 5, 800), outputs=(n, 1, 800),
                  forecast_states=(n * issue_per_window, 5, forecast_positions),
                  predictions=(n * issue_per_window, 1, forecast_positions),
                  observation=(n, 1, 800), hours=(n, 1, 800))
    for key, shape in shapes.items():
        if tuple(result[key].shape) != shape or not torch.isfinite(result[key]).all():
            raise ValueError('Trajectory shape/finiteness mismatch: ' + key)
        if key != 'hours' and result[key].dtype != torch.float32:
            raise ValueError('Non-float32 trajectory: ' + key)
    ids = (windows[:, None] + np.arange(issue_per_window)[None, :]).ravel()
    obs = dataset.qobs.detach().cpu().numpy().reshape(-1)
    hours = dataset.tm_hours.detach().cpu().numpy().reshape(-1).astype(np.float64)
    target = core.rearrange_data_unfold(result['observation'], forecast_positions).cpu().numpy().reshape(-1, forecast_positions)
    target_hours = core.rearrange_data_unfold(result['hours'], forecast_positions).cpu().numpy().reshape(-1, forecast_positions)
    indexes = ids[:, None] + np.arange(forecast_positions)[None, :]
    if not np.array_equal(target, obs[indexes]) or not np.array_equal(target_hours, hours[indexes]):
        raise ValueError('Observed target or target-hour mismatch')
    if not np.all(target_hours - hours[ids, None] == np.arange(forecast_positions)):
        raise ValueError('Issue plus lead does not equal target time')
    pred = result['predictions'].cpu().numpy().reshape(-1, forecast_positions)[:, :retain_positions]
    return pred, target[:, :retain_positions], ids


def validate_dataset(dataset, spec):
    import numpy as np
    if len(dataset) != spec['full_window_count'] or dataset.qobs.numel() != spec['source_hour_count']:
        raise ValueError('Data count differs from frozen split')
    hours = dataset.tm_hours.detach().cpu().numpy().reshape(-1).astype(np.float64)
    if not np.isfinite(hours).all() or not np.all(np.diff(hours) == 1):
        raise ValueError('Non-hourly source timeline')
    return {k: fingerprint(getattr(dataset, k)) for k in ('p', 'etpot', 'qobs', 'tm_hours', 'states_all')}


def preflight(case, p, rt, cr, ar, output):
    import numpy as np
    import torch
    from torch.utils.data import default_collate
    source = p['datasets']['validation']
    dataset = rt.load_dataset(source['path'], source['sha256'])
    val_spec = next(c for c in p['cases'] if c['case_id'] == 'matched_fixed_validation')
    input_fingerprints = validate_dataset(dataset, val_spec)
    size = p['preflight']['first_validation_windows']
    if not 1 <= size <= 256:
        raise ValueError('Preflight limited to first 256 validation windows')
    batch = default_collate([dataset[i] for i in range(size)])
    frozen = []
    bridge = None
    for repetition in range(2):
        runtime = ar.build_runtime(case, output)
        result = ar.infer(runtime, batch, case['forecast_positions'])
        pred, obs, _ = validate_result(result, dataset, runtime.core, np.arange(size),
                                       case['forecast_positions'], case['retain_positions'])
        frozen.append(fingerprints(result))
        if repetition == 0 and case['family'] == 'matched' and case['mode'] == 'fixed':
            old = ar.historical_hand_infer(runtime, batch, case['forecast_positions'])
            old_pred, old_obs, _ = validate_result(old, dataset, runtime.core, np.arange(size),
                                                  case['forecast_positions'], case['retain_positions'])
            if not np.array_equal(obs, old_obs):
                raise ValueError('Matched/historical bridge observations differ')
            def score(prediction):
                target = obs.astype(np.float64)
                return 1 - np.sum((prediction.astype(np.float64) - target) ** 2, axis=0) / np.sum((target - target.mean(axis=0)) ** 2, axis=0)
            bits = fingerprints(old) == frozen[-1]
            bridge = dict(bitwise_equal=bits,
                          maximum_prediction_absolute_difference_mmh=float(np.max(np.abs(pred.astype(np.float64) - old_pred))),
                          per_lead_nse_difference=(score(pred) - score(old_pred)).tolist(),
                          naming='matched fixed-noise implementation' if not bits else 'sample-bridged matched fixed-noise implementation',
                          full_period_historical_identity_established=False)
            del old
        effective = runtime.effective
        del result, runtime
        torch.cuda.empty_cache()
    if frozen[0] != frozen[1]:
        raise ValueError('Same-environment repeated plain inference is not bitwise stable')
    if input_fingerprints != validate_dataset(dataset, val_spec):
        raise ValueError('Validation input tensors changed')
    return dict(state='ADAPTIVE_PREFLIGHT_COMPLETE_PENDING_INDEPENDENT_ACCEPTANCE',
                case_id=case['case_id'], validation_window_indices=list(range(size)),
                repetitions=2, repeated_results_identical=True, fingerprints=frozen,
                input_fingerprints=input_fingerprints, source=source,
                bridge=bridge, effective_config=effective, test_data_reads=0,
                full_period_scores_produced=False)


def require_preflight(path, case, protocol_path, environment):
    accepted = read_json(path)
    if accepted.get('state') != 'ADAPTIVE_PREFLIGHT_ACCEPTED' or accepted.get('open_critical_important_findings') != 0:
        raise ValueError('Independent preflight acceptance required')
    if accepted.get('case_id') != case['case_id'] or accepted.get('protocol_sha256') != sha(protocol_path):
        raise ValueError('Acceptance case/protocol identity differs')
    if not accepted.get('reviewer') or not accepted.get('review_path'):
        raise ValueError('Independent preflight review provenance missing')
    verify(accepted['review_path'], accepted['review_sha256'])
    verify(accepted['completion_path'], accepted['completion_sha256'])
    completion = read_json(accepted['completion_path'])
    if (completion.get('state') != 'ADAPTIVE_PREFLIGHT_COMPLETE_PENDING_INDEPENDENT_ACCEPTANCE'
            or completion.get('case_id') != case['case_id']
            or completion.get('protocol_sha256') != sha(protocol_path)
            or not completion.get('repeated_results_identical')):
        raise ValueError('Accepted preflight is incomplete')
    same_environment(environment, completion['environment'])
    return accepted, completion


def score_dataset(runtime, dataset, infer_fn, statistics, batch_size,
                  forecast_positions=48, retain_positions=25):
    import numpy as np
    from torch.utils.data import DataLoader
    count = 801 - forecast_positions
    accumulator = statistics.IssueAccumulator(len(dataset) + count - 1, retain_positions)
    cursor = 0
    for batch in DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=0, drop_last=False):
        n = batch['qobs'].shape[0]
        result = infer_fn(runtime, batch, forecast_positions)
        pred, target, ids = validate_result(result, dataset, runtime.core,
                                            np.arange(cursor, cursor + n), forecast_positions, retain_positions)
        accumulator.update(pred, target, ids)
        cursor += n
        if cursor % (batch_size * 10) == 0:
            print(f'{runtime.case["case_id"]}: {cursor}/{len(dataset)} windows', flush=True)
        del result
    expected = np.convolve(np.ones(len(dataset), dtype=np.int64), np.ones(count, dtype=np.int64))
    if cursor != len(dataset) or not np.array_equal(accumulator.stats[:, :, 0], np.repeat(expected[:, None], retain_positions, axis=1)):
        raise ValueError('Issue-level counts do not match exact window multiplicity')
    return accumulator.stats


def run_full(case, p, rt, ar, output, preflight_completion):
    import numpy as np
    source = p['datasets'][case['split']]
    dataset = rt.load_dataset(source['path'], source['sha256'])
    before = validate_dataset(dataset, case)
    runtime = ar.build_runtime(case, output)
    if runtime.effective != preflight_completion['effective_config']:
        raise ValueError('Effective model differs from accepted preflight')
    statistics = rt.frozen_statistics()
    stats = score_dataset(runtime, dataset, ar.infer, statistics, case['batch_size'],
                          case['forecast_positions'], case['retain_positions'])
    if list(stats.shape) != [case['issue_count'], case['retain_positions'], 8]:
        raise ValueError('Full statistics shape differs')
    if not np.all(stats[:, :, 0].sum(axis=0) == case['pairs_per_lead']):
        raise ValueError('Total pair count differs')
    metrics = statistics.metrics(stats.sum(axis=0))
    if any(not np.isfinite(v).all() for v in metrics.values()):
        raise ValueError('Nonfinite full score')
    observation = dataset.qobs.cpu().numpy().reshape(-1)
    hours = dataset.tm_hours.cpu().numpy().reshape(-1).astype(np.float64)
    np.savez_compressed(output / 'issue_statistics.npz', stats=stats,
                        issue_hours=hours[:case['issue_count']], observation=observation,
                        actual_leads=np.arange(case['retain_positions']))
    if before != validate_dataset(dataset, case):
        raise ValueError('Input data changed during inference')
    score = float(metrics['nse'][1:13].mean())
    values = dict(case_id=case['case_id'], split=case['split'], delta_r=case['delta_r'],
                  metrics={k: v.tolist() for k, v in metrics.items()},
                  mean_future_1_12_nse=score, effective_config=runtime.effective,
                  observation_fingerprint=fingerprint(dataset.qobs),
                  time_fingerprint=fingerprint(dataset.tm_hours),
                  stats_shape=list(stats.shape), pairs_per_lead=case['pairs_per_lead'],
                  statistics_sha256=sha(output / 'issue_statistics.npz'))
    write_json(output / 'metrics.json', values)
    return dict(state='ADAPTIVE_FULL_EVALUATION_COMPLETE_PENDING_SCIENTIFIC_REVIEW', **values,
                dataset=source, input_fingerprints=before,
                metrics_sha256=sha(output / 'metrics.json'),
                new_training=False, test_access=case['split'] == 'test')


def read_complete(path, protocol_sha256):
    path = Path(path)
    record = read_json(path / 'completion.json')
    if record.get('state') != 'ADAPTIVE_FULL_EVALUATION_COMPLETE_PENDING_SCIENTIFIC_REVIEW':
        raise ValueError('Result is not a complete full evaluation: ' + str(path))
    if record.get('protocol_sha256') != protocol_sha256:
        raise ValueError('Result was produced under a different protocol')
    verify(path / 'metrics.json', record['metrics_sha256'])
    verify(path / 'issue_statistics.npz', record['statistics_sha256'])
    return record


def choose_rate(records):
    import math
    if {float(r['delta_r']) for r in records} != {.01, .02} or len(records) != 2:
        raise ValueError('Both frozen rate candidates are required; no survivor selection')
    for row in records:
        if row['split'] != 'validation' or not math.isfinite(row['mean_future_1_12_nse']):
            raise ValueError('Selection must use finite validation scores only')
    return min(records, key=lambda r: (-r['mean_future_1_12_nse'], r['delta_r']))


def freeze_selection(paths, protocol_path, output):
    import numpy as np
    digest = sha(protocol_path)
    records = [read_complete(path, digest) for path in paths]
    if len(records) != 5 or {r['case_id'] for r in records} != VALIDATION_IDS:
        raise ValueError('Five complete validation identities required')
    reference = None
    for path, row in zip(paths, records):
        if row['split'] != 'validation':
            raise ValueError('Test data cannot enter selection')
        same_environment(row['environment'], records[0]['environment'])
        with np.load(Path(path) / 'issue_statistics.npz', allow_pickle=False) as data:
            domains = {k: data[k].copy() for k in ('issue_hours', 'observation', 'actual_leads')}
            domains['observation_statistics'] = data['stats'][:, :, :3].copy()
        if reference is not None and any(not np.array_equal(domains[k], reference[k]) for k in domains):
            raise ValueError('Selection observation/time/count domains differ')
        reference = domains
    historical = choose_rate([r for r in records if r['case_id'].startswith('historical_')])
    matched = choose_rate([r for r in records if r['case_id'].startswith('matched_r')])
    bindings = [dict(path=str(Path(path).resolve()), case_id=row['case_id'],
                     completion_sha256=sha(Path(path) / 'completion.json'),
                     metrics_sha256=row['metrics_sha256'], statistics_sha256=row['statistics_sha256'])
                for path, row in zip(paths, records)]
    record = dict(state='ADAPTIVE_VALIDATION_SELECTION_FROZEN', protocol_sha256=digest,
                  selected_delta_r=matched['delta_r'], selection_metric='pooled future 1..12 mean NSE',
                  selected_case_id=matched['case_id'], selection_score=matched['mean_future_1_12_nse'],
                  historical_reselected_delta_r=historical['delta_r'],
                  historical_reselection_is_audit_only=True,
                  frozen_validation_results=bindings,
                  environment=matched['environment'], test_data_read=False,
                  tie_break='smaller delta_r', all_five_validation_configurations_complete=True)
    write_json(output / 'selection_frozen.json', record)
    write_json(output / 'historical_selection.json', dict(
        state='HISTORICAL_SELECTION_RULE_AUDITED', original_delta_r=.01,
        reranked_delta_r=historical['delta_r'], candidates=[r for r in records if r['case_id'].startswith('historical_')],
        new_winner_test_not_computed=True, old_test_scores_not_reassigned=True))
    return record


def resolve_case(p, identifier, selection_path=None, protocol_path=None):
    case = dict(next(c for c in p['cases'] if c['case_id'] == identifier))
    if case['split'] == 'test':
        if selection_path is None:
            raise ValueError('Test configuration requires frozen validation selection')
        selected = read_json(selection_path)
        if selected.get('state') != 'ADAPTIVE_VALIDATION_SELECTION_FROZEN' or selected.get('protocol_sha256') != sha(protocol_path):
            raise ValueError('Invalid frozen selection')
        rows = selected['frozen_validation_results']
        if len(rows) != 5 or {r['case_id'] for r in rows} != VALIDATION_IDS:
            raise ValueError('Frozen selection must bind exactly five validation identities')
        for row in selected['frozen_validation_results']:
            verify(Path(row['path']) / 'completion.json', row['completion_sha256'])
            verify(Path(row['path']) / 'metrics.json', row['metrics_sha256'])
            # Do not reopen any test tensor while preparing a validation preflight.
        if selected['selected_delta_r'] not in (.01, .02):
            raise ValueError('Selected rate outside frozen candidate set')
        candidates = [read_json(Path(row['path']) / 'metrics.json')
                      for row in selected['frozen_validation_results']
                      if row['case_id'].startswith('matched_r')]
        winner = choose_rate(candidates)
        if (winner['delta_r'] != selected['selected_delta_r']
                or winner['case_id'] != selected['selected_case_id']
                or winner['mean_future_1_12_nse'] != selected['selection_score']):
            raise ValueError('Frozen selected rate differs from bound validation metrics')
        if case['mode'] == 'selected':
            case['delta_r'] = selected['selected_delta_r']
    return case


def summarize_test(paths, protocol_path, selection_path, output):
    """Read authenticated saved arrays only; never opens raw test inputs."""
    import numpy as np
    protocol = read_json(protocol_path)
    resolve_case(protocol, 'matched_selected_test', selection_path, protocol_path)
    selected = read_json(selection_path)
    records = [read_complete(path, sha(protocol_path)) for path in paths]
    if len(records) != 2 or {r['case_id'] for r in records} != {'matched_fixed_test', 'matched_selected_test'}:
        raise ValueError('Exactly the fixed and selected matched test results are required')
    sources = {r['case_id']: (Path(path), r) for path, r in zip(paths, records)}
    reference, metrics = None, {}
    for identifier, (path, record) in sources.items():
        if record['split'] != 'test':
            raise ValueError('Expected test evaluation, not validation')
        if record.get('selection_sha256') != sha(selection_path):
            raise ValueError('Test result does not bind this frozen selection')
        same_environment(record['environment'], selected['environment'])
        with np.load(path / 'issue_statistics.npz', allow_pickle=False) as data:
            domains = {k: data[k].copy() for k in ('issue_hours', 'observation', 'actual_leads')}
            domains['observation_statistics'] = data['stats'][:, :, :3].copy()
        if reference is not None and any(not np.array_equal(domains[k], reference[k]) for k in domains):
            raise ValueError('Paired test domains differ')
        reference = domains
        metrics[identifier] = record['metrics']
    if sources['matched_fixed_test'][1]['delta_r'] != 0. or sources['matched_selected_test'][1]['delta_r'] != selected['selected_delta_r']:
        raise ValueError('Test rate differs from fixed/selected protocol')
    fixed, online = metrics['matched_fixed_test'], metrics['matched_selected_test']
    delta = {name: (np.asarray(online[name]) - np.asarray(fixed[name])).tolist() for name in fixed}
    summary = dict(state='MATCHED_ADAPTIVE_TEST_SUMMARIZED_PENDING_SCIENTIFIC_REVIEW',
                   protocol_sha256=sha(protocol_path), selection_path=str(Path(selection_path).resolve()),
                   selection_sha256=sha(selection_path), selected_delta_r=selected['selected_delta_r'],
                   physics='original', actual_leads=list(range(25)), metrics=metrics,
                   selected_minus_fixed=delta,
                   mean_future_1_12_nse_difference=float(np.mean(delta['nse'][1:13])),
                   mean_future_13_24_nse_difference=float(np.mean(delta['nse'][13:25])),
                   result_bindings=[dict(case_id=r['case_id'], path=str(Path(path).resolve()),
                                         completion_sha256=sha(Path(path) / 'completion.json'),
                                         statistics_sha256=r['statistics_sha256']) for path, r in zip(paths, records)],
                   learned_noise_comparison='Requires same-domain admitted learned-noise result from numerical_impact; not automatically established by this pair.',
                   claim_scope='Only the registered observation-noise adaptation versus its matched fixed-noise implementation; not all adaptive covariance methods.',
                   no_training=True, raw_test_reads=0)
    write_json(output / 'results.json', summary)
    text = ("# Matched observation-noise adaptation: saved-result readout\n\n"
            f"Selected validation rate: {selected['selected_delta_r']}. Physics: original implementation.\n\n"
            f"Selected minus fixed mean Nash efficiency, future 1-12 h: {summary['mean_future_1_12_nse_difference']:.10f}; "
            f"future 13-24 h: {summary['mean_future_13_24_nse_difference']:.10f}.\n\n"
            "This reports two actual matched test evaluations after validation selection. "
            "A positive difference favours adaptation for that interval; a negative difference favours fixed noise. "
            "Independent scientific review, uncertainty, and the admitted learned-noise comparison remain separate steps. "
            "The historical hand-tuned method is not silently renamed or replaced; historical re-ranking is an audit only. "
            "No general superiority over all adaptive covariance approaches follows from this comparison.\n")
    with (output / 'readout.md').open('x', encoding='utf-8') as handle:
        handle.write(text)
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['preflight', 'run', 'freeze-selection', 'summarize-test'])
    parser.add_argument('--protocol', type=Path, default=HERE / 'matched_protocol.json')
    parser.add_argument('--case-id')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--code-acceptance', type=Path)
    parser.add_argument('--preflight-acceptance', type=Path)
    parser.add_argument('--selection', type=Path)
    parser.add_argument('--validation-results', type=Path, nargs='*')
    parser.add_argument('--test-results', type=Path, nargs='*')
    parser.add_argument('--path-map', type=Path, help='JSON list of explicit {source,target} absolute path-prefix relocations')
    args = parser.parse_args(argv)
    if args.path_map:
        global PATH_MAPPINGS
        mappings = json.loads(args.path_map.read_text(encoding='utf-8-sig'))
        PATH_MAPPINGS = sorted([(r['source'].replace('\\', '/').rstrip('/'),
                                r['target'].replace('\\', '/').rstrip('/')) for r in mappings],
                               key=lambda pair: -len(pair[0]))
        if any(not source or not target for source, target in PATH_MAPPINGS):
            raise ValueError('Empty relocation prefix forbidden')
    protocol = read_json(args.protocol)
    validate_protocol(protocol)
    output = safe_output(args.output)
    started = time.perf_counter()
    write_json(output / 'running.json', dict(command=args.command, case_id=args.case_id,
               protocol_sha256=sha(args.protocol), argv=sys.argv, path_mappings=PATH_MAPPINGS))
    rt = None
    try:
        if args.command == 'freeze-selection':
            record = freeze_selection(args.validation_results or [], args.protocol, output)
        elif args.command == 'summarize-test':
            if args.selection is None:
                raise ValueError('--selection is required')
            record = summarize_test(args.test_results or [], args.protocol, args.selection, output)
        else:
            if args.code_acceptance is None:
                raise ValueError('--code-acceptance is required')
            require_code_review(args.code_acceptance, args.protocol)
            case = resolve_case(protocol, args.case_id, args.selection, args.protocol)
            rt, cr, ar = bind_legacy(protocol)
            # The guard blocks test reads and hashes in every preflight.
            split = 'validation' if args.command == 'preflight' else case['split']
            rt.install_guard(output, [protocol['datasets'][split]['path']])
            environment = setup_environment(output, case['batch_size'])
            write_json(output / 'environment.json', environment)
            if args.command == 'preflight':
                record = preflight(case, protocol, rt, cr, ar, output)
            else:
                if args.preflight_acceptance is None:
                    raise ValueError('--preflight-acceptance is required before full evaluation')
                _, pre = require_preflight(args.preflight_acceptance, case, args.protocol, environment)
                if case['split'] == 'test':
                    same_environment(environment, read_json(args.selection)['environment'])
                record = run_full(case, protocol, rt, ar, output, pre)
            record.update(environment=environment, code_acceptance_sha256=sha(args.code_acceptance))
            if args.selection is not None:
                record.update(selection_path=str(args.selection.resolve()), selection_sha256=sha(args.selection))
            if args.preflight_acceptance is not None:
                record.update(preflight_acceptance_path=str(args.preflight_acceptance.resolve()),
                              preflight_acceptance_sha256=sha(args.preflight_acceptance))
            for path, digest in protocol['source_bindings'].items():
                verify(path, digest)
        record.update(protocol_sha256=sha(args.protocol), seconds=time.perf_counter() - started)
        write_json(output / 'completion.json', record)
        print(record['state'], flush=True)
    except BaseException as exc:
        write_json(output / 'failure.json', dict(state='FAILED', command=args.command,
                   case_id=args.case_id, error=repr(exc), traceback=traceback.format_exc(),
                   seconds=time.perf_counter() - started, retries=0))
        raise
    finally:
        if rt is not None:
            write_json(output / 'import_ledger.json', rt.IMPORT_LEDGER)
            write_json(output / 'load_ledger.json', rt.LOAD_LEDGER)
        torch = sys.modules.get('torch')
        ready = torch is not None and torch.cuda.is_initialized()
        write_json(output / 'resources.json', dict(seconds=time.perf_counter() - started,
                   peak_cuda_allocated=torch.cuda.max_memory_allocated() if ready else 0,
                   peak_cuda_reserved=torch.cuda.max_memory_reserved() if ready else 0))
        write_json(output / 'output_hashes.json', {
            str(f.relative_to(output)): sha(f) for f in output.rglob('*')
            if f.is_file() and 'cache' not in f.parts and f.name != 'output_hashes.json'})


if __name__ == '__main__':
    main()
