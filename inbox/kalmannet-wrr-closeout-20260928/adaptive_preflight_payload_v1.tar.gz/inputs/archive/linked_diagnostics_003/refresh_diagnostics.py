"""Refresh existing linked manuscript diagnostics, not selection or training."""
from __future__ import annotations

import importlib
import json
import os
from pathlib import Path
import shutil
import sys
import traceback

import evaluate as base

HERE, ORIGINAL = base.HERE, base.ORIGINAL
RUN = HERE / 'linked_diagnostics_003'


def main():
    if RUN.exists():
        raise RuntimeError('Output exists; no overwrite or automatic retry')
    RUN.mkdir()
    state = {'status': 'PREPARING', 'loads': [], 'training_attempts': [], 'started_at': base.now(),
             'scope': 'Update existing state/event figures and the already-selected adaptive comparator after model/lead correction; no selection or training.'}
    base.write_json(RUN / 'status.json', state)
    try:
        allowed = {p.resolve() for p in (base.TEST, base.NEURAL, base.NOISE)}
        before = {str(p): base.sha(p) for p in allowed}
        frozen_before = json.loads((HERE / 'run_001/protected_before.json').read_text())
        if any(frozen_before[p] != h for p, h in before.items()):
            raise RuntimeError('Inputs changed after primary comparison')
        base.audit.RUN = RUN
        for key in ('TEMP', 'TMP', 'MPLCONFIGDIR', 'NUMBA_CACHE_DIR', 'XDG_CACHE_HOME', 'TORCH_HOME'):
            dest = RUN / 'cache' / key
            dest.mkdir(parents=True)
            os.environ[key] = str(dest)
        sys.dont_write_bytecode = True
        base.audit.install_file_guard(allowed)
        project = RUN / 'source/kalmannet'
        filters = RUN / 'source/filters'
        shutil.copytree(HERE / 'run_001/source', RUN / 'source')
        extra_paths = ['draft/scripts/analyze_state_updates.py',
                       'experiments/optimize_hyper_parameters/select_adaptive_covariance_ukf.py',
                       'experiments/optimize_hyper_parameters/adaptive_covariance_ukf_config.yaml',
                       'src/shared/adaptive_covariance_ukf.py', 'src/shared/__init__.py',
                       'src/shared/metrics.py']
        sources = []
        for item in json.loads((HERE / 'run_001/source_manifest.json').read_text()):
            copy = RUN / Path(item['snapshot']).relative_to(HERE / 'run_001')
            item = dict(item, snapshot=str(copy))
            sources.append(item)
        for rel in extra_paths:
            source, target = ORIGINAL / rel, project / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            sources.append({'original': str(source), 'snapshot': str(target), 'sha256': base.sha(source)})
        shutil.copyfile(HERE / 'run_001/configs/learned_noise_original.yaml', RUN / 'noise_config.yaml')
        shutil.copyfile(HERE / 'run_001/dpr_config.yaml', RUN / 'dpr_config.yaml')
        shutil.copyfile(Path(__file__), RUN / 'refresh_diagnostics.py')
        base.write_json(RUN / 'source_manifest.json', sources)
        sys.path[:] = [str(project), str(filters), str(base.FILTERS), str(HERE)] + [p for p in sys.path if p and Path(p).resolve() not in {ORIGINAL, base.WORKTREE}]
        os.chdir(RUN)
        finder = base.audit.SnapshotOnlyFinder((project, filters), {r['snapshot']: r for r in sources})
        sys.meta_path.insert(0, finder)
        import numpy as np
        import torch
        import yaml
        from statistics_core import IssueAccumulator, metrics
        torch.set_grad_enabled(False)
        torch.manual_seed(42)
        torch.backends.cudnn.benchmark = False
        original_load, cached = torch.load, {}

        def load(path, *a, **kw):
            p = base.audit.checked_input(path, allowed)
            if p not in cached:
                cached[p] = original_load(p, *a, **kw)
                state['loads'].append(str(p))
            return cached[p]

        torch.load = load

        def forbid(*a, **kw):
            state['training_attempts'].append('training/backward/update')
            raise RuntimeError('Training forbidden')

        torch.optim.AdamW.step = forbid
        torch.Tensor.backward = forbid
        torch.autograd.backward = forbid
        paper = importlib.import_module('draft.scripts.generate_paper_metrics')
        # Import preflight before any inference. Earlier failed snapshots remain intact.
        sys.modules['src'].__path__ = [str(project / 'src')]
        importlib.import_module('src.shared.adaptive_covariance_ukf')
        paper.KNET_PATH, paper.UKF_PATH = base.NEURAL, base.NOISE
        paper.UKF_CONFIG_PATH = RUN / 'noise_config.yaml'
        paper.TEST_DATA_PATHS = [str(base.TEST)]
        paper.Pipeline.train = forbid
        ds = torch.load(base.TEST, map_location='cpu', weights_only=False)
        device = torch.device('cuda')
        models = []
        for builder_name in ('build_knet', 'build_trainable_kf'):
            original_builder = getattr(paper, builder_name)
            def wrap_builder(builder):
                def build(*a, **kw):
                    model = builder(*a, **kw)
                    original_state_load = model.load_state_dict
                    def state_load(sd, *args, **kwargs):
                        result = original_state_load(sd, *args, **kwargs)
                        for p in model.parameters():
                            p.requires_grad_(False)
                        models.append((model, {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}))
                        return result
                    model.load_state_dict = state_load
                    return model
                return build
            setattr(paper, builder_name, wrap_builder(original_builder))
        diagnostic = importlib.import_module('draft.scripts.analyze_state_updates')
        specs = diagnostic.build_nonoverlapping_slices(len(ds), ds.window_size)
        old_summary_path = ORIGINAL / 'draft/artifacts/state_update_diagnostics_20260723/state_update_summary.json'
        old_summary = json.loads(old_summary_path.read_text())
        updates = {}
        observation = None
        for name, function in [('neural_gain', diagnostic._run_neural_gain), ('learned_noise', diagnostic._run_learned_noise), ('hand_tuned', diagnostic._run_hand_tuned)]:
            print(f'STATE DIAGNOSTIC {name}', flush=True)
            values = function(ds, specs, device)
            updates[name] = values[0]
            if observation is None:
                observation = values[1]
            elif not np.array_equal(observation, values[1]):
                raise RuntimeError('State-diagnostic observation ordering differs')
        summary = diagnostic.summarize_updates(updates, observation, np.asarray(old_summary['state_scales_training_iqr']),
                old_summary['flow_thresholds_test_discharge']['q25'], old_summary['flow_thresholds_test_discharge']['q75'], diagnostic.STATE_NAMES)
        base.write_json(RUN / 'state_summary.json', summary)
        base.write_json(RUN / 'normalization_provenance.json', {'source': str(old_summary_path), 'sha256': base.sha(old_summary_path),
                        'training_data_loaded': False, 'unchanged_training_scales_reused': True, 'n_test_hours': len(observation), 'segments': specs})
        np.savez_compressed(RUN / 'state_updates.npz', **updates, observation=observation)
        # Event selection and plotted valid-time windows remain exactly fixed.
        old_events_path = ORIGINAL / 'draft/artifacts/hydrograph_appendix_h12_h24_data.json'
        old_payload = json.loads(old_events_path.read_text())
        events = old_payload['events']
        subset = torch.utils.data.Subset(ds, [e['global_test_index'] for e in events])
        real_loader = paper.DataLoader
        event_loader = real_loader(subset, batch_size=6, shuffle=False, num_workers=0)
        paper.DataLoader = lambda *a, **kw: event_loader
        paper.load_test_data = lambda *a, **kw: (event_loader, subset)
        output_events = [{'peak_hour': e['peak_hour'], 'peak_position': e['peak_position'],
                         'global_test_index': e['global_test_index'], 'horizons': {}} for e in events]
        current = {'name': ''}
        class EventStats:
            def __init__(self, *a, **kw):
                self.n_batches = 0
            def update(self, fc, obs):
                arrays = np.asarray(fc).reshape(6, 753, 48)
                for i, e in enumerate(events):
                    sample = ds[e['global_test_index']]
                    times = sample['tm_hours'].squeeze().numpy()
                    q = sample['qobs'].squeeze().numpy()
                    for lead in (6, 12, 18, 24):
                        valid_times = np.asarray(e['horizons'][str(lead)]['times_hours'])
                        pos = np.searchsorted(times, valid_times)
                        if not np.array_equal(times[pos], valid_times) or np.any(pos - lead < 0) or np.any(pos - lead >= 753):
                            raise RuntimeError('Original event window incompatible with true lead')
                        fc_values = arrays[i, pos - lead, lead] * paper.MMH_TO_M3S
                        if not np.isfinite(fc_values).all():
                            raise RuntimeError('Nonfinite event forecast')
                        block = output_events[i]['horizons'].setdefault(str(lead), {'times_hours': valid_times.tolist(), 'obs_m3s': (q[pos] * paper.MMH_TO_M3S).tolist(), 'methods': {}})
                        block['methods'][current['name']] = fc_values.tolist()
                self.n_batches += 1
        paper.RunningRegimeStats = EventStats
        cfg = yaml.safe_load(paper.LOCAL_CONFIG_PATH.read_text(encoding='utf-8'))
        for name, fn in [('neural_gain', lambda: paper.eval_knet(cfg, device, 48, 6, 0, 1)),
                         ('learned_noise', lambda: paper.eval_ukf(cfg, device, 48, 6, 0, 1)),
                         ('hand_tuned', lambda: paper.eval_handtuned(device, 48, 6, 0, 1)),
                         ('open_loop', lambda: paper.eval_openloop(device, 48, 6, 0, 1))]:
            current['name'] = name
            print(f'EVENT DIAGNOSTIC {name}', flush=True)
            fn()
        base.write_json(RUN / 'events.json', {'selection_source': str(old_events_path), 'source_sha256': base.sha(old_events_path), 'events': output_events})
        # Recover parameters of the already selected learned-noise checkpoint.
        sd = cached[base.NOISE.resolve()]
        sd = sd.get('model_state_dict', sd)
        covariance = {k: torch.exp(v).cpu().tolist() for k, v in sd.items() if k.endswith('Q_layer.raw') or k.endswith('R_layer.raw')}
        base.write_json(RUN / 'selected_noise_covariance.json', covariance)
        paper.DataLoader = real_loader
        # Refresh the existing adaptive comparator with unchanged rate/settings,
        # adding the missing actual-hour-24 regime row. No new candidate tested.
        sys.modules['src'].__path__ = [str(project / 'src')]
        adaptive = importlib.import_module('experiments.optimize_hyper_parameters.select_adaptive_covariance_ukf')
        acfg = yaml.safe_load((project / 'experiments/optimize_hyper_parameters/adaptive_covariance_ukf_config.yaml').read_text(encoding='utf-8'))
        if base.sha(ORIGINAL / 'experiments/optimize_hyper_parameters/adaptive_covariance_ukf_config.yaml') != '998fa6082b5edba3d88321152af11f8dc6289f4ab56ccca82ac37a2ef204c969':
            raise RuntimeError('Previously selected adaptive configuration changed')
        selection_path = ORIGINAL / 'artifacts/regge_adaptive_covariance_ukf_v1_validation/selection.json'
        if base.sha(selection_path) != 'f4dbca35ee4adc2487a506d6b95d93e18646e50f0a7a4d2881a652b5ae9da0a8':
            raise RuntimeError('Adaptive selection manifest changed')
        acfg['training']['forecast_lead_time'] = 48
        sample_p = ds[0]['p'].squeeze()
        aargs = paper.build_args(acfg, sample_p, sample_p)
        aargs.device = 'cuda'
        system = paper._init_mod.initialize_system_model(aargs.train_seq_len, aargs.seq_len_val, device=device)
        model = adaptive.build_regge_adaptive_model(acfg, system, aargs, 100.0).to(device)
        loader = real_loader(ds, batch_size=128, shuffle=False, num_workers=0)
        collector = IssueAccumulator(len(ds.tm_hours) - 47, 25)
        obs_series = ds.qobs.squeeze().numpy()
        class AdaptiveSink(paper.StreamingRegime):
            def __init__(self):
                list.__init__(self)
                self.cursor = 0
            def append(self, batch):
                fc = batch['outputs_fc_win'].cpu().numpy()
                obs = batch['y_obs_win'].cpu().numpy()
                b = len(fc)
                ids = (np.arange(self.cursor, self.cursor + b)[:, None] + np.arange(753)[None, :]).ravel()
                y = obs.reshape(-1, 48)[:, :25]
                if not np.array_equal(y, obs_series[ids[:, None] + np.arange(25)[None, :]]):
                    raise RuntimeError('Adaptive issue/valid-time mismatch')
                collector.update(fc.reshape(-1, 48)[:, :25], y, ids)
                self.cursor += b
                if self.cursor % 1280 == 0:
                    print(f'ADAPTIVE {self.cursor}/{len(ds)}', flush=True)
        pipeline = paper.StreamingPipeline(str(RUN / 'adaptive_pipeline'))
        pipeline.set_sys_model(system)
        pipeline.set_knet_model(model)
        pipeline.set_train_params(aargs)
        pipeline.save_predictions = True
        pipeline.display_metrics_list = ['nse', 'mse']
        paper.initialize_training(pipeline, loader, loader)
        sink = AdaptiveSink()
        pipeline.set_streaming(sink)
        paper.run_one_epoch(pipeline, loader, 0, is_training=False)
        if sink.cursor != len(ds):
            raise RuntimeError('Incomplete adaptive evaluation')
        np.savez_compressed(RUN / 'adaptive_issue_statistics.npz', stats=collector.stats,
                            issue_hours=ds.tm_hours.squeeze().numpy()[:len(collector.stats)], observation=obs_series)
        base.write_json(RUN / 'adaptive_metrics.json', {k: v.tolist() for k, v in metrics(collector.stats.sum(axis=0)).items()})
        # The manuscript's existing unassimilated baseline also needs actual hour 24.
        open_collector = IssueAccumulator(len(ds.tm_hours) - 47, 25)
        class OpenStats:
            def __init__(self, *a, **kw):
                self.n_batches = 0
                self.cursor = 0
            def update(self, fc, obs):
                fc, obs = np.asarray(fc), np.asarray(obs)
                b = len(fc) // 753
                ids = (np.arange(self.cursor, self.cursor + b)[:, None] + np.arange(753)[None, :]).ravel()
                y = obs.reshape(-1, 48)[:, :25]
                if not np.array_equal(y, obs_series[ids[:, None] + np.arange(25)[None, :]]):
                    raise RuntimeError('Open-loop issue/valid-time mismatch')
                open_collector.update(fc.reshape(-1, 48)[:, :25], y, ids)
                self.cursor += b
                self.n_batches += 1
        paper.RunningRegimeStats = OpenStats
        paper.load_test_data = lambda *a, **kw: (loader, ds)
        print('EXISTING OPEN-LOOP BASELINE', flush=True)
        open_result = paper.eval_openloop(device, 48, 128, 0, 1)
        np.savez_compressed(RUN / 'open_loop_issue_statistics.npz', stats=open_collector.stats,
                            issue_hours=ds.tm_hours.squeeze().numpy()[:len(open_collector.stats)], observation=obs_series)
        base.write_json(RUN / 'open_loop_metrics.json', {k: v.tolist() for k, v in metrics(open_collector.stats.sum(axis=0)).items()})
        unchanged = all(all(torch.equal(m.state_dict()[k].detach().cpu(), v) for k, v in old.items()) for m, old in models)
        checks = {'learned_parameters_unchanged': unchanged, 'inputs_unchanged': before == {str(p): base.sha(p) for p in allowed},
                  'source_unchanged': all(base.sha(r['snapshot']) == r['sha256'] and base.sha(r['original']) == r['sha256'] for r in sources),
                  'only_three_registered_loads': len(state['loads']) == 3, 'no_training_attempts': not state['training_attempts']}
        base.write_json(RUN / 'acceptance.json', checks)
        base.write_json(RUN / 'import_ledger.json', finder.imports)
        if not all(checks.values()):
            raise RuntimeError(f'Linked diagnostic acceptance failed: {checks}')
        state.update({'status': 'COMPLETE', 'finished_at': base.now(), 'acceptance': checks})
        base.write_json(RUN / 'status.json', state)
        print('COMPLETE linked diagnostics', flush=True)
    except BaseException as exc:
        state.update({'status': 'FAILED', 'failed_at': base.now(), 'error': str(exc), 'traceback': traceback.format_exc()})
        base.write_json(RUN / 'status.json', state)
        raise


if __name__ == '__main__':
    main()
