import torch
import torch.nn as nn
import os
from .adaptive_cov import (LearnableCov)
from filters.filter.batch.my_version.batch_unscentedkalmanfilter_gpu import batch_sigma_points
from filters.da_coupler.walrus_batch import fx_walrus_batch, hx_walrus_batch

def _as_diag_tensor(raw, size, device):
    """
    raw: 标量 / list / tuple ；元素可以是 str 或数字
    返回 [size, size] 对角张量
    """
    # 1) 转 float list 或 float
    if isinstance(raw, str):
        raw = float(raw)
    elif isinstance(raw, (list, tuple)):
        raw = [float(x) for x in raw]

    v = torch.as_tensor(raw, dtype=torch.float32, device=device)
    if v.dim() == 0:
        v = v.repeat(size)

    return torch.diag(v)

# ---------- 1) 自适应 AEKF ---------- #
class AdaptiveBatchUKF(nn.Module):
    def __init__(
        self, base_filter,
        alpha_init: float = 0.1,
        adapt_q: bool = True, adapt_r: bool = True,
        tune_alpha: bool = False, eps: float = 0.0,
        adapt_method: str = "berry_mehra",
        diag_only: bool = False
    ):
        super().__init__()
        self.flt = base_filter
        self.eps = eps
        self.adapt_q = adapt_q
        self.adapt_r = adapt_r
        self.adapt_method = adapt_method.lower()
        self.diag_only = diag_only

        if tune_alpha:
            self.raw_alpha = nn.Parameter(torch.logit(torch.tensor(alpha_init)))
        else:
            # α 作为 buffer 注册，便于保存 / 加载
            self.register_buffer("alpha_const", torch.tensor(alpha_init))

    # ------- 显式暴露常用接口 (x / P / Q / R) -------
    @property
    def x(self):
        return self.flt.x
    @x.setter
    def x(self, value):
        self.flt.x = value

    @property
    def P(self):
        return self.flt.P
    @P.setter
    def P(self, value):
        self.flt.P = value

    @property
    def Q(self):
        return self.flt.Q
    @Q.setter
    def Q(self, value):
        self.flt.Q = value

    @property
    def R(self):
        return self.flt.R
    @R.setter
    def R(self, value):
        self.flt.R = value

    @property
    def dim_x(self):
        return self.flt.dim_x

    @property
    def dim_z(self):
        return self.flt.dim_z
    # ----------------------------------------------

    @property
    def alpha(self):
        """对外统一读取 α；若 tunable 则使用 sigmoid(raw_alpha)。"""
        return torch.sigmoid(self.raw_alpha) if hasattr(self, "raw_alpha") else self.alpha_const

    # --------- predict / update 保持原有逻辑 ---------
    def predict(self, *args, **kwargs):
        # 允许动态覆写 fx
        if hasattr(self, "fx") and callable(self.fx):
            self.flt.fx = self.fx
        self.flt.predict(*args, **kwargs)
        self._x_pred = self.flt.x.clone()
        self._P_pred = self.flt.P.clone()

    def update(self, z):
        # 允许动态覆写 hx
        if hasattr(self, "hx") and callable(self.hx):
            self.flt.hx = self.hx

        # ---------- 以下与原实现一致 ----------
        sigmas = batch_sigma_points(self._x_pred, self._P_pred, self.flt.c)
        sig_h = self.flt.hx(sigmas)
        z_pred = torch.einsum("bni,n->bi", sig_h, self.flt.Wm)
        d = z - z_pred
        z_diff = sig_h - z_pred.unsqueeze(1)
        S = torch.einsum("n,bni,bnj->bij", self.flt.Wc, z_diff, z_diff) + self.flt.R

        # cross‑covariance & Kalman gain
        sig_x = batch_sigma_points(self._x_pred, self._P_pred, self.flt.c)
        x_diff = sig_x - self._x_pred.unsqueeze(1)
        Pxz = torch.einsum("n,bni,bnj->bij", self.flt.Wc, x_diff, z_diff)
        # 数值稳定：对 S 添加最小抖动并做安全逆
        I_z = torch.eye(self.flt.dim_z, device=z.device).unsqueeze(0)
        jitter_base = max(float(self.eps), 1e-8)

        def _safe_inv(mat, ident):
            eps = jitter_base
            for _ in range(5):
                try:
                    return torch.linalg.inv(mat + eps * ident)
                except RuntimeError:
                    eps *= 10.0
            # 最后兜底：��用 pinv 以防彻底失败
            return torch.linalg.pinv(mat + eps * ident)

        S_inv = _safe_inv(S, I_z)
        K = torch.einsum("bij,bjk->bik", Pxz, S_inv)

        # 调用原 UKF 的更新（保持数值一致）
        self.flt.update(z)

        # 计算��差 eps
        sig_post = batch_sigma_points(self.flt.x, self.flt.P, self.flt.c)
        z_post = torch.einsum("bni,n->bi", self.flt.hx(sig_post), self.flt.Wm)
        eps = z - z_post

        I_x = torch.eye(self.flt.dim_x, device=z.device).unsqueeze(0)
        I_z = torch.eye(self.flt.dim_z, device=z.device).unsqueeze(0)

        alpha_val = self.alpha  # 使用统一接口

        if self.adapt_method != "berry_mehra":
            raise ValueError(f"Unsupported adapt_method: {self.adapt_method}. Use 'berry_mehra'.")

        # ---------- 自适应 Q (Berry-Mehra covariance matching) ----------
        if self.adapt_q:
            ddT = torch.einsum("bi,bj->bij", d, d)
            Q_new = alpha_val * self.flt.Q + (1 - alpha_val) * torch.einsum(
                "bij,bjk->bik", K,
                torch.einsum("bij,bjk->bik", ddT, K.transpose(1, 2))
            )
            Q_new = 0.5 * (Q_new + Q_new.transpose(1, 2)) + self.eps * I_x
            if self.diag_only:
                Q_new = torch.diag_embed(torch.diagonal(Q_new, dim1=-2, dim2=-1))
            self.flt.Q = Q_new

        # ---------- 自适应 R (Berry-Mehra covariance matching) ----------
        if self.adapt_r:
            HPHt = S - self.flt.R
            eeT = torch.einsum("bi,bj->bij", eps, eps)
            R_new = alpha_val * self.flt.R + (1 - alpha_val) * (eeT + HPHt)
            R_new = 0.5 * (R_new + R_new.transpose(1, 2)) + self.eps * I_z
            if self.diag_only:
                R_new = torch.diag_embed(torch.diagonal(R_new, dim1=-2, dim2=-1))
            self.flt.R = R_new


class BerryMehraAdaptiveUKF(AdaptiveBatchUKF):
    """
    显式的 Berry-Mehra 自适应 UKF 封装。
    该实现基于 Innovation covariance matching，在线更新 Q/R。
    """
    def __init__(
        self, base_filter,
        alpha_init: float = 0.1,
        adapt_q: bool = True, adapt_r: bool = True,
        tune_alpha: bool = False, eps: float = 0.0,
        diag_only: bool = False
    ):
        super().__init__(
            base_filter=base_filter,
            alpha_init=alpha_init,
            adapt_q=adapt_q,
            adapt_r=adapt_r,
            tune_alpha=tune_alpha,
            eps=eps,
            adapt_method="berry_mehra",
            diag_only=diag_only
        )


# ---------- 2) 端到端可训练 UKF ---------- #
class TrainableUKF(nn.Module):
    def __init__(self, base_filter, system_model,
                 learn_q=False, learn_r=False,
                 cov_type="diag", adapt_online=False, q_init=1e-3, r_init=1e-4, p0_scale=1e-3,
                 device=None):
        super().__init__()
        self.p0_scale = p0_scale
        # 数值稳定常量（对 Q/R 添加对角抖动），避免 S 奇异
        self.cov_jitter = 1e-8
        self.core = AdaptiveBatchUKF(base_filter, alpha_init=0.1,
                                     adapt_q=True, adapt_r=True) if adapt_online else base_filter
        if learn_q:
            self.Q_layer = LearnableCov(base_filter.dim_x, init_diag=q_init, cov_type=cov_type)
        else:
            self.register_buffer("Q_const", base_filter.Q.clone())
        if learn_r:
            self.R_layer = LearnableCov(base_filter.dim_z, init_diag=r_init, cov_type=cov_type)
        else:
            self.register_buffer("R_const", base_filter.R.clone())

        self.fx = system_model
        self.dt = 1.0

        if len(list(self.parameters())) == 0:
            self.dummy = nn.Parameter(torch.zeros(1))

        if device is not None:
            self.device = device
            self.to(device)

    def _stabilize_cov(self, M, dim):
        """对称化 + 对角抖动，返回数值更稳定的协方差。"""
        I = torch.eye(dim, device=M.device)
        Ms = 0.5 * (M + M.transpose(0, 1))
        Ms = Ms + self.cov_jitter * I
        return Ms

    # --------- 同样显式暴露 x/P/Q/R（外层代码可直接访问） ----------
    @property
    def x(self):
        return self.core.x

    @property
    def P(self):
        return self.core.P

    @property
    def Q(self):
        return self.Q_layer() if hasattr(self, "Q_layer") else self.Q_const

    @property
    def R(self):
        return self.R_layer() if hasattr(self, "R_layer") else self.R_const

    # --------------------------------------------------------------
    def forward(self, y_t, u_t):
        B = y_t.size(0)
        # 数值稳定：对 Q/R 进行对称化并添加对角抖动
        Q_now = self._stabilize_cov(self.Q, self.core.dim_x)
        R_now = self._stabilize_cov(self.R, self.core.dim_z)

        # 调试打印（可通过 KF_DEBUG_QR=1 开启）
        if os.getenv("KF_DEBUG_QR", "0") == "1":
            try:
                qd = torch.diag(Q_now)
                rd = torch.diag(R_now)
                print(f"[QR] diag(Q): min={qd.min().item():.3e}, max={qd.max().item():.3e}; diag(R): min={rd.min().item():.3e}, max={rd.max().item():.3e}")
            except Exception:
                pass

        self.core.Q = Q_now.unsqueeze(0).repeat(B, 1, 1)
        self.core.R = R_now.unsqueeze(0).repeat(B, 1, 1)

        self.core.fx = lambda sig, dt, c=u_t: fx_walrus_batch(sig, dt, sys_model=self.fx, controls=c, device=self.device)
        self.core.predict(dt=self.dt)
        self.core.hx = lambda sig: hx_walrus_batch(sig, sys_model=self.fx, device=self.device)
        self.core.update(y_t)
        return self.core.x  # [B, m]

    def init_sequence(self, x0_seq, seq_len=None):
        """
        在每条新序列开始前调用：
          - 初始化状态 x
          - 用 p0_scale 重置协方差 P
        """
        # detach + clone，切断旧计算图
        x0 = x0_seq.detach().clone().to(self.device)  # [B, m]
        self.core.x = x0

        # 构造 P0
        P0 = _as_diag_tensor(self.p0_scale, self.core.dim_x, self.device)  # [m,m]
        jitter = 1e-6 * torch.eye(self.core.dim_x, device=self.device)
        P0 = (P0 + jitter).unsqueeze(0).repeat(self.batch_size, 1, 1)  # [B, m, m]
        self.core.P = P0

        # print("init_sequence called")