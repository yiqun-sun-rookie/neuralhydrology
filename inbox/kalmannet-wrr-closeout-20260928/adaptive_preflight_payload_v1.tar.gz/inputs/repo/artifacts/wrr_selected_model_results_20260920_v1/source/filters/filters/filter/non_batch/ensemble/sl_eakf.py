# -*- coding: utf-8 -*-
"""
SL_EAKF - 随机局部化集合调整 Kalman 滤波器

单步实现，支持 predict()/update() 接口。

参考文献:
- Anderson (2012): Localization and Sampling Error Correction in Ensemble Kalman Filter Data Assimilation
"""

from __future__ import annotations

from typing import Callable, Optional

import numpy as np
from scipy.linalg import sqrtm

from .etkf import ETKF


class SL_EAKF(ETKF):
    """
    随机局部化集合调整 Kalman 滤波器。
    
    SL_EAKF 使用随机化的局部化方法，通过在状态空间中引入随机扰动
    来减少采样误差，同时保持物理一致性。
    
    参数
    ----------
    dim_x : int
        状态维度
    dim_z : int
        观测维度
    fx : callable
        状态转移函数
    hx : callable
        观测函数
    N : int
        集合成员数量
    loc_radius : float
        局部化半径
    **kwargs
        其他参数传递给 ETKF
    """
    
    def __init__(
        self,
        dim_x: int,
        dim_z: int,
        fx: Callable,
        hx: Callable,
        N: int = 20,
        loc_radius: Optional[float] = None,
        **kwargs
    ):
        super().__init__(dim_x, dim_z, fx, hx, N=N, **kwargs)
        self.loc_radius = loc_radius
        self._state_obs_distances = None
    
    def set_localization(
        self,
        distances: Optional[np.ndarray] = None,
        radius: Optional[float] = None,
    ):
        """设置局部化参数。"""
        if distances is not None:
            self._state_obs_distances = np.asarray(distances, dtype=float)
        if radius is not None:
            self.loc_radius = radius
    
    def _compute_localization(self) -> np.ndarray:
        """计算局部化系数矩阵 (dim_x, dim_z)。"""
        if self.loc_radius is None or self._state_obs_distances is None:
            return np.ones((self.dim_x, self.dim_z))
        
        d = self._state_obs_distances
        r = self.loc_radius
        
        # Gaspari-Cohn 函数
        return self._gaspari_cohn(d, r)
    
    @staticmethod
    def _gaspari_cohn(d: np.ndarray, r: float) -> np.ndarray:
        """Gaspari-Cohn 局部化函数。"""
        c = r / np.sqrt(0.3)
        z = np.abs(d) / c
        
        weights = np.zeros_like(z)
        
        mask1 = z <= 1
        z1 = z[mask1]
        weights[mask1] = 1 - 5/3 * z1**2 + 5/8 * z1**3 + z1**4 / 2 - z1**5 / 4
        
        mask2 = (z > 1) & (z <= 2)
        z2 = z[mask2]
        weights[mask2] = (
            4 - 5 * z2 + 5/3 * z2**2 + 5/8 * z2**3 
            - z2**4 / 2 + z2**5 / 12 - 2 / (3 * z2)
        )
        
        weights[z > 2] = 0
        return np.maximum(weights, 0)
    
    def update(self, z: np.ndarray, **kwargs):
        """
        EAKF 风格的更新，带随机局部化。
        """
        z = np.asarray(z, dtype=float).reshape(-1)
        
        # 计算观测集合
        Y = np.zeros((self.dim_z, self.N))
        for i in range(self.N):
            Y[:, i] = np.asarray(self._hx(self.E[:, i]), dtype=float).reshape(-1)
        
        y_mean = Y.mean(axis=1)
        
        # 局部化系数
        loc_coef = self._compute_localization()  # (dim_x, dim_z)
        
        # EAKF 逐观测更新
        for m in range(self.dim_z):
            # 该观测的预测
            y_m = Y[m, :]
            y_m_mean = y_mean[m]
            y_m_var = np.var(y_m, ddof=1)
            
            if y_m_var < 1e-12:
                continue
            
            # 观测误差方差
            r_m = self.R[m, m]
            
            # 更新增益
            obs_inc = z[m] - y_m_mean
            
            # Kalman 增益（观测空间）
            k_obs = y_m_var / (y_m_var + r_m)
            
            # 观测空间的分析增量
            a_inc = k_obs * obs_inc
            
            # 调整系数（确保方差正确）
            alpha = np.sqrt(r_m / (y_m_var + r_m))
            
            # 更新观测集合
            Y[m, :] = y_m_mean + a_inc + alpha * (y_m - y_m_mean)
            
            # 更新状态集合（使用局部化的回归）
            for j in range(self.dim_x):
                x_j = self.E[j, :]
                x_j_mean = x_j.mean()
                
                # 局部化后的协方差
                cov_xy = np.cov(x_j, y_m, ddof=1)[0, 1]
                cov_xy_loc = cov_xy * loc_coef[j, m]
                
                if np.abs(cov_xy_loc) < 1e-12:
                    continue
                
                # 回归系数
                reg_coef = cov_xy_loc / y_m_var
                
                # 状态增量
                x_inc = reg_coef * (Y[m, :] - y_m)
                
                # 随机化局部化（添加小扰动以减少采样误差）
                if self.loc_radius is not None:
                    noise_scale = 0.01 * np.std(x_j) * (1 - loc_coef[j, m])
                    x_inc += noise_scale * np.random.randn(self.N)
                
                # 更新状态
                self.E[j, :] = x_j + x_inc
            
            # 更新 y_mean 用于下一个观测
            y_mean = Y.mean(axis=1)


__all__ = ["SL_EAKF"]

