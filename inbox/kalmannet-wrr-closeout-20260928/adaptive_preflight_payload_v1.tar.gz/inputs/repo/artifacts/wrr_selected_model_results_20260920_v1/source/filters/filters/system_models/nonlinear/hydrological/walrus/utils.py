import torch
from tqdm import tqdm
from filters.utils.metrics import calc_nse, calc_mse
from filters.utils.visualization import plot_comparison_2_series
import numpy as np
import re
import yaml

def load_params_from_yaml(file_path):
    with open(file_path) as f:
        # 启用科学计数法解析
        loader = yaml.FullLoader
        loader.add_implicit_resolver(
            u'tag:yaml.org,2002:float',
            re.compile(u'''^(?:
             [-+]?(?:[0-9][0-9_]*)\\.[0-9_]*(?:[eE][-+]?[0-9]+)?
            |[-+]?(?:[0-9][0-9_]*)(?:[eE][-+]?[0-9]+)
            |\\.[0-9_]+(?:[eE][-+]?[0-9]+)?
            |[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\\.[0-9_]*$
            |[-+]?\\.(?:inf|Inf|INF)
            |\\.(?:nan|NaN|NAN))$''', re.X),
            list(u'-+0123456789.'))
        return yaml.load(f, Loader=loader)



def run_model(hydro_model, controls, device):
    """
    运行Walrus模型并返回所有状态。

    参数:
    ----------
    controls : torch.Tensor
        控制变量，形状为 [1, sim_len, 2]，其中2表示p和etpot。
    state0 : torch.Tensor
        初始状态，形状为 [m]。
    params : dict
        模型参数。
    device : torch.device
        设备（CPU或GPU）。

    返回:
    -------
    torch.Tensor
        所有时间步的状态，形状为 [sim_len, m]。
    """
    sim_len = controls.shape[0]
    m = len(hydro_model.state)

    # 初始化状态记录
    states = torch.zeros((sim_len, m), dtype=torch.float32, device=device)
    states[0, :] = hydro_model.state

    # 运行模型
    with tqdm(range(1, sim_len), desc="Running Walrus Model", unit="step") as pbar:
        for t in pbar:
            controls_t = controls[t, :].unsqueeze(0) # [1, 2]
            x_prev = states[t - 1, :].unsqueeze(0)  # [1, m]
            x_next = hydro_model.f(x_prev, controls_t)  # [1, m]
            states[t, :] = x_next.squeeze(0)

    outputs = states[:, -1]
    return states, outputs


def evaluate_and_plot(states_all, qobs_array, filename_prefix, save_plots=True):
    """
    计算评估指标，绘制对比图，并保存结果。

    参数:
    ----------
    states_all : torch.Tensor
        所有时间步的状态，形状为 [sim_len, m]。
    qobs_array : array-like
        观测的Q值，长度为 sim_len。
    filename_prefix : str
        文件名前缀，用于保存图像和状态。
    save_plots : bool, optional
        是否保存绘图结果，默认为 True。

    返回:
    -------
    dict
        包含评估指标的字典。
    """
    sim_len = states_all.shape[0]

    # 提取Q状态
    q_state = states_all[:, -1].detach().cpu().numpy()  # [sim_len]
    q_obs_plot = qobs_array[:sim_len]  # [sim_len]

    # 计算评估指标
    nse = calc_nse(q_obs_plot, q_state)
    mse = calc_mse(q_obs_plot, q_state)
    metrics = {"NSE": nse, "MSE": mse}

    print(f"NSE for {filename_prefix}: {nse}")
    print(f"MSE for {filename_prefix}: {mse}")

    # 绘图
    if save_plots:
        plot_comparison_2_series(
            q_obs_plot,
            q_state,
            title=f'Comparison of Modeled Q and Observed Q - {filename_prefix}',
            xlabel='Time step',
            ylabel='Q',
            legend=['Observed Q', 'Modeled Q (states_all last dim)'],
            filename=f'results/figures/{filename_prefix}_comparison.png'
        )

    return metrics


def create_controls(p, etpot, device):
    """
    合并 p 和 etpot 为控制变量。

    参数:
    ----------
    p : array-like
        降水量。
    etpot : array-like
        潜在蒸散量。

    返回:
    -------
    torch.Tensor
        控制变量，形状为 [1, sim_len, 2]。
    """
    controls = np.stack((p, etpot), axis=-1)  # [sim_len, 2]
    controls_tensor = torch.tensor(controls, dtype=torch.float32, device=device)  # [sim_len, 2]
    return controls_tensor

