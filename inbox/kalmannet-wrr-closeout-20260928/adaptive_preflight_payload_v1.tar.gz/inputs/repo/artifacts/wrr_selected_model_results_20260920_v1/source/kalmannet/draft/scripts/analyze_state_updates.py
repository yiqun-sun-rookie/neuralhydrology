"""Compare posterior-minus-prior state corrections across the three paper filters.

This is an inference-only diagnostic. It uses deterministic, non-overlapping
windows from the existing training and test datasets so each underlying hour is
counted once. Hydrological states are not observed; the output therefore
describes update behavior, not state-estimation accuracy.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import types
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

import numpy as np
import torch
import yaml
from torch.utils.data._utils.collate import default_collate


PROJECT_ROOT = Path(__file__).resolve().parents[2]
PROJECTS_ROOT = PROJECT_ROOT.parent
for _path in (PROJECT_ROOT, PROJECTS_ROOT):
    if str(_path) not in sys.path:
        sys.path.insert(0, str(_path))

EXPERIMENT_ID = "D01_state_update_characteristics_h1_24_20260723"
DEFAULT_OUTPUT_DIR = (
    PROJECT_ROOT / "draft" / "artifacts" / "state_update_diagnostics_20260723"
)
DEFAULT_FIGURE_PDF = (
    PROJECT_ROOT / "draft" / "latex" / "figures" / "state_update_characteristics.pdf"
)
DEFAULT_FIGURE_PNG = (
    PROJECT_ROOT / "draft" / "latex" / "figures" / "state_update_characteristics.png"
)

TRAIN_DATA_PATH = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "high_flow_aug"
    / "train_win800_19990101_01-20070527_03.pt"
)
TEST_DATA_PATH = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "high_flow_aug"
    / "test_win800_20090314_14-20110101_01.pt"
)

STATE_NAMES = [
    "Storage deficit",
    "Groundwater depth",
    "Quickflow level",
    "Surface-water level",
    "Discharge",
]
STATE_SYMBOLS = [r"$d_v$", r"$d_g$", r"$h_q$", r"$h_s$", r"$Q$"]
METHOD_LABELS = {
    "neural_gain": "Neural gain",
    "learned_noise": "Learned noise",
    "hand_tuned": "Hand tuned",
}


def build_nonoverlapping_slices(
    num_windows: int, window_size: int
) -> list[tuple[int, int, int]]:
    """Return (window index, first offset, exclusive last offset) specifications.

    A sliding-window dataset with ``num_windows`` windows of length
    ``window_size`` contains ``num_windows + window_size - 1`` underlying
    hourly records. The returned slices cover each of those hours exactly once.
    """
    if num_windows <= 0 or window_size <= 0:
        raise ValueError("num_windows and window_size must be positive")

    total_hours = num_windows + window_size - 1
    specs: list[tuple[int, int, int]] = []
    covered_until = 0

    for window_index in range(0, num_windows, window_size):
        end_global = min(window_index + window_size, total_hours)
        specs.append((window_index, 0, end_global - window_index))
        covered_until = end_global

    if covered_until < total_hours:
        final_window = num_windows - 1
        start_offset = covered_until - final_window
        specs.append((final_window, start_offset, window_size))

    return specs


def compute_state_scales(states: np.ndarray) -> np.ndarray:
    """Return per-state interquartile ranges with finite positive fallbacks."""
    values = np.asarray(states, dtype=np.float64)
    if values.ndim != 2:
        raise ValueError("states must have shape [time, state]")

    q25, q75 = np.nanpercentile(values, [25, 75], axis=0)
    scales = q75 - q25
    standard_deviation = np.nanstd(values, axis=0)
    invalid = ~np.isfinite(scales) | (scales <= 0)
    scales[invalid] = standard_deviation[invalid]
    invalid = ~np.isfinite(scales) | (scales <= 0)
    scales[invalid] = 1.0
    return scales


def _distribution_summary(values: np.ndarray) -> dict[str, list[float] | int]:
    absolute = np.abs(values)
    return {
        "n": int(values.shape[0]),
        "median_signed_normalized": np.nanmedian(values, axis=0).tolist(),
        "q25_signed_normalized": np.nanpercentile(values, 25, axis=0).tolist(),
        "q75_signed_normalized": np.nanpercentile(values, 75, axis=0).tolist(),
        "median_absolute_normalized": np.nanmedian(absolute, axis=0).tolist(),
        "q25_absolute_normalized": np.nanpercentile(absolute, 25, axis=0).tolist(),
        "q75_absolute_normalized": np.nanpercentile(absolute, 75, axis=0).tolist(),
        "p95_absolute_normalized": np.nanpercentile(absolute, 95, axis=0).tolist(),
    }


def summarize_updates(
    updates_by_method: dict[str, np.ndarray],
    discharge: np.ndarray,
    state_scales: np.ndarray,
    flow_q25: float,
    flow_q75: float,
    state_names: list[str],
) -> dict:
    """Summarize signed and absolute normalized corrections by flow group."""
    discharge_values = np.asarray(discharge, dtype=np.float64).reshape(-1)
    scales = np.asarray(state_scales, dtype=np.float64).reshape(1, -1)
    if len(state_names) != scales.shape[1]:
        raise ValueError("state_names and state_scales must have the same length")

    masks = {
        "all": np.isfinite(discharge_values),
        "low": np.isfinite(discharge_values) & (discharge_values <= flow_q25),
        "mid": (
            np.isfinite(discharge_values)
            & (discharge_values > flow_q25)
            & (discharge_values <= flow_q75)
        ),
        "high": np.isfinite(discharge_values) & (discharge_values > flow_q75),
    }

    methods: dict[str, dict] = {}
    for method, raw_updates in updates_by_method.items():
        update_values = np.asarray(raw_updates, dtype=np.float64)
        if update_values.shape != (discharge_values.size, scales.shape[1]):
            raise ValueError(
                f"{method} updates have shape {update_values.shape}; expected "
                f"{(discharge_values.size, scales.shape[1])}"
            )
        normalized = update_values / scales
        methods[method] = {
            regime: _distribution_summary(normalized[mask])
            for regime, mask in masks.items()
        }

    return {
        "state_names": state_names,
        "state_scales_training_iqr": scales.reshape(-1).tolist(),
        "flow_thresholds_test_discharge": {
            "q25": float(flow_q25),
            "q75": float(flow_q75),
        },
        "methods": methods,
    }


def capture_prior_and_posterior(model, observation, control):
    """Run the learned-noise model's original forward while capturing its prior."""
    core = model.core
    had_local_predict = "predict" in getattr(core, "__dict__", {})
    previous_local_predict = core.__dict__.get("predict") if had_local_predict else None
    original_predict = core.predict
    captured: dict[str, torch.Tensor] = {}

    def predict_and_capture(*args, **kwargs):
        result = original_predict(*args, **kwargs)
        captured["prior"] = core.x.detach().clone()
        return result

    core.predict = predict_and_capture
    try:
        posterior = model(observation, control)
    finally:
        if had_local_predict:
            core.predict = previous_local_predict
        else:
            delattr(core, "predict")

    if "prior" not in captured:
        raise RuntimeError("The model forward did not call core.predict")
    return captured["prior"], posterior.detach().clone()


def _install_legacy_dataset_aliases() -> None:
    import knet.modules
    import knet.modules.nn
    import knet.modules.pipeline

    sys.modules.setdefault("src", types.ModuleType("src"))
    sys.modules["src.modules"] = knet.modules
    sys.modules["src.modules.pipeline"] = knet.modules.pipeline
    sys.modules["src.modules.nn"] = knet.modules.nn


def _load_dataset(path: Path):
    _install_legacy_dataset_aliases()
    return torch.load(path, map_location="cpu", weights_only=False)


def _iter_slice_batches(dataset, specs, batch_size: int = 32):
    grouped: dict[tuple[int, int], list[int]] = defaultdict(list)
    for window_index, start_offset, end_offset in specs:
        grouped[(start_offset, end_offset)].append(window_index)

    for (start_offset, end_offset), window_indices in grouped.items():
        for first in range(0, len(window_indices), batch_size):
            indices = window_indices[first : first + batch_size]
            batch = default_collate([dataset[index] for index in indices])
            yield batch, start_offset, end_offset


def _reference_statistics(dataset, specs) -> tuple[np.ndarray, np.ndarray]:
    state_parts = []
    discharge_parts = []
    for batch, start, end in _iter_slice_batches(dataset, specs, batch_size=32):
        states = batch["state0"][:, :, start:end].permute(0, 2, 1)
        discharge = batch["qobs"][:, 0, start:end]
        state_parts.append(states.reshape(-1, states.shape[-1]).numpy())
        discharge_parts.append(discharge.reshape(-1).numpy())

    state_values = np.concatenate(state_parts, axis=0)
    discharge_values = np.concatenate(discharge_parts)
    discharge_values = discharge_values[np.isfinite(discharge_values)]
    return compute_state_scales(state_values), discharge_values


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=PROJECT_ROOT,
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except Exception:
        return "unknown"


def _prepare_neural_gain(device: torch.device, sample_p: torch.Tensor):
    from draft.scripts import generate_paper_metrics as paper_metrics
    import knet.utils.model_initialization_use_script_mdl_1 as initialization

    with paper_metrics.LOCAL_CONFIG_PATH.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    with paper_metrics.V2_CONFIG_PATH.open("r", encoding="utf-8") as handle:
        version_two_config = yaml.safe_load(handle)

    config["model"]["knet"].update(
        {
            "hidden_size": 32,
            "in_mult": 10,
            "out_mult": 10,
            "num_layers": 1,
            "activation": "relu",
            "dropout": 0.0,
        }
    )
    version_two_model = version_two_config.get("model", {}).get("knet", {})
    for key in ("state_bounds", "clamp_scale"):
        if key in version_two_model:
            config["model"]["knet"][key] = version_two_model[key]

    args = paper_metrics.build_args(config, sample_p, sample_p)
    args.device = str(device)
    system_model = initialization.initialize_system_model(
        args.train_seq_len, args.seq_len_val, device=device
    )
    model = paper_metrics.build_knet(system_model, args).to(device)
    checkpoint = torch.load(
        paper_metrics.KNET_PATH, map_location=device, weights_only=False
    )
    state_dict = checkpoint.get("model_state_dict", checkpoint)
    model.load_state_dict(state_dict)
    model.eval()
    return model, system_model, paper_metrics.KNET_PATH


def _prepare_learned_noise(device: torch.device, sample_p: torch.Tensor):
    from draft.scripts import generate_paper_metrics as paper_metrics
    import knet.utils.model_initialization_use_script_mdl_1 as initialization

    with paper_metrics.UKF_CONFIG_PATH.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    config["model"]["type"] = "trainable_ukf"
    args = paper_metrics.build_args(config, sample_p, sample_p)
    args.device = str(device)
    system_model = initialization.initialize_system_model(
        args.train_seq_len, args.seq_len_val, device=device
    )
    model = paper_metrics.build_trainable_kf(config, system_model, args).to(device)
    checkpoint = torch.load(
        paper_metrics.UKF_PATH, map_location=device, weights_only=False
    )
    state_dict = checkpoint.get("model_state_dict", checkpoint)
    model.load_state_dict(state_dict)
    model.eval()
    return model, system_model, paper_metrics.UKF_PATH


def _prepare_batch(batch, start: int, end: int, device: torch.device):
    from knet.modules.pipeline.utils import prepare_batch_data

    precipitation, evaporation, observation, states, time_hours = prepare_batch_data(
        batch, device
    )
    return (
        precipitation[:, :, start:end],
        evaporation[:, :, start:end],
        observation[:, :, start:end],
        states[:, :, start:end],
        time_hours[:, :, start:end],
    )


def _run_neural_gain(dataset, specs, device):
    sample_p = dataset[0]["p"].squeeze()
    model, _system_model, checkpoint_path = _prepare_neural_gain(device, sample_p)
    corrections = []
    observations = []

    with torch.no_grad():
        for batch, start, end in _iter_slice_batches(dataset, specs):
            precipitation, evaporation, discharge, states, _ = _prepare_batch(
                batch, start, end, device
            )
            control = torch.cat((precipitation, evaporation), dim=1)
            batch_size, _, sequence_length = discharge.shape
            model.batch_size = batch_size
            model.init_hidden_KNet()
            model.update_mode = True
            model.init_sequence(states[:, :, 0], sequence_length)

            batch_corrections = []
            for time_index in range(sequence_length):
                posterior = model(
                    discharge[:, :, time_index], control[:, :, time_index]
                )
                prior = model.m1x_prior.detach()
                batch_corrections.append((posterior - prior).cpu())

            corrections.append(torch.stack(batch_corrections, dim=1).reshape(-1, 5))
            observations.append(discharge[:, 0, :].cpu().reshape(-1))

    return (
        torch.cat(corrections).numpy(),
        torch.cat(observations).numpy(),
        checkpoint_path,
    )


def _run_learned_noise(dataset, specs, device):
    sample_p = dataset[0]["p"].squeeze()
    model, _system_model, checkpoint_path = _prepare_learned_noise(device, sample_p)
    corrections = []
    observations = []

    with torch.no_grad():
        for batch, start, end in _iter_slice_batches(dataset, specs):
            precipitation, evaporation, discharge, states, _ = _prepare_batch(
                batch, start, end, device
            )
            control = torch.cat((precipitation, evaporation), dim=1)
            batch_size, _, sequence_length = discharge.shape
            model.batch_size = batch_size
            model.update_mode = True
            model.init_sequence(states[:, :, 0], sequence_length)

            batch_corrections = []
            for time_index in range(sequence_length):
                prior, posterior = capture_prior_and_posterior(
                    model,
                    discharge[:, :, time_index],
                    control[:, :, time_index],
                )
                batch_corrections.append((posterior - prior).cpu())

            corrections.append(torch.stack(batch_corrections, dim=1).reshape(-1, 5))
            observations.append(discharge[:, 0, :].cpu().reshape(-1))

    return (
        torch.cat(corrections).numpy(),
        torch.cat(observations).numpy(),
        checkpoint_path,
    )


def _run_hand_tuned(dataset, specs, device):
    from draft.scripts.generate_paper_metrics import HANDTUNED_Q, HANDTUNED_R
    from filters.da_coupler.walrus_batch import fx_walrus_batch, hx_walrus_batch
    from filters.filter.batch.my_version.batch_unscentedkalmanfilter_gpu import (
        BatchUnscentedKalmanFilterGPU,
    )
    from filters.filter.non_batch.kalman import MerweScaledSigmaPoints
    import knet.utils.model_initialization_use_script_mdl_1 as initialization

    system_model = initialization.initialize_system_model(800, 800, device=device)
    corrections = []
    observations = []

    with torch.no_grad():
        for batch, start, end in _iter_slice_batches(dataset, specs):
            precipitation, evaporation, discharge, states, _ = _prepare_batch(
                batch, start, end, device
            )
            control = torch.cat((precipitation, evaporation), dim=1)
            batch_size, observation_dim, sequence_length = discharge.shape
            initial_state = states[:, :, 0]
            state_dim = initial_state.shape[1]

            points = MerweScaledSigmaPoints(
                n=state_dim, alpha=0.6874, beta=2.0, kappa=-2.0
            )
            points.c = points.alpha**2 * (points.n + points.kappa)
            filter_model = BatchUnscentedKalmanFilterGPU(
                dim_x=state_dim,
                dim_z=observation_dim,
                dt=1.0,
                hx=lambda sigma_points: hx_walrus_batch(
                    sigma_points, sys_model=system_model, device=device
                ),
                fx=lambda sigma_points, dt: fx_walrus_batch(
                    sigma_points,
                    dt,
                    sys_model=system_model,
                    controls=None,
                    device=device,
                ),
                points=points,
                batch_size=batch_size,
            )
            filter_model.x = initial_state.clone()
            filter_model.P = torch.diag_embed(0.1 * initial_state.clone())
            q_values = torch.tensor(HANDTUNED_Q, dtype=torch.float32, device=device)
            filter_model.Q = (
                torch.diag_embed(q_values)
                .unsqueeze(0)
                .expand(batch_size, -1, -1)
                .clone()
            )
            r_values = torch.tensor(HANDTUNED_R, dtype=torch.float32, device=device)
            filter_model.R = (
                torch.diag_embed(r_values)
                .unsqueeze(0)
                .expand(batch_size, -1, -1)
                .clone()
            )

            batch_corrections = []
            for time_index in range(sequence_length):
                current_control = control[:, :, time_index]
                filter_model.fx = (
                    lambda sigma_points, dt, current_control=current_control: fx_walrus_batch(
                        sigma_points,
                        dt,
                        sys_model=system_model,
                        controls=current_control,
                        device=device,
                    )
                )
                filter_model.predict()
                prior = filter_model.x.detach().clone()
                filter_model.update(discharge[:, :, time_index])
                batch_corrections.append((filter_model.x - prior).cpu())

            corrections.append(torch.stack(batch_corrections, dim=1).reshape(-1, 5))
            observations.append(discharge[:, 0, :].cpu().reshape(-1))

    return torch.cat(corrections).numpy(), torch.cat(observations).numpy()


def _plot_summary(summary: dict, pdf_path: Path, png_path: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import LogNorm

    methods = ["neural_gain", "learned_noise", "hand_tuned"]
    regimes = ["low", "mid", "high"]
    matrices = []
    for regime in regimes:
        matrices.append(
            np.asarray(
                [
                    summary["methods"][method][regime][
                        "median_absolute_normalized"
                    ]
                    for method in methods
                ],
                dtype=float,
            )
        )

    positive = np.concatenate([matrix.reshape(-1) for matrix in matrices])
    positive = positive[np.isfinite(positive) & (positive > 0)]
    lower = max(float(positive.min()), 1e-5)
    upper = float(positive.max())
    norm = LogNorm(vmin=lower, vmax=upper)

    figure, axes = plt.subplots(1, 3, figsize=(7.5, 2.9), sharey=True)
    last_image = None
    for axis, regime, matrix in zip(axes, regimes, matrices):
        last_image = axis.imshow(matrix, cmap="viridis", norm=norm, aspect="auto")
        axis.set_title(f"{regime.capitalize()} flow")
        axis.set_xticks(range(len(STATE_SYMBOLS)), STATE_SYMBOLS)
        axis.tick_params(axis="x", labelsize=9)
    axes[0].set_yticks(
        range(len(methods)), [METHOD_LABELS[method] for method in methods]
    )
    figure.supxlabel("Hydrological state", y=0.02, fontsize=9)
    colorbar = figure.colorbar(
        last_image, ax=axes, fraction=0.028, pad=0.03, location="right"
    )
    colorbar.set_label(
        "Median absolute update / training-state interquartile range", fontsize=8
    )
    figure.subplots_adjust(left=0.18, right=0.87, bottom=0.20, top=0.86, wspace=0.12)

    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    png_path.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(pdf_path, bbox_inches="tight")
    figure.savefig(png_path, dpi=300, bbox_inches="tight")
    plt.close(figure)


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def run(output_dir: Path, figure_pdf: Path, figure_png: Path, device_name: str):
    device = torch.device(device_name)
    training_dataset = _load_dataset(TRAIN_DATA_PATH)
    test_dataset = _load_dataset(TEST_DATA_PATH)
    window_size = int(test_dataset[0]["qobs"].shape[-1])
    training_slices = build_nonoverlapping_slices(len(training_dataset), window_size)
    test_slices = build_nonoverlapping_slices(len(test_dataset), window_size)

    state_scales, _training_discharge = _reference_statistics(
        training_dataset, training_slices
    )
    _test_state_scales, test_discharge_reference = _reference_statistics(
        test_dataset, test_slices
    )
    flow_q25, flow_q75 = np.percentile(test_discharge_reference, [25, 75])
    neural_updates, neural_discharge, neural_checkpoint = _run_neural_gain(
        test_dataset, test_slices, device
    )
    learned_updates, learned_discharge, learned_checkpoint = _run_learned_noise(
        test_dataset, test_slices, device
    )
    hand_updates, hand_discharge = _run_hand_tuned(test_dataset, test_slices, device)

    if not (
        np.array_equal(neural_discharge, learned_discharge, equal_nan=True)
        and np.array_equal(neural_discharge, hand_discharge, equal_nan=True)
    ):
        raise RuntimeError("The three filters were not evaluated on identical observations")

    summary = summarize_updates(
        updates_by_method={
            "neural_gain": neural_updates,
            "learned_noise": learned_updates,
            "hand_tuned": hand_updates,
        },
        discharge=neural_discharge,
        state_scales=state_scales,
        flow_q25=flow_q25,
        flow_q75=flow_q75,
        state_names=STATE_NAMES,
    )
    summary["experiment_id"] = EXPERIMENT_ID
    summary["evidence_boundary"] = (
        "The five hydrological states are unobserved. These statistics describe "
        "posterior-minus-prior update behavior and do not measure state accuracy."
    )
    summary["sample_design"] = {
        "window_size_hours": window_size,
        "training_slices": len(training_slices),
        "test_slices": len(test_slices),
        "test_hours_counted_once": int(neural_discharge.size),
        "dense_window_duplicates_excluded": True,
    }

    output_dir.mkdir(parents=True, exist_ok=True)
    summary_path = output_dir / "state_update_summary.json"
    _write_json(summary_path, summary)
    _plot_summary(summary, figure_pdf, figure_png)

    from draft.scripts import generate_paper_metrics as paper_metrics

    config_paths = [
        paper_metrics.LOCAL_CONFIG_PATH,
        paper_metrics.V2_CONFIG_PATH,
        paper_metrics.UKF_CONFIG_PATH,
    ]
    run_config = {
        "experiment_id": EXPERIMENT_ID,
        "status": "complete",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "inference_only": True,
        "model_selection_or_retraining": False,
        "git_commit": _git_commit(),
        "analysis_script_sha256": _sha256(Path(__file__).resolve()),
        "device": str(device),
        "torch_version": torch.__version__,
        "data": {
            "training_path": str(TRAIN_DATA_PATH),
            "training_sha256": _sha256(TRAIN_DATA_PATH),
            "test_path": str(TEST_DATA_PATH),
            "test_sha256": _sha256(TEST_DATA_PATH),
        },
        "checkpoints": {
            "neural_gain": {
                "path": str(neural_checkpoint),
                "sha256": _sha256(neural_checkpoint),
            },
            "learned_noise": {
                "path": str(learned_checkpoint),
                "sha256": _sha256(learned_checkpoint),
            },
            "hand_tuned": {
                "Q": paper_metrics.HANDTUNED_Q,
                "R": paper_metrics.HANDTUNED_R,
            },
        },
        "config_sha256": {
            str(path): _sha256(path) for path in config_paths
        },
        "normalization": "Per-state interquartile range from non-overlapping training hours",
        "flow_groups": (
            "Q25 and Q75 of nonduplicated test observations; descriptive only "
            "and not used for training or model selection"
        ),
        "outputs": {
            "summary": str(summary_path),
            "figure_pdf": str(figure_pdf),
            "figure_png": str(figure_png),
        },
    }
    _write_json(output_dir / "run_config.json", run_config)
    return summary


def parse_args(argv: Iterable[str] | None = None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--figure-pdf", type=Path, default=DEFAULT_FIGURE_PDF)
    parser.add_argument("--figure-png", type=Path, default=DEFAULT_FIGURE_PNG)
    parser.add_argument(
        "--device",
        default="cuda" if torch.cuda.is_available() else "cpu",
    )
    return parser.parse_args(argv)


def main(argv: Iterable[str] | None = None) -> int:
    arguments = parse_args(argv)
    summary = run(
        output_dir=arguments.output_dir,
        figure_pdf=arguments.figure_pdf,
        figure_png=arguments.figure_png,
        device_name=arguments.device,
    )
    print(
        json.dumps(
            {
                "experiment_id": summary["experiment_id"],
                "test_hours": summary["sample_design"]["test_hours_counted_once"],
                "output": str(arguments.output_dir / "state_update_summary.json"),
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
