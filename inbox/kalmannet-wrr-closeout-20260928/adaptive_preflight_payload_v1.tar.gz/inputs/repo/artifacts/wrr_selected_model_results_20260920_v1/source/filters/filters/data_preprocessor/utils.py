import torch
import numpy as np
import random

def initialize_seed(seed_value):
    """
    Initialize random seeds to ensure reproducibility.
    """
    torch.manual_seed(seed_value)
    np.random.seed(seed_value)
    random.seed(seed_value)

def check_data_loader(data_loader, data_name):
    import torch
    print(f"Checking data in {data_name}...")
    for i, batch in enumerate(data_loader):
        p = batch['p']
        etpot = batch['etpot']
        qobs = batch['qobs']
        state0 = batch['state0']
        tm_hours = batch['tm_hours']

        # 检查是否存在NaN或Inf
        if torch.isnan(p).any() or torch.isnan(etpot).any() or torch.isnan(qobs).any() or torch.isnan(state0).any() or torch.isnan(tm_hours).any():
            print(f"NaN detected in {data_name} at batch {i}")
        if torch.isinf(p).any() or torch.isinf(etpot).any() or torch.isinf(qobs).any() or torch.isinf(state0).any() or torch.isinf(tm_hours).any():
            print(f"Inf detected in {data_name} at batch {i}")


def add_gaussian_noise(arr, noise_level=0.05, seed=33, ensure_non_negative=True):
    """
    对数组 arr 添加加性高斯噪声，噪声标准差 = noise_level * arr.std()。
    """
    rng = np.random.RandomState(seed)
    arr_std = arr.std() if arr.std() > 1e-8 else 1.0
    noise = rng.normal(loc=0.0, scale=noise_level * arr_std, size=arr.shape)
    arr_noisy = arr + noise
    if ensure_non_negative:
        arr_noisy = np.clip(arr_noisy, 0, None)
    return arr_noisy
