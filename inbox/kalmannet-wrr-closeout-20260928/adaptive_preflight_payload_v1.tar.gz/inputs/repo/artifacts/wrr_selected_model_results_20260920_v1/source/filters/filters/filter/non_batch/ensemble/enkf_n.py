# -*- coding: utf-8 -*-
"""
EnKF_N - 有限集合修正的集合 Kalman 滤波器

单步实现，支持 predict()/update() 接口。

参考文献:
- Bocquet (2011): Ensemble Kalman filtering without the intrinsic need for inflation
"""

from __future__ import annotations

from typing import Callable, Optional

import numpy as np
from scipy.optimize import minimize_scalar

from .etkf import ETKF


class EnKF_N(ETKF):
    """
    有限集合修正的集合 Kalman 滤波器。
    
    EnKF_N 通过自适应调整膨胀因子来补偿有限集合大小带来的采样误差，
    无需手动调参膨胀因子。
    
    参数
    ----------
    dim_x : int
        状态维度
    dim_z : int
        观测维度
    fx : callable
        状态转移函数
    hx : callable
        观测函数
    N : int
        集合成员数量
    **kwargs
        其他参数传递给 ETKF
    
    注意
    ----
    EnKF_N 会自动计算最优膨胀因子，因此构造函数中的 `infl` 参数会被忽略。
    """
    
    def __init__(
        self,
        dim_x: int,
        dim_z: int,
        fx: Callable,
        hx: Callable,
        N: int = 20,
        **kwargs
    ):
        # 移除用户指定的膨胀因子
        kwargs.pop("infl", None)
        super().__init__(dim_x, dim_z, fx, hx, N=N, infl=1.0, **kwargs)
        
        # 存储最近的最优膨胀因子（用于诊断）
        self.last_infl = 1.0
    
    def update(self, z: np.ndarray, **kwargs):
        """
        带自适应膨胀的更新步。
        """
        z = np.asarray(z, dtype=float).reshape(-1)
        
        # 计算观测集合
        Y = np.zeros((self.dim_z, self.N))
        for i in range(self.N):
            Y[:, i] = np.asarray(self._hx(self.E[:, i]), dtype=float).reshape(-1)
        
        y_mean = Y.mean(axis=1, keepdims=True)
        S = Y - y_mean  # (dim_z, N)
        d = z.reshape(-1, 1) - y_mean  # (dim_z, 1)
        A = self._anomalies()  # (dim_x, N)
        
        R_inv = np.linalg.inv(self.R)
        
        # 计算最优膨胀因子
        infl_opt = self._optimal_inflation(S, d, R_inv)
        self.last_infl = infl_opt
        
        # 应用膨胀
        mean = self.E.mean(axis=1, keepdims=True)
        A_inflated = infl_opt * A
        
        # ETKF 更新（使用膨胀后的异常）
        C = S.T @ R_inv @ S / (self.N - 1)
        C_inflated = C / (infl_opt ** 2)  # 调整 C
        
        I = np.eye(self.N)
        Pa_tilde = np.linalg.inv(I + C_inflated)
        
        T = self._matrix_sqrt(Pa_tilde)
        if self.rot:
            T = T @ self._random_orthogonal(self.N)
        
        w = Pa_tilde @ S.T @ R_inv @ d / (self.N - 1) / (infl_opt ** 2)
        
        # 更新集合
        self.E = mean + A_inflated @ w + A_inflated @ T
    
    def _optimal_inflation(
        self, 
        S: np.ndarray, 
        d: np.ndarray, 
        R_inv: np.ndarray
    ) -> float:
        """
        计算最优膨胀因子。
        
        使用简化的启发式方法，避免数值不稳定。
        """
        N = self.N
        
        # 创新向量
        d_vec = d.flatten()
        innov_norm = np.linalg.norm(d_vec)
        
        # 观测空间的散布
        s_norm = np.linalg.norm(S, 'fro') / np.sqrt(N - 1)
        
        if s_norm < 1e-10:
            return 1.02  # 默认膨胀
        
        # 简化的膨胀估计：基于创新与散布的比值
        ratio = innov_norm / (s_norm + 1e-10)
        
        # 启发式膨胀因子
        if ratio < 1.0:
            infl = 1.0
        elif ratio < 2.0:
            infl = 1.0 + 0.02 * (ratio - 1.0)
        else:
            infl = 1.02 + 0.01 * np.log(ratio)
        
        # 限制范围
        infl = np.clip(infl, 1.0, 1.5)
        
        return float(infl)


__all__ = ["EnKF_N"]

