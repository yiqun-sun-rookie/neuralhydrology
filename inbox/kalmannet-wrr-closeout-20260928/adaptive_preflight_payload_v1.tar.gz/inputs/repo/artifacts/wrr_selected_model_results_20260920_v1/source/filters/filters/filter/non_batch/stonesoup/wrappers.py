# -*- coding: utf-8 -*-
"""
Stone Soup 滤波器的统一包装器。

将 Stone Soup 的 Predictor/Updater 分离设计包装为 FilterPy 风格的
单对象 predict()/update() 接口，便于与现有代码集成。

注意：此包装器直接操作状态数组，绕过 Stone Soup 的复杂模型系统，
以便支持任意用户定义的 fx/hx 函数。
"""

from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timedelta
from typing import Any, Callable, Optional

import numpy as np
from scipy.linalg import cholesky, cho_solve


class StoneSoupKF:
    """
    Stone Soup 风格的线性 Kalman 滤波器包装。
    
    使用标准 Kalman 滤波方程，但提供与 FilterPy 一致的接口。
    """
    
    def __init__(
        self,
        dim_x: int,
        dim_z: int,
        fx: Callable,
        hx: Callable,
        dt: float = 1.0,
        Q: Optional[np.ndarray] = None,
        R: Optional[np.ndarray] = None,
        x0: Optional[np.ndarray] = None,
        P0: Optional[np.ndarray] = None,
    ):
        self.dim_x = dim_x
        self.dim_z = dim_z
        self.dt = dt
        self._fx = fx
        self._hx = hx
        
        # 协方差矩阵
        self.Q = Q if Q is not None else np.eye(dim_x) * 0.1
        self.R = R if R is not None else np.eye(dim_z) * 0.1
        
        # 初始状态
        self.x = x0 if x0 is not None else np.zeros(dim_x)
        self.P = P0 if P0 is not None else np.eye(dim_x)
        
        self.x = np.asarray(self.x, dtype=float).reshape(-1)
        self.P = np.asarray(self.P, dtype=float)
        self.Q = np.asarray(self.Q, dtype=float)
        self.R = np.asarray(self.R, dtype=float)
    
    def predict(self, controls: Optional[np.ndarray] = None, **kwargs):
        """预测步。"""
        ctrl = controls if controls is not None else kwargs.get("controls")
        
        # 状态转移
        if ctrl is not None:
            x_pred = self._fx(self.x, self.dt, controls=ctrl)
        else:
            x_pred = self._fx(self.x, self.dt)
        
        self.x = np.asarray(x_pred, dtype=float).reshape(-1)
        
        # 协方差传播（简化版：假设 F ≈ I）
        self.P = self.P + self.Q
    
    def update(self, z: np.ndarray, **kwargs):
        """更新步。"""
        z = np.asarray(z, dtype=float).reshape(-1)
        
        # 预测观测
        z_pred = np.asarray(self._hx(self.x), dtype=float).reshape(-1)
        
        # 创新
        y = z - z_pred
        
        # 简化的 Kalman 增益计算（假设 H ≈ [1, 0, 0, ...]）
        # 使用 Joseph 形式以保持数值稳定性
        S = self.P[:self.dim_z, :self.dim_z] + self.R
        
        try:
            S_chol = cholesky(S, lower=True)
            K_T = cho_solve((S_chol, True), self.P[:self.dim_z, :].T)
            K = K_T.T
        except np.linalg.LinAlgError:
            # 回退到普通求逆
            K = self.P[:, :self.dim_z] @ np.linalg.inv(S)
        
        # 状态更新
        self.x = self.x + K @ y
        
        # 协方差更新
        I_KH = np.eye(self.dim_x)
        I_KH[:, :self.dim_z] -= K
        self.P = I_KH @ self.P @ I_KH.T + K @ self.R @ K.T


class StoneSoupEKF(StoneSoupKF):
    """Stone Soup 风格的扩展 Kalman 滤波器。"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
    
    def _compute_jacobian(self, x: np.ndarray, func: Callable, eps: float = 1e-7) -> np.ndarray:
        """数值计算 Jacobian 矩阵。"""
        n = len(x)
        f0 = np.asarray(func(x), dtype=float).reshape(-1)
        m = len(f0)
        J = np.zeros((m, n), dtype=float)
        
        for i in range(n):
            x_plus = x.copy()
            x_plus[i] += eps
            f_plus = np.asarray(func(x_plus), dtype=float).reshape(-1)
            J[:, i] = (f_plus - f0) / eps
        
        return J
    
    def predict(self, controls: Optional[np.ndarray] = None, **kwargs):
        """预测步（带 Jacobian）。"""
        ctrl = controls if controls is not None else kwargs.get("controls")
        
        # 计算状态转移 Jacobian
        if ctrl is not None:
            fx_wrapper = lambda x: self._fx(x, self.dt, controls=ctrl)
        else:
            fx_wrapper = lambda x: self._fx(x, self.dt)
        
        F = self._compute_jacobian(self.x, fx_wrapper)
        
        # 状态转移
        self.x = np.asarray(fx_wrapper(self.x), dtype=float).reshape(-1)
        
        # 协方差传播
        self.P = F @ self.P @ F.T + self.Q
    
    def update(self, z: np.ndarray, **kwargs):
        """更新步（带 Jacobian）。"""
        z = np.asarray(z, dtype=float).reshape(-1)
        
        # 计算观测 Jacobian
        H = self._compute_jacobian(self.x, self._hx)
        
        # 预测观测
        z_pred = np.asarray(self._hx(self.x), dtype=float).reshape(-1)
        
        # 创新
        y = z - z_pred
        
        # Kalman 增益
        S = H @ self.P @ H.T + self.R
        try:
            K = self.P @ H.T @ np.linalg.inv(S)
        except np.linalg.LinAlgError:
            K = self.P @ H.T @ np.linalg.pinv(S)
        
        # 状态更新
        self.x = self.x + K @ y
        
        # 协方差更新 (Joseph form)
        I_KH = np.eye(self.dim_x) - K @ H
        self.P = I_KH @ self.P @ I_KH.T + K @ self.R @ K.T


class StoneSoupUKF:
    """
    Stone Soup 风格的无迹 Kalman 滤波器。
    
    使用 Merwe 缩放 sigma 点。
    """
    
    def __init__(
        self,
        dim_x: int,
        dim_z: int,
        fx: Callable,
        hx: Callable,
        dt: float = 1.0,
        Q: Optional[np.ndarray] = None,
        R: Optional[np.ndarray] = None,
        x0: Optional[np.ndarray] = None,
        P0: Optional[np.ndarray] = None,
        alpha: float = 0.001,
        beta: float = 2.0,
        kappa: float = 0.0,
    ):
        self.dim_x = dim_x
        self.dim_z = dim_z
        self.dt = dt
        self._fx = fx
        self._hx = hx
        
        # UKF 参数
        self.alpha = alpha
        self.beta = beta
        self.kappa = kappa
        
        # 计算 lambda 和权重
        self._lambda = alpha**2 * (dim_x + kappa) - dim_x
        self._compute_weights()
        
        # 协方差矩阵
        self.Q = Q if Q is not None else np.eye(dim_x) * 0.1
        self.R = R if R is not None else np.eye(dim_z) * 0.1
        
        # 初始状态
        self.x = x0 if x0 is not None else np.zeros(dim_x)
        self.P = P0 if P0 is not None else np.eye(dim_x)
        
        self.x = np.asarray(self.x, dtype=float).reshape(-1)
        self.P = np.asarray(self.P, dtype=float)
        self.Q = np.asarray(self.Q, dtype=float)
        self.R = np.asarray(self.R, dtype=float)
    
    def _compute_weights(self):
        """计算 sigma 点权重。"""
        n = self.dim_x
        lam = self._lambda
        
        # 均值权重
        self.Wm = np.full(2 * n + 1, 1 / (2 * (n + lam)))
        self.Wm[0] = lam / (n + lam)
        
        # 协方差权重
        self.Wc = np.full(2 * n + 1, 1 / (2 * (n + lam)))
        self.Wc[0] = lam / (n + lam) + (1 - self.alpha**2 + self.beta)
    
    def _compute_sigma_points(self, x: np.ndarray, P: np.ndarray) -> np.ndarray:
        """计算 sigma 点。"""
        n = self.dim_x
        lam = self._lambda
        
        # 确保 P 正定
        try:
            sqrt_P = cholesky((n + lam) * P, lower=True)
        except np.linalg.LinAlgError:
            # 添加小的对角扰动
            sqrt_P = cholesky((n + lam) * (P + 1e-9 * np.eye(n)), lower=True)
        
        sigmas = np.zeros((2 * n + 1, n))
        sigmas[0] = x
        
        for i in range(n):
            sigmas[i + 1] = x + sqrt_P[:, i]
            sigmas[n + i + 1] = x - sqrt_P[:, i]
        
        return sigmas
    
    def predict(self, controls: Optional[np.ndarray] = None, **kwargs):
        """预测步。"""
        ctrl = controls if controls is not None else kwargs.get("controls")
        
        # 生成 sigma 点
        sigmas = self._compute_sigma_points(self.x, self.P)
        
        # 传播 sigma 点
        sigmas_f = np.zeros_like(sigmas)
        for i, s in enumerate(sigmas):
            if ctrl is not None:
                sigmas_f[i] = self._fx(s, self.dt, controls=ctrl)
            else:
                sigmas_f[i] = self._fx(s, self.dt)
        
        # 计算均值和协方差
        self.x = np.dot(self.Wm, sigmas_f)
        
        y = sigmas_f - self.x
        self.P = y.T @ np.diag(self.Wc) @ y + self.Q
        
        # 保存用于更新
        self._sigmas_f = sigmas_f
    
    def update(self, z: np.ndarray, **kwargs):
        """更新步。"""
        z = np.asarray(z, dtype=float).reshape(-1)
        
        # 传播 sigma 点到观测空间
        sigmas_h = np.zeros((2 * self.dim_x + 1, self.dim_z))
        for i, s in enumerate(self._sigmas_f):
            sigmas_h[i] = np.asarray(self._hx(s), dtype=float).reshape(-1)
        
        # 预测观测
        z_pred = np.dot(self.Wm, sigmas_h)
        
        # 创新协方差
        y_z = sigmas_h - z_pred
        Pzz = y_z.T @ np.diag(self.Wc) @ y_z + self.R
        
        # 互协方差
        y_x = self._sigmas_f - self.x
        Pxz = y_x.T @ np.diag(self.Wc) @ y_z
        
        # Kalman 增益
        try:
            K = Pxz @ np.linalg.inv(Pzz)
        except np.linalg.LinAlgError:
            K = Pxz @ np.linalg.pinv(Pzz)
        
        # 状态更新
        self.x = self.x + K @ (z - z_pred)
        
        # 协方差更新
        self.P = self.P - K @ Pzz @ K.T


class StoneSoupEnKF:
    """Stone Soup 风格的集合 Kalman 滤波器。"""
    
    def __init__(
        self,
        dim_x: int,
        dim_z: int,
        fx: Callable,
        hx: Callable,
        dt: float = 1.0,
        Q: Optional[np.ndarray] = None,
        R: Optional[np.ndarray] = None,
        x0: Optional[np.ndarray] = None,
        P0: Optional[np.ndarray] = None,
        ensemble_size: int = 50,
    ):
        self.dim_x = dim_x
        self.dim_z = dim_z
        self.dt = dt
        self._fx = fx
        self._hx = hx
        self.N = ensemble_size
        
        # 协方差矩阵
        self.Q = Q if Q is not None else np.eye(dim_x) * 0.1
        self.R = R if R is not None else np.eye(dim_z) * 0.1
        
        # 初始状态
        x0 = x0 if x0 is not None else np.zeros(dim_x)
        P0 = P0 if P0 is not None else np.eye(dim_x)
        
        x0 = np.asarray(x0, dtype=float).reshape(-1)
        P0 = np.asarray(P0, dtype=float)
        self.Q = np.asarray(self.Q, dtype=float)
        self.R = np.asarray(self.R, dtype=float)
        
        # 初始化集合
        self.ensemble = np.random.multivariate_normal(x0, P0, self.N).T  # (dim_x, N)
    
    @property
    def x(self) -> np.ndarray:
        """集合均值。"""
        return self.ensemble.mean(axis=1)
    
    @x.setter
    def x(self, value: np.ndarray):
        """重置集合到新均值（保持散布）。"""
        mean = self.ensemble.mean(axis=1, keepdims=True)
        self.ensemble = self.ensemble - mean + np.asarray(value).reshape(-1, 1)
    
    @property
    def P(self) -> np.ndarray:
        """集合协方差。"""
        mean = self.ensemble.mean(axis=1, keepdims=True)
        centered = self.ensemble - mean
        return centered @ centered.T / (self.N - 1)
    
    @P.setter
    def P(self, value: np.ndarray):
        """通过重采样设置协方差。"""
        mean = self.x
        self.ensemble = np.random.multivariate_normal(mean, value, self.N).T
    
    def predict(self, controls: Optional[np.ndarray] = None, **kwargs):
        """预测步。"""
        ctrl = controls if controls is not None else kwargs.get("controls")
        
        # 传播每个集合成员
        for i in range(self.N):
            if ctrl is not None:
                self.ensemble[:, i] = self._fx(self.ensemble[:, i], self.dt, controls=ctrl)
            else:
                self.ensemble[:, i] = self._fx(self.ensemble[:, i], self.dt)
            
            # 添加过程噪声
            self.ensemble[:, i] += np.random.multivariate_normal(
                np.zeros(self.dim_x), self.Q
            )
    
    def update(self, z: np.ndarray, **kwargs):
        """更新步。"""
        z = np.asarray(z, dtype=float).reshape(-1)
        
        # 计算观测集合
        H_ensemble = np.zeros((self.dim_z, self.N))
        for i in range(self.N):
            H_ensemble[:, i] = np.asarray(self._hx(self.ensemble[:, i]), dtype=float).reshape(-1)
        
        # 均值
        x_mean = self.ensemble.mean(axis=1, keepdims=True)
        h_mean = H_ensemble.mean(axis=1, keepdims=True)
        
        # 扰动
        X = self.ensemble - x_mean
        Y = H_ensemble - h_mean
        
        # 协方差
        Pxy = X @ Y.T / (self.N - 1)
        Pyy = Y @ Y.T / (self.N - 1) + self.R
        
        # Kalman 增益
        try:
            K = Pxy @ np.linalg.inv(Pyy)
        except np.linalg.LinAlgError:
            K = Pxy @ np.linalg.pinv(Pyy)
        
        # 更新每个集合成员
        for i in range(self.N):
            # 扰动观测
            z_perturbed = z + np.random.multivariate_normal(
                np.zeros(self.dim_z), self.R
            )
            innovation = z_perturbed - H_ensemble[:, i]
            self.ensemble[:, i] += K @ innovation


class StoneSoupParticleFilter:
    """Stone Soup 风格的粒子滤波器 (SIR)。"""
    
    def __init__(
        self,
        dim_x: int,
        dim_z: int,
        fx: Callable,
        hx: Callable,
        dt: float = 1.0,
        Q: Optional[np.ndarray] = None,
        R: Optional[np.ndarray] = None,
        x0: Optional[np.ndarray] = None,
        P0: Optional[np.ndarray] = None,
        num_particles: int = 500,
    ):
        self.dim_x = dim_x
        self.dim_z = dim_z
        self.dt = dt
        self._fx = fx
        self._hx = hx
        self.N = num_particles
        
        # 噪声协方差
        self.Q = Q if Q is not None else np.eye(dim_x) * 0.1
        self.R = R if R is not None else np.eye(dim_z) * 0.1
        
        # 初始化粒子
        x0 = x0 if x0 is not None else np.zeros(dim_x)
        P0 = P0 if P0 is not None else np.eye(dim_x)
        
        self.particles = np.random.multivariate_normal(x0, P0, self.N).T  # (dim_x, N)
        self.weights = np.ones(self.N) / self.N
    
    @property
    def x(self) -> np.ndarray:
        """加权均值。"""
        return (self.particles * self.weights).sum(axis=1)
    
    @property
    def P(self) -> np.ndarray:
        """加权协方差。"""
        mean = self.x.reshape(-1, 1)
        centered = self.particles - mean
        return (centered * self.weights) @ centered.T
    
    def predict(self, controls: Optional[np.ndarray] = None, **kwargs):
        """预测步。"""
        ctrl = controls if controls is not None else kwargs.get("controls")
        
        for i in range(self.N):
            if ctrl is not None:
                self.particles[:, i] = self._fx(self.particles[:, i], self.dt, controls=ctrl)
            else:
                self.particles[:, i] = self._fx(self.particles[:, i], self.dt)
            
            # 添加过程噪声
            self.particles[:, i] += np.random.multivariate_normal(
                np.zeros(self.dim_x), self.Q
            )
    
    def update(self, z: np.ndarray, **kwargs):
        """更新步。"""
        z = np.asarray(z, dtype=float).reshape(-1)
        
        # 计算似然
        R_inv = np.linalg.inv(self.R)
        for i in range(self.N):
            z_pred = np.asarray(self._hx(self.particles[:, i]), dtype=float).reshape(-1)
            diff = z - z_pred
            self.weights[i] *= np.exp(-0.5 * diff @ R_inv @ diff)
        
        # 归一化
        self.weights += 1e-300  # 防止除零
        self.weights /= self.weights.sum()
        
        # 重采样（系统重采样）
        self._systematic_resample()
    
    def _systematic_resample(self):
        """系统重采样。"""
        N = self.N
        positions = (np.random.random() + np.arange(N)) / N
        
        cumsum = np.cumsum(self.weights)
        cumsum[-1] = 1.0  # 防止浮点误差
        
        indices = np.searchsorted(cumsum, positions)
        
        self.particles = self.particles[:, indices].copy()
        self.weights = np.ones(N) / N


# 正则化粒子滤波器（继承 PF）
class StoneSoupRegularisedPF(StoneSoupParticleFilter):
    """Stone Soup 风格的正则化粒子滤波器。"""
    
    def __init__(self, *args, regularisation_factor: float = 0.5, **kwargs):
        super().__init__(*args, **kwargs)
        self.reg_factor = regularisation_factor
    
    def _systematic_resample(self):
        """带正则化的重采样。"""
        super()._systematic_resample()
        
        # 添加正则化噪声
        cov = self.P * self.reg_factor
        noise = np.random.multivariate_normal(
            np.zeros(self.dim_x), cov, self.N
        ).T
        self.particles += noise


__all__ = [
    "StoneSoupKF",
    "StoneSoupEKF",
    "StoneSoupUKF",
    "StoneSoupEnKF",
    "StoneSoupParticleFilter",
    "StoneSoupRegularisedPF",
]
