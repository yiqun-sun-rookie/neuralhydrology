"""Read-only capture and paired propagation; importable without real inputs."""
from pathlib import Path
import hashlib
import inspect
import os
import sys

import numpy as np
import torch


def readable(path):
    path = str(Path(path).resolve())
    return '\\\\?\\' + path if os.name == 'nt' and not path.startswith('\\\\?\\') else path


def sha(path):
    digest = hashlib.sha256()
    with open(readable(path), 'rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def reserve_run(path):
    # mkdir(exist_ok=False) is the atomic one-attempt/no-overwrite gate.
    Path(path).mkdir(exist_ok=False)


def save_arrays(path, **arrays):
    with Path(path).open('xb') as stream:
        np.savez_compressed(stream, **arrays)


def flatten_steps(steps):
    """[time][batch,features] -> [batch*time,features], exactly as original."""
    return torch.stack(steps, dim=1).flatten(0, 1).numpy()


def error_benefits(prior, posterior, observation):
    a = np.asarray(prior, dtype=np.float64) - observation
    b = np.asarray(posterior, dtype=np.float64) - observation
    return a, b, np.abs(a) - np.abs(b), a * a - b * b


def parity_check(actual, reference, scales):
    if actual.shape != reference.shape:
        raise ValueError('Increment reference shape differs')
    delta = np.abs(actual.astype(np.float64) - reference.astype(np.float64))
    bound = 1e-5 * np.asarray(scales) + 1e-5 * np.abs(reference.astype(np.float64))
    finite = bool(np.isfinite(actual).all() and np.isfinite(reference).all())
    return {'exact': bool(np.array_equal(actual, reference)),
            'tolerance_pass': finite and bool(np.all(delta <= bound)),
            'max_absolute_difference_by_state': np.max(delta, axis=0).tolist(),
            'n_outside_tolerance': int(np.count_nonzero(~(delta <= bound))),
            'tolerance': 'abs(error) <= 1e-5 * training_state_IQR + 1e-5 * abs(reference)'}


def paired_forecasts(system, prior, posterior, controls, device, horizon=24, batch_size=512):
    """No observations accepted. Both branches use the identical controls[t+h]."""
    if prior.shape != posterior.shape or len(controls) != len(prior):
        raise ValueError('State/forcing lengths differ')
    n = len(prior) - horizon
    if n <= 0:
        raise ValueError('No full future horizon')
    output = [np.empty((n, horizon + 1), dtype=np.float32) for _ in range(2)]
    with torch.no_grad():
        for first in range(0, n, batch_size):
            last = min(first + batch_size, n)
            branches = [torch.as_tensor(x[first:last], device=device).clone() for x in (prior, posterior)]
            for lead in range(horizon + 1):
                if lead:
                    u = torch.as_tensor(controls[first + lead:last + lead], device=device)
                    branches = [system.f(x, u) for x in branches]
                for target, x in zip(output, branches):
                    target[first:last, lead] = system.h(x).detach().cpu().reshape(-1).numpy()
    return output


class OriginalRoutineCapture:
    """Trace selected original lines/returns, never replace filter arithmetic.

    The only traced lines belong to the caller's exact _run_* code object.
    UKF update frames disable line tracing and expose z_pred on return.
    """
    def __init__(self, function, method, update_functions=()):
        self.function, self.method = function, method
        lines, first = inspect.getsourcelines(function)
        sites = [first + i for i, line in enumerate(lines) if 'batch_corrections.append(' in line]
        if len(sites) != 1:
            raise RuntimeError('Original capture site is not unique')
        self.site = sites[0]
        self.update_codes = {fn.__code__ for fn in update_functions}
        self.predicted = {}
        self.groups = []
        self.system = None

    def trace(self, frame, event, arg):
        if event == 'call':
            if frame.f_code is self.function.__code__:
                return self.trace
            if frame.f_code in self.update_codes:
                frame.f_trace_lines = False
                return self.trace
            return None
        if event == 'return' and frame.f_code in self.update_codes:
            local = frame.f_locals
            if 'z_pred' not in local:
                raise RuntimeError('Original UKF update returned without predicted observation')
            self.predicted[id(local['self'])] = local['z_pred'].detach().cpu().clone()
        elif event == 'line' and frame.f_code is self.function.__code__ and frame.f_lineno == self.site:
            self.capture(frame.f_locals)
        return self.trace

    def capture(self, local):
        time_index = local['time_index']
        prior = local['prior']
        if self.method == 'hand_tuned':
            model = local['filter_model']
            posterior = model.x
            predicted = self.predicted.pop(id(model))
            self.system = local['system_model']
        else:
            model, posterior = local['model'], local['posterior']
            self.system = local['_system_model']
            predicted = (model.m1y.detach().cpu().clone() if self.method == 'neural_gain'
                         else self.predicted.pop(id(model.core)))
        if time_index == 0:
            self.groups.append({key: [] for key in ('prior', 'posterior', 'predicted_observation')})
            self.groups[-1]['control'] = local['control'].detach().cpu().permute(0, 2, 1).flatten(0, 1).numpy().copy()
            hours = local['batch']['tm_hours'][:, :, local['start']:local['end']]
            self.groups[-1]['hours'] = hours.detach().cpu().reshape(local['batch_size'], -1).flatten().numpy().copy()
        group = self.groups[-1]
        group['prior'].append(prior.detach().cpu().clone())
        group['posterior'].append(posterior.detach().cpu().clone())
        group['predicted_observation'].append(predicted.reshape(local['batch_size'], 1))

    def run(self, *args):
        if sys.gettrace() is not None:
            raise RuntimeError('Existing debugger/tracer would be overwritten')
        sys.settrace(self.trace)
        try:
            result = self.function(*args)
        finally:
            sys.settrace(None)
        arrays = {key: np.concatenate([flatten_steps(g[key]) for g in self.groups])
                  for key in ('prior', 'posterior', 'predicted_observation')}
        arrays.update({key: np.concatenate([g[key] for g in self.groups]) for key in ('control', 'hours')})
        arrays['predicted_observation'] = arrays['predicted_observation'].reshape(-1)
        arrays['increments'] = arrays['posterior'] - arrays['prior']
        arrays['original_increments'] = result[0]
        arrays['observation'] = result[1]
        arrays['innovation'] = arrays['observation'] - arrays['predicted_observation']
        return arrays
