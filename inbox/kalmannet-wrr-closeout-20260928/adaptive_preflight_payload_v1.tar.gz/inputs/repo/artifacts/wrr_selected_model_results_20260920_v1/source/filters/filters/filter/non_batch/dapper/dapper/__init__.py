"""Root package of **DAPPER**
(Data Assimilation with Python: a Package for Experimental Research)

--8<-- "dapper/README.md"
"""

from __future__ import annotations

import sys as _sys

_pkg = _sys.modules[__name__]
# Register this module under the canonical top-level name ``dapper`` so that
# statements like ``from dapper.dpr_config import rc`` keep working even though
# the package lives inside ``filters.filter.non_batch.dapper``.
_sys.modules["dapper"] = _pkg

__version__ = "1.7.3"

# A parsimonious list of imports used in the examples.
# NOTE: In this vendored copy inside `filters`, we avoid importing tools that
# rely on cluster/remote infrastructure (e.g. `tools.remote.uplink`) so that
# simple local usage does not require those optional dependencies.
from .dpr_config import rc
from .tools.rounding import round2sigfig
from .tools.seeding import rng, set_seed
from .xp_launch import combinator, seed_and_simulate, xpList
from .xp_process import xpSpace


def find_latest_run(*args, **kwargs):  # type: ignore[override]
    """Stub for the upstream helper that located the latest remote run.

    The full implementation depends on `dapper.tools.remote.uplink`, which in turn
    assumes a specific cluster layout. For this embedded copy we do not support it.
    """
    raise NotImplementedError("find_latest_run is not available in this embedded DAPPER copy.")


def load_xps(*args, **kwargs):  # type: ignore[override]
    """Stub for the upstream helper that loads experiment results from disk."""
    raise NotImplementedError("load_xps is not available in this embedded DAPPER copy.")
