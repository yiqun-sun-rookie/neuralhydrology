import torch, os
def save_checkpoint(pipeline, epoch, is_best=False):
    checkpoint = {
        'epoch': epoch,
        'model_state_dict': pipeline.target_model.state_dict(),
        'optimizer_state_dict': pipeline.optimizer.state_dict(),
        'best_val_bp_loss': pipeline.best_val_bp_loss,
        'no_improve_epochs': pipeline.no_improve_epochs,
        'current_phase_idx': pipeline.current_phase_idx,
        'forecast_lead_time': pipeline.forecast_lead_time,
        'scheduler_state_dict': pipeline.scheduler.state_dict()
    }

    os.makedirs(pipeline.model_save_path, exist_ok=True)
    # 固定间隔保存
    if epoch % pipeline.checkpoint_save_interval == 0:
        checkpoint_path = os.path.join(pipeline.model_save_path, f'checkpoint_epoch_{epoch}.pt')
        torch.save(checkpoint, checkpoint_path)
        print(f"Checkpoint saved at epoch {epoch} to {checkpoint_path}")

    # 保存最佳模型
    if is_best:
        best_checkpoint_path = os.path.join(pipeline.model_save_path, 'best_model_checkpoint.pt')
        torch.save(checkpoint, best_checkpoint_path)
        print(f"Best model checkpoint saved at epoch {epoch} to {best_checkpoint_path}")

def load_checkpoint(pipeline, checkpoint_path):
    checkpoint = torch.load(checkpoint_path)
    pipeline.target_model.load_state_dict(checkpoint['model_state_dict'])
    pipeline.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    pipeline.best_val_bp_loss = checkpoint['best_val_bp_loss']
    pipeline.no_improve_epochs = checkpoint['no_improve_epochs']
    pipeline.loss_train = checkpoint['loss_train']
    pipeline.loss_cv = checkpoint['loss_cv']
    pipeline.current_phase_idx = checkpoint['current_phase_idx']
    pipeline.forecast_lead_time = checkpoint['forecast_lead_time']
    pipeline.train_start_time = checkpoint['train_start_time']
    torch.set_rng_state(checkpoint['torch_random_state'])
    # 如果保存了 CUDA 随机状态
    if torch.cuda.is_available() and 'torch_cuda_random_state' in checkpoint:
        torch.cuda.set_rng_state(checkpoint['torch_cuda_random_state'])
    return checkpoint['epoch']