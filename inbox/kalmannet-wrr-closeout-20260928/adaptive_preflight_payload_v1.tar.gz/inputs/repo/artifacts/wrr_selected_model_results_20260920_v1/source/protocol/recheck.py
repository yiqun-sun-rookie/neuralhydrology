"""One authorized validation-only pass over 11 immutable saved filters.

Model/inference code is copied byte-for-byte and imported from the copy.
No training/test dataset, backward pass, optimizer update, or source overwrite.
"""
from __future__ import annotations

import hashlib
import importlib.abc
import importlib.machinery
import importlib.metadata
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
ORIGINAL = Path('G:/github/pycharm/projects/kalmannet').resolve()
FILTERS = Path('G:/github/pycharm/projects/filters').resolve()
PRIOR = ORIGINAL / 'experiments/optimize_hyper_parameters/wrr_hp_extension_20260902/rescoring/ukf_lr_grid_rescore.json'
EVALUATOR_REL = Path('experiments/optimize_hyper_parameters/wrr_hp_extension_20260902/rescore_ukf_lr_grid.py')
VALIDATION = ORIGINAL / 'data/processed/high_flow_aug/val_win800_20070527_04-20090314_13.pt'
VALIDATION_HASH = '2e195fc974b5cc8cdb35df3cb7fd72a202af033ecc415acc03a87020b00bd403'
PRIOR_HASH = '41ab003fbec96d9c8d298f18c961d1d305dd2c04d16b6d728fb4450e5e54b27d'
PREFLIGHT = '--preflight' in sys.argv
RUN = HERE / ('preflight_003' if PREFLIGHT else 'run_001')


def checked_input(path, allowed):
    if not isinstance(path, (str, os.PathLike)):
        raise PermissionError('Only registered path-based input is allowed')
    resolved = Path(path).resolve()
    if resolved not in allowed:
        raise PermissionError(f'Unregistered tensor input: {resolved}')
    return resolved


def is_null_device(path):
    # Windows NUL is a sink, not an on-disk output. Do not allow other devices.
    return os.fsdecode(path).lower() in {os.devnull.lower(), '\\\\.\\nul', '\\\\.\\nul\\'}


def pooled_scores(count, sy, sy2, sse):
    if not len(count) or not (len(count) == len(sy) == len(sy2) == len(sse)):
        raise ValueError('Sufficient-statistic vector lengths differ or are empty')
    result = []
    for n, s, s2, err in zip(count, sy, sy2, sse):
        if not all(math.isfinite(float(v)) for v in (n, s, s2, err)) or n < 2 or err < 0:
            raise ValueError('Invalid sufficient statistics')
        denominator = s2 - s * s / n
        if denominator <= 0:
            raise ValueError('Nonpositive observation variance')
        result.append(float(1 - err / denominator))
    return result


def primary_score(scores):
    if len(scores) != 13 or not all(math.isfinite(float(x)) for x in scores):
        raise ValueError('Expected thirteen finite positions: analysis plus hours 1..12')
    return math.fsum(float(x) for x in scores[1:13]) / 12


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def now():
    return time.strftime('%Y-%m-%dT%H:%M:%S%z')


class SnapshotOnlyFinder(importlib.abc.MetaPathFinder):
    def __init__(self, roots, records):
        self.roots = roots
        self.records = records
        self.imports = {}

    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] not in {'knet', 'hydrologic', 'experiments', 'filters'}:
            return None
        spec = importlib.machinery.PathFinder.find_spec(fullname, path)
        if spec is None:
            raise ImportError(f'Project module missing from frozen snapshot: {fullname}')
        if spec.origin is None:
            locations = [Path(p).resolve() for p in spec.submodule_search_locations or []]
            if not locations or not all(any(p.is_relative_to(r) for r in self.roots) for p in locations):
                raise ImportError(f'Namespace outside frozen source: {fullname}')
            return spec
        origin = Path(spec.origin).resolve()
        record = self.records.get(str(origin))
        if record is None or sha(origin) != record['sha256']:
            raise ImportError(f'Unsealed or changed project import: {fullname}: {origin}')
        self.imports[fullname] = str(origin)
        return spec


def install_file_guard(allowed):
    def audit(event, args):
        if event == 'open':
            filename, mode, flags = args
            if not isinstance(filename, (str, bytes, os.PathLike)):
                return
            if is_null_device(filename):
                return
            path = Path(os.fsdecode(filename)).resolve()
            writing = (isinstance(mode, str) and any(c in mode for c in 'wax+')) or (
                isinstance(flags, int) and bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)))
            if writing and not path.is_relative_to(RUN):
                raise PermissionError(f'Write outside isolated run: {path}')
            if not writing and any(path.is_relative_to(p) for p in (ORIGINAL, FILTERS)):
                if path.suffix.lower() in {'.pt', '.pth', '.pkl', '.pickle', '.npy', '.npz'}:
                    checked_input(path, allowed)
        elif event in {'os.mkdir', 'os.remove', 'os.rmdir', 'os.chmod', 'os.utime'}:
            if isinstance(args[0], (str, bytes, os.PathLike)):
                path = Path(os.fsdecode(args[0])).resolve()
                if not path.is_relative_to(RUN):
                    raise PermissionError(f'Filesystem mutation outside run: {event}: {path}')
        elif event in {'os.rename', 'os.link', 'os.symlink'}:
            for item in args[:2]:
                if isinstance(item, (str, bytes, os.PathLike)):
                    if not Path(os.fsdecode(item)).resolve().is_relative_to(RUN):
                        raise PermissionError(f'Filesystem mutation outside run: {event}')
    sys.addaudithook(audit)


def snapshot_sources():
    source_roots = {'kalmannet': ORIGINAL, 'filters': FILTERS}
    paths = set()
    for package in ('knet', 'hydrologic'):
        paths.update(('kalmannet', p) for p in (ORIGINAL / package).rglob('*.py') if '__pycache__' not in p.parts)
    paths.update(('filters', p) for p in (FILTERS / 'filters').rglob('*.py') if '__pycache__' not in p.parts)
    paths.add(('filters', FILTERS / 'filters/filter/non_batch/dapper/dapper/dpr_config.yaml'))
    for relative in ('experiments/__init__.py', 'experiments/optimize_hyper_parameters/__init__.py',
                     'experiments/optimize_hyper_parameters/train_and_eval.py', str(EVALUATOR_REL)):
        path = ORIGINAL / relative
        if path.is_file():
            paths.add(('kalmannet', path))
    records = {}
    for project, path in sorted(paths, key=lambda item: (item[0], str(item[1]))):
        destination = RUN / 'source' / project / path.relative_to(source_roots[project])
        destination.parent.mkdir(parents=True, exist_ok=True)
        before = sha(path)
        shutil.copyfile(path, destination)
        if sha(destination) != before or sha(path) != before:
            raise RuntimeError(f'Source changed while snapshotting: {path}')
        records[str(destination.resolve())] = {'original': str(path), 'snapshot': str(destination), 'sha256': before}
    for path in (Path(__file__), HERE / 'test_recheck.py', HERE / 'runtime_dpr_config.yaml', HERE.parent / 'docs/superpowers/plans/2026-09-14-learned-noise-validation-recheck.md'):
        destination = RUN / 'protocol_sources' / path.name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
    write_json(RUN / 'source_manifest.json', list(records.values()))
    return records


def main():
    if RUN.exists():
        raise RuntimeError(f'Output already exists; no overwrite or automatic retry: {RUN}')
        RUN.mkdir(parents=True)
    state = {'status': 'PREPARING', 'started_at': now(), 'cases': [], 'load_ledger': [],
             'forbidden_operation_attempts': [], 'authorization': 'User go: 11 existing models, validation only; no training/test/manuscript changes'}
    write_json(RUN / 'status.json', state)
    try:
        if sha(PRIOR) != PRIOR_HASH:
            raise RuntimeError('Prior candidate registry hash differs from audited record')
        prior = json.loads(PRIOR.read_text(encoding='utf-8'))
        prior_rows = prior['results']
        if len(prior_rows) != 11 or len({r['checkpoint'] for r in prior_rows}) != 11:
            raise RuntimeError('Expected exactly eleven distinct registered checkpoints')
        allowed = {VALIDATION.resolve()} | {Path(r['checkpoint']).resolve() for r in prior_rows}
        for name in ('TEMP', 'TMP', 'TORCH_HOME', 'TORCH_EXTENSIONS_DIR', 'MPLCONFIGDIR', 'XDG_CACHE_HOME', 'NUMBA_CACHE_DIR'):
            destination = RUN / 'runtime_cache' / name.lower()
            destination.mkdir(parents=True, exist_ok=True)
            os.environ[name] = str(destination)
        os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
        os.environ['PYTHONUTF8'] = '1'
        sys.dont_write_bytecode = True
        install_file_guard(allowed)
        sources = snapshot_sources()
        shutil.copyfile(HERE / 'runtime_dpr_config.yaml', RUN / 'dpr_config.yaml')
        os.chdir(RUN)
        protected = [PRIOR, ORIGINAL / 'draft/latex/manuscript_24h.tex',
                     Path('C:/Users/yiqun/Downloads/WRR_2026WR044505_revised_clean_HM.docx'),
                     Path('C:/Users/yiqun/Downloads/WRR_2026WR044505_revised_clean_HM_agreed_edits.docx')]
        protected_hashes = {str(p): sha(p) for p in protected}
        if sha(VALIDATION) != VALIDATION_HASH:
            raise RuntimeError('Validation input hash mismatch')
        registry = []
        for index, row in enumerate(prior_rows, 1):
            checkpoint = Path(row['checkpoint']).resolve()
            if sha(checkpoint) != row['checkpoint_sha256']:
                raise RuntimeError(f'Checkpoint changed since previous record: {checkpoint}')
            cfg_path = Path(row['config_used']).resolve()
            cfg_copy = RUN / 'configs' / f'case_{index:02d}_original.yaml'
            cfg_copy.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(cfg_path, cfg_copy)
            registry.append({'case_id': f'case_{index:02d}', 'run_dir': row['run_dir'], 'checkpoint': str(checkpoint),
                             'checkpoint_sha256': row['checkpoint_sha256'], 'original_config': str(cfg_path),
                             'config_snapshot': str(cfg_copy), 'config_sha256': sha(cfg_copy),
                             'prior_score': row['pooled_mean_slots_1_12_corrected_def'], 'status': 'PENDING'})
        write_json(RUN / 'registry.json', registry)
        shutil.copyfile(PRIOR, RUN / 'prior_results.json')
        frozen_project = (RUN / 'source/kalmannet').resolve()
        frozen_filters = (RUN / 'source/filters').resolve()
        # The original helper conditionally inserts this literal external path.
        # Keeping it present but after the snapshot prevents that insertion;
        # SnapshotOnlyFinder also refuses every original project-source import.
        sys.path[:] = [str(frozen_project), str(frozen_filters), str(FILTERS)] + [
            p for p in sys.path if p and Path(p).resolve() not in {ORIGINAL, FILTERS, HERE.parent}]
        finder = SnapshotOnlyFinder((frozen_project, frozen_filters), sources)
        sys.meta_path.insert(0, finder)
        import numpy as np
        import torch
        import yaml
        if torch.__version__ != '2.4.0' or not torch.cuda.is_available():
            raise RuntimeError(f'Expected available CUDA in torch 2.4.0, found {torch.__version__}')
        original_torch_load = torch.load

        def guarded_load(path, *args, **kwargs):
            checked = checked_input(path, allowed)
            state['load_ledger'].append({'path': str(checked), 'time': now()})
            return original_torch_load(checked, *args, **kwargs)

        torch.load = guarded_load

        def forbidden(name):
            def blocked(*args, **kwargs):
                state['forbidden_operation_attempts'].append(name)
                raise RuntimeError(f'Forbidden operation: {name}')
            return blocked

        torch.optim.AdamW.step = forbidden('AdamW.step')
        torch.Tensor.backward = forbidden('Tensor.backward')
        torch.autograd.backward = forbidden('autograd.backward')
        torch.set_grad_enabled(False)
        torch.manual_seed(42)
        evaluator_path = frozen_project / EVALUATOR_REL
        spec = importlib.util.spec_from_file_location('frozen_validation_evaluator', evaluator_path)
        evaluator = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = evaluator
        spec.loader.exec_module(evaluator)
        evaluator.Pipeline.train = forbidden('Pipeline.train')
        evaluator.VAL_PT = VALIDATION
        evaluator.OUT_DIR = RUN / 'evaluation_outputs'
        evaluator.OUT_DIR.mkdir()
        evaluator.PAPER_UKF = Path(next(r['checkpoint'] for r in prior_rows if r['is_paper_checkpoint']))
        case_by_name = {r['run_dir']: r for r in registry}
        evaluator.find_ckpt = lambda directory: Path(case_by_name[directory.name]['checkpoint'])

        def frozen_config(directory):
            row = case_by_name[directory.name]
            cfg = yaml.safe_load(Path(row['config_snapshot']).read_text(encoding='utf-8'))
            cfg['model']['type'] = 'trainable_ukf'
            cfg['data']['base_path'] = str(RUN / 'evaluation_outputs' / row['case_id'])
            cfg['data']['dataset_path'] = {'val': str(VALIDATION)}
            cfg['training']['forecast_lead_time'] = 13
            cfg['dataloader']['batch_size'] = 2048
            cfg['runtime']['device'] = 'cuda'
            if cfg['model']['trainable_ukf'].get('adapt_online', False):
                raise RuntimeError('Online noise adaptation is outside this fixed-weight comparison')
            effective = RUN / 'configs' / f"{row['case_id']}_evaluation.json"
            write_json(effective, cfg)
            return cfg, str(effective)

        evaluator.load_cfg = frozen_config
        live = {}
        original_builder = evaluator.build_trainable_kf

        def frozen_builder(*args, **kwargs):
            model = original_builder(*args, **kwargs)
            original_load_state = model.load_state_dict

            def load_state(sd, *a, **k):
                result = original_load_state(sd, *a, **k)
                for parameter in model.parameters():
                    parameter.requires_grad_(False)
                live['before_weights'] = {name: tensor.detach().cpu().clone() for name, tensor in model.state_dict().items()}
                return result

            model.load_state_dict = load_state
            live['model'] = model
            return model

        evaluator.build_trainable_kf = frozen_builder
        original_epoch = evaluator.run_one_epoch

        def validation_epoch(*args, **kwargs):
            if kwargs.get('is_training') is not False:
                return forbidden('training_epoch')()
            return original_epoch(*args, **kwargs)

        evaluator.run_one_epoch = validation_epoch
        old_acc = evaluator.Acc

        class CheckedAccumulator(old_acc):
            def __init__(self, length):
                super().__init__(length)
                self.batch_count = 0
                live['accumulator'] = self

            def update(self, data):
                observations = data['y_obs_win']
                predictions = data['outputs_fc_win']
                if observations.shape != predictions.shape or predictions.shape[-1] != 13:
                    raise RuntimeError('Prediction/observation shape or lead count differs')
                if not torch.isfinite(observations).all() or not torch.isfinite(predictions).all():
                    raise RuntimeError('Nonfinite validation pair; no silent exclusion allowed')
                times = data['tm_hours_win']
                offsets = times[..., 1:] - times[..., :1]
                if not torch.all(offsets == torch.arange(1, 13, device=times.device)):
                    raise RuntimeError('Forecast observation windows are not hourly aligned')
                super().update(data)
                self.batch_count += 1

        evaluator.Acc = CheckedAccumulator
        environment = {'python': sys.version, 'executable': sys.executable, 'torch': torch.__version__,
                       'working_directory': str(Path.cwd()), 'filesystem_only_dependency_override_sha256': sha(RUN / 'dpr_config.yaml'),
                       'numpy': np.__version__, 'cuda': torch.version.cuda, 'cudnn': torch.backends.cudnn.version(),
                       'device': torch.cuda.get_device_name(0), 'cudnn_benchmark': torch.backends.cudnn.benchmark,
                       'matmul_precision': torch.get_float32_matmul_precision(), 'evaluation_seed': 42,
                       'packages': sorted([{'name': d.metadata.get('Name', ''), 'version': d.version}
                                           for d in importlib.metadata.distributions()], key=lambda d: d['name'].lower()),
                       'environment': {key: os.environ.get(key) for key in ('CUDA_VISIBLE_DEVICES', 'KNET_FORECAST_LEADS_START_AT_ONE',
                                       'NO_TQDM', 'VALIDATION_QUIET', 'PERF_INTERVAL', 'EPOCH_SUMMARY', 'KMP_DUPLICATE_LIB_OK')}}
        write_json(RUN / 'environment.json', environment)
        write_json(RUN / 'protected_hashes_before.json', protected_hashes)
        if PREFLIGHT:
            # No data/checkpoint deserialization or real-model inference here.
            # Exercise lazy project imports and the unmodified forecast indexing.
            from types import SimpleNamespace
            from knet.modules.pipeline.core_fun import system_model_forecast
            toy = SimpleNamespace(m=1, h=lambda x: x, f=lambda x, u: x + 1)
            zeros = torch.zeros((1, 1, 15))
            _, toy_forecasts = system_model_forecast(toy, zeros, zeros, zeros, lead_time=13)
            if not torch.equal(toy_forecasts[0, 0], torch.arange(13, dtype=zeros.dtype)):
                raise RuntimeError('Synthetic lead-position check failed')
            for row in registry:
                cfg, _ = frozen_config(Path(row['run_dir']))
                sample = torch.zeros(800)
                args = evaluator.build_args(cfg, sample, sample)
                args.device = 'cuda'
                system = evaluator._init_mod.initialize_system_model(args.train_seq_len, args.seq_len_val, device='cuda')
                model = frozen_builder(cfg, system, args)
                if sum(p.numel() for p in model.parameters()) != 6:
                    raise RuntimeError('Expected six learned noise parameters')
                del model, system
                live.clear()
            write_json(RUN / 'import_ledger.json', finder.imports)
            state.update({'status': 'PREFLIGHT_PASS', 'finished_at': now(), 'tensor_loads': len(state['load_ledger']),
                          'synthetic_lead_mapping': 'position 0=current; positions 1..12=future hours 1..12',
                          'eleven_configurations_constructed_without_loading_weights': True})
            write_json(RUN / 'status.json', state)
            print('PREFLIGHT_PASS no validation/model tensor loaded; 11 configurations constructed', flush=True)
            return
        dataset = evaluator.torch.load(VALIDATION, map_location='cpu', weights_only=False)
        loader = evaluator.DataLoader(dataset, batch_size=2048, shuffle=False, num_workers=0)
        state['status'] = 'RUNNING'
        state['validation_dataset_length'] = len(dataset)
        state['validation_sha256'] = VALIDATION_HASH
        write_json(RUN / 'status.json', state)
        for index, row in enumerate(registry, 1):
            state['current_case'] = row['case_id']
            row['status'] = 'RUNNING'
            write_json(RUN / 'registry.json', registry)
            write_json(RUN / 'status.json', state)
            print(f"START {index}/11 {row['run_dir']}", flush=True)
            if sha(row['checkpoint']) != row['checkpoint_sha256']:
                raise RuntimeError('Checkpoint changed before evaluation')
            result = evaluator.evaluate(Path(row['run_dir']), dataset, loader)
            after_weights = live['model'].state_dict()
            before_weights = live['before_weights']
            unchanged = set(after_weights) == set(before_weights) and all(
                torch.equal(after_weights[name].detach().cpu(), before_weights[name]) for name in before_weights)
            if not unchanged:
                raise RuntimeError('Model parameters changed during evaluation')
            acc = live['accumulator']
            stats = {'count': acc.n.tolist(), 'observation_sum': acc.sy.tolist(),
                     'observation_square_sum': acc.sy2.tolist(), 'squared_error_sum': acc.sse.tolist()}
            scores = pooled_scores(stats['count'], stats['observation_sum'], stats['observation_square_sum'], stats['squared_error_sum'])
            score = primary_score(scores)
            if abs(score - result['pooled_mean_slots_1_12_corrected_def']) > 0.0000006:
                raise RuntimeError('Primary score disagrees with reused evaluator')
            result.update({'case_id': row['case_id'], 'status': 'COMPLETE', 'sufficient_statistics': stats,
                           'nse_per_position_full_precision': scores, 'primary_score': score,
                           'parameters_unchanged': unchanged, 'validation_batches': acc.batch_count,
                           'difference_from_prior_rounded_score': score - row['prior_score'],
                           'completed_at': now()})
            write_json(RUN / 'cases' / f"{row['case_id']}.json", result)
            row.update({'status': 'COMPLETE', 'primary_score': score})
            state['cases'].append({'case_id': row['case_id'], 'lr': result['lr'], 'primary_score': score})
            write_json(RUN / 'registry.json', registry)
            write_json(RUN / 'status.json', state)
            write_json(RUN / 'import_ledger.json', finder.imports)
            print(f"DONE {index}/11 lr={result['lr']} score={score:.12f} unchanged={unchanged}", flush=True)
            live.clear()
            torch.cuda.empty_cache()
        inputs_unchanged = sha(VALIDATION) == VALIDATION_HASH and all(sha(r['checkpoint']) == r['checkpoint_sha256'] for r in registry)
        configs_unchanged = all(sha(r['original_config']) == r['config_sha256'] for r in registry)
        snapshots_unchanged = all(sha(path) == record['sha256'] for path, record in sources.items())
        imported_originals_unchanged = all(sha(sources[path]['original']) == sources[path]['sha256'] for path in set(finder.imports.values()))
        protected_after = {str(p): sha(p) for p in protected}
        write_json(RUN / 'protected_hashes_after.json', protected_after)
        load_paths = [entry['path'] for entry in state['load_ledger']]
        all_cases = [json.loads((RUN / 'cases' / f"{row['case_id']}.json").read_text(encoding='utf-8')) for row in registry]
        counts_equal = len({tuple(case['sufficient_statistics']['count']) for case in all_cases}) == 1
        checks = {'eleven_completed': len(state['cases']) == 11,
                  'exactly_twelve_permitted_loads': len(load_paths) == 12 and set(load_paths) == {str(p) for p in allowed},
                  'no_training_attempts': not state['forbidden_operation_attempts'], 'equal_validation_counts': counts_equal,
                  'input_files_unchanged': inputs_unchanged, 'configs_unchanged': configs_unchanged,
                  'source_snapshot_unchanged': snapshots_unchanged, 'imported_original_sources_unchanged': imported_originals_unchanged,
                  'manuscripts_and_prior_results_unchanged': protected_after == protected_hashes,
                  'all_model_parameters_unchanged': all(c['parameters_unchanged'] for c in all_cases)}
        ranking = sorted(all_cases, key=lambda r: (-r['primary_score'], r['case_id']))
        compact_ranking = [{'rank': index, 'case_id': row['case_id'], 'run_dir': row['run_dir'], 'learning_rate': row['lr'],
                            'score': row['primary_score'], 'checkpoint': row['checkpoint'], 'checkpoint_sha256': row['checkpoint_sha256'],
                            'is_current_paper_model': row['is_paper_checkpoint']} for index, row in enumerate(ranking, 1)]
        write_json(RUN / 'ranking.json', compact_ranking)
        write_json(RUN / 'acceptance.json', checks)
        if not all(checks.values()):
            raise RuntimeError(f'Acceptance checks failed: {checks}')
        state.update({'status': 'COMPLETE', 'finished_at': now(), 'acceptance': checks, 'winner': compact_ranking[0]})
        write_json(RUN / 'status.json', state)
        print('COMPLETE all acceptance checks passed', flush=True)
    except BaseException as exc:
        state.update({'status': 'FAILED', 'failed_at': now(), 'error': f'{type(exc).__name__}: {exc}', 'traceback': traceback.format_exc()})
        write_json(RUN / 'status.json', state)
        print(state['traceback'], flush=True)
        raise


if __name__ == '__main__':
    main()
