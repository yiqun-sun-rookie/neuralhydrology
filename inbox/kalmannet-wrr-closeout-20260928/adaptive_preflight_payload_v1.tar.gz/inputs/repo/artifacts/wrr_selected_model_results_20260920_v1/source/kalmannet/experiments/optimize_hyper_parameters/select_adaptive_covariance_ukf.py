#!/usr/bin/env python3
"""Select the Regge adaptive-covariance baseline on validation data only.

The script deliberately has no command-line option for changing the dataset
role. It uses the validation dataset pinned in the YAML contract, records all
candidate scores, and writes one immutable JSON selection manifest.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import importlib
import inspect
import json
import math
import os
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping

import torch
import torch.nn as nn
import yaml
from torch.utils.data import DataLoader


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from experiments.optimize_hyper_parameters.train_and_eval import build_args
from knet.pipelines.pipeline_clean_based_on_11 import Pipeline
from knet.pipelines.train_clean_based_on_11 import initialize_training, run_one_epoch
from knet.utils.model_initialization_use_script_mdl_1 import initialize_system_model


CONFIG_SCHEMA_VERSION = "regge_adaptive_covariance_ukf_v1"
SELECTION_SCHEMA_VERSION = "regge_adaptive_covariance_selection_v1"
CORE_MODULE = "src.shared.adaptive_covariance_ukf"
PIPELINE_CONTRACT = {
    "build_args": (
        "experiments.optimize_hyper_parameters.train_and_eval.build_args"
    ),
    "epoch_runner": "knet.pipelines.train_clean_based_on_11.run_one_epoch",
    "batch_runner": "knet.pipelines.train_clean_based_on_11.run_one_batch",
    "forecast_runner": "knet.modules.pipeline.core_fun.system_model_forecast",
    "selection_lead_hours": 12,
    "final_lead_hours": 48,
    "final_report_hours": list(range(1, 25)),
    "metric_definition": "draft/scripts/generate_paper_metrics.py",
    "batch_statistics_schema": "regge_adaptive_covariance_batch_stats_v1",
}
REQUIRED_CORE_API = {
    "module": CORE_MODULE,
    "config_class": "AdaptiveNoiseConfig",
    "filter_class": "InnovationCorrelationAdaptiveUKF",
    "filter_methods": ["reset", "step", "diagnostics"],
}
_REQUIRED_DECLARED_NUMERICS = (
    "q_min",
    "q_max",
    "r_min",
    "r_max",
    "denominator_epsilon",
    "pinv_rtol",
    "covariance_epsilon",
)
INDEPENDENT_GATE_MANIFEST_PATH = (
    "artifacts/adaptive_covariance_validation_v2/manifest.sha256.json"
)
INDEPENDENT_GATE_MANIFEST_SHA256 = (
    "7a55861b1d3de64e98d585733b0b182bf4a127ab0a282bbaf17de082c71144e0"
)
INDEPENDENT_GATE_SUMMARY_PATH = (
    "artifacts/adaptive_covariance_validation_v2/summary.json"
)
INDEPENDENT_GATE_SUMMARY_SHA256 = (
    "daa172d2c43a295b05119313e44eaea969a31e4cd0140dafa4ed38a6bcfcb264"
)
INDEPENDENT_GATE_ELIGIBLE_SCALES = [50, 100]


def sha256_file(path: Path | str) -> str:
    """Return the SHA-256 digest of the exact bytes at *path*."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_yaml(path: Path | str) -> dict[str, Any]:
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("configuration root must be a mapping")
    return payload


def _load_json_mapping(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"JSON root must be a mapping: {path}")
    return payload


def validate_independent_gate_payloads(
    *,
    manifest: Mapping[str, Any],
    summary: Mapping[str, Any],
    eligible_scales: Iterable[int],
    selection_grid: Iterable[int],
    expected_summary_sha256: str,
) -> None:
    """Validate the pinned synthetic gate without opening hydrological data."""
    if manifest.get("experiment_id") != "adaptive_covariance_validation_v2":
        raise RuntimeError("independent numerical gate has an unexpected experiment id")
    summary_record = manifest.get("artifacts", {}).get("summary", {})
    if str(summary_record.get("sha256", "")).lower() != (
        expected_summary_sha256.lower()
    ):
        raise RuntimeError("gate manifest does not authenticate the configured summary")
    if summary.get("experiment_id") != "adaptive_covariance_validation_v2":
        raise RuntimeError("gate summary has an unexpected experiment id")
    if summary.get("status") != "passed":
        raise RuntimeError("independent numerical gate status is not passed")
    if float(summary.get("selected_stationarity_scale", float("nan"))) != 50.0:
        raise RuntimeError("independent numerical gate did not select scale 50")

    candidates = summary.get("candidates")
    if not isinstance(candidates, list) or not candidates:
        raise RuntimeError("independent numerical gate candidates are missing")
    seen_scales: set[float] = set()
    passed_scales: set[float] = set()
    for candidate in candidates:
        if not isinstance(candidate, Mapping):
            raise RuntimeError("independent numerical gate candidate is malformed")
        scale = float(candidate.get("stationarity_scale", float("nan")))
        if not math.isfinite(scale) or scale <= 0 or scale in seen_scales:
            raise RuntimeError("independent numerical gate candidate scales are invalid")
        seen_scales.add(scale)
        if candidate.get("passed") is True:
            passed_scales.add(scale)
    expected_eligible = {float(value) for value in eligible_scales}
    if passed_scales != expected_eligible or passed_scales != {50.0, 100.0}:
        raise RuntimeError("only stationarity scales 50 and 100 may pass the gate")
    configured_grid = {float(value) for value in selection_grid}
    if not configured_grid or not configured_grid.issubset(passed_scales):
        raise RuntimeError("hydrological selection grid exceeds gate-eligible scales")


def verify_independent_numerical_gate(
    config: Mapping[str, Any], project_root: Path = PROJECT_ROOT
) -> dict[str, Any]:
    """Authenticate and inspect v2 evidence before validation-data access."""
    selection = config.get("selection", {})
    gate = selection.get("independent_numerical_gate", {})
    manifest_path = (project_root / str(gate.get("manifest_path", ""))).resolve()
    summary_path = (project_root / str(gate.get("summary_path", ""))).resolve()
    for label, path in (("manifest", manifest_path), ("summary", summary_path)):
        if not path.is_file():
            raise FileNotFoundError(f"independent numerical gate {label} is missing: {path}")
    manifest_sha256 = sha256_file(manifest_path)
    summary_sha256 = sha256_file(summary_path)
    if manifest_sha256.lower() != str(gate.get("manifest_sha256", "")).lower():
        raise RuntimeError("independent numerical gate manifest SHA-256 mismatch")
    if summary_sha256.lower() != str(gate.get("summary_sha256", "")).lower():
        raise RuntimeError("independent numerical gate summary SHA-256 mismatch")
    manifest = _load_json_mapping(manifest_path)
    summary = _load_json_mapping(summary_path)
    summary_record = manifest.get("artifacts", {}).get("summary", {})
    manifest_summary_path = (
        manifest_path.parent / str(summary_record.get("path", ""))
    ).resolve()
    if _normalized_path(manifest_summary_path) != _normalized_path(summary_path):
        raise RuntimeError("gate manifest points to a different summary file")
    validate_independent_gate_payloads(
        manifest=manifest,
        summary=summary,
        eligible_scales=gate.get("eligible_stationarity_scales", []),
        selection_grid=selection.get("stationarity_scale_grid", []),
        expected_summary_sha256=summary_sha256,
    )
    return {
        "status": "verified",
        "manifest_path": str(manifest_path),
        "manifest_sha256": manifest_sha256,
        "summary_path": str(summary_path),
        "summary_sha256": summary_sha256,
        "summary_status": summary["status"],
        "selected_stationarity_scale": summary["selected_stationarity_scale"],
        "eligible_stationarity_scales": list(
            gate["eligible_stationarity_scales"]
        ),
    }


def _normalized_path(path: Path) -> str:
    return os.path.normcase(str(path.resolve(strict=False)))


def resolve_dataset_path(
    config: Mapping[str, Any], role: str, project_root: Path = PROJECT_ROOT
) -> Path:
    datasets = config.get("data", {}).get("datasets", {})
    if role not in datasets:
        raise ValueError(f"dataset role is not configured: {role}")
    raw_path = Path(str(datasets[role]["path"]))
    return (raw_path if raw_path.is_absolute() else project_root / raw_path).resolve()


def assert_selection_dataset_allowed(
    config: Mapping[str, Any],
    role: str,
    candidate_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> Path:
    """Enforce that selection can open the configured validation file only."""
    if role != "validation":
        raise ValueError("selection is restricted to the validation dataset only")
    expected_validation = resolve_dataset_path(config, "validation", project_root)
    configured_test = resolve_dataset_path(config, "test", project_root)
    candidate = Path(candidate_path).resolve(strict=False)
    if _normalized_path(candidate) == _normalized_path(configured_test):
        raise ValueError("selection cannot access the configured test dataset")
    if _normalized_path(candidate) != _normalized_path(expected_validation):
        raise ValueError("selection path is not the configured validation dataset")
    return expected_validation


def require_selection_dataset(
    config: Mapping[str, Any], project_root: Path = PROJECT_ROOT
) -> Path:
    selection = config.get("selection", {})
    role = str(selection.get("dataset_role", ""))
    candidate = resolve_dataset_path(config, role, project_root)
    return assert_selection_dataset_allowed(config, role, candidate, project_root)


def validate_config(
    config: Mapping[str, Any], *, require_declared_bounds: bool
) -> None:
    """Validate immutable data, method, and evaluation-contract fields."""
    if config.get("schema_version") != CONFIG_SCHEMA_VERSION:
        raise ValueError(f"schema_version must be {CONFIG_SCHEMA_VERSION}")
    if config.get("experiment", {}).get("id") != "REGGE_ACUKF_B01":
        raise ValueError("experiment.id must be REGGE_ACUKF_B01")
    if config.get("model", {}).get("type") != "trainable_ukf":
        raise ValueError("model.type must remain trainable_ukf for legacy build_args")
    if config.get("model", {}).get("integration_adapter") != (
        "innovation_correlation_adaptive_ukf"
    ):
        raise ValueError("unexpected adaptive integration adapter")
    if config.get("selection", {}).get("dataset_role") != "validation":
        raise ValueError("selection.dataset_role must be validation")
    if config.get("final_evaluation", {}).get("dataset_role") != "test":
        raise ValueError("final_evaluation.dataset_role must be test")
    if config.get("training", {}).get("forecast_lead_time") != 12:
        raise ValueError("selection forecast horizon must be 12 hours")
    if config.get("final_evaluation", {}).get("forecast_lead_time") != 48:
        raise ValueError("final evaluation must run 48 hours for H1-H24 parity")
    if config.get("final_evaluation", {}).get("report_horizons") != list(
        range(1, 25)
    ):
        raise ValueError("final report horizons must be exactly H1-H24")
    final_evaluation = config.get("final_evaluation", {})
    if final_evaluation.get("metric_definition") != (
        "draft/scripts/generate_paper_metrics.py"
    ):
        raise ValueError("unexpected final metric definition")
    if final_evaluation.get("catchment_area_km2") != 957:
        raise ValueError("final catchment area must be 957 km2")
    if final_evaluation.get("save_batch_sufficient_statistics") is not True:
        raise ValueError("batch sufficient statistics must be saved")
    if final_evaluation.get("sufficient_statistics_filename") != (
        "batch_sufficient_statistics.npz"
    ):
        raise ValueError("unexpected sufficient-statistics filename")
    if final_evaluation.get("regime_quantiles") != (
        "exact_disk_backed_first_pass"
    ):
        raise ValueError("flow-regime quantiles must use the exact disk-backed pass")
    if final_evaluation.get("regime_boundaries") != {
        "low": "observed < Q25",
        "mid": "Q25 <= observed <= Q75",
        "high": "observed > Q75",
    }:
        raise ValueError("flow-regime boundaries do not match the formal generator")
    if final_evaluation.get("save_adaptive_diagnostics") is not True:
        raise ValueError("adaptive diagnostics must be saved")
    if final_evaluation.get("save_full_adaptive_histories") is not False:
        raise ValueError("full adaptive histories must remain disabled")
    if final_evaluation.get("save_raw_predictions") is not False:
        raise ValueError("raw prediction tensors must not be saved")
    if config.get("selection", {}).get("stationarity_scale_grid") != [
        50,
        100,
    ]:
        raise ValueError("stationarity scale grid must be [50, 100]")
    if config.get("selection", {}).get("delta_rule") != (
        "reciprocal_stationarity_scale_for_enabled_covariances"
    ):
        raise ValueError(
            "delta rule must be reciprocal_stationarity_scale_for_enabled_covariances"
        )
    independent_gate = config.get("selection", {}).get(
        "independent_numerical_gate", {}
    )
    expected_gate = {
        "manifest_path": INDEPENDENT_GATE_MANIFEST_PATH,
        "manifest_sha256": INDEPENDENT_GATE_MANIFEST_SHA256,
        "summary_path": INDEPENDENT_GATE_SUMMARY_PATH,
        "summary_sha256": INDEPENDENT_GATE_SUMMARY_SHA256,
        "eligible_stationarity_scales": INDEPENDENT_GATE_ELIGIBLE_SCALES,
    }
    if independent_gate != expected_gate:
        raise ValueError("independent numerical gate contract does not match v2 evidence")

    adaptive = config.get("adaptive_covariance", {})
    if adaptive.get("core_module") != CORE_MODULE:
        raise ValueError(f"adaptive core module must be {CORE_MODULE}")
    if adaptive.get("method") != "berry_sauer_2013_innovation_correlation":
        raise ValueError("unexpected adaptive covariance method")
    if adaptive.get("case_study_mode") != (
        "observation_noise_only_fixed_process_covariance"
    ):
        raise ValueError("unexpected case-study adaptive covariance mode")
    if adaptive.get("q_basis") != [0.14, 1.0, 0.004, 1.2, 0.0]:
        raise ValueError("q_basis must equal the Regge hand-tuned diagonal basis")
    if adaptive.get("adapt_q") is not False or adaptive.get("adapt_r") is not True:
        raise ValueError(
            "the Regge baseline must keep Q fixed and adapt observation noise R only"
        )
    if adaptive.get("reset_each_window") is not True:
        raise ValueError("adaptive covariance must reset for every 800-hour window")
    if adaptive.get("adaptation_applies_from_next_step") is not True:
        raise ValueError("the update from time k must first apply at time k+1")

    val_path = resolve_dataset_path(config, "validation", PROJECT_ROOT)
    test_path = resolve_dataset_path(config, "test", PROJECT_ROOT)
    if _normalized_path(val_path) == _normalized_path(test_path):
        raise ValueError("validation and test dataset paths must differ")

    if not require_declared_bounds:
        return
    missing = [name for name in _REQUIRED_DECLARED_NUMERICS if adaptive.get(name) is None]
    if missing:
        joined = ", ".join(missing)
        raise ValueError(
            f"adaptive covariance values must be declared before validation selection: {joined}"
        )
    numeric = {name: float(adaptive[name]) for name in _REQUIRED_DECLARED_NUMERICS}
    if not all(math.isfinite(value) for value in numeric.values()):
        raise ValueError("adaptive covariance numerical limits must be finite")
    if not 0.0 <= numeric["q_min"] < numeric["q_max"]:
        raise ValueError("q bounds must satisfy 0 <= q_min < q_max")
    if not 0.0 < numeric["r_min"] < numeric["r_max"]:
        raise ValueError("r bounds must satisfy 0 < r_min < r_max")
    if (
        numeric["denominator_epsilon"] <= 0.0
        or numeric["pinv_rtol"] <= 0.0
        or numeric["covariance_epsilon"] <= 0.0
    ):
        raise ValueError(
            "denominator_epsilon, pinv_rtol, and covariance_epsilon must be positive"
        )


def validate_core_api(module: Any) -> tuple[type, type]:
    """Validate the shared core without importing it at module import time."""
    config_class = getattr(module, REQUIRED_CORE_API["config_class"], None)
    if not isinstance(config_class, type):
        raise RuntimeError("adaptive core is missing AdaptiveNoiseConfig")
    filter_class = getattr(module, REQUIRED_CORE_API["filter_class"], None)
    if not isinstance(filter_class, type):
        raise RuntimeError(
            "adaptive core is missing InnovationCorrelationAdaptiveUKF"
        )
    for method_name in REQUIRED_CORE_API["filter_methods"]:
        if not callable(getattr(filter_class, method_name, None)):
            raise RuntimeError(f"adaptive core filter is missing {method_name}()")
    return config_class, filter_class


def load_core_api() -> tuple[type, type, Any]:
    try:
        module = importlib.import_module(CORE_MODULE)
    except ImportError as exc:
        raise RuntimeError(
            f"shared adaptive core is unavailable: {CORE_MODULE}"
        ) from exc
    config_class, filter_class = validate_core_api(module)
    return config_class, filter_class, module


def _as_diagonal(values: Iterable[float], device: torch.device | str) -> torch.Tensor:
    return torch.diag(torch.as_tensor(list(values), dtype=torch.float32, device=device))


VALIDATION_ADAPTIVE_COUNTERS = (
    "update_count",
    "q_update_count",
    "r_update_count",
    "skipped_small_denominator_count",
    "q_lower_bound_hits",
    "q_upper_bound_hits",
    "r_lower_bound_hits",
    "r_upper_bound_hits",
)


class ValidationAdaptiveDiagnosticsAccumulator:
    """Summarize every validation batch without retaining adaptive histories."""

    def __init__(self) -> None:
        self.batch_count = 0
        self.sample_count = 0
        self.counter_totals = {name: 0 for name in VALIDATION_ADAPTIVE_COUNTERS}
        self._final_q: list[torch.Tensor] = []
        self._final_r: list[torch.Tensor] = []
        self.minimum_variance = float("inf")
        self.maximum_variance = float("-inf")

    @staticmethod
    def _tensor(value: Any) -> torch.Tensor:
        return torch.as_tensor(value).detach().cpu()

    def append(self, diagnostics: Mapping[str, Any]) -> None:
        q_history = self._tensor(diagnostics["q_after"])
        r_history = self._tensor(diagnostics["r_after"])
        if q_history.ndim < 2 or r_history.ndim < 2:
            raise RuntimeError("adaptive validation histories lack time and batch axes")
        if q_history.shape[0] == 0 or r_history.shape[0] == 0:
            raise RuntimeError("adaptive validation batch contains no updates")
        if not bool(torch.isfinite(q_history).all()) or not bool(
            torch.isfinite(r_history).all()
        ):
            raise RuntimeError("non-finite adaptive q/r diagnostics on validation")
        final_q = q_history[-1].to(torch.float64).reshape(-1)
        final_r = r_history[-1].to(torch.float64).reshape(-1)
        if final_q.shape != final_r.shape:
            raise RuntimeError("adaptive validation q/r batch sizes differ")
        batch_size = int(final_q.numel())
        if batch_size == 0:
            raise RuntimeError("adaptive validation batch is empty")
        for name in VALIDATION_ADAPTIVE_COUNTERS:
            values = self._tensor(diagnostics[name]).reshape(-1)
            if values.numel() != batch_size or not bool(torch.isfinite(values).all()):
                raise RuntimeError(f"invalid adaptive validation counter: {name}")
            if bool((values < 0).any()):
                raise RuntimeError(f"negative adaptive validation counter: {name}")
            self.counter_totals[name] += int(values.to(torch.int64).sum().item())
        minimum = float(self._tensor(diagnostics["minimum_variance"]).item())
        maximum = float(self._tensor(diagnostics["maximum_variance"]).item())
        if not math.isfinite(minimum) or not math.isfinite(maximum):
            raise RuntimeError("non-finite adaptive covariance diagnostic on validation")
        self.minimum_variance = min(self.minimum_variance, minimum)
        self.maximum_variance = max(self.maximum_variance, maximum)
        self._final_q.append(final_q)
        self._final_r.append(final_r)
        self.batch_count += 1
        self.sample_count += batch_size

    @staticmethod
    def _distribution(values: torch.Tensor) -> dict[str, float]:
        quantiles = torch.quantile(
            values, torch.tensor([0.0, 0.25, 0.5, 0.75, 1.0], dtype=values.dtype)
        )
        return {
            "minimum": float(quantiles[0]),
            "q25": float(quantiles[1]),
            "median": float(quantiles[2]),
            "q75": float(quantiles[3]),
            "maximum": float(quantiles[4]),
            "mean": float(values.mean()),
        }

    @staticmethod
    def _rate(
        numerator: int, denominator: int, label: str
    ) -> float | None:
        if denominator <= 0:
            if numerator != 0:
                raise RuntimeError(
                    f"adaptive validation rate has numerator but no denominator: {label}"
                )
            return None
        return float(numerator / denominator)

    def summary(self) -> dict[str, Any]:
        if self.batch_count == 0 or not self._final_q or not self._final_r:
            raise RuntimeError("adaptive validation diagnostics are empty")
        q_values = torch.cat(self._final_q)
        r_values = torch.cat(self._final_r)
        q_updates = self.counter_totals["q_update_count"]
        r_updates = self.counter_totals["r_update_count"]
        q_skips = self.counter_totals["skipped_small_denominator_count"]
        rates = {
            "q_lower_bound_hit_rate_per_q_update": self._rate(
                self.counter_totals["q_lower_bound_hits"], q_updates, "q lower"
            ),
            "q_upper_bound_hit_rate_per_q_update": self._rate(
                self.counter_totals["q_upper_bound_hits"], q_updates, "q upper"
            ),
            "r_lower_bound_hit_rate_per_r_update": self._rate(
                self.counter_totals["r_lower_bound_hits"], r_updates, "r lower"
            ),
            "r_upper_bound_hit_rate_per_r_update": self._rate(
                self.counter_totals["r_upper_bound_hits"], r_updates, "r upper"
            ),
            "small_denominator_skip_rate_per_q_attempt": self._rate(
                q_skips, q_updates + q_skips, "q denominator"
            ),
        }
        return {
            "all_finite": True,
            "batch_count": self.batch_count,
            "sample_count": self.sample_count,
            "counter_totals": dict(self.counter_totals),
            "rates": rates,
            "final_q_scale": self._distribution(q_values),
            "final_r_variance": self._distribution(r_values),
            "minimum_covariance_variance": self.minimum_variance,
            "maximum_covariance_variance": self.maximum_variance,
            "saved_detail": "aggregate counters, rates, and final q/r distributions",
            "not_saved": "full adaptive histories, innovations, gains, and covariance matrices",
        }


class ReggeAdaptiveCovarianceAdapter(nn.Module):
    """Expose the shared adaptive core through the unchanged Regge pipeline API."""

    def __init__(
        self,
        *,
        base_filter: Any,
        system_model: Any,
        adaptive_filter_class: type,
        adaptive_config: Any,
        p0_scale: Iterable[float],
        device: torch.device | str,
    ) -> None:
        super().__init__()
        self.base_filter = base_filter
        self.system_model = system_model
        self.core = adaptive_filter_class(base_filter, adaptive_config)
        self.p0_scale = tuple(float(value) for value in p0_scale)
        self.device = torch.device(device)
        self.batch_size = int(getattr(base_filter, "batch_size", 1))
        self.update_mode = True
        # The legacy Pipeline always creates an optimizer, even for evaluation.
        self._pipeline_parameter = nn.Parameter(torch.zeros(1, device=self.device))
        self._validation_diagnostics: (
            ValidationAdaptiveDiagnosticsAccumulator | None
        ) = None
        self._adaptive_batch_pending = False

    def init_hidden_KNet(self) -> None:
        """No recurrent hidden state is used by this conventional filter."""

    def enable_validation_diagnostics(self) -> None:
        if self._validation_diagnostics is not None:
            raise RuntimeError("validation diagnostics are already enabled")
        self._validation_diagnostics = ValidationAdaptiveDiagnosticsAccumulator()

    def _flush_validation_diagnostics(self) -> None:
        if self._validation_diagnostics is None or not self._adaptive_batch_pending:
            return
        self._validation_diagnostics.append(self.core.diagnostics())
        self._adaptive_batch_pending = False

    def validation_diagnostics_summary(self) -> dict[str, Any]:
        if self._validation_diagnostics is None:
            raise RuntimeError("validation diagnostics were not enabled")
        self._flush_validation_diagnostics()
        return self._validation_diagnostics.summary()

    def init_sequence(self, x0_sequence: torch.Tensor, seq_len: int | None = None) -> None:
        del seq_len
        self._flush_validation_diagnostics()
        x0 = x0_sequence.detach().clone().to(self.device)
        self.batch_size = int(x0.shape[0])
        if hasattr(self.base_filter, "batch_size"):
            self.base_filter.batch_size = self.batch_size
        p0 = _as_diagonal(self.p0_scale, self.device)
        p0 = p0 + 1.0e-6 * torch.eye(
            p0.shape[0], dtype=p0.dtype, device=p0.device
        )
        p0 = p0.unsqueeze(0).expand(self.batch_size, -1, -1).clone()
        self.core.reset(x0, p0)

    @staticmethod
    def _updated_state(result: Any) -> torch.Tensor:
        if torch.is_tensor(result):
            return result
        for attribute in ("updated_state", "x", "state"):
            value = getattr(result, attribute, None)
            if torch.is_tensor(value):
                return value
        if isinstance(result, Mapping):
            for key in ("updated_state", "x", "state"):
                value = result.get(key)
                if torch.is_tensor(value):
                    return value
        raise RuntimeError("adaptive core step() did not expose an updated state tensor")

    def forward(self, observation: torch.Tensor, controls: torch.Tensor) -> torch.Tensor:
        from filters.da_coupler.walrus_batch import fx_walrus_batch, hx_walrus_batch

        fx = lambda sigma, dt: fx_walrus_batch(
            sigma,
            dt,
            sys_model=self.system_model,
            controls=controls,
            device=self.device,
        )
        hx = lambda sigma: hx_walrus_batch(
            sigma, sys_model=self.system_model, device=self.device
        )
        result = self.core.step(observation, fx=fx, hx=hx)
        if self._validation_diagnostics is not None:
            self._adaptive_batch_pending = True
        return self._updated_state(result)


def _adaptive_config_kwargs(
    config: Mapping[str, Any], stationarity_scale: float
) -> dict[str, Any]:
    if stationarity_scale <= 0:
        raise ValueError("stationarity_scale must be positive")
    adaptive = config["adaptive_covariance"]
    delta = 1.0 / float(stationarity_scale)
    return {
        "q_basis": adaptive["q_basis"],
        "initial_q_scale": float(adaptive["initial_q_scale"]),
        "initial_r_variance": float(adaptive["initial_r_variance"]),
        "delta_q": delta if bool(adaptive["adapt_q"]) else 0.0,
        "delta_r": delta,
        "q_min": float(adaptive["q_min"]),
        "q_max": float(adaptive["q_max"]),
        "r_min": float(adaptive["r_min"]),
        "r_max": float(adaptive["r_max"]),
        "denominator_epsilon": float(adaptive["denominator_epsilon"]),
        "pinv_rtol": float(adaptive["pinv_rtol"]),
        "covariance_epsilon": float(adaptive["covariance_epsilon"]),
        "adapt_q": bool(adaptive["adapt_q"]),
        "adapt_r": bool(adaptive["adapt_r"]),
    }


def build_regge_adaptive_model(
    config: Mapping[str, Any],
    system_model: Any,
    args: Any,
    stationarity_scale: float,
) -> ReggeAdaptiveCovarianceAdapter:
    """Build the same Regge batch UKF wrapped by the shared adaptive core."""
    from filters.da_coupler.walrus_batch import fx_walrus_batch, hx_walrus_batch
    from filters.filter.batch.my_version.batch_unscentedkalmanfilter_gpu import (
        BatchUnscentedKalmanFilterGPU,
    )
    from filters.filter.non_batch.kalman import MerweScaledSigmaPoints

    config_class, filter_class, _ = load_core_api()
    device = torch.device(args.device)
    sigma = config["sigma_points"]
    points = MerweScaledSigmaPoints(
        n=system_model.m,
        alpha=float(sigma["alpha"]),
        beta=float(sigma["beta"]),
        kappa=float(sigma["kappa"]),
    )
    points.c = points.alpha**2 * (points.n + points.kappa)
    base_filter = BatchUnscentedKalmanFilterGPU(
        dim_x=system_model.m,
        dim_z=system_model.n,
        dt=1.0,
        hx=lambda values: hx_walrus_batch(values, sys_model=system_model),
        fx=lambda values, dt: fx_walrus_batch(values, dt, sys_model=system_model),
        points=points,
        batch_size=args.n_batch,
        device=device,
    )
    state0 = torch.as_tensor(
        config["system_model"]["state0"], dtype=torch.float32, device=device
    )
    base_filter.x = state0.unsqueeze(0).repeat(args.n_batch, 1)
    initial_covariance = _as_diagonal(
        config["system_model"]["p0_scale"], device
    )
    initial_covariance = initial_covariance + 1.0e-6 * torch.eye(
        system_model.m, dtype=initial_covariance.dtype, device=device
    )
    base_filter.P = initial_covariance.unsqueeze(0).repeat(args.n_batch, 1, 1)
    adaptive_kwargs = _adaptive_config_kwargs(config, stationarity_scale)
    q_basis = _as_diagonal(config["adaptive_covariance"]["q_basis"], device)
    adaptive_kwargs["q_basis"] = q_basis
    base_filter.Q = q_basis * adaptive_kwargs["initial_q_scale"]
    base_filter.R = torch.tensor(
        [[adaptive_kwargs["initial_r_variance"]]],
        dtype=torch.float32,
        device=device,
    )
    try:
        adaptive_config = config_class(**adaptive_kwargs)
    except TypeError as exc:
        raise RuntimeError(
            "AdaptiveNoiseConfig does not match the frozen Regge core API"
        ) from exc
    return ReggeAdaptiveCovarianceAdapter(
        base_filter=base_filter,
        system_model=system_model,
        adaptive_filter_class=filter_class,
        adaptive_config=adaptive_config,
        p0_scale=config["system_model"]["p0_scale"],
        device=device,
    )


def verify_dataset_hash(
    config: Mapping[str, Any], role: str, path: Path
) -> str:
    expected = str(config["data"]["datasets"][role]["sha256"]).lower()
    observed = sha256_file(path)
    if observed.lower() != expected:
        raise RuntimeError(
            f"{role} dataset SHA-256 mismatch: expected {expected}, observed {observed}"
        )
    return observed


def _sample_precipitation(dataset: Any) -> torch.Tensor:
    sample = dataset[0]
    if not isinstance(sample, Mapping) or "p" not in sample:
        raise ValueError("dataset samples must be mappings containing 'p'")
    precipitation = sample["p"]
    return precipitation.squeeze() if precipitation.ndim > 1 else precipitation


def evaluate_dataset(
    *,
    config: Mapping[str, Any],
    dataset: Any,
    stationarity_scale: float,
    device: str,
    work_directory: Path,
) -> tuple[float, dict[str, float], dict[str, Any]]:
    """Evaluate one frozen adaptive setting through build_args/run_one_epoch."""
    effective = copy.deepcopy(dict(config))
    effective["runtime"]["device"] = device
    sample_p = _sample_precipitation(dataset)
    args = build_args(effective, sample_p, sample_p)
    args.device = device
    loader = DataLoader(
        dataset,
        batch_size=int(effective["dataloader"]["batch_size"]),
        shuffle=False,
        num_workers=int(effective["dataloader"]["num_workers"]),
        pin_memory=bool(effective["dataloader"]["pin_memory"]),
    )
    system_model = initialize_system_model(
        args.train_seq_len, args.seq_len_val, device=device
    )
    model = build_regge_adaptive_model(
        effective, system_model, args, stationarity_scale
    ).to(device)
    model.enable_validation_diagnostics()
    pipeline = Pipeline(str(work_directory))
    pipeline.set_sys_model(system_model)
    pipeline.set_knet_model(model)
    pipeline.set_train_params(args)
    pipeline.save_predictions = False
    pipeline.display_metrics_list = ["nse", "mse"]
    initialize_training(pipeline, loader, loader)
    average_loss, metrics = run_one_epoch(
        pipeline, loader, epoch=0, is_training=False
    )
    clean_metrics = {key: float(value) for key, value in metrics.items()}
    clean_average_loss = float(average_loss)
    if not math.isfinite(clean_average_loss) or any(
        not math.isfinite(value) for value in clean_metrics.values()
    ):
        raise RuntimeError(
            f"non-finite validation result for stationarity scale {stationarity_scale}"
        )
    adaptive_diagnostics = model.validation_diagnostics_summary()
    return clean_average_loss, clean_metrics, adaptive_diagnostics


def _source_path(callable_object: Any) -> Path:
    path = inspect.getsourcefile(callable_object)
    if path is None:
        raise RuntimeError(f"cannot resolve source for {callable_object}")
    return Path(path).resolve()


def implementation_paths(core_module: Any) -> list[Path]:
    from filters.da_coupler import walrus_batch
    from filters.filter.batch.my_version import batch_unscentedkalmanfilter_gpu
    from knet.modules.pipeline import core_fun
    from experiments.optimize_hyper_parameters import run_adaptive_covariance_baseline

    paths = [
        Path(__file__).resolve(),
        Path(run_adaptive_covariance_baseline.__file__).resolve(),
        _source_path(build_args),
        _source_path(run_one_epoch),
        _source_path(core_fun.system_model_forecast),
        Path(core_module.__file__).resolve(),
        Path(batch_unscentedkalmanfilter_gpu.__file__).resolve(),
        Path(walrus_batch.__file__).resolve(),
        PROJECT_ROOT / "draft" / "scripts" / "generate_paper_metrics.py",
    ]
    unique: list[Path] = []
    for path in paths:
        if path not in unique:
            unique.append(path)
    return unique


def implementation_records(paths: Iterable[Path]) -> list[dict[str, str]]:
    return [
        {"path": str(Path(path).resolve()), "sha256": sha256_file(path)}
        for path in paths
    ]


def verify_implementation_records(records: Iterable[Mapping[str, Any]]) -> None:
    for record in records:
        path = Path(str(record["path"]))
        expected = str(record["sha256"]).lower()
        if not path.is_file():
            raise RuntimeError(f"implementation file is missing: {path}")
        observed = sha256_file(path)
        if observed.lower() != expected:
            raise RuntimeError(
                f"implementation file changed after selection: {path}"
            )


def write_json_exclusive(path: Path | str, payload: Mapping[str, Any]) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("x", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")


def git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=PROJECT_ROOT, text=True
        ).strip()
    except (OSError, subprocess.CalledProcessError):
        return "unknown"


def verify_frozen_selection(
    *,
    selection_path: Path,
    expected_selection_sha256: str,
    config_path: Path,
    verify_implementation_files: bool = True,
    verify_core: bool = True,
) -> dict[str, Any]:
    if len(expected_selection_sha256) != 64 or any(
        character not in "0123456789abcdefABCDEF"
        for character in expected_selection_sha256
    ):
        raise ValueError("expected selection SHA-256 must contain 64 hex characters")
    observed_selection_hash = sha256_file(selection_path)
    if observed_selection_hash.lower() != expected_selection_sha256.lower():
        raise ValueError(
            "selection SHA-256 mismatch; refusing final test evaluation"
        )
    payload = json.loads(selection_path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != SELECTION_SCHEMA_VERSION:
        raise ValueError("unexpected selection manifest schema_version")
    if payload.get("status") != "frozen":
        raise ValueError("selection manifest status must be 'frozen'")
    if payload.get("pipeline_contract") != PIPELINE_CONTRACT:
        raise ValueError("selection pipeline contract does not match current contract")
    if payload.get("core_api") != REQUIRED_CORE_API:
        raise ValueError("selection core API does not match current contract")
    expected_config_hash = str(payload.get("config", {}).get("sha256", ""))
    current_config_hash = sha256_file(config_path)
    if current_config_hash.lower() != expected_config_hash.lower():
        raise ValueError("config SHA-256 mismatch after validation selection")
    if verify_core:
        load_core_api()
    if verify_implementation_files:
        verify_implementation_records(payload.get("implementation_files", []))
    return payload


def run_selection(
    *, config_path: Path, output_path: Path, device: str
) -> dict[str, Any]:
    config_path = config_path.resolve()
    output_path = output_path.resolve()
    if output_path.exists():
        raise FileExistsError(f"selection output already exists: {output_path}")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    config = load_yaml(config_path)
    validate_config(config, require_declared_bounds=True)
    independent_gate = verify_independent_numerical_gate(config, PROJECT_ROOT)
    validation_path = require_selection_dataset(config, PROJECT_ROOT)
    _, _, core_module = load_core_api()
    if not validation_path.is_file():
        raise FileNotFoundError(f"validation dataset not found: {validation_path}")
    validation_hash = verify_dataset_hash(config, "validation", validation_path)
    dataset = torch.load(validation_path, map_location="cpu", weights_only=False)

    torch.manual_seed(int(config["runtime"]["seed"]))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(int(config["runtime"]["seed"]))

    candidates: list[dict[str, Any]] = []
    for stationarity_scale in config["selection"]["stationarity_scale_grid"]:
        with tempfile.TemporaryDirectory(
            prefix=f"regge_acukf_s{stationarity_scale}_",
            dir=str(output_path.parent),
        ) as temporary:
            average_loss, metrics, adaptive_diagnostics = evaluate_dataset(
                config=config,
                dataset=dataset,
                stationarity_scale=float(stationarity_scale),
                device=device,
                work_directory=Path(temporary),
            )
        validation_nse = float(metrics.get("nse", float("nan")))
        if not math.isfinite(validation_nse):
            raise RuntimeError(
                f"non-finite validation NSE for stationarity scale {stationarity_scale}"
            )
        delta = 1.0 / float(stationarity_scale)
        candidates.append(
            {
                "stationarity_scale": float(stationarity_scale),
                "delta_q": 0.0,
                "delta_r": delta,
                "validation_average_loss": average_loss,
                "validation_metrics": metrics,
                "validation_adaptive_diagnostics": adaptive_diagnostics,
            }
        )
    selected_candidate = max(
        candidates, key=lambda record: record["validation_metrics"]["nse"]
    )
    selected = {
        "stationarity_scale": selected_candidate["stationarity_scale"],
        "delta_q": selected_candidate["delta_q"],
        "delta_r": selected_candidate["delta_r"],
        "validation_nse": selected_candidate["validation_metrics"]["nse"],
    }
    manifest = {
        "schema_version": SELECTION_SCHEMA_VERSION,
        "status": "frozen",
        "experiment_id": config["experiment"]["id"],
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "git_commit": git_commit(),
        "config": {
            "path": str(config_path),
            "sha256": sha256_file(config_path),
        },
        "selection_dataset": {
            "role": "validation",
            "path": str(validation_path),
            "sha256": validation_hash,
        },
        "pipeline_contract": PIPELINE_CONTRACT,
        "core_api": REQUIRED_CORE_API,
        "independent_numerical_gate": independent_gate,
        "adaptive_covariance": copy.deepcopy(config["adaptive_covariance"]),
        "candidates": candidates,
        "selected": selected,
        "implementation_files": implementation_records(
            implementation_paths(core_module)
        ),
    }
    write_json_exclusive(output_path, manifest)
    return manifest


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Select Regge adaptive covariance settings on validation data only."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path(__file__).with_name("adaptive_covariance_ukf_config.yaml"),
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--device", default="cuda" if torch.cuda.is_available() else "cpu"
    )
    return parser


def main(argv: list[str] | None = None) -> None:
    arguments = build_argument_parser().parse_args(argv)
    manifest = run_selection(
        config_path=arguments.config,
        output_path=arguments.output,
        device=arguments.device,
    )
    selection_hash = sha256_file(arguments.output)
    print(
        json.dumps(
            {
                "selection_path": str(arguments.output.resolve()),
                "selection_sha256": selection_hash,
                "selected": manifest["selected"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
