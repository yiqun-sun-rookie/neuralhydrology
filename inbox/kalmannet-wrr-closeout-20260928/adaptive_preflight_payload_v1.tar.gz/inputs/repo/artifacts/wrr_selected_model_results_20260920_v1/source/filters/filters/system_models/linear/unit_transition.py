import torch
import numpy as np
def fx_torch(x, dt):
    F = torch.tensor([[1, dt],
                      [0, 1]], dtype=torch.float32, device=x.device)
    return torch.matmul(x, F.T)

def fx_numpy(x, dt):
    F = np.array([[1, dt],
                  [0, 1]], dtype=np.float32)
    return np.dot(x, F.T)

def hx(x):
    return x[:, 0:1]