"""Causal innovation-correlation covariance adaptation for a batch UKF.

This module implements the rank-deficient, one-process-basis equations from
Berry and Sauer (2013), following the innovation-correlation approach of
Mehra (1970, 1972).  It deliberately does *not* estimate an independent
process variance for every state from a scalar observation.  Instead,

``Q_k = q_k * Q_basis`` and ``R_k = r_k``.

The covariance estimates calculated with observation ``z_k`` are installed
only after the state update at ``k`` and therefore first affect filtering at
``k + 1``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Mapping

import torch


Tensor = torch.Tensor


def _require_finite(name: str, value: Tensor) -> None:
    if not torch.isfinite(value).all():
        raise ValueError(f"{name} contains a non-finite value")


def _clone_optional(value: Tensor | None) -> Tensor | None:
    return None if value is None else value.detach().clone()


def _clone_history(history: list[Tensor]) -> list[Tensor]:
    return [value.detach().clone() for value in history]


@dataclass(frozen=True)
class AdaptiveNoiseConfig:
    """Configuration for one-basis innovation-correlation adaptation.

    All variance bounds apply to the scalar process-basis coefficient or the
    scalar observation variance.  ``q_basis`` must be a finite, non-negative
    diagonal matrix with at least one positive entry.
    """

    q_basis: Tensor
    initial_q_scale: float = 1.0
    initial_r_variance: float = 1.0
    delta_q: float = 0.01
    delta_r: float = 0.01
    q_min: float = 0.0
    q_max: float = 1.0e6
    r_min: float = 1.0e-12
    r_max: float = 1.0e6
    denominator_epsilon: float = 1.0e-12
    pinv_rtol: float = 1.0e-7
    covariance_epsilon: float = 1.0e-12
    adapt_q: bool = True
    adapt_r: bool = True

    def __post_init__(self) -> None:
        basis = torch.as_tensor(self.q_basis).detach().clone()
        if basis.ndim != 2 or basis.shape[0] != basis.shape[1]:
            raise ValueError("q_basis must be a square matrix")
        _require_finite("q_basis", basis)
        diagonal = torch.diagonal(basis)
        if not torch.equal(basis, torch.diag_embed(diagonal)):
            raise ValueError("q_basis must be diagonal")
        if torch.any(diagonal < 0) or not torch.any(diagonal > 0):
            raise ValueError("q_basis diagonal must be non-negative and non-zero")
        object.__setattr__(self, "q_basis", basis)

        scalar_names = (
            "initial_q_scale",
            "initial_r_variance",
            "delta_q",
            "delta_r",
            "q_min",
            "q_max",
            "r_min",
            "r_max",
            "denominator_epsilon",
            "pinv_rtol",
            "covariance_epsilon",
        )
        for name in scalar_names:
            value = float(getattr(self, name))
            if not torch.isfinite(torch.tensor(value)):
                raise ValueError(f"{name} must be finite")

        if not 0.0 <= self.delta_q <= 1.0:
            raise ValueError("delta_q must be in [0, 1]")
        if not 0.0 <= self.delta_r <= 1.0:
            raise ValueError("delta_r must be in [0, 1]")
        if self.q_min < 0 or self.q_min > self.q_max:
            raise ValueError("q bounds must satisfy 0 <= q_min <= q_max")
        if self.r_min <= 0 or self.r_min > self.r_max:
            raise ValueError("r bounds must satisfy 0 < r_min <= r_max")
        if not self.q_min <= self.initial_q_scale <= self.q_max:
            raise ValueError("initial_q_scale is outside the declared q bounds")
        if not self.r_min <= self.initial_r_variance <= self.r_max:
            raise ValueError("initial_r_variance is outside the declared r bounds")
        if self.denominator_epsilon <= 0:
            raise ValueError("denominator_epsilon must be positive")
        if self.pinv_rtol <= 0:
            raise ValueError("pinv_rtol must be positive")
        if self.covariance_epsilon <= 0:
            raise ValueError("covariance_epsilon must be positive")


@dataclass(frozen=True)
class AdaptiveStepResult:
    """State, covariance timing, and local-map diagnostics for one step."""

    x: Tensor
    P: Tensor
    q_used: Tensor
    r_used: Tensor
    q_after: Tensor
    r_after: Tensor
    Q_used: Tensor
    R_used: Tensor
    innovation: Tensor
    gain: Tensor
    transition_map: Tensor
    observation_map: Tensor
    q_denominator: Tensor


def sigma_point_linear_map(
    input_points: Tensor,
    output_points: Tensor,
    *,
    input_mean: Tensor | None = None,
    output_mean: Tensor | None = None,
    pinv_rtol: float = 1.0e-7,
) -> Tensor:
    """Return the least-squares local map between two sigma-point clouds.

    Point tensors may have shape ``[sigma, dimension]`` or
    ``[batch, sigma, dimension]``.  Means are supplied by the UKF in normal
    use; arithmetic means are a convenience fallback for standalone tests.
    """

    inputs = torch.as_tensor(input_points)
    outputs = torch.as_tensor(output_points, device=inputs.device, dtype=inputs.dtype)
    squeeze_batch = inputs.ndim == 2
    if squeeze_batch:
        inputs = inputs.unsqueeze(0)
        outputs = outputs.unsqueeze(0)
    if inputs.ndim != 3 or outputs.ndim != 3:
        raise ValueError("sigma-point tensors must have two or three dimensions")
    if inputs.shape[:2] != outputs.shape[:2]:
        raise ValueError("input and output sigma-point batches must align")
    _require_finite("input_points", inputs)
    _require_finite("output_points", outputs)
    if pinv_rtol <= 0:
        raise ValueError("pinv_rtol must be positive")

    if input_mean is None:
        in_mean = inputs.mean(dim=-2)
    else:
        in_mean = torch.as_tensor(input_mean, device=inputs.device, dtype=inputs.dtype)
        if in_mean.ndim == 1:
            in_mean = in_mean.unsqueeze(0)
    if output_mean is None:
        out_mean = outputs.mean(dim=-2)
    else:
        out_mean = torch.as_tensor(output_mean, device=inputs.device, dtype=inputs.dtype)
        if out_mean.ndim == 1:
            out_mean = out_mean.unsqueeze(0)
    if in_mean.shape != (inputs.shape[0], inputs.shape[2]):
        raise ValueError("input_mean has an incompatible shape")
    if out_mean.shape != (outputs.shape[0], outputs.shape[2]):
        raise ValueError("output_mean has an incompatible shape")
    _require_finite("input_mean", in_mean)
    _require_finite("output_mean", out_mean)

    input_perturbations = (inputs - in_mean.unsqueeze(-2)).transpose(-1, -2)
    output_perturbations = (outputs - out_mean.unsqueeze(-2)).transpose(-1, -2)
    local_map = output_perturbations @ torch.linalg.pinv(
        input_perturbations, rtol=pinv_rtol
    )
    _require_finite("sigma-point local map", local_map)
    return local_map.squeeze(0) if squeeze_batch else local_map


def rank_deficient_q_scale(
    C: Tensor,
    H_next: Tensor,
    F: Tensor,
    Q_basis: Tensor,
    H: Tensor,
    *,
    denominator_epsilon: float = 1.0e-12,
) -> Tensor:
    """Solve the Berry-Sauer one-basis rank-deficient process-noise equation.

    The equation is ``A q = C`` with
    ``A = H_next @ F @ Q_basis @ H.T``.  Frobenius least squares gives
    ``q = <A, C> / <A, A>``.  A small denominator is unidentifiable and is
    rejected here; the stateful wrapper skips and counts such updates.
    """

    C_t = torch.as_tensor(C)
    device, dtype = C_t.device, C_t.dtype
    H_next_t = torch.as_tensor(H_next, device=device, dtype=dtype)
    F_t = torch.as_tensor(F, device=device, dtype=dtype)
    Q_basis_t = torch.as_tensor(Q_basis, device=device, dtype=dtype)
    H_t = torch.as_tensor(H, device=device, dtype=dtype)
    for name, value in (
        ("C", C_t),
        ("H_next", H_next_t),
        ("F", F_t),
        ("Q_basis", Q_basis_t),
        ("H", H_t),
    ):
        _require_finite(name, value)
    A = H_next_t @ F_t @ Q_basis_t @ H_t.transpose(-1, -2)
    if A.shape != C_t.shape:
        raise ValueError("C and H_next @ F @ Q_basis @ H.T must have the same shape")
    numerator = (A * C_t).flatten(start_dim=max(A.ndim - 2, 0)).sum(dim=-1)
    denominator = (A * A).flatten(start_dim=max(A.ndim - 2, 0)).sum(dim=-1)
    if torch.any(denominator <= denominator_epsilon):
        raise ValueError("rank-deficient process-noise equation has a small denominator")
    result = numerator / denominator
    _require_finite("q_scale estimate", result)
    return result


def _batch_sigma_points(
    x: Tensor,
    P: Tensor,
    c: float,
    covariance_epsilon: float,
) -> Tensor:
    if x.ndim != 2 or P.shape != (x.shape[0], x.shape[1], x.shape[1]):
        raise ValueError("x and P must have shapes [batch, state] and [batch, state, state]")
    _require_finite("state", x)
    _require_finite("state covariance", P)
    if c <= 0:
        raise ValueError("sigma-point scale c must be positive")
    dimension = x.shape[-1]
    covariance = 0.5 * (P + P.transpose(-1, -2)) * float(c)
    factor, info = torch.linalg.cholesky_ex(covariance)
    if torch.any(info != 0):
        eigenvalues = torch.linalg.eigvalsh(covariance)
        shift = torch.clamp(
            covariance_epsilon - eigenvalues.min(dim=-1).values, min=0.0
        )
        identity = torch.eye(dimension, device=x.device, dtype=x.dtype)
        covariance = covariance + shift[:, None, None] * identity
        factor, info = torch.linalg.cholesky_ex(covariance)
        if torch.any(info != 0):
            raise ValueError("state covariance cannot produce finite sigma points")
    columns = factor.transpose(-1, -2)
    points = torch.cat(
        (x.unsqueeze(-2), x.unsqueeze(-2) + columns, x.unsqueeze(-2) - columns),
        dim=-2,
    )
    _require_finite("sigma points", points)
    return points


def _batch_covariance(value: Tensor, batch_size: int, dimension: int, name: str) -> Tensor:
    tensor = torch.as_tensor(value)
    if tensor.ndim == 2:
        tensor = tensor.unsqueeze(0).expand(batch_size, -1, -1).clone()
    if tensor.shape != (batch_size, dimension, dimension):
        raise ValueError(
            f"{name} must have shape [{dimension}, {dimension}] or "
            f"[{batch_size}, {dimension}, {dimension}]"
        )
    _require_finite(name, tensor)
    return tensor


class InnovationCorrelationAdaptiveUKF:
    """Stateful causal covariance adapter around a batch UKF engine."""

    STATE_VERSION = 1

    def __init__(self, base_filter: Any, config: AdaptiveNoiseConfig):
        required = (
            "x",
            "P",
            "Q",
            "R",
            "Wm",
            "Wc",
            "c",
            "predict",
            "update",
            "fx",
            "hx",
            "dim_x",
            "dim_z",
        )
        missing = [name for name in required if not hasattr(base_filter, name)]
        if missing:
            raise TypeError(f"base_filter is missing required attributes: {missing}")
        if int(base_filter.dim_z) != 1:
            raise ValueError("the one-basis adapter currently requires one observation")
        if config.q_basis.shape != (int(base_filter.dim_x), int(base_filter.dim_x)):
            raise ValueError("q_basis shape does not match base_filter.dim_x")
        self.flt = base_filter
        self.config = config
        self.dim_x = int(base_filter.dim_x)
        self.dim_z = int(base_filter.dim_z)
        self._initialized = False
        self.reset(base_filter.x, base_filter.P)

    @property
    def x(self) -> Tensor:
        return self.flt.x

    @property
    def P(self) -> Tensor:
        return self.flt.P

    @property
    def Q(self) -> Tensor:
        return self.flt.Q

    @property
    def R(self) -> Tensor:
        return self.flt.R

    def _config_state(self) -> dict[str, Any]:
        return {
            "q_basis": self.config.q_basis.detach().cpu().clone(),
            "initial_q_scale": float(self.config.initial_q_scale),
            "initial_r_variance": float(self.config.initial_r_variance),
            "delta_q": float(self.config.delta_q),
            "delta_r": float(self.config.delta_r),
            "q_min": float(self.config.q_min),
            "q_max": float(self.config.q_max),
            "r_min": float(self.config.r_min),
            "r_max": float(self.config.r_max),
            "denominator_epsilon": float(self.config.denominator_epsilon),
            "pinv_rtol": float(self.config.pinv_rtol),
            "covariance_epsilon": float(self.config.covariance_epsilon),
            "adapt_q": bool(self.config.adapt_q),
            "adapt_r": bool(self.config.adapt_r),
        }

    def _build_process_covariance(self, q_scale: Tensor) -> Tensor:
        return q_scale[:, None, None] * self.q_basis.unsqueeze(0)

    @staticmethod
    def _build_observation_covariance(r_variance: Tensor) -> Tensor:
        return r_variance[:, None, None]

    def _install_covariances(self, q_scale: Tensor, r_variance: Tensor) -> None:
        self.flt.Q = self._build_process_covariance(q_scale)
        self.flt.R = self._build_observation_covariance(r_variance)

    def reset(self, x0: Tensor, P0: Tensor) -> None:
        """Reset all filter, lag, counter, and covariance state for a sequence."""

        x = torch.as_tensor(x0).detach().clone()
        if x.ndim == 1:
            x = x.unsqueeze(0)
        if x.ndim != 2 or x.shape[-1] != self.dim_x:
            raise ValueError("x0 must have shape [batch, dim_x]")
        if not x.dtype.is_floating_point:
            x = x.to(dtype=torch.get_default_dtype())
        _require_finite("x0", x)
        batch_size = x.shape[0]
        covariance = torch.as_tensor(P0, device=x.device, dtype=x.dtype).detach().clone()
        covariance = _batch_covariance(covariance, batch_size, self.dim_x, "P0")

        self.q_basis = self.config.q_basis.to(device=x.device, dtype=x.dtype).clone()
        self.q_scale = torch.full(
            (batch_size,),
            float(self.config.initial_q_scale),
            device=x.device,
            dtype=x.dtype,
        )
        self.r_variance = torch.full(
            (batch_size,),
            float(self.config.initial_r_variance),
            device=x.device,
            dtype=x.dtype,
        )
        self.flt.x = x
        self.flt.P = covariance
        if hasattr(self.flt, "batch_size"):
            self.flt.batch_size = batch_size
        self._install_covariances(self.q_scale, self.r_variance)

        self._prev_innovation: Tensor | None = None
        self._prev_gain: Tensor | None = None
        self._prev_observation_map: Tensor | None = None
        self._prev_transition_map: Tensor | None = None
        self._prev_transition_input_covariance: Tensor | None = None
        self.time_index = 0
        zeros = torch.zeros(batch_size, device=x.device, dtype=torch.long)
        self._update_count = zeros.clone()
        self._q_update_count = zeros.clone()
        self._r_update_count = zeros.clone()
        self._skipped_small_denominator_count = zeros.clone()
        self._q_lower_bound_hits = zeros.clone()
        self._q_upper_bound_hits = zeros.clone()
        self._r_lower_bound_hits = zeros.clone()
        self._r_upper_bound_hits = zeros.clone()
        self._minimum_variance = torch.tensor(float("inf"), device=x.device, dtype=x.dtype)
        self._maximum_variance = torch.tensor(float("-inf"), device=x.device, dtype=x.dtype)
        self._history: dict[str, list[Tensor]] = {
            "q_used": [],
            "r_used": [],
            "q_after": [],
            "r_after": [],
            "Q_used": [],
            "R_used": [],
            "q_denominator": [],
        }
        self._initialized = True

    def _weights(self, batch_size: int, sigma_count: int, dtype: torch.dtype, device: torch.device) -> tuple[Tensor, Tensor]:
        mean_weights = torch.as_tensor(self.flt.Wm, device=device, dtype=dtype)
        covariance_weights = torch.as_tensor(self.flt.Wc, device=device, dtype=dtype)
        if mean_weights.shape != (sigma_count,) or covariance_weights.shape != (sigma_count,):
            raise ValueError("base_filter sigma-point weights have an incompatible shape")
        _require_finite("mean sigma-point weights", mean_weights)
        _require_finite("covariance sigma-point weights", covariance_weights)
        return mean_weights, covariance_weights

    def _current_diagnostics(self) -> dict[str, Any]:
        history = {
            name: (
                torch.stack(values, dim=0)
                if values
                else torch.empty(
                    (0,), device=self.q_scale.device, dtype=self.q_scale.dtype
                )
            )
            for name, values in self._history.items()
        }
        return {
            "time_index": self.time_index,
            "update_count": self._update_count.detach().clone(),
            "q_update_count": self._q_update_count.detach().clone(),
            "r_update_count": self._r_update_count.detach().clone(),
            "skipped_small_denominator_count": self._skipped_small_denominator_count.detach().clone(),
            "q_lower_bound_hits": self._q_lower_bound_hits.detach().clone(),
            "q_upper_bound_hits": self._q_upper_bound_hits.detach().clone(),
            "r_lower_bound_hits": self._r_lower_bound_hits.detach().clone(),
            "r_upper_bound_hits": self._r_upper_bound_hits.detach().clone(),
            "minimum_variance": self._minimum_variance.detach().clone(),
            "maximum_variance": self._maximum_variance.detach().clone(),
            **history,
        }

    def diagnostics(self) -> dict[str, Any]:
        """Return detached counters and the exact covariance trace."""

        return self._current_diagnostics()

    def step(
        self,
        z: Tensor,
        *,
        fx: Callable[..., Tensor] | None = None,
        hx: Callable[..., Tensor] | None = None,
        dt: float | None = None,
    ) -> AdaptiveStepResult:
        """Predict, update, then causally prepare covariance for the next step."""

        if not self._initialized:
            raise RuntimeError("reset must be called before step")
        if fx is not None:
            self.flt.fx = fx
        if hx is not None:
            self.flt.hx = hx
        observation = torch.as_tensor(z, device=self.x.device, dtype=self.x.dtype)
        if observation.ndim == 1:
            observation = observation.unsqueeze(-1)
        if observation.shape != (self.x.shape[0], self.dim_z):
            raise ValueError("z must have shape [batch, dim_z]")
        _require_finite("z", observation)

        q_used = self.q_scale.detach().clone()
        r_used = self.r_variance.detach().clone()
        self._install_covariances(q_used, r_used)
        Q_used = self.flt.Q.detach().clone()
        R_used = self.flt.R.detach().clone()

        analysis_mean = self.x.detach().clone()
        transition_input_covariance = self.P.detach().clone()
        analysis_points = _batch_sigma_points(
            analysis_mean,
            transition_input_covariance,
            float(self.flt.c),
            self.config.covariance_epsilon,
        )
        if dt is None:
            self.flt.predict()
            transition_dt = float(getattr(self.flt, "dt", 1.0))
        else:
            self.flt.predict(dt=dt)
            transition_dt = float(dt)
        forecast_mean = self.x.detach().clone()
        forecast_covariance = self.P.detach().clone()
        _require_finite("forecast state", forecast_mean)
        _require_finite("forecast covariance", forecast_covariance)

        propagated_points = getattr(self.flt, "sigmas_f", None)
        if propagated_points is None:
            propagated_points = self.flt.fx(analysis_points, transition_dt)
        propagated_points = torch.as_tensor(
            propagated_points, device=self.x.device, dtype=self.x.dtype
        )
        transition_map = sigma_point_linear_map(
            analysis_points,
            propagated_points,
            input_mean=analysis_mean,
            output_mean=forecast_mean,
            pinv_rtol=self.config.pinv_rtol,
        )

        forecast_points = _batch_sigma_points(
            forecast_mean,
            forecast_covariance,
            float(self.flt.c),
            self.config.covariance_epsilon,
        )
        observation_points = torch.as_tensor(
            self.flt.hx(forecast_points), device=self.x.device, dtype=self.x.dtype
        )
        if observation_points.shape[:2] != forecast_points.shape[:2] or observation_points.shape[-1] != self.dim_z:
            raise ValueError("hx must return [batch, sigma, dim_z]")
        _require_finite("observation sigma points", observation_points)
        mean_weights, covariance_weights = self._weights(
            self.x.shape[0], forecast_points.shape[1], self.x.dtype, self.x.device
        )
        predicted_observation = torch.einsum(
            "bsz,s->bz", observation_points, mean_weights
        )
        observation_map = sigma_point_linear_map(
            forecast_points,
            observation_points,
            input_mean=forecast_mean,
            output_mean=predicted_observation,
            pinv_rtol=self.config.pinv_rtol,
        )
        state_deviation = forecast_points - forecast_mean.unsqueeze(-2)
        observation_deviation = observation_points - predicted_observation.unsqueeze(-2)
        innovation_covariance = torch.einsum(
            "s,bsi,bsj->bij",
            covariance_weights,
            observation_deviation,
            observation_deviation,
        ) + R_used
        cross_covariance = torch.einsum(
            "s,bsi,bsj->bij",
            covariance_weights,
            state_deviation,
            observation_deviation,
        )
        gain = torch.linalg.solve(
            innovation_covariance, cross_covariance.transpose(-1, -2)
        ).transpose(-1, -2)
        innovation = observation - predicted_observation
        for name, value in (
            ("innovation covariance", innovation_covariance),
            ("Kalman gain", gain),
            ("innovation", innovation),
        ):
            _require_finite(name, value)

        self.flt.update(observation)
        _require_finite("updated state", self.x)
        _require_finite("updated covariance", self.P)

        innovation_outer = innovation.unsqueeze(-1) @ innovation.unsqueeze(-2)
        r_estimate = (
            innovation_outer
            - observation_map @ forecast_covariance @ observation_map.transpose(-1, -2)
        ).squeeze(-1).squeeze(-1)
        _require_finite("observation variance estimate", r_estimate)
        r_after = r_used.clone()
        if self.config.adapt_r:
            r_tentative = r_used + self.config.delta_r * (r_estimate - r_used)
            self._r_lower_bound_hits += (r_tentative < self.config.r_min).to(torch.long)
            self._r_upper_bound_hits += (r_tentative > self.config.r_max).to(torch.long)
            r_after = torch.clamp(
                r_tentative, min=self.config.r_min, max=self.config.r_max
            )
            self._r_update_count += 1

        q_after = q_used.clone()
        q_denominator = torch.full_like(q_used, float("nan"))
        q_updated = torch.zeros_like(q_used, dtype=torch.bool)
        if self._prev_innovation is not None:
            previous_outer = self._prev_innovation.unsqueeze(-1) @ self._prev_innovation.unsqueeze(-2)
            current_previous_outer = innovation.unsqueeze(-1) @ self._prev_innovation.unsqueeze(-2)
            leading = observation_map @ transition_map
            C = (
                current_previous_outer
                + leading @ self._prev_gain @ previous_outer
                - leading
                @ self._prev_transition_map
                @ self._prev_transition_input_covariance
                @ self._prev_transition_map.transpose(-1, -2)
                @ self._prev_observation_map.transpose(-1, -2)
            )
            A = (
                leading
                @ self.q_basis
                @ self._prev_observation_map.transpose(-1, -2)
            )
            numerator = (A * C).flatten(start_dim=-2).sum(dim=-1)
            q_denominator = (A * A).flatten(start_dim=-2).sum(dim=-1)
            _require_finite("process-noise equation numerator", numerator)
            _require_finite("process-noise equation denominator", q_denominator)
            identifiable = q_denominator > self.config.denominator_epsilon
            self._skipped_small_denominator_count += (~identifiable).to(torch.long)
            if self.config.adapt_q and torch.any(identifiable):
                q_estimate = torch.zeros_like(q_used)
                q_estimate[identifiable] = numerator[identifiable] / q_denominator[identifiable]
                _require_finite("process scale estimate", q_estimate[identifiable])
                q_tentative = q_used + self.config.delta_q * (q_estimate - q_used)
                self._q_lower_bound_hits += (
                    identifiable & (q_tentative < self.config.q_min)
                ).to(torch.long)
                self._q_upper_bound_hits += (
                    identifiable & (q_tentative > self.config.q_max)
                ).to(torch.long)
                q_candidate = torch.clamp(
                    q_tentative, min=self.config.q_min, max=self.config.q_max
                )
                q_after = torch.where(identifiable, q_candidate, q_used)
                q_updated = identifiable
                self._q_update_count += identifiable.to(torch.long)

        any_update = q_updated | torch.full_like(q_updated, self.config.adapt_r)
        self._update_count += any_update.to(torch.long)
        _require_finite("adapted process scale", q_after)
        _require_finite("adapted observation variance", r_after)

        self.q_scale = q_after.detach().clone()
        self.r_variance = r_after.detach().clone()
        self._install_covariances(self.q_scale, self.r_variance)
        covariance_diagonal = torch.cat(
            (
                torch.diagonal(Q_used, dim1=-2, dim2=-1).reshape(-1),
                R_used.reshape(-1),
                torch.diagonal(self.flt.Q, dim1=-2, dim2=-1).reshape(-1),
                self.flt.R.reshape(-1),
            )
        )
        self._minimum_variance = torch.minimum(
            self._minimum_variance, covariance_diagonal.min()
        )
        self._maximum_variance = torch.maximum(
            self._maximum_variance, covariance_diagonal.max()
        )

        self._prev_innovation = innovation.detach().clone()
        self._prev_gain = gain.detach().clone()
        self._prev_observation_map = observation_map.detach().clone()
        self._prev_transition_map = transition_map.detach().clone()
        self._prev_transition_input_covariance = transition_input_covariance.detach().clone()
        self.time_index += 1
        for name, value in (
            ("q_used", q_used),
            ("r_used", r_used),
            ("q_after", q_after),
            ("r_after", r_after),
            ("Q_used", Q_used),
            ("R_used", R_used),
            ("q_denominator", q_denominator),
        ):
            self._history[name].append(value.detach().clone())

        return AdaptiveStepResult(
            x=self.x.detach().clone(),
            P=self.P.detach().clone(),
            q_used=q_used,
            r_used=r_used,
            q_after=q_after.detach().clone(),
            r_after=r_after.detach().clone(),
            Q_used=Q_used,
            R_used=R_used,
            innovation=innovation.detach().clone(),
            gain=gain.detach().clone(),
            transition_map=transition_map.detach().clone(),
            observation_map=observation_map.detach().clone(),
            q_denominator=q_denominator.detach().clone(),
        )

    def state_dict(self) -> dict[str, Any]:
        """Return all state required for exact chunk continuation."""

        return {
            "version": self.STATE_VERSION,
            "config": self._config_state(),
            "x": self.x.detach().clone(),
            "P": self.P.detach().clone(),
            "q_scale": self.q_scale.detach().clone(),
            "r_variance": self.r_variance.detach().clone(),
            "previous_innovation": _clone_optional(self._prev_innovation),
            "previous_gain": _clone_optional(self._prev_gain),
            "previous_observation_map": _clone_optional(self._prev_observation_map),
            "previous_transition_map": _clone_optional(self._prev_transition_map),
            "previous_transition_input_covariance": _clone_optional(
                self._prev_transition_input_covariance
            ),
            "time_index": self.time_index,
            "update_count": self._update_count.detach().clone(),
            "q_update_count": self._q_update_count.detach().clone(),
            "r_update_count": self._r_update_count.detach().clone(),
            "skipped_small_denominator_count": self._skipped_small_denominator_count.detach().clone(),
            "q_lower_bound_hits": self._q_lower_bound_hits.detach().clone(),
            "q_upper_bound_hits": self._q_upper_bound_hits.detach().clone(),
            "r_lower_bound_hits": self._r_lower_bound_hits.detach().clone(),
            "r_upper_bound_hits": self._r_upper_bound_hits.detach().clone(),
            "minimum_variance": self._minimum_variance.detach().clone(),
            "maximum_variance": self._maximum_variance.detach().clone(),
            "history": {
                name: _clone_history(values) for name, values in self._history.items()
            },
        }

    def load_state_dict(self, state: Mapping[str, Any]) -> None:
        """Restore a state produced by :meth:`state_dict`."""

        if int(state.get("version", -1)) != self.STATE_VERSION:
            raise ValueError("unsupported adaptive UKF state version")
        saved_config = state.get("config")
        if not isinstance(saved_config, Mapping):
            raise ValueError("adaptive UKF state is missing its configuration")
        current_config = self._config_state()
        for name, current in current_config.items():
            saved = saved_config.get(name)
            if isinstance(current, Tensor):
                if saved is None or not torch.equal(torch.as_tensor(saved), current):
                    raise ValueError(f"state configuration mismatch for {name}")
            elif saved != current:
                raise ValueError(f"state configuration mismatch for {name}")

        x = torch.as_tensor(state["x"]).detach().clone()
        P = torch.as_tensor(state["P"], device=x.device, dtype=x.dtype).detach().clone()
        self.reset(x, P)
        batch_size = x.shape[0]

        def batch_tensor(name: str, *, dtype: torch.dtype | None = None) -> Tensor:
            value = torch.as_tensor(
                state[name], device=x.device, dtype=dtype or x.dtype
            ).detach().clone()
            if value.shape != (batch_size,):
                raise ValueError(f"state field {name} has an incompatible batch shape")
            return value

        self.q_scale = batch_tensor("q_scale")
        self.r_variance = batch_tensor("r_variance")
        if torch.any((self.q_scale < self.config.q_min) | (self.q_scale > self.config.q_max)):
            raise ValueError("saved q_scale is outside configured bounds")
        if torch.any((self.r_variance < self.config.r_min) | (self.r_variance > self.config.r_max)):
            raise ValueError("saved r_variance is outside configured bounds")
        self._install_covariances(self.q_scale, self.r_variance)

        optional_shapes = {
            "previous_innovation": (batch_size, self.dim_z),
            "previous_gain": (batch_size, self.dim_x, self.dim_z),
            "previous_observation_map": (batch_size, self.dim_z, self.dim_x),
            "previous_transition_map": (batch_size, self.dim_x, self.dim_x),
            "previous_transition_input_covariance": (
                batch_size,
                self.dim_x,
                self.dim_x,
            ),
        }

        def optional_tensor(name: str) -> Tensor | None:
            raw = state.get(name)
            if raw is None:
                return None
            value = torch.as_tensor(raw, device=x.device, dtype=x.dtype).detach().clone()
            if value.shape != optional_shapes[name]:
                raise ValueError(f"state field {name} has an incompatible shape")
            _require_finite(name, value)
            return value

        self._prev_innovation = optional_tensor("previous_innovation")
        self._prev_gain = optional_tensor("previous_gain")
        self._prev_observation_map = optional_tensor("previous_observation_map")
        self._prev_transition_map = optional_tensor("previous_transition_map")
        self._prev_transition_input_covariance = optional_tensor(
            "previous_transition_input_covariance"
        )
        self.time_index = int(state["time_index"])
        if self.time_index < 0:
            raise ValueError("time_index cannot be negative")
        self._update_count = batch_tensor("update_count", dtype=torch.long)
        self._q_update_count = batch_tensor("q_update_count", dtype=torch.long)
        self._r_update_count = batch_tensor("r_update_count", dtype=torch.long)
        self._skipped_small_denominator_count = batch_tensor(
            "skipped_small_denominator_count", dtype=torch.long
        )
        self._q_lower_bound_hits = batch_tensor("q_lower_bound_hits", dtype=torch.long)
        self._q_upper_bound_hits = batch_tensor("q_upper_bound_hits", dtype=torch.long)
        self._r_lower_bound_hits = batch_tensor("r_lower_bound_hits", dtype=torch.long)
        self._r_upper_bound_hits = batch_tensor("r_upper_bound_hits", dtype=torch.long)
        self._minimum_variance = torch.as_tensor(
            state["minimum_variance"], device=x.device, dtype=x.dtype
        ).detach().clone()
        self._maximum_variance = torch.as_tensor(
            state["maximum_variance"], device=x.device, dtype=x.dtype
        ).detach().clone()

        history = state.get("history")
        if not isinstance(history, Mapping) or set(history) != set(self._history):
            raise ValueError("saved covariance history is incomplete")
        restored_history: dict[str, list[Tensor]] = {}
        for name in self._history:
            values = [
                torch.as_tensor(value, device=x.device, dtype=x.dtype).detach().clone()
                for value in history[name]
            ]
            if len(values) != self.time_index:
                raise ValueError(f"saved history length mismatch for {name}")
            restored_history[name] = values
        self._history = restored_history
        self._initialized = True


__all__ = [
    "AdaptiveNoiseConfig",
    "AdaptiveStepResult",
    "InnovationCorrelationAdaptiveUKF",
    "rank_deficient_q_scale",
    "sigma_point_linear_map",
]
