import numpy as np
import torch
import torch.nn as nn
import warnings
from ._sigma_points import JulierSigmaPointStrategy, SigmaPointStrategy
from ._unscented_transform import UnscentedTransform

class UnscentedKalmanFilter(nn.Module):

    def __init__(self, *, sys_model, state0, p0, device=True):
        super().__init__()
        self.device = torch.device('cuda' if device else 'cpu')

        # 从系统模型中提取过程模型相关参数
        self.f = sys_model.f  # 状态转移函数
        self.m = sys_model.m  # 状态向量维度
        self.Q = sys_model.Q.to(self.device)  # 过程噪声协方差矩阵

        # 从系统模型中提取观测模型相关参数
        self.h = sys_model.h  # 观测函数
        self.n = sys_model.n  # 观测向量维度
        self.R = sys_model.R.to(self.device)  # 观测噪声协方差矩阵

        # 设置先验状态和协方差
        self.set_posterior_state_mean_and_cov(state0.to(self.device), p0.to(self.device))

        # unscented_transform 用于UT相关计算
        self.unscented_transform = UnscentedTransform(dim=self.m)

        # 设置网络
        self.Q_nn = None
        self.R_nn = None

    def predict(self, controls):
        # 上一时刻的结果
        x_k_minus_1 = self.m1x_posterior
        P_k_minus_1 = self.m2x_posterior

        # 计算维度
        N, state_dim = x_k_minus_1.shape

        # 生成Sigma点
        X_k_minus_1 = self.unscented_transform.select_sigma_points(x_k_minus_1, P_k_minus_1)
        # x_k_pred, P_k_pred = self.unscented_transform.compute_distribution_square_root(X_k_minus_1)

        sigma_point_count = state_dim * 2 + 1
        assert X_k_minus_1.shape == (N, sigma_point_count, state_dim)

        # 展平Sigma点并通过动力学模型传播，然后通过测量模型
        X_k_minus_1_reshaped = X_k_minus_1.reshape((-1, state_dim))
        controls_reshaped = controls.repeat_interleave(sigma_point_count, dim=0)
        assert X_k_minus_1_reshaped.shape[0] == controls_reshaped.shape[0]

        X_k_pred = self.f(X_k_minus_1_reshaped, controls_reshaped)
        # 将Sigma点维度改回去
        X_k_pred = X_k_pred.reshape(X_k_minus_1.shape)

        # 计算预测分布
        x_k_pred, P_k_pred = self.unscented_transform.compute_distribution(X_k_pred)
        assert x_k_pred.shape == (N, state_dim)
        assert P_k_pred.shape == (N, state_dim, state_dim)

        # 这里是准备接入Q的神经网络
        if self.Q_nn is not None:
            self.Q = self.Q_nn(x_k_pred)
            assert self.Q.shape == (N, state_dim, state_dim)

        # Add Q
        P_k_pred = P_k_pred + torch.linalg.cholesky(self.Q)

        # Update the predicted state and covariance
        self.m1x_prior = x_k_pred
        self.m2x_prior = P_k_pred

    def update(self, y):
        # predict 结果
        x_k_pred = self.m1x_prior
        P_k_pred = self.m2x_prior

        # 生成Sigma点
        X_k_pred = self.unscented_transform.select_sigma_points(x_k_pred, P_k_pred)

        # 检查维度
        N, sigma_point_count, state_dim = X_k_pred.shape
        observation_dim = self.n
        assert x_k_pred.shape == (N, state_dim)
        assert P_k_pred.shape == (N, state_dim, state_dim)

        # 通过观测模型传播Sigma点
        Y_k_pred = self.h(X_k_pred.reshape((-1, state_dim)))
        Y_k_pred = Y_k_pred.reshape((N, sigma_point_count, observation_dim))
        # 检查维度
        assert Y_k_pred.shape == (N, sigma_point_count, observation_dim)

        # 计算观测分布
        y_k_pred, P_y_k_pred = self.unscented_transform.compute_distribution(Y_k_pred)
        # 这里是准备接入R的神经网络
        if self.R_nn is not None:
            R = self.R_nn(y_k_pred)
            assert R.shape == (N, observation_dim, observation_dim)
        # Add R
        P_y_k_pred = P_y_k_pred + self.R
        # 检查维度
        assert y_k_pred.shape == (N, observation_dim)
        assert P_y_k_pred.shape == (N, observation_dim, observation_dim)

        # Compute cross-covariance
        X_k_pred_centered = X_k_pred - x_k_pred[:, None, :]
        Y_k_pred_centered = Y_k_pred - y_k_pred[:, None, :]
        P_xy = torch.sum(
            self.unscented_transform.weights_c[None, :, None, None]
            * (X_k_pred_centered[:, :, :, None] @ Y_k_pred_centered[:, :, None, :]),
            dim=1,
        )
        assert P_xy.shape == (N, state_dim, observation_dim)

        # Compute Kalman gain
        K = torch.bmm(P_xy, torch.inverse(P_y_k_pred))
        self.K_array[:, :, :, self.t] = K
        self.t += 1
        # 检查维度
        assert K.shape == (N, state_dim, observation_dim)

        # Update mean
        innovations = y - y_k_pred
        x_k = x_k_pred + (K @ innovations[:, :, None]).squeeze(-1)

        # Correct covariance
        P_k = P_k_pred - K @ P_y_k_pred @ K.transpose(-1, -2)

        # Update internal state with corrected beliefs
        self.m1x_posterior = x_k
        self.m2x_posterior = P_k

    def set_posterior_state_mean_and_cov(self, m1x_0, m2x_0):
        self.m1x_posterior = m1x_0
        self.m2x_posterior = m2x_0


    def operate_batch(self, *, y, controls):
        """
        obs y: batch of observations [batch_size, n, T]
        controls: batch of controls [batch_size, control_dim, T]
        """
        device = self.device
        y = y.to(device) if y.device != device else y
        controls = controls.to(device) if controls.device != device else controls

        # 维度
        N, n, T = y.shape

        # 初始化时间序列存储：KG数组, i, 状态, 协方差
        self.K_array = torch.zeros(N, self.m, self.n, T).to(device)
        self.t = 0
        self.states = torch.zeros(N, self.m, T).to(device)
        self.covs = torch.zeros(N, self.m, self.m, T).to(device)

        # 按batch计算
        for t in range(T):
            self.states[:,:,t] = self.m1x_posterior
            self.covs[:,:,:,t] = self.m2x_posterior
            self.predict(controls[:,:,t])
            self.update(y[:,:,t])


    def compute_distribution(self, sigma_points):
        """Estimate a distribution from selected sigma points.

        Args:
            sigma_points (torch.Tensor): Sigma points, with shape
                `(N, 2 * dim + 1, dim)`.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: Mean and covariance, with shapes
            `(N, dim)` and `(N, dim, dim)` respectively.
        """
        # Make sure devices match
        device = sigma_points.device
        if self.weights_c.device != device:
            self.weights_c = self.weights_c.to(device)
            self.weights_m = self.weights_m.to(device)

        # Check shapes
        N, sigma_point_count, dim = sigma_points.shape
        assert self.weights_m.shape == self.weights_c.shape == (sigma_point_count,)

        # Compute transformed mean, covariance
        transformed_mean = torch.sum(
            self.weights_m[None, :, None] * sigma_points, dim=1
        )
        assert transformed_mean.shape == (N, dim)

        sigma_points_centered = sigma_points - transformed_mean[:, None, :]
        # sigma_points_centered = sigma_points - sigma_points[:, 0:1, :]
        transformed_covariance = torch.sum(
            self.weights_c[None, :, None, None]
            * (
                sigma_points_centered[:, :, :, None]
                @ sigma_points_centered[:, :, None, :]
            ),
            dim=1,
        )
        assert transformed_covariance.shape == (N, dim, dim)
        return transformed_mean, transformed_covariance

    def select_sigma_points_square_root(self, input_mean, input_scale_tril):
        """Select sigma points using square root of covariance.

        Args:
            input_mean (torch.Tensor): Distribution mean. Shape should be `(N, dim)`.
            input_scale_tril (torch.Tensor): Cholesky decomposition of distribution
                covariance. Shape should be `(N, dim, dim)`.
        Returns:
            torch.Tensor: Selected sigma points, with shape `(N, 2 * dim + 1, dim)`.
        """

        N, dim = input_mean.shape
        assert input_scale_tril.shape == (N, dim, dim)
        assert dim == self._dim

        # Compute matrix root, offsets for sigma points
        #
        # Note that we offset with the row vectors, so we need an upper-triangular
        # cholesky decomposition [1].
        #
        # [1] https://www.cs.ubc.ca/~murphyk/Papers/Julier_Uhlmann_mar04.pdf
        matrix_root = np.sqrt(dim + self._lambd) * input_scale_tril.transpose(-1, -2)
        assert matrix_root.shape == (N, dim, dim)

        sigma_point_offsets = input_mean.new_zeros((N, 2 * dim + 1, dim))
        sigma_point_offsets[:, 1 : 1 + dim] = matrix_root
        sigma_point_offsets[:, 1 + dim :] = -matrix_root

        # Create & return matrix of sigma points
        sigma_points: torch.Tensor = input_mean[:, None, :] + sigma_point_offsets
        assert sigma_points.shape == (N, 2 * dim + 1, dim)
        return sigma_points