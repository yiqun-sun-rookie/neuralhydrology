"""
Shared Metrics Module
=====================
Common evaluation metrics and loss functions for hydrological modeling.

Usage:
    from shared.metrics import nse_metric, mse_loss
"""

import torch

def nse_metric(y_pred: torch.Tensor, y_true: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    """
    Nash-Sutcliffe Efficiency (NSE).
    
    Args:
        y_pred: Simulated values [Batch, Time, 1]
        y_true: Observed values [Batch, Time, 1]
        eps: Small epsilon to avoid division by zero
        
    Returns:
        NSE score (scalar)
    """
    # Compute variance of y_true per sample (dim=1 is time)
    y_mean = torch.mean(y_true, dim=1, keepdim=True)
    ss_tot = torch.sum((y_true - y_mean) ** 2, dim=1)
    ss_res = torch.sum((y_true - y_pred) ** 2, dim=1)
    
    # NSE per sample
    nse_per_sample = 1.0 - ss_res / (ss_tot + eps)
    
    # Mean NSE across batch
    return nse_per_sample.mean()

def mse_loss(y_pred: torch.Tensor, y_true: torch.Tensor) -> torch.Tensor:
    """Standard Mean Squared Error."""
    return torch.mean((y_pred - y_true) ** 2)

def kge_metric(y_pred: torch.Tensor, y_true: torch.Tensor) -> torch.Tensor:
    """
    Kling-Gupta Efficiency (KGE).
    Note: Simplified version, watch out for bias term on normalized data.
    """
    # Mean
    mu_sim = y_pred.mean(dim=1)
    mu_obs = y_true.mean(dim=1)
    
    # Standard deviation
    std_sim = y_pred.std(dim=1)
    std_obs = y_true.std(dim=1)
    
    # Correlation
    # (Simplified implementation for batch tensors, requires careful check)
    # Keeping it placeholder for now or use torch.corrcoef per batch if needed
    raise NotImplementedError("KGE tensor implementation pending validation.")
