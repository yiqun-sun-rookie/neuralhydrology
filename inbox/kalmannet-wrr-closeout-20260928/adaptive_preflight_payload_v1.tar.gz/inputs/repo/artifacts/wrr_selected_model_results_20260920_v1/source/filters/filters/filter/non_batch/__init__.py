# -*- coding: utf-8 -*-
"""Copyright 2015 Roger R Labbe Jr.

non_batch library.
http://github.com/rlabbe/filterpy

Documentation at:
https://filterpy.readthedocs.org

Supporting book at:
https://github.com/rlabbe/Kalman-and-Bayesian-Filters-in-Python

This is licensed under an MIT license. See the readme.MD file
for more information.
"""

__version__ = "1.4.5"

__all__ = ['common', 'discrete_bayes', 'gh', 'hinfinity',
           'kalman', 'leastsq', 'memory', 'monte_carlo', 'stats',
           'dapper', 'stonesoup', 'ensemble']

from . import common
from . import discrete_bayes
from . import gh
from . import hinfinity
from . import kalman
from . import leastsq
from . import memory
from . import monte_carlo
from . import stats
try:
    from . import dapper
except (ImportError, TypeError):
    dapper = None  # dapper deps (mpl_tools, struct_tools) are optional
from . import ensemble  # 集合同化算法（单步版本）

# Stone Soup 风格滤波器
try:
    from . import stonesoup
except ImportError:
    stonesoup = None
