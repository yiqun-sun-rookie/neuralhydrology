import torch
from torch.utils.data import Dataset

class WindowedTimeSeriesDataset(Dataset):
    def __init__(self, p, etpot, qobs, tm_hours, states_file_path, window_size):
        self.p = torch.tensor(p, dtype=torch.float32).unsqueeze(-1)
        self.etpot = torch.tensor(etpot, dtype=torch.float32).unsqueeze(-1)
        self.qobs = torch.tensor(qobs, dtype=torch.float32).unsqueeze(-1)
        self.states_all = torch.load(states_file_path)  # [T, m]
        self.tm_hours = torch.tensor(tm_hours, dtype=torch.float32).unsqueeze(-1)
        self.window_size = window_size

    def __len__(self):
        """
        返回可用的滑窗数量。假设原序列长度为 T，则可切出的窗口数量 = (T - window_size + 1)。
        不在这里与 batch_size 挂钩，方便后续在 DataLoader 中灵活指定 batch_size。
        """
        total_length = len(self.p)  # p, etpot, qobs, tm_hours 应该长度一致
        return total_length - self.window_size + 1

    def __getitem__(self, idx):
        """
        返回第 idx 个窗口的数据字典。
        每个窗口长度 window_size，对应区间为 [idx, idx+window_size)。
        """
        start = idx
        end = idx + self.window_size

        sample = {
            'p': self.p[start:end].transpose(0, 1),  # shape: [1, window_size]
            'etpot': self.etpot[start:end].transpose(0, 1),  # shape: [1, window_size]
            'qobs': self.qobs[start:end].transpose(0, 1),  # shape: [1, window_size]
            'tm_hours': self.tm_hours[start:end].transpose(0, 1),  # shape: [1, window_size]
            'state0': self.states_all[start:end].transpose(0, 1)  # shape: [m, window_size]
        }

        return sample