import torch
import torch.nn as nn

class UKF_with_NN(nn.Module):
    def __init__(self, dim_x, dim_z, dt, fx_factory, hx_factory, x, P, points, q_prior, r_prior, scaler_q, scaler_r, nn_q, nn_r, device='cuda'):
        super().__init__()  # 调用父类初始化

        self.device = device
        self.dim_x = dim_x
        self.dim_z = dim_z
        self.dt = dt
        self.fx_factory = fx_factory  # measurement function
        self.hx_factory = hx_factory  # state transition function
        # self.batch_size = batch_size
        self.nn_q = nn_q.to(self.device)  # 神经网络模型
        self.nn_r = nn_r.to(self.device)  # 神经网络模型

        # Initialize weights with float32
        self.Wm = torch.tensor(points.Wm, dtype=torch.float32, device=self.device)
        self.Wc = torch.tensor(points.Wc, dtype=torch.float32, device=self.device)
        self.c = points.c

        self.x = x
        self.x0 = x
        self.P = P
        self.P0 = P

        # 初始化神经网络的隐藏状态
        self.h_prev_q = self.nn_q.init_hidden()
        self.h_prev_r = self.nn_r.init_hidden()


        # 为了保存之前的状态和观测
        # self.z_obs_previous = torch.zeros(batch_size, dim_z, device=self.device)
        # self.z_obs = torch.zeros(batch_size, dim_z, device=self.device)
        # self.z_prior = torch.zeros(batch_size, dim_z, device=self.device)
        # self.x_posterior_previous = torch.zeros(batch_size, dim_x, device=self.device)
        # self.x_prior_previous = torch.zeros(batch_size, dim_x, device=self.device)

        #
        self.q = q_prior
        self.q0 = q_prior

        self.r = r_prior
        self.r0 = r_prior

        self.q_prior = q_prior
        self.q_prior0 = q_prior

        self.r_prior = r_prior
        self.r_prior0 = r_prior

        self.scaler_q = scaler_q
        self.scaler_q0 = scaler_q

        self.scaler_r = scaler_r
        self.scaler_r0 = scaler_r

        # 调试chol分解失败问题
        self.regularization_count = 0 # 记录正则化次数
        self.epsilon = 1e-8 # 正则化参数

        # 修正策略配置
        self.recovery_config = {
            'mode': 'hybrid',  # 可选: 'eigen', 'svd', 'hybrid', 'reset'
            'epsilon': 1e-8,
            'max_recovery_attempts': 3,
            'reset_value': 1e-6
        }
        self.recovery_counter = 0
        self.last_recovery_type = None


    def reset_for_batch(self, batch_size):
        """动态调整状态和隐藏状态以匹配当前批次大小"""
        self.x = self.x0[:batch_size].clone()  # 直接取前batch_size个状态
        self.P = self.P0[:batch_size].clone()  # 直接取前batch_size个协方差矩阵
        # self.x0 = self.x0[:batch_size].clone()  # 直接取前batch_size个状态
        # self.P0 = self.P0[:batch_size].clone()  # 直接取前batch_size个协方差矩阵
        self.h_prev_q = self.nn_q.init_hidden(batch_size)
        self.h_prev_r = self.nn_r.init_hidden(batch_size)

        #
        self.q = self.q_prior0[:batch_size].clone()  #
        self.r = self.r_prior0[:batch_size].clone()  #
        self.q_prior = self.q_prior0[:batch_size].clone()  #
        self.r_prior = self.r_prior0[:batch_size].clone()  #
        self.scaler_q = self.scaler_q0[:batch_size].clone()  #
        self.scaler_r = self.scaler_r0[:batch_size].clone()  #

        # 动态初始化观测和状态缓存
        self.z_obs_previous = torch.zeros(batch_size, self.dim_z, device=self.device)
        self.z_obs = torch.zeros(batch_size, self.dim_z, device=self.device)
        self.z_prior = torch.zeros(batch_size, self.dim_z, device=self.device)
        self.x_posterior_previous = torch.zeros(batch_size, self.dim_x, device=self.device)
        self.x_prior_previous = torch.zeros(batch_size, self.dim_x, device=self.device)

    def _core_cholesky(self, P_scaled):
        """分层的Cholesky分解尝试"""
        try:
            # 首次尝试原始分解（保持梯度）
            return torch.linalg.cholesky(P_scaled)
        except RuntimeError as e1:
            # 从第二次尝试开始禁用梯度
            with torch.no_grad():  # 关键修改点
                try:
                    # 二次尝试：基础正则化
                    I = torch.eye(self.dim_x, device=P_scaled.device).expand_as(P_scaled)
                    U = torch.linalg.cholesky(P_scaled + self.recovery_config['epsilon'] * I)
                except RuntimeError as e2:
                    try:
                        # 三次尝试：特征值重构
                        P_fixed = self._eigen_recovery(P_scaled)
                        U = torch.linalg.cholesky(P_fixed)
                    except RuntimeError as e3:
                        # 最终手段：应急重置
                        print(f"极端情况触发矩阵重置 (总恢复次数: {self.recovery_counter})")
                        U = torch.eye(self.dim_x, device=P_scaled.device).expand_as(P_scaled) * \
                            self.recovery_config['reset_value']

                # 将结果重新链接到计算图
                return U.clone().requires_grad_(P_scaled.requires_grad)  # 梯度重新关联

    def _eigen_recovery(self, P):
        """特征值重构方法"""
        P_sym = self._make_symmetric(P)
        eigvals, eigvecs = torch.linalg.eigh(P_sym + 1e-12 * torch.eye(P_sym.shape[-1], device=P_sym.device))

        # 计算最小特征值
        min_eig = eigvals.min(dim=1).values

        # 动态调整epsilon
        dynamic_epsilon = torch.where(
            min_eig < 0,
            -min_eig + self.recovery_config['epsilon'],
            torch.zeros_like(min_eig)
        )

        # 批量修正特征值
        # 改为非inplace操作
        eigvals_new = eigvals + dynamic_epsilon.unsqueeze(1)  # 创建新张量
        P_reconstructed = eigvecs @ torch.diag_embed(eigvals_new) @ eigvecs.transpose(1, 2)
        return P_reconstructed

    def _make_symmetric(self, matrix):
        """
        确保矩阵是对称的
        """
        return (matrix + matrix.transpose(1, 2)) / 2

    def _check_positive_definite(self, matrix):
        """检查正定性（调试用）"""
        try:
            eigvals = torch.linalg.eigvalsh(matrix)
            return torch.all(eigvals[:, 0] > 1e-8)
        except RuntimeError:
            return False

    def batch_sigma_points(self, x, P, c):
        """
        批量生成 sigma 点。

        参数：
        - x: 均值张量，形状为 (batch_size, dim_state)
        - P: 协方差张量，形状为 (batch_size, dim_state, dim_state)
        - c: sigma 点缩放参数

        返回：
        - sigmas: sigma 点张量，形状为 (batch_size, 2 * dim_state + 1, dim_state)
        """
        batch_size, dim_x = x.shape
        num_sigmas = 2 * dim_x + 1

        # 添加断言确保批次一致性
        assert P.shape[0] == batch_size, f"P 的批次大小 {P.shape[0]} 与 x 的批次大小 {batch_size} 不一致"

        # 计算平方根矩阵，形状为 (batch_size, dim_state, dim_state)
        # 缩放协方差矩阵
        P_scaled = P * c

        try:
            U = self._core_cholesky(P_scaled)
            self.last_recovery_type = "direct"
        except RuntimeError as final_e:
            # 最终应急处理
            U = torch.eye(dim_x, device=self.device).expand_as(P_scaled) * \
                self.recovery_config['reset_value']
            self.last_recovery_type = "emergency_reset"
            self.recovery_counter += 1

        # 扩展 x，形状为 (batch_size, 1, dim_state)
        x = x.unsqueeze(1)

        # 初始化 sigma 点张量，形状为 (batch_size, num_sigmas, dim_state)
        sigmas = torch.zeros(batch_size, num_sigmas, dim_x, device=x.device)

        # 第一个 sigma 点是均值
        sigmas[:, 0, :] = x[:, 0, :]

        for k in range(dim_x):
            sigmas[:, k + 1, :] = x[:, 0, :] + U[:, :, k]
            sigmas[:, dim_x + k + 1, :] = x[:, 0, :] - U[:, :, k]

        return sigmas

    def predict(self, controls=None, dt=None):
        if dt is None:
            dt = self.dt

        # 计算 sigma 点
        sigmas = self.batch_sigma_points(self.x, self.P, self.c)
        current_fx = self.fx_factory.create_fx(controls)
        sigmas_f = current_fx(sigmas, dt)
        self.sigmas_f = sigmas_f

        # 更新状态 x
        self.x = torch.einsum('bni,n->bi', sigmas_f, self.Wm)
        self.x_prior = self.x
        # 计算 P
        x_diff = sigmas_f - self.x.unsqueeze(1)
        self.P = torch.einsum('n,bni,bnj->bij', self.Wc, x_diff, x_diff) + self.q
        self.P = self._make_symmetric(self.P)  # 强制对称

        # 调试检查
        if not self._check_positive_definite(self.P):
            print("Warning: Non-positive-definite P after prediction")
            self.recovery_counter += 1
    def update(self, z):
        # 获取自适应的R矩阵
        sigmas = self.batch_sigma_points(self.x, self.P, self.c)
        current_hx = self.hx_factory.create_hx()
        sigmas_h = current_hx(sigmas)
        z_pred = torch.einsum('bni,n->bi', sigmas_h, self.Wm)

        # 计算观测差异
        z_diff = sigmas_h - z_pred.unsqueeze(1)
        S = torch.einsum('n,bni,bnj->bij', self.Wc, z_diff, z_diff) + self.r

        # 计算交叉协方差
        x_diff = sigmas - self.x.unsqueeze(1)
        Pxz = torch.einsum('n,bni,bnj->bij', self.Wc, x_diff, z_diff)

        # 卡尔曼增益
        S_inv = torch.inverse(S)
        K = torch.einsum('bij,bjk->bik', Pxz, S_inv)

        # 更新状态 x 和协方差 P
        y = z - z_pred
        delta_x = torch.einsum('bik,bk->bi', K, y)
        self.x = (self.x + delta_x).clone()
        delta_P = torch.einsum('bik,bkj->bij', K, torch.einsum('bij,bjk->bik', S, K.transpose(1, 2)))
        self.P = (self.P - delta_P).clone()
        self.P = self._make_symmetric(self.P)  # 强制对称

        z_obs_diff = z - self.z_obs_previous
        z_innov_diff = z - z_pred
        x_posterior_diff = self.x - self.x_posterior_previous
        x_update_diff = self.x - self.x_prior_previous
        q_next = self.get_q(z_obs_diff.clone(), z_innov_diff.clone(), x_posterior_diff.clone(), x_update_diff.clone())
        self.q = q_next
        r_next = self.get_r(z_obs_diff.clone(), z_innov_diff.clone(), x_posterior_diff.clone(), x_update_diff.clone())
        self.r = r_next
        # 检查q_next和r_next是否有nan
        if torch.isnan(q_next).any() or torch.isnan(r_next).any():
            raise ValueError("q_next or r_next contains nan")

        self.z_obs_previous = z
        self.x_posterior_previous = self.x
        self.x_prior_previous = self.x_prior

        # print(self.r)

    def get_q(self, z_obs_diff, z_innov_diff, x_posterior_diff, x_prior_diff):
        # 获取自适应的 Q 矩阵，通过神经网络
        # 使用前向差异、更新差异来估算 Q
        q_diag, h_prev_q_new = self.nn_q(z_obs_diff, z_innov_diff, x_posterior_diff, x_prior_diff,
                                          h_prev=self.h_prev_q)
        if torch.isnan(q_diag).any():
            print(f"NaN detected in q_diag")
        # 对元组中的每个张量进行 detach
        if isinstance(h_prev_q_new, tuple):
            self.h_prev_q = tuple([h.detach() for h in h_prev_q_new])  # 处理 LSTM 的 (h, c)
        else:
            self.h_prev_q = h_prev_q_new.detach()  # 处理 GRU 的单一隐藏状态

        # 从 self.scaler_q 中提取对角线元素，形状为 (batch_size, dim_x)
        diag_elements = torch.diagonal(self.scaler_q, dim1=1, dim2=2)

        # 将 q_diag 的每个元素与对应的 diag_elements 相乘

        return torch.diag_embed(q_diag * diag_elements)

    def get_r(self, z_obs_diff, z_innov_diff, x_posterior_diff, x_prior_diff):
        # 获取自适应的 R 矩阵，通过神经网络
        # 使用前向差异、更新差异来估算 R
        r_diag, h_prev_r_new = self.nn_r(z_obs_diff, z_innov_diff, x_posterior_diff, x_prior_diff, h_prev=self.h_prev_r)
        if torch.isnan(r_diag).any():
            print(f"NaN detected in r_diag")
        # 对元组中的每个张量进行 detach
        if isinstance(h_prev_r_new, tuple):
            self.h_prev_r = tuple([h.detach() for h in h_prev_r_new])  # 处理 LSTM 的 (h, c)
        else:
            self.h_prev_r = h_prev_r_new.detach()  # 处理 GRU 的单一隐藏状态
        # 从 self.scaler_q 中提取对角线元素，形状为 (batch_size, dim_x)
        diag_elements = torch.diagonal(self.scaler_r, dim1=1, dim2=2)

        # 将 q_diag 的每个元素与对应的 diag_elements 相乘

        return torch.diag_embed(r_diag * diag_elements)
