# -*- coding: utf-8 -*-
"""
集合同化算法的单步实现。

这些算法提供与 FilterPy 一致的 predict()/update() 接口，
支持 streaming 模式的在线同化。

包含的算法：
- LETKF: 局部集合转换 Kalman 滤波
- EnKF_N: 有限集合修正的集合 Kalman 滤波
- ETKF: 集合转换 Kalman 滤波
- SL_EAKF: 随机局部化集合调整 Kalman 滤波

与 DAPPER 的区别：
- DAPPER 需要批量运行，预先定义所有时间步
- 这里的实现支持单步调用，适合实时/streaming 场景
"""

from .letkf import LETKF
from .enkf_n import EnKF_N
from .etkf import ETKF
from .sl_eakf import SL_EAKF

__all__ = [
    "LETKF",
    "EnKF_N",
    "ETKF",
    "SL_EAKF",
]

