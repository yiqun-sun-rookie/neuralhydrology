"""Re-score the learned-noise UKF learning-rate grid (9 learning rates, 11 run directories) on the VALIDATION set
under one code snapshot, with both aggregation conventions and both lead-time definitions.

Same protocol as rescore_checkpoints.py (neural-gain grid): lead_time = 13 -> slots 0..12, so that
  * slots 0..11 = the current code's "H1-12" (slot 0 = analysis value)
  * slots 1..12 = corrected definition (true 1..12 h forecasts)
Batch-weighted per-slot NSE reproduces the screening score the paper reported; pooled NSE is the paper's test convention.
Validation only; the held-out test split is blocked. Outputs: rescoring/ukf_lr_grid_rescore.{json,csv}
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

os.environ.setdefault("NO_TQDM", "1"); os.environ.setdefault("VALIDATION_QUIET", "1")
os.environ.setdefault("PERF_INTERVAL", "0"); os.environ.setdefault("EPOCH_SUMMARY", "0")
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
sys.path.insert(0, str(PROJECT))

import numpy as np
import torch
import yaml
from torch.utils.data import DataLoader

_orig_load = torch.load
def _guarded_load(f, *a, **k):
    try: name = Path(os.fspath(f)).name.lower()
    except TypeError: name = ""
    if name.startswith("test_") or "held_out_test" in name:
        raise RuntimeError(f"BLOCKED test-set load: {f}")
    return _orig_load(f, *a, **k)
torch.load = _guarded_load

from experiments.optimize_hyper_parameters.train_and_eval import build_args, build_trainable_kf  # noqa: E402
import knet.utils.model_initialization_use_script_mdl_1 as _init_mod  # noqa: E402
from knet.pipelines.pipeline_clean_based_on_11 import Pipeline  # noqa: E402
from knet.pipelines.train_clean_based_on_11 import initialize_training, run_one_epoch  # noqa: E402

VAL_PT = PROJECT / "data/processed/high_flow_aug/val_win800_20070527_04-20090314_13.pt"
VAL_SHA = "2e195fc974b5cc8cdb35df3cb7fd72a202af033ecc415acc03a87020b00bd403"
GRID = PROJECT / "experiments/optimize_hyper_parameters/benchmark_tuning/lr_grid_runs"
PAPER_UKF = GRID / "idx0007_lrextra0030/results/results/best_model.pt"
OUT_DIR = HERE / "rescoring"
LEAD = 13
BATCH = 2048


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


class Acc:
    def __init__(self, L):
        self.L = L; self.n = np.zeros(L); self.sy = np.zeros(L); self.sy2 = np.zeros(L); self.sse = np.zeros(L)
        self.bw_num = np.zeros(L); self.bw_den = 0.0; self.n_windows = 0
    def update(self, d):
        fc = d["outputs_fc_win"].numpy().astype(np.float64).reshape(-1, self.L)
        ob = d["y_obs_win"].numpy().astype(np.float64).reshape(-1, self.L); nb = fc.shape[0]
        for lt in range(self.L):
            o = ob[:, lt]; s = fc[:, lt]
            self.n[lt] += len(o); self.sy[lt] += o.sum(); self.sy2[lt] += (o*o).sum(); self.sse[lt] += ((o-s)**2).sum()
            self.bw_num[lt] += (1.0 - ((o-s)**2).sum() / (((o-o.mean())**2).sum() + 1e-8)) * nb
        self.bw_den += nb; self.n_windows += nb
    def results(self):
        nse, rmse = [], []
        for lt in range(self.L):
            m = self.sy[lt]/self.n[lt]; sst = self.sy2[lt] - self.n[lt]*m**2
            nse.append(float(1.0 - self.sse[lt]/sst)); rmse.append(float(np.sqrt(self.sse[lt]/self.n[lt])))
        return nse, rmse, [float(x/self.bw_den) for x in self.bw_num]


class SP(list):
    def __init__(self, acc): super().__init__(); self.acc = acc
    def append(self, d): self.acc.update(d)


class StreamingPipeline(Pipeline):
    def __init__(self, *a, **k): super().__init__(*a, **k); self._sp = None
    def set_streaming(self, sp): self._sp = sp; self.predictions = sp
    def __setattr__(self, name, value):
        if name == "predictions" and getattr(self, "_sp", None) is not None and isinstance(value, list) and not isinstance(value, SP):
            return
        super().__setattr__(name, value)


def find_ckpt(d: Path):
    for c in (d/"results/results/best_model.pt", d/"results/best_model.pt"):
        if c.is_file(): return c
    hits = sorted(d.rglob("best_model.pt"))
    return hits[0] if hits else None


def load_cfg(d: Path) -> dict:
    p = d/"config_effective.yaml"
    if not p.is_file():
        p = PROJECT/"experiments/optimize_hyper_parameters/trainable_kf_config.yaml"
    cfg = yaml.safe_load(p.read_text(encoding="utf-8"))
    cfg["model"]["type"] = "trainable_ukf"
    cfg["data"]["dataset_path"] = {"val": str(VAL_PT)}          # validation only, no test path anywhere
    cfg["training"]["forecast_lead_time"] = LEAD
    cfg["dataloader"]["batch_size"] = BATCH
    cfg["runtime"]["device"] = "cuda"
    return cfg, str(p)


def evaluate(d: Path, val_ds, loader):
    cfg, cfg_path = load_cfg(d)
    ck_path = find_ckpt(d)
    sample_p = val_ds[0]["p"]; sample_p = sample_p.squeeze() if sample_p.ndim > 1 else sample_p
    args = build_args(cfg, sample_p, sample_p); args.device = "cuda"
    sys_model = _init_mod.initialize_system_model(args.train_seq_len, args.seq_len_val, device="cuda")
    model = build_trainable_kf(cfg, sys_model, args).to("cuda")
    ck = torch.load(ck_path, map_location="cuda", weights_only=False)
    sd = ck["model_state_dict"] if isinstance(ck, dict) and "model_state_dict" in ck else ck
    model.load_state_dict(sd, strict=True)
    pipe = StreamingPipeline(str(OUT_DIR/"pipe_tmp_ukf")); pipe.set_sys_model(sys_model); pipe.set_knet_model(model); pipe.set_train_params(args)
    pipe.save_predictions = True; pipe.display_metrics_list = ["nse"]
    initialize_training(pipe, loader, loader)
    acc = Acc(LEAD); pipe.set_streaming(SP(acc))
    t0 = time.time()
    with torch.no_grad():
        avg_bp, avg_disp = run_one_epoch(pipe, loader, 0, is_training=False)
    nse, rmse, bw = acc.results()
    # learned noise parameters, for the record
    learned = {k: (v.detach().cpu().flatten().tolist()[:6]) for k, v in model.state_dict().items() if v.numel() <= 6}
    out = {
        "run_dir": d.name, "config_used": cfg_path, "lr": float(cfg["training"].get("learning_rate", float("nan"))),
        "checkpoint": str(ck_path), "checkpoint_sha256": sha256(ck_path), "checkpoint_epoch_field": int(ck.get("epoch", -1)) if isinstance(ck, dict) else None,
        "is_paper_checkpoint": ck_path.resolve() == PAPER_UKF.resolve(),
        "seconds": round(time.time()-t0, 1), "n_windows": acc.n_windows, "val_bp_loss_L13": float(avg_bp),
        "pooled_nse_slot": [round(x, 6) for x in nse], "pooled_rmse_slot": [round(x, 6) for x in rmse], "batchweighted_nse_slot": [round(x, 6) for x in bw],
        "pooled_mean_slots_0_11_current_def": round(float(np.mean(nse[0:12])), 6),
        "pooled_mean_slots_1_12_corrected_def": round(float(np.mean(nse[1:13])), 6),
        "screening_bw_slots_0_11_current_def": round(float(np.mean(bw[0:12])), 6),
        "screening_bw_slots_1_12_corrected_def": round(float(np.mean(bw[1:13])), 6),
        "learned_small_tensors": learned,
    }
    del model, sys_model, pipe; torch.cuda.empty_cache()
    return out


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    torch.manual_seed(42)
    assert sha256(VAL_PT) == VAL_SHA, "validation file hash mismatch"
    val_ds = torch.load(VAL_PT, map_location="cpu", weights_only=False)
    loader = DataLoader(val_ds, batch_size=BATCH, shuffle=False, num_workers=0)
    dirs = [d for d in sorted(GRID.glob("idx*")) if d.is_dir() and find_ckpt(d)]
    print(f"[ukf-rescore] {len(dirs)} run dirs with a best_model.pt; lead_time={LEAD}; device={torch.cuda.get_device_name(0)}", flush=True)
    results = []
    for i, d in enumerate(dirs, 1):
        try:
            r = evaluate(d, val_ds, loader)
        except Exception as exc:
            r = {"run_dir": d.name, "error": f"{type(exc).__name__}: {exc}"}
        results.append(r)
        print(f"[{i}/{len(dirs)}] {d.name} lr={r.get('lr')} cur={r.get('pooled_mean_slots_0_11_current_def')} corr={r.get('pooled_mean_slots_1_12_corrected_def')} bw_cur={r.get('screening_bw_slots_0_11_current_def')} paper={r.get('is_paper_checkpoint')} err={r.get('error')}", flush=True)
        (OUT_DIR/"ukf_lr_grid_rescore.json").write_text(json.dumps({"generated_at": datetime.now().isoformat(timespec="seconds"), "validation_sha256": VAL_SHA,
            "lead_time": LEAD, "batch_size": BATCH, "device": torch.cuda.get_device_name(0), "torch": torch.__version__, "results": results}, indent=2), encoding="utf-8")
    cols = ["run_dir", "lr", "is_paper_checkpoint", "checkpoint_epoch_field", "pooled_mean_slots_0_11_current_def", "pooled_mean_slots_1_12_corrected_def",
            "screening_bw_slots_0_11_current_def", "screening_bw_slots_1_12_corrected_def", "val_bp_loss_L13", "error"]
    with (OUT_DIR/"ukf_lr_grid_rescore.csv").open("w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore"); w.writeheader()
        for r in results: w.writerow({c: r.get(c) for c in cols})
    print("[done]", OUT_DIR/"ukf_lr_grid_rescore.json", flush=True)


if __name__ == "__main__":
    main()
