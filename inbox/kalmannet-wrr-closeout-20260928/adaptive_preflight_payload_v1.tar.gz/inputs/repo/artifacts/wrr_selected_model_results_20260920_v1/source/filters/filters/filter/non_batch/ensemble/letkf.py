# -*- coding: utf-8 -*-
"""
LETKF - 局部集合转换 Kalman 滤波器

单步实现，支持 predict()/update() 接口。

参考文献:
- Hunt et al. (2007): Efficient Data Assimilation for Spatiotemporal Chaos
"""

from __future__ import annotations

from typing import Callable, Optional

import numpy as np
from scipy.linalg import sqrtm, svd

from .etkf import ETKF


class LETKF(ETKF):
    """
    局部集合转换 Kalman 滤波器。
    
    LETKF 在 ETKF 基础上增加了局部化，对每个状态变量独立进行更新，
    使用局部化函数减少远距离观测的影响。
    
    参数
    ----------
    dim_x : int
        状态维度
    dim_z : int
        观测维度
    fx : callable
        状态转移函数
    hx : callable
        观测函数
    N : int
        集合成员数量
    loc_radius : float
        局部化半径，默认 None（无局部化，退化为 ETKF）
    loc_func : str
        局部化函数类型: 'gaspari_cohn', 'exponential', 'boxcar'
    **kwargs
        其他参数传递给 ETKF
    """
    
    def __init__(
        self,
        dim_x: int,
        dim_z: int,
        fx: Callable,
        hx: Callable,
        N: int = 20,
        loc_radius: Optional[float] = None,
        loc_func: str = "gaspari_cohn",
        **kwargs
    ):
        super().__init__(dim_x, dim_z, fx, hx, N=N, **kwargs)
        
        self.loc_radius = loc_radius
        self.loc_func = loc_func
        
        # 状态-观测距离矩阵（用户可设置）
        # 默认假设所有状态变量与所有观测等距离
        self._state_obs_distances = None
    
    def set_localization(
        self,
        distances: Optional[np.ndarray] = None,
        radius: Optional[float] = None,
    ):
        """
        设置局部化参数。
        
        参数
        ----------
        distances : ndarray, shape (dim_x, dim_z)
            状态变量与观测之间的距离矩阵
        radius : float
            局部化半径
        """
        if distances is not None:
            self._state_obs_distances = np.asarray(distances, dtype=float)
        if radius is not None:
            self.loc_radius = radius
    
    def _localization_weights(self) -> np.ndarray:
        """计算局部化权重矩阵 (dim_x, dim_z)。"""
        if self.loc_radius is None or self._state_obs_distances is None:
            # 无局部化
            return np.ones((self.dim_x, self.dim_z))
        
        d = self._state_obs_distances
        r = self.loc_radius
        
        if self.loc_func == "gaspari_cohn":
            return self._gaspari_cohn(d, r)
        elif self.loc_func == "exponential":
            return np.exp(-(d / r) ** 2)
        elif self.loc_func == "boxcar":
            return (d <= r).astype(float)
        else:
            return np.ones((self.dim_x, self.dim_z))
    
    @staticmethod
    def _gaspari_cohn(d: np.ndarray, r: float) -> np.ndarray:
        """Gaspari-Cohn 局部化函数。"""
        c = r / np.sqrt(0.3)  # 转换为 GC 参数
        z = np.abs(d) / c
        
        weights = np.zeros_like(z)
        
        # 0 <= z <= 1
        mask1 = z <= 1
        z1 = z[mask1]
        weights[mask1] = (
            1 - 5/3 * z1**2 + 5/8 * z1**3 + z1**4 / 2 - z1**5 / 4
        )
        
        # 1 < z <= 2
        mask2 = (z > 1) & (z <= 2)
        z2 = z[mask2]
        weights[mask2] = (
            4 - 5 * z2 + 5/3 * z2**2 + 5/8 * z2**3 
            - z2**4 / 2 + z2**5 / 12 - 2 / (3 * z2)
        )
        
        # z > 2
        weights[z > 2] = 0
        
        return np.maximum(weights, 0)
    
    def update(self, z: np.ndarray, **kwargs):
        """
        局部化更新步。
        
        如果设置了局部化参数，对每个状态变量独立更新；
        否则退化为标准 ETKF 更新。
        """
        z = np.asarray(z, dtype=float).reshape(-1)
        
        # 计算观测集合
        Y = np.zeros((self.dim_z, self.N))
        for i in range(self.N):
            Y[:, i] = np.asarray(self._hx(self.E[:, i]), dtype=float).reshape(-1)
        
        y_mean = Y.mean(axis=1, keepdims=True)
        S = Y - y_mean  # (dim_z, N)
        d = z.reshape(-1, 1) - y_mean  # (dim_z, 1)
        A = self._anomalies()  # (dim_x, N)
        
        # 获取局部化权重
        loc_weights = self._localization_weights()  # (dim_x, dim_z)
        
        if self.loc_radius is None:
            # 无局部化，使用全局 ETKF 更新
            super().update(z)
            return
        
        # 逐状态变量局部化更新
        R_inv = np.linalg.inv(self.R)
        mean = self.E.mean(axis=1, keepdims=True)
        E_new = np.zeros_like(self.E)
        
        for j in range(self.dim_x):
            # 该状态变量的局部化权重
            w_j = loc_weights[j, :].reshape(-1, 1)  # (dim_z, 1)
            
            # 局部化的 R^{-1}
            R_inv_loc = R_inv * (w_j @ w_j.T)
            
            # 局部化的 ETKF 更新
            C = S.T @ R_inv_loc @ S / (self.N - 1)
            I = np.eye(self.N)
            Pa_tilde = np.linalg.inv(I + C)
            
            T = self._matrix_sqrt(Pa_tilde)
            if self.rot:
                T = T @ self._random_orthogonal(self.N)
            
            w = Pa_tilde @ S.T @ R_inv_loc @ d / (self.N - 1)
            
            # 更新该状态变量的集合
            E_new[j, :] = mean[j, 0] + A[j:j+1, :] @ w + A[j:j+1, :] @ T
        
        self.E = E_new


__all__ = ["LETKF"]

