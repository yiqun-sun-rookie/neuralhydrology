import torch
import torch.nn as nn
def forward_sequence(pipeline, y_obs, controls):
    batch_size = y_obs.size(0)
    seq_len = y_obs.size(-1)
    states_upd = torch.zeros([batch_size, pipeline.sys_model.m, seq_len]).to(pipeline.device)
    # 动态重置 UKF 状态
    pipeline.target_model.reset_for_batch(batch_size)
    # # 初始化UKF状态
    # pipeline.target_model.x = pipeline.target_model.x0.clone()
    # pipeline.target_model.P = pipeline.target_model.P0.clone()
    # pipeline.target_model.h_prev_q = pipeline.target_model.nn_q.init_hidden()
    # pipeline.target_model.h_prev_r = pipeline.target_model.nn_r.init_hidden()

    for t in range(seq_len):
        # UKF预测步骤（传入当前控制量）
        pipeline.target_model.predict(controls=controls[:, :, t], dt=1.0)

        # UKF更新步骤
        pipeline.target_model.update(z=y_obs[:, :, t])

        # 记录更新后状态
        states_upd[:, :, t] = pipeline.target_model.x.clone()

    return states_upd

def compute_forecast_loss(outputs_forecast_flat, y_obs_rearranged, metric_mode="nse"):
    """
    计算预测输出与观测数据之间的损失。

    参数:
        outputs_forecast_flat (torch.Tensor): 预测的输出，形状 [batch_size, feasible_timesteps, n, lead_time]
        y_obs_rearranged (torch.Tensor): 重组后的观测数据，形状 [batch_size, feasible_timesteps, n, lead_time]
        metric_mode (str): 选择的度量指标，如 "mse" 或 "nse"

    返回:
        total_loss (torch.Tensor): 标量损失值
    """
    # 确保输出和观测数据的尺寸一致
    assert outputs_forecast_flat.size() == y_obs_rearranged.size()

    # 根据选择的度量指标计算损失
    loss_map = multi_metric_loss(outputs_forecast_flat, y_obs_rearranged, metric_mode)

    # 聚合 n 维度
    loss_map = loss_map.mean(dim=2)  # [batch_size, feasible_timesteps, lead_time]

    # 选择一个度量方式来聚合 lead_time 方向的损失
    total_loss = weighted_leadtime_loss(
        loss_map,
        lead_time=loss_map.shape[-1],
        weighting_mode="linear",  # 可选: "exponential", "custom", "none"
        start_weight=1.0,
        end_weight=0.5
    )
    # total_loss 形状: [batch_size, feasible_timesteps]

    # 聚合 batch_size 和 feasible_timesteps
    loss_avg = total_loss.mean()  # 标量

    return loss_avg
def system_model_forecast(sys_model, p, etpot, states_updated, lead_time=12):
    """
    进行系统模型的前向预测。

    参数:
        sys_model: 系统模型对象，需具有 f 和 h 方法。
        p (torch.Tensor): 降雨数据，形状 [batch_size, 1, Timesteps]
        etpot (torch.Tensor): 蒸发数据，形状 [batch_size, 1, Timesteps]
        states_updated (torch.Tensor): 更新后的状态，形状 [batch_size, m, Timesteps]
        lead_time (int): 预测的时间步长

    返回:
        states_forecast_flat (torch.Tensor): 预测的状态，形状 [batch_size, feasible_timesteps, m, lead_time]
        outputs_forecast_flat (torch.Tensor): 预测的输出，形状 [batch_size, feasible_timesteps, n, lead_time]
    """
    # 确保输入参数的维度
    assert p.dim() == 3 and etpot.dim() == 3 and states_updated.dim() == 3
    assert p.size(0) == etpot.size(0) == states_updated.size(0)
    assert p.size(1) == etpot.size(1) == 1
    assert states_updated.size(1) == sys_model.m
    assert p.size(2) == etpot.size(2) == states_updated.size(2)

    batch_size = p.size(0)
    num_timesteps = p.size(2)
    feasible_timesteps = num_timesteps - lead_time + 1
    total_samples = batch_size * feasible_timesteps

    # 重组输入数据为 [batch_size, feasible_timesteps, lead_time]
    p_rearranged = rearrange_data_unfold(p, lead_time)
    etpot_rearranged = rearrange_data_unfold(etpot, lead_time)

    # 断言重组后的尺寸
    assert p_rearranged.size(0) == etpot_rearranged.size(0) == batch_size
    assert p_rearranged.size(1) == etpot_rearranged.size(1) == feasible_timesteps
    assert p_rearranged.size(2) == etpot_rearranged.size(2) == lead_time

    # 重塑输入为 [total_samples, lead_time]
    p_flat = p_rearranged.reshape(total_samples, lead_time)
    etpot_flat = etpot_rearranged.reshape(total_samples, lead_time)

    # 重塑状态为 [total_samples, m]
    states_reshaped = states_updated[:, :, :feasible_timesteps].permute(0, 2, 1).reshape(total_samples, sys_model.m).clone()
    assert states_reshaped.size(0) == total_samples and states_reshaped.size(1) == sys_model.m

    # 初始化列表，添加初始状态和初始输出
    states_forecast_list = [states_reshaped]
    initial_output = sys_model.h(states_reshaped)
    outputs_forecast_list = [initial_output]

    # 预测循环
    controls = torch.stack((p_flat, etpot_flat), dim=2)  # [total_samples, lead_time, 2]
    for lt in range(1, lead_time):
        controls_lt = controls[:, lt, :]  # [total_samples, 2]

        # 前向传播
        next_state = sys_model.f(states_forecast_list[-1], controls_lt)  # [total_samples, m]
        next_output = sys_model.h(next_state)  # [total_samples, n]

        # 添加到列表
        states_forecast_list.append(next_state)
        outputs_forecast_list.append(next_output)

    # 将列表转换为张量
    states_forecast_flat = torch.stack(states_forecast_list, dim=2)   # [total_samples, m, lead_time]
    outputs_forecast_flat = torch.stack(outputs_forecast_list, dim=2) # [total_samples, n, lead_time]

    return states_forecast_flat, outputs_forecast_flat



@torch.jit.script
def rearrange_data_unfold(p: torch.Tensor, lead_time: int) -> torch.Tensor:
    """
    使用 torch.unfold 重排输入张量 `p`，根据指定的前置时间步长（lead_time）形成批次。

    参数：
        p (torch.Tensor): 输入张量，形状为 [batch_size, 1, num_timesteps]。
        lead_time (int): 用于形成批次的前置时间步长。

    返回：
        torch.Tensor: 重排后的张量，形状为 [batch_size, feasible_timesteps, lead_time]。
    """
    batch_size, _, num_timesteps = p.size()

    # 去除通道维度（如果存在）
    p = p.squeeze(1)  # 现在 p 的形状为 [batch_size, num_timesteps]

    # 使用 unfold 提取滑动窗口
    p_unfolded = p.unfold(dimension=1, size=lead_time, step=1)  # [batch_size, feasible_timesteps, lead_time]

    return p_unfolded

def weighted_leadtime_loss(
        loss_forecast: torch.Tensor,
        lead_time: int,
        weighting_mode: str = "linear",
        device: torch.device = torch.device("cuda"),
        start_weight: float = 1.0,
        end_weight: float = 0.2,
        base: float = 0.9,
        custom_weights: torch.Tensor = None
) -> torch.Tensor:
    """
    计算对多步预测误差(lead_time方向)加权后的总损失，并始终进行权重归一化。

    参数：
        loss_forecast (torch.Tensor):
            预测误差张量，形状 [batch_size, lead_time]。

        lead_time (int):
            预测的时间步数，与 loss_forecast 的第二维度保持一致。

        weighting_mode (str, optional):
            加权模式，可选值：["linear", "exponential", "custom", "none"]。
            - "linear":     从 start_weight 线性衰减至 end_weight
            - "exponential":指数衰减, start_weight * base^(0..lead_time-1)
            - "custom":     使用 custom_weights 直接作为加权向量
            - "none":       不做特殊加权(等权)

        device (torch.device, optional):
            计算设备 (CPU 或 GPU)。默认 CPU。

        start_weight (float, optional):
            用于 "linear" 或 "exponential" 模式下的起始权重。

        end_weight (float, optional):
            用于 "linear" 模式下的结束权重。

        base (float, optional):
            用于 "exponential" 模式下的衰减基数(0<base<1时衰减,>1则递增)。

        custom_weights (torch.Tensor, optional):
            当模式为 "custom" 时，需要形状为 [lead_time] 的自定义权重。

    返回：
        torch.Tensor:
            单一标量损失值 (scalar)，可直接用于 backward()。

    示例：
        >>> # loss_forecast=[batch_size, lead_time]
        >>> # 让短期(lead_time=1)权重大，长期渐小
        >>> total_loss = weighted_leadtime_loss(
        ...     loss_forecast, lead_time=5, weighting_mode="linear",
        ...     start_weight=1.0, end_weight=0.5
        ... )
        >>> total_loss.backward()
    """

    # 1. 先对 batch 维度进行平均: [batch_size, lead_time] -> [lead_time]
    loss_per_lt = torch.mean(loss_forecast, dim=0)  # [lead_time]

    # 2. 根据模式生成对应的权重向量 weights: [lead_time]
    if weighting_mode == "linear":
        # 在 [start_weight, end_weight] 范围内均匀插值
        weights = torch.linspace(start_weight, end_weight, steps=lead_time, device=device)

    elif weighting_mode == "exponential":
        # 从 start_weight 开始，指数衰减(或递增)
        exps = torch.arange(lead_time, dtype=torch.float32, device=device)
        # 例: base=0.9, start_weight=1.0 -> [1.0,0.9,0.81,0.729,...]
        weights = start_weight * (base ** exps)

    elif weighting_mode == "custom":
        # 需您自行传入 custom_weights, 形状为 [lead_time]
        if custom_weights is None:
            raise ValueError("在 'custom' 模式下，请传入 custom_weights。")
        if custom_weights.size(0) != lead_time:
            raise ValueError(f"custom_weights.size(0)={custom_weights.size(0)} != lead_time={lead_time}")
        weights = custom_weights.to(device)

    else:
        # "none": 等权, 也可直接写成 torch.ones(lead_time, device=device)
        weights = torch.ones(lead_time, device=device)

    # 归一化 
    # 将所有权重之和归一到1，使它们变成各自占比
    weights_sum = torch.sum(weights)
    if weights_sum.item() == 0.0:
        raise ValueError("权重和为0，无法归一化。请检查weights或更换加权模式。")

    weights = weights / weights_sum

    # 3. 计算加权后的损失: loss_per_lt * weights，再做 sum 得到标量
    weighted_loss = torch.sum(loss_per_lt * weights)

    return weighted_loss


def multi_metric_loss(
        predictions: torch.Tensor,
        targets: torch.Tensor,
        metric: str = "mse"
) -> torch.Tensor:
    """
    计算不同指标对应的逐元素误差张量 (batch_size, lead_time)。

    参数：
        predictions (torch.Tensor): 预测值, 形状 [batch_size, lead_time].
        targets (torch.Tensor):     观测值, 形状 [batch_size, lead_time].
        metric (str):              指标类型, 可选 "mse" 或 "nse".

    返回：
        torch.Tensor: 形状 [batch_size, lead_time] 的误差张量。
          - 对 "mse" 而言, 每个元素 = (pred - obs)^2.
          - 对 "nse" 而言, 每个元素代表 1 - NSE 的局部贡献, 数值越小越好.
    """
    assert predictions.shape == targets.shape, "预测值与观测值形状不符"
    batch_size, lead_time = predictions.shape

    if metric.lower() == "mse":
        # 逐元素 MSE
        # shape = [batch_size, lead_time]
        loss_fn = nn.MSELoss(reduction='none')
        loss_map = loss_fn(predictions, targets)

    elif metric.lower() == "nse":
        # 计算 1 - NSE(lead_time) 或等价的 numerator/denominator
        # numerator = sum((obs - pred)^2) over batch
        # denominator= sum((obs - mean(obs))^2) over batch
        # nse = 1 - numerator/denominator => nse_loss = numerator/denominator
        # shape => [lead_time].
        # 然后再广播成 [batch_size, lead_time].

        # 1) 先计算 mean(obs) along batch 维度 -> [1, lead_time]
        with torch.no_grad():
            obs_mean = targets.mean(dim=0, keepdim=True)  # shape=[1, lead_time]

        # 2) numerator: sum((obs - pred)^2) over batch
        numerator_lt = ((targets - predictions) ** 2).sum(dim=0)  # shape=[lead_time]

        # 3) denominator: sum((obs - obs_mean)^2) over batch
        denominator_lt = ((targets - obs_mean) ** 2).sum(dim=0) + 1e-8  # 避免除0

        nse_loss_lt = numerator_lt / denominator_lt  # shape=[lead_time], 这就是 1-NSE
        # 4) 广播回 [batch_size, lead_time]
        # 让每个batch的同一lead_time位置都相等
        loss_map = nse_loss_lt.unsqueeze(0).expand(batch_size, -1)

    else:
        raise ValueError(f"不支持的指标类型: {metric}. 可选: 'mse' or 'nse'.")

    return loss_map  # shape=[batch_size, lead_time]
