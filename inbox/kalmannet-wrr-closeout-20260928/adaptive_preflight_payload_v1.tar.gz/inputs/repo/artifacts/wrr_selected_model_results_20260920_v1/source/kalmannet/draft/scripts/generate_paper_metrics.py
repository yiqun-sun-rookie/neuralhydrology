"""
generate_paper_metrics.py — Unified on-the-fly streaming eval for all paper numbers.

Produces paper_metrics.json with:
  - per_lead_nse (4 models x H1-H48)
  - regime breakdown (H12, H24)
  - rmse/mae
  - bootstrap CI (H12)
  - learned Q/R
  - provenance metadata

Usage:
  python draft/scripts/generate_paper_metrics.py --lead-time 48 --output draft/artifacts/paper_metrics.json
"""
import sys
import json
import argparse
import hashlib
import gc
import time
import subprocess
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader
import yaml

project_root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(project_root))

AREA_KM2 = 957
MMH_TO_M3S = AREA_KM2 * 1000.0 / 3600.0


# ============================================================================
# RunningNSE — per-lead-time sufficient statistics
# ============================================================================
class RunningNSE:
    def __init__(self, max_lt):
        self.max_lt = max_lt
        self.count = np.zeros(max_lt, dtype=np.float64)
        self.sum_obs = np.zeros(max_lt, dtype=np.float64)
        self.sum_obs_sq = np.zeros(max_lt, dtype=np.float64)
        self.sse = np.zeros(max_lt, dtype=np.float64)

    def update(self, fc: np.ndarray, obs: np.ndarray):
        if fc.ndim == 3:
            fc = fc.reshape(-1, fc.shape[-1])
            obs = obs.reshape(-1, obs.shape[-1])
        L = min(fc.shape[-1], self.max_lt)
        for lt in range(L):
            o = obs[:, lt].astype(np.float64)
            s = fc[:, lt].astype(np.float64)
            mask = ~np.isnan(o) & ~np.isnan(s)
            o, s = o[mask], s[mask]
            n = len(o)
            if n == 0:
                continue
            self.count[lt] += n
            self.sum_obs[lt] += o.sum()
            self.sum_obs_sq[lt] += (o * o).sum()
            self.sse[lt] += ((o - s) ** 2).sum()

    def results(self):
        nse = np.full(self.max_lt, np.nan)
        for lt in range(self.max_lt):
            if self.count[lt] > 0:
                mean_o = self.sum_obs[lt] / self.count[lt]
                sst = self.sum_obs_sq[lt] - self.count[lt] * mean_o ** 2
                if sst > 0:
                    nse[lt] = 1.0 - self.sse[lt] / sst
        return nse


# ============================================================================
# RunningRegimeStats — per-lead, per-regime sufficient statistics
# ============================================================================
class RunningRegimeStats:
    def __init__(self, max_lt, q25, q75):
        self.max_lt = max_lt
        if np.isscalar(q25):
            self.q25 = np.full(max_lt, q25)
            self.q75 = np.full(max_lt, q75)
        else:
            self.q25 = np.pad(q25, (0, max(0, max_lt - len(q25))), mode='edge')
            self.q75 = np.pad(q75, (0, max(0, max_lt - len(q75))), mode='edge')
        self.regimes = ['all', 'low', 'mid', 'high']
        self.stats = {r: {
            'n': np.zeros(max_lt, dtype=np.float64),
            'sy': np.zeros(max_lt, dtype=np.float64),
            'sy2': np.zeros(max_lt, dtype=np.float64),
            'sp': np.zeros(max_lt, dtype=np.float64),
            'sp2': np.zeros(max_lt, dtype=np.float64),
            'spo': np.zeros(max_lt, dtype=np.float64),
            'sse': np.zeros(max_lt, dtype=np.float64),
            'ae': np.zeros(max_lt, dtype=np.float64),
        } for r in self.regimes}
        # Per-batch stats for bootstrap (list of dicts)
        self.batch_stats = []
        self.n_batches = 0

    def update(self, fc, obs):
        if fc.ndim == 3:
            fc = fc.reshape(-1, fc.shape[-1])
            obs = obs.reshape(-1, obs.shape[-1])
        L = min(fc.shape[-1], self.max_lt)

        # Per-batch sufficient stats for bootstrap
        batch_n = np.zeros(L, dtype=np.float64)
        batch_sy = np.zeros(L, dtype=np.float64)
        batch_sy2 = np.zeros(L, dtype=np.float64)
        batch_sse = np.zeros(L, dtype=np.float64)

        for lt in range(L):
            o = obs[:, lt].astype(np.float64)
            s = fc[:, lt].astype(np.float64)
            valid = ~np.isnan(o) & ~np.isnan(s)
            o, s = o[valid], s[valid]
            if len(o) == 0:
                continue
            err = o - s
            # Batch-level stats (all regime)
            batch_n[lt] = len(o)
            batch_sy[lt] = o.sum()
            batch_sy2[lt] = (o ** 2).sum()
            batch_sse[lt] = (err ** 2).sum()
            # Regime masks
            masks = {
                'all': np.ones(len(o), dtype=bool),
                'low': o < self.q25[lt],
                'mid': (o >= self.q25[lt]) & (o <= self.q75[lt]),
                'high': o > self.q75[lt],
            }
            for r, m in masks.items():
                n = int(m.sum())
                if n == 0:
                    continue
                self.stats[r]['n'][lt] += n
                self.stats[r]['sy'][lt] += o[m].sum()
                self.stats[r]['sy2'][lt] += (o[m] ** 2).sum()
                self.stats[r]['sp'][lt] += s[m].sum()
                self.stats[r]['sp2'][lt] += (s[m] ** 2).sum()
                self.stats[r]['spo'][lt] += (s[m] * o[m]).sum()
                self.stats[r]['sse'][lt] += (err[m] ** 2).sum()
                self.stats[r]['ae'][lt] += np.abs(err[m]).sum()
        self.batch_stats.append({
            'n': batch_n, 'sy': batch_sy, 'sy2': batch_sy2, 'sse': batch_sse,
        })
        self.n_batches += 1


# ============================================================================
# Helper functions
# ============================================================================
def nse_from_stats(n, sy, sy2, sse):
    if n == 0:
        return float('nan')
    den = sy2 - (sy ** 2 / n)
    return float(1 - sse / den) if den > 0 else float('nan')


def kge_from_stats(n, sy, sy2, sp, sp2, spo):
    """Compute KGE from sufficient statistics."""
    if n < 2:
        return float('nan'), float('nan'), float('nan'), float('nan')
    mean_o = sy / n
    mean_s = sp / n
    var_o = sy2 / n - mean_o ** 2
    var_s = sp2 / n - mean_s ** 2
    if var_o <= 0 or var_s <= 0:
        return float('nan'), float('nan'), float('nan'), float('nan')
    std_o = np.sqrt(var_o)
    std_s = np.sqrt(var_s)
    r = (spo / n - mean_o * mean_s) / (std_o * std_s)
    alpha = std_s / std_o
    beta = mean_s / mean_o if mean_o != 0 else float('nan')
    kge = 1.0 - np.sqrt((r - 1) ** 2 + (alpha - 1) ** 2 + (beta - 1) ** 2)
    return float(kge), float(r), float(alpha), float(beta)


def rmse_from_stats(n, sse):
    return float(np.sqrt(sse / n)) if n > 0 else float('nan')


def mae_from_stats(n, ae):
    return float(ae / n) if n > 0 else float('nan')


def bootstrap_nse(n_arr, sy_arr, sy2_arr, sse_arr, n_boot=10000, seed=42):
    """Bootstrap NSE from per-batch sufficient statistics.

    Each input is shape [n_batches]. Returns array of shape [n_boot].
    """
    rng = np.random.RandomState(seed)
    n_batches = len(n_arr)
    nse_samples = np.zeros(n_boot, dtype=np.float64)
    for i in range(n_boot):
        idx = rng.randint(0, n_batches, size=n_batches)
        N = n_arr[idx].sum()
        SY = sy_arr[idx].sum()
        SY2 = sy2_arr[idx].sum()
        SSE = sse_arr[idx].sum()
        den = SY2 - SY ** 2 / N
        nse_samples[i] = 1 - SSE / den if den > 0 else np.nan
    return nse_samples


def md5_file(path):
    """Compute MD5 hash of a file."""
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def git_commit_hash():
    """Get current git short hash."""
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=str(project_root), text=True,
        ).strip()
    except Exception:
        return "unknown"


# ============================================================================
# Imports for model evaluation (legacy pipeline)
# ============================================================================
from experiments.optimize_hyper_parameters.train_and_eval import build_args, build_knet, build_trainable_kf
import knet.utils.model_initialization_use_script_mdl_1 as _init_mod
from knet.pipelines.pipeline_clean_based_on_11 import Pipeline
from knet.pipelines.train_clean_based_on_11 import initialize_training, run_one_epoch
from knet.modules.pipeline.walrus_batch_speedup import WalrusBatch
from knet.modules.pipeline.core_fun import system_model_forecast, rearrange_data_unfold

_original_init_sys_model = _init_mod.initialize_system_model

# External dependency: filters package (for hand-tuned UKF)
import types
import knet.modules
import knet.modules.pipeline
import knet.modules.nn
sys.modules['src'] = types.ModuleType('src')
sys.modules['src.modules'] = knet.modules
sys.modules['src.modules.pipeline'] = knet.modules.pipeline
sys.modules['src.modules.nn'] = knet.modules.nn


# ============================================================================
# Config and checkpoint paths
# ============================================================================
LOCAL_CONFIG_PATH = project_root / "experiments" / "optimize_hyper_parameters" / "kalman_hybrid_config.yaml"
V2_CONFIG_PATH = project_root / "experiments" / "optimize_hyper_parameters" / "kalman_hybrid_config_v2.yaml"
UKF_CONFIG_PATH = project_root / "experiments" / "optimize_hyper_parameters" / "trainable_kf_config.yaml"

KNET_PATH = project_root / "retrain_v2_fixed_bounds" / "results" / "best_model.pt"
UKF_PATH = (project_root / "experiments" / "optimize_hyper_parameters" /
            "benchmark_tuning" / "lr_grid_runs" / "idx0007_lrextra0030" /
            "results" / "results" / "best_model.pt")

HANDTUNED_Q = [0.14, 1.0, 0.004, 1.2, 0.0]
HANDTUNED_R = [1.5e-5]

TEST_DATA_PATHS = [
    "data/processed/high_flow_aug/test_win800_20090314_14-20110101_01.pt",
]

WALRUS_PARAMS = {
    'cw': 4.136718976768621e+02, 'cv': 45, 'cg': 16749666.3692294,
    'cq': 3.89027632718506, 'cs': 0.2, 'cd': 2450, 'as_': 0.01,
}
INITIAL_STATE = [140.0, 1000.0, 4.0, 1200.0, 0.1]

# Hyperparameter search results (static, not recomputed)
VAL_NSE = {"knet": 0.841, "ukf": 0.808}


# ============================================================================
# StreamingRegime — drop-in for pipeline.predictions with regime accumulation
# ============================================================================
class StreamingRegime(list):
    """Replace pipeline.predictions — accumulate regime stats, discard batch."""
    def __init__(self, acc: RunningRegimeStats):
        super().__init__()
        self.acc = acc

    def append(self, batch_dict):
        fc = batch_dict['outputs_fc_win'].cpu().numpy()
        obs = batch_dict['y_obs_win'].cpu().numpy()
        self.acc.update(fc, obs)


class StreamingPipeline(Pipeline):
    """Intercept predictions=[] reset to keep streaming object alive."""
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._streaming_predictions = None

    def set_streaming(self, sp):
        self._streaming_predictions = sp
        self.predictions = sp

    def __setattr__(self, name, value):
        if name == 'predictions' and hasattr(self, '_streaming_predictions') and self._streaming_predictions is not None:
            if isinstance(value, list) and not isinstance(value, StreamingRegime):
                return  # ignore reset
        super().__setattr__(name, value)


# ============================================================================
# Test data loading
# ============================================================================
def load_test_data(cfg_or_path, batch_size):
    """Load test dataset and return (test_loader, test_dataset)."""
    if isinstance(cfg_or_path, dict):
        test_ds_path = cfg_or_path['data']['dataset_path']['test']
    else:
        test_ds_path = str(cfg_or_path)
    # Fix drive letter differences
    for old, new in [("F:/", "G:/"), ("G:/github/pycharm/projects/kalmannet", str(project_root))]:
        test_ds_path = test_ds_path.replace(old, new)
    test_ds = torch.load(test_ds_path, map_location='cpu', weights_only=False)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False, num_workers=0)
    return test_loader, test_ds


# ============================================================================
# Quantile computation (first pass over observations)
# ============================================================================
def compute_quantiles(cfg, device, lead_time, batch_size):
    """Run open-loop pass to get per-lead-time Q25/Q75 from observations."""
    print("\n[Quantiles] Computing per-lead-time Q25/Q75 from test observations...")
    test_loader, test_ds = load_test_data(cfg, batch_size)
    # Collect all observations per lead time
    obs_per_lt = [[] for _ in range(lead_time)]
    for batch in test_loader:
        y_obs = batch['qobs']  # [B, 1, T]
        y_obs_win = rearrange_data_unfold(y_obs, lead_time)  # [B, 1, T-L+1, L]
        y_flat = y_obs_win.squeeze(1).reshape(-1, lead_time).numpy()  # [N, L]
        for lt in range(lead_time):
            vals = y_flat[:, lt]
            vals = vals[~np.isnan(vals)]
            obs_per_lt[lt].append(vals)
    q25 = np.zeros(lead_time)
    q75 = np.zeros(lead_time)
    for lt in range(lead_time):
        all_vals = np.concatenate(obs_per_lt[lt])
        q25[lt] = np.percentile(all_vals, 25)
        q75[lt] = np.percentile(all_vals, 75)
    print(f"[Quantiles] Done. Q25 range: [{q25.min():.6f}, {q25.max():.6f}], Q75 range: [{q75.min():.6f}, {q75.max():.6f}]")
    del test_loader, test_ds
    gc.collect()
    return q25, q75


# ============================================================================
# Eval: KNet (LSTM-NGF) via StreamingPipeline
# ============================================================================
def eval_knet(cfg, device, lead_time, batch_size, q25, q75):
    """Evaluate V2 KNet (LSTM-NGF) with regime accumulation."""
    print(f"\n{'='*60}")
    print(f"[knet] LSTM-NGF  lead_time={lead_time}  batch_size={batch_size}")
    print(f"{'='*60}")

    _init_mod.initialize_system_model = _original_init_sys_model

    cfg_copy = json.loads(json.dumps(cfg))
    cfg_copy['training']['forecast_lead_time'] = lead_time
    cfg_copy['model']['knet']['hidden_size'] = 32
    cfg_copy['model']['knet']['in_mult'] = 10
    cfg_copy['model']['knet']['out_mult'] = 10
    cfg_copy['model']['knet']['num_layers'] = 1
    cfg_copy['model']['knet']['activation'] = 'relu'
    cfg_copy['model']['knet']['dropout'] = 0.0

    # V2 config overrides (state_bounds, clamp_scale)
    v2_cfg = yaml.safe_load(open(V2_CONFIG_PATH, 'r', encoding='utf-8'))
    if 'state_bounds' in v2_cfg.get('model', {}).get('knet', {}):
        cfg_copy['model']['knet']['state_bounds'] = v2_cfg['model']['knet']['state_bounds']
    if 'clamp_scale' in v2_cfg.get('model', {}).get('knet', {}):
        cfg_copy['model']['knet']['clamp_scale'] = v2_cfg['model']['knet']['clamp_scale']

    test_loader, test_ds = load_test_data(cfg_copy, batch_size)
    sample_p = test_ds[0]['p']
    if sample_p.ndim > 1:
        sample_p = sample_p.squeeze()
    test_args = build_args(cfg_copy, sample_p, sample_p)
    test_args.device = device

    sys_model = _init_mod.initialize_system_model(test_args.train_seq_len, test_args.seq_len_val, device=device)
    knet_model = build_knet(sys_model, test_args)
    knet_model.to(device)

    checkpoint = torch.load(KNET_PATH, map_location=device, weights_only=False)
    if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
        knet_model.load_state_dict(checkpoint['model_state_dict'])
    else:
        knet_model.load_state_dict(checkpoint)
    print(f"  [OK] Loaded {KNET_PATH.name}")

    work_dir = str(project_root / "draft" / "artifacts" / "tmp_paper_metrics_knet")
    pipeline = StreamingPipeline(work_dir)
    pipeline.set_sys_model(sys_model)
    pipeline.set_knet_model(knet_model)
    pipeline.set_train_params(test_args)
    pipeline.save_predictions = True
    pipeline.display_metrics_list = ["nse", "mse"]
    initialize_training(pipeline, test_loader, test_loader)

    acc = RunningRegimeStats(lead_time, q25, q75)
    pipeline.set_streaming(StreamingRegime(acc))

    t0 = time.time()
    _, _ = run_one_epoch(pipeline, test_loader, 0, is_training=False)
    print(f"  [Done] {time.time()-t0:.1f}s, {acc.n_batches} batches")

    del knet_model, sys_model, pipeline, test_loader, test_ds
    torch.cuda.empty_cache()
    gc.collect()
    return acc


# ============================================================================
# Eval: Trainable UKF via StreamingPipeline
# ============================================================================
def eval_ukf(cfg, device, lead_time, batch_size, q25, q75):
    """Evaluate Trainable-UKF with regime accumulation."""
    print(f"\n{'='*60}")
    print(f"[ukf] Trainable-UKF  lead_time={lead_time}  batch_size={batch_size}")
    print(f"{'='*60}")

    _init_mod.initialize_system_model = _original_init_sys_model

    ukf_cfg = yaml.safe_load(open(UKF_CONFIG_PATH, 'r', encoding='utf-8'))
    ukf_cfg['model']['type'] = 'trainable_ukf'
    ukf_cfg['training']['forecast_lead_time'] = lead_time

    test_loader, test_ds = load_test_data(ukf_cfg, batch_size)
    sample_p = test_ds[0]['p']
    if sample_p.ndim > 1:
        sample_p = sample_p.squeeze()
    test_args = build_args(ukf_cfg, sample_p, sample_p)
    test_args.device = str(device)

    sys_model = _init_mod.initialize_system_model(test_args.train_seq_len, test_args.seq_len_val, device=device)
    ukf_model = build_trainable_kf(ukf_cfg, sys_model, test_args)
    ukf_model.to(device)

    checkpoint = torch.load(UKF_PATH, map_location=device, weights_only=False)
    if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
        ukf_model.load_state_dict(checkpoint['model_state_dict'])
    else:
        ukf_model.load_state_dict(checkpoint)
    print(f"  [OK] Loaded {UKF_PATH.name}")

    work_dir = str(project_root / "draft" / "artifacts" / "tmp_paper_metrics_ukf")
    pipeline = StreamingPipeline(work_dir)
    pipeline.set_sys_model(sys_model)
    pipeline.set_knet_model(ukf_model)
    pipeline.set_train_params(test_args)
    pipeline.save_predictions = True
    pipeline.display_metrics_list = ["nse", "mse"]
    initialize_training(pipeline, test_loader, test_loader)

    acc = RunningRegimeStats(lead_time, q25, q75)
    pipeline.set_streaming(StreamingRegime(acc))

    t0 = time.time()
    _, _ = run_one_epoch(pipeline, test_loader, 0, is_training=False)
    print(f"  [Done] {time.time()-t0:.1f}s, {acc.n_batches} batches")

    del ukf_model, sys_model, pipeline, test_loader, test_ds
    torch.cuda.empty_cache()
    gc.collect()
    return acc


# ============================================================================
# Eval: Hand-tuned UKF (manual batch loop)
# ============================================================================
def eval_handtuned(device, lead_time, batch_size, q25, q75):
    """Evaluate hand-tuned UKF (Sun et al., 2020) with regime accumulation."""
    from filters.filter.non_batch.kalman import MerweScaledSigmaPoints
    from filters.filter.batch.my_version.batch_unscentedkalmanfilter_gpu import (
        BatchUnscentedKalmanFilterGPU,
    )
    from filters.da_coupler.walrus_batch import fx_walrus_batch, hx_walrus_batch
    from knet.modules.pipeline.utils import prepare_batch_data

    print(f"\n{'='*60}")
    print(f"[handtuned] Hand-tuned UKF  lead_time={lead_time}  batch_size={batch_size}")
    print(f"  Q = diag{HANDTUNED_Q}")
    print(f"  R = {HANDTUNED_R}")
    print(f"{'='*60}")

    # Load test data
    test_path = None
    for p in TEST_DATA_PATHS:
        full = project_root / p
        if full.exists():
            test_path = str(full)
            break
    if test_path is None:
        raise FileNotFoundError(f"Test data not found: {TEST_DATA_PATHS}")
    test_ds = torch.load(test_path, weights_only=False)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False, num_workers=0)

    sys_model = _init_mod.initialize_system_model(800, 800, device=device)
    acc = RunningRegimeStats(lead_time, q25, q75)

    t0 = time.time()
    with torch.no_grad():
        for bi, batch in enumerate(test_loader):
            p_data, ep, y_obs, state0, tm_hours = prepare_batch_data(batch, device)
            control = torch.cat((p_data, ep), dim=1)
            B, n, T = y_obs.shape

            # UKF filter
            if state0.dim() == 3:
                state0_first = state0.squeeze(-1) if state0.size(-1) == 1 else state0[:, :, 0]
            else:
                state0_first = state0
            dim_x = state0_first.shape[1]

            points = MerweScaledSigmaPoints(n=dim_x, alpha=0.6874, beta=2.0, kappa=-2.0)
            points.c = points.alpha ** 2 * (points.n + points.kappa)

            ukf = BatchUnscentedKalmanFilterGPU(
                dim_x=dim_x, dim_z=n, dt=1.0,
                hx=lambda sigmas: hx_walrus_batch(sigmas, sys_model=sys_model, device=device),
                fx=lambda sigmas, dt: fx_walrus_batch(sigmas, dt, sys_model=sys_model, controls=None),
                points=points, batch_size=B,
            )
            ukf.x = state0_first.clone()
            ukf.P = torch.diag_embed(0.1 * state0_first.clone())
            q_t = torch.tensor(HANDTUNED_Q, dtype=torch.float32, device=device)
            ukf.Q = torch.diag_embed(q_t).unsqueeze(0).expand(B, -1, -1).clone()
            r_t = torch.tensor(HANDTUNED_R, dtype=torch.float32, device=device)
            ukf.R = torch.diag_embed(r_t).unsqueeze(0).expand(B, -1, -1).clone()

            states_upd = torch.zeros(B, dim_x, T, device=device)
            outputs_upd = torch.zeros(B, n, T, device=device)
            for t in range(T):
                ct = control[:, :, t]
                ukf.fx = lambda sigmas, dt, ct=ct: fx_walrus_batch(
                    sigmas, dt, sys_model=sys_model, controls=ct, device=device
                )
                ukf.predict()
                ukf.update(y_obs[:, :, t])
                states_upd[:, :, t] = ukf.x.clone()
                outputs_upd[:, :, t] = sys_model.h(ukf.x)

            # Forecast from updated states
            states_fc_flat, outputs_fc_flat = system_model_forecast(
                sys_model=sys_model, p=p_data, etpot=ep,
                states_updated=states_upd, lead_time=lead_time,
            )
            if sys_model.n == 1:
                outputs_fc_flat = outputs_fc_flat.squeeze(1)
            y_obs_rearr = rearrange_data_unfold(y_obs, lead_time).reshape(-1, lead_time)

            fc_np = outputs_fc_flat.cpu().numpy()
            obs_np = y_obs_rearr.cpu().numpy()
            if fc_np.ndim != 2 or fc_np.shape[-1] != lead_time:
                fc_np = fc_np.reshape(-1, lead_time)
                obs_np = obs_np.reshape(-1, lead_time)

            acc.update(fc_np, obs_np)

            del states_upd, outputs_upd, states_fc_flat, outputs_fc_flat, y_obs_rearr
            torch.cuda.empty_cache()
            if (bi + 1) % 10 == 0:
                print(f"  batch {bi+1}/{len(test_loader)} ({time.time()-t0:.0f}s)")

    print(f"  [Done] {time.time()-t0:.1f}s, {acc.n_batches} batches")
    del test_loader, test_ds
    torch.cuda.empty_cache()
    gc.collect()
    return acc


# ============================================================================
# Eval: Open-loop (no DA, manual batch loop)
# ============================================================================
def eval_openloop(device, lead_time, batch_size, q25, q75):
    """Evaluate open-loop WALRUS (no data assimilation) with regime accumulation."""
    from knet.modules.pipeline.utils import prepare_batch_data

    print(f"\n{'='*60}")
    print(f"[openloop] Open-loop WALRUS  lead_time={lead_time}  batch_size={batch_size}")
    print(f"{'='*60}")

    test_path = None
    for p in TEST_DATA_PATHS:
        full = project_root / p
        if full.exists():
            test_path = str(full)
            break
    if test_path is None:
        raise FileNotFoundError(f"Test data not found: {TEST_DATA_PATHS}")
    test_ds = torch.load(test_path, weights_only=False)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False, num_workers=0)

    initial_state = torch.tensor(INITIAL_STATE, dtype=torch.float32, device=device)
    walrus = WalrusBatch(**WALRUS_PARAMS, initial_state=initial_state, device=device)
    walrus.eval()

    acc = RunningRegimeStats(lead_time, q25, q75)

    t0 = time.time()
    with torch.no_grad():
        for bi, batch in enumerate(test_loader):
            p_data, ep, y_obs, state0, tm_hours = prepare_batch_data(batch, device)
            B = p_data.size(0)
            T = p_data.size(-1)

            # Open-loop: use stored OL state at t=0, run forward without DA
            x_current = state0[:, :, 0].clone() if state0.dim() == 3 else state0.clone()
            outputs_ol = torch.zeros(B, T, device=device)
            for t in range(T):
                p_t = p_data[:, 0, t]
                ep_t = ep[:, 0, t]
                controls_t = torch.stack([p_t, ep_t], dim=1)
                y_t = walrus.h(x_current)
                outputs_ol[:, t] = y_t.squeeze(-1)
                x_current = walrus.f(x_current, controls_t)

            # Rearrange to [N, L] for per-lead-time metrics
            outputs_ol_3d = outputs_ol.unsqueeze(1)  # [B, 1, T]
            outputs_ol_win = rearrange_data_unfold(outputs_ol_3d, lead_time)  # [B, 1, T-L+1, L]
            fc_flat = outputs_ol_win.squeeze(1).reshape(-1, lead_time)
            y_obs_win = rearrange_data_unfold(y_obs, lead_time)
            obs_flat = y_obs_win.squeeze(1).reshape(-1, lead_time)

            acc.update(fc_flat.cpu().numpy(), obs_flat.cpu().numpy())

            if (bi + 1) % 10 == 0:
                print(f"  batch {bi+1}/{len(test_loader)} ({time.time()-t0:.0f}s)")

    print(f"  [Done] {time.time()-t0:.1f}s, {acc.n_batches} batches")
    del test_loader, test_ds
    torch.cuda.empty_cache()
    gc.collect()
    return acc


# ============================================================================
# Extract learned Q/R from Trainable-UKF checkpoint
# ============================================================================
def extract_learned_qr(checkpoint_path):
    """Extract the covariance diagonals used by the trainable UKF.

    LearnableCov stores log-covariance parameters and applies torch.exp in its
    forward pass, so checkpoint values must be restored with the same transform.
    """
    ckpt = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
    state_dict = ckpt.get('model_state_dict', ckpt)
    q_diag = {}
    r_val = None
    state_names = ['dv', 'dg', 'hq', 'hs', 'Q']
    for k, v in state_dict.items():
        if 'Q_layer.raw' in k:
            vals = torch.exp(v).cpu().numpy()
            for i, name in enumerate(state_names):
                if i < len(vals):
                    q_diag[name] = float(vals[i])
        if 'R_layer.raw' in k:
            r_val = float(torch.exp(v).cpu().item())
    return {"q_diag": q_diag, "r": r_val, "source_checkpoint": str(checkpoint_path)}


# ============================================================================
# Assemble JSON from all accumulators
# ============================================================================
def assemble_json(accs, lead_time, bootstrap_leads, n_boot, regime_horizons):
    """Build paper_metrics.json structure from model accumulators."""
    result = {}

    # Provenance
    result['provenance'] = {
        'generated_at': datetime.now().isoformat(),
        'git_commit': git_commit_hash(),
        'script': 'draft/scripts/generate_paper_metrics.py',
        'lead_time': lead_time,
        'n_boot': n_boot,
        'checkpoints': {
            'knet': {'path': str(KNET_PATH), 'md5': md5_file(KNET_PATH) if KNET_PATH.exists() else 'N/A'},
            'ukf': {'path': str(UKF_PATH), 'md5': md5_file(UKF_PATH) if UKF_PATH.exists() else 'N/A'},
            'handtuned': {'q_diag': HANDTUNED_Q, 'r': HANDTUNED_R[0]},
            'openloop': None,
        },
    }

    # Per-lead-time NSE
    result['per_lead_nse'] = {}
    for model_key, acc in accs.items():
        s = acc.stats['all']
        nse_dict = {}
        for h in range(1, lead_time + 1):
            lt = h - 1
            nse_dict[f'H{h}'] = round(nse_from_stats(s['n'][lt], s['sy'][lt], s['sy2'][lt], s['sse'][lt]), 6)
        result['per_lead_nse'][model_key] = nse_dict

    # Per-lead-time KGE
    result['per_lead_kge'] = {}
    for model_key, acc in accs.items():
        s = acc.stats['all']
        kge_dict = {}
        for h in range(1, lead_time + 1):
            lt = h - 1
            kge, r, alpha, beta = kge_from_stats(
                s['n'][lt], s['sy'][lt], s['sy2'][lt],
                s['sp'][lt], s['sp2'][lt], s['spo'][lt])
            kge_dict[f'H{h}'] = {
                'kge': round(kge, 6), 'r': round(r, 6),
                'alpha': round(alpha, 6), 'beta': round(beta, 6),
            }
        result['per_lead_kge'][model_key] = kge_dict

    # Regime breakdown at specified horizons
    result['regime'] = {}
    for h in regime_horizons:
        if h > lead_time:
            continue
        lt = h - 1
        result['regime'][f'H{h}'] = {}
        for model_key, acc in accs.items():
            model_regime = {}
            for regime in acc.regimes:
                s = acc.stats[regime]
                model_regime[regime] = {
                    'nse': round(nse_from_stats(s['n'][lt], s['sy'][lt], s['sy2'][lt], s['sse'][lt]), 6),
                    'rmse': round(rmse_from_stats(s['n'][lt], s['sse'][lt]) * MMH_TO_M3S, 2),
                    'mae': round(mae_from_stats(s['n'][lt], s['ae'][lt]) * MMH_TO_M3S, 2),
                    'count': int(s['n'][lt]),
                }
            result['regime'][f'H{h}'][model_key] = model_regime

    # RMSE / MAE at key horizons
    result['rmse_mae'] = {}
    for h in regime_horizons:
        if h > lead_time:
            continue
        lt = h - 1
        result['rmse_mae'][f'H{h}'] = {}
        for model_key, acc in accs.items():
            s = acc.stats['all']
            result['rmse_mae'][f'H{h}'][model_key] = {
                'rmse': round(rmse_from_stats(s['n'][lt], s['sse'][lt]) * MMH_TO_M3S, 2),
                'mae': round(mae_from_stats(s['n'][lt], s['ae'][lt]) * MMH_TO_M3S, 2),
            }

    # Bootstrap CI
    result['bootstrap'] = {}
    for h in bootstrap_leads:
        if h > lead_time:
            continue
        lt = h - 1
        result['bootstrap'][f'H{h}'] = {}
        for model_key, acc in accs.items():
            n_arr = np.array([bs['n'][lt] for bs in acc.batch_stats])
            sy_arr = np.array([bs['sy'][lt] for bs in acc.batch_stats])
            sy2_arr = np.array([bs['sy2'][lt] for bs in acc.batch_stats])
            sse_arr = np.array([bs['sse'][lt] for bs in acc.batch_stats])
            if n_arr.sum() == 0:
                continue
            samples = bootstrap_nse(n_arr, sy_arr, sy2_arr, sse_arr, n_boot=n_boot)
            ci = [round(float(np.percentile(samples, 2.5)), 6),
                  round(float(np.percentile(samples, 97.5)), 6)]
            s = acc.stats['all']
            nse_val = nse_from_stats(s['n'][lt], s['sy'][lt], s['sy2'][lt], s['sse'][lt])
            result['bootstrap'][f'H{h}'][model_key] = {
                'nse': round(nse_val, 6),
                'ci95': ci,
            }
        # Paired difference (knet - ukf)
        if 'knet' in accs and 'ukf' in accs:
            knet_n = np.array([bs['n'][lt] for bs in accs['knet'].batch_stats])
            knet_sy = np.array([bs['sy'][lt] for bs in accs['knet'].batch_stats])
            knet_sy2 = np.array([bs['sy2'][lt] for bs in accs['knet'].batch_stats])
            knet_sse = np.array([bs['sse'][lt] for bs in accs['knet'].batch_stats])
            ukf_n = np.array([bs['n'][lt] for bs in accs['ukf'].batch_stats])
            ukf_sy = np.array([bs['sy'][lt] for bs in accs['ukf'].batch_stats])
            ukf_sy2 = np.array([bs['sy2'][lt] for bs in accs['ukf'].batch_stats])
            ukf_sse = np.array([bs['sse'][lt] for bs in accs['ukf'].batch_stats])
            knet_samples = bootstrap_nse(knet_n, knet_sy, knet_sy2, knet_sse, n_boot=n_boot)
            ukf_samples = bootstrap_nse(ukf_n, ukf_sy, ukf_sy2, ukf_sse, n_boot=n_boot)
            diff_samples = knet_samples - ukf_samples
            result['bootstrap'][f'H{h}']['diff_knet_ukf'] = {
                'mean': round(float(np.mean(diff_samples)), 6),
                'ci95': [round(float(np.percentile(diff_samples, 2.5)), 6),
                         round(float(np.percentile(diff_samples, 97.5)), 6)],
            }

    # Learned Q/R
    if UKF_PATH.exists():
        result['learned_qr'] = extract_learned_qr(UKF_PATH)
    else:
        result['learned_qr'] = None

    # Validation NSE (static)
    result['val_nse'] = VAL_NSE

    return result


# ============================================================================
# Main
# ============================================================================
def main():
    parser = argparse.ArgumentParser(description="Generate paper_metrics.json")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--lead-time", type=int, default=48)
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--bootstrap-leads", type=int, nargs='+', default=[12])
    parser.add_argument("--n-boot", type=int, default=10000)
    parser.add_argument("--regime-horizons", type=int, nargs='+', default=[12, 24])
    parser.add_argument("--output", default="draft/artifacts/paper_metrics.json")
    args = parser.parse_args()

    device = torch.device(args.device)
    lead_time = args.lead_time

    # Auto-scale batch_size
    if args.batch_size is not None:
        batch_size = args.batch_size
    else:
        base_bs = 512
        scale = max(1, lead_time // 12)
        batch_size = max(32, base_bs // scale)

    print(f"[Config] lead_time={lead_time}, batch_size={batch_size}, device={device}")
    print(f"[Config] bootstrap_leads={args.bootstrap_leads}, n_boot={args.n_boot}")
    print(f"[Config] regime_horizons={args.regime_horizons}")

    cfg = yaml.safe_load(open(LOCAL_CONFIG_PATH, 'r', encoding='utf-8'))

    # Step 1: Compute quantiles
    q25, q75 = compute_quantiles(cfg, device, lead_time, batch_size)

    # Step 2: Evaluate all 4 models
    accs = {}
    accs['knet'] = eval_knet(cfg, device, lead_time, batch_size, q25, q75)
    accs['ukf'] = eval_ukf(cfg, device, lead_time, batch_size, q25, q75)
    accs['handtuned'] = eval_handtuned(device, lead_time, batch_size, q25, q75)
    accs['openloop'] = eval_openloop(device, lead_time, batch_size, q25, q75)

    # Step 3: Assemble JSON
    print(f"\n{'='*60}")
    print("[Assemble] Building paper_metrics.json...")
    result = assemble_json(accs, lead_time, args.bootstrap_leads, args.n_boot, args.regime_horizons)

    # Step 4: Write
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    print(f"[OK] Written to {output_path}")

    # Print summary
    print(f"\n{'='*60}")
    print("Summary of per-lead-time NSE at key horizons:")
    for h in [1, 12, 24, 48]:
        if h > lead_time:
            continue
        line = f"  H{h:>2}: "
        for model_key in ['knet', 'ukf', 'handtuned', 'openloop']:
            v = result['per_lead_nse'][model_key][f'H{h}']
            line += f"  {model_key}={v:.4f}"
        print(line)


if __name__ == "__main__":
    main()
