import os
import matplotlib.pyplot as plt
def plot_state_and_observation(states, observations, state_names, obs_state_names, save_path, time_steps=None):
    """
    绘制每个状态变量及其观测值随时间的变化。

    参数:
        states (torch.Tensor): 模型状态，维度为 [samples, state_num, timesteps]
        observations (torch.Tensor): 观测数据，维度应与 states 相同
        state_names (list of str): 状态变量的名称列表
        obs_state_names (list of str): 有观测数据的状态变量名称列表
        time_steps (list or torch.Tensor, optional): 时间步的具体值，如果未提供，则使用序列号
        save_path (str): 图像保存路径
    """
    # 确保观测状态是状态名称的子集
    if not set(obs_state_names).issubset(set(state_names)):
        raise ValueError("observed_states must be a subset of state_names")

    # 确保保存路径存在
    os.makedirs(save_path, exist_ok=True)

    # 如果未提供时间步，则使用默认的序列号
    if time_steps is None:
        time_steps = range(states.size(2))

    # 构建一个观测状态索引映射
    observed_index_map = {name: idx for idx, name in enumerate(obs_state_names) if name in state_names}

    # 遍历每个状态变量
    for idx, name in enumerate(state_names):
        plt.figure(figsize=(10, 6))
        for sample in range(states.size(0)):
            # 绘制状态
            plt.plot(time_steps, states[sample, idx, :].detach().cpu().numpy(), linestyle='--',
                     label=f'Sample {sample + 1} State')

        # 如果当前状态有观测数据，绘制观测值
        if name in obs_state_names:
            obs_idx = observed_index_map[name]  # 获取观测数据中的索引
            # 为所有样本绘制相同的观测数据
            plt.scatter(time_steps, observations[:, obs_idx, :].mean(dim=0).detach().cpu().numpy(), marker='o',
                        label='Observation')
        else:
            plt.text(0.5, 0.5, 'No observation available', horizontalalignment='center', verticalalignment='center',
                     transform=plt.gca().transAxes)

        plt.title(f'State Variable and Observation Over Time: {name}')
        plt.xlabel('Time Step')
        plt.ylabel(name)
        plt.legend()
        plt.grid(True)

        # 根据是否有观测数据修改文件名
        observed_suffix = 'observed' if name in obs_state_names else 'unobserved'
        # 保存图像
        plt.savefig(os.path.join(save_path, f'{name}_state_and_observation_over_time_{observed_suffix}.png'))
        plt.close()
