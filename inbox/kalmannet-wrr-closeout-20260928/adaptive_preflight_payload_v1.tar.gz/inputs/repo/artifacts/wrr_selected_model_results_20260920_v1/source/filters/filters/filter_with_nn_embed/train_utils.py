from collections import defaultdict
from filters.filter_with_nn_embed.metrics import compute_train_loss, compute_display_metrics
from tqdm import tqdm
import yaml
import torch
import numpy as np


def load_params_from_yaml(file_path):
    """
    从 YAML 配置文件中加载训练参数
    """
    with open(file_path, 'r', encoding='utf-8') as file:
        config = yaml.safe_load(file)
    return config['training_params']


def display_params(params):
    """
    显示训练参数中的重要值，避免重复显示 `repeat` 后的部分，只显示第一个
    """
    display_params = {
        'train_epochs': params['train_epochs'],
        'train_loss_metric': params['train_loss_metric'],
        'display_loss_metric': params['display_loss_metric'],
        'lr': params['lr'],
        'wd': params['wd'],

        # 网络维度和激活函数
        'dim_x': params['dim_x'],
        'dim_z': params['dim_z'],
        'in_mult_nn': params['in_mult_nn'],
        'out_mult_nn': params['out_mult_nn'],
        'activation': params['activation'],

        # 网络层数与隐藏层维度
        'num_layers_q': params['num_layers_q'],
        'num_layers_r': params['num_layers_r'],
        'd_hidden_q': params['d_hidden_q'],
        'd_hidden_r': params['d_hidden_r'],
        'dropout_prob': params['dropout_prob'],

        # LSTM 相关设置
        'use_lstm': params['use_lstm'],

        # 卡尔曼滤波器相关先验 (只显示第一个)
        'q_prior': params['q_prior'][0, :, :].tolist(),  # 只显示第一个重复的部分
        'r_prior': params['r_prior'][0, :, :].tolist(),  # 只显示第一个重复的部分
        'P0': params['P0'][0, :, :].tolist(),  # 只显示第一个重复的部分

        # Clamp 和 Scale 信息 (这里显示原始值)
        'clamp_scale_info': {
            "obs_diff_clamp": params['clamp_scale_info']['obs_diff_clamp'].tolist(),
            "obs_diff_scale": params['clamp_scale_info']['obs_diff_scale'].tolist(),
            "obs_innov_diff_clamp": params['clamp_scale_info']['obs_innov_diff_clamp'].tolist(),
            "obs_innov_diff_scale": params['clamp_scale_info']['obs_innov_diff_scale'].tolist(),
            "fw_update_diff_clamp": params['clamp_scale_info']['fw_update_diff_clamp'].tolist(),
            "fw_update_diff_scale": params['clamp_scale_info']['fw_update_diff_scale'].tolist()
        },

        # 初始状态 (只显示第一个)
        'state0': params['state0'][0, :].tolist()  # 只显示第一个重复的部分
    }

    # 打印显示参数
    for key, value in display_params.items():
        print(f"{key}: {value}")

def get_train_params(device, batch_size, config_file):
    """
    读取 YAML 文件中的配置并返回一个包含所有参数的字典
    """
    # 加载训练参数
    params = load_params_from_yaml(config_file)

    # 从字典中提取参数
    model_params = {
        # 训练参数
        'train_epochs': params['train_epochs'],
        'train_loss_metric': params['train_loss_metric'],
        'display_loss_metric': params['display_loss_metric'],
        'lr': float(params['lr']),
        'wd': float(params['wd']),
        'batch_size': batch_size,
        'window_size': params['window_size'],
        'forecast_lead_time': params['forecast_lead_time'],
        'early_stopping': params['early_stopping'],
        'lead_time_phases': params['phase_settings']['lead_time_phases'],

        # 网络维度和激活函数
        'dim_x': params['dim_x'],
        'dim_z': params['dim_z'],
        'in_mult_nn': params['in_mult_nn'],
        'out_mult_nn': params['out_mult_nn'],
        'activation': params['activation'],

        # 网络层数与隐藏层维度
        'num_layers_q': params['num_layers_q'],
        'num_layers_r': params['num_layers_r'],
        'd_hidden_q': params['d_hidden_q'],
        'd_hidden_r': params['d_hidden_r'],
        'dropout_prob': params['dropout_prob'],
        'init_method': params['init_method'],

        # LSTM 相关设置
        'use_lstm': params['use_lstm'],

        # 卡尔曼滤波器相关先验
        'q_prior': torch.tensor(np.diag(params['q_prior']) * 0.1, dtype=torch.float32, device=device).unsqueeze(
            0).repeat(batch_size, 1, 1),
        'r_prior': torch.tensor(params['r_prior'], dtype=torch.float32, device=device).unsqueeze(0).repeat(batch_size,
                                                                                                           1, 1),
        'P0': torch.tensor(np.diag(params['P0']), dtype=torch.float32, device=device).unsqueeze(0).repeat(batch_size, 1,
                                                                                                          1),

        # Clamp 和 Scale 信息
        'clamp_scale_info': {
            "obs_diff_clamp": torch.tensor(params['clamp_scale_info']['obs_diff_clamp'], dtype=torch.float32,
                                           device=device),
            "obs_diff_scale": torch.tensor(params['clamp_scale_info']['obs_diff_scale'], dtype=torch.float32,
                                           device=device),
            "obs_innov_diff_clamp": torch.tensor(params['clamp_scale_info']['obs_innov_diff_clamp'],
                                                 dtype=torch.float32, device=device),
            "obs_innov_diff_scale": torch.tensor(params['clamp_scale_info']['obs_innov_diff_scale'],
                                                 dtype=torch.float32, device=device),
            "fw_update_diff_clamp": torch.tensor(params['clamp_scale_info']['fw_update_diff_clamp'],
                                                 dtype=torch.float32, device=device),
            "fw_update_diff_scale": torch.tensor(params['clamp_scale_info']['fw_update_diff_scale'],
                                                 dtype=torch.float32, device=device)
        },

        # 初始状态
        'state0': torch.tensor(params['state0'], dtype=torch.float32, device=device).unsqueeze(0).repeat(batch_size, 1)
    }

    display_params(model_params)
    return model_params

@torch.jit.script
def rearrange_data_unfold(p: torch.Tensor, lead_time: int) -> torch.Tensor:
    """
    使用 torch.unfold 重排输入张量 `p`，根据指定的前置时间步长（lead_time）形成批次。

    参数：
        p (torch.Tensor): 输入张量，形状为 [batch_size, 1, num_timesteps]。
        lead_time (int): 用于形成批次的前置时间步长。

    返回：
        torch.Tensor: 重排后的张量，形状为 [batch_size, feasible_timesteps, lead_time]。
    """
    batch_size, _, num_timesteps = p.size()

    # 去除通道维度（如果存在）
    p = p.squeeze(1)  # 现在 p 的形状为 [batch_size, num_timesteps]

    # 使用 unfold 提取滑动窗口
    p_unfolded = p.unfold(dimension=1, size=lead_time, step=1)  # [batch_size, feasible_timesteps, lead_time]

    return p_unfolded

