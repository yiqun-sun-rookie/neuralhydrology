import torch
import torch.nn as nn
import torch.nn.functional as F


class R_Adaptive_RNN(nn.Module):
    """
    =============================================================
    ========== 自适应估计 Q,R + 差分量 clamp/scale 示例网络 =========

    核心思路:
      1) 在每一步接受四个差分量: obs_diff, obs_innov_diff, fw_evol_diff, fw_update_diff
         (以及上一时刻的 RNN hidden_state) 作为输入.
      2) 先对四个差分量做 clamp+scale 操作:
         - clamp: 保证每一维在 (min, max) 区间.
         - scale: 再将其除以一个 scale 值, 防止差分量过大/过小.
         => 这样可以稳定训练, 避免梯度爆炸或饱和.
      3) 将处理后的差分量拼接后送入 LSTM/GRU, 输出隐藏向量 => 再映射到 Q,R 对角线.
      4) 通过 hidden_state 在时序上“记忆”前一时刻网络输出/内部状态, 达到“跨时间依赖”的效果.
      5) 该网络不追踪 Sigma (状态协方差), 因此比 KalmanNet 那种多路 GRU 结构更简单, 但也缺失了对 Sigma 的直接学习.

    =============================================================
    """

    def __init__(
            self,
            dim_x: int,  # 状态维度 => 决定 Q对角线大小
            dim_z: int,  # 观测维度 => 决定 R对角线大小
            batch_size: int,
            hidden_dim: int = 32,  # RNN隐藏层维度
            use_lstm: bool = True,  # True => 用LSTM; False => 用GRU
            clamp_scale_info: dict = None,  # 存放各差分量的 clamp/scale 范围
            debug_enabled: bool = False,  # 是否收集差分量统计信息
            r_scale: float = 1.0,  # 用于控制 R 的大小
            init_method: str = 'zeros',  # 隐藏状态初始化方法
            r_prior: torch.Tensor = None,  # 提供的 R 先验信息
            device: torch.device = 'cuda',
            use_init_weights: bool = True  # 是否初始化权重
    ):
        """
        Args:
            dim_x, dim_z: 分别是状态、观测向量的维度
            hidden_dim:   RNN hidden 的维度
            use_lstm:     True => LSTM, False => GRU
            clamp_scale_info: 包含各差分量 clamp,min,max,scale 的信息的字典.
            r_scale: 用于控制 R 的大小的常数
        """
        super().__init__()
        self.dim_x = dim_x
        self.dim_z = dim_z
        self.hidden_dim = hidden_dim
        self.batch_size = batch_size
        self.use_lstm = use_lstm
        self.register_buffer('r_scale', torch.tensor(r_scale))

        self.clamp_scale_info = clamp_scale_info if clamp_scale_info is not None else {}
        self.debug_enabled = debug_enabled
        self.init_method = init_method  # 初始化方式
        self.register_buffer('r_prior', torch.tensor(r_prior))
        self.device = device
        self.use_init_weights = use_init_weights
        # 输入特征维度
        self.input_dim = 2 * dim_z + 2 * dim_x

        # 构建 RNN
        if self.use_lstm:
            self.rnn = nn.LSTM(self.input_dim, hidden_dim, batch_first=True)
        else:
            self.rnn = nn.GRU(self.input_dim, hidden_dim, batch_first=True)

        # 输出映射: hidden_dim -> Q,R 对角
        self.fc_r = nn.Sequential(
            nn.Linear(hidden_dim, dim_z),
            nn.Sigmoid())  # 使输出限制在 0 到 1 之间

        if self.use_init_weights:
            self.init_weights()

        # 先验映射层
        if self.r_prior is not None:
            self.r_prior_to_hidden_state = nn.Linear(self.r_prior.numel(), self.hidden_dim).to(self.device)
            self.r_prior_to_cell_state = nn.Linear(self.r_prior.numel(), self.hidden_dim).to(self.device)

    def forward(
            self,
            obs_diff: torch.Tensor,
            obs_innov_diff: torch.Tensor,
            fw_evol_diff: torch.Tensor,
            fw_update_diff: torch.Tensor,
            h_prev=None
    ):
        # 对四个差分量做 clamp+scale
        obs_diff = self._clamp_and_scale(
            obs_diff,
            self.clamp_scale_info.get("obs_diff_clamp", []),
            self.clamp_scale_info.get("obs_diff_scale", [])
        )
        obs_innov_diff = self._clamp_and_scale(
            obs_innov_diff,
            self.clamp_scale_info.get("obs_innov_clamp", []),
            self.clamp_scale_info.get("obs_innov_scale", [])
        )
        fw_evol_diff = self._clamp_and_scale(
            fw_evol_diff,
            self.clamp_scale_info.get("fw_diff_clamp", []),
            self.clamp_scale_info.get("fw_diff_scale", [])
        )
        fw_update_diff = self._clamp_and_scale(
            fw_update_diff,
            self.clamp_scale_info.get("fw_diff_clamp", []),
            self.clamp_scale_info.get("fw_diff_scale", [])
        )

        # 拼接
        net_input = torch.cat([obs_diff, obs_innov_diff, fw_evol_diff, fw_update_diff], dim=-1)
        net_input = net_input.unsqueeze(1)

        if h_prev is not None:
            if self.use_lstm:
                h_prev = (h_prev[0].detach(), h_prev[1].detach())
            else:
                h_prev = h_prev.detach()

        # RNN 前向传播
        if self.use_lstm:
            out, (h_new, c_new) = self.rnn(net_input, h_prev)
            # 保留 h_out 的梯度（移除 detach）
            h_out = out[:, -1, :].detach()  # 仅保留最后一个时间步的输出
            # 对新的隐藏状态分离梯度
            h_new = h_new.detach()
            c_new = c_new.detach()
            h_curr = (h_new, c_new)
        else:
            out, h_new = self.rnn(net_input, h_prev)
            h_out = out[:, -1, :]  # 仅保留最后一个时间步的输出
            h_new = h_new.detach()  # 分离梯度
            h_curr = h_new

        # 用全连接映射到 R 对角线并乘以常数
        r_diag = self.fc_r(h_out) * self.r_scale # (B, dim_z)

        return r_diag, h_curr

    def init_hidden(self, batch_size=None):
        """
        根据初始化方法选择隐藏状态的初始化方式
        """
        if batch_size is None:
            batch_size = self.batch_size
        else:
            self.batch_size = batch_size

        if self.init_method == 'zeros':
            # 0 初始化
            if self.use_lstm:
                h0 = torch.zeros(1, batch_size, self.hidden_dim, device=self.device)
                c0 = torch.zeros(1, batch_size, self.hidden_dim, device=self.device)
                return (h0, c0)
            else:
                h0 = torch.zeros(1, batch_size, self.hidden_dim, device=self.device)
                return h0

        elif self.init_method == 'gaussian':
            # 高斯随机初始化
            if self.use_lstm:
                h0 = torch.randn(1, batch_size, self.hidden_dim, device=self.device) * 0.1  # 随机初始化，标准差为 0.1
                c0 = torch.randn(1, batch_size, self.hidden_dim, device=self.device) * 0.1
                return (h0, c0)
            else:
                h0 = torch.randn(1, batch_size, self.hidden_dim, device=self.device) * 0.1
                return h0

        elif self.init_method == 'prior':
            # 基于先验初始化
            if self.r_prior is not None:
                prior_r_flat = self.r_prior.view(1, -1).to(self.device)
                h0 = self.r_prior_to_hidden_state(prior_r_flat).unsqueeze(0).repeat(1, batch_size, 1)
                if self.use_lstm:
                    c0 = self.r_prior_to_cell_state(prior_r_flat).unsqueeze(0).repeat(1, batch_size, 1)  # LSTM 需要初始化 cell state
                    return (h0, c0)
                else:
                    return h0
            else:
                # 没有提供先验，则默认用零初始化
                h0 = torch.zeros(1, batch_size, self.hidden_dim, device=self.device)
                return h0

    def _clamp_and_scale(self, tensor, clamp_list, scale_list):
        if len(clamp_list) == 0 or len(scale_list) == 0:
            return tensor

        # 向量化操作（避免循环）
        clamped = torch.clamp(tensor,
                              min=torch.tensor([c[0] for c in clamp_list], device=tensor.device),
                              max=torch.tensor([c[1] for c in clamp_list], device=tensor.device)
                              )
        scaled = clamped / torch.tensor(scale_list, device=tensor.device)
        return scaled

    def init_weights(self):
        """初始化权重"""
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.LSTM):
                for name, param in m.named_parameters():
                    if 'weight_ih' in name:
                        nn.init.xavier_uniform_(param.data)
                    elif 'weight_hh' in name:
                        nn.init.orthogonal_(param.data)
                    elif 'bias' in name:
                        nn.init.zeros_(param.data)
            elif isinstance(m, nn.GRU):
                for name, param in m.named_parameters():
                    if 'weight_ih' in name:
                        nn.init.xavier_uniform_(param.data)
                    elif 'weight_hh' in name:
                        nn.init.orthogonal_(param.data)
                    elif 'bias' in name:
                        nn.init.zeros_(param.data)
