import numpy as np


def calc_nse(obs, sim):
    """
    计算 Nash-Sutcliffe 效率（NSE）指标。

    NSE 衡量模拟值与观测值的拟合程度，其值范围通常在 -∞ 到 1 之间，值越接近 1 表明模型拟合越好。

    参数:
    ----------
    obs : array-like
        观测数据。
    sim : array-like
        模拟数据。

    返回:
    -------
    float
        NSE 值。如果数据点不足或分母为零，返回 np.nan。
    """
    obs = np.asarray(obs)
    sim = np.asarray(sim)

    mask = ~np.isnan(obs) & ~np.isnan(sim)
    obs_m = obs[mask]
    sim_m = sim[mask]

    if len(obs_m) < 2:
        return np.nan

    mean_obs = np.mean(obs_m)
    denominator = np.sum((obs_m - mean_obs) ** 2)
    if denominator == 0:
        return np.nan

    numerator = np.sum((obs_m - sim_m) ** 2)
    nse = 1 - numerator / denominator
    return nse


def calc_mse(obs, sim):
    """
    计算均方误差（MSE）。

    MSE 衡量模拟值与观测值之间的平均平方差，值越小表示模型性能越好。

    参数:
    ----------
    obs : array-like
        观测数据。
    sim : array-like
        模拟数据。

    返回:
    -------
    float
        MSE 值。如果数据点不足，返回 np.nan。
    """
    obs = np.asarray(obs)
    sim = np.asarray(sim)

    mask = ~np.isnan(obs) & ~np.isnan(sim)
    obs_m = obs[mask]
    sim_m = sim[mask]

    if len(obs_m) == 0:
        return np.nan

    mse = np.mean((obs_m - sim_m) ** 2)
    return mse


def calc_mae(obs, sim):
    """
    计算平均绝对误差（MAE）。

    MAE 衡量模拟值与观测值之间的平均绝对差，值越小表示模型性能越好。

    参数:
    ----------
    obs : array-like
        观测数据。
    sim : array-like
        模拟数据。

    返回:
    -------
    float
        MAE 值。如果数据点不足，返回 np.nan。
    """
    obs = np.asarray(obs)
    sim = np.asarray(sim)

    mask = ~np.isnan(obs) & ~np.isnan(sim)
    obs_m = obs[mask]
    sim_m = sim[mask]

    if len(obs_m) == 0:
        return np.nan

    mae = np.mean(np.abs(obs_m - sim_m))
    return mae


def calc_kge(obs, sim):
    """
    计算 Kling-Gupta 效率（KGE）。

    KGE 综合考虑相关性、偏差和变异性，是衡量水文模型性能的综合指标，值范围通常在 -∞ 到 1 之间，值越接近 1 表明模型性能越好。

    参数:
    ----------
    obs : array-like
        观测数据。
    sim : array-like
        模拟数据。

    返回:
    -------
    float
        KGE 值。如果数据点不足、均值为零或标准差为零，返回 np.nan。
    """
    obs = np.asarray(obs)
    sim = np.asarray(sim)

    mask = ~np.isnan(obs) & ~np.isnan(sim)
    obs_m = obs[mask]
    sim_m = sim[mask]

    if len(obs_m) < 2:
        return np.nan

    mean_obs = np.mean(obs_m)
    mean_sim = np.mean(sim_m)
    std_obs = np.std(obs_m)
    std_sim = np.std(sim_m)

    # 检查标准差是否为零，避免除以零
    if std_obs == 0 or std_sim == 0 or mean_obs == 0:
        return np.nan

    correlation_matrix = np.corrcoef(obs_m, sim_m)
    r = correlation_matrix[0, 1]

    # 如果相关系数为nan（例如全部值相同），返回nan
    if np.isnan(r):
        return np.nan

    alpha = std_sim / std_obs
    beta = mean_sim / mean_obs

    kge = 1 - np.sqrt((r - 1) ** 2 + (alpha - 1) ** 2 + (beta - 1) ** 2)
    return kge
