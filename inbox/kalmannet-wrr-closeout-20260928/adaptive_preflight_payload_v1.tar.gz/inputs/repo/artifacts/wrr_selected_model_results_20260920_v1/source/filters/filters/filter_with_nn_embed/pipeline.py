import os
from torch.utils.tensorboard import SummaryWriter
from datetime import datetime
from torch.optim import AdamW
from torch.optim.lr_scheduler import ReduceLROnPlateau
from filters.filter_with_nn_embed.train import train_nn
from filters.filter_with_nn_embed.test import test_nn
class Pipeline:
    def __init__(self, base_path, filter_with_nn_embed, target_model_name, sys_model, train_params, saved_models_path, device):
        super().__init__()
        self.train_epochs = train_params['train_epochs']
        self.batch_size = train_params['batch_size']
        self.forecast_lead_time = train_params['forecast_lead_time']
        self.lead_time_phases = train_params['lead_time_phases']
        self.early_stopping_patience = train_params['early_stopping']['patience']
        self.min_delta = train_params['early_stopping']['min_delta']
        self.base_path = base_path
        self.target_model_name = target_model_name

        self.target_model = filter_with_nn_embed
        self.sys_model = sys_model
        self.train_params = train_params
        self.saved_models_path = saved_models_path
        self.device = device

        self.best_val_bp_loss = float('inf')
        self.no_improve_epochs = 0
        self.best_val_bp_loss_idx = 0


        self.train_start_time = datetime.now().strftime("%Y_%m_%d_%H")
        # 统一的基础路径结构
        self.base_save_path = os.path.join(
            base_path,
            "results",
            target_model_name,
            self.train_start_time  # 使用时间戳作为顶层目录
        )
        # 自动创建标准化的子目录结构
        self.path_config = {
            'models': os.path.join(self.base_save_path, "models"),
            'checkpoints': os.path.join(self.base_save_path, "checkpoints"),
            'logs': os.path.join(self.base_save_path, "logs"),
            'history': os.path.join(self.base_save_path, "models/history")
        }
        # 创建所有需要的目录
        for path in self.path_config.values():
            os.makedirs(path, exist_ok=True)

        # 定义关键文件路径
        self.best_model_path = os.path.join(self.path_config['models'], "best_model.pt")
        self.final_model_path = os.path.join(self.path_config['models'], f"final_model_{self.train_start_time}.pt")


        self.optimizer = AdamW(list(filter_with_nn_embed.nn_q.parameters()) + list(filter_with_nn_embed.nn_r.parameters()),
                               lr=self.train_params["lr"], weight_decay=self.train_params["wd"])
        self.scheduler_switch_epoch = 2
        self.scheduler = ReduceLROnPlateau(
            self.optimizer,
            mode='min',
            factor=0.1,
            patience=3,
            threshold=1e-5,
            cooldown=0,
            min_lr=1e-8
        )
        self.writer = SummaryWriter()
        self.current_phase_idx = 0

        # 初始化 metric
        self.train_loss_metric = "mse"
        self.display_metrics_list = ["nse"]
        self.batch_display_interval = 1

        # 添加状态保存属性
        self.current_phase_idx = 0
        self.no_improve_epochs = 0
        self.best_val_bp_loss = float('inf')
        self.loss_train = [float('inf')] * self.train_epochs
        self.loss_cv = [float('inf')] * self.train_epochs

        self.checkpoint_save_interval = 5
        # 新增属性：记录上一次检查点保存的 epoch
        self.last_checkpoint_epoch = -self.checkpoint_save_interval - 1  # 初始化为负值，确保第一次保存不受限制
    def train(self, train_loader, val_loader, checkpoint=None):
        return train_nn(self, train_loader, val_loader, checkpoint)

    def test(self, test_loader, max_batches=None, enable_plot=True):
        """测试接口: 支持限制前几个 batch 以快速验证。"""
        return test_nn(self, test_loader, max_batches=max_batches, enable_plot=enable_plot)
