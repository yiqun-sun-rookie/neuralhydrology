"""Additive statistics grouped by issue hour, with paired time-block draws."""
from __future__ import annotations

import numpy as np

FIELDS = ('n', 'sy', 'sy2', 'sp', 'sp2', 'spo', 'sse', 'ae')


class IssueAccumulator:
    def __init__(self, n_times, n_leads):
        self.stats = np.zeros((n_times, n_leads, 8), dtype=np.float64)

    def update(self, pred, obs, issue_index):
        p, o = np.asarray(pred, dtype=np.float64), np.asarray(obs, dtype=np.float64)
        ids = np.asarray(issue_index)
        if p.ndim != 2 or p.shape != o.shape or p.shape[1] != self.stats.shape[1]:
            raise ValueError('Prediction and observation shape/lead mismatch')
        if ids.shape != (len(p),) or not np.issubdtype(ids.dtype, np.integer):
            raise ValueError('Issue indices must be an aligned integer vector')
        if np.any(ids < 0) or np.any(ids >= len(self.stats)):
            raise ValueError('Issue indices outside registered timeline')
        if not np.isfinite(p).all() or not np.isfinite(o).all():
            raise ValueError('Nonfinite prediction or observation')
        size = len(self.stats)
        count = np.bincount(ids, minlength=size)
        for lead in range(p.shape[1]):
            op, pp = o[:, lead], p[:, lead]
            err = pp - op
            self.stats[:, lead, 0] += count
            for field, values in enumerate((op, op * op, pp, pp * pp, pp * op, err * err, np.abs(err)), 1):
                self.stats[:, lead, field] += np.bincount(ids, weights=values, minlength=size)


def metrics(stats):
    s = np.asarray(stats, dtype=np.float64)
    n, sy, sy2, sp, sp2, spo, sse, ae = np.moveaxis(s, -1, 0)
    if not np.isfinite(s).all() or np.any(n < 2) or np.any(sse < 0):
        raise ValueError('Invalid sufficient statistics')
    den = sy2 - sy * sy / n
    var_p = sp2 - sp * sp / n
    if np.any(den <= 0):
        raise ValueError('Nonpositive observation variance')
    with np.errstate(divide='ignore', invalid='ignore'):
        r = (spo - sp * sy / n) / np.sqrt(den * var_p)
        alpha = np.sqrt(var_p / den)
        beta = sp / sy
        kge = 1 - np.sqrt((r - 1)**2 + (alpha - 1)**2 + (beta - 1)**2)
    return {'nse': 1 - sse / den, 'rmse': np.sqrt(sse / n), 'mae': ae / n,
            'kge': kge, 'correlation': r, 'variability_ratio': alpha, 'bias_ratio': beta}


def circular_block_totals(values, length):
    a = np.asarray(values)
    if not 1 <= length <= len(a):
        raise ValueError('Block length outside available timeline')
    extended = np.concatenate((a, a[:length - 1]), axis=0)
    prefix = np.concatenate((np.zeros_like(a[:1]), np.cumsum(extended, axis=0)), axis=0)
    return prefix[length:] - prefix[:-length]


def paired_draws(model_stats, block_length, n_draws, seed):
    """Return per-lead NSE draws [draw, method, lead], same time sample throughout.

    Draw complete circular blocks then a final truncated block to keep exactly
    the original number of issue-hour clusters. Observation denominators are
    recalculated in every replicate, not held at their original values.
    """
    a = np.asarray(model_stats, dtype=np.float64)
    if a.ndim != 4 or a.shape[-1] != 8:
        raise ValueError('Expected [method, issue hour, lead, field]')
    # NSE requires only four sufficient statistics.
    compact = a[..., [0, 1, 2, 6]].transpose(1, 0, 2, 3)
    n = len(compact)
    whole, remainder = divmod(n, block_length)
    full = circular_block_totals(compact, block_length)
    partial = circular_block_totals(compact, remainder) if remainder else None
    rng = np.random.default_rng(seed)
    output = np.empty((n_draws, a.shape[0], a.shape[2]), dtype=np.float64)
    for start in range(0, n_draws, 100):
        stop = min(start + 100, n_draws)
        indexes = rng.integers(0, n, size=(stop - start, whole + bool(remainder)))
        totals = full[indexes[:, :whole]].sum(axis=1)
        if remainder:
            totals += partial[indexes[:, -1]]
        count, sy, sy2, error = np.moveaxis(totals, -1, 0)
        denominator = sy2 - sy * sy / count
        if not np.isfinite(denominator).all() or np.any(denominator <= 0):
            raise ValueError('Degenerate resample; no silent replicate exclusion')
        output[start:stop] = 1 - error / denominator
    return output
