import torch
import torch.nn as nn
import time
from Filters.Linear_KF import KalmanFilter

def KFTest(args,           # 包含所有设置的参数对象，通常包括训练参数和其他配置。
           SysModel,       # 系统模型对象，包含状态转移和观测模型等信息。
           test_input,     # 测试数据输入，通常是观测值。
           test_target,    # 测试数据的真实状态，用于计算误差。
           allStates=True, # 布尔值，指示是否在所有状态上计算误差。
           randomInit=False, # 是否使用随机初始化状态。
           test_init=None,   # 如果使用随机初始化，则此参数提供测试数据的初始状态。
           test_lengthMask=None): # 可选参数，用于处理变长序列的掩码。
    # 定义损失函数为均方误差
    loss_fn = nn.MSELoss(reduction='mean')

    # 初始化误差存储数组
    MSE_KF_linear_arr = torch.zeros(args.N_T)
    # 为卡尔曼滤波器输出分配内存
    KF_out = torch.zeros(args.N_T, SysModel.m, args.T_test)

    # 若只关注位置信息，设置相应的掩码
    # 设置相应的掩码
    if not allStates:
        loc = torch.tensor([True, False, False] if SysModel.m != 2 else [True, False])

    if not allStates:
        loc = torch.tensor([True, False, False])  # 默认掩码，假设位置在第一个
        if SysModel.m == 2:
            loc = torch.tensor([True, False])  # 若状态维度为2，更新掩码

    # 开始计时
    start = time.time()

    # 创建卡尔曼滤波器实例
    KF = KalmanFilter(SysModel, args)
    # 初始化卡尔曼滤波器状态
    if randomInit:
        # SysModel.m2x_0.view(1, SysModel.m, SysModel.m).expand(args.N_T, -1, -1)用于创建一个与测试样本数量相匹配的初始协方差矩阵
        # 这里，m2x_0首先被重塑成一个三维张量，然后通过expand方法扩展以适应批处理操作
        KF.Init_batched_sequence(test_init, SysModel.m2x_0.view(1, SysModel.m, SysModel.m).expand(args.N_T, -1, -1))
    else:
        # 使用模型的默认初始状态和协方差矩阵进行批量初始化卡尔曼滤波器的状态
        # SysModel.m1x_0.view(1, SysModel.m, 1).expand(args.N_T, -1, -1) 创建一个与测试样本数量相匹配的初始状态均值矩阵
        # SysModel.m2x_0.view(1, SysModel.m, SysModel.m).expand(args.N_T, -1, -1) 创建一个与测试样本数量相匹配的初始协方差矩阵
        # 这两个矩阵分别对应于卡尔曼滤波器初始化时的均值和协方差，确保每个测试样本都使用相同的初始状态和协方差进行预测
        KF.Init_batched_sequence(SysModel.m1x_0.view(1, SysModel.m, 1).expand(args.N_T, -1, -1),
                                 SysModel.m2x_0.view(1, SysModel.m, SysModel.m).expand(args.N_T, -1, -1))

    # 使用测试输入生成滤波输出，运行KF
    KF.GenerateBatch(test_input)

    # 结束计时
    end = time.time()
    t = end - start
    KF_out = KF.x

    # 计算每个测试样本的均方误差
    for j in range(args.N_T):  # 遍历每个测试样本
        if allStates:  # 如果考虑所有状态
            if args.randomLength:  # 如果序列长度是随机的
                # 应用长度掩码并计算MSE，只考虑有效长度的状态
                MSE_KF_linear_arr[j] = loss_fn(KF.x[j, :, test_lengthMask[j]],
                                               test_target[j, :, test_lengthMask[j]]).item()
            else:
                # 计算所有状态的MSE，使用完整序列长度
                MSE_KF_linear_arr[j] = loss_fn(KF.x[j, :, :], test_target[j, :, :]).item()
        else:  # 如果只考虑特定状态（由loc掩码指定）
            if args.randomLength:  # 如果序列长度是随机的
                # 应用长度掩码并计算MSE，只考虑有效长度和特定状态
                MSE_KF_linear_arr[j] = loss_fn(KF.x[j, loc, test_lengthMask[j]],
                                               test_target[j, loc, test_lengthMask[j]]).item()
            else:
                # 计算特定状态的MSE，使用完整序列长度
                MSE_KF_linear_arr[j] = loss_fn(KF.x[j, loc, :], test_target[j, loc, :]).item()

    # 计算均方误差的平均值和分贝（dB）形式
    MSE_KF_linear_avg = torch.mean(MSE_KF_linear_arr)
    MSE_KF_dB_avg = 10 * torch.log10(MSE_KF_linear_avg)

    # 计算标准差和置信区间
    MSE_KF_linear_std = torch.std(MSE_KF_linear_arr, unbiased=True)
    KF_std_dB = 10 * torch.log10(MSE_KF_linear_std + MSE_KF_linear_avg) - MSE_KF_dB_avg

    # 打印结果
    print("Kalman Filter - MSE LOSS:", MSE_KF_dB_avg, "[dB]")
    print("Kalman Filter - STD:", KF_std_dB, "[dB]")
    print("Inference Time:", t)

    # 返回误差数据和滤波输出
    return [MSE_KF_linear_arr, MSE_KF_linear_avg, MSE_KF_dB_avg, KF_out]
