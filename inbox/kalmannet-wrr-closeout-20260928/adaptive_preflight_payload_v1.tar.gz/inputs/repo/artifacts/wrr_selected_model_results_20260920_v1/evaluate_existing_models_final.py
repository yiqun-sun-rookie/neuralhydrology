"""Correct evaluation adapter: use each registered model's trained configuration.

Architecture and all non-weight model settings come from the retrieved training YAML.
Original 48 output positions preserve the comparison's window domain; report 0..24.
"""
from __future__ import annotations
import argparse,gc,hashlib,importlib,importlib.util,json,os,shutil,sys,time,traceback
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PROJECT=HERE/'source/kalmannet'
FILTERS=HERE/'source/filters'
HELPERS=HERE/'source/protocol'
LEADS=48
BATCH=256
sys.dont_write_bytecode=True

def sha(path):
    path=str(Path(path).resolve())
    path='\\\\?\\'+path if os.name=='nt' and not path.startswith('\\\\?\\') else path
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(4*1024*1024),b''):h.update(block)
    return h.hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def write(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def now():return time.strftime('%Y-%m-%dT%H:%M:%S%z')

def main():
    cli=argparse.ArgumentParser();cli.add_argument('--preflight',action='store_true');args=cli.parse_args()
    run=HERE/('preflight_003' if args.preflight else 'run_003')
    run.mkdir(exist_ok=False)
    started=time.perf_counter()
    state=dict(status='PREPARING',started_at=now(),cases=[],loads=[],training_attempts=[],
               authorization='User go until complete results: accepted three-seed existing-model selection; no new training or test-driven reselection.')
    write(run/'status.json',state)
    registry=read(HERE/'input_registry.json');protocol=read(HERE/'protocol.json')
    assert protocol['config']==dict(hidden_size=64,num_layers=1,in_out_mult=15,lr='0.01')
    source_records={str(Path(r['path']).resolve()):r for r in read(HERE/'source_manifest.json')}
    allowed={Path(registry['test']['path']).resolve(),Path(registry['noise']['path']).resolve()}
    allowed|={Path(r['checkpoint']).resolve() for r in registry['seeds'].values()}
    comparator_registry=read(HERE/'comparator_reuse_registry.json')
    for item in comparator_registry:
        assert sha(item['path'])==item['sha256']
        allowed.add(Path(item['path']).resolve())
    protected={str(p):sha(p) for p in allowed}
    for p in [HERE/'protocol.json',HERE/'input_registry.json',HERE/'source_manifest.json',HERE/'retrieval_verification.json',
              ROOT/'draft/latex/manuscript_24h.tex',Path('C:/Users/yiqun/Downloads/WRR_2026WR044505_revised_clean_HM_agreed_edits.docx')]:
        protected[str(p)]=sha(p)
    finder=None
    try:
        assert all(sha(p)==r['sha256'] for p,r in source_records.items())
        assert sha(registry['test']['path'])==registry['test']['sha256']
        assert sha(registry['noise']['path'])==registry['noise']['sha256']
        assert all(sha(r['checkpoint'])==r['sha256'] for r in registry['seeds'].values())
        for name in ('TEMP','TMP','TORCH_HOME','TORCH_EXTENSIONS_DIR','MPLCONFIGDIR','XDG_CACHE_HOME','NUMBA_CACHE_DIR'):
            p=run/'cache'/name;p.mkdir(parents=True);os.environ[name]=str(p)
        os.environ['PYTHONDONTWRITEBYTECODE']='1';os.environ['NO_TQDM']='1';os.environ['VALIDATION_QUIET']='1'
        shutil.copyfile(HELPERS/'dpr_config.yaml',run/'dpr_config.yaml')
        spec=importlib.util.spec_from_file_location('source_guard',HELPERS/'recheck.py')
        guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
        guard.RUN=run;guard.sha=sha
        guard.install_file_guard(allowed)
        os.chdir(run)
        sys.path[:]=[str(PROJECT),str(FILTERS),str(HELPERS),str(guard.FILTERS)]+[
            p for p in sys.path if p and Path(p).resolve() not in {ROOT,HERE,guard.FILTERS}]
        class SealedFinder(guard.SnapshotOnlyFinder):
            def find_spec(self,fullname,path=None,target=None):
                if fullname.split('.')[0] in {'draft','src'}:
                    resolved=importlib.machinery.PathFinder.find_spec(fullname,path)
                    if resolved is None:raise ImportError('Missing sealed module: '+fullname)
                    if resolved.origin is not None:
                        origin=str(Path(resolved.origin).resolve())
                        if origin not in self.records or sha(origin)!=self.records[origin]['sha256']:
                            raise ImportError('Unsealed import: '+fullname)
                        self.imports[fullname]=origin
                    return resolved
                return super().find_spec(fullname,path,target)
        finder=SealedFinder((PROJECT,FILTERS),source_records);sys.meta_path.insert(0,finder)
        import numpy as np
        import torch
        import yaml
        from statistics_core import IssueAccumulator,metrics
        from replay_helpers import OriginalRoutineCapture,save_arrays
        assert torch.__version__=='2.4.0' and torch.cuda.is_available(),'Use registered knet_clean runtime'
        torch.set_grad_enabled(False);torch.manual_seed(42);torch.backends.cudnn.benchmark=False
        torch.cuda.reset_peak_memory_stats()
        original_load=torch.load
        cache={}
        def guarded_load(path,*a,**kw):
            p=guard.checked_input(path,allowed)
            if p not in cache:
                cache[p]=original_load(p,*a,**kw);state['loads'].append(dict(path=str(p),sha256=sha(p),at=now()))
            return cache[p]
        torch.load=guarded_load
        def forbidden(*a,**kw):
            state['training_attempts'].append('backward_or_optimizer_step')
            raise RuntimeError('Training forbidden in existing-model evaluation')
        torch.Tensor.backward=forbidden;torch.autograd.backward=forbidden
        for cls in vars(torch.optim).values():
            if isinstance(cls,type) and issubclass(cls,torch.optim.Optimizer):cls.step=forbidden
        paper=importlib.import_module('draft.scripts.generate_paper_metrics')
        paper.Pipeline.train=forbidden
        paper.TEST_DATA_PATHS=[registry['test']['path']]
        paper.UKF_PATH=Path(registry['noise']['path'])
        paper.UKF_CONFIG_PATH=Path(registry['noise']['config'])
        original_args=paper.build_args
        requested=protocol['config']
        training_configs={seed:yaml.safe_load((HERE/'inputs'/f'seed{seed}'/'config.yaml').read_text(encoding='utf-8')) for seed in (42,43,44)}
        trained_model=training_configs[42]['model']
        assert all(c['model']==trained_model for c in training_configs.values())
        def selected_args(config,*a,**kw):
            config=json.loads(json.dumps(config))
            if config['model']['type'].lower()=='knet':
                # Replace the whole model specification, including absent bounds.
                # This removes legacy evaluation overrides that belong to another model.
                config['model']=json.loads(json.dumps(trained_model))
                config['runtime']['use_amp']=False
                config['runtime']['use_torch_compile']=False
            return original_args(config,*a,**kw)
        paper.build_args=selected_args
        live={}
        for name in ('build_knet','build_trainable_kf'):
            builder=getattr(paper,name)
            def wrap(original,kind):
                def build(*a,**kw):
                    model=original(*a,**kw)
                    params=sum(p.numel() for p in model.parameters())
                    if kind=='build_knet':
                        assert params==185448
                        expected_bounds={'dv':[50.,500.],'dg':[50.,2450.],'hq':[0.,20.],'hs':[5.,5000.],'q':[0.,5.]}
                        actual_bounds={k:[float(getattr(model,k+'_lb')),float(getattr(model,k+'_ub'))] for k in expected_bounds}
                        assert actual_bounds==expected_bounds
                        assert model.enable_clamp_scale is True
                        requested_clamps=trained_model['knet']['clamp_scale']
                        for k,v in requested_clamps.items():
                            if k=='enable':continue
                            np.testing.assert_allclose(model.clamp_scale_info[k].detach().cpu().numpy(),np.asarray(v,dtype=np.float32),rtol=0,atol=0)
                        write(run/'effective_neural_model_config.json',dict(model=trained_model,effective_state_bounds=actual_bounds,
                            validation='Exact agreement with retrieved training YAML and hashed network-class defaults; architecture, bounds, input clamps and scales all checked.'))
                    load=model.load_state_dict
                    def strict_load(sd,*a,**kw):
                        kw['strict']=True;result=load(sd,*a,**kw)
                        for p in model.parameters():p.requires_grad_(False)
                        live['before']={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
                        live['parameters']=params
                        return result
                    model.load_state_dict=strict_load;live['model']=model
                    return model
                return build
            setattr(paper,name,wrap(builder,name))
        original_epoch=paper.run_one_epoch
        def eval_epoch(*a,**kw):
            if kw.get('is_training') is not False:return forbidden()
            return original_epoch(*a,**kw)
        paper.run_one_epoch=eval_epoch
        environment=dict(python=sys.version,executable=sys.executable,torch=torch.__version__,numpy=np.__version__,
            cuda=torch.version.cuda,cudnn=torch.backends.cudnn.version(),device=torch.cuda.get_device_name(0),
            batch_size=BATCH,evaluation_random_seed=42,cudnn_benchmark=False,matmul_precision=torch.get_float32_matmul_precision())
        write(run/'environment.json',environment)
        cfg=yaml.safe_load(paper.LOCAL_CONFIG_PATH.read_text(encoding='utf-8'))
        cfg['data']['dataset_path']={'test':registry['test']['path']}
        from types import SimpleNamespace
        from knet.modules.pipeline.core_fun import system_model_forecast
        toy=SimpleNamespace(m=1,h=lambda x:x,f=lambda x,u:x+1)
        z=torch.zeros((1,1,50));_,fc=system_model_forecast(toy,z,z,z,lead_time=LEADS)
        assert torch.equal(fc[0,0],torch.arange(LEADS,dtype=z.dtype))
        if args.preflight:
            checkpoints=[]
            model_args=selected_args(cfg,torch.zeros(800),torch.zeros(800));model_args.device='cuda'
            system=paper._init_mod.initialize_system_model(800,800,device='cuda')
            for seed in (42,43,44):
                r=registry['seeds'][str(seed)];model=paper.build_knet(system,model_args)
                checkpoint=torch.load(r['checkpoint'],map_location='cpu',weights_only=False)
                model.load_state_dict(checkpoint.get('model_state_dict',checkpoint))
                assert int(checkpoint['epoch'])+1==r['best_epoch_one_based']
                checkpoints.append(dict(seed=seed,parameters=live['parameters'],epoch_one_based=int(checkpoint['epoch'])+1,
                                        strict_weights_loaded=True,model_keys=list(checkpoint) if isinstance(checkpoint,dict) else None))
                del model
            write(run/'model_interface_checks.json',checkpoints)
            state.update(status='PREFLIGHT_PASS',synthetic_time_mapping=True,model_forward_executed=False,
                         test_data_loaded=False,finished_at=now())
            write(run/'status.json',state)
            print('PREFLIGHT_PASS: all three existing weights fit the selected frozen network; no model forward or test data load.',flush=True)
            return
        assert read(HERE/'preflight_002/status.json')['status']=='PREFLIGHT_PASS'
        ds=torch.load(registry['test']['path'],map_location='cpu',weights_only=False)
        tm=ds.tm_hours.squeeze().numpy().astype(np.float64);obs=ds.qobs.squeeze().numpy()
        assert ds.window_size==800 and len(ds)==len(tm)-799 and len(tm)==15780 and np.all(np.diff(tm)==1)
        assert np.isfinite(obs).all()
        loader=paper.DataLoader(ds,batch_size=BATCH,shuffle=False,num_workers=0)
        paper.load_test_data=lambda config,batch_size:(loader,ds)
        n_issues=len(tm)-LEADS+1
        write(run/'time_contract.json',dict(actual_leads=list(range(25)),original_output_positions=LEADS,
            n_hours=len(tm),n_windows=len(ds),window_hours=800,issue_hours=n_issues,
            expected_pairs_per_lead=len(ds)*(800-LEADS+1),forecast_includes_current_slot_zero=True,
            physical_time_step_hours=1,test_dataset_sha256=registry['test']['sha256']))
        class TimeAccumulator:
            def __init__(self,max_lt,q25,q75):
                assert max_lt==LEADS
                self.grouped=IssueAccumulator(n_issues,25);self.n_batches=0;self.cursor=0
            def update(self,forecast,observed):
                pred=np.asarray(forecast).reshape(-1,LEADS)[:,:25]
                target=np.asarray(observed).reshape(-1,LEADS)[:,:25]
                feasible=800-LEADS+1
                assert len(pred)%feasible==0
                size=len(pred)//feasible
                ids=(np.arange(self.cursor,self.cursor+size)[:,None]+np.arange(feasible)[None,:]).ravel()
                target_ids=ids[:,None]+np.arange(25)[None,:]
                assert np.array_equal(target,obs[target_ids])
                assert np.all(tm[target_ids]-tm[ids,None]==np.arange(25)[None,:])
                self.grouped.update(pred,target,ids);self.n_batches+=1;self.cursor+=size
                if self.n_batches%5==0 or self.cursor==len(ds):
                    print(f"PROGRESS {state['current_case']} {self.cursor}/{len(ds)} windows",flush=True)
        paper.RunningRegimeStats=TimeAccumulator
        diagnostic=importlib.import_module('draft.scripts.analyze_state_updates')
        specs=diagnostic.build_nonoverlapping_slices(len(ds),ds.window_size)
        assert len(specs)==20
        cases=[(f'neural_seed{seed}',seed) for seed in (42,43,44)]
        # Two missing comparator issue-statistic files are regenerated with the
        # registered unchanged implementations to support paired uncertainty.
        # The two comparator runs from attempt 001 used their correct unchanged settings.
        # Preserve and reuse those complete results; do not repeat their computation.
        assert read(HERE/'run_001/status.json')['status']=='COMPLETE'
        for comparator in ('learned_noise','hand_tuned'):
            prior=HERE/'run_001'/comparator
            record=read(prior/'metrics.json')
            assert record['status']=='COMPLETE' and record['max_nse_difference_from_original_comparator']<1e-9
            target=run/comparator;target.mkdir()
            for filename in ('metrics.json','issue_statistics.npz'):
                shutil.copyfile(prior/filename,target/filename)
                assert sha(prior/filename)==sha(target/filename)
            record['reused_from']=str(prior);state['cases'].append(record)
        common_obs_stats=None
        state['status']='RUNNING';write(run/'status.json',state)
        old_values=read(Path('C:/Users/yiqun/.codex/worktrees/c7a4/kalmannet/artifacts/comment_112_signed_state_20260916/source_snapshot/test_comparison_20260915/delivery_001/paper_values.json'))
        for name,seed in cases:
            case=run/name;case.mkdir();state['current_case']=name;write(run/'status.json',state)
            paper.project_root=case
            torch.manual_seed(42)
            if seed is not None:
                paper.KNET_PATH=Path(registry['seeds'][str(seed)]['checkpoint'])
                evaluate=lambda:paper.eval_knet(cfg,torch.device('cuda'),LEADS,BATCH,0,1)
            elif name=='learned_noise':evaluate=lambda:paper.eval_ukf(cfg,torch.device('cuda'),LEADS,BATCH,0,1)
            else:
                live.clear();evaluate=lambda:paper.eval_handtuned(torch.device('cuda'),LEADS,BATCH,0,1)
            print('START '+name,flush=True);case_start=time.perf_counter()
            acc=evaluate();assert acc.cursor==len(ds)
            stats=acc.grouped.stats
            assert np.all(stats.sum(axis=0)[:,0]==11280693)
            if common_obs_stats is None:common_obs_stats=stats[...,:3].copy()
            else:np.testing.assert_allclose(stats[...,:3],common_obs_stats,rtol=0,atol=1e-10)
            values=metrics(stats.sum(axis=0))
            save_arrays(case/'issue_statistics.npz',stats=stats,issue_hours=tm[:n_issues],observation=obs,actual_leads=np.arange(25))
            point={k:v.tolist() for k,v in values.items()}
            unchanged=not live or all(torch.equal(live['model'].state_dict()[k].detach().cpu(),v) for k,v in live['before'].items())
            assert unchanged
            row=dict(name=name,seed=seed,status='COMPLETE',n_windows=acc.cursor,n_batches=acc.n_batches,
                     parameters_unchanged=unchanged,mean_nse_1_12=float(values['nse'][1:13].mean()),
                     mean_nse_13_24=float(values['nse'][13:25].mean()),metrics=point,seconds=time.perf_counter()-case_start)
            if seed is None:
                diff=np.max(np.abs(values['nse']-np.asarray(old_values['metrics'][name]['nse'])))
                row['max_nse_difference_from_original_comparator']=float(diff)
                assert diff<1e-9,'Unchanged comparator did not reproduce original results'
            write(case/'metrics.json',row)
            if seed is not None:
                capture=OriginalRoutineCapture(diagnostic._run_neural_gain,'neural_gain')
                raw=capture.run(ds,specs,torch.device('cuda'))
                assert raw['increments'].shape==(15780,5)
                assert np.array_equal(raw['increments'],raw['original_increments'])
                assert np.array_equal(raw['hours'],tm) and np.array_equal(raw['observation'],obs)
                assert all(np.isfinite(v).all() for v in raw.values())
                assert all(torch.equal(live['model'].state_dict()[k].detach().cpu(),v) for k,v in live['before'].items())
                save_arrays(case/'state_diagnostics.npz',**raw)
                row['state_hours']=15780;row['state_arithmetic_verified']=True
                write(case/'metrics.json',row)
            state['cases'].append(row);write(run/'status.json',state)
            print('DONE '+name+f" NSE 1-12={row['mean_nse_1_12']:.6f}; 13-24={row['mean_nse_13_24']:.6f}",flush=True)
            live.clear();gc.collect();torch.cuda.empty_cache()
        checks=dict(all_five_cases_complete=len(state['cases'])==5,
                    trained_model_configuration_matched=True,
                    source_unchanged=all(sha(p)==r['sha256'] for p,r in source_records.items()),
                    protected_unchanged=all(sha(p)==digest for p,digest in protected.items()),
                    no_training_attempts=not state['training_attempts'],all_parameters_unchanged=all(r['parameters_unchanged'] for r in state['cases']),
                    three_new_state_diagnostics=sum(r.get('state_hours')==15780 for r in state['cases'])==3,
                    shared_time_observation_domain=True,registered_inputs_only=True)
        write(run/'acceptance.json',checks);assert all(checks.values())
        state.update(status='COMPLETE',finished_at=now(),seconds=time.perf_counter()-started)
        write(run/'status.json',state)
        print('COMPLETE: three selected-model tests and state diagnostics; two unchanged comparator statistics.',flush=True)
    except BaseException as exc:
        state.update(status='FAILED',error=repr(exc),traceback=traceback.format_exc(),failed_at=now())
        write(run/'status.json',state);raise
    finally:
        if finder is not None:write(run/'import_ledger.json',finder.imports)
        write(run/'protected_after.json',{p:dict(before=h,after=sha(p),unchanged=sha(p)==h) for p,h in protected.items()})
        write(run/'load_ledger.json',state['loads'])
        import psutil
        import torch
        write(run/'resources.json',dict(seconds=time.perf_counter()-started,process_memory=psutil.Process().memory_info()._asdict(),
                    peak_cuda_allocated=torch.cuda.max_memory_allocated() if torch.cuda.is_initialized() else 0,
                    peak_cuda_reserved=torch.cuda.max_memory_reserved() if torch.cuda.is_initialized() else 0))

if __name__=='__main__':main()
