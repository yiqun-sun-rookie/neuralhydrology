"""Frozen 28-case neural evaluator. Only --execute-case may access test tensors.

Controller acceptance is required after independent review of preflight evidence.
No retraining, optimizer, automatic retries, resume, or test-driven selection.
"""
import argparse
import copy
import gc
import hashlib
from pathlib import Path
import time
import traceback
import sys

import neural_runtime as rt


def validate_targets(target, ids, observation, hours, leads):
    import numpy as np
    target, ids, leads = np.asarray(target), np.asarray(ids), np.asarray(leads)
    if target.shape != (len(ids), len(leads)) or not np.array_equal(leads, np.arange(len(leads))):
        raise ValueError('Expected current-inclusive contiguous saved lead domain')
    indexes = ids[:, None] + leads[None, :]
    if np.any(indexes < 0) or np.any(indexes >= len(observation)):
        raise ValueError('Target outside timeline')
    if not np.array_equal(target, observation[indexes]):
        raise ValueError('Target observations differ from exact issue+lead')
    if not np.all(hours[indexes] - hours[ids, None] == leads[None, :]):
        raise ValueError('Target time is not issue time plus lead hours')


def validate_preflight_time_mapping(runtime, result, dataset, window_indices, source):
    """Check actual validation batch unfolding against the bound source timeline."""
    import numpy as np
    windows = np.asarray(window_indices, dtype=np.int64)
    size = len(windows)
    shapes = dict(observation=(size,1,800), hours=(size,1,800),
                  updated=(size,5,800), outputs=(size,1,800),
                  forecast_states=(size*753,5,48), predictions=(size*753,1,48))
    for name, expected in shapes.items():
        if tuple(result[name].shape) != expected:
            raise ValueError('Actual validation shape mismatch: ' + name)
    target = runtime.core.rearrange_data_unfold(result['observation'],48)
    target_hours = runtime.core.rearrange_data_unfold(result['hours'],48)
    if tuple(target.shape) != (size,753,48) or tuple(target_hours.shape) != (size,753,48):
        raise ValueError('Actual validation unfolded target shape mismatch')
    target = target.detach().cpu().numpy().reshape(-1,48)
    target_hours = target_hours.detach().cpu().numpy().reshape(-1,48)
    # Identical issue ordering/formula and target unfolding to formal scoring.
    ids = (windows[:,None] + np.arange(753)[None,:]).ravel()
    leads = np.arange(48)
    observation = dataset.qobs.detach().cpu().numpy().reshape(-1)
    hours = dataset.tm_hours.detach().cpu().numpy().reshape(-1).astype(np.float64)
    validate_targets(target,ids,observation,hours,leads)
    validate_targets(target[:,:25],ids,observation,hours,np.arange(25))
    if not np.array_equal(target_hours,hours[ids[:,None]+leads[None,:]]):
        raise ValueError('Actual batch target hours differ from exact issue+lead')
    issue_hours = result['hours'][:,0,:753].detach().cpu().numpy().reshape(-1)
    if not np.array_equal(issue_hours,hours[ids]):
        raise ValueError('Actual batch issue hours differ from source issue hours')
    if not np.all(target_hours.astype(np.float64)-issue_hours[:,None] == leads[None,:]):
        raise ValueError('Actual batch target time is not issue time plus lead hours')
    arrays = dict(issue_ids=ids,issue_hours=issue_hours,target_observations=target,target_hours=target_hours)
    return dict(passed=True,source=dict(source),window_count=size,window_hours=800,
                window_indices=windows.tolist(),issues_per_window=753,issue_count=len(ids),
                target_pair_count=int(target.size),saved_target_pair_count=int(target[:,:25].size),
                actual_leads=leads.tolist(),saved_leads=list(range(25)),
                actual_shapes={k:list(v) for k,v in shapes.items()},unfolded_shape=[size,753,48],
                target_observations_exact=True,target_hours_exact=True,issue_hours_exact=True,
                target_minus_issue_equals_lead=True,saved_validate_targets_passed=True,
                arrays={k:dict(shape=list(v.shape),dtype=str(v.dtype),sha256=hashlib.sha256(v.tobytes()).hexdigest()) for k,v in arrays.items()})


def engine_bindings():
    return {str(rt.ROOT / name): rt.sha(rt.ROOT / name) for name in ('evaluate_neural.py','neural_runtime.py','diagnostic_capture.py','test_neural_evaluation.py','prepare_test_states.py')}


def finite_tensors(result):
    import torch
    for name in ('updated','outputs','forecast_states','predictions'):
        value = result[name]
        if value is not None and (value.dtype != torch.float32 or not torch.isfinite(value).all()):
            raise ValueError('Nonfinite/non-float32 trajectory: ' + name)


def digest_tensor(value):
    return hashlib.sha256(value.detach().cpu().contiguous().numpy().tobytes()).hexdigest()


def compare_tensor_bits(reference, value):
    """Require shape/dtype identity; raw element bytes are the parity gate."""
    import numpy as np
    import torch
    if reference.shape != value.shape or reference.dtype != value.dtype:
        raise ValueError('Raw-bit parity requires identical shape and original dtype')
    left = reference.detach().cpu().contiguous()
    right = value.detach().cpu().contiguous()
    # Void elements compare each original element's complete byte representation,
    # retaining signed zero and without a numeric conversion or tolerance.
    raw_type = np.dtype(('V',left.element_size()))
    left_bits = left.reshape(-1).numpy().view(raw_type)
    right_bits = right.reshape(-1).numpy().view(raw_type)
    bit_differences = int(np.count_nonzero(left_bits != right_bits))
    numeric_differences = int(torch.count_nonzero(left != right))
    return dict(bitwise_equal=bit_differences == 0,numeric_equal=torch.equal(left,right),
                different_bit_elements=bit_differences,different_numeric_elements=numeric_differences,
                max_absolute_difference=float((left-right).abs().max()) if left.numel() else 0.,
                shape=list(left.shape),dtype=str(left.dtype))


def weights_snapshot(model):
    return {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}


def verify_weights(model, before):
    import torch
    if set(before) != set(model.state_dict()) or not all(torch.equal(before[key], value.detach().cpu()) for key, value in model.state_dict().items()):
        raise ValueError('Learned weights changed during inference')


def parity_case(case, output, dataset, corrected, validation_source):
    import torch
    import numpy as np
    from torch.utils.data import default_collate
    from diagnostic_capture import decomposition
    # Same registered 256 full windows, matching scoring batch size; no test data.
    ds = copy.copy(dataset)
    if case['variant'].endswith('corrected_states'):
        ds.states_all = corrected
    indices = list(range(256))
    batch = default_collate([ds[i] for i in indices])
    references = None
    result_record = dict(case_id=case['case_id'], validation_window_indices=indices, full_window_hours=800,
                         batch_size=256, forecast_positions=48, checks=[], checkpoint_sha256=case['checkpoint_sha256'])
    for label, instrumented, logging, plain in [('pinned_original',False,False,True), ('capture_off',True,False,False), ('capture_on',True,True,False)]:
        runtime = rt.build_model(case, output, instrumented=instrumented, plain_physics=plain)
        before = weights_snapshot(runtime.model)
        if hasattr(runtime.hydro, 'audit_q_calls'): rt.reset_counters(runtime.hydro)
        result = rt.infer(runtime, batch, logging=logging)
        torch.cuda.synchronize()
        finite_tensors(result)
        time_mapping = validate_preflight_time_mapping(runtime,result,dataset,indices,validation_source)
        current = {key: result[key].detach().cpu() for key in ('updated','outputs','forecast_states','predictions')}
        if references is None:
            references = current
        else:
            differences = {}
            for name, value in current.items():
                differences[name] = compare_tensor_bits(references[name],value)
            rt.write_json(output/(label+'_comparison.json'),dict(case_id=case['case_id'],phase=label,comparisons=differences,
                                                               input_checkpoint_sha256=case['checkpoint_sha256'],
                                                               baseline_sha256={k:digest_tensor(v) for k,v in references.items()},
                                                               current_sha256={k:digest_tensor(v) for k,v in current.items()}))
            if not all(row['bitwise_equal'] for row in differences.values()):
                raise ValueError(f'Bitwise parity failed: {case["case_id"]} {label}: {differences}')
        check = dict(phase=label, bitwise_equal=True, trajectory_sha256={k:digest_tensor(v) for k,v in current.items()},
                     real_validation_time_mapping=time_mapping)
        if hasattr(runtime.hydro, 'audit_q_calls'):
            rt.check_counters(result['assimilation_counters'], rt.expected_counters(256,800,False))
            rt.check_counters(result['counters'], rt.expected_counters(256,800,True))
            check['assimilation_counters'] = result['assimilation_counters']
            check['total_counters'] = result['counters']
            check['forecast_counters'] = {k:result['counters'][k] - result['assimilation_counters'][k] for k in rt.COUNTERS}
        if logging:
            raw = result['capture'].arrays()
            if not np.array_equal(raw['posterior'], current['updated'].permute(0,2,1).reshape(-1,5).numpy()):
                raise ValueError('Recorded posterior is not actual complete analysis trajectory')
            if not np.array_equal(raw['physical_after'], raw['prior']):
                raise ValueError('Recorded physics is not the actual network propagation')
            check['decomposition'] = decomposition(raw['prior'],raw['proposal'],raw['posterior'])
            check['capture_sha256'] = {k:hashlib.sha256(v.tobytes()).hexdigest() for k,v in raw.items()}
        verify_weights(runtime.model, before)
        check['learned_weights_unchanged'] = True
        check['effective_config'] = runtime.effective
        result_record['checks'].append(check)
        del result, runtime, before, current
        gc.collect()
        torch.cuda.empty_cache()
    result_record['status'] = 'PARITY_PASS'
    return result_record


def preflight(output, cases, bindings, proof):
    import torch
    from types import SimpleNamespace
    protocol = rt.read_json(rt.FORMAL / 'protocol.json')
    data = protocol['data']['val']
    path = rt.REPO / 'data/processed/high_flow_aug' / data['name']
    state_path = rt.FORMAL / 'initial_states' / data['corrected_states_name']
    ds = rt.load_dataset(path, data['sha256'])
    corrected = rt.load_tensor(state_path, data['corrected_states_sha256'], 'corrected_validation_states')
    import prepare_test_states as preparer
    preparer.validate_dataset(ds, expected_rows=data['rows'], expected_window=800)
    if corrected.shape != ds.states_all.shape or corrected.dtype != torch.float32 or not torch.isfinite(corrected).all():
        raise ValueError('Invalid corrected validation states')
    for name in ('p','etpot','qobs','tm_hours'):
        if digest_tensor(getattr(ds,name)) != data['columns_sha256'][name]:
            raise ValueError('Validation column drift: ' + name)
    core = rt.load_core()
    z = torch.zeros((1,1,50), dtype=torch.float32)
    _, forecast = core.system_model_forecast(SimpleNamespace(m=1,f=lambda x,u:x+1,h=lambda x:x),z,z,z,48)
    if not torch.equal(forecast[0,0],torch.arange(48,dtype=torch.float32)):
        raise ValueError('Synthetic current-slot-zero time contract failed')
    bound = dict(bindings)
    bound.update({str(path):data['sha256'],str(state_path):data['corrected_states_sha256']})
    checks = []
    for case in cases:
        case_output = output / case['case_id']
        case_output.mkdir()
        print('PARITY_START ' + case['case_id'], flush=True)
        check = parity_case(case, case_output, ds, corrected,
                            dict(path=str(path),sha256=data['sha256'],split='validation',columns_sha256=data['columns_sha256']))
        rt.write_json(case_output / 'parity.json', check)
        checks.append(check)
        bound[case['checkpoint']] = case['checkpoint_sha256']
        bound[case['config']] = case['config_sha256']
        print('PARITY_PASS ' + case['case_id'], flush=True)
    for name,digest in bound.items(): rt.verify(name,digest)
    return dict(state='PREFLIGHT_PASS_PENDING_INDEPENDENT_REVIEW', case_ids=[c['case_id'] for c in cases],
                cases=checks, source_bindings=bindings, unchanged_bound_inputs=bound, source_compatibility=proof,
                engine_bindings=engine_bindings(), synthetic_time_positions=True,real_validation_time_mapping=True,
                non_test_data=dict(path=str(path),sha256=data['sha256'], corrected_states_path=str(state_path),
                                   corrected_states_sha256=data['corrected_states_sha256'],split='validation',indices=list(range(256))),
                no_training=True,test_tensor_reads=0,test_tensor_hashes=0,scientific_scores=False)


def accepted_execution(case, acceptance_path, original_receipt):
    acceptance = rt.require_acceptance(acceptance_path, 'PREFLIGHT_ACCEPTED')
    preflight_path = Path(acceptance['preflight_receipt']['path'])
    rt.verify(preflight_path, acceptance['preflight_receipt']['sha256'])
    receipt = rt.read_json(preflight_path)
    if receipt['state'] != 'PREFLIGHT_PASS_PENDING_INDEPENDENT_REVIEW' or case['case_id'] not in receipt['case_ids']:
        raise ValueError('Case is not covered by accepted preflight')
    if receipt['engine_bindings'] != engine_bindings():
        raise ValueError('Evaluation implementation changed since accepted preflight')
    for path,digest in receipt['unchanged_bound_inputs'].items(): rt.verify(path,digest)
    initial_path = Path(acceptance['initial_state_receipt']['path'])
    rt.verify(initial_path, acceptance['initial_state_receipt']['sha256'])
    initial = rt.read_json(initial_path)
    if initial['state'] != 'PAIRED_TEST_STATES_COMPLETE' or not initial['paired']['columns_exactly_unchanged']:
        raise ValueError('Required completed test-state receipt missing')
    if case['family'] != 'new' and not case['variant'].startswith('original_outlet'):
        if original_receipt is None: raise ValueError('Historical corrected branch requires passed original-setting reproduction')
        original = rt.read_json(original_receipt)
        required_id = case['case_id'].split('__')[0] + '__original_outlet_original_states'
        if original.get('state') != 'COMPLETE' or original.get('case_id') != required_id or not original.get('historical_reproduction',{}).get('passed'):
            raise ValueError('Historical original-setting branch has not passed reproduction')
        if original.get('checkpoint_sha256') != case['checkpoint_sha256']:
            raise ValueError('Historical branch checkpoint mismatch')
    accepted_environment = receipt.get('environment')
    if not isinstance(accepted_environment,dict):
        raise ValueError('Accepted preflight numerical environment missing')
    return initial_path, initial, accepted_environment


def execute_in_bound_environment(case, output, initial_path, initial, actual_environment, accepted_environment):
    """Environment gate precedes run_case's first test read/hash or model call."""
    rt.require_same_environment(actual_environment,accepted_environment)
    return run_case(case,output,initial_path,initial)


def grouped_metrics(stats, obs, contract, statistics):
    import numpy as np
    records = []
    for row in contract['flow_definitions']['forecast']['frozen_per_lead_thresholds_and_counts']:
        lead = row['lead_hours']
        target = obs[np.arange(len(stats)) + lead]
        masks = dict(low=target < row['q25_mmh'],mid=(target >= row['q25_mmh']) & (target <= row['q75_mmh']),high=target > row['q75_mmh'])
        record = dict(lead_hours=lead,q25_mmh=row['q25_mmh'],q75_mmh=row['q75_mmh'],groups={})
        for name, mask in masks.items():
            total = stats[mask,lead,:].sum(axis=0)
            if total[0] != row['counts'][name]: raise ValueError('Frozen per-lead group count mismatch')
            values = statistics.metrics(total)
            if not all(np.isfinite(v).all() for v in values.values()): raise ValueError('Nonfinite grouped metric')
            record['groups'][name] = dict(count=int(total[0]),metrics={k:float(v) for k,v in values.items()},
                                          rmse_m3s=float(values['rmse']*957000/3600),mae_m3s=float(values['mae']*957000/3600))
        records.append(record)
    return records


def run_case(case, output, initial_path, initial):
    import torch
    import numpy as np
    from torch.utils.data import DataLoader
    from diagnostic_capture import state_summary
    import prepare_test_states as preparer
    contract = rt.read_json(rt.RULES)['evaluation_contract']
    dataset = rt.load_dataset(initial['source_dataset']['path'],initial['source_dataset']['sha256'])
    preparer.validate_dataset(dataset)
    if len(dataset) != 14981: raise ValueError('Wrong test window count')
    for name in preparer.COLUMNS:
        if digest_tensor(getattr(dataset,name)) != initial['paired']['columns_before'][name]['sha256']:
            raise ValueError('Test column drift: ' + name)
    # Both paired outputs are hash-bound, even when original stored states are selected.
    for name, record in initial['files'].items(): rt.verify(initial_path.parent / name,record['sha256'])
    original_state_digest = digest_tensor(dataset.states_all)
    if case['variant'].endswith('corrected_states'):
        record = initial['files']['test_corrected_cpu.pt']
        dataset.states_all = rt.load_tensor(initial_path.parent / 'test_corrected_cpu.pt',record['sha256'],'corrected_test_states')
        if digest_tensor(dataset.states_all) != record['tensor']['sha256']:
            raise ValueError('Corrected state tensor mismatch')
    state_digest = digest_tensor(dataset.states_all)
    runtime = rt.build_model(case, output, instrumented=True)
    before = weights_snapshot(runtime.model)
    statistics = rt.frozen_statistics()
    accumulator = statistics.IssueAccumulator(15733,25)
    obs = dataset.qobs.squeeze().numpy()
    hours = dataset.tm_hours.squeeze().numpy().astype(np.float64)
    total_counters = {k:0 for k in rt.COUNTERS}
    assimilation = {k:0 for k in rt.COUNTERS}
    cursor = 0
    batches = 0
    for batch in DataLoader(dataset,batch_size=256,shuffle=False,num_workers=0,drop_last=False):
        rt.reset_counters(runtime.hydro)
        result = rt.infer(runtime,batch,logging=False)
        finite_tensors(result)
        size = batch['qobs'].shape[0]
        rt.check_counters(result['counters'],rt.expected_counters(size,800,True))
        rt.check_counters(result['assimilation_counters'],rt.expected_counters(size,800,False))
        for key in total_counters:
            total_counters[key] += result['counters'][key]
            assimilation[key] += result['assimilation_counters'][key]
        ids = (np.arange(cursor,cursor+size)[:,None] + np.arange(753)[None,:]).ravel()
        pred = result['predictions'].cpu().numpy().reshape(-1,48)[:,:25]
        target = runtime.core.rearrange_data_unfold(result['observation'],48).cpu().numpy().reshape(-1,48)[:,:25]
        validate_targets(target,ids,obs,hours,np.arange(25))
        accumulator.update(pred,target,ids)
        cursor += size
        batches += 1
        del result
        if batches % 5 == 0 or cursor == len(dataset): print(f'FORECAST {case["case_id"]} {cursor}/14981',flush=True)
    stats = accumulator.stats
    if cursor != 14981 or batches != 59 or stats.shape != (15733,25,8): raise ValueError('Incomplete prediction coverage')
    counts = stats.sum(axis=0)[:,0]
    if not np.all(counts == 11280693): raise ValueError('Prediction pair count mismatch')
    expected_multiplicity = np.convolve(np.ones(14981,dtype=np.int64),np.ones(753,dtype=np.int64))
    if not np.array_equal(stats[:,:,0],np.broadcast_to(expected_multiplicity[:,None],(15733,25))):
        raise ValueError('Issue-level multiplicity mismatch')
    values = statistics.metrics(stats.sum(axis=0))
    if not all(np.isfinite(v).all() for v in values.values()): raise ValueError('Nonfinite metric')
    np.savez_compressed(output/'issue_statistics.npz',stats=stats,issue_hours=hours[:15733],observation=obs,actual_leads=np.arange(25))
    result_record = dict(case_id=case['case_id'],checkpoint_sha256=case['checkpoint_sha256'],
                         metrics={k:v.tolist() for k,v in values.items()},error_conversion=957000/3600,
                         rmse_m3s=(values['rmse']*957000/3600).tolist(),mae_m3s=(values['mae']*957000/3600).tolist(),
                         n_windows=cursor,n_batches=batches,pairs_per_lead=counts.tolist(),
                         grouped_metrics=grouped_metrics(stats,obs,contract,statistics),effective_config=runtime.effective,
                         saved_original_state_sha256=original_state_digest,selected_state_sha256=state_digest,
                         original_states_source='dataset.states_all (not reconstructed original replay)',
                         forecast_counters=dict(total=total_counters,assimilation=assimilation,
                                                forecast={k:total_counters[k]-assimilation[k] for k in rt.COUNTERS}))
    if case['family'] != 'new' and case['variant'].startswith('original_outlet'):
        archived = rt.read_json(Path(case['reference'])/'metrics.json')
        differences = {}
        for key, value in values.items():
            factor = 957000/3600 if key in ('rmse','mae') else 1.
            differences[key] = float(np.max(np.abs(value-np.asarray(archived['metrics'][key])))*factor)
        old = np.load(Path(case['reference'])/'issue_statistics.npz',allow_pickle=False)
        for key,new in [('issue_hours',hours[:15733]),('observation',obs),('actual_leads',np.arange(25))]:
            if not np.array_equal(old[key],new): raise ValueError('Historical exact time/observation domain mismatch')
        if not np.array_equal(old['stats'][:,:,0],stats[:,:,0]): raise ValueError('Historical exact count mismatch')
        passed = all(v <= (1e-4 if k in ('rmse','mae') else 1e-6) for k,v in differences.items())
        result_record['historical_reproduction'] = dict(passed=passed,maximum_absolute_differences=differences,
                                                       error_difference_unit='m3/s',dimensionless_tolerance=1e-6,error_tolerance_m3s=1e-4)
        rt.write_json(output/'historical_reproduction.json',result_record['historical_reproduction'])
        if not passed:
            rt.write_json(output/'metrics_before_failed_reproduction.json',result_record)
            raise ValueError('Historical original-setting reproduction failed; affected historical branch stopped')
    rt.write_json(output/'metrics.json',result_record)
    build_slices, iter_batches = rt.load_slice_functions()
    specs = build_slices(len(dataset),dataset.window_size)
    if len(specs) != 20 or sum(end-start for _,start,end in specs) != 15780:
        raise ValueError('Archived non-overlapping slice coverage mismatch')
    parts = {}
    diagnostics_counters = {k:0 for k in rt.COUNTERS}
    diagnostic_batches = []
    for batch,start,end in iter_batches(dataset,specs,batch_size=32):
        sliced = {key:value[:,:,start:end] for key,value in batch.items()}
        rt.reset_counters(runtime.hydro)
        result = rt.infer(runtime,sliced,logging=True,forecast=False)
        finite_tensors(result)
        rt.check_counters(result['counters'],rt.expected_counters(sliced['qobs'].shape[0],end-start,False))
        raw = result['capture'].arrays()
        raw['observation'] = result['observation'][:,0,:].cpu().numpy().reshape(-1)
        raw['hours'] = result['hours'][:,0,:].cpu().numpy().reshape(-1)
        for key,value in raw.items(): parts.setdefault(key,[]).append(value)
        for key in diagnostics_counters: diagnostics_counters[key] += result['counters'][key]
        diagnostic_batches.append(dict(size=sliced['qobs'].shape[0],start=start,end=end,counters=result['counters']))
    raw = {key:np.concatenate(value,axis=0) for key,value in parts.items()}
    if not np.array_equal(raw['hours'],hours) or not np.array_equal(raw['observation'],obs):
        raise ValueError('Diagnostics failed exact complete chronological coverage')
    if not all(np.isfinite(value).all() for value in raw.values()): raise ValueError('Nonfinite diagnostic array')
    np.savez_compressed(output/'state_diagnostics.npz',**raw)
    summary = state_summary(raw,contract['flow_definitions']['state'],runtime.effective['bounds'])
    rt.write_json(output/'state_summary.json',summary)
    verify_weights(runtime.model,before)
    for name in preparer.COLUMNS:
        if digest_tensor(getattr(dataset,name)) != initial['paired']['columns_before'][name]['sha256']:
            raise ValueError('Input column changed during inference')
    if digest_tensor(dataset.states_all) != state_digest: raise ValueError('Initial states changed during inference')
    rt.verify(initial['source_dataset']['path'],initial['source_dataset']['sha256'])
    for name,record in initial['files'].items(): rt.verify(initial_path.parent/name,record['sha256'])
    result_record.update(state='COMPLETE',state_hours=15780,state_slices=specs,diagnostic_batches=diagnostic_batches,
                         diagnostic_counters=diagnostics_counters,learned_weights_unchanged=True,
                         source_input_tensors_unchanged=True,diagnostic_identity=summary['identity'])
    return result_record


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--preflight',action='store_true')
    group.add_argument('--execute-case')
    group.add_argument('--registry-only',action='store_true')
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--acceptance',type=Path,default=rt.ROOT/'neural_preflight_acceptance.json')
    parser.add_argument('--historical-original-receipt',type=Path)
    parser.add_argument('--preflight-family',choices=('all','main','compact','new'),default='all',
                        help='Fixed branch only; permits new-model gates independently of historical failure')
    args = parser.parse_args(argv)
    output = rt.claim_output(args.output)
    started = time.perf_counter()
    rt.write_json(output/'running.json',dict(state='RUNNING',mode='preflight' if args.preflight else 'case' if args.execute_case else 'registry',case_id=args.execute_case))
    bindings = {}
    entry_engine = engine_bindings()
    try:
        cases = rt.case_registry()
        rt.write_json(output/'case_registry.json',cases)
        if args.registry_only:
            rt.write_json(output/'completion.json',dict(state='REGISTRY_COMPLETE',cases=28,test_tensor_reads=0,test_tensor_hashes=0))
            return
        bindings,proof = rt.verify_sources()
        rt.write_json(output/'entry_bindings.json',dict(engine=entry_engine,sources=bindings,source_compatibility=proof))
        selected = next((c for c in cases if c['case_id'] == args.execute_case),None)
        if args.execute_case and selected is None: raise ValueError('Unknown fixed case')
        protocol = rt.read_json(rt.FORMAL/'protocol.json')
        val = protocol['data']['val']
        tensor_paths = [c['checkpoint'] for c in cases]
        tensor_paths += [rt.REPO/'data/processed/high_flow_aug'/val['name'],rt.FORMAL/'initial_states'/val['corrected_states_name']]
        if args.execute_case:
            initial_path,initial,accepted_environment = accepted_execution(selected,args.acceptance,args.historical_original_receipt)
            tensor_paths += [initial['source_dataset']['path']]+[initial_path.parent/name for name in initial['files']]
            if selected['family'] != 'new': tensor_paths.append(Path(selected['reference'])/'issue_statistics.npz')
        rt.install_guard(output,tensor_paths)
        environment = rt.setup_runtime(output)
        rt.write_json(output/'environment.json',environment)
        if args.preflight:
            covered = [c for c in cases if args.preflight_family == 'all' or c['family'] == args.preflight_family]
            record = preflight(output,covered,bindings,proof)
        else:
            record = execute_in_bound_environment(selected,output,initial_path,initial,environment,accepted_environment)
        for path,digest in bindings.items(): rt.verify(path,digest)
        for path,digest in entry_engine.items(): rt.verify(path,digest)
        for case in cases if args.preflight else [selected]:
            rt.verify(case['checkpoint'],case['checkpoint_sha256'])
            rt.verify(case['config'],case['config_sha256'])
        record.update(environment=environment,source_bindings=bindings,engine_bindings=engine_bindings(),seconds=time.perf_counter()-started)
        rt.write_json(output/'completion.json',record)
        print(record['state'],flush=True)
    except BaseException as exc:
        rt.write_json(output/'failure.json',dict(state='FAILED',case_id=args.execute_case,error=repr(exc),traceback=traceback.format_exc(),seconds=time.perf_counter()-started,
                                              entry_engine_bindings=entry_engine,source_bindings=bindings,test_mode=bool(args.execute_case)))
        raise
    finally:
        rt.write_json(output/'import_ledger.json',rt.IMPORT_LEDGER)
        rt.write_json(output/'load_ledger.json',rt.LOAD_LEDGER)
        torch = sys.modules.get('torch')
        cuda_ready = torch is not None and hasattr(torch,'cuda') and torch.cuda.is_initialized()
        rt.write_json(output/'resources.json',dict(seconds=time.perf_counter()-started,peak_cuda_allocated=torch.cuda.max_memory_allocated() if cuda_ready else 0,
                                                  peak_cuda_reserved=torch.cuda.max_memory_reserved() if cuda_ready else 0))
        rt.write_json(output/'output_hashes.json',{str(path.relative_to(output)):rt.sha(path) for path in output.rglob('*') if path.is_file() and 'cache' not in path.parts})


if __name__ == '__main__':
    main()
