"""Capture-only additions at exact frozen source anchors and native-unit summaries."""
import ast


def instrument_source(source, kind):
    additions = []
    def add(anchor, extra):
        nonlocal source
        if source.count(anchor) != 1:
            raise ValueError(f'Instrumentation anchor missing/ambiguous: {anchor}')
        source = source.replace(anchor, anchor + extra, 1)
        additions.append(extra)
    original = source
    if kind == 'network':
        add('        super().__init__()\n', '        self._audit_capture = None\n')
        add('        updated_state = torch.squeeze(updated_state, -1)\n',
            '        if self._audit_capture is not None:\n'
            '            self._audit_capture.proposal(self.m1x_prior, updated_state, INOV.squeeze(-1))\n')
        add('        self.m1x_posterior = updated_state\n',
            '        if self._audit_capture is not None:\n'
            '            self._audit_capture.posterior(self.m1x_posterior)\n')
    elif kind == 'physics':
        add('        self.device = device\n',
            '        self.capture_enabled = False\n'
            '        self.capture_before = torch.empty((0, 5), dtype=torch.float32, device=device)\n'
            '        self.capture_after = torch.empty((0, 5), dtype=torch.float32, device=device)\n')
        add('        dv, hs, dg = self.func_walrus_pond_flood(dv, hs, dg)\n',
            '        if self.capture_enabled:\n'
            '            self.capture_before = torch.stack([dv, dg, hq, hs, q], dim=1).detach().clone()\n')
        add('        next_x = torch.stack([dv, dg, hq, hs, q], dim=1)\n',
            '        if self.capture_enabled:\n'
            '            self.capture_after = next_x.detach().clone()\n')
    else:
        raise ValueError('Unknown instrumentation kind')
    restored = source
    for addition in reversed(additions):
        if restored.count(addition) != 1:
            raise ValueError('Capture removal ambiguous')
        restored = restored.replace(addition, '', 1)
    if ast.dump(ast.parse(restored)) != ast.dump(ast.parse(original)):
        raise ValueError('Capture changes computation syntax')
    return source, dict(capture_removal_restores_ast=True, kind=kind, capture_additions=additions)


class Recorder:
    def __init__(self):
        self.values = {name: [] for name in ('prior', 'proposal', 'innovation', 'posterior', 'physical_before', 'physical_after')}

    def proposal(self, prior, proposal, innovation):
        for name, value in [('prior', prior), ('proposal', proposal), ('innovation', innovation)]:
            self.values[name].append(value.detach().clone())

    def posterior(self, posterior):
        self.values['posterior'].append(posterior.detach().clone())

    def physical(self, before, after):
        self.values['physical_before'].append(before.detach().clone())
        self.values['physical_after'].append(after.detach().clone())

    def arrays(self):
        import torch
        result = {}
        for name, values in self.values.items():
            if not values:
                raise ValueError('Missing actual capture: ' + name)
            result[name] = torch.stack(values, dim=1).reshape(-1, 5).cpu().numpy()
        if len({v.shape for v in result.values()}) != 1:
            raise ValueError('Capture shapes mismatch')
        validate_proposal(result['prior'], result['proposal'], result['innovation'])
        return result


def validate_proposal(prior, proposal, innovation):
    import numpy as np
    if prior.dtype != np.float32 or proposal.dtype != np.float32 or innovation.dtype != np.float32:
        raise ValueError('Proposal validation requires original float32 arrays')
    if not np.array_equal(prior + innovation, proposal):
        raise ValueError('Captured proposal is not the unclamped prior + INOV anchor')


def decomposition(prior, proposal, posterior):
    import numpy as np
    if not (prior.dtype == proposal.dtype == posterior.dtype == np.float32):
        raise ValueError('State diagnostics must retain original float32')
    if not (prior.shape == proposal.shape == posterior.shape) or prior.ndim != 2 or prior.shape[1] != 5:
        raise ValueError('Expected aligned [hour, five states] arrays')
    if not all(np.isfinite(a).all() for a in (prior, proposal, posterior)):
        raise ValueError('Nonfinite captured state')
    residual = (posterior - prior) - ((proposal - prior) + (posterior - proposal))
    bound = 8 * np.finfo(np.float32).eps * (1 + np.maximum.reduce([np.abs(prior), np.abs(proposal), np.abs(posterior)]))
    violations = (np.abs(residual) > bound).sum(axis=0)
    if np.any(violations):
        raise ValueError('State decomposition exceeds fixed elementwise bound')
    return dict(max_absolute_residual=np.abs(residual).max(axis=0).tolist(),
                max_bound=bound.max(axis=0).tolist(), min_bound=bound.min(axis=0).tolist(),
                violations=violations.tolist(), checked_elements=list(prior.shape),
                bound='8 * eps_float32 * (1 + maxabs(prior,proposal,posterior))')


def state_summary(raw, state_contract, bounds):
    import numpy as np
    identity = decomposition(raw['prior'], raw['proposal'], raw['posterior'])
    observation = raw['observation']
    thresholds = state_contract['thresholds']
    masks = dict(all=np.ones(len(observation), dtype=bool), low=observation <= thresholds['q25'],
                 mid=(observation > thresholds['q25']) & (observation <= thresholds['q75']), high=observation > thresholds['q75'])
    scales = np.asarray(state_contract['scales'], dtype=np.float64)
    deltas = {'final_update': raw['posterior'].astype(np.float64) - raw['prior'],
              'network_proposal': raw['proposal'].astype(np.float64) - raw['prior'],
              'posterior_clamp': raw['posterior'].astype(np.float64) - raw['proposal'],
              'physical_terminal_clamp': raw['physical_after'].astype(np.float64) - raw['physical_before']}
    def distribution(values):
        return dict(q25=np.quantile(values, .25, axis=0).tolist(), median=np.median(values, axis=0).tolist(),
                    q75=np.quantile(values, .75, axis=0).tolist(), median_absolute=np.median(np.abs(values), axis=0).tolist(),
                    positive=(values > 0).sum(axis=0).tolist(), negative=(values < 0).sum(axis=0).tolist(),
                    zero=(values == 0).sum(axis=0).tolist())
    lower = np.asarray([bounds[k][0] for k in ('dv','dg','hq','hs','q')], dtype=np.float32)
    upper = np.asarray([bounds[k][1] for k in ('dv','dg','hq','hs','q')], dtype=np.float32)
    groups = {}
    for name, mask in masks.items():
        if int(mask.sum()) != state_contract['counts'][name]:
            raise ValueError('Frozen current-hour state group count mismatch: ' + name)
        groups[name] = dict(count=int(mask.sum()),
                           deltas={key: dict(native=distribution(values[mask]), fixed_training_iqr=distribution(values[mask] / scales)) for key, values in deltas.items()},
                           posterior_at_lower=(raw['posterior'][mask] == lower).sum(axis=0).tolist(),
                           posterior_at_upper=(raw['posterior'][mask] == upper).sum(axis=0).tolist(),
                           proposal_below_lower=(raw['proposal'][mask] < lower).sum(axis=0).tolist(),
                           proposal_above_upper=(raw['proposal'][mask] > upper).sum(axis=0).tolist(),
                           physical_changed=(raw['physical_after'][mask] != raw['physical_before'][mask]).sum(axis=0).tolist())
    return dict(identity=identity, states=state_contract['names'], fixed_training_iqr=scales.tolist(),
                physical_units=['mm','mm','mm','mm','mm/hour'], groups=groups,
                limitation='Internal states have no truth labels; behavior and boundary hits do not identify physical truth.')
