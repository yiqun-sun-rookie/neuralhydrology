"""Frozen conventional comparators. Import performs no data/model access."""
import ast
import copy
import hashlib
import importlib
import importlib.abc
import importlib.util
import os
from pathlib import Path
import sys
from types import SimpleNamespace
import uuid

import neural_runtime as rt

ARCHIVE = Path('C:/Users/yiqun/.codex/worktrees/c7a4/kalmannet/artifacts/comment_112_signed_state_20260916/source_snapshot/test_comparison_20260915')
REFRESH = ARCHIVE/'linked_diagnostics_003'
OLD_PREFIX = 'C:/Users/yiqun/.codex/worktrees/570e/kalmannet/test_comparison_20260915/linked_diagnostics_003/source/'
PAPER = rt.SOURCE/'draft/scripts/generate_paper_metrics.py'
SELECTION = rt.REPO/'artifacts/regge_adaptive_covariance_ukf_v1_validation/selection.json'
ADAPT_CONFIG = rt.SOURCE/'experiments/optimize_hyper_parameters/adaptive_covariance_ukf_config.yaml'
SELECTION_SHA = 'f4dbca35ee4adc2487a506d6b95d93e18646e50f0a7a4d2881a652b5ae9da0a8'
ADAPT_SHA = '998fa6082b5edba3d88321152af11f8dc6289f4ab56ccca82ac37a2ef204c969'
METHODS = ('learned_noise','hand_tuned','adaptive','open_loop')
VARIANTS = ('original_outlet_original_states','corrected_outlet_original_states','corrected_outlet_corrected_states')
_SEALED = None
_ARCHIVE_MAP = None
SHARED_SOURCE_NAMES = ('prepare.py','initializer.py','core.py','system_model.py',
                       'dataset.py','params.py','walrus_corrected.py')
FORMAL_MANIFEST_SHA = '4bd8fe167bb5d6932a25161e9855bfdf03f656352b567aeee903e31925b6899f'


def verify_shared_sources():
    """Bind every actually loaded shared computation module to the frozen manifest."""
    path=rt.FORMAL/'manifest.json'
    bindings={str(path):rt.verify(path,FORMAL_MANIFEST_SHA)}
    manifest=rt.read_json(path)
    for name in SHARED_SOURCE_NAMES:
        relative='sources/'+name
        if relative not in manifest['files']: raise ValueError('Shared source absent from frozen manifest: '+relative)
        source=rt.FORMAL/relative
        bindings[str(source)]=rt.verify(source,manifest['files'][relative])
    return bindings


def require_shared_bindings(bindings):
    """Reject old/incomplete acceptance receipts as well as changed actual files."""
    current=verify_shared_sources()
    for path,digest in current.items():
        if bindings.get(path)!=digest: raise ValueError('Accepted shared computation binding missing/changed: '+path)
    return True


def case_registry():
    registry = rt.read_json(rt.MAIN/'input_registry.json')
    result=[]
    for method in METHODS:
        for variant in VARIANTS:
            row=dict(case_id=method+'__'+variant,method=method,variant=variant,
                     batch_size=256 if method in METHODS[:2] else 128,seed=42,
                     reference_statistics='archived' if method in METHODS[:2] else 'missing; new reconstruction required')
            if method=='learned_noise':
                r=registry['noise']
                row.update(checkpoint=r['path'],checkpoint_sha256=r['sha256'],config=r['config'],config_sha256=r['config_sha256'])
            if method=='adaptive':
                row.update(config=str(ADAPT_CONFIG),config_sha256=ADAPT_SHA,selection=str(SELECTION),selection_sha256=SELECTION_SHA,stationarity_scale=100.0)
            result.append(row)
    return result


def verify_sources():
    """Never touches tensors, including historical sufficient statistics."""
    import prepare_test_states as prep
    bindings=prep.verify_sources()['fingerprints']
    bindings.update(verify_shared_sources())
    records=rt.read_json(rt.MAIN/'source_manifest.json')
    for row in records:
        path=Path(row['path'])
        bindings[str(path)]=rt.verify(path,row['sha256'])
    archived=rt.read_json(REFRESH/'source_manifest.json')
    relocations=[]; unavailable=[]
    # The original source tree has been partially pruned; use only digest-equal
    # equivalents from the registered primary snapshot, never current source.
    for row in archived:
        old=row['snapshot'].replace('\\','/')
        if not old.startswith(OLD_PREFIX): raise ValueError('Unexpected archived prefix: '+old)
        rel=old[len(OLD_PREFIX):]
        primary=rt.MAIN/'source'/rel
        relocated=REFRESH/'source'/rel
        candidates=(primary,relocated,Path(row['original']))
        candidate=next((p for p in candidates if p.is_file() and rt.sha(p)==row['sha256']),None)
        if candidate is not None:
            bindings[str(candidate)]=row['sha256']
            relocations.append(dict(original=old,relative=rel,actual=str(candidate),sha256=row['sha256']))
        else: unavailable.append(dict(original=old,relative=rel,sha256=row['sha256']))
        # Unused files may be absent; missing imports still fail the sealed finder.
    required=[PAPER,rt.SOURCE/'experiments/optimize_hyper_parameters/train_and_eval.py',
              rt.SOURCE/'experiments/optimize_hyper_parameters/select_adaptive_covariance_ukf.py',
              rt.SOURCE/'src/shared/adaptive_covariance_ukf.py',ADAPT_CONFIG]
    matches={r['relative'] for r in relocations}
    if any(str(p.relative_to(rt.MAIN/'source')).replace('\\','/') not in matches for p in required): raise ValueError('Required archive source not digest-matched')
    for path in (REFRESH/'source_manifest.json',REFRESH/'refresh_diagnostics.py',rt.MAIN/'source_manifest.json',
                 rt.MAIN/'input_registry.json',rt.MAIN/'evaluate_existing_models_final.py',rt.RULES,
                 rt.MAIN/'comparator_reuse_registry.json',rt.MAIN/'run_003/learned_noise/metrics.json',
                 rt.MAIN/'run_003/hand_tuned/metrics.json',ARCHIVE/'delivery_001/paper_values.json'):
        bindings[str(path)]=rt.sha(path)
    bindings[str(SELECTION)]=rt.verify(SELECTION,SELECTION_SHA)
    bindings[str(ADAPT_CONFIG)]=rt.verify(ADAPT_CONFIG,ADAPT_SHA)
    for case in case_registry():
        if 'config' in case: bindings[case['config']]=rt.verify(case['config'],case['config_sha256'])
    # Shared adapters are accepted only after their complete computational syntax
    # is checked against both historical source trees, apart from exposed hydro.
    def function(path,name):
        return next(n for n in ast.parse(path.read_text(encoding='utf-8-sig')).body if isinstance(n,ast.FunctionDef) and n.name==name)
    for family in ('primary','refresh'):
        byrel={r['relative']:Path(r['actual']) for r in relocations}
        base=rt.SOURCE
        initpath=base/'knet/utils/model_initialization_use_script_mdl_1.py' if family=='primary' else byrel['kalmannet/knet/utils/model_initialization_use_script_mdl_1.py']
        a=function(initpath,'initialize_system_model'); b=function(rt.FORMAL/'sources/initializer.py','initialize_system_model')
        b.body[-1].value=b.body[-1].value.elts[0]
        if ast.dump(a)!=ast.dump(b): raise ValueError('Historical initializer differs: '+family)
        preparepath=base/'knet/modules/pipeline/utils.py' if family=='primary' else byrel['kalmannet/knet/modules/pipeline/utils.py']
        if ast.dump(function(preparepath,'prepare_batch_data'))!=ast.dump(function(rt.FORMAL/'sources/prepare.py','prepare_batch_data')):
            raise ValueError('Historical batch preparation differs: '+family)
        for local,old in [('core.py','knet/modules/pipeline/core_fun.py'),('system_model.py','knet/modules/pipeline/system_model.py'),('params.py','hydrologic/params.py')]:
            historic=base/old if family=='primary' else byrel['kalmannet/'+old]
            if ast.dump(ast.parse(historic.read_text(encoding='utf-8-sig')))!=ast.dump(ast.parse((rt.FORMAL/'sources'/local).read_text(encoding='utf-8'))):
                raise ValueError('Shared computation differs: '+family+' '+local)
    return bindings,dict(archive_equivalents_matched=True,exact_prefix=OLD_PREFIX,relocations=relocations,unavailable_unused_sources=unavailable,
                         shared_initialization_only_return_exposure=True,shared_core_system_params_exact_ast=True,
                         shared_prepare_exact_ast_both_archives=True,shared_manifest_sha256=FORMAL_MANIFEST_SHA,
                         original_missing_statistics=['adaptive','open_loop'])


def archive_source(relative):
    global _ARCHIVE_MAP
    if _ARCHIVE_MAP is None:
        _,proof=verify_sources()
        _ARCHIVE_MAP={r['relative']:Path(r['actual']) for r in proof['relocations']}
    if relative not in _ARCHIVE_MAP: raise FileNotFoundError('Unmatched archived source: '+relative)
    return _ARCHIVE_MAP[relative]


class SealedFinder(importlib.abc.MetaPathFinder):
    def __init__(self,records,overrides): self.records,self.overrides=records,overrides
    def find_spec(self,fullname,path=None,target=None):
        first=fullname.split('.')[0]
        if first not in ('filters','src'): return None
        root=rt.MAIN/'source/filters' if first=='filters' else rt.SOURCE
        stem=root.joinpath(*fullname.split('.'))
        file=stem/'__init__.py' if stem.is_dir() else stem.with_suffix('.py')
        if not file.is_file():
            if stem.is_dir():
                spec=importlib.machinery.ModuleSpec(fullname,None,is_package=True)
                spec.submodule_search_locations=[str(stem)]
                return spec
            raise ImportError('Frozen module missing: '+fullname)
        file=self.overrides.get(str(file.resolve()),file)
        expected=self.records.get(str(file.resolve()))
        if expected is None: raise ImportError('Unsealed module: '+str(file))
        rt.verify(file,expected)
        rt.IMPORT_LEDGER.append(dict(module=fullname,path=str(file),sha256=expected))
        return importlib.util.spec_from_file_location(fullname,file,submodule_search_locations=[str(stem)] if stem.is_dir() else None)


def seal_imports(method='learned_noise'):
    global _SEALED
    if _SEALED is None:
        records={str(Path(r['path']).resolve()):r['sha256'] for r in rt.read_json(rt.MAIN/'source_manifest.json')}
        if any(k=='filters' or k.startswith('filters.') or k=='src' or k.startswith('src.') for k in sys.modules):
            raise RuntimeError('Comparator process requires clean project import namespace')
        overrides={}
        if method in ('adaptive','open_loop'):
            _,proof=verify_sources()
            for r in proof['relocations']:
                requested=(rt.MAIN/'source'/r['relative']).resolve()
                actual=Path(r['actual']).resolve()
                overrides[str(requested)]=actual
                records[str(actual)]=r['sha256']
        _SEALED=SealedFinder(records,overrides)
        sys.meta_path.insert(0,_SEALED)


def extract(path,names,namespace):
    tree=ast.parse(Path(path).read_text(encoding='utf-8-sig'))
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
    if {n.name for n in nodes}!=set(names): raise ValueError('Missing exact archived function/class')
    body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)]+nodes
    exec(compile(ast.fix_missing_locations(ast.Module(body=body,type_ignores=[])),str(path),'exec'),namespace)
    rt.IMPORT_LEDGER.append(dict(module='exact_ast:'+','.join(names),path=str(path),sha256=rt.sha(path)))
    return namespace


def builders(method='learned_noise'):
    import torch
    ns=dict(torch=torch,os=os,SimpleNamespace=SimpleNamespace,math=__import__('math'),qprint=lambda *a,**k:None,dprint=lambda *a,**k:None)
    names=('_to_tensor','_normalize_clamp_dict','build_args','_as_diag_tensor','build_trainable_kf')
    path=rt.SOURCE/'experiments/optimize_hyper_parameters/train_and_eval.py' if method=='learned_noise' else archive_source('kalmannet/experiments/optimize_hyper_parameters/train_and_eval.py')
    return SimpleNamespace(**extract(path,names,ns))


def adaptive_builder():
    import torch
    from typing import Mapping
    ns=dict(torch=torch,nn=torch.nn,importlib=importlib,Mapping=Mapping,CORE_MODULE='src.shared.adaptive_covariance_ukf',
            REQUIRED_CORE_API=dict(config_class='AdaptiveNoiseConfig',filter_class='InnovationCorrelationAdaptiveUKF',filter_methods=['reset','step','diagnostics']))
    names=('validate_core_api','load_core_api','_as_diagonal','ReggeAdaptiveCovarianceAdapter','_adaptive_config_kwargs','build_regge_adaptive_model')
    return extract(archive_source('kalmannet/experiments/optimize_hyper_parameters/select_adaptive_covariance_ukf.py'),names,ns)['build_regge_adaptive_model']


def physical_source(case,output,mode):
    """mode plain, counters, or capture. Plain corrected removes counters only."""
    from diagnostic_capture import instrument_source
    path=rt.PROBE/'sources/walrus.py' if mode=='plain' else rt.PROBE/'sources/walrus_observed.py'
    if not case['variant'].startswith('original_outlet'):
        if mode=='plain':
            text=path.read_text(encoding='utf-8').replace('        overflow = hs > cd + 1.0','        overflow = hs > cd')
        else:
            path=rt.FORMAL/'sources/walrus_corrected.py'
            text=path.read_text(encoding='utf-8')
    else: text=path.read_text(encoding='utf-8')
    proof={}
    if mode=='capture': text,proof=instrument_source(text,'physics')
    dest=output/('physical_'+mode+'_'+uuid.uuid4().hex+'.py')
    with dest.open('x',encoding='utf-8') as f: f.write(text)
    return dest,proof


def build_model(case,output,mode='capture',device='cuda'):
    import torch
    import yaml
    seal_imports(case['method'])
    path,proof=physical_source(case,output,mode)
    hydro_module=rt.load_module(path,'probe_walrus_observed')
    rt.load_module(rt.FORMAL/'sources/system_model.py','probe_system_model')
    rt.load_module(rt.FORMAL/'sources/params.py','probe_params')
    initial=rt.load_module(rt.FORMAL/'sources/initializer.py')
    if case['method']=='open_loop':
        constants={}
        paper_path=archive_source('kalmannet/draft/scripts/generate_paper_metrics.py')
        tree=ast.parse(paper_path.read_text(encoding='utf-8'))
        for n in tree.body:
            if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('INITIAL_STATE','WALRUS_PARAMS') for t in n.targets):
                exec(compile(ast.Module(body=[n],type_ignores=[]),str(paper_path),'exec'),constants)
        hydro=hydro_module.WalrusBatch(**constants['WALRUS_PARAMS'],initial_state=torch.tensor(constants['INITIAL_STATE'],dtype=torch.float32,device=device),device=device)
        hydro.eval()
        system=hydro
        model=None
        args=None
        effective=dict(physics_execution='eager',parameters=constants['WALRUS_PARAMS'],historical_order='h(x_current) then f(x_current,forcing[t])')
    else:
        system,hydro=initial.initialize_system_model(800,800,device=device)
        effective=dict(physics_execution='torch.jit.script as archived')
        model=None; args=None
        if case['method'] in ('learned_noise','adaptive'):
            rt.verify(case['config'],case['config_sha256'])
            cfg=yaml.safe_load(Path(case['config']).read_text(encoding='utf-8'))
            cfg['training']['forecast_lead_time']=48
            # Archived evaluator changed actual loader batches, not builder n_batch.
            build=builders(case['method'])
            args=build.build_args(cfg,torch.zeros(800),torch.zeros(800))
            args.device=device
            if case['method']=='learned_noise':
                model=build.build_trainable_kf(cfg,system,args).to(device)
                checkpoint=rt.load_tensor(case['checkpoint'],case['checkpoint_sha256'],'fixed_learned_noise_checkpoint')
                sd=checkpoint.get('model_state_dict',checkpoint)
                model.load_state_dict(sd,strict=True)
                effective.update(checkpoint_keys=list(checkpoint),learned_covariance={k:v.detach().cpu().tolist() for k,v in sd.items()},
                                 Q=model.Q.detach().cpu().tolist(),R=model.R.detach().cpu().tolist(),
                                 Q_effective=model._stabilize_cov(model.Q,5).detach().cpu().tolist(),R_effective=model._stabilize_cov(model.R,1).detach().cpu().tolist(),
                                 noise_transform='exact archived LearnableCov exp(raw), symmetrization plus cov_jitter')
            else:
                rt.verify(SELECTION,SELECTION_SHA)
                model=adaptive_builder()(cfg,system,args,100.0).to(device)
                effective.update(stationarity_scale=100.0,adaptive_config=cfg['adaptive_covariance'])
            model.eval()
            for p in model.parameters(): p.requires_grad_(False)
            effective.update(config=cfg,builder_batch_size=args.n_batch)
        else:
            effective.update(sigma=dict(alpha=.6874,beta=2.,kappa=-2.),initial_covariance='diag(0.1 * state0)',Q=[.14,1.,.004,1.2,0.],R=[1.5e-5])
    effective.update(batch_size=case['batch_size'],method=case['method'],variant=case['variant'],instrumentation=proof)
    return SimpleNamespace(case=case,system=system,hydro=hydro,model=model,args=args,core=rt.load_core(),mode=mode,device=device,effective=effective)


def manual_adapter_source(method):
    """Extract exact historical batch statements; add only output/capture hooks."""
    paper_path=PAPER if method=='hand_tuned' else archive_source('kalmannet/draft/scripts/generate_paper_metrics.py')
    tree=ast.parse(paper_path.read_text(encoding='utf-8'))
    name='eval_handtuned' if method=='hand_tuned' else 'eval_openloop'
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
    loop=next(n for n in ast.walk(fn) if isinstance(n,ast.For) and isinstance(n.target,ast.Tuple) and ast.unparse(n.target)=='(bi, batch)')
    body=[]
    for n in loop.body:
        if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='acc.update': break
        body.append(copy.deepcopy(n))
    original=copy.deepcopy(body)
    # In hand-tuned routine the factory is observed, without replacing arithmetic.
    # Open loop additionally exposes its emitted states and all propagation ends.
    if method=='open_loop':
        body.insert(0,ast.parse('emitted_states = []').body[0])
        for index,n in enumerate(body):
            if isinstance(n,ast.For) and ast.unparse(n.target)=='t':
                n.body.insert(0,ast.parse('emitted_states.append(x_current.detach().clone())').body[0])
                n.body.insert(0,ast.parse('if recorder is not None: recorder.emit(x_current)').body[0])
                n.body.append(ast.parse('if recorder is not None: recorder.physical(walrus)').body[0])
    # Prove original retained computation by removing exactly the additions.
    restored=copy.deepcopy(body)
    if method=='open_loop':
        restored=restored[1:]
        for n in restored:
            if isinstance(n,ast.For) and ast.unparse(n.target)=='t':
                n.body=n.body[2:-1]
    if ast.dump(ast.Module(body=restored,type_ignores=[]))!=ast.dump(ast.Module(body=original,type_ignores=[])):
        raise ValueError('Manual adapter computation changed')
    if method=='hand_tuned':
        ret='return dict(updated=states_upd, outputs=outputs_upd, forecast_states=states_fc_flat, predictions=outputs_fc_flat, observation=y_obs, hours=tm_hours)'
    else:
        ret='return dict(updated=torch.stack(emitted_states,dim=2), outputs=outputs_ol_3d, forecast_states=None, predictions=fc_flat, observation=y_obs, hours=tm_hours)'
    body+=ast.parse(ret).body
    wrapper=ast.parse('def execute(batch, device, sys_model, walrus, recorder):\n pass').body[0]
    wrapper.body=body
    source=ast.unparse(ast.fix_missing_locations(ast.Module(body=[wrapper],type_ignores=[])))+'\n'
    return source,dict(retained_computation_exact_ast=True,source=str(paper_path),source_sha256=rt.sha(paper_path),function=name)


class Capture:
    def __init__(self):
        self.values={k:[] for k in ('prior','posterior','physical_before','physical_after','emitted')}
        self.physical_enabled=True
    def emit(self,x): self.values['emitted'].append(x.detach().clone())
    def physical(self,hydro):
        if not self.physical_enabled: return
        self.values['physical_before'].append(hydro.capture_before.detach().clone())
        self.values['physical_after'].append(hydro.capture_after.detach().clone())
    def wrap_filter(self,flt):
        predict,update=flt.predict,flt.update
        def observed_predict(*a,**kw):
            result=predict(*a,**kw)
            self.values['prior'].append(flt.x.detach().clone())
            return result
        def observed_update(*a,**kw):
            result=update(*a,**kw)
            self.values['posterior'].append(flt.x.detach().clone())
            return result
        flt.predict,flt.update=observed_predict,observed_update
        return predict,update
    def tensors(self):
        import torch
        return {k:torch.stack(v,dim=1) for k,v in self.values.items() if v}


def run_manual(method,hydro,system,batch,device,recorder,output=None):
    import torch
    core=rt.load_core()
    def forecast(*a,**kw):
        if recorder is not None: recorder.physical_enabled=False
        return core.system_model_forecast(*a,**kw)
    ns=dict(torch=torch,prepare_batch_data=rt.load_module(rt.FORMAL/'sources/prepare.py').prepare_batch_data,
            system_model_forecast=forecast,rearrange_data_unfold=core.rearrange_data_unfold,lead_time=48)
    if method=='hand_tuned':
        seal_imports()
        from filters.filter.non_batch.kalman import MerweScaledSigmaPoints
        from filters.filter.batch.my_version.batch_unscentedkalmanfilter_gpu import BatchUnscentedKalmanFilterGPU
        from filters.da_coupler.walrus_batch import fx_walrus_batch,hx_walrus_batch
        def factory(*a,**kw):
            flt=BatchUnscentedKalmanFilterGPU(*a,**kw)
            if recorder is not None: recorder.wrap_filter(flt)
            return flt
        ns.update(MerweScaledSigmaPoints=MerweScaledSigmaPoints,BatchUnscentedKalmanFilterGPU=factory,
                  fx_walrus_batch=fx_walrus_batch,hx_walrus_batch=hx_walrus_batch,HANDTUNED_Q=[.14,1.,.004,1.2,0.],HANDTUNED_R=[1.5e-5])
    source,proof=manual_adapter_source(method)
    exec(compile(source,str(PAPER)+'#exact_batch','exec'),ns)
    return ns['execute'](batch,device,system,hydro,recorder)


def expected_counters(method,batch_size,hours,forecast):
    sigma=1 if method=='open_loop' else 11
    extra=0 if method=='open_loop' or not forecast else 47
    return dict(audit_q_calls=hours+extra,audit_q_elements=batch_size*hours*sigma+extra*batch_size*(hours-47))


def finite(values):
    import torch
    for key,v in values.items():
        if torch.is_tensor(v) and (v.dtype!=torch.float32 or not torch.isfinite(v).all()):
            raise ValueError('Nonfinite/non-float32 comparator trajectory: '+key)


def infer(runtime,batch,logging=False,forecast=True):
    import torch
    case=runtime.case
    capture=Capture() if logging else None
    hydro=runtime.hydro
    if runtime.mode=='capture': hydro.capture_enabled=logging
    if runtime.mode!='plain': rt.reset_counters(hydro)
    original_f=runtime.system.f
    if logging and case['method']!='open_loop':
        def observed_f(x,u):
            result=original_f(x,u)
            capture.physical(hydro)
            return result
        runtime.system.f=observed_f
    old_filter=None; flt=None
    try:
        if case['method'] in ('hand_tuned','open_loop'):
            result=run_manual(case['method'],hydro,runtime.system,batch,runtime.device,capture)
        else:
            p,ep,obs,states,hours=rt.load_module(rt.FORMAL/'sources/prepare.py').prepare_batch_data(batch,runtime.device)
            model=runtime.model
            model.batch_size=obs.shape[0]; model.update_mode=True
            model.init_hidden_KNet(); model.init_sequence(states[:,:,0],obs.shape[-1])
            flt=model.core if case['method']=='learned_noise' else model.base_filter
            if logging: old_filter=capture.wrap_filter(flt)
            updated,outputs=runtime.core.forward_sequence(SimpleNamespace(knet_model=model,sys_model=runtime.system,args=runtime.args),obs,torch.cat((p,ep),dim=1))
            assimilation=rt.counter_snapshot(hydro) if runtime.mode!='plain' else None
            # Physical capture is for assimilation sigma paths; forecast counters
            # still cover every propagation, without retaining huge sigma arrays.
            if logging: runtime.system.f=original_f
            forecasts,predictions=runtime.core.system_model_forecast(runtime.system,p,ep,updated,48) if forecast else (None,None)
            result=dict(updated=updated,outputs=outputs,forecast_states=forecasts,predictions=predictions,observation=obs,hours=hours,assimilation_counters=assimilation)
    finally:
        if case['method']!='open_loop': runtime.system.f=original_f
        if old_filter is not None: flt.predict,flt.update=old_filter
    if runtime.mode!='plain':
        result['counters']=rt.counter_snapshot(hydro)
        rt.check_counters(result['counters'],expected_counters(case['method'],batch['qobs'].shape[0],batch['qobs'].shape[-1],forecast))
    result['capture']=capture.tensors() if capture else {}
    finite(result); finite(result['capture'])
    return result


def model_snapshot(runtime):
    import evaluate_neural as ev
    if runtime.model is None: return {}
    return ev.weights_snapshot(runtime.model)


def verify_model(runtime,before):
    import evaluate_neural as ev
    if runtime.model is not None:
        after=runtime.model.state_dict()
        if set(after)!=set(before): raise ValueError('Frozen model keys changed')
        for key in before:
            if not ev.compare_tensor_bits(before[key],after[key])['bitwise_equal']:
                raise ValueError('Frozen model tensor changed: '+key)


def setup_runtime(output,case):
    env=rt.setup_runtime(output)
    env['batch_size']=case['batch_size']
    env['reference_differences']['batch_size']=dict(reference=256,actual=case['batch_size']) if case['batch_size']!=256 else {}
    return env
