"""Frozen neural inference bindings; import has no filesystem or tensor side effects."""
import ast
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import pickle
import platform
import sys
import types
import uuid

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
FORMAL = ROOT.parent / 'wrr-hamid-weights-20260923-v1/formal_package_v3'
PROBE = FORMAL.parent / 'probe_package_v2'
MAIN = REPO / 'artifacts/wrr_selected_model_results_20260920_v1'
COMPACT = REPO / 'artifacts/wrr_capacity_comparison_20260921_v1'
SOURCE = MAIN / 'source/kalmannet'
RULES = ROOT.parent / 'wrr-hamid-evaluation-readiness-20260927-v1/readiness_evidence.json'
COUNTERS = ('audit_q_calls', 'audit_q_elements', 'audit_gap_hits')
IMPORT_LEDGER = []
LOAD_LEDGER = []
NUMERICAL_ENVIRONMENT_FIELDS = (
    'python','executable','torch','numpy','cuda','cudnn','device','dtype',
    'batch_size','seed','cudnn_benchmark','amp','compilation','matmul_precision',
    'cudnn_enabled','cudnn_deterministic','deterministic_algorithms',
    'cuda_matmul_allow_tf32','cudnn_allow_tf32','autocast_enabled','grad_enabled',
)


def require_same_environment(actual, accepted):
    """Pure metadata gate; never loads/hashes inputs or invokes a model."""
    missing = [name for name in NUMERICAL_ENVIRONMENT_FIELDS if name not in actual or name not in accepted]
    if missing:
        raise ValueError('Accepted preflight numerical environment missing fields: ' + ', '.join(missing))
    differences = {name:{'accepted':accepted[name],'actual':actual[name]}
                   for name in NUMERICAL_ENVIRONMENT_FIELDS
                   if type(actual[name]) is not type(accepted[name]) or actual[name] != accepted[name]}
    if differences:
        raise ValueError('Accepted preflight numerical environment mismatch: ' + json.dumps(differences,sort_keys=True))
    return True


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def verify(path, expected):
    actual = sha(path)
    if actual != expected:
        raise ValueError(f'Input hash mismatch: {path}: {actual} != {expected}')
    return actual


def write_json(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write('\n')


def claim_output(path):
    path = Path(path).resolve()
    if path == ROOT or not path.is_relative_to(ROOT):
        raise ValueError('Output must be an exclusive child of the task root')
    path.mkdir(exist_ok=False)
    return path


def require_acceptance(path, state):
    receipt = read_json(path)
    if receipt.get('state') != state or receipt.get('open_critical_important_findings', 0) != 0:
        raise ValueError(f'Required accepted gate absent: {path}')
    return receipt


def retrieval_gate():
    accepted = require_acceptance(ROOT / 'retrieval_acceptance.json', 'RETRIEVAL_ACCEPTED_FOR_REVIEWED_EVALUATION_PREFLIGHT')
    verification = ROOT / 'retrieval_001/verification.json'
    verify(verification, accepted['verification_sha256'])
    evidence = read_json(verification)
    if evidence['state'] != 'RETRIEVAL_AND_JSON_EVIDENCE_VERIFIED_PENDING_INDEPENDENT_REVIEW':
        raise ValueError('Unknown retrieval verification schema/state')
    return evidence


def case_registry():
    contract = read_json(RULES)['evaluation_contract']
    cases = []
    variants = contract['experiment_families']['historical_sensitivity']['variants']
    for family, folder, count, run in [('main', MAIN, 185448, 'run_003'), ('compact', COMPACT, 18841, 'run_001')]:
        registry = read_json(folder / 'input_registry.json')
        for seed in (42, 43, 44):
            record = registry['seeds'][str(seed)]
            for variant in variants:
                cases.append(dict(case_id=f'{family}_seed{seed}__{variant}', family=family, seed=seed,
                                  variant=variant, checkpoint=record['checkpoint'], checkpoint_sha256=record['sha256'],
                                  config=record['config'], config_sha256=record['config_sha256'],
                                  epoch=record['best_epoch_one_based'] - 1, parameters=count,
                                  reference=str(folder / run / f'neural_seed{seed}'),
                                  registry=str(folder / 'input_registry.json')))
    verified = retrieval_gate()
    by_id = {r['exp_id']: r for r in verified['completed_models']}
    required = contract['experiment_families']['corrected_weight_comparison']
    if set(by_id) != set(required['completed_model_ids']) or set(by_id) & set(required['failed_model_ids']):
        raise ValueError('Completed-only fixed model set mismatch')
    for identifier in required['completed_model_ids']:
        record = by_id[identifier]
        cases.append(dict(case_id=identifier, family='new', seed=record['seed'],
                          variant='corrected_outlet_corrected_states', checkpoint=record['checkpoint_local_path'],
                          checkpoint_sha256=record['checkpoint_sha256'], config=record['config_path'],
                          config_sha256=record['config_sha256'], epoch=record['best_epoch_zero_based'],
                          parameters=185448, initial_weight_tensor_sha256=record['initial_weight_tensor_sha256'],
                          common_validation_mse=record['best_validation_mse'],
                          protocol_sha256=record['started']['protocol_sha256']))
    if len(cases) != 28 or len({r['case_id'] for r in cases}) != 28:
        raise ValueError('Expected exactly 28 unique neural cases')
    return cases


def verify_sources():
    import prepare_test_states as preparer
    bindings = preparer.verify_sources()['fingerprints']
    for path in (RULES, ROOT/'retrieval_acceptance.json', ROOT/'retrieval_001/verification.json'):
        bindings[str(path)] = sha(path)
    manifest = read_json(FORMAL / 'manifest.json')
    for name in ('network', 'system_model', 'params', 'core', 'prepare', 'dataset', 'initializer', 'builders', 'walrus_corrected'):
        path = FORMAL / f'sources/{name}.py'
        bindings[str(path)] = verify(path, manifest['files'][f'sources/{name}.py'])
    protocol = read_json(FORMAL / 'protocol.json')
    for name, item in protocol['source_manifest'].items():
        bindings[item['path']] = verify(item['path'], item['sha256'])
    # Verify every reused archived source against the registered source manifest.
    source_records = {str(Path(r['path']).resolve()): r['sha256'] for r in read_json(MAIN / 'source_manifest.json')}
    for path in [MAIN / 'source/protocol/statistics_core.py', SOURCE / 'draft/scripts/analyze_state_updates.py']:
        bindings[str(path)] = verify(path, source_records[str(path.resolve())])
    for folder in (MAIN, COMPACT):
        for name in ('input_registry.json', 'source_manifest.json', 'retrieval_verification.json', 'protocol.json'):
            path = folder / name
            bindings[str(path)] = sha(path)
    def tree(path):
        return ast.parse(Path(path).read_text(encoding='utf-8-sig'))
    def functions(path):
        return {n.name: n for n in tree(path).body if isinstance(n, ast.FunctionDef)}
    builders = functions(FORMAL / 'sources/builders.py')
    old_builders = functions(protocol['source_manifest']['builder_reference.py']['path'])
    for name, node in builders.items():
        if ast.dump(node) != ast.dump(old_builders[name]):
            raise ValueError('Archived builder computation mismatch: ' + name)
    old_init = functions(protocol['source_manifest']['initializer_reference.py']['path'])['initialize_system_model']
    new_init = functions(FORMAL / 'sources/initializer.py')['initialize_system_model']
    if not isinstance(new_init.body[-1].value, ast.Tuple):
        raise ValueError('Initializer return changed')
    new_init.body[-1].value = new_init.body[-1].value.elts[0]
    if ast.dump(new_init) != ast.dump(old_init):
        raise ValueError('Initializer computation mismatch beyond exposed scripted model')
    for name in ('network.py', 'system_model.py', 'params.py', 'core.py', 'dataset.py'):
        if ast.dump(tree(FORMAL / 'sources' / name)) != ast.dump(tree(protocol['source_manifest'][name]['path'])):
            raise ValueError('Archived source computation mismatch: ' + name)
    old_prepare = functions(protocol['source_manifest']['utils_reference.py']['path'])['prepare_batch_data']
    new_prepare = functions(FORMAL / 'sources/prepare.py')['prepare_batch_data']
    if ast.dump(old_prepare) != ast.dump(new_prepare):
        raise ValueError('Batch preparation mismatch')
    return bindings, dict(builders_exact_ast=True, initializer_only_return_exposure=True,
                          unchanged_network_system_params_core_dataset=True, prepare_exact_ast=True)


def load_module(path, name=None):
    path = Path(path)
    name = name or ('_frozen_eval_' + uuid.uuid4().hex)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    previous = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = previous
    IMPORT_LEDGER.append(dict(module=name, path=str(path), sha256=sha(path)))
    return module


def frozen_statistics():
    return load_module(MAIN / 'source/protocol/statistics_core.py')


def load_core():
    return load_module(FORMAL / 'sources/core.py')


def load_slice_functions():
    from collections import defaultdict
    from torch.utils.data import default_collate
    path = SOURCE / 'draft/scripts/analyze_state_updates.py'
    source = ast.parse(path.read_text(encoding='utf-8-sig'))
    selected = [n for n in source.body if isinstance(n, ast.FunctionDef) and n.name in ('build_nonoverlapping_slices', '_iter_slice_batches')]
    if len(selected) != 2:
        raise ValueError('Missing archived diagnostic slice functions')
    namespace = {'defaultdict': defaultdict, 'default_collate': default_collate}
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), 'exec'), namespace)
    IMPORT_LEDGER.append(dict(module='exact_extracted_diagnostic_slices', path=str(path), sha256=sha(path)))
    return namespace['build_nonoverlapping_slices'], namespace['_iter_slice_batches']


def install_guard(output, tensor_paths):
    allowed = {Path(p).resolve() for p in tensor_paths}
    output = Path(output).resolve()
    def audit(event, args):
        if event != 'open' or not isinstance(args[0], (str, bytes, os.PathLike)):
            return
        path = Path(os.fsdecode(args[0])).resolve()
        if path == Path(os.devnull).resolve():
            return
        mode, flags = args[1:3]
        writing = isinstance(mode, str) and any(s in mode for s in 'wax+')
        writing = writing or isinstance(flags, int) and bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND))
        if writing and not path.is_relative_to(output):
            raise PermissionError('Write outside exclusive run: ' + str(path))
        if not writing and path.suffix.lower() in ('.pt', '.pth', '.npz') and path not in allowed and not path.is_relative_to(output):
            raise PermissionError('Unregistered tensor read/hash blocked: ' + str(path))
    sys.addaudithook(audit)


def setup_runtime(output):
    for name in ('TEMP', 'TMP', 'TORCH_HOME', 'TORCH_EXTENSIONS_DIR', 'MPLCONFIGDIR', 'XDG_CACHE_HOME', 'NUMBA_CACHE_DIR'):
        path = output / 'cache' / name
        path.mkdir(parents=True)
        os.environ[name] = str(path)
    sys.dont_write_bytecode = True
    for name in ('KF_DEBUG_CHECKS', 'FORECAST_START_LEAD', 'FORECAST_INCLUDE_CURRENT'):
        os.environ.pop(name, None)
    import torch
    import numpy as np
    if (platform.python_version(), torch.__version__, np.__version__) != ('3.11.13', '2.4.0', '2.3.2'):
        raise ValueError('Use frozen knet_clean Python/PyTorch/NumPy runtime')
    if not torch.cuda.is_available() or torch.get_default_dtype() != torch.float32:
        raise ValueError('CUDA and default float32 required')
    torch.manual_seed(42)
    torch.backends.cudnn.benchmark = False
    torch.set_grad_enabled(False)
    torch.cuda.reset_peak_memory_stats()
    def forbidden(*args, **kwargs):
        raise RuntimeError('Training, optimizer construction/steps and backward are forbidden')
    torch.Tensor.backward = forbidden
    torch.autograd.backward = forbidden
    torch.optim.Optimizer.__init__ = forbidden
    for cls in vars(torch.optim).values():
        if isinstance(cls, type) and issubclass(cls, torch.optim.Optimizer):
            cls.step = forbidden
    actual = dict(python=platform.python_version(), executable=sys.executable, torch=str(torch.__version__), numpy=np.__version__,
                  cuda=torch.version.cuda, cudnn=torch.backends.cudnn.version(), device=torch.cuda.get_device_name(0),
                  batch_size=256, dtype=str(torch.get_default_dtype()).removeprefix('torch.'),
                  seed=int(torch.initial_seed()),cudnn_benchmark=torch.backends.cudnn.benchmark,
                  amp=False,compilation=False,matmul_precision=torch.get_float32_matmul_precision(),
                  cudnn_enabled=torch.backends.cudnn.enabled,cudnn_deterministic=torch.backends.cudnn.deterministic,
                  deterministic_algorithms=torch.are_deterministic_algorithms_enabled(),
                  cuda_matmul_allow_tf32=torch.backends.cuda.matmul.allow_tf32,
                  cudnn_allow_tf32=torch.backends.cudnn.allow_tf32,autocast_enabled=torch.is_autocast_enabled(),
                  grad_enabled=torch.is_grad_enabled())
    reference = read_json(MAIN / 'run_003/environment.json')
    actual['reference_differences'] = {k: {'reference': reference[k], 'actual': actual[k]} for k in ('torch','numpy','cuda','cudnn','device','batch_size','cudnn_benchmark','matmul_precision') if actual[k] != reference[k]}
    return actual


def load_dataset(path, expected):
    import torch
    verify(path, expected)
    dataset_class = load_module(FORMAL / 'sources/dataset.py').WindowedTimeSeriesDataset
    class Compat(pickle.Unpickler):
        def find_class(self, module, name):
            if module == 'src.modules.data_preprocessor.windowed_time_series' and name == 'WindowedTimeSeriesDataset':
                return dataset_class
            return super().find_class(module, name)
    adapter = types.ModuleType('frozen_dataset_compat')
    adapter.Unpickler, adapter.load, adapter.loads = Compat, pickle.load, pickle.loads
    ds = torch.load(path, map_location='cpu', weights_only=False, pickle_module=adapter)
    if not isinstance(ds, dataset_class):
        raise ValueError('Unexpected frozen dataset class')
    LOAD_LEDGER.append(dict(path=str(path), sha256=expected, role='dataset'))
    return ds


def load_tensor(path, expected, role):
    import torch
    verify(path, expected)
    value = torch.load(path, map_location='cpu', weights_only=False)
    LOAD_LEDGER.append(dict(path=str(path), sha256=expected, role=role))
    return value


def build_model(case, output, instrumented, plain_physics=False):
    import torch
    import yaml
    from diagnostic_capture import instrument_source
    verify(case['config'], case['config_sha256'])
    cfg = read_json(case['config']) if case['family'] == 'new' else yaml.safe_load(Path(case['config']).read_text(encoding='utf-8'))
    cfg = copy.deepcopy(cfg)
    cfg['runtime'].update(device='cuda', use_amp=False, use_torch_compile=False, debug_checks=False)
    cfg['dataloader']['batch_size'] = 256
    physics = 'original' if case['variant'].startswith('original_outlet') else 'corrected'
    physics_path = PROBE / ('sources/walrus.py' if plain_physics else 'sources/walrus_observed.py') if physics == 'original' else FORMAL / 'sources/walrus_corrected.py'
    network_path = FORMAL / 'sources/network.py'
    proofs = {}
    if instrumented:
        for kind, path in [('network', network_path), ('physics', physics_path)]:
            text, proofs[kind] = instrument_source(path.read_text(encoding='utf-8'), kind)
            generated = output / (kind + '_' + uuid.uuid4().hex + '.py')
            with generated.open('x', encoding='utf-8') as stream:
                stream.write(text)
            if kind == 'network': network_path = generated
            else: physics_path = generated
    load_module(physics_path, 'probe_walrus_observed')
    load_module(FORMAL / 'sources/system_model.py', 'probe_system_model')
    load_module(FORMAL / 'sources/params.py', 'probe_params')
    load_module(network_path, 'probe_network')
    init = load_module(FORMAL / 'sources/initializer.py')
    builder = load_module(FORMAL / 'sources/builders.py')
    system, hydro = init.initialize_system_model(800, 800, device='cuda')
    args = builder.build_args(cfg, torch.zeros(800), torch.zeros(800))
    model = builder.build_knet(system, args)
    checkpoint = load_tensor(case['checkpoint'], case['checkpoint_sha256'], 'checkpoint')
    key = 'model' if case['family'] == 'new' else 'model_state_dict'
    if not isinstance(checkpoint, dict) or key not in checkpoint or checkpoint['epoch'] != case['epoch']:
        raise ValueError('Checkpoint schema/epoch mismatch')
    if case['family'] == 'new':
        for field in ('initial_weight_tensor_sha256', 'protocol_sha256', 'common_validation_mse'):
            if checkpoint[field] != case[field]:
                raise ValueError('New checkpoint internal provenance mismatch: ' + field)
    model.load_state_dict(checkpoint[key], strict=True)
    if sum(p.numel() for p in model.parameters()) != case['parameters']:
        raise ValueError('Unexpected trained architecture size')
    for value in model.state_dict().values():
        if value.dtype != torch.float32 or not torch.isfinite(value).all():
            raise ValueError('Checkpoint tensors must be finite float32')
    model.eval()
    for param in model.parameters(): param.requires_grad_(False)
    bounds = {k: [float(getattr(model, k + '_lb')), float(getattr(model, k + '_ub'))] for k in ('dv','dg','hq','hs','q')}
    expected = {'dv':[50.,500.], 'dg':[50.,2450.], 'hq':[0.,20.], 'hs':[5.,5000.], 'q':[0.,5.]}
    expected.update(cfg['model']['knet'].get('state_bounds', {}))
    if bounds != expected or not model.enable_clamp_scale:
        raise ValueError('Effective trained bounds/clamp switch mismatch')
    for key, value in cfg['model']['knet']['clamp_scale'].items():
        if key != 'enable' and not torch.equal(model.clamp_scale_info[key].detach().cpu(), torch.tensor(value, dtype=torch.float32)):
            raise ValueError('Effective trained clamp scale mismatch: ' + key)
    return types.SimpleNamespace(model=model, system=system, hydro=hydro, args=args, core=load_core(),
                                 effective=dict(model=cfg['model'], bounds=bounds, parameters=case['parameters'],
                                                physics=physics, instrumentation=proofs), instrumented=instrumented)


def counter_snapshot(hydro):
    return {name: int(getattr(hydro, name)) for name in COUNTERS}


def reset_counters(hydro):
    for name in COUNTERS:
        getattr(hydro, name).zero_()


def expected_counters(batch_size, hours, forecast):
    return dict(audit_q_calls=hours + (47 if forecast else 0),
                audit_q_elements=batch_size * hours + (batch_size * (hours - 47) * 47 if forecast else 0))


def check_counters(actual, expected):
    for name, value in expected.items():
        if actual[name] != value:
            raise ValueError(f'Physical propagation coverage mismatch: {name}: {actual[name]} != {value}')
    if not 0 <= actual['audit_gap_hits'] <= actual['audit_q_elements']:
        raise ValueError('Invalid outlet gap hits')


def infer(runtime, batch, logging=False, forecast=True):
    import torch
    from diagnostic_capture import Recorder
    prepared = load_module(FORMAL / 'sources/prepare.py').prepare_batch_data(batch, 'cuda')
    p, ep, obs, states, hours = prepared
    model, hydro = runtime.model, runtime.hydro
    model.batch_size = obs.shape[0]
    model.update_mode = True
    model.init_hidden_KNet()
    model.init_sequence(states[:, :, 0], obs.shape[-1])
    recorder = Recorder() if logging else None
    if runtime.instrumented:
        model._audit_capture = recorder
        hydro.capture_enabled = logging
    original_f = model.f
    if logging:
        def observed_f(x, controls):
            result = original_f(x, controls)
            recorder.physical(hydro.capture_before, hydro.capture_after)
            return result
        model.f = observed_f
    try:
        pipeline = types.SimpleNamespace(knet_model=model, sys_model=runtime.system, args=runtime.args)
        updated, outputs = runtime.core.forward_sequence(pipeline, obs, torch.cat((p, ep), dim=1))
    finally:
        model.f = original_f
    assimilation_counters = counter_snapshot(hydro) if hasattr(hydro, 'audit_q_calls') else None
    if forecast:
        forecasts, predictions = runtime.core.system_model_forecast(runtime.system, p, ep, updated, lead_time=48)
    else:
        forecasts, predictions = None, None
    result = dict(updated=updated, outputs=outputs, forecast_states=forecasts, predictions=predictions,
                  observation=obs, hours=hours, capture=recorder, assimilation_counters=assimilation_counters)
    if hasattr(hydro, 'audit_q_calls'):
        result['counters'] = counter_snapshot(hydro)
    return result
