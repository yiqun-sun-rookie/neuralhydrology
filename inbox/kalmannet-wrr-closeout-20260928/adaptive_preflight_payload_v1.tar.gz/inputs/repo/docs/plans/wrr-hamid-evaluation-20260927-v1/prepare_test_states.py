"""Auditable paired test-state reconstruction. Importing this module is inert.

Only build_test_initial_states() or the CLI with --execute can read test data.
Reconstructed implementation, not proof of historical bitwise execution.
"""
import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import pickle
import platform
import sys
import time
import types
import uuid

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
PRIOR = ROOT.parent / 'wrr-hamid-weights-20260923-v1'
FORMAL = PRIOR / 'formal_package_v3'
PROBE = PRIOR / 'probe_package_v2'
TEST_PATH = REPO / 'data/processed/high_flow_aug/test_win800_20090314_14-20110101_01.pt'
TEST_SHA = 'df18203c073314c5a15c6df77411cb972a0a3f983d97cc468760ff12dbd6908a'
ORIGINAL_SHA = '703adbb37c7bd3804f7f218664c9636f4a3c5a303687fdbb33fc6172b0daffd2'
CORRECTED_SHA = 'ef134f2913199c9323bf9e3c3cff43bc5de0a414f29daf95951034aa6ff345a1'
OBSERVED_SHA = 'b02a8c95175557997764280a281533fcbe5a534ad2f35c9df8b6ef674dc74537'
COLUMNS = ('p', 'etpot', 'qobs', 'tm_hours')
COUNTERS = ('audit_gap_hits', 'audit_q_calls', 'audit_q_elements')
LIMITATION = 'Reconstructed implementation, not proof of historical bitwise execution. The original 0.01 guards remain; complete ideal derivatives are not restored.'


def file_sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def verify_file(path, expected):
    actual = file_sha(path)
    if actual != expected:
        raise ValueError(f'SHA-256 mismatch: {path}: {actual} != {expected}')
    return actual


def tensor_sha(tensor):
    return hashlib.sha256(tensor.detach().cpu().contiguous().numpy().tobytes()).hexdigest()


def tensor_record(tensor):
    return {'sha256': tensor_sha(tensor), 'dtype': str(tensor.dtype),
            'shape': list(tensor.shape), 'device': str(tensor.device)}


def claim_output(output_dir):
    target = Path(output_dir).resolve()
    if target == ROOT or not target.is_relative_to(ROOT):
        raise ValueError('Output must be a new child directory inside the task root')
    # Existing parents must resolve within ROOT; mkdir is exclusive and never overwrites.
    target.mkdir(exist_ok=False)
    return target


def atomic_json(path, payload):
    temporary = path.with_name('.' + path.name + '.' + uuid.uuid4().hex + '.tmp')
    with temporary.open('x', encoding='utf-8') as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False, allow_nan=False)
        handle.flush()
        os.fsync(handle.fileno())
    if path.exists():
        raise FileExistsError(path)
    temporary.rename(path)


def verify_observation_only(original, observed):
    """Remove exactly the pinned counter additions, then compare complete syntax trees."""
    clean = observed
    for name in COUNTERS:
        line = f'        self.register_buffer("{name}", torch.zeros((), dtype=torch.int64, device=self.device))\n'
        if clean.count(line) != 1:
            raise ValueError('Unexpected counter buffer instrumentation')
        clean = clean.replace(line, '', 1)
    block = ('        with torch.no_grad():\n'
             '            self.audit_gap_hits.add_(((hs > self.cd) & (hs <= self.cd + 1.0)).sum())\n'
             '            self.audit_q_calls.add_(1)\n'
             '            self.audit_q_elements.add_(hs.numel())\n')
    if clean.count(block) != 1:
        raise ValueError('Unexpected counter update instrumentation')
    clean = clean.replace(block, '', 1)
    if ast.dump(ast.parse(clean)) != ast.dump(ast.parse(original)):
        raise ValueError('Observed model differs from original beyond counters')
    return True


def verify_sources():
    pinned = {
        FORMAL / 'manifest.json': '4bd8fe167bb5d6932a25161e9855bfdf03f656352b567aeee903e31925b6899f',
        PROBE / 'manifest.json': '6a3c22fbca369886c0bd8dd9f746e0d32cc0fb750a80b8070640d2c9d632cb7a',
        FORMAL / 'protocol.json': '2575b0fcdafcf5befb38c4e6a431f856a202164c81763a3eb99e1c141d6055cc',
        PRIOR / 'initial_state_replay_v1/completion.json': '5a9773f2b3014d09d5b2d95ac2a6a5c9ec18e574f3529f7652778cc375b74d3b',
        PRIOR / 'rebuild_initial_states.py': '7775a31800fc3113e6a4df6e0efca7d62cb439fad044aebaeb17ef660af63fce',
        FORMAL / 'sources/dataset.py': '8389e6d1fc24ca46fc395ebe102ab685436409be03dd787ba2b46eca56e79cb4',
        FORMAL / 'sources/params.py': 'bd64b468504491cacee12c060b8f3f2ff8bb1a7a3e04cf01b826547a6bc52cab',
        PROBE / 'sources/walrus.py': ORIGINAL_SHA,
        PROBE / 'sources/walrus_observed.py': OBSERVED_SHA,
        FORMAL / 'sources/walrus_corrected.py': CORRECTED_SHA,
    }
    fingerprints = {str(path): verify_file(path, expected) for path, expected in pinned.items()}
    formal = json.loads((FORMAL / 'manifest.json').read_text(encoding='utf-8'))
    probe = json.loads((PROBE / 'manifest.json').read_text(encoding='utf-8'))
    protocol = json.loads((FORMAL / 'protocol.json').read_text(encoding='utf-8'))
    for rel in ('sources/dataset.py', 'sources/params.py', 'sources/walrus_corrected.py', 'protocol.json'):
        if formal['files'][rel] != pinned[FORMAL / rel]:
            raise ValueError(f'Frozen manifest mismatch: {rel}')
    if probe['files']['sources/walrus_observed.py'] != OBSERVED_SHA:
        raise ValueError('Probe manifest mismatch')
    archived = Path(protocol['source_manifest']['walrus.py']['path'])
    fingerprints[str(archived)] = verify_file(archived, ORIGINAL_SHA)
    original_path = PROBE / 'sources/walrus.py'
    observed_path = PROBE / 'sources/walrus_observed.py'
    corrected_path = FORMAL / 'sources/walrus_corrected.py'
    original = original_path.read_text(encoding='utf-8')
    observed = observed_path.read_text(encoding='utf-8')
    corrected = corrected_path.read_text(encoding='utf-8')
    verify_observation_only(original, observed)
    before, after = '        overflow = hs > cd + 1.0', '        overflow = hs > cd'
    if observed.count(before) != 1 or ast.dump(ast.parse(observed.replace(before, after, 1))) != ast.dump(ast.parse(corrected)):
        raise ValueError('Correction differs beyond the frozen outlet condition')
    reference = (PRIOR / 'rebuild_initial_states.py').read_text(encoding='utf-8')
    for binding in ('a[0]=state0;b[0]=state0', 'for t in range(1,n):',
                    'controls[t].unsqueeze(0)', 'ds.states_all[0]'):
        if binding not in reference:
            raise ValueError('Frozen initial-state rule does not match')
    return {'fingerprints': fingerprints, 'original_path': original_path,
            'observed_path': observed_path, 'corrected_path': corrected_path,
            'dataset_path': FORMAL / 'sources/dataset.py',
            'params_path': FORMAL / 'sources/params.py',
            'initial_state_rule': 'states[0] = dataset.states_all[0]; states[t] = f(states[t-1], forcing[t]), t=1..N-1; exact saved row order',
            'observation_only_source_verified': True, 'sole_correction_verified': True}


def load_source(path, label):
    # The source has already passed its pinned fingerprint gate. Suppress bytecode.
    name = '_state_preparer_' + label + '_' + uuid.uuid4().hex
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    previous = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = previous
    return module


def configure_runtime():
    import numpy as np
    import torch
    if (platform.python_version(), torch.__version__, np.__version__) != ('3.11.13', '2.4.0', '2.3.2'):
        raise ValueError('Runtime does not match frozen Python 3.11.13 / PyTorch 2.4.0 / NumPy 2.3.2')
    if torch.get_default_dtype() != torch.float32:
        raise ValueError('Default floating point dtype must be float32')
    torch.set_num_threads(1)
    if torch.get_num_interop_threads() != 1:
        torch.set_num_interop_threads(1)
    return {'python': platform.python_version(), 'torch': torch.__version__, 'numpy': np.__version__,
            'executable': sys.executable, 'platform': platform.platform(), 'device': 'cpu',
            'threads': torch.get_num_threads(), 'interop_threads': torch.get_num_interop_threads(),
            'default_dtype': str(torch.get_default_dtype()), 'f_execution': 'torch.jit.script; sequential Python loop',
            'autograd_for_replay': False, 'optimizer': None}


def make_models(sources, state0, include_unobserved=False):
    import torch
    params = load_source(sources['params_path'], 'params').params
    kwargs = {name: float(params[name]) for name in ('cw', 'cv', 'cg', 'cq', 'cd', 'cs')}
    kwargs.update(initial_state=state0.clone(), device='cpu')
    paths = [sources['observed_path'], sources['corrected_path']]
    if include_unobserved:
        paths.append(sources['original_path'])
    models = []
    for index, path in enumerate(paths):
        model = load_source(path, 'model' + str(index)).WalrusBatch(**kwargs)
        model.eval()
        if any(p.requires_grad for p in model.parameters()):
            raise ValueError('Unexpected trainable model parameters')
        models.append(torch.jit.script(model))
    return models


def reset_counters(model):
    for name in COUNTERS:
        getattr(model, name).zero_()


def technical_gate(sources):
    """Synthetic-only checks, always executed before test file hashing or loading."""
    import torch
    environment = configure_runtime()
    start = time.perf_counter()
    state0 = torch.tensor([140., 1000., 4., 1200., .1], dtype=torch.float32)
    old, fixed, plain = make_models(sources, state0, include_unobserved=True)
    lo, hi = torch.tensor(2450., dtype=torch.float32), torch.tensor(2451., dtype=torch.float32)
    infinity = torch.tensor(float('inf'), dtype=torch.float32)
    levels = torch.stack([torch.tensor(2449.), lo, torch.nextafter(lo, infinity),
                          torch.tensor(2450.5), hi, torch.nextafter(hi, infinity), torch.tensor(2452.)])
    gap = (levels > lo) & (levels <= hi)
    values, gradients = [], []
    for model in (old, fixed):
        reset_counters(model)
        hs = levels.clone().requires_grad_(True)
        out = model.func_q_hs_def(hs)
        grad = torch.autograd.grad(out.sum(), hs)[0]
        if not bool(torch.isfinite(out).all() and torch.isfinite(grad).all()):
            raise ValueError('Nonfinite outlet output or gradient')
        if int(model.audit_q_calls) != 1 or int(model.audit_q_elements) != 7 or int(model.audit_gap_hits) != 3:
            raise ValueError('Outlet observation counter mismatch')
        values.append(out.detach())
        gradients.append(grad.detach())
    if not bool((values[0][gap] == 0).all() and (values[1][gap] > 0).all()):
        raise ValueError('Outlet gap correction failed')
    if not torch.equal(values[0][~gap], values[1][~gap]):
        raise ValueError('Outlet changed outside the frozen gap')
    # The guard deliberately yields zero derivative immediately to the right of cd.
    if gradients[1][2].item() != 0:
        raise ValueError('The retained 0.01 guard differs')
    outlet = {'dtype': str(levels.dtype), 'levels': levels.tolist(), 'gap_elements': int(gap.sum()),
              'original': values[0].tolist(), 'corrected': values[1].tolist(),
              'original_gradients': gradients[0].tolist(), 'corrected_gradients': gradients[1].tolist(),
              'finite_gradients': True, 'original_gap_hits': int(old.audit_gap_hits),
              'corrected_gap_hits': int(fixed.audit_gap_hits), 'outside_gap_equal': True}
    # Prove instrumentation preserves f on synthetic states around outlet levels.
    x = state0.repeat(len(levels), 1)
    x[:, 3] = levels
    forcing = torch.zeros(len(levels), 2, dtype=torch.float32)
    with torch.no_grad():
        observed_result, plain_result = old.f(x, forcing), plain.f(x, forcing)
    if not torch.equal(observed_result, plain_result):
        raise ValueError('Counter instrumentation changes model propagation')
    for model in (old, fixed):
        state = x.clone().requires_grad_(True)
        controls = forcing.clone().requires_grad_(True)
        out = model.f(state, controls)
        deriv = torch.autograd.grad(out.sum(), (state, controls))
        if not bool(torch.isfinite(out).all()) or not all(bool(torch.isfinite(g).all()) for g in deriv):
            raise ValueError('Nonfinite propagation output or necessary gradient')
    # Bridge the row loop to the hash-bound previous scripted replay on synthetic
    # input only. Its guarded main is never invoked and no tensor file is read.
    synthetic = types.SimpleNamespace(
        p=torch.tensor([[99.], [1.], [2.], [3.]], dtype=torch.float32),
        etpot=torch.tensor([[0.], [.1], [.2], [.3]], dtype=torch.float32),
        qobs=torch.ones(4, 1, dtype=torch.float32),
        tm_hours=torch.arange(4, dtype=torch.float32).reshape(-1, 1),
        states_all=state0.repeat(4, 1), window_size=2)
    a, b, replay_receipt = replay(synthetic, old, fixed, expected_rows=4, expected_window=2)
    reference = load_source(PRIOR / 'rebuild_initial_states.py', 'frozen_replay')
    prior_loop = torch.jit.script(reference.PairedReplay(old, fixed))
    with torch.no_grad():
        expected_a, expected_b = prior_loop(torch.cat((synthetic.p, synthetic.etpot), dim=1), state0)
    if not torch.equal(a, expected_a) or not torch.equal(b, expected_b):
        raise ValueError('Synthetic replay differs from frozen training/validation recipe')
    return {'state': 'TECHNICAL_GATE_PASSED', 'environment': environment, 'outlet': outlet,
            'observation_only_source_verified': sources['observation_only_source_verified'],
            'sole_correction_verified': sources['sole_correction_verified'],
            'instrumented_f_exactly_equal': True, 'propagation_gradients_finite': True,
            'synthetic_replay': replay_receipt, 'frozen_replay_exactly_equal': True,
            'test_data_access': False, 'seconds': time.perf_counter() - start, 'limitation': LIMITATION}


def snapshot_columns(dataset):
    return {name: getattr(dataset, name).detach().clone() for name in COLUMNS}


def check_columns(dataset, snapshot):
    import torch
    for name, saved in snapshot.items():
        current = getattr(dataset, name)
        if current.dtype != saved.dtype or current.device != saved.device or not torch.equal(current, saved):
            raise ValueError(f'Protected data column changed: {name}')


def validate_dataset(dataset, expected_rows=15780, expected_window=800):
    import torch
    for name in (*COLUMNS, 'states_all'):
        arr = getattr(dataset, name, None)
        expected = (expected_rows, 5 if name == 'states_all' else 1)
        if not isinstance(arr, torch.Tensor) or tuple(arr.shape) != expected:
            raise ValueError(f'Invalid shape: {name}; expected {expected}')
        if arr.dtype != torch.float32 or arr.device.type != 'cpu':
            raise ValueError(f'Frozen data precision/device mismatch: {name}')
        if not bool(torch.isfinite(arr).all()):
            raise ValueError(f'Nonfinite data: {name}')
    if dataset.window_size != expected_window or expected_rows < expected_window:
        raise ValueError('Invalid window length')
    if not bool((dataset.tm_hours[1:] - dataset.tm_hours[:-1] == 1).all()):
        raise ValueError('Time must advance exactly one hour per saved row')
    return {'rows': expected_rows, 'state_shape': [expected_rows, 5],
            'window_hours': expected_window, 'windows': expected_rows - expected_window + 1,
            'time_first': dataset.tm_hours[0].item(), 'time_last': dataset.tm_hours[-1].item(),
            'time_adjacent_difference': 1, 'dtype': 'torch.float32', 'all_finite': True}


def replay(dataset, original, corrected, expected_rows=15780, expected_window=800):
    import torch
    contract = validate_dataset(dataset, expected_rows, expected_window)
    snapshot = snapshot_columns(dataset)
    stored = dataset.states_all.clone()
    state0 = stored[0].clone()
    controls = torch.cat((dataset.p, dataset.etpot), dim=1)
    a, b = torch.empty_like(stored), torch.empty_like(stored)
    a[0], b[0] = state0, state0
    for model in (original, corrected):
        reset_counters(model)
    started = time.perf_counter()
    with torch.no_grad():
        for index in range(1, expected_rows):
            for model, states in ((original, a), (corrected, b)):
                result = model.f(states[index - 1:index], controls[index:index + 1])
                if result.shape != (1, 5) or result.dtype != stored.dtype or result.device.type != 'cpu':
                    raise ValueError(f'Propagation shape/precision/device mismatch at row {index}')
                if not bool(torch.isfinite(result).all()):
                    raise ValueError(f'Nonfinite propagation at row {index}')
                states[index] = result[0]
    check_columns(dataset, snapshot)
    if not torch.equal(stored, dataset.states_all):
        raise ValueError('Stored original states were mutated')
    report = {'time_contract': contract, 'seconds': time.perf_counter() - started,
              'initial_state_actual': state0.tolist(), 'initial_state': tensor_record(state0),
              'initial_state_source': 'original dataset.states_all[0]; identical for both chains',
              'columns_before': {k: tensor_record(v) for k, v in snapshot.items()},
              'columns_after': {k: tensor_record(getattr(dataset, k)) for k in COLUMNS},
              'columns_exactly_unchanged': True, 'stored_states': tensor_record(stored),
              'original_vs_stored_max_abs_by_state': (a - stored).abs().max(dim=0).values.tolist(),
              'repair_vs_original_max_abs_by_state': (b - a).abs().max(dim=0).values.tolist(),
              'original_vs_stored_changed_rows': int((a != stored).any(dim=1).sum()),
              'original_vs_stored_changed_values': int((a != stored).sum()),
              'repair_changed_rows': int((a != b).any(dim=1).sum()),
              'repair_changed_values': int((a != b).sum()),
              'original_cpu': tensor_record(a), 'corrected_cpu': tensor_record(b)}
    for label, model in (('original', original), ('corrected', corrected)):
        report[label + '_gap_hits'] = int(model.audit_gap_hits)
        report[label + '_f_calls'] = int(model.audit_q_calls)
        report[label + '_q_elements'] = int(model.audit_q_elements)
        if report[label + '_f_calls'] != expected_rows - 1 or report[label + '_q_elements'] != expected_rows - 1:
            raise ValueError('Propagation counter mismatch')
    return a, b, report


def load_test_dataset(sources):
    import torch
    verify_file(TEST_PATH, TEST_SHA)
    dataset_class = load_source(sources['dataset_path'], 'dataset').WindowedTimeSeriesDataset
    class Compat(pickle.Unpickler):
        def find_class(self, module, name):
            if module == 'src.modules.data_preprocessor.windowed_time_series' and name == 'WindowedTimeSeriesDataset':
                return dataset_class
            return super().find_class(module, name)
    adapter = types.ModuleType('known_dataset')
    adapter.Unpickler, adapter.load, adapter.loads = Compat, pickle.load, pickle.loads
    data = torch.load(TEST_PATH, map_location='cpu', weights_only=False, pickle_module=adapter)
    if not isinstance(data, dataset_class):
        raise ValueError('Unexpected frozen dataset class')
    validate_dataset(data)
    if len(data) != 14981:
        raise ValueError('Frozen dataset window count mismatch')
    return data


def build_test_initial_states(output_dir: Path) -> dict:
    """Explicit execution entry; exclusively creates output_dir below ROOT."""
    output = claim_output(output_dir)
    started = time.perf_counter()
    report = {'state': 'RUNNING', 'phase': 'verify_sources', 'output_dir': str(output),
              'limitation': LIMITATION, 'implementation_sha256': file_sha(Path(__file__))}
    try:
        sources = verify_sources()
        report['source_fingerprints'] = sources['fingerprints']
        report['initial_state_rule'] = sources['initial_state_rule']
        report['phase'] = 'technical_gate'
        report['technical_gate'] = technical_gate(sources)
        report['environment'] = report['technical_gate']['environment']
        report['phase'] = 'load_test_dataset'
        dataset = load_test_dataset(sources)
        report['source_dataset'] = {'path': str(TEST_PATH), 'sha256': TEST_SHA}
        report['phase'] = 'paired_replay'
        original, corrected = make_models(sources, dataset.states_all[0])
        report['model_buffers_before_replay'] = {
            label: {name: tensor_record(value) for name, value in model.named_buffers()}
            for label, model in (('original', original), ('corrected', corrected))}
        a, b, paired = replay(dataset, original, corrected)
        report['paired'] = paired
        # Bind sources and dataset again before committing successful outputs.
        for path, expected in sources['fingerprints'].items():
            verify_file(Path(path), expected)
        verify_file(TEST_PATH, TEST_SHA)
        report['phase'] = 'save_outputs'
        import torch
        report['files'] = {}
        for name, tensor in (('test_original_cpu.pt', a), ('test_corrected_cpu.pt', b)):
            path = output / name
            with path.open('xb') as handle:
                torch.save(tensor, handle)
                handle.flush()
                os.fsync(handle.fileno())
            report['files'][name] = {'sha256': file_sha(path), 'bytes': path.stat().st_size,
                                   'tensor': tensor_record(tensor)}
        report.update(state='PAIRED_TEST_STATES_COMPLETE', phase='complete', seconds=time.perf_counter() - started)
        atomic_json(output / 'completion.json', report)
        return report
    except BaseException as error:
        report.update(state='FAILED', error_type=type(error).__name__, error=str(error),
                      seconds=time.perf_counter() - started)
        atomic_json(output / 'failure.json', report)
        raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args(argv)
    if not args.execute:
        print('Not executed. Test data were not read. Add --execute and --output only after review.')
        return 0
    if args.output is None:
        parser.error('--execute requires --output')
    report = build_test_initial_states(args.output)
    print(json.dumps({'state': report['state'], 'output_dir': report['output_dir']}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
