"""Paired original/corrected CPU cache replay, preserving all four input columns."""
import hashlib
import importlib.util
import json
from pathlib import Path
import pickle
import sys
import time
import types
import torch
from torch import nn

ROOT=Path(__file__).resolve().parent
PKG=ROOT/'probe_package_v2'
OUT=ROOT/'initial_state_replay_v1'

class PairedReplay(nn.Module):
    def __init__(self,original,corrected):
        super().__init__();self.original=original;self.corrected=corrected
    def forward(self,controls:torch.Tensor,state0:torch.Tensor):
        n=controls.shape[0]
        a=torch.zeros((n,5),dtype=state0.dtype,device=state0.device)
        b=torch.zeros_like(a)
        a[0]=state0;b[0]=state0
        for t in range(1,n):
            a[t]=self.original.f(a[t-1].unsqueeze(0),controls[t].unsqueeze(0)).squeeze(0)
            b[t]=self.corrected.f(b[t-1].unsqueeze(0),controls[t].unsqueeze(0)).squeeze(0)
        return a,b

def tensor_sha(x):return hashlib.sha256(x.detach().cpu().contiguous().numpy().tobytes()).hexdigest()
def main():
    OUT.mkdir(exist_ok=False)
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    spec=importlib.util.spec_from_file_location('probe_driver',PKG/'probe.py');probe=importlib.util.module_from_spec(spec);spec.loader.exec_module(probe)
    dataset=probe.load('dataset','dataset.py');params=probe.load('params','params.py').params;old=probe.load('walrus_observed','walrus_observed.py')
    fixed_path=ROOT/'physics_diagnostic_v1/walrus_fixed.py'
    spec=importlib.util.spec_from_file_location('cache_fixed',fixed_path);new=importlib.util.module_from_spec(spec);sys.modules[spec.name]=new;spec.loader.exec_module(new)
    kwargs={k:float(params[k]) for k in ['cw','cv','cg','cq','cd','cs']};kwargs.update(initial_state=torch.tensor([140.,1000.,4.,1200.,.1]),device='cpu')
    original=torch.jit.script(old.WalrusBatch(**kwargs));corrected=torch.jit.script(new.WalrusBatch(**kwargs))
    replay=torch.jit.script(PairedReplay(original,corrected))
    class Compat(pickle.Unpickler):
        def find_class(self,module,name):
            if module=='src.modules.data_preprocessor.windowed_time_series' and name=='WindowedTimeSeriesDataset':return dataset.WindowedTimeSeriesDataset
            return super().find_class(module,name)
    adapter=types.ModuleType('known_dataset');adapter.Unpickler=Compat;adapter.load=pickle.load;adapter.loads=pickle.loads
    manifest=json.loads((PKG/'manifest.json').read_text())
    report={'state':'REPLAY_RUNNING','torch':torch.__version__,'device':'cpu','threads':1,'loop':'states[0]=documented state0; states[t]=f(states[t-1],forcing[t]) across exact saved row order including augmented joins','limitation':'Reconstructed implementation, not proof of historical execution. Original CPU replay separates arithmetic drift from the one-line condition repair.','source_sha256':hashlib.sha256(fixed_path.read_bytes()).hexdigest(),'splits':{}}
    for split,meta in manifest['data'].items():
        path=ROOT.parents[2]/'data/processed/high_flow_aug'/meta['name'];assert hashlib.sha256(path.read_bytes()).hexdigest()==meta['sha256']
        ds=torch.load(path,map_location='cpu',weights_only=False,pickle_module=adapter)
        columns={k:tensor_sha(getattr(ds,k)) for k in ['p','etpot','qobs','tm_hours']}
        for mdl in [original,corrected]:mdl.audit_gap_hits.zero_();mdl.audit_q_calls.zero_();mdl.audit_q_elements.zero_()
        start=time.perf_counter()
        with torch.no_grad():a,b=replay(torch.cat((ds.p,ds.etpot),dim=1),ds.states_all[0])
        assert bool(torch.isfinite(a).all()) and bool(torch.isfinite(b).all())
        assert all(tensor_sha(getattr(ds,k))==v for k,v in columns.items())
        for label,arr in [('original_cpu',a),('corrected_cpu',b)]:
            with (OUT/(split+'_'+label+'.pt')).open('xb') as f:torch.save(arr,f)
        delta_stored=(a-ds.states_all).abs();delta_repair=(b-a).abs()
        row={'seconds':time.perf_counter()-start,'source_dataset_sha256':meta['sha256'],'columns_unchanged_sha256':columns,'original_vs_stored_max_abs_by_state':delta_stored.max(dim=0).values.tolist(),'repair_vs_original_max_abs_by_state':delta_repair.max(dim=0).values.tolist(),'repair_changed_rows':int(torch.any(a!=b,dim=1).sum()),'repair_changed_values':int((a!=b).sum()),'original_gap_calls':int(original.audit_gap_hits),'corrected_gap_calls':int(corrected.audit_gap_hits),'original_f_calls':int(original.audit_q_calls),'corrected_f_calls':int(corrected.audit_q_calls),'original_tensor_sha256':tensor_sha(a),'corrected_tensor_sha256':tensor_sha(b)}
        assert row['original_f_calls']==len(ds.qobs)-1==row['corrected_f_calls']
        report['splits'][split]=row
        with (OUT/(split+'_receipt.json')).open('x') as f:json.dump(row,f,indent=2)
        print(json.dumps({'split':split,**row}),flush=True)
    report['state']='PAIRED_CACHE_REPLAY_COMPLETE'
    report['files']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.glob('*.pt'))}
    with (OUT/'completion.json').open('x') as f:json.dump(report,f,indent=2)
    print('PAIRED_CACHE_REPLAY_COMPLETE',flush=True)

if __name__=='__main__':main()
