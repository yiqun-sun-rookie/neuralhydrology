

def prepare_batch_data(batch, device):
    p = batch['p'].to(device)
    ep = batch['etpot'].to(device)
    y_obs = batch['qobs'].to(device)
    state0 = batch['state0'].to(device)
    tm_hours = batch['tm_hours'].to(device)
    return p, ep, y_obs, state0, tm_hours
