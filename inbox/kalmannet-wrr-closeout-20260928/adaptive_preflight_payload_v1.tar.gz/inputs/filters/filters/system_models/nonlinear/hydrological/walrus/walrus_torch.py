import torch
import torch.nn as nn
from torch.autograd.functional import jacobian as torch_jacobian
class WalrusTorch(nn.Module):
    def __init__(self, *, cw, cv, cg, cq, cd, cs, as_=0.01, device=None, m=5, n=1, initial_state=None, check_nan_flag=False):
        """
        初始化水文模型参数和初始状态。
        Parameters:
        cw, cv, cg, cq, cd, cs : float
        as_ : float, optional 表面区域比例，默认为0.01。
        ag_ : float, optional 地下区域比例，如果未提供，则自动计算为1-as_。
        initial_state : numpy array初始状态向量。
        m : int, optional 状态向量的行维度，如果未提供，则自动从 initial_state 计算。
        n : int, optional 观测向量维度，如果未提供，默认为1。
        """
        super().__init__()

        # 设定设备
        self.device = device
        # 状态和观测维度
        self.m, self.n = m, n
        # 模型参数、默认值和约束
        self.set_paramters_defaults_bounds_state_names(cw=cw, cv=cv, cg=cg, cq=cq, cd=cd, cs=cs, as_=as_)
        # 初始状态
        self.state = initial_state.to(self.device) if not initial_state.is_cuda else initial_state
        # NaN 标志
        self.check_nan_flag = check_nan_flag

    def f(self, state, controls, noise=None):
        # 处理、检查输入
        self._check_nan(controls, "Input controls to f")
        assert controls.ndim == 2 and controls.shape[1] == 2, f"Expected controls to have shape [batch_size, 2], got {controls.shape}"
        p_t, etpot_t = controls[:, 0], controls[:, 1]
        assert p_t.ndim == 1, f"Expected p_t to have 1 dimension, got {p_t.ndim}"

        # 处理、检查状态
        self._check_nan(state, "Input state to f")
        assert state.ndim == 2 and state.shape[1] == self.m, f"Expected x to have shape [batch_size, state_dim], got {state.shape}"
        state = self._apply_state_constraints(state)  # 应用状态约束

        # 前向传播更新状态
        state = self.walrus_st_sp(state, p_t, etpot_t)
        if noise is not None:
            noise = noise.to(self.device) if not noise.is_cuda else noise
            state += noise
        next_state = self._apply_state_constraints(state)  # 应用状态约束
        self._check_nan(next_state, "Output state from forward")

        return state

    def h(self, x):
        self._check_nan(x, "Input x to h")
        assert x.ndim == 2 and x.shape[1] == self.m, f"Expected x to have shape [batch_size, state_dim], got {x.shape}"
        output = x[:, -1].unsqueeze(-1)
        # 检查结果的维度,返回值应为 [batch_size]
        self._check_nan(output, "Output result from h")
        assert output.ndim == 2 and output.shape[0] == x.shape[0] and output.shape[1] == self.n, \
            f"Expected output to have shape [batch_size, n], got {output.shape}"

        return output

    def _check_nan(self, tensor, name="Tensor"):
        """
        仅在 debug 时期做检查，性能敏感场景可直接关闭。
        """
        if self.check_nan_flag:
            if torch.isnan(tensor).any():
                raise ValueError(f"{name} contains NaN values.")

    def _prepare_state_for_jacobian(self, state: torch.Tensor) -> torch.Tensor:
        """
        Ensure the state tensor is 2D and requires grad for jacobian computations.
        """
        if state.ndim == 1:
            state = state.unsqueeze(0)
        return state.detach().clone().requires_grad_(True)

    def _compute_state_jacobian(self, func, state: torch.Tensor, controls: torch.Tensor | None = None) -> torch.Tensor:
        """
        Generic helper returning the jacobian of `func` w.r.t. the state.
        """
        state = self._prepare_state_for_jacobian(state)

        def wrapped(st):
            if controls is None:
                return func(st)
            return func(st, controls)

        jac = torch_jacobian(wrapped, state)
        if jac.ndim == 4:
            jac = jac[0, :, 0, :]
        elif jac.ndim == 3:
            jac = jac.squeeze(0)
        return jac

    def linearize_f(self, state, controls):
        """
        Compute ∂f/∂x at the provided state and controls.
        Expects state shape (m,) or (1, m); controls shape (2,) or (1, 2).
        Returns tensor with shape [m, m].
        """
        state_t = torch.as_tensor(state, dtype=torch.float32, device=self.device)
        ctrl_t = torch.as_tensor(controls, dtype=torch.float32, device=self.device)
        if ctrl_t.ndim == 1:
            ctrl_t = ctrl_t.unsqueeze(0)
        jac = self._compute_state_jacobian(lambda st, ctrl: self.f(st, ctrl), state_t, ctrl_t)
        return jac

    def linearize_h(self, state):
        """
        Compute ∂h/∂x at the provided state.
        Expects state shape (m,) or (1, m); returns tensor [n, m].
        """
        state_t = torch.as_tensor(state, dtype=torch.float32, device=self.device)
        jac = self._compute_state_jacobian(lambda st: self.h(st), state_t, None)
        return jac

    def set_state(self, state):
        """
        设置模型状态。
        """
        self.state = state.to(self.device) if not state.is_cuda else state

    def set_paramters_defaults_bounds_state_names(self, *, cw, cv, cg, cq, cd, cs, as_):
        # 模型参数
        self.cw = torch.tensor(cw, dtype=torch.float32, device=self.device)
        self.cv = torch.tensor(cv, dtype=torch.float32, device=self.device)
        self.cg = torch.tensor(cg, dtype=torch.float32, device=self.device)
        self.cq = torch.tensor(cq, dtype=torch.float32, device=self.device)
        self.cd = torch.tensor(cd, dtype=torch.float32, device=self.device)
        self.cs = torch.tensor(cs, dtype=torch.float32, device=self.device)
        self.as_ = torch.tensor(as_, dtype=torch.float32, device=self.device)
        self.ag_ = torch.tensor(1 - as_, dtype=torch.float32, device=self.device)
        self.b = torch.tensor(4.38, dtype=torch.float32, device=self.device)
        self.psi_ae = torch.tensor(90.0, dtype=torch.float32, device=self.device)
        self.theta_s = torch.tensor(0.41, dtype=torch.float32, device=self.device)
        self.zeta1 = torch.tensor(0.02, dtype=torch.float32, device=self.device)
        self.zeta2 = torch.tensor(400.0, dtype=torch.float32, device=self.device)
        self.min_h = torch.tensor(0.001, dtype=torch.float32, device=self.device)
        self.hs_min = torch.tensor(0.0, dtype=torch.float32, device=self.device)
        self.exps = torch.tensor(1.5, dtype=torch.float32, device=self.device)
        # 默认值
        self.default_fxg_t = torch.tensor(0, dtype=torch.float32, device=self.device)
        self.default_fxs_t = torch.tensor(0, dtype=torch.float32, device=self.device)
        self.default_hs_min_t = torch.tensor(0, dtype=torch.float32, device=self.device)
        # 状态约束
        self.dv_lb = torch.tensor(5.0, dtype=torch.float32, device=self.device)
        self.dv_ub = torch.tensor(500.0, dtype=torch.float32, device=self.device)
        self.dg_lb = torch.tensor(5.0, dtype=torch.float32, device=self.device)
        self.dg_ub = self.cd.clone().detach()
        self.hq_lb = torch.tensor(0.0, dtype=torch.float32, device=self.device)
        self.hq_ub = torch.tensor(20.0, dtype=torch.float32, device=self.device)
        self.hs_lb = torch.tensor(5.0, dtype=torch.float32, device=self.device)
        self.hs_ub = torch.tensor(5000.0, dtype=torch.float32, device=self.device)
        self.q_lb = torch.tensor(0.0, dtype=torch.float32, device=self.device)
        self.q_ub = torch.tensor(5.0, dtype=torch.float32, device=self.device)
        # 状态名称
        self.state_names = ['dv', 'dg', 'hq', 'hs', 'q']
        self.observed_state_names = ['q']

    def _apply_state_constraints(self, state):
        """
        应用状态约束。
        """
        state_new = torch.stack([
            torch.clamp(state[:, 0], self.dv_lb, self.dv_ub),  # dv
            torch.clamp(state[:, 1], self.dg_lb, self.dg_ub),  # dg
            torch.clamp(state[:, 2], self.hq_lb, self.hq_ub),  # hq
            torch.clamp(state[:, 3], self.hs_lb, self.hs_ub),  # hs
            torch.clamp(state[:, 4], self.q_lb, self.q_ub)  # q
        ], dim=1)
        self._check_nan(state, "After state constraints")
        return state_new

    def walrus_st_sp(self, state, p_t, etpot_t, fxg_t=0, fxs_t=0):

        # initialize state
        dv0, dg0, hq0, hs0, q = (state[:, 0], state[:, 1], torch.clamp(state[:, 2], min=0),
                                  state[:, 3], torch.clamp(state[:, 4], min=0))
        # -------------- 1. 计算 w --------------
        w = 0.5 * torch.cos(torch.clamp(dv0, min=0, max=self.cw) * torch.pi / self.cw) + 0.5

        # -------------- 2. 计算 dveq --------------
        dg_new = torch.clamp(dg0, self.dg_lb, self.dg_ub)  # dv_new
        psi_ae, b, theta_s = self.psi_ae, self.b, self.theta_s
        dveq = torch.where(dg_new > psi_ae,
                           (dg_new - (psi_ae / (1 - b)) - (dg_new ** (1 - 1 / b)) * (psi_ae ** (1 / b)) / (
                                       1 - 1 / b)) * theta_s, torch.where(dg_new < 0.0, dg_new, torch.zeros_like(dg_new)))

        # -------------- 3. 分割降水 p -> pq, pv, ps --------------
        pq = p_t * w * self.ag_
        pv = p_t * (1.0 - w) * self.ag_
        ps = p_t * self.as_

        # -------------- 4. 蒸散发 etv, ets --------------
        zeta2 = self.zeta2
        exp_term = torch.exp(self.zeta1 * (dv0 - zeta2))
        beta = (1 - exp_term) / (1 + exp_term) * 0.5 + 0.5
        etv = etpot_t * beta * self.ag_
        ets = torch.where(hs0 < self.min_h, 0.0, etpot_t * self.as_)

        # -------------- 5. q = f(hs) --------------
        fqs = hq0 / self.cq
        fgs = (self.cd - dg0 - hs0) * torch.max((self.cd - dg0), hs0) / self.cg
        # update state
        dv = dv0 - (fxg_t + pv - etv - fgs) / self.ag_
        dg = dg0 + (dv0 - dveq) / self.cv
        hq = torch.clamp(hq0 + (pq - fqs) / self.ag_, min=0.001)
        hs = torch.clamp(hs0 + (fxs_t + ps - ets + fgs + fqs - q) / self.as_, self.hs_lb, self.hs_ub)
        # 使用 torch.where 替代 if-else 来保持可微分性
        normal_flow = (hs > self.hs_min) & (hs <= self.cd)
        overflow = hs > self.cd + 1.0
        # 使用张量操作计算流量q
        q = torch.where(normal_flow, self.cs * ((hs - self.hs_min) / (self.cd - self.hs_min)) ** self.exps, 0.0)
        denom = torch.clamp(self.cd - self.hs_min, min=0.01)
        base = torch.clamp(hs - self.cd, min=0.01)
        q = torch.where(overflow, self.cs + self.cs * (base / denom) ** self.exps, q)

        # special case: large-scale ponding and flooding
        # Check conditions and adjust using torch.where
        condition1 = (dv < 0.0) & (hs <= self.cd)
        condition2 = (dv >= 0.0) & (hs > self.cd)
        condition3 = (dv <= 0.0) & (hs >= self.cd)
        condition4 = dv < 0.0

        # Apply adjustments based on conditions
        hs = torch.where(condition1, hs - (dv * self.ag_ / self.as_), hs)
        dv = torch.where(condition1, torch.zeros_like(dv), dv)
        dv = torch.where(condition2, dv - (hs - self.cd) * self.as_ / self.ag_, dv)
        hs = torch.where(condition2, self.cd * torch.ones_like(hs), hs)
        adjustment = dv * self.ag_ - (hs - self.cd) * self.as_
        hs = torch.where(condition3, self.cd - adjustment, hs)
        hs = torch.clamp(hs, min=0.001)
        dv = torch.where(condition3, adjustment, dv)
        dg = torch.where(condition4, dv, dg)

        # Final state
        next_state = torch.stack([dv, dg, hq, hs, q], dim=1)
        self._check_nan(next_state, "Output result from walrus_st_sp")

        return next_state
