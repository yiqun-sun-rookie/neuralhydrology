import matplotlib.pyplot as plt
from filters.utils.metrics import calc_mse, calc_nse

def plot_and_evaluate_series(
    sequences_dict,
    reference_key=None,
    metrics_list=None,
    title="Comparison of Q",
    xlabel="Time step",
    ylabel="Q",
    save_path=None
):
    """
    绘制若干条时序数据并可选地对其中除 reference_key 以外的序列
    与 reference_key 做对比，计算指定指标(如 MSE/NSE)。

    参数
    ----------
    sequences_dict : dict[str, array-like]
        e.g. {"Obs": q_obs, "Open-loop": q_openloop, "UKF": q_ukf, ...}
        key 为序列名称, value为该序列的 ndarray/list, 各序列长度应相同.

    reference_key : str or None
        指定用哪个key作为“参考/观测”序列。若 None 则不计算指标。
        常见写法："Obs" 表示观测。

    metrics_list : list[str] or None
        要计算的指标，如 ["MSE","NSE"]。若为 None，则不计算任何指标。

    title : str
        图标题
    xlabel : str
        X轴名称
    ylabel : str
        Y轴名称
    save_path : str or None
        若不为 None，则保存图像到该路径。

    返回
    ----------
    metrics_dict : dict[str, dict]
        若指定 reference_key & metrics_list，返回形如
        {
          "Open-loop": {"MSE":..., "NSE":...},
          "UKF":       {"MSE":..., "NSE":...},
          ...
        }
        若 reference_key=None 或 metrics_list=None，则返回空 dict。
    """

    # 1) 画图
    plt.figure(figsize=(10, 6))
    for name, series in sequences_dict.items():
        plt.plot(series, label=name)

    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.grid(True)
    plt.legend()

    if save_path is not None:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"Figure saved to: {save_path}")
    plt.show()

    # 2) 若需要计算指标
    metrics_dict = {}
    if (reference_key is not None) and (metrics_list is not None):
        if reference_key not in sequences_dict:
            raise ValueError(f"reference_key '{reference_key}' 不在 sequences_dict 中!")

        ref_series = sequences_dict[reference_key]
        N = len(ref_series)

        for name, series in sequences_dict.items():
            if name == reference_key:
                continue

            if len(series) != N:
                raise ValueError(f"Sequence '{name}' length != reference '{reference_key}' length.")

            m_dict = {}
            for metric in metrics_list:
                up_metric = metric.upper()
                if up_metric == "MSE":
                    m_dict["MSE"] = calc_mse(ref_series, series)
                elif up_metric == "NSE":
                    m_dict["NSE"] = calc_nse(ref_series, series)
                else:
                    print(f"Warning: unknown metric '{metric}', skip.")
            metrics_dict[name] = m_dict

        # 打印
        for name, mdict in metrics_dict.items():
            items_str = ", ".join([f"{k}={v:.4f}" for k,v in mdict.items()])
            print(f"Compare '{name}' vs '{reference_key}': {items_str}")

    return metrics_dict
def plot_comparison_2_series(observed, simulated, title, xlabel, ylabel, legend, filename=None):
    """
    绘制观测值与模拟值的对比图。

    参数:
    ----------
    observed : array-like
        观测值。
    simulated : array-like
        模拟值。
    title : str
        图表标题。
    xlabel : str
        X轴标签。
    ylabel : str
        Y轴标签。
    legend : list
        图例标签，长度为2。
    filename : str, optional
        保存图像的文件路径。如果为None，则不保存。
    """
    plt.figure(figsize=(10, 6))
    plt.plot(observed, label=legend[0], alpha=0.7)
    plt.plot(simulated, label=legend[1], alpha=0.7)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.legend()
    plt.grid(True)
    if filename:
        plt.savefig(filename)
    plt.show()
