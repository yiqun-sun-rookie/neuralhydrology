import torch


def rearrange_data(p, lead_time=120):
    """
    Rearranges the input tensor `p` to form batches based on the specified lead time.

    Args:
        p (torch.Tensor): Input tensor of shape [1, 1, num_timesteps].
        lead_time (int): The lead time for forming batches.

    Returns:
        torch.Tensor: Rearranged tensor of shape [feasible_timesteps, lead_time].
    """
    num_timesteps = p.size(2)
    feasible_timesteps = num_timesteps - lead_time + 1

    p = p.squeeze(0).squeeze(0)
    p_batches = torch.stack([p[t:t + lead_time] for t in range(feasible_timesteps)], dim=0)

    return p_batches
def rearrange_controls(controls, lead_time=120):
    """
    为了方便预报计算的批次，每一个时刻都要向后预报计算，逐个时段向后计算耗时很长，所以需要划分来提高效率。
    由于每一个时刻的预报是独立的（都是适用更新后的状态计算的），对于每一个时刻，lead_time=t的预报结果只依赖于lead_time=t-1，所以可以按lead_time来进行批量计算。
    假设有一个降水输入序列 [ 3, 2, 8, 5, 5, 2, 7]，对应的时间为[1, 2, 3, 4, 5, 6, 7]
    假设lead_time=0,1,2,3，那么可以按照如下方式划分：
    [3, 2, 8, 5, 5, 2, 7
     2, 8, 5, 5, 2, 7
     8, 5, 5, 2, 7
     5, 5, 2, 7
     5, 2, 7
     2, 7
     7
     其中第一列是每一个时刻lead_time=0计算需要用到的数据，第二列是lead_time=1的数据，以此类推。
     7 - 3 + 1 = 5 这是因为只有5个时间点有足够的数据进行完整的lead_time=3的预测
    这样划分之后，就可以按照lead_time来进行批量计算了，因为每一个lead_time中的feasible_timesteps是独立的（不同时刻，使用了不同的初始条件）。
    lead_time = 0时用的状态时滤波提供的，之后的状态是根据lead_time=0的状态计算的，lead_time=1的状态是根据lead_time=0的状态计算的，以此类推。

    Rearranges the input control tensor `controls` to form overlapping time windows based on the specified lead time.

    Args:
        controls (torch.Tensor): Input control tensor of shape [control_dim, T].
        lead_time (int): The lead time for forming overlapping time windows.

    Returns:
        torch.Tensor: Rearranged tensor of shape [control_dim, feasible_timesteps, lead_time].
    """
    control_dim, num_timesteps = controls.size()
    feasible_timesteps = num_timesteps - lead_time + 1

    if feasible_timesteps <= 0:
        raise ValueError("Lead time is too long for the given number of timesteps.")

    # Initialize the output tensor with zeros
    windowed_controls = torch.zeros(control_dim, feasible_timesteps, lead_time, dtype=controls.dtype, device=controls.device)

    # Populate the output tensor with the windows
    for i in range(feasible_timesteps):
        windowed_controls[:, i, :] = controls[:, i:i+lead_time]

    return windowed_controls

def rearrange_batched_controls(controls, lead_time=120):
    """
    为了方便预报计算的批次，每一个时刻都要向后预报计算，逐个时段向后计算耗时很长，所以需要划分来提高效率。
    由于每一个时刻的预报是独立的（都是适用更新后的状态计算的），对于每一个时刻，lead_time=t的预报结果只依赖于lead_time=t-1，所以可以按lead_time来进行批量计算。
    假设有一个降水输入序列 [ 3, 2, 8, 5, 5, 2, 7]，对应的时间为[1, 2, 3, 4, 5, 6, 7]
    假设lead_time=0,1,2,3，那么可以按照如下方式划分：
    [3, 2, 8, 5, 5, 2, 7
     2, 8, 5, 5, 2, 7
     8, 5, 5, 2, 7
     5, 5, 2, 7
     5, 2, 7
     2, 7
     7
     其中第一列是每一个时刻lead_time=0计算需要用到的数据，第二列是lead_time=1的数据，以此类推。
     7 - 3 + 1 = 5 这是因为只有5个时间点有足够的数据进行完整的lead_time=3的预测
    这样划分之后，就可以按照lead_time来进行批量计算了，因为每一个lead_time中的feasible_timesteps是独立的（不同时刻，使用了不同的初始条件）。
    lead_time = 0时用的状态时滤波提供的，之后的状态是根据lead_time=0的状态计算的，lead_time=1的状态是根据lead_time=0的状态计算的，以此类推。

    Rearranges the input control tensor `controls` to form overlapping time windows based on the specified lead time.

    Args:
        controls (torch.Tensor): Input control tensor of shape [batch_size, control_dim, T].
        lead_time (int): The lead time for forming overlapping time windows.

    Returns:
        torch.Tensor: Rearranged tensor of shape [batch_size, control_dim, feasible_timesteps, lead_time].
    """
    batch_size, control_dim, num_timesteps = controls.size()
    feasible_timesteps = num_timesteps - lead_time + 1

    if feasible_timesteps <= 0:
        raise ValueError("Lead time is too long for the given number of timesteps.")

    # Initialize the output tensor with zeros
    windowed_controls = torch.zeros(batch_size, control_dim, feasible_timesteps, lead_time, dtype=controls.dtype, device=controls.device)

    # Populate the output tensor with the windows
    for i in range(feasible_timesteps):
        windowed_controls[:, :, i, :] = controls[:, :, i:i+lead_time]

    return windowed_controls

# Example usage
p = torch.rand(1, 1, 10)  # Simulate some data
etpot = torch.rand(1, 1, 10)  # Simulate some data
print("p", p)
print("etpot", etpot)
controls = torch.cat([p, etpot], dim=1)
print("controls", controls)

p_arranged = rearrange_data(p, lead_time=5)
print("p_arranged_0", p_arranged)
# etpot_arranged = rearrange_data(etpot, lead_time=5)
# print("etpot_arranged", etpot_arranged)
# controls_arranged = rearrange_controls(controls, lead_time=5)
# print("controls_arranged", controls_arranged)


# controls = torch.rand(5, 2, 10)  # Simulate some data
# print(controls[4, 1, :])
windowed_controls = rearrange_batched_controls(controls, lead_time=5)
print("p_arranged_1", windowed_controls[0, 0, :, :])
print("lt=0", windowed_controls[0, 1, :, 0])
print("lt=1", windowed_controls[0, 1, :, 1])
print(windowed_controls.shape)
