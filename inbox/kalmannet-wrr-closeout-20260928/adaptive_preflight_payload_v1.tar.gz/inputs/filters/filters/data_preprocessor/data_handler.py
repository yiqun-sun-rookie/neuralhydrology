import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import os
import warnings
warnings.filterwarnings("ignore", category=FutureWarning)
class DataHandler:
    def __init__(self, file_path, start_date, end_date):
        self.file_path = file_path
        self.start_date = datetime.strptime(start_date, '%Y-%m-%d %H')
        self.end_date = datetime.strptime(end_date, '%Y-%m-%d %H')

    def load_and_filter_data(self):
        if not os.path.exists(self.file_path):
            raise FileNotFoundError(f"File not found: {self.file_path}")
        # 假设使用pandas读取和筛选数据
        df = pd.read_csv(self.file_path, delim_whitespace=True, parse_dates=['date'], date_parser=self.parse_date)
        df['date'] = pd.to_datetime(df['date'])
        filtered_df = df[(df['date'] >= self.start_date) & (df['date'] <= self.end_date)]
        return filtered_df

    def convert_time_to_hours(self, tm_series):
        # 转换时间为小时数
        return (tm_series - datetime(1970, 1, 1)).dt.total_seconds() / 3600

    def convert_hours_to_time(self, hours_series):
        """
        将自1970-01-01以来的小时数转换回日期时间序列。

        参数:
        ----------
        hours_series : array-like
            表示自1970-01-01以来的小时数（可以是列表、NumPy数组或Pandas Series）。

        返回:
        -------
        pd.Series
            对应的日期时间序列。

        示例:
        -------
        >>> data_handler = DataHandler('path/to/data.txt', '1999-01-01 01', '2010-01-03 01')
        >>> hours = pd.Series([0, 1, 2, 3])
        >>> data_handler.convert_hours_to_time(hours)
        0   1970-01-01 00:00:00
        1   1970-01-01 01:00:00
        2   1970-01-01 02:00:00
        3   1970-01-01 03:00:00
        dtype: datetime64[ns]
        """
        # 确保输入为Pandas Series
        if not isinstance(hours_series, pd.Series):
            hours_series = pd.Series(hours_series)

        # 使用 pd.to_datetime 进行转换
        datetime_series = pd.to_datetime(hours_series, unit='h', origin='unix')  # origin='unix'对应1970-01-01

        return datetime_series
    def split_data(self, p, etpot, qobs, tm_hours, ratios):
        # 根据给定的比例划分数据
        total_len = len(p)
        train_end = int(total_len * ratios[0])
        val_end = train_end + int(total_len * ratios[1])

        train_data = (p[:train_end], etpot[:train_end], qobs[:train_end], tm_hours[:train_end])
        val_data = (p[train_end:val_end], etpot[train_end:val_end], qobs[train_end:val_end], tm_hours[train_end:val_end])
        test_data = (p[val_end:], etpot[val_end:], qobs[val_end:], tm_hours[val_end:])
        return train_data, val_data, test_data

    def parse_date(self, date_str):
        """解析日期字符串，处理小时为'24'的情况转换为次日的'00'小时。"""
        try:
            return datetime.strptime(date_str, "%Y%m%d%H")
        except ValueError:
            if date_str.endswith("24"):
                date_without_hour = date_str[:-2]
                base_date = datetime.strptime(date_without_hour, "%Y%m%d")
                return base_date + timedelta(days=1)
            else:
                raise
# 使用DataHandler