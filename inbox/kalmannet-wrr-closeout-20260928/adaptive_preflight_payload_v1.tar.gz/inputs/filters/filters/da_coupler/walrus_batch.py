import torch

def fx_walrus_batch(sigmas, dt, sys_model=None, controls=None, device=None):
    """
    批量版的Walrus状态转移函数:
    - sigmas: (batch_size, num_sigmas, dim_x)
    - dt: 时间间隔(可用可不用, 取决于你的模型)
    - sys_model: WalrusTorch 模型, 其f(...)可接收 [batch*... , dim_x]
    - controls: (batch_size, 2)

    输出:
    - next_sigmas: (batch_size, num_sigmas, dim_x)
    """
    if device is None:
        device = sys_model.device
    batch_size, num_sigmas, dim_x = sigmas.shape

    # 1) reshape sigmas => 2D: [(batch_size * num_sigmas), dim_x]
    sigmas_2d = sigmas.view(batch_size * num_sigmas, dim_x)

    # 2) 同理, controls 需要复制 num_sigmas 份, 再堆叠
    #    原形状: (batch_size, 2) -> 先重复(num_sigmas,1), 再变成 (batch_size*num_sigmas, 2)
    #    repeat_interleave 是一种方法; 也可用 repeat + reshape
    controls_2d = controls.repeat_interleave(num_sigmas, dim=0)  # shape: (batch_size*num_sigmas, 2)

    # 转到正确设备和类型
    sigmas_2d = sigmas_2d.to(device)
    controls_2d = controls_2d.to(device)

    # 3) 调用WalrusTorch的 f(...) 做状态更新
    #    WalrusTorch.f(...) 期望 [batch_size2, dim_x], [batch_size2, 2]
    #    返回同样形状
    next_sigmas_2d = sys_model.f(sigmas_2d, controls_2d)

    # 4) reshape回到3D: (batch_size, num_sigmas, dim_x)
    next_sigmas_3d = next_sigmas_2d.view(batch_size, num_sigmas, dim_x)

    return next_sigmas_3d

def hx_walrus_batch(sigmas, sys_model=None, device=None):
    """
    批量版的Walrus观测函数:
    - sigmas: (batch_size, num_sigmas, dim_x)
    返回:
    - meas: (batch_size, num_sigmas, dim_z)
    """
    if device is None:
        device = sys_model.device
    batch_size, num_sigmas, dim_x = sigmas.shape

    # 1) reshape 到 2D
    sigmas_2d = sigmas.view(batch_size * num_sigmas, dim_x).to(device)

    # 2) 调用 sys_model.h, 得到 (batch_size * num_sigmas, dim_z)
    meas_2d = sys_model.h(sigmas_2d)

    # 3) reshape 回 (batch_size, num_sigmas, dim_z)
    dim_z = meas_2d.shape[1]
    meas_3d = meas_2d.view(batch_size, num_sigmas, dim_z)

    return meas_3d
