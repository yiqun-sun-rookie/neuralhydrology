import torch, torch.nn as nn, torch.nn.functional as F

import torch
import torch.nn as nn


class LearnableCov(nn.Module):
    """
    对角/满协方差的可学习对数参数化。

    init_diag 可以是:
        • 标量  → 所有对角同值
        • list/tuple/1‑D tensor → 每维单独初值
    """
    def __init__(self, dim, init_diag=1e-3, cov_type="diag"):
        super().__init__()
        self.dim = dim
        self.cov_type = cov_type

        # ---------- 关键：把任何输入转成 1‑D Tensor ----------
        vec = torch.as_tensor(init_diag, dtype=torch.float32)
        if vec.dim() == 0:                 # 标量 → repeat dim 次
            vec = vec.repeat(dim)
        elif vec.numel() != dim:           # 列表/张量长度校验
            raise ValueError(
                f"init_diag 长度 {vec.numel()} ≠ dim {dim}. "
                "若只想用标量请直接写 1e-3"
            )
        # ----------------------------------------------------

        # 用 log‑space 存储以保证协方差正定
        self.raw = nn.Parameter(torch.log(vec))   # [dim]
    def forward(self):
        diag = torch.exp(self.raw)            # [dim]
        if self.cov_type == "diag":
            return torch.diag(diag)           # [dim,dim]
        else:                                 # “full” 可扩展
            return torch.diag(diag)           # 先返回对角；后续可加低秩
