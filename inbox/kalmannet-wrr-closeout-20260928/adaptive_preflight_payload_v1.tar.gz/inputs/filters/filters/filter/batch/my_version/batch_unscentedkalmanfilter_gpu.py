import torch

class BatchUnscentedKalmanFilterGPU:
    def __init__(self, dim_x, dim_z, dt, hx, fx, points, batch_size, device=None):
        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device)
        self.dim_x = dim_x
        self.dim_z = dim_z
        self.dt = dt
        self.hx = hx  # measurement function
        self.fx = fx  # state transition function
        self.batch_size = batch_size

        # Initialize weights with float32
        self.Wm = torch.tensor(points.Wm, dtype=torch.float32, device=self.device)  # shape: (num_sigmas,)
        self.Wc = torch.tensor(points.Wc, dtype=torch.float32, device=self.device)  # shape: (num_sigmas,)
        self.c = points.c  # scaling factor

        # Initialize state vectors and covariance matrices for batch with float32
        self.x = torch.zeros(batch_size, dim_x, dtype=torch.float32, device=self.device)  # shape: (batch_size, dim_state)
        self.P = torch.eye(dim_x, dtype=torch.float32, device=self.device).unsqueeze(0).repeat(batch_size, 1, 1)
        self.Q = torch.eye(dim_x, dtype=torch.float32, device=self.device).unsqueeze(0).repeat(batch_size, 1, 1)
        self.R = torch.eye(dim_z, dtype=torch.float32, device=self.device).unsqueeze(0).repeat(batch_size, 1, 1)

    def predict(self, dt=None):
        if dt is None:
            dt = self.dt

        # Compute sigma points
        sigmas = batch_sigma_points(self.x, self.P, self.c)  # shape: (batch_size, num_sigmas, dim_state)

        # Pass sigma points through the state transition function fx
        sigmas_f = self.fx(sigmas, dt)  # shape: (batch_size, num_sigmas, dim_state)
        self.sigmas_f = sigmas_f

        # Compute predicted state mean x
        self.x = torch.einsum('bni,n->bi', sigmas_f, self.Wm)  # shape: (batch_size, dim_state)

        # Compute predicted state covariance P
        x_diff = sigmas_f - self.x.unsqueeze(1)  # shape: (batch_size, num_sigmas, dim_state)
        self.P = torch.einsum('n,bni,bnj->bij', self.Wc, x_diff, x_diff) + self.Q  # shape: (batch_size, dim_state, dim_state)

    def update(self, z):
        # batch_size, dim_obs = z.shape
        # dim_state = self.dim_state
        # num_sigmas = 2 * dim_state + 1

        # Compute sigma points
        sigmas = batch_sigma_points(self.x, self.P, self.c)  # shape: (batch_size, num_sigmas, dim_state)

        # Pass sigma points through the measurement function hx
        sigmas_h = self.hx(sigmas)  # shape: (batch_size, num_sigmas, dim_obs)

        # Compute predicted measurement mean z_pred
        z_pred = torch.einsum('bni,n->bi', sigmas_h, self.Wm)  # shape: (batch_size, dim_obs)

        # Compute measurement covariance S
        z_diff = sigmas_h - z_pred.unsqueeze(1)  # shape: (batch_size, num_sigmas, dim_obs)
        S = torch.einsum('n,bni,bnj->bij', self.Wc, z_diff, z_diff) + self.R  # shape: (batch_size, dim_obs, dim_obs)

        # Compute cross covariance Pxz
        x_diff = sigmas - self.x.unsqueeze(1)  # shape: (batch_size, num_sigmas, dim_state)
        Pxz = torch.einsum('n,bni,bnj->bij', self.Wc, x_diff, z_diff)  # shape: (batch_size, dim_state, dim_obs)

        # Compute Kalman gain K
        S_inv = torch.inverse(S)  # shape: (batch_size, dim_obs, dim_obs)
        K = torch.einsum('bij,bjk->bik', Pxz, S_inv)  # shape: (batch_size, dim_state, dim_obs)
        # print(K)
        # Update state mean x and covariance P
        y = z - z_pred  # shape: (batch_size, dim_obs)
        self.x = self.x + torch.einsum('bik,bk->bi', K, y)  # shape: (batch_size, dim_state)
        self.P = self.P - torch.einsum('bik,bkj->bij', K, torch.einsum('bij,bjk->bik', S, K.transpose(1, 2)))  # shape: (batch_size, dim_state, dim_state)

def batch_sigma_points(x, P, c):
    """
    批量生成 sigma 点。

    参数：
    - x: 均值张量，形状为 (batch_size, dim_state)
    - P: 协方差张量，形状为 (batch_size, dim_state, dim_state)
    - c: sigma 点缩放参数

    返回：
    - sigmas: sigma 点张量，形状为 (batch_size, 2 * dim_state + 1, dim_state)
    """
    batch_size, dim_x = x.shape
    num_sigmas = 2 * dim_x + 1
    device = x.device

    # [FIX] 数值稳定性处理：确保协方差矩阵正定
    P_scaled = P * c

    try:
        # 优先尝试无扰动分解，以保持最高精度
        U = torch.linalg.cholesky(P_scaled)
    except torch._C._LinAlgError:
        # 如果失败，则进入带扰动的重试逻辑
        jitter = 1e-6
        max_attempts = 3

        for attempt in range(max_attempts):
            try:
                # 添加对角线扰动项确保正定性
                if attempt > 0:
                    jitter *= 10  # 逐步增大jitter

                P_regularized = P_scaled + jitter * torch.eye(dim_x, device=device).unsqueeze(0)

                # 尝试Cholesky分解
                U = torch.linalg.cholesky(P_regularized)
                break  # 分解成功，跳出循环

            except torch._C._LinAlgError as e:
                if attempt == max_attempts - 1:
                    # 最后一次尝试：使用特征值分解作为fallback
                    print(f"[WARNING] Cholesky分解失败，使用SVD分解作为fallback (batch中可能有非正定矩阵)")
                    try:
                        # 使用SVD分解获得平方根矩阵
                        U_svd, S, Vh = torch.linalg.svd(P_regularized)
                        # 确保特征值为正
                        S = torch.clamp(S, min=jitter)
                        # 重构平方根矩阵: A = U @ diag(S) @ V^T, sqrt(A) = U @ diag(sqrt(S))
                        U = U_svd @ torch.diag_embed(torch.sqrt(S))
                    except Exception as svd_error:
                        # 极端情况：使用单位矩阵
                        print(f"[ERROR] SVD也失败了，使用单位矩阵作为最后的fallback: {svd_error}")
                        U = torch.eye(dim_x, device=device).unsqueeze(0) * 0.1
                else:
                    continue

    # 扩展 x，形状为 (batch_size, 1, dim_state)
    x = x.unsqueeze(1)

    # 初始化 sigma 点张量，形状为 (batch_size, num_sigmas, dim_state)
    sigmas = torch.zeros(batch_size, num_sigmas, dim_x, device=device)

    # 第一个 sigma 点是均值
    sigmas[:, 0, :] = x[:, 0, :]

    for k in range(dim_x):
        sigmas[:, k + 1, :] = x[:, 0, :] + U[:, :, k]
        sigmas[:, dim_x + k + 1, :] = x[:, 0, :] - U[:, :, k]

    return sigmas
