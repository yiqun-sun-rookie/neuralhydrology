# -*- coding: utf-8 -*-
"""
Stone Soup 滤波器集成模块。

Stone Soup 是英国国防科技实验室 (DSTL) 开发的专业追踪滤波框架，
提供丰富的滤波算法，包括 Kalman 系列、粒子滤波、PHD 滤波等。

GitHub: https://github.com/dstl/Stone-Soup
文档: https://stonesoup.readthedocs.io/

使用前请安装: pip install stonesoup

本模块提供统一的包装器接口，使 Stone Soup 滤波器与现有 FilterPy 
风格的 predict()/update() 接口保持一致。

支持的算法:
- KalmanFilter: 线性 Kalman 滤波器
- ExtendedKalmanFilter: 扩展 Kalman 滤波器
- UnscentedKalmanFilter: 无迹 Kalman 滤波器
- EnsembleKalmanFilter: 集合 Kalman 滤波器
- ParticleFilter: 粒子滤波器 (SIR)
- RegularisedParticleFilter: 正则化粒子滤波器

示例:
    from filters.filter.non_batch.stonesoup import StoneSoupUKF
    
    ukf = StoneSoupUKF(dim_x=4, dim_z=2, fx=my_fx, hx=my_hx, dt=1.0)
    ukf.x = initial_state
    ukf.P = initial_covariance
    
    for z in measurements:
        ukf.predict(controls=control_input)
        ukf.update(z)
        print(ukf.x)  # 后验状态估计
"""

from __future__ import absolute_import

# Stone Soup 风格的滤波器实现
# 注意：这些包装器实现了与 Stone Soup 相同的算法，
# 但使用独立实现以避免 Stone Soup 复杂的类验证系统。
# 提供与 FilterPy 一致的 predict()/update() 接口。

_HAS_STONESOUP = True  # 始终可用，因为是独立实现

from .wrappers import (
    StoneSoupKF,
    StoneSoupEKF,
    StoneSoupUKF,
    StoneSoupEnKF,
    StoneSoupParticleFilter,
    StoneSoupRegularisedPF,
)

__all__ = [
    "StoneSoupKF",
    "StoneSoupEKF",
    "StoneSoupUKF",
    "StoneSoupEnKF",
    "StoneSoupParticleFilter",
    "StoneSoupRegularisedPF",
    "_HAS_STONESOUP",
]


def available_algorithms():
    """返回可用的 Stone Soup 算法列表。"""
    if not _HAS_STONESOUP:
        return []
    return [
        "stonesoup_kf",
        "stonesoup_ekf",
        "stonesoup_ukf",
        "stonesoup_enkf",
        "stonesoup_pf",
        "stonesoup_rpf",
    ]

