"""
Vendored copy of DAPPER (Data Assimilation with Python Experiments).

This package proxies the original `dapper` module so it can be imported as
`filters.filter.non_batch.dapper` while continuing to expose all upstream
subpackages (e.g. `mods`, `tools`, `xp_launch`, ...).
"""

from importlib import import_module as _import_module
from typing import Any
import sys as _sys

_UPSTREAM = _import_module(f"{__name__}.dapper")

# Expose vendored DAPPER also as top-level package name ``dapper`` so that
# upstream-style imports like ``import dapper.tools.remote.uplink`` keep working.
_sys.modules.setdefault("dapper", _UPSTREAM)

__doc__ = _UPSTREAM.__doc__
__file__ = _UPSTREAM.__file__
__package__ = __name__
__path__ = _UPSTREAM.__path__
__version__ = getattr(_UPSTREAM, "__version__", "0.0")

if hasattr(_UPSTREAM, "__all__"):
    __all__ = list(_UPSTREAM.__all__)  # type: ignore[attr-defined]
else:
    __all__ = [name for name in dir(_UPSTREAM) if not name.startswith("_")]


def __getattr__(name: str) -> Any:
    """Forward attribute lookups to the upstream DAPPER package."""
    return getattr(_UPSTREAM, name)


def __dir__() -> list[str]:
    """Ensure `dir(filters.filter.non_batch.dapper)` mirrors the upstream package."""
    return sorted(set(globals()) | set(dir(_UPSTREAM)))

