"""
Bridge utilities between WalrusTorch models and DAPPER experiments.

This module builds DAPPER-friendly HMM configurations from Walrus
systems, and provides helpers to run xp classes (LETKF, EnKS, etc.)
directly on those HMMs from within the filters project.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, replace
from typing import Callable, Dict, Optional, Tuple

import numpy as np
import torch
from torch.autograd.functional import jacobian as torch_jacobian

import filters.filter.non_batch.dapper.dapper as _embedded_dapper
from filters.system_models.nonlinear.hydrological.walrus.walrus_torch import WalrusTorch

# Ensure vendored DAPPER is registered under the canonical top-level name
sys.modules.setdefault("dapper", _embedded_dapper)

from dapper.mods import HiddenMarkovModel, Operator, TimeDependentOperator
from dapper.mods.utils import ens_compatible
from dapper.tools.chronos import Chronology
from dapper.tools.localization import no_localization
from dapper.tools.randvars import GaussRV
from dapper.tools.seeding import rng, set_seed


@dataclass
class WalrusHMMConfig:
    """Configuration required to build a Walrus-based DAPPER HMM."""

    controls: np.ndarray  # shape (T, 2)
    observations: np.ndarray  # shape (T,)
    truth_states: np.ndarray  # shape (T, dim_x)
    model_params: Dict[str, float]
    dt: float = 1.0
    process_noise_scale: float = 0.1
    obs_noise_scale: float = 0.001
    initial_state: Optional[np.ndarray] = None
    seed: Optional[int] = None


def _build_walrus_model(
    params: Dict[str, float], initial_state: np.ndarray
) -> WalrusTorch:
    device = torch.device("cpu")
    return WalrusTorch(
        cw=params["cw"],
        cv=params["cv"],
        cg=params["cg"],
        cq=params["cq"],
        cd=params["cd"],
        cs=params["cs"],
        initial_state=torch.tensor(initial_state, dtype=torch.float32, device=device),
    ).to(device)


def _ensure_batch(x: np.ndarray, state_dim: int) -> Tuple[torch.Tensor, bool]:
    arr = np.asarray(x, dtype=float)
    was_vector = arr.ndim == 1
    if was_vector:
        arr = arr.reshape(1, -1)
    if arr.shape[1] != state_dim and arr.shape[0] == state_dim:
        arr = arr.T
    if arr.shape[1] != state_dim:
        raise ValueError(
            f"Expected array with second dimension {state_dim}, got {arr.shape}"
        )
    tensor = torch.as_tensor(arr, dtype=torch.float32)
    return tensor, was_vector


def _finite_difference_jacobian(
    func: Callable[[np.ndarray], np.ndarray], state_vec: np.ndarray, eps: float = 1e-4
) -> np.ndarray:
    base = np.asarray(func(state_vec), dtype=float).ravel()
    dim_out = base.size
    dim_in = state_vec.size
    jac = np.zeros((dim_out, dim_in), dtype=float)
    for idx in range(dim_in):
        perturbed = state_vec.copy()
        perturbed[idx] += eps
        diff = np.asarray(func(perturbed), dtype=float).ravel() - base
        jac[:, idx] = diff / eps
    return jac


def build_walrus_hmm(
    cfg: WalrusHMMConfig,
) -> Tuple[HiddenMarkovModel, np.ndarray, np.ndarray]:
    """
    Construct a DAPPER HiddenMarkovModel together with truth/observation arrays.
    """

    controls = np.asarray(cfg.controls, dtype=float)
    obs = np.asarray(cfg.observations, dtype=float)
    truth = np.asarray(cfg.truth_states, dtype=float)

    assert len(controls) == len(obs) == len(
        truth
    ), "Controls/obs/truth must have equal length."
    num_steps = len(controls)
    if num_steps < 2:
        raise ValueError("Need at least two time steps to build an HMM.")

    state0 = (
        truth[0].copy()
        if cfg.initial_state is None
        else np.asarray(cfg.initial_state, dtype=float)
    )

    if cfg.seed is not None:
        set_seed(cfg.seed)

    walrus_model = _build_walrus_model(cfg.model_params, state0.copy())
    dim_x = state0.size
    device = getattr(walrus_model.dv_lb, "device", torch.device("cpu"))

    def _control_for_time(t_val: float) -> np.ndarray:
        step = int(round(float(t_val) / cfg.dt))
        ctrl_idx = max(0, min(step - 1, num_steps - 1))
        return controls[ctrl_idx]

    def _eval_dyn_numpy(state_vec: np.ndarray, ctrl_vec: np.ndarray) -> np.ndarray:
        state_t = torch.as_tensor(state_vec, dtype=torch.float32, device=device).unsqueeze(0)
        ctrl_t = torch.as_tensor(ctrl_vec, dtype=torch.float32, device=device).unsqueeze(0)
        with torch.no_grad():
            return walrus_model.f(state_t, ctrl_t).squeeze(0).cpu().numpy()

    def _eval_obs_numpy(state_vec: np.ndarray) -> np.ndarray:
        state_t = torch.as_tensor(state_vec, dtype=torch.float32, device=device).unsqueeze(0)
        with torch.no_grad():
            return walrus_model.h(state_t).squeeze(0).cpu().numpy()

    def _autograd_jacobian(
        state_vec: np.ndarray, ctrl_vec: Optional[np.ndarray], mode: str
    ) -> np.ndarray:
        state_tensor = torch.as_tensor(
            state_vec, dtype=torch.float32, device=device
        ).requires_grad_(True)

        if mode == "dyn":
            assert ctrl_vec is not None
            ctrl_tensor = torch.as_tensor(ctrl_vec, dtype=torch.float32, device=device)

            def func(st: torch.Tensor) -> torch.Tensor:
                return walrus_model.f(st.unsqueeze(0), ctrl_tensor.unsqueeze(0)).squeeze(0)

        else:

            def func(st: torch.Tensor) -> torch.Tensor:
                return walrus_model.h(st.unsqueeze(0)).squeeze(0)

        jac = torch_jacobian(func, state_tensor, create_graph=False)
        return jac.detach().cpu().numpy()

    def _state_jacobian(
        state_vec: np.ndarray, ctrl_vec: Optional[np.ndarray], mode: str
    ) -> np.ndarray:
        state_vec = np.asarray(state_vec, dtype=float).reshape(-1)
        try:
            if mode == "dyn" and hasattr(walrus_model, "linearize_f"):
                jac_t = walrus_model.linearize_f(state_vec, ctrl_vec)
                return np.atleast_2d(jac_t.detach().cpu().numpy())
            if mode == "obs" and hasattr(walrus_model, "linearize_h"):
                jac_t = walrus_model.linearize_h(state_vec)
                return np.atleast_2d(jac_t.detach().cpu().numpy())
        except Exception:
            pass
        try:
            jac = _autograd_jacobian(state_vec, ctrl_vec, mode)
        except RuntimeError:
            if mode == "dyn":
                jac = _finite_difference_jacobian(
                    lambda s: _eval_dyn_numpy(s, ctrl_vec), state_vec
                )
            else:
                jac = _finite_difference_jacobian(_eval_obs_numpy, state_vec)
        return np.atleast_2d(jac)

    @ens_compatible
    def dyn_model(x, t, dt):
        ctrl_vec = _control_for_time(t)

        x_torch, was_vector = _ensure_batch(x, state0.size)
        ctrl = torch.as_tensor(ctrl_vec, dtype=torch.float32).unsqueeze(0)
        ctrl = ctrl.expand(x_torch.shape[0], -1)

        with torch.no_grad():
            next_state = walrus_model.f(x_torch, ctrl).cpu().numpy()
        if was_vector:
            return next_state[0]
        return next_state.T

    @ens_compatible
    def obs_model(x):
        x_torch, was_vector = _ensure_batch(x, state0.size)
        with torch.no_grad():
            z = walrus_model.h(x_torch).cpu().numpy()
        if was_vector:
            return z[0]
        return z.T

    def dyn_linear(x, t, dt):
        state_vec = np.asarray(x, dtype=float)
        ctrl_vec = _control_for_time(t)
        return _state_jacobian(state_vec, ctrl_vec, mode="dyn")

    def obs_linear(x):
        state_vec = np.asarray(x, dtype=float)
        return _state_jacobian(state_vec, None, mode="obs")

    Q = np.eye(state0.size) * cfg.process_noise_scale
    R = np.eye(1) * cfg.obs_noise_scale
    dyn_noise = 0 if np.allclose(Q, 0.0) else Q

    Dyn = Operator(M=state0.size, model=dyn_model, noise=dyn_noise, linear=dyn_linear)
    Obs = TimeDependentOperator(
        M=1,
        model=obs_model,
        noise=R,
        localizer=no_localization(state0.size, 1),
        linear=obs_linear,
    )

    K = num_steps - 1
    tseq = Chronology(dt=cfg.dt, dko=1, K=K)
    X0 = GaussRV(C=Q, mu=state0)

    hmm = HiddenMarkovModel(Dyn=Dyn, Obs=Obs, tseq=tseq, X0=X0)

    yy = np.empty(tseq.Ko + 1, dtype=object)
    for ko in range(tseq.Ko + 1):
        obs_idx = (ko + 1) * tseq.dko
        obs_idx = min(obs_idx, len(obs) - 1)
        yy[ko] = np.array([obs[obs_idx]], dtype=float)

    return hmm, truth, yy


def run_dapper_experiment(xp_class, cfg: WalrusHMMConfig, xp_kwargs: Optional[Dict] = None):
    """
    Execute a DAPPER experiment class (LETKF, Var4D, etc.) on Walrus data.
    Returns the xp instance after assimilation.
    """

    xp_kwargs = xp_kwargs or {}
    hmm, truth, yy = build_walrus_hmm(cfg)
    xp_instance = xp_class(**xp_kwargs)
    xp_instance.assimilate(hmm, truth, yy)
    return xp_instance


def extract_mean_trajectory(stats, prefer_series: str = "a") -> np.ndarray:
    """
    Helper to pull the mean trajectory from a DAPPER stats object.
    `prefer_series` can be 'a', 'f', 's', or 'u'.
    """

    if stats is None or not hasattr(stats, "mu"):
        raise ValueError("Stats object missing `mu` series.")

    series = getattr(stats.mu, prefer_series, None)
    if series is None or np.all(np.isnan(series)):
        series = stats.mu.a
    return np.asarray(series, dtype=float)

