# -*- coding: utf-8 -*-
"""
ETKF - 集合转换 Kalman 滤波器

单步实现，支持 predict()/update() 接口。

参考文献:
- Bishop et al. (2001): Adaptive Sampling with the Ensemble Transform Kalman Filter
- Hunt et al. (2007): Efficient Data Assimilation for Spatiotemporal Chaos
"""

from __future__ import annotations

from typing import Callable, Optional

import numpy as np
from scipy.linalg import sqrtm, svd


class ETKF:
    """
    集合转换 Kalman 滤波器 (Ensemble Transform Kalman Filter)。
    
    ETKF 使用确定性的集合转换来更新集合成员，避免了传统 EnKF 
    中的扰动观测带来的采样误差。
    
    参数
    ----------
    dim_x : int
        状态维度
    dim_z : int
        观测维度
    fx : callable
        状态转移函数 fx(x, dt, controls=None) -> x_next
    hx : callable
        观测函数 hx(x) -> z
    N : int
        集合成员数量，默认 20
    dt : float
        时间步长，默认 1.0
    infl : float
        膨胀因子，默认 1.02
    rot : bool
        是否使用随机旋转，默认 True
    Q : ndarray, optional
        过程噪声协方差
    R : ndarray, optional
        观测噪声协方差
    x0 : ndarray, optional
        初始状态均值
    P0 : ndarray, optional
        初始状态协方差
    
    示例
    --------
    >>> etkf = ETKF(dim_x=4, dim_z=1, fx=my_fx, hx=my_hx, N=30)
    >>> etkf.predict(controls=ctrl)
    >>> etkf.update(z)
    >>> print(etkf.x)  # 后验均值
    """
    
    def __init__(
        self,
        dim_x: int,
        dim_z: int,
        fx: Callable,
        hx: Callable,
        N: int = 20,
        dt: float = 1.0,
        infl: float = 1.02,
        rot: bool = True,
        Q: Optional[np.ndarray] = None,
        R: Optional[np.ndarray] = None,
        x0: Optional[np.ndarray] = None,
        P0: Optional[np.ndarray] = None,
    ):
        self.dim_x = dim_x
        self.dim_z = dim_z
        self.N = N
        self.dt = dt
        self.infl = infl
        self.rot = rot
        self._fx = fx
        self._hx = hx
        
        # 噪声协方差
        self.Q = Q if Q is not None else np.eye(dim_x) * 0.1
        self.R = R if R is not None else np.eye(dim_z) * 0.1
        
        # 初始化集合
        x0 = x0 if x0 is not None else np.zeros(dim_x)
        P0 = P0 if P0 is not None else np.eye(dim_x)
        
        x0 = np.asarray(x0, dtype=float).reshape(-1)
        P0 = np.asarray(P0, dtype=float)
        self.Q = np.asarray(self.Q, dtype=float)
        self.R = np.asarray(self.R, dtype=float)
        
        # 集合矩阵: (dim_x, N)
        self.E = np.random.multivariate_normal(x0, P0, N).T
    
    @property
    def x(self) -> np.ndarray:
        """集合均值（后验状态估计）。"""
        return self.E.mean(axis=1)
    
    @x.setter
    def x(self, value: np.ndarray):
        """设置均值（保持散布）。"""
        mean = self.E.mean(axis=1, keepdims=True)
        self.E = self.E - mean + np.asarray(value).reshape(-1, 1)
    
    @property
    def P(self) -> np.ndarray:
        """集合协方差。"""
        A = self._anomalies()
        return A @ A.T / (self.N - 1)
    
    @P.setter
    def P(self, value: np.ndarray):
        """通过重采样设置协方差。"""
        mean = self.x
        self.E = np.random.multivariate_normal(mean, value, self.N).T
    
    def _anomalies(self) -> np.ndarray:
        """计算集合异常 (anomalies)。"""
        mean = self.E.mean(axis=1, keepdims=True)
        return self.E - mean
    
    def predict(self, controls: Optional[np.ndarray] = None, **kwargs):
        """
        预测步：传播集合成员。
        
        参数
        ----------
        controls : ndarray, optional
            控制输入
        """
        ctrl = controls if controls is not None else kwargs.get("controls")
        
        # 传播每个集合成员
        for i in range(self.N):
            if ctrl is not None:
                self.E[:, i] = self._fx(self.E[:, i], self.dt, controls=ctrl)
            else:
                self.E[:, i] = self._fx(self.E[:, i], self.dt)
        
        # 添加过程噪声（可选，通过膨胀实现）
        if np.any(self.Q > 0):
            for i in range(self.N):
                self.E[:, i] += np.random.multivariate_normal(
                    np.zeros(self.dim_x), self.Q
                )
        
        # 膨胀
        if self.infl != 1.0:
            mean = self.E.mean(axis=1, keepdims=True)
            self.E = mean + self.infl * (self.E - mean)
    
    def update(self, z: np.ndarray, **kwargs):
        """
        更新步：集合转换。
        
        参数
        ----------
        z : ndarray
            观测值
        """
        z = np.asarray(z, dtype=float).reshape(-1)
        
        # 数值稳定性检查
        if not np.all(np.isfinite(self.E)):
            # 重置为均值附近
            mean = np.nanmean(self.E, axis=1)
            mean = np.where(np.isfinite(mean), mean, 0.0)
            self.E = np.random.randn(self.dim_x, self.N) * 0.01 + mean.reshape(-1, 1)
        
        # 计算观测集合
        Y = np.zeros((self.dim_z, self.N))
        for i in range(self.N):
            y_i = np.asarray(self._hx(self.E[:, i]), dtype=float).reshape(-1)
            Y[:, i] = np.where(np.isfinite(y_i), y_i, 0.0)
        
        # 观测异常
        y_mean = Y.mean(axis=1, keepdims=True)
        S = Y - y_mean  # (dim_z, N)
        
        # 创新
        d = z.reshape(-1, 1) - y_mean  # (dim_z, 1)
        
        # 状态异常
        A = self._anomalies()  # (dim_x, N)
        
        # 检查异常是否有效
        if not np.all(np.isfinite(A)) or np.linalg.norm(A) < 1e-12:
            return  # 跳过更新
        
        # ETKF 更新
        # 参考: Hunt et al. (2007)
        try:
            R_inv = np.linalg.inv(self.R + 1e-6 * np.eye(self.dim_z))
        except np.linalg.LinAlgError:
            R_inv = np.linalg.pinv(self.R)
        
        # C = S^T R^{-1} S / (N-1)
        C = S.T @ R_inv @ S / (self.N - 1)
        
        # 添加正则化
        C = C + 1e-6 * np.eye(self.N)
        
        # Pa_tilde = (I + C)^{-1}
        I = np.eye(self.N)
        try:
            Pa_tilde = np.linalg.inv(I + C)
        except np.linalg.LinAlgError:
            Pa_tilde = np.linalg.pinv(I + C)
        
        # 转换矩阵 T = sqrt(Pa_tilde)
        T = self._matrix_sqrt(Pa_tilde)
        
        # 检查 T 是否有效
        if not np.all(np.isfinite(T)):
            T = np.eye(self.N) * 0.9  # 收缩
        
        # 随机旋转（可选）
        if self.rot:
            T = T @ self._random_orthogonal(self.N)
        
        # 更新权重
        # w = Pa_tilde @ S^T @ R^{-1} @ d / (N-1)
        w = Pa_tilde @ S.T @ R_inv @ d / (self.N - 1)
        
        # 限制权重
        w = np.clip(w, -10, 10)
        
        # 更新集合
        mean = self.E.mean(axis=1, keepdims=True)
        E_new = mean + A @ w + A @ T
        
        # 最终检查
        if np.all(np.isfinite(E_new)):
            self.E = E_new
    
    def _matrix_sqrt(self, A: np.ndarray) -> np.ndarray:
        """计算对称正定矩阵的平方根。"""
        try:
            return np.real(sqrtm(A))
        except Exception:
            # SVD 回退
            U, s, Vt = svd(A)
            return U @ np.diag(np.sqrt(np.maximum(s, 0))) @ Vt
    
    def _random_orthogonal(self, n: int) -> np.ndarray:
        """生成随机正交矩阵。"""
        H = np.random.randn(n, n)
        Q, _ = np.linalg.qr(H)
        return Q


__all__ = ["ETKF"]

