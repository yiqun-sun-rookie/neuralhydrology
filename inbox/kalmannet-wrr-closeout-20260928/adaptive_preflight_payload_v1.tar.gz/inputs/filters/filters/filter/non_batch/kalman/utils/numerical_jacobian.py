import numpy as np
def numerical_jacobian(fun, x, args=(), eps=1e-5):
    """
    在 x 点，对 fun(x, *args) 做数值微分 (中心差分)，返回 Jacobian。

    参数
    ----------
    fun : callable
        接受 (n,) + *args -> (m,) 的函数。
    x : ndarray of shape (n,)
        要在此点上近似求导的输入向量。
    args : tuple
        额外传给 fun(...) 的参数。
    eps : float, optional
        差分步长，默认 1e-5。

    返回
    ----------
    J : ndarray of shape (m, n)
        fun 在 x 处的 Jacobian 矩阵。
    """
    x0 = np.asarray(x, dtype=float)
    f0 = fun(x0, *args)   # shape=(m,)
    m = f0.shape[0]
    n = x0.shape[0]
    J = np.zeros((m, n), dtype=float)

    for j in range(n):
        # +eps
        x0[j] += eps
        f_plus = fun(x0, *args)
        x0[j] -= eps  # 恢复

        # -eps
        x0[j] -= eps
        f_minus = fun(x0, *args)
        x0[j] += eps  # 恢复

        # 差分
        J[:, j] = (f_plus - f_minus) / (2.0 * eps)

    return J
