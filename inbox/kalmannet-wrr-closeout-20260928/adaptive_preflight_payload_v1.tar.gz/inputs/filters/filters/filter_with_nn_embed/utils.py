import torch
import numpy as np
from pyDOE import lhs
import matplotlib.pyplot as plt
import seaborn as sns  # 导入 Seaborn
sns.set_style("darkgrid")




def plot_comparison(y_obs, sequences, batch_i):
    """
    绘制特定批次中 y_obs 和多个 sequences 的对比图，并在图例中显示 NSE。

    参数:
    - y_obs (torch.Tensor): 真实观测值，形状为 (batch_size, num_features, seq_len)
    - sequences (dict or list of torch.Tensor): 包含多个序列的字典或列表
        - 如果是字典，键为序列名称，值为对应的张量
        - 如果是列表，函数将自动生成序列名称
    - batch_i (int): 要比较的批次索引
    """
    # 确保 batch_i 在有效范围内
    assert 0 <= batch_i < y_obs.shape[0], "batch_i 超出范围"

    # 提取特定批次的 y_obs 数据
    y_obs_batch = y_obs[batch_i]  # 形状: (num_features, seq_len)

    # 初始化序列数据字典
    sequences_data = {}

    if isinstance(sequences, dict):
        # 序列为字典，键为名称
        for name, tensor in sequences.items():
            assert tensor.shape[0] == y_obs.shape[0], f"序列 '{name}' 的 batch_size 不匹配 y_obs"
            sequences_data[name] = tensor[batch_i]
    elif isinstance(sequences, list):
        # 序列为列表，自动生成序列名称
        for idx, tensor in enumerate(sequences, start=1):
            name = f'Sequence {idx}'
            assert tensor.shape[0] == y_obs.shape[0], f"序列 '{name}' 的 batch_size 不匹配 y_obs"
            sequences_data[name] = tensor[batch_i]
    else:
        raise TypeError("sequences 参数必须是字典或列表")

    # 转换数据为 NumPy
    y_obs_batch = y_obs_batch.cpu() if y_obs_batch.is_cuda else y_obs_batch
    sequences_np = {name: (tensor.cpu().detach().numpy() if tensor.is_cuda else tensor.detach().numpy())
                   for name, tensor in sequences_data.items()}
    y_obs_np = y_obs_batch.detach().numpy()

    num_features, seq_len = y_obs_np.shape
    time_steps = np.arange(seq_len)

    # 设置绘图风格
    try:
        sns.set_style("darkgrid")  # 使用 Seaborn 样式
    except Exception as e:
        print(f"警告：无法设置 Seaborn 样式，使用默认 Matplotlib 样式。错误信息：{e}")

    fig, axs = plt.subplots(num_features, 1, figsize=(12, 4 * num_features), sharex=True)

    # 如果只有一个特征，axs 不是列表，需要转换为列表
    if num_features == 1:
        axs = [axs]

    # 定义颜色和标记列表
    colors = plt.cm.get_cmap('tab10').colors  # 使用 Tab10 颜色映射
    markers = ['o', 'x', '^', 's', 'D', 'v', '*', 'P', 'h', '+']  # 定义标记样式

    # 计算 NSE 并存储
    nse_values = {}

    # 计算所有序列的 NSE
    for name, data in sequences_np.items():
        nse_per_feature = []
        for f in range(num_features):
            nse = calculate_nse(y_obs_np[f], data[f])
            nse_per_feature.append(nse)
        # 取平均 NSE，忽略 NaN 值
        average_nse = np.nanmean(nse_per_feature)
        nse_values[name] = average_nse

    # 绘制 y_obs
    for f in range(num_features):
        axs[f].plot(time_steps, y_obs_np[f], label='y_obs', marker='o', linestyle='-', color='black')

    # 绘制所有其他序列，并在标签中包含 NSE
    for idx, (name, data) in enumerate(sequences_np.items()):
        color = colors[idx % len(colors)]
        marker = markers[idx % len(markers)]
        nse = nse_values[name]
        label_with_nse = f"{name} (NSE: {nse:.3f})"
        for f in range(num_features):
            axs[f].plot(time_steps, data[f], label=label_with_nse, marker=marker, linestyle='--', color=color)
        # To avoid duplicate labels in legend, we break after the first feature
        if num_features > 1:
            axs[0].plot([], [], label=label_with_nse, color=color, linestyle='--', marker=marker)

    # 添加图例、标签和标题
    for f in range(num_features):
        axs[f].set_ylabel(f'Feature {f + 1}')
        axs[f].legend(loc='upper right')
        axs[f].set_title(f'Batch {batch_i}, Feature {f + 1} Comparison')

    axs[-1].set_xlabel('Time Step')
    plt.tight_layout()
    plt.show()

    # 打印 NSE 值
    print(f"NSE Values for Batch {batch_i}:")
    for name, nse in nse_values.items():
        print(f" - {name}: NSE = {nse:.3f}")

def calculate_nse(observed, predicted):
    """
    计算 Nash-Sutcliffe Efficiency (NSE)。

    参数:
    - observed (np.ndarray): 观测值数组。
    - predicted (np.ndarray): 预测值数组。

    返回:
    - float: 计算得到的 NSE 值。
    """
    observed = np.array(observed)
    predicted = np.array(predicted)

    numerator = np.sum((observed - predicted) ** 2)
    denominator = np.sum((observed - np.mean(observed)) ** 2)

    nse = 1 - (numerator / denominator)
    return nse


def prepare_batch_data(batch, device):
    p = batch['p'].to(device)
    ep = batch['etpot'].to(device)
    y_obs = batch['qobs'].to(device)
    state0 = batch['state0'].to(device)
    return p, ep, y_obs, state0

def get_randomized_initial_state(self, sys_model, batch_size):
        # 返回随机的初始状态
        lower_bounds = torch.tensor([5.0, 5.0, 0.0, 5.0, 0.0])
        upper_bounds = torch.tensor([500.0, 2450.0, 20.0, 5000.0, 5.0])
        state0_tmp = sys_model.m1x_0.reshape(1, sys_model.m, 1).repeat(batch_size, 1, 1)
        return latin_hypercube_sampling(batch_size, sys_model.m1x_0.size(0), lower_bounds, upper_bounds).to(state0_tmp.dtype).squeeze(-1)

def get_fixed_initial_state(self, sys_model, batch_size):
    """
    使用 sys_model.m1x_0 初始化状态，对所有样本都是相同的初始值。
    假设 sys_model.m1x_0 的形状是 [m, 1]。
    通过 repeat 扩展到 [batch_size, m, 1]，然后再 squeeze 得到 [batch_size, m]。
    """
    state0_tmp = sys_model.m1x_0.reshape(1, sys_model.m, 1).repeat(batch_size, 1, 1)
    state0_batch = state0_tmp.squeeze(-1)  # 得到 [batch_size, m]
    return state0_batch

def latin_hypercube_sampling(num_samples, num_dimensions, lower_bounds, upper_bounds):
    # 生成拉丁超立方抽样样本
    lhc_samples = lhs(num_dimensions, samples=num_samples)

    # 将[0, 1]区间的样本映射到实际的参数范围
    range_tensor = upper_bounds - lower_bounds
    scaled_samples = torch.tensor(lhc_samples) * range_tensor + lower_bounds

    return scaled_samples

import os
def set_cpu_threads_by_percentage(percentage):
    # 获取系统的总CPU核心数
    total_cpu = os.cpu_count()

    # 计算基于百分比的线程数
    num_threads = max(1, int(total_cpu * percentage / 100))

    # 设置PyTorch使用的线程数
    torch.set_num_threads(num_threads)

    print(f"Setting PyTorch to use {num_threads} threads ({percentage}% of {total_cpu} CPU cores).")


# 例如，设置PyTorch使用50%的CPU核心
set_cpu_threads_by_percentage(50)
