import torch

def compute_train_loss(pred, obs, metric='mse', lead_times=None, reduction='mean'):
    """
    返回一个标量，用于 backward().
    metric: 'mse'/'l1'/'nse'/'nse_global'
    lead_times: None 或 list[int]
    reduction: 'mean'/'sum'
    """
    if metric.lower() == 'mse':
        loss_map = mse_map(pred, obs)
    elif metric.lower() == 'l1':
        loss_map = l1_map(pred, obs)
    elif metric.lower() == 'nse':
        # 逐 lead_time (1-NSE) => shape=[batch_size, lead_time]
        loss_map = nse_map(pred, obs)
    elif metric.lower() == 'nse_global':
        # 整体 (1-NSE)，把所有 (batch x lead_time) 展开
        loss_map = nse_global_map(pred, obs)
    else:
        raise ValueError(f"不支持的训练损失类型: {metric}")

    # 最后对 loss_map 做 reduce
    return reduce_loss_map(loss_map, lead_times=lead_times, reduction=reduction)

# ----------------------------
# 1) 逐元素(逐 lead_time)误差计算
# ----------------------------
def mse_map(pred, obs):
    """(pred - obs)^2, shape同 pred,obs => [batch_size, lead_time]."""
    return (pred - obs) ** 2


def l1_map(pred, obs):
    """|pred - obs|, shape同 pred,obs => [batch_size, lead_time]."""
    return torch.abs(pred - obs)

def nse_global_map(pred, obs, eps=1e-8):
    """
    计算(1 - NSE)，把 pred, obs 所有维度 (batch_size x lead_time) 展开后整体计算。
    返回 shape=[batch_size, lead_time]，其中每个元素都相同(=标量)，
    以便与 reduce_loss_map 保持一致 (它期望 [batch_size, lead_time] 形状)。
    """
    # 1) 展开到一维
    #    pred, obs => [batch_size, lead_time]
    pred_flat = pred.reshape(-1)  # => [B*L]
    obs_flat  = obs.reshape(-1)   # => [B*L]

    # 2) 全局 mean(obs)
    obs_mean = obs_flat.mean()

    # 3) (1-NSE) = numerator/denominator
    numerator   = torch.sum((obs_flat - pred_flat)**2)
    denominator = torch.sum((obs_flat - obs_mean)**2) + eps
    nse_global  = numerator / denominator  # => 标量 (1-NSE)

    # 4) 为了后续能用 reduce_loss_map，返回与 pred 同形状 [batch_size, lead_time]。
    #    大小相同的每个元素都= nse_global
    return nse_global.unsqueeze(0).expand_as(pred)

def nse_map(pred, obs, eps=1e-8):
    """
    计算(1-NSE)的逐 lead_time 误差图。最终返回 shape = [batch_size, lead_time]。
    """
    # obs_mean => [1, lead_time]
    obs_mean = obs.mean(dim=0, keepdim=True)
    # numerator => sum_{batch}((obs - pred)^2) => shape=[lead_time]
    numerator = ((obs - pred) ** 2).sum(dim=0)
    # denominator => sum_{batch}((obs - obs_mean)^2) => shape=[lead_time]
    denominator = ((obs - obs_mean) ** 2).sum(dim=0) + eps
    # nse_loss_lt => numerator / denominator => shape=[lead_time]
    nse_loss_lt = numerator / denominator  # 这是(1 - NSE)数值

    # 将 [lead_time] 广播回 [batch_size, lead_time]
    return nse_loss_lt.unsqueeze(0).expand_as(obs)


# -------------------------------------
# 2) 将逐元素误差图 reduce 成标量loss
# -------------------------------------
def reduce_loss_map(loss_map, lead_times=None, reduction='mean'):
    """
    选择性只对特定 lead_times 的误差做统计，并最终聚合成标量。

    lead_times: None 或 list[int]
      - None 表示使用全部列
      - list 表示按列索引取
    reduction: 'mean' or 'sum'
    """
    if lead_times is not None:
        # 注意是否0-based索引
        loss_map = loss_map[:, lead_times]

    if reduction == 'mean':
        return loss_map.mean()
    elif reduction == 'sum':
        return loss_map.sum()
    else:
        raise ValueError(f"Unsupported reduction mode: {reduction}")


# -------------------------------------
# 3) 训练时调用的主函数
# -------------------------------------
def compute_train_loss(pred, obs, metric='mse', lead_times=None, reduction='mean'):
    """
    返回一个标量，用于 backward().
    metric: 'mse'/'l1'/'nse'/'nse_global'
    lead_times: None 或 list[int]
    reduction: 'mean'/'sum'
    """
    if metric.lower() == 'mse':
        loss_map = mse_map(pred, obs)
    elif metric.lower() == 'l1':
        loss_map = l1_map(pred, obs)
    elif metric.lower() == 'nse':
        # 逐 lead_time (1-NSE) => shape=[batch_size, lead_time]
        loss_map = nse_map(pred, obs)
    elif metric.lower() == 'nse_global':
        # 整体 (1-NSE)，把所有 (batch x lead_time) 展开
        loss_map = nse_global_map(pred, obs)
    else:
        raise ValueError(f"不支持的训练损失类型: {metric}")

    # 最后对 loss_map 做 reduce
    return reduce_loss_map(loss_map, lead_times=lead_times, reduction=reduction)


# -------------------------------------
# 4) 只用于显示的指标计算
# -------------------------------------
def compute_display_metrics(pred, obs, metrics=('mse', 'nse'), lead_times=None):
    """
    返回一个 dict，如 {"mse": <value>, "nse": <value>}。
    这里仅做统计用，不回传梯度。
    """
    results = {}

    # 先截取要用的 lead_time
    if lead_times is not None:
        pred = pred[:, lead_times]
        obs = obs[:, lead_times]

    # MSE
    if 'mse' in metrics:
        mse_val = (pred - obs).pow(2).mean().item()
        results['mse'] = mse_val

    # L1
    if 'l1' in metrics:
        l1_val = torch.abs(pred - obs).mean().item()
        results['l1'] = l1_val

    # NSE
    if 'nse' in metrics:
        with torch.no_grad():
            obs_mean = obs.mean(dim=0, keepdim=True)
            numerator = ((obs - pred) ** 2).sum(dim=0)
            denominator = ((obs - obs_mean) ** 2).sum(dim=0) + 1e-8
            # 这里是 nse(t) = 1 - numerator/denominator, shape=[lead_time]
            nse_lt = 1.0 - numerator / denominator
            nse_avg = nse_lt.mean().item()  # lead_time 再平均
        results['nse'] = nse_avg

    return results
