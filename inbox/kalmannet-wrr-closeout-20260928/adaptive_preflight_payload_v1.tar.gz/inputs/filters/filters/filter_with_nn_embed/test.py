import torch
from tqdm import tqdm
import matplotlib.pyplot as plt
import numpy as np
def test_nn(self, test_loader, max_batches=None, enable_plot=True):
    """
    测试训练好的神经网络模型在测试数据集上的表现 (可限制前若干个 batch 以便快速联调)。

    Args:
        test_loader (DataLoader): 测���数据集 DataLoader。
        max_batches (int|None): 只跑前 N 个 batch；None 表示全部。
        enable_plot (bool): 是否绘图（快速验证时可关掉）。

    Returns:
        list: [MSEs_test(list), loss_avg(float), updated_states_test(Tensor|empty), updated_outputs_test(Tensor|empty)]
    """
    # 设置模型为评估模式
    self.knet_model.eval()

    total_loss = 0.0
    total_samples = 0
    MSEs_test = []
    updated_states_test = []
    updated_outputs_test = []

    with torch.no_grad():
        with tqdm(test_loader, desc='Testing', unit='batch') as test_bar:
            for batch_idx, batch in enumerate(test_bar):
                # 若设置了 max_batches 且已达到数量，结束循环
                if max_batches is not None and batch_idx >= max_batches:
                    break

                # 准备批次数据
                p, ep, y_obs, state0 = self.prepare_batch_data(batch, )
                control = torch.cat((p, ep), dim=1)
                current_batch_size = p.size(0)

                # 初始化模型状态
                self.knet_model.batch_size = current_batch_size
                self.knet_model.init_nn()
                self.knet_model.update_mode = True
                self.knet_model.init_sequence(state0[:, :, 0], -99)

                # 前向计算
                states_upd, outputs_upd = self.forward_sequence(self.sys_model, y_obs, control)

                loss = self.loss_calculator.compute_losses(outputs_upd, y_obs)['mse']
                total_loss += loss.item() * current_batch_size
                total_samples += current_batch_size

                # 收集（可选，避免 OOM 可关掉）
                updated_states_test.append(states_upd.cpu())
                updated_outputs_test.append(outputs_upd.cpu())

                # 预测（示例保持，与原逻���一致）
                outputs_ol = state0[:, -1, :].unsqueeze(1)
                forecast_loss, outputs_forecast = self.compute_loss(self.sys_model, p, ep, y_obs, states_upd, outputs_upd)

                if enable_plot and batch_idx == 0:  # 仅首个 batch 绘图，减少阻塞
                    plot_forecasts_with_openloop_updated(
                        batch_i=0,
                        y_obs=y_obs,
                        outputs_ol=outputs_ol,
                        outputs_upd=outputs_upd,
                        outputs_forecast=outputs_forecast,
                        lead_times=[0, 1, 6, 11]
                    )

                avg_loss = total_loss / total_samples
                test_bar.set_postfix({'avg_loss': f"{avg_loss:.6f}", 'batch': batch_idx + 1})

    if total_samples == 0:
        print("[Warn] 未处理任何 batch，返回空结果。")
        return [MSEs_test, float('nan'), torch.empty(0), torch.empty(0)]

    # 计算平均损失
    loss_avg = total_loss / total_samples

    # 安全拼接
    if updated_states_test:
        updated_states_test = torch.cat(updated_states_test, dim=0)
    else:
        updated_states_test = torch.empty(0)
    if updated_outputs_test:
        updated_outputs_test = torch.cat(updated_outputs_test, dim=0)
    else:
        updated_outputs_test = torch.empty(0)

    # 打印测试结果
    print(f"Test: {loss_avg:.6f} [-] (batches={len(updated_outputs_test) if updated_outputs_test.numel()>0 else 0})")

    return [MSEs_test, loss_avg, updated_states_test, updated_outputs_test]

def plot_forecasts_with_openloop_updated(
    batch_i: int,
    y_obs: torch.Tensor,               # [batch_size, 1, seq_len]
    outputs_ol: torch.Tensor,          # [batch_size, 1, seq_len] => open loop
    outputs_upd: torch.Tensor,         # [batch_size, 1, seq_len] => updated
    outputs_forecast: torch.Tensor,    # [batch_size, feasible_timesteps, lead_time]
    lead_times=None
):
    """
    在同一个图上绘制:
      1) 观测 (Obs),
      2) Openloop (outputs_ol),
      3) Updated (outputs_upd),
      4) 并行多步预测 outputs_forecast (不同 lead_time).

    并在图例中显示各自相对于 Obs 的 NSE。

    参数:
    - batch_i: 绘制第几个 batch.
    - y_obs: [batch_size, 1, seq_len]，观测序列
    - outputs_ol: [batch_size, 1, seq_len]，open loop 序列
    - outputs_upd: [batch_size, 1, seq_len]，updated 序列
    - outputs_forecast: [batch_size, feasible_timesteps, lead_time],
        并行多步预测输出，(t,k)->(t+k) 关系.
    - lead_times: list or None,
        如果指定，如 [1,3,6]，只画那几个 k；否则默认画全部 0..lead_time-1.
    """
    # 把数据转为 numpy，方便处理
    device = y_obs.device
    y_obs_np = y_obs.detach().cpu().numpy()          # => [B, 1, seq_len]
    ol_np = outputs_ol.detach().cpu().numpy()     # => [B, 1, seq_len]
    upd_np = outputs_upd.detach().cpu().numpy()    # => [B, 1, seq_len]

    # 基本形状
    num_batches, _, seq_len = y_obs.shape
    _, feasible_timesteps, max_lead = outputs_forecast.shape
    assert 0 <= batch_i < num_batches, f"batch_i 超出范围(0..{num_batches-1})"

    # 取出 batch_i 对应的一维时序
    obs_1d = y_obs_np[batch_i, 0, :]  # => shape=[seq_len]
    ol_1d  = ol_np[batch_i, 0, :]
    upd_1d = upd_np[batch_i, 0, :]

    # 如果没给 lead_times，就画 0..(max_lead-1)
    if lead_times is None:
        lead_times = list(range(max_lead))

    # 并行预测, 需要对齐到真实时刻
    forecast_curves = {}
    a = outputs_forecast[batch_i, :, 0].detach().cpu().numpy()
    # check a should be identical with ol_1d[:seq_len].transpose
    # assert np.allclose(a, ol_1d[:feasible_timesteps].transpose())
    for k in lead_times:
        forecast_1d = outputs_forecast[batch_i, :, k]
        # => shape=[feasible_timesteps]
        aligned_curve = align_forecast_to_real_time(forecast_1d, k, seq_len)
        forecast_curves[k] = aligned_curve

    # 准备绘图
    plt.figure(figsize=(10,5))
    x = np.arange(seq_len)

    def calc_nse(obs, sim):
        mask = ~np.isnan(obs) & ~np.isnan(sim)
        obs_m = obs[mask]
        sim_m = sim[mask]
        if len(obs_m) < 2:
            return np.nan
        numerator = np.sum((obs_m - sim_m)**2)
        denominator = np.sum((obs_m - obs_m.mean())**2)
        return 1 - numerator/denominator if denominator != 0 else np.nan

    # 先计算 openloop、updated、obs 的 NSE
    nse_ol  = calc_nse(obs_1d, ol_1d)
    nse_upd = calc_nse(obs_1d, upd_1d)

    # 绘制 Obs
    plt.plot(x, obs_1d, label='Obs', marker='o', color='black')
    # 绘制 Openloop (图例带上 NSE)
    plt.plot(x, ol_1d, label=f'Openloop (NSE={nse_ol:.3f})', marker='x', linestyle='-', color='orange')
    # 绘制 Updated (图例带上 NSE)
    plt.plot(x, upd_1d, label=f'Updated (NSE={nse_upd:.3f})', marker='d', linestyle='-', color='green')

    colors = [plt.cm.tab10(i) for i in range(10)]

    # 画并行多步预测
    for idx, (k, curve) in enumerate(forecast_curves.items()):
        color = colors[idx % len(colors)]
        nse_val = calc_nse(obs_1d, curve)
        label_k = f"Lead {k} (NSE={nse_val:.3f})"
        plt.plot(x, curve, marker='s', linestyle='--', color=color, label=label_k)

    plt.xlabel("Time step")
    plt.ylabel("Value")
    plt.title(f"Batch {batch_i}: Obs / Openloop / Updated / Forecasts")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

    print("说明：")
    print(" - 当 lead_time=k 较大时，该曲线前面时刻 [0..k-1] 一般会是 NaN (空),")
    print("   因为并行预测中的 (t,k)->(t+k) 对齐导致最早一个预测点出现在 real_time=k。")
    print(" - 这恰好说明在真实时刻 < k 时，不能直接从并行预测获取 'k 步以后' 的结果。")

def align_forecast_to_real_time(forecast_1d, k, seq_len):
    """
    将 forecast_1d (形状 [feasible_timesteps]) 对应的 lead_time = k 的预测值
    映射到长度为 seq_len 的一维时序上 (真实时刻维度)。

    参数:
    - forecast_1d: [feasible_timesteps]，索引 t -> 基准时刻 t 的预测值
    - k: 指定的 lead_time (往后预测步数)
    - seq_len: 原始序列的总长度 (num_timesteps)

    返回:
    - aligned_curve: shape = [seq_len]
      其中 aligned_curve[t + k] = forecast_1d[t] (若 t + k < seq_len)，
      其余位置使用 NaN 填充。

    注意:
    - 因为 (t + k) 可能小于 0 或大于 seq_len - 1，
      所以在超出范围的地方我们无法对齐，就留成 NaN。
    - 这也是为什么当 k 较大时，曲线的前几个时刻 (0..k-1) 会是 NaN，
      说明“物理时刻 < k” 的部分对这个 lead_time 并没有可用的预测值。
    """
    if isinstance(forecast_1d, torch.Tensor):
        forecast_1d = forecast_1d.detach().cpu().numpy()

    feasible_timesteps = len(forecast_1d)
    aligned_curve = np.full(seq_len, np.nan)

    for t in range(feasible_timesteps):
        real_time = t + k
        if real_time < seq_len:
            aligned_curve[real_time] = forecast_1d[t]
    return aligned_curve
