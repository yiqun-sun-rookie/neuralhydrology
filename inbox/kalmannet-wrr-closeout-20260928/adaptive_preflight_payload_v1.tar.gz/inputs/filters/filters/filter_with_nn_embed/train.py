import os.path
import time, torch
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm
from collections import OrderedDict, defaultdict
from filters.filter_with_nn_embed.utils import prepare_batch_data
from filters.filter_with_nn_embed.core_fun import forward_sequence, system_model_forecast, rearrange_data_unfold
from filters.filter_with_nn_embed.metrics import compute_train_loss, compute_display_metrics
from filters.filter_with_nn_embed.save_load_checkpoints import load_checkpoint, save_checkpoint
def train_nn(pipeline, train_loader, val_loader, resume_checkpoint=None):
    start_epoch = 0
    if resume_checkpoint is not None:
        start_epoch = load_checkpoint(pipeline, resume_checkpoint) + 1

    # debug_mode = True
    # crash_epoch = 0
    # crash_batch = 1144
    # 主训练循环
    # torch.autograd.set_detect_anomaly(True)
    for epoch in range(start_epoch, pipeline.train_epochs):
        # if debug_mode and epoch < crash_epoch:
        #     print(f"[Debug] Skip epoch {epoch}")
        #     continue
        # ---------- Training ----------
        train_avg_bp_loss, train_avg_display_loss = run_one_epoch(pipeline, train_loader, epoch, is_training=True)
        # ---------- Validation ----------
        val_avg_bp_loss, val_avg_display_loss = run_one_epoch(pipeline, val_loader, epoch, is_training=False)
        # 学习率调整、早停检查、模型保存等逻辑
        post_epoch_operations(pipeline, epoch, val_avg_bp_loss, val_avg_display_loss)
        # 若早停条件达成则跳出循环
        if pipeline.no_improve_epochs >= pipeline.early_stopping_patience:
            print(f"验证损失连续 {pipeline.early_stopping_patience} 个 epoch 未改善，提前停止训练。")
            break

        pipeline.loss_train[epoch], pipeline.loss_cv[epoch] = train_avg_bp_loss, val_avg_bp_loss


    pipeline.writer.close()

    return train_avg_bp_loss, train_avg_display_loss, val_avg_bp_loss, val_avg_display_loss


def run_one_epoch(pipeline, data_loader, epoch, is_training=True):
    #
    debug_mode = False
    crash_epoch = 0
    crash_batch = 1143

    # 切换模型状态
    if is_training:
        pipeline.target_model.train()
        desc = f"[Train] Epoch {epoch + 1}/{pipeline.train_epochs}"
    else:
        pipeline.target_model.eval()
        desc = f"[Validate] Epoch {epoch + 1}/{pipeline.train_epochs}"
    # 初始化
    total_bp_loss, total_display_loss, total_samples, main_display_metric_avg = 0.0, defaultdict(float), 0, None
    if len(pipeline.display_metrics_list) > 0:
        main_display_metric = pipeline.display_metrics_list[0]  # 'mse' or 'nse'
    # 主循环
    # torch.autograd.set_detect_anomaly(True)
    with torch.set_grad_enabled(is_training):
        with tqdm(data_loader, desc=desc, unit='batch') as bar:
            for batch_idx, batch in enumerate(bar):
                if debug_mode and epoch == crash_epoch and batch_idx < crash_batch and is_training:
                    # 跳过已完成的batch
                    if batch_idx % 100 == 0:
                        print(f"[Debug] 跳过 epoch {epoch} batch {batch_idx}")
                    continue

                bp_loss, display_loss, batch_size = run_one_batch(pipeline, batch, is_training, epoch)

                # 累加各指标，计算
                for key, value in display_loss.items():
                    total_display_loss[key] += value
                # 计算当前的epoch平均bp_loss
                total_bp_loss += bp_loss
                total_samples += batch_size
                avg_bp_loss = total_bp_loss / total_samples
                # 计算当前的epoch平均display_metric
                if main_display_metric in display_loss and total_samples > 0:
                    main_display_metric_avg = total_display_loss[main_display_metric] / total_samples

                # 每隔一定 batch 显示一次信息
                if (batch_idx + 1) % pipeline.batch_display_interval == 0 or batch_idx == len(bar) - 1:
                    # 构造日志信息字符串
                    msg = f"Batch {batch_idx + 1}: mse: {avg_bp_loss:.5f}"
                    if main_display_metric_avg is not None:
                        msg += f", {main_display_metric}: {main_display_metric_avg:.5f}"
                    msg += f", LR: {pipeline.optimizer.param_groups[0]['lr']}"
                    bar.write(msg)

                # # 遇到上次崩溃点时暂停
                # if debug_mode and epoch == crash_epoch and batch_idx == crash_batch:
                #     print("\n===== 到达上次崩溃点 =====")
                #     print("当前模型状态：")
                #     print(pipeline.target_model.state_dict())
                #     print("正在执行崩溃batch...")
                #     # 这里可以添加更多调试信息

    # epoch结束，计算最终平均
    final_avg_bp_loss = avg_bp_loss
    final_avg_display_loss = {metric_name: (val_sum / total_samples)
        for metric_name, val_sum in total_display_loss.items()}

    return final_avg_bp_loss, final_avg_display_loss
def run_one_batch(pipeline, batch, is_training, epoch):
    p, ep, y_obs, state0 = prepare_batch_data(batch, pipeline.device)
    control = torch.cat((p, ep), dim=1) # (B, 2, T)

    # 前向update计算
    states_upd = forward_sequence(pipeline, y_obs, control)

    # 预报计算
    _, outputs_forecast_flat = system_model_forecast(sys_model=pipeline.sys_model, p=p, etpot=ep,
                                                     states_updated=states_upd, lead_time=pipeline.forecast_lead_time)

    # 计算损失
    if pipeline.sys_model.n == 1:
        outputs_forecast_flat = outputs_forecast_flat.squeeze(1)
    y_obs_rearranged = rearrange_data_unfold(y_obs, pipeline.forecast_lead_time).reshape(-1, pipeline.forecast_lead_time)
    # 用来反向传播的损失
    bp_loss = compute_train_loss(outputs_forecast_flat, y_obs_rearranged, lead_times=None, reduction='mean')
    # 计算显示的损失
    display_loss = compute_display_metrics(outputs_forecast_flat, y_obs_rearranged, metrics=pipeline.display_metrics_list,lead_times=None)

    # 如果是训练模式，则反向传播、优化
    if is_training:
        pipeline.optimizer.zero_grad()
        bp_loss.backward()
        pipeline.optimizer.step()
        # 梯度裁剪
        grad_norm_nn_q = torch.nn.utils.clip_grad_norm_(pipeline.target_model.nn_q.parameters(), max_norm=1.0)
        if grad_norm_nn_q > 1:
            print(f"Warning: high gradient norm {grad_norm_nn_q} detected at epoch {epoch}")
        grad_norm_nn_r = torch.nn.utils.clip_grad_norm_(pipeline.target_model.nn_r.parameters(), max_norm=1.0)
        if grad_norm_nn_r > 1:
            print(f"Warning: high gradient norm {grad_norm_nn_r} detected at epoch {epoch}")

    # 批次指标
    current_batch_size = p.size(0)
    bp_loss_batch_sum = bp_loss.item() * current_batch_size
    display_metrics_batch_sum = {}
    for k, v in display_loss.items():
        display_metrics_batch_sum[k] = v * current_batch_size

    return bp_loss_batch_sum, display_metrics_batch_sum, current_batch_size


def post_epoch_operations(pipeline, epoch, val_bp_loss, val_avg_display_loss):
    min_delta = 1e-6

    # 学习率调整
    if epoch >= pipeline.scheduler_switch_epoch:
        pipeline.scheduler.step(val_bp_loss)

    # 模型保存逻辑
    is_final_epoch = (epoch == pipeline.train_epochs - 1)

    # 条件1: 当前是最佳模型
    if pipeline.best_val_bp_loss - val_bp_loss > min_delta:
        pipeline.best_val_bp_loss = val_bp_loss
        pipeline.no_improve_epochs = 0
        # 保存最佳模型
        _save_model(pipeline, epoch, tag="best",
                    val_bp_loss=val_bp_loss, val_display_loss=val_avg_display_loss)

        # 检查是否需要保存检查点：距离上一次检查点保存超过间隔
        if epoch - pipeline.last_checkpoint_epoch >= pipeline.checkpoint_save_interval:
            _save_checkpoint(pipeline, epoch, tag="best")  # 保存特殊检查点
            pipeline.last_checkpoint_epoch = epoch  # 更新上一次检查点保存的 epoch
    else:
        pipeline.no_improve_epochs += 1

    # 条件2: 定期保存检查点（原有逻辑保持不变）
    if epoch % pipeline.checkpoint_save_interval == 0:
        _save_checkpoint(pipeline, epoch, tag="regular")
        pipeline.last_checkpoint_epoch = epoch  # 更新上一次检查点保存的 epoch

    # 条件3: 最终 epoch 或早停时保存最终模型
    if is_final_epoch or pipeline.no_improve_epochs >= pipeline.early_stopping_patience:
        _save_model(pipeline, epoch, tag="final",
                    val_bp_loss=val_bp_loss, val_display_loss=val_avg_display_loss)

    # 阶段切换判断
    maybe_update_lead_time_phase(pipeline, epoch, val_avg_display_loss)

def _save_model(pipeline, epoch, tag, val_bp_loss=None, val_display_loss=None):
    """统一模型保存方法"""
    filename = f"{tag}_model_epoch{epoch:03d}_{pipeline.train_start_time}.pt"
    path = os.path.join(pipeline.path_config['models'], filename)

    model_data = {
        'model_state_dict': pipeline.target_model.state_dict(),
        'epoch': epoch,
        'val_bp_loss': val_bp_loss,
        'val_display_loss': val_display_loss,
    }

    try:
        torch.save(model_data, path)
        print(f"成功保存 {tag} 模型及元数据至: {path}")
    except Exception as e:
        print(f"保存 {tag} 模型失败: {str(e)}")
        raise
#
# def _save_model(pipeline, epoch, tag):
#     """统一模型保存方法"""
#     filename = f"{tag}_model_epoch{epoch:03d}_{pipeline.train_start_time}.pt"
#     path = os.path.join(pipeline.path_config['models'], filename)
#
#     try:
#         torch.save(pipeline.target_model, path)
#         print(f"成功保存 {tag} 模型至: {path}")
#     except Exception as e:
#         print(f"保存 {tag} 模型失败: {str(e)}")
#         raise


def _save_checkpoint(pipeline, epoch, tag):
    """统一检查点保存方法"""
    checkpoint = {
        'epoch': epoch,
        'model_state_dict': pipeline.target_model.state_dict(),  # 模型参数
        'optimizer_state_dict': pipeline.optimizer.state_dict(),  # 优化器状态
        'best_val_bp_loss': pipeline.best_val_bp_loss,  # 最优验证损失
        'no_improve_epochs': pipeline.no_improve_epochs,  # 未改善的 epoch 数，用于早停
        'loss_train': pipeline.loss_train,  # 训练损失历史
        'loss_cv': pipeline.loss_cv,  # 验证损失历史
        'current_phase_idx': pipeline.current_phase_idx,  # 当前 lead time phase 索引
        'forecast_lead_time': pipeline.forecast_lead_time,  # 当前预报提前时间
        'train_start_time': pipeline.train_start_time,  # 训练开始时间戳
        'torch_random_state': torch.get_rng_state(),  # PyTorch 随机状态
        'torch_cuda_random_state': torch.cuda.get_rng_state() if torch.cuda.is_available() else None,
    }

    # 根据 tag 生成文件名
    if tag == "regular":
        filename = f"checkpoint_epoch{epoch:03d}.pt"
    else:  # tag == "best"
        filename = f"checkpoint_best_epoch{epoch:03d}.pt"

    path = os.path.join(pipeline.path_config['checkpoints'], filename)

    try:
        torch.save(checkpoint, path)
        print(f"检查点已保存至: {path}")
    except Exception as e:
        print(f"保存检查点失败: {str(e)}")
        raise


def maybe_update_lead_time_phase(pipeline, epoch, val_loss):
    """
    双重条件：
     1) epoch >= min_epoch
     2) 验证集表现好 (如 NSE>threshold
    才切到下一个 phase
    """
    # 若已经到最后一个 phase，就不再切换
    # if pipeline.current_phase_idx >= len(pipeline.lead_time_phases) - 1:
    #     return

    phase_info = pipeline.lead_time_phases[pipeline.current_phase_idx]

    # 1) epoch 要 >= phase_info["min_epoch"]
    if epoch < phase_info["min_epoch"]:
        return  # 还没到最小epoch，不切

    # 2) 看验证集效果
    # 假设你想要 "val_loss < some_threshold"
    val_threshold = phase_info["val_improve_threshold"]
    # 如果实际上你追求 nse>0.5, 也行, 只要在post_epoch_operations里拿到 nse
    # 这里先假设 val_loss是 "MSE"
    nse = val_loss.get("nse")
    if nse is None:
        print(f"[Warning] 'nse' 未在 val_loss 中找到: {val_loss}")
        return

    if nse > val_threshold:
        # 满足 => 切换到下一个 phase
        pipeline.current_phase_idx += 1
        new_idx = pipeline.current_phase_idx
        if new_idx < len(pipeline.lead_time_phases):
            new_lead_time = pipeline.lead_time_phases[new_idx]["lead_time"]
            pipeline.forecast_lead_time = new_lead_time
            print(f"[Phase Update] epoch={epoch}, nse={nse:.4f}, "
                  f"切换到 lead_time={new_lead_time}")

