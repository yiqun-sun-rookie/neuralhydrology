from filters.da_coupler.walrus_batch import fx_walrus_batch, hx_walrus_batch
class WalrusFunctionFactory:
    def __init__(self, sys_model):
        self.sys_model = sys_model
        self.current_controls = None

    def set_controls(self, controls):
        self.current_controls = controls

    def create_fx(self, controls):
        return lambda sigmas, dt: fx_walrus_batch(
            sigmas, dt, sys_model=self.sys_model, controls=controls
        )

    def create_hx(self):
        return lambda sigmas: hx_walrus_batch(sigmas, sys_model=self.sys_model)
