import torch

class UKF_with_NN:
    def __init__(self, dim_x, dim_z, dt, hx, fx, points, prior_q, prior_r, scaler_q, scaler_r, batch_size, nn_q, nn_r, device='cuda'):
        self.device = torch.device(device)
        self.dim_x = dim_x
        self.dim_z = dim_z
        self.dt = dt
        self.hx = hx  # measurement function
        self.fx = fx  # state transition function
        self.batch_size = batch_size
        self.nn_q = nn_q.to(self.device)  # 神经网络模型
        self.nn_r = nn_r.to(self.device)  # 神经网络模型

        # Initialize weights with float32
        self.Wm = torch.tensor(points.Wm, dtype=torch.float32, device=self.device)
        self.Wc = torch.tensor(points.Wc, dtype=torch.float32, device=self.device)
        self.c = points.c

        self.x = torch.zeros(batch_size, dim_x, dtype=torch.float32, device=self.device)
        self.P = torch.eye(dim_x, dtype=torch.float32, device=self.device).unsqueeze(0).repeat(batch_size, 1, 1)

        # 初始化神经网络的隐藏状态
        self.h_prev_q = self.nn_q.init_hidden(batch_size=batch_size, device=self.device)
        self.h_prev_r = self.nn_r.init_hidden(batch_size=batch_size, device=self.device)


        # 为了保存之前的状态和观测
        self.z_obs_previous = torch.zeros(batch_size, dim_z, device=self.device)
        self.z_obs = torch.zeros(batch_size, dim_z, device=self.device)
        self.z_prior = torch.zeros(batch_size, dim_z, device=self.device)
        self.x_posterior_previous = torch.zeros(batch_size, dim_x, device=self.device)
        self.x_prior_previous = torch.zeros(batch_size, dim_x, device=self.device)

        #
        self.q = prior_q
        self.r = prior_r
        self.scaler_q = scaler_q
        self.scaler_r = scaler_r

    def predict(self, dt=None):
        if dt is None:
            dt = self.dt

        # 计算 sigma 点
        sigmas = batch_sigma_points(self.x, self.P, self.c)
        sigmas_f = self.fx(sigmas, dt)
        self.sigmas_f = sigmas_f

        # 更新状态 x
        self.x = torch.einsum('bni,n->bi', sigmas_f, self.Wm)
        self.x_prior = self.x
        # 计算 P
        x_diff = sigmas_f - self.x.unsqueeze(1)
        self.P = torch.einsum('n,bni,bnj->bij', self.Wc, x_diff, x_diff) + self.q
        self.P = self._make_symmetric(self.P)
        # 添加正定性保护
        min_eig = torch.linalg.eigvalsh(self.P).min(dim=1).values
        if (min_eig < 1e-8).any():
            I = torch.eye(self.dim_x, device=self.device).expand_as(self.P)
            self.P = self.P + 1e-8 * I  # 添加小正数到对角线

    def update(self, z):
        # 获取自适应的R矩阵
        sigmas = batch_sigma_points(self.x, self.P, self.c)
        sigmas_h = self.hx(sigmas)
        z_pred = torch.einsum('bni,n->bi', sigmas_h, self.Wm)

        # 计算观测差异
        z_diff = sigmas_h - z_pred.unsqueeze(1)
        S = torch.einsum('n,bni,bnj->bij', self.Wc, z_diff, z_diff) + self.r

        # 计算交叉协方差
        x_diff = sigmas - self.x.unsqueeze(1)
        Pxz = torch.einsum('n,bni,bnj->bij', self.Wc, x_diff, z_diff)

        # 卡尔曼增益
        S_inv = torch.inverse(S)
        K = torch.einsum('bij,bjk->bik', Pxz, S_inv)

        # 更新状态 x 和协方差 P
        y = z - z_pred
        self.x = self.x + torch.einsum('bik,bk->bi', K, y).clone()
        self.P = self.P - torch.einsum('bik,bkj->bij', K, torch.einsum('bij,bjk->bik', S, K.transpose(1, 2))).clone()
        self.P = self._make_symmetric(self.P)
        # 添加正定性保护
        min_eig = torch.linalg.eigvalsh(self.P).min(dim=1).values
        if (min_eig < 1e-8).any():
            I = torch.eye(self.dim_x, device=self.device).expand_as(self.P)
            self.P = self.P + 1e-8 * I

        z_obs_diff = z - self.z_obs_previous
        z_innov_diff = z - z_pred
        x_posterior_diff = self.x - self.x_posterior_previous
        x_update_diff = self.x - self.x_prior_previous
        q_next = self.get_q(z_obs_diff, z_innov_diff, x_posterior_diff, x_update_diff)

        self.q = q_next
        r_next = self.get_r(z_obs_diff, z_innov_diff, x_posterior_diff, x_update_diff)
        self.r = r_next
        # 检查q_next和r_next是否有nan
        if torch.isnan(q_next).any() or torch.isnan(r_next).any():
            raise ValueError("q_next or r_next contains nan")

        self.z_obs_previous = z
        self.x_posterior_previous = self.x
        self.x_prior_previous = self.x_prior

    def get_q(self, z_obs_diff, z_innov_diff, x_posterior_diff, x_prior_diff):
        # 获取自适应的 Q 矩阵，通过神经网络
        # 使用前向差异、更新差异来估算 Q
        q_diag, self.h_prev_q = self.nn_q(z_obs_diff, z_innov_diff, x_posterior_diff, x_prior_diff, h_prev=self.h_prev_q)
        if torch.isnan(q_diag).any() or torch.any(q_diag < 0):
            print(f"Invalid q_diag detected: {q_diag}")
        return torch.diag_embed(q_diag * self.scaler_q)

    def get_r(self, z_obs_diff, z_innov_diff, x_posterior_diff, x_prior_diff):
        # 获取自适应的 R 矩阵，通过神经网络
        # 使用前向差异、更新差异来估算 R
        r_diag, self.h_prev_r = self.nn_r(z_obs_diff, z_innov_diff, x_posterior_diff, x_prior_diff, h_prev=self.h_prev_r)
        if torch.isnan(r_diag).any() or torch.any(r_diag < 0):
            print(f"Invalid r_diag  detected: {r_diag}")
        return torch.diag_embed(r_diag * self.scaler_r)

    def _make_symmetric(self, matrix):
        """
        确保矩阵是对称的
        """
        return (matrix + matrix.transpose(1, 2)) / 2



def batch_sigma_points(x, P, c):
    """
    批量生成 sigma 点。

    参数：
    - x: 均值张量，形状为 (batch_size, dim_state)
    - P: 协方差张量，形状为 (batch_size, dim_state, dim_state)
    - c: sigma 点缩放参数

    返回：
    - sigmas: sigma 点张量，形状为 (batch_size, 2 * dim_state + 1, dim_state)
    """
    batch_size, dim_x = x.shape
    num_sigmas = 2 * dim_x + 1

    # 计算平方根矩阵，形状为 (batch_size, dim_state, dim_state)
    U = torch.linalg.cholesky(P * c)

    # 扩展 x，形状为 (batch_size, 1, dim_state)
    x = x.unsqueeze(1)

    # 初始化 sigma 点张量，形状为 (batch_size, num_sigmas, dim_state)
    sigmas = torch.zeros(batch_size, num_sigmas, dim_x, device=x.device)

    # 第一个 sigma 点是均值
    sigmas[:, 0, :] = x[:, 0, :]

    for k in range(dim_x):
        sigmas[:, k + 1, :] = x[:, 0, :] + U[:, :, k]
        sigmas[:, dim_x + k + 1, :] = x[:, 0, :] - U[:, :, k]

    return sigmas
