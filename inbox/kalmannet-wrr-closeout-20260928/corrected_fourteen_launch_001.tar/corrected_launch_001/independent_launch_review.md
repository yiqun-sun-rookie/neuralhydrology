# Corrected-setting launcher: independent specification and code review

## Specification compliance

**Verdict: compliant for the requested launcher task.** `corrected_one.slurm:20-35` permits exactly the eight named model bases with two corrected variants and rejects other argument counts, including `main_seed42`. Lines 4-14 request the exact scheduler resources; lines 37-45 use one case-specific first-attempt output, original completion and new admission. Lines 47-59 require absent output and marker, scheduler identity, logs, proof files, both hash lists, a hash-bound copied delivery receipt and byte equality with the live receipt. Lines 61-77 retain the named environment, create an exclusive marker and invoke one unchanged formal runner. The seven synthetic tests in `test_corrected_one.py:118-227` cover these boundaries with a captured runner invocation.

**Cannot verify from this diff:** whether the unchanged formal runner independently validates the admission, original bridge, preflight, environment, code and data. This task does not modify that runner, and the launcher passes its exact admission at `corrected_one.slurm:76`. Actual original-result acceptance, corrected-state delivery and live admission are separate controller decisions, not results established by this review.

## Strengths

- The complete case allowlist is explicit (`corrected_one.slurm:25-35`), and the test compares it with the exact 16-case set (`test_corrected_one.py:118-124`).
- Existing outputs and markers, including dangling symbolic links, stop execution; marker creation uses exclusive shell redirection (`corrected_one.slurm:47-50,70-75`). The tests also retain the marker when the model call fails (`test_corrected_one.py:185-227`).
- The mock runner captures the full formal command for both corrected variants without loading inputs or executing a model (`test_corrected_one.py:66-78,136-154`).

## Issues

Critical: **0**. Important: **0**. Minor: **0**.

## Assessment

**Task quality: Approved for this code-review gate.** The implementation is short, case bounded, and testable; approval does not authorize a case or establish a scientific result. The implementer's report states that Bash syntax and seven synthetic tests passed. I did not rerun them because the diff raised no specific untested doubt. The PowerShell startup produced unrelated Conda initialization noise during read-only checks; no test output was generated in this review.

Verified local SHA-256: `review.patch` = `fa74e4478b1517bd3a5ad283d7542170e8e301f895ece765591d53bd5bee73dc`; `corrected_one.slurm` = `dc805a9cb8862f89577120a6757cc838462cd3dc8b98a2eac081284b3cef305f`; `test_corrected_one.py` = `767d6950e1cc035611d4f500ca3e0a76e9afe3e2e7d2ca5165c812317dadf897`.

Focused external checks: the risk that the source original-output path was inconsistent was checked against `hpc/remaining_launch_001/original_eight/original_one.slurm:31-32`; its output pattern matches `corrected_one.slurm:42`. The risk that corrected-state input delivery was already complete was checked against `hpc/plain_formal_input_delivery_001/delivery_catalogue.json`: its `file10` records the corrected-state source and target with SHA-256 `7c9f21f4ab69840a3f87064ff9aec15222f48b124ac61c6f65d21a39ac07df60`, while the catalogue state is `DELIVERY_DESIGN_ONLY_NOT_PACKAGED_OR_COPIED`.

**Outstanding controller duties:** independently accept each same-model original result; keep `main_seed42` closed; deliver and hash-verify catalogue `file10`; create and bind the live delivery completion and copied receipt; sign each new exact-case admission with its accepted preflight, same-model original completion and independent result decision; bind deployment hashes and precreate logs; then enforce absent destinations, one job per case, real sequential dependencies, one task-owned graphics processor at a time, no retry or interruption of other experiments. Audit each finished attempt separately. No case is admitted by this review.
