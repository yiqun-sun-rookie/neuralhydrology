# 14份修正评价准入的独立核查

审核者：Codex 独立结果审核代理 `/root/completed_actual_result_review`。日期：2026-09-29，新加坡时间。

## 结论与范围

**本次核查的14份具名准入身份和证据绑定通过，严重问题0项、重要问题0项。** 精确范围是主网络随机初始化43、44，紧凑网络随机初始化42、43、44，学习噪声滤波器及手动设定噪声滤波器，共七个模型，每模型“只修正出口公式”和“修正出口公式并采用已登记修正初态”两个版本。主网络随机初始化42及历史在线观测噪声滤波器均不在14份准入中。

此结论仅完成控制者新签准入文件的独立检查。它不签发新的准入，不批准实际提交，不接受修正输出，也不重新开展科学结果审核。串行提交程序另有独立审核，仍须完成；正式部署和提交前的现场指纹、目标及标记不存在、资源和队列条件仍由执行者核对。本次未访问远程、执行模型、打开原始张量或检查点、修改程序或准入文件。

本次使用既已阅读的可复现性检查和科学同行评审技能，限定核对来源链与接受范围。未将较早前置条件报告中的“尚待交付、尚待原结果接受”当成当前事实；这两项分别由第28号真实交付回执和具名逐模型实际结果裁定补足。

## 核查结果

- `admissions/` 恰好14份JSON文件，文件名、内部案例身份和冻结清单中的身份一致，集合恰好为上述七模型×两个修正版本，没有额外模型、原设置版本或重复身份。
- 14份均为 `PLAIN_EVALUATION_ACCEPTED`，当前案例未结严重/重要问题为0，并有具名签发者和原设置独立审核路径/指纹。其作用是控制者授予的指定首次运行准入，不是生产结果已接受。
- 每项预检绝对路径精确指向自身 `__preflight_attempt01/completion.json`；14个本地完成记录指纹均等于准入引用，也等于既有独立实际检查报告 `provenance/plain_actual_checker_002.json` 的该项证据索引。该检查报告当前指纹仍为 `803509089c0c9aea6f21374eb254a6ae9cf6ffb875f47e3b85a487d7aedc653c`。各项13项已登记检查均为真，预检状态、两次重复逐位相同、时间映射通过和测试张量读取0均符合冻结运行要求。
- 每项原设置绝对路径精确指向同模型的 `__original_outlet_original_states__formal_attempt01/completion.json`；当前原完成记录指纹等于准入引用。原完成身份、状态、历史复现通过和清单绑定成立；其实际结果裁定为 accepted=true，逐案例严重0、重要0。
- 14项各自预检的9份代码绑定与同模型原设置一致，21个环境字段与原设置及准入中的接受环境完全一致。当前本地9份冻结运行代码也分别重算指纹一致。此为文件和记录核查，不是重新执行预检或证明未来运行环境。
- 所有准入、预检和原完成记录都绑定同一部署清单 `fe81db8c7bbea43e2f8040ea004e8f8bbf5ddf2107cd5b73369643f3e68c3087`；预检包清单与返回清单当前字节指纹相同。
- 原预检作业调度失败 `FAILED|127:0` 在14份准入中均保留，并说明是27项预检完成后的调度查询错误。没有将该历史失败改写为调度成功。
- 原实际结果裁定总体 accepted=false、重要问题3项原样保留；七项当前相关模型各自为0问题。14份准入没有把总体问题数改成0，也没有把主网络初始化42、历史在线方法或两个未接受匹配测试纳入通过集合。较早前置条件报告保留原文，不能把其历史16项条件范围解读为现在16项已经准入。

## 真实初态交付

第28号原始回执 `hpc/receipt_028_corrected_state_delivery.txt` 当前安全散列算法256位指纹（SHA-256，用于核对字节身份）为：

`6189f7c21bf04e4da96e1164967fe00b5abd9913f71bf2a292db490b289e825b`

回执记录2026-09-29 12:44:34至12:44:37，退出码0，已部署交付程序、目录表、部署清单、传输分片和最终目标指纹均通过。审核者在内存中解码其嵌入的Base64完成记录，所得字节指纹、回执标注和本地 `corrected_state_delivery.json` 指纹三者相同：

`5fa38b2d534fdf4161885dc0749ae6ac6b5a691b71dbf3032e4336b63b6a35f9`

实际完成记录满足 `OPAQUE_INPUTS_COPIED_NOT_EVALUATED`、阶段 `corrected_states`，文件数组恰好1项且为 `file10`，316,764字节；源/目标完整指纹：

`7c9f21f4ab69840a3f87064ff9aec15222f48b124ac61c6f65d21a39ac07df60`

精确目标为：

`/data1/home/sunyiq/kalmannet_wrr_closeout_20260928_v1/plain_preflight_v1/inputs/repo/docs/plans/wrr-hamid-evaluation-20260927-v1/test_states_001/test_corrected_cpu.pt`

其路径、文件身份、大小、完整指纹和唯一分片与既有交付目录表一致；目录表当前指纹仍为 `ca5e0e183e8ff7776ea9fd2e716999e774931ba32a385942fd065b3969d453d0`。记录的模型执行数0、张量反序列化数0、正式评价准入false均正确。交付脚本还在成功回执前校验最终文件大小，并拒绝已有目标或失败回执。审核者没有再次读取实际张量，以上实际交付结论基于字节绑定的完成记录和退出成功回执；提交时仍须按启动器要求比对远端真实回执与复制件。

14份准入的 `corrected_state_delivery` 均精确引用新启动根下复制件的绝对路径及上述真实指纹，未引用设计目录或旧原设置交付回执来冒充完成。

## 审核证明文件

下列复制件与原审核文件各自当前指纹完全相同；前两份的远端路径和指纹已逐项核对14份准入引用，第三份是保留的前置条件证明：

| 复制证明 | SHA-256 |
|---|---|
| `proofs/corrected_scope_independent_review.md` | `383319c5305d090234d00151a89e3e268d2e26da8296e59467e25941644ecc8c` |
| `proofs/independent_result_review.md` | `4432c11f5dcdfeb06221cc2d20da8302f0fb892c9c054a25164f8dc92f6031fa` |
| `proofs/result_acceptance_001.json` | `a35e94a6354f1c9fd7091666c0e59df01ec1c209e8be85e7248c19b8e4411533` |

## 本次核查的14份准确文件身份

机器身份中 `main` 表示主网络，`compact` 表示紧凑网络，`learned_noise` 表示学习噪声滤波器，`hand_tuned` 表示手动设定噪声滤波器；`corrected_outlet_original_states` 表示只修正出口公式，`corrected_outlet_corrected_states` 表示同时使用修正初态。这里列出完整指纹，后续改动需重新检查本次覆盖范围。

| 精确案例身份 | 准入JSON SHA-256 | 自身预检完成记录 SHA-256 |
|---|---|---|
| `compact_seed42__corrected_outlet_corrected_states` | `f18c37f62003169c433e2d12e8c9d2065c72e4e20ad48a07163f81d1c1649509` | `1a3eae9e7c846900088b8988e5c0cedb370a1d12398f3974c2cb2c0911f05a13` |
| `compact_seed42__corrected_outlet_original_states` | `bb8770f57a7734726cfc9f983c92a77aefacfc0e91818525cc6344c3edc42b70` | `9c0f3205eb092573f032d2e51c52fe22b28192d53d36e4425f161341621da627` |
| `compact_seed43__corrected_outlet_corrected_states` | `bb27c3fb3d7961a23d58a66eeb08d6c1f84bffc1fea6065e0bc057a56a2dd27c` | `b7aaf03f9308f82984dd6f4d9d0c640fccfff87dd537f0af77c1a39a8e95113d` |
| `compact_seed43__corrected_outlet_original_states` | `b9bc525d762f2813af407c79fc18873fea0ffbc84b9c27c713f1d3e8c658f3c7` | `a5d4d8341e7c62979bb8bd226af2da9ed85d9004ef66473a5cd2f4b6aa1944af` |
| `compact_seed44__corrected_outlet_corrected_states` | `3626da7af40c1b5e3a07f6d5dd9353eb4eda611abda5a3bbf6cb3eeaf49d5d65` | `ca7a3f60e623ca63c5586473764c675e5a3313595aebb97f10577b24b4624944` |
| `compact_seed44__corrected_outlet_original_states` | `16c583874bb9ab8fec5c020dbfe7686ed9391313024236a1836cb0574224bcaa` | `384e68e207298b9d9704653e721b6b317b52f783ec7b457fbae5523edaa91fc0` |
| `hand_tuned__corrected_outlet_corrected_states` | `dbafbf6cccf851ba317dc90917bbe5c8d142f5bd92405313d8af09aab0f3a6a4` | `c0462c4a2b279bdcbd4f83d11e51d96a766ad401923892bd9527d103637ff5f3` |
| `hand_tuned__corrected_outlet_original_states` | `aa27d2a40b9da1836219428fb889d2d271a4a19920f0572918ab6b98234defe5` | `295ca13ad6d040fa3cf69fd713ba099505976d4efca6e32289f25f5fe6f53c64` |
| `learned_noise__corrected_outlet_corrected_states` | `9c01e583d55c08f34c6edd912f879cff41cd244b4e04dfe1f72142be53001e9c` | `f4ed9e4498f31356779dadc97147dc9d42418d027fe211390666262777962828` |
| `learned_noise__corrected_outlet_original_states` | `c895a9cd7deffb2f8492bb6e3c40dd4a1e38e30e469efcd7cd4422c2e8f15d4d` | `58e483cd4ece4e7b5e414d00b76dab59875f34372b120837b748bc206e56b4d5` |
| `main_seed43__corrected_outlet_corrected_states` | `d7f3a456d8cfdc20047295189c3d15118300c76180069c1c9cb89ff6a828d19a` | `7af4d8c7b91aa50f3f00ddeb8d4707208157cc8c6163ef5706d445d6e6c7e805` |
| `main_seed43__corrected_outlet_original_states` | `2e385452bff5f472bb33d425d3956db12571f9989b4f7b4c556a33ea5921822c` | `a069f8a2897640f2994d2957874e7ec4cb3933be632868f7f598fce426878412` |
| `main_seed44__corrected_outlet_corrected_states` | `b8bcc93c28897e3a669022924d9299315321c806b2b429e786af7f42eaa707dd` | `75970b02ffa1a6c0ceaebe7167de76dfbc802f82ae50336dbd239fd37cf91e16` |
| `main_seed44__corrected_outlet_original_states` | `ca7683c4ccf0445b3fd19d9c97e12569660c82e3a17eb2262367e00fbdf4f194` | `62dd9a0255f15b1040a6a830d5bed42c604575ef94f9dad7442fedf0bb251e77` |

对应原设置完成记录：

| 同模型原设置身份 | 原完成记录 SHA-256 |
|---|---|
| `compact_seed42__original_outlet_original_states` | `ceb64d604a132958bd3cd8ee06c8dc319c4b5aba93b0e4d431cc98d8df2c8ee0` |
| `compact_seed43__original_outlet_original_states` | `d48283c9ca5d7f00217e928ed029bdb223b808be237576aea5f911b6d02dbaf8` |
| `compact_seed44__original_outlet_original_states` | `45ac842ea552aea046ad13f62e0265fff9298450c7976743c2611464f534db97` |
| `hand_tuned__original_outlet_original_states` | `b1be110b02e6362b7cb03c0a77f9acff6f3b60b768c951b0c9739a2331925857` |
| `learned_noise__original_outlet_original_states` | `ae52d7c8505a93e5b4e1c2c533abf17ff8ec1ecec51b4513eb71cddbd35f0379` |
| `main_seed43__original_outlet_original_states` | `7e5a23058c2cb3eb0540763bff186bc7dc1387a55d31f3068121474f0ddf86e1` |
| `main_seed44__original_outlet_original_states` | `53bcb5d02a5e92fc34a7aeda5e7a23c61f0022889ce2c9a04e9f8667b098ce31` |

## 保留边界

本报告严重0、重要0仅表示这14份准入绑定未发现缺陷，不表示整个研究或串行提交程序不存在未结事项。原实际结果审核的三个问题继续属于各自未接受模型/测试范围，不能以本报告清零。修正运行完成后仍需实际输出、来源、保存统计和数值影响独立验收；当前0小时与未来1—24小时必须分开。两种改变同时发生时不能称为单因素因果试验，也不能预告方法优越或稿件交付结论。

唯一新增文件是本报告。没有编辑14份准入、已冻结证据或程序，没有提交或启动任何作业。

