# 修正评价前置条件独立审查：有条件齐备，尚未准入

日期：2026-09-29。独立审查者：`corrected_scope_review`。本文中的相对路径均以 `docs/plans/wrr-hamid-all-comments-completion-20260928-v1` 为根。按 `corrected_scope_review_brief.md` 指定范围，只读取既存记录和代码；未打开张量、检查点或统计数组，未访问远端，未运行模型，未签发准入或原设置结果接受。采用可重复性核查技能，区分已冻结证据、实际运行验收和科学结论。

## 结论与问题计数

**16项修正设置自身的预检、程序和记录环境前置条件齐备，可在对应原设置实际独立接受后继续办理逐项准入；目前不能启动。严重问题0项，重要准入缺口3项。** 这3项是原设置实际接受、修正测试初态交付核验、逐项准入及新启动包审核；不是发现预检失败。八项原设置的数组验收由另一审查负责，本报告不把它们视为已经接受。主网络随机初始化42仍关闭，其两项修正设置不在本次16项范围内。

1. **重要缺口一：对应原设置尚须实际独立接受。** 后续计划第27、45、53—55、63行要求逐模型独立验收。`numerical_impact/code/plain_evaluation.py:122–136` 核验同模型原设置完成状态、身份、部署清单、程序、环境、历史复现通过状态和结果文件登记；运行完成记录本身不能替代数组与记录的独立验收。新准入记录必须绑定真正的独立裁定，不得仅把该完成记录改称接受。八个模型若全部实际接受，该缺口才对这16项关闭；若只有部分接受，只准入对应子集。
2. **重要缺口二：修正测试初态的目的文件尚无交付完成证据。** `hpc/plain_formal_input_delivery_001/delivery_catalogue.json:393–410` 登记 `file10`，而 `hpc/plain_formal_launch_001/remote_input_completion.json:3–62` 仅覆盖原设置阶段的 `file01` 至 `file09`。预检包明确排除了测试初态（`hpc/plain_preflight_package_001/package_receipt.json:18–29`）。八项“同时修正公式与初态”运行前必须按下列唯一来源不透明交付并核对目的文件摘要；禁止重新生成初态。只修正公式的八项不读取这个张量，但仍依赖已有初态配对证明记录，见 `run_plain.py:84–95`。本审查没有访问远端，不能证明该目标此刻存在或不存在。
3. **重要缺口三：16项各自的正式准入及新启动包尚须独立审核。** 既有审核明确只签九项原设置准入，未签任何修正准入（`hpc/plain_formal_admission_001/independent_review.md:7–9`）。`plain_evaluation.py:97–119` 要求具名审核、零未结严重/重要问题、准确清单/身份/代码绑定及该项自身预检；`run_plain.py:142–150` 在模型执行前核查并创建全新独占目录。新启动器须固定实际接受的子集、逐项首次尝试、真实串行和资源限制，并接受独立规格/代码审核。不得把本报告作为 `PLAIN_EVALUATION_ACCEPTED` 记录。

本报告未发现需要修改已冻结推理程序或放宽复现门槛的额外代码缺陷。上面三项完成后仍须正式核对准入记录；“有条件齐备”不等于“已经准入”。

## 已独立核实的预检与程序绑定

本次重新计算16项配置身份摘要，全部与各自预检完成记录一致；逐项检查160份证据记录的文件摘要，160/160一致；16项两次独立构建的输出指纹全部相同。16项绑定的是同一套9份代码，当前本地9份代码与冻结摘要全部一致；21个记录环境字段除登记批大小外相同。每项既有独立检查记录的13项检查均为真。这里验证的是记录及指纹，不是重新计算预测。

- 部署清单 `hpc/plain_preflight_package_001/deployed_manifest.json`，安全散列算法256位摘要（文件内容指纹）：`fe81db8c7bbea43e2f8040ea004e8f8bbf5ddf2107cd5b73369643f3e68c3087`；返回副本 `hpc/plain_receipts_001/deployed_manifest.json` 完全一致。
- 已接受的实际检查报告是 `provenance/plain_actual_checker_002.json`，不是假设名称 `plain_preflight_audit_001.json`；摘要 `803509089c0c9aea6f21374eb254a6ae9cf6ffb875f47e3b85a487d7aedc653c`。其 `rows[case_id].evidence_sha256` 是每项10份记录的完整摘要索引；技术检查27/27通过，`formal_acceptance_created=false`。
- 预检包回执摘要 `b97410e78202bde3e18aa5dcaac2e6fe4c0ee7146156668e225db6e3a716915d`。9份代码逐文件清单位于每项预检 `completion.json.code_bindings`；其中 `plain_evaluation.py` 为 `81b616719ab456eb43507a52787ff8bab31d71ef505caf70c0ddbc4569f35505`，`run_plain.py` 为 `1ad9c0cf371cbbdf1c61fa33be0c104d90dbb28b69be890f05e5435a1fc8041b`。
- 记录环境：Python 3.11.13、PyTorch 2.4.0、NumPy 2.3.3、CUDA 12.1、cuDNN 90100、NVIDIA GeForce RTX 3090、32位浮点数、执行随机种子42。历史在线观测噪声滤波器批大小128，其余256。模型训练随机初始化43/44与执行随机种子42不是同一概念。正式执行还须再次与该项环境完全核对，见 `run_plain.py:171–177`。
- 原物理源码摘要 `703adbb37c7bd3804f7f218664c9636f4a3c5a303687fdbb33fc6172b0daffd2`，仅修正条件后的生成物理源码摘要 `8ba7ac99581b948c3ba4443e2a86ce32731d27216c67d30976192dd57ff00312`。既有独立接受见 `hpc/plain_formal_admission_001/independent_review.md:21–25`；本轮没有修改生成方式。

下表左列是机器记录的精确身份，右列是本次独立重算的配置摘要。`main` 指主网络，`compact` 指紧凑网络，`learned_noise` 指学习噪声滤波器，`hand_tuned` 指手动设定噪声滤波器，`adaptive` 指历史在线观测噪声滤波器；`corrected_outlet_original_states` 指只修正出口公式，`corrected_outlet_corrected_states` 指同时使用已重建初态。每项原始记录位于 `hpc/plain_receipts_001/numerical_impact/runs/<身份>__preflight_attempt01/completion.json`。

| 精确身份 | 配置摘要 |
|---|---|
| `main_seed43__corrected_outlet_original_states` | `7c7ad97004b57cb8bd641f32dfe828d58366bb57a1fed20243d4d72241887186` |
| `main_seed43__corrected_outlet_corrected_states` | `16e96687e9b023277509b1cf265821651281cee51e4b23d2016efd0799648a35` |
| `main_seed44__corrected_outlet_original_states` | `5842dd66c77a41c27d3efb1d7c88f2c96b9808394bd93a74fb0465db9c2f7d4d` |
| `main_seed44__corrected_outlet_corrected_states` | `1c1563306889afc096c9ee3a0549ded9bd678d11ba746a1364720e2680538e8b` |
| `compact_seed42__corrected_outlet_original_states` | `482813aedfadacbe7ec0851fd2fedd6da49b541920fd006c328c982a2387a86a` |
| `compact_seed42__corrected_outlet_corrected_states` | `b215376698e8531fca53528dbfe74254e5a112d101e3ada589f1dfd2f6cb7be6` |
| `compact_seed43__corrected_outlet_original_states` | `2c894323ab686cc1aca7b6954ffbc0a47894a84f476ef151858a373ab590c478` |
| `compact_seed43__corrected_outlet_corrected_states` | `28a1e6e7528254aa211df622f6d1f70bc0711332bf2302026e57f6fe2a273e45` |
| `compact_seed44__corrected_outlet_original_states` | `2b140d037ecc63ed6c2d17877c0d85ae4cc67462cf21a136bf3ef93451263364` |
| `compact_seed44__corrected_outlet_corrected_states` | `a2b4a2de5afd6134f0f042f907eed7d2a5d74e212d52957fffc1c7a5fa5c3a64` |
| `learned_noise__corrected_outlet_original_states` | `91d5e2f47a6da1d528e9a27cac2e715c66d92c9ff79d2c5e8785ac76ee3c7dec` |
| `learned_noise__corrected_outlet_corrected_states` | `fd2e40b3f2c364cd0a6e04524d0214e480ac5a2e9ad179c460ab465cb801d1cb` |
| `hand_tuned__corrected_outlet_original_states` | `5cfb254c17261cdcd3b41cb2cf6977d0c329965b3146998c3fc8d5ffee416471` |
| `hand_tuned__corrected_outlet_corrected_states` | `c0ab420ee99ba0884508bd4151668019923eb15100c7fab4fe84e1996c4c91ba` |
| `adaptive__corrected_outlet_original_states` | `85bd332a585cbfd17f274b2efcc558d004ffd4a13607893c030572d7401583bb` |
| `adaptive__corrected_outlet_corrected_states` | `28348d93d03b4b591bd94f30dd6dd3d7f788fc3be84cd9bf0fbc3357625dff7e` |

## 修正初态的唯一来源与未验证边界

部署清单第1592—1605行冻结了一份验证初态和一份测试初态。验证初态文件摘要为 `70f0eb175d5dba5c6a7fc1290879a7346cff436f376a2ff92bc8db7433d24a1e`，已在各自验证预检中登记。测试初态唯一来源为：

`G:/github/pycharm/projects/kalmannet/docs/plans/wrr-hamid-evaluation-20260927-v1/test_states_001/test_corrected_cpu.pt`

唯一登记目的地为：

`/data1/home/sunyiq/kalmannet_wrr_closeout_20260928_v1/plain_preflight_v1/inputs/repo/docs/plans/wrr-hamid-evaluation-20260927-v1/test_states_001/test_corrected_cpu.pt`

文件大小316,764字节；文件摘要 `7c9f21f4ab69840a3f87064ff9aec15222f48b124ac61c6f65d21a39ac07df60`；登记张量摘要 `9a1ac3c04927733bf7d54f297e470f1fe718ab3ccbfe01ebd7852db76a8c3a3c`。同目录配对完成记录 `completion.json` 摘要 `8d6c01ace209541fafe28e2d36a146c5086ac95211bf964455453a72e6d9f382`。部署清单和交付目录引用一致；记录中的来源唯一且未变。**本轮未读取原始文件，所以未证明本地张量当前字节或远端目的文件当前字节未变；这正是交付核验仍须完成的部分。**

## 运行门槛与科学比较的区别

现有运行程序已经正确区分两者：`run_plain.py:111–117` 仅对原设置调用历史数值复现；修正设置必须先有对应原设置通过记录（`plain_evaluation.py:122–136`），自身继续核对全时期数据形状、计数、时间、输入和参数不变性（`run_plain.py:84–104、118–124、174–191`）。因此无需为修正设置新增“必须复制历史指标”的门槛，也无需改动冻结计算代码。

原设置仍严格保留五个无量纲指标差不超过0.000001、两项误差指标差不超过0.0001立方米/秒的复现要求，包含逐时效与两个未来12小时时段（`plain_evaluation.py:140–180`）。修正结果应计算“只修公式减原设置”“再改初态减只修公式”及“联合改变减原设置”的七指标和流量分组差异，当前0小时单列、未来1—12及13—24小时分别汇总；联合改变不是单因素实验。正式完成后仍须独立重算保存统计和核对共同评价域，不能用运行完成状态替代效果验收。

## 必须保留的失败、限制与资源边界

- 预检作业228835仍为 `FAILED`、退出码 `127:0`、耗时928秒；原运输记录第5—7、102行保留了最终状态查询缺少 `libreadline.so.6` 的错误。运输记录摘要本轮重核为 `7a693527175ae4d6e00e5affb8d7765c2c686e7beb7fe78e90277feeb85c8765`。既有独立审核证明错误发生在27项完成标记之后，不得改写调度状态，也不据此重复计算。
- 主网络随机初始化42的原设置数值复现失败继续保留，不加入16项；其两项修正分支不因其他模型验收而开放。
- 历史在线观测噪声滤波器缺失旧发布时间、观测和逐时刻计数数组。`plain_evaluation.py:169–180` 明确把其域标记为新重建并返回缺件列表。可保留受限的旧指标/时间域桥接，不能宣称恢复了旧数组。
- 总上限34种不同完整评价配置，已尝试16，未尝试18；本轮最多新增16种具备条件的修正配置，因而最多达到32种已尝试配置。新训练0；只读统计处理单独记账，不计为新模型评价。
- 集群仅使用既有独占根；最多同时一张显卡、4个处理器核心、`hgpu2p` 分区、排除 `ngu002`、每个作业最多6小时。启动前由主执行者重新核实队列、目标文件摘要和输出目录不存在；本报告不提供实时队列结论、不代替集群指南或启动器审核。

Hamid Moradkhani 是合作者。本报告不表示合作者接受、稿件可交付、方法优越或任何新科学结论。
