# Uninstrumented frozen-model sensitivity protocol

Status: implementation candidate; no real model or dataset has been evaluated by its author. An independent implementation review and a separate real, target-environment preflight acceptance are required. This is not acceptance of any earlier counted/captured route.

## Fixed scope and scientific use

- Exactly 27 model/setting combinations: three saved main-model seeds, three saved compact-model seeds, learned noise, hand-tuned noise and the historically selected adaptive method; each uses original outlet/original states, corrected outlet/original states, corrected outlet/corrected states. Default training is zero. No checkpoint or setting is selected using test scores.
- The only physical-source comparison changes `overflow = hs > cd + 1.0` to `overflow = hs > cd`. The original physical source is hash-bound; the new implementation exposes no counter or recording attributes. Forward-sequence, forecast, learned-network, initialization and comparator arithmetic come from frozen source adapters. Old files are unchanged.
- Every actual model/setting receives two separately rebuilt repetitions on the first **256 validation windows**, with original historical loader batch size: 256 except adaptive 128 (two batches). The same batch size is used in formal scoring. These are preflight samples, not full-period reproduction and not new historical scores.
- Each preflight checks all six actual result tensors, dtype/finiteness, exact source observation and hour mapping, 48 forecast positions, source columns and fixed initial states, unchanged learned parameters, and byte-identical repeats within the actual environment. No test tensor is allowed in preflight.
- Original-outlet/full-test scores must first reproduce each model's existing full-period scores within 1e-6 for dimensionless metrics and 1e-4 cubic metres per second for root mean squared error and mean absolute error. Seven metrics at all 25 saved lead positions and the 1–12/13–24 hour averages are checked. Archived domain/count/observation arrays are checked where available; the historical adaptive model lacks these arrays, and the receipt explicitly retains that provenance limitation.
- Each corrected formal case additionally requires its own accepted preflight and that same model's successful original full-period receipt, with identical deployed manifest, code bindings and environment. Failed original reproduction stops that model's corrected cases; it does not erase old evidence or declare every historical score false.
- Full test domain: 15,780 hourly rows, 14,981 windows of width 800, 48 propagation positions including current time, 753 issue positions/window, 15,733 distinct issue hours, 11,280,693 pairs/retained lead; save leads 0–24. Sufficient statistics have shape (15733,25,8). Overlapping multiplicities are checked exactly. Preserved grouped evaluation uses the frozen readiness contract. It is sensitivity on the same historical period, not unseen-period generalization.
- No currently inspected old preflight qualifies to skip a new model/setting: old gates used different counted/captured routes or host environments. Existing archived statistics supply original-score reference evidence, not acceptance of a corrected route. Any future identical-input evidence reuse must be explicitly registered and independently accepted; this driver currently executes all 27 requested preflights.

## Sources and portable deployment

`code/vendor/` contains unchanged copies of the old neural/comparator runtime, evaluator and diagnostic source. Importing the diagnostic helper does not enable its recording path. The wrapper calls only uninstrumented execution and rejects observer attributes. The frozen source manifest was verified as text/JSON/YAML only; neither manifest preparation nor dependency enumeration opens a tensor.

Prepare local manifest and dependency inventory, using a fresh output name if either exists:

```text
python -B code/build_manifest.py --repo REPOSITORY --output protocol/local_manifest.json
python -B code/deployment_inventory.py --manifest protocol/local_manifest.json --output protocol/deployment_inventory.json
```

Inventory groups separate code, source/metadata, validation tensors, checkpoints and formal-only inputs. First preflight needs all bound source/metadata, validation tensors and only its selected checkpoint. Formal-only inputs can be absent and are not opened at preflight. The copied directory structure matters to sealed imports: preserve original relative structure under the selected deployed evidence root.

To relocate, pass a JSON object of old absolute path prefixes to new absolute prefixes to `build_manifest.py --relocations FILE --numpy-version 2.3.3`. Longest prefix wins, for dictionary keys as well as values; SHA-256 values do not change. All unmatched Windows prefixes must be mapped before Linux deployment. Expected versions are Python 3.11.13, PyTorch 2.4.0, and NumPy 2.3.2 locally or explicitly 2.3.3 in the deployed manifest. Platform change invalidates old acceptance. The manifest's `output_root` must map to the new exclusive run root; create that root, never an individual run directory, beforehand.

## Invocation and admission

One case per fresh process; each invocation claims a previously nonexistent output directory below manifest `output_root` and refuses writes outside it. Different configurations and technical retry attempts must have separate registered identifiers/directories. Preflight and formal output directories are separate stages of one registered configuration. Do not edit code/manifest/configuration after admission; changes invalidate acceptance and require a new reviewed attempt.

```text
python -B code/run_plain.py --stage preflight --manifest deployed_manifest.json --case main_seed42__original_outlet_original_states --output RUN_ROOT/registered_case_preflight_attempt01
python -B code/run_plain.py --stage formal --manifest deployed_manifest.json --case main_seed42__original_outlet_original_states --output RUN_ROOT/registered_case_formal_attempt01 --acceptance independent_acceptance.json
```

Preflight state `PLAIN_PREFLIGHT_PASS_PENDING_REVIEW` is not permission to score. Independently create an acceptance JSON only after reviewing that case's actual completion, source/parameter/data identities, import/load ledgers, exact target mapping, resources and repeated predictions:

```json
{
  "state": "PLAIN_EVALUATION_ACCEPTED",
  "open_critical_important_findings": 0,
  "reviewer": "actual independent reviewer identity",
  "review_record": {"path": "actual review file", "sha256": "actual SHA256"},
  "manifest_sha256": "actual deployed manifest SHA256",
  "case_id": "the exact case being admitted",
  "preflight_receipt": {"path": "that case preflight completion.json", "sha256": "actual SHA256"}
}
```

Corrected formal cases also require `historical_original_receipt: {"path": "same model original-setting formal completion.json", "sha256": "actual SHA256"}`. Formal admission binds the complete evaluator code inventory and 21 actual numerical environment fields from preflight, including executable, hardware, library versions, precision settings and batch size. Acceptance is checked before runtime setup; environment equality is checked before any test tensor hash/load. A tensor allowlist blocks unregistered data/checkpoints; optimizer/backward calls are disabled.

## Outcomes, failure handling and resource estimate

Every attempt preserves running/completion or failure, environment, source-import/tensor-load ledgers and peak device allocation/reservation. A formal completion also binds metrics and sufficient-statistic files by digest. Reproduction failure preserves the newly computed statistics and provisional metrics but does not mark a completed accepted score. No automatic retry, fallback tolerance, changed batch size, source substitution, training or alternative model is implemented.

The CPU synthetic suite checks acceptance failures, precise one-line physical-source transformation, actual time mapping, nonfinite forecasts, final short batches and directly known error/count values. It does not validate actual model speed, GPU memory demand or historical score reproduction. Runtime and peak allocation can only be estimated from real per-method target-host preflights, followed by observed full-run batches; a 256-window estimate is provisional and is not a guaranteed completion time.
