"""CPU-only synthetic tests. No real datasets, checkpoints, CUDA or remote access."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from types import SimpleNamespace

os.environ['CUDA_VISIBLE_DEVICES'] = ''
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'code'))
from plain_runtime import fingerprint, plain_physics_text, sha, write_json
from plain_evaluation import METRICS, historical_bridge, require_acceptance, score_dataset, validate_result
from build_manifest import relocate


class Gates(unittest.TestCase):
    def setUp(self):
        scratch = ROOT/'tests'/'scratch'
        scratch.mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(dir=scratch)
        self.root = Path(self.temp.name)
        self.case = {'case_id':'main_seed42__original_outlet_original_states','variant':'original_outlet_original_states','batch_size':256}
        self.manifest = {'cases':[self.case]}
        self.manifest_path = self.root/'manifest.json'
        write_json(self.manifest_path,self.manifest)
        self.code = {'driver.py':'a'*64}
        self.preflight = dict(state='PLAIN_PREFLIGHT_PASS_PENDING_REVIEW',case_fingerprint=fingerprint(self.case),
            manifest_sha256=sha(self.manifest_path),code_bindings=self.code,test_tensor_reads=0,
            repeat_bitwise_equal=True,time_mapping_passed=True,environment={'gpu':'synthetic'})
        self.review = self.root/'review.json'
        write_json(self.review, {'finding_count':0})

    def tearDown(self):
        self.temp.cleanup()

    def receipt(self, **overrides):
        pre = self.root/'preflight.json'
        write_json(pre,self.preflight)
        receipt = dict(state='PLAIN_EVALUATION_ACCEPTED',open_critical_important_findings=0,reviewer='synthetic reviewer',
            review_record={'path':str(self.review),'sha256':sha(self.review)},manifest_sha256=sha(self.manifest_path),
            case_id=self.case['case_id'],preflight_receipt={'path':str(pre),'sha256':sha(pre)})
        receipt.update(overrides)
        path = self.root/'acceptance.json'
        write_json(path,receipt)
        return path

    def gate(self,path):
        return require_acceptance(self.case,self.manifest,self.manifest_path,path,self.code)

    def test_valid_independent_exact_case_acceptance(self):
        self.assertEqual(self.gate(self.receipt()),{'gpu':'synthetic'})

    def test_missing_findings_is_rejected(self):
        with self.assertRaises(ValueError):
            self.gate(self.receipt(open_critical_important_findings=None))

    def test_missing_reviewer_is_rejected(self):
        with self.assertRaises(ValueError):
            self.gate(self.receipt(reviewer=''))

    def test_different_manifest_is_rejected(self):
        with self.assertRaises(ValueError):
            self.gate(self.receipt(manifest_sha256='0'*64))

    def test_case_change_invalidates_preflight(self):
        path=self.receipt()
        self.case['batch_size']=128
        with self.assertRaises(ValueError): self.gate(path)

    def test_implementation_change_invalidates_preflight(self):
        path=self.receipt()
        self.code={'driver.py':'b'*64}
        with self.assertRaises(ValueError): self.gate(path)

    def test_test_read_in_preflight_is_rejected(self):
        self.preflight['test_tensor_reads']=1
        with self.assertRaises(ValueError): self.gate(self.receipt())

    def test_failed_time_mapping_is_rejected(self):
        self.preflight['time_mapping_passed']=False
        with self.assertRaises(ValueError): self.gate(self.receipt())

    def test_failed_repeat_is_rejected(self):
        self.preflight['repeat_bitwise_equal']=False
        with self.assertRaises(ValueError): self.gate(self.receipt())

    def test_corrected_requires_original_bridge(self):
        self.case['variant']='corrected_outlet_original_states'
        self.case['case_id']='main_seed42__corrected_outlet_original_states'
        self.preflight['case_fingerprint']=fingerprint(self.case)
        with self.assertRaisesRegex(ValueError,'original full-period'):
            self.gate(self.receipt())

    def test_physical_repair_is_exact_one_line(self):
        text='def f(hs, cd):\n        overflow = hs > cd + 1.0\n        return overflow\n'
        self.assertEqual(plain_physics_text(text,False),text)
        self.assertEqual(plain_physics_text(text,True),text.replace('hs > cd + 1.0','hs > cd'))

    def test_physical_repair_rejects_observer(self):
        with self.assertRaises(ValueError):
            plain_physics_text('def f():\n        overflow = hs > cd + 1.0\n        audit_q_calls = 0\n',True)

    def test_physical_repair_rejects_ambiguous_match(self):
        with self.assertRaises(ValueError): plain_physics_text('        overflow = hs > cd + 1.0\n'*2,True)

    def test_relocations_use_longest_prefix_and_preserve_sha(self):
        self.assertEqual(relocate({'G:/x/a':'G:\\x\\y\\b','sha':'f'*64},{'G:/x':'/new','G:/x/y':'/special'}),
                         {'/new/a':'/special/b','sha':'f'*64})

    def test_outputs_are_exclusive(self):
        path=self.root/'record.json'
        write_json(path,{'first':1})
        with self.assertRaises(FileExistsError): write_json(path,{'replacement':2})


class SyntheticForecast(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import numpy as np
        import torch
        cls.np,cls.torch=np,torch
        torch.set_default_device('cpu')
        # Locate only frozen statistics source, never any data/checkpoint.
        repo=Path(__file__).resolve().parents[5]
        source=repo/'artifacts/wrr_selected_model_results_20260920_v1/source/protocol/statistics_core.py'
        spec=importlib.util.spec_from_file_location('synthetic_statistics',source)
        cls.statistics=importlib.util.module_from_spec(spec);spec.loader.exec_module(cls.statistics)

    def setUp(self):
        torch=self.torch
        class Dataset:
            window_size=8
            qobs=torch.arange(1,15,dtype=torch.float32,device='cpu')[:,None]
            tm_hours=torch.arange(101,115,dtype=torch.float32,device='cpu')[:,None]
            def __len__(self): return len(self.qobs)-self.window_size+1
            def __getitem__(self,i):
                return {k:getattr(self,k)[i:i+self.window_size].T for k in ('qobs','tm_hours')}
        self.ds=Dataset()
        self.core=SimpleNamespace(rearrange_data_unfold=lambda x,h:x[:,0,:].unfold(1,h,1))

    def infer(self,batch,h=3):
        torch=self.torch
        obs,hours=batch['qobs'],batch['tm_hours']
        pred=self.core.rearrange_data_unfold(obs,h).reshape(-1,1,h)+0.25
        return dict(observation=obs,hours=hours,updated=torch.zeros((len(obs),5,8),device='cpu'),
                    outputs=obs.clone(),forecast_states=torch.zeros((len(pred),5,h),device='cpu'),predictions=pred)

    def batch(self):
        from torch.utils.data import default_collate
        return default_collate([self.ds[i] for i in (0,1)])

    def test_actual_issue_target_mapping(self):
        pred,target,ids=validate_result(self.infer(self.batch()),self.ds,self.core,[0,1],3,2)
        self.np.testing.assert_allclose(pred-target,.25)
        self.assertEqual(ids.tolist(),list(range(6))+list(range(1,7)))

    def test_wrong_hour_is_rejected(self):
        result=self.infer(self.batch()); result['hours']=result['hours']+1
        with self.assertRaisesRegex(ValueError,'time batch'): validate_result(result,self.ds,self.core,[0,1],3,2)

    def test_nonfinite_forecast_is_rejected(self):
        result=self.infer(self.batch());result['predictions'][0,0,0]=float('nan')
        with self.assertRaisesRegex(ValueError,'Nonfinite'): validate_result(result,self.ds,self.core,[0,1],3,2)

    def test_last_short_batch_full_statistics_match_direct_error(self):
        stats,obs,hours,result=score_dataset(SimpleNamespace(core=self.core),self.ds,self.infer,self.statistics,3,3,2)
        self.assertEqual(result['batches'],3)
        self.assertEqual(result['pairs_per_lead'],42)
        self.np.testing.assert_allclose(result['metrics']['rmse'],[.25,.25])
        self.np.testing.assert_allclose(result['metrics']['mae'],[.25,.25])
        self.np.testing.assert_array_equal(stats[:,0,0],self.np.convolve(self.np.ones(7),self.np.ones(6)))


if __name__ == '__main__':
    unittest.main(verbosity=2)
