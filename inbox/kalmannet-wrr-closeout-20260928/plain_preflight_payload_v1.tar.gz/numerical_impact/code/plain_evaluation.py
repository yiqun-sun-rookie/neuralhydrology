"""Shared uninstrumented sufficient-statistic scoring and fail-closed acceptance."""
from pathlib import Path
import time

from plain_runtime import fingerprint, read_json, sha, verify


METRICS = ('nse', 'rmse', 'mae', 'kge', 'correlation', 'variability_ratio', 'bias_ratio')
CONVERSION = 957000 / 3600


def validate_result(result, dataset, core, window_indices, forecast_positions=48, retain_positions=25):
    import numpy as np
    import torch
    windows = np.asarray(window_indices, dtype=np.int64)
    width, count = dataset.window_size, len(windows)
    issues = width - forecast_positions + 1
    if not 1 <= retain_positions <= forecast_positions <= width or count == 0:
        raise ValueError('Invalid forecast geometry')
    for name, shape in [('observation', (count, 1, width)), ('hours', (count, 1, width)),
                        ('updated', (count, 5, width)), ('outputs', (count, 1, width))]:
        if tuple(result[name].shape) != shape:
            raise ValueError('Actual trajectory shape mismatch: ' + name)
    if tuple(result['predictions'].shape) not in ((count*issues, 1, forecast_positions), (count*issues, forecast_positions)):
        raise ValueError('Prediction position geometry mismatch')
    if result['forecast_states'] is None or tuple(result['forecast_states'].shape) != (count*issues, 5, forecast_positions):
        raise ValueError('Forecast state position geometry mismatch')
    for name in ('updated', 'outputs', 'forecast_states', 'predictions', 'observation', 'hours'):
        if result[name].dtype != torch.float32 or not torch.isfinite(result[name]).all():
            raise ValueError('Nonfinite or non-float32 actual output: ' + name)
    obs = dataset.qobs.detach().cpu().numpy().reshape(-1)
    hours = dataset.tm_hours.detach().cpu().numpy().reshape(-1).astype(np.float64)
    rows = windows[:, None] + np.arange(width)[None, :]
    if not np.array_equal(result['observation'][:, 0, :].detach().cpu().numpy(), obs[rows]):
        raise ValueError('Actual observation batch differs from registered source')
    if not np.array_equal(result['hours'][:, 0, :].detach().cpu().numpy(), hours[rows]):
        raise ValueError('Actual time batch differs from registered source')
    target = core.rearrange_data_unfold(result['observation'], forecast_positions)
    target_hours = core.rearrange_data_unfold(result['hours'], forecast_positions)
    if tuple(target.shape) != (count, issues, forecast_positions) or target_hours.shape != target.shape:
        raise ValueError('Target unfolding geometry mismatch')
    target = target.detach().cpu().numpy().reshape(-1, forecast_positions)
    target_hours = target_hours.detach().cpu().numpy().reshape(-1, forecast_positions)
    ids = (windows[:, None] + np.arange(issues)[None, :]).ravel()
    positions = ids[:, None] + np.arange(forecast_positions)[None, :]
    if not np.array_equal(target, obs[positions]) or not np.array_equal(target_hours, hours[positions]):
        raise ValueError('Actual targets do not map to issue plus lead')
    if not np.all(target_hours - hours[ids, None] == np.arange(forecast_positions)[None, :]):
        raise ValueError('Target hours are not contiguous lead positions')
    pred = result['predictions'].detach().cpu().numpy().reshape(-1, forecast_positions)
    return pred[:, :retain_positions], target[:, :retain_positions], ids


def score_dataset(runtime, dataset, infer_fn, statistics, batch_size, forecast_positions=48, retain_positions=25):
    """Return (stats, obs, hours, summary); caller controls all model and file access."""
    import numpy as np
    from torch.utils.data import DataLoader
    n_windows = len(dataset)
    issues_per_window = dataset.window_size - forecast_positions + 1
    n_issues = len(dataset.qobs) - forecast_positions + 1
    accumulator = statistics.IssueAccumulator(n_issues, retain_positions)
    start = time.perf_counter()
    cursor, batches = 0, 0
    for batch in DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=0, drop_last=False):
        result = infer_fn(batch)
        size = batch['qobs'].shape[0]
        pred, target, ids = validate_result(result, dataset, runtime.core, list(range(cursor, cursor+size)),
                                            forecast_positions, retain_positions)
        accumulator.update(pred, target, ids)
        cursor += size
        batches += 1
        del result
        if batches % 5 == 0 or cursor == n_windows:
            print(f'FORECAST_WINDOWS {cursor}/{n_windows}', flush=True)
    stats = accumulator.stats
    multiplicity = np.convolve(np.ones(n_windows, dtype=np.int64), np.ones(issues_per_window, dtype=np.int64))
    if cursor != n_windows or stats.shape != (n_issues, retain_positions, 8):
        raise ValueError('Incomplete full-period output')
    if not np.array_equal(stats[:, :, 0], np.broadcast_to(multiplicity[:, None], (n_issues, retain_positions))):
        raise ValueError('Issue-level multiplicities differ from the registered overlapping windows')
    if not np.all(stats.sum(axis=0)[:, 0] == n_windows*issues_per_window):
        raise ValueError('Full-period forecast pair count mismatch')
    values = statistics.metrics(stats.sum(axis=0))
    if set(values) != set(METRICS) or not all(np.isfinite(v).all() for v in values.values()):
        raise ValueError('Invalid complete metrics')
    summary = dict(metrics={k: v.tolist() for k, v in values.items()},
                   rmse_m3s=(values['rmse']*CONVERSION).tolist(), mae_m3s=(values['mae']*CONVERSION).tolist(),
                   n_windows=n_windows, batches=batches, n_issue_hours=n_issues,
                   issues_per_window=issues_per_window, pairs_per_lead=int(n_windows*issues_per_window),
                   actual_leads=list(range(retain_positions)), propagation_positions=forecast_positions,
                   seconds=time.perf_counter()-start)
    obs = dataset.qobs.detach().cpu().numpy().reshape(-1)
    hours = dataset.tm_hours.detach().cpu().numpy().reshape(-1).astype(np.float64)
    return stats, obs, hours, summary


def require_acceptance(case, manifest, manifest_path, acceptance_path, code_bindings):
    """Before any test read/hash: exact manifest, case, code, preflight, independent review."""
    receipt = read_json(acceptance_path)
    if (receipt.get('state') != 'PLAIN_EVALUATION_ACCEPTED' or
            type(receipt.get('open_critical_important_findings')) is not int or
            receipt['open_critical_important_findings'] != 0):
        raise ValueError('Explicit independent acceptance missing')
    if not receipt.get('reviewer') or not receipt.get('review_record'):
        raise ValueError('Named independent review is required')
    verify(receipt['review_record']['path'], receipt['review_record']['sha256'])
    if receipt.get('manifest_sha256') != sha(manifest_path) or receipt.get('case_id') != case['case_id']:
        raise ValueError('Acceptance manifest or case mismatch')
    ref = receipt['preflight_receipt']
    verify(ref['path'], ref['sha256'])
    preflight = read_json(ref['path'])
    if (preflight.get('state') != 'PLAIN_PREFLIGHT_PASS_PENDING_REVIEW' or
            preflight.get('case_fingerprint') != fingerprint(case) or
            preflight.get('manifest_sha256') != sha(manifest_path) or
            preflight.get('code_bindings') != code_bindings or
            preflight.get('test_tensor_reads') != 0 or
            preflight.get('repeat_bitwise_equal') is not True or
            preflight.get('time_mapping_passed') is not True):
        raise ValueError('Case lacks matching successful plain preflight')
    if not isinstance(preflight.get('environment'), dict):
        raise ValueError('Missing preflight environment')
    if case['variant'] != 'original_outlet_original_states':
        original_ref = receipt.get('historical_original_receipt')
        if not original_ref:
            raise ValueError('Corrected branch requires separately accepted original full-period bridge')
        verify(original_ref['path'], original_ref['sha256'])
        original = read_json(original_ref['path'])
        required_id = case['case_id'].split('__')[0] + '__original_outlet_original_states'
        expected_case = next(c for c in manifest['cases'] if c['case_id'] == required_id)
        if (original.get('state') != 'PLAIN_EVALUATION_COMPLETE' or original.get('case_fingerprint') != fingerprint(expected_case)
                or original.get('manifest_sha256') != sha(manifest_path) or original.get('code_bindings') != code_bindings
                or original.get('historical_reproduction', {}).get('passed') is not True
                or original.get('environment') != preflight['environment']):
            raise ValueError('Original bridge identity/code/environment does not cover corrected case')
        if not original.get('artifacts'):
            raise ValueError('Original bridge has no bound prediction statistics')
    return preflight['environment']


def historical_bridge(case, values, stats, obs, hours):
    """Compare all seven fields/period means; archived-array absence remains explicit."""
    import numpy as np
    reference = case['historical_reference']
    verify(reference['metrics_path'], reference['metrics_sha256'])
    saved = read_json(reference['metrics_path'])
    for key in reference.get('metric_keys', []):
        saved = saved[key]
    old_units = reference['error_units']
    differences, periods = {}, {}
    for key in METRICS:
        current, old = np.asarray(values[key]), np.asarray(saved[key])
        if current.shape != (25,) or old.shape != (25,) or not np.isfinite(old).all():
            raise ValueError('Historical full per-lead metrics missing: ' + key)
        factor = CONVERSION if key in ('rmse', 'mae') else 1.
        old_factor = 1. if old_units == 'm3/s' and key in ('rmse', 'mae') else factor
        delta = current*factor-old*old_factor
        differences[key] = float(np.max(np.abs(delta)))
        periods[key] = {label: float(abs(delta[a:b].mean())) for label,a,b in [('1_12',1,13),('13_24',13,25)]}
    arrays = reference.get('statistics_path')
    if arrays:
        verify(arrays, reference['statistics_sha256'])
        with np.load(arrays, allow_pickle=False) as old:
            for name, current in [('issue_hours', hours[:15733]), ('observation', obs), ('actual_leads', np.arange(25))]:
                if not np.array_equal(old[name], current):
                    raise ValueError('Historical exact domain mismatch: ' + name)
            if not np.array_equal(old['stats'][:, :, :3], stats[:, :, :3]):
                raise ValueError('Historical counts/observation sufficient statistics mismatch')
        provenance = 'archived statistics domain checked'
    else:
        domain = reference['frozen_missing_array_domain']
        if (len(hours) != 15780 or not np.all(np.diff(hours) == 1) or
                hours[0] != domain['first_hour'] or hours[-1] != domain['last_hour'] or
                not np.all(stats.sum(axis=0)[:, 0] == 11280693)):
            raise ValueError('Reconstructed historical domain mismatch')
        provenance = 'new reconstruction; historical issue/observation arrays unavailable'
    passed = all(differences[k] <= (1e-4 if k in ('rmse','mae') else 1e-6) and
                 max(periods[k].values()) <= (1e-4 if k in ('rmse','mae') else 1e-6) for k in METRICS)
    return dict(passed=passed, maximum_absolute_differences=differences, period_absolute_differences=periods,
                error_difference_unit='m3/s', dimensionless_tolerance=1e-6, error_tolerance_m3s=1e-4,
                provenance=provenance, unavailable_original_arrays=[] if arrays else ['issue_hours','observation','per_issue_counts'])
