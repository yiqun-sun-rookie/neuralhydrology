"""Bindings for prediction-only evaluation; importing this file never loads tensors."""
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import sys
from types import SimpleNamespace


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def verify(path, expected):
    if sha(path) != expected:
        raise ValueError('Content fingerprint mismatch: ' + str(path))


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def write_json(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write('\n')


def plain_physics_text(original, corrected):
    """Exactly the original source, or the one registered outlet comparison edit."""
    before, after = '        overflow = hs > cd + 1.0', '        overflow = hs > cd'
    if original.count(before) != 1 or 'audit_q_' in original or 'audit_gap_' in original or 'capture_enabled' in original:
        raise ValueError('Unexpected plain physical source')
    text = original.replace(before, after, 1) if corrected else original
    ast.parse(text)
    return text


def bind_runtime(manifest):
    """Return (rt, cr, ev); all computation comes from explicitly hash-bound sources.

    Required keys: legacy_engine {name:{path,sha256}}, paths {FORMAL,PROBE,MAIN,
    COMPACT,SOURCE,REPO,RULES,ARCHIVE,REFRESH,PAPER,SELECTION,ADAPT_CONFIG},
    source_bindings {absolute_path:sha256}, archive_map {relative:actual_path}.
    Relocation changes the manifest and invalidates all previous acceptances.
    """
    sys.dont_write_bytecode = True
    for name, record in manifest['legacy_engine'].items():
        verify(record['path'], record['sha256'])
    for path, digest in manifest['source_bindings'].items():
        if Path(path).suffix.lower() in ('.pt', '.pth', '.npz', '.npy'):
            raise ValueError('Tensor files must not enter preflight source bindings')
        verify(path, digest)
    for name in ('neural_runtime', 'diagnostic_capture', 'evaluate_neural', 'comparator_runtime'):
        record = manifest['legacy_engine'][name + '.py']
        if name in sys.modules:
            if Path(sys.modules[name].__file__).resolve() != Path(record['path']).resolve():
                raise RuntimeError('Unrelated runtime already imported: ' + name)
            continue
        spec = importlib.util.spec_from_file_location(name, record['path'])
        mod = importlib.util.module_from_spec(spec)
        sys.modules[name] = mod
        spec.loader.exec_module(mod)
    rt, cr, ev = (sys.modules[n] for n in ('neural_runtime', 'comparator_runtime', 'evaluate_neural'))
    for name in ('FORMAL', 'PROBE', 'MAIN', 'COMPACT', 'SOURCE', 'REPO', 'RULES'):
        setattr(rt, name, Path(manifest['paths'][name]))
    for name in ('ARCHIVE', 'REFRESH', 'PAPER', 'SELECTION', 'ADAPT_CONFIG'):
        setattr(cr, name, Path(manifest['paths'][name]))
    cr._ARCHIVE_MAP = {name: Path(path) for name, path in manifest['archive_map'].items()}
    bound = {str(Path(path).resolve()): digest for path, digest in manifest['source_bindings'].items()}
    original_loader = rt.load_module
    generated = {}

    def load_bound(path, name=None):
        actual = Path(path).resolve()
        expected = generated.get(str(actual), bound.get(str(actual)))
        if expected is None:
            raise ValueError('Unbound dynamically loaded source: ' + str(actual))
        verify(actual, expected)
        return original_loader(actual, name)

    def seal(method='learned_noise'):
        if cr._SEALED is not None:
            return
        if any(n == 'filters' or n.startswith('filters.') or n == 'src' or n.startswith('src.') for n in sys.modules):
            raise RuntimeError('Fresh process required for a sealed comparator')
        overrides = {}
        if method == 'adaptive':
            overrides = {str((rt.MAIN / 'source' / rel).resolve()): Path(path)
                         for rel, path in manifest['archive_map'].items()}
        cr._SEALED = cr.SealedFinder(bound, overrides)
        sys.meta_path.insert(0, cr._SEALED)

    def physical(case, output, mode):
        if mode != 'plain':
            raise ValueError('Only uninstrumented physical execution is allowed')
        original = rt.PROBE / 'sources/walrus.py'
        verify(original, bound[str(original.resolve())])
        corrected = not case['variant'].startswith('original_outlet')
        dest = Path(output) / ('physical_corrected.py' if corrected else 'physical_original.py')
        text = plain_physics_text(original.read_text(encoding='utf-8'), corrected)
        with dest.open('x', encoding='utf-8', newline='\n') as stream:
            stream.write(text)
        generated[str(dest.resolve())] = sha(dest)
        return dest, dict(plain=True, only_outlet_condition_changed=corrected,
                          original_sha256=bound[str(original.resolve())], source_sha256=sha(dest))

    rt.load_module, cr.seal_imports, cr.physical_source = load_bound, seal, physical
    rt._plain_generated_sources = generated
    return rt, cr, ev


def build_runtime(case, output, rt, cr, device='cuda'):
    """Reuse the reviewed builders; redirect only the physical-source file."""
    if 'method' in case:
        runtime = cr.build_model(case, Path(output), mode='plain', device=device)
        infer_fn = lambda batch: cr.infer(runtime, batch, logging=False, forecast=True)
    else:
        physical, proof = cr.physical_source(case, Path(output), 'plain')
        loader = rt.load_module
        paths = {str((rt.PROBE/'sources/walrus.py').resolve()), str((rt.FORMAL/'sources/walrus_corrected.py').resolve())}
        def select_physical(path, name=None):
            return loader(physical if str(Path(path).resolve()) in paths else path, name)
        rt.load_module = select_physical
        try:
            runtime = rt.build_model(case, Path(output), instrumented=False, plain_physics=True)
        finally:
            rt.load_module = loader
        runtime.effective['plain_physical_source'] = proof
        infer_fn = lambda batch: rt.infer(runtime, batch, logging=False, forecast=True)
    if any(hasattr(runtime.hydro, name) for name in ('audit_q_calls', 'audit_gap_hits', 'capture_enabled')):
        raise ValueError('Observed/counted physical model entered prediction-only path')
    return runtime, infer_fn


def engine_environment(output, batch_size, expected_versions=None):
    """Freeze actual host environment; original historical host is not impersonated."""
    for key in ('TEMP', 'TMP', 'TORCH_HOME', 'TORCH_EXTENSIONS_DIR', 'MPLCONFIGDIR', 'XDG_CACHE_HOME', 'NUMBA_CACHE_DIR'):
        path = Path(output) / 'cache' / key
        path.mkdir(parents=True)
        os.environ[key] = str(path)
    sys.dont_write_bytecode = True
    for key in ('KF_DEBUG_CHECKS', 'FORECAST_START_LEAD', 'FORECAST_INCLUDE_CURRENT'):
        os.environ.pop(key, None)
    import numpy as np
    import torch
    versions = {'python': platform.python_version(), 'torch': str(torch.__version__), 'numpy': np.__version__}
    if expected_versions is not None and versions != expected_versions:
        raise ValueError('Runtime differs from deployed version manifest')
    if not torch.cuda.is_available() or torch.get_default_dtype() != torch.float32:
        raise ValueError('CUDA float32 required for actual inference')
    torch.manual_seed(42)
    torch.backends.cudnn.benchmark = False
    torch.set_grad_enabled(False)
    torch.cuda.reset_peak_memory_stats()
    def forbidden(*args, **kwargs):
        raise RuntimeError('Training/backward/optimizer execution forbidden')
    torch.Tensor.backward = forbidden
    torch.autograd.backward = forbidden
    torch.optim.Optimizer.__init__ = forbidden
    for value in vars(torch.optim).values():
        if isinstance(value, type) and issubclass(value, torch.optim.Optimizer):
            value.step = forbidden
    return dict(**versions, executable=sys.executable, cuda=torch.version.cuda,
                cudnn=torch.backends.cudnn.version(), device=torch.cuda.get_device_name(0),
                dtype='float32', batch_size=batch_size, seed=42, amp=False, compilation=False,
                cudnn_benchmark=False, matmul_precision=torch.get_float32_matmul_precision(),
                cudnn_enabled=torch.backends.cudnn.enabled, cudnn_deterministic=torch.backends.cudnn.deterministic,
                deterministic_algorithms=torch.are_deterministic_algorithms_enabled(),
                cuda_matmul_allow_tf32=torch.backends.cuda.matmul.allow_tf32,
                cudnn_allow_tf32=torch.backends.cudnn.allow_tf32,
                autocast_enabled=torch.is_autocast_enabled(), grad_enabled=torch.is_grad_enabled())


def load_bound_dataset(record, rt, state_record=None):
    import torch
    ds = rt.load_dataset(record['path'], record['sha256'])
    if len(ds.qobs) != record['rows'] or ds.window_size != 800 or len(ds) != record['rows']-799:
        raise ValueError('Dataset geometry mismatch')
    for name, digest in record['columns_sha256'].items():
        value = getattr(ds, name)
        if value.dtype != torch.float32 or not torch.isfinite(value).all():
            raise ValueError('Invalid input column: ' + name)
        if tensor_sha(value) != digest:
            raise ValueError('Dataset column mismatch: ' + name)
    if not torch.all(ds.tm_hours[1:] - ds.tm_hours[:-1] == 1):
        raise ValueError('Non-hourly source timeline')
    if state_record is not None:
        ds.states_all = rt.load_tensor(state_record['path'], state_record['sha256'], 'fixed_corrected_initial_states')
    if ds.states_all.shape != (record['rows'], 5) or ds.states_all.dtype != torch.float32 or not torch.isfinite(ds.states_all).all():
        raise ValueError('Invalid fixed initial states')
    if state_record and state_record.get('tensor_sha256') and tensor_sha(ds.states_all) != state_record['tensor_sha256']:
        raise ValueError('Initial-state tensor fingerprint mismatch')
    return ds


def tensor_sha(value):
    return hashlib.sha256(value.detach().cpu().contiguous().numpy().tobytes()).hexdigest()


def trajectory_fingerprints(result):
    return {key: {'shape': list(result[key].shape), 'dtype': str(result[key].dtype), 'sha256': tensor_sha(result[key])}
            for key in ('updated', 'outputs', 'forecast_states', 'predictions') if result[key] is not None}


def parameter_fingerprints(runtime):
    return {name: tensor_sha(value) for name, value in runtime.model.named_parameters()} if runtime.model is not None else {}
