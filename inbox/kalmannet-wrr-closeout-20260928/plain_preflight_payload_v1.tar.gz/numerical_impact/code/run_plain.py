"""One frozen model/setting per process. Formal test access requires reviewed preflight."""
import argparse
import gc
from pathlib import Path
import sys
import time
import traceback
sys.dont_write_bytecode = True

from plain_runtime import (bind_runtime, build_runtime, engine_environment, fingerprint,
                           load_bound_dataset, parameter_fingerprints, read_json, sha,
                           tensor_sha, trajectory_fingerprints, verify, write_json)
from plain_evaluation import historical_bridge, require_acceptance, score_dataset, validate_result


def code_bindings():
    root = Path(__file__).resolve().parent
    return {str(p): sha(p) for p in sorted(root.rglob('*.py'))}


def select_case(manifest, identifier):
    if manifest.get('schema') != 'plain_evaluation_v1' or manifest.get('training_allowed') is not False:
        raise ValueError('Not a reviewed prediction-only manifest')
    models = [f'{family}_seed{seed}' for family in ('main','compact') for seed in (42,43,44)] + ['learned_noise','hand_tuned','adaptive']
    variants = ['original_outlet_original_states','corrected_outlet_original_states','corrected_outlet_corrected_states']
    expected = {m+'__'+v for m in models for v in variants}
    if len(manifest['cases']) != 27 or {c['case_id'] for c in manifest['cases']} != expected:
        raise ValueError('Frozen 27-case identity set mismatch')
    case = next((c for c in manifest['cases'] if c['case_id'] == identifier), None)
    if case is None or case['variant'] not in variants or case['batch_size'] not in (128,256):
        raise ValueError('Unknown fixed model/setting')
    return case


def input_snapshot(dataset):
    return {name: tensor_sha(getattr(dataset, name)) for name in ('p','etpot','qobs','tm_hours','states_all')}


def preflight(case, manifest, output, rt, cr):
    import torch
    from torch.utils.data import default_collate
    state = manifest['corrected_states']['validation'] if case['variant'].endswith('corrected_states') else None
    dataset = load_bound_dataset(manifest['datasets']['validation'], rt, state)
    before_input = input_snapshot(dataset)
    indices = list(range(256))
    checks = []
    for phase in ('repeat_a','repeat_b'):
        folder = output/phase
        folder.mkdir()
        runtime, infer_fn = build_runtime(case, folder, rt, cr)
        before_params = parameter_fingerprints(runtime)
        write_json(folder/'model_start.json', dict(case_id=case['case_id'], input_fingerprints=before_input,
                                                  parameter_fingerprints=before_params))
        start = time.perf_counter()
        current = []
        for start_index in range(0, len(indices), case['batch_size']):
            batch_indices = indices[start_index:start_index+case['batch_size']]
            batch = default_collate([dataset[i] for i in batch_indices])
            result = infer_fn(batch)
            torch.cuda.synchronize()
            validate_result(result, dataset, runtime.core, batch_indices)
            current.append(dict(window_indices=batch_indices, arrays=trajectory_fingerprints(result)))
            del result
        if before_params != parameter_fingerprints(runtime) or before_input != input_snapshot(dataset):
            raise ValueError('Frozen input/learned parameters changed')
        checks.append(dict(phase=phase, arrays=current, seconds=time.perf_counter()-start,
                           time_mapping_passed=True, inputs_unchanged=True, parameters_unchanged=True,
                           effective_config=runtime.effective))
        write_json(folder/'completion.json', checks[-1])
        del runtime, infer_fn
        gc.collect()
        torch.cuda.empty_cache()
    if checks[0]['arrays'] != checks[1]['arrays']:
        raise ValueError('Repeated plain inference is not byte-identical')
    return dict(state='PLAIN_PREFLIGHT_PASS_PENDING_REVIEW', checks=checks,
                repeat_bitwise_equal=True, time_mapping_passed=True, test_tensor_reads=0,
                validation_window_indices=indices, forecast_positions=48, retained_positions=25,
                no_instrumentation=True, training_calls=0)


def formal(case, manifest, output, rt, cr, ev):
    import numpy as np
    import torch
    initial = manifest['initial_state_receipt']
    verify(initial['path'], initial['sha256'])
    evidence = read_json(initial['path'])
    if evidence.get('state') != 'PAIRED_TEST_STATES_COMPLETE' or not evidence['paired']['columns_exactly_unchanged']:
        raise ValueError('Paired initial-state evidence unavailable')
    if evidence['source_dataset']['sha256'] != manifest['datasets']['test']['sha256']:
        raise ValueError('Test dataset not bound to paired initial-state receipt')
    fixed = manifest['corrected_states']['test']
    if fixed['sha256'] != evidence['files']['test_corrected_cpu.pt']['sha256']:
        raise ValueError('Corrected test states not bound to their receipt')
    state = fixed if case['variant'].endswith('corrected_states') else None
    dataset = load_bound_dataset(manifest['datasets']['test'], rt, state)
    before_input = input_snapshot(dataset)
    runtime, infer_fn = build_runtime(case, output, rt, cr)
    before_params = parameter_fingerprints(runtime)
    write_json(output/'model_start.json', dict(case_id=case['case_id'], input_fingerprints=before_input,
                                              parameter_fingerprints=before_params))
    statistics = rt.frozen_statistics()
    stats, obs, hours, summary = score_dataset(runtime, dataset, infer_fn, statistics, case['batch_size'])
    if stats.shape != (15733,25,8) or summary['pairs_per_lead'] != 11280693 or summary['n_windows'] != 14981:
        raise ValueError('Frozen test domain mismatch')
    values = {k: np.asarray(v) for k,v in summary['metrics'].items()}
    contract = rt.read_json(rt.RULES)['evaluation_contract']
    summary['grouped_metrics'] = ev.grouped_metrics(stats, obs, contract, statistics)
    with (output/'issue_statistics.npz').open('xb') as stream:
        np.savez_compressed(stream, stats=stats, issue_hours=hours[:15733], observation=obs, actual_leads=np.arange(25))
    summary.update(effective_config=runtime.effective, input_fingerprints=before_input)
    if case['variant'] == 'original_outlet_original_states':
        bridge = historical_bridge(case, values, stats, obs, hours)
        summary['historical_reproduction'] = bridge
        write_json(output/'historical_reproduction.json', bridge)
        if not bridge['passed']:
            write_json(output/'metrics_before_failed_bridge.json', summary)
            raise ValueError('Full original-setting numerical bridge failed; corrected branches closed')
    if before_params != parameter_fingerprints(runtime) or before_input != input_snapshot(dataset):
        raise ValueError('Frozen input/learned parameters changed')
    torch.cuda.synchronize()
    write_json(output/'metrics.json', summary)
    summary.update(state='PLAIN_EVALUATION_COMPLETE', no_instrumentation=True, training_calls=0,
                   inputs_unchanged=True, learned_parameters_unchanged=True,
                   artifacts=[{'path':str(output/name),'sha256':sha(output/name)} for name in ('issue_statistics.npz','metrics.json')])
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', required=True, choices=['preflight','formal'])
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--case', required=True)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--acceptance', type=Path)
    args = parser.parse_args(argv)
    manifest_digest = sha(args.manifest)
    manifest = read_json(args.manifest)
    verify(args.manifest, manifest_digest)
    case = select_case(manifest, args.case)
    bindings = code_bindings()
    accepted_env = None
    if args.stage == 'formal':
        if args.acceptance is None:
            raise ValueError('Formal evaluation requires explicit acceptance; no test data accessed')
        accepted_env = require_acceptance(case, manifest, args.manifest, args.acceptance, bindings)
    output = args.output.resolve()
    output_root = Path(manifest['output_root']).resolve()
    if output == output_root or not output.is_relative_to(output_root):
        raise ValueError('Output must be an exclusive child of the manifest output root')
    output.mkdir(parents=False, exist_ok=False)
    start = time.perf_counter()
    write_json(output/'running.json', dict(case_id=case['case_id'], stage=args.stage, manifest_sha256=manifest_digest))
    rt = None
    try:
        rt, cr, ev = bind_runtime(manifest)
        split = 'validation' if args.stage == 'preflight' else 'test'
        allowed = [manifest['datasets'][split]['path']]
        if case['variant'].endswith('corrected_states'):
            allowed.append(manifest['corrected_states'][split]['path'])
        if 'checkpoint' in case:
            allowed.append(case['checkpoint'])
        if args.stage == 'formal':
            reference = case['historical_reference']
            if reference.get('statistics_path'):
                allowed.append(reference['statistics_path'])
            acceptance = read_json(args.acceptance)
            if acceptance.get('historical_original_receipt'):
                original = read_json(acceptance['historical_original_receipt']['path'])
                allowed.extend(r['path'] for r in original['artifacts'])
        rt.install_guard(output, allowed)
        environment = engine_environment(output, case['batch_size'], manifest['expected_versions'])
        write_json(output/'environment.json', environment)
        if args.stage == 'formal':
            rt.require_same_environment(environment, accepted_env)
            if acceptance.get('historical_original_receipt'):
                for record in original['artifacts']:
                    verify(record['path'], record['sha256'])
            result = formal(case, manifest, output, rt, cr, ev)
        else:
            result = preflight(case, manifest, output, rt, cr)
        if bindings != code_bindings():
            raise ValueError('Evaluator code changed during execution')
        verify(args.manifest, manifest_digest)
        for path,digest in manifest['source_bindings'].items():
            verify(path,digest)
        for key in ('checkpoint','config'):
            if key in case:
                verify(case[key],case[key+'_sha256'])
        verify(manifest['datasets'][split]['path'],manifest['datasets'][split]['sha256'])
        if case['variant'].endswith('corrected_states'):
            verify(manifest['corrected_states'][split]['path'],manifest['corrected_states'][split]['sha256'])
        result.update(case_id=case['case_id'], case_fingerprint=fingerprint(case), manifest_sha256=manifest_digest,
                      code_bindings=bindings, environment=environment, elapsed_seconds=time.perf_counter()-start)
        write_json(output/'completion.json', result)
        print(result['state'], case['case_id'], flush=True)
    except BaseException as error:
        write_json(output/'failure.json', dict(case_id=case['case_id'], stage=args.stage, error=repr(error), traceback=traceback.format_exc(),
                                               seconds=time.perf_counter()-start))
        raise
    finally:
        if rt:
            write_json(output/'import_ledger.json', rt.IMPORT_LEDGER)
            write_json(output/'load_ledger.json', rt.LOAD_LEDGER)
        torch = sys.modules.get('torch')
        ready = torch is not None and torch.cuda.is_initialized()
        write_json(output/'resources.json', dict(seconds=time.perf_counter()-start,
            peak_cuda_allocated=torch.cuda.max_memory_allocated() if ready else 0,
            peak_cuda_reserved=torch.cuda.max_memory_reserved() if ready else 0))


if __name__ == '__main__':
    main()
