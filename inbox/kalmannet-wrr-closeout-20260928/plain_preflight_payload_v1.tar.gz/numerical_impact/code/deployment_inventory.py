"""Enumerate source/metadata/tensor dependencies without opening any tensor."""
import argparse
from pathlib import Path
from plain_runtime import read_json, sha, write_json


def inventory(manifest):
    groups = {key: {} for key in ('code', 'source_metadata', 'validation_tensors', 'checkpoints', 'formal_only')}
    groups['source_metadata'].update(manifest['source_bindings'])
    for p in Path(__file__).resolve().parent.rglob('*.py'):
        groups['code'][str(p)] = sha(p)
    for record in manifest['legacy_engine'].values():
        groups['code'][record['path']] = record['sha256']
    for key in ('datasets', 'corrected_states'):
        record = manifest[key]['validation']
        groups['validation_tensors'][record['path']] = record['sha256']
        record = manifest[key]['test']
        groups['formal_only'][record['path']] = record['sha256']
    record = manifest['initial_state_receipt']
    groups['source_metadata'][record['path']] = record['sha256']
    for case in manifest['cases']:
        for name in ('config', 'selection'):
            if name in case:
                groups['source_metadata'][case[name]] = case[name+'_sha256']
        if 'checkpoint' in case:
            groups['checkpoints'][case['checkpoint']] = case['checkpoint_sha256']
        ref = case['historical_reference']
        groups['source_metadata'][ref['metrics_path']] = ref['metrics_sha256']
        if ref.get('statistics_path'):
            groups['formal_only'][ref['statistics_path']] = ref['statistics_sha256']
    return {'schema':'plain_dependency_inventory_v1', 'tensor_contents_read':False,
            'groups':groups, 'counts':{key:len(rows) for key,rows in groups.items()},
            'note':'Preserve directory structure and map every absolute prefix in the manifest; code hashes must be regenerated on the deployed host before acceptance.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    write_json(args.output, inventory(read_json(args.manifest)))


if __name__ == '__main__':
    main()
