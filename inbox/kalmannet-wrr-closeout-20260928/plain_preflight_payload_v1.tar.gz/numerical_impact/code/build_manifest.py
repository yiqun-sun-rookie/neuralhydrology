"""Create metadata-only local/deployed manifests; never open a tensor file."""
import argparse
import copy
from pathlib import Path
from plain_runtime import read_json, sha, verify, write_json


def normalize(path):
    return str(path).replace('\\', '/')


def relocate(value, mappings):
    if isinstance(value, list):
        return [relocate(v, mappings) for v in value]
    if isinstance(value, dict):
        return {relocate(k, mappings): relocate(v, mappings) for k, v in value.items()}
    if isinstance(value, str):
        original = normalize(value)
        for old, new in sorted(mappings.items(), key=lambda kv: -len(kv[0])):
            old, new = normalize(old).rstrip('/'), normalize(new).rstrip('/')
            if original == old or original.startswith(old + '/'):
                return new + original[len(old):]
        return original if ':/' in original else value
    return value


def build(repo):
    repo = Path(repo)
    old = repo/'docs/plans/wrr-hamid-evaluation-20260927-v1'
    here = Path(__file__).resolve().parent
    prior = repo/'docs/plans/wrr-hamid-weights-20260923-v1'
    formal, probe = prior/'formal_package_v3', prior/'probe_package_v2'
    main = repo/'artifacts/wrr_selected_model_results_20260920_v1'
    compact = repo/'artifacts/wrr_capacity_comparison_20260921_v1'
    source = main/'source/kalmannet'
    archive = Path('C:/Users/yiqun/.codex/worktrees/c7a4/kalmannet/artifacts/comment_112_signed_state_20260916/source_snapshot/test_comparison_20260915')
    entry_path = old/'test_artifacts/task4/preflight_001_learned_noise_original/entry_bindings.json'
    entry = read_json(entry_path)
    sources = dict(entry['sources'])
    sources[str(entry_path)] = sha(entry_path)
    for name, digest in read_json(formal/'manifest.json')['files'].items():
        if name.startswith('sources/'):
            sources[str(formal/name)] = digest
    statistics = main/'source/protocol/statistics_core.py'
    sources[str(statistics)] = sha(statistics)
    for path, digest in sources.items():
        if Path(path).suffix.lower() in ('.pt', '.pth', '.npz', '.npy'):
            raise ValueError('Manifest preparation must not open tensor files')
        verify(path, digest)
    neural = read_json(old/'test_artifacts/task3/preflight_002/case_registry.json')
    comparator = read_json(old/'test_artifacts/task4/preflight_001_learned_noise_original/case_registry.json')
    cases = [copy.deepcopy(c) for c in neural if c['family'] in ('main','compact')]
    cases += [copy.deepcopy(c) for c in comparator if c['method'] != 'open_loop']
    audit = {r['case']: r for r in read_json(old/'archived_statistics_audit_001.json')['cases']}
    paper = archive/'delivery_001/paper_values.json'
    for case in cases:
        case.setdefault('batch_size', 256)
        model = case['case_id'].split('__')[0]
        if model != 'adaptive':
            row = audit[model]
            case['historical_reference'] = dict(metrics_path=row['metric_path'], metrics_sha256=row['metric_sha256'],
                metric_keys=['metrics'], error_units='mm/hour', statistics_path=row['statistics_path'], statistics_sha256=row['statistics_sha256'])
        else:
            case['historical_reference'] = dict(metrics_path=str(paper), metrics_sha256=sha(paper),
                metric_keys=['metrics','adaptive'], error_units='m3/s',
                frozen_missing_array_domain={'first_hour':343622.,'last_hour':359401.})
        case['exp_id'] = 'original_impact__' + case['case_id']
    if len(cases) != 27 or len({c['case_id'] for c in cases}) != 27:
        raise ValueError('Expected 27 unique, frozen historical settings')
    protocol = read_json(formal/'protocol.json')
    val = protocol['data']['val']
    initial_path = old/'test_states_001/completion.json'
    initial = read_json(initial_path)
    validation = dict(path=str(repo/'data/processed/high_flow_aug'/val['name']), sha256=val['sha256'], rows=val['rows'], columns_sha256=val['columns_sha256'])
    test = dict(path=initial['source_dataset']['path'], sha256=initial['source_dataset']['sha256'], rows=15780,
                columns_sha256={k:r['sha256'] for k,r in initial['paired']['columns_before'].items()})
    corrected_test = initial['files']['test_corrected_cpu.pt']
    return dict(schema='plain_evaluation_v1', training_allowed=False, max_cases=27, cases=cases,
                output_root=str(here.parent/'runs'),
                expected_versions={'python':'3.11.13','torch':'2.4.0','numpy':'2.3.2'},
                legacy_engine={name:{'path':str(here/'vendor'/name),'sha256':sha(here/'vendor'/name)} for name in
                               ('neural_runtime.py','diagnostic_capture.py','evaluate_neural.py','comparator_runtime.py')},
                paths={k:str(v) for k,v in dict(FORMAL=formal,PROBE=probe,MAIN=main,COMPACT=compact,SOURCE=source,REPO=repo,
                    RULES=old.parent/'wrr-hamid-evaluation-readiness-20260927-v1/readiness_evidence.json',ARCHIVE=archive,
                    REFRESH=archive/'linked_diagnostics_003',PAPER=source/'draft/scripts/generate_paper_metrics.py',
                    SELECTION=repo/'artifacts/regge_adaptive_covariance_ukf_v1_validation/selection.json',
                    ADAPT_CONFIG=source/'experiments/optimize_hyper_parameters/adaptive_covariance_ukf_config.yaml').items()},
                source_bindings=sources, archive_map={r['relative']:r['actual'] for r in entry['proof']['relocations']},
                datasets={'validation':validation,'test':test},
                corrected_states={'validation':{'path':str(formal/'initial_states'/val['corrected_states_name']), 'sha256':val['corrected_states_sha256']},
                    'test':{'path':str(initial_path.parent/'test_corrected_cpu.pt'),'sha256':corrected_test['sha256'],'tensor_sha256':corrected_test['tensor']['sha256']}},
                initial_state_receipt={'path':str(initial_path),'sha256':sha(initial_path)},
                scientific_scope='Frozen-model sensitivity; no retraining, state capture or counter instrumentation; not a new unseen period.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--relocations', type=Path, help='Optional exact/prefix mapping after host paths are verified')
    parser.add_argument('--numpy-version', choices=['2.3.2','2.3.3'], default='2.3.2')
    args = parser.parse_args()
    manifest = build(args.repo)
    if args.relocations:
        manifest = relocate(manifest, read_json(args.relocations))
    manifest['expected_versions']['numpy'] = args.numpy_version
    write_json(args.output, manifest)


if __name__ == '__main__':
    main()
