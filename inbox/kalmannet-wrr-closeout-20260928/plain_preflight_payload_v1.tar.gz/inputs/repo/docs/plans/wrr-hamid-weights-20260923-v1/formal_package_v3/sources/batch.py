import os, time, math, torch
from probe_core import forward_sequence, system_model_forecast, rearrange_data_unfold
from probe_metrics import composite_loss
from probe_prepare import prepare_batch_data
GRAD_CLIP=1.0
REL_CLIP=0.05
NAN_BACKOFF=0.5
MAX_NAN_RESETS=3
class NumericalFailure(RuntimeError):
    pass
def _restore_safe_state(pipeline):
    raise NumericalFailure("Non-finite loss or gradient explosion; complete epoch replay required")

def run_one_batch(pipeline, batch, is_training, epoch, measure_time: bool=False, compute_metrics: bool=True):
    t0 = time.time() if measure_time else None
    p, ep, y_obs, state0, tm_hours = prepare_batch_data(batch, pipeline.args.device)
    control = torch.cat((p, ep), dim=1)
    current_batch_size = p.size(0)
    # 初始化knet_model
    pipeline.knet_model.batch_size = current_batch_size
    pipeline.knet_model.init_hidden_KNet()
    pipeline.knet_model.update_mode = True
    pipeline.knet_model.init_sequence(state0[:, :, 0], pipeline.sys_model.train_seq_len)

    # 计算可行窗口步数，若为 0 则跳过本 batch
    num_timesteps = y_obs.size(-1)
    # [WRR-HP-EXT] Forecast slots are lead 1..L hours (no analysis slot) when the switch is on (default on):
    # forecast L+1 slots (slot 0 == analysis h(x_{t|t})), then drop slot 0 in outputs, states and targets.
    _leads_from_one = os.getenv('KNET_FORECAST_LEADS_START_AT_ONE', '1') == '1'
    _L = pipeline.args.forecast_lead_time
    _L_fc = _L + 1 if _leads_from_one else _L
    feas_T = num_timesteps - _L_fc + 1
    if feas_T <= 0:
        if getattr(pipeline.args, 'debug_checks', False) or (os.getenv('KF_DEBUG_CHECKS', '0') == '1'):
            print(f"[SafeTrain] Empty window: T={num_timesteps} < L={pipeline.args.forecast_lead_time} at epoch {epoch}. skip batch.")
        # 统计
        if hasattr(pipeline, '_debug_stats'):
            pipeline._debug_stats['skipped_empty_window'] = pipeline._debug_stats.get('skipped_empty_window', 0) + 1
        step_time = (time.time()-t0) if measure_time else 0.0
        return 0.0, {}, 0, step_time

    # 前向update计算
    states_upd, outputs_upd = forward_sequence(pipeline, y_obs, control)

    # 预报计算
    states_forecast_flat, outputs_forecast_flat = system_model_forecast(sys_model=pipeline.sys_model,
                                                                        p=p, etpot=ep, states_updated=states_upd,
                                                                        lead_time=_L_fc)
    # 计算损失
    if pipeline.sys_model.n == 1:
        outputs_forecast_flat = outputs_forecast_flat.squeeze(1)
    y_future = rearrange_data_unfold(y_obs, _L_fc).reshape(-1, _L_fc)
    if _leads_from_one:
        # slot k (k = 1..L) is the k-hour-ahead forecast x_{t+k|t} paired with y_{t+k}
        outputs_forecast_flat = outputs_forecast_flat[:, 1:]
        states_forecast_flat = states_forecast_flat[:, :, 1:]
        y_future = y_future[:, 1:]

    # C) t = 0 的预测 / 观测
    upd_now = outputs_upd[:, 0, :feas_T].reshape(-1)  # [N]
    y_now = y_obs[:, 0, :feas_T].reshape(-1)  # [N]

    # ---------- 3. 组合损失 ----------
    # 从配置中读取损失类型，默认为 'mse'
    loss_type = getattr(pipeline.args, 'loss_type', 'mse')
    bp_loss, loss_dict = composite_loss(
        outputs_fc=outputs_forecast_flat,  # [N, L]
        y_future=y_future,  # [N, L]
        outputs_upd=upd_now,  # [N]
        y_now=y_now,  # [N]
        lambda_upd=pipeline.args.lambda_upd,
        high_flow_thr=pipeline.args.high_flow_thr,
        alpha_hf=pipeline.args.alpha_hf,
        delta_thr=pipeline.args.delta_thr,
        beta_rise=pipeline.args.beta_rise,
        use_log=pipeline.args.use_log,
        gamma_slope=pipeline.args.gamma_slope,
        loss_type=loss_type,  # 'mse', 'nse', or 'kge'
    )

    # ---------- 4. display metrics ----------
    if compute_metrics:
        # 显示指标不参与反向传播，no_grad 可减少显存和构图开销
        with torch.no_grad():
            display_loss = compute_display_metrics(
                outputs_forecast_flat,  # pred  [N, L]
                y_future,  # obs   [N, L]
                metrics=pipeline.display_metrics_list + ['nse_high'],
                lead_times=None,
                high_flow_thr=pipeline.args.high_flow_thr
            )
    else:
        display_loss = {}

    # 如果是训练模式，则反向传播、优化
    if is_training:
        # 0) 先检测 loss 数值
        if not torch.isfinite(bp_loss):
            print(f"[SafeTrain] NaN/Inf loss at epoch {epoch} ⇒ backoff LR ×{NAN_BACKOFF}")
            _restore_safe_state(pipeline)
            pipeline.nan_resets_left -= 1
            if hasattr(pipeline, '_debug_stats'):
                pipeline._debug_stats['skipped_nan_inf'] = pipeline._debug_stats.get('skipped_nan_inf', 0) + 1
            step_time = (time.time()-t0) if measure_time else 0.0
            return 0.0, {}, 0, step_time  # 跳过此 batch 统计

        pipeline.optimizer.zero_grad()
        bp_loss.backward()

        # 梯度裁剪
        grad_norm = torch.nn.utils.clip_grad_norm_(pipeline.knet_model.parameters(), max_norm=GRAD_CLIP)
        if grad_norm > 1:
            print(f"Warning: high gradient norm {grad_norm} detected at epoch {epoch}")
        # 如仍异常大，则回滚并降 LR
        if not math.isfinite(grad_norm) or grad_norm > 1e4:
            print(f"[SafeTrain] Grad explosion {grad_norm:.2e} at epoch {epoch}")
            _restore_safe_state(pipeline)
            pipeline.nan_resets_left -= 1
            if hasattr(pipeline, '_debug_stats'):
                pipeline._debug_stats['skipped_grad_explosion'] = pipeline._debug_stats.get('skipped_grad_explosion', 0) + 1
            step_time = (time.time()-t0) if measure_time else 0.0
            return 0.0, {}, 0, step_time

        cur_lr = pipeline.optimizer.param_groups[0]['lr']

        for p in pipeline.knet_model.parameters():
            if p.grad is None:
                continue

            # 计算当前参数平均幅度；加 eps 防 0
            mean_abs_w = p.data.abs().mean().clamp(min=1e-8)

            # 目标：lr * |grad| ≤ REL_CLIP * mean_abs_w
            max_grad_val = (REL_CLIP * mean_abs_w) / cur_lr

            p.grad.data.clamp_(-max_grad_val, max_grad_val)

        pipeline.optimizer.step()
        # _save_safe_state(pipeline)  # ← 无条件 【已移至 post_epoch_operations】
        pipeline.nan_resets_left = MAX_NAN_RESETS

    # ========== [新增] 如��是测试/验证模式且需要保存结果，追加到 pipeline.predictions ==========
    if (not is_training) and getattr(pipeline, 'save_predictions', False):
        # ---------- 1. 窗口化驱动/观测 ----------
        # [WRR-HP-EXT] windows are built with _L_fc and, when leads start at one, slot 0 is dropped so that
        # every saved window aligns with the forecast slots (lead 1..L).
        p_win = rearrange_data_unfold(p, _L_fc).squeeze(2)  # [B,T-L_fc+1,L_fc]
        ep_win = rearrange_data_unfold(ep, _L_fc).squeeze(2)
        y_win = rearrange_data_unfold(y_obs, _L_fc).squeeze(2)

        # ---------- 2. 窗口化时间戳 ----------
        tm_raw = tm_hours.squeeze(1) if tm_hours.dim() == 3 else tm_hours  # [B,T]
        tm_win = tm_raw.unfold(1, _L_fc, 1)  # [B,T-L_fc+1,L_fc]
        if _leads_from_one:
            p_win, ep_win, y_win, tm_win = p_win[:, :, 1:], ep_win[:, :, 1:], y_win[:, :, 1:], tm_win[:, :, 1:]

        # ---------- 3. 预测结果 reshape 成窗口格式 ----------
        states_fc_win = states_forecast_flat.reshape(
            current_batch_size, -1, pipeline.sys_model.m, _L
        )  # [B,T-L_fc+1,m,L]
        outputs_fc_win = outputs_forecast_flat.reshape(
            current_batch_size, -1, _L
        )  # [B,T-L_fc+1,L]

        # ---------- 4. 追加到 predictions ----------
        pipeline.predictions.append({
            "p_raw": p.detach().cpu(),
            "ep_raw": ep.detach().cpu(),
            "y_obs_raw": y_obs.detach().cpu(),
            "tm_hours_raw": tm_raw.detach().cpu(),
            "p_win": p_win.detach().cpu(),
            "ep_win": ep_win.detach().cpu(),
            "y_obs_win": y_win.detach().cpu(),
            "tm_hours_win": tm_win.detach().cpu(),
            "outputs_upd": outputs_upd.detach().cpu(),
            "states_upd": states_upd.detach().cpu(),
            "states_fc_win": states_fc_win.detach().cpu(),
            "outputs_fc_win": outputs_fc_win.detach().cpu(),
        })

    # 记录处理的 batch/samples
    if hasattr(pipeline, '_debug_stats') and current_batch_size > 0:
        pipeline._debug_stats['processed_batches'] = pipeline._debug_stats.get('processed_batches', 0) + 1
        pipeline._debug_stats['processed_samples'] = pipeline._debug_stats.get('processed_samples', 0) + int(current_batch_size)

    # 统一返回“批次总和”
    bp_loss_batch_sum = loss_dict['loss_total'] * current_batch_size
    # 对显示指标(此处只有 'nse')也做 batch_size 加权
    display_metrics_batch_sum = {}
    for k, v in display_loss.items():
        display_metrics_batch_sum[k] = v * current_batch_size  # => “该batch总和”

    step_time = (time.time()-t0) if measure_time else 0.0
    return bp_loss_batch_sum, display_metrics_batch_sum, current_batch_size, step_time
