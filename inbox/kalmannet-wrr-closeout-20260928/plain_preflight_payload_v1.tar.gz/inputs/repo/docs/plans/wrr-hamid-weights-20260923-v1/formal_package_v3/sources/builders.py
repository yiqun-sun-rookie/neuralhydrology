import os, math, torch
from types import SimpleNamespace
from probe_network import KalmanNet

def _to_tensor(v, device):
    """将标量 / list / tuple 转为 torch.tensor(float32)."""
    if isinstance(v, (list, tuple)):
        return torch.tensor([float(x) for x in v], dtype=torch.float32, device=device)
    try:
        return torch.tensor(float(v), dtype=torch.float32, device=device)
    except Exception:
        return torch.tensor([], dtype=torch.float32, device=device)

def _normalize_clamp_dict(cs_raw: dict | None, device: str):
    """规范化 clamp_scale 信息。
    预期结构 (可缺省):
      obs_diff_clamp: [lo, hi]
      obs_diff_scale: float
      obs_innov_diff_clamp: [lo, hi]
      obs_innov_diff_scale: float
      fw_update_diff_clamp: [[lo,hi], ...]  (每维一对)
      fw_update_diff_scale: [s1, s2, ...] 或标量
    返回: dict 或 None (若校验失败)
    """
    if not isinstance(cs_raw, dict):
        return None
    out = {}
    try:
        # 单/双端 clamp
        for k in [
            ("obs_diff_clamp", True),
            ("obs_diff_scale", False),
            ("obs_innov_diff_clamp", True),
            ("obs_innov_diff_scale", False),
        ]:
            name, is_pair = k
            if name in cs_raw:
                val = cs_raw[name]
                if is_pair and isinstance(val, (list, tuple)) and len(val) == 2:
                    out[name] = _to_tensor(val, device)
                elif not is_pair:
                    out[name] = _to_tensor(val, device)
        # fw_update (可能为多维)
        if "fw_update_diff_clamp" in cs_raw:
            fw_clamp = cs_raw["fw_update_diff_clamp"]
            if isinstance(fw_clamp, (list, tuple)) and all(isinstance(p, (list, tuple)) and len(p) == 2 for p in fw_clamp):
                out["fw_update_diff_clamp"] = torch.stack([_to_tensor(p, device) for p in fw_clamp])  # [D,2]
        if "fw_update_diff_scale" in cs_raw:
            fw_scale = cs_raw["fw_update_diff_scale"]
            if isinstance(fw_scale, (list, tuple)):
                out["fw_update_diff_scale"] = _to_tensor(fw_scale, device)
            else:
                out["fw_update_diff_scale"] = _to_tensor(fw_scale, device)
    except Exception:
        return None
    return out if out else None

def build_args(cfg, p_train, p_val):
    """
    把 YAML里的所有超参数展开为一个 SimpleNamespace。
    同时兼容KalmanNe和Trainable‑UKF 两种模型类型。
    """
    # ── 1. 数据集派生字段 ───────────────────────────────────────────
    train_seq_len  = p_train.shape[-1]
    seq_len_val    = p_val.shape[-1]
    batch_size     = cfg["dataloader"]["batch_size"]
    steps_per_epoch = max(1, math.ceil(len(p_train) / batch_size))

    # ── 2. YAML别名 ───────────────────────────────────────────────
    train_cfg   = cfg["training"]
    loss_cfg    = cfg["loss"]
    runtime_cfg = cfg["runtime"]
    instr_cfg   = cfg.get("instrumentation", {})

    model_type  = cfg["model"]["type"].lower()

    # KNet 专属
    knet_cfg = cfg["model"].get("knet", {})
    # UKF 专属
    ukf_cfg  = cfg["model"].get("trainable_ukf", {})

    # 读取调试开关：优先 runtime.debug_checks，其次环境变量 KF_DEBUG_CHECKS
    debug_checks = bool(runtime_cfg.get("debug_checks", False)) or (os.getenv("KF_DEBUG_CHECKS", "0") == "1")

    # ── 3. 组装 args ───────────────────────────────────────────────
    # Ensure in_mult_KNet is set for KalmanNet
    if model_type == "knet" and "in_mult_KNet" in knet_cfg:
        in_mult_KNet = knet_cfg.get("in_mult_KNet", 1)
    else:
        in_mult_KNet = 1  # Default value

    # 调试：打印从 cfg 读取的训练轮次
    # (移除冗余 debug: cfg.training.train_epochs)
    # Add in_mult_KNet to the namespace
    args = SimpleNamespace(
        # —— 数据长度 & 运行环境 ——
        train_seq_len   = train_seq_len,
        seq_len_val     = seq_len_val,
        steps_per_epoch = steps_per_epoch,
        n_batch         = batch_size,

        device   = runtime_cfg["device"],
        use_cuda = runtime_cfg["device"] == "cuda",
        use_amp  = runtime_cfg.get("use_amp", False),
        use_torch_compile = runtime_cfg.get("use_torch_compile", False),
        debug_checks = debug_checks,

        # —— 训练超参 ——
        model_type              = model_type,
        train_epochs            = train_cfg["train_epochs"],
        lr                      = train_cfg["learning_rate"],
        wd                      = train_cfg["weight_decay"],
        batch_display_interval  = train_cfg["batch_display_interval"],
        forecast_lead_time      = train_cfg["forecast_lead_time"], # NOTE: Fixed horizon. No dynamic curriculum logic in train loop.
        early_stopping          = train_cfg["early_stopping"],

        # —— Runtime 配置（包括 checkpoint 间隔） ——
    # checkpoint 保存间隔（若 YAML 未给出，则默认 20，而不是之前的 5）
    ckpt_interval           = runtime_cfg.get("ckpt_interval", 20),  # NOTE: will be cleaned to int below if tuple

        # —— 损失函数超参（直接展开 loss_cfg） ——
        **loss_cfg,
    )

    # === 模型专属字段 ===
    if model_type == "knet":
        # 安全获取 clamp 配置（可能旧 trial 缺失）
        clamp_cfg = knet_cfg.get("clamp_scale") or {}
        args.__dict__.update(
            d_hidden_Q           = knet_cfg.get("hidden_size", 32),
            d_hidden_Sigma       = knet_cfg.get("hidden_size", 32),
            num_layers_GRU_Q     = knet_cfg.get("num_layers", 1),
            num_layers_GRU_Sigma = knet_cfg.get("num_layers", 1),
            num_layers_GRU_S     = knet_cfg.get("num_layers", 1),
            dropout_prob         = knet_cfg.get("dropout", 0.0),
            in_mult_KNet         = knet_cfg.get("in_mult", 5),
            out_mult_KNet        = knet_cfg.get("out_mult", 5),
            activation_function  = knet_cfg.get("activation", "relu"),
            enable_clamp_scale   = bool(clamp_cfg.get("enable", False)),
            clamp_scale_info     = clamp_cfg if isinstance(clamp_cfg, dict) else {},
            state_bounds         = knet_cfg.get("state_bounds", {}),
        )
    elif model_type == "trainable_ukf":
        # 直接把 ukf_cfg 整包塞进 args，后面 builder 自行解析
        args.ukf_cfg = ukf_cfg
    else:
        raise ValueError(f"Unknown model.type = {model_type}")

    # 二次调试：构造后再次输出
    # (移除冗余 debug: args.train_epochs)
    # 修复潜在 tuple 形式 (20,) 影响取模：若 ckpt_interval 是长度1元组则取其值
    if isinstance(args.ckpt_interval, tuple) and len(args.ckpt_interval) == 1:
        args.ckpt_interval = args.ckpt_interval[0]

    # ==== 注入 instrumentation 参数 (供训练循环直接使用) ====
    args.perf_interval        = int(instr_cfg.get('perf_interval', 0))
    args.perf_gpu             = bool(instr_cfg.get('perf_gpu', False))
    args.mem_advice           = bool(instr_cfg.get('mem_advice', False))
    args.no_tqdm              = bool(instr_cfg.get('no_tqdm', False))
    args.bottleneck_analysis  = bool(instr_cfg.get('bottleneck_analysis', False))
    args.loader_probe_steps   = int(instr_cfg.get('loader_probe_steps', 0))
    args.metrics_interval     = int(instr_cfg.get('metrics_interval', 1))

    return args

def build_knet(sys_model, args):
    knet = KalmanNet()
    # 兼容旧 args 缺失 clamp 字段
    enable_clamp = bool(getattr(args, 'enable_clamp_scale', False))
    clamp_dict_raw = getattr(args, 'clamp_scale_info', {}) if enable_clamp else {}
    normalized = _normalize_clamp_dict(clamp_dict_raw, getattr(args, 'device', 'cpu')) if enable_clamp else None

    if enable_clamp and normalized is None:
        print('[Warn] clamp_scale 已启用但配置不完整/无效：自动关闭。')
        enable_clamp = False

    knet.debug_enabled = False
    knet.enable_clamp_scale = enable_clamp

    if enable_clamp:
        knet.clamp_scale_info = normalized  # 直接存放规范化后的 tensor 字典

    # KalmanNet 构建完全依赖 args
    knet.build_nn(sys_model, args)
    knet.to(args.device)

    # ========== torch.compile 优化 ==========
    if getattr(args, 'use_torch_compile', False):
        print("[INFO] Applying torch.compile optimization to KNet model...")
        try:
            knet = torch.compile(knet, mode='default')
            print("[INFO] torch.compile applied successfully!")
        except Exception as e:
            print(f"[WARNING] torch.compile failed: {e}. Continuing without compilation.")

    return knet
