"""After job termination: opaque NPZ hashing and NPY headers only; no array values."""
import argparse
import ast
from datetime import datetime, timezone
import math
from pathlib import Path
import stat
import struct
import zipfile
from audit_common import (ARRAYS, HERE, child, load_contract, load_index, path_key, read_json,
                          require, sha_file, write_new)


def collector_bindings():
    return {name: sha_file(HERE/name) for name in ('audit_common.py', 'collect_statistics_headers.py')}


def inspect_npz(path):
    """Read compressed-container bytes for SHA; decode exactly headers, never array payloads."""
    path = Path(path)
    require(path.name == 'issue_statistics.npz' and path.is_file() and not path.is_symlink(), 'Only new issue_statistics.npz allowed')
    before = path.stat()
    require(0 < before.st_size < 100_000_000, 'Unexpected statistics artifact byte size')
    checksum = sha_file(path)
    result = {}
    with zipfile.ZipFile(path) as archive:
        members = archive.infolist()
        require(len(members) == 4 and {m.filename for m in members} == set(ARRAYS), 'Missing/duplicate/extra statistics members')
        for member in members:
            require(not member.is_dir() and not member.flag_bits & 1 and member.compress_type in (0, 8), 'Unsupported ZIP member')
            require(stat.S_IFMT(member.external_attr >> 16) in (0, stat.S_IFREG), 'Non-regular ZIP member')
            with archive.open(member) as stream:
                require(stream.read(6) == b'\x93NUMPY', 'Not an NPY member')
                version = tuple(stream.read(2))
                require(version in ((1, 0), (2, 0), (3, 0)), 'Unsupported NPY version')
                length_width = 2 if version == (1, 0) else 4
                length_bytes = stream.read(length_width)
                require(len(length_bytes) == length_width, 'Truncated NPY length')
                length = int.from_bytes(length_bytes, 'little')
                require(0 < length <= 4096, 'Oversized NPY header')
                data = stream.read(length)
                require(len(data) == length and data.endswith(b'\n'), 'Truncated NPY header')
                header = ast.literal_eval(data.decode('utf-8' if version == (3, 0) else 'latin1').strip())
            require(isinstance(header, dict) and set(header) == {'descr', 'fortran_order', 'shape'}, 'Invalid NPY header schema')
            expected_shape, expected_dtype = ARRAYS[member.filename]
            shape = header['shape']
            require(type(shape) is tuple and all(type(n) is int and n > 0 for n in shape) and list(shape) == expected_shape,
                    'Wrong statistics shape: ' + member.filename)
            require(header['descr'] == expected_dtype and header['fortran_order'] is False, 'Wrong/object dtype or array order')
            header_bytes = 8 + length_width + length
            expected_bytes = header_bytes + math.prod(shape) * int(expected_dtype[-1])
            require(member.file_size == expected_bytes, 'Truncated/oversized array member')
            result[member.filename] = dict(shape=list(shape), dtype=expected_dtype, fortran_order=False,
                npy_version=list(version), header_bytes=header_bytes, uncompressed_bytes=member.file_size,
                compressed_bytes=member.compress_size, crc32=member.CRC)
    after = path.stat()
    require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns) and sha_file(path) == checksum,
            'Statistics artifact changed during header inspection')
    return dict(sha256=checksum, bytes=before.st_size, members=result, array_values_decoded=False,
                array_payload_crc_recomputed=False)


def collect_case(contract, row, root):
    folder = child(root, row['directory'])
    require(folder.is_dir(), 'Missing formal output directory')
    failure = child(folder, 'failure.json')
    failed_bridge = child(folder, 'metrics_before_failed_bridge.json')
    if failure.exists() or failed_bridge.exists():
        return dict(case_id=row['case_id'], directory=row['directory'], state='SAVED_FAILURE_PRESENT',
                    failure_sha256=sha_file(failure) if failure.exists() else None,
                    failed_bridge_sha256=sha_file(failed_bridge) if failed_bridge.exists() else None)
    completion, checksum = read_json(child(folder, 'completion.json'))
    require(completion['state'] == 'PLAIN_EVALUATION_COMPLETE' and completion['case_id'] == row['case_id'] and
            completion['manifest_sha256'] == contract['manifest_sha256'], 'Wrong or incomplete formal receipt')
    expected_path = path_key(contract['output_root'])+'/'+row['directory']+'/issue_statistics.npz'
    references = [a for a in completion['artifacts'] if path_key(a['path']) == expected_path]
    require(len(references) == 1, 'Missing/duplicate/wrong statistics artifact path')
    artifact = inspect_npz(child(folder, 'issue_statistics.npz'))
    require(artifact['sha256'] == references[0]['sha256'], 'Statistics bytes do not match completion binding')
    require(sha_file(folder/'completion.json') == checksum, 'Completion changed during inspection')
    return dict(case_id=row['case_id'], directory=row['directory'], state='STATISTICS_HEADER_AND_OPAQUE_SHA_VERIFIED',
                completion_sha256=checksum, recorded_path=expected_path, artifact=artifact)


def collect(contract, contract_sha, index, index_sha, root):
    root = Path(root)
    require(root.is_dir() and not root.is_symlink() and
            path_key(str(root.resolve())) == path_key(contract['output_root']), 'Collector must run beside registered formal outputs')
    rows = []
    for row in index['cases']:
        try:
            rows.append(collect_case(contract, row, root))
        except (ValueError, KeyError, TypeError, OSError, EOFError, SyntaxError, zipfile.BadZipFile, struct.error) as error:
            rows.append(dict(case_id=row['case_id'], directory=row['directory'], state='REJECTED_OR_INCOMPLETE', error=str(error)))
    verified = sum(r['state'] == 'STATISTICS_HEADER_AND_OPAQUE_SHA_VERIFIED' for r in rows)
    return dict(schema='plain_original_statistics_headers_v1', state='HEADERS_VERIFIED_NOT_SCIENTIFIC_ACCEPTANCE' if verified == 9 else 'REJECTED_OR_INCOMPLETE',
                generated_utc=datetime.now(timezone.utc).isoformat(), contract_sha256=contract_sha, run_index_sha256=index_sha,
                collector_bindings=collector_bindings(), recorded_runs_root=path_key(contract['output_root']),
                expected_count=9, verified_count=verified, rows=rows, array_values_decoded=False,
                models_executed=0, raw_test_tensors_opened=0,
                limitation='Header geometry and opaque file identity only. Array values, member payload CRC, counts, time values and metrics were not recomputed. Run only after the registered job has terminated.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--contract', required=True, type=Path)
    parser.add_argument('--contract-sha256', required=True)
    parser.add_argument('--run-index', required=True, type=Path)
    parser.add_argument('--run-index-sha256', required=True)
    parser.add_argument('--runs-root', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    require(not args.output.resolve().is_relative_to(args.runs_root.resolve()), 'Do not write into the formal evidence tree')
    contract = load_contract(args.contract, args.contract_sha256)
    index = load_index(args.run_index, args.run_index_sha256, contract)
    report = collect(contract, args.contract_sha256, index, args.run_index_sha256, args.runs_root)
    write_new(args.output, report)
    print(report['state'], report['verified_count'], '/9')
    return 0 if report['verified_count'] == 9 else 2


if __name__ == '__main__':
    raise SystemExit(main())
