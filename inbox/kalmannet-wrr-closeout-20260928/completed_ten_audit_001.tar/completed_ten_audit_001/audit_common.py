"""Standard-library metadata helpers; never imports the frozen model runtime."""
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
MODELS = tuple(f'{f}_seed{s}' for f in ('main', 'compact') for s in (42, 43, 44)) + ('learned_noise', 'hand_tuned', 'adaptive')
VARIANT = 'original_outlet_original_states'
CASE_IDS = tuple(m + '__' + VARIANT for m in MODELS)
METRICS = ('nse', 'rmse', 'mae', 'kge', 'correlation', 'variability_ratio', 'bias_ratio')
CONVERSION = 957000 / 3600
# JSON-only mathematical checks, fixed before examining any new formal result.
# These are floating-point allowances, NOT the historical bridge tolerances.
METRIC_ATOL = 1e-10
METRIC_RTOL = 1e-10
GEOMETRY = dict(n_windows=14981, n_issue_hours=15733, issues_per_window=753, pairs_per_lead=11280693,
                actual_leads=list(range(25)), propagation_positions=48)
ARRAYS = {'stats.npy': ([15733, 25, 8], '<f8'), 'issue_hours.npy': ([15733], '<f8'),
          'observation.npy': ([15780], '<f4'), 'actual_leads.npy': ([25], '<i8')}
EFFECTIVE_SHA = 'd0714a2b29b39e161375c187f8b952213d4364f043a1ac7b3a44a2788154016a'
MANIFEST_SHA = 'fe81db8c7bbea43e2f8040ea004e8f8bbf5ddf2107cd5b73369643f3e68c3087'
PACKAGE_SHA = 'b97410e78202bde3e18aa5dcaac2e6fe4c0ee7146156668e225db6e3a716915d'
PREFLIGHT_AUDIT_SHA = '803509089c0c9aea6f21374eb254a6ae9cf6ffb875f47e3b85a487d7aedc653c'
REVIEW_SHA = 'bc1f9fe381fed8838991c74a3f32065ca8d7a0722c8fce8efa057e2c681a6670'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'Missing or symlink file: ' + str(path))
    checksum = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            checksum.update(block)
    return checksum.hexdigest()


def fingerprint(value):
    return sha_bytes(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode())


def same(actual, expected, label):
    require(fingerprint(actual) == fingerprint(expected), label + ' mismatch')


def hash_text(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def path_key(value):
    require(isinstance(value, str) and value and '\x00' not in value, 'Invalid path')
    value = value.replace('\\', '/')
    require('..' not in PurePosixPath(value).parts, 'Parent traversal rejected')
    return str(PurePosixPath(value))


def child(root, name):
    require(isinstance(name, str) and name and Path(name).name == name and
            PurePosixPath(name).name == name and name not in ('.', '..'), 'Expected one child name')
    path = Path(root) / name
    require(not path.is_symlink() and path.resolve().is_relative_to(Path(root).resolve()), 'Symlink or escaped child')
    return path


def read_json(path, expected_sha=None):
    path = Path(path)
    require(path.suffix == '.json' and path.is_file() and not path.is_symlink(), 'Missing/non-JSON/symlink metadata: ' + str(path))
    require(path.stat().st_size < 10_000_000, 'Metadata too large')
    data = path.read_bytes()
    checksum = sha_bytes(data)
    if expected_sha is not None:
        require(hash_text(expected_sha) and checksum == expected_sha, 'Metadata fingerprint mismatch: ' + str(path))
    def unique(pairs):
        result = {}
        for k, v in pairs:
            require(k not in result, 'Duplicate JSON key: ' + k)
            result[k] = v
        return result
    value = json.loads(data.decode('utf-8-sig'), object_pairs_hook=unique,
                       parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Nonfinite JSON')))
    return value, checksum


def write_new(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def positive(value):
    return type(value) in (int, float) and math.isfinite(value) and value > 0


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def close(actual, expected, label):
    # Only cross-check JSON arithmetic round-off. Scientific bridge bounds stay fixed.
    require(finite(actual) and finite(expected) and math.isclose(actual, expected, rel_tol=2e-13, abs_tol=2e-13),
            label + ' inconsistent saved arithmetic')


def metric_set(values, vector=True):
    require(isinstance(values, dict) and set(values) == set(METRICS), 'Seven metric names required')
    for name, value in values.items():
        row = value if vector else [value]
        require(isinstance(row, list) and len(row) == (25 if vector else 1) and all(finite(v) for v in row),
                'Invalid metric shape/nonfinite value: ' + name)
        if name in ('rmse', 'mae', 'variability_ratio'):
            require(all(v >= 0 for v in row), 'Invalid negative error/variability')
    for index in range(25 if vector else 1):
        point = {k: values[k][index] if vector else values[k] for k in METRICS}
        require(point['nse'] <= 1 + METRIC_ATOL, 'Nash efficiency exceeds mathematical upper bound')
        require(point['kge'] <= 1 + METRIC_ATOL, 'Kling-Gupta efficiency exceeds mathematical upper bound')
        require(-1-METRIC_ATOL <= point['correlation'] <= 1+METRIC_ATOL,
                'Correlation outside mathematical bounds')
        allowance = max(METRIC_ATOL, METRIC_RTOL*max(point['mae'], point['rmse']))
        require(point['mae'] <= point['rmse'] + allowance, 'MAE exceeds RMSE for the same saved pairs')
        expected_kge = 1-math.hypot(point['correlation']-1, point['variability_ratio']-1, point['bias_ratio']-1)
        require(math.isclose(point['kge'], expected_kge, rel_tol=METRIC_RTOL, abs_tol=METRIC_ATOL),
                'Kling-Gupta efficiency inconsistent with its three saved components')
        # Bias ratio is not sign-restricted without independently established
        # prediction/observation sign assumptions. NSE/KGE have no lower bound.


def load_contract(path, checksum):
    contract, _ = read_json(path, checksum)
    require(contract['schema'] == 'plain_original_formal_audit_contract_v1', 'Wrong contract schema')
    require(contract['manifest_sha256'] == MANIFEST_SHA and contract['effective_contract_sha256'] == EFFECTIVE_SHA and
            contract['preflight_audit_sha256'] == PREFLIGHT_AUDIT_SHA, 'Wrong frozen contract lineage')
    require(set(contract['cases']) == set(CASE_IDS), 'Contract must contain exactly nine original settings')
    same(contract['geometry'], GEOMETRY, 'Frozen geometry')
    for identifier, row in contract['cases'].items():
        require(row['case']['case_id'] == identifier and row['case']['variant'] == VARIANT, 'Non-original contract case')
        require(row['case_fingerprint'] == fingerprint(row['case']), 'Contract case fingerprint mismatch')
        require(row['admission']['state'] == 'PLAIN_EVALUATION_ACCEPTED' and
                row['admission']['case_id'] == identifier and row['admission']['manifest_sha256'] == MANIFEST_SHA and
                row['admission']['open_critical_important_findings'] == 0 and
                type(row['admission']['open_critical_important_findings']) is int and
                row['admission']['review_record']['sha256'] == REVIEW_SHA and row['admission']['reviewer'],
                'Missing bound original-setting independent admission')
        same(row['environment'], row['admission']['accepted_environment'], 'Admitted environment')
        metric_set(row['historical_metrics'])
    return contract


def load_index(path, checksum, contract):
    index, _ = read_json(path, checksum)
    require(index.get('schema') == 'plain_original_formal_run_index_v1' and
            index.get('manifest_sha256') == MANIFEST_SHA, 'Wrong run-index schema/manifest')
    rows = index['cases']
    require(isinstance(rows, list) and len(rows) == 9 and {r['case_id'] for r in rows} == set(CASE_IDS),
            'Missing, duplicate or non-original run-index cases')
    directories = []
    for row in rows:
        require(set(row) == {'case_id', 'directory'}, 'Unexpected run-index fields')
        name = row['directory']
        require(isinstance(name, str) and name.startswith(row['case_id'] + '__') and
                re.fullmatch('[a-zA-Z0-9_-]+', name) is not None and '__preflight_' not in name,
                'Wrong/unsafe exclusive formal directory')
        directories.append(name)
    require(len(set(directories)) == 9, 'Shared formal output directory')
    return index


def bridge_from_json(case_contract, metrics):
    metric_set(metrics)
    old = case_contract['historical_metrics']
    units = case_contract['case']['historical_reference']['error_units']
    require(units in ('mm/hour', 'm3/s'), 'Unknown historical units')
    maxima, periods, period_means = {}, {}, {}
    for key in METRICS:
        factor = CONVERSION if key in ('rmse', 'mae') else 1.
        old_factor = 1. if units == 'm3/s' and key in ('rmse', 'mae') else factor
        current = [v * factor for v in metrics[key]]
        saved = [v * old_factor for v in old[key]]
        delta = [a-b for a, b in zip(current, saved)]
        maxima[key] = max(abs(v) for v in delta)
        periods[key] = {label: abs(math.fsum(delta[a:b])/12) for label, a, b in [('1_12', 1, 13), ('13_24', 13, 25)]}
        period_means[key] = {label: {'current': math.fsum(current[a:b])/12, 'archived': math.fsum(saved[a:b])/12}
                             for label, a, b in [('1_12', 1, 13), ('13_24', 13, 25)]}
    arrays_present = 'statistics_path' in case_contract['case']['historical_reference']
    result = dict(passed=all(maxima[k] <= (1e-4 if k in ('rmse','mae') else 1e-6) and
                            max(periods[k].values()) <= (1e-4 if k in ('rmse','mae') else 1e-6) for k in METRICS),
                  maximum_absolute_differences=maxima, period_absolute_differences=periods,
                  error_difference_unit='m3/s', dimensionless_tolerance=1e-6, error_tolerance_m3s=1e-4,
                  provenance='archived statistics domain checked' if arrays_present else
                             'new reconstruction; historical issue/observation arrays unavailable',
                  unavailable_original_arrays=[] if arrays_present else ['issue_hours','observation','per_issue_counts'])
    return result, period_means
