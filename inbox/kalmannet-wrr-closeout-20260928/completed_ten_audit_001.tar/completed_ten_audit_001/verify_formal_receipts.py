"""Local saved-JSON audit of nine original full-period cases; never opens arrays."""
import argparse
from collections import Counter
import math
from pathlib import Path, PurePosixPath
from audit_common import (ARRAYS, CASE_IDS, CONVERSION, GEOMETRY, METRICS, bridge_from_json, child, close,
                          finite, fingerprint, hash_text, load_contract, load_index, metric_set, path_key,
                          positive, read_json, require, same, sha_file, write_new)
from collect_statistics_headers import collector_bindings

SUMMARY_KEYS = set(GEOMETRY) | {'metrics', 'rmse_m3s', 'mae_m3s', 'batches', 'seconds', 'grouped_metrics',
    'effective_config', 'input_fingerprints', 'historical_reproduction'}
EXTRA_KEYS = {'state', 'no_instrumentation', 'training_calls', 'inputs_unchanged', 'learned_parameters_unchanged',
    'artifacts', 'case_id', 'case_fingerprint', 'manifest_sha256', 'code_bindings', 'environment', 'elapsed_seconds'}


def check_groups(groups, contract):
    require(isinstance(groups, list) and len(groups) == 24, 'Exactly 24 frozen per-lead flow groups required')
    for row, expected in zip(groups, contract['grouping']):
        require(set(row) == {'lead_hours','q25_mmh','q75_mmh','groups'}, 'Flow-group record schema mismatch')
        for key in ('lead_hours', 'q25_mmh', 'q75_mmh'):
            same(row[key], expected[key], 'Frozen flow group ' + key)
        require(set(row['groups']) == {'low','mid','high'}, 'Missing/extra flow category')
        require(sum(expected['counts'].values()) == GEOMETRY['pairs_per_lead'], 'Frozen flow counts mismatch')
        for group, values in row['groups'].items():
            require(set(values) == {'count','metrics','rmse_m3s','mae_m3s'}, 'Flow-category schema mismatch')
            same(values['count'], expected['counts'][group], 'Frozen flow group count')
            metric_set(values['metrics'], vector=False)
            for key in ('rmse','mae'):
                close(values[key+'_m3s'], values['metrics'][key]*CONVERSION, 'Flow-group unit conversion')


def check_bridge(saved, expected):
    require(set(saved) == set(expected), 'Historical bridge schema mismatch')
    for key in set(expected) - {'maximum_absolute_differences','period_absolute_differences'}:
        same(saved[key], expected[key], 'Historical bridge ' + key)
    require(set(saved['maximum_absolute_differences']) == set(METRICS) and
            set(saved['period_absolute_differences']) == set(METRICS), 'Missing bridge metric')
    for key in METRICS:
        close(saved['maximum_absolute_differences'][key], expected['maximum_absolute_differences'][key], 'Per-lead bridge ' + key)
        require(set(saved['period_absolute_differences'][key]) == {'1_12','13_24'}, 'Wrong 12-hour period keys')
        for period in ('1_12','13_24'):
            close(saved['period_absolute_differences'][key][period], expected['period_absolute_differences'][key][period],
                  'Period bridge ' + key + '/' + period)
    require(expected['passed'] is True, 'Archived numerical-reproduction tolerance exceeded; corrected branches remain closed')


def check_header(header, row, contract, completion_sha, stats_sha):
    require(header['state'] == 'STATISTICS_HEADER_AND_OPAQUE_SHA_VERIFIED' and header['case_id'] == row['case_id'] and
            header['directory'] == row['directory'], 'No matching successful statistics-header receipt')
    require(header['completion_sha256'] == completion_sha and header['artifact']['sha256'] == stats_sha,
            'Header receipt not bound to this completion/statistics artifact')
    same(header['recorded_path'], path_key(contract['output_root'])+'/'+row['directory']+'/issue_statistics.npz', 'Header artifact path')
    artifact = header['artifact']
    require(type(artifact['bytes']) is int and 0 < artifact['bytes'] < 100_000_000 and
            artifact['array_values_decoded'] is False and artifact['array_payload_crc_recomputed'] is False, 'Wrong header inspection scope')
    require(set(artifact['members']) == set(ARRAYS), 'Wrong statistics members')
    for name, (shape, dtype) in ARRAYS.items():
        member = artifact['members'][name]
        same(member['shape'], shape, 'Statistics header shape')
        require(member['dtype'] == dtype and member['fortran_order'] is False and
                member['npy_version'] in ([1,0],[2,0],[3,0]), 'Wrong header dtype/order/version')
        require(type(member['header_bytes']) is int and 10 <= member['header_bytes'] <= 4108 and
                type(member['uncompressed_bytes']) is int and
                member['uncompressed_bytes'] == member['header_bytes'] + math.prod(shape)*int(dtype[-1]), 'Header member size mismatch')
        require(type(member['compressed_bytes']) is int and 0 < member['compressed_bytes'] <= member['uncompressed_bytes']+100_000 and
                type(member['crc32']) is int and 0 <= member['crc32'] <= 0xffffffff, 'Invalid ZIP member metadata')


def audit_case(contract, row, root, header, checks):
    identifier = row['case_id']
    expected = contract['cases'][identifier]
    case = expected['case']
    folder = child(root, row['directory'])
    require(folder.is_dir(), 'Missing formal receipt directory')
    evidence = {}
    def record(name):
        value, checksum = read_json(child(folder, name))
        evidence[name] = checksum
        return value
    failure_path = child(folder, 'failure.json')
    bridge_failure_path = child(folder, 'metrics_before_failed_bridge.json')
    if failure_path.exists() or bridge_failure_path.exists():
        failure = record('failure.json') if failure_path.exists() else None
        if failure is not None:
            require(failure['case_id'] == identifier and failure['stage'] == 'formal', 'Failure receipt has wrong identity/stage')
        if bridge_failure_path.exists():
            record('metrics_before_failed_bridge.json')
        return dict(case_id=identifier, state='SAVED_FAILURE_PRESENT', checks=checks,
            failure=failure, failed_bridge_receipt_present=bridge_failure_path.exists(), evidence_sha256=evidence)
    checks['no_saved_failure'] = True
    completion = record('completion.json')
    require(set(completion) == SUMMARY_KEYS | EXTRA_KEYS, 'Frozen completion schema changed')
    require(completion['state'] == 'PLAIN_EVALUATION_COMPLETE' and completion['case_id'] == identifier and
            completion['case_fingerprint'] == expected['case_fingerprint'] and
            completion['manifest_sha256'] == contract['manifest_sha256'], 'Completion identity/state mismatch')
    same(record('running.json'), dict(case_id=identifier,stage='formal',manifest_sha256=contract['manifest_sha256']), 'Running receipt')
    same(completion['code_bindings'], contract['code_bindings'], 'Frozen nine-file evaluator')
    same(record('environment.json'), expected['environment'], 'Accepted numerical environment')
    same(completion['environment'], expected['environment'], 'Completion environment')
    checks.update(case_code_identity=True, independently_admitted_environment=True)
    for key in ('no_instrumentation','inputs_unchanged','learned_parameters_unchanged'):
        require(completion[key] is True, 'Missing runtime integrity claim: '+key)
    require(type(completion['training_calls']) is int and completion['training_calls'] == 0, 'Forbidden or missing training count')
    same(completion['effective_config'], expected['effective_config'], 'Independently frozen effective configuration')
    same(completion['input_fingerprints'], contract['input_fingerprints'], 'Frozen original test input columns/states')
    same(record('model_start.json'), dict(case_id=identifier, input_fingerprints=contract['input_fingerprints'],
        parameter_fingerprints=expected['parameter_fingerprints']), 'Accepted model parameter/input fingerprints')
    checks.update(effective_configuration=True, initial_parameter_fingerprints=True, input_fingerprints=True,
                  unchanged_parameters_inputs_runtime_claims=True)
    metrics = record('metrics.json')
    require(set(metrics) == SUMMARY_KEYS, 'Frozen metrics schema changed')
    same(metrics, {k:completion[k] for k in SUMMARY_KEYS}, 'Completion/metric records')
    for key, value in GEOMETRY.items():
        same(metrics[key], value, 'Full-period geometry/count ' + key)
    same(metrics['batches'], math.ceil(14981/case['batch_size']), 'Full-period batch count')
    require(positive(metrics['seconds']) and positive(completion['elapsed_seconds']) and
            completion['elapsed_seconds'] >= metrics['seconds'], 'Invalid elapsed scoring/runtime time')
    metric_set(metrics['metrics'])
    for key in ('rmse','mae'):
        values = metrics[key+'_m3s']
        require(isinstance(values,list) and len(values) == 25, 'Missing full error-unit conversion')
        for a,b in zip(values,metrics['metrics'][key]):
            close(a,b*CONVERSION,'Full-period error conversion')
    check_groups(metrics['grouped_metrics'],contract)
    bridge, periods = bridge_from_json(expected,metrics['metrics'])
    same(record('historical_reproduction.json'),metrics['historical_reproduction'],'Bridge/completion records')
    check_bridge(metrics['historical_reproduction'],bridge)
    checks.update(full_period_saved_counts=True, seven_metrics_all_25_leads=True, two_12_hour_json_period_means=True,
                  frozen_24_lead_flow_groups=True, archived_numerical_bridge=True)
    recorded_output = path_key(contract['output_root'])+'/'+row['directory']
    artifacts = completion['artifacts']
    require(isinstance(artifacts,list) and len(artifacts) == 2, 'Exactly two formal artifacts required')
    bypath = {}
    for artifact in artifacts:
        require(set(artifact) == {'path','sha256'} and hash_text(artifact['sha256']), 'Invalid artifact binding')
        path = path_key(artifact['path'])
        require(path not in bypath, 'Duplicate formal artifact')
        bypath[path] = artifact['sha256']
    require(set(bypath) == {recorded_output+'/issue_statistics.npz', recorded_output+'/metrics.json'}, 'Wrong formal artifact paths')
    require(bypath[recorded_output+'/metrics.json'] == evidence['metrics.json'], 'Saved metrics artifact bytes changed')
    check_header(header,row,contract,evidence['completion.json'],bypath[recorded_output+'/issue_statistics.npz'])
    checks['statistics_shape_and_opaque_sha_from_bound_header_receipt'] = True
    proof = expected['effective_config']['plain_physical_source' if 'family' in case else 'instrumentation']
    generated = recorded_output+'/physical_original.py'
    imports = record('import_ledger.json')
    require(isinstance(imports,list) and imports, 'Missing computational imports')
    imported = Counter()
    for item in imports:
        path = path_key(item['path'])
        require(item.get('module') and hash_text(item['sha256']) and
                item['sha256'] == (proof['source_sha256'] if path == generated else contract['source_bindings'].get(path)),
                'Unbound/changed computational source: '+path)
        require(PurePosixPath(path).name not in ('walrus_observed.py','walrus_corrected.py'), 'Counted physical source imported')
        if item['module'] == 'probe_walrus_observed':
            require(path == generated, 'Wrong physical alias location')
        imported[path] += 1
    require(imported[generated] == 1 and all(imported[p] >= 1 for p in expected['required_imports']),
            'Missing required computational/statistics imports')
    loads = record('load_ledger.json')
    require(isinstance(loads,list), 'Missing tensor-load ledger')
    actual_loads = Counter((path_key(v['path']),v['sha256'],v['role']) for v in loads)
    data = contract['test_dataset']
    expected_loads = Counter({(path_key(data['path']),data['sha256'],'dataset'):1})
    if 'checkpoint' in case:
        expected_loads[(path_key(case['checkpoint']),case['checkpoint_sha256'],
                        'checkpoint' if 'family' in case else 'fixed_learned_noise_checkpoint')] = 1
    require(actual_loads == expected_loads, 'Missing/extra/wrong tensor path, role, digest or load count')
    resources = record('resources.json')
    require(set(resources) == {'seconds','peak_cuda_allocated','peak_cuda_reserved'} and positive(resources['seconds']) and
            resources['seconds'] >= completion['elapsed_seconds'] and type(resources['peak_cuda_allocated']) is int and
            resources['peak_cuda_allocated'] > 0 and type(resources['peak_cuda_reserved']) is int and
            resources['peak_cuda_reserved'] >= resources['peak_cuda_allocated'], 'Invalid resource measurements')
    checks.update(source_provenance=True, exact_original_test_and_checkpoint_loads=True, resource_receipt=True)
    return dict(case_id=identifier,state='SAVED_FORMAL_METADATA_VERIFIED_REQUIRES_INDEPENDENT_REVIEW',checks=checks,
        evidence_sha256=evidence,recorded_output=recorded_output,resources=resources,
        json_period_means=periods,period_units='rmse/mae m3/s; other metrics dimensionless',
        bridge=bridge,admission_sha256=expected['admission_sha256'])


def audit(contract,contract_sha,index,index_sha,root,headers):
    require(headers['schema'] == 'plain_original_statistics_headers_v1' and headers['contract_sha256'] == contract_sha and
            headers['run_index_sha256'] == index_sha and headers['recorded_runs_root'] == path_key(contract['output_root']),
            'Wrong header receipt contract/index/root binding')
    same(headers['collector_bindings'],collector_bindings(),'Reviewed header collector code')
    require(headers['array_values_decoded'] is False and headers['models_executed'] == 0 and
            headers['raw_test_tensors_opened'] == 0 and headers['expected_count'] == 9, 'Unexpected header inspection scope')
    header_rows = headers['rows']
    require(len(header_rows) == 9 and {r['case_id'] for r in header_rows} == set(CASE_IDS), 'Missing/duplicate header receipt cases')
    require(headers['verified_count'] == sum(r['state'] == 'STATISTICS_HEADER_AND_OPAQUE_SHA_VERIFIED' for r in header_rows),
            'Inconsistent header verified count')
    expected_header_state = ('HEADERS_VERIFIED_NOT_SCIENTIFIC_ACCEPTANCE' if headers['verified_count'] == 9
                             else 'REJECTED_OR_INCOMPLETE')
    require(headers.get('state') == expected_header_state, 'Missing/inconsistent header top-level state')
    root = Path(root)
    require(root.is_dir() and not root.is_symlink(), 'Missing or symlink local receipt root')
    rows = []
    for row in index['cases']:
        checks = {}
        try:
            header = next(h for h in header_rows if h['case_id'] == row['case_id'])
            rows.append(audit_case(contract,row,root,header,checks))
        except (ValueError,KeyError,TypeError,IndexError,OSError,OverflowError) as error:
            rows.append(dict(case_id=row['case_id'],state='REJECTED_OR_INCOMPLETE',checks=checks,error=str(error)))
    count = sum(r['state'] == 'SAVED_FORMAL_METADATA_VERIFIED_REQUIRES_INDEPENDENT_REVIEW' for r in rows)
    return dict(schema='plain_original_formal_metadata_audit_v1',
        state='ALL_NINE_METADATA_VERIFIED_PENDING_INDEPENDENT_REVIEW' if count == 9 else 'REJECTED_OR_INCOMPLETE',
        verified_count=count,expected_count=9,rows=rows,contract_sha256=contract_sha,run_index_sha256=index_sha,
        formal_acceptance_created=False,corrected_branches_enabled=False,models_executed=0,raw_test_tensors_opened=0,
        local_array_files_opened=0,independent_array_metric_recalculation=False,
        limitation='Checks saved JSON, accepted identities and a separately bound header/opaque-hash receipt. Time alignment, array counts, observation equality, full-trajectory finiteness and post-run parameter/input invariance remain frozen-runtime claims, not independent array recomputation. Scheduler success and scientific acceptance are separate.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('contract','run-index','headers','receipts-root','output'):
        parser.add_argument('--'+name,required=True,type=Path)
    for name in ('contract','run-index','headers'):
        parser.add_argument('--'+name+'-sha256',required=True)
    args = parser.parse_args()
    require(not args.output.resolve().is_relative_to(args.receipts_root.resolve()), 'Audit output cannot mutate receipt tree')
    contract = load_contract(args.contract,args.contract_sha256)
    index = load_index(args.run_index,args.run_index_sha256,contract)
    headers, header_sha = read_json(args.headers,args.headers_sha256)
    result = audit(contract,args.contract_sha256,index,args.run_index_sha256,args.receipts_root,headers)
    result['headers_receipt_sha256'] = header_sha
    write_new(args.output,result)
    print(result['state'],result['verified_count'],'/9')
    return 0 if result['verified_count'] == 9 else 2


if __name__ == '__main__':
    raise SystemExit(main())
