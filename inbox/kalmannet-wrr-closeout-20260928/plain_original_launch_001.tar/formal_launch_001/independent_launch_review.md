# Independent review: original-nine full-period bridge launcher

Date: 2026-09-28. Reviewer: `all_comments_coverage`.

**The script is acceptable for exactly nine original-setting evaluations, conditional on the separately verified final launch checksum list, nine independent admissions and completed original-input delivery.** This is not a submission or an acceptance of eventual bridge results.

Reviewed script: `hpc/plain_formal_launch_001/original_nine.slurm`; SHA-256 `eba1a8c061bcffb0f701d601dcb17f6c3e5b4301b93f15859cec7628ff44350c`. Independently checked with the installed `E:/Program Files/Git/bin/bash.exe -n`: exit 0. The script body was not executed. An initial syntax-check attempt used a nonexistent C-drive Git path and did not run; the valid E-drive check above is the actual successful result.

The script has one node, one graphics processor, four central-processor cores, a six-hour limit, `hgpu2p`, exclusion of `ngu002`, and no automatic requeue. All computations are sequential. Both case-list passes contain exactly main/compact seeds 42–44, learned noise, hand tuned and historical adaptive, each suffixed `__original_outlet_original_states`. There is no corrected case, training, adaptive-rate selection or unregistered alternate candidate.

Before inference it requires the original-input completion file, verifies the launch checksum list and original preflight package checksum list, checks all nine admission files, and refuses any existing planned output. Its exclusive `original_batch_started` marker prevents unnoticed relaunch. Each original setting uses a new `__formal_attempt01` output inside the current isolated root and passes its own independent acceptance to the unchanged formal driver. The driver separately validates reviewer record, completion identity/hash, manifest, code, environment and the fixed historical bridge. No overwrite, deletion, skip-existing, tolerance change or retry is implemented.

`set -eo pipefail` stops the batch on the first failing command or evaluation. The terminal broken scheduler-state query is absent; the script ends with a marker explicitly pending independent bridge review. Scheduler status must be retrieved by the parent from a separate read-only context, and future failures must be preserved.

Final deployment prerequisites remain substantive: `launch_files.sha256` must bind this exact script, all nine exact admissions, their `independent_review.md`, and the exact successful original-input completion receipt (plus any other intended launch evidence). Hashes must be verified at the destination before submission. The parent must keep this graphics-processor job sequential with the separately admitted five-validation comparison job using an actual scheduler dependency; this script alone does not govern a second job. The completion receipt and eventual scheduler number are not invented by this review.

The review neither authorizes the 18 corrected branches nor interprets historical reproduction as a scientific improvement. Those branches remain gated by each model's accepted original full-period result. No model, remote command or scheduler submission was performed here.
