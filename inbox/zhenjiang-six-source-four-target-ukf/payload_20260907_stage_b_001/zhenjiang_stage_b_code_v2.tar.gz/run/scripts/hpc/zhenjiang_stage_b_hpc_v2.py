#!/usr/bin/env python3
"""Build and inspect the isolated Stage-B HPC package.

Examples:
  python -B scripts/hpc/zhenjiang_stage_b_hpc_v2.py build --output-dir migration_packages/zhenjiang_stage_b_20260907_001
  python -B scripts/hpc/zhenjiang_stage_b_hpc_v2.py verify-bundle --archive DIR/zhenjiang_stage_b_code_v2.tar.gz --manifest DIR/bundle_manifest.json
  python -B scripts/hpc/zhenjiang_stage_b_hpc_v2.py deployment-command --bundle-dir DIR --output DIR/deploy_and_submit.sh
  python -B scripts/hpc/zhenjiang_stage_b_hpc_v2.py query-command --output DIR/query_stage_b.sh --job-id 123

Build and login-node verification use only the Python standard library.  They
never open the twelve formal data objects.  Numerical imports are confined to
the Slurm allocation by the packaged job script and runtime.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import tarfile
from typing import Mapping, Sequence

PROJECT_ROOT = Path(__file__).resolve().parents[2]
REMOTE_ROOT = "/data1/home/sunyiq/zhenjiang_5s5t_stage_b_20260907_001"
OLD_ROOTS = (
    "/data1/home/sunyiq/zhenjiang_six_source_four_target_differentiable_ukf_20260901_r2",
    "/data1/home/sunyiq/zhenjiang_six_source_four_target_differentiable_ukf_20260902_recovery_attempt_002",
    "/data1/home/sunyiq/zhenjiang_five_source_five_target_single_analysis_ukf_oracle_datong_20260904_r1",
    "/data1/home/sunyiq/zhenjiang_5s5t_stage_a_20260905_recovery_001",
)
CONTRACTS = {
    "contracts/stage_b_execution_contract.json": (
        "docs/records/zhenjiang_stage_b_20260907_001_execution_contract.json",
        "688ee2340954542b71955df35dd1f918450e0b01035f16b5bf353ce8ffbb798f",
    ),
    "contracts/paid_execution_authorization.json": (
        "docs/records/zhenjiang_stage_b_20260907_001_execution_authorization.json",
        "feab3b9e38a9ce2c6f7e9e4d33c07f588c6361d315abcb8ecfd06665fa4a1a2e",
    ),
    "contracts/stage_b_data_authorization.json": (
        "docs/records/zhenjiang_stage_b_20260907_001_data_authorization.json",
        "39fc0920f7f13e9ec0aebd368e162fe026e08a3961efee35876758559632f9de",
    ),
}
SOURCE_MAP = {
    "run/scripts/hpc/zhenjiang_stage_b_hpc_v2.py": "scripts/hpc/zhenjiang_stage_b_hpc_v2.py",
    "run/scripts/hpc/zhenjiang_five_source_five_target_stage_b_v2.slurm": "scripts/hpc/zhenjiang_five_source_five_target_stage_b_v2.slurm",
    "run/scripts/modeling/run_zhenjiang_five_source_five_target_stage_b_v2.py": "scripts/modeling/run_zhenjiang_five_source_five_target_stage_b_v2.py",
    "run/scripts/modeling/run_zhenjiang_five_source_five_target_stage_a_v2.py": "scripts/modeling/run_zhenjiang_five_source_five_target_stage_a_v2.py",
    "run/scripts/modeling/train_zhenjiang_five_source_five_target_d32_gru_v2.py": "scripts/modeling/train_zhenjiang_five_source_five_target_d32_gru_v2.py",
    "run/scripts/modeling/zhenjiang_five_source_five_target_d32_gru_v2.py": "scripts/modeling/zhenjiang_five_source_five_target_d32_gru_v2.py",
    "run/scripts/modeling/zhenjiang_five_source_five_target_data_v2.py": "scripts/modeling/zhenjiang_five_source_five_target_data_v2.py",
    "run/scripts/modeling/zhenjiang_five_source_five_target_single_analysis_runner_v2.py": "scripts/modeling/zhenjiang_five_source_five_target_single_analysis_runner_v2.py",
    "run/scripts/modeling/zhenjiang_five_source_five_target_single_analysis_training_v2.py": "scripts/modeling/zhenjiang_five_source_five_target_single_analysis_training_v2.py",
    "run/scripts/modeling/zhenjiang_five_source_five_target_single_analysis_ukf_v2.py": "scripts/modeling/zhenjiang_five_source_five_target_single_analysis_ukf_v2.py",
    "run/scripts/analysis/zhenjiang_five_source_five_target_single_analysis_contract_v2.py": "scripts/analysis/zhenjiang_five_source_five_target_single_analysis_contract_v2.py",
    "run/scripts/astronomical_tide/wusongkou_astronomical_tide_realtime_v2.py": "scripts/astronomical_tide/wusongkou_astronomical_tide_realtime_v2.py",
    "run/third_party/pytides/astro.py": "third_party/pytides/astro.py",
    "run/third_party/pytides/constituent.py": "third_party/pytides/constituent.py",
    "run/third_party/pytides/nodal_corrections.py": "third_party/pytides/nodal_corrections.py",
    "run/third_party/pytides/tide.py": "third_party/pytides/tide.py",
    "run/docs/records/zhenjiang_stage_b_20260907_001_task1_final_approval.md": "docs/records/zhenjiang_stage_b_20260907_001_task1_final_approval.md",
}
ARCHIVE_NAME = "zhenjiang_stage_b_code_v2.tar.gz"
MANIFEST_NAME = "bundle_manifest.json"


def sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode("utf-8")


def _read_regular(path: Path) -> bytes:
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"not an ordinary file: {path}")
    return path.read_bytes()


def _tar_bytes(files: Mapping[str, bytes]) -> bytes:
    uncompressed = io.BytesIO()
    with tarfile.open(fileobj=uncompressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for name in sorted(files):
            info = tarfile.TarInfo(name)
            info.size = len(files[name]); info.mtime = 0; info.uid = 0; info.gid = 0
            info.uname = ""; info.gname = ""; info.mode = 0o755 if name.endswith(".slurm") else 0o644
            archive.addfile(info, io.BytesIO(files[name]))
    output = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", fileobj=output, mtime=0, compresslevel=9) as stream:
        stream.write(uncompressed.getvalue())
    return output.getvalue()


def build_bundle(output_dir: Path, project_root: Path = PROJECT_ROOT) -> Mapping[str, object]:
    """Exclusively build one deterministic, data-free package."""
    output_dir.mkdir(parents=False, exist_ok=False)
    files = {target: _read_regular(project_root / source) for target, source in SOURCE_MAP.items()}
    for target, (source, expected_hash) in CONTRACTS.items():
        raw = _read_regular(project_root / source)
        if sha256(raw) != expected_hash:
            raise ValueError(f"controller-owned contract identity changed: {source}")
        files[target] = raw
    execution = json.loads(files["contracts/stage_b_execution_contract.json"])
    paid = json.loads(files["contracts/paid_execution_authorization.json"])
    data = json.loads(files["contracts/stage_b_data_authorization.json"])
    machine_target = "run/scripts/analysis/zhenjiang_five_source_five_target_single_analysis_contract_v2.py"
    if sha256(files[machine_target]) != execution.get("machine_contract_sha256"):
        raise ValueError("source machine-contract hash differs from execution contract")
    if (execution.get("stage_b_data_authorization_sha256") != CONTRACTS["contracts/stage_b_data_authorization.json"][1]
            or execution.get("paid_execution_authorization_sha256") != CONTRACTS["contracts/paid_execution_authorization.json"][1]
            or paid.get("remote_root") != REMOTE_ROOT or paid.get("seed_order") != [17, 29, 43]
            or paid.get("maximum_sbatch_submissions") != 1
            or paid.get("maximum_new_formal_object_reads") != 36
            or data.get("maximum_read_count") != 36 or len(data.get("allowed_byte_ranges", [])) != 12
            or data.get("allowed_purposes") != [execution.get("formal_purpose")]
            or data.get("allowed_time_partitions") != [execution.get("time_partition")]):
        raise ValueError("execution, paid, and data authorization bindings differ")
    rows = [{"relative_path": name, "byte_count": len(raw), "sha256": sha256(raw)}
            for name, raw in sorted(files.items())]
    manifest = {
        "schema_version": "zhenjiang-stage-b-bundle-v2",
        "remote_root": REMOTE_ROOT,
        "source_file_count": len(rows),
        "source_files": rows,
        "formal_data_included": False,
        "results_included": False,
        "git_metadata_included": False,
        "held_out_2023_or_2024_data_included": False,
        "login_node_numerical_imports_permitted": False,
    }
    manifest_raw = json_bytes(manifest)
    archive_raw = _tar_bytes({**files, MANIFEST_NAME: manifest_raw})
    (output_dir / ARCHIVE_NAME).write_bytes(archive_raw)
    (output_dir / MANIFEST_NAME).write_bytes(manifest_raw)
    identity = {"archive": ARCHIVE_NAME, "archive_byte_count": len(archive_raw),
                "archive_sha256": sha256(archive_raw), "manifest": MANIFEST_NAME,
                "manifest_byte_count": len(manifest_raw), "manifest_sha256": sha256(manifest_raw)}
    (output_dir / "bundle_identity.json").write_bytes(json_bytes(identity))
    payload = []
    for name in (ARCHIVE_NAME, MANIFEST_NAME, "bundle_identity.json"):
        raw = (output_dir / name).read_bytes()
        payload.append({"source": str((output_dir / name).resolve()),
                        "destination": "inbox/zhenjiang-six-source-four-target-ukf/payload_20260907_stage_b_001/" + name,
                        "byte_count": len(raw), "sha256": sha256(raw)})
    (output_dir / "payload_manifest.json").write_bytes(json_bytes(payload))
    verify_bundle(output_dir / ARCHIVE_NAME, output_dir / MANIFEST_NAME)
    return identity


def verify_bundle(archive_path: Path, manifest_path: Path) -> Mapping[str, object]:
    """Verify safe membership and exact outer/inner raw-byte identity."""
    archive_raw = _read_regular(archive_path); manifest_raw = _read_regular(manifest_path)
    manifest = json.loads(manifest_raw.decode("utf-8"))
    expected = {row["relative_path"]: row for row in manifest["source_files"]}
    observed = {}
    with tarfile.open(fileobj=io.BytesIO(archive_raw), mode="r:gz") as archive:
        for member in archive.getmembers():
            path = PurePosixPath(member.name)
            if path.is_absolute() or ".." in path.parts or "\\" in member.name:
                raise ValueError("unsafe archive path")
            if not member.isfile() or member.issym() or member.islnk():
                raise ValueError("all archive members must be regular files")
            if member.name in observed:
                raise ValueError("duplicate archive member")
            handle = archive.extractfile(member)
            if handle is None:
                raise ValueError("archive member cannot be read")
            observed[member.name] = handle.read()
    if set(observed) != set(expected) | {MANIFEST_NAME}:
        raise ValueError("archive membership differs from explicit allow-list")
    if observed[MANIFEST_NAME] != manifest_raw:
        raise ValueError("inner and outer manifests differ")
    for name, row in expected.items():
        raw = observed[name]
        if len(raw) != row["byte_count"] or sha256(raw) != row["sha256"]:
            raise ValueError("archive byte identity differs: " + name)
    if _tar_bytes(observed) != archive_raw:
        raise ValueError("archive encoding or deterministic metadata differs")
    return {"archive_sha256": sha256(archive_raw), "manifest_sha256": sha256(manifest_raw),
            "member_count": len(observed)}


def verify_deployed_tree(root: Path, manifest_path: Path, trusted_manifest_sha256: str) -> Mapping[str, object]:
    """Recheck every deployed allow-listed byte before compute imports or data reads."""
    manifest_raw = _read_regular(manifest_path)
    if sha256(manifest_raw) != trusted_manifest_sha256:
        raise ValueError("deployed manifest differs from external trusted identity")
    manifest = json.loads(manifest_raw)
    rows = manifest["source_files"]
    for row in rows:
        raw = _read_regular(root / row["relative_path"])
        if len(raw) != row["byte_count"] or sha256(raw) != row["sha256"]:
            raise ValueError("deployed byte identity differs: " + row["relative_path"])
    return {"verified_file_count": len(rows)}


def parse_submission_receipt(text: str) -> str:
    import re
    match = re.fullmatch(r"Submitted batch job ([0-9]+)\n?", text)
    if not match:
        raise ValueError("submission receipt is not the single accepted form")
    return match.group(1)


def validate_seed_start(seed: int, restart_count: str, attempt_exists: bool,
                        predecessor: Mapping[str, object] | None) -> None:
    if restart_count != "0" or attempt_exists:
        raise ValueError("only a first, non-restarted job attempt is permitted")
    order = (17, 29, 43)
    if seed not in order:
        raise ValueError("seed is outside the frozen order")
    if seed != 17:
        prior = order[order.index(seed) - 1]
        if not predecessor or predecessor.get("status") != "complete" or predecessor.get("seed") != prior:
            raise ValueError("predecessor completion does not authorize the next seed")
        if predecessor.get("execution_contract_sha256") != CONTRACTS["contracts/stage_b_execution_contract.json"][1]:
            raise ValueError("predecessor execution-contract identity differs")


def deployment_script(bundle_dir: Path) -> str:
    identity = json.loads(_read_regular(bundle_dir / "bundle_identity.json"))
    verify_bundle(bundle_dir / ARCHIVE_NAME, bundle_dir / MANIFEST_NAME)
    payload = "/data1/home/sunyiq/hpc_mailbox/inbox/zhenjiang-six-source-four-target-ukf/payload_20260907_stage_b_001"
    roots = " ".join("'" + value + "'" for value in OLD_ROOTS)
    return f'''#!/usr/bin/env bash
set -eo pipefail
umask 027
ROOT='{REMOTE_ROOT}'
MAILBOX_ROOT="$(git rev-parse --show-toplevel)"
PAYLOAD="$MAILBOX_ROOT/inbox/zhenjiang-six-source-four-target-ukf/payload_20260907_stage_b_001"
ARCHIVE="$PAYLOAD/{ARCHIVE_NAME}"
MANIFEST="$PAYLOAD/{MANIFEST_NAME}"
fatal() {{ printf '[FATAL] %s\\n' "$1" >&2; exit 1; }}
ordinary() {{ [ -f "$1" ] && [ ! -L "$1" ] || fatal "not ordinary file: $1"; }}
identity() {{ ordinary "$1"; [ "$(stat -c '%s' -- "$1")" = "$2" ] || fatal 'byte count changed'; [ "$(sha256sum -- "$1" | awk '{{print $1}}')" = "$3" ] || fatal 'SHA-256 changed'; }}
[ "$(id -un)" = sunyiq ] || fatal 'unexpected user'
[ ! -e "$ROOT" ] && [ ! -L "$ROOT" ] || fatal 'new root is not absent'
for old in {roots}; do [ -d "$old" ] && [ ! -L "$old" ] || fatal "protected root invalid: $old"; done
identity "$ARCHIVE" '{identity['archive_byte_count']}' '{identity['archive_sha256']}'
identity "$MANIFEST" '{identity['manifest_byte_count']}' '{identity['manifest_sha256']}'
source /data1/home/sunyiq/miniconda3/etc/profile.d/conda.sh
conda activate nh_final
export PYTHONDONTWRITEBYTECODE=1
python -B - "$ARCHIVE" "$MANIFEST" <<'PY'
import importlib.util, pathlib, sys, tarfile
archive, manifest = map(pathlib.Path, sys.argv[1:])
with tarfile.open(archive, 'r:gz') as tf:
    names = tf.getnames()
    if names.count('bundle_manifest.json') != 1 or tf.extractfile('bundle_manifest.json').read() != manifest.read_bytes():
        raise SystemExit('inner/outer manifest mismatch')
if importlib.util.find_spec('torch') is None:
    raise SystemExit('nh_final torch distribution is absent; torch is not imported on login')
PY
[ ! -e "$ROOT" ] && [ ! -L "$ROOT" ] || fatal 'new root appeared during preflight'
mkdir -- "$ROOT"
mkdir -p -- "$ROOT/logs" "$ROOT/runs/stage_b" "$ROOT/evidence/stage_b_attempts" "$ROOT/evidence/submission/attempt_001"
tar -xzf "$ARCHIVE" -C "$ROOT" --no-same-owner --no-same-permissions
python -B "$ROOT/run/scripts/hpc/zhenjiang_stage_b_hpc_v2.py" verify-bundle --archive "$ARCHIVE" --manifest "$ROOT/bundle_manifest.json"
for seed in 17 29 43; do
  p="/data1/home/sunyiq/zhenjiang_5s5t_stage_a_20260905_recovery_001/runs/stage_a/seed_${{seed}}/best_checkpoint.pt"
  case "$seed" in 17) h=374d3278c7e41dee0e2c1e937f936df442a44348a02addd46a2c4bb5b13b8263;; 29) h=7e8a0376f47b3c7f217e004df2519b48dce3311ceb5f3203e1f844eb97c4ff46;; 43) h=79b04446f4407496ceb8f0d85442ac2fe8ecd60db2d64e18c90a0bf3a13fe961;; esac
  identity "$p" 88882 "$h"
done
printf '{{"status":"submission_requested","sbatch_call_limit":1}}\\n' > "$ROOT/evidence/submission/attempt_001/requested.json"
REPLY_FILE="$ROOT/evidence/submission/attempt_001/sbatch_reply.raw.txt"
EXIT_FILE="$ROOT/evidence/submission/attempt_001/sbatch_exit_status.txt"
set +e
sbatch "$ROOT/run/scripts/hpc/zhenjiang_five_source_five_target_stage_b_v2.slurm" '{identity['manifest_sha256']}' > "$REPLY_FILE" 2>&1
rc=$?
set -e
printf '%s\\n' "$rc" > "$EXIT_FILE"
reply="$(cat "$REPLY_FILE")"
printf '%s\\n' "$reply"
if [ "$rc" -ne 0 ]; then
  printf '%s\\n' 'only authorized sbatch call failed; no retry' > "$ROOT/evidence/submission/attempt_001/submission_failure.txt"
  fatal 'only authorized sbatch call failed; no retry'
fi
if ! job="$(python -B "$ROOT/run/scripts/hpc/zhenjiang_stage_b_hpc_v2.py" parse-submission --text "$reply")"; then
  printf '%s\\n' 'submission receipt rejected; no retry' > "$ROOT/evidence/submission/attempt_001/submission_failure.txt"
  fatal 'submission receipt rejected; no retry'
fi
printf '{{"status":"submitted","job_id":"%s","sbatch_call_count":1}}\\n' "$job" > "$ROOT/evidence/submission/attempt_001/submission_receipt.json"
squeue -j "$job" -h -o '%i|%j|%T|%P|%M|%R|%Z' || true
'''


def query_script(job_id: str) -> str:
    if not job_id.isascii() or not job_id.isdigit():
        raise ValueError("query requires one numeric job identifier")
    job = job_id
    return f'''#!/usr/bin/env bash
set -eo pipefail
ROOT='{REMOTE_ROOT}'
JOB='{job}'
QUERY_CONDA_SH="${{ZHENJIANG_QUERY_CONDA_SH:-/data1/home/sunyiq/miniconda3/etc/profile.d/conda.sh}}"
[ -f "$QUERY_CONDA_SH" ] || {{ printf '[FATAL] query conda activation script absent: %s\\n' "$QUERY_CONDA_SH" >&2; exit 1; }}
source "$QUERY_CONDA_SH"
conda activate nh_final
python -B - "$ROOT/evidence/submission/attempt_001/submission_receipt.json" "$JOB" <<'PY'
import json,pathlib,sys
p=pathlib.Path(sys.argv[1]); expected=sys.argv[2]
if not p.is_file(): raise SystemExit('fixed-root submission receipt absent')
d=json.loads(p.read_bytes())
if d.get('status')!='submitted' or d.get('job_id')!=expected or d.get('sbatch_call_count')!=1:
    raise SystemExit('job identifier is not bound to the fixed-root receipt')
PY
printf '%s\\n' '=== SUBMISSION ==='
find "$ROOT/evidence/submission" -type f -maxdepth 3 -print -exec sed -n '1,80p' {{}} \\; 2>/dev/null || true
squeue -j "$JOB" -h -o '%i|%j|%T|%P|%M|%R|%Z' || true
sacct -j "$JOB" -X --format=JobID,JobName,State,ExitCode,Elapsed,NodeList || true
printf '%s\\n' '=== PROGRESS ==='
for seed in 17 29 43; do
  dir="$ROOT/runs/stage_b/seed_$seed"
  if [ ! -d "$dir" ]; then printf 'seed_%s=not-created\\n' "$seed"; continue; fi
  for p in "$dir/first_optimizer_update.json" "$dir/completion.json" "$dir/failure.json"; do [ ! -f "$p" ] || {{ echo "--- $p"; tail -n 25 "$p"; }}; done
  find "$dir" -maxdepth 1 -type f -name 'epoch_*.json' -printf '%f\\n' 2>/dev/null | sort | tail -n 3 | while read name; do p="$dir/$name"; echo "--- $p"; tail -n 25 "$p"; done
done
for p in "$ROOT/evidence/stage_b_job_attempt/attempt_001/failure.txt" "$ROOT/evidence/stage_b_job_attempt/attempt_001/completion.json" "$ROOT/logs/stage-b-$JOB.out" "$ROOT/logs/stage-b-$JOB.err"; do [ ! -f "$p" ] || {{ echo "--- $p"; tail -n 80 "$p"; }}; done
printf '%s\\n' '=== READ-ONLY USAGE LEDGER ==='
python -B - "$ROOT/evidence/stage_b_formal_data_usage.sqlite3" <<'PY'
import pathlib, sqlite3, sys
p = pathlib.Path(sys.argv[1])
if not p.is_file(): print('ledger_absent'); raise SystemExit(0)
db = sqlite3.connect('file:' + str(p) + '?mode=ro', uri=True)
for name, in db.execute("select name from sqlite_master where type='table' order by name"):
    print(name, db.execute('select count(*) from "' + name.replace('"','""') + '"').fetchone()[0])
db.close()
PY
'''


def _write_new_lf(path: Path, text: str) -> None:
    if "\r" in text: raise ValueError("generated shell contains CR")
    with path.open("x", encoding="utf-8", newline="\n") as handle: handle.write(text)


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__); sub = parser.add_subparsers(dest="action", required=True)
    build = sub.add_parser("build"); build.add_argument("--output-dir", required=True, type=Path)
    verify = sub.add_parser("verify-bundle"); verify.add_argument("--archive", required=True, type=Path); verify.add_argument("--manifest", required=True, type=Path)
    tree = sub.add_parser("verify-deployed-tree"); tree.add_argument("--root", required=True, type=Path); tree.add_argument("--manifest", required=True, type=Path); tree.add_argument("--trusted-manifest-sha256", required=True)
    deploy = sub.add_parser("deployment-command"); deploy.add_argument("--bundle-dir", required=True, type=Path); deploy.add_argument("--output", required=True, type=Path)
    query = sub.add_parser("query-command"); query.add_argument("--output", required=True, type=Path); query.add_argument("--job-id", required=True)
    receipt = sub.add_parser("parse-submission"); receipt.add_argument("--text", required=True)
    args = parser.parse_args(argv)
    if args.action == "build": result = build_bundle(args.output_dir)
    elif args.action == "verify-bundle": result = verify_bundle(args.archive, args.manifest)
    elif args.action == "verify-deployed-tree": result = verify_deployed_tree(args.root, args.manifest, args.trusted_manifest_sha256)
    elif args.action == "deployment-command": _write_new_lf(args.output, deployment_script(args.bundle_dir)); result = {"output": str(args.output)}
    elif args.action == "query-command": _write_new_lf(args.output, query_script(args.job_id)); result = {"output": str(args.output)}
    else: print(parse_submission_receipt(args.text)); return 0
    print(json.dumps(result, sort_keys=True)); return 0


if __name__ == "__main__": raise SystemExit(main())
