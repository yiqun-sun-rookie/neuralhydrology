#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""One-attempt formal Stage-B calibration entry point.

The command accepts only an immutable execution contract and a registered
seed.  Formal data remain the twelve byte ranges registered by Stage A, but a
new Stage-B authorization, purpose, ledger, output root, and attempt namespace
are mandatory.

Example::

    python scripts/modeling/run_zhenjiang_five_source_five_target_stage_b_v2.py \
      --execution-contract /.../stage_b_execution_contract.json \
      --execution-contract-sha256 <sha256> --seed 17
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import platform
import sys
from typing import BinaryIO, Callable, Dict, Iterable, Mapping, Optional, Sequence, Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader

PROJECT_ROOT = Path(__file__).resolve().parents[2]
for directory in (PROJECT_ROOT / "scripts" / "analysis", PROJECT_ROOT / "scripts" / "astronomical_tide"):
    if str(directory) not in sys.path:
        sys.path.insert(0, str(directory))

from run_zhenjiang_five_source_five_target_stage_a_v2 import (  # noqa: E402
    FormalContentSpec,
    StageAFormalDataContract,
    _parse_csv_series,
    _read_anchored_json,
    _strict_json_document,
    _tide_model_from_authorized_bytes,
    load_formal_data_contract,
    load_immutable_authorization,
)
from train_zhenjiang_five_source_five_target_d32_gru_v2 import (  # noqa: E402
    StageATrainingConfiguration,
)
from zhenjiang_five_source_five_target_d32_gru_v2 import (  # noqa: E402
    EXPECTED_PARAMETER_COUNT,
    FiveSourceFiveTargetD32GRU,
)
from zhenjiang_five_source_five_target_data_v2 import (  # noqa: E402
    AtomicUsageLedger,
    AuthorizedReadRequest,
    ImmutableDataAuthorization,
    build_data_from_arrays,
    build_split_datasets,
)
from zhenjiang_five_source_five_target_single_analysis_runner_v2 import (  # noqa: E402
    StageBBatch,
    evaluate_stage_b_batch,
    run_stage_b_training_step,
)
from zhenjiang_five_source_five_target_single_analysis_training_v2 import (  # noqa: E402
    FROZEN_STAGE_B_TRAINING_CONFIG,
    StageBEarlyStopping,
    build_stage_b_checkpoint_payload,
    build_stage_b_optimizer,
    save_stage_b_checkpoint_exclusive,
    stage_b_trainable_parameters,
)
from zhenjiang_five_source_five_target_single_analysis_ukf_v2 import (  # noqa: E402
    FiveSourceFiveTargetSingleAnalysisUKF,
    cross_covariance_distinguishability,
)
from zhenjiang_five_source_five_target_single_analysis_contract_v2 import (  # noqa: E402
    DATONG_BOUNDARY_MODE,
    EXPERIMENT_FAMILY,
    HISTORY_STATIONS,
    TARGET_STATIONS,
)

SCHEMA = "zhenjiang-five-source-five-target-stage-b-execution-v2"
FORMAL_PURPOSE = "stage_b_calibration_2017_2021_and_best_epoch_selection_2022"
TIME_PARTITION = "2017-2022"
SEED_ORDER = (17, 29, 43)
OLD_ROOT = PurePosixPath("/data1/home/sunyiq/zhenjiang_5s5t_stage_a_20260905_recovery_001")
NEW_ROOT = PurePosixPath("/data1/home/sunyiq/zhenjiang_5s5t_stage_b_20260907_001")
OUTPUT_ROOT = NEW_ROOT / "runs" / "stage_b"
LEDGER_PATH = NEW_ROOT / "evidence" / "stage_b_formal_data_usage.sqlite3"
ATTEMPT_ROOT = NEW_ROOT / "evidence" / "stage_b_attempts"
CHECKPOINT_SHA256 = {
    17: "374d3278c7e41dee0e2c1e937f936df442a44348a02addd46a2c4bb5b13b8263",
    29: "7e8a0376f47b3c7f217e004df2519b48dce3311ceb5f3203e1f844eb97c4ff46",
    43: "79b04446f4407496ceb8f0d85442ac2fe8ecd60db2d64e18c90a0bf3a13fe961",
}
NORMALIZATION_KEYS = (
    "history_stage", "future_wusongkou_astronomical_tide",
    "future_datong_observed_driver", "explicit_stage",
)


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _require_sha(value: object, label: str) -> str:
    if not isinstance(value, str) or len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
        raise ValueError(label + " must be a lowercase SHA-256")
    return value


def _exact_keys(value: object, keys: Iterable[str], label: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping) or set(value) != set(keys):
        raise ValueError(label + " keys differ from the frozen interface")
    return value


@dataclass(frozen=True)
class ExecutionContract:
    raw: Mapping[str, object]
    raw_sha256: str

    @property
    def seed_order(self) -> Tuple[int, ...]:
        return tuple(self.raw["seed_order"])


EXECUTION_KEYS = (
    "schema_version", "experiment_family", "boundary_mode", "stage",
    "formal_purpose", "time_partition", "seed_order",
    "old_stage_a_experiment_root", "source_stage_a_data_contract_path",
    "source_stage_a_data_contract_sha256", "stage_b_data_authorization_path",
    "stage_b_data_authorization_sha256", "paid_execution_authorization_path",
    "paid_execution_authorization_sha256", "stage_b_usage_ledger_path",
    "stage_b_output_root", "stage_b_attempt_root",
    "lifetime_prior_formal_read_count", "prior_2023_read_count",
    "prior_2024_read_count", "new_2023_read_count", "new_2024_read_count",
    "checkpoints", "normalization_sha256", "environment",
    "training_configuration", "first_attempt", "machine_contract_sha256",
)


def load_execution_contract(path: Path, trusted_sha256: str) -> ExecutionContract:
    document, actual = _read_anchored_json(path, trusted_sha256, "Stage-B execution contract")
    _exact_keys(document, EXECUTION_KEYS, "execution contract")
    fixed = {
        "schema_version": SCHEMA, "experiment_family": EXPERIMENT_FAMILY,
        "boundary_mode": DATONG_BOUNDARY_MODE, "stage": "stage_b",
        "formal_purpose": FORMAL_PURPOSE, "time_partition": TIME_PARTITION,
        "seed_order": list(SEED_ORDER), "old_stage_a_experiment_root": str(OLD_ROOT),
        "stage_b_usage_ledger_path": str(LEDGER_PATH),
        "stage_b_output_root": str(OUTPUT_ROOT), "stage_b_attempt_root": str(ATTEMPT_ROOT),
        "lifetime_prior_formal_read_count": 48, "prior_2023_read_count": 2,
        "prior_2024_read_count": "unknown", "new_2023_read_count": 0,
        "new_2024_read_count": 0, "first_attempt": True,
        "training_configuration": asdict(FROZEN_STAGE_B_TRAINING_CONFIG),
    }
    changed = [key for key, expected in fixed.items() if document[key] != expected]
    if changed:
        raise ValueError("execution contract changed frozen fields: " + ", ".join(changed))
    for key in ("source_stage_a_data_contract_sha256", "stage_b_data_authorization_sha256",
                "paid_execution_authorization_sha256", "machine_contract_sha256"):
        _require_sha(document[key], key)
    normalizations = _exact_keys(document["normalization_sha256"], NORMALIZATION_KEYS, "normalization SHA-256")
    for key, value in normalizations.items():
        _require_sha(value, str(key))
    checkpoints = _exact_keys(document["checkpoints"], ("17", "29", "43"), "checkpoints")
    for seed in SEED_ORDER:
        item = _exact_keys(checkpoints[str(seed)], ("path", "size_bytes", "sha256"), "checkpoint")
        path_value = PurePosixPath(item["path"])
        if item["size_bytes"] != 88882 or item["sha256"] != CHECKPOINT_SHA256[seed]:
            raise ValueError("checkpoint identity changed")
        if OLD_ROOT not in path_value.parents or path_value.name != "best_checkpoint.pt":
            raise ValueError("checkpoint must be an old-root best checkpoint")
    exact_paths = {
        "source_stage_a_data_contract_path": str(OLD_ROOT / "contracts" / "stage_a_data_contract.json"),
        "stage_b_data_authorization_path": str(NEW_ROOT / "contracts" / "stage_b_data_authorization.json"),
        "paid_execution_authorization_path": str(NEW_ROOT / "contracts" / "paid_execution_authorization.json"),
    }
    if any(document[key] != value for key, value in exact_paths.items()):
        raise ValueError("contract document path differs from the exact frozen path")
    return ExecutionContract(document, actual)


def validate_paid_execution_authorization(contract: ExecutionContract) -> Mapping[str, object]:
    document, _ = _read_anchored_json(
        contract.raw["paid_execution_authorization_path"],
        contract.raw["paid_execution_authorization_sha256"], "paid execution authorization")
    expected = {
        "schema_version": 1,
        "authorization_id": "ZJ-5S5T-V2-STAGE-B-HPC-20260907-01",
        "paid_hpc_execution_authorized": True, "stage": "stage_b",
        "remote_root": str(NEW_ROOT), "seed_order": list(SEED_ORDER),
        "maximum_sbatch_submissions": 1, "maximum_first_attempts_per_seed": 1,
        "automatic_retry": False, "automatic_requeue": False,
        "automatic_cancellation": False, "automatic_cleanup": False,
        "fail_stop_after_first_seed_failure": True,
        "stage_a_retraining_authorized": False, "evaluation_2022_authorized": False,
        "development_2023_authorized": False, "sealed_2024_authorized": False,
        "maximum_new_formal_object_reads": 36,
        "lifetime_prior_formal_read_count": 48,
        "success_requires": "observed_stage_b_optimizer_update",
    }
    missing = [key for key, value in expected.items() if document.get(key) != value]
    if missing:
        raise ValueError("paid execution authorization scope changed: " + ", ".join(missing))
    return document


def validate_formal_environment(expected: Mapping[str, object]) -> Mapping[str, object]:
    """Formal CUDA gate; synthetic helpers do not call it."""
    import pandas, scipy, psutil
    actual = {
        "python_version": platform.python_version(), "torch_version": torch.__version__,
        "numpy_version": np.__version__, "pandas_version": pandas.__version__,
        "scipy_version": scipy.__version__, "psutil_version": psutil.__version__,
        "cuda_version": torch.version.cuda, "cuda_available": torch.cuda.is_available(),
        "device_type": "cuda" if torch.cuda.is_available() else "cpu",
    }
    if torch.cuda.is_available():
        properties = torch.cuda.get_device_properties(0)
        actual.update(device_name=properties.name,
                      compute_capability=list(torch.cuda.get_device_capability(0)),
                      device_memory_bytes=properties.total_memory)
    expected_keys = ("python_version", "torch_version", "numpy_version", "pandas_version",
                     "scipy_version", "psutil_version", "cuda_version", "cuda_available",
                     "device_type", "device_name", "compute_capability", "minimum_device_memory_bytes")
    expected = _exact_keys(expected, expected_keys, "environment")
    for key in expected_keys[:-3]:
        if actual.get(key) != expected[key]:
            raise RuntimeError("formal environment mismatch: " + key)
    if actual.get("device_name") != expected["device_name"] or actual.get("compute_capability") != expected["compute_capability"]:
        raise RuntimeError("formal CUDA device identity mismatch")
    if actual.get("device_memory_bytes", 0) < expected["minimum_device_memory_bytes"]:
        raise RuntimeError("formal CUDA memory is below the minimum")
    return actual


def validate_authorization_binding(authorization: ImmutableDataAuthorization,
                                   source_contract: StageAFormalDataContract,
                                   ledger: AtomicUsageLedger, *, seed: int) -> None:
    if authorization.maximum_read_count != 36 or authorization.previous_access_count_confirmed != 0:
        raise ValueError("Stage-B authorization must provide a fresh 36-read ledger budget")
    if set(authorization.allowed_purposes) != {FORMAL_PURPOSE} or set(authorization.allowed_time_partitions) != {TIME_PARTITION}:
        raise ValueError("Stage-B purpose or years differ")
    if set(authorization.allowed_byte_ranges) != {item.authorized_byte_range for item in source_contract.files}:
        raise ValueError("Stage-B authorized ranges differ from the twelve registered inputs")
    if seed not in SEED_ORDER:
        raise ValueError("seed order changed")
    expected_prior = SEED_ORDER.index(seed) * 12
    records = ledger.event_records()
    if any(row["authorization_id"] != authorization.authorization_id for row in records):
        raise ValueError("ledger contains a foreign authorization")
    grouped: Dict[str, list] = defaultdict(list)
    for row in records:
        grouped[row["reservation_id"]].append(row)
    if len(grouped) != expected_prior:
        raise ValueError("seed does not match exact prior completed read count")
    observed = Counter()
    for rows in grouped.values():
        if [row["event_type"] for row in rows] != ["RESERVED", "COMPLETED"]:
            raise ValueError("prior reads must be complete RESERVED-to-COMPLETED pairs")
        first, second = rows
        immutable = ("authorization_id", "authorization_document_sha256", "purpose", "time_partition",
                     "path", "byte_offset", "byte_count", "expected_remaining_read_count")
        if any(first[key] != second[key] for key in immutable) or first["purpose"] != FORMAL_PURPOSE or second["bytes_read"] != first["byte_count"]:
            raise ValueError("prior ledger pair is inconsistent")
        if (first["authorization_document_sha256"]
                != authorization.authorization_document_sha256
                or first["time_partition"] != TIME_PARTITION):
            raise ValueError("prior ledger pair is bound to a foreign authorization or partition")
        observed[(first["path"], first["byte_offset"], first["byte_count"])] += 1
    expected = Counter((item.path, item.byte_offset, item.byte_count)
                       for item in source_contract.files for _ in range(SEED_ORDER.index(seed)))
    if observed != expected:
        raise ValueError("prior ledger does not cover each input exactly once per prior seed")


def read_authorized_content(specification: FormalContentSpec, authorization: ImmutableDataAuthorization,
                            ledger: AtomicUsageLedger, opener: Optional[Callable[[Path], BinaryIO]] = None) -> bytes:
    remaining = authorization.maximum_read_count - ledger.reserved_read_count(authorization.authorization_id)
    request = AuthorizedReadRequest(FORMAL_PURPOSE, TIME_PARTITION, specification.path,
                                    specification.byte_offset, specification.byte_count, remaining)
    reservation = ledger.reserve(authorization, request)
    count = 0
    try:
        with (opener or (lambda path: path.open("rb", buffering=0)))(Path(specification.path)) as handle:
            handle.seek(specification.byte_offset)
            content = handle.read(specification.byte_count)
        count = len(content)
        if count != specification.byte_count or sha256_bytes(content) != specification.content_sha256:
            raise RuntimeError("formal data byte identity differs")
        ledger.mark_completed(reservation, bytes_read=count)
        return content
    except BaseException as error:
        ledger.mark_failed(reservation, bytes_read=count, reason=f"{type(error).__name__}: {error}")
        raise


def load_partitions(source_contract: StageAFormalDataContract, authorization: ImmutableDataAuthorization,
                    ledger: AtomicUsageLedger):
    contents = {(item.role, item.station): read_authorized_content(item, authorization, ledger)
                for item in sorted(source_contract.files)}
    times = None
    stages, targets = [], []
    for station in HISTORY_STATIONS:
        current_times, values = _parse_csv_series(contents[("realtime_stage", station)], role="realtime_stage")
        if times is not None and not np.array_equal(times, current_times):
            raise RuntimeError("stage timelines differ")
        times = current_times
        stages.append(values)
    for station in TARGET_STATIONS:
        current_times, values = _parse_csv_series(contents[("retrospective_target", station)], role="retrospective_target")
        if not np.array_equal(times, current_times):
            raise RuntimeError("target timelines differ")
        targets.append(values)
    tide = _tide_model_from_authorized_bytes(contents[("wusongkou_astronomical_tide_model", "wusongkou")]).predict_float64(times)
    data = build_data_from_arrays(times_beijing=times, realtime_stages_m=np.stack(stages, axis=1),
                                  retrospective_targets_m=np.stack(targets, axis=1), astronomical_tide_m=tide,
                                  datong_identity=source_contract.datong_identity,
                                  explicit_stage_identity=source_contract.explicit_stage_identity)
    return data, build_split_datasets(data)


def load_stage_a_model(path: Path, *, seed: int, expected_sha256: str) -> FiveSourceFiveTargetD32GRU:
    raw = path.read_bytes()
    if len(raw) != 88882 or sha256_bytes(raw) != expected_sha256 or expected_sha256 != CHECKPOINT_SHA256[seed]:
        raise RuntimeError("Stage-A checkpoint raw-byte identity differs")
    checkpoint = torch.load(io.BytesIO(raw), map_location="cpu", weights_only=True)
    required = {"schema_version", "experiment_family", "boundary_mode", "stage", "seed", "epoch",
                "model_class", "training_years", "selection_year", "selection_use", "total_parameter_count",
                "stage_a_trainable_parameter_count", "explicit_stage_standard_deviations_m", "selection_metrics",
                "training_configuration", "model_state_dict"}
    _exact_keys(checkpoint, required, "Stage-A checkpoint")
    if checkpoint["seed"] != seed or checkpoint["stage"] != "stage_a" or checkpoint["experiment_family"] != EXPERIMENT_FAMILY:
        raise ValueError("Stage-A checkpoint seed or experiment binding differs")
    if checkpoint["total_parameter_count"] != EXPECTED_PARAMETER_COUNT or checkpoint["stage_a_trainable_parameter_count"] != EXPECTED_PARAMETER_COUNT:
        raise ValueError("Stage-A parameter count differs")
    if checkpoint["training_configuration"] != asdict(StageATrainingConfiguration()):
        raise ValueError("Stage-A frozen configuration differs")
    model = FiveSourceFiveTargetD32GRU()
    model.load_state_dict(checkpoint["model_state_dict"], strict=True)
    model.requires_grad_(False).eval()
    if sum(parameter.numel() for parameter in model.parameters()) != EXPECTED_PARAMETER_COUNT or any(p.requires_grad for p in model.parameters()):
        raise RuntimeError("exactly 20,416 backbone weights must be frozen")
    return model


def stage_b_batch_from_mapping(mapping: Mapping[str, object], scale: torch.Tensor, device: torch.device) -> StageBBatch:
    return StageBBatch(mapping["history"].to(device), mapping["future_control"].to(device),
                       mapping["analysis_observations"].to(device),
                       mapping["targets_a_plus_1_to_a_plus_23"].to(device), scale.to(device))


def _write_json_exclusive(path: Path, value: object) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")


def _append_jsonl_durable(path: Path, value: object) -> None:
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(value, sort_keys=True, allow_nan=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def partition_provenance(enumeration: object) -> Mapping[str, Mapping[str, object]]:
    """Return auditable candidate accounting and valid-origin identities."""
    result = {}
    for partition in enumeration.partitions:
        result[partition.partition_name] = {
            "raw_candidate_count": partition.raw_candidate_count,
            "cross_year_excluded_count": partition.cross_year_excluded_count,
            "missing_excluded_count": partition.missing_excluded_count,
            "valid_count": partition.valid_count,
            "valid_analysis_time_manifest_sha256": partition.valid_analysis_time_manifest_sha256,
        }
    if set(result) != {"training", "selection"}:
        raise ValueError("record enumeration must contain training and selection only")
    return result


def _checkpoint_snapshot(value: object) -> object:
    """Detach checkpoint tensors so best and last cannot share mutable storage."""
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().clone()
    if isinstance(value, Mapping):
        return {key: _checkpoint_snapshot(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_checkpoint_snapshot(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_checkpoint_snapshot(item) for item in value)
    return value


def finalize_stage_b_checkpoints(seed_dir: Path, *, best_payload: Mapping[str, object],
                                 last_payload: Mapping[str, object]) -> Mapping[str, Mapping[str, object]]:
    """Persist independent best/last snapshots and return their raw identities."""
    paths = {"best_checkpoint.pt": best_payload, "last_checkpoint.pt": last_payload}
    result = {}
    for name, payload_value in paths.items():
        path = seed_dir / name
        save_stage_b_checkpoint_exclusive(path, _checkpoint_snapshot(payload_value))
        result[name] = {"byte_count": path.stat().st_size, "sha256": sha256_file(path)}
    return result


def reserve_attempt(contract: ExecutionContract, seed: int, ledger: AtomicUsageLedger) -> Path:
    sequence_index = contract.seed_order.index(seed)
    seed_dir = Path(contract.raw["stage_b_output_root"]) / f"seed_{seed}"
    if seed_dir.exists():
        raise FileExistsError("seed output already exists")
    attempt_root = Path(contract.raw["stage_b_attempt_root"])
    if not attempt_root.is_dir() or not seed_dir.parent.is_dir():
        raise FileNotFoundError("Task-2 wrapper must create fixed output and attempt parents")
    marker = attempt_root / f"seed_{seed}_attempt_001.json"
    _write_json_exclusive(marker, {"seed": seed, "seed_sequence_index": sequence_index,
                                   "execution_contract_sha256": contract.raw_sha256, "first_attempt": True})
    seed_dir.mkdir(parents=False, exist_ok=False)
    return seed_dir


def _batch_factory(dataset, *, batch_size: int, seed: int, shuffle: bool,
                   scale: torch.Tensor, device: torch.device):
    generator = torch.Generator().manual_seed(seed)
    def factory():
        loader = DataLoader(dataset, batch_size=batch_size, shuffle=shuffle,
                            num_workers=0, generator=generator)
        for mapping in loader:
            yield stage_b_batch_from_mapping(mapping, scale, device)
    return factory


def run_formal_stage_b(contract: ExecutionContract, seed: int) -> Mapping[str, object]:
    """Run one seed with persistent batch, epoch, checkpoint, and failure evidence."""
    paid = validate_paid_execution_authorization(contract)
    environment = validate_formal_environment(contract.raw["environment"])
    source_contract, source_sha = load_formal_data_contract(
        contract.raw["source_stage_a_data_contract_path"],
        contract.raw["source_stage_a_data_contract_sha256"])
    authorization, authorization_sha = load_immutable_authorization(
        contract.raw["stage_b_data_authorization_path"],
        contract.raw["stage_b_data_authorization_sha256"])
    ledger = AtomicUsageLedger(Path(contract.raw["stage_b_usage_ledger_path"]))
    validate_authorization_binding(authorization, source_contract, ledger, seed=seed)
    if seed != 17:
        prior_seed = SEED_ORDER[SEED_ORDER.index(seed) - 1]
        prior_completion = Path(contract.raw["stage_b_output_root"]) / f"seed_{prior_seed}" / "completion.json"
        if not prior_completion.is_file():
            raise RuntimeError("previous seed has no immutable completion proof")
        prior = _strict_json_document(prior_completion.read_bytes(), "previous seed completion")
        if prior.get("status") != "complete" or prior.get("seed") != prior_seed:
            raise RuntimeError("previous seed completion proof is invalid")
    seed_dir = reserve_attempt(contract, seed, ledger)
    try:
        checkpoint_spec = contract.raw["checkpoints"][str(seed)]
        backbone = load_stage_a_model(Path(checkpoint_spec["path"]), seed=seed,
                                      expected_sha256=checkpoint_spec["sha256"])
        frozen_backbone = {name: value.detach().cpu().clone()
                           for name, value in backbone.state_dict().items()}
        model = FiveSourceFiveTargetSingleAnalysisUKF(backbone).to("cuda")
        data, datasets = load_partitions(source_contract, authorization, ledger)
        actual_normalization = {
            "history_stage": data.normalization.history_stage.normalization_sha256,
            "future_wusongkou_astronomical_tide": data.normalization.future_wusongkou_astronomical_tide.normalization_sha256,
            "future_datong_observed_driver": data.normalization.future_datong_observed_driver.normalization_sha256,
            "explicit_stage": data.normalization.explicit_stage.normalization_sha256,
        }
        if actual_normalization != contract.raw["normalization_sha256"]:
            raise RuntimeError("four normalization identities differ from execution contract")
        scale = torch.tensor(data.normalization.explicit_stage.std_m, dtype=torch.float32)
        train_factory = _batch_factory(datasets["training"], batch_size=32, seed=seed,
                                       shuffle=True, scale=scale, device=torch.device("cuda"))
        selection_factory = _batch_factory(datasets["selection"], batch_size=32, seed=seed,
                                           shuffle=False, scale=scale, device=torch.device("cuda"))
        # Structural preflight stops once all five sources have passed at least once.
        passes = torch.zeros(5, dtype=torch.bool)
        model.eval()
        with torch.no_grad():
            for batch in train_factory():
                output = model(batch.history, batch.future_control, batch.analysis_observations)
                passes |= cross_covariance_distinguishability(
                    output["analysis_unscented_covariance_before_process_noise"]).cpu()
                if bool(passes.all()):
                    break
        if not bool(passes.all()):
            raise RuntimeError("five-source distinguishability preflight failed")
        optimizer = build_stage_b_optimizer(model)
        stopping = StageBEarlyStopping()
        best_values = None
        training_log, selection_log = [], []
        for epoch in range(1, 21):
            epoch_sum = 0.0; epoch_cells = 0; batch_records = []
            for batch_index, batch in enumerate(train_factory(), 1):
                _, loss, gradients = run_stage_b_training_step(
                    model, batch, optimizer, require_preflight=False,
                    require_all_synthetic_gradients_nonzero=False)
                cells = int(batch.history.shape[0]) * 575
                epoch_sum += float(loss) * cells; epoch_cells += cells
                record = {"epoch": epoch, "batch_index": batch_index, "loss_m": float(loss),
                          "gradient_scalar_count": sum(value.numel() for value in gradients.values()),
                          "zero_gradient_scalar_count": sum(int(torch.count_nonzero(value == 0)) for value in gradients.values()),
                          "gradients_finite": all(bool(torch.isfinite(value).all()) for value in gradients.values()),
                          "gradients": {name: [float(item) for item in value.detach().cpu().tolist()]
                                        for name, value in sorted(gradients.items())}}
                _append_jsonl_durable(seed_dir / "batch_updates.jsonl", record)
                if epoch == 1 and batch_index == 1:
                    _write_json_exclusive(seed_dir / "first_optimizer_update.json", record)
                batch_records.append(record)
                print(json.dumps({"stage_b_optimizer_update_succeeded": True, **record}), flush=True)
            selection_sum = 0.0; selection_cells = 0
            for batch in selection_factory():
                _, loss = evaluate_stage_b_batch(model, batch)
                cells = int(batch.history.shape[0]) * 575
                selection_sum += float(loss) * cells; selection_cells += cells
            train_metric = epoch_sum / epoch_cells
            selection_metric = selection_sum / selection_cells
            improved = stopping.observe(epoch, selection_metric)
            training_log.append({"epoch": epoch, "training_575_cell_mae_m": train_metric,
                                 "batch_gradient_audit": batch_records})
            selection_log.append({"epoch": epoch, "selection_2022_575_cell_mae_m": selection_metric,
                                  "selected_as_best": improved})
            epoch_record = {"epoch": epoch, "training_575_cell_mae_m": train_metric,
                            "selection_2022_575_cell_mae_m": selection_metric,
                            "selected_as_best": improved}
            _write_json_exclusive(seed_dir / f"epoch_{epoch:02d}.json", epoch_record)
            payload = build_stage_b_checkpoint_payload(
                model, stage_a_checkpoint_sha256=checkpoint_spec["sha256"],
                upstream_sha256={
                    "machine_contract_sha256": contract.raw["machine_contract_sha256"],
                    "data_contract_sha256": contract.raw_sha256,
                    "source_stage_a_data_contract_sha256": source_sha,
                    "history_stage_normalization_sha256": actual_normalization["history_stage"],
                    "future_wusongkou_astronomical_tide_normalization_sha256": actual_normalization["future_wusongkou_astronomical_tide"],
                    "future_datong_observed_driver_normalization_sha256": actual_normalization["future_datong_observed_driver"],
                    "explicit_stage_normalization_sha256": actual_normalization["explicit_stage"],
                }, distinguishability_passes=passes.tolist(), model_seed=seed,
                best_epoch=stopping.best_epoch, best_selection_metric_m=stopping.best_metric_m,
                training_log=training_log, selection_log=selection_log)
            save_stage_b_checkpoint_exclusive(seed_dir / f"checkpoint_epoch_{epoch:02d}.pt", payload)
            if improved:
                best_values = tuple(value.detach().clone() for value in stage_b_trainable_parameters(model))
            if stopping.should_stop:
                break
        if best_values is None:
            raise RuntimeError("no best Stage-B epoch")
        if any(not torch.equal(frozen_backbone[name], value.detach().cpu())
               for name, value in model.backbone.state_dict().items()):
            raise RuntimeError("a frozen Stage-A backbone tensor changed")
        with torch.no_grad():
            for parameter, value in zip(stage_b_trainable_parameters(model), best_values):
                parameter.copy_(value)
        best_payload = dict(payload)
        best_payload["raw_process_standard_deviation"] = model.analysis_noise.raw_process_standard_deviation.detach().cpu()
        best_payload["raw_observation_standard_deviation"] = model.analysis_noise.raw_observation_standard_deviation.detach().cpu()
        checkpoint_files = finalize_stage_b_checkpoints(
            seed_dir, best_payload=best_payload, last_payload=payload)
        receipt = {"status": "complete", "seed": seed, "best_epoch": stopping.best_epoch,
                   "stage": "stage_b", "boundary_mode": DATONG_BOUNDARY_MODE,
                   "experiment_family": EXPERIMENT_FAMILY,
                   "epochs_completed": len(training_log),
                   "best_selection_metric_m": stopping.best_metric_m,
                   "authorization_sha256": authorization_sha, "source_data_contract_sha256": source_sha,
                   "execution_contract_sha256": contract.raw_sha256,
                   "ledger_snapshot_sha256": ledger.logical_snapshot_sha256(),
                   "normalization_sha256": actual_normalization, "environment": environment,
                   "sample_enumeration": partition_provenance(data.record_enumeration),
                   "checkpoint_files": checkpoint_files,
                   "frozen_backbone_parameter_count": EXPECTED_PARAMETER_COUNT,
                   "frozen_backbone_all_tensors_bitwise_unchanged": True,
                   "first_optimizer_update_proof": "first_optimizer_update.json",
                   "paid_authorization_id": paid["authorization_id"]}
        _write_json_exclusive(seed_dir / "completion.json", receipt)
        return receipt
    except BaseException as error:
        _write_json_exclusive(seed_dir / "failure.json", {"status": "failed", "seed": seed,
                              "error_type": type(error).__name__, "error": str(error),
                              "ledger_snapshot_sha256": ledger.logical_snapshot_sha256()})
        raise


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execution-contract", required=True)
    parser.add_argument("--execution-contract-sha256", required=True)
    parser.add_argument("--seed", required=True, type=int, choices=SEED_ORDER)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_argument_parser().parse_args(argv)
    # Formal orchestration is intentionally gated before any formal data handle.
    contract = load_execution_contract(Path(args.execution_contract), args.execution_contract_sha256)
    receipt = run_formal_stage_b(contract, args.seed)
    print(json.dumps(receipt, indent=2, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = ["ExecutionContract", "FORMAL_PURPOSE", "load_execution_contract",
           "load_stage_a_model", "read_authorized_content", "stage_b_batch_from_mapping",
           "validate_authorization_binding", "validate_formal_environment",
           "validate_paid_execution_authorization"]
