#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Stage-B training contract for the five-source single-analysis model.

Only the five effective process-noise standard-deviation parameters and five
effective observation-noise standard-deviation parameters are optimized.  The
backbone is frozen, but updated states must retain an input-gradient path
through all 23 deterministic process-model steps.

Example:
    pytest -q -p no:cacheprovider \
      tests/test_zhenjiang_five_source_five_target_single_analysis_training_v2.py
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import os
from pathlib import Path
import re
from typing import Dict, Iterable, Mapping, Sequence

import torch

from zhenjiang_five_source_five_target_single_analysis_ukf_v2 import (
    FiveSourceFiveTargetSingleAnalysisUKF,
    cross_covariance_distinguishability,
)


SOURCE_COUNT = 5
FORECAST_HOURS = 23
TARGET_COUNT = 5
STAGE_B_ERROR_CELL_COUNT_PER_SAMPLE = SOURCE_COUNT * FORECAST_HOURS * TARGET_COUNT
SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")
EXPERIMENT_FAMILY = (
    "ZHENJIANG_FIVE_SOURCE_FIVE_TARGET_D32_GRU_"
    "SINGLE_ANALYSIS_UKF_ORACLE_DATONG_V2"
)
DATONG_BOUNDARY_MODE = "retrospective_observed_oracle"
ALLOWED_MODEL_SEEDS = (17, 29, 43)
REQUIRED_STAGE_B_UPSTREAM_SHA256_KEYS = (
    "machine_contract_sha256",
    "data_contract_sha256",
    "history_stage_normalization_sha256",
    "future_wusongkou_astronomical_tide_normalization_sha256",
    "future_datong_observed_driver_normalization_sha256",
    "explicit_stage_normalization_sha256",
)


@dataclass(frozen=True)
class StageBTrainingConfig:
    """Frozen optimization and early-stopping settings for stage B."""

    batch_size: int = 32
    optimizer_name: str = "Adam"
    learning_rate: float = 0.001
    gradient_norm_limit: float = 1.0
    maximum_epochs: int = 20
    early_stopping_patience: int = 4
    minimum_selection_improvement_m: float = 0.0001
    selection_period: str = "2022"
    selection_metric: str = "updated_forecast_575_cell_equal_weight_mae_m"


FROZEN_STAGE_B_TRAINING_CONFIG = StageBTrainingConfig()


def validate_frozen_stage_b_config(
    config: StageBTrainingConfig | None,
) -> StageBTrainingConfig:
    """Return the sole registered stage-B configuration or fail closed."""

    resolved = config or FROZEN_STAGE_B_TRAINING_CONFIG
    if resolved != FROZEN_STAGE_B_TRAINING_CONFIG:
        raise ValueError("stage-B training configuration is frozen")
    return resolved


class StageBEarlyStopping:
    """Keep the earlier epoch unless improvement is at least 0.0001 m."""

    def __init__(
        self,
        patience: int = 4,
        minimum_improvement_m: float = 0.0001,
    ) -> None:
        if type(patience) is not int or patience < 1:
            raise ValueError("patience must be a positive integer")
        if minimum_improvement_m <= 0.0:
            raise ValueError("minimum improvement must be positive")
        if (
            patience != FROZEN_STAGE_B_TRAINING_CONFIG.early_stopping_patience
            or float(minimum_improvement_m)
            != FROZEN_STAGE_B_TRAINING_CONFIG.minimum_selection_improvement_m
        ):
            raise ValueError("stage-B early stopping configuration is frozen")
        self.patience = patience
        self.minimum_improvement_m = float(minimum_improvement_m)
        self.best_metric_m: float | None = None
        self.best_epoch: int | None = None
        self.epochs_without_improvement = 0

    def observe(self, epoch: int, metric_m: float) -> bool:
        """Return true only when the frozen replacement rule is satisfied."""

        if type(epoch) is not int or epoch < 1:
            raise ValueError("epoch must be a positive integer")
        if not torch.isfinite(torch.tensor(metric_m, dtype=torch.float64)):
            raise ValueError("selection metric must be finite")
        improved = (
            self.best_metric_m is None
            or float(metric_m)
            <= self.best_metric_m - self.minimum_improvement_m
        )
        if improved:
            self.best_metric_m = float(metric_m)
            self.best_epoch = epoch
            self.epochs_without_improvement = 0
        else:
            self.epochs_without_improvement += 1
        return improved

    @property
    def should_stop(self) -> bool:
        return self.epochs_without_improvement >= self.patience


def stage_b_absolute_error_loss(
    updated_forecast: torch.Tensor,
    target: torch.Tensor,
    explicit_stage_scale_m: torch.Tensor,
) -> torch.Tensor:
    """Return the equal-weight mean over exactly 575 metre-error cells."""

    if updated_forecast.ndim != 4 or updated_forecast.shape[1:] != (
        SOURCE_COUNT,
        FORECAST_HOURS,
        TARGET_COUNT,
    ):
        raise ValueError("updated forecast must have shape [batch, 5, 23, 5]")
    batch_size = int(updated_forecast.shape[0])
    if target.shape != (batch_size, FORECAST_HOURS, TARGET_COUNT):
        raise ValueError("target must have shape [batch, 23, 5]")
    if explicit_stage_scale_m.shape != (TARGET_COUNT,):
        raise ValueError("explicit stage scale must have shape [5]")
    if target.device != updated_forecast.device or explicit_stage_scale_m.device != updated_forecast.device:
        raise ValueError("loss tensors must share one device")
    if not updated_forecast.dtype.is_floating_point or not target.dtype.is_floating_point:
        raise ValueError("forecast and target must be floating point")
    if not explicit_stage_scale_m.dtype.is_floating_point:
        raise ValueError("explicit stage scale must be floating point")
    if not bool(torch.isfinite(updated_forecast).all()) or not bool(
        torch.isfinite(target).all()
    ) or not bool(torch.isfinite(explicit_stage_scale_m).all()):
        raise ValueError("stage-B loss received a nonfinite value")
    if bool((explicit_stage_scale_m <= 0.0).any()):
        raise ValueError("explicit stage scales must be positive")
    if updated_forecast[0].numel() != STAGE_B_ERROR_CELL_COUNT_PER_SAMPLE:
        raise RuntimeError("stage-B sample must contain exactly 575 error cells")
    error_m = (
        updated_forecast - target[:, None, :, :]
    ) * explicit_stage_scale_m[None, None, None, :]
    return error_m.abs().mean(dtype=torch.float64)


def freeze_backbone_for_stage_b(
    model: FiveSourceFiveTargetSingleAnalysisUKF,
) -> None:
    """Freeze and put the shared process backbone in evaluation mode."""

    if not isinstance(model, FiveSourceFiveTargetSingleAnalysisUKF):
        raise ValueError("model must be a five-source single-analysis model")
    model.backbone.requires_grad_(False)
    model.backbone.eval()
    if any(parameter.requires_grad for parameter in model.backbone.parameters()):
        raise RuntimeError("all backbone parameters must be frozen")


def stage_b_trainable_parameters(
    model: FiveSourceFiveTargetSingleAnalysisUKF,
) -> Sequence[torch.nn.Parameter]:
    """Return the two registered vectors containing exactly ten scalars."""

    freeze_backbone_for_stage_b(model)
    parameters = (
        model.analysis_noise.raw_process_standard_deviation,
        model.analysis_noise.raw_observation_standard_deviation,
    )
    if sum(parameter.numel() for parameter in parameters) != 10:
        raise RuntimeError("stage-B optimizer must receive exactly ten scalars")
    all_trainable = {
        id(parameter)
        for parameter in model.parameters()
        if parameter.requires_grad
    }
    if all_trainable != {id(parameter) for parameter in parameters}:
        raise RuntimeError("an unregistered stage-B parameter is trainable")
    return parameters


def build_stage_b_optimizer(
    model: FiveSourceFiveTargetSingleAnalysisUKF,
    config: StageBTrainingConfig | None = None,
) -> torch.optim.Adam:
    """Build the frozen Adam optimizer over only the ten analysis scalars."""

    resolved = validate_frozen_stage_b_config(config)
    if resolved.optimizer_name != "Adam":
        raise ValueError("stage-B optimizer must be Adam")
    return torch.optim.Adam(
        stage_b_trainable_parameters(model),
        lr=resolved.learning_rate,
    )


def require_cross_covariance_distinguishability(
    stabilized_covariance_before_q: torch.Tensor,
) -> torch.Tensor:
    """Raise unless every source passes on at least one training sample."""

    passes = cross_covariance_distinguishability(
        stabilized_covariance_before_q
    )
    if passes.shape != (SOURCE_COUNT,) or not bool(passes.all()):
        failed = [str(index) for index, value in enumerate(passes.tolist()) if not value]
        raise RuntimeError(
            "cross-covariance distinguishability failed for source indices: %s"
            % ",".join(failed)
        )
    return passes


def validate_stage_b_gradients(
    model: FiveSourceFiveTargetSingleAnalysisUKF,
    *,
    require_nonzero: bool,
) -> Dict[str, torch.Tensor]:
    """Validate the frozen-backbone and ten-analysis-parameter gradient path."""

    backbone_gradients = [
        parameter.grad
        for parameter in model.backbone.parameters()
        if parameter.grad is not None
    ]
    if backbone_gradients:
        raise RuntimeError("backbone parameters must not receive gradients")
    gradients: Dict[str, torch.Tensor] = {}
    for name, parameter in (
        (
            "raw_process_standard_deviation",
            model.analysis_noise.raw_process_standard_deviation,
        ),
        (
            "raw_observation_standard_deviation",
            model.analysis_noise.raw_observation_standard_deviation,
        ),
    ):
        if parameter.grad is None:
            raise RuntimeError("%s did not receive a gradient" % name)
        if not bool(torch.isfinite(parameter.grad).all()):
            raise RuntimeError("%s gradient is nonfinite" % name)
        if require_nonzero and bool((parameter.grad == 0.0).any()):
            raise RuntimeError("%s synthetic gradient must be nonzero" % name)
        gradients[name] = parameter.grad.detach().clone()
    if sum(gradient.numel() for gradient in gradients.values()) != 10:
        raise RuntimeError("gradient audit must cover exactly ten scalars")
    return gradients


def _validate_sha256(value: str, *, label: str) -> str:
    if not isinstance(value, str) or SHA256_PATTERN.fullmatch(value) is None:
        raise ValueError("%s must be a lowercase SHA-256" % label)
    return value


def build_stage_b_checkpoint_payload(
    model: FiveSourceFiveTargetSingleAnalysisUKF,
    *,
    stage_a_checkpoint_sha256: str,
    upstream_sha256: Mapping[str, str],
    distinguishability_passes: Iterable[bool],
    model_seed: int,
    best_epoch: int,
    best_selection_metric_m: float,
    training_log: Sequence[Mapping[str, object]],
    selection_log: Sequence[Mapping[str, object]],
    config: StageBTrainingConfig | None = None,
) -> Dict[str, object]:
    """Build a traceable payload without opening or selecting any checkpoint."""

    _validate_sha256(
        stage_a_checkpoint_sha256, label="stage-A checkpoint SHA-256"
    )
    normalized_upstream = {
        str(name): _validate_sha256(value, label="upstream SHA-256")
        for name, value in sorted(upstream_sha256.items())
    }
    if not normalized_upstream:
        raise ValueError("at least one upstream contract SHA-256 is required")
    missing_upstream = sorted(
        set(REQUIRED_STAGE_B_UPSTREAM_SHA256_KEYS) - set(normalized_upstream)
    )
    if missing_upstream:
        raise ValueError(
            "missing required stage-B upstream SHA-256 keys: %s"
            % ",".join(missing_upstream)
        )
    if model_seed not in ALLOWED_MODEL_SEEDS:
        raise ValueError("model_seed must be one of 17, 29, or 43")
    if type(best_epoch) is not int or not (
        1 <= best_epoch <= FROZEN_STAGE_B_TRAINING_CONFIG.maximum_epochs
    ):
        raise ValueError("best_epoch is outside the frozen stage-B epoch range")
    if not torch.isfinite(
        torch.tensor(best_selection_metric_m, dtype=torch.float64)
    ) or best_selection_metric_m < 0.0:
        raise ValueError("best_selection_metric_m must be finite and nonnegative")
    passes = tuple(bool(value) for value in distinguishability_passes)
    if passes != (True,) * SOURCE_COUNT:
        raise ValueError("all five distinguishability checks must pass")
    frozen_training_log = [dict(item) for item in training_log]
    frozen_selection_log = [dict(item) for item in selection_log]
    if not frozen_training_log or not frozen_selection_log:
        raise ValueError("stage-B training and selection logs must be nonempty")
    resolved_config = validate_frozen_stage_b_config(config)
    return {
        "schema_version": "2.0",
        "experiment_family": EXPERIMENT_FAMILY,
        "boundary_mode": DATONG_BOUNDARY_MODE,
        "stage": "stage_b",
        "model_seed": model_seed,
        "best_epoch": best_epoch,
        "best_selection_metric_m": float(best_selection_metric_m),
        "trainable_scalar_count": 10,
        "stage_a_checkpoint_sha256": stage_a_checkpoint_sha256,
        "upstream_sha256": normalized_upstream,
        "distinguishability_passes": list(passes),
        "training_config": asdict(resolved_config),
        "training_log": frozen_training_log,
        "selection_log": frozen_selection_log,
        "raw_process_standard_deviation": (
            model.analysis_noise.raw_process_standard_deviation.detach().cpu()
        ),
        "raw_observation_standard_deviation": (
            model.analysis_noise.raw_observation_standard_deviation.detach().cpu()
        ),
        "fixed_hidden_process_variance": (
            model.analysis_noise.fixed_hidden_process_variance.detach().cpu()
        ),
    }


def save_stage_b_checkpoint_exclusive(
    checkpoint_path: Path,
    payload: Mapping[str, object],
) -> None:
    """Create one new checkpoint path and fail rather than overwrite it."""

    path = Path(checkpoint_path)
    if not path.parent.is_dir():
        raise ValueError("checkpoint parent directory must already exist")
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            torch.save(dict(payload), handle)
    except BaseException:
        raise


__all__ = [
    "FROZEN_STAGE_B_TRAINING_CONFIG",
    "REQUIRED_STAGE_B_UPSTREAM_SHA256_KEYS",
    "STAGE_B_ERROR_CELL_COUNT_PER_SAMPLE",
    "StageBEarlyStopping",
    "StageBTrainingConfig",
    "build_stage_b_checkpoint_payload",
    "build_stage_b_optimizer",
    "freeze_backbone_for_stage_b",
    "require_cross_covariance_distinguishability",
    "save_stage_b_checkpoint_exclusive",
    "stage_b_absolute_error_loss",
    "stage_b_trainable_parameters",
    "validate_stage_b_gradients",
    "validate_frozen_stage_b_config",
]
