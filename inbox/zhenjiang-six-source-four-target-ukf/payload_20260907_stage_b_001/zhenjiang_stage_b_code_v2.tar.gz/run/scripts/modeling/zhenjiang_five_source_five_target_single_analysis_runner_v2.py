#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Synthetic-safe stage-B runner for the single-analysis model.

The runner accepts already constructed tensors and never discovers or opens a
formal data source.  A caller with separately authorized data may later adapt
the same batch interface.  The training path intentionally does not wrap the
23-hour updated forecast in ``torch.no_grad``.

Example:
    python scripts/modeling/zhenjiang_five_source_five_target_single_analysis_runner_v2.py \
      --describe-contract
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from typing import Callable, Dict, Iterable, Mapping, Tuple

import torch

from zhenjiang_five_source_five_target_single_analysis_training_v2 import (
    STAGE_B_ERROR_CELL_COUNT_PER_SAMPLE,
    StageBEarlyStopping,
    StageBTrainingConfig,
    build_stage_b_checkpoint_payload,
    build_stage_b_optimizer,
    require_cross_covariance_distinguishability,
    stage_b_absolute_error_loss,
    stage_b_trainable_parameters,
    validate_stage_b_gradients,
    validate_frozen_stage_b_config,
)
from zhenjiang_five_source_five_target_single_analysis_ukf_v2 import (
    FiveSourceFiveTargetSingleAnalysisUKF,
    cross_covariance_distinguishability,
)


@dataclass(frozen=True)
class StageBBatch:
    """One in-memory batch with no path or file-discovery capability."""

    history: torch.Tensor
    future_control: torch.Tensor
    analysis_observations: torch.Tensor
    targets_a_plus_1_to_a_plus_23: torch.Tensor
    explicit_stage_scale_m: torch.Tensor


@dataclass(frozen=True)
class StageBTrainingRunResult:
    """Complete in-memory training result restored to its best 2022 epoch."""

    model_seed: int
    epochs_completed: int
    best_epoch: int
    best_selection_metric_m: float
    distinguishability_passes: Tuple[bool, ...]
    training_log: Tuple[Mapping[str, object], ...]
    selection_log: Tuple[Mapping[str, object], ...]
    checkpoint_payload: Mapping[str, object]


def _factory_batches(
    factory: Callable[[], Iterable[StageBBatch]], *, label: str
) -> Iterable[StageBBatch]:
    if not callable(factory):
        raise ValueError(f"{label} batch factory must be callable")
    produced = False
    for batch in factory():
        produced = True
        if not isinstance(batch, StageBBatch):
            raise ValueError(f"{label} factory must yield StageBBatch objects")
        yield batch
    if not produced:
        raise ValueError(f"{label} batch factory yielded no batches")


def _batch_error_cell_count(batch: StageBBatch) -> int:
    targets = batch.targets_a_plus_1_to_a_plus_23
    if not isinstance(targets, torch.Tensor) or targets.ndim != 3:
        raise ValueError("stage-B target must be a three-dimensional tensor")
    batch_size = int(targets.shape[0])
    if batch_size < 1:
        raise ValueError("stage-B batch must contain at least one sample")
    return batch_size * STAGE_B_ERROR_CELL_COUNT_PER_SAMPLE


def _preflight_training_batches(
    model: FiveSourceFiveTargetSingleAnalysisUKF,
    training_batch_factory: Callable[[], Iterable[StageBBatch]],
) -> Tuple[bool, ...]:
    """Require each source to pass in at least one legitimate training sample."""

    passes = torch.zeros(5, dtype=torch.bool)
    model.eval()
    with torch.no_grad():
        for batch in _factory_batches(
            training_batch_factory, label="training preflight"
        ):
            outputs = model(
                batch.history,
                batch.future_control,
                batch.analysis_observations,
            )
            batch_passes = cross_covariance_distinguishability(
                outputs["analysis_unscented_covariance_before_process_noise"]
            ).detach().cpu()
            passes |= batch_passes
    if not bool(passes.all()):
        failed = [str(index) for index, value in enumerate(passes) if not bool(value)]
        raise RuntimeError(
            "cross-covariance distinguishability failed for source indices: %s"
            % ",".join(failed)
        )
    return tuple(bool(value) for value in passes.tolist())


def run_stage_b_training_step(
    model: FiveSourceFiveTargetSingleAnalysisUKF,
    batch: StageBBatch,
    optimizer: torch.optim.Optimizer,
    *,
    require_preflight: bool,
    require_all_synthetic_gradients_nonzero: bool,
    config: StageBTrainingConfig | None = None,
) -> Tuple[Mapping[str, object], torch.Tensor, Dict[str, torch.Tensor]]:
    """Run one differentiable in-memory optimization step."""

    resolved = validate_frozen_stage_b_config(config)
    registered_parameters = tuple(stage_b_trainable_parameters(model))
    optimizer_parameters = tuple(
        parameter
        for group in optimizer.param_groups
        for parameter in group["params"]
    )
    if {id(value) for value in optimizer_parameters} != {
        id(value) for value in registered_parameters
    }:
        raise ValueError("optimizer parameters do not match the ten-scalar contract")

    model.train()
    optimizer.zero_grad(set_to_none=True)
    outputs = model(
        batch.history,
        batch.future_control,
        batch.analysis_observations,
    )
    if require_preflight:
        require_cross_covariance_distinguishability(
            outputs["analysis_unscented_covariance_before_process_noise"]
        )
    loss = stage_b_absolute_error_loss(
        outputs["updated_forecast"],
        batch.targets_a_plus_1_to_a_plus_23,
        batch.explicit_stage_scale_m,
    )
    loss.backward()
    gradients = validate_stage_b_gradients(
        model,
        require_nonzero=require_all_synthetic_gradients_nonzero,
    )
    torch.nn.utils.clip_grad_norm_(
        registered_parameters,
        max_norm=resolved.gradient_norm_limit,
    )
    optimizer.step()
    return outputs, loss.detach(), gradients


def evaluate_stage_b_batch(
    model: FiveSourceFiveTargetSingleAnalysisUKF,
    batch: StageBBatch,
) -> Tuple[Mapping[str, object], torch.Tensor]:
    """Evaluate one in-memory batch without changing any parameter."""

    model.eval()
    with torch.no_grad():
        outputs = model(
            batch.history,
            batch.future_control,
            batch.analysis_observations,
        )
        loss = stage_b_absolute_error_loss(
            outputs["updated_forecast"],
            batch.targets_a_plus_1_to_a_plus_23,
            batch.explicit_stage_scale_m,
        )
    return outputs, loss


def train_stage_b_in_memory(
    model: FiveSourceFiveTargetSingleAnalysisUKF,
    *,
    model_seed: int,
    training_batch_factory: Callable[[], Iterable[StageBBatch]],
    selection_2022_batch_factory: Callable[[], Iterable[StageBBatch]],
    stage_a_checkpoint_sha256: str,
    upstream_sha256: Mapping[str, str],
    config: StageBTrainingConfig | None = None,
) -> StageBTrainingRunResult:
    """Run the complete frozen stage-B loop without opening data or paths."""

    resolved = validate_frozen_stage_b_config(config)
    distinguishability_passes = _preflight_training_batches(
        model, training_batch_factory
    )
    optimizer = build_stage_b_optimizer(model, resolved)
    early_stopping = StageBEarlyStopping(
        patience=resolved.early_stopping_patience,
        minimum_improvement_m=resolved.minimum_selection_improvement_m,
    )
    training_log = []
    selection_log = []
    best_parameter_values = None

    for epoch in range(1, resolved.maximum_epochs + 1):
        training_error_sum = 0.0
        training_cell_count = 0
        batch_gradient_log = []
        for batch_index, batch in enumerate(
            _factory_batches(training_batch_factory, label="training"),
            start=1,
        ):
            _, loss, gradients = run_stage_b_training_step(
                model,
                batch,
                optimizer,
                require_preflight=False,
                require_all_synthetic_gradients_nonzero=False,
                config=resolved,
            )
            cell_count = _batch_error_cell_count(batch)
            training_error_sum += float(loss) * cell_count
            training_cell_count += cell_count
            batch_gradient_log.append(
                {
                    "batch_index": batch_index,
                    "gradient_scalar_count": sum(
                        gradient.numel() for gradient in gradients.values()
                    ),
                    "zero_gradient_scalar_count": sum(
                        int(torch.count_nonzero(gradient == 0.0))
                        for gradient in gradients.values()
                    ),
                    "gradients": {
                        name: [float(value) for value in gradient.cpu().tolist()]
                        for name, gradient in sorted(gradients.items())
                    },
                }
            )
        training_metric_m = training_error_sum / training_cell_count

        selection_error_sum = 0.0
        selection_cell_count = 0
        for batch in _factory_batches(
            selection_2022_batch_factory, label="2022 selection"
        ):
            _, loss = evaluate_stage_b_batch(model, batch)
            cell_count = _batch_error_cell_count(batch)
            selection_error_sum += float(loss) * cell_count
            selection_cell_count += cell_count
        selection_metric_m = selection_error_sum / selection_cell_count
        improved = early_stopping.observe(epoch, selection_metric_m)
        training_log.append(
            {
                "epoch": epoch,
                "training_575_cell_mae_m": training_metric_m,
                "batch_gradient_audit": batch_gradient_log,
            }
        )
        selection_log.append(
            {
                "epoch": epoch,
                "selection_2022_575_cell_mae_m": selection_metric_m,
                "selected_as_best": improved,
            }
        )
        if improved:
            best_parameter_values = tuple(
                parameter.detach().clone()
                for parameter in stage_b_trainable_parameters(model)
            )
        if early_stopping.should_stop:
            break

    if (
        best_parameter_values is None
        or early_stopping.best_epoch is None
        or early_stopping.best_metric_m is None
    ):
        raise RuntimeError("stage-B training completed without a best epoch")
    with torch.no_grad():
        for parameter, best_value in zip(
            stage_b_trainable_parameters(model), best_parameter_values
        ):
            parameter.copy_(best_value)

    checkpoint_payload = build_stage_b_checkpoint_payload(
        model,
        stage_a_checkpoint_sha256=stage_a_checkpoint_sha256,
        upstream_sha256=upstream_sha256,
        distinguishability_passes=distinguishability_passes,
        model_seed=model_seed,
        best_epoch=early_stopping.best_epoch,
        best_selection_metric_m=early_stopping.best_metric_m,
        training_log=training_log,
        selection_log=selection_log,
        config=resolved,
    )
    return StageBTrainingRunResult(
        model_seed=model_seed,
        epochs_completed=len(training_log),
        best_epoch=early_stopping.best_epoch,
        best_selection_metric_m=early_stopping.best_metric_m,
        distinguishability_passes=distinguishability_passes,
        training_log=tuple(training_log),
        selection_log=tuple(selection_log),
        checkpoint_payload=checkpoint_payload,
    )


def contract_description() -> Dict[str, object]:
    """Return the frozen, data-free runner interface."""

    config = StageBTrainingConfig()
    return {
        "schema_version": "2.0",
        "input_shapes": {
            "history": ["B", 24, 6],
            "future_control": ["B", 24, 2],
            "analysis_observations": ["B", 5],
            "targets_a_plus_1_to_a_plus_23": ["B", 23, 5],
            "explicit_stage_scale_m": [5],
        },
        "prediction_shapes": {
            "open_loop_forecast": ["B", 23, 5],
            "updated_forecast": ["B", 5, 23, 5],
        },
        "trainable_scalar_count": 10,
        "error_cells_per_sample": 575,
        "future_unscented_prediction_count": 0,
        "post_analysis_covariance_propagation_count": 0,
        "training_config": config.__dict__,
    }


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Describe the synthetic-safe stage-B runner contract."
    )
    parser.add_argument(
        "--describe-contract",
        action="store_true",
        help="print the frozen interface without opening data or running training",
    )
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    if not args.describe_contract:
        raise SystemExit(
            "No formal execution is available without a separate data and run authorization."
        )
    print(json.dumps(contract_description(), ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "StageBBatch",
    "StageBTrainingRunResult",
    "contract_description",
    "evaluate_stage_b_batch",
    "run_stage_b_training_step",
    "train_stage_b_in_memory",
]
