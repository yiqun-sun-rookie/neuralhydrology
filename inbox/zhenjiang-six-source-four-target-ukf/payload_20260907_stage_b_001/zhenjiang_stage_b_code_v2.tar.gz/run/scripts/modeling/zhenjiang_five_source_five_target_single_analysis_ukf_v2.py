#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Single-analysis unscented update for the five-source/five-target model.

This module contains model mathematics only.  It never opens a data file,
selects a checkpoint, creates an experiment directory, or submits work.  One
65-point unscented prediction advances the encoded state from ``a-1`` to
``a``.  The open-loop state and five independent scalar-update states then
advance for 23 hours through the deterministic neural process model only.

Example:
    pytest -q -p no:cacheprovider \
      tests/test_zhenjiang_five_source_five_target_single_analysis_ukf_v2.py
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, Mapping, Tuple

import torch
from torch import nn
from torch.nn import functional as F


STATE_DIMENSION = 32
EXPLICIT_STATE_DIMENSION = 5
SOURCE_COUNT = 5
TARGET_COUNT = 5
HISTORY_HOURS = 24
CONTROL_HOURS = 24
POST_ANALYSIS_FORECAST_HOURS = 23
ANALYSIS_SIGMA_POINT_COUNT = 65

UNSCENTED_ALPHA = 1.0
UNSCENTED_BETA = 2.0
UNSCENTED_KAPPA = 0.0
UNSCENTED_LAMBDA = 0.0
UNSCENTED_SCALING = 32.0

INITIAL_STATE_VARIANCE = 0.001
INITIAL_EFFECTIVE_PROCESS_VARIANCE = 0.001
FIXED_HIDDEN_PROCESS_VARIANCE = 0.001
INITIAL_OBSERVATION_VARIANCE = 0.01
MINIMUM_NOISE_STANDARD_DEVIATION = 1e-4

RELATIVE_SPECTRAL_FLOOR = 1e-12
MAXIMUM_INPUT_ASYMMETRY_RELATIVE = 1e-10
MINIMUM_INPUT_EIGENVALUE_RELATIVE = -1e-10
MAXIMUM_OUTPUT_ASYMMETRY_RELATIVE = 1e-12
MINIMUM_OUTPUT_FLOOR_FRACTION = 0.99
CROSS_COVARIANCE_RELATIVE_THRESHOLD = 1e-12


@dataclass(frozen=True)
class GaussianState:
    """A batch of 32-dimensional Gaussian state distributions."""

    mean: torch.Tensor
    covariance: torch.Tensor


def _validate_gaussian_state(state: GaussianState) -> int:
    if not isinstance(state, GaussianState):
        raise ValueError("state must be a GaussianState")
    if state.mean.ndim != 2 or state.mean.shape[1] != STATE_DIMENSION:
        raise ValueError("state mean must have shape [batch, 32]")
    batch_size = int(state.mean.shape[0])
    if state.mean.dtype != torch.float64:
        raise ValueError("state mean must use float64")
    if state.covariance.shape != (batch_size, STATE_DIMENSION, STATE_DIMENSION):
        raise ValueError("state covariance must have shape [batch, 32, 32]")
    if state.covariance.dtype != torch.float64:
        raise ValueError("state covariance must use float64")
    if state.mean.device != state.covariance.device:
        raise ValueError("state mean and covariance must share a device")
    if not bool(torch.isfinite(state.mean).all()):
        raise ValueError("state mean contains a nonfinite value")
    if not bool(torch.isfinite(state.covariance).all()):
        raise ValueError("state covariance contains a nonfinite value")
    return batch_size


def _raw_standard_deviation(initial_variance: float) -> float:
    if not math.isfinite(float(initial_variance)):
        raise ValueError("initial variance must be finite")
    shifted = math.sqrt(float(initial_variance)) - MINIMUM_NOISE_STANDARD_DEVIATION
    if shifted <= 0.0:
        raise ValueError("initial variance must exceed the variance floor")
    return math.log(math.expm1(shifted))


class EffectiveAnalysisNoise(nn.Module):
    """Five effective process variances and five observation variances."""

    def __init__(self) -> None:
        super().__init__()
        process_raw = _raw_standard_deviation(INITIAL_EFFECTIVE_PROCESS_VARIANCE)
        observation_raw = _raw_standard_deviation(INITIAL_OBSERVATION_VARIANCE)
        self.raw_process_standard_deviation = nn.Parameter(
            torch.full((EXPLICIT_STATE_DIMENSION,), process_raw, dtype=torch.float64)
        )
        self.raw_observation_standard_deviation = nn.Parameter(
            torch.full((SOURCE_COUNT,), observation_raw, dtype=torch.float64)
        )
        self.register_buffer(
            "fixed_hidden_process_variance",
            torch.full(
                (STATE_DIMENSION - EXPLICIT_STATE_DIMENSION,),
                FIXED_HIDDEN_PROCESS_VARIANCE,
                dtype=torch.float64,
            ),
        )

    @staticmethod
    def _positive_variance(raw: torch.Tensor) -> torch.Tensor:
        standard_deviation = MINIMUM_NOISE_STANDARD_DEVIATION + F.softplus(raw)
        return standard_deviation.square()

    def explicit_process_variance(self) -> torch.Tensor:
        """Return the five trainable effective process variances."""

        return self._positive_variance(self.raw_process_standard_deviation)

    def observation_variance(self) -> torch.Tensor:
        """Return the five trainable effective observation variances."""

        return self._positive_variance(self.raw_observation_standard_deviation)

    def process_variance(self) -> torch.Tensor:
        """Return all 32 diagonal entries, with 27 fixed hidden entries."""

        return torch.cat(
            (self.explicit_process_variance(), self.fixed_hidden_process_variance),
            dim=0,
        )

    def process_covariance(self) -> torch.Tensor:
        """Return the diagonal 32-dimensional process covariance."""

        return torch.diag(self.process_variance())


def stabilize_covariance(
    covariance: torch.Tensor,
) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    """Apply the single registered pre-process-noise spectral stabilization.

    The raw input asymmetry is measured before any modification.  The matrix is
    then symmetrized, decomposed with ``torch.linalg.eigh`` in float64, clipped
    at ``1e-12 * scale``, reconstructed, and symmetrized once more.  No jitter,
    singular-value decomposition, or Cholesky retry is used.
    """

    if not isinstance(covariance, torch.Tensor):
        raise ValueError("covariance must be a torch tensor")
    if covariance.ndim < 2 or covariance.shape[-2:] != (
        STATE_DIMENSION,
        STATE_DIMENSION,
    ):
        raise ValueError("covariance must end with shape [32, 32]")
    if covariance.dtype != torch.float64:
        raise ValueError("covariance must use float64")
    if not bool(torch.isfinite(covariance).all()):
        raise ValueError("covariance contains a nonfinite value")

    transpose = covariance.transpose(-1, -2)
    input_asymmetry = (covariance - transpose).abs().amax(dim=(-2, -1))
    symmetric = (covariance + transpose) * 0.5
    diagonal_scale = torch.diagonal(
        symmetric, dim1=-2, dim2=-1
    ).abs().amax(dim=-1)
    scale = torch.maximum(diagonal_scale, torch.ones_like(diagonal_scale))
    if bool(
        (input_asymmetry > MAXIMUM_INPUT_ASYMMETRY_RELATIVE * scale).any()
    ):
        raise ValueError("covariance input asymmetry exceeds the frozen limit")

    eigenvalues, eigenvectors = torch.linalg.eigh(symmetric)
    minimum_before_floor = eigenvalues[..., 0]
    if bool(
        (minimum_before_floor < MINIMUM_INPUT_EIGENVALUE_RELATIVE * scale).any()
    ):
        raise ValueError("covariance has a clearly negative eigenvalue")
    spectral_floor = RELATIVE_SPECTRAL_FLOOR * scale
    clipped_eigenvalues = torch.maximum(
        eigenvalues, spectral_floor.unsqueeze(-1)
    )
    reconstructed = (
        eigenvectors
        @ torch.diag_embed(clipped_eigenvalues)
        @ eigenvectors.transpose(-1, -2)
    )
    stabilized = (reconstructed + reconstructed.transpose(-1, -2)) * 0.5
    output_asymmetry = (
        stabilized - stabilized.transpose(-1, -2)
    ).abs().amax(dim=(-2, -1))
    if bool(
        (output_asymmetry > MAXIMUM_OUTPUT_ASYMMETRY_RELATIVE * scale).any()
    ):
        raise RuntimeError("stabilized covariance remains too asymmetric")
    minimum_after_floor = torch.linalg.eigvalsh(stabilized)[..., 0]
    if bool(
        (
            minimum_after_floor
            < MINIMUM_OUTPUT_FLOOR_FRACTION * spectral_floor
        ).any()
    ):
        raise RuntimeError("stabilized covariance misses the spectral floor")
    return stabilized, {
        "input_asymmetry": input_asymmetry,
        "scale": scale,
        "spectral_floor": spectral_floor,
        "minimum_eigenvalue_before_floor": minimum_before_floor,
        "minimum_eigenvalue_after_floor": minimum_after_floor,
        "output_asymmetry": output_asymmetry,
        "clipped": (eigenvalues < spectral_floor.unsqueeze(-1)).any(dim=-1),
    }


def check_positive_definite_covariance(
    covariance: torch.Tensor, *, name: str
) -> Dict[str, torch.Tensor]:
    """Check a covariance without modifying or spectrally projecting it."""

    if covariance.dtype != torch.float64 or covariance.shape[-2:] != (
        STATE_DIMENSION,
        STATE_DIMENSION,
    ):
        raise ValueError("%s must end in float64 [32, 32]" % name)
    if not bool(torch.isfinite(covariance).all()):
        raise ValueError("%s contains a nonfinite value" % name)
    transpose = covariance.transpose(-1, -2)
    asymmetry = (covariance - transpose).abs().amax(dim=(-2, -1))
    diagonal_scale = torch.diagonal(
        covariance, dim1=-2, dim2=-1
    ).abs().amax(dim=-1)
    scale = torch.maximum(diagonal_scale, torch.ones_like(diagonal_scale))
    if bool((asymmetry > MAXIMUM_OUTPUT_ASYMMETRY_RELATIVE * scale).any()):
        raise ValueError("%s is too asymmetric" % name)
    minimum_eigenvalue = torch.linalg.eigvalsh(covariance)[..., 0]
    if bool((minimum_eigenvalue <= 0.0).any()):
        raise ValueError("%s is not positive definite" % name)
    return {
        "asymmetry": asymmetry,
        "scale": scale,
        "minimum_eigenvalue": minimum_eigenvalue,
    }


class FixedUnscentedTransform(nn.Module):
    """The fixed 65-point transform used only for the analysis prediction."""

    def __init__(self) -> None:
        super().__init__()
        mean_weights = torch.full(
            (ANALYSIS_SIGMA_POINT_COUNT,),
            1.0 / 64.0,
            dtype=torch.float64,
        )
        covariance_weights = mean_weights.clone()
        mean_weights[0] = 0.0
        covariance_weights[0] = 2.0
        if abs(float(mean_weights.sum()) - 1.0) > 1e-15:
            raise RuntimeError("unscented mean weights do not sum to one")
        self.register_buffer("mean_weights", mean_weights)
        self.register_buffer("covariance_weights", covariance_weights)

    def sigma_points(self, state: GaussianState) -> torch.Tensor:
        """Return center, positive columns, and negative columns."""

        _validate_gaussian_state(state)
        factor, information = torch.linalg.cholesky_ex(
            UNSCENTED_SCALING * state.covariance,
            check_errors=False,
        )
        if bool((information != 0).any()):
            raise ValueError("analysis covariance Cholesky decomposition failed")
        columns = factor.transpose(-1, -2)
        center = state.mean.unsqueeze(1)
        points = torch.cat((center, center + columns, center - columns), dim=1)
        if points.shape[1] != ANALYSIS_SIGMA_POINT_COUNT:
            raise RuntimeError("analysis prediction must create exactly 65 points")
        return points

    def predict_once(
        self,
        state: GaussianState,
        control_at_analysis: torch.Tensor,
        transition,
        process_covariance: torch.Tensor,
    ) -> Tuple[GaussianState, torch.Tensor, Dict[str, torch.Tensor]]:
        """Run the sole unscented prediction and add Q after stabilization."""

        batch_size = _validate_gaussian_state(state)
        if control_at_analysis.shape != (batch_size, 2):
            raise ValueError("analysis control must have shape [batch, 2]")
        if control_at_analysis.dtype != torch.float32:
            raise ValueError("analysis control must use float32")
        if control_at_analysis.device != state.mean.device:
            raise ValueError("analysis control must share the state device")
        if not bool(torch.isfinite(control_at_analysis).all()):
            raise ValueError("analysis control contains a nonfinite value")
        if process_covariance.shape != (STATE_DIMENSION, STATE_DIMENSION):
            raise ValueError("process covariance must have shape [32, 32]")
        if process_covariance.dtype != torch.float64:
            raise ValueError("process covariance must use float64")
        if process_covariance.device != state.mean.device:
            raise ValueError("process covariance must share the state device")

        points = self.sigma_points(state)
        flat_points = points.reshape(-1, STATE_DIMENSION).to(torch.float32)
        repeated_control = (
            control_at_analysis[:, None, :]
            .expand(batch_size, ANALYSIS_SIGMA_POINT_COUNT, 2)
            .reshape(batch_size * ANALYSIS_SIGMA_POINT_COUNT, 2)
        )
        propagated = transition(flat_points, repeated_control)
        if not isinstance(propagated, torch.Tensor) or propagated.shape != (
            batch_size * ANALYSIS_SIGMA_POINT_COUNT,
            STATE_DIMENSION,
        ):
            raise ValueError("transition must return [batch*65, 32]")
        if propagated.dtype != torch.float32:
            raise ValueError("transition must retain float32 state")
        if not bool(torch.isfinite(propagated).all()):
            raise ValueError("transition returned a nonfinite value")
        propagated64 = propagated.reshape(
            batch_size, ANALYSIS_SIGMA_POINT_COUNT, STATE_DIMENSION
        ).to(torch.float64)
        mean_weights = self.mean_weights.to(propagated64.device)
        covariance_weights = self.covariance_weights.to(propagated64.device)
        predicted_mean = torch.einsum("s,bsi->bi", mean_weights, propagated64)
        deviations = propagated64 - predicted_mean[:, None, :]
        raw_covariance = torch.einsum(
            "s,bsi,bsj->bij", covariance_weights, deviations, deviations
        )
        stabilized_covariance, stabilization = stabilize_covariance(raw_covariance)
        prior_covariance = stabilized_covariance + process_covariance[None, :, :]
        post_q_health = check_positive_definite_covariance(
            prior_covariance, name="analysis prior covariance after Q"
        )
        diagnostics = dict(stabilization)
        diagnostics.update(
            {
                "post_q_asymmetry": post_q_health["asymmetry"],
                "post_q_minimum_eigenvalue": post_q_health["minimum_eigenvalue"],
            }
        )
        return (
            GaussianState(predicted_mean, prior_covariance),
            stabilized_covariance,
            diagnostics,
        )


def independent_scalar_updates(
    prior: GaussianState,
    observations: torch.Tensor,
    observation_variance: torch.Tensor,
) -> Dict[str, torch.Tensor | GaussianState]:
    """Run five independent fixed-selection scalar updates from one prior."""

    batch_size = _validate_gaussian_state(prior)
    if observations.shape != (batch_size, SOURCE_COUNT):
        raise ValueError("observations must have shape [batch, 5]")
    if observations.device != prior.mean.device or not observations.dtype.is_floating_point:
        raise ValueError("observations must be floating point on the state device")
    if not bool(torch.isfinite(observations).all()):
        raise ValueError("observations contain a nonfinite value")
    if observation_variance.shape != (SOURCE_COUNT,):
        raise ValueError("observation variance must have shape [5]")
    if observation_variance.dtype != torch.float64:
        raise ValueError("observation variance must use float64")
    if observation_variance.device != prior.mean.device:
        raise ValueError("observation variance must share the state device")

    identity = torch.eye(
        STATE_DIMENSION, dtype=torch.float64, device=prior.mean.device
    )
    posterior_means = []
    posterior_covariances = []
    innovations = []
    innovation_variances = []
    gains = []
    contractions = []
    posterior_minimum_eigenvalues = []
    for source_index in range(SOURCE_COUNT):
        cross_covariance = prior.covariance[:, :, source_index]
        innovation_variance = (
            prior.covariance[:, source_index, source_index]
            + observation_variance[source_index]
        )
        if not bool(torch.isfinite(innovation_variance).all()) or bool(
            (innovation_variance <= 0.0).any()
        ):
            raise ValueError("innovation variance must be finite and positive")
        gain = cross_covariance / innovation_variance[:, None]
        innovation = (
            observations[:, source_index].to(torch.float64)
            - prior.mean[:, source_index]
        )
        posterior_mean = prior.mean + gain * innovation[:, None]
        selector = torch.zeros(
            STATE_DIMENSION, dtype=torch.float64, device=prior.mean.device
        )
        selector[source_index] = 1.0
        joseph_factor = identity[None, :, :] - torch.einsum(
            "bi,j->bij", gain, selector
        )
        posterior_covariance = (
            joseph_factor
            @ prior.covariance
            @ joseph_factor.transpose(-1, -2)
            + torch.einsum("bi,bj->bij", gain, gain)
            * observation_variance[source_index]
        )
        health = check_positive_definite_covariance(
            posterior_covariance,
            name="analysis posterior covariance for source %d" % source_index,
        )
        contraction = gain[:, source_index]
        if not bool(torch.isfinite(contraction).all()) or bool(
            (contraction <= 0.0).any()
        ) or bool((contraction >= 1.0).any()):
            raise ValueError("observation contraction must be strictly in (0, 1)")
        posterior_means.append(posterior_mean)
        posterior_covariances.append(posterior_covariance)
        innovations.append(innovation)
        innovation_variances.append(innovation_variance)
        gains.append(gain)
        contractions.append(contraction)
        posterior_minimum_eigenvalues.append(health["minimum_eigenvalue"])

    posterior_state = GaussianState(
        mean=torch.stack(posterior_means, dim=1),
        covariance=torch.stack(posterior_covariances, dim=1),
    )
    return {
        "posterior_state": posterior_state,
        "innovation": torch.stack(innovations, dim=1),
        "innovation_variance": torch.stack(innovation_variances, dim=1),
        "kalman_gain": torch.stack(gains, dim=1),
        "observation_contraction": torch.stack(contractions, dim=1),
        "posterior_minimum_eigenvalue": torch.stack(
            posterior_minimum_eigenvalues, dim=1
        ),
    }


def cross_covariance_distinguishability(
    stabilized_covariance_before_q: torch.Tensor,
) -> torch.Tensor:
    """Return five booleans for the registered cross-covariance hard check."""

    if stabilized_covariance_before_q.ndim != 3 or stabilized_covariance_before_q.shape[
        1:
    ] != (STATE_DIMENSION, STATE_DIMENSION):
        raise ValueError("stabilized covariance must have shape [batch, 32, 32]")
    if stabilized_covariance_before_q.dtype != torch.float64:
        raise ValueError("stabilized covariance must use float64")
    diagonal = torch.diagonal(
        stabilized_covariance_before_q, dim1=-2, dim2=-1
    ).abs()
    scale = torch.maximum(
        diagonal.amax(dim=-1),
        torch.ones(
            stabilized_covariance_before_q.shape[0],
            dtype=torch.float64,
            device=stabilized_covariance_before_q.device,
        ),
    )
    passes = []
    for source_index in range(SOURCE_COUNT):
        mask = torch.ones(
            STATE_DIMENSION,
            dtype=torch.bool,
            device=stabilized_covariance_before_q.device,
        )
        mask[source_index] = False
        maximum_cross = stabilized_covariance_before_q[
            :, mask, source_index
        ].abs().amax(dim=1)
        passes.append(
            (maximum_cross > CROSS_COVARIANCE_RELATIVE_THRESHOLD * scale).any()
        )
    return torch.stack(passes)


def analytic_gain_jacobian_determinant(
    diagonal_covariance: torch.Tensor,
    cross_covariance: torch.Tensor,
    process_variance: torch.Tensor,
    observation_variance: torch.Tensor,
) -> torch.Tensor:
    """Return ``-cross / (diagonal + q + R)^3`` for audit tests."""

    denominator = diagonal_covariance + process_variance + observation_variance
    return -cross_covariance / denominator.pow(3)


class FiveSourceFiveTargetSingleAnalysisUKF(nn.Module):
    """Freeze one backbone and expose ten effective analysis parameters."""

    def __init__(self, backbone: nn.Module) -> None:
        super().__init__()
        self._validate_backbone(backbone)
        self.backbone = backbone
        self.backbone.requires_grad_(False)
        self.backbone.eval()
        self.analysis_noise = EffectiveAnalysisNoise()
        self.unscented_transform = FixedUnscentedTransform()
        self.register_buffer(
            "initial_covariance",
            torch.eye(STATE_DIMENSION, dtype=torch.float64)
            * INITIAL_STATE_VARIANCE,
        )
        trainable_count = sum(
            parameter.numel()
            for parameter in self.parameters()
            if parameter.requires_grad
        )
        if trainable_count != 10:
            raise RuntimeError("single-analysis model must expose exactly 10 scalars")

    @staticmethod
    def _validate_backbone(backbone: nn.Module) -> None:
        if not isinstance(backbone, nn.Module):
            raise ValueError("backbone must be a torch module")
        if getattr(backbone, "state_size", None) != STATE_DIMENSION:
            raise ValueError("backbone must expose state_size=32")
        for method_name in ("encode_history", "transition_step", "physical_forecast"):
            if not callable(getattr(backbone, method_name, None)):
                raise ValueError("backbone must expose %s" % method_name)

    def train(self, mode: bool = True):
        """Change analysis-parameter mode while the backbone remains frozen."""

        super().train(mode)
        self.backbone.eval()
        return self

    def _validate_inputs(
        self,
        history: torch.Tensor,
        future_control: torch.Tensor,
        analysis_observations: torch.Tensor,
    ) -> int:
        if history.ndim != 3 or history.shape[1:] != (HISTORY_HOURS, 6):
            raise ValueError("history must have shape [batch, 24, 6]")
        batch_size = int(history.shape[0])
        if future_control.shape != (batch_size, CONTROL_HOURS, 2):
            raise ValueError("future_control must have shape [batch, 24, 2]")
        if analysis_observations.shape != (batch_size, SOURCE_COUNT):
            raise ValueError("analysis_observations must have shape [batch, 5]")
        for name, value in (
            ("history", history),
            ("future_control", future_control),
            ("analysis_observations", analysis_observations),
        ):
            if value.dtype != torch.float32:
                raise ValueError("%s must use float32" % name)
            if value.device != history.device:
                raise ValueError("all model inputs must share one device")
            if not bool(torch.isfinite(value).all()):
                raise ValueError("%s contains a nonfinite value" % name)
        return batch_size

    def _encode_once(self, history: torch.Tensor) -> GaussianState:
        encoded = self.backbone.encode_history(history)
        if encoded.shape != (history.shape[0], STATE_DIMENSION):
            raise ValueError("encoded state must have shape [batch, 32]")
        if encoded.dtype != torch.float32 or not bool(torch.isfinite(encoded).all()):
            raise ValueError("encoded state must be finite float32")
        covariance = self.initial_covariance.to(history.device)[None, :, :].expand(
            history.shape[0], -1, -1
        )
        return GaussianState(encoded.to(torch.float64), covariance)

    def _direct_future_forecasts(
        self,
        prior_mean: torch.Tensor,
        posterior_mean: torch.Tensor,
        future_control: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, Tuple[int, ...], int]:
        batch_size = int(prior_mean.shape[0])
        branch_state = torch.cat((prior_mean[:, None, :], posterior_mean), dim=1)
        state = branch_state.to(torch.float32)
        forecasts = []
        control_indices = []
        branch_control_equality_checks = 0
        for control_index in range(1, CONTROL_HOURS):
            shared_control = future_control[:, control_index, :]
            repeated_control = shared_control[:, None, :].expand(
                batch_size, 1 + SOURCE_COUNT, 2
            )
            for branch_index in range(1, 1 + SOURCE_COUNT):
                if not torch.equal(
                    repeated_control[:, 0, :],
                    repeated_control[:, branch_index, :],
                ):
                    raise RuntimeError(
                        "open-loop and updated branches must receive equal controls"
                    )
                branch_control_equality_checks += 1
            flat_state = state.reshape(
                batch_size * (1 + SOURCE_COUNT), STATE_DIMENSION
            )
            flat_control = repeated_control.reshape(
                batch_size * (1 + SOURCE_COUNT), 2
            )
            next_state = self.backbone.transition_step(flat_state, flat_control)
            if next_state.shape != flat_state.shape or next_state.dtype != torch.float32:
                raise ValueError("transition must return float32 [batch*6, 32]")
            if not bool(torch.isfinite(next_state).all()):
                raise ValueError("future transition returned a nonfinite value")
            physical = self.backbone.physical_forecast(next_state)
            if physical.shape != (flat_state.shape[0], TARGET_COUNT):
                raise ValueError("physical forecast must have shape [batch*6, 5]")
            if not torch.equal(physical, next_state[:, :TARGET_COUNT]):
                raise ValueError("physical forecast must be exactly the first five states")
            state = next_state.reshape(
                batch_size, 1 + SOURCE_COUNT, STATE_DIMENSION
            )
            forecasts.append(
                physical.reshape(batch_size, 1 + SOURCE_COUNT, TARGET_COUNT)
            )
            control_indices.append(control_index)
        stacked = torch.stack(forecasts, dim=2)
        if stacked.shape != (
            batch_size,
            1 + SOURCE_COUNT,
            POST_ANALYSIS_FORECAST_HOURS,
            TARGET_COUNT,
        ):
            raise RuntimeError("future forecast branch shape is invalid")
        return (
            stacked[:, 0],
            stacked[:, 1:],
            tuple(control_indices),
            branch_control_equality_checks,
        )

    def forward(
        self,
        history: torch.Tensor,
        future_control: torch.Tensor,
        analysis_observations: torch.Tensor,
    ) -> Mapping[str, object]:
        """Return one common open loop and five independent update forecasts."""

        batch_size = self._validate_inputs(
            history, future_control, analysis_observations
        )
        future_control_used = future_control.detach().clone()
        encoded_state = self._encode_once(history)
        process_covariance = self.analysis_noise.process_covariance().to(history.device)
        prior, covariance_before_q, prediction_diagnostics = (
            self.unscented_transform.predict_once(
                encoded_state,
                future_control[:, 0, :],
                self.backbone.transition_step,
                process_covariance,
            )
        )
        updates = independent_scalar_updates(
            prior,
            analysis_observations,
            self.analysis_noise.observation_variance().to(history.device),
        )
        posterior = updates["posterior_state"]
        if not isinstance(posterior, GaussianState):
            raise RuntimeError("posterior state is invalid")
        (
            open_forecast,
            updated_forecast,
            control_indices,
            branch_control_equality_checks,
        ) = (
            self._direct_future_forecasts(
                prior.mean, posterior.mean, future_control
            )
        )
        if open_forecast.shape != (
            batch_size,
            POST_ANALYSIS_FORECAST_HOURS,
            TARGET_COUNT,
        ):
            raise RuntimeError("open-loop forecast shape is invalid")
        if updated_forecast.shape != (
            batch_size,
            SOURCE_COUNT,
            POST_ANALYSIS_FORECAST_HOURS,
            TARGET_COUNT,
        ):
            raise RuntimeError("updated forecast shape is invalid")
        if not torch.equal(future_control, future_control_used):
            raise RuntimeError("model execution must not mutate future_control")

        result: Dict[str, object] = {
            "analysis_prior_mean": prior.mean,
            "analysis_prior_covariance": prior.covariance,
            "analysis_unscented_covariance_before_process_noise": covariance_before_q,
            "analysis_posterior_mean": posterior.mean,
            "analysis_posterior_covariance": posterior.covariance,
            "analysis_innovation": updates["innovation"],
            "analysis_innovation_variance": updates["innovation_variance"],
            "analysis_kalman_gain": updates["kalman_gain"],
            "analysis_observation_contraction": updates["observation_contraction"],
            "analysis_posterior_minimum_eigenvalue": updates[
                "posterior_minimum_eigenvalue"
            ],
            "open_loop_forecast": open_forecast,
            "updated_forecast": updated_forecast,
            "future_control_used": future_control_used,
            "effective_process_variance": self.analysis_noise.process_variance(),
            "effective_observation_variance": (
                self.analysis_noise.observation_variance()
            ),
            "encode_history_call_count": 1,
            "analysis_unscented_prediction_call_count": 1,
            "post_analysis_unscented_prediction_call_count": 0,
            "post_analysis_covariance_propagation_call_count": 0,
            "analysis_control_index": 0,
            "future_process_control_indices": control_indices,
            "branch_control_bitwise_equality_check_count": (
                branch_control_equality_checks
            ),
            "prediction_covariance_diagnostics": prediction_diagnostics,
        }
        for key, value in result.items():
            if "future_covariance" in key:
                raise RuntimeError("future covariance outputs are forbidden")
            if isinstance(value, torch.Tensor) and not bool(torch.isfinite(value).all()):
                raise ValueError("output %s contains a nonfinite value" % key)
        return result


__all__ = [
    "ANALYSIS_SIGMA_POINT_COUNT",
    "EffectiveAnalysisNoise",
    "FiveSourceFiveTargetSingleAnalysisUKF",
    "FixedUnscentedTransform",
    "GaussianState",
    "POST_ANALYSIS_FORECAST_HOURS",
    "STATE_DIMENSION",
    "analytic_gain_jacobian_determinant",
    "check_positive_definite_covariance",
    "cross_covariance_distinguishability",
    "independent_scalar_updates",
    "stabilize_covariance",
]
