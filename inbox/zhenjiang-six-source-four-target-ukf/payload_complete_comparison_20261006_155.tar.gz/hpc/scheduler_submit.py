"""Submit five recovery jobs once, with the school's required short queue flag."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT=Path(__file__).resolve().parents[1]
WRAPPER='/usr/local/globle/softs/slurm/19.05.4.1/bin/xbatch'
OLD_JOBS={'236695','236696','236697','236698'}

def main():
    manifest=json.loads((ROOT/'release_manifest.json').read_text())
    for name in ('hpc/prepare_data.sbatch','hpc/train_case.sbatch'):
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=manifest['files'][name]['sha256']:
            raise ValueError('released scheduler template changed')
    queue=subprocess.run(['squeue','-u','sunyiq','-h','-o','%i|%j|%T|%R'],capture_output=True,text=True,check=True)
    old=[]
    for line in queue.stdout.splitlines():
        fields=line.split('|')
        if fields[0] in OLD_JOBS:
            if fields[2]!='PENDING' or 'DependencyNeverSatisfied' not in fields[3]:
                raise ValueError('old job state changed; inspect before cancellation')
            old.append(fields[0])
        elif 'zj_' in fields[1] and '261006_r2' in fields[1]:
            raise ValueError('recovery job already exists')
    jobs={}
    def submit(key,content):
        path=ROOT/'hpc'/('recovery_'+key+'.slurm')
        with path.open('x') as f: f.write(content)
        record=ROOT/'records'/('scheduler_'+key+'_attempt.json')
        with record.open('x') as f:
            json.dump({'status':'reserved','script':str(path),'script_sha256':hashlib.sha256(path.read_bytes()).hexdigest()},f)
        result=subprocess.run([WRAPPER,str(path)],capture_output=True,text=True,timeout=60)
        with (ROOT/'records'/('scheduler_'+key+'_response.json')).open('x') as f:
            json.dump({'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr},f,indent=2)
        matched=re.fullmatch(r'Submitted batch job ([0-9]+)\s*',result.stdout)
        if result.returncode or not matched:
            print('UNCONFIRMED',key,result.returncode,result.stdout,result.stderr,flush=True)
            raise RuntimeError('preserve uncertain attempt; no automatic resubmission')
        job=matched.group(1); jobs[key]=job
        temp=ROOT/'records/scheduler_jobs.json.tmp'; temp.write_text(json.dumps(jobs,indent=2)+'\n')
        temp.replace(ROOT/'records/scheduler_jobs.json')
        print(json.dumps({'status':'submitted','key':key,'job_id':job}),flush=True)
        return job
    preparation=submit('preparation',(ROOT/'hpc/prepare_data.sbatch').read_text())
    base=(ROOT/'hpc/train_case.sbatch').read_text()
    for case in ('legacy_lstm__small','explicit_gru__small','legacy_lstm__historical_capacity','explicit_gru__historical_capacity'):
        body=base.replace('#SBATCH --job-name=zj_train_261006_r2',
            '#SBATCH --job-name=zj_'+case+'_261006_r2\n#SBATCH --dependency=afterok:'+preparation)
        body=body.replace('case_name="$1"','case_name="'+case+'"')
        submit(case,body)
    if old:
        result=subprocess.run(['scancel',*old],capture_output=True,text=True)
        with (ROOT/'records/old_unstarted_jobs_cancelled.json').open('x') as f:
            json.dump({'jobs':old,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,
                       'failed_preparation_236694_and_all_outputs_preserved':True},f,indent=2)
        if result.returncode: raise RuntimeError('could not cancel old dependency-blocked jobs')
    result=subprocess.run(['squeue','-h','-j',','.join(jobs.values()),'-o','%i|%j|%T|%R'],capture_output=True,text=True)
    print(result.stdout)

if __name__=='__main__': main()
