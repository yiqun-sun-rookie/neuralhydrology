"""HPC-only GPU admission and isolated epoch47/2021 validation.

Packaged unchanged as hpc/gpu_workflow.py in the CPU-admitted factor candidate.
Modes: submit, bootstrap, replay, probe. No formal checkpoints are written.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import traceback

ROOT = Path(__file__).resolve().parents[1]
SLURM = '/usr/local/globle/softs/slurm/19.05.4.1/bin/'


def read(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()


def save(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def query(arguments):
    result = subprocess.run(arguments, capture_output=True, text=True, timeout=40)
    value = dict(command=arguments, returncode=result.returncode,
                 stdout=result.stdout, stderr=result.stderr)
    assert result.returncode == 0, value
    return value


def spec_and_pins():
    spec = read(ROOT / 'gpu_spec.json')
    assert spec['root'] == str(ROOT)
    assert sha(ROOT / 'human_authority.json') == spec['authority_sha256']
    authority = read(ROOT / 'human_authority.json')
    assert authority['human_answer_verbatim'] == '允许平方根表示修复，其余规则不变（推荐）'
    assert authority['approved_exception'] == 'square-root/factor covariance representation and necessary differentiable update/propagation implementation only'
    assert sha(ROOT / 'records/stored_operand_cpu_admission.json') == spec['cpu_result_sha256']
    cpu = read(ROOT / 'records/stored_operand_cpu_admission.json')
    assert cpu['status'] == 'sqrt_stored_operands_cpu_admission_passed'
    assert cpu['candidate_sha256'] == spec['candidate_sha256']
    for name, value in spec['candidate_files'].items():
        assert sha(ROOT / name) == value, name
    source = Path(spec['source_root'])
    for name, value in spec['source_code_files'].items():
        assert sha(source / name) == value, name
    for files in spec['all_member_source_files'].values():
        for value in files.values():
            path = Path(value['path'])
            assert path.is_file() and path.stat().st_size == value['bytes']
            assert sha(path) == value['sha256'], str(path)
    manifest = read(ROOT / 'gpu_package_manifest.json')
    for name, value in manifest['files'].items():
        assert sha(ROOT / name) == value['sha256']
        assert (ROOT / name).stat().st_size == value['bytes']
    return spec


def submit():
    spec = spec_and_pins()
    assert not (ROOT / 'records/gpu_submission_attempt.json').exists()
    assert not (ROOT / 'evidence_gpu').exists()
    source = Path(spec['source_root'])
    jobs = read(source / 'records/scheduler_jobs.json')
    assert str(jobs[spec['case']]) == spec['source_job']
    queue = query([SLURM + 'squeue', '-h', '-u', 'sunyiq', '-o', '%i|%j|%T|%Z'])
    rows = [line.split('|') for line in queue['stdout'].splitlines() if line.strip()]
    assert all(len(row) == 4 for row in rows)
    forbidden = ('zj_gru_cov_diag_', 'zj_gru_val_', 'zj_gru_covariance_',
                 'zj_gru_comp_', 'zj_gru_fail006_', 'zj_gru_gradient_recovery',
                 'zj_sqrt_')
    assert not any(row[0] == spec['source_job'] or row[1].startswith(forbidden)
                   or row[3] in (str(ROOT), str(source)) for row in rows), queue
    accounting = query([SLURM + 'sacct', '-n', '-X', '-j', spec['source_job'],
                        '--format=JobID,State,ExitCode,Start,End,NodeList', '-P'])
    entries = [line.strip().split('|') for line in accounting['stdout'].splitlines() if line.strip()]
    assert len(entries) == 1 and entries[0][:5] == [
        spec['source_job'], 'FAILED', '1:0', '2026-10-16T15:56:08', '2026-10-16T17:30:44']
    script = ROOT / 'hpc/sqrt_gpu_admission.slurm'
    body = script.read_text().splitlines()
    for line in ('#SBATCH -p hgpu2p,hgpu4', '#SBATCH --gres=gpu:1',
                 '#SBATCH --cpus-per-task=4', '#SBATCH --exclude=ngu002,ngu009,ngu011,ngu103',
                 '#SBATCH --time=00:30:00', '#SBATCH --time-min=00:15:00'):
        assert line in body
    assert body.index('conda activate nh_final') < body.index('set -u')
    attempt = dict(status='reserved_no_retry', at=now(), root=str(ROOT),
                   script_sha256=sha(script), spec_sha256=sha(ROOT / 'gpu_spec.json'),
                   manifest_sha256=sha(ROOT / 'gpu_package_manifest.json'),
                   queue=queue, source_accounting=accounting, formal_epochs_added=0)
    save(ROOT / 'records/gpu_submission_attempt.json', attempt)
    try:
        result = subprocess.run([SLURM + 'xbatch', str(script)], cwd=ROOT,
                                capture_output=True, text=True, timeout=60)
    except Exception as error:
        save(ROOT / 'records/gpu_submission_response.json',
             dict(status='uncertain_readonly_reconciliation_required', error=str(error), at=now()))
        raise
    save(ROOT / 'records/gpu_submission_response.json',
         dict(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr, at=now()))
    match = re.fullmatch(r'Submitted batch job ([0-9]+)\s*', result.stdout)
    assert result.returncode == 0 and match, 'unknown submission; never retry'
    job = match.group(1)
    save(ROOT / 'records/scheduler_jobs.json', {'sqrt_gpu_admission': job})
    print(json.dumps(dict(status='sqrt_gpu_admission_submitted', root=str(ROOT), job_id=job,
                          spec_sha256=attempt['spec_sha256'],
                          manifest_sha256=attempt['manifest_sha256'],
                          formal_epochs_added=0, at=now())), flush=True)


def bootstrap():
    spec = spec_and_pins()
    import torch
    props = torch.cuda.get_device_properties(0)
    profile = dict(job_id=os.environ['SLURM_JOB_ID'], node=os.environ.get('SLURMD_NODENAME'),
                   actual_device_identity=dict(device='cuda:0', name=props.name,
                                               total_memory_bytes=props.total_memory),
                   capability=[props.major, props.minor], measured_at=now())
    save(ROOT / 'records/gpu_hardware.json', profile)
    print(json.dumps(profile), flush=True)
    assert profile['capability'] == [8, 6]
    assert ((props.name == 'NVIDIA GeForce RTX 3090' and props.total_memory == 25296044032)
            or (props.name == 'NVIDIA A40' and props.total_memory >= 25296044032))
    assert (props.name == 'NVIDIA A40' and os.environ['SLURM_JOB_PARTITION'] == 'hgpu4'
            or props.name == 'NVIDIA GeForce RTX 3090' and os.environ['SLURM_JOB_PARTITION'] == 'hgpu2p')
    env = dict(os.environ, ZHENJIANG_TEST_DEVICE='cuda',
               ZHENJIANG_ACCEPTANCE_RECEIPT=str(ROOT / 'records/gpu_original39.json'),
               ZHENJIANG_A40_HARDWARE_PROFILE=str(ROOT / 'records/gpu_hardware.json'))
    env['PYTHONPATH'] = spec['pytest_runtime'] + os.pathsep + str(ROOT)
    command = [sys.executable, '-B', '-m', 'pytest',
               *[str(ROOT / 'acceptance' / name) for name in (
                   'test_gradient_recovery.py', 'test_training.py',
                   'test_numerical_recovery.py', 'test_joseph_recovery.py')],
               '-q', '-p', 'no:cacheprovider', '--basetemp', str(ROOT / 'records/gpu_test_temp')]
    process = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True, timeout=650)
    save(ROOT / 'records/gpu_original39_output.json',
         dict(command=command, returncode=process.returncode, stdout=process.stdout, stderr=process.stderr))
    assert process.returncode == 0, process.stdout + process.stderr
    acceptance = read(ROOT / 'records/gpu_original39.json')
    assert acceptance['exit_status'] == 0 and acceptance['tests_collected'] == 39
    assert acceptance['formal_training_steps'] == acceptance['real_data_optimizer_steps'] == acceptance['raw_evaluation_year_reads'] == 0
    sys.path.insert(0, str(ROOT))
    from src import differentiable_filter as dense, square_root_filter as factor
    from src.scheduler import code_identity
    from src.training import deterministic_runtime
    deterministic_runtime()
    torch.set_num_threads(4)
    assert code_identity() == spec['candidate_code_hash']
    operand = Path(spec['stored_root']) / 'evidence/covariance_failure_operands.pt'
    assert sha(operand) == spec['stored_operands_sha256']
    raw = torch.load(operand, map_location='cpu', weights_only=True)
    frames = {frame['function']: frame for frame in raw['original_failure_traceback_frames']}
    index = frames['repair_rejected_members']['scalars']['i']
    values = frames['linear_update']['tensors']
    prior, complement, gain, r = [values[k][index:index + 1].to('cuda:0')
                                 for k in ('covariance', 'complement', 'gain', 'r_diagonal')]
    ledger = dense.StabilityLedger()
    lower = dense.stable_cholesky(prior, ledger)
    columns = torch.cat((complement @ lower, gain * r.sqrt()[:, None, :]), -1).detach().requires_grad_()
    result = factor.factor_columns(columns, ledger)
    direct = factor.joseph_factor(lower, complement, gain, r)
    assert torch.equal(result.detach(), direct)
    n = prior.shape[-1]
    w = torch.diag(torch.arange(1, n + 1, device='cuda:0', dtype=torch.float64) / n)[None]
    gradient, = torch.autograd.grad((w * (result @ result.transpose(-1, -2))).sum(), columns)
    expected = 2 * w @ columns.detach()
    error = float((gradient - expected).abs().max() / expected.abs().max())
    assert bool(torch.isfinite(gradient).all()) and error < 1e-7, error
    points, wm, wc = factor.points_from_factor(torch.zeros_like(prior[:, 0]), direct)
    assert points.shape == (1, 257, 128) and torch.isfinite(points).all()
    assert list(dense.JITTERS) == spec['original_jitters']
    from src.models import make_parts
    from src.contracts import Whitening
    parts = make_parts('explicit_gru', 'historical_capacity', 101)
    from src.execution import move_parts
    noise = dense.make_noise(128)
    whitening = Whitening(torch.zeros(128, dtype=torch.float64), torch.ones(128, dtype=torch.float64))
    whitening = move_parts(parts, noise, whitening, 'cuda:0')
    mean, predicted = factor.predict_factor(parts, torch.zeros(1, 128, device='cuda:0', dtype=torch.float64),
                                            torch.eye(128, device='cuda:0', dtype=torch.float64)[None],
                                            torch.zeros(1, 3, device='cuda:0'), whitening, noise)
    assert torch.isfinite(mean).all() and torch.isfinite(predicted).all()
    assert (predicted.diagonal(dim1=-2, dim2=-1) > 0).all()
    spec_and_pins()
    value = dict(status='sqrt_gpu_original39_and_new_production_passed', at=now(),
                 job_id=os.environ['SLURM_JOB_ID'], root=str(ROOT), hardware=profile,
                 original_tests=39, original_acceptance_sha256=sha(ROOT / 'records/gpu_original39.json'),
                 candidate_code_hash=code_identity(), candidate_sha256=sha(ROOT / 'src/square_root_filter.py'),
                 stored_operand_gradient_relative_error=error, direct_factor_sigma_points=True,
                 new_prediction_factor_path=True, original_jitters=list(dense.JITTERS),
                 ledger_attempts=[x.tolist() for x in ledger.current_jitter],
                 real_data_optimizer_steps=0, formal_epochs_added=0, evaluation_values_read=False)
    save(ROOT / 'records/gpu_bootstrap.json', value)
    print(json.dumps(value), flush=True)


def replay():
    spec = spec_and_pins()
    import copy
    import torch
    from types import SimpleNamespace
    sys.path.insert(0, str(ROOT / 'hpc'))
    import authenticated_source_helpers as helper
    api = helper.import_source(ROOT, spec['candidate_code_hash'])
    api.training.deterministic_runtime()
    torch.set_num_threads(4)
    evidence = ROOT / 'evidence_gpu'
    evidence.mkdir(exist_ok=False)
    log = helper.EventLog(evidence)
    session, start, batch, context = None, None, None, {}
    result = dict(status='sqrt_gpu_replay_started', root=str(ROOT), at=now(),
                  job_id=os.environ['SLURM_JOB_ID'], candidate_code_hash=spec['candidate_code_hash'],
                  source_checkpoint_sha256=spec['source_checkpoint_sha256'],
                  source_complete_epochs=46, source_optimizer_steps=7060,
                  historical_rng_equality_established=False, formal_epochs_added=0,
                  formal_recovery_confirmed=False, evaluation_values_read=False,
                  successful_in_memory_batches=0, original_2021_validation_completed=False)
    code = 1
    try:
        bootstrap_record = read(ROOT / 'records/gpu_bootstrap.json')
        assert bootstrap_record['status'] == 'sqrt_gpu_original39_and_new_production_passed'
        assert bootstrap_record['candidate_code_hash'] == spec['candidate_code_hash']
        args = SimpleNamespace(expected_config_sha256=spec['source_config_sha256'],
                               expected_code_sha256=spec['source_code_hash'],
                               expected_checkpoint_sha256=spec['source_checkpoint_sha256'])
        source = Path(spec['source_root'])
        run, config, protocol, manifest, seals, pinned = helper.validate_metadata(source, spec['run_id'], args, api)
        checkpoint = source / 'runs' / spec['run_id'] / 'continuation.pt'
        state = torch.load(checkpoint, map_location='cpu', weights_only=True)
        helper.validate_checkpoint(state, spec['source_config_sha256'],
                                   read(source / 'runs' / spec['run_id'] / 'metrics.json'), 46)
        assert sum(len(x) for x in state['train_metrics']) == 7060
        train = api.runtime.load_stage(manifest, 'tuning_train')
        stats = api.runtime.fit_stage_stats(train, manifest)
        assert api.scheduler.digest_json(api.runtime.stats_record(stats)) == config['effective_config']['normalization_hash']
        windows, times = api.runtime.prepare_windows(train, stats)
        for epoch in range(1, 47):
            ids, digest = api.training.epoch_indices(times, run['seed'], epoch)
            assert digest == state['shuffle_hashes'][epoch - 1]
            assert len(state['train_metrics'][epoch - 1]) == (len(ids) + 15) // 16
        runtime_config = copy.deepcopy(config)
        effective = runtime_config['effective_config']
        effective['device_identity'] = bootstrap_record['hardware']['actual_device_identity']
        effective['code_hash'] = spec['candidate_code_hash']
        assert {key for key in effective if effective[key] != config['effective_config'][key]} <= {'device_identity', 'code_hash'}
        save(evidence / 'runtime_binding.json', dict(source_config_sha256=spec['source_config_sha256'],
             authorized_representation_code_hash=spec['candidate_code_hash'], runtime_config=runtime_config,
             diagnostic_only=True, historical_rng_equality_established=False))
        session = api.runtime.build_session(run, runtime_config, protocol, stats, evidence / 'scratch', seals)
        api.training.restore_parts(session.parts, state['current'], session.noise)
        session.optimizer.load_state_dict(state['optimizer'])
        helper.validate_adam(session, api, 7060)
        assert session.micro_batch == 2
        initial_parameters = api.training.snapshot_parts(session.parts, session.noise)
        ids, digest = api.training.epoch_indices(times, run['seed'], 47)
        assert (len(ids) + 15) // 16 == 154
        save(evidence / 'replay_identity.json', dict(epoch=47, ordered_window_indices=ids.tolist(),
             shuffle_sha256=digest, source_checkpoint_sha256=sha(checkpoint), effective_batch=16, microbatch=2))
        metrics = []
        for offset in range(0, len(ids), 16):
            indices = ids[offset:offset + 16]
            context = dict(phase='tuning_train', epoch=47, effective_batch_index=offset // 16 + 1,
                           window_indices=indices.tolist())
            batch = api.execution.move_batch(api.contracts.combine_batches([windows[int(i)] for i in indices]), session.device)
            start = helper.capture_start(session, api)
            log.emit(dict(context, status='effective_batch_started'))
            metric = api.training.train_effective_batch(session.parts, session.noise, session.whitening,
                         session.method, batch, session.stats, session.optimizer, session.micro_batch)
            metrics.append(metric)
            result['successful_in_memory_batches'] += 1
            log.emit(dict(context, status='effective_batch_completed_in_memory', metric=metric))
        helper.validate_adam(session, api, 7214)
        result['final_in_memory_optimizer_steps'] = [7214]
        from src.differentiable_filter import StabilityLedger
        all_jitters = [j for epoch_rows in state['train_metrics'] + [metrics]
                       for metric in epoch_rows for j in metric['stability']['step_jitters']]
        result['combined_training_stability'] = StabilityLedger(all_jitters).report()
        select = api.runtime.load_stage(manifest, 'tuning_select')
        assert set((select['times'].astype('datetime64[Y]').astype(int) + 1970).tolist()) == {2021}
        validation_windows, _ = api.runtime.prepare_windows(select, stats)
        assert len(validation_windows) == 7804
        batches = api.runtime.batches(validation_windows)
        assert len(batches) == 488
        # Wrap observation only; original validation_mae and its ledger/denominator remain intact.
        original_prediction = api.training.branch_prediction
        count = 0
        start = helper.capture_start(session, api)
        def observed(*arguments, **keywords):
            nonlocal count, start, batch, context
            batch = arguments[4]
            context = dict(phase='tuning_select', year=2021, validation_batch_index=count + 1)
            output = original_prediction(*arguments, **keywords)
            count += 1
            if count % 32 == 0 or count == 488:
                log.emit(dict(context, status='original_2021_validation_batch_completed'))
            return output
        api.training.branch_prediction = observed
        try:
            value = api.training.validation_mae(session.parts, session.noise, session.whitening,
                                               session.method, batches, stats)
        finally:
            api.training.branch_prediction = original_prediction
        assert count == 488
        helper.validate_adam(session, api, 7214)
        current = api.training.snapshot_parts(session.parts, session.noise)
        result.update(status='sqrt_gpu_epoch47_and_original2021_passed',
                      original_2021_validation_completed=True, validation_batches=count,
                      validation_windows=7804, validation_mae_cm=value,
                      parameters_changed=any(not torch.equal(value, current[key][name])
                          for key, row in initial_parameters.items() for name, value in row.items()),
                      optimizer_steps_advanced=154, source_bytes_unchanged=True,
                      actual_gpu_bootstrap_sha256=sha(ROOT / 'records/gpu_bootstrap.json'))
        assert result['parameters_changed']
        code = 0
    except Exception as error:
        result.update(status='sqrt_gpu_first_failure_preserved', error_type=type(error).__name__,
                      reason=str(error), traceback=traceback.format_exc(), failure_context=context)
        if session is not None and start is not None:
            # These diagnostic artifacts are never eligible for formal migration.
            artifact = evidence / 'first_failure_model_adam_rng_batch.pt'
            tensors = []
            tb = error.__traceback__
            while tb is not None:
                frame = tb.tb_frame
                tensors.append(dict(function=frame.f_code.co_name, line=tb.tb_lineno,
                    tensors={key: helper.cpu_tree(value) for key, value in frame.f_locals.items()
                             if isinstance(value, torch.Tensor)}))
                tb = tb.tb_next
            torch.save(dict(batch_start=start,
                            batch={key: helper.cpu_tree(value) for key, value in vars(batch).items()}
                            if batch is not None else None, context=context, frames=tensors,
                            current=api.training.snapshot_parts(session.parts, session.noise),
                            optimizer=helper.cpu_tree(session.optimizer.state_dict())), artifact)
            result['failure_artifact'] = dict(path=str(artifact), bytes=artifact.stat().st_size, sha256=sha(artifact))
    finally:
        try:
            spec_and_pins()
            result['source_bytes_unchanged'] = True
        except Exception as error:
            result['source_bytes_unchanged'] = False
            result['source_identity_error'] = str(error)
            code = 1
        result.update(exit_code=code, finished_at=now())
        save(evidence / 'result.json', result)
        log.emit(dict(status='sqrt_gpu_isolated_workflow_finished', result_status=result['status'],
                      exit_code=code, formal_epochs_added=0))
        log.close()
    raise SystemExit(code)


def probe():
    jobs = read(ROOT / 'records/scheduler_jobs.json')
    job = jobs['sqrt_gpu_admission']
    value = dict(status='sqrt_gpu_workflow_status', root=str(ROOT), job_id=job, checked_at=now(),
                 scheduler_jobs=jobs, formal_epochs_added=0, documents={})
    value['queue'] = query([SLURM + 'squeue', '-h', '-j', job, '-o', '%i|%T|%N|%Z|%S|%e|%l|%r'])
    value['accounting'] = query([SLURM + 'sacct', '-n', '-X', '-j', job,
        '--format=JobID,State,ExitCode,Start,End,NodeList', '-P'])
    for name in ('records/gpu_hardware.json', 'records/gpu_original39.json', 'records/gpu_original39_output.json',
                 'records/gpu_bootstrap.json', 'evidence_gpu/result.json'):
        path = ROOT / name
        if path.is_file():
            value['documents'][name] = dict(bytes=path.stat().st_size, sha256=sha(path), value=read(path))
    value['logs'] = {}
    for path in (ROOT / 'logs').glob('*_' + job + '.out'):
        with path.open('rb') as stream:
            stream.seek(max(0, path.stat().st_size - 12000))
            tail = stream.read().decode(errors='replace')
        value['logs'][path.name] = dict(bytes=path.stat().st_size, tail=tail)
    print(json.dumps(value, sort_keys=True), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['submit', 'bootstrap', 'replay', 'probe'])
    globals()[parser.parse_args().mode]()
