"""Import a complete external final-foundation group before HPC reaches it.

On HPC: python -B import_cloud_group.py --bundle-root /absolute/verified/bundle
Preserves actual RTX4090 provenance; never overwrites an existing training run.
"""
import argparse
import copy
from dataclasses import asdict
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path('/data1/home/sunyiq/zhenjiang_complete_comparison_fixed200_20261019_003/base')
CASE = 'legacy_lstm__historical_capacity'
GROUP = CASE + '__final_foundation_group'


def read(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bundle-root', type=Path, required=True)
    bundle = p.parse_args().bundle_root.resolve(strict=True)
    sys.path.insert(0, str(ROOT))
    from src.scheduler import code_identity, digest_json, seal_group, load_tuning_foundation_source
    record = ROOT / 'records' / CASE
    receipt_path = record / 'autodl_final_foundation_import_20261024.json'
    if receipt_path.exists():
        print(json.dumps(read(receipt_path)))
        return
    assert read(record / 'progress.json')['group'] == CASE + '__tune_branch_group'
    assert not (record / 'final_foundation_group_outcome.json').exists()
    reservation = read(record / 'autodl_final_foundation_reservation_20261024.json')
    assert reservation['case'] == CASE and reservation['seeds'] == [17, 29, 43, 61, 89]
    assert read(bundle / 'EXIT.json')['exit_code'] == 0
    execution = read(bundle / 'EXECUTION.json')
    auth = read(ROOT / 'records/authorization.json')
    assert execution['source_code_hash'] == code_identity(ROOT) == auth['code_hash']
    assert execution['source_protocol_sha256'] == sha(ROOT / 'configs/protocol-v3.json') == auth['protocol_sha256']
    assert execution['case'] == CASE and execution['epochs_total'] == 200
    assert execution['execution_device']['name'] == 'NVIDIA GeForce RTX 4090'
    assert not execution['source400_rerun'] and not execution['years_2023_2024_read']
    registry = read(ROOT / 'configs/registry-v3.json')
    expected = {r['exp_id'] for r in registry['runs'] if r['budget_group'] == GROUP}
    assert len(expected) == 5
    outcome = read(bundle / 'final_foundation_group_outcome.json')
    assert set(outcome['members']) == expected
    checked = seal_group(GROUP + '__seal', outcome['members'], 200, expected_members=list(expected))
    # JSON conversion handles the seal tuple/list representation without changing identity.
    assert digest_json(asdict(checked)) == digest_json(outcome['seal'])
    tuning = load_tuning_foundation_source(CASE + '__tune_foundation_group__seal')
    winner = min(tuning['members'], key=lambda k: (
        min(tuning['members'][k]['validation_mae']), tuning['members'][k]['learning_rate']))
    assert execution['selected_foundation_source'] == winner
    assert execution['learning_rate'] == tuning['members'][winner]['learning_rate']
    prep = read(ROOT / 'records/data_preparation_complete.json')['reports']['final']
    assert digest_json(outcome['statistics']) == prep['normalization_hash']
    assert outcome['calendar']['training'] == prep['eligible_windows']['final_train']
    assert outcome['calendar']['validation'] == prep['eligible_windows']['final_select']
    for item in read(bundle / 'ARTIFACTS.json'):
        path = bundle / item['path']
        assert path.resolve().is_relative_to(bundle)
        assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
    for name, member in outcome['members'].items():
        folder = bundle / 'runs' / name
        assert not (ROOT / 'runs' / name).exists(), 'HPC run already started; do not overwrite'
        head = read(folder / 'checkpoint_head.json')
        assert head['completed_epochs'] == 200
        assert sha(folder / 'continuation.pt') == head['checkpoint_sha256']
        assert sha(folder / 'best.pt') == member['checkpoint_sha256']
        assert read(folder / 'metrics.json')['validation_mae_cm'] == member['validation_mae']
        assert digest_json(read(folder / 'whitening.json')) == member['whitening_hash']
        config = read(folder / 'config.json')
        assert config['registration']['exp_id'] == name
        assert config['effective_config']['code_hash'] == auth['code_hash']
        assert config['effective_config']['device_identity'] == execution['execution_device']
        assert config['effective_config']['learning_rate'] == execution['learning_rate']
    staging = record / 'autodl_final_foundation_import_staging_20261024'
    staging.mkdir(exist_ok=False)
    for name in sorted(expected):
        shutil.copytree(bundle / 'runs' / name, staging / name)
    assert read(record / 'progress.json')['group'] == CASE + '__tune_branch_group'
    derived = copy.deepcopy(outcome)
    for name, member in derived['members'].items():
        member['checkpoint_path'] = str(ROOT / 'runs' / name / 'best.pt')
    derived['seal'] = asdict(seal_group(GROUP + '__seal', derived['members'], 200,
                                       expected_members=list(derived['members'])))
    for name in sorted(expected):
        (staging / name).rename(ROOT / 'runs' / name)
    shutil.copyfile(bundle / 'final_foundation_group_outcome.json',
                    record / 'autodl_original_final_foundation_outcome_20261024.json')
    shutil.copyfile(bundle / 'EXECUTION.json', record / 'autodl_final_foundation_execution_20261024.json')
    shutil.copyfile(bundle / 'final_foundation_group_configs.json', record / 'final_foundation_group_configs.json')
    atomic(record / 'final_foundation_group_outcome.json', derived)
    receipt = {'schema': '003-autodl-final-foundation-import-v1', 'status': 'complete_group_imported',
               'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'case': CASE, 'group': GROUP, 'members': sorted(expected), 'epochs_total': 200,
               'execution_device': execution['execution_device'],
               'cloud_original_outcome_sha256': sha(bundle / 'final_foundation_group_outcome.json'),
               'hpc_path_mapped_outcome_sha256': sha(record / 'final_foundation_group_outcome.json'),
               'weights_changed': False, 'only_result_path_and_derived_seal_remapped': True,
               'existing_hpc_training_jobs_retained': True, 'duplicate_training_required': False}
    atomic(receipt_path, receipt)
    print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    main()
