"""Observe the original GPU Cholesky on authenticated, already saved tensors.

This is a zero-training, zero-data-loader diagnostic. It retains every original
jitter and matrix, and does not propose or apply a replacement factorization.
"""
import datetime
import hashlib
import json
from pathlib import Path
import sys
import traceback

import torch

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, sort_keys=True, allow_nan=False)
        stream.write('\n')


def summary(tensor):
    finite = torch.isfinite(tensor)
    return {'dtype':str(tensor.dtype),'shape':list(tensor.shape),
            'finite':bool(finite.all()),'nan_indices':torch.nonzero(torch.isnan(tensor)).cpu().tolist(),
            'positive_inf_count':int(torch.isposinf(tensor).sum()),
            'negative_inf_count':int(torch.isneginf(tensor).sum()),
            'maximum_finite_absolute':float(tensor[finite].abs().max()) if bool(finite.any()) else None}


def main():
    evidence = ROOT/'evidence'
    evidence.mkdir(exist_ok=False)
    spec = json.loads((ROOT/'diagnostic_spec.json').read_bytes())
    result = {'status':'validation_sigma_gpu_original_factor_audit',
              'checked_at_beijing':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
              'diagnostic_root':str(ROOT),'source_root':spec['source_root'],
              'formal_training_epochs_added':0,'training_data_values_read':False,
              'selection_data_values_read':False,'evaluation_values_read':False,
              'science_rules_changed':False,'repair_admitted':False}
    try:
        assert str(ROOT) == spec['diagnostic_root'] and spec['maximum_replay_epochs'] == 0
        source = Path(spec['source_root'])
        sys.path.insert(0,str(source))
        from src.scheduler import code_identity
        from src.differentiable_filter import unscented_points, JITTERS
        assert code_identity(source) == spec['source_code_hash']
        assert all(sha(Path(path)) == digest for path,digest in spec['pinned_source_files'].items())
        for name,item in spec['tensor_artifacts'].items():
            assert sha(Path(item['path'])) == item['sha256']
        torch.set_num_threads(4)
        torch.use_deterministic_algorithms(True)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        assert torch.cuda.device_count() == 1
        device = torch.cuda.get_device_properties(0)
        assert device.name == 'NVIDIA GeForce RTX 3090' and device.total_memory == 25296044032
        result['device_identity'] = {'name':device.name,'total_memory_bytes':device.total_memory,'device':'cuda:0'}
        result['torch_version'] = torch.__version__
        operand = torch.load(spec['tensor_artifacts']['covariance_failure_operands.pt']['path'],map_location='cpu',weights_only=True)
        assert list(JITTERS) == operand['original_jitters']
        inputs = operand['original_predict_inputs']
        mean,cov = inputs['mean'].cuda(),inputs['covariance'].cuda()
        assert cov.dtype == mean.dtype == torch.float64 and bool(torch.isfinite(cov).all())
        saved = operand['original_sigma_points'].cuda()
        with torch.no_grad():
            actual,wm,wc = unscented_points(mean,cov)
            sym=(cov+cov.transpose(-1,-2))*.5
            eye=torch.eye(128,dtype=torch.float64,device='cuda')
            factors=[]; detail=[]
            for index,item in enumerate(sym):
                factor,info=torch.linalg.cholesky_ex(item+JITTERS[0]*eye)
                factors.append(factor.cpu())
                row={'index':index,'jitter':0.0,'info':int(info),'factor':summary(factor)}
                if not bool(torch.isfinite(factor).all()):
                    row['remaining_original_jitter_attempts']=[]
                    for jitter in JITTERS[1:]:
                        value,code=torch.linalg.cholesky_ex(item+jitter*eye)
                        row['remaining_original_jitter_attempts'].append({'jitter':jitter,'info':int(code),'factor':summary(value)})
                detail.append(row)
            finite=torch.isfinite(saved)
            difference=(actual[finite]-saved[finite]).abs()
            result.update(original_predict_inputs_all_finite=True,original_sigma_points=summary(actual),
                          saved_sigma_points=summary(saved),
                          original_sigma_nan_mask_matches_saved=bool(torch.equal(torch.isnan(actual),torch.isnan(saved))),
                          original_finite_sigma_values_bitwise_equal=bool(torch.equal(actual[finite],saved[finite])),
                          all_original_factor_attempts=detail,original_jitters=list(JITTERS),
                          maximum_finite_sigma_difference=float(difference.max()) if bool(torch.isfinite(difference).all()) else None)
        tensor_path=evidence/'original_gpu_factors_and_sigma.pt'
        with tensor_path.open('xb') as stream:torch.save({'factors':factors,'sigma':actual.cpu(),'wm':wm.cpu(),'wc':wc.cpu()},stream)
        result['tensor_artifact']={'path':str(tensor_path),'sha256':sha(tensor_path),'bytes':tensor_path.stat().st_size}
        assert all(sha(Path(path)) == digest for path,digest in spec['pinned_source_files'].items())
        assert code_identity(source) == spec['source_code_hash']
        result.update(source_code_hash=spec['source_code_hash'],all_source_bytes_unchanged=True,
                      all_twelve_formal_members_preserved=True,source_identity_count=len(spec['pinned_source_files']),exit_code=0)
        save(evidence/'sigma_gpu_audit_result.json',result)
        print(json.dumps(result,sort_keys=True,allow_nan=False),flush=True)
        return 0
    except Exception as error:
        result.update(status='validation_sigma_gpu_audit_technical_error',exit_code=1,
                      error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
        save(evidence/'sigma_gpu_audit_technical_error.json',result)
        print(json.dumps(result,sort_keys=True,allow_nan=False),flush=True)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
