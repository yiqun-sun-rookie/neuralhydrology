"""Replay one failed continuation in a new diagnostic directory; no formal output.

Run with the source release's admitted GPU environment (numpy and torch required):
python -B hpc/replay_gradient_diagnostic_20261011.py --source-root SOURCE \
  --diagnostic-root NEW_DIRECTORY --run-id RUN --expected-code-sha256 CODE \
  --expected-config-sha256 CONFIG --expected-checkpoint-sha256 CHECKPOINT

NEW_DIRECTORY must be the isolated deployed package containing diagnostic_spec.json.
An exclusive evidence/ child is reserved; a prior execution is never overwritten.
Only tuning_train (2017--2020) is loaded. The original frozen configuration,
complete foundation seal, admission, device, continuation and histories are
checked before replay. Adam updates occur only in memory. A failing effective
batch's starting model/Adam/RNG state is saved under NEW_DIRECTORY, never in the
source release. Source failure evidence is retained. No epoch/finish/group fit,
selection loader, final loader, scheduler command or remote command is called.

The two loss-scale trials are diagnostics, not an authorized training repair.
Their factors are 2**exponent and 2**(exponent-1), default -8 and -9. Instrumented
backward is repeated only on the failing batch, with the same saved batch start.
The earliest nonfinite autograd event means backward execution order, not proof
of the mathematical root cause. A checkpoint without RNG state cannot establish
historical RNG equality; local RNG is preserved for all same-start comparisons.
"""
import argparse
import copy
import hashlib
import importlib
import json
import math
import random
import sys
import time
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

TARGET_RUN = 'explicit_gru__historical_capacity__tune_branch__filter_joint__s101__lr0p003'


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write_exclusive(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def tensor_summary(value):
    if value is None:
        return {'missing': True, 'finite': False}
    detached = value.detach()
    finite = torch.isfinite(detached)
    good = detached[finite]
    return {'missing': False, 'finite': bool(finite.all()),
            'dtype': str(detached.dtype), 'shape': list(detached.shape),
            'element_count': detached.numel(), 'zero_count': int((detached == 0).sum()),
            'finite_nonzero_count': int((finite & (detached != 0)).sum()),
            'nan_count': int(torch.isnan(detached).sum()),
            'positive_inf_count': int(torch.isposinf(detached).sum()),
            'negative_inf_count': int(torch.isneginf(detached).sum()),
            'maximum_finite_absolute': float(good.abs().max()) if good.numel() else None}


def tensor_sha256(value):
    tensor = value.detach().cpu().contiguous()
    digest = hashlib.sha256(str((str(tensor.dtype), tuple(tensor.shape))).encode())
    digest.update(tensor.reshape(-1).view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()


def assert_finite_tree(value, path='state'):
    if isinstance(value, torch.Tensor):
        require(bool(torch.isfinite(value).all()), 'nonfinite tensor: ' + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            assert_finite_tree(item, path + '/' + str(key))
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            assert_finite_tree(item, path + '/' + str(index))
    elif isinstance(value, (float, np.floating)):
        require(math.isfinite(float(value)), 'nonfinite number: ' + path)


def cpu_tree(value):
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().clone()
    if isinstance(value, dict):
        return {key: cpu_tree(item) for key, item in value.items()}
    if isinstance(value, list):
        return [cpu_tree(item) for item in value]
    if isinstance(value, tuple):
        return tuple(cpu_tree(item) for item in value)
    return copy.deepcopy(value)


def capture_rng():
    return {'python': random.getstate(), 'numpy': np.random.get_state(),
            'torch_cpu': torch.get_rng_state().clone(),
            'torch_cuda': [state.clone() for state in torch.cuda.get_rng_state_all()]
            if torch.cuda.is_available() else []}


def restore_rng(state):
    random.setstate(state['python'])
    np.random.set_state(state['numpy'])
    torch.set_rng_state(state['torch_cpu'])
    if state['torch_cuda']:
        torch.cuda.set_rng_state_all(state['torch_cuda'])


def named_trainable(session, api):
    named = []; seen = set()
    for name in ('initializer', 'encoder', 'process', 'readout'):
        module = getattr(session.parts, name)
        if module is not None:
            for key, parameter in module.named_parameters():
                if parameter.requires_grad and id(parameter) not in seen:
                    named.append((name + '.' + key, parameter)); seen.add(id(parameter))
    if session.noise is not None:
        for name in ('raw_q', 'raw_r', 'raw_p0'):
            parameter = getattr(session.noise, name)
            if parameter.requires_grad and id(parameter) not in seen:
                named.append(('noise.' + name, parameter)); seen.add(id(parameter))
    require([id(p) for _, p in named] ==
            [id(p) for p in api.models.parameters(session.parts, session.noise, True)],
            'diagnostic named parameter order differs from original optimizer order')
    return named


def capture_start(session, api):
    return {'model': api.training.snapshot_parts(session.parts, session.noise),
            'optimizer': cpu_tree(session.optimizer.state_dict()), 'rng': capture_rng()}


def restore_start(session, api, start):
    api.training.restore_parts(session.parts, start['model'], session.noise)
    session.optimizer.load_state_dict(copy.deepcopy(start['optimizer']))
    session.optimizer.zero_grad(set_to_none=True)
    restore_rng(start['rng'])


class AutogradTrace:
    """Observe gradients without changing them; retain only the first bad event."""
    def __init__(self, loss):
        self.events = 0; self.first_bad = None; self.handles = []
        pending = [loss.grad_fn]; seen = set()
        while pending:
            node = pending.pop()
            if node is None or node in seen:
                continue
            seen.add(node)
            kind = type(node).__name__
            def hook(inputs, outputs, kind=kind):
                self.events += 1
                if self.first_bad is None:
                    bad = [(side, index, tensor_summary(tensor))
                           for side, values in (('grad_output', outputs), ('grad_input', inputs))
                           for index, tensor in enumerate(values)
                           if tensor is not None and not bool(torch.isfinite(tensor).all())]
                    if bad:
                        self.first_bad = {'backward_event_index': self.events,
                                          'operation': kind, 'nonfinite_gradients': bad}
            self.handles.append(node.register_hook(hook))
            pending.extend(edge[0] for edge in node.next_functions)

    def close(self):
        for handle in self.handles:
            handle.remove()


def robust_norm(gradients):
    require(gradients and all(g is not None and bool(torch.isfinite(g).all()) for g in gradients),
            'cannot normalize missing or nonfinite gradients')
    peak = torch.stack([g.detach().double().abs().max() for g in gradients]).max()
    if float(peak) == 0:
        return peak
    norm = peak * torch.stack([(g.detach().double() / peak).square().sum()
                              for g in gradients]).sum().sqrt()
    require(bool(torch.isfinite(norm)), 'diagnostic norm exceeds float64 range')
    return norm


def scaled_equivalent_clip(gradients, scale):
    """Clip g=scaled_gradient/scale without materializing overflowing raw g.

    The original rule is g*min(1, 1/(||g||+1e-6)). Hence the coefficient on
    scale*g is min(1/scale, 1/(||scale*g||+scale*1e-6)). This is a real-arithmetic
    identity; computed rounding and Adam results are measured, not assumed equal.
    """
    require(math.isfinite(scale) and 0 < scale <= 1, 'invalid diagnostic scale')
    norm = robust_norm(gradients)
    coefficient = torch.clamp(1. / (norm + scale * 1e-6), max=1. / scale)
    casts = {}; before_nonzero = sum(int((g != 0).sum()) for g in gradients)
    with torch.no_grad():
        for gradient in gradients:
            cast = coefficient.to(dtype=gradient.dtype, device=gradient.device)
            casts[str(gradient.dtype)] = {'cast_value': float(cast), 'cast_is_zero': float(cast) == 0.,
                                         'cast_is_subnormal': 0 < abs(float(cast)) < torch.finfo(gradient.dtype).tiny}
            # Diagnostic only: multiply in float64 before conversion, avoiding a coefficient
            # rounded/flush-to-zero in float32. This differs from the original fallback
            # arithmetic; measured comparisons must not be reported as formal acceptance.
            gradient.copy_((gradient.detach().double() * coefficient).to(dtype=gradient.dtype))
    after_nonzero = sum(int((g != 0).sum()) for g in gradients)
    require(before_nonzero == 0 or after_nonzero > 0, 'diagnostic clipping erased every nonzero gradient')
    return {'scaled_norm_float64': float(norm), 'implied_unscaled_norm_float64': float(norm / scale),
            'coefficient_applied_to_scaled_gradients': float(coefficient),
            'original_clip_bound': 1., 'original_clip_epsilon': 1e-6, 'coefficient_dtype_casts': casts,
            'nonzero_before_clip': before_nonzero, 'nonzero_after_clip': after_nonzero,
            'diagnostic_multiplication_precision': 'float64_then_original_gradient_dtype',
            'original_fallback_multiplication_precision': 'original_gradient_dtype',
            'formal_equivalence_acceptance': False}


def trial_batch(session, api, batch, scale=1., instrument=False):
    """Original branch forward/loss/accumulation; one in-memory update if valid."""
    named = named_trainable(session, api)
    result = {'scale': scale, 'micro_batches': [], 'success': False}
    session.optimizer.zero_grad(set_to_none=True)
    denominator = (1 + batch.high_mask[:, 24:].double()).sum((0, 1))
    ledger = api.filter.StabilityLedger() if session.method.startswith('filter') else None
    try:
        for offset in range(0, len(batch.history), session.micro_batch):
            row = {'micro_batch_index': len(result['micro_batches']) + 1, 'effective_batch_offset': offset}
            result['micro_batches'].append(row)
            sub = api.contracts.slice_batch(batch, slice(offset, offset + session.micro_batch))
            prediction = api.training.branch_prediction(session.parts, session.noise, session.whitening,
                                                        session.method, sub, ledger)
            loss = api.training.weighted_mae_cm(prediction, sub.targets[:, 24:],
                                                sub.high_mask[:, 24:], session.stats, denominator)
            row.update(prediction_sha256=tensor_sha256(prediction), forward=tensor_summary(prediction),
                       unscaled_loss_hex=float(loss.detach()).hex() if bool(torch.isfinite(loss)) else None,
                       unscaled_loss_finite=bool(torch.isfinite(loss)))
            require(bool(torch.isfinite(loss)), 'nonfinite loss')
            backward_loss = loss if scale == 1. else loss * scale
            trace = AutogradTrace(backward_loss) if instrument else None
            try:
                backward_loss.backward()
            finally:
                if trace is not None:
                    row['autograd_trace'] = {'events': trace.events, 'first_nonfinite': trace.first_bad}
                    trace.close()
            row['parameter_gradients'] = {name: tensor_summary(p.grad) for name, p in named}
        result['parameter_gradients'] = {name: tensor_summary(p.grad) for name, p in named}
        result['_raw_gradients'] = [p.grad.detach().cpu().clone() if p.grad is not None else None for _, p in named]
        require(all(p.grad is not None and bool(torch.isfinite(p.grad).all()) for _, p in named),
                'missing or nonfinite trainable gradient')
        if ledger is not None:
            result['stability'] = ledger.report(enforce=False)
        gradients = [p.grad for _, p in named]
        result['_raw_gradients'] = [g.detach().cpu().clone() for g in gradients]
        norm = robust_norm(gradients)
        result['_directions'] = [g.detach().double().cpu() / float(norm) if float(norm) else
                                 torch.zeros_like(g.detach().double().cpu()) for g in gradients]
        if scale == 1.:
            result['gradient_norm_before_clip'] = float(api.training.clip_finite_gradients([p for _, p in named]))
        else:
            result['equivalent_clip'] = scaled_equivalent_clip(gradients, scale)
        result['_clipped_gradients'] = [p.grad.detach().cpu().clone() for _, p in named]
        session.optimizer.step()
        assert_finite_tree(api.training.snapshot_parts(session.parts, session.noise), 'after_step/model')
        assert_finite_tree(session.optimizer.state_dict(), 'after_step/optimizer')
        result['_after_model'] = api.training.snapshot_parts(session.parts, session.noise)
        result['_after_optimizer'] = cpu_tree(session.optimizer.state_dict())
        result['success'] = True
    except Exception as error:
        result['error'] = {'type': type(error).__name__, 'reason': str(error)}
        result['parameter_gradients'] = {name: tensor_summary(p.grad) for name, p in named}
        if '_raw_gradients' not in result:
            result['_raw_gradients'] = [p.grad.detach().cpu().clone() if p.grad is not None else None for _, p in named]
    return result


def public_trial(result):
    return {key: value for key, value in result.items() if not key.startswith('_')}


def compare_trees(left, right):
    result = {'structure_equal': True, 'tensor_count': 0, 'bitwise_equal': True,
              'maximum_absolute_difference': 0., 'maximum_relative_difference': 0.}
    def visit(a, b):
        if isinstance(a, torch.Tensor) and isinstance(b, torch.Tensor):
            if a.shape != b.shape or a.dtype != b.dtype:
                result['structure_equal'] = False; result['bitwise_equal'] = False; return
            result['tensor_count'] += 1
            aa, bb = a.detach().cpu(), b.detach().cpu()
            result['bitwise_equal'] &= torch.equal(aa, bb)
            difference = (aa.double() - bb.double()).abs()
            if difference.numel():
                result['maximum_absolute_difference'] = max(result['maximum_absolute_difference'], float(difference.max()))
                relative = difference / torch.maximum(aa.double().abs(), bb.double().abs()).clamp_min(1e-300)
                result['maximum_relative_difference'] = max(result['maximum_relative_difference'], float(relative.max()))
        elif isinstance(a, dict) and isinstance(b, dict) and set(a) == set(b):
            for key in a:
                visit(a[key], b[key])
        elif isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)) and len(a) == len(b):
            for x, y in zip(a, b):
                visit(x, y)
        elif a != b:
            result['structure_equal'] = False; result['bitwise_equal'] = False
    visit(left, right)
    return result


def compare_trials(left, right):
    lhs, rhs = left['micro_batches'], right['micro_batches']
    same_forward = len(lhs) == len(rhs) and all(a.get('prediction_sha256') == b.get('prediction_sha256')
                   and a.get('unscaled_loss_hex') == b.get('unscaled_loss_hex') for a, b in zip(lhs, rhs))
    result = {'same_complete_forward_and_unscaled_loss': same_forward,
              'both_successful': left['success'] and right['success']}
    if '_raw_gradients' in left and '_raw_gradients' in right:
        finite_elements = 0; lost_nonzero = 0; max_difference = 0.
        for a, b in zip(left['_raw_gradients'], right['_raw_gradients']):
            if a is None or b is None:
                continue
            original = a.double() / left['scale']; other = b.double() / right['scale']
            mask = torch.isfinite(original) & torch.isfinite(other)
            finite_elements += int(mask.sum())
            lost_nonzero += int((mask & (original != 0) & (other == 0)).sum())
            if bool(mask.any()):
                max_difference = max(max_difference, float((original[mask]-other[mask]).abs().max()))
        result['finite_raw_elements_after_scale_normalization'] = {
            'compared_element_count': finite_elements, 'left_nonzero_became_right_zero_count': lost_nonzero,
            'maximum_absolute_difference': max_difference}
    if result['both_successful']:
        for name, field in (('normalized_gradient_direction', '_directions'),
                            ('original_epsilon_equivalent_clipped_gradient', '_clipped_gradients'),
                            ('adam_one_step_model', '_after_model'),
                            ('adam_one_step_moments_and_steps', '_after_optimizer')):
            result[name] = compare_trees(left[field], right[field])
    else:
        result['original_adam_equivalence'] = 'cannot establish against a nonfinite or incomplete original backward'
    return result


def import_source(root, expected_code):
    require(not any(name == 'src' or name.startswith('src.') for name in sys.modules),
            'source modules already imported; start a fresh Python process')
    sys.path.insert(0, str(root))
    modules = {key: importlib.import_module('src.' + value) for key, value in
               {'runtime': 'runtime', 'scheduler': 'scheduler', 'training': 'training',
                'models': 'models', 'contracts': 'contracts', 'filter': 'differentiable_filter',
                'execution': 'execution'}.items()}
    for module in modules.values():
        require(root in Path(module.__file__).resolve().parents, 'import escaped source release')
    api = SimpleNamespace(**modules)
    require(api.scheduler.code_identity(root) == expected_code == api.scheduler.code_identity(),
            'source implementation SHA256 differs from expected identity')
    return api


def validate_metadata(root, run_id, args, api):
    run_dir = root / 'runs' / run_id
    for path in (run_dir, run_dir / 'config.json', run_dir / 'continuation.pt', run_dir / 'failure.json'):
        require(root in path.resolve(strict=True).parents, 'source run path escapes source root')
    config_path = run_dir / 'config.json'
    require(sha256_file(config_path) == args.expected_config_sha256, 'frozen source configuration SHA256 differs')
    config = read_json(config_path); effective = config['effective_config']; run = config['registration']
    require(run['exp_id'] == run_id and run['type'] == 'tune_branch' and run['method'] == 'filter_joint',
            'diagnostic must target the registered failed tuning filter_joint member')
    require(run['case'] == 'explicit_gru__historical_capacity' and run['seed'] == 101 and
            effective['learning_rate'] == .003 and run['train_years'] == [2017, 2018, 2019, 2020],
            'target architecture, seed, rate or training years differ')
    protocol_path = root / 'configs/protocol-v3.json'
    protocol = read_json(protocol_path); auth = read_json(root / 'records/authorization.json')
    protocol_sha = sha256_file(protocol_path)
    require(config['status'] == 'frozen_authorized' and config['protocol_sha256'] ==
            auth['protocol_sha256'] == protocol_sha, 'configuration/protocol/authorization binding differs')
    require(auth['code_hash'] == effective['code_hash'] == args.expected_code_sha256,
            'authorization or frozen code identity differs')
    require(auth['authority'].get('formal_training') and auth['authority'].get('technical_recovery') and
            not auth['authority'].get('evaluation_year_reads') and not auth.get('evaluation_year_reads', False),
            'source authority missing or evaluation-read boundary changed')
    registry = read_json(root / 'configs/registry-v3.json'); api.scheduler.validate_registry(registry, protocol)
    registered = [r for r in registry['runs'] if r['exp_id'] == run_id]
    require(registered == [run], 'frozen registration differs from source registry')
    group_configs = read_json(root / 'records' / run['case'] / 'tune_branch_group_configs.json')
    require(group_configs.get(run_id) == config, 'run differs from frozen whole-group configuration')
    prep = read_json(root / 'records/data_preparation_complete.json')
    require(prep.get('status') == 'admitted' and prep.get('code_hash') == args.expected_code_sha256,
            'prepared data not admitted to source implementation')
    manifest = read_json(root / 'prepared/tuning/manifest.json')
    require(manifest.get('status') == 'admitted' and not manifest.get('evaluation_year_reads', False),
            'tuning manifest admission or evaluation-read boundary changed')
    require(api.scheduler.digest_json(manifest) == effective['training_data_hash'] and
            manifest['tide_source_hash'] == effective['tide_source_hash'], 'frozen data/tide manifest identity differs')
    entries = [e for e in manifest['files'] if 'tuning_train' in e.get('phases', [])]
    require(entries and all(e['role'] in ('realtime_inputs', 'qc_labels', 'astronomical_tide') and
                            set(e['years']).issubset({2017, 2018, 2019, 2020}) for e in entries),
            'tuning training entry includes forbidden role or years')
    outcome_path = root / 'records' / run['case'] / 'tune_foundation_group_outcome.json'
    outcome = read_json(outcome_path); seal_record = outcome['seal']
    require(len(outcome['members']) == 3 and seal_record['epochs'] == 400, 'complete 3-member 400-epoch parent group required')
    checked = api.scheduler.seal_group(run['case'] + '__tune_foundation_group__seal', outcome['members'],
                                       400, expected_members=list(outcome['members']))
    from dataclasses import asdict
    normalized_seal = dict(seal_record, member_ids=tuple(seal_record['member_ids']))
    require(asdict(checked) == normalized_seal, 'complete saved parent seal differs from reconstructed evidence')
    seals = {checked.group_id: checked}; api.scheduler.verify_parent_binding(run, effective, seals)
    failure = read_json(run_dir / 'failure.json')
    require(failure.get('status') == 'failed' and failure.get('epochs_completed') == 40 and
            failure.get('reason') == 'missing or nonfinite trainable gradient', 'expected 40-epoch source failure differs')
    checkpoint_path = run_dir / 'continuation.pt'
    require(sha256_file(checkpoint_path) == args.expected_checkpoint_sha256, 'source continuation SHA256 differs')
    pinned = {str(path): sha256_file(path) for path in
              (config_path, checkpoint_path, run_dir / 'failure.json', run_dir / 'metrics.json',
               protocol_path, root / 'configs/registry-v3.json', Path(effective['parent_checkpoint']),
               root / 'records/authorization.json', root / 'records/data_preparation_complete.json',
               root / 'prepared/tuning/manifest.json', outcome_path,
               root / 'records' / run['case'] / 'tune_branch_group_configs.json')}
    return run, config, protocol, manifest, seals, pinned


def validate_spec(spec, source, deployed, args):
    require(spec.get('schema') == 'isolated_gradient_diagnostic_spec_v1' and
            spec.get('source_root') == str(source) and spec.get('diagnostic_root') == str(deployed) and
            spec.get('run_id') == args.run_id and spec.get('source_code_hash') == args.expected_code_sha256,
            'deployed diagnostic specification differs from exact invocation')
    require(spec.get('in_memory_optimizer_replay_allowed') is True and
            spec.get('formal_checkpoint_write_allowed') is False and
            spec.get('scientific_rules_changed') is False and spec.get('evaluation_values_read') is False and
            spec.get('admitted_training_phase_only') == 'tuning_train' and
            spec.get('training_years') == [2017, 2018, 2019, 2020] and
            spec.get('expected_saved_epoch') == 40 and spec.get('replayed_epoch') == 41,
            'deployed diagnostic scope or permitted writes differs')
    files = sorted([*source.joinpath('src').glob('*.py'), *source.joinpath('scripts').glob('*.py'),
                    *source.joinpath('vendor/pytides').glob('*.py')])
    actual = {p.relative_to(source).as_posix(): sha256_file(p) for p in files}
    require(actual == spec.get('source_code_file_hashes'), 'source per-file identity differs from probe')
    expected = spec['source_run_files']
    require(set(expected) == {'config.json', 'continuation.pt', 'failure.json', 'metrics.json'},
            'diagnostic specification must bind all four source run files')
    require(expected['config.json']['sha256'] == args.expected_config_sha256 and
            expected['continuation.pt']['sha256'] == args.expected_checkpoint_sha256,
            'CLI checkpoint/config identities differ from diagnostic specification')
    for name, identity in expected.items():
        path = source / 'runs' / args.run_id / name
        require(source in path.resolve(strict=True).parents and path.stat().st_size == identity['bytes'] and
                sha256_file(path) == identity['sha256'], 'source run probe identity differs: ' + name)


def validate_checkpoint(state, config_sha, metrics, expected_epochs=40):
    require(set(state) == {'current', 'optimizer', 'best', 'values', 'train_metrics', 'shuffle_hashes', 'config_sha256'},
            'continuation fields differ; review new state format before replay')
    require(state['config_sha256'] == config_sha, 'continuation does not bind exact source config bytes')
    require(all(len(state[key]) == expected_epochs for key in ('values', 'train_metrics', 'shuffle_hashes')),
            'continuation is not the required complete 40-epoch state')
    require(state['best'] is not None and all(math.isfinite(x) and x >= 0 for x in state['values']),
            'best state or finite complete validation history missing')
    require(metrics.get('validation_mae_cm') == state['values'] and
            metrics.get('train_metrics') == state['train_metrics'] and
            metrics.get('shuffle_hashes') == state['shuffle_hashes'], 'source metrics and checkpoint histories differ')
    require(all(isinstance(x, str) and len(x) == 64 for x in state['shuffle_hashes']), 'invalid shuffle identity history')
    assert_finite_tree(state)


def validate_adam(session, api, expected_steps):
    named = named_trainable(session, api); optimizer = session.optimizer
    require(len(optimizer.param_groups) == 1 and
            [id(p) for p in optimizer.param_groups[0]['params']] == [id(p) for _, p in named],
            'Adam parameter identity/order differs')
    group = optimizer.param_groups[0]
    require(group['lr'] == .003 and tuple(group['betas']) == (.9, .999) and group['eps'] == 1e-8 and
            group['weight_decay'] == 0 and not group.get('amsgrad', False) and not group.get('maximize', False),
            'Adam settings differ from frozen original rule')
    require(len(optimizer.state) == len(named), 'Adam state missing trainable parameter')
    for name, parameter in named:
        state = optimizer.state[parameter]
        require(set(state) == {'step', 'exp_avg', 'exp_avg_sq'}, 'Adam state fields differ: ' + name)
        require(float(state['step']) == expected_steps and state['exp_avg'].shape == parameter.shape and
                state['exp_avg_sq'].shape == parameter.shape and bool((state['exp_avg_sq'] >= 0).all()),
                'Adam step, moment shape or variance differs: ' + name)
    assert_finite_tree(optimizer.state_dict(), 'Adam')


def prepare_new_root(source, diagnostic):
    source = Path(source).resolve(strict=True)
    diagnostic = Path(diagnostic).resolve()
    require(source != diagnostic and source not in diagnostic.parents and diagnostic not in source.parents,
            'diagnostic directory overlaps source release')
    require(diagnostic.is_dir() and (diagnostic / 'diagnostic_spec.json').is_file(),
            'isolated diagnostic package and specification must already be deployed')
    evidence = diagnostic / 'evidence'
    evidence.mkdir(exist_ok=False)
    require(diagnostic in evidence.resolve().parents, 'diagnostic evidence path escaped deployed root')
    return source, evidence


class EventLog:
    def __init__(self, root):
        self.stream = (root / 'events.jsonl').open('x', encoding='utf-8')

    def emit(self, event):
        event = dict(event, emitted_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
        line = json.dumps(event, sort_keys=True, allow_nan=False)
        self.stream.write(line + '\n'); self.stream.flush()
        print(line, flush=True)

    def close(self):
        self.stream.close()


def execute(args):
    source, diagnostic = prepare_new_root(args.source_root, args.diagnostic_root)
    log = EventLog(diagnostic); api = None; pinned = {}; result = None
    try:
        require(args.run_id == TARGET_RUN, 'this diagnostic is restricted to the specified failed member')
        deployed = diagnostic.parent
        spec_path = deployed / 'diagnostic_spec.json'
        spec = read_json(spec_path)
        validate_spec(spec, source, deployed, args)
        write_exclusive(diagnostic / 'diagnostic_spec_identity.json',
                        {'path': str(spec_path), 'sha256': sha256_file(spec_path), 'specification': spec})
        api = import_source(source, args.expected_code_sha256)
        run, config, protocol, manifest, seals, pinned = validate_metadata(source, args.run_id, args, api)
        actual_device = api.execution.device_identity(config['effective_config']['device'])
        require(actual_device == config['effective_config']['device_identity'] == spec['expected_device_identity'],
                'GPU model or total memory differs')
        api.training.deterministic_runtime(); torch.set_num_threads(4)
        state = torch.load(source / 'runs' / args.run_id / 'continuation.pt', map_location='cpu', weights_only=True)
        validate_checkpoint(state, args.expected_config_sha256, read_json(source / 'runs' / args.run_id / 'metrics.json'))
        log.emit({'status': 'source_preflight_verified', 'run_id': args.run_id, 'source_root': str(source),
                  'source_file_sha256': pinned, 'source_code_sha256': args.expected_code_sha256,
                  'device_identity': actual_device, 'torch_version': str(torch.__version__),
                  'torch_cuda_version': torch.version.cuda, 'completed_epochs': 40,
                  'training_phase_only': 'tuning_train', 'training_years_only': [2017, 2018, 2019, 2020],
                  'checkpoint_contains_global_rng': False, 'formal_optimizer_updates': 0,
                  'source_job_inactivity_must_be_verified_by_controller': True})
        # Never execute_group: that helper would open the 2021 selection loader.
        stage = api.runtime.load_stage(manifest, 'tuning_train')
        stats = api.runtime.fit_stage_stats(stage, manifest)
        require(api.scheduler.digest_json(api.runtime.stats_record(stats)) == config['effective_config']['normalization_hash'],
                'reconstructed training statistics differ')
        windows, issue_times = api.runtime.prepare_windows(stage, stats)
        for epoch in range(1, 41):
            old_ids, old_sha = api.training.epoch_indices(issue_times, run['seed'], epoch)
            require(old_sha == state['shuffle_hashes'][epoch-1] and
                    len(state['train_metrics'][epoch-1]) == (len(old_ids) + 15)//16,
                    'complete checkpoint training order or batch history differs at epoch ' + str(epoch))
        # build_session receives a NEW diagnostic output root, never the failed source runs.
        # It reuses complete parent verification, parent checkpoint authentication and exact construction.
        session = api.runtime.build_session(run, config, protocol, stats, diagnostic / 'scratch_session', seals)
        require(diagnostic in session.run_dir.resolve().parents, 'session output escaped diagnostic directory')
        api.training.restore_parts(session.parts, state['current'], session.noise)
        session.optimizer.load_state_dict(state['optimizer'])
        require(session.micro_batch == config['effective_config']['training_contract'].get('initial_micro_batch', 2)
                and session.micro_batch >= 1, 'original microbatch differs')
        validate_adam(session, api, sum(len(rows) for rows in state['train_metrics']))
        ids, shuffle_sha = api.training.epoch_indices(issue_times, run['seed'], 41)
        require(len(ids) > 0, 'empty replay training phase')
        write_exclusive(diagnostic / 'replay_identity.json',
                        {'source_sha256': pinned, 'run_id': args.run_id, 'epoch': 41, 'shuffle_sha256': shuffle_sha,
                         'effective_batch_size': 16, 'micro_batch_size': session.micro_batch,
                         'normalization_sha256': config['effective_config']['normalization_hash'],
                         'manifest_sha256': api.scheduler.digest_json(manifest), 'device_identity': actual_device,
                         'no_formal_epoch_writes': True, 'source_failure_retained': True,
                         'rng_limit': 'source continuation has no global RNG; deterministic original path reused'})
        successful_batches = 0
        for offset in range(0, len(ids), 16):
            batch_index = offset // 16 + 1
            index_list = ids[offset:offset+16]
            batch = api.execution.move_batch(api.contracts.combine_batches([windows[i] for i in index_list]), session.device)
            start = capture_start(session, api)
            log.emit({'status': 'effective_batch_started', 'epoch': 41, 'effective_batch_index': batch_index,
                      'window_indices': index_list.tolist(), 'actual_batch_size': len(batch.history)})
            original = trial_batch(session, api, batch)
            log.emit({'status': 'effective_batch_finished' if original['success'] else 'first_replay_failure',
                      'epoch': 41, 'effective_batch_index': batch_index, 'trial': public_trial(original),
                      'formal_optimizer_updates': 0, 'diagnostic_memory_updates': successful_batches + int(original['success'])})
            if original['success']:
                successful_batches += 1
                continue
            # Evidence contains model/Adam/RNG only. No raw batch/input/target arrays are saved.
            state_path = diagnostic / ('failed_batch_%05d_start.pt' % batch_index)
            with state_path.open('xb') as stream:
                torch.save(start, stream)
            write_exclusive(diagnostic / 'failed_batch_start_identity.json',
                            {'state_path': str(state_path), 'state_sha256': sha256_file(state_path),
                             'epoch': 41, 'effective_batch_index': batch_index,
                             'window_indices': index_list.tolist(), 'shuffle_sha256': shuffle_sha,
                             'source_continuation_sha256': args.expected_checkpoint_sha256,
                             'prior_in_memory_optimizer_updates': successful_batches})
            restore_start(session, api, start)
            instrumented = trial_batch(session, api, batch, instrument=True)
            log.emit({'status': 'same_start_instrumented_backward', 'trial': public_trial(instrumented),
                      'comparison_with_original': compare_trials(original, instrumented)})
            trials = []
            for exponent in (args.loss_scale_exponent, args.loss_scale_exponent-1):
                restore_start(session, api, start)
                scaled = trial_batch(session, api, batch, scale=2. ** exponent)
                trials.append(scaled)
                log.emit({'status': 'same_start_loss_scale_trial', 'power_of_two_exponent': exponent,
                          'trial': public_trial(scaled), 'comparison_with_original': compare_trials(original, scaled)})
            result = {'status': 'failure_localized', 'epoch': 41, 'effective_batch_index': batch_index,
                      'prior_in_memory_optimizer_updates': successful_batches, 'formal_optimizer_updates': 0,
                      'original': public_trial(original), 'instrumented': public_trial(instrumented),
                      'scale_trials': [public_trial(t) for t in trials],
                      'adjacent_scale_comparison': compare_trials(*trials),
                      'scientific_or_training_repair_applied': False, 'evaluation_or_final_inputs_read': False}
            break
        if result is None:
            result = {'status': 'complete_epoch_replay_without_reproduced_failure', 'epoch': 41,
                      'diagnostic_memory_updates': successful_batches, 'formal_optimizer_updates': 0,
                      'no_validation_run': True, 'no_new_formal_epoch_saved': True,
                      'historical_failure_cause': 'not established', 'evaluation_or_final_inputs_read': False}
    except Exception as error:
        result = {'status': 'diagnostic_stopped', 'error_type': type(error).__name__, 'reason': str(error),
                  'formal_optimizer_updates': 0, 'scientific_or_training_repair_applied': False}
    finally:
        changes = [path for path, sha in pinned.items() if not Path(path).is_file() or sha256_file(path) != sha]
        if api is not None and api.scheduler.code_identity(source) != args.expected_code_sha256:
            changes.append('source implementation code identity')
        result = result or {'status': 'diagnostic_stopped', 'reason': 'no result produced'}
        result['source_identity_rechecked_unchanged'] = bool(pinned) and api is not None and not changes
        result['source_changes_observed'] = changes
        if changes:
            result['status'] = 'diagnostic_stopped_source_changed'
        write_exclusive(diagnostic / 'diagnostic_result.json', result)
        log.emit(result); log.close()
    return 0 if result['status'] in ('failure_localized', 'complete_epoch_replay_without_reproduced_failure') else 1


def parser():
    command = argparse.ArgumentParser(description=__doc__)
    for name in ('source-root', 'diagnostic-root', 'run-id', 'expected-code-sha256',
                 'expected-config-sha256', 'expected-checkpoint-sha256'):
        command.add_argument('--' + name, required=True)
    command.add_argument('--loss-scale-exponent', type=int, default=-8)
    return command


def main():
    args = parser().parse_args()
    for name in ('expected_code_sha256', 'expected_config_sha256', 'expected_checkpoint_sha256'):
        value = getattr(args, name)
        require(len(value) == 64 and all(c in '0123456789abcdef' for c in value), 'invalid SHA256: ' + name)
    require(-120 <= args.loss_scale_exponent <= -1, 'loss scale exponent must be between -120 and -1')
    return execute(args)


if __name__ == '__main__':
    raise SystemExit(main())
