"""Derive an isolated diagnostic job from the verified path-fix script, once."""
import base64
import datetime
import hashlib
import json
import pathlib
import re
import subprocess

ROOT = pathlib.Path(__file__).resolve().parents[1]
XBATCH = '/usr/local/globle/softs/slurm/19.05.4.1/bin/xbatch'


def save(name, value):
    with (ROOT / 'records' / name).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n')


def query(args):
    p = subprocess.run(args, capture_output=True, text=True, timeout=30)
    if p.returncode:
        raise RuntimeError('scheduler query failed: ' + repr(args) + p.stderr)
    return p.stdout


def main():
    spec = json.loads((ROOT / 'diagnostic_spec.json').read_text())
    assert str(ROOT) == spec['diagnostic_root']
    source = pathlib.Path(spec['source_root'])
    jobs = json.loads((source / 'records/scheduler_jobs.json').read_text())
    assert str(jobs[spec['case']]) == str(spec['source_job'])
    queued = query(['squeue', '-h', '-j', str(spec['source_job']), '-o', '%i|%j|%T|%N'])
    accounting = query(['sacct', '-n', '-X', '-j', str(spec['source_job']), '--format=JobID,State,ExitCode', '-P'])
    assert not queued.strip() and str(spec['source_job']) + '|FAILED|1:0|' in accounting
    all_jobs = query(['squeue', '-h', '-u', 'sunyiq', '-o', '%i|%j|%T|%N'])
    assert not any(line.split('|')[1] == spec['job_name'] for line in all_jobs.splitlines())
    for name, expected in spec['source_run_files'].items():
        p = source / 'runs' / spec['run_id'] / name
        assert hashlib.sha256(p.read_bytes()).hexdigest() == expected['sha256'], name
    template = pathlib.Path(spec['verified_pathfix_script'])
    raw = template.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == spec['verified_pathfix_sha256']
    lines = raw.decode().splitlines()
    assert lines[0] == '#!/usr/bin/env bash'
    assert '#SBATCH -p hgpu2p' in lines
    assert '#SBATCH --cpus-per-task=4' in lines and '#SBATCH --gres=gpu:1' in lines
    assert lines.index('conda activate nh_final') < lines.index('set -u')
    changed = []
    body = []
    replacements = {'#SBATCH --job-name=': '#SBATCH --job-name=' + spec['job_name'],
                    '#SBATCH --exclude=': '#SBATCH --exclude=ngu002,ngu011',
                    '#SBATCH --output=': '#SBATCH --output=' + str(ROOT / 'logs/%x_%j.out'),
                    'cd ': 'cd ' + str(ROOT)}
    for line in lines:
        if line.startswith('#SBATCH --dependency=') or line.startswith('case_name=') or line.startswith('python -B -u scripts/train_supercomputer_case.py'):
            changed.append({'original': line, 'replacement': None})
            continue
        assert not line.startswith('#SBATCH --nodelist=')
        replacement = next((v for k, v in replacements.items() if line.startswith(k)), line)
        if replacement != line:
            changed.append({'original': line, 'replacement': replacement})
        body.append(replacement)
    call = ('python -B -u hpc/replay_gradient_diagnostic_20261011.py'
            ' --source-root ' + spec['source_root'] +
            ' --diagnostic-root ' + spec['diagnostic_root'] +
            ' --run-id ' + spec['run_id'] +
            ' --expected-code-sha256 ' + spec['source_code_hash'] +
            ' --expected-checkpoint-sha256 ' + spec['source_run_files']['continuation.pt']['sha256'] +
            ' --expected-config-sha256 ' + spec['source_run_files']['config.json']['sha256'])
    body.append(call)
    encoded = ('\n'.join(body) + '\n').encode()
    script = ROOT / 'hpc/gradient_diagnostic.slurm'
    with script.open('xb') as f:
        f.write(encoded)
    assert next(x[3:] for x in body if x.startswith('cd ')) == str(ROOT)
    assert next(x.split('=', 1)[1] for x in body if x.startswith('#SBATCH --output=')) == str(ROOT / 'logs/%x_%j.out')
    assert str(source) not in '\n'.join(body[:-1])
    before = {'source_failure_sha256': spec['source_run_files']['failure.json']['sha256'],
              'source_job_queue': queued, 'source_job_accounting': accounting,
              'diagnostic_job_name_absent_from_queue': True}
    save('diagnostic_submission_attempt.json', {'status': 'reserved_no_retry',
         'script': str(script), 'script_sha256': hashlib.sha256(encoded).hexdigest(),
         'derived_from_pathfix': str(template), 'pathfix_sha256': spec['verified_pathfix_sha256'],
         'changes': changed, 'source_preconditions': before,
         'time_beijing': datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()})
    try:
        result = subprocess.run([XBATCH, str(script)], capture_output=True, text=True, timeout=60)
    except Exception as exc:
        save('diagnostic_submission_response.json', {'status': 'uncertain_inspect_without_resubmitting', 'error_type': type(exc).__name__, 'error': str(exc)})
        raise
    save('diagnostic_submission_response.json', {'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
    match = re.fullmatch(r'Submitted batch job ([0-9]+)\s*', result.stdout)
    if result.returncode or not match:
        raise RuntimeError('diagnostic submission uncertain; inspect exclusive response and scheduler, do not repeat')
    job = match.group(1)
    save('scheduler_jobs.json', {'gradient_diagnostic': job})
    print(json.dumps({'status': 'isolated_gradient_diagnostic_submitted', 'root': str(ROOT), 'job_id': job,
                      'script_sha256': hashlib.sha256(encoded).hexdigest(), 'script_base64': base64.b64encode(encoded).decode(),
                      'source_failed_job': spec['source_job'], 'formal_training_restarted': False,
                      'evaluation_values_read': False}), flush=True)


if __name__ == '__main__':
    main()
