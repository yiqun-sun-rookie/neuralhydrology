"""Authenticated source helpers derived from the archived isolated gradient diagnostic.
Only admission and snapshot helpers are retained. No old replay, scale trial or submission is retained.
"""
import argparse,copy,hashlib,importlib,json,math,random,sys,time
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import torch

def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write_exclusive(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def tensor_summary(value):
    if value is None:
        return {'missing': True, 'finite': False}
    detached = value.detach()
    finite = torch.isfinite(detached)
    good = detached[finite]
    return {'missing': False, 'finite': bool(finite.all()),
            'dtype': str(detached.dtype), 'shape': list(detached.shape),
            'element_count': detached.numel(), 'zero_count': int((detached == 0).sum()),
            'finite_nonzero_count': int((finite & (detached != 0)).sum()),
            'nan_count': int(torch.isnan(detached).sum()),
            'positive_inf_count': int(torch.isposinf(detached).sum()),
            'negative_inf_count': int(torch.isneginf(detached).sum()),
            'maximum_finite_absolute': float(good.abs().max()) if good.numel() else None}


def assert_finite_tree(value, path='state'):
    if isinstance(value, torch.Tensor):
        require(bool(torch.isfinite(value).all()), 'nonfinite tensor: ' + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            assert_finite_tree(item, path + '/' + str(key))
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            assert_finite_tree(item, path + '/' + str(index))
    elif isinstance(value, (float, np.floating)):
        require(math.isfinite(float(value)), 'nonfinite number: ' + path)


def cpu_tree(value):
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().clone()
    if isinstance(value, dict):
        return {key: cpu_tree(item) for key, item in value.items()}
    if isinstance(value, list):
        return [cpu_tree(item) for item in value]
    if isinstance(value, tuple):
        return tuple(cpu_tree(item) for item in value)
    return copy.deepcopy(value)


def capture_rng():
    return {'python': random.getstate(), 'numpy': np.random.get_state(),
            'torch_cpu': torch.get_rng_state().clone(),
            'torch_cuda': [state.clone() for state in torch.cuda.get_rng_state_all()]
            if torch.cuda.is_available() else []}


def named_trainable(session, api):
    named = []; seen = set()
    for name in ('initializer', 'encoder', 'process', 'readout'):
        module = getattr(session.parts, name)
        if module is not None:
            for key, parameter in module.named_parameters():
                if parameter.requires_grad and id(parameter) not in seen:
                    named.append((name + '.' + key, parameter)); seen.add(id(parameter))
    if session.noise is not None:
        for name in ('raw_q', 'raw_r', 'raw_p0'):
            parameter = getattr(session.noise, name)
            if parameter.requires_grad and id(parameter) not in seen:
                named.append(('noise.' + name, parameter)); seen.add(id(parameter))
    require([id(p) for _, p in named] ==
            [id(p) for p in api.models.parameters(session.parts, session.noise, True)],
            'diagnostic named parameter order differs from original optimizer order')
    return named


def capture_start(session, api):
    return {'model': api.training.snapshot_parts(session.parts, session.noise),
            'optimizer': cpu_tree(session.optimizer.state_dict()), 'rng': capture_rng()}


def import_source(root, expected_code):
    require(not any(name == 'src' or name.startswith('src.') for name in sys.modules),
            'source modules already imported; start a fresh Python process')
    sys.path.insert(0, str(root))
    modules = {key: importlib.import_module('src.' + value) for key, value in
               {'runtime': 'runtime', 'scheduler': 'scheduler', 'training': 'training',
                'models': 'models', 'contracts': 'contracts', 'filter': 'differentiable_filter',
                'execution': 'execution'}.items()}
    for module in modules.values():
        require(root in Path(module.__file__).resolve().parents, 'import escaped source release')
    api = SimpleNamespace(**modules)
    require(api.scheduler.code_identity(root) == expected_code == api.scheduler.code_identity(),
            'source implementation SHA256 differs from expected identity')
    return api


def validate_metadata(root, run_id, args, api):
    run_dir = root / 'runs' / run_id
    for path in (run_dir, run_dir / 'config.json', run_dir / 'continuation.pt', run_dir / 'failure.json'):
        require(root in path.resolve(strict=True).parents, 'source run path escapes source root')
    config_path = run_dir / 'config.json'
    require(sha256_file(config_path) == args.expected_config_sha256, 'frozen source configuration SHA256 differs')
    config = read_json(config_path); effective = config['effective_config']; run = config['registration']
    require(run['exp_id'] == run_id and run['type'] == 'tune_branch' and run['method'] == 'filter_joint',
            'diagnostic must target the registered failed tuning filter_joint member')
    require(run['case'] == 'explicit_gru__historical_capacity' and run['seed'] == 101 and
            effective['learning_rate'] == .003 and run['train_years'] == [2017, 2018, 2019, 2020],
            'target architecture, seed, rate or training years differ')
    protocol_path = root / 'configs/protocol-v3.json'
    protocol = read_json(protocol_path); auth = read_json(root / 'records/authorization.json')
    protocol_sha = sha256_file(protocol_path)
    require(config['status'] == 'frozen_authorized' and config['protocol_sha256'] ==
            auth['protocol_sha256'] == protocol_sha, 'configuration/protocol/authorization binding differs')
    require(auth['code_hash'] == effective['code_hash'] == args.expected_code_sha256,
            'authorization or frozen code identity differs')
    require(auth['authority'].get('formal_training') and auth['authority'].get('technical_recovery') and
            not auth['authority'].get('evaluation_year_reads') and not auth.get('evaluation_year_reads', False),
            'source authority missing or evaluation-read boundary changed')
    registry = read_json(root / 'configs/registry-v3.json'); api.scheduler.validate_registry(registry, protocol)
    registered = [r for r in registry['runs'] if r['exp_id'] == run_id]
    require(registered == [run], 'frozen registration differs from source registry')
    group_configs = read_json(root / 'records' / run['case'] / 'tune_branch_group_configs.json')
    require(group_configs.get(run_id) == config, 'run differs from frozen whole-group configuration')
    prep = read_json(root / 'records/data_preparation_complete.json')
    require(prep.get('status') == 'admitted' and prep.get('code_hash') == args.expected_code_sha256,
            'prepared data not admitted to source implementation')
    manifest = read_json(root / 'prepared/tuning/manifest.json')
    require(manifest.get('status') == 'admitted' and not manifest.get('evaluation_year_reads', False),
            'tuning manifest admission or evaluation-read boundary changed')
    require(api.scheduler.digest_json(manifest) == effective['training_data_hash'] and
            manifest['tide_source_hash'] == effective['tide_source_hash'], 'frozen data/tide manifest identity differs')
    entries = [e for e in manifest['files'] if 'tuning_train' in e.get('phases', [])]
    require(entries and all(e['role'] in ('realtime_inputs', 'qc_labels', 'astronomical_tide') and
                            set(e['years']).issubset({2017, 2018, 2019, 2020}) for e in entries),
            'tuning training entry includes forbidden role or years')
    selected=[e for e in manifest['files'] if 'tuning_select' in e.get('phases',[])]
    require(run['selection_years']==[2021] and selected and all(set(e['years'])=={2021} for e in selected), 'diagnostic selection boundary differs')
    outcome_path = root / 'records' / run['case'] / 'tune_foundation_group_outcome.json'
    outcome = read_json(outcome_path); seal_record = outcome['seal']
    require(len(outcome['members']) == 3 and seal_record['epochs'] == 400, 'complete 3-member 400-epoch parent group required')
    checked = api.scheduler.seal_group(run['case'] + '__tune_foundation_group__seal', outcome['members'],
                                       400, expected_members=list(outcome['members']))
    from dataclasses import asdict
    normalized_seal = dict(seal_record, member_ids=tuple(seal_record['member_ids']))
    require(asdict(checked) == normalized_seal, 'complete saved parent seal differs from reconstructed evidence')
    seals = {checked.group_id: checked}; api.scheduler.verify_parent_binding(run, effective, seals)
    for member in outcome['members'].values():
        require(sha256_file(member['checkpoint_path']) == member['checkpoint_sha256'], 'complete parent weight bytes differ')
    failure = read_json(run_dir / 'failure.json')
    require(failure.get('status') == 'failed' and failure.get('epochs_completed') == 44 and
            failure.get('reason') == 'invalid covariance' and failure.get('evidence',{}).get('shape') == [16,128,128], 'expected 44-epoch covariance source failure differs')
    checkpoint_path = run_dir / 'continuation.pt'
    require(sha256_file(checkpoint_path) == args.expected_checkpoint_sha256, 'source continuation SHA256 differs')
    pinned = {str(path): sha256_file(path) for path in
              (config_path, checkpoint_path, run_dir / 'failure.json', run_dir / 'metrics.json',
               protocol_path, root / 'configs/registry-v3.json', Path(effective['parent_checkpoint']),
               root / 'records/authorization.json', root / 'records/data_preparation_complete.json',
               root / 'prepared/tuning/manifest.json', outcome_path,
               root / 'records' / run['case'] / 'tune_branch_group_configs.json')}
    for member in outcome['members'].values():
        pinned[member['checkpoint_path']] = member['checkpoint_sha256']
    return run, config, protocol, manifest, seals, pinned


def validate_spec(spec, source, deployed, args):
    require(spec.get('schema') == 'isolated_validation_covariance_diagnostic_spec_v1' and
            spec.get('source_root') == str(source) and spec.get('diagnostic_root') == str(deployed) and
            spec.get('run_id') == args.run_id and spec.get('source_code_hash') == args.expected_code_sha256,
            'deployed diagnostic specification differs from exact invocation')
    require(spec.get('in_memory_optimizer_replay_allowed') is True and
            spec.get('formal_checkpoint_write_allowed') is False and
            spec.get('scientific_rules_changed') is False and spec.get('evaluation_values_read') is False and
            spec.get('admitted_training_phase') == 'tuning_train' and
            spec.get('admitted_selection_phase') == 'tuning_select' and spec.get('selection_years') == [2021] and
            spec.get('training_years') == [2017, 2018, 2019, 2020] and
            spec.get('expected_saved_epoch') == 44 and spec.get('replayed_epoch') == 45,
            'deployed diagnostic scope or permitted writes differs')
    files = sorted([*source.joinpath('src').glob('*.py'), *source.joinpath('scripts').glob('*.py'),
                    *source.joinpath('vendor/pytides').glob('*.py')])
    actual = {p.relative_to(source).as_posix(): sha256_file(p) for p in files}
    require(actual == spec.get('source_code_file_hashes'), 'source per-file identity differs from probe')
    expected = spec['source_run_files']
    require(set(expected) == {'config.json', 'continuation.pt', 'failure.json', 'metrics.json'},
            'diagnostic specification must bind all four source run files')
    require(expected['config.json']['sha256'] == args.expected_config_sha256 and
            expected['continuation.pt']['sha256'] == args.expected_checkpoint_sha256,
            'CLI checkpoint/config identities differ from diagnostic specification')
    for name, identity in expected.items():
        path = source / 'runs' / args.run_id / name
        require(source in path.resolve(strict=True).parents and path.stat().st_size == identity['bytes'] and
                sha256_file(path) == identity['sha256'], 'source run probe identity differs: ' + name)


def validate_checkpoint(state, config_sha, metrics, expected_epochs=44):
    require(set(state) == {'current', 'optimizer', 'best', 'values', 'train_metrics', 'shuffle_hashes', 'config_sha256'},
            'continuation fields differ; review new state format before replay')
    require(state['config_sha256'] == config_sha, 'continuation does not bind exact source config bytes')
    require(all(len(state[key]) == expected_epochs for key in ('values', 'train_metrics', 'shuffle_hashes')),
            'continuation is not the required complete 44-epoch state')
    require(state['best'] is not None and all(math.isfinite(x) and x >= 0 for x in state['values']),
            'best state or finite complete validation history missing')
    require(metrics.get('validation_mae_cm') == state['values'] and
            metrics.get('train_metrics') == state['train_metrics'] and
            metrics.get('shuffle_hashes') == state['shuffle_hashes'], 'source metrics and checkpoint histories differ')
    require(all(isinstance(x, str) and len(x) == 64 for x in state['shuffle_hashes']), 'invalid shuffle identity history')
    assert_finite_tree(state)


def validate_adam(session, api, expected_steps):
    named = named_trainable(session, api); optimizer = session.optimizer
    require(len(optimizer.param_groups) == 1 and
            [id(p) for p in optimizer.param_groups[0]['params']] == [id(p) for _, p in named],
            'Adam parameter identity/order differs')
    group = optimizer.param_groups[0]
    require(group['lr'] == .003 and tuple(group['betas']) == (.9, .999) and group['eps'] == 1e-8 and
            group['weight_decay'] == 0 and not group.get('amsgrad', False) and not group.get('maximize', False),
            'Adam settings differ from frozen original rule')
    require(len(optimizer.state) == len(named), 'Adam state missing trainable parameter')
    for name, parameter in named:
        state = optimizer.state[parameter]
        require(set(state) == {'step', 'exp_avg', 'exp_avg_sq'}, 'Adam state fields differ: ' + name)
        require(float(state['step']) == expected_steps and state['exp_avg'].shape == parameter.shape and
                state['exp_avg_sq'].shape == parameter.shape and bool((state['exp_avg_sq'] >= 0).all()),
                'Adam step, moment shape or variance differs: ' + name)
    assert_finite_tree(optimizer.state_dict(), 'Adam')


def prepare_new_root(source, diagnostic):
    source = Path(source).resolve(strict=True)
    diagnostic = Path(diagnostic).resolve()
    require(source != diagnostic and source not in diagnostic.parents and diagnostic not in source.parents,
            'diagnostic directory overlaps source release')
    require(diagnostic.is_dir() and (diagnostic / 'diagnostic_spec.json').is_file(),
            'isolated diagnostic package and specification must already be deployed')
    evidence = diagnostic / 'evidence'
    evidence.mkdir(exist_ok=False)
    require(diagnostic in evidence.resolve().parents, 'diagnostic evidence path escaped deployed root')
    return source, evidence


class EventLog:
    def __init__(self, root):
        self.stream = (root / 'events.jsonl').open('x', encoding='utf-8')

    def emit(self, event):
        event = dict(event, emitted_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
        line = json.dumps(event, sort_keys=True, allow_nan=False)
        self.stream.write(line + '\n'); self.stream.flush()
        print(line, flush=True)

    def close(self):
        self.stream.close()
