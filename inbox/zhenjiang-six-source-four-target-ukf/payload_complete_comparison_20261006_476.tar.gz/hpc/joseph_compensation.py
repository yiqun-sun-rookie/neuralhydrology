"""Diagnostic evaluation of the original dense Joseph products in float64.

Retain product and sum residuals until the final float64 rounding. This module
does not change the covariance formula, gain, noise, dtype or jitter policy.
"""
import torch


def two_sum(a,b):
    total=a+b
    recovered_b=total-a
    return total,(a-(total-recovered_b))+(b-recovered_b)


def product_with_error(a,b):
    splitter=134217729.0
    split_a,split_b=splitter*a,splitter*b
    high_a=split_a-(split_a-a)
    high_b=split_b-(split_b-b)
    low_a,low_b=a-high_a,b-high_b
    product=a*b
    error=((high_a*high_b-product)+high_a*low_b+low_a*high_b)+low_a*low_b
    return product,error


def dd_add(a,al,b,bl):
    high,error=two_sum(a,b)
    return two_sum(high,(al+bl)+error)


def dd_matmul(a,b,al=None,bl=None):
    assert a.dtype==b.dtype==torch.float64
    high,low=product_with_error(a[..., :, :, None],b[..., None, :, :])
    if al is not None:low=low+al[..., :, :, None]*b[..., None, :, :]
    if bl is not None:low=low+a[..., :, :, None]*bl[..., None, :, :]
    if al is not None and bl is not None:low=low+al[..., :, :, None]*bl[..., None, :, :]
    while high.shape[-2]>1:
        if high.shape[-2]%2:
            high=torch.cat((high,torch.zeros_like(high[..., :1, :])),dim=-2)
            low=torch.cat((low,torch.zeros_like(low[..., :1, :])),dim=-2)
        high,low=dd_add(high[..., 0::2, :],low[..., 0::2, :],
                       high[..., 1::2, :],low[..., 1::2, :])
    return high.squeeze(-2),low.squeeze(-2)


def compensated_joseph(complement,covariance,gain,noise):
    """Evaluate A P A.T + K R K.T, carrying float64 residuals."""
    assert all(x.dtype==torch.float64 and bool(torch.isfinite(x).all())
               for x in (complement,covariance,gain,noise))
    left,left_low=dd_matmul(complement,covariance)
    first,first_low=dd_matmul(left,complement.transpose(-1,-2),al=left_low)
    right,right_low=dd_matmul(gain,noise)
    second,second_low=dd_matmul(right,gain.transpose(-1,-2),al=right_low)
    high,low=dd_add(first,first_low,second,second_low)
    high,low=dd_add(high,low,high.transpose(-1,-2),low.transpose(-1,-2))
    rounded=high*.5+low*.5
    assert bool(torch.isfinite(rounded).all())
    return rounded


def repair_rejected_members(p,complement,covariance,gain,noise,stable_cholesky):
    """Keep every accepted member bitwise; recompute only rejected Joseph sums."""
    values=[];changed=[]
    for i in range(p.shape[0]):
        try:stable_cholesky(p[i:i+1])
        except Exception as error:
            if type(error).__name__!='FilterFailure':raise
            candidate=compensated_joseph(complement[i:i+1],covariance[i:i+1],gain[i:i+1],noise[i:i+1])
            stable_cholesky(candidate)
            values.append(candidate);changed.append(i)
        else:values.append(p[i:i+1])
    assert changed,'original rejected covariance must have a rejected member'
    return torch.cat(values),changed
