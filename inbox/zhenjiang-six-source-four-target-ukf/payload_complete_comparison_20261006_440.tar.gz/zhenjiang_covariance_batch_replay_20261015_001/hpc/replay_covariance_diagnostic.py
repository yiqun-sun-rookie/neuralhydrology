"""One authenticated failed batch: original control and conditional F64 candidate.

Restore the saved batch-start model, Adam and RNG. Read 2017--2020 training
only. Reuse the original loss, gradient recovery, clipping and Adam. The
candidate changes only roundoff evaluation after the original permitted-jitter
Cholesky failure. Save all evidence in this new diagnostic directory; zero
formal epochs and at most one in-memory optimizer update.
"""
import argparse
import datetime
import importlib.util
import json
from pathlib import Path
import random
import traceback

import numpy as np
import torch

import authenticated_source_helpers as h

ROOT = Path(__file__).resolve().parents[1]


def now():
    return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()


def tensor_hash(tensor):
    import hashlib
    return hashlib.sha256(tensor.detach().cpu().contiguous().numpy().tobytes()).hexdigest()


def tensor_save(path, value):
    value = h.cpu_tree(value)
    if isinstance(value, dict) and 'rng' in value:
        n = value['rng']['numpy']
        value['rng']['numpy'] = (n[0], n[1].tolist() if hasattr(n[1], 'tolist') else n[1], *n[2:])
    with path.open('xb') as stream:
        torch.save(value, stream)
    return {'path': str(path), 'sha256': h.sha256_file(path), 'bytes': path.stat().st_size}


def tree_equal(a, b):
    if isinstance(a, torch.Tensor):
        return isinstance(b, torch.Tensor) and torch.equal(a.cpu(), b.cpu())
    if isinstance(a, dict):
        return isinstance(b, dict) and a.keys() == b.keys() and all(tree_equal(a[k], b[k]) for k in a)
    if isinstance(a, (list, tuple)):
        return isinstance(b, (list, tuple)) and len(a) == len(b) and all(tree_equal(x, y) for x, y in zip(a, b))
    return a == b


def restore_start(session, api, start):
    api.training.restore_parts(session.parts, start['model'], session.noise)
    session.optimizer.load_state_dict(start['optimizer'])
    random.setstate(start['rng']['python'])
    n = start['rng']['numpy']
    np.random.set_state((n[0], np.asarray(n[1], dtype=np.uint32), *n[2:]))
    torch.set_rng_state(start['rng']['torch_cpu'])
    if start['rng']['torch_cuda']:
        torch.cuda.set_rng_state_all(start['rng']['torch_cuda'])
    h.require(tree_equal(api.training.snapshot_parts(session.parts, session.noise), start['model']),
              'restored model differs from authenticated batch start')
    h.require(tree_equal(h.cpu_tree(session.optimizer.state_dict()), start['optimizer']),
              'restored Adam differs from authenticated batch start')
    h.validate_adam(session, api, 6761)


class ReplayTrace:
    def __init__(self, api, reference, accurate_function, candidate=False):
        self.api, self.reference, self.accurate = api, reference, accurate_function
        self.candidate = candidate
        self.context = {}
        self.prefix, self.recoveries, self.patches = [], [], []
        self.moments, self.failure = None, None

    def patch(self, module, name, replacement):
        self.patches.append((module, name, getattr(module, name)))
        setattr(module, name, replacement)

    def install(self):
        f = self.api.filter
        original_slice, original_predict = self.api.training.slice_batch, f.unscented_predict
        original_moments, original_cholesky = f.unscented_moments, f.stable_cholesky

        def slice_batch(batch, selection):
            self.context = {'microbatch_start': selection.start, 'microbatch_stop': selection.stop,
                            'analysis_step': 0}
            return original_slice(batch, selection)

        def moments(points, wm, wc):
            output = original_moments(points, wm, wc)
            self.moments = (points, wm, wc, output[0])
            return output

        def cholesky(p, ledger=None):
            try:
                return original_cholesky(p, ledger)
            except f.FilterFailure as error:
                if self.failure is None:
                    self.failure = {'context': dict(self.context), 'reason': str(error),
                                    'evidence': error.evidence,
                                    'equal_saved_original_covariance': torch.equal(
                                        p.detach().cpu(), self.reference['original_input_covariance'])}
                raise

        def candidate_predict(parts, mean, covariance, control, whitening, noise, ledger=None):
            # These are the unchanged original operations, in their original order.
            points, wm, wc = f.unscented_points(mean, covariance, ledger)
            b, n, d = points.shape
            physical = points * whitening.scale + whitening.mean
            propagated = parts.process(physical.reshape(b*n, d).to(torch.float32),
                                       control[:, None].expand(b, n, 3).reshape(b*n, 3).to(torch.float32))
            whitened = (propagated.reshape(b, n, d).to(torch.float64) - whitening.mean) / whitening.scale
            predicted, p = f.unscented_moments(whitened, wm, wc)
            q, _, _ = f.noise_variances(noise)
            p = f.symmetric(p + torch.diag(q)[None])
            try:
                original_cholesky(p, ledger)
            except f.FilterFailure as error:
                if str(error) != 'covariance not positive definite after permitted jitter':
                    raise
                h.require(bool((wc >= 0).all()) and bool((q > 0).all()), 'positive original operands required')
                differences = whitened - predicted[:, None]
                with torch.no_grad():
                    accurate = self.accurate(differences, wc, q)
                updated = p + (accurate - p).detach()
                h.require(torch.equal(updated.detach(), accurate), 'compensated dense value differs')
                if not self.recoveries:
                    expected = self.reference['context']
                    h.require(all(self.context[k] == expected[k] for k in self.context), 'original failure context differs')
                    h.require(torch.equal(p.detach().cpu(), self.reference['original_input_covariance']),
                              'original failure covariance bytes differ')
                    h.require(torch.equal(whitened.detach().cpu(), self.reference['moments']['points']) and
                              torch.equal(predicted.detach().cpu(), self.reference['moments']['mean']),
                              'original failure points or mean differ')
                original_cholesky(updated, ledger)
                self.recoveries.append({'context': dict(self.context), 'original_evidence': error.evidence,
                                        'candidate_dtype': str(updated.dtype), 'jitter_policy': list(f.JITTERS),
                                        'max_absolute_roundoff_correction': float((updated.detach()-p.detach()).abs().max())})
                p = updated
            return predicted, p

        def predict(*args, **kwargs):
            self.context['analysis_step'] += 1
            result = (candidate_predict if self.candidate else original_predict)(*args, **kwargs)
            if not self.recoveries:
                self.prefix.append({'context': dict(self.context), 'mean_sha256': tensor_hash(result[0]),
                                    'covariance_sha256': tensor_hash(result[1])})
            return result

        self.patch(self.api.training, 'slice_batch', slice_batch)
        self.patch(f, 'unscented_moments', moments)
        if not self.candidate:
            self.patch(f, 'stable_cholesky', cholesky)
        self.patch(f, 'unscented_predict', predict)

    def remove(self):
        for module, name, original in reversed(self.patches):
            setattr(module, name, original)
        self.patches.clear()


def execute(args):
    source, evidence = h.prepare_new_root(args.source_root, args.diagnostic_root)
    spec = h.read_json(ROOT / 'diagnostic_spec.json')
    result = {'status': 'isolated_covariance_batch_replay_started', 'checked_at_beijing': now(),
              'diagnostic_root': str(ROOT), 'source_root': str(source), 'run_id': args.run_id,
              'formal_training_epochs_added': 0, 'formal_training_restarted': False,
              'scientific_rules_changed': False, 'evaluation_values_read': False,
              'selection_input_values_read': False, 'validation_input_values_read': False,
              'in_memory_optimizer_updates': 0, 'automatic_formal_recovery_admitted': False}
    api, session, trace, pinned = None, None, None, dict(spec['pinned_files'])
    exit_code = 1
    try:
        h.require(spec['maximum_in_memory_optimizer_updates'] == 1 and spec['maximum_effective_batches'] == 1,
                  'one-batch diagnostic scope differs')
        h.require(all(h.sha256_file(path) == sha for path, sha in pinned.items()), 'pinned source bytes differ')
        h.validate_spec(spec, source, ROOT, args)
        api = h.import_source(source, args.expected_code_sha256)
        run, config, protocol, manifest, seals, metadata_pinned = h.validate_metadata(source, args.run_id, args, api)
        pinned.update(metadata_pinned)
        device = api.execution.device_identity(config['effective_config']['device'])
        h.require(device == spec['expected_device_identity'], 'GPU differs')
        api.training.deterministic_runtime()
        torch.set_num_threads(4)
        checkpoint = torch.load(source/'runs'/args.run_id/'continuation.pt', map_location='cpu', weights_only=True)
        h.validate_checkpoint(checkpoint, args.expected_config_sha256, h.read_json(source/'runs'/args.run_id/'metrics.json'), 44)
        h.require(sum(len(x) for x in checkpoint['train_metrics']) == 6752, 'source complete Adam budget differs')
        stage = api.runtime.load_stage(manifest, 'tuning_train')
        stats = api.runtime.fit_stage_stats(stage, manifest)
        h.require(api.scheduler.digest_json(api.runtime.stats_record(stats)) == config['effective_config']['normalization_hash'],
                  'normalization differs')
        windows, issue_times = api.runtime.prepare_windows(stage, stats)
        for epoch in range(1, 45):
            ordered, sha = api.training.epoch_indices(issue_times, run['seed'], epoch)
            h.require(sha == checkpoint['shuffle_hashes'][epoch-1] and
                      len(checkpoint['train_metrics'][epoch-1]) == (len(ordered)+15)//16, 'saved complete order differs')
        ordered, shuffle_sha = api.training.epoch_indices(issue_times, run['seed'], 45)
        indices = ordered[144:160]
        h.require(indices.tolist() == spec['window_indices'], 'original failed effective batch indices differ')
        session = api.runtime.build_session(run, config, protocol, stats, evidence/'scratch_session', seals)
        h.require(session.micro_batch == 2 and session.method == 'filter_joint', 'original batch method differs')
        start = torch.load(spec['batch_start_path'], map_location='cpu', weights_only=True)
        reference = torch.load(spec['operands_path'], map_location='cpu', weights_only=True)
        h.require(reference['context'] == spec['failure_context'], 'saved failure identity differs')
        batch = api.execution.move_batch(api.contracts.combine_batches([windows[int(i)] for i in indices]), session.device)
        candidate_spec = importlib.util.spec_from_file_location('authenticated_compensated_arithmetic', spec['arithmetic_program'])
        arithmetic = importlib.util.module_from_spec(candidate_spec)
        candidate_spec.loader.exec_module(arithmetic)
        restore_start(session, api, start)
        trace = ReplayTrace(api, reference, arithmetic.compensated_dense)
        trace.install()
        try:
            api.training.train_effective_batch(session.parts, session.noise, session.whitening,
                session.method, batch, session.stats, session.optimizer, session.micro_batch)
            raise ValueError('original failed batch unexpectedly succeeded')
        except api.filter.FilterFailure as error:
            h.require(str(error) == 'covariance not positive definite after permitted jitter', 'original error differs')
            h.require(trace.failure and trace.failure['equal_saved_original_covariance'] and
                      error.evidence == reference['original_error_evidence'], 'original stored error did not reproduce')
        finally:
            trace.remove()
        control = trace
        h.validate_adam(session, api, 6761)
        result.update(original_control_failure=control.failure, original_control_successful_predicts=len(control.prefix),
                      all_44_history_and_shuffle_prefixes_verified=True, source_complete_epochs=44,
                      source_complete_optimizer_steps=6752, batch_start_optimizer_steps=6761,
                      historical_continuation_rng_equality_established=False,
                      saved_diagnostic_batch_rng_restored=True, device_identity=device,
                      replayed_epoch=45, effective_batch_index=10, window_indices=indices.tolist(),
                      training_input_values_read=True, shuffle_sha256=shuffle_sha)
        restore_start(session, api, start)
        trace = ReplayTrace(api, reference, arithmetic.compensated_dense, candidate=True)
        trace.install()
        metric = api.training.train_effective_batch(session.parts, session.noise, session.whitening,
            session.method, batch, session.stats, session.optimizer, session.micro_batch)
        h.require(trace.prefix == control.prefix, 'ordinary path outputs changed before first covariance recovery')
        h.require(trace.recoveries, 'candidate did not reach the original failure')
        h.validate_adam(session, api, 6762)
        named = h.named_trainable(session, api)
        gradients = {name: h.tensor_summary(p.grad) for name, p in named}
        h.require(all(row['finite'] and not row['missing'] for row in gradients.values()), 'candidate gradients not finite')
        after = h.capture_start(session, api)
        h.assert_finite_tree(after['model']); h.assert_finite_tree(after['optimizer'])
        result.update(status='isolated_covariance_batch_replay_candidate_passed', candidate_metric=metric,
                      ordinary_path_bitwise_unchanged_before_first_recovery=True,
                      candidate_covariance_recoveries=trace.recoveries, gradient_summaries=gradients,
                      all_trainable_gradients_finite=True, final_in_memory_optimizer_steps=6762,
                      in_memory_optimizer_updates=1, model_parameters_advanced=not tree_equal(after['model'], start['model']),
                      optimizer_state_advanced=not tree_equal(after['optimizer'], start['optimizer']))
        h.require(result['model_parameters_advanced'] and result['optimizer_state_advanced'], 'candidate model or Adam did not advance')
        result['candidate_gradients'] = tensor_save(evidence/'candidate_gradients.pt',
                                                    {name: p.grad for name, p in named})
        result['candidate_after_batch'] = tensor_save(evidence/'candidate_after_batch_model_adam_rng.pt', after)
        exit_code = 0
    except Exception as error:
        result.update(status='isolated_covariance_batch_replay_failed', exception_type=type(error).__name__,
                      reason=str(error), traceback=traceback.format_exc(), candidate_context=dict(trace.context) if trace else None)
        if trace and trace.candidate:
            result['candidate_covariance_recoveries'] = trace.recoveries
        if session and api:
            result['failed_candidate_state'] = tensor_save(evidence/'failed_candidate_model_adam_rng.pt', h.capture_start(session, api))
    finally:
        if trace:
            trace.remove()
        unchanged = {path: h.sha256_file(path) == sha for path, sha in pinned.items()}
        result.update(source_file_unchanged_checks=unchanged, source_bytes_unchanged=bool(pinned) and all(unchanged.values()),
                      source_code_unchanged=api is not None and api.scheduler.code_identity(source) == args.expected_code_sha256,
                      source_code_sha256=args.expected_code_sha256, finished_at_beijing=now())
        if not result['source_bytes_unchanged'] or not result['source_code_unchanged']:
            exit_code = 1
        result['exit_code'] = exit_code
        h.write_exclusive(evidence/'diagnostic_result.json', result)
        print(json.dumps({'status': result['status'], 'formal_training_epochs_added': 0, 'exit_code': exit_code}), flush=True)
    return exit_code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('source-root', 'diagnostic-root', 'run-id', 'expected-code-sha256', 'expected-config-sha256', 'expected-checkpoint-sha256'):
        parser.add_argument('--'+name, required=True)
    return execute(parser.parse_args())


if __name__ == '__main__':
    raise SystemExit(main())
