"""Audit compensated float64 evaluation of the original weighted covariance.

Run only on the authenticated saved operands, with zero model/optimizer steps.
The mean, weights, noise and final dense float64 representation stay fixed.
Higher precision is used only to compare with the saved diagnostic reference.
No candidate is admitted to formal training by this diagnostic.
"""
import hashlib
import importlib.util
import json
from pathlib import Path

import mpmath as mp
import torch

ROOT = Path(__file__).resolve().parents[1]


def two_sum(a, b):
    total = a + b
    recovered_b = total - a
    error = (a - (total - recovered_b)) + (b - recovered_b)
    return total, error


def product_with_error(a, b):
    splitter = 134217729.0
    split_a, split_b = splitter * a, splitter * b
    high_a = split_a - (split_a - a)
    high_b = split_b - (split_b - b)
    low_a, low_b = a - high_a, b - high_b
    product = a * b
    error = ((high_a * high_b - product) + high_a * low_b + low_a * high_b) + low_a * low_b
    return product, error


def compensated_dense(differences, weights, q):
    """Compute the same positive weighted outer products using float64 only."""
    assert differences.dtype == weights.dtype == q.dtype == torch.float64
    # The frozen weights are powers of two, so their multiplication is exact
    # for these authenticated finite, normal-range saved operands.
    assert weights[0] == 2 and bool((weights[1:] == 1 / 256).all())
    high, low = product_with_error(differences[:, :, :, None], differences[:, :, None, :])
    high, low = high * weights[None, :, None, None], low * weights[None, :, None, None]
    while high.shape[1] > 1:
        if high.shape[1] % 2:
            high = torch.cat((high, torch.zeros_like(high[:, :1])), dim=1)
            low = torch.cat((low, torch.zeros_like(low[:, :1])), dim=1)
        added, residue = two_sum(high[:, 0::2], high[:, 1::2])
        high, low = two_sum(added, (low[:, 0::2] + low[:, 1::2]) + residue)
    high, residue = two_sum(high[:, 0], torch.diag(q)[None])
    high, low = two_sum(high, low[:, 0] + residue)
    rounded = high + low
    # Mirror a single triangle, avoiding a further rounding of equal entries.
    return torch.tril(rounded) + torch.tril(rounded, -1).transpose(-1, -2)


def main():
    spec = json.loads((ROOT / 'audit_spec.json').read_text())
    assert str(ROOT) == spec['audit_root'] and spec['model_steps_allowed'] == 0
    helper_path = Path(spec['source_arithmetic_helper'])
    assert hashlib.sha256(helper_path.read_bytes()).hexdigest() == spec['source_arithmetic_helper_sha256']
    module_spec = importlib.util.spec_from_file_location('authenticated_helpers', helper_path)
    h = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(h)
    pinned = dict(spec['pinned_files'])
    assert all(h.sha(path) == expected for path, expected in pinned.items())
    evidence = ROOT / 'evidence'
    evidence.mkdir(exist_ok=False)
    props = torch.cuda.get_device_properties(0)
    device = {'device': 'cuda:0', 'name': props.name, 'total_memory_bytes': props.total_memory}
    assert device == spec['expected_device_identity']
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    operands = torch.load(spec['operands_path'], map_location='cpu', weights_only=True)
    assert operands['context'] == spec['failure_context']
    assert operands['original_jitters'] == spec['permitted_jitters']
    moments = operands['moments']
    differences = (moments['points'] - moments['mean'][:, None]).cuda().requires_grad_()
    weights = moments['wc'].cuda()
    q = operands['noise_variances'][0].cuda().requires_grad_()
    assert differences.shape == (2, 257, 128) and bool((q > 0).all())
    nominal = torch.einsum('p,bpi,bpj->bij', weights, differences, differences)
    nominal = (nominal + nominal.transpose(-1, -2)) * .5
    nominal = nominal + torch.diag(q)[None]
    assert torch.equal(nominal.detach(), operands['original_input_covariance'].cuda())
    with torch.no_grad():
        accurate = compensated_dense(differences, weights, q)
    # The compensation consists of algebraically zero roundoff residuals.
    # Retain the exact original weighted-covariance derivative, without
    # differentiating the cancellation-prone splitter implementation.
    candidate = nominal + (accurate - nominal).detach()
    assert torch.equal(candidate.detach(), accurate)
    candidate.retain_grad()
    lower, info = torch.linalg.cholesky_ex(candidate)
    result = {'status': 'saved_covariance_matrix_audit_complete',
              'audit_kind': 'compensated_float64_dense_original_covariance',
              'checked_at_beijing': h.now(), 'device_identity': device,
              'failure_context': operands['context'], 'model_steps': 0,
              'optimizer_updates': 0, 'formal_training_epochs_added': 0,
              'training_inputs_read': False, 'evaluation_values_read': False,
              'scientific_rules_changed': False, 'automatic_technical_repair_admitted': False,
              'final_covariance_dtype': str(candidate.dtype), 'jitter_used': 0.,
              'eigenvalue_clipping_used': False, 'final_covariance_representation': 'dense_float64',
              'original_q_weights_and_mean_unchanged': True,
              'compensated_cholesky_info': info.cpu().tolist(),
              'nominal_to_compensated_max_abs_change': float((accurate - nominal.detach()).abs().max())}
    decimal_path = Path(spec['reconstructed_decimal_path'])
    assert h.sha(decimal_path) == spec['reconstructed_decimal_sha256']
    decimal = json.loads(decimal_path.read_text())
    nearest = torch.tensor([[float(x) for x in row] for row in decimal['covariance']],
                           dtype=torch.float64, device='cuda')
    result['failing_member_equal_nearest_reference'] = torch.equal(accurate[1], nearest)
    result['failing_member_unequal_reference_entries'] = int((accurate[1] != nearest).sum())
    result['failing_member_max_abs_reference_error'] = float((accurate[1] - nearest).abs().max())
    with mp.workdps(120):
        reference = mp.matrix([[mp.mpf(x) for x in row] for row in decimal['covariance']])
        result['compensated_stored_matrix_certificate'] = h.cholesky_certificate(h.matrix(accurate[1]))
        result['failing_member_relative_covariance_max_error'] = str(
            max(abs(x) for x in (h.matrix(accurate[1]) - reference)) / max(abs(x) for x in reference))
    if bool((info == 0).all()):
        logdet = 2 * lower.diagonal(dim1=-2, dim2=-1).log().sum()
        logdet.backward()
        expected_d = weights[None, :, None] * (differences.detach() @ (
            candidate.grad + candidate.grad.transpose(-1, -2)))
        expected_q = candidate.grad.diagonal(dim1=-2, dim2=-1).sum(0)
        result.update(standalone_covariance_gradient_differences_finite=bool(torch.isfinite(differences.grad).all()),
                      standalone_covariance_gradient_q_finite=bool(torch.isfinite(q.grad).all()),
                      analytic_weighted_covariance_gradient_max_error=float((differences.grad - expected_d).abs().max()),
                      analytic_q_gradient_max_error=float((q.grad - expected_q).abs().max()))
    with (evidence / 'compensated_float64_covariance.pt').open('xb') as f:
        torch.save({'covariance': accurate.cpu(), 'source_context': operands['context'],
                    'formal_training_used': False}, f)
    unchanged = {path: h.sha(path) == expected for path, expected in pinned.items()}
    assert all(unchanged.values()) and h.sha(decimal_path) == spec['reconstructed_decimal_sha256']
    result.update(source_and_original_artifacts_unchanged=True, unchanged_file_checks=unchanged,
                  finished_at_beijing=h.now())
    h.save(evidence / 'saved_matrix_audit_result.json', result)
    print(json.dumps({'status': result['status'], 'audit_kind': result['audit_kind'],
                      'cholesky_info': result['compensated_cholesky_info'], 'model_steps': 0}), flush=True)


if __name__ == '__main__':
    main()
