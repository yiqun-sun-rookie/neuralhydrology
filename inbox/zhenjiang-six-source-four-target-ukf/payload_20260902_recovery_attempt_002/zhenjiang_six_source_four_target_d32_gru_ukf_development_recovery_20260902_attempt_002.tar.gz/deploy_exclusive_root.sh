#!/usr/bin/env bash
set -eo pipefail

ORIGINAL_ROOT="/data1/home/sunyiq/zhenjiang_six_source_four_target_differentiable_ukf_20260901_r2"
ROOT="/data1/home/sunyiq/zhenjiang_six_source_four_target_differentiable_ukf_20260902_recovery_attempt_002"
STAGING="${ROOT}.staging"
PARTIAL="${ROOT}.partial"
PAYLOAD_ROOT="${1:?usage: deploy_exclusive_root.sh /absolute/extracted_bundle}"

fatal() {
  echo "[FATAL] $1"
  exit 1
}

require_file() {
  [ -f "$1" ] && [ ! -L "$1" ] || fatal "required ordinary file is absent: $1"
}

require_sha256() {
  observed="$(sha256sum "$2" | awk '{print $1}')"
  [ "${observed}" = "$1" ] || fatal "SHA-256 differs: $2"
}

case "${PAYLOAD_ROOT}" in
  /*) ;;
  *) fatal "payload root must be absolute" ;;
esac
[ -d "${PAYLOAD_ROOT}/run" ] || fatal "payload run tree is absent"
require_file "${PAYLOAD_ROOT}/bundle_manifest.json"
require_file "${PAYLOAD_ROOT}/deploy_exclusive_root.sh"
for candidate in "${ROOT}" "${STAGING}" "${PARTIAL}"; do
  [ ! -e "${candidate}" ] || fatal "exclusive recovery destination already exists: ${candidate}"
done
[ -d "${ORIGINAL_ROOT}" ] && [ ! -L "${ORIGINAL_ROOT}" ] || fatal "original r2 root is absent"
ORIGINAL_PARTIAL="${ORIGINAL_ROOT}/evidence/development_2023/evaluation/attempt_001.partial"
[ -d "${ORIGINAL_PARTIAL}" ] && [ ! -L "${ORIGINAL_PARTIAL}" ] || fatal "failed attempt partial is absent"
require_file "${ORIGINAL_PARTIAL}/development_access_started.json"
require_file "${ORIGINAL_ROOT}/logs/development-2023-217810.out"
require_file "${ORIGINAL_ROOT}/logs/development-2023-217810.err"
require_file "${ORIGINAL_ROOT}/run/docs/records/ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_DIFFERENTIABLE_UKF_V1_REGISTRY.json"
require_file "${ORIGINAL_ROOT}/run/scripts/analysis/zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1.py"
[ ! -e "${ORIGINAL_ROOT}/evidence/development_2023/evaluation/attempt_001" ] || fatal "failed attempt unexpectedly has final evaluation"
[ ! -e "${ORIGINAL_ROOT}/evidence/development_2023/independent_audit/attempt_001" ] || fatal "failed attempt unexpectedly has final audit"
[ ! -e "${ORIGINAL_ROOT}/evidence/development_2023/independent_audit/attempt_001.partial" ] || fatal "failed attempt unexpectedly has partial audit"
entry_count="$(find "${ORIGINAL_PARTIAL}" -mindepth 1 -maxdepth 1 -printf '.' | wc -c)"
[ "${entry_count}" = "1" ] || fatal "failed attempt partial must contain exactly one file"
[ "$(stat -c '%s' "${ORIGINAL_PARTIAL}/development_access_started.json")" = "9140" ] || fatal "old access-marker byte count differs"
[ "$(stat -c '%s' "${ORIGINAL_ROOT}/logs/development-2023-217810.out")" = "903" ] || fatal "old standard-output byte count differs"
[ "$(stat -c '%s' "${ORIGINAL_ROOT}/logs/development-2023-217810.err")" = "1644" ] || fatal "old standard-error byte count differs"
[ "$(stat -c '%s' "${ORIGINAL_ROOT}/run/scripts/analysis/zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1.py")" = "129641" ] || fatal "old evaluator byte count differs"
require_sha256 "704366cb22eef1d3acb58f4f0524a6e50d49ffa442afcf0fca498fbd21154cb8" "${ORIGINAL_ROOT}/run/docs/records/ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_DIFFERENTIABLE_UKF_V1_REGISTRY.json"
require_sha256 "badf3ee5f8cf3f0d9c5e5771b11385a45a6f22d6355fc43357bc44f2bd364c9e" "${ORIGINAL_PARTIAL}/development_access_started.json"
require_sha256 "bcd7cc658a9a1790f07cce392a9b60d9f3338b722af8520f2a20bb61998111c8" "${ORIGINAL_ROOT}/logs/development-2023-217810.out"
require_sha256 "7ebac31811938324b27f10743850a0b32e981d1b8eb5f0dcc750ce089b60f185" "${ORIGINAL_ROOT}/logs/development-2023-217810.err"
require_sha256 "f64e5ffcc47061d97f66e28e15ec45f7412b1d8a59455771180c4ef47eab9281" "${ORIGINAL_ROOT}/run/scripts/analysis/zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1.py"

original_identity_before="$(sha256sum \
  "${ORIGINAL_ROOT}/run/docs/records/ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_DIFFERENTIABLE_UKF_V1_REGISTRY.json" \
  "${ORIGINAL_PARTIAL}/development_access_started.json" \
  "${ORIGINAL_ROOT}/logs/development-2023-217810.out" \
  "${ORIGINAL_ROOT}/logs/development-2023-217810.err" \
  "${ORIGINAL_ROOT}/run/scripts/analysis/zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1.py" | sha256sum | awk '{print $1}')"

mkdir "${STAGING}"
trap 'if [ -d "${STAGING}" ] && [ ! -e "${ROOT}" ] && [ ! -e "${PARTIAL}" ]; then mv "${STAGING}" "${PARTIAL}"; fi' ERR
cp -a "${PAYLOAD_ROOT}/run" "${STAGING}/run"
if [ -n "$(find "${STAGING}/run" -type l -print -quit)" ]; then
  fatal "recovery payload contains a symbolic link"
fi
mkdir -p "${STAGING}/logs" "${STAGING}/evidence" "${STAGING}/jobs"
cp "${PAYLOAD_ROOT}/bundle_manifest.json" "${STAGING}/jobs/bundle_manifest.json"
cp "${PAYLOAD_ROOT}/deploy_exclusive_root.sh" "${STAGING}/jobs/deploy_exclusive_root.sh"

python3 - "${PAYLOAD_ROOT}" "${STAGING}" <<'PY'
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys

payload = Path(sys.argv[1]).resolve(strict=True)
staging = Path(sys.argv[2]).resolve(strict=True)
manifest = json.loads((payload / "bundle_manifest.json").read_text(encoding="utf-8"))
if (
    manifest.get("migration_id")
    != "zhenjiang_six_source_four_target_d32_gru_ukf_development_recovery_20260902_attempt_002"
    or manifest.get("authorized_2023_technical_recovery") is not True
    or manifest.get("recovery_attempt_number") != 2
    or manifest.get("current_attempt_development_loader_call_count") != 1
    or manifest.get("cumulative_development_loader_call_count") != 2
    or manifest.get("prior_failed_development_access_attempt_count") != 1
    or manifest.get("original_single_read_contract_satisfied") is not False
    or manifest.get("held_out_2024_target_access_authorized") is not False
    or manifest.get("boundary_future_target_access_authorized") is not False
    or manifest.get("original_remote_root_read_only")
    != "/data1/home/sunyiq/zhenjiang_six_source_four_target_differentiable_ukf_20260901_r2"
    or manifest.get("recovery_remote_root")
    != "/data1/home/sunyiq/zhenjiang_six_source_four_target_differentiable_ukf_20260902_recovery_attempt_002"
):
    raise SystemExit("recovery bundle authorization drift")
rows = manifest.get("source_files")
if not isinstance(rows, list) or len(rows) != 5 or manifest.get("source_file_count") != 5:
    raise SystemExit("recovery bundle source count drift")
expected = {row["path"]: (row["byte_count"], row["sha256"]) for row in rows}
actual = {
    path.relative_to(staging / "run").as_posix(): path
    for path in (staging / "run").rglob("*")
    if path.is_file()
}
if set(actual) != set(expected):
    raise SystemExit("deployed recovery run tree differs from exact membership")
for relative, path in actual.items():
    content = path.read_bytes()
    byte_count, digest = expected[relative]
    if len(content) != byte_count or hashlib.sha256(content).hexdigest() != digest:
        raise SystemExit("deployed recovery payload identity drift: " + relative)
contract_path = staging / "run/docs/records/ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_DIFFERENTIABLE_UKF_V1_2023_TECHNICAL_RECOVERY_ATTEMPT_002_AUTHORIZATION.json"
contract = json.loads(contract_path.read_text(encoding="utf-8"))
implementations = {row["path"]: row["sha256"] for row in contract["implementation_files"]}
expected_implementations = {
    "scripts/analysis/zhenjiang_six_source_four_target_d32_gru_ukf_development_recovery_v1.py",
    "scripts/analysis/audit_zhenjiang_six_source_four_target_d32_gru_ukf_development_recovery_v1.py",
    "scripts/hpc/zhenjiang_six_source_four_target_d32_gru_ukf_development_recovery_v1.slurm",
}
if (
    contract.get("authorized") is not True
    or contract.get("recovery_attempt_number") != 2
    or contract.get("cumulative_development_loader_call_count") != 2
    or contract.get("held_out_2024_target_access_authorized") is not False
    or contract.get("boundary_future_target_access_authorized") is not False
    or set(implementations) != expected_implementations
):
    raise SystemExit("recovery contract drift inside deployed tree")
for relative, digest in implementations.items():
    if hashlib.sha256((staging / "run" / relative).read_bytes()).hexdigest() != digest:
        raise SystemExit("recovery contract implementation identity drift: " + relative)
PY

find "${STAGING}/run" -type f -exec chmod 0444 {} +
find "${STAGING}/run" -type d -exec chmod 0555 {} +
chmod 0444 "${STAGING}/jobs/bundle_manifest.json"
chmod 0555 "${STAGING}/jobs/deploy_exclusive_root.sh"
mv "${STAGING}" "${ROOT}"
trap - ERR

original_identity_after="$(sha256sum \
  "${ORIGINAL_ROOT}/run/docs/records/ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_DIFFERENTIABLE_UKF_V1_REGISTRY.json" \
  "${ORIGINAL_PARTIAL}/development_access_started.json" \
  "${ORIGINAL_ROOT}/logs/development-2023-217810.out" \
  "${ORIGINAL_ROOT}/logs/development-2023-217810.err" \
  "${ORIGINAL_ROOT}/run/scripts/analysis/zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1.py" | sha256sum | awk '{print $1}')"
[ "${original_identity_after}" = "${original_identity_before}" ] || fatal "original r2 forensic identity changed during deployment"
echo "[DONE] exclusive recovery root deployed=${ROOT}"
