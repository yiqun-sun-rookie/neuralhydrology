"""Synthetic-only tests for the frozen 2023 evaluation writer."""

from __future__ import annotations

import ast
import csv
import hashlib
import inspect
import json
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import pytest
import torch


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "scripts" / "analysis"
MODELING = ROOT / "scripts" / "modeling"
if str(ANALYSIS) not in sys.path:
    sys.path.insert(0, str(ANALYSIS))
if str(MODELING) not in sys.path:
    sys.path.insert(0, str(MODELING))

import audit_zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1 as audit_module  # noqa: E402,E501
import audit_zhenjiang_six_source_four_target_d32_gru_ukf_development_recovery_v1 as recovery_audit_module  # noqa: E402,E501
import zhenjiang_six_source_four_target_base_qualification_v1 as qualification_module  # noqa: E402,E501
import zhenjiang_six_source_four_target_d32_gru_ukf_development_recovery_v1 as evaluation_module  # noqa: E402,E501
import zhenjiang_six_source_four_target_data_v1 as data_module  # noqa: E402
import zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_runner_v1 as runner_module  # noqa: E402,E501

from zhenjiang_six_source_four_target_d32_gru_ukf_development_recovery_v1 import (  # noqa: E402
    accumulate_development_sufficient_statistics,
    build_base_observation_head_qualification,
    execute_frozen_2023_development_evaluation_once,
    verify_sufficient_grid,
    write_development_evaluation,
)


def _data_access_audit():
    bytes_by_path = {
        "dataset_config.json": 2854,
        "realtime_features/datong_realtime_features.csv": 5_485_506,
        "realtime_features/nanjing_realtime_features.csv": 5_452_340,
        "realtime_features/zhenjiang_realtime_features.csv": 5_490_493,
        "realtime_features/jiangyin_realtime_features.csv": 5_451_807,
        "realtime_features/xuliujing_realtime_features.csv": 5_452_448,
        "realtime_features/wusongkou_realtime_features.csv": 5_449_542,
        "retrospective_targets/nanjing_retrospective_targets.csv": 5_453_455,
        "retrospective_targets/zhenjiang_retrospective_targets.csv": 5_491_015,
        "retrospective_targets/jiangyin_retrospective_targets.csv": 5_452_821,
        "retrospective_targets/xuliujing_retrospective_targets.csv": 5_453_528,
    }
    csv_paths = [path for path in bytes_by_path if path.endswith(".csv")]
    return {
        "opened_paths": list(bytes_by_path),
        "bytes_read_by_path": bytes_by_path,
        "rows_parsed_by_path": {path: 61_344 for path in csv_paths},
        "values_loaded_by_path": {path: 61_344 for path in csv_paths},
        "target_rows_by_period": {
            "training": 175_296,
            "selection": 35_040,
            "development_gate": 35_040,
            "heldout_or_later": 0,
            "boundary_target": 0,
        },
        "astronomical_tide_model_open_count": 1,
        "development_feature_bytes_read": 4_685_966,
        "development_feature_rows_parsed": 52_560,
        "development_feature_values_loaded": 52_560,
        "development_target_bytes_read": 3_123_728,
        "development_target_rows_parsed": 35_040,
        "development_target_values_loaded": 35_040,
        "heldout_target_bytes_read": 0,
        "heldout_target_rows_parsed": 0,
        "heldout_target_values_loaded": 0,
        "boundary_target_bytes_read": 0,
        "boundary_target_rows_parsed": 0,
        "boundary_target_values_loaded": 0,
    }


def _artifact_identities():
    return [
        {
            "seed": seed,
            "base_checkpoint_path": "/synthetic/s%d/base.pt" % seed,
            "base_checkpoint_sha256": "%064x" % seed,
            "observation_head_path": "/synthetic/s%d/head.pt" % seed,
            "observation_head_sha256": "%064x" % (seed + 100),
            "filter_checkpoint_path": "/synthetic/s%d/filter.pt" % seed,
            "filter_checkpoint_sha256": "%064x" % (seed + 200),
            "filter_completion_manifest_sha256": "%064x" % (seed + 300),
            "observation_head_design_diagnostic": {
                "seed": seed,
                "selection_report_path": "/synthetic/s%d/ridge_candidate_diagnostics.json" % seed,
                "selection_report_sha256": "%064x" % (seed + 400),
                "coefficient_float32_sha256": "%064x" % (seed + 500),
                "selected_ridge_strength": 0.1,
                "augmented_design_singular_values": [
                    float(value) for value in range(33, 0, -1)
                ],
                "augmented_design_rank": 33,
                "augmented_design_condition_number": 33.0,
            },
        }
        for seed in (17, 29, 43)
    ]


def _run_identity():
    return {
        "registry_path": "/synthetic/registry.json",
        "registry_sha256": "a" * 64,
        "input_root_path": "/synthetic/input",
        "input_manifest_path": "/synthetic/input/manifest.json",
        "input_manifest_sha256": "b" * 64,
    }


def _write_exact_size(path: Path, payload: bytes, byte_count: int) -> None:
    """Write one parseable or opaque forensic fixture at an exact byte size."""

    if len(payload) > byte_count:
        raise AssertionError("fixture payload exceeds its frozen byte count")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(payload + b" " * (byte_count - len(payload)))


def _build_recovery_contract_fixture(
    tmp_path, monkeypatch, *, use_real_run_identity=False
):
    """Create an isolated exact attempt-001 failure and attempt-002 contract."""

    original_root = tmp_path / "original_r2"
    recovery_root = tmp_path / "recovery_attempt_002"
    monkeypatch.setattr(evaluation_module, "ORIGINAL_REMOTE_ROOT", original_root)
    monkeypatch.setattr(evaluation_module, "RECOVERY_REMOTE_ROOT", recovery_root)

    registry_path = (
        original_root
        / "run/docs/records/"
        "ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_"
        "DIFFERENTIABLE_UKF_V1_REGISTRY.json"
    )
    registry_path.parent.mkdir(parents=True, exist_ok=True)
    registry_path.write_text("{}\n", encoding="utf-8")
    registry_sha256 = hashlib.sha256(registry_path.read_bytes()).hexdigest()
    monkeypatch.setattr(
        evaluation_module, "ORIGINAL_REGISTRY_SHA256", registry_sha256
    )
    if use_real_run_identity:
        input_root = original_root / "inputs/pre2024-four-target-v1"
        input_root.mkdir(parents=True)
        input_manifest = input_root / "four_target_input_manifest.json"
        input_manifest.write_text("{}\n", encoding="utf-8")
        run_identity = {
            "registry_path": str(registry_path),
            "registry_sha256": registry_sha256,
            "input_root_path": str(input_root),
            "input_manifest_path": str(input_manifest),
            "input_manifest_sha256": hashlib.sha256(
                input_manifest.read_bytes()
            ).hexdigest(),
        }
    else:
        run_identity = _run_identity()

    original_evaluation = original_root / evaluation_module.FORMAL_EVALUATION_RELATIVE_PATH
    original_partial = original_evaluation.with_name(
        original_evaluation.name + ".partial"
    )
    original_partial.mkdir(parents=True)
    original_marker_path = (
        original_partial / evaluation_module.DEVELOPMENT_ACCESS_MARKER_NAME
    )
    original_marker = {
        "status": "development_access_claimed_before_loader",
        "experiment_id": evaluation_module.FORMAL_DEVELOPMENT_EXPERIMENT_ID,
        "evaluation_partial_directory": str(original_partial.resolve()),
        "registered_run_identity": run_identity,
        "frozen_artifact_identities": _artifact_identities(),
        "frozen_artifact_count": 9,
        "held_out_2024_target_access_authorized": False,
        "boundary_future_target_access_authorized": False,
    }
    _write_exact_size(
        original_marker_path,
        json.dumps(original_marker, sort_keys=True).encode("utf-8"),
        9140,
    )
    original_marker_sha256 = hashlib.sha256(
        original_marker_path.read_bytes()
    ).hexdigest()
    monkeypatch.setattr(
        evaluation_module, "ORIGINAL_ACCESS_MARKER_SHA256", original_marker_sha256
    )

    stdout_path = original_root / "logs/development-2023-217810.out"
    stderr_path = original_root / "logs/development-2023-217810.err"
    original_evaluator_path = (
        original_root
        / "run/scripts/analysis/"
        "zhenjiang_six_source_four_target_d32_gru_"
        "ukf_development_evaluation_v1.py"
    )
    _write_exact_size(stdout_path, b"failed stdout\n", 903)
    _write_exact_size(stderr_path, b"failed stderr\n", 1644)
    _write_exact_size(original_evaluator_path, b"# frozen evaluator\n", 129641)
    stdout_sha256 = hashlib.sha256(stdout_path.read_bytes()).hexdigest()
    stderr_sha256 = hashlib.sha256(stderr_path.read_bytes()).hexdigest()
    evaluator_sha256 = hashlib.sha256(original_evaluator_path.read_bytes()).hexdigest()
    monkeypatch.setattr(evaluation_module, "ORIGINAL_STDOUT_SHA256", stdout_sha256)
    monkeypatch.setattr(evaluation_module, "ORIGINAL_STDERR_SHA256", stderr_sha256)
    monkeypatch.setattr(
        evaluation_module, "ORIGINAL_EVALUATOR_SHA256", evaluator_sha256
    )

    implementation_paths = (
        "scripts/analysis/"
        "zhenjiang_six_source_four_target_d32_gru_ukf_development_recovery_v1.py",
        "scripts/analysis/"
        "audit_zhenjiang_six_source_four_target_d32_gru_ukf_development_recovery_v1.py",
        "scripts/hpc/"
        "zhenjiang_six_source_four_target_d32_gru_ukf_development_recovery_v1.slurm",
    )
    implementation_rows = []
    for index, relative_path in enumerate(implementation_paths):
        implementation_path = recovery_root / "run" / relative_path
        implementation_path.parent.mkdir(parents=True, exist_ok=True)
        implementation_path.write_text(
            "recovery implementation %d\n" % index, encoding="utf-8"
        )
        implementation_rows.append(
            {
                "path": relative_path,
                "sha256": hashlib.sha256(implementation_path.read_bytes()).hexdigest(),
            }
        )

    original_audit = original_root / evaluation_module.FORMAL_AUDIT_RELATIVE_PATH
    recovery_evaluation = (
        recovery_root / evaluation_module.RECOVERY_EVALUATION_RELATIVE_PATH
    )
    recovery_audit = recovery_root / evaluation_module.RECOVERY_AUDIT_RELATIVE_PATH
    contract_path = (
        recovery_root
        / "run/docs/records/"
        "ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_"
        "DIFFERENTIABLE_UKF_V1_2023_TECHNICAL_RECOVERY_"
        "ATTEMPT_002_AUTHORIZATION.json"
    )
    contract = {
        "schema_version": "1.0",
        "status": "authorized_2023_technical_recovery_attempt_002",
        "authorized": True,
        "authorization_date": "2026-09-02",
        "user_authorization_text": evaluation_module.RECOVERY_USER_AUTHORIZATION_TEXT,
        "recovery_experiment_id": evaluation_module.RECOVERY_EXPERIMENT_ID,
        "recovery_attempt_number": 2,
        "current_attempt_development_loader_call_count": 1,
        "cumulative_development_loader_call_count": 2,
        "prior_failed_development_access_attempt_count": 1,
        "original_single_read_contract_satisfied": False,
        "held_out_2024_target_access_authorized": False,
        "boundary_future_target_access_authorized": False,
        "scientific_contract_changed": False,
        "permitted_change": (
            "float32_dependency_validation_and_recovery_bookkeeping_only"
        ),
        "original_remote_root": str(original_root),
        "recovery_remote_root": str(recovery_root),
        "original_registry_path": str(registry_path),
        "original_registry_sha256": registry_sha256,
        "original_evaluation_partial_directory": str(original_partial),
        "original_evaluation_directory": str(original_evaluation),
        "original_audit_directory": str(original_audit),
        "original_audit_partial_directory": str(
            original_audit.with_name(original_audit.name + ".partial")
        ),
        "original_access_marker_path": str(original_marker_path),
        "original_access_marker_byte_count": 9140,
        "original_access_marker_sha256": original_marker_sha256,
        "original_failed_job_id": 217810,
        "original_stdout_path": str(stdout_path),
        "original_stdout_byte_count": 903,
        "original_stdout_sha256": stdout_sha256,
        "original_stderr_path": str(stderr_path),
        "original_stderr_byte_count": 1644,
        "original_stderr_sha256": stderr_sha256,
        "original_evaluator_path": str(original_evaluator_path),
        "original_evaluator_byte_count": 129641,
        "original_evaluator_sha256": evaluator_sha256,
        "recovery_evaluation_directory": str(recovery_evaluation),
        "recovery_audit_directory": str(recovery_audit),
        "frozen_seeds": [17, 29, 43],
        "bootstrap_repeat_count": evaluation_module.BOOTSTRAP_REPEAT_COUNT,
        "bootstrap_random_seed": evaluation_module.BOOTSTRAP_RANDOM_SEED,
        "implementation_files": implementation_rows,
    }
    contract_path.parent.mkdir(parents=True, exist_ok=True)
    contract_path.write_text(
        json.dumps(contract, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return {
        "contract": contract,
        "contract_path": contract_path,
        "original_partial": original_partial,
        "recovery_evaluation": recovery_evaluation,
        "recovery_audit": recovery_audit,
        "run_identity": run_identity,
        "artifact_identities": _artifact_identities(),
    }


def synthetic_seed_statistics(
    seed: int, experiment_id: str = "synthetic_formal_candidate"
):
    origins = (
        "2023-01-01T00:00:00+08:00",
        "2023-01-02T00:00:00+08:00",
        "2023-01-15T00:00:00+08:00",
        "2023-01-16T00:00:00+08:00",
    )
    count = len(origins)
    origin_axis = np.arange(count, dtype=np.float64)[:, None, None] * 0.01
    lead_axis = np.arange(23, dtype=np.float64)[None, :, None] * 0.1
    target_axis = np.arange(4, dtype=np.float64)[None, None, :] * 0.1
    truth = 1.0 + origin_axis + lead_axis + target_axis
    base = truth + 0.11
    prior = truth + 0.10
    updated = np.repeat((truth + 0.08)[:, None, :, :], 6, axis=1)
    analysis_truth = truth[:, 0, :]
    analysis_prior_target = analysis_truth + 0.10
    analysis_posterior_target = np.repeat(
        (analysis_truth + 0.08)[:, None, :], 6, axis=1
    )
    observation = (
        np.arange(count, dtype=np.float64)[:, None] * 0.01
        + np.arange(6, dtype=np.float64)[None, :] * 0.1
    )
    prior_observation = observation + 0.10
    posterior_observation = np.repeat(prior_observation[:, None, :], 6, axis=1)
    for source in range(6):
        posterior_observation[:, source, source] = observation[:, source] + 0.05
    kalman_gain = np.ones((count, 6, 32), dtype=np.float64) * 0.01
    contraction = np.ones((count, 6), dtype=np.float64) * 0.5
    posterior_variance = np.ones((count, 6), dtype=np.float64) * 0.002
    eigenvalue = np.ones((count, 6), dtype=np.float64) * 0.001
    spectral_floor = np.ones((count, 6), dtype=np.float64) * 1e-12
    observation_noise = np.ones(6, dtype=np.float64) * 0.1
    prior_state = np.zeros((count, 23, 32), dtype=np.float64)
    updated_state = np.empty((count, 6, 23, 32), dtype=np.float64)
    for source in range(6):
        updated_state[:, source] = 0.001 * (source + 1)
    return accumulate_development_sufficient_statistics(
        experiment_id=experiment_id,
        seed=seed,
        origin_times=origins,
        target_future_m=truth,
        analysis_target_m=analysis_truth,
        analysis_observation_m=observation,
        current_stage_m=observation + 0.20,
        base_issue_hour_one_forecast_m=analysis_truth + 0.11,
        base_deterministic_forecast_m=base,
        unscented_prior_forecast_m=prior,
        updated_forecast_m=updated,
        analysis_prior_target_m=analysis_prior_target,
        analysis_posterior_target_m=analysis_posterior_target,
        analysis_prior_observation_m=prior_observation,
        analysis_posterior_observation_m=posterior_observation,
        analysis_kalman_gain=kalman_gain,
        analysis_observation_contraction=contraction,
        analysis_posterior_observation_variance_normalized=posterior_variance,
        analysis_posterior_minimum_eigenvalue=eigenvalue,
        analysis_spectral_floor=spectral_floor,
        observation_noise_standard_deviation_normalized=observation_noise,
        unscented_prior_state_mean=prior_state,
        updated_state_mean=updated_state,
    )


def test_accumulator_has_dynamic_calendar_block_scaled_shapes():
    statistics = synthetic_seed_statistics(17)
    assert statistics["nonempty_block_ids"] == [0, 2]
    assert statistics["nonempty_block_count"] == 2
    assert len(statistics["future_rows"]) == 2 * 6 * 4 * 23
    assert len(statistics["analysis_observation_rows"]) == 2 * 6
    assert len(statistics["analysis_target_rows"]) == 2 * 6 * 4
    assert len(statistics["state_difference_rows"]) == 2 * 6 * 23
    assert all(
        row["issue_horizon_hour"] == row["post_update_lead_hour"] + 1
        for row in statistics["future_rows"]
    )


def test_data_access_audit_normalization_is_idempotent():
    first = evaluation_module._validated_data_access_audit(_data_access_audit())
    second = evaluation_module._validated_data_access_audit(first)
    assert second == first
    assert first["rows_parsed_by_path"]["dataset_config.json"] == 0
    assert first["values_loaded_by_path"]["dataset_config.json"] == 0


def test_qualification_hard_gate_is_pooled_not_per_seed():
    statistics = [synthetic_seed_statistics(seed) for seed in (17, 29, 43)]
    base_rows = [
        dict(row) for item in statistics for row in item["base_qualification_rows"]
    ]
    observation_rows = [
        dict(row)
        for item in statistics
        for row in item["observation_head_qualification_rows"]
    ]
    for row in base_rows:
        if row["seed"] == 17 and row["target_index"] == 0:
            row["base_first_six_absolute_error_sum_m"] = (
                row["persistence_first_six_absolute_error_sum_m"] + 0.01
            )
    for row in observation_rows:
        if row["seed"] == 17 and row["source_index"] == 0:
            row["head_absolute_error_sum_m"] = (
                row["persistence_absolute_error_sum_m"] + 0.01
            )

    qualification = build_base_observation_head_qualification(
        base_rows, observation_rows
    )
    failed_target_seed = next(
        row
        for row in qualification["target_seed_results"]
        if row["seed"] == 17 and row["target_index"] == 0
    )
    failed_source_seed = next(
        row
        for row in qualification["observation_head_seed_results"]
        if row["seed"] == 17 and row["source_index"] == 0
    )
    assert failed_target_seed["passed"] is False
    assert failed_source_seed["passed"] is False
    assert qualification["target_pooled_results"][0]["passed"] is True
    assert qualification["observation_head_pooled_results"][0]["passed"] is True
    assert qualification["passed"] is True
    assert qualification["qualification_gate_contract"] == {
        "aggregation": "pooled_equal_weight_three_seeds",
        "hard_target_gate_count": 4,
        "hard_source_gate_count": 6,
        "per_seed_results_are_diagnostics_only": True,
    }


def test_pooled_sufficient_qualification_matches_authoritative_raw_arrays():
    statistics = [synthetic_seed_statistics(seed) for seed in (17, 29, 43)]
    sufficient = build_base_observation_head_qualification(
        [row for item in statistics for row in item["base_qualification_rows"]],
        [
            row
            for item in statistics
            for row in item["observation_head_qualification_rows"]
        ],
    )

    origin_count = 4
    truth_future = (
        1.0
        + np.arange(origin_count, dtype=np.float64)[:, None, None] * 0.01
        + np.arange(23, dtype=np.float64)[None, :, None] * 0.1
        + np.arange(4, dtype=np.float64)[None, None, :] * 0.1
    )
    target_hour_one = truth_future[:, 0, :]
    full_targets = np.concatenate(
        (target_hour_one[:, None, :], truth_future), axis=1
    )
    full_base = full_targets + 0.11
    observations = (
        np.arange(origin_count, dtype=np.float64)[:, None] * 0.01
        + np.arange(6, dtype=np.float64)[None, :] * 0.1
    )
    issue_stage = observations + 0.20
    repeats = 3
    authoritative = qualification_module.evaluate_base_and_observation_head_qualification(
        base_predictions_m=np.concatenate([full_base] * repeats, axis=0),
        base_targets_m=np.concatenate([full_targets] * repeats, axis=0),
        target_issue_stage_m=np.concatenate([issue_stage[:, 1:5]] * repeats, axis=0),
        observation_head_predictions_m=np.concatenate(
            [observations + 0.10] * repeats, axis=0
        ),
        realtime_observations_t_plus_1_m=np.concatenate(
            [observations] * repeats, axis=0
        ),
        source_issue_stage_m=np.concatenate([issue_stage] * repeats, axis=0),
        augmented_design_singular_values=np.arange(33, 0, -1, dtype=np.float64),
        augmented_design_rank=33,
        augmented_design_condition_number=33.0,
    )

    for target_row in sufficient["target_pooled_results"]:
        expected = authoritative["base_forecast"]["target_results"][
            target_row["target_station"]
        ]
        assert target_row["first_six_cell_count"] == expected["sample_count"] * 6
        assert target_row["full_twenty_four_cell_count"] == expected["sample_count"] * 24
        assert target_row["base_first_six_mae_m"] == pytest.approx(
            expected["mean_absolute_error_issue_horizon_1_to_6_m"],
            rel=1e-12,
            abs=1e-12,
        )
        assert target_row["persistence_first_six_mae_m"] == pytest.approx(
            expected["persistence_mean_absolute_error_issue_horizon_1_to_6_m"],
            rel=1e-12,
            abs=1e-12,
        )
        assert target_row["base_full_twenty_four_rmse_m"] == pytest.approx(
            expected["root_mean_squared_error_issue_horizon_1_to_24_m"],
            rel=1e-12,
            abs=1e-12,
        )
        assert target_row["base_full_twenty_four_nse"] == pytest.approx(
            expected["nash_sutcliffe_efficiency_issue_horizon_1_to_24"],
            rel=1e-12,
            abs=1e-12,
        )
        assert target_row["passed"] is expected["passes"]

    for source_row in sufficient["observation_head_pooled_results"]:
        expected = authoritative["realtime_observation_head"]["source_results"][
            source_row["source_station"]
        ]
        assert source_row["cell_count"] == expected["sample_count"]
        assert source_row["head_mae_m"] == pytest.approx(
            expected["mean_absolute_error_t_plus_1_m"], rel=1e-12, abs=1e-12
        )
        assert source_row["persistence_mae_m"] == pytest.approx(
            expected["persistence_mean_absolute_error_t_plus_1_m"],
            rel=1e-12,
            abs=1e-12,
        )
        assert source_row["head_bias_m"] == pytest.approx(
            expected["mean_bias_t_plus_1_m"], rel=1e-12, abs=1e-12
        )
        assert source_row["passed"] is expected["passes"]
    assert sufficient["passed"] is authoritative["passes"]


def test_observation_head_design_rank_must_be_positive():
    diagnostics = [
        dict(row["observation_head_design_diagnostic"])
        for row in _artifact_identities()
    ]
    diagnostics[0]["augmented_design_rank"] = 0
    with pytest.raises(ValueError, match="augmented rank"):
        evaluation_module._validated_observation_head_design_diagnostics(
            diagnostics
        )


def test_observation_head_report_rejects_self_consistent_non_global_selection(
    tmp_path,
):
    head_path = tmp_path / "realtime_observation_head.pt"
    selected_hash = "%064x" % 8
    torch.save(
        {
            "seed": 17,
            "selected_ridge_strength": 1.0,
            "coefficient_float32_sha256": selected_hash,
        },
        head_path,
    )
    candidates = []
    for index, ridge in enumerate(evaluation_module.FROZEN_RIDGE_STRENGTHS):
        candidates.append(
            {
                "ridge_strength": ridge,
                "selection_mean_absolute_error_m": 0.1 + 0.01 * index,
                "station_selection_mean_absolute_error_m": [0.1] * 6,
                "augmented_design_singular_values": [
                    float(value) for value in range(33, 0, -1)
                ],
                "augmented_design_rank": 33,
                "augmented_design_condition_number": 33.0,
                "coefficient_float64_sha256": "%064x" % (index + 100),
                "coefficient_float32_sha256": "%064x" % (index + 1),
            }
        )
    (tmp_path / "ridge_candidate_diagnostics.json").write_text(
        json.dumps(
            {
                "selected_ridge_strength": 1.0,
                "selected_coefficient_float32_sha256": selected_hash,
                "candidates": candidates,
            }
        ),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="global-minimum"):
        evaluation_module._read_observation_head_design_diagnostic(
            head_path, seed=17
        )


def test_three_seed_grid_verifier_freezes_1656_lead_summaries():
    statistics = [synthetic_seed_statistics(seed) for seed in (17, 29, 43)]
    grid = verify_sufficient_grid(
        [row for seed in statistics for row in seed["future_rows"]],
        [row for seed in statistics for row in seed["analysis_observation_rows"]],
        [row for seed in statistics for row in seed["analysis_target_rows"]],
        [row for seed in statistics for row in seed["state_difference_rows"]],
    )
    assert grid["nonempty_block_count"] == 2
    assert grid["future_rows_per_seed"] == 2 * 6 * 4 * 23
    assert grid["analysis_observation_rows_per_seed"] == 2 * 6
    assert grid["analysis_target_rows_per_seed"] == 2 * 6 * 4
    assert grid["state_difference_rows_per_seed"] == 2 * 6 * 23
    assert grid["source_target_lead_summary_rows"] == 1656


def test_grid_verifier_rejects_duplicate_observation_target_and_state_keys():
    statistics = [synthetic_seed_statistics(seed) for seed in (17, 29, 43)]
    future = [row for seed in statistics for row in seed["future_rows"]]
    observation = [
        row for seed in statistics for row in seed["analysis_observation_rows"]
    ]
    target = [row for seed in statistics for row in seed["analysis_target_rows"]]
    state = [row for seed in statistics for row in seed["state_difference_rows"]]
    for table_name, table in (
        ("analysis observation", observation),
        ("analysis target", target),
        ("state difference", state),
    ):
        corrupted = list(table)
        corrupted[-1] = dict(corrupted[0])
        arguments = {
            "observation": observation,
            "target": target,
            "state": state,
        }
        arguments[
            {
                "analysis observation": "observation",
                "analysis target": "target",
                "state difference": "state",
            }[table_name]
        ] = corrupted
        with pytest.raises(ValueError, match="exact unique key grid"):
            verify_sufficient_grid(
                future,
                arguments["observation"],
                arguments["target"],
                arguments["state"],
            )


def test_writer_creates_complete_non_overwriting_evaluation(tmp_path):
    statistics = [synthetic_seed_statistics(seed) for seed in (17, 29, 43)]
    output = tmp_path / "new_evaluation"
    write_development_evaluation(
        output,
        statistics,
        base_observation_head_qualification={"passed": True},
        identity_gate_details={
            "four_normalization_identities_match": True,
            "boundary_future_target_access_is_zero": True,
            "held_out_2024_target_access_is_zero": True,
        },
        dependency_perturbation_evidence={
            "sample_identity_sha256": "0" * 64,
            "original_observation_normalized": np.zeros((2, 6)),
            "perturbed_observation_normalized": np.ones((2, 6)) * 0.01,
            "original_posterior_observation_normalized": np.ones((2, 6)) * 0.05,
            "perturbed_posterior_observation_normalized": np.ones((2, 6)) * 0.055,
        },
        data_access_audit=_data_access_audit(),
        frozen_artifact_identities=_artifact_identities(),
        registered_run_identity=_run_identity(),
        repeat_count=200,
        random_seed=20260901,
        synthetic_test_mode=True,
    )
    assert output.is_dir()
    required = {
        "future_sufficient_statistics.csv",
        "analysis_observation_sufficient_statistics.csv",
        "analysis_target_sufficient_statistics.csv",
        "state_difference_sufficient_statistics.csv",
        "base_and_three_branch_forecast_metrics.csv",
        "source_target_lead_metrics.csv",
        "source_target_window_metrics.csv",
        "six_source_four_target_gain_matrix.csv",
        "internal_four_by_four_gain_matrix.csv",
        "boundary_to_internal_gain_matrix.csv",
        "analysis_realtime_observation_diagnostics.csv",
        "analysis_target_space_gain_matrix.csv",
        "forecast_movement_matrix.csv",
        "reciprocal_direction_summary.csv",
        "development_gate_decision.json",
        "completion_manifest.json",
    }
    assert required.issubset({path.name for path in output.iterdir()})
    with (output / "source_target_lead_metrics.csv").open(
        encoding="utf-8", newline=""
    ) as handle:
        assert len(list(csv.DictReader(handle))) == 1656
    manifest = (output / "completion_manifest.json").read_text(encoding="utf-8")
    assert '"held_out_2024_target_access_count": 0' in manifest
    assert '"boundary_future_target_access_count": 0' in manifest
    with pytest.raises(FileExistsError):
        write_development_evaluation(
            output,
            statistics,
            base_observation_head_qualification={"passed": True},
            identity_gate_details={"identity": True},
            dependency_perturbation_evidence={
                "sample_identity_sha256": "0" * 64,
                "original_observation_normalized": np.zeros((1, 6)),
                "perturbed_observation_normalized": np.ones((1, 6)) * 0.01,
                "original_posterior_observation_normalized": np.ones((1, 6)) * 0.05,
                "perturbed_posterior_observation_normalized": np.ones((1, 6)) * 0.055,
            },
            data_access_audit=_data_access_audit(),
            frozen_artifact_identities=_artifact_identities(),
            registered_run_identity=_run_identity(),
            repeat_count=200,
            random_seed=20260901,
            synthetic_test_mode=True,
        )


def test_dependency_evidence_accepts_exact_model_float32_addition():
    original_float32 = np.asarray(
        [
            [-3.25, -1.125, -0.03125, 0.0, 1.75, 8.5],
            [0.125, 0.75, 2.5, 4.0, 12.0, 20.0],
        ],
        dtype=np.float32,
    )
    perturbed_float32 = original_float32 + np.float32(
        evaluation_module.DEPENDENCY_PERTURBATION_DELTA_NORMALIZED
    )
    evidence = {
        "sample_identity_sha256": "0" * 64,
        "original_observation_normalized": original_float32.astype(np.float64),
        "perturbed_observation_normalized": perturbed_float32.astype(np.float64),
        "original_posterior_observation_normalized": np.ones((2, 6)) * 0.05,
        "perturbed_posterior_observation_normalized": np.ones((2, 6)) * 0.055,
    }

    validated = evaluation_module._validated_dependency_evidence(evidence)

    assert np.array_equal(
        validated["perturbed_observation_normalized"],
        perturbed_float32.astype(np.float64),
    )
    assert not np.allclose(
        validated["perturbed_observation_normalized"]
        - validated["original_observation_normalized"],
        evaluation_module.DEPENDENCY_PERTURBATION_DELTA_NORMALIZED,
        atol=1e-12,
        rtol=1e-10,
    )


def test_recovery_contract_and_prior_failure_are_exact_and_tamper_evident(
    tmp_path, monkeypatch
):
    fixture = _build_recovery_contract_fixture(tmp_path, monkeypatch)

    contract = evaluation_module._validated_recovery_contract(
        fixture["contract_path"]
    )
    prior_marker = evaluation_module._verify_prior_failed_attempt(contract)

    assert contract["recovery_attempt_number"] == 2
    assert contract["cumulative_development_loader_call_count"] == 2
    assert contract["original_single_read_contract_satisfied"] is False
    assert prior_marker["frozen_artifact_count"] == 9
    assert not Path(contract["original_evaluation_directory"]).exists()
    assert not Path(contract["original_audit_directory"]).exists()

    extra = fixture["original_partial"] / "unexpected_result.csv"
    extra.write_text("must not exist\n", encoding="utf-8")
    with pytest.raises(RuntimeError, match="exactly its access marker"):
        evaluation_module._verify_prior_failed_attempt(contract)


def test_recovery_contract_rejects_authorization_or_implementation_drift(
    tmp_path, monkeypatch
):
    fixture = _build_recovery_contract_fixture(tmp_path, monkeypatch)
    contract_path = fixture["contract_path"]
    document = json.loads(contract_path.read_text(encoding="utf-8"))
    document["held_out_2024_target_access_authorized"] = True
    contract_path.write_text(
        json.dumps(document, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    with pytest.raises(ValueError, match="authorization or frozen contract drift"):
        evaluation_module._validated_recovery_contract(contract_path)

    document["held_out_2024_target_access_authorized"] = False
    contract_path.write_text(
        json.dumps(document, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    implementation_path = (
        Path(document["recovery_remote_root"])
        / "run"
        / document["implementation_files"][0]["path"]
    )
    implementation_path.write_text("tampered\n", encoding="utf-8")
    with pytest.raises(ValueError, match="implementation identity drift"):
        evaluation_module._validated_recovery_contract(contract_path)


def test_recovery_writer_manifests_two_accesses_and_refuses_retry(
    tmp_path, monkeypatch
):
    fixture = _build_recovery_contract_fixture(tmp_path, monkeypatch)
    contract = evaluation_module._validated_recovery_contract(
        fixture["contract_path"]
    )
    evaluation_module._verify_prior_failed_attempt(contract)
    output = fixture["recovery_evaluation"]
    artifacts = _artifact_identities()
    run_identity = _run_identity()
    partial = output.with_name(output.name + ".partial")
    evaluation_module._claim_development_access_before_loader(
        partial,
        registered_run_identity=run_identity,
        frozen_artifact_identities=artifacts,
    )
    recovery_marker = evaluation_module._claim_technical_recovery_access_before_loader(
        partial,
        contract=contract,
        registered_run_identity=run_identity,
        frozen_artifact_identities=artifacts,
    )
    original = np.asarray([[0.0, -1.25, 2.5, 8.0, 16.0, 31.0]], dtype=np.float32)
    perturbed = original + np.float32(
        evaluation_module.DEPENDENCY_PERTURBATION_DELTA_NORMALIZED
    )

    write_development_evaluation(
        output,
        [
            synthetic_seed_statistics(
                seed,
                experiment_id=evaluation_module.FORMAL_DEVELOPMENT_EXPERIMENT_ID,
            )
            for seed in (17, 29, 43)
        ],
        base_observation_head_qualification={"passed": True},
        identity_gate_details={"technical_recovery_identity": True},
        dependency_perturbation_evidence={
            "sample_identity_sha256": "0" * 64,
            "original_observation_normalized": original.astype(np.float64),
            "perturbed_observation_normalized": perturbed.astype(np.float64),
            "original_posterior_observation_normalized": np.ones((1, 6)) * 0.05,
            "perturbed_posterior_observation_normalized": np.ones((1, 6)) * 0.055,
        },
        data_access_audit=_data_access_audit(),
        frozen_artifact_identities=artifacts,
        registered_run_identity=run_identity,
        repeat_count=evaluation_module.BOOTSTRAP_REPEAT_COUNT,
        random_seed=evaluation_module.BOOTSTRAP_RANDOM_SEED,
        synthetic_test_mode=False,
        technical_recovery_context=recovery_marker,
    )

    manifest = json.loads(
        (output / "completion_manifest.json").read_text(encoding="utf-8")
    )
    assert manifest["authorized_technical_recovery"] is True
    assert manifest["recovery_attempt_number"] == 2
    assert manifest["current_attempt_development_loader_call_count"] == 1
    assert manifest["cumulative_development_loader_call_count"] == 2
    assert manifest["prior_failed_development_access_attempt_count"] == 1
    assert manifest["original_single_read_contract_satisfied"] is False
    assert manifest["prior_attempt_scientific_result_file_count"] == 0
    assert manifest["held_out_2024_target_access_count"] == 0
    assert manifest["boundary_future_target_access_count"] == 0
    names = {row["name"] for row in manifest["files"]}
    assert evaluation_module.DEVELOPMENT_ACCESS_MARKER_NAME in names
    assert evaluation_module.TECHNICAL_RECOVERY_ACCESS_MARKER_NAME in names
    with pytest.raises(FileExistsError, match="already exists"):
        evaluation_module._require_recovery_output_paths(
            output, fixture["recovery_audit"], contract
        )


def test_recovery_auditor_independently_verifies_authorization_chain(
    tmp_path, monkeypatch
):
    fixture = _build_recovery_contract_fixture(
        tmp_path, monkeypatch, use_real_run_identity=True
    )
    contract = evaluation_module._validated_recovery_contract(
        fixture["contract_path"]
    )
    artifacts = fixture["artifact_identities"]
    run_identity = fixture["run_identity"]
    partial = fixture["recovery_evaluation"].with_name("attempt_002.partial")
    evaluation_module._claim_development_access_before_loader(
        partial,
        registered_run_identity=run_identity,
        frozen_artifact_identities=artifacts,
    )
    recovery_marker = evaluation_module._claim_technical_recovery_access_before_loader(
        partial,
        contract=contract,
        registered_run_identity=run_identity,
        frozen_artifact_identities=artifacts,
    )
    partial.rename(fixture["recovery_evaluation"])
    directory = fixture["recovery_evaluation"]
    marker_path = directory / evaluation_module.TECHNICAL_RECOVERY_ACCESS_MARKER_NAME
    manifest = {
        "technical_recovery_access_marker_sha256": hashlib.sha256(
            marker_path.read_bytes()
        ).hexdigest(),
        "technical_recovery_access_started_at_utc": recovery_marker["claimed_at_utc"],
        "recovery_contract_path": contract["contract_path"],
        "recovery_contract_sha256": contract["contract_sha256"],
    }
    for name in (
        "ORIGINAL_REGISTRY_SHA256",
        "ORIGINAL_ACCESS_MARKER_SHA256",
        "ORIGINAL_STDOUT_SHA256",
        "ORIGINAL_STDERR_SHA256",
        "ORIGINAL_EVALUATOR_SHA256",
    ):
        contract_key = name.lower()
        monkeypatch.setattr(recovery_audit_module, name, contract[contract_key])
    monkeypatch.setattr(
        recovery_audit_module,
        "ORIGINAL_REMOTE_ROOT",
        Path(contract["original_remote_root"]),
    )

    recovery_audit_module._audit_technical_recovery_chain(
        directory, manifest, artifacts, run_identity
    )

    prior_partial = Path(contract["original_evaluation_partial_directory"])
    (prior_partial / "unexpected.csv").write_text("invalid\n", encoding="utf-8")
    with pytest.raises(RuntimeError, match="prior failed-attempt marker drift"):
        recovery_audit_module._audit_technical_recovery_chain(
            directory, manifest, artifacts, run_identity
        )


def test_recovery_auditor_checks_exact_float32_operation_and_no_copy():
    original = np.asarray(
        [[-3.25, -1.125, 0.0, 1.75, 8.5, 20.0]], dtype=np.float32
    )
    perturbed = original + np.float32(0.01)
    posterior = original.astype(np.float64) * 0.5 + 0.2
    posterior_perturbed = posterior + (
        perturbed.astype(np.float64) - original.astype(np.float64)
    ) * 0.5

    result = recovery_audit_module.audit_observation_dependency_perturbation(
        original.astype(np.float64),
        perturbed.astype(np.float64),
        posterior,
        posterior_perturbed,
    )

    assert result["status"] == "passed"
    assert result["exact_model_float32_addition_verified"] is True
    assert result["direct_copy_detected"] is False
    corrupted = perturbed.astype(np.float64)
    corrupted[0, 0] = np.nextafter(corrupted[0, 0], np.inf)
    with pytest.raises(ValueError, match="exact model float32"):
        recovery_audit_module.audit_observation_dependency_perturbation(
            original.astype(np.float64),
            corrupted,
            posterior,
            posterior_perturbed,
        )


def test_recovery_audit_output_is_non_overwriting_and_self_verified(
    tmp_path, monkeypatch
):
    evaluation = tmp_path / "evaluation"
    evaluation.mkdir()
    evaluation_manifest = evaluation / "completion_manifest.json"
    evaluation_manifest.write_text("{}\n", encoding="utf-8")
    evaluation_digest = hashlib.sha256(evaluation_manifest.read_bytes()).hexdigest()
    reconstructed = {
        "schema_version": "1.0",
        "status": "passed_independent_reconstruction",
        "evaluation_manifest_sha256": evaluation_digest,
        "authorized_technical_recovery_audited": True,
        "cumulative_development_loader_call_count": 2,
        "held_out_2024_target_access_count": 0,
        "boundary_future_target_access_count": 0,
    }
    monkeypatch.setattr(
        recovery_audit_module,
        "audit_completed_development_evaluation",
        lambda path: dict(reconstructed),
    )
    audit_directory = tmp_path / "audit"

    report_path = recovery_audit_module.write_independent_audit(
        evaluation, audit_directory
    )

    assert report_path == audit_directory / "independent_audit_report.json"
    manifest = recovery_audit_module.verify_independent_audit_directory(
        audit_directory
    )
    assert manifest["cumulative_development_loader_call_count"] == 2
    assert {path.name for path in audit_directory.iterdir()} == {
        "independent_audit_report.json",
        "completion_manifest.json",
    }
    with pytest.raises(FileExistsError, match="already exists"):
        recovery_audit_module.write_independent_audit(evaluation, audit_directory)


def test_recovery_executor_has_one_loader_call_after_both_preload_claims():
    source = inspect.getsource(
        evaluation_module.execute_authorized_2023_technical_recovery_once
    )
    tree = ast.parse(source)
    calls = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        function = node.func
        name = function.id if isinstance(function, ast.Name) else None
        if name is not None:
            calls.append((name, node.lineno))
    by_name = {}
    for name, line_number in calls:
        by_name.setdefault(name, []).append(line_number)

    assert len(by_name["load_development_data"]) == 1
    loader_line = by_name["load_development_data"][0]
    assert by_name["_claim_development_access_before_loader"][0] < loader_line
    assert by_name["_claim_technical_recovery_access_before_loader"][0] < loader_line
    assert loader_line < by_name["write_development_evaluation"][0]
    assert loader_line < by_name["write_independent_audit"][0]


def test_dependency_evidence_rejects_nonexact_float32_perturbation():
    original_float32 = np.zeros((1, 6), dtype=np.float32)
    perturbed = (
        original_float32
        + np.float32(evaluation_module.DEPENDENCY_PERTURBATION_DELTA_NORMALIZED)
    ).astype(np.float64)
    perturbed[0, 0] = np.nextafter(perturbed[0, 0], np.inf)

    with pytest.raises(ValueError, match=r"exact \+0.01 addition"):
        evaluation_module._validated_dependency_evidence(
            {
                "sample_identity_sha256": "0" * 64,
                "original_observation_normalized": original_float32.astype(
                    np.float64
                ),
                "perturbed_observation_normalized": perturbed,
                "original_posterior_observation_normalized": np.ones((1, 6))
                * 0.05,
                "perturbed_posterior_observation_normalized": np.ones((1, 6))
                * 0.055,
            }
        )


def test_materialized_float32_dependency_evidence_passes_its_validator(
    monkeypatch,
):
    observation = torch.asarray(
        [[-3.25, -1.125, -0.03125, 0.0, 8.5, 20.0]],
        dtype=torch.float32,
    )
    batch = {
        "history": torch.zeros((1, 24, 1), dtype=torch.float32),
        "future_tide": torch.zeros((1, 24, 1), dtype=torch.float32),
        "analysis_observations": observation,
        "targets_t_plus_1_to_t_plus_24": torch.zeros(
            (1, 24, 4), dtype=torch.float32
        ),
        "targets_t_plus_2_to_t_plus_24": torch.zeros(
            (1, 23, 4), dtype=torch.float32
        ),
        "issue_position": torch.asarray([0], dtype=torch.int64),
        "issue_time_beijing": ["2023-01-01T00:00:00+08:00"],
    }
    data = SimpleNamespace(
        normalization=SimpleNamespace(
            retrospective_target=SimpleNamespace(
                mean_m=np.zeros(4), standard_deviation_m=np.ones(4)
            ),
            analysis_stage=SimpleNamespace(
                mean_m=np.zeros(6), standard_deviation_m=np.ones(6)
            ),
        ),
        retrospective_targets_m=np.zeros((25, 4), dtype=np.float64),
        realtime_stages_m=np.zeros((2, 6), dtype=np.float64),
    )

    class FrozenModel(torch.nn.Module):
        def forward(self, history, tide, analysis_observations):
            count = analysis_observations.shape[0]
            target_forecast = torch.zeros(
                (count, 23, 4), dtype=analysis_observations.dtype
            )
            target_analysis = torch.zeros(
                (count, 6, 4), dtype=analysis_observations.dtype
            )
            posterior_observation = (
                analysis_observations[:, None, :].repeat(1, 6, 1) * 0.5
            )
            return {
                "base_deterministic_issue_hour_one_target": torch.zeros(
                    (count, 4), dtype=analysis_observations.dtype
                ),
                "base_deterministic_forecast": target_forecast,
                "unscented_prior_forecast": target_forecast,
                "updated_forecast": target_forecast,
                "analysis_prior_target": target_analysis,
                "analysis_posterior_target": target_analysis,
                "analysis_prior_observation": posterior_observation,
                "analysis_posterior_observation": posterior_observation,
                "analysis_kalman_gain": torch.zeros(
                    (count, 6, 6), dtype=analysis_observations.dtype
                ),
                "analysis_observation_contraction": torch.full(
                    (count, 6), 0.5, dtype=analysis_observations.dtype
                ),
                "analysis_posterior_observation_variance": torch.ones(
                    (count, 6), dtype=analysis_observations.dtype
                ),
                "analysis_posterior_minimum_eigenvalue": torch.ones(
                    count, dtype=analysis_observations.dtype
                ),
                "analysis_spectral_floor": torch.zeros(
                    count, dtype=analysis_observations.dtype
                ),
                "observation_noise_standard_deviation": torch.ones(
                    6, dtype=analysis_observations.dtype
                ),
                "unscented_prior_state_mean": torch.zeros(
                    (count, 32), dtype=analysis_observations.dtype
                ),
                "updated_state_mean": torch.ones(
                    (count, 32), dtype=analysis_observations.dtype
                ),
            }

    frozen_models = {seed: FrozenModel().eval() for seed in (17, 29, 43)}
    monkeypatch.setattr(
        evaluation_module,
        "accumulate_development_sufficient_statistics",
        lambda **kwargs: {"seed": kwargs["seed"]},
    )
    monkeypatch.setattr(
        evaluation_module,
        "combine_seed_sufficient_statistics",
        lambda rows: rows[0],
    )

    _, evidence = evaluation_module.materialize_shared_development_statistics(
        data=data,
        development_dataset=object(),
        frozen_models=frozen_models,
        device="cpu",
        batch_size=32,
        data_loader_factory=lambda *args, **kwargs: [batch],
    )
    validated = evaluation_module._validated_dependency_evidence(evidence)

    expected = (
        observation.numpy()
        + np.float32(
            evaluation_module.DEPENDENCY_PERTURBATION_DELTA_NORMALIZED
        )
    ).astype(np.float64)
    assert np.array_equal(
        validated["perturbed_observation_normalized"], expected
    )


def test_formal_writer_rejects_nonfrozen_bootstrap_settings(tmp_path):
    statistics = [synthetic_seed_statistics(seed) for seed in (17, 29, 43)]
    with pytest.raises(ValueError, match="frozen bootstrap"):
        write_development_evaluation(
            tmp_path / "formal",
            statistics,
            base_observation_head_qualification={"passed": True},
            identity_gate_details={"identity": True},
            dependency_perturbation_evidence={
                "sample_identity_sha256": "0" * 64,
                "original_observation_normalized": np.zeros((1, 6)),
                "perturbed_observation_normalized": np.ones((1, 6)) * 0.01,
                "original_posterior_observation_normalized": np.ones((1, 6)) * 0.05,
                "perturbed_posterior_observation_normalized": np.ones((1, 6)) * 0.055,
            },
            data_access_audit=_data_access_audit(),
            frozen_artifact_identities=_artifact_identities(),
            registered_run_identity=_run_identity(),
            repeat_count=10,
            random_seed=1,
            synthetic_test_mode=False,
        )


def test_formal_writer_reuses_and_manifests_preclaimed_access_marker(tmp_path):
    output = tmp_path / "formal_evaluation"
    artifacts = _artifact_identities()
    run_identity = _run_identity()
    evaluation_module._claim_development_access_before_loader(
        output.with_name(output.name + ".partial"),
        registered_run_identity=run_identity,
        frozen_artifact_identities=artifacts,
    )
    write_development_evaluation(
        output,
        [
            synthetic_seed_statistics(
                seed,
                experiment_id=evaluation_module.FORMAL_DEVELOPMENT_EXPERIMENT_ID,
            )
            for seed in (17, 29, 43)
        ],
        base_observation_head_qualification={"passed": True},
        identity_gate_details={"all_frozen_identities_match": True},
        dependency_perturbation_evidence={
            "sample_identity_sha256": "0" * 64,
            "original_observation_normalized": np.zeros((1, 6)),
            "perturbed_observation_normalized": np.ones((1, 6)) * 0.01,
            "original_posterior_observation_normalized": np.ones((1, 6)) * 0.05,
            "perturbed_posterior_observation_normalized": np.ones((1, 6)) * 0.055,
        },
        data_access_audit=_data_access_audit(),
        frozen_artifact_identities=artifacts,
        registered_run_identity=run_identity,
        repeat_count=20_000,
        random_seed=20_260_901,
        synthetic_test_mode=False,
    )
    marker_path = output / evaluation_module.DEVELOPMENT_ACCESS_MARKER_NAME
    marker = json.loads(marker_path.read_text(encoding="utf-8"))
    manifest = json.loads(
        (output / "completion_manifest.json").read_text(encoding="utf-8")
    )
    assert manifest["development_access_started_before_loader"] is True
    assert manifest["development_access_started_at_utc"] == marker["claimed_at_utc"]
    assert manifest["development_access_marker_sha256"] == hashlib.sha256(
        marker_path.read_bytes()
    ).hexdigest()
    assert evaluation_module.DEVELOPMENT_ACCESS_MARKER_NAME in {
        row["name"] for row in manifest["files"]
    }


@pytest.mark.parametrize(
    "fail_after_loader", (False, True), ids=("complete", "interrupted")
)
def test_formal_runner_loads_development_once_and_shares_one_dataset(
    tmp_path, monkeypatch, fail_after_loader
):
    remote_root = tmp_path / "formal_root"
    input_root = remote_root / "inputs" / "pre2024-four-target-v1"
    input_root.mkdir(parents=True)
    tide_path = remote_root / "run" / "tide_model.json"
    tide_path.parent.mkdir(parents=True)
    tide_path.write_text("{}\n", encoding="utf-8")
    output = remote_root / evaluation_module.FORMAL_EVALUATION_RELATIVE_PATH
    audit_output = remote_root / evaluation_module.FORMAL_AUDIT_RELATIVE_PATH
    smoke = remote_root / "runs/development_evaluation_smoke/attempt_001"
    tasks = []
    artifact_paths = {}
    for seed in (17, 29, 43):
        base_dir = remote_root / f"runs/base/s{seed}/attempt_001"
        head_dir = remote_root / f"runs/observation_head/s{seed}/attempt_001"
        filter_dir = remote_root / f"runs/filter/s{seed}/attempt_001"
        for directory in (base_dir, head_dir, filter_dir):
            directory.mkdir(parents=True)
        base = base_dir / "best_checkpoint.pt"
        head = head_dir / "realtime_observation_head.pt"
        selected_filter = filter_dir / "best_filter_checkpoint.pt"
        base.write_bytes(("base-%d" % seed).encode())
        head.write_bytes(("head-%d" % seed).encode())
        selected_filter.write_bytes(("filter-%d" % seed).encode())
        artifact_paths[seed] = (base, head, selected_filter)
        tasks.extend(
            [
                {
                    "stage": "base_training",
                    "seed": seed,
                    "registered_output_path": str(base_dir),
                },
                {
                    "stage": "observation_head",
                    "seed": seed,
                    "registered_output_path": str(head_dir),
                },
                {
                    "stage": "filter_training",
                    "seed": seed,
                    "registered_output_path": str(filter_dir),
                    "registered_base_checkpoint_path": str(base),
                    "registered_observation_head_path": str(head),
                },
            ]
        )
    post_tasks = [
        {
            "stage": "development_2023_evaluation",
            "registered_smoke_path": str(smoke),
            "registered_output_path": str(output),
        },
        {
            "stage": "independent_audit",
            "registered_output_path": str(audit_output),
            "registered_evaluation_output_path": str(output),
        },
    ]
    registry = {
        "authorization": {
            "development_2023_evaluation_authorized": True,
            "heldout_2024_target_access_authorized": False,
            "formal_command_confirmation": evaluation_module.FORMAL_CONFIRMATION,
        },
        "hpc": {
            "remote_root": str(remote_root),
            "isolated_input_root": str(input_root),
            "tide_model_path": str(tide_path),
        },
        "optimization": {},
        "tasks": tasks,
        "post_training_tasks": post_tasks,
    }
    registry_path = tmp_path / "registry.json"
    registry_path.write_text(json.dumps(registry), encoding="utf-8")

    normalization = data_module.FourSpaceNormalization(
        history_stage=data_module.SpaceNormalization(
            data_module.NORMALIZATION_HISTORY_STAGE,
            np.zeros(6),
            np.ones(6),
            np.ones(6, dtype=np.int64),
        ),
        future_tide=data_module.SpaceNormalization(
            data_module.NORMALIZATION_FUTURE_TIDE,
            np.zeros(1),
            np.ones(1),
            np.ones(1, dtype=np.int64),
        ),
        analysis_stage=data_module.SpaceNormalization(
            data_module.NORMALIZATION_ANALYSIS_STAGE,
            np.zeros(6),
            np.ones(6),
            np.ones(6, dtype=np.int64),
        ),
        retrospective_target=data_module.SpaceNormalization(
            data_module.NORMALIZATION_RETROSPECTIVE_TARGET,
            np.zeros(4),
            np.ones(4),
            np.ones(4, dtype=np.int64),
        ),
    )
    normalization_document = evaluation_module._normalization_document(normalization)
    audit_value = data_module.DataAccessAudit(**_data_access_audit())
    shared_dataset = [object()]
    fake_data = SimpleNamespace(
        normalization=normalization,
        access_audit=audit_value,
    )
    counters = {"load": 0, "build": 0, "materialize": 0}
    event_order = []

    class FrozenModel:
        training = False

        @staticmethod
        def parameters():
            return ()

    monkeypatch.setattr(runner_module, "validate_registry_document", lambda value: None)
    monkeypatch.setattr(
        runner_module,
        "load_registered_post_training_task",
        lambda path, *, stage: (
            registry,
            next(row for row in post_tasks if row["stage"] == stage),
        ),
    )
    monkeypatch.setattr(
        runner_module,
        "verify_output_directory",
        lambda path: {"status": "technical_pass_development_evaluation_smoke"},
    )
    manifest_path = input_root / "four_target_input_manifest.json"
    manifest_path.write_text("{}\n", encoding="utf-8")
    monkeypatch.setattr(
        runner_module,
        "verify_isolated_input_manifest",
        lambda root, document: {
            "manifest_path": str(manifest_path),
            "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        },
    )

    def load_filter(path, *, seed, device):
        base, head, selected_filter = artifact_paths[seed]
        digest = lambda value: hashlib.sha256(value.read_bytes()).hexdigest()
        return FrozenModel(), {
            "base_checkpoint_sha256": digest(base),
            "observation_head_sha256": digest(head),
            "base_normalization": normalization_document,
            "filter_checkpoint_path": str(selected_filter),
            "filter_checkpoint_sha256": digest(selected_filter),
            "filter_completion_manifest_sha256": "%064x" % seed,
            "normalization_sha256": evaluation_module._mapping_sha256(
                normalization_document
            ),
        }

    monkeypatch.setattr(
        runner_module,
        "load_registered_frozen_filter_for_evaluation",
        load_filter,
    )
    monkeypatch.setattr(
        evaluation_module,
        "_read_observation_head_design_diagnostic",
        lambda path, *, seed: {
            "seed": seed,
            "selection_report_path": str(path.parent / "ridge_candidate_diagnostics.json"),
            "selection_report_sha256": "%064x" % (seed + 400),
            "coefficient_float32_sha256": "%064x" % (seed + 500),
            "selected_ridge_strength": 0.1,
            "augmented_design_singular_values": [
                float(value) for value in range(33, 0, -1)
            ],
            "augmented_design_rank": 33,
            "augmented_design_condition_number": 33.0,
        },
    )

    def load_once(root, tide):
        marker_path = output.with_name(output.name + ".partial") / (
            evaluation_module.DEVELOPMENT_ACCESS_MARKER_NAME
        )
        assert marker_path.is_file()
        json.loads(marker_path.read_text(encoding="utf-8"))
        event_order.append("marker_then_loader")
        counters["load"] += 1
        return fake_data

    def build_once(data):
        counters["build"] += 1
        return {
            "training": object(),
            "selection": object(),
            "development_gate": shared_dataset,
        }

    monkeypatch.setattr(data_module, "load_development_data", load_once)
    monkeypatch.setattr(data_module, "build_split_datasets", build_once)
    monkeypatch.setattr(
        data_module, "assert_forbidden_target_access_is_zero", lambda value: None
    )

    def materialize(**kwargs):
        counters["materialize"] += 1
        assert kwargs["development_dataset"] is shared_dataset
        assert set(kwargs["frozen_models"]) == {17, 29, 43}
        if fail_after_loader:
            raise RuntimeError("injected failure after development load")
        return [synthetic_seed_statistics(seed) for seed in (17, 29, 43)], {
            "sample_identity_sha256": "0" * 64,
            "original_observation_normalized": np.zeros((1, 6)),
            "perturbed_observation_normalized": np.ones((1, 6)) * 0.01,
            "original_posterior_observation_normalized": np.ones((1, 6)) * 0.05,
            "perturbed_posterior_observation_normalized": np.ones((1, 6)) * 0.055,
        }

    monkeypatch.setattr(
        evaluation_module, "materialize_shared_development_statistics", materialize
    )
    captured = {}

    def write_evaluation(path, statistics, **kwargs):
        captured["statistics"] = statistics
        captured["kwargs"] = kwargs
        path.mkdir(parents=True)
        (path / "completion_manifest.json").write_text("{}\n", encoding="utf-8")
        return path

    monkeypatch.setattr(evaluation_module, "write_development_evaluation", write_evaluation)

    def write_audit(evaluation, destination):
        destination.mkdir(parents=True)
        report = destination / "independent_audit_report.json"
        report.write_text("{}\n", encoding="utf-8")
        return report

    monkeypatch.setattr(audit_module, "write_independent_audit", write_audit)
    arguments = {
        "registry_path": registry_path,
        "input_root": input_root,
        "tide_model_path": tide_path,
        "output_directory": output,
        "audit_directory": audit_output,
        "device": "cpu",
        "confirmation": evaluation_module.FORMAL_CONFIRMATION,
    }
    if fail_after_loader:
        with pytest.raises(RuntimeError, match="injected failure"):
            execute_frozen_2023_development_evaluation_once(**arguments)
        partial = output.with_name(output.name + ".partial")
        marker_path = partial / evaluation_module.DEVELOPMENT_ACCESS_MARKER_NAME
        marker = json.loads(marker_path.read_text(encoding="utf-8"))
        assert partial.is_dir()
        assert marker["status"] == "development_access_claimed_before_loader"
        assert marker["frozen_artifact_count"] == 9
        assert event_order == ["marker_then_loader"]
        with pytest.raises(FileExistsError, match="already exists"):
            execute_frozen_2023_development_evaluation_once(**arguments)
        assert counters == {"load": 1, "build": 1, "materialize": 1}
        assert event_order == ["marker_then_loader"]
        return

    result = execute_frozen_2023_development_evaluation_once(**arguments)
    assert counters == {"load": 1, "build": 1, "materialize": 1}
    assert event_order == ["marker_then_loader"]
    assert result["development_loader_call_count"] == 1
    assert result["development_dataset_instance_count"] == 1
    assert result["seed_evaluation_count"] == 3
    assert captured["kwargs"]["synthetic_test_mode"] is False
    assert captured["kwargs"]["data_access_audit"] == (
        evaluation_module._validated_data_access_audit(_data_access_audit())
    )
