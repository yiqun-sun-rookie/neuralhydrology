#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Independent audit of the authorized attempt-002 2023 technical recovery.

The audit intentionally does not import the main metric or evaluation module.
It verifies the completion manifest, rebuilds tables, bootstrap intervals,
Holm corrections and gates from the six raw sufficient-statistic CSV files,
and compares every published field with frozen numeric tolerances.

Example:
    python scripts/analysis/audit_zhenjiang_six_source_four_target_d32_gru_ukf_development_recovery_v1.py \
      --evaluation-directory results/example --audit-directory results/example_audit
"""

from __future__ import annotations

import argparse
from collections import defaultdict
import csv
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import torch


SOURCES = (
    "datong",
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
TARGETS = ("nanjing", "zhenjiang", "jiangyin", "xuliujing")
SEEDS = (17, 29, 43)
WINDOWS = (
    ("post_update_1_to_6", tuple(range(1, 7))),
    ("post_update_1_to_12", tuple(range(1, 13))),
    ("post_update_1_to_23", tuple(range(1, 24))),
)
ADJACENT = (
    (0, 0),
    (1, 1),
    (2, 0),
    (2, 2),
    (3, 1),
    (3, 3),
    (4, 2),
    (5, 3),
)
FLOAT32_ABSOLUTE_TOLERANCE = 1e-6
FLOAT32_RELATIVE_TOLERANCE = 1e-6
FLOAT64_ABSOLUTE_TOLERANCE = 1e-12
FLOAT64_RELATIVE_TOLERANCE = 1e-10
FROZEN_BOOTSTRAP_REPEAT_COUNT = 20_000
FROZEN_BOOTSTRAP_RANDOM_SEED = 20_260_901
FROZEN_DEPENDENCY_PERTURBATION_DELTA_NORMALIZED = 0.01
FROZEN_DEVELOPMENT_BYTES_BY_PATH = {
    "dataset_config.json": 2854,
    "realtime_features/datong_realtime_features.csv": 5_485_506,
    "realtime_features/nanjing_realtime_features.csv": 5_452_340,
    "realtime_features/zhenjiang_realtime_features.csv": 5_490_493,
    "realtime_features/jiangyin_realtime_features.csv": 5_451_807,
    "realtime_features/xuliujing_realtime_features.csv": 5_452_448,
    "realtime_features/wusongkou_realtime_features.csv": 5_449_542,
    "retrospective_targets/nanjing_retrospective_targets.csv": 5_453_455,
    "retrospective_targets/zhenjiang_retrospective_targets.csv": 5_491_015,
    "retrospective_targets/jiangyin_retrospective_targets.csv": 5_452_821,
    "retrospective_targets/xuliujing_retrospective_targets.csv": 5_453_528,
}
FROZEN_DEVELOPMENT_CSV_PATHS = frozenset(
    path for path in FROZEN_DEVELOPMENT_BYTES_BY_PATH if path.endswith(".csv")
)
FROZEN_DEVELOPMENT_TARGET_ROWS_BY_PERIOD = {
    "training": 175_296,
    "selection": 35_040,
    "development_gate": 35_040,
    "heldout_or_later": 0,
    "boundary_target": 0,
}
FROZEN_PREFIX_ROWS_PER_CSV = 61_344
FROZEN_PREDEVELOPMENT_ROWS_PER_CSV = 52_584
FROZEN_DEVELOPMENT_FEATURE_BYTES = 4_685_966
FROZEN_DEVELOPMENT_TARGET_BYTES = 3_123_728
FROZEN_DEVELOPMENT_FEATURE_ROWS = 52_560
FROZEN_DEVELOPMENT_TARGET_ROWS = 35_040
FORMAL_DEVELOPMENT_EXPERIMENT_ID = (
    "ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_DIFFERENTIABLE_UKF_V1"
    "_2023_DEVELOPMENT_V1"
)
DEVELOPMENT_ACCESS_MARKER_NAME = "development_access_started.json"
TECHNICAL_RECOVERY_ACCESS_MARKER_NAME = "technical_recovery_access_started.json"
RECOVERY_EXPERIMENT_ID = (
    "ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_DIFFERENTIABLE_UKF_V1"
    "_2023_DEVELOPMENT_TECHNICAL_RECOVERY_ATTEMPT_002_V1"
)
RECOVERY_USER_AUTHORIZATION_TEXT = (
    "同意进行一次且仅一次的 2023 年技术恢复读取，使用新的 `attempt_002`，"
    "继续禁止读取 2024 年目标数据。"
)
ORIGINAL_REMOTE_ROOT = Path(
    "/data1/home/sunyiq/"
    "zhenjiang_six_source_four_target_differentiable_ukf_20260901_r2"
)
ORIGINAL_REGISTRY_SHA256 = (
    "704366cb22eef1d3acb58f4f0524a6e50d49ffa442afcf0fca498fbd21154cb8"
)
ORIGINAL_ACCESS_MARKER_SHA256 = (
    "badf3ee5f8cf3f0d9c5e5771b11385a45a6f22d6355fc43357bc44f2bd364c9e"
)
ORIGINAL_STDOUT_SHA256 = (
    "bcd7cc658a9a1790f07cce392a9b60d9f3338b722af8520f2a20bb61998111c8"
)
ORIGINAL_STDERR_SHA256 = (
    "7ebac31811938324b27f10743850a0b32e981d1b8eb5f0dcc750ce089b60f185"
)
ORIGINAL_EVALUATOR_SHA256 = (
    "f64e5ffcc47061d97f66e28e15ec45f7412b1d8a59455771180c4ef47eab9281"
)
FROZEN_RIDGE_STRENGTHS = (0.0, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1.0)
FROZEN_RIDGE_TIE_TOLERANCE_M = 1e-12

FUTURE_FIELDS = (
    "schema_version",
    "experiment_id",
    "seed",
    "block_id",
    "block_origin_count",
    "source_index",
    "source_station",
    "target_index",
    "target_station",
    "issue_horizon_hour",
    "post_update_lead_hour",
    "cell_count",
    "base_absolute_error_sum_m",
    "prior_absolute_error_sum_m",
    "updated_absolute_error_sum_m",
    "base_squared_error_sum_m2",
    "prior_squared_error_sum_m2",
    "updated_squared_error_sum_m2",
    "updated_minus_prior_absolute_movement_sum_m",
    "target_sum_m",
    "target_squared_sum_m2",
)
OBSERVATION_FIELDS = (
    "schema_version",
    "experiment_id",
    "seed",
    "block_id",
    "block_origin_count",
    "source_index",
    "source_station",
    "cell_count",
    "prior_absolute_residual_sum_m",
    "posterior_absolute_residual_sum_m",
    "innovation_absolute_sum_m",
    "kalman_gain_norm_sum",
    "posterior_observation_variance_sum_normalized",
    "observation_contraction_min",
    "observation_contraction_max",
    "contraction_ratio_values_json",
    "near_zero_prior_count",
    "near_zero_posterior_max_absolute_residual_m",
    "posterior_minimum_eigenvalue_minus_0_99_floor_min",
    "observation_noise_standard_deviation_normalized",
)
TARGET_FIELDS = (
    "schema_version",
    "experiment_id",
    "seed",
    "block_id",
    "block_origin_count",
    "source_index",
    "source_station",
    "target_index",
    "target_station",
    "cell_count",
    "prior_absolute_error_sum_m",
    "posterior_absolute_error_sum_m",
    "prior_squared_error_sum_m2",
    "posterior_squared_error_sum_m2",
    "posterior_minus_prior_absolute_movement_sum_m",
    "target_sum_m",
    "target_squared_sum_m2",
)
STATE_FIELDS = (
    "schema_version",
    "experiment_id",
    "seed",
    "block_id",
    "block_origin_count",
    "source_index",
    "source_station",
    "issue_horizon_hour",
    "post_update_lead_hour",
    "cell_count",
    "state_mean_absolute_difference_sum",
    "state_l2_difference_sum",
)
BASE_QUALIFICATION_FIELDS = (
    "schema_version",
    "experiment_id",
    "seed",
    "block_id",
    "block_origin_count",
    "target_index",
    "target_station",
    "first_six_cell_count",
    "full_twenty_four_cell_count",
    "base_first_six_absolute_error_sum_m",
    "persistence_first_six_absolute_error_sum_m",
    "base_full_twenty_four_absolute_error_sum_m",
    "base_full_twenty_four_squared_error_sum_m2",
    "target_full_twenty_four_sum_m",
    "target_full_twenty_four_squared_sum_m2",
)
OBSERVATION_HEAD_QUALIFICATION_FIELDS = (
    "schema_version",
    "experiment_id",
    "seed",
    "block_id",
    "block_origin_count",
    "source_index",
    "source_station",
    "cell_count",
    "head_absolute_error_sum_m",
    "persistence_absolute_error_sum_m",
    "head_bias_sum_m",
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise RuntimeError("audit cannot read JSON: %s" % path.name) from error


def _read_csv(path: Path) -> List[Dict[str, str]]:
    try:
        with path.open(encoding="utf-8", newline="") as handle:
            return list(csv.DictReader(handle))
    except OSError as error:
        raise RuntimeError("audit cannot read CSV: %s" % path.name) from error


def _int(value: Any, name: str) -> int:
    if isinstance(value, bool):
        raise ValueError("audit integer is Boolean: %s" % name)
    try:
        result = int(value)
    except (TypeError, ValueError) as error:
        raise ValueError("audit integer is invalid: %s" % name) from error
    if isinstance(value, str) and value.strip() != str(result):
        raise ValueError("audit integer text is not canonical: %s" % name)
    return result


def _float(value: Any, name: str) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError("audit float is invalid: %s" % name) from error
    if not math.isfinite(result):
        raise ValueError("audit float is nonfinite: %s" % name)
    return result


def _self(source: int, target: int) -> bool:
    return source in range(1, 5) and target == source - 1


def _boundary(source: int) -> bool:
    return source in (0, 5)


def _typed_rows(
    rows: Iterable[Mapping[str, Any]],
    fields: Sequence[str],
    integer_fields: Sequence[str],
    json_fields: Sequence[str] = (),
) -> List[Dict[str, Any]]:
    result = []
    seen = set()
    for source_row in rows:
        if set(source_row) != set(fields):
            raise RuntimeError("audit sufficient-statistic schema drift")
        row: Dict[str, Any] = {}
        for name in fields:
            if name in integer_fields:
                row[name] = _int(source_row[name], name)
            elif name in json_fields:
                parsed = json.loads(source_row[name])
                if not isinstance(parsed, list) or any(
                    not isinstance(value, (int, float))
                    or not math.isfinite(float(value))
                    for value in parsed
                ):
                    raise RuntimeError("audit diagnostic JSON is invalid")
                row[name] = [float(value) for value in parsed]
            elif name in {
                "schema_version",
                "experiment_id",
                "source_station",
                "target_station",
            }:
                row[name] = source_row[name]
            else:
                row[name] = _float(source_row[name], name)
        if row["schema_version"] != "1.0":
            raise RuntimeError("audit sufficient-statistic version drift")
        if "source_index" in row:
            source = row["source_index"]
            if source not in range(6) or row["source_station"] != SOURCES[source]:
                raise RuntimeError("audit source direction identity drift")
        if "target_index" in row:
            target = row["target_index"]
            if target not in range(4) or row["target_station"] != TARGETS[target]:
                raise RuntimeError("audit target direction identity drift")
        if "post_update_lead_hour" in row:
            if row["issue_horizon_hour"] != row["post_update_lead_hour"] + 1:
                raise RuntimeError("audit horizon alignment drift")
        if row["seed"] not in SEEDS:
            raise RuntimeError("audit seed is invalid")
        count_names = [
            name
            for name in (
                "cell_count",
                "first_six_cell_count",
                "full_twenty_four_cell_count",
            )
            if name in row
        ]
        if not count_names or any(row[name] < 1 for name in count_names):
            raise RuntimeError("audit sufficient-statistic count is invalid")
        key_names = ["experiment_id", "seed", "block_id"]
        if "source_index" in row:
            key_names.append("source_index")
        if "target_index" in row:
            key_names.append("target_index")
        if "post_update_lead_hour" in row:
            key_names.append("post_update_lead_hour")
        key = tuple(row[name] for name in key_names)
        if key in seen:
            raise RuntimeError("audit found a duplicate sufficient-statistic row")
        seen.add(key)
        result.append(row)
    if not result:
        raise RuntimeError("audit sufficient-statistic table is empty")
    return result


def _future_rows(rows: Iterable[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    typed = _typed_rows(
        rows,
        FUTURE_FIELDS,
        (
            "seed",
            "block_id",
            "block_origin_count",
            "source_index",
            "target_index",
            "issue_horizon_hour",
            "post_update_lead_hour",
            "cell_count",
        ),
    )
    for row in typed:
        if row["post_update_lead_hour"] not in range(1, 24):
            raise RuntimeError("audit lead is outside one through twenty-three")
        if row["cell_count"] != row["block_origin_count"]:
            raise RuntimeError("audit block cell count drift")
        for name in FUTURE_FIELDS[12:19] + ("target_squared_sum_m2",):
            if row[name] < 0.0:
                raise RuntimeError("audit nonnegative statistic is negative")
    return typed


def _groups(rows: Sequence[Mapping[str, Any]], names: Sequence[str]):
    result: Dict[Tuple[Any, ...], List[Mapping[str, Any]]] = defaultdict(list)
    for row in rows:
        result[tuple(row[name] for name in names)].append(row)
    return result


def _metric(rows: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    cells = sum(int(row["cell_count"]) for row in rows)
    target_sum = sum(float(row["target_sum_m"]) for row in rows)
    target_square = sum(float(row["target_squared_sum_m2"]) for row in rows)
    sst = max(0.0, target_square - target_sum**2 / cells)
    result: Dict[str, Any] = {
        "cell_count": cells,
        "target_sum_m": target_sum,
        "target_squared_sum_m2": target_square,
        "target_sst_m2": sst,
        "forecast_movement_m": sum(
            float(row["updated_minus_prior_absolute_movement_sum_m"])
            for row in rows
        )
        / cells,
    }
    for branch in ("base", "prior", "updated"):
        absolute = sum(
            float(row[branch + "_absolute_error_sum_m"]) for row in rows
        )
        square = sum(float(row[branch + "_squared_error_sum_m2"]) for row in rows)
        result[branch + "_absolute_error_sum_m"] = absolute
        result[branch + "_squared_error_sum_m2"] = square
        result[branch + "_mae_m"] = absolute / cells
        result[branch + "_rmse_m"] = math.sqrt(square / cells)
        result[branch + "_nse"] = 1.0 - square / sst if sst > 0.0 else None
    covariance = result["base_mae_m"] - result["prior_mae_m"]
    measurement = result["prior_mae_m"] - result["updated_mae_m"]
    total = result["base_mae_m"] - result["updated_mae_m"]
    result.update(
        {
            "covariance_propagation_gain_m": covariance,
            "covariance_propagation_gain_mm": 1000.0 * covariance,
            "measurement_update_gain_m": measurement,
            "measurement_update_gain_mm": 1000.0 * measurement,
            "measurement_update_relative_gain_percent": (
                100.0 * measurement / result["prior_mae_m"]
                if result["prior_mae_m"] != 0.0
                else None
            ),
            "measurement_update_relative_gain_status": (
                "defined"
                if result["prior_mae_m"] != 0.0
                else "undefined_zero_baseline"
            ),
            "total_gain_m": total,
            "total_gain_mm": 1000.0 * total,
            "gain_decomposition_residual_m": total - covariance - measurement,
        }
    )
    return result


def _lead_table(rows: Sequence[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    result = []
    for key, group in sorted(
        _groups(rows, ("seed", "source_index", "target_index", "post_update_lead_hour")).items()
    ):
        seed, source, target, lead = key
        result.append(
            {
                "seed": seed,
                "source_index": source,
                "source_station": SOURCES[source],
                "target_index": target,
                "target_station": TARGETS[target],
                "is_self": _self(source, target),
                "is_boundary_source": _boundary(source),
                "issue_horizon_hour": lead + 1,
                "post_update_lead_hour": lead,
                **_metric(group),
            }
        )
    return result


def _window_table(rows: Sequence[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    result = []
    scopes = [
        *(("seed_%d" % seed, (seed,)) for seed in SEEDS),
        ("pooled_three_seeds", SEEDS),
    ]
    for scope, seeds in scopes:
        for source in range(6):
            for target in range(4):
                for name, leads in WINDOWS:
                    selected = [
                        row
                        for row in rows
                        if row["seed"] in seeds
                        and row["source_index"] == source
                        and row["target_index"] == target
                        and row["post_update_lead_hour"] in leads
                    ]
                    if not selected:
                        continue
                    result.append(
                        {
                            "scope": scope,
                            "seed": seeds[0] if len(seeds) == 1 else None,
                            "source_index": source,
                            "source_station": SOURCES[source],
                            "target_index": target,
                            "target_station": TARGETS[target],
                            "is_self": _self(source, target),
                            "is_boundary_source": _boundary(source),
                            "window_name": name,
                            "issue_horizon_start": min(leads) + 1,
                            "issue_horizon_end": max(leads) + 1,
                            "post_update_lead_start": min(leads),
                            "post_update_lead_end": max(leads),
                            **_metric(selected),
                        }
                    )
    return result


def _matrices(window_rows: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    selected = [
        dict(row)
        for row in window_rows
        if row["scope"] == "pooled_three_seeds"
        and row["window_name"] == "post_update_1_to_6"
    ]
    full = []
    for row in sorted(selected, key=lambda value: (value["source_index"], value["target_index"])):
        source = row["source_index"]
        target = row["target_index"]
        if source in range(1, 5):
            internal = source - 1
            if internal == target:
                part = "diagonal_self"
            elif internal < target:
                part = "upper_upstream_source_to_downstream_target"
            else:
                part = "lower_downstream_source_to_upstream_target"
        else:
            part = "boundary_source"
        row.update(
            {
                "matrix_row": source,
                "matrix_column": target,
                "matrix_part": part,
                "is_adjacent_direction": (source, target) in ADJACENT,
            }
        )
        full.append(row)
    return {
        "full": full,
        "internal": [row for row in full if row["source_index"] in range(1, 5)],
        "boundary": [row for row in full if row["source_index"] in (0, 5)],
    }


def _holm(values: Sequence[float]) -> Tuple[List[float], List[bool]]:
    order = sorted(range(len(values)), key=lambda index: (values[index], index))
    adjusted = [0.0] * len(values)
    rejected = [False] * len(values)
    running = 0.0
    continuing = True
    for rank, original in enumerate(order):
        running = max(running, (len(values) - rank) * values[original])
        adjusted[original] = min(1.0, running)
        rejected[original] = continuing and values[original] <= 0.05 / (
            len(values) - rank
        )
        if not rejected[original]:
            continuing = False
    return adjusted, rejected


def _quantiles(values: np.ndarray) -> Tuple[float, float, float]:
    one = float(np.quantile(values, 0.05, method="linear"))
    low, high = np.quantile(values, (0.025, 0.975), method="linear")
    return one, float(low), float(high)


def _bootstrap(
    rows: Sequence[Mapping[str, Any]], repeat_count: int, random_seed: int
) -> Dict[str, Any]:
    primary = [row for row in rows if row["post_update_lead_hour"] in range(1, 7)]
    blocks = sorted({row["block_id"] for row in primary})
    position = {value: index for index, value in enumerate(blocks)}
    shape = (3, len(blocks), 6, 4)
    base = np.zeros(shape)
    prior = np.zeros(shape)
    updated = np.zeros(shape)
    movement = np.zeros(shape)
    cells = np.zeros(shape, dtype=np.int64)
    counts = np.zeros(shape, dtype=np.int64)
    for row in primary:
        index = (
            SEEDS.index(row["seed"]),
            position[row["block_id"]],
            row["source_index"],
            row["target_index"],
        )
        base[index] += row["base_absolute_error_sum_m"]
        prior[index] += row["prior_absolute_error_sum_m"]
        updated[index] += row["updated_absolute_error_sum_m"]
        movement[index] += row["updated_minus_prior_absolute_movement_sum_m"]
        cells[index] += row["cell_count"]
        counts[index] += 1
    if bool((counts != 6).any()) or bool((cells <= 0).any()):
        raise RuntimeError("audit bootstrap grid is incomplete")
    generator = np.random.Generator(np.random.PCG64(random_seed))
    seed_draws = generator.integers(0, 3, size=(repeat_count, 3), endpoint=False)
    block_draws = generator.integers(
        0, len(blocks), size=(repeat_count, len(blocks)), endpoint=False
    )
    cell_rows = []
    measurement_arrays = {}
    total_arrays = {}
    for source in range(6):
        for target in range(4):
            index = (seed_draws[:, :, None], block_draws[:, None, :], source, target)
            denominator = cells[index].sum(axis=(1, 2))
            base_draw = base[index].sum(axis=(1, 2))
            prior_draw = prior[index].sum(axis=(1, 2))
            updated_draw = updated[index].sum(axis=(1, 2))
            measurement = (prior_draw - updated_draw) / denominator
            total = (base_draw - updated_draw) / denominator
            measurement_arrays[(source, target)] = measurement
            total_arrays[(source, target)] = total
            one, low, high = _quantiles(measurement)
            total_one, _, _ = _quantiles(total)
            point_cells = cells[:, :, source, target].sum()
            point_covariance = float(
                (base[:, :, source, target].sum() - prior[:, :, source, target].sum())
                / point_cells
            )
            point_measurement = float(
                (prior[:, :, source, target].sum() - updated[:, :, source, target].sum())
                / point_cells
            )
            point_total = float(
                (base[:, :, source, target].sum() - updated[:, :, source, target].sum())
                / point_cells
            )
            cell_rows.append(
                {
                    "source_index": source,
                    "source_station": SOURCES[source],
                    "target_index": target,
                    "target_station": TARGETS[target],
                    "is_self": _self(source, target),
                    "is_boundary_source": _boundary(source),
                    "point_covariance_propagation_gain_m": point_covariance,
                    "point_measurement_update_gain_m": point_measurement,
                    "point_total_gain_m": point_total,
                    "point_gain_decomposition_residual_m": (
                        point_total - point_covariance - point_measurement
                    ),
                    "point_forecast_movement_m": float(
                        movement[:, :, source, target].sum() / point_cells
                    ),
                    "measurement_gain_one_sided_95_lower_m": one,
                    "measurement_gain_two_sided_95_lower_m": low,
                    "measurement_gain_two_sided_95_upper_m": high,
                    "measurement_gain_one_sided_p_value": float(
                        (1 + np.count_nonzero(measurement <= 0.0))
                        / (repeat_count + 1)
                    ),
                    "total_gain_one_sided_95_lower_m": total_one,
                }
            )
    cross = [
        (source, target)
        for source in range(6)
        for target in range(4)
        if not _self(source, target)
    ]
    internal = [key for key in cross if key[0] in range(1, 5)]
    boundary = [key for key in cross if key[0] in (0, 5)]
    lookup = {(row["source_index"], row["target_index"]): row for row in cell_rows}

    def macro(keys, name):
        measurement = np.stack([measurement_arrays[key] for key in keys], axis=1).mean(axis=1)
        total = np.stack([total_arrays[key] for key in keys], axis=1).mean(axis=1)
        one, low, high = _quantiles(measurement)
        return {
            "name": name,
            "cell_count": len(keys),
            "point_measurement_update_gain_m": float(
                np.mean([lookup[key]["point_measurement_update_gain_m"] for key in keys])
            ),
            "point_total_gain_m": float(
                np.mean([lookup[key]["point_total_gain_m"] for key in keys])
            ),
            "measurement_gain_one_sided_95_lower_m": one,
            "measurement_gain_two_sided_95_lower_m": low,
            "measurement_gain_two_sided_95_upper_m": high,
            "measurement_gain_one_sided_p_value": float(
                (1 + np.count_nonzero(measurement <= 0.0)) / (repeat_count + 1)
            ),
            "bootstrap_total_gain_mean_m": float(total.mean()),
        }

    columns = [
        macro([key for key in cross if key[1] == target], "target_" + TARGETS[target])
        for target in range(4)
    ]
    internal_rows = [row for row in cell_rows if row["source_index"] in range(1, 5) and not row["is_self"]]
    boundary_rows = [row for row in cell_rows if row["is_boundary_source"]]
    for family, family_rows in (("internal_12", internal_rows), ("boundary_8", boundary_rows)):
        adjusted, rejected = _holm(
            [row["measurement_gain_one_sided_p_value"] for row in family_rows]
        )
        for row, adjusted_p, reject in zip(family_rows, adjusted, rejected):
            row["holm_family"] = family
            row["holm_adjusted_one_sided_p_value"] = adjusted_p
            row["holm_reject_at_0_05"] = reject
            row["direction_stable_support"] = bool(
                reject and row["measurement_gain_one_sided_95_lower_m"] > 0.0
            )
    return {
        "schema_version": "1.0",
        "sampling": {
            "repeat_count": repeat_count,
            "bit_generator": "PCG64",
            "random_seed": random_seed,
            "seed_draw_count": 3,
            "calendar_block_draw_count": len(blocks),
            "seed_values": list(SEEDS),
            "nonempty_block_ids": blocks,
            "shared_across_all_cells_leads_and_branches": True,
            "quantile_method": "linear",
        },
        "cell_summaries": cell_rows,
        "cross_20_macro": macro(cross, "cross_20"),
        "internal_12_macro": macro(internal, "internal_12"),
        "boundary_8_macro": macro(boundary, "boundary_8"),
        "target_column_cross_macros": columns,
    }


def _forecast_decision(window_rows, bootstrap):
    primary = [row for row in window_rows if row["window_name"] == "post_update_1_to_6"]
    lookup = {(row["scope"], row["source_index"], row["target_index"]): row for row in primary}
    self_rows = []
    for target in range(4):
        source = target + 1
        pooled = lookup[("pooled_three_seeds", source, target)]
        positive = sum(
            lookup[("seed_%d" % seed, source, target)]["measurement_update_gain_m"] > 0.0
            for seed in SEEDS
        )
        self_rows.append(
            {
                "source_index": source,
                "target_index": target,
                "point_gain_m": pooled["measurement_update_gain_m"],
                "positive_seed_count": positive,
                "pass": bool(pooled["measurement_update_gain_m"] > 0.0 and positive >= 2),
            }
        )
    cells = {(row["source_index"], row["target_index"]): row for row in bootstrap["cell_summaries"]}
    adjacent = []
    for key in ADJACENT:
        row = cells[key]
        adjacent.append(
            {
                "source_index": key[0],
                "target_index": key[1],
                "movement_m": row["point_forecast_movement_m"],
                "gain_m": row["point_measurement_update_gain_m"],
                "movement_above_numerical_tolerance": bool(row["point_forecast_movement_m"] > 1e-6),
                "gain_positive": bool(row["point_measurement_update_gain_m"] > 0.0),
            }
        )
    cross = bootstrap["cross_20_macro"]
    internal = bootstrap["internal_12_macro"]
    boundary = bootstrap["boundary_8_macro"]
    gates = {
        "four_self_cells_pass": all(row["pass"] for row in self_rows),
        "cross_20_measurement_lower_strictly_positive": cross["measurement_gain_one_sided_95_lower_m"] > 0.0,
        "cross_20_total_point_strictly_positive": cross["point_total_gain_m"] > 0.0,
        "internal_12_point_strictly_positive": internal["point_measurement_update_gain_m"] > 0.0,
        "boundary_8_point_strictly_positive": boundary["point_measurement_update_gain_m"] > 0.0,
        "four_target_columns_strictly_positive": all(
            row["point_measurement_update_gain_m"] > 0.0
            for row in bootstrap["target_column_cross_macros"]
        ),
        "eight_adjacent_movements_above_1e_6_m": all(row["movement_above_numerical_tolerance"] for row in adjacent),
        "at_least_six_adjacent_gains_positive": sum(row["gain_positive"] for row in adjacent) >= 6,
    }
    self_forecast_gate_pass = gates["four_self_cells_pass"]
    cross_station_gate_pass = all(
        value
        for name, value in gates.items()
        if name != "four_self_cells_pass"
    )
    if not (gates["cross_20_measurement_lower_strictly_positive"] and gates["cross_20_total_point_strictly_positive"]):
        cross_station_status = "scientific_direction_fail"
    elif cross_station_gate_pass:
        cross_station_status = "statistical_direction_pass_practical_magnitude_not_assessed"
    else:
        cross_station_status = "local_cross_station_effect_only"
    if cross_station_status != "statistical_direction_pass_practical_magnitude_not_assessed":
        status = cross_station_status
    elif not self_forecast_gate_pass:
        status = "cross_station_pass_self_forecast_fail"
    else:
        status = cross_station_status
    return {
        "schema_version": "1.0",
        "status": status,
        "cross_station_status": cross_station_status,
        "self_forecast_gate_pass": self_forecast_gate_pass,
        "cross_station_gate_pass": cross_station_gate_pass,
        "forecast_gate_pass": bool(self_forecast_gate_pass and cross_station_gate_pass),
        "self_cells": self_rows,
        "adjacent_directions": adjacent,
        "gates": gates,
        "practical_magnitude_gate": "not_frozen",
    }


def _observation_summary(rows, repeat_count, random_seed):
    blocks = sorted({row["block_id"] for row in rows})
    position = {value: index for index, value in enumerate(blocks)}
    prior = np.zeros((3, len(blocks), 6))
    posterior = np.zeros_like(prior)
    cells = np.zeros_like(prior, dtype=np.int64)
    ratios = {source: [] for source in range(6)}
    diagnostics = {source: [] for source in range(6)}
    for row in rows:
        index = (SEEDS.index(row["seed"]), position[row["block_id"]], row["source_index"])
        prior[index] += row["prior_absolute_residual_sum_m"]
        posterior[index] += row["posterior_absolute_residual_sum_m"]
        cells[index] += row["cell_count"]
        ratios[row["source_index"]].extend(row["contraction_ratio_values_json"])
        diagnostics[row["source_index"]].append(row)
    if bool((cells <= 0).any()):
        raise RuntimeError("audit observation grid is incomplete")
    generator = np.random.Generator(np.random.PCG64(random_seed))
    seed_draws = generator.integers(0, 3, size=(repeat_count, 3), endpoint=False)
    block_draws = generator.integers(0, len(blocks), size=(repeat_count, len(blocks)), endpoint=False)
    result = []
    for source in range(6):
        index = (seed_draws[:, :, None], block_draws[:, None, :], source)
        delta = (posterior[index].sum(axis=(1, 2)) - prior[index].sum(axis=(1, 2))) / cells[index].sum(axis=(1, 2))
        total = int(cells[:, :, source].sum())
        prior_mae = float(prior[:, :, source].sum() / total)
        posterior_mae = float(posterior[:, :, source].sum() / total)
        source_rows = diagnostics[source]
        median = float(np.median(ratios[source])) if ratios[source] else None
        row = {
            "source_index": source,
            "source_station": SOURCES[source],
            "cell_count": total,
            "prior_mae_m": prior_mae,
            "posterior_mae_m": posterior_mae,
            "posterior_minus_prior_mae_m": posterior_mae - prior_mae,
            "posterior_minus_prior_one_sided_95_upper_m": float(np.quantile(delta, 0.95, method="linear")),
            "contraction_ratio_median": median,
            "contraction_ratio_count": len(ratios[source]),
            "near_zero_prior_count": sum(row["near_zero_prior_count"] for row in source_rows),
            "near_zero_posterior_max_absolute_residual_m": max(row["near_zero_posterior_max_absolute_residual_m"] for row in source_rows),
            "observation_contraction_min": min(row["observation_contraction_min"] for row in source_rows),
            "observation_contraction_max": max(row["observation_contraction_max"] for row in source_rows),
            "posterior_minimum_eigenvalue_minus_0_99_floor_min": min(row["posterior_minimum_eigenvalue_minus_0_99_floor_min"] for row in source_rows),
            "observation_noise_standard_deviation_normalized": source_rows[0]["observation_noise_standard_deviation_normalized"],
        }
        row["pass"] = bool(
            0.0 < row["observation_contraction_min"]
            and row["observation_contraction_max"] < 1.0
            and posterior_mae < prior_mae
            and row["posterior_minus_prior_one_sided_95_upper_m"] < 0.0
            and median is not None and 0.0 < median < 1.0
            and row["near_zero_posterior_max_absolute_residual_m"] <= 1e-6
            and row["posterior_minimum_eigenvalue_minus_0_99_floor_min"] >= 0.0
            and row["observation_noise_standard_deviation_normalized"] > 1e-4
            and posterior_mae > 1e-6
        )
        result.append(row)
    return result


def _analysis_target(rows):
    result = []
    for source in range(6):
        for target in range(4):
            selected = [row for row in rows if row["source_index"] == source and row["target_index"] == target]
            cells = sum(row["cell_count"] for row in selected)
            prior = sum(row["prior_absolute_error_sum_m"] for row in selected)
            posterior = sum(row["posterior_absolute_error_sum_m"] for row in selected)
            result.append(
                {
                    "source_index": source,
                    "source_station": SOURCES[source],
                    "target_index": target,
                    "target_station": TARGETS[target],
                    "cell_count": cells,
                    "prior_mae_m": prior / cells,
                    "posterior_mae_m": posterior / cells,
                    "analysis_gain_m": (prior - posterior) / cells,
                    "analysis_gain_mm": 1000.0 * (prior - posterior) / cells,
                    "analysis_movement_m": sum(row["posterior_minus_prior_absolute_movement_sum_m"] for row in selected) / cells,
                }
            )
    return result


def _state(rows):
    result = []
    for source in range(6):
        for lead in range(1, 24):
            selected = [row for row in rows if row["source_index"] == source and row["post_update_lead_hour"] == lead]
            cells = sum(row["cell_count"] for row in selected)
            result.append(
                {
                    "source_index": source,
                    "source_station": SOURCES[source],
                    "issue_horizon_hour": lead + 1,
                    "post_update_lead_hour": lead,
                    "cell_count": cells,
                    "state_mean_absolute_difference": sum(row["state_mean_absolute_difference_sum"] for row in selected) / cells,
                    "state_l2_difference": sum(row["state_l2_difference_sum"] for row in selected) / cells,
                }
            )
    return result


def _qualification(base_rows, observation_rows, observation_head_diagnostics):
    target_results = []
    for seed in SEEDS:
        for target in range(4):
            selected = [
                row
                for row in base_rows
                if row["seed"] == seed and row["target_index"] == target
            ]
            if not selected:
                raise RuntimeError("audit base qualification grid is incomplete")
            first_cells = sum(row["first_six_cell_count"] for row in selected)
            full_cells = sum(
                row["full_twenty_four_cell_count"] for row in selected
            )
            base_first = sum(
                row["base_first_six_absolute_error_sum_m"] for row in selected
            )
            persistence = sum(
                row["persistence_first_six_absolute_error_sum_m"]
                for row in selected
            )
            full_absolute = sum(
                row["base_full_twenty_four_absolute_error_sum_m"]
                for row in selected
            )
            full_squared = sum(
                row["base_full_twenty_four_squared_error_sum_m2"]
                for row in selected
            )
            target_sum = sum(
                row["target_full_twenty_four_sum_m"] for row in selected
            )
            target_squared = sum(
                row["target_full_twenty_four_squared_sum_m2"]
                for row in selected
            )
            sst = max(0.0, target_squared - target_sum**2 / full_cells)
            nse = 1.0 - full_squared / sst if sst > 0.0 else None
            result = {
                "seed": seed,
                "target_index": target,
                "target_station": TARGETS[target],
                "first_six_cell_count": first_cells,
                "base_first_six_mae_m": base_first / first_cells,
                "persistence_first_six_mae_m": persistence / first_cells,
                "full_twenty_four_cell_count": full_cells,
                "base_full_twenty_four_mae_m": full_absolute / full_cells,
                "base_full_twenty_four_rmse_m": math.sqrt(
                    full_squared / full_cells
                ),
                "base_full_twenty_four_nse": nse,
            }
            result["passed"] = bool(
                result["base_first_six_mae_m"]
                < result["persistence_first_six_mae_m"]
                and nse is not None
                and nse > 0.0
            )
            target_results.append(result)
    observation_results = []
    for seed in SEEDS:
        for source in range(6):
            selected = [
                row
                for row in observation_rows
                if row["seed"] == seed and row["source_index"] == source
            ]
            if not selected:
                raise RuntimeError(
                    "audit observation-head qualification grid is incomplete"
                )
            cells = sum(row["cell_count"] for row in selected)
            head = sum(row["head_absolute_error_sum_m"] for row in selected)
            persistence = sum(
                row["persistence_absolute_error_sum_m"] for row in selected
            )
            bias = sum(row["head_bias_sum_m"] for row in selected)
            result = {
                "seed": seed,
                "source_index": source,
                "source_station": SOURCES[source],
                "cell_count": cells,
                "head_mae_m": head / cells,
                "persistence_mae_m": persistence / cells,
                "head_bias_m": bias / cells,
            }
            result["passed"] = bool(
                result["head_mae_m"] < result["persistence_mae_m"]
            )
            observation_results.append(result)
    target_pooled_results = []
    for target in range(4):
        selected = [row for row in base_rows if row["target_index"] == target]
        first_cells = sum(row["first_six_cell_count"] for row in selected)
        full_cells = sum(row["full_twenty_four_cell_count"] for row in selected)
        base_first = sum(
            row["base_first_six_absolute_error_sum_m"] for row in selected
        )
        persistence = sum(
            row["persistence_first_six_absolute_error_sum_m"] for row in selected
        )
        full_absolute = sum(
            row["base_full_twenty_four_absolute_error_sum_m"] for row in selected
        )
        full_squared = sum(
            row["base_full_twenty_four_squared_error_sum_m2"] for row in selected
        )
        target_sum = sum(row["target_full_twenty_four_sum_m"] for row in selected)
        target_squared = sum(
            row["target_full_twenty_four_squared_sum_m2"] for row in selected
        )
        sst = max(0.0, target_squared - target_sum**2 / full_cells)
        nse = 1.0 - full_squared / sst if sst > 0.0 else None
        result = {
            "target_index": target,
            "target_station": TARGETS[target],
            "first_six_cell_count": first_cells,
            "base_first_six_mae_m": base_first / first_cells,
            "persistence_first_six_mae_m": persistence / first_cells,
            "full_twenty_four_cell_count": full_cells,
            "base_full_twenty_four_mae_m": full_absolute / full_cells,
            "base_full_twenty_four_rmse_m": math.sqrt(full_squared / full_cells),
            "base_full_twenty_four_nse": nse,
        }
        result["passed"] = bool(
            result["base_first_six_mae_m"]
            < result["persistence_first_six_mae_m"]
            and nse is not None
            and nse > 0.0
        )
        target_pooled_results.append(result)
    observation_pooled_results = []
    for source in range(6):
        selected = [
            row for row in observation_rows if row["source_index"] == source
        ]
        cells = sum(row["cell_count"] for row in selected)
        head = sum(row["head_absolute_error_sum_m"] for row in selected)
        persistence = sum(
            row["persistence_absolute_error_sum_m"] for row in selected
        )
        bias = sum(row["head_bias_sum_m"] for row in selected)
        result = {
            "source_index": source,
            "source_station": SOURCES[source],
            "cell_count": cells,
            "head_mae_m": head / cells,
            "persistence_mae_m": persistence / cells,
            "head_bias_m": bias / cells,
        }
        result["passed"] = bool(result["head_mae_m"] < result["persistence_mae_m"])
        observation_pooled_results.append(result)
    gates = {
        "all_four_pooled_targets_beat_persistence_and_have_positive_nse": all(
            row["passed"] for row in target_pooled_results
        ),
        "all_six_pooled_observation_heads_beat_one_hour_persistence": all(
            row["passed"] for row in observation_pooled_results
        ),
    }
    return {
        "schema_version": "1.0",
        "qualification_gate_contract": {
            "aggregation": "pooled_equal_weight_three_seeds",
            "hard_target_gate_count": 4,
            "hard_source_gate_count": 6,
            "per_seed_results_are_diagnostics_only": True,
        },
        "passed": all(gates.values()),
        "target_pooled_results": target_pooled_results,
        "observation_head_pooled_results": observation_pooled_results,
        "target_seed_results": target_results,
        "observation_head_seed_results": observation_results,
        "observation_head_design_diagnostics": observation_head_diagnostics,
        "gates": gates,
    }


def _reciprocal(matrix):
    lookup = {(row["source_index"], row["target_index"]): row for row in matrix}
    result = []
    for upstream in range(4):
        for downstream in range(upstream + 1, 4):
            forward = lookup[(upstream + 1, downstream)]
            reverse = lookup[(downstream + 1, upstream)]
            result.append(
                {
                    "upstream_station": TARGETS[upstream],
                    "downstream_station": TARGETS[downstream],
                    "upstream_to_downstream_gain_m": forward["measurement_update_gain_m"],
                    "downstream_to_upstream_gain_m": reverse["measurement_update_gain_m"],
                    "upstream_to_downstream_movement_m": forward["forecast_movement_m"],
                    "downstream_to_upstream_movement_m": reverse["forecast_movement_m"],
                }
            )
    return result


def _grid(
    future,
    observations,
    targets,
    states,
    base_qualification,
    observation_head_qualification,
):
    blocks = sorted({row["block_id"] for row in future})
    block_count = len(blocks)
    expected = {
        "future_rows_per_seed": block_count * 6 * 4 * 23,
        "analysis_observation_rows_per_seed": block_count * 6,
        "analysis_target_rows_per_seed": block_count * 6 * 4,
        "state_difference_rows_per_seed": block_count * 6 * 23,
        "base_qualification_rows_per_seed": block_count * 4,
        "observation_head_qualification_rows_per_seed": block_count * 6,
        "source_target_lead_summary_rows": 1656,
    }
    contracts = (
        (
            "future",
            future,
            lambda row: (
                row["seed"],
                row["block_id"],
                row["source_index"],
                row["target_index"],
                row["post_update_lead_hour"],
            ),
            block_count * 6 * 4 * 23 * 3,
        ),
        (
            "observation",
            observations,
            lambda row: (row["seed"], row["block_id"], row["source_index"]),
            block_count * 6 * 3,
        ),
        (
            "target",
            targets,
            lambda row: (
                row["seed"],
                row["block_id"],
                row["source_index"],
                row["target_index"],
            ),
            block_count * 6 * 4 * 3,
        ),
        (
            "state",
            states,
            lambda row: (
                row["seed"],
                row["block_id"],
                row["source_index"],
                row["post_update_lead_hour"],
            ),
            block_count * 6 * 23 * 3,
        ),
        (
            "base qualification",
            base_qualification,
            lambda row: (row["seed"], row["block_id"], row["target_index"]),
            block_count * 4 * 3,
        ),
        (
            "observation-head qualification",
            observation_head_qualification,
            lambda row: (row["seed"], row["block_id"], row["source_index"]),
            block_count * 6 * 3,
        ),
    )
    for name, table, key_function, expected_count in contracts:
        keys = [key_function(row) for row in table]
        if len(keys) != expected_count or len(set(keys)) != expected_count:
            raise RuntimeError("audit %s exact unique key grid differs" % name)
        if sorted({key[1] for key in keys}) != blocks:
            raise RuntimeError("audit %s calendar block grid differs" % name)
    for seed in SEEDS:
        actual = (
            sum(row["seed"] == seed for row in future),
            sum(row["seed"] == seed for row in observations),
            sum(row["seed"] == seed for row in targets),
            sum(row["seed"] == seed for row in states),
            sum(row["seed"] == seed for row in base_qualification),
            sum(row["seed"] == seed for row in observation_head_qualification),
        )
        wanted = (
            expected["future_rows_per_seed"],
            expected["analysis_observation_rows_per_seed"],
            expected["analysis_target_rows_per_seed"],
            expected["state_difference_rows_per_seed"],
            expected["base_qualification_rows_per_seed"],
            expected["observation_head_qualification_rows_per_seed"],
        )
        if actual != wanted:
            raise RuntimeError("audit B-scaled sufficient-statistic grid differs")
    return {
        "schema_version": "1.0",
        "status": "verified",
        "seed_values": list(SEEDS),
        "nonempty_block_ids": blocks,
        "nonempty_block_count": block_count,
        **expected,
    }


def _coerce_actual(value: str, expected: Any) -> Any:
    if expected is None:
        if value != "":
            raise RuntimeError("audit expected an empty CSV value")
        return None
    if isinstance(expected, bool):
        if value not in {"True", "False"}:
            raise RuntimeError("audit Boolean text is invalid")
        return value == "True"
    if isinstance(expected, int):
        return _int(value, "CSV integer")
    if isinstance(expected, float):
        return _float(value, "CSV float")
    return value


def _compare_value(actual: Any, expected: Any, context: str) -> None:
    if isinstance(expected, Mapping):
        if not isinstance(actual, Mapping) or set(actual) != set(expected):
            raise RuntimeError("audit mapping keys differ: %s" % context)
        for key in expected:
            _compare_value(actual[key], expected[key], context + "." + str(key))
    elif isinstance(expected, list):
        if not isinstance(actual, list) or len(actual) != len(expected):
            raise RuntimeError("audit list length differs: %s" % context)
        for index, (left, right) in enumerate(zip(actual, expected)):
            _compare_value(left, right, "%s[%d]" % (context, index))
    elif isinstance(expected, bool) or expected is None or isinstance(expected, str):
        if actual != expected:
            raise RuntimeError("audit exact value differs: %s" % context)
    elif isinstance(expected, int):
        if type(actual) is not int or actual != expected:
            raise RuntimeError("audit integer differs: %s" % context)
    elif isinstance(expected, float):
        if not isinstance(actual, (int, float)) or not math.isclose(
            float(actual),
            expected,
            abs_tol=FLOAT64_ABSOLUTE_TOLERANCE,
            rel_tol=FLOAT64_RELATIVE_TOLERANCE,
        ):
            raise RuntimeError("audit float differs: %s" % context)
    else:
        raise RuntimeError("audit encountered an unsupported value type")


def _compare_csv(path: Path, expected: Sequence[Mapping[str, Any]]) -> None:
    actual = _read_csv(path)
    if len(actual) != len(expected):
        raise RuntimeError("audit CSV row count differs: %s" % path.name)
    for index, (left, right) in enumerate(zip(actual, expected)):
        if set(left) != set(right):
            raise RuntimeError("audit CSV fields differ: %s" % path.name)
        converted = {key: _coerce_actual(left[key], right[key]) for key in right}
        _compare_value(converted, right, "%s[%d]" % (path.name, index))


def _audit_technical_recovery_chain(
    directory: Path,
    manifest: Mapping[str, Any],
    artifact_rows: Sequence[Mapping[str, Any]],
    run_identity: Mapping[str, Any],
) -> None:
    """Independently prove authorization, cumulative counts and prior failure."""

    marker_path = directory / TECHNICAL_RECOVERY_ACCESS_MARKER_NAME
    marker_digest = manifest.get("technical_recovery_access_marker_sha256")
    if (
        not marker_path.is_file()
        or marker_path.is_symlink()
        or not isinstance(marker_digest, str)
        or _sha256(marker_path) != marker_digest
    ):
        raise RuntimeError("audit technical recovery access-marker identity drift")
    marker = _read_json(marker_path)
    required_marker = {
        "schema_version",
        "status",
        "recovery_experiment_id",
        "claimed_at_utc",
        "evaluation_partial_directory",
        "recovery_contract_path",
        "recovery_contract_sha256",
        "user_authorization_text",
        "authorized_technical_recovery",
        "recovery_attempt_number",
        "current_attempt_development_loader_call_count",
        "cumulative_development_loader_call_count",
        "prior_failed_development_access_attempt_count",
        "original_single_read_contract_satisfied",
        "prior_attempt_scientific_result_file_count",
        "prior_attempt_partial_directory",
        "prior_access_marker_path",
        "prior_access_marker_byte_count",
        "prior_access_marker_sha256",
        "prior_failed_job_id",
        "prior_stdout_path",
        "prior_stdout_byte_count",
        "prior_stdout_sha256",
        "prior_stderr_path",
        "prior_stderr_byte_count",
        "prior_stderr_sha256",
        "registered_run_identity",
        "frozen_artifact_identities",
        "frozen_artifact_count",
        "held_out_2024_target_access_authorized",
        "boundary_future_target_access_authorized",
    }
    timestamp = marker.get("claimed_at_utc") if isinstance(marker, Mapping) else None
    try:
        parsed_timestamp = datetime.fromisoformat(
            str(timestamp).replace("Z", "+00:00")
        )
    except ValueError as error:
        raise RuntimeError("audit technical recovery UTC timestamp drift") from error
    expected_partial = directory.with_name(directory.name + ".partial").resolve()
    if (
        not isinstance(marker, Mapping)
        or set(marker) != required_marker
        or marker.get("schema_version") != "1.0"
        or marker.get("status")
        != "technical_recovery_access_claimed_before_loader"
        or marker.get("recovery_experiment_id") != RECOVERY_EXPERIMENT_ID
        or marker.get("evaluation_partial_directory") != str(expected_partial)
        or marker.get("user_authorization_text")
        != RECOVERY_USER_AUTHORIZATION_TEXT
        or marker.get("authorized_technical_recovery") is not True
        or marker.get("recovery_attempt_number") != 2
        or marker.get("current_attempt_development_loader_call_count") != 1
        or marker.get("cumulative_development_loader_call_count") != 2
        or marker.get("prior_failed_development_access_attempt_count") != 1
        or marker.get("original_single_read_contract_satisfied") is not False
        or marker.get("prior_attempt_scientific_result_file_count") != 0
        or marker.get("registered_run_identity") != run_identity
        or marker.get("frozen_artifact_identities") != list(artifact_rows)
        or marker.get("frozen_artifact_count") != 9
        or marker.get("held_out_2024_target_access_authorized") is not False
        or marker.get("boundary_future_target_access_authorized") is not False
        or manifest.get("technical_recovery_access_started_at_utc") != timestamp
        or not isinstance(timestamp, str)
        or not timestamp.endswith("Z")
        or parsed_timestamp.utcoffset() is None
        or parsed_timestamp.utcoffset().total_seconds() != 0.0
    ):
        raise RuntimeError("audit technical recovery access-marker content drift")

    contract_path = Path(marker["recovery_contract_path"])
    if (
        not contract_path.is_file()
        or contract_path.is_symlink()
        or _sha256(contract_path) != marker["recovery_contract_sha256"]
        or manifest.get("recovery_contract_path") != str(contract_path.resolve())
        or manifest.get("recovery_contract_sha256")
        != marker["recovery_contract_sha256"]
    ):
        raise RuntimeError("audit technical recovery contract identity drift")
    contract = _read_json(contract_path)
    required_contract = {
        "schema_version",
        "status",
        "authorized",
        "authorization_date",
        "user_authorization_text",
        "recovery_experiment_id",
        "recovery_attempt_number",
        "current_attempt_development_loader_call_count",
        "cumulative_development_loader_call_count",
        "prior_failed_development_access_attempt_count",
        "original_single_read_contract_satisfied",
        "held_out_2024_target_access_authorized",
        "boundary_future_target_access_authorized",
        "scientific_contract_changed",
        "permitted_change",
        "original_remote_root",
        "recovery_remote_root",
        "original_registry_path",
        "original_registry_sha256",
        "original_evaluation_partial_directory",
        "original_evaluation_directory",
        "original_audit_directory",
        "original_audit_partial_directory",
        "original_access_marker_path",
        "original_access_marker_byte_count",
        "original_access_marker_sha256",
        "original_failed_job_id",
        "original_stdout_path",
        "original_stdout_byte_count",
        "original_stdout_sha256",
        "original_stderr_path",
        "original_stderr_byte_count",
        "original_stderr_sha256",
        "original_evaluator_path",
        "original_evaluator_byte_count",
        "original_evaluator_sha256",
        "recovery_evaluation_directory",
        "recovery_audit_directory",
        "frozen_seeds",
        "bootstrap_repeat_count",
        "bootstrap_random_seed",
        "implementation_files",
    }
    recovery_root = directory.resolve().parents[3]
    original_root = Path(contract.get("original_remote_root", "")).resolve()
    expected_audit = (
        directory.resolve().parents[1]
        / "independent_audit"
        / "attempt_002"
    )
    if (
        not isinstance(contract, Mapping)
        or set(contract) != required_contract
        or contract.get("schema_version") != "1.0"
        or contract.get("status")
        != "authorized_2023_technical_recovery_attempt_002"
        or contract.get("authorized") is not True
        or contract.get("authorization_date") != "2026-09-02"
        or contract.get("user_authorization_text")
        != RECOVERY_USER_AUTHORIZATION_TEXT
        or contract.get("recovery_experiment_id") != RECOVERY_EXPERIMENT_ID
        or contract.get("recovery_attempt_number") != 2
        or contract.get("current_attempt_development_loader_call_count") != 1
        or contract.get("cumulative_development_loader_call_count") != 2
        or contract.get("prior_failed_development_access_attempt_count") != 1
        or contract.get("original_single_read_contract_satisfied") is not False
        or contract.get("held_out_2024_target_access_authorized") is not False
        or contract.get("boundary_future_target_access_authorized") is not False
        or contract.get("scientific_contract_changed") is not False
        or contract.get("permitted_change")
        != "float32_dependency_validation_and_recovery_bookkeeping_only"
        or contract.get("original_registry_sha256") != ORIGINAL_REGISTRY_SHA256
        or contract.get("original_access_marker_byte_count") != 9140
        or contract.get("original_access_marker_sha256")
        != ORIGINAL_ACCESS_MARKER_SHA256
        or contract.get("original_failed_job_id") != 217810
        or contract.get("original_stdout_byte_count") != 903
        or contract.get("original_stdout_sha256") != ORIGINAL_STDOUT_SHA256
        or contract.get("original_stderr_byte_count") != 1644
        or contract.get("original_stderr_sha256") != ORIGINAL_STDERR_SHA256
        or contract.get("original_evaluator_byte_count") != 129641
        or contract.get("original_evaluator_sha256") != ORIGINAL_EVALUATOR_SHA256
        or contract.get("frozen_seeds") != list(SEEDS)
        or contract.get("bootstrap_repeat_count")
        != FROZEN_BOOTSTRAP_REPEAT_COUNT
        or contract.get("bootstrap_random_seed") != FROZEN_BOOTSTRAP_RANDOM_SEED
        or original_root != ORIGINAL_REMOTE_ROOT.resolve()
        or Path(contract.get("recovery_remote_root", "")).resolve()
        != recovery_root
        or Path(contract.get("original_registry_path", "")).resolve()
        != (
            original_root
            / "run/docs/records/"
            "ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_"
            "DIFFERENTIABLE_UKF_V1_REGISTRY.json"
        ).resolve()
        or Path(contract.get("original_registry_path", "")).resolve()
        != Path(run_identity.get("registry_path", "")).resolve()
        or contract.get("original_registry_sha256")
        != run_identity.get("registry_sha256")
        or Path(contract.get("original_evaluation_partial_directory", "")).resolve()
        != (
            original_root
            / "evidence/development_2023/evaluation/attempt_001.partial"
        ).resolve()
        or Path(contract.get("original_evaluation_directory", "")).resolve()
        != (
            original_root / "evidence/development_2023/evaluation/attempt_001"
        ).resolve()
        or Path(contract.get("original_audit_directory", "")).resolve()
        != (
            original_root
            / "evidence/development_2023/independent_audit/attempt_001"
        ).resolve()
        or Path(contract.get("original_audit_partial_directory", "")).resolve()
        != (
            original_root
            / "evidence/development_2023/independent_audit/attempt_001.partial"
        ).resolve()
        or Path(contract.get("original_access_marker_path", "")).resolve()
        != (
            original_root
            / "evidence/development_2023/evaluation/attempt_001.partial"
            / DEVELOPMENT_ACCESS_MARKER_NAME
        ).resolve()
        or Path(contract.get("original_stdout_path", "")).resolve()
        != (original_root / "logs/development-2023-217810.out").resolve()
        or Path(contract.get("original_stderr_path", "")).resolve()
        != (original_root / "logs/development-2023-217810.err").resolve()
        or Path(contract.get("original_evaluator_path", "")).resolve()
        != (
            original_root
            / "run/scripts/analysis/"
            "zhenjiang_six_source_four_target_d32_gru_"
            "ukf_development_evaluation_v1.py"
        ).resolve()
        or Path(contract.get("recovery_evaluation_directory", "")).resolve()
        != directory.resolve()
        or Path(contract.get("recovery_audit_directory", "")).resolve()
        != expected_audit.resolve()
    ):
        raise RuntimeError("audit technical recovery authorization drift")

    prior_partial = Path(contract["original_evaluation_partial_directory"])
    prior_marker_path = Path(contract["original_access_marker_path"])
    if (
        not prior_partial.is_dir()
        or prior_partial.is_symlink()
        or list(prior_partial.iterdir()) != [prior_marker_path]
        or not prior_marker_path.is_file()
        or prior_marker_path.is_symlink()
        or prior_marker_path.stat().st_size != 9140
        or _sha256(prior_marker_path) != ORIGINAL_ACCESS_MARKER_SHA256
        or marker.get("prior_attempt_partial_directory")
        != str(prior_partial.resolve())
        or marker.get("prior_access_marker_path")
        != str(prior_marker_path.resolve())
        or marker.get("prior_access_marker_byte_count") != 9140
        or marker.get("prior_access_marker_sha256")
        != ORIGINAL_ACCESS_MARKER_SHA256
    ):
        raise RuntimeError("audit prior failed-attempt marker drift")
    prior_marker = _read_json(prior_marker_path)
    if (
        prior_marker.get("registered_run_identity") != run_identity
        or prior_marker.get("frozen_artifact_identities") != list(artifact_rows)
        or prior_marker.get("held_out_2024_target_access_authorized") is not False
        or prior_marker.get("boundary_future_target_access_authorized") is not False
    ):
        raise RuntimeError("audit prior and recovery frozen identities differ")
    for path_key, bytes_key, hash_key, marker_prefix in (
        (
            "original_stdout_path",
            "original_stdout_byte_count",
            "original_stdout_sha256",
            "prior_stdout",
        ),
        (
            "original_stderr_path",
            "original_stderr_byte_count",
            "original_stderr_sha256",
            "prior_stderr",
        ),
        (
            "original_evaluator_path",
            "original_evaluator_byte_count",
            "original_evaluator_sha256",
            None,
        ),
    ):
        path = Path(contract[path_key])
        if (
            not path.is_file()
            or path.is_symlink()
            or path.stat().st_size != contract[bytes_key]
            or _sha256(path) != contract[hash_key]
        ):
            raise RuntimeError("audit prior forensic artifact identity drift")
        if marker_prefix is not None and (
            marker.get(marker_prefix + "_path") != str(path.resolve())
            or marker.get(marker_prefix + "_byte_count") != contract[bytes_key]
            or marker.get(marker_prefix + "_sha256") != contract[hash_key]
        ):
            raise RuntimeError("audit recovery marker prior log identity drift")
    if marker.get("prior_failed_job_id") != contract["original_failed_job_id"]:
        raise RuntimeError("audit prior failed job identity drift")
    for absent_key in (
        "original_evaluation_directory",
        "original_audit_directory",
        "original_audit_partial_directory",
    ):
        if Path(contract[absent_key]).exists():
            raise RuntimeError("audit prior failure unexpectedly published a result")

    implementation_rows = contract.get("implementation_files")
    expected_implementation_paths = {
        "scripts/analysis/"
        "zhenjiang_six_source_four_target_d32_gru_ukf_development_recovery_v1.py",
        "scripts/analysis/"
        "audit_zhenjiang_six_source_four_target_d32_gru_ukf_development_recovery_v1.py",
        "scripts/hpc/"
        "zhenjiang_six_source_four_target_d32_gru_ukf_development_recovery_v1.slurm",
    }
    if (
        not isinstance(implementation_rows, list)
        or len(implementation_rows) != 3
        or any(not isinstance(row, Mapping) for row in implementation_rows)
        or {row.get("path") for row in implementation_rows}
        != expected_implementation_paths
    ):
        raise RuntimeError("audit recovery implementation allow-list drift")
    for row in implementation_rows:
        if not isinstance(row, Mapping) or set(row) != {"path", "sha256"}:
            raise RuntimeError("audit recovery implementation row schema drift")
        path = recovery_root / "run" / row["path"]
        if not path.is_file() or path.is_symlink() or _sha256(path) != row["sha256"]:
            raise RuntimeError("audit recovery implementation identity drift")


def _verify_manifest(directory: Path) -> Mapping[str, Any]:
    manifest = _read_json(directory / "completion_manifest.json")
    if manifest.get("status") != "completed_development_evaluation":
        raise RuntimeError("audit completion status differs")
    recovery_expectations = {
        "authorized_technical_recovery": True,
        "recovery_experiment_id": RECOVERY_EXPERIMENT_ID,
        "recovery_attempt_number": 2,
        "current_attempt_development_loader_call_count": 1,
        "cumulative_development_loader_call_count": 2,
        "prior_failed_development_access_attempt_count": 1,
        "original_single_read_contract_satisfied": False,
        "prior_attempt_scientific_result_file_count": 0,
    }
    if any(manifest.get(name) != value for name, value in recovery_expectations.items()):
        raise RuntimeError("audit technical recovery count or authorization drift")
    if manifest.get("held_out_2024_target_access_count") != 0 or manifest.get(
        "boundary_future_target_access_count"
    ) != 0:
        raise RuntimeError("audit detected forbidden target access")
    if manifest.get("dependency_evidence_contains_target_values") is not False:
        raise RuntimeError("audit dependency evidence target-value contract drift")
    synthetic = manifest.get("synthetic_test_mode")
    if type(synthetic) is not bool:
        raise RuntimeError("audit synthetic/formal mode identity drift")
    expected_loader_count = 0 if synthetic else 1
    if (
        manifest.get("real_target_loader_present") is (not synthetic)
        and manifest.get("development_loader_call_count")
        == expected_loader_count
        and manifest.get("development_dataset_instance_count")
        == expected_loader_count
        and manifest.get("seed_evaluation_count") == 3
    ):
        pass
    else:
        raise RuntimeError("audit single-load shared-dataset identity drift")
    access = manifest.get("development_data_access_audit")
    required_access = {
        "opened_paths",
        "bytes_read_by_path",
        "rows_parsed_by_path",
        "values_loaded_by_path",
        "target_rows_by_period",
        "astronomical_tide_model_open_count",
        "development_feature_bytes_read",
        "development_feature_rows_parsed",
        "development_feature_values_loaded",
        "development_target_bytes_read",
        "development_target_rows_parsed",
        "development_target_values_loaded",
        "heldout_target_bytes_read",
        "heldout_target_rows_parsed",
        "heldout_target_values_loaded",
        "boundary_target_bytes_read",
        "boundary_target_rows_parsed",
        "boundary_target_values_loaded",
    }
    if not isinstance(access, Mapping) or set(access) != required_access:
        raise RuntimeError("audit development data-access schema drift")
    opened = access["opened_paths"]
    if (
        not isinstance(opened, list)
        or set(opened) != set(FROZEN_DEVELOPMENT_BYTES_BY_PATH)
        or len(opened) != len(FROZEN_DEVELOPMENT_BYTES_BY_PATH)
        or len(set(opened)) != len(opened)
    ):
        raise RuntimeError("audit frozen eleven-path allow-list drift")
    if access["bytes_read_by_path"] != FROZEN_DEVELOPMENT_BYTES_BY_PATH:
        raise RuntimeError("audit frozen per-path byte identity drift")
    parsed = access["rows_parsed_by_path"]
    if (
        not isinstance(parsed, Mapping)
        or set(parsed) != set(FROZEN_DEVELOPMENT_BYTES_BY_PATH)
        or parsed.get("dataset_config.json") != 0
        or any(
            type(parsed[path]) is not int
            or parsed[path] != FROZEN_PREFIX_ROWS_PER_CSV
            for path in FROZEN_DEVELOPMENT_CSV_PATHS
        )
    ):
        raise RuntimeError("audit frozen per-path parsed-row identity drift")
    loaded = access["values_loaded_by_path"]
    if (
        not isinstance(loaded, Mapping)
        or set(loaded) != set(FROZEN_DEVELOPMENT_BYTES_BY_PATH)
        or loaded.get("dataset_config.json") != 0
        or any(
            type(loaded[path]) is not int
            or loaded[path] < 0
            or loaded[path] > FROZEN_PREFIX_ROWS_PER_CSV
            for path in FROZEN_DEVELOPMENT_CSV_PATHS
        )
    ):
        raise RuntimeError("audit frozen per-path loaded-value identity drift")
    if access["astronomical_tide_model_open_count"] != 1:
        raise RuntimeError("audit tide-model open count drift")
    exact_aggregates = {
        "development_feature_bytes_read": FROZEN_DEVELOPMENT_FEATURE_BYTES,
        "development_feature_rows_parsed": FROZEN_DEVELOPMENT_FEATURE_ROWS,
        "development_target_bytes_read": FROZEN_DEVELOPMENT_TARGET_BYTES,
        "development_target_rows_parsed": FROZEN_DEVELOPMENT_TARGET_ROWS,
    }
    if any(access[name] != value for name, value in exact_aggregates.items()):
        raise RuntimeError("audit frozen development aggregate identity drift")
    feature_paths = [
        path for path in FROZEN_DEVELOPMENT_CSV_PATHS
        if path.startswith("realtime_features/")
    ]
    target_paths = [
        path for path in FROZEN_DEVELOPMENT_CSV_PATHS
        if path.startswith("retrospective_targets/")
    ]
    for aggregate_name, paths, maximum in (
        (
            "development_feature_values_loaded",
            feature_paths,
            FROZEN_DEVELOPMENT_FEATURE_ROWS,
        ),
        (
            "development_target_values_loaded",
            target_paths,
            FROZEN_DEVELOPMENT_TARGET_ROWS,
        ),
    ):
        observed = access[aggregate_name]
        total = sum(loaded[path] for path in paths)
        predevelopment_capacity = (
            len(paths) * FROZEN_PREDEVELOPMENT_ROWS_PER_CSV
        )
        if (
            type(observed) is not int
            or not max(0, total - predevelopment_capacity)
            <= observed
            <= min(total, maximum)
        ):
            raise RuntimeError("audit development loaded-value aggregate drift")
    for name in (
        "heldout_target_bytes_read",
        "heldout_target_rows_parsed",
        "heldout_target_values_loaded",
        "boundary_target_bytes_read",
        "boundary_target_rows_parsed",
        "boundary_target_values_loaded",
    ):
        if type(access[name]) is not int or access[name] != 0:
            raise RuntimeError("audit forbidden target access is nonzero")
    periods = access["target_rows_by_period"]
    if (
        not isinstance(periods, Mapping)
        or dict(periods) != FROZEN_DEVELOPMENT_TARGET_ROWS_BY_PERIOD
    ):
        raise RuntimeError("audit target-period access identity drift")

    artifact_rows = manifest.get("frozen_artifact_identities")
    if (
        not isinstance(artifact_rows, list)
        or len(artifact_rows) != 3
        or sorted(row.get("seed", -1) for row in artifact_rows) != list(SEEDS)
    ):
        raise RuntimeError("audit frozen artifact seed identity drift")
    artifact_paths = []
    for artifact in artifact_rows:
        required_artifact = {
            "seed",
            "base_checkpoint_path",
            "base_checkpoint_sha256",
            "observation_head_path",
            "observation_head_sha256",
            "filter_checkpoint_path",
            "filter_checkpoint_sha256",
            "filter_completion_manifest_sha256",
            "observation_head_design_diagnostic",
        }
        if not isinstance(artifact, Mapping) or set(artifact) != required_artifact:
            raise RuntimeError("audit frozen artifact schema drift")
        for path_name, hash_name in (
            ("base_checkpoint_path", "base_checkpoint_sha256"),
            ("observation_head_path", "observation_head_sha256"),
            ("filter_checkpoint_path", "filter_checkpoint_sha256"),
        ):
            artifact_paths.append(artifact[path_name])
            digest = artifact[hash_name]
            if (
                not isinstance(digest, str)
                or len(digest) != 64
                or any(character not in "0123456789abcdef" for character in digest)
            ):
                raise RuntimeError("audit frozen artifact hash drift")
            if manifest.get("synthetic_test_mode") is False:
                path = Path(artifact[path_name])
                if not path.is_file() or _sha256(path) != digest:
                    raise RuntimeError("audit frozen artifact content identity drift")
        manifest_digest = artifact["filter_completion_manifest_sha256"]
        if not isinstance(manifest_digest, str) or len(manifest_digest) != 64:
            raise RuntimeError("audit filter manifest hash drift")
        if manifest.get("synthetic_test_mode") is False:
            filter_manifest = (
                Path(artifact["filter_checkpoint_path"]).parent
                / "completion_manifest.json"
            )
            if (
                not filter_manifest.is_file()
                or _sha256(filter_manifest) != manifest_digest
            ):
                raise RuntimeError("audit filter completion-manifest identity drift")
    if len(set(artifact_paths)) != 9:
        raise RuntimeError("audit frozen artifact paths are not unique")

    run_identity = manifest.get("registered_run_identity")
    required_run_identity = {
        "registry_path",
        "registry_sha256",
        "input_root_path",
        "input_manifest_path",
        "input_manifest_sha256",
    }
    if not isinstance(run_identity, Mapping) or set(run_identity) != required_run_identity:
        raise RuntimeError("audit registered run identity drift")
    if manifest.get("synthetic_test_mode") is False:
        for path_name, hash_name in (
            ("registry_path", "registry_sha256"),
            ("input_manifest_path", "input_manifest_sha256"),
        ):
            path = Path(run_identity[path_name])
            if not path.is_file() or _sha256(path) != run_identity[hash_name]:
                raise RuntimeError("audit registered document content identity drift")
    marker_path = directory / DEVELOPMENT_ACCESS_MARKER_NAME
    if synthetic:
        if (
            manifest.get("development_access_started_before_loader") is not False
            or manifest.get("development_access_marker_sha256") is not None
            or manifest.get("development_access_started_at_utc") is not None
            or marker_path.exists()
        ):
            raise RuntimeError("audit synthetic development-access marker drift")
    else:
        marker_digest = manifest.get("development_access_marker_sha256")
        if (
            manifest.get("development_access_started_before_loader") is not True
            or not isinstance(marker_digest, str)
            or len(marker_digest) != 64
            or not marker_path.is_file()
            or _sha256(marker_path) != marker_digest
        ):
            raise RuntimeError("audit development-access marker identity drift")
        marker = _read_json(marker_path)
        required_marker = {
            "schema_version",
            "status",
            "experiment_id",
            "claimed_at_utc",
            "evaluation_partial_directory",
            "registered_run_identity",
            "frozen_artifact_identities",
            "frozen_artifact_count",
            "held_out_2024_target_access_authorized",
            "boundary_future_target_access_authorized",
        }
        timestamp = marker.get("claimed_at_utc") if isinstance(marker, Mapping) else None
        try:
            parsed_timestamp = datetime.fromisoformat(
                str(timestamp).replace("Z", "+00:00")
            )
        except ValueError as error:
            raise RuntimeError("audit development-access marker UTC drift") from error
        expected_partial = directory.with_name(directory.name + ".partial").resolve()
        if (
            not isinstance(marker, Mapping)
            or set(marker) != required_marker
            or marker.get("schema_version") != "1.0"
            or marker.get("status") != "development_access_claimed_before_loader"
            or marker.get("experiment_id") != FORMAL_DEVELOPMENT_EXPERIMENT_ID
            or marker.get("evaluation_partial_directory") != str(expected_partial)
            or marker.get("registered_run_identity") != run_identity
            or marker.get("frozen_artifact_identities") != artifact_rows
            or marker.get("frozen_artifact_count") != 9
            or marker.get("held_out_2024_target_access_authorized") is not False
            or marker.get("boundary_future_target_access_authorized") is not False
            or not isinstance(timestamp, str)
            or not timestamp.endswith("Z")
            or parsed_timestamp.utcoffset() is None
            or parsed_timestamp.utcoffset().total_seconds() != 0.0
            or manifest.get("development_access_started_at_utc") != timestamp
        ):
            raise RuntimeError("audit development-access marker content drift")
    _audit_technical_recovery_chain(
        directory,
        manifest,
        artifact_rows,
        run_identity,
    )
    rows = manifest.get("files")
    if not isinstance(rows, list) or manifest.get(
        "file_count_excluding_manifest"
    ) != len(rows):
        raise RuntimeError("audit manifest file count differs")
    expected_names = {row.get("name") for row in rows}
    actual_names = {
        path.name
        for path in directory.iterdir()
        if path.is_file() and path.name != "completion_manifest.json"
    }
    if expected_names != actual_names:
        raise RuntimeError("audit manifest file-name set differs")
    for row in rows:
        path = directory / row["name"]
        if path.stat().st_size != row["byte_count"] or _sha256(path) != row["sha256"]:
            raise RuntimeError("audit manifest identity differs: %s" % path.name)
    return manifest


def _select_reported_observation_head_candidate(
    candidates: Any,
) -> Mapping[str, Any]:
    """Independently reapply the frozen global-minimum ridge rule."""

    required = {
        "ridge_strength",
        "selection_mean_absolute_error_m",
        "station_selection_mean_absolute_error_m",
        "augmented_design_singular_values",
        "augmented_design_rank",
        "augmented_design_condition_number",
        "coefficient_float64_sha256",
        "coefficient_float32_sha256",
    }
    if not isinstance(candidates, list) or len(candidates) != len(
        FROZEN_RIDGE_STRENGTHS
    ):
        raise RuntimeError("audit observation-head candidate grid drift")
    checked: List[Mapping[str, Any]] = []
    for candidate in candidates:
        if not isinstance(candidate, Mapping) or set(candidate) != required:
            raise RuntimeError("audit observation-head candidate schema drift")
        ridge = candidate["ridge_strength"]
        selection_error = candidate["selection_mean_absolute_error_m"]
        station_errors = candidate["station_selection_mean_absolute_error_m"]
        singular_values = candidate["augmented_design_singular_values"]
        rank = candidate["augmented_design_rank"]
        condition = candidate["augmented_design_condition_number"]
        if (
            not isinstance(ridge, (int, float))
            or isinstance(ridge, bool)
            or not math.isfinite(float(ridge))
            or not isinstance(selection_error, (int, float))
            or isinstance(selection_error, bool)
            or not math.isfinite(float(selection_error))
            or float(selection_error) < 0.0
            or not isinstance(station_errors, list)
            or len(station_errors) != 6
            or any(
                not isinstance(value, (int, float))
                or isinstance(value, bool)
                or not math.isfinite(float(value))
                or float(value) < 0.0
                for value in station_errors
            )
            or not isinstance(singular_values, list)
            or len(singular_values) != 33
            or any(
                not isinstance(value, (int, float))
                or isinstance(value, bool)
                or not math.isfinite(float(value))
                or float(value) < 0.0
                for value in singular_values
            )
            or type(rank) is not int
            or rank not in range(1, 34)
            or (
                condition is not None
                and (
                    not isinstance(condition, (int, float))
                    or isinstance(condition, bool)
                    or not math.isfinite(float(condition))
                    or float(condition) < 1.0
                )
            )
        ):
            raise RuntimeError("audit observation-head candidate numerical drift")
        for name in ("coefficient_float64_sha256", "coefficient_float32_sha256"):
            digest = candidate[name]
            if not isinstance(digest, str) or len(digest) != 64 or any(
                character not in "0123456789abcdef" for character in digest
            ):
                raise RuntimeError("audit observation-head coefficient hash drift")
        checked.append(candidate)
    if tuple(sorted(float(row["ridge_strength"]) for row in checked)) != (
        FROZEN_RIDGE_STRENGTHS
    ):
        raise RuntimeError("audit observation-head fixed ridge grid drift")
    global_minimum = min(
        float(row["selection_mean_absolute_error_m"]) for row in checked
    )
    tied = [
        row
        for row in checked
        if float(row["selection_mean_absolute_error_m"]) - global_minimum
        <= FROZEN_RIDGE_TIE_TOLERANCE_M
    ]
    return max(tied, key=lambda row: float(row["ridge_strength"]))


def _audit_observation_head_design_diagnostics(
    manifest: Mapping[str, Any],
) -> List[Dict[str, Any]]:
    """Independently rebuild selected-head numerical diagnostics."""

    required = {
        "seed",
        "selection_report_path",
        "selection_report_sha256",
        "coefficient_float32_sha256",
        "selected_ridge_strength",
        "augmented_design_singular_values",
        "augmented_design_rank",
        "augmented_design_condition_number",
    }
    result = []
    synthetic = manifest["synthetic_test_mode"]
    report_paths = set()
    for artifact in sorted(
        manifest["frozen_artifact_identities"], key=lambda row: row["seed"]
    ):
        recorded = artifact["observation_head_design_diagnostic"]
        if not isinstance(recorded, Mapping) or set(recorded) != required:
            raise RuntimeError("audit observation-head diagnostic schema drift")
        if recorded.get("seed") != artifact["seed"]:
            raise RuntimeError("audit observation-head diagnostic seed drift")
        report_path = Path(recorded.get("selection_report_path", ""))
        if not str(report_path) or str(report_path) in report_paths:
            raise RuntimeError("audit observation-head report path drift")
        report_paths.add(str(report_path))
        if synthetic:
            rebuilt = dict(recorded)
        else:
            if (
                not report_path.is_file()
                or _sha256(report_path) != recorded["selection_report_sha256"]
            ):
                raise RuntimeError("audit observation-head report identity drift")
            report = _read_json(report_path)
            head = torch.load(
                artifact["observation_head_path"],
                map_location="cpu",
                weights_only=False,
            )
            selected_ridge = report.get("selected_ridge_strength")
            selected_coefficient = report.get(
                "selected_coefficient_float32_sha256"
            )
            if (
                not isinstance(head, Mapping)
                or head.get("seed") != artifact["seed"]
                or head.get("selected_ridge_strength") != selected_ridge
                or head.get("coefficient_float32_sha256")
                != selected_coefficient
            ):
                raise RuntimeError("audit observation-head artifact/report drift")
            candidates = report.get("candidates")
            frozen_selected = _select_reported_observation_head_candidate(
                candidates
            )
            if (
                frozen_selected["ridge_strength"] != selected_ridge
                or frozen_selected["coefficient_float32_sha256"]
                != selected_coefficient
            ):
                raise RuntimeError(
                    "audit observation-head global-minimum tie rule drift"
                )
            selected = [
                row
                for row in candidates
                if isinstance(row, Mapping)
                and row.get("ridge_strength") == selected_ridge
                and row.get("coefficient_float32_sha256")
                == selected_coefficient
            ] if isinstance(candidates, list) else []
            if len(selected) != 1:
                raise RuntimeError("audit selected head diagnostic is not unique")
            candidate = selected[0]
            rebuilt = {
                "seed": artifact["seed"],
                "selection_report_path": str(report_path),
                "selection_report_sha256": _sha256(report_path),
                "coefficient_float32_sha256": selected_coefficient,
                "selected_ridge_strength": selected_ridge,
                "augmented_design_singular_values": candidate.get(
                    "augmented_design_singular_values"
                ),
                "augmented_design_rank": candidate.get(
                    "augmented_design_rank"
                ),
                "augmented_design_condition_number": candidate.get(
                    "augmented_design_condition_number"
                ),
            }
            _compare_value(recorded, rebuilt, "observation-head design diagnostic")
        singular = rebuilt["augmented_design_singular_values"]
        rank = rebuilt["augmented_design_rank"]
        condition = rebuilt["augmented_design_condition_number"]
        ridge = rebuilt["selected_ridge_strength"]
        for digest_name in (
            "selection_report_sha256",
            "coefficient_float32_sha256",
        ):
            digest = rebuilt[digest_name]
            if not isinstance(digest, str) or len(digest) != 64 or any(
                character not in "0123456789abcdef" for character in digest
            ):
                raise RuntimeError("audit observation-head diagnostic hash drift")
        if (
            not isinstance(singular, list)
            or len(singular) != 33
            or any(
                not isinstance(value, (int, float))
                or isinstance(value, bool)
                or not math.isfinite(float(value))
                or float(value) < 0.0
                for value in singular
            )
            or type(rank) is not int
            or rank not in range(1, 34)
            or not isinstance(ridge, (int, float))
            or isinstance(ridge, bool)
            or not math.isfinite(float(ridge))
            or float(ridge) < 0.0
            or (
                condition is not None
                and (
                    not isinstance(condition, (int, float))
                    or isinstance(condition, bool)
                    or not math.isfinite(float(condition))
                    or float(condition) < 1.0
                )
            )
        ):
            raise RuntimeError("audit observation-head numerical diagnostic drift")
        result.append(rebuilt)
    if [row["seed"] for row in result] != list(SEEDS):
        raise RuntimeError("audit observation-head diagnostic seed grid drift")
    return result


def audit_observation_dependency_perturbation(
    original_observation: Any,
    perturbed_observation: Any,
    original_posterior_observation: Any,
    perturbed_posterior_observation: Any,
) -> Dict[str, Any]:
    """Reject a direct-copy posterior by checking perturbation response slope."""

    original = np.asarray(original_observation, dtype=np.float64)
    perturbed = np.asarray(perturbed_observation, dtype=np.float64)
    posterior = np.asarray(original_posterior_observation, dtype=np.float64)
    posterior_perturbed = np.asarray(
        perturbed_posterior_observation, dtype=np.float64
    )
    if not (
        original.shape == perturbed.shape == posterior.shape == posterior_perturbed.shape
        and original.ndim == 2
        and original.shape[1] == 6
    ):
        raise ValueError("dependency perturbation arrays must share shape [sample, 6]")
    original_float32 = original.astype(np.float32)
    if not np.array_equal(original, original_float32.astype(np.float64)):
        raise ValueError("dependency observations are not exact model float32 values")
    expected_perturbed = (
        original_float32
        + np.float32(FROZEN_DEPENDENCY_PERTURBATION_DELTA_NORMALIZED)
    ).astype(np.float64)
    if not np.array_equal(perturbed, expected_perturbed):
        raise ValueError(
            "dependency perturbation is not the exact model float32 +0.01 operation"
        )
    observation_delta = perturbed - original
    if bool((np.abs(observation_delta) <= 1e-9).any()):
        raise ValueError("every dependency perturbation must be nonzero")
    slope = (posterior_perturbed - posterior) / observation_delta
    if not bool(np.isfinite(slope).all()):
        raise RuntimeError("dependency perturbation slope is nonfinite")
    if bool((slope <= 0.0).any()) or bool((slope >= 1.0).any()):
        raise RuntimeError(
            "posterior dependency slope must be strictly between zero and one"
        )
    if bool(np.allclose(posterior, original, atol=1e-12, rtol=1e-10)):
        raise RuntimeError("posterior directly copies the original observation")
    if bool(
        np.allclose(
            posterior_perturbed, perturbed, atol=1e-12, rtol=1e-10
        )
    ):
        raise RuntimeError("posterior directly copies the perturbed observation")
    return {
        "status": "passed",
        "minimum_response_slope": float(slope.min()),
        "maximum_response_slope": float(slope.max()),
        "exact_model_float32_addition_verified": True,
        "direct_copy_detected": False,
    }


def audit_completed_development_evaluation(
    evaluation_directory: Path,
) -> Dict[str, Any]:
    """Rebuild and verify every published metric table and development gate."""

    directory = Path(evaluation_directory)
    if not directory.is_dir():
        raise ValueError("evaluation_directory must exist")
    manifest = _verify_manifest(directory)
    future = _future_rows(_read_csv(directory / "future_sufficient_statistics.csv"))
    observation = _typed_rows(
        _read_csv(directory / "analysis_observation_sufficient_statistics.csv"),
        OBSERVATION_FIELDS,
        (
            "seed",
            "block_id",
            "block_origin_count",
            "source_index",
            "cell_count",
            "near_zero_prior_count",
        ),
        ("contraction_ratio_values_json",),
    )
    target = _typed_rows(
        _read_csv(directory / "analysis_target_sufficient_statistics.csv"),
        TARGET_FIELDS,
        (
            "seed",
            "block_id",
            "block_origin_count",
            "source_index",
            "target_index",
            "cell_count",
        ),
    )
    state = _typed_rows(
        _read_csv(directory / "state_difference_sufficient_statistics.csv"),
        STATE_FIELDS,
        (
            "seed",
            "block_id",
            "block_origin_count",
            "source_index",
            "issue_horizon_hour",
            "post_update_lead_hour",
            "cell_count",
        ),
    )
    base_qualification_rows = _typed_rows(
        _read_csv(directory / "base_qualification_sufficient_statistics.csv"),
        BASE_QUALIFICATION_FIELDS,
        (
            "seed",
            "block_id",
            "block_origin_count",
            "target_index",
            "first_six_cell_count",
            "full_twenty_four_cell_count",
        ),
    )
    observation_head_qualification_rows = _typed_rows(
        _read_csv(
            directory / "observation_head_qualification_sufficient_statistics.csv"
        ),
        OBSERVATION_HEAD_QUALIFICATION_FIELDS,
        (
            "seed",
            "block_id",
            "block_origin_count",
            "source_index",
            "cell_count",
        ),
    )
    grid = _grid(
        future,
        observation,
        target,
        state,
        base_qualification_rows,
        observation_head_qualification_rows,
    )
    lead = _lead_table(future)
    if len(lead) != 1656:
        raise RuntimeError("audit source-target-lead count differs from 1,656")
    windows = _window_table(future)
    matrices = _matrices(windows)
    recorded_bootstrap = _read_json(directory / "bootstrap_summary.json")
    sampling = recorded_bootstrap.get("sampling", {})
    if _int(sampling.get("repeat_count"), "bootstrap repeat count") != (
        FROZEN_BOOTSTRAP_REPEAT_COUNT
    ):
        raise RuntimeError("audit rejects bootstrap repeat-count drift")
    if _int(sampling.get("random_seed"), "bootstrap random seed") != (
        FROZEN_BOOTSTRAP_RANDOM_SEED
    ):
        raise RuntimeError("audit rejects bootstrap random-seed drift")
    repeat_count = FROZEN_BOOTSTRAP_REPEAT_COUNT
    random_seed = FROZEN_BOOTSTRAP_RANDOM_SEED
    bootstrap = _bootstrap(future, repeat_count, random_seed)
    observations = _observation_summary(observation, repeat_count, random_seed)
    targets = _analysis_target(target)
    states = _state(state)
    forecast = _forecast_decision(windows, bootstrap)
    recorded_decision = _read_json(directory / "development_gate_decision.json")
    identity_details = recorded_decision.get("identity_gate_details")
    if not isinstance(identity_details, Mapping) or not identity_details:
        raise RuntimeError("audit identity gate details are missing")
    identity_pass = all(bool(value) for value in identity_details.values())
    observation_head_diagnostics = _audit_observation_head_design_diagnostics(
        manifest
    )
    qualification = _qualification(
        base_qualification_rows,
        observation_head_qualification_rows,
        observation_head_diagnostics,
    )
    recorded_qualification = _read_json(
        directory / "base_observation_head_qualification.json"
    )
    _compare_value(
        recorded_qualification,
        qualification,
        "base_observation_head_qualification",
    )
    qualification_pass = bool(qualification.get("passed"))
    evidence_path = directory / "observation_dependency_perturbation_evidence.npz"
    with np.load(evidence_path, allow_pickle=False) as evidence:
        required_evidence = {
            "schema_version",
            "space",
            "perturbation_delta_normalized",
            "sample_identity_sha256",
            "original_observation_normalized",
            "perturbed_observation_normalized",
            "original_posterior_observation_normalized",
            "perturbed_posterior_observation_normalized",
        }
        if set(evidence.files) != required_evidence:
            raise RuntimeError("audit dependency evidence schema drift")
        if str(evidence["schema_version"].item()) != "1.0" or str(
            evidence["space"].item()
        ) != "realtime_observation_normalized":
            raise RuntimeError("audit dependency evidence space drift")
        if not math.isclose(
            float(evidence["perturbation_delta_normalized"].item()),
            FROZEN_DEPENDENCY_PERTURBATION_DELTA_NORMALIZED,
            abs_tol=0.0,
            rel_tol=0.0,
        ):
            raise RuntimeError("audit dependency perturbation-size drift")
        sample_identity = str(evidence["sample_identity_sha256"].item())
        if len(sample_identity) != 64 or any(
            character not in "0123456789abcdef" for character in sample_identity
        ):
            raise RuntimeError("audit dependency sample identity drift")
        perturbation_result = audit_observation_dependency_perturbation(
            evidence["original_observation_normalized"],
            evidence["perturbed_observation_normalized"],
            evidence["original_posterior_observation_normalized"],
            evidence["perturbed_posterior_observation_normalized"],
        )
    observation_pass = all(row["pass"] for row in observations)
    self_forecast_pass = bool(forecast["self_forecast_gate_pass"])
    cross_station_pass = bool(forecast["cross_station_gate_pass"])
    forecast_pass = bool(forecast["forecast_gate_pass"])
    if not identity_pass:
        status = "invalid_identity_or_target_access_stop"
    elif not qualification_pass:
        status = "base_or_observation_head_qualification_fail"
    elif not observation_pass:
        status = "analysis_update_principle_fail"
    else:
        status = forecast["status"]
    decision = {
        "schema_version": "1.0",
        "status": status,
        "identity_gate_details": dict(identity_details),
        "identity_gate_pass": identity_pass,
        "base_observation_head_qualification_pass": qualification_pass,
        "analysis_observation_update_pass": observation_pass,
        "self_forecast_gate_pass": self_forecast_pass,
        "cross_station_gate_pass": cross_station_pass,
        "cross_station_status": forecast["cross_station_status"],
        "forecast_direction_gate_pass": forecast_pass,
        "dependency_perturbation_evidence_recorded": True,
        "forecast_direction_decision": forecast,
        "practical_magnitude_gate": "not_frozen",
    }
    movement = [
        {
            "source_index": row["source_index"],
            "source_station": row["source_station"],
            "target_index": row["target_index"],
            "target_station": row["target_station"],
            "forecast_movement_m": row["forecast_movement_m"],
            "forecast_movement_mm": 1000.0 * row["forecast_movement_m"],
            "measurement_update_gain_m": row["measurement_update_gain_m"],
        }
        for row in matrices["full"]
    ]
    _compare_csv(
        directory / "base_and_three_branch_forecast_metrics.csv",
        [row for row in windows if row["scope"] == "pooled_three_seeds"],
    )
    _compare_csv(directory / "source_target_lead_metrics.csv", lead)
    _compare_csv(directory / "source_target_window_metrics.csv", windows)
    _compare_csv(directory / "six_source_four_target_gain_matrix.csv", matrices["full"])
    _compare_csv(directory / "internal_four_by_four_gain_matrix.csv", matrices["internal"])
    _compare_csv(directory / "boundary_to_internal_gain_matrix.csv", matrices["boundary"])
    _compare_csv(directory / "analysis_realtime_observation_diagnostics.csv", observations)
    _compare_csv(directory / "analysis_target_space_gain_matrix.csv", targets)
    _compare_csv(directory / "forecast_movement_matrix.csv", movement)
    _compare_csv(directory / "reciprocal_direction_summary.csv", _reciprocal(matrices["full"]))
    _compare_csv(directory / "state_difference_diagnostics.csv", states)
    _compare_value(recorded_bootstrap, bootstrap, "bootstrap_summary")
    _compare_value(_read_json(directory / "sufficient_grid_identity.json"), grid, "grid")
    _compare_value(recorded_decision, decision, "development_gate_decision")
    return {
        "schema_version": "1.0",
        "status": "passed_independent_reconstruction",
        "evaluation_manifest_sha256": _sha256(directory / "completion_manifest.json"),
        "manifest_file_count": manifest["file_count_excluding_manifest"],
        "future_sufficient_row_count": len(future),
        "source_target_lead_row_count": len(lead),
        "nonempty_calendar_block_count": grid["nonempty_block_count"],
        "bootstrap_repeat_count": repeat_count,
        "holm_internal_direction_count": 12,
        "holm_boundary_direction_count": 8,
        "exact_key_boolean_and_count_mismatch_count": 0,
        "float64_numeric_mismatch_count": 0,
        "main_metrics_module_imported": False,
        "dependency_perturbation_audit": perturbation_result,
        "base_observation_head_qualification_reconstructed": True,
        "authorized_technical_recovery_audited": True,
        "recovery_experiment_id": RECOVERY_EXPERIMENT_ID,
        "recovery_attempt_number": 2,
        "current_attempt_development_loader_call_count": 1,
        "cumulative_development_loader_call_count": 2,
        "prior_failed_development_access_attempt_count": 1,
        "original_single_read_contract_satisfied": False,
        "prior_attempt_scientific_result_file_count": 0,
        "held_out_2024_target_access_count": 0,
        "boundary_future_target_access_count": 0,
        "frozen_artifact_identity_count": 9,
        "recovery_implementation_identity_count": 3,
    }


def write_independent_audit(
    evaluation_directory: Path, audit_directory: Path
) -> Path:
    """Atomically write and self-verify one non-overwriting audit attempt."""

    audit_directory = Path(audit_directory)
    if audit_directory.exists():
        raise FileExistsError("audit output directory already exists")
    partial = audit_directory.with_name(audit_directory.name + ".partial")
    if partial.exists():
        raise FileExistsError("partial audit output directory already exists")
    report = audit_completed_development_evaluation(evaluation_directory)
    partial.mkdir(parents=True, exist_ok=False)
    report_path = partial / "independent_audit_report.json"
    with report_path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(report, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")
    manifest = {
        "schema_version": "1.0",
        "status": "completed_independent_audit",
        "evaluation_directory": str(Path(evaluation_directory).resolve()),
        "evaluation_manifest_sha256": _sha256(
            Path(evaluation_directory) / "completion_manifest.json"
        ),
        "file_count_excluding_manifest": 1,
        "files": [
            {
                "name": report_path.name,
                "byte_count": report_path.stat().st_size,
                "sha256": _sha256(report_path),
            }
        ],
        "held_out_2024_target_access_count": 0,
        "boundary_future_target_access_count": 0,
        "authorized_technical_recovery_audited": True,
        "recovery_experiment_id": RECOVERY_EXPERIMENT_ID,
        "recovery_attempt_number": 2,
        "current_attempt_development_loader_call_count": 1,
        "cumulative_development_loader_call_count": 2,
        "prior_failed_development_access_attempt_count": 1,
        "original_single_read_contract_satisfied": False,
        "prior_attempt_scientific_result_file_count": 0,
    }
    manifest_path = partial / "completion_manifest.json"
    with manifest_path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")
    verify_independent_audit_directory(partial)
    partial.rename(audit_directory)
    return audit_directory / report_path.name


def verify_independent_audit_directory(audit_directory: Path) -> Mapping[str, Any]:
    """Verify the independent audit's own completion manifest and report."""

    directory = Path(audit_directory)
    manifest = _read_json(directory / "completion_manifest.json")
    rows = manifest.get("files")
    if (
        manifest.get("schema_version") != "1.0"
        or manifest.get("status") != "completed_independent_audit"
        or manifest.get("file_count_excluding_manifest") != 1
        or not isinstance(rows, list)
        or len(rows) != 1
        or rows[0].get("name") != "independent_audit_report.json"
        or manifest.get("held_out_2024_target_access_count") != 0
        or manifest.get("boundary_future_target_access_count") != 0
        or manifest.get("authorized_technical_recovery_audited") is not True
        or manifest.get("recovery_experiment_id") != RECOVERY_EXPERIMENT_ID
        or manifest.get("recovery_attempt_number") != 2
        or manifest.get("current_attempt_development_loader_call_count") != 1
        or manifest.get("cumulative_development_loader_call_count") != 2
        or manifest.get("prior_failed_development_access_attempt_count") != 1
        or manifest.get("original_single_read_contract_satisfied") is not False
        or manifest.get("prior_attempt_scientific_result_file_count") != 0
    ):
        raise RuntimeError("independent audit completion-manifest contract drift")
    report_path = directory / rows[0]["name"]
    if (
        not report_path.is_file()
        or report_path.stat().st_size != rows[0].get("byte_count")
        or _sha256(report_path) != rows[0].get("sha256")
    ):
        raise RuntimeError("independent audit report identity drift")
    report = _read_json(report_path)
    if (
        report.get("status") != "passed_independent_reconstruction"
        or report.get("evaluation_manifest_sha256")
        != manifest.get("evaluation_manifest_sha256")
        or report.get("authorized_technical_recovery_audited") is not True
        or report.get("cumulative_development_loader_call_count") != 2
        or report.get("held_out_2024_target_access_count") != 0
        or report.get("boundary_future_target_access_count") != 0
    ):
        raise RuntimeError("independent audit report completion drift")
    actual_names = {
        path.name for path in directory.iterdir() if path.is_file()
    }
    if actual_names != {"independent_audit_report.json", "completion_manifest.json"}:
        raise RuntimeError("independent audit artifact set drift")
    return manifest


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evaluation-directory", type=Path, required=True)
    parser.add_argument("--audit-directory", type=Path, required=True)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    arguments = _build_parser().parse_args(argv)
    write_independent_audit(
        arguments.evaluation_directory, arguments.audit_directory
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
