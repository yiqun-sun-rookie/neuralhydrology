"""Run unchanged formal training through checkpoint-safe scheduler slices.

Usage: python -B hpc/run_scheduler_slice.py --case explicit_gru__historical_capacity
Only injects the existing scheduler_deadline argument. No training config, epoch
budget, scientific choice, optimizer or mathematical operation is changed.
"""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]

def scheduler_deadline(job,query=subprocess.run):
    result=query(['scontrol','show','job','-o',job],capture_output=True,text=True,check=True,timeout=30)
    fields=dict(re.findall(r'(\w+)=([^\s]+)',result.stdout))
    if fields['JobId']!=job or fields['JobState']!='RUNNING' or fields['WorkDir']!=str(ROOT):
        raise ValueError('scheduler allocation identity mismatch')
    end=fields['EndTime']
    if end in ('Unknown','NONE','N/A'):
        raise ValueError('finite scheduler allocation end time is required')
    remaining=datetime.datetime.fromisoformat(end).timestamp()-time.time()
    if remaining<=600:
        raise ValueError('allocation has insufficient remaining checkpoint margin')
    return time.perf_counter()+remaining-600,fields

def main():
    job=os.environ['SLURM_JOB_ID']
    deadline,fields=scheduler_deadline(job)
    sys.path.insert(0,str(ROOT/'scripts'))
    spec=importlib.util.spec_from_file_location('registered_formal_case',ROOT/'scripts/train_supercomputer_case.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    from src.training import SchedulerContinuation
    original=module.execute_group
    def execute(*args,**kwargs):
        if 'scheduler_deadline' in kwargs:raise ValueError('duplicate scheduler deadline')
        return original(*args,scheduler_deadline=deadline,**kwargs)
    module.execute_group=execute
    try:
        module.main()
    except SchedulerContinuation:
        record={'status':'scheduler_slice_saved_for_continuation','job_id':job,'checked_at':datetime.datetime.now().astimezone().isoformat(),'scheduler':fields,'checkpoint_boundary':'all members retain their own last complete epoch including optimizer and selection history','formal_training_complete':False,'scientific_budget_changed':False,'code_hash':module.code_identity(),'wrapper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
        path=ROOT/'records'/('scheduler_slice_end_'+job+'.json')
        with path.open('x',encoding='utf-8') as f:json.dump(record,f,sort_keys=True,indent=2);f.write('\n')
        print(json.dumps(record),flush=True)
    except Exception as error:
        print(json.dumps({'status':'training_stopped','error_type':type(error).__name__,'reason':str(error)}),flush=True)
        raise

if __name__=='__main__':main()
