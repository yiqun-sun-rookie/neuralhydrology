"""Capture the rejected original Joseph update after the finite-factor guard.

Only frozen training normalization and the single 2021 selection batch93 are
read. No optimizer step, formal epoch, final evaluation, or replacement math.
"""
import argparse
import datetime
import hashlib
import inspect
import json
from pathlib import Path
import random
import traceback

import numpy as np
import torch

from authenticated_source_helpers import (import_source,validate_metadata,
    validate_adam,sha256_file,read_json,write_exclusive,cpu_tree)

ROOT=Path(__file__).resolve().parents[1]


def save_tensor(path,value):
    with path.open('xb') as stream:torch.save(cpu_tree(value),stream)
    return {'path':str(path),'sha256':sha256_file(path),'bytes':path.stat().st_size}


def summary(value):
    good=torch.isfinite(value)
    return {'shape':list(value.shape),'dtype':str(value.dtype),'stride':list(value.stride()),
        'finite':bool(good.all()),'nan_count':int(torch.isnan(value).sum()),
        'inf_count':int(torch.isinf(value).sum()),
        'maximum_finite_absolute':float(value[good].abs().max()) if bool(good.any()) else None}


def main():
    evidence=ROOT/'evidence';evidence.mkdir(exist_ok=False)
    spec=read_json(ROOT/'diagnostic_spec.json');source=Path(spec['source_root']);pinned=spec['pinned_source_files']
    result={'status':'posterior_covariance_capture_started','diagnostic_root':str(ROOT),'source_root':str(source),
        'source_code_hash':spec['source_code_hash'],'checked_at_beijing':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
        'formal_training_epochs_added':0,'optimizer_updates':0,'formal_recovery_admitted':False,
        'scientific_rules_changed':False,'evaluation_values_read':False,'historical_rng_equality_established':False,
        'training_input_values_read':False,'selection_input_values_read':False}
    code=1;api=None;captured=None;session=None
    try:
        assert str(ROOT)==spec['diagnostic_root'] and spec['maximum_replay_epochs']==0 and spec['maximum_optimizer_updates']==0
        assert len(spec['all_member_source_files'])==12
        assert all(sha256_file(Path(p))==s for p,s in pinned.items())
        assert all(sha256_file(Path(i['path']))==i['sha256'] for i in spec['tensor_artifacts'].values())
        assert sha256_file(Path(spec['prior_guard_result']['path']))==spec['prior_guard_result']['sha256']
        prior=read_json(Path(spec['prior_guard_result']['path']))
        assert prior['status']=='finite_factor_guard_candidate_validation_failed' and prior['last_validation_batch']==93
        api=import_source(source,spec['source_code_hash'])
        args=argparse.Namespace(expected_config_sha256=spec['source_run_files']['config.json']['sha256'],
            expected_checkpoint_sha256=spec['source_run_files']['continuation.pt']['sha256'],expected_code_sha256=spec['source_code_hash'])
        run,config,protocol,manifest,seals,_=validate_metadata(source,spec['run_id'],args,api)
        api.training.deterministic_runtime();torch.set_num_threads(4)
        device=api.execution.device_identity(config['effective_config']['device'])
        assert device==config['effective_config']['device_identity']==spec['expected_device_identity']
        result['device_identity']=device
        train=api.runtime.load_stage(manifest,'tuning_train');result['training_input_values_read']=True
        stats=api.runtime.fit_stage_stats(train,manifest);del train
        assert api.scheduler.digest_json(api.runtime.stats_record(stats))==config['effective_config']['normalization_hash']
        start=torch.load(spec['tensor_artifacts']['before_validation_model_adam_rng.pt']['path'],map_location='cpu',weights_only=True)
        session=api.runtime.build_session(run,config,protocol,stats,evidence/'scratch_session',seals)
        api.training.restore_parts(session.parts,start['model'],session.noise)
        session.optimizer.load_state_dict(start['optimizer']);validate_adam(session,api,6906)
        random.setstate(start['rng']['python']);nr=start['rng']['numpy']
        np.random.set_state((nr[0],np.asarray(nr[1],dtype=np.uint32),*nr[2:]))
        torch.set_rng_state(start['rng']['torch_cpu']);torch.cuda.set_rng_state_all(start['rng']['torch_cuda'])
        model_before=api.training.snapshot_parts(session.parts,session.noise)
        f=api.filter;guard=inspect.getsource(f.stable_cholesky)
        assert guard.count('if int(info)==0:')==1
        guard=guard.replace('if int(info)==0:','if int(info)==0 and bool(torch.isfinite(factor).all()):')
        assert hashlib.sha256(guard.encode()).hexdigest()==prior['guarded_function_source_sha256']
        exec(compile(guard,'<isolated proven finite-factor guard>','exec'),f.__dict__)
        guarded=f.stable_cholesky
        context={'selection_phase':'tuning_select','selection_years':[2021],'validation_batch_index':93,
                 'window_indices':list(range(1472,1488)),'analysis_step':0}
        original_predict=f.unscented_predict
        def predict(*args,**kwargs):
            context['analysis_step']+=1
            return original_predict(*args,**kwargs)
        f.unscented_predict=predict
        def observe(p,ledger=None):
            nonlocal captured
            try:return guarded(p,ledger)
            except f.FilterFailure as error:
                frame=inspect.currentframe().f_back
                try:
                    if captured is None and frame.f_code.co_name=='linear_update' and p.shape[-1]==128:
                        names=('mean','covariance','observation','matrix','offset','r_diagonal','r','ph',
                               'innovation_cov','chol','gain','residual','posterior','complement','p')
                        actual={k:frame.f_locals[k].detach() for k in names if isinstance(frame.f_locals.get(k),torch.Tensor)}
                        assert 'p' in actual and 'complement' in actual and 'gain' in actual
                        values={'context':dict(context),'actual_linear_update_locals':actual,
                            'tensor_layouts':{k:summary(v) for k,v in actual.items()},
                            'original_jitters':list(f.JITTERS),'noise_variances':f.noise_variances(session.noise),
                            'guarded_function_source_sha256':hashlib.sha256(guard.encode()).hexdigest(),
                            'linear_update_source':inspect.getsource(f.linear_update),
                            'exception_reason':str(error),'exception_evidence':error.evidence}
                        captured=save_tensor(evidence/'posterior_covariance_original_operands.pt',values)
                        result.update(capture_context=dict(context),actual_operand_summaries=values['tensor_layouts'],
                                      original_operands_artifact=captured)
                        # Only after the exact original operands are saved, estimate spectra.
                        spectra={}
                        for name in ('covariance','innovation_cov','p'):
                            tensor=actual[name]
                            if bool(torch.isfinite(tensor).all()):
                                spectra[name]={device_name:torch.linalg.eigvalsh((v+v.transpose(-1,-2))*.5).amin(-1).cpu().tolist()
                                    for device_name,v in [('original_gpu',tensor),('cpu_float64',tensor.cpu())]}
                        write_exclusive(evidence/'posterior_covariance_analysis.json',{
                            'status':'posterior_covariance_original_operands_captured','context':dict(context),
                            'reason':str(error),'error_evidence':error.evidence,'spectra_float64_estimates':spectra,
                            'exact_positive_definiteness_not_decided_by_float64_estimates':True,
                            'operand_summaries':values['tensor_layouts'],'original_operands_artifact':captured,
                            'original_jitters':list(f.JITTERS),'replacement_math_applied':False})
                except Exception as capture_error:
                    write_exclusive(evidence/'posterior_capture_error.json',{'original_reason':str(error),
                        'capture_error':str(capture_error),'traceback':traceback.format_exc()})
                finally:del frame
                raise
        f.stable_cholesky=observe
        selected=api.runtime.load_stage(manifest,'tuning_select');result['selection_input_values_read']=True
        windows,_=api.runtime.prepare_windows(selected,stats)
        assert len(windows)==prior['validation_windows']==7804
        batch=api.execution.move_batch(api.contracts.combine_batches(windows[1472:1488]),session.device)
        try:
            with torch.no_grad():api.training.branch_prediction(session.parts,session.noise,session.whitening,session.method,batch,f.StabilityLedger())
        except f.FilterFailure as error:
            assert captured is not None
            result.update(status='posterior_covariance_original_failure_captured',reason=str(error),
                error_evidence=error.evidence,exception_type=type(error).__name__,
                candidate_guard_failure_class_and_shape_reproduced=(str(error)==prior['reason'] and context['analysis_step']==24),
                exact_stored_matrix_match_to_prior_not_claimed=True)
        else:
            result.update(status='posterior_covariance_failure_not_reproduced',reason=None)
        after=api.training.snapshot_parts(session.parts,session.noise)
        assert all(torch.equal(model_before[k][n],after[k][n]) for k in model_before for n in model_before[k])
        validate_adam(session,api,6906)
        adam_after=cpu_tree(session.optimizer.state_dict())
        assert adam_after['param_groups']==start['optimizer']['param_groups']
        assert all(torch.equal(adam_after['state'][key][name],value)
            for key,row in start['optimizer']['state'].items() for name,value in row.items())
        result.update(model_and_adam_unchanged=True,source_optimizer_steps=6906,final_optimizer_steps=6906,
            diagnostic_rng_restored=True,selection_phase='tuning_select',selection_years=[2021],
            training_years=[2017,2018,2019,2020],normalization_hash=config['effective_config']['normalization_hash'],
            guarded_function_source_sha256=hashlib.sha256(guard.encode()).hexdigest(),original_jitters=list(f.JITTERS))
        code=0
    except Exception as error:
        result.update(status='posterior_covariance_diagnostic_technical_error',error_type=type(error).__name__,
                      reason=str(error),traceback=traceback.format_exc())
    finally:
        same={p:sha256_file(Path(p))==s for p,s in pinned.items()}
        result.update(source_file_unchanged_checks=same,all_source_bytes_unchanged=all(same.values()),
            source_code_unchanged=api is not None and api.scheduler.code_identity(source)==spec['source_code_hash'],
            finished_at_beijing=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat())
        if not result['all_source_bytes_unchanged'] or not result['source_code_unchanged']:code=1
        result['exit_code']=code;write_exclusive(evidence/'posterior_diagnostic_result.json',result)
        print(json.dumps({k:v for k,v in result.items() if k!='source_file_unchanged_checks'},sort_keys=True,allow_nan=False),flush=True)
    return code


if __name__=='__main__':raise SystemExit(main())
