"""Bounded saved-matrix float64 compensated Cholesky and gradient diagnostic.

Run on the registered RTX 3090 with python -B hpc/audit_compensated_factor.py.
No model/data loader/optimizer/validation or formal checkpoint is loaded.
All compensation uses float64 tensors; high precision is a CPU reference only.
"""
import datetime
import hashlib
import json
from pathlib import Path
import sys
import traceback

import mpmath as mp
import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def tensor_sha(value):
    return hashlib.sha256(value.detach().contiguous().cpu().numpy().tobytes()).hexdigest()


def save(name, value):
    with (ROOT/'evidence'/name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, sort_keys=True, allow_nan=False)
        stream.write('\n')


def two_sum(a, b):
    total = a+b
    recovered = total-a
    return total, (a-(total-recovered))+(b-recovered)


def add(a, al, b, bl):
    high, low = two_sum(a, b)
    return two_sum(high, (al+bl)+low)


def mul(a, al, b, bl):
    splitter = 134217729.0
    aa, bb = splitter*a, splitter*b
    ah, bh = aa-(aa-a), bb-(bb-b)
    ar, br = a-ah, b-bh
    high = a*b
    low = ((ah*bh-high)+ah*br+ar*bh)+ar*br
    return two_sum(high, low+(a*bl+al*b)+al*bl)


def reduce_pairs(high, low):
    while high.shape[-1] > 1:
        if high.shape[-1] % 2:
            high = torch.cat((high, torch.zeros_like(high[..., :1])), dim=-1)
            low = torch.cat((low, torch.zeros_like(low[..., :1])), dim=-1)
        high, low = add(high[..., 0::2], low[..., 0::2],
                        high[..., 1::2], low[..., 1::2])
    return high[..., 0], low[..., 0]


@torch.no_grad()
def compensated_cholesky(matrix):
    """Original unpivoted lower Cholesky recurrence with float64 residuals."""
    assert matrix.dtype == torch.float64 and matrix.device.type == 'cuda'
    assert matrix.ndim == 2 and matrix.shape[0] == matrix.shape[1]
    assert torch.equal(matrix, matrix.T) and bool(torch.isfinite(matrix).all())
    n = matrix.shape[0]
    high, low = torch.zeros_like(matrix), torch.zeros_like(matrix)
    for j in range(n):
        if j:
            ph, pl = mul(high[j:, :j], low[j:, :j], high[j, :j], low[j, :j])
            sh, sl = reduce_pairs(ph, pl)
            rh, rl = add(matrix[j:, j], torch.zeros_like(sh), -sh, -sl)
        else:
            rh, rl = matrix[:, 0].clone(), torch.zeros_like(matrix[:, 0])
        if not bool(torch.isfinite(rh).all() and torch.isfinite(rl).all()) or not bool(rh[0] > 0):
            return None, {'positive': False, 'rejected_pivot': j,
                          'pivot_high': float(rh[0]), 'pivot_low': float(rl[0])}
        root = torch.sqrt(rh[0])
        sqh, sql = mul(root, root.new_zeros(()), root, root.new_zeros(()))
        eh, el = add(rh[0], rl[0], -sqh, -sql)
        dh, dl = two_sum(root, (eh+el)/(2*root))
        quotient = rh/dh
        qh, ql = quotient, torch.zeros_like(quotient)
        # Two compensated quotient corrections retain the low part of L.
        for _ in range(2):
            ph, pl = mul(qh, ql, dh, dl)
            eh, el = add(rh, rl, -ph, -pl)
            qh, ql = add(qh, ql, (eh+el)/dh, torch.zeros_like(eh))
        high[j:, j], low[j:, j] = qh, ql
        high[j, j], low[j, j] = dh, dl
    factor = high+low
    finite = bool(torch.isfinite(factor).all() and (factor.diagonal() > 0).all())
    return (factor if finite else None), {'positive': finite, 'all_recurrence_tensors_float64': True}


class CompensatedCholesky(torch.autograd.Function):
    @staticmethod
    def forward(ctx, matrix):
        factor, evidence = compensated_cholesky(matrix)
        if factor is None:
            raise FloatingPointError(str(evidence))
        ctx.save_for_backward(factor)
        return factor

    @staticmethod
    def backward(ctx, output_gradient):
        (factor,) = ctx.saved_tensors
        projected = torch.tril(factor.T@output_gradient)
        projected = projected-torch.diag_embed(projected.diagonal()*.5)
        left = torch.linalg.solve_triangular(factor.T, projected, upper=True)
        gradient = torch.linalg.solve_triangular(factor.T, left.T, upper=True).T
        return (gradient+gradient.T)*.5


def reference(matrix, digits, output_gradient=None):
    """Independent arbitrary-precision CPU reference of the exact input bytes."""
    with mp.workdps(digits):
        a = mp.matrix([[mp.mpf(float(x)) for x in row] for row in matrix.numpy()])
        factor = mp.cholesky(a)
        nearest = np.array(factor.tolist(), dtype=np.float64)
        record = {'digits': digits, 'positive': True,
                  'minimum_factor_diagonal': mp.nstr(min(factor[i, i] for i in range(a.rows)), 50),
                  'nearest_float64_factor_sha256': hashlib.sha256(nearest.tobytes()).hexdigest()}
        gradient = None
        if output_gradient is not None:
            g = mp.matrix([[mp.mpf(float(x)) for x in row] for row in output_gradient.numpy()])
            product = factor.T*g
            projected = mp.matrix(a.rows)
            for i in range(a.rows):
                for j in range(i+1):
                    projected[i, j] = product[i, j]*(mp.mpf('.5') if i == j else 1)
            inverse = factor**-1
            full = inverse.T*projected*inverse
            full = (full+full.T)*mp.mpf('.5')
            gradient = np.array(full.tolist(), dtype=np.float64)
            record['nearest_float64_gradient_sha256'] = hashlib.sha256(gradient.tobytes()).hexdigest()
        return record, torch.from_numpy(nearest), None if gradient is None else torch.from_numpy(gradient)


def relative_max(actual, expected):
    actual, expected = actual.detach().cpu(), expected.detach().cpu()
    return float((actual-expected).abs().max()/expected.abs().max().clamp_min(1e-300))


def main():
    (ROOT/'evidence').mkdir(exist_ok=False)
    spec = json.loads((ROOT/'diagnostic_spec.json').read_bytes())
    assert str(ROOT) == spec['diagnostic_root']
    source = Path(spec['source_root'])
    assert len(spec['pinned_source_files']) == 58 and len(spec['source_code_file_hashes']) == 37
    for path, expected in spec['pinned_source_files'].items():
        assert sha(path) == expected
    for path, expected in spec['source_code_file_hashes'].items():
        assert sha(source/path) == expected
    assert sha(spec['raw_path']) == spec['raw_sha256']
    assert sha(spec['cpu_audit_path']) == spec['cpu_audit_sha256']
    assert sha(spec['parent_factor_result_path']) == spec['parent_factor_result_sha256']
    parent = json.loads(Path(spec['parent_factor_result_path']).read_bytes())
    assert parent['original_gpu_rejection_reproduced'] and not parent['any_power_two_congruence_factor_passed']
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    assert torch.cuda.is_available() and torch.cuda.device_count() == 1
    props = torch.cuda.get_device_properties(0)
    device = {'device': 'cuda:0', 'name': props.name, 'total_memory_bytes': props.total_memory}
    assert device == spec['expected_device_identity']
    raw = torch.load(spec['raw_path'], map_location='cpu', weights_only=True)
    frames = {f['function']: f for f in raw['original_failure_traceback_frames']}
    index = frames['repair_rejected_members']['scalars']['i']
    original = frames['linear_update']['tensors']['p']
    candidate = frames['repair_rejected_members']['tensors']['candidate']
    assert index == 10 and tensor_sha(original[index]) == spec['original_posterior_sha256']
    assert tensor_sha(candidate[0]) == spec['compensated_candidate_sha256']
    sys.path.insert(0, str(source))
    from src.differentiable_filter import JITTERS, FilterFailure, stable_cholesky
    assert list(JITTERS) == spec['original_jitters'] == raw['original_jitters']
    gpu = original.to('cuda:0')
    controls, changed, factors = [], [], []
    eye = torch.eye(128, dtype=torch.float64, device='cuda:0')
    for i in range(16):
        try:
            baseline = stable_cholesky(gpu[i:i+1])[0]
        except FilterFailure:
            changed.append(i)
            attempts = []
            selected = None
            for jitter in JITTERS:
                selected, observation = compensated_cholesky(gpu[i]+jitter*eye)
                attempts.append({'jitter': jitter, **observation})
                if selected is not None:
                    break
            controls.append({'member_index': i, 'original_accepted': False,
                             'compensated_attempts': attempts, 'compensated_accepted': selected is not None,
                             'selected_jitter': attempts[-1]['jitter'] if selected is not None else None})
            factors.append(selected)
        else:
            # The conditional path returns the already accepted factor verbatim.
            selected = baseline
            previous = parent['original_member_controls'][i]
            assert previous['member_index'] == i and previous['original_accepted']
            assert tensor_sha(selected) == previous['factor_sha256']
            controls.append({'member_index': i, 'original_accepted': True,
                             'factor_sha256': tensor_sha(baseline), 'conditional_factor_sha256': tensor_sha(selected),
                             'factor_bitwise_preserved': True})
            factors.append(selected)
    assert changed == [10]
    comparisons = []
    gradient_passed = False
    references_passed = False
    gradient_comparison = None
    if factors[index] is not None and controls[index]['selected_jitter'] == 0:
        for name, matrix in [('original', original[index]), ('compensated_joseph', candidate[0])]:
            factor, observation = compensated_cholesky(matrix.to('cuda:0'))
            references = [reference(matrix, precision) for precision in (80, 120)]
            equal = torch.equal(references[0][1], references[1][1])
            errors = [relative_max(factor, r[1]) if factor is not None else None for r in references]
            # Check every nonzero reference factor entry, rather than allowing
            # large matrix entries to hide an inaccurate small pivot.
            detailed_error = None
            if factor is not None:
                ref = references[-1][1]
                mask = ref != 0
                detailed_error = float(((factor.cpu()[mask]-ref[mask]).abs()/ref[mask].abs()).max())
            passed = bool(equal and factor is not None and detailed_error <= spec['relative_gate'])
            comparisons.append({'matrix': name, 'input_sha256': tensor_sha(matrix),
                'recurrence': observation, 'reference_records': [r[0] for r in references],
                'two_precision_rounded_factors_equal': equal, 'relative_max_errors': errors,
                'maximum_entrywise_relative_error': detailed_error, 'reference_gate_passed': passed})
        references_passed = all(c['reference_gate_passed'] for c in comparisons)
        a = original[index].to('cuda:0').requires_grad_(True)
        factor = CompensatedCholesky.apply(a)
        positions = torch.arange(factor.numel(), dtype=torch.float64, device='cuda:0').reshape_as(factor)
        coefficient = torch.tril(torch.sin(positions+1)/(factor.detach().abs().clamp_min(1)))
        (factor*coefficient).sum().backward()
        gradients = [reference(original[index], precision, coefficient.cpu()) for precision in (80, 120)]
        errors = [relative_max(a.grad, r[2]) for r in gradients]
        reference_error = relative_max(gradients[0][2], gradients[1][2])
        gradient_passed = bool(torch.isfinite(a.grad).all() and max(errors+[reference_error]) <= spec['relative_gate'])
        gradient_comparison = {'gate': spec['relative_gate'], 'relative_max_errors': errors,
            'two_precision_reference_relative_max_error': reference_error,
            'reference_records': [r[0] for r in gradients], 'gradient_finite': bool(torch.isfinite(a.grad).all()),
            'gradient_gate_passed': gradient_passed, 'output_gradient_sha256': tensor_sha(coefficient)}
    assert torch.equal(gpu.cpu(), original)
    assert all(sha(p) == h for p, h in spec['pinned_source_files'].items())
    assert all(sha(source/p) == h for p, h in spec['source_code_file_hashes'].items())
    assert sha(spec['raw_path']) == spec['raw_sha256']
    accepted = bool(references_passed and gradient_passed and all(f is not None for f in factors))
    save('compensated_factor_gate_result.json', {
        'status': 'saved_compensated_factor_gate_completed',
        'checked_at_beijing': datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
        'diagnostic_root': str(ROOT), 'device_identity': device, 'source_code_hash': spec['source_code_hash'],
        'operands_sha256': spec['raw_sha256'], 'source_identity_count': 58, 'source_code_file_count': 37,
        'original_member_controls': controls, 'changed_member_indices': changed,
        'factor_reference_comparisons': comparisons, 'gradient_comparison': gradient_comparison,
        'factor_reference_gate_passed': references_passed, 'gradient_gate_passed': gradient_passed,
        'saved_matrix_gate_passed': accepted, 'all_originally_accepted_members_bitwise_preserved': True,
        'all_source_and_input_bytes_unchanged': True, 'all_twelve_failed_members_preserved': True,
        'original_jitters': list(JITTERS), 'covariance_formula_changed': False,
        'matrix_changed': False, 'network_or_covariance_dtype_changed': False,
        'formal_repair_admitted': False, 'formal_training_restarted': False,
        'formal_training_epochs_added': 0, 'optimizer_updates': 0,
        'training_data_values_read': False, 'selection_data_values_read': False,
        'evaluation_values_read': False, 'original_2021_validation_run': False,
        'scientific_rules_changed': False})


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        if (ROOT/'evidence').is_dir():
            save('compensated_factor_gate_technical_error.json', {
                'status': 'saved_compensated_factor_gate_technical_error',
                'error_type': type(error).__name__, 'error': str(error), 'traceback': traceback.format_exc(),
                'formal_training_epochs_added': 0, 'evaluation_values_read': False,
                'scientific_rules_changed': False})
        raise
