"""Exclusive one-shot submission of the isolated covariance replay.

python -B hpc/submit_covariance_diagnostic.py
Read source FAILED accounting and live own-account work directories first.
An uncertain submission reserves its attempt forever; it must be reconciled by
read-only queue/accounting inspection, never by executing this entry again.
"""
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]
XBATCH = '/usr/local/globle/softs/slurm/19.05.4.1/bin/xbatch'


def now():
    return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def save(name, value):
    with (ROOT / 'records' / name).open('x', encoding='utf-8') as f:
        json.dump(value, f, sort_keys=True, indent=2, allow_nan=False)
        f.write('\n')


def query(args):
    p = subprocess.run(args, capture_output=True, text=True, timeout=30)
    assert p.returncode == 0, {'args': args, 'stdout': p.stdout, 'stderr': p.stderr}
    return {'command': args, 'returncode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}


def verify_prior_technical_failure(spec):
    prior=spec['prior_technical_failure']
    path=Path(prior['result_path'])
    assert hashlib.sha256(path.read_bytes()).hexdigest()==prior['result_sha256']
    value=json.loads(path.read_bytes())
    assert value['exception_type']=='FileExistsError' and not value['covariance_failure_observed']
    assert value['source_bytes_unchanged'] and value['source_code_unchanged']
    assert value['formal_training_epochs_added']==0
    for key,expected in [('original_validation_stability_ledger','ledger_sha256'),('before_validation_model_adam_rng','batch_start_sha256')]:
        assert hashlib.sha256(Path(value[key]['path']).read_bytes()).hexdigest()==prior[expected]
    accounting=subprocess.run(['sacct','-n','-X','-j',prior['job_id'],'--format=JobID,State,ExitCode,Start,End','-P'],capture_output=True,text=True,check=True,timeout=30)
    rows=[line.split('|') for line in accounting.stdout.splitlines() if line.startswith(prior['job_id']+'|')]
    assert len(rows)==1 and rows[0][:5]==[prior['job_id'],'COMPLETED','0:0',prior['actual_start'],prior['actual_end']]
    return rows[0]

def main():
    spec = json.loads((ROOT / 'diagnostic_spec.json').read_text())
    assert str(ROOT) == spec['diagnostic_root']
    assert not (ROOT / 'records/diagnostic_submission_attempt.json').exists(), 'prior attempt must be reconciled; no retry'
    assert not (ROOT / 'evidence').exists(), 'prior diagnostic execution must not be overwritten'
    verify_prior_technical_failure(spec)
    source = Path(spec['source_root'])
    jobs = json.loads((source / 'records/scheduler_jobs.json').read_text())
    assert str(jobs[spec['case']]) == str(spec['source_job']) == '242937'
    import sys
    sys.path.insert(0, str(source))
    from src.scheduler import code_identity
    assert code_identity(source) == spec['source_code_hash']
    for name, identity in spec['source_run_files'].items():
        path = source / 'runs' / spec['run_id'] / name
        assert sha(path) == identity['sha256'] and path.stat().st_size == identity['bytes'], name
    for rid,files in spec['all_member_source_files'].items():
        for name,identity in files.items():
            path=source/'runs'/rid/name
            assert sha(path)==identity['sha256'] and path.stat().st_size==identity['bytes']
    assert sha(Path(spec['verified_pathfix_script'])) == spec['verified_pathfix_sha256']
    queue = query(['squeue', '-h', '-u', 'sunyiq', '-o', '%i|%j|%T|%Z'])
    rows = [line.split('|') for line in queue['stdout'].splitlines() if line.strip()]
    assert all(len(row) == 4 for row in rows)
    assert not any(row[0] == spec['source_job'] for row in rows)
    assert not any(row[1].startswith('zj_gru_') or row[1].startswith('zj_gru_gradient_recovery')
                   or row[3] in (str(ROOT), str(source)) for row in rows), 'source or same diagnostic is active'
    accounting = query(['sacct', '-n', '-X', '-j', spec['source_job'], '--format=JobID,State,ExitCode,Start,End,NodeList', '-P'])
    entries = [line.strip().split('|') for line in accounting['stdout'].splitlines() if line.strip()]
    assert len(entries) == 1 and entries[0][:3] == [spec['source_job'], 'FAILED', '1:0']
    assert entries[0][3:5]==spec['source_actual_start_end']
    parent=query(['sacct','-n','-X','-j',spec['parent_gate_job'],'--format=JobID,State,ExitCode,Start,End','-P'])
    prows=[l.split('|') for l in parent['stdout'].splitlines() if l.startswith(spec['parent_gate_job']+'|')]
    assert len(prows)==1 and prows[0][:5]==[spec['parent_gate_job'],'COMPLETED','0:0',spec['parent_gate_actual_start'],spec['parent_gate_actual_end']]
    assert not any(r[0]==spec['parent_gate_job'] for r in rows)
    assert sha(Path(spec['parent_gate_result_path']))==spec['parent_gate_result_sha256']
    proof=json.loads(Path(spec['parent_gate_result_path']).read_bytes());assert proof['saved_matrix_gate_passed'] and proof['gradient_gate_passed']
    assert all(sha(Path(p))==h for p,h in spec['pinned_source_files'].items())
    assert all(sha(source/p)==h for p,h in spec['bootstrap_test_sha256'].items())
    manifest = json.loads((ROOT / 'package_manifest.json').read_text())
    for relative, identity in manifest['files'].items():
        path = ROOT / relative
        assert path.is_file() and sha(path) == identity['sha256'] and path.stat().st_size == identity['bytes'], relative
    script = ROOT / 'hpc/covariance_diagnostic.slurm'
    body = script.read_text().splitlines()
    assert '#SBATCH -p hgpu2p' in body and '#SBATCH --gres=gpu:1' in body
    assert '#SBATCH --cpus-per-task=4' in body and '#SBATCH --exclude=ngu002,ngu011' in body
    assert '#SBATCH --time=02:00:00' in body and '#SBATCH --time-min=00:30:00' in body
    assert body.index('conda activate nh_final') < body.index('set -u')
    assert not any('pytest' in line or 'run_scheduler_slice' in line or 'train_supercomputer_case' in line for line in body)
    assert body[-1].startswith('python -B -u hpc/replay_validation_covariance_diagnostic.py ')
    for name in ('replay_validation_covariance_diagnostic.py', 'authenticated_source_helpers.py', 'submit_covariance_diagnostic.py'):
        compile((ROOT / 'hpc' / name).read_text(), str(ROOT / 'hpc' / name), 'exec')
    attempt = {'status': 'reserved_no_retry', 'checked_at_beijing': now(), 'script': str(script),
               'script_sha256': sha(script), 'spec_sha256': sha(ROOT / 'diagnostic_spec.json'),
               'package_manifest_sha256': sha(ROOT / 'package_manifest.json'), 'queue': queue,
               'source_accounting': accounting, 'formal_training_restarted': False,
               'evaluation_values_read': False, 'source_state_unchanged': True}
    save('diagnostic_submission_attempt.json', attempt)
    try:
        p = subprocess.run([XBATCH, str(script)], cwd=str(ROOT), capture_output=True, text=True, timeout=60)
    except Exception as error:
        save('diagnostic_submission_response.json', {'status': 'uncertain_read_only_reconciliation_required',
             'checked_at_beijing': now(), 'error_type': type(error).__name__, 'error': str(error)})
        raise
    save('diagnostic_submission_response.json', {'checked_at_beijing': now(), 'returncode': p.returncode,
         'stdout': p.stdout, 'stderr': p.stderr})
    match = re.fullmatch(r'Submitted batch job ([0-9]+)\s*', p.stdout)
    if p.returncode != 0 or match is None:
        raise RuntimeError('exclusive submission response uncertain; inspect, never repeat')
    job = match.group(1)
    save('scheduler_jobs.json', {'covariance_diagnostic': job})
    print(json.dumps({'status': 'compensated_validation_ledgerfix_submitted', 'checked_at_beijing': now(),
          'diagnostic_root': str(ROOT), 'source_failed_job': spec['source_job'], 'job_id': job,
          'script_sha256': attempt['script_sha256'], 'spec_sha256': attempt['spec_sha256'],
          'package_manifest_sha256': attempt['package_manifest_sha256'],
          'formal_training_restarted': False, 'formal_epochs_added': 0,
          'scientific_rules_changed': False, 'evaluation_values_read': False}), flush=True)


if __name__ == '__main__':
    main()
