"""Authenticate all twelve failed-group continuations in an isolated release.
Preserve source failures, completed parent group, complete histories and Adam.
Only the implementation/configuration binding changes. No raw data is opened.
"""
import ast,copy,datetime,hashlib,json,pathlib,shutil,subprocess,sys
import torch
ROOT=pathlib.Path(__file__).resolve().parents[1]
PARENT=pathlib.Path('/data1/home/sunyiq/zhenjiang_complete_comparison_20261016_recovery_006')
CASE='explicit_gru__historical_capacity'
OLD_CODE='4232fbb467341b6332f91e9289cdb975613babb5d29e2079b66d55f7822c3757'
sys.path.insert(0,str(ROOT))
from src.scheduler import code_identity,seal_group,digest_json,verify_parent_binding
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(v,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
def state_hash(v):
    h=hashlib.sha256()
    def visit(x):
        if isinstance(x,torch.Tensor):
            x=x.detach().cpu().contiguous();h.update(str((str(x.dtype),tuple(x.shape))).encode());h.update(x.reshape(-1).view(torch.uint8).numpy().tobytes())
        elif isinstance(x,dict):
            for k in sorted(x,key=repr):h.update(repr(k).encode());visit(x[k])
        elif isinstance(x,(list,tuple)):
            h.update(str(len(x)).encode())
            for y in x:visit(y)
        else:h.update(json.dumps(x,sort_keys=True,allow_nan=False).encode())
    visit(v);return h.hexdigest()
def finite(v):
    if isinstance(v,torch.Tensor):assert torch.isfinite(v).all(),'nonfinite source state'
    elif isinstance(v,dict):
        for x in v.values():finite(x)
    elif isinstance(v,(list,tuple)):
        for x in v:finite(x)
def main():
    intent=read(ROOT/'records/covariance_recovery_intent_20261015.json')
    assert str(ROOT)==intent['recovery_root'] and str(PARENT)==intent['source_root']
    assert all(sha(pathlib.Path(p))==expected for p,expected in intent['pinned_source_files'].items())
    assert sha(pathlib.Path(intent['candidate_result_path']))==intent['candidate_result_sha256']
    candidate=read(pathlib.Path(intent['candidate_result_path']))
    assert candidate['status']=='sqrt_gpu_epoch47_and_original2021_passed'
    assert candidate['exit_code']==0 and candidate['source_complete_epochs']==46 and candidate['source_optimizer_steps']==7060
    assert candidate['successful_in_memory_batches']==154 and candidate['final_in_memory_optimizer_steps']==[7214]
    assert candidate['original_2021_validation_completed'] and candidate['validation_windows']==7804 and candidate['validation_batches']==488
    assert candidate['parameters_changed'] and candidate['optimizer_steps_advanced']==154 and candidate['source_bytes_unchanged']
    assert candidate['formal_epochs_added']==0 and not candidate['formal_recovery_confirmed'] and not candidate['evaluation_values_read']
    assert sha(pathlib.Path(intent['candidate_bootstrap_path']))==intent['candidate_bootstrap_sha256']
    boot=read(pathlib.Path(intent['candidate_bootstrap_path']))
    assert boot['status']=='sqrt_gpu_original39_and_new_production_passed' and boot['original_tests']==39
    assert boot['candidate_code_hash']==intent['recovery_code_hash'] and boot['hardware']['actual_device_identity']==intent['new_device_identity']
    assert boot['stored_operand_gradient_relative_error']<1e-7 and boot['direct_factor_sigma_points'] and boot['new_prediction_factor_path']
    assert sha(ROOT/'human_authority.json')==intent['scientific_representation_authority_sha256']
    assert read(ROOT/'human_authority.json')['human_answer_verbatim']=='允许平方根表示修复，其余规则不变（推荐）'
    assert sha(ROOT/'records/hardware_authority.json')==intent['hardware_authority_sha256']
    assert sha(pathlib.Path(intent['candidate_cpu_path']))==intent['candidate_cpu_sha256']
    actual={p.relative_to(ROOT).as_posix():sha(p) for p in sorted([*ROOT.joinpath('src').glob('*.py'),*ROOT.joinpath('scripts').glob('*.py'),*ROOT.joinpath('vendor/pytides').glob('*.py')])}
    assert actual==intent['new_code_file_hashes']
    oldfiles={p.relative_to(PARENT).as_posix():sha(p) for p in sorted([*PARENT.joinpath('src').glob('*.py'),*PARENT.joinpath('scripts').glob('*.py'),*PARENT.joinpath('vendor/pytides').glob('*.py')])}
    assert oldfiles==intent['source_code_file_hashes']
    assert sorted(k for k in set(actual)|set(oldfiles) if actual.get(k)!=oldfiles.get(k))==['src/differentiable_filter.py','src/square_root_filter.py']
    old_completed=pathlib.Path(intent['old_completed_source_root'])
    assert code_identity(old_completed)==intent['old_completed_source_code_hash']
    assert read(old_completed/'records/authorization.json')['code_hash']==intent['old_completed_source_code_hash']
    job=str(read(PARENT/'records/scheduler_jobs.json')[CASE])
    assert job==intent['source_failed_job']=='243692'
    q=subprocess.run(['squeue','-h','-u','sunyiq','-o','%i|%j|%T'],capture_output=True,text=True,check=True)
    assert not any(l.split('|')[0]==job or l.split('|')[1].startswith(('zj_gru_','zj_sqrt_')) for l in q.stdout.splitlines()),'source or related derived allocation active'
    a=subprocess.run(['sacct','-n','-X','-j',job,'--format=JobID,State,ExitCode','-P'],capture_output=True,text=True,check=True)
    assert job+'|FAILED|1:0' in a.stdout,'source failure unconfirmed'
    completed_query=subprocess.run(['sacct','-n','-X','-j',intent['candidate_job_id'],'--format=JobID,State,ExitCode,Start,End','-P'],capture_output=True,text=True,check=True)
    completed_rows=[line.split('|') for line in completed_query.stdout.splitlines() if line.strip()]
    assert len(completed_rows)==1 and completed_rows[0][:5]==[intent['candidate_job_id'],'COMPLETED','0:0',intent['candidate_actual_start'],intent['candidate_actual_end']]
    assert code_identity(PARENT)==OLD_CODE
    new=code_identity();auth=read(ROOT/'records/authorization.json');assert auth['code_hash']==new==intent['recovery_code_hash']
    assert auth['authority']['technical_recovery'] and auth['authority']['formal_training'] and not auth['authority']['evaluation_year_reads']
    assert sha(ROOT/'configs/protocol-v3.json')==auth['protocol_sha256']
    for name in ['protocol-v3.json','registry-v3.json']:
        assert (ROOT/'configs'/name).read_bytes()==(PARENT/'configs'/name).read_bytes(),'scientific config changed'
    assert not (PARENT/'records'/CASE/'tune_branch_group_outcome.json').exists(),'branch completed; reuse instead'
    outcome_path=PARENT/'records'/CASE/'tune_foundation_group_outcome.json';outcome=read(outcome_path)
    seal=seal_group(CASE+'__tune_foundation_group__seal',outcome['members'],400,expected_members=list(outcome['members']))
    from dataclasses import asdict
    assert asdict(seal)==dict(outcome['seal'],member_ids=tuple(outcome['seal']['member_ids']))
    for member in outcome['members'].values():
        assert sha(pathlib.Path(member['checkpoint_path']))==member['checkpoint_sha256']
        assert len(member['validation_mae'])==400 and member['epochs']==400
    completed_source_audit=[]
    for rid,member in outcome['members'].items():
        checkpoint=pathlib.Path(member['checkpoint_path'])
        folder=checkpoint.parent
        saved=torch.load(folder/'continuation.pt',map_location='cpu',weights_only=True)
        finite(saved)
        metric=read(folder/'metrics.json')
        assert len(saved['values'])==len(saved['train_metrics'])==len(saved['shuffle_hashes'])==400
        assert saved['values']==metric['validation_mae_cm']==member['validation_mae']
        assert saved['train_metrics']==metric['train_metrics'] and saved['shuffle_hashes']==metric['shuffle_hashes']
        assert saved['config_sha256']==sha(folder/'config.json')
        assert member['best_epoch']==min(range(400),key=lambda i:saved['values'][i])+1
        assert state_hash(saved['best'])==state_hash(torch.load(checkpoint,map_location='cpu',weights_only=True))
        completed_source_audit.append({'run':rid,'epochs':400,'best_epoch':member['best_epoch'],
            'best_checkpoint_sha256':sha(checkpoint),'continuation_sha256':sha(folder/'continuation.pt'),
            'metrics_sha256':sha(folder/'metrics.json'),'all_history_and_selection_verified':True})
    write(ROOT/'records/completed_source1200_audit.json',{'members':completed_source_audit,'epochs':1200})
    dest=ROOT/'records'/CASE;dest.mkdir()
    shutil.copyfile(outcome_path,dest/'tune_foundation_group_outcome.json')
    # Preserve original completed-group provenance and parent checkpoint paths.
    write(ROOT/'records/completed_group_reuse.json',{'source':str(outcome_path),'sha256':sha(outcome_path),'members':list(outcome['members']),'epochs':400,'retrained':False,'parent_checkpoint_paths_preserved':True})
    for split in ['tuning','final']:
        p=ROOT/'prepared'/split/'manifest.json';p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(PARENT/'prepared'/split/'manifest.json',p)
    prep=read(PARENT/'records/data_preparation_complete.json');assert prep['status']=='admitted' and prep['code_hash']==OLD_CODE
    shutil.copyfile(PARENT/'records/data_preparation_complete.json',ROOT/'records/parent_data_preparation_complete.json')
    prep['code_hash']=new;prep['recovery_reauthentication']={'source_root':str(PARENT),'source_record_sha256':sha(PARENT/'records/data_preparation_complete.json'),'unchanged_manifests':True,'no_data_or_tide_refit':True}
    write(ROOT/'records/data_preparation_complete.json',prep)
    configs=read(PARENT/'records'/CASE/'tune_branch_group_configs.json');assert len(configs)==12
    registered=read(ROOT/'configs/registry-v3.json')['runs'];expected={r['exp_id'] for r in registered if r['budget_group']==CASE+'__tune_branch_group' and r['status']!='alias'}
    assert set(configs)==expected
    shutil.copytree(PARENT/'records/source_failures',ROOT/'records/source_failures/inherited_006')
    migrations=[]
    for run,config in configs.items():
        source=PARENT/'runs'/run;target=ROOT/'runs'/run
        assert read(source/'config.json')==config and config['effective_config']['code_hash']==OLD_CODE
        failure=read(source/'failure.json');assert failure['status']=='failed' and failure['evidence']['attempted_jitters']==[0.,1e-10,1e-9,1e-8,1e-7,1e-6,1e-5,.0001]
        verify_parent_binding(config['registration'],config['effective_config'],{seal.group_id:seal})
        source_ids={n:sha(source/n) for n in ['config.json','continuation.pt','metrics.json','failure.json']}
        assert all(intent['pinned_source_files'][str(source/n)]==digest for n,digest in source_ids.items())
        archive=ROOT/'records/source_failures/006_current'/run;archive.mkdir(parents=True)
        shutil.copyfile(source/'failure.json',archive/'failure.json')
        shutil.copyfile(source/'config.json',archive/'source_config.json')
        state=torch.load(source/'continuation.pt',map_location='cpu',weights_only=True);finite(state)
        assert state['config_sha256']==source_ids['config.json']
        metric=read(source/'metrics.json');epochs=len(state['values'])
        assert epochs==failure['epochs_completed'] and epochs in [46,47]
        assert all(len(state[k])==epochs for k in ['values','train_metrics','shuffle_hashes'])
        assert state['values']==metric['validation_mae_cm'] and state['train_metrics']==metric['train_metrics'] and state['shuffle_hashes']==metric['shuffle_hashes']
        before=state_hash({k:v for k,v in state.items() if k!='config_sha256'})
        target.mkdir();config['effective_config']['code_hash']=new;config['effective_config']['device_identity']=intent['new_device_identity'];write(target/'config.json',config)
        state['config_sha256']=sha(target/'config.json')
        with (target/'continuation.pt').open('xb') as f:torch.save(state,f)
        check=torch.load(target/'continuation.pt',map_location='cpu',weights_only=True)
        assert state_hash({k:v for k,v in check.items() if k!='config_sha256'})==before
        shutil.copyfile(source/'metrics.json',target/'metrics.json')
        write(target/'recovery_from_failure.json',{'source_root':str(PARENT),'source_failure':str(source/'failure.json'),'source_files':source_ids,'source_code':OLD_CODE,'recovery_code':new,'source_failure_retained':True,'technical_reason':'Human-authorized persistent square-root covariance; all other scientific rules unchanged.'})
        assert all(sha(source/n)==h for n,h in source_ids.items())
        migrations.append({'run':run,'epochs_preserved':epochs,'source_files':source_ids,'source_root':str(PARENT),'training_state_semantic_sha256':before,'recovery_config_sha256':state['config_sha256'],'recovery_checkpoint_sha256':sha(target/'continuation.pt'),'only_checkpoint_metadata_change':'config_sha256'})
    assert sorted(m['epochs_preserved'] for m in migrations)==[46]+[47]*11
    write(dest/'tune_branch_group_configs.json',configs)
    write(ROOT/'records/recovery_preparation_complete.json',{'status':'authenticated_continuation_prepared','case':CASE,'source_job':job,'parent_root':str(PARENT),'parent_code_hash':OLD_CODE,'recovery_code_hash':new,'migrations':migrations,'scientific_protocol_unchanged':True,'old_failure_and_checkpoints_preserved':True,'completed_foundation_group_reused':True,'evaluation_values_read':False})
    inherited_runtime=PARENT/'records/covariance_recovery_runtime_admitted_20261015.json'
    ready=read(inherited_runtime);runtime=pathlib.Path(ready['runtime'])
    assert str(runtime)=='/data1/home/sunyiq/zhenjiang_complete_comparison_20261012_recovery_003/hpc/startup_dependency_runtime_20261013_v1'
    assert all(sha(runtime/name)==digest for name,digest in ready['runtime_files'].items())
    assert sha(ROOT/'hpc/prepare_recovery.py')=='53854600e635bfa24b832eb49018bdd4e598a11fdd48c4c29ff39ad7d73ad53e'
    startup={'runtime':str(runtime),'runtime_files':ready['runtime_files'],'source_runtime_record':str(inherited_runtime),
             'source_runtime_record_sha256':sha(inherited_runtime),'global_packages_modified':False,'reinstalled':False}
    write(ROOT/'records/covariance_recovery_runtime_admitted_20261015.json',startup)
    assert all(sha(pathlib.Path(p))==expected for p,expected in intent['pinned_source_files'].items())
    assert code_identity(PARENT)==OLD_CODE and code_identity()==new
    audit={'status':'covariance_recovery_cpu_admitted','checked_at_beijing':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),'case':CASE,'source_job':job,'source_root':str(PARENT),'root':str(ROOT),'code_hash':new,'source_code_hash':OLD_CODE,'scientific_protocol_sha256':auth['protocol_sha256'],'scientific_protocol_unchanged':True,'registry_unchanged':True,'member_count':12,'preserved_branch_complete_member_epochs':sum(m['epochs_preserved'] for m in migrations),'preserved_old_source_complete_member_epochs':1200,'migrations':migrations,'completed_foundation_group_reused':True,'old_completed_source_code_hash':intent['old_completed_source_code_hash'],'source_bytes_unchanged':True,'all_failures_retained':True,'candidate_result_sha256':intent['candidate_result_sha256'],'candidate_full_validation_verified':True,'candidate_direct_gradient_verified':True,'diagnostic_partial_epoch_checkpoint_used':False,'runtime':startup,'source_sacct':a.stdout,'candidate_sacct':completed_query.stdout,'evaluation_values_read':False,'training_submitted':False}
    write(ROOT/'records/covariance_recovery_cpu_admitted_20261015.json',audit)
    print(json.dumps(audit,sort_keys=True),flush=True)
    print(json.dumps({'status':'authenticated_continuation_prepared','epochs':[m['epochs_preserved'] for m in migrations],'code_hash':new}),flush=True)
if __name__=='__main__':main()
