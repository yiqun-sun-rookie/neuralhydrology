"""Actual formal allocation original39 and factor-production admission."""
import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def read(path):
    return json.loads(Path(path).read_bytes())

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def now():
    return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()

def save(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')

def bootstrap():
    spec = spec_and_pins()
    import torch
    props = torch.cuda.get_device_properties(0)
    profile = dict(job_id=os.environ['SLURM_JOB_ID'], node=os.environ.get('SLURMD_NODENAME'),
                   actual_device_identity=dict(device='cuda:0', name=props.name,
                                               total_memory_bytes=props.total_memory),
                   capability=[props.major, props.minor], measured_at=now())
    save(ROOT / ('records/sqrt_hardware_'+os.environ['SLURM_JOB_ID']+'.json'), profile)
    print(json.dumps(profile), flush=True)
    assert profile['capability'] == [8, 6]
    assert ((props.name == 'NVIDIA GeForce RTX 3090' and props.total_memory == 25296044032)
            or (props.name == 'NVIDIA A40' and props.total_memory >= 25296044032))
    assert (props.name == 'NVIDIA A40' and os.environ['SLURM_JOB_PARTITION'] == 'hgpu4'
            or props.name == 'NVIDIA GeForce RTX 3090' and os.environ['SLURM_JOB_PARTITION'] == 'hgpu2p')
    env = dict(os.environ, ZHENJIANG_TEST_DEVICE='cuda',
               ZHENJIANG_ACCEPTANCE_RECEIPT=str(ROOT / ('records/bootstrap_original39_'+os.environ['SLURM_JOB_ID']+'.json')),
               ZHENJIANG_A40_HARDWARE_PROFILE=str(ROOT / ('records/sqrt_hardware_'+os.environ['SLURM_JOB_ID']+'.json')))
    env['PYTHONPATH'] = spec['pytest_runtime'] + os.pathsep + str(ROOT)
    command = [sys.executable, '-B', '-m', 'pytest',
               *[str(ROOT / 'acceptance' / name) for name in (
                   'test_gradient_recovery.py', 'test_training.py',
                   'test_numerical_recovery.py', 'test_joseph_recovery.py')],
               '-q', '-p', 'no:cacheprovider', '--basetemp', str(ROOT / 'records/gpu_test_temp')]
    process = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True, timeout=650)
    save(ROOT / ('records/bootstrap_original39_output_'+os.environ['SLURM_JOB_ID']+'.json'),
         dict(command=command, returncode=process.returncode, stdout=process.stdout, stderr=process.stderr))
    assert process.returncode == 0, process.stdout + process.stderr
    acceptance = read(ROOT / ('records/bootstrap_original39_'+os.environ['SLURM_JOB_ID']+'.json'))
    assert acceptance['exit_status'] == 0 and acceptance['tests_collected'] == 39
    assert acceptance['formal_training_steps'] == acceptance['real_data_optimizer_steps'] == acceptance['raw_evaluation_year_reads'] == 0
    sys.path.insert(0, str(ROOT))
    from src import differentiable_filter as dense, square_root_filter as factor
    from src.scheduler import code_identity
    from src.training import deterministic_runtime
    deterministic_runtime()
    torch.set_num_threads(4)
    assert code_identity() == spec['candidate_code_hash']
    operand = Path(spec['stored_root']) / 'evidence/covariance_failure_operands.pt'
    assert sha(operand) == spec['stored_operands_sha256']
    raw = torch.load(operand, map_location='cpu', weights_only=True)
    frames = {frame['function']: frame for frame in raw['original_failure_traceback_frames']}
    index = frames['repair_rejected_members']['scalars']['i']
    values = frames['linear_update']['tensors']
    prior, complement, gain, r = [values[k][index:index + 1].to('cuda:0')
                                 for k in ('covariance', 'complement', 'gain', 'r_diagonal')]
    ledger = dense.StabilityLedger()
    lower = dense.stable_cholesky(prior, ledger)
    columns = torch.cat((complement @ lower, gain * r.sqrt()[:, None, :]), -1).detach().requires_grad_()
    result = factor.factor_columns(columns, ledger)
    direct = factor.joseph_factor(lower, complement, gain, r)
    assert torch.equal(result.detach(), direct)
    n = prior.shape[-1]
    w = torch.diag(torch.arange(1, n + 1, device='cuda:0', dtype=torch.float64) / n)[None]
    gradient, = torch.autograd.grad((w * (result @ result.transpose(-1, -2))).sum(), columns)
    expected = 2 * w @ columns.detach()
    error = float((gradient - expected).abs().max() / expected.abs().max())
    assert bool(torch.isfinite(gradient).all()) and error < 1e-7, error
    points, wm, wc = factor.points_from_factor(torch.zeros_like(prior[:, 0]), direct)
    assert points.shape == (1, 257, 128) and torch.isfinite(points).all()
    assert list(dense.JITTERS) == spec['original_jitters']
    from src.models import make_parts
    from src.contracts import Whitening
    parts = make_parts('explicit_gru', 'historical_capacity', 101)
    from src.execution import move_parts
    noise = dense.make_noise(128)
    whitening = Whitening(torch.zeros(128, dtype=torch.float64), torch.ones(128, dtype=torch.float64))
    whitening = move_parts(parts, noise, whitening, 'cuda:0')
    mean, predicted = factor.predict_factor(parts, torch.zeros(1, 128, device='cuda:0', dtype=torch.float64),
                                            torch.eye(128, device='cuda:0', dtype=torch.float64)[None],
                                            torch.zeros(1, 3, device='cuda:0'), whitening, noise)
    assert torch.isfinite(mean).all() and torch.isfinite(predicted).all()
    assert (predicted.diagonal(dim1=-2, dim2=-1) > 0).all()
    spec_and_pins()
    value = dict(status='sqrt_gpu_original39_and_new_production_passed', at=now(),
                 job_id=os.environ['SLURM_JOB_ID'], root=str(ROOT), hardware=profile,
                 original_tests=39, original_acceptance_sha256=sha(ROOT / ('records/bootstrap_original39_'+os.environ['SLURM_JOB_ID']+'.json')),
                 candidate_code_hash=code_identity(), candidate_sha256=sha(ROOT / 'src/square_root_filter.py'),
                 stored_operand_gradient_relative_error=error, direct_factor_sigma_points=True,
                 new_prediction_factor_path=True, original_jitters=list(dense.JITTERS),
                 ledger_attempts=[x.tolist() for x in ledger.current_jitter],
                 real_data_optimizer_steps=0, formal_epochs_added=0, evaluation_values_read=False)
    save(ROOT / ('records/sqrt_bootstrap_'+os.environ['SLURM_JOB_ID']+'.json'), value)
    print(json.dumps(value), flush=True)

def spec_and_pins():
    spec=read(ROOT/'gpu_spec.json')
    assert spec['root']==str(ROOT)
    assert sha(ROOT/'human_authority.json')==spec['authority_sha256']
    assert sha(ROOT/'records/stored_operand_cpu_admission.json')==spec['cpu_result_sha256']
    for name,digest in spec['candidate_files'].items():assert sha(ROOT/name)==digest
    manifest=read(ROOT/'release_manifest.json')
    for name,item in manifest['files'].items():assert sha(ROOT/name)==item['sha256']
    for files in spec['all_member_source_files'].values():
        for item in files.values():assert sha(Path(item['path']))==item['sha256']
    return spec

if __name__=='__main__':bootstrap()
