"""Full-state unscented propagation and differentiable affine Joseph updates."""
from dataclasses import dataclass, field
import torch
from torch.nn import Parameter
from torch.nn.functional import softplus
from .contracts import FilterNoise, Whitening
from .models import LSTMReadout, CoordinateReadout

JITTERS=(0.,1e-10,1e-9,1e-8,1e-7,1e-6,1e-5,1e-4)

class FilterFailure(FloatingPointError):
    def __init__(self,message,evidence):
        super().__init__(message)
        self.evidence=evidence

@dataclass
class StabilityLedger:
    step_jitters: list = field(default_factory=list)
    current_jitter: list = field(default_factory=list)

    def record(self,values):
        self.current_jitter.append(values.detach().cpu())

    def end_step(self,batch_size):
        maximum=(torch.stack(self.current_jitter).amax(0) if self.current_jitter
                 else torch.zeros(batch_size,dtype=torch.float64))
        self.step_jitters.extend(maximum.tolist())
        self.current_jitter.clear()

    def report(self,enforce=True):
        total=len(self.step_jitters)
        large=sum(j>1e-6 for j in self.step_jitters)
        report={'analysis_steps':total,'large_jitter_steps':large,
                'large_jitter_fraction':large/total if total else 0.,
                'max_jitter':max(self.step_jitters,default=0.),'step_jitters':list(self.step_jitters)}
        if enforce and total and large/total>.01:
            raise FilterFailure('large jitter exceeds 1% of analysis steps',report)
        return report

def symmetric(p):
    return (p+p.transpose(-1,-2))*.5

def stable_cholesky(p,ledger=None):
    p=symmetric(p)
    if p.ndim!=3 or p.dtype!=torch.float64 or not torch.isfinite(p).all():
        raise FilterFailure('invalid covariance',{'shape':list(p.shape)})
    d=p.shape[-1]
    eye=torch.eye(d,dtype=p.dtype,device=p.device)
    factors=[]
    jitters=[]
    for item in p:
        for jitter in JITTERS:
            factor,info=torch.linalg.cholesky_ex(item+jitter*eye)
            if int(info)==0:
                factors.append(factor)
                jitters.append(jitter)
                break
        else:
            raise FilterFailure('covariance not positive definite after permitted jitter',
                                {'attempted_jitters':list(JITTERS),
                                 'minimum_eigenvalue':float(torch.linalg.eigvalsh(item.detach()).min())})
    if ledger is not None:
        ledger.record(torch.tensor(jitters,dtype=p.dtype))
    return torch.stack(factors)

def make_noise(state_dim):
    def raw(value,size):
        return Parameter(torch.full((size,),torch.log(torch.expm1(torch.tensor(value-1e-6,dtype=torch.float64))).item(),dtype=torch.float64))
    return FilterNoise(raw(.001,state_dim),raw(.01,4),raw(.01,1))

def noise_variances(noise):
    return tuple(softplus(p)+1e-6 for p in (noise.raw_q,noise.raw_r,noise.raw_p0))

def observation_affine(parts,whitening):
    d=parts.state_dim
    if isinstance(parts.readout,LSTMReadout):
        w=parts.readout.in_features
        zero=parts.readout.weight.new_zeros(4,w)
        a=torch.cat((zero,parts.readout.weight,zero,zero),dim=1).to(torch.float64)
        bias=parts.readout.bias.to(torch.float64)
    elif isinstance(parts.readout,CoordinateReadout):
        a=torch.eye(d,dtype=torch.float64,device=whitening.mean.device)[:4]
        bias=a.new_zeros(4)
    else:
        raise ValueError('unregistered affine readout')
    return a*whitening.scale[None],a@whitening.mean+bias

def linear_update(mean,covariance,observation,matrix,offset,r_diagonal,ledger=None):
    b,d=mean.shape
    if matrix.ndim==2:
        matrix=matrix[None].expand(b,-1,-1)
    r_diagonal=r_diagonal.expand(b,-1)
    r=torch.diag_embed(r_diagonal)
    ph=covariance@matrix.transpose(-1,-2)
    innovation_cov=symmetric(matrix@ph+r)
    chol=stable_cholesky(innovation_cov,ledger)
    gain=torch.cholesky_solve(ph.transpose(-1,-2),chol).transpose(-1,-2)
    residual=observation-(matrix@mean[...,None]).squeeze(-1)-offset
    posterior=mean+(gain@residual[...,None]).squeeze(-1)
    complement=torch.eye(d,dtype=mean.dtype,device=mean.device)[None]-gain@matrix
    p=symmetric(complement@covariance@complement.transpose(-1,-2)+gain@r@gain.transpose(-1,-2))
    stable_cholesky(p,ledger)
    if not torch.isfinite(posterior).all():
        raise FilterFailure('nonfinite posterior',{})
    return posterior,p

def unscented_points(mean,covariance,ledger=None):
    d=mean.shape[1]
    delta=stable_cholesky(covariance,ledger).transpose(-1,-2)*(d**.5)
    points=torch.cat((mean[:,None],mean[:,None]+delta,mean[:,None]-delta),dim=1)
    wm=mean.new_full((2*d+1,),1/(2*d)); wm[0]=0
    wc=wm.clone(); wc[0]=2
    return points,wm,wc

def unscented_moments(points,wm,wc):
    mean=torch.einsum('p,bpd->bd',wm,points)
    differences=points-mean[:,None]
    return mean,symmetric(torch.einsum('p,bpi,bpj->bij',wc,differences,differences))

def unscented_predict(parts,mean,covariance,control,whitening,noise,ledger=None):
    points,wm,wc=unscented_points(mean,covariance,ledger)
    b,n,d=points.shape
    physical=points*whitening.scale+whitening.mean
    propagated=parts.process(physical.reshape(b*n,d).to(torch.float32),
                              control[:,None].expand(b,n,3).reshape(b*n,3).to(torch.float32))
    whitened=(propagated.reshape(b,n,d).to(torch.float64)-whitening.mean)/whitening.scale
    predicted,p=unscented_moments(whitened,wm,wc)
    q,_,_=noise_variances(noise)
    p=symmetric(p+torch.diag(q)[None])
    stable_cholesky(p,ledger)
    return predicted,p

def filter_analysis(parts,noise,whitening,initial_state,batch,use_observations=True,ledger=None):
    if whitening.mean.numel()!=parts.state_dim:
        raise ValueError('full state whitening dimension')
    local=ledger is None
    ledger=StabilityLedger() if local else ledger
    mean=(initial_state.to(torch.float64)-whitening.mean)/whitening.scale
    _,r,p0=noise_variances(noise)
    p=torch.eye(parts.state_dim,dtype=torch.float64,device=mean.device)[None].expand(len(mean),-1,-1)*p0
    for i in range(24):
        mean,p=unscented_predict(parts,mean,p,batch.analysis_controls[:,i],whitening,noise,ledger)
        if use_observations:
            matrix,offset=observation_affine(parts,whitening)
            mean,p=linear_update(mean,p,batch.history[:,24+i,:4].to(torch.float64),matrix,offset,r,ledger)
        ledger.end_step(len(mean))
    report=ledger.report(enforce=local)
    report['posterior_covariance']=p
    return (mean*whitening.scale+whitening.mean).to(torch.float32),report

def fit_whitening(parts,phase_zero_batches):
    """49 equal-weight states per eligible phase-zero window, streamed moments."""
    count=0; total=None; squared=None
    with torch.no_grad():
        for batch in phase_zero_batches:
            mid=parts.initializer(batch.history[:,:24])
            end=parts.initializer(batch.history[:,24:],mid)
            states=[mid,end]; state=mid
            for control in batch.midpoint_controls.unbind(1):
                state=parts.process(state,control)
                states.append(state)
            stack=torch.stack(states,dim=1).to(torch.float64).reshape(-1,parts.state_dim)
            count+=len(stack)
            total=stack.sum(0) if total is None else total+stack.sum(0)
            squared=stack.square().sum(0) if squared is None else squared+stack.square().sum(0)
    if not count:
        raise ValueError('empty whitening calendar')
    mean=total/count
    scale=(squared/count-mean.square()).clamp_min(0).sqrt().clamp_min(.001)
    return Whitening(mean.detach(),scale.detach())
