"""Admitted separate input/label/tide files, fresh sessions and frozen inference.

Called only after command line guards. No directory scans for raw data, no
historical model imports and no automatic data admission or cluster submission.
"""
from dataclasses import asdict
from pathlib import Path
import hashlib
import json
import time
import numpy as np
import torch
from .contracts import CHANNELS, TARGETS, Whitening, combine_batches, GroupSeal
from .data_contract import read_admitted_npz, build_calendar, build_physical_window, PHASE_YEARS
from .normalization import fit_training_stats,normalize_window,denormalize_targets_cm
from .models import make_parts,count_parameters
from .state_estimators import make_branches,configure_branch,hash_module
from .differentiable_filter import make_noise,fit_whitening,StabilityLedger
from .training import (FitSession,train_group,restore_parts,branch_prediction,foundation_predictions,
                       snapshot_parts,validation_mae,epoch_indices)
from .scheduler import digest_json,seal_group,verify_parent_binding
from .execution import bound_device,move_parts,model_device,device_batches

def stats_record(stats):
    return {k:(v.tolist() if isinstance(v,np.ndarray) else list(v) if isinstance(v,tuple) else v)
            for k,v in asdict(stats).items()}

def load_stage(manifest,phase):
    """Each source has one admitted role. Mixed-year sources are not opened."""
    if manifest.get('units')!='m' or manifest.get('timestamp_rule')!='whole_hour' or not manifest.get('timezone'):
        raise ValueError('metre units, whole-hour rule and source timezone required')
    if set(manifest.get('tide_training_years',[]))!=set(PHASE_YEARS['tuning_train' if phase.startswith('tuning') else 'final_train']):
        raise ValueError('astronomical tide training years not bound to stage')
    columns={role:[] for role in ('realtime_inputs','qc_labels','astronomical_tide')}
    for entry in manifest['files']:
        if phase in entry.get('phases',[]) and entry['role'] in columns:
            expected_order={'realtime_inputs':list(CHANNELS),'qc_labels':list(TARGETS),
                            'astronomical_tide':['astronomical_tide']}[entry['role']]
            if entry.get('station_order')!=expected_order:
                raise ValueError('named source channel order missing or changed')
            if not entry.get('datum') or not entry.get('provider'):
                raise ValueError('source datum and provider identity required')
            if manifest.get('business_time_availability_certified') and not entry.get('available_at_evidence'):
                raise ValueError('business availability claim lacks source evidence')
            columns[entry['role']].append(read_admitted_npz(entry['path'],manifest,phase,entry['role']))
    joined={}
    for role,files in columns.items():
        if not files: raise ValueError('missing admitted role: '+role)
        keys={'times',{'realtime_inputs':'history_m','qc_labels':'labels_m','astronomical_tide':'tide_m'}[role]}
        if any(set(f)!=keys for f in files): raise ValueError('data role has unexpected arrays')
        all_times=np.concatenate([f['times'] for f in files]).astype('datetime64[ns]')
        order=np.argsort(all_times)
        if len(np.unique(all_times))!=len(all_times): raise ValueError('duplicate admitted hours')
        value_key=next(k for k in keys if k!='times')
        joined[role]=(all_times[order],np.concatenate([f[value_key] for f in files])[order])
    times=joined['realtime_inputs'][0]
    if not all(np.array_equal(times,v[0]) for v in joined.values()):
        raise ValueError('source-role calendars must be explicitly aligned before admission')
    actual=set((times.astype('datetime64[Y]').astype(int)+1970).tolist())
    if actual!=set(PHASE_YEARS[phase]): raise ValueError('complete stage year list required')
    history=joined['realtime_inputs'][1]; labels=joined['qc_labels'][1]; tide=joined['astronomical_tide'][1]
    if not np.array_equal(history[:,6],tide,equal_nan=True): raise ValueError('history and forecast tide source disagree')
    eligible,excluded=build_calendar(times,history,labels,tide)
    return {'times':times,'history_m':history,'labels_m':labels,'tide_m':tide,'eligible':eligible,'excluded':excluded}

def prepare_windows(stage,stats):
    windows=[]
    for i in stage['eligible']:
        w=build_physical_window(stage['history_m'][i-47:i+1],stage['times'][i-47:i+1],
                                stage['tide_m'][i-23:i+24],stage['labels_m'][i-23:i+24])
        windows.append(normalize_window(w,stats))
    return windows,stage['times'][stage['eligible']]

def fit_stage_stats(stage,manifest):
    series={'times':stage['times'],'labels_m':stage['labels_m'],
            **{name:stage['history_m'][:,i] for i,name in enumerate(CHANNELS)}}
    years=tuple(sorted(set((stage['times'].astype('datetime64[Y]').astype(int)+1970).tolist())))
    return fit_training_stats(series,years,digest_json(manifest))

def batches(windows,size=16):
    return [combine_batches(windows[start:start+size]) for start in range(0,len(windows),size)]

def authenticated_checkpoint(path,sha):
    p=Path(path)
    if hashlib.sha256(p.read_bytes()).hexdigest()!=sha: raise ValueError('checkpoint changed')
    return torch.load(p,map_location='cpu',weights_only=True)

def whitening_record(whitening):
    return {'mean':whitening.mean.tolist(),'scale':whitening.scale.tolist()}

def load_whitening(record,sha):
    if digest_json(record)!=sha: raise ValueError('whitening digest changed')
    return Whitening(torch.tensor(record['mean'],dtype=torch.float64),torch.tensor(record['scale'],dtype=torch.float64))

def build_session(run,config,protocol,stats,output_root,seals=None):
    effective=config['effective_config']
    if effective is None or config.get('status')!='frozen_authorized': raise PermissionError('run config not frozen')
    from .scheduler import code_identity
    if effective['code_hash']!=code_identity(): raise ValueError('implementation code changed after freezing')
    if effective['budget_policy_hash']!=digest_json(protocol['training']): raise ValueError('budget rules changed')
    if effective['normalization_hash']!=digest_json(stats_record(stats)):
        raise ValueError('training statistics changed')
    verify_parent_binding(run,effective,seals or {})
    device=bound_device(effective)
    case=next(c for c in protocol['cases'] if c['family']+'__'+c['capacity']==run['case'])
    parts=make_parts(case['family'],case['capacity'],run['seed']); noise=None; wh=None
    if run['method']!='foundation':
        state=authenticated_checkpoint(effective['parent_checkpoint'],effective['parent_hash'])
        restore_parts(parts,state)
        if effective['initializer_hash']!=hash_module(parts.initializer): raise ValueError('initializer identity changed')
        parts=make_branches(parts,run['seed']+100000)[run['method']]
        if parts.encoder is not None and effective['analysis_initialization_hash']!=hash_module(parts.encoder):
            raise ValueError('analysis initialization changed')
        if run['method'].startswith('filter'):
            noise=make_noise(parts.state_dim)
            wh=load_whitening(effective['whitening'],effective['whitening_hash'])
        configure_branch(parts,noise,run['method'])
    if effective['optimizer']!='Adam' or effective['loss']!='high_water_weighted_station_equal_mae_cm':
        raise ValueError('optimizer or loss changed')
    wh=move_parts(parts,noise,wh,device)
    return FitSession(parts,noise,wh,run['method'],stats,run['seed'],effective['learning_rate'],
                      Path(output_root)/run['exp_id'],config)

def execute_group(group_id,registry,protocol,configs,manifest,output_root,seals=None,scheduler_deadline=None):
    members=[r for r in registry['runs'] if r['budget_group']==group_id and r['status']!='alias']
    if not members: raise ValueError('no physical group members')
    for run in members:
        effective=configs[run['exp_id']]['effective_config']
        bound_device(effective)
        verify_parent_binding(run,effective,seals or {})
    limits={configs[r['exp_id']]['effective_config'].get('group_wall_seconds_limit') for r in members}
    if len(limits)!=1:
        raise ValueError('group execution limits disagree')
    limit=next(iter(limits))
    if limit is None:
        if protocol.get('resource',{}).get('execution_policy')!='user_authorized_no_cost_or_timing_gate':
            raise PermissionError('unlimited execution requires explicit user authorization')
        deadline=None
    else:
        if limit<=0: raise ValueError('invalid execution limit')
        deadline=time.perf_counter()+limit
    split='tuning' if members[0]['type'].startswith('tune') else 'final'
    train=load_stage(manifest,split+'_train'); select=load_stage(manifest,split+'_select')
    stats=fit_stage_stats(train,manifest)
    training_windows,training_times=prepare_windows(train,stats)
    validation_windows,_=prepare_windows(select,stats)
    from .sealing import calendar_snapshot
    selection_calendar=calendar_snapshot(select,split+'_select')
    validation_batches=batches(validation_windows)
    sessions={r['exp_id']:build_session(r,configs[r['exp_id']],protocol,stats,output_root,seals) for r in members}
    for session in sessions.values():
        session.deadline=deadline
        session.scheduler_deadline=scheduler_deadline
    results,epochs=train_group(sessions,training_windows,training_times,validation_batches)
    for run in members:
        session=sessions[run['exp_id']]
        if run['method']=='foundation':
            ids,_=epoch_indices(training_times,run['seed'],1)
            whitening=fit_whitening(session.parts,device_batches(batches([training_windows[i] for i in ids]),session.device))
            record=whitening_record(whitening)
            (session.run_dir/'whitening.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
            results[run['exp_id']]['whitening_hash']=digest_json(record)
            results[run['exp_id']]['initializer_hash']=hash_module(session.parts.initializer)
        results[run['exp_id']].update({key:run[key] for key in ('case','seed','method','type')})
        results[run['exp_id']]['learning_rate']=configs[run['exp_id']]['effective_config']['learning_rate']
        results[run['exp_id']]['checkpoint_path']=str(session.run_dir/'best.pt')
        results[run['exp_id']]['normalization_hash']=digest_json(stats_record(stats))
        results[run['exp_id']]['selection_calendar_sha256']=digest_json(selection_calendar)
    seal=seal_group(group_id+'__seal',results,epochs,expected_members=list(sessions))
    return {'seal':asdict(seal),'members':results,'statistics':stats_record(stats),
            'calendar':{'training':len(training_windows),'validation':len(validation_windows),
                        'training_snapshot':calendar_snapshot(train,split+'_train'),
                        'selection_snapshot':selection_calendar,'selection_sha256':digest_json(selection_calendar),
                        'training_excluded':train['excluded'],'validation_excluded':select['excluded']}}

def frozen_model(run,config,checkpoint):
    effective=config['effective_config']; family,capacity=run['case'].split('__')
    parts=make_parts(family,capacity,run['seed']); noise=None; wh=None
    if run['method']!='foundation':
        parts=make_branches(parts,run['seed']+100000)[run['method']]
        if run['method'].startswith('filter'):
            noise=make_noise(parts.state_dim); wh=load_whitening(effective['whitening'],effective['whitening_hash'])
        configure_branch(parts,noise,run['method'])
    state=authenticated_checkpoint(checkpoint['path'],checkpoint['sha256']); restore_parts(parts,state,noise)
    wh=move_parts(parts,noise,wh,bound_device(effective))
    return parts,noise,wh

def prediction_table(run,config,checkpoint,windows,issue_times,stats,use_observations=True,diagnostic_kind=None,foundation_whitening=None):
    import pandas as pd
    parts,noise,wh=frozen_model(run,config,checkpoint)
    if diagnostic_kind is not None and run['method']=='foundation':
        from .diagnostics import foundation_diagnostic
        wh=load_whitening(foundation_whitening,digest_json(foundation_whitening)) if foundation_whitening is not None else None
        wh=move_parts(parts,None,wh,model_device(parts))
    outputs=[]; truths=[]
    ledger=StabilityLedger() if run['method'].startswith('filter') or diagnostic_kind=='initial_noise_filter' else None
    with torch.no_grad():
        for batch in device_batches(batches(windows),model_device(parts)):
            if diagnostic_kind is not None and run['method']=='foundation':
                pred=foundation_diagnostic(parts,wh,batch,diagnostic_kind,ledger)
            else:
                pred=(foundation_predictions(parts,batch)[1] if run['method']=='foundation' else
                      branch_prediction(parts,noise,wh,run['method'],batch,ledger,use_observations=use_observations))
            outputs.append(denormalize_targets_cm(pred.double(),stats).cpu().numpy())
            truths.append(batch.targets_m[:,24:].cpu().numpy()*100)
    if ledger is not None: ledger.report()
    prediction=np.concatenate(outputs); observation=np.concatenate(truths)
    b,h,s=np.indices(prediction.shape)
    times=np.asarray(issue_times)[b.ravel()]
    return pd.DataFrame({'run_id':run['exp_id'],'year':times.astype('datetime64[Y]').astype(int)+1970,
        'seed':run['seed'],'issue_time':times,'lead_hour':h.ravel()+1,'station':np.asarray(TARGETS)[s.ravel()],
        'prediction_cm':prediction.ravel(),'observation_cm':observation.ravel(),'eligible':True,'reason':''})
