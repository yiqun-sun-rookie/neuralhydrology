"""Frozen evaluation tables, complete contrasts and two historical protections."""
import numpy as np
from .contracts import PredictionRows,TARGETS
from .scoring import (prediction_cube,score_rows,paired_resamples,scientific_decision,historical_constraints,
                      replacement_decision,sensitivity_decision,retention_admission,event_diagnostics)

def rows_from_frame(frame):
    required={'issue_time','lead_hour','station','seed','prediction_cm','observation_cm','eligible','reason'}
    if not required.issubset(frame.columns) or not frame['eligible'].all() or frame['reason'].fillna('').ne('').any():
        raise ValueError('ineligible or failed prediction rows cannot be silently removed')
    return PredictionRows(frame['issue_time'].to_numpy(dtype='datetime64[ns]'),frame['lead_hour'].to_numpy(),
        frame['station'].to_numpy(),frame['seed'].to_numpy(),frame['prediction_cm'].to_numpy(),frame['observation_cm'].to_numpy())

def align_reference(new_frame,old_frame,stations=TARGETS):
    left=rows_from_frame(new_frame); right=rows_from_frame(old_frame)
    # Validate the ORIGINAL complete grid before calendar intersection.
    nc,nl,nt,ns=prediction_cube(left,stations); oc,ol,ot,os=prediction_cube(right,stations)
    common=np.intersect1d(nt,ot); li=np.searchsorted(nt,common); ri=np.searchsorted(ot,common)
    if not len(common) or not np.array_equal(nl[li],ol[ri]): raise ValueError('common historical labels cannot be certified')
    return nc[:,li],oc[:,ri],nl[li],common,nt,ot,ol

def complete_scientific_comparisons(frames,protocol,thresholds_cm):
    results=[]
    for year in protocol['statistics']['years']:
        for track in protocol['statistics']['tracks']:
            for case in protocol['cases']:
                name=case['family']+'__'+case['capacity']
                cubes={}; common_labels=None; common_times=None; common_seeds=None
                for method in protocol['method_order']:
                    cube,labels,times,seeds=prediction_cube(rows_from_frame(frames[(year,track,name,method)]))
                    if list(seeds)!=sorted(protocol['seeds']): raise ValueError('missing final seed')
                    if common_labels is not None and (not np.array_equal(labels,common_labels) or not np.array_equal(times,common_times) or not np.array_equal(seeds,common_seeds)):
                        raise ValueError('methods do not share the full input-defined calendar')
                    common_labels,common_times,common_seeds=labels,times,seeds
                    cubes[method]=np.abs(cube-labels[None])
                for left,right in protocol['statistics']['within_case_contrasts']:
                    sensitivity=[]
                    for days in (3,7,14):
                        res=paired_resamples(cubes[left],cubes[right],common_times,True,days,
                            protocol['statistics']['resamples'],protocol['statistics']['seed'])
                        sensitivity.append({'block_days':days,'decision':scientific_decision(res),
                            'point_relative_improvement':res['point_relative_improvement'],
                            'corrected_interval':res['corrected_interval'],'ordinary_interval':res['ordinary_interval'],
                            'time_sampling_sha256':res['time_sampling_sha256'],'estimable':res['estimable']})
                    results.append({'year':year,'track':track,'case':name,'left':left,'right':right,
                        'block_sensitivity':sensitivity,'sensitive':len({x['decision'] for x in sensitivity})>1,
                        'global_contrasts':64})
    if len(results)!=64: raise ValueError('incomplete global 64-contrast family')
    return results

def replacement_report(candidate_frames,joint_frames,specialist_frames,thresholds_cm,policy,protocol):
    constraints={}; decisions={}; retention={}
    for year in (2024,2023):
        new=candidate_frames[year]; old=joint_frames[year]; z=specialist_frames[year]
        n,reference,labels,common,nt,ot,old_labels=align_reference(new,old)
        zn,zref,zlabels,zcommon,_,zt,zold_labels=align_reference(new[new.station=='zhenjiang'],z,('zhenjiang',))
        dates=np.intersect1d(common,zcommon)
        li=np.searchsorted(common,dates); zi=np.searchsorted(zcommon,dates)
        n,reference,labels,zref=n[:,li],reference[:,li],labels[li],zref[:,zi]
        if not np.array_equal(labels[...,1:2],zlabels[zi]): raise ValueError('specialist labels differ')
        full={s:ot for s in TARGETS}; intersection={s:dates for s in TARGETS}
        old_valid=ot[:,None]+np.arange(1,24)[None]*np.timedelta64(1,'h')
        common_valid=dates[:,None]+np.arange(1,24)[None]*np.timedelta64(1,'h')
        original_high={s:np.unique(old_valid[old_labels[...,j]>thresholds_cm[j]]) for j,s in enumerate(TARGETS)}
        common_high={s:np.unique(common_valid[labels[...,j]>thresholds_cm[j]]) for j,s in enumerate(TARGETS)}
        joint_retention=retention_admission(full,intersection,original_high,common_high)
        z_valid=zt[:,None]+np.arange(1,24)[None]*np.timedelta64(1,'h')
        zh=np.unique(z_valid[zold_labels[...,0]>thresholds_cm[1]])
        zhc=np.unique(common_valid[labels[...,1]>thresholds_cm[1]])
        zret={'calendar_retention':len(dates)/len(zt) if len(zt) else None,
              'high_water_retention':len(zhc)/len(zh) if len(zh) else None}
        admitted=joint_retention['accepted'] and all(v is not None and v>=.9 for v in zret.values())
        retention[year]={'joint':joint_retention,'specialist':zret,'admitted':admitted}
        constraints[year]={}; decisions[year]={}
        for days in (3,7,14):
            c=historical_constraints(n,reference,zref,labels,dates,thresholds_cm,
                policy['relative_mae_margin'],policy['miss_and_false_rate_margin'],days,
                protocol['statistics']['resamples'],protocol['statistics']['seed'])
            constraints[year][days]=c
            decisions[year][days]=(replacement_decision(c,policy_frozen=policy.get('status')=='frozen_approved')
                if admitted else '无法验收：历史日历或高水保留不足90%')
    return {'constraints':constraints,'retention':retention,'decisions':decisions,
            'overall_decision':sensitivity_decision(decisions),'scope':'retrospective training recipe, not a deployment checkpoint'}
