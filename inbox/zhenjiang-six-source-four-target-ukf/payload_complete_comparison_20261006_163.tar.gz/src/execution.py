"""Bind actual devices and move the complete state, batch and covariance together."""
from dataclasses import fields
import torch
from .contracts import ModelBatch, Whitening


def device_identity(device):
    requested = torch.device(device)
    if requested.type == 'cpu':
        return {'device': 'cpu', 'name': 'CPU', 'total_memory_bytes': None}
    if requested.type != 'cuda' or not torch.cuda.is_available():
        raise ValueError('requested execution device unavailable; no CPU fallback')
    index = torch.cuda.current_device() if requested.index is None else requested.index
    info = torch.cuda.get_device_properties(index)
    return {'device': 'cuda:' + str(index), 'name': info.name, 'total_memory_bytes': info.total_memory}


def bound_device(effective):
    declared = effective.get('device_identity')
    if not declared or not effective.get('device'):
        raise ValueError('explicit execution device and measured identity required')
    actual = device_identity(effective['device'])
    if actual != declared:
        raise ValueError('actual execution device differs from frozen identity')
    return torch.device(actual['device'])


def bind_authorized_device(effective, quote, authority):
    identity = effective.get('device_identity')
    if identity != quote.get('device_identity') or identity != authority.get('device_identity'):
        raise PermissionError('device differs from quote or explicit authority')
    return bound_device(effective)


def move_parts(parts, noise, whitening, device):
    for module in (parts.initializer, parts.encoder, parts.process, parts.readout):
        if module is not None:
            module.to(device)
    if noise is not None:
        for name in ('raw_q', 'raw_r', 'raw_p0'):
            value = getattr(noise, name)
            setattr(noise, name, torch.nn.Parameter(value.detach().to(device), requires_grad=value.requires_grad))
    if whitening is not None:
        whitening = Whitening(whitening.mean.to(device), whitening.scale.to(device))
    return whitening


def model_device(parts):
    devices = {p.device for module in (parts.initializer, parts.encoder, parts.process, parts.readout)
               if module is not None for p in module.parameters()}
    if len(devices) != 1:
        raise ValueError('model tensors do not share one execution device')
    return next(iter(devices))


def move_batch(batch, device):
    return ModelBatch(**{f.name: getattr(batch, f.name).to(device) for f in fields(batch)})


def device_batches(batches, device):
    for batch in batches:
        yield move_batch(batch, device)
