"""Train-hour statistics and exactly one explicit metre-to-model transform."""
import numpy as np
import torch
from .contracts import CHANNELS, TARGETS, TrainingStats, ModelBatch, verify_shapes

def fit_training_stats(unique_train_hours, years, manifest_sha256):
    times = np.asarray(unique_train_hours['times']).astype('datetime64[ns]')
    if len(np.unique(times))!=len(times) or np.isnat(times).any():
        raise ValueError('statistics require unique valid hours')
    actual = set((times.astype('datetime64[Y]').astype(int)+1970).tolist())
    if actual != set(years) or not actual.issubset(range(2017,2022)):
        raise ValueError('statistics years mismatch')
    h = np.column_stack([unique_train_hours[c] for c in CHANNELS]).astype(np.float64)
    targets = np.asarray(unique_train_hours.get('labels_m',h[:,:4]),dtype=np.float64)
    if h.shape != (len(times),7) or targets.shape != (len(times),4):
        raise ValueError('training statistics shape')
    def column_stats(a):
        valid_columns=[column[np.isfinite(column)] for column in a.T]
        if any(len(column)==0 for column in valid_columns):
            raise ValueError('no valid unique hours for a named channel')
        return (np.array([column.mean() for column in valid_columns]),
                np.array([column.std(ddof=0) for column in valid_columns]))
    tm,ts = column_stats(targets)
    hm,hs = column_stats(h)
    hm[:4],hs[:4] = tm,ts
    controls = np.column_stack((h[:,6],h[:,4],h[:,5]-h[:,6]))
    cm,cs=column_stats(controls)
    thresholds=np.array([np.quantile(column[np.isfinite(column)],.95,method='linear') for column in targets.T])
    return TrainingStats(hm,hs,cm,cs,tm,ts,thresholds,tuple(years),manifest_sha256)

def normalize_window(window,stats):
    verify_shapes(window)
    def convert(x):
        return torch.tensor(np.asarray(x)[None],dtype=torch.float32)
    return ModelBatch(convert((window.history_m-stats.history_mean)/stats.history_std),
                      convert((window.analysis_controls_m-stats.control_mean)/stats.control_std),
                      convert((window.forecast_controls_m-stats.control_mean)/stats.control_std),
                      convert((window.midpoint_controls_m-stats.control_mean)/stats.control_std),
                      torch.tensor(((window.targets_m-stats.target_mean)/stats.target_std)[None],dtype=torch.float64),
                      torch.tensor(window.targets_m[None],dtype=torch.float64),
                      torch.tensor((window.targets_m>stats.high_threshold_m)[None],dtype=torch.bool))

def denormalize_targets_cm(values,stats):
    mean = torch.tensor(stats.target_mean.copy(),dtype=values.dtype,device=values.device)
    std = torch.tensor(stats.target_std.copy(),dtype=values.dtype,device=values.device)
    return (values*std+mean)*100
