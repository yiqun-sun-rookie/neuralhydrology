"""Four registered diagnostics, using the same weights, controls and calendar."""
import torch
from .contracts import ModelParts
from .execution import move_parts
from .state_estimators import initialize_state
from .models import rollout
from .training import foundation_predictions
from .differentiable_filter import make_noise,filter_analysis
from .scheduler import digest_json

FOUNDATION_DIAGNOSTICS=('foundation_endpoint','midpoint_no_target_observations','initial_noise_filter')
TRAINED_FILTER_DIAGNOSTIC='trained_filter_no_observations'


def foundation_diagnostic(parts,whitening,batch,kind,ledger=None):
    if kind=='foundation_endpoint':
        return foundation_predictions(parts,batch)[1]
    initial=initialize_state(parts,batch.history[:,:24])
    if kind=='midpoint_no_target_observations':
        state=initial
        for control in batch.analysis_controls.unbind(1):
            state=parts.process(state,control)
    elif kind=='initial_noise_filter':
        if whitening is None:
            raise ValueError('sealed foundation whitening required for initial noise diagnostic')
        fixed=ModelParts(parts.initializer,None,parts.process,parts.readout,parts.state_dim)
        noise=make_noise(parts.state_dim)
        whitening=move_parts(fixed,noise,whitening,batch.history.device)
        state,_=filter_analysis(fixed,noise,whitening,initial,batch,True,ledger)
    else:
        raise ValueError('unregistered foundation diagnostic')
    return rollout(parts.process,parts.readout,state,batch.forecast_controls)


def diagnostic_collection(index,protocol):
    """Logical identities required even when prediction computation is shared by aliases."""
    records=[]
    for item in index['models']:
        run=item['run']
        kinds=(FOUNDATION_DIAGNOSTICS if run['method']=='foundation' else
               (TRAINED_FILTER_DIAGNOSTIC,) if run['method'].startswith('filter') else ())
        for kind in kinds:
            parent=item if run['method']=='foundation' else next(x for x in index['models']
                if x['run']['exp_id']==item['config']['effective_config']['parent_run_id'])
            records.append({'run_id':run['exp_id'],'case':run['case'],'seed':run['seed'],'kind':kind,
                'source_checkpoint_sha256':item['checkpoint']['sha256'],
                'foundation_checkpoint_sha256':parent['checkpoint']['sha256'],
                'whitening_sha256':digest_json(parent['whitening']),
                'station_order':protocol['data']['targets'],
                'initial_noise_settings':{k:protocol['filter'][k] for k in
                    ('process_variance','observation_variance','initial_variance','variance_floor')}
                    if kind=='initial_noise_filter' else None,
                'noise':'prescribed_initial_variances' if kind=='initial_noise_filter' else
                        'trained_noise_no_observation_update' if kind==TRAINED_FILTER_DIAGNOSTIC else 'none',
                'control_contract':'registered_analysis_controls_and_issue_time_hold',
                'calendar':'same_input_defined_calendar_as_main_predictions'})
    if len(records)!=140:
        raise ValueError('all 60 foundation and 80 trained-filter logical diagnostics required per year')
    return records
