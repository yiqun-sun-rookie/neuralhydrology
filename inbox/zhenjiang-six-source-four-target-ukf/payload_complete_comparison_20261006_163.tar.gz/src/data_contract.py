"""Reject files before opening them; construct metre inputs without future gauges.

Manifest entries pin path, years, role and SHA256. Only separately admitted
year files can be read. See scripts/admit_data.py --help for manifest checking.
"""
from pathlib import Path
import hashlib
import io
import numpy as np
from .contracts import PhysicalWindow, verify_shapes

PHASE_YEARS = {'tuning_train':(2017,2018,2019,2020), 'tuning_select':(2021,),
               'final_train':(2017,2018,2019,2020,2021), 'final_select':(2022,),
               'evaluation_2023':(2023,), 'evaluation_2024':(2024,)}

def _under(path, roots):
    return any(path == root or root in path.parents for root in roots)

def allowed_path(path: Path, manifest: dict, phase: str) -> Path:
    if phase not in PHASE_YEARS or manifest.get('status') != 'admitted':
        raise PermissionError('phase or data admission missing')
    if phase.startswith('evaluation') and not manifest.get('evaluation_year_reads',False):
        raise PermissionError('evaluation-year read not authorized')
    path = Path(path)
    if not path.is_absolute() or '..' in path.parts:
        raise PermissionError('absolute, non-traversing path required')
    lexical = path.absolute()
    roots = [Path(r).absolute() for r in manifest.get('approved_roots',[])]
    blocked = [Path(r).absolute() for r in manifest.get('forbidden_roots',[])]
    if not roots or not _under(lexical,roots) or _under(lexical,blocked):
        raise PermissionError('lexical path outside approved roots')
    entries = [x for x in manifest.get('files',[]) if Path(x['path']).absolute() == lexical]
    if len(entries) != 1:
        raise PermissionError('file not uniquely registered')
    e = entries[0]
    if not e.get('years') or not set(e['years']).issubset(PHASE_YEARS[phase]) or phase not in e.get('phases',[]):
        raise PermissionError('mixed or forbidden years; isolate before admission')
    if e.get('role') not in {'realtime_inputs','qc_labels','astronomical_tide','historical_predictions'}:
        raise PermissionError('unregistered file role')
    resolved = lexical.resolve(strict=True)
    if not _under(resolved,[r.resolve(strict=True) for r in roots]) or _under(resolved,[r.resolve() for r in blocked]):
        raise PermissionError('resolved path escapes admission')
    if e.get('sha256') != hashlib.sha256(resolved.read_bytes()).hexdigest():
        raise ValueError('admitted file bytes changed')
    return resolved

def read_admitted_npz(path, manifest, phase, role):
    p = allowed_path(Path(path),manifest,phase)
    entry = next(x for x in manifest['files'] if Path(x['path']).absolute() == Path(path).absolute())
    if entry['role'] != role:
        raise PermissionError('input and label roles cannot be interchanged')
    raw = p.read_bytes()
    if hashlib.sha256(raw).hexdigest() != entry['sha256']:
        raise ValueError('file changed between admission and reading')
    with np.load(io.BytesIO(raw),allow_pickle=False) as f:
        result = {k: f[k] for k in f.files}
    times = result.get('times')
    if times is None or np.isnat(times.astype('datetime64[ns]')).any():
        raise ValueError('authenticated timestamps required')
    years = times.astype('datetime64[Y]').astype(int)+1970
    if not set(years.tolist()).issubset(entry['years']):
        raise ValueError('actual timestamps violate admitted years')
    return result

def future_controls(last_datong_m, last_residual_m, tide_m):
    tide = np.asarray(tide_m,dtype=np.float64)
    if tide.ndim != 1 or not np.isfinite(tide).all():
        raise ValueError('invalid forecast tide')
    return np.column_stack((tide,np.full(len(tide),last_datong_m),np.full(len(tide),last_residual_m)))

def build_physical_window(history_m, history_times, future_tide_m, targets_m):
    h = np.asarray(history_m,dtype=np.float64)
    times = np.asarray(history_times).astype('datetime64[ns]')
    tide = np.asarray(future_tide_m,dtype=np.float64)
    if h.shape != (48,7) or times.shape != (48,) or tide.shape != (47,):
        raise ValueError('history/timestamp/tide shape')
    if np.isnat(times).any() or not np.all(np.diff(times)==np.timedelta64(1,'h')):
        raise ValueError('missing or duplicate hour')
    if not np.all(times == times.astype('datetime64[h]').astype('datetime64[ns]')):
        raise ValueError('timestamps are not whole hours')
    if not np.array_equal(tide[:24],h[24:,6]):
        raise ValueError('overlapping astronomical tide differs')
    residual = h[:,5]-h[:,6]
    analysis = np.column_stack((h[24:,6],h[23:47,4],residual[23:47]))
    w = PhysicalWindow(times[-1],h,analysis,
                       future_controls(h[-1,4],residual[-1],tide[24:]),
                       future_controls(h[23,4],residual[23],tide),
                       np.asarray(targets_m,dtype=np.float64))
    verify_shapes(w)
    return w

def build_calendar(times, history_m, labels_m, tide_m):
    """Return common eligible issue indices and exclusions, never model failures."""
    times = np.asarray(times).astype('datetime64[ns]')
    if len(np.unique(times)) != len(times) or np.any(np.diff(times)<=np.timedelta64(0,'h')):
        raise ValueError('duplicate or unordered timestamps')
    if history_m.shape != (len(times),7) or labels_m.shape != (len(times),4) or tide_m.shape != (len(times),):
        raise ValueError('calendar data shapes')
    eligible, excluded = [], []
    for i in range(len(times)):
        reason = None
        if i<47 or i+23>=len(times):
            reason='incomplete_window'
        elif not np.all(np.diff(times[i-47:i+24])==np.timedelta64(1,'h')):
            reason='missing_hour'
        elif len(set(times[i-47:i+24].astype('datetime64[Y]'))) != 1:
            reason='cross_year'
        elif not (np.isfinite(history_m[i-47:i+1]).all() and np.isfinite(labels_m[i-23:i+24]).all() and np.isfinite(tide_m[i-23:i+24]).all()):
            reason='missing_input_or_label'
        if reason:
            excluded.append({'issue_time':str(times[i]),'reason':reason})
        else:
            eligible.append(i)
    return np.array(eligible,dtype=int),excluded
