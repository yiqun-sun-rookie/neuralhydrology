"""Bind selection, evaluation sources, margins and distinct calendar identities."""
import math
import numpy as np
from .contracts import GroupSeal
from .scheduler import digest_json,code_identity,verify_parent_binding,seal_group

CALENDAR_RULES = {
    'algorithm': 'build_calendar_v1', 'history_hours': 48, 'future_hours': 23, 'same_year_hours': 71,
    'eligible': 'continuous_whole_hours_complete_history_qc_labels_and_tide',
    'exclusions': ['incomplete_window','missing_hour','cross_year','missing_input_or_label'],
    'model_failure_exclusion': False,
}


def manifest_identity(manifest):
    # Authorization can be granted after model sealing without changing the source identity.
    return digest_json({k:v for k,v in manifest.items() if k!='evaluation_year_reads'})


def require_digest(value,label):
    if not isinstance(value,str) or len(value)!=64 or any(c not in '0123456789abcdef' for c in value):
        raise ValueError('valid content digest required: '+label)


def validate_policy(policy):
    if policy.get('status')!='frozen_approved':
        raise ValueError('replacement margins not explicitly frozen')
    for name in ('relative_mae_margin','miss_and_false_rate_margin'):
        value=policy.get(name)
        if not isinstance(value,(int,float)) or not math.isfinite(value) or value<0:
            raise ValueError('invalid frozen margin: '+name)
    if policy['miss_and_false_rate_margin']>1:
        raise ValueError('rate margin must be a fraction between zero and one')


def validate_calendar_contract(contract):
    if contract.get('status')!='frozen' or contract.get('rules')!=CALENDAR_RULES:
        raise ValueError('the complete input-defined calendar rules must be frozen')
    require_digest(contract.get('selection_2022_sha256'),'2022 selection calendar')
    historic=contract.get('historical_calendars',{})
    if set(historic)!={'2023','2024'}:
        raise ValueError('both historical reference calendars required')
    for year in ('2023','2024'):
        if set(historic[year])!={'joint','specialist'}:
            raise ValueError('both historical reference calendar identities required')
        for role,value in historic[year].items():
            require_digest(value,year+'/'+role)
    years=contract.get('evaluation',{})
    if set(years)!={'2023','2024'}:
        raise ValueError('both evaluation calendar commitments required')
    for record in years.values():
        if record.get('mode') not in ('generate_after_model_seal','precommitted'):
            raise ValueError('unknown evaluation calendar commitment')
        if record['mode']=='precommitted':
            require_digest(record.get('sha256'),'precommitted evaluation calendar')


def validate_reference_calendars(references,contract):
    if references.get('status')!='admitted' or set(references.get('years',{}))!={'2023','2024'}:
        raise ValueError('complete admitted historical reference collection required')
    for year in ('2023','2024'):
        for role in ('joint','specialist'):
            item=references['years'][year][role]
            if item.get('calendar_sha256')!=contract['historical_calendars'][year][role]:
                raise ValueError('historical calendar differs from pre-evaluation commitment')


def validate_model_collection(index,protocol,outcomes=None):
    if index.get('code_hash')!=code_identity():
        raise ValueError('implementation changed after model collection freezing')
    models=index.get('models',[])
    identities=[(m['run']['type'],m['run']['case'],m['run']['method'],m['run']['seed']) for m in models]
    cases=[c['family']+'__'+c['capacity'] for c in protocol['cases']]
    required={(track,case,method,seed) for track in ('primary','controlled') for case in cases
              for method in protocol['method_order'] for seed in protocol['seeds']}
    required|={('final_foundation',case,'foundation',seed) for case in cases for seed in protocol['seeds']}
    if set(identities)!=required or len(identities)!=180:
        raise ValueError('all 160 final branches and 20 final foundations required before evaluation reads')
    items={m['run']['exp_id']:m for m in models}
    if len(items)!=len(models):
        raise ValueError('duplicate frozen run identity')
    seals={k:GroupSeal(**v) for k,v in index.get('foundation_seals',{}).items()}
    stats_hash=digest_json(index['training_stats'])
    for item in models:
        run=item['run']; effective=item['config']['effective_config']
        if any(effective.get(k)!=run[k] for k in ('case','method','seed')):
            raise ValueError('frozen model config identity differs from registration')
        if effective.get('normalization_hash')!=stats_hash or effective.get('code_hash')!=index['code_hash']:
            raise ValueError('frozen model statistics or implementation differ')
        require_digest(item['checkpoint'].get('sha256'),'frozen checkpoint')
        if outcomes is not None:
            outcome=outcomes[run['exp_id']]
            if outcome['checkpoint_sha256']!=item['checkpoint']['sha256']:
                raise ValueError('checkpoint differs from completed logical outcome')
        if run['method']=='foundation':
            gate=run['case']+'__final_foundation_group__seal'
            seal=seals.get(gate)
            expected={m['run']['exp_id'] for m in models if m['run']['method']=='foundation' and m['run']['case']==run['case']}
            if (seal is None or set(seal.member_ids)!=expected or seal.status!='sealed_success'
                or not seal.budget_final or seal.group_id!=gate):
                raise ValueError('final foundation group seal missing')
            checked=seal_group(gate,seal.member_evidence,seal.epochs,expected_members=seal.member_ids)
            if checked.evidence_sha256!=seal.evidence_sha256 or checked.checkpoint_hashes!=seal.checkpoint_hashes:
                raise ValueError('final foundation evidence changed')
            row=seal.member_evidence[run['exp_id']]
            if (row['checkpoint_sha256']!=item['checkpoint']['sha256']
                or digest_json(item['whitening'])!=row['whitening_hash']):
                raise ValueError('diagnostic foundation or whitening is not sealed')
        else:
            verify_parent_binding(run,effective,seals)
            parent=items.get(effective['parent_run_id'])
            if parent is None or parent['checkpoint']['sha256']!=effective['parent_hash']:
                raise ValueError('diagnostic parent missing from frozen model collection')
        if item.get('alias_of'):
            source=items.get(item['alias_of'])
            if (source is None or source.get('alias_of') or source['checkpoint']!=item['checkpoint']
                or source['config']['effective_config']!=effective):
                raise ValueError('alias differs from complete effective configuration')
    return items


def selection_bindings(index,manifest,references,policy,calendar_contract):
    validate_policy(policy)
    validate_calendar_contract(calendar_contract)
    validate_reference_calendars(references,calendar_contract)
    if manifest.get('status')!='admitted':
        raise ValueError('evaluation source identity must be admitted, no values need be read here')
    return {'models_sha256':digest_json(index),'evaluation_manifest_sha256':manifest_identity(manifest),
            'references_sha256':digest_json(references),'margin_policy_sha256':digest_json(policy),
            'calendar_contract_sha256':digest_json(calendar_contract)}


def verify_evaluation_bindings(selection,index,manifest,references,policy,calendar_contract,protocol):
    unsigned={k:v for k,v in selection.items() if k!='selection_sha256'}
    if selection.get('status')!='sealed_success' or digest_json(unsigned)!=selection.get('selection_sha256'):
        raise ValueError('selection seal altered or incomplete')
    actual=selection_bindings(index,manifest,references,policy,calendar_contract)
    if actual!=selection.get('bindings'):
        raise ValueError('models, margins, evaluation sources, references or calendar contract changed after sealing')
    validate_model_collection(index,protocol,selection['evidence']['logical_run_results'])


def calendar_snapshot(stage,phase):
    times=stage['times'].astype('datetime64[ns]')
    eligible=times[stage['eligible']]
    if not len(eligible):
        raise ValueError('no complete input-defined evaluation windows')
    return {'phase':phase,'source_hours':len(times),'eligible_windows':len(eligible),
            'all_hours_sha256':digest_json(times.astype(str).tolist()),
            'issue_hours_sha256':digest_json(eligible.astype(str).tolist()),
            'exclusions_sha256':digest_json(stage['excluded'])}


def historical_calendar_identity(frame,role,year):
    """Reconstruct the reference calendar from its complete, admitted prediction grid."""
    from .contracts import TARGETS
    from .evaluation import rows_from_frame
    from .scoring import prediction_cube
    stations=TARGETS if role=='joint' else ('zhenjiang',) if role=='specialist' else None
    if stations is None: raise ValueError('unknown historical reference role')
    _,_,times,seeds=prediction_cube(rows_from_frame(frame),stations)
    if not np.all(times.astype('datetime64[Y]').astype(int)+1970==year) or list(seeds)!=[17,29,43]:
        raise ValueError('historical reference year or complete three-seed grid differs')
    return digest_json({'role':role,'year':year,'station_order':list(stations),'lead_hours':list(range(1,24)),
                        'seeds':seeds.tolist(),'issue_times':times.astype('datetime64[ns]').astype(str).tolist()})


def lock_evaluation_calendars(selection,manifest,contract,stages,previous=None):
    validate_calendar_contract(contract)
    if digest_json(contract)!=selection['bindings']['calendar_contract_sha256']:
        raise ValueError('calendar contract changed after model selection sealing')
    if manifest_identity(manifest)!=selection['bindings']['evaluation_manifest_sha256']:
        raise ValueError('evaluation sources changed before calendar generation')
    calendars={str(year):calendar_snapshot(stages[year],'evaluation_'+str(year)) for year in (2024,2023)}
    for year,snapshot in calendars.items():
        commitment=contract['evaluation'][year]
        if commitment['mode']=='precommitted' and digest_json(snapshot)!=commitment['sha256']:
            raise ValueError('actual evaluation calendar differs from precommitted calendar')
    unsigned={'status':'sealed_data_calendar','selection_sha256':selection['selection_sha256'],
              'source_manifest_sha256':manifest_identity(manifest),'contract_sha256':digest_json(contract),'years':calendars}
    record={**unsigned,'calendar_lock_sha256':digest_json(unsigned)}
    if previous is not None and record!=previous:
        raise ValueError('evaluation calendar changed after first input-defined lock')
    return record
