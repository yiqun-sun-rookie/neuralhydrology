"""Independent physical scoring, shared calendar blocks and explicit decisions.

No forecasting model is imported. Prediction files are evidence, not inputs to
training. Undefined denominators and incomplete grids are never filled with 0.
"""
import hashlib
from pathlib import Path
import numpy as np
from .contracts import TARGETS

CORRECTED_QUANTILES=(.000390625,.999609375)

def prediction_cube(rows,station_order=TARGETS):
    arrays=[np.asarray(getattr(rows,k)) for k in rows.__dataclass_fields__]
    if len({len(a) for a in arrays})!=1 or not len(arrays[0]):
        raise ValueError('empty or mismatched prediction table')
    times=np.unique(np.asarray(rows.issue_time).astype('datetime64[ns]'))
    seeds=np.unique(rows.seed)
    if not np.isfinite(rows.prediction_cm).all() or not np.isfinite(rows.observation_cm).all():
        raise ValueError('numerical failures remain failures; cannot remove rows')
    if set(rows.station)!=set(station_order) or set(rows.lead)!=set(range(1,24)):
        raise ValueError('all registered stations and 23 leads required')
    cube=np.full((len(seeds),len(times),23,len(station_order)),np.nan)
    labels=np.full_like(cube,np.nan)
    seed_idx={v:i for i,v in enumerate(seeds)}; time_idx={v:i for i,v in enumerate(times)}
    station_idx={v:i for i,v in enumerate(station_order)}
    for time,lead,station,seed,pred,obs in zip(*arrays):
        slot=(seed_idx[seed],time_idx[np.datetime64(time,'ns')],int(lead)-1,station_idx[station])
        if np.isfinite(cube[slot]): raise ValueError('duplicate prediction row')
        cube[slot]=pred; labels[slot]=obs
    if not np.isfinite(cube).all(): raise ValueError('missing station, lead, seed or issue hour')
    if not np.array_equal(labels,np.broadcast_to(labels[:1],labels.shape)):
        raise ValueError('different labels across seeds')
    valid_times=(times[:,None]+np.arange(1,24)[None]*np.timedelta64(1,'h')).ravel()
    order=np.argsort(valid_times)
    repeated=np.diff(valid_times[order])==np.timedelta64(0,'h')
    for j in range(len(station_order)):
        values=labels[0,...,j].ravel()[order]
        if np.any(np.diff(values)[repeated]!=0):
            raise ValueError('same target hour has contradictory observations')
    return cube,labels[0],times,seeds

def _average(x,mask=None):
    if mask is None: return float(np.mean(x))
    return float(x[mask].mean()) if mask.any() else None

def metric_components(prediction,observations,thresholds,station_order=TARGETS):
    e=np.abs(prediction-observations[None]); high=observations>thresholds
    out={}; overall=[]; high_values=[]
    for j,station in enumerate(station_order):
        values=e[...,j]
        out[station+'_overall_mae']=float(values.mean())
        out[station+'_high_mae']=_average(values,np.broadcast_to(high[...,j],values.shape))
        out[station+'_long_lead_mae']=float(values[:,:,11:].mean())
        hm=np.broadcast_to(high[...,j],values.shape)
        predicted_high=prediction[...,j]>thresholds[j]
        out[station+'_miss_rate']=_average((~predicted_high).astype(float),hm)
        out[station+'_false_rate']=_average(predicted_high.astype(float),~hm)
        overall.append(out[station+'_overall_mae']); high_values.append(out[station+'_high_mae'])
    out['overall_mae']=float(np.mean(overall))
    out['high_mae']=None if any(v is None for v in high_values) else float(np.mean(high_values))
    return out

def score_rows(rows,thresholds_cm,station_order=TARGETS):
    prediction,observations,times,seeds=prediction_cube(rows,station_order)
    thresholds=np.asarray(thresholds_cm,dtype=float)
    if thresholds.shape!=(len(station_order),) or not np.isfinite(thresholds).all():
        raise ValueError('training-derived named thresholds required')
    components=metric_components(prediction,observations,thresholds,station_order)
    error=prediction-observations[None]
    high=observations>thresholds
    nse={}
    for j,station in enumerate(station_order):
        denominator=((observations[...,j]-observations[...,j].mean())**2).sum()
        nse[station]=None if denominator==0 else [float(1-(error[s,...,j]**2).sum()/denominator) for s in range(len(seeds))]
    coverage={}
    for j,station in enumerate(station_order):
        valid_times=times[:,None]+np.arange(1,24)[None]*np.timedelta64(1,'h')
        coverage[station]={'issue_hours':len(times),'forecast_cells':int(high[...,j].size),
                           'high_cells':int(high[...,j].sum()),
                           'unique_high_valid_hours':len(np.unique(valid_times[high[...,j]]))}
    return {'components':components,'overall_mae_cm':components['overall_mae'],
            'seed_mae_cm':{str(seed):float(np.abs(error[i]).mean()) for i,seed in enumerate(seeds)},
            'lead_mae_cm':np.abs(error).mean(axis=(0,1,3)).tolist(),
            'bias_cm':float(error.mean()),'nash_efficiency_by_seed':nse,'coverage':coverage,
            'issue_hours':len(times),'seeds':seeds.tolist(),'lead_hours':list(range(1,24))}

def calendar_blocks(issue_dates,block_days):
    dates=np.asarray(issue_dates).astype('datetime64[D]')
    if dates.ndim!=1 or not len(dates) or np.isnat(dates).any() or block_days not in (3,7,14):
        raise ValueError('invalid calendar block contract')
    years=dates.astype('datetime64[Y]')
    if len(np.unique(years))!=1: raise ValueError('resample one year at a time')
    start=years[0].astype('datetime64[D]')
    end=(years[0]+np.timedelta64(1,'Y')).astype('datetime64[D]')
    n=(int((end-start)/np.timedelta64(1,'D'))+block_days-1)//block_days
    membership=((dates-start).astype(int)//block_days)
    return [np.flatnonzero(membership==i) for i in range(n)]

def sampling_plan(issue_dates,n_left,n_right,paired_seeds,block_days,repetitions,random_seed):
    if paired_seeds and n_left!=n_right: raise ValueError('paired seeds require equal sets')
    if repetitions<1 or min(n_left,n_right)<1: raise ValueError('invalid resampling size')
    blocks=calendar_blocks(issue_dates,block_days)
    time_rng=np.random.default_rng(random_seed)
    seed_rng=np.random.default_rng(random_seed+100000)
    time_counts=np.zeros((repetitions,len(blocks)),dtype=np.int32)
    left=np.empty((repetitions,n_left),dtype=int); right=np.empty((repetitions,n_right),dtype=int)
    for k in range(repetitions):
        selected=time_rng.integers(len(blocks),size=len(blocks))
        time_counts[k]=np.bincount(selected,minlength=len(blocks))
        left[k]=seed_rng.integers(n_left,size=n_left)
        right[k]=left[k] if paired_seeds else seed_rng.integers(n_right,size=n_right)
    h=hashlib.sha256(time_counts.tobytes()).hexdigest()
    return blocks,time_counts,left,right,h

def _resampled_cell_means(values,blocks,time_counts,seed_draws):
    # Summation before division preserves the short final block and empty blocks.
    sums=np.stack([values[:,idx].sum(axis=1) for idx in blocks],axis=1)
    counts=np.array([len(idx) for idx in blocks])
    sample_sizes=time_counts@counts
    result=np.empty((len(time_counts),*values.shape[2:]))
    for k,(mult,seeds) in enumerate(zip(time_counts,seed_draws)):
        if sample_sizes[k]==0: result[k]=np.nan
        else: result[k]=np.tensordot(sums[seeds].mean(0),mult,axes=(0,0))/sample_sizes[k]
    return result

def paired_resamples(errors_left,errors_right,issue_dates,paired_seeds,block_days,repetitions,random_seed):
    a,b=np.asarray(errors_left),np.asarray(errors_right)
    if a.ndim!=4 or b.ndim!=4 or a.shape[1:]!=b.shape[1:] or a.shape[1]!=len(issue_dates):
        raise ValueError('expected seed x issue x lead x station matched tensors')
    if not np.isfinite(a).all() or not np.isfinite(b).all(): raise ValueError('incomplete shared calendar')
    blocks,mult,ls,rs,h=sampling_plan(issue_dates,len(a),len(b),paired_seeds,block_days,repetitions,random_seed)
    left=_resampled_cell_means(a,blocks,mult,ls).mean((1,2))
    right=_resampled_cell_means(b,blocks,mult,rs).mean((1,2))
    with np.errstate(divide='ignore',invalid='ignore'):
        relative=(left-right)/left
    estimable=bool(np.isfinite(relative).all())
    return {'left_mean_samples':left,'right_mean_samples':right,'relative_improvement_samples':relative,
            'corrected_interval':np.quantile(relative,CORRECTED_QUANTILES).tolist() if estimable else None,
            'ordinary_interval':np.quantile(relative,[.025,.975]).tolist() if estimable else None,
            'time_sampling_sha256':h,'left_seed_draws':ls,'right_seed_draws':rs,'estimable':estimable,
            'point_relative_improvement':float((a.mean()-b.mean())/a.mean()) if a.mean()!=0 else None}

def scientific_decision(result):
    if not result['estimable']: return '无法确定'
    low,high=result['corrected_interval']; point=result['point_relative_improvement']
    if point>=.05 and low>0: return '支持明确改善'
    if low>=-.05 and high<=.05: return '支持在5%范围内等效'
    return '不满足明确改善或等效标准'

def _primitive_blocks(prediction,observations,thresholds,blocks):
    error=np.abs(prediction-observations[None]); high=observations>thresholds
    numerators=[]; denominators=[]
    for j in range(prediction.shape[-1]):
        e=error[...,j]; hm=high[...,j]
        ph=prediction[...,j]>thresholds[j]
        for value,mask in ((e,np.ones_like(hm,dtype=bool)),(e,hm),
                           (e[:,:,11:],np.ones_like(hm[:,11:],dtype=bool)),
                           ((~ph).astype(float),hm),(ph.astype(float),~hm)):
            sums=np.stack([(value[:,idx]*mask[idx][None]).sum((1,2)) for idx in blocks],axis=1)
            counts=np.array([mask[idx].sum() for idx in blocks])
            numerators.append(sums); denominators.append(counts)
    return np.stack(numerators,axis=-1),np.stack(denominators,axis=-1)

def _primitive_resamples(primitives,mult,seed_draws):
    sums,counts=primitives; result=[]
    for weights,seeds in zip(mult,seed_draws):
        numerator=np.tensordot(sums[seeds],weights,axes=(1,0))
        denominator=weights@counts
        with np.errstate(divide='ignore',invalid='ignore'):
            result.append((numerator/denominator).mean(0))
    return np.asarray(result)

def historical_constraints(new_prediction,joint_reference,specialist_reference,observations,issue_dates,
                           thresholds_cm,relative_margin,rate_margin,block_days=7,repetitions=50000,random_seed=20261005):
    if new_prediction.shape[1:]!=joint_reference.shape[1:] or observations.shape!=new_prediction.shape[1:]:
        raise ValueError('historical alignment mismatch')
    if new_prediction.shape[2:]!=(23,4) or specialist_reference.shape[1:]!=(*new_prediction.shape[1:3],1):
        raise ValueError('four-station and specialist contracts cannot be mixed')
    if not all(np.isfinite(x).all() for x in (new_prediction,joint_reference,specialist_reference,observations)):
        raise ValueError('incomplete historical predictions')
    blocks,mult,ns,os,h=sampling_plan(issue_dates,len(new_prediction),len(joint_reference),False,block_days,repetitions,random_seed)
    # A separate seed draw for the specialist; reuse exactly the time counts.
    rng=np.random.default_rng(random_seed+1)
    zs=rng.integers(len(specialist_reference),size=(repetitions,len(specialist_reference)))
    new_pr=_primitive_blocks(new_prediction,observations,thresholds_cm,blocks)
    old_pr=_primitive_blocks(joint_reference,observations,thresholds_cm,blocks)
    z_pr=_primitive_blocks(specialist_reference,observations[...,1:2],np.asarray(thresholds_cm)[1:2],blocks)
    new=_primitive_resamples(new_pr,mult,ns); old=_primitive_resamples(old_pr,mult,os); z=_primitive_resamples(z_pr,mult,zs)
    def point(pr):
        num,den=pr
        with np.errstate(divide='ignore',invalid='ignore'): return (num.sum(1)/den.sum(0)).mean(0)
    npnt,opnt,zpnt=point(new_pr),point(old_pr),point(z_pr)
    constraints=[]
    def add(name,lv,rv,lp,rp,is_rate):
        with np.errstate(divide='ignore',invalid='ignore'):
            values=lv-rv if is_rate else lv/rv-1
            point_value=float(lp-rp if is_rate else lp/rp-1)
        estimable=bool(np.isfinite(values).all() and np.isfinite(point_value))
        constraints.append({'name':name,'point':point_value if np.isfinite(point_value) else None,
            'upper':float(np.quantile(values,.95)) if estimable else None,
            'margin':rate_margin if is_rate else relative_margin,'estimable':estimable,
            'block_days':block_days,'time_sampling_sha256':h})
    add('joint_overall_mae',new[:,::5].mean(1),old[:,::5].mean(1),npnt[::5].mean(),opnt[::5].mean(),False)
    add('joint_high_mae',new[:,1::5].mean(1),old[:,1::5].mean(1),npnt[1::5].mean(),opnt[1::5].mean(),False)
    for j,station in enumerate(TARGETS):
        for i,metric in enumerate(('overall_mae','high_mae','long_lead_mae','miss_rate','false_rate')):
            k=j*5+i
            add('joint_'+station+'_'+metric,new[:,k],old[:,k],npnt[k],opnt[k],i>=3)
    for i,metric in enumerate(('overall_mae','high_mae','long_lead_mae','miss_rate','false_rate')):
        add('specialist_zhenjiang_'+metric,new[:,5+i],z[:,i],npnt[5+i],zpnt[i],i>=3)
    return constraints

def replacement_decision(constraints,required_count=27,policy_frozen=False):
    if not policy_frozen: return '无法验收：容限尚未冻结'
    if len(constraints)!=required_count or len({c.get('name') for c in constraints})!=required_count:
        return '无法验收：约束不完整或重复'
    for c in constraints:
        if not c.get('estimable') or any(c.get(k) is None or not np.isfinite(c[k]) for k in ('point','upper','margin')):
            return '无法验收：存在未定义约束'
        if c['upper']>c['margin']: return '不通过：保留现有模型'
    return '通过：已暴露年份的回顾训练方案非劣证据'

def sensitivity_decision(decisions_by_year_and_block):
    if set(decisions_by_year_and_block)!={2023,2024} or any(set(v)!={3,7,14} for v in decisions_by_year_and_block.values()):
        return '无法验收：年份或块长不完整'
    if any(len(set(v.values()))>1 for v in decisions_by_year_and_block.values()):
        return '对时间相关假设敏感：不建议替换'
    if all(all(s.startswith('通过') for s in v.values()) for v in decisions_by_year_and_block.values()):
        return '通过回顾验收；部署与新年份验证仍需另行验收'
    return '不通过或无法验收：保留现有模型'

def retention_admission(original_calendar,intersection_calendar,original_high_hours,intersection_high_hours):
    values={}
    for station in TARGETS:
        full=set(original_calendar[station]); part=set(intersection_calendar[station])
        high=set(original_high_hours[station]); high_part=set(intersection_high_hours[station])
        if not part.issubset(full) or not high_part.issubset(high): raise ValueError('intersection is not a subset')
        values[station]={'calendar_retention':len(part)/len(full) if full else None,
                         'high_water_retention':len(high_part)/len(high) if high else None}
    accepted=all(v is not None and v>=.9 for d in values.values() for v in d.values())
    return {'accepted':accepted,'retention':values,'scope':'common-calendar retrospective only' if not accepted else 'historical performance admission'}

def choose_candidate(validation_rows,protocol):
    expected={(c['family']+'__'+c['capacity'],m,s) for c in protocol['cases'] for m in protocol['method_order'] for s in protocol['seeds']}
    keys=[(r['case'],r['method'],r['seed']) for r in validation_rows]
    if set(keys)!=expected or len(keys)!=len(expected): raise ValueError('all 16 primary cells and five seeds required')
    if any(r.get('track')!='primary' or r.get('year')!=2022 or not np.isfinite(r['mae_cm']) for r in validation_rows):
        raise ValueError('candidate selection requires only 2022 primary validation')
    candidates=[]
    for case_idx,c in enumerate(protocol['cases']):
        case=c['family']+'__'+c['capacity']
        for method_idx,method in enumerate(protocol['method_order']):
            subset=[r for r in validation_rows if r['case']==case and r['method']==method]
            sizes={r['future_parameters'] for r in subset}
            if len(sizes)!=1: raise ValueError('parameter count changed across seeds')
            candidates.append({'case':case,'method':method,'mae_cm':float(np.mean([r['mae_cm'] for r in subset])),
                               'future_parameters':sizes.pop(),'case_order':case_idx,'method_order':method_idx})
    return min(candidates,key=lambda c:(c['mae_cm'],c['future_parameters'],c['case_order'],c['method_order']))

def write_prediction_manifest(prediction_paths,frozen_selection):
    if frozen_selection.get('status')!='sealed_success' or not frozen_selection.get('selection_sha256'):
        raise PermissionError('selection must be sealed before prediction reads')
    return {'selection_sha256':frozen_selection['selection_sha256'],'files':[
        {'path':str(Path(p).resolve()),'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in prediction_paths]}

def event_diagnostics(valid_times,observations_cm,threshold_cm,issue_times,prediction_cm):
    times=np.asarray(valid_times).astype('datetime64[h]'); obs=np.asarray(observations_cm)
    if times.ndim!=1 or obs.shape!=times.shape or len(times)<1 or np.any(np.diff(times)!=np.timedelta64(1,'h')):
        raise ValueError('complete hourly event label calendar required')
    high=np.flatnonzero(obs>threshold_cm); groups=[]
    for i in high:
        if not groups or i-groups[-1][-1]>24: groups.append([int(i)])
        else: groups[-1].append(int(i))
    bounds=[[max(0,g[0]-24),min(len(times)-1,g[-1]+24)] for g in groups]
    for i in range(len(bounds)-1):
        if bounds[i][1]>=bounds[i+1][0]:
            midpoint=(groups[i][-1]+groups[i+1][0])//2
            bounds[i][1]=midpoint; bounds[i+1][0]=midpoint+1
    events=[]
    for g,(lo,hi) in zip(groups,bounds):
        peak=g[int(np.argmax(obs[g]))]
        complete=(g[0]>=24 and g[-1]+24<len(times) and np.isfinite(obs[lo:hi+1]).all())
        windows=[]
        for issue,pred in zip(issue_times,prediction_cm):
            lead_times=np.datetime64(issue,'h')+np.arange(1,24)*np.timedelta64(1,'h')
            hits=np.flatnonzero(lead_times==times[peak])
            if not len(hits) or not 3<=hits[0]<=19 or not np.isfinite(pred).all(): continue
            if peak<3 or peak+3>=len(times) or not np.isfinite(obs[peak-3:peak+4]).all(): continue
            selected=int(np.argmax(pred))
            windows.append({'issue_time':str(issue),'peak_value_error_cm':float(pred[selected]-obs[peak]),
                            'peak_time_error_hours':int((lead_times[selected]-times[peak])/np.timedelta64(1,'h'))})
        events.append({'start':str(times[lo]),'end':str(times[hi]),'peak':str(times[peak]),
                       'complete':complete,'forecast_windows':windows})
    count=sum(e['complete'] and bool(e['forecast_windows']) for e in events)
    return {'events':events,'complete_evaluable_events':count,'stable_event_statistics_permitted':count>=10,
            'scope':'post-event diagnosis; does not select issue times or models'}
