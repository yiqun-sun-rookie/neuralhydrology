"""Two registered complete-state forecasters; no historical executable imports."""
import torch
from torch import nn
from .contracts import CASES, ModelParts

def pack_lstm_state(hidden,cell):
    if hidden.shape != cell.shape or hidden.ndim!=3 or hidden.shape[0]!=2:
        raise ValueError('two complete LSTM layers required')
    return torch.cat((hidden.permute(1,0,2).flatten(1),cell.permute(1,0,2).flatten(1)),dim=1)

def unpack_lstm_state(state,hidden_width):
    if state.ndim!=2 or state.shape[1]!=4*hidden_width:
        raise ValueError('complete LSTM state dimension')
    h,c = state[:,:2*hidden_width],state[:,2*hidden_width:]
    return (h.reshape(-1,2,hidden_width).permute(1,0,2).contiguous(),
            c.reshape(-1,2,hidden_width).permute(1,0,2).contiguous())

class LSTMEncoder(nn.Module):
    def __init__(self,width):
        super().__init__()
        self.width=width
        self.state_dim=width*4
        self.net=nn.LSTM(7,width,num_layers=2,batch_first=True,dropout=0)

    def forward(self,history,state=None):
        initial=None if state is None else unpack_lstm_state(state,self.width)
        _,(h,c)=self.net(history,initial)
        return pack_lstm_state(h,c)

class GRUEncoder(nn.Module):
    def __init__(self,width,state_dim):
        super().__init__()
        self.width,self.state_dim=width,state_dim
        self.to_hidden=nn.Linear(state_dim,width)
        self.net=nn.GRU(7,width,batch_first=True)
        self.to_state=nn.Linear(width,state_dim)

    def forward(self,history,state=None):
        if state is None:
            state=history.new_zeros(len(history),self.state_dim)
        _,hidden=self.net(history,self.to_hidden(state)[None])
        return self.to_state(hidden[0])

class LSTMProcess(nn.Module):
    def __init__(self,width):
        super().__init__()
        self.width=width
        self.net=nn.LSTM(width+3,width,num_layers=2,batch_first=True,dropout=0)

    def forward(self,state,control):
        h,c=unpack_lstm_state(state,self.width)
        _,(h,c)=self.net(torch.cat((h[1],control),dim=1)[:,None],(h,c))
        return pack_lstm_state(h,c)

class LSTMReadout(nn.Linear):
    def forward(self,state):
        w=self.in_features
        return super().forward(state[:,w:2*w])

class GRUProcess(nn.Module):
    def __init__(self,state_dim):
        super().__init__()
        self.cell=nn.GRUCell(3,state_dim)
        self.projection=nn.Linear(state_dim,state_dim)

    def forward(self,state,control):
        return self.projection(self.cell(control,state))

class CoordinateReadout(nn.Module):
    def forward(self,state):
        return state[:,:4]

def make_parts(family,capacity,seed):
    matches=[c for c in CASES if c[:2]==(family,capacity)]
    if len(matches)!=1:
        raise ValueError('unregistered architecture/capacity')
    _,_,width,d=matches[0]
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(seed)
        if family=='legacy_lstm':
            encoder=LSTMEncoder(width)
            process,readout=LSTMProcess(width),LSTMReadout(width,4)
        else:
            encoder=GRUEncoder(width,d)
            process,readout=GRUProcess(d),CoordinateReadout()
    return ModelParts(encoder,encoder,process,readout,d)

def rollout(process,readout,state,controls):
    if state.ndim!=2 or controls.ndim!=3 or controls.shape[0]!=state.shape[0] or controls.shape[2]!=3:
        raise ValueError('rollout input shape')
    state=state.to(torch.float32)
    outputs=[]
    for control in controls.unbind(1):
        state=process(state,control.to(torch.float32))
        outputs.append(readout(state))
    output=torch.stack(outputs,dim=1)
    if not torch.isfinite(output).all():
        raise FloatingPointError('forecast numerical failure; keep calendar')
    return output

def parameters(parts,noise=None,trainable_only=False):
    seen=set()
    for module in (parts.initializer,parts.encoder,parts.process,parts.readout):
        if module is None:
            continue
        for p in module.parameters():
            if id(p) not in seen and (not trainable_only or p.requires_grad):
                seen.add(id(p))
                yield p
    if noise is not None:
        for p in (noise.raw_q,noise.raw_r,noise.raw_p0):
            if not trainable_only or p.requires_grad:
                yield p

def count_parameters(parts):
    return {'encoder':sum(p.numel() for p in parts.initializer.parameters()),
            'future':sum(p.numel() for m in (parts.process,parts.readout) for p in m.parameters()),
            'total':sum(p.numel() for p in parameters(parts)),
            'trainable':sum(p.numel() for p in parameters(parts,trainable_only=True)),
            'state_dimension':parts.state_dim,'representative_points':2*parts.state_dim+1}
