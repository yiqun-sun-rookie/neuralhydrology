"""Fresh paired analysis encoders and frozen common initializers."""
import copy
import hashlib
import torch
from .contracts import METHODS, ModelParts
from .models import LSTMEncoder, GRUEncoder

def hash_module(module):
    h=hashlib.sha256()
    for name,x in sorted(module.state_dict().items()):
        x=x.detach().cpu().contiguous()
        h.update(str((name,tuple(x.shape),str(x.dtype))).encode())
        h.update(x.numpy().tobytes())
    return h.hexdigest()

def make_branches(foundation,analysis_seed):
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(analysis_seed)
        base=foundation.initializer
        fresh=(LSTMEncoder(base.width) if isinstance(base,LSTMEncoder)
               else GRUEncoder(base.width,foundation.state_dim))
    result={}
    for method in METHODS:
        result[method]=ModelParts(copy.deepcopy(base),copy.deepcopy(fresh) if method.startswith('encoder') else None,
                                  copy.deepcopy(foundation.process),copy.deepcopy(foundation.readout),foundation.state_dim)
        result[method].initializer.requires_grad_(False)
    return result

def configure_branch(parts,noise,method):
    if method not in METHODS:
        raise ValueError('unregistered method')
    is_encoder=method.startswith('encoder_')
    if is_encoder != (parts.encoder is not None) or is_encoder == (noise is not None):
        raise ValueError('analysis parameter registration mismatch')
    parts.initializer.requires_grad_(False)
    if parts.encoder is not None:
        parts.encoder.requires_grad_(True)
    for module in (parts.process,parts.readout):
        module.requires_grad_(method.endswith('_joint'))
    if noise is not None:
        for p in (noise.raw_q,noise.raw_r,noise.raw_p0):
            p.requires_grad_(True)

def initialize_state(parts,history_first24):
    if history_first24.shape[1:]!=(24,7):
        raise ValueError('initializer requires first24 hours')
    with torch.no_grad():
        return parts.initializer(history_first24)

def encoder_analysis(parts,initial_state,history_last24):
    if parts.encoder is None or history_last24.shape[1:]!=(24,7):
        raise ValueError('analysis encoder requires last24 hours')
    return parts.encoder(history_last24,initial_state)
