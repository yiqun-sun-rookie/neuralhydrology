"""Named metre inputs, complete states and authenticated evidence contracts."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Mapping
import numpy as np
import torch

TARGETS = ('nanjing', 'zhenjiang', 'jiangyin', 'xuliujing')
CHANNELS = TARGETS + ('datong', 'wusongkou', 'astronomical_tide')
METHODS = ('encoder_fixed', 'encoder_joint', 'filter_fixed', 'filter_joint')
CASES = (('legacy_lstm', 'small', 16, 64),
         ('explicit_gru', 'small', 24, 32),
         ('legacy_lstm', 'historical_capacity', 64, 256),
         ('explicit_gru', 'historical_capacity', 94, 128))

@dataclass(frozen=True)
class PhysicalWindow:
    issue_time: np.datetime64
    history_m: np.ndarray
    analysis_controls_m: np.ndarray
    forecast_controls_m: np.ndarray
    midpoint_controls_m: np.ndarray
    targets_m: np.ndarray

@dataclass(frozen=True)
class TrainingStats:
    history_mean: np.ndarray
    history_std: np.ndarray
    control_mean: np.ndarray
    control_std: np.ndarray
    target_mean: np.ndarray
    target_std: np.ndarray
    high_threshold_m: np.ndarray
    years: tuple[int, ...]
    manifest_sha256: str

    def __post_init__(self):
        for name, size in (('history_mean',7),('history_std',7),('control_mean',3),
                           ('control_std',3),('target_mean',4),('target_std',4),
                           ('high_threshold_m',4)):
            a = np.asarray(getattr(self, name), dtype=np.float64).copy()
            if a.shape != (size,) or not np.isfinite(a).all():
                raise ValueError('invalid statistics: ' + name)
            if name.endswith('std') and (a < 1e-6).any():
                raise ValueError('degenerate physical channel: ' + name)
            a.setflags(write=False)
            object.__setattr__(self, name, a)
        if not self.years or len(set(self.years)) != len(self.years) or any(y not in range(2017,2022) for y in self.years):
            raise ValueError('statistics must come from permitted training years')
        if len(self.manifest_sha256) != 64:
            raise ValueError('missing manifest digest')
        if not (np.array_equal(self.history_mean[:4],self.target_mean)
                and np.array_equal(self.history_std[:4],self.target_std)):
            raise ValueError('observation and readout scales disagree')

@dataclass(frozen=True)
class ModelBatch:
    history: torch.Tensor
    analysis_controls: torch.Tensor
    forecast_controls: torch.Tensor
    midpoint_controls: torch.Tensor
    targets: torch.Tensor
    targets_m: torch.Tensor
    high_mask: torch.Tensor

    def __post_init__(self):
        b = self.history.shape[0]
        for name, tail in (('history',(48,7)),('analysis_controls',(24,3)),
                           ('forecast_controls',(23,3)),('midpoint_controls',(47,3)),
                           ('targets',(47,4)),('targets_m',(47,4)),('high_mask',(47,4))):
            x = getattr(self,name)
            if b < 1 or x.shape != (b,*tail) or not torch.isfinite(x).all():
                raise ValueError('invalid model batch: ' + name)
        if self.high_mask.dtype != torch.bool:
            raise ValueError('high_mask must be boolean')

@dataclass
class ModelParts:
    initializer: torch.nn.Module
    encoder: torch.nn.Module | None
    process: torch.nn.Module
    readout: torch.nn.Module
    state_dim: int

@dataclass(frozen=True)
class Whitening:
    mean: torch.Tensor
    scale: torch.Tensor

    def __post_init__(self):
        if self.mean.ndim != 1 or self.mean.shape != self.scale.shape:
            raise ValueError('invalid whitening shape')
        if self.mean.dtype != torch.float64 or self.scale.dtype != torch.float64:
            raise ValueError('whitening requires float64')
        if not torch.isfinite(self.mean).all() or not torch.isfinite(self.scale).all() or (self.scale < .001).any():
            raise ValueError('invalid whitening values')

@dataclass
class FilterNoise:
    raw_q: torch.nn.Parameter
    raw_r: torch.nn.Parameter
    raw_p0: torch.nn.Parameter

@dataclass(frozen=True)
class GroupSeal:
    group_id: str
    member_ids: tuple[str, ...]
    epochs: int
    checkpoint_hashes: Mapping[str, str]
    status: str
    budget_final: bool = False
    evidence_sha256: str = ''
    member_evidence: Mapping[str, dict] = field(default_factory=dict)

@dataclass(frozen=True)
class PredictionRows:
    issue_time: np.ndarray
    lead: np.ndarray
    station: np.ndarray
    seed: np.ndarray
    prediction_cm: np.ndarray
    observation_cm: np.ndarray

def verify_shapes(window):
    for name, shape in (('history_m',(48,7)),('analysis_controls_m',(24,3)),
                        ('forecast_controls_m',(23,3)),('midpoint_controls_m',(47,3)),
                        ('targets_m',(47,4))):
        x = np.asarray(getattr(window,name))
        if x.shape != shape or not np.isfinite(x).all():
            raise ValueError('invalid physical window: ' + name)
    t = np.datetime64(window.issue_time, 'ns')
    if np.isnat(t) or t != t.astype('datetime64[h]').astype('datetime64[ns]'):
        raise ValueError('issue time must be an exact hour')
    times = t + np.arange(-47,24)*np.timedelta64(1,'h')
    if len(set(times.astype('datetime64[Y]'))) != 1:
        raise ValueError('71-hour window crosses a year boundary')

def slice_batch(batch, selection):
    return ModelBatch(**{name: getattr(batch,name)[selection] for name in batch.__dataclass_fields__})

def combine_batches(batches):
    if not batches:
        raise ValueError('empty batches')
    return ModelBatch(**{name: torch.cat([getattr(b,name) for b in batches])
                         for name in batches[0].__dataclass_fields__})
