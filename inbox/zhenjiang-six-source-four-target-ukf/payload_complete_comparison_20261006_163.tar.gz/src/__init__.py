"""Isolated water-level comparison; importing this package performs no I/O."""
