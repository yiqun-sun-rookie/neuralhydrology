"""Physical losses, full-batch denominators, independent RNG and group budgets."""
import copy
import hashlib
import json
import time
from pathlib import Path
import numpy as np
import torch
from .contracts import slice_batch, combine_batches
from .models import parameters, rollout
from .state_estimators import initialize_state, encoder_analysis
from .differentiable_filter import filter_analysis, StabilityLedger
from .execution import model_device,move_batch,device_batches,device_identity

def deterministic_runtime():
    import os
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    torch.backends.cudnn.benchmark=False

def weighted_mae_cm(prediction,targets,high_mask,stats,denominator=None):
    if prediction.shape!=targets.shape or high_mask.shape!=targets.shape:
        raise ValueError('weighted loss shape')
    scale=torch.tensor(stats.target_std.copy()*100,dtype=torch.float64,device=prediction.device)
    errors=(prediction.double()-targets.double()).abs()*scale
    weights=1+high_mask.double()
    summed=(errors*weights).sum(dim=(0,1))
    denominator=weights.sum(dim=(0,1)) if denominator is None else denominator
    if (denominator<=0).any():
        raise ValueError('empty station denominator')
    return (summed/denominator).mean()

def foundation_predictions(parts,batch):
    mid=parts.initializer(batch.history[:,:24])
    endpoint=parts.initializer(batch.history[:,24:],mid)
    return (rollout(parts.process,parts.readout,mid,batch.midpoint_controls),
            rollout(parts.process,parts.readout,endpoint,batch.forecast_controls))

def foundation_loss(parts,batch,stats,denominators=None):
    mid,end=foundation_predictions(parts,batch)
    dmid,dend=(None,None) if denominators is None else denominators
    return .5*weighted_mae_cm(mid,batch.targets,batch.high_mask,stats,dmid)+.5*weighted_mae_cm(end,batch.targets[:,24:],batch.high_mask[:,24:],stats,dend)

def branch_prediction(parts,noise,whitening,method,batch,ledger=None,use_observations=True):
    initial=initialize_state(parts,batch.history[:,:24])
    if method.startswith('encoder_'):
        if noise is not None: raise ValueError('encoder has filter noise')
        state=encoder_analysis(parts,initial,batch.history[:,24:])
    elif method.startswith('filter_'):
        if noise is None or whitening is None: raise ValueError('filter metadata missing')
        state,_=filter_analysis(parts,noise,whitening,initial,batch,use_observations,ledger)
    else:
        raise ValueError('unregistered method')
    return rollout(parts.process,parts.readout,state,batch.forecast_controls)

def branch_loss(parts,noise,whitening,method,batch,stats,denominator=None,ledger=None):
    prediction=branch_prediction(parts,noise,whitening,method,batch,ledger)
    return weighted_mae_cm(prediction,batch.targets[:,24:],batch.high_mask[:,24:],stats,denominator)

def make_optimizer(parts,noise,learning_rate):
    if learning_rate not in (.0003,.001,.003):
        raise ValueError('unregistered learning rate')
    return torch.optim.Adam(list(parameters(parts,noise,True)),lr=learning_rate,
                            betas=(.9,.999),eps=1e-8,weight_decay=0)

def clip_finite_gradients(trainable):
    """Keep the original path; recover finite-gradient norm overflow only."""
    try:
        return torch.nn.utils.clip_grad_norm_(trainable,1.,error_if_nonfinite=True)
    except RuntimeError as error:
        if 'non-finite' not in str(error):
            raise
        gradients=[p.grad for p in trainable]
        if not gradients or any(g is None or not torch.isfinite(g).all() for g in gradients):
            raise FloatingPointError('missing or nonfinite trainable gradient') from error
        # Scale before squaring. This changes neither the L2 bound nor epsilon.
        peak=torch.stack([g.detach().double().abs().max() for g in gradients]).max()
        if not torch.isfinite(peak) or peak<=0:
            raise FloatingPointError('invalid finite-gradient scale') from error
        norm=peak*torch.stack([(g.detach().double()/peak).square().sum() for g in gradients]).sum().sqrt()
        if not torch.isfinite(norm):
            raise FloatingPointError('gradient norm exceeds float64 range') from error
        coefficient=(1./(norm+1e-6)).clamp(max=1.)
        with torch.no_grad():
            for gradient in gradients:
                gradient.mul_(coefficient.to(dtype=gradient.dtype,device=gradient.device))
        print(json.dumps({'status':'gradient_norm_overflow_recovered','finite_gradients':True,
                          'gradient_norm_before_clip':float(norm),'tensor_count':len(gradients),
                          'norm_dtype':'float64','clipping_bound':1.}),flush=True)
        return norm


def train_effective_batch(parts,noise,whitening,method,batch,stats,optimizer,micro_batch=2):
    if micro_batch<1 or len(batch.history)>16:
        raise ValueError('effective batch exceeds fixed budget')
    optimizer.zero_grad(set_to_none=True)
    full=(1+batch.high_mask.double()).sum((0,1))
    endpoint=(1+batch.high_mask[:,24:].double()).sum((0,1))
    ledger=StabilityLedger() if method.startswith('filter') else None
    loss_value=0.
    for start in range(0,len(batch.history),micro_batch):
        sub=slice_batch(batch,slice(start,start+micro_batch))
        loss=(foundation_loss(parts,sub,stats,(full,endpoint)) if method=='foundation'
              else branch_loss(parts,noise,whitening,method,sub,stats,endpoint,ledger))
        if not torch.isfinite(loss):
            raise FloatingPointError('nonfinite loss')
        loss.backward()
        loss_value+=float(loss.detach())
    trainable=list(parameters(parts,noise,True))
    if any(p.grad is None or not torch.isfinite(p.grad).all() for p in trainable):
        raise FloatingPointError('missing or nonfinite trainable gradient')
    health=None if ledger is None else ledger.report(enforce=False)
    norm=clip_finite_gradients(trainable)
    optimizer.step()
    return {'loss_cm':loss_value,'gradient_norm_before_clip':float(norm),
            'actual_batch_size':len(batch.history),'stability':health}

def validation_mae(parts,noise,whitening,method,batches,stats):
    total=None; count=0
    ledger=StabilityLedger() if method.startswith('filter') else None
    with torch.no_grad():
        for batch in device_batches(batches,model_device(parts)):
            output=(foundation_predictions(parts,batch)[1] if method=='foundation'
                    else branch_prediction(parts,noise,whitening,method,batch,ledger))
            scale=torch.tensor(stats.target_std.copy()*100,dtype=torch.float64,device=output.device)
            mean=torch.tensor(stats.target_mean.copy()*100,dtype=torch.float64,device=output.device)
            summed=(output.double()*scale+mean-batch.targets_m[:,24:]*100).abs().sum((0,1))
            total=summed if total is None else total+summed
            count+=len(output)*23
    if not count:
        raise ValueError('empty validation calendar')
    if ledger is not None: ledger.report()
    return float((total/count).mean())

def best_epoch(validation_mae):
    if not validation_mae or not np.isfinite(validation_mae).all():
        raise ValueError('incomplete or failed validation series')
    return int(np.argmin(validation_mae))+1

def extension_required(values,current_epochs):
    if current_epochs not in (200,400) or not values:
        raise ValueError('invalid budget boundary')
    for series in values.values():
        if len(series)!=current_epochs or not np.isfinite(series).all() or min(series)<0:
            raise ValueError('all members require complete valid validation history')
    start=current_epochs-20
    return any(np.mean(v[start:start+10])>0 and
               (np.mean(v[start:start+10])-np.mean(v[start+10:]))/np.mean(v[start:start+10])>=.01
               for v in values.values())

def select_learning_rate(candidate_values):
    if set(candidate_values)!={.0003,.001,.003} or not np.isfinite(list(candidate_values.values())).all():
        raise ValueError('three completed candidate scores required')
    return min(candidate_values,key=lambda rate:(candidate_values[rate],rate))

def epoch_indices(issue_times,seed,epoch):
    times=np.asarray(issue_times).astype('datetime64[h]')
    phase=(epoch-1)%12
    eligible=np.flatnonzero((times.astype(np.int64)%12)==phase)
    generator=torch.Generator().manual_seed(seed+200000+epoch-1)
    ordered=eligible[torch.randperm(len(eligible),generator=generator).numpy()]
    return ordered,hashlib.sha256(ordered.astype('<i8').tobytes()).hexdigest()

def snapshot_parts(parts,noise=None):
    state={name:{k:v.detach().cpu().clone() for k,v in getattr(parts,name).state_dict().items()}
           for name in ('initializer','process','readout')}
    if parts.encoder is not None:
        state['encoder']={k:v.detach().cpu().clone() for k,v in parts.encoder.state_dict().items()}
    if noise is not None:
        state['noise']={name:getattr(noise,name).detach().cpu().clone() for name in ('raw_q','raw_r','raw_p0')}
    return state

def restore_parts(parts,state,noise=None):
    for name in ('initializer','process','readout','encoder'):
        module=getattr(parts,name)
        if module is not None: module.load_state_dict(state[name],strict=True)
    if noise is not None:
        with torch.no_grad():
            for name in ('raw_q','raw_r','raw_p0'): getattr(noise,name).copy_(state['noise'][name])

class SchedulerContinuation(Exception):
    """A scheduler time slice ended; this is not a scientific fit failure."""


class FitSession:
    """A fresh optimizer and metrics log; no evaluation loader is accepted."""
    def __init__(self,parts,noise,whitening,method,stats,seed,rate,run_dir,config):
        self.parts,self.noise,self.whitening,self.method=parts,noise,whitening,method
        self.stats,self.seed=stats,seed
        self.optimizer=make_optimizer(parts,noise,rate)
        self.run_dir=Path(run_dir)
        resume=config.get('effective_config',{}).get('scheduler_continuation',False)
        exists=self.run_dir.exists()
        self.run_dir.mkdir(parents=True,exist_ok=resume)
        self.values=[]; self.train_metrics=[]; self.shuffle_hashes=[]; self.best_state=None
        self.deadline=None
        self.scheduler_deadline=None
        self.micro_batch=config.get('effective_config',{}).get('training_contract',{}).get('initial_micro_batch',2)
        self.device=model_device(parts)
        config_path=self.run_dir/'config.json'
        if exists:
            if not resume or json.loads(config_path.read_text())!=config:
                raise ValueError('continuation configuration differs')
            if (self.run_dir/'failure.json').exists(): raise ValueError('failed fit cannot resume automatically')
            checkpoint=self.run_dir/'continuation.pt'
            if checkpoint.exists():
                state=torch.load(checkpoint,map_location=self.device,weights_only=True)
                restore_parts(parts,state['current'],noise)
                self.optimizer.load_state_dict(state['optimizer'])
                self.values=state['values']; self.train_metrics=state['train_metrics']
                self.shuffle_hashes=state['shuffle_hashes']; self.best_state=state['best']
                if state['config_sha256']!=hashlib.sha256(config_path.read_bytes()).hexdigest():
                    raise ValueError('continuation identity differs')
        else:
            config_path.write_text(json.dumps(config,sort_keys=True,indent=2)+'\n',encoding='utf-8')

    def epoch(self,training_windows,training_times,validation_batches,epoch):
        ids,sha=epoch_indices(training_times,self.seed,epoch)
        if not len(ids): raise ValueError('empty training phase')
        metrics=[]
        for start in range(0,len(ids),16):
            if self.deadline is not None and time.perf_counter()>=self.deadline:
                raise TimeoutError('approved group wall-time/cost ceiling reached')
            b=move_batch(combine_batches([training_windows[i] for i in ids[start:start+16]]),self.device)
            metrics.append(train_effective_batch(self.parts,self.noise,self.whitening,self.method,b,self.stats,self.optimizer,self.micro_batch))
            first_step=self.run_dir/'first_optimizer_step.json'
            if not first_step.exists():
                first_step.write_text(json.dumps({'status':'real_optimizer_step_completed','epoch':epoch,
                    'training_batch_size':len(b.history),'method':self.method,'loss_cm':metrics[-1]['loss_cm'],
                    'device_identity':device_identity(self.device)},indent=2)+'\n',encoding='utf-8')
                print(json.dumps({'run':self.run_dir.name,'status':'first_optimizer_step_completed',
                                  'loss_cm':metrics[-1]['loss_cm']}),flush=True)
        value=validation_mae(self.parts,self.noise,self.whitening,self.method,validation_batches,self.stats)
        if self.deadline is not None and time.perf_counter()>=self.deadline:
            raise TimeoutError('approved group ceiling reached after validation')
        self.values.append(value); self.shuffle_hashes.append(sha); self.train_metrics.append(metrics)
        if best_epoch(self.values)==epoch:
            self.best_state=snapshot_parts(self.parts,self.noise)
        if epoch in (100,200,400):
            torch.save(snapshot_parts(self.parts,self.noise),self.run_dir/f'epoch_{epoch:03d}.pt')
        if self.run_dir.joinpath('config.json').exists():
            state={'current':snapshot_parts(self.parts,self.noise),'optimizer':self.optimizer.state_dict(),
                   'best':self.best_state,'values':self.values,'train_metrics':self.train_metrics,
                   'shuffle_hashes':self.shuffle_hashes,
                   'config_sha256':hashlib.sha256((self.run_dir/'config.json').read_bytes()).hexdigest()}
            temporary=self.run_dir/'continuation.pt.tmp'
            torch.save(state,temporary); temporary.replace(self.run_dir/'continuation.pt')
        metrics_path=self.run_dir/'metrics.json.tmp'
        metrics_path.write_text(json.dumps({'validation_mae_cm':self.values,
            'shuffle_hashes':self.shuffle_hashes,'train_metrics':self.train_metrics},indent=2)+'\n',encoding='utf-8')
        metrics_path.replace(self.run_dir/'metrics.json')
        print(json.dumps({'run':self.run_dir.name,'epoch':epoch,'validation_mae_cm':value}),flush=True)

    def finish(self,epochs,budget_final):
        if not budget_final or len(self.values)!=epochs:
            raise ValueError('cannot finish before group budget is final')
        if self.method.startswith('filter'):
            jitters=[j for epoch in self.train_metrics for batch in epoch for j in batch['stability']['step_jitters']]
            StabilityLedger(jitters).report()
        torch.save(self.best_state,self.run_dir/'best.pt')
        restore_parts(self.parts,self.best_state,self.noise)
        return {'status':'success','epochs':epochs,'budget_final':True,'best_epoch':best_epoch(self.values),
                'validation_mae':self.values,'checkpoint_sha256':hashlib.sha256((self.run_dir/'best.pt').read_bytes()).hexdigest(),
                'shuffle_hash':hashlib.sha256(''.join(self.shuffle_hashes).encode()).hexdigest(),
                'device_identity':device_identity(self.device),'micro_batch':self.micro_batch,'effective_batch_size':16}

def train_group(sessions,training_windows,training_times,validation_batches):
    """Barrier at 200; any member extends the entire physical group to 400."""
    deterministic_runtime()
    try:
        def advance(first,last):
            for epoch in range(first,last+1):
                for session in sessions.values():
                    if len(session.values)>=epoch: continue
                    scheduler_deadline=getattr(session,'scheduler_deadline',None)
                    if scheduler_deadline is not None and time.perf_counter()>=scheduler_deadline:
                        raise SchedulerContinuation('resume from last complete member epoch in next scheduler allocation')
                    session.epoch(training_windows,training_times,validation_batches,epoch)
        advance(1,200)
        extend=extension_required({k:s.values[:200] for k,s in sessions.items()},200)
        if extend:
            advance(201,400)
        final_epochs=400 if extend else 200
        results={k:s.finish(final_epochs,True) for k,s in sessions.items()}
        for row in results.values():
            row['budget_not_proven_converged']=final_epochs==400 and extension_required({k:r['validation_mae'] for k,r in results.items()},400)
        return results,final_epochs
    except SchedulerContinuation:
        raise
    except Exception as error:
        for session in sessions.values():
            (session.run_dir/'failure.json').write_text(json.dumps({'status':'failed','type':type(error).__name__,
                'reason':str(error),'epochs_completed':len(session.values),'evidence':getattr(error,'evidence',{})},indent=2)+'\n',encoding='utf-8')
        raise
