"""Closed registration, complete group seals and result-independent aliases."""
import copy
import hashlib
import json
from collections import Counter
from .contracts import GroupSeal
from .training import extension_required

def digest_json(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def code_identity(root=None):
    from pathlib import Path
    root=Path(root) if root is not None else Path(__file__).resolve().parents[1]
    files=sorted([*root.joinpath('src').glob('*.py'),*root.joinpath('scripts').glob('*.py'),
                  *root.joinpath('vendor/pytides').glob('*.py')])
    return digest_json({p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files})

def validate_registry(registry,protocol):
    runs=registry['runs']; gates=registry['gates']
    byid={r['exp_id']:r for r in runs}; bygate={g['gate_id']:g for g in gates}
    if len(runs)!=240 or len(byid)!=240 or len(gates)!=34 or len(bygate)!=34:
        raise ValueError('240 unique logical runs and 34 unique gates required')
    if Counter(r['type'] for r in runs)!={'tune_foundation':12,'tune_branch':48,'final_foundation':20,'primary':80,'controlled':80}:
        raise ValueError('registration allocation changed')
    nodes={r['exp_id']:r['dependency_ids'] for r in runs}
    nodes.update({g['gate_id']:g['members']+g['depends_on'] for g in gates})
    seen=set(); active=set()
    def visit(node):
        if node not in nodes: raise ValueError('missing dependency: '+node)
        if node in active: raise ValueError('dependency cycle')
        if node in seen: return
        active.add(node)
        for dep in nodes[node]: visit(dep)
        active.remove(node); seen.add(node)
    for node in nodes: visit(node)
    for name in ('run_dir','config_path','metrics_path'):
        if len({r[name] for r in runs})!=240: raise ValueError('shared output path')
    for r in runs:
        split=protocol['splits']['tuning' if r['type'].startswith('tune') else 'final']
        if r['train_years']!=split['train'] or r['selection_years']!=split['select']:
            raise ValueError('year contract changed')
        if r['type'] in ('primary','controlled'):
            seal=r['case']+'__final_foundation_group__seal'
            if seal not in r['dependency_ids'] or set(byid[m]['seed'] for m in bygate[seal]['members'])!=set(protocol['seeds']):
                raise ValueError('incomplete final foundation barrier')
            parent=byid[r['parent_run_id']]
            if (parent['seed'],parent['case'])!=(r['seed'],r['case']): raise ValueError('wrong parent')
    if not protocol['authority'].get('formal_training',False) and any(r['status'] not in ('planned_not_authorized','alias') for r in runs):
        raise PermissionError('formal run status lacks authority')

def ready(run,completed_run_ids,seals,external_evidence=None):
    for dep in run['dependency_ids']:
        if dep in run.get('dependency_members',{}) or dep.endswith('__seal') or dep.endswith('_sealed') or '__select_rate__' in dep:
            expected=run.get('dependency_members',{}).get(dep)
            if expected == []:
                record=(external_evidence or {}).get(dep,{})
                unsigned={k:v for k,v in record.items() if k!='evidence_sha256'}
                if record.get('status')!='admitted' or record.get('evidence_sha256')!=digest_json(unsigned):
                    return False
                continue
            seal=seals.get(dep)
            if (seal is None or seal.group_id!=dep or seal.status!='sealed_success' or not seal.budget_final
                or len(seal.evidence_sha256)!=64 or set(seal.checkpoint_hashes)!=set(seal.member_ids)):
                return False
            if expected is None or set(expected)!=set(seal.member_ids): return False
            required=run.get('required_group_epochs',{}).get(dep)
            if required is not None and required!=seal.epochs: return False
            if any(len(h)!=64 for h in seal.checkpoint_hashes.values()): return False
        elif dep not in completed_run_ids:
            return False
    return True

def seal_group(group_id,member_results,final_epochs,expected_members=None):
    if expected_members is None or not expected_members or set(member_results)!=set(expected_members):
        raise ValueError('complete expected physical member set required')
    if final_epochs not in (200,400): raise ValueError('unregistered final budget')
    for r in member_results.values():
        if r.get('status')!='success' or not r.get('budget_final') or r.get('epochs')!=final_epochs:
            raise ValueError('group incomplete, failed, or budget not final')
        if len(r.get('checkpoint_sha256',''))!=64 or not 1<=r.get('best_epoch',0)<=final_epochs:
            raise ValueError('missing selected checkpoint')
        from .training import best_epoch
        if best_epoch(r['validation_mae'])!=r['best_epoch']: raise ValueError('not earliest best epoch')
    needs_extension=extension_required({k:r['validation_mae'] for k,r in member_results.items()},final_epochs)
    if final_epochs==200 and needs_extension:
        raise ValueError('extension required; 200-epoch seal is stale')
    hashes={k:r['checkpoint_sha256'] for k,r in member_results.items()}
    return GroupSeal(group_id,tuple(sorted(expected_members)),final_epochs,hashes,'sealed_success',True,
                     digest_json(member_results),copy.deepcopy(member_results))


def verify_parent_binding(run,effective,seals):
    """A file's self-hash cannot substitute for its membership in the selected parent group."""
    if run['method']=='foundation':
        return
    suffix='__tune_foundation_group__seal' if run['type']=='tune_branch' else '__final_foundation_group__seal'
    gate=run['case']+suffix
    seal=seals.get(gate)
    expected=run.get('dependency_members',{}).get(gate)
    if (seal is None or seal.group_id!=gate or seal.status!='sealed_success' or not seal.budget_final
        or not expected or set(expected)!=set(seal.member_ids)
        or set(seal.member_evidence)!=set(seal.member_ids)
        or seal.evidence_sha256!=digest_json(seal.member_evidence)):
        raise ValueError('complete authenticated parent group evidence required')
    # Reconstruct the seal from the actual member outcomes, including final budget and earliest best.
    checked=seal_group(gate,seal.member_evidence,seal.epochs,expected_members=expected)
    if checked.checkpoint_hashes!=seal.checkpoint_hashes:
        raise ValueError('parent group checkpoint hashes disagree with evidence')
    parent=effective.get('parent_run_id')
    if not parent or parent not in seal.member_ids or (run.get('parent_run_id') and parent!=run['parent_run_id']):
        raise ValueError('resolved parent run is not the registered parent')
    record=seal.member_evidence[parent]
    if (record.get('case'),record.get('seed'),record.get('method'))!=(run['case'],run['seed'],'foundation'):
        raise ValueError('parent architecture, seed or method changed')
    if run['type']=='tune_branch':
        winner=min(seal.member_ids,key=lambda m:(min(seal.member_evidence[m]['validation_mae']),
                   seal.member_evidence[m]['learning_rate']))
        if parent!=winner:
            raise ValueError('tuning branch does not inherit selected foundation candidate')
    pairs={'parent_hash':'checkpoint_sha256','parent_best_epoch':'best_epoch',
           'initializer_hash':'initializer_hash','normalization_hash':'normalization_hash'}
    if any(effective.get(left)!=record.get(right) or record.get(right) is None for left,right in pairs.items()):
        raise ValueError('parent identity differs from the complete group seal')
    if run['method'].startswith('filter'):
        if effective.get('whitening_hash')!=record.get('whitening_hash') or not record.get('whitening_hash'):
            raise ValueError('whitening is not from the selected sealed parent')
        if digest_json(effective.get('whitening'))!=record['whitening_hash']:
            raise ValueError('parent whitening bytes differ')

def resolve_aliases(registry,selected_rates,resolved_configs,cases=None):
    result=copy.deepcopy(registry); aliases=dict(result.get('aliases',{}))
    needed=set(result['alias_policy']['must_match'])
    for run in result['runs']:
        if run['type']!='controlled': continue
        if cases is not None and run['case'] not in cases: continue
        target=run['may_alias']
        key=(run['case'],run['method'])
        if key not in selected_rates: raise ValueError('method rate not selected')
        left=resolved_configs.get(run['exp_id']); right=resolved_configs.get(target)
        if left is None or right is None or not needed.issubset(left) or not needed.issubset(right):
            raise ValueError('complete resolved configs required before alias decision')
        # Equality covers ALL effective fields, including normalization and whitening.
        if selected_rates[key]==.001 and left==right:
            aliases[run['exp_id']]=target
            run['status']='alias'; run['physical_run_id']=target
    result['aliases']=aliases
    result['physical_run_ids']=[r['exp_id'] for r in result['runs'] if r['exp_id'] not in aliases]
    for gate in result['gates']:
        gate['physical_members']=sorted({aliases.get(m,m) for m in gate['members']})
    for r in result['runs']:
        for gate_id in r.get('dependency_members',{}):
            g=next(g for g in result['gates'] if g['gate_id']==gate_id)
            r['dependency_members'][gate_id]=g['physical_members']
    return result

def authorize(records,action,protocol_hash=None):
    if not records.get('authority',{}).get(action,False):
        raise PermissionError('explicit '+action+' authority missing')
    if protocol_hash is not None and records.get('protocol_sha256')!=protocol_hash:
        raise PermissionError('authorization belongs to a different protocol')

def resolve_effective_config(run,protocol,selected_rate,identities):
    """Bind mechanisms before training; actual final epochs belong to the seal."""
    required={'parent_hash','initializer_hash','analysis_initialization_hash','training_data_hash',
              'normalization_hash','whitening_hash','tide_source_hash','code_hash','shuffle_hash'}
    if not required.issubset(identities): raise ValueError('identity chain incomplete')
    if selected_rate not in protocol['learning_rates']: raise ValueError('unregistered selected rate')
    config=copy.deepcopy(identities)
    config.update({'case':run['case'],'method':run['method'],'seed':run['seed'],
        'learning_rate':selected_rate,'budget_group':run['budget_group'],
        'budget_policy_hash':digest_json(protocol['training']),
        'optimizer':'Adam','optimizer_settings':{k:protocol['training'][k] for k in
            ('betas','epsilon','weight_decay','gradient_clip_norm')},
        'loss':'high_water_weighted_station_equal_mae_cm',
        'objective':'equal_midpoint47_endpoint23' if run['method']=='foundation' else 'endpoint23',
        'noise_initialization':{k:protocol['filter'][k] for k in
            ('process_variance','observation_variance','initial_variance','variance_floor')},
        'training_contract':protocol['training'],'data_contract':protocol['data'],
        'network_precision':'float32','covariance_precision':'float64'})
    if 'resolved_group_epochs' in config: raise ValueError('future budget outcome cannot determine pre-training aliasing')
    return config

def estimate_resources(measured_seconds,steps_per_epoch,epoch_cap,device_price_per_hour):
    if epoch_cap!=400 or device_price_per_hour<0 or not measured_seconds:
        raise ValueError('400-epoch worst-case quotation required')
    from .contracts import CASES,METHODS
    cases=[family+'__'+capacity for family,capacity,_,_ in CASES]
    expected={case+'/'+method for case in cases for method in ('foundation',*METHODS)}
    if set(measured_seconds)!=expected or set(steps_per_epoch)!=expected:
        raise ValueError('exact four configurations and five training categories required')
    totals=[]; per_fit={}
    for name,m in measured_seconds.items():
        if m['warmup_steps']!=5 or m['measurement_steps']!=30 or m['memory_fraction']>.8:
            raise ValueError('resource admission failed: '+name)
        if m['seconds_per_step']<=0 or m['validation_seconds_per_epoch']<0 or m['save_seconds_per_epoch']<0:
            raise ValueError('invalid resource measurement')
        spec=steps_per_epoch[name]
        if spec['fits_max']!=(8 if name.endswith('/foundation') else 13):
            raise ValueError('worst-case fit allocation differs')
        seconds=(1.5*m['seconds_per_step']*spec['maximum_steps']+m['validation_seconds_per_epoch']+m['save_seconds_per_epoch'])*epoch_cap*spec['fits_max']
        per_fit[name]=seconds/spec['fits_max']
        totals.append({'category':name,'seconds_upper':seconds,'fits_max':spec['fits_max']})
    if sum(r['fits_max'] for r in totals)!=240 or len(totals)!=20:
        raise ValueError('all four configurations and five training categories required')
    seconds=sum(r['seconds_upper'] for r in totals)
    groups={}
    for case in cases:
        foundation=per_fit[case+'/foundation']; branches=sum(per_fit[case+'/'+m] for m in METHODS)
        groups.update({case+'__tune_foundation_group':3*foundation,case+'__final_foundation_group':5*foundation,
            case+'__tune_branch_group':3*branches,case+'__all_final_branches_group':10*branches})
    return {'status':'unbound_estimate','categories':totals,'maximum_epochs':400,'physical_fits_upper':240,'hours_upper':seconds/3600,
            'device_price_per_hour':device_price_per_hour,'cost_upper':seconds/3600*device_price_per_hour,
            'group_seconds_upper':groups,'scientific_result':False}


def quote_measured_resources(document,steps,price,overheads):
    """Only whole-calendar validation and actual disk measurements can seal a quote."""
    from .execution import device_identity
    measurements=document.get('measurements',{})
    identities=[m.get('device_identity') for m in measurements.values()]
    if not identities or any(i!=identities[0] for i in identities) or not identities[0]:
        raise ValueError('one measured device identity required for all categories')
    identity=identities[0]
    if identity!=device_identity(identity['device']):
        raise ValueError('quotation device is unavailable or differs from measured device')
    for name,m in measurements.items():
        spec=steps.get(name,{})
        if (m.get('validation_scope')!='complete_selection_calendar'
            or not m.get('validation_windows') or m['validation_windows']!=spec.get('validation_windows')
            or not m.get('disk_save_bytes') or m.get('save_scope')!='actual_disk_checkpoint'
            or spec.get('maximum_steps',0)<=0):
            raise ValueError('full validation calendar, step counts and actual disk save required: '+name)
    required={'data_preparation','historical_reference_conversion','prediction_outputs','bootstrap_50000','storage'}
    if set(overheads)!=required or any(not isinstance(v,(int,float)) or v<0 for v in overheads.values()):
        raise ValueError('all five non-training cost ceilings required')
    quote=estimate_resources(measurements,steps,400,price)
    quote.update(status='sealed_success',device_identity=identity,protocol_sha256=document['protocol_sha256'],
                 measurements_sha256=digest_json(document),calendar_steps_sha256=digest_json(steps),
                 non_training_cost_upper=overheads,training_cost_upper=quote['cost_upper'])
    quote['cost_upper']+=sum(overheads.values())
    return quote
