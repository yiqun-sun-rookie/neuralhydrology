"""Synthetic CUDA check of the unchanged clipping bound and overflow recovery."""
import json
import pathlib
import sys
import torch
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.training import clip_finite_gradients,deterministic_runtime

deterministic_runtime()
a=torch.nn.Parameter(torch.zeros(3,device='cuda'));a.grad=torch.tensor([.1,-.2,.3],device='cuda')
b=torch.nn.Parameter(torch.zeros(3,device='cuda'));b.grad=a.grad.clone()
expected=torch.nn.utils.clip_grad_norm_([a],1.,error_if_nonfinite=True)
actual=clip_finite_gradients([b])
assert torch.equal(expected,actual) and torch.equal(a.grad,b.grad)
b.grad=torch.tensor([1e20,-2e20,3e20],device='cuda')
assert torch.isfinite(b.grad).all()
clip_finite_gradients([b])
assert torch.allclose(torch.linalg.vector_norm(b.grad.double()),torch.tensor(1.,device='cuda',dtype=torch.float64),atol=1e-7,rtol=1e-7)
print(json.dumps({'status':'synthetic_cuda_numeric_acceptance_passed','ordinary_path_bitwise_equal':True,
                  'finite_large_gradients_clipped_to_original_bound':True,'formal_optimizer_updates':0}),flush=True)
