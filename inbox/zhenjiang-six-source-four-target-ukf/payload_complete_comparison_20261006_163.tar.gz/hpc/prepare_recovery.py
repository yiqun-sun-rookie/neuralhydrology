"""Authenticate and copy the failed case's complete-epoch state into a new root.

Run inside the admitted nh_final environment. Original sources remain read-only.
Only code/configuration identity is rebound; training tensors and histories must
remain bit-for-bit identical. No evaluation data or historical models are read.
"""
import copy
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys

import torch

ROOT=pathlib.Path(__file__).resolve().parents[1]
PARENT=pathlib.Path('/data1/home/sunyiq/zhenjiang_complete_comparison_20261006_002')
CASE='explicit_gru__historical_capacity'
OLD_CODE='343af2846edcab85a98bab74c777fc91c7fcae191e6ed30727cb99f77b722c9d'
sys.path.insert(0,str(ROOT))
from src.scheduler import code_identity


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as stream:
        json.dump(value,stream,sort_keys=True,indent=2,allow_nan=False);stream.write('\n')


def state_hash(value):
    digest=hashlib.sha256()
    def visit(item):
        if isinstance(item,torch.Tensor):
            tensor=item.detach().cpu().contiguous()
            digest.update(str((str(tensor.dtype),tuple(tensor.shape))).encode())
            digest.update(tensor.reshape(-1).view(torch.uint8).numpy().tobytes())
        elif isinstance(item,dict):
            for key in sorted(item,key=repr):
                digest.update(repr(key).encode());visit(item[key])
        elif isinstance(item,(list,tuple)):
            digest.update(str(len(item)).encode())
            for entry in item:visit(entry)
        else:
            digest.update(json.dumps(item,sort_keys=True,allow_nan=False).encode())
    visit(value)
    return digest.hexdigest()


def main():
    queue=subprocess.run(['squeue','-h','-j','236708','-o','%i|%T'],capture_output=True,text=True,check=True)
    if queue.stdout.strip():raise ValueError('original failed case has an active job; do not duplicate')
    account=subprocess.run(['sacct','-n','-X','-j','236708','--format=JobID,State,ExitCode','-P'],capture_output=True,text=True,check=True)
    if not any(line.startswith('236708|FAILED|1:0') for line in account.stdout.splitlines()):
        raise ValueError('original case failure is not confirmed')
    parent_files=sorted([*PARENT.joinpath('src').glob('*.py'),*PARENT.joinpath('scripts').glob('*.py'),*PARENT.joinpath('vendor/pytides').glob('*.py')])
    parent_hashes={p.relative_to(PARENT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in parent_files}
    actual_old=hashlib.sha256(json.dumps(parent_hashes,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    if actual_old!=OLD_CODE:raise ValueError('original released training sources changed')
    new_code=code_identity()
    auth=read(ROOT/'records/authorization.json')
    if auth['code_hash']!=new_code:raise ValueError('recovery authority code differs')
    for name in ('protocol-v3.json','registry-v3.json'):
        if (ROOT/'configs'/name).read_bytes()!=(PARENT/'configs'/name).read_bytes():
            raise ValueError('frozen protocol or registrations changed')
    for split in ('tuning','final'):
        dest=ROOT/'prepared'/split/'manifest.json';dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(PARENT/'prepared'/split/'manifest.json',dest)
    prep_path=PARENT/'records/data_preparation_complete.json';prep=read(prep_path)
    if prep['status']!='admitted' or prep['code_hash']!=OLD_CODE:
        raise ValueError('original prepared data is not admitted')
    shutil.copyfile(prep_path,ROOT/'records/parent_data_preparation_complete.json')
    prep['code_hash']=new_code
    prep['recovery_reauthentication']={'source_record_sha256':hashlib.sha256(prep_path.read_bytes()).hexdigest(),
        'source_root':str(PARENT),'unchanged_manifests':True,'no_data_or_tide_refit':True}
    write(ROOT/'records/data_preparation_complete.json',prep)
    source_group=PARENT/'records'/CASE/'tune_foundation_group_configs.json'
    old_configs=read(source_group);new_configs=copy.deepcopy(old_configs)
    migrations=[]
    for run,config in new_configs.items():
        source=PARENT/'runs'/run;dest=ROOT/'runs'/run
        original_config=source/'config.json';failure=source/'failure.json';checkpoint=source/'continuation.pt'
        if read(original_config)!=old_configs[run] or old_configs[run]['effective_config']['code_hash']!=OLD_CODE:
            raise ValueError('original run configuration differs')
        if not failure.is_file() or 'norm' not in read(failure)['reason']:
            raise ValueError('expected original finite-gradient norm failure missing')
        config['effective_config']['code_hash']=new_code
        dest.mkdir()
        config_path=dest/'config.json';write(config_path,config)
        old_checkpoint_sha=hashlib.sha256(checkpoint.read_bytes()).hexdigest()
        state=torch.load(checkpoint,map_location='cpu',weights_only=True)
        if state['config_sha256']!=hashlib.sha256(original_config.read_bytes()).hexdigest():
            raise ValueError('source continuation configuration binding differs')
        immutable_payload={k:v for k,v in state.items() if k!='config_sha256'}
        unchanged_hash=state_hash(immutable_payload)
        state['config_sha256']=hashlib.sha256(config_path.read_bytes()).hexdigest()
        torch.save(state,dest/'continuation.pt')
        recovered=torch.load(dest/'continuation.pt',map_location='cpu',weights_only=True)
        if state_hash({k:v for k,v in recovered.items() if k!='config_sha256'})!=unchanged_hash:
            raise ValueError('recovery changed tensors, optimizer or training histories')
        if hashlib.sha256(checkpoint.read_bytes()).hexdigest()!=old_checkpoint_sha:
            raise ValueError('source checkpoint changed during recovery')
        shutil.copyfile(source/'metrics.json',dest/'metrics.json')
        migrations.append({'run':run,'source_checkpoint':str(checkpoint),'source_checkpoint_sha256':old_checkpoint_sha,
            'source_failure':str(failure),'source_failure_sha256':hashlib.sha256(failure.read_bytes()).hexdigest(),
            'epochs_preserved':len(state['values']),'training_state_semantic_sha256':unchanged_hash,
            'source_config_sha256':hashlib.sha256(original_config.read_bytes()).hexdigest(),
            'recovery_config_sha256':state['config_sha256'],
            'recovery_checkpoint_sha256':hashlib.sha256((dest/'continuation.pt').read_bytes()).hexdigest(),
            'only_checkpoint_metadata_change':'config_sha256','failed_evidence_preserved':True})
    write(ROOT/'records'/CASE/'tune_foundation_group_configs.json',new_configs)
    if sorted(row['epochs_preserved'] for row in migrations)!=[82,83,83]:
        raise ValueError('expected last complete member epochs differ')
    write(ROOT/'records/recovery_preparation_complete.json',{'status':'authenticated_continuation_prepared',
        'parent_root':str(PARENT),'parent_code_hash':OLD_CODE,'recovery_code_hash':new_code,'case':CASE,
        'migrations':migrations,'scientific_protocol_unchanged':True,'old_failure_and_checkpoints_preserved':True,
        'evaluation_values_read':False})
    print(json.dumps({'status':'authenticated_continuation_prepared','case':CASE,
                      'epochs_preserved':[row['epochs_preserved'] for row in migrations],'code_hash':new_code}),flush=True)


if __name__=='__main__':main()
