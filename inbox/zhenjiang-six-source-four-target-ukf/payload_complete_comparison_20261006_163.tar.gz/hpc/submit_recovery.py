"""Submit the single authenticated continuation once, using the school wrapper."""
import hashlib
import json
import pathlib
import re
import subprocess

ROOT=pathlib.Path(__file__).resolve().parents[1]
CASE='explicit_gru__historical_capacity'


def main():
    prep=json.loads((ROOT/'records/recovery_preparation_complete.json').read_text())
    if prep['status']!='authenticated_continuation_prepared':raise ValueError('authenticated preparation missing')
    script=ROOT/'hpc/recover_case.slurm'
    body=f'''#!/usr/bin/env bash
#SBATCH --job-name=zj_gru_history_recovery_261006_001
#SBATCH -p hgpu2p
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --gres=gpu:1
#SBATCH --nodelist=ngu001
#SBATCH --exclude=ngu002
#SBATCH --time=0
#SBATCH --output={ROOT}/logs/%x_%j.out
set -eo pipefail
source /data1/home/sunyiq/miniconda3/etc/profile.d/conda.sh
conda activate nh_final
set -u
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=4
export MKL_NUM_THREADS=4
export OPENBLAS_NUM_THREADS=4
export CUBLAS_WORKSPACE_CONFIG=:4096:8
cd {ROOT}
python -B -u hpc/gpu_recovery_acceptance.py
python -B -u scripts/train_supercomputer_case.py --case {CASE}
'''
    output=next(line.split('=',1)[1] for line in body.splitlines() if line.startswith('#SBATCH --output='))
    directory=next(line[3:] for line in body.splitlines() if line.startswith('cd '))
    if pathlib.Path(output).parent!=ROOT/'logs' or pathlib.Path(directory)!=ROOT:
        raise ValueError('recovery scheduler paths escape the isolated root')
    with script.open('x') as stream:stream.write(body)
    with (ROOT/'records/recovery_submission_attempt.json').open('x') as stream:
        json.dump({'script':str(script),'sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'status':'reserved'},stream)
    result=subprocess.run(['/usr/local/globle/softs/slurm/19.05.4.1/bin/xbatch',str(script)],capture_output=True,text=True,timeout=60)
    with (ROOT/'records/recovery_submission_response.json').open('x') as stream:
        json.dump({'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr},stream,indent=2)
    matched=re.fullmatch(r'Submitted batch job ([0-9]+)\s*',result.stdout)
    if result.returncode or not matched:raise RuntimeError('submission uncertain; inspect evidence without repeating')
    with (ROOT/'records/scheduler_jobs.json').open('x') as stream:json.dump({CASE:matched.group(1)},stream,indent=2)
    print(json.dumps({'status':'recovery_job_submitted','case':CASE,'job_id':matched.group(1),'root':str(ROOT)}),flush=True)


if __name__=='__main__':main()
