"""Seal code/tests/protected-file evidence; uses synthetic arithmetic only.

Usage: python -B scripts/record_acceptance.py --junit records/all_tests_final.xml
Output records/acceptance.json, records/numerical_evidence.json and package-manifest.json.
"""
import argparse
import ast
import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path
import sys
from _entry import ROOT,read_json,write_json

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--junit',required=True)
    p.add_argument('--steps',required=True,help='fresh pytest session receipt including actual device checks')
    args=p.parse_args()
    xml=ET.parse(args.junit); suites=list(xml.getroot().iter('testsuite'))
    summary={k:sum(int(s.attrib.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')}
    if summary['failures'] or summary['errors'] or summary['skipped']: raise ValueError('complete green suite required')
    steps=read_json(args.steps)
    if steps['exit_status']!=0 or steps['tests_collected']!=summary['tests']:
        raise ValueError('test process receipt and full suite disagree')
    if any(steps[k]!=0 for k in ('formal_training_steps','real_data_optimizer_steps','raw_evaluation_year_reads','paid_submissions')):
        raise ValueError('repair authorization boundary exceeded')
    gpu=steps.get('actual_gpu_checks',[])
    if len(gpu)!=4 or any(not r['formal_constructor_used'] or r['peak_allocated_bytes']/r['device_identity']['total_memory_bytes']>.8 for r in gpu):
        raise ValueError('all four complete-state GPU constructor checks required for this host acceptance')
    lineage=read_json(ROOT/'records/lineage.json'); parent=Path(lineage['parent'])
    parent_manifest=parent/'package-manifest.json'
    if hashlib.sha256(parent_manifest.read_bytes()).hexdigest()!=lineage['parent_manifest_sha256']:
        raise ValueError('frozen predecessor manifest changed')
    parent_files=read_json(parent_manifest)['files']
    for name,expected in parent_files.items():
        if hashlib.sha256((parent/name).read_bytes()).hexdigest()!=expected:
            raise ValueError('frozen predecessor member changed: '+name)
    legacy_xml=ROOT/'prior_acceptance/all_tests_verified.xml'
    legacy={(r.get('classname'),r.get('name')) for r in ET.parse(legacy_xml).getroot().iter('testcase')}
    current={(r.get('classname'),r.get('name')) for r in xml.getroot().iter('testcase')}
    if len(legacy)!=74 or not legacy.issubset(current): raise ValueError('all original 74 test identities must be retained')
    previous=read_json(ROOT/'records/protected_sources_before.json'); after=[]
    for row in previous:
        sha=hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()
        if sha!=row['sha256']: raise ValueError('protected source changed: '+row['path'])
        after.append({'path':row['path'],'sha256':sha})
    write_json(ROOT/'records/protected_sources_after.json',after)
    original=read_json(ROOT/'original_plan/package-manifest.json')
    for name,sha in original['files'].items():
        if hashlib.sha256((ROOT/'original_plan'/name).read_bytes()).hexdigest()!=sha: raise ValueError('original snapshot changed')
    source_files=[*ROOT.joinpath('src').glob('*.py'),*ROOT.joinpath('scripts').glob('*.py')]
    for path in source_files: ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
    from src.scheduler import validate_registry,code_identity
    protocol=read_json(ROOT/'configs/protocol-v3.json'); registry=read_json(ROOT/'configs/registry-v3.json')
    validate_registry(registry,protocol)
    from src.models import make_parts,count_parameters
    from src.contracts import CASES
    import torch
    from src.differentiable_filter import linear_update
    torch.set_num_threads(1)
    h=torch.tensor([[1.]],dtype=torch.float64,requires_grad=True)
    mean,p=linear_update(torch.zeros(1,1,dtype=torch.float64),torch.full((1,1,1),2.,dtype=torch.float64),
        torch.full((1,1),3.,dtype=torch.float64),h,torch.zeros(1,dtype=torch.float64),torch.ones(1,1,dtype=torch.float64))
    mean.square().sum().backward()
    counts={family+'__'+capacity:count_parameters(make_parts(family,capacity,17)) for family,capacity,_,_ in CASES}
    write_json(ROOT/'records/numerical_evidence.json',{'scope':'synthetic arithmetic and instantiated parameter counts only',
        'scalar_posterior_mean':mean.item(),'scalar_posterior_variance':p.item(),'readout_gradient':h.grad.item(),
        'analytic_expected':[2.,2/3,-8/3],'actual_parameter_counts':counts,
        'network_dtype':'float32','covariance_dtype':'float64','scientific_result':False})
    write_json(ROOT/'records/acceptance.json',{'status':'reviewed_next_plan_step_1_repair_and_synthetic_acceptance_passed','date':'2026-10-05',
        'completed_next_plan_step':1,'total_next_plan_steps':6,'test_summary':summary,'original_tests_preserved':74,
        'fresh_junit_sha256':hashlib.sha256(Path(args.junit).read_bytes()).hexdigest(),
        'fresh_steps_sha256':hashlib.sha256(Path(args.steps).read_bytes()).hexdigest(),
        'predecessor_files_verified':len(parent_files),'predecessor_manifest_sha256':lineage['parent_manifest_sha256'],
        'synthetic_optimizer_steps':steps['synthetic_optimizer_steps'],'actual_gpu_checks':gpu,
        'repaired':['explicit_actual_device_and_quote_binding','complete_parent_group_and_checkpoint_binding',
                    'policy_source_selection_reference_and_evaluation_calendar_binding','all_four_diagnostic_types'],
        'logical_registrations':240,'dependency_gates':34,'physical_fit_range':[160,240],
        'original_plan_files_verified':10,'protected_source_files_verified':len(after),'code_hash':code_identity(),
        'python_sources_parsed':len(source_files),'formal_training_steps':0,'real_data_optimizer_steps':0,
        'raw_evaluation_year_reads':0,'old_checkpoint_reads':0,'remote_submissions':0,'scientific_success':'unknown',
        'real_data_admission':'pending','resource_pilot':'not_run','margin_policy':'proposal_not_approved',
        'remaining':['real_data_admission','historical_prediction_value_admission','resources_and_tariff',
                     'margin_policy_choice','formal_training_authority','evaluation_year_authority']})
    files={path.relative_to(ROOT).as_posix():hashlib.sha256(path.read_bytes()).hexdigest()
           for path in sorted(ROOT.rglob('*')) if path.is_file() and path!=ROOT/'package-manifest.json'}
    write_json(ROOT/'package-manifest.json',{'status':'local_code_synthetic_only','code_hash':code_identity(),'files':files})
    print(json.dumps({'tests':summary,'protected_sources':len(after),'files_in_package':len(files),'formal_steps':0}))

if __name__=='__main__': main()
