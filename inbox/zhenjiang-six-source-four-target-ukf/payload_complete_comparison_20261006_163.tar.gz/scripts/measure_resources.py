"""Measure 5 warmup + 30 full optimizer steps on authorized fixed train windows.

Usage: python -B scripts/measure_resources.py --manifest FILE --device cuda
 --output records/resource_measurements_VERSION.json
Quotation alone: --measurements FILE --steps FILE --price-per-hour NUMBER.
No jobs are submitted; pilot weights are discarded and never saved.
"""
from _entry import parser,require_authority,read_json,write_json,main_guard,ROOT

def main():
    p=parser(__doc__); p.add_argument('--manifest'); p.add_argument('--device',choices=['cpu','cuda'],default='cuda')
    p.add_argument('--measurements'); p.add_argument('--steps'); p.add_argument('--price-per-hour',type=float)
    p.add_argument('--overheads',help='five explicitly measured or authorized non-training cost ceilings')
    p.add_argument('--output',default=str(ROOT/'records/resource_measurements_v3.json')); args=p.parse_args()
    if args.measurements:
        if not args.steps or args.price_per_hour is None or not args.overheads:
            raise ValueError('full-calendar step counts, device tariff and non-training costs required')
        from src.scheduler import quote_measured_resources
        write_json(args.output,quote_measured_resources(read_json(args.measurements),read_json(args.steps),
                   args.price_per_hour,read_json(args.overheads)))
        return
    protocol,sha=require_authority(args,'real_data_pilot')
    if not args.manifest: raise ValueError('authorized fixed sample manifest required')
    import time
    import torch
    from dataclasses import fields
    from src.contracts import ModelBatch,combine_batches,CASES
    from src.runtime import load_stage,fit_stage_stats,prepare_windows,batches
    from src.models import make_parts
    from src.state_estimators import make_branches,configure_branch
    from src.differentiable_filter import make_noise,fit_whitening
    from src.training import make_optimizer,train_effective_batch,deterministic_runtime,validation_mae,snapshot_parts
    from src.execution import device_identity,move_parts,move_batch
    import tempfile
    import os
    manifest=read_json(args.manifest); stage=load_stage(manifest,'final_train'); stats=fit_stage_stats(stage,manifest)
    windows,_=prepare_windows(stage,stats)
    selection,_=prepare_windows(load_stage(manifest,'final_select'),stats)
    if len(windows)<16: raise ValueError('16 fixed approved windows required')
    batch=combine_batches(windows[:16])
    batch=move_batch(batch,args.device)
    deterministic_runtime(); measured={}
    if args.device=='cuda' and not torch.cuda.is_available(): raise ValueError('requested GPU unavailable')
    for family,capacity,w,d in CASES:
        base=make_parts(family,capacity,101)
        move_parts(base,None,None,args.device)
        wh=fit_whitening(base,[batch])
        for method in ('foundation',*protocol['method_order']):
            parts=base if method=='foundation' else make_branches(base,100101)[method]
            noise=make_noise(d) if method.startswith('filter') else None
            wh=move_parts(parts,noise,wh,args.device)
            if method!='foundation': configure_branch(parts,noise,method)
            optimizer=make_optimizer(parts,noise,.001)
            durations=[]
            if args.device=='cuda': torch.cuda.reset_peak_memory_stats()
            for step in range(35):
                if args.device=='cuda': torch.cuda.synchronize()
                start=time.perf_counter()
                train_effective_batch(parts,noise,wh,method,batch,stats,optimizer)
                if args.device=='cuda': torch.cuda.synchronize()
                if step>=5: durations.append(time.perf_counter()-start)
            if args.device=='cuda': torch.cuda.synchronize()
            start=time.perf_counter(); validation_mae(parts,noise,wh,method,batches(selection),stats)
            if args.device=='cuda': torch.cuda.synchronize()
            validation_seconds=time.perf_counter()-start
            from pathlib import Path
            scratch=Path(args.output).resolve().parent; scratch.mkdir(parents=True,exist_ok=True)
            descriptor,checkpoint_path=tempfile.mkstemp(prefix='discarded_resource_pilot_',suffix='.pt',dir=scratch)
            os.close(descriptor)
            try:
                start=time.perf_counter()
                torch.save(snapshot_parts(parts,noise),checkpoint_path)
                with open(checkpoint_path,'rb+') as handle: os.fsync(handle.fileno())
                save_seconds=time.perf_counter()-start
                disk_bytes=Path(checkpoint_path).stat().st_size
            finally:
                os.unlink(checkpoint_path)
            peak=torch.cuda.max_memory_allocated() if args.device=='cuda' else None
            total=torch.cuda.get_device_properties(0).total_memory if args.device=='cuda' else None
            fraction=peak/total if total else 0.
            category=family+'__'+capacity+'/'+method
            measured[category]={'warmup_steps':5,'measurement_steps':30,'seconds_per_step':max(durations),
                'step_seconds':durations,'validation_seconds_per_epoch':validation_seconds,
                'validation_scope':'complete_selection_calendar','validation_windows':len(selection),
                'save_seconds_per_epoch':save_seconds,'save_scope':'actual_disk_checkpoint','disk_save_bytes':disk_bytes,
                'peak_memory_bytes':peak,'device_memory_bytes':total,
                'memory_fraction':fraction,'device':args.device,'device_identity':device_identity(args.device),
                'pilot_weights_saved':False,'real_training_fits':0}
            if fraction>.8:
                write_json(args.output,{'status':'failed_memory_admission','failed_category':category,'measurements':measured})
                raise ValueError('GPU peak memory exceeds 80%; complete configuration cannot run')
    write_json(args.output,{'status':'measurements_only_requires_calendar_step_counts_and_tariff',
        'protocol_sha256':sha,'measurements':measured,'pilot_weights_saved':False,
        'next_required':['maximum_steps_per_epoch','device_price_per_hour','non_training_cost_ceilings']})

if __name__=='__main__': main_guard(main)
