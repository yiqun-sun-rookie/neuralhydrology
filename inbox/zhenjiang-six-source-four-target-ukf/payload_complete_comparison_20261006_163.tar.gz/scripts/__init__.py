"""Permission-gated command line entry points."""
