"""Execute a complete authorized physical budget group, never a partial grid.

Usage: python -B scripts/run_registered.py --group CASE__tune_foundation_group
 --registry FILE --configs FILE --manifest FILE --seals FILE --output-root runs
Defaults have no formal-training authority and reject before model/data imports.
"""
from _entry import parser,require_authority,require_status,read_json,write_json,main_guard,ROOT

def main():
    p=parser(__doc__); p.add_argument('--group'); p.add_argument('--registry',default=str(ROOT/'configs/registry-v3.json'))
    p.add_argument('--configs'); p.add_argument('--manifest'); p.add_argument('--seals')
    p.add_argument('--resource-quote',default=str(ROOT/'records/resource_quote.json'))
    p.add_argument('--margin-policy',default=str(ROOT/'records/margin_policy.json'))
    p.add_argument('--output-root',default=str(ROOT/'runs')); p.add_argument('--receipt'); args=p.parse_args()
    protocol,sha=require_authority(args,'formal_training')
    quote=require_status(args.resource_quote,{'sealed_success'}); policy=require_status(args.margin_policy,{'frozen_approved'})
    auth=read_json(args.authority)
    limit=auth.get('maximum_cost')
    if limit is None or quote.get('cost_upper') is None or quote['cost_upper']>limit:
        raise PermissionError('specific resource cost ceiling not authorized')
    if not all((args.group,args.configs,args.manifest,args.seals)): raise ValueError('complete group inputs required')
    registry=read_json(args.registry)
    if registry['protocol_sha256']!=sha: raise ValueError('registry protocol differs')
    from src.scheduler import validate_registry,ready,verify_parent_binding,digest_json,code_identity
    from src.execution import bind_authorized_device
    from src.sealing import manifest_identity,validate_policy
    from src.contracts import GroupSeal
    validate_registry(registry,protocol)
    validate_policy(policy)
    if quote.get('protocol_sha256')!=sha: raise ValueError('resource quote protocol differs')
    evidence=read_json(args.seals)
    seals={k:GroupSeal(**v) for k,v in evidence['seals'].items()}
    members=[r for r in registry['runs'] if r['budget_group']==args.group and r['status']!='alias']
    if not members or any(not ready(r,set(evidence['completed_run_ids']),seals,evidence.get('external_evidence',{})) for r in members):
        raise PermissionError('complete dependency seals missing or stale')
    configs=read_json(args.configs)
    if any(configs[r['exp_id']].get('status')!='frozen_authorized' or configs[r['exp_id']]['protocol_sha256']!=sha for r in members):
        raise PermissionError('resolved frozen configs required')
    ceiling=quote.get('group_seconds_upper',{}).get(args.group)
    if ceiling is None or any(configs[r['exp_id']]['effective_config'].get('group_wall_seconds_limit')!=ceiling for r in members):
        raise PermissionError('whole-group wall-time ceiling not bound to resource quote')
    manifest=read_json(args.manifest)
    bindings={'resource_quote_sha256':digest_json(quote),'margin_policy_sha256':digest_json(policy),
              'data_manifest_sha256':manifest_identity(manifest),'code_hash':code_identity()}
    if any(auth.get(k)!=v for k,v in bindings.items()):
        raise PermissionError('training authority does not bind the frozen quote, policy, data and code')
    external=evidence.get('external_evidence',{})
    for run in members:
        if not ready(run,set(evidence['completed_run_ids']),seals,external):
            raise PermissionError('complete dependency seals or external admission missing')
        effective=configs[run['exp_id']]['effective_config']
        bind_authorized_device(effective,quote,auth)
        verify_parent_binding(run,effective,seals)
        for dep,expected in run.get('dependency_members',{}).items():
            if expected==[] and any(external[dep].get(k)!=v for k,v in {'protocol_sha256':sha,**bindings}.items()):
                raise PermissionError('external admission evidence belongs to different execution inputs')
    from src.runtime import execute_group
    result=execute_group(args.group,registry,protocol,configs,manifest,args.output_root,seals)
    write_json(args.receipt or ROOT/'records'/('group_'+args.group+'.json'),result)

if __name__=='__main__': main_guard(main)
