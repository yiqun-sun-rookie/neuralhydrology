"""Resolve one dependency-ready group without inventing future parent weights.

Usage: python -B scripts/resolve_group.py --group CASE__tune_foundation_group
 --registry FILE --identities FILE --rates FILE --seals FILE --resource-quote FILE
 --output NEW_FILE. Inputs are admitted per-run identities and already selected
 case/method rates. This writes configurations only; no data or model is opened.
"""
from _entry import parser,require_authority,require_status,read_json,write_json,main_guard,ROOT


def main():
    p=parser(__doc__)
    p.add_argument('--group'); p.add_argument('--registry',default=str(ROOT/'configs/registry-v3.json'))
    for flag in ('identities','rates','seals','resource-quote','output'): p.add_argument('--'+flag)
    args=p.parse_args(); protocol,sha=require_authority(args,'formal_training')
    if not all((args.group,args.identities,args.rates,args.seals,args.resource_quote,args.output)):
        raise ValueError('complete group, admitted identities, rates, dependency evidence and quote required')
    from src.scheduler import validate_registry,ready,resolve_effective_config,verify_parent_binding
    from src.contracts import GroupSeal
    from src.execution import device_identity,bind_authorized_device
    registry=read_json(args.registry); validate_registry(registry,protocol)
    if registry['protocol_sha256']!=sha: raise ValueError('registry protocol differs')
    auth=read_json(args.authority); quote=require_status(args.resource_quote,{'sealed_success'})
    if quote.get('protocol_sha256')!=sha: raise ValueError('resource quote protocol differs')
    evidence=read_json(args.seals); seals={k:GroupSeal(**v) for k,v in evidence['seals'].items()}
    members=[r for r in registry['runs'] if r['budget_group']==args.group and r['status']!='alias']
    if not members or any(not ready(r,set(evidence['completed_run_ids']),seals,evidence.get('external_evidence',{})) for r in members):
        raise PermissionError('group dependencies incomplete; later configurations cannot be resolved yet')
    identities=read_json(args.identities); rates=read_json(args.rates); result={}
    if set(identities)!={r['exp_id'] for r in members}: raise ValueError('exact physical group identity map required')
    ceiling=quote.get('group_seconds_upper',{}).get(args.group)
    if ceiling is None or ceiling<=0: raise ValueError('specific whole-group resource ceiling required')
    device=auth.get('device_identity',{}).get('device')
    if not device: raise PermissionError('specific authorized device identity required')
    for run in members:
        rate=run.get('learning_rate') or (.001 if run['type']=='controlled' else rates[run['case']+'/'+run['method']])
        identity=identities[run['exp_id']]
        if run['method']=='foundation' and any(identity.get(k) is not None for k in
            ('parent_hash','parent_run_id','parent_checkpoint','initializer_hash','analysis_initialization_hash','whitening_hash')):
            raise ValueError('fresh foundation must explicitly have no inherited weights or statistics')
        effective=resolve_effective_config(run,protocol,rate,identity)
        effective.update(device=device,device_identity=device_identity(device),group_wall_seconds_limit=ceiling)
        bind_authorized_device(effective,quote,auth)
        verify_parent_binding(run,effective,seals)
        result[run['exp_id']]={'status':'frozen_authorized','protocol_sha256':sha,'registration':run,'effective_config':effective}
    write_json(args.output,result)


if __name__=='__main__': main_guard(main)
