"""Standard-library-only guards run BEFORE importing any model or data loader."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def write_json(path,value):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists(): raise FileExistsError('preserve existing evidence: '+str(p))
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')

def parser(description):
    p=argparse.ArgumentParser(description=description)
    p.add_argument('--protocol',type=Path,default=ROOT/'configs/protocol-v3.json')
    p.add_argument('--authority',type=Path,default=ROOT/'records/authorization.json')
    return p

def require_authority(args,action):
    auth=read_json(args.authority)
    if not auth.get('authority',{}).get(action,False):
        raise PermissionError('explicit authorization missing for '+action)
    sha=hashlib.sha256(args.protocol.read_bytes()).hexdigest()
    if auth.get('protocol_sha256')!=sha:
        raise PermissionError('authorization protocol digest differs')
    return read_json(args.protocol),sha

def require_status(path,accepted):
    record=read_json(path)
    if record.get('status') not in accepted:
        raise PermissionError('evidence not sealed/admitted: '+str(path))
    return record

def main_guard(function):
    try:
        function()
    except (OSError,ValueError,KeyError,RuntimeError) as error:
        print(json.dumps({'status':'rejected','reason':str(error),
                         'model_module_imported':'src.models' in sys.modules},ensure_ascii=False))
        raise SystemExit(2)
