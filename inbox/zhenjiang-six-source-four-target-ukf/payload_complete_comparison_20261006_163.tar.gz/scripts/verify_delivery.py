"""Independent standard-library reconstruction of the repair delivery's evidence.

Usage: python -B scripts/verify_delivery.py [--output OUTSIDE_PACKAGE_NEW_JSON]
No training imports, raw series reads or model checkpoint loads are performed.
The optional report stays outside the package to preserve its frozen manifest.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
from _entry import ROOT,read_json,write_json,main_guard


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--output',type=Path); args=p.parse_args()
    manifest=read_json(ROOT/'package-manifest.json')
    actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p!=ROOT/'package-manifest.json'}
    if actual!=set(manifest['files']): raise ValueError('new delivery membership differs from manifest')
    for name,expected in manifest['files'].items():
        if sha(ROOT/name)!=expected: raise ValueError('new delivery member changed: '+name)
    acceptance=read_json(ROOT/'records/acceptance.json'); lineage=read_json(ROOT/'records/lineage.json')
    parent=Path(lineage['parent']); old=read_json(parent/'package-manifest.json')
    if sha(parent/'package-manifest.json')!=lineage['parent_manifest_sha256']: raise ValueError('predecessor manifest changed')
    for name,expected in old['files'].items():
        if sha(parent/name)!=expected: raise ValueError('predecessor changed: '+name)
    original=read_json(ROOT/'original_plan/package-manifest.json')
    for name,expected in original['files'].items():
        if sha(ROOT/'original_plan'/name)!=expected: raise ValueError('scientific plan snapshot changed')
    protected=read_json(ROOT/'records/protected_sources_before.json')
    for row in protected:
        if sha(row['path'])!=row['sha256']: raise ValueError('protected source changed: '+row['path'])
    sources=sorted([*ROOT.joinpath('src').glob('*.py'),*ROOT.joinpath('scripts').glob('*.py')])
    for path in [*sources,*ROOT.joinpath('tests').glob('*.py')]:
        ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
    encoded=json.dumps({p.relative_to(ROOT).as_posix():sha(p) for p in sources},sort_keys=True,separators=(',',':')).encode()
    if hashlib.sha256(encoded).hexdigest()!=manifest['code_hash'] or manifest['code_hash']!=acceptance['code_hash']:
        raise ValueError('independently reconstructed code identity differs')
    authority=read_json(ROOT/'records/authorization.json')['authority']
    if any(authority.get(k,False) for k in ('formal_training','real_data_pilot','evaluation_year_reads','data_admission','remote_execution')):
        raise ValueError('unapproved real execution authority present')
    blueprints=[p for p in ROOT.joinpath('configs').glob('*.json') if p.name not in ('protocol-v3.json','registry-v3.json')]
    if len(blueprints)!=240 or any(read_json(p).get('effective_config') is not None for p in blueprints):
        raise ValueError('synthetic fixtures contaminated formal blueprints')
    if any(list(ROOT.joinpath(n).iterdir()) for n in ('runs','predictions')):
        raise ValueError('formal output directories must remain empty')
    record={'status':'independently_reconstructed_pass','new_manifest_sha256':sha(ROOT/'package-manifest.json'),
        'new_files_verified':len(manifest['files']),'predecessor_files_verified':len(old['files']),
        'scientific_plan_files_verified':len(original['files']),'protected_sources_verified':len(protected),
        'code_hash':manifest['code_hash'],'test_summary':acceptance['test_summary'],'formal_blueprints_unresolved':240,
        'completed_next_plan_step':1,'science_or_formal_training_claim':False}
    if args.output:
        if ROOT==args.output.resolve() or ROOT in args.output.resolve().parents: raise ValueError('verification report must be outside frozen package')
        write_json(args.output,record)
    print(json.dumps(record,ensure_ascii=False))


if __name__=='__main__': main_guard(main)
