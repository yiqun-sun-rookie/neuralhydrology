"""Generate an evidence checklist or verify explicitly authorized data admission.

Usage: python -B scripts/admit_data.py --template --output records/data_requirements.json
Real verification: --manifest FILE --phase tuning_train, after separate authority.
"""
from _entry import parser,require_authority,write_json,read_json,main_guard,ROOT

def main():
    p=parser(__doc__); p.add_argument('--template',action='store_true')
    p.add_argument('--manifest'); p.add_argument('--phase',default='tuning_train')
    p.add_argument('--output',default=str(ROOT/'records/data_requirements.json')); args=p.parse_args()
    if args.template:
        write_json(args.output,{'status':'requirements_only','raw_reads':0,'units':'m','timestamp_rule':'whole_hour',
            'required_roles':['realtime_inputs','qc_labels','astronomical_tide'],
            'required_file_fields':['path','role','years','phases','sha256','station_order','datum','provider','available_at_evidence'],
            'training_years_tuning':[2017,2018,2019,2020],'training_years_final':[2017,2018,2019,2020,2021],
            'selection_years':[2021,2022],'evaluation_years_restricted':[2023,2024],
            'mixed_files':'provider-approved isolated year files before model reads',
            'historical_joint_reference_seeds_epochs':[[17,100],[29,97],[43,96]],
            'historical_specialist_reference_seeds_epochs':[[17,65],[29,67],[43,51]],
            'historical_required':'complete 23-lead predictions, common labels, original calendars, training thresholds, configs and choice receipts',
            'business_claim_requires':'provider evidence of datum, timezone, clock rule and actual arrival times'})
        return
    require_authority(args,'data_admission')
    if not args.manifest: raise ValueError('manifest required')
    from src.runtime import load_stage
    manifest=read_json(args.manifest); stage=load_stage(manifest,args.phase)
    write_json(args.output,{'status':'verified_data_calendar','phase':args.phase,'eligible_windows':len(stage['eligible']),
                           'excluded':stage['excluded'],'business_validated':bool(manifest.get('business_time_availability_certified',False))})

if __name__=='__main__': main_guard(main)
