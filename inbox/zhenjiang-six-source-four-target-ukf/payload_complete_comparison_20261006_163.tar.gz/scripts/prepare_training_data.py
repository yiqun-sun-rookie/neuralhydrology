"""Prepare isolated 2017--2022 supercomputer data and two fresh tide fits.

Usage: python -B scripts/prepare_training_data.py
Reads only the exact previously isolated training files listed in the source
contract. Produces per-year, per-role NPZ files and admitted manifests.
Never opens original mixed-year sources, historical predictions or old weights.
"""
from _entry import ROOT,read_json,write_json
from datetime import datetime,timedelta
import hashlib
import io
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from src.contracts import CHANNELS,TARGETS
from src.scheduler import digest_json,code_identity
from src.runtime import load_stage,fit_stage_stats,stats_record
from src.sealing import calendar_snapshot

SOURCE=Path('/data1/home/sunyiq/zhenjiang_5s5t_stage_a_20260905_recovery_001/inputs/2017_2022')
REFERENCE=datetime(2016,12,31,16)

def validate_csv(raw,role):
    frame=pd.read_csv(io.BytesIO(raw),encoding='utf-8-sig')
    value_key='STAGE' if role=='realtime_stage' else 'TARGET_STAGE'
    flag='is_missing_for_model' if role=='realtime_stage' else 'is_missing_for_target'
    for key in ('TIME','time_beijing','time_utc',value_key,flag):
        if key not in frame: raise ValueError('source schema missing '+key)
    parsed=pd.to_datetime(frame['TIME'],errors='raise')
    timezone=getattr(parsed.dt,'tz',None)
    if timezone is not None:
        # NumPy converts a timezone-aware series to UTC. The model calendar is
        # explicitly Beijing wall-clock hours; retain that convention first.
        times=parsed.dt.tz_convert('Asia/Shanghai').dt.tz_localize(None).to_numpy(dtype='datetime64[ns]')
    else:
        times=parsed.to_numpy(dtype='datetime64[ns]')
    expected=np.arange(np.datetime64('2017-01-01T00','h'),np.datetime64('2023-01-01T00','h'),
                       np.timedelta64(1,'h')).astype('datetime64[ns]')
    if not np.array_equal(times,expected): raise ValueError('isolated source calendar changed')
    beijing=pd.to_datetime(frame['time_beijing'],utc=True,errors='raise').to_numpy(dtype='datetime64[ns]')
    utc=pd.to_datetime(frame['time_utc'],utc=True,errors='raise').to_numpy(dtype='datetime64[ns]')
    if not np.array_equal(beijing,utc) or not np.array_equal(utc,times-np.timedelta64(8,'h')):
        raise ValueError('Beijing and UTC clocks disagree')
    if timezone is not None and not np.array_equal(parsed.dt.tz_convert('UTC').to_numpy(dtype='datetime64[ns]'),utc):
        raise ValueError('explicit TIME instant differs from paired UTC source')
    flags=frame[flag].astype(str).str.lower()
    if not flags.isin(['0','1','true','false','0.0','1.0']).all():
        raise ValueError('unknown missing flags')
    missing=flags.isin(['1','true','1.0']).to_numpy()
    values=pd.to_numeric(frame[value_key],errors='raise').to_numpy(dtype=np.float64)
    if np.isinf(values).any() or not np.array_equal(~np.isfinite(values),missing):
        raise ValueError('source missing flag and values disagree')
    return times,values

def fixed_tide(model,times):
    from tide import Tide
    hours=(times.astype('datetime64[h]')-np.datetime64('2017-01-01T00','h')).astype(np.int64)
    speed,_,_,equilibrium=model.prepare(REFERENCE,[REFERENCE],radians=True)
    chunks=hours//240
    result=np.empty(len(times),np.float64)
    for index in np.unique(chunks):
        positions=np.flatnonzero(chunks==index)
        midpoint=REFERENCE+timedelta(hours=(int(index)+.5)*240)
        _,[node_phase],[node_factor],_=model.prepare(REFERENCE,[midpoint],radians=True)
        result[positions]=Tide._tidal_series(hours[positions],model.model['amplitude'][:,None],
            np.pi/180*model.model['phase'][:,None],speed,node_phase,node_factor,equilibrium)
    if not np.isfinite(result).all(): raise ValueError('tide prediction not finite')
    return result

def fit_tide(times,targets,years):
    from tide import Tide
    actual=times.astype('datetime64[Y]').astype(int)+1970
    selected=np.isin(actual,years)&np.isfinite(targets)
    fitting_times=times[selected]
    if fitting_times[0]!=np.datetime64('2017-01-01T00'): raise ValueError('fixed tide reference unavailable')
    utc=[pd.Timestamp(t).to_pydatetime()-timedelta(hours=8) for t in fitting_times]
    model,solver=Tide.decompose(targets[selected],utc,full_output=True)
    parameters,covariance,info,message,status=solver
    if status not in (1,2,3,4) or not np.isfinite(parameters).all() or not np.isfinite(info['fvec']).all():
        raise ValueError('fresh astronomical fit failed')
    doc={'training_years':years,'training_count':int(selected.sum()),'solver_status':int(status),
         'training_times_sha256':hashlib.sha256(fitting_times.tobytes()).hexdigest(),
         'training_values_sha256':hashlib.sha256(targets[selected].astype('<f8').tobytes()).hexdigest(),
         'reference_utc':'2016-12-31T16:00:00','absolute_chunk_hours':240,
         'constituents':[{'name':r['constituent'].name,'amplitude_m':float(r['amplitude']),
                          'phase_degrees':float(r['phase'])} for r in model.model],
         'solver_evaluations':int(info['nfev']),'training_residual_sum_squares_m2':float(np.dot(info['fvec'],info['fvec']))}
    return model,doc

def main():
    protocol=read_json(ROOT/'configs/protocol-v3.json'); auth=read_json(ROOT/'records/authorization.json')
    if not auth['authority'].get('real_data_preparation') or auth['protocol_sha256']!=hashlib.sha256((ROOT/'configs/protocol-v3.json').read_bytes()).hexdigest():
        raise PermissionError('training preparation not authorized')
    if auth['code_hash']!=code_identity(): raise ValueError('released implementation changed')
    destination=ROOT/'prepared'
    destination.mkdir(exist_ok=False)
    contract=read_json(ROOT/'configs/source_training_contract.json')
    arrays={}; ledger=[]; calendar=None
    for entry in contract['files']:
        if entry['role'] not in ('realtime_stage','retrospective_target'): continue
        path=Path(entry['path'])
        if path.parent.parent!=SOURCE or path.is_symlink() or SOURCE.resolve() not in path.resolve().parents:
            raise PermissionError('source path outside exact isolated training directory')
        raw=path.read_bytes()
        if len(raw)!=entry['byte_count'] or hashlib.sha256(raw).hexdigest()!=entry['content_sha256']:
            raise ValueError('isolated training source identity changed: '+entry['station'])
        times,values=validate_csv(raw,entry['role'])
        if calendar is not None and not np.array_equal(calendar,times): raise ValueError('source clocks differ')
        calendar=times; arrays[(entry['role'],entry['station'])]=values
        ledger.append({'path':str(path),'role':entry['role'],'station':entry['station'],
                       'sha256':entry['content_sha256'],'rows':len(times),'missing_hours':int(np.isnan(values).sum())})
    if len(arrays)!=11: raise ValueError('all eleven isolated source files required')
    print(json.dumps({'status':'eleven_training_sources_verified','years':[2017,2018,2019,2020,2021,2022],
                      'rows_per_source':len(calendar),'evaluation_values_read':False}),flush=True)
    sys.path.insert(0,str(ROOT/'vendor/pytides'))
    reports={}
    for split,years in (('tuning',[2017,2018,2019,2020]),('final',[2017,2018,2019,2020,2021])):
        out=destination/split; out.mkdir()
        print(json.dumps({'status':'fitting_fresh_astronomical_tide','split':split,'training_years':years}),flush=True)
        model,tide_doc=fit_tide(calendar,arrays[('retrospective_target','wusongkou')],years)
        write_json(out/'tide_fit.json',tide_doc)
        tide=fixed_tide(model,calendar)
        history=np.column_stack([arrays[('realtime_stage',s)] for s in CHANNELS[:-1]]+[tide])
        labels=np.column_stack([arrays[('retrospective_target',s)] for s in TARGETS])
        manifest={'status':'admitted','units':'m','timezone':'Asia/Shanghai','timestamp_rule':'whole_hour',
            'tide_training_years':years,'tide_source_hash':digest_json(tide_doc),'evaluation_year_reads':False,
            'business_time_availability_certified':False,'approved_roots':[str(out)],'forbidden_roots':[],
            'source_contract_sha256':hashlib.sha256((ROOT/'configs/source_training_contract.json').read_bytes()).hexdigest(),
            'source_read_ledger_sha256':digest_json(ledger),'files':[]}
        needed=years+[protocol['splits'][split]['select'][0]]
        year_values=calendar.astype('datetime64[Y]').astype(int)+1970
        for year in needed:
            selection=year_values==year
            phase=split+('_train' if year in years else '_select')
            for role,key,value,order in (('realtime_inputs','history_m',history,list(CHANNELS)),
                ('qc_labels','labels_m',labels,list(TARGETS)),('astronomical_tide','tide_m',tide,['astronomical_tide'])):
                path=out/(str(year)+'_'+role+'.npz')
                np.savez(path,times=calendar[selection],**{key:value[selection]})
                manifest['files'].append({'path':str(path),'years':[year],'role':role,'phases':[phase],
                    'station_order':order,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                    'datum':'station_specific_gauge_datum_unverified_no_cross_station_unification',
                    'provider':'water_level_model_input_v7_beijing_realtime_verified'})
        write_json(out/'manifest.json',manifest)
        stages={phase:load_stage(manifest,phase) for phase in (split+'_train',split+'_select')}
        stats=fit_stage_stats(stages[split+'_train'],manifest)
        report={'manifest_sha256':digest_json(manifest),'statistics':stats_record(stats),
            'calendars':{phase:calendar_snapshot(stage,phase) for phase,stage in stages.items()},
            'eligible_windows':{phase:len(stage['eligible']) for phase,stage in stages.items()},
            'tide_source_hash':manifest['tide_source_hash'],'evaluation_values_read':False}
        if any(n==0 for n in report['eligible_windows'].values()): raise ValueError('empty admitted calendar')
        write_json(out/'admission.json',report); reports[split]=report
        print(json.dumps({'split':split,'eligible_windows':report['eligible_windows'],'tide_training_years':years}),flush=True)
    write_json(ROOT/'records/source_read_ledger.json',ledger)
    write_json(ROOT/'records/data_preparation_complete.json',{'status':'admitted','reports':reports,
               'source_files':11,'evaluation_values_read':False,'fresh_tide_fits':2,'code_hash':code_identity()})

if __name__=='__main__': main()
