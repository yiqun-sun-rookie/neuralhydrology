"""Inventory existing JSON ledgers only; never open CSV/NPY/checkpoint values.

Usage: python -B scripts/prepare_next_step.py
Outputs concrete data-source and historical-prediction requirements in records/.
"""
import hashlib
import json
from pathlib import Path
from _entry import ROOT,write_json

def read_metadata(path):
    raw=Path(path).read_bytes()
    return json.loads(raw),hashlib.sha256(raw).hexdigest()

def main():
    projects=Path('G:/github/pycharm/projects')
    ledger_path=projects/'zhenjiang_process_highwater_loss_20260928_002/reports/reference_asset_read_ledger.json'
    ledger,sha=read_metadata(ledger_path)
    sources=[{'station':r['station'],'role':r['role'],'original_source':r['source'],
        'source_exists':Path(r['source']).is_file(),'old_source_sha256':r['source_sha256'],
        'old_selected_2017_2022_sha256':r['selected_sha256'],
        'old_full_byte_scan_includes_later_years':r['byte_scan_includes_later_year_rows'],
        'current_raw_source_hash_verified':False} for r in ledger]
    write_json(ROOT/'records/data_source_inventory.json',{'status':'metadata_inventory_only','ledger_path':str(ledger_path),
        'ledger_sha256':sha,'sources':sources,'real_raw_csv_reads':0,
        'required_preparation':'approved data preparation must supply isolated single-year files; no mixed-year read in training',
        'prepared_training_source_root_from_old_protocol':'/data1/home/sunyiq/zhenjiang_5s5t_stage_a_20260905_recovery_001/inputs/2017_2022',
        'tide_required_fits':{'tuning':[2017,2018,2019,2020],'final':[2017,2018,2019,2020,2021]}})
    base=projects/'zhenjiang_architecture_sharing_evaluation_20261001_005'
    models,model_sha=read_metadata(base/'models_frozen.json')
    protocol=json.loads((ROOT/'configs/protocol-v3.json').read_text(encoding='utf-8'))
    needed=protocol['historical_benchmark']['runs']+protocol['historical_benchmark']['zhenjiang_protection']['runs']
    records=[]; identities=[]
    for year in (2023,2024):
        index,index_sha=read_metadata(base/'evaluation'/str(year)/'index.json')
        identities.append({'path':str(base/'evaluation'/str(year)/'index.json'),'sha256':index_sha})
        for run in needed:
            matched=[m for m in models['models'] if m['run']['exp_id']==run['run']]
            if len(matched)!=1: raise ValueError('historical run not uniquely bound')
            m=matched[0]; checkpoint=m['choices']['common_selected']
            if m['choice_epochs']['common_selected']!=run['epoch']: raise ValueError('historical choice changed')
            p=index['predictions'][m['source']+'/'+checkpoint['relative_path']]
            if p['source_weight_sha256']!=checkpoint['sha256'] or p['epoch']!=run['epoch'] or p['array']['shape'][1]!=23:
                raise ValueError('historical metadata binding differs')
            records.append({'year':year,'run':run['run'],'seed':run['seed'],'epoch':run['epoch'],
                'prediction_path':str(base/p['array']['relative_path']),'prediction_sha256_in_old_index':p['array']['sha256'],
                'shape':p['array']['shape'],'old_weight_sha256':checkpoint['sha256'],
                'common_arrays':index['arrays'],'prediction_values_read':False,'weight_values_read':False,
                'value_admission_status':'pending_authorized_values_and_common_labels'})
    write_json(ROOT/'records/historical_prediction_metadata.json',{'status':'metadata_bound_not_value_admitted',
        'models_frozen_sha256':model_sha,'index_identities':identities,'entries':records,
        'required_old_prediction_files':12,'raw_evaluation_values_read':0,'old_checkpoints_read':0})
    print(json.dumps({'source_files_identified':len(sources),'historical_prediction_files_bound':len(records),
                      'raw_series_reads':0,'prediction_array_reads':0}))

if __name__=='__main__': main()
