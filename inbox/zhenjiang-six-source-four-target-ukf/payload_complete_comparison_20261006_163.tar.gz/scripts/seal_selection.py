"""Seal a single candidate using complete primary 2022 validation evidence.

Usage: python -B scripts/seal_selection.py --validation FILE --evidence FILE
 --output records/selection_lock_v3.json; no evaluation data are read.
"""
from _entry import parser,require_authority,require_status,read_json,write_json,main_guard,ROOT

def main():
    p=parser(__doc__); p.add_argument('--validation'); p.add_argument('--evidence')
    for flag in ('models','manifest','references','margin-policy','calendar-contract'):
        p.add_argument('--'+flag)
    p.add_argument('--output',default=str(ROOT/'records/selection_lock_v3.json')); args=p.parse_args()
    protocol,sha=require_authority(args,'formal_training')
    if not all((args.validation,args.evidence,args.models,args.manifest,args.references,args.margin_policy,args.calendar_contract)):
        raise ValueError('validation, complete outcomes, models, evaluation source identities, policy and distinct calendars required')
    evidence=require_status(args.evidence,{'all_final_groups_sealed'})
    from src.scoring import choose_candidate
    from src.scheduler import digest_json
    from src.sealing import selection_bindings,validate_model_collection
    if evidence.get('protocol_sha256')!=sha or len(evidence.get('logical_run_results',{}))!=240:
        raise ValueError('all 240 logical outcomes and protocol digest required')
    if not all(evidence.get(k) for k in ('all_checkpoint_hashes','benchmark_manifest_sha256','selection_2022_calendar_sha256','all_choice_hashes')):
        raise ValueError('pre-evaluation evidence chain incomplete')
    outcomes=evidence['logical_run_results']
    registered=read_json(ROOT/'configs/registry-v3.json')
    if set(outcomes)!={r['exp_id'] for r in registered['runs']}:
        raise ValueError('completed logical identities differ from the 240 registered runs')
    if any(r.get('status') not in ('success','alias') for r in outcomes.values()):
        raise ValueError('failed or missing logical outcomes cannot be sealed as complete')
    index=read_json(args.models); rows=read_json(args.validation); contract=read_json(args.calendar_contract)
    refs=read_json(args.references)
    if (digest_json(index)!=evidence['all_checkpoint_hashes'] or digest_json(refs)!=evidence['benchmark_manifest_sha256']
        or digest_json(rows)!=evidence.get('validation_rows_sha256')
        or contract['selection_2022_sha256']!=evidence['selection_2022_calendar_sha256']):
        raise ValueError('model index, reference, validation or 2022 calendar differs from completed evidence')
    items=validate_model_collection(index,protocol,outcomes)
    by_identity={(i['run']['case'],i['run']['method'],i['run']['seed']):outcomes[k]
                 for k,i in items.items() if i['run']['type']=='primary'}
    for row in rows:
        result=by_identity[(row['case'],row['method'],row['seed'])]
        if result.get('selection_calendar_sha256')!=contract['selection_2022_sha256']:
            raise ValueError('2022 selection calendar differs from selected checkpoint receipt')
        if row['mae_cm']!=result['validation_mae'][result['best_epoch']-1]:
            raise ValueError('candidate validation score differs from selected checkpoint receipt')
    bindings=selection_bindings(index,read_json(args.manifest),refs,read_json(args.margin_policy),contract)
    selected=choose_candidate(rows,protocol)
    record={'status':'sealed_success','candidate':selected,'protocol_sha256':sha,'evidence':evidence,'selection_source_year':2022,
            'retrospective_years_already_exposed':[2023,2024],'bindings':bindings}
    record['selection_sha256']=digest_json(record)
    write_json(args.output,record)

if __name__=='__main__': main_guard(main)
