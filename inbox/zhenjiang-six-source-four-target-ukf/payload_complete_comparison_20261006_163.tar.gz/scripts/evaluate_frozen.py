"""Evaluate sealed complete model collections only after evaluation-year authority.

Usage: python -B scripts/evaluate_frozen.py --selection FILE --models FILE
 --manifest FILE --references FILE --margin-policy FILE --output NEW_DIRECTORY
All models and aliases are reported; candidates cannot be selected here.
"""
from _entry import parser,require_authority,require_status,read_json,write_json,main_guard,ROOT

def main():
    p=parser(__doc__); p.add_argument('--selection',default=str(ROOT/'records/selection_lock.json'))
    p.add_argument('--models'); p.add_argument('--manifest'); p.add_argument('--references'); p.add_argument('--margin-policy')
    p.add_argument('--calendar-contract'); p.add_argument('--calendar-lock')
    p.add_argument('--output'); args=p.parse_args()
    protocol,sha=require_authority(args,'evaluation_year_reads')
    selection=require_status(args.selection,{'sealed_success'})
    if selection['protocol_sha256']!=sha: raise ValueError('selection protocol differs')
    if not all((args.models,args.manifest,args.references,args.margin_policy,args.calendar_contract,args.output)):
        raise ValueError('full frozen model and historical collections required')
    from src.scheduler import digest_json,code_identity
    unsigned={k:v for k,v in selection.items() if k!='selection_sha256'}
    if digest_json(unsigned)!=selection['selection_sha256']: raise ValueError('selection seal altered')
    index=read_json(args.models)
    if index.get('code_hash')!=code_identity(): raise ValueError('implementation changed after selection sealing')
    if digest_json(index)!=selection['evidence']['all_checkpoint_hashes']:
        raise ValueError('model index differs from pre-evaluation lock')
    policy=require_status(args.margin_policy,{'frozen_approved'})
    manifest=require_status(args.manifest,{'admitted'})
    refs=require_status(args.references,{'admitted'})
    if digest_json(refs)!=selection['evidence']['benchmark_manifest_sha256']:
        raise ValueError('historical reference admission differs')
    contract=read_json(args.calendar_contract)
    from src.sealing import verify_evaluation_bindings,lock_evaluation_calendars,historical_calendar_identity
    from src.diagnostics import diagnostic_collection,FOUNDATION_DIAGNOSTICS,TRAINED_FILTER_DIAGNOSTIC
    verify_evaluation_bindings(selection,index,manifest,refs,policy,contract,protocol)
    auth=read_json(args.authority)
    if auth.get('selection_sha256')!=selection['selection_sha256']:
        raise PermissionError('evaluation authority belongs to a different model selection seal')
    from pathlib import Path
    import pandas as pd
    import numpy as np
    from src.contracts import TrainingStats
    from src.runtime import load_stage,prepare_windows,prediction_table
    from src.data_contract import allowed_path
    from src.scoring import score_rows,write_prediction_manifest,prediction_cube,event_diagnostics
    from src.evaluation import rows_from_frame,complete_scientific_comparisons,replacement_report
    output=Path(args.output); output.mkdir(parents=True,exist_ok=False)
    stats=TrainingStats(**index['training_stats'])
    if tuple(stats.years)!=(2017,2018,2019,2020,2021): raise ValueError('final training statistics required')
    stages={year:load_stage(manifest,'evaluation_'+str(year)) for year in (2024,2023)}
    locked=lock_evaluation_calendars(selection,manifest,contract,stages,read_json(args.calendar_lock) if args.calendar_lock else None)
    write_json(output/'calendar_lock.json',locked)
    frames={}; scores={}; paths=[]; candidate={}; joint={}; specialist={}; events={}; annual_coverage={}; diagnostic_records={}
    expected_diagnostics=diagnostic_collection(index,protocol)
    for year in (2024,2023):
        stage=stages[year]; windows,times=prepare_windows(stage,stats)
        items={item['run']['exp_id']:item for item in index['models']}
        physical={}; diagnostic_frames={}
        for run_id,item in items.items():
            if item.get('alias_of'): continue
            frame=prediction_table(item['run'],item['config'],item['checkpoint'],windows,times,stats)
            physical[run_id]=frame
            cube,labels,origins,seeds=prediction_cube(rows_from_frame(frame))
            event_rows={}; coverage={}
            for j,station in enumerate(protocol['data']['targets']):
                if np.all(np.diff(stage['times'])==np.timedelta64(1,'h')):
                    event_rows[station]=event_diagnostics(stage['times'],stage['labels_m'][:,j]*100,
                        stats.high_threshold_m[j]*100,origins,cube[0,...,j])
                else:
                    event_rows[station]={'status':'unable_due_missing_hourly_calendar','stable_event_statistics_permitted':False}
                valid_times=origins[:,None]+np.arange(1,24)[None]*np.timedelta64(1,'h')
                covered=len(np.unique(valid_times[labels[...,j]>stats.high_threshold_m[j]*100]))
                denominator=int((stage['labels_m'][:,j]>stats.high_threshold_m[j]).sum())
                fraction=covered/denominator if denominator else None
                coverage[station]={'covered_unique_high_hours':covered,'identifiable_annual_high_hours':denominator,
                    'fraction':fraction,'annual_high_water_claim_permitted':fraction is not None and fraction>=.9}
            events[str((year,run_id))]=event_rows; annual_coverage[str((year,run_id))]=coverage
            path=output/(str(year)+'__'+run_id+'.csv'); frame.to_csv(path,index=False); paths.append(path)
            # The no-observation diagnostic uses the same trained weights and covariance propagation.
            if item['run']['method'].startswith('filter'):
                diagnostic=prediction_table(item['run'],item['config'],item['checkpoint'],windows,times,stats,False)
                diagnostic_frames[(run_id,TRAINED_FILTER_DIAGNOSTIC)]=diagnostic
            if item['run']['method']=='foundation':
                diagnostic_frames[(run_id,'foundation_endpoint')]=frame
                for kind in FOUNDATION_DIAGNOSTICS[1:]:
                    diagnostic_frames[(run_id,kind)]=prediction_table(item['run'],item['config'],item['checkpoint'],
                        windows,times,stats,diagnostic_kind=kind,foundation_whitening=item['whitening'])
        records=[]
        for entry in expected_diagnostics:
            run_id=entry['run_id']; source=items[run_id].get('alias_of',run_id)
            diagnostic=diagnostic_frames[(source,entry['kind'])].copy(); diagnostic['run_id']=run_id
            path=output/(str(year)+'__'+run_id+'__'+entry['kind']+'.csv')
            diagnostic.to_csv(path,index=False); paths.append(path)
            records.append({**entry,'path':str(path),'year':year,'calendar_lock_sha256':locked['calendar_lock_sha256'],
                            'prediction_sha256':__import__('hashlib').sha256(path.read_bytes()).hexdigest()})
        diagnostic_records[str(year)]=records
        grouped={}
        for run_id,item in items.items():
            run=item['run']; table=physical[item.get('alias_of',run_id)].copy(); table['run_id']=run_id
            if run['type'] not in ('primary','controlled'): continue
            key=(year,run['type'],run['case'],run['method']); grouped.setdefault(key,[]).append(table)
        for key,tables in grouped.items():
            frames[key]=pd.concat(tables,ignore_index=True)
            scores[str(key)]=score_rows(rows_from_frame(frames[key]),stats.high_threshold_m*100)
        c=selection['candidate']; candidate[year]=frames[(year,'primary',c['case'],c['method'])]
        for role,dest in (('joint',joint),('specialist',specialist)):
            e=refs['years'][str(year)][role]
            path=allowed_path(Path(e['path']),refs,'evaluation_'+str(year))
            dest[year]=pd.read_csv(path,parse_dates=['issue_time'],float_precision='round_trip')
            if historical_calendar_identity(dest[year],role,year)!=e['calendar_sha256']:
                raise ValueError('actual historical prediction calendar differs from sealed reference calendar')
    contrasts=complete_scientific_comparisons(frames,protocol,stats.high_threshold_m*100)
    replacement=replacement_report(candidate,joint,specialist,stats.high_threshold_m*100,policy,protocol)
    write_json(output/'scores.json',scores); write_json(output/'all_64_contrasts.json',contrasts)
    write_json(output/'replacement.json',replacement)
    write_json(output/'event_diagnostics.json',events); write_json(output/'annual_high_water_coverage.json',annual_coverage)
    write_json(output/'diagnostic_manifest.json',diagnostic_records)
    write_json(output/'prediction_manifest.json',write_prediction_manifest(paths,selection))

if __name__=='__main__': main_guard(main)
