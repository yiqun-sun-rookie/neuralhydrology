"""Preserve the successor already created from 313 verified predecessor files.

Rebootstrapping an existing delivery is refused. Read records/lineage.json
and scripts/verify_delivery.py for its provenance. No source files are read.
"""
from _entry import main_guard


def main():
    raise PermissionError('successor already created: preserve lineage and frozen configurations; bootstrap is retired')


if __name__=='__main__': main_guard(main)
