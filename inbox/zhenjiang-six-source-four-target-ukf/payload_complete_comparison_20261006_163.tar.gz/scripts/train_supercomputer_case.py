"""Run one registered architecture through tuning and complete final training.

Usage: python -B scripts/train_supercomputer_case.py --case legacy_lstm__small
Requires newly admitted 2017--2022 sources, authenticated fresh parent groups and
explicit supercomputer authority. Performs no evaluation or historical prediction
reads. Each case owns independent outputs; complete 200/400 epoch rules persist.
"""
from _entry import ROOT,read_json,write_json
import argparse
import copy
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import os
import sys
import time
import torch
from src.contracts import GroupSeal
from src.execution import device_identity
from src.models import make_parts
from src.state_estimators import make_branches,hash_module
from src.scheduler import (digest_json,code_identity,validate_registry,ready,resolve_effective_config,
                           verify_parent_binding,resolve_aliases,seal_group)
from src.runtime import execute_group,load_stage,fit_stage_stats,stats_record
from src.training import deterministic_runtime

def checkpoint_winner(outcome,method='foundation'):
    members={k:v for k,v in outcome['members'].items() if v['method']==method}
    return min(members,key=lambda k:(min(members[k]['validation_mae']),members[k]['learning_rate']))

def atomic_json(path,value):
    temp=path.with_suffix('.tmp')
    temp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    temp.replace(path)

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--case',required=True)
    args=p.parse_args(); case=args.case
    protocol=read_json(ROOT/'configs/protocol-v3.json'); auth=read_json(ROOT/'records/authorization.json')
    protocol_sha=hashlib.sha256((ROOT/'configs/protocol-v3.json').read_bytes()).hexdigest()
    if not auth['authority'].get('formal_training') or auth['protocol_sha256']!=protocol_sha:
        raise PermissionError('explicit formal training authority missing')
    if protocol['resource']['execution_policy']!='user_authorized_no_cost_or_timing_gate':
        raise PermissionError('execution policy differs from user authorization')
    if auth['code_hash']!=code_identity(): raise ValueError('released training implementation changed')
    registry=read_json(ROOT/'configs/registry-v3.json'); validate_registry(registry,protocol)
    if case not in {r['case'] for r in registry['runs']}: raise ValueError('unregistered case')
    prep=read_json(ROOT/'records/data_preparation_complete.json')
    if prep.get('status')!='admitted' or prep.get('code_hash')!=code_identity():
        raise ValueError('new training data not admitted for this release')
    identity=device_identity('cuda:0')
    deterministic_runtime(); torch.set_num_threads(4)
    record_dir=ROOT/'records'/case; record_dir.mkdir(exist_ok=True)
    write_start=record_dir/('allocation_'+str(os.environ.get('SLURM_JOB_ID','unknown'))+'.json')
    if not write_start.exists():
        write_json(write_start,{'status':'training_process_started','device_identity':identity,'case':case,
            'job_id':os.environ.get('SLURM_JOB_ID'),'code_hash':code_identity(),'protocol_sha256':protocol_sha,
            'evaluation_values_read':False,'cost_ceiling':None})
    manifests={split:read_json(ROOT/'prepared'/split/'manifest.json') for split in ('tuning','final')}
    statistics={split:stats_record(fit_stage_stats(load_stage(m,split+'_train'),m)) for split,m in manifests.items()}
    global_gate='protocol_and_data_and_training_authority_sealed'
    external={'status':'admitted','protocol_sha256':protocol_sha,'data_preparation_sha256':digest_json(prep),
              'explicit_unlimited_training_authority_sha256':digest_json(auth),'code_hash':code_identity()}
    external['evidence_sha256']=digest_json(external)
    seals={}; completed=set(); rates={}; outcomes={}

    def update_progress(status,group=None):
        atomic_json(record_dir/'progress.json',{'status':status,'group':group,'case':case,
            'completed_fits':len(completed),'completed_groups':list(outcomes),'selected_rates':rates,
            'job_id':os.environ.get('SLURM_JOB_ID'),'evaluation_values_read':False})

    def execute(suffix):
        nonlocal registry
        group=case+'__'+suffix; path=record_dir/(suffix+'_outcome.json')
        if path.exists():
            outcome=read_json(path)
            checked=seal_group(group+'__seal',outcome['members'],outcome['seal']['epochs'],
                               expected_members=list(outcome['members']))
            if asdict(checked)!=dict(outcome['seal'],member_ids=tuple(outcome['seal']['member_ids'])):
                raise ValueError('saved group seal differs')
        else:
            split='tuning' if suffix.startswith('tune') else 'final'; manifest=manifests[split]
            members=[r for r in registry['runs'] if r['budget_group']==group and r['status']!='alias']
            configs={}
            for run in members:
                if not ready(run,completed,seals,{global_gate:external}):
                    raise PermissionError('registered dependency incomplete: '+run['exp_id'])
                registered_rate=run.get('learning_rate')
                rate=(registered_rate if isinstance(registered_rate,(int,float)) else
                      .001 if run['type']=='controlled' else rates[run['method']])
                identities={'parent_hash':None,'parent_run_id':None,'parent_checkpoint':None,'parent_best_epoch':None,
                    'initializer_hash':None,'analysis_initialization_hash':None,'whitening_hash':None,'whitening':None,
                    'training_data_hash':digest_json(manifest),'normalization_hash':digest_json(statistics[split]),
                    'tide_source_hash':manifest['tide_source_hash'],'code_hash':code_identity(),
                    'shuffle_hash':digest_json({'seed':run['seed'],'offset':200000,'stride':12,'phases':'epoch_modulo_12'})}
                if run['method']!='foundation':
                    parent_id=(checkpoint_winner(outcomes[case+'__tune_foundation_group']) if run['type']=='tune_branch'
                               else run['parent_run_id'])
                    parent_group=case+('__tune_foundation_group' if run['type']=='tune_branch' else '__final_foundation_group')
                    parent=outcomes[parent_group]['members'][parent_id]
                    if parent['normalization_hash']!=identities['normalization_hash']: raise ValueError('parent statistics differ')
                    identities.update(parent_run_id=parent_id,parent_hash=parent['checkpoint_sha256'],
                        parent_checkpoint=parent['checkpoint_path'],parent_best_epoch=parent['best_epoch'],
                        initializer_hash=parent['initializer_hash'])
                    if run['method'].startswith('encoder'):
                        family,capacity=case.split('__')
                        branches=make_branches(make_parts(family,capacity,run['seed']),run['seed']+100000)
                        identities['analysis_initialization_hash']=hash_module(branches[run['method']].encoder)
                    else:
                        whitening=read_json(Path(parent['checkpoint_path']).parent/'whitening.json')
                        identities.update(whitening=whitening,whitening_hash=parent['whitening_hash'])
                effective=resolve_effective_config(run,protocol,rate,identities)
                effective.update(device=identity['device'],device_identity=identity,group_wall_seconds_limit=None,
                                 scheduler_continuation=True)
                verify_parent_binding(run,effective,seals)
                configs[run['exp_id']]={'status':'frozen_authorized','registration':run,
                    'protocol_sha256':protocol_sha,'effective_config':effective}
            if suffix=='all_final_branches_group':
                effective_configs={k:v['effective_config'] for k,v in configs.items()}
                registry=resolve_aliases(registry,{(case,m):rates[m] for m in protocol['method_order']},
                                         effective_configs,cases={case})
                alias_path=record_dir/'aliases_before_final_training.json'
                alias_record={'aliases':registry['aliases'],'effective_configs_sha256':digest_json(effective_configs)}
                if alias_path.exists():
                    if read_json(alias_path)!=alias_record: raise ValueError('frozen aliases changed')
                else: write_json(alias_path,alias_record)
                configs={k:v for k,v in configs.items() if k not in registry['aliases']}
            frozen_path=record_dir/(suffix+'_configs.json')
            if frozen_path.exists():
                if read_json(frozen_path)!=configs: raise ValueError('frozen group configurations changed')
            else: write_json(frozen_path,configs)
            update_progress('executing_group',group)
            print(json.dumps({'status':'starting_formal_group','group':group,'physical_fits':len(configs)}),flush=True)
            outcome=execute_group(group,registry,protocol,configs,manifest,ROOT/'runs',seals)
            write_json(path,outcome)
        outcomes[group]=outcome; completed.update(outcome['members'])
        seals[group+'__seal']=GroupSeal(**outcome['seal'])
        update_progress('group_sealed',group)
        return outcome

    tune_foundation=execute('tune_foundation_group')
    winner=checkpoint_winner(tune_foundation)
    rates['foundation']=tune_foundation['members'][winner]['learning_rate']
    tune_branch=execute('tune_branch_group')
    for method in protocol['method_order']:
        winner=checkpoint_winner(tune_branch,method); rates[method]=tune_branch['members'][winner]['learning_rate']
        members={k:v for k,v in tune_branch['members'].items() if v['method']==method}
        gate=case+'__select_rate__'+method
        seals[gate]=seal_group(gate,members,tune_branch['seal']['epochs'],expected_members=list(members))
    rate_path=record_dir/'selected_rates_2021.json'
    if not rate_path.exists(): write_json(rate_path,{'rates':rates,'criterion':'2021 unweighted four-station MAE; smaller rate wins tie'})
    execute('final_foundation_group'); execute('all_final_branches_group')
    write_json(record_dir/'training_complete.json',{'status':'case_training_complete','completed_fits':len(completed),
        'seals':{k:asdict(v) for k,v in seals.items()},'rates':rates,'evaluation_values_read':False})
    update_progress('case_training_complete')

if __name__=='__main__':
    try: main()
    except Exception as error:
        print(json.dumps({'status':'training_stopped','error_type':type(error).__name__,'reason':str(error)}),flush=True)
        raise
