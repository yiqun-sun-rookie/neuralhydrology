"""Audit the exact saved positive Joseph matrix on the registered GPU only.

No model, data loader, optimizer, validation, or formal repair is executed.
Power-of-two congruence is an isolated arithmetic diagnostic, never installed.
"""
import datetime
import hashlib
import json
from pathlib import Path
import sys
import traceback

import torch

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def save(name, value):
    path = ROOT/'evidence'/name
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, sort_keys=True, allow_nan=False)
        stream.write('\n')
    return {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}


def tensor_sha(tensor):
    return hashlib.sha256(tensor.detach().contiguous().cpu().numpy().tobytes()).hexdigest()


def main():
    (ROOT/'evidence').mkdir(exist_ok=False)
    spec = read(ROOT/'diagnostic_spec.json')
    assert str(ROOT) == spec['diagnostic_root']
    source = Path(spec['source_root'])
    pinned = spec['pinned_source_files']
    code = spec['source_code_file_hashes']
    assert len(pinned) == 58 and len(code) == 37
    assert all(sha(p) == h for p, h in pinned.items())
    assert all(sha(source/name) == h for name, h in code.items())
    assert sha(spec['raw_path']) == spec['raw_sha256']
    assert sha(spec['cpu_audit_path']) == spec['cpu_audit_sha256']
    assert sha(spec['replay_result_path']) == spec['replay_result_sha256']
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    assert torch.cuda.is_available() and torch.cuda.device_count() == 1
    props = torch.cuda.get_device_properties(0)
    device = {'device': 'cuda:0', 'name': props.name, 'total_memory_bytes': props.total_memory}
    assert device == spec['expected_device_identity']
    raw = torch.load(spec['raw_path'], map_location='cpu', weights_only=True)
    cpu = read(spec['cpu_audit_path'])
    assert cpu['two_precision_nearest_float64_reference_equal']
    assert all(r['stored_compensated_candidate']['positive'] and
               r['nearest_float64_reference']['positive'] for r in cpu['high_precision_diagnostic_references'])
    frames = {f['function']: f for f in raw['original_failure_traceback_frames']}
    index = frames['repair_rejected_members']['scalars']['i']
    assert index == cpu['failed_member_index'] == 10
    original = frames['linear_update']['tensors']['p']
    candidate = frames['repair_rejected_members']['tensors']['candidate']
    assert torch.equal(original[index:index+1], candidate)
    assert tensor_sha(candidate[0]) == cpu['high_precision_diagnostic_references'][0]['nearest_float64_reference_sha256']
    assert raw['context']['epoch'] == 46 and raw['context']['validation_batch_index'] == 170
    sys.path.insert(0, str(source))
    from src.differentiable_filter import JITTERS, FilterFailure, stable_cholesky
    assert list(JITTERS) == raw['original_jitters'] == spec['original_jitters']
    gpu = original.to('cuda:0')
    gpu_candidate = candidate.to('cuda:0')
    assert torch.equal(gpu.cpu(), original) and torch.equal(gpu_candidate.cpu(), candidate)
    controls = []
    for i in range(16):
        try:
            factor = stable_cholesky(gpu[i:i+1])
        except FilterFailure as error:
            controls.append({'member_index': i, 'original_accepted': False,
                             'reason': str(error), 'evidence': error.evidence})
        else:
            controls.append({'member_index': i, 'original_accepted': True,
                             'factor_finite': bool(torch.isfinite(factor).all()),
                             'factor_sha256': tensor_sha(factor)})
    attempts, scaled_attempts = [], []
    eye = torch.eye(128, dtype=torch.float64, device='cuda:0')
    for jitter in JITTERS:
        matrix = gpu_candidate[0] + jitter*eye
        factor, info = torch.linalg.cholesky_ex(matrix)
        attempts.append({'jitter': jitter, 'info': int(info),
                         'finite_factor': bool(torch.isfinite(factor).all())})
        # Binary powers are exactly invertible on these stored entries. No
        # changed posterior, noise, absolute jitter, rank, or spectrum is used.
        diagonal = matrix.diagonal()
        assert bool((diagonal > 0).all())
        _, exponent = torch.frexp(diagonal)
        powers = -torch.div(exponent, 2, rounding_mode='floor')
        scaled = torch.ldexp(torch.ldexp(matrix, powers[:, None]), powers[None, :])
        inverted = torch.ldexp(torch.ldexp(scaled, -powers[:, None]), -powers[None, :])
        assert torch.equal(inverted, matrix) and bool(torch.isfinite(scaled).all())
        sf, si = torch.linalg.cholesky_ex(scaled)
        unscaled = torch.ldexp(sf, -powers[:, None])
        finite = bool(torch.isfinite(unscaled).all())
        entry = {'jitter': jitter, 'info': int(si), 'finite_factor': finite,
                 'input_congruence_exactly_invertible': True,
                 'power_min': int(powers.min()), 'power_max': int(powers.max()),
                 'input_matrix_sha256': tensor_sha(matrix),
                 'scaled_matrix_sha256': tensor_sha(scaled)}
        if int(si) == 0 and finite:
            residual = unscaled @ unscaled.T - matrix
            entry.update(factor_sha256=tensor_sha(unscaled),
                         maximum_absolute_reconstruction_error=float(residual.abs().max()),
                         reconstruction_error_over_entry_scale=float(residual.abs().max()/matrix.abs().max()),
                         positive_factor_diagonal=bool((unscaled.diagonal() > 0).all()))
        scaled_attempts.append(entry)
    assert torch.equal(gpu.cpu(), original) and torch.equal(gpu_candidate.cpu(), candidate)
    assert all(sha(p) == h for p, h in pinned.items())
    assert all(sha(source/name) == h for name, h in code.items())
    assert sha(spec['raw_path']) == spec['raw_sha256']
    result = {'status': 'saved_joseph_gpu_factorization_audit_completed',
              'checked_at_beijing': datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
              'diagnostic_root': str(ROOT), 'source_root': str(source),
              'source_code_hash': spec['source_code_hash'], 'device_identity': device,
              'source_identity_count': len(pinned), 'source_code_file_count': len(code),
              'operands_sha256': spec['raw_sha256'], 'cpu_audit_sha256': spec['cpu_audit_sha256'],
              'original_context': raw['context'], 'failed_member_index': index,
              'original_jitters': list(JITTERS), 'original_member_controls': controls,
              'original_gpu_attempts': attempts, 'power_two_congruence_gpu_attempts': scaled_attempts,
              'original_gpu_rejection_reproduced': not any(a['info'] == 0 and a['finite_factor'] for a in attempts),
              'any_power_two_congruence_factor_passed': any(a['info'] == 0 and a['finite_factor'] for a in scaled_attempts),
              'all_input_tensor_bytes_unchanged': True, 'all_source_bytes_unchanged': True,
              'all_twelve_failed_members_preserved': True, 'same_stored_positive_matrix_verified': True,
              'gradient_gate_tested': False, 'original_2021_validation_run': False,
              'diagnostic_only_no_candidate_installed': True, 'formal_repair_admitted': False,
              'formal_training_epochs_added': 0, 'optimizer_updates': 0,
              'training_data_values_read': False, 'selection_data_values_read': False,
              'evaluation_values_read': False, 'scientific_rules_changed': False,
              'formal_training_restarted': False}
    save('joseph_gpu_factorization_audit_result.json', result)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        if (ROOT/'evidence').is_dir():
            save('joseph_gpu_factorization_audit_technical_error.json',
                 {'status': 'saved_joseph_gpu_factorization_audit_technical_error',
                  'error_type': type(error).__name__, 'error': str(error),
                  'traceback': traceback.format_exc(), 'formal_training_epochs_added': 0,
                  'evaluation_values_read': False, 'scientific_rules_changed': False})
        raise
