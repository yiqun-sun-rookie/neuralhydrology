#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Train the frozen first-stage five-target direct-state model.

The reusable training entry accepts already-authorized, already-standardized
datasets.  It uses 2017--2021 only for parameter updates and 2022 only for
best-epoch selection.  The command-line interface intentionally runs synthetic
smoke data only; it cannot open formal data or create a formal experiment root.

Example:
    python scripts/modeling/train_zhenjiang_five_source_five_target_d32_gru_v2.py --execution-mode synthetic_smoke --seed 17 --device cpu
"""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
import platform
import random
import sys
from typing import Dict, Mapping, Optional, Sequence, Tuple, Union

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset

from zhenjiang_five_source_five_target_d32_gru_v2 import (
    EXPECTED_PARAMETER_COUNT,
    FiveSourceFiveTargetD32GRU,
    TARGET_STATIONS,
    trainable_parameter_count,
)


EXPERIMENT_FAMILY = (
    "ZHENJIANG_FIVE_SOURCE_FIVE_TARGET_D32_GRU_"
    "SINGLE_ANALYSIS_UKF_ORACLE_DATONG_V2"
)
DATONG_BOUNDARY_MODE = "retrospective_observed_oracle"
ALLOWED_SEEDS: Tuple[int, ...] = (17, 29, 43)
TRAINING_YEARS: Tuple[int, ...] = (2017, 2018, 2019, 2020, 2021)
SELECTION_YEAR = 2022
SELECTION_USE = "best_epoch_selection_only"
SMOOTH_ABSOLUTE_ERROR_TRANSITION_M = 0.10
CELLS_PER_SAMPLE = 24 * 5
HISTORICAL_INTERNAL_FOUR_STATION_REFERENCE_M = 0.085800
INTERNAL_FOUR_STATIONS: Tuple[str, ...] = TARGET_STATIONS[:4]


@dataclass(frozen=True)
class StageATrainingConfiguration:
    """Immutable first-stage optimization and early-stopping settings."""

    batch_size: int = 128
    maximum_epochs: int = 36
    patience_epochs: int = 4
    minimum_improvement_m: float = 0.0001
    learning_rate: float = 0.001
    weight_decay: float = 0.0001
    maximum_gradient_norm: float = 1.0


FROZEN_CONFIGURATION = StageATrainingConfiguration()


@dataclass(frozen=True)
class StageAPartitions:
    """Datasets plus explicit, non-interchangeable calendar-year roles."""

    training_dataset: Dataset
    selection_dataset: Dataset
    training_years: Tuple[int, ...] = TRAINING_YEARS
    selection_year: int = SELECTION_YEAR

    def validate(self) -> "StageAPartitions":
        if tuple(self.training_years) != TRAINING_YEARS:
            raise ValueError("stage A parameter updates must use 2017--2021 only")
        if self.selection_year != SELECTION_YEAR:
            raise ValueError("stage A best-epoch selection must use 2022 only")
        if len(self.training_dataset) < 1:
            raise ValueError("2017--2021 training dataset must be nonempty")
        if len(self.selection_dataset) < 1:
            raise ValueError("2022 selection dataset must be nonempty")
        return self


def _validate_prediction_target(
    predictions_standardized: torch.Tensor,
    targets_standardized: torch.Tensor,
) -> int:
    if (
        not isinstance(predictions_standardized, torch.Tensor)
        or not isinstance(targets_standardized, torch.Tensor)
        or predictions_standardized.ndim != 3
        or predictions_standardized.shape[1:] != (24, 5)
        or targets_standardized.shape != predictions_standardized.shape
        or predictions_standardized.shape[0] < 1
    ):
        raise ValueError("predictions and targets must have shape [batch, 24, 5]")
    if (
        predictions_standardized.dtype != torch.float32
        or targets_standardized.dtype != torch.float32
        or predictions_standardized.device != targets_standardized.device
        or not bool(torch.isfinite(predictions_standardized).all())
        or not bool(torch.isfinite(targets_standardized).all())
    ):
        raise ValueError("prediction and target tensors must be finite float32 peers")
    return int(predictions_standardized.shape[0])


def _validated_explicit_stage_scale(
    explicit_stage_standard_deviations_m: torch.Tensor,
    *,
    device: torch.device,
) -> torch.Tensor:
    scale = torch.as_tensor(
        explicit_stage_standard_deviations_m,
        dtype=torch.float32,
        device=device,
    )
    if (
        scale.shape != (5,)
        or not bool(torch.isfinite(scale).all())
        or bool((scale <= 0).any())
    ):
        raise ValueError(
            "explicit-stage standard deviations must be five positive values"
        )
    return scale


def smooth_absolute_error_sum_and_count(
    predictions_standardized: torch.Tensor,
    targets_standardized: torch.Tensor,
    explicit_stage_standard_deviations_m: torch.Tensor,
) -> Tuple[torch.Tensor, int]:
    """Return the 0.10-metre smooth absolute-error sum and cell count."""

    batch_size = _validate_prediction_target(
        predictions_standardized,
        targets_standardized,
    )
    scale = _validated_explicit_stage_scale(
        explicit_stage_standard_deviations_m,
        device=predictions_standardized.device,
    )
    error_m = (
        predictions_standardized - targets_standardized
    ) * scale[None, None, :]
    absolute_error_m = error_m.abs()
    transition_m = SMOOTH_ABSOLUTE_ERROR_TRANSITION_M
    loss_cell = torch.where(
        absolute_error_m < transition_m,
        0.5 * error_m.square() / transition_m,
        absolute_error_m - 0.5 * transition_m,
    )
    return loss_cell.sum(), batch_size * CELLS_PER_SAMPLE


def five_target_smooth_absolute_error(
    predictions_standardized: torch.Tensor,
    targets_standardized: torch.Tensor,
    explicit_stage_standard_deviations_m: torch.Tensor,
) -> torch.Tensor:
    """Return the mean of all equally weighted five-target metre cells."""

    loss_sum, cell_count = smooth_absolute_error_sum_and_count(
        predictions_standardized,
        targets_standardized,
        explicit_stage_standard_deviations_m,
    )
    return loss_sum / cell_count


def _historical_reference_document() -> Dict[str, object]:
    return {
        "mean_absolute_error_m": (
            HISTORICAL_INTERNAL_FOUR_STATION_REFERENCE_M
        ),
        "stations": list(INTERNAL_FOUR_STATIONS),
        "matched_boundary_comparison": False,
        "used_for_selection": False,
        "used_as_stopping_threshold": False,
        "used_for_architecture_change": False,
        "reason": (
            "Historical four-station value used a different boundary, target, "
            "and model contract; it is not a fair comparison for this family."
        ),
    }


def _mean_absolute_error_report_from_sums(
    absolute_error_sum_by_lead_target_m: torch.Tensor,
    *,
    sample_count: int,
) -> Dict[str, object]:
    if (
        absolute_error_sum_by_lead_target_m.shape != (24, 5)
        or absolute_error_sum_by_lead_target_m.dtype != torch.float64
        or sample_count < 1
        or not bool(torch.isfinite(absolute_error_sum_by_lead_target_m).all())
    ):
        raise ValueError("selection error sums must be finite float64 [24, 5]")
    per_lead_target = absolute_error_sum_by_lead_target_m / sample_count
    per_target = absolute_error_sum_by_lead_target_m.sum(dim=0) / (
        sample_count * 24
    )
    cell_count = sample_count * CELLS_PER_SAMPLE
    overall = absolute_error_sum_by_lead_target_m.sum() / cell_count
    return {
        "metric": "mean_absolute_error_m",
        "selection_year": SELECTION_YEAR,
        "selection_use": SELECTION_USE,
        "sample_count": sample_count,
        "cell_count": cell_count,
        "target_stations": list(TARGET_STATIONS),
        "lead_hours_after_analysis": list(range(24)),
        "overall_mean_absolute_error_m": float(overall),
        "per_target_mean_absolute_error_m": [
            float(value) for value in per_target
        ],
        "per_lead_target_mean_absolute_error_m": [
            [float(value) for value in row]
            for row in per_lead_target
        ],
        "historical_internal_four_station_reference": (
            _historical_reference_document()
        ),
    }


def mean_absolute_error_report(
    predictions_standardized: torch.Tensor,
    targets_standardized: torch.Tensor,
    explicit_stage_standard_deviations_m: torch.Tensor,
) -> Dict[str, object]:
    """Report all five station-by-lead absolute metrics in metres."""

    batch_size = _validate_prediction_target(
        predictions_standardized,
        targets_standardized,
    )
    scale = _validated_explicit_stage_scale(
        explicit_stage_standard_deviations_m,
        device=predictions_standardized.device,
    )
    absolute_error_m = (
        (predictions_standardized - targets_standardized)
        * scale[None, None, :]
    ).abs()
    error_sums = absolute_error_m.sum(dim=0, dtype=torch.float64).cpu()
    return _mean_absolute_error_report_from_sums(
        error_sums,
        sample_count=batch_size,
    )


def should_replace_best(
    current_selection_mean_absolute_error_m: float,
    best_selection_mean_absolute_error_m: float,
    minimum_improvement_m: Optional[float] = None,
) -> bool:
    """Apply the frozen minimum improvement while retaining earlier ties."""

    if minimum_improvement_m is None:
        minimum_improvement_m = FROZEN_CONFIGURATION.minimum_improvement_m
    if not np.isfinite(current_selection_mean_absolute_error_m):
        raise ValueError("current selection metric must be finite")
    if current_selection_mean_absolute_error_m < 0.0:
        raise ValueError("selection mean absolute error cannot be negative")
    if best_selection_mean_absolute_error_m == float("inf"):
        return True
    if not np.isfinite(best_selection_mean_absolute_error_m):
        raise ValueError("best selection metric must be finite or positive infinity")
    return current_selection_mean_absolute_error_m <= (
        best_selection_mean_absolute_error_m - minimum_improvement_m
    )


def configure_stage_a_parameters(model: FiveSourceFiveTargetD32GRU) -> None:
    """Make every backbone scalar trainable and verify the exact count."""

    if not isinstance(model, FiveSourceFiveTargetD32GRU):
        raise ValueError("FiveSourceFiveTargetD32GRU is required")
    model.requires_grad_(True)
    if trainable_parameter_count(model) != EXPECTED_PARAMETER_COUNT:
        raise RuntimeError("stage A must train exactly 20,416 backbone parameters")


def total_parameter_count(model: nn.Module) -> int:
    """Return every scalar parameter, regardless of its gradient flag."""

    return sum(parameter.numel() for parameter in model.parameters())


def _set_all_random_generators(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _environment_manifest(device: torch.device) -> Dict[str, object]:
    cudnn = torch.backends.cudnn
    return {
        "python_version": sys.version,
        "platform": platform.platform(),
        "processor": platform.processor(),
        "torch_version": torch.__version__,
        "requested_device": str(device),
        "cuda_available": torch.cuda.is_available(),
        "cuda_version": torch.version.cuda,
        "cudnn_version": cudnn.version() if cudnn.is_available() else None,
        "deterministic_algorithms_enabled": (
            torch.are_deterministic_algorithms_enabled()
        ),
        "cudnn_deterministic": bool(cudnn.deterministic),
        "cudnn_benchmark": bool(cudnn.benchmark),
        "known_nondeterministic_operations": [],
    }


def _create_exclusive_output_directory(
    output_directory: Union[str, Path],
) -> Path:
    output_path = Path(output_directory)
    if not output_path.parent.is_dir():
        raise FileNotFoundError(
            "the exclusive output directory parent must already exist"
        )
    try:
        output_path.mkdir(exist_ok=False)
    except FileExistsError as error:
        raise FileExistsError(
            f"refusing to reuse any existing output directory: {output_path}"
        ) from error
    return output_path


def _batch_tensors(
    batch: Mapping[str, torch.Tensor],
    *,
    device: torch.device,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    required = ("history", "future_control", "targets_a_to_a_plus_23")
    missing = [name for name in required if name not in batch]
    if missing:
        raise ValueError(f"stage A batch is missing fields: {missing}")
    return (
        batch["history"].to(device),
        batch["future_control"].to(device),
        batch["targets_a_to_a_plus_23"].to(device),
    )


def _run_training_epoch(
    model: FiveSourceFiveTargetD32GRU,
    loader: DataLoader,
    explicit_stage_scale_m: torch.Tensor,
    *,
    device: torch.device,
    optimizer: torch.optim.Optimizer,
    maximum_gradient_norm: float,
) -> float:
    model.train()
    total_loss_sum = 0.0
    total_cell_count = 0
    for batch in loader:
        history, future_control, targets = _batch_tensors(batch, device=device)
        optimizer.zero_grad(set_to_none=True)
        predictions = model(history, future_control)
        loss_sum, cell_count = smooth_absolute_error_sum_and_count(
            predictions,
            targets,
            explicit_stage_scale_m,
        )
        loss = loss_sum / cell_count
        loss.backward()
        nn.utils.clip_grad_norm_(
            model.parameters(),
            maximum_gradient_norm,
        )
        optimizer.step()
        total_loss_sum += float(loss_sum.detach().cpu())
        total_cell_count += cell_count
    if total_cell_count < 1:
        raise ValueError("training loader yielded zero cells")
    return total_loss_sum / total_cell_count


def _evaluate_2022_selection(
    model: FiveSourceFiveTargetD32GRU,
    loader: DataLoader,
    explicit_stage_scale_m: torch.Tensor,
    *,
    device: torch.device,
) -> Dict[str, object]:
    model.eval()
    error_sums = torch.zeros((24, 5), dtype=torch.float64)
    sample_count = 0
    with torch.no_grad():
        for batch in loader:
            history, future_control, targets = _batch_tensors(
                batch,
                device=device,
            )
            predictions = model(history, future_control)
            batch_size = _validate_prediction_target(predictions, targets)
            scale = _validated_explicit_stage_scale(
                explicit_stage_scale_m,
                device=device,
            )
            absolute_error_m = (
                (predictions - targets) * scale[None, None, :]
            ).abs()
            error_sums += absolute_error_m.sum(
                dim=0,
                dtype=torch.float64,
            ).cpu()
            sample_count += batch_size
    if sample_count < 1:
        raise ValueError("2022 selection loader yielded zero cells")
    return _mean_absolute_error_report_from_sums(
        error_sums,
        sample_count=sample_count,
    )


def _checkpoint(
    model: FiveSourceFiveTargetD32GRU,
    *,
    seed: int,
    epoch: int,
    selection_metrics: Mapping[str, object],
    explicit_stage_scale_m: torch.Tensor,
    configuration: StageATrainingConfiguration,
) -> Dict[str, object]:
    total_count = total_parameter_count(model)
    trainable_count = trainable_parameter_count(model)
    if total_count != EXPECTED_PARAMETER_COUNT:
        raise RuntimeError("total model parameter count changed")
    if trainable_count != EXPECTED_PARAMETER_COUNT:
        raise RuntimeError("stage A trainable parameter count changed")
    return {
        "schema_version": 2,
        "experiment_family": EXPERIMENT_FAMILY,
        "boundary_mode": DATONG_BOUNDARY_MODE,
        "stage": "stage_a",
        "seed": seed,
        "epoch": epoch,
        "model_class": "FiveSourceFiveTargetD32GRU",
        "training_years": list(TRAINING_YEARS),
        "selection_year": SELECTION_YEAR,
        "selection_use": SELECTION_USE,
        "total_parameter_count": total_count,
        "stage_a_trainable_parameter_count": trainable_count,
        "explicit_stage_standard_deviations_m": [
            float(value)
            for value in explicit_stage_scale_m.detach().cpu()
        ],
        "selection_metrics": dict(selection_metrics),
        "training_configuration": asdict(configuration),
        "model_state_dict": {
            name: value.detach().cpu().clone()
            for name, value in model.state_dict().items()
        },
    }


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _write_json(path: Path, document: object) -> None:
    path.write_text(
        json.dumps(document, indent=2, sort_keys=True, allow_nan=False),
        encoding="utf-8",
    )


def train_stage_a(
    *,
    partitions: StageAPartitions,
    explicit_stage_standard_deviations_m: torch.Tensor,
    seed: int,
    device: Union[str, torch.device],
    output_directory: Union[str, Path],
    configuration: Optional[StageATrainingConfiguration] = None,
) -> Mapping[str, object]:
    """Train one seed in an atomically created, never-reused directory."""

    if configuration is None:
        configuration = FROZEN_CONFIGURATION
    if configuration != FROZEN_CONFIGURATION:
        raise ValueError("stage A training configuration is frozen")
    if seed not in ALLOWED_SEEDS:
        raise ValueError("seed must be one of 17, 29, or 43")
    partitions.validate()
    scale_on_cpu = _validated_explicit_stage_scale(
        explicit_stage_standard_deviations_m,
        device=torch.device("cpu"),
    )
    output_path = _create_exclusive_output_directory(output_directory)

    _set_all_random_generators(seed)
    torch_device = torch.device(device)
    model = FiveSourceFiveTargetD32GRU().to(torch_device)
    configure_stage_a_parameters(model)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=configuration.learning_rate,
        weight_decay=configuration.weight_decay,
    )
    data_order_generator = torch.Generator().manual_seed(seed)
    training_loader = DataLoader(
        partitions.training_dataset,
        batch_size=configuration.batch_size,
        shuffle=True,
        generator=data_order_generator,
        drop_last=False,
    )
    selection_loader = DataLoader(
        partitions.selection_dataset,
        batch_size=configuration.batch_size,
        shuffle=False,
        drop_last=False,
    )
    scale_on_device = scale_on_cpu.to(torch_device)

    training_history = []
    best_metric_m = float("inf")
    best_checkpoint = None
    best_selection_metrics = None
    last_checkpoint = None
    epochs_without_improvement = 0
    for epoch in range(1, configuration.maximum_epochs + 1):
        training_metric_m = _run_training_epoch(
            model,
            training_loader,
            scale_on_device,
            device=torch_device,
            optimizer=optimizer,
            maximum_gradient_norm=configuration.maximum_gradient_norm,
        )
        selection_metrics = _evaluate_2022_selection(
            model,
            selection_loader,
            scale_on_device,
            device=torch_device,
        )
        selection_metric_m = float(
            selection_metrics["overall_mean_absolute_error_m"]
        )
        improved = should_replace_best(
            selection_metric_m,
            best_metric_m,
            configuration.minimum_improvement_m,
        )
        training_history.append(
            {
                "epoch": epoch,
                "training_smooth_absolute_error_m": training_metric_m,
                "selection_2022_mean_absolute_error_m": selection_metric_m,
                "selected_as_best": improved,
            }
        )
        last_checkpoint = _checkpoint(
            model,
            seed=seed,
            epoch=epoch,
            selection_metrics=selection_metrics,
            explicit_stage_scale_m=scale_on_cpu,
            configuration=configuration,
        )
        if improved:
            best_metric_m = selection_metric_m
            best_checkpoint = last_checkpoint
            best_selection_metrics = selection_metrics
            epochs_without_improvement = 0
        else:
            epochs_without_improvement += 1
        if epochs_without_improvement >= configuration.patience_epochs:
            break

    if (
        best_checkpoint is None
        or best_selection_metrics is None
        or last_checkpoint is None
    ):
        raise RuntimeError("stage A completed no checkpointed epoch")

    best_path = output_path / "best_checkpoint.pt"
    last_path = output_path / "last_checkpoint.pt"
    history_path = output_path / "training_history.json"
    environment_path = output_path / "environment_manifest.json"
    torch.save(best_checkpoint, best_path)
    torch.save(last_checkpoint, last_path)
    _write_json(history_path, training_history)
    _write_json(environment_path, _environment_manifest(torch_device))

    artifact_paths = (best_path, last_path, history_path, environment_path)
    manifest = {
        "schema_version": 2,
        "experiment_family": EXPERIMENT_FAMILY,
        "boundary_mode": DATONG_BOUNDARY_MODE,
        "stage": "stage_a",
        "status": "complete",
        "seed": seed,
        "output_directory": str(output_path.resolve()),
        "output_directory_created_exclusively": True,
        "training_years": list(TRAINING_YEARS),
        "selection_year": SELECTION_YEAR,
        "selection_use": SELECTION_USE,
        "best_epoch": int(best_checkpoint["epoch"]),
        "best_selection_mean_absolute_error_m": best_metric_m,
        "best_selection_metrics": best_selection_metrics,
        "total_parameter_count": EXPECTED_PARAMETER_COUNT,
        "stage_a_trainable_parameter_count": EXPECTED_PARAMETER_COUNT,
        "training_configuration": asdict(configuration),
        "files": {
            path.name: {
                "byte_count": path.stat().st_size,
                "sha256": _sha256(path),
            }
            for path in artifact_paths
        },
    }
    _write_json(output_path / "completion_manifest.json", manifest)
    return manifest


class _SyntheticDataset(Dataset):
    def __init__(self, sample_count: int, seed: int) -> None:
        generator = torch.Generator().manual_seed(seed)
        self.history = torch.randn(
            sample_count,
            24,
            6,
            generator=generator,
        )
        self.future_control = torch.randn(
            sample_count,
            24,
            2,
            generator=generator,
        )
        self.targets = torch.randn(
            sample_count,
            24,
            5,
            generator=generator,
        )

    def __len__(self) -> int:
        return len(self.history)

    def __getitem__(self, index: int) -> Mapping[str, torch.Tensor]:
        return {
            "history": self.history[index],
            "future_control": self.future_control[index],
            "targets_a_to_a_plus_23": self.targets[index],
        }


def run_synthetic_smoke(
    seed: int,
    device: Union[str, torch.device],
) -> Mapping[str, object]:
    """Run two in-memory synthetic epochs without formal reads or outputs."""

    if seed not in ALLOWED_SEEDS:
        raise ValueError("seed must be one of 17, 29, or 43")
    _set_all_random_generators(seed)
    torch_device = torch.device(device)
    model = FiveSourceFiveTargetD32GRU().to(torch_device)
    configure_stage_a_parameters(model)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=FROZEN_CONFIGURATION.learning_rate,
        weight_decay=FROZEN_CONFIGURATION.weight_decay,
    )
    dataset = _SyntheticDataset(8, seed)
    generator = torch.Generator().manual_seed(seed)
    loader = DataLoader(
        dataset,
        batch_size=4,
        shuffle=True,
        generator=generator,
    )
    scale = torch.ones(5, dtype=torch.float32, device=torch_device)
    metrics = []
    for _ in range(2):
        metrics.append(
            _run_training_epoch(
                model,
                loader,
                scale,
                device=torch_device,
                optimizer=optimizer,
                maximum_gradient_norm=(
                    FROZEN_CONFIGURATION.maximum_gradient_norm
                ),
            )
        )
    if not all(np.isfinite(value) for value in metrics):
        raise RuntimeError("synthetic smoke produced nonfinite metrics")
    return {
        "execution_mode": "synthetic_smoke",
        "seed": seed,
        "device": str(torch_device),
        "epochs": 2,
        "cells_per_sample": CELLS_PER_SAMPLE,
        "stage_a_trainable_parameter_count": trainable_parameter_count(model),
        "metrics_finite": True,
        "formal_data_read": False,
        "formal_output_created": False,
    }


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--execution-mode",
        choices=("synthetic_smoke",),
        required=True,
    )
    parser.add_argument(
        "--seed",
        type=int,
        choices=ALLOWED_SEEDS,
        required=True,
    )
    parser.add_argument("--device", required=True)
    arguments = parser.parse_args(argv)
    report = run_synthetic_smoke(arguments.seed, arguments.device)
    print(json.dumps(report, indent=2, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
