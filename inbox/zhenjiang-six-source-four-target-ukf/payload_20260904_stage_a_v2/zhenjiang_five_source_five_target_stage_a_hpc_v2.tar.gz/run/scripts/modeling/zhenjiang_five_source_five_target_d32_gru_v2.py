#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Direct 32-dimensional explicit-state recurrent process model.

The model encodes one 24-hour, six-station history into the state at the hour
before analysis.  Each two-component control then advances the complete state
by one hour.  State coordinates zero through four are the standardized total
water levels for Nanjing, Zhenjiang, Jiangyin, Xuliujing, and Wusongkou; they
are returned directly, without a learned output head.  This module performs no
data access, training, or experiment-state mutation.
"""

from __future__ import annotations

from typing import Tuple

import torch
from torch import nn


HISTORY_STATIONS: Tuple[str, ...] = (
    "datong",
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
TARGET_STATIONS: Tuple[str, ...] = (
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
HISTORY_HOURS = 24
FORECAST_HOURS = 24
CONTROL_DIMENSION = 2
ENCODER_HIDDEN_SIZE = 64
STATE_DIMENSION = 32
EXPLICIT_STATE_DIMENSION = 5
EXPECTED_PARAMETER_COUNT = 20_416


def trainable_parameter_count(model: nn.Module) -> int:
    """Return the exact number of trainable scalar parameters."""

    return sum(
        parameter.numel()
        for parameter in model.parameters()
        if parameter.requires_grad
    )


def _validate_tensor(
    value: torch.Tensor,
    *,
    name: str,
    shape: Tuple[int, ...],
    reference: torch.Tensor,
) -> None:
    if not isinstance(value, torch.Tensor) or tuple(value.shape) != shape:
        raise ValueError(f"{name} must have shape {shape}")
    if (
        not value.dtype.is_floating_point
        or value.dtype != reference.dtype
        or value.device != reference.device
        or not bool(torch.isfinite(value).all())
    ):
        raise ValueError(f"{name} must be finite and match the model")


class FiveSourceFiveTargetD32GRU(nn.Module):
    """Encode one history and directly propagate five explicit water levels."""

    state_size = STATE_DIMENSION

    def __init__(self) -> None:
        super().__init__()
        self.history_encoder = nn.GRU(
            input_size=len(HISTORY_STATIONS),
            hidden_size=ENCODER_HIDDEN_SIZE,
            batch_first=True,
        )
        self.state_projection = nn.Linear(
            ENCODER_HIDDEN_SIZE,
            STATE_DIMENSION,
        )
        self.process_cell = nn.GRUCell(
            input_size=CONTROL_DIMENSION,
            hidden_size=STATE_DIMENSION,
        )
        self.transition_state_projection = nn.Linear(
            STATE_DIMENSION,
            STATE_DIMENSION,
        )
        actual_parameter_count = trainable_parameter_count(self)
        if actual_parameter_count != EXPECTED_PARAMETER_COUNT:
            raise RuntimeError(
                "model parameter count changed: "
                f"{actual_parameter_count} != {EXPECTED_PARAMETER_COUNT}"
            )

    def _reference(self) -> torch.Tensor:
        return self.state_projection.weight

    def _validate_history(self, history: torch.Tensor) -> int:
        if not isinstance(history, torch.Tensor) or history.ndim != 3:
            raise ValueError("history must have shape [batch, 24, 6]")
        batch_size = int(history.shape[0])
        if batch_size < 1:
            raise ValueError("history must contain at least one sample")
        _validate_tensor(
            history,
            name="history",
            shape=(batch_size, HISTORY_HOURS, len(HISTORY_STATIONS)),
            reference=self._reference(),
        )
        return batch_size

    def _validate_state(self, state: torch.Tensor) -> int:
        if not isinstance(state, torch.Tensor) or state.ndim != 2:
            raise ValueError("state must have shape [batch, 32]")
        batch_size = int(state.shape[0])
        if batch_size < 1:
            raise ValueError("state must contain at least one sample")
        _validate_tensor(
            state,
            name="state",
            shape=(batch_size, STATE_DIMENSION),
            reference=self._reference(),
        )
        return batch_size

    def _validate_future_control(
        self,
        future_control: torch.Tensor,
        *,
        batch_size: int,
    ) -> None:
        _validate_tensor(
            future_control,
            name="future_control",
            shape=(batch_size, FORECAST_HOURS, CONTROL_DIMENSION),
            reference=self._reference(),
        )

    def encode_history(self, history: torch.Tensor) -> torch.Tensor:
        """Compress standardized ``[batch,24,6]`` history to ``[batch,32]``."""

        self._validate_history(history)
        _, hidden = self.history_encoder(history)
        return self.state_projection(hidden[-1])

    def transition_step(
        self,
        state: torch.Tensor,
        control: torch.Tensor,
    ) -> torch.Tensor:
        """Advance ``[batch,32]`` state with ``[batch,2]`` control once."""

        batch_size = self._validate_state(state)
        _validate_tensor(
            control,
            name="control",
            shape=(batch_size, CONTROL_DIMENSION),
            reference=self._reference(),
        )
        candidate = self.process_cell(control, state)
        return self.transition_state_projection(candidate)

    def physical_forecast(self, state: torch.Tensor) -> torch.Tensor:
        """Return the five explicit standardized levels as an exact state view."""

        if (
            not isinstance(state, torch.Tensor)
            or state.ndim < 1
            or state.shape[-1] != STATE_DIMENSION
            or state.numel() == 0
        ):
            raise ValueError("state must have final dimension 32 and be nonempty")
        if (
            not state.dtype.is_floating_point
            or state.dtype != self._reference().dtype
            or state.device != self._reference().device
            or not bool(torch.isfinite(state).all())
        ):
            raise ValueError("state must be finite and match the model")
        return state[..., :EXPLICIT_STATE_DIMENSION]

    def forecast_from_state(
        self,
        initial_state: torch.Tensor,
        future_control: torch.Tensor,
    ) -> torch.Tensor:
        """Propagate 24 controls and return forecasts with shape ``[B,24,5]``."""

        batch_size = self._validate_state(initial_state)
        self._validate_future_control(future_control, batch_size=batch_size)
        state = initial_state
        predictions = []
        for control_index in range(FORECAST_HOURS):
            state = self.transition_step(
                state,
                future_control[:, control_index, :],
            )
            predictions.append(self.physical_forecast(state))
        return torch.stack(predictions, dim=1)

    def forward(
        self,
        history: torch.Tensor,
        future_control: torch.Tensor,
    ) -> torch.Tensor:
        """Forecast analysis hour through hour 23 as ``[batch,24,5]``."""

        batch_size = self._validate_history(history)
        self._validate_future_control(future_control, batch_size=batch_size)
        return self.forecast_from_state(
            self.encode_history(history),
            future_control,
        )


__all__ = [
    "CONTROL_DIMENSION",
    "ENCODER_HIDDEN_SIZE",
    "EXPECTED_PARAMETER_COUNT",
    "EXPLICIT_STATE_DIMENSION",
    "FORECAST_HOURS",
    "FiveSourceFiveTargetD32GRU",
    "HISTORY_HOURS",
    "HISTORY_STATIONS",
    "STATE_DIMENSION",
    "TARGET_STATIONS",
    "trainable_parameter_count",
]

