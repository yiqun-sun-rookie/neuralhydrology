#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Authorized formal Stage-A entry point for the five-target experiment.

This command has no default execution mode.  A formal invocation must supply
two externally anchored JSON documents, the single fixed SQLite usage ledger,
the fixed output root, one registered seed, one CUDA device, and the exact paid
HPC confirmation phrase.  Every formal data byte is reserved in the ledger
before its file handle is opened.  No caller-provided array or dataset is
accepted by the public entry point.

Example (paths and digests are illustrative only)::

    python scripts/modeling/run_zhenjiang_five_source_five_target_stage_a_v2.py \
      --authorization /.../authorization.json \
      --trusted-authorization-sha256 <64-lowercase-hex> \
      --usage-ledger /data1/home/sunyiq/.../evidence/stage_a_formal_data_usage.sqlite3 \
      --data-contract /.../stage_a_data_contract.json \
      --trusted-data-contract-sha256 <64-lowercase-hex> \
      --output-root /data1/home/sunyiq/.../runs \
      --seed 17 --device cuda \
      --confirmation CONFIRM_ZHENJIANG_FIVE_SOURCE_FIVE_TARGET_STAGE_A_PAID_HPC_20260904_R1
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
import hashlib
import io
import json
import math
import os
from pathlib import Path
import sys
from typing import BinaryIO, Callable, Dict, Mapping, Optional, Sequence, Tuple, Union

import numpy as np
import torch


PROJECT_ROOT = Path(__file__).resolve().parents[2]
ANALYSIS_DIR = PROJECT_ROOT / "scripts" / "analysis"
ASTRONOMICAL_TIDE_DIR = PROJECT_ROOT / "scripts" / "astronomical_tide"
for _directory in (ANALYSIS_DIR, ASTRONOMICAL_TIDE_DIR):
    if str(_directory) not in sys.path:
        sys.path.insert(0, str(_directory))

from zhenjiang_five_source_five_target_single_analysis_contract_v2 import (  # noqa: E402
    DATONG_BOUNDARY_MODE,
    EXPERIMENT_FAMILY,
    HISTORY_STATIONS,
    TARGET_STATIONS,
)
from zhenjiang_five_source_five_target_data_v2 import (  # noqa: E402
    AtomicUsageLedger,
    AuthorizedByteRange,
    AuthorizedReadRequest,
    DatongPhysicalVariableIdentity,
    FiveTargetStagePhysicalVariableIdentity,
    ImmutableDataAuthorization,
    build_data_from_arrays,
    build_split_datasets,
)
from train_zhenjiang_five_source_five_target_d32_gru_v2 import (  # noqa: E402
    ALLOWED_SEEDS,
    SELECTION_USE,
    SELECTION_YEAR,
    TRAINING_YEARS,
    StageAPartitions,
    train_stage_a,
)
import wusongkou_astronomical_tide_realtime_v2 as tide_interface  # noqa: E402


BEIJING = timezone(timedelta(hours=8))
UTC = timezone.utc
FORMAL_PURPOSE = "stage_a_training_2017_2021_and_best_epoch_selection_2022"
FORMAL_TIME_PARTITION = "2017-2022"
DATA_CONTRACT_SCHEMA = "zhenjiang-five-source-five-target-stage-a-data-v2"
EXPECTED_ROW_COUNT = 52_584
FIRST_TIME_BEIJING = "2017-01-01T00:00:00+08:00"
LAST_TIME_BEIJING = "2022-12-31T23:00:00+08:00"
FORMAL_CONFIRMATION = (
    "CONFIRM_ZHENJIANG_FIVE_SOURCE_FIVE_TARGET_"
    "STAGE_A_PAID_HPC_20260904_R1"
)
FIXED_REMOTE_EXPERIMENT_ROOT = Path(
    "/data1/home/sunyiq/"
    "zhenjiang_five_source_five_target_single_analysis_ukf_"
    "oracle_datong_20260904_r1"
)
FIXED_OUTPUT_ROOT = FIXED_REMOTE_EXPERIMENT_ROOT / "runs"
FIXED_USAGE_LEDGER = (
    FIXED_REMOTE_EXPERIMENT_ROOT
    / "evidence"
    / "stage_a_formal_data_usage.sqlite3"
)
FIXED_ATTEMPT_EVIDENCE_ROOT = (
    FIXED_REMOTE_EXPERIMENT_ROOT / "evidence" / "stage_a_attempts"
)

FEATURE_FIELDS = (
    "TIME",
    "STAGE",
    "time_beijing",
    "time_utc",
    "is_missing_for_model",
)
TARGET_FIELDS = (
    "TIME",
    "TARGET_STAGE",
    "time_beijing",
    "time_utc",
    "is_missing_for_target",
)
REALTIME_ROLE = "realtime_stage"
TARGET_ROLE = "retrospective_target"
TIDE_ROLE = "wusongkou_astronomical_tide_model"
CSV_SCOPE = "header_plus_2017_2022_rows"
FULL_FILE_SCOPE = "full_file"
FEATURE_FORMAT = "zhenjiang_realtime_feature_csv_v1"
TARGET_FORMAT = "zhenjiang_retrospective_target_csv_v1"
TIDE_FORMAT = "accepted_wusongkou_astronomical_tide_json_v1"


def _sha256_bytes(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _require_sha256(value: object, name: str) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(name + " must be a lowercase SHA-256 digest")
    return value


def _require_nonempty_text(value: object, name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(name + " must be non-empty text")
    return value


def _strict_object(pairs: Sequence[Tuple[str, object]]) -> Mapping[str, object]:
    result: Dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key: " + key)
        result[key] = value
    return result


def _strict_json_document(content: bytes, name: str) -> Mapping[str, object]:
    try:
        decoded = content.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ValueError(name + " must be UTF-8") from error
    try:
        document = json.loads(decoded, object_pairs_hook=_strict_object)
    except (TypeError, ValueError, json.JSONDecodeError) as error:
        raise ValueError(name + " must be strict JSON") from error
    if not isinstance(document, Mapping):
        raise ValueError(name + " must be one JSON object")
    return document


def _require_exact_keys(
    document: Mapping[str, object], expected: Sequence[str], name: str
) -> None:
    actual = set(document)
    required = set(expected)
    if actual != required:
        missing = sorted(required - actual)
        extra = sorted(actual - required)
        raise ValueError(
            "{} keys differ; missing={}, extra={}".format(name, missing, extra)
        )


def _read_anchored_json(
    path_value: Union[str, Path], trusted_sha256: str, name: str
) -> Tuple[Mapping[str, object], str]:
    trusted = _require_sha256(trusted_sha256, "trusted " + name + " SHA-256")
    path = Path(path_value)
    content = path.read_bytes()
    actual = _sha256_bytes(content)
    if actual != trusted:
        raise RuntimeError(name + " raw-byte SHA-256 differs from trusted anchor")
    return _strict_json_document(content, name), actual


@dataclass(frozen=True, order=True)
class FormalContentSpec:
    role: str
    station: str
    path: str
    byte_offset: int
    byte_count: int
    content_sha256: str
    verification_scope: str
    serialization_format: str

    @classmethod
    def from_document(cls, document: object) -> "FormalContentSpec":
        if not isinstance(document, Mapping):
            raise ValueError("each formal content specification must be an object")
        _require_exact_keys(
            document,
            (
                "role",
                "station",
                "path",
                "byte_offset",
                "byte_count",
                "content_sha256",
                "verification_scope",
                "serialization_format",
            ),
            "formal content specification",
        )
        role = _require_nonempty_text(document["role"], "file role")
        station = _require_nonempty_text(document["station"], "file station")
        path_text = _require_nonempty_text(document["path"], "file path")
        path = Path(path_text)
        if not path.is_absolute() or str(path.resolve()) != path_text:
            raise ValueError("formal file path must be absolute and canonical")
        byte_offset = document["byte_offset"]
        byte_count = document["byte_count"]
        if type(byte_offset) is not int or byte_offset != 0:
            raise ValueError("formal byte_offset must be integer zero")
        if type(byte_count) is not int or byte_count <= 0:
            raise ValueError("formal byte_count must be positive")
        return cls(
            role=role,
            station=station,
            path=path_text,
            byte_offset=byte_offset,
            byte_count=byte_count,
            content_sha256=_require_sha256(
                document["content_sha256"], "content_sha256"
            ),
            verification_scope=_require_nonempty_text(
                document["verification_scope"], "verification_scope"
            ),
            serialization_format=_require_nonempty_text(
                document["serialization_format"], "serialization_format"
            ),
        )

    @property
    def authorized_byte_range(self) -> AuthorizedByteRange:
        return AuthorizedByteRange(self.path, self.byte_offset, self.byte_count)


@dataclass(frozen=True)
class StageAFormalDataContract:
    schema_version: str
    experiment_family: str
    boundary_mode: str
    formal_purpose: str
    time_partition: str
    training_years: Tuple[int, ...]
    selection_year: int
    selection_use: str
    remote_experiment_root: str
    output_root: str
    usage_ledger_path: str
    expected_row_count: int
    first_time_beijing: str
    last_time_beijing: str
    datong_identity: DatongPhysicalVariableIdentity
    explicit_stage_identity: FiveTargetStagePhysicalVariableIdentity
    files: Tuple[FormalContentSpec, ...]

    @classmethod
    def from_document(cls, document: Mapping[str, object]) -> "StageAFormalDataContract":
        _require_exact_keys(
            document,
            (
                "schema_version",
                "experiment_family",
                "boundary_mode",
                "formal_purpose",
                "time_partition",
                "training_years",
                "selection_year",
                "selection_use",
                "remote_experiment_root",
                "output_root",
                "usage_ledger_path",
                "expected_row_count",
                "first_time_beijing",
                "last_time_beijing",
                "datong_physical_variable_identity",
                "explicit_stage_physical_variable_identity",
                "files",
            ),
            "formal data contract",
        )
        datong = document["datong_physical_variable_identity"]
        explicit = document["explicit_stage_physical_variable_identity"]
        if not isinstance(datong, Mapping) or not isinstance(explicit, Mapping):
            raise ValueError("physical-variable identities must be objects")
        _require_exact_keys(
            datong,
            (
                "station_identity",
                "water_level_definition",
                "unit",
                "vertical_datum",
                "timestamp_semantics",
            ),
            "Datong identity",
        )
        _require_exact_keys(
            explicit,
            (
                "station_order",
                "water_level_definition",
                "unit",
                "vertical_datum",
                "timestamp_semantics",
            ),
            "explicit-stage identity",
        )
        files_document = document["files"]
        if not isinstance(files_document, list):
            raise ValueError("files must be a JSON list")
        contract = cls(
            schema_version=_require_nonempty_text(
                document["schema_version"], "schema_version"
            ),
            experiment_family=_require_nonempty_text(
                document["experiment_family"], "experiment_family"
            ),
            boundary_mode=_require_nonempty_text(
                document["boundary_mode"], "boundary_mode"
            ),
            formal_purpose=_require_nonempty_text(
                document["formal_purpose"], "formal_purpose"
            ),
            time_partition=_require_nonempty_text(
                document["time_partition"], "time_partition"
            ),
            training_years=tuple(document["training_years"]),
            selection_year=document["selection_year"],
            selection_use=_require_nonempty_text(
                document["selection_use"], "selection_use"
            ),
            remote_experiment_root=_require_nonempty_text(
                document["remote_experiment_root"], "remote_experiment_root"
            ),
            output_root=_require_nonempty_text(document["output_root"], "output_root"),
            usage_ledger_path=_require_nonempty_text(
                document["usage_ledger_path"], "usage_ledger_path"
            ),
            expected_row_count=document["expected_row_count"],
            first_time_beijing=_require_nonempty_text(
                document["first_time_beijing"], "first_time_beijing"
            ),
            last_time_beijing=_require_nonempty_text(
                document["last_time_beijing"], "last_time_beijing"
            ),
            datong_identity=DatongPhysicalVariableIdentity(**dict(datong)),
            explicit_stage_identity=FiveTargetStagePhysicalVariableIdentity(
                station_order=tuple(explicit["station_order"]),
                water_level_definition=explicit["water_level_definition"],
                unit=explicit["unit"],
                vertical_datum=explicit["vertical_datum"],
                timestamp_semantics=explicit["timestamp_semantics"],
            ),
            files=tuple(
                FormalContentSpec.from_document(item) for item in files_document
            ),
        )
        contract.validate()
        return contract

    def validate(self) -> "StageAFormalDataContract":
        fixed_values = {
            "schema_version": (self.schema_version, DATA_CONTRACT_SCHEMA),
            "experiment_family": (self.experiment_family, EXPERIMENT_FAMILY),
            "boundary_mode": (self.boundary_mode, DATONG_BOUNDARY_MODE),
            "formal_purpose": (self.formal_purpose, FORMAL_PURPOSE),
            "time_partition": (self.time_partition, FORMAL_TIME_PARTITION),
            "training_years": (self.training_years, tuple(TRAINING_YEARS)),
            "selection_year": (self.selection_year, SELECTION_YEAR),
            "selection_use": (self.selection_use, SELECTION_USE),
            "remote_experiment_root": (
                self.remote_experiment_root,
                str(FIXED_REMOTE_EXPERIMENT_ROOT),
            ),
            "output_root": (self.output_root, str(FIXED_OUTPUT_ROOT)),
            "usage_ledger_path": (self.usage_ledger_path, str(FIXED_USAGE_LEDGER)),
            "expected_row_count": (self.expected_row_count, EXPECTED_ROW_COUNT),
            "first_time_beijing": (self.first_time_beijing, FIRST_TIME_BEIJING),
            "last_time_beijing": (self.last_time_beijing, LAST_TIME_BEIJING),
        }
        changed = [name for name, pair in fixed_values.items() if pair[0] != pair[1]]
        if changed:
            raise ValueError("formal data contract changed frozen fields: " + ", ".join(changed))
        expected_roles = {
            *((REALTIME_ROLE, station) for station in HISTORY_STATIONS),
            *((TARGET_ROLE, station) for station in TARGET_STATIONS),
            (TIDE_ROLE, "wusongkou"),
        }
        actual_roles = {(item.role, item.station) for item in self.files}
        if actual_roles != expected_roles or len(self.files) != len(expected_roles):
            raise ValueError(
                "files must contain exactly six historical stages, five targets, "
                "and one Wusongkou astronomical-tide model"
            )
        if len({item.path for item in self.files}) != len(self.files):
            raise ValueError("formal file paths must be unique")
        for item in self.files:
            if item.role == REALTIME_ROLE:
                expected = (CSV_SCOPE, FEATURE_FORMAT)
            elif item.role == TARGET_ROLE:
                expected = (CSV_SCOPE, TARGET_FORMAT)
            else:
                expected = (FULL_FILE_SCOPE, TIDE_FORMAT)
                if item.content_sha256 != tide_interface.EXPECTED_TIDE_MODEL_SHA256:
                    raise ValueError("astronomical-tide content identity changed")
            if (item.verification_scope, item.serialization_format) != expected:
                raise ValueError("formal file scope or serialization format changed")
        return self

    @property
    def file_by_role_station(self) -> Mapping[Tuple[str, str], FormalContentSpec]:
        return {(item.role, item.station): item for item in self.files}


def load_immutable_authorization(
    path: Union[str, Path], trusted_sha256: str
) -> Tuple[ImmutableDataAuthorization, str]:
    document, raw_sha256 = _read_anchored_json(
        path, trusted_sha256, "authorization document"
    )
    _require_exact_keys(
        document,
        (
            "authorization_id",
            "authorized_by",
            "authorized_at_beijing",
            "allowed_purposes",
            "allowed_time_partitions",
            "allowed_byte_ranges",
            "maximum_read_count",
            "previous_access_count_confirmed",
            "misread_events_acknowledged",
        ),
        "authorization document",
    )
    ranges = document["allowed_byte_ranges"]
    if not isinstance(ranges, list):
        raise ValueError("allowed_byte_ranges must be a JSON list")
    parsed_ranges = []
    for item in ranges:
        if not isinstance(item, Mapping):
            raise ValueError("each authorized byte range must be an object")
        _require_exact_keys(
            item, ("path", "byte_offset", "byte_count"), "authorized byte range"
        )
        parsed_ranges.append(
            AuthorizedByteRange(
                path=item["path"],
                byte_offset=item["byte_offset"],
                byte_count=item["byte_count"],
            )
        )
    authorization = ImmutableDataAuthorization(
        authorization_id=document["authorization_id"],
        authorized_by=document["authorized_by"],
        authorized_at_beijing=document["authorized_at_beijing"],
        allowed_purposes=tuple(document["allowed_purposes"]),
        allowed_time_partitions=tuple(document["allowed_time_partitions"]),
        allowed_byte_ranges=tuple(parsed_ranges),
        maximum_read_count=document["maximum_read_count"],
        previous_access_count_confirmed=document["previous_access_count_confirmed"],
        misread_events_acknowledged=document["misread_events_acknowledged"],
    )
    return authorization, raw_sha256


def load_formal_data_contract(
    path: Union[str, Path], trusted_sha256: str
) -> Tuple[StageAFormalDataContract, str]:
    document, raw_sha256 = _read_anchored_json(
        path, trusted_sha256, "formal data contract"
    )
    return StageAFormalDataContract.from_document(document), raw_sha256


def validate_authorization_binding(
    authorization: ImmutableDataAuthorization,
    contract: StageAFormalDataContract,
    ledger: AtomicUsageLedger,
    *,
    seed: int,
) -> None:
    contract.validate()
    expected_total_reads = len(contract.files) * len(ALLOWED_SEEDS)
    if authorization.maximum_read_count != expected_total_reads:
        raise ValueError(
            "formal Stage-A authorization must allow exactly 36 reads "
            "(12 files times 3 seeds)"
        )
    if authorization.previous_access_count_confirmed != 0:
        raise ValueError(
            "formal Stage-A authorization must start from a declared zero "
            "baseline in its new HPC ledger"
        )
    if set(authorization.allowed_purposes) != {FORMAL_PURPOSE}:
        raise ValueError("authorization must cover only the exact formal Stage-A purpose")
    if set(authorization.allowed_time_partitions) != {FORMAL_TIME_PARTITION}:
        raise ValueError("authorization must cover only the 2017-2022 partition")
    expected_ranges = {item.authorized_byte_range for item in contract.files}
    if set(authorization.allowed_byte_ranges) != expected_ranges:
        raise ValueError("authorization byte ranges differ from the data contract")
    seed_order = (17, 29, 43)
    if seed not in seed_order:
        raise ValueError("formal Stage-A seed order changed")
    prior_seed_count = seed_order.index(seed)
    expected_prior_read_count = len(contract.files) * prior_seed_count
    records = ledger.event_records()
    if any(
        record["authorization_id"] != authorization.authorization_id
        for record in records
    ):
        raise ValueError("formal Stage-A ledger contains a foreign authorization")
    by_reservation = defaultdict(list)
    for record in records:
        by_reservation[record["reservation_id"]].append(record)
    if len(by_reservation) != expected_prior_read_count:
        raise ValueError(
            "formal Stage-A seed does not match the exact prior-read count "
            "0/12/24"
        )
    expected_ranges = Counter(
        (
            item.path,
            item.byte_offset,
            item.byte_count,
        )
        for item in contract.files
        for _repeat in range(prior_seed_count)
    )
    observed_ranges = Counter()
    for reservation_records in by_reservation.values():
        if [record["event_type"] for record in reservation_records] != [
            "RESERVED",
            "COMPLETED",
        ]:
            raise ValueError(
                "every prior Stage-A read must be reserved and completed"
            )
        reserved, completed = reservation_records
        immutable_fields = (
            "authorization_id",
            "authorization_document_sha256",
            "purpose",
            "time_partition",
            "path",
            "byte_offset",
            "byte_count",
            "expected_remaining_read_count",
        )
        if any(reserved[field] != completed[field] for field in immutable_fields):
            raise ValueError("prior Stage-A ledger pair changed immutable fields")
        if (
            reserved["authorization_document_sha256"]
            != authorization.authorization_document_sha256
            or reserved["purpose"] != FORMAL_PURPOSE
            or reserved["time_partition"] != FORMAL_TIME_PARTITION
            or reserved["bytes_read"] != 0
            or completed["bytes_read"] != reserved["byte_count"]
        ):
            raise ValueError("prior Stage-A ledger evidence is inconsistent")
        observed_ranges[
            (
                reserved["path"],
                reserved["byte_offset"],
                reserved["byte_count"],
            )
        ] += 1
    if observed_ranges != expected_ranges:
        raise ValueError("prior Stage-A ledger does not cover each formal file exactly")
    already_reserved = ledger.reserved_read_count(authorization.authorization_id)
    if already_reserved != expected_prior_read_count:
        raise ValueError("formal Stage-A reserved count changed during validation")
    remaining = (
        authorization.maximum_read_count
        - authorization.previous_access_count_confirmed
        - already_reserved
    )
    expected_remaining = expected_total_reads - expected_prior_read_count
    if remaining != expected_remaining:
        raise ValueError("formal Stage-A remaining-read count changed")


def _required_slurm_environment(name: str) -> str:
    value = os.environ.get(name)
    if not isinstance(value, str) or not value:
        raise RuntimeError("required Slurm environment variable is missing: " + name)
    return value


def _load_hpc_first_attempt_marker(
    *, seed: int
) -> Tuple[Path, Mapping[str, object], str, str]:
    """Validate the one scheduler-created first-attempt marker for this seed."""

    job_id = _required_slurm_environment("SLURM_JOB_ID")
    stage_a_seed = _required_slurm_environment("ZHENJIANG_STAGE_A_SEED")
    sequence_index = _required_slurm_environment(
        "ZHENJIANG_STAGE_A_SEED_SEQUENCE_INDEX"
    )
    expected_sequence_index = str((17, 29, 43).index(seed) + 1)
    if stage_a_seed != str(seed) or sequence_index != expected_sequence_index:
        raise RuntimeError("sequential Stage-A seed environment changed")
    bundle_sha256 = _require_sha256(
        _required_slurm_environment(
            "ZHENJIANG_STAGE_A_BUNDLE_MANIFEST_SHA256"
        ),
        "bundle-manifest SHA-256 environment anchor",
    )
    execution_authorization_sha256 = _require_sha256(
        _required_slurm_environment(
            "ZHENJIANG_STAGE_A_EXECUTION_AUTHORIZATION_SHA256"
        ),
        "execution-authorization SHA-256 environment anchor",
    )
    attempt_directory = (
        FIXED_ATTEMPT_EVIDENCE_ROOT
        / ("seed_{}".format(seed))
        / "attempt_001"
    )
    marker_path = attempt_directory / "first_attempt_started.json"
    for path, label in (
        (FIXED_ATTEMPT_EVIDENCE_ROOT, "attempt-evidence root"),
        (attempt_directory.parent, "seed-attempt parent"),
        (attempt_directory, "first-attempt directory"),
    ):
        if path.is_symlink() or not path.is_dir():
            raise RuntimeError(label + " must be an ordinary directory")
    if marker_path.is_symlink() or not marker_path.is_file():
        raise RuntimeError("first-attempt marker must be one ordinary file")
    content = marker_path.read_bytes()
    document = _strict_json_document(content, "first-attempt marker")
    _require_exact_keys(
        document,
        (
            "schema_version",
            "experiment_family",
            "stage",
            "status",
            "seed",
            "attempt_number",
            "job_id",
            "seed_sequence_index",
            "bundle_manifest_sha256",
            "execution_authorization_sha256",
            "created_at_utc",
        ),
        "first-attempt marker",
    )
    expected = {
        "schema_version": 2,
        "experiment_family": EXPERIMENT_FAMILY,
        "stage": "stage_a",
        "status": "first_attempt_started",
        "seed": seed,
        "attempt_number": 1,
        "job_id": job_id,
        "seed_sequence_index": int(sequence_index),
        "bundle_manifest_sha256": bundle_sha256,
        "execution_authorization_sha256": execution_authorization_sha256,
    }
    changed = [name for name, value in expected.items() if document.get(name) != value]
    if changed:
        raise RuntimeError(
            "first-attempt marker changed frozen fields: " + ", ".join(changed)
        )
    created_at = document["created_at_utc"]
    if not isinstance(created_at, str) or not created_at.endswith("Z"):
        raise RuntimeError("first-attempt time must be explicit universal time")
    try:
        datetime.fromisoformat(created_at[:-1] + "+00:00")
    except ValueError as error:
        raise RuntimeError("first-attempt time is not ISO-8601") from error
    return (
        marker_path,
        document,
        bundle_sha256,
        execution_authorization_sha256,
    )


def _reserve_formal_runner_entry(
    *,
    seed: int,
    attempt_marker_path: Path,
    bundle_manifest_sha256: str,
    execution_authorization_sha256: str,
    data_authorization_sha256: str,
    data_contract_sha256: str,
) -> Tuple[Path, str]:
    """Consume this seed's only formal-runner entry before any data read."""

    entry_path = attempt_marker_path.parent / "formal_runner_entered.json"
    document = {
        "schema_version": 2,
        "experiment_family": EXPERIMENT_FAMILY,
        "stage": "stage_a",
        "status": "formal_runner_entered",
        "seed": seed,
        "attempt_number": 1,
        "job_id": _required_slurm_environment("SLURM_JOB_ID"),
        "seed_sequence_index": int(
            _required_slurm_environment(
                "ZHENJIANG_STAGE_A_SEED_SEQUENCE_INDEX"
            )
        ),
        "bundle_manifest_sha256": bundle_manifest_sha256,
        "execution_authorization_sha256": execution_authorization_sha256,
        "data_authorization_sha256": data_authorization_sha256,
        "data_contract_sha256": data_contract_sha256,
        "created_at_utc": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
    }
    content = (
        json.dumps(document, sort_keys=True, separators=(",", ":"), allow_nan=False)
        + "\n"
    ).encode("utf-8")
    try:
        with entry_path.open("xb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
    except FileExistsError as error:
        raise RuntimeError(
            "this seed has already consumed its only formal-runner attempt"
        ) from error
    return entry_path, _sha256_bytes(content)


@dataclass(frozen=True)
class FormalReadEvidence:
    role: str
    station: str
    path: str
    byte_offset: int
    byte_count: int
    content_sha256: str
    reservation_id: str
    completed_ledger_snapshot_sha256: str


def _open_unbuffered(path: Path) -> BinaryIO:
    """Open one authorized range without a buffered read-ahead layer."""

    return path.open("rb", buffering=0)


def _read_one_authorized_content(
    *,
    specification: FormalContentSpec,
    authorization: ImmutableDataAuthorization,
    ledger: AtomicUsageLedger,
    opener: Optional[Callable[[Path], BinaryIO]] = None,
) -> Tuple[bytes, FormalReadEvidence]:
    already_reserved = ledger.reserved_read_count(authorization.authorization_id)
    expected_remaining = (
        authorization.maximum_read_count
        - authorization.previous_access_count_confirmed
        - already_reserved
    )
    request = AuthorizedReadRequest(
        purpose=FORMAL_PURPOSE,
        time_partition=FORMAL_TIME_PARTITION,
        path=specification.path,
        byte_offset=specification.byte_offset,
        byte_count=specification.byte_count,
        expected_remaining_read_count=expected_remaining,
    )
    reservation_id = ledger.reserve(authorization, request)
    bytes_read = 0
    try:
        path = Path(specification.path)
        if specification.verification_scope == FULL_FILE_SCOPE:
            if path.stat().st_size != specification.byte_count:
                raise RuntimeError("full-file byte count differs from data contract")
        open_function = opener if opener is not None else _open_unbuffered
        with open_function(path) as handle:
            handle.seek(specification.byte_offset)
            content = handle.read(specification.byte_count)
        bytes_read = len(content)
        if bytes_read != specification.byte_count:
            raise RuntimeError("authorized byte range ended early")
        if _sha256_bytes(content) != specification.content_sha256:
            raise RuntimeError("formal content SHA-256 differs from data contract")
        snapshot = ledger.mark_completed(reservation_id, bytes_read=bytes_read)
    except BaseException as error:
        ledger.mark_failed(
            reservation_id,
            bytes_read=bytes_read,
            reason="{}: {}".format(type(error).__name__, str(error)),
        )
        raise
    evidence = FormalReadEvidence(
        role=specification.role,
        station=specification.station,
        path=specification.path,
        byte_offset=specification.byte_offset,
        byte_count=specification.byte_count,
        content_sha256=specification.content_sha256,
        reservation_id=reservation_id,
        completed_ledger_snapshot_sha256=snapshot,
    )
    return content, evidence


def _parse_time(value: str) -> datetime:
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None or parsed.utcoffset() != timedelta(hours=8):
        raise ValueError("formal timestamp must explicitly use Beijing +08:00")
    return parsed


def _optional_float(value: str, missing_flag: str) -> float:
    if missing_flag == "True":
        if value != "":
            raise ValueError("missing value must be empty")
        return float("nan")
    if missing_flag != "False" or value == "":
        raise ValueError("available value and missing flag disagree")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError("available value must be finite")
    return result


def _parse_csv_series(
    content: bytes, *, role: str
) -> Tuple[np.ndarray, np.ndarray]:
    if role == REALTIME_ROLE:
        expected_fields = FEATURE_FIELDS
        value_field = "STAGE"
        missing_field = "is_missing_for_model"
    elif role == TARGET_ROLE:
        expected_fields = TARGET_FIELDS
        value_field = "TARGET_STAGE"
        missing_field = "is_missing_for_target"
    else:
        raise ValueError("CSV parser received a non-CSV role")
    try:
        decoded = content.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ValueError("formal CSV must be UTF-8") from error
    times = []
    values = []
    with io.StringIO(decoded, newline="") as handle:
        reader = csv.DictReader(handle)
        if tuple(reader.fieldnames or ()) != expected_fields:
            raise RuntimeError("formal CSV fields changed")
        for row in reader:
            time = _parse_time(row["time_beijing"])
            utc_time = datetime.fromisoformat(row["time_utc"])
            if (
                row["TIME"] != row["time_beijing"]
                or utc_time.tzinfo is None
                or utc_time.utcoffset() != timedelta(0)
                or time.astimezone(UTC) != utc_time
            ):
                raise RuntimeError("Beijing and universal timestamps differ")
            if time.year < 2017 or time.year > 2022:
                raise RuntimeError("formal Stage-A prefix contains an unauthorized year")
            times.append(time)
            values.append(_optional_float(row[value_field], row[missing_field]))
    if len(times) != EXPECTED_ROW_COUNT:
        raise RuntimeError("formal Stage-A prefix row count changed")
    if (
        times[0].isoformat() != FIRST_TIME_BEIJING
        or times[-1].isoformat() != LAST_TIME_BEIJING
        or any(
            times[index] - times[index - 1] != timedelta(hours=1)
            for index in range(1, len(times))
        )
    ):
        raise RuntimeError("formal Stage-A prefix timeline changed")
    return np.asarray(times, dtype=object), np.asarray(values, dtype=np.float64)


def _tide_model_from_authorized_bytes(content: bytes):
    document = _strict_json_document(content, "Wusongkou tide model")
    records = document.get("constituents")
    if (
        document.get("model_type") != "harmonic_astronomical_tide"
        or document.get("station_slug") != "wusongkou"
        or document.get("constituent_count") != 38
        or not isinstance(records, list)
        or len(records) != 38
    ):
        raise RuntimeError("authorized astronomical-tide model identity changed")
    constituent_by_name = {
        value.name: value
        for value in vars(tide_interface.constituent).values()
        if isinstance(value, tide_interface.constituent.BaseConstituent)
    }
    objects = []
    amplitudes = []
    phases = []
    for expected_index, record in enumerate(records):
        if not isinstance(record, Mapping) or record.get("index") != expected_index:
            raise RuntimeError("authorized constituent order changed")
        name = record.get("constituent")
        if name not in constituent_by_name:
            raise RuntimeError("unknown authorized constituent")
        amplitude = float(record.get("amplitude_m"))
        phase = float(record.get("phase_degrees"))
        if not math.isfinite(amplitude) or not math.isfinite(phase):
            raise RuntimeError("authorized constituent is nonfinite")
        objects.append(constituent_by_name[name])
        amplitudes.append(amplitude)
        phases.append(phase)
    dependencies = tide_interface._verify_astronomical_dependencies()
    return tide_interface.FrozenAstronomicalTideRealtimeV2(
        tide_interface.Tide(objects, amplitudes, phases),
        constituent_count=len(objects),
        dependency_content_identities=dependencies,
    )


def _load_formal_partitions(
    *,
    contract: StageAFormalDataContract,
    authorization: ImmutableDataAuthorization,
    ledger: AtomicUsageLedger,
) -> Tuple[StageAPartitions, torch.Tensor, Mapping[str, object]]:
    contents: Dict[Tuple[str, str], bytes] = {}
    read_evidence = []
    for specification in sorted(contract.files):
        content, evidence = _read_one_authorized_content(
            specification=specification,
            authorization=authorization,
            ledger=ledger,
        )
        contents[(specification.role, specification.station)] = content
        read_evidence.append(asdict(evidence))

    canonical_times = None
    stage_columns = []
    target_columns = []
    for station in HISTORY_STATIONS:
        times, values = _parse_csv_series(
            contents[(REALTIME_ROLE, station)], role=REALTIME_ROLE
        )
        if canonical_times is None:
            canonical_times = times
        elif not np.array_equal(times, canonical_times):
            raise RuntimeError("historical-stage timelines differ")
        stage_columns.append(values)
    for station in TARGET_STATIONS:
        times, values = _parse_csv_series(
            contents[(TARGET_ROLE, station)], role=TARGET_ROLE
        )
        if canonical_times is None or not np.array_equal(times, canonical_times):
            raise RuntimeError("retrospective-target timelines differ")
        target_columns.append(values)
    if canonical_times is None:
        raise RuntimeError("formal data contract produced no timeline")
    tide_model = _tide_model_from_authorized_bytes(
        contents[(TIDE_ROLE, "wusongkou")]
    )
    tide_values = tide_model.predict_float64(canonical_times)
    data = build_data_from_arrays(
        times_beijing=canonical_times,
        realtime_stages_m=np.stack(stage_columns, axis=1),
        retrospective_targets_m=np.stack(target_columns, axis=1),
        astronomical_tide_m=tide_values,
        datong_identity=contract.datong_identity,
        explicit_stage_identity=contract.explicit_stage_identity,
    )
    datasets = build_split_datasets(data)
    partitions = StageAPartitions(
        training_dataset=datasets["training"],
        selection_dataset=datasets["selection"],
        training_years=tuple(TRAINING_YEARS),
        selection_year=SELECTION_YEAR,
    ).validate()
    normalization = data.normalization
    evidence = {
        "formal_read_evidence": read_evidence,
        "ledger_snapshot_sha256_after_all_reads": ledger.logical_snapshot_sha256(),
        "training_sample_count": len(partitions.training_dataset),
        "selection_sample_count": len(partitions.selection_dataset),
        "datong_boundary_data_identity_sha256": data.datong_boundary_data_identity_sha256,
        "explicit_stage_data_identity_sha256": data.explicit_stage_data_identity_sha256,
        "normalization_sha256": {
            "history_stage": normalization.history_stage.normalization_sha256,
            "future_wusongkou_astronomical_tide": (
                normalization.future_wusongkou_astronomical_tide.normalization_sha256
            ),
            "future_datong_observed_driver": (
                normalization.future_datong_observed_driver.normalization_sha256
            ),
            "explicit_stage": normalization.explicit_stage.normalization_sha256,
        },
    }
    scale = torch.as_tensor(
        normalization.explicit_stage.standard_deviation_m,
        dtype=torch.float32,
    )
    return partitions, scale, evidence


def _source_fingerprints() -> Mapping[str, Mapping[str, object]]:
    paths = (
        Path(__file__).resolve(),
        PROJECT_ROOT
        / "scripts"
        / "modeling"
        / "zhenjiang_five_source_five_target_data_v2.py",
        PROJECT_ROOT
        / "scripts"
        / "modeling"
        / "train_zhenjiang_five_source_five_target_d32_gru_v2.py",
        PROJECT_ROOT
        / "scripts"
        / "analysis"
        / "zhenjiang_five_source_five_target_single_analysis_contract_v2.py",
    )
    return {
        str(path): {"byte_count": path.stat().st_size, "sha256": _sha256_file(path)}
        for path in paths
    }


def _write_json_exclusive(path: Path, document: object) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(document, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")


def run_formal_stage_a(
    *,
    authorization_path: Union[str, Path],
    trusted_authorization_sha256: str,
    usage_ledger_path: Union[str, Path],
    data_contract_path: Union[str, Path],
    trusted_data_contract_sha256: str,
    output_root: Union[str, Path],
    seed: int,
    device: str,
    confirmation: str,
) -> Mapping[str, object]:
    """Execute one authorized seed exactly once; no retry is attempted."""

    if confirmation != FORMAL_CONFIRMATION:
        raise ValueError("paid-HPC confirmation phrase differs from the frozen value")
    if seed not in ALLOWED_SEEDS:
        raise ValueError("seed must be one of 17, 29, or 43")
    if device != "cuda":
        raise ValueError("formal Stage-A execution requires device='cuda'")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable; refusing any formal data read")
    output_root_path = Path(output_root)
    ledger_path = Path(usage_ledger_path)
    if output_root_path != FIXED_OUTPUT_ROOT:
        raise ValueError("output root differs from the fixed new HPC root")
    if ledger_path != FIXED_USAGE_LEDGER:
        raise ValueError("usage ledger differs from the fixed evidence path")
    seed_directory = output_root_path / "stage_a" / ("seed_{}".format(seed))
    if not seed_directory.parent.is_dir():
        raise FileNotFoundError("fixed Stage-A output parent must already exist")
    if seed_directory.exists():
        raise FileExistsError("refusing to reuse any seed output directory")

    authorization, authorization_raw_sha256 = load_immutable_authorization(
        authorization_path, trusted_authorization_sha256
    )
    contract, data_contract_raw_sha256 = load_formal_data_contract(
        data_contract_path, trusted_data_contract_sha256
    )
    if contract.output_root != str(output_root_path):
        raise ValueError("CLI output root differs from the trusted data contract")
    if contract.usage_ledger_path != str(ledger_path):
        raise ValueError("CLI ledger differs from the trusted data contract")
    ledger = AtomicUsageLedger(ledger_path)
    validate_authorization_binding(
        authorization,
        contract,
        ledger,
        seed=seed,
    )
    (
        attempt_marker_path,
        _attempt_marker,
        bundle_manifest_sha256,
        execution_authorization_sha256,
    ) = _load_hpc_first_attempt_marker(seed=seed)
    runner_entry_path, runner_entry_sha256 = _reserve_formal_runner_entry(
        seed=seed,
        attempt_marker_path=attempt_marker_path,
        bundle_manifest_sha256=bundle_manifest_sha256,
        execution_authorization_sha256=execution_authorization_sha256,
        data_authorization_sha256=authorization_raw_sha256,
        data_contract_sha256=data_contract_raw_sha256,
    )
    partitions, scale, input_evidence = _load_formal_partitions(
        contract=contract,
        authorization=authorization,
        ledger=ledger,
    )
    training_manifest = train_stage_a(
        partitions=partitions,
        explicit_stage_standard_deviations_m=scale,
        seed=seed,
        device=device,
        output_directory=seed_directory,
    )
    receipt = {
        "schema_version": 2,
        "experiment_family": EXPERIMENT_FAMILY,
        "boundary_mode": DATONG_BOUNDARY_MODE,
        "stage": "stage_a",
        "status": "complete",
        "seed": seed,
        "seed_sequence_index": int(
            _attempt_marker["seed_sequence_index"]
        ),
        "formal_purpose": FORMAL_PURPOSE,
        "time_partition": FORMAL_TIME_PARTITION,
        "authorization_path": str(Path(authorization_path).resolve()),
        "authorization_raw_byte_sha256": authorization_raw_sha256,
        "authorization_canonical_document_sha256": (
            authorization.authorization_document_sha256
        ),
        "data_contract_path": str(Path(data_contract_path).resolve()),
        "data_contract_raw_byte_sha256": data_contract_raw_sha256,
        "usage_ledger_path": str(ledger_path),
        "first_attempt_marker_path": str(attempt_marker_path),
        "formal_runner_entry_path": str(runner_entry_path),
        "formal_runner_entry_sha256": runner_entry_sha256,
        "bundle_manifest_sha256": bundle_manifest_sha256,
        "execution_authorization_sha256": execution_authorization_sha256,
        "final_usage_ledger_snapshot_sha256": ledger.logical_snapshot_sha256(),
        "output_directory": str(seed_directory),
        "training_completion_manifest_sha256": _sha256_file(
            seed_directory / "completion_manifest.json"
        ),
        "source_fingerprints": _source_fingerprints(),
        "input_evidence": input_evidence,
        "best_epoch": training_manifest["best_epoch"],
        "best_selection_mean_absolute_error_m": training_manifest[
            "best_selection_mean_absolute_error_m"
        ],
    }
    _write_json_exclusive(seed_directory / "formal_run_receipt.json", receipt)
    return receipt


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--authorization", required=True)
    parser.add_argument("--trusted-authorization-sha256", required=True)
    parser.add_argument("--usage-ledger", required=True)
    parser.add_argument("--data-contract", required=True)
    parser.add_argument("--trusted-data-contract-sha256", required=True)
    parser.add_argument(
        "--output-root",
        "--output-directory",
        dest="output_root",
        required=True,
    )
    parser.add_argument("--seed", type=int, choices=ALLOWED_SEEDS, required=True)
    parser.add_argument("--device", choices=("cuda",), required=True)
    parser.add_argument("--confirmation", required=True)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    arguments = build_argument_parser().parse_args(argv)
    receipt = run_formal_stage_a(
        authorization_path=arguments.authorization,
        trusted_authorization_sha256=arguments.trusted_authorization_sha256,
        usage_ledger_path=arguments.usage_ledger,
        data_contract_path=arguments.data_contract,
        trusted_data_contract_sha256=arguments.trusted_data_contract_sha256,
        output_root=arguments.output_root,
        seed=arguments.seed,
        device=arguments.device,
        confirmation=arguments.confirmation,
    )
    print(json.dumps(receipt, indent=2, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
