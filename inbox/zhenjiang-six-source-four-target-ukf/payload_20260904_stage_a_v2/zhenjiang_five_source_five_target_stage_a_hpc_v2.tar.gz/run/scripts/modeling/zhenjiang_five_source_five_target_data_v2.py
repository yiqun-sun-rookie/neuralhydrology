#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Five-source, five-target synthetic-first data and access contract.

This module deliberately contains no registered production path and no default
production loader.  Array construction is therefore the only data entry point
until a separately approved authorization document and content identity are
available.  Authorized byte reads reserve a SQLite usage slot before the data
file opener is called; an uncompleted reservation still consumes its slot.

Example (synthetic arrays only):
    data = build_data_from_arrays(
        times_beijing=times,
        realtime_stages_m=realtime_stages,
        retrospective_targets_m=targets,
        astronomical_tide_m=astronomical_tide,
        datong_identity=identity,
        explicit_stage_identity=five_target_identity,
    )
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
from typing import BinaryIO, Callable, Dict, Mapping, Optional, Sequence, Tuple, Union
import uuid

import numpy as np
import torch
from torch.utils.data import Dataset


PROJECT_ROOT = Path(__file__).resolve().parents[2]
ANALYSIS_DIR = PROJECT_ROOT / "scripts" / "analysis"
if str(ANALYSIS_DIR) not in sys.path:
    sys.path.insert(0, str(ANALYSIS_DIR))

from zhenjiang_five_source_five_target_single_analysis_contract_v2 import (  # noqa: E402
    CONTROL_HOURS,
    DATONG_BOUNDARY_MODE,
    HISTORY_HOURS,
    HISTORY_STATIONS,
    OBSERVATION_STATIONS,
    POST_ANALYSIS_FORECAST_HOURS,
    STAGE_A_TARGET_HOURS,
    TARGET_STATIONS,
)


BEIJING = timezone(timedelta(hours=8))
UTC = timezone.utc
TRAIN_YEARS = (2017, 2018, 2019, 2020, 2021)
SELECTION_YEAR = 2022
DEVELOPMENT_YEAR = 2023
HELDOUT_YEAR = 2024
BOUNDARY_MODE = DATONG_BOUNDARY_MODE

NORMALIZATION_HISTORY_STAGE = "history_stage"
NORMALIZATION_FUTURE_WUSONGKOU_ASTRONOMICAL_TIDE = (
    "future_wusongkou_astronomical_tide"
)
NORMALIZATION_FUTURE_DATONG_OBSERVED_DRIVER = "future_datong_observed_driver"
NORMALIZATION_EXPLICIT_STAGE = "explicit_stage"

CONTROL_SEQUENCE_SCHEMA_VERSION = "zhenjiang-control-sequence-v2"
CONTROL_SEQUENCE_CHANNEL_ORDER = (
    "wusongkou_astronomical_tide",
    "datong_observed_boundary",
)

_LEDGER_EVENT_TYPES = ("RESERVED", "COMPLETED", "FAILED", "DENIED")


def _canonical_json_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _require_nonempty_text(value: object, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be non-empty text")
    return value


def _require_sha256(value: object, field_name: str) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(f"{field_name} must be a lowercase SHA-256 digest")
    return value


def _canonical_analysis_time_beijing(value: object) -> str:
    if isinstance(value, datetime):
        instant = value
    elif isinstance(value, str):
        try:
            instant = datetime.fromisoformat(value)
        except ValueError as error:
            raise ValueError(
                "analysis_time_beijing must be an ISO-8601 timestamp"
            ) from error
    else:
        raise ValueError("analysis_time_beijing must be text or datetime")
    if instant.tzinfo is None or instant.utcoffset() != timedelta(hours=8):
        raise ValueError("analysis_time_beijing must explicitly use +08:00")
    return instant.isoformat()


def canonical_control_sequence_bytes(
    future_control: torch.Tensor,
    *,
    analysis_time_beijing: object,
    future_wusongkou_astronomical_tide_normalization_sha256: str,
    future_datong_observed_driver_normalization_sha256: str,
    datong_boundary_data_identity_sha256: str,
    boundary_mode: str = BOUNDARY_MODE,
) -> bytes:
    """Encode the exact normalized ``[24,2]`` model control contract.

    The JSON header has one trailing newline.  The tensor payload immediately
    following it is contiguous row-major IEEE-754 little-endian float32.  No
    generic tensor digest is accepted as a substitute for this semantic
    envelope.
    """

    if not isinstance(future_control, torch.Tensor):
        raise ValueError("future_control must be the actual torch tensor")
    if future_control.shape != (CONTROL_HOURS, 2):
        raise ValueError("future_control must have shape [24,2]")
    if future_control.dtype != torch.float32:
        raise ValueError("future_control must use float32")
    if not bool(torch.isfinite(future_control).all()):
        raise ValueError("future_control contains a nonfinite value")
    if boundary_mode != BOUNDARY_MODE:
        raise ValueError("only retrospective_observed_oracle is permitted")
    header = {
        "schema_version": CONTROL_SEQUENCE_SCHEMA_VERSION,
        "shape": [CONTROL_HOURS, 2],
        "dtype": "<f4",
        "channel_order": list(CONTROL_SEQUENCE_CHANNEL_ORDER),
        "analysis_time_beijing": _canonical_analysis_time_beijing(
            analysis_time_beijing
        ),
        "boundary_mode": boundary_mode,
        "future_wusongkou_astronomical_tide_normalization_sha256": (
            _require_sha256(
                future_wusongkou_astronomical_tide_normalization_sha256,
                "future_wusongkou_astronomical_tide_normalization_sha256",
            )
        ),
        "future_datong_observed_driver_normalization_sha256": _require_sha256(
            future_datong_observed_driver_normalization_sha256,
            "future_datong_observed_driver_normalization_sha256",
        ),
        "datong_boundary_data_identity_sha256": _require_sha256(
            datong_boundary_data_identity_sha256,
            "datong_boundary_data_identity_sha256",
        ),
    }
    array = (
        future_control.detach()
        .to(device="cpu")
        .contiguous()
        .numpy()
        .astype(np.dtype("<f4"), copy=False)
    )
    return _canonical_json_bytes(header) + b"\n" + array.tobytes(order="C")


def canonical_control_sequence_sha256(
    future_control: torch.Tensor,
    **header_fields: object,
) -> str:
    """Hash the exact semantic control bytes accepted by the model."""

    return _sha256_bytes(
        canonical_control_sequence_bytes(future_control, **header_fields)
    )


def _event_time_utc() -> str:
    return datetime.now(UTC).isoformat(timespec="microseconds")


@dataclass(frozen=True, order=True)
class AuthorizedByteRange:
    """One exact path and byte interval covered by an authorization."""

    path: str
    byte_offset: int
    byte_count: int

    def __post_init__(self) -> None:
        _require_nonempty_text(self.path, "path")
        if type(self.byte_offset) is not int or self.byte_offset < 0:
            raise ValueError("byte_offset must be a non-negative integer")
        if type(self.byte_count) is not int or self.byte_count <= 0:
            raise ValueError("byte_count must be a positive integer")

    def canonical_document(self) -> Mapping[str, object]:
        return {
            "path": self.path,
            "byte_offset": self.byte_offset,
            "byte_count": self.byte_count,
        }


@dataclass(frozen=True)
class ImmutableDataAuthorization:
    """Machine-readable immutable authorization body.

    The SHA-256 is a computed envelope property, not a field embedded in the
    body itself.  This mirrors the rule that the source authorization document
    does not contain its own digest.
    """

    authorization_id: str
    authorized_by: str
    authorized_at_beijing: str
    allowed_purposes: Tuple[str, ...]
    allowed_time_partitions: Tuple[str, ...]
    allowed_byte_ranges: Tuple[AuthorizedByteRange, ...]
    maximum_read_count: int
    previous_access_count_confirmed: int
    misread_events_acknowledged: bool

    def __post_init__(self) -> None:
        _require_nonempty_text(self.authorization_id, "authorization_id")
        _require_nonempty_text(self.authorized_by, "authorized_by")
        _require_nonempty_text(
            self.authorized_at_beijing, "authorized_at_beijing"
        )
        try:
            authorized_at = datetime.fromisoformat(self.authorized_at_beijing)
        except ValueError as error:
            raise ValueError("authorized_at_beijing must be ISO-8601") from error
        if authorized_at.tzinfo is None or authorized_at.utcoffset() != timedelta(
            hours=8
        ):
            raise ValueError("authorized_at_beijing must carry the +08:00 offset")

        purposes = tuple(self.allowed_purposes)
        partitions = tuple(self.allowed_time_partitions)
        byte_ranges = tuple(self.allowed_byte_ranges)
        if not purposes or any(
            not isinstance(value, str) or not value.strip() for value in purposes
        ):
            raise ValueError("allowed_purposes must contain non-empty text")
        if len(set(purposes)) != len(purposes):
            raise ValueError("allowed_purposes must not contain duplicates")
        if not partitions or any(
            not isinstance(value, str) or not value.strip() for value in partitions
        ):
            raise ValueError(
                "allowed_time_partitions must contain non-empty text"
            )
        if len(set(partitions)) != len(partitions):
            raise ValueError("allowed_time_partitions must not contain duplicates")
        partition_text = " ".join(partitions)
        if "2023" in partition_text and "2024" in partition_text:
            raise ValueError("2023 and 2024 cannot share one authorization record")
        if not byte_ranges or any(
            not isinstance(value, AuthorizedByteRange) for value in byte_ranges
        ):
            raise ValueError(
                "allowed_byte_ranges must contain AuthorizedByteRange objects"
            )
        if len(set(byte_ranges)) != len(byte_ranges):
            raise ValueError("allowed_byte_ranges must not contain duplicates")
        if type(self.maximum_read_count) is not int or self.maximum_read_count < 0:
            raise ValueError("maximum_read_count must be a non-negative integer")
        if (
            type(self.previous_access_count_confirmed) is not int
            or self.previous_access_count_confirmed < 0
            or self.previous_access_count_confirmed > self.maximum_read_count
        ):
            raise ValueError(
                "previous_access_count_confirmed must be between zero and the maximum"
            )
        if type(self.misread_events_acknowledged) is not bool:
            raise ValueError("misread_events_acknowledged must be Boolean")
        object.__setattr__(self, "allowed_purposes", purposes)
        object.__setattr__(self, "allowed_time_partitions", partitions)
        object.__setattr__(self, "allowed_byte_ranges", byte_ranges)

    def canonical_document(self) -> Mapping[str, object]:
        return {
            "authorization_id": self.authorization_id,
            "authorized_by": self.authorized_by,
            "authorized_at_beijing": self.authorized_at_beijing,
            "allowed_purposes": list(self.allowed_purposes),
            "allowed_time_partitions": list(self.allowed_time_partitions),
            "allowed_byte_ranges": [
                value.canonical_document() for value in self.allowed_byte_ranges
            ],
            "maximum_read_count": self.maximum_read_count,
            "previous_access_count_confirmed": (
                self.previous_access_count_confirmed
            ),
            "misread_events_acknowledged": self.misread_events_acknowledged,
        }

    @property
    def authorization_document_sha256(self) -> str:
        return _sha256_bytes(_canonical_json_bytes(self.canonical_document()))

    @property
    def remaining_read_count_at_issue(self) -> int:
        return self.maximum_read_count - self.previous_access_count_confirmed

    # Read-only compatibility names used by evaluation-only validators.  They
    # are properties rather than duplicate stored fields, so the canonical
    # authorization body remains singular and immutable.
    @property
    def authorized_at(self) -> str:
        return self.authorized_at_beijing

    @property
    def allowed_paths_or_byte_ranges(self) -> Tuple[AuthorizedByteRange, ...]:
        return self.allowed_byte_ranges

    @property
    def max_read_count(self) -> int:
        return self.maximum_read_count

    @property
    def prior_access_count_confirmed(self) -> int:
        return self.previous_access_count_confirmed


@dataclass(frozen=True)
class AuthorizedReadRequest:
    """One exact requested use of an immutable authorization."""

    purpose: str
    time_partition: str
    path: str
    byte_offset: int
    byte_count: int
    expected_remaining_read_count: int

    def __post_init__(self) -> None:
        _require_nonempty_text(self.purpose, "purpose")
        _require_nonempty_text(self.time_partition, "time_partition")
        _require_nonempty_text(self.path, "path")
        if type(self.byte_offset) is not int or self.byte_offset < 0:
            raise ValueError("byte_offset must be a non-negative integer")
        if type(self.byte_count) is not int or self.byte_count <= 0:
            raise ValueError("byte_count must be a positive integer")
        if (
            type(self.expected_remaining_read_count) is not int
            or self.expected_remaining_read_count < 0
        ):
            raise ValueError(
                "expected_remaining_read_count must be a non-negative integer"
            )

    @property
    def byte_range(self) -> AuthorizedByteRange:
        return AuthorizedByteRange(
            path=self.path,
            byte_offset=self.byte_offset,
            byte_count=self.byte_count,
        )


@dataclass(frozen=True)
class AuthorizedReadResult:
    """Immutable evidence returned by one completed authorized byte read."""

    content: bytes
    reservation_id: str
    completed_ledger_snapshot_sha256: str

    def __post_init__(self) -> None:
        if type(self.content) is not bytes:
            raise ValueError("content must be immutable bytes")
        _require_nonempty_text(self.reservation_id, "reservation_id")
        _require_sha256(
            self.completed_ledger_snapshot_sha256,
            "completed_ledger_snapshot_sha256",
        )


class ReadAuthorizationDenied(RuntimeError):
    """Raised before a data file handle is opened when a request is denied."""


class AtomicUsageLedger:
    """SQLite append-only usage ledger with exclusive atomic reservations."""

    def __init__(self, database_path: Union[str, Path]) -> None:
        self.database_path = Path(database_path)
        if not self.database_path.parent.exists():
            raise ValueError("usage-ledger parent directory must already exist")
        connection = self._connect()
        try:
            connection.execute("BEGIN EXCLUSIVE")
            self._ensure_schema(connection)
            connection.commit()
        except BaseException:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(
            str(self.database_path),
            timeout=30.0,
            isolation_level=None,
        )
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA busy_timeout = 30000")
        connection.execute("PRAGMA synchronous = FULL")
        return connection

    @staticmethod
    def _ensure_schema(connection: sqlite3.Connection) -> None:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS authorization_baselines (
                authorization_id TEXT PRIMARY KEY,
                authorization_document_sha256 TEXT NOT NULL,
                previous_access_count_confirmed INTEGER NOT NULL,
                maximum_read_count INTEGER NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS usage_events (
                event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                reservation_id TEXT NOT NULL,
                event_type TEXT NOT NULL CHECK (
                    event_type IN ('RESERVED', 'COMPLETED', 'FAILED', 'DENIED')
                ),
                authorization_id TEXT NOT NULL,
                authorization_document_sha256 TEXT NOT NULL,
                purpose TEXT NOT NULL,
                time_partition TEXT NOT NULL,
                path TEXT NOT NULL,
                byte_offset INTEGER NOT NULL,
                byte_count INTEGER NOT NULL,
                expected_remaining_read_count INTEGER NOT NULL,
                bytes_read INTEGER NOT NULL,
                reason TEXT NOT NULL,
                created_at_utc TEXT NOT NULL,
                UNIQUE (reservation_id, event_type)
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS reservation_identifiers (
                reservation_id TEXT PRIMARY KEY,
                first_seen_at_utc TEXT NOT NULL
            )
            """
        )
        # Upgrade ledgers created before reservation identifiers were a
        # separate global namespace.  Each historical identifier is claimed
        # exactly once, even though a successful request legitimately has both
        # RESERVED and COMPLETED events carrying that identifier.
        connection.execute(
            """
            INSERT OR IGNORE INTO reservation_identifiers (
                reservation_id,
                first_seen_at_utc
            )
            SELECT reservation_id, MIN(created_at_utc)
            FROM usage_events
            GROUP BY reservation_id
            """
        )

    @staticmethod
    def _insert_event(
        connection: sqlite3.Connection,
        *,
        reservation_id: str,
        event_type: str,
        authorization: ImmutableDataAuthorization,
        request: AuthorizedReadRequest,
        bytes_read: int,
        reason: str,
    ) -> None:
        if event_type not in _LEDGER_EVENT_TYPES:
            raise ValueError("unknown ledger event type")
        connection.execute(
            """
            INSERT INTO usage_events (
                reservation_id,
                event_type,
                authorization_id,
                authorization_document_sha256,
                purpose,
                time_partition,
                path,
                byte_offset,
                byte_count,
                expected_remaining_read_count,
                bytes_read,
                reason,
                created_at_utc
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                reservation_id,
                event_type,
                authorization.authorization_id,
                authorization.authorization_document_sha256,
                request.purpose,
                request.time_partition,
                request.path,
                request.byte_offset,
                request.byte_count,
                request.expected_remaining_read_count,
                bytes_read,
                reason,
                _event_time_utc(),
            ),
        )

    @staticmethod
    def _registration_mismatch_reason(
        row: sqlite3.Row,
        authorization: ImmutableDataAuthorization,
    ) -> Optional[str]:
        if (
            row["authorization_document_sha256"]
            != authorization.authorization_document_sha256
        ):
            return "authorization body SHA-256 differs from its registered baseline"
        if (
            row["previous_access_count_confirmed"]
            != authorization.previous_access_count_confirmed
        ):
            return "previous access count confirmation differs from its baseline"
        if row["maximum_read_count"] != authorization.maximum_read_count:
            return "maximum read count differs from its registered baseline"
        return None

    def reserve(
        self,
        authorization: ImmutableDataAuthorization,
        request: AuthorizedReadRequest,
        *,
        reservation_id: Optional[str] = None,
    ) -> str:
        """Atomically consume a read slot before any data opener may run."""

        if not isinstance(authorization, ImmutableDataAuthorization):
            raise ValueError("ImmutableDataAuthorization is required")
        if not isinstance(request, AuthorizedReadRequest):
            raise ValueError("AuthorizedReadRequest is required")
        identifier = (
            str(uuid.uuid4()) if reservation_id is None else reservation_id
        )
        _require_nonempty_text(identifier, "reservation_id")
        connection = self._connect()
        try:
            connection.execute("BEGIN EXCLUSIVE")
            self._ensure_schema(connection)
            already_claimed = connection.execute(
                """
                SELECT 1 FROM reservation_identifiers
                WHERE reservation_id = ?
                """,
                (identifier,),
            ).fetchone()
            if already_claimed is not None:
                connection.commit()
                raise ReadAuthorizationDenied(
                    "reservation_id has already been used by an earlier request"
                )
            connection.execute(
                """
                INSERT INTO reservation_identifiers (
                    reservation_id,
                    first_seen_at_utc
                ) VALUES (?, ?)
                """,
                (identifier, _event_time_utc()),
            )
            baseline = connection.execute(
                """
                SELECT authorization_document_sha256,
                       previous_access_count_confirmed,
                       maximum_read_count
                FROM authorization_baselines
                WHERE authorization_id = ?
                """,
                (authorization.authorization_id,),
            ).fetchone()
            denial_reason: Optional[str] = None
            if baseline is None:
                connection.execute(
                    """
                    INSERT INTO authorization_baselines (
                        authorization_id,
                        authorization_document_sha256,
                        previous_access_count_confirmed,
                        maximum_read_count
                    ) VALUES (?, ?, ?, ?)
                    """,
                    (
                        authorization.authorization_id,
                        authorization.authorization_document_sha256,
                        authorization.previous_access_count_confirmed,
                        authorization.maximum_read_count,
                    ),
                )
            else:
                denial_reason = self._registration_mismatch_reason(
                    baseline, authorization
                )

            reserved_count = int(
                connection.execute(
                    """
                    SELECT COUNT(*)
                    FROM usage_events
                    WHERE authorization_id = ? AND event_type = 'RESERVED'
                    """,
                    (authorization.authorization_id,),
                ).fetchone()[0]
            )
            remaining_count = (
                authorization.maximum_read_count
                - authorization.previous_access_count_confirmed
                - reserved_count
            )
            if denial_reason is None and not authorization.misread_events_acknowledged:
                denial_reason = "misread events have not been acknowledged"
            if (
                denial_reason is None
                and request.purpose not in authorization.allowed_purposes
            ):
                denial_reason = "requested purpose is not authorized"
            if (
                denial_reason is None
                and request.time_partition
                not in authorization.allowed_time_partitions
            ):
                denial_reason = "requested time partition is not authorized"
            if (
                denial_reason is None
                and request.byte_range not in authorization.allowed_byte_ranges
            ):
                denial_reason = "requested path or byte range is not authorized"
            if (
                denial_reason is None
                and request.expected_remaining_read_count != remaining_count
            ):
                denial_reason = (
                    "expected remaining read count does not match the atomic ledger"
                )
            if denial_reason is None and remaining_count <= 0:
                denial_reason = "no remaining read authorization"

            if denial_reason is not None:
                self._insert_event(
                    connection,
                    reservation_id=identifier,
                    event_type="DENIED",
                    authorization=authorization,
                    request=request,
                    bytes_read=0,
                    reason=denial_reason,
                )
                connection.commit()
                raise ReadAuthorizationDenied(denial_reason)

            self._insert_event(
                connection,
                reservation_id=identifier,
                event_type="RESERVED",
                authorization=authorization,
                request=request,
                bytes_read=0,
                reason="read slot atomically reserved before data handle open",
            )
            connection.commit()
            return identifier
        except ReadAuthorizationDenied:
            raise
        except BaseException:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _append_terminal_event(
        self,
        reservation_id: str,
        *,
        event_type: str,
        bytes_read: int,
        reason: str,
    ) -> str:
        if event_type not in ("COMPLETED", "FAILED"):
            raise ValueError("terminal event must be COMPLETED or FAILED")
        if type(bytes_read) is not int or bytes_read < 0:
            raise ValueError("bytes_read must be a non-negative integer")
        connection = self._connect()
        try:
            connection.execute("BEGIN EXCLUSIVE")
            reserved = connection.execute(
                """
                SELECT * FROM usage_events
                WHERE reservation_id = ? AND event_type = 'RESERVED'
                """,
                (reservation_id,),
            ).fetchone()
            if reserved is None:
                raise ValueError("terminal event requires an existing reservation")
            terminal_count = int(
                connection.execute(
                    """
                    SELECT COUNT(*) FROM usage_events
                    WHERE reservation_id = ?
                      AND event_type IN ('COMPLETED', 'FAILED')
                    """,
                    (reservation_id,),
                ).fetchone()[0]
            )
            if terminal_count != 0:
                raise ValueError("reservation already has a terminal event")
            connection.execute(
                """
                INSERT INTO usage_events (
                    reservation_id,
                    event_type,
                    authorization_id,
                    authorization_document_sha256,
                    purpose,
                    time_partition,
                    path,
                    byte_offset,
                    byte_count,
                    expected_remaining_read_count,
                    bytes_read,
                    reason,
                    created_at_utc
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    reservation_id,
                    event_type,
                    reserved["authorization_id"],
                    reserved["authorization_document_sha256"],
                    reserved["purpose"],
                    reserved["time_partition"],
                    reserved["path"],
                    reserved["byte_offset"],
                    reserved["byte_count"],
                    reserved["expected_remaining_read_count"],
                    bytes_read,
                    reason,
                    _event_time_utc(),
                ),
            )
            completed_snapshot_sha256 = self._logical_snapshot_sha256_from_connection(
                connection
            )
            connection.commit()
            return completed_snapshot_sha256
        except BaseException:
            connection.rollback()
            raise
        finally:
            connection.close()

    def mark_completed(self, reservation_id: str, *, bytes_read: int) -> str:
        """Append COMPLETED and return the exact committed logical snapshot hash."""

        return self._append_terminal_event(
            reservation_id,
            event_type="COMPLETED",
            bytes_read=bytes_read,
            reason="authorized byte range read completely",
        )

    def mark_failed(
        self,
        reservation_id: str,
        *,
        bytes_read: int,
        reason: str,
    ) -> str:
        return self._append_terminal_event(
            reservation_id,
            event_type="FAILED",
            bytes_read=bytes_read,
            reason=_require_nonempty_text(reason, "reason"),
        )

    def reserved_read_count(self, authorization_id: str) -> int:
        _require_nonempty_text(authorization_id, "authorization_id")
        connection = self._connect()
        try:
            self._ensure_schema(connection)
            return int(
                connection.execute(
                    """
                    SELECT COUNT(*) FROM usage_events
                    WHERE authorization_id = ? AND event_type = 'RESERVED'
                    """,
                    (authorization_id,),
                ).fetchone()[0]
            )
        finally:
            connection.close()

    def event_records(self) -> Tuple[Mapping[str, object], ...]:
        connection = self._connect()
        try:
            self._ensure_schema(connection)
            rows = connection.execute(
                "SELECT * FROM usage_events ORDER BY event_id"
            ).fetchall()
            return tuple(dict(row) for row in rows)
        finally:
            connection.close()

    @staticmethod
    def _logical_snapshot_sha256_from_connection(
        connection: sqlite3.Connection,
    ) -> str:
        rows = connection.execute(
            "SELECT * FROM usage_events ORDER BY event_id"
        ).fetchall()
        return _sha256_bytes(_canonical_json_bytes([dict(row) for row in rows]))

    def logical_snapshot_bytes(self) -> bytes:
        """Return canonical logical JSON, never raw SQLite page bytes."""

        return _canonical_json_bytes(list(self.event_records()))

    def logical_snapshot_sha256(self) -> str:
        return _sha256_bytes(self.logical_snapshot_bytes())


def read_authorized_bytes(
    *,
    authorization: ImmutableDataAuthorization,
    request: AuthorizedReadRequest,
    ledger: AtomicUsageLedger,
    opener: Optional[Callable[[Path], BinaryIO]] = None,
) -> bytes:
    """Compatibility wrapper returning only the immutable byte content."""

    return read_authorized_bytes_with_evidence(
        authorization=authorization,
        request=request,
        ledger=ledger,
        opener=opener,
    ).content


def read_authorized_bytes_with_evidence(
    *,
    authorization: ImmutableDataAuthorization,
    request: AuthorizedReadRequest,
    ledger: AtomicUsageLedger,
    opener: Optional[Callable[[Path], BinaryIO]] = None,
    reservation_id: Optional[str] = None,
) -> AuthorizedReadResult:
    """Read exact bytes and return their durable COMPLETED-ledger evidence."""

    if not isinstance(ledger, AtomicUsageLedger):
        raise ValueError("AtomicUsageLedger is required")
    completed_reservation_id = ledger.reserve(
        authorization,
        request,
        reservation_id=reservation_id,
    )
    open_function = opener if opener is not None else lambda path: path.open("rb")
    bytes_read = 0
    try:
        with open_function(Path(request.path)) as handle:
            handle.seek(request.byte_offset)
            content = handle.read(request.byte_count)
            bytes_read = len(content)
        if type(content) is not bytes:
            raise RuntimeError("authorized byte reader must return immutable bytes")
        if bytes_read != request.byte_count:
            raise RuntimeError("authorized byte range ended before its byte count")
    except BaseException as error:
        ledger.mark_failed(
            completed_reservation_id,
            bytes_read=bytes_read,
            reason=f"{type(error).__name__}: {error}",
        )
        raise
    completed_snapshot_sha256 = ledger.mark_completed(
        completed_reservation_id,
        bytes_read=bytes_read,
    )
    return AuthorizedReadResult(
        content=content,
        reservation_id=completed_reservation_id,
        completed_ledger_snapshot_sha256=completed_snapshot_sha256,
    )


@dataclass(frozen=True)
class DatongPhysicalVariableIdentity:
    """Five evidence fields defining one Datong total-stage variable."""

    station_identity: str
    water_level_definition: str
    unit: str
    vertical_datum: str
    timestamp_semantics: str

    def __post_init__(self) -> None:
        for field_name in (
            "station_identity",
            "water_level_definition",
            "unit",
            "vertical_datum",
            "timestamp_semantics",
        ):
            _require_nonempty_text(getattr(self, field_name), field_name)

    def canonical_document(self) -> Mapping[str, str]:
        return {
            "station_identity": self.station_identity,
            "water_level_definition": self.water_level_definition,
            "unit": self.unit,
            "vertical_datum": self.vertical_datum,
            "timestamp_semantics": self.timestamp_semantics,
        }


@dataclass(frozen=True)
class FiveTargetStagePhysicalVariableIdentity:
    """Five evidence fields shared by observations and retrospective targets."""

    station_order: Tuple[str, ...]
    water_level_definition: str
    unit: str
    vertical_datum: str
    timestamp_semantics: str

    def __post_init__(self) -> None:
        stations = tuple(self.station_order)
        if stations != tuple(TARGET_STATIONS):
            raise ValueError(
                "five-target stage identity must use the frozen station order"
            )
        for field_name in (
            "water_level_definition",
            "unit",
            "vertical_datum",
            "timestamp_semantics",
        ):
            _require_nonempty_text(getattr(self, field_name), field_name)
        object.__setattr__(self, "station_order", stations)

    def canonical_document(self) -> Mapping[str, object]:
        return {
            "station_order": list(self.station_order),
            "water_level_definition": self.water_level_definition,
            "unit": self.unit,
            "vertical_datum": self.vertical_datum,
            "timestamp_semantics": self.timestamp_semantics,
        }


def physical_variable_identity_sha256(
    identity: Union[
        DatongPhysicalVariableIdentity,
        FiveTargetStagePhysicalVariableIdentity,
    ],
) -> str:
    if not isinstance(
        identity,
        (DatongPhysicalVariableIdentity, FiveTargetStagePhysicalVariableIdentity),
    ):
        raise ValueError("a registered physical-variable identity is required")
    return _sha256_bytes(_canonical_json_bytes(identity.canonical_document()))


def validate_datong_boundary_identity(
    history_identity: DatongPhysicalVariableIdentity,
    future_boundary_identity: DatongPhysicalVariableIdentity,
    datong_boundary_data_identity_sha256: str,
) -> None:
    """Require identical station, quantity, unit, datum, and time meaning."""

    if (
        not isinstance(history_identity, DatongPhysicalVariableIdentity)
        or not isinstance(
            future_boundary_identity, DatongPhysicalVariableIdentity
        )
        or history_identity != future_boundary_identity
    ):
        raise ValueError("Datong history and future boundary five-field identity differs")
    _require_sha256(
        datong_boundary_data_identity_sha256,
        "datong_boundary_data_identity_sha256",
    )
    expected = physical_variable_identity_sha256(history_identity)
    if datong_boundary_data_identity_sha256 != expected:
        raise ValueError("Datong boundary identity SHA-256 does not match its record")


def validate_explicit_stage_identity(
    realtime_observation_identity: FiveTargetStagePhysicalVariableIdentity,
    retrospective_target_identity: FiveTargetStagePhysicalVariableIdentity,
    explicit_stage_data_identity_sha256: str,
) -> None:
    """Require equal station, quantity, unit, datum, and timestamp meaning."""

    if (
        not isinstance(
            realtime_observation_identity,
            FiveTargetStagePhysicalVariableIdentity,
        )
        or not isinstance(
            retrospective_target_identity,
            FiveTargetStagePhysicalVariableIdentity,
        )
        or realtime_observation_identity != retrospective_target_identity
    ):
        raise ValueError(
            "realtime observations and retrospective targets have different "
            "five-field identities"
        )
    _require_sha256(
        explicit_stage_data_identity_sha256,
        "explicit_stage_data_identity_sha256",
    )
    expected = physical_variable_identity_sha256(realtime_observation_identity)
    if explicit_stage_data_identity_sha256 != expected:
        raise ValueError("explicit-stage identity SHA-256 does not match its record")


def _readonly_float_array(value: object, field_name: str) -> np.ndarray:
    try:
        array = np.array(value, dtype=np.float64, copy=True)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{field_name} must be numeric") from error
    array.setflags(write=False)
    return array


def _readonly_object_array(value: object, field_name: str) -> np.ndarray:
    array = np.array(value, dtype=object, copy=True)
    if array.ndim != 1:
        raise ValueError(f"{field_name} must be one-dimensional")
    array.setflags(write=False)
    return array


def _validate_beijing_timeline(times_beijing: object) -> np.ndarray:
    times = _readonly_object_array(times_beijing, "times_beijing")
    if len(times) < HISTORY_HOURS + CONTROL_HOURS:
        raise ValueError("timeline is too short for one complete 48-hour sample")
    for timestamp in times:
        if (
            not isinstance(timestamp, datetime)
            or timestamp.tzinfo is None
            or timestamp.utcoffset() != timedelta(hours=8)
        ):
            raise ValueError("every timestamp must be a +08:00 Beijing datetime")
    if any(
        times[index] - times[index - 1] != timedelta(hours=1)
        for index in range(1, len(times))
    ):
        raise ValueError("timeline must be strictly unique and hourly")
    return times


def normalization_timestamp_manifest_sha256(
    *,
    role: str,
    station_order: Sequence[str],
    timestamps_beijing: Sequence[datetime],
) -> str:
    """Hash the exact unique-time manifest used by one population statistic."""

    _require_nonempty_text(role, "role")
    stations = tuple(station_order)
    if not stations or any(
        not isinstance(station, str) or not station for station in stations
    ):
        raise ValueError("station_order must contain non-empty station names")
    timestamps = tuple(timestamps_beijing)
    if not timestamps:
        raise ValueError("normalization timestamp manifest must not be empty")
    if len(set(timestamps)) != len(timestamps):
        raise ValueError("normalization timestamp manifest must be unique")
    if tuple(sorted(timestamps)) != timestamps:
        raise ValueError("normalization timestamp manifest must be chronological")
    for timestamp in timestamps:
        if (
            not isinstance(timestamp, datetime)
            or timestamp.tzinfo is None
            or timestamp.utcoffset() != timedelta(hours=8)
        ):
            raise ValueError("normalization timestamps must use Beijing +08:00")
    document = {
        "role": role,
        "station_order": list(stations),
        "ddof": 0,
        "unique_timestamps_beijing": [
            timestamp.isoformat() for timestamp in timestamps
        ],
    }
    return _sha256_bytes(_canonical_json_bytes(document))


@dataclass(frozen=True)
class SpaceNormalization:
    """Population statistics with a non-interchangeable semantic role."""

    role: str
    station_order: Tuple[str, ...]
    mean_m: np.ndarray
    std_m: np.ndarray
    unique_timestamp_count: int
    unique_timestamp_manifest_sha256: str
    ddof: int = 0

    def __post_init__(self) -> None:
        _require_nonempty_text(self.role, "role")
        stations = tuple(self.station_order)
        if not stations or any(
            not isinstance(station, str) or not station for station in stations
        ):
            raise ValueError("station_order must contain non-empty station names")
        means = _readonly_float_array(self.mean_m, "mean_m")
        standard_deviations = _readonly_float_array(self.std_m, "std_m")
        if means.shape != (len(stations),) or standard_deviations.shape != (
            len(stations),
        ):
            raise ValueError("normalization vectors must match station_order")
        if not np.isfinite(means).all() or not np.isfinite(
            standard_deviations
        ).all():
            raise ValueError("normalization statistics must be finite")
        if np.any(standard_deviations <= 0.0):
            raise ValueError("normalization standard deviations must be positive")
        if (
            type(self.unique_timestamp_count) is not int
            or self.unique_timestamp_count <= 0
        ):
            raise ValueError("unique_timestamp_count must be a positive integer")
        _require_sha256(
            self.unique_timestamp_manifest_sha256,
            "unique_timestamp_manifest_sha256",
        )
        if self.ddof != 0:
            raise ValueError("normalization must use population standard deviation ddof=0")
        object.__setattr__(self, "station_order", stations)
        object.__setattr__(self, "mean_m", means)
        object.__setattr__(self, "std_m", standard_deviations)

    def normalize(self, values_m: object) -> np.ndarray:
        values = np.asarray(values_m, dtype=np.float64)
        width = len(self.station_order)
        if width == 1 and values.ndim == 1:
            return (values - self.mean_m[0]) / self.std_m[0]
        if values.ndim < 1 or values.shape[-1] != width:
            raise ValueError(f"values do not match normalization role {self.role}")
        return (values - self.mean_m) / self.std_m

    @property
    def normalization_sha256(self) -> str:
        """Hash the role, timestamp manifest, and exact fitted float64 values."""

        document = {
            "schema_version": "2.0",
            "role": self.role,
            "station_order": list(self.station_order),
            "ddof": self.ddof,
            "unique_timestamp_count": self.unique_timestamp_count,
            "unique_timestamp_manifest_sha256": (
                self.unique_timestamp_manifest_sha256
            ),
            "mean_m_float64_hex": [float(value).hex() for value in self.mean_m],
            "std_m_float64_hex": [float(value).hex() for value in self.std_m],
        }
        return _sha256_bytes(_canonical_json_bytes(document))


@dataclass(frozen=True)
class FourSpaceNormalization:
    """The four and only four fitted coordinate roles."""

    history_stage: SpaceNormalization
    future_wusongkou_astronomical_tide: SpaceNormalization
    future_datong_observed_driver: SpaceNormalization
    explicit_stage: SpaceNormalization

    def __post_init__(self) -> None:
        validate_four_space_normalization(self)


def _validate_space_role(
    space: SpaceNormalization,
    *,
    role: str,
    station_order: Tuple[str, ...],
) -> None:
    if not isinstance(space, SpaceNormalization):
        raise ValueError(f"{role} must be a SpaceNormalization")
    if space.role != role or space.station_order != station_order:
        raise ValueError(f"normalization identity mismatch for {role}")


def validate_four_space_normalization(
    normalization: FourSpaceNormalization,
) -> None:
    if not isinstance(normalization, FourSpaceNormalization):
        raise ValueError("FourSpaceNormalization is required")
    _validate_space_role(
        normalization.history_stage,
        role=NORMALIZATION_HISTORY_STAGE,
        station_order=tuple(HISTORY_STATIONS),
    )
    _validate_space_role(
        normalization.future_wusongkou_astronomical_tide,
        role=NORMALIZATION_FUTURE_WUSONGKOU_ASTRONOMICAL_TIDE,
        station_order=("wusongkou_astronomical_tide",),
    )
    _validate_space_role(
        normalization.future_datong_observed_driver,
        role=NORMALIZATION_FUTURE_DATONG_OBSERVED_DRIVER,
        station_order=("datong",),
    )
    _validate_space_role(
        normalization.explicit_stage,
        role=NORMALIZATION_EXPLICIT_STAGE,
        station_order=tuple(TARGET_STATIONS),
    )


@dataclass(frozen=True, order=True)
class SampleRecord:
    """One complete rolling origin indexed by its analysis time a."""

    analysis_index: int
    analysis_time_beijing: datetime

    def __post_init__(self) -> None:
        if type(self.analysis_index) is not int or self.analysis_index < HISTORY_HOURS:
            raise ValueError("analysis_index cannot precede its 24-hour history")
        timestamp = self.analysis_time_beijing
        if (
            not isinstance(timestamp, datetime)
            or timestamp.tzinfo is None
            or timestamp.utcoffset() != timedelta(hours=8)
        ):
            raise ValueError("analysis_time_beijing must use Beijing +08:00")


def _valid_origin_manifest_sha256(records: Sequence[SampleRecord]) -> str:
    return _sha256_bytes(
        _canonical_json_bytes(
            [
                {
                    "analysis_index": record.analysis_index,
                    "analysis_time_beijing": record.analysis_time_beijing.isoformat(),
                }
                for record in records
            ]
        )
    )


@dataclass(frozen=True)
class PartitionRecordSet:
    """Disjoint candidate accounting for one natural-year partition."""

    partition_name: str
    raw_candidate_count: int
    cross_year_excluded_count: int
    missing_excluded_count: int
    valid_count: int
    valid_analysis_time_manifest_sha256: str
    records: Tuple[SampleRecord, ...]

    def __post_init__(self) -> None:
        _require_nonempty_text(self.partition_name, "partition_name")
        records = tuple(self.records)
        for field_name in (
            "raw_candidate_count",
            "cross_year_excluded_count",
            "missing_excluded_count",
            "valid_count",
        ):
            value = getattr(self, field_name)
            if type(value) is not int or value < 0:
                raise ValueError(f"{field_name} must be a non-negative integer")
        if self.raw_candidate_count != (
            self.cross_year_excluded_count
            + self.missing_excluded_count
            + self.valid_count
        ):
            raise ValueError("partition candidate accounting is not exhaustive")
        if self.valid_count != len(records):
            raise ValueError("valid_count differs from the valid record list")
        expected_manifest = _valid_origin_manifest_sha256(records)
        if self.valid_analysis_time_manifest_sha256 != expected_manifest:
            raise ValueError("valid analysis-time manifest SHA-256 changed")
        object.__setattr__(self, "records", records)


@dataclass(frozen=True)
class RecordEnumeration:
    """Immutable valid origins and exclusion counts for every partition."""

    partitions: Tuple[PartitionRecordSet, ...]

    def __post_init__(self) -> None:
        partitions = tuple(self.partitions)
        names = tuple(partition.partition_name for partition in partitions)
        if len(names) != len(set(names)):
            raise ValueError("partition names must be unique")
        object.__setattr__(self, "partitions", partitions)

    @property
    def valid_records(self) -> Tuple[SampleRecord, ...]:
        return tuple(
            sorted(
                (
                    record
                    for partition in self.partitions
                    for record in partition.records
                ),
                key=lambda record: record.analysis_index,
            )
        )

    def records_for_partition(self, partition_name: str) -> Tuple[SampleRecord, ...]:
        for partition in self.partitions:
            if partition.partition_name == partition_name:
                return partition.records
        return ()


def _partition_name_for_year(year: int) -> str:
    if year in TRAIN_YEARS:
        return "training"
    if year == SELECTION_YEAR:
        return "selection"
    if year == DEVELOPMENT_YEAR:
        return "development_2023"
    if year == HELDOUT_YEAR:
        return "heldout_2024"
    return f"unsupported_{year}"


def _validate_array_shapes(
    *,
    times_beijing: np.ndarray,
    realtime_stages_m: np.ndarray,
    retrospective_targets_m: np.ndarray,
    astronomical_tide_m: np.ndarray,
) -> None:
    row_count = len(times_beijing)
    if realtime_stages_m.shape != (row_count, len(HISTORY_STATIONS)):
        raise ValueError("realtime_stages_m must have shape [time, 6]")
    if retrospective_targets_m.shape != (row_count, len(TARGET_STATIONS)):
        raise ValueError("retrospective_targets_m must have shape [time, 5]")
    if astronomical_tide_m.shape != (row_count,):
        raise ValueError("astronomical_tide_m must have shape [time]")


def enumerate_record_sets(
    *,
    times_beijing: object,
    realtime_stages_m: object,
    retrospective_targets_m: object,
    astronomical_tide_m: object,
) -> RecordEnumeration:
    """Apply the unique fixed slices and exclude cross-year or incomplete origins."""

    times = _validate_beijing_timeline(times_beijing)
    stages = np.asarray(realtime_stages_m, dtype=np.float64)
    targets = np.asarray(retrospective_targets_m, dtype=np.float64)
    tide = np.asarray(astronomical_tide_m, dtype=np.float64)
    _validate_array_shapes(
        times_beijing=times,
        realtime_stages_m=stages,
        retrospective_targets_m=targets,
        astronomical_tide_m=tide,
    )
    mutable: Dict[str, Dict[str, object]] = {}
    final_analysis_index = len(times) - CONTROL_HOURS
    for analysis_index in range(HISTORY_HOURS, final_analysis_index + 1):
        analysis_time = times[analysis_index]
        partition_name = _partition_name_for_year(analysis_time.year)
        row = mutable.setdefault(
            partition_name,
            {"raw": 0, "cross": 0, "missing": 0, "records": []},
        )
        row["raw"] = int(row["raw"]) + 1
        complete_times = times[
            analysis_index - HISTORY_HOURS : analysis_index + CONTROL_HOURS
        ]
        if any(timestamp.year != analysis_time.year for timestamp in complete_times):
            row["cross"] = int(row["cross"]) + 1
            continue

        history = stages[analysis_index - HISTORY_HOURS : analysis_index]
        future_tide = tide[analysis_index : analysis_index + CONTROL_HOURS]
        future_datong = stages[
            analysis_index : analysis_index + CONTROL_HOURS, 0
        ]
        analysis_observations = stages[analysis_index, 1:6]
        future_targets = targets[
            analysis_index : analysis_index + STAGE_A_TARGET_HOURS, :5
        ]
        if not all(
            np.isfinite(values).all()
            for values in (
                history,
                future_tide,
                future_datong,
                analysis_observations,
                future_targets,
            )
        ):
            row["missing"] = int(row["missing"]) + 1
            continue
        records = row["records"]
        assert isinstance(records, list)
        records.append(SampleRecord(analysis_index, analysis_time))

    partitions = []
    for partition_name, values in mutable.items():
        records = tuple(values["records"])
        partitions.append(
            PartitionRecordSet(
                partition_name=partition_name,
                raw_candidate_count=int(values["raw"]),
                cross_year_excluded_count=int(values["cross"]),
                missing_excluded_count=int(values["missing"]),
                valid_count=len(records),
                valid_analysis_time_manifest_sha256=(
                    _valid_origin_manifest_sha256(records)
                ),
                records=records,
            )
        )
    return RecordEnumeration(tuple(partitions))


def _unique_positions(
    records: Sequence[SampleRecord],
    offsets: np.ndarray,
) -> np.ndarray:
    positions = np.asarray(
        [record.analysis_index for record in records], dtype=np.int64
    )
    return np.unique((positions[:, None] + offsets[None, :]).reshape(-1))


def _fit_space(
    *,
    role: str,
    station_order: Tuple[str, ...],
    timestamps_beijing: np.ndarray,
    values_m: np.ndarray,
) -> SpaceNormalization:
    values = np.asarray(values_m, dtype=np.float64)
    if values.ndim == 1:
        values = values[:, None]
    if values.shape != (len(timestamps_beijing), len(station_order)):
        raise ValueError(f"normalization values have the wrong shape for {role}")
    if not np.isfinite(values).all():
        raise ValueError(f"normalization values are non-finite for {role}")
    means = np.mean(values, axis=0, dtype=np.float64)
    standard_deviations = np.std(values, axis=0, ddof=0, dtype=np.float64)
    if not np.isfinite(standard_deviations).all() or np.any(
        standard_deviations <= 0.0
    ):
        raise ValueError(f"normalization standard deviation is invalid for {role}")
    return SpaceNormalization(
        role=role,
        station_order=station_order,
        mean_m=means,
        std_m=standard_deviations,
        unique_timestamp_count=len(timestamps_beijing),
        unique_timestamp_manifest_sha256=(
            normalization_timestamp_manifest_sha256(
                role=role,
                station_order=station_order,
                timestamps_beijing=timestamps_beijing,
            )
        ),
        ddof=0,
    )


def fit_four_space_normalization(
    *,
    times_beijing: object,
    realtime_stages_m: object,
    retrospective_targets_m: object,
    astronomical_tide_m: object,
    training_records: Sequence[SampleRecord],
) -> FourSpaceNormalization:
    """Fit four population statistics on unique 2017--2021 timestamps only."""

    times = _validate_beijing_timeline(times_beijing)
    stages = np.asarray(realtime_stages_m, dtype=np.float64)
    targets = np.asarray(retrospective_targets_m, dtype=np.float64)
    tide = np.asarray(astronomical_tide_m, dtype=np.float64)
    _validate_array_shapes(
        times_beijing=times,
        realtime_stages_m=stages,
        retrospective_targets_m=targets,
        astronomical_tide_m=tide,
    )
    records = tuple(training_records)
    if not records:
        raise ValueError("at least one valid training record is required")
    if len(set(records)) != len(records):
        raise ValueError("training records must not contain duplicates")
    if any(record.analysis_time_beijing.year not in TRAIN_YEARS for record in records):
        raise ValueError("normalization records must belong only to 2017-2021")
    if any(
        record.analysis_index >= len(times)
        or times[record.analysis_index] != record.analysis_time_beijing
        for record in records
    ):
        raise ValueError("training record does not match the supplied timeline")

    history_positions = _unique_positions(
        records, np.arange(-HISTORY_HOURS, 0, dtype=np.int64)
    )
    control_positions = _unique_positions(
        records, np.arange(0, CONTROL_HOURS, dtype=np.int64)
    )
    history_times = times[history_positions]
    control_times = times[control_positions]
    normalization = FourSpaceNormalization(
        history_stage=_fit_space(
            role=NORMALIZATION_HISTORY_STAGE,
            station_order=tuple(HISTORY_STATIONS),
            timestamps_beijing=history_times,
            values_m=stages[history_positions],
        ),
        future_wusongkou_astronomical_tide=_fit_space(
            role=NORMALIZATION_FUTURE_WUSONGKOU_ASTRONOMICAL_TIDE,
            station_order=("wusongkou_astronomical_tide",),
            timestamps_beijing=control_times,
            values_m=tide[control_positions],
        ),
        future_datong_observed_driver=_fit_space(
            role=NORMALIZATION_FUTURE_DATONG_OBSERVED_DRIVER,
            station_order=("datong",),
            timestamps_beijing=control_times,
            values_m=stages[control_positions, 0],
        ),
        explicit_stage=_fit_space(
            role=NORMALIZATION_EXPLICIT_STAGE,
            station_order=tuple(TARGET_STATIONS),
            timestamps_beijing=control_times,
            values_m=targets[control_positions, :5],
        ),
    )
    validate_four_space_normalization(normalization)
    return normalization


@dataclass(frozen=True)
class FiveSourceFiveTargetData:
    """Aligned arrays with one identity and one shared explicit-stage space."""

    times_beijing: np.ndarray
    realtime_stages_m: np.ndarray
    retrospective_targets_m: np.ndarray
    astronomical_tide_m: np.ndarray
    datong_identity: DatongPhysicalVariableIdentity
    history_datong_identity: DatongPhysicalVariableIdentity
    future_datong_boundary_identity: DatongPhysicalVariableIdentity
    datong_boundary_data_identity_sha256: str
    explicit_stage_identity: FiveTargetStagePhysicalVariableIdentity
    realtime_observation_identity: FiveTargetStagePhysicalVariableIdentity
    retrospective_target_identity: FiveTargetStagePhysicalVariableIdentity
    explicit_stage_data_identity_sha256: str
    record_enumeration: RecordEnumeration
    normalization: FourSpaceNormalization
    boundary_mode: str = BOUNDARY_MODE

    def __post_init__(self) -> None:
        times = _validate_beijing_timeline(self.times_beijing)
        stages = _readonly_float_array(self.realtime_stages_m, "realtime_stages_m")
        targets = _readonly_float_array(
            self.retrospective_targets_m, "retrospective_targets_m"
        )
        tide = _readonly_float_array(self.astronomical_tide_m, "astronomical_tide_m")
        _validate_array_shapes(
            times_beijing=times,
            realtime_stages_m=stages,
            retrospective_targets_m=targets,
            astronomical_tide_m=tide,
        )
        if not isinstance(self.datong_identity, DatongPhysicalVariableIdentity):
            raise ValueError("datong_identity is required")
        if (
            self.datong_identity is not self.history_datong_identity
            or self.datong_identity is not self.future_datong_boundary_identity
        ):
            raise ValueError(
                "history and future Datong must reference one identity object"
            )
        validate_datong_boundary_identity(
            self.history_datong_identity,
            self.future_datong_boundary_identity,
            self.datong_boundary_data_identity_sha256,
        )
        if (
            self.explicit_stage_identity is not self.realtime_observation_identity
            or self.explicit_stage_identity is not self.retrospective_target_identity
        ):
            raise ValueError(
                "observations and targets must reference one explicit-stage "
                "identity object"
            )
        validate_explicit_stage_identity(
            self.realtime_observation_identity,
            self.retrospective_target_identity,
            self.explicit_stage_data_identity_sha256,
        )
        if not isinstance(self.record_enumeration, RecordEnumeration):
            raise ValueError("RecordEnumeration is required")
        validate_four_space_normalization(self.normalization)
        if self.boundary_mode != BOUNDARY_MODE:
            raise ValueError("only retrospective_observed_oracle is permitted")
        object.__setattr__(self, "times_beijing", times)
        object.__setattr__(self, "realtime_stages_m", stages)
        object.__setattr__(self, "retrospective_targets_m", targets)
        object.__setattr__(self, "astronomical_tide_m", tide)

    @property
    def analysis_observation_normalization(self) -> SpaceNormalization:
        return self.normalization.explicit_stage

    @property
    def target_normalization(self) -> SpaceNormalization:
        return self.normalization.explicit_stage


def build_data_from_arrays(
    *,
    times_beijing: object,
    realtime_stages_m: object,
    retrospective_targets_m: object,
    astronomical_tide_m: object,
    datong_identity: DatongPhysicalVariableIdentity,
    explicit_stage_identity: FiveTargetStagePhysicalVariableIdentity,
) -> FiveSourceFiveTargetData:
    """Build the complete contract from aligned arrays without file access."""

    times = _validate_beijing_timeline(times_beijing)
    stages = np.asarray(realtime_stages_m, dtype=np.float64)
    targets = np.asarray(retrospective_targets_m, dtype=np.float64)
    tide = np.asarray(astronomical_tide_m, dtype=np.float64)
    _validate_array_shapes(
        times_beijing=times,
        realtime_stages_m=stages,
        retrospective_targets_m=targets,
        astronomical_tide_m=tide,
    )
    if not isinstance(datong_identity, DatongPhysicalVariableIdentity):
        raise ValueError("DatongPhysicalVariableIdentity is required")
    if not isinstance(
        explicit_stage_identity, FiveTargetStagePhysicalVariableIdentity
    ):
        raise ValueError("FiveTargetStagePhysicalVariableIdentity is required")
    enumeration = enumerate_record_sets(
        times_beijing=times,
        realtime_stages_m=stages,
        retrospective_targets_m=targets,
        astronomical_tide_m=tide,
    )
    training_records = enumeration.records_for_partition("training")
    normalization = fit_four_space_normalization(
        times_beijing=times,
        realtime_stages_m=stages,
        retrospective_targets_m=targets,
        astronomical_tide_m=tide,
        training_records=training_records,
    )
    identity_sha256 = physical_variable_identity_sha256(datong_identity)
    explicit_identity_sha256 = physical_variable_identity_sha256(
        explicit_stage_identity
    )
    return FiveSourceFiveTargetData(
        times_beijing=times,
        realtime_stages_m=stages,
        retrospective_targets_m=targets,
        astronomical_tide_m=tide,
        datong_identity=datong_identity,
        history_datong_identity=datong_identity,
        future_datong_boundary_identity=datong_identity,
        datong_boundary_data_identity_sha256=identity_sha256,
        explicit_stage_identity=explicit_stage_identity,
        realtime_observation_identity=explicit_stage_identity,
        retrospective_target_identity=explicit_stage_identity,
        explicit_stage_data_identity_sha256=explicit_identity_sha256,
        record_enumeration=enumeration,
        normalization=normalization,
        boundary_mode=BOUNDARY_MODE,
    )


def _float32_tensor(values: object) -> torch.Tensor:
    return torch.from_numpy(np.asarray(values, dtype=np.float32).copy())


class FiveSourceFiveTargetDataset(Dataset):
    """Return one fixed-slice normalized sample with a two-channel control."""

    def __init__(
        self,
        data: FiveSourceFiveTargetData,
        records: Sequence[SampleRecord],
    ) -> None:
        if not isinstance(data, FiveSourceFiveTargetData):
            raise ValueError("FiveSourceFiveTargetData is required")
        validate_four_space_normalization(data.normalization)
        self.data = data
        self.records = tuple(records)
        registered = frozenset(data.record_enumeration.valid_records)
        if any(record not in registered for record in self.records):
            raise ValueError("dataset records must be registered valid records")

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, index: int) -> Mapping[str, object]:
        if type(index) is not int or index < 0 or index >= len(self.records):
            raise IndexError("dataset index must be an in-range integer")
        record = self.records[index]
        analysis_index = record.analysis_index
        history_m = self.data.realtime_stages_m[
            analysis_index - HISTORY_HOURS : analysis_index
        ]
        future_tide_m = self.data.astronomical_tide_m[
            analysis_index : analysis_index + CONTROL_HOURS
        ]
        future_datong_m = self.data.realtime_stages_m[
            analysis_index : analysis_index + CONTROL_HOURS, 0
        ]
        observations_m = self.data.realtime_stages_m[analysis_index, 1:6]
        targets_m = self.data.retrospective_targets_m[
            analysis_index : analysis_index + STAGE_A_TARGET_HOURS, :5
        ]
        if (
            history_m.shape != (HISTORY_HOURS, len(HISTORY_STATIONS))
            or future_tide_m.shape != (CONTROL_HOURS,)
            or future_datong_m.shape != (CONTROL_HOURS,)
            or observations_m.shape != (len(OBSERVATION_STATIONS),)
            or targets_m.shape
            != (STAGE_A_TARGET_HOURS, len(TARGET_STATIONS))
            or not all(
                np.isfinite(values).all()
                for values in (
                    history_m,
                    future_tide_m,
                    future_datong_m,
                    observations_m,
                    targets_m,
                )
            )
        ):
            raise ValueError("registered sample no longer satisfies its shape contract")

        normalization = self.data.normalization
        history = _float32_tensor(normalization.history_stage.normalize(history_m))
        future_tide = _float32_tensor(
            normalization.future_wusongkou_astronomical_tide.normalize(
                future_tide_m
            )
        )
        future_datong = _float32_tensor(
            normalization.future_datong_observed_driver.normalize(future_datong_m)
        )
        future_control = torch.stack((future_tide, future_datong), dim=-1)
        explicit_stage = normalization.explicit_stage
        analysis_observations = _float32_tensor(
            explicit_stage.normalize(observations_m)
        )
        targets = _float32_tensor(explicit_stage.normalize(targets_m))
        if (
            history.shape != (24, 6)
            or future_control.shape != (24, 2)
            or analysis_observations.shape != (5,)
            or targets.shape != (24, 5)
            or targets[1:].shape != (POST_ANALYSIS_FORECAST_HOURS, 5)
        ):
            raise RuntimeError("normalized sample shape changed")
        model_inputs = {
            "history": history,
            "future_control": future_control,
            "analysis_observations": analysis_observations,
        }
        return {
            "history": history,
            "future_wusongkou_astronomical_tide": future_tide,
            "future_datong_observed_stage": future_datong,
            "future_wusongkou_astronomical_tide_m": torch.from_numpy(
                np.asarray(future_tide_m, dtype=np.float64).copy()
            ),
            "future_datong_observed_boundary_m": torch.from_numpy(
                np.asarray(future_datong_m, dtype=np.float64).copy()
            ),
            "future_control": future_control,
            "analysis_observations": analysis_observations,
            "targets_a_to_a_plus_23": targets,
            "targets_a_plus_1_to_a_plus_23": targets[1:],
            "model_inputs": model_inputs,
            "control_sequence_sha256": canonical_control_sequence_sha256(
                future_control,
                analysis_time_beijing=record.analysis_time_beijing,
                future_wusongkou_astronomical_tide_normalization_sha256=(
                    normalization.future_wusongkou_astronomical_tide.normalization_sha256
                ),
                future_datong_observed_driver_normalization_sha256=(
                    normalization.future_datong_observed_driver.normalization_sha256
                ),
                datong_boundary_data_identity_sha256=(
                    self.data.datong_boundary_data_identity_sha256
                ),
                boundary_mode=self.data.boundary_mode,
            ),
            "datong_boundary_data_identity_sha256": (
                self.data.datong_boundary_data_identity_sha256
            ),
            "explicit_stage_data_identity_sha256": (
                self.data.explicit_stage_data_identity_sha256
            ),
            "explicit_stage_manifest_sha256": (
                explicit_stage.unique_timestamp_manifest_sha256
            ),
            "history_stage_normalization_sha256": (
                normalization.history_stage.normalization_sha256
            ),
            "future_wusongkou_astronomical_tide_normalization_sha256": (
                normalization.future_wusongkou_astronomical_tide.normalization_sha256
            ),
            "future_datong_observed_driver_normalization_sha256": (
                normalization.future_datong_observed_driver.normalization_sha256
            ),
            "explicit_stage_normalization_sha256": (
                normalization.explicit_stage.normalization_sha256
            ),
            "boundary_mode": self.data.boundary_mode,
            "analysis_index": analysis_index,
            "analysis_time_beijing": record.analysis_time_beijing.isoformat(),
        }


def build_split_datasets(
    data: FiveSourceFiveTargetData,
) -> Mapping[str, FiveSourceFiveTargetDataset]:
    """Build the frozen 2017--2021 training and 2022 selection partitions."""

    if not isinstance(data, FiveSourceFiveTargetData):
        raise ValueError("FiveSourceFiveTargetData is required")
    return {
        partition_name: FiveSourceFiveTargetDataset(
            data, data.record_enumeration.records_for_partition(partition_name)
        )
        for partition_name in ("training", "selection")
    }
