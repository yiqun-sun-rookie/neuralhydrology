#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Machine-readable contract for the five-source, five-target experiment.

The module freezes station roles, the rolling-origin time axis, tensor shapes,
the 5-by-5 directional matrix, statistical gates, and the only allowed model
interfaces.  It does not load data, execute a model, or write results.

Example:
    python scripts/analysis/zhenjiang_five_source_five_target_single_analysis_contract_v2.py --self-check
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from types import MappingProxyType
from typing import Dict, Iterable, Mapping, Sequence, Tuple


EXPERIMENT_FAMILY = (
    "ZHENJIANG_FIVE_SOURCE_FIVE_TARGET_D32_GRU_"
    "SINGLE_ANALYSIS_UKF_ORACLE_DATONG_V2"
)

HISTORY_STATIONS: Tuple[str, ...] = (
    "datong",
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
OBSERVATION_STATIONS: Tuple[str, ...] = (
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
TARGET_STATIONS: Tuple[str, ...] = OBSERVATION_STATIONS
INTERNAL_STATIONS: Tuple[str, ...] = OBSERVATION_STATIONS[:-1]
WUSONGKOU_STATION = "wusongkou"
RANDOM_SEEDS: Tuple[int, ...] = (17, 29, 43)

DATONG_BOUNDARY_MODE = "retrospective_observed_oracle"
ALLOWED_DATONG_BOUNDARY_MODES: Tuple[str, ...] = (DATONG_BOUNDARY_MODE,)

HISTORY_HOURS = 24
CONTROL_HOURS = 24
STAGE_A_TARGET_HOURS = 24
POST_ANALYSIS_FORECAST_HOURS = 23
STATE_DIMENSION = 32
ANALYSIS_SIGMA_POINT_COUNT = 65

HISTORY_HOUR_OFFSETS: Tuple[int, ...] = tuple(range(-24, 0))
FULL_SAMPLE_HOUR_OFFSETS: Tuple[int, ...] = tuple(range(-24, 24))
CONTROL_HOUR_OFFSETS: Tuple[int, ...] = tuple(range(0, 24))
STAGE_A_TARGET_HOUR_OFFSETS: Tuple[int, ...] = tuple(range(0, 24))
POST_ANALYSIS_FORECAST_HOUR_OFFSETS: Tuple[int, ...] = tuple(range(1, 24))
ANALYSIS_HOUR_OFFSET = 0
ANALYSIS_CONTROL_INDEX = 0
POST_ANALYSIS_CONTROL_INDICES: Tuple[int, ...] = tuple(range(1, 24))
UNSCENTED_ANALYSIS_PREDICTION_TRANSITION = (-1, 0)
ANALYSIS_UPDATE_HOUR_OFFSET = 0
ENCODER_CALLS_PER_ANALYSIS_ORIGIN = 1
BRANCHES_SHARE_HISTORY_ENCODING = True
REENCODE_WITHIN_TRAJECTORY = False
ROLLING_ORIGIN_STEP_HOURS = 1

CONTROL_CHANNELS: Tuple[str, ...] = (
    "future_wusongkou_astronomical_tide",
    "future_datong_observed_stage",
)

TIMELINE: Mapping[str, Tuple[int, ...]] = MappingProxyType(
    {
        "history": HISTORY_HOUR_OFFSETS,
        "full_sample": FULL_SAMPLE_HOUR_OFFSETS,
        "future_datong_observed_stage": CONTROL_HOUR_OFFSETS,
        "future_wusongkou_astronomical_tide": CONTROL_HOUR_OFFSETS,
        "stage_a_targets": STAGE_A_TARGET_HOUR_OFFSETS,
        "post_analysis_forecasts": POST_ANALYSIS_FORECAST_HOUR_OFFSETS,
        "analysis_observation": (ANALYSIS_HOUR_OFFSET,),
        "analysis_update": (ANALYSIS_UPDATE_HOUR_OFFSET,),
        "analysis_control_index": (ANALYSIS_CONTROL_INDEX,),
        "post_analysis_control_indices": POST_ANALYSIS_CONTROL_INDICES,
    }
)

# The string ``B`` is the sole symbolic dimension in the immutable shape map.
TENSOR_SHAPES: Mapping[str, Tuple[object, ...]] = MappingProxyType(
    {
        "history": ("B", 24, 6),
        "future_wusongkou_astronomical_tide": ("B", 24),
        "future_datong_observed_stage": ("B", 24),
        "future_control": ("B", 24, 2),
        "analysis_observations": ("B", 5),
        "targets_a_to_a_plus_23": ("B", 24, 5),
        "targets_a_plus_1_to_a_plus_23": ("B", 23, 5),
        "open_loop_forecast": ("B", 23, 5),
        "updated_forecast": ("B", 5, 23, 5),
    }
)

FORECAST_FIELDS: Tuple[str, ...] = (
    "open_loop_forecast",
    "updated_forecast",
)


class ContractError(ValueError):
    """Raised when a proposed interface contradicts the frozen contract."""


@dataclass(frozen=True, order=True)
class DirectionCell:
    """One directed observation-source row and forecast-target column."""

    source_station: str
    target_station: str

    @property
    def key(self) -> str:
        return f"{self.source_station}->{self.target_station}"

    @property
    def is_self(self) -> bool:
        return self.source_station == self.target_station

    @property
    def is_internal_cross(self) -> bool:
        return (
            not self.is_self
            and self.source_station in INTERNAL_STATIONS
            and self.target_station in INTERNAL_STATIONS
        )

    @property
    def is_wusongkou_related_cross(self) -> bool:
        return (
            not self.is_self
            and WUSONGKOU_STATION
            in (self.source_station, self.target_station)
        )


SOURCE_TARGET_CELLS: Tuple[DirectionCell, ...] = tuple(
    DirectionCell(source_station, target_station)
    for source_station in OBSERVATION_STATIONS
    for target_station in TARGET_STATIONS
)
SELF_CELLS: Tuple[DirectionCell, ...] = tuple(
    cell for cell in SOURCE_TARGET_CELLS if cell.is_self
)
CROSS_CELLS: Tuple[DirectionCell, ...] = tuple(
    cell for cell in SOURCE_TARGET_CELLS if not cell.is_self
)
INTERNAL_CROSS_CELLS: Tuple[DirectionCell, ...] = tuple(
    cell for cell in SOURCE_TARGET_CELLS if cell.is_internal_cross
)
WUSONGKOU_RELATED_CROSS_CELLS: Tuple[DirectionCell, ...] = tuple(
    cell for cell in SOURCE_TARGET_CELLS if cell.is_wusongkou_related_cross
)

ADJACENT_DIRECTIONS: Tuple[Tuple[str, str], ...] = (
    ("nanjing", "zhenjiang"),
    ("zhenjiang", "nanjing"),
    ("zhenjiang", "jiangyin"),
    ("jiangyin", "zhenjiang"),
    ("jiangyin", "xuliujing"),
    ("xuliujing", "jiangyin"),
    ("xuliujing", "wusongkou"),
    ("wusongkou", "xuliujing"),
)

OBSERVATION_GAIN_FIELD = "observation_gain_m"
FORECAST_MOVEMENT_FIELD = "forecast_movement_m"
REPORT_WINDOWS: Tuple[Tuple[int, int], ...] = ((1, 6), (1, 12), (1, 23))
PRIMARY_REPORT_WINDOW = (1, 6)

BOOTSTRAP_BLOCK_DAYS = 7
BOOTSTRAP_REPLICATES = 20_000
BOOTSTRAP_GENERATOR = "PCG64"
BOOTSTRAP_RANDOM_SEED = 20260901
BOOTSTRAP_QUANTILE_METHOD = "linear"
ONE_SIDED_LOWER_QUANTILE = 0.05
TWO_SIDED_LOWER_QUANTILE = 0.025
TWO_SIDED_UPPER_QUANTILE = 0.975

HOLM_ALPHA = 0.05
HOLM_FAMILIES: Mapping[str, Tuple[DirectionCell, ...]] = MappingProxyType(
    {
        "internal_four_station_cross": INTERNAL_CROSS_CELLS,
        "wusongkou_related_cross": WUSONGKOU_RELATED_CROSS_CELLS,
    }
)

ADJACENT_MOVEMENT_THRESHOLD_M = 1e-6
MIN_POSITIVE_ADJACENT_GAIN_DIRECTIONS = 6
SIGNIFICANTLY_HARMFUL_CROSS_CELL_MAX_COUNT = 0


@dataclass(frozen=True, order=True)
class GateDefinition:
    """One of the eight preregistered statistical acceptance gates."""

    number: int
    key: str
    criterion: str


GATE_DEFINITIONS: Tuple[GateDefinition, ...] = (
    GateDefinition(
        1,
        "self_gain_and_seed_support",
        "For each of five 1-6 h self cells, pool every valid absolute-error "
        "unit across all three model seeds, subtract pooled updated MAE from "
        "pooled open-loop MAE, require that gain > 0, and also require at "
        "least two of three seed-level gains > 0; do not average seed gains "
        "to form the pooled estimate.",
    ),
    GateDefinition(
        2,
        "cross_macro_lower_bound",
        "The one-sided 95% lower bound of the equal-cell macro mean over "
        "20 cross cells is > 0.",
    ),
    GateDefinition(
        3,
        "internal_cross_macro_gain",
        "The point estimate of the equal-cell macro mean over 12 internal "
        "cross cells is > 0.",
    ),
    GateDefinition(
        4,
        "wusongkou_cross_macro_gain",
        "The point estimate of the equal-cell macro mean over eight "
        "Wusongkou-related cross cells is > 0.",
    ),
    GateDefinition(
        5,
        "target_column_cross_macro_gain",
        "For each target, the equal-cell macro mean over its four cross "
        "cells is > 0.",
    ),
    GateDefinition(
        6,
        "adjacent_forecast_movement",
        "Forecast movement is > 1e-6 m in all eight adjacent directions.",
    ),
    GateDefinition(
        7,
        "adjacent_positive_gain_count",
        "Observation gain is > 0 in at least six of eight adjacent "
        "directions.",
    ),
    GateDefinition(
        8,
        "no_significantly_harmful_cross_cell",
        "No cross cell has a two-sided 95% interval upper bound < 0.",
    ),
)


def expected_tensor_shapes(batch_size: int) -> Dict[str, Tuple[int, ...]]:
    """Materialize every frozen symbolic shape for a positive batch size."""

    if type(batch_size) is not int or batch_size < 1:
        raise ValueError("batch_size must be a positive integer")
    return {
        name: tuple(
            batch_size if dimension == "B" else int(dimension)
            for dimension in shape
        )
        for name, shape in TENSOR_SHAPES.items()
    }


def validate_datong_boundary_mode(boundary_mode: object) -> None:
    """Reject persistence, predicted, or any other unregistered boundary."""

    if boundary_mode not in ALLOWED_DATONG_BOUNDARY_MODES:
        raise ContractError(
            "boundary_mode must be exactly "
            f"{DATONG_BOUNDARY_MODE!r}; persistence and predicted Datong "
            "boundaries require a separate experiment family"
        )


def validate_prediction_fields(prediction_fields: Iterable[str]) -> None:
    """Require exactly the public open-loop and updated forecast interfaces."""

    if isinstance(prediction_fields, (str, bytes)):
        actual = (prediction_fields,)
    else:
        try:
            actual = tuple(prediction_fields)
        except TypeError as error:
            raise ContractError(
                "prediction_fields must be exactly "
                f"{FORECAST_FIELDS!r}"
            ) from error
    if actual != FORECAST_FIELDS:
        raise ContractError(
            "prediction_fields must be exactly "
            f"{FORECAST_FIELDS!r}; a missing, renamed, reordered, or third "
            "forecast branch is forbidden"
        )


def _is_future_covariance_field(field_name: str) -> bool:
    normalized = field_name.strip().lower().replace("-", "_")
    refers_to_future = "future" in normalized or "forecast" in normalized
    covariance_tokens = normalized.split("_")
    refers_to_covariance = "covari" in normalized or "cov" in covariance_tokens
    return refers_to_future and refers_to_covariance


def validate_no_future_covariance_fields(output_fields: Iterable[str]) -> None:
    """Reject any named future or forecast covariance output."""

    if isinstance(output_fields, (str, bytes)):
        fields: Sequence[object] = (output_fields,)
    else:
        try:
            fields = tuple(output_fields)
        except TypeError as error:
            raise ContractError("output_fields must be an iterable of names") from error
    invalid_types = tuple(field for field in fields if not isinstance(field, str))
    if invalid_types:
        raise ContractError("output_fields must contain only strings")
    forbidden = tuple(
        field for field in fields if _is_future_covariance_field(field)
    )
    if forbidden:
        raise ContractError(
            "future covariance fields are forbidden after the single "
            f"analysis update: {forbidden!r}"
        )


def validate_contract_usage(
    *,
    boundary_mode: object,
    prediction_fields: Iterable[str],
    output_fields: Iterable[str],
) -> None:
    """Validate all prohibited-interface boundaries in one call."""

    validate_datong_boundary_mode(boundary_mode)
    validate_prediction_fields(prediction_fields)
    validate_no_future_covariance_fields(output_fields)


def _duplicate_values(values: Iterable[object]) -> Tuple[object, ...]:
    seen = set()
    duplicates = []
    for value in values:
        if value in seen and value not in duplicates:
            duplicates.append(value)
        seen.add(value)
    return tuple(duplicates)


def self_check() -> Dict[str, object]:
    """Validate the frozen constants and return a JSON-compatible report."""

    findings = []
    if _duplicate_values(HISTORY_STATIONS):
        findings.append("duplicate_history_station")
    if _duplicate_values(OBSERVATION_STATIONS):
        findings.append("duplicate_observation_station")
    if TARGET_STATIONS != OBSERVATION_STATIONS:
        findings.append("target_order_drift")
    if "datong" in OBSERVATION_STATIONS or "datong" in TARGET_STATIONS:
        findings.append("datong_role_drift")
    if ALLOWED_DATONG_BOUNDARY_MODES != (DATONG_BOUNDARY_MODE,):
        findings.append("boundary_mode_drift")
    if HISTORY_HOUR_OFFSETS != tuple(range(-24, 0)):
        findings.append("history_timeline_drift")
    if FULL_SAMPLE_HOUR_OFFSETS != tuple(range(-24, 24)):
        findings.append("full_sample_timeline_drift")
    if CONTROL_HOUR_OFFSETS != tuple(range(24)):
        findings.append("control_timeline_drift")
    if POST_ANALYSIS_CONTROL_INDICES != tuple(range(1, 24)):
        findings.append("post_analysis_control_timeline_drift")
    if POST_ANALYSIS_FORECAST_HOUR_OFFSETS != tuple(range(1, 24)):
        findings.append("post_analysis_forecast_timeline_drift")
    if UNSCENTED_ANALYSIS_PREDICTION_TRANSITION != (-1, 0):
        findings.append("analysis_prediction_transition_drift")
    if ANALYSIS_UPDATE_HOUR_OFFSET != 0:
        findings.append("analysis_update_timeline_drift")
    if (
        ENCODER_CALLS_PER_ANALYSIS_ORIGIN != 1
        or not BRANCHES_SHARE_HISTORY_ENCODING
        or REENCODE_WITHIN_TRAJECTORY
        or ROLLING_ORIGIN_STEP_HOURS != 1
    ):
        findings.append("encoder_schedule_drift")
    if CONTROL_CHANNELS != (
        "future_wusongkou_astronomical_tide",
        "future_datong_observed_stage",
    ):
        findings.append("control_channel_order_drift")
    if ANALYSIS_SIGMA_POINT_COUNT != 2 * STATE_DIMENSION + 1:
        findings.append("analysis_sigma_point_count_drift")
    if len(SOURCE_TARGET_CELLS) != 25:
        findings.append("wrong_total_cell_count")
    if len(set(SOURCE_TARGET_CELLS)) != 25:
        findings.append("duplicate_direction_cell")
    if len(SELF_CELLS) != 5:
        findings.append("wrong_self_cell_count")
    if len(CROSS_CELLS) != 20:
        findings.append("wrong_cross_cell_count")
    if len(INTERNAL_CROSS_CELLS) != 12:
        findings.append("wrong_internal_cross_cell_count")
    if len(WUSONGKOU_RELATED_CROSS_CELLS) != 8:
        findings.append("wrong_wusongkou_related_cross_cell_count")
    if set(INTERNAL_CROSS_CELLS).intersection(WUSONGKOU_RELATED_CROSS_CELLS):
        findings.append("cross_partition_overlap")
    if set(INTERNAL_CROSS_CELLS).union(WUSONGKOU_RELATED_CROSS_CELLS) != set(
        CROSS_CELLS
    ):
        findings.append("cross_partition_incomplete")
    directional_pairs = {
        (cell.source_station, cell.target_station) for cell in CROSS_CELLS
    }
    if len(ADJACENT_DIRECTIONS) != 8 or any(
        direction not in directional_pairs for direction in ADJACENT_DIRECTIONS
    ):
        findings.append("adjacent_direction_drift")
    if FORECAST_FIELDS != ("open_loop_forecast", "updated_forecast"):
        findings.append("forecast_interface_drift")
    if tuple(gate.number for gate in GATE_DEFINITIONS) != tuple(range(1, 9)):
        findings.append("gate_number_drift")
    if len({gate.key for gate in GATE_DEFINITIONS}) != 8:
        findings.append("gate_key_drift")
    if tuple(HOLM_FAMILIES) != (
        "internal_four_station_cross",
        "wusongkou_related_cross",
    ):
        findings.append("holm_family_drift")
    try:
        validate_contract_usage(
            boundary_mode=DATONG_BOUNDARY_MODE,
            prediction_fields=FORECAST_FIELDS,
            output_fields=(
                "analysis_prior_covariance",
                "analysis_posterior_covariance",
                *FORECAST_FIELDS,
            ),
        )
    except ContractError:
        findings.append("registered_interface_validation_failure")

    return {
        "experiment_family": EXPERIMENT_FAMILY,
        "datong_boundary_mode": DATONG_BOUNDARY_MODE,
        "history_station_count": len(HISTORY_STATIONS),
        "observation_source_count": len(OBSERVATION_STATIONS),
        "target_count": len(TARGET_STATIONS),
        "total_cell_count": len(SOURCE_TARGET_CELLS),
        "self_cell_count": len(SELF_CELLS),
        "cross_cell_count": len(CROSS_CELLS),
        "internal_cross_cell_count": len(INTERNAL_CROSS_CELLS),
        "wusongkou_related_cross_cell_count": len(
            WUSONGKOU_RELATED_CROSS_CELLS
        ),
        "adjacent_direction_count": len(ADJACENT_DIRECTIONS),
        "gate_count": len(GATE_DEFINITIONS),
        "forecast_interface_count": len(FORECAST_FIELDS),
        "state_dimension": STATE_DIMENSION,
        "analysis_sigma_point_count": ANALYSIS_SIGMA_POINT_COUNT,
        "post_analysis_forecast_hours": POST_ANALYSIS_FORECAST_HOURS,
        "finding_count": len(findings),
        "findings": findings,
    }


def main() -> int:
    """Print the self-check report; this module has no execution mode."""

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-check", action="store_true")
    arguments = parser.parse_args()
    if not arguments.self_check:
        parser.error("--self-check is required; this module has no run mode")
    report = self_check()
    print(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2))
    return 0 if report["finding_count"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
