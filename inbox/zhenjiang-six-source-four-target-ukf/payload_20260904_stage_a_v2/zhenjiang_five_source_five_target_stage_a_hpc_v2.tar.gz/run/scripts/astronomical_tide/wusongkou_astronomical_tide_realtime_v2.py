#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Read-only real-time interface for the accepted Wusongkou tide model.

The public interface uses Beijing time. Astronomy alone receives a naive
coordinated-universal-time copy. Every prediction uses a fixed 2017 reference
and an absolute 240-hour nodal-correction block.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import hashlib
import json
import math
from pathlib import Path
import sys
from typing import Sequence

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[2]
THIRD_PARTY_TIDE_DIR = PROJECT_ROOT / "third_party" / "pytides"
if str(THIRD_PARTY_TIDE_DIR) not in sys.path:
    sys.path.insert(0, str(THIRD_PARTY_TIDE_DIR))

import astro  # noqa: E402
import constituent  # noqa: E402
import nodal_corrections  # noqa: E402,F401
from tide import Tide, d2r  # noqa: E402


UTC = timezone.utc
BEIJING = timezone(timedelta(hours=8))
ASTRONOMICAL_REFERENCE_BEIJING = datetime(2017, 1, 1, 0, tzinfo=BEIJING)
ASTRONOMICAL_REFERENCE_UTC_NAIVE = datetime(2016, 12, 31, 16)
ABSOLUTE_CHUNK_HOURS = 240.0
DEFAULT_TIDE_MODEL_PATH = Path(
    "results/modeling/wusongkou_astronomical_tide_v1_validation/tide_model.json"
)
EXPECTED_TIDE_MODEL_SHA256 = (
    "ce8512f28e87ab6d62814b064d91ca358b98efd7ee27b4f831322ea93775516d"
)
EXPECTED_FIRST_VERSION_MANIFEST_SHA256 = (
    "3a02ff8a40a013034f110b971c5b9b1dd0c5d398cd9f63657591c2a5dce22c49"
)
EXPECTED_FIRST_VERSION_MANIFEST_BYTES = 4585
EXPECTED_FIRST_VERSION_TOTAL_BYTES = 2312560
EXPECTED_ASTRONOMICAL_DEPENDENCIES = (
    (
        "tide",
        "tide.py",
        "fbdc9ec80a4bc9741520e73751038ab06db836add2425dbcc420873fde5dcbce",
    ),
    (
        "astro",
        "astro.py",
        "d29a2197c24a3e243590f0e7dcf52a2a4266a0951abab08244957711cabaa5bd",
    ),
    (
        "constituent",
        "constituent.py",
        "fed8fa1a14663391f2f706e8ca70eedddd188321221a7fd8120ddcd01b11846a",
    ),
    (
        "nodal_corrections",
        "nodal_corrections.py",
        "ae6af6c135fe88f90752fd6cf522d6976e5f8f8a29341d719627124dd254989b",
    ),
)

FIRST_VERSION_FROZEN_PATHS = (
    "docs/records/WUSONGKOU_ASTRONOMICAL_TIDE_V1_ACCEPTED.md",
    "docs/records/WUSONGKOU_ASTRONOMICAL_TIDE_V1_ITERATION_REVIEW.md",
    "results/modeling/wusongkou_astronomical_tide_v1_validation/availability_summary.csv",
    "results/modeling/wusongkou_astronomical_tide_v1_validation/build_summary.json",
    "results/modeling/wusongkou_astronomical_tide_v1_validation/constituents.csv",
    "results/modeling/wusongkou_astronomical_tide_v1_validation/experiment_config.json",
    "results/modeling/wusongkou_astronomical_tide_v1_validation/experiment_registry.csv",
    "results/modeling/wusongkou_astronomical_tide_v1_validation/input_manifest.csv",
    "results/modeling/wusongkou_astronomical_tide_v1_validation/key_horizon_metrics.csv",
    "results/modeling/wusongkou_astronomical_tide_v1_validation/output_manifest.csv",
    "results/modeling/wusongkou_astronomical_tide_v1_validation/tide_model.json",
    "results/modeling/wusongkou_astronomical_tide_v1_validation/validation_metrics.csv",
    "results/modeling/wusongkou_astronomical_tide_v1_validation/validation_predictions.csv.gz",
    "results/modeling/wusongkou_astronomical_tide_v1_validation_determinism_rebuild/availability_summary.csv",
    "results/modeling/wusongkou_astronomical_tide_v1_validation_determinism_rebuild/build_summary.json",
    "results/modeling/wusongkou_astronomical_tide_v1_validation_determinism_rebuild/constituents.csv",
    "results/modeling/wusongkou_astronomical_tide_v1_validation_determinism_rebuild/experiment_config.json",
    "results/modeling/wusongkou_astronomical_tide_v1_validation_determinism_rebuild/experiment_registry.csv",
    "results/modeling/wusongkou_astronomical_tide_v1_validation_determinism_rebuild/input_manifest.csv",
    "results/modeling/wusongkou_astronomical_tide_v1_validation_determinism_rebuild/key_horizon_metrics.csv",
    "results/modeling/wusongkou_astronomical_tide_v1_validation_determinism_rebuild/output_manifest.csv",
    "results/modeling/wusongkou_astronomical_tide_v1_validation_determinism_rebuild/tide_model.json",
    "results/modeling/wusongkou_astronomical_tide_v1_validation_determinism_rebuild/validation_metrics.csv",
    "results/modeling/wusongkou_astronomical_tide_v1_validation_determinism_rebuild/validation_predictions.csv.gz",
    "scripts/astronomical_tide/compare_wusongkou_astronomical_tide_v1_determinism.py",
    "scripts/astronomical_tide/verify_wusongkou_astronomical_tide_v1.py",
    "scripts/astronomical_tide/wusongkou_astronomical_tide_v1.py",
    "tests/test_compare_wusongkou_astronomical_tide_v1_determinism.py",
    "tests/test_verify_wusongkou_astronomical_tide_v1.py",
    "tests/test_wusongkou_astronomical_tide_v1.py",
)


@dataclass(frozen=True)
class InputContentIdentity:
    """Verified byte identity and scope of one dependency or input."""

    relative_path: str
    verification_scope: str
    byte_count: int
    sha256: str


@dataclass(frozen=True)
class FrozenInventoryIdentity:
    """Canonical identity of all immutable first-version artifacts."""

    file_count: int
    manifest_byte_count: int
    total_file_byte_count: int
    manifest_sha256: str


def sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def beijing_to_astronomical_utc(value: datetime) -> datetime:
    """Convert Beijing interface time to naive universal time for astronomy."""
    if value.tzinfo is None or value.utcoffset() != timedelta(hours=8):
        raise ValueError("astronomical interface time must be Beijing +08:00")
    return value.astimezone(UTC).replace(tzinfo=None)


def _full_file_identity(relative_path: str, path: Path) -> InputContentIdentity:
    return InputContentIdentity(
        relative_path=relative_path,
        verification_scope="full_file",
        byte_count=path.stat().st_size,
        sha256=sha256(path),
    )


def _verify_astronomical_dependencies() -> tuple[InputContentIdentity, ...]:
    identities = []
    for module_name, filename, expected_sha256 in EXPECTED_ASTRONOMICAL_DEPENDENCIES:
        imported_module = sys.modules.get(module_name)
        expected_path = (THIRD_PARTY_TIDE_DIR / filename).resolve()
        if (
            imported_module is None
            or not getattr(imported_module, "__file__", None)
            or Path(imported_module.__file__).resolve() != expected_path
        ):
            raise RuntimeError(
                "astronomical dependency import path changed: " + filename
            )
        identity = _full_file_identity(
            "third_party/pytides/" + filename, expected_path
        )
        if identity.sha256 != expected_sha256:
            raise RuntimeError(
                "astronomical dependency fingerprint changed: " + filename
            )
        identities.append(identity)
    return tuple(identities)


def first_version_frozen_manifest(project_root: str | Path = PROJECT_ROOT) -> bytes:
    """Return the canonical 30-file first-version inventory bytes."""
    root = Path(project_root).resolve()
    lines = []
    for relative_path in sorted(FIRST_VERSION_FROZEN_PATHS):
        path = root / relative_path
        if not path.is_file():
            raise RuntimeError(
                "first-version frozen file is missing: " + relative_path
            )
        lines.append(
            "{}\t{}\t{}\n".format(
                relative_path,
                path.stat().st_size,
                sha256(path),
            )
        )
    return "".join(lines).encode("utf-8")


def verify_first_version_frozen_inventory(
    project_root: str | Path = PROJECT_ROOT,
) -> FrozenInventoryIdentity:
    """Reject any change among the 30 immutable first-version artifacts."""
    root = Path(project_root).resolve()
    manifest = first_version_frozen_manifest(root)
    identity = FrozenInventoryIdentity(
        file_count=len(FIRST_VERSION_FROZEN_PATHS),
        manifest_byte_count=len(manifest),
        total_file_byte_count=sum(
            (root / relative_path).stat().st_size
            for relative_path in FIRST_VERSION_FROZEN_PATHS
        ),
        manifest_sha256=hashlib.sha256(manifest).hexdigest(),
    )
    if (
        identity.file_count != 30
        or identity.manifest_byte_count != EXPECTED_FIRST_VERSION_MANIFEST_BYTES
        or identity.total_file_byte_count != EXPECTED_FIRST_VERSION_TOTAL_BYTES
        or identity.manifest_sha256 != EXPECTED_FIRST_VERSION_MANIFEST_SHA256
    ):
        raise RuntimeError("first-version frozen inventory changed")
    return identity


class FrozenAstronomicalTideRealtimeV2:
    """Fixed-reference, absolute-chunk wrapper around 38 saved constituents."""

    def __init__(
        self,
        model: Tide,
        constituent_count: int,
        dependency_content_identities: tuple[InputContentIdentity, ...],
    ) -> None:
        self._model = model
        self.constituent_count = int(constituent_count)
        self.dependency_content_identities = dependency_content_identities
        self._amplitudes = self._model.model["amplitude"][:, np.newaxis]
        self._phases = d2r * self._model.model["phase"][:, np.newaxis]
        speed, _, _, equilibrium = self._model.prepare(
            ASTRONOMICAL_REFERENCE_UTC_NAIVE,
            [ASTRONOMICAL_REFERENCE_UTC_NAIVE],
            radians=True,
        )
        self._speed = speed
        self._equilibrium = equilibrium
        self._chunk_corrections = {}

    def _corrections(self, chunk_index: int):
        cached = self._chunk_corrections.get(chunk_index)
        if cached is None:
            midpoint = ASTRONOMICAL_REFERENCE_UTC_NAIVE + timedelta(
                hours=(chunk_index + 0.5) * ABSOLUTE_CHUNK_HOURS
            )
            _, [node_phase], [node_factor], _ = self._model.prepare(
                ASTRONOMICAL_REFERENCE_UTC_NAIVE,
                [midpoint],
                radians=True,
            )
            cached = (node_phase, node_factor)
            self._chunk_corrections[chunk_index] = cached
        return cached

    def predict_float64(self, times_beijing: Sequence[datetime]) -> np.ndarray:
        """Return double-precision values while preserving requested order."""
        requested_times = list(times_beijing)
        if not requested_times:
            return np.empty(0, dtype=np.float64)
        astronomical_times = [
            beijing_to_astronomical_utc(value) for value in requested_times
        ]
        if any(
            value < ASTRONOMICAL_REFERENCE_UTC_NAIVE
            for value in astronomical_times
        ):
            raise ValueError(
                "astronomical request must not be earlier than reference"
            )
        hours = np.asarray(
            [
                (value - ASTRONOMICAL_REFERENCE_UTC_NAIVE).total_seconds()
                / 3600.0
                for value in astronomical_times
            ],
            dtype=np.float64,
        )
        chunk_indices = np.floor(hours / ABSOLUTE_CHUNK_HOURS).astype(np.int64)
        predictions = np.empty(len(requested_times), dtype=np.float64)
        for chunk_index in np.unique(chunk_indices):
            positions = np.flatnonzero(chunk_indices == chunk_index)
            node_phase, node_factor = self._corrections(int(chunk_index))
            predictions[positions] = Tide._tidal_series(
                hours[positions],
                self._amplitudes,
                self._phases,
                self._speed,
                node_phase,
                node_factor,
                self._equilibrium,
            )
        if not np.isfinite(predictions).all():
            raise RuntimeError("astronomical tide returned a nonfinite value")
        return predictions

    def predict(self, times_beijing: Sequence[datetime]) -> np.ndarray:
        """Return 32-bit values in the original sparse or duplicate order."""
        return self.predict_float64(times_beijing).astype(np.float32)


FrozenAstronomicalTide = FrozenAstronomicalTideRealtimeV2


def load_frozen_astronomical_tide(
    path: str | Path = DEFAULT_TIDE_MODEL_PATH,
) -> FrozenAstronomicalTideRealtimeV2:
    """Load accepted parameters without fitting or reading observations."""
    dependency_identities = _verify_astronomical_dependencies()
    path = Path(path).resolve()
    accepted_path = (PROJECT_ROOT / DEFAULT_TIDE_MODEL_PATH).resolve()
    if path != accepted_path:
        raise ValueError("only the accepted tide_model.json path is allowed")
    if sha256(path) != EXPECTED_TIDE_MODEL_SHA256:
        raise RuntimeError("frozen astronomical-tide fingerprint changed")
    payload = json.loads(path.read_text(encoding="utf-8"))
    records = payload.get("constituents")
    if (
        payload.get("model_type") != "harmonic_astronomical_tide"
        or payload.get("station_slug") != "wusongkou"
        or payload.get("constituent_count") != 38
        or not isinstance(records, list)
        or len(records) != 38
    ):
        raise RuntimeError("frozen astronomical-tide identity changed")
    constituent_by_name = {
        value.name: value
        for value in vars(constituent).values()
        if isinstance(value, constituent.BaseConstituent)
    }
    objects = []
    amplitudes = []
    phases = []
    for expected_index, record in enumerate(records):
        if record.get("index") != expected_index:
            raise RuntimeError("frozen constituent order changed")
        name = record.get("constituent")
        if name not in constituent_by_name:
            raise RuntimeError("unknown frozen constituent: " + str(name))
        amplitude = float(record.get("amplitude_m"))
        phase = float(record.get("phase_degrees"))
        if not math.isfinite(amplitude) or not math.isfinite(phase):
            raise RuntimeError("frozen constituent parameter is nonfinite")
        objects.append(constituent_by_name[name])
        amplitudes.append(amplitude)
        phases.append(phase)
    return FrozenAstronomicalTideRealtimeV2(
        Tide(objects, amplitudes, phases),
        constituent_count=len(objects),
        dependency_content_identities=dependency_identities,
    )


__all__ = [
    "ASTRONOMICAL_REFERENCE_BEIJING",
    "ASTRONOMICAL_REFERENCE_UTC_NAIVE",
    "BEIJING",
    "DEFAULT_TIDE_MODEL_PATH",
    "EXPECTED_ASTRONOMICAL_DEPENDENCIES",
    "EXPECTED_TIDE_MODEL_SHA256",
    "FrozenAstronomicalTide",
    "FrozenAstronomicalTideRealtimeV2",
    "FrozenInventoryIdentity",
    "InputContentIdentity",
    "UTC",
    "beijing_to_astronomical_utc",
    "first_version_frozen_manifest",
    "load_frozen_astronomical_tide",
    "sha256",
    "verify_first_version_frozen_inventory",
]
