"""First exclusive formal repair submission, or audited finite-slice continuation.

python -B hpc/submit_covariance_recovery_squeue_20261015.py
python -B hpc/submit_covariance_recovery_squeue_20261015.py --continue-slice
Never retry an ambiguous publication or scheduler attempt. Failed fits require
new diagnosis. Actual allocation deadlines are supplied by the squeue wrapper.
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]
CASE = 'explicit_gru__historical_capacity'
CODE = '4232fbb467341b6332f91e9289cdb975613babb5d29e2079b66d55f7822c3757'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


def query(args):
    p = subprocess.run(args, capture_output=True, text=True, timeout=30)
    assert p.returncode == 0, p.stderr
    return {'command':args, 'returncode':p.returncode, 'stdout':p.stdout, 'stderr':p.stderr}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    flags = parser.add_mutually_exclusive_group()
    flags.add_argument('--continue-slice', action='store_true')
    args = parser.parse_args()
    if (ROOT/'records'/CASE/'training_complete.json').exists():
        print(json.dumps({'status':'case_complete_no_continuation_submission'}))
        return
    import sys
    sys.path.insert(0, str(ROOT))
    from src.scheduler import code_identity
    auth = read(ROOT/'records/authorization.json')
    assert code_identity() == auth['code_hash'] == CODE
    assert sha(ROOT/'configs/protocol-v3.json') == auth['protocol_sha256']
    assert auth['authority']['formal_training'] and auth['authority']['technical_recovery']
    assert not list(ROOT.joinpath('runs').glob('*/failure.json')), 'new fit failure requires diagnosis'
    prep = read(ROOT/'records/covariance_recovery_cpu_admitted_20261015.json')
    assert prep['source_bytes_unchanged'] and prep['scientific_protocol_unchanged'] and prep['member_count'] == 12
    assert prep['code_hash'] == CODE and prep['candidate_full_validation_verified'] and prep['candidate_direct_gradient_verified']
    runtime = read(ROOT/'records/covariance_recovery_runtime_admitted_20261015.json')
    assert all(sha(Path(runtime['runtime'])/name) == expected for name,expected in runtime['runtime_files'].items())
    audit = read(ROOT/'records/covariance_checkpoint_audit_latest.json')
    assert sha(Path(audit['immutable_record'])) == audit['immutable_record_sha256']
    assert audit['code_hash'] == CODE and audit['all_source_bytes_unchanged'] and not audit['any_new_failure_file']
    assert len(audit['members']) == 12
    for row in audit['members']:
        assert sha(ROOT/'runs'/row['run']/'continuation.pt') == row['current_checkpoint_sha256']
    queue = query(['squeue','-h','-u','sunyiq','-o','%i|%j|%T|%Z'])
    rows = [line.split('|') for line in queue['stdout'].splitlines() if line.strip()]
    assert not any(row[1].startswith('zj_gru_') or row[3] == str(ROOT) for row in rows)
    jobs_path = ROOT/'records/scheduler_jobs.json'
    jobs = read(jobs_path) if jobs_path.exists() else {}
    if args.continue_slice:
        old = str(jobs[CASE])
        assert not any(row[0] == old for row in rows)
        accounting = query(['sacct','-n','-X','-j',old,'--format=JobID,State,ExitCode,Start,End,NodeList','-P'])
        ar = [line.split('|') for line in accounting['stdout'].splitlines() if line.startswith(old+'|')]
        assert len(ar) == 1
        assert ar[0][1] == 'TIMEOUT' or (ar[0][1:3] == ['COMPLETED','0:0'] and
                                       (ROOT/'records'/('scheduler_slice_end_'+old+'.json')).exists())
        assert str(audit['job_id']) == old
        key, name = 'after_'+old, 'zj_gru_covariance_slice_'+old+'_261016'
    else:
        assert not jobs and audit['job_id'] is None
        old = str(prep['source_job'])
        assert not any(row[0] == old for row in rows)
        accounting = query(['sacct','-n','-X','-j',old,'--format=JobID,State,ExitCode,Start,End,NodeList','-P'])
        ar = [line.split('|') for line in accounting['stdout'].splitlines() if line.startswith(old+'|')]
        assert len(ar) == 1 and ar[0][1:3] == ['FAILED','1:0']
        key, name = 'initial', 'zj_gru_covariance_recovery_261016_006'
    template = ROOT/'hpc/pathfix_compensated_recovery_squeue_20261016_006.slurm'
    manifest = read(ROOT/'release_manifest.json')
    assert sha(template) == manifest['files'][template.relative_to(ROOT).as_posix()]['sha256']
    lines = [('#SBATCH --job-name='+name) if line.startswith('#SBATCH --job-name=') else line
             for line in template.read_text().splitlines()]
    assert '#SBATCH -p hgpu2p' in lines and '#SBATCH --gres=gpu:1' in lines and '#SBATCH --cpus-per-task=4' in lines
    assert '#SBATCH --exclude=ngu002,ngu011' in lines and '#SBATCH --time=12:00:00' in lines
    assert '#SBATCH --time-min=02:00:00' in lines and lines.index('conda activate nh_final') < lines.index('set -u')
    assert [line for line in lines if line.startswith('cd ')] == ['cd '+str(ROOT)]
    script = ROOT/'hpc'/('pathfix_covariance_'+key+'.slurm')
    attempt = ROOT/'records'/('covariance_submission_'+key+'.attempt.json')
    assert not attempt.exists(), 'existing attempt requires read-only reconciliation; never retry'
    with script.open('x') as stream:
        stream.write('\n'.join(lines)+'\n')
    save(attempt, {'status':'exclusive_submission_reserved_no_retry', 'source_job':old, 'case':CASE,
         'checked_at_beijing':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
         'code_hash':CODE, 'queue':queue, 'accounting':accounting, 'script_sha256':sha(script),
         'checkpoint_audit_sha256':sha(Path(audit['immutable_record'])), 'science_rules_changed':False})
    response_path = ROOT/'records'/('covariance_submission_'+key+'.response.json')
    try:
        p = subprocess.run(['/usr/local/globle/softs/slurm/19.05.4.1/bin/xbatch',str(script)],
                           cwd=str(ROOT), capture_output=True, text=True, timeout=60)
    except Exception as error:
        save(response_path, {'status':'uncertain_read_only_reconciliation_required', 'error':str(error)})
        raise
    save(response_path, {'returncode':p.returncode, 'stdout':p.stdout, 'stderr':p.stderr})
    match = re.fullmatch(r'Submitted batch job ([0-9]+)\s*', p.stdout)
    assert p.returncode == 0 and match, 'submission uncertain; inspect existing response and scheduler, never replay'
    job = match.group(1)
    if jobs_path.exists():
        save(ROOT/'records'/('scheduler_jobs_before_'+key+'.json'), jobs)
    jobs[CASE] = job
    temporary = jobs_path.with_name(jobs_path.name+'.tmp')
    save(temporary, jobs)
    temporary.replace(jobs_path)
    confirmed = {'status':'covariance_formal_recovery_submitted', 'job_id':job, 'previous_job':old,
                 'root':str(ROOT), 'case':CASE, 'code_hash':CODE, 'script_sha256':sha(script),
                 'time_limit':'12:00:00', 'time_min':'02:00:00', 'formal_progress_confirmed':False,
                 'evaluation_values_read':False, 'science_rules_changed':False}
    save(ROOT/'records'/('covariance_submission_'+key+'.confirmed.json'), confirmed)
    print(json.dumps(confirmed), flush=True)


if __name__ == '__main__':
    main()
