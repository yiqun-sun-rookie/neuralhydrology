"""Run unchanged formal training through checkpoint-safe scheduler slices.

Usage: python -B hpc/run_scheduler_slice.py --case explicit_gru__historical_capacity
Only injects the existing scheduler_deadline argument. No training config, epoch
budget, scientific choice, optimizer or mathematical operation is changed.
"""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]

SQUEUE = '/usr/local/globle/softs/slurm/19.05.4.1/bin/squeue'
SQUEUE_SHA256 = 'd8d6de8192243a946c40838b4a774bd1b132a1dce3c71dd97045cc9c07d8f14b'
SQUEUE_FORMAT = '%i|%T|%Z|%e|%l|%P|%C|%b|%N'

def scheduler_deadline(job, query=subprocess.run, verify_binary=True):
    if verify_binary and hashlib.sha256(Path(SQUEUE).read_bytes()).hexdigest() != SQUEUE_SHA256:
        raise ValueError('registered scheduler queue executable identity mismatch')
    command = [SQUEUE, '-h', '-j', job, '-o', SQUEUE_FORMAT]
    result = query(command, capture_output=True, text=True, timeout=30)
    if result.returncode:
        print(json.dumps({'status': 'scheduler_queue_query_failed', 'job_id': job,
                          'command': command, 'returncode': result.returncode,
                          'stdout': result.stdout, 'stderr': result.stderr}), flush=True)
        raise RuntimeError('registered scheduler queue query failed; allocation deadline not guessed')
    rows = [line.split('|') for line in result.stdout.splitlines() if line.strip()]
    if len(rows) != 1 or len(rows[0]) != 9:
        raise ValueError('scheduler query must return exactly one registered allocation')
    keys = ('JobId', 'JobState', 'WorkDir', 'EndTime', 'TimeLimit', 'Partition',
            'NumCPUs', 'TresPerNode', 'NodeList')
    fields = dict(zip(keys, rows[0]))
    if fields['JobId'] != job or fields['JobState'] != 'RUNNING' or fields['WorkDir'] != str(ROOT):
        raise ValueError('scheduler allocation identity mismatch')
    if fields['Partition'] != 'hgpu2p' or fields['NumCPUs'] != '4' or fields['TresPerNode'] != 'gpu:1':
        raise ValueError('scheduler allocation resource mismatch')
    if fields['NodeList'] in ('', '(null)', 'None', 'NONE'):
        raise ValueError('assigned scheduler node is required')
    end = fields['EndTime']
    if end in ('Unknown', 'NONE', 'N/A') or fields['TimeLimit'] in ('UNLIMITED', 'N/A', 'NONE'):
        raise ValueError('finite scheduler allocation end time is required')
    remaining = datetime.datetime.fromisoformat(end).timestamp() - time.time()
    if remaining <= 600:
        raise ValueError('allocation has insufficient remaining checkpoint margin')
    fields['QueryInterface'] = 'registered_same_version_squeue_actual_running_allocation'
    return time.perf_counter() + remaining - 600, fields

def main():
    job=os.environ['SLURM_JOB_ID']
    deadline,fields=scheduler_deadline(job)
    sys.path.insert(0,str(ROOT/'scripts'))
    spec=importlib.util.spec_from_file_location('registered_formal_case',ROOT/'scripts/train_supercomputer_case.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    from src.training import SchedulerContinuation
    original=module.execute_group
    def execute(*args,**kwargs):
        if 'scheduler_deadline' in kwargs:raise ValueError('duplicate scheduler deadline')
        return original(*args,scheduler_deadline=deadline,**kwargs)
    module.execute_group=execute
    try:
        module.main()
    except SchedulerContinuation:
        record={'status':'scheduler_slice_saved_for_continuation','job_id':job,'checked_at':datetime.datetime.now().astimezone().isoformat(),'scheduler':fields,'checkpoint_boundary':'all members retain their own last complete epoch including optimizer and selection history','formal_training_complete':False,'scientific_budget_changed':False,'code_hash':module.code_identity(),'wrapper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
        path=ROOT/'records'/('scheduler_slice_end_'+job+'.json')
        with path.open('x',encoding='utf-8') as f:json.dump(record,f,sort_keys=True,indent=2);f.write('\n')
        print(json.dumps(record),flush=True)
    except Exception as error:
        print(json.dumps({'status':'training_stopped','error_type':type(error).__name__,'reason':str(error)}),flush=True)
        raise

if __name__=='__main__':main()
