import pytest
import torch
from src.contracts import CASES, Whitening
from src.models import make_parts, rollout
from src.state_estimators import make_branches, initialize_state, configure_branch
from src.differentiable_filter import (make_noise,noise_variances,unscented_points,unscented_moments,
    observation_affine,linear_update,filter_analysis,stable_cholesky,StabilityLedger,FilterFailure,fit_whitening)

def test_scalar_update_value_and_readout_gradient():
    h=torch.tensor([[1.]],dtype=torch.float64,requires_grad=True)
    result,p=linear_update(torch.zeros(1,1,dtype=torch.float64),torch.full((1,1,1),2.,dtype=torch.float64),
                           torch.full((1,1),3.,dtype=torch.float64),h,torch.zeros(1,dtype=torch.float64),
                           torch.ones(1,1,dtype=torch.float64))
    assert torch.allclose(result,torch.tensor([[2.]],dtype=torch.float64))
    assert torch.allclose(p,torch.tensor([[[2/3]]],dtype=torch.float64))
    result.square().sum().backward()
    assert torch.allclose(h.grad,torch.tensor([[-8/3]],dtype=torch.float64))

def test_unscented_moments_and_linear_propagation():
    g=torch.Generator().manual_seed(42)
    m=torch.randn(2,6,dtype=torch.float64,generator=g)
    a=torch.randn(2,6,6,dtype=torch.float64,generator=g); p=a@a.transpose(-1,-2)+torch.eye(6)*.1
    points,wm,wc=unscented_points(m,p)
    actual,actual_p=unscented_moments(points,wm,wc)
    assert torch.allclose(m,actual,atol=1e-12) and torch.allclose(p,actual_p,atol=1e-12)
    f=torch.randn(6,6,dtype=torch.float64,generator=g)
    transformed=points@f.T+3
    tm,tp=unscented_moments(transformed,wm,wc)
    assert torch.allclose(tm,m@f.T+3,atol=1e-12)
    assert torch.allclose(tp,f@p@f.T,atol=1e-11)

@pytest.mark.parametrize('family,capacity,w,d',CASES)
def test_all_full_dimensions_24_updates_23_forecast_gradients(family,capacity,w,d,batch):
    f=make_parts(family,capacity,17); p=make_branches(f,100017)['filter_joint']
    noise=make_noise(d); configure_branch(p,noise,'filter_joint')
    wh=Whitening(torch.linspace(-.1,.1,d,dtype=torch.float64),torch.linspace(.5,1.5,d,dtype=torch.float64))
    initial=initialize_state(p,batch.history[:,:24])
    matrix,offset=observation_affine(p,wh)
    z=(initial.double()-wh.mean)/wh.scale
    assert torch.allclose(z@matrix.T+offset,p.readout(initial).double(),atol=2e-8)
    s,report=filter_analysis(p,noise,wh,initial,batch)
    prediction=rollout(p.process,p.readout,s,batch.forecast_controls)
    prediction.square().sum().backward()
    for param in (noise.raw_q,noise.raw_r,noise.raw_p0):
        assert param.grad is not None and torch.isfinite(param.grad).all() and param.grad.abs().sum()>0
    assert report['analysis_steps']==24 and report['large_jitter_fraction']<=.01
    assert s.shape==(1,d) and report['posterior_covariance'].dtype==torch.float64
    assert any(q.grad is not None and q.grad.abs().sum()>0 for q in p.process.parameters())
    if family=='legacy_lstm': assert p.readout.weight.grad.abs().sum()>0

def test_readout_matrix_is_current_and_analysis_only_gradient(batch):
    f=make_parts('legacy_lstm','small',17); p=make_branches(f,100017)['filter_joint']; n=make_noise(64)
    configure_branch(p,n,'filter_joint')
    wh=Whitening(torch.zeros(64,dtype=torch.float64),torch.ones(64,dtype=torch.float64))
    initial=initialize_state(p,batch.history[:,:24]); h,_=observation_affine(p,wh)
    with torch.no_grad(): p.readout.weight.mul_(1.5)
    actual,_=observation_affine(p,wh)
    assert torch.allclose(actual,h*1.5)
    result,_=filter_analysis(p,n,wh,initial,batch)
    result.square().sum().backward()
    assert p.readout.weight.grad.abs().sum()>0

def test_no_observation_still_propagates_uncertainty(batch):
    p=make_parts('explicit_gru','small',17); n=make_noise(32)
    wh=Whitening(torch.zeros(32,dtype=torch.float64),torch.ones(32,dtype=torch.float64))
    s,report=filter_analysis(p,n,wh,p.initializer(batch.history[:,:24]),batch,use_observations=False)
    assert report['analysis_steps']==24
    assert not torch.allclose(report['posterior_covariance'],torch.eye(32,dtype=torch.float64)[None]*.01)

def test_initial_noise_values_and_failures_preserved():
    q,r,p0=noise_variances(make_noise(64))
    assert torch.allclose(q,torch.full_like(q,.001),atol=1e-15)
    assert torch.allclose(r,torch.full_like(r,.01),atol=1e-15)
    assert torch.allclose(p0,torch.full_like(p0,.01),atol=1e-15)
    with pytest.raises(FilterFailure) as failure:
        stable_cholesky(-torch.eye(4,dtype=torch.float64)[None])
    assert failure.value.evidence['attempted_jitters'][-1]==1e-4
    ledger=StabilityLedger([0.]*23+[1e-5])
    with pytest.raises(FilterFailure) as failure: ledger.report()
    assert failure.value.evidence['large_jitter_fraction']==1/24

def test_whitening_uses_49_states_and_does_not_change_parent(batch):
    p=make_parts('explicit_gru','small',17)
    wh=fit_whitening(p,[batch])
    with torch.no_grad():
        mid=p.initializer(batch.history[:,:24]); end=p.initializer(batch.history[:,24:],mid)
        states=[mid,end]; state=mid
        for control in batch.midpoint_controls.unbind(1): state=p.process(state,control); states.append(state)
    a=torch.stack(states,1).double().reshape(49,32)
    assert torch.allclose(wh.mean,a.mean(0),atol=1e-12)
    assert torch.allclose(wh.scale,a.std(0,unbiased=False).clamp_min(.001),atol=1e-12)
