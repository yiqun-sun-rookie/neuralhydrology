import importlib.util
from pathlib import Path
from types import SimpleNamespace
import pytest


def load_module():
    path=Path(__file__).resolve().parents[1]/'hpc/prepare_recovery_v2.py'
    spec=importlib.util.spec_from_file_location('recovery_guard_test',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


@pytest.mark.parametrize('code,stderr',[(0,''),(1,'slurm_load_jobs error: Invalid job id specified')])
def test_confirmed_terminal_job_may_be_absent_from_queue(monkeypatch,code,stderr):
    module=load_module()
    results=iter([SimpleNamespace(stdout='236708|FAILED|1:0\n'),SimpleNamespace(stdout='',stderr=stderr,returncode=code)])
    monkeypatch.setattr(module.subprocess,'run',lambda *a,**kw:next(results))
    module.confirm_failed_source_job()


@pytest.mark.parametrize('stdout,stderr,code',[('236708|RUNNING\n','',0),('', 'Unable to contact slurm controller',1)])
def test_active_job_or_query_fault_is_rejected(monkeypatch,stdout,stderr,code):
    module=load_module()
    results=iter([SimpleNamespace(stdout='236708|FAILED|1:0\n'),SimpleNamespace(stdout=stdout,stderr=stderr,returncode=code)])
    monkeypatch.setattr(module.subprocess,'run',lambda *a,**kw:next(results))
    with pytest.raises((ValueError,RuntimeError)):module.confirm_failed_source_job()


def test_accounting_must_confirm_exact_source_failure(monkeypatch):
    module=load_module();monkeypatch.setattr(module.subprocess,'run',lambda *a,**kw:SimpleNamespace(stdout='236708|RUNNING|0:0\n'))
    with pytest.raises(ValueError):module.confirm_failed_source_job()
