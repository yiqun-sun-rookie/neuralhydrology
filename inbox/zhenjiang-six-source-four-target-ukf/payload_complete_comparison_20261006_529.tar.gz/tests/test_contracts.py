from dataclasses import replace
from pathlib import Path
import hashlib
import numpy as np
import pytest
import torch
from src.contracts import verify_shapes, CHANNELS
from src.data_contract import allowed_path, build_physical_window, build_calendar
from src.normalization import normalize_window, denormalize_targets_cm, fit_training_stats

def test_nonunit_stats_and_roundtrip(stats,physical):
    truth=np.tile(stats.target_mean+2*stats.target_std,(47,1))
    w=replace(physical,history_m=np.tile(stats.history_mean+2*stats.history_std,(48,1)),
              analysis_controls_m=np.tile(stats.control_mean+2*stats.control_std,(24,1)),
              forecast_controls_m=np.tile(stats.control_mean+2*stats.control_std,(23,1)),
              midpoint_controls_m=np.tile(stats.control_mean+2*stats.control_std,(47,1)),targets_m=truth)
    b=normalize_window(w,stats)
    assert torch.equal(b.history,torch.full_like(b.history,2))
    assert torch.equal(b.forecast_controls,torch.full_like(b.forecast_controls,2))
    assert torch.equal(denormalize_targets_cm(b.targets,stats),torch.tensor(truth[None]*100,dtype=torch.float32))

def test_negative_residual_and_no_labels_in_controls(physical):
    h=physical.history_m.copy(); h[:,5]=4; h[:,6]=6
    times=physical.issue_time+np.arange(-47,1)*np.timedelta64(1,'h')
    tide=np.full(47,6.)
    a=build_physical_window(h,times,tide,physical.targets_m)
    b=build_physical_window(h,times,tide,physical.targets_m+200)
    assert (a.analysis_controls_m[:,2]==-2).all()
    assert np.array_equal(a.forecast_controls_m,b.forecast_controls_m)
    assert np.array_equal(a.midpoint_controls_m,b.midpoint_controls_m)
    h[24:,4:6]+=30
    c=build_physical_window(h,times,tide,physical.targets_m)
    assert np.array_equal(a.midpoint_controls_m,c.midpoint_controls_m)

@pytest.mark.parametrize('kind',['missing','duplicate','cross_year','overlap','nan','shape'])
def test_bad_windows_rejected(physical,kind):
    h=physical.history_m.copy(); tide=np.r_[h[24:,6],np.ones(23)]
    times=physical.issue_time+np.arange(-47,1)*np.timedelta64(1,'h')
    if kind=='missing': times[10:]+=np.timedelta64(1,'h')
    if kind=='duplicate': times[10]=times[9]
    if kind=='cross_year': times=np.datetime64('2020-12-30T20')+np.arange(48)*np.timedelta64(1,'h')
    if kind=='overlap': tide[0]+=1
    if kind=='nan': h[1,0]=np.nan
    if kind=='shape': h=h[:47]
    with pytest.raises(ValueError): build_physical_window(h,times,tide,physical.targets_m)

def manifest_for(p,years=(2020,)):
    return {'status':'admitted','approved_roots':[str(p.parent)],'files':[
        {'path':str(p),'years':list(years),'phases':['tuning_train'],'role':'realtime_inputs',
         'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}]}

def test_allowed_authentic_path_and_digest(tmp_path):
    p=tmp_path/'inputs.bin'; p.write_bytes(b'synthetic')
    m=manifest_for(p)
    assert allowed_path(p,m,'tuning_train')==p.resolve()
    p.write_bytes(b'changed')
    with pytest.raises(ValueError): allowed_path(p,m,'tuning_train')

@pytest.mark.parametrize('kind',['mixed_year','evaluation','lexical_escape','resolved_escape'])
def test_reject_before_any_file_bytes(tmp_path,monkeypatch,kind):
    p=tmp_path/'inputs.bin'; p.write_bytes(b'x'); m=manifest_for(p)
    phase='tuning_train'
    if kind=='mixed_year': m['files'][0]['years']=[2020,2023]
    if kind=='evaluation': phase='evaluation_2023'
    if kind=='lexical_escape': m['approved_roots']=[str(tmp_path/'sub')]
    if kind=='resolved_escape':
        original=Path.resolve
        monkeypatch.setattr(Path,'resolve',lambda self,*a,**kw: tmp_path.parent/'outside.bin' if self==p else original(self,*a,**kw))
    def forbidden(self): raise AssertionError('restricted bytes opened')
    monkeypatch.setattr(Path,'read_bytes',forbidden)
    with pytest.raises(PermissionError): allowed_path(p,m,phase)

def test_unique_hours_stats_and_degenerate_rejection():
    times=np.datetime64('2020-01-01')+np.arange(100)*np.timedelta64(1,'h')
    series={'times':times,**{c: np.sin(np.arange(100)/(i+3))+i for i,c in enumerate(CHANNELS)}}
    s=fit_training_stats(series,(2020,),'a'*64)
    assert s.high_threshold_m[0]==np.quantile(series[CHANNELS[0]],.95,method='linear')
    assert s.control_mean[2]==pytest.approx((series['wusongkou']-series['astronomical_tide']).mean())
    repeated={k:np.repeat(v,2,axis=0) for k,v in series.items()}
    with pytest.raises(ValueError): fit_training_stats(repeated,(2020,),'a'*64)
    series['datong']=np.ones(100)
    with pytest.raises(ValueError): fit_training_stats(series,(2020,),'a'*64)

def test_calendar_records_input_exclusions():
    times=np.datetime64('2020-06-01')+np.arange(120)*np.timedelta64(1,'h')
    h=np.ones((120,7)); labels=np.ones((120,4)); tide=np.ones(120)
    ids,excluded=build_calendar(times,h,labels,tide)
    assert len(ids)==50 and len(excluded)==70
    h[60,0]=np.nan
    ids2,excluded2=build_calendar(times,h,labels,tide)
    assert len(ids2)<len(ids) and any(e['reason']=='missing_input_or_label' for e in excluded2)

def test_high_threshold_uses_own_unique_labels_not_other_input_availability():
    times=np.datetime64('2020-06-01')+np.arange(100)*np.timedelta64(1,'h')
    series={'times':times,**{c:np.arange(100,dtype=float)*(i+1) for i,c in enumerate(CHANNELS)}}
    labels=np.column_stack([series[c] for c in CHANNELS[:4]])
    series['labels_m']=labels
    series['wusongkou'][-20:]=np.nan
    s=fit_training_stats(series,(2020,),'a'*64)
    assert s.high_threshold_m[0]==np.quantile(labels[:,0],.95,method='linear')
    assert s.target_mean[0]==49.5
