"""Device and parent-group counterexamples use synthetic tensors and receipts only."""
import copy
from dataclasses import asdict
import json
from pathlib import Path
import numpy as np
import pytest
import torch
from src.contracts import Whitening
from src.execution import device_identity,bound_device,bind_authorized_device,move_parts,move_batch
from src.scheduler import digest_json,code_identity,resolve_effective_config,seal_group,verify_parent_binding
from src.runtime import build_session,stats_record
from src.models import make_parts
from src.state_estimators import make_branches,configure_branch,hash_module
from src.differentiable_filter import make_noise
from src.training import deterministic_runtime,train_effective_batch,make_optimizer
from src.diagnostics import foundation_diagnostic,FOUNDATION_DIAGNOSTICS

ROOT=Path(__file__).resolve().parents[1]


def registry():
    return json.loads((ROOT/'configs/registry-v3.json').read_text(encoding='utf-8'))


def parent_fixture(child):
    gate=child['case']+'__final_foundation_group__seal'
    members=child['dependency_members'][gate]
    outcomes={m:{'status':'success','budget_final':True,'epochs':200,'checkpoint_sha256':digest_json(m),
        'best_epoch':1,'validation_mae':[1.]*200,'case':child['case'],'seed':int(m.rsplit('__s',1)[1].split('__')[0]),
        'method':'foundation','learning_rate':.001,'initializer_hash':'c'*64,'normalization_hash':'d'*64,
        'whitening_hash':'e'*64} for m in members}
    seal=seal_group(gate,outcomes,200,expected_members=members)
    parent=child['parent_run_id']; row=outcomes[parent]
    effective={'parent_run_id':parent,'parent_hash':row['checkpoint_sha256'],'parent_best_epoch':1,
               'initializer_hash':'c'*64,'normalization_hash':'d'*64}
    return {gate:seal},effective


def test_device_must_be_explicit_and_match_quote_and_authority():
    cpu=device_identity('cpu'); effective={'device':'cpu','device_identity':cpu}
    assert str(bind_authorized_device(effective,{'device_identity':cpu},{'device_identity':cpu}))=='cpu'
    for broken in ({}, {'device':'cpu'}, {'device':'cpu','device_identity':{**cpu,'name':'wrong'}}):
        with pytest.raises(ValueError): bound_device(broken)
    with pytest.raises(PermissionError):
        bind_authorized_device(effective,{'device_identity':{**cpu,'name':'wrong'}},{'device_identity':cpu})


def test_foundation_constructor_uses_declared_device_and_rejects_unavailable_device(tmp_path,stats):
    r=registry(); row=next(x for x in r['runs'] if x['type']=='tune_foundation')
    p=json.loads((ROOT/'configs/protocol-v3.json').read_text(encoding='utf-8'))
    identities={k:None for k in ('parent_hash','initializer_hash','analysis_initialization_hash','training_data_hash',
        'normalization_hash','whitening_hash','tide_source_hash','code_hash','shuffle_hash')}
    identities.update(code_hash=code_identity(),normalization_hash=digest_json(stats_record(stats)))
    eff=resolve_effective_config(row,p,.001,identities)
    eff.update(device='cpu',device_identity=device_identity('cpu'))
    config={'status':'frozen_authorized','effective_config':eff}
    session=build_session(row,config,p,stats,tmp_path/'positive')
    assert str(session.device)=='cpu'
    broken=copy.deepcopy(config); broken['effective_config']['device']='cuda:99999'
    with pytest.raises((ValueError,RuntimeError,AssertionError)):
        build_session(row,broken,p,stats,tmp_path/'negative')
    assert not (tmp_path/'negative').exists()


def test_parent_self_hash_cannot_replace_complete_group_identity():
    child=next(x for x in registry()['runs'] if x['type']=='primary' and x['method']=='encoder_fixed')
    seals,eff=parent_fixture(child)
    verify_parent_binding(child,eff,seals)
    for key in ('parent_hash','initializer_hash','normalization_hash'):
        broken={**eff,key:'b'*64}
        with pytest.raises(ValueError): verify_parent_binding(child,broken,seals)
    for key,value in (('parent_run_id','wrong'),('parent_best_epoch',2)):
        with pytest.raises(ValueError): verify_parent_binding(child,{**eff,key:value},seals)
    corrupt=copy.deepcopy(seals); seal=next(iter(corrupt.values()))
    seal.member_evidence[eff['parent_run_id']]['checkpoint_sha256']='b'*64
    with pytest.raises(ValueError): verify_parent_binding(child,eff,corrupt)
    with pytest.raises(ValueError): verify_parent_binding(child,eff,{})


@pytest.mark.parametrize('epochs',[200,400])
def test_group_cannot_seal_claimed_budget_without_complete_validation_records(epochs):
    row={'status':'success','budget_final':True,'epochs':epochs,'checkpoint_sha256':'a'*64,
         'best_epoch':1,'validation_mae':[1.]*epochs}
    assert seal_group('synthetic_budget',{'member':row},epochs,expected_members=['member']).epochs==epochs
    for series in ([1.],[1.]*(epochs-1),[-1.]*epochs):
        with pytest.raises(ValueError):
            seal_group('synthetic_budget',{'member':{**row,'validation_mae':series}},epochs,expected_members=['member'])


@pytest.mark.parametrize('kind',FOUNDATION_DIAGNOSTICS)
def test_foundation_diagnostics_keep_full_state_and_23_future_steps(kind,batch):
    parts=make_parts('legacy_lstm','small',17)
    wh=Whitening(torch.zeros(64,dtype=torch.float64),torch.ones(64,dtype=torch.float64))
    before=hash_module(parts.process)
    with torch.no_grad(): output=foundation_diagnostic(parts,wh,batch,kind)
    assert output.shape==(1,23,4) and torch.isfinite(output).all()
    assert before==hash_module(parts.process)


def test_midpoint_diagnostic_does_not_use_later_target_observations(batch):
    from src.contracts import ModelBatch
    parts=make_parts('explicit_gru','small',17)
    modified=batch.history.clone(); modified[:,24:,:4]+=10
    altered=ModelBatch(modified,batch.analysis_controls,batch.forecast_controls,batch.midpoint_controls,
                       batch.targets,batch.targets_m,batch.high_mask)
    with torch.no_grad():
        a=foundation_diagnostic(parts,None,batch,'midpoint_no_target_observations')
        b=foundation_diagnostic(parts,None,altered,'midpoint_no_target_observations')
    assert torch.equal(a,b)


@pytest.mark.parametrize('family,capacity,d',[('legacy_lstm','small',64),('explicit_gru','small',32),
    ('legacy_lstm','historical_capacity',256),('explicit_gru','historical_capacity',128)])
def test_actual_gpu_complete_filter_and_foundation_step(family,capacity,d,batch,stats,tmp_path,device_evidence):
    if not torch.cuda.is_available():
        pytest.skip('GPU unavailable on this host; CPU coverage is retained')
    deterministic_runtime()
    identity=device_identity('cuda:0')
    device=bind_authorized_device({'device':'cuda:0','device_identity':identity},
                                  {'device_identity':identity},{'device_identity':identity})
    p=json.loads((ROOT/'configs/protocol-v3.json').read_text(encoding='utf-8'))
    row=next(x for x in registry()['runs'] if x['type']=='tune_foundation' and x['case']==family+'__'+capacity)
    from repair_fixtures import identities
    eff=resolve_effective_config(row,p,.001,identities(stats,{'scope':'synthetic_gpu_batch','files':[]}))
    eff.update(device='cuda:0',device_identity=identity)
    session=build_session(row,{'status':'frozen_authorized','effective_config':eff},p,stats,tmp_path)
    assert str(session.device)=='cuda:0'
    base=session.parts
    gpu_batch=move_batch(batch,device)
    torch.cuda.reset_peak_memory_stats()
    result=train_effective_batch(base,None,None,'foundation',gpu_batch,stats,session.optimizer)
    parts=make_branches(base,100017)['filter_joint']; noise=make_noise(d)
    wh=Whitening(torch.zeros(d,dtype=torch.float64),torch.ones(d,dtype=torch.float64))
    configure_branch(parts,noise,'filter_joint'); wh=move_parts(parts,noise,wh,device)
    output=train_effective_batch(parts,noise,wh,'filter_joint',gpu_batch,stats,make_optimizer(parts,noise,.001))
    tensors=[gpu_batch.history,noise.raw_q,noise.raw_r,noise.raw_p0,wh.mean,wh.scale]
    assert all(str(t.device)=='cuda:0' for t in tensors)
    assert np.isfinite(result['loss_cm']) and np.isfinite(output['loss_cm'])
    assert torch.cuda.max_memory_allocated()/identity['total_memory_bytes']<=.8
    device_evidence.append({'scope':'synthetic batch only, not the 16-window resource pilot','case':family+'__'+capacity,
        'device_identity':identity,'state_dim':d,'sigma_points':2*d+1,'network_dtype':'float32','covariance_dtype':'float64',
        'foundation_loss_cm':result['loss_cm'],'filter_loss_cm':output['loss_cm'],
        'peak_allocated_bytes':torch.cuda.max_memory_allocated(),'batch_windows':len(batch.history),
        'formal_constructor_used':True,'deterministic_algorithms':torch.are_deterministic_algorithms_enabled()})
