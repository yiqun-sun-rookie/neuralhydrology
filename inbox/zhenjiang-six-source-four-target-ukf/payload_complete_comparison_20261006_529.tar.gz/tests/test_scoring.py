import json
from pathlib import Path
import numpy as np
import pytest
from src.contracts import TARGETS,PredictionRows
from src.scoring import (score_rows,paired_resamples,CORRECTED_QUANTILES,replacement_decision,choose_candidate,
                        historical_constraints,retention_admission,sensitivity_decision,event_diagnostics,calendar_blocks)

def rows_for(cube,observations,times,seeds):
    a,b,c,d=np.indices(cube.shape)
    return PredictionRows(np.asarray(times)[b.ravel()],c.ravel()+1,np.asarray(TARGETS)[d.ravel()],
                          np.asarray(seeds)[a.ravel()],cube.ravel(),np.broadcast_to(observations[None],cube.shape).ravel())

def test_ten_cm_and_average_seed_error_not_ensemble_error():
    times=np.array(['2024-06-01'],dtype='datetime64[h]'); labels=np.full((1,23,4),190.)
    predictions=np.full((2,1,23,4),200.); predictions[1]=180.
    rows=rows_for(predictions,labels,times,[17,29]); out=score_rows(rows,np.full(4,180.))
    assert out['overall_mae_cm']==10 and np.abs(predictions.mean(0)-labels).mean()==0
    assert len(out['lead_mae_cm'])==23
    short=PredictionRows(**{k:getattr(rows,k)[:-1] for k in rows.__dataclass_fields__})
    with pytest.raises(ValueError): score_rows(short,np.full(4,180.))

def test_full_50000_resamples_and_shared_time_blocks_independent_seed_sets():
    times=np.datetime64('2023-01-01')+np.arange(365)*np.timedelta64(1,'D')
    left=np.full((5,365,1,1),10.); right=np.full((3,365,1,1),9.)
    result=paired_resamples(left,right,times,False,7,50000,20261005)
    assert len(result['relative_improvement_samples'])==50000
    assert np.allclose(result['corrected_interval'],[.1,.1])
    assert result['left_seed_draws'].shape==(50000,5) and result['right_seed_draws'].shape==(50000,3)
    again=paired_resamples(left,right*2,times,False,7,10,20261005)
    base=paired_resamples(left,right,times,False,7,10,20261005)
    assert again['time_sampling_sha256']==base['time_sampling_sha256']
    with pytest.raises(ValueError): paired_resamples(left,right,times,True,7,10,7)

def test_calendar_tail_is_reaggregated_by_sample_count():
    times=np.datetime64('2023-01-01')+np.arange(365)*np.timedelta64(1,'D')
    blocks=calendar_blocks(times,7)
    assert len(blocks[-1])==1
    a=np.arange(365.).reshape(1,365,1,1)+1; b=a*.8
    result=paired_resamples(a,b,times,True,7,300,42)
    assert np.allclose(result['relative_improvement_samples'],.2)
    assert not np.allclose(result['left_mean_samples'],np.mean([a[:,x].mean() for x in blocks]))

def constraints():
    return [{'name':str(i),'point':.01,'upper':.04,'margin':.05,'estimable':True} for i in range(27)]

def test_upper_bound_undefined_specialist_and_unfrozen_policy():
    c=constraints()
    assert replacement_decision(c).startswith('无法验收')
    assert replacement_decision(c,policy_frozen=True).startswith('通过')
    c[-1]['upper']=.051
    assert replacement_decision(c,policy_frozen=True).startswith('不通过')
    c[-1]['estimable']=False
    assert replacement_decision(c,policy_frozen=True).startswith('无法验收')
    assert replacement_decision(c[:26],policy_frozen=True).startswith('无法验收')
    c=constraints(); c[-1]=dict(c[0])
    assert replacement_decision(c,policy_frozen=True).startswith('无法验收')

def test_27_named_constraints_five_vs_three_and_no_high_denominator():
    times=np.datetime64('2023-01-01')+np.arange(365)*np.timedelta64(1,'D')
    obs=np.broadcast_to((np.sin(np.arange(365)/8)*20+200)[:,None,None],(365,23,4)).copy()
    new=np.broadcast_to(obs,(5,*obs.shape)).copy()+1
    old=np.broadcast_to(obs,(3,*obs.shape)).copy()+2
    z=old[...,1:2]+1
    c=historical_constraints(new,old,z,obs,times,np.full(4,200.),.05,.01,repetitions=200)
    assert len(c)==27 and sum(x['name'].startswith('specialist') for x in c)==5
    assert sum('mae' in x['name'] for x in c)==17
    assert c[0]['upper']==pytest.approx(-.5)
    c=historical_constraints(new,old,z,obs,times,np.full(4,1000.),.05,.01,repetitions=10)
    assert not all(x['estimable'] for x in c)

def test_correction_retention_sensitivity_and_events():
    assert CORRECTED_QUANTILES==(.000390625,.999609375)
    full={s:list(range(100)) for s in TARGETS}; part={s:list(range(89)) for s in TARGETS}
    assert not retention_admission(full,part,full,full)['accepted']
    decisions={2023:{3:'通过',7:'通过',14:'不通过'},2024:{3:'通过',7:'通过',14:'通过'}}
    assert sensitivity_decision(decisions).startswith('对时间相关假设敏感')
    times=np.datetime64('2023-06-01')+np.arange(100)*np.timedelta64(1,'h')
    obs=np.zeros(100); obs[50]=10
    event=event_diagnostics(times,obs,5,times[40:41],np.zeros((1,23)))
    assert event['complete_evaluable_events']==1 and not event['stable_event_statistics_permitted']
    obs[49]=np.nan
    incomplete=event_diagnostics(times,obs,5,times[40:41],np.zeros((1,23)))
    assert incomplete['complete_evaluable_events']==0 and not incomplete['events'][0]['forecast_windows']

def test_repeated_valid_time_labels_must_agree():
    times=np.array(['2024-06-01T00','2024-06-01T01'],dtype='datetime64[h]')
    predictions=np.zeros((1,2,23,4)); labels=np.ones((2,23,4))
    labels[1,0,0]=2
    with pytest.raises(ValueError): score_rows(rows_for(predictions,labels,times,[17]),np.ones(4))

def test_only_primary_2022_candidate_can_be_selected():
    root=Path(__file__).resolve().parents[1]
    p=json.loads((root/'configs/protocol-v3.json').read_text(encoding='utf-8'))
    rows=[{'case':c['family']+'__'+c['capacity'],'method':m,'seed':s,'track':'primary','year':2022,
           'mae_cm':2.,'future_parameters':10+i} for i,c in enumerate(p['cases']) for m in p['method_order'] for s in p['seeds']]
    chosen=choose_candidate(rows,p)
    assert chosen['case']=='legacy_lstm__small' and chosen['method']=='encoder_fixed'
    rows[0]['year']=2024
    with pytest.raises(ValueError): choose_candidate(rows,p)
