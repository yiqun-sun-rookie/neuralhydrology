"""Real argument parsing and admission/sealing/scoring, with synthetic sources.

Group budgets use labelled replay histories after one real optimizer epoch.
The large evaluation flow substitutes numerical prediction only; real tensor
and frozen-checkpoint prediction paths are covered in companion tests.
"""
import copy
import hashlib
import json
from pathlib import Path
import pytest
from repair_fixtures import (ROOT,save,command,collection_fixture,make_sources,identities,fake_prediction)
from src.scheduler import digest_json,code_identity
from src.execution import device_identity
from src.sealing import manifest_identity
from src.runtime import load_stage,fit_stage_stats


def selection_flow(tmp_path,monkeypatch):
    flow=collection_fixture(tmp_path)
    inputs={key:save(tmp_path/(key+'.json'),flow[key]) for key in
            ('models','manifest','references','calendar_contract','margin_policy','validation','evidence','authority')}
    selected=tmp_path/'selected.json'
    command(monkeypatch,'seal_selection',protocol=flow['protocol_path'],**inputs,output=selected)
    lock=json.loads(selected.read_text(encoding='utf-8'))
    flow['authority']['selection_sha256']=lock['selection_sha256']; save(inputs['authority'],flow['authority'])
    return flow,inputs,selected


def test_selection_cli_and_two_year_evaluation_output_every_diagnostic(tmp_path,monkeypatch):
    flow,paths,selected=selection_flow(tmp_path,monkeypatch)
    import src.runtime
    calls=[]
    def predict(*args,**kwargs):
        calls.append((args[0]['exp_id'],kwargs.get('diagnostic_kind'),args[6] if len(args)>6 else True))
        return fake_prediction(*args,**kwargs)
    monkeypatch.setattr(src.runtime,'prediction_table',predict)
    output=tmp_path/'evaluation'
    command(monkeypatch,'evaluate_frozen',protocol=flow['protocol_path'],authority=paths['authority'],selection=selected,
            **{k:paths[k] for k in ('models','manifest','references','margin_policy','calendar_contract')},output=output)
    diagnostics=json.loads((output/'diagnostic_manifest.json').read_text(encoding='utf-8'))
    assert set(diagnostics)=={'2023','2024'}
    for year,rows in diagnostics.items():
        assert len(rows)==140 and len({r['kind'] for r in rows})==4
        assert all(r['station_order']==['nanjing','zhenjiang','jiangyin','xuliujing'] for r in rows)
        for row in rows:
            path=Path(row['path'])
            assert row['prediction_sha256']==hashlib.sha256(path.read_bytes()).hexdigest()
    comparisons=json.loads((output/'all_64_contrasts.json').read_text(encoding='utf-8'))
    protection=json.loads((output/'replacement.json').read_text(encoding='utf-8'))
    assert len(comparisons)==64
    assert all(len(rows)==27 for year in protection['constraints'].values() for rows in year.values())
    assert any(kind=='midpoint_no_target_observations' for _,kind,_ in calls)
    assert any(kind=='initial_noise_filter' for _,kind,_ in calls)
    assert sum(not observations for _,_,observations in calls)==80  # 40 physical filters per year
    assert (output/'calendar_lock.json').is_file()


@pytest.mark.parametrize('changed',['margin_policy','manifest','calendar_contract'])
def test_evaluation_cli_refuses_changed_commitment_before_loading_values(tmp_path,monkeypatch,changed):
    flow,paths,selected=selection_flow(tmp_path,monkeypatch)
    if changed=='margin_policy': flow[changed]['relative_mae_margin']=.04
    elif changed=='manifest': flow[changed]['files'][0]['provider']='changed provider'
    else: flow[changed]['selection_2022_sha256']='c'*64
    save(paths[changed],flow[changed])
    import src.runtime
    loads=[]
    monkeypatch.setattr(src.runtime,'load_stage',lambda *args: loads.append(args))
    with pytest.raises(ValueError,match='changed after sealing'):
        command(monkeypatch,'evaluate_frozen',protocol=flow['protocol_path'],authority=paths['authority'],selection=selected,
            **{k:paths[k] for k in ('models','manifest','references','margin_policy','calendar_contract')},output=tmp_path/'refused')
    assert not loads and not (tmp_path/'refused').exists()


def test_synthetic_admission_group_resolution_real_optimizer_and_final_budget_receipt(tmp_path,monkeypatch):
    protocol=json.loads((ROOT/'configs/protocol-v3.json').read_text(encoding='utf-8'))
    protocol['authority'].update(formal_training=True,data_admission=True)
    protocol_path=save(tmp_path/'protocol.json',protocol); sha=hashlib.sha256(protocol_path.read_bytes()).hexdigest()
    registry=json.loads((ROOT/'configs/registry-v3.json').read_text(encoding='utf-8')); registry['protocol_sha256']=sha
    registry_path=save(tmp_path/'registry.json',registry)
    manifest=make_sources(tmp_path/'sources',tuning=True); manifest_path=save(tmp_path/'manifest.json',manifest)
    stats=fit_stage_stats(load_stage(manifest,'tuning_train'),manifest)
    group=registry['runs'][0]['budget_group']; members=[r for r in registry['runs'] if r['budget_group']==group]
    cpu=device_identity('cpu')
    quote={'status':'sealed_success','scope':'synthetic_quote_fixture','protocol_sha256':sha,'cost_upper':0,
           'group_seconds_upper':{group:1000},'device_identity':cpu}
    policy={'status':'frozen_approved','relative_mae_margin':0.,'miss_and_false_rate_margin':0.,'scope':'synthetic_only'}
    bindings={'resource_quote_sha256':digest_json(quote),'margin_policy_sha256':digest_json(policy),
              'data_manifest_sha256':manifest_identity(manifest),'code_hash':code_identity()}
    auth={'authority':{'data_admission':True,'formal_training':True},'protocol_sha256':sha,'scope':'temporary synthetic only',
          'maximum_cost':0,'device_identity':cpu,**bindings}
    auth_path=save(tmp_path/'authority.json',auth); quote_path=save(tmp_path/'quote.json',quote)
    policy_path=save(tmp_path/'policy.json',policy)
    external={'status':'admitted','protocol_sha256':sha,**bindings}; external['evidence_sha256']=digest_json(external)
    gate=members[0]['dependency_ids'][0]
    seals_path=save(tmp_path/'dependencies.json',{'seals':{},'completed_run_ids':[], 'external_evidence':{gate:external}})
    id_path=save(tmp_path/'identities.json',{r['exp_id']:identities(stats,manifest) for r in members})
    rates_path=save(tmp_path/'rates.json',{})
    command(monkeypatch,'admit_data',protocol=protocol_path,authority=auth_path,manifest=manifest_path,
            phase='tuning_train',output=tmp_path/'admission.json')
    configs_path=tmp_path/'resolved_group.json'
    command(monkeypatch,'resolve_group',protocol=protocol_path,authority=auth_path,group=group,
            registry=registry_path,identities=id_path,rates=rates_path,seals=seals_path,resource_quote=quote_path,output=configs_path)
    import src.runtime
    steps=[]
    def replay_after_actual_epoch(sessions,windows,times,batches):
        for session in sessions.values():
            session.epoch(windows,times,batches,1)
            steps.extend(session.train_metrics[0])
            session.values=[session.values[0]]*200
            session.shuffle_hashes=[session.shuffle_hashes[0]]*200
        results={k:s.finish(200,True) for k,s in sessions.items()}
        for row in results.values(): row['scope']='synthetic actual epoch then labelled 200-epoch budget replay'
        return results,200
    monkeypatch.setattr(src.runtime,'train_group',replay_after_actual_epoch)
    receipt=tmp_path/'group_receipt.json'
    command(monkeypatch,'run_registered',protocol=protocol_path,authority=auth_path,group=group,registry=registry_path,
            configs=configs_path,manifest=manifest_path,seals=seals_path,resource_quote=quote_path,
            margin_policy=policy_path,output_root=tmp_path/'runs',receipt=receipt)
    result=json.loads(receipt.read_text(encoding='utf-8'))
    assert len(result['members'])==3 and result['seal']['epochs']==200 and steps
    assert all(r['device_identity']==cpu for r in result['members'].values())
    assert all(len(r['validation_mae'])==200 for r in result['members'].values())
    # Administrative evidence cannot be replaced by an empty fabricated training group.
    broken=json.loads(seals_path.read_text(encoding='utf-8')); broken['external_evidence']={}; save(seals_path,broken)
    with pytest.raises(PermissionError):
        command(monkeypatch,'run_registered',protocol=protocol_path,authority=auth_path,group=group,registry=registry_path,
            configs=configs_path,manifest=manifest_path,seals=seals_path,resource_quote=quote_path,
            margin_policy=policy_path,output_root=tmp_path/'blocked_runs',receipt=tmp_path/'blocked_receipt.json')
    assert not (tmp_path/'blocked_runs').exists()
