"""Counterexamples distinguish selection, historical and post-seal calendars."""
import copy
import pytest
from repair_fixtures import collection_fixture
from src.scheduler import digest_json
from src.sealing import (selection_bindings,verify_evaluation_bindings,validate_model_collection,
    lock_evaluation_calendars,calendar_snapshot,validate_policy)
from src.runtime import load_stage
from src.diagnostics import diagnostic_collection


@pytest.fixture
def flow(tmp_path):
    return collection_fixture(tmp_path)


def sealed(flow):
    lock={'status':'sealed_success','evidence':flow['evidence'],
          'bindings':selection_bindings(flow['models'],flow['manifest'],flow['references'],
                                       flow['margin_policy'],flow['calendar_contract'])}
    return {**lock,'selection_sha256':digest_json(lock)}


@pytest.mark.parametrize('field',['models','manifest','references','margin_policy','calendar_contract'])
def test_every_preselection_identity_cannot_be_changed(flow,field):
    lock=sealed(flow)
    verify_evaluation_bindings(lock,flow['models'],flow['manifest'],flow['references'],flow['margin_policy'],
                               flow['calendar_contract'],flow['protocol'])
    broken=copy.deepcopy(flow); broken[field]['new_field']='changed after seal'
    with pytest.raises(ValueError):
        verify_evaluation_bindings(lock,broken['models'],broken['manifest'],broken['references'],
                                   broken['margin_policy'],broken['calendar_contract'],broken['protocol'])


@pytest.mark.parametrize('value',[-1,float('nan'),float('inf'),None,'0.05'])
def test_unapproved_or_non_numeric_margin_cannot_be_sealed(value):
    with pytest.raises(ValueError):
        validate_policy({'status':'frozen_approved','relative_mae_margin':value,'miss_and_false_rate_margin':.01})


def test_distinct_calendar_roles_and_first_postseal_lock(flow):
    lock=sealed(flow); contract=flow['calendar_contract']; manifest=flow['manifest']
    stages={y:load_stage(manifest,'evaluation_'+str(y)) for y in (2023,2024)}
    calendars=lock_evaluation_calendars(lock,manifest,contract,stages)
    assert set(calendars['years'])=={'2023','2024'}
    assert all(v['eligible_windows']==13 for v in calendars['years'].values())
    assert lock_evaluation_calendars(lock,manifest,contract,stages,calendars)==calendars
    changed=copy.deepcopy(stages); changed[2023]['eligible']=changed[2023]['eligible'][1:]
    with pytest.raises(ValueError): lock_evaluation_calendars(lock,manifest,contract,changed,calendars)
    committed=copy.deepcopy(contract)
    for y in (2023,2024):
        committed['evaluation'][str(y)]={'mode':'precommitted','sha256':digest_json(calendar_snapshot(stages[y],'evaluation_'+str(y)))}
    committed_flow=copy.deepcopy(flow); committed_flow['calendar_contract']=committed
    committed_lock=sealed(committed_flow)
    assert lock_evaluation_calendars(committed_lock,manifest,committed,stages)['years']==calendars['years']
    with pytest.raises(ValueError): lock_evaluation_calendars(committed_lock,manifest,committed,changed)
    with pytest.raises(ValueError): lock_evaluation_calendars(lock,manifest,committed,stages)
    wrong_reference=copy.deepcopy(flow['references'])
    wrong_reference['years']['2023']['joint']['calendar_sha256']=contract['selection_2022_sha256']
    with pytest.raises(ValueError):
        selection_bindings(flow['models'],manifest,wrong_reference,flow['margin_policy'],contract)
    granted=copy.deepcopy(manifest); granted['evaluation_year_reads']=False
    assert selection_bindings(flow['models'],granted,flow['references'],flow['margin_policy'],contract)==lock['bindings']


def test_all_foundations_and_four_diagnostic_types_required(flow):
    index=flow['models']; validate_model_collection(index,flow['protocol'],flow['evidence']['logical_run_results'])
    diagnostics=diagnostic_collection(index,flow['protocol'])
    assert len(diagnostics)==140 and len({d['kind'] for d in diagnostics})==4
    assert sum(d['kind']=='initial_noise_filter' for d in diagnostics)==20
    missing=copy.deepcopy(index); missing['models']=[m for m in index['models'] if m['run']['method']!='foundation']
    with pytest.raises(ValueError): validate_model_collection(missing,flow['protocol'])
    incomplete=copy.deepcopy(index); incomplete['foundation_seals'].pop(next(iter(incomplete['foundation_seals'])))
    with pytest.raises(ValueError): validate_model_collection(incomplete,flow['protocol'])
    altered=copy.deepcopy(index); alias=next(m for m in altered['models'] if m.get('alias_of'))
    alias['config']['effective_config']['loss']='different loss'
    with pytest.raises(ValueError): validate_model_collection(altered,flow['protocol'])
