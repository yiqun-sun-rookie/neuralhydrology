"""Explicit synthetic receipts, single-year sources and calendar fixtures.

Budget histories and checkpoint identities here are fabricated flow fixtures.
They are never written to the delivery's real admission/configuration records.
Actual numerical training and checkpoint reloads are tested separately.
"""
import copy
from dataclasses import asdict
import hashlib
import importlib
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from src.contracts import CHANNELS,TARGETS
from src.execution import device_identity
from src.runtime import load_stage,fit_stage_stats,stats_record,prepare_windows
from src.scheduler import code_identity,digest_json,resolve_effective_config,seal_group
from src.sealing import CALENDAR_RULES,calendar_snapshot,historical_calendar_identity

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))


def save(path,value):
    path=Path(path); path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    return path


def command(monkeypatch,name,**arguments):
    argv=[name]
    for key,value in arguments.items():
        argv+=['--'+key.replace('_','-'),str(value)]
    monkeypatch.setattr(sys,'argv',argv)
    importlib.import_module(name).main()


def make_sources(root,tuning=False):
    root.mkdir(parents=True,exist_ok=True)
    manifest={'status':'admitted','scope':'synthetic_only','approved_roots':[str(root)],'forbidden_roots':[],
        'units':'m','timestamp_rule':'whole_hour','timezone':'synthetic UTC',
        'tide_training_years':[2017,2018,2019,2020] if tuning else [2017,2018,2019,2020,2021],
        'evaluation_year_reads':not tuning,'business_time_availability_certified':False,'files':[]}
    for year in range(2017,2025):
        if tuning and year>2021: continue
        phase=('tuning_train' if year<=2020 else 'tuning_select') if tuning else (
            'final_train' if year<=2021 else 'final_select' if year==2022 else 'evaluation_'+str(year))
        times=np.datetime64(str(year)+'-06-01T00')+np.arange(83)*np.timedelta64(1,'h')
        x=np.arange(83,dtype=float)
        history=np.stack([2+j+.4*np.sin(x/(3+j))+.02*x for j in range(7)],axis=1)
        for role,key,values,stations in (
            ('realtime_inputs','history_m',history,list(CHANNELS)),
            ('qc_labels','labels_m',history[:,:4],list(TARGETS)),
            ('astronomical_tide','tide_m',history[:,6],['astronomical_tide'])):
            path=root/(str(year)+'__'+role+'.npz'); np.savez(path,times=times,**{key:values})
            manifest['files'].append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                'years':[year],'role':role,'phases':[phase],'station_order':stations,
                'datum':'synthetic metres','provider':'generated test fixture'})
    return manifest


def identities(stats,manifest):
    result={k:None for k in ('parent_hash','initializer_hash','analysis_initialization_hash','training_data_hash',
        'normalization_hash','whitening_hash','tide_source_hash','code_hash','shuffle_hash')}
    result.update(training_data_hash=digest_json(manifest),normalization_hash=digest_json(stats_record(stats)),
        tide_source_hash=digest_json([f for f in manifest['files'] if f['role']=='astronomical_tide']),
        code_hash=code_identity(),shuffle_hash=digest_json('registered synthetic seed stream'))
    return result


def fake_prediction(run,config,checkpoint,windows,issue_times,stats,use_observations=True,
                    diagnostic_kind=None,foundation_whitening=None):
    """Flow-only replacement: the numerical model path has its own real tensor checks."""
    labels=np.concatenate([w.targets_m[:,24:].numpy() for w in windows])*100
    b,h,s=np.indices(labels.shape)
    offset=1.+.1*('filter' in run['method'])+.001*run['seed']
    return pd.DataFrame({'run_id':run['exp_id'],'year':np.asarray(issue_times)[b.ravel()].astype('datetime64[Y]').astype(int)+1970,
        'seed':run['seed'],'issue_time':np.asarray(issue_times)[b.ravel()],'lead_hour':h.ravel()+1,
        'station':np.asarray(TARGETS)[s.ravel()],'prediction_cm':labels.ravel()+offset,
        'observation_cm':labels.ravel(),'eligible':True,'reason':''})


def collection_fixture(tmp_path):
    protocol=json.loads((ROOT/'configs/protocol-v3.json').read_text(encoding='utf-8'))
    protocol['authority']['formal_training']=True
    protocol['statistics']['resamples']=40  # flow check only; formal protocol remains 50,000
    protocol_path=save(tmp_path/'synthetic_protocol.json',protocol)
    sha=hashlib.sha256(protocol_path.read_bytes()).hexdigest()
    registry=json.loads((ROOT/'configs/registry-v3.json').read_text(encoding='utf-8'))
    registry['protocol_sha256']=sha
    manifest=make_sources(tmp_path/'synthetic_sources')
    stats=fit_stage_stats(load_stage(manifest,'final_train'),manifest)
    stats_json=stats_record(stats); stat_sha=digest_json(stats_json)
    outcomes={}
    for run in registry['runs']:
        value=1.+.01*protocol['method_order'].index(run['method']) if run['method']!='foundation' else 2.
        outcomes[run['exp_id']]={'status':'success','scope':'fabricated_budget_history_for_flow_test',
            'budget_final':True,'epochs':200,'best_epoch':1,'validation_mae':[value]*200,
            'checkpoint_sha256':digest_json(run['exp_id']),'initializer_hash':digest_json(run['case']),
            'normalization_hash':stat_sha,'case':run['case'],'seed':run['seed'],'method':run['method'],
            'learning_rate':.001}
    seals={}; whitening={}
    for case in protocol['cases']:
        name=case['family']+'__'+case['capacity']; d=case['state_dim']
        wh={'mean':[0.]*d,'scale':[1.]*d}; whitening[name]=wh
        members=[r['exp_id'] for r in registry['runs'] if r['type']=='final_foundation' and r['case']==name]
        for member in members: outcomes[member]['whitening_hash']=digest_json(wh)
        gate=name+'__final_foundation_group__seal'
        seals[gate]=asdict(seal_group(gate,{m:outcomes[m] for m in members},200,expected_members=members))
    models=[]; validation=[]
    for run in registry['runs']:
        if run['type'] not in ('final_foundation','primary','controlled'): continue
        ids=identities(stats,manifest)
        if run['method']!='foundation':
            parent=outcomes[run['parent_run_id']]
            ids.update(parent_run_id=run['parent_run_id'],parent_hash=parent['checkpoint_sha256'],parent_best_epoch=1,
                initializer_hash=parent['initializer_hash'])
            if run['method'].startswith('filter'):
                ids.update(whitening=whitening[run['case']],whitening_hash=parent['whitening_hash'])
        eff=resolve_effective_config(run,protocol,.001,ids)
        eff.update(device='cpu',device_identity=device_identity('cpu'))
        item={'run':copy.deepcopy(run),'config':{'status':'frozen_authorized','protocol_sha256':sha,'effective_config':eff},
              'checkpoint':{'path':str(tmp_path/(run['exp_id']+'.fixture')),
                            'sha256':outcomes[run['exp_id']]['checkpoint_sha256']}}
        if run['type']=='final_foundation': item['whitening']=whitening[run['case']]
        if run['type']=='primary':
            validation.append({'track':'primary','year':2022,'case':run['case'],'method':run['method'],
                'seed':run['seed'],'mae_cm':outcomes[run['exp_id']]['validation_mae'][0],'future_parameters':100})
        models.append(item)
    # Alias all 80 controlled branches by complete effective identity, before any evaluation.
    byid={m['run']['exp_id']:m for m in models}
    for item in models:
        if item['run']['type']!='controlled': continue
        source=item['run']['may_alias']; item['alias_of']=source
        item['checkpoint']=copy.deepcopy(byid[source]['checkpoint'])
        item['config']['effective_config']=copy.deepcopy(byid[source]['config']['effective_config'])
        outcomes[item['run']['exp_id']].update(status='alias',checkpoint_sha256=item['checkpoint']['sha256'],alias_of=source)
    index={'code_hash':code_identity(),'training_stats':stats_json,'models':models,'foundation_seals':seals,
           'scope':'synthetic metadata only, numerical checkpoints checked separately'}
    refs={'status':'admitted','scope':'synthetic_only','approved_roots':[str(tmp_path)],'forbidden_roots':[],
          'evaluation_year_reads':True,'files':[],'years':{}}
    historical={}
    for year in (2023,2024):
        stage=load_stage(manifest,'evaluation_'+str(year)); windows,times=prepare_windows(stage,stats)
        historical[str(year)]={}; refs['years'][str(year)]={}
        for role in ('joint','specialist'):
            frames=[]
            for seed in (17,29,43):
                run={'exp_id':'synthetic_historical_'+role,'seed':seed,'method':'historical'}
                frame=fake_prediction(run,None,None,windows,times,stats)
                frame['prediction_cm']+=.5
                if role=='specialist': frame=frame[frame.station=='zhenjiang']
                frames.append(frame)
            frame=pd.concat(frames)
            path=tmp_path/(role+'_'+str(year)+'.csv'); frame.to_csv(path,index=False)
            calendar_sha=historical_calendar_identity(frame,role,year)
            historical[str(year)][role]=calendar_sha
            refs['years'][str(year)][role]={'path':str(path),'calendar_sha256':calendar_sha}
            refs['files'].append({'path':str(path),'role':'historical_predictions','years':[year],
                'phases':['evaluation_'+str(year)],'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    contract={'status':'frozen','rules':copy.deepcopy(CALENDAR_RULES),
        'selection_2022_sha256':digest_json(calendar_snapshot(load_stage(manifest,'final_select'),'final_select')),
        'historical_calendars':historical,'evaluation':{str(y):{'mode':'generate_after_model_seal'} for y in (2023,2024)}}
    policy={'status':'frozen_approved','scope':'synthetic_fixture_only','relative_mae_margin':.05,'miss_and_false_rate_margin':.01}
    for run in registry['runs']:
        if run['type'] in ('primary','controlled','final_foundation'):
            outcomes[run['exp_id']]['selection_calendar_sha256']=contract['selection_2022_sha256']
    evidence={'status':'all_final_groups_sealed','scope':'fabricated_flow_receipts_only','protocol_sha256':sha,
        'logical_run_results':outcomes,'all_checkpoint_hashes':digest_json(index),
        'benchmark_manifest_sha256':digest_json(refs),'selection_2022_calendar_sha256':contract['selection_2022_sha256'],
        'all_choice_hashes':digest_json('synthetic only'),'validation_rows_sha256':digest_json(validation)}
    authority={'authority':{'formal_training':True,'evaluation_year_reads':True},'protocol_sha256':sha,
               'scope':'temporary synthetic fixture permissions only'}
    return {'protocol':protocol,'protocol_path':protocol_path,'sha':sha,'registry':registry,'manifest':manifest,
        'stats':stats,'models':index,'references':refs,'calendar_contract':contract,'margin_policy':policy,
        'validation':validation,'evidence':evidence,'authority':authority}
