import hashlib
import numpy as np
import pytest
from src.contracts import CHANNELS,TARGETS
from src.runtime import load_stage,fit_stage_stats,prepare_windows

def test_separate_synthetic_year_files_admitted_and_wrong_channel_order_refused(tmp_path):
    entries=[]
    for year in range(2017,2022):
        times=np.datetime64(str(year)+'-06-01')+np.arange(80)*np.timedelta64(1,'h')
        h=np.column_stack([np.sin(np.arange(80)/(j+1))+j for j in range(7)])
        for role,key,value,order in [('realtime_inputs','history_m',h,CHANNELS),
                                     ('qc_labels','labels_m',h[:,:4],TARGETS),
                                     ('astronomical_tide','tide_m',h[:,6],('astronomical_tide',))]:
            p=tmp_path/f'{year}_{role}.npz'; np.savez(p,times=times,**{key:value})
            entries.append({'path':str(p),'years':[year],'role':role,'phases':['final_train'],
                'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'station_order':list(order),
                'datum':'synthetic_metres','provider':'synthetic_test'})
    manifest={'status':'admitted','approved_roots':[str(tmp_path)],'units':'m','timestamp_rule':'whole_hour',
              'timezone':'Asia/Shanghai','tide_training_years':list(range(2017,2022)),
              'business_time_availability_certified':False,'files':entries}
    stage=load_stage(manifest,'final_train')
    stats=fit_stage_stats(stage,manifest); windows,times=prepare_windows(stage,stats)
    assert len(windows)==50 and len(times)==50 and stats.years==tuple(range(2017,2022))
    entries[0]['station_order'][0]='swapped_station'
    with pytest.raises(ValueError): load_stage(manifest,'final_train')
