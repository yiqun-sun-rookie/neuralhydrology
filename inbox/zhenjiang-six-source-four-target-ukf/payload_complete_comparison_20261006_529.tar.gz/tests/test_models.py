import pytest
import torch
from src.contracts import CASES
from src.models import make_parts, count_parameters, pack_lstm_state, unpack_lstm_state, rollout

def test_complete_lstm_state_roundtrip():
    h=torch.arange(64.).reshape(2,2,16); c=h+100
    state=pack_lstm_state(h,c)
    restored_h,restored_c=unpack_lstm_state(state,16)
    assert state.shape==(2,64) and torch.equal(h,restored_h) and torch.equal(c,restored_c)

@pytest.mark.parametrize('family,capacity,width,d',CASES)
def test_parameter_counts_and_forecasts(family,capacity,width,d,batch):
    p=make_parts(family,capacity,17); counts=count_parameters(p)
    enc=(12*width**2+44*width if family=='legacy_lstm' else 3*width**2+28*width+2*width*d+d)
    future=(16*width**2+32*width+4 if family=='legacy_lstm' else 4*d**2+16*d)
    assert (counts['encoder'],counts['future'],counts['total'])==(enc,future,enc+future)
    s=p.initializer(batch.history[:,:24])
    assert s.shape==(1,d)
    out=rollout(p.process,p.readout,s,batch.forecast_controls)
    long=rollout(p.process,p.readout,s,batch.midpoint_controls)
    assert out.shape==(1,23,4) and long.shape==(1,47,4)
    assert torch.equal(out[:,0],p.readout(p.process(s,batch.forecast_controls[:,0])))
    assert not torch.equal(out[:,0],p.readout(s))
    if family=='explicit_gru': assert torch.equal(p.readout(s),s[:,:4])

def test_lstm_wrapper_matches_native_and_cell_changes_future(batch):
    p=make_parts('legacy_lstm','small',17)
    s=p.initializer(batch.history[:,:24]); h,c=unpack_lstm_state(s,16)
    expected_states=[]; actual=s
    for u in batch.forecast_controls.unbind(1):
        _,(h,c)=p.process.net(torch.cat((h[1],u),1)[:,None],(h,c))
        actual=p.process(actual,u)
        assert torch.equal(actual,pack_lstm_state(h,c))
    changed=s.clone(); changed[:,32:]+=1
    assert not torch.equal(p.process(changed,batch.forecast_controls[:,0]),p.process(s,batch.forecast_controls[:,0]))

def test_model_creation_does_not_change_shuffle_rng():
    g=torch.Generator().manual_seed(200017)
    before=torch.random.get_rng_state().clone()
    make_parts('legacy_lstm','small',17)
    assert torch.equal(before,torch.random.get_rng_state())
    assert torch.equal(torch.randperm(20,generator=g),torch.randperm(20,generator=torch.Generator().manual_seed(200017)))
