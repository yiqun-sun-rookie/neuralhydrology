import copy
import json
from pathlib import Path
import pytest
from src.scheduler import validate_registry,ready,seal_group,resolve_aliases,estimate_resources
from src.contracts import CASES,METHODS

ROOT=Path(__file__).resolve().parents[1]
def load():
    return (json.loads((ROOT/'configs/registry-v3.json').read_text(encoding='utf-8')),
            json.loads((ROOT/'configs/protocol-v3.json').read_text(encoding='utf-8')))

def results_for(members,epochs=200):
    return {m:{'status':'success','budget_final':True,'epochs':epochs,'checkpoint_sha256':'a'*64,
               'best_epoch':1,'validation_mae':[1.]*epochs} for m in members}

def test_full_registry_and_corrupt_cycle():
    r,p=load(); validate_registry(r,p)
    r['runs'][0]['dependency_ids'].append(r['runs'][0]['exp_id'])
    with pytest.raises(ValueError): validate_registry(r,p)

def test_missing_four_foundations_and_partial_or_stale_seals():
    r,p=load(); child=next(x for x in r['runs'] if x['type']=='primary')
    own={child['parent_run_id']}; seals={}
    assert not ready(child,own,seals)
    for gate,members in child['dependency_members'].items():
        seals[gate]=seal_group(gate,results_for(members),200,expected_members=members)
    assert ready(child,own,seals)
    group=child['case']+'__final_foundation_group__seal'; members=child['dependency_members'][group]
    with pytest.raises(ValueError): seal_group(group,results_for(members[:1]),200,expected_members=members)
    improving=results_for(members); improving[members[0]]['validation_mae']=[2.]*190+[1.]*10
    improving[members[0]]['best_epoch']=191
    with pytest.raises(ValueError): seal_group(group,improving,200,expected_members=members)
    child['required_group_epochs']={group:400}
    assert not ready(child,own,seals)

def aliases_fixture(rate):
    r,p=load(); rates={(x['case'],x['method']):rate for x in r['runs'] if x['type']=='primary'}
    configs={}
    for row in r['runs']:
        if row['type'] not in ('primary','controlled'): continue
        cfg={k:'a'*64 for k in r['alias_policy']['must_match']}
        cfg['learning_rate']=.001 if row['type']=='controlled' else rates[(row['case'],row['method'])]
        cfg['budget_group']=row['budget_group']; cfg['seed']=row['seed']; cfg['method']=row['method']
        configs[row['exp_id']]=cfg
    return r,rates,configs

@pytest.mark.parametrize('rate,count',[(.001,160),(.0003,240)])
def test_alias_counts(rate,count):
    r,rates,cfg=aliases_fixture(rate); resolved=resolve_aliases(r,rates,cfg)
    assert len(resolved['physical_run_ids'])==count
    assert all(len(g['physical_members']) in (0,3,5,12,20,40) for g in resolved['gates'])

def test_alias_mixed_unit_reduces_exactly_five_and_changed_config_cannot_alias():
    r,rates,cfg=aliases_fixture(.0003)
    key=next(iter(rates)); rates[key]=.001
    for row in r['runs']:
        if row['type']=='primary' and (row['case'],row['method'])==key: cfg[row['exp_id']]['learning_rate']=.001
    assert len(resolve_aliases(r,rates,cfg)['physical_run_ids'])==235
    r,rates,cfg=aliases_fixture(.001)
    controlled=next(x for x in r['runs'] if x['type']=='controlled')
    for key in ('parent_hash','normalization_hash','loss','budget_policy_hash','whitening_hash'):
        changed=copy.deepcopy(cfg); changed[controlled['exp_id']][key]='different'
        assert len(resolve_aliases(r,rates,changed)['physical_run_ids'])==161

def test_complete_resource_categories_and_memory_limit():
    categories={}; specs={}
    for family,capacity,_,_ in CASES:
        for method in ('foundation',*METHODS):
            name=family+'__'+capacity+'/'+method
            categories[name]={'warmup_steps':5,'measurement_steps':30,'memory_fraction':.6,
                'seconds_per_step':1.,'validation_seconds_per_epoch':2.,'save_seconds_per_epoch':.1}
            specs[name]={'maximum_steps':100,'fits_max':8 if method=='foundation' else 13}
    q=estimate_resources(categories,specs,400,10.)
    assert q['cost_upper']==pytest.approx(240*400*152.1/3600*10)
    assert len(q['group_seconds_upper'])==16
    categories['legacy_lstm__small/filter_joint']['memory_fraction']=.81
    with pytest.raises(ValueError): estimate_resources(categories,specs,400,10.)
