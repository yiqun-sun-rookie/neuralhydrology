import json
from pathlib import Path
import subprocess
import sys
import numpy as np
import pytest
import torch
from src.contracts import CASES,Whitening,PredictionRows,TARGETS
from src.models import make_parts,parameters
from src.state_estimators import make_branches,configure_branch,hash_module
from src.differentiable_filter import make_noise
from src.training import branch_prediction,train_effective_batch,make_optimizer
from src.normalization import denormalize_targets_cm
from src.scoring import score_rows,paired_resamples
from src.scheduler import resolve_effective_config,digest_json

ROOT=Path(__file__).resolve().parents[1]

@pytest.mark.parametrize('family,capacity,w,d',CASES)
def test_complete_71_hours_four_methods_cm_scoring_and_optimizer(family,capacity,w,d,batch,stats,physical):
    foundation=make_parts(family,capacity,17)
    branches=make_branches(foundation,100017)
    wh=Whitening(torch.zeros(d,dtype=torch.float64),torch.ones(d,dtype=torch.float64))
    for method,p in branches.items():
        noise=make_noise(d) if method.startswith('filter') else None
        configure_branch(p,noise,method)
        before=[hash_module(m) for m in (p.initializer,p.process,p.readout)]
        initial_noise=None if noise is None else noise.raw_q.detach().clone()
        optimizer=make_optimizer(p,noise,.001)
        evidence=train_effective_batch(p,noise,wh,method,batch,stats,optimizer)
        after=[hash_module(m) for m in (p.initializer,p.process,p.readout)]
        assert before[0]==after[0]
        if method.endswith('fixed'): assert before==after
        else: assert before[1]!=after[1]
        if noise is not None: assert not torch.equal(initial_noise,noise.raw_q)
        with torch.no_grad(): prediction=branch_prediction(p,noise,wh,method,batch)
        prediction_cm=denormalize_targets_cm(prediction.double(),stats).numpy()
        truth_cm=batch.targets_m[:,24:].numpy()*100
        lead,station=np.indices((23,4))
        rows=PredictionRows(np.repeat(physical.issue_time,92),lead.ravel()+1,np.asarray(TARGETS)[station.ravel()],
            np.repeat(17,92),prediction_cm.ravel(),truth_cm.ravel())
        out=score_rows(rows,stats.high_threshold_m*100)
        assert out['overall_mae_cm']==pytest.approx(np.abs(prediction_cm-truth_cm).mean())
        assert len(out['lead_mae_cm'])==23 and np.isfinite(evidence['loss_cm'])

@pytest.mark.parametrize('script',['run_registered.py','measure_resources.py','evaluate_frozen.py','admit_data.py','seal_selection.py','resolve_group.py'])
def test_unapproved_entry_rejects_before_model_import_or_data_open(script):
    result=subprocess.run([sys.executable,'-B',str(ROOT/'scripts'/script)],cwd=ROOT,capture_output=True,text=True)
    assert result.returncode==2,result.stdout+result.stderr
    record=json.loads(result.stdout.strip())
    assert record['status']=='rejected' and not record['model_module_imported']
    assert 'authorization missing' in record['reason']

def test_time_blocks_do_not_change_with_seed_group_size():
    dates=np.datetime64('2023-01-01')+np.arange(365)*np.timedelta64(1,'D')
    a=np.full((5,365,1,1),2.); b=np.full((3,365,1,1),1.)
    independent=paired_resamples(a,b,dates,False,7,100,20261005)
    paired=paired_resamples(a,a*.5,dates,True,7,100,20261005)
    assert independent['time_sampling_sha256']==paired['time_sampling_sha256']

def test_effective_config_uses_shared_budget_policy_not_unknown_final_epochs():
    protocol=json.loads((ROOT/'configs/protocol-v3.json').read_text(encoding='utf-8'))
    registry=json.loads((ROOT/'configs/registry-v3.json').read_text(encoding='utf-8'))
    row=next(r for r in registry['runs'] if r['type']=='primary')
    identities={k:'a'*64 for k in ('parent_hash','initializer_hash','analysis_initialization_hash','training_data_hash',
        'normalization_hash','whitening_hash','tide_source_hash','code_hash','shuffle_hash')}
    config=resolve_effective_config(row,protocol,.001,identities)
    assert config['budget_policy_hash']==digest_json(protocol['training'])
    assert 'resolved_group_epochs' not in config
    identities['resolved_group_epochs']=200
    with pytest.raises(ValueError): resolve_effective_config(row,protocol,.001,identities)
