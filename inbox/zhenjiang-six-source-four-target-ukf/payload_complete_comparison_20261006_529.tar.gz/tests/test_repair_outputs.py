"""Numerical checkpoint reload and measured quotation boundary checks."""
import copy
import hashlib
import json
import numpy as np
import pytest
import torch
from repair_fixtures import save,command
from src.contracts import CASES,METHODS,Whitening
from src.execution import device_identity
from src.models import make_parts
from src.state_estimators import make_branches,configure_branch
from src.differentiable_filter import make_noise
from src.runtime import prediction_table,whitening_record
from src.scheduler import digest_json,quote_measured_resources
from src.training import snapshot_parts


def test_actual_checkpoint_reload_and_all_four_diagnostics(tmp_path,batch,stats,physical):
    foundation=make_parts('explicit_gru','small',17)
    wh=Whitening(torch.zeros(32,dtype=torch.float64),torch.ones(32,dtype=torch.float64)); wh_record=whitening_record(wh)
    effective={'device':'cpu','device_identity':device_identity('cpu')}
    config={'effective_config':effective}
    run={'exp_id':'synthetic_foundation','case':'explicit_gru__small','seed':17,'method':'foundation'}
    path=tmp_path/'foundation.pt'; torch.save(snapshot_parts(foundation),path)
    checkpoint={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    origin=np.array([physical.issue_time]); frames={}
    for kind in ('foundation_endpoint','midpoint_no_target_observations','initial_noise_filter'):
        frames[kind]=prediction_table(run,config,checkpoint,[batch],origin,stats,
                                      diagnostic_kind=kind,foundation_whitening=wh_record)
        assert len(frames[kind])==92 and np.isfinite(frames[kind].prediction_cm).all()
        assert set(frames[kind].lead_hour)==set(range(1,24))
    original=prediction_table(run,config,checkpoint,[batch],origin,stats)
    assert np.array_equal(original.prediction_cm,frames['foundation_endpoint'].prediction_cm)
    parts=make_branches(foundation,100017)['filter_joint']; noise=make_noise(32); configure_branch(parts,noise,'filter_joint')
    run={**run,'exp_id':'synthetic_filter','method':'filter_joint'}
    path=tmp_path/'filter.pt'; torch.save(snapshot_parts(parts,noise),path)
    checkpoint={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    config={'effective_config':{**effective,'whitening':wh_record,'whitening_hash':digest_json(wh_record)}}
    off=prediction_table(run,config,checkpoint,[batch],origin,stats,False)
    on=prediction_table(run,config,checkpoint,[batch],origin,stats,True)
    assert len(off)==92 and np.isfinite(off.prediction_cm).all()
    assert not np.array_equal(off.prediction_cm,on.prediction_cm)
    with pytest.raises(ValueError): prediction_table(run,config,{**checkpoint,'sha256':'b'*64},[batch],origin,stats)


def quotation():
    categories={}; specs={}
    for family,capacity,_,_ in CASES:
        for method in ('foundation',*METHODS):
            name=family+'__'+capacity+'/'+method
            categories[name]={'warmup_steps':5,'measurement_steps':30,'memory_fraction':0.,'seconds_per_step':1.,
                'validation_seconds_per_epoch':2.,'save_seconds_per_epoch':.1,'device_identity':device_identity('cpu'),
                'validation_scope':'complete_selection_calendar','validation_windows':42,
                'save_scope':'actual_disk_checkpoint','disk_save_bytes':1000}
            specs[name]={'maximum_steps':100,'validation_windows':42,'fits_max':8 if method=='foundation' else 13}
    document={'protocol_sha256':'a'*64,'scope':'synthetic measured-value fixture','measurements':categories}
    overheads={k:1. for k in ('data_preparation','historical_reference_conversion','prediction_outputs','bootstrap_50000','storage')}
    return document,specs,overheads


def test_measured_quote_cli_binds_device_full_calendar_disk_and_all_costs(tmp_path,monkeypatch):
    doc,steps,overheads=quotation()
    command(monkeypatch,'measure_resources',measurements=save(tmp_path/'measurements.json',doc),
        steps=save(tmp_path/'steps.json',steps),overheads=save(tmp_path/'overheads.json',overheads),price_per_hour=10,
        output=tmp_path/'quote.json')
    result=json.loads((tmp_path/'quote.json').read_text(encoding='utf-8'))
    assert result['status']=='sealed_success' and len(result['categories'])==20 and len(result['group_seconds_upper'])==16
    assert result['device_identity']==device_identity('cpu')
    assert result['cost_upper']==pytest.approx(240*400*152.1/3600*10+5)
    for field,value in (('validation_scope','16_windows_only'),('save_scope','memory_serialization'),
                        ('disk_save_bytes',0),('device_identity',{'device':'wrong'})):
        broken=copy.deepcopy(doc); broken['measurements'][next(iter(broken['measurements']))][field]=value
        with pytest.raises((ValueError,KeyError)): quote_measured_resources(broken,steps,10,overheads)
    with pytest.raises(ValueError): quote_measured_resources(doc,steps,10,{})
