"""Operational flow fixtures only; no real data, supercomputer or paid job is used."""
import copy
from dataclasses import asdict
import hashlib
import importlib
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import pytest
import torch
from repair_fixtures import ROOT,save,make_sources
from src.scheduler import code_identity,digest_json,seal_group
from src.execution import device_identity
from src.models import make_parts,parameters
from src.runtime import load_stage,fit_stage_stats,stats_record
from src.training import FitSession

def test_resumption_keeps_optimizer_best_weights_and_validation_history(tmp_path,batch,stats):
    config={'effective_config':{'scheduler_continuation':True,'training_contract':{'initial_micro_batch':2}}}
    times=np.array([np.datetime64('2020-06-01T00')])
    a=FitSession(make_parts('explicit_gru','small',17),None,None,'foundation',stats,17,.001,tmp_path/'a',config)
    b=FitSession(make_parts('explicit_gru','small',17),None,None,'foundation',stats,17,.001,tmp_path/'b',config)
    a.epoch([batch],times,[batch],1); b.epoch([batch],times,[batch],1)
    resumed=FitSession(make_parts('explicit_gru','small',17),None,None,'foundation',stats,17,.001,tmp_path/'b',config)
    # Epoch 13 uses the same time-of-day phase; this is a two-step continuation witness.
    a.epoch([batch],times,[batch],13); resumed.epoch([batch],times,[batch],13)
    assert a.values==resumed.values and a.shuffle_hashes==resumed.shuffle_hashes
    assert all(torch.equal(x,y) for x,y in zip(parameters(a.parts),parameters(resumed.parts)))
    assert a.optimizer.state_dict()['param_groups']==resumed.optimizer.state_dict()['param_groups']
    changed=copy.deepcopy(config); changed['effective_config']['training_contract']['initial_micro_batch']=1
    with pytest.raises(ValueError,match='configuration differs'):
        FitSession(make_parts('explicit_gru','small',17),None,None,'foundation',stats,17,.001,tmp_path/'b',changed)

def test_case_dependencies_learning_rates_aliases_and_all_four_group_seals(tmp_path,monkeypatch):
    module=importlib.import_module('train_supercomputer_case')
    for name in ('configs','records','runs','prepared'): (tmp_path/name).mkdir()
    protocol=json.loads((ROOT/'configs/protocol-v3.json').read_text(encoding='utf-8'))
    protocol_path=save(tmp_path/'configs/protocol-v3.json',protocol)
    sha=hashlib.sha256(protocol_path.read_bytes()).hexdigest()
    registry=json.loads((ROOT/'configs/registry-v3.json').read_text(encoding='utf-8')); registry['protocol_sha256']=sha
    save(tmp_path/'configs/registry-v3.json',registry)
    save(tmp_path/'records/authorization.json',{'protocol_sha256':sha,'authority':{'formal_training':True},'code_hash':code_identity()})
    save(tmp_path/'records/data_preparation_complete.json',{'status':'admitted','code_hash':code_identity()})
    for split in ('tuning','final'):
        directory=tmp_path/'prepared'/split; directory.mkdir()
        manifest=make_sources(directory/'files',tuning=split=='tuning')
        manifest['files']=[f for f in manifest['files'] if f['years'][0]<= (2021 if split=='tuning' else 2022)]
        manifest['evaluation_year_reads']=False; manifest['tide_source_hash']=digest_json(split)
        save(directory/'manifest.json',manifest)
    monkeypatch.setattr(module,'ROOT',tmp_path)
    monkeypatch.setattr(module,'device_identity',lambda device:device_identity('cpu'))
    monkeypatch.setattr(sys,'argv',['train_supercomputer_case','--case','explicit_gru__small'])
    calls=[]
    def replay_group(group,registry,protocol,configs,manifest,output_root,seals):
        # Fabricated 200-epoch outcomes exercise orchestration without scientific claims.
        calls.append((group,len(configs))); results={}
        for key,config in configs.items():
            run=config['registration']; effective=config['effective_config']
            assert effective['group_wall_seconds_limit'] is None
            directory=output_root/key; directory.mkdir()
            whitening={'mean':[0.]*32,'scale':[1.]*32}; save(directory/'whitening.json',whitening)
            results[key]={'status':'success','budget_final':True,'epochs':200,'best_epoch':1,
                'validation_mae':[1. if effective['learning_rate']==.001 else 2.]*200,
                'checkpoint_sha256':digest_json(key),'initializer_hash':digest_json('synthetic_initializer'),
                'normalization_hash':effective['normalization_hash'],'whitening_hash':digest_json(whitening),
                'checkpoint_path':str(directory/'best.pt'),'case':run['case'],'method':run['method'],
                'seed':run['seed'],'type':run['type'],'learning_rate':effective['learning_rate']}
        seal=seal_group(group+'__seal',results,200,expected_members=list(results))
        return {'members':results,'seal':asdict(seal)}
    monkeypatch.setattr(module,'execute_group',replay_group)
    module.main()
    assert [n for _,n in calls]==[3,12,5,20]
    report=json.loads((tmp_path/'records/explicit_gru__small/training_complete.json').read_text())
    assert report['completed_fits']==40 and set(report['rates'].values())=={.001}
    assert report['evaluation_values_read'] is False
    assert len(report['seals'])==8

def test_fixed_tide_is_identical_for_overlapping_and_separate_requests(monkeypatch):
    module=importlib.import_module('prepare_training_data')
    monkeypatch.syspath_prepend(str(ROOT/'vendor/pytides'))
    from tide import Tide
    import constituent
    model=Tide(constituents=[constituent._M2,constituent._Z0],amplitudes=[.3,2.],phases=[10.,0.])
    times=np.datetime64('2017-12-20T00')+np.arange(1000)*np.timedelta64(1,'h')
    whole=module.fixed_tide(model,times)
    assert np.array_equal(whole[300:800],module.fixed_tide(model,times[300:800]))
    assert np.isfinite(whole).all()

@pytest.mark.parametrize('timezone_aware',[False,True])
def test_training_csv_checks_all_hours_clock_and_missing_flags(timezone_aware):
    module=importlib.import_module('prepare_training_data')
    times=pd.date_range('2017-01-01','2022-12-31T23',freq='h')
    utc=times.tz_localize('Asia/Shanghai').tz_convert('UTC')
    frame=pd.DataFrame({'TIME':times.tz_localize('Asia/Shanghai') if timezone_aware else times,'STAGE':np.ones(len(times)),
        'time_beijing':times.tz_localize('Asia/Shanghai'),'time_utc':utc,'is_missing_for_model':False})
    returned,values=module.validate_csv(frame.to_csv(index=False).encode(),'realtime_stage')
    assert len(returned)==52584 and np.isfinite(values).all()
    frame.loc[0,'is_missing_for_model']=True
    with pytest.raises(ValueError,match='flag and values disagree'):
        module.validate_csv(frame.to_csv(index=False).encode(),'realtime_stage')
    frame=frame.iloc[1:]
    with pytest.raises(ValueError,match='calendar changed'):
        module.validate_csv(frame.to_csv(index=False).encode(),'realtime_stage')
