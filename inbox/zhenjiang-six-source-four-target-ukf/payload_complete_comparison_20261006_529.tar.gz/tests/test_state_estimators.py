import pytest
import torch
from src.contracts import CASES
from src.models import make_parts, parameters, count_parameters, rollout
from src.state_estimators import make_branches, hash_module, configure_branch, initialize_state, encoder_analysis
from src.differentiable_filter import make_noise

@pytest.mark.parametrize('family,capacity,w,d',CASES)
def test_fresh_analysis_shared_future_and_deployment_counts(family,capacity,w,d):
    f=make_parts(family,capacity,17); branches=make_branches(f,100017)
    assert hash_module(branches['encoder_fixed'].encoder)==hash_module(branches['encoder_joint'].encoder)
    assert hash_module(branches['encoder_fixed'].encoder)!=hash_module(f.encoder)
    for method,p in branches.items():
        n=None if method.startswith('encoder') else make_noise(d)
        configure_branch(p,n,method)
        assert hash_module(p.initializer)==hash_module(f.initializer)
        assert hash_module(p.process)==hash_module(f.process)
        assert hash_module(p.readout)==hash_module(f.readout)
        assert all(not q.requires_grad for q in p.initializer.parameters())
        expected=count_parameters(f)['total']+(count_parameters(f)['encoder'] if n is None else d+5)
        assert sum(q.numel() for q in parameters(p,n))==expected

@pytest.mark.parametrize('method',['encoder_fixed','encoder_joint'])
def test_optimization_freezes_only_weights_and_keeps_input_gradient(method,batch):
    f=make_parts('legacy_lstm','small',17); p=make_branches(f,100017)[method]
    configure_branch(p,None,method)
    original=[hash_module(m) for m in (p.initializer,p.process,p.readout)]
    initial=initialize_state(p,batch.history[:,:24])
    state=encoder_analysis(p,initial,batch.history[:,24:]); state.retain_grad()
    optimizer=torch.optim.Adam(list(parameters(p,trainable_only=True)),lr=.001)
    rollout(p.process,p.readout,state,batch.forecast_controls).square().sum().backward()
    assert torch.isfinite(state.grad).all() and state.grad.abs().sum()>0
    optimizer.step()
    final=[hash_module(m) for m in (p.initializer,p.process,p.readout)]
    assert final[0]==original[0]
    if method.endswith('fixed'): assert final==original
    else: assert final[1]!=original[1] and final[2]!=original[2]
