import json
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
from src.contracts import TARGETS
from src.evaluation import complete_scientific_comparisons,replacement_report,align_reference
from src.training import FitSession
from src.models import make_parts

ROOT=Path(__file__).resolve().parents[1]

def frame(year,seeds,error):
    dates=np.datetime64(str(year)+'-01-01')+np.arange(0,365,10)*np.timedelta64(1,'D')
    shape=(len(seeds),len(dates),23,4); a,b,c,d=np.indices(shape)
    truth=np.broadcast_to((200+np.sin(np.arange(len(dates)))*20)[None,:,None,None],shape)
    return pd.DataFrame({'issue_time':dates[b.ravel()],'seed':np.asarray(seeds)[a.ravel()],
        'lead_hour':c.ravel()+1,'station':np.asarray(TARGETS)[d.ravel()],
        'prediction_cm':truth.ravel()+error,'observation_cm':truth.ravel(),'eligible':True,'reason':''})

def test_all_64_contrasts_and_both_years_27_constraint_workflow():
    p=json.loads((ROOT/'configs/protocol-v3.json').read_text(encoding='utf-8')); p['statistics']['resamples']=20
    frames={}; candidates={}; joint={}; specialists={}
    for year in (2023,2024):
        sources={m:frame(year,p['seeds'],1+i) for i,m in enumerate(p['method_order'])}
        for c in p['cases']:
            for track in ('primary','controlled'):
                for method in p['method_order']:
                    frames[(year,track,c['family']+'__'+c['capacity'],method)]=sources[method]
        candidates[year]=sources['encoder_fixed']; joint[year]=frame(year,[17,29,43],2)
        specialists[year]=frame(year,[17,29,43],3).query("station=='zhenjiang'")
    result=complete_scientific_comparisons(frames,p,np.full(4,200.))
    assert len(result)==64 and all(len(r['block_sensitivity'])==3 for r in result)
    policy={'status':'frozen_approved','relative_mae_margin':.05,'miss_and_false_rate_margin':.01}
    r=replacement_report(candidates,joint,specialists,np.full(4,200.),policy,p)
    assert set(r['constraints'])=={2023,2024}
    assert all(len(rows)==27 for byblock in r['constraints'].values() for rows in byblock.values())
    assert all(x['admitted'] for x in r['retention'].values())
    assert r['overall_decision'].startswith('通过回顾验收')
    altered=joint[2024].copy(); altered['observation_cm']+=.001
    with pytest.raises(ValueError): align_reference(candidates[2024],altered)

def test_approved_time_ceiling_stops_before_optimizer_step(tmp_path,batch,stats):
    parts=make_parts('explicit_gru','small',17)
    session=FitSession(parts,None,None,'foundation',stats,17,.001,tmp_path/'synthetic',{})
    session.deadline=0.
    with pytest.raises(TimeoutError):
        session.epoch([batch],np.array(['2020-06-01T00'],dtype='datetime64[h]'),[batch],1)
    assert len(session.optimizer.state)==0 and not session.values
