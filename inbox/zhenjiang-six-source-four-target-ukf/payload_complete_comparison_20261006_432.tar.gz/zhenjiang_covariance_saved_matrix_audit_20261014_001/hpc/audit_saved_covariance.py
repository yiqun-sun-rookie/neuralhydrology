"""Scheduled audit of authenticated saved covariance operands; zero model steps.

python -B hpc/audit_saved_covariance.py
Checks the exact stored float64 matrix at two diagnostic precisions, the
original permitted jitter, and reconstruction from the saved positive-weight
operands. Higher precision is diagnostic only and cannot enter formal training.
"""
import datetime
import hashlib
import json
from pathlib import Path

import mpmath as mp
import torch

ROOT = Path(__file__).resolve().parents[1]


def now():
    return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


def save(path, value):
    with path.open('x', encoding='utf-8') as f:
        json.dump(value, f, sort_keys=True, indent=2, allow_nan=False)
        f.write('\n')


def exact_float(value):
    numerator, denominator = float(value).as_integer_ratio()
    return mp.mpf(numerator) / denominator


def matrix(tensor):
    rows = tensor.detach().cpu().tolist()
    return mp.matrix([[exact_float(x) for x in row] for row in rows])


def cholesky_certificate(a):
    n = a.rows
    lower = mp.matrix(n)
    least = None
    for row in range(n):
        for column in range(row + 1):
            pivot = a[row, column] - mp.fsum(lower[row, k] * lower[column, k] for k in range(column))
            if row == column:
                least = pivot if least is None else min(least, pivot)
                if pivot <= 0:
                    return {'positive_definite': False, 'first_nonpositive_pivot_index_1based': row + 1,
                            'nonpositive_pivot': mp.nstr(pivot, 55), 'precision_decimal_digits': mp.mp.dps}
                lower[row, column] = mp.sqrt(pivot)
            else:
                lower[row, column] = pivot / lower[column, column]
    return {'positive_definite': True, 'minimum_cholesky_pivot': mp.nstr(least, 55),
            'precision_decimal_digits': mp.mp.dps}


def main():
    spec = json.loads((ROOT / 'audit_spec.json').read_text())
    assert str(ROOT) == spec['audit_root'] and spec['model_steps_allowed'] == 0
    evidence = ROOT / 'evidence'
    evidence.mkdir(exist_ok=False)
    pinned = dict(spec['pinned_files'])
    assert all(sha(path) == expected for path, expected in pinned.items())
    props = torch.cuda.get_device_properties(0)
    device = {'device': 'cuda:0', 'name': props.name, 'total_memory_bytes': props.total_memory}
    assert device == spec['expected_device_identity']
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    operands = torch.load(spec['operands_path'], map_location='cpu', weights_only=True)
    p = operands['original_input_covariance']
    assert p.dtype == torch.float64 and p.shape == (2, 128, 128) and bool(torch.isfinite(p).all())
    assert operands['original_jitters'] == spec['permitted_jitters']
    assert operands['context'] == spec['failure_context']
    assert all(bool(torch.isfinite(x).all()) for x in operands['moments'].values())
    q = operands['noise_variances'][0]
    wc = operands['moments']['wc']
    assert q.dtype == wc.dtype == torch.float64 and bool((q > 0).all()) and bool((wc >= 0).all())
    result = {'status': 'saved_covariance_matrix_audit_started', 'checked_at_beijing': now(),
              'device_identity': device, 'formal_training_epochs_added': 0, 'model_steps': 0,
              'optimizer_updates': 0, 'training_inputs_read': False, 'evaluation_values_read': False,
              'scientific_rules_changed': False, 'new_jitter_allowed': False,
              'failure_context': operands['context'], 'torch_version': str(torch.__version__),
              'mpmath_version': str(mp.__version__), 'minimum_original_q': float(q.min()),
              'maximum_original_q': float(q.max()), 'matrix_certificates': []}
    print(json.dumps({'status': result['status'], 'checked_at_beijing': now()}), flush=True)
    gpu = p.cuda()
    eye = torch.eye(128, dtype=torch.float64, device=gpu.device)
    maximum_jitter = max(spec['permitted_jitters'])
    for jitter in (0., maximum_jitter):
        stored = (gpu + jitter * eye).cpu()
        record = {'jitter': jitter, 'gpu_float64_cholesky_info': torch.linalg.cholesky_ex(gpu + jitter * eye)[1].cpu().tolist(),
                  'diagonal_jitter_materialized_in_float64': (stored.diagonal(dim1=-2, dim2=-1) - p.diagonal(dim1=-2, dim2=-1)).tolist(),
                  'stored_matrix_high_precision_certificates': []}
        for digits in (80, 120):
            with mp.workdps(digits):
                record['stored_matrix_high_precision_certificates'].append({
                    'digits': digits, 'members': [cholesky_certificate(matrix(item)) for item in stored]})
        result['matrix_certificates'].append(record)
    # Diagnose float64 diagonal scaling on the unchanged stored matrix. Never
    # use a successful factor as proof that the exact matrix is positive definite.
    diagonal_scale = gpu.diagonal(dim1=-2, dim2=-1).sqrt()
    scaled = gpu / diagonal_scale[:, :, None] / diagonal_scale[:, None, :]
    _, info = torch.linalg.cholesky_ex((scaled + scaled.transpose(-1, -2)) * .5)
    result['float64_correlation_scaling_cholesky_info'] = info.cpu().tolist()
    result['correlation_scaling_used_in_formal_training'] = False
    # Only the failing saved microbatch member is reconstructed; no model or
    # data loader is called. Original float64 subtraction operands and exact
    # positive weights/Q are retained for this arithmetic diagnosis.
    member = 1
    differences = operands['moments']['points'][member] - operands['moments']['mean'][member][None]
    with mp.workdps(120):
        d = matrix(differences)
        weights = [exact_float(x) for x in wc.tolist()]
        noise = [exact_float(x) for x in q.tolist()]
        reconstructed = mp.matrix(128)
        for i in range(128):
            for j in range(i + 1):
                value = mp.fsum(weights[k] * d[k, i] * d[k, j] for k in range(d.rows))
                if i == j:
                    value += noise[i]
                reconstructed[i, j] = reconstructed[j, i] = value
        result['positive_operand_reconstruction_certificate'] = cholesky_certificate(reconstructed)
        result['positive_operand_reconstruction_member_index_0based'] = member
        result['reconstruction_minimum_q_exact'] = mp.nstr(min(noise), 55)
        save(evidence / 'reconstructed_covariance_decimal_120digits.json', {
            'member_index_0based': member, 'precision_decimal_digits': 120,
            'covariance': [[mp.nstr(reconstructed[i, j], 125) for j in range(128)] for i in range(128)],
            'formal_training_used': False})
    unchanged = {path: sha(path) == expected for path, expected in pinned.items()}
    assert all(unchanged.values()), 'source or original diagnostic artifacts changed'
    result.update(status='saved_covariance_matrix_audit_complete', finished_at_beijing=now(),
                  source_and_original_artifacts_unchanged=True, unchanged_file_checks=unchanged,
                  automatic_technical_repair_admitted=False)
    save(evidence / 'saved_matrix_audit_result.json', result)
    print(json.dumps({'status': result['status'], 'finished_at_beijing': result['finished_at_beijing'],
                      'model_steps': 0, 'source_and_original_artifacts_unchanged': True}), flush=True)


if __name__ == '__main__':
    main()
