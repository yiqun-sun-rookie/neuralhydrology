"""Submit this distinct saved-matrix arithmetic audit once; never retry ambiguously."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


def save(name, value):
    with (ROOT / 'records' / name).open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')


def query(args):
    p = subprocess.run(args, capture_output=True, text=True, timeout=30)
    assert p.returncode == 0, p.stderr
    return {'command': args, 'returncode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}


def main():
    # Check installed dependencies before reserving the exclusive scheduler call.
    import mpmath
    import torch
    spec = json.loads((ROOT / 'audit_spec.json').read_text())
    assert str(ROOT) == spec['audit_root'] and spec['model_steps_allowed'] == 0
    assert not (ROOT / 'records/submission_attempt.json').exists() and not (ROOT / 'evidence').exists()
    assert all(sha(path) == expected for path, expected in spec['pinned_files'].items())
    assert sha(spec['verified_template_path']) == spec['verified_template_sha256']
    source = Path(spec['source_root'])
    jobs = json.loads((source / 'records/scheduler_jobs.json').read_text())
    assert str(jobs[spec['source_case']]) == spec['source_failed_job']
    queue = query(['squeue', '-h', '-u', 'sunyiq', '-o', '%i|%j|%T|%Z'])
    rows = [line.split('|') for line in queue['stdout'].splitlines() if line.strip()]
    assert not any(row[0] in (spec['source_failed_job'], spec['original_diagnostic_job']) or
                   row[1].startswith(('zj_gru_cov_mat_aud_', 'zj_gru_gradient_recovery')) for row in rows)
    accounting = query(['sacct', '-n', '-X', '-j', spec['source_failed_job'] + ',' + spec['original_diagnostic_job'],
        '--format=JobID,State,ExitCode,Start,End,NodeList', '-P'])
    entries = {line.split('|')[0]: line.split('|') for line in accounting['stdout'].splitlines() if line.strip()}
    assert entries[spec['source_failed_job']][1:3] == ['FAILED', '1:0']
    assert entries[spec['original_diagnostic_job']][1:3] == ['COMPLETED', '0:0']
    manifest = json.loads((ROOT / 'package_manifest.json').read_text())
    assert all(sha(ROOT / name) == item['sha256'] for name, item in manifest['files'].items())
    script = ROOT / 'hpc/saved_matrix_audit.slurm'
    body = script.read_text().splitlines()
    assert '#SBATCH -p hgpu2p' in body and '#SBATCH --gres=gpu:1' in body and '#SBATCH --cpus-per-task=4' in body
    assert '#SBATCH --exclude=ngu002,ngu011' in body and body.index('conda activate nh_final') < body.index('set -u')
    assert body[-1] == 'python -B -u hpc/audit_saved_covariance.py'
    save('submission_attempt.json', {'status': 'reserved_no_retry', 'checked_at_beijing': datetime.datetime.now(
        datetime.timezone(datetime.timedelta(hours=8))).isoformat(), 'queue': queue, 'accounting': accounting,
        'script_sha256': sha(script), 'spec_sha256': sha(ROOT / 'audit_spec.json'),
        'package_manifest_sha256': sha(ROOT / 'package_manifest.json'), 'model_steps_allowed': 0})
    try:
        p = subprocess.run(['/usr/local/globle/softs/slurm/19.05.4.1/bin/xbatch', str(script)],
                           capture_output=True, text=True, timeout=60)
    except Exception as error:
        save('submission_response.json', {'status': 'uncertain_read_only_reconciliation_required', 'error': str(error)})
        raise
    save('submission_response.json', {'returncode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr})
    match = re.fullmatch(r'Submitted batch job ([0-9]+)\s*', p.stdout)
    assert p.returncode == 0 and match, 'submission uncertain; no retry'
    job = match.group(1)
    save('scheduler_jobs.json', {'saved_matrix_audit': job})
    print(json.dumps({'status': 'saved_covariance_matrix_audit_submitted', 'audit_root': str(ROOT),
          'job_id': job, 'script_sha256': sha(script), 'spec_sha256': sha(ROOT / 'audit_spec.json'),
          'package_manifest_sha256': sha(ROOT / 'package_manifest.json'), 'model_steps_allowed': 0,
          'formal_training_restarted': False, 'original_diagnostic_not_resubmitted': True}), flush=True)


if __name__ == '__main__':
    main()
