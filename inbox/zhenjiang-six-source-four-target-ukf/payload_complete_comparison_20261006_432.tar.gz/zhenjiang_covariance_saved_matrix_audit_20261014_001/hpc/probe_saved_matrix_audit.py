"""Read only this saved-matrix audit's exclusive submission, accounting and result."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def doc(path):
    if not path.is_file():
        return None
    raw = path.read_bytes()
    return {'value': json.loads(raw), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def query(args):
    p = subprocess.run(args, capture_output=True, text=True, timeout=30)
    assert p.returncode == 0, p.stderr
    return {'command': args, 'returncode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}


def main():
    jobs = doc(ROOT / 'records/scheduler_jobs.json')
    job = jobs['value']['saved_matrix_audit'] if jobs else None
    queries = [query(['squeue', '-h', '-u', 'sunyiq', '-o', '%i|%j|%T|%N|%Z|%S|%e|%M|%l|%R'])]
    if job:
        queries.append(query(['sacct', '-n', '-X', '-j', job, '--format=JobID,State,ExitCode,Start,End,NodeList,Elapsed,Timelimit', '-P']))
    result = doc(ROOT / 'evidence/saved_matrix_audit_result.json')
    print(json.dumps({'status': 'saved_covariance_matrix_audit_status', 'checked_at_beijing': datetime.datetime.now(
        datetime.timezone(datetime.timedelta(hours=8))).isoformat(), 'audit_root': str(ROOT), 'job_id': job,
        'queries': queries, 'submission_attempt': doc(ROOT / 'records/submission_attempt.json'),
        'submission_response': doc(ROOT / 'records/submission_response.json'), 'scheduler_jobs': jobs,
        'audit_result': result, 'model_steps': 0, 'formal_training_epochs_added': 0,
        'evaluation_values_read': False, 'scheduler_mutated': False}), flush=True)


if __name__ == '__main__':
    main()
