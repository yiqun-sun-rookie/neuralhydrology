"""HPC-only CPU admission on the authenticated failed004 stored operands.

No raw training data or checkpoint loads, optimizer steps, or GPU submissions.
Writes one exclusive JSON result in the new isolated candidate directory.
"""
import datetime
import hashlib
import json
from pathlib import Path
import sys

import mpmath as mp
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src import differentiable_filter as dense
from src import square_root_filter as sqrt


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def matrix(value):
    return mp.matrix([[mp.mpf(float(x)) for x in row] for row in value.tolist()])


def relative(actual, expected):
    return float((actual - expected).abs().max() / expected.abs().max().clamp_min(1e-30))


def main():
    assert not torch.cuda.is_available(), 'CPU-only stored operand admission'
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    spec = json.loads((ROOT / 'repair_spec.json').read_bytes())
    old = Path(spec['stored_root'])
    pins = spec['stored_input_sha256']
    assert all(sha(old / name) == digest for name, digest in pins.items())
    source = Path(spec['source_root'])
    assert all(sha(source / name) == digest for name, digest in spec['source_code_file_hashes'].items())
    raw = torch.load(old / 'evidence/covariance_failure_operands.pt', map_location='cpu', weights_only=True)
    frames = {frame['function']: frame for frame in raw['original_failure_traceback_frames']}
    values = frames['linear_update']['tensors']
    index = frames['repair_rejected_members']['scalars']['i']
    prior, complement, gain = [values[name][index:index + 1].clone() for name in ('covariance', 'complement', 'gain')]
    r = values['r_diagonal'][index:index + 1].clone()
    assert list(dense.JITTERS) == raw['original_jitters'] == spec['original_jitters']
    ledger = dense.StabilityLedger()
    lower = dense.stable_cholesky(prior, ledger)
    factor = sqrt.joseph_factor(lower, complement, gain, r, ledger)
    assert bool(torch.isfinite(factor).all()) and bool((factor.diagonal(dim1=-2, dim2=-1) > 0).all())
    # Same bad dense result remains bad: the candidate retains its factor.
    rounded_product = factor @ factor.transpose(-1, -2)
    _, rounded_info = torch.linalg.cholesky_ex(rounded_product)
    references = []
    for digits in (80, 120):
        with mp.workdps(digits):
            a, k, p, rr, lf = [matrix(v) for v in (complement[0], gain[0], prior[0], torch.diag(r[0]), factor[0])]
            exact = a * p * a.T + k * rr * k.T
            represented = lf * lf.T
            scale = max(abs(x) for x in exact)
            error = max(abs(represented[i, j] - exact[i, j]) for i in range(p.rows) for j in range(p.cols)) / scale
            assert error < mp.mpf('1e-12'), str(error)
            references.append({'decimal_digits': digits, 'represented_covariance_relative_max_error': mp.nstr(error, 45),
                               'positive_lower_diagonal': True,
                               'minimum_factor_diagonal_squared': mp.nstr(min(lf[i, i]**2 for i in range(lf.rows)), 45)})
    # Actual ill-conditioned operands: derivative of tr(W B B.T) through QR
    # must agree with 2 W B. This checks the implemented factor gradient.
    columns = torch.cat((complement @ lower, gain * r.sqrt()[:, None, :]), dim=-1).detach().requires_grad_(True)
    positions = torch.arange(prior.shape[-1], dtype=torch.float64)
    w = torch.diag((positions + 1) / prior.shape[-1])[None]
    f = sqrt.factor_columns(columns)
    loss = (w * (f @ f.transpose(-1, -2))).sum()
    grad, = torch.autograd.grad(loss, columns)
    expected = 2 * w @ columns.detach()
    actual_gradient_error = relative(grad, expected)
    assert bool(torch.isfinite(grad).all()) and actual_gradient_error < 1e-7, actual_gradient_error
    # A single well-conditioned control verifies means, covariance and ALL
    # lower-factor/H/r/input derivatives against the original dense formula.
    generator = torch.Generator().manual_seed(20261017)
    batch, dimension, observations = 2, 8, 4
    means = torch.randn(batch, dimension, generator=generator, dtype=torch.float64).requires_grad_()
    l = (torch.eye(dimension, dtype=torch.float64)[None] + .01 * torch.tril(torch.randn(batch, dimension, dimension, generator=generator, dtype=torch.float64))).requires_grad_()
    h = (.1 * torch.randn(observations, dimension, generator=generator, dtype=torch.float64)).requires_grad_()
    noise = torch.full((observations,), .01, dtype=torch.float64, requires_grad=True)
    obs = torch.randn(batch, observations, generator=generator, dtype=torch.float64).requires_grad_()
    offset = torch.zeros(observations, dtype=torch.float64, requires_grad=True)
    mp_, lp = sqrt.update_factor(means, l, obs, h, offset, noise)
    md, pd = dense.linear_update(means, l @ l.transpose(-1, -2), obs, h, offset, noise)
    inputs = [means, l, h, noise, obs, offset]
    gs = torch.autograd.grad(mp_.square().sum() + lp.square().sum(), inputs, retain_graph=True)
    gd = torch.autograd.grad(md.square().sum() + pd.diagonal(dim1=-2, dim2=-1).sum(), inputs)
    control_gradient_errors = [relative(x, y) for x, y in zip(gs, gd)]
    assert torch.allclose(mp_, md, atol=1e-12, rtol=1e-12)
    assert torch.allclose(lp @ lp.transpose(-1, -2), pd, atol=1e-12, rtol=1e-12)
    assert max(control_gradient_errors) < 1e-9, control_gradient_errors
    # Direct factor->sigma points verifies no dense factorization is hidden.
    points, wm, wc = sqrt.points_from_factor(means.detach(), l.detach())
    recovered_mean, recovered_p = dense.unscented_moments(points, wm, wc)
    assert torch.allclose(recovered_mean, means.detach(), atol=1e-12, rtol=1e-12)
    assert torch.allclose(recovered_p, l.detach() @ l.detach().transpose(-1, -2), atol=1e-12, rtol=1e-12)
    assert all(sha(old / name) == digest for name, digest in pins.items())
    assert all(sha(source / name) == digest for name, digest in spec['source_code_file_hashes'].items())
    result = {'status': 'sqrt_stored_operands_cpu_admission_passed',
              'checked_at_utc_plus_08': datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
              'root': str(ROOT), 'source_job': '243692', 'source_complete_epochs': 46, 'source_adam_steps': 7060,
              'source_checkpoint_sha256': spec['source_checkpoint_sha256'], 'human_authority_sha256': sha(ROOT / 'human_authority.json'),
              'candidate_sha256': sha(ROOT / 'src/square_root_filter.py'), 'stored_input_sha256': pins,
              'raw_failed_member_index': index, 'reference_results': references,
              'actual_stored_factor_gradient_relative_error': actual_gradient_error,
              'control_all_input_gradient_relative_errors': control_gradient_errors,
              'dense_reconstructed_covariance_cholesky_info': rounded_info.tolist(),
              'candidate_factor_min_diagonal': float(factor.diagonal(dim1=-2, dim2=-1).min()),
              'original_jitters': list(dense.JITTERS), 'ledger_attempts': [x.tolist() for x in ledger.current_jitter],
              'source_bytes_unchanged': True, 'precision_applied_to_training': False,
              'evaluation_values_read': False, 'optimizer_updates': 0, 'gpu_submissions': 0, 'formal_epochs_added': 0,
              'full_filter_gpu_original39_production_admission_complete': False, 'formal_recovery_confirmed': False}
    path = ROOT / 'records/stored_operand_cpu_admission.json'
    with path.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, sort_keys=True, allow_nan=False)
        stream.write('\n')
    data = path.read_bytes()
    print(json.dumps({'status': 'sqrt_cpu_admission_complete_document', 'root': str(ROOT),
                      'bytes': len(data), 'sha256': sha(path), 'value': result}, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
