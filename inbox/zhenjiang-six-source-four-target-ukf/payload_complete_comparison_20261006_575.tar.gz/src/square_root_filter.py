"""Authorized factor covariance candidate; float64, original jitter and ledger.

This file is packaged as src/square_root_filter.py in a NEW isolated release.
It never reconstructs a dense posterior for subsequent sigma propagation.
"""
import torch
from .differentiable_filter import (
    FilterFailure, JITTERS, StabilityLedger, noise_variances, observation_affine,
)


def _valid_factor(lower):
    return bool(torch.isfinite(lower).all()) and bool((lower.diagonal(dim1=-2, dim2=-1) > 0).all())


def record_factor(lower, ledger=None):
    if lower.ndim != 3 or lower.dtype != torch.float64 or not _valid_factor(lower):
        raise FilterFailure('invalid square-root covariance', {'shape': list(lower.shape)})
    if ledger is not None:
        ledger.record(torch.zeros(len(lower), dtype=lower.dtype))
    return lower


def _qr_lower(columns):
    # B B.T = R.T R, with positive diagonal giving the Cholesky orientation.
    _, upper = torch.linalg.qr(columns.transpose(-1, -2), mode='reduced')
    signs = torch.where(upper.diagonal(dim1=-2, dim2=-1) < 0, -1., 1.)
    return (upper * signs[..., :, None]).transpose(-1, -2)


def factor_columns(columns, ledger=None):
    if columns.ndim != 3 or columns.dtype != torch.float64 or not bool(torch.isfinite(columns).all()):
        raise FilterFailure('invalid covariance factor operands', {'shape': list(columns.shape)})
    lower = _qr_lower(columns)
    if _valid_factor(lower):
        return record_factor(lower, ledger)
    # Only the original physical diagonal jitter values are permitted. Each
    # append represents B B.T + jitter I; no eigenvalue clipping or new floor.
    factors, jitters = [], []
    dimension = columns.shape[-2]
    eye = torch.eye(dimension, dtype=columns.dtype, device=columns.device)
    for member in columns:
        for jitter in JITTERS:
            augmented = member if jitter == 0 else torch.cat((member, eye * jitter**.5), dim=-1)
            trial = _qr_lower(augmented[None])[0]
            if _valid_factor(trial):
                factors.append(trial)
                jitters.append(jitter)
                break
        else:
            raise FilterFailure('square-root covariance invalid after permitted jitter',
                                {'attempted_jitters': list(JITTERS)})
    if ledger is not None:
        ledger.record(torch.tensor(jitters, dtype=columns.dtype))
    return torch.stack(factors)


def joseph_factor(lower, complement, gain, r_diagonal, ledger=None):
    if not bool((r_diagonal > 0).all()):
        raise FilterFailure('invalid observation noise', {})
    columns = torch.cat((complement @ lower, gain * r_diagonal.sqrt()[..., None, :]), dim=-1)
    return factor_columns(columns, ledger)


def points_from_factor(mean, lower, ledger=None):
    record_factor(lower, ledger)
    dimension = mean.shape[-1]
    delta = lower.transpose(-1, -2) * dimension**.5
    points = torch.cat((mean[:, None], mean[:, None] + delta, mean[:, None] - delta), dim=1)
    wm = mean.new_full((2 * dimension + 1,), 1 / (2 * dimension))
    wm[0] = 0
    wc = wm.clone()
    wc[0] = 2
    return points, wm, wc


def predict_factor(parts, mean, lower, control, whitening, noise, ledger=None):
    points, wm, wc = points_from_factor(mean, lower, ledger)
    batch, count, dimension = points.shape
    physical = points * whitening.scale + whitening.mean
    propagated = parts.process(physical.reshape(batch * count, dimension).to(torch.float32),
                               control[:, None].expand(batch, count, 3).reshape(batch * count, 3).to(torch.float32))
    whitened = (propagated.reshape(batch, count, dimension).to(torch.float64) - whitening.mean) / whitening.scale
    predicted = torch.einsum('p,bpd->bd', wm, whitened)
    differences = whitened - predicted[:, None]
    q, _, _ = noise_variances(noise)
    if not bool((wc >= 0).all()) or not bool((q > 0).all()):
        raise FilterFailure('invalid positive covariance weights or process noise', {})
    weighted = (differences * wc.sqrt()[None, :, None]).transpose(-1, -2)
    process = torch.diag_embed(q.sqrt()).expand(batch, -1, -1)
    return predicted, factor_columns(torch.cat((weighted, process), dim=-1), ledger)


def update_factor(mean, lower, observation, matrix, offset, r_diagonal, ledger=None):
    batch, dimension = mean.shape
    if matrix.ndim == 2:
        matrix = matrix[None].expand(batch, -1, -1)
    r_diagonal = r_diagonal.expand(batch, -1)
    projected = matrix @ lower
    innovation_factor = factor_columns(torch.cat((projected, torch.diag_embed(r_diagonal.sqrt())), dim=-1), ledger)
    cross = lower @ projected.transpose(-1, -2)
    gain = torch.cholesky_solve(cross.transpose(-1, -2), innovation_factor).transpose(-1, -2)
    residual = observation - (matrix @ mean[..., None]).squeeze(-1) - offset
    posterior = mean + (gain @ residual[..., None]).squeeze(-1)
    complement = torch.eye(dimension, dtype=mean.dtype, device=mean.device)[None] - gain @ matrix
    result = joseph_factor(lower, complement, gain, r_diagonal, ledger)
    if not bool(torch.isfinite(posterior).all()):
        raise FilterFailure('nonfinite posterior', {})
    return posterior, result


def filter_analysis_factor(parts, noise, whitening, initial_state, batch, use_observations=True, ledger=None):
    if whitening.mean.numel() != parts.state_dim:
        raise ValueError('full state whitening dimension')
    local = ledger is None
    ledger = StabilityLedger() if local else ledger
    mean = (initial_state.to(torch.float64) - whitening.mean) / whitening.scale
    _, r, p0 = noise_variances(noise)
    lower = torch.diag_embed(p0.sqrt().expand(len(mean), parts.state_dim))
    for step in range(24):
        mean, lower = predict_factor(parts, mean, lower, batch.analysis_controls[:, step], whitening, noise, ledger)
        if use_observations:
            matrix, offset = observation_affine(parts, whitening)
            mean, lower = update_factor(mean, lower, batch.history[:, 24 + step, :4].to(torch.float64),
                                        matrix, offset, r, ledger)
        ledger.end_step(len(mean))
    report = ledger.report(enforce=local)
    report['posterior_covariance_factor'] = lower
    # Compatibility reporting only: no later propagation reads this dense copy.
    report['posterior_covariance'] = lower @ lower.transpose(-1, -2)
    report['covariance_internal_representation'] = 'positive_diagonal_QR_lower_factor_float64'
    return (mean * whitening.scale + whitening.mean).to(torch.float32), report
