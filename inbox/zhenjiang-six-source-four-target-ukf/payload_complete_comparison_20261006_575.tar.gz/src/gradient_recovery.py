"""Checked power-of-two backward rescaling for representational overflow.

Ordinary finite batches retain the original execution path. Recovery preserves
forward values, physical losses, denominators, clipping and optimizer settings.
"""
import hashlib
import json
import random
import numpy as np
import torch

def rng_state():
    return (random.getstate(),np.random.get_state(),torch.get_rng_state(),
            torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [])

def restore_rng(state):
    random.setstate(state[0]);np.random.set_state(state[1]);torch.set_rng_state(state[2])
    if state[3]:torch.cuda.set_rng_state_all(state[3])

def tensor_hash(value):
    return hashlib.sha256(value.detach().cpu().contiguous().numpy().tobytes()).hexdigest()

def retry_overflow(parts,noise,whitening,method,batch,stats,optimizer,micro_batch,initial_rng):
    from . import training as t
    from .contracts import slice_batch
    from .models import parameters
    from .differentiable_filter import StabilityLedger
    trainable=list(parameters(parts,noise,True))
    if any(p.grad is None for p in trainable):
        raise FloatingPointError('missing gradient cannot use numerical overflow recovery')
    full=(1+batch.high_mask.double()).sum((0,1))
    endpoint=(1+batch.high_mask[:,24:].double()).sum((0,1))

    def trial(exponent):
        restore_rng(initial_rng);optimizer.zero_grad(set_to_none=True)
        scale=2.**exponent;signature=[];loss_value=0.
        ledger=StabilityLedger() if method.startswith('filter') else None
        for start in range(0,len(batch.history),micro_batch):
            sub=slice_batch(batch,slice(start,start+micro_batch))
            if method=='foundation':
                mid,end=t.foundation_predictions(parts,sub)
                loss=.5*t.weighted_mae_cm(mid,sub.targets,sub.high_mask,stats,full)+.5*t.weighted_mae_cm(end,sub.targets[:,24:],sub.high_mask[:,24:],stats,endpoint)
                predictions=[tensor_hash(mid),tensor_hash(end)]
            else:
                prediction=t.branch_prediction(parts,noise,whitening,method,sub,ledger)
                loss=t.weighted_mae_cm(prediction,sub.targets[:,24:],sub.high_mask[:,24:],stats,endpoint)
                predictions=[tensor_hash(prediction)]
            if not torch.isfinite(loss):raise FloatingPointError('nonfinite loss cannot use gradient overflow recovery')
            value=float(loss.detach());loss_value+=value;signature.append((predictions,value.hex()))
            (loss if exponent==0 else loss*scale).backward()
        gradients=[p.grad for p in trainable]
        finite=all(g is not None and bool(torch.isfinite(g).all()) for g in gradients)
        result={'signature':signature,'finite':finite,'loss_cm':loss_value,
                'stability':None if ledger is None else ledger.report(enforce=False),'rng':rng_state()}
        if finite:result['gradients']=[g.detach().clone() for g in gradients]
        return result

    original=trial(0)
    if original['finite']:raise FloatingPointError('nonfinite backward did not repeat; preserve for diagnosis')
    accepted=None
    for exponent in (-8,-16,-32,-64,-128):
        candidate=trial(exponent)
        if candidate['signature']!=original['signature']:
            raise FloatingPointError('forward or unscaled loss changed during gradient recovery')
        if not candidate['finite']:continue
        adjacent=trial(exponent-1)
        if not adjacent['finite'] or adjacent['signature']!=original['signature']:
            raise FloatingPointError('adjacent backward scale failed recovery verification')
        ga,gb=candidate['gradients'],adjacent['gradients']
        if not all(torch.equal(a.double(),b.double()*2) for a,b in zip(ga,gb)):
            raise FloatingPointError('adjacent scales changed gradient direction')
        # Fail closed: matching scales alone cannot exclude shared underflow.
        # Every gradient element in the admitted failing fixture is nonzero.
        if any(bool((g.abs()<torch.finfo(g.dtype).tiny).any()) for g in ga+gb):
            raise FloatingPointError('zero or subnormal gradient needs separate underflow diagnosis')
        def clipping(gradients,scale):
            peak=torch.stack([g.detach().double().abs().max() for g in gradients]).max()
            norm=peak*torch.stack([(g.detach().double()/peak).square().sum() for g in gradients]).sum().sqrt()
            coefficient=torch.clamp(1./(norm+scale*1e-6),max=1./scale)
            return [(g.double()*coefficient).to(g.dtype) for g in gradients],norm/scale
        clipped,norm=clipping(ga,2.**exponent);clipped_b,_=clipping(gb,2.**(exponent-1))
        if not torch.isfinite(norm) or not all(torch.equal(a,b) and bool(torch.isfinite(a).all()) for a,b in zip(clipped,clipped_b)):
            raise FloatingPointError('adjacent scales changed registered clipping result')
        if any(bool((g==0).any()) for g in clipped):
            raise FloatingPointError('clipping erased a nonzero gradient; preserve for diagnosis')
        accepted=(candidate,clipped,float(norm),exponent);break
    if accepted is None:raise FloatingPointError('no verified finite backward rescaling; preserve failure')
    candidate,clipped,norm,exponent=accepted
    with torch.no_grad():
        for p,g in zip(trainable,clipped):p.grad=g
    restore_rng(candidate['rng']);optimizer.step()
    print(json.dumps({'status':'nonfinite_backward_overflow_recovered','backward_scale_exponent':exponent,
                      'adjacent_scale_exponent':exponent-1,'forward_and_unscaled_loss_unchanged':True,
                      'adjacent_unscaled_gradients_bitwise_equal':True,'adjacent_clipped_gradients_bitwise_equal':True,
                      'zero_or_subnormal_gradients':0,'gradient_norm_before_clip':norm,
                      'clipping_bound':1.,'clipping_epsilon':1e-6,'tensor_count':len(trainable)}),flush=True)
    return {'loss_cm':candidate['loss_cm'],'gradient_norm_before_clip':norm,
            'actual_batch_size':len(batch.history),'stability':candidate['stability']}
