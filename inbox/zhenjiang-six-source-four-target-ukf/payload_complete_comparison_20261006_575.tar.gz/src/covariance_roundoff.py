"""Authenticated float64 products and summation of the same positive UT covariance.

Only called after the original permitted-jitter factorization fails. All
operands and dense output remain float64. No model state or threshold changes.
"""
import torch


def two_sum(a, b):
    total = a + b
    recovered_b = total - a
    error = (a - (total - recovered_b)) + (b - recovered_b)
    return total, error


def product_with_error(a, b):
    splitter = 134217729.0
    split_a, split_b = splitter * a, splitter * b
    high_a = split_a - (split_a - a)
    high_b = split_b - (split_b - b)
    low_a, low_b = a - high_a, b - high_b
    product = a * b
    error = ((high_a * high_b - product) + high_a * low_b + low_a * high_b) + low_a * low_b
    return product, error


def compensated_dense(differences, weights, q):
    """Compute the same positive weighted outer products using float64 only."""
    assert differences.dtype == weights.dtype == q.dtype == torch.float64
    # The frozen weights are powers of two, so their multiplication is exact
    # for these authenticated finite, normal-range saved operands.
    assert weights[0] == 2 and bool((weights[1:] == 1 / 256).all())
    high, low = product_with_error(differences[:, :, :, None], differences[:, :, None, :])
    high, low = high * weights[None, :, None, None], low * weights[None, :, None, None]
    while high.shape[1] > 1:
        if high.shape[1] % 2:
            high = torch.cat((high, torch.zeros_like(high[:, :1])), dim=1)
            low = torch.cat((low, torch.zeros_like(low[:, :1])), dim=1)
        added, residue = two_sum(high[:, 0::2], high[:, 1::2])
        high, low = two_sum(added, (low[:, 0::2] + low[:, 1::2]) + residue)
    high, residue = two_sum(high[:, 0], torch.diag(q)[None])
    high, low = two_sum(high, low[:, 0] + residue)
    rounded = high + low
    # Mirror a single triangle, avoiding a further rounding of equal entries.
    return torch.tril(rounded) + torch.tril(rounded, -1).transpose(-1, -2)
