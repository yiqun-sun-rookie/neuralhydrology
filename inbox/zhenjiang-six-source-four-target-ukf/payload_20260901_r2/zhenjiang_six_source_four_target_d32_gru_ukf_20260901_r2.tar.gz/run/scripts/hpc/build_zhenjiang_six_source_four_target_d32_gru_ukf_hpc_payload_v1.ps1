[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$ProjectRoot = "G:\github\pycharm\projects\zhenjiang_stage_forecast",

    [Parameter(Mandatory = $false)]
    [string]$OutputDirectory = "G:\github\pycharm\projects\zhenjiang_stage_forecast\migration_packages\zhenjiang_six_source_four_target_d32_gru_ukf_20260901_r2"
)

$ErrorActionPreference = "Stop"
$project = (Resolve-Path -LiteralPath $ProjectRoot).Path
$output = [IO.Path]::GetFullPath($OutputDirectory)
if (Test-Path -LiteralPath $output) {
    throw "Refusing to overwrite existing payload directory: $output"
}

$registryRelative = "docs/records/ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_DIFFERENTIABLE_UKF_V1_REGISTRY.json"
$registryPath = Join-Path $project ($registryRelative -replace "/", "\")
if (-not (Test-Path -LiteralPath $registryPath -PathType Leaf)) {
    throw "Missing formal registry: $registryRelative"
}
$registry = Get-Content -LiteralPath $registryPath -Raw | ConvertFrom-Json
$remoteRoot = "/data1/home/sunyiq/zhenjiang_six_source_four_target_differentiable_ukf_20260901_r2"
$sourceInputRoot = "/data1/home/sunyiq/zhenjiang_d32_differentiable_ukf_20260828_r2/inputs/pre2024-v1"
$isolatedInputRoot = "$remoteRoot/inputs/pre2024-four-target-v1"
$acceptedTideModel = "results/modeling/wusongkou_astronomical_tide_v1_validation/tide_model.json"
if (
    [string]$registry.registry_name -ne "zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_v1" -or
    [string]$registry.status -ne "authorized_pending_submission" -or
    [string]$registry.hpc.remote_root -ne $remoteRoot -or
    [string]$registry.hpc.source_input_root_read_only -ne $sourceInputRoot -or
    [string]$registry.hpc.isolated_input_root -ne $isolatedInputRoot -or
    $registry.authorization.formal_hpc_training_authorized -ne $true -or
    $registry.authorization.development_2023_evaluation_authorized -ne $true -or
    $registry.authorization.heldout_2024_target_access_authorized -ne $false -or
    $registry.authorization.scientific_conclusion_authorized -ne $false
) {
    throw "Registry authorization or isolated root identity changed"
}

$payloadRows = @($registry.payload_files)
if ($payloadRows.Count -lt 1) {
    throw "Registry payload_files must be a non-empty exact allow-list"
}
$payloadByPath = @{}
$registeredPaths = @()
foreach ($row in $payloadRows) {
    $propertyNames = @($row.PSObject.Properties.Name | Sort-Object)
    $expectedPropertyNames = @("path", "sha256")
    if (@(Compare-Object -ReferenceObject $expectedPropertyNames -DifferenceObject $propertyNames).Count -ne 0) {
        throw "Each payload row must contain only path and sha256"
    }
    $relative = [string]$row.path
    $expectedSha = ([string]$row.sha256).ToLowerInvariant()
    $segments = @($relative.Split("/"))
    if (
        [string]::IsNullOrWhiteSpace($relative) -or
        [IO.Path]::IsPathRooted($relative) -or
        $relative.Contains("\") -or
        $relative.Contains(":") -or
        $relative.Contains("//") -or
        $segments -contains "" -or
        $segments -contains "." -or
        $segments -contains ".."
    ) {
        throw "Payload path must be normalized project-relative text: $relative"
    }
    if ($relative -eq $registryRelative) {
        throw "Registry cannot self-register its own SHA-256"
    }
    $forbidden = (
        $relative -match "(?i)(^|/)(data|archive|migration_packages|logs|__pycache__)(/|$)" -or
        $relative -match "(?i)(^|/)\.git[^/]*(/|$)" -or
        $relative -match "(?i)(^|/)\.hpc_mailbox[^/]*(/|$)" -or
        $relative -match "(?i)\.(csv|tsv|parquet|feather|npy|npz|h5|hdf5)$"
    )
    if ($forbidden -or ($relative.StartsWith("results/") -and $relative -ne $acceptedTideModel)) {
        throw "Payload enters an excluded data, result, archive, cache, Git, or mailbox path: $relative"
    }
    if ($expectedSha -notmatch "^[0-9a-f]{64}$") {
        throw "Registered payload SHA-256 is invalid: $relative"
    }
    if ($payloadByPath.ContainsKey($relative)) {
        throw "Payload allow-list contains a duplicate path: $relative"
    }
    $payloadByPath[$relative] = $expectedSha
    $registeredPaths += $relative
}
if (-not $payloadByPath.ContainsKey($acceptedTideModel)) {
    throw "Accepted astronomical tide model is absent from the payload allow-list"
}

$projectPrefix = $project.TrimEnd("\") + "\"
$sourceItems = @()
foreach ($relative in $registeredPaths) {
    $sourceCandidate = Join-Path $project ($relative -replace "/", "\")
    if (-not (Test-Path -LiteralPath $sourceCandidate -PathType Leaf)) {
        throw "Missing registered payload source: $relative"
    }
    $source = (Resolve-Path -LiteralPath $sourceCandidate).Path
    if (-not $source.StartsWith($projectPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Payload source escapes project root: $relative"
    }
    $file = Get-Item -LiteralPath $source
    if (($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw "Payload source must not be a link: $relative"
    }
    $observedSha = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($observedSha -ne $payloadByPath[$relative]) {
        throw "Registered payload SHA-256 mismatch: $relative"
    }
    $sourceItems += [ordered]@{
        path = $relative
        byte_count = [int64]$file.Length
        sha256 = $observedSha
    }
}

# The registry is appended after verifying every member. It cannot contain its
# own digest, so its identity is recorded in both generated bundle manifests.
$registryFile = Get-Item -LiteralPath $registryPath
$registrySha = (Get-FileHash -LiteralPath $registryPath -Algorithm SHA256).Hash.ToLowerInvariant()
$allItems = @($sourceItems) + @([ordered]@{
    path = $registryRelative
    byte_count = [int64]$registryFile.Length
    sha256 = $registrySha
})
$allPaths = @($registeredPaths) + @($registryRelative)
if (($allPaths | Sort-Object -Unique).Count -ne $allPaths.Count) {
    throw "Payload path set contains a duplicate"
}

$manifest = [ordered]@{
    schema_version = 1
    migration_id = "zhenjiang_six_source_four_target_d32_gru_ukf_20260901_r2"
    scientific_result = $false
    formal_jobs_submitted = $false
    heldout_2024_target_access_authorized = $false
    development_2023_evaluation_authorized = $true
    remote_root = $remoteRoot
    source_input_root_read_only = $sourceInputRoot
    isolated_input_root = $isolatedInputRoot
    registry_path = $registryRelative
    registry_sha256 = $registrySha
    source_file_count = $allItems.Count
    source_files = $allItems
    excluded_source_roots = @(
        ".hpc_mailbox*", ".git*", "__pycache__", "migration_packages",
        "results_except_accepted_tide_model", "logs", "data", "archive"
    )
}

$deployText = @'
#!/usr/bin/env bash
set -eo pipefail

ROOT="/data1/home/sunyiq/zhenjiang_six_source_four_target_differentiable_ukf_20260901_r2"
STAGING="${ROOT}.staging"
PARTIAL="${ROOT}.partial"
SOURCE_INPUT="/data1/home/sunyiq/zhenjiang_d32_differentiable_ukf_20260828_r2/inputs/pre2024-v1"
DESTINATION_INPUT="${STAGING}/inputs/pre2024-four-target-v1"
PAYLOAD_ROOT="${1:?usage: deploy_exclusive_root.sh /absolute/extracted_bundle}"

fatal() {
  echo "[FATAL] $1"
  exit 1
}

case "${PAYLOAD_ROOT}" in
  /*) ;;
  *) fatal "payload root must be absolute" ;;
esac
[ -d "${PAYLOAD_ROOT}/run" ] || fatal "payload run tree is absent"
[ -f "${PAYLOAD_ROOT}/bundle_manifest.json" ] || fatal "bundle manifest is absent"
[ -f "${PAYLOAD_ROOT}/deploy_exclusive_root.sh" ] || fatal "deploy script identity is absent"
for candidate in "${ROOT}" "${PARTIAL}" "${STAGING}"; do
  [ ! -e "${candidate}" ] || fatal "exclusive destination already exists: ${candidate}"
done
[ -d "${SOURCE_INPUT}" ] || fatal "read-only source input root is absent"

mkdir "${STAGING}"
cp -a "${PAYLOAD_ROOT}/run" "${STAGING}/run"
if [ -n "$(find "${STAGING}/run" -type l -print -quit)" ]; then
  fatal "payload contains a symbolic link"
fi
mkdir -p "${DESTINATION_INPUT}" "${STAGING}/runs" "${STAGING}/logs" "${STAGING}/jobs" "${STAGING}/evidence"
cp "${PAYLOAD_ROOT}/deploy_exclusive_root.sh" "${STAGING}/jobs/deploy_exclusive_root.sh"
cp "${PAYLOAD_ROOT}/bundle_manifest.json" "${STAGING}/jobs/bundle_manifest.json"
chmod 0555 "${STAGING}/jobs/deploy_exclusive_root.sh"
chmod 0444 "${STAGING}/jobs/bundle_manifest.json"

python - "${PAYLOAD_ROOT}" "${STAGING}" "${SOURCE_INPUT}" "${DESTINATION_INPUT}" <<'PY'
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import sys

payload = Path(sys.argv[1]).resolve(strict=True)
staging = Path(sys.argv[2]).resolve(strict=True)
source_root = Path(sys.argv[3]).resolve(strict=True)
destination_root = Path(sys.argv[4]).resolve(strict=True)
manifest = json.loads((payload / "bundle_manifest.json").read_text(encoding="utf-8"))
if (
    (staging / "jobs/bundle_manifest.json").read_bytes()
    != (payload / "bundle_manifest.json").read_bytes()
):
    raise SystemExit("retained bundle manifest identity mismatch")
registry_path = staging / "run" / manifest["registry_path"]
registry = json.loads(registry_path.read_text(encoding="utf-8"))
if (
    manifest.get("heldout_2024_target_access_authorized") is not False
    or registry["authorization"]["heldout_2024_target_access_authorized"] is not False
    or registry["hpc"]["source_input_root_read_only"] != str(source_root)
    or registry["hpc"]["isolated_input_root"]
    != "/data1/home/sunyiq/zhenjiang_six_source_four_target_differentiable_ukf_20260901_r2/inputs/pre2024-four-target-v1"
):
    raise SystemExit("bundle or input authorization changed")

expected_payload = {
    row["path"]: (row["byte_count"], row["sha256"])
    for row in manifest["source_files"]
}
actual_payload = {
    path.relative_to(staging / "run").as_posix(): path
    for path in (staging / "run").rglob("*")
    if path.is_file()
}
if set(actual_payload) != set(expected_payload):
    raise SystemExit("deployed run tree differs from exact bundle membership")
for relative, path in actual_payload.items():
    payload_bytes = path.read_bytes()
    expected_bytes, expected_sha = expected_payload[relative]
    if len(payload_bytes) != expected_bytes or hashlib.sha256(payload_bytes).hexdigest() != expected_sha:
        raise SystemExit("deployed payload identity mismatch: " + relative)

rows = registry.get("input_files")
if not isinstance(rows, list) or len(rows) != 11:
    raise SystemExit("registry does not contain exactly eleven input rows")
target_paths = {
    row["path"] for row in rows if row["path"].startswith("retrospective_targets/")
}
expected_targets = {
    "retrospective_targets/nanjing_retrospective_targets.csv",
    "retrospective_targets/zhenjiang_retrospective_targets.csv",
    "retrospective_targets/jiangyin_retrospective_targets.csv",
    "retrospective_targets/xuliujing_retrospective_targets.csv",
}
if target_paths != expected_targets:
    raise SystemExit("input target set contains a boundary or misses an internal target")

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb", buffering=0) as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

copied = []
for row in rows:
    relative = Path(row["path"])
    if relative.is_absolute() or ".." in relative.parts or "boundary" in relative.as_posix().lower():
        raise SystemExit("unsafe input relative path")
    source = source_root / relative
    destination = destination_root / relative
    resolved_source = source.resolve(strict=True)
    try:
        resolved_source.relative_to(source_root)
    except ValueError as error:
        raise SystemExit("source input escaped its read-only root") from error
    if source.is_symlink() or resolved_source != source or not source.is_file():
        raise SystemExit("source input is not one physical regular file: " + row["path"])
    if source.stat().st_size != row["byte_count"] or sha256(source) != row["sha256"]:
        raise SystemExit("source input identity changed: " + row["path"])
    destination.parent.mkdir(parents=True, exist_ok=True)
    with source.open("rb", buffering=0) as source_handle, destination.open("xb", buffering=0) as destination_handle:
        shutil.copyfileobj(source_handle, destination_handle, length=1024 * 1024)
        destination_handle.flush()
        os.fsync(destination_handle.fileno())
    if destination.is_symlink() or destination.stat().st_size != row["byte_count"] or sha256(destination) != row["sha256"]:
        raise SystemExit("new physical input copy identity mismatch: " + row["path"])
    destination.chmod(stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)
    copied.append({
        "path": row["path"],
        "verification_scope": row["verification_scope"],
        "byte_count": row["byte_count"],
        "sha256": row["sha256"],
    })

input_manifest = {
    "schema_version": 1,
    "source_root_read_only": str(source_root),
    "destination_root": "/data1/home/sunyiq/zhenjiang_six_source_four_target_differentiable_ukf_20260901_r2/inputs/pre2024-four-target-v1",
    "file_count": 11,
    "files": copied,
    "later_than_2023_bytes_read": 0,
    "heldout_2024_target_bytes_read": 0,
    "boundary_target_bytes_read": 0,
    "copy_method": "new_physical_regular_files_no_links",
}
(destination_root / "four_target_input_manifest.json").write_text(
    json.dumps(input_manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
top = {path.name for path in staging.iterdir()}
if top != {"run", "inputs", "runs", "logs", "jobs", "evidence"}:
    raise SystemExit("staging top-level directory set differs from the frozen allow-list")
PY

chmod -R a-w "${STAGING}/run" "${DESTINATION_INPUT}"
for candidate in "${ROOT}" "${PARTIAL}"; do
  [ ! -e "${candidate}" ] || fatal "exclusive destination appeared during staging: ${candidate}"
done
mv "${STAGING}" "${ROOT}"
echo "[DONE] exclusive root published: ${ROOT}"
echo "[DONE] copied exactly eleven registered 2017-2023 files; 2024 and boundary targets were not copied"
'@

$systemTemporary = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd("\") + "\"
$temporaryRoot = Join-Path $systemTemporary ("zsf4t_ukf_bundle_" + [Guid]::NewGuid().ToString("N"))
$resolvedTemporary = [IO.Path]::GetFullPath($temporaryRoot)
if (-not $resolvedTemporary.StartsWith($systemTemporary, [StringComparison]::OrdinalIgnoreCase)) {
    throw "Temporary payload path escaped the system temporary directory"
}
$treeRoot = Join-Path $resolvedTemporary "tree"
$runRoot = Join-Path $treeRoot "run"
$publishRoot = Join-Path $resolvedTemporary "publish"
$archiveName = "zhenjiang_six_source_four_target_d32_gru_ukf_20260901_r2.tar.gz"
$archivePath = Join-Path $publishRoot $archiveName
$manifestPath = Join-Path $publishRoot "manifest.sha256.json"
$identityPath = Join-Path $publishRoot "bundle_identity.json"
$utf8NoBom = [Text.UTF8Encoding]::new($false)
$succeeded = $false

try {
    New-Item -ItemType Directory -Path $runRoot -Force | Out-Null
    New-Item -ItemType Directory -Path $publishRoot -Force | Out-Null
    foreach ($relative in $allPaths) {
        $source = Join-Path $project ($relative -replace "/", "\")
        $destination = Join-Path $runRoot ($relative -replace "/", "\")
        $destinationParent = Split-Path -Parent $destination
        if (-not (Test-Path -LiteralPath $destinationParent)) {
            New-Item -ItemType Directory -Path $destinationParent -Force | Out-Null
        }
        Copy-Item -LiteralPath $source -Destination $destination
    }
    [IO.File]::WriteAllText(
        (Join-Path $treeRoot "bundle_manifest.json"),
        ($manifest | ConvertTo-Json -Depth 10) + "`n",
        $utf8NoBom
    )
    [IO.File]::WriteAllText(
        (Join-Path $treeRoot "deploy_exclusive_root.sh"),
        $deployText.Replace("`r`n", "`n") + "`n",
        $utf8NoBom
    )

    & tar.exe -czf $archivePath -C $treeRoot .
    if ($LASTEXITCODE -ne 0) {
        throw "tar creation failed with exit code $LASTEXITCODE"
    }
    $members = @(& tar.exe -tzf $archivePath)
    if ($LASTEXITCODE -ne 0) {
        throw "tar listing failed with exit code $LASTEXITCODE"
    }
    $fileMembers = @(
        $members |
            Where-Object { $_ -ne "./" -and -not $_.EndsWith("/") } |
            ForEach-Object { if ($_.StartsWith("./")) { $_ } else { "./$_" } } |
            Sort-Object
    )
    $expectedMembers = @(
        @($allPaths | ForEach-Object { "./run/$_" }) +
        @("./bundle_manifest.json", "./deploy_exclusive_root.sh") |
        Sort-Object
    )
    if (@(Compare-Object -ReferenceObject $expectedMembers -DifferenceObject $fileMembers).Count -ne 0) {
        throw "Archive membership differs from the exact registered payload"
    }

    [IO.File]::WriteAllText(
        $manifestPath,
        ($manifest | ConvertTo-Json -Depth 10) + "`n",
        $utf8NoBom
    )
    $archive = Get-Item -LiteralPath $archivePath
    $identity = [ordered]@{
        schema_version = 1
        migration_id = $manifest.migration_id
        archive_name = $archiveName
        archive_byte_count = [int64]$archive.Length
        archive_sha256 = (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant()
        archive_member_count = $expectedMembers.Count
        manifest_sha256 = (Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant()
        registry_sha256 = $registrySha
        submitted_job_count = 0
    }
    [IO.File]::WriteAllText(
        $identityPath,
        ($identity | ConvertTo-Json -Depth 5) + "`n",
        $utf8NoBom
    )
    if (Test-Path -LiteralPath $output) {
        throw "Refusing to overwrite existing payload directory: $output"
    }
    Move-Item -LiteralPath $publishRoot -Destination $output
    $succeeded = $true
}
finally {
    if (Test-Path -LiteralPath $resolvedTemporary) {
        $checked = [IO.Path]::GetFullPath($resolvedTemporary)
        if (-not $checked.StartsWith($systemTemporary, [StringComparison]::OrdinalIgnoreCase)) {
            throw "Refusing unsafe temporary cleanup target: $checked"
        }
        Remove-Item -LiteralPath $checked -Recurse -Force
    }
}

if (-not $succeeded -or -not (Test-Path -LiteralPath $output -PathType Container)) {
    throw "Payload publication did not complete"
}
$publishedArchive = Join-Path $output $archiveName
$publishedManifest = Join-Path $output "manifest.sha256.json"
Write-Output "ARCHIVE=$publishedArchive"
Write-Output "ARCHIVE_SHA=$((Get-FileHash -LiteralPath $publishedArchive -Algorithm SHA256).Hash.ToLowerInvariant())"
Write-Output "MANIFEST_SHA=$((Get-FileHash -LiteralPath $publishedManifest -Algorithm SHA256).Hash.ToLowerInvariant())"
Write-Output "REGISTRY_SHA=$registrySha"
Write-Output "SOURCE_FILES=$($allItems.Count)"
Write-Output "ARCHIVE_MEMBERS=$($expectedMembers.Count)"
Write-Output "FORMAL_JOBS_SUBMITTED=0"
