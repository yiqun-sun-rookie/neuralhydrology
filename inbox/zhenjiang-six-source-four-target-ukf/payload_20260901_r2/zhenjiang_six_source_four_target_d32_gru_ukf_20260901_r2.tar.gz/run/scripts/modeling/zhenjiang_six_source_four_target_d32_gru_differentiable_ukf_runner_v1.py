#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run one registered six-source/four-target filter training attempt.

Formal mode requires both the registry authorization and the exact command-line
confirmation.  Output is created as ``attempt_001.partial`` and atomically
published only after its completion manifest is verified.  Existing complete
or partial attempts are never reused or overwritten.

Example:
    python scripts/modeling/zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_runner_v1.py \
      --execution-mode synthetic_smoke --seed 17 --device cpu
"""

from __future__ import annotations

import argparse
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import random
import tempfile
import time
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

from zhenjiang_six_source_four_target_data_v1 import (
    AUTHORIZED_CONTENT_IDENTITIES,
    FourSpaceNormalization,
    TRAINING_SELECTION_CONTENT_IDENTITIES,
    assert_forbidden_target_access_is_zero,
    build_split_datasets,
    load_training_selection_data,
)
from zhenjiang_six_source_four_target_d32_gru_v1 import (
    SixSourceFourTargetD32GRU,
)
from zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_v1 import (
    SixSourceFourTargetD32GRUDifferentiableUKF,
)
from zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_training_v1 import (
    ErrorAccumulator,
    all_cell_metre_absolute_error_sum,
    prepare_filter_for_training,
    validate_filter_forward_output,
)
from train_zhenjiang_six_source_four_target_d32_gru_v1 import (
    run_synthetic_smoke as run_base_synthetic_smoke,
    train_base_model,
)
from fit_zhenjiang_six_source_four_target_realtime_observation_head_v1 import (
    _load_base_model,
    collect_prior_design_and_observations,
    fit_and_select_observation_head,
    run_synthetic_smoke as run_head_synthetic_smoke,
    save_observation_head_selection,
)


EXPERIMENT_FAMILY = (
    "ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_DIFFERENTIABLE_UKF_V1"
)
REGISTRY_NAME = (
    "zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_v1"
)
ALLOWED_SEEDS = (17, 29, 43)
FORMAL_CONFIRMATION = (
    "CONFIRM_ZHENJIANG_SIX_SOURCE_FOUR_TARGET_UKF_HPC_20260901"
)
DEFAULT_REGISTRY_PATH = Path(
    "docs/records/"
    "ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_DIFFERENTIABLE_UKF_V1_REGISTRY.json"
)
REMOTE_ROOT = Path(
    "/data1/home/sunyiq/"
    "zhenjiang_six_source_four_target_differentiable_ukf_20260901_r2"
)
ISOLATED_INPUT_ROOT = REMOTE_ROOT / "inputs/pre2024-four-target-v1"
REGISTERED_TIDE_MODEL_PATH = (
    REMOTE_ROOT
    / "run/results/modeling/"
    "wusongkou_astronomical_tide_v1_validation/tide_model.json"
)
REAL_BATCH_SMOKE_SIZE = 32

FROZEN_OPTIMIZATION: Mapping[str, Any] = {
    "optimizer": "Adam",
    "learning_rate": 0.001,
    "betas": [0.9, 0.999],
    "epsilon": 1e-8,
    "weight_decay": 0.0,
    "learning_rate_scheduler": None,
    "automatic_mixed_precision": False,
    "batch_size": 32,
    "gradient_clip_global_l2": 1.0,
    "minimum_epochs": 5,
    "maximum_epochs": 20,
    "early_stopping_patience": 4,
    "minimum_improvement_m": 0.0001,
    "drop_last": False,
}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb", buffering=0) as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _sha256_prefix(path: str | Path, byte_count: int) -> str:
    """Hash exactly a registered prefix without requesting the next byte."""

    if type(byte_count) is not int or byte_count < 1:
        raise ValueError("prefix byte count must be a positive integer")
    digest = hashlib.sha256()
    remaining = byte_count
    with Path(path).open("rb", buffering=0) as handle:
        while remaining:
            block = handle.read(min(1024 * 1024, remaining))
            if not block:
                raise RuntimeError("input ended before the training-selection prefix")
            digest.update(block)
            remaining -= len(block)
    return digest.hexdigest()


def _read_json(path: str | Path) -> Mapping[str, Any]:
    try:
        document = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError(f"cannot read JSON document: {path}") from error
    if not isinstance(document, Mapping):
        raise ValueError("JSON root must be an object")
    return document


def _write_json_exclusive(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")


def _normalization_document(
    normalization: FourSpaceNormalization,
) -> Mapping[str, Any]:
    def one(space) -> Mapping[str, Any]:
        return {
            "role": space.role,
            "mean_m": np.asarray(space.mean_m).tolist(),
            "standard_deviation_m": np.asarray(
                space.standard_deviation_m
            ).tolist(),
            "value_count": np.asarray(space.value_count).tolist(),
        }

    return {
        "history_stage": one(normalization.history_stage),
        "future_tide": one(normalization.future_tide),
        "analysis_stage": one(normalization.analysis_stage),
        "retrospective_target": one(normalization.retrospective_target),
    }


def _mapping_sha256(value: Mapping[str, Any]) -> str:
    encoded = json.dumps(
        value, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _array_sha256(*arrays: np.ndarray) -> str:
    """Reproduce the observation-head coefficient identity byte for byte."""

    digest = hashlib.sha256()
    for array in arrays:
        contiguous = np.ascontiguousarray(array)
        digest.update(str(contiguous.dtype).encode("ascii"))
        digest.update(str(contiguous.shape).encode("ascii"))
        digest.update(contiguous.tobytes(order="C"))
    return digest.hexdigest()


def _require_exact_registered_path(
    actual: str | Path, expected: Any, *, label: str
) -> Path:
    if not isinstance(expected, str) or not expected.startswith("/"):
        raise ValueError(f"registered {label} path is not absolute")
    actual_path = Path(actual).resolve()
    expected_path = Path(expected).resolve()
    if actual_path != expected_path:
        raise ValueError(f"{label} differs from its unique registered path")
    return actual_path


def _verify_upstream_completion(
    directory: Path,
    *,
    required_file: str,
    expected_seed: int,
) -> Mapping[str, Any]:
    """Verify the exact artifact set and hashes in one upstream task output."""

    manifest_path = directory / "completion_manifest.json"
    document = _read_json(manifest_path)
    if document.get("status") != "complete" or document.get("seed") != expected_seed:
        raise ValueError("upstream completion manifest status or seed changed")
    rows = document.get("files")
    if not isinstance(rows, Mapping) or required_file not in rows:
        raise ValueError("upstream completion manifest lacks the required artifact")
    observed_files = {
        path.name
        for path in directory.iterdir()
        if path.is_file() and path.name != "completion_manifest.json"
    }
    if observed_files != set(rows):
        raise ValueError("upstream completion manifest artifact set changed")
    for name, identity in rows.items():
        if not isinstance(identity, Mapping):
            raise ValueError("upstream completion identity row is invalid")
        path = directory / name
        if (
            not path.is_file()
            or path.stat().st_size != identity.get("byte_count")
            or _sha256(path) != identity.get("sha256")
        ):
            raise ValueError("upstream completion artifact identity mismatch")
    return document


def verify_isolated_input_manifest(
    input_root: str | Path, registry: Mapping[str, Any]
) -> Mapping[str, Any]:
    """Verify the physically copied eleven-file input directory and manifest."""

    root = Path(input_root).resolve()
    if root.is_symlink() or not root.is_dir():
        raise ValueError("isolated input root must be a physical directory")
    manifest_path = root / "four_target_input_manifest.json"
    manifest = _read_json(manifest_path)
    if (
        manifest.get("schema_version") != 1
        or manifest.get("source_root_read_only")
        != registry["hpc"]["source_input_root_read_only"]
        or manifest.get("destination_root") != registry["hpc"]["isolated_input_root"]
        or manifest.get("file_count") != 11
        or manifest.get("later_than_2023_bytes_read") != 0
    ):
        raise ValueError("isolated input manifest contract changed")
    expected_rows = registry.get("input_files")
    observed_rows = manifest.get("files")
    if not isinstance(expected_rows, list) or not isinstance(observed_rows, list):
        raise ValueError("isolated input manifest file rows are missing")
    expected = {
        row["path"]: (row["byte_count"], row["sha256"])
        for row in expected_rows
    }
    observed = {
        row.get("path"): (row.get("byte_count"), row.get("sha256"))
        for row in observed_rows
        if isinstance(row, Mapping)
    }
    if len(observed_rows) != 11 or observed != expected:
        raise ValueError("isolated eleven-file identity set changed")
    expected_files = set(expected) | {"four_target_input_manifest.json"}
    actual_files = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file()
    }
    if actual_files != expected_files:
        raise ValueError("isolated input directory contains an unregistered file")
    for relative, (byte_count, _development_digest) in expected.items():
        path = root / relative
        training_identity = TRAINING_SELECTION_CONTENT_IDENTITIES[relative]
        if (
            path.is_symlink()
            or not path.is_file()
            or path.stat().st_size != byte_count
            or _sha256_prefix(path, training_identity.byte_count)
            != training_identity.sha256
        ):
            raise ValueError("isolated training-selection prefix identity mismatch")
    return {
        "manifest_path": str(manifest_path),
        "manifest_sha256": _sha256(manifest_path),
        "file_count": 11,
    }


def validate_registry_document(document: Mapping[str, Any]) -> None:
    """Validate task counts, unique identities, authorization, and frozen setup."""

    if document.get("schema_version") != 1:
        raise ValueError("registry schema changed")
    if document.get("registry_name") != REGISTRY_NAME:
        raise ValueError("registry name changed")
    if document.get("experiment_family") != EXPERIMENT_FAMILY:
        raise ValueError("experiment family changed")
    authorization = document.get("authorization")
    if not isinstance(authorization, Mapping):
        raise ValueError("registry authorization is missing")
    if authorization.get("heldout_2024_target_access_authorized") is not False:
        raise ValueError("2024 target access must remain unauthorized")
    if authorization.get("development_2023_evaluation_authorized") is not True:
        raise ValueError("the single frozen 2023 development evaluation is not authorized")
    if authorization.get("scientific_conclusion_authorized") is not False:
        raise ValueError("a scientific-success conclusion cannot be pre-authorized")
    if authorization.get("formal_hpc_training_authorized") is not True:
        raise ValueError("formal high-performance-computing training is not authorized")
    if document.get("status") != "authorized_pending_submission":
        raise ValueError("registry status is not authorized_pending_submission")
    if document.get("optimization") != FROZEN_OPTIMIZATION:
        raise ValueError("frozen optimization configuration changed")
    hpc = document.get("hpc")
    if not isinstance(hpc, Mapping):
        raise ValueError("high-performance-computing path contract is missing")
    if (
        hpc.get("remote_root") != REMOTE_ROOT.as_posix()
        or hpc.get("isolated_input_root") != ISOLATED_INPUT_ROOT.as_posix()
        or hpc.get("tide_model_path") != REGISTERED_TIDE_MODEL_PATH.as_posix()
        or hpc.get("remote_root_top_level_allowlist")
        != ["run", "inputs", "runs", "logs", "jobs", "evidence"]
    ):
        raise ValueError("registered high-performance-computing paths changed")
    expected_inputs = {
        identity.relative_path: (
            identity.verification_scope,
            identity.byte_count,
            identity.sha256,
        )
        for identity in AUTHORIZED_CONTENT_IDENTITIES.values()
    }
    input_rows = document.get("input_files")
    observed_inputs = {
        row.get("path"): (
            row.get("verification_scope"),
            row.get("byte_count"),
            row.get("sha256"),
        )
        for row in input_rows
        if isinstance(row, Mapping)
    } if isinstance(input_rows, list) else {}
    if (
        not isinstance(input_rows, list)
        or len(input_rows) != 11
        or len(observed_inputs) != 11
        or observed_inputs != expected_inputs
    ):
        raise ValueError("registered eleven-file input identities changed")
    expected_training_prefixes = {
        identity.relative_path: (
            identity.verification_scope,
            identity.byte_count,
            identity.sha256,
        )
        for identity in TRAINING_SELECTION_CONTENT_IDENTITIES.values()
    }
    training_rows = document.get("training_selection_prefix_files")
    observed_training_prefixes = {
        row.get("path"): (
            row.get("verification_scope"),
            row.get("byte_count"),
            row.get("sha256"),
        )
        for row in training_rows
        if isinstance(row, Mapping)
    } if isinstance(training_rows, list) else {}
    if (
        not isinstance(training_rows, list)
        or len(training_rows) != 11
        or len(observed_training_prefixes) != 11
        or observed_training_prefixes != expected_training_prefixes
        or sum(value[1] for value in observed_training_prefixes.values())
        != 46_826_115
    ):
        raise ValueError("registered 2017--2022 training prefix identities changed")
    tasks = document.get("tasks")
    if not isinstance(tasks, list) or len(tasks) != 9:
        raise ValueError("registry must contain exactly nine tasks")
    identifiers = [row.get("task_id") for row in tasks if isinstance(row, Mapping)]
    if len(identifiers) != 9 or len(set(identifiers)) != 9:
        raise ValueError("registry contains duplicate or invalid task identifiers")
    expected = {
        (stage, seed)
        for stage in ("base_training", "observation_head", "filter_training")
        for seed in ALLOWED_SEEDS
    }
    observed = {
        (row.get("stage"), row.get("seed"))
        for row in tasks
        if isinstance(row, Mapping)
    }
    if observed != expected:
        raise ValueError("registry task stage/seed coordinates changed")
    if any(row.get("status") != "authorized_pending_submission" for row in tasks):
        raise ValueError("one or more tasks are not authorized_pending_submission")
    for row in tasks:
        seed = row["seed"]
        stage = row["stage"]
        expected_output = REMOTE_ROOT / "runs" / (
            "base" if stage == "base_training" else stage.replace("_training", "")
        ) / f"s{seed}" / "attempt_001"
        if row.get("registered_output_path") != expected_output.as_posix():
            raise ValueError("registered task output path changed")
        if stage in {"observation_head", "filter_training"}:
            expected_base = (
                REMOTE_ROOT / "runs/base" / f"s{seed}"
                / "attempt_001/best_checkpoint.pt"
            )
            if row.get("registered_base_checkpoint_path") != expected_base.as_posix():
                raise ValueError("registered base checkpoint path changed")
        if stage == "base_training":
            expected_smoke = REMOTE_ROOT / "runs/base_smoke" / f"s{seed}/attempt_001"
            if row.get("registered_smoke_path") != expected_smoke.as_posix():
                raise ValueError("registered base smoke path changed")
        elif stage == "observation_head":
            expected_smoke = (
                REMOTE_ROOT / "runs/observation_head_smoke"
                / f"s{seed}/attempt_001"
            )
            if row.get("registered_smoke_path") != expected_smoke.as_posix():
                raise ValueError("registered observation-head smoke path changed")
        elif stage == "filter_training":
            expected_head = (
                REMOTE_ROOT / "runs/observation_head" / f"s{seed}"
                / "attempt_001/realtime_observation_head.pt"
            )
            expected_smoke = (
                REMOTE_ROOT / "runs/filter_real_batch_smoke"
                / f"s{seed}/attempt_001"
            )
            if row.get("registered_observation_head_path") != expected_head.as_posix():
                raise ValueError("registered observation-head path changed")
            if row.get("registered_real_batch_smoke_path") != expected_smoke.as_posix():
                raise ValueError("registered real-batch smoke path changed")
    post_training_tasks = document.get("post_training_tasks")
    if not isinstance(post_training_tasks, list) or len(post_training_tasks) != 2:
        raise ValueError("registry must contain two post-training evidence tasks")
    post_by_stage = {
        row.get("stage"): row
        for row in post_training_tasks
        if isinstance(row, Mapping)
    }
    if set(post_by_stage) != {"development_2023_evaluation", "independent_audit"}:
        raise ValueError("registered post-training task stages changed")
    evaluation_output = (
        REMOTE_ROOT / "evidence/development_2023/evaluation/attempt_001"
    ).as_posix()
    evaluation_smoke = (
        REMOTE_ROOT / "runs/development_evaluation_smoke/attempt_001"
    ).as_posix()
    audit_output = (
        REMOTE_ROOT / "evidence/development_2023/independent_audit/attempt_001"
    ).as_posix()
    evaluation = post_by_stage["development_2023_evaluation"]
    audit = post_by_stage["independent_audit"]
    if (
        evaluation.get("task_id")
        != "ZSF4T-D32-GRU-DUKF-DEVELOPMENT-2023-EVALUATION-V1"
        or evaluation.get("status") != "authorized_pending_submission"
        or evaluation.get("registered_smoke_path") != evaluation_smoke
        or evaluation.get("registered_output_path") != evaluation_output
        or audit.get("task_id")
        != "ZSF4T-D32-GRU-DUKF-DEVELOPMENT-2023-INDEPENDENT-AUDIT-V1"
        or audit.get("status") != "authorized_pending_submission"
        or audit.get("registered_output_path") != audit_output
        or audit.get("registered_evaluation_output_path") != evaluation_output
    ):
        raise ValueError("registered post-training evidence paths changed")


def load_registered_task(
    registry_path: str | Path,
    *,
    seed: int,
    stage: str,
) -> Tuple[Mapping[str, Any], Mapping[str, Any]]:
    """Load exactly one unique task from the authorized registry."""

    document = _read_json(registry_path)
    validate_registry_document(document)
    rows = [
        row
        for row in document["tasks"]
        if row["seed"] == seed and row["stage"] == stage
    ]
    if len(rows) != 1:
        raise ValueError("registered task coordinate is not unique")
    return document, rows[0]


def load_registered_post_training_task(
    registry_path: str | Path,
    *,
    stage: str,
) -> Tuple[Mapping[str, Any], Mapping[str, Any]]:
    """Load one exact registered 2023 evaluation or independent-audit task."""

    if stage not in {"development_2023_evaluation", "independent_audit"}:
        raise ValueError("post-training stage is not registered")
    document = _read_json(registry_path)
    validate_registry_document(document)
    rows = [
        row
        for row in document["post_training_tasks"]
        if row["stage"] == stage
    ]
    if len(rows) != 1:
        raise ValueError("registered post-training task coordinate is not unique")
    return document, rows[0]


def _move_batch(batch: Mapping[str, Any], device: torch.device) -> Dict[str, Any]:
    required = (
        "history",
        "future_tide",
        "analysis_observations",
        "targets_t_plus_2_to_t_plus_24",
    )
    result: Dict[str, Any] = dict(batch)
    for key in required:
        value = batch.get(key)
        if not isinstance(value, torch.Tensor):
            raise ValueError(f"batch is missing tensor {key}")
        result[key] = value.to(device=device, non_blocking=False)
    return result


def _gradient_diagnostics(model: torch.nn.Module) -> Mapping[str, Any]:
    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
    scalar_count = sum(parameter.numel() for parameter in trainable)
    if scalar_count != 38:
        raise RuntimeError("trainable scalar count differs from 38")
    nonfinite = 0
    zero = 0
    for parameter in trainable:
        if parameter.grad is None:
            raise RuntimeError("a trainable filter parameter has no gradient")
        nonfinite += int((~torch.isfinite(parameter.grad)).sum().item())
        zero += int((parameter.grad == 0.0).sum().item())
    if nonfinite:
        raise RuntimeError("filter gradient contains a nonfinite value")
    return {
        "gradient_scalar_count": scalar_count,
        "nonfinite_gradient_count": nonfinite,
        "zero_gradient_count": zero,
    }


def run_training_epoch(
    model: torch.nn.Module,
    loader: Iterable[Mapping[str, Any]],
    optimizer: torch.optim.Optimizer,
    target_standard_deviation_m: torch.Tensor,
    device: torch.device | str,
    *,
    gradient_clip_global_l2: float = 1.0,
    maximum_batches: Optional[int] = None,
) -> Tuple[Mapping[str, Any], Sequence[Mapping[str, Any]]]:
    """Train one epoch and aggregate sums/counts across the partial last batch."""

    torch_device = torch.device(device)
    model.train(True)
    if hasattr(model, "backbone"):
        model.backbone.eval()
    accumulator = ErrorAccumulator()
    gradient_rows = []
    for batch_index, raw_batch in enumerate(loader):
        if maximum_batches is not None and batch_index >= maximum_batches:
            break
        batch = _move_batch(raw_batch, torch_device)
        optimizer.zero_grad(set_to_none=True)
        output = model(
            batch["history"],
            batch["future_tide"],
            batch["analysis_observations"],
        )
        batch_size = int(batch["history"].shape[0])
        validate_filter_forward_output(output, batch_size)
        error_sum, cell_count = all_cell_metre_absolute_error_sum(
            output["updated_forecast"],
            batch["targets_t_plus_2_to_t_plus_24"],
            target_standard_deviation_m,
        )
        loss = error_sum / cell_count
        if not bool(torch.isfinite(loss)):
            raise RuntimeError("training loss is nonfinite")
        loss.backward()
        gradient_row = dict(_gradient_diagnostics(model))
        norm = torch.nn.utils.clip_grad_norm_(
            [parameter for parameter in model.parameters() if parameter.requires_grad],
            max_norm=gradient_clip_global_l2,
            error_if_nonfinite=True,
        )
        gradient_row.update(
            {
                "batch_index": batch_index,
                "preclip_global_l2": float(norm.detach().cpu()),
            }
        )
        gradient_rows.append(gradient_row)
        optimizer.step()
        accumulator.add(error_sum, cell_count, batch_size)
    return accumulator.summary(), gradient_rows


@torch.no_grad()
def run_validation_epoch(
    model: torch.nn.Module,
    loader: Iterable[Mapping[str, Any]],
    target_standard_deviation_m: torch.Tensor,
    device: torch.device | str,
    *,
    maximum_batches: Optional[int] = None,
) -> Mapping[str, Any]:
    """Evaluate all 552 cells without dropping or equally averaging batches."""

    torch_device = torch.device(device)
    model.eval()
    if hasattr(model, "backbone"):
        model.backbone.eval()
    accumulator = ErrorAccumulator()
    for batch_index, raw_batch in enumerate(loader):
        if maximum_batches is not None and batch_index >= maximum_batches:
            break
        batch = _move_batch(raw_batch, torch_device)
        output = model(
            batch["history"],
            batch["future_tide"],
            batch["analysis_observations"],
        )
        batch_size = int(batch["history"].shape[0])
        validate_filter_forward_output(output, batch_size)
        error_sum, cell_count = all_cell_metre_absolute_error_sum(
            output["updated_forecast"],
            batch["targets_t_plus_2_to_t_plus_24"],
            target_standard_deviation_m,
        )
        accumulator.add(error_sum, cell_count, batch_size)
    summary = accumulator.summary()
    return {**summary, "selection_mae_m": summary["mae_m"]}


def _load_frozen_filter(
    base_checkpoint_path: Path,
    observation_head_path: Path,
    *,
    seed: int,
    device: torch.device,
) -> Tuple[SixSourceFourTargetD32GRUDifferentiableUKF, Mapping[str, Any]]:
    _verify_upstream_completion(
        base_checkpoint_path.parent,
        required_file=base_checkpoint_path.name,
        expected_seed=seed,
    )
    _verify_upstream_completion(
        observation_head_path.parent,
        required_file=observation_head_path.name,
        expected_seed=seed,
    )
    base_sha = _sha256(base_checkpoint_path)
    base = torch.load(base_checkpoint_path, map_location="cpu", weights_only=False)
    if (
        not isinstance(base, Mapping)
        or base.get("seed") != seed
        or base.get("model_class") != "SixSourceFourTargetD32GRU"
        or base.get("realtime_observation_head_fitted") is not False
        or base.get("total_parameter_count") != 19_594
        or base.get("base_stage_trainable_parameter_count") != 19_396
        or not isinstance(base.get("normalization"), Mapping)
    ):
        raise ValueError("base checkpoint identity or contract changed")
    backbone = SixSourceFourTargetD32GRU()
    backbone.load_state_dict(base["model_state_dict"], strict=True)
    head_sha = _sha256(observation_head_path)
    head = torch.load(observation_head_path, map_location="cpu", weights_only=False)
    if (
        not isinstance(head, Mapping)
        or head.get("seed") != seed
        or head.get("base_checkpoint_sha256") != base_sha
        or head.get("normalization_role") != "analysis_t_plus_1_realtime_stage"
        or head.get("selected_ridge_strength")
        not in (0.0, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1.0)
    ):
        raise ValueError("realtime observation head identity or contract changed")
    weight = head.get("weight_float32")
    bias = head.get("bias_float32")
    if (
        not isinstance(weight, torch.Tensor)
        or weight.shape != (6, 32)
        or weight.dtype != torch.float32
        or not isinstance(bias, torch.Tensor)
        or bias.shape != (6,)
        or bias.dtype != torch.float32
    ):
        raise ValueError("saved realtime observation head is not float32 [6,32]+[6]")
    observed_coefficient_sha = _array_sha256(
        weight.detach().cpu().numpy(), bias.detach().cpu().numpy()
    )
    if observed_coefficient_sha != head.get("coefficient_float32_sha256"):
        raise ValueError("saved realtime observation coefficient identity changed")
    with torch.no_grad():
        backbone.realtime_observation_decoder.weight.copy_(weight)
        backbone.realtime_observation_decoder.bias.copy_(bias)
    filter_model = prepare_filter_for_training(
        SixSourceFourTargetD32GRUDifferentiableUKF(backbone), device
    )
    return filter_model, {
        "base_checkpoint_sha256": base_sha,
        "observation_head_sha256": head_sha,
        "base_normalization": base.get("normalization"),
    }


def _filter_checkpoint(
    model: SixSourceFourTargetD32GRUDifferentiableUKF,
    *,
    seed: int,
    epoch: int,
    selection_mae_m: float,
    identities: Mapping[str, Any],
    normalization_sha256: str,
) -> Mapping[str, Any]:
    return {
        "schema_version": 1,
        "experiment_family": EXPERIMENT_FAMILY,
        "seed": seed,
        "epoch": epoch,
        "selection_mae_m": selection_mae_m,
        "selection_cell_contract": "6_sources_x_23_leads_x_4_targets",
        "selection_cells_per_base_sample": 552,
        "base_checkpoint_sha256": identities["base_checkpoint_sha256"],
        "observation_head_sha256": identities["observation_head_sha256"],
        "normalization_sha256": normalization_sha256,
        "filter_state_dict": {
            "process_noise.raw_standard_deviation": (
                model.process_noise.raw_standard_deviation.detach().cpu().clone()
            ),
            "observation_noise.raw_standard_deviation": (
                model.observation_noise.raw_standard_deviation.detach().cpu().clone()
            ),
        },
        "optimization": dict(FROZEN_OPTIMIZATION),
    }


def write_completion_manifest(output_directory: str | Path, *, status: str) -> Path:
    """Write the last artifact, binding every preceding regular file."""

    output = Path(output_directory)
    manifest_path = output / "completion_manifest.json"
    if manifest_path.exists():
        raise FileExistsError("completion manifest already exists")
    files = []
    for path in sorted(output.rglob("*")):
        if path.is_file() and path != manifest_path:
            files.append(
                {
                    "path": path.relative_to(output).as_posix(),
                    "byte_count": path.stat().st_size,
                    "sha256": _sha256(path),
                }
            )
    document = {
        "schema_version": 1,
        "experiment_family": EXPERIMENT_FAMILY,
        "status": status,
        "created_utc": _utc_now(),
        "verified_artifact_count": len(files),
        "files": files,
    }
    _write_json_exclusive(manifest_path, document)
    return manifest_path


def verify_output_directory(output_directory: str | Path) -> Mapping[str, Any]:
    """Recompute a completed attempt without importing checkpoints."""

    output = Path(output_directory)
    document = _read_json(output / "completion_manifest.json")
    if (
        document.get("schema_version") != 1
        or document.get("experiment_family") != EXPERIMENT_FAMILY
    ):
        raise RuntimeError("completion manifest contract changed")
    rows = document.get("files")
    if not isinstance(rows, list) or document.get("verified_artifact_count") != len(rows):
        raise RuntimeError("completion manifest file count changed")
    registered = set()
    for row in rows:
        relative = Path(row.get("path", ""))
        if relative.is_absolute() or ".." in relative.parts or relative.as_posix() in registered:
            raise RuntimeError("completion artifact path is invalid")
        registered.add(relative.as_posix())
        path = output / relative
        if (
            not path.is_file()
            or path.stat().st_size != row.get("byte_count")
            or _sha256(path) != row.get("sha256")
        ):
            raise RuntimeError("completion artifact identity mismatch")
    observed = {
        path.relative_to(output).as_posix()
        for path in output.rglob("*")
        if path.is_file() and path.name != "completion_manifest.json"
    }
    if observed != registered:
        raise RuntimeError("completion artifact set identity mismatch")
    return {
        "status": document.get("status"),
        "verified_file_count": len(rows),
        "completion_manifest_sha256": _sha256(
            output / "completion_manifest.json"
        ),
    }


def _verify_registered_real_batch_smoke(
    output_directory: str | Path, *, seed: int
) -> Mapping[str, Any]:
    """Verify the retained batch-32 graphics-processor preflight evidence."""

    output = Path(output_directory)
    verification = verify_output_directory(output)
    if verification.get("status") != "technical_pass_real_batch_32":
        raise RuntimeError("registered real-batch smoke did not pass")
    report = _read_json(output / "report.json")
    required = {
        "execution_mode": "real_batch_smoke",
        "status": "technical_pass_real_batch_32",
        "stage": "filter",
        "seed": seed,
        "batch_size": REAL_BATCH_SMOKE_SIZE,
        "valid_cell_count": REAL_BATCH_SMOKE_SIZE * 552,
        "forward_backward_optimizer_step_count": 1,
        "device_type": "cuda",
    }
    if any(report.get(key) != value for key, value in required.items()):
        raise RuntimeError("registered real-batch smoke report contract changed")
    for key in (
        "step_seconds",
        "peak_gpu_memory_allocated_bytes",
        "peak_gpu_memory_reserved_bytes",
    ):
        value = report.get(key)
        if not isinstance(value, (int, float)) or isinstance(value, bool) or value < 0:
            raise RuntimeError("registered real-batch smoke resource evidence is invalid")
    return {**verification, "report": report}


def _verify_registered_synthetic_smoke(
    output_directory: str | Path, *, stage: str, seed: int
) -> Mapping[str, Any]:
    """Verify the retained no-real-data preflight for an upstream stage."""

    if stage not in {"base", "observation_head"}:
        raise ValueError("synthetic upstream smoke stage changed")
    output = Path(output_directory)
    verification = verify_output_directory(output)
    if verification.get("status") != "technical_pass":
        raise RuntimeError("registered synthetic smoke did not pass")
    report = _read_json(output / "report.json")
    required = {
        "execution_mode": "synthetic_smoke",
        "status": "technical_pass",
        "stage": stage,
        "seed": seed,
        "formal_output_created": False,
        "real_data_opened": False,
    }
    if any(report.get(key) != value for key, value in required.items()):
        raise RuntimeError("registered synthetic smoke report contract changed")
    return {**verification, "report": report}


def load_registered_frozen_filter_for_evaluation(
    registry_path: str | Path,
    *,
    seed: int,
    device: str | torch.device,
) -> Tuple[SixSourceFourTargetD32GRUDifferentiableUKF, Mapping[str, Any]]:
    """Load one immutable registered filter without opening an evaluation dataset."""

    registry, task = load_registered_task(
        registry_path, seed=seed, stage="filter_training"
    )
    del registry
    base_checkpoint = Path(task["registered_base_checkpoint_path"])
    observation_head = Path(task["registered_observation_head_path"])
    filter_output = Path(task["registered_output_path"])
    model, identities = _load_frozen_filter(
        base_checkpoint,
        observation_head,
        seed=seed,
        device=torch.device(device),
    )
    verification = verify_output_directory(filter_output)
    if verification.get("status") != "complete_2022_selected_training":
        raise ValueError("registered filter training completion status changed")
    checkpoint_path = filter_output / "best_filter_checkpoint.pt"
    checkpoint = torch.load(
        checkpoint_path, map_location="cpu", weights_only=False
    )
    if (
        not isinstance(checkpoint, Mapping)
        or checkpoint.get("schema_version") != 1
        or checkpoint.get("experiment_family") != EXPERIMENT_FAMILY
        or checkpoint.get("seed") != seed
        or checkpoint.get("base_checkpoint_sha256")
        != identities["base_checkpoint_sha256"]
        or checkpoint.get("observation_head_sha256")
        != identities["observation_head_sha256"]
        or checkpoint.get("normalization_sha256")
        != _mapping_sha256(identities["base_normalization"])
        or checkpoint.get("optimization") != FROZEN_OPTIMIZATION
        or type(checkpoint.get("epoch")) is not int
        or checkpoint.get("epoch") < 1
        or not isinstance(checkpoint.get("selection_mae_m"), (int, float))
        or isinstance(checkpoint.get("selection_mae_m"), bool)
        or not math.isfinite(float(checkpoint.get("selection_mae_m")))
    ):
        raise ValueError("registered filter checkpoint identity or contract changed")
    state = checkpoint.get("filter_state_dict")
    expected_keys = {
        "process_noise.raw_standard_deviation",
        "observation_noise.raw_standard_deviation",
    }
    if not isinstance(state, Mapping) or set(state) != expected_keys:
        raise ValueError("registered filter state dictionary changed")
    process = state["process_noise.raw_standard_deviation"]
    observation = state["observation_noise.raw_standard_deviation"]
    if (
        not isinstance(process, torch.Tensor)
        or process.shape != model.process_noise.raw_standard_deviation.shape
        or process.dtype != torch.float64
        or not isinstance(observation, torch.Tensor)
        or observation.shape != model.observation_noise.raw_standard_deviation.shape
        or observation.dtype != torch.float64
        or not bool(torch.isfinite(process).all())
        or not bool(torch.isfinite(observation).all())
    ):
        raise ValueError("registered filter noise parameter shape or dtype changed")
    with torch.no_grad():
        model.process_noise.raw_standard_deviation.copy_(
            process.to(model.process_noise.raw_standard_deviation.device)
        )
        model.observation_noise.raw_standard_deviation.copy_(
            observation.to(model.observation_noise.raw_standard_deviation.device)
        )
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    model.eval()
    return model, {
        **identities,
        "filter_checkpoint_path": str(checkpoint_path),
        "filter_checkpoint_sha256": _sha256(checkpoint_path),
        "filter_completion_manifest_sha256": verification[
            "completion_manifest_sha256"
        ],
        "normalization_sha256": checkpoint["normalization_sha256"],
        "selection_mae_m": checkpoint["selection_mae_m"],
        "epoch": checkpoint["epoch"],
    }


def _set_reproducible_execution(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True, warn_only=False)


def _exclusive_attempt_paths(output_directory: str | Path) -> Tuple[Path, Path]:
    final = Path(output_directory).resolve()
    partial = final.with_name(final.name + ".partial")
    if final.exists():
        raise FileExistsError(f"attempt output already exists: {final}")
    if partial.exists():
        raise FileExistsError(f"partial attempt output already exists: {partial}")
    if final.name != "attempt_001":
        raise ValueError("formal output must end in attempt_001")
    return partial, final


def assert_training_target_access_is_predevelopment(access_audit: Any) -> None:
    """Require explicit zero access to every 2023, held-out, and boundary field."""

    counts = getattr(access_audit, "target_rows_by_period", None)
    if not isinstance(counts, Mapping):
        raise ValueError("data access audit lacks target period counts")
    forbidden_keys = (
        "development_gate",
        "development_2023",
        "heldout_or_later",
        "heldout_2024_and_later",
        "boundary_target",
    )
    for key in forbidden_keys:
        value = counts.get(key, 0)
        if type(value) is not int or value != 0:
            raise RuntimeError(f"nonzero forbidden target access before training: {key}")
    required_zero_attributes = (
        "development_feature_bytes_read",
        "development_feature_rows_parsed",
        "development_feature_values_loaded",
        "development_target_bytes_read",
        "development_target_rows_parsed",
        "development_target_values_loaded",
        "heldout_target_bytes_read",
        "heldout_target_rows_parsed",
        "heldout_target_values_loaded",
        "boundary_target_bytes_read",
        "boundary_target_rows_parsed",
        "boundary_target_values_loaded",
    )
    for attribute in required_zero_attributes:
        if not hasattr(access_audit, attribute):
            raise ValueError(f"data access audit lacks required field: {attribute}")
        value = getattr(access_audit, attribute)
        if type(value) is not int or value != 0:
            raise RuntimeError(
                f"nonzero forbidden target access before training: {attribute}"
            )


def execute_filter_real_batch_smoke(
    *,
    seed: int,
    device: str | torch.device,
    registry_path: str | Path,
    input_root: str | Path,
    tide_model_path: str | Path,
    base_checkpoint_path: str | Path,
    observation_head_path: str | Path,
    output_directory: str | Path,
) -> Mapping[str, Any]:
    """Run one actual batch-32 filter optimization step and retain evidence."""

    if seed not in ALLOWED_SEEDS:
        raise ValueError("seed must be one of 17, 29, or 43")
    partial, final = _exclusive_attempt_paths(output_directory)
    registry, task = load_registered_task(
        registry_path, seed=seed, stage="filter_training"
    )
    _require_exact_registered_path(
        final,
        task.get("registered_real_batch_smoke_path"),
        label="filter real-batch smoke output",
    )
    isolated_input = _require_exact_registered_path(
        input_root,
        registry["hpc"]["isolated_input_root"],
        label="formal isolated input root",
    )
    registered_tide_model = _require_exact_registered_path(
        tide_model_path,
        registry["hpc"]["tide_model_path"],
        label="registered astronomical tide model",
    )
    base_checkpoint = _require_exact_registered_path(
        base_checkpoint_path,
        task.get("registered_base_checkpoint_path"),
        label="base checkpoint",
    )
    observation_head = _require_exact_registered_path(
        observation_head_path,
        task.get("registered_observation_head_path"),
        label="realtime observation head",
    )
    if (
        not registered_tide_model.is_file()
        or not base_checkpoint.is_file()
        or not observation_head.is_file()
    ):
        raise FileNotFoundError("registered tide model, base, or observation head is absent")
    torch_device = torch.device(device)
    if torch_device.type != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("real-batch smoke requires one visible CUDA graphics processor")

    # Upstream manifests and coefficients are authenticated before any copied
    # time-series input is opened.
    _set_reproducible_execution(seed)
    model, identities = _load_frozen_filter(
        base_checkpoint, observation_head, seed=seed, device=torch_device
    )
    input_identity = verify_isolated_input_manifest(isolated_input, registry)
    data, training_dataset, _selection_dataset = _load_training_data_after_guards(
        isolated_input, registered_tide_model
    )
    normalization_document = _normalization_document(data.normalization)
    if identities["base_normalization"] != normalization_document:
        raise ValueError("data normalization identity differs from the base checkpoint")
    if len(training_dataset) < REAL_BATCH_SMOKE_SIZE:
        raise RuntimeError("training selection data lacks one complete batch of 32")

    partial.parent.mkdir(parents=True, exist_ok=True)
    partial.mkdir(exist_ok=False)
    try:
        loader = DataLoader(
            training_dataset,
            batch_size=REAL_BATCH_SMOKE_SIZE,
            shuffle=False,
            drop_last=True,
            num_workers=0,
        )
        first_batch = next(iter(loader))
        if int(first_batch["history"].shape[0]) != REAL_BATCH_SMOKE_SIZE:
            raise RuntimeError("real-batch smoke did not materialize exactly 32 samples")
        target_scale = torch.as_tensor(
            data.normalization.retrospective_target.standard_deviation_m,
            dtype=torch.float64,
            device=torch_device,
        )
        optimizer = torch.optim.Adam(
            [parameter for parameter in model.parameters() if parameter.requires_grad],
            lr=0.001,
            betas=(0.9, 0.999),
            eps=1e-8,
            weight_decay=0.0,
            amsgrad=False,
        )
        torch.cuda.synchronize(torch_device)
        torch.cuda.reset_peak_memory_stats(torch_device)
        started = time.perf_counter()
        training, gradients = run_training_epoch(
            model,
            (first_batch,),
            optimizer,
            target_scale,
            torch_device,
            gradient_clip_global_l2=1.0,
        )
        torch.cuda.synchronize(torch_device)
        elapsed = time.perf_counter() - started
        if (
            training["base_sample_count"] != REAL_BATCH_SMOKE_SIZE
            or training["valid_cell_count"] != REAL_BATCH_SMOKE_SIZE * 552
            or len(gradients) != 1
        ):
            raise RuntimeError("real-batch smoke step count or cell count changed")
        report = {
            "schema_version": 1,
            "experiment_family": EXPERIMENT_FAMILY,
            "execution_mode": "real_batch_smoke",
            "status": "technical_pass_real_batch_32",
            "stage": "filter",
            "task_id": task["task_id"],
            "seed": seed,
            "batch_size": REAL_BATCH_SMOKE_SIZE,
            "valid_cell_count": training["valid_cell_count"],
            "mae_m": training["mae_m"],
            "gradient_scalar_count": gradients[0]["gradient_scalar_count"],
            "forward_backward_optimizer_step_count": 1,
            "step_seconds": elapsed,
            "device": str(torch_device),
            "device_type": torch_device.type,
            "graphics_processor_name": torch.cuda.get_device_name(torch_device),
            "peak_gpu_memory_allocated_bytes": torch.cuda.max_memory_allocated(
                torch_device
            ),
            "peak_gpu_memory_reserved_bytes": torch.cuda.max_memory_reserved(
                torch_device
            ),
            "registered_output_path": str(final),
            "registry_sha256": _sha256(registry_path),
            "base_checkpoint_sha256": identities["base_checkpoint_sha256"],
            "observation_head_sha256": identities["observation_head_sha256"],
            "training_selection_input_manifest_path": input_identity[
                "manifest_path"
            ],
            "training_selection_input_manifest_sha256": input_identity[
                "manifest_sha256"
            ],
            "data_access_audit": asdict(data.access_audit),
            "formal_filter_result_created": False,
            "created_utc": _utc_now(),
        }
        _write_json_exclusive(partial / "report.json", report)
        write_completion_manifest(
            partial, status="technical_pass_real_batch_32"
        )
        verification = verify_output_directory(partial)
        _verify_registered_real_batch_smoke(partial, seed=seed)
        os.replace(str(partial), str(final))
        return {**verification, **report, "output_directory": str(final)}
    except Exception:
        # The partial directory is intentionally retained as failure evidence.
        raise


def execute_filter_training(
    *,
    seed: int,
    device: str | torch.device,
    registry_path: str | Path,
    input_root: str | Path,
    tide_model_path: str | Path,
    base_checkpoint_path: str | Path,
    observation_head_path: str | Path,
    output_directory: str | Path,
) -> Mapping[str, Any]:
    """Execute one authorized 2017--2022 fit/selection attempt."""

    if seed not in ALLOWED_SEEDS:
        raise ValueError("seed must be one of 17, 29, or 43")
    partial, final = _exclusive_attempt_paths(output_directory)
    registry, task = load_registered_task(
        registry_path, seed=seed, stage="filter_training"
    )
    _require_exact_registered_path(
        final, task.get("registered_output_path"), label="filter output"
    )
    _require_exact_registered_path(
        input_root,
        registry["hpc"]["isolated_input_root"],
        label="formal isolated input root",
    )
    registered_tide_model = _require_exact_registered_path(
        tide_model_path,
        registry["hpc"]["tide_model_path"],
        label="registered astronomical tide model",
    )
    base_checkpoint = _require_exact_registered_path(
        base_checkpoint_path,
        task.get("registered_base_checkpoint_path"),
        label="base checkpoint",
    )
    observation_head = _require_exact_registered_path(
        observation_head_path,
        task.get("registered_observation_head_path"),
        label="realtime observation head",
    )
    real_batch_smoke = Path(task["registered_real_batch_smoke_path"])
    if (
        not registered_tide_model.is_file()
        or not base_checkpoint.is_file()
        or not observation_head.is_file()
    ):
        raise FileNotFoundError("registered tide model, base, or observation head is absent")
    _verify_registered_real_batch_smoke(real_batch_smoke, seed=seed)

    torch_device = torch.device(device)
    _set_reproducible_execution(seed)
    # The upstream task manifests and observation-head coefficient identity are
    # authenticated before any copied time-series input is opened.
    model, identities = _load_frozen_filter(
        base_checkpoint, observation_head, seed=seed, device=torch_device
    )
    input_identity = verify_isolated_input_manifest(input_root, registry)
    # Data is opened only after all overwrite, registry, and upstream-identity
    # guards have passed.
    data = load_training_selection_data(input_root, registered_tide_model)
    assert_forbidden_target_access_is_zero(data.access_audit)
    assert_training_target_access_is_predevelopment(data.access_audit)
    normalization_document = _normalization_document(data.normalization)
    if identities["base_normalization"] != normalization_document:
        raise ValueError("data normalization identity differs from the base checkpoint")
    normalization_sha = _mapping_sha256(normalization_document)
    datasets = build_split_datasets(data)
    if len(datasets["training"]) < 1 or len(datasets["selection"]) < 1:
        raise RuntimeError("training and 2022 selection datasets must be nonempty")

    partial.parent.mkdir(parents=True, exist_ok=True)
    partial.mkdir(exist_ok=False)
    try:
        run_identity = {
            "schema_version": 1,
            "experiment_family": EXPERIMENT_FAMILY,
            "task_id": task["task_id"],
            "seed": seed,
            "attempt_id": "attempt_001",
            "started_utc": _utc_now(),
            "registry_sha256": _sha256(registry_path),
            "base_checkpoint_sha256": identities["base_checkpoint_sha256"],
            "observation_head_sha256": identities["observation_head_sha256"],
            "normalization_sha256": normalization_sha,
            "training_selection_input_manifest_path": input_identity[
                "manifest_path"
            ],
            "training_selection_input_manifest_sha256": input_identity[
                "manifest_sha256"
            ],
            "training_sample_count": len(datasets["training"]),
            "selection_sample_count": len(datasets["selection"]),
            "data_access_audit": asdict(data.access_audit),
            "optimization": dict(FROZEN_OPTIMIZATION),
            "environment": {
                "torch": torch.__version__,
                "numpy": np.__version__,
                "device": str(torch_device),
                "cuda_matmul_allow_tf32": torch.backends.cuda.matmul.allow_tf32,
                "cudnn_allow_tf32": torch.backends.cudnn.allow_tf32,
            },
        }
        _write_json_exclusive(partial / "run_identity.json", run_identity)
        generator = torch.Generator().manual_seed(seed)
        training_loader = DataLoader(
            datasets["training"],
            batch_size=32,
            shuffle=True,
            generator=generator,
            drop_last=False,
            num_workers=0,
        )
        selection_loader = DataLoader(
            datasets["selection"],
            batch_size=32,
            shuffle=False,
            drop_last=False,
            num_workers=0,
        )
        target_scale = torch.as_tensor(
            data.normalization.retrospective_target.standard_deviation_m,
            dtype=torch.float64,
            device=torch_device,
        )
        optimizer = torch.optim.Adam(
            [parameter for parameter in model.parameters() if parameter.requires_grad],
            lr=0.001,
            betas=(0.9, 0.999),
            eps=1e-8,
            weight_decay=0.0,
            amsgrad=False,
        )
        history = []
        gradient_history = []
        best_metric = math.inf
        best_checkpoint = None
        last_checkpoint = None
        best_epoch = 0
        epochs_without_improvement = 0
        for epoch in range(1, 21):
            start = time.perf_counter()
            training, gradients = run_training_epoch(
                model,
                training_loader,
                optimizer,
                target_scale,
                torch_device,
                gradient_clip_global_l2=1.0,
            )
            selection = run_validation_epoch(
                model, selection_loader, target_scale, torch_device
            )
            metric = float(selection["selection_mae_m"])
            improved = best_epoch == 0 or metric < best_metric - 0.0001
            if improved:
                best_metric = metric
                best_epoch = epoch
                epochs_without_improvement = 0
            else:
                epochs_without_improvement += 1
            last_checkpoint = _filter_checkpoint(
                model,
                seed=seed,
                epoch=epoch,
                selection_mae_m=metric,
                identities=identities,
                normalization_sha256=normalization_sha,
            )
            if improved:
                best_checkpoint = last_checkpoint
            history.append(
                {
                    "epoch": epoch,
                    "training_absolute_error_sum_m": training["absolute_error_sum_m"],
                    "training_cell_count": training["valid_cell_count"],
                    "training_mae_m": training["mae_m"],
                    "selection_absolute_error_sum_m": selection["absolute_error_sum_m"],
                    "selection_cell_count": selection["valid_cell_count"],
                    "selection_mae_m": metric,
                    "selected_as_best": improved,
                    "best_epoch_after": best_epoch,
                    "epoch_seconds": time.perf_counter() - start,
                }
            )
            gradient_history.extend(
                {"epoch": epoch, **row} for row in gradients
            )
            if epoch >= 5 and epochs_without_improvement >= 4:
                break
        if best_checkpoint is None or last_checkpoint is None:
            raise RuntimeError("training did not produce a checkpoint")
        torch.save(best_checkpoint, partial / "best_filter_checkpoint.pt")
        torch.save(last_checkpoint, partial / "last_filter_checkpoint.pt")
        _write_json_exclusive(
            partial / "training_history.json", {"epochs": history}
        )
        _write_json_exclusive(
            partial / "gradient_history.json", {"batches": gradient_history}
        )
        _write_json_exclusive(
            partial / "summary.json",
            {
                "schema_version": 1,
                "status": "complete_2022_selected_training",
                "seed": seed,
                "best_epoch": best_epoch,
                "best_selection_mae_m": best_metric,
                "completed_epoch": history[-1]["epoch"],
                "training_cells_per_base_sample": 552,
                "station_specific_checkpoint_count": 0,
                "data_access_audit": asdict(data.access_audit),
                "training_selection_input_manifest_sha256": input_identity[
                    "manifest_sha256"
                ],
            },
        )
        write_completion_manifest(
            partial, status="complete_2022_selected_training"
        )
        verification = verify_output_directory(partial)
        os.replace(str(partial), str(final))
        return {
            **verification,
            "output_directory": str(final),
            "best_epoch": best_epoch,
            "best_selection_mae_m": best_metric,
        }
    except Exception:
        # The partial directory is intentionally retained as failure evidence.
        raise


def _extend_stage_completion_manifest(
    directory: Path,
    *,
    registered_output_path: Path,
    run_identity_path: Path,
) -> None:
    """Bind the access audit to an upstream task before atomic publication."""

    manifest_path = directory / "completion_manifest.json"
    document = dict(_read_json(manifest_path))
    rows = document.get("files")
    if not isinstance(rows, Mapping):
        raise ValueError("stage completion manifest lacks a file mapping")
    mutable_rows = dict(rows)
    mutable_rows[run_identity_path.name] = {
        "byte_count": run_identity_path.stat().st_size,
        "sha256": _sha256(run_identity_path),
    }
    document["files"] = mutable_rows
    if "output_directory" in document:
        document["output_directory"] = str(registered_output_path)
    manifest_path.write_text(
        json.dumps(document, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def _load_training_data_after_guards(
    input_root: Path,
    tide_model_path: Path,
) -> Tuple[Any, Mapping[str, Any], Mapping[str, Any]]:
    data = load_training_selection_data(input_root, tide_model_path)
    assert_forbidden_target_access_is_zero(data.access_audit)
    assert_training_target_access_is_predevelopment(data.access_audit)
    datasets = build_split_datasets(data)
    if (
        len(datasets["training"]) < 1
        or len(datasets["selection"]) < 1
        or len(datasets["development_gate"]) != 0
    ):
        raise RuntimeError("training-selection split touched development data")
    return data, datasets["training"], datasets["selection"]


def execute_base_training(
    *,
    seed: int,
    device: str | torch.device,
    registry_path: str | Path,
    input_root: str | Path,
    tide_model_path: str | Path,
    output_directory: str | Path,
) -> Mapping[str, Any]:
    """Train one base model into its own immutable registered attempt."""

    partial, final = _exclusive_attempt_paths(output_directory)
    registry, task = load_registered_task(
        registry_path, seed=seed, stage="base_training"
    )
    _require_exact_registered_path(
        final, task.get("registered_output_path"), label="base output"
    )
    isolated_input = _require_exact_registered_path(
        input_root,
        registry["hpc"]["isolated_input_root"],
        label="formal isolated input root",
    )
    registered_tide_model = _require_exact_registered_path(
        tide_model_path,
        registry["hpc"]["tide_model_path"],
        label="registered astronomical tide model",
    )
    if not registered_tide_model.is_file():
        raise FileNotFoundError("registered astronomical tide model is absent")
    _verify_registered_synthetic_smoke(
        task["registered_smoke_path"], stage="base", seed=seed
    )
    input_identity = verify_isolated_input_manifest(isolated_input, registry)
    _set_reproducible_execution(seed)
    torch_device = torch.device(device)
    data, training_dataset, selection_dataset = _load_training_data_after_guards(
        isolated_input, registered_tide_model
    )
    partial.parent.mkdir(parents=True, exist_ok=True)
    try:
        report = train_base_model(
            training_dataset=training_dataset,
            selection_dataset=selection_dataset,
            normalization=data.normalization,
            seed=seed,
            device=torch_device,
            output_directory=partial,
        )
        run_identity_path = partial / "run_identity.json"
        _write_json_exclusive(
            run_identity_path,
            {
                "schema_version": 1,
                "task_id": task["task_id"],
                "stage": "base_training",
                "seed": seed,
                "registered_output_path": str(final),
                "registry_sha256": _sha256(registry_path),
                "training_selection_input_manifest_sha256": input_identity[
                    "manifest_sha256"
                ],
                "data_access_audit": asdict(data.access_audit),
                "created_utc": _utc_now(),
            },
        )
        _extend_stage_completion_manifest(
            partial,
            registered_output_path=final,
            run_identity_path=run_identity_path,
        )
        _verify_upstream_completion(
            partial, required_file="best_checkpoint.pt", expected_seed=seed
        )
        os.replace(str(partial), str(final))
        return {
            "status": "complete",
            "stage": "base_training",
            "seed": seed,
            "output_directory": str(final),
            "best_epoch": report["best_epoch"],
        }
    except Exception:
        raise


def execute_observation_head_training(
    *,
    seed: int,
    device: str | torch.device,
    registry_path: str | Path,
    input_root: str | Path,
    tide_model_path: str | Path,
    base_checkpoint_path: str | Path,
    output_directory: str | Path,
) -> Mapping[str, Any]:
    """Fit one realtime observation head into its own immutable attempt."""

    partial, final = _exclusive_attempt_paths(output_directory)
    registry, task = load_registered_task(
        registry_path, seed=seed, stage="observation_head"
    )
    _require_exact_registered_path(
        final, task.get("registered_output_path"), label="observation-head output"
    )
    registered_base = _require_exact_registered_path(
        base_checkpoint_path,
        task.get("registered_base_checkpoint_path"),
        label="observation-head upstream base checkpoint",
    )
    if not registered_base.is_file():
        raise FileNotFoundError("registered base checkpoint is absent")
    _verify_upstream_completion(
        registered_base.parent,
        required_file=registered_base.name,
        expected_seed=seed,
    )
    isolated_input = _require_exact_registered_path(
        input_root,
        registry["hpc"]["isolated_input_root"],
        label="formal isolated input root",
    )
    registered_tide_model = _require_exact_registered_path(
        tide_model_path,
        registry["hpc"]["tide_model_path"],
        label="registered astronomical tide model",
    )
    if not registered_tide_model.is_file():
        raise FileNotFoundError("registered astronomical tide model is absent")
    _verify_registered_synthetic_smoke(
        task["registered_smoke_path"], stage="observation_head", seed=seed
    )
    input_identity = verify_isolated_input_manifest(isolated_input, registry)
    _set_reproducible_execution(seed)
    torch_device = torch.device(device)
    data, training_dataset, selection_dataset = _load_training_data_after_guards(
        isolated_input, registered_tide_model
    )
    model = _load_base_model(registered_base, seed, str(torch_device))
    training_x, training_y = collect_prior_design_and_observations(
        model, training_dataset, device=str(torch_device)
    )
    selection_x, selection_y = collect_prior_design_and_observations(
        model, selection_dataset, device=str(torch_device)
    )
    selection = fit_and_select_observation_head(
        training_x,
        training_y,
        selection_x,
        selection_y,
        data.normalization.analysis_stage.standard_deviation_m,
    )
    try:
        report = save_observation_head_selection(
            model=model,
            selection=selection,
            seed=seed,
            base_checkpoint=registered_base,
            output_directory=partial,
        )
        run_identity_path = partial / "run_identity.json"
        _write_json_exclusive(
            run_identity_path,
            {
                "schema_version": 1,
                "task_id": task["task_id"],
                "stage": "observation_head",
                "seed": seed,
                "registered_output_path": str(final),
                "registered_base_checkpoint_path": str(registered_base),
                "base_checkpoint_sha256": _sha256(registered_base),
                "registry_sha256": _sha256(registry_path),
                "training_selection_input_manifest_sha256": input_identity[
                    "manifest_sha256"
                ],
                "data_access_audit": asdict(data.access_audit),
                "created_utc": _utc_now(),
            },
        )
        _extend_stage_completion_manifest(
            partial,
            registered_output_path=final,
            run_identity_path=run_identity_path,
        )
        _verify_upstream_completion(
            partial,
            required_file="realtime_observation_head.pt",
            expected_seed=seed,
        )
        os.replace(str(partial), str(final))
        return {
            "status": "complete",
            "stage": "observation_head",
            "seed": seed,
            "output_directory": str(final),
            "selected_ridge_strength": report["selected_ridge_strength"],
        }
    except Exception:
        raise


class _SyntheticDataset(Dataset):
    def __init__(self, count: int, seed: int) -> None:
        generator = torch.Generator().manual_seed(seed)
        self.rows = [
            {
                "history": torch.randn(24, 6, generator=generator) * 0.02,
                "future_tide": torch.randn(24, generator=generator) * 0.02,
                "analysis_observations": torch.randn(6, generator=generator) * 0.02,
                "targets_t_plus_2_to_t_plus_24": torch.randn(
                    23, 4, generator=generator
                )
                * 0.02,
            }
            for _ in range(count)
        ]

    def __len__(self) -> int:
        return len(self.rows)

    def __getitem__(self, index: int) -> Mapping[str, torch.Tensor]:
        return self.rows[index]


def run_synthetic_smoke(seed: int, device: str | torch.device) -> Mapping[str, Any]:
    """Run one synthetic batch without touching a formal output root."""

    if seed not in ALLOWED_SEEDS:
        raise ValueError("seed must be one of 17, 29, or 43")
    _set_reproducible_execution(seed)
    torch_device = torch.device(device)
    model = prepare_filter_for_training(
        SixSourceFourTargetD32GRUDifferentiableUKF(
            SixSourceFourTargetD32GRU()
        ),
        torch_device,
    )
    optimizer = torch.optim.Adam(
        [parameter for parameter in model.parameters() if parameter.requires_grad],
        lr=0.001,
        betas=(0.9, 0.999),
        eps=1e-8,
        weight_decay=0.0,
    )
    loader = DataLoader(_SyntheticDataset(1, seed), batch_size=1, shuffle=False)
    scale = torch.ones(4, dtype=torch.float64, device=torch_device)
    training, gradients = run_training_epoch(
        model, loader, optimizer, scale, torch_device
    )
    return {
        "execution_mode": "synthetic_smoke",
        "status": "technical_pass",
        "seed": seed,
        "valid_cell_count": training["valid_cell_count"],
        "mae_m": training["mae_m"],
        "gradient_scalar_count": gradients[0]["gradient_scalar_count"],
        "formal_output_created": False,
        "real_data_opened": False,
    }


def run_upstream_synthetic_smoke(
    stage: str, seed: int, device: str | torch.device
) -> Mapping[str, Any]:
    """Run one upstream synthetic smoke path without a formal output root."""

    if stage == "base":
        report = run_base_synthetic_smoke(seed, str(device))
        if report.get("metrics_finite") is not True:
            raise RuntimeError("base synthetic metrics are nonfinite")
    elif stage == "observation_head":
        report = run_head_synthetic_smoke(seed, str(device))
        if report.get("candidate_count") != 8:
            raise RuntimeError("observation-head candidate count changed")
    else:
        raise ValueError("upstream smoke stage must be base or observation_head")
    if (
        report.get("execution_mode") != "synthetic_smoke"
        or report.get("seed") != seed
        or report.get("formal_output_created") is not False
    ):
        raise RuntimeError("upstream synthetic smoke contract changed")
    return {
        "execution_mode": "synthetic_smoke",
        "stage": stage,
        "status": "technical_pass",
        "seed": seed,
        "stage_report": report,
        "formal_output_created": False,
        "real_data_opened": False,
    }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--execution-mode",
        choices=("synthetic_smoke", "real_batch_smoke", "formal"),
        required=True,
    )
    parser.add_argument(
        "--stage",
        choices=("base", "observation_head", "filter"),
        default="filter",
    )
    parser.add_argument("--seed", type=int, choices=ALLOWED_SEEDS, required=True)
    parser.add_argument("--device", required=True)
    parser.add_argument("--registry", type=Path, default=DEFAULT_REGISTRY_PATH)
    parser.add_argument("--input-root", type=Path)
    parser.add_argument("--tide-model-path", type=Path)
    parser.add_argument("--base-checkpoint", type=Path)
    parser.add_argument("--observation-head", type=Path)
    parser.add_argument("--output-directory", type=Path)
    parser.add_argument("--formal-confirmation")
    parser.add_argument("--verify-output", type=Path)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    arguments = _parser().parse_args(argv)
    if arguments.verify_output is not None:
        incompatible = (
            arguments.execution_mode != "synthetic_smoke"
            or any(
                value is not None
                for value in (
                    arguments.input_root,
                    arguments.tide_model_path,
                    arguments.base_checkpoint,
                    arguments.observation_head,
                    arguments.output_directory,
                    arguments.formal_confirmation,
                )
            )
        )
        if incompatible:
            raise SystemExit("--verify-output must be used without formal arguments")
        report = verify_output_directory(arguments.verify_output)
    elif arguments.execution_mode == "synthetic_smoke":
        if arguments.stage in {"base", "observation_head"}:
            report = run_upstream_synthetic_smoke(
                arguments.stage, arguments.seed, arguments.device
            )
        else:
            report = run_synthetic_smoke(arguments.seed, arguments.device)
    elif arguments.execution_mode == "real_batch_smoke":
        if arguments.formal_confirmation != FORMAL_CONFIRMATION:
            raise RuntimeError(
                "exact paid-compute command-line confirmation is missing"
            )
        if arguments.stage != "filter":
            raise ValueError("real_batch_smoke is defined only for the filter stage")
        required = {
            "input_root": arguments.input_root,
            "tide_model_path": arguments.tide_model_path,
            "base_checkpoint": arguments.base_checkpoint,
            "observation_head": arguments.observation_head,
            "output_directory": arguments.output_directory,
        }
        missing = [name for name, value in required.items() if value is None]
        if missing:
            raise ValueError("real_batch_smoke is missing: " + ", ".join(missing))
        report = execute_filter_real_batch_smoke(
            seed=arguments.seed,
            device=arguments.device,
            registry_path=arguments.registry,
            input_root=arguments.input_root,
            tide_model_path=arguments.tide_model_path,
            base_checkpoint_path=arguments.base_checkpoint,
            observation_head_path=arguments.observation_head,
            output_directory=arguments.output_directory,
        )
    else:
        if arguments.formal_confirmation != FORMAL_CONFIRMATION:
            raise RuntimeError("exact formal command-line confirmation is missing")
        common_required = {
            "input_root": arguments.input_root,
            "tide_model_path": arguments.tide_model_path,
            "output_directory": arguments.output_directory,
        }
        missing = [name for name, value in common_required.items() if value is None]
        if missing:
            raise ValueError("formal mode is missing: " + ", ".join(missing))
        if arguments.stage == "base":
            if arguments.base_checkpoint is not None or arguments.observation_head is not None:
                raise ValueError("base stage rejects command-line upstream artifacts")
            report = execute_base_training(
                seed=arguments.seed,
                device=arguments.device,
                registry_path=arguments.registry,
                input_root=arguments.input_root,
                tide_model_path=arguments.tide_model_path,
                output_directory=arguments.output_directory,
            )
        elif arguments.stage == "observation_head":
            if arguments.base_checkpoint is None or arguments.observation_head is not None:
                raise ValueError(
                    "observation_head stage requires only its registered base checkpoint"
                )
            report = execute_observation_head_training(
                seed=arguments.seed,
                device=arguments.device,
                registry_path=arguments.registry,
                input_root=arguments.input_root,
                tide_model_path=arguments.tide_model_path,
                base_checkpoint_path=arguments.base_checkpoint,
                output_directory=arguments.output_directory,
            )
        else:
            if arguments.base_checkpoint is None or arguments.observation_head is None:
                raise ValueError("filter stage requires both registered upstream artifacts")
            report = execute_filter_training(
                seed=arguments.seed,
                device=arguments.device,
                registry_path=arguments.registry,
                input_root=arguments.input_root,
                tide_model_path=arguments.tide_model_path,
                base_checkpoint_path=arguments.base_checkpoint,
                observation_head_path=arguments.observation_head,
                output_directory=arguments.output_directory,
            )
    print(json.dumps(report, indent=2, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
