"""Static safety checks for the isolated four-target high-performance run."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

import pytest


ROOT = Path(__file__).resolve().parents[1]
MODELING = ROOT / "scripts" / "modeling"
if str(MODELING) not in sys.path:
    sys.path.insert(0, str(MODELING))

from register_zhenjiang_six_source_four_target_d32_gru_ukf_v1 import (  # noqa: E402
    ACCEPTED_TIDE_MODEL_RELATIVE_PATH,
    REMOTE_ROOT,
    _safe_relative_path,
    validate_registry,
)


REGISTRY = (
    ROOT
    / "docs/records/"
    "ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_DIFFERENTIABLE_UKF_V1_REGISTRY.json"
)
BUILDER = (
    ROOT
    / "scripts/hpc/"
    "build_zhenjiang_six_source_four_target_d32_gru_ukf_hpc_payload_v1.ps1"
)
REGISTER_SCRIPT = (
    ROOT
    / "scripts/modeling/"
    "register_zhenjiang_six_source_four_target_d32_gru_ukf_v1.py"
)
RUNNER = (
    ROOT
    / "scripts/modeling/"
    "zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_runner_v1.py"
)
UPSTREAM_SLURM = (
    ROOT / "scripts/hpc/zhenjiang_six_source_four_target_d32_gru_base_v1.slurm"
)
FILTER_SLURM = (
    ROOT
    / "scripts/hpc/"
    "zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_v1.slurm"
)
EVALUATION_SLURM = (
    ROOT
    / "scripts/hpc/"
    "zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1.slurm"
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _registry() -> dict:
    return json.loads(REGISTRY.read_text(encoding="utf-8"))


def test_registry_has_nine_independent_training_attempts_and_two_evidence_tasks():
    document = _registry()
    authorization = document["authorization"]
    assert authorization["formal_hpc_training_authorized"] is True
    assert authorization["development_2023_evaluation_authorized"] is True
    assert authorization["heldout_2024_target_access_authorized"] is False
    assert authorization["scientific_conclusion_authorized"] is False

    expected = {
        (stage, seed): (
            f"{REMOTE_ROOT}/runs/"
            f"{'base' if stage == 'base_training' else stage.replace('_training', '')}/"
            f"s{seed}/attempt_001"
        )
        for stage in ("base_training", "observation_head", "filter_training")
        for seed in (17, 29, 43)
    }
    observed = {
        (row["stage"], row["seed"]): row["registered_output_path"]
        for row in document["tasks"]
    }
    assert observed == expected
    assert len(set(observed.values())) == 9
    assert all("/results/" not in value for value in observed.values())
    assert all("base_head" not in value for value in observed.values())

    post = {row["stage"]: row for row in document["post_training_tasks"]}
    assert post["development_2023_evaluation"]["registered_output_path"] == (
        f"{REMOTE_ROOT}/evidence/development_2023/evaluation/attempt_001"
    )
    assert post["independent_audit"]["registered_output_path"] == (
        f"{REMOTE_ROOT}/evidence/development_2023/independent_audit/attempt_001"
    )


def test_technical_recovery_uses_only_the_fresh_r2_root_and_bundle_identity():
    document = _registry()
    assert REMOTE_ROOT.endswith("_r2")
    assert document["hpc"]["remote_root"] == REMOTE_ROOT
    failed_r1_root = REMOTE_ROOT[:-1] + "1"
    migration_id = "zhenjiang_six_source_four_target_d32_gru_ukf_20260901_r2"
    failed_migration_id = migration_id[:-1] + "1"
    builder_text = BUILDER.read_text(encoding="utf-8")
    assert f'migration_id = "{migration_id}"' in builder_text
    assert f'$archiveName = "{migration_id}.tar.gz"' in builder_text
    assert migration_id in builder_text
    assert failed_migration_id not in builder_text
    for path in (REGISTRY, UPSTREAM_SLURM, FILTER_SLURM, EVALUATION_SLURM):
        text = path.read_text(encoding="utf-8")
        assert REMOTE_ROOT in text
        assert failed_r1_root not in text
    root_name = REMOTE_ROOT.rsplit("/", 1)[-1]
    failed_root_name = root_name[:-1] + "1"
    for path in (REGISTER_SCRIPT, RUNNER):
        text = path.read_text(encoding="utf-8")
        assert root_name in text
        assert failed_root_name not in text


def test_registry_binds_exact_full_and_training_prefix_input_identities():
    document = _registry()
    full_rows = document["input_files"]
    training_rows = document["training_selection_prefix_files"]
    assert len(full_rows) == len(training_rows) == 11
    assert sum(row["byte_count"] for row in full_rows) == 54_635_809
    assert sum(row["byte_count"] for row in training_rows) == 46_826_115
    assert {
        row["path"]
        for row in full_rows
        if row["path"].startswith("retrospective_targets/")
    } == {
        "retrospective_targets/nanjing_retrospective_targets.csv",
        "retrospective_targets/zhenjiang_retrospective_targets.csv",
        "retrospective_targets/jiangyin_retrospective_targets.csv",
        "retrospective_targets/xuliujing_retrospective_targets.csv",
    }
    assert all(row["verification_scope"] == "header_plus_52584_rows" for row in training_rows[1:])


@pytest.mark.parametrize(
    "path",
    [UPSTREAM_SLURM, FILTER_SLURM, EVALUATION_SLURM],
)
def test_slurm_contract_uses_one_3090_without_memory_or_nested_launcher(path):
    text = path.read_text(encoding="utf-8")
    assert "#SBATCH --partition=hgpu2p" in text
    assert "#SBATCH --gres=gpu:1" in text
    assert "#SBATCH --exclude=ngu002" in text
    assert "#SBATCH --mem" not in text
    assert "srun " not in text
    assert "sbatch " not in text
    assert f"#SBATCH --output={REMOTE_ROOT}/logs/" in text
    assert f"#SBATCH --error={REMOTE_ROOT}/logs/" in text
    assert "RTX 3090" in text
    assert "conda activate nh_final" in text
    assert "set -u" not in text
    assert "/results/base_head/" not in text
    assert f'{REMOTE_ROOT}/smoke/' not in text


def test_three_independent_seeds_run_concurrently_with_stage_dependencies():
    upstream = UPSTREAM_SLURM.read_text(encoding="utf-8")
    filtering = FILTER_SLURM.read_text(encoding="utf-8")
    assert "#SBATCH --array=0-2%3" in upstream
    assert "#SBATCH --array=0-2%3" in filtering
    assert "runs/base/s${SEED}/attempt_001" in upstream
    assert "runs/observation_head/s${SEED}/attempt_001" in upstream
    assert "runs/filter/s${SEED}/attempt_001" in filtering
    assert "runs/filter_real_batch_smoke/s${SEED}/attempt_001" in filtering


def test_filter_formal_job_is_gated_by_actual_batch_32_forward_backward_step():
    text = FILTER_SLURM.read_text(encoding="utf-8")
    assert "--execution-mode real_batch_smoke" in text
    assert "--execution-mode formal" in text
    assert text.index("--execution-mode real_batch_smoke") < text.index(
        "--execution-mode formal"
    )
    runner = (
        ROOT
        / "scripts/modeling/"
        "zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_runner_v1.py"
    ).read_text(encoding="utf-8")
    assert "REAL_BATCH_SMOKE_SIZE = 32" in runner
    assert '"forward_backward_optimizer_step_count": 1' in runner
    assert "torch.cuda.max_memory_allocated" in runner
    assert "torch.cuda.max_memory_reserved" in runner
    assert "_verify_registered_real_batch_smoke(real_batch_smoke" in runner


def test_development_evaluation_smoke_and_single_formal_call_are_separate():
    text = EVALUATION_SLURM.read_text(encoding="utf-8")
    assert "--execution-mode synthetic_smoke" in text
    assert "--execution-mode formal_2023_once" in text
    assert text.index("--execution-mode synthetic_smoke") < text.index(
        "--execution-mode formal_2023_once"
    )
    assert "evidence/development_2023/evaluation/attempt_001" in text
    assert "evidence/development_2023/independent_audit/attempt_001" in text
    evaluator = (
        ROOT
        / "scripts/analysis/"
        "zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1.py"
    ).read_text(encoding="utf-8")
    assert "technical_pass_development_evaluation_smoke" in evaluator
    assert '"real_data_opened": False' in evaluator
    assert "load_development_data(input_root, tide_model_path)" in evaluator


def test_payload_allowlist_hashes_every_member_and_the_accepted_tide_model():
    document = _registry()
    rows = document["payload_files"]
    assert rows
    paths = [row["path"] for row in rows]
    assert len(paths) == len(set(paths))
    assert ACCEPTED_TIDE_MODEL_RELATIVE_PATH in paths
    for row in rows:
        path = ROOT / row["path"]
        assert path.is_file() and not path.is_symlink()
        assert _sha256(path) == row["sha256"]
        parts = [part.lower() for part in Path(row["path"]).parts]
        assert not any(part.startswith(".hpc_mailbox") for part in parts)
        assert not any(part.startswith(".git") for part in parts)
        assert "__pycache__" not in parts
        assert not ({"data", "archive", "migration_packages", "logs"} & set(parts))
        if parts[0] == "results":
            assert row["path"] == ACCEPTED_TIDE_MODEL_RELATIVE_PATH
    report = validate_registry(REGISTRY, project_root=ROOT)
    assert report["payload_file_count"] == len(rows)
    assert report["heldout_2024_target_access_authorized"] is False


def test_only_the_exact_accepted_tide_model_may_enter_results():
    assert _safe_relative_path(ACCEPTED_TIDE_MODEL_RELATIVE_PATH).as_posix() == (
        ACCEPTED_TIDE_MODEL_RELATIVE_PATH
    )
    for forbidden in (
        "results/modeling/another/tide_model.json",
        "results/modeling/wusongkou_astronomical_tide_v1_validation/other.json",
        "results/checkpoint.pt",
    ):
        with pytest.raises(ValueError, match="only the accepted"):
            _safe_relative_path(forbidden)
    for forbidden in (
        ".hpc_mailbox_zhenjiang_four_target_ukf_r1/message.json",
        ".git/config",
        "scripts/__pycache__/module.pyc",
        "logs/job.out",
        "data/input.json",
        "archive/frozen.py",
        "scripts/analysis/leaked_targets.csv",
    ):
        with pytest.raises(ValueError):
            _safe_relative_path(forbidden)


def test_builder_excludes_mailboxes_and_exclusively_stages_the_new_root():
    text = BUILDER.read_text(encoding="utf-8")
    for marker in (
        ".hpc_mailbox",
        ".git",
        "__pycache__",
        "migration_packages",
        "results_except_accepted_tide_model",
        "logs",
        "data",
        "archive",
    ):
        assert marker in text
    assert 'STAGING="${ROOT}.staging"' in text
    assert 'PARTIAL="${ROOT}.partial"' in text
    assert 'for candidate in "${ROOT}" "${PARTIAL}" "${STAGING}"' in text
    assert 'mv "${STAGING}" "${ROOT}"' in text
    assert "cp --reflink=never" not in text
    assert (
        'cp "${PAYLOAD_ROOT}/bundle_manifest.json" '
        '"${STAGING}/jobs/bundle_manifest.json"'
    ) in text
    assert (
        'cp "${PAYLOAD_ROOT}/deploy_exclusive_root.sh" '
        '"${STAGING}/jobs/deploy_exclusive_root.sh"'
    ) in text
    assert 'chmod 0444 "${STAGING}/jobs/bundle_manifest.json"' in text
    assert "retained bundle manifest identity mismatch" in text
    assert 'destination.open("xb", buffering=0)' in text
    assert "new physical input copy identity mismatch" in text
    assert '"file_count": 11' in text
    assert '"heldout_2024_target_bytes_read": 0' in text
    assert '"boundary_target_bytes_read": 0' in text
    assert '"run", "inputs", "runs", "logs", "jobs", "evidence"' in text


def test_powershell_builder_parses_without_execution():
    executable = shutil.which("powershell") or shutil.which("pwsh")
    if executable is None:
        pytest.skip("PowerShell parser is unavailable")
    command = (
        "$errors=$null; "
        f"[System.Management.Automation.Language.Parser]::ParseFile('{BUILDER}',"
        "[ref]$null,[ref]$errors) | Out-Null; "
        "if ($errors.Count -ne 0) { $errors | ForEach-Object { $_.Message }; exit 1 }"
    )
    subprocess.run(
        [executable, "-NoProfile", "-Command", command],
        check=True,
        cwd=ROOT,
        capture_output=True,
        text=True,
    )


@pytest.mark.parametrize(
    "path",
    [UPSTREAM_SLURM, FILTER_SLURM, EVALUATION_SLURM],
)
def test_slurm_shell_syntax_when_bash_is_available(path):
    executable = shutil.which("bash")
    if executable is None:
        pytest.skip("Bash parser is unavailable")
    probe = subprocess.run(
        [executable, "--version"], capture_output=True, check=False
    )
    if probe.returncode != 0:
        pytest.skip("Bash command is an unavailable Windows subsystem stub")
    subprocess.run(
        [executable, "-n"],
        input=path.read_bytes(),
        check=True,
        cwd=ROOT,
        capture_output=True,
    )
