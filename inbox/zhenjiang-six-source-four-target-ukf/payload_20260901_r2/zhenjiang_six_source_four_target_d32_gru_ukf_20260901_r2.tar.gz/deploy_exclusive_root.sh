#!/usr/bin/env bash
set -eo pipefail

ROOT="/data1/home/sunyiq/zhenjiang_six_source_four_target_differentiable_ukf_20260901_r2"
STAGING="${ROOT}.staging"
PARTIAL="${ROOT}.partial"
SOURCE_INPUT="/data1/home/sunyiq/zhenjiang_d32_differentiable_ukf_20260828_r2/inputs/pre2024-v1"
DESTINATION_INPUT="${STAGING}/inputs/pre2024-four-target-v1"
PAYLOAD_ROOT="${1:?usage: deploy_exclusive_root.sh /absolute/extracted_bundle}"

fatal() {
  echo "[FATAL] $1"
  exit 1
}

case "${PAYLOAD_ROOT}" in
  /*) ;;
  *) fatal "payload root must be absolute" ;;
esac
[ -d "${PAYLOAD_ROOT}/run" ] || fatal "payload run tree is absent"
[ -f "${PAYLOAD_ROOT}/bundle_manifest.json" ] || fatal "bundle manifest is absent"
[ -f "${PAYLOAD_ROOT}/deploy_exclusive_root.sh" ] || fatal "deploy script identity is absent"
for candidate in "${ROOT}" "${PARTIAL}" "${STAGING}"; do
  [ ! -e "${candidate}" ] || fatal "exclusive destination already exists: ${candidate}"
done
[ -d "${SOURCE_INPUT}" ] || fatal "read-only source input root is absent"

mkdir "${STAGING}"
cp -a "${PAYLOAD_ROOT}/run" "${STAGING}/run"
if [ -n "$(find "${STAGING}/run" -type l -print -quit)" ]; then
  fatal "payload contains a symbolic link"
fi
mkdir -p "${DESTINATION_INPUT}" "${STAGING}/runs" "${STAGING}/logs" "${STAGING}/jobs" "${STAGING}/evidence"
cp "${PAYLOAD_ROOT}/deploy_exclusive_root.sh" "${STAGING}/jobs/deploy_exclusive_root.sh"
cp "${PAYLOAD_ROOT}/bundle_manifest.json" "${STAGING}/jobs/bundle_manifest.json"
chmod 0555 "${STAGING}/jobs/deploy_exclusive_root.sh"
chmod 0444 "${STAGING}/jobs/bundle_manifest.json"

python - "${PAYLOAD_ROOT}" "${STAGING}" "${SOURCE_INPUT}" "${DESTINATION_INPUT}" <<'PY'
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import sys

payload = Path(sys.argv[1]).resolve(strict=True)
staging = Path(sys.argv[2]).resolve(strict=True)
source_root = Path(sys.argv[3]).resolve(strict=True)
destination_root = Path(sys.argv[4]).resolve(strict=True)
manifest = json.loads((payload / "bundle_manifest.json").read_text(encoding="utf-8"))
if (
    (staging / "jobs/bundle_manifest.json").read_bytes()
    != (payload / "bundle_manifest.json").read_bytes()
):
    raise SystemExit("retained bundle manifest identity mismatch")
registry_path = staging / "run" / manifest["registry_path"]
registry = json.loads(registry_path.read_text(encoding="utf-8"))
if (
    manifest.get("heldout_2024_target_access_authorized") is not False
    or registry["authorization"]["heldout_2024_target_access_authorized"] is not False
    or registry["hpc"]["source_input_root_read_only"] != str(source_root)
    or registry["hpc"]["isolated_input_root"]
    != "/data1/home/sunyiq/zhenjiang_six_source_four_target_differentiable_ukf_20260901_r2/inputs/pre2024-four-target-v1"
):
    raise SystemExit("bundle or input authorization changed")

expected_payload = {
    row["path"]: (row["byte_count"], row["sha256"])
    for row in manifest["source_files"]
}
actual_payload = {
    path.relative_to(staging / "run").as_posix(): path
    for path in (staging / "run").rglob("*")
    if path.is_file()
}
if set(actual_payload) != set(expected_payload):
    raise SystemExit("deployed run tree differs from exact bundle membership")
for relative, path in actual_payload.items():
    payload_bytes = path.read_bytes()
    expected_bytes, expected_sha = expected_payload[relative]
    if len(payload_bytes) != expected_bytes or hashlib.sha256(payload_bytes).hexdigest() != expected_sha:
        raise SystemExit("deployed payload identity mismatch: " + relative)

rows = registry.get("input_files")
if not isinstance(rows, list) or len(rows) != 11:
    raise SystemExit("registry does not contain exactly eleven input rows")
target_paths = {
    row["path"] for row in rows if row["path"].startswith("retrospective_targets/")
}
expected_targets = {
    "retrospective_targets/nanjing_retrospective_targets.csv",
    "retrospective_targets/zhenjiang_retrospective_targets.csv",
    "retrospective_targets/jiangyin_retrospective_targets.csv",
    "retrospective_targets/xuliujing_retrospective_targets.csv",
}
if target_paths != expected_targets:
    raise SystemExit("input target set contains a boundary or misses an internal target")

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb", buffering=0) as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

copied = []
for row in rows:
    relative = Path(row["path"])
    if relative.is_absolute() or ".." in relative.parts or "boundary" in relative.as_posix().lower():
        raise SystemExit("unsafe input relative path")
    source = source_root / relative
    destination = destination_root / relative
    resolved_source = source.resolve(strict=True)
    try:
        resolved_source.relative_to(source_root)
    except ValueError as error:
        raise SystemExit("source input escaped its read-only root") from error
    if source.is_symlink() or resolved_source != source or not source.is_file():
        raise SystemExit("source input is not one physical regular file: " + row["path"])
    if source.stat().st_size != row["byte_count"] or sha256(source) != row["sha256"]:
        raise SystemExit("source input identity changed: " + row["path"])
    destination.parent.mkdir(parents=True, exist_ok=True)
    with source.open("rb", buffering=0) as source_handle, destination.open("xb", buffering=0) as destination_handle:
        shutil.copyfileobj(source_handle, destination_handle, length=1024 * 1024)
        destination_handle.flush()
        os.fsync(destination_handle.fileno())
    if destination.is_symlink() or destination.stat().st_size != row["byte_count"] or sha256(destination) != row["sha256"]:
        raise SystemExit("new physical input copy identity mismatch: " + row["path"])
    destination.chmod(stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)
    copied.append({
        "path": row["path"],
        "verification_scope": row["verification_scope"],
        "byte_count": row["byte_count"],
        "sha256": row["sha256"],
    })

input_manifest = {
    "schema_version": 1,
    "source_root_read_only": str(source_root),
    "destination_root": "/data1/home/sunyiq/zhenjiang_six_source_four_target_differentiable_ukf_20260901_r2/inputs/pre2024-four-target-v1",
    "file_count": 11,
    "files": copied,
    "later_than_2023_bytes_read": 0,
    "heldout_2024_target_bytes_read": 0,
    "boundary_target_bytes_read": 0,
    "copy_method": "new_physical_regular_files_no_links",
}
(destination_root / "four_target_input_manifest.json").write_text(
    json.dumps(input_manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
top = {path.name for path in staging.iterdir()}
if top != {"run", "inputs", "runs", "logs", "jobs", "evidence"}:
    raise SystemExit("staging top-level directory set differs from the frozen allow-list")
PY

chmod -R a-w "${STAGING}/run" "${DESTINATION_INPUT}"
for candidate in "${ROOT}" "${PARTIAL}"; do
  [ ! -e "${candidate}" ] || fatal "exclusive destination appeared during staging: ${candidate}"
done
mv "${STAGING}" "${ROOT}"
echo "[DONE] exclusive root published: ${ROOT}"
echo "[DONE] copied exactly eleven registered 2017-2023 files; 2024 and boundary targets were not copied"
