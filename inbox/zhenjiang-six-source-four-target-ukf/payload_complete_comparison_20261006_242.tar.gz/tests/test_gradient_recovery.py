import copy
import os
import pytest
import torch
from src.contracts import CASES,Whitening,combine_batches
from src.models import make_parts,parameters
from src.state_estimators import make_branches,configure_branch
from src.differentiable_filter import make_noise
from src.training import train_effective_batch,_train_effective_batch_original,make_optimizer

@pytest.mark.parametrize('family,capacity,w,d',CASES)
@pytest.mark.parametrize('method',['foundation','encoder_fixed','encoder_joint','filter_fixed','filter_joint'])
def test_ordinary_path_model_gradient_and_adam_unchanged(family,capacity,w,d,method,batch,stats):
    a=make_parts(family,capacity,17);noise=None
    wh=Whitening(torch.zeros(d,dtype=torch.float64),torch.ones(d,dtype=torch.float64))
    if method!='foundation':
        a=make_branches(a,100017)[method];noise=make_noise(d) if method.startswith('filter') else None
        configure_branch(a,noise,method)
    b=copy.deepcopy(a);noise_b=copy.deepcopy(noise)
    if os.environ.get('ZHENJIANG_TEST_DEVICE')=='cuda':
        from src.execution import move_parts,move_batch
        wh=move_parts(a,noise,wh,'cuda:0');move_parts(b,noise_b,None,'cuda:0');batch=move_batch(batch,'cuda:0')
    oa=make_optimizer(a,noise,.003);ob=make_optimizer(b,noise_b,.003)
    batch=combine_batches([batch]*2)
    original=_train_effective_batch_original(a,noise,wh,method,batch,stats,oa,2)
    actual=train_effective_batch(b,noise_b,wh,method,batch,stats,ob,2)
    assert original==actual
    for x,y in zip(parameters(a,noise),parameters(b,noise_b)):
        assert torch.equal(x,y)
        assert (x.grad is None and y.grad is None) or torch.equal(x.grad,y.grad)
    assert oa.param_groups[0]['lr']==ob.param_groups[0]['lr']
    for sa,sb in zip(oa.state.values(),ob.state.values()):
        assert sa.keys()==sb.keys()
        for k in sa:assert torch.equal(sa[k],sb[k])

def test_missing_gradient_is_not_repaired(monkeypatch,batch,stats):
    from src.gradient_recovery import retry_overflow,rng_state
    p=make_parts('explicit_gru','small',17);optimizer=make_optimizer(p,None,.003)
    with pytest.raises(FloatingPointError,match='missing gradient cannot'):
        retry_overflow(p,None,None,'foundation',batch,stats,optimizer,2,rng_state())
