import numpy as np
import pytest
import torch
import json
import os
from pathlib import Path
from src.contracts import TrainingStats
from src.data_contract import build_physical_window
from src.normalization import normalize_window

torch.set_num_threads(1)
torch.use_deterministic_algorithms(True)
torch.backends.mkldnn.enabled=False
torch.backends.cuda.matmul.allow_tf32=False
torch.backends.cudnn.allow_tf32=False

SYNTHETIC_STEPS=0
DEVICE_EVIDENCE=[]
def pytest_sessionstart(session):
    original=torch.optim.Adam.step
    def counted(self,*args,**kwargs):
        global SYNTHETIC_STEPS
        result=original(self,*args,**kwargs)
        SYNTHETIC_STEPS+=1
        return result
    torch.optim.Adam.step=counted

def pytest_sessionfinish(session,exitstatus):
    path=os.environ.get('ZHENJIANG_ACCEPTANCE_RECEIPT')
    if path:
        Path(path).write_text(json.dumps({'exit_status':exitstatus,'tests_collected':session.testscollected,
            'synthetic_optimizer_steps':SYNTHETIC_STEPS,'formal_training_steps':0,'real_data_optimizer_steps':0,
            'raw_evaluation_year_reads':0,'paid_submissions':0,'scientific_result':False,
            'actual_gpu_checks':DEVICE_EVIDENCE},indent=2)+'\n',encoding='utf-8')

@pytest.fixture
def device_evidence():
    return DEVICE_EVIDENCE

@pytest.fixture
def stats():
    return TrainingStats(np.arange(1.,8.),np.arange(2.,9.),np.array([7.,5.,-1.]),
                         np.array([8.,6.,2.]),np.arange(1.,5.),np.arange(2.,6.),
                         np.arange(10.,14.),(2020,),'a'*64)

@pytest.fixture
def physical():
    rng=np.random.default_rng(71)
    values=rng.normal(size=(71,7))*.8+np.arange(1.,8.)
    times=np.datetime64('2020-06-01T00')+np.arange(71)*np.timedelta64(1,'h')
    return build_physical_window(values[:48],times[:48],values[24:,6],values[24:,:4])

@pytest.fixture
def batch(physical,stats):
    return normalize_window(physical,stats)
