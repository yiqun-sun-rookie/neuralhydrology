"""Reject an allocated GPU if any frozen resumed member has a different device."""
import json,pathlib,sys,os
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from src.execution import device_identity
from src.scheduler import code_identity
case='explicit_gru__historical_capacity';actual=device_identity('cuda:0')
configs=json.loads((ROOT/'records'/case/'tune_branch_group_configs.json').read_text())
assert len(configs)==12 and all(c['effective_config']['device_identity']==actual and c['effective_config']['code_hash']==code_identity() for c in configs.values())
record={'status':'replacement_gpu_matches_all_frozen_members','device_identity':actual,'members':12,'job_id':os.environ.get('SLURM_JOB_ID'),'node':os.environ.get('SLURMD_NODENAME'),'code_hash':code_identity(),'evaluation_values_read':False}
with (ROOT/'records'/('gpu_binding_'+record['job_id']+'.json')).open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record),flush=True)
