"""Authenticate all twelve failed-group continuations in an isolated release.
Preserve source failures, completed parent group, complete histories and Adam.
Only the implementation/configuration binding changes. No raw data is opened.
"""
import copy,hashlib,json,pathlib,shutil,subprocess,sys
import torch
ROOT=pathlib.Path(__file__).resolve().parents[1]
PARENT=pathlib.Path('/data1/home/sunyiq/zhenjiang_complete_comparison_20261006_recovery_001')
CASE='explicit_gru__historical_capacity'
OLD_CODE='3b9b490021ac5f4893548822894540d81b5d9c125a57f0aff843cae21bc7b68b'
sys.path.insert(0,str(ROOT))
from src.scheduler import code_identity,seal_group,digest_json,verify_parent_binding
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(v,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
def state_hash(v):
    h=hashlib.sha256()
    def visit(x):
        if isinstance(x,torch.Tensor):
            x=x.detach().cpu().contiguous();h.update(str((str(x.dtype),tuple(x.shape))).encode());h.update(x.reshape(-1).view(torch.uint8).numpy().tobytes())
        elif isinstance(x,dict):
            for k in sorted(x,key=repr):h.update(repr(k).encode());visit(x[k])
        elif isinstance(x,(list,tuple)):
            h.update(str(len(x)).encode())
            for y in x:visit(y)
        else:h.update(json.dumps(x,sort_keys=True,allow_nan=False).encode())
    visit(v);return h.hexdigest()
def finite(v):
    if isinstance(v,torch.Tensor):assert torch.isfinite(v).all(),'nonfinite source state'
    elif isinstance(v,dict):
        for x in v.values():finite(x)
    elif isinstance(v,(list,tuple)):
        for x in v:finite(x)
def main():
    job=str(read(PARENT/'records/scheduler_jobs.json')[CASE])
    q=subprocess.run(['squeue','-h','-u','sunyiq','-o','%i|%j|%T'],capture_output=True,text=True,check=True)
    assert not any(l.split('|')[0]==job for l in q.stdout.splitlines()),'source active'
    a=subprocess.run(['sacct','-n','-X','-j',job,'--format=JobID,State,ExitCode','-P'],capture_output=True,text=True,check=True)
    assert job+'|FAILED|1:0' in a.stdout,'source failure unconfirmed'
    assert code_identity(PARENT)==OLD_CODE
    new=code_identity();auth=read(ROOT/'records/authorization.json');assert auth['code_hash']==new
    for name in ['protocol-v3.json','registry-v3.json']:
        assert (ROOT/'configs'/name).read_bytes()==(PARENT/'configs'/name).read_bytes(),'scientific config changed'
    assert not (PARENT/'records'/CASE/'tune_branch_group_outcome.json').exists(),'branch completed; reuse instead'
    outcome_path=PARENT/'records'/CASE/'tune_foundation_group_outcome.json';outcome=read(outcome_path)
    seal=seal_group(CASE+'__tune_foundation_group__seal',outcome['members'],400,expected_members=list(outcome['members']))
    from dataclasses import asdict
    assert asdict(seal)==dict(outcome['seal'],member_ids=tuple(outcome['seal']['member_ids']))
    for member in outcome['members'].values():
        assert sha(pathlib.Path(member['checkpoint_path']))==member['checkpoint_sha256']
        assert len(member['validation_mae'])==400 and member['epochs']==400
    dest=ROOT/'records'/CASE;dest.mkdir()
    shutil.copyfile(outcome_path,dest/'tune_foundation_group_outcome.json')
    # Preserve original completed-group provenance and parent checkpoint paths.
    write(ROOT/'records/completed_group_reuse.json',{'source':str(outcome_path),'sha256':sha(outcome_path),'members':list(outcome['members']),'epochs':400,'retrained':False,'parent_checkpoint_paths_preserved':True})
    for split in ['tuning','final']:
        p=ROOT/'prepared'/split/'manifest.json';p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(PARENT/'prepared'/split/'manifest.json',p)
    prep=read(PARENT/'records/data_preparation_complete.json');assert prep['status']=='admitted' and prep['code_hash']==OLD_CODE
    shutil.copyfile(PARENT/'records/data_preparation_complete.json',ROOT/'records/parent_data_preparation_complete.json')
    prep['code_hash']=new;prep['recovery_reauthentication']={'source_root':str(PARENT),'source_record_sha256':sha(PARENT/'records/data_preparation_complete.json'),'unchanged_manifests':True,'no_data_or_tide_refit':True}
    write(ROOT/'records/data_preparation_complete.json',prep)
    configs=read(PARENT/'records'/CASE/'tune_branch_group_configs.json');assert len(configs)==12
    registered=read(ROOT/'configs/registry-v3.json')['runs'];expected={r['exp_id'] for r in registered if r['budget_group']==CASE+'__tune_branch_group' and r['status']!='alias'}
    assert set(configs)==expected
    migrations=[]
    for run,config in configs.items():
        source=PARENT/'runs'/run;target=ROOT/'runs'/run
        assert read(source/'config.json')==config and config['effective_config']['code_hash']==OLD_CODE
        failure=read(source/'failure.json');assert failure['reason']=='missing or nonfinite trainable gradient' and failure['status']=='failed'
        verify_parent_binding(config['registration'],config['effective_config'],{seal.group_id:seal})
        source_ids={n:sha(source/n) for n in ['config.json','continuation.pt','metrics.json','failure.json']}
        state=torch.load(source/'continuation.pt',map_location='cpu',weights_only=True);finite(state)
        assert state['config_sha256']==source_ids['config.json']
        metric=read(source/'metrics.json');epochs=len(state['values'])
        assert epochs==failure['epochs_completed'] and epochs in [40,41]
        assert all(len(state[k])==epochs for k in ['values','train_metrics','shuffle_hashes'])
        assert state['values']==metric['validation_mae_cm'] and state['train_metrics']==metric['train_metrics'] and state['shuffle_hashes']==metric['shuffle_hashes']
        before=state_hash({k:v for k,v in state.items() if k!='config_sha256'})
        target.mkdir();config['effective_config']['code_hash']=new;write(target/'config.json',config)
        state['config_sha256']=sha(target/'config.json')
        with (target/'continuation.pt').open('xb') as f:torch.save(state,f)
        check=torch.load(target/'continuation.pt',map_location='cpu',weights_only=True)
        assert state_hash({k:v for k,v in check.items() if k!='config_sha256'})==before
        shutil.copyfile(source/'metrics.json',target/'metrics.json')
        write(target/'recovery_from_failure.json',{'source_root':str(PARENT),'source_failure':str(source/'failure.json'),'source_files':source_ids,'source_code':OLD_CODE,'recovery_code':new,'source_failure_retained':True,'technical_reason':'validated conditional backward rescaling for float32 representational overflow'})
        assert all(sha(source/n)==h for n,h in source_ids.items())
        migrations.append({'run':run,'epochs_preserved':epochs,'source_files':source_ids,'source_root':str(PARENT),'training_state_semantic_sha256':before,'recovery_config_sha256':state['config_sha256'],'recovery_checkpoint_sha256':sha(target/'continuation.pt'),'only_checkpoint_metadata_change':'config_sha256'})
    assert sorted(m['epochs_preserved'] for m in migrations)==[40]+[41]*11
    write(dest/'tune_branch_group_configs.json',configs)
    write(ROOT/'records/recovery_preparation_complete.json',{'status':'authenticated_continuation_prepared','case':CASE,'source_job':job,'parent_root':str(PARENT),'parent_code_hash':OLD_CODE,'recovery_code_hash':new,'migrations':migrations,'scientific_protocol_unchanged':True,'old_failure_and_checkpoints_preserved':True,'completed_foundation_group_reused':True,'evaluation_values_read':False})
    print(json.dumps({'status':'authenticated_continuation_prepared','epochs':[m['epochs_preserved'] for m in migrations],'code_hash':new}),flush=True)
if __name__=='__main__':main()
