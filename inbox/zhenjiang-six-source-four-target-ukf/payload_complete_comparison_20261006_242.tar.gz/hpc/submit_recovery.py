"""Submit the uniquely authenticated failed-case continuation via school xbatch."""
import hashlib,json,pathlib,re,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]
CASE='explicit_gru__historical_capacity'
def main():
    prep=json.loads((ROOT/'records/recovery_preparation_complete.json').read_text())
    assert prep['status']=='authenticated_continuation_prepared' and prep['case']==CASE
    q=subprocess.run(['squeue','-h','-u','sunyiq','-o','%i|%j|%T'],capture_output=True,text=True,check=True)
    name='zj_gru_gradient_recovery_261012_003'
    assert not any(row.split('|')[0]==str(prep['source_job']) or row.split('|')[1]==name for row in q.stdout.splitlines())
    source=pathlib.Path('/data1/home/sunyiq/zhenjiang_complete_comparison_20261006_002/hpc/pathfix_explicit_gru__historical_capacity.slurm')
    raw=source.read_bytes();assert hashlib.sha256(raw).hexdigest()=='73cd8f3816acaade159a070acc081743e05bf988a267d63cc8ff45f25084f469'
    lines=[]
    for line in raw.decode().splitlines():
        if line.startswith('#SBATCH --job-name='):line='#SBATCH --job-name='+name
        elif line.startswith('#SBATCH --dependency='):continue
        elif line.startswith('#SBATCH --exclude='):line='#SBATCH --exclude=ngu002,ngu011'
        elif line.startswith('#SBATCH --output='):line='#SBATCH --output='+str(ROOT/'logs/%x_%j.out')
        elif line.startswith('cd '):line='cd '+str(ROOT)
        elif line.startswith('python -B -u scripts/train_supercomputer_case.py'):
            lines+=['python -B -u hpc/check_gpu_binding.py','ZHENJIANG_TEST_DEVICE=cuda ZHENJIANG_ACCEPTANCE_RECEIPT="records/gpu_acceptance_${SLURM_JOB_ID}.json" python -B -m pytest tests/test_gradient_recovery.py tests/test_training.py tests/test_numerical_recovery.py -q -p no:cacheprovider']
        lines.append(line)
    if not any(l.startswith('#SBATCH --exclude=') for l in lines):lines.insert(2,'#SBATCH --exclude=ngu002,ngu011')
    assert '#SBATCH -p hgpu2p' in lines and '#SBATCH --gres=gpu:1' in lines and '#SBATCH --cpus-per-task=4' in lines
    assert lines.index('conda activate nh_final')<lines.index('set -u')
    assert [l for l in lines if l.startswith('cd ')]==['cd '+str(ROOT)]
    assert [l for l in lines if l.startswith('#SBATCH --output=')]==['#SBATCH --output='+str(ROOT/'logs/%x_%j.out')]
    assert 'case_name="'+CASE+'"' in lines
    assert 'python -B -u scripts/train_supercomputer_case.py --case "$case_name"' in lines
    script=ROOT/'hpc/pathfix_gradient_recovery_003.slurm'
    with script.open('x') as f:f.write('\n'.join(lines)+'\n')
    record={'status':'reserved','script':str(script),'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'source_pathfix_sha256':hashlib.sha256(raw).hexdigest(),'source_job':prep['source_job'],'case':CASE,'source_failure_retained':True,'scientific_rules_changed':False,'squeue_before':q.stdout}
    with (ROOT/'records/recovery_submission_attempt.json').open('x') as f:json.dump(record,f,indent=2)
    r=subprocess.run(['/usr/local/globle/softs/slurm/19.05.4.1/bin/xbatch',str(script)],capture_output=True,text=True,timeout=45)
    response={'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
    with (ROOT/'records/recovery_submission_response.json').open('x') as f:json.dump(response,f,indent=2)
    m=re.fullmatch(r'Submitted batch job ([0-9]+)\s*',r.stdout)
    if r.returncode or not m:raise RuntimeError('submission uncertain; read receipt and scheduler; never blind retry')
    with (ROOT/'records/scheduler_jobs.json').open('x') as f:json.dump({CASE:m.group(1)},f,indent=2)
    print(json.dumps({'status':'authenticated_gradient_continuation_submitted','case':CASE,'job_id':m.group(1),'root':str(ROOT),'formal_progress_confirmed':False}),flush=True)
if __name__=='__main__':main()
