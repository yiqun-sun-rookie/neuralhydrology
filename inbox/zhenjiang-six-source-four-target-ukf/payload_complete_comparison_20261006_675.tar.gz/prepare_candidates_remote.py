"""Prepare inactive 003 candidates from preserved CPU checkpoints; no training.

Executed only inside the new candidate root after a hash-verified package
extraction. Original source roots and jobs are never written or stopped.
"""
import copy
import datetime
import gc
import hashlib
import importlib
import importlib.util
import json
from pathlib import Path
import sys

import torch

ROOT=Path(__file__).resolve().parent
RELEASE=ROOT/'release'
ARCHIVE=Path('/data1/home/sunyiq/zhenjiang_fixed200_003_sources_20261019_001')
preserved=json.loads((ARCHIVE/'preservation_report.json').read_bytes())
expected=json.loads((ROOT/'expected_original_code.json').read_bytes())
spec=importlib.util.spec_from_file_location('migration_tool',RELEASE/'tools/checkpoint_migration.py')
tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool);io=tool.checkpoint_io
CASE_VARIANT={'explicit_gru__small':'base','legacy_lstm__historical_capacity':'base',
              'legacy_lstm__small':'small_lstm_recovery','explicit_gru__historical_capacity':'sqrt_gru_recovery'}

def sha(raw):return hashlib.sha256(raw).hexdigest()
def copy_new(source,target):
    raw=io.read_stable(source);target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as handle:handle.write(raw)
    return {'source':str(source),'preserved':str(target),'bytes':len(raw),'sha256':sha(raw)}

report={'schema':'fixed200-inactive-candidates-v1','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'candidate_root':str(ROOT),'source_archive':str(ARCHIVE),'activated':False,'training_steps':0,
        'source_writes':False,'old_jobs_modified':False,'previous_attempt_receipt':673,'cases':{},'foundation_sources':[]}

# The original completed400 catalogue, outcomes and selected weights are verified
# without recomputing an epoch or changing their original identity.
catalogue=json.loads((RELEASE/'stage_source_admission.json').read_bytes())
for group,source in catalogue['sources'].items():
    row={'group':group,'members':[]}
    try:
        outcome_path=Path(source['outcome_sample_root'])/source['original_outcome_path']
        raw=io.read_stable(outcome_path)
        assert sha(raw)==source['original_outcome_sha256'],'original400 outcome hash differs'
        outcome=json.loads(raw);assert outcome['seal']==source['seal']
        row['outcome']=copy_new(outcome_path,ROOT/'foundation_sources'/group/'original_outcome.json')
        for rid,member in source['seal']['member_evidence'].items():
            path=Path(member['checkpoint_path'])
            assert sha(io.read_stable(path))==member['checkpoint_sha256'],'original400 best hash differs'
            assert member['epochs']==len(member['validation_mae'])==400
            entry=copy_new(path,ROOT/'foundation_sources'/group/rid/'best.pt')
            entry.update(run_id=rid,epochs=400,original_best_epoch=member['best_epoch'])
            for name in ('config.json','whitening.json'):
                if (path.parent/name).exists():copy_new(path.parent/name,ROOT/'foundation_sources'/group/rid/name)
            row['members'].append(entry)
        row['verified_original_400']=True
    except Exception as error:row['error']=type(error).__name__+': '+str(error)
    report['foundation_sources'].append(row)

for case,rows in preserved['cases'].items():
    variant=CASE_VARIANT[case];runtime=RELEASE/'runtimes'/variant
    registry=json.loads((runtime/'configs/registry-v3.json').read_bytes())
    target_runs={r['exp_id']:r for r in registry['runs'] if r['case']==case and r['type']=='tune_branch' and r['status']!='alias'}
    protocol_raw=(runtime/'configs/protocol-v3.json').read_bytes();protocol=json.loads(protocol_raw)
    case_record={'variant':variant,'members':[],'source_code_verified':False,'group_ready':False}
    report['cases'][case]=case_record
    try:
        source_config=json.loads((ARCHIVE/case/rows[0]['run_id']/'config.json').read_bytes())
        original_root=Path(rows[0]['files']['config.json']['source']).parents[2]
        source_files={}
        for relative,wanted in expected[variant]['files'].items():
            path=original_root/relative
            raw=io.read_stable(path)
            assert sha(raw)==wanted,'original source implementation differs: '+relative
            destination=ROOT/'verified_original_code'/case/relative
            copy_new(path,destination);source_files[relative]=sha(raw)
        assert io.digest_json(source_files)==source_config['effective_config']['code_hash'],'source code identity differs'
        case_record['source_code_verified']=True;case_record['source_code_hash']=io.digest_json(source_files)
        # Import target CPU construction only to check exact named tensors and
        # Adam group/parameter order against the authenticated original code.
        for key in list(sys.modules):
            if key=='src' or key.startswith('src.'):del sys.modules[key]
        sys.path.insert(0,str(runtime))
        training=importlib.import_module('src.training');models=importlib.import_module('src.models')
        estimators=importlib.import_module('src.state_estimators');filters=importlib.import_module('src.differentiable_filter')
        for member in rows:
            rid=member['run_id'];folder=ARCHIVE/case/rid;item={'run_id':rid,'source_completed_epochs':member['completed_epochs']}
            case_record['members'].append(item)
            try:
                for name,entry in member['files'].items():
                    assert sha(io.read_stable(folder/name))==entry['sha256'],'preserved source bytes differ'
                source_config_raw=io.read_stable(folder/'config.json');source=json.loads(source_config_raw)
                assert source['effective_config']['code_hash']==case_record['source_code_hash']
                if (member['completed_epochs']>200 and not member['inline_best_matches_first200']
                        and member['first200_best_epoch']!=200):
                    raise ValueError('true first200 best weights or historical complete state required')
                family,capacity=case.split('__');method=source['effective_config']['method'];seed=source['effective_config']['seed']
                parts=models.make_parts(family,capacity,seed);parts=estimators.make_branches(parts,seed+100000)[method]
                noise=filters.make_noise(parts.state_dim) if method.startswith('filter') else None
                estimators.configure_branch(parts,noise,method)
                optimizer=training.make_optimizer(parts,noise,source['effective_config']['learning_rate'])
                expected_state=training.snapshot_parts(parts,noise)
                target=copy.deepcopy(source);target['registration']=target_runs[rid]
                target['protocol_sha256']=sha(protocol_raw)
                effective=target['effective_config'];effective['code_hash']=io.runtime_code_hash(runtime)
                assert effective['data_contract']==protocol['data'],'data contract differs'
                effective['training_contract']=protocol['training'];effective['budget_policy_hash']=io.digest_json(protocol['training'])
                destination=ROOT/'candidates'/variant/'runs'/rid
                if member['completed_epochs']<=200:
                    receipt=tool.prepare_candidate(folder,target,destination,expected_current=expected_state,optimizer=optimizer);item['member_kind']='continuation'
                else:
                    receipt=tool.prepare_result(folder,target,destination,expected_current=expected_state,optimizer=optimizer);item['member_kind']='completed_prefix_result'
                item['named_tensor_and_adam_layout_verified']=True
                item.update(status='prepared_not_activated',candidate_dir=str(destination),
                    receipt_sha256=sha((destination/'migration_source.json').read_bytes()),
                    source_code_transition_reviewed='original implementation exact; numerical and optimizer functions unchanged')
                del parts,optimizer,noise,expected_state;gc.collect()
            except Exception as error:
                item.update(status='blocked',reason=type(error).__name__+': '+str(error))
        sys.path.remove(str(runtime))
        if len(case_record['members'])==len(target_runs) and all(r['status']=='prepared_not_activated' for r in case_record['members']):
            bindings=io.migration_bindings(runtime,case,ROOT/'candidates'/variant/'runs')
            manifest=ROOT/'candidates'/variant/(case+'_migration_manifest.json')
            manifest.write_text(json.dumps(bindings,sort_keys=True,indent=2)+'\n')
            case_record.update(group_ready=True,migration_manifest=str(manifest),migration_manifest_digest=io.digest_json(bindings),
                pending_before_activation=['fresh single-writer transfer boundary','admitted data and exact regenerated configuration','activation decision'])
    except Exception as error:
        case_record['error']=type(error).__name__+': '+str(error)

report['summary']={'source_members':sum(len(x) for x in preserved['cases'].values()),
    'candidate_members':sum(r.get('status')=='prepared_not_activated' for c in report['cases'].values() for r in c['members']),
    'blocked_members':sum(r.get('status')=='blocked' for c in report['cases'].values() for r in c['members']),
    'ready_cases':[k for k,c in report['cases'].items() if c['group_ready']],
    'case_errors':{k:c['error'] for k,c in report['cases'].items() if c.get('error')},
    'verified_original400_members':sum(len(s['members']) for s in report['foundation_sources'] if s.get('verified_original_400'))}
report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
raw=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode();(ROOT/'candidate_report.json').write_bytes(raw)
print(json.dumps(report,sort_keys=True))
print(json.dumps({'candidate_report_sha256':sha(raw),'root':str(ROOT)}))
