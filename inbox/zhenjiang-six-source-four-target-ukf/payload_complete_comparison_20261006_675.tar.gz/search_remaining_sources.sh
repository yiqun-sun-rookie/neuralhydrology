#!/usr/bin/env bash
set -euo pipefail
python3 - <<'SEARCH_003'
import datetime,json,os,pathlib
archive=pathlib.Path('/data1/home/sunyiq/zhenjiang_fixed200_003_sources_20261019_001')
candidate=pathlib.Path('/data1/home/sunyiq/zhenjiang_fixed200_003_candidates_20261019_002')
preserved=json.loads((archive/'preservation_report.json').read_text())
result=json.loads((candidate/'candidate_report.json').read_text())
blocked=[m['run_id'] for c in result['cases'].values() for m in c['members'] if m.get('status')=='blocked']
found=[];bundles=[]
for root_name in preserved['bounded_archive_search']['roots']:
 for folder,dirs,files in os.walk(root_name):
  dirs[:]=[d for d in dirs if d not in ('data','prepared','logs','.git','__pycache__','vendor','third_party')]
  for name in files:
   path=pathlib.Path(folder)/name
   if name.endswith(('.tar.gz','.tgz','.zip')):bundles.append(str(path))
   if name.endswith(('.pt','.pth')) and any(rid in str(path) for rid in blocked):
    stat=path.stat();found.append({'path':str(path),'bytes':stat.st_size,'mtime_ns':stat.st_mtime_ns})
flags={}
for variant in ('base','small_lstm_recovery','sqrt_gru_recovery'):
 protocol=json.loads((candidate/'release/runtimes'/variant/'configs/protocol-v3.json').read_text())
 flags[variant]=protocol['authority']
print(json.dumps({'schema':'fixed200-remaining-source-search-v1','checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'all pt/pth and compressed bundles under the nine known comparison/recovery roots, excluding data/prepared/logs/vendor',
 'source_writes':False,'blocked_members':blocked,'weight_or_state_files':found,'compressed_bundles':bundles,
 'staged_authority_flags':flags,'candidate_summary':result['summary']},sort_keys=True))
SEARCH_003
