"""CPU-only checkpoint inspection and inactive candidate preparation.

Inputs: explicit local run/config paths. Outputs: JSON report, or a NEW candidate
directory with preserved source bytes and identity bindings. Never trains,
evaluates, imports src.runtime, creates authority, or seals scientific results.

Examples:
  python tools/checkpoint_migration.py inspect --run-dir /saved/run
  python tools/checkpoint_migration.py prepare-candidate --run-dir /saved/run \
      --target-config /resolved/config.json --destination /new/candidates/run
  python tools/checkpoint_migration.py export-best --run-dir /saved/run \
      --destination /new/weights_candidate
  python tools/checkpoint_migration.py bindings --run-dir /new/candidates/runs \
      --runtime-root runtimes/base --case explicit_gru__small
"""
import argparse
import copy
import importlib.util
import io
import json
from pathlib import Path
import pickle
import tempfile

import torch

RELEASE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('checkpoint_io', RELEASE / 'runtimes/base/src/continuation.py')
checkpoint_io = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checkpoint_io)


def _changes(old, new, prefix=''):
    if isinstance(old, dict) and isinstance(new, dict):
        result = []
        for key in sorted(old.keys() | new.keys()):
            path = prefix + key
            if key not in old or key not in new:
                result.append(path)
            else:
                result.extend(_changes(old[key], new[key], path + '.'))
        return result
    return [] if old == new else [prefix.rstrip('.')]


def check_config_transition(source, target):
    """Reject scientific changes; report every permitted identity/budget change."""
    for config in (source, target):
        registration, effective = config.get('registration', {}), config.get('effective_config')
        required = {'case', 'method', 'seed', 'learning_rate', 'parent_hash',
                    'initializer_hash', 'analysis_initialization_hash', 'training_data_hash',
                    'normalization_hash', 'whitening_hash', 'tide_source_hash', 'code_hash',
                    'shuffle_hash', 'training_contract', 'data_contract', 'optimizer'}
        if (config.get('status') != 'frozen_authorized' or registration.get('type') != 'tune_branch'
                or not isinstance(effective, dict) or not required.issubset(effective)):
            raise ValueError('resolved tuning-branch config required; foundation/final migration forbidden')
        if any(registration.get(k) != effective[k] for k in ('case', 'method', 'seed')):
            raise ValueError('registration and effective identity differ')
    training = target['effective_config']['training_contract']
    source_training = source['effective_config']['training_contract']
    if source_training.get('initial_epochs') != 200 or source_training.get('maximum_epochs') not in (200, 400):
        raise ValueError('unregistered source budget')
    if training.get('initial_epochs') != 200 or training.get('maximum_epochs') != 200:
        raise ValueError('target budget must be fixed 200')
    if target['effective_config'].get('optimizer') != 'Adam':
        raise ValueError('Adam required')
    if not target['effective_config'].get('scheduler_continuation'):
        raise ValueError('target must explicitly enable continuation')
    allowed = {'protocol_sha256', 'effective_config.code_hash',
               'effective_config.budget_policy_hash', 'effective_config.scheduler_continuation',
               'effective_config.continuation_required',
               'registration.run_dir', 'registration.config_path', 'registration.metrics_path',
               'registration.execution_mode', 'registration.maximum_epochs'}
    allowed.update('effective_config.training_contract.' + k for k in (
        'initial_epochs', 'maximum_epochs', 'extension_scope', 'extension_early_window',
        'extension_late_window', 'extension_relative_drop', 'extension_at_max_windows'))
    old_registration, new_registration = source['registration'], target['registration']
    if old_registration.get('status') != new_registration.get('status'):
        if (old_registration.get('status'), new_registration.get('status')) != (
                'authorized_pending_dependencies', 'planned_not_authorized'):
            raise ValueError('unregistered registration status transition')
        allowed.add('registration.status')
    if old_registration.get('required_group_epochs') != new_registration.get('required_group_epochs'):
        parent = target['effective_config']['case'] + '__tune_foundation_group__seal'
        if (old_registration.get('required_group_epochs') is not None or
                new_registration.get('required_group_epochs') != {parent:400} or
                new_registration.get('dependency_ids') != [parent]):
            raise ValueError('only the exact registered 400 epoch tuning parent can be mapped')
        allowed.add('registration.required_group_epochs')
    changed = _changes(source, target)
    refused = sorted(set(changed) - allowed)
    if refused:
        raise ValueError('scientific/unregistered configuration changes: ' + ', '.join(refused))
    for field in ('extension_scope', 'extension_early_window', 'extension_late_window',
                  'extension_relative_drop', 'extension_at_max_windows'):
        if training.get(field) is not None:
            raise ValueError('target automatic extension must be absent')
    if target['registration'].get('maximum_epochs', 200) != 200:
        raise ValueError('registration budget must be 200')
    expected_budget = checkpoint_io.sha256(json.dumps(training, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode())
    if target['effective_config'].get('budget_policy_hash') != expected_budget:
        raise ValueError('target budget policy hash differs')
    return changed


def _publish(destination, source_dir, write_files):
    destination, source_dir = Path(destination).resolve(), Path(source_dir).resolve()
    if destination == source_dir or source_dir in destination.parents or destination in source_dir.parents:
        raise ValueError('source and destination must be disjoint')
    if destination.exists():
        raise FileExistsError('destination already exists; no overwrite permitted')
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.checkpoint-candidate-', dir=destination.parent) as name:
        temporary = Path(name)
        write_files(temporary)
        if destination.exists():
            raise FileExistsError('destination appeared during preparation')
        temporary.rename(destination)
    return destination


def prepare_candidate(run_dir, target_config, destination, expected_current=None, optimizer=None):
    state, source, report, source_config_raw, source_raw = checkpoint_io.load_continuation(run_dir, 200)
    checkpoint_io.validate_continuation(state, report['config_sha256'], 200,
                                        expected_current, optimizer)
    if (Path(run_dir) / 'failure.json').exists():
        raise ValueError('failed run is not an automatic migration source')
    target = copy.deepcopy(target_config)
    if not isinstance(target.get('effective_config'), dict):
        raise ValueError('unresolved target config')
    target['effective_config']['continuation_required'] = True
    changed = check_config_transition(source, target)
    target_raw = (json.dumps(target, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    migrated = dict(state)
    migrated['config_sha256'] = checkpoint_io.sha256(target_raw)
    buffer = io.BytesIO()
    torch.save(migrated, buffer)
    migrated_raw = buffer.getvalue()
    receipt = {'schema': 'checkpoint-migration-candidate-v2',
               'status': 'prepared_not_activated', 'training_authorized': False,
               'scientific_source_admitted': False, 'group_sealed': False,
               'source_run_dir': str(Path(run_dir).resolve()),
               'source_config_sha256': report['config_sha256'],
               'source_checkpoint_sha256': report['checkpoint_sha256'],
               'target_config_sha256': checkpoint_io.sha256(target_raw),
               'target_checkpoint_sha256': checkpoint_io.sha256(migrated_raw),
               'completed_epochs': report['completed_epochs'], 'changed_config_paths': changed,
               'source_code_transition': 'requires_source_admission_review',
               'legacy_optimizer_parameter_names_recorded': False}

    def write_files(root):
        (root / 'source_config.json').write_bytes(source_config_raw)
        (root / 'source_continuation.pt').write_bytes(source_raw)
        (root / 'config.json').write_bytes(target_raw)
        (root / 'continuation.pt').write_bytes(migrated_raw)
        (root / 'migration_source.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
        checkpoint_io.initialize_lineage(root, migrated_raw, target_raw, report['completed_epochs'],
            checkpoint_io.sha256((root / 'migration_source.json').read_bytes()))
    _publish(destination, run_dir, write_files)
    return receipt


def prepare_result(run_dir, target_config, destination, expected_current=None, optimizer=None):
    """Prepare a first-200 completed-result candidate without inventing Adam."""
    state, source, report, source_config_raw, source_raw = checkpoint_io.load_continuation(run_dir)
    checkpoint_io.validate_continuation(state, report['config_sha256'],
                                        expected_current=expected_current, optimizer=optimizer)
    if report['completed_epochs'] < 200 or (Path(run_dir) / 'failure.json').exists():
        raise ValueError('complete successful first200 source required')
    target = copy.deepcopy(target_config)
    target['effective_config']['continuation_required'] = True
    changed = check_config_transition(source, target)
    target_raw = (json.dumps(target, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    selected_file, selected_raw = 'source_continuation.pt', source_raw
    if report['inline_best_matches_first200']:
        best = state['best']
    elif report['first200_best_epoch'] == 200:
        selected_file = 'source_epoch_200.pt'
        selected_raw = checkpoint_io.read_stable(Path(run_dir) / 'epoch_200.pt')
        best = torch.load(io.BytesIO(selected_raw), map_location='cpu', weights_only=True)
    else:
        raise ValueError('true first200 best weights or historical complete state required')
    checkpoint_io._same_layout(checkpoint_io._tensors(best), checkpoint_io._tensors(state['current']))
    buffer = io.BytesIO(); torch.save(best, buffer); best_raw = buffer.getvalue()
    outcome = {'status':'success', 'epochs':200, 'budget_final':True,
        'best_epoch':report['first200_best_epoch'], 'validation_mae':state['values'][:200],
        'checkpoint_sha256':checkpoint_io.sha256(best_raw),
        'shuffle_hash':checkpoint_io.sha256(''.join(state['shuffle_hashes'][:200]).encode()),
        'device_identity':target['effective_config'].get('device_identity'),
        'micro_batch':target['effective_config']['training_contract']['initial_micro_batch'],
        'effective_batch_size':16}
    record = {'schema':'completed-first200-result-v1', 'outcome':outcome,
              'train_metrics':state['train_metrics'][:200]}
    receipt = {'schema':'completed-prefix-source-v1', 'status':'prepared_not_activated',
        'scientific_source_admitted':False, 'training_authorized':False, 'group_sealed':False,
        'source_run_dir':str(Path(run_dir).resolve()), 'source_completed_epochs':report['completed_epochs'],
        'source_config_sha256':checkpoint_io.sha256(source_config_raw),
        'source_checkpoint_sha256':checkpoint_io.sha256(source_raw),
        'target_config_sha256':checkpoint_io.sha256(target_raw),
        'target_checkpoint_sha256':checkpoint_io.sha256(best_raw),
        'selected_source_file':selected_file, 'selected_source_sha256':checkpoint_io.sha256(selected_raw),
        'result_sha256':checkpoint_io.digest_json(record), 'changed_config_paths':changed,
        'source_code_transition':'requires_source_admission_review'}

    def write_files(root):
        (root / 'config.json').write_bytes(target_raw)
        (root / 'source_config.json').write_bytes(source_config_raw)
        (root / 'source_continuation.pt').write_bytes(source_raw)
        if selected_file != 'source_continuation.pt': (root / selected_file).write_bytes(selected_raw)
        (root / 'best.pt').write_bytes(best_raw)
        for name, document in [('migration_source.json',receipt),('completed_prefix_result.json',record)]:
            (root / name).write_text(json.dumps(document, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    _publish(destination, run_dir, write_files)
    checkpoint_io.load_prefix_result(destination)
    return receipt


def export_best(run_dir, destination):
    """Export an inline first-200 best candidate; no group seal/data evaluation."""
    state, _, report, config_raw, source_raw = checkpoint_io.load_continuation(run_dir)
    if not report['inline_best_matches_first200']:
        raise ValueError('inline best is from after epoch 200; historical weights required')
    receipt = dict(report, status='weights_candidate_not_admitted',
                   group_sealed=False, training_authorized=False,
                   selected_epoch=report['first200_best_epoch'])

    def write_files(root):
        torch.save(state['best'], root / 'best.pt')
        receipt['exported_checkpoint_sha256'] = checkpoint_io.sha256((root / 'best.pt').read_bytes())
        (root / 'source_config.json').write_bytes(config_raw)
        (root / 'source_continuation.pt').write_bytes(source_raw)
        (root / 'source.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    _publish(destination, run_dir, write_files)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['inspect', 'prepare-candidate', 'prepare-result', 'export-best', 'bindings'])
    parser.add_argument('--run-dir', required=True, type=Path)
    parser.add_argument('--target-config', type=Path)
    parser.add_argument('--destination', type=Path)
    parser.add_argument('--runtime-root', type=Path)
    parser.add_argument('--case')
    args = parser.parse_args()
    if args.action in ('prepare-candidate', 'prepare-result', 'export-best') and args.destination is None:
        parser.error('--destination required')
    try:
        if args.action == 'bindings':
            if args.runtime_root is None or args.case is None:
                parser.error('--runtime-root and --case required')
            result = checkpoint_io.migration_bindings(args.runtime_root, args.case, args.run_dir)
        elif args.action == 'inspect':
            result = checkpoint_io.load_continuation(args.run_dir)[2]
            result['failed_run_marker_exists'] = (args.run_dir / 'failure.json').exists()
        elif args.action in ('prepare-candidate', 'prepare-result'):
            if args.target_config is None:
                parser.error('--target-config required')
            prepare = prepare_candidate if args.action == 'prepare-candidate' else prepare_result
            result = prepare(args.run_dir, json.loads(args.target_config.read_bytes()), args.destination)
        else:
            result = export_best(args.run_dir, args.destination)
    except (OSError, ValueError, KeyError, TypeError, RuntimeError, EOFError, pickle.UnpicklingError) as error:
        print(json.dumps({'status': 'rejected', 'reason': str(error)}))
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
