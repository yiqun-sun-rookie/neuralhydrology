"""Continue only a terminal scheduler slice; never submit an active instance.

Usage: python -B hpc/submit_scheduler_continuation.py
Requires the current job to have timed out without fit failure, or to have
completed the registered graceful slice. Completed cases are not submitted.
Run the registered checkpoint audit before invoking this scheduler helper.
"""
import datetime,hashlib,json,os
from pathlib import Path
import re
import subprocess

ROOT=Path(__file__).resolve().parents[1]
CASE='explicit_gru__historical_capacity'

def save_new(path,value):
    with path.open('x',encoding='utf-8') as f:
        json.dump(value,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())

def main():
    complete=ROOT/'records'/CASE/'training_complete.json'
    if complete.exists():
        print(json.dumps({'status':'case_complete_no_continuation_submission'}));return
    jobs=json.loads((ROOT/'records/scheduler_jobs.json').read_text())
    old=str(jobs[CASE]);assert old.isdigit()
    q=subprocess.run(['squeue','-h','-u','sunyiq','-o','%i|%j|%T'],capture_output=True,text=True,check=True,timeout=30)
    rows=[line.split('|') for line in q.stdout.splitlines()]
    assert not any(r[0]==old or r[1].startswith(('zj_gru_gradient_recovery_','zj_gru_slice_')) for r in rows),'registered case still has an active allocation or pending continuation'
    accounting=subprocess.run(['sacct','-n','-X','-j',old,'--format=JobID,State,ExitCode','-P'],capture_output=True,text=True,check=True,timeout=30)
    row=next(line.split('|') for line in accounting.stdout.splitlines() if line.startswith(old+'|'))
    graceful=ROOT/'records'/('scheduler_slice_end_'+old+'.json')
    assert row[1]=='TIMEOUT' or (row[1]=='COMPLETED' and row[2]=='0:0' and graceful.exists()),'new technical failures require diagnosis instead of blind continuation'
    failures=list(ROOT.joinpath('runs').glob('*/failure.json'));assert not failures,'failed fit cannot resume through this helper'
    from src.scheduler import code_identity
    auth=json.loads(ROOT.joinpath('records/authorization.json').read_text())
    assert auth['code_hash']==code_identity()=='19bf9eb19614f62a329da1cac2f2ec377558ff7f72d32ac5f5d935f30415eca0'
    assert hashlib.sha256(ROOT.joinpath('configs/protocol-v3.json').read_bytes()).hexdigest()==auth['protocol_sha256']
    source=ROOT/'hpc/pathfix_gradient_recovery_squeue_20261014_v1.slurm'
    before=json.loads(ROOT.joinpath('records/scheduler_queue_repair_20261014_001_manifest.json').read_text())
    assert hashlib.sha256(source.read_bytes()).hexdigest()==before['repair_script_sha256']
    ready=json.loads(ROOT.joinpath('records/scheduler_queue_repair_20261014_001_ready.json').read_text())
    runtime=Path(ready['runtime'])
    assert all(hashlib.sha256((runtime/name).read_bytes()).hexdigest()==digest for name,digest in ready['runtime_files'].items())
    assert hashlib.sha256(ROOT.joinpath(before['scheduler_wrapper']).read_bytes()).hexdigest()==before['files'][before['scheduler_wrapper']]['sha256']
    records={}
    for p in sorted(ROOT.joinpath('runs').glob('*/config.json')):
        value=json.loads(p.read_text());assert value['effective_config']['scheduler_continuation']
        point=p.parent/'continuation.pt';assert point.exists()
        records[p.parent.name]={'config_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'continuation_bytes':point.stat().st_size,'continuation_mtime_ns':point.stat().st_mtime_ns}
    name='zj_gru_slice_'+old+'_261012'
    lines=[]
    for line in source.read_text().splitlines():
        if line.startswith('#SBATCH --job-name='):line='#SBATCH --job-name='+name
        elif line.startswith('#SBATCH --time-min='):continue
        elif line.startswith('#SBATCH --time='):
            lines.append('#SBATCH --time-min=02:00:00');line='#SBATCH --time=12:00:00'
        elif line=='python -B -u scripts/train_supercomputer_case.py --case "$case_name"':
            line='python -B -u hpc/run_scheduler_slice_squeue_20261014.py --case "$case_name"'
        lines.append(line)
    assert '#SBATCH -p hgpu2p' in lines and '#SBATCH --gres=gpu:1' in lines and '#SBATCH --cpus-per-task=4' in lines
    assert '#SBATCH --exclude=ngu002,ngu011' in lines and '#SBATCH --time-min=02:00:00' in lines
    assert lines.index('conda activate nh_final')<lines.index('set -u')
    assert [l for l in lines if l.startswith('cd ')]==['cd '+str(ROOT)]
    script=ROOT/'hpc'/('pathfix_scheduler_slice_after_'+old+'.slurm')
    attempt=ROOT/'records'/('scheduler_slice_submission_after_'+old+'.attempt.json')
    assert not attempt.exists(),'submission already attempted; inspect unique response and queue'
    with script.open('x',encoding='utf-8') as f:f.write('\n'.join(lines)+'\n')
    record={'status':'continuation_submission_reserved','previous_job':old,'time':datetime.datetime.now().astimezone().isoformat(),'case':CASE,'accounting':accounting.stdout,'queue_before':q.stdout,'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'wrapper_sha256':hashlib.sha256(ROOT.joinpath('hpc/run_scheduler_slice_squeue_20261014.py').read_bytes()).hexdigest(),'scientific_budget_changed':False,'run_configs_and_checkpoint_stats':records}
    save_new(attempt,record)
    result=subprocess.run(['/usr/local/globle/softs/slurm/19.05.4.1/bin/xbatch',str(script)],capture_output=True,text=True,timeout=45)
    save_new(ROOT/'records'/('scheduler_slice_submission_after_'+old+'.response.json'),{'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    m=re.fullmatch(r'Submitted batch job ([0-9]+)\s*',result.stdout)
    if result.returncode or not m:raise RuntimeError('submission uncertain; inspect response and scheduler; never blind retry')
    save_new(ROOT/'records'/('scheduler_jobs_before_slice_'+old+'.json'),jobs)
    jobs[CASE]=m.group(1);temporary=ROOT/'records/scheduler_jobs.json.slice.tmp'
    with temporary.open('x',encoding='utf-8') as f:json.dump(jobs,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    temporary.replace(ROOT/'records/scheduler_jobs.json')
    record.update(status='scheduler_continuation_submitted',new_job=m.group(1),formal_progress_confirmed=False)
    save_new(ROOT/'records'/('scheduler_slice_submission_after_'+old+'.confirmed.json'),record)
    print(json.dumps(record),flush=True)

if __name__=='__main__':
    import sys
    sys.path.insert(0,str(ROOT))
    main()
