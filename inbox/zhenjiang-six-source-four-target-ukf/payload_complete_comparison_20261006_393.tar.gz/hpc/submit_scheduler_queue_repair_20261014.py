"""Submit one admitted scheduler queue repair after a confirmed failed job.

Run after the checkpoint and runtime admission has a verified complete receipt.
Preserves the failed job, all histories, and optimizer checkpoints.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
CASE = "explicit_gru__historical_capacity"
REPAIR = "scheduler_queue_repair_20261014_001"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def main():
    manifest = json.loads((ROOT / "records" / (REPAIR + "_manifest.json")).read_text())
    ready = json.loads((ROOT / "records" / (REPAIR + "_ready.json")).read_text())
    assert ready["status"] == "isolated_startup_dependencies_ready_continuation_admitted"
    jobs = json.loads((ROOT / "records/scheduler_jobs.json").read_text())
    old = str(jobs[CASE])
    assert old == manifest["source_failed_job"]
    queue = subprocess.run(["squeue", "-h", "-u", "sunyiq", "-o", "%i|%j|%T"],
                           capture_output=True, text=True, check=True, timeout=30)
    rows = [line.split("|") for line in queue.stdout.splitlines()]
    assert not any(row[0] == old or row[1].startswith(("zj_gru_gradient_recovery_", "zj_gru_slice_")) for row in rows)
    accounting = subprocess.run(["sacct", "-n", "-X", "-j", old, "--format=JobID,State,ExitCode", "-P"],
                                capture_output=True, text=True, check=True, timeout=30)
    assert accounting.stdout.strip() == old + "|FAILED|1:0"
    assert not list(ROOT.joinpath("runs").glob("*/failure.json"))
    sys.path.insert(0, str(ROOT))
    from src.scheduler import code_identity
    assert code_identity(ROOT) == ready["code_hash"]
    assert sha(ROOT / "configs/protocol-v3.json") == ready["protocol_sha256"]
    for member in ready["checkpoint_members"]:
        assert sha(ROOT / "runs" / member["run"] / "continuation.pt") == member["current_checkpoint_sha256"]
    runtime = Path(ready["runtime"])
    for name, digest in ready["runtime_files"].items():
        assert sha(runtime / name) == digest
    for name, expected in manifest["files"].items():
        assert sha(ROOT / name) == expected["sha256"]
    script = ROOT / manifest["repair_script"]
    assert sha(script) == manifest["repair_script_sha256"]
    attempt = ROOT / "records" / (REPAIR + "_submission_attempt.json")
    save(attempt, {"status": "exclusive_submission_reserved", "source_failed_job": old,
                   "script_sha256": sha(script), "queue_before": queue.stdout,
                   "accounting_before": accounting.stdout, "scientific_rules_changed": False})
    process = subprocess.run(["/usr/local/globle/softs/slurm/19.05.4.1/bin/xbatch", str(script)],
                             capture_output=True, text=True, timeout=45)
    save(ROOT / "records" / (REPAIR + "_submission_response.json"),
         {"returncode": process.returncode, "stdout": process.stdout, "stderr": process.stderr})
    match = re.fullmatch(r"Submitted batch job ([0-9]+)\s*", process.stdout)
    if process.returncode or not match:
        raise RuntimeError("Submission uncertain; inspect the unique response and scheduler before any further attempt")
    save(ROOT / "records" / (REPAIR + "_scheduler_jobs_before.json"), jobs)
    jobs[CASE] = match.group(1)
    temporary = ROOT / "records/scheduler_jobs.json.startup_repair.tmp"
    save(temporary, jobs)
    temporary.replace(ROOT / "records/scheduler_jobs.json")
    record = {"status": "scheduler_queue_repair_submitted", "case": CASE,
              "source_failed_job": old, "job_id": match.group(1), "root": str(ROOT),
              "checked_at_beijing": datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
              "script": str(script), "script_sha256": sha(script), "formal_progress_confirmed": False,
              "scientific_rules_changed": False, "evaluation_values_read": False}
    save(ROOT / "records" / (REPAIR + "_submission_confirmed.json"), record)
    print(json.dumps(record), flush=True)


if __name__ == "__main__":
    main()
