"""Audit a canonical float64 covariance factor from saved positive operands.

Zero model/optimizer steps. No formal filter is changed. Compare the nearest
float64 dense reference and the full-state QR factor with the authenticated
120-digit reconstruction. Test only the standalone factor's differentiation.
"""
import importlib.util
import json
from pathlib import Path

import mpmath as mp
import torch

ROOT = Path(__file__).resolve().parents[1]


def hp_lower(a):
    n = a.rows
    lower = mp.matrix(n)
    for i in range(n):
        for j in range(i + 1):
            value = a[i, j] - mp.fsum(lower[i, k] * lower[j, k] for k in range(j))
            if i == j:
                assert value > 0, 'reference is not positive definite'
                lower[i, j] = mp.sqrt(value)
            else:
                lower[i, j] = value / lower[j, j]
    return lower


def triangular_solve(lower, rhs):
    answer = mp.matrix(lower.rows, rhs.cols)
    for i in range(lower.rows):
        for j in range(rhs.cols):
            answer[i, j] = (rhs[i, j] - mp.fsum(lower[i, k] * answer[k, j] for k in range(i))) / lower[i, i]
    return answer


def main():
    spec = json.loads((ROOT / 'audit_spec.json').read_text())
    helper_path = Path(spec['source_arithmetic_helper'])
    import hashlib
    assert hashlib.sha256(helper_path.read_bytes()).hexdigest() == spec['source_arithmetic_helper_sha256']
    module_spec = importlib.util.spec_from_file_location('authenticated_arithmetic_helpers', helper_path)
    h = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(h)
    assert str(ROOT) == spec['audit_root'] and spec['model_steps_allowed'] == 0
    evidence = ROOT / 'evidence'
    evidence.mkdir(exist_ok=False)
    pinned = dict(spec['pinned_files'])
    assert all(h.sha(path) == expected for path, expected in pinned.items())
    decimal_path = Path(spec['reconstructed_decimal_path'])
    decimal_sha = h.sha(decimal_path)
    decimal = json.loads(decimal_path.read_text())
    assert decimal['member_index_0based'] == 1 and decimal['precision_decimal_digits'] == 120
    source_result = json.loads(Path(spec['source_matrix_result_path']).read_text())
    assert source_result['source_and_original_artifacts_unchanged'] and source_result['model_steps'] == 0
    props = torch.cuda.get_device_properties(0)
    device = {'device': 'cuda:0', 'name': props.name, 'total_memory_bytes': props.total_memory}
    assert device == spec['expected_device_identity']
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    operands = torch.load(spec['operands_path'], map_location='cpu', weights_only=True)
    assert operands['context'] == spec['failure_context']
    assert operands['original_jitters'] == spec['permitted_jitters']
    p = operands['original_input_covariance']
    moments = operands['moments']
    q = operands['noise_variances'][0].cuda().clone().requires_grad_()
    differences = (moments['points'][1] - moments['mean'][1][None]).cuda().clone().requires_grad_()
    assert differences.dtype == q.dtype == torch.float64 and differences.shape == (257, 128)
    assert moments['wc'][0] == 2 and bool((moments['wc'][1:] == 1/256).all())
    assert bool((q > 0).all())
    # Repeat the centre column twice, rather than multiplying it by rounded
    # sqrt(2); all remaining UT square-root weights are the exact binary 1/16.
    columns = torch.cat((differences[0, :, None], differences[0, :, None],
                         differences[1:].T / 16, torch.diag(q.sqrt())), dim=1)
    _, upper = torch.linalg.qr(columns.T, mode='reduced')
    signs = torch.where(upper.diagonal() >= 0, 1., -1.).to(torch.float64)
    lower = (signs[:, None] * upper).T
    assert lower.dtype == torch.float64 and bool(torch.isfinite(lower).all()) and bool((lower.diagonal() > 0).all())
    result = {'status': 'saved_covariance_matrix_audit_complete', 'audit_kind': 'canonical_float64_factor_boundary',
              'checked_at_beijing': h.now(), 'device_identity': device, 'failure_context': operands['context'],
              'model_steps': 0, 'optimizer_updates': 0, 'formal_training_epochs_added': 0,
              'training_inputs_read': False, 'evaluation_values_read': False, 'scientific_rules_changed': False,
              'formal_filter_or_precision_changed': False, 'automatic_technical_repair_admitted': False,
              'reconstructed_decimal_sha256': decimal_sha, 'canonical_factor_dtype': str(lower.dtype),
              'canonical_factor_diagonal_min': float(lower.diagonal().min().detach()),
              'canonical_factor_diagonal_max': float(lower.diagonal().max().detach()),
              'jitter_used': 0., 'eigenvalue_clipping_used': False}
    nearest = torch.tensor([[float(x) for x in row] for row in decimal['covariance']], dtype=torch.float64, device='cuda')
    result['nearest_float64_dense_reference_cholesky_info'] = int(torch.linalg.cholesky_ex(nearest)[1])
    with mp.workdps(120):
        reference = mp.matrix([[mp.mpf(x) for x in row] for row in decimal['covariance']])
        cert = h.cholesky_certificate(reference)
        assert cert['positive_definite'] and cert['minimum_cholesky_pivot'] == source_result['positive_operand_reconstruction_certificate']['minimum_cholesky_pivot']
        result['authenticated_reference_certificate'] = cert
        result['nearest_float64_dense_reference_certificate'] = h.cholesky_certificate(h.matrix(nearest))
        candidate = h.matrix(lower.detach())
        residual = reference - candidate * candidate.T
        result['factor_relative_covariance_max_error'] = str(max(abs(x) for x in residual) / max(abs(x) for x in reference))
        normalized = triangular_solve(candidate, reference)
        normalized = triangular_solve(candidate, normalized.T).T - mp.eye(128)
        result['factor_normalized_covariance_max_error'] = str(max(abs(x) for x in normalized))
        ref_lower = hp_lower(reference)
        result['factor_relative_canonical_lower_max_error'] = str(max(abs(x) for x in (candidate-ref_lower)) / max(abs(x) for x in ref_lower))
    # Differentiate this matrix factor only; no model parameters or optimizer
    # exist in this program. This is not evidence of repaired training gradients.
    standalone_logdet = 2 * lower.diagonal().log().sum()
    standalone_logdet.backward()
    result['standalone_factor_gradient_differences_finite'] = bool(torch.isfinite(differences.grad).all())
    result['standalone_factor_gradient_q_finite'] = bool(torch.isfinite(q.grad).all())
    with (evidence / 'canonical_float64_factor.pt').open('xb') as f:
        torch.save({'lower': lower.detach().cpu(), 'source_context': operands['context'], 'formal_training_used': False}, f)
    unchanged = {path: h.sha(path) == expected for path, expected in pinned.items()}
    assert all(unchanged.values()) and h.sha(decimal_path) == decimal_sha
    result.update(source_and_original_artifacts_unchanged=True, unchanged_file_checks=unchanged,
                  finished_at_beijing=h.now())
    h.save(evidence / 'saved_matrix_audit_result.json', result)
    print(json.dumps({'status': result['status'], 'audit_kind': result['audit_kind'],
                      'finished_at_beijing': result['finished_at_beijing'], 'model_steps': 0}), flush=True)


if __name__ == '__main__':
    main()
