"""Read-only preflight for the version-2 Stage-A cluster bundle.

This verifier checks deployment topology, exact bundle membership, byte
identities, line endings, immutable contract identities, and exclusive output
paths.  It never opens any formal hydrological data and never creates a file.

Example (on an allocated compute node, before formal training)::

    python -u scripts/hpc/verify_zhenjiang_five_source_five_target_stage_a_hpc_v2.py \
      --remote-root /data1/home/sunyiq/zhenjiang_5s5t_stage_a_20260905_recovery_001 \
      --project-root /data1/home/sunyiq/zhenjiang_5s5t_stage_a_20260905_recovery_001/run \
      --bundle-manifest /data1/home/sunyiq/zhenjiang_5s5t_stage_a_20260905_recovery_001/bundle_manifest.json \
      --trusted-bundle-manifest-sha256 SHA256 \
      --authorization /data1/home/sunyiq/zhenjiang_5s5t_stage_a_20260905_recovery_001/contracts/stage_a_authorization.json \
      --trusted-authorization-sha256 SHA256 \
      --usage-ledger /data1/home/sunyiq/zhenjiang_5s5t_stage_a_20260905_recovery_001/evidence/stage_a_formal_data_usage.sqlite3 \
      --data-contract /data1/home/sunyiq/zhenjiang_5s5t_stage_a_20260905_recovery_001/contracts/stage_a_data_contract.json \
      --trusted-data-contract-sha256 SHA256 \
      --execution-authorization /data1/home/sunyiq/zhenjiang_5s5t_stage_a_20260905_recovery_001/evidence/contracts/paid_hpc_execution_authorization.json \
      --trusted-execution-authorization-sha256 SHA256 \
      --output-root /data1/home/sunyiq/zhenjiang_5s5t_stage_a_20260905_recovery_001/runs \
      --seed 17
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
from typing import Dict, Mapping, Optional, Sequence, Tuple, Union


EXPERIMENT_FAMILY = (
    "ZHENJIANG_FIVE_SOURCE_FIVE_TARGET_D32_GRU_SINGLE_ANALYSIS_UKF_"
    "ORACLE_DATONG_V2"
)
EXPECTED_REMOTE_ROOT_TEXT = (
    "/data1/home/sunyiq/"
    "zhenjiang_5s5t_stage_a_20260905_recovery_001"
)
EXPECTED_REMOTE_ROOT = Path(EXPECTED_REMOTE_ROOT_TEXT)
AUTHORIZATION_RELATIVE_PATH = "contracts/stage_a_authorization.json"
DATA_CONTRACT_RELATIVE_PATH = "contracts/stage_a_data_contract.json"
EXECUTION_AUTHORIZATION_RELATIVE_PATH = (
    "evidence/contracts/paid_hpc_execution_authorization.json"
)
USAGE_LEDGER_RELATIVE_PATH = (
    "evidence/stage_a_formal_data_usage.sqlite3"
)
FORMAL_CONFIRMATION = (
    "CONFIRM_ZHENJIANG_FIVE_SOURCE_FIVE_TARGET_"
    "STAGE_A_PAID_HPC_20260905_RECOVERY_001"
)
EXECUTION_AUTHORIZATION_ID = "ZJ-5S5T-V2-STAGE-A-HPC-RECOVERY-20260905-01"
IDENTITY_REGISTRATION_USAGE_LEDGER = (
    r"G:\github\pycharm\projects\zhenjiang_stage_forecast\migration_packages"
    r"\zhenjiang_five_source_five_target_stage_a_hpc_v2_identity_registration"
    r"\identity_registration_usage.sqlite3"
)
IDENTITY_REGISTRATION_BUNDLE = (
    r"G:\github\pycharm\projects\zhenjiang_stage_forecast\migration_packages"
    r"\zhenjiang_five_source_five_target_stage_a_hpc_v2_identity_registration"
    r"\zhenjiang_2017_2022_prefixes.tar.gz"
)
IDENTITY_REGISTRATION_MANIFEST = (
    r"G:\github\pycharm\projects\zhenjiang_stage_forecast\docs\records"
    r"\zhenjiang_five_source_five_target_2017_2022_identity_registration_20260904.json"
)
REGISTRY_RELATIVE_PATH = (
    "run/docs/records/"
    "zhenjiang_five_source_five_target_single_analysis_ukf_oracle_datong_"
    "v2_registry.json"
)
EXPECTED_BUNDLE_MEMBERS: Tuple[str, ...] = tuple(
    sorted(
        (
            AUTHORIZATION_RELATIVE_PATH,
            DATA_CONTRACT_RELATIVE_PATH,
            EXECUTION_AUTHORIZATION_RELATIVE_PATH,
            REGISTRY_RELATIVE_PATH,
            "run/scripts/analysis/"
            "zhenjiang_five_source_five_target_single_analysis_contract_v2.py",
            "run/scripts/astronomical_tide/"
            "wusongkou_astronomical_tide_realtime_v2.py",
            "run/scripts/hpc/"
            "verify_zhenjiang_five_source_five_target_stage_a_hpc_v2.py",
            "run/scripts/hpc/"
            "zhenjiang_five_source_five_target_stage_a_v2.slurm",
            "run/scripts/modeling/"
            "run_zhenjiang_five_source_five_target_stage_a_v2.py",
            "run/scripts/modeling/"
            "train_zhenjiang_five_source_five_target_d32_gru_v2.py",
            "run/scripts/modeling/"
            "zhenjiang_five_source_five_target_d32_gru_v2.py",
            "run/scripts/modeling/"
            "zhenjiang_five_source_five_target_data_v2.py",
            "run/third_party/pytides/astro.py",
            "run/third_party/pytides/constituent.py",
            "run/third_party/pytides/nodal_corrections.py",
            "run/third_party/pytides/tide.py",
        )
    )
)
ALLOWED_SEEDS = (17, 29, 43)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            block = handle.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def _validated_sha256(value: object, field_name: str) -> str:
    if not isinstance(value, str):
        raise ValueError("{} must be a lowercase SHA-256 string".format(field_name))
    lowered = value.lower()
    if len(lowered) != 64 or any(
        character not in "0123456789abcdef" for character in lowered
    ):
        raise ValueError("{} must be a lowercase SHA-256 string".format(field_name))
    return lowered


def _require_directory(path: Path, label: str) -> Path:
    if path.is_symlink() or not path.is_dir():
        raise ValueError("{} must be an existing ordinary directory: {}".format(label, path))
    return path.resolve(strict=True)


def _require_file(path: Path, label: str) -> Path:
    if path.is_symlink() or not path.is_file():
        raise ValueError("{} must be an existing ordinary file: {}".format(label, path))
    return path.resolve(strict=True)


def _require_lf_only(path: Path, label: str) -> None:
    if b"\r\n" in path.read_bytes():
        raise ValueError("{} contains forbidden CRLF line endings: {}".format(label, path))


def _safe_member_path(relative: object) -> str:
    if not isinstance(relative, str) or not relative:
        raise ValueError("bundle relative_path must be nonempty text")
    pure = PurePosixPath(relative)
    if (
        pure.is_absolute()
        or "\\" in relative
        or ":" in relative
        or "//" in relative
        or any(part in ("", ".", "..") for part in pure.parts)
    ):
        raise ValueError("bundle relative_path is not normalized: {!r}".format(relative))
    forbidden = {"data", "results", "archive", ".git"}
    if any(part.lower() in forbidden for part in pure.parts):
        raise ValueError("bundle contains a forbidden data-like path: {}".format(relative))
    return relative


def _expected_child(root: Path, relative: str, label: str) -> Path:
    candidate = root.joinpath(*PurePosixPath(relative).parts)
    resolved = _require_file(candidate, label)
    if root not in resolved.parents:
        raise ValueError("{} escapes the frozen remote root: {}".format(label, candidate))
    return resolved


def _read_manifest(path: Path) -> Mapping[str, object]:
    _require_file(path, "bundle manifest")
    _require_lf_only(path, "bundle manifest")
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError("bundle manifest is not canonical UTF-8 JSON") from error
    if not isinstance(document, dict):
        raise ValueError("bundle manifest must be a JSON object")
    return document


def _read_json_object(path: Path, label: str) -> Mapping[str, object]:
    _require_file(path, label)
    _require_lf_only(path, label)
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError("{} is not canonical UTF-8 JSON".format(label)) from error
    if not isinstance(document, dict):
        raise ValueError("{} must be a JSON object".format(label))
    return document


def _validate_paid_execution_authorization(
    path: Path,
    *,
    remote_root: Path,
    remote_root_identity: Optional[str] = None,
) -> None:
    if remote_root_identity is None:
        remote_root_identity = str(remote_root)
    document = _read_json_object(path, "paid-HPC execution authorization")
    required_outer_fields = {
        "schema_version",
        "authorization_id",
        "authorized_at_beijing",
        "authorized_by",
        "authorizing_message_sha256",
        "authorizing_message_utf8",
        "interpreted_authorized_actions",
        "identity_registration_scope",
        "prior_access_events_acknowledgement",
        "hpc_scope",
        "explicitly_not_authorized",
        "paid_hpc_execution_contract",
    }
    if not required_outer_fields.issubset(document):
        raise ValueError("paid-HPC execution authorization lost required provenance")
    if document.get("schema_version") != 1:
        raise ValueError("paid-HPC execution authorization schema must remain 1")
    if document.get("authorization_id") != EXECUTION_AUTHORIZATION_ID:
        raise ValueError("paid-HPC execution authorization identity changed")
    for field in ("authorized_at_beijing", "authorized_by"):
        if not isinstance(document.get(field), str) or not document[field].strip():
            raise ValueError("paid-HPC execution authorization {} is absent".format(field))
    message = document.get("authorizing_message_utf8")
    if not isinstance(message, str) or not message:
        raise ValueError("authorizing message is absent")
    expected_message_sha256 = _validated_sha256(
        document.get("authorizing_message_sha256"),
        "authorizing_message_sha256",
    )
    if hashlib.sha256(message.encode("utf-8")).hexdigest() != expected_message_sha256:
        raise ValueError("authorizing message SHA-256 changed")

    prior = document.get("prior_access_events_acknowledgement")
    if not isinstance(prior, dict) or (
        prior.get("development_2023_confirmed_previous_read_count") != 2
        or prior.get("held_out_2024_previous_read_count")
        != "unknown_not_zero_assumed"
    ):
        raise ValueError("prior 2023 or 2024 access acknowledgement changed")
    identity_scope = document.get("identity_registration_scope")
    if not isinstance(identity_scope, dict) or (
        identity_scope.get("required_usage_ledger_path")
        != IDENTITY_REGISTRATION_USAGE_LEDGER
        or identity_scope.get("required_bundle_output_path")
        != IDENTITY_REGISTRATION_BUNDLE
        or identity_scope.get("required_identity_manifest_path")
        != IDENTITY_REGISTRATION_MANIFEST
    ):
        raise ValueError("identity-registration ledger or output path changed")
    hpc_scope = document.get("hpc_scope")
    if not isinstance(hpc_scope, dict) or (
        hpc_scope.get("allowed_remote_root") != remote_root_identity
        or hpc_scope.get("allowed_seeds") != list(ALLOWED_SEEDS)
        or hpc_scope.get("allowed_stage")
        != "stage_a_full_model_training_with_2022_best_epoch_selection"
        or hpc_scope.get("paid_compute_authorized") is not True
    ):
        raise ValueError("original paid-HPC scope changed")

    contract = document.get("paid_hpc_execution_contract")
    expected_contract = {
        "experiment_family": EXPERIMENT_FAMILY,
        "remote_root": remote_root_identity,
        "stage": "stage_a",
        "paid_hpc_execution_authorized": True,
        "allowed_seeds": list(ALLOWED_SEEDS),
        "execution_mode": "single_job_sequential_seed_loop",
        "seed_order": list(ALLOWED_SEEDS),
        "maximum_sbatch_submissions": 1,
        "maximum_first_attempts_per_seed": 1,
        "slurm_no_requeue_required": True,
        "automatic_requeue": False,
        "automatic_retry": False,
        "automatic_cleanup": False,
        "fail_stop_after_first_seed_failure": True,
        "remaining_unattempted_seeds_may_run_after_one_seed_failure": False,
        "stage_b_authorized": False,
        "evaluation_authorized": False,
        "confirmation_phrase": FORMAL_CONFIRMATION,
    }
    if contract != expected_contract:
        raise ValueError("paid-HPC execution contract differs from the exact scope")

    exclusions = document.get("explicitly_not_authorized")
    if not isinstance(exclusions, list) or not all(
        isinstance(value, str) for value in exclusions
    ):
        raise ValueError("explicitly-not-authorized evidence is absent")
    exclusion_text = "\n".join(exclusions).lower()
    for required_phrase in (
        "stage-b",
        "2022 five-by-five evaluation matrix",
        "2023 target",
        "2024 target",
        "protected historical hpc root",
        "automatic retry",
        "scientific success claims",
    ):
        if required_phrase not in exclusion_text:
            raise ValueError(
                "paid-HPC exclusion is absent: {}".format(required_phrase)
            )


def validate_stage_a_preflight(
    *,
    remote_root: Union[str, Path],
    project_root: Union[str, Path],
    manifest: Union[str, Path],
    trusted_bundle_manifest_sha256: str,
    authorization: Union[str, Path],
    trusted_authorization_sha256: str,
    usage_ledger: Union[str, Path],
    data_contract: Union[str, Path],
    trusted_data_contract_sha256: str,
    execution_authorization: Union[str, Path],
    trusted_execution_authorization_sha256: str,
    output_root: Union[str, Path],
    seed: int,
    expected_remote_root: Union[str, Path] = EXPECTED_REMOTE_ROOT,
) -> Mapping[str, object]:
    """Validate one seed without opening formal data or creating output."""

    if seed not in ALLOWED_SEEDS:
        raise ValueError("seed must be exactly one of 17, 29, or 43")
    expected_root_path = Path(expected_remote_root).resolve(strict=True)
    root = _require_directory(Path(remote_root), "remote root")
    if root != expected_root_path:
        raise ValueError("remote root differs from the frozen deployment root")

    project = _require_directory(Path(project_root), "project root")
    if project != (root / "run").resolve(strict=True):
        raise ValueError("project root must be the frozen remote run directory")
    contracts = _require_directory(root / "contracts", "contract directory")
    evidence = _require_directory(root / "evidence", "evidence directory")
    _require_directory(evidence / "contracts", "execution-contract directory")
    runs = _require_directory(Path(output_root), "output root")
    _require_directory(root / "logs", "log directory")
    if contracts != (root / "contracts").resolve(strict=True):
        raise ValueError("contract directory topology changed")
    if evidence != (root / "evidence").resolve(strict=True):
        raise ValueError("evidence directory topology changed")
    if runs != (root / "runs").resolve(strict=True):
        raise ValueError("output root must be the frozen remote runs directory")
    stage_a_root = _require_directory(runs / "stage_a", "Stage-A output parent")
    if stage_a_root != (root / "runs" / "stage_a").resolve(strict=True):
        raise ValueError("Stage-A output parent topology changed")

    manifest_path = _require_file(Path(manifest), "bundle manifest")
    if manifest_path != (root / "bundle_manifest.json").resolve(strict=True):
        raise ValueError("bundle manifest path differs from the frozen topology")
    trusted_manifest = _validated_sha256(
        trusted_bundle_manifest_sha256,
        "trusted_bundle_manifest_sha256",
    )
    if _sha256(manifest_path) != trusted_manifest:
        raise ValueError("bundle manifest SHA-256 differs from the trusted value")
    authorization_path = _require_file(Path(authorization), "authorization")
    if authorization_path != (
        root / AUTHORIZATION_RELATIVE_PATH
    ).resolve(strict=True):
        raise ValueError("authorization path differs from the frozen topology")
    data_contract_path = _require_file(Path(data_contract), "data contract")
    if data_contract_path != (root / DATA_CONTRACT_RELATIVE_PATH).resolve(
        strict=True
    ):
        raise ValueError("data-contract path differs from the frozen topology")
    execution_authorization_path = _require_file(
        Path(execution_authorization),
        "paid-HPC execution authorization",
    )
    if execution_authorization_path != (
        root / EXECUTION_AUTHORIZATION_RELATIVE_PATH
    ).resolve(strict=True):
        raise ValueError(
            "paid-HPC execution-authorization path differs from the frozen topology"
        )

    ledger_path = Path(usage_ledger)
    expected_ledger = root / USAGE_LEDGER_RELATIVE_PATH
    if ledger_path.resolve(strict=False) != expected_ledger.resolve(strict=False):
        raise ValueError("usage-ledger path differs from the frozen topology")
    if ledger_path.exists() and (
        ledger_path.is_symlink() or not ledger_path.is_file()
    ):
        raise ValueError("existing usage ledger must be an ordinary file")
    if ledger_path.parent.resolve(strict=True) != evidence:
        raise ValueError("usage-ledger parent differs from the evidence directory")

    trusted_authorization = _validated_sha256(
        trusted_authorization_sha256,
        "trusted_authorization_sha256",
    )
    trusted_data_contract = _validated_sha256(
        trusted_data_contract_sha256,
        "trusted_data_contract_sha256",
    )
    trusted_execution_authorization = _validated_sha256(
        trusted_execution_authorization_sha256,
        "trusted_execution_authorization_sha256",
    )
    observed_authorization = _sha256(authorization_path)
    observed_data_contract = _sha256(data_contract_path)
    observed_execution_authorization = _sha256(execution_authorization_path)
    if observed_authorization != trusted_authorization:
        raise ValueError("authorization SHA-256 differs from the trusted value")
    if observed_data_contract != trusted_data_contract:
        raise ValueError("data-contract SHA-256 differs from the trusted value")
    if observed_execution_authorization != trusted_execution_authorization:
        raise ValueError(
            "paid-HPC execution-authorization SHA-256 differs from the trusted value"
        )
    _validate_paid_execution_authorization(
        execution_authorization_path,
        remote_root=root,
    )

    document = _read_manifest(manifest_path)
    if document.get("schema_version") != 2:
        raise ValueError("bundle schema_version must equal 2")
    if document.get("experiment_family") != EXPERIMENT_FAMILY:
        raise ValueError("bundle experiment family changed")
    if document.get("remote_root") != str(root):
        raise ValueError("bundle remote root identity changed")
    for field in (
        "scientific_result",
        "formal_data_included",
        "held_out_2023_or_2024_data_included",
    ):
        if document.get(field) is not False:
            raise ValueError("bundle field {} must be false".format(field))
    if document.get("authorization_sha256") != trusted_authorization:
        raise ValueError("bundle authorization SHA-256 changed")
    if document.get("data_contract_sha256") != trusted_data_contract:
        raise ValueError("bundle data-contract SHA-256 changed")
    if (
        document.get("execution_authorization_sha256")
        != trusted_execution_authorization
    ):
        raise ValueError("bundle paid-HPC execution-authorization SHA-256 changed")

    rows = document.get("source_files")
    if not isinstance(rows, list) or document.get("source_file_count") != len(rows):
        raise ValueError("bundle source-file count is invalid")
    observed_members: Dict[str, Mapping[str, object]] = {}
    for row in rows:
        if not isinstance(row, dict) or set(row) != {
            "relative_path",
            "byte_count",
            "sha256",
        }:
            raise ValueError("each bundle member must have exactly three fields")
        relative = _safe_member_path(row.get("relative_path"))
        if relative in observed_members:
            raise ValueError("bundle contains a duplicate member: {}".format(relative))
        observed_members[relative] = row
    if tuple(sorted(observed_members)) != EXPECTED_BUNDLE_MEMBERS:
        raise ValueError("bundle membership differs from the exact allow-list")

    for relative in EXPECTED_BUNDLE_MEMBERS:
        row = observed_members[relative]
        path = _expected_child(root, relative, "bundle member")
        expected_size = row.get("byte_count")
        if type(expected_size) is not int or expected_size < 1:
            raise ValueError("bundle byte_count is invalid: {}".format(relative))
        if path.stat().st_size != expected_size:
            raise ValueError("bundle byte count changed: {}".format(relative))
        expected_sha = _validated_sha256(row.get("sha256"), "member sha256")
        if _sha256(path) != expected_sha:
            raise ValueError("bundle member SHA-256 changed: {}".format(relative))
        _require_lf_only(path, "bundle member")

    attempt = runs / "stage_a" / "seed_{}".format(seed)
    if attempt.exists() or attempt.is_symlink():
        raise ValueError("exclusive Stage-A output already exists: {}".format(attempt))
    partial = Path(str(attempt) + ".partial")
    if partial.exists() or partial.is_symlink():
        raise ValueError("exclusive Stage-A partial output already exists: {}".format(partial))

    return {
        "schema_version": 2,
        "experiment_family": EXPERIMENT_FAMILY,
        "status": "preflight_passed",
        "seed": seed,
        "remote_root": str(root),
        "bundle_member_count": len(observed_members),
        "authorization_sha256": trusted_authorization,
        "data_contract_sha256": trusted_data_contract,
        "bundle_manifest_sha256": trusted_manifest,
        "execution_authorization_sha256": trusted_execution_authorization,
        "formal_data_read": False,
        "output_created": False,
    }


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--project-root", required=True)
    parser.add_argument("--bundle-manifest", dest="manifest", required=True)
    parser.add_argument("--trusted-bundle-manifest-sha256", required=True)
    parser.add_argument("--authorization", required=True)
    parser.add_argument("--trusted-authorization-sha256", required=True)
    parser.add_argument("--usage-ledger", required=True)
    parser.add_argument("--data-contract", required=True)
    parser.add_argument("--trusted-data-contract-sha256", required=True)
    parser.add_argument("--execution-authorization", required=True)
    parser.add_argument("--trusted-execution-authorization-sha256", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--seed", type=int, choices=ALLOWED_SEEDS, required=True)
    arguments = parser.parse_args(argv)
    report = validate_stage_a_preflight(**vars(arguments))
    print(json.dumps(report, indent=2, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
