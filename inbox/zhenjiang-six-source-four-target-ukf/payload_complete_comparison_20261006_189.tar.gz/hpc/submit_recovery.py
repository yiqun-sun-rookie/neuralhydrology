"""Submit this authenticated continuation once from its verified pathfix script."""
import hashlib
import json
import pathlib
import re
import subprocess

ROOT = pathlib.Path(__file__).resolve().parents[1]
PARENT = pathlib.Path('/data1/home/sunyiq/zhenjiang_complete_comparison_20261006_002')
CASE = 'legacy_lstm__small'


def main():
    prep = json.loads((ROOT / 'records/recovery_preparation_complete.json').read_text())
    if prep['status'] != 'authenticated_continuation_prepared' or prep['case'] != CASE:
        raise ValueError('authenticated continuation missing')
    admission = json.loads((ROOT / 'records/gpu_compatibility_admission.json').read_text())
    if not admission['matches_frozen_device'] or admission['real_training_started']:
        raise ValueError('synthetic replacement-GPU admission missing')
    node = admission['node']
    if not re.fullmatch(r'ngu[0-9]+', node) or node in ('ngu002', 'ngu011'):
        raise ValueError('replacement node not admitted')
    source = PARENT / 'hpc/pathfix_legacy_lstm__small.slurm'
    raw = source.read_bytes()
    if hashlib.sha256(raw).hexdigest() != '0006d552d49e2313b0f2b63224073feae2b4f2e797e4769ff530a882cf429f5b':
        raise ValueError('verified scheduler pathfix script differs')
    out = []
    for line in raw.decode().splitlines():
        if line.startswith('#SBATCH --job-name='):
            line = '#SBATCH --job-name=zj_lstm_small_recovery_261008_002'
        elif line.startswith('#SBATCH --dependency='):
            continue
        elif line.startswith('#SBATCH --exclude='):
            line = '#SBATCH --exclude=ngu002,ngu011'
        elif line.startswith('#SBATCH --output='):
            line = '#SBATCH --output=' + str(ROOT / 'logs/%x_%j.out')
        elif line.startswith('cd '):
            line = 'cd ' + str(ROOT)
        elif line.startswith('python -B -u scripts/train_supercomputer_case.py'):
            out += ['python -B -u hpc/check_gpu_binding.py',
                    'python -B -u hpc/gpu_recovery_acceptance.py']
        out.append(line)
    out.insert(2, '#SBATCH --nodelist=' + node)
    body = '\n'.join(out) + '\n'
    if '#SBATCH -p hgpu2p' not in out or '#SBATCH --gres=gpu:1' not in out or '#SBATCH --cpus-per-task=4' not in out:
        raise ValueError('recovery resources changed')
    if out.index('conda activate nh_final') > out.index('set -u'):
        raise ValueError('undefined-variable guard precedes environment activation')
    if [l for l in out if l.startswith('cd ')] != ['cd ' + str(ROOT)]:
        raise ValueError('recovery working directory differs')
    if [l for l in out if l.startswith('#SBATCH --output=')] != ['#SBATCH --output=' + str(ROOT / 'logs/%x_%j.out')]:
        raise ValueError('recovery output directory differs')
    script = ROOT / 'hpc/recover_small_lstm.slurm'
    with script.open('x') as f:
        f.write(body)
    with (ROOT / 'records/recovery_submission_attempt.json').open('x') as f:
        json.dump({'status': 'reserved', 'script': str(script), 'node': node,
                   'sha256': hashlib.sha256(script.read_bytes()).hexdigest(),
                   'source_pathfix_sha256': hashlib.sha256(raw).hexdigest()}, f, indent=2)
    result = subprocess.run(['/usr/local/globle/softs/slurm/19.05.4.1/bin/xbatch', str(script)],
                            capture_output=True, text=True, timeout=45)
    response = {'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    with (ROOT / 'records/recovery_submission_response.json').open('x') as f:
        json.dump(response, f, indent=2)
    matched = re.fullmatch(r'Submitted batch job ([0-9]+)\s*', result.stdout)
    if result.returncode or not matched:
        raise RuntimeError('submission uncertain; inspect without repeating')
    with (ROOT / 'records/scheduler_jobs.json').open('x') as f:
        json.dump({CASE: matched.group(1)}, f, indent=2)
    print(json.dumps({'status': 'authenticated_continuation_submitted', 'case': CASE,
                      'job_id': matched.group(1), 'root': str(ROOT), 'node': node}), flush=True)


if __name__ == '__main__':
    main()
