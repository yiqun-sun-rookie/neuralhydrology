"""Check replacement allocation against every authenticated frozen member."""
import json
import pathlib
import torch

ROOT = pathlib.Path(__file__).resolve().parents[1]
p = torch.cuda.get_device_properties(0)
actual = {'device': 'cuda:0', 'name': p.name, 'total_memory_bytes': p.total_memory}
configs = json.loads((ROOT / 'records/legacy_lstm__small/tune_foundation_group_configs.json').read_text())
if len(configs) != 3:
    raise ValueError('complete foundation group not present')
if any(c['effective_config']['device_identity'] != actual for c in configs.values()):
    raise ValueError('replacement GPU differs from authenticated frozen device')
print(json.dumps({'status': 'replacement_gpu_matches_all_frozen_members',
                  'device_identity': actual, 'evaluation_values_read': False}), flush=True)
