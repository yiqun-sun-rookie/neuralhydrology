"""Preserve a confirmed stalled case and authenticate its complete checkpoints.

Run in nh_final after its unique source allocation has ended. Changes only the
code/configuration binding; tensors, optimizer and every epoch remain identical.
No evaluation files are read. Example: python -B hpc/prepare_recovery.py
"""
import copy
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys

import torch

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.scheduler import code_identity

PARENT = pathlib.Path('/data1/home/sunyiq/zhenjiang_complete_comparison_20261006_002')
CASE = 'legacy_lstm__small'
OLD_CODE = '343af2846edcab85a98bab74c777fc91c7fcae191e6ed30727cb99f77b722c9d'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def state_hash(value):
    digest = hashlib.sha256()
    def visit(item):
        if isinstance(item, torch.Tensor):
            tensor = item.detach().cpu().contiguous()
            digest.update(str((str(tensor.dtype), tuple(tensor.shape))).encode())
            digest.update(tensor.reshape(-1).view(torch.uint8).numpy().tobytes())
        elif isinstance(item, dict):
            for key in sorted(item, key=repr):
                digest.update(repr(key).encode())
                visit(item[key])
        elif isinstance(item, (list, tuple)):
            digest.update(str(len(item)).encode())
            for entry in item:
                visit(entry)
        else:
            digest.update(json.dumps(item, sort_keys=True, allow_nan=False).encode())
    visit(value)
    return digest.hexdigest()


def migrate_checkpoint(source, destination, source_config, new_config):
    source_sha = hashlib.sha256(source.read_bytes()).hexdigest()
    state = torch.load(source, map_location='cpu', weights_only=True)
    if state['config_sha256'] != hashlib.sha256(source_config.read_bytes()).hexdigest():
        raise ValueError('source checkpoint configuration differs')
    if not state['values'] or len(state['values']) != len(state['shuffle_hashes']):
        raise ValueError('incomplete history/shuffle binding')
    if len(state['train_metrics']) != len(state['values']):
        raise ValueError('incomplete per-epoch training history')
    def check_finite(item):
        if isinstance(item, torch.Tensor):
            if not bool(torch.isfinite(item).all()):
                raise ValueError('checkpoint contains nonfinite tensor state')
        elif isinstance(item, dict):
            for value in item.values():
                check_finite(value)
        elif isinstance(item, (list, tuple)):
            for value in item:
                check_finite(value)
    check_finite(state)
    before = state_hash({k: v for k, v in state.items() if k != 'config_sha256'})
    state['config_sha256'] = hashlib.sha256(new_config.read_bytes()).hexdigest()
    torch.save(state, destination)
    restored = torch.load(destination, map_location='cpu', weights_only=True)
    if state_hash({k: v for k, v in restored.items() if k != 'config_sha256'}) != before:
        raise ValueError('checkpoint migration changed training state')
    if hashlib.sha256(source.read_bytes()).hexdigest() != source_sha:
        raise ValueError('source checkpoint changed during migration')
    return {'source_checkpoint_sha256': source_sha,
            'recovery_checkpoint_sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
            'training_state_semantic_sha256': before, 'epochs_preserved': len(state['values']),
            'source_config_sha256': hashlib.sha256(source_config.read_bytes()).hexdigest(),
            'recovery_config_sha256': state['config_sha256']}


def main():
    fault = read(ROOT / 'records/source_stall_evidence.json')
    job = str(read(PARENT / 'records/scheduler_jobs.json')[CASE])
    if fault['status'] != 'technical_training_stall_confirmed' or fault['job_id'] != job:
        raise ValueError('current source job not bound to confirmed stall')
    queue = subprocess.run(['squeue', '-h', '-j', job, '-o', '%i|%T'],
                           capture_output=True, text=True)
    if queue.stdout.strip() or (queue.returncode and 'invalid job id' not in queue.stderr.lower()):
        raise ValueError('source allocation may still be active; no duplicate continuation')
    account = subprocess.run(['sacct', '-n', '-X', '-j', job,
                              '--format=JobID,State,ExitCode', '-P'],
                             capture_output=True, text=True, check=True)
    if not any(line.startswith(job + '|CANCELLED') for line in account.stdout.splitlines()):
        raise ValueError('source technical stop not confirmed by accounting')
    stop = read(ROOT / 'records/source_stop_confirmed.json')
    if stop['source_job'] != job or stop['status'] != 'stalled_source_allocation_stopped':
        raise ValueError('authorized technical stop record missing')
    files = sorted([*PARENT.joinpath('src').glob('*.py'),
                    *PARENT.joinpath('scripts').glob('*.py'),
                    *PARENT.joinpath('vendor/pytides').glob('*.py')])
    hashes = {p.relative_to(PARENT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in files}
    old_code = hashlib.sha256(json.dumps(hashes, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    if old_code != OLD_CODE:
        raise ValueError('source code identity differs')
    new_code = code_identity()
    if read(ROOT / 'records/authorization.json')['code_hash'] != new_code:
        raise ValueError('recovery authorization identity differs')
    for name in ('protocol-v3.json', 'registry-v3.json'):
        if (ROOT / 'configs' / name).read_bytes() != (PARENT / 'configs' / name).read_bytes():
            raise ValueError('frozen scientific configuration changed')
    if (PARENT / 'records' / CASE / 'tune_foundation_group_outcome.json').exists():
        raise ValueError('foundation group is completed; do not retrain')
    for split in ('tuning', 'final'):
        dest = ROOT / 'prepared' / split / 'manifest.json'
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(PARENT / 'prepared' / split / 'manifest.json', dest)
    prep_path = PARENT / 'records/data_preparation_complete.json'
    prep = read(prep_path)
    if prep['status'] != 'admitted' or prep['code_hash'] != OLD_CODE:
        raise ValueError('source training data admission differs')
    shutil.copyfile(prep_path, ROOT / 'records/parent_data_preparation_complete.json')
    prep['code_hash'] = new_code
    prep['recovery_reauthentication'] = {
        'source_record_sha256': hashlib.sha256(prep_path.read_bytes()).hexdigest(),
        'source_root': str(PARENT), 'unchanged_manifests': True, 'no_data_or_tide_refit': True}
    write(ROOT / 'records/data_preparation_complete.json', prep)
    old_configs = read(PARENT / 'records' / CASE / 'tune_foundation_group_configs.json')
    if set(old_configs) != set(fault['members']) or len(old_configs) != 3:
        raise ValueError('complete registered foundation members differ')
    configs = copy.deepcopy(old_configs)
    migrations = []
    for run, config in configs.items():
        source = PARENT / 'runs' / run
        dest = ROOT / 'runs' / run
        if read(source / 'config.json') != old_configs[run]:
            raise ValueError('source frozen group configuration differs')
        if hashlib.sha256((source / 'config.json').read_bytes()).hexdigest() != fault['members'][run]['config']['sha256']:
            raise ValueError('source configuration changed since fault evidence')
        if config['effective_config']['code_hash'] != OLD_CODE:
            raise ValueError('source configuration code differs')
        if (source / 'failure.json').exists():
            raise ValueError('additional failure appeared; preserve and diagnose instead of bypassing')
        if (source / 'continuation.pt').stat().st_mtime_ns != fault['members'][run]['continuation_checkpoint_stat']['mtime_ns']:
            raise ValueError('source checkpoint advanced since confirmed stall')
        dest.mkdir()
        config['effective_config']['code_hash'] = new_code
        write(dest / 'config.json', config)
        row = migrate_checkpoint(source / 'continuation.pt', dest / 'continuation.pt',
                                 source / 'config.json', dest / 'config.json')
        if row['epochs_preserved'] != fault['members'][run]['metrics']['completed_epochs']:
            raise ValueError('source checkpoint and observed history length differ')
        shutil.copyfile(source / 'metrics.json', dest / 'metrics.json')
        row.update(run=run, source_checkpoint=str(source / 'continuation.pt'),
                   recovery_checkpoint=str(dest / 'continuation.pt'),
                   only_checkpoint_metadata_change='config_sha256', source_evidence_preserved=True)
        migrations.append(row)
    write(ROOT / 'records' / CASE / 'tune_foundation_group_configs.json', configs)
    write(ROOT / 'records/recovery_preparation_complete.json', {
        'status': 'authenticated_continuation_prepared', 'case': CASE,
        'source_job': job, 'parent_root': str(PARENT), 'parent_code_hash': OLD_CODE,
        'recovery_code_hash': new_code, 'migrations': migrations,
        'scientific_protocol_unchanged': True, 'source_checkpoints_preserved': True,
        'evaluation_values_read': False})
    print(json.dumps({'status': 'authenticated_continuation_prepared', 'case': CASE,
                      'epochs_preserved': [m['epochs_preserved'] for m in migrations],
                      'code_hash': new_code}), flush=True)


if __name__ == '__main__':
    main()
