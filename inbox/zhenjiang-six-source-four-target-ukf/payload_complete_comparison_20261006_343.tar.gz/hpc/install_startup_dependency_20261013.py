"""Install isolated pytest dependencies and admit the unchanged continuation.

Run from the registered recovery root after the authenticated payload deploy.
Writes only new hpc runtime files and records; never edits training sources.
"""
import datetime
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REPAIR = "startup_dependency_repair_20261013_001"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def main():
    manifest = json.loads((ROOT / "records" / (REPAIR + "_manifest.json")).read_text())
    sys.path.insert(0, str(ROOT))
    from src.scheduler import code_identity
    auth = json.loads((ROOT / "records/authorization.json").read_text())
    assert code_identity(ROOT) == auth["code_hash"] == manifest["code_hash"]
    assert sha(ROOT / "configs/protocol-v3.json") == auth["protocol_sha256"]
    assert sha(ROOT / "hpc/pathfix_gradient_recovery_003.slurm") == manifest["original_script_sha256"]
    assert sys.version_info[:2] == (3, 11)
    audit = json.loads((ROOT / "records" / (REPAIR + "_checkpoint_audit.json")).read_text())["audit"]
    assert len(audit["members"]) == 12 and audit["additional_complete_member_epochs"] == 0
    prep = json.loads((ROOT / "records/recovery_preparation_complete.json").read_text())
    migrations = {item["run"]: item for item in prep["migrations"]}
    for member in audit["members"]:
        folder = ROOT / "runs" / member["run"]
        assert sha(folder / "continuation.pt") == member["current_checkpoint_sha256"]
        assert sha(folder / "config.json") == migrations[member["run"]]["recovery_config_sha256"]
        assert member["all_saved_tensors_finite"] and member["all_source_histories_preserved"]
        assert member["minimum_added_optimizer_steps"] == 0 and not member["current_parameters_differ"]
        assert not (folder / "failure.json").exists()
        for name, expected in migrations[member["run"]]["source_files"].items():
            source = Path(migrations[member["run"]]["source_root"]) / "runs" / member["run"] / name
            assert sha(source) == expected
    reuse = json.loads((ROOT / "records/completed_group_reuse.json").read_text())
    outcome_path = Path(reuse["source"])
    assert sha(outcome_path) == reuse["sha256"]
    outcome = json.loads(outcome_path.read_text())
    assert set(outcome["members"]) == set(reuse["members"]) and len(reuse["members"]) == 3
    completed = []
    for name, result in outcome["members"].items():
        values = result["validation_mae"]
        assert result["epochs"] == len(values) == 400 and result["budget_final"] is True
        assert all(math.isfinite(value) for value in values)
        assert result["best_epoch"] == values.index(min(values)) + 1
        point = Path(result["checkpoint_path"])
        assert sha(point) == result["checkpoint_sha256"]
        completed.append({"run": name, "epochs": 400, "best_epoch": result["best_epoch"],
                          "checkpoint_sha256": result["checkpoint_sha256"],
                          "history_sha256": hashlib.sha256(json.dumps(values, separators=(",", ":")).encode()).hexdigest()})
    runtime = ROOT / "hpc/startup_dependency_runtime_20261013_v1"
    assert not runtime.exists(), "Existing runtime requires reading its saved outcome; do not reinstall blindly"
    wheels = []
    for item in manifest["wheels"]:
        wheel = ROOT / "hpc/startup_dependency_wheels_20261013_v1" / item["wheel"]
        assert sha(wheel) == item["sha256"]
        wheels.append(str(wheel))
    before = {name: importlib.metadata.version(name) for name in ("torch", "numpy", "packaging")}
    command = [sys.executable, "-B", "-m", "pip", "install", "--no-index", "--no-deps",
               "--no-compile", "--disable-pip-version-check", "--target", str(runtime), *wheels]
    process = subprocess.run(command, capture_output=True, text=True, timeout=120)
    save(ROOT / "records" / (REPAIR + "_installation.json"),
         {"returncode": process.returncode, "stdout": process.stdout, "stderr": process.stderr})
    assert process.returncode == 0
    environment = dict(os.environ, PYTHONPATH=str(runtime) + os.pathsep + os.environ.get("PYTHONPATH", ""))
    check = subprocess.run([sys.executable, "-B", "-m", "pytest", "--version"],
                           capture_output=True, text=True, env=environment, timeout=30)
    assert check.returncode == 0 and check.stdout.strip() == "pytest 8.3.5"
    after = {name: importlib.metadata.version(name) for name in before}
    assert before == after and importlib.util.find_spec("pytest") is None
    files = {str(path.relative_to(runtime)): sha(path) for path in sorted(runtime.rglob("*")) if path.is_file()}
    record = {"status": "isolated_startup_dependencies_ready_continuation_admitted",
              "checked_at_beijing": datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
              "source_failed_job": manifest["source_failed_job"], "runtime": str(runtime),
              "runtime_files": files, "global_training_packages_before": before,
              "global_training_packages_after": after, "pytest_version": check.stdout.strip(),
              "checkpoint_audit_receipt": manifest["checkpoint_audit_receipt"],
              "checkpoint_members": audit["members"], "completed_group_members": completed,
              "completed_group_seal": outcome["seal"], "preserved_completed_member_epochs": 1200,
              "code_hash": auth["code_hash"], "protocol_sha256": auth["protocol_sha256"],
              "scientific_rules_changed": False, "evaluation_values_read": False,
              "formal_recovery_confirmed": False}
    save(ROOT / "records" / (REPAIR + "_ready.json"), record)
    print(json.dumps({key: value for key, value in record.items() if key != "runtime_files"}), flush=True)


if __name__ == "__main__":
    main()
