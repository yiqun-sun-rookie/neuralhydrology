"""Original 39 allocated-GPU checks plus the authenticated factor kernel."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
import torch
from compensated_factor_kernel import compensated_cholesky,tensor_sha
ROOT=Path(__file__).resolve().parents[1]
spec=json.loads((ROOT/'diagnostic_spec.json').read_bytes());source=Path(spec['source_root'])
assert all(hashlib.sha256((source/name).read_bytes()).hexdigest()==h for name,h in spec['source_code_file_hashes'].items())
assert all(hashlib.sha256((source/name).read_bytes()).hexdigest()==h for name,h in spec['bootstrap_test_sha256'].items())
parent=Path(spec['parent_gate_result_path']);assert hashlib.sha256(parent.read_bytes()).hexdigest()==spec['parent_gate_result_sha256']
proof=json.loads(parent.read_bytes());assert proof['saved_matrix_gate_passed'] and proof['gradient_gate_passed']
receipt=ROOT/'records/bootstrap_original39_acceptance.json';assert not receipt.exists()
env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1';env['ZHENJIANG_TEST_DEVICE']='cuda'
env['ZHENJIANG_ACCEPTANCE_RECEIPT']=str(receipt)
runtime='/data1/home/sunyiq/zhenjiang_complete_comparison_20261012_recovery_003/hpc/startup_dependency_runtime_20261013_v1'
env['PYTHONPATH']=runtime+os.pathsep+str(source)+(os.pathsep+env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
command=[sys.executable,'-B','-m','pytest','tests/test_gradient_recovery.py','tests/test_training.py','tests/test_numerical_recovery.py','tests/test_joseph_recovery.py','-q','-p','no:cacheprovider','--basetemp',str(ROOT/'records/bootstrap_temp')]
p=subprocess.run(command,cwd=source,env=env,capture_output=True,text=True,timeout=600)
with (ROOT/'records/bootstrap_original39_output.json').open('x') as f:json.dump({'command':command,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr},f)
assert p.returncode==0,p.stdout+p.stderr
acceptance=json.loads(receipt.read_bytes());assert acceptance['exit_status']==0 and acceptance['tests_collected']==39
assert acceptance['formal_training_steps']==acceptance['real_data_optimizer_steps']==acceptance['raw_evaluation_year_reads']==0
assert any(x['test']=='authenticated_original_joseph_path' for x in acceptance['actual_gpu_checks'])
torch.use_deterministic_algorithms(True);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
props=torch.cuda.get_device_properties(0);assert props.name=='NVIDIA GeForce RTX 3090' and props.total_memory==25296044032
raw_path=Path(spec['saved_operands_path']);assert hashlib.sha256(raw_path.read_bytes()).hexdigest()==spec['saved_operands_sha256']
raw=torch.load(raw_path,map_location='cpu',weights_only=True)
frames={v['function']:v for v in raw['original_failure_traceback_frames']}
matrix=frames['linear_update']['tensors']['p'][10].to('cuda:0')
assert tensor_sha(matrix)=='28cd4b4b299b36ea15111abbb0f9aa17f1ab498f319753cbfdb9080f0dc0d337'
factor,observation=compensated_cholesky(matrix)
assert observation['positive'] and tensor_sha(factor)=='37c9b10395677d494f96c542f7c12ccaf5c10a09bcccd25922f0832dcd508984'
assert all(hashlib.sha256((source/name).read_bytes()).hexdigest()==h for name,h in spec['bootstrap_test_sha256'].items())
out={'status':'original39_and_compensated_factor_bootstrap_passed','original_test_count':39,'original_acceptance_sha256':hashlib.sha256(receipt.read_bytes()).hexdigest(),'saved_factor_sha256':tensor_sha(factor),'parent_gate_result_sha256':spec['parent_gate_result_sha256'],'formal_epochs_added':0,'evaluation_values_read':False}
with (ROOT/'records/compensated_validation_bootstrap.json').open('x') as f:json.dump(out,f,sort_keys=True)
print(json.dumps(out),flush=True)
