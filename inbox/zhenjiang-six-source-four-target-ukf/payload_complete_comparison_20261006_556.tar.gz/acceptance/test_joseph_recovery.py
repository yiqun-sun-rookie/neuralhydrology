"""Exercise the production path on the authenticated original failed operands."""
import hashlib
import json
import os
from pathlib import Path

import pytest
import torch

from src import differentiable_filter as filtering


@pytest.mark.skipif(os.environ.get('ZHENJIANG_TEST_DEVICE')!='cuda',reason='matching allocated GPU acceptance only')
def test_authenticated_original_joseph_path(device_evidence):
    root=Path('/data1/home/sunyiq/zhenjiang_complete_comparison_20261015_recovery_005')
    intent=json.loads((root/'records/covariance_recovery_intent_20261015.json').read_bytes())
    path=Path('/data1/home/sunyiq/zhenjiang_validation_posterior_diagnostic_20261015_001/evidence/posterior_covariance_original_operands.pt')
    assert hashlib.sha256(path.read_bytes()).hexdigest()=='59bfa304af91eab58ebb9396fab4ff0a4ea9477c12cc9f7bfde3e0a0a2f30187'
    assert torch.cuda.is_available()
    properties=torch.cuda.get_device_properties(0)
    profile=json.loads(Path(os.environ['ZHENJIANG_A40_HARDWARE_PROFILE']).read_bytes())
    assert properties.name=='NVIDIA A40' and properties.total_memory==profile['actual_device_identity']['total_memory_bytes'] and [properties.major,properties.minor]==[8,6]
    raw=torch.load(path,map_location='cpu',weights_only=True)
    values={k:v.to('cuda:0') for k,v in raw['actual_linear_update_locals'].items()}
    assert raw['context']['validation_batch_index']==93 and raw['context']['analysis_step']==24
    ledger=filtering.StabilityLedger()
    with torch.no_grad():
        mean,covariance=filtering.linear_update(values['mean'],values['covariance'],
            values['observation'],values['matrix'][0],values['offset'],values['r_diagonal'][0],ledger)
    assert torch.equal(mean,values['posterior'])
    assert bool(torch.isfinite(covariance).all()) and covariance.dtype==torch.float64
    for member in range(16):
        if member!=11:assert torch.equal(covariance[member],values['p'][member])
    digest=hashlib.sha256(covariance[11].cpu().numpy().tobytes()).hexdigest()
    assert digest=='ac170e7cca935a07754691ccdbd89bb5f036131af4afc5a6b836af613cab2009'
    assert filtering.JITTERS==tuple(raw['original_jitters']) or list(filtering.JITTERS)==raw['original_jitters']
    assert all(float(j) in raw['original_jitters'] for group in ledger.current_jitter for j in group)
    device_evidence.append({'test':'authenticated_original_joseph_path','device':'cuda:0',
        'source_failed_job':'242609','source_saved_epoch':44,'production_code_hash':intent['recovery_code_hash'],
        'raw_operands_sha256':'59bfa304af91eab58ebb9396fab4ff0a4ea9477c12cc9f7bfde3e0a0a2f30187',
        'unchanged_normal_members':15,'repaired_member':11,'reference_sha256':digest,
        'formal_optimizer_updates':0,'evaluation_year_reads':0})
