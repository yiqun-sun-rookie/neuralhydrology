"""Original39 and actual new production operation before any formal training."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parents[1]
intent=json.loads((ROOT/'records/covariance_recovery_intent_20261015.json').read_bytes())
source=Path(intent['source_root']);job=os.environ['SLURM_JOB_ID']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(source/p)==h for p,h in intent['source_code_file_hashes'].items())
assert all(sha(p)==h for p,h in intent['pinned_source_files'].items())
props=torch.cuda.get_device_properties(0)
assert props.name=='NVIDIA A40' and [props.major,props.minor]==[8,6] and props.total_memory>=25296044032
profile={'status':'authorized_A40_hardware_measured_before_computation','actual_device_identity':{'device':'cuda:0','name':props.name,'total_memory_bytes':props.total_memory},'capability':[props.major,props.minor],'source_device_identity':{'device':'cuda:0','name':'NVIDIA GeForce RTX 3090','total_memory_bytes':25296044032},'job_id':job,'node':os.environ.get('SLURMD_NODENAME'),'authority_sha256':sha(ROOT/'hardware_authority.json')}
profile_path=ROOT/'records'/('a40_hardware_binding_'+job+'.json')
with profile_path.open('x') as f:json.dump(profile,f,sort_keys=True)
receipt=ROOT/'records'/('bootstrap_original39_'+job+'.json')
env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1';env['ZHENJIANG_TEST_DEVICE']='cuda'
env['ZHENJIANG_ACCEPTANCE_RECEIPT']=str(receipt)
env['ZHENJIANG_A40_HARDWARE_PROFILE']=str(profile_path)
runtime='/data1/home/sunyiq/zhenjiang_complete_comparison_20261012_recovery_003/hpc/startup_dependency_runtime_20261013_v1'
env['PYTHONPATH']=runtime+os.pathsep+str(source)
command=[sys.executable,'-B','-m','pytest',str(ROOT/'acceptance/test_gradient_recovery.py'),str(ROOT/'acceptance/test_training.py'),str(ROOT/'acceptance/test_numerical_recovery.py'),str(ROOT/'acceptance/test_joseph_recovery.py'),'-q','-p','no:cacheprovider','--basetemp',str(ROOT/'records'/('bootstrap_temp_'+job))]
p=subprocess.run(command,cwd=source,env=env,capture_output=True,text=True,timeout=600)
with (ROOT/'records'/('bootstrap_original39_output_'+job+'.json')).open('x') as f:json.dump({'command':command,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr},f)
assert p.returncode==0,p.stdout+p.stderr
acceptance=json.loads(receipt.read_bytes());assert acceptance['exit_status']==0 and acceptance['tests_collected']==39
assert acceptance['formal_training_steps']==acceptance['real_data_optimizer_steps']==acceptance['raw_evaluation_year_reads']==0
assert any(x['test']=='authenticated_original_joseph_path' for x in acceptance['actual_gpu_checks'])
torch.set_num_threads(4);torch.use_deterministic_algorithms(True)
torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
props=torch.cuda.get_device_properties(0)
assert props.name=='NVIDIA A40' and props.total_memory==profile['actual_device_identity']['total_memory_bytes'] and [props.major,props.minor]==[8,6]
sys.path.insert(0,'/data1/home/sunyiq/zhenjiang_complete_comparison_20261016_recovery_006')
from src import differentiable_filter as filtering
from src.compensated_factor import tensor_sha
raw_path=Path(intent['saved_operands_path']);assert sha(raw_path)==intent['saved_operands_sha256']
raw=torch.load(raw_path,map_location='cpu',weights_only=True)
frames={v['function']:v for v in raw['original_failure_traceback_frames']}
v={k:x.to('cuda:0') for k,x in frames['linear_update']['tensors'].items()}
original=v['p'];assert tensor_sha(original[10])=='28cd4b4b299b36ea15111abbb0f9aa17f1ab498f319753cbfdb9080f0dc0d337'
ledger=filtering.StabilityLedger()
with torch.no_grad():
 factor=filtering.stable_cholesky(original,ledger)
 mean,covariance=filtering.linear_update(v['mean'],v['covariance'],v['observation'],v['matrix'],v['offset'],v['r_diagonal'],filtering.StabilityLedger())
assert tensor_sha(factor[10])=='37c9b10395677d494f96c542f7c12ccaf5c10a09bcccd25922f0832dcd508984'
assert torch.equal(covariance,original) and torch.equal(mean,v['posterior'])
assert list(filtering.JITTERS)==raw['original_jitters']
for index in range(16):
 if index!=10:
  ordinary=filtering._ordinary_stable_cholesky(original[index:index+1])[0]
  assert torch.equal(ordinary,factor[index])
assert len(ledger.current_jitter)==1 and not bool(ledger.current_jitter[0].any())
a=original[10].detach().clone().requires_grad_(True)
f=filtering.stable_cholesky(a[None])[0]
positions=torch.arange(f.numel(),dtype=torch.float64,device='cuda:0').reshape_as(f)
coefficient=torch.tril(torch.sin(positions+1)/(f.detach().abs().clamp_min(1)))
(f*coefficient).sum().backward();assert bool(torch.isfinite(a.grad).all())
assert all(sha(source/p)==h for p,h in intent['source_code_file_hashes'].items())
assert all(sha(p)==h for p,h in intent['pinned_source_files'].items())
out={'status':'a40_hardware_bound_original39_and_actual006_production_passed','actual_hardware_profile':profile,'only_test_assertion_changed':'declared_GPU_identity_metadata','job_id':job,
 'original_tests':39,'original_acceptance_sha256':sha(receipt),'new_production_source_code':intent['recovery_code_hash'],
 'original_matrix_sha256':tensor_sha(original[10]),'factor_sha256':tensor_sha(factor[10]),
 'unchanged_ordinary_members':15,'original_posterior_and_mean_bitwise_preserved':True,
 'gradient_finite':True,'formal_epochs_added':0,'evaluation_values_read':False}
with (ROOT/'records'/('a40_original39_and_production_'+job+'.json')).open('x') as f:json.dump(out,f,sort_keys=True)
print(json.dumps(out),flush=True)
