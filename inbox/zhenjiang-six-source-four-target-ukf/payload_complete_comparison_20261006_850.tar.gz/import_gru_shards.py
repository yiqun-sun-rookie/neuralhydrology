"""Import exactly five completed canonical GRU foundation members from two shards.

HPC usage: python -B import_gru_shards.py --bundle-root /absolute/bundle
Bundle layout: cloud/complete, cloud/ARCHIVE_MANIFEST.json, and corresponding
g15 paths. Validates original scientific identities and all full-state bytes,
then creates the original complete five-member seal; never trains a model.
"""
import argparse
import copy
from dataclasses import asdict
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/data1/home/sunyiq/zhenjiang_complete_comparison_fixed200_20261019_003/sqrt_gru_recovery')
CASE = 'explicit_gru__historical_capacity'
GROUP = CASE+'__final_foundation_group'
ASSIGNMENTS = {'cloud':[17,29], 'g15':[43,61,89]}

def read(p):
    return json.loads(Path(p).read_bytes())

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def atomic(p, v):
    p = Path(p);tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n');tmp.replace(p)

def main():
    p = argparse.ArgumentParser(description=__doc__);p.add_argument('--bundle-root',type=Path,required=True)
    bundle = p.parse_args().bundle_root.resolve(strict=True)
    sys.path.insert(0,str(ROOT))
    from src.scheduler import code_identity,digest_json,seal_group,load_tuning_foundation_source
    record = ROOT/'records'/CASE
    receipt_path = record/'external_gru_foundation_import_20261028.json'
    assert not receipt_path.exists(), 'already imported: consume original receipt, do not import again'
    assert not (record/'final_foundation_group_outcome.json').exists()
    reservation = read(record/'external_final_foundation_20261028.json')
    assert reservation['group'] == GROUP and reservation['assignments'] == ASSIGNMENTS
    auth = read(ROOT/'records/authorization.json')
    assert code_identity(ROOT) == auth['code_hash'] == reservation['source_code_hash']
    phase = read(record/'progress.json')['group']
    assert phase in (CASE+'__tune_branch_group',GROUP)
    if phase == GROUP:
        q = subprocess.run(['/usr/local/globle/softs/slurm/19.05.4.1/bin/squeue','-h','-u','sunyiq','-o','%i|%T|%Z'],text=True,capture_output=True,check=True,timeout=30)
        assert not any(line.endswith('|'+str(ROOT)) for line in q.stdout.splitlines()), 'phase boundary still has a writer'
        assert any(record.glob('external_stage_wait_*.json'))
    registry = read(ROOT/'configs/registry-v3.json')
    expected = {r['exp_id']:r for r in registry['runs'] if r['budget_group'] == GROUP}
    assert len(expected) == 5 and sorted(r['seed'] for r in expected.values()) == [17,29,43,61,89]
    assert all(not (ROOT/'runs'/name).exists() for name in expected), 'canonical member already started'
    original = load_tuning_foundation_source(CASE+'__tune_foundation_group__seal')
    winner = min(original['members'],key=lambda k:(min(original['members'][k]['validation_mae']),original['members'][k]['learning_rate']))
    rate = original['members'][winner]['learning_rate']
    prep = read(ROOT/'records/data_preparation_complete.json')['reports']['final']
    members, configs, sources, origins = {}, {}, {}, {}
    statistics = calendar = None
    for host,seeds in ASSIGNMENTS.items():
        source = bundle/host/'complete'
        manifest = read(bundle/host/'ARCHIVE_MANIFEST.json')
        for row in manifest['files']:
            path = source/row['path']
            assert path.resolve().is_relative_to(source.resolve())
            assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256']
        assert read(source/'EXIT.json')['exit_code'] == 0
        execution = read(source/'EXECUTION.json');outcome=read(source/'shard_outcome.json')
        assert execution['case'] == CASE and execution['seeds'] == seeds and execution['epochs_total'] == 200
        assert execution['source_code_hash'] == auth['code_hash']
        assert execution['source_protocol_sha256'] == sha(ROOT/'configs/protocol-v3.json') == auth['protocol_sha256']
        assert execution['selected_foundation_source'] == winner and execution['learning_rate'] == rate
        assert not execution['source400_rerun'] and not execution['years_2023_2024_read']
        device = execution['execution_device']
        assert device['name'] == ('NVIDIA GeForce RTX 4090' if host=='cloud' else 'NVIDIA GeForce RTX 3060 Laptop GPU')
        checked_reservation = read(source/'HPC_RESERVATION_VERIFIED.json')
        assert checked_reservation['authorization_sha256'] == reservation['authorization_sha256']
        assert sha(source/'AUTHORIZATION.json') == reservation['authorization_sha256']
        assigned = {name for name,r in expected.items() if r['seed'] in seeds}
        assert set(outcome['members']) == assigned and not outcome['canonical_group_complete']
        assert outcome['assigned_seeds'] == seeds and outcome['canonical_group'] == GROUP
        checked = seal_group(outcome['shard_group']+'__seal',outcome['members'],200,expected_members=list(assigned))
        assert digest_json(asdict(checked)) == digest_json(outcome['seal'])
        assert digest_json(outcome['statistics']) == prep['normalization_hash']
        assert outcome['calendar']['training'] == prep['eligible_windows']['final_train']
        assert outcome['calendar']['validation'] == prep['eligible_windows']['final_select']
        if statistics is not None:
            assert statistics == outcome['statistics'] and calendar == outcome['calendar']
        statistics,calendar = outcome['statistics'],outcome['calendar']
        shard_configs = read(source/'final_foundation_group_configs.json')
        assert set(shard_configs) == assigned
        for name,m in outcome['members'].items():
            folder = source/'runs'/name
            assert m['case'] == CASE and m['seed'] == expected[name]['seed'] and m['method'] == 'foundation'
            head = read(folder/'checkpoint_head.json')
            assert head['completed_epochs'] == 200 and sha(folder/'continuation.pt') == head['checkpoint_sha256']
            assert sha(folder/'best.pt') == m['checkpoint_sha256']
            assert read(folder/'metrics.json')['validation_mae_cm'] == m['validation_mae']
            assert digest_json(read(folder/'whitening.json')) == m['whitening_hash']
            config = read(folder/'config.json')
            assert config == shard_configs[name] and config['registration'] == expected[name]
            assert config['effective_config']['code_hash'] == auth['code_hash']
            assert config['effective_config']['device_identity'] == device and m['device_identity'] == device
            assert config['effective_config']['learning_rate'] == rate
            assert name not in members
            members[name]=copy.deepcopy(m);configs[name]=config;sources[name]=folder
            origins[name]={'host':host,'device_identity':device,'original_checkpoint_path':m['checkpoint_path'],
                           'original_shard_outcome_sha256':sha(source/'shard_outcome.json')}
    assert set(members) == set(expected)
    full_original = {'members':members,'statistics':statistics,'calendar':calendar,
                     'seal':asdict(seal_group(GROUP+'__seal',members,200,expected_members=list(expected))),
                     'execution_provenance':origins}
    derived = copy.deepcopy(full_original)
    for name,m in derived['members'].items():m['checkpoint_path']=str(ROOT/'runs'/name/'best.pt')
    derived['seal']=asdict(seal_group(GROUP+'__seal',derived['members'],200,expected_members=list(expected)))
    staging = record/'external_gru_foundation_import_staging_20261028'
    staging.mkdir(exist_ok=False)
    for name in sorted(expected):shutil.copytree(sources[name],staging/name)
    assert read(record/'progress.json')['group'] == phase
    assert all(not (ROOT/'runs'/name).exists() for name in expected)
    frozen_configs = record/'final_foundation_group_configs.json'
    if frozen_configs.exists():
        assert phase == GROUP and any(record.glob('external_stage_wait_*.json'))
        shutil.copyfile(frozen_configs,record/'unstarted_hpc_foundation_configs_before_external_import_20261028.json')
    for name in sorted(expected):(staging/name).rename(ROOT/'runs'/name)
    atomic(record/'external_gru_original_merged_foundation_outcome_20261028.json',full_original)
    atomic(record/'external_gru_foundation_provenance_20261028.json',origins)
    atomic(frozen_configs,configs)
    # Complete group outcome is the last admission write seen by original entry.
    atomic(record/'final_foundation_group_outcome.json',derived)
    result = {'status':'complete_group_imported','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'case':CASE,'group':GROUP,'seeds':[17,29,43,61,89],'epochs_total':200,
              'weights_changed':False,'actual_training_devices_preserved':True,'members':origins,
              'hpc_path_mapped_outcome_sha256':sha(record/'final_foundation_group_outcome.json'),
              'source_code_hash':auth['code_hash'],'existing_hpc_jobs_retained':True,
              'only_result_paths_and_derived_seal_remapped':True,'duplicate_training_required':False}
    atomic(receipt_path,result)
    print('GRU_COMPLETE_IMPORT_JSON '+json.dumps(result),flush=True)

if __name__ == '__main__':
    main()
