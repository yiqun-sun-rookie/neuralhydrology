"""Checkpoint I/O and structural checks; no model, data or training imports."""
import hashlib
import copy
import io
import json
import math
from pathlib import Path
import re
import tempfile

import torch


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def read_stable(path):
    """Hash and deserialize the same bytes, rejecting a concurrent replacement."""
    path = Path(path)
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError('checkpoint input changed while reading: ' + str(path))
    if len(raw) != after.st_size:
        raise ValueError('incomplete checkpoint read: ' + str(path))
    return raw


def _tensors(tree, prefix=''):
    if not isinstance(tree, dict) or not tree:
        raise ValueError('nonempty named tensor state required: ' + prefix)
    result = {}
    for name, value in tree.items():
        key = prefix + str(name)
        if isinstance(value, dict):
            result.update(_tensors(value, key + '.'))
        elif isinstance(value, torch.Tensor):
            if not torch.isfinite(value).all():
                raise ValueError('nonfinite checkpoint tensor: ' + key)
            result[key] = value
        else:
            raise ValueError('unexpected checkpoint value: ' + key)
    return result


def _same_layout(left, right):
    if left.keys() != right.keys():
        raise ValueError('checkpoint parameter names differ')
    for name in left:
        if left[name].shape != right[name].shape or left[name].dtype != right[name].dtype:
            raise ValueError('checkpoint parameter shape/dtype differs: ' + name)


def validate_continuation(state, config_sha256, maximum_epochs=None,
                          expected_current=None, optimizer=None, allow_initialized=False):
    """Check the completed boundary before mutating model/Adam state.

    This checks internal consistency, not scientific source admission. Legacy
    files lack optimizer parameter names; shape checks alone cannot prove their
    historical ordering. Exact configuration/code provenance remains required.
    """
    required = {'current', 'optimizer', 'best', 'values', 'train_metrics',
                'shuffle_hashes', 'config_sha256'}
    if not isinstance(state, dict) or not required.issubset(state):
        raise ValueError('complete continuation fields required; weights-only file rejected')
    if state['config_sha256'] != config_sha256:
        raise ValueError('continuation identity differs')
    values = state['values']
    if (allow_initialized and values == [] and state.get('initialization') == 'fresh-authorized-v1'):
        if state['train_metrics'] != [] or state['shuffle_hashes'] != [] or state['best'] is not None:
            raise ValueError('initialized state must have empty histories and no best')
        current = _tensors(state['current'])
        if expected_current is not None:
            _same_layout(current, _tensors(expected_current))
        if state['optimizer'].get('state') != {} or not state['optimizer'].get('param_groups'):
            raise ValueError('initialized Adam must have no update state')
        if optimizer is not None and state['optimizer'] != optimizer.state_dict():
            raise ValueError('initialized optimizer configuration differs')
        return {'completed_epochs': 0, 'next_epoch': 1, 'classification': 'initialized_fresh',
                'scientific_source_admitted': False}
    if not isinstance(values, list) or not values:
        raise ValueError('nonempty completed epoch history required')
    n = len(values)
    if maximum_epochs is not None and n > maximum_epochs:
        raise ValueError('legacy history exceeds fixed 200 epoch protocol')
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or
           not math.isfinite(v) or v < 0 for v in values):
        raise ValueError('invalid validation history')
    metrics, shuffles = state['train_metrics'], state['shuffle_hashes']
    if (not isinstance(metrics, list) or not isinstance(shuffles, list) or
            len(metrics) != n or len(shuffles) != n):
        raise ValueError('completed history lengths differ')
    if any(not isinstance(e, list) or not e or
           any(not isinstance(batch, dict) for batch in e) for e in metrics):
        raise ValueError('complete per-epoch batch history required')
    if any(not isinstance(s, str) or not re.fullmatch('[0-9a-f]{64}', s) for s in shuffles):
        raise ValueError('complete shuffle hashes required')
    current, best = _tensors(state['current']), _tensors(state['best'])
    _same_layout(current, best)
    if expected_current is not None:
        _same_layout(current, _tensors(expected_current))
    saved = state['optimizer']
    if not isinstance(saved, dict) or not {'state', 'param_groups'}.issubset(saved):
        raise ValueError('complete Adam state required')
    groups, moments = saved['param_groups'], saved['state']
    if not isinstance(groups, list) or not groups or not isinstance(moments, dict):
        raise ValueError('complete Adam groups required')
    ids = [p for group in groups for p in group.get('params', [])]
    if not ids or len(set(ids)) != len(ids) or set(ids) != set(moments):
        raise ValueError('Adam parameter membership differs')
    expected_steps = sum(len(epoch) for epoch in metrics)
    for parameter_id in ids:
        record = moments[parameter_id]
        if not {'step', 'exp_avg', 'exp_avg_sq'}.issubset(record):
            raise ValueError('Adam moments missing')
        step = record['step']
        if isinstance(step, torch.Tensor):
            if step.numel() != 1:
                raise ValueError('invalid Adam step')
            step = step.item()
        if step != expected_steps:
            raise ValueError('Adam step does not match completed batch history')
        avg, square = record['exp_avg'], record['exp_avg_sq']
        if (not isinstance(avg, torch.Tensor) or not isinstance(square, torch.Tensor) or
                avg.shape != square.shape or avg.dtype != square.dtype or
                not torch.isfinite(avg).all() or not torch.isfinite(square).all() or
                (square < 0).any()):
            raise ValueError('invalid Adam moments')
    if optimizer is not None:
        if len(groups) != len(optimizer.param_groups):
            raise ValueError('Adam group count differs')
        for source, target in zip(groups, optimizer.param_groups):
            if len(source['params']) != len(target['params']):
                raise ValueError('Adam group membership differs')
            for key, value in target.items():
                if key != 'params' and source.get(key) != value:
                    raise ValueError('Adam settings differ: ' + key)
            for parameter_id, parameter in zip(source['params'], target['params']):
                if (moments[parameter_id]['exp_avg'].shape != parameter.shape or
                        moments[parameter_id]['exp_avg'].dtype != parameter.dtype):
                    raise ValueError('Adam parameter shape/dtype differs')
    prefix = values[:200]
    first_best = values.index(min(values)) + 1
    prefix_best = prefix.index(min(prefix)) + 1
    return {'completed_epochs': n, 'best_epoch': first_best,
            'first200_best_epoch': prefix_best,
            'inline_best_matches_first200': first_best == prefix_best,
            'next_epoch': n + 1 if n < 200 else None,
            'classification': ('resume_candidate' if n < 200 else
                               'export_only_candidate' if n == 200 else 'legacy_over200'),
            'optimizer_steps': expected_steps,
            'legacy_optimizer_parameter_names_recorded': False,
            'scientific_source_admitted': False}


def load_continuation(run_dir, maximum_epochs=None, map_location='cpu', allow_initialized=False):
    """Require both files; absent checkpoints never become empty histories."""
    run_dir = Path(run_dir)
    config_raw = read_stable(run_dir / 'config.json')
    raw = read_stable(run_dir / 'continuation.pt')
    state = torch.load(io.BytesIO(raw), map_location=map_location, weights_only=True)
    report = validate_continuation(state, sha256(config_raw), maximum_epochs,
                                   allow_initialized=allow_initialized)
    report.update(config_sha256=sha256(config_raw), checkpoint_sha256=sha256(raw),
                  run_dir=str(run_dir.resolve()))
    return state, json.loads(config_raw), report, config_raw, raw


def verify_migration_receipt(run_dir, config_raw, checkpoint_sha256):
    """Bind a prepared copy to the preserved, unchanged source bytes."""
    root = Path(run_dir)
    receipt = json.loads(read_stable(root / 'migration_source.json'))
    if (receipt.get('schema') not in ('checkpoint-migration-candidate-v1', 'checkpoint-migration-candidate-v2') or
            receipt.get('target_config_sha256') != sha256(config_raw) or
            receipt.get('source_config_sha256') != sha256(read_stable(root / 'source_config.json')) or
            receipt.get('source_checkpoint_sha256') != sha256(read_stable(root / 'source_continuation.pt'))):
        raise ValueError('migration source binding differs')
    if receipt['schema'] == 'checkpoint-migration-candidate-v1':
        if receipt.get('target_checkpoint_sha256') != checkpoint_sha256:
            raise ValueError('migration source binding differs')
    else:
        anchor = verify_checkpoint_lineage(root, checkpoint_sha256)
        if (anchor['initial_checkpoint_sha256'] != receipt['target_checkpoint_sha256'] or
                anchor['source_receipt_sha256'] != sha256(read_stable(root / 'migration_source.json'))):
            raise ValueError('migration source binding differs')
    return receipt


def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    temporary.replace(path)


def initialize_lineage(root, checkpoint_raw, config_raw, completed_epochs, source_receipt_sha256=None):
    """Freeze the initial state; only checkpoint/head advance after preparation."""
    root = Path(root)
    (root / 'initial_continuation.pt').write_bytes(checkpoint_raw)
    anchor = {'schema': 'continuation-anchor-v1', 'config_sha256': sha256(config_raw),
              'initial_checkpoint_sha256': sha256(checkpoint_raw), 'initial_epochs': completed_epochs,
              'source_receipt_sha256': source_receipt_sha256}
    with (root / 'continuation_anchor.json').open('x', encoding='utf-8') as handle:
        json.dump(anchor, handle, sort_keys=True, indent=2); handle.write('\n')
    (root / 'checkpoint_events').mkdir()
    atomic_json(root / 'checkpoint_head.json', {'checkpoint_sha256': sha256(checkpoint_raw),
        'completed_epochs': completed_epochs, 'anchor_sha256': sha256(read_stable(root / 'continuation_anchor.json'))})
    return anchor


def publish_fresh_initialization(root, state, config_raw):
    """Publish config and complete N=0 state together before any batch starts."""
    root = Path(root)
    if root.exists(): raise FileExistsError('fresh initialization destination exists')
    validate_continuation(state, sha256(config_raw), 200, allow_initialized=True)
    if state['values'] or state.get('initialization') != 'fresh-authorized-v1':
        raise ValueError('fresh initialization must be N=0')
    with tempfile.TemporaryDirectory(prefix='.initialized-', dir=root.parent) as name:
        temporary = Path(name)
        buffer = io.BytesIO(); torch.save(state, buffer); raw = buffer.getvalue()
        (temporary / 'config.json').write_bytes(config_raw)
        initialize_lineage(temporary, raw, config_raw, 0)
        (temporary / 'continuation.pt').write_bytes(raw)
        if root.exists(): raise FileExistsError('initialization destination appeared')
        temporary.rename(root)


def verify_checkpoint_lineage(root, checkpoint_sha256):
    """Verify source prefix and append-only complete-epoch chain without writing.

    A prepared event is saved before checkpoint replacement and head afterwards.
    A crash between the latter two is accepted only when the current chain
    extends the last committed head. A checkpoint older than that head is refused.
    """
    root = Path(root)
    anchor_raw = read_stable(root / 'continuation_anchor.json')
    anchor, head = json.loads(anchor_raw), json.loads(read_stable(root / 'checkpoint_head.json'))
    initial_raw, current_raw = read_stable(root / 'initial_continuation.pt'), read_stable(root / 'continuation.pt')
    if (anchor.get('schema') != 'continuation-anchor-v1' or sha256(initial_raw) != anchor['initial_checkpoint_sha256'] or
            sha256(current_raw) != checkpoint_sha256 or sha256(read_stable(root / 'config.json')) != anchor['config_sha256'] or
            head['anchor_sha256'] != sha256(anchor_raw)):
        raise ValueError('continuation anchor identity differs')
    initial = torch.load(io.BytesIO(initial_raw), map_location='cpu', weights_only=True)
    current = torch.load(io.BytesIO(current_raw), map_location='cpu', weights_only=True)
    validate_continuation(initial, anchor['config_sha256'], 200, allow_initialized=anchor['initial_epochs'] == 0)
    validate_continuation(current, anchor['config_sha256'], 200, allow_initialized=anchor['initial_epochs'] == 0)
    n, start = len(current['values']), anchor['initial_epochs']
    if len(initial['values']) != start or not start <= head['completed_epochs'] <= n <= 200:
        raise ValueError('continuation progress rolled back or exceeds 200')
    for key in ('values', 'train_metrics', 'shuffle_hashes'):
        if current[key][:start] != initial[key]:
            raise ValueError('preserved initial history differs')
    cursor, epochs, seen_head = checkpoint_sha256, n, False
    while True:
        if cursor == head['checkpoint_sha256']:
            if epochs != head['completed_epochs']:
                raise ValueError('continuation head epoch differs')
            seen_head = True
        if cursor == anchor['initial_checkpoint_sha256']:
            if epochs != start: raise ValueError('initial epoch differs')
            break
        event = json.loads(read_stable(root / 'checkpoint_events' / (cursor[:16] + '.json')))
        if (event.get('schema') != 'complete-epoch-transition-v1' or event['checkpoint_sha256'] != cursor or
                event['anchor_sha256'] != sha256(anchor_raw) or event['completed_epochs'] != epochs or
                event['previous_epochs'] != epochs - 1 or epochs <= start or
                (epochs == n and event['history_sha256'] != digest_json({k:current[k] for k in ('values','train_metrics','shuffle_hashes')}))):
            raise ValueError('complete epoch transition differs')
        parent = event['previous_checkpoint_sha256']
        if parent != anchor['initial_checkpoint_sha256'] and event['previous_event_sha256'] != sha256(
                read_stable(root / 'checkpoint_events' / (parent[:16] + '.json'))):
            raise ValueError('previous transition record changed')
        cursor, epochs = event['previous_checkpoint_sha256'], epochs - 1
    if not seen_head: raise ValueError('current checkpoint does not extend committed head')
    return anchor


def save_complete_checkpoint(root, state):
    """Save one complete epoch, preserving an auditable crash-recoverable chain."""
    root = Path(root)
    if not (root / 'continuation_anchor.json').exists():
        temporary = root / 'continuation.pt.tmp'
        torch.save(state, temporary); temporary.replace(root / 'continuation.pt')
        return
    previous_raw = read_stable(root / 'continuation.pt')
    previous_sha = sha256(previous_raw)
    anchor = verify_checkpoint_lineage(root, previous_sha)
    previous = torch.load(io.BytesIO(previous_raw), map_location='cpu', weights_only=True)
    validate_continuation(state, anchor['config_sha256'], 200)
    n = len(state['values'])
    if n != len(previous['values']) + 1:
        raise ValueError('checkpoint must advance exactly one complete epoch')
    for key in ('values', 'train_metrics', 'shuffle_hashes'):
        if state[key][:-1] != previous[key]: raise ValueError('checkpoint history changed')
    buffer = io.BytesIO(); torch.save(state, buffer); raw = buffer.getvalue(); current_sha = sha256(raw)
    event = {'schema':'complete-epoch-transition-v1', 'checkpoint_sha256':current_sha,
             'previous_checkpoint_sha256':previous_sha, 'previous_epochs':n-1, 'completed_epochs':n,
             'previous_event_sha256':None if previous_sha == anchor['initial_checkpoint_sha256'] else sha256(
                 read_stable(root / 'checkpoint_events' / (previous_sha[:16] + '.json'))),
             'anchor_sha256':sha256(read_stable(root / 'continuation_anchor.json')),
             'history_sha256':digest_json({k:state[k] for k in ('values','train_metrics','shuffle_hashes')})}
    event_path = root / 'checkpoint_events' / (current_sha[:16] + '.json')
    if event_path.exists():
        if json.loads(read_stable(event_path)) != event: raise ValueError('existing transition differs')
    else:
        with event_path.open('x', encoding='utf-8') as handle: json.dump(event, handle, sort_keys=True)
    temporary = root / 'continuation.pt.tmp'; temporary.write_bytes(raw); temporary.replace(root / 'continuation.pt')
    atomic_json(root / 'checkpoint_head.json', {'checkpoint_sha256':current_sha,
        'completed_epochs':n, 'anchor_sha256':event['anchor_sha256']})


def digest_json(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode())


def runtime_code_hash(root):
    root = Path(root)
    files = sorted([*root.joinpath('src').glob('*.py'), *root.joinpath('scripts').glob('*.py'),
                    *root.joinpath('vendor/pytides').glob('*.py')])
    return digest_json({p.relative_to(root).as_posix(): sha256(read_stable(p)) for p in files})


def migration_bindings(runtime_root, case, run_root):
    """Read a complete case's prepared tuning members into a portable hash map."""
    root, run_root = Path(runtime_root), Path(run_root)
    registry = json.loads(read_stable(root / 'configs/registry-v3.json'))
    admission = json.loads(read_stable(root / 'configs/stage_source_admission.json'))
    if case not in admission['allowed_cases']:
        raise ValueError('case not assigned to this runtime')
    protocol_hash = sha256(read_stable(root / 'configs/protocol-v3.json'))
    code_hash = runtime_code_hash(root)
    members = [r for r in registry['runs'] if r['case'] == case and r['type'] == 'tune_branch'
               and r['status'] != 'alias']
    if not members:
        raise ValueError('registered tuning branch members required')
    bindings = {}
    for run in members:
        folder = run_root / run['exp_id']
        if (folder / 'failure.json').exists():
            raise ValueError('failed migration candidate')
        result_only = (folder / 'completed_prefix_result.json').exists()
        if result_only:
            outcome, receipt = load_prefix_result(folder)
            config_raw = read_stable(folder / 'config.json'); config = json.loads(config_raw)
            report = {'config_sha256':sha256(config_raw), 'checkpoint_sha256':outcome['checkpoint_sha256']}
        else:
            _, config, report, config_raw, _ = load_continuation(folder, 200)
        if (config.get('registration') != run or config.get('protocol_sha256') != protocol_hash or
                config.get('status') != 'frozen_authorized' or
                config['effective_config'].get('code_hash') != code_hash or
                not config['effective_config'].get('continuation_required')):
            raise ValueError('migration candidate registration/protocol/code differs')
        if not result_only: receipt = verify_migration_receipt(folder, config_raw, report['checkpoint_sha256'])
        bindings[run['exp_id']] = {'config_sha256': report['config_sha256'],
            'checkpoint_sha256': receipt.get('target_checkpoint_sha256', report['checkpoint_sha256']),
            'member_kind':'completed_prefix_result' if result_only else 'continuation',
            'receipt_sha256': sha256(read_stable(folder / 'migration_source.json'))}
    return {'schema': 'fixed200-migration-bindings-v1', 'case': case,
            'protocol_sha256': protocol_hash, 'code_hash': code_hash, 'members': bindings}


def bind_migration_configs(configs, bindings, run_root):
    """Preserve the required flag and reject a regenerated/configured mismatch."""
    if set(configs) != set(bindings['members']):
        raise ValueError('complete migration group required; no fresh fallback')
    result = copy.deepcopy(configs)
    for member, expected in result.items():
        expected['effective_config']['continuation_required'] = True
        folder = Path(run_root) / member
        raw = read_stable(folder / 'config.json')
        pin = bindings['members'][member]
        if sha256(raw) != pin['config_sha256'] or json.loads(raw) != expected:
            raise ValueError('migration configuration differs from regenerated configuration')
        if sha256(read_stable(folder / 'migration_source.json')) != pin['receipt_sha256']:
            raise ValueError('migration candidate changed after preflight')
        if pin.get('member_kind') == 'completed_prefix_result':
            outcome, _ = load_prefix_result(folder)
            if outcome['checkpoint_sha256'] != pin['checkpoint_sha256']:
                raise ValueError('completed result checkpoint differs')
        else:
            receipt = verify_migration_receipt(folder, raw, sha256(read_stable(folder / 'continuation.pt')))
            if receipt['target_checkpoint_sha256'] != pin['checkpoint_sha256']:
                raise ValueError('initial migration checkpoint differs')
    return result


def load_prefix_result(root):
    """Validate a completed first-200 result; never creates optimizer state."""
    root = Path(root)
    config_raw = read_stable(root / 'config.json')
    receipt_raw = read_stable(root / 'migration_source.json')
    receipt = json.loads(receipt_raw)
    record = json.loads(read_stable(root / 'completed_prefix_result.json'))
    if (receipt.get('schema') != 'completed-prefix-source-v1' or
            receipt.get('target_config_sha256') != sha256(config_raw) or
            receipt['result_sha256'] != digest_json(record) or
            receipt['source_config_sha256'] != sha256(read_stable(root / 'source_config.json')) or
            receipt['source_checkpoint_sha256'] != sha256(read_stable(root / 'source_continuation.pt'))):
        raise ValueError('completed result source binding differs')
    source = torch.load(io.BytesIO(read_stable(root / 'source_continuation.pt')), map_location='cpu', weights_only=True)
    validate_continuation(source, receipt['source_config_sha256'])
    outcome = record['outcome']; values = source['values'][:200]
    if (record.get('schema') != 'completed-first200-result-v1' or
            receipt['target_checkpoint_sha256'] != outcome['checkpoint_sha256'] or
            len(values) != 200 or outcome['epochs'] != 200 or not outcome['budget_final'] or
            outcome['status'] != 'success' or outcome['validation_mae'] != values or
            outcome['best_epoch'] != values.index(min(values)) + 1 or
            record['train_metrics'] != source['train_metrics'][:200] or
            outcome['shuffle_hash'] != sha256(''.join(source['shuffle_hashes'][:200]).encode()) or
            sha256(read_stable(root / 'best.pt')) != outcome['checkpoint_sha256']):
        raise ValueError('completed first200 result differs')
    if receipt['selected_source_file'] not in ('source_continuation.pt','source_epoch_200.pt'):
        raise ValueError('unsupported selected best source')
    selected_raw = read_stable(root / receipt['selected_source_file'])
    if sha256(selected_raw) != receipt['selected_source_sha256']:
        raise ValueError('selected best source differs')
    if receipt['selected_source_file'] == 'source_continuation.pt':
        if source['values'].index(min(source['values'])) + 1 != outcome['best_epoch']:
            raise ValueError('inline best is after 200')
        expected = source['best']
    elif receipt['selected_source_file'] == 'source_epoch_200.pt' and outcome['best_epoch'] == 200:
        expected = torch.load(io.BytesIO(selected_raw), map_location='cpu', weights_only=True)
    else: raise ValueError('unsupported selected best source')
    actual = torch.load(io.BytesIO(read_stable(root / 'best.pt')), map_location='cpu', weights_only=True)
    left, right = _tensors(expected), _tensors(actual); _same_layout(left, right)
    if any(not torch.equal(left[k], right[k]) for k in left): raise ValueError('exported best weights differ')
    return outcome, receipt
