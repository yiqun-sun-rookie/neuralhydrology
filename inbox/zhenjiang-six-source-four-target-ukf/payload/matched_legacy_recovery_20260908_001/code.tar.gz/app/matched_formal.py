#!/usr/bin/env python3
"""Run one contract-bound matched legacy training seed on the approved GPU job.

The public command accepts only the immutable execution-contract path, its
trusted SHA-256 digest, and one of the three fixed seeds.  It has no local,
CPU, retry, checkpoint, data-root, year, or evaluation override.

Example::

    python -B matched_formal.py --execution-contract /data1/home/sunyiq/\
zhenjiang_matched_legacy_process_20260908_001/contracts/execution_contract.json \
        --execution-contract-sha256 8c3ef366a8dbbf8b9e18704d1dca8a7bd887ca3afd745a0a9c495ed1a1d709cb \
        --seed 17
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import stat
import sys
from types import ModuleType
from typing import BinaryIO, Callable, Dict, Iterator, Mapping, Optional, Sequence, Tuple, Union

import numpy as np
import torch

import matched_training


FORMAL_PURPOSE = "matched_legacy_training_2017_2021_and_best_epoch_selection_2022"
FORMAL_TIME_PARTITION = "2017-2022"
EXPERIMENT_FAMILY = "ZHENJIANG_MATCHED_LEGACY_PROCESS_MODEL_20260907"
DATA_AUTHORIZATION_ID = "ZJ-MATCHED-LEGACY-DATA-20260908-01"
PAID_AUTHORIZATION_ID = "ZJ-MATCHED-LEGACY-HPC-20260908-01"
SEED_ORDER = (17, 29, 43)
TRAINING_YEARS = (2017, 2018, 2019, 2020, 2021)
SELECTION_YEAR = 2022

REMOTE_ROOT_TEXT = "/data1/home/sunyiq/zhenjiang_matched_legacy_process_20260908_001"
APP_ROOT_TEXT = REMOTE_ROOT_TEXT + "/app"
REFERENCE_ROOT_TEXT = APP_ROOT_TEXT + "/reference"
CONTRACT_ROOT_TEXT = REMOTE_ROOT_TEXT + "/contracts"
INPUT_ROOT_TEXT = (
    "/data1/home/sunyiq/"
    "zhenjiang_5s5t_stage_a_20260905_recovery_001/inputs/2017_2022"
)
EXECUTION_CONTRACT_PATH_TEXT = CONTRACT_ROOT_TEXT + "/execution_contract.json"
DATA_AUTHORIZATION_PATH_TEXT = CONTRACT_ROOT_TEXT + "/data_authorization.json"
PAID_AUTHORIZATION_PATH_TEXT = CONTRACT_ROOT_TEXT + "/paid_execution_authorization.json"
SOURCE_DATA_CONTRACT_PATH_TEXT = CONTRACT_ROOT_TEXT + "/source_data_contract.json"
REFERENCE_MANIFEST_PATH_TEXT = CONTRACT_ROOT_TEXT + "/reference_source_manifest.json"
COMPARISON_PROTOCOL_PATH_TEXT = CONTRACT_ROOT_TEXT + "/comparison_protocol.json"
USAGE_LEDGER_PATH_TEXT = REMOTE_ROOT_TEXT + "/evidence/formal_data_usage.sqlite3"
ATTEMPT_ROOT_TEXT = REMOTE_ROOT_TEXT + "/evidence/seed_attempts"
OUTPUT_ROOT_TEXT = APP_ROOT_TEXT + "/artifacts"
JOB_ATTEMPT_ROOT_TEXT = REMOTE_ROOT_TEXT + "/evidence/job_attempt_001"
SUBMISSION_RECEIPT_PATH_TEXT = REMOTE_ROOT_TEXT + "/evidence/submission_receipt.json"

EXPECTED_EXECUTION_CONTRACT_SHA256 = (
    "8c3ef366a8dbbf8b9e18704d1dca8a7bd887ca3afd745a0a9c495ed1a1d709cb"
)
EXPECTED_DATA_AUTHORIZATION_SHA256 = (
    "9183768515384e2c3dd49af6c1b9709565ee2ddbcb26998b86f55042d154bf65"
)
EXPECTED_PAID_AUTHORIZATION_SHA256 = (
    "39a32bba37ceba3f568c829bb7a4957413cba9d3433f9ad4444e5aa1d2afb6d8"
)
EXPECTED_SOURCE_DATA_CONTRACT_SHA256 = (
    "0e2cc530d5158cb9535862b10d6489436b73811c84a3d601579ed79de28155b3"
)
EXPECTED_REFERENCE_MANIFEST_SHA256 = (
    "5cdfc023f4a581d54443a8eb8ed6a44f3a62cf9ad59e3564d19947cb1c0faf06"
)
EXPECTED_COMPARISON_PROTOCOL_SHA256 = (
    "c1993098b3ee7c936bcc77cb5ae2e5e99c4dd13e45eb17ce23f7835d2217bd43"
)

EXPECTED_TRAINING_SAMPLE_COUNT = 38_073
EXPECTED_SELECTION_SAMPLE_COUNT = 8_032
EXPECTED_MAXIMUM_READS = 36
EXPECTED_MAXIMUM_BYTES = 154_503_999
EXPECTED_NORMALIZATION_SHA256 = {
    "history_stage": "d71c35d2f34e4d754fb2ca05395ca1fcc5b290bbdf74ce5e99c03351a9039897",
    "future_wusongkou_astronomical_tide": "9525962812d2f5b2540771ad48fcba5c6a4a18cebb856ea51e6352e87e388089",
    "future_datong_observed_driver": "82f7a22786a72db66b77ebef9319987bf68be0172c121bd9dca1c5a0e5918595",
    "explicit_stage": "b79ff31ade01a53484038f51995ecf5b9d04e52c9dbf30282423e0cbca16f406",
}
EXPECTED_ENVIRONMENT = {
    "python_version": "3.11.13",
    "torch_version": "2.4.0",
    "numpy_version": "2.3.3",
    "pandas_version": "2.3.2",
    "scipy_version": "1.16.2",
    "psutil_version": "7.0.0",
    "cuda_version": "12.1",
    "cuda_available": True,
    "device_type": "cuda",
    "device_name": "NVIDIA GeForce RTX 3090",
    "compute_capability": [8, 6],
    "minimum_device_memory_bytes": 21_474_836_480,
}

REALTIME_ROLE = "realtime_stage"
TARGET_ROLE = "retrospective_target"
TIDE_ROLE = "wusongkou_astronomical_tide_model"
CSV_SCOPE = "header_plus_2017_2022_rows"
FULL_FILE_SCOPE = "full_file"
FEATURE_FORMAT = "zhenjiang_realtime_feature_csv_v1"
TARGET_FORMAT = "zhenjiang_retrospective_target_csv_v1"
TIDE_FORMAT = "accepted_wusongkou_astronomical_tide_json_v1"
HISTORY_STATIONS = ("datong", "nanjing", "zhenjiang", "jiangyin", "xuliujing", "wusongkou")
TARGET_STATIONS = ("nanjing", "zhenjiang", "jiangyin", "xuliujing", "wusongkou")

REFERENCE_FILE_IDENTITIES = {
    "scripts/analysis/zhenjiang_five_source_five_target_single_analysis_contract_v2.py": (17_466, "ba953d140784a7b0845dd332c64311e344479dbbf5cac98eb57227b97ffdd79a"),
    "scripts/astronomical_tide/wusongkou_astronomical_tide_realtime_v2.py": (14_978, "6a8e45b8988809899ae84febd2e4790a6369acaad88f346bc7f2ddca7f40f5f5"),
    "scripts/modeling/run_zhenjiang_five_source_five_target_stage_a_v2.py": (47_054, "81f4846119447936035fe9b5fcf3169e61df7a0c726db36a1c6f6f878722ffd5"),
    "scripts/modeling/train_zhenjiang_five_source_five_target_d32_gru_v2.py": (26_174, "d2ff8313469019e2065131811c1ffb4c698c904a87f70956cea7aa9ee2455c27"),
    "scripts/modeling/zhenjiang_five_source_five_target_d32_gru_v2.py": (7_549, "3dc45a73dc333156a4d5bd5429028aaaa6e13380904f79ca2d334c25af6d355a"),
    "scripts/modeling/zhenjiang_five_source_five_target_data_v2.py": (71_264, "5126737d395a9cda5a4d7def5714f8582542ad3ace48e0b539bd99acd1f99039"),
    "third_party/pytides/astro.py": (6_036, "d29a2197c24a3e243590f0e7dcf52a2a4266a0951abab08244957711cabaa5bd"),
    "third_party/pytides/constituent.py": (6_405, "fed8fa1a14663391f2f706e8ca70eedddd188321221a7fd8120ddcd01b11846a"),
    "third_party/pytides/nodal_corrections.py": (3_708, "ae6af6c135fe88f90752fd6cf522d6976e5f8f8a29341d719627124dd254989b"),
    "third_party/pytides/tide.py": (13_956, "fbdc9ec80a4bc9741520e73751038ab06db836add2425dbcc420873fde5dcbce"),
}

_SHA256_PATTERN = re.compile(r"[0-9a-f]{64}\Z")
_REFERENCE_CACHE: Dict[Tuple[Path, str], "ReferenceSources"] = {}
_VERIFIED_REFERENCE_MODULES: Dict[Tuple[str, Path], ModuleType] = {}


def _sha256_bytes(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _require_sha256(value: object, name: str) -> str:
    if not isinstance(value, str) or _SHA256_PATTERN.fullmatch(value) is None:
        raise ValueError(name + " must be a lowercase SHA-256 digest")
    return value


def _strict_object(pairs: Sequence[Tuple[str, object]]) -> Mapping[str, object]:
    result: Dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key: " + key)
        result[key] = value
    return result


def _strict_json_bytes(content: bytes, name: str) -> Mapping[str, object]:
    try:
        decoded = content.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ValueError(name + " must be UTF-8") from error
    try:
        document = json.loads(decoded, object_pairs_hook=_strict_object)
    except (TypeError, ValueError, json.JSONDecodeError) as error:
        raise ValueError(name + " must be strict JSON") from error
    if not isinstance(document, Mapping):
        raise ValueError(name + " must contain one JSON object")
    return document


def _read_anchored_json(path: Union[str, Path], trusted_sha256: str, name: str):
    trusted = _require_sha256(trusted_sha256, name + " trusted SHA-256")
    anchored_path = Path(path)
    lexical = Path(os.path.abspath(str(anchored_path)))
    if (
        anchored_path.is_symlink()
        or not anchored_path.is_file()
        or anchored_path.resolve(strict=True) != lexical
    ):
        raise RuntimeError(name + " must be one ordinary unredirected file")
    content = anchored_path.read_bytes()
    actual = _sha256_bytes(content)
    if actual != trusted:
        raise RuntimeError(name + " raw-byte SHA-256 differs from its anchor")
    return _strict_json_bytes(content, name), actual, content


def _require_exact_keys(document: Mapping[str, object], keys: Sequence[str], name: str) -> None:
    expected = set(keys)
    actual = set(document)
    if actual != expected:
        raise ValueError(
            "{} keys differ; missing={}, extra={}".format(
                name, sorted(expected - actual), sorted(actual - expected)
            )
        )


def _require_exact_values(document: Mapping[str, object], expected: Mapping[str, object], name: str) -> None:
    changed = [key for key, value in expected.items() if document.get(key) != value]
    if changed:
        raise ValueError(name + " changed fixed fields: " + ", ".join(changed))


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse_utc(value: object, name: str) -> str:
    if not isinstance(value, str) or not value.endswith("Z"):
        raise ValueError(name + " must be an ISO-8601 universal time ending in Z")
    try:
        datetime.fromisoformat(value[:-1] + "+00:00")
    except ValueError as error:
        raise ValueError(name + " must be valid ISO-8601") from error
    return value


@dataclass(frozen=True, order=True)
class FormalContentSpec:
    role: str
    station: str
    path: str
    byte_offset: int
    byte_count: int
    content_sha256: str
    verification_scope: str
    serialization_format: str

    @classmethod
    def from_document(cls, document: object) -> "FormalContentSpec":
        if not isinstance(document, Mapping):
            raise ValueError("formal content specification must be an object")
        _require_exact_keys(
            document,
            ("role", "station", "path", "byte_offset", "byte_count", "content_sha256", "verification_scope", "serialization_format"),
            "formal content specification",
        )
        value = cls(**dict(document))
        value.validate()
        return value

    def validate(self) -> "FormalContentSpec":
        if self.role not in (REALTIME_ROLE, TARGET_ROLE, TIDE_ROLE):
            raise ValueError("formal content role is unknown")
        if not isinstance(self.station, str) or not self.station:
            raise ValueError("formal content station must be non-empty")
        if (
            not isinstance(self.path, str)
            or not (self.path.startswith("/") or Path(self.path).is_absolute())
        ):
            raise ValueError("formal content path must be absolute")
        if type(self.byte_offset) is not int or self.byte_offset != 0:
            raise ValueError("formal byte offset must be integer zero")
        if type(self.byte_count) is not int or self.byte_count <= 0:
            raise ValueError("formal byte count must be positive")
        _require_sha256(self.content_sha256, "formal content SHA-256")
        expected = {
            REALTIME_ROLE: (CSV_SCOPE, FEATURE_FORMAT),
            TARGET_ROLE: (CSV_SCOPE, TARGET_FORMAT),
            TIDE_ROLE: (FULL_FILE_SCOPE, TIDE_FORMAT),
        }[self.role]
        if (self.verification_scope, self.serialization_format) != expected:
            raise ValueError("formal content scope or serialization format changed")
        return self

    @property
    def range_tuple(self) -> Tuple[str, int, int]:
        return self.path, self.byte_offset, self.byte_count


class ValidatedExecutionContract(dict):
    """Dictionary-compatible fixed contract plus its verified bound documents."""

    def __init__(self, document, *, raw_sha256, bound_documents, bound_raw_sha256):
        super().__init__(document)
        self.raw_sha256 = raw_sha256
        self.bound_documents = bound_documents
        self.bound_raw_sha256 = bound_raw_sha256


@dataclass(frozen=True)
class ReferenceSources:
    root: Path
    manifest: Mapping[str, object]
    manifest_sha256: str
    training: ModuleType
    data: ModuleType
    tide: ModuleType
    runner: ModuleType
    file_identities: Mapping[str, Mapping[str, object]]

    @property
    def AtomicUsageLedger(self):
        return self.data.AtomicUsageLedger


@dataclass(frozen=True)
class SourceDataContract:
    datong_identity: object
    explicit_stage_identity: object
    files: Tuple[FormalContentSpec, ...]


def source_contract_from_document(
    document: Mapping[str, object], reference: ReferenceSources
) -> SourceDataContract:
    """Create only the two frozen identity objects and twelve file specs."""

    specifications = _validated_source_specifications(document)
    datong = document["datong_physical_variable_identity"]
    explicit = document["explicit_stage_physical_variable_identity"]
    return SourceDataContract(
        datong_identity=reference.data.DatongPhysicalVariableIdentity(**dict(datong)),
        explicit_stage_identity=reference.data.FiveTargetStagePhysicalVariableIdentity(
            station_order=tuple(explicit["station_order"]),
            water_level_definition=explicit["water_level_definition"],
            unit=explicit["unit"],
            vertical_datum=explicit["vertical_datum"],
            timestamp_semantics=explicit["timestamp_semantics"],
        ),
        files=specifications,
    )


def _validate_execution_document(document: Mapping[str, object]) -> None:
    _require_exact_keys(
        document,
        (
            "schema_version", "experiment_family", "formal_purpose", "time_partition", "seed_order",
            "remote_root", "app_root", "reference_source_root", "reference_source_manifest_path",
            "reference_source_manifest_sha256", "source_data_contract_path", "source_data_contract_sha256",
            "data_authorization_path", "data_authorization_sha256", "paid_execution_authorization_path",
            "paid_execution_authorization_sha256", "comparison_protocol_path", "comparison_protocol_sha256",
            "usage_ledger_path", "attempt_root", "output_root", "job_attempt_root", "submission_receipt_path",
            "expected_training_sample_count", "expected_selection_sample_count", "normalization_sha256",
            "environment", "maximum_new_formal_object_reads", "maximum_new_formal_bytes", "new_2023_reads", "new_2024_reads",
        ),
        "execution contract",
    )
    _require_exact_values(
        document,
        {
            "schema_version": "matched-legacy-formal-execution-1",
            "experiment_family": EXPERIMENT_FAMILY,
            "formal_purpose": FORMAL_PURPOSE,
            "time_partition": FORMAL_TIME_PARTITION,
            "seed_order": list(SEED_ORDER),
            "remote_root": REMOTE_ROOT_TEXT,
            "app_root": APP_ROOT_TEXT,
            "reference_source_root": REFERENCE_ROOT_TEXT,
            "reference_source_manifest_path": REFERENCE_MANIFEST_PATH_TEXT,
            "reference_source_manifest_sha256": EXPECTED_REFERENCE_MANIFEST_SHA256,
            "source_data_contract_path": SOURCE_DATA_CONTRACT_PATH_TEXT,
            "source_data_contract_sha256": EXPECTED_SOURCE_DATA_CONTRACT_SHA256,
            "data_authorization_path": DATA_AUTHORIZATION_PATH_TEXT,
            "data_authorization_sha256": EXPECTED_DATA_AUTHORIZATION_SHA256,
            "paid_execution_authorization_path": PAID_AUTHORIZATION_PATH_TEXT,
            "paid_execution_authorization_sha256": EXPECTED_PAID_AUTHORIZATION_SHA256,
            "comparison_protocol_path": COMPARISON_PROTOCOL_PATH_TEXT,
            "comparison_protocol_sha256": EXPECTED_COMPARISON_PROTOCOL_SHA256,
            "usage_ledger_path": USAGE_LEDGER_PATH_TEXT,
            "attempt_root": ATTEMPT_ROOT_TEXT,
            "output_root": OUTPUT_ROOT_TEXT,
            "job_attempt_root": JOB_ATTEMPT_ROOT_TEXT,
            "submission_receipt_path": SUBMISSION_RECEIPT_PATH_TEXT,
            "expected_training_sample_count": EXPECTED_TRAINING_SAMPLE_COUNT,
            "expected_selection_sample_count": EXPECTED_SELECTION_SAMPLE_COUNT,
            "normalization_sha256": EXPECTED_NORMALIZATION_SHA256,
            "environment": EXPECTED_ENVIRONMENT,
            "maximum_new_formal_object_reads": EXPECTED_MAXIMUM_READS,
            "maximum_new_formal_bytes": EXPECTED_MAXIMUM_BYTES,
            "new_2023_reads": 0,
            "new_2024_reads": 0,
        },
        "execution contract",
    )


def _range_tuples(document: Mapping[str, object], key: str) -> Tuple[Tuple[str, int, int], ...]:
    values = document.get(key)
    if not isinstance(values, list):
        raise ValueError(key + " must be a list")
    result = []
    for value in values:
        if not isinstance(value, Mapping):
            raise ValueError(key + " entries must be objects")
        result.append((value.get("path"), value.get("byte_offset"), value.get("byte_count")))
    return tuple(result)


def _validated_source_specifications(
    source: Mapping[str, object],
) -> Tuple[FormalContentSpec, ...]:
    _require_exact_keys(
        source,
        (
            "schema_version", "experiment_family", "boundary_mode", "formal_purpose",
            "time_partition", "training_years", "selection_year", "selection_use",
            "remote_experiment_root", "output_root", "usage_ledger_path",
            "expected_row_count", "first_time_beijing", "last_time_beijing",
            "datong_physical_variable_identity",
            "explicit_stage_physical_variable_identity", "files",
        ),
        "source data contract",
    )
    files = source.get("files")
    if not isinstance(files, list) or len(files) != 12:
        raise ValueError("source data contract must register exactly twelve objects")
    specifications = tuple(FormalContentSpec.from_document(value) for value in files)
    expected_roles = {
        *((REALTIME_ROLE, station) for station in HISTORY_STATIONS),
        *((TARGET_ROLE, station) for station in TARGET_STATIONS),
        (TIDE_ROLE, "wusongkou"),
    }
    if {(value.role, value.station) for value in specifications} != expected_roles:
        raise ValueError("source data contract station roles changed")
    if len({value.path for value in specifications}) != 12:
        raise ValueError("source data contract paths must be unique")
    if any(not value.path.startswith(INPUT_ROOT_TEXT + "/") for value in specifications):
        raise ValueError("source data contract path is outside the exact input root")
    _require_exact_values(
        source,
        {
            "schema_version": "zhenjiang-five-source-five-target-stage-a-data-v2",
            "experiment_family": (
                "ZHENJIANG_FIVE_SOURCE_FIVE_TARGET_D32_GRU_"
                "SINGLE_ANALYSIS_UKF_ORACLE_DATONG_V2"
            ),
            "boundary_mode": "retrospective_observed_oracle",
            "formal_purpose": "stage_a_training_2017_2021_and_best_epoch_selection_2022",
            "time_partition": FORMAL_TIME_PARTITION,
            "training_years": list(TRAINING_YEARS),
            "selection_year": SELECTION_YEAR,
            "selection_use": "best_epoch_selection_only",
            "remote_experiment_root": (
                "/data1/home/sunyiq/"
                "zhenjiang_5s5t_stage_a_20260905_recovery_001"
            ),
            "output_root": (
                "/data1/home/sunyiq/"
                "zhenjiang_5s5t_stage_a_20260905_recovery_001/runs"
            ),
            "usage_ledger_path": (
                "/data1/home/sunyiq/"
                "zhenjiang_5s5t_stage_a_20260905_recovery_001/"
                "evidence/stage_a_formal_data_usage.sqlite3"
            ),
            "expected_row_count": 52_584,
            "first_time_beijing": "2017-01-01T00:00:00+08:00",
            "last_time_beijing": "2022-12-31T23:00:00+08:00",
        },
        "source data contract",
    )
    datong = source["datong_physical_variable_identity"]
    explicit = source["explicit_stage_physical_variable_identity"]
    if not isinstance(datong, Mapping) or not isinstance(explicit, Mapping):
        raise ValueError("source physical-variable identities must be objects")
    _require_exact_keys(
        datong,
        ("station_identity", "water_level_definition", "unit", "vertical_datum", "timestamp_semantics"),
        "source Datong identity",
    )
    _require_exact_keys(
        explicit,
        ("station_order", "water_level_definition", "unit", "vertical_datum", "timestamp_semantics"),
        "source explicit-stage identity",
    )
    if tuple(explicit["station_order"]) != TARGET_STATIONS:
        raise ValueError("source explicit-stage station order changed")
    if sum(value.byte_count for value in specifications) * len(SEED_ORDER) != EXPECTED_MAXIMUM_BYTES:
        raise ValueError("source contract byte budget changed")
    return specifications


def _validate_bound_documents(contract: Mapping[str, object], documents: Mapping[str, Mapping[str, object]]) -> None:
    source = documents["source_data_contract"]
    authorization = documents["data_authorization"]
    paid = documents["paid_execution_authorization"]
    protocol = documents["comparison_protocol"]
    manifest = documents["reference_source_manifest"]

    specifications = _validated_source_specifications(source)
    _require_exact_values(
        authorization,
        {
            "authorization_id": DATA_AUTHORIZATION_ID,
            "allowed_purposes": [FORMAL_PURPOSE],
            "allowed_time_partitions": [FORMAL_TIME_PARTITION],
            "maximum_read_count": EXPECTED_MAXIMUM_READS,
            "previous_access_count_confirmed": 0,
            "misread_events_acknowledged": True,
        },
        "data authorization",
    )
    if Counter(_range_tuples(authorization, "allowed_byte_ranges")) != Counter(value.range_tuple for value in specifications):
        raise ValueError("data authorization byte ranges differ from the source contract")
    if sum(value.byte_count for value in specifications) * len(SEED_ORDER) != EXPECTED_MAXIMUM_BYTES:
        raise ValueError("source contract byte budget changed")
    _require_exact_values(
        paid,
        {
            "schema_version": 1,
            "authorization_id": PAID_AUTHORIZATION_ID,
            "paid_hpc_execution_authorized": True,
            "remote_root": REMOTE_ROOT_TEXT,
            "experiment_family": EXPERIMENT_FAMILY,
            "seed_order": list(SEED_ORDER),
            "maximum_sbatch_submissions": 1,
            "maximum_first_attempts_per_seed": 1,
            "maximum_new_formal_object_reads": EXPECTED_MAXIMUM_READS,
            "maximum_new_formal_bytes": EXPECTED_MAXIMUM_BYTES,
            "maximum_wall_time_hours": 2,
            "number_of_gpus": 1,
            "number_of_cpus": 4,
            "automatic_retry": False,
            "automatic_requeue": False,
            "automatic_cancellation": False,
            "automatic_cleanup": False,
            "fail_stop_after_first_seed_failure": True,
            "reference_model_retraining": False,
            "new_2023_reads": 0,
            "new_2024_reads": 0,
            "complete_25_cell_evaluation": False,
            "direct_ssh_or_scp": False,
            "git_fetch_including_lazy": False,
        },
        "paid execution authorization",
    )
    _require_exact_values(
        protocol,
        {
            "schema_version": "matched-process-model-comparison-1",
            "experiment_family": EXPERIMENT_FAMILY,
            "candidate_model": "MatchedLegacyProcessModel",
            "candidate_parameter_count": 19_525,
            "reference_parameter_count": 20_416,
            "history_station_order": list(HISTORY_STATIONS),
            "target_station_order": list(TARGET_STATIONS),
            "training_years": list(TRAINING_YEARS),
            "selection_year": SELECTION_YEAR,
            "seeds": list(SEED_ORDER),
            "new_2023_reads": 0,
            "new_2024_reads": 0,
            "complete_25_cell_evaluation_in_scope": False,
        },
        "comparison protocol",
    )
    gate = protocol.get("formal_matching_gate")
    if not isinstance(gate, Mapping):
        raise ValueError("comparison protocol matching gate is missing")
    _require_exact_values(
        gate,
        {
            "source_data_contract_sha256": EXPECTED_SOURCE_DATA_CONTRACT_SHA256,
            "expected_selection_sample_count": EXPECTED_SELECTION_SAMPLE_COUNT,
            "normalization_sha256": EXPECTED_NORMALIZATION_SHA256,
        },
        "comparison protocol matching gate",
    )
    _validate_reference_manifest_document(manifest, expected_root=REFERENCE_ROOT_TEXT)


def load_execution_contract(path: Union[str, Path], trusted_sha256: str) -> ValidatedExecutionContract:
    """Load the fixed contract and verify all raw-byte bindings it names."""

    if _require_sha256(trusted_sha256, "execution contract SHA-256") != EXPECTED_EXECUTION_CONTRACT_SHA256:
        raise ValueError("execution contract trusted SHA-256 differs from the registered value")
    document, raw_sha256, _raw = _read_anchored_json(path, trusted_sha256, "execution contract")
    _validate_execution_document(document)
    names = {
        "source_data_contract": (document["source_data_contract_path"], document["source_data_contract_sha256"]),
        "data_authorization": (document["data_authorization_path"], document["data_authorization_sha256"]),
        "paid_execution_authorization": (document["paid_execution_authorization_path"], document["paid_execution_authorization_sha256"]),
        "comparison_protocol": (document["comparison_protocol_path"], document["comparison_protocol_sha256"]),
        "reference_source_manifest": (document["reference_source_manifest_path"], document["reference_source_manifest_sha256"]),
    }
    bound_documents = {}
    bound_hashes = {}
    for name, (bound_path, digest) in names.items():
        value, actual, _content = _read_anchored_json(bound_path, digest, name.replace("_", " "))
        bound_documents[name] = value
        bound_hashes[name] = actual
    _validate_bound_documents(document, bound_documents)
    return ValidatedExecutionContract(
        document,
        raw_sha256=raw_sha256,
        bound_documents=bound_documents,
        bound_raw_sha256=bound_hashes,
    )


def _validate_reference_manifest_document(document: Mapping[str, object], *, expected_root: str) -> None:
    _require_exact_keys(document, ("schema_version", "source_project", "deployed_reference_root", "files"), "reference source manifest")
    _require_exact_values(
        document,
        {
            "schema_version": 1,
            "source_project": "G:/github/pycharm/projects/zhenjiang_stage_forecast",
            "deployed_reference_root": expected_root,
        },
        "reference source manifest",
    )
    files = document.get("files")
    if not isinstance(files, list) or len(files) != len(REFERENCE_FILE_IDENTITIES):
        raise ValueError("reference source manifest must contain exactly ten files")
    observed = {}
    for record in files:
        if not isinstance(record, Mapping):
            raise ValueError("reference source file record must be an object")
        _require_exact_keys(record, ("relative_path", "byte_count", "sha256"), "reference source file record")
        relative = record["relative_path"]
        if relative in observed:
            raise ValueError("reference source manifest contains a duplicate path")
        observed[relative] = (record["byte_count"], record["sha256"])
    if observed != REFERENCE_FILE_IDENTITIES:
        raise ValueError("reference source file identities differ from the ten pinned files")


def _load_verified_module(module_name: str, path: Path, content: bytes) -> ModuleType:
    identity = (module_name, path.resolve())
    existing = sys.modules.get(module_name)
    if existing is not None:
        if _VERIFIED_REFERENCE_MODULES.get(identity) is existing:
            return existing
        raise RuntimeError("refusing pre-existing unverified module for " + module_name)
    specification = importlib.util.spec_from_file_location(module_name, str(path))
    if specification is None:
        raise ImportError("cannot construct source loader for " + str(path))
    module = importlib.util.module_from_spec(specification)
    sys.modules[module_name] = module
    try:
        code = compile(content, str(path), "exec", dont_inherit=True)
        exec(code, module.__dict__)
    except BaseException:
        if sys.modules.get(module_name) is module:
            del sys.modules[module_name]
        raise
    _VERIFIED_REFERENCE_MODULES[identity] = module
    return module


def load_reference_sources(reference_root: Union[str, Path], manifest_path: Union[str, Path], trusted_manifest_sha256: str) -> ReferenceSources:
    """Verify every pinned source byte before loading unchanged dependencies."""

    declared_root = Path(reference_root)
    root = declared_root.resolve(strict=True)
    if (
        declared_root.is_symlink()
        or not declared_root.is_dir()
        or root != Path(os.path.abspath(str(declared_root)))
    ):
        raise RuntimeError("reference source root must be an ordinary unredirected directory")
    document, manifest_sha256, _raw = _read_anchored_json(manifest_path, trusted_manifest_sha256, "reference source manifest")
    _validate_reference_manifest_document(document, expected_root=str(reference_root))
    cache_key = (root, manifest_sha256)
    cached = _REFERENCE_CACHE.get(cache_key)
    if cached is not None:
        return cached
    contents: Dict[str, bytes] = {}
    identities = {}
    for relative, (byte_count, sha256) in REFERENCE_FILE_IDENTITIES.items():
        path = root.joinpath(*relative.split("/"))
        lexical = Path(os.path.abspath(str(path)))
        resolved = path.resolve(strict=True)
        if path.is_symlink() or resolved != lexical or root not in resolved.parents:
            raise RuntimeError("reference source path is redirected: " + relative)
        content = path.read_bytes()
        if len(content) != byte_count or _sha256_bytes(content) != sha256:
            raise RuntimeError("reference source identity differs: " + relative)
        contents[relative] = content
        identities[relative] = {"byte_count": byte_count, "sha256": sha256}

    training = matched_training.load_frozen_training(root / "scripts" / "modeling")
    analysis = _load_verified_module(
        "zhenjiang_five_source_five_target_single_analysis_contract_v2",
        root / "scripts" / "analysis" / "zhenjiang_five_source_five_target_single_analysis_contract_v2.py",
        contents["scripts/analysis/zhenjiang_five_source_five_target_single_analysis_contract_v2.py"],
    )
    del analysis
    data = _load_verified_module(
        "zhenjiang_five_source_five_target_data_v2",
        root / "scripts" / "modeling" / "zhenjiang_five_source_five_target_data_v2.py",
        contents["scripts/modeling/zhenjiang_five_source_five_target_data_v2.py"],
    )
    for module_name, relative in (
        ("nodal_corrections", "third_party/pytides/nodal_corrections.py"),
        ("constituent", "third_party/pytides/constituent.py"),
        ("astro", "third_party/pytides/astro.py"),
        ("tide", "third_party/pytides/tide.py"),
    ):
        _load_verified_module(module_name, root.joinpath(*relative.split("/")), contents[relative])
    tide = _load_verified_module(
        "wusongkou_astronomical_tide_realtime_v2",
        root / "scripts" / "astronomical_tide" / "wusongkou_astronomical_tide_realtime_v2.py",
        contents["scripts/astronomical_tide/wusongkou_astronomical_tide_realtime_v2.py"],
    )
    runner = _load_verified_module(
        "run_zhenjiang_five_source_five_target_stage_a_v2",
        root / "scripts" / "modeling" / "run_zhenjiang_five_source_five_target_stage_a_v2.py",
        contents["scripts/modeling/run_zhenjiang_five_source_five_target_stage_a_v2.py"],
    )
    for relative, expected in identities.items():
        path = root.joinpath(*relative.split("/"))
        if path.stat().st_size != expected["byte_count"] or _sha256_file(path) != expected["sha256"]:
            raise RuntimeError("reference source changed during loading: " + relative)
    result = ReferenceSources(root, document, manifest_sha256, training, data, tide, runner, identities)
    _REFERENCE_CACHE[cache_key] = result
    return result


def _authorization_range_tuples(authorization: object) -> Tuple[Tuple[str, int, int], ...]:
    return tuple((value.path, value.byte_offset, value.byte_count) for value in authorization.allowed_byte_ranges)


def load_data_authorization(document: Mapping[str, object], reference: ReferenceSources):
    """Construct the original immutable authorization type from verified JSON."""

    _require_exact_keys(
        document,
        ("authorization_id", "authorized_by", "authorized_at_beijing", "allowed_purposes", "allowed_time_partitions", "allowed_byte_ranges", "maximum_read_count", "previous_access_count_confirmed", "misread_events_acknowledged"),
        "data authorization",
    )
    ranges = _range_tuples(document, "allowed_byte_ranges")
    return reference.data.ImmutableDataAuthorization(
        authorization_id=document["authorization_id"],
        authorized_by=document["authorized_by"],
        authorized_at_beijing=document["authorized_at_beijing"],
        allowed_purposes=tuple(document["allowed_purposes"]),
        allowed_time_partitions=tuple(document["allowed_time_partitions"]),
        allowed_byte_ranges=tuple(reference.data.AuthorizedByteRange(*value) for value in ranges),
        maximum_read_count=document["maximum_read_count"],
        previous_access_count_confirmed=document["previous_access_count_confirmed"],
        misread_events_acknowledged=document["misread_events_acknowledged"],
    )


def validate_seed_ledger(authorization: object, specifications: Sequence[FormalContentSpec], ledger: object, *, seed: int) -> None:
    """Require the exact complete predecessor history for one fixed seed."""

    specs = tuple(specifications)
    if seed not in SEED_ORDER:
        raise ValueError("seed must be one of 17, 29, or 43")
    if authorization.authorization_id != DATA_AUTHORIZATION_ID:
        raise ValueError("formal ledger authorization identifier is foreign")
    if tuple(authorization.allowed_purposes) != (FORMAL_PURPOSE,):
        raise ValueError("formal ledger purpose differs")
    if tuple(authorization.allowed_time_partitions) != (FORMAL_TIME_PARTITION,):
        raise ValueError("formal ledger partition differs")
    if Counter(_authorization_range_tuples(authorization)) != Counter(value.range_tuple for value in specs):
        raise ValueError("formal ledger authorization ranges differ")
    if authorization.previous_access_count_confirmed != 0:
        raise ValueError("formal ledger must start at a zero prior-access baseline")
    expected_maximum = len(specs) * len(SEED_ORDER)
    if authorization.maximum_read_count != expected_maximum:
        raise ValueError("formal ledger maximum read count differs")
    seed_index = SEED_ORDER.index(seed)
    expected_prior = len(specs) * seed_index
    records = tuple(ledger.event_records())
    by_reservation = defaultdict(list)
    for record in records:
        by_reservation[record["reservation_id"]].append(record)
    if len(by_reservation) != expected_prior:
        raise RuntimeError("seed does not match the exact prior-seed read count")
    expected_ranges = Counter(value.range_tuple for value in specs for _ in range(seed_index))
    observed_ranges = Counter()
    for pair in by_reservation.values():
        if [value["event_type"] for value in pair] != ["RESERVED", "COMPLETED"]:
            raise RuntimeError("every prior seed reservation must be complete and successful")
        reserved, completed = pair
        fixed_fields = (
            "authorization_id", "authorization_document_sha256", "purpose", "time_partition",
            "path", "byte_offset", "byte_count", "expected_remaining_read_count",
        )
        if any(reserved[field] != completed[field] for field in fixed_fields):
            raise RuntimeError("prior seed ledger pair changed immutable fields")
        if (
            reserved["authorization_id"] != authorization.authorization_id
            or reserved["authorization_document_sha256"] != authorization.authorization_document_sha256
            or reserved["purpose"] != FORMAL_PURPOSE
            or reserved["time_partition"] != FORMAL_TIME_PARTITION
            or reserved["bytes_read"] != 0
            or completed["bytes_read"] != reserved["byte_count"]
        ):
            raise RuntimeError("prior seed ledger evidence is foreign or incomplete")
        observed_ranges[(reserved["path"], reserved["byte_offset"], reserved["byte_count"])] += 1
    if observed_ranges != expected_ranges:
        raise RuntimeError("prior seed ledger does not cover every registered object exactly")
    reserved_records = [
        record for record in records if record["event_type"] == "RESERVED"
    ]
    for index, record in enumerate(reserved_records):
        if record["expected_remaining_read_count"] != expected_maximum - index:
            raise RuntimeError("prior seed remaining-read evidence is inconsistent")
    if ledger.reserved_read_count(authorization.authorization_id) != expected_prior:
        raise RuntimeError("formal ledger reserved count changed during validation")


def _validated_formal_input_path(specification: FormalContentSpec) -> Path:
    path = Path(specification.path)
    root = Path(INPUT_ROOT_TEXT)
    lexical_root = Path(os.path.abspath(str(root)))
    resolved_root = root.resolve(strict=True)
    lexical_path = Path(os.path.abspath(str(path)))
    resolved_path = path.resolve(strict=True)
    if root.is_symlink() or resolved_root != lexical_root:
        raise RuntimeError("formal input root is redirected")
    if path.is_symlink() or resolved_path != lexical_path or resolved_root not in resolved_path.parents:
        raise RuntimeError("formal input path is redirected outside the exact input root")
    if not path.is_file():
        raise RuntimeError("formal input must be an ordinary file")
    return resolved_path


def _open_unbuffered(path: Path) -> BinaryIO:
    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    descriptor = os.open(path, flags)
    try:
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            raise RuntimeError("formal input descriptor is not a regular file")
        descriptor_path = Path("/proc/self/fd") / str(descriptor)
        if descriptor_path.exists() and descriptor_path.resolve() != path.resolve():
            raise RuntimeError("formal input descriptor was redirected")
        return os.fdopen(descriptor, "rb", buffering=0)
    except BaseException:
        os.close(descriptor)
        raise


@dataclass(frozen=True)
class FormalReadEvidence:
    role: str
    station: str
    path: str
    byte_offset: int
    byte_count: int
    content_sha256: str
    reservation_id: str
    completed_ledger_snapshot_sha256: str


def read_authorized_content(specification: FormalContentSpec, authorization: object, ledger: object, opener: Optional[Callable[[Path], BinaryIO]] = None):
    """Reserve, read exactly one registered byte interval, and hash the result."""

    specification.validate()
    if authorization.authorization_id != DATA_AUTHORIZATION_ID:
        raise ValueError("foreign data authorization")
    if tuple(authorization.allowed_purposes) != (FORMAL_PURPOSE,):
        raise ValueError("data authorization purpose differs")
    if tuple(authorization.allowed_time_partitions) != (FORMAL_TIME_PARTITION,):
        raise ValueError("data authorization partition differs")
    if specification.range_tuple not in _authorization_range_tuples(authorization):
        raise ValueError("data authorization byte range differs")
    already_reserved = ledger.reserved_read_count(authorization.authorization_id)
    remaining = authorization.maximum_read_count - authorization.previous_access_count_confirmed - already_reserved
    data_module = sys.modules.get(authorization.__class__.__module__)
    if (
        data_module is None
        or getattr(data_module, "ImmutableDataAuthorization", None)
        is not authorization.__class__
    ):
        raise ValueError("authorization is not the verified original immutable type")
    request = data_module.AuthorizedReadRequest(
        FORMAL_PURPOSE,
        FORMAL_TIME_PARTITION,
        specification.path,
        specification.byte_offset,
        specification.byte_count,
        remaining,
    )
    reservation = ledger.reserve(authorization, request)
    bytes_read = 0
    try:
        path = Path(specification.path) if opener is not None else _validated_formal_input_path(specification)
        if opener is None and specification.verification_scope == FULL_FILE_SCOPE and path.stat().st_size != specification.byte_count:
            raise RuntimeError("full-file byte identity differs")
        open_function = opener if opener is not None else _open_unbuffered
        with open_function(path) as handle:
            handle.seek(specification.byte_offset)
            content = handle.read(specification.byte_count)
            try:
                bytes_read = len(content)
            except TypeError:
                bytes_read = 0
        if type(content) is not bytes:
            raise RuntimeError("formal input reader must return immutable bytes")
        if bytes_read != specification.byte_count or _sha256_bytes(content) != specification.content_sha256:
            raise RuntimeError("formal input byte identity differs")
        snapshot = ledger.mark_completed(reservation, bytes_read=bytes_read)
    except BaseException as error:
        ledger.mark_failed(reservation, bytes_read=bytes_read, reason=type(error).__name__)
        raise
    return content, FormalReadEvidence(
        specification.role, specification.station, specification.path,
        specification.byte_offset, specification.byte_count, specification.content_sha256,
        reservation, snapshot,
    )


def read_seed_contents(specifications: Sequence[FormalContentSpec], authorization: object, ledger: object, *, seed: int, opener: Optional[Callable[[Path], BinaryIO]] = None):
    """Read the twelve registered objects only after exact predecessor validation."""

    specs = tuple(specifications)
    validate_seed_ledger(authorization, specs, ledger, seed=seed)
    contents = {}
    evidence = []
    for specification in sorted(specs):
        content, record = read_authorized_content(specification, authorization, ledger, opener)
        key = (specification.role, specification.station)
        if key in contents:
            raise RuntimeError("duplicate formal role/station content")
        contents[key] = content
        evidence.append(asdict(record))
    return contents, tuple(evidence)


def _source_contract_object(source_contract: object, reference: ReferenceSources):
    if isinstance(source_contract, Mapping):
        return source_contract_from_document(source_contract, reference)
    return source_contract


def _record_enumeration_evidence(enumeration: object) -> Mapping[str, object]:
    return {
        partition.partition_name: {
            "raw_candidate_count": partition.raw_candidate_count,
            "cross_year_excluded_count": partition.cross_year_excluded_count,
            "missing_excluded_count": partition.missing_excluded_count,
            "valid_count": partition.valid_count,
            "valid_analysis_time_manifest_sha256": partition.valid_analysis_time_manifest_sha256,
        }
        for partition in enumeration.partitions
    }


def partitions_from_contents(contents: Mapping[Tuple[str, str], bytes], source_contract: object, reference: ReferenceSources):
    """Build genuine frozen datasets and normalization from in-memory bytes only."""

    contract = _source_contract_object(source_contract, reference)
    expected_keys = {
        *((REALTIME_ROLE, station) for station in HISTORY_STATIONS),
        *((TARGET_ROLE, station) for station in TARGET_STATIONS),
        (TIDE_ROLE, "wusongkou"),
    }
    if set(contents) != expected_keys:
        raise ValueError("in-memory contents must contain exactly the twelve registered roles")
    canonical_times = None
    history_columns = []
    target_columns = []
    for station in HISTORY_STATIONS:
        times, values = reference.runner._parse_csv_series(contents[(REALTIME_ROLE, station)], role=REALTIME_ROLE)
        if canonical_times is None:
            canonical_times = times
        elif not np.array_equal(times, canonical_times):
            raise RuntimeError("historical-stage timelines differ")
        history_columns.append(values)
    for station in TARGET_STATIONS:
        times, values = reference.runner._parse_csv_series(contents[(TARGET_ROLE, station)], role=TARGET_ROLE)
        if canonical_times is None or not np.array_equal(times, canonical_times):
            raise RuntimeError("retrospective-target timelines differ")
        target_columns.append(values)
    if canonical_times is None or {value.year for value in canonical_times} != set(range(2017, 2023)):
        raise RuntimeError("formal timeline must contain exactly calendar years 2017 through 2022")
    tide_model = reference.runner._tide_model_from_authorized_bytes(contents[(TIDE_ROLE, "wusongkou")])
    data = reference.data.build_data_from_arrays(
        times_beijing=canonical_times,
        realtime_stages_m=np.stack(history_columns, axis=1),
        retrospective_targets_m=np.stack(target_columns, axis=1),
        astronomical_tide_m=tide_model.predict_float64(canonical_times),
        datong_identity=contract.datong_identity,
        explicit_stage_identity=contract.explicit_stage_identity,
    )
    datasets = reference.data.build_split_datasets(data)
    partitions = reference.training.StageAPartitions(
        training_dataset=datasets["training"],
        selection_dataset=datasets["selection"],
        training_years=TRAINING_YEARS,
        selection_year=SELECTION_YEAR,
    ).validate()
    normalization = data.normalization
    provenance = {
        "training_sample_count": len(partitions.training_dataset),
        "selection_sample_count": len(partitions.selection_dataset),
        "datong_boundary_data_identity_sha256": data.datong_boundary_data_identity_sha256,
        "explicit_stage_data_identity_sha256": data.explicit_stage_data_identity_sha256,
        "normalization_sha256": {
            "history_stage": normalization.history_stage.normalization_sha256,
            "future_wusongkou_astronomical_tide": normalization.future_wusongkou_astronomical_tide.normalization_sha256,
            "future_datong_observed_driver": normalization.future_datong_observed_driver.normalization_sha256,
            "explicit_stage": normalization.explicit_stage.normalization_sha256,
        },
        "legal_origin_evidence": _record_enumeration_evidence(data.record_enumeration),
    }
    scale = _explicit_stage_scale(data)
    return partitions, scale, provenance


def _explicit_stage_scale(data: object) -> torch.Tensor:
    normalization = getattr(data, "normalization", None)
    explicit_stage = getattr(normalization, "explicit_stage", None)
    if explicit_stage is None or not hasattr(explicit_stage, "std_m"):
        raise RuntimeError("normalization.explicit_stage.std_m is required")
    values = np.asarray(explicit_stage.std_m, dtype=np.float32)
    if values.shape != (5,) or not np.isfinite(values).all() or np.any(values <= 0):
        raise RuntimeError("normalization.explicit_stage.std_m is invalid")
    return torch.tensor(values.copy(), dtype=torch.float32)


def _validate_matching_gate(provenance: Mapping[str, object], contract: Mapping[str, object]) -> None:
    if provenance.get("training_sample_count") != contract["expected_training_sample_count"]:
        raise RuntimeError("training sample count differs before optimizer updates")
    if provenance.get("selection_sample_count") != contract["expected_selection_sample_count"]:
        raise RuntimeError("selection sample count differs before optimizer updates")
    if provenance.get("normalization_sha256") != contract["normalization_sha256"]:
        raise RuntimeError("normalization identities differ before optimizer updates")


def _load_json_exact(path: Path, name: str) -> Tuple[Mapping[str, object], bytes]:
    if path.is_symlink() or not path.is_file() or path.resolve(strict=True) != Path(os.path.abspath(str(path))):
        raise RuntimeError(name + " must be one ordinary unredirected file")
    content = path.read_bytes()
    return _strict_json_bytes(content, name), content


def _require_ordinary_directory(path: Path, name: str) -> Path:
    lexical = Path(os.path.abspath(str(path)))
    if (
        path.is_symlink()
        or not path.is_dir()
        or path.resolve(strict=True) != lexical
    ):
        raise RuntimeError(name + " must be an ordinary unredirected directory")
    return lexical


def _validate_runtime_directories(contract: Mapping[str, object]) -> None:
    remote_root = _require_ordinary_directory(Path(contract["remote_root"]), "remote root")
    app_root = _require_ordinary_directory(Path(contract["app_root"]), "app root")
    output_root = _require_ordinary_directory(Path(contract["output_root"]), "output root")
    attempt_root = _require_ordinary_directory(Path(contract["attempt_root"]), "seed attempt root")
    ledger_path = Path(contract["usage_ledger_path"])
    ledger_parent = _require_ordinary_directory(ledger_path.parent, "usage-ledger parent")
    for path in (app_root, output_root, attempt_root, ledger_parent):
        if path != remote_root and remote_root not in path.parents:
            raise RuntimeError("runtime directory escaped the fixed remote root")
    if ledger_path.exists() and (
        ledger_path.is_symlink()
        or not ledger_path.is_file()
        or ledger_path.resolve(strict=True) != Path(os.path.abspath(str(ledger_path)))
    ):
        raise RuntimeError("usage ledger is redirected")


def _required_job_identity(contract: Mapping[str, object], execution_contract_sha256: str) -> str:
    job_id = os.environ.get("SLURM_JOB_ID", "")
    if not job_id.isdigit():
        raise RuntimeError("SLURM_JOB_ID must be a numeric job identifier")
    if os.environ.get("SLURM_RESTART_COUNT") not in (None, "0"):
        raise RuntimeError("a restarted Slurm job is not authorized")
    if os.environ.get("SLURM_ARRAY_TASK_ID") is not None or os.environ.get("SLURM_ARRAY_JOB_ID") is not None:
        raise RuntimeError("a Slurm array task is not authorized")
    receipt, _ = _load_json_exact(Path(contract["submission_receipt_path"]), "submission receipt")
    _require_exact_keys(
        receipt,
        ("schema_version", "experiment_family", "status", "job_id", "execution_contract_sha256", "submission_attempt_number", "maximum_sbatch_submissions", "submitted_at_utc"),
        "submission receipt",
    )
    _require_exact_values(
        receipt,
        {
            "schema_version": 1,
            "experiment_family": EXPERIMENT_FAMILY,
            "status": "submitted",
            "job_id": job_id,
            "execution_contract_sha256": execution_contract_sha256,
            "submission_attempt_number": 1,
            "maximum_sbatch_submissions": 1,
        },
        "submission receipt",
    )
    _parse_utc(receipt["submitted_at_utc"], "submitted_at_utc")
    started, _ = _load_json_exact(Path(contract["job_attempt_root"]) / "started.json", "job start receipt")
    _require_exact_keys(
        started,
        ("schema_version", "experiment_family", "status", "job_id", "execution_contract_sha256", "attempt_number", "started_at_utc"),
        "job start receipt",
    )
    _require_exact_values(
        started,
        {
            "schema_version": 1,
            "experiment_family": EXPERIMENT_FAMILY,
            "status": "started",
            "job_id": job_id,
            "execution_contract_sha256": execution_contract_sha256,
            "attempt_number": 1,
        },
        "job start receipt",
    )
    _parse_utc(started["started_at_utc"], "started_at_utc")
    return job_id


def _environment_manifest() -> Mapping[str, object]:
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable before formal data access")
    properties = torch.cuda.get_device_properties(0)
    return {
        "python_version": platform.python_version(),
        "torch_version": torch.__version__,
        "numpy_version": np.__version__,
        "pandas_version": importlib.metadata.version("pandas"),
        "scipy_version": importlib.metadata.version("scipy"),
        "psutil_version": importlib.metadata.version("psutil"),
        "cuda_version": torch.version.cuda,
        "cuda_available": True,
        "device_type": "cuda",
        "device_name": properties.name,
        "compute_capability": list(torch.cuda.get_device_capability(0)),
        "device_memory_bytes": int(properties.total_memory),
    }


def _validate_environment(contract: Mapping[str, object]) -> Mapping[str, object]:
    actual = _environment_manifest()
    expected = contract["environment"]
    for key in (
        "python_version", "torch_version", "numpy_version", "pandas_version", "scipy_version",
        "psutil_version", "cuda_version", "cuda_available", "device_type", "device_name", "compute_capability",
    ):
        if actual[key] != expected[key]:
            raise RuntimeError("registered execution environment differs: " + key)
    if actual["device_memory_bytes"] < expected["minimum_device_memory_bytes"]:
        raise RuntimeError("CUDA device memory is below the registered minimum")
    return actual


def _write_json_exclusive(path: Path, document: object) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(document, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())


def _validate_predecessor(attempt_root: Path, *, seed: int, job_id: str, contract_sha256: str) -> None:
    index = SEED_ORDER.index(seed)
    if index == 0:
        return
    predecessor = attempt_root / ("seed_%d" % SEED_ORDER[index - 1]) / "completion_receipt.json"
    document, _ = _load_json_exact(predecessor, "predecessor seed completion receipt")
    _require_exact_values(
        document,
        {
            "schema_version": 1,
            "experiment_family": EXPERIMENT_FAMILY,
            "status": "complete",
            "seed": SEED_ORDER[index - 1],
            "seed_sequence_index": index,
            "job_id": job_id,
            "execution_contract_sha256": contract_sha256,
        },
        "predecessor seed completion receipt",
    )


def _reserve_seed_attempt(attempt_root: Path, *, seed: int, job_id: str, contract_sha256: str) -> Path:
    attempt_directory = attempt_root / ("seed_%d" % seed)
    attempt_directory.mkdir(exist_ok=False)
    started = {
            "schema_version": 1,
            "experiment_family": EXPERIMENT_FAMILY,
            "status": "formal_seed_attempt_started",
            "seed": seed,
            "seed_sequence_index": SEED_ORDER.index(seed) + 1,
            "attempt_number": 1,
            "job_id": job_id,
            "execution_contract_sha256": contract_sha256,
            "created_at_utc": _utc_now(),
    }
    try:
        _write_json_exclusive(attempt_directory / "attempt_started.json", started)
    except BaseException as error:
        failure = {
            **started,
            "status": "failed_before_attempt_start_receipt_completed",
            "error_type": type(error).__name__,
            "failed_at_utc": _utc_now(),
        }
        _write_json_exclusive(attempt_directory / "failure.json", failure)
        raise
    return attempt_directory


def _require_deployed_app_location() -> None:
    actual = Path(__file__).resolve().parent
    expected = Path(APP_ROOT_TEXT)
    if actual != expected:
        raise RuntimeError("matched_formal.py is not executing from the fixed deployed app root")


def run_authorized_seed(execution_contract_path: Union[str, Path], trusted_sha256: str, seed: int):
    """Execute one fixed CUDA seed and save its exclusive formal receipt."""

    if seed not in SEED_ORDER:
        raise ValueError("seed must be one of 17, 29, or 43")
    _require_deployed_app_location()
    if str(execution_contract_path) != EXECUTION_CONTRACT_PATH_TEXT:
        raise ValueError("execution contract path differs from the fixed deployed value")
    contract = load_execution_contract(execution_contract_path, trusted_sha256)
    _validate_runtime_directories(contract)
    job_id = _required_job_identity(contract, contract.raw_sha256)
    environment = _validate_environment(contract)
    reference = load_reference_sources(
        contract["reference_source_root"],
        contract["reference_source_manifest_path"],
        contract["reference_source_manifest_sha256"],
    )
    source_contract = source_contract_from_document(
        contract.bound_documents["source_data_contract"], reference
    )
    specifications = source_contract.files
    authorization = load_data_authorization(contract.bound_documents["data_authorization"], reference)
    ledger = reference.data.AtomicUsageLedger(contract["usage_ledger_path"])
    validate_seed_ledger(authorization, specifications, ledger, seed=seed)
    attempt_root = Path(contract["attempt_root"])
    _validate_predecessor(attempt_root, seed=seed, job_id=job_id, contract_sha256=contract.raw_sha256)
    output_directory = Path(contract["output_root"]) / ("seed_%d" % seed)
    if output_directory.exists():
        raise FileExistsError("formal training output already exists")
    attempt_directory = _reserve_seed_attempt(
        attempt_root, seed=seed, job_id=job_id, contract_sha256=contract.raw_sha256
    )
    try:
        contents, read_evidence = read_seed_contents(specifications, authorization, ledger, seed=seed)
        partitions, scale, provenance = partitions_from_contents(contents, source_contract, reference)
        _validate_matching_gate(provenance, contract)
        if not hasattr(scale, "dtype") or scale.dtype != torch.float32 or tuple(scale.shape) != (5,):
            raise RuntimeError("explicit-stage standard deviations are unavailable")
        training_manifest = matched_training.train_matched_legacy(
            partitions=partitions,
            explicit_stage_standard_deviations_m=scale,
            seed=seed,
            device="cuda",
            output_directory=output_directory,
            source_directory=Path(contract["reference_source_root"]) / "scripts" / "modeling",
        )
        training_manifest_path = output_directory / "completion_manifest.json"
        final_ledger_records = tuple(ledger.event_records())
        receipt = {
            "schema_version": 1,
            "experiment_family": EXPERIMENT_FAMILY,
            "status": "complete",
            "formal_purpose": FORMAL_PURPOSE,
            "time_partition": FORMAL_TIME_PARTITION,
            "seed": seed,
            "seed_sequence_index": SEED_ORDER.index(seed) + 1,
            "job_id": job_id,
            "execution_contract_path": EXECUTION_CONTRACT_PATH_TEXT,
            "execution_contract_sha256": contract.raw_sha256,
            "source_data_contract_sha256": contract.bound_raw_sha256["source_data_contract"],
            "data_authorization_raw_sha256": contract.bound_raw_sha256["data_authorization"],
            "data_authorization_canonical_sha256": authorization.authorization_document_sha256,
            "paid_execution_authorization_sha256": contract.bound_raw_sha256["paid_execution_authorization"],
            "comparison_protocol_sha256": contract.bound_raw_sha256["comparison_protocol"],
            "reference_source_manifest_sha256": reference.manifest_sha256,
            "reference_source_identities": reference.file_identities,
            "environment": environment,
            "formal_read_evidence": list(read_evidence),
            "formal_read_count_this_seed": len(read_evidence),
            "formal_bytes_this_seed": sum(value["byte_count"] for value in read_evidence),
            "cumulative_reserved_read_count": sum(
                value["event_type"] == "RESERVED"
                for value in final_ledger_records
            ),
            "cumulative_completed_bytes": sum(
                value["bytes_read"]
                for value in final_ledger_records
                if value["event_type"] == "COMPLETED"
            ),
            "final_usage_ledger_snapshot_sha256": ledger.logical_snapshot_sha256(),
            "data_provenance": provenance,
            "training_output_directory": str(output_directory),
            "training_completion_manifest_sha256": _sha256_file(training_manifest_path),
            "training_manifest": training_manifest,
            "completed_at_utc": _utc_now(),
        }
        _write_json_exclusive(attempt_directory / "completion_receipt.json", receipt)
        return receipt
    except BaseException as error:
        failure = {
            "schema_version": 1,
            "experiment_family": EXPERIMENT_FAMILY,
            "status": "failed",
            "seed": seed,
            "seed_sequence_index": SEED_ORDER.index(seed) + 1,
            "attempt_number": 1,
            "job_id": job_id,
            "execution_contract_sha256": contract.raw_sha256,
            "error_type": type(error).__name__,
            "failed_at_utc": _utc_now(),
        }
        try:
            _write_json_exclusive(attempt_directory / "failure.json", failure)
        except BaseException as evidence_error:
            raise RuntimeError(
                "formal seed failed and its failure evidence could not be persisted"
            ) from evidence_error
        raise


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execution-contract", required=True)
    parser.add_argument("--execution-contract-sha256", required=True)
    parser.add_argument("--seed", type=int, choices=SEED_ORDER, required=True)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    arguments = build_argument_parser().parse_args(argv)
    receipt = run_authorized_seed(
        arguments.execution_contract,
        arguments.execution_contract_sha256,
        arguments.seed,
    )
    print(json.dumps(receipt, indent=2, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
