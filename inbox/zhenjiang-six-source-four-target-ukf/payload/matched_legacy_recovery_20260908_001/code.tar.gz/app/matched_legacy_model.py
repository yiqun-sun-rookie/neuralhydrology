"""Matched legacy deterministic forecast architecture and input validation."""

from __future__ import annotations

from typing import Tuple

import torch
from torch import nn


HISTORY_HOURS = 24
HISTORY_VARIABLES = 6
FORECAST_HOURS = 24
CONTROL_VARIABLES = 2
ENCODER_HIDDEN_SIZE = 64
LATENT_STATE_SIZE = 32
TARGET_VARIABLES = 5
EXPECTED_PARAMETER_COUNT = 19_525


class MatchedLegacyProcessModel(nn.Module):
    """Encode 24 hours once, then produce a 24-hour five-station forecast."""

    def __init__(self) -> None:
        super().__init__()
        self.history_encoder = nn.GRU(
            input_size=HISTORY_VARIABLES,
            hidden_size=ENCODER_HIDDEN_SIZE,
            batch_first=True,
        )
        self.state_projection = nn.Linear(
            ENCODER_HIDDEN_SIZE,
            LATENT_STATE_SIZE,
        )
        self.process_cell = nn.GRUCell(
            input_size=CONTROL_VARIABLES,
            hidden_size=LATENT_STATE_SIZE,
        )
        self.target_decoder = nn.Linear(
            LATENT_STATE_SIZE,
            TARGET_VARIABLES,
        )
        actual_count = sum(parameter.numel() for parameter in self.parameters())
        if actual_count != EXPECTED_PARAMETER_COUNT:
            raise RuntimeError(
                "model parameter count changed: {} != {}".format(
                    actual_count,
                    EXPECTED_PARAMETER_COUNT,
                )
            )

    def _model_reference(self) -> torch.Tensor:
        return self.state_projection.weight

    def _validate_inputs(
        self,
        history: torch.Tensor,
        future_control: torch.Tensor,
    ) -> Tuple[int, torch.device]:
        if not isinstance(history, torch.Tensor) or history.ndim != 3:
            raise ValueError("history must have shape [batch, 24, 6]")
        batch_size = int(history.shape[0])
        if batch_size < 1:
            raise ValueError("history must contain at least one sample")
        if tuple(history.shape) != (batch_size, HISTORY_HOURS, HISTORY_VARIABLES):
            raise ValueError("history must have shape [batch, 24, 6]")
        if (
            not isinstance(future_control, torch.Tensor)
            or future_control.ndim != 3
            or tuple(future_control.shape)
            != (batch_size, FORECAST_HOURS, CONTROL_VARIABLES)
        ):
            raise ValueError(
                "future_control must have shape [batch, 24, 2] "
                "with the same batch size as history"
            )
        if history.dtype != torch.float32:
            raise ValueError("history must be float32")
        if future_control.dtype != torch.float32:
            raise ValueError("future_control must be float32")
        if not bool(torch.isfinite(history).all()):
            raise ValueError("history must contain only finite values")
        if not bool(torch.isfinite(future_control).all()):
            raise ValueError("future_control must contain only finite values")
        reference = self._model_reference()
        if reference.dtype != torch.float32:
            raise ValueError("model parameters must remain float32")
        if history.device != reference.device:
            raise ValueError("history device must match the model device")
        if future_control.device != reference.device:
            raise ValueError("future_control device must match the model device")
        return batch_size, reference.device

    def forward(
        self,
        history: torch.Tensor,
        future_control: torch.Tensor,
    ) -> torch.Tensor:
        """Return forecasts shaped ``[batch, 24, 5]``."""

        self._validate_inputs(history, future_control)
        _, hidden = self.history_encoder(history)
        state = torch.tanh(self.state_projection(hidden[-1]))
        predictions = []
        for hour in range(FORECAST_HOURS):
            state = self.process_cell(future_control[:, hour, :], state)
            predictions.append(self.target_decoder(state))
        return torch.stack(predictions, dim=1)


__all__ = [
    "CONTROL_VARIABLES",
    "ENCODER_HIDDEN_SIZE",
    "EXPECTED_PARAMETER_COUNT",
    "FORECAST_HOURS",
    "HISTORY_HOURS",
    "HISTORY_VARIABLES",
    "LATENT_STATE_SIZE",
    "MatchedLegacyProcessModel",
    "TARGET_VARIABLES",
]
