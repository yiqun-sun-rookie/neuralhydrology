#!/usr/bin/env python3
"""Train the hash-pinned matched legacy comparator or run a synthetic smoke test.

The reusable function accepts already-standardized in-memory datasets. The
command line intentionally exposes only the in-memory synthetic smoke mode.

Example:
    python -B matched_training.py --execution-mode synthetic_smoke --seed 17 \
        --source-directory G:\\path\\to\\zhenjiang_stage_forecast
"""

from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
from types import ModuleType
from typing import Dict, Mapping, Optional, Sequence, Tuple, Union

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

from matched_legacy_model import EXPECTED_PARAMETER_COUNT, MatchedLegacyProcessModel


EXPERIMENT_FAMILY = "ZHENJIANG_MATCHED_LEGACY_PROCESS_MODEL_20260907"
MODEL_CLASS = "MatchedLegacyProcessModel"
STAGE = "matched_legacy_backbone"
BOUNDARY_MODE = "retrospective_observed_oracle"
ALLOWED_SEEDS: Tuple[int, ...] = (17, 29, 43)
TRAINING_YEARS: Tuple[int, ...] = (2017, 2018, 2019, 2020, 2021)
SELECTION_YEAR = 2022
SELECTION_USE = "best_epoch_selection_only"
HISTORY_STATIONS: Tuple[str, ...] = (
    "datong",
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
FUTURE_CONTROLS: Tuple[str, ...] = (
    "wusongkou_astronomical_tide",
    "retrospective_hourly_observed_datong_water_level",
)
TARGET_STATIONS: Tuple[str, ...] = (
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
DEPENDENCY_HASHES: Mapping[str, str] = {
    "zhenjiang_five_source_five_target_d32_gru_v2.py": (
        "3dc45a73dc333156a4d5bd5429028aaaa6e13380904f79ca2d334c25af6d355a"
    ),
    "train_zhenjiang_five_source_five_target_d32_gru_v2.py": (
        "d2ff8313469019e2065131811c1ffb4c698c904a87f70956cea7aa9ee2455c27"
    ),
}
ARCHITECTURE_REFERENCE_HASHES: Mapping[str, str] = {
    "zhenjiang_six_source_four_target_d32_gru_v1.py": (
        "fdb90828d46c3f0e26ee1bfd4d8ae6edadb6d96bb8b553a995eaf59a61992209"
    ),
}
MODEL_MODULE_NAME = "zhenjiang_five_source_five_target_d32_gru_v2"
TRAINING_MODULE_NAME = "train_zhenjiang_five_source_five_target_d32_gru_v2"
PACKAGE_ROOT = Path(__file__).resolve().parent
ARTIFACTS_ROOT = PACKAGE_ROOT / "artifacts"
_LOADED_TRAINING_MODULES: Dict[Path, ModuleType] = {}
_VERIFIED_SOURCE_MODULES: Dict[Tuple[str, Path], ModuleType] = {}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _source_file_directory(source_directory: Union[str, Path]) -> Path:
    source = Path(source_directory).resolve()
    candidates = (source, source / "scripts" / "modeling")
    for candidate in candidates:
        if all((candidate / name).is_file() for name in DEPENDENCY_HASHES):
            return candidate.resolve()
    raise FileNotFoundError(
        "source_directory must contain the pinned modeling files directly "
        "or under scripts/modeling"
    )


def _verified_source_bytes(source_file_directory: Path) -> Mapping[str, bytes]:
    source_bytes = {
        name: (source_file_directory / name).read_bytes()
        for name in DEPENDENCY_HASHES
    }
    actual_hashes = {
        name: hashlib.sha256(value).hexdigest()
        for name, value in source_bytes.items()
    }
    mismatches = {
        name: {"expected": DEPENDENCY_HASHES[name], "actual": actual_hashes[name]}
        for name in DEPENDENCY_HASHES
        if actual_hashes[name] != DEPENDENCY_HASHES[name]
    }
    if mismatches:
        raise RuntimeError(
            "frozen source SHA-256 mismatch; refusing execution: {}".format(
                json.dumps(mismatches, sort_keys=True)
            )
        )
    return source_bytes


def _load_original_module(
    module_name: str,
    path: Path,
    verified_source_bytes: bytes,
) -> ModuleType:
    identity = (module_name, path.resolve())
    existing = sys.modules.get(module_name)
    if existing is not None:
        if _VERIFIED_SOURCE_MODULES.get(identity) is existing:
            return existing
        raise RuntimeError(
            "refusing pre-existing unverified module for {}".format(module_name)
        )
    specification = importlib.util.spec_from_file_location(module_name, str(path))
    if specification is None:
        raise ImportError("cannot construct source loader for {}".format(path))
    module = importlib.util.module_from_spec(specification)
    sys.modules[module_name] = module
    try:
        code = compile(
            verified_source_bytes,
            str(path),
            "exec",
            dont_inherit=True,
        )
        exec(code, module.__dict__)
    except BaseException:
        if sys.modules.get(module_name) is module:
            del sys.modules[module_name]
        raise
    _VERIFIED_SOURCE_MODULES[identity] = module
    return module


def load_frozen_training(source_directory: Union[str, Path]) -> ModuleType:
    """Return the unmodified pinned training module after pre-execution checks."""

    source_files = _source_file_directory(source_directory)
    source_bytes = _verified_source_bytes(source_files)
    cached = _LOADED_TRAINING_MODULES.get(source_files)
    if cached is not None:
        return cached
    _load_original_module(
        MODEL_MODULE_NAME,
        source_files / (MODEL_MODULE_NAME + ".py"),
        source_bytes[MODEL_MODULE_NAME + ".py"],
    )
    training = _load_original_module(
        TRAINING_MODULE_NAME,
        source_files / (TRAINING_MODULE_NAME + ".py"),
        source_bytes[TRAINING_MODULE_NAME + ".py"],
    )
    _LOADED_TRAINING_MODULES[source_files] = training
    return training


def _trainable_parameter_count(model: torch.nn.Module) -> int:
    return sum(
        parameter.numel() for parameter in model.parameters() if parameter.requires_grad
    )


def _fixed_identity_fields() -> Dict[str, object]:
    return {
        "experiment_family": EXPERIMENT_FAMILY,
        "model_class": MODEL_CLASS,
        "stage": STAGE,
        "boundary_mode": BOUNDARY_MODE,
        "history_hours": 24,
        "history_stations": list(HISTORY_STATIONS),
        "history_ends_one_hour_before_analysis_origin": True,
        "forecast_hours": 24,
        "forecast_starts_at_analysis_origin": True,
        "future_controls": list(FUTURE_CONTROLS),
        "target_stations": list(TARGET_STATIONS),
        "future_target_feedback": False,
        "observation_updates": False,
        "uncertainty_calibration": False,
        "covariance_propagation": False,
        "state_coordinates": "latent",
        "learned_forecast_decoder": True,
        "explicit_physical_state_claim": False,
        "whole_backbone_comparison": True,
        "capacity_claimed_identical": False,
        "completed_new_backbone_parameter_count": 20_416,
        "smooth_absolute_error_transition_m": 0.10,
        "equally_weighted_cells_per_sample": 120,
        "selection_metric": "ordinary_metre_scale_mean_absolute_error_float64_sums",
        "selection_reporting": "five_target_and_per_lead",
        "training_years": list(TRAINING_YEARS),
        "selection_year": SELECTION_YEAR,
        "selection_use": SELECTION_USE,
        "dependency_sha256": dict(DEPENDENCY_HASHES),
        "architecture_reference_sha256": dict(ARCHITECTURE_REFERENCE_HASHES),
        "architecture_reference_loaded": False,
    }


def _checkpoint_snapshot(
    *,
    model: MatchedLegacyProcessModel,
    seed: int,
    epoch: int,
    selection_metrics: Mapping[str, object],
    scale: torch.Tensor,
    configuration: object,
) -> Dict[str, object]:
    total_count = sum(parameter.numel() for parameter in model.parameters())
    trainable_count = _trainable_parameter_count(model)
    if total_count != EXPECTED_PARAMETER_COUNT:
        raise RuntimeError("total model parameter count changed")
    if trainable_count != EXPECTED_PARAMETER_COUNT:
        raise RuntimeError("trainable model parameter count changed")
    checkpoint = _fixed_identity_fields()
    checkpoint.update(
        {
            "schema_version": 1,
            "seed": seed,
            "epoch": epoch,
            "total_parameter_count": total_count,
            "trainable_parameter_count": trainable_count,
            "explicit_stage_standard_deviations_m": [
                float(value) for value in scale.detach().cpu()
            ],
            "selection_metrics": dict(selection_metrics),
            "training_configuration": asdict(configuration),
            "model_state_dict": {
                name: value.detach().cpu().clone()
                for name, value in model.state_dict().items()
            },
        }
    )
    return checkpoint


def _write_json(path: Path, document: object) -> None:
    path.write_text(
        json.dumps(document, indent=2, sort_keys=True, allow_nan=False),
        encoding="utf-8",
    )


def _current_artifacts_root() -> Path:
    package_root = PACKAGE_ROOT.resolve(strict=True)
    declared_root = package_root / "artifacts"
    if not declared_root.is_dir():
        raise FileNotFoundError("the package artifacts directory must already exist")
    lexical_root = Path(os.path.abspath(str(declared_root)))
    resolved_root = declared_root.resolve(strict=True)
    if resolved_root != lexical_root or resolved_root.parent != package_root:
        raise ValueError(
            "the package artifacts root must not be redirected by a link or junction"
        )
    return resolved_root


def _exclusive_output_directory(output_directory: Union[str, Path]) -> Path:
    artifacts_root = _current_artifacts_root()
    output = Path(output_directory).resolve()
    if output.parent != artifacts_root:
        raise ValueError(
            "output_directory must be a direct child of this package's artifacts directory"
        )
    if output.exists():
        raise FileExistsError(
            "refusing to reuse any existing output directory: {}".format(output)
        )
    output.mkdir(exist_ok=False)
    return output


def _build_training_loader(
    dataset: Dataset,
    *,
    batch_size: int,
    seed: int,
) -> DataLoader:
    """Build the independently seeded shuffled loader used by every trainer."""

    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=True,
        generator=torch.Generator().manual_seed(seed),
        drop_last=False,
    )


def train_matched_legacy(
    *,
    partitions: object,
    explicit_stage_standard_deviations_m: torch.Tensor,
    seed: int,
    device: Union[str, torch.device],
    output_directory: Union[str, Path],
    source_directory: Union[str, Path],
) -> Mapping[str, object]:
    """Train one matched baseline seed using standardized in-memory partitions."""

    if seed not in ALLOWED_SEEDS:
        raise ValueError("seed must be one of 17, 29, or 43")
    frozen = load_frozen_training(source_directory)
    configuration = frozen.FROZEN_CONFIGURATION
    partitions.validate()
    scale_on_cpu = frozen._validated_explicit_stage_scale(
        explicit_stage_standard_deviations_m,
        device=torch.device("cpu"),
    )
    torch_device = torch.device(device)
    if torch_device.type == "cuda" and not torch.cuda.is_available():
        raise ValueError("requested CUDA device is unavailable")
    output_path = _exclusive_output_directory(output_directory)

    frozen._set_all_random_generators(seed)
    model = MatchedLegacyProcessModel().to(torch_device)
    if _trainable_parameter_count(model) != EXPECTED_PARAMETER_COUNT:
        raise RuntimeError("all 19,525 comparator parameters must be trainable")
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=configuration.learning_rate,
        weight_decay=configuration.weight_decay,
    )
    training_loader = _build_training_loader(
        partitions.training_dataset,
        batch_size=configuration.batch_size,
        seed=seed,
    )
    selection_loader = DataLoader(
        partitions.selection_dataset,
        batch_size=configuration.batch_size,
        shuffle=False,
        drop_last=False,
    )
    scale_on_device = scale_on_cpu.to(torch_device)

    history = []
    best_metric_m = float("inf")
    best_checkpoint = None
    best_selection_metrics = None
    last_checkpoint = None
    stale_epochs = 0
    for epoch in range(1, configuration.maximum_epochs + 1):
        training_loss_m = frozen._run_training_epoch(
            model,
            training_loader,
            scale_on_device,
            device=torch_device,
            optimizer=optimizer,
            maximum_gradient_norm=configuration.maximum_gradient_norm,
        )
        selection_metrics = frozen._evaluate_2022_selection(
            model,
            selection_loader,
            scale_on_device,
            device=torch_device,
        )
        selection_metric_m = float(
            selection_metrics["overall_mean_absolute_error_m"]
        )
        selected = frozen.should_replace_best(
            selection_metric_m,
            best_metric_m,
            configuration.minimum_improvement_m,
        )
        history.append(
            {
                "epoch": epoch,
                "training_smooth_absolute_error_m": float(training_loss_m),
                "selection_2022_mean_absolute_error_m": selection_metric_m,
                "selected_as_best": selected,
            }
        )
        last_checkpoint = _checkpoint_snapshot(
            model=model,
            seed=seed,
            epoch=epoch,
            selection_metrics=selection_metrics,
            scale=scale_on_cpu,
            configuration=configuration,
        )
        if selected:
            best_metric_m = selection_metric_m
            best_checkpoint = last_checkpoint
            best_selection_metrics = dict(selection_metrics)
            stale_epochs = 0
        else:
            stale_epochs += 1
        if stale_epochs >= configuration.patience_epochs:
            break

    if (
        best_checkpoint is None
        or best_selection_metrics is None
        or last_checkpoint is None
    ):
        raise RuntimeError("matched training completed no checkpointed epoch")

    best_path = output_path / "best_checkpoint.pt"
    last_path = output_path / "last_checkpoint.pt"
    history_path = output_path / "training_history.json"
    environment_path = output_path / "environment_manifest.json"
    torch.save(best_checkpoint, best_path)
    torch.save(last_checkpoint, last_path)
    _write_json(history_path, history)
    _write_json(environment_path, frozen._environment_manifest(torch_device))

    artifact_paths = (best_path, last_path, history_path, environment_path)
    manifest = _fixed_identity_fields()
    manifest.update(
        {
            "schema_version": 1,
            "status": "complete",
            "seed": seed,
            "output_directory": str(output_path),
            "output_directory_created_exclusively": True,
            "best_epoch": int(best_checkpoint["epoch"]),
            "best_selection_mean_absolute_error_m": best_metric_m,
            "best_selection_metrics": best_selection_metrics,
            "total_parameter_count": EXPECTED_PARAMETER_COUNT,
            "trainable_parameter_count": EXPECTED_PARAMETER_COUNT,
            "training_configuration": asdict(configuration),
            "files": {
                path.name: {
                    "byte_count": path.stat().st_size,
                    "sha256": _sha256(path),
                }
                for path in artifact_paths
            },
        }
    )
    _write_json(output_path / "completion_manifest.json", manifest)
    return manifest


class _SyntheticDataset(Dataset):
    def __init__(self, sample_count: int, seed: int) -> None:
        generator = torch.Generator().manual_seed(seed)
        self.history = torch.randn(sample_count, 24, 6, generator=generator)
        self.future_control = torch.randn(
            sample_count, 24, 2, generator=generator
        )
        self.targets = torch.randn(sample_count, 24, 5, generator=generator)

    def __len__(self) -> int:
        return int(self.history.shape[0])

    def __getitem__(self, index: int) -> Mapping[str, torch.Tensor]:
        return {
            "history": self.history[index],
            "future_control": self.future_control[index],
            "targets_a_to_a_plus_23": self.targets[index],
        }


def run_synthetic_smoke(
    *,
    source_directory: Union[str, Path],
    seed: int = 17,
) -> Mapping[str, object]:
    """Run two CPU epochs in memory and create no experiment output."""

    if seed not in ALLOWED_SEEDS:
        raise ValueError("seed must be one of 17, 29, or 43")
    frozen = load_frozen_training(source_directory)
    frozen._set_all_random_generators(seed)
    device = torch.device("cpu")
    model = MatchedLegacyProcessModel().to(device)
    before = {
        name: value.detach().clone() for name, value in model.named_parameters()
    }
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=frozen.FROZEN_CONFIGURATION.learning_rate,
        weight_decay=frozen.FROZEN_CONFIGURATION.weight_decay,
    )
    dataset = _SyntheticDataset(8, seed)
    loader = _build_training_loader(
        dataset,
        batch_size=4,
        seed=seed,
    )
    evaluation_loader = DataLoader(dataset, batch_size=4, shuffle=False)
    scale = torch.ones(5, dtype=torch.float32, device=device)
    training_metrics = []
    for _ in range(2):
        training_metrics.append(
            frozen._run_training_epoch(
                model,
                loader,
                scale,
                device=device,
                optimizer=optimizer,
                maximum_gradient_norm=(
                    frozen.FROZEN_CONFIGURATION.maximum_gradient_norm
                ),
            )
        )
    selection_metrics = frozen._evaluate_2022_selection(
        model,
        evaluation_loader,
        scale,
        device=device,
    )
    parameter_changed = any(
        not torch.equal(before[name], value)
        for name, value in model.named_parameters()
    )
    finite_metrics = all(np.isfinite(value) for value in training_metrics)
    finite_metrics = finite_metrics and np.isfinite(
        selection_metrics["overall_mean_absolute_error_m"]
    )
    if not parameter_changed:
        raise RuntimeError("synthetic smoke performed no parameter update")
    if not finite_metrics:
        raise RuntimeError("synthetic smoke produced nonfinite metrics")
    return {
        "execution_mode": "synthetic_smoke",
        "seed": seed,
        "device": "cpu",
        "epochs": 2,
        "parameter_changed": True,
        "metrics_finite": True,
        "training_smooth_absolute_error_m": [
            float(value) for value in training_metrics
        ],
        "selection_mean_absolute_error_m": float(
            selection_metrics["overall_mean_absolute_error_m"]
        ),
        "total_parameter_count": EXPECTED_PARAMETER_COUNT,
        "trainable_parameter_count": _trainable_parameter_count(model),
        "formal_data_read": False,
        "experiment_output_created": False,
    }


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--execution-mode",
        choices=("synthetic_smoke",),
        required=True,
    )
    parser.add_argument(
        "--seed",
        type=int,
        choices=ALLOWED_SEEDS,
        required=True,
    )
    parser.add_argument("--source-directory", required=True)
    arguments = parser.parse_args(argv)
    report = run_synthetic_smoke(
        source_directory=arguments.source_directory,
        seed=arguments.seed,
    )
    print(json.dumps(report, indent=2, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
