"""Read this isolated diagnostic's accounting and authenticated evidence only.

python -B hpc/probe_covariance_diagnostic.py
Never submits or executes a model, and does not read any evaluation inputs.
"""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def query(args):
    p = subprocess.run(args, capture_output=True, text=True, timeout=30)
    return {'command': args, 'returncode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}


def main():
    spec = json.loads((ROOT / 'diagnostic_spec.json').read_text())
    record = {'status': 'finite_factor_guard_diagnostic_status', 'diagnostic_root': str(ROOT),
              'checked_at_beijing': datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
              'source_failed_job': spec['source_job'], 'job_name': spec['job_name'],
              'evaluation_values_read': False, 'formal_training_restarted': False,
              'formal_training_epochs_added': 0, 'scheduler_mutated': False}
    for name in ('diagnostic_submission_attempt.json', 'diagnostic_submission_response.json', 'scheduler_jobs.json'):
        path = ROOT / 'records' / name
        record[name] = {'value': json.loads(path.read_text()), 'sha256': sha(path), 'bytes': path.stat().st_size} if path.exists() else None
    jobs = record['scheduler_jobs.json']
    job = str(jobs['value']['covariance_diagnostic']) if jobs else None
    record['job_id'] = job
    record['queries'] = [query(['squeue', '-h', '-u', 'sunyiq', '-o', '%i|%j|%T|%N|%Z|%S|%e|%M|%l'])]
    if job:
        record['queries'].append(query(['sacct', '-n', '-X', '-j', job,
            '--format=JobID,State,ExitCode,Start,End,NodeList,Elapsed,Timelimit', '-P']))
    evidence = ROOT / 'evidence'
    record['evidence_documents'] = {}
    for name in ('guard_validation_result.json', 'isolated_guard_source.json'):
        path = evidence / name
        if path.exists():
            record['evidence_documents'][name] = {'value': json.loads(path.read_text()), 'sha256': sha(path), 'bytes': path.stat().st_size}
    record['tensor_artifacts'] = {}
    if evidence.is_dir():
        for path in sorted(evidence.glob('*.pt')):
            record['tensor_artifacts'][path.name] = {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}
    events = evidence / 'events.jsonl'
    if events.exists():
        lines = events.read_text().splitlines()
        record['event_count'] = len(lines)
        record['latest_events'] = [{k: v for k, v in json.loads(line).items() if k != 'metric'} for line in lines[-4:]]
    assert all(q['returncode'] == 0 for q in record['queries']), record['queries']
    print(json.dumps(record, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
