"""Isolate a finite-factor success guard using the authenticated validation state.

No optimizer updates or formal epochs. Original 2017--2020 inputs only recreate
and authenticate the frozen normalization; only the original 2021 selection
calendar is validated. No 2023/2024 or final evaluation loader is opened.
"""
import argparse
import datetime
import hashlib
import inspect
import json
from pathlib import Path
import random
import traceback

import numpy as np
import torch

from authenticated_source_helpers import (import_source, validate_metadata,
    validate_adam, sha256_file, read_json, write_exclusive, cpu_tree)

ROOT=Path(__file__).resolve().parents[1]


def tensor_save(path,value):
    with path.open('xb') as stream:torch.save(cpu_tree(value),stream)
    return {'path':str(path),'sha256':sha256_file(path),'bytes':path.stat().st_size}


def same(a,b):
    if isinstance(a,torch.Tensor):return isinstance(b,torch.Tensor) and torch.equal(a.cpu(),b.cpu())
    if isinstance(a,dict):return a.keys()==b.keys() and all(same(a[k],b[k]) for k in a)
    if isinstance(a,(tuple,list)):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
    return a==b


def main():
    evidence=ROOT/'evidence';evidence.mkdir(exist_ok=False)
    spec=read_json(ROOT/'diagnostic_spec.json');source=Path(spec['source_root'])
    record={'status':'finite_factor_guard_validation_started','diagnostic_root':str(ROOT),
        'source_root':str(source),'checked_at_beijing':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
        'formal_training_epochs_added':0,'optimizer_updates':0,'formal_recovery_admitted':False,
        'evaluation_values_read':False,'scientific_rules_changed':False,'historical_rng_equality_established':False,
        'training_input_values_read':False,'selection_input_values_read':False}
    pinned=spec['pinned_source_files'];api=None;code=1
    try:
        assert str(ROOT)==spec['diagnostic_root'] and spec['maximum_replay_epochs']==0
        assert len(spec['all_member_source_files'])==12
        assert all(sha256_file(Path(p))==s for p,s in pinned.items())
        assert all(sha256_file(Path(x['path']))==x['sha256'] for x in spec['tensor_artifacts'].values())
        api=import_source(source,spec['source_code_hash'])
        args=argparse.Namespace(expected_config_sha256=spec['source_run_files']['config.json']['sha256'],
            expected_checkpoint_sha256=spec['source_run_files']['continuation.pt']['sha256'],
            expected_code_sha256=spec['source_code_hash'])
        run,config,protocol,manifest,seals,_=validate_metadata(source,spec['run_id'],args,api)
        api.training.deterministic_runtime();torch.set_num_threads(4)
        device=api.execution.device_identity(config['effective_config']['device'])
        assert device==config['effective_config']['device_identity']==spec['expected_device_identity']
        start=torch.load(spec['tensor_artifacts']['before_validation_model_adam_rng.pt']['path'],map_location='cpu',weights_only=True)
        operand=torch.load(spec['tensor_artifacts']['covariance_failure_operands.pt']['path'],map_location='cpu',weights_only=True)
        original_factors=torch.load(spec['original_gpu_factor_artifact']['path'],map_location='cpu',weights_only=True)
        assert sha256_file(Path(spec['original_gpu_factor_artifact']['path']))==spec['original_gpu_factor_artifact']['sha256']
        train=api.runtime.load_stage(manifest,'tuning_train');record['training_input_values_read']=True
        stats=api.runtime.fit_stage_stats(train,manifest)
        assert api.scheduler.digest_json(api.runtime.stats_record(stats))==config['effective_config']['normalization_hash']
        del train
        session=api.runtime.build_session(run,config,protocol,stats,evidence/'scratch_session',seals)
        api.training.restore_parts(session.parts,start['model'],session.noise)
        session.optimizer.load_state_dict(start['optimizer']);validate_adam(session,api,6906)
        assert same(api.training.snapshot_parts(session.parts,session.noise),start['model'])
        assert same(cpu_tree(session.optimizer.state_dict()),start['optimizer'])
        random.setstate(start['rng']['python'])
        nr=start['rng']['numpy'];np.random.set_state((nr[0],np.asarray(nr[1],dtype=np.uint32),*nr[2:]))
        torch.set_rng_state(start['rng']['torch_cpu']);torch.cuda.set_rng_state_all(start['rng']['torch_cuda'])
        record.update(model_adam_restored_from_authenticated_state=True,diagnostic_rng_restored=True,
            source_optimizer_steps=6906,device_identity=device,normalization_hash=config['effective_config']['normalization_hash'])
        inputs=operand['original_predict_inputs'];mean=inputs['mean'].to(session.device);cov=inputs['covariance'].to(session.device)
        f=api.filter
        with torch.no_grad():control,wm,wc=f.unscented_points(mean,cov)
        assert torch.equal(torch.isnan(control.cpu()),torch.isnan(operand['original_sigma_points']))
        finite=torch.isfinite(operand['original_sigma_points'])
        assert torch.equal(control.cpu()[finite],operand['original_sigma_points'][finite])
        assert int(torch.isnan(control).sum())==2
        original_source=inspect.getsource(f.stable_cholesky)
        assert original_source.count('if int(info)==0:')==1
        guarded_source=original_source.replace('if int(info)==0:', 'if int(info)==0 and bool(torch.isfinite(factor).all()):')
        record['guarded_function_source_sha256']=hashlib.sha256(guarded_source.encode()).hexdigest()
        write_exclusive(evidence/'isolated_guard_source.json',{'original_function_source':original_source,
            'guarded_function_source':guarded_source,'source_file_not_modified':True,
            'only_change':'require finite factor when backend reports successful Cholesky; same jitter order and values'})
        exec(compile(guarded_source,'<isolated finite-factor success guard>','exec'),f.__dict__)
        with torch.no_grad():
            ledger=f.StabilityLedger();candidate,cm,cc=f.unscented_points(mean,cov,ledger)
        assert torch.isfinite(candidate).all() and torch.equal(wm,cm) and torch.equal(wc,cc)
        jitters=ledger.current_jitter[0].tolist()
        assert jitters==[1e-6 if i==11 else 0.0 for i in range(16)]
        for i in range(16):
            if i!=11:assert torch.equal(candidate[i].cpu(),control[i].cpu())
        ledger.end_step(16);direct_report=ledger.report()
        record.update(original_control_bitwise_reproduced=True,ordinary_fifteen_sigma_sets_bitwise_unchanged=True,
            guarded_sigma_all_finite=True,guarded_original_jitters=jitters,
            direct_guard_stability=direct_report,
            direct_tensor_artifact=tensor_save(evidence/'control_and_guard_sigma.pt',{'original':control,'candidate':candidate,'wm':wm,'wc':wc}))
        selected=api.runtime.load_stage(manifest,'tuning_select');record['selection_input_values_read']=True
        windows,_=api.runtime.prepare_windows(selected,stats);validation=api.runtime.batches(windows)
        record.update(selection_phase='tuning_select',selection_years=[2021],training_years=[2017,2018,2019,2020],
                      validation_windows=len(windows),validation_batch_count=len(validation))
        ledgers=[];base_ledger=api.training.StabilityLedger
        def observed_ledger():
            value=base_ledger();ledgers.append(value);return value
        api.training.StabilityLedger=observed_ledger
        class ObservedBatches:
            def __iter__(self):
                for i,batch in enumerate(validation):
                    record['last_validation_batch']=i+1
                    if i%25==0:
                        with (evidence/'events.jsonl').open('a',encoding='utf-8') as stream:
                            stream.write(json.dumps({'status':'guard_validation_batch_started','batch':i+1,
                                'checked_at_beijing':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()})+'\n')
                    yield batch
        try:
            score=api.training.validation_mae(session.parts,session.noise,session.whitening,session.method,ObservedBatches(),stats)
            assert np.isfinite(score)
            record.update(status='finite_factor_guard_full_validation_passed',candidate_validation_mae_cm=score,
                          full_validation_passed=True)
        except Exception as error:
            record.update(status='finite_factor_guard_candidate_validation_failed',full_validation_passed=False,
                error_type=type(error).__name__,reason=str(error),error_evidence=getattr(error,'evidence',{}),
                traceback=traceback.format_exc())
        assert len(ledgers)==1
        stability=ledgers[0].report(enforce=False);step_values=stability.pop('step_jitters')
        record['validation_stability']=stability
        record['validation_jitter_artifact']=tensor_save(evidence/'full_validation_original_ledger.pt',torch.tensor(step_values,dtype=torch.float64))
        assert same(api.training.snapshot_parts(session.parts,session.noise),start['model'])
        assert same(cpu_tree(session.optimizer.state_dict()),start['optimizer'])
        validate_adam(session,api,6906)
        record.update(model_and_adam_unchanged=True,final_optimizer_steps=6906)
        code=0
    except Exception as error:
        record.update(status='finite_factor_guard_diagnostic_technical_error',error_type=type(error).__name__,
            reason=str(error),traceback=traceback.format_exc())
    finally:
        unchanged={p:sha256_file(Path(p))==s for p,s in pinned.items()}
        record.update(source_file_unchanged_checks=unchanged,all_source_bytes_unchanged=all(unchanged.values()),
            source_code_unchanged=api is not None and api.scheduler.code_identity(source)==spec['source_code_hash'],
            source_code_hash=spec['source_code_hash'],finished_at_beijing=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat())
        if not record['all_source_bytes_unchanged'] or not record['source_code_unchanged']:code=1
        record['exit_code']=code
        write_exclusive(evidence/'guard_validation_result.json',record)
        print(json.dumps({k:v for k,v in record.items() if k!='source_file_unchanged_checks'},sort_keys=True,allow_nan=False),flush=True)
    return code


if __name__=='__main__':raise SystemExit(main())
