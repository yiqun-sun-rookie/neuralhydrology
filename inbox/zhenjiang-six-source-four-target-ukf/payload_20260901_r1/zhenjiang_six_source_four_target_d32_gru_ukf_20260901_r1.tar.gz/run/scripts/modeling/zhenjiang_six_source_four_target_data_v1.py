#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Leakage-safe data contract for six observation sources and four targets.

Only the four internal retrospective-target files are authorized.  Datong and
Wusongkou retrospective-target paths are neither constructed nor opened.  The
training-selection loader reads an independently registered 2017--2022 byte
prefix.  Only the post-freeze development loader reads through 2023; neither
entry reads a byte from the 2024 target suffix.

Example (contract inspection without data access):
    python -c "from zhenjiang_six_source_four_target_data_v1 import TRAINING_SELECTION_CONTENT_IDENTITIES; print(len(TRAINING_SELECTION_CONTENT_IDENTITIES))"
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import hashlib
import io
from pathlib import Path
import sys
from typing import BinaryIO, Callable, Dict, Mapping, Optional, Sequence, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset


PROJECT_ROOT = Path(__file__).resolve().parents[2]
ANALYSIS_DIR = PROJECT_ROOT / "scripts" / "analysis"
ASTRONOMICAL_TIDE_DIR = PROJECT_ROOT / "scripts" / "astronomical_tide"
for _directory in (ANALYSIS_DIR, ASTRONOMICAL_TIDE_DIR):
    if str(_directory) not in sys.path:
        sys.path.insert(0, str(_directory))

from zhenjiang_six_source_four_target_d32_gru_ukf_contract_v1 import (  # noqa: E402
    BASE_FORECAST_HOURS,
    DEVELOPMENT_YEAR,
    HELDOUT_YEAR,
    HISTORY_HOURS,
    SELECTION_YEAR,
    SOURCE_STATIONS,
    TARGET_STATIONS,
    TRAIN_YEARS,
    window_is_within_one_calendar_year,
)
from wusongkou_astronomical_tide_realtime_v2 import (  # noqa: E402
    EXPECTED_TIDE_MODEL_SHA256 as TIDE_MODULE_EXPECTED_SHA256,
    load_frozen_astronomical_tide,
)


BEIJING = timezone(timedelta(hours=8))
DEFAULT_INPUT_ROOT = Path(
    "data/processed/water_level_model_input_v7_beijing_realtime_verified"
)
DEFAULT_TIDE_MODEL_PATH = Path(
    "results/modeling/wusongkou_astronomical_tide_v1_validation/tide_model.json"
)
EXPECTED_TIDE_MODEL_SHA256 = (
    "ce8512f28e87ab6d62814b064d91ca358b98efd7ee27b4f831322ea93775516d"
)
EXPECTED_PREFIX_ROW_COUNT = 61_344
EXPECTED_TRAINING_SELECTION_ROW_COUNT = 52_584

NORMALIZATION_HISTORY_STAGE = "history_realtime_stage_repeated_windows"
NORMALIZATION_FUTURE_TIDE = "future_astronomical_tide_repeated_windows"
NORMALIZATION_ANALYSIS_STAGE = "analysis_t_plus_1_realtime_stage"
NORMALIZATION_RETROSPECTIVE_TARGET = "four_internal_retrospective_targets"

FEATURE_FIELDS = (
    "TIME",
    "STAGE",
    "time_beijing",
    "time_utc",
    "is_missing_for_model",
)
TARGET_FIELDS = (
    "TIME",
    "TARGET_STAGE",
    "time_beijing",
    "time_utc",
    "is_missing_for_target",
)


@dataclass(frozen=True)
class ContentIdentitySpec:
    relative_path: str
    verification_scope: str
    byte_count: int
    sha256: str


_DEVELOPMENT_IDENTITY_ROWS = (
    ("dataset_config.json", "full_file", 2854, "63b2d3a33b249e1f598db2a1ffb2096c9d9006b366e4e913d594f74a6881d492"),
    ("realtime_features/datong_realtime_features.csv", "header_plus_61344_rows", 5485506, "2024937a062df6df6d09eca8789e29aaf85e8734688836f702a3e37f8046e65c"),
    ("realtime_features/nanjing_realtime_features.csv", "header_plus_61344_rows", 5452340, "405efee1787da935392c2175f9cd7dde5dd8a0a2b7960005ced76723c5ea94f9"),
    ("realtime_features/zhenjiang_realtime_features.csv", "header_plus_61344_rows", 5490493, "fc35c509496d00599e85e021cfc7231a4f7201a750a3d444332daca746b7fa6b"),
    ("realtime_features/jiangyin_realtime_features.csv", "header_plus_61344_rows", 5451807, "b3c3ccc8815cf7062f4d0858084c120daa42f5a00459ae885a230afc81821485"),
    ("realtime_features/xuliujing_realtime_features.csv", "header_plus_61344_rows", 5452448, "23ae019c407523493d475a7d1119177d152877fc3359de3d4943a63134d6133a"),
    ("realtime_features/wusongkou_realtime_features.csv", "header_plus_61344_rows", 5449542, "43d62a572c81f5f2e14b732022947cb4eeca32b8654d813ed34722f511a27316"),
    ("retrospective_targets/nanjing_retrospective_targets.csv", "header_plus_61344_rows", 5453455, "a9c650aef6b232baa423d2d2cdd1e2b30981608aca42e292fb944994f2b60f55"),
    ("retrospective_targets/zhenjiang_retrospective_targets.csv", "header_plus_61344_rows", 5491015, "abb38bd543989c0fd0c17f597a36a33799c7816bdad021c9b36268322b169946"),
    ("retrospective_targets/jiangyin_retrospective_targets.csv", "header_plus_61344_rows", 5452821, "5c07b7b61e1cf8301adcc9268d1a73fa5957ec2f1acdc86832dae3eb3dff5e76"),
    ("retrospective_targets/xuliujing_retrospective_targets.csv", "header_plus_61344_rows", 5453528, "b676d2ca3e2f5af64c6eeb690fe39b77e9de25a96ab023a35e08fa60044a554a"),
)
DEVELOPMENT_CONTENT_IDENTITIES: Mapping[str, ContentIdentitySpec] = {
    row[0]: ContentIdentitySpec(*row) for row in _DEVELOPMENT_IDENTITY_ROWS
}
_TRAINING_SELECTION_IDENTITY_ROWS = (
    ("dataset_config.json", "full_file", 2854, "63b2d3a33b249e1f598db2a1ffb2096c9d9006b366e4e913d594f74a6881d492"),
    ("realtime_features/datong_realtime_features.csv", "header_plus_52584_rows", 4701303, "8771742f9b0fe8ae4f933a99b7ea2d6ac5b6ea038352ab1d20d16dfa02679510"),
    ("realtime_features/nanjing_realtime_features.csv", "header_plus_52584_rows", 4673779, "a2f6fc0d4978132839d597f06d1912fee35fad526f7ef3dfb0929f78cf82f1fa"),
    ("realtime_features/zhenjiang_realtime_features.csv", "header_plus_52584_rows", 4703128, "4a46bc94cb0d0d735c84043e28eae9d8c2b0610fd478dbefafa017f8d1f45704"),
    ("realtime_features/jiangyin_realtime_features.csv", "header_plus_52584_rows", 4673156, "c6568bac636cf8037d808ee9728751aa9e031e0f91b1d1771892acfe5fb2b51a"),
    ("realtime_features/xuliujing_realtime_features.csv", "header_plus_52584_rows", 4673755, "cf23dda4b80b81da257872429b61928eec211d2fba47bc73e8643fde80133586"),
    ("realtime_features/wusongkou_realtime_features.csv", "header_plus_52584_rows", 4671049, "b3dc0c759a0adbb34d1011f288528394c0c27a134c59725591e653b82a4d9a5b"),
    ("retrospective_targets/nanjing_retrospective_targets.csv", "header_plus_52584_rows", 4674734, "9e0d1bdd950326bc1c11e05bfcc26ecf6ac847a2e15d01c7cdc49d79644c14b4"),
    ("retrospective_targets/zhenjiang_retrospective_targets.csv", "header_plus_52584_rows", 4703632, "17d897dea5b3599717b1ad2bfd9520ae7e1900d1c9247e27b4d542f2701de937"),
    ("retrospective_targets/jiangyin_retrospective_targets.csv", "header_plus_52584_rows", 4674038, "922157f3294822f86a58d1f590cd0c54eb3b7529beeb957bc53192126b211891"),
    ("retrospective_targets/xuliujing_retrospective_targets.csv", "header_plus_52584_rows", 4674687, "4344b95978c5308cb22bbd3b39e703e9ac6f8daf7973d2a4089c54ef212eb9f8"),
)
TRAINING_SELECTION_CONTENT_IDENTITIES: Mapping[str, ContentIdentitySpec] = {
    row[0]: ContentIdentitySpec(*row)
    for row in _TRAINING_SELECTION_IDENTITY_ROWS
}
# Backward-compatible public name means the 2017--2023 development identity.
AUTHORIZED_CONTENT_IDENTITIES = DEVELOPMENT_CONTENT_IDENTITIES
AUTHORIZED_TARGET_PATHS = tuple(
    f"retrospective_targets/{station}_retrospective_targets.csv"
    for station in TARGET_STATIONS
)
FORBIDDEN_BOUNDARY_TARGET_PATHS = tuple(
    f"retrospective_targets/{station}_retrospective_targets.csv"
    for station in ("datong", "wusongkou")
)


@dataclass(frozen=True, order=True)
class SampleRecord:
    """One accepted rolling origin."""

    issue_position: int
    issue_time_beijing: datetime


@dataclass(frozen=True)
class RecordEnumeration:
    """Three candidate sets and auditable exclusion counts."""

    base_forecast_records: Tuple[SampleRecord, ...]
    realtime_observation_head_records: Tuple[SampleRecord, ...]
    paired_filter_records: Tuple[SampleRecord, ...]
    exclusion_counts: Mapping[str, Mapping[str, int]]


@dataclass(frozen=True)
class SpaceNormalization:
    """Population statistics carrying a non-interchangeable space identity."""

    role: str
    mean_m: np.ndarray
    standard_deviation_m: np.ndarray
    value_count: np.ndarray


@dataclass(frozen=True)
class FourSpaceNormalization:
    history_stage: SpaceNormalization
    future_tide: SpaceNormalization
    analysis_stage: SpaceNormalization
    retrospective_target: SpaceNormalization


@dataclass(frozen=True)
class DataAccessAudit:
    """Immutable access evidence produced by the prefix-only loader."""

    opened_paths: Tuple[str, ...]
    bytes_read_by_path: Mapping[str, int]
    rows_parsed_by_path: Mapping[str, int]
    values_loaded_by_path: Mapping[str, int]
    target_rows_by_period: Mapping[str, int]
    astronomical_tide_model_open_count: int
    development_feature_bytes_read: int = 0
    development_feature_rows_parsed: int = 0
    development_feature_values_loaded: int = 0
    development_target_bytes_read: int = 0
    development_target_rows_parsed: int = 0
    development_target_values_loaded: int = 0
    heldout_target_bytes_read: int = 0
    heldout_target_rows_parsed: int = 0
    heldout_target_values_loaded: int = 0
    boundary_target_bytes_read: int = 0
    boundary_target_rows_parsed: int = 0
    boundary_target_values_loaded: int = 0

    def count_open(self, relative_path: str) -> int:
        return sum(path == relative_path for path in self.opened_paths)


@dataclass(frozen=True)
class SixSourceFourTargetData:
    """Aligned development data with four target columns only."""

    times_beijing: np.ndarray
    realtime_stages_m: np.ndarray
    retrospective_targets_m: np.ndarray
    astronomical_tide_m: np.ndarray
    record_enumeration: RecordEnumeration
    normalization: FourSpaceNormalization
    access_audit: DataAccessAudit

    @property
    def paired_records_by_split(self) -> Mapping[str, Tuple[SampleRecord, ...]]:
        grouped: Dict[str, list] = {
            "training": [],
            "selection": [],
            "development_gate": [],
        }
        for record in self.record_enumeration.paired_filter_records:
            year = record.issue_time_beijing.year
            if year in TRAIN_YEARS:
                grouped["training"].append(record)
            elif year == SELECTION_YEAR:
                grouped["selection"].append(record)
            elif year == DEVELOPMENT_YEAR:
                grouped["development_gate"].append(record)
        return {key: tuple(values) for key, values in grouped.items()}


def _empty_audit() -> DataAccessAudit:
    return DataAccessAudit(
        opened_paths=(),
        bytes_read_by_path={},
        rows_parsed_by_path={},
        values_loaded_by_path={},
        target_rows_by_period={
            "training": 0,
            "selection": 0,
            "development_gate": 0,
            "heldout_or_later": 0,
            "boundary_target": 0,
        },
        astronomical_tide_model_open_count=0,
    )


def assert_forbidden_target_access_is_zero(audit: DataAccessAudit) -> None:
    """Stop if a boundary target or a 2024-and-later target was touched."""

    if not isinstance(audit, DataAccessAudit):
        raise ValueError("access audit is required")
    for path in FORBIDDEN_BOUNDARY_TARGET_PATHS:
        if (
            audit.count_open(path) != 0
            or audit.bytes_read_by_path.get(path, 0) != 0
            or audit.rows_parsed_by_path.get(path, 0) != 0
            or audit.values_loaded_by_path.get(path, 0) != 0
        ):
            raise RuntimeError(f"forbidden boundary target was accessed: {path}")
    if int(audit.target_rows_by_period.get("boundary_target", 0)) != 0:
        raise RuntimeError("boundary target access counter must be zero")
    if int(audit.target_rows_by_period.get("heldout_or_later", 0)) != 0:
        raise RuntimeError("2024-or-later target access counter must be zero")
    for name in (
        "heldout_target_bytes_read",
        "heldout_target_rows_parsed",
        "heldout_target_values_loaded",
        "boundary_target_bytes_read",
        "boundary_target_rows_parsed",
        "boundary_target_values_loaded",
    ):
        value = getattr(audit, name)
        if type(value) is not int or value != 0:
            raise RuntimeError(f"forbidden target counter must be integer zero: {name}")


def _read_identity_bound_bytes(
    input_root: Path,
    spec: ContentIdentitySpec,
    *,
    opener: Callable[[Path], BinaryIO],
) -> bytes:
    path = input_root / Path(spec.relative_path)
    with opener(path) as handle:
        if spec.verification_scope == "full_file":
            content = handle.read()
        elif spec.verification_scope in (
            "header_plus_52584_rows",
            "header_plus_61344_rows",
        ):
            content = handle.read(spec.byte_count)
        else:
            raise ValueError(f"unknown verification scope: {spec.verification_scope}")
    if len(content) != spec.byte_count:
        raise RuntimeError(f"identity byte count changed: {spec.relative_path}")
    if hashlib.sha256(content).hexdigest() != spec.sha256:
        raise RuntimeError(f"identity digest changed: {spec.relative_path}")
    return content


def load_authorized_prefix_bytes(
    input_root: str | Path,
    *,
    identity_specs: Mapping[str, ContentIdentitySpec] = AUTHORIZED_CONTENT_IDENTITIES,
    opener: Optional[Callable[[Path], BinaryIO]] = None,
) -> Tuple[Mapping[str, bytes], DataAccessAudit]:
    """Read only the eleven authorized identities, never either boundary target."""

    expected_paths = {
        "dataset_config.json",
        *(f"realtime_features/{station}_realtime_features.csv" for station in SOURCE_STATIONS),
        *AUTHORIZED_TARGET_PATHS,
    }
    if set(identity_specs) != expected_paths:
        raise ValueError("identity specification must contain exactly 11 authorized paths")
    if any(path in identity_specs for path in FORBIDDEN_BOUNDARY_TARGET_PATHS):
        raise ValueError("boundary target identity is forbidden")
    root = Path(input_root)
    open_function = opener if opener is not None else lambda path: path.open("rb")
    contents: Dict[str, bytes] = {}
    opened = []
    byte_counts: Dict[str, int] = {}
    for relative_path in sorted(identity_specs):
        spec = identity_specs[relative_path]

        def recording_opener(path: Path, *, _relative=relative_path) -> BinaryIO:
            opened.append(_relative)
            return open_function(path)

        content = _read_identity_bound_bytes(
            root, spec, opener=recording_opener
        )
        if identity_specs is TRAINING_SELECTION_CONTENT_IDENTITIES and (
            spec.verification_scope == "header_plus_52584_rows"
        ):
            lines = content.splitlines()
            if (
                len(lines) != EXPECTED_TRAINING_SELECTION_ROW_COUNT + 1
                or not lines[-1].startswith(
                    b"2022-12-31T23:00:00+08:00,"
                )
            ):
                raise RuntimeError(
                    f"training-selection prefix boundary changed: {relative_path}"
                )
        if identity_specs is DEVELOPMENT_CONTENT_IDENTITIES and (
            spec.verification_scope == "header_plus_61344_rows"
        ):
            lines = content.splitlines()
            if (
                len(lines) != EXPECTED_PREFIX_ROW_COUNT + 1
                or not lines[-1].startswith(
                    b"2023-12-31T23:00:00+08:00,"
                )
            ):
                raise RuntimeError(
                    f"development prefix boundary changed: {relative_path}"
                )
        contents[relative_path] = content
        byte_counts[relative_path] = len(content)
    development_feature_bytes = 0
    development_target_bytes = 0
    for relative_path, spec in identity_specs.items():
        if spec.verification_scope != "header_plus_61344_rows":
            continue
        training_spec = TRAINING_SELECTION_CONTENT_IDENTITIES[relative_path]
        suffix_bytes = spec.byte_count - training_spec.byte_count
        if suffix_bytes < 0:
            raise RuntimeError("development identity is shorter than training identity")
        if relative_path.startswith("realtime_features/"):
            development_feature_bytes += suffix_bytes
        elif relative_path.startswith("retrospective_targets/"):
            development_target_bytes += suffix_bytes
    audit = DataAccessAudit(
        opened_paths=tuple(opened),
        bytes_read_by_path=byte_counts,
        rows_parsed_by_path={},
        values_loaded_by_path={},
        target_rows_by_period={
            "training": 0,
            "selection": 0,
            "development_gate": 0,
            "heldout_or_later": 0,
            "boundary_target": 0,
        },
        astronomical_tide_model_open_count=0,
        development_feature_bytes_read=development_feature_bytes,
        development_target_bytes_read=development_target_bytes,
    )
    assert_forbidden_target_access_is_zero(audit)
    return contents, audit


def _parse_time(value: str) -> datetime:
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None or parsed.utcoffset() != timedelta(hours=8):
        raise ValueError(f"time must use Beijing +08:00: {value}")
    return parsed


def _optional_float(value: str, missing_flag: str) -> float:
    if missing_flag == "True":
        if value != "":
            raise ValueError("missing value must be empty")
        return float("nan")
    if missing_flag != "False" or value == "":
        raise ValueError("available value and missing flag disagree")
    parsed = float(value)
    if not np.isfinite(parsed):
        raise ValueError("available value must be finite")
    return parsed


def _parse_prefix_series(
    content: bytes,
    *,
    expected_fields: Tuple[str, ...],
    value_field: str,
    missing_field: str,
    expected_rows: int,
) -> Tuple[np.ndarray, np.ndarray]:
    with io.StringIO(content.decode("utf-8"), newline="") as handle:
        reader = csv.DictReader(handle)
        if tuple(reader.fieldnames or ()) != expected_fields:
            raise RuntimeError("CSV fields changed")
        times = []
        values = []
        for row in reader:
            time = _parse_time(row["time_beijing"])
            utc_time = datetime.fromisoformat(row["time_utc"])
            if (
                row["TIME"] != row["time_beijing"]
                or utc_time.tzinfo is None
                or utc_time.utcoffset() != timedelta(0)
                or time.astimezone(timezone.utc) != utc_time
            ):
                raise RuntimeError("Beijing and coordinated-universal times differ")
            if time.year >= HELDOUT_YEAR:
                raise RuntimeError("authorized prefix unexpectedly contains a 2024 row")
            times.append(time)
            values.append(_optional_float(row[value_field], row[missing_field]))
    if len(times) != expected_rows:
        raise RuntimeError("authorized prefix row count changed")
    if any(times[index] - times[index - 1] != timedelta(hours=1) for index in range(1, len(times))):
        raise RuntimeError("authorized prefix is not hourly")
    return np.asarray(times, dtype=object), np.asarray(values, dtype=np.float64)


def _record_reasons(
    counts: Dict[str, Dict[str, int]], set_name: str, reasons: Sequence[str]
) -> None:
    for reason in reasons:
        counts[set_name][reason] = counts[set_name].get(reason, 0) + 1


def enumerate_record_sets(
    times_beijing: np.ndarray,
    realtime_stages_m: np.ndarray,
    retrospective_targets_m: np.ndarray,
    astronomical_tide_m: np.ndarray,
) -> RecordEnumeration:
    """Enumerate base, observation-head, and exact paired rolling origins."""

    times = np.asarray(times_beijing, dtype=object)
    stages = np.asarray(realtime_stages_m, dtype=np.float64)
    targets = np.asarray(retrospective_targets_m, dtype=np.float64)
    tide = np.asarray(astronomical_tide_m, dtype=np.float64)
    if times.ndim != 1 or len(times) < HISTORY_HOURS + BASE_FORECAST_HOURS:
        raise ValueError("timeline is too short")
    if stages.shape != (len(times), 6):
        raise ValueError("realtime stages must have shape [time, 6]")
    if targets.shape != (len(times), 4):
        raise ValueError("retrospective targets must have shape [time, 4]")
    if tide.shape != (len(times),):
        raise ValueError("astronomical tide must have shape [time]")
    if any(
        not isinstance(time, datetime)
        or time.tzinfo is None
        or time.utcoffset() != timedelta(hours=8)
        for time in times
    ):
        raise ValueError("timeline must contain Beijing-aware datetimes")
    if any(
        times[index] - times[index - 1] != timedelta(hours=1)
        for index in range(1, len(times))
    ):
        raise ValueError("timeline must be hourly without gaps")
    allowed_years = set(TRAIN_YEARS) | {SELECTION_YEAR, DEVELOPMENT_YEAR}
    base_records = []
    observation_records = []
    paired_records = []
    counts: Dict[str, Dict[str, int]] = {
        "base_forecast": {},
        "realtime_observation_head": {},
        "paired_filter": {},
    }
    for position in range(HISTORY_HOURS - 1, len(times) - BASE_FORECAST_HOURS):
        issue_time = times[position]
        if not isinstance(issue_time, datetime) or issue_time.year not in allowed_years:
            continue
        if not window_is_within_one_calendar_year(issue_time):
            for set_name in counts:
                _record_reasons(counts, set_name, ("cross_calendar_year",))
            continue
        history = stages[position - 23 : position + 1]
        future_targets = targets[position + 1 : position + 25]
        future_tide = tide[position + 1 : position + 25]
        analysis_observations = stages[position + 1]
        base_reasons = []
        if not np.isfinite(history).all():
            base_reasons.append("history_realtime_stage_nonfinite")
        if not np.isfinite(future_targets).all():
            base_reasons.append("future_retrospective_target_nonfinite")
        if not np.isfinite(future_tide).all():
            base_reasons.append("future_astronomical_tide_nonfinite")
        observation_reasons = []
        if not np.isfinite(history).all():
            observation_reasons.append("history_realtime_stage_nonfinite")
        if not np.isfinite(analysis_observations).all():
            observation_reasons.append("analysis_realtime_stage_nonfinite")
        if not np.isfinite(future_tide[:1]).all():
            observation_reasons.append("analysis_astronomical_tide_nonfinite")
        record = SampleRecord(position, issue_time)
        if not base_reasons:
            base_records.append(record)
        else:
            _record_reasons(counts, "base_forecast", base_reasons)
        if not observation_reasons:
            observation_records.append(record)
        else:
            _record_reasons(
                counts, "realtime_observation_head", observation_reasons
            )
        paired_reasons = tuple(dict.fromkeys(base_reasons + observation_reasons))
        if not paired_reasons:
            paired_records.append(record)
        else:
            _record_reasons(counts, "paired_filter", paired_reasons)
    return RecordEnumeration(
        base_forecast_records=tuple(base_records),
        realtime_observation_head_records=tuple(observation_records),
        paired_filter_records=tuple(paired_records),
        exclusion_counts={key: dict(value) for key, value in counts.items()},
    )


def _space_statistics(role: str, values: np.ndarray, axes: Tuple[int, ...]) -> SpaceNormalization:
    array = np.asarray(values, dtype=np.float64)
    if not np.isfinite(array).all():
        raise ValueError(f"normalization values are nonfinite for {role}")
    mean = np.mean(array, axis=axes, dtype=np.float64)
    scale = np.std(array, axis=axes, ddof=0, dtype=np.float64)
    mean = np.atleast_1d(np.asarray(mean, dtype=np.float64))
    scale = np.atleast_1d(np.asarray(scale, dtype=np.float64))
    if np.any(scale <= 0.0):
        raise ValueError(f"normalization scale is not positive for {role}")
    reduced_count = int(np.prod([array.shape[axis] for axis in axes]))
    count = np.full(mean.shape, reduced_count, dtype=np.int64)
    return SpaceNormalization(role, mean, scale, count)


def fit_four_space_normalization(
    realtime_stages_m: np.ndarray,
    retrospective_targets_m: np.ndarray,
    astronomical_tide_m: np.ndarray,
    paired_training_records: Sequence[SampleRecord],
) -> FourSpaceNormalization:
    """Fit four distinct population-statistic identities on 2017--2021 pairs."""

    records = tuple(paired_training_records)
    if not records:
        raise ValueError("paired training records must not be empty")
    if any(record.issue_time_beijing.year not in TRAIN_YEARS for record in records):
        raise ValueError("normalization records must be from 2017--2021 only")
    stages = np.asarray(realtime_stages_m, dtype=np.float64)
    targets = np.asarray(retrospective_targets_m, dtype=np.float64)
    tide = np.asarray(astronomical_tide_m, dtype=np.float64)
    positions = np.asarray([record.issue_position for record in records], dtype=np.int64)
    history_positions = positions[:, None] + np.arange(-23, 1)[None, :]
    future_positions = positions[:, None] + np.arange(1, 25)[None, :]
    history_values = stages[history_positions]
    tide_values = tide[future_positions, None]
    analysis_values = stages[positions + 1]
    target_values = targets[future_positions]
    normalization = FourSpaceNormalization(
        history_stage=_space_statistics(
            NORMALIZATION_HISTORY_STAGE, history_values, (0, 1)
        ),
        future_tide=_space_statistics(
            NORMALIZATION_FUTURE_TIDE, tide_values, (0, 1)
        ),
        analysis_stage=_space_statistics(
            NORMALIZATION_ANALYSIS_STAGE, analysis_values, (0,)
        ),
        retrospective_target=_space_statistics(
            NORMALIZATION_RETROSPECTIVE_TARGET, target_values, (0, 1)
        ),
    )
    validate_four_space_normalization(normalization)
    return normalization


def _validate_space(space: SpaceNormalization, role: str, width: int) -> None:
    if not isinstance(space, SpaceNormalization) or space.role != role:
        raise ValueError(f"normalization identity mismatch for {role}")
    if (
        np.asarray(space.mean_m).shape != (width,)
        or np.asarray(space.standard_deviation_m).shape != (width,)
        or np.asarray(space.value_count).shape != (width,)
        or not np.isfinite(space.mean_m).all()
        or not np.isfinite(space.standard_deviation_m).all()
        or np.any(np.asarray(space.standard_deviation_m) <= 0)
        or np.any(np.asarray(space.value_count) <= 0)
    ):
        raise ValueError(f"normalization shape or values changed for {role}")


def validate_four_space_normalization(normalization: FourSpaceNormalization) -> None:
    """Reject swapped or malformed normalization identities."""

    if not isinstance(normalization, FourSpaceNormalization):
        raise ValueError("four-space normalization is required")
    _validate_space(normalization.history_stage, NORMALIZATION_HISTORY_STAGE, 6)
    _validate_space(normalization.future_tide, NORMALIZATION_FUTURE_TIDE, 1)
    _validate_space(normalization.analysis_stage, NORMALIZATION_ANALYSIS_STAGE, 6)
    _validate_space(
        normalization.retrospective_target,
        NORMALIZATION_RETROSPECTIVE_TARGET,
        4,
    )


def build_data_from_arrays(
    *,
    times_beijing: np.ndarray,
    realtime_stages_m: np.ndarray,
    retrospective_targets_m: np.ndarray,
    astronomical_tide_m: np.ndarray,
    access_audit: Optional[DataAccessAudit] = None,
) -> SixSourceFourTargetData:
    """Construct the data contract from aligned arrays without file access."""

    audit = access_audit if access_audit is not None else _empty_audit()
    assert_forbidden_target_access_is_zero(audit)
    enumeration = enumerate_record_sets(
        times_beijing,
        realtime_stages_m,
        retrospective_targets_m,
        astronomical_tide_m,
    )
    training_records = tuple(
        record
        for record in enumeration.paired_filter_records
        if record.issue_time_beijing.year in TRAIN_YEARS
    )
    normalization = fit_four_space_normalization(
        realtime_stages_m,
        retrospective_targets_m,
        astronomical_tide_m,
        training_records,
    )
    return SixSourceFourTargetData(
        times_beijing=np.asarray(times_beijing, dtype=object),
        realtime_stages_m=np.asarray(realtime_stages_m, dtype=np.float64),
        retrospective_targets_m=np.asarray(
            retrospective_targets_m, dtype=np.float64
        ),
        astronomical_tide_m=np.asarray(astronomical_tide_m, dtype=np.float64),
        record_enumeration=enumeration,
        normalization=normalization,
        access_audit=audit,
    )


def _load_registered_data(
    *,
    input_root: str | Path = DEFAULT_INPUT_ROOT,
    tide_model_path: str | Path = DEFAULT_TIDE_MODEL_PATH,
    identity_specs: Mapping[str, ContentIdentitySpec],
    expected_rows: int,
    maximum_year: int,
) -> SixSourceFourTargetData:
    """Load one exact registered prefix without reading its following byte."""

    contents, prefix_audit = load_authorized_prefix_bytes(
        input_root, identity_specs=identity_specs
    )
    canonical_times = None
    stage_columns = []
    target_columns = []
    rows_parsed: Dict[str, int] = {}
    values_loaded: Dict[str, int] = {}
    for station in SOURCE_STATIONS:
        relative_path = f"realtime_features/{station}_realtime_features.csv"
        times, values = _parse_prefix_series(
            contents[relative_path],
            expected_fields=FEATURE_FIELDS,
            value_field="STAGE",
            missing_field="is_missing_for_model",
            expected_rows=expected_rows,
        )
        if canonical_times is None:
            canonical_times = times
        elif not np.array_equal(times, canonical_times):
            raise RuntimeError(f"realtime timeline changed for {station}")
        stage_columns.append(values)
        rows_parsed[relative_path] = len(values)
        values_loaded[relative_path] = int(np.isfinite(values).sum())
    for station in TARGET_STATIONS:
        relative_path = f"retrospective_targets/{station}_retrospective_targets.csv"
        times, values = _parse_prefix_series(
            contents[relative_path],
            expected_fields=TARGET_FIELDS,
            value_field="TARGET_STAGE",
            missing_field="is_missing_for_target",
            expected_rows=expected_rows,
        )
        if not np.array_equal(times, canonical_times):
            raise RuntimeError(f"target timeline changed for {station}")
        target_columns.append(values)
        rows_parsed[relative_path] = len(values)
        values_loaded[relative_path] = int(np.isfinite(values).sum())
    assert canonical_times is not None
    if (
        canonical_times[0] != datetime(2017, 1, 1, 0, tzinfo=BEIJING)
        or canonical_times[-1]
        != datetime(maximum_year, 12, 31, 23, tzinfo=BEIJING)
    ):
        raise RuntimeError("registered prefix time boundary changed")
    tide_path = Path(tide_model_path)
    if TIDE_MODULE_EXPECTED_SHA256 != EXPECTED_TIDE_MODEL_SHA256:
        raise RuntimeError("astronomical tide module contract changed")
    tide_model = load_frozen_astronomical_tide(tide_path)
    tide_values = np.asarray(tide_model.predict(canonical_times), dtype=np.float64)
    stage_matrix = np.stack(stage_columns, axis=1)
    target_matrix = np.stack(target_columns, axis=1)
    development_mask = np.asarray(
        [time.year == DEVELOPMENT_YEAR for time in canonical_times], dtype=bool
    )
    period_counts = {
        "training": 0,
        "selection": 0,
        "development_gate": 0,
        "heldout_or_later": 0,
        "boundary_target": 0,
    }
    for time in canonical_times:
        if time.year in TRAIN_YEARS:
            period_counts["training"] += len(TARGET_STATIONS)
        elif time.year == SELECTION_YEAR:
            period_counts["selection"] += len(TARGET_STATIONS)
        elif time.year == DEVELOPMENT_YEAR:
            period_counts["development_gate"] += len(TARGET_STATIONS)
        else:
            period_counts["heldout_or_later"] += len(TARGET_STATIONS)
    audit = DataAccessAudit(
        opened_paths=prefix_audit.opened_paths,
        bytes_read_by_path=dict(prefix_audit.bytes_read_by_path),
        rows_parsed_by_path=rows_parsed,
        values_loaded_by_path=values_loaded,
        target_rows_by_period=period_counts,
        astronomical_tide_model_open_count=1,
        development_feature_bytes_read=(
            prefix_audit.development_feature_bytes_read
        ),
        development_feature_rows_parsed=int(development_mask.sum())
        * len(SOURCE_STATIONS),
        development_feature_values_loaded=int(
            np.isfinite(stage_matrix[development_mask]).sum()
        ),
        development_target_bytes_read=prefix_audit.development_target_bytes_read,
        development_target_rows_parsed=int(development_mask.sum())
        * len(TARGET_STATIONS),
        development_target_values_loaded=int(
            np.isfinite(target_matrix[development_mask]).sum()
        ),
        heldout_target_bytes_read=0,
        heldout_target_rows_parsed=0,
        heldout_target_values_loaded=0,
        boundary_target_bytes_read=0,
        boundary_target_rows_parsed=0,
        boundary_target_values_loaded=0,
    )
    assert_forbidden_target_access_is_zero(audit)
    return build_data_from_arrays(
        times_beijing=canonical_times,
        realtime_stages_m=stage_matrix,
        retrospective_targets_m=target_matrix,
        astronomical_tide_m=tide_values,
        access_audit=audit,
    )


def load_training_selection_data(
    input_root: str | Path = DEFAULT_INPUT_ROOT,
    tide_model_path: str | Path = DEFAULT_TIDE_MODEL_PATH,
) -> SixSourceFourTargetData:
    """Load exactly 2017--2022; no 2023 feature or target byte is read."""

    data = _load_registered_data(
        input_root=input_root,
        tide_model_path=tide_model_path,
        identity_specs=TRAINING_SELECTION_CONTENT_IDENTITIES,
        expected_rows=EXPECTED_TRAINING_SELECTION_ROW_COUNT,
        maximum_year=SELECTION_YEAR,
    )
    development_counter_names = (
        "development_feature_bytes_read",
        "development_feature_rows_parsed",
        "development_feature_values_loaded",
        "development_target_bytes_read",
        "development_target_rows_parsed",
        "development_target_values_loaded",
    )
    if data.access_audit.target_rows_by_period.get("development_gate", 0) != 0:
        raise RuntimeError("training-selection loader touched development data")
    if any(
        type(getattr(data.access_audit, name)) is not int
        or getattr(data.access_audit, name) != 0
        for name in development_counter_names
    ) or data.paired_records_by_split["development_gate"]:
        raise RuntimeError("training-selection loader touched development data")
    return data


def load_development_data(
    input_root: str | Path = DEFAULT_INPUT_ROOT,
    tide_model_path: str | Path = DEFAULT_TIDE_MODEL_PATH,
) -> SixSourceFourTargetData:
    """Load exactly 2017--2023 after all model selection is frozen."""

    return _load_registered_data(
        input_root=input_root,
        tide_model_path=tide_model_path,
        identity_specs=DEVELOPMENT_CONTENT_IDENTITIES,
        expected_rows=EXPECTED_PREFIX_ROW_COUNT,
        maximum_year=DEVELOPMENT_YEAR,
    )


class SixSourceFourTargetDataset(Dataset):
    """Return one paired origin with four explicitly separated spaces."""

    def __init__(
        self,
        data: SixSourceFourTargetData,
        records: Sequence[SampleRecord],
    ) -> None:
        if not isinstance(data, SixSourceFourTargetData):
            raise ValueError("SixSourceFourTargetData is required")
        assert_forbidden_target_access_is_zero(data.access_audit)
        validate_four_space_normalization(data.normalization)
        self.data = data
        self.records = tuple(records)
        registered = frozenset(data.record_enumeration.paired_filter_records)
        if any(record not in registered for record in self.records):
            raise ValueError("dataset records must be registered paired records")

    def __len__(self) -> int:
        return len(self.records)

    def get_prior_input(self, index: int) -> Mapping[str, object]:
        """Return history and tide without reading the t+1 realtime observation."""

        if type(index) is not int or index < 0 or index >= len(self.records):
            raise IndexError("dataset index must be an in-range integer")
        record = self.records[index]
        position = record.issue_position
        history = self.data.realtime_stages_m[position - 23 : position + 1]
        tide = self.data.astronomical_tide_m[position + 1 : position + 25]
        if (
            history.shape != (24, 6)
            or tide.shape != (24,)
            or not np.isfinite(history).all()
            or not np.isfinite(tide).all()
        ):
            raise ValueError("registered prior input became incomplete")
        normalization = self.data.normalization
        normalized_history = (
            history - normalization.history_stage.mean_m[None, :]
        ) / normalization.history_stage.standard_deviation_m[None, :]
        normalized_tide = (
            tide - normalization.future_tide.mean_m[0]
        ) / normalization.future_tide.standard_deviation_m[0]
        return {
            "history": torch.from_numpy(
                normalized_history.astype(np.float32, copy=True)
            ),
            "future_tide": torch.from_numpy(
                normalized_tide.astype(np.float32, copy=True)
            ),
            "issue_position": position,
            "issue_time_beijing": record.issue_time_beijing.isoformat(),
        }

    def get_analysis_observation(self, index: int) -> torch.Tensor:
        """Read and normalize six t+1 realtime values after priors exist."""

        if type(index) is not int or index < 0 or index >= len(self.records):
            raise IndexError("dataset index must be an in-range integer")
        position = self.records[index].issue_position
        observations = self.data.realtime_stages_m[position + 1]
        if observations.shape != (6,) or not np.isfinite(observations).all():
            raise ValueError("registered analysis observation became incomplete")
        normalization = self.data.normalization.analysis_stage
        normalized = (
            observations - normalization.mean_m
        ) / normalization.standard_deviation_m
        return torch.from_numpy(normalized.astype(np.float32, copy=True))

    def __getitem__(self, index: int) -> Mapping[str, object]:
        if type(index) is not int or index < 0 or index >= len(self.records):
            raise IndexError("dataset index must be an in-range integer")
        assert_forbidden_target_access_is_zero(self.data.access_audit)
        record = self.records[index]
        position = record.issue_position
        prior_input = self.get_prior_input(index)
        observations = self.data.realtime_stages_m[position + 1]
        targets = self.data.retrospective_targets_m[position + 1 : position + 25]
        if (
            observations.shape != (6,)
            or targets.shape != (24, 4)
            or not np.isfinite(observations).all()
            or not np.isfinite(targets).all()
        ):
            raise ValueError("registered paired record became incomplete")
        normalization = self.data.normalization
        normalized_observations = (
            observations - normalization.analysis_stage.mean_m
        ) / normalization.analysis_stage.standard_deviation_m
        normalized_targets = (
            targets - normalization.retrospective_target.mean_m[None, :]
        ) / normalization.retrospective_target.standard_deviation_m[None, :]
        return {
            "history": prior_input["history"],
            "future_tide": prior_input["future_tide"],
            "analysis_observations": torch.from_numpy(
                normalized_observations.astype(np.float32, copy=True)
            ),
            "targets_t_plus_1_to_t_plus_24": torch.from_numpy(
                normalized_targets.astype(np.float32, copy=True)
            ),
            "targets_t_plus_2_to_t_plus_24": torch.from_numpy(
                normalized_targets[1:].astype(np.float32, copy=True)
            ),
            "analysis_availability_scenarios": torch.eye(6, dtype=torch.bool),
            "issue_position": position,
            "issue_time_beijing": record.issue_time_beijing.isoformat(),
        }


def build_split_datasets(
    data: SixSourceFourTargetData,
) -> Mapping[str, SixSourceFourTargetDataset]:
    """Build the paired 2017--2021, 2022, and 2023 datasets."""

    grouped = data.paired_records_by_split
    return {
        split_name: SixSourceFourTargetDataset(data, grouped[split_name])
        for split_name in ("training", "selection", "development_gate")
    }
