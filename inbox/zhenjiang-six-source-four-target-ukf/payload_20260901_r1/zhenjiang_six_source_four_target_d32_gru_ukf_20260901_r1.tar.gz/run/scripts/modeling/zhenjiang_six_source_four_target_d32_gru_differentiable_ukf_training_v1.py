#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Training primitives for the six-source/four-target differentiable filter.

The functions in this module operate only on tensors and an already-built
filter.  They never open data files, choose an experiment directory, or start
a formal run.  Every base sample contributes exactly ``6 * 23 * 4 = 552``
equally weighted forecast cells, including the four internal-station self
cells.

Example:
    python -m pytest -q -p no:cacheprovider \
      tests/test_zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_training_v1.py
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Mapping, Tuple

import torch

from zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_v1 import (
    FORECAST_HOURS,
    SOURCE_COUNT,
    TARGET_COUNT,
    SixSourceFourTargetD32GRUDifferentiableUKF,
)


TRAINABLE_FILTER_PARAMETER_COUNT = 38
CELLS_PER_BASE_SAMPLE = SOURCE_COUNT * FORECAST_HOURS * TARGET_COUNT
SELF_SOURCE_TARGET_PAIRS = ((1, 0), (2, 1), (3, 2), (4, 3))


@dataclass
class ErrorAccumulator:
    """Accumulate an epoch by error sum and exact cell count."""

    absolute_error_sum_m: float = 0.0
    cell_count: int = 0
    base_sample_count: int = 0
    completed_batch_count: int = 0

    def add(
        self,
        error_sum: torch.Tensor | float,
        cell_count: int,
        base_sample_count: int,
    ) -> None:
        if type(cell_count) is not int or cell_count < 1:
            raise ValueError("cell_count must be a positive integer")
        if type(base_sample_count) is not int or base_sample_count < 1:
            raise ValueError("base_sample_count must be a positive integer")
        value = float(
            error_sum.detach().cpu().item()
            if isinstance(error_sum, torch.Tensor)
            else error_sum
        )
        if not torch.isfinite(torch.tensor(value, dtype=torch.float64)):
            raise ValueError("absolute error sum must be finite")
        if value < 0.0:
            raise ValueError("absolute error sum must be nonnegative")
        self.absolute_error_sum_m += value
        self.cell_count += cell_count
        self.base_sample_count += base_sample_count
        self.completed_batch_count += 1

    def summary(self) -> Dict[str, float | int]:
        if self.cell_count < 1 or self.base_sample_count < 1:
            raise RuntimeError("epoch contains no forecast cells")
        expected = self.base_sample_count * CELLS_PER_BASE_SAMPLE
        if self.cell_count != expected:
            raise RuntimeError(
                "epoch cell count differs from 552 per base sample"
            )
        return {
            "absolute_error_sum_m": self.absolute_error_sum_m,
            "valid_cell_count": self.cell_count,
            "base_sample_count": self.base_sample_count,
            "completed_batches": self.completed_batch_count,
            "mae_m": self.absolute_error_sum_m / self.cell_count,
        }


def prepare_filter_for_training(
    filter_model: SixSourceFourTargetD32GRUDifferentiableUKF,
    device: torch.device | str,
) -> SixSourceFourTargetD32GRUDifferentiableUKF:
    """Move one filter to a device and reassert the frozen-backbone contract."""

    if not isinstance(
        filter_model, SixSourceFourTargetD32GRUDifferentiableUKF
    ):
        raise ValueError("the six-source/four-target differentiable filter is required")
    torch_device = torch.device(device)
    filter_model = filter_model.to(torch_device)
    filter_model.backbone.requires_grad_(False)
    filter_model.train(True)
    filter_model.backbone.eval()
    trainable = [
        parameter
        for parameter in filter_model.parameters()
        if parameter.requires_grad
    ]
    if sum(parameter.numel() for parameter in trainable) != (
        TRAINABLE_FILTER_PARAMETER_COUNT
    ):
        raise RuntimeError("filter must expose exactly 38 trainable scalars")
    if any(parameter.dtype != torch.float64 for parameter in trainable):
        raise RuntimeError("all 38 filter parameters must use float64")
    if any(parameter.requires_grad for parameter in filter_model.backbone.parameters()):
        raise RuntimeError("shared backbone is unexpectedly trainable")
    if filter_model.backbone.training:
        raise RuntimeError("shared backbone must remain in evaluation mode")
    return filter_model


def all_cell_metre_absolute_error_sum(
    updated_forecast: torch.Tensor,
    targets_t_plus_2_to_t_plus_24: torch.Tensor,
    retrospective_target_standard_deviation_m: torch.Tensor,
) -> Tuple[torch.Tensor, int]:
    """Return the absolute error sum in metres over all 552 cells per sample."""

    if not isinstance(updated_forecast, torch.Tensor) or updated_forecast.ndim != 4:
        raise ValueError("updated forecast must have shape [batch,6,23,4]")
    batch_size = int(updated_forecast.shape[0])
    if batch_size < 1 or updated_forecast.shape != (
        batch_size,
        SOURCE_COUNT,
        FORECAST_HOURS,
        TARGET_COUNT,
    ):
        raise ValueError("updated forecast must have shape [batch,6,23,4]")
    if (
        not isinstance(targets_t_plus_2_to_t_plus_24, torch.Tensor)
        or targets_t_plus_2_to_t_plus_24.shape
        != (batch_size, FORECAST_HOURS, TARGET_COUNT)
    ):
        raise ValueError("targets must have shape [batch,23,4]")
    if (
        not isinstance(retrospective_target_standard_deviation_m, torch.Tensor)
        or retrospective_target_standard_deviation_m.shape != (TARGET_COUNT,)
    ):
        raise ValueError("target standard deviation must have shape [4]")
    if updated_forecast.device != targets_t_plus_2_to_t_plus_24.device:
        raise ValueError("forecast and targets must share one device")
    if updated_forecast.device != retrospective_target_standard_deviation_m.device:
        raise ValueError("target scale must share the forecast device")
    for name, tensor in (
        ("updated forecast", updated_forecast),
        ("targets", targets_t_plus_2_to_t_plus_24),
        ("target scale", retrospective_target_standard_deviation_m),
    ):
        if not tensor.dtype.is_floating_point or not bool(torch.isfinite(tensor).all()):
            raise ValueError(f"{name} must be finite floating point")
    if bool((retrospective_target_standard_deviation_m <= 0.0).any()):
        raise ValueError("target standard deviations must be positive")

    dtype = updated_forecast.dtype
    target = targets_t_plus_2_to_t_plus_24.to(dtype=dtype)
    scale = retrospective_target_standard_deviation_m.to(dtype=dtype)
    error_m = (updated_forecast - target[:, None, :, :]) * scale[
        None, None, None, :
    ]
    error_sum = error_m.abs().sum(dtype=torch.float64)
    cell_count = batch_size * CELLS_PER_BASE_SAMPLE
    if error_sum.ndim != 0 or not bool(torch.isfinite(error_sum)):
        raise RuntimeError("552-cell error sum is invalid")
    return error_sum, cell_count


def all_cell_metre_mean_absolute_error(
    updated_forecast: torch.Tensor,
    targets_t_plus_2_to_t_plus_24: torch.Tensor,
    retrospective_target_standard_deviation_m: torch.Tensor,
) -> torch.Tensor:
    """Return the equally weighted 552-cell mean absolute error in metres."""

    error_sum, count = all_cell_metre_absolute_error_sum(
        updated_forecast,
        targets_t_plus_2_to_t_plus_24,
        retrospective_target_standard_deviation_m,
    )
    return error_sum / count


def validate_filter_forward_output(
    output: Mapping[str, torch.Tensor], batch_size: int
) -> None:
    """Validate the training-relevant fields of one filter forward result."""

    if not isinstance(output, Mapping):
        raise ValueError("filter forward output must be a mapping")
    expected = {
        "updated_forecast": (
            batch_size,
            SOURCE_COUNT,
            FORECAST_HOURS,
            TARGET_COUNT,
        ),
        "base_deterministic_forecast": (
            batch_size,
            FORECAST_HOURS,
            TARGET_COUNT,
        ),
        "unscented_prior_forecast": (
            batch_size,
            FORECAST_HOURS,
            TARGET_COUNT,
        ),
    }
    for name, shape in expected.items():
        value = output.get(name)
        if (
            not isinstance(value, torch.Tensor)
            or value.shape != shape
            or not bool(torch.isfinite(value).all())
        ):
            raise ValueError(f"filter output {name} has an invalid shape or value")


# A descriptive alias retained for callers that spell out the experiment role.
six_source_four_target_metre_absolute_error_sum = (
    all_cell_metre_absolute_error_sum
)


__all__ = [
    "CELLS_PER_BASE_SAMPLE",
    "ErrorAccumulator",
    "SELF_SOURCE_TARGET_PAIRS",
    "TRAINABLE_FILTER_PARAMETER_COUNT",
    "all_cell_metre_absolute_error_sum",
    "all_cell_metre_mean_absolute_error",
    "prepare_filter_for_training",
    "six_source_four_target_metre_absolute_error_sum",
    "validate_filter_forward_output",
]
