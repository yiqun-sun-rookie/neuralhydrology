#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Train the frozen four-target shared-state base model.

Formal mode uses 2017--2021 paired records for fitting and 2022 paired records
for checkpoint selection.  The six-output realtime observation head is frozen
during this stage and fitted by a separate script.

Examples:
    python scripts/modeling/train_zhenjiang_six_source_four_target_d32_gru_v1.py --execution-mode synthetic_smoke --seed 17 --device cpu
    python scripts/modeling/train_zhenjiang_six_source_four_target_d32_gru_v1.py --execution-mode formal --seed 17 --device cuda --output-root /exclusive/root --formal-authorization AUTHORIZED_TASK_11_HPC_TRAINING
"""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
import random
import tempfile
from typing import Dict, Mapping, Optional, Sequence, Tuple

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset

from zhenjiang_six_source_four_target_d32_gru_v1 import (
    EXPECTED_PARAMETER_COUNT,
    SixSourceFourTargetD32GRU,
    trainable_parameter_count,
)
from zhenjiang_six_source_four_target_data_v1 import (
    DEFAULT_INPUT_ROOT,
    DEFAULT_TIDE_MODEL_PATH,
    FourSpaceNormalization,
    build_split_datasets,
    load_training_selection_data,
)


EXPERIMENT_FAMILY = "ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_V1"
ALLOWED_SEEDS = (17, 29, 43)
FORMAL_AUTHORIZATION_TEXT = "AUTHORIZED_TASK_11_HPC_TRAINING"
SMOOTH_ABSOLUTE_ERROR_TRANSITION_M = 0.10
CELLS_PER_SAMPLE = 24 * 4


@dataclass(frozen=True)
class BaseTrainingConfiguration:
    batch_size: int = 128
    maximum_epochs: int = 36
    patience_epochs: int = 4
    minimum_improvement_m: float = 0.0001
    learning_rate: float = 0.001
    weight_decay: float = 0.0001
    maximum_gradient_norm: float = 1.0


FROZEN_CONFIGURATION = BaseTrainingConfiguration()


def smooth_absolute_error_sum_and_count(
    predictions_standardized: torch.Tensor,
    targets_standardized: torch.Tensor,
    target_standard_deviations_m: torch.Tensor,
) -> Tuple[torch.Tensor, int]:
    """Return the 0.10-metre smooth absolute-error sum and exact cell count."""

    if (
        not isinstance(predictions_standardized, torch.Tensor)
        or predictions_standardized.ndim != 3
        or predictions_standardized.shape[1:] != (24, 4)
        or targets_standardized.shape != predictions_standardized.shape
        or predictions_standardized.shape[0] < 1
    ):
        raise ValueError("predictions and targets must have shape [batch, 24, 4]")
    if (
        predictions_standardized.dtype != torch.float32
        or targets_standardized.dtype != torch.float32
        or predictions_standardized.device != targets_standardized.device
        or not bool(torch.isfinite(predictions_standardized).all())
        or not bool(torch.isfinite(targets_standardized).all())
    ):
        raise ValueError("prediction and target tensors must be finite float32 peers")
    scale = torch.as_tensor(
        target_standard_deviations_m,
        dtype=torch.float32,
        device=predictions_standardized.device,
    )
    if scale.shape != (4,) or not bool(torch.isfinite(scale).all()) or bool((scale <= 0).any()):
        raise ValueError("target standard deviations must be four positive values")
    error_m = (predictions_standardized - targets_standardized) * scale[None, None, :]
    absolute_error_m = error_m.abs()
    transition = SMOOTH_ABSOLUTE_ERROR_TRANSITION_M
    element_loss = torch.where(
        absolute_error_m < transition,
        0.5 * absolute_error_m.square() / transition,
        absolute_error_m - 0.5 * transition,
    )
    cell_count = int(predictions_standardized.shape[0]) * CELLS_PER_SAMPLE
    return element_loss.sum(), cell_count


def four_target_smooth_absolute_error(
    predictions_standardized: torch.Tensor,
    targets_standardized: torch.Tensor,
    target_standard_deviations_m: torch.Tensor,
) -> torch.Tensor:
    loss_sum, cell_count = smooth_absolute_error_sum_and_count(
        predictions_standardized,
        targets_standardized,
        target_standard_deviations_m,
    )
    return loss_sum / cell_count


def mean_absolute_error_sum_and_count(
    predictions_standardized: torch.Tensor,
    targets_standardized: torch.Tensor,
    target_standard_deviations_m: torch.Tensor,
) -> Tuple[torch.Tensor, int]:
    """Return ordinary absolute error in metres for 2022 selection."""

    if (
        predictions_standardized.ndim != 3
        or predictions_standardized.shape[1:] != (24, 4)
        or targets_standardized.shape != predictions_standardized.shape
        or predictions_standardized.shape[0] < 1
    ):
        raise ValueError("predictions and targets must have shape [batch, 24, 4]")
    if (
        predictions_standardized.dtype != torch.float32
        or targets_standardized.dtype != torch.float32
        or predictions_standardized.device != targets_standardized.device
        or not bool(torch.isfinite(predictions_standardized).all())
        or not bool(torch.isfinite(targets_standardized).all())
    ):
        raise ValueError("prediction and target tensors must be finite float32 peers")
    scale = torch.as_tensor(
        target_standard_deviations_m,
        dtype=torch.float32,
        device=predictions_standardized.device,
    )
    if (
        scale.shape != (4,)
        or not bool(torch.isfinite(scale).all())
        or bool((scale <= 0).any())
    ):
        raise ValueError("target standard deviations must be four positive values")
    error_m = (predictions_standardized - targets_standardized) * scale[None, None, :]
    return error_m.abs().sum(), int(predictions_standardized.shape[0]) * CELLS_PER_SAMPLE


def configure_base_training_parameters(model: SixSourceFourTargetD32GRU) -> None:
    """Train the encoder, transition, and target head but not the realtime head."""

    if not isinstance(model, SixSourceFourTargetD32GRU):
        raise ValueError("SixSourceFourTargetD32GRU is required")
    model.requires_grad_(True)
    model.realtime_observation_decoder.requires_grad_(False)


def total_parameter_count(model: nn.Module) -> int:
    """Return all scalar parameters, independent of the current freeze mask."""

    return sum(parameter.numel() for parameter in model.parameters())


def _normalization_document(normalization: FourSpaceNormalization) -> Dict[str, object]:
    def one(space):
        return {
            "role": space.role,
            "mean_m": np.asarray(space.mean_m).tolist(),
            "standard_deviation_m": np.asarray(space.standard_deviation_m).tolist(),
            "value_count": np.asarray(space.value_count).tolist(),
        }

    return {
        "history_stage": one(normalization.history_stage),
        "future_tide": one(normalization.future_tide),
        "analysis_stage": one(normalization.analysis_stage),
        "retrospective_target": one(normalization.retrospective_target),
    }


def _checkpoint(
    model: SixSourceFourTargetD32GRU,
    *,
    seed: int,
    epoch: int,
    selection_loss_m: float,
    normalization: FourSpaceNormalization,
) -> Dict[str, object]:
    total_count = total_parameter_count(model)
    base_trainable_count = trainable_parameter_count(model)
    if total_count != EXPECTED_PARAMETER_COUNT:
        raise RuntimeError("total model parameter count changed")
    return {
        "schema_version": 1,
        "experiment_family": EXPERIMENT_FAMILY,
        "seed": seed,
        "epoch": epoch,
        "selection_mean_absolute_error_m": selection_loss_m,
        "model_class": "SixSourceFourTargetD32GRU",
        "total_parameter_count": total_count,
        "base_stage_trainable_parameter_count": base_trainable_count,
        "model_state_dict": {
            key: value.detach().cpu().clone()
            for key, value in model.state_dict().items()
        },
        "normalization": _normalization_document(normalization),
        "training_configuration": asdict(FROZEN_CONFIGURATION),
        "realtime_observation_head_fitted": False,
    }


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _run_epoch(
    model: SixSourceFourTargetD32GRU,
    loader: DataLoader,
    target_scale_m: torch.Tensor,
    *,
    device: torch.device,
    optimizer: Optional[torch.optim.Optimizer],
) -> float:
    training = optimizer is not None
    model.train(training)
    total_sum = 0.0
    total_count = 0
    for batch in loader:
        history = batch["history"].to(device)
        tide = batch["future_tide"].to(device)
        targets = batch["targets_t_plus_1_to_t_plus_24"].to(device)
        if training:
            optimizer.zero_grad(set_to_none=True)
        with torch.set_grad_enabled(training):
            predictions = model(history, tide)
            loss_sum, cell_count = smooth_absolute_error_sum_and_count(
                predictions, targets, target_scale_m
            )
            loss = loss_sum / cell_count
            if training:
                loss.backward()
                nn.utils.clip_grad_norm_(
                    [parameter for parameter in model.parameters() if parameter.requires_grad],
                    FROZEN_CONFIGURATION.maximum_gradient_norm,
                )
                optimizer.step()
        total_sum += float(loss_sum.detach().cpu())
        total_count += cell_count
    if total_count == 0:
        raise ValueError("epoch loader yielded zero cells")
    return total_sum / total_count


def _evaluate_mean_absolute_error(
    model: SixSourceFourTargetD32GRU,
    loader: DataLoader,
    target_scale_m: torch.Tensor,
    *,
    device: torch.device,
) -> float:
    model.eval()
    total_sum = 0.0
    total_count = 0
    with torch.no_grad():
        for batch in loader:
            predictions = model(
                batch["history"].to(device), batch["future_tide"].to(device)
            )
            error_sum, cell_count = mean_absolute_error_sum_and_count(
                predictions,
                batch["targets_t_plus_1_to_t_plus_24"].to(device),
                target_scale_m,
            )
            total_sum += float(error_sum.cpu())
            total_count += cell_count
    if total_count == 0:
        raise ValueError("selection loader yielded zero cells")
    return total_sum / total_count


def train_base_model(
    *,
    training_dataset: Dataset,
    selection_dataset: Dataset,
    normalization: FourSpaceNormalization,
    seed: int,
    device: str | torch.device,
    output_directory: str | Path,
    configuration: BaseTrainingConfiguration = FROZEN_CONFIGURATION,
) -> Mapping[str, object]:
    """Train one seed into an exclusively created output directory."""

    if configuration != FROZEN_CONFIGURATION:
        raise ValueError("base training configuration is frozen")
    if seed not in ALLOWED_SEEDS:
        raise ValueError("seed must be one of 17, 29, or 43")
    if len(training_dataset) == 0 or len(selection_dataset) == 0:
        raise ValueError("training and 2022 selection datasets must be nonempty")
    output_path = Path(output_directory)
    output_path.mkdir(parents=True, exist_ok=False)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch_device = torch.device(device)
    model = SixSourceFourTargetD32GRU().to(torch_device)
    configure_base_training_parameters(model)
    optimizer = torch.optim.AdamW(
        [parameter for parameter in model.parameters() if parameter.requires_grad],
        lr=configuration.learning_rate,
        weight_decay=configuration.weight_decay,
    )
    generator = torch.Generator().manual_seed(seed)
    training_loader = DataLoader(
        training_dataset,
        batch_size=configuration.batch_size,
        shuffle=True,
        generator=generator,
        drop_last=False,
    )
    selection_loader = DataLoader(
        selection_dataset,
        batch_size=configuration.batch_size,
        shuffle=False,
        drop_last=False,
    )
    target_scale = torch.as_tensor(
        normalization.retrospective_target.standard_deviation_m,
        dtype=torch.float32,
        device=torch_device,
    )
    history = []
    best_metric = float("inf")
    best_checkpoint = None
    no_improvement_epochs = 0
    last_checkpoint = None
    for epoch in range(1, configuration.maximum_epochs + 1):
        training_metric = _run_epoch(
            model,
            training_loader,
            target_scale,
            device=torch_device,
            optimizer=optimizer,
        )
        selection_metric = _evaluate_mean_absolute_error(
            model,
            selection_loader,
            target_scale,
            device=torch_device,
        )
        improved = selection_metric < (
            best_metric - configuration.minimum_improvement_m
        )
        row = {
            "epoch": epoch,
            "training_smooth_absolute_error_m": training_metric,
            "selection_mean_absolute_error_m": selection_metric,
            "selected_as_best": improved,
        }
        history.append(row)
        last_checkpoint = _checkpoint(
            model,
            seed=seed,
            epoch=epoch,
            selection_loss_m=selection_metric,
            normalization=normalization,
        )
        if improved:
            best_metric = selection_metric
            best_checkpoint = last_checkpoint
            no_improvement_epochs = 0
        else:
            no_improvement_epochs += 1
        if no_improvement_epochs >= configuration.patience_epochs:
            break
    assert best_checkpoint is not None and last_checkpoint is not None
    best_path = output_path / "best_checkpoint.pt"
    last_path = output_path / "last_checkpoint.pt"
    history_path = output_path / "training_history.json"
    torch.save(best_checkpoint, best_path)
    torch.save(last_checkpoint, last_path)
    history_path.write_text(
        json.dumps(history, indent=2, sort_keys=True, allow_nan=False),
        encoding="utf-8",
    )
    manifest = {
        "schema_version": 1,
        "experiment_family": EXPERIMENT_FAMILY,
        "seed": seed,
        "status": "complete",
        "output_directory": str(output_path.resolve()),
        "best_epoch": int(best_checkpoint["epoch"]),
        "best_selection_mean_absolute_error_m": float(best_metric),
        "total_parameter_count": int(best_checkpoint["total_parameter_count"]),
        "base_stage_trainable_parameter_count": int(
            best_checkpoint["base_stage_trainable_parameter_count"]
        ),
        "realtime_observation_head_fitted": False,
        "files": {
            path.name: {"byte_count": path.stat().st_size, "sha256": _sha256(path)}
            for path in (best_path, last_path, history_path)
        },
    }
    manifest_path = output_path / "completion_manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True, allow_nan=False),
        encoding="utf-8",
    )
    return manifest


class _SyntheticDataset(Dataset):
    def __init__(self, sample_count: int, seed: int) -> None:
        generator = torch.Generator().manual_seed(seed)
        self.history = torch.randn(sample_count, 24, 6, generator=generator)
        self.tide = torch.randn(sample_count, 24, generator=generator)
        self.targets = torch.randn(sample_count, 24, 4, generator=generator)

    def __len__(self) -> int:
        return len(self.history)

    def __getitem__(self, index: int) -> Mapping[str, torch.Tensor]:
        return {
            "history": self.history[index],
            "future_tide": self.tide[index],
            "targets_t_plus_1_to_t_plus_24": self.targets[index],
        }


def _synthetic_normalization() -> FourSpaceNormalization:
    from zhenjiang_six_source_four_target_data_v1 import (
        NORMALIZATION_ANALYSIS_STAGE,
        NORMALIZATION_FUTURE_TIDE,
        NORMALIZATION_HISTORY_STAGE,
        NORMALIZATION_RETROSPECTIVE_TARGET,
        SpaceNormalization,
    )

    def space(role: str, width: int) -> SpaceNormalization:
        return SpaceNormalization(role, np.zeros(width), np.ones(width), np.ones(width, dtype=np.int64))

    return FourSpaceNormalization(
        history_stage=space(NORMALIZATION_HISTORY_STAGE, 6),
        future_tide=space(NORMALIZATION_FUTURE_TIDE, 1),
        analysis_stage=space(NORMALIZATION_ANALYSIS_STAGE, 6),
        retrospective_target=space(NORMALIZATION_RETROSPECTIVE_TARGET, 4),
    )


def run_synthetic_smoke(seed: int, device: str) -> Mapping[str, object]:
    """Run a two-epoch temporary smoke test without touching formal roots."""

    smoke_configuration = BaseTrainingConfiguration(
        batch_size=4,
        maximum_epochs=2,
        patience_epochs=4,
        minimum_improvement_m=0.0001,
        learning_rate=0.001,
        weight_decay=0.0001,
        maximum_gradient_norm=1.0,
    )
    # train_base_model intentionally accepts only the formal configuration, so
    # the smoke executes the same loss and optimizer primitives directly.
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    model = SixSourceFourTargetD32GRU().to(device)
    configure_base_training_parameters(model)
    optimizer = torch.optim.AdamW(
        [parameter for parameter in model.parameters() if parameter.requires_grad],
        lr=smoke_configuration.learning_rate,
        weight_decay=smoke_configuration.weight_decay,
    )
    dataset = _SyntheticDataset(8, seed)
    loader = DataLoader(dataset, batch_size=4, shuffle=False)
    scale = torch.ones(4, dtype=torch.float32, device=device)
    metrics = []
    for _ in range(2):
        metrics.append(
            _run_epoch(model, loader, scale, device=torch.device(device), optimizer=optimizer)
        )
    assert all(np.isfinite(metrics))
    with tempfile.TemporaryDirectory(prefix="zhenjiang_base_synthetic_smoke_") as temporary:
        temporary_path = Path(temporary)
        marker = temporary_path / "synthetic_smoke.json"
        marker.write_text(json.dumps({"seed": seed, "metrics": metrics}), encoding="utf-8")
        assert marker.is_file()
    return {
        "execution_mode": "synthetic_smoke",
        "seed": seed,
        "device": str(device),
        "epochs": 2,
        "metrics_finite": True,
        "formal_output_created": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execution-mode", choices=("synthetic_smoke", "formal"), required=True)
    parser.add_argument("--seed", type=int, choices=ALLOWED_SEEDS, required=True)
    parser.add_argument("--device", required=True)
    parser.add_argument("--input-root", default=str(DEFAULT_INPUT_ROOT))
    parser.add_argument("--tide-model-path", default=str(DEFAULT_TIDE_MODEL_PATH))
    parser.add_argument("--output-root")
    parser.add_argument("--formal-authorization")
    arguments = parser.parse_args()
    if arguments.execution_mode == "synthetic_smoke":
        report = run_synthetic_smoke(arguments.seed, arguments.device)
    else:
        if arguments.formal_authorization != FORMAL_AUTHORIZATION_TEXT:
            raise RuntimeError("formal training authorization text is missing")
        if arguments.output_root is None:
            raise ValueError("--output-root is required in formal mode")
        data = load_training_selection_data(
            arguments.input_root, arguments.tide_model_path
        )
        datasets = build_split_datasets(data)
        report = train_base_model(
            training_dataset=datasets["training"],
            selection_dataset=datasets["selection"],
            normalization=data.normalization,
            seed=arguments.seed,
            device=arguments.device,
            output_directory=Path(arguments.output_root) / f"s{arguments.seed}",
        )
    print(json.dumps(report, indent=2, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
