#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Differentiable unscented filtering for the six-source/four-target model.

This module contains filter mathematics only.  It never opens water-level
files, selects a checkpoint, starts training, or writes an experiment result.
The caller must provide one already selected and frozen-compatible
``SixSourceFourTargetD32GRU`` instance.

Example:
    python -m pytest -q -p no:cacheprovider \
      tests/test_zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_v1.py
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable, Dict, Tuple

import torch
from torch import nn
from torch.nn import functional as F


STATE_DIMENSION = 32
SOURCE_COUNT = 6
TARGET_COUNT = 4
HISTORY_HOURS = 24
FORECAST_HOURS = 23
SIGMA_POINT_COUNT = 65

MERWE_ALPHA = 1.0
MERWE_BETA = 2.0
MERWE_KAPPA = 0.0
MERWE_LAMBDA = 0.0
MERWE_SCALING = 32.0

INITIAL_STATE_VARIANCE = 0.001
PROCESS_INITIAL_VARIANCE = 0.001
OBSERVATION_INITIAL_VARIANCE = 0.01
MINIMUM_NOISE_STANDARD_DEVIATION = 1e-4
RELATIVE_SPECTRAL_FLOOR = 1e-12
MAXIMUM_INPUT_ASYMMETRY = 1e-10
MINIMUM_ALLOWED_INPUT_EIGENVALUE_RELATIVE = -1e-10
MAXIMUM_OUTPUT_ASYMMETRY = 1e-12
MINIMUM_OUTPUT_EIGENVALUE_FRACTION = 0.99


@dataclass(frozen=True)
class GaussianState:
    """A batch of Gaussian state means and full covariance matrices."""

    mean: torch.Tensor
    covariance: torch.Tensor


class PositiveDiagonalCovariance(nn.Module):
    """Represent diagonal variances through softplus standard deviations."""

    def __init__(self, dimension: int, initial_variance: float) -> None:
        super().__init__()
        if type(dimension) is not int or dimension < 1:
            raise ValueError("dimension must be a positive integer")
        if (
            not isinstance(initial_variance, (int, float))
            or not math.isfinite(float(initial_variance))
            or float(initial_variance) <= MINIMUM_NOISE_STANDARD_DEVIATION**2
        ):
            raise ValueError(
                "initial_variance must be finite and exceed the variance floor"
            )
        shifted = (
            math.sqrt(float(initial_variance))
            - MINIMUM_NOISE_STANDARD_DEVIATION
        )
        raw = math.log(math.expm1(shifted))
        self.raw_standard_deviation = nn.Parameter(
            torch.full((dimension,), raw, dtype=torch.float64)
        )

    def standard_deviation(self) -> torch.Tensor:
        """Return ``1e-4 + softplus(raw standard deviation)``."""

        return MINIMUM_NOISE_STANDARD_DEVIATION + F.softplus(
            self.raw_standard_deviation
        )

    def variance(self) -> torch.Tensor:
        """Return variances obtained only by squaring standard deviations."""

        return self.standard_deviation().square()

    def forward(self) -> torch.Tensor:
        """Return one diagonal covariance matrix."""

        return torch.diag(self.variance())


def _require_gaussian_state(state: GaussianState) -> int:
    if not isinstance(state, GaussianState):
        raise ValueError("state must be a GaussianState")
    if (
        state.mean.ndim != 2
        or state.mean.shape[1] != STATE_DIMENSION
        or state.mean.dtype != torch.float64
    ):
        raise ValueError("state mean must be float64 [batch, 32]")
    batch_size = int(state.mean.shape[0])
    if state.covariance.shape != (
        batch_size,
        STATE_DIMENSION,
        STATE_DIMENSION,
    ) or state.covariance.dtype != torch.float64:
        raise ValueError("state covariance must be float64 [batch, 32, 32]")
    if state.mean.device != state.covariance.device:
        raise ValueError("state mean and covariance devices differ")
    if not bool(torch.isfinite(state.mean).all()) or not bool(
        torch.isfinite(state.covariance).all()
    ):
        raise ValueError("state contains a nonfinite value")
    return batch_size


def stabilize_covariance(
    covariance: torch.Tensor,
) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    """Symmetrize and apply the frozen relative spectral floor without jitter."""

    if (
        not isinstance(covariance, torch.Tensor)
        or covariance.ndim < 2
        or covariance.shape[-2:] != (STATE_DIMENSION, STATE_DIMENSION)
        or covariance.dtype != torch.float64
    ):
        raise ValueError("covariance must end in float64 [32, 32]")
    if not bool(torch.isfinite(covariance).all()):
        raise ValueError("covariance contains a nonfinite value")
    transpose = covariance.transpose(-1, -2)
    symmetric = (covariance + transpose) * 0.5
    diagonal_scale = torch.diagonal(
        symmetric, dim1=-2, dim2=-1
    ).abs().amax(dim=-1)
    scale = torch.maximum(diagonal_scale, torch.ones_like(diagonal_scale))
    input_asymmetry = (covariance - transpose).abs().amax(dim=(-2, -1))
    if bool((input_asymmetry > MAXIMUM_INPUT_ASYMMETRY * scale).any()):
        raise ValueError("covariance input asymmetry exceeds the frozen limit")

    eigenvalues, eigenvectors = torch.linalg.eigh(symmetric)
    pre_floor_minimum = eigenvalues[..., 0]
    if bool(
        (
            pre_floor_minimum
            < MINIMUM_ALLOWED_INPUT_EIGENVALUE_RELATIVE * scale
        ).any()
    ):
        raise ValueError("covariance has a clearly negative eigenvalue")
    floor = RELATIVE_SPECTRAL_FLOOR * scale
    clipped_eigenvalues = torch.maximum(eigenvalues, floor.unsqueeze(-1))
    clipped_matrix = (eigenvalues < floor.unsqueeze(-1)).any(dim=-1)
    if bool(clipped_matrix.any()):
        stabilized = (
            eigenvectors
            @ torch.diag_embed(clipped_eigenvalues)
            @ eigenvectors.transpose(-1, -2)
        )
        stabilized = (stabilized + stabilized.transpose(-1, -2)) * 0.5
    else:
        # Avoid undefined eigenvector derivatives for a repeated positive
        # spectrum such as the fixed initial covariance.
        stabilized = symmetric
    output_asymmetry = (
        stabilized - stabilized.transpose(-1, -2)
    ).abs().amax(dim=(-2, -1))
    if bool((output_asymmetry > MAXIMUM_OUTPUT_ASYMMETRY * scale).any()):
        raise RuntimeError("stabilized covariance remains too asymmetric")
    post_floor_minimum = torch.linalg.eigvalsh(stabilized)[..., 0]
    if bool(
        (
            post_floor_minimum
            < MINIMUM_OUTPUT_EIGENVALUE_FRACTION * floor
        ).any()
    ):
        raise RuntimeError("stabilized covariance misses the spectral floor")
    return stabilized, {
        "scale": scale,
        "spectral_floor": floor,
        "input_asymmetry": input_asymmetry,
        "output_asymmetry": output_asymmetry,
        "pre_floor_minimum_eigenvalue": pre_floor_minimum,
        "post_floor_minimum_eigenvalue": post_floor_minimum,
        "clipped_matrix": clipped_matrix,
    }


class DifferentiableMerweUnscentedTransform(nn.Module):
    """The fixed 65-point Merwe transform for a 32-dimensional state."""

    def __init__(self) -> None:
        super().__init__()
        mean_weights = torch.full(
            (SIGMA_POINT_COUNT,),
            1.0 / (2.0 * MERWE_SCALING),
            dtype=torch.float64,
        )
        covariance_weights = mean_weights.clone()
        mean_weights[0] = MERWE_LAMBDA / MERWE_SCALING
        covariance_weights[0] = mean_weights[0] + (
            1.0 - MERWE_ALPHA**2 + MERWE_BETA
        )
        self.register_buffer("mean_weights", mean_weights)
        self.register_buffer("covariance_weights", covariance_weights)

    def sigma_points(self, state: GaussianState) -> torch.Tensor:
        """Return center, positive-column and negative-column sigma points."""

        _require_gaussian_state(state)
        covariance, _ = stabilize_covariance(state.covariance)
        factor, information = torch.linalg.cholesky_ex(
            covariance * MERWE_SCALING, check_errors=False
        )
        if bool((information != 0).any()):
            raise RuntimeError("covariance Cholesky decomposition failed")
        columns = factor.transpose(-1, -2)
        center = state.mean.unsqueeze(1)
        points = torch.cat((center, center + columns, center - columns), dim=1)
        if points.shape[1] != SIGMA_POINT_COUNT:
            raise RuntimeError("unscented transform did not produce 65 points")
        return points

    def predict(
        self,
        state: GaussianState,
        tide: torch.Tensor,
        transition: Callable[[torch.Tensor, torch.Tensor], torch.Tensor],
        process_covariance: torch.Tensor,
    ) -> Tuple[GaussianState, Dict[str, torch.Tensor]]:
        """Propagate all sigma points in float32 and covariance in float64."""

        batch_size = _require_gaussian_state(state)
        if (
            not isinstance(tide, torch.Tensor)
            or tide.shape != (batch_size,)
            or not tide.dtype.is_floating_point
            or tide.device != state.mean.device
            or not bool(torch.isfinite(tide).all())
        ):
            raise ValueError("tide must be finite, colocated and shaped [batch]")
        if not callable(transition):
            raise ValueError("transition must be callable")
        if (
            not isinstance(process_covariance, torch.Tensor)
            or process_covariance.dtype != torch.float64
            or process_covariance.device != state.mean.device
        ):
            raise ValueError("process covariance must be colocated float64")
        if process_covariance.shape == (STATE_DIMENSION, STATE_DIMENSION):
            process = process_covariance.unsqueeze(0)
        elif process_covariance.shape == (
            batch_size,
            STATE_DIMENSION,
            STATE_DIMENSION,
        ):
            process = process_covariance
        else:
            raise ValueError("process covariance has an invalid shape")

        points = self.sigma_points(state)
        flat_points = points.reshape(-1, STATE_DIMENSION).to(torch.float32)
        repeated_tide = (
            tide[:, None]
            .expand(batch_size, SIGMA_POINT_COUNT)
            .reshape(-1)
            .to(torch.float32)
        )
        propagated = transition(flat_points, repeated_tide)
        if (
            not isinstance(propagated, torch.Tensor)
            or propagated.shape
            != (batch_size * SIGMA_POINT_COUNT, STATE_DIMENSION)
            or propagated.dtype != torch.float32
            or not bool(torch.isfinite(propagated).all())
        ):
            raise ValueError(
                "transition output must be finite float32 [batch*65, 32]"
            )
        propagated = propagated.reshape(
            batch_size, SIGMA_POINT_COUNT, STATE_DIMENSION
        ).to(torch.float64)
        mean_weights = self.mean_weights.to(device=propagated.device)
        covariance_weights = self.covariance_weights.to(device=propagated.device)
        mean = torch.einsum("s,bsi->bi", mean_weights, propagated)
        deviations = propagated - mean.unsqueeze(1)
        covariance = torch.einsum(
            "s,bsi,bsj->bij", covariance_weights, deviations, deviations
        )
        covariance, diagnostics = stabilize_covariance(covariance + process)
        return GaussianState(mean, covariance), diagnostics


class SixSourceFourTargetD32GRUDifferentiableUKF(nn.Module):
    """One shared filter with six scalar update scenarios and four targets."""

    def __init__(self, backbone: nn.Module) -> None:
        super().__init__()
        self._validate_backbone(backbone)
        self.backbone = backbone
        self.backbone.requires_grad_(False)
        self.backbone.eval()
        self.unscented_transform = DifferentiableMerweUnscentedTransform()
        self.process_noise = PositiveDiagonalCovariance(
            STATE_DIMENSION, PROCESS_INITIAL_VARIANCE
        )
        self.observation_noise = PositiveDiagonalCovariance(
            SOURCE_COUNT, OBSERVATION_INITIAL_VARIANCE
        )
        self.register_buffer(
            "initial_covariance",
            torch.eye(STATE_DIMENSION, dtype=torch.float64)
            * INITIAL_STATE_VARIANCE,
        )
        trainable = sum(
            parameter.numel()
            for parameter in self.parameters()
            if parameter.requires_grad
        )
        if trainable != STATE_DIMENSION + SOURCE_COUNT:
            raise RuntimeError("the filter must expose exactly 38 trainable scalars")

    @staticmethod
    def _validate_backbone(backbone: nn.Module) -> None:
        if not isinstance(backbone, nn.Module):
            raise ValueError("backbone must be a torch module")
        if getattr(backbone, "state_size", None) != STATE_DIMENSION:
            raise ValueError("backbone must expose state_size=32")
        for name, rows in (
            ("realtime_observation_decoder", SOURCE_COUNT),
            ("retrospective_target_decoder", TARGET_COUNT),
        ):
            decoder = getattr(backbone, name, None)
            if (
                not isinstance(decoder, nn.Linear)
                or decoder.weight.shape != (rows, STATE_DIMENSION)
                or decoder.bias is None
                or decoder.bias.shape != (rows,)
            ):
                raise ValueError("backbone %s has an invalid shape" % name)
            if decoder.weight.dtype != torch.float32 or decoder.bias.dtype != torch.float32:
                raise ValueError(
                    "%s must contain the selected saved float32 values" % name
                )
        if not callable(getattr(backbone, "encode_history", None)):
            raise ValueError("backbone must expose encode_history")
        if not callable(getattr(backbone, "transition_step", None)):
            raise ValueError("backbone must expose transition_step")

    def train(self, mode: bool = True):
        """Change filter mode while keeping the shared backbone frozen."""

        super().train(mode)
        self.backbone.eval()
        return self

    def _device(self) -> torch.device:
        return self.backbone.realtime_observation_decoder.weight.device

    def _validate_inputs(
        self,
        history: torch.Tensor,
        future_tide: torch.Tensor,
        analysis_observation: torch.Tensor,
    ) -> int:
        if not isinstance(history, torch.Tensor) or history.ndim != 3:
            raise ValueError("history must have shape [batch, 24, 6]")
        batch_size = int(history.shape[0])
        if history.shape != (batch_size, HISTORY_HOURS, SOURCE_COUNT):
            raise ValueError("history must have shape [batch, 24, 6]")
        if (
            history.dtype != torch.float32
            or history.device != self._device()
            or not bool(torch.isfinite(history).all())
        ):
            raise ValueError("history must be finite colocated float32")
        if (
            not isinstance(future_tide, torch.Tensor)
            or future_tide.shape != (batch_size, HISTORY_HOURS)
            or future_tide.dtype != torch.float32
            or future_tide.device != self._device()
            or not bool(torch.isfinite(future_tide).all())
        ):
            raise ValueError("future tide must be finite float32 [batch, 24]")
        if (
            not isinstance(analysis_observation, torch.Tensor)
            or analysis_observation.shape != (batch_size, SOURCE_COUNT)
            or not analysis_observation.dtype.is_floating_point
            or analysis_observation.device != self._device()
            or not bool(torch.isfinite(analysis_observation).all())
        ):
            raise ValueError(
                "analysis observation must be finite and shaped [batch, 6]"
            )
        return batch_size

    def _decode_realtime(self, state_mean: torch.Tensor) -> torch.Tensor:
        decoder = self.backbone.realtime_observation_decoder
        return F.linear(
            state_mean,
            decoder.weight.to(torch.float64),
            decoder.bias.to(torch.float64),
        )

    def _decode_target(self, state_mean: torch.Tensor) -> torch.Tensor:
        decoder = self.backbone.retrospective_target_decoder
        return F.linear(
            state_mean,
            decoder.weight.to(torch.float64),
            decoder.bias.to(torch.float64),
        )

    def predict_state(
        self, state: GaussianState, tide: torch.Tensor
    ) -> Tuple[GaussianState, Dict[str, torch.Tensor]]:
        """Advance one Gaussian state by one hour."""

        return self.unscented_transform.predict(
            state,
            tide,
            self.backbone.transition_step,
            self.process_noise(),
        )

    def update_one_source(
        self,
        prior: GaussianState,
        observation: torch.Tensor,
        source_index: int,
    ) -> Dict[str, torch.Tensor | GaussianState]:
        """Apply one scalar Joseph-form update to every row in a batch."""

        batch_size = _require_gaussian_state(prior)
        if type(source_index) is not int or source_index not in range(SOURCE_COUNT):
            raise ValueError("source_index must be an integer from zero through five")
        if (
            not isinstance(observation, torch.Tensor)
            or observation.shape != (batch_size,)
            or not observation.dtype.is_floating_point
            or observation.device != prior.mean.device
            or not bool(torch.isfinite(observation).all())
        ):
            raise ValueError("observation must be finite and shaped [batch]")

        decoder = self.backbone.realtime_observation_decoder
        h = decoder.weight[source_index].to(torch.float64)
        bias = decoder.bias[source_index].to(torch.float64)
        cross_covariance = torch.einsum("bij,j->bi", prior.covariance, h)
        innovation_variance = (
            torch.einsum("j,bj->b", h, cross_covariance)
            + self.observation_noise.variance()[source_index]
        )
        if bool((~torch.isfinite(innovation_variance)).any()) or bool(
            (innovation_variance <= 0.0).any()
        ):
            raise ValueError("innovation variance must be finite and positive")
        kalman_gain = cross_covariance / innovation_variance[:, None]
        predicted_observation = torch.einsum("j,bj->b", h, prior.mean) + bias
        innovation = observation.to(torch.float64) - predicted_observation
        posterior_mean = prior.mean + kalman_gain * innovation[:, None]
        identity = torch.eye(
            STATE_DIMENSION, dtype=torch.float64, device=prior.mean.device
        )
        joseph_factor = identity[None, :, :] - torch.einsum(
            "bi,j->bij", kalman_gain, h
        )
        posterior_covariance = (
            joseph_factor
            @ prior.covariance
            @ joseph_factor.transpose(-1, -2)
            + torch.einsum("bi,bj->bij", kalman_gain, kalman_gain)
            * self.observation_noise.variance()[source_index]
        )
        posterior_covariance, diagnostics = stabilize_covariance(
            posterior_covariance
        )
        contraction = torch.einsum("j,bj->b", h, kalman_gain)
        if bool((contraction <= 0.0).any()) or bool((contraction >= 1.0).any()):
            raise RuntimeError(
                "observation-row times Kalman gain must be strictly in (0, 1)"
            )
        posterior = GaussianState(posterior_mean, posterior_covariance)
        posterior_all_observations = self._decode_realtime(posterior_mean)
        posterior_observation_variance = torch.einsum(
            "j,bjk,k->b", h, posterior_covariance, h
        )
        return {
            "posterior_state": posterior,
            "innovation": innovation,
            "kalman_gain": kalman_gain,
            "innovation_variance": innovation_variance,
            "predicted_observation": predicted_observation,
            "posterior_all_observations": posterior_all_observations,
            "observation_contraction": contraction,
            "posterior_observation_variance": posterior_observation_variance,
            "spectral_floor": diagnostics["spectral_floor"],
            "posterior_minimum_eigenvalue": diagnostics[
                "post_floor_minimum_eigenvalue"
            ],
            "covariance_clipped": diagnostics["clipped_matrix"],
        }

    def update_all_sources(
        self, prior: GaussianState, observations: torch.Tensor
    ) -> Dict[str, torch.Tensor | GaussianState]:
        """Run six isolated scalar scenarios from one unchanged common prior."""

        batch_size = _require_gaussian_state(prior)
        if (
            not isinstance(observations, torch.Tensor)
            or observations.shape != (batch_size, SOURCE_COUNT)
        ):
            raise ValueError("observations must have shape [batch, 6]")
        updates = [
            self.update_one_source(prior, observations[:, source], source)
            for source in range(SOURCE_COUNT)
        ]
        posterior_states = [row["posterior_state"] for row in updates]
        if not all(isinstance(row, GaussianState) for row in posterior_states):
            raise RuntimeError("internal posterior state is invalid")
        return {
            "posterior_state": GaussianState(
                torch.stack([row.mean for row in posterior_states], dim=1),
                torch.stack([row.covariance for row in posterior_states], dim=1),
            ),
            "innovation": torch.stack(
                [row["innovation"] for row in updates], dim=1
            ),
            "kalman_gain": torch.stack(
                [row["kalman_gain"] for row in updates], dim=1
            ),
            "innovation_variance": torch.stack(
                [row["innovation_variance"] for row in updates], dim=1
            ),
            "predicted_observation": torch.stack(
                [row["predicted_observation"] for row in updates], dim=1
            ),
            "posterior_all_observations": torch.stack(
                [row["posterior_all_observations"] for row in updates], dim=1
            ),
            "observation_contraction": torch.stack(
                [row["observation_contraction"] for row in updates], dim=1
            ),
            "posterior_observation_variance": torch.stack(
                [row["posterior_observation_variance"] for row in updates], dim=1
            ),
            "spectral_floor": torch.stack(
                [row["spectral_floor"] for row in updates], dim=1
            ),
            "posterior_minimum_eigenvalue": torch.stack(
                [row["posterior_minimum_eigenvalue"] for row in updates], dim=1
            ),
            "covariance_clipped": torch.stack(
                [row["covariance_clipped"] for row in updates], dim=1
            ),
        }

    def _initial_state(self, history: torch.Tensor) -> GaussianState:
        encoded = self.backbone.encode_history(history)
        if (
            not isinstance(encoded, torch.Tensor)
            or encoded.shape != (history.shape[0], STATE_DIMENSION)
            or encoded.dtype != torch.float32
            or not bool(torch.isfinite(encoded).all())
        ):
            raise ValueError("encoded state must be finite float32 [batch, 32]")
        covariance = self.initial_covariance.to(history.device).expand(
            history.shape[0], -1, -1
        )
        return GaussianState(encoded.to(torch.float64), covariance)

    def _base_deterministic_forecast(
        self, initial_mean: torch.Tensor, future_tide: torch.Tensor
    ) -> torch.Tensor:
        state = initial_mean.to(torch.float32)
        forecasts = []
        for hour_index in range(HISTORY_HOURS):
            state = self.backbone.transition_step(state, future_tide[:, hour_index])
            if state.dtype != torch.float32:
                raise ValueError("transition must retain float32 state")
            if hour_index >= 1:
                forecasts.append(
                    self.backbone.decode_retrospective_target(state).to(torch.float64)
                )
        result = torch.stack(forecasts, dim=1)
        if result.shape != (initial_mean.shape[0], FORECAST_HOURS, TARGET_COUNT):
            raise RuntimeError("base deterministic forecast shape is invalid")
        return result

    def _base_issue_hour_one_target(
        self, initial_mean: torch.Tensor, future_tide: torch.Tensor
    ) -> torch.Tensor:
        state = self.backbone.transition_step(
            initial_mean.to(torch.float32), future_tide[:, 0]
        )
        if state.dtype != torch.float32:
            raise ValueError("transition must retain float32 state")
        result = self.backbone.decode_retrospective_target(state).to(torch.float64)
        if result.shape != (initial_mean.shape[0], TARGET_COUNT):
            raise RuntimeError("base issue-hour-one target shape is invalid")
        return result

    def _propagate_forecast(
        self, state: GaussianState, tide: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        forecasts = []
        means = []
        covariances = []
        current = state
        for hour_index in range(1, HISTORY_HOURS):
            current, _ = self.predict_state(current, tide[:, hour_index])
            forecasts.append(self._decode_target(current.mean))
            means.append(current.mean)
            covariances.append(current.covariance)
        return (
            torch.stack(forecasts, dim=1),
            torch.stack(means, dim=1),
            torch.stack(covariances, dim=1),
        )

    def forward_single_source(
        self,
        history: torch.Tensor,
        future_tide: torch.Tensor,
        analysis_observation: torch.Tensor,
        source_index: int,
    ) -> Dict[str, torch.Tensor]:
        """Run one source independently for scenario-equivalence auditing."""

        batch_size = self._validate_inputs(
            history, future_tide, analysis_observation
        )
        initial = self._initial_state(history)
        base = self._base_deterministic_forecast(initial.mean, future_tide)
        base_hour_one = self._base_issue_hour_one_target(initial.mean, future_tide)
        prior, _ = self.predict_state(initial, future_tide[:, 0])
        update = self.update_one_source(
            prior, analysis_observation[:, source_index], source_index
        )
        posterior = update["posterior_state"]
        if not isinstance(posterior, GaussianState):
            raise RuntimeError("internal posterior state is invalid")
        prior_forecast, prior_mean, prior_covariance = self._propagate_forecast(
            prior, future_tide
        )
        updated_forecast, updated_mean, updated_covariance = (
            self._propagate_forecast(posterior, future_tide)
        )
        if base.shape[0] != batch_size:
            raise RuntimeError("internal batch shape is invalid")
        return {
            "base_deterministic_forecast": base,
            "base_deterministic_issue_hour_one_target": base_hour_one,
            "unscented_prior_forecast": prior_forecast,
            "updated_forecast": updated_forecast,
            "unscented_prior_state_mean": prior_mean,
            "updated_state_mean": updated_mean,
            "unscented_prior_state_covariance": prior_covariance,
            "updated_state_covariance": updated_covariance,
            "analysis_prior_target": self._decode_target(prior.mean),
            "analysis_posterior_target": self._decode_target(posterior.mean),
            "analysis_prior_observation": self._decode_realtime(prior.mean),
            "analysis_posterior_observation": update[
                "posterior_all_observations"
            ],
            "analysis_posterior_state_mean": posterior.mean,
            "analysis_posterior_state_covariance": posterior.covariance,
            "analysis_innovation": update["innovation"],
            "analysis_kalman_gain": update["kalman_gain"],
            "analysis_innovation_variance": update["innovation_variance"],
            "analysis_observation_contraction": update[
                "observation_contraction"
            ],
            "analysis_posterior_observation_variance": update[
                "posterior_observation_variance"
            ],
            "analysis_spectral_floor": update["spectral_floor"],
            "analysis_posterior_minimum_eigenvalue": update[
                "posterior_minimum_eigenvalue"
            ],
            "process_noise_standard_deviation": (
                self.process_noise.standard_deviation()
            ),
            "observation_noise_standard_deviation": (
                self.observation_noise.standard_deviation()
            ),
        }

    def forward(
        self,
        history: torch.Tensor,
        future_tide: torch.Tensor,
        analysis_observation: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """Return common base/prior branches and six isolated update branches."""

        batch_size = self._validate_inputs(
            history, future_tide, analysis_observation
        )
        initial = self._initial_state(history)
        base = self._base_deterministic_forecast(initial.mean, future_tide)
        base_hour_one = self._base_issue_hour_one_target(initial.mean, future_tide)
        prior, _ = self.predict_state(initial, future_tide[:, 0])
        updates = self.update_all_sources(prior, analysis_observation)
        posterior = updates["posterior_state"]
        if not isinstance(posterior, GaussianState):
            raise RuntimeError("internal posterior state is invalid")

        prior_forecast, prior_mean, prior_covariance = self._propagate_forecast(
            prior, future_tide
        )
        flat_posterior = GaussianState(
            posterior.mean.reshape(batch_size * SOURCE_COUNT, STATE_DIMENSION),
            posterior.covariance.reshape(
                batch_size * SOURCE_COUNT, STATE_DIMENSION, STATE_DIMENSION
            ),
        )
        repeated_tide = future_tide[:, None, :].expand(
            batch_size, SOURCE_COUNT, HISTORY_HOURS
        ).reshape(batch_size * SOURCE_COUNT, HISTORY_HOURS)
        updated_forecast, updated_mean, updated_covariance = (
            self._propagate_forecast(flat_posterior, repeated_tide)
        )
        updated_forecast = updated_forecast.reshape(
            batch_size, SOURCE_COUNT, FORECAST_HOURS, TARGET_COUNT
        )
        updated_mean = updated_mean.reshape(
            batch_size, SOURCE_COUNT, FORECAST_HOURS, STATE_DIMENSION
        )
        updated_covariance = updated_covariance.reshape(
            batch_size,
            SOURCE_COUNT,
            FORECAST_HOURS,
            STATE_DIMENSION,
            STATE_DIMENSION,
        )
        result = {
            "base_deterministic_forecast": base,
            "base_deterministic_issue_hour_one_target": base_hour_one,
            "unscented_prior_forecast": prior_forecast,
            "updated_forecast": updated_forecast,
            "unscented_prior_state_mean": prior_mean,
            "updated_state_mean": updated_mean,
            "unscented_prior_state_covariance": prior_covariance,
            "updated_state_covariance": updated_covariance,
            "analysis_prior_target": self._decode_target(prior.mean),
            "analysis_posterior_target": self._decode_target(posterior.mean),
            "analysis_prior_observation": self._decode_realtime(prior.mean),
            "analysis_posterior_observation": updates[
                "posterior_all_observations"
            ],
            "analysis_prior_state_mean": prior.mean,
            "analysis_prior_state_covariance": prior.covariance,
            "analysis_posterior_state_mean": posterior.mean,
            "analysis_posterior_state_covariance": posterior.covariance,
            "analysis_innovation": updates["innovation"],
            "analysis_kalman_gain": updates["kalman_gain"],
            "analysis_innovation_variance": updates["innovation_variance"],
            "analysis_observation_contraction": updates[
                "observation_contraction"
            ],
            "analysis_posterior_observation_variance": updates[
                "posterior_observation_variance"
            ],
            "analysis_spectral_floor": updates["spectral_floor"],
            "analysis_posterior_minimum_eigenvalue": updates[
                "posterior_minimum_eigenvalue"
            ],
            "process_noise_standard_deviation": (
                self.process_noise.standard_deviation()
            ),
            "observation_noise_standard_deviation": (
                self.observation_noise.standard_deviation()
            ),
        }
        for name, value in result.items():
            if not isinstance(value, torch.Tensor) or not bool(
                torch.isfinite(value).all()
            ):
                raise ValueError("forward output %s is not finite" % name)
        return result


__all__ = [
    "DifferentiableMerweUnscentedTransform",
    "GaussianState",
    "PositiveDiagonalCovariance",
    "SixSourceFourTargetD32GRUDifferentiableUKF",
    "stabilize_covariance",
]
