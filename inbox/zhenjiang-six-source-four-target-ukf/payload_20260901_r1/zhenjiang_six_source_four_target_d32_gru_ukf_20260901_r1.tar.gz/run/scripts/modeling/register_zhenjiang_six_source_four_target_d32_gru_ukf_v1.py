#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Validate the nine-task registry for the four-target filter experiment.

Validation is read-only: it creates no result directory and changes no task
status.  File identities are checked against the local payload allow-list so a
bundle cannot silently mix code revisions.

Example:
    python scripts/modeling/register_zhenjiang_six_source_four_target_d32_gru_ukf_v1.py --validate-only
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
from typing import Any, Mapping, Optional, Sequence


PROJECT_ROOT = Path(__file__).resolve().parents[2]
MODELING_DIR = PROJECT_ROOT / "scripts" / "modeling"
if str(MODELING_DIR) not in sys.path:
    sys.path.insert(0, str(MODELING_DIR))

from zhenjiang_six_source_four_target_data_v1 import (  # noqa: E402
    AUTHORIZED_CONTENT_IDENTITIES,
    AUTHORIZED_TARGET_PATHS,
    TRAINING_SELECTION_CONTENT_IDENTITIES,
)
from zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_runner_v1 import (  # noqa: E402
    DEFAULT_REGISTRY_PATH,
    validate_registry_document,
)


REMOTE_ROOT = (
    "/data1/home/sunyiq/"
    "zhenjiang_six_source_four_target_differentiable_ukf_20260901_r1"
)
SOURCE_INPUT_ROOT = (
    "/data1/home/sunyiq/"
    "zhenjiang_d32_differentiable_ukf_20260828_r2/inputs/pre2024-v1"
)
ISOLATED_INPUT_ROOT = REMOTE_ROOT + "/inputs/pre2024-four-target-v1"
TIDE_MODEL_PATH = (
    REMOTE_ROOT
    + "/run/results/modeling/"
    "wusongkou_astronomical_tide_v1_validation/tide_model.json"
)
ACCEPTED_TIDE_MODEL_RELATIVE_PATH = (
    "results/modeling/"
    "wusongkou_astronomical_tide_v1_validation/tide_model.json"
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb", buffering=0) as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _safe_relative_path(text: Any) -> Path:
    if not isinstance(text, str) or not text or "\\" in text or ":" in text:
        raise ValueError("payload path must be normalized project-relative text")
    path = Path(text)
    if path.is_absolute() or ".." in path.parts or "." in path.parts:
        raise ValueError("payload path must be normalized project-relative text")
    if path.parts[0].lower() in {
        "archive",
        "data",
        "logs",
        "migration_packages",
        ".git",
    }:
        raise ValueError("payload path enters a forbidden mutable/data root")
    normalized = path.as_posix()
    if path.parts[0].lower() == "results" and normalized != ACCEPTED_TIDE_MODEL_RELATIVE_PATH:
        raise ValueError("only the accepted hash-bound tide model may enter results")
    if any(
        part.lower() == "__pycache__"
        or part.lower().startswith(".git")
        or part.lower().startswith(".hpc_mailbox")
        for part in path.parts
    ):
        raise ValueError("payload path enters a cache, Git, or mailbox directory")
    if path.suffix.lower() in {
        ".csv",
        ".tsv",
        ".parquet",
        ".feather",
        ".npy",
        ".npz",
        ".h5",
        ".hdf5",
    }:
        raise ValueError("payload path names a forbidden data-like file")
    return path


def validate_registry(
    registry_path: str | Path = DEFAULT_REGISTRY_PATH,
    *,
    project_root: str | Path = PROJECT_ROOT,
) -> Mapping[str, Any]:
    """Validate authorization, task coordinates, paths, inputs, and code hashes."""

    root = Path(project_root).resolve()
    path = Path(registry_path)
    if not path.is_absolute():
        path = root / path
    document = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(document, Mapping):
        raise ValueError("registry root must be an object")
    validate_registry_document(document)

    hpc = document.get("hpc")
    if not isinstance(hpc, Mapping):
        raise ValueError("HPC path contract is missing")
    expected_hpc = {
        "remote_root": REMOTE_ROOT,
        "source_input_root_read_only": SOURCE_INPUT_ROOT,
        "isolated_input_root": ISOLATED_INPUT_ROOT,
        "tide_model_path": TIDE_MODEL_PATH,
        "partition": "hgpu2p",
        "graphics_processor": "RTX 3090",
        "excluded_node": "ngu002",
        "memory_directive_allowed": False,
        "remote_root_top_level_allowlist": [
            "run",
            "inputs",
            "runs",
            "logs",
            "jobs",
            "evidence",
        ],
        "root_creation_policy": "exclusive_root_partial_staging_must_all_be_absent",
        "attempt_creation_policy": "exclusive_attempt_and_partial_must_both_be_absent",
        "smoke_required_before_formal": True,
    }
    if dict(hpc) != expected_hpc:
        raise ValueError("HPC path or safety contract changed")

    input_rows = document.get("input_files")
    if not isinstance(input_rows, list) or len(input_rows) != 11:
        raise ValueError("registry must list exactly eleven copied input files")
    expected_paths = set(AUTHORIZED_CONTENT_IDENTITIES)
    observed_paths = {row.get("path") for row in input_rows if isinstance(row, Mapping)}
    if observed_paths != expected_paths or len(observed_paths) != len(input_rows):
        raise ValueError("eleven-file input allow-list changed or contains duplicates")
    for row in input_rows:
        identity = AUTHORIZED_CONTENT_IDENTITIES[row["path"]]
        expected = {
            "path": identity.relative_path,
            "verification_scope": identity.verification_scope,
            "byte_count": identity.byte_count,
            "sha256": identity.sha256,
            "copy_policy": "read_only_source_to_new_physical_regular_file",
        }
        if row != expected:
            raise ValueError(f"registered input identity changed: {row.get('path')}")
    registered_targets = {
        row["path"] for row in input_rows if row["path"].startswith("retrospective_targets/")
    }
    if registered_targets != set(AUTHORIZED_TARGET_PATHS):
        raise ValueError("boundary target or missing internal target in input allow-list")

    training_rows = document.get("training_selection_prefix_files")
    if not isinstance(training_rows, list) or len(training_rows) != 11:
        raise ValueError("registry must list eleven training-selection prefixes")
    expected_training = {
        identity.relative_path: {
            "path": identity.relative_path,
            "verification_scope": identity.verification_scope,
            "byte_count": identity.byte_count,
            "sha256": identity.sha256,
        }
        for identity in TRAINING_SELECTION_CONTENT_IDENTITIES.values()
    }
    observed_training = {
        row.get("path"): row for row in training_rows if isinstance(row, Mapping)
    }
    if observed_training != expected_training:
        raise ValueError("training-selection prefix identity registry changed")
    if sum(row["byte_count"] for row in training_rows) != 46_826_115:
        raise ValueError("training-selection prefix byte total changed")

    for task in document["tasks"]:
        seed = task["seed"]
        stage = task["stage"]
        expected_output = f"{REMOTE_ROOT}/runs/{stage.replace('_training', '')}/s{seed}/attempt_001"
        if stage == "observation_head":
            expected_output = f"{REMOTE_ROOT}/runs/observation_head/s{seed}/attempt_001"
        elif stage == "filter_training":
            expected_output = f"{REMOTE_ROOT}/runs/filter/s{seed}/attempt_001"
        if task.get("registered_output_path") != expected_output:
            raise ValueError("registered task output path changed")
        if stage in {"observation_head", "filter_training"}:
            expected_base = f"{REMOTE_ROOT}/runs/base/s{seed}/attempt_001/best_checkpoint.pt"
            if task.get("registered_base_checkpoint_path") != expected_base:
                raise ValueError("registered base checkpoint path changed")
        if stage == "base_training":
            expected_smoke = f"{REMOTE_ROOT}/runs/base_smoke/s{seed}/attempt_001"
            if task.get("registered_smoke_path") != expected_smoke:
                raise ValueError("registered base smoke path changed")
        elif stage == "observation_head":
            expected_smoke = (
                f"{REMOTE_ROOT}/runs/observation_head_smoke/s{seed}/attempt_001"
            )
            if task.get("registered_smoke_path") != expected_smoke:
                raise ValueError("registered observation-head smoke path changed")
        if stage == "filter_training":
            expected_head = f"{REMOTE_ROOT}/runs/observation_head/s{seed}/attempt_001/realtime_observation_head.pt"
            expected_smoke = f"{REMOTE_ROOT}/runs/filter_real_batch_smoke/s{seed}/attempt_001"
            if task.get("registered_observation_head_path") != expected_head:
                raise ValueError("registered observation-head path changed")
            if task.get("registered_real_batch_smoke_path") != expected_smoke:
                raise ValueError("registered real-batch smoke path changed")

    post_rows = document.get("post_training_tasks")
    if not isinstance(post_rows, list) or len(post_rows) != 2:
        raise ValueError("registry must contain two post-training evidence tasks")
    post_by_stage = {
        row.get("stage"): row for row in post_rows if isinstance(row, Mapping)
    }
    evaluation_output = (
        f"{REMOTE_ROOT}/evidence/development_2023/evaluation/attempt_001"
    )
    evaluation_smoke = (
        f"{REMOTE_ROOT}/runs/development_evaluation_smoke/attempt_001"
    )
    audit_output = (
        f"{REMOTE_ROOT}/evidence/development_2023/independent_audit/attempt_001"
    )
    if (
        set(post_by_stage) != {"development_2023_evaluation", "independent_audit"}
        or post_by_stage["development_2023_evaluation"].get(
            "registered_output_path"
        )
        != evaluation_output
        or post_by_stage["development_2023_evaluation"].get(
            "registered_smoke_path"
        )
        != evaluation_smoke
        or post_by_stage["independent_audit"].get("registered_output_path")
        != audit_output
        or post_by_stage["independent_audit"].get(
            "registered_evaluation_output_path"
        )
        != evaluation_output
    ):
        raise ValueError("registered post-training evidence paths changed")

    payload_rows = document.get("payload_files")
    if not isinstance(payload_rows, list) or not payload_rows:
        raise ValueError("payload file allow-list must be nonempty")
    seen = set()
    for row in payload_rows:
        if not isinstance(row, Mapping) or set(row) != {"path", "sha256"}:
            raise ValueError("each payload row must contain only path and sha256")
        relative = _safe_relative_path(row["path"])
        normalized = relative.as_posix()
        if normalized in seen:
            raise ValueError("payload file allow-list contains a duplicate path")
        seen.add(normalized)
        expected_hash = row["sha256"]
        if (
            not isinstance(expected_hash, str)
            or len(expected_hash) != 64
            or any(character not in "0123456789abcdef" for character in expected_hash)
        ):
            raise ValueError("payload SHA-256 is invalid")
        source = (root / relative).resolve()
        try:
            source.relative_to(root)
        except ValueError as error:
            raise ValueError("payload path escapes project root") from error
        if not source.is_file() or source.is_symlink():
            raise FileNotFoundError(f"payload source is absent: {normalized}")
        if _sha256(source) != expected_hash:
            raise ValueError(f"payload SHA-256 mismatch: {normalized}")
    if ACCEPTED_TIDE_MODEL_RELATIVE_PATH not in seen:
        raise ValueError("accepted astronomical tide model is not hash-bound")

    stage_counts = {
        stage: sum(row["stage"] == stage for row in document["tasks"])
        for stage in ("base_training", "observation_head", "filter_training")
    }
    return {
        "status": "valid_authorized_pending_submission",
        "registry_path": str(path),
        "base_training_task_count": stage_counts["base_training"],
        "observation_head_task_count": stage_counts["observation_head"],
        "filter_training_task_count": stage_counts["filter_training"],
        "post_training_task_count": len(post_rows),
        "duplicate_task_identifier_count": 0,
        "input_file_count": len(input_rows),
        "training_selection_prefix_file_count": len(training_rows),
        "training_selection_prefix_byte_count": 46_826_115,
        "payload_file_count": len(payload_rows),
        "formal_result_created": False,
        "heldout_2024_target_access_authorized": False,
    }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validate-only", action="store_true", required=True)
    parser.add_argument("--registry", type=Path, default=DEFAULT_REGISTRY_PATH)
    parser.add_argument("--project-root", type=Path, default=PROJECT_ROOT)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    arguments = _parser().parse_args(argv)
    report = validate_registry(
        arguments.registry, project_root=arguments.project_root
    )
    print(json.dumps(report, indent=2, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
