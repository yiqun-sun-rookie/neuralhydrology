#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared 32-dimensional recurrent model with two label-space heads.

The history encoder and astronomical-tide-driven transition are shared.  The
six-output realtime observation head is used only for assimilation innovation;
the four-output retrospective target head is used only for forecast training
and scoring.  This module performs no data access or training.
"""

from __future__ import annotations

from typing import Tuple

import torch
from torch import nn


SOURCE_STATIONS: Tuple[str, ...] = (
    "datong",
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
TARGET_STATIONS: Tuple[str, ...] = (
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
)
HISTORY_HOURS = 24
FORECAST_HOURS = 24
ENCODER_HIDDEN_SIZE = 64
STATE_DIMENSION = 32
EXPECTED_PARAMETER_COUNT = 19_594
REALTIME_OBSERVATION_NORMALIZATION_ROLE = "analysis_t_plus_1_realtime_stage"
RETROSPECTIVE_TARGET_NORMALIZATION_ROLE = "four_internal_retrospective_targets"


def trainable_parameter_count(model: nn.Module) -> int:
    """Return the exact number of trainable scalar parameters."""

    return sum(
        parameter.numel()
        for parameter in model.parameters()
        if parameter.requires_grad
    )


def _validate_tensor(
    value: torch.Tensor,
    *,
    name: str,
    shape: Tuple[int, ...],
    reference: torch.Tensor,
) -> None:
    if not isinstance(value, torch.Tensor) or tuple(value.shape) != shape:
        raise ValueError(f"{name} must have shape {shape}")
    if (
        not value.dtype.is_floating_point
        or value.dtype != reference.dtype
        or value.device != reference.device
        or not bool(torch.isfinite(value).all())
    ):
        raise ValueError(f"{name} must be finite and match the model")


class SixSourceFourTargetD32GRU(nn.Module):
    """Forecast four targets through one shared state and two separate heads."""

    state_size = STATE_DIMENSION
    realtime_observation_normalization_role = (
        REALTIME_OBSERVATION_NORMALIZATION_ROLE
    )
    retrospective_target_normalization_role = (
        RETROSPECTIVE_TARGET_NORMALIZATION_ROLE
    )

    def __init__(self) -> None:
        super().__init__()
        self.history_encoder = nn.GRU(
            input_size=len(SOURCE_STATIONS),
            hidden_size=ENCODER_HIDDEN_SIZE,
            batch_first=True,
        )
        self.state_projection = nn.Linear(ENCODER_HIDDEN_SIZE, STATE_DIMENSION)
        self.process_cell = nn.GRUCell(input_size=1, hidden_size=STATE_DIMENSION)
        self.realtime_observation_decoder = nn.Linear(
            STATE_DIMENSION, len(SOURCE_STATIONS)
        )
        self.retrospective_target_decoder = nn.Linear(
            STATE_DIMENSION, len(TARGET_STATIONS)
        )
        actual = trainable_parameter_count(self)
        if actual != EXPECTED_PARAMETER_COUNT:
            raise RuntimeError(
                f"model parameter count changed: {actual} != {EXPECTED_PARAMETER_COUNT}"
            )

    def _reference(self) -> torch.Tensor:
        return self.state_projection.weight

    def _validate_history(self, history: torch.Tensor) -> int:
        if not isinstance(history, torch.Tensor) or history.ndim != 3:
            raise ValueError("history must have shape [batch, 24, 6]")
        batch_size = int(history.shape[0])
        if batch_size < 1:
            raise ValueError("history must contain at least one sample")
        _validate_tensor(
            history,
            name="history",
            shape=(batch_size, HISTORY_HOURS, len(SOURCE_STATIONS)),
            reference=self._reference(),
        )
        return batch_size

    def _validate_state(self, state: torch.Tensor) -> int:
        if not isinstance(state, torch.Tensor) or state.ndim != 2:
            raise ValueError("state must have shape [batch, 32]")
        batch_size = int(state.shape[0])
        if batch_size < 1:
            raise ValueError("state must contain at least one sample")
        _validate_tensor(
            state,
            name="state",
            shape=(batch_size, STATE_DIMENSION),
            reference=self._reference(),
        )
        return batch_size

    def encode_history(self, history: torch.Tensor) -> torch.Tensor:
        """Compress standardized ``[batch,24,6]`` histories to ``[batch,32]``."""

        self._validate_history(history)
        _, hidden = self.history_encoder(history)
        return torch.tanh(self.state_projection(hidden[-1]))

    def transition_step(
        self, state: torch.Tensor, astronomical_tide: torch.Tensor
    ) -> torch.Tensor:
        """Advance a shared state by one hour using only astronomical tide."""

        batch_size = self._validate_state(state)
        _validate_tensor(
            astronomical_tide,
            name="astronomical_tide",
            shape=(batch_size,),
            reference=self._reference(),
        )
        return self.process_cell(astronomical_tide[:, None], state)

    def decode_realtime_observation(self, state: torch.Tensor) -> torch.Tensor:
        """Decode six standardized realtime ``STAGE`` values."""

        self._validate_state(state)
        return self.realtime_observation_decoder(state)

    def decode_retrospective_target(self, state: torch.Tensor) -> torch.Tensor:
        """Decode four standardized retrospective ``TARGET_STAGE`` values."""

        self._validate_state(state)
        return self.retrospective_target_decoder(state)

    def forecast_from_state(
        self, initial_state: torch.Tensor, future_tide: torch.Tensor
    ) -> torch.Tensor:
        """Propagate one state and return ``[batch,24,4]`` target forecasts."""

        batch_size = self._validate_state(initial_state)
        _validate_tensor(
            future_tide,
            name="future_tide",
            shape=(batch_size, FORECAST_HOURS),
            reference=self._reference(),
        )
        state = initial_state
        predictions = []
        for hour_index in range(FORECAST_HOURS):
            state = self.transition_step(state, future_tide[:, hour_index])
            predictions.append(self.decode_retrospective_target(state))
        return torch.stack(predictions, dim=1)

    def forward(
        self, history: torch.Tensor, future_tide: torch.Tensor
    ) -> torch.Tensor:
        """Return standardized four-target forecasts with shape ``[batch,24,4]``."""

        batch_size = self._validate_history(history)
        _validate_tensor(
            future_tide,
            name="future_tide",
            shape=(batch_size, FORECAST_HOURS),
            reference=self._reference(),
        )
        return self.forecast_from_state(self.encode_history(history), future_tide)
