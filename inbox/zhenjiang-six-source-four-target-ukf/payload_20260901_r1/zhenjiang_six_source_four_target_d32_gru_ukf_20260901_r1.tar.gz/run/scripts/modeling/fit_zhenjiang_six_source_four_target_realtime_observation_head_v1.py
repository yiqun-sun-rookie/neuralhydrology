#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Fit the shared six-output realtime observation head after base training.

The design state is the exact 65-sigma-point analysis-prior mean produced by
the runtime transition.  All prior states are generated before this script
asks the dataset for any ``STAGE[t+1]`` observation.

Example:
    python scripts/modeling/fit_zhenjiang_six_source_four_target_realtime_observation_head_v1.py --execution-mode synthetic_smoke --seed 17 --device cpu
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import tempfile
from typing import Dict, Mapping, Optional, Sequence, Tuple

import numpy as np
import torch

from zhenjiang_six_source_four_target_d32_gru_v1 import (
    EXPECTED_PARAMETER_COUNT,
    SixSourceFourTargetD32GRU,
    trainable_parameter_count,
)
from zhenjiang_six_source_four_target_data_v1 import (
    DEFAULT_INPUT_ROOT,
    DEFAULT_TIDE_MODEL_PATH,
    SixSourceFourTargetDataset,
    build_split_datasets,
    load_training_selection_data,
)
from train_zhenjiang_six_source_four_target_d32_gru_v1 import (
    ALLOWED_SEEDS,
    FORMAL_AUTHORIZATION_TEXT,
    _normalization_document,
    configure_base_training_parameters,
    total_parameter_count,
)


STATE_DIMENSION = 32
SIGMA_POINT_COUNT = 65
INITIAL_STATE_VARIANCE = 0.001
RIDGE_STRENGTHS = (0.0, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1.0)
TIE_TOLERANCE_M = 1e-12


@dataclass(frozen=True)
class RidgeCandidate:
    ridge_strength: float
    weight_float32: np.ndarray
    bias_float32: np.ndarray
    selection_mean_absolute_error_m: float
    station_selection_mean_absolute_error_m: np.ndarray
    augmented_design_singular_values: np.ndarray
    augmented_design_rank: int
    augmented_design_condition_number: Optional[float]
    coefficient_float64_sha256: str
    coefficient_float32_sha256: str


@dataclass(frozen=True)
class ObservationHeadSelection:
    selected: RidgeCandidate
    candidates: Tuple[RidgeCandidate, ...]


def _select_ridge_candidate(
    candidates: Sequence[RidgeCandidate],
) -> RidgeCandidate:
    """Apply the frozen tolerance only against the global minimum error."""

    if not candidates:
        raise ValueError("at least one ridge candidate is required")
    global_minimum = min(
        candidate.selection_mean_absolute_error_m for candidate in candidates
    )
    tied_to_global_minimum = [
        candidate
        for candidate in candidates
        if candidate.selection_mean_absolute_error_m - global_minimum
        <= TIE_TOLERANCE_M
    ]
    return max(tied_to_global_minimum, key=lambda candidate: candidate.ridge_strength)


def _array_sha256(*arrays: np.ndarray) -> str:
    digest = hashlib.sha256()
    for array in arrays:
        contiguous = np.ascontiguousarray(array)
        digest.update(str(contiguous.dtype).encode("ascii"))
        digest.update(str(contiguous.shape).encode("ascii"))
        digest.update(contiguous.tobytes(order="C"))
    return digest.hexdigest()


def unscented_analysis_prior_mean(
    model: torch.nn.Module,
    history: torch.Tensor,
    tide_t_plus_1: torch.Tensor,
    *,
    initial_state_variance: float = INITIAL_STATE_VARIANCE,
) -> torch.Tensor:
    """Return the runtime-equivalent 65-point propagated mean in float64."""

    if history.ndim != 3 or history.shape[1:] != (24, 6):
        raise ValueError("history must have shape [batch, 24, 6]")
    batch_size = int(history.shape[0])
    if tide_t_plus_1.shape != (batch_size,):
        raise ValueError("tide_t_plus_1 must have shape [batch]")
    if history.dtype != torch.float32 or tide_t_plus_1.dtype != torch.float32:
        raise ValueError("runtime transition inputs must use float32")
    if history.device != tide_t_plus_1.device:
        raise ValueError("history and tide must share a device")
    if not bool(torch.isfinite(history).all()) or not bool(torch.isfinite(tide_t_plus_1).all()):
        raise ValueError("prior inputs must be finite")
    encoded = model.encode_history(history)
    if encoded.shape != (batch_size, STATE_DIMENSION) or encoded.dtype != torch.float32:
        raise ValueError("encoded state must be float32 [batch, 32]")
    mean = encoded.to(torch.float64)
    covariance = (
        torch.eye(STATE_DIMENSION, dtype=torch.float64, device=history.device)
        * float(initial_state_variance)
    ).expand(batch_size, -1, -1)
    # Merwe alpha=1, beta=2, kappa=0 gives lambda=0 and scaling=32.
    square_root = torch.linalg.cholesky(covariance * STATE_DIMENSION)
    directions = square_root.transpose(-1, -2)
    sigma_points = torch.cat(
        [
            mean[:, None, :],
            mean[:, None, :] + directions,
            mean[:, None, :] - directions,
        ],
        dim=1,
    )
    if sigma_points.shape != (batch_size, SIGMA_POINT_COUNT, STATE_DIMENSION):
        raise RuntimeError("sigma-point construction changed")
    flat_points = sigma_points.reshape(-1, STATE_DIMENSION).to(torch.float32)
    repeated_tide = tide_t_plus_1[:, None].expand(-1, SIGMA_POINT_COUNT).reshape(-1)
    propagated = model.transition_step(flat_points, repeated_tide)
    if propagated.shape != flat_points.shape or propagated.dtype != torch.float32:
        raise ValueError("transition must return float32 [batch*65, 32]")
    propagated = propagated.reshape(
        batch_size, SIGMA_POINT_COUNT, STATE_DIMENSION
    ).to(torch.float64)
    weights = torch.full(
        (SIGMA_POINT_COUNT,),
        1.0 / (2.0 * STATE_DIMENSION),
        dtype=torch.float64,
        device=history.device,
    )
    weights[0] = 0.0
    prior_mean = torch.sum(propagated * weights[None, :, None], dim=1)
    if not bool(torch.isfinite(prior_mean).all()):
        raise RuntimeError("analysis prior mean is nonfinite")
    return prior_mean


def collect_prior_states_before_observations(
    model: torch.nn.Module,
    dataset: SixSourceFourTargetDataset,
    *,
    device: str | torch.device,
    batch_size: int = 128,
) -> np.ndarray:
    """Collect all prior states without calling the observation accessor."""

    if type(batch_size) is not int or batch_size < 1:
        raise ValueError("batch_size must be positive")
    values = []
    model.eval()
    torch_device = torch.device(device)
    with torch.no_grad():
        for start in range(0, len(dataset), batch_size):
            inputs = [
                dataset.get_prior_input(index)
                for index in range(start, min(start + batch_size, len(dataset)))
            ]
            history = torch.stack([item["history"] for item in inputs]).to(torch_device)
            tide = torch.stack([item["future_tide"] for item in inputs]).to(torch_device)
            values.append(
                unscented_analysis_prior_mean(model, history, tide[:, 0]).cpu().numpy()
            )
    if not values:
        raise ValueError("prior dataset must be nonempty")
    return np.concatenate(values, axis=0).astype(np.float64, copy=False)


def collect_analysis_observations_after_priors(
    dataset: SixSourceFourTargetDataset,
) -> np.ndarray:
    """Collect standardized six-station observations in a separate second pass."""

    if len(dataset) == 0:
        raise ValueError("observation dataset must be nonempty")
    return np.stack(
        [dataset.get_analysis_observation(index).numpy() for index in range(len(dataset))],
        axis=0,
    ).astype(np.float64)


def collect_prior_design_and_observations(
    model: torch.nn.Module,
    dataset: SixSourceFourTargetDataset,
    *,
    device: str | torch.device,
    batch_size: int = 128,
) -> Tuple[np.ndarray, np.ndarray]:
    """Enforce the prior-first, observation-second collection order."""

    priors = collect_prior_states_before_observations(
        model, dataset, device=device, batch_size=batch_size
    )
    observations = collect_analysis_observations_after_priors(dataset)
    return priors, observations


def _ridge_with_unpenalized_intercept(
    design: np.ndarray, observations: np.ndarray, ridge_strength: float
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, int, Optional[float]]:
    x = np.asarray(design, dtype=np.float64)
    y = np.asarray(observations, dtype=np.float64)
    if x.ndim != 2 or x.shape[1] != STATE_DIMENSION or y.shape != (x.shape[0], 6):
        raise ValueError("ridge inputs must be [sample,32] and [sample,6]")
    if x.shape[0] < 1 or not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError("ridge inputs must be nonempty and finite")
    if ridge_strength not in RIDGE_STRENGTHS:
        raise ValueError("ridge strength is not frozen")
    x_mean = x.mean(axis=0, dtype=np.float64)
    y_mean = y.mean(axis=0, dtype=np.float64)
    centered_x = x - x_mean
    centered_y = y - y_mean
    u, singular_values, vt = np.linalg.svd(centered_x, full_matrices=False)
    tolerance = (
        max(centered_x.shape) * np.finfo(np.float64).eps * singular_values[0]
        if singular_values.size
        else 0.0
    )
    if ridge_strength == 0.0:
        factors = np.zeros_like(singular_values)
        retained = singular_values > tolerance
        factors[retained] = 1.0 / singular_values[retained]
    else:
        factors = singular_values / (
            np.square(singular_values) + float(ridge_strength)
        )
    slopes = (vt.T * factors[None, :]) @ (u.T @ centered_y)
    intercept = y_mean - x_mean @ slopes
    augmented = np.concatenate(
        [np.ones((x.shape[0], 1), dtype=np.float64), x], axis=1
    )
    augmented_singular_values = np.linalg.svd(
        augmented, full_matrices=False, compute_uv=False
    )
    augmented_tolerance = (
        max(augmented.shape)
        * np.finfo(np.float64).eps
        * augmented_singular_values[0]
    )
    rank = int(np.count_nonzero(augmented_singular_values > augmented_tolerance))
    positive = augmented_singular_values[
        augmented_singular_values > augmented_tolerance
    ]
    condition = (
        float(positive[0] / positive[-1])
        if rank == min(augmented.shape) and positive.size
        else None
    )
    return slopes, intercept, augmented_singular_values, rank, condition


def fit_and_select_observation_head(
    training_states: np.ndarray,
    training_observations_standardized: np.ndarray,
    selection_states: np.ndarray,
    selection_observations_standardized: np.ndarray,
    observation_standard_deviations_m: np.ndarray,
    *,
    ridge_strengths: Sequence[float] = RIDGE_STRENGTHS,
) -> ObservationHeadSelection:
    """Fit every frozen candidate, quantize once, and select one common ridge."""

    strengths = tuple(float(value) for value in ridge_strengths)
    if strengths != RIDGE_STRENGTHS:
        raise ValueError("ridge candidate sequence is frozen")
    selection_x = np.asarray(selection_states, dtype=np.float64)
    selection_y = np.asarray(selection_observations_standardized, dtype=np.float64)
    scales = np.asarray(observation_standard_deviations_m, dtype=np.float64)
    if selection_x.ndim != 2 or selection_x.shape[1] != 32:
        raise ValueError("selection states must have shape [sample, 32]")
    if selection_y.shape != (selection_x.shape[0], 6) or scales.shape != (6,):
        raise ValueError("selection observations/scales have wrong shape")
    if not np.isfinite(selection_x).all() or not np.isfinite(selection_y).all() or not np.isfinite(scales).all() or np.any(scales <= 0):
        raise ValueError("selection values must be finite with positive scales")
    candidates = []
    for strength in strengths:
        slopes, intercept, singular_values, rank, condition = (
            _ridge_with_unpenalized_intercept(
                training_states, training_observations_standardized, strength
            )
        )
        weight_float32 = slopes.T.astype(np.float32)
        bias_float32 = intercept.astype(np.float32)
        # The exact values saved to the checkpoint are the exact values scored.
        prediction = (
            selection_x @ weight_float32.astype(np.float64).T
            + bias_float32.astype(np.float64)[None, :]
        )
        absolute_error_m = np.abs(prediction - selection_y) * scales[None, :]
        station_mae = absolute_error_m.mean(axis=0, dtype=np.float64)
        candidate = RidgeCandidate(
            ridge_strength=strength,
            weight_float32=weight_float32,
            bias_float32=bias_float32,
            selection_mean_absolute_error_m=float(
                absolute_error_m.mean(dtype=np.float64)
            ),
            station_selection_mean_absolute_error_m=station_mae,
            augmented_design_singular_values=singular_values,
            augmented_design_rank=rank,
            augmented_design_condition_number=condition,
            coefficient_float64_sha256=_array_sha256(slopes, intercept),
            coefficient_float32_sha256=_array_sha256(
                weight_float32, bias_float32
            ),
        )
        candidates.append(candidate)
    selected = _select_ridge_candidate(candidates)
    return ObservationHeadSelection(selected=selected, candidates=tuple(candidates))


def install_selected_head(
    model: SixSourceFourTargetD32GRU,
    selection: ObservationHeadSelection,
) -> None:
    """Install exactly the float32 coefficients that 2022 selection scored."""

    candidate = selection.selected
    if candidate.weight_float32.dtype != np.float32 or candidate.bias_float32.dtype != np.float32:
        raise ValueError("selected observation head must already be float32")
    with torch.no_grad():
        model.realtime_observation_decoder.weight.copy_(
            torch.from_numpy(candidate.weight_float32).to(
                model.realtime_observation_decoder.weight.device
            )
        )
        model.realtime_observation_decoder.bias.copy_(
            torch.from_numpy(candidate.bias_float32).to(
                model.realtime_observation_decoder.bias.device
            )
        )


def _candidate_document(candidate: RidgeCandidate) -> Mapping[str, object]:
    return {
        "ridge_strength": candidate.ridge_strength,
        "selection_mean_absolute_error_m": candidate.selection_mean_absolute_error_m,
        "station_selection_mean_absolute_error_m": candidate.station_selection_mean_absolute_error_m.tolist(),
        "augmented_design_singular_values": candidate.augmented_design_singular_values.tolist(),
        "augmented_design_rank": candidate.augmented_design_rank,
        "augmented_design_condition_number": candidate.augmented_design_condition_number,
        "coefficient_float64_sha256": candidate.coefficient_float64_sha256,
        "coefficient_float32_sha256": candidate.coefficient_float32_sha256,
    }


def save_observation_head_selection(
    *,
    model: SixSourceFourTargetD32GRU,
    selection: ObservationHeadSelection,
    seed: int,
    base_checkpoint: str | Path,
    output_directory: str | Path,
) -> Mapping[str, object]:
    """Write one head and its full candidate diagnostics to a new directory."""

    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=False)
    base_path = Path(base_checkpoint)
    base_digest = hashlib.sha256(base_path.read_bytes()).hexdigest()
    install_selected_head(model, selection)
    selected = selection.selected
    artifact = {
        "schema_version": 1,
        "seed": seed,
        "base_checkpoint_sha256": base_digest,
        "selected_ridge_strength": selected.ridge_strength,
        "weight_float32": model.realtime_observation_decoder.weight.detach().cpu(),
        "bias_float32": model.realtime_observation_decoder.bias.detach().cpu(),
        "coefficient_float32_sha256": selected.coefficient_float32_sha256,
        "normalization_role": model.realtime_observation_normalization_role,
    }
    artifact_path = output / "realtime_observation_head.pt"
    torch.save(artifact, artifact_path)
    diagnostics_path = output / "ridge_candidate_diagnostics.json"
    diagnostics_path.write_text(
        json.dumps(
            {
                "selected_ridge_strength": selected.ridge_strength,
                "selected_coefficient_float32_sha256": selected.coefficient_float32_sha256,
                "candidates": [_candidate_document(candidate) for candidate in selection.candidates],
            },
            indent=2,
            sort_keys=True,
            allow_nan=False,
        ),
        encoding="utf-8",
    )
    manifest = {
        "schema_version": 1,
        "status": "complete",
        "seed": seed,
        "base_checkpoint_sha256": base_digest,
        "selected_ridge_strength": selected.ridge_strength,
        "files": {
            path.name: {
                "byte_count": path.stat().st_size,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }
            for path in (artifact_path, diagnostics_path)
        },
    }
    (output / "completion_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True, allow_nan=False),
        encoding="utf-8",
    )
    return manifest


def _load_base_model(
    path: str | Path,
    seed: int,
    device: str,
    *,
    expected_normalization: Optional[Mapping[str, object]] = None,
) -> SixSourceFourTargetD32GRU:
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    if (
        checkpoint.get("seed") != seed
        or checkpoint.get("model_class") != "SixSourceFourTargetD32GRU"
        or checkpoint.get("realtime_observation_head_fitted") is not False
    ):
        raise RuntimeError("base checkpoint contract changed")
    if (
        expected_normalization is not None
        and checkpoint.get("normalization") != expected_normalization
    ):
        raise RuntimeError("base checkpoint normalization differs from registered data")
    model = SixSourceFourTargetD32GRU()
    model.load_state_dict(checkpoint["model_state_dict"], strict=True)
    configure_base_training_parameters(model)
    if (
        total_parameter_count(model) != EXPECTED_PARAMETER_COUNT
        or checkpoint.get("total_parameter_count") != total_parameter_count(model)
        or checkpoint.get("base_stage_trainable_parameter_count")
        != trainable_parameter_count(model)
    ):
        raise RuntimeError("base checkpoint parameter counts changed")
    model.to(device).eval()
    return model


def run_synthetic_smoke(seed: int, device: str) -> Mapping[str, object]:
    generator = np.random.default_rng(seed)
    training_x = generator.normal(size=(80, 32))
    true_weight = generator.normal(scale=0.1, size=(32, 6))
    true_bias = generator.normal(scale=0.1, size=(6,))
    training_y = training_x @ true_weight + true_bias
    selection_x = generator.normal(size=(24, 32))
    selection_y = selection_x @ true_weight + true_bias
    result = fit_and_select_observation_head(
        training_x, training_y, selection_x, selection_y, np.ones(6)
    )
    with tempfile.TemporaryDirectory(prefix="zhenjiang_head_synthetic_smoke_") as temporary:
        marker = Path(temporary) / "result.json"
        marker.write_text(
            json.dumps(_candidate_document(result.selected), allow_nan=False),
            encoding="utf-8",
        )
    return {
        "execution_mode": "synthetic_smoke",
        "seed": seed,
        "device": device,
        "selected_ridge_strength": result.selected.ridge_strength,
        "candidate_count": len(result.candidates),
        "formal_output_created": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execution-mode", choices=("synthetic_smoke", "formal"), required=True)
    parser.add_argument("--seed", type=int, choices=ALLOWED_SEEDS, required=True)
    parser.add_argument("--device", required=True)
    parser.add_argument("--input-root", default=str(DEFAULT_INPUT_ROOT))
    parser.add_argument("--tide-model-path", default=str(DEFAULT_TIDE_MODEL_PATH))
    parser.add_argument("--base-checkpoint")
    parser.add_argument("--output-directory")
    parser.add_argument("--formal-authorization")
    arguments = parser.parse_args()
    if arguments.execution_mode == "synthetic_smoke":
        report = run_synthetic_smoke(arguments.seed, arguments.device)
    else:
        if arguments.formal_authorization != FORMAL_AUTHORIZATION_TEXT:
            raise RuntimeError("formal fitting authorization text is missing")
        if arguments.base_checkpoint is None or arguments.output_directory is None:
            raise ValueError("formal mode requires --base-checkpoint and --output-directory")
        data = load_training_selection_data(
            arguments.input_root, arguments.tide_model_path
        )
        datasets = build_split_datasets(data)
        model = _load_base_model(
            arguments.base_checkpoint,
            arguments.seed,
            arguments.device,
            expected_normalization=_normalization_document(data.normalization),
        )
        training_x, training_y = collect_prior_design_and_observations(
            model, datasets["training"], device=arguments.device
        )
        selection_x, selection_y = collect_prior_design_and_observations(
            model, datasets["selection"], device=arguments.device
        )
        selection = fit_and_select_observation_head(
            training_x,
            training_y,
            selection_x,
            selection_y,
            data.normalization.analysis_stage.standard_deviation_m,
        )
        report = save_observation_head_selection(
            model=model,
            selection=selection,
            seed=arguments.seed,
            base_checkpoint=arguments.base_checkpoint,
            output_directory=arguments.output_directory,
        )
    print(json.dumps(report, indent=2, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
