#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Frozen 2023 qualification for the base forecast and realtime head.

The evaluator is pure with respect to model checkpoints: it accepts already
generated arrays, computes the preregistered metrics, and never writes or
modifies a checkpoint or regularization choice.

Example:
    python scripts/analysis/zhenjiang_six_source_four_target_base_qualification_v1.py --input-npz metrics_input.npz --output-json qualification.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Mapping, Optional

import numpy as np


TARGET_STATIONS = ("nanjing", "zhenjiang", "jiangyin", "xuliujing")
SOURCE_STATIONS = (
    "datong",
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)


def _nash_sutcliffe_efficiency(prediction: np.ndarray, target: np.ndarray) -> Optional[float]:
    denominator = float(np.square(target - np.mean(target, dtype=np.float64)).sum(dtype=np.float64))
    if denominator == 0.0:
        return None
    numerator = float(np.square(prediction - target).sum(dtype=np.float64))
    return 1.0 - numerator / denominator


def evaluate_base_forecast_qualification(
    predictions_m: np.ndarray,
    targets_m: np.ndarray,
    issue_time_realtime_stage_m: np.ndarray,
) -> Mapping[str, object]:
    """Apply the per-target 1--6 h persistence and 1--24 h efficiency gates."""

    predictions = np.asarray(predictions_m, dtype=np.float64)
    targets = np.asarray(targets_m, dtype=np.float64)
    persistence_origin = np.asarray(issue_time_realtime_stage_m, dtype=np.float64)
    if (
        predictions.ndim != 3
        or predictions.shape[1:] != (24, 4)
        or targets.shape != predictions.shape
        or persistence_origin.shape != (predictions.shape[0], 4)
        or predictions.shape[0] < 1
    ):
        raise ValueError("base arrays must be [sample,24,4] and [sample,4]")
    if not np.isfinite(predictions).all() or not np.isfinite(targets).all() or not np.isfinite(persistence_origin).all():
        raise ValueError("base qualification arrays must be finite")
    persistence = np.broadcast_to(persistence_origin[:, None, :], targets.shape)
    rows: Dict[str, object] = {}
    for target_index, station in enumerate(TARGET_STATIONS):
        forecast_errors = predictions[:, :, target_index] - targets[:, :, target_index]
        persistence_errors = persistence[:, :, target_index] - targets[:, :, target_index]
        forecast_mae_1_6 = float(np.abs(forecast_errors[:, :6]).mean(dtype=np.float64))
        persistence_mae_1_6 = float(np.abs(persistence_errors[:, :6]).mean(dtype=np.float64))
        rmse_1_24 = float(np.sqrt(np.square(forecast_errors).mean(dtype=np.float64)))
        nse_1_24 = _nash_sutcliffe_efficiency(
            predictions[:, :, target_index].reshape(-1),
            targets[:, :, target_index].reshape(-1),
        )
        beats_persistence = forecast_mae_1_6 < persistence_mae_1_6
        positive_nse = nse_1_24 is not None and nse_1_24 > 0.0
        rows[station] = {
            "sample_count": int(predictions.shape[0]),
            "mean_absolute_error_issue_horizon_1_to_6_m": forecast_mae_1_6,
            "persistence_mean_absolute_error_issue_horizon_1_to_6_m": persistence_mae_1_6,
            "root_mean_squared_error_issue_horizon_1_to_24_m": rmse_1_24,
            "nash_sutcliffe_efficiency_issue_horizon_1_to_24": nse_1_24,
            "beats_persistence_1_to_6": beats_persistence,
            "positive_nash_sutcliffe_efficiency_1_to_24": positive_nse,
            "passes": beats_persistence and positive_nse,
        }
    return {
        "target_results": rows,
        "passes": all(bool(row["passes"]) for row in rows.values()),
    }


def evaluate_realtime_observation_head_qualification(
    predictions_t_plus_1_m: np.ndarray,
    observations_t_plus_1_m: np.ndarray,
    issue_time_realtime_stage_m: np.ndarray,
    *,
    augmented_design_singular_values: np.ndarray,
    augmented_design_rank: int,
    augmented_design_condition_number: Optional[float],
) -> Mapping[str, object]:
    """Apply six station-wise one-hour persistence gates and report bias."""

    predictions = np.asarray(predictions_t_plus_1_m, dtype=np.float64)
    observations = np.asarray(observations_t_plus_1_m, dtype=np.float64)
    persistence = np.asarray(issue_time_realtime_stage_m, dtype=np.float64)
    if (
        predictions.ndim != 2
        or predictions.shape[1] != 6
        or observations.shape != predictions.shape
        or persistence.shape != predictions.shape
        or predictions.shape[0] < 1
    ):
        raise ValueError("observation-head arrays must have shape [sample,6]")
    singular_values = np.asarray(augmented_design_singular_values, dtype=np.float64)
    if singular_values.ndim != 1 or singular_values.size < 1 or not np.isfinite(singular_values).all():
        raise ValueError("augmented design singular values must be finite")
    if type(augmented_design_rank) is not int or augmented_design_rank < 1:
        raise ValueError("augmented design rank must be a positive integer")
    if augmented_design_condition_number is not None and (
        not np.isfinite(augmented_design_condition_number)
        or augmented_design_condition_number < 1.0
    ):
        raise ValueError("condition number must be null or finite and at least one")
    if not np.isfinite(predictions).all() or not np.isfinite(observations).all() or not np.isfinite(persistence).all():
        raise ValueError("observation-head qualification arrays must be finite")
    rows: Dict[str, object] = {}
    for station_index, station in enumerate(SOURCE_STATIONS):
        errors = predictions[:, station_index] - observations[:, station_index]
        persistence_errors = persistence[:, station_index] - observations[:, station_index]
        mae = float(np.abs(errors).mean(dtype=np.float64))
        persistence_mae = float(np.abs(persistence_errors).mean(dtype=np.float64))
        rows[station] = {
            "sample_count": int(predictions.shape[0]),
            "mean_absolute_error_t_plus_1_m": mae,
            "persistence_mean_absolute_error_t_plus_1_m": persistence_mae,
            "mean_bias_t_plus_1_m": float(errors.mean(dtype=np.float64)),
            "beats_one_hour_persistence": mae < persistence_mae,
            "passes": mae < persistence_mae,
        }
    return {
        "source_results": rows,
        "augmented_design_singular_values": singular_values.tolist(),
        "augmented_design_rank": augmented_design_rank,
        "augmented_design_condition_number": augmented_design_condition_number,
        "passes": all(bool(row["passes"]) for row in rows.values()),
    }


def evaluate_base_and_observation_head_qualification(
    *,
    base_predictions_m: np.ndarray,
    base_targets_m: np.ndarray,
    target_issue_stage_m: np.ndarray,
    observation_head_predictions_m: np.ndarray,
    realtime_observations_t_plus_1_m: np.ndarray,
    source_issue_stage_m: np.ndarray,
    augmented_design_singular_values: np.ndarray,
    augmented_design_rank: int,
    augmented_design_condition_number: Optional[float],
) -> Mapping[str, object]:
    """Return the complete frozen qualification without changing any model."""

    base = evaluate_base_forecast_qualification(
        base_predictions_m, base_targets_m, target_issue_stage_m
    )
    observation = evaluate_realtime_observation_head_qualification(
        observation_head_predictions_m,
        realtime_observations_t_plus_1_m,
        source_issue_stage_m,
        augmented_design_singular_values=augmented_design_singular_values,
        augmented_design_rank=augmented_design_rank,
        augmented_design_condition_number=augmented_design_condition_number,
    )
    return {
        "schema_version": 1,
        "evaluation_year": 2023,
        "checkpoint_mutation_allowed": False,
        "regularization_reselection_allowed": False,
        "base_forecast": base,
        "realtime_observation_head": observation,
        "passes": bool(base["passes"] and observation["passes"]),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-npz", required=True)
    parser.add_argument("--output-json", required=True)
    arguments = parser.parse_args()
    output = Path(arguments.output_json)
    if output.exists():
        raise FileExistsError(f"qualification output already exists: {output}")
    arrays = np.load(arguments.input_npz, allow_pickle=False)
    condition_value = arrays["augmented_design_condition_number"]
    condition = None if condition_value.size == 0 else float(condition_value.reshape(()))
    report = evaluate_base_and_observation_head_qualification(
        base_predictions_m=arrays["base_predictions_m"],
        base_targets_m=arrays["base_targets_m"],
        target_issue_stage_m=arrays["target_issue_stage_m"],
        observation_head_predictions_m=arrays["observation_head_predictions_m"],
        realtime_observations_t_plus_1_m=arrays["realtime_observations_t_plus_1_m"],
        source_issue_stage_m=arrays["source_issue_stage_m"],
        augmented_design_singular_values=arrays["augmented_design_singular_values"],
        augmented_design_rank=int(arrays["augmented_design_rank"].reshape(())),
        augmented_design_condition_number=condition,
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(report, indent=2, sort_keys=True, allow_nan=False),
        encoding="utf-8",
    )
    print(json.dumps(report, indent=2, sort_keys=True, allow_nan=False))
    return 0 if report["passes"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
