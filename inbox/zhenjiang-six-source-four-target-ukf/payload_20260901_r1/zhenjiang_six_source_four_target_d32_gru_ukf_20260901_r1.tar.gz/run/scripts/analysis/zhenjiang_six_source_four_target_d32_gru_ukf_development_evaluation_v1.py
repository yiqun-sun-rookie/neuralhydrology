#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build and independently audit the frozen 2023 development evaluation.

The metric layer accepts in-memory arrays.  Formal mode first verifies all
nine frozen training artifacts, then calls the authorized 2017--2023 loader
exactly once and shares that one development dataset across all three seeds.
No target value is written to the dependency-perturbation evidence.

Example:
    python -m pytest -q -p no:cacheprovider \
      tests/test_zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1.py
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import sys
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

import numpy as np
import torch
from torch.utils.data import DataLoader

from zhenjiang_six_source_four_target_d32_gru_ukf_metrics_v1 import (
    BOOTSTRAP_RANDOM_SEED,
    BOOTSTRAP_REPEAT_COUNT,
    FUTURE_SUFFICIENT_FIELDS,
    SEEDS,
    SOURCE_STATIONS,
    TARGET_STATIONS,
    assign_calendar_seven_day_blocks,
    bootstrap_crossed_seed_calendar_blocks,
    build_directional_matrices,
    decide_forecast_direction_gates,
    summarize_source_target_leads,
    summarize_source_target_windows,
)


ANALYSIS_OBSERVATION_FIELDS = (
    "schema_version",
    "experiment_id",
    "seed",
    "block_id",
    "block_origin_count",
    "source_index",
    "source_station",
    "cell_count",
    "prior_absolute_residual_sum_m",
    "posterior_absolute_residual_sum_m",
    "innovation_absolute_sum_m",
    "kalman_gain_norm_sum",
    "posterior_observation_variance_sum_normalized",
    "observation_contraction_min",
    "observation_contraction_max",
    "contraction_ratio_values_json",
    "near_zero_prior_count",
    "near_zero_posterior_max_absolute_residual_m",
    "posterior_minimum_eigenvalue_minus_0_99_floor_min",
    "observation_noise_standard_deviation_normalized",
)

ANALYSIS_TARGET_FIELDS = (
    "schema_version",
    "experiment_id",
    "seed",
    "block_id",
    "block_origin_count",
    "source_index",
    "source_station",
    "target_index",
    "target_station",
    "cell_count",
    "prior_absolute_error_sum_m",
    "posterior_absolute_error_sum_m",
    "prior_squared_error_sum_m2",
    "posterior_squared_error_sum_m2",
    "posterior_minus_prior_absolute_movement_sum_m",
    "target_sum_m",
    "target_squared_sum_m2",
)

STATE_DIFFERENCE_FIELDS = (
    "schema_version",
    "experiment_id",
    "seed",
    "block_id",
    "block_origin_count",
    "source_index",
    "source_station",
    "issue_horizon_hour",
    "post_update_lead_hour",
    "cell_count",
    "state_mean_absolute_difference_sum",
    "state_l2_difference_sum",
)

BASE_QUALIFICATION_FIELDS = (
    "schema_version",
    "experiment_id",
    "seed",
    "block_id",
    "block_origin_count",
    "target_index",
    "target_station",
    "first_six_cell_count",
    "full_twenty_four_cell_count",
    "base_first_six_absolute_error_sum_m",
    "persistence_first_six_absolute_error_sum_m",
    "base_full_twenty_four_absolute_error_sum_m",
    "base_full_twenty_four_squared_error_sum_m2",
    "target_full_twenty_four_sum_m",
    "target_full_twenty_four_squared_sum_m2",
)

OBSERVATION_HEAD_QUALIFICATION_FIELDS = (
    "schema_version",
    "experiment_id",
    "seed",
    "block_id",
    "block_origin_count",
    "source_index",
    "source_station",
    "cell_count",
    "head_absolute_error_sum_m",
    "persistence_absolute_error_sum_m",
    "head_bias_sum_m",
)

DEPENDENCY_PERTURBATION_DELTA_NORMALIZED = 0.01
FROZEN_DEVELOPMENT_BYTES_BY_PATH = {
    "dataset_config.json": 2854,
    "realtime_features/datong_realtime_features.csv": 5_485_506,
    "realtime_features/nanjing_realtime_features.csv": 5_452_340,
    "realtime_features/zhenjiang_realtime_features.csv": 5_490_493,
    "realtime_features/jiangyin_realtime_features.csv": 5_451_807,
    "realtime_features/xuliujing_realtime_features.csv": 5_452_448,
    "realtime_features/wusongkou_realtime_features.csv": 5_449_542,
    "retrospective_targets/nanjing_retrospective_targets.csv": 5_453_455,
    "retrospective_targets/zhenjiang_retrospective_targets.csv": 5_491_015,
    "retrospective_targets/jiangyin_retrospective_targets.csv": 5_452_821,
    "retrospective_targets/xuliujing_retrospective_targets.csv": 5_453_528,
}
FROZEN_DEVELOPMENT_CSV_PATHS = frozenset(
    path for path in FROZEN_DEVELOPMENT_BYTES_BY_PATH if path.endswith(".csv")
)
FROZEN_DEVELOPMENT_TARGET_ROWS_BY_PERIOD = {
    "training": 175_296,
    "selection": 35_040,
    "development_gate": 35_040,
    "heldout_or_later": 0,
    "boundary_target": 0,
}
FROZEN_DEVELOPMENT_FEATURE_BYTES = 4_685_966
FROZEN_DEVELOPMENT_TARGET_BYTES = 3_123_728
FROZEN_DEVELOPMENT_FEATURE_ROWS = 52_560
FROZEN_DEVELOPMENT_TARGET_ROWS = 35_040
FROZEN_PREFIX_ROWS_PER_CSV = 61_344
FROZEN_PREDEVELOPMENT_ROWS_PER_CSV = 52_584
FORMAL_EXPERIMENT_FAMILY = (
    "ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_DIFFERENTIABLE_UKF_V1"
)
FORMAL_DEVELOPMENT_EXPERIMENT_ID = FORMAL_EXPERIMENT_FAMILY + "_2023_DEVELOPMENT_V1"
FORMAL_CONFIRMATION = (
    "CONFIRM_ZHENJIANG_SIX_SOURCE_FOUR_TARGET_UKF_HPC_20260901"
)
FORMAL_EVALUATION_RELATIVE_PATH = Path(
    "evidence/development_2023/evaluation/attempt_001"
)
FORMAL_AUDIT_RELATIVE_PATH = Path(
    "evidence/development_2023/independent_audit/attempt_001"
)
DEVELOPMENT_ACCESS_MARKER_NAME = "development_access_started.json"
FROZEN_RIDGE_STRENGTHS = (0.0, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1.0)
FROZEN_RIDGE_TIE_TOLERANCE_M = 1e-12
DATA_ACCESS_AUDIT_FIELDS = (
    "opened_paths",
    "bytes_read_by_path",
    "rows_parsed_by_path",
    "values_loaded_by_path",
    "target_rows_by_period",
    "astronomical_tide_model_open_count",
    "development_feature_bytes_read",
    "development_feature_rows_parsed",
    "development_feature_values_loaded",
    "development_target_bytes_read",
    "development_target_rows_parsed",
    "development_target_values_loaded",
    "heldout_target_bytes_read",
    "heldout_target_rows_parsed",
    "heldout_target_values_loaded",
    "boundary_target_bytes_read",
    "boundary_target_rows_parsed",
    "boundary_target_values_loaded",
)

SUFFICIENT_FILE_NAMES = (
    "future_sufficient_statistics.csv",
    "analysis_observation_sufficient_statistics.csv",
    "analysis_target_sufficient_statistics.csv",
    "state_difference_sufficient_statistics.csv",
    "base_qualification_sufficient_statistics.csv",
    "observation_head_qualification_sufficient_statistics.csv",
)

SUMMARY_FILE_NAMES = (
    "base_observation_head_qualification.json",
    "base_and_three_branch_forecast_metrics.csv",
    "source_target_lead_metrics.csv",
    "source_target_window_metrics.csv",
    "six_source_four_target_gain_matrix.csv",
    "internal_four_by_four_gain_matrix.csv",
    "boundary_to_internal_gain_matrix.csv",
    "analysis_realtime_observation_diagnostics.csv",
    "analysis_target_space_gain_matrix.csv",
    "forecast_movement_matrix.csv",
    "reciprocal_direction_summary.csv",
    "bootstrap_summary.json",
    "development_gate_decision.json",
    "sufficient_grid_identity.json",
)


def _array(value: Any, name: str, shape: Sequence[int]) -> np.ndarray:
    if hasattr(value, "detach"):
        value = value.detach().cpu().numpy()
    result = np.asarray(value, dtype=np.float64)
    if result.shape != tuple(shape):
        raise ValueError("%s must have shape %s" % (name, tuple(shape)))
    if not bool(np.isfinite(result).all()):
        raise ValueError("%s contains a nonfinite value" % name)
    return result


def _canonical_ratios(values: np.ndarray) -> str:
    return json.dumps(
        [float(value) for value in values],
        ensure_ascii=False,
        separators=(",", ":"),
    )


def accumulate_development_sufficient_statistics(
    *,
    experiment_id: str,
    seed: int,
    origin_times: Sequence[Any],
    target_future_m: Any,
    analysis_target_m: Any,
    analysis_observation_m: Any,
    current_stage_m: Any,
    base_issue_hour_one_forecast_m: Any,
    base_deterministic_forecast_m: Any,
    unscented_prior_forecast_m: Any,
    updated_forecast_m: Any,
    analysis_prior_target_m: Any,
    analysis_posterior_target_m: Any,
    analysis_prior_observation_m: Any,
    analysis_posterior_observation_m: Any,
    analysis_kalman_gain: Any,
    analysis_observation_contraction: Any,
    analysis_posterior_observation_variance_normalized: Any,
    analysis_posterior_minimum_eigenvalue: Any,
    analysis_spectral_floor: Any,
    observation_noise_standard_deviation_normalized: Any,
    unscented_prior_state_mean: Any,
    updated_state_mean: Any,
) -> Dict[str, Any]:
    """Convert one seed's in-memory 2023 arrays into block sufficient rows."""

    if not isinstance(experiment_id, str) or not experiment_id:
        raise ValueError("experiment_id must be nonempty")
    if seed not in SEEDS:
        raise ValueError("seed is outside the frozen set")
    origin_count = len(origin_times)
    if origin_count < 1:
        raise ValueError("origin_times must not be empty")
    block_ids, nonempty_blocks = assign_calendar_seven_day_blocks(origin_times)
    target_future = _array(target_future_m, "target_future_m", (origin_count, 23, 4))
    analysis_target = _array(
        analysis_target_m, "analysis_target_m", (origin_count, 4)
    )
    observation = _array(
        analysis_observation_m, "analysis_observation_m", (origin_count, 6)
    )
    current_stage = _array(current_stage_m, "current_stage_m", (origin_count, 6))
    base_hour_one = _array(
        base_issue_hour_one_forecast_m,
        "base_issue_hour_one_forecast_m",
        (origin_count, 4),
    )
    base = _array(
        base_deterministic_forecast_m,
        "base_deterministic_forecast_m",
        (origin_count, 23, 4),
    )
    prior = _array(
        unscented_prior_forecast_m,
        "unscented_prior_forecast_m",
        (origin_count, 23, 4),
    )
    updated = _array(
        updated_forecast_m,
        "updated_forecast_m",
        (origin_count, 6, 23, 4),
    )
    analysis_prior_target = _array(
        analysis_prior_target_m, "analysis_prior_target_m", (origin_count, 4)
    )
    analysis_posterior_target = _array(
        analysis_posterior_target_m,
        "analysis_posterior_target_m",
        (origin_count, 6, 4),
    )
    analysis_prior_observation = _array(
        analysis_prior_observation_m,
        "analysis_prior_observation_m",
        (origin_count, 6),
    )
    analysis_posterior_observation = _array(
        analysis_posterior_observation_m,
        "analysis_posterior_observation_m",
        (origin_count, 6, 6),
    )
    kalman_gain = _array(
        analysis_kalman_gain, "analysis_kalman_gain", (origin_count, 6, 32)
    )
    contraction = _array(
        analysis_observation_contraction,
        "analysis_observation_contraction",
        (origin_count, 6),
    )
    posterior_variance = _array(
        analysis_posterior_observation_variance_normalized,
        "analysis_posterior_observation_variance_normalized",
        (origin_count, 6),
    )
    posterior_eigenvalue = _array(
        analysis_posterior_minimum_eigenvalue,
        "analysis_posterior_minimum_eigenvalue",
        (origin_count, 6),
    )
    spectral_floor = _array(
        analysis_spectral_floor,
        "analysis_spectral_floor",
        (origin_count, 6),
    )
    observation_noise = _array(
        observation_noise_standard_deviation_normalized,
        "observation_noise_standard_deviation_normalized",
        (6,),
    )
    prior_state = _array(
        unscented_prior_state_mean,
        "unscented_prior_state_mean",
        (origin_count, 23, 32),
    )
    updated_state = _array(
        updated_state_mean,
        "updated_state_mean",
        (origin_count, 6, 23, 32),
    )
    if bool((contraction <= 0.0).any()) or bool((contraction >= 1.0).any()):
        raise ValueError("every observation contraction must be strictly in (0, 1)")
    if bool((posterior_variance < 0.0).any()):
        raise ValueError("posterior observation variance must be nonnegative")

    posterior_own_observation = np.stack(
        [analysis_posterior_observation[:, source, source] for source in range(6)],
        axis=1,
    )
    future_rows: List[Dict[str, Any]] = []
    observation_rows: List[Dict[str, Any]] = []
    target_rows: List[Dict[str, Any]] = []
    state_rows: List[Dict[str, Any]] = []
    base_qualification_rows: List[Dict[str, Any]] = []
    observation_head_qualification_rows: List[Dict[str, Any]] = []
    block_origin_counts: Dict[int, int] = {}
    for block in nonempty_blocks:
        mask = block_ids == block
        count = int(mask.sum())
        block_origin_counts[int(block)] = count
        full_target = np.concatenate(
            (analysis_target[mask, None, :], target_future[mask]), axis=1
        )
        full_base = np.concatenate(
            (base_hour_one[mask, None, :], base[mask]), axis=1
        )
        for target in range(4):
            target_truth = full_target[:, :, target]
            base_error = full_base[:, :, target] - target_truth
            persistence_error = (
                current_stage[mask, target + 1, None] - target_truth
            )
            base_qualification_rows.append(
                {
                    "schema_version": "1.0",
                    "experiment_id": experiment_id,
                    "seed": seed,
                    "block_id": int(block),
                    "block_origin_count": count,
                    "target_index": target,
                    "target_station": TARGET_STATIONS[target],
                    "first_six_cell_count": count * 6,
                    "full_twenty_four_cell_count": count * 24,
                    "base_first_six_absolute_error_sum_m": float(
                        np.abs(base_error[:, :6]).sum()
                    ),
                    "persistence_first_six_absolute_error_sum_m": float(
                        np.abs(persistence_error[:, :6]).sum()
                    ),
                    "base_full_twenty_four_absolute_error_sum_m": float(
                        np.abs(base_error).sum()
                    ),
                    "base_full_twenty_four_squared_error_sum_m2": float(
                        np.square(base_error).sum()
                    ),
                    "target_full_twenty_four_sum_m": float(target_truth.sum()),
                    "target_full_twenty_four_squared_sum_m2": float(
                        np.square(target_truth).sum()
                    ),
                }
            )
        for source in range(6):
            head_error = (
                analysis_prior_observation[mask, source]
                - observation[mask, source]
            )
            persistence_error = (
                current_stage[mask, source] - observation[mask, source]
            )
            observation_head_qualification_rows.append(
                {
                    "schema_version": "1.0",
                    "experiment_id": experiment_id,
                    "seed": seed,
                    "block_id": int(block),
                    "block_origin_count": count,
                    "source_index": source,
                    "source_station": SOURCE_STATIONS[source],
                    "cell_count": count,
                    "head_absolute_error_sum_m": float(
                        np.abs(head_error).sum()
                    ),
                    "persistence_absolute_error_sum_m": float(
                        np.abs(persistence_error).sum()
                    ),
                    "head_bias_sum_m": float(head_error.sum()),
                }
            )
        for source in range(6):
            for target in range(4):
                for lead_index in range(23):
                    truth = target_future[mask, lead_index, target]
                    base_error = base[mask, lead_index, target] - truth
                    prior_error = prior[mask, lead_index, target] - truth
                    updated_error = updated[mask, source, lead_index, target] - truth
                    movement = np.abs(
                        updated[mask, source, lead_index, target]
                        - prior[mask, lead_index, target]
                    )
                    future_rows.append(
                        {
                            "schema_version": "1.0",
                            "experiment_id": experiment_id,
                            "seed": seed,
                            "block_id": int(block),
                            "block_origin_count": count,
                            "source_index": source,
                            "source_station": SOURCE_STATIONS[source],
                            "target_index": target,
                            "target_station": TARGET_STATIONS[target],
                            "issue_horizon_hour": lead_index + 2,
                            "post_update_lead_hour": lead_index + 1,
                            "cell_count": count,
                            "base_absolute_error_sum_m": float(
                                np.abs(base_error).sum()
                            ),
                            "prior_absolute_error_sum_m": float(
                                np.abs(prior_error).sum()
                            ),
                            "updated_absolute_error_sum_m": float(
                                np.abs(updated_error).sum()
                            ),
                            "base_squared_error_sum_m2": float(
                                np.square(base_error).sum()
                            ),
                            "prior_squared_error_sum_m2": float(
                                np.square(prior_error).sum()
                            ),
                            "updated_squared_error_sum_m2": float(
                                np.square(updated_error).sum()
                            ),
                            "updated_minus_prior_absolute_movement_sum_m": float(
                                movement.sum()
                            ),
                            "target_sum_m": float(truth.sum()),
                            "target_squared_sum_m2": float(np.square(truth).sum()),
                        }
                    )

                target_truth = analysis_target[mask, target]
                target_prior_error = analysis_prior_target[mask, target] - target_truth
                target_posterior_error = (
                    analysis_posterior_target[mask, source, target] - target_truth
                )
                target_rows.append(
                    {
                        "schema_version": "1.0",
                        "experiment_id": experiment_id,
                        "seed": seed,
                        "block_id": int(block),
                        "block_origin_count": count,
                        "source_index": source,
                        "source_station": SOURCE_STATIONS[source],
                        "target_index": target,
                        "target_station": TARGET_STATIONS[target],
                        "cell_count": count,
                        "prior_absolute_error_sum_m": float(
                            np.abs(target_prior_error).sum()
                        ),
                        "posterior_absolute_error_sum_m": float(
                            np.abs(target_posterior_error).sum()
                        ),
                        "prior_squared_error_sum_m2": float(
                            np.square(target_prior_error).sum()
                        ),
                        "posterior_squared_error_sum_m2": float(
                            np.square(target_posterior_error).sum()
                        ),
                        "posterior_minus_prior_absolute_movement_sum_m": float(
                            np.abs(
                                analysis_posterior_target[mask, source, target]
                                - analysis_prior_target[mask, target]
                            ).sum()
                        ),
                        "target_sum_m": float(target_truth.sum()),
                        "target_squared_sum_m2": float(
                            np.square(target_truth).sum()
                        ),
                    }
                )

            prior_residual = (
                analysis_prior_observation[mask, source] - observation[mask, source]
            )
            posterior_residual = (
                posterior_own_observation[mask, source] - observation[mask, source]
            )
            prior_absolute = np.abs(prior_residual)
            posterior_absolute = np.abs(posterior_residual)
            ratio_mask = prior_absolute > 1e-6
            ratios = posterior_absolute[ratio_mask] / prior_absolute[ratio_mask]
            near_zero_values = posterior_absolute[~ratio_mask]
            spectral_margin = (
                posterior_eigenvalue[mask, source]
                - 0.99 * spectral_floor[mask, source]
            )
            observation_rows.append(
                {
                    "schema_version": "1.0",
                    "experiment_id": experiment_id,
                    "seed": seed,
                    "block_id": int(block),
                    "block_origin_count": count,
                    "source_index": source,
                    "source_station": SOURCE_STATIONS[source],
                    "cell_count": count,
                    "prior_absolute_residual_sum_m": float(prior_absolute.sum()),
                    "posterior_absolute_residual_sum_m": float(
                        posterior_absolute.sum()
                    ),
                    "innovation_absolute_sum_m": float(prior_absolute.sum()),
                    "kalman_gain_norm_sum": float(
                        np.linalg.norm(kalman_gain[mask, source], axis=1).sum()
                    ),
                    "posterior_observation_variance_sum_normalized": float(
                        posterior_variance[mask, source].sum()
                    ),
                    "observation_contraction_min": float(
                        contraction[mask, source].min()
                    ),
                    "observation_contraction_max": float(
                        contraction[mask, source].max()
                    ),
                    "contraction_ratio_values_json": _canonical_ratios(ratios),
                    "near_zero_prior_count": int((~ratio_mask).sum()),
                    "near_zero_posterior_max_absolute_residual_m": (
                        float(near_zero_values.max()) if near_zero_values.size else 0.0
                    ),
                    "posterior_minimum_eigenvalue_minus_0_99_floor_min": float(
                        spectral_margin.min()
                    ),
                    "observation_noise_standard_deviation_normalized": float(
                        observation_noise[source]
                    ),
                }
            )

            for lead_index in range(23):
                difference = (
                    updated_state[mask, source, lead_index]
                    - prior_state[mask, lead_index]
                )
                state_rows.append(
                    {
                        "schema_version": "1.0",
                        "experiment_id": experiment_id,
                        "seed": seed,
                        "block_id": int(block),
                        "block_origin_count": count,
                        "source_index": source,
                        "source_station": SOURCE_STATIONS[source],
                        "issue_horizon_hour": lead_index + 2,
                        "post_update_lead_hour": lead_index + 1,
                        "cell_count": count,
                        "state_mean_absolute_difference_sum": float(
                            np.abs(difference).mean(axis=1).sum()
                        ),
                        "state_l2_difference_sum": float(
                            np.linalg.norm(difference, axis=1).sum()
                        ),
                    }
                )
    return {
        "schema_version": "1.0",
        "experiment_id": experiment_id,
        "seed": seed,
        "nonempty_block_ids": list(nonempty_blocks),
        "nonempty_block_count": len(nonempty_blocks),
        "block_origin_counts": block_origin_counts,
        "future_rows": future_rows,
        "analysis_observation_rows": observation_rows,
        "analysis_target_rows": target_rows,
        "state_difference_rows": state_rows,
        "base_qualification_rows": base_qualification_rows,
        "observation_head_qualification_rows": (
            observation_head_qualification_rows
        ),
    }


def combine_seed_sufficient_statistics(
    batch_statistics: Sequence[Mapping[str, Any]],
) -> Dict[str, Any]:
    """Merge batch-level sufficient rows without retaining hourly targets."""

    if not batch_statistics:
        raise ValueError("batch_statistics must not be empty")
    experiment_ids = {row.get("experiment_id") for row in batch_statistics}
    seeds = {row.get("seed") for row in batch_statistics}
    if len(experiment_ids) != 1 or len(seeds) != 1:
        raise ValueError("batch sufficient-statistic identities differ")
    experiment_id = next(iter(experiment_ids))
    seed = next(iter(seeds))
    if not isinstance(experiment_id, str) or not experiment_id or seed not in SEEDS:
        raise ValueError("batch sufficient-statistic identity is invalid")

    table_contracts = {
        "future_rows": {
            "keys": (
                "seed",
                "block_id",
                "source_index",
                "target_index",
                "issue_horizon_hour",
                "post_update_lead_hour",
            ),
            "sum": set(FUTURE_SUFFICIENT_FIELDS)
            - {
                "schema_version",
                "experiment_id",
                "seed",
                "block_id",
                "source_index",
                "source_station",
                "target_index",
                "target_station",
                "issue_horizon_hour",
                "post_update_lead_hour",
            },
        },
        "analysis_target_rows": {
            "keys": ("seed", "block_id", "source_index", "target_index"),
            "sum": set(ANALYSIS_TARGET_FIELDS)
            - {
                "schema_version",
                "experiment_id",
                "seed",
                "block_id",
                "source_index",
                "source_station",
                "target_index",
                "target_station",
            },
        },
        "state_difference_rows": {
            "keys": (
                "seed",
                "block_id",
                "source_index",
                "issue_horizon_hour",
                "post_update_lead_hour",
            ),
            "sum": set(STATE_DIFFERENCE_FIELDS)
            - {
                "schema_version",
                "experiment_id",
                "seed",
                "block_id",
                "source_index",
                "source_station",
                "issue_horizon_hour",
                "post_update_lead_hour",
            },
        },
        "base_qualification_rows": {
            "keys": ("seed", "block_id", "target_index"),
            "sum": set(BASE_QUALIFICATION_FIELDS)
            - {
                "schema_version",
                "experiment_id",
                "seed",
                "block_id",
                "target_index",
                "target_station",
            },
        },
        "observation_head_qualification_rows": {
            "keys": ("seed", "block_id", "source_index"),
            "sum": set(OBSERVATION_HEAD_QUALIFICATION_FIELDS)
            - {
                "schema_version",
                "experiment_id",
                "seed",
                "block_id",
                "source_index",
                "source_station",
            },
        },
    }

    def merge_sum_table(name: str, contract: Mapping[str, Any]) -> List[Dict[str, Any]]:
        merged: Dict[tuple, Dict[str, Any]] = {}
        for batch in batch_statistics:
            rows = batch.get(name)
            if not isinstance(rows, list) or not rows:
                raise ValueError("batch sufficient-statistic table is empty: " + name)
            for row in rows:
                key = tuple(row[field] for field in contract["keys"])
                if key not in merged:
                    merged[key] = dict(row)
                    continue
                destination = merged[key]
                for field, value in row.items():
                    if field in contract["sum"]:
                        destination[field] += value
                    elif destination[field] != value:
                        raise ValueError("batch sufficient-statistic metadata drift")
        return [merged[key] for key in sorted(merged)]

    result_tables = {
        name: merge_sum_table(name, contract)
        for name, contract in table_contracts.items()
    }

    observation_merged: Dict[tuple, Dict[str, Any]] = {}
    observation_sum = {
        "block_origin_count",
        "cell_count",
        "prior_absolute_residual_sum_m",
        "posterior_absolute_residual_sum_m",
        "innovation_absolute_sum_m",
        "kalman_gain_norm_sum",
        "posterior_observation_variance_sum_normalized",
        "near_zero_prior_count",
    }
    observation_min = {
        "observation_contraction_min",
        "posterior_minimum_eigenvalue_minus_0_99_floor_min",
    }
    observation_max = {
        "observation_contraction_max",
        "near_zero_posterior_max_absolute_residual_m",
    }
    for batch in batch_statistics:
        rows = batch.get("analysis_observation_rows")
        if not isinstance(rows, list) or not rows:
            raise ValueError("batch analysis-observation table is empty")
        for row in rows:
            key = (row["seed"], row["block_id"], row["source_index"])
            ratios = json.loads(row["contraction_ratio_values_json"])
            if not isinstance(ratios, list):
                raise ValueError("contraction ratio evidence is invalid")
            if key not in observation_merged:
                observation_merged[key] = dict(row)
                observation_merged[key]["contraction_ratio_values_json"] = list(
                    ratios
                )
                continue
            destination = observation_merged[key]
            for field, value in row.items():
                if field in observation_sum:
                    destination[field] += value
                elif field in observation_min:
                    destination[field] = min(destination[field], value)
                elif field in observation_max:
                    destination[field] = max(destination[field], value)
                elif field == "contraction_ratio_values_json":
                    destination[field].extend(ratios)
                elif isinstance(value, float):
                    if not math.isclose(
                        float(destination[field]),
                        float(value),
                        abs_tol=1e-12,
                        rel_tol=1e-10,
                    ):
                        raise ValueError("batch observation metadata drift")
                elif destination[field] != value:
                    raise ValueError("batch observation metadata drift")
    observation_rows = []
    for key in sorted(observation_merged):
        row = observation_merged[key]
        row["contraction_ratio_values_json"] = json.dumps(
            row["contraction_ratio_values_json"],
            ensure_ascii=False,
            separators=(",", ":"),
        )
        observation_rows.append(row)

    block_counts: Dict[int, int] = {}
    for batch in batch_statistics:
        values = batch.get("block_origin_counts")
        if not isinstance(values, Mapping):
            raise ValueError("batch block-origin counts are missing")
        for block, count in values.items():
            block_id = int(block)
            if type(count) is not int or count < 1:
                raise ValueError("batch block-origin count is invalid")
            block_counts[block_id] = block_counts.get(block_id, 0) + count
    return {
        "schema_version": "1.0",
        "experiment_id": experiment_id,
        "seed": seed,
        "nonempty_block_ids": sorted(block_counts),
        "nonempty_block_count": len(block_counts),
        "block_origin_counts": block_counts,
        "future_rows": result_tables["future_rows"],
        "analysis_observation_rows": observation_rows,
        "analysis_target_rows": result_tables["analysis_target_rows"],
        "state_difference_rows": result_tables["state_difference_rows"],
        "base_qualification_rows": result_tables["base_qualification_rows"],
        "observation_head_qualification_rows": result_tables[
            "observation_head_qualification_rows"
        ],
    }


def _require_exact_fields(rows: Iterable[Mapping[str, Any]], fields: Sequence[str]) -> None:
    for row in rows:
        if set(row) != set(fields):
            raise ValueError("sufficient-statistic field set drift")


def verify_sufficient_grid(
    future_rows: Sequence[Mapping[str, Any]],
    observation_rows: Sequence[Mapping[str, Any]],
    target_rows: Sequence[Mapping[str, Any]],
    state_rows: Sequence[Mapping[str, Any]],
    base_qualification_rows: Optional[Sequence[Mapping[str, Any]]] = None,
    observation_head_qualification_rows: Optional[
        Sequence[Mapping[str, Any]]
    ] = None,
) -> Dict[str, Any]:
    """Mechanically verify B-scaled row counts and exact directional keys."""

    _require_exact_fields(future_rows, FUTURE_SUFFICIENT_FIELDS)
    _require_exact_fields(observation_rows, ANALYSIS_OBSERVATION_FIELDS)
    _require_exact_fields(target_rows, ANALYSIS_TARGET_FIELDS)
    _require_exact_fields(state_rows, STATE_DIFFERENCE_FIELDS)
    if base_qualification_rows is not None:
        _require_exact_fields(
            base_qualification_rows, BASE_QUALIFICATION_FIELDS
        )
    if observation_head_qualification_rows is not None:
        _require_exact_fields(
            observation_head_qualification_rows,
            OBSERVATION_HEAD_QUALIFICATION_FIELDS,
        )
    seeds = sorted({int(row["seed"]) for row in future_rows})
    if seeds != list(SEEDS):
        raise ValueError("sufficient grid requires all three frozen seeds")
    blocks_by_seed = {
        seed: sorted(
            {int(row["block_id"]) for row in future_rows if int(row["seed"]) == seed}
        )
        for seed in seeds
    }
    if len({tuple(value) for value in blocks_by_seed.values()}) != 1:
        raise ValueError("nonempty calendar block identity differs across seeds")
    block_ids = blocks_by_seed[SEEDS[0]]
    block_count = len(block_ids)
    if block_count < 1:
        raise ValueError("no nonempty calendar block was registered")
    expected = {
        "future_rows_per_seed": block_count * 6 * 4 * 23,
        "analysis_observation_rows_per_seed": block_count * 6,
        "analysis_target_rows_per_seed": block_count * 6 * 4,
        "state_difference_rows_per_seed": block_count * 6 * 23,
        "source_target_lead_summary_rows": 3 * 6 * 4 * 23,
    }
    if base_qualification_rows is not None:
        expected["base_qualification_rows_per_seed"] = block_count * 4
    if observation_head_qualification_rows is not None:
        expected["observation_head_qualification_rows_per_seed"] = (
            block_count * 6
        )

    table_contracts = [
        (
            "future",
            future_rows,
            lambda row: (
                int(row["seed"]),
                int(row["block_id"]),
                int(row["source_index"]),
                int(row["target_index"]),
                int(row["post_update_lead_hour"]),
            ),
            block_count * 6 * 4 * 23 * 3,
        ),
        (
            "analysis observation",
            observation_rows,
            lambda row: (
                int(row["seed"]),
                int(row["block_id"]),
                int(row["source_index"]),
            ),
            block_count * 6 * 3,
        ),
        (
            "analysis target",
            target_rows,
            lambda row: (
                int(row["seed"]),
                int(row["block_id"]),
                int(row["source_index"]),
                int(row["target_index"]),
            ),
            block_count * 6 * 4 * 3,
        ),
        (
            "state difference",
            state_rows,
            lambda row: (
                int(row["seed"]),
                int(row["block_id"]),
                int(row["source_index"]),
                int(row["post_update_lead_hour"]),
            ),
            block_count * 6 * 23 * 3,
        ),
    ]
    if base_qualification_rows is not None:
        table_contracts.append(
            (
                "base qualification",
                base_qualification_rows,
                lambda row: (
                    int(row["seed"]),
                    int(row["block_id"]),
                    int(row["target_index"]),
                ),
                block_count * 4 * 3,
            )
        )
    if observation_head_qualification_rows is not None:
        table_contracts.append(
            (
                "observation-head qualification",
                observation_head_qualification_rows,
                lambda row: (
                    int(row["seed"]),
                    int(row["block_id"]),
                    int(row["source_index"]),
                ),
                block_count * 6 * 3,
            )
        )
    for name, table, key_function, expected_count in table_contracts:
        keys = [key_function(row) for row in table]
        if len(keys) != expected_count or len(set(keys)) != expected_count:
            raise ValueError("%s exact unique key grid differs" % name)
        if sorted({key[0] for key in keys}) != list(SEEDS):
            raise ValueError("%s seed grid differs" % name)
        if sorted({key[1] for key in keys}) != block_ids:
            raise ValueError("%s calendar block grid differs" % name)
    for seed in seeds:
        actual = {
            "future_rows_per_seed": sum(int(row["seed"]) == seed for row in future_rows),
            "analysis_observation_rows_per_seed": sum(
                int(row["seed"]) == seed for row in observation_rows
            ),
            "analysis_target_rows_per_seed": sum(
                int(row["seed"]) == seed for row in target_rows
            ),
            "state_difference_rows_per_seed": sum(
                int(row["seed"]) == seed for row in state_rows
            ),
        }
        if base_qualification_rows is not None:
            actual["base_qualification_rows_per_seed"] = sum(
                int(row["seed"]) == seed for row in base_qualification_rows
            )
        if observation_head_qualification_rows is not None:
            actual["observation_head_qualification_rows_per_seed"] = sum(
                int(row["seed"]) == seed
                for row in observation_head_qualification_rows
            )
        for name, value in actual.items():
            if value != expected[name]:
                raise ValueError("%s count differs for seed %d" % (name, seed))
    return {
        "schema_version": "1.0",
        "status": "verified",
        "seed_values": seeds,
        "nonempty_block_ids": block_ids,
        "nonempty_block_count": block_count,
        **expected,
    }


def _observation_summary(
    rows: Sequence[Mapping[str, Any]],
    *,
    repeat_count: int,
    random_seed: int,
) -> List[Dict[str, Any]]:
    seeds = list(SEEDS)
    blocks = sorted({int(row["block_id"]) for row in rows})
    shape = (3, len(blocks), 6)
    prior = np.zeros(shape)
    posterior = np.zeros(shape)
    cells = np.zeros(shape, dtype=np.int64)
    positions = {value: index for index, value in enumerate(blocks)}
    ratios: Dict[int, List[float]] = {source: [] for source in range(6)}
    diagnostics: Dict[int, List[Mapping[str, Any]]] = {
        source: [] for source in range(6)
    }
    for row in rows:
        index = (
            seeds.index(int(row["seed"])),
            positions[int(row["block_id"])],
            int(row["source_index"]),
        )
        prior[index] += float(row["prior_absolute_residual_sum_m"])
        posterior[index] += float(row["posterior_absolute_residual_sum_m"])
        cells[index] += int(row["cell_count"])
        source = int(row["source_index"])
        decoded = json.loads(row["contraction_ratio_values_json"])
        if not isinstance(decoded, list) or any(
            not isinstance(value, (int, float)) or not math.isfinite(float(value))
            for value in decoded
        ):
            raise ValueError("contraction ratio JSON is invalid")
        ratios[source].extend(float(value) for value in decoded)
        diagnostics[source].append(row)
    if bool((cells <= 0).any()):
        raise ValueError("observation seed-block-source grid is incomplete")
    generator = np.random.Generator(np.random.PCG64(random_seed))
    seed_draws = generator.integers(0, 3, size=(repeat_count, 3), endpoint=False)
    block_draws = generator.integers(
        0, len(blocks), size=(repeat_count, len(blocks)), endpoint=False
    )
    result = []
    for source in range(6):
        chosen_prior = prior[
            seed_draws[:, :, None], block_draws[:, None, :], source
        ].sum(axis=(1, 2))
        chosen_posterior = posterior[
            seed_draws[:, :, None], block_draws[:, None, :], source
        ].sum(axis=(1, 2))
        chosen_cells = cells[
            seed_draws[:, :, None], block_draws[:, None, :], source
        ].sum(axis=(1, 2))
        deltas = (chosen_posterior - chosen_prior) / chosen_cells
        source_rows = diagnostics[source]
        total_cells = int(cells[:, :, source].sum())
        source_ratios = ratios[source]
        prior_mae = float(prior[:, :, source].sum() / total_cells)
        posterior_mae = float(posterior[:, :, source].sum() / total_cells)
        ratio_median = float(np.median(source_ratios)) if source_ratios else None
        row = {
            "source_index": source,
            "source_station": SOURCE_STATIONS[source],
            "cell_count": total_cells,
            "prior_mae_m": prior_mae,
            "posterior_mae_m": posterior_mae,
            "posterior_minus_prior_mae_m": posterior_mae - prior_mae,
            "posterior_minus_prior_one_sided_95_upper_m": float(
                np.quantile(deltas, 0.95, method="linear")
            ),
            "contraction_ratio_median": ratio_median,
            "contraction_ratio_count": len(source_ratios),
            "near_zero_prior_count": sum(
                int(value["near_zero_prior_count"]) for value in source_rows
            ),
            "near_zero_posterior_max_absolute_residual_m": max(
                float(value["near_zero_posterior_max_absolute_residual_m"])
                for value in source_rows
            ),
            "observation_contraction_min": min(
                float(value["observation_contraction_min"]) for value in source_rows
            ),
            "observation_contraction_max": max(
                float(value["observation_contraction_max"]) for value in source_rows
            ),
            "posterior_minimum_eigenvalue_minus_0_99_floor_min": min(
                float(value["posterior_minimum_eigenvalue_minus_0_99_floor_min"])
                for value in source_rows
            ),
            "observation_noise_standard_deviation_normalized": source_rows[0][
                "observation_noise_standard_deviation_normalized"
            ],
        }
        row["pass"] = bool(
            0.0 < row["observation_contraction_min"]
            and row["observation_contraction_max"] < 1.0
            and posterior_mae < prior_mae
            and row["posterior_minus_prior_one_sided_95_upper_m"] < 0.0
            and ratio_median is not None
            and 0.0 < ratio_median < 1.0
            and row["near_zero_posterior_max_absolute_residual_m"] <= 1e-6
            and row["posterior_minimum_eigenvalue_minus_0_99_floor_min"] >= 0.0
            and float(row["observation_noise_standard_deviation_normalized"]) > 1e-4
            and posterior_mae > 1e-6
        )
        result.append(row)
    return result


def _analysis_target_summary(rows: Sequence[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    result = []
    for source in range(6):
        for target in range(4):
            selected = [
                row
                for row in rows
                if int(row["source_index"]) == source
                and int(row["target_index"]) == target
            ]
            cells = sum(int(row["cell_count"]) for row in selected)
            prior = sum(float(row["prior_absolute_error_sum_m"]) for row in selected)
            posterior = sum(
                float(row["posterior_absolute_error_sum_m"]) for row in selected
            )
            result.append(
                {
                    "source_index": source,
                    "source_station": SOURCE_STATIONS[source],
                    "target_index": target,
                    "target_station": TARGET_STATIONS[target],
                    "cell_count": cells,
                    "prior_mae_m": prior / cells,
                    "posterior_mae_m": posterior / cells,
                    "analysis_gain_m": (prior - posterior) / cells,
                    "analysis_gain_mm": 1000.0 * (prior - posterior) / cells,
                    "analysis_movement_m": sum(
                        float(row["posterior_minus_prior_absolute_movement_sum_m"])
                        for row in selected
                    )
                    / cells,
                }
            )
    return result


def _state_summary(rows: Sequence[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    result = []
    for source in range(6):
        for lead in range(1, 24):
            selected = [
                row
                for row in rows
                if int(row["source_index"]) == source
                and int(row["post_update_lead_hour"]) == lead
            ]
            cells = sum(int(row["cell_count"]) for row in selected)
            result.append(
                {
                    "source_index": source,
                    "source_station": SOURCE_STATIONS[source],
                    "issue_horizon_hour": lead + 1,
                    "post_update_lead_hour": lead,
                    "cell_count": cells,
                    "state_mean_absolute_difference": sum(
                        float(row["state_mean_absolute_difference_sum"])
                        for row in selected
                    )
                    / cells,
                    "state_l2_difference": sum(
                        float(row["state_l2_difference_sum"]) for row in selected
                    )
                    / cells,
                }
            )
    return result


def _validated_observation_head_design_diagnostics(
    rows: Sequence[Mapping[str, Any]],
) -> List[Dict[str, Any]]:
    required = {
        "seed",
        "selection_report_path",
        "selection_report_sha256",
        "coefficient_float32_sha256",
        "selected_ridge_strength",
        "augmented_design_singular_values",
        "augmented_design_rank",
        "augmented_design_condition_number",
    }
    if (
        not isinstance(rows, Sequence)
        or isinstance(rows, (str, bytes))
        or len(rows) != 3
        or sorted(row.get("seed", -1) for row in rows) != list(SEEDS)
    ):
        raise ValueError("three observation-head design diagnostics are required")
    normalized = []
    for row in sorted(rows, key=lambda value: int(value["seed"])):
        if not isinstance(row, Mapping) or set(row) != required:
            raise ValueError("observation-head design diagnostic schema drift")
        value = dict(row)
        if not isinstance(value["selection_report_path"], str) or not value[
            "selection_report_path"
        ]:
            raise ValueError("observation-head selection report path is invalid")
        for name in (
            "selection_report_sha256",
            "coefficient_float32_sha256",
        ):
            digest = value[name]
            if (
                not isinstance(digest, str)
                or len(digest) != 64
                or any(character not in "0123456789abcdef" for character in digest)
            ):
                raise ValueError("observation-head diagnostic SHA-256 is invalid")
        singular_values = value["augmented_design_singular_values"]
        if (
            not isinstance(singular_values, list)
            or len(singular_values) != 33
            or any(
                not isinstance(item, (int, float))
                or isinstance(item, bool)
                or not math.isfinite(float(item))
                or float(item) < 0.0
                for item in singular_values
            )
        ):
            raise ValueError("observation-head singular-value diagnostic drift")
        rank = value["augmented_design_rank"]
        condition = value["augmented_design_condition_number"]
        ridge = value["selected_ridge_strength"]
        if type(rank) is not int or rank not in range(1, 34):
            raise ValueError("observation-head augmented rank is invalid")
        if (
            not isinstance(ridge, (int, float))
            or isinstance(ridge, bool)
            or not math.isfinite(float(ridge))
            or float(ridge) < 0.0
        ):
            raise ValueError("observation-head ridge strength is invalid")
        if condition is not None and (
            not isinstance(condition, (int, float))
            or isinstance(condition, bool)
            or not math.isfinite(float(condition))
            or float(condition) < 1.0
        ):
            raise ValueError("observation-head condition number is invalid")
        normalized.append(value)
    return normalized


def build_base_observation_head_qualification(
    base_rows: Sequence[Mapping[str, Any]],
    observation_head_rows: Sequence[Mapping[str, Any]],
    observation_head_design_diagnostics: Optional[
        Sequence[Mapping[str, Any]]
    ] = None,
) -> Dict[str, Any]:
    """Reconstruct the Section 6.2 qualification only from sufficient sums."""

    _require_exact_fields(base_rows, BASE_QUALIFICATION_FIELDS)
    _require_exact_fields(
        observation_head_rows, OBSERVATION_HEAD_QUALIFICATION_FIELDS
    )
    target_results = []
    for seed in SEEDS:
        for target in range(4):
            selected = [
                row
                for row in base_rows
                if int(row["seed"]) == seed
                and int(row["target_index"]) == target
            ]
            if not selected:
                raise ValueError("base qualification grid is incomplete")
            first_cells = sum(int(row["first_six_cell_count"]) for row in selected)
            full_cells = sum(
                int(row["full_twenty_four_cell_count"]) for row in selected
            )
            base_first = sum(
                float(row["base_first_six_absolute_error_sum_m"])
                for row in selected
            )
            persistence_first = sum(
                float(row["persistence_first_six_absolute_error_sum_m"])
                for row in selected
            )
            base_full_absolute = sum(
                float(row["base_full_twenty_four_absolute_error_sum_m"])
                for row in selected
            )
            base_full_squared = sum(
                float(row["base_full_twenty_four_squared_error_sum_m2"])
                for row in selected
            )
            target_sum = sum(
                float(row["target_full_twenty_four_sum_m"]) for row in selected
            )
            target_squared = sum(
                float(row["target_full_twenty_four_squared_sum_m2"])
                for row in selected
            )
            target_sst = max(0.0, target_squared - target_sum**2 / full_cells)
            nse = (
                1.0 - base_full_squared / target_sst
                if target_sst > 0.0
                else None
            )
            row = {
                "seed": seed,
                "target_index": target,
                "target_station": TARGET_STATIONS[target],
                "first_six_cell_count": first_cells,
                "base_first_six_mae_m": base_first / first_cells,
                "persistence_first_six_mae_m": persistence_first / first_cells,
                "full_twenty_four_cell_count": full_cells,
                "base_full_twenty_four_mae_m": base_full_absolute / full_cells,
                "base_full_twenty_four_rmse_m": math.sqrt(
                    base_full_squared / full_cells
                ),
                "base_full_twenty_four_nse": nse,
            }
            row["passed"] = bool(
                row["base_first_six_mae_m"]
                < row["persistence_first_six_mae_m"]
                and nse is not None
                and nse > 0.0
            )
            target_results.append(row)
    observation_results = []
    for seed in SEEDS:
        for source in range(6):
            selected = [
                row
                for row in observation_head_rows
                if int(row["seed"]) == seed
                and int(row["source_index"]) == source
            ]
            if not selected:
                raise ValueError("observation-head qualification grid is incomplete")
            cells = sum(int(row["cell_count"]) for row in selected)
            head_absolute = sum(
                float(row["head_absolute_error_sum_m"]) for row in selected
            )
            persistence_absolute = sum(
                float(row["persistence_absolute_error_sum_m"])
                for row in selected
            )
            bias = sum(float(row["head_bias_sum_m"]) for row in selected)
            row = {
                "seed": seed,
                "source_index": source,
                "source_station": SOURCE_STATIONS[source],
                "cell_count": cells,
                "head_mae_m": head_absolute / cells,
                "persistence_mae_m": persistence_absolute / cells,
                "head_bias_m": bias / cells,
            }
            row["passed"] = bool(row["head_mae_m"] < row["persistence_mae_m"])
            observation_results.append(row)
    target_pooled_results = []
    for target in range(4):
        selected = [
            row for row in base_rows if int(row["target_index"]) == target
        ]
        first_cells = sum(int(row["first_six_cell_count"]) for row in selected)
        full_cells = sum(
            int(row["full_twenty_four_cell_count"]) for row in selected
        )
        base_first = sum(
            float(row["base_first_six_absolute_error_sum_m"]) for row in selected
        )
        persistence_first = sum(
            float(row["persistence_first_six_absolute_error_sum_m"])
            for row in selected
        )
        full_absolute = sum(
            float(row["base_full_twenty_four_absolute_error_sum_m"])
            for row in selected
        )
        full_squared = sum(
            float(row["base_full_twenty_four_squared_error_sum_m2"])
            for row in selected
        )
        target_sum = sum(
            float(row["target_full_twenty_four_sum_m"]) for row in selected
        )
        target_squared = sum(
            float(row["target_full_twenty_four_squared_sum_m2"])
            for row in selected
        )
        target_sst = max(0.0, target_squared - target_sum**2 / full_cells)
        nse = 1.0 - full_squared / target_sst if target_sst > 0.0 else None
        result = {
            "target_index": target,
            "target_station": TARGET_STATIONS[target],
            "first_six_cell_count": first_cells,
            "base_first_six_mae_m": base_first / first_cells,
            "persistence_first_six_mae_m": persistence_first / first_cells,
            "full_twenty_four_cell_count": full_cells,
            "base_full_twenty_four_mae_m": full_absolute / full_cells,
            "base_full_twenty_four_rmse_m": math.sqrt(full_squared / full_cells),
            "base_full_twenty_four_nse": nse,
        }
        result["passed"] = bool(
            result["base_first_six_mae_m"]
            < result["persistence_first_six_mae_m"]
            and nse is not None
            and nse > 0.0
        )
        target_pooled_results.append(result)
    observation_pooled_results = []
    for source in range(6):
        selected = [
            row
            for row in observation_head_rows
            if int(row["source_index"]) == source
        ]
        cells = sum(int(row["cell_count"]) for row in selected)
        head = sum(float(row["head_absolute_error_sum_m"]) for row in selected)
        persistence = sum(
            float(row["persistence_absolute_error_sum_m"]) for row in selected
        )
        bias = sum(float(row["head_bias_sum_m"]) for row in selected)
        result = {
            "source_index": source,
            "source_station": SOURCE_STATIONS[source],
            "cell_count": cells,
            "head_mae_m": head / cells,
            "persistence_mae_m": persistence / cells,
            "head_bias_m": bias / cells,
        }
        result["passed"] = bool(result["head_mae_m"] < result["persistence_mae_m"])
        observation_pooled_results.append(result)
    gates = {
        "all_four_pooled_targets_beat_persistence_and_have_positive_nse": all(
            row["passed"] for row in target_pooled_results
        ),
        "all_six_pooled_observation_heads_beat_one_hour_persistence": all(
            row["passed"] for row in observation_pooled_results
        ),
    }
    diagnostics = _validated_observation_head_design_diagnostics(
        observation_head_design_diagnostics
    ) if observation_head_design_diagnostics is not None else []
    return {
        "schema_version": "1.0",
        "qualification_gate_contract": {
            "aggregation": "pooled_equal_weight_three_seeds",
            "hard_target_gate_count": 4,
            "hard_source_gate_count": 6,
            "per_seed_results_are_diagnostics_only": True,
        },
        "passed": all(gates.values()),
        "target_pooled_results": target_pooled_results,
        "observation_head_pooled_results": observation_pooled_results,
        "target_seed_results": target_results,
        "observation_head_seed_results": observation_results,
        "observation_head_design_diagnostics": diagnostics,
        "gates": gates,
    }


def _validated_dependency_evidence(
    evidence: Mapping[str, Any],
) -> Dict[str, np.ndarray | str]:
    required = {
        "sample_identity_sha256",
        "original_observation_normalized",
        "perturbed_observation_normalized",
        "original_posterior_observation_normalized",
        "perturbed_posterior_observation_normalized",
    }
    if not isinstance(evidence, Mapping) or set(evidence) != required:
        raise ValueError("dependency perturbation evidence schema drift")
    identity = evidence["sample_identity_sha256"]
    if (
        not isinstance(identity, str)
        or len(identity) != 64
        or any(character not in "0123456789abcdef" for character in identity)
    ):
        raise ValueError("dependency perturbation sample identity is invalid")
    original = np.asarray(
        evidence["original_observation_normalized"], dtype=np.float64
    )
    if original.ndim != 2 or original.shape[0] < 1 or original.shape[1] != 6:
        raise ValueError("dependency evidence observation must have shape [sample, 6]")
    arrays: Dict[str, np.ndarray | str] = {
        "sample_identity_sha256": identity,
        "original_observation_normalized": original,
    }
    for name in required - {
        "sample_identity_sha256",
        "original_observation_normalized",
    }:
        value = np.asarray(evidence[name], dtype=np.float64)
        if value.shape != original.shape or not bool(np.isfinite(value).all()):
            raise ValueError("dependency perturbation array shape or value is invalid")
        arrays[name] = value
    if not bool(np.isfinite(original).all()):
        raise ValueError("dependency original observation is nonfinite")
    perturbation = (
        arrays["perturbed_observation_normalized"] - original
    )
    if not bool(
        np.allclose(
            perturbation,
            DEPENDENCY_PERTURBATION_DELTA_NORMALIZED,
            atol=1e-12,
            rtol=1e-10,
        )
    ):
        raise ValueError("dependency perturbation must be +0.01 normalized units")
    return arrays


def _validated_data_access_audit(audit: Mapping[str, Any]) -> Dict[str, Any]:
    if not isinstance(audit, Mapping) or set(audit) != set(DATA_ACCESS_AUDIT_FIELDS):
        raise ValueError("development data-access audit schema drift")
    opened = audit["opened_paths"]
    if (
        not isinstance(opened, (list, tuple))
        or len(opened) != len(FROZEN_DEVELOPMENT_BYTES_BY_PATH)
        or set(opened) != set(FROZEN_DEVELOPMENT_BYTES_BY_PATH)
        or len(set(opened)) != len(opened)
    ):
        raise ValueError("development data-access audit path allow-list drift")
    normalized: Dict[str, Any] = {"opened_paths": list(opened)}
    bytes_by_path = audit["bytes_read_by_path"]
    if (
        not isinstance(bytes_by_path, Mapping)
        or dict(bytes_by_path) != FROZEN_DEVELOPMENT_BYTES_BY_PATH
    ):
        raise ValueError("development per-path byte identity drift")
    normalized["bytes_read_by_path"] = dict(bytes_by_path)
    rows_by_path = audit["rows_parsed_by_path"]
    rows_keys = set(rows_by_path) if isinstance(rows_by_path, Mapping) else set()
    if (
        not isinstance(rows_by_path, Mapping)
        or rows_keys
        not in (
            FROZEN_DEVELOPMENT_CSV_PATHS,
            set(FROZEN_DEVELOPMENT_BYTES_BY_PATH),
        )
        or (
            "dataset_config.json" in rows_by_path
            and rows_by_path["dataset_config.json"] != 0
        )
        or any(
            type(rows_by_path[path]) is not int
            or rows_by_path[path] != FROZEN_PREFIX_ROWS_PER_CSV
            for path in FROZEN_DEVELOPMENT_CSV_PATHS
        )
    ):
        raise ValueError("development parsed-row identity drift")
    normalized["rows_parsed_by_path"] = {
        "dataset_config.json": 0,
        **{path: rows_by_path[path] for path in FROZEN_DEVELOPMENT_CSV_PATHS},
    }
    values_by_path = audit["values_loaded_by_path"]
    values_keys = (
        set(values_by_path) if isinstance(values_by_path, Mapping) else set()
    )
    if (
        not isinstance(values_by_path, Mapping)
        or values_keys
        not in (
            FROZEN_DEVELOPMENT_CSV_PATHS,
            set(FROZEN_DEVELOPMENT_BYTES_BY_PATH),
        )
        or (
            "dataset_config.json" in values_by_path
            and values_by_path["dataset_config.json"] != 0
        )
        or any(
            type(values_by_path[path]) is not int
            or values_by_path[path] < 0
            or values_by_path[path] > FROZEN_PREFIX_ROWS_PER_CSV
            for path in FROZEN_DEVELOPMENT_CSV_PATHS
        )
    ):
        raise ValueError("development loaded-value identity drift")
    normalized["values_loaded_by_path"] = {
        "dataset_config.json": 0,
        **{path: values_by_path[path] for path in FROZEN_DEVELOPMENT_CSV_PATHS},
    }
    periods = audit["target_rows_by_period"]
    expected_periods = {
        "training",
        "selection",
        "development_gate",
        "heldout_or_later",
        "boundary_target",
    }
    if not isinstance(periods, Mapping) or set(periods) != expected_periods:
        raise ValueError("development target-period counters differ")
    if dict(periods) != FROZEN_DEVELOPMENT_TARGET_ROWS_BY_PERIOD:
        raise ValueError("development target-period identity drift")
    normalized["target_rows_by_period"] = dict(periods)
    for name in DATA_ACCESS_AUDIT_FIELDS[5:]:
        if name == "target_rows_by_period":
            continue
        value = audit[name]
        if type(value) is not int or value < 0:
            raise ValueError("development aggregate access count is invalid")
        normalized[name] = value
    if normalized["astronomical_tide_model_open_count"] != 1:
        raise ValueError("astronomical tide model must be opened exactly once")
    exact_aggregates = {
        "development_feature_bytes_read": FROZEN_DEVELOPMENT_FEATURE_BYTES,
        "development_feature_rows_parsed": FROZEN_DEVELOPMENT_FEATURE_ROWS,
        "development_target_bytes_read": FROZEN_DEVELOPMENT_TARGET_BYTES,
        "development_target_rows_parsed": FROZEN_DEVELOPMENT_TARGET_ROWS,
    }
    if any(normalized[name] != value for name, value in exact_aggregates.items()):
        raise ValueError("development aggregate byte or row identity drift")
    feature_paths = [
        path for path in FROZEN_DEVELOPMENT_CSV_PATHS
        if path.startswith("realtime_features/")
    ]
    target_paths = [
        path for path in FROZEN_DEVELOPMENT_CSV_PATHS
        if path.startswith("retrospective_targets/")
    ]
    for aggregate_name, paths, maximum in (
        (
            "development_feature_values_loaded",
            feature_paths,
            FROZEN_DEVELOPMENT_FEATURE_ROWS,
        ),
        (
            "development_target_values_loaded",
            target_paths,
            FROZEN_DEVELOPMENT_TARGET_ROWS,
        ),
    ):
        observed = normalized[aggregate_name]
        total = sum(values_by_path[path] for path in paths)
        predevelopment_capacity = (
            len(paths) * FROZEN_PREDEVELOPMENT_ROWS_PER_CSV
        )
        if not max(0, total - predevelopment_capacity) <= observed <= min(
            total, maximum
        ):
            raise ValueError("development loaded-value aggregate is incompatible")
    forbidden = (
        "heldout_target_bytes_read",
        "heldout_target_rows_parsed",
        "heldout_target_values_loaded",
        "boundary_target_bytes_read",
        "boundary_target_rows_parsed",
        "boundary_target_values_loaded",
    )
    if any(normalized[name] != 0 for name in forbidden):
        raise ValueError("held-out or boundary target access is nonzero")
    if (
        normalized["target_rows_by_period"]["heldout_or_later"] != 0
        or normalized["target_rows_by_period"]["boundary_target"] != 0
    ):
        raise ValueError("held-out or boundary target-period access is nonzero")
    return normalized


def _reciprocal_summary(matrix: Sequence[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    lookup = {
        (int(row["source_index"]), int(row["target_index"])): row for row in matrix
    }
    result = []
    for upstream_target in range(4):
        for downstream_target in range(upstream_target + 1, 4):
            forward = lookup[(upstream_target + 1, downstream_target)]
            reverse = lookup[(downstream_target + 1, upstream_target)]
            result.append(
                {
                    "upstream_station": TARGET_STATIONS[upstream_target],
                    "downstream_station": TARGET_STATIONS[downstream_target],
                    "upstream_to_downstream_gain_m": forward[
                        "measurement_update_gain_m"
                    ],
                    "downstream_to_upstream_gain_m": reverse[
                        "measurement_update_gain_m"
                    ],
                    "upstream_to_downstream_movement_m": forward[
                        "forecast_movement_m"
                    ],
                    "downstream_to_upstream_movement_m": reverse[
                        "forecast_movement_m"
                    ],
                }
            )
    return result


def _write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    if not rows:
        raise ValueError("cannot write an empty CSV table")
    fields: List[str] = []
    for row in rows:
        for field in row:
            if field not in fields:
                fields.append(field)
    with path.open("x", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)


def _write_json(path: Path, value: Any) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _normalization_document(normalization: Any) -> Dict[str, Any]:
    """Create the checkpoint's four-space normalization identity."""

    result: Dict[str, Any] = {}
    for name in (
        "history_stage",
        "future_tide",
        "analysis_stage",
        "retrospective_target",
    ):
        space = getattr(normalization, name, None)
        if space is None:
            raise ValueError("development normalization space is missing")
        result[name] = {
            "role": space.role,
            "mean_m": np.asarray(space.mean_m, dtype=np.float64).tolist(),
            "standard_deviation_m": np.asarray(
                space.standard_deviation_m, dtype=np.float64
            ).tolist(),
            "value_count": np.asarray(space.value_count).tolist(),
        }
    return result


def _mapping_sha256(value: Mapping[str, Any]) -> str:
    encoded = json.dumps(
        value, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _read_json_mapping(path: Path) -> Mapping[str, Any]:
    try:
        document = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError("cannot read registered JSON document") from error
    if not isinstance(document, Mapping):
        raise ValueError("registered JSON root must be an object")
    return document


def _write_json_atomically_create_only(path: Path, value: Any) -> None:
    """Publish a complete JSON marker only after its bytes reach disk."""

    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(
            value,
            handle,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    if path.exists():
        raise FileExistsError("development-access marker already exists")
    os.rename(temporary, path)


def _claim_development_access_before_loader(
    partial_directory: Path,
    *,
    registered_run_identity: Mapping[str, str],
    frozen_artifact_identities: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    """Atomically and permanently record that the single 2023 read is starting."""

    partial = Path(partial_directory).resolve()
    partial.mkdir(parents=True, exist_ok=False)
    marker = {
        "schema_version": "1.0",
        "status": "development_access_claimed_before_loader",
        "experiment_id": FORMAL_DEVELOPMENT_EXPERIMENT_ID,
        "claimed_at_utc": datetime.now(timezone.utc)
        .isoformat(timespec="microseconds")
        .replace("+00:00", "Z"),
        "evaluation_partial_directory": str(partial),
        "registered_run_identity": dict(registered_run_identity),
        "frozen_artifact_identities": [
            dict(row)
            for row in sorted(
                frozen_artifact_identities, key=lambda value: int(value["seed"])
            )
        ],
        "frozen_artifact_count": 9,
        "held_out_2024_target_access_authorized": False,
        "boundary_future_target_access_authorized": False,
    }
    _write_json_atomically_create_only(
        partial / DEVELOPMENT_ACCESS_MARKER_NAME, marker
    )
    return marker


def _validated_development_access_marker(
    marker: Mapping[str, Any],
    *,
    partial_directory: Path,
    registered_run_identity: Mapping[str, str],
    frozen_artifact_identities: Sequence[Mapping[str, Any]],
) -> Dict[str, Any]:
    required = {
        "schema_version",
        "status",
        "experiment_id",
        "claimed_at_utc",
        "evaluation_partial_directory",
        "registered_run_identity",
        "frozen_artifact_identities",
        "frozen_artifact_count",
        "held_out_2024_target_access_authorized",
        "boundary_future_target_access_authorized",
    }
    if not isinstance(marker, Mapping) or set(marker) != required:
        raise ValueError("development-access marker schema drift")
    timestamp = marker["claimed_at_utc"]
    try:
        parsed_timestamp = datetime.fromisoformat(
            str(timestamp).replace("Z", "+00:00")
        )
    except ValueError as error:
        raise ValueError("development-access marker UTC timestamp is invalid") from error
    if (
        not isinstance(timestamp, str)
        or not timestamp.endswith("Z")
        or parsed_timestamp.utcoffset() is None
        or parsed_timestamp.utcoffset().total_seconds() != 0.0
        or marker["schema_version"] != "1.0"
        or marker["status"] != "development_access_claimed_before_loader"
        or marker["experiment_id"] != FORMAL_DEVELOPMENT_EXPERIMENT_ID
        or marker["evaluation_partial_directory"]
        != str(Path(partial_directory).resolve())
        or marker["registered_run_identity"] != dict(registered_run_identity)
        or marker["frozen_artifact_identities"]
        != [dict(row) for row in frozen_artifact_identities]
        or marker["frozen_artifact_count"] != 9
        or marker["held_out_2024_target_access_authorized"] is not False
        or marker["boundary_future_target_access_authorized"] is not False
    ):
        raise ValueError("development-access marker identity drift")
    return dict(marker)


def _require_new_output_paths(
    output_directory: Path,
    audit_directory: Path,
    remote_root: Path,
) -> tuple[Path, Path]:
    expected_output = (remote_root / FORMAL_EVALUATION_RELATIVE_PATH).resolve()
    expected_audit = (remote_root / FORMAL_AUDIT_RELATIVE_PATH).resolve()
    output = Path(output_directory).resolve()
    audit = Path(audit_directory).resolve()
    if output != expected_output or audit != expected_audit:
        raise ValueError("formal evaluation or audit path differs from frozen evidence path")
    for path in (
        output,
        output.with_name(output.name + ".partial"),
        audit,
        audit.with_name(audit.name + ".partial"),
    ):
        if path.exists():
            raise FileExistsError("formal evaluation evidence path already exists")
    return output, audit


def _registered_artifact_paths(
    registry: Mapping[str, Any], seed: int
) -> tuple[Path, Path, Path]:
    tasks = registry.get("tasks")
    if not isinstance(tasks, list):
        raise ValueError("registry task list is missing")
    coordinates = {
        stage: [
            row
            for row in tasks
            if isinstance(row, Mapping)
            and row.get("stage") == stage
            and row.get("seed") == seed
        ]
        for stage in ("base_training", "observation_head", "filter_training")
    }
    if any(len(rows) != 1 for rows in coordinates.values()):
        raise ValueError("registered training task coordinate is not unique")
    base_directory = Path(
        coordinates["base_training"][0]["registered_output_path"]
    ).resolve()
    head_directory = Path(
        coordinates["observation_head"][0]["registered_output_path"]
    ).resolve()
    filter_directory = Path(
        coordinates["filter_training"][0]["registered_output_path"]
    ).resolve()
    base_path = base_directory / "best_checkpoint.pt"
    head_path = head_directory / "realtime_observation_head.pt"
    filter_path = filter_directory / "best_filter_checkpoint.pt"
    filter_task = coordinates["filter_training"][0]
    if (
        Path(filter_task.get("registered_base_checkpoint_path", "")).resolve()
        != base_path
        or Path(filter_task.get("registered_observation_head_path", "")).resolve()
        != head_path
    ):
        raise ValueError("registered filter upstream artifact path drift")
    return base_path, head_path, filter_path


def _load_selected_filter_noise(
    model: Any,
    checkpoint_path: Path,
    *,
    seed: int,
    expected_base_sha256: str,
    expected_head_sha256: str,
    expected_normalization_sha256: str,
    expected_optimization: Mapping[str, Any],
) -> Mapping[str, Any]:
    checkpoint = torch.load(
        checkpoint_path, map_location="cpu", weights_only=False
    )
    required = {
        "schema_version",
        "experiment_family",
        "seed",
        "epoch",
        "selection_mae_m",
        "selection_cell_contract",
        "selection_cells_per_base_sample",
        "base_checkpoint_sha256",
        "observation_head_sha256",
        "normalization_sha256",
        "filter_state_dict",
        "optimization",
    }
    if not isinstance(checkpoint, Mapping) or set(checkpoint) != required:
        raise ValueError("selected filter checkpoint schema drift")
    if (
        checkpoint["schema_version"] != 1
        or checkpoint["experiment_family"] != FORMAL_EXPERIMENT_FAMILY
        or checkpoint["seed"] != seed
        or checkpoint["base_checkpoint_sha256"] != expected_base_sha256
        or checkpoint["observation_head_sha256"] != expected_head_sha256
        or checkpoint["normalization_sha256"] != expected_normalization_sha256
        or checkpoint["selection_cell_contract"]
        != "6_sources_x_23_leads_x_4_targets"
        or checkpoint["selection_cells_per_base_sample"] != 552
        or checkpoint["optimization"] != expected_optimization
        or type(checkpoint["epoch"]) is not int
        or checkpoint["epoch"] not in range(1, 21)
        or not math.isfinite(float(checkpoint["selection_mae_m"]))
    ):
        raise ValueError("selected filter checkpoint identity drift")
    state = checkpoint["filter_state_dict"]
    expected_state = {
        "process_noise.raw_standard_deviation": (32,),
        "observation_noise.raw_standard_deviation": (6,),
    }
    if not isinstance(state, Mapping) or set(state) != set(expected_state):
        raise ValueError("selected filter noise-state schema drift")
    for name, shape in expected_state.items():
        value = state[name]
        if (
            not isinstance(value, torch.Tensor)
            or tuple(value.shape) != shape
            or value.dtype != torch.float64
            or not bool(torch.isfinite(value).all())
        ):
            raise ValueError("selected filter noise tensor identity drift")
    with torch.no_grad():
        model.process_noise.raw_standard_deviation.copy_(
            state["process_noise.raw_standard_deviation"].to(
                device=model.process_noise.raw_standard_deviation.device
            )
        )
        model.observation_noise.raw_standard_deviation.copy_(
            state["observation_noise.raw_standard_deviation"].to(
                device=model.observation_noise.raw_standard_deviation.device
            )
        )
    model.eval()
    model.requires_grad_(False)
    if model.training or any(parameter.requires_grad for parameter in model.parameters()):
        raise RuntimeError("development filter was not frozen")
    return checkpoint


def _select_reported_observation_head_candidate(
    candidates: Any,
) -> Mapping[str, Any]:
    """Reapply the frozen global-minimum ridge-selection rule."""

    required = {
        "ridge_strength",
        "selection_mean_absolute_error_m",
        "station_selection_mean_absolute_error_m",
        "augmented_design_singular_values",
        "augmented_design_rank",
        "augmented_design_condition_number",
        "coefficient_float64_sha256",
        "coefficient_float32_sha256",
    }
    if not isinstance(candidates, list) or len(candidates) != len(
        FROZEN_RIDGE_STRENGTHS
    ):
        raise ValueError("observation-head candidate grid is incomplete")
    normalized: List[Mapping[str, Any]] = []
    for candidate in candidates:
        if not isinstance(candidate, Mapping) or set(candidate) != required:
            raise ValueError("observation-head candidate diagnostic schema drift")
        ridge = candidate["ridge_strength"]
        selection_error = candidate["selection_mean_absolute_error_m"]
        station_errors = candidate["station_selection_mean_absolute_error_m"]
        singular_values = candidate["augmented_design_singular_values"]
        rank = candidate["augmented_design_rank"]
        condition = candidate["augmented_design_condition_number"]
        if (
            not isinstance(ridge, (int, float))
            or isinstance(ridge, bool)
            or not math.isfinite(float(ridge))
            or not isinstance(selection_error, (int, float))
            or isinstance(selection_error, bool)
            or not math.isfinite(float(selection_error))
            or float(selection_error) < 0.0
            or not isinstance(station_errors, list)
            or len(station_errors) != 6
            or any(
                not isinstance(value, (int, float))
                or isinstance(value, bool)
                or not math.isfinite(float(value))
                or float(value) < 0.0
                for value in station_errors
            )
            or not isinstance(singular_values, list)
            or len(singular_values) != 33
            or any(
                not isinstance(value, (int, float))
                or isinstance(value, bool)
                or not math.isfinite(float(value))
                or float(value) < 0.0
                for value in singular_values
            )
            or type(rank) is not int
            or rank not in range(1, 34)
            or (
                condition is not None
                and (
                    not isinstance(condition, (int, float))
                    or isinstance(condition, bool)
                    or not math.isfinite(float(condition))
                    or float(condition) < 1.0
                )
            )
        ):
            raise ValueError("observation-head candidate numerical diagnostic drift")
        for name in ("coefficient_float64_sha256", "coefficient_float32_sha256"):
            digest = candidate[name]
            if (
                not isinstance(digest, str)
                or len(digest) != 64
                or any(character not in "0123456789abcdef" for character in digest)
            ):
                raise ValueError("observation-head candidate coefficient hash drift")
        normalized.append(candidate)
    if tuple(sorted(float(row["ridge_strength"]) for row in normalized)) != (
        FROZEN_RIDGE_STRENGTHS
    ):
        raise ValueError("observation-head fixed ridge grid drift")
    global_minimum = min(
        float(row["selection_mean_absolute_error_m"]) for row in normalized
    )
    tied = [
        row
        for row in normalized
        if float(row["selection_mean_absolute_error_m"]) - global_minimum
        <= FROZEN_RIDGE_TIE_TOLERANCE_M
    ]
    return max(tied, key=lambda row: float(row["ridge_strength"]))


def _read_observation_head_design_diagnostic(
    observation_head_path: Path, *, seed: int
) -> Dict[str, Any]:
    report_path = observation_head_path.parent / "ridge_candidate_diagnostics.json"
    report = _read_json_mapping(report_path)
    head = torch.load(
        observation_head_path, map_location="cpu", weights_only=False
    )
    if not isinstance(head, Mapping) or head.get("seed") != seed:
        raise ValueError("observation-head artifact identity drift")
    selected_ridge = report.get("selected_ridge_strength")
    selected_coefficient = report.get("selected_coefficient_float32_sha256")
    if (
        selected_ridge != head.get("selected_ridge_strength")
        or selected_coefficient != head.get("coefficient_float32_sha256")
    ):
        raise ValueError("observation-head report and coefficient identity differ")
    candidates = report.get("candidates")
    frozen_selected = _select_reported_observation_head_candidate(candidates)
    if (
        frozen_selected["ridge_strength"] != selected_ridge
        or frozen_selected["coefficient_float32_sha256"]
        != selected_coefficient
    ):
        raise ValueError(
            "observation-head selection violates the global-minimum tie rule"
        )
    selected = [
        row
        for row in candidates
        if isinstance(row, Mapping)
        and row.get("ridge_strength") == selected_ridge
        and row.get("coefficient_float32_sha256") == selected_coefficient
    ]
    if len(selected) != 1:
        raise ValueError("selected observation-head diagnostic is not unique")
    candidate = selected[0]
    return {
        "seed": seed,
        "selection_report_path": str(report_path.resolve()),
        "selection_report_sha256": _sha256(report_path),
        "coefficient_float32_sha256": selected_coefficient,
        "selected_ridge_strength": selected_ridge,
        "augmented_design_singular_values": candidate.get(
            "augmented_design_singular_values"
        ),
        "augmented_design_rank": candidate.get("augmented_design_rank"),
        "augmented_design_condition_number": candidate.get(
            "augmented_design_condition_number"
        ),
    }


def _tensor_numpy(value: Any, name: str) -> np.ndarray:
    if not isinstance(value, torch.Tensor):
        raise ValueError("model output is not a tensor: " + name)
    result = value.detach().cpu().numpy().astype(np.float64, copy=False)
    if not bool(np.isfinite(result).all()):
        raise ValueError("model output is nonfinite: " + name)
    return result


def materialize_shared_development_statistics(
    *,
    data: Any,
    development_dataset: Any,
    frozen_models: Mapping[int, Any],
    device: str | torch.device,
    batch_size: int = 32,
    data_loader_factory: Any = DataLoader,
) -> tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Run three frozen seeds over one already-created 2023 dataset object."""

    if set(frozen_models) != set(SEEDS):
        raise ValueError("exactly three frozen seed models are required")
    if type(batch_size) is not int or batch_size < 1:
        raise ValueError("batch_size must be a positive integer")
    normalization = data.normalization
    target_mean = np.asarray(
        normalization.retrospective_target.mean_m, dtype=np.float64
    )
    target_scale = np.asarray(
        normalization.retrospective_target.standard_deviation_m,
        dtype=np.float64,
    )
    observation_mean = np.asarray(
        normalization.analysis_stage.mean_m, dtype=np.float64
    )
    observation_scale = np.asarray(
        normalization.analysis_stage.standard_deviation_m, dtype=np.float64
    )
    if (
        target_mean.shape != (4,)
        or target_scale.shape != (4,)
        or observation_mean.shape != (6,)
        or observation_scale.shape != (6,)
        or bool((target_scale <= 0.0).any())
        or bool((observation_scale <= 0.0).any())
    ):
        raise ValueError("development normalization shape or scale drift")
    torch_device = torch.device(device)
    seed_statistics: List[Dict[str, Any]] = []
    dependency_evidence: Optional[Dict[str, Any]] = None
    for seed in SEEDS:
        model = frozen_models[seed]
        if model.training or any(
            parameter.requires_grad for parameter in model.parameters()
        ):
            raise RuntimeError("development model must remain frozen")
        loader = data_loader_factory(
            development_dataset,
            batch_size=batch_size,
            shuffle=False,
            drop_last=False,
            num_workers=0,
        )
        batches: List[Mapping[str, Any]] = []
        for raw_batch in loader:
            required_tensor_keys = (
                "history",
                "future_tide",
                "analysis_observations",
                "targets_t_plus_1_to_t_plus_24",
                "targets_t_plus_2_to_t_plus_24",
                "issue_position",
            )
            if any(
                not isinstance(raw_batch.get(name), torch.Tensor)
                for name in required_tensor_keys
            ):
                raise ValueError("development batch tensor contract drift")
            history = raw_batch["history"].to(torch_device)
            tide = raw_batch["future_tide"].to(torch_device)
            observation_normalized = raw_batch["analysis_observations"].to(
                torch_device
            )
            positions = raw_batch["issue_position"].detach().cpu().numpy()
            if positions.ndim != 1 or positions.shape[0] != history.shape[0]:
                raise ValueError("development issue-position contract drift")
            positions = positions.astype(np.int64, copy=False)
            issue_times = list(raw_batch.get("issue_time_beijing", ()))
            if len(issue_times) != len(positions) or any(
                not isinstance(value, str)
                or not value.startswith("2023-")
                or not value.endswith("+08:00")
                for value in issue_times
            ):
                raise ValueError("development issue-time contract drift")
            with torch.no_grad():
                output = model(history, tide, observation_normalized)
            target_24_m = np.stack(
                [
                    data.retrospective_targets_m[position + 1 : position + 25]
                    for position in positions
                ],
                axis=0,
            ).astype(np.float64, copy=False)
            current_stage_m = np.asarray(
                data.realtime_stages_m[positions], dtype=np.float64
            )
            analysis_observation_m = np.asarray(
                data.realtime_stages_m[positions + 1], dtype=np.float64
            )

            def target_to_m(value: Any, name: str) -> np.ndarray:
                array = _tensor_numpy(value, name)
                return array * target_scale + target_mean

            def observation_to_m(value: Any, name: str) -> np.ndarray:
                array = _tensor_numpy(value, name)
                return array * observation_scale + observation_mean

            batches.append(
                accumulate_development_sufficient_statistics(
                    experiment_id=FORMAL_DEVELOPMENT_EXPERIMENT_ID,
                    seed=seed,
                    origin_times=issue_times,
                    target_future_m=target_24_m[:, 1:, :],
                    analysis_target_m=target_24_m[:, 0, :],
                    analysis_observation_m=analysis_observation_m,
                    current_stage_m=current_stage_m,
                    base_issue_hour_one_forecast_m=target_to_m(
                        output["base_deterministic_issue_hour_one_target"],
                        "base_deterministic_issue_hour_one_target",
                    ),
                    base_deterministic_forecast_m=target_to_m(
                        output["base_deterministic_forecast"],
                        "base_deterministic_forecast",
                    ),
                    unscented_prior_forecast_m=target_to_m(
                        output["unscented_prior_forecast"],
                        "unscented_prior_forecast",
                    ),
                    updated_forecast_m=target_to_m(
                        output["updated_forecast"], "updated_forecast"
                    ),
                    analysis_prior_target_m=target_to_m(
                        output["analysis_prior_target"],
                        "analysis_prior_target",
                    ),
                    analysis_posterior_target_m=target_to_m(
                        output["analysis_posterior_target"],
                        "analysis_posterior_target",
                    ),
                    analysis_prior_observation_m=observation_to_m(
                        output["analysis_prior_observation"],
                        "analysis_prior_observation",
                    ),
                    analysis_posterior_observation_m=observation_to_m(
                        output["analysis_posterior_observation"],
                        "analysis_posterior_observation",
                    ),
                    analysis_kalman_gain=output["analysis_kalman_gain"],
                    analysis_observation_contraction=output[
                        "analysis_observation_contraction"
                    ],
                    analysis_posterior_observation_variance_normalized=output[
                        "analysis_posterior_observation_variance"
                    ],
                    analysis_posterior_minimum_eigenvalue=output[
                        "analysis_posterior_minimum_eigenvalue"
                    ],
                    analysis_spectral_floor=output["analysis_spectral_floor"],
                    observation_noise_standard_deviation_normalized=output[
                        "observation_noise_standard_deviation"
                    ],
                    unscented_prior_state_mean=output[
                        "unscented_prior_state_mean"
                    ],
                    updated_state_mean=output["updated_state_mean"],
                )
            )
            if dependency_evidence is None:
                perturbed = observation_normalized + observation_normalized.new_tensor(
                    DEPENDENCY_PERTURBATION_DELTA_NORMALIZED
                )
                with torch.no_grad():
                    perturbed_output = model(history, tide, perturbed)
                original_posterior = _tensor_numpy(
                    output["analysis_posterior_observation"],
                    "analysis_posterior_observation",
                )
                perturbed_posterior = _tensor_numpy(
                    perturbed_output["analysis_posterior_observation"],
                    "perturbed_analysis_posterior_observation",
                )
                source_index = np.arange(6)
                dependency_evidence = {
                    "sample_identity_sha256": hashlib.sha256(
                        json.dumps(
                            issue_times,
                            ensure_ascii=False,
                            separators=(",", ":"),
                        ).encode("utf-8")
                    ).hexdigest(),
                    "original_observation_normalized": _tensor_numpy(
                        observation_normalized,
                        "original_observation_normalized",
                    ),
                    "perturbed_observation_normalized": _tensor_numpy(
                        perturbed, "perturbed_observation_normalized"
                    ),
                    "original_posterior_observation_normalized": (
                        original_posterior[:, source_index, source_index]
                    ),
                    "perturbed_posterior_observation_normalized": (
                        perturbed_posterior[:, source_index, source_index]
                    ),
                }
        if not batches:
            raise RuntimeError("development dataset produced no batches")
        seed_statistics.append(combine_seed_sufficient_statistics(batches))
    if dependency_evidence is None:
        raise RuntimeError("dependency perturbation evidence was not generated")
    return seed_statistics, dependency_evidence


def write_development_evaluation(
    output_directory: Path,
    seed_statistics: Sequence[Mapping[str, Any]],
    *,
    identity_gate_details: Mapping[str, bool],
    dependency_perturbation_evidence: Mapping[str, Any],
    data_access_audit: Mapping[str, Any],
    frozen_artifact_identities: Sequence[Mapping[str, Any]],
    registered_run_identity: Mapping[str, str],
    base_observation_head_qualification: Optional[Mapping[str, Any]] = None,
    repeat_count: int = BOOTSTRAP_REPEAT_COUNT,
    random_seed: int = BOOTSTRAP_RANDOM_SEED,
    synthetic_test_mode: bool = False,
) -> Path:
    """Create one non-overwriting complete evaluation directory atomically."""

    if not synthetic_test_mode and (
        repeat_count != BOOTSTRAP_REPEAT_COUNT
        or random_seed != BOOTSTRAP_RANDOM_SEED
    ):
        raise ValueError("formal evaluation must use the frozen bootstrap settings")
    output_directory = Path(output_directory)
    if output_directory.exists():
        raise FileExistsError("evaluation output directory already exists")
    partial = output_directory.with_name(output_directory.name + ".partial")
    if synthetic_test_mode and partial.exists():
        raise FileExistsError("partial evaluation directory already exists")
    if not synthetic_test_mode and not partial.is_dir():
        raise RuntimeError(
            "formal evaluation requires a development-access marker claimed before loading"
        )
    if len(seed_statistics) != 3 or sorted(
        int(row["seed"]) for row in seed_statistics
    ) != list(SEEDS):
        raise ValueError("evaluation requires exactly the three frozen seeds")
    experiment_ids = {row["experiment_id"] for row in seed_statistics}
    if len(experiment_ids) != 1:
        raise ValueError("seed experiment identities differ")
    future_rows = [row for seed in seed_statistics for row in seed["future_rows"]]
    observation_rows = [
        row for seed in seed_statistics for row in seed["analysis_observation_rows"]
    ]
    target_rows = [
        row for seed in seed_statistics for row in seed["analysis_target_rows"]
    ]
    state_rows = [
        row for seed in seed_statistics for row in seed["state_difference_rows"]
    ]
    base_qualification_rows = [
        row for seed in seed_statistics for row in seed["base_qualification_rows"]
    ]
    observation_head_qualification_rows = [
        row
        for seed in seed_statistics
        for row in seed["observation_head_qualification_rows"]
    ]
    grid = verify_sufficient_grid(
        future_rows,
        observation_rows,
        target_rows,
        state_rows,
        base_qualification_rows,
        observation_head_qualification_rows,
    )
    dependency_evidence = _validated_dependency_evidence(
        dependency_perturbation_evidence
    )
    normalized_access_audit = _validated_data_access_audit(data_access_audit)
    required_run_identity = {
        "registry_path",
        "registry_sha256",
        "input_root_path",
        "input_manifest_path",
        "input_manifest_sha256",
    }
    if (
        not isinstance(registered_run_identity, Mapping)
        or set(registered_run_identity) != required_run_identity
    ):
        raise ValueError("registered development run identity schema drift")
    normalized_run_identity = dict(registered_run_identity)
    for name in ("registry_path", "input_root_path", "input_manifest_path"):
        if not isinstance(normalized_run_identity[name], str) or not normalized_run_identity[name]:
            raise ValueError("registered development path identity is invalid")
    for name in ("registry_sha256", "input_manifest_sha256"):
        digest = normalized_run_identity[name]
        if (
            not isinstance(digest, str)
            or len(digest) != 64
            or any(character not in "0123456789abcdef" for character in digest)
        ):
            raise ValueError("registered development document SHA-256 is invalid")
    if (
        len(frozen_artifact_identities) != 3
        or sorted(int(row.get("seed", -1)) for row in frozen_artifact_identities)
        != list(SEEDS)
    ):
        raise ValueError("three frozen seed artifact identities are required")
    normalized_artifact_identities = []
    seen_artifact_paths = set()
    for row in sorted(frozen_artifact_identities, key=lambda value: int(value["seed"])):
        required_identity = {
            "seed",
            "base_checkpoint_path",
            "base_checkpoint_sha256",
            "observation_head_path",
            "observation_head_sha256",
            "filter_checkpoint_path",
            "filter_checkpoint_sha256",
            "filter_completion_manifest_sha256",
            "observation_head_design_diagnostic",
        }
        if not isinstance(row, Mapping) or set(row) != required_identity:
            raise ValueError("frozen artifact identity schema drift")
        normalized_row = dict(row)
        for path_name in (
            "base_checkpoint_path",
            "observation_head_path",
            "filter_checkpoint_path",
        ):
            path = normalized_row[path_name]
            if not isinstance(path, str) or not path or path in seen_artifact_paths:
                raise ValueError("frozen artifact path is invalid or duplicated")
            seen_artifact_paths.add(path)
        for hash_name in (
            "base_checkpoint_sha256",
            "observation_head_sha256",
            "filter_checkpoint_sha256",
            "filter_completion_manifest_sha256",
        ):
            digest = normalized_row[hash_name]
            if (
                not isinstance(digest, str)
                or len(digest) != 64
                or any(character not in "0123456789abcdef" for character in digest)
            ):
                raise ValueError("frozen artifact SHA-256 is invalid")
        normalized_artifact_identities.append(normalized_row)
    design_diagnostics = _validated_observation_head_design_diagnostics(
        [
            row["observation_head_design_diagnostic"]
            for row in normalized_artifact_identities
        ]
    )
    report_paths = [row["selection_report_path"] for row in design_diagnostics]
    if len(set(report_paths)) != 3 or any(
        path in seen_artifact_paths for path in report_paths
    ):
        raise ValueError("observation-head selection report path is duplicated")
    access_marker: Optional[Dict[str, Any]] = None
    if not synthetic_test_mode:
        access_marker = _validated_development_access_marker(
            _read_json_mapping(partial / DEVELOPMENT_ACCESS_MARKER_NAME),
            partial_directory=partial,
            registered_run_identity=normalized_run_identity,
            frozen_artifact_identities=normalized_artifact_identities,
        )
    qualification = build_base_observation_head_qualification(
        base_qualification_rows,
        observation_head_qualification_rows,
        design_diagnostics,
    )
    if base_observation_head_qualification is not None and bool(
        base_observation_head_qualification.get("passed")
    ) != bool(qualification["passed"]):
        raise ValueError(
            "declared qualification disagrees with sufficient statistics"
        )
    lead_metrics = summarize_source_target_leads(future_rows)
    if len(lead_metrics) != grid["source_target_lead_summary_rows"]:
        raise RuntimeError("source-target-lead summary count differs from 1,656")
    window_metrics = summarize_source_target_windows(future_rows)
    matrices = build_directional_matrices(window_metrics)
    bootstrap = bootstrap_crossed_seed_calendar_blocks(
        future_rows, repeat_count=repeat_count, random_seed=random_seed
    )
    forecast_decision = decide_forecast_direction_gates(window_metrics, bootstrap)
    observation_summary = _observation_summary(
        observation_rows, repeat_count=repeat_count, random_seed=random_seed
    )
    target_summary = _analysis_target_summary(target_rows)
    state_summary = _state_summary(state_rows)
    identity_pass = bool(identity_gate_details) and all(
        bool(value) for value in identity_gate_details.values()
    )
    qualification_pass = bool(qualification["passed"])
    observation_pass = all(row["pass"] for row in observation_summary)
    self_forecast_pass = bool(forecast_decision["self_forecast_gate_pass"])
    cross_station_pass = bool(forecast_decision["cross_station_gate_pass"])
    forecast_pass = bool(forecast_decision["forecast_gate_pass"])
    if not identity_pass:
        overall_status = "invalid_identity_or_target_access_stop"
    elif not qualification_pass:
        overall_status = "base_or_observation_head_qualification_fail"
    elif not observation_pass:
        overall_status = "analysis_update_principle_fail"
    else:
        overall_status = forecast_decision["status"]
    decision = {
        "schema_version": "1.0",
        "status": overall_status,
        "identity_gate_details": dict(identity_gate_details),
        "identity_gate_pass": identity_pass,
        "base_observation_head_qualification_pass": qualification_pass,
        "analysis_observation_update_pass": observation_pass,
        "self_forecast_gate_pass": self_forecast_pass,
        "cross_station_gate_pass": cross_station_pass,
        "cross_station_status": forecast_decision["cross_station_status"],
        "forecast_direction_gate_pass": forecast_pass,
        "dependency_perturbation_evidence_recorded": True,
        "forecast_direction_decision": forecast_decision,
        "practical_magnitude_gate": "not_frozen",
    }
    base_branch_rows = [
        row
        for row in window_metrics
        if row["scope"] == "pooled_three_seeds"
    ]
    movement_rows = [
        {
            "source_index": row["source_index"],
            "source_station": row["source_station"],
            "target_index": row["target_index"],
            "target_station": row["target_station"],
            "forecast_movement_m": row["forecast_movement_m"],
            "forecast_movement_mm": 1000.0 * row["forecast_movement_m"],
            "measurement_update_gain_m": row["measurement_update_gain_m"],
        }
        for row in matrices["full_six_by_four"]
    ]

    if synthetic_test_mode:
        partial.mkdir(parents=True, exist_ok=False)
    _write_csv(partial / SUFFICIENT_FILE_NAMES[0], future_rows)
    _write_csv(partial / SUFFICIENT_FILE_NAMES[1], observation_rows)
    _write_csv(partial / SUFFICIENT_FILE_NAMES[2], target_rows)
    _write_csv(partial / SUFFICIENT_FILE_NAMES[3], state_rows)
    _write_csv(partial / SUFFICIENT_FILE_NAMES[4], base_qualification_rows)
    _write_csv(
        partial / SUFFICIENT_FILE_NAMES[5],
        observation_head_qualification_rows,
    )
    _write_json(
        partial / "base_observation_head_qualification.json",
        qualification,
    )
    np.savez(
        partial / "observation_dependency_perturbation_evidence.npz",
        schema_version=np.asarray("1.0"),
        space=np.asarray("realtime_observation_normalized"),
        perturbation_delta_normalized=np.asarray(
            DEPENDENCY_PERTURBATION_DELTA_NORMALIZED, dtype=np.float64
        ),
        sample_identity_sha256=np.asarray(
            dependency_evidence["sample_identity_sha256"]
        ),
        original_observation_normalized=dependency_evidence[
            "original_observation_normalized"
        ],
        perturbed_observation_normalized=dependency_evidence[
            "perturbed_observation_normalized"
        ],
        original_posterior_observation_normalized=dependency_evidence[
            "original_posterior_observation_normalized"
        ],
        perturbed_posterior_observation_normalized=dependency_evidence[
            "perturbed_posterior_observation_normalized"
        ],
    )
    _write_csv(partial / "base_and_three_branch_forecast_metrics.csv", base_branch_rows)
    _write_csv(partial / "source_target_lead_metrics.csv", lead_metrics)
    _write_csv(partial / "source_target_window_metrics.csv", window_metrics)
    _write_csv(
        partial / "six_source_four_target_gain_matrix.csv",
        matrices["full_six_by_four"],
    )
    _write_csv(
        partial / "internal_four_by_four_gain_matrix.csv",
        matrices["internal_four_by_four"],
    )
    _write_csv(
        partial / "boundary_to_internal_gain_matrix.csv",
        matrices["boundary_two_by_four"],
    )
    _write_csv(
        partial / "analysis_realtime_observation_diagnostics.csv",
        observation_summary,
    )
    _write_csv(partial / "analysis_target_space_gain_matrix.csv", target_summary)
    _write_csv(partial / "forecast_movement_matrix.csv", movement_rows)
    _write_csv(
        partial / "reciprocal_direction_summary.csv",
        _reciprocal_summary(matrices["full_six_by_four"]),
    )
    _write_json(partial / "bootstrap_summary.json", bootstrap)
    _write_json(partial / "development_gate_decision.json", decision)
    _write_json(partial / "sufficient_grid_identity.json", grid)
    # State diagnostics are necessary evidence even though they are not a
    # paper-facing matrix.
    _write_csv(partial / "state_difference_diagnostics.csv", state_summary)
    artifacts = []
    for path in sorted(partial.iterdir(), key=lambda value: value.name):
        artifacts.append(
            {
                "name": path.name,
                "byte_count": path.stat().st_size,
                "sha256": _sha256(path),
            }
        )
    _write_json(
        partial / "completion_manifest.json",
        {
            "schema_version": "1.0",
            "status": "completed_development_evaluation",
            "experiment_id": next(iter(experiment_ids)),
            "file_count_excluding_manifest": len(artifacts),
            "files": artifacts,
            "real_target_loader_present": not synthetic_test_mode,
            "development_loader_call_count": 0 if synthetic_test_mode else 1,
            "development_dataset_instance_count": 0 if synthetic_test_mode else 1,
            "seed_evaluation_count": 3,
            "development_access_started_before_loader": not synthetic_test_mode,
            "development_access_marker_sha256": (
                _sha256(partial / DEVELOPMENT_ACCESS_MARKER_NAME)
                if access_marker is not None
                else None
            ),
            "development_access_started_at_utc": (
                access_marker["claimed_at_utc"]
                if access_marker is not None
                else None
            ),
            "dependency_evidence_contains_target_values": False,
            "development_data_access_audit": normalized_access_audit,
            "frozen_artifact_identities": normalized_artifact_identities,
            "registered_run_identity": normalized_run_identity,
            "synthetic_test_mode": synthetic_test_mode,
            "held_out_2024_target_access_count": 0,
            "boundary_future_target_access_count": 0,
        },
    )
    partial.rename(output_directory)
    return output_directory


def _synthetic_smoke_batch(seed: int, origins: Sequence[str]) -> Mapping[str, Any]:
    count = len(origins)
    origin_axis = np.arange(count, dtype=np.float64)[:, None, None] * 0.01
    truth = (
        1.0
        + origin_axis
        + np.arange(23, dtype=np.float64)[None, :, None] * 0.1
        + np.arange(4, dtype=np.float64)[None, None, :] * 0.1
    )
    analysis_truth = truth[:, 0, :]
    observation = (
        np.arange(count, dtype=np.float64)[:, None] * 0.01
        + np.arange(6, dtype=np.float64)[None, :] * 0.1
    )
    posterior_observation = np.repeat(
        (observation + 0.10)[:, None, :], 6, axis=1
    )
    for source in range(6):
        posterior_observation[:, source, source] = observation[:, source] + 0.05
    updated_state = np.empty((count, 6, 23, 32), dtype=np.float64)
    for source in range(6):
        updated_state[:, source] = 0.001 * (source + 1)
    return accumulate_development_sufficient_statistics(
        experiment_id="synthetic_development_evaluation_smoke",
        seed=seed,
        origin_times=origins,
        target_future_m=truth,
        analysis_target_m=analysis_truth,
        analysis_observation_m=observation,
        current_stage_m=observation + 0.20,
        base_issue_hour_one_forecast_m=analysis_truth + 0.11,
        base_deterministic_forecast_m=truth + 0.11,
        unscented_prior_forecast_m=truth + 0.10,
        updated_forecast_m=np.repeat((truth + 0.08)[:, None], 6, axis=1),
        analysis_prior_target_m=analysis_truth + 0.10,
        analysis_posterior_target_m=np.repeat(
            (analysis_truth + 0.08)[:, None], 6, axis=1
        ),
        analysis_prior_observation_m=observation + 0.10,
        analysis_posterior_observation_m=posterior_observation,
        analysis_kalman_gain=np.ones((count, 6, 32), dtype=np.float64) * 0.01,
        analysis_observation_contraction=np.ones((count, 6), dtype=np.float64)
        * 0.5,
        analysis_posterior_observation_variance_normalized=np.ones(
            (count, 6), dtype=np.float64
        )
        * 0.002,
        analysis_posterior_minimum_eigenvalue=np.ones(
            (count, 6), dtype=np.float64
        )
        * 0.001,
        analysis_spectral_floor=np.ones((count, 6), dtype=np.float64) * 1e-12,
        observation_noise_standard_deviation_normalized=np.ones(
            6, dtype=np.float64
        )
        * 0.1,
        unscented_prior_state_mean=np.zeros((count, 23, 32), dtype=np.float64),
        updated_state_mean=updated_state,
    )


def run_synthetic_development_evaluation_smoke(
    *, registry_path: str | Path, output_directory: str | Path
) -> Mapping[str, Any]:
    """Exercise batch merging and exact grids without opening any real data."""

    project_root = Path(__file__).resolve().parents[2]
    modeling_directory = project_root / "scripts" / "modeling"
    if str(modeling_directory) not in sys.path:
        sys.path.insert(0, str(modeling_directory))
    from zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_runner_v1 import (  # noqa: E501,WPS433
        load_registered_post_training_task,
        verify_output_directory,
    )

    _registry, task = load_registered_post_training_task(
        registry_path, stage="development_2023_evaluation"
    )
    output = Path(output_directory).resolve()
    if output != Path(task.get("registered_smoke_path", "")).resolve():
        raise ValueError("synthetic smoke output differs from its registered path")
    partial = output.with_name(output.name + ".partial")
    if output.exists() or partial.exists():
        raise FileExistsError("synthetic smoke output or partial already exists")
    first = ("2023-01-01T00:00:00+08:00", "2023-01-02T00:00:00+08:00")
    second = ("2023-01-15T00:00:00+08:00", "2023-01-16T00:00:00+08:00")
    statistics = [
        combine_seed_sufficient_statistics(
            [_synthetic_smoke_batch(seed, first), _synthetic_smoke_batch(seed, second)]
        )
        for seed in SEEDS
    ]
    grid = verify_sufficient_grid(
        [row for item in statistics for row in item["future_rows"]],
        [row for item in statistics for row in item["analysis_observation_rows"]],
        [row for item in statistics for row in item["analysis_target_rows"]],
        [row for item in statistics for row in item["state_difference_rows"]],
        [row for item in statistics for row in item["base_qualification_rows"]],
        [
            row
            for item in statistics
            for row in item["observation_head_qualification_rows"]
        ],
    )
    partial.mkdir(parents=True, exist_ok=False)
    report_path = partial / "report.json"
    _write_json(
        report_path,
        {
            "schema_version": 1,
            "execution_mode": "synthetic_smoke",
            "status": "technical_pass_development_evaluation_smoke",
            "real_data_opened": False,
            "formal_output_created": False,
            "seed_count": 3,
            "nonempty_calendar_block_count": grid["nonempty_block_count"],
            "source_target_lead_summary_rows": grid[
                "source_target_lead_summary_rows"
            ],
        },
    )
    _write_json(
        partial / "completion_manifest.json",
        {
            "schema_version": 1,
            "experiment_family": FORMAL_EXPERIMENT_FAMILY,
            "status": "technical_pass_development_evaluation_smoke",
            "verified_artifact_count": 1,
            "files": [
                {
                    "path": report_path.name,
                    "byte_count": report_path.stat().st_size,
                    "sha256": _sha256(report_path),
                }
            ],
        },
    )
    verification = verify_output_directory(partial)
    partial.rename(output)
    return {
        **verification,
        "output_directory": str(output),
        "real_data_opened": False,
        "formal_output_created": False,
    }


def execute_frozen_2023_development_evaluation_once(
    *,
    registry_path: str | Path,
    input_root: str | Path,
    tide_model_path: str | Path,
    output_directory: str | Path,
    audit_directory: str | Path,
    device: str | torch.device,
    confirmation: str,
    batch_size: int = 32,
) -> Mapping[str, Any]:
    """Verify nine artifacts, open 2023 once, evaluate three seeds, and audit."""

    if confirmation != FORMAL_CONFIRMATION:
        raise PermissionError("formal 2023 development confirmation differs")
    project_root = Path(__file__).resolve().parents[2]
    modeling_directory = project_root / "scripts" / "modeling"
    if str(modeling_directory) not in sys.path:
        sys.path.insert(0, str(modeling_directory))
    from zhenjiang_six_source_four_target_data_v1 import (  # noqa: WPS433
        assert_forbidden_target_access_is_zero,
        build_split_datasets,
        load_development_data,
    )
    from zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_runner_v1 import (  # noqa: E501,WPS433
        load_registered_frozen_filter_for_evaluation,
        load_registered_post_training_task,
        validate_registry_document,
        verify_isolated_input_manifest,
        verify_output_directory,
    )

    registry_path = Path(registry_path).resolve()
    registry = _read_json_mapping(registry_path)
    validate_registry_document(registry)
    authorization = registry.get("authorization")
    if (
        not isinstance(authorization, Mapping)
        or authorization.get("development_2023_evaluation_authorized") is not True
        or authorization.get("heldout_2024_target_access_authorized") is not False
        or authorization.get("formal_command_confirmation") != FORMAL_CONFIRMATION
    ):
        raise PermissionError("registry does not authorize only the 2023 development gate")
    hpc = registry.get("hpc")
    if not isinstance(hpc, Mapping):
        raise ValueError("registry high-performance-computing path contract is missing")
    remote_root = Path(hpc.get("remote_root", "")).resolve()
    input_root = Path(input_root).resolve()
    if input_root != Path(hpc.get("isolated_input_root", "")).resolve():
        raise ValueError("development input root differs from the registered isolated root")
    tide_model_path = Path(tide_model_path).resolve()
    if tide_model_path != Path(hpc.get("tide_model_path", "")).resolve():
        raise ValueError("astronomical tide model path differs from registry")
    output, audit = _require_new_output_paths(
        Path(output_directory), Path(audit_directory), remote_root
    )
    _evaluation_registry, evaluation_task = load_registered_post_training_task(
        registry_path, stage="development_2023_evaluation"
    )
    _audit_registry, audit_task = load_registered_post_training_task(
        registry_path, stage="independent_audit"
    )
    if (
        Path(evaluation_task.get("registered_output_path", "")).resolve()
        != output
        or Path(audit_task.get("registered_output_path", "")).resolve()
        != audit
        or Path(
            audit_task.get("registered_evaluation_output_path", "")
        ).resolve()
        != output
    ):
        raise ValueError("registered post-training output path drift")
    smoke_path = Path(evaluation_task.get("registered_smoke_path", "")).resolve()
    smoke_verification = verify_output_directory(smoke_path)
    if smoke_verification.get("status") != (
        "technical_pass_development_evaluation_smoke"
    ):
        raise RuntimeError("registered development-evaluation smoke did not pass")
    input_identity = verify_isolated_input_manifest(input_root, registry)

    torch_device = torch.device(device)
    frozen_models: Dict[int, Any] = {}
    artifact_identities: List[Dict[str, Any]] = []
    base_normalization: Optional[Mapping[str, Any]] = None
    artifact_paths = set()
    for seed in SEEDS:
        base_path, head_path, filter_path = _registered_artifact_paths(
            registry, seed
        )
        for path in (base_path, head_path, filter_path):
            if not path.is_file() or str(path) in artifact_paths:
                raise FileNotFoundError("frozen artifact is absent or duplicated")
            artifact_paths.add(str(path))
        model, identities = load_registered_frozen_filter_for_evaluation(
            registry_path, seed=seed, device=torch_device
        )
        normalization = identities.get("base_normalization")
        if not isinstance(normalization, Mapping):
            raise ValueError("base checkpoint normalization identity is missing")
        if base_normalization is None:
            base_normalization = normalization
        elif base_normalization != normalization:
            raise ValueError("three base normalization identities differ")
        if (
            Path(identities.get("filter_checkpoint_path", "")).resolve()
            != filter_path
            or identities.get("base_checkpoint_sha256") != _sha256(base_path)
            or identities.get("observation_head_sha256") != _sha256(head_path)
            or identities.get("normalization_sha256")
            != _mapping_sha256(normalization)
        ):
            raise ValueError("registered evaluation artifact identity drift")
        frozen_models[seed] = model
        artifact_identities.append(
            {
                "seed": seed,
                "base_checkpoint_path": str(base_path),
                "base_checkpoint_sha256": _sha256(base_path),
                "observation_head_path": str(head_path),
                "observation_head_sha256": _sha256(head_path),
                "filter_checkpoint_path": str(filter_path),
                "filter_checkpoint_sha256": identities[
                    "filter_checkpoint_sha256"
                ],
                "filter_completion_manifest_sha256": identities[
                    "filter_completion_manifest_sha256"
                ],
                "observation_head_design_diagnostic": (
                    _read_observation_head_design_diagnostic(
                        head_path, seed=seed
                    )
                ),
            }
        )
    if len(artifact_paths) != 9 or base_normalization is None:
        raise RuntimeError("nine unique frozen artifacts were not established")

    registered_run_identity = {
        "registry_path": str(registry_path),
        "registry_sha256": _sha256(registry_path),
        "input_root_path": str(input_root),
        "input_manifest_path": input_identity["manifest_path"],
        "input_manifest_sha256": input_identity["manifest_sha256"],
    }
    _claim_development_access_before_loader(
        output.with_name(output.name + ".partial"),
        registered_run_identity=registered_run_identity,
        frozen_artifact_identities=artifact_identities,
    )

    # This is the only call that can open the frozen 2023 development target.
    data = load_development_data(input_root, tide_model_path)
    assert_forbidden_target_access_is_zero(data.access_audit)
    normalized_access = _validated_data_access_audit(asdict(data.access_audit))
    if _normalization_document(data.normalization) != base_normalization:
        raise ValueError("loaded development normalization differs from all bases")
    datasets = build_split_datasets(data)
    if set(datasets) != {"training", "selection", "development_gate"}:
        raise ValueError("development split dictionary identity drift")
    development_dataset = datasets["development_gate"]
    if len(development_dataset) < 1:
        raise RuntimeError("frozen 2023 development dataset is empty")
    statistics, dependency_evidence = materialize_shared_development_statistics(
        data=data,
        development_dataset=development_dataset,
        frozen_models=frozen_models,
        device=torch_device,
        batch_size=batch_size,
    )
    write_development_evaluation(
        output,
        statistics,
        identity_gate_details={
            "registry_authorizes_2023_only": True,
            "nine_frozen_artifacts_verified_before_data": True,
            "three_base_normalization_identities_match": True,
            "development_loader_called_once": True,
            "one_shared_development_dataset_for_three_seeds": True,
            "exact_frozen_data_access_audit": True,
            "held_out_2024_target_access_is_zero": True,
            "boundary_future_target_access_is_zero": True,
        },
        dependency_perturbation_evidence=dependency_evidence,
        data_access_audit=normalized_access,
        frozen_artifact_identities=artifact_identities,
        registered_run_identity=registered_run_identity,
        repeat_count=BOOTSTRAP_REPEAT_COUNT,
        random_seed=BOOTSTRAP_RANDOM_SEED,
        synthetic_test_mode=False,
    )
    from audit_zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1 import (  # noqa: E501,WPS433
        write_independent_audit,
    )

    audit_report = write_independent_audit(output, audit)
    return {
        "status": "completed_2023_development_evaluation_and_independent_audit",
        "development_loader_call_count": 1,
        "development_dataset_instance_count": 1,
        "seed_evaluation_count": 3,
        "evaluation_directory": str(output),
        "independent_audit_report": str(audit_report),
    }


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--execution-mode",
        choices=("synthetic_smoke", "formal_2023_once"),
        required=True,
    )
    parser.add_argument("--registry", type=Path, required=True)
    parser.add_argument("--input-root", type=Path)
    parser.add_argument("--tide-model-path", type=Path)
    parser.add_argument("--output-directory", type=Path, required=True)
    parser.add_argument("--audit-directory", type=Path)
    parser.add_argument("--device")
    parser.add_argument("--confirmation")
    parser.add_argument("--batch-size", type=int, default=32)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    arguments = _build_parser().parse_args(argv)
    if arguments.execution_mode == "synthetic_smoke":
        result = run_synthetic_development_evaluation_smoke(
            registry_path=arguments.registry,
            output_directory=arguments.output_directory,
        )
    else:
        required = {
            "input_root": arguments.input_root,
            "tide_model_path": arguments.tide_model_path,
            "audit_directory": arguments.audit_directory,
            "device": arguments.device,
            "confirmation": arguments.confirmation,
        }
        if any(value is None for value in required.values()):
            raise ValueError("formal_2023_once requires all formal paths and confirmation")
        result = execute_frozen_2023_development_evaluation_once(
            registry_path=arguments.registry,
            input_root=arguments.input_root,
            tide_model_path=arguments.tide_model_path,
            output_directory=arguments.output_directory,
            audit_directory=arguments.audit_directory,
            device=arguments.device,
            confirmation=arguments.confirmation,
            batch_size=arguments.batch_size,
        )
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


__all__ = [
    "ANALYSIS_OBSERVATION_FIELDS",
    "ANALYSIS_TARGET_FIELDS",
    "BASE_QUALIFICATION_FIELDS",
    "DEPENDENCY_PERTURBATION_DELTA_NORMALIZED",
    "OBSERVATION_HEAD_QUALIFICATION_FIELDS",
    "STATE_DIFFERENCE_FIELDS",
    "accumulate_development_sufficient_statistics",
    "build_base_observation_head_qualification",
    "combine_seed_sufficient_statistics",
    "execute_frozen_2023_development_evaluation_once",
    "materialize_shared_development_statistics",
    "run_synthetic_development_evaluation_smoke",
    "verify_sufficient_grid",
    "write_development_evaluation",
]


if __name__ == "__main__":
    raise SystemExit(main())
