#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pure metrics for six directed observation sources and four forecast targets.

Only block-level sufficient statistics enter this module.  It has no model,
water-level loader, checkpoint loader, or output-directory side effect.

Example:
    python -m pytest -q -p no:cacheprovider \
      tests/test_zhenjiang_six_source_four_target_d32_gru_ukf_metrics_v1.py
"""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta, timezone
import json
import math
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np


SOURCE_STATIONS = (
    "datong",
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
TARGET_STATIONS = ("nanjing", "zhenjiang", "jiangyin", "xuliujing")
SEEDS = (17, 29, 43)
ISSUE_HORIZON_HOURS = tuple(range(2, 25))
POST_UPDATE_LEAD_HOURS = tuple(range(1, 24))
WINDOWS = {
    "post_update_1_to_6": tuple(range(1, 7)),
    "post_update_1_to_12": tuple(range(1, 13)),
    "post_update_1_to_23": tuple(range(1, 24)),
}
BOOTSTRAP_REPEAT_COUNT = 20_000
BOOTSTRAP_RANDOM_SEED = 20_260_901
BEIJING_TIMEZONE = timezone(timedelta(hours=8))
DEVELOPMENT_ANCHOR = datetime(2023, 1, 1, tzinfo=BEIJING_TIMEZONE)

# Eight preregistered directions.  The tuple is (source index, target index).
ADJACENT_DIRECTIONS = (
    (0, 0),  # Datong -> Nanjing
    (1, 1),  # Nanjing -> Zhenjiang
    (2, 0),  # Zhenjiang -> Nanjing
    (2, 2),  # Zhenjiang -> Jiangyin
    (3, 1),  # Jiangyin -> Zhenjiang
    (3, 3),  # Jiangyin -> Xuliujing
    (4, 2),  # Xuliujing -> Jiangyin
    (5, 3),  # Wusongkou -> Xuliujing
)

FUTURE_SUFFICIENT_FIELDS = (
    "schema_version",
    "experiment_id",
    "seed",
    "block_id",
    "block_origin_count",
    "source_index",
    "source_station",
    "target_index",
    "target_station",
    "issue_horizon_hour",
    "post_update_lead_hour",
    "cell_count",
    "base_absolute_error_sum_m",
    "prior_absolute_error_sum_m",
    "updated_absolute_error_sum_m",
    "base_squared_error_sum_m2",
    "prior_squared_error_sum_m2",
    "updated_squared_error_sum_m2",
    "updated_minus_prior_absolute_movement_sum_m",
    "target_sum_m",
    "target_squared_sum_m2",
)


def is_self_cell(source_index: int, target_index: int) -> bool:
    """Return whether an internal source observes its same named target."""

    return source_index in range(1, 5) and target_index == source_index - 1


def is_boundary_cell(source_index: int) -> bool:
    """Return whether the row is a boundary observation source."""

    return source_index in (0, 5)


def _as_int(value: Any, name: str) -> int:
    if isinstance(value, bool):
        raise ValueError("%s must be an integer" % name)
    try:
        result = int(value)
    except (TypeError, ValueError) as error:
        raise ValueError("%s must be an integer" % name) from error
    if isinstance(value, float) and value != result:
        raise ValueError("%s must be an integer" % name)
    if isinstance(value, str) and value.strip() != str(result):
        raise ValueError("%s must use canonical integer text" % name)
    return result


def _as_float(value: Any, name: str) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError("%s must be numeric" % name) from error
    if not math.isfinite(result):
        raise ValueError("%s must be finite" % name)
    return result


def _parse_beijing_time(value: Any) -> datetime:
    if isinstance(value, np.datetime64):
        if np.isnat(value):
            raise ValueError("origin time is NaT")
        microseconds = value.astype("datetime64[us]").astype(np.int64)
        parsed = datetime(1970, 1, 1) + timedelta(microseconds=int(microseconds))
    elif isinstance(value, datetime):
        parsed = value
    elif isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError as error:
            raise ValueError("origin time is not ISO-8601") from error
    else:
        raise ValueError("origin time must be datetime, datetime64, or ISO text")
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=BEIJING_TIMEZONE)
    else:
        parsed = parsed.astimezone(BEIJING_TIMEZONE)
    return parsed


def calendar_seven_day_block(origin_time: Any) -> int:
    """Assign one 2023 issue time to its Beijing-calendar seven-day block."""

    parsed = _parse_beijing_time(origin_time)
    if parsed.year != 2023:
        raise ValueError("development origin time must be in calendar year 2023")
    elapsed = parsed - DEVELOPMENT_ANCHOR
    block = elapsed.days // 7
    if block < 0:
        raise ValueError("development block identifier must be nonnegative")
    return block


def assign_calendar_seven_day_blocks(
    origin_times: Sequence[Any],
) -> Tuple[np.ndarray, Tuple[int, ...]]:
    """Return per-origin block identifiers and all nonempty blocks."""

    if len(origin_times) < 1:
        raise ValueError("origin_times must not be empty")
    identifiers = np.asarray(
        [calendar_seven_day_block(value) for value in origin_times],
        dtype=np.int64,
    )
    return identifiers, tuple(int(value) for value in np.unique(identifiers))


def validate_horizon_pair(issue_horizon_hour: Any, post_update_lead_hour: Any) -> None:
    """Reject comparisons that do not align t+2:t+24 across all branches."""

    issue = _as_int(issue_horizon_hour, "issue_horizon_hour")
    lead = _as_int(post_update_lead_hour, "post_update_lead_hour")
    if issue not in ISSUE_HORIZON_HOURS or lead not in POST_UPDATE_LEAD_HOURS:
        raise ValueError("forecast horizon is outside the frozen range")
    if issue != lead + 1:
        raise ValueError("issue horizon and post-update lead are misaligned")


def _normalize_future_row(row: Mapping[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, Mapping) or set(row) != set(FUTURE_SUFFICIENT_FIELDS):
        raise ValueError("future sufficient-statistic schema drift")
    result = dict(row)
    if result["schema_version"] != "1.0":
        raise ValueError("future sufficient-statistic version drift")
    if not isinstance(result["experiment_id"], str) or not result["experiment_id"]:
        raise ValueError("experiment identity is invalid")
    for name in (
        "seed",
        "block_id",
        "block_origin_count",
        "source_index",
        "target_index",
        "issue_horizon_hour",
        "post_update_lead_hour",
        "cell_count",
    ):
        result[name] = _as_int(result[name], name)
    for name in FUTURE_SUFFICIENT_FIELDS[12:]:
        result[name] = _as_float(result[name], name)
    if result["seed"] not in SEEDS:
        raise ValueError("seed is outside the frozen set")
    source = result["source_index"]
    target = result["target_index"]
    if source not in range(6) or target not in range(4):
        raise ValueError("source or target index is outside the frozen set")
    if result["source_station"] != SOURCE_STATIONS[source]:
        raise ValueError("source station does not match source index")
    if result["target_station"] != TARGET_STATIONS[target]:
        raise ValueError("target station does not match target index")
    validate_horizon_pair(
        result["issue_horizon_hour"], result["post_update_lead_hour"]
    )
    if result["block_id"] < 0 or result["block_origin_count"] < 1:
        raise ValueError("block identity or origin count is invalid")
    if result["cell_count"] != result["block_origin_count"]:
        raise ValueError("one row must contain one cell per block origin")
    nonnegative = (
        "base_absolute_error_sum_m",
        "prior_absolute_error_sum_m",
        "updated_absolute_error_sum_m",
        "base_squared_error_sum_m2",
        "prior_squared_error_sum_m2",
        "updated_squared_error_sum_m2",
        "updated_minus_prior_absolute_movement_sum_m",
        "target_squared_sum_m2",
    )
    if any(result[name] < 0.0 for name in nonnegative):
        raise ValueError("nonnegative future statistic is negative")
    minimum_square = result["target_sum_m"] ** 2 / result["cell_count"]
    tolerance = 1e-10 * max(1.0, result["target_squared_sum_m2"])
    if result["target_squared_sum_m2"] + tolerance < minimum_square:
        raise ValueError("target sums violate the Cauchy inequality")
    return result


def validate_future_sufficient_rows(
    rows: Iterable[Mapping[str, Any]],
) -> List[Dict[str, Any]]:
    """Strictly validate types, directions, horizons, and unique row keys."""

    normalized = []
    seen = set()
    for source_row in rows:
        row = _normalize_future_row(source_row)
        key = (
            row["experiment_id"],
            row["seed"],
            row["block_id"],
            row["source_index"],
            row["target_index"],
            row["post_update_lead_hour"],
        )
        if key in seen:
            raise ValueError("duplicate future sufficient-statistic row")
        seen.add(key)
        normalized.append(row)
    if not normalized:
        raise ValueError("future sufficient-statistic rows must not be empty")
    return normalized


def gain_from_mean_absolute_errors(
    reference_mae_m: float, candidate_mae_m: float
) -> Dict[str, Any]:
    """Return absolute and relative gain after aggregating reference errors."""

    reference = _as_float(reference_mae_m, "reference_mae_m")
    candidate = _as_float(candidate_mae_m, "candidate_mae_m")
    if reference < 0.0 or candidate < 0.0:
        raise ValueError("mean absolute errors must be nonnegative")
    gain_m = reference - candidate
    if reference == 0.0:
        relative = None
        status = "undefined_zero_baseline"
    else:
        relative = 100.0 * gain_m / reference
        status = "defined"
    return {
        "absolute_gain_m": gain_m,
        "absolute_gain_mm": 1000.0 * gain_m,
        "relative_gain_percent": relative,
        "relative_gain_status": status,
    }


def _metrics_from_rows(rows: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    if not rows:
        raise ValueError("metric group must not be empty")
    cells = sum(int(row["cell_count"]) for row in rows)
    if cells <= 0:
        raise ValueError("metric group contains no cells")
    target_sum = sum(float(row["target_sum_m"]) for row in rows)
    target_squared_sum = sum(
        float(row["target_squared_sum_m2"]) for row in rows
    )
    target_sst = target_squared_sum - target_sum**2 / cells
    tolerance = 1e-10 * max(1.0, target_squared_sum)
    if target_sst < -tolerance:
        raise ValueError("aggregated target variance is negative")
    target_sst = max(0.0, target_sst)
    result: Dict[str, Any] = {
        "cell_count": cells,
        "target_sum_m": target_sum,
        "target_squared_sum_m2": target_squared_sum,
        "target_sst_m2": target_sst,
        "forecast_movement_m": sum(
            float(row["updated_minus_prior_absolute_movement_sum_m"])
            for row in rows
        )
        / cells,
    }
    for branch in ("base", "prior", "updated"):
        absolute_sum = sum(
            float(row[branch + "_absolute_error_sum_m"]) for row in rows
        )
        squared_sum = sum(
            float(row[branch + "_squared_error_sum_m2"]) for row in rows
        )
        result[branch + "_absolute_error_sum_m"] = absolute_sum
        result[branch + "_squared_error_sum_m2"] = squared_sum
        result[branch + "_mae_m"] = absolute_sum / cells
        result[branch + "_rmse_m"] = math.sqrt(squared_sum / cells)
        result[branch + "_nse"] = (
            1.0 - squared_sum / target_sst if target_sst > 0.0 else None
        )
    covariance_gain = gain_from_mean_absolute_errors(
        result["base_mae_m"], result["prior_mae_m"]
    )
    measurement_gain = gain_from_mean_absolute_errors(
        result["prior_mae_m"], result["updated_mae_m"]
    )
    total_gain = gain_from_mean_absolute_errors(
        result["base_mae_m"], result["updated_mae_m"]
    )
    result.update(
        {
            "covariance_propagation_gain_m": covariance_gain["absolute_gain_m"],
            "covariance_propagation_gain_mm": covariance_gain["absolute_gain_mm"],
            "measurement_update_gain_m": measurement_gain["absolute_gain_m"],
            "measurement_update_gain_mm": measurement_gain["absolute_gain_mm"],
            "measurement_update_relative_gain_percent": measurement_gain[
                "relative_gain_percent"
            ],
            "measurement_update_relative_gain_status": measurement_gain[
                "relative_gain_status"
            ],
            "total_gain_m": total_gain["absolute_gain_m"],
            "total_gain_mm": total_gain["absolute_gain_mm"],
        }
    )
    residual = result["total_gain_m"] - (
        result["covariance_propagation_gain_m"]
        + result["measurement_update_gain_m"]
    )
    if not math.isclose(residual, 0.0, abs_tol=1e-12, rel_tol=1e-10):
        raise RuntimeError("total gain does not equal its two components")
    result["gain_decomposition_residual_m"] = residual
    return result


def _group_rows(
    rows: Sequence[Mapping[str, Any]], names: Sequence[str]
) -> Mapping[Tuple[Any, ...], List[Mapping[str, Any]]]:
    groups: Dict[Tuple[Any, ...], List[Mapping[str, Any]]] = defaultdict(list)
    for row in rows:
        groups[tuple(row[name] for name in names)].append(row)
    return groups


def summarize_source_target_leads(
    rows: Iterable[Mapping[str, Any]],
) -> List[Dict[str, Any]]:
    """Summarize the fixed 3 x 6 x 4 x 23 directional lead grid."""

    normalized = validate_future_sufficient_rows(rows)
    result = []
    groups = _group_rows(
        normalized,
        ("seed", "source_index", "target_index", "post_update_lead_hour"),
    )
    for key, group in sorted(groups.items()):
        seed, source, target, lead = key
        result.append(
            {
                "seed": seed,
                "source_index": source,
                "source_station": SOURCE_STATIONS[source],
                "target_index": target,
                "target_station": TARGET_STATIONS[target],
                "is_self": is_self_cell(source, target),
                "is_boundary_source": is_boundary_cell(source),
                "issue_horizon_hour": lead + 1,
                "post_update_lead_hour": lead,
                **_metrics_from_rows(group),
            }
        )
    return result


def summarize_source_target_windows(
    rows: Iterable[Mapping[str, Any]],
) -> List[Dict[str, Any]]:
    """Summarize per-seed and pooled 6 x 4 directional window metrics."""

    normalized = validate_future_sufficient_rows(rows)
    result: List[Dict[str, Any]] = []
    for scope, seeds in (
        *[("seed_%d" % seed, (seed,)) for seed in SEEDS],
        ("pooled_three_seeds", SEEDS),
    ):
        for source in range(6):
            for target in range(4):
                for window_name, lead_hours in WINDOWS.items():
                    selected = [
                        row
                        for row in normalized
                        if row["seed"] in seeds
                        and row["source_index"] == source
                        and row["target_index"] == target
                        and row["post_update_lead_hour"] in lead_hours
                    ]
                    if not selected:
                        continue
                    result.append(
                        {
                            "scope": scope,
                            "seed": seeds[0] if len(seeds) == 1 else None,
                            "source_index": source,
                            "source_station": SOURCE_STATIONS[source],
                            "target_index": target,
                            "target_station": TARGET_STATIONS[target],
                            "is_self": is_self_cell(source, target),
                            "is_boundary_source": is_boundary_cell(source),
                            "window_name": window_name,
                            "issue_horizon_start": min(lead_hours) + 1,
                            "issue_horizon_end": max(lead_hours) + 1,
                            "post_update_lead_start": min(lead_hours),
                            "post_update_lead_end": max(lead_hours),
                            **_metrics_from_rows(selected),
                        }
                    )
    return result


def build_directional_matrices(
    window_rows: Sequence[Mapping[str, Any]],
    window_name: str = "post_update_1_to_6",
) -> Dict[str, List[Dict[str, Any]]]:
    """Split the pooled full matrix into internal and boundary matrices."""

    selected = [
        dict(row)
        for row in window_rows
        if row.get("scope") == "pooled_three_seeds"
        and row.get("window_name") == window_name
    ]
    keys = {
        (int(row["source_index"]), int(row["target_index"])) for row in selected
    }
    if keys != {(source, target) for source in range(6) for target in range(4)}:
        raise ValueError("pooled six-source/four-target matrix is incomplete")
    full = []
    for row in sorted(
        selected, key=lambda value: (value["source_index"], value["target_index"])
    ):
        source = int(row["source_index"])
        target = int(row["target_index"])
        if source in range(1, 5):
            source_internal_index = source - 1
            if source_internal_index == target:
                triangle = "diagonal_self"
            elif source_internal_index < target:
                triangle = "upper_upstream_source_to_downstream_target"
            else:
                triangle = "lower_downstream_source_to_upstream_target"
        else:
            triangle = "boundary_source"
        row.update(
            {
                "matrix_row": source,
                "matrix_column": target,
                "matrix_part": triangle,
                "is_adjacent_direction": (source, target) in ADJACENT_DIRECTIONS,
            }
        )
        full.append(row)
    return {
        "full_six_by_four": full,
        "internal_four_by_four": [
            row for row in full if row["source_index"] in range(1, 5)
        ],
        "boundary_two_by_four": [
            row for row in full if row["source_index"] in (0, 5)
        ],
        "adjacent_eight": [row for row in full if row["is_adjacent_direction"]],
    }


def holm_adjust_one_sided(
    p_values: Sequence[float], alpha: float = 0.05
) -> Tuple[List[float], List[bool]]:
    """Return Holm adjusted probabilities and step-down decisions."""

    if not p_values:
        raise ValueError("Holm family must not be empty")
    values = [_as_float(value, "p_value") for value in p_values]
    if any(value < 0.0 or value > 1.0 for value in values):
        raise ValueError("probability value is outside zero through one")
    if not math.isfinite(alpha) or alpha <= 0.0 or alpha >= 1.0:
        raise ValueError("alpha must be strictly between zero and one")
    order = sorted(range(len(values)), key=lambda index: (values[index], index))
    adjusted = [0.0] * len(values)
    running = 0.0
    rejected = [False] * len(values)
    continue_rejecting = True
    for rank, original in enumerate(order):
        running = max(running, (len(values) - rank) * values[original])
        adjusted[original] = min(1.0, running)
        threshold = alpha / (len(values) - rank)
        rejected[original] = continue_rejecting and values[original] <= threshold
        if not rejected[original]:
            continue_rejecting = False
    return adjusted, rejected


def _linear_quantiles(values: np.ndarray) -> Tuple[float, float, float]:
    lower_one = float(np.quantile(values, 0.05, method="linear"))
    lower_two, upper_two = np.quantile(
        values, (0.025, 0.975), method="linear"
    )
    return lower_one, float(lower_two), float(upper_two)


def bootstrap_crossed_seed_calendar_blocks(
    rows: Iterable[Mapping[str, Any]],
    *,
    repeat_count: int = BOOTSTRAP_REPEAT_COUNT,
    random_seed: int = BOOTSTRAP_RANDOM_SEED,
) -> Dict[str, Any]:
    """Run the crossed seed-by-calendar-block paired bootstrap.

    The same seed and block draws are shared across all 24 directions, all six
    leads in the primary window, and all three forecast branches.
    """

    if type(repeat_count) is not int or repeat_count < 1:
        raise ValueError("repeat_count must be a positive integer")
    normalized = validate_future_sufficient_rows(rows)
    primary = [
        row
        for row in normalized
        if row["post_update_lead_hour"] in WINDOWS["post_update_1_to_6"]
    ]
    seeds = sorted({row["seed"] for row in primary})
    blocks = sorted({row["block_id"] for row in primary})
    if seeds != list(SEEDS) or not blocks:
        raise ValueError("bootstrap requires all three seeds and nonempty blocks")
    seed_position = {value: index for index, value in enumerate(seeds)}
    block_position = {value: index for index, value in enumerate(blocks)}
    shape = (3, len(blocks), 6, 4)
    base = np.zeros(shape, dtype=np.float64)
    prior = np.zeros(shape, dtype=np.float64)
    updated = np.zeros(shape, dtype=np.float64)
    movement = np.zeros(shape, dtype=np.float64)
    cells = np.zeros(shape, dtype=np.int64)
    row_counts = np.zeros(shape, dtype=np.int64)
    for row in primary:
        index = (
            seed_position[row["seed"]],
            block_position[row["block_id"]],
            row["source_index"],
            row["target_index"],
        )
        base[index] += row["base_absolute_error_sum_m"]
        prior[index] += row["prior_absolute_error_sum_m"]
        updated[index] += row["updated_absolute_error_sum_m"]
        movement[index] += row["updated_minus_prior_absolute_movement_sum_m"]
        cells[index] += row["cell_count"]
        row_counts[index] += 1
    if bool((row_counts != 6).any()) or bool((cells <= 0).any()):
        raise ValueError("bootstrap seed-block-direction grid is incomplete")

    generator = np.random.Generator(np.random.PCG64(random_seed))
    seed_draws = generator.integers(0, 3, size=(repeat_count, 3), endpoint=False)
    block_draws = generator.integers(
        0, len(blocks), size=(repeat_count, len(blocks)), endpoint=False
    )
    cell_summaries = []
    measurement_samples: Dict[Tuple[int, int], np.ndarray] = {}
    total_samples: Dict[Tuple[int, int], np.ndarray] = {}
    for source in range(6):
        for target in range(4):
            chosen_cells = cells[
                seed_draws[:, :, None], block_draws[:, None, :], source, target
            ]
            denominator = chosen_cells.sum(axis=(1, 2))
            chosen_base = base[
                seed_draws[:, :, None], block_draws[:, None, :], source, target
            ].sum(axis=(1, 2))
            chosen_prior = prior[
                seed_draws[:, :, None], block_draws[:, None, :], source, target
            ].sum(axis=(1, 2))
            chosen_updated = updated[
                seed_draws[:, :, None], block_draws[:, None, :], source, target
            ].sum(axis=(1, 2))
            measurement_gain = (chosen_prior - chosen_updated) / denominator
            total_gain = (chosen_base - chosen_updated) / denominator
            covariance_gain = (chosen_base - chosen_prior) / denominator
            measurement_samples[(source, target)] = measurement_gain
            total_samples[(source, target)] = total_gain
            one_lower, two_lower, two_upper = _linear_quantiles(measurement_gain)
            total_one_lower, _, _ = _linear_quantiles(total_gain)
            point_cells = cells[:, :, source, target].sum()
            point_measurement = float(
                (prior[:, :, source, target].sum() - updated[:, :, source, target].sum())
                / point_cells
            )
            point_total = float(
                (base[:, :, source, target].sum() - updated[:, :, source, target].sum())
                / point_cells
            )
            point_covariance = float(
                (base[:, :, source, target].sum() - prior[:, :, source, target].sum())
                / point_cells
            )
            decomposition_residual = point_total - (
                point_covariance + point_measurement
            )
            if not math.isclose(
                decomposition_residual, 0.0, abs_tol=1e-12, rel_tol=1e-10
            ):
                raise RuntimeError("bootstrap point gain decomposition failed")
            cell_summaries.append(
                {
                    "source_index": source,
                    "source_station": SOURCE_STATIONS[source],
                    "target_index": target,
                    "target_station": TARGET_STATIONS[target],
                    "is_self": is_self_cell(source, target),
                    "is_boundary_source": is_boundary_cell(source),
                    "point_covariance_propagation_gain_m": point_covariance,
                    "point_measurement_update_gain_m": point_measurement,
                    "point_total_gain_m": point_total,
                    "point_gain_decomposition_residual_m": decomposition_residual,
                    "point_forecast_movement_m": float(
                        movement[:, :, source, target].sum() / point_cells
                    ),
                    "measurement_gain_one_sided_95_lower_m": one_lower,
                    "measurement_gain_two_sided_95_lower_m": two_lower,
                    "measurement_gain_two_sided_95_upper_m": two_upper,
                    "measurement_gain_one_sided_p_value": float(
                        (1 + np.count_nonzero(measurement_gain <= 0.0))
                        / (repeat_count + 1)
                    ),
                    "total_gain_one_sided_95_lower_m": total_one_lower,
                }
            )

    cross_keys = [
        (source, target)
        for source in range(6)
        for target in range(4)
        if not is_self_cell(source, target)
    ]
    internal_keys = [key for key in cross_keys if key[0] in range(1, 5)]
    boundary_keys = [key for key in cross_keys if key[0] in (0, 5)]

    def macro(keys: Sequence[Tuple[int, int]], name: str) -> Dict[str, Any]:
        measurement = np.stack(
            [measurement_samples[key] for key in keys], axis=1
        ).mean(axis=1)
        total = np.stack([total_samples[key] for key in keys], axis=1).mean(axis=1)
        one_lower, two_lower, two_upper = _linear_quantiles(measurement)
        cell_lookup = {
            (row["source_index"], row["target_index"]): row
            for row in cell_summaries
        }
        return {
            "name": name,
            "cell_count": len(keys),
            "point_measurement_update_gain_m": float(
                np.mean(
                    [
                        cell_lookup[key]["point_measurement_update_gain_m"]
                        for key in keys
                    ]
                )
            ),
            "point_total_gain_m": float(
                np.mean([cell_lookup[key]["point_total_gain_m"] for key in keys])
            ),
            "measurement_gain_one_sided_95_lower_m": one_lower,
            "measurement_gain_two_sided_95_lower_m": two_lower,
            "measurement_gain_two_sided_95_upper_m": two_upper,
            "measurement_gain_one_sided_p_value": float(
                (1 + np.count_nonzero(measurement <= 0.0))
                / (repeat_count + 1)
            ),
            "bootstrap_total_gain_mean_m": float(total.mean()),
        }

    target_column_macros = []
    for target in range(4):
        keys = [key for key in cross_keys if key[1] == target]
        target_column_macros.append(macro(keys, "target_" + TARGET_STATIONS[target]))

    internal_rows = [row for row in cell_summaries if row["source_index"] in range(1, 5) and not row["is_self"]]
    boundary_rows = [row for row in cell_summaries if row["is_boundary_source"]]
    for family_name, family_rows in (
        ("internal_12", internal_rows),
        ("boundary_8", boundary_rows),
    ):
        adjusted, rejected = holm_adjust_one_sided(
            [row["measurement_gain_one_sided_p_value"] for row in family_rows]
        )
        for row, adjusted_p, reject in zip(family_rows, adjusted, rejected):
            row["holm_family"] = family_name
            row["holm_adjusted_one_sided_p_value"] = adjusted_p
            row["holm_reject_at_0_05"] = reject
            row["direction_stable_support"] = bool(
                reject
                and row["measurement_gain_one_sided_95_lower_m"] > 0.0
            )

    return {
        "schema_version": "1.0",
        "sampling": {
            "repeat_count": repeat_count,
            "bit_generator": "PCG64",
            "random_seed": random_seed,
            "seed_draw_count": 3,
            "calendar_block_draw_count": len(blocks),
            "seed_values": seeds,
            "nonempty_block_ids": blocks,
            "shared_across_all_cells_leads_and_branches": True,
            "quantile_method": "linear",
        },
        "cell_summaries": cell_summaries,
        "cross_20_macro": macro(cross_keys, "cross_20"),
        "internal_12_macro": macro(internal_keys, "internal_12"),
        "boundary_8_macro": macro(boundary_keys, "boundary_8"),
        "target_column_cross_macros": target_column_macros,
    }


def decide_forecast_direction_gates(
    window_rows: Sequence[Mapping[str, Any]],
    bootstrap: Mapping[str, Any],
) -> Dict[str, Any]:
    """Apply the frozen self, cross, group, column, and adjacent gates."""

    primary = [
        row
        for row in window_rows
        if row.get("window_name") == "post_update_1_to_6"
    ]
    lookup = {
        (row.get("scope"), int(row["source_index"]), int(row["target_index"])): row
        for row in primary
    }
    self_rows = []
    for target in range(4):
        source = target + 1
        pooled = lookup.get(("pooled_three_seeds", source, target))
        if pooled is None:
            raise ValueError("self-cell window metrics are incomplete")
        positive_seeds = sum(
            float(lookup[("seed_%d" % seed, source, target)]["measurement_update_gain_m"])
            > 0.0
            for seed in SEEDS
        )
        self_rows.append(
            {
                "source_index": source,
                "target_index": target,
                "point_gain_m": float(pooled["measurement_update_gain_m"]),
                "positive_seed_count": positive_seeds,
                "pass": bool(
                    float(pooled["measurement_update_gain_m"]) > 0.0
                    and positive_seeds >= 2
                ),
            }
        )
    cell_bootstrap = {
        (int(row["source_index"]), int(row["target_index"])): row
        for row in bootstrap["cell_summaries"]
    }
    adjacent = []
    for key in ADJACENT_DIRECTIONS:
        row = cell_bootstrap[key]
        adjacent.append(
            {
                "source_index": key[0],
                "target_index": key[1],
                "movement_m": row["point_forecast_movement_m"],
                "gain_m": row["point_measurement_update_gain_m"],
                "movement_above_numerical_tolerance": bool(
                    row["point_forecast_movement_m"] > 1e-6
                ),
                "gain_positive": bool(row["point_measurement_update_gain_m"] > 0.0),
            }
        )
    cross = bootstrap["cross_20_macro"]
    internal = bootstrap["internal_12_macro"]
    boundary = bootstrap["boundary_8_macro"]
    columns = bootstrap["target_column_cross_macros"]
    gates = {
        "four_self_cells_pass": all(row["pass"] for row in self_rows),
        "cross_20_measurement_lower_strictly_positive": (
            cross["measurement_gain_one_sided_95_lower_m"] > 0.0
        ),
        "cross_20_total_point_strictly_positive": cross["point_total_gain_m"] > 0.0,
        "internal_12_point_strictly_positive": (
            internal["point_measurement_update_gain_m"] > 0.0
        ),
        "boundary_8_point_strictly_positive": (
            boundary["point_measurement_update_gain_m"] > 0.0
        ),
        "four_target_columns_strictly_positive": all(
            row["point_measurement_update_gain_m"] > 0.0 for row in columns
        ),
        "eight_adjacent_movements_above_1e_6_m": all(
            row["movement_above_numerical_tolerance"] for row in adjacent
        ),
        "at_least_six_adjacent_gains_positive": sum(
            row["gain_positive"] for row in adjacent
        )
        >= 6,
    }
    self_forecast_gate_pass = gates["four_self_cells_pass"]
    cross_station_gate_pass = all(
        value
        for name, value in gates.items()
        if name != "four_self_cells_pass"
    )
    if not (
        gates["cross_20_measurement_lower_strictly_positive"]
        and gates["cross_20_total_point_strictly_positive"]
    ):
        cross_station_status = "scientific_direction_fail"
    elif cross_station_gate_pass:
        cross_station_status = (
            "statistical_direction_pass_practical_magnitude_not_assessed"
        )
    else:
        cross_station_status = "local_cross_station_effect_only"
    if cross_station_status != (
        "statistical_direction_pass_practical_magnitude_not_assessed"
    ):
        status = cross_station_status
    elif not self_forecast_gate_pass:
        status = "cross_station_pass_self_forecast_fail"
    else:
        status = cross_station_status
    return {
        "schema_version": "1.0",
        "status": status,
        "cross_station_status": cross_station_status,
        "self_forecast_gate_pass": self_forecast_gate_pass,
        "cross_station_gate_pass": cross_station_gate_pass,
        "forecast_gate_pass": bool(
            self_forecast_gate_pass and cross_station_gate_pass
        ),
        "self_cells": self_rows,
        "adjacent_directions": adjacent,
        "gates": gates,
        "practical_magnitude_gate": "not_frozen",
    }


def rows_to_canonical_json(rows: Sequence[Mapping[str, Any]]) -> str:
    """Return stable JSON for identity comparisons in tests and audits."""

    return json.dumps(list(rows), ensure_ascii=False, sort_keys=True, separators=(",", ":"))


__all__ = [
    "ADJACENT_DIRECTIONS",
    "BOOTSTRAP_RANDOM_SEED",
    "BOOTSTRAP_REPEAT_COUNT",
    "FUTURE_SUFFICIENT_FIELDS",
    "SOURCE_STATIONS",
    "TARGET_STATIONS",
    "assign_calendar_seven_day_blocks",
    "bootstrap_crossed_seed_calendar_blocks",
    "build_directional_matrices",
    "calendar_seven_day_block",
    "decide_forecast_direction_gates",
    "gain_from_mean_absolute_errors",
    "holm_adjust_one_sided",
    "summarize_source_target_leads",
    "summarize_source_target_windows",
    "validate_future_sufficient_rows",
    "validate_horizon_pair",
]
