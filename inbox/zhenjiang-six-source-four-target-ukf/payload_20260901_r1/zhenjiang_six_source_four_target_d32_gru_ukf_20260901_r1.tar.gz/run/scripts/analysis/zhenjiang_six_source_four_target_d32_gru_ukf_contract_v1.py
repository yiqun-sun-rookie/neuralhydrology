#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Read-only contract for the six-source, four-target forecast experiment.

This module contains no data loader, model execution, or result writer.  It is
the single source of truth for station direction, calendar splits, random
seeds, tensor shapes, and the distinction between self and cross-station
cells.

Example:
    python scripts/analysis/zhenjiang_six_source_four_target_d32_gru_ukf_contract_v1.py --self-check
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime, timedelta
import json
from typing import Dict, Iterable, Tuple


EXPERIMENT_FAMILY = (
    "ZHENJIANG_SIX_SOURCE_FOUR_TARGET_D32_GRU_DIFFERENTIABLE_UKF_V1"
)
SOURCE_STATIONS: Tuple[str, ...] = (
    "datong",
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
TARGET_STATIONS: Tuple[str, ...] = (
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
)
TARGET_SOURCE_INDICES: Tuple[int, ...] = (1, 2, 3, 4)
BOUNDARY_SOURCE_STATIONS: Tuple[str, ...] = ("datong", "wusongkou")
RANDOM_SEEDS: Tuple[int, ...] = (17, 29, 43)

TRAIN_YEARS: Tuple[int, ...] = (2017, 2018, 2019, 2020, 2021)
SELECTION_YEAR = 2022
DEVELOPMENT_YEAR = 2023
HELDOUT_YEAR = 2024

HISTORY_HOURS = 24
BASE_FORECAST_HOURS = 24
POST_UPDATE_FORECAST_HOURS = 23
STATE_DIMENSION = 32
SIGMA_POINT_COUNT = 65

# Directed pairs: current observation source -> future forecast target.
ADJACENT_DIRECTIONS: Tuple[Tuple[str, str], ...] = (
    ("datong", "nanjing"),
    ("nanjing", "zhenjiang"),
    ("zhenjiang", "nanjing"),
    ("zhenjiang", "jiangyin"),
    ("jiangyin", "zhenjiang"),
    ("jiangyin", "xuliujing"),
    ("xuliujing", "jiangyin"),
    ("wusongkou", "xuliujing"),
)


@dataclass(frozen=True, order=True)
class DirectionCell:
    """One directed source-row and target-column matrix cell."""

    source_station: str
    target_station: str

    @property
    def key(self) -> str:
        return f"{self.source_station}->{self.target_station}"

    @property
    def is_self(self) -> bool:
        return self.source_station == self.target_station

    @property
    def is_boundary(self) -> bool:
        return self.source_station in BOUNDARY_SOURCE_STATIONS

    @property
    def is_internal_cross(self) -> bool:
        return (
            self.source_station in TARGET_STATIONS
            and self.target_station in TARGET_STATIONS
            and not self.is_self
        )


def all_direction_cells() -> Tuple[DirectionCell, ...]:
    """Return the row-major six-by-four directed matrix."""

    return tuple(
        DirectionCell(source, target)
        for source in SOURCE_STATIONS
        for target in TARGET_STATIONS
    )


def expected_output_shapes(batch_size: int) -> Dict[str, Tuple[int, ...]]:
    """Return all frozen output shapes for a positive batch size."""

    if type(batch_size) is not int or batch_size < 1:
        raise ValueError("batch_size must be a positive integer")
    return {
        "base_deterministic_future_forecast": (
            batch_size,
            POST_UPDATE_FORECAST_HOURS,
            len(TARGET_STATIONS),
        ),
        "no_observation_unscented_prior_future_forecast": (
            batch_size,
            POST_UPDATE_FORECAST_HOURS,
            len(TARGET_STATIONS),
        ),
        "updated_future_forecast": (
            batch_size,
            len(SOURCE_STATIONS),
            POST_UPDATE_FORECAST_HOURS,
            len(TARGET_STATIONS),
        ),
        "analysis_prior_target": (batch_size, len(TARGET_STATIONS)),
        "analysis_posterior_target": (
            batch_size,
            len(SOURCE_STATIONS),
            len(TARGET_STATIONS),
        ),
        "updated_state": (
            batch_size,
            len(SOURCE_STATIONS),
            STATE_DIMENSION,
        ),
        "kalman_gain": (
            batch_size,
            len(SOURCE_STATIONS),
            STATE_DIMENSION,
        ),
    }


def window_is_within_one_calendar_year(issue_time: datetime) -> bool:
    """Return whether ``[t-23,t+24]`` stays inside one calendar year."""

    if not isinstance(issue_time, datetime):
        raise ValueError("issue_time must be a datetime")
    first = issue_time - timedelta(hours=HISTORY_HOURS - 1)
    last = issue_time + timedelta(hours=BASE_FORECAST_HOURS)
    return first.year == issue_time.year == last.year


def split_name_for_year(year: int) -> str:
    """Map one registered year to its immutable scientific role."""

    if type(year) is not int:
        raise ValueError("year must be an integer")
    if year in TRAIN_YEARS:
        return "training"
    if year == SELECTION_YEAR:
        return "selection"
    if year == DEVELOPMENT_YEAR:
        return "development_gate"
    if year == HELDOUT_YEAR:
        return "new_model_heldout"
    raise ValueError(f"year is outside the registered split: {year}")


def _duplicate_values(values: Iterable[object]) -> Tuple[object, ...]:
    seen = set()
    duplicates = []
    for value in values:
        if value in seen and value not in duplicates:
            duplicates.append(value)
        seen.add(value)
    return tuple(duplicates)


def self_check() -> Dict[str, object]:
    """Validate the immutable contract and return a machine-readable report."""

    cells = all_direction_cells()
    self_cells = tuple(cell for cell in cells if cell.is_self)
    cross_cells = tuple(cell for cell in cells if not cell.is_self)
    internal_cross = tuple(cell for cell in cells if cell.is_internal_cross)
    boundary = tuple(cell for cell in cells if cell.is_boundary)
    findings = []
    if _duplicate_values(SOURCE_STATIONS):
        findings.append("duplicate_source_station")
    if _duplicate_values(TARGET_STATIONS):
        findings.append("duplicate_target_station")
    if len(cells) != 24:
        findings.append("wrong_total_cell_count")
    if len(self_cells) != 4:
        findings.append("wrong_self_cell_count")
    if len(cross_cells) != 20:
        findings.append("wrong_cross_cell_count")
    if len(internal_cross) != 12:
        findings.append("wrong_internal_cross_cell_count")
    if len(boundary) != 8:
        findings.append("wrong_boundary_cell_count")
    if tuple(SOURCE_STATIONS[index] for index in TARGET_SOURCE_INDICES) != (
        TARGET_STATIONS
    ):
        findings.append("target_source_index_drift")
    if len(ADJACENT_DIRECTIONS) != 8 or any(
        DirectionCell(*pair) not in cells for pair in ADJACENT_DIRECTIONS
    ):
        findings.append("adjacent_direction_drift")
    if SIGMA_POINT_COUNT != 2 * STATE_DIMENSION + 1:
        findings.append("sigma_point_count_drift")
    return {
        "experiment_family": EXPERIMENT_FAMILY,
        "source_count": len(SOURCE_STATIONS),
        "target_count": len(TARGET_STATIONS),
        "total_cell_count": len(cells),
        "self_cell_count": len(self_cells),
        "cross_cell_count": len(cross_cells),
        "internal_cross_cell_count": len(internal_cross),
        "boundary_cell_count": len(boundary),
        "adjacent_direction_count": len(ADJACENT_DIRECTIONS),
        "random_seeds": list(RANDOM_SEEDS),
        "training_years": list(TRAIN_YEARS),
        "selection_year": SELECTION_YEAR,
        "development_year": DEVELOPMENT_YEAR,
        "heldout_year": HELDOUT_YEAR,
        "finding_count": len(findings),
        "findings": findings,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-check", action="store_true")
    arguments = parser.parse_args()
    if not arguments.self_check:
        parser.error("--self-check is required; this module has no run mode")
    report = self_check()
    print(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2))
    return 0 if report["finding_count"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
