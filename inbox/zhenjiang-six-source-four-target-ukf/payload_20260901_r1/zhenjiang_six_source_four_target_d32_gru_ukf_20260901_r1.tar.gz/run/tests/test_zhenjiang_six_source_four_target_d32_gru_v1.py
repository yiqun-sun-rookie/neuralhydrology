"""Interface tests for the shared-state dual-head model."""

from __future__ import annotations

from pathlib import Path
import sys

import pytest
import torch


ROOT = Path(__file__).resolve().parents[1]
MODELING_DIR = ROOT / "scripts" / "modeling"
if str(MODELING_DIR) not in sys.path:
    sys.path.insert(0, str(MODELING_DIR))

from zhenjiang_six_source_four_target_d32_gru_v1 import (  # noqa: E402
    EXPECTED_PARAMETER_COUNT,
    REALTIME_OBSERVATION_NORMALIZATION_ROLE,
    RETROSPECTIVE_TARGET_NORMALIZATION_ROLE,
    SixSourceFourTargetD32GRU,
    trainable_parameter_count,
)


def _inputs(batch_size=3):
    generator = torch.Generator().manual_seed(702)
    history = torch.randn(batch_size, 24, 6, generator=generator)
    tide = torch.randn(batch_size, 24, generator=generator)
    return history, tide


def test_exact_architecture_interfaces_shapes_and_parameter_count():
    model = SixSourceFourTargetD32GRU()
    history, tide = _inputs()
    state = model.encode_history(history)
    next_state = model.transition_step(state, tide[:, 0])
    observation = model.decode_realtime_observation(next_state)
    target = model.decode_retrospective_target(next_state)
    forecast = model(history, tide)
    assert state.shape == next_state.shape == (3, 32)
    assert observation.shape == (3, 6)
    assert target.shape == (3, 4)
    assert forecast.shape == (3, 24, 4)
    assert trainable_parameter_count(model) == EXPECTED_PARAMETER_COUNT == 19_594
    for tensor in (state, next_state, observation, target, forecast):
        assert bool(torch.isfinite(tensor).all())


def test_heads_have_distinct_label_space_identities():
    model = SixSourceFourTargetD32GRU()
    assert (
        model.realtime_observation_normalization_role
        == REALTIME_OBSERVATION_NORMALIZATION_ROLE
        == "analysis_t_plus_1_realtime_stage"
    )
    assert (
        model.retrospective_target_normalization_role
        == RETROSPECTIVE_TARGET_NORMALIZATION_ROLE
        == "four_internal_retrospective_targets"
    )
    assert model.realtime_observation_decoder.weight.shape == (6, 32)
    assert model.retrospective_target_decoder.weight.shape == (4, 32)
    assert (
        model.realtime_observation_decoder.weight.data_ptr()
        != model.retrospective_target_decoder.weight.data_ptr()
    )


def test_changing_realtime_head_cannot_change_target_forecast():
    model = SixSourceFourTargetD32GRU().eval()
    history, tide = _inputs()
    with torch.no_grad():
        before = model(history, tide).clone()
        model.realtime_observation_decoder.weight.add_(7.0)
        model.realtime_observation_decoder.bias.sub_(3.0)
        after = model(history, tide)
    torch.testing.assert_close(after, before, rtol=0.0, atol=0.0)


def test_changing_target_head_cannot_change_innovation_prediction():
    model = SixSourceFourTargetD32GRU().eval()
    history, tide = _inputs()
    with torch.no_grad():
        state = model.transition_step(model.encode_history(history), tide[:, 0])
        before = model.decode_realtime_observation(state).clone()
        model.retrospective_target_decoder.weight.mul_(0.0)
        model.retrospective_target_decoder.bias.add_(99.0)
        after = model.decode_realtime_observation(state)
    torch.testing.assert_close(after, before, rtol=0.0, atol=0.0)


@pytest.mark.parametrize(
    "history_shape,tide_shape,message",
    [
        ((2, 23, 6), (2, 24), "history"),
        ((2, 24, 5), (2, 24), "history"),
        ((2, 24, 6), (2, 23), "future_tide"),
    ],
)
def test_input_shapes_are_strict(history_shape, tide_shape, message):
    model = SixSourceFourTargetD32GRU()
    history = torch.zeros(history_shape)
    tide = torch.zeros(tide_shape)
    with pytest.raises(ValueError, match=message):
        model(history, tide)
