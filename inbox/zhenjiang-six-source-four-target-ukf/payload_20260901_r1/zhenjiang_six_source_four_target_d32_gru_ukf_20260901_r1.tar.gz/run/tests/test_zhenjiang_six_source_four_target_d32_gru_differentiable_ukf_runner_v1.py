"""Synthetic and filesystem-safety tests for the formal filter runner."""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import sys
from types import SimpleNamespace

import pytest
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset


ROOT = Path(__file__).resolve().parents[1]
MODELING_DIR = ROOT / "scripts" / "modeling"
if str(MODELING_DIR) not in sys.path:
    sys.path.insert(0, str(MODELING_DIR))

from zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_runner_v1 import (  # noqa: E402
    _exclusive_attempt_paths,
    _require_exact_registered_path,
    _verify_registered_real_batch_smoke,
    assert_training_target_access_is_predevelopment,
    load_registered_frozen_filter_for_evaluation,
    run_synthetic_smoke,
    run_training_epoch,
    run_validation_epoch,
    verify_output_directory,
    write_completion_manifest,
)
import zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_runner_v1 as runner_module  # noqa: E402,E501
from zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_training_v1 import (  # noqa: E402,E501
    prepare_filter_for_training,
)
from zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_v1 import (  # noqa: E402,E501
    SixSourceFourTargetD32GRUDifferentiableUKF,
)
from zhenjiang_six_source_four_target_d32_gru_v1 import (  # noqa: E402
    SixSourceFourTargetD32GRU,
)


class _Rows(Dataset):
    def __init__(self, count: int) -> None:
        self.count = count

    def __len__(self) -> int:
        return self.count

    def __getitem__(self, index: int):
        level = 2.0 if index < 32 else 10.0
        return {
            "history": torch.zeros(24, 6),
            "future_tide": torch.zeros(24),
            "analysis_observations": torch.zeros(6),
            "targets_t_plus_2_to_t_plus_24": torch.full((23, 4), level),
        }


class _TinyFilter(nn.Module):
    """Expose exactly 38 trainable values and the three runner branches."""

    def __init__(self) -> None:
        super().__init__()
        self.noise = nn.Parameter(torch.full((38,), 0.01, dtype=torch.float64))

    def forward(self, history, future_tide, observations):
        batch = history.shape[0]
        value = self.noise.mean()
        updated = value.expand(batch, 6, 23, 4)
        common = value.expand(batch, 23, 4)
        return {
            "updated_forecast": updated,
            "base_deterministic_forecast": common,
            "unscented_prior_forecast": common,
        }


def test_epoch_metric_weights_a_partial_last_batch_by_all_cells():
    model = _TinyFilter()
    loader = DataLoader(_Rows(33), batch_size=32, shuffle=False, drop_last=False)
    scale = torch.ones(4, dtype=torch.float64)

    validation = run_validation_epoch(model, loader, scale, "cpu")
    expected = (32.0 * abs(0.01 - 2.0) + abs(0.01 - 10.0)) / 33.0
    assert validation["completed_batches"] == 2
    assert validation["base_sample_count"] == 33
    assert validation["valid_cell_count"] == 33 * 552
    assert validation["selection_mae_m"] == pytest.approx(expected)
    assert validation["selection_mae_m"] != pytest.approx(
        (abs(0.01 - 2.0) + abs(0.01 - 10.0)) / 2.0
    )


def test_training_epoch_updates_one_shared_38_parameter_set():
    model = _TinyFilter()
    before = model.noise.detach().clone()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    metrics, gradients = run_training_epoch(
        model,
        DataLoader(_Rows(2), batch_size=2, shuffle=False),
        optimizer,
        torch.ones(4, dtype=torch.float64),
        "cpu",
    )

    assert metrics["valid_cell_count"] == 2 * 552
    assert gradients[0]["gradient_scalar_count"] == 38
    assert gradients[0]["nonfinite_gradient_count"] == 0
    assert not torch.equal(model.noise.detach(), before)


def test_existing_complete_or_partial_attempt_stops_before_creation(tmp_path):
    complete = tmp_path / "attempt_001"
    complete.mkdir()
    with pytest.raises(FileExistsError, match="already exists"):
        _exclusive_attempt_paths(complete)
    complete.rmdir()
    partial = tmp_path / "attempt_001.partial"
    partial.mkdir()
    with pytest.raises(FileExistsError, match="partial"):
        _exclusive_attempt_paths(tmp_path / "attempt_001")


def test_another_nonexistent_output_directory_is_not_a_registered_attempt(tmp_path):
    registered = tmp_path / "registered" / "attempt_001"
    another = tmp_path / "another" / "attempt_001"
    assert not registered.exists() and not another.exists()
    with pytest.raises(ValueError, match="unique registered path"):
        _require_exact_registered_path(
            another, "/registered/attempt_001", label="base output"
        )


@dataclass
class _Audit:
    target_rows_by_period: dict
    development_feature_bytes_read: int = 0
    development_feature_rows_parsed: int = 0
    development_feature_values_loaded: int = 0
    development_target_bytes_read: int = 0
    development_target_rows_parsed: int = 0
    development_target_values_loaded: int = 0
    heldout_target_bytes_read: int = 0
    heldout_target_rows_parsed: int = 0
    heldout_target_values_loaded: int = 0
    boundary_target_bytes_read: int = 0
    boundary_target_rows_parsed: int = 0
    boundary_target_values_loaded: int = 0


@pytest.mark.parametrize(
    "audit",
    [
        _Audit({"development_gate": 1, "heldout_or_later": 0, "boundary_target": 0}),
        _Audit({"development_gate": 0, "heldout_or_later": 1, "boundary_target": 0}),
        _Audit({"development_gate": 0, "heldout_or_later": 0, "boundary_target": 1}),
        _Audit(
            {"development_gate": 0, "heldout_or_later": 0, "boundary_target": 0},
            development_target_values_loaded=1,
        ),
    ],
)
def test_nonzero_forbidden_target_access_stops_before_training(audit):
    with pytest.raises(RuntimeError, match="forbidden target access"):
        assert_training_target_access_is_predevelopment(audit)


def test_unrecorded_development_access_field_is_not_treated_as_zero():
    complete = _Audit(
        {"development_gate": 0, "heldout_or_later": 0, "boundary_target": 0}
    )
    fields = vars(complete).copy()
    fields.pop("development_target_values_loaded")
    audit = SimpleNamespace(**fields)
    with pytest.raises(ValueError, match="lacks required field"):
        assert_training_target_access_is_predevelopment(audit)


def test_completion_manifest_is_last_and_detects_identity_drift(tmp_path):
    output = tmp_path / "attempt_001"
    output.mkdir()
    artifact = output / "run_identity.json"
    artifact.write_text("{}\n", encoding="utf-8")
    manifest = write_completion_manifest(output, status="technical_pass")
    assert manifest.stat().st_mtime_ns >= artifact.stat().st_mtime_ns
    assert verify_output_directory(output)["verified_file_count"] == 1
    artifact.write_text('{"changed":true}\n', encoding="utf-8")
    with pytest.raises(RuntimeError, match="identity"):
        verify_output_directory(output)


def test_real_batch_smoke_gate_requires_one_batch_32_optimizer_step(tmp_path):
    output = tmp_path / "attempt_001"
    output.mkdir()
    report = {
        "execution_mode": "real_batch_smoke",
        "status": "technical_pass_real_batch_32",
        "stage": "filter",
        "seed": 17,
        "batch_size": 32,
        "valid_cell_count": 32 * 552,
        "forward_backward_optimizer_step_count": 1,
        "device_type": "cuda",
        "step_seconds": 1.25,
        "peak_gpu_memory_allocated_bytes": 1024,
        "peak_gpu_memory_reserved_bytes": 2048,
    }
    (output / "report.json").write_text(
        json.dumps(report), encoding="utf-8"
    )
    write_completion_manifest(output, status="technical_pass_real_batch_32")
    assert _verify_registered_real_batch_smoke(output, seed=17)["report"] == report

    report["batch_size"] = 31
    bad = tmp_path / "bad" / "attempt_001"
    bad.mkdir(parents=True)
    (bad / "report.json").write_text(json.dumps(report), encoding="utf-8")
    write_completion_manifest(bad, status="technical_pass_real_batch_32")
    with pytest.raises(RuntimeError, match="report contract"):
        _verify_registered_real_batch_smoke(bad, seed=17)


def test_synthetic_smoke_reads_no_real_data_and_writes_no_formal_result():
    report = run_synthetic_smoke(17, "cpu")
    assert report["status"] == "technical_pass"
    assert report["valid_cell_count"] == 552
    assert report["gradient_scalar_count"] == 38
    assert report["real_data_opened"] is False
    assert report["formal_output_created"] is False


def test_evaluation_loader_uses_registered_filter_checkpoint_and_freezes_it(
    tmp_path, monkeypatch
):
    output = tmp_path / "runs" / "filter" / "s17" / "attempt_001"
    output.mkdir(parents=True)
    model = prepare_filter_for_training(
        SixSourceFourTargetD32GRUDifferentiableUKF(
            SixSourceFourTargetD32GRU()
        ),
        "cpu",
    )
    normalization = {"frozen": "normalization"}
    normalization_sha = runner_module._mapping_sha256(normalization)
    checkpoint = {
        "schema_version": 1,
        "experiment_family": runner_module.EXPERIMENT_FAMILY,
        "seed": 17,
        "epoch": 4,
        "selection_mae_m": 0.125,
        "base_checkpoint_sha256": "a" * 64,
        "observation_head_sha256": "b" * 64,
        "normalization_sha256": normalization_sha,
        "filter_state_dict": {
            "process_noise.raw_standard_deviation": (
                model.process_noise.raw_standard_deviation.detach().clone()
            ),
            "observation_noise.raw_standard_deviation": (
                model.observation_noise.raw_standard_deviation.detach().clone()
            ),
        },
        "optimization": dict(runner_module.FROZEN_OPTIMIZATION),
    }
    torch.save(checkpoint, output / "best_filter_checkpoint.pt")
    task = {
        "registered_base_checkpoint_path": str(tmp_path / "best_checkpoint.pt"),
        "registered_observation_head_path": str(tmp_path / "head.pt"),
        "registered_output_path": str(output),
    }
    monkeypatch.setattr(
        runner_module,
        "load_registered_task",
        lambda *_args, **_kwargs: ({}, task),
    )
    monkeypatch.setattr(
        runner_module,
        "_load_frozen_filter",
        lambda *_args, **_kwargs: (
            model,
            {
                "base_checkpoint_sha256": "a" * 64,
                "observation_head_sha256": "b" * 64,
                "base_normalization": normalization,
            },
        ),
    )
    monkeypatch.setattr(
        runner_module,
        "verify_output_directory",
        lambda _path: {
            "status": "complete_2022_selected_training",
            "completion_manifest_sha256": "c" * 64,
        },
    )

    loaded, identities = load_registered_frozen_filter_for_evaluation(
        tmp_path / "registry.json", seed=17, device="cpu"
    )
    assert loaded.training is False
    assert all(parameter.requires_grad is False for parameter in loaded.parameters())
    assert identities["filter_checkpoint_path"] == str(
        output / "best_filter_checkpoint.pt"
    )
    assert identities["normalization_sha256"] == normalization_sha
    assert identities["selection_mae_m"] == pytest.approx(0.125)
