"""Hand-calculated tests for frozen base and observation-head qualification."""

from __future__ import annotations

from pathlib import Path
import sys

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS_DIR = ROOT / "scripts" / "analysis"
if str(ANALYSIS_DIR) not in sys.path:
    sys.path.insert(0, str(ANALYSIS_DIR))

from zhenjiang_six_source_four_target_base_qualification_v1 import (  # noqa: E402
    evaluate_base_and_observation_head_qualification,
    evaluate_base_forecast_qualification,
    evaluate_realtime_observation_head_qualification,
)


def _passing_arrays(sample_count=20):
    sample = np.arange(sample_count, dtype=np.float64)[:, None, None]
    hour = np.arange(24, dtype=np.float64)[None, :, None]
    station = np.arange(4, dtype=np.float64)[None, None, :]
    targets = 1.0 + 0.2 * sample + 0.1 * hour + 0.3 * station
    predictions = targets + 0.01
    target_issue = targets[:, 0, :] - 1.0
    source_issue = np.broadcast_to(
        np.arange(6, dtype=np.float64)[None, :], (sample_count, 6)
    ).copy()
    realtime = source_issue + 0.5
    observation_prediction = realtime + 0.02
    return targets, predictions, target_issue, source_issue, realtime, observation_prediction


def test_all_targets_and_sources_pass_only_under_strict_registered_rules():
    targets, predictions, target_issue, source_issue, realtime, observation_prediction = _passing_arrays()
    report = evaluate_base_and_observation_head_qualification(
        base_predictions_m=predictions,
        base_targets_m=targets,
        target_issue_stage_m=target_issue,
        observation_head_predictions_m=observation_prediction,
        realtime_observations_t_plus_1_m=realtime,
        source_issue_stage_m=source_issue,
        augmented_design_singular_values=np.asarray([8.0, 2.0, 1.0]),
        augmented_design_rank=3,
        augmented_design_condition_number=8.0,
    )
    assert report["evaluation_year"] == 2023
    assert report["checkpoint_mutation_allowed"] is False
    assert report["regularization_reselection_allowed"] is False
    assert report["base_forecast"]["passes"] is True
    assert report["realtime_observation_head"]["passes"] is True
    assert report["passes"] is True
    for row in report["base_forecast"]["target_results"].values():
        assert row["mean_absolute_error_issue_horizon_1_to_6_m"] < row[
            "persistence_mean_absolute_error_issue_horizon_1_to_6_m"
        ]
        assert row["nash_sutcliffe_efficiency_issue_horizon_1_to_24"] > 0.0
    for row in report["realtime_observation_head"]["source_results"].values():
        assert row["mean_absolute_error_t_plus_1_m"] < row[
            "persistence_mean_absolute_error_t_plus_1_m"
        ]
        assert abs(row["mean_bias_t_plus_1_m"] - 0.02) < 1e-12


def test_one_failed_target_or_source_fails_the_combined_qualification():
    targets, predictions, target_issue, source_issue, realtime, observation_prediction = _passing_arrays()
    predictions[:, :6, 2] = targets[:, :6, 2] + 2.0
    base = evaluate_base_forecast_qualification(predictions, targets, target_issue)
    assert base["target_results"]["jiangyin"]["passes"] is False
    assert base["passes"] is False
    observation_prediction[:, 4] = realtime[:, 4] + 1.0
    observation = evaluate_realtime_observation_head_qualification(
        observation_prediction,
        realtime,
        source_issue,
        augmented_design_singular_values=np.asarray([2.0, 1.0]),
        augmented_design_rank=2,
        augmented_design_condition_number=2.0,
    )
    assert observation["source_results"]["xuliujing"]["passes"] is False
    assert observation["passes"] is False


def test_zero_target_variance_cannot_pass_nash_sutcliffe_gate():
    targets = np.ones((3, 24, 4), dtype=np.float64)
    predictions = targets.copy()
    issue = np.zeros((3, 4), dtype=np.float64)
    report = evaluate_base_forecast_qualification(predictions, targets, issue)
    assert all(
        row["nash_sutcliffe_efficiency_issue_horizon_1_to_24"] is None
        for row in report["target_results"].values()
    )
    assert report["passes"] is False


def test_qualification_does_not_mutate_any_input_array():
    targets, predictions, target_issue, source_issue, realtime, observation_prediction = _passing_arrays()
    copies = [array.copy() for array in (targets, predictions, target_issue, source_issue, realtime, observation_prediction)]
    evaluate_base_and_observation_head_qualification(
        base_predictions_m=predictions,
        base_targets_m=targets,
        target_issue_stage_m=target_issue,
        observation_head_predictions_m=observation_prediction,
        realtime_observations_t_plus_1_m=realtime,
        source_issue_stage_m=source_issue,
        augmented_design_singular_values=np.asarray([4.0, 1.0]),
        augmented_design_rank=2,
        augmented_design_condition_number=4.0,
    )
    for actual, expected in zip(
        (targets, predictions, target_issue, source_issue, realtime, observation_prediction),
        copies,
    ):
        np.testing.assert_array_equal(actual, expected)
