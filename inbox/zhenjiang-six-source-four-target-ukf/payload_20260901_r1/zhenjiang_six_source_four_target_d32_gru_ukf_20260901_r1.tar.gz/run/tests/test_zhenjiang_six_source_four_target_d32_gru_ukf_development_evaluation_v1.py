"""Synthetic-only tests for the frozen 2023 evaluation writer."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import pytest
import torch


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "scripts" / "analysis"
MODELING = ROOT / "scripts" / "modeling"
if str(ANALYSIS) not in sys.path:
    sys.path.insert(0, str(ANALYSIS))
if str(MODELING) not in sys.path:
    sys.path.insert(0, str(MODELING))

import audit_zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1 as audit_module  # noqa: E402,E501
import zhenjiang_six_source_four_target_base_qualification_v1 as qualification_module  # noqa: E402,E501
import zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1 as evaluation_module  # noqa: E402,E501
import zhenjiang_six_source_four_target_data_v1 as data_module  # noqa: E402
import zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_runner_v1 as runner_module  # noqa: E402,E501

from zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1 import (  # noqa: E402
    accumulate_development_sufficient_statistics,
    build_base_observation_head_qualification,
    execute_frozen_2023_development_evaluation_once,
    verify_sufficient_grid,
    write_development_evaluation,
)


def _data_access_audit():
    bytes_by_path = {
        "dataset_config.json": 2854,
        "realtime_features/datong_realtime_features.csv": 5_485_506,
        "realtime_features/nanjing_realtime_features.csv": 5_452_340,
        "realtime_features/zhenjiang_realtime_features.csv": 5_490_493,
        "realtime_features/jiangyin_realtime_features.csv": 5_451_807,
        "realtime_features/xuliujing_realtime_features.csv": 5_452_448,
        "realtime_features/wusongkou_realtime_features.csv": 5_449_542,
        "retrospective_targets/nanjing_retrospective_targets.csv": 5_453_455,
        "retrospective_targets/zhenjiang_retrospective_targets.csv": 5_491_015,
        "retrospective_targets/jiangyin_retrospective_targets.csv": 5_452_821,
        "retrospective_targets/xuliujing_retrospective_targets.csv": 5_453_528,
    }
    csv_paths = [path for path in bytes_by_path if path.endswith(".csv")]
    return {
        "opened_paths": list(bytes_by_path),
        "bytes_read_by_path": bytes_by_path,
        "rows_parsed_by_path": {path: 61_344 for path in csv_paths},
        "values_loaded_by_path": {path: 61_344 for path in csv_paths},
        "target_rows_by_period": {
            "training": 175_296,
            "selection": 35_040,
            "development_gate": 35_040,
            "heldout_or_later": 0,
            "boundary_target": 0,
        },
        "astronomical_tide_model_open_count": 1,
        "development_feature_bytes_read": 4_685_966,
        "development_feature_rows_parsed": 52_560,
        "development_feature_values_loaded": 52_560,
        "development_target_bytes_read": 3_123_728,
        "development_target_rows_parsed": 35_040,
        "development_target_values_loaded": 35_040,
        "heldout_target_bytes_read": 0,
        "heldout_target_rows_parsed": 0,
        "heldout_target_values_loaded": 0,
        "boundary_target_bytes_read": 0,
        "boundary_target_rows_parsed": 0,
        "boundary_target_values_loaded": 0,
    }


def _artifact_identities():
    return [
        {
            "seed": seed,
            "base_checkpoint_path": "/synthetic/s%d/base.pt" % seed,
            "base_checkpoint_sha256": "%064x" % seed,
            "observation_head_path": "/synthetic/s%d/head.pt" % seed,
            "observation_head_sha256": "%064x" % (seed + 100),
            "filter_checkpoint_path": "/synthetic/s%d/filter.pt" % seed,
            "filter_checkpoint_sha256": "%064x" % (seed + 200),
            "filter_completion_manifest_sha256": "%064x" % (seed + 300),
            "observation_head_design_diagnostic": {
                "seed": seed,
                "selection_report_path": "/synthetic/s%d/ridge_candidate_diagnostics.json" % seed,
                "selection_report_sha256": "%064x" % (seed + 400),
                "coefficient_float32_sha256": "%064x" % (seed + 500),
                "selected_ridge_strength": 0.1,
                "augmented_design_singular_values": [
                    float(value) for value in range(33, 0, -1)
                ],
                "augmented_design_rank": 33,
                "augmented_design_condition_number": 33.0,
            },
        }
        for seed in (17, 29, 43)
    ]


def _run_identity():
    return {
        "registry_path": "/synthetic/registry.json",
        "registry_sha256": "a" * 64,
        "input_root_path": "/synthetic/input",
        "input_manifest_path": "/synthetic/input/manifest.json",
        "input_manifest_sha256": "b" * 64,
    }


def synthetic_seed_statistics(
    seed: int, experiment_id: str = "synthetic_formal_candidate"
):
    origins = (
        "2023-01-01T00:00:00+08:00",
        "2023-01-02T00:00:00+08:00",
        "2023-01-15T00:00:00+08:00",
        "2023-01-16T00:00:00+08:00",
    )
    count = len(origins)
    origin_axis = np.arange(count, dtype=np.float64)[:, None, None] * 0.01
    lead_axis = np.arange(23, dtype=np.float64)[None, :, None] * 0.1
    target_axis = np.arange(4, dtype=np.float64)[None, None, :] * 0.1
    truth = 1.0 + origin_axis + lead_axis + target_axis
    base = truth + 0.11
    prior = truth + 0.10
    updated = np.repeat((truth + 0.08)[:, None, :, :], 6, axis=1)
    analysis_truth = truth[:, 0, :]
    analysis_prior_target = analysis_truth + 0.10
    analysis_posterior_target = np.repeat(
        (analysis_truth + 0.08)[:, None, :], 6, axis=1
    )
    observation = (
        np.arange(count, dtype=np.float64)[:, None] * 0.01
        + np.arange(6, dtype=np.float64)[None, :] * 0.1
    )
    prior_observation = observation + 0.10
    posterior_observation = np.repeat(prior_observation[:, None, :], 6, axis=1)
    for source in range(6):
        posterior_observation[:, source, source] = observation[:, source] + 0.05
    kalman_gain = np.ones((count, 6, 32), dtype=np.float64) * 0.01
    contraction = np.ones((count, 6), dtype=np.float64) * 0.5
    posterior_variance = np.ones((count, 6), dtype=np.float64) * 0.002
    eigenvalue = np.ones((count, 6), dtype=np.float64) * 0.001
    spectral_floor = np.ones((count, 6), dtype=np.float64) * 1e-12
    observation_noise = np.ones(6, dtype=np.float64) * 0.1
    prior_state = np.zeros((count, 23, 32), dtype=np.float64)
    updated_state = np.empty((count, 6, 23, 32), dtype=np.float64)
    for source in range(6):
        updated_state[:, source] = 0.001 * (source + 1)
    return accumulate_development_sufficient_statistics(
        experiment_id=experiment_id,
        seed=seed,
        origin_times=origins,
        target_future_m=truth,
        analysis_target_m=analysis_truth,
        analysis_observation_m=observation,
        current_stage_m=observation + 0.20,
        base_issue_hour_one_forecast_m=analysis_truth + 0.11,
        base_deterministic_forecast_m=base,
        unscented_prior_forecast_m=prior,
        updated_forecast_m=updated,
        analysis_prior_target_m=analysis_prior_target,
        analysis_posterior_target_m=analysis_posterior_target,
        analysis_prior_observation_m=prior_observation,
        analysis_posterior_observation_m=posterior_observation,
        analysis_kalman_gain=kalman_gain,
        analysis_observation_contraction=contraction,
        analysis_posterior_observation_variance_normalized=posterior_variance,
        analysis_posterior_minimum_eigenvalue=eigenvalue,
        analysis_spectral_floor=spectral_floor,
        observation_noise_standard_deviation_normalized=observation_noise,
        unscented_prior_state_mean=prior_state,
        updated_state_mean=updated_state,
    )


def test_accumulator_has_dynamic_calendar_block_scaled_shapes():
    statistics = synthetic_seed_statistics(17)
    assert statistics["nonempty_block_ids"] == [0, 2]
    assert statistics["nonempty_block_count"] == 2
    assert len(statistics["future_rows"]) == 2 * 6 * 4 * 23
    assert len(statistics["analysis_observation_rows"]) == 2 * 6
    assert len(statistics["analysis_target_rows"]) == 2 * 6 * 4
    assert len(statistics["state_difference_rows"]) == 2 * 6 * 23
    assert all(
        row["issue_horizon_hour"] == row["post_update_lead_hour"] + 1
        for row in statistics["future_rows"]
    )


def test_data_access_audit_normalization_is_idempotent():
    first = evaluation_module._validated_data_access_audit(_data_access_audit())
    second = evaluation_module._validated_data_access_audit(first)
    assert second == first
    assert first["rows_parsed_by_path"]["dataset_config.json"] == 0
    assert first["values_loaded_by_path"]["dataset_config.json"] == 0


def test_qualification_hard_gate_is_pooled_not_per_seed():
    statistics = [synthetic_seed_statistics(seed) for seed in (17, 29, 43)]
    base_rows = [
        dict(row) for item in statistics for row in item["base_qualification_rows"]
    ]
    observation_rows = [
        dict(row)
        for item in statistics
        for row in item["observation_head_qualification_rows"]
    ]
    for row in base_rows:
        if row["seed"] == 17 and row["target_index"] == 0:
            row["base_first_six_absolute_error_sum_m"] = (
                row["persistence_first_six_absolute_error_sum_m"] + 0.01
            )
    for row in observation_rows:
        if row["seed"] == 17 and row["source_index"] == 0:
            row["head_absolute_error_sum_m"] = (
                row["persistence_absolute_error_sum_m"] + 0.01
            )

    qualification = build_base_observation_head_qualification(
        base_rows, observation_rows
    )
    failed_target_seed = next(
        row
        for row in qualification["target_seed_results"]
        if row["seed"] == 17 and row["target_index"] == 0
    )
    failed_source_seed = next(
        row
        for row in qualification["observation_head_seed_results"]
        if row["seed"] == 17 and row["source_index"] == 0
    )
    assert failed_target_seed["passed"] is False
    assert failed_source_seed["passed"] is False
    assert qualification["target_pooled_results"][0]["passed"] is True
    assert qualification["observation_head_pooled_results"][0]["passed"] is True
    assert qualification["passed"] is True
    assert qualification["qualification_gate_contract"] == {
        "aggregation": "pooled_equal_weight_three_seeds",
        "hard_target_gate_count": 4,
        "hard_source_gate_count": 6,
        "per_seed_results_are_diagnostics_only": True,
    }


def test_pooled_sufficient_qualification_matches_authoritative_raw_arrays():
    statistics = [synthetic_seed_statistics(seed) for seed in (17, 29, 43)]
    sufficient = build_base_observation_head_qualification(
        [row for item in statistics for row in item["base_qualification_rows"]],
        [
            row
            for item in statistics
            for row in item["observation_head_qualification_rows"]
        ],
    )

    origin_count = 4
    truth_future = (
        1.0
        + np.arange(origin_count, dtype=np.float64)[:, None, None] * 0.01
        + np.arange(23, dtype=np.float64)[None, :, None] * 0.1
        + np.arange(4, dtype=np.float64)[None, None, :] * 0.1
    )
    target_hour_one = truth_future[:, 0, :]
    full_targets = np.concatenate(
        (target_hour_one[:, None, :], truth_future), axis=1
    )
    full_base = full_targets + 0.11
    observations = (
        np.arange(origin_count, dtype=np.float64)[:, None] * 0.01
        + np.arange(6, dtype=np.float64)[None, :] * 0.1
    )
    issue_stage = observations + 0.20
    repeats = 3
    authoritative = qualification_module.evaluate_base_and_observation_head_qualification(
        base_predictions_m=np.concatenate([full_base] * repeats, axis=0),
        base_targets_m=np.concatenate([full_targets] * repeats, axis=0),
        target_issue_stage_m=np.concatenate([issue_stage[:, 1:5]] * repeats, axis=0),
        observation_head_predictions_m=np.concatenate(
            [observations + 0.10] * repeats, axis=0
        ),
        realtime_observations_t_plus_1_m=np.concatenate(
            [observations] * repeats, axis=0
        ),
        source_issue_stage_m=np.concatenate([issue_stage] * repeats, axis=0),
        augmented_design_singular_values=np.arange(33, 0, -1, dtype=np.float64),
        augmented_design_rank=33,
        augmented_design_condition_number=33.0,
    )

    for target_row in sufficient["target_pooled_results"]:
        expected = authoritative["base_forecast"]["target_results"][
            target_row["target_station"]
        ]
        assert target_row["first_six_cell_count"] == expected["sample_count"] * 6
        assert target_row["full_twenty_four_cell_count"] == expected["sample_count"] * 24
        assert target_row["base_first_six_mae_m"] == pytest.approx(
            expected["mean_absolute_error_issue_horizon_1_to_6_m"],
            rel=1e-12,
            abs=1e-12,
        )
        assert target_row["persistence_first_six_mae_m"] == pytest.approx(
            expected["persistence_mean_absolute_error_issue_horizon_1_to_6_m"],
            rel=1e-12,
            abs=1e-12,
        )
        assert target_row["base_full_twenty_four_rmse_m"] == pytest.approx(
            expected["root_mean_squared_error_issue_horizon_1_to_24_m"],
            rel=1e-12,
            abs=1e-12,
        )
        assert target_row["base_full_twenty_four_nse"] == pytest.approx(
            expected["nash_sutcliffe_efficiency_issue_horizon_1_to_24"],
            rel=1e-12,
            abs=1e-12,
        )
        assert target_row["passed"] is expected["passes"]

    for source_row in sufficient["observation_head_pooled_results"]:
        expected = authoritative["realtime_observation_head"]["source_results"][
            source_row["source_station"]
        ]
        assert source_row["cell_count"] == expected["sample_count"]
        assert source_row["head_mae_m"] == pytest.approx(
            expected["mean_absolute_error_t_plus_1_m"], rel=1e-12, abs=1e-12
        )
        assert source_row["persistence_mae_m"] == pytest.approx(
            expected["persistence_mean_absolute_error_t_plus_1_m"],
            rel=1e-12,
            abs=1e-12,
        )
        assert source_row["head_bias_m"] == pytest.approx(
            expected["mean_bias_t_plus_1_m"], rel=1e-12, abs=1e-12
        )
        assert source_row["passed"] is expected["passes"]
    assert sufficient["passed"] is authoritative["passes"]


def test_observation_head_design_rank_must_be_positive():
    diagnostics = [
        dict(row["observation_head_design_diagnostic"])
        for row in _artifact_identities()
    ]
    diagnostics[0]["augmented_design_rank"] = 0
    with pytest.raises(ValueError, match="augmented rank"):
        evaluation_module._validated_observation_head_design_diagnostics(
            diagnostics
        )


def test_observation_head_report_rejects_self_consistent_non_global_selection(
    tmp_path,
):
    head_path = tmp_path / "realtime_observation_head.pt"
    selected_hash = "%064x" % 8
    torch.save(
        {
            "seed": 17,
            "selected_ridge_strength": 1.0,
            "coefficient_float32_sha256": selected_hash,
        },
        head_path,
    )
    candidates = []
    for index, ridge in enumerate(evaluation_module.FROZEN_RIDGE_STRENGTHS):
        candidates.append(
            {
                "ridge_strength": ridge,
                "selection_mean_absolute_error_m": 0.1 + 0.01 * index,
                "station_selection_mean_absolute_error_m": [0.1] * 6,
                "augmented_design_singular_values": [
                    float(value) for value in range(33, 0, -1)
                ],
                "augmented_design_rank": 33,
                "augmented_design_condition_number": 33.0,
                "coefficient_float64_sha256": "%064x" % (index + 100),
                "coefficient_float32_sha256": "%064x" % (index + 1),
            }
        )
    (tmp_path / "ridge_candidate_diagnostics.json").write_text(
        json.dumps(
            {
                "selected_ridge_strength": 1.0,
                "selected_coefficient_float32_sha256": selected_hash,
                "candidates": candidates,
            }
        ),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="global-minimum"):
        evaluation_module._read_observation_head_design_diagnostic(
            head_path, seed=17
        )


def test_three_seed_grid_verifier_freezes_1656_lead_summaries():
    statistics = [synthetic_seed_statistics(seed) for seed in (17, 29, 43)]
    grid = verify_sufficient_grid(
        [row for seed in statistics for row in seed["future_rows"]],
        [row for seed in statistics for row in seed["analysis_observation_rows"]],
        [row for seed in statistics for row in seed["analysis_target_rows"]],
        [row for seed in statistics for row in seed["state_difference_rows"]],
    )
    assert grid["nonempty_block_count"] == 2
    assert grid["future_rows_per_seed"] == 2 * 6 * 4 * 23
    assert grid["analysis_observation_rows_per_seed"] == 2 * 6
    assert grid["analysis_target_rows_per_seed"] == 2 * 6 * 4
    assert grid["state_difference_rows_per_seed"] == 2 * 6 * 23
    assert grid["source_target_lead_summary_rows"] == 1656


def test_grid_verifier_rejects_duplicate_observation_target_and_state_keys():
    statistics = [synthetic_seed_statistics(seed) for seed in (17, 29, 43)]
    future = [row for seed in statistics for row in seed["future_rows"]]
    observation = [
        row for seed in statistics for row in seed["analysis_observation_rows"]
    ]
    target = [row for seed in statistics for row in seed["analysis_target_rows"]]
    state = [row for seed in statistics for row in seed["state_difference_rows"]]
    for table_name, table in (
        ("analysis observation", observation),
        ("analysis target", target),
        ("state difference", state),
    ):
        corrupted = list(table)
        corrupted[-1] = dict(corrupted[0])
        arguments = {
            "observation": observation,
            "target": target,
            "state": state,
        }
        arguments[
            {
                "analysis observation": "observation",
                "analysis target": "target",
                "state difference": "state",
            }[table_name]
        ] = corrupted
        with pytest.raises(ValueError, match="exact unique key grid"):
            verify_sufficient_grid(
                future,
                arguments["observation"],
                arguments["target"],
                arguments["state"],
            )


def test_writer_creates_complete_non_overwriting_evaluation(tmp_path):
    statistics = [synthetic_seed_statistics(seed) for seed in (17, 29, 43)]
    output = tmp_path / "new_evaluation"
    write_development_evaluation(
        output,
        statistics,
        base_observation_head_qualification={"passed": True},
        identity_gate_details={
            "four_normalization_identities_match": True,
            "boundary_future_target_access_is_zero": True,
            "held_out_2024_target_access_is_zero": True,
        },
        dependency_perturbation_evidence={
            "sample_identity_sha256": "0" * 64,
            "original_observation_normalized": np.zeros((2, 6)),
            "perturbed_observation_normalized": np.ones((2, 6)) * 0.01,
            "original_posterior_observation_normalized": np.ones((2, 6)) * 0.05,
            "perturbed_posterior_observation_normalized": np.ones((2, 6)) * 0.055,
        },
        data_access_audit=_data_access_audit(),
        frozen_artifact_identities=_artifact_identities(),
        registered_run_identity=_run_identity(),
        repeat_count=200,
        random_seed=20260901,
        synthetic_test_mode=True,
    )
    assert output.is_dir()
    required = {
        "future_sufficient_statistics.csv",
        "analysis_observation_sufficient_statistics.csv",
        "analysis_target_sufficient_statistics.csv",
        "state_difference_sufficient_statistics.csv",
        "base_and_three_branch_forecast_metrics.csv",
        "source_target_lead_metrics.csv",
        "source_target_window_metrics.csv",
        "six_source_four_target_gain_matrix.csv",
        "internal_four_by_four_gain_matrix.csv",
        "boundary_to_internal_gain_matrix.csv",
        "analysis_realtime_observation_diagnostics.csv",
        "analysis_target_space_gain_matrix.csv",
        "forecast_movement_matrix.csv",
        "reciprocal_direction_summary.csv",
        "development_gate_decision.json",
        "completion_manifest.json",
    }
    assert required.issubset({path.name for path in output.iterdir()})
    with (output / "source_target_lead_metrics.csv").open(
        encoding="utf-8", newline=""
    ) as handle:
        assert len(list(csv.DictReader(handle))) == 1656
    manifest = (output / "completion_manifest.json").read_text(encoding="utf-8")
    assert '"held_out_2024_target_access_count": 0' in manifest
    assert '"boundary_future_target_access_count": 0' in manifest
    with pytest.raises(FileExistsError):
        write_development_evaluation(
            output,
            statistics,
            base_observation_head_qualification={"passed": True},
            identity_gate_details={"identity": True},
            dependency_perturbation_evidence={
                "sample_identity_sha256": "0" * 64,
                "original_observation_normalized": np.zeros((1, 6)),
                "perturbed_observation_normalized": np.ones((1, 6)) * 0.01,
                "original_posterior_observation_normalized": np.ones((1, 6)) * 0.05,
                "perturbed_posterior_observation_normalized": np.ones((1, 6)) * 0.055,
            },
            data_access_audit=_data_access_audit(),
            frozen_artifact_identities=_artifact_identities(),
            registered_run_identity=_run_identity(),
            repeat_count=200,
            random_seed=20260901,
            synthetic_test_mode=True,
        )


def test_formal_writer_rejects_nonfrozen_bootstrap_settings(tmp_path):
    statistics = [synthetic_seed_statistics(seed) for seed in (17, 29, 43)]
    with pytest.raises(ValueError, match="frozen bootstrap"):
        write_development_evaluation(
            tmp_path / "formal",
            statistics,
            base_observation_head_qualification={"passed": True},
            identity_gate_details={"identity": True},
            dependency_perturbation_evidence={
                "sample_identity_sha256": "0" * 64,
                "original_observation_normalized": np.zeros((1, 6)),
                "perturbed_observation_normalized": np.ones((1, 6)) * 0.01,
                "original_posterior_observation_normalized": np.ones((1, 6)) * 0.05,
                "perturbed_posterior_observation_normalized": np.ones((1, 6)) * 0.055,
            },
            data_access_audit=_data_access_audit(),
            frozen_artifact_identities=_artifact_identities(),
            registered_run_identity=_run_identity(),
            repeat_count=10,
            random_seed=1,
            synthetic_test_mode=False,
        )


def test_formal_writer_reuses_and_manifests_preclaimed_access_marker(tmp_path):
    output = tmp_path / "formal_evaluation"
    artifacts = _artifact_identities()
    run_identity = _run_identity()
    evaluation_module._claim_development_access_before_loader(
        output.with_name(output.name + ".partial"),
        registered_run_identity=run_identity,
        frozen_artifact_identities=artifacts,
    )
    write_development_evaluation(
        output,
        [
            synthetic_seed_statistics(
                seed,
                experiment_id=evaluation_module.FORMAL_DEVELOPMENT_EXPERIMENT_ID,
            )
            for seed in (17, 29, 43)
        ],
        base_observation_head_qualification={"passed": True},
        identity_gate_details={"all_frozen_identities_match": True},
        dependency_perturbation_evidence={
            "sample_identity_sha256": "0" * 64,
            "original_observation_normalized": np.zeros((1, 6)),
            "perturbed_observation_normalized": np.ones((1, 6)) * 0.01,
            "original_posterior_observation_normalized": np.ones((1, 6)) * 0.05,
            "perturbed_posterior_observation_normalized": np.ones((1, 6)) * 0.055,
        },
        data_access_audit=_data_access_audit(),
        frozen_artifact_identities=artifacts,
        registered_run_identity=run_identity,
        repeat_count=20_000,
        random_seed=20_260_901,
        synthetic_test_mode=False,
    )
    marker_path = output / evaluation_module.DEVELOPMENT_ACCESS_MARKER_NAME
    marker = json.loads(marker_path.read_text(encoding="utf-8"))
    manifest = json.loads(
        (output / "completion_manifest.json").read_text(encoding="utf-8")
    )
    assert manifest["development_access_started_before_loader"] is True
    assert manifest["development_access_started_at_utc"] == marker["claimed_at_utc"]
    assert manifest["development_access_marker_sha256"] == hashlib.sha256(
        marker_path.read_bytes()
    ).hexdigest()
    assert evaluation_module.DEVELOPMENT_ACCESS_MARKER_NAME in {
        row["name"] for row in manifest["files"]
    }


@pytest.mark.parametrize(
    "fail_after_loader", (False, True), ids=("complete", "interrupted")
)
def test_formal_runner_loads_development_once_and_shares_one_dataset(
    tmp_path, monkeypatch, fail_after_loader
):
    remote_root = tmp_path / "formal_root"
    input_root = remote_root / "inputs" / "pre2024-four-target-v1"
    input_root.mkdir(parents=True)
    tide_path = remote_root / "run" / "tide_model.json"
    tide_path.parent.mkdir(parents=True)
    tide_path.write_text("{}\n", encoding="utf-8")
    output = remote_root / evaluation_module.FORMAL_EVALUATION_RELATIVE_PATH
    audit_output = remote_root / evaluation_module.FORMAL_AUDIT_RELATIVE_PATH
    smoke = remote_root / "runs/development_evaluation_smoke/attempt_001"
    tasks = []
    artifact_paths = {}
    for seed in (17, 29, 43):
        base_dir = remote_root / f"runs/base/s{seed}/attempt_001"
        head_dir = remote_root / f"runs/observation_head/s{seed}/attempt_001"
        filter_dir = remote_root / f"runs/filter/s{seed}/attempt_001"
        for directory in (base_dir, head_dir, filter_dir):
            directory.mkdir(parents=True)
        base = base_dir / "best_checkpoint.pt"
        head = head_dir / "realtime_observation_head.pt"
        selected_filter = filter_dir / "best_filter_checkpoint.pt"
        base.write_bytes(("base-%d" % seed).encode())
        head.write_bytes(("head-%d" % seed).encode())
        selected_filter.write_bytes(("filter-%d" % seed).encode())
        artifact_paths[seed] = (base, head, selected_filter)
        tasks.extend(
            [
                {
                    "stage": "base_training",
                    "seed": seed,
                    "registered_output_path": str(base_dir),
                },
                {
                    "stage": "observation_head",
                    "seed": seed,
                    "registered_output_path": str(head_dir),
                },
                {
                    "stage": "filter_training",
                    "seed": seed,
                    "registered_output_path": str(filter_dir),
                    "registered_base_checkpoint_path": str(base),
                    "registered_observation_head_path": str(head),
                },
            ]
        )
    post_tasks = [
        {
            "stage": "development_2023_evaluation",
            "registered_smoke_path": str(smoke),
            "registered_output_path": str(output),
        },
        {
            "stage": "independent_audit",
            "registered_output_path": str(audit_output),
            "registered_evaluation_output_path": str(output),
        },
    ]
    registry = {
        "authorization": {
            "development_2023_evaluation_authorized": True,
            "heldout_2024_target_access_authorized": False,
            "formal_command_confirmation": evaluation_module.FORMAL_CONFIRMATION,
        },
        "hpc": {
            "remote_root": str(remote_root),
            "isolated_input_root": str(input_root),
            "tide_model_path": str(tide_path),
        },
        "optimization": {},
        "tasks": tasks,
        "post_training_tasks": post_tasks,
    }
    registry_path = tmp_path / "registry.json"
    registry_path.write_text(json.dumps(registry), encoding="utf-8")

    normalization = data_module.FourSpaceNormalization(
        history_stage=data_module.SpaceNormalization(
            data_module.NORMALIZATION_HISTORY_STAGE,
            np.zeros(6),
            np.ones(6),
            np.ones(6, dtype=np.int64),
        ),
        future_tide=data_module.SpaceNormalization(
            data_module.NORMALIZATION_FUTURE_TIDE,
            np.zeros(1),
            np.ones(1),
            np.ones(1, dtype=np.int64),
        ),
        analysis_stage=data_module.SpaceNormalization(
            data_module.NORMALIZATION_ANALYSIS_STAGE,
            np.zeros(6),
            np.ones(6),
            np.ones(6, dtype=np.int64),
        ),
        retrospective_target=data_module.SpaceNormalization(
            data_module.NORMALIZATION_RETROSPECTIVE_TARGET,
            np.zeros(4),
            np.ones(4),
            np.ones(4, dtype=np.int64),
        ),
    )
    normalization_document = evaluation_module._normalization_document(normalization)
    audit_value = data_module.DataAccessAudit(**_data_access_audit())
    shared_dataset = [object()]
    fake_data = SimpleNamespace(
        normalization=normalization,
        access_audit=audit_value,
    )
    counters = {"load": 0, "build": 0, "materialize": 0}
    event_order = []

    class FrozenModel:
        training = False

        @staticmethod
        def parameters():
            return ()

    monkeypatch.setattr(runner_module, "validate_registry_document", lambda value: None)
    monkeypatch.setattr(
        runner_module,
        "load_registered_post_training_task",
        lambda path, *, stage: (
            registry,
            next(row for row in post_tasks if row["stage"] == stage),
        ),
    )
    monkeypatch.setattr(
        runner_module,
        "verify_output_directory",
        lambda path: {"status": "technical_pass_development_evaluation_smoke"},
    )
    manifest_path = input_root / "four_target_input_manifest.json"
    manifest_path.write_text("{}\n", encoding="utf-8")
    monkeypatch.setattr(
        runner_module,
        "verify_isolated_input_manifest",
        lambda root, document: {
            "manifest_path": str(manifest_path),
            "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        },
    )

    def load_filter(path, *, seed, device):
        base, head, selected_filter = artifact_paths[seed]
        digest = lambda value: hashlib.sha256(value.read_bytes()).hexdigest()
        return FrozenModel(), {
            "base_checkpoint_sha256": digest(base),
            "observation_head_sha256": digest(head),
            "base_normalization": normalization_document,
            "filter_checkpoint_path": str(selected_filter),
            "filter_checkpoint_sha256": digest(selected_filter),
            "filter_completion_manifest_sha256": "%064x" % seed,
            "normalization_sha256": evaluation_module._mapping_sha256(
                normalization_document
            ),
        }

    monkeypatch.setattr(
        runner_module,
        "load_registered_frozen_filter_for_evaluation",
        load_filter,
    )
    monkeypatch.setattr(
        evaluation_module,
        "_read_observation_head_design_diagnostic",
        lambda path, *, seed: {
            "seed": seed,
            "selection_report_path": str(path.parent / "ridge_candidate_diagnostics.json"),
            "selection_report_sha256": "%064x" % (seed + 400),
            "coefficient_float32_sha256": "%064x" % (seed + 500),
            "selected_ridge_strength": 0.1,
            "augmented_design_singular_values": [
                float(value) for value in range(33, 0, -1)
            ],
            "augmented_design_rank": 33,
            "augmented_design_condition_number": 33.0,
        },
    )

    def load_once(root, tide):
        marker_path = output.with_name(output.name + ".partial") / (
            evaluation_module.DEVELOPMENT_ACCESS_MARKER_NAME
        )
        assert marker_path.is_file()
        json.loads(marker_path.read_text(encoding="utf-8"))
        event_order.append("marker_then_loader")
        counters["load"] += 1
        return fake_data

    def build_once(data):
        counters["build"] += 1
        return {
            "training": object(),
            "selection": object(),
            "development_gate": shared_dataset,
        }

    monkeypatch.setattr(data_module, "load_development_data", load_once)
    monkeypatch.setattr(data_module, "build_split_datasets", build_once)
    monkeypatch.setattr(
        data_module, "assert_forbidden_target_access_is_zero", lambda value: None
    )

    def materialize(**kwargs):
        counters["materialize"] += 1
        assert kwargs["development_dataset"] is shared_dataset
        assert set(kwargs["frozen_models"]) == {17, 29, 43}
        if fail_after_loader:
            raise RuntimeError("injected failure after development load")
        return [synthetic_seed_statistics(seed) for seed in (17, 29, 43)], {
            "sample_identity_sha256": "0" * 64,
            "original_observation_normalized": np.zeros((1, 6)),
            "perturbed_observation_normalized": np.ones((1, 6)) * 0.01,
            "original_posterior_observation_normalized": np.ones((1, 6)) * 0.05,
            "perturbed_posterior_observation_normalized": np.ones((1, 6)) * 0.055,
        }

    monkeypatch.setattr(
        evaluation_module, "materialize_shared_development_statistics", materialize
    )
    captured = {}

    def write_evaluation(path, statistics, **kwargs):
        captured["statistics"] = statistics
        captured["kwargs"] = kwargs
        path.mkdir(parents=True)
        (path / "completion_manifest.json").write_text("{}\n", encoding="utf-8")
        return path

    monkeypatch.setattr(evaluation_module, "write_development_evaluation", write_evaluation)

    def write_audit(evaluation, destination):
        destination.mkdir(parents=True)
        report = destination / "independent_audit_report.json"
        report.write_text("{}\n", encoding="utf-8")
        return report

    monkeypatch.setattr(audit_module, "write_independent_audit", write_audit)
    arguments = {
        "registry_path": registry_path,
        "input_root": input_root,
        "tide_model_path": tide_path,
        "output_directory": output,
        "audit_directory": audit_output,
        "device": "cpu",
        "confirmation": evaluation_module.FORMAL_CONFIRMATION,
    }
    if fail_after_loader:
        with pytest.raises(RuntimeError, match="injected failure"):
            execute_frozen_2023_development_evaluation_once(**arguments)
        partial = output.with_name(output.name + ".partial")
        marker_path = partial / evaluation_module.DEVELOPMENT_ACCESS_MARKER_NAME
        marker = json.loads(marker_path.read_text(encoding="utf-8"))
        assert partial.is_dir()
        assert marker["status"] == "development_access_claimed_before_loader"
        assert marker["frozen_artifact_count"] == 9
        assert event_order == ["marker_then_loader"]
        with pytest.raises(FileExistsError, match="already exists"):
            execute_frozen_2023_development_evaluation_once(**arguments)
        assert counters == {"load": 1, "build": 1, "materialize": 1}
        assert event_order == ["marker_then_loader"]
        return

    result = execute_frozen_2023_development_evaluation_once(**arguments)
    assert counters == {"load": 1, "build": 1, "materialize": 1}
    assert event_order == ["marker_then_loader"]
    assert result["development_loader_call_count"] == 1
    assert result["development_dataset_instance_count"] == 1
    assert result["seed_evaluation_count"] == 3
    assert captured["kwargs"]["synthetic_test_mode"] is False
    assert captured["kwargs"]["data_access_audit"] == (
        evaluation_module._validated_data_access_audit(_data_access_audit())
    )
