"""Independent-reconstruction and direct-copy dependency audit tests."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import pytest
import torch


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "scripts" / "analysis"
if str(ANALYSIS) not in sys.path:
    sys.path.insert(0, str(ANALYSIS))

import audit_zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1 as audit_module  # noqa: E402,E501
from audit_zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1 import (  # noqa: E402
    audit_completed_development_evaluation,
    audit_observation_dependency_perturbation,
    write_independent_audit,
)
from zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1 import (  # noqa: E402
    accumulate_development_sufficient_statistics,
    write_development_evaluation,
)


def _data_access_audit():
    bytes_by_path = {
        "dataset_config.json": 2854,
        "realtime_features/datong_realtime_features.csv": 5_485_506,
        "realtime_features/nanjing_realtime_features.csv": 5_452_340,
        "realtime_features/zhenjiang_realtime_features.csv": 5_490_493,
        "realtime_features/jiangyin_realtime_features.csv": 5_451_807,
        "realtime_features/xuliujing_realtime_features.csv": 5_452_448,
        "realtime_features/wusongkou_realtime_features.csv": 5_449_542,
        "retrospective_targets/nanjing_retrospective_targets.csv": 5_453_455,
        "retrospective_targets/zhenjiang_retrospective_targets.csv": 5_491_015,
        "retrospective_targets/jiangyin_retrospective_targets.csv": 5_452_821,
        "retrospective_targets/xuliujing_retrospective_targets.csv": 5_453_528,
    }
    csv_paths = [path for path in bytes_by_path if path.endswith(".csv")]
    return {
        "opened_paths": list(bytes_by_path),
        "bytes_read_by_path": bytes_by_path,
        "rows_parsed_by_path": {path: 61_344 for path in csv_paths},
        "values_loaded_by_path": {path: 61_344 for path in csv_paths},
        "target_rows_by_period": {
            "training": 175_296,
            "selection": 35_040,
            "development_gate": 35_040,
            "heldout_or_later": 0,
            "boundary_target": 0,
        },
        "astronomical_tide_model_open_count": 1,
        "development_feature_bytes_read": 4_685_966,
        "development_feature_rows_parsed": 52_560,
        "development_feature_values_loaded": 52_560,
        "development_target_bytes_read": 3_123_728,
        "development_target_rows_parsed": 35_040,
        "development_target_values_loaded": 35_040,
        "heldout_target_bytes_read": 0,
        "heldout_target_rows_parsed": 0,
        "heldout_target_values_loaded": 0,
        "boundary_target_bytes_read": 0,
        "boundary_target_rows_parsed": 0,
        "boundary_target_values_loaded": 0,
    }


def _artifact_identities():
    return [
        {
            "seed": seed,
            "base_checkpoint_path": "/synthetic/s%d/base.pt" % seed,
            "base_checkpoint_sha256": "%064x" % seed,
            "observation_head_path": "/synthetic/s%d/head.pt" % seed,
            "observation_head_sha256": "%064x" % (seed + 100),
            "filter_checkpoint_path": "/synthetic/s%d/filter.pt" % seed,
            "filter_checkpoint_sha256": "%064x" % (seed + 200),
            "filter_completion_manifest_sha256": "%064x" % (seed + 300),
            "observation_head_design_diagnostic": {
                "seed": seed,
                "selection_report_path": "/synthetic/s%d/ridge_candidate_diagnostics.json" % seed,
                "selection_report_sha256": "%064x" % (seed + 400),
                "coefficient_float32_sha256": "%064x" % (seed + 500),
                "selected_ridge_strength": 0.1,
                "augmented_design_singular_values": [
                    float(value) for value in range(33, 0, -1)
                ],
                "augmented_design_rank": 33,
                "augmented_design_condition_number": 33.0,
            },
        }
        for seed in (17, 29, 43)
    ]


def _run_identity():
    return {
        "registry_path": "/synthetic/registry.json",
        "registry_sha256": "a" * 64,
        "input_root_path": "/synthetic/input",
        "input_manifest_path": "/synthetic/input/manifest.json",
        "input_manifest_sha256": "b" * 64,
    }


def _seed(seed: int):
    origins = (
        "2023-01-01T00:00:00+08:00",
        "2023-01-02T00:00:00+08:00",
        "2023-01-15T00:00:00+08:00",
        "2023-01-16T00:00:00+08:00",
    )
    count = len(origins)
    truth = (
        1.0
        + np.arange(count, dtype=np.float64)[:, None, None] * 0.01
        + np.arange(23, dtype=np.float64)[None, :, None] * 0.1
        + np.arange(4, dtype=np.float64)[None, None, :] * 0.1
    )
    observation = (
        np.arange(count, dtype=np.float64)[:, None] * 0.01
        + np.arange(6, dtype=np.float64)[None, :] * 0.1
    )
    prior_observation = observation + 0.10
    posterior_observation = np.repeat(prior_observation[:, None, :], 6, axis=1)
    for source in range(6):
        posterior_observation[:, source, source] = observation[:, source] + 0.05
    prior_state = np.zeros((count, 23, 32), dtype=np.float64)
    updated_state = np.stack(
        [prior_state + 0.001 * (source + 1) for source in range(6)], axis=1
    )
    analysis_truth = truth[:, 0]
    return accumulate_development_sufficient_statistics(
        experiment_id="synthetic_audit_candidate",
        seed=seed,
        origin_times=origins,
        target_future_m=truth,
        analysis_target_m=analysis_truth,
        analysis_observation_m=observation,
        current_stage_m=observation + 0.20,
        base_issue_hour_one_forecast_m=analysis_truth + 0.11,
        base_deterministic_forecast_m=truth + 0.11,
        unscented_prior_forecast_m=truth + 0.10,
        updated_forecast_m=np.repeat((truth + 0.08)[:, None], 6, axis=1),
        analysis_prior_target_m=analysis_truth + 0.10,
        analysis_posterior_target_m=np.repeat(
            (analysis_truth + 0.08)[:, None], 6, axis=1
        ),
        analysis_prior_observation_m=prior_observation,
        analysis_posterior_observation_m=posterior_observation,
        analysis_kalman_gain=np.ones((count, 6, 32)) * 0.01,
        analysis_observation_contraction=np.ones((count, 6)) * 0.5,
        analysis_posterior_observation_variance_normalized=np.ones((count, 6))
        * 0.002,
        analysis_posterior_minimum_eigenvalue=np.ones((count, 6)) * 0.001,
        analysis_spectral_floor=np.ones((count, 6)) * 1e-12,
        observation_noise_standard_deviation_normalized=np.ones(6) * 0.1,
        unscented_prior_state_mean=prior_state,
        updated_state_mean=updated_state,
    )


def _evaluation(tmp_path: Path, *, direct_copy_evidence: bool = False) -> Path:
    output = tmp_path / "evaluation"
    original_observation = np.zeros((2, 6))
    perturbed_observation = np.ones((2, 6)) * 0.01
    if direct_copy_evidence:
        original_posterior = original_observation
        perturbed_posterior = perturbed_observation
    else:
        original_posterior = np.ones((2, 6)) * 0.05
        perturbed_posterior = np.ones((2, 6)) * 0.055
    write_development_evaluation(
        output,
        [_seed(seed) for seed in (17, 29, 43)],
        base_observation_head_qualification={"passed": True},
        identity_gate_details={
            "four_normalization_identities_match": True,
            "boundary_future_target_access_is_zero": True,
            "held_out_2024_target_access_is_zero": True,
        },
        dependency_perturbation_evidence={
            "sample_identity_sha256": "0" * 64,
            "original_observation_normalized": original_observation,
            "perturbed_observation_normalized": perturbed_observation,
            "original_posterior_observation_normalized": original_posterior,
            "perturbed_posterior_observation_normalized": perturbed_posterior,
        },
        data_access_audit=_data_access_audit(),
        frozen_artifact_identities=_artifact_identities(),
        registered_run_identity=_run_identity(),
        repeat_count=20000,
        random_seed=20260901,
        synthetic_test_mode=True,
    )
    return output


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _refresh_manifest_file_identity(directory: Path, file_name: str) -> None:
    manifest_path = directory / "completion_manifest.json"
    document = json.loads(manifest_path.read_text(encoding="utf-8"))
    path = directory / file_name
    for row in document["files"]:
        if row["name"] == file_name:
            row["byte_count"] = path.stat().st_size
            row["sha256"] = _sha(path)
            break
    manifest_path.write_text(
        json.dumps(document, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def test_independent_audit_reconstructs_all_tables_intervals_and_gates(tmp_path):
    output = _evaluation(tmp_path)
    report = audit_completed_development_evaluation(output)
    assert report["status"] == "passed_independent_reconstruction"
    assert report["source_target_lead_row_count"] == 1656
    assert report["bootstrap_repeat_count"] == 20000
    assert report["holm_internal_direction_count"] == 12
    assert report["holm_boundary_direction_count"] == 8
    assert report["main_metrics_module_imported"] is False


def test_auditor_source_does_not_import_main_metric_or_evaluation_module():
    source = (
        ANALYSIS
        / "audit_zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1.py"
    ).read_text(encoding="utf-8")
    assert "import zhenjiang_six_source_four_target_d32_gru_ukf_metrics_v1" not in source
    assert "from zhenjiang_six_source_four_target_d32_gru_ukf_metrics_v1" not in source
    assert "import zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1" not in source
    assert "from zhenjiang_six_source_four_target_d32_gru_ukf_development_evaluation_v1" not in source


def test_independent_audit_detects_tampered_matrix_even_with_refreshed_manifest(tmp_path):
    output = _evaluation(tmp_path)
    matrix_path = output / "six_source_four_target_gain_matrix.csv"
    with matrix_path.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
        fields = list(rows[0])
    rows[0]["measurement_update_gain_m"] = "123.0"
    with matrix_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    _refresh_manifest_file_identity(output, matrix_path.name)
    with pytest.raises(RuntimeError, match="float differs"):
        audit_completed_development_evaluation(output)


def test_independent_audit_rejects_bootstrap_contract_drift(tmp_path):
    output = _evaluation(tmp_path)
    bootstrap_path = output / "bootstrap_summary.json"
    document = json.loads(bootstrap_path.read_text(encoding="utf-8"))
    document["sampling"]["repeat_count"] = 200
    bootstrap_path.write_text(
        json.dumps(document, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    _refresh_manifest_file_identity(output, bootstrap_path.name)
    with pytest.raises(RuntimeError, match="repeat-count drift"):
        audit_completed_development_evaluation(output)


def test_independent_audit_reconstructs_instead_of_trusting_qualification_pass(
    tmp_path,
):
    output = _evaluation(tmp_path)
    qualification_path = output / "base_observation_head_qualification.json"
    document = json.loads(qualification_path.read_text(encoding="utf-8"))
    document["passed"] = False
    qualification_path.write_text(
        json.dumps(document, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    _refresh_manifest_file_identity(output, qualification_path.name)
    with pytest.raises(RuntimeError, match="exact value differs"):
        audit_completed_development_evaluation(output)


@pytest.mark.parametrize("tamper", ("report_sha256", "singular_value"))
def test_independent_audit_rejects_tampered_head_design_evidence(
    tmp_path, tamper
):
    output = _evaluation(tmp_path)
    manifest_path = output / "completion_manifest.json"
    document = json.loads(manifest_path.read_text(encoding="utf-8"))
    diagnostic = document["frozen_artifact_identities"][0][
        "observation_head_design_diagnostic"
    ]
    if tamper == "report_sha256":
        diagnostic["selection_report_sha256"] = "f" * 64
    else:
        diagnostic["augmented_design_singular_values"][0] += 1.0
    manifest_path.write_text(
        json.dumps(document, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    with pytest.raises(RuntimeError, match="(exact value|float) differs"):
        audit_completed_development_evaluation(output)


def test_dependency_perturbation_rejects_direct_observation_copy():
    observation = np.zeros((3, 6), dtype=np.float64)
    perturbed = observation + 0.2
    with pytest.raises(RuntimeError, match="strictly between"):
        audit_observation_dependency_perturbation(
            observation,
            perturbed,
            observation,
            perturbed,
        )
    prior = np.ones((3, 6), dtype=np.float64) * 0.1
    posterior = 0.5 * observation + 0.5 * prior
    posterior_perturbed = 0.5 * perturbed + 0.5 * prior
    report = audit_observation_dependency_perturbation(
        observation,
        perturbed,
        posterior,
        posterior_perturbed,
    )
    assert report["status"] == "passed"
    assert report["minimum_response_slope"] == pytest.approx(0.5)
    assert report["maximum_response_slope"] == pytest.approx(0.5)


def test_completed_evaluation_fails_when_recorded_dependency_is_direct_copy(
    tmp_path,
):
    output = _evaluation(tmp_path, direct_copy_evidence=True)
    with pytest.raises(RuntimeError, match="strictly between"):
        audit_completed_development_evaluation(output)


def test_audit_output_is_non_overwriting(tmp_path):
    output = _evaluation(tmp_path)
    audit_directory = tmp_path / "evaluation_audit"
    report_path = write_independent_audit(output, audit_directory)
    assert report_path.is_file()
    assert (audit_directory / "completion_manifest.json").is_file()
    with pytest.raises(FileExistsError):
        write_independent_audit(output, audit_directory)


def test_independent_audit_rejects_wrong_frozen_input_byte_identity(tmp_path):
    output = _evaluation(tmp_path)
    manifest_path = output / "completion_manifest.json"
    document = json.loads(manifest_path.read_text(encoding="utf-8"))
    document["development_data_access_audit"]["bytes_read_by_path"][
        "dataset_config.json"
    ] += 1
    manifest_path.write_text(
        json.dumps(document, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    with pytest.raises(RuntimeError, match="per-path byte identity"):
        audit_completed_development_evaluation(output)


def test_independent_audit_rejects_development_access_marker_mode_drift(tmp_path):
    output = _evaluation(tmp_path)
    manifest_path = output / "completion_manifest.json"
    document = json.loads(manifest_path.read_text(encoding="utf-8"))
    document["development_access_started_before_loader"] = True
    manifest_path.write_text(
        json.dumps(document, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    with pytest.raises(RuntimeError, match="synthetic development-access marker"):
        audit_completed_development_evaluation(output)


def test_independent_auditor_rejects_self_consistent_non_global_head_selection(
    tmp_path,
):
    artifacts = []
    for seed in (17, 29, 43):
        directory = tmp_path / f"s{seed}"
        directory.mkdir()
        head_path = directory / "realtime_observation_head.pt"
        candidates = []
        for index, ridge in enumerate(audit_module.FROZEN_RIDGE_STRENGTHS):
            candidates.append(
                {
                    "ridge_strength": ridge,
                    "selection_mean_absolute_error_m": 0.1 + 0.01 * index,
                    "station_selection_mean_absolute_error_m": [0.1] * 6,
                    "augmented_design_singular_values": [
                        float(value) for value in range(33, 0, -1)
                    ],
                    "augmented_design_rank": 33,
                    "augmented_design_condition_number": 33.0,
                    "coefficient_float64_sha256": "%064x" % (index + 100),
                    "coefficient_float32_sha256": "%064x" % (index + 1),
                }
            )
        selected = candidates[-1] if seed == 17 else candidates[0]
        torch.save(
            {
                "seed": seed,
                "selected_ridge_strength": selected["ridge_strength"],
                "coefficient_float32_sha256": selected[
                    "coefficient_float32_sha256"
                ],
            },
            head_path,
        )
        report_path = directory / "ridge_candidate_diagnostics.json"
        report_path.write_text(
            json.dumps(
                {
                    "selected_ridge_strength": selected["ridge_strength"],
                    "selected_coefficient_float32_sha256": selected[
                        "coefficient_float32_sha256"
                    ],
                    "candidates": candidates,
                }
            ),
            encoding="utf-8",
        )
        artifacts.append(
            {
                "seed": seed,
                "observation_head_path": str(head_path),
                "observation_head_design_diagnostic": {
                    "seed": seed,
                    "selection_report_path": str(report_path),
                    "selection_report_sha256": _sha(report_path),
                    "coefficient_float32_sha256": selected[
                        "coefficient_float32_sha256"
                    ],
                    "selected_ridge_strength": selected["ridge_strength"],
                    "augmented_design_singular_values": selected[
                        "augmented_design_singular_values"
                    ],
                    "augmented_design_rank": selected["augmented_design_rank"],
                    "augmented_design_condition_number": selected[
                        "augmented_design_condition_number"
                    ],
                },
            }
        )
    with pytest.raises(RuntimeError, match="global-minimum"):
        audit_module._audit_observation_head_design_diagnostics(
            {
                "synthetic_test_mode": False,
                "frozen_artifact_identities": artifacts,
            }
        )
