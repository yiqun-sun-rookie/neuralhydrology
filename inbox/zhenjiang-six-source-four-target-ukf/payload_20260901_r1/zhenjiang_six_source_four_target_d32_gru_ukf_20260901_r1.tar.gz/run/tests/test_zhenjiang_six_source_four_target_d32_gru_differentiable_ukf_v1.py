"""Synthetic tests for the six-source/four-target differentiable filter."""

from __future__ import annotations

import math
from pathlib import Path
import sys

import pytest
import torch
from torch import nn


ROOT = Path(__file__).resolve().parents[1]
MODELING = ROOT / "scripts" / "modeling"
if str(MODELING) not in sys.path:
    sys.path.insert(0, str(MODELING))

from zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_v1 import (  # noqa: E402
    DifferentiableMerweUnscentedTransform,
    GaussianState,
    PositiveDiagonalCovariance,
    SixSourceFourTargetD32GRUDifferentiableUKF,
    stabilize_covariance,
)


class ToyBackbone(nn.Module):
    """Small deterministic backbone with the formal public interface."""

    state_size = 32

    def __init__(self) -> None:
        super().__init__()
        self.history_projection = nn.Linear(24 * 6, 32)
        self.tide_projection = nn.Linear(1, 32, bias=False)
        self.realtime_observation_decoder = nn.Linear(32, 6)
        self.retrospective_target_decoder = nn.Linear(32, 4)
        generator = torch.Generator().manual_seed(7)
        with torch.no_grad():
            for parameter in self.parameters():
                parameter.copy_(
                    torch.randn(
                        parameter.shape,
                        generator=generator,
                        dtype=torch.float32,
                    )
                    * 0.03
                )
            # Every observation row must see state uncertainty.
            self.realtime_observation_decoder.weight[:, 0] += 0.2

    def encode_history(self, history: torch.Tensor) -> torch.Tensor:
        return torch.tanh(self.history_projection(history.reshape(history.shape[0], -1)))

    def transition_step(
        self, state: torch.Tensor, tide: torch.Tensor
    ) -> torch.Tensor:
        return state + 0.015 * torch.sin(state) + self.tide_projection(
            tide[:, None]
        )

    def decode_realtime_observation(self, state: torch.Tensor) -> torch.Tensor:
        return self.realtime_observation_decoder(state)

    def decode_retrospective_target(self, state: torch.Tensor) -> torch.Tensor:
        return self.retrospective_target_decoder(state)


@pytest.fixture
def adapter() -> SixSourceFourTargetD32GRUDifferentiableUKF:
    return SixSourceFourTargetD32GRUDifferentiableUKF(ToyBackbone())


def _inputs(batch_size: int = 1):
    generator = torch.Generator().manual_seed(23)
    history = torch.randn(batch_size, 24, 6, generator=generator) * 0.1
    tide = torch.randn(batch_size, 24, generator=generator) * 0.05
    observation = torch.randn(batch_size, 6, generator=generator) * 0.1
    return history, tide, observation


def test_merwe_transform_has_65_points_and_float64_covariance():
    transform = DifferentiableMerweUnscentedTransform()
    state = GaussianState(
        torch.zeros(2, 32, dtype=torch.float64),
        torch.eye(32, dtype=torch.float64)[None].expand(2, -1, -1) * 0.001,
    )
    points = transform.sigma_points(state)
    assert points.shape == (2, 65, 32)
    assert points.dtype == torch.float64
    assert transform.mean_weights.dtype == torch.float64
    assert transform.covariance_weights.dtype == torch.float64


@pytest.mark.parametrize("variance", [0.001, 0.01])
def test_softplus_standard_deviation_parameterization_round_trips(variance):
    covariance = PositiveDiagonalCovariance(4, variance)
    expected_raw = math.log(math.expm1(math.sqrt(variance) - 1e-4))
    assert covariance.raw_standard_deviation.dtype == torch.float64
    assert torch.allclose(
        covariance.raw_standard_deviation,
        torch.full((4,), expected_raw, dtype=torch.float64),
        atol=0.0,
        rtol=0.0,
    )
    assert torch.allclose(
        covariance.standard_deviation(),
        torch.full((4,), math.sqrt(variance), dtype=torch.float64),
        atol=1e-15,
        rtol=1e-15,
    )
    assert torch.allclose(
        covariance.variance(),
        torch.full((4,), variance, dtype=torch.float64),
        atol=1e-15,
        rtol=1e-15,
    )


def test_saved_observation_head_must_be_float32():
    backbone = ToyBackbone().double()
    with pytest.raises(ValueError, match="saved float32"):
        SixSourceFourTargetD32GRUDifferentiableUKF(backbone)


def test_scalar_update_uses_joseph_form_and_strict_contraction(adapter):
    batch_size = 2
    mean = torch.randn(batch_size, 32, dtype=torch.float64) * 0.05
    covariance = (
        torch.eye(32, dtype=torch.float64)[None].expand(batch_size, -1, -1)
        * 0.004
    )
    prior = GaussianState(mean, covariance)
    observation = torch.tensor([0.2, -0.1], dtype=torch.float32)
    result = adapter.update_one_source(prior, observation, 2)
    posterior = result["posterior_state"]
    assert isinstance(posterior, GaussianState)
    h = adapter.backbone.realtime_observation_decoder.weight[2].double()
    gain = result["kalman_gain"]
    noise = adapter.observation_noise.variance()[2]
    identity = torch.eye(32, dtype=torch.float64)
    factor = identity[None] - torch.einsum("bi,j->bij", gain, h)
    expected = (
        factor @ covariance @ factor.transpose(-1, -2)
        + torch.einsum("bi,bj->bij", gain, gain) * noise
    )
    expected, _ = stabilize_covariance(expected)
    assert torch.allclose(posterior.covariance, expected, atol=1e-12, rtol=1e-10)
    contraction = result["observation_contraction"]
    assert bool((contraction > 0.0).all())
    assert bool((contraction < 1.0).all())
    eigenvalues = torch.linalg.eigvalsh(posterior.covariance)
    assert bool(
        (
            eigenvalues[:, 0]
            >= 0.99 * result["spectral_floor"]
        ).all()
    )


def test_forward_has_frozen_shapes_and_common_branch_identity(adapter):
    outputs = adapter(*_inputs(batch_size=2))
    assert outputs["base_deterministic_forecast"].shape == (2, 23, 4)
    assert outputs["base_deterministic_issue_hour_one_target"].shape == (2, 4)
    assert outputs["unscented_prior_forecast"].shape == (2, 23, 4)
    assert outputs["updated_forecast"].shape == (2, 6, 23, 4)
    assert outputs["analysis_prior_target"].shape == (2, 4)
    assert outputs["analysis_posterior_target"].shape == (2, 6, 4)
    assert outputs["analysis_kalman_gain"].shape == (2, 6, 32)
    copied_base = outputs["base_deterministic_forecast"][:, None].expand(-1, 6, -1, -1)
    copied_prior = outputs["unscented_prior_forecast"][:, None].expand(-1, 6, -1, -1)
    assert torch.equal(copied_base[:, 0], copied_base[:, 5])
    assert torch.equal(copied_prior[:, 0], copied_prior[:, 5])


def test_six_vectorized_scenarios_equal_six_independent_calls(adapter):
    history, tide, observations = _inputs()
    combined = adapter(history, tide, observations)
    for source_index in range(6):
        independent = adapter.forward_single_source(
            history, tide, observations, source_index
        )
        assert torch.allclose(
            combined["updated_forecast"][:, source_index],
            independent["updated_forecast"],
            atol=1e-6,
            rtol=1e-6,
        )
        assert torch.allclose(
            combined["analysis_posterior_state_mean"][:, source_index],
            independent["analysis_posterior_state_mean"],
            atol=1e-12,
            rtol=1e-10,
        )


def test_one_source_scenario_does_not_read_other_source_values(adapter):
    history, tide, observations = _inputs()
    changed = observations.clone()
    changed[:, 1:] += 1000.0
    first = adapter.forward_single_source(history, tide, observations, 0)
    second = adapter.forward_single_source(history, tide, changed, 0)
    assert torch.equal(first["updated_forecast"], second["updated_forecast"])
    assert torch.equal(
        first["analysis_posterior_state_mean"],
        second["analysis_posterior_state_mean"],
    )


def test_only_38_noise_scalars_train_and_receive_finite_gradients(adapter):
    history, tide, observations = _inputs(batch_size=2)
    output = adapter(history, tide, observations)
    loss = output["updated_forecast"].square().mean()
    loss.backward()
    trainable = [parameter for parameter in adapter.parameters() if parameter.requires_grad]
    assert sum(parameter.numel() for parameter in trainable) == 38
    assert all(parameter.grad is not None for parameter in trainable)
    assert all(bool(torch.isfinite(parameter.grad).all()) for parameter in trainable)
    assert all(
        parameter.grad is None for parameter in adapter.backbone.parameters()
    )
