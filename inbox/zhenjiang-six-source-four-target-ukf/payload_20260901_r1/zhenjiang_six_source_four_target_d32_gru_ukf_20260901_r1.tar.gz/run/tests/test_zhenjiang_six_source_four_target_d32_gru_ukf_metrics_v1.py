"""Hand-calculated tests for six-source/four-target directional metrics."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
import sys

import pytest


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "scripts" / "analysis"
if str(ANALYSIS) not in sys.path:
    sys.path.insert(0, str(ANALYSIS))

from zhenjiang_six_source_four_target_d32_gru_ukf_metrics_v1 import (  # noqa: E402
    SOURCE_STATIONS,
    TARGET_STATIONS,
    assign_calendar_seven_day_blocks,
    bootstrap_crossed_seed_calendar_blocks,
    build_directional_matrices,
    decide_forecast_direction_gates,
    gain_from_mean_absolute_errors,
    holm_adjust_one_sided,
    summarize_source_target_leads,
    summarize_source_target_windows,
    validate_horizon_pair,
)


def _row(
    *,
    seed=17,
    block=0,
    count=2,
    source=0,
    target=0,
    lead=1,
    base_mae=0.11,
    prior_mae=0.10,
    updated_mae=0.08,
    movement=0.005,
):
    return {
        "schema_version": "1.0",
        "experiment_id": "synthetic",
        "seed": seed,
        "block_id": block,
        "block_origin_count": count,
        "source_index": source,
        "source_station": SOURCE_STATIONS[source],
        "target_index": target,
        "target_station": TARGET_STATIONS[target],
        "issue_horizon_hour": lead + 1,
        "post_update_lead_hour": lead,
        "cell_count": count,
        "base_absolute_error_sum_m": base_mae * count,
        "prior_absolute_error_sum_m": prior_mae * count,
        "updated_absolute_error_sum_m": updated_mae * count,
        "base_squared_error_sum_m2": base_mae**2 * count,
        "prior_squared_error_sum_m2": prior_mae**2 * count,
        "updated_squared_error_sum_m2": updated_mae**2 * count,
        "updated_minus_prior_absolute_movement_sum_m": movement * count,
        "target_sum_m": 0.0,
        "target_squared_sum_m2": 1.0 * count,
    }


def _complete_rows(*, adverse_cross=False):
    rows = []
    for seed in (17, 29, 43):
        for block in (0, 2):
            for source in range(6):
                for target in range(4):
                    for lead in range(1, 24):
                        updated = 0.08
                        if adverse_cross and not (
                            source in range(1, 5) and target == source - 1
                        ):
                            updated = 0.11
                        # One spectacular cell cannot compensate 19 adverse cells.
                        if adverse_cross and (source, target) == (0, 0):
                            updated = 0.0
                        rows.append(
                            _row(
                                seed=seed,
                                block=block,
                                source=source,
                                target=target,
                                lead=lead,
                                updated_mae=updated,
                            )
                        )
    return rows


def test_gain_example_is_positive_20_mm_and_20_percent():
    result = gain_from_mean_absolute_errors(0.10, 0.08)
    assert result["absolute_gain_m"] == pytest.approx(0.02)
    assert result["absolute_gain_mm"] == pytest.approx(20.0)
    assert result["relative_gain_percent"] == pytest.approx(20.0)
    assert result["relative_gain_status"] == "defined"


def test_negative_gain_and_zero_baseline_status():
    assert gain_from_mean_absolute_errors(0.10, 0.12)[
        "absolute_gain_mm"
    ] == pytest.approx(-20.0)
    zero = gain_from_mean_absolute_errors(0.0, 0.02)
    assert zero["relative_gain_percent"] is None
    assert zero["relative_gain_status"] == "undefined_zero_baseline"


def test_issue_and_post_update_horizons_cannot_be_misaligned():
    validate_horizon_pair(2, 1)
    validate_horizon_pair(24, 23)
    with pytest.raises(ValueError, match="misaligned"):
        validate_horizon_pair(2, 2)


def test_calendar_blocks_use_time_not_valid_sample_sequence():
    beijing = timezone(timedelta(hours=8))
    times = [
        datetime(2023, 1, 1, 0, tzinfo=beijing),
        datetime(2023, 1, 20, 12, tzinfo=beijing),
        "2023-12-31T23:00:00+08:00",
    ]
    identifiers, nonempty = assign_calendar_seven_day_blocks(times)
    assert identifiers.tolist() == [0, 2, 52]
    assert nonempty == (0, 2, 52)


def test_three_branches_metrics_and_gain_decomposition_are_exact():
    rows = _complete_rows()
    summaries = summarize_source_target_leads(rows)
    assert len(summaries) == 3 * 6 * 4 * 23 == 1656
    cell = next(
        row
        for row in summaries
        if row["seed"] == 17
        and row["source_index"] == 0
        and row["target_index"] == 0
        and row["post_update_lead_hour"] == 1
    )
    assert cell["base_mae_m"] == pytest.approx(0.11)
    assert cell["prior_mae_m"] == pytest.approx(0.10)
    assert cell["updated_mae_m"] == pytest.approx(0.08)
    assert cell["covariance_propagation_gain_m"] == pytest.approx(0.01)
    assert cell["measurement_update_gain_m"] == pytest.approx(0.02)
    assert cell["total_gain_m"] == pytest.approx(0.03)
    assert cell["total_gain_m"] == pytest.approx(
        cell["covariance_propagation_gain_m"]
        + cell["measurement_update_gain_m"]
    )
    assert cell["base_rmse_m"] == pytest.approx(0.11)
    assert cell["base_nse"] is not None


def test_window_relative_gain_uses_aggregated_errors_not_mean_percentages():
    first = _row(count=1, prior_mae=0.01, updated_mae=0.0)
    second = _row(block=1, count=9, prior_mae=0.10, updated_mae=0.09)
    # Complete only the selected source-target window for this focused summary.
    rows = [first, second]
    summaries = summarize_source_target_windows(rows)
    pooled = next(
        row
        for row in summaries
        if row["scope"] == "pooled_three_seeds"
        and row["window_name"] == "post_update_1_to_6"
    )
    expected = 100.0 * ((0.01 + 0.90) - (0.0 + 0.81)) / (0.01 + 0.90)
    assert pooled["measurement_update_relative_gain_percent"] == pytest.approx(
        expected
    )


def test_directional_matrix_does_not_swap_reciprocal_cells():
    rows = _complete_rows()
    for row in rows:
        if row["source_index"] == 1 and row["target_index"] == 1:
            row["updated_absolute_error_sum_m"] = 0.07 * row["cell_count"]
        if row["source_index"] == 2 and row["target_index"] == 0:
            row["updated_absolute_error_sum_m"] = 0.095 * row["cell_count"]
    windows = summarize_source_target_windows(rows)
    matrices = build_directional_matrices(windows)
    assert len(matrices["full_six_by_four"]) == 24
    assert len(matrices["internal_four_by_four"]) == 16
    assert len(matrices["boundary_two_by_four"]) == 8
    assert len(matrices["adjacent_eight"]) == 8
    lookup = {
        (row["source_index"], row["target_index"]): row
        for row in matrices["full_six_by_four"]
    }
    assert lookup[(1, 1)]["measurement_update_gain_m"] == pytest.approx(0.03)
    assert lookup[(2, 0)]["measurement_update_gain_m"] == pytest.approx(0.005)
    assert lookup[(1, 1)]["matrix_part"].startswith("upper_")
    assert lookup[(2, 0)]["matrix_part"].startswith("lower_")


def test_bootstrap_is_fixed_shared_and_holm_families_are_separate():
    rows = _complete_rows()
    first = bootstrap_crossed_seed_calendar_blocks(
        rows, repeat_count=200, random_seed=20260901
    )
    second = bootstrap_crossed_seed_calendar_blocks(
        rows, repeat_count=200, random_seed=20260901
    )
    assert first == second
    assert first["sampling"]["bit_generator"] == "PCG64"
    assert first["sampling"]["nonempty_block_ids"] == [0, 2]
    assert first["cross_20_macro"][
        "measurement_gain_one_sided_95_lower_m"
    ] == pytest.approx(0.02)
    internal = [
        row for row in first["cell_summaries"] if row.get("holm_family") == "internal_12"
    ]
    boundary = [
        row for row in first["cell_summaries"] if row.get("holm_family") == "boundary_8"
    ]
    assert len(internal) == 12
    assert len(boundary) == 8
    adjusted, rejected = holm_adjust_one_sided([0.001, 0.02, 0.2])
    assert adjusted == pytest.approx([0.003, 0.04, 0.2])
    assert rejected == [True, True, False]


def test_single_large_cell_cannot_monopolize_cross_macro_or_group_gates():
    rows = _complete_rows(adverse_cross=True)
    windows = summarize_source_target_windows(rows)
    bootstrap = bootstrap_crossed_seed_calendar_blocks(
        rows, repeat_count=200, random_seed=20260901
    )
    decision = decide_forecast_direction_gates(windows, bootstrap)
    assert bootstrap["cell_summaries"][0][
        "point_measurement_update_gain_m"
    ] > 0.0
    assert bootstrap["cross_20_macro"][
        "point_measurement_update_gain_m"
    ] < 0.0
    assert decision["status"] == "scientific_direction_fail"
    assert not decision["gates"][
        "cross_20_measurement_lower_strictly_positive"
    ]


def test_cross_station_pass_is_reported_separately_from_failed_self_gate():
    rows = _complete_rows()
    for row in rows:
        if row["source_index"] == 1 and row["target_index"] == 0:
            row["updated_absolute_error_sum_m"] = 0.12 * row["cell_count"]
    windows = summarize_source_target_windows(rows)
    bootstrap = bootstrap_crossed_seed_calendar_blocks(
        rows, repeat_count=200, random_seed=20260901
    )
    decision = decide_forecast_direction_gates(windows, bootstrap)
    assert decision["cross_station_status"] == (
        "statistical_direction_pass_practical_magnitude_not_assessed"
    )
    assert decision["cross_station_gate_pass"] is True
    assert decision["self_forecast_gate_pass"] is False
    assert decision["forecast_gate_pass"] is False
    assert decision["status"] == "cross_station_pass_self_forecast_fail"
