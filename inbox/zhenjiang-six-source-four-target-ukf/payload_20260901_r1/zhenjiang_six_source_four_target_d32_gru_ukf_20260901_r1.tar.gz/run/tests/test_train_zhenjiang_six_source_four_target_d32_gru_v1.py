"""Synthetic tests for four-target base training primitives."""

from __future__ import annotations

import inspect
from pathlib import Path
import sys

import numpy as np
import pytest
import torch
from torch.utils.data import Dataset


ROOT = Path(__file__).resolve().parents[1]
MODELING_DIR = ROOT / "scripts" / "modeling"
if str(MODELING_DIR) not in sys.path:
    sys.path.insert(0, str(MODELING_DIR))

import train_zhenjiang_six_source_four_target_d32_gru_v1 as trainer  # noqa: E402
from train_zhenjiang_six_source_four_target_d32_gru_v1 import (  # noqa: E402
    BaseTrainingConfiguration,
    CELLS_PER_SAMPLE,
    FROZEN_CONFIGURATION,
    configure_base_training_parameters,
    four_target_smooth_absolute_error,
    mean_absolute_error_sum_and_count,
    run_synthetic_smoke,
    smooth_absolute_error_sum_and_count,
    total_parameter_count,
    train_base_model,
)
from zhenjiang_six_source_four_target_d32_gru_v1 import (  # noqa: E402
    SixSourceFourTargetD32GRU,
)


def test_loss_has_exactly_96_equal_cells_per_sample_and_matches_formula():
    prediction = torch.zeros(2, 24, 4, dtype=torch.float32)
    target = torch.zeros_like(prediction)
    prediction[0, 0, 0] = 0.05
    prediction[1, 23, 3] = 0.20
    scales = torch.ones(4)
    loss_sum, count = smooth_absolute_error_sum_and_count(
        prediction, target, scales
    )
    expected = 0.5 * 0.05**2 / 0.10 + (0.20 - 0.5 * 0.10)
    assert count == 2 * CELLS_PER_SAMPLE == 192
    assert float(loss_sum) == pytest.approx(expected, abs=1e-8)
    assert float(four_target_smooth_absolute_error(prediction, target, scales)) == pytest.approx(
        expected / 192, abs=1e-10
    )


def test_selection_metric_is_ordinary_mean_absolute_error_in_metres():
    prediction = torch.ones(1, 24, 4)
    target = torch.zeros_like(prediction)
    scales = torch.tensor([1.0, 2.0, 3.0, 4.0])
    error_sum, count = mean_absolute_error_sum_and_count(
        prediction, target, scales
    )
    assert count == 96
    assert float(error_sum / count) == pytest.approx(2.5)


def test_formal_training_hyperparameters_are_exact():
    assert FROZEN_CONFIGURATION == BaseTrainingConfiguration(
        batch_size=128,
        maximum_epochs=36,
        patience_epochs=4,
        minimum_improvement_m=0.0001,
        learning_rate=0.001,
        weight_decay=0.0001,
        maximum_gradient_norm=1.0,
    )


def test_formal_base_entry_uses_only_training_selection_loader():
    source = inspect.getsource(trainer.main)
    assert "load_training_selection_data" in source
    assert "load_development_data" not in source


def test_realtime_observation_head_is_frozen_during_base_training():
    model = SixSourceFourTargetD32GRU()
    configure_base_training_parameters(model)
    assert all(
        not parameter.requires_grad
        for parameter in model.realtime_observation_decoder.parameters()
    )
    assert all(
        parameter.requires_grad
        for name, parameter in model.named_parameters()
        if not name.startswith("realtime_observation_decoder.")
    )
    assert total_parameter_count(model) == 19_594
    assert sum(
        parameter.numel()
        for parameter in model.parameters()
        if parameter.requires_grad
    ) == 19_396
    history = torch.randn(2, 24, 6)
    tide = torch.randn(2, 24)
    target = torch.randn(2, 24, 4)
    four_target_smooth_absolute_error(model(history, tide), target, torch.ones(4)).backward()
    assert all(
        parameter.grad is None
        for parameter in model.realtime_observation_decoder.parameters()
    )


class _TinyDataset(Dataset):
    def __init__(self, sample_count: int, seed: int):
        generator = torch.Generator().manual_seed(seed)
        self.history = torch.randn(sample_count, 24, 6, generator=generator)
        self.tide = torch.randn(sample_count, 24, generator=generator)
        self.target = torch.randn(sample_count, 24, 4, generator=generator)

    def __len__(self):
        return len(self.history)

    def __getitem__(self, index):
        return {
            "history": self.history[index],
            "future_tide": self.tide[index],
            "targets_t_plus_1_to_t_plus_24": self.target[index],
        }


def test_training_creates_exclusive_seed_artifacts_and_refuses_overwrite(
    tmp_path, monkeypatch
):
    small = BaseTrainingConfiguration(
        batch_size=2,
        maximum_epochs=1,
        patience_epochs=4,
        minimum_improvement_m=0.0001,
        learning_rate=0.001,
        weight_decay=0.0001,
        maximum_gradient_norm=1.0,
    )
    monkeypatch.setattr(trainer, "FROZEN_CONFIGURATION", small)
    output = tmp_path / "s17"
    manifest = train_base_model(
        training_dataset=_TinyDataset(2, 1),
        selection_dataset=_TinyDataset(2, 2),
        normalization=trainer._synthetic_normalization(),
        seed=17,
        device="cpu",
        output_directory=output,
        configuration=small,
    )
    assert manifest["seed"] == 17
    assert manifest["total_parameter_count"] == 19_594
    assert manifest["base_stage_trainable_parameter_count"] == 19_396
    assert (output / "best_checkpoint.pt").is_file()
    assert (output / "last_checkpoint.pt").is_file()
    assert (output / "training_history.json").is_file()
    assert (output / "completion_manifest.json").is_file()
    checkpoint = torch.load(output / "best_checkpoint.pt", weights_only=False)
    assert checkpoint["realtime_observation_head_fitted"] is False
    assert checkpoint["selection_mean_absolute_error_m"] >= 0.0
    assert checkpoint["total_parameter_count"] == 19_594
    assert checkpoint["base_stage_trainable_parameter_count"] == 19_396
    assert "model_parameter_count" not in checkpoint
    with pytest.raises(FileExistsError):
        train_base_model(
            training_dataset=_TinyDataset(2, 1),
            selection_dataset=_TinyDataset(2, 2),
            normalization=trainer._synthetic_normalization(),
            seed=17,
            device="cpu",
            output_directory=output,
            configuration=small,
        )


def test_synthetic_smoke_does_not_create_a_formal_result_root(tmp_path):
    formal_root = tmp_path / "formal_result_that_must_not_exist"
    report = run_synthetic_smoke(17, "cpu")
    assert report["formal_output_created"] is False
    assert report["metrics_finite"] is True
    assert not formal_root.exists()
