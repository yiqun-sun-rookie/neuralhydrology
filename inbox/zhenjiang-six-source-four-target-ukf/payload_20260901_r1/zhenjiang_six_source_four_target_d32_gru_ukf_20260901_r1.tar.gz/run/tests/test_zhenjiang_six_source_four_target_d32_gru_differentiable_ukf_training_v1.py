"""Synthetic tests for the 552-cell differentiable-filter objective."""

from __future__ import annotations

from pathlib import Path
import sys

import pytest
import torch


ROOT = Path(__file__).resolve().parents[1]
MODELING_DIR = ROOT / "scripts" / "modeling"
if str(MODELING_DIR) not in sys.path:
    sys.path.insert(0, str(MODELING_DIR))

from zhenjiang_six_source_four_target_d32_gru_v1 import (  # noqa: E402
    SixSourceFourTargetD32GRU,
)
from zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_v1 import (  # noqa: E402
    SixSourceFourTargetD32GRUDifferentiableUKF,
)
from zhenjiang_six_source_four_target_d32_gru_differentiable_ukf_training_v1 import (  # noqa: E402
    CELLS_PER_BASE_SAMPLE,
    ErrorAccumulator,
    SELF_SOURCE_TARGET_PAIRS,
    all_cell_metre_absolute_error_sum,
    prepare_filter_for_training,
)


def test_all_552_cells_are_equally_weighted_and_self_cells_have_gradients():
    batch_size = 2
    prediction = torch.arange(
        1,
        batch_size * 6 * 23 * 4 + 1,
        dtype=torch.float64,
    ).reshape(batch_size, 6, 23, 4)
    prediction = (prediction / 10_000.0).requires_grad_(True)
    target = torch.zeros(batch_size, 23, 4, dtype=torch.float64)
    scale = torch.tensor([0.5, 1.0, 1.5, 2.0], dtype=torch.float64)

    error_sum, count = all_cell_metre_absolute_error_sum(
        prediction, target, scale
    )
    manual = 0.0
    for sample in range(batch_size):
        for source in range(6):
            for lead in range(23):
                for target_index in range(4):
                    manual += abs(
                        float(prediction[sample, source, lead, target_index])
                        * float(scale[target_index])
                    )
    assert count == batch_size * CELLS_PER_BASE_SAMPLE == batch_size * 552
    assert float(error_sum) == pytest.approx(manual, rel=0.0, abs=1e-12)

    error_sum.backward()
    expected_gradient = scale[None, None, None, :].expand_as(prediction)
    torch.testing.assert_close(
        prediction.grad, expected_gradient, rtol=0.0, atol=0.0
    )
    for source_index, target_index in SELF_SOURCE_TARGET_PAIRS:
        assert bool(
            (prediction.grad[:, source_index, :, target_index] != 0.0).all()
        )


def test_epoch_uses_total_sum_over_total_cells_not_mean_of_batch_means():
    accumulator = ErrorAccumulator()
    accumulator.add(error_sum=32.0 * 552.0 * 2.0, cell_count=32 * 552, base_sample_count=32)
    accumulator.add(error_sum=1.0 * 552.0 * 10.0, cell_count=1 * 552, base_sample_count=1)
    summary = accumulator.summary()

    expected = (32.0 * 552.0 * 2.0 + 1.0 * 552.0 * 10.0) / (33 * 552)
    assert summary["mae_m"] == pytest.approx(expected)
    assert summary["mae_m"] != pytest.approx((2.0 + 10.0) / 2.0)
    assert summary["valid_cell_count"] == 33 * 552
    assert summary["completed_batches"] == 2


def test_epoch_accumulator_rejects_a_non_552_cell_contract():
    accumulator = ErrorAccumulator()
    accumulator.add(error_sum=1.0, cell_count=551, base_sample_count=1)
    with pytest.raises(RuntimeError, match="552"):
        accumulator.summary()


def test_prepare_filter_keeps_one_shared_backbone_frozen_and_only_38_trainable():
    torch.manual_seed(7)
    filter_model = SixSourceFourTargetD32GRUDifferentiableUKF(
        SixSourceFourTargetD32GRU()
    )
    prepared = prepare_filter_for_training(filter_model, "cpu")

    trainable = [p for p in prepared.parameters() if p.requires_grad]
    assert sum(parameter.numel() for parameter in trainable) == 38
    assert all(parameter.dtype == torch.float64 for parameter in trainable)
    assert all(
        parameter.grad is None for parameter in prepared.backbone.parameters()
    )
    assert all(
        not parameter.requires_grad
        for parameter in prepared.backbone.parameters()
    )
    assert prepared.backbone.training is False


@pytest.mark.parametrize(
    "prediction_shape,target_shape,scale_shape",
    [
        ((1, 6, 24, 4), (1, 23, 4), (4,)),
        ((1, 6, 23, 4), (1, 24, 4), (4,)),
        ((1, 6, 23, 4), (1, 23, 4), (6,)),
    ],
)
def test_loss_rejects_shape_drift(prediction_shape, target_shape, scale_shape):
    with pytest.raises(ValueError):
        all_cell_metre_absolute_error_sum(
            torch.zeros(prediction_shape),
            torch.zeros(target_shape),
            torch.ones(scale_shape),
        )
