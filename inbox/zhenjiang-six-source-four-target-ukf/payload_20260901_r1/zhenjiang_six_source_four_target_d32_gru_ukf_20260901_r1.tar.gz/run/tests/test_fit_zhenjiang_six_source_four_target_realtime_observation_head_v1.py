"""Synthetic tests for runtime-prior observation-head fitting."""

from __future__ import annotations

from dataclasses import replace
import inspect
from pathlib import Path
import sys

import numpy as np
import pytest
import torch
from torch import nn


ROOT = Path(__file__).resolve().parents[1]
MODELING_DIR = ROOT / "scripts" / "modeling"
if str(MODELING_DIR) not in sys.path:
    sys.path.insert(0, str(MODELING_DIR))

import fit_zhenjiang_six_source_four_target_realtime_observation_head_v1 as fitter  # noqa: E402
from fit_zhenjiang_six_source_four_target_realtime_observation_head_v1 import (  # noqa: E402
    RIDGE_STRENGTHS,
    collect_prior_design_and_observations,
    fit_and_select_observation_head,
    install_selected_head,
    unscented_analysis_prior_mean,
)
from zhenjiang_six_source_four_target_d32_gru_v1 import (  # noqa: E402
    SixSourceFourTargetD32GRU,
)


class _NonlinearTransition(nn.Module):
    def encode_history(self, history):
        return history[:, -1, :1].repeat(1, 32)

    def transition_step(self, state, tide):
        return state.square() + 0.1 * tide[:, None]


def test_formal_observation_head_entry_uses_only_training_selection_loader():
    source = inspect.getsource(fitter.main)
    assert "load_training_selection_data" in source
    assert "load_development_data" not in source


def test_prior_is_exact_65_point_runtime_mean_not_deterministic_shortcut():
    model = _NonlinearTransition()
    history = torch.zeros(2, 24, 6, dtype=torch.float32)
    history[:, -1, 0] = torch.tensor([0.2, -0.3])
    tide = torch.tensor([0.5, -0.1], dtype=torch.float32)
    actual = unscented_analysis_prior_mean(model, history, tide)
    encoded = model.encode_history(history)
    deterministic = model.transition_step(encoded, tide).to(torch.float64)
    # For f(x)=x^2, the symmetric sigma-point mean adds the prior variance.
    expected = deterministic + 0.001
    torch.testing.assert_close(actual, expected, rtol=0.0, atol=2e-8)
    assert not torch.allclose(actual, deterministic, rtol=0.0, atol=1e-6)


class _OrderDataset:
    def __init__(self):
        self.events = []

    def __len__(self):
        return 3

    def get_prior_input(self, index):
        self.events.append(("prior", index))
        return {
            "history": torch.full((24, 6), 0.01 * index),
            "future_tide": torch.zeros(24),
        }

    def get_analysis_observation(self, index):
        self.events.append(("observation", index))
        return torch.full((6,), float(index))


def test_all_priors_are_generated_before_any_analysis_observation_is_read():
    dataset = _OrderDataset()
    model = SixSourceFourTargetD32GRU().eval()
    priors, observations = collect_prior_design_and_observations(
        model, dataset, device="cpu", batch_size=2
    )
    assert priors.shape == (3, 32)
    assert observations.shape == (3, 6)
    assert dataset.events == [
        ("prior", 0),
        ("prior", 1),
        ("prior", 2),
        ("observation", 0),
        ("observation", 1),
        ("observation", 2),
    ]


def test_ridge_uses_one_common_strength_unpenalized_intercept_and_float32_scoring():
    generator = np.random.default_rng(33)
    training_x = generator.normal(size=(90, 32))
    weight = generator.normal(scale=0.05, size=(32, 6))
    bias = np.asarray([3, 4, 5, 6, 7, 8], dtype=np.float64)
    training_y = training_x @ weight + bias
    selection_x = generator.normal(size=(25, 32))
    selection_y = selection_x @ weight + bias
    result = fit_and_select_observation_head(
        training_x,
        training_y,
        selection_x,
        selection_y,
        np.asarray([1, 2, 3, 4, 5, 6], dtype=np.float64),
    )
    assert tuple(candidate.ridge_strength for candidate in result.candidates) == RIDGE_STRENGTHS
    assert result.selected.ridge_strength in RIDGE_STRENGTHS
    candidate = result.selected
    assert candidate.weight_float32.dtype == np.float32
    assert candidate.bias_float32.dtype == np.float32
    prediction = (
        selection_x @ candidate.weight_float32.astype(np.float64).T
        + candidate.bias_float32.astype(np.float64)[None, :]
    )
    expected = np.mean(
        np.abs(prediction - selection_y)
        * np.asarray([1, 2, 3, 4, 5, 6])[None, :]
    )
    assert candidate.selection_mean_absolute_error_m == pytest.approx(expected, abs=0.0)
    assert candidate.augmented_design_rank == 33
    assert candidate.augmented_design_condition_number is not None
    assert candidate.coefficient_float64_sha256 != candidate.coefficient_float32_sha256


def test_exact_tie_selects_larger_ridge_strength():
    training_x = np.zeros((10, 32), dtype=np.float64)
    training_y = np.tile(np.arange(6, dtype=np.float64), (10, 1))
    selection_x = np.zeros((4, 32), dtype=np.float64)
    selection_y = np.tile(np.arange(6, dtype=np.float64), (4, 1))
    result = fit_and_select_observation_head(
        training_x, training_y, selection_x, selection_y, np.ones(6)
    )
    assert all(candidate.selection_mean_absolute_error_m == 0.0 for candidate in result.candidates)
    assert result.selected.ridge_strength == 1.0


def test_tie_tolerance_is_measured_from_global_minimum_not_chained():
    training_x = np.zeros((10, 32), dtype=np.float64)
    training_y = np.zeros((10, 6), dtype=np.float64)
    result = fit_and_select_observation_head(
        training_x,
        training_y,
        np.zeros((4, 32), dtype=np.float64),
        np.zeros((4, 6), dtype=np.float64),
        np.ones(6),
    )
    template = result.candidates[0]
    candidates = (
        replace(
            template,
            ridge_strength=0.0,
            selection_mean_absolute_error_m=1.0,
        ),
        replace(
            template,
            ridge_strength=0.1,
            selection_mean_absolute_error_m=1.0 + 0.8e-12,
        ),
        replace(
            template,
            ridge_strength=1.0,
            selection_mean_absolute_error_m=1.0 + 1.6e-12,
        ),
    )
    selected = fitter._select_ridge_candidate(candidates)
    assert selected.ridge_strength == 0.1
    assert selected is not candidates[-1]


def test_zero_strength_uses_pseudoinverse_and_selected_values_install_exactly():
    generator = np.random.default_rng(91)
    training_x = generator.normal(size=(12, 32))
    training_y = generator.normal(size=(12, 6))
    selection_x = generator.normal(size=(5, 32))
    selection_y = generator.normal(size=(5, 6))
    result = fit_and_select_observation_head(
        training_x, training_y, selection_x, selection_y, np.ones(6)
    )
    zero = result.candidates[0]
    assert zero.ridge_strength == 0.0
    assert np.isfinite(zero.weight_float32).all()
    assert np.isfinite(zero.bias_float32).all()
    model = SixSourceFourTargetD32GRU()
    install_selected_head(model, result)
    np.testing.assert_array_equal(
        model.realtime_observation_decoder.weight.detach().numpy(),
        result.selected.weight_float32,
    )
    np.testing.assert_array_equal(
        model.realtime_observation_decoder.bias.detach().numpy(),
        result.selected.bias_float32,
    )
