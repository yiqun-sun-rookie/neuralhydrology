"""Synthetic tests for the immutable six-source, four-target contract."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import sys

import pytest


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS_DIR = ROOT / "scripts" / "analysis"
if str(ANALYSIS_DIR) not in sys.path:
    sys.path.insert(0, str(ANALYSIS_DIR))

from zhenjiang_six_source_four_target_d32_gru_ukf_contract_v1 import (  # noqa: E402
    ADJACENT_DIRECTIONS,
    DEVELOPMENT_YEAR,
    HELDOUT_YEAR,
    RANDOM_SEEDS,
    SELECTION_YEAR,
    SOURCE_STATIONS,
    TARGET_SOURCE_INDICES,
    TARGET_STATIONS,
    TRAIN_YEARS,
    all_direction_cells,
    expected_output_shapes,
    self_check,
    split_name_for_year,
    window_is_within_one_calendar_year,
)


def test_station_order_seeds_and_physical_target_indices_are_frozen():
    assert SOURCE_STATIONS == (
        "datong", "nanjing", "zhenjiang", "jiangyin", "xuliujing", "wusongkou"
    )
    assert TARGET_STATIONS == ("nanjing", "zhenjiang", "jiangyin", "xuliujing")
    assert TARGET_SOURCE_INDICES == (1, 2, 3, 4)
    assert RANDOM_SEEDS == (17, 29, 43)
    assert len(ADJACENT_DIRECTIONS) == 8


def test_cell_partition_is_exact_and_directional():
    cells = all_direction_cells()
    assert len(cells) == 24
    assert sum(cell.is_self for cell in cells) == 4
    assert sum(not cell.is_self for cell in cells) == 20
    assert sum(cell.is_internal_cross for cell in cells) == 12
    assert sum(cell.is_boundary for cell in cells) == 8
    keys = {cell.key for cell in cells}
    assert "nanjing->zhenjiang" in keys
    assert "zhenjiang->nanjing" in keys
    assert "nanjing->zhenjiang" != "zhenjiang->nanjing"


def test_all_output_shapes_are_frozen():
    shapes = expected_output_shapes(7)
    assert shapes["base_deterministic_future_forecast"] == (7, 23, 4)
    assert shapes["no_observation_unscented_prior_future_forecast"] == (7, 23, 4)
    assert shapes["updated_future_forecast"] == (7, 6, 23, 4)
    assert shapes["analysis_prior_target"] == (7, 4)
    assert shapes["analysis_posterior_target"] == (7, 6, 4)
    assert shapes["updated_state"] == (7, 6, 32)
    assert shapes["kalman_gain"] == (7, 6, 32)
    with pytest.raises(ValueError, match="positive integer"):
        expected_output_shapes(0)


def test_calendar_split_and_cross_year_rule_are_explicit():
    assert TRAIN_YEARS == (2017, 2018, 2019, 2020, 2021)
    assert SELECTION_YEAR == 2022
    assert DEVELOPMENT_YEAR == 2023
    assert HELDOUT_YEAR == 2024
    assert split_name_for_year(2019) == "training"
    assert split_name_for_year(2022) == "selection"
    assert split_name_for_year(2023) == "development_gate"
    assert split_name_for_year(2024) == "new_model_heldout"
    assert window_is_within_one_calendar_year(
        datetime(2023, 6, 1, 12, tzinfo=timezone.utc)
    )
    assert not window_is_within_one_calendar_year(
        datetime(2023, 1, 1, 12, tzinfo=timezone.utc)
    )
    assert not window_is_within_one_calendar_year(
        datetime(2023, 12, 31, 12, tzinfo=timezone.utc)
    )


def test_self_check_has_zero_findings():
    report = self_check()
    assert report["source_count"] == 6
    assert report["target_count"] == 4
    assert report["total_cell_count"] == 24
    assert report["self_cell_count"] == 4
    assert report["cross_cell_count"] == 20
    assert report["finding_count"] == 0
    assert report["findings"] == []
