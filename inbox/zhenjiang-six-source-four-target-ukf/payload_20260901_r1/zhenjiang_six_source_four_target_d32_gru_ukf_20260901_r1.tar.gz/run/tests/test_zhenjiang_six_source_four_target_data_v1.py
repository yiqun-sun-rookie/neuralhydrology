"""Synthetic-only tests for the six-source, four-target data contract."""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timedelta, timezone
import hashlib
import io
from pathlib import Path
import sys

import numpy as np
import pytest
import torch


ROOT = Path(__file__).resolve().parents[1]
MODELING_DIR = ROOT / "scripts" / "modeling"
if str(MODELING_DIR) not in sys.path:
    sys.path.insert(0, str(MODELING_DIR))

import zhenjiang_six_source_four_target_data_v1 as data_module  # noqa: E402
from zhenjiang_six_source_four_target_data_v1 import (  # noqa: E402
    AUTHORIZED_TARGET_PATHS,
    DataAccessAudit,
    FourSpaceNormalization,
    NORMALIZATION_ANALYSIS_STAGE,
    NORMALIZATION_FUTURE_TIDE,
    NORMALIZATION_HISTORY_STAGE,
    NORMALIZATION_RETROSPECTIVE_TARGET,
    SOURCE_STATIONS,
    ContentIdentitySpec,
    DEVELOPMENT_CONTENT_IDENTITIES,
    SixSourceFourTargetDataset,
    TRAINING_SELECTION_CONTENT_IDENTITIES,
    assert_forbidden_target_access_is_zero,
    build_data_from_arrays,
    build_split_datasets,
    enumerate_record_sets,
    fit_four_space_normalization,
    load_authorized_prefix_bytes,
    load_training_selection_data,
    validate_four_space_normalization,
)


BEIJING = timezone(timedelta(hours=8))


def _arrays(hour_count: int = 240):
    times = np.asarray(
        [
            datetime(2021, 6, 1, tzinfo=BEIJING) + timedelta(hours=index)
            for index in range(hour_count)
        ],
        dtype=object,
    )
    hour = np.arange(hour_count, dtype=np.float64)[:, None]
    station = np.arange(6, dtype=np.float64)[None, :]
    stages = 2.0 + 0.02 * hour + 0.1 * station + np.sin(hour / 7.0)
    target_station = np.arange(4, dtype=np.float64)[None, :]
    targets = 3.0 + 0.025 * hour + 0.2 * target_station + np.cos(hour / 11.0)
    tide = 1.0 + 0.3 * np.sin(np.arange(hour_count, dtype=np.float64) / 4.0)
    return times, stages, targets, tide


def _data():
    times, stages, targets, tide = _arrays()
    return build_data_from_arrays(
        times_beijing=times,
        realtime_stages_m=stages,
        retrospective_targets_m=targets,
        astronomical_tide_m=tide,
    )


def test_dataset_has_exact_shapes_spaces_and_one_station_scenarios():
    data = _data()
    dataset = SixSourceFourTargetDataset(
        data, data.record_enumeration.paired_filter_records[:2]
    )
    sample = dataset[0]
    assert sample["history"].shape == (24, 6)
    assert sample["future_tide"].shape == (24,)
    assert sample["analysis_observations"].shape == (6,)
    assert sample["targets_t_plus_1_to_t_plus_24"].shape == (24, 4)
    assert sample["targets_t_plus_2_to_t_plus_24"].shape == (23, 4)
    availability = sample["analysis_availability_scenarios"]
    assert availability.shape == (6, 6)
    assert availability.dtype == torch.bool
    torch.testing.assert_close(availability.sum(dim=1), torch.ones(6, dtype=torch.int64))
    assert torch.equal(availability, torch.eye(6, dtype=torch.bool))
    for key in (
        "history",
        "future_tide",
        "analysis_observations",
        "targets_t_plus_1_to_t_plus_24",
        "targets_t_plus_2_to_t_plus_24",
    ):
        assert sample[key].dtype == torch.float32
        assert bool(torch.isfinite(sample[key]).all())


def test_three_record_sets_are_distinct_and_formal_set_is_intersection():
    times, stages, targets, tide = _arrays()
    # A missing t+1 observation can exclude observation/paired records while
    # leaving some base-forecast records.  A missing target does the converse.
    stages[90, 0] = np.nan
    targets[150, 0] = np.nan
    sets = enumerate_record_sets(times, stages, targets, tide)
    base = set(sets.base_forecast_records)
    observation = set(sets.realtime_observation_head_records)
    paired = set(sets.paired_filter_records)
    assert paired == base & observation
    assert paired < base
    assert paired < observation
    assert sets.exclusion_counts["paired_filter"]


def test_four_normalizations_use_independent_roles_and_repeated_windows():
    data = _data()
    normalization = data.normalization
    assert normalization.history_stage.role == NORMALIZATION_HISTORY_STAGE
    assert normalization.future_tide.role == NORMALIZATION_FUTURE_TIDE
    assert normalization.analysis_stage.role == NORMALIZATION_ANALYSIS_STAGE
    assert (
        normalization.retrospective_target.role
        == NORMALIZATION_RETROSPECTIVE_TARGET
    )
    assert normalization.history_stage.mean_m.shape == (6,)
    assert normalization.future_tide.mean_m.shape == (1,)
    assert normalization.analysis_stage.mean_m.shape == (6,)
    assert normalization.retrospective_target.mean_m.shape == (4,)
    training_count = len(data.paired_records_by_split["training"])
    np.testing.assert_array_equal(
        normalization.history_stage.value_count,
        np.full(6, training_count * 24),
    )
    np.testing.assert_array_equal(
        normalization.analysis_stage.value_count,
        np.full(6, training_count),
    )


def test_swapping_normalization_identities_is_rejected():
    data = _data()
    n = data.normalization
    swapped = FourSpaceNormalization(
        history_stage=replace(
            n.history_stage, role=NORMALIZATION_ANALYSIS_STAGE
        ),
        future_tide=n.future_tide,
        analysis_stage=replace(
            n.analysis_stage, role=NORMALIZATION_HISTORY_STAGE
        ),
        retrospective_target=n.retrospective_target,
    )
    with pytest.raises(ValueError, match="identity mismatch"):
        validate_four_space_normalization(swapped)


def test_only_four_internal_target_paths_can_be_opened(tmp_path):
    paths = {
        "dataset_config.json",
        *(f"realtime_features/{station}_realtime_features.csv" for station in SOURCE_STATIONS),
        *AUTHORIZED_TARGET_PATHS,
    }
    specs = {}
    for index, relative_path in enumerate(sorted(paths)):
        content = f"synthetic-{index}\n".encode("utf-8")
        path = tmp_path / relative_path
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        specs[relative_path] = ContentIdentitySpec(
            relative_path=relative_path,
            verification_scope="full_file",
            byte_count=len(content),
            sha256=hashlib.sha256(content).hexdigest(),
        )
    opened = []

    def monitor(path: Path):
        opened.append(path.as_posix())
        return path.open("rb")

    contents, audit = load_authorized_prefix_bytes(
        tmp_path, identity_specs=specs, opener=monitor
    )
    assert set(contents) == paths
    assert len(opened) == 11
    assert all("datong_retrospective_targets" not in path for path in opened)
    assert all("wusongkou_retrospective_targets" not in path for path in opened)
    assert_forbidden_target_access_is_zero(audit)


def test_training_selection_identities_are_exact_and_end_at_52584_rows():
    expected = {
        "realtime_features/datong_realtime_features.csv": (4701303, "8771742f9b0fe8ae4f933a99b7ea2d6ac5b6ea038352ab1d20d16dfa02679510"),
        "realtime_features/nanjing_realtime_features.csv": (4673779, "a2f6fc0d4978132839d597f06d1912fee35fad526f7ef3dfb0929f78cf82f1fa"),
        "realtime_features/zhenjiang_realtime_features.csv": (4703128, "4a46bc94cb0d0d735c84043e28eae9d8c2b0610fd478dbefafa017f8d1f45704"),
        "realtime_features/jiangyin_realtime_features.csv": (4673156, "c6568bac636cf8037d808ee9728751aa9e031e0f91b1d1771892acfe5fb2b51a"),
        "realtime_features/xuliujing_realtime_features.csv": (4673755, "cf23dda4b80b81da257872429b61928eec211d2fba47bc73e8643fde80133586"),
        "realtime_features/wusongkou_realtime_features.csv": (4671049, "b3dc0c759a0adbb34d1011f288528394c0c27a134c59725591e653b82a4d9a5b"),
        "retrospective_targets/nanjing_retrospective_targets.csv": (4674734, "9e0d1bdd950326bc1c11e05bfcc26ecf6ac847a2e15d01c7cdc49d79644c14b4"),
        "retrospective_targets/zhenjiang_retrospective_targets.csv": (4703632, "17d897dea5b3599717b1ad2bfd9520ae7e1900d1c9247e27b4d542f2701de937"),
        "retrospective_targets/jiangyin_retrospective_targets.csv": (4674038, "922157f3294822f86a58d1f590cd0c54eb3b7529beeb957bc53192126b211891"),
        "retrospective_targets/xuliujing_retrospective_targets.csv": (4674687, "4344b95978c5308cb22bbd3b39e703e9ac6f8daf7973d2a4089c54ef212eb9f8"),
    }
    assert set(TRAINING_SELECTION_CONTENT_IDENTITIES) == set(
        DEVELOPMENT_CONTENT_IDENTITIES
    )
    for path, (byte_count, sha256) in expected.items():
        spec = TRAINING_SELECTION_CONTENT_IDENTITIES[path]
        assert spec.verification_scope == "header_plus_52584_rows"
        assert spec.byte_count == byte_count
        assert spec.sha256 == sha256
        assert spec.byte_count < DEVELOPMENT_CONTENT_IDENTITIES[path].byte_count
        assert spec.sha256 != DEVELOPMENT_CONTENT_IDENTITIES[path].sha256
    config = TRAINING_SELECTION_CONTENT_IDENTITIES["dataset_config.json"]
    assert config.verification_scope == "full_file"
    assert config.byte_count == 2854
    assert config.sha256 == "63b2d3a33b249e1f598db2a1ffb2096c9d9006b366e4e913d594f74a6881d492"


def test_training_selection_prefix_reader_does_not_read_following_2023_bytes(tmp_path):
    paths = {
        "dataset_config.json",
        *(f"realtime_features/{station}_realtime_features.csv" for station in SOURCE_STATIONS),
        *AUTHORIZED_TARGET_PATHS,
    }
    specs = {}
    forbidden_suffix = b"2023_TARGET_BYTES_MUST_NOT_BE_READ"
    for index, relative_path in enumerate(sorted(paths)):
        prefix = f"registered-through-2022-{index}\n".encode("ascii")
        path = tmp_path / relative_path
        path.parent.mkdir(parents=True, exist_ok=True)
        if relative_path == "dataset_config.json":
            path.write_bytes(prefix)
            scope = "full_file"
        else:
            path.write_bytes(prefix + forbidden_suffix)
            scope = "header_plus_52584_rows"
        specs[relative_path] = ContentIdentitySpec(
            relative_path=relative_path,
            verification_scope=scope,
            byte_count=len(prefix),
            sha256=hashlib.sha256(prefix).hexdigest(),
        )
    contents, audit = load_authorized_prefix_bytes(
        tmp_path, identity_specs=specs
    )
    for relative_path, content in contents.items():
        assert forbidden_suffix not in content
        assert len(content) == specs[relative_path].byte_count
        assert audit.bytes_read_by_path[relative_path] == len(content)
    assert audit.target_rows_by_period["development_gate"] == 0
    assert audit.target_rows_by_period["heldout_or_later"] == 0
    for name in (
        "development_feature_bytes_read",
        "development_feature_rows_parsed",
        "development_feature_values_loaded",
        "development_target_bytes_read",
        "development_target_rows_parsed",
        "development_target_values_loaded",
        "heldout_target_bytes_read",
        "heldout_target_rows_parsed",
        "heldout_target_values_loaded",
        "boundary_target_bytes_read",
        "boundary_target_rows_parsed",
        "boundary_target_values_loaded",
    ):
        assert type(getattr(audit, name)) is int
        assert getattr(audit, name) == 0


def test_training_selection_entry_has_no_development_dataset_or_target_count(monkeypatch):
    synthetic = _data()
    captured = {}

    def fake_loader(**kwargs):
        captured.update(kwargs)
        return synthetic

    monkeypatch.setattr(data_module, "_load_registered_data", fake_loader)
    loaded = load_training_selection_data("unused", "unused")
    assert loaded is synthetic
    assert captured["identity_specs"] is TRAINING_SELECTION_CONTENT_IDENTITIES
    assert captured["expected_rows"] == 52_584
    assert captured["maximum_year"] == 2022
    assert loaded.access_audit.target_rows_by_period["development_gate"] == 0
    assert loaded.paired_records_by_split["development_gate"] == ()
    assert loaded.access_audit.development_feature_bytes_read == 0
    assert loaded.access_audit.development_feature_rows_parsed == 0
    assert loaded.access_audit.development_feature_values_loaded == 0
    assert loaded.access_audit.development_target_bytes_read == 0
    assert loaded.access_audit.development_target_rows_parsed == 0
    assert loaded.access_audit.development_target_values_loaded == 0


@pytest.mark.parametrize(
    "path",
    (
        "retrospective_targets/datong_retrospective_targets.csv",
        "retrospective_targets/wusongkou_retrospective_targets.csv",
    ),
)
def test_any_boundary_target_access_is_a_hard_stop(path):
    audit = DataAccessAudit(
        opened_paths=(path,),
        bytes_read_by_path={path: 1},
        rows_parsed_by_path={},
        values_loaded_by_path={},
        target_rows_by_period={
            "training": 0,
            "selection": 0,
            "development_gate": 0,
            "heldout_or_later": 0,
            "boundary_target": 0,
        },
        astronomical_tide_model_open_count=0,
    )
    with pytest.raises(RuntimeError, match="forbidden boundary target"):
        assert_forbidden_target_access_is_zero(audit)


def test_any_2024_target_counter_is_a_hard_stop():
    audit = DataAccessAudit(
        opened_paths=(),
        bytes_read_by_path={},
        rows_parsed_by_path={},
        values_loaded_by_path={},
        target_rows_by_period={
            "training": 0,
            "selection": 0,
            "development_gate": 0,
            "heldout_or_later": 1,
            "boundary_target": 0,
        },
        astronomical_tide_model_open_count=0,
    )
    with pytest.raises(RuntimeError, match="2024-or-later"):
        assert_forbidden_target_access_is_zero(audit)


def test_explicit_forbidden_byte_parse_and_load_counters_are_hard_stops():
    for field in (
        "heldout_target_bytes_read",
        "heldout_target_rows_parsed",
        "heldout_target_values_loaded",
        "boundary_target_bytes_read",
        "boundary_target_rows_parsed",
        "boundary_target_values_loaded",
    ):
        audit = replace(DataAccessAudit(
            opened_paths=(),
            bytes_read_by_path={},
            rows_parsed_by_path={},
            values_loaded_by_path={},
            target_rows_by_period={
                "training": 0,
                "selection": 0,
                "development_gate": 0,
                "heldout_or_later": 0,
                "boundary_target": 0,
            },
            astronomical_tide_model_open_count=0,
        ), **{field: 1})
        with pytest.raises(RuntimeError, match="forbidden target counter"):
            assert_forbidden_target_access_is_zero(audit)


def test_split_builder_has_fixed_keys_and_uses_only_paired_records():
    data = _data()
    datasets = build_split_datasets(data)
    assert tuple(datasets) == ("training", "selection", "development_gate")
    grouped = data.paired_records_by_split
    assert datasets["training"].records == grouped["training"]
    assert datasets["selection"].records == grouped["selection"] == ()
    assert datasets["development_gate"].records == grouped["development_gate"] == ()


def test_cross_calendar_year_origins_are_never_registered():
    hour_count = 144
    times = np.asarray(
        [
            datetime(2020, 12, 29, tzinfo=BEIJING) + timedelta(hours=index)
            for index in range(hour_count)
        ],
        dtype=object,
    )
    stages = np.ones((hour_count, 6), dtype=np.float64)
    targets = np.ones((hour_count, 4), dtype=np.float64)
    tide = np.ones(hour_count, dtype=np.float64)
    sets = enumerate_record_sets(times, stages, targets, tide)
    assert all(
        (record.issue_time_beijing - timedelta(hours=23)).year
        == record.issue_time_beijing.year
        == (record.issue_time_beijing + timedelta(hours=24)).year
        for record in sets.paired_filter_records
    )
    assert sets.exclusion_counts["paired_filter"]["cross_calendar_year"] > 0


def test_fit_normalization_rejects_non_training_records():
    times, stages, targets, tide = _arrays()
    sets = enumerate_record_sets(times, stages, targets, tide)
    bad_record = replace(
        sets.paired_filter_records[0],
        issue_time_beijing=datetime(2022, 6, 2, tzinfo=BEIJING),
    )
    with pytest.raises(ValueError, match="2017--2021"):
        fit_four_space_normalization(stages, targets, tide, (bad_record,))
