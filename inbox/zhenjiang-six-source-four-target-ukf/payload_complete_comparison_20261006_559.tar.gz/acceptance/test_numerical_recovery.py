import copy
from pathlib import Path

import pytest
import torch

from src.training import clip_finite_gradients, train_group


@pytest.mark.parametrize('scale',[0.,.01,1.,10.,1e10])
def test_ordinary_clipping_matches_original_bitwise(scale):
    a=torch.nn.Parameter(torch.zeros(4));a.grad=torch.tensor([1.,-2.,3.,-4.])*scale
    b=torch.nn.Parameter(torch.zeros(4));b.grad=a.grad.clone()
    expected=torch.nn.utils.clip_grad_norm_([a],1.,error_if_nonfinite=True)
    actual=clip_finite_gradients([b])
    assert torch.equal(expected,actual) and torch.equal(a.grad,b.grad)


def test_finite_float32_gradient_norm_overflow_preserves_direction_and_bound():
    a=torch.nn.Parameter(torch.zeros(3));a.grad=torch.tensor([1e20,-2e20,3e20])
    original=a.grad.clone()
    with pytest.raises(RuntimeError):torch.nn.utils.clip_grad_norm_([a],1.,error_if_nonfinite=True)
    assert torch.equal(a.grad,original)
    norm=clip_finite_gradients([a])
    expected=original.double()/torch.linalg.vector_norm(original.double())
    assert torch.isfinite(norm) and torch.allclose(a.grad.double(),expected,atol=1e-7,rtol=1e-7)
    assert float(torch.linalg.vector_norm(a.grad.double()))==pytest.approx(1.,abs=1e-7)


@pytest.mark.parametrize('bad',[float('inf'),float('nan')])
def test_invalid_gradient_is_still_rejected(bad):
    a=torch.nn.Parameter(torch.zeros(1));a.grad=torch.tensor([bad])
    with pytest.raises(FloatingPointError):clip_finite_gradients([a])


def test_continuation_above_200_keeps_group_budget_and_existing_history(tmp_path):
    class Session:
        def __init__(self,n):
            self.values=[2.]*190+[1.9]*10+[1.8]*(n-200)
            self.before=list(self.values);self.run_dir=tmp_path/str(n);self.run_dir.mkdir()
        def epoch(self,w,t,b,e):
            assert e==len(self.values)+1
            self.values.append(1.8)
        def finish(self,e,final):
            assert e==400 and final and len(self.values)==400
            assert self.values[:len(self.before)]==self.before
            return {'validation_mae':self.values}
    sessions={'a':Session(221),'b':Session(205)}
    results,epochs=train_group(sessions,None,None,None)
    assert epochs==400 and all(len(row['validation_mae'])==400 for row in results.values())


def test_migration_hash_preserves_optimizer_and_detects_tensor_changes(tmp_path):
    import importlib.util
    path=Path('/data1/home/sunyiq/zhenjiang_complete_comparison_20261015_recovery_005/hpc/prepare_recovery.py')
    spec=importlib.util.spec_from_file_location('recovery_prepare_test',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    state={'current':{'weights':torch.tensor([1.,2.])},
           'optimizer':{'step':torch.tensor(82.),'moment':torch.tensor([.1,.2])},
           'values':[3.,2.],'shuffle_hashes':['a','b']}
    before=module.state_hash(state)
    torch.save(state,tmp_path/'state.pt')
    restored=torch.load(tmp_path/'state.pt',weights_only=True)
    assert module.state_hash(restored)==before
    restored['optimizer']['moment'][0]+=1
    assert module.state_hash(restored)!=before
