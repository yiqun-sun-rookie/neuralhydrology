import copy
import numpy as np
import pytest
import torch
from src.contracts import combine_batches, ModelBatch
from src.models import make_parts, parameters
from src.training import (weighted_mae_cm,foundation_loss,foundation_predictions,train_effective_batch,
                          make_optimizer,best_epoch,extension_required,epoch_indices,select_learning_rate)

def test_weighted_loss_is_seven_thirds_cm(stats):
    targets=torch.zeros(1,2,4)
    pred=torch.tensor([1.,3.]).reshape(1,2,1).expand(1,2,4)/torch.tensor(stats.target_std.copy()*100)
    mask=torch.tensor([False,True]).reshape(1,2,1).expand(1,2,4)
    assert float(weighted_mae_cm(pred,targets,mask,stats))==pytest.approx(7/3)

@pytest.mark.parametrize('count',[16,5])
def test_micro_batches_match_full_batch_gradients_and_loss(count,batch,stats):
    b=combine_batches([batch]*count)
    mask=b.high_mask.clone(); mask[::2,:,1::2]=True
    b=ModelBatch(b.history,b.analysis_controls,b.forecast_controls,b.midpoint_controls,b.targets,b.targets_m,mask)
    a=make_parts('explicit_gru','small',17); c=copy.deepcopy(a)
    oa=make_optimizer(a,None,.001); oc=make_optimizer(c,None,.001)
    ra=train_effective_batch(a,None,None,'foundation',b,stats,oa,micro_batch=count)
    rc=train_effective_batch(c,None,None,'foundation',b,stats,oc,micro_batch=2)
    assert ra['loss_cm']==pytest.approx(rc['loss_cm'],abs=1e-6)
    differences=[float((p-q).abs().max()) for p,q in zip(parameters(a),parameters(c))]
    assert max(differences)<1e-6
    gradients=[float((p.grad-q.grad).abs().max()) for p,q in zip(parameters(a),parameters(c))]
    assert max(gradients)<2e-7

def test_foundation_two_normalized_losses_and_connected_gradients(batch,stats):
    p=make_parts('legacy_lstm','small',17)
    mid,end=foundation_predictions(p,batch)
    expected=.5*weighted_mae_cm(mid,batch.targets,batch.high_mask,stats)+.5*weighted_mae_cm(end,batch.targets[:,24:],batch.high_mask[:,24:],stats)
    assert torch.equal(foundation_loss(p,batch,stats),expected)
    expected.backward()
    assert all(q.grad is not None and torch.isfinite(q.grad).all() for q in parameters(p))

def test_earliest_best_nonfinite_and_group_extension():
    assert best_epoch([3.,2.,2.])==2
    with pytest.raises(ValueError): best_epoch([3.,np.nan])
    values={'a':[2.]*200,'b':[2.]*190+[1.9]*10}
    assert extension_required(values,200)
    assert extension_required({'a':[2.]*390+[1.9]*10},400)
    with pytest.raises(ValueError): extension_required({'a':[2.]*199},200)

def test_own_rate_choice_counterexample_and_ties():
    rates=(.0003,.001,.003)
    assert select_learning_rate(dict(zip(rates,[1,5,5])))==.0003
    assert select_learning_rate(dict(zip(rates,[10,2,3])))==.001
    assert select_learning_rate(dict(zip(rates,[1,1,1])))==.0003
    with pytest.raises(ValueError): select_learning_rate({.001:1})

def test_phase_shuffle_is_independent_and_reproducible():
    times=np.datetime64('2020-06-01')+np.arange(72)*np.timedelta64(1,'h')
    for epoch in range(1,13):
        ids,sha=epoch_indices(times,17,epoch)
        other,other_sha=epoch_indices(times,17,epoch)
        assert len(ids)==6 and np.array_equal(ids,other) and sha==other_sha
        assert ((times[ids].astype('datetime64[h]').astype(int)%12)==epoch-1).all()
