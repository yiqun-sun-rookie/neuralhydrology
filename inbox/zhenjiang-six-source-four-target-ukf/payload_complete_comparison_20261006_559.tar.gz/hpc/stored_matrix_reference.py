"""Diagnose the captured training failure using its exact stored operands.

Run only on HPC, CPU only, after the original006 isolated replay captures a
failure. The two diagnostic precisions never affect training or source files.
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path

import mpmath as mp
import torch


def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_bytes())
def tensor_sha(t): return hashlib.sha256(t.contiguous().numpy().tobytes()).hexdigest()
def matrix(t): return mp.matrix([[mp.mpf(float(x)) for x in row] for row in t.tolist()])
def pivots(a):
    lower = mp.matrix(a.rows)
    minimum = None
    for j in range(a.rows):
        pivot = a[j,j]-mp.fsum(lower[j,k]*lower[j,k] for k in range(j))
        minimum = pivot if minimum is None else min(minimum,pivot)
        if pivot <= 0:
            return dict(positive=False,first_nonpositive_index=j,pivot=mp.nstr(pivot,55),minimum_pivot=mp.nstr(minimum,55))
        lower[j,j] = mp.sqrt(pivot)
        for i in range(j+1,a.rows):
            lower[i,j] = (a[i,j]-mp.fsum(lower[i,k]*lower[j,k] for k in range(j)))/lower[j,j]
    return dict(positive=True,first_nonpositive_index=None,minimum_pivot=mp.nstr(minimum,55))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--diagnostic-root', type=Path, required=True)
    args = p.parse_args()
    root = args.diagnostic_root.resolve(strict=True)
    assert root.name == 'zhenjiang_training_covariance_failure_006_20261016_001'
    assert not torch.cuda.is_available()
    torch.set_num_threads(1)
    spec = read(root/'diagnostic_spec.json')
    result_path = root/'evidence/diagnostic_result.json'
    result_sha = sha(result_path)
    result = read(result_path)
    assert result['status'] == 'original_replay_failure_captured' and result['covariance_failure_observed']
    assert result['source_complete_epochs'] == 46 and result['source_optimizer_steps'] == 7060
    assert result['source_bytes_unchanged'] and result['source_code_unchanged']
    raw_path = root/'evidence/covariance_failure_operands.pt'
    raw_sha = sha(raw_path)
    analysis = read(root/'evidence/covariance_failure_analysis.json')
    assert any(x['path']==str(raw_path) and x['sha256']==raw_sha for x in analysis['artifacts'])
    raw = torch.load(raw_path,map_location='cpu',weights_only=True)
    assert raw['context'] == result['failure_context'] and raw['context']['epoch'] == 47
    assert raw['context']['phase'] == 'tuning_train'
    frames = {v['function']:v for v in raw['original_failure_traceback_frames']}
    values = frames['linear_update']['tensors']
    repair = frames['repair_rejected_members']
    index = repair['scalars']['i']
    candidate = repair['tensors']['candidate'][0]
    assert 0 <= index < values['p'].shape[0] and candidate.shape == (128,128)
    assert all(v.dtype==torch.float64 and bool(torch.isfinite(v).all()) for v in values.values())
    assert bool((values['r_diagonal']>0).all())
    jitters = [0.,1e-10,1e-9,1e-8,1e-7,1e-6,1e-5,.0001]
    assert raw['original_jitters'] == jitters
    source = Path(spec['source_root'])
    pinned = result['source_file_sha256']
    assert all(sha(Path(name))==digest for name,digest in pinned.items())
    assert all(sha(source/name)==digest for name,digest in spec['source_code_file_hashes'].items())
    tensors = {'stored_prior':values['covariance'][index], 'stored_posterior':values['p'][index], 'stored_compensated_candidate':candidate}
    assert all(bool(torch.isfinite(v).all()) for v in tensors.values())
    summaries = {name:dict(tensor_sha256=tensor_sha(v),entry_scale=float(v.abs().max()),minimum_diagonal=float(v.diagonal().min()),
        stored_symmetric=torch.equal(v,v.T)) for name,v in tensors.items()}
    references,nearest = [],[]
    eye = torch.eye(128,dtype=torch.float64)
    for digits in (80,120):
        with mp.workdps(digits):
            prepared = {name:(matrix(v)+matrix(v).T)/2 for name,v in tensors.items()}
            a,k,noise = [matrix(values[name][index]) for name in ['complement','gain','r']]
            exact = a*prepared['stored_prior']*a.T+k*noise*k.T
            exact = (exact+exact.T)/2
            rounded = torch.tensor([[float(exact[i,j]) for j in range(128)] for i in range(128)],dtype=torch.float64)
            row = dict(decimal_digits=digits,matrices={name:pivots(v) for name,v in prepared.items()},
                exact_same_joseph_from_stored_operands=pivots(exact),nearest_float64_reference=pivots(matrix(rounded)),
                nearest_float64_reference_sha256=tensor_sha(rounded),candidate_equals_nearest_float64_reference=torch.equal(candidate,rounded),
                maximum_original_difference=mp.nstr(max(abs(prepared['stored_posterior'][i,j]-exact[i,j]) for i in range(128) for j in range(128)),55),
                maximum_candidate_difference=mp.nstr(max(abs(prepared['stored_compensated_candidate'][i,j]-exact[i,j]) for i in range(128) for j in range(128)),55))
            # Reproduce actual float64 additions, including a jitter smaller
            # than one stored ULP. References do not secretly add exact jitter.
            row['original_float64_jitter_endpoint_admissibility'] = {name:[dict(jitter=j,**pivots(matrix((v+v.T)*.5+j*eye))) for j in (jitters[0],jitters[-1])] for name,v in tensors.items() if name!='stored_prior'}
            row['intermediate_jitter_bound']='Float64 addition changes only the diagonal monotonically; rejection at the largest jitter bounds all smaller permitted jitters.'
            references.append(row)
            nearest.append(rounded)
    assert torch.equal(nearest[0],nearest[1])
    for key in tensors:
        assert references[0]['matrices'][key]['positive'] == references[1]['matrices'][key]['positive']
    assert sha(raw_path)==raw_sha and sha(result_path)==result_sha
    assert all(sha(Path(name))==digest for name,digest in pinned.items())
    record = dict(status='failed006_exact_stored_training_operands_reference_complete',
        checked_at_beijing=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
        source_root=str(source),source_job='243692',diagnostic_root=str(root),source_code_hash=spec['source_code_hash'],
        source_complete_epochs=46,source_optimizer_steps=7060,source_checkpoint_sha256=spec['source_run_files']['continuation.pt']['sha256'],
        raw_operands_sha256=raw_sha,diagnostic_result_sha256=result_sha,context=raw['context'],failed_member_index=index,
        matrix_summaries=summaries,original_jitters=jitters,all_operands_finite=True,all_observation_noise_positive=True,
        high_precision_references=references,two_precision_nearest_reference_equal=True,source_bytes_unchanged=True,
        precision_applied_to_training=False,training_or_selection_inputs_read=False,evaluation_values_read=False,
        scheduler_mutated=False,formal_epochs_added=0,scientific_rules_changed=False,continuation_admitted=False)
    path = root/'evidence/failed006_stored_matrix_reference.json'
    with path.open('x',encoding='utf-8') as f:
        json.dump(record,f,sort_keys=True,allow_nan=False)
        f.write('\n')
    print(json.dumps(dict(status=record['status'],path=str(path),sha256=sha(path),formal_epochs_added=0)))


if __name__=='__main__': main()
