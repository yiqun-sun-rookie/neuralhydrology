"""Observe the original epoch45 path from the authenticated 44-epoch continuation.

python -B hpc/replay_covariance_diagnostic.py --source-root SOURCE \
  --diagnostic-root NEW_ROOT --run-id RUN --expected-code-sha256 CODE \
  --expected-config-sha256 CONFIG --expected-checkpoint-sha256 CHECKPOINT

Only tuning_train (2017--2020) is opened. Original source functions and Adam
updates are reused in memory for at most one epoch. Observers return the exact
original tensors and exceptions. A failed batch's start and covariance operands
are saved exclusively in NEW_ROOT/evidence. No validation, selection, epoch
commit, formal restart, jitter change or covariance correction is performed.
"""
import argparse
import datetime
import json
import os
from pathlib import Path
import traceback

import torch

from authenticated_source_helpers import (
    EventLog, capture_start, cpu_tree, import_source, prepare_new_root, read_json,
    require, sha256_file, tensor_summary, validate_adam, validate_checkpoint,
    validate_metadata, validate_spec, write_exclusive,
)

TARGET_RUN = 'explicit_gru__historical_capacity__tune_branch__filter_joint__s101__lr0p003'


def now():
    return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()


def save_tensor(path, value):
    with path.open('xb') as stream:
        torch.save(value, stream)
    return {'path': str(path), 'sha256': sha256_file(path), 'bytes': path.stat().st_size}


def portable_start(start):
    # Preserve the exact RNG values without requiring arbitrary pickle classes.
    numpy_state = start['rng']['numpy']
    start['rng']['numpy'] = (numpy_state[0], numpy_state[1].tolist(), *numpy_state[2:])
    return start


def spectrum(matrix):
    matrix = (matrix + matrix.transpose(-1, -2)) * .5
    finite = bool(torch.isfinite(matrix).all())
    value = {'finite': finite, 'dtype': str(matrix.dtype), 'shape': list(matrix.shape)}
    if not finite or matrix.ndim != 3:
        return value
    eigen = torch.linalg.eigvalsh(matrix)
    for name, tensor in {
        'minimum_eigenvalue': eigen.amin(-1), 'maximum_eigenvalue': eigen.amax(-1),
        'negative_eigenvalue_count': (eigen < 0).sum(-1),
        'maximum_absolute_entry': matrix.abs().amax((-1, -2)),
        'minimum_diagonal': matrix.diagonal(dim1=-2, dim2=-1).amin(-1),
        'maximum_diagonal': matrix.diagonal(dim1=-2, dim2=-1).amax(-1),
    }.items():
        value[name] = tensor.detach().cpu().tolist()
    scale = matrix.abs().amax((-1, -2)).clamp_min(torch.finfo(matrix.dtype).tiny)
    value['minimum_eigenvalue_over_entry_scale'] = (eigen.amin(-1) / scale).detach().cpu().tolist()
    return value


class CovarianceObserver:
    """Runtime-only observation in this diagnostic process; originals always run."""

    def __init__(self, api, evidence):
        self.api, self.evidence = api, evidence
        self.context = {}
        self.moments = None
        self.variances = None
        self.failure = None
        self.captures = []
        self.patches = []

    def patch(self, module, name, replacement):
        self.patches.append((module, name, getattr(module, name)))
        setattr(module, name, replacement)

    def install(self):
        f = self.api.filter
        original_moments = f.unscented_moments
        original_noise = f.noise_variances
        original_predict = f.unscented_predict
        original_cholesky = f.stable_cholesky
        original_slice = self.api.contracts.slice_batch

        def moments(points, wm, wc):
            output = original_moments(points, wm, wc)
            self.moments = {'points': points.detach(), 'wm': wm.detach(), 'wc': wc.detach(),
                            'mean': output[0].detach(), 'covariance': output[1].detach()}
            return output

        def noise(noise_parameters):
            output = original_noise(noise_parameters)
            self.variances = tuple(value.detach() for value in output)
            return output

        def predict(*args, **kwargs):
            self.context['analysis_step'] = self.context.get('analysis_step', 0) + 1
            self.moments, self.variances = None, None
            return original_predict(*args, **kwargs)

        def slice_batch(batch, selection):
            self.context.update(microbatch_start=selection.start, microbatch_stop=selection.stop,
                                analysis_step=0)
            return original_slice(batch, selection)

        def cholesky(p, ledger=None):
            try:
                return original_cholesky(p, ledger)
            except f.FilterFailure as error:
                if self.failure is None:
                    try:
                        self.capture(error, p)
                    except Exception as capture_error:
                        # Diagnostics must not substitute their error for the original.
                        write_exclusive(self.evidence / 'observer_capture_error.json', {
                            'original_reason': str(error), 'capture_error': str(capture_error),
                            'traceback': traceback.format_exc(), 'checked_at_beijing': now()})
                raise

        self.patch(f, 'unscented_moments', moments)
        self.patch(f, 'noise_variances', noise)
        self.patch(f, 'unscented_predict', predict)
        self.patch(f, 'stable_cholesky', cholesky)
        self.patch(self.api.training, 'slice_batch', slice_batch)
        self.patch(self.api.contracts, 'slice_batch', slice_batch)

    def capture(self, error, p):
        # Capture original operands before any alternative diagnostic arithmetic.
        operands = {'original_input_covariance': p.detach(), 'context': dict(self.context),
                    'original_error_evidence': error.evidence, 'moments': self.moments,
                    'noise_variances': self.variances,
                    'original_jitters': list(self.api.filter.JITTERS)}
        record = {'status': 'original_covariance_failure_observed', 'checked_at_beijing': now(),
                  'exception_type': type(error).__name__, 'reason': str(error),
                  'original_error_evidence': error.evidence, 'context': dict(self.context),
                  'stack': traceback.format_stack(), 'scientific_path_changed': False}
        self.failure = record
        self.captures.append(save_tensor(self.evidence / 'covariance_failure_operands.pt', cpu_tree(operands)))
        symmetric = self.api.filter.symmetric(p.detach())
        record['gpu_float64_spectrum'] = spectrum(symmetric)
        record['cpu_float64_spectrum'] = spectrum(symmetric.cpu())
        if symmetric.ndim == 3 and bool(torch.isfinite(symmetric).all()):
            eye = torch.eye(symmetric.shape[-1], dtype=symmetric.dtype, device=symmetric.device)
            record['original_cholesky_info_by_jitter'] = {
                str(j): torch.linalg.cholesky_ex(symmetric + j * eye)[1].cpu().tolist()
                for j in self.api.filter.JITTERS}
        if self.moments is not None:
            record['moment_tensor_summaries'] = {k: tensor_summary(v) for k, v in self.moments.items()}
            wc, wm = self.moments['wc'], self.moments['wm']
            record['all_covariance_weights_nonnegative'] = bool((wc >= 0).all())
            record['all_mean_weights_nonnegative'] = bool((wm >= 0).all())
            record['mean_weight_sum'] = float(wm.sum())
            if self.variances is not None:
                record['noise_variance_summaries'] = [tensor_summary(v) for v in self.variances]
                record['all_noise_variances_positive'] = all(bool((v > 0).all()) for v in self.variances)
                # Equivalent weighted Gram arithmetic is measured after the failure.
                # It never replaces the original covariance or feeds the optimizer.
                differences = self.moments['points'] - self.moments['mean'][:, None]
                if (self.moments['covariance'].shape == symmetric.shape and
                        bool((wc >= 0).all()) and bool(torch.isfinite(differences).all())):
                    weighted = differences * wc.sqrt()[None, :, None]
                    gram = torch.bmm(weighted.transpose(1, 2), weighted)
                    q = self.variances[0]
                    alternative = self.api.filter.symmetric(gram + torch.diag(q)[None])
                    record['diagnostic_gram_spectrum'] = spectrum(alternative)
                    record['diagnostic_gram_cpu_spectrum'] = spectrum(alternative.cpu())
                    record['diagnostic_gram_max_absolute_difference'] = float((alternative - symmetric).abs().max())
                    record['diagnostic_gram_shapes_match'] = list(alternative.shape) == list(symmetric.shape)
                    record['diagnostic_gram_used_in_training'] = False
                    self.captures.append(save_tensor(self.evidence / 'diagnostic_gram_after_failure.pt', cpu_tree({
                        'weighted_gram': gram, 'gram_plus_original_q': alternative})))
        record['artifacts'] = list(self.captures)
        write_exclusive(self.evidence / 'covariance_failure_analysis.json', record)

    def remove(self):
        for module, name, original in reversed(self.patches):
            setattr(module, name, original)


def execute(args):
    source, evidence = prepare_new_root(args.source_root, args.diagnostic_root)
    log = EventLog(evidence)
    api, pinned, observer, session = None, {}, None, None
    result = {'checked_at_beijing': now(), 'source_root': str(source), 'diagnostic_root': str(evidence.parent),
              'run_id': args.run_id, 'replayed_epoch': 45, 'formal_training_epochs_added': 0,
              'selection_input_values_read': False, 'validation_input_values_read': False,
              'evaluation_values_read': False, 'scientific_rules_changed': False,
              'source_failure_retained': True, 'successful_in_memory_batches': 0}
    exit_code = 1
    try:
        require(args.run_id == TARGET_RUN, 'only the specified failed member is admitted')
        spec_path = evidence.parent / 'diagnostic_spec.json'
        spec = read_json(spec_path)
        validate_spec(spec, source, evidence.parent, args)
        write_exclusive(evidence / 'diagnostic_spec_identity.json', {'sha256': sha256_file(spec_path), 'spec': spec})
        api = import_source(source, args.expected_code_sha256)
        run, config, protocol, manifest, seals, pinned = validate_metadata(source, args.run_id, args, api)
        group = read_json(source / 'records' / run['case'] / 'tune_branch_group_configs.json')
        require(len(group) == 12, 'all twelve source members must be retained')
        for rid in group:
            for name in ('config.json', 'continuation.pt', 'failure.json', 'metrics.json'):
                path = source / 'runs' / rid / name
                require(source in path.resolve(strict=True).parents, 'source group file escaped release')
                pinned[str(path)] = sha256_file(path)
        device = api.execution.device_identity(config['effective_config']['device'])
        require(device == spec['expected_device_identity'] == config['effective_config']['device_identity'], 'GPU identity differs')
        api.training.deterministic_runtime()
        torch.set_num_threads(4)
        state = torch.load(source / 'runs' / args.run_id / 'continuation.pt', map_location='cpu', weights_only=True)
        validate_checkpoint(state, args.expected_config_sha256, read_json(source / 'runs' / args.run_id / 'metrics.json'), 44)
        expected_steps = sum(len(rows) for rows in state['train_metrics'])
        require(expected_steps == spec['expected_optimizer_steps'], 'saved Adam step count differs')
        result.update(device_identity=device, source_complete_epochs=44, source_optimizer_steps=expected_steps,
                      source_file_sha256=pinned, source_code_sha256=args.expected_code_sha256,
                      historical_rng_equality_established=False,
                      rng_limit='Original continuation has no global RNG; original deterministic model path reused.')
        log.emit({'status': 'source_preflight_verified', 'complete_epochs': 44, 'optimizer_steps': expected_steps,
                  'device_identity': device, 'slurm_job_id': os.environ.get('SLURM_JOB_ID')})
        stage = api.runtime.load_stage(manifest, 'tuning_train')
        result['training_input_values_read'] = True
        stats = api.runtime.fit_stage_stats(stage, manifest)
        require(api.scheduler.digest_json(api.runtime.stats_record(stats)) == config['effective_config']['normalization_hash'],
                'training normalization differs from source')
        windows, issue_times = api.runtime.prepare_windows(stage, stats)
        for epoch in range(1, 45):
            ordered, sha = api.training.epoch_indices(issue_times, run['seed'], epoch)
            require(sha == state['shuffle_hashes'][epoch - 1] and len(state['train_metrics'][epoch - 1]) == (len(ordered) + 15) // 16,
                    'complete saved order or batch count differs at epoch ' + str(epoch))
        result['all_44_history_and_shuffle_prefixes_verified'] = True
        session = api.runtime.build_session(run, config, protocol, stats, evidence / 'scratch_session', seals)
        require(evidence in session.run_dir.resolve().parents, 'session directory escaped diagnostic evidence')
        api.training.restore_parts(session.parts, state['current'], session.noise)
        session.optimizer.load_state_dict(state['optimizer'])
        validate_adam(session, api, expected_steps)
        require(session.micro_batch == 2, 'frozen microbatch size differs')
        ordered, shuffle_sha = api.training.epoch_indices(issue_times, run['seed'], 45)
        require(len(ordered) > 0, 'empty replay epoch')
        write_exclusive(evidence / 'replay_identity.json', {
            'epoch': 45, 'shuffle_sha256': shuffle_sha, 'ordered_window_indices': ordered.tolist(),
            'effective_batch': 16, 'micro_batch': 2, 'source_sha256': pinned,
            'normalization_hash': config['effective_config']['normalization_hash'],
            'admitted_phase': 'tuning_train', 'years': [2017, 2018, 2019, 2020]})
        observer = CovarianceObserver(api, evidence)
        observer.install()
        for offset in range(0, len(ordered), 16):
            indices = ordered[offset:offset + 16]
            observer.context = {'epoch': 45, 'effective_batch_index': offset // 16 + 1,
                                'window_indices': indices.tolist(), 'analysis_step': 0}
            batch = api.execution.move_batch(api.contracts.combine_batches([windows[int(i)] for i in indices]), session.device)
            start = portable_start(capture_start(session, api))
            log.emit(dict(observer.context, status='effective_batch_started'))
            try:
                metric = api.training.train_effective_batch(session.parts, session.noise, session.whitening,
                    session.method, batch, session.stats, session.optimizer, session.micro_batch)
            except Exception as error:
                result.update(status='original_replay_failure_captured', exception_type=type(error).__name__,
                              reason=str(error), failure_context=dict(observer.context),
                              failure_traceback=traceback.format_exc(),
                              covariance_failure_observed=observer.failure is not None)
                result['failed_batch_start'] = save_tensor(evidence / 'failed_batch_start_model_adam_rng.pt', start)
                result['failure_model'] = save_tensor(evidence / 'failed_batch_current_model.pt',
                    api.training.snapshot_parts(session.parts, session.noise))
                result['failure_optimizer'] = save_tensor(evidence / 'failed_batch_current_adam.pt', cpu_tree(session.optimizer.state_dict()))
                result['covariance_analysis_path'] = str(evidence / 'covariance_failure_analysis.json') if observer.failure else None
                log.emit({'status': 'first_failure_stopped', 'context': result['failure_context'], 'reason': str(error)})
                exit_code = 0
                break
            result['successful_in_memory_batches'] += 1
            log.emit({'status': 'effective_batch_completed_in_memory', 'effective_batch_index': offset // 16 + 1, 'metric': metric})
        else:
            result.update(status='one_training_epoch_replayed_failure_not_reproduced', covariance_failure_observed=False)
            exit_code = 0
    except Exception as error:
        result.update(status='isolated_covariance_diagnostic_technical_error', exception_type=type(error).__name__,
                      reason=str(error), failure_traceback=traceback.format_exc())
    finally:
        if observer:
            observer.remove()
        if session is not None:
            result['final_in_memory_optimizer_steps'] = sorted(set(float(s['step']) for s in session.optimizer.state.values()))
        unchanged = {path: sha256_file(path) == sha for path, sha in pinned.items()}
        result['source_file_unchanged_checks'] = unchanged
        result['source_bytes_unchanged'] = bool(pinned) and all(unchanged.values())
        result['source_code_unchanged'] = api is not None and api.scheduler.code_identity(source) == args.expected_code_sha256
        if not result['source_bytes_unchanged'] or not result['source_code_unchanged']:
            exit_code = 1
        result.update(finished_at_beijing=now(), exit_code=exit_code)
        write_exclusive(evidence / 'diagnostic_result.json', result)
        log.emit({'status': 'isolated_covariance_diagnostic_finished', 'result_path': str(evidence / 'diagnostic_result.json'),
                  'result_status': result['status'], 'source_bytes_unchanged': result['source_bytes_unchanged'],
                  'formal_training_epochs_added': 0, 'exit_code': exit_code})
        log.close()
    return exit_code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('source-root', 'diagnostic-root', 'run-id', 'expected-code-sha256', 'expected-config-sha256', 'expected-checkpoint-sha256'):
        parser.add_argument('--' + name, required=True)
    return execute(parser.parse_args())


if __name__ == '__main__':
    raise SystemExit(main())
