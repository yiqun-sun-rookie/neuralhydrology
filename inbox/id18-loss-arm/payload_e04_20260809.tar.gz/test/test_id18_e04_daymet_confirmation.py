"""Frozen protocol tests for the ID18 post-2008 independent confirmation."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest

from neuralhydrology.utils.config import Config

from src.loss_mechanism_531.build_e04_confirmation_manifest import (
    confirmation_coverage,
    read_tail_lines,
)


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
CONFIG_ROOT = REPOSITORY_ROOT / "src" / "loss_mechanism_531" / "configs"
CONTRACT_PATH = CONFIG_ROOT / "e04_daymet_confirmation_contract.json"
CONFIRMATION_MANIFEST = CONFIG_ROOT / "e04_daymet_confirmation_basins.txt"
SOURCE_MANIFEST = (
    REPOSITORY_ROOT
    / "src"
    / "xaj_global_pilot"
    / "configs"
    / "conceptual_benchmark_camels_us_531_repro.txt"
)
HPC_ROOT = CONFIG_ROOT.parent / "hpc"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _ids(path: Path) -> list[str]:
    return [line.strip().zfill(8) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def test_contract_freezes_population_periods_models_arms_and_budget():
    contract = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))

    assert contract["experiment_id"] == "E04_daymet_post2008_objective_confirmation_482"
    assert contract["scope"] == "post_2008_independent_confirmation_not_paper_evaluation"
    assert contract["forcing"] == "daymet"
    assert contract["required_basin_count"] == 482
    assert set(contract["arms"]) == {"nse", "flow_regime_nse"}
    assert contract["neural_seeds"] == [100, 200, 300]
    assert len(contract["fixed_models"]) == 4
    assert contract["conceptual_calibration"] == {
        "cma_es_evaluations_per_restart": 5000,
        "restarts": 3,
        "restart_seeds": [42, 1042, 2042],
        "bounds_preset": "v1",
    }

    periods = contract["periods"]
    assert periods["conceptual_input_and_warmup_start"] == "1999-10-01"
    assert periods["optimization_target_start"] == "2000-09-30"
    assert periods["optimization_end"] == "2008-12-31"
    assert periods["confirmation_state_warmup_start"] == "2008-01-01"
    assert periods["confirmation_state_warmup_end"] == "2008-12-31"
    assert periods["confirmation_start"] == "2009-01-01"
    assert periods["confirmation_end"] == "2014-12-31"
    assert periods["forbidden_paper_evaluation_start"] == "1989-10-01"
    assert periods["forbidden_paper_evaluation_end"] == "1999-09-30"


def test_contract_freezes_missing_data_event_rule_and_verdicts():
    contract = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))

    cohort = contract["confirmation_cohort"]
    assert cohort["minimum_observation_completeness"] == pytest.approx(0.95)
    assert cohort["selection_uses_performance"] is False
    assert cohort["tail_lines_read_per_streamflow_file"] == 2192

    events = contract["event_definition"]
    assert events["threshold_quantiles"] == {"primary": 0.9, "sensitivity": 0.95}
    assert events["merge_gap_days"] == 2
    assert events["minimum_peak_separation_days"] == 5
    assert events["half_window_days"] == 3
    assert events["missing_observation_rule"] == (
        "Identify events separately within contiguous finite-observation segments; "
        "never merge across a missing day; exclude every seven-day window containing a missing observation."
    )

    decision = contract["decision_rule"]
    assert decision["bootstrap"] == {"unit": "whole_basin", "resamples": 10000, "seed": 20260809}
    assert set(decision["verdicts"]) == {
        "CONFIRMED",
        "GRADIENT_ONLY",
        "MODEL_DEPENDENCE_ONLY",
        "NOT_CONFIRMED",
    }


def test_confirmation_manifest_is_frozen_482_basin_subset_with_matching_hashes():
    contract = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))
    source = _ids(SOURCE_MANIFEST)
    confirmation = _ids(CONFIRMATION_MANIFEST)

    assert len(source) == len(set(source)) == 531
    assert len(confirmation) == len(set(confirmation)) == 482
    assert set(confirmation) < set(source)
    assert confirmation == sorted(confirmation)
    assert contract["basin_manifest"] == CONFIRMATION_MANIFEST.relative_to(REPOSITORY_ROOT).as_posix()
    assert contract["source_basin_manifest"] == SOURCE_MANIFEST.relative_to(REPOSITORY_ROOT).as_posix()
    assert contract["frozen_hashes"]["basin_manifest_sha256"] == _sha256(CONFIRMATION_MANIFEST)
    assert contract["frozen_hashes"]["source_basin_manifest_sha256"] == _sha256(SOURCE_MANIFEST)


def test_binary_tail_reader_returns_only_requested_final_lines(tmp_path):
    path = tmp_path / "streamflow.txt"
    path.write_bytes("".join(f"line-{index:04d}\r\n" for index in range(3000)).encode("ascii"))

    assert read_tail_lines(path, 3) == ["line-2997", "line-2998", "line-2999"]
    assert read_tail_lines(path, 3001)[0] == "line-0000"
    with pytest.raises(ValueError, match="positive"):
        read_tail_lines(path, 0)


def test_confirmation_coverage_ignores_preconfirmation_tail_row_and_counts_missing():
    lines = [
        "01022500 2008 12 31 12.0 A",
        "01022500 2009 01 01 10.0 A",
        "01022500 2009 01 02 -999.0 M",
        "01022500 2009 01 03 0.0 A",
        "01022500 2009 01 04 5.0 A",
    ]

    summary = confirmation_coverage(lines, start_date="2009-01-01", end_date="2009-01-04")

    assert summary == {
        "expected_day_count": 4,
        "row_count": 4,
        "valid_observation_count": 3,
        "completeness": 0.75,
        "first_date": "2009-01-01",
        "last_date": "2009-01-04",
    }


@pytest.mark.parametrize(
    "lines,match",
    [
        (["01022500 2009 01 01 1.0 A", "01022500 2009 01 01 2.0 A"], "duplicate"),
        (["malformed"], "malformed"),
    ],
)
def test_confirmation_coverage_rejects_ambiguous_rows(lines, match):
    with pytest.raises(ValueError, match=match):
        confirmation_coverage(lines, start_date="2009-01-01", end_date="2009-01-02")


def test_manifest_writer_refuses_to_replace_different_existing_file(tmp_path, monkeypatch):
    import src.loss_mechanism_531.build_e04_confirmation_manifest as builder

    output = tmp_path / "manifest.txt"
    output.write_text("different\n", encoding="utf-8")
    monkeypatch.setattr(builder, "build_confirmation_cohort", lambda *_: (["01022500"], {}))

    with pytest.raises(FileExistsError, match="refusing to overwrite"):
        builder.main([
            "--source-manifest", str(tmp_path / "source.txt"),
            "--data-root", str(tmp_path / "data"),
            "--output", str(output),
            "--write",
        ])

    assert output.read_text(encoding="utf-8") == "different\n"


def test_two_neural_templates_differ_only_in_registered_identity_output_and_loss():
    baseline = Config(CONFIG_ROOT / "e04_daymet_basin_nse.yml").as_dict()
    intervention = Config(CONFIG_ROOT / "e04_daymet_flow_regime_nse.yml").as_dict()
    differing = {
        key
        for key in set(baseline) | set(intervention)
        if baseline.get(key) != intervention.get(key)
    }

    assert differing == {"experiment_name", "run_dir", "loss"}
    assert baseline["loss"] == "BasinAverageNSE"
    assert intervention["loss"] == "BasinAverageFlowRegimeNSE"
    for config in (baseline, intervention):
        assert config["train_start_date"].isoformat() == "2000-09-30T00:00:00"
        assert config["train_end_date"].isoformat() == "2008-12-31T00:00:00"
        assert config["test_start_date"].isoformat() == "2009-01-01T00:00:00"
        assert config["test_end_date"].isoformat() == "2014-12-31T00:00:00"
        assert config["forcings"] == ["daymet"]
        assert config["dynamic_inputs"] == [
            "prcp(mm/day)",
            "tmin(C)",
            "tmax(C)",
            "srad(W/m2)",
            "vp(Pa)",
        ]
        assert config["train_basin_file"] == CONFIRMATION_MANIFEST.relative_to(REPOSITORY_ROOT)
        assert config["validation_basin_file"] == CONFIRMATION_MANIFEST.relative_to(REPOSITORY_ROOT)
        assert config["test_basin_file"] == CONFIRMATION_MANIFEST.relative_to(REPOSITORY_ROOT)
        assert config["epochs"] == 30
        assert config["seed"] == 100


def test_preparer_materializes_six_frozen_configs_without_mutating_templates(tmp_path):
    from src.loss_mechanism_531.prepare_e04_confirmation import materialize_formal_configs

    before = {
        path.name: path.read_bytes()
        for path in (CONFIG_ROOT / "e04_daymet_basin_nse.yml", CONFIG_ROOT / "e04_daymet_flow_regime_nse.yml")
    }
    generated = materialize_formal_configs(
        protocol_directory=tmp_path / "protocol",
        data_root=tmp_path / "camels_us",
        run_root=tmp_path / "runs",
    )

    assert len(generated) == 6
    assert {path.name for path in generated} == {
        f"{arm}_s{seed}.yml"
        for arm in ("nse", "flow_regime_nse")
        for seed in (100, 200, 300)
    }
    for path in generated:
        config = Config(path).as_dict()
        seed = int(path.stem.rsplit("s", 1)[1])
        arm = path.stem.rsplit("_s", 1)[0]
        assert config["seed"] == seed
        assert config["data_dir"] == tmp_path / "camels_us"
        assert config["run_dir"] == tmp_path / "runs" / arm
        assert config["experiment_name"] == f"E04_daymet_confirmation_{arm}_s{seed}"
    after = {path.name: path.read_bytes() for path in (
        CONFIG_ROOT / "e04_daymet_basin_nse.yml",
        CONFIG_ROOT / "e04_daymet_flow_regime_nse.yml",
    )}
    assert after == before


def test_preparer_materializes_two_non_scientific_smoke_configs(tmp_path):
    from src.loss_mechanism_531.prepare_e04_confirmation import materialize_smoke_configs

    manifest, configs = materialize_smoke_configs(
        smoke_directory=tmp_path / "smoke",
        data_root=tmp_path / "camels_us",
        run_root=tmp_path / "runs",
    )

    assert _ids(manifest) == [_ids(CONFIRMATION_MANIFEST)[0]]
    assert {path.name for path in configs} == {"nse_s100.yml", "flow_regime_nse_s100.yml"}
    for path in configs:
        config = Config(path).as_dict()
        assert config["epochs"] == 1
        assert config["save_weights_every"] == 1
        assert config["max_updates_per_epoch"] == 1
        assert config["seed"] == 100
        assert config["train_basin_file"] == manifest
        assert config["test_basin_file"] == manifest


def test_preflight_source_inventory_covers_direct_scoring_and_model_dependencies():
    from src.loss_mechanism_531.prepare_e04_confirmation import _source_inventory

    inventory = _source_inventory()
    paths = {item["path"] for item in inventory}

    assert {
        "src/hydroagent/data_loading.py",
        "src/scl_hydro/hbv_lite_numpy.py",
        "src/xaj_global_pilot/gr4j_model.py",
        "src/xaj_global_pilot/xaj_model.py",
        "src/lstm_fair_531/scripts/hydrological_process_diagnostics.py",
        "src/lstm_fair_531/scripts/posthoc_cause_diagnostics.py",
        "src/loss_mechanism_531/run_e04_conceptual.py",
        "src/loss_mechanism_531/run_e04_neural.py",
        "src/loss_mechanism_531/score_e04_confirmation.py",
        "src/loss_mechanism_531/audit_e04_confirmation.py",
    }.issubset(paths)
    assert all(len(item["sha256"]) == 64 for item in inventory)


def test_neural_runner_cli_exposes_no_scientific_overrides():
    from src.loss_mechanism_531.run_e04_neural import _build_parser

    parser = _build_parser()
    parsed = parser.parse_args(["--arm", "nse", "--seed", "200", "--gpu", "-1"])

    assert parsed.arm == "nse"
    assert parsed.seed == 200
    assert parsed.gpu == -1
    assert not any(action.dest in {
        "config_file",
        "train_start_date",
        "train_end_date",
        "test_start_date",
        "test_end_date",
        "epochs",
        "basin_file",
        "forcing",
    } for action in parser._actions)


def test_neural_prediction_integrity_check_uses_dates_and_basin_ids_not_scores(tmp_path):
    import pickle

    import numpy as np
    import pandas as pd
    import xarray as xr

    from src.loss_mechanism_531.run_e04_neural import validate_prediction_file

    dates = pd.date_range("2009-01-01", "2009-01-03", freq="D")
    payload = {}
    for basin_id in ("01022500", "01031500"):
        payload[basin_id] = {
            "1D": {
                "xr": xr.Dataset(
                    {
                        "QObs(mm/d)_obs": (("date", "time_step"), np.array([[1.0], [np.nan], [2.0]])),
                        "QObs(mm/d)_sim": (("date", "time_step"), np.array([[0.8], [1.1], [2.2]])),
                    },
                    coords={"date": dates, "time_step": [0]},
                )
            }
        }
    path = tmp_path / "test_results.p"
    path.write_bytes(pickle.dumps(payload))

    result = validate_prediction_file(
        path,
        expected_basins=["01022500", "01031500"],
        expected_start="2009-01-01",
        expected_end="2009-01-03",
    )

    assert result == {
        "basin_count": 2,
        "date_count": 3,
        "start_date": "2009-01-01",
        "end_date": "2009-01-03",
        "all_simulations_finite": True,
    }


def test_neural_prediction_integrity_check_rejects_missing_basin(tmp_path):
    import pickle

    from src.loss_mechanism_531.run_e04_neural import validate_prediction_file

    path = tmp_path / "test_results.p"
    path.write_bytes(pickle.dumps({}))
    with pytest.raises(ValueError, match="basin set"):
        validate_prediction_file(
            path,
            expected_basins=["01022500"],
            expected_start="2009-01-01",
            expected_end="2009-01-03",
        )


def test_registry_contains_one_frozen_e04_row():
    import csv

    registry = CONFIG_ROOT.parent / "registry" / "experiments.csv"
    with registry.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    selected = [row for row in rows if row["experiment_id"] == "E04_daymet_post2008_objective_confirmation_482"]

    assert len(selected) == 1
    assert selected[0]["status"] == "protocol_frozen"
    assert selected[0]["basins"] == "482"
    assert selected[0]["optimization_period"] == "2000-09-30/2008-12-31"
    assert selected[0]["internal_holdout"] == "2009-01-01/2014-12-31"
    assert selected[0]["arms"] == "nse;flow_regime_nse"


def test_conceptual_runner_takes_scientific_settings_only_from_contract():
    from src.loss_mechanism_531.run_e04_conceptual import (
        _build_parser,
        frozen_settings,
    )

    parser = _build_parser()
    parsed = parser.parse_args(["--model", "gr4j", "--loss", "flow_regime_nse", "--smoke"])
    settings = frozen_settings(json.loads(CONTRACT_PATH.read_text(encoding="utf-8")), smoke=parsed.smoke)

    assert parsed.model == "gr4j"
    assert parsed.loss == "flow_regime_nse"
    assert not any(action.dest in {
        "calibration_start",
        "calibration_end",
        "confirmation_start",
        "confirmation_end",
        "forcing",
        "trials",
        "restarts",
        "limit",
    } for action in parser._actions)
    assert settings["input_start"] == "1999-10-01"
    assert settings["input_end"] == "2008-12-31"
    assert settings["state_warmup_start"] == "2008-01-01"
    assert settings["state_warmup_end"] == "2008-12-31"
    assert settings["confirmation_start"] == "2009-01-01"
    assert settings["confirmation_end"] == "2014-12-31"
    assert settings["forcing"] == "daymet"
    assert settings["trials"] == 5
    assert settings["restarts"] == 1
    assert settings["restart_seeds"] == [42]
    assert settings["basin_limit"] == 1
    assert settings["non_scientific_smoke"] is True


def test_formal_conceptual_settings_preserve_registered_budget():
    from src.loss_mechanism_531.run_e04_conceptual import frozen_settings

    settings = frozen_settings(json.loads(CONTRACT_PATH.read_text(encoding="utf-8")), smoke=False)

    assert settings["trials"] == 5000
    assert settings["restarts"] == 3
    assert settings["restart_seeds"] == [42, 1042, 2042]
    assert settings["basin_limit"] is None
    assert settings["non_scientific_smoke"] is False


def test_hpc_scripts_use_isolated_root_and_required_cluster_safety_settings():
    scripts = {path.name: path.read_text(encoding="utf-8") for path in sorted(HPC_ROOT.glob("e04_*.slurm"))}

    assert set(scripts) == {
        "e04_conceptual.slurm",
        "e04_neural.slurm",
        "e04_score.slurm",
        "e04_smoke.slurm",
    }
    for text in scripts.values():
        assert "#SBATCH -p hgpu2p" in text
        assert "#SBATCH --exclude=ngu002" in text
        assert "set -eo pipefail" in text
        assert "conda activate nh_final" in text
        assert "id18_e04_20260809" in text
        assert "${E04_CODE_ROOT}:${E04_BASE_REPO}" in text
        assert "--mem" not in text
        assert "srun " not in text
        assert "1989-10-01" not in text
        assert "1999-09-30" not in text
    assert "#SBATCH --cpus-per-task=28" in scripts["e04_conceptual.slurm"]
    assert "#SBATCH --gres=gpu:1" not in scripts["e04_conceptual.slurm"]
    assert "#SBATCH --gres=gpu:1" in scripts["e04_neural.slurm"]
    assert "#SBATCH --gres=gpu:1" in scripts["e04_smoke.slurm"]
    assert "#SBATCH --gres=gpu:1" not in scripts["e04_score.slurm"]


def test_event_segments_never_cross_missing_observations():
    import numpy as np
    import pandas as pd

    from src.loss_mechanism_531.score_e04_confirmation import finite_observation_segments

    dates = pd.date_range("2009-01-01", periods=12, freq="D")
    observations = np.array([1.0, 2.0, np.nan, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, np.nan, 9.0, 10.0])
    segments = finite_observation_segments(dates, observations, minimum_length=2)

    assert [indices.tolist() for indices in segments] == [[0, 1], [3, 4, 5, 6, 7, 8], [10, 11]]
    assert all(np.isfinite(observations[indices]).all() for indices in segments)
    assert all(np.all(np.diff(indices) == 1) for indices in segments)


def test_event_metrics_exclude_windows_touching_missing_days():
    import numpy as np
    import pandas as pd

    from src.loss_mechanism_531.score_e04_confirmation import collect_one_series_event_metrics

    dates = pd.date_range("2009-01-01", periods=41, freq="D")
    observations = np.ones(41, dtype=float)
    observations[10] = 10.0
    observations[20] = np.nan
    observations[30] = 9.0
    simulations = np.nan_to_num(observations, nan=1.0)
    definition = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))["event_definition"]

    rows = collect_one_series_event_metrics(
        dates,
        observations,
        simulations,
        quantile=0.8,
        definition=definition,
    )

    assert len(rows) == 2
    assert set(pd.to_datetime(rows["observed_peak_date"])) == {dates[10], dates[30]}
    assert rows["aligned_peak_magnitude_bias"].abs().max() == pytest.approx(0.0)
    assert rows["event_peak_concentration"].min() == pytest.approx(1.0)
    assert rows["event_peak_concentration"].max() == pytest.approx(1.0)


def test_event_metrics_return_typed_empty_table_when_no_event_window_is_valid():
    import numpy as np
    import pandas as pd

    from src.loss_mechanism_531.score_e04_confirmation import EVENT_METRICS, collect_one_series_event_metrics

    dates = pd.date_range("2009-01-01", periods=41, freq="D")
    observations = np.ones(41, dtype=float)
    simulations = observations.copy()
    definition = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))["event_definition"]

    rows = collect_one_series_event_metrics(
        dates,
        observations,
        simulations,
        quantile=0.9,
        definition=definition,
    )

    assert rows.empty
    assert set(EVENT_METRICS).issubset(rows.columns)


def _synthetic_confirmation_metric_tables(*, xaj_variability_change: float = 0.30):
    import pandas as pd

    models = ("gr4j", "hbv_lite", "lstm_three_seed_ensemble", "xaj")
    variability_changes = {
        "gr4j": 0.20,
        "hbv_lite": 0.25,
        "lstm_three_seed_ensemble": 0.10,
        "xaj": xaj_variability_change,
    }
    full_rows = []
    event_rows = []
    for basin_index in range(40):
        basin_id = f"{basin_index:08d}"
        for model in models:
            for arm in ("nse", "flow_regime_nse"):
                intervention = arm == "flow_regime_nse"
                full_rows.append({
                    "basin_id": basin_id,
                    "model": model,
                    "arm": arm,
                    "variability_ratio": 0.8 + (variability_changes[model] if intervention else 0.0),
                    "correlation": 0.7 + (0.01 if intervention else 0.0),
                })
                for quantile in (0.9, 0.95):
                    event_rows.append({
                        "basin_id": basin_id,
                        "model": model,
                        "arm": arm,
                        "event_threshold_quantile": quantile,
                        "aligned_peak_magnitude_bias": 0.2 if intervention else 0.0,
                        "event_peak_concentration": 0.04 if intervention else 0.0,
                        "absolute_peak_timing_error_days": 1.2 if intervention else 1.0,
                    })
    return pd.DataFrame(full_rows), pd.DataFrame(event_rows)


def test_registered_decision_confirms_clean_synthetic_gradient_and_model_dependence():
    from src.loss_mechanism_531.score_e04_confirmation import build_decision

    full, events = _synthetic_confirmation_metric_tables()
    criteria, decision = build_decision(
        full,
        events,
        json.loads(CONTRACT_PATH.read_text(encoding="utf-8")),
    )

    assert criteria["passed"].all()
    assert decision["gradient_passed"] is True
    assert decision["model_dependence_passed"] is True
    assert decision["verdict"] == "CONFIRMED"


def test_registered_decision_reports_gradient_only_without_xaj_lstm_separation():
    from src.loss_mechanism_531.score_e04_confirmation import build_decision

    full, events = _synthetic_confirmation_metric_tables(xaj_variability_change=0.10)
    criteria, decision = build_decision(
        full,
        events,
        json.loads(CONTRACT_PATH.read_text(encoding="utf-8")),
    )

    dependence = criteria[criteria["criterion"] == "model_dependence"]
    assert not dependence["passed"].all()
    assert decision["gradient_passed"] is True
    assert decision["model_dependence_passed"] is False
    assert decision["verdict"] == "GRADIENT_ONLY"


def test_independent_audit_does_not_import_formal_e04_scorer():
    source = (CONFIG_ROOT.parent / "audit_e04_confirmation.py").read_text(encoding="utf-8")

    assert "score_e04_confirmation import" not in source
    assert "from .score_e04_confirmation" not in source


def test_independent_frame_comparison_enforces_fixed_numeric_tolerance():
    import pandas as pd

    from src.loss_mechanism_531.audit_e04_confirmation import compare_frames

    expected = pd.DataFrame({"basin_id": ["a", "b"], "metric": [1.0, 2.0], "label": ["x", "y"]})
    within = pd.DataFrame({
        "basin_id": ["b", "a"],
        "metric": [2.0 + 5e-11, 1.0 - 5e-11],
        "label": ["y", "x"],
    })
    outside = within.copy()
    outside.loc[outside["basin_id"] == "b", "metric"] = 2.0 + 2e-10

    accepted = compare_frames(expected, within, key_columns=["basin_id"], tolerance=1e-10)
    rejected = compare_frames(expected, outside, key_columns=["basin_id"], tolerance=1e-10)

    assert accepted["passed"] is True
    assert accepted["maximum_numeric_difference"] == pytest.approx(5e-11)
    assert rejected["passed"] is False
    assert rejected["maximum_numeric_difference"] == pytest.approx(2e-10)


def test_independent_frame_comparison_rejects_moved_or_sign_changed_infinity():
    import numpy as np
    import pandas as pd

    from src.loss_mechanism_531.audit_e04_confirmation import compare_frames

    expected = pd.DataFrame({"key": ["a", "b"], "value": [np.inf, 0.0]})
    moved = pd.DataFrame({"key": ["a", "b"], "value": [0.0, np.inf]})
    changed_sign = pd.DataFrame({"key": ["a", "b"], "value": [-np.inf, 0.0]})

    assert compare_frames(expected, moved, key_columns=["key"])["passed"] is False
    assert compare_frames(expected, changed_sign, key_columns=["key"])["passed"] is False


def test_independent_decision_matches_registered_synthetic_verdict():
    from src.loss_mechanism_531.audit_e04_confirmation import recompute_decision

    full, events = _synthetic_confirmation_metric_tables()
    criteria, decision = recompute_decision(
        full,
        events,
        json.loads(CONTRACT_PATH.read_text(encoding="utf-8")),
    )

    assert criteria["passed"].all()
    assert decision["verdict"] == "CONFIRMED"
