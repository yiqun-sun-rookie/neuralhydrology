"""Train and evaluate one frozen E04 neural arm and seed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import pickle
import subprocess
import sys

import numpy as np
import pandas as pd
from ruamel.yaml import YAML

from .prepare_e04_confirmation import (
    ARMS,
    CONTRACT_PATH,
    EXPERIMENT_ID,
    REPOSITORY_ROOT,
    SEEDS,
    _write_new_or_verify,
    load_and_validate_contract,
    sha256,
)


LOSS_NAMES = {
    "nse": "BasinAverageNSE",
    "flow_regime_nse": "BasinAverageFlowRegimeNSE",
}


def _build_parser() -> argparse.ArgumentParser:
    contract = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))
    result_root = REPOSITORY_ROOT / contract["registered_result_root"]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", choices=tuple(ARMS), required=True)
    parser.add_argument("--seed", choices=SEEDS, type=int, required=True)
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--protocol-root", type=Path, default=result_root / "protocol")
    parser.add_argument("--result-root", type=Path, default=result_root)
    parser.add_argument("--smoke", action="store_true")
    return parser


def _variables(dataset) -> tuple[str, str]:
    observation = [name for name in dataset.data_vars if str(name).endswith("_obs")]
    simulation = [name for name in dataset.data_vars if str(name).endswith("_sim")]
    if len(observation) != 1 or len(simulation) != 1:
        raise ValueError(f"expected one observation and simulation variable, got {list(dataset.data_vars)}")
    return str(observation[0]), str(simulation[0])


def _vector(dataset, variable: str) -> np.ndarray:
    values = np.asarray(dataset[variable].values)
    if values.ndim == 2 and values.shape[1] == 1:
        values = values[:, 0]
    if values.ndim != 1:
        raise ValueError(f"unexpected prediction shape for {variable}: {values.shape}")
    return values.astype(np.float64)


def validate_prediction_file(
    path: Path,
    *,
    expected_basins: list[str],
    expected_start: str,
    expected_end: str,
) -> dict:
    """Check only population, dates, shape, and finiteness; do not compute a score."""
    payload = pickle.loads(Path(path).read_bytes())
    if not isinstance(payload, dict):
        raise ValueError("neural prediction artifact is not a basin dictionary")
    normalized = {str(key).zfill(8): key for key in payload}
    if len(normalized) != len(payload) or set(normalized) != set(expected_basins):
        raise ValueError("neural prediction basin set differs from the frozen manifest")

    expected_dates = pd.date_range(expected_start, expected_end, freq="D")
    all_finite = True
    for basin_id in expected_basins:
        dataset = payload[normalized[basin_id]]["1D"]["xr"]
        dates = pd.DatetimeIndex(dataset["date"].values)
        if not dates.equals(expected_dates):
            raise ValueError(f"neural prediction dates drifted for basin {basin_id}")
        _, simulation_variable = _variables(dataset)
        simulation = _vector(dataset, simulation_variable)
        if simulation.size != expected_dates.size:
            raise ValueError(f"neural prediction length drifted for basin {basin_id}")
        all_finite = all_finite and bool(np.isfinite(simulation).all())
    if not all_finite:
        raise ValueError("neural prediction contains non-finite simulations")
    return {
        "basin_count": len(expected_basins),
        "date_count": len(expected_dates),
        "start_date": expected_dates[0].date().isoformat(),
        "end_date": expected_dates[-1].date().isoformat(),
        "all_simulations_finite": True,
    }


def _read_yaml(path: Path) -> dict:
    yaml = YAML(typ="safe")
    with Path(path).open("r", encoding="utf-8") as handle:
        return yaml.load(handle)


def _read_ids(path: Path) -> list[str]:
    basins = [line.strip().zfill(8) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(basins) != len(set(basins)):
        raise ValueError("neural basin manifest contains duplicate identifiers")
    return basins


def _validate_config(config_path: Path, *, arm: str, seed: int, smoke: bool, contract: dict) -> tuple[dict, list[str]]:
    config = _read_yaml(config_path)
    expected_epochs = 1 if smoke else 30
    expected_name = (
        f"E04_daymet_confirmation_smoke_{arm}_s100"
        if smoke
        else f"E04_daymet_confirmation_{arm}_s{seed}"
    )
    expected = {
        "experiment_name": expected_name,
        "loss": LOSS_NAMES[arm],
        "seed": seed,
        "epochs": expected_epochs,
        "forcings": ["daymet"],
        "train_start_date": "30/09/2000",
        "train_end_date": "31/12/2008",
        "test_start_date": "01/01/2009",
        "test_end_date": "31/12/2014",
    }
    for key, value in expected.items():
        if config.get(key) != value:
            raise ValueError(f"E04 neural config drifted at {key}: {config.get(key)!r} != {value!r}")
    manifest_paths = {Path(config[key]) for key in ("train_basin_file", "validation_basin_file", "test_basin_file")}
    if len(manifest_paths) != 1:
        raise ValueError("E04 neural train, validation, and test basin manifests differ")
    manifest = next(iter(manifest_paths))
    if not manifest.is_absolute():
        manifest = REPOSITORY_ROOT / manifest
    basins = _read_ids(manifest)
    expected_count = 1 if smoke else int(contract["required_basin_count"])
    if len(basins) != expected_count:
        raise ValueError(f"E04 neural config has {len(basins)} basins, expected {expected_count}")
    if not smoke and sha256(manifest) != contract["frozen_hashes"]["basin_manifest_sha256"]:
        raise ValueError("E04 neural basin manifest hash drifted")
    return config, basins


def _find_complete_run(config: dict) -> Path | None:
    root = Path(config["run_dir"])
    epoch = int(config["epochs"])
    candidates = sorted(root.glob(f"{config['experiment_name']}_*_ep{epoch}"))
    complete = [path for path in candidates if (path / f"model_epoch{epoch:03d}.pt").exists()]
    if len(complete) > 1:
        raise RuntimeError(f"multiple complete E04 neural runs found: {complete}")
    return complete[0] if complete else None


def _run_logged(command: list[str], log_path: Path) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8", newline="") as log:
        log.write("COMMAND " + " ".join(command) + "\n")
        log.flush()
        subprocess.run(command, cwd=REPOSITORY_ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)
    if args.smoke and args.seed != 100:
        raise ValueError("E04 smoke is frozen to seed 100")
    contract = load_and_validate_contract()
    config_path = (
        args.result_root / "smoke" / "configs" / f"{args.arm}_s100.yml"
        if args.smoke
        else args.protocol_root / "generated_configs" / f"{args.arm}_s{args.seed}.yml"
    )
    config, basins = _validate_config(
        config_path,
        arm=args.arm,
        seed=args.seed,
        smoke=args.smoke,
        contract=contract,
    )
    epoch = int(config["epochs"])
    run_directory = _find_complete_run(config)
    log_root = args.result_root / ("smoke/logs/neural" if args.smoke else "logs/neural")
    log_path = log_root / f"{args.arm}_s{args.seed}.log"
    if run_directory is None:
        _run_logged([
            sys.executable,
            "-X",
            "utf8",
            "-m",
            "src.loss_mechanism_531.run_neural_loss_experiment",
            "train",
            "--config-file",
            str(config_path),
            "--gpu",
            str(args.gpu),
        ], log_path)
        run_directory = _find_complete_run(config)
        if run_directory is None:
            raise RuntimeError("E04 training completed without the frozen final checkpoint")

    prediction_path = run_directory / "test" / f"model_epoch{epoch:03d}" / "test_results.p"
    if not prediction_path.exists():
        _run_logged([
            sys.executable,
            "-X",
            "utf8",
            "-m",
            "src.loss_mechanism_531.run_neural_loss_evaluation_repair",
            "evaluate",
            "--run-dir",
            str(run_directory),
            "--period",
            "test",
            "--epoch",
            str(epoch),
            "--gpu",
            str(args.gpu),
        ], log_path)
    if not prediction_path.exists():
        raise RuntimeError("E04 evaluation completed without a prediction artifact")

    integrity = validate_prediction_file(
        prediction_path,
        expected_basins=basins,
        expected_start=contract["periods"]["confirmation_start"],
        expected_end=contract["periods"]["confirmation_end"],
    )
    completion_root = args.result_root / ("smoke/neural_completions" if args.smoke else "protocol/neural_completions")
    completion = {
        "experiment_id": EXPERIMENT_ID,
        "arm": args.arm,
        "seed": args.seed,
        "epoch": epoch,
        "non_scientific_smoke": bool(args.smoke),
        "config_path": str(config_path.resolve()),
        "config_sha256": sha256(config_path),
        "run_directory": str(run_directory.resolve()),
        "prediction_path": str(prediction_path.resolve()),
        "prediction_sha256": sha256(prediction_path),
        "integrity": integrity,
    }
    _write_new_or_verify(
        completion_root / f"{args.arm}_s{args.seed}.json",
        json.dumps(completion, ensure_ascii=False, indent=2) + "\n",
    )
    print(json.dumps({
        "arm": args.arm,
        "seed": args.seed,
        "epoch": epoch,
        "basin_count": integrity["basin_count"],
        "status": "complete",
    }))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
