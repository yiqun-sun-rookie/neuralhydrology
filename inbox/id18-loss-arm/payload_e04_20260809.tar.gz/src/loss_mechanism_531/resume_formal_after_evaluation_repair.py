"""Resume E01 after the evaluation-only runtime registration failure.

This coordinator preserves the frozen training and scoring entry points.  It
uses the repair wrapper only for evaluation of the flow-regime loss arm and
records all post-preflight repair files in a separate immutable manifest.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from . import run_formal_experiment as formal

REPAIR_ID = "E01_evaluation_registration_repair_20260801"
ORIGINAL_NEURAL_MODULE = "src.loss_mechanism_531.run_neural_loss_experiment"
REPAIRED_EVALUATION_MODULE = "src.loss_mechanism_531.run_neural_loss_evaluation_repair"
REPAIR_MANIFEST_PATH = formal.PROTOCOL_ROOT / "evaluation_repair_manifest.json"
REPAIR_SOURCE_FILES = (
    formal.SOURCE_ROOT / "evaluation_repair.py",
    formal.SOURCE_ROOT / "run_neural_loss_evaluation_repair.py",
    formal.SOURCE_ROOT / "resume_formal_after_evaluation_repair.py",
    formal.REPOSITORY_ROOT / "test" / "test_id18_flow_regime_evaluation_repair.py",
)


def evaluation_module_for_arm(arm: str) -> str:
    """Return the frozen wrapper except for the repaired evaluation path."""
    if arm == "flow_regime_nse":
        return REPAIRED_EVALUATION_MODULE
    if arm == "nse":
        return ORIGINAL_NEURAL_MODULE
    raise ValueError(f"unknown neural arm: {arm}")


def _repair_manifest_payload() -> dict:
    state = formal._load_state()
    return {
        "repair_id": REPAIR_ID,
        "experiment_id": formal.EXPERIMENT_ID,
        "created_utc": formal._utc_now(),
        "failure_signature": (
            "NotImplementedError: BasinAverageFlowRegimeNSE not implemented or not linked in get_loss()"
        ),
        "prior_state_error": state.get("error"),
        "scope": "evaluation runtime registration and evaluation-only sample weights",
        "training_changed": False,
        "checkpoint_selection_changed": False,
        "formal_scoring_changed": False,
        "original_preflight_sha256": formal._sha256(formal.PROTOCOL_ROOT / "preflight.json"),
        "repair_source_files": [
            {
                "path": path.relative_to(formal.REPOSITORY_ROOT).as_posix(),
                "sha256": formal._sha256(path),
            }
            for path in REPAIR_SOURCE_FILES
        ],
    }


def _register_or_verify_repair_manifest() -> dict:
    if REPAIR_MANIFEST_PATH.exists():
        manifest = formal._load_json(REPAIR_MANIFEST_PATH)
        if manifest.get("repair_id") != REPAIR_ID:
            raise RuntimeError("evaluation repair manifest identity changed")
        for record in manifest.get("repair_source_files", []):
            path = formal.REPOSITORY_ROOT / record["path"]
            if formal._sha256(path) != record["sha256"]:
                raise RuntimeError(f"evaluation repair source changed after registration: {path}")
        return manifest

    payload = _repair_manifest_payload()
    formal._write_json(REPAIR_MANIFEST_PATH, payload)
    return payload


def _run_neural_jobs(state: dict) -> None:
    config_root = formal.PROTOCOL_ROOT / "generated_configs"
    for arm, seed in formal.NEURAL_JOBS:
        label = f"{arm}/seed-{seed}"
        run_directory = formal._find_neural_run(arm, seed)
        prediction_path = (
            run_directory / "test" / "model_epoch030" / "test_results.p"
            if run_directory is not None
            else None
        )
        if prediction_path is not None and prediction_path.exists():
            formal._record_job(
                state,
                kind="neural",
                label=label,
                status="completed",
                run_directory=str(run_directory),
                resumed=True,
            )
            continue

        resources = formal._resource_snapshot()
        if not resources["passed"]:
            raise RuntimeError(f"resource gate failed before {label}: {resources}")
        formal._record_job(
            state,
            kind="neural",
            label=label,
            status="running",
            resources_before=resources,
            evaluation_repair=arm == "flow_regime_nse",
        )
        log_path = formal.LOG_ROOT / "neural" / f"{arm}_s{seed}.log"

        if run_directory is None:
            config_path = config_root / f"{arm}_s{seed}.yml"
            config = formal._read_yaml(config_path)
            if config["seed"] != seed or config["loss"] not in {
                    "BasinAverageNSE", "BasinAverageFlowRegimeNSE"}:
                raise RuntimeError(f"generated neural configuration differs from contract: {config_path}")
            formal._run_logged([
                sys.executable,
                "-X",
                "utf8",
                "-m",
                ORIGINAL_NEURAL_MODULE,
                "train",
                "--config-file",
                str(config_path),
                "--gpu",
                "0",
            ], log_path)
            run_directory = formal._find_neural_run(arm, seed)
            if run_directory is None:
                raise RuntimeError(f"training completed without epoch-30 checkpoint: {label}")

        formal._run_logged([
            sys.executable,
            "-X",
            "utf8",
            "-m",
            evaluation_module_for_arm(arm),
            "evaluate",
            "--run-dir",
            str(run_directory),
            "--period",
            "test",
            "--epoch",
            "30",
            "--gpu",
            "0",
        ], log_path)
        prediction_path = run_directory / "test" / "model_epoch030" / "test_results.p"
        if not prediction_path.exists():
            raise RuntimeError(f"evaluation completed without daily prediction artifact: {label}")
        formal._record_job(
            state,
            kind="neural",
            label=label,
            status="completed",
            run_directory=str(run_directory),
            evaluation_repair=arm == "flow_regime_nse",
        )


def main() -> int:
    formal._acquire_lock()
    state = formal._load_state()
    state["status"] = "running"
    formal._save_state(state)
    try:
        formal._verify_preflight()
        repair_manifest = _register_or_verify_repair_manifest()
        state["evaluation_repair"] = {
            "repair_id": REPAIR_ID,
            "manifest_path": str(REPAIR_MANIFEST_PATH),
            "manifest_sha256": formal._sha256(REPAIR_MANIFEST_PATH),
        }
        formal._save_state(state)
        preflight = formal._verify_preflight()
        formal._run_conceptual_jobs(state, preflight["resolved_data_root"])
        _run_neural_jobs(state)
        formal._run_logged([
            sys.executable,
            "-X",
            "utf8",
            "-m",
            "src.loss_mechanism_531.score_flow_regime_loss_experiment",
            "--result-root",
            str(formal.RESULT_ROOT),
            "--neural-run-root",
            str(formal.REPOSITORY_ROOT / "runs" / "e01_loss"),
        ], formal.LOG_ROOT / "scoring.log")
        state["status"] = "scored_pending_independent_audit"
        state["completed_utc"] = formal._utc_now()
        state["evaluation_repair"]["manifest_sha256"] = formal._sha256(REPAIR_MANIFEST_PATH)
        state["evaluation_repair"]["registered_file_count"] = len(repair_manifest["repair_source_files"])
        formal._save_state(state)
        return 0
    except Exception as error:
        state["status"] = "failed"
        state["error"] = f"{type(error).__name__}: {error}"
        formal._save_state(state)
        raise
    finally:
        formal._write_json(formal.LOCK_PATH, {
            "process_id": __import__("os").getpid(),
            "released_utc": formal._utc_now(),
            "status": state["status"],
            "repair_id": REPAIR_ID,
        })


if __name__ == "__main__":
    raise SystemExit(main())
