"""Run one isolated conceptual-model arm of the flow-regime loss experiment."""

from __future__ import annotations

import argparse
import json
import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

for _variable in (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
):
    os.environ.setdefault(_variable, "1")

import numpy as np
import pandas as pd

from .conceptual_calibration import calibrate_conceptual_model, resolve_model_definition

EXPERIMENT_ID = "E01_flow_regime_balanced_loss_531"
CALIBRATION_START = "1999-10-01"
CALIBRATION_END = "2005-09-30"
EVALUATION_START = "2005-10-01"
EVALUATION_END = "2008-09-30"
FORCING = "maurer"
PET_METHOD = "priestley_taylor"
DISCHARGE_NORMALIZATION = "common_forcing_header_float32"


def _default_data_root() -> str:
    repository_root = Path(__file__).resolve().parents[2]
    candidates = (
        repository_root / "data" / "camels_us",
        repository_root.parents[1] / "data" / "camels_us",
    )
    for candidate in candidates:
        if (candidate / "basin_mean_forcing" / "maurer").is_dir():
            return str(candidate)
    return "data/camels_us"


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", choices=["gr4j", "xaj", "hbv_lite"], required=True)
    parser.add_argument("--loss", choices=["nse", "flow_regime_nse", "tail_downweighted_nse"], required=True)
    parser.add_argument(
        "--experiment-id",
        default=None,
        help=("Identifier stamped into run metadata. Defaults to the registered experiment whose output root "
              "is being written, inferred from --output-root, so a second experiment reusing this runner is "
              "not labelled with the first experiment's identifier."))
    parser.add_argument("--calibration-start", default=CALIBRATION_START)
    parser.add_argument("--calibration-end", default=CALIBRATION_END)
    parser.add_argument("--evaluation-start", default=EVALUATION_START)
    parser.add_argument("--evaluation-end", default=EVALUATION_END)
    parser.add_argument(
        "--manifest",
        default="src/xaj_global_pilot/configs/conceptual_benchmark_camels_us_531_repro.txt",
    )
    parser.add_argument("--data-root", default=_default_data_root())
    parser.add_argument(
        "--output-root",
        default=f"results/18_lstm_fair_531/{EXPERIMENT_ID}/conceptual",
    )
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--trials", type=int, default=5000)
    parser.add_argument("--restarts", type=int, default=3)
    parser.add_argument("--bounds-preset", default="v1")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--skip-existing", dest="skip_existing", action="store_true", default=True)
    parser.add_argument("--no-skip-existing", dest="skip_existing", action="store_false")
    return parser


def _validate_frozen_periods(args: argparse.Namespace) -> None:
    actual = (
        args.calibration_start,
        args.calibration_end,
        args.evaluation_start,
        args.evaluation_end,
    )
    expected = (CALIBRATION_START, CALIBRATION_END, EVALUATION_START, EVALUATION_END)
    if actual != expected:
        raise ValueError(f"Experiment periods are frozen at {expected}, got {actual}")
    if args.workers < 1 or args.trials < 1 or args.restarts < 1:
        raise ValueError("workers, trials, and restarts must all be positive")


def _extract_forcing(frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    rain = np.nan_to_num(frame["prcp"].to_numpy(dtype=np.float64), nan=0.0)
    pet_column = "ep" if "ep" in frame.columns else "pet" if "pet" in frame.columns else None
    if pet_column is None:
        raise RuntimeError("Forcing data contain neither ep nor pet")
    pet = np.nan_to_num(frame[pet_column].to_numpy(dtype=np.float64), nan=0.0)
    temperature = (
        np.nan_to_num(frame["tmean"].to_numpy(dtype=np.float64), nan=0.0)
        if "tmean" in frame.columns
        else np.zeros_like(rain)
    )
    return rain, pet, temperature


def _serialize_state(state, state_names: tuple[str, ...]) -> dict[str, float]:
    if isinstance(state, dict):
        return {name: float(state.get(name, 0.0)) for name in state_names}
    values = np.asarray(state, dtype=np.float64).reshape(-1)
    return {
        name: float(values[index]) if index < values.size else 0.0
        for index, name in enumerate(state_names)
    }


def _run_one(task: tuple) -> dict:
    (
        basin_id,
        model,
        loss,
        data_root,
        trials,
        restarts,
        bounds_preset,
        model_dir,
    ) = task
    from hydroagent.data_loading import load_camels_basin
    from xaj_global_pilot.metrics import compute_metrics

    start_time = time.time()
    try:
        definition = resolve_model_definition(model, bounds_preset=bounds_preset)
        forcing_calibration, observations_calibration, _ = load_camels_basin(
            basin_id,
            data_root=data_root,
            start_date=CALIBRATION_START,
            end_date=CALIBRATION_END,
            forcing=FORCING,
            pet_method=PET_METHOD,
            keep_obs_nan_days=True,
            discharge_normalization=DISCHARGE_NORMALIZATION,
        )
        rain, pet, temperature = _extract_forcing(forcing_calibration)
        calibration = calibrate_conceptual_model(
            definition,
            rain,
            pet,
            temperature,
            observations_calibration.to_numpy(dtype=np.float64),
            loss=loss,
            n_trials=trials,
            n_restarts=restarts,
        )
        parameters = calibration["optimized_params"]

        warmup_start = (
            pd.Timestamp(EVALUATION_START) - pd.DateOffset(years=1)
        ).strftime("%Y-%m-%d")
        warmup_end = (
            pd.Timestamp(EVALUATION_START) - pd.DateOffset(days=1)
        ).strftime("%Y-%m-%d")
        forcing_warmup, _, _ = load_camels_basin(
            basin_id,
            data_root=data_root,
            start_date=warmup_start,
            end_date=warmup_end,
            forcing=FORCING,
            pet_method=PET_METHOD,
            keep_obs_nan_days=True,
            discharge_normalization=DISCHARGE_NORMALIZATION,
        )
        rain_warmup, pet_warmup, temperature_warmup = _extract_forcing(forcing_warmup)
        _, evaluation_initial_state = definition.simulate(
            rain_warmup,
            pet_warmup,
            temperature_warmup,
            parameters,
            initial_state=None,
        )

        forcing_evaluation, observations_evaluation, _ = load_camels_basin(
            basin_id,
            data_root=data_root,
            start_date=EVALUATION_START,
            end_date=EVALUATION_END,
            forcing=FORCING,
            pet_method=PET_METHOD,
            keep_obs_nan_days=True,
            discharge_normalization=DISCHARGE_NORMALIZATION,
        )
        rain_evaluation, pet_evaluation, temperature_evaluation = _extract_forcing(forcing_evaluation)
        predictions, _ = definition.simulate(
            rain_evaluation,
            pet_evaluation,
            temperature_evaluation,
            parameters,
            initial_state=evaluation_initial_state,
        )
        predictions = np.asarray(predictions, dtype=np.float64)
        prediction_series = pd.Series(predictions, index=observations_evaluation.index, name="simulation")
        metrics = compute_metrics(observations_evaluation, prediction_series)

        model_directory = Path(model_dir)
        daily_directory = model_directory / "daily"
        daily_directory.mkdir(parents=True, exist_ok=True)
        pd.DataFrame({
            "basin_id": basin_id,
            "date": observations_evaluation.index,
            "observation": observations_evaluation.to_numpy(dtype=np.float64),
            "simulation": predictions,
        }).to_csv(daily_directory / f"{basin_id}.csv", index=False)

        row = {
            "basin_id": basin_id,
            "model": model,
            "loss_arm": loss,
            "period": "internal_holdout",
            **metrics,
            "run_status": "success",
            "error_message": "",
            "elapsed_seconds": round(time.time() - start_time, 3),
            "calibration_nse": calibration["nse"],
            "calibration_loss": calibration["loss"],
            "calibration_warmup_days": calibration["warmup_days"],
            "forcing": FORCING,
            "pet_method": PET_METHOD,
            "discharge_normalization": DISCHARGE_NORMALIZATION,
            "bounds_preset": bounds_preset,
            "trials": trials,
            "restarts": restarts,
            "state_init_mode": f"warmup_end_{warmup_end}",
        }
        for name, value in parameters.items():
            row[f"p_{name}"] = float(value)
        for name, value in _serialize_state(evaluation_initial_state, definition.state_names).items():
            row[f"state_{name}"] = value
        pd.DataFrame([row]).to_csv(model_directory / f"{basin_id}.csv", index=False)
        return row
    except Exception as error:
        row = {
            "basin_id": basin_id,
            "model": model,
            "loss_arm": loss,
            "period": "internal_holdout",
            "run_status": "failed",
            "error_message": f"{type(error).__name__}: {error}",
            "elapsed_seconds": round(time.time() - start_time, 3),
        }
        Path(model_dir).mkdir(parents=True, exist_ok=True)
        pd.DataFrame([row]).to_csv(Path(model_dir) / f"{basin_id}.csv", index=False)
        return row


def _read_basin_ids(path: Path) -> list[str]:
    basins = [
        line.strip().zfill(8)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if len(basins) != len(set(basins)):
        raise ValueError("Basin manifest contains duplicate identifiers")
    return basins


def _resolve_experiment_id(args) -> str:
    """Return the identifier to stamp into run metadata.

    An explicit ``--experiment-id`` wins. Otherwise the identifier is read from the output root,
    whose layout is ``results/18_lstm_fair_531/<experiment_id>/conceptual``. This keeps a second
    registered experiment from inheriting the first one's identifier when it reuses this runner.
    """
    if args.experiment_id:
        return args.experiment_id
    for part in Path(args.output_root).resolve().parts[::-1]:
        if part.startswith("E") and "_" in part:
            return part
    return EXPERIMENT_ID


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)
    _validate_frozen_periods(args)
    basins = _read_basin_ids(Path(args.manifest))
    if args.limit is not None:
        if args.limit < 1:
            raise ValueError("limit must be positive")
        basins = basins[:args.limit]

    model_directory = Path(args.output_root) / args.loss / args.model
    model_directory.mkdir(parents=True, exist_ok=True)
    pending = [
        basin
        for basin in basins
        if not args.skip_existing
        or not (model_directory / f"{basin}.csv").exists()
        or not (model_directory / "daily" / f"{basin}.csv").exists()
    ]
    tasks = [
        (
            basin,
            args.model,
            args.loss,
            args.data_root,
            args.trials,
            args.restarts,
            args.bounds_preset,
            str(model_directory),
        )
        for basin in pending
    ]

    rows: list[dict] = []
    if tasks:
        with ProcessPoolExecutor(max_workers=args.workers) as executor:
            futures = {executor.submit(_run_one, task): task[0] for task in tasks}
            for index, future in enumerate(as_completed(futures), start=1):
                row = future.result()
                rows.append(row)
                print(
                    f"[{index}/{len(tasks)}] {row['basin_id']} {row['run_status']} "
                    f"{row['elapsed_seconds']:.1f}s",
                    flush=True,
                )

    all_rows = []
    for basin in basins:
        path = model_directory / f"{basin}.csv"
        if path.exists():
            all_rows.append(pd.read_csv(path, dtype={"basin_id": str}))
    summary = pd.concat(all_rows, ignore_index=True) if all_rows else pd.DataFrame()
    summary_path = model_directory / "calibration_summary.csv"
    summary.to_csv(summary_path, index=False)
    metadata = {
        "experiment_id": _resolve_experiment_id(args),
        "model": args.model,
        "loss_arm": args.loss,
        "basin_count_requested": len(basins),
        "basin_count_success": int((summary.get("run_status") == "success").sum()) if not summary.empty else 0,
        "calibration_start": CALIBRATION_START,
        "optimization_target_start": "2000-09-30",
        "calibration_end": CALIBRATION_END,
        "evaluation_start": EVALUATION_START,
        "evaluation_end": EVALUATION_END,
        "trials": args.trials,
        "restarts": args.restarts,
        "workers": args.workers,
        "non_scientific_smoke": bool(args.limit is not None or args.trials != 5000 or args.restarts != 3),
    }
    (model_directory / "run_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return 0 if metadata["basin_count_success"] == len(basins) else 1


if __name__ == "__main__":
    raise SystemExit(main())
