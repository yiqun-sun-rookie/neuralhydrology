"""Run one frozen conceptual-model arm of the E04 independent confirmation."""

from __future__ import annotations

import argparse
import io
import json
import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

for _variable in (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
):
    os.environ.setdefault(_variable, "1")

import numpy as np
import pandas as pd

from .conceptual_calibration import calibrate_conceptual_model, resolve_model_definition
from .prepare_e04_confirmation import CONTRACT_PATH, EXPERIMENT_ID, REPOSITORY_ROOT, load_and_validate_contract, sha256


MODELS = ("gr4j", "xaj", "hbv_lite")
LOSSES = ("nse", "flow_regime_nse")


def frozen_settings(contract: dict, *, smoke: bool) -> dict:
    """Resolve every scientific setting from the registered contract."""
    if contract["experiment_id"] != EXPERIMENT_ID:
        raise ValueError("E04 experiment identifier drifted")
    if contract["forcing"] != "daymet" or set(contract["arms"]) != set(LOSSES):
        raise ValueError("E04 forcing or objective arms drifted")
    periods = contract["periods"]
    calibration = contract["conceptual_calibration"]
    return {
        "input_start": periods["conceptual_input_and_warmup_start"],
        "input_end": periods["optimization_end"],
        "optimization_target_start": periods["optimization_target_start"],
        "state_warmup_start": periods["confirmation_state_warmup_start"],
        "state_warmup_end": periods["confirmation_state_warmup_end"],
        "confirmation_start": periods["confirmation_start"],
        "confirmation_end": periods["confirmation_end"],
        "forcing": contract["forcing"],
        "pet_method": contract["pet_method_for_conceptual_models"],
        "discharge_normalization": contract["discharge_normalization"],
        "bounds_preset": calibration["bounds_preset"],
        "trials": 5 if smoke else int(calibration["cma_es_evaluations_per_restart"]),
        "restarts": 1 if smoke else int(calibration["restarts"]),
        "restart_seeds": (
            [int(calibration["restart_seeds"][0])]
            if smoke
            else [int(seed) for seed in calibration["restart_seeds"]]
        ),
        "basin_limit": 1 if smoke else None,
        "non_scientific_smoke": bool(smoke),
    }


def _default_data_root() -> Path:
    candidates = (
        REPOSITORY_ROOT / "data/camels_us",
        REPOSITORY_ROOT.parents[1] / "data/camels_us",
    )
    for candidate in candidates:
        if (candidate / "basin_mean_forcing/daymet").is_dir():
            return candidate
    return REPOSITORY_ROOT / "data/camels_us"


def _build_parser() -> argparse.ArgumentParser:
    contract = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))
    result_root = REPOSITORY_ROOT / contract["registered_result_root"]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", choices=MODELS, required=True)
    parser.add_argument("--loss", choices=LOSSES, required=True)
    parser.add_argument("--contract", type=Path, default=CONTRACT_PATH)
    parser.add_argument("--data-root", type=Path, default=_default_data_root())
    parser.add_argument("--output-root", type=Path, default=result_root / "conceptual")
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--no-skip-existing", dest="skip_existing", action="store_false", default=True)
    return parser


def _extract_forcing(frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    rain = np.nan_to_num(frame["prcp"].to_numpy(dtype=np.float64), nan=0.0)
    pet_column = "ep" if "ep" in frame.columns else "pet" if "pet" in frame.columns else None
    if pet_column is None:
        raise RuntimeError("forcing data contain neither ep nor pet")
    potential_evapotranspiration = np.nan_to_num(frame[pet_column].to_numpy(dtype=np.float64), nan=0.0)
    temperature = (
        np.nan_to_num(frame["tmean"].to_numpy(dtype=np.float64), nan=0.0)
        if "tmean" in frame.columns
        else np.zeros_like(rain)
    )
    return rain, potential_evapotranspiration, temperature


def _serialize_state(state, state_names: tuple[str, ...]) -> dict[str, float]:
    if isinstance(state, dict):
        return {name: float(state.get(name, 0.0)) for name in state_names}
    values = np.asarray(state, dtype=np.float64).reshape(-1)
    return {name: float(values[index]) if index < values.size else 0.0 for index, name in enumerate(state_names)}


def _read_basin_ids(path: Path, expected_count: int) -> list[str]:
    basins = [line.strip().zfill(8) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(basins) != len(set(basins)) or len(basins) != expected_count:
        raise ValueError(f"E04 manifest must contain {expected_count} unique basins")
    return basins


def _dataframe_csv(frame: pd.DataFrame) -> str:
    buffer = io.StringIO()
    frame.to_csv(buffer, index=False, lineterminator="\n")
    return buffer.getvalue()


def _write_new(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="") as handle:
        handle.write(content)


def _write_new_or_verify(path: Path, content: str) -> None:
    if path.exists():
        if path.read_text(encoding="utf-8") != content:
            raise FileExistsError(f"refusing to overwrite a different E04 artifact: {path}")
        return
    _write_new(path, content)


def _run_one(task: tuple) -> dict:
    basin_id, model, loss, data_root, model_directory, settings, contract_hash, manifest_hash = task
    from hydroagent.data_loading import load_camels_basin
    from xaj_global_pilot.metrics import compute_metrics

    started = time.time()
    try:
        definition = resolve_model_definition(model, bounds_preset=settings["bounds_preset"])
        forcing_input, observations_input, _ = load_camels_basin(
            basin_id,
            data_root=data_root,
            start_date=settings["input_start"],
            end_date=settings["input_end"],
            forcing=settings["forcing"],
            pet_method=settings["pet_method"],
            keep_obs_nan_days=True,
            discharge_normalization=settings["discharge_normalization"],
        )
        rain, pet, temperature = _extract_forcing(forcing_input)
        calibration = calibrate_conceptual_model(
            definition,
            rain,
            pet,
            temperature,
            observations_input.to_numpy(dtype=np.float64),
            loss=loss,
            n_trials=settings["trials"],
            n_restarts=settings["restarts"],
            restart_seeds=tuple(settings["restart_seeds"]),
        )
        parameters = calibration["optimized_params"]

        forcing_warmup, _, _ = load_camels_basin(
            basin_id,
            data_root=data_root,
            start_date=settings["state_warmup_start"],
            end_date=settings["state_warmup_end"],
            forcing=settings["forcing"],
            pet_method=settings["pet_method"],
            keep_obs_nan_days=True,
            discharge_normalization=settings["discharge_normalization"],
        )
        warmup_rain, warmup_pet, warmup_temperature = _extract_forcing(forcing_warmup)
        _, confirmation_state = definition.simulate(
            warmup_rain,
            warmup_pet,
            warmup_temperature,
            parameters,
            initial_state=None,
        )

        forcing_confirmation, observations_confirmation, _ = load_camels_basin(
            basin_id,
            data_root=data_root,
            start_date=settings["confirmation_start"],
            end_date=settings["confirmation_end"],
            forcing=settings["forcing"],
            pet_method=settings["pet_method"],
            keep_obs_nan_days=True,
            discharge_normalization=settings["discharge_normalization"],
        )
        confirmation_rain, confirmation_pet, confirmation_temperature = _extract_forcing(forcing_confirmation)
        predictions, _ = definition.simulate(
            confirmation_rain,
            confirmation_pet,
            confirmation_temperature,
            parameters,
            initial_state=confirmation_state,
        )
        predictions = np.asarray(predictions, dtype=np.float64)
        if predictions.shape != observations_confirmation.to_numpy().shape:
            raise ValueError("confirmation prediction shape does not match observations")
        prediction_series = pd.Series(predictions, index=observations_confirmation.index, name="simulation")
        metrics = compute_metrics(observations_confirmation, prediction_series)

        row = {
            "experiment_id": EXPERIMENT_ID,
            "contract_sha256": contract_hash,
            "basin_manifest_sha256": manifest_hash,
            "basin_id": basin_id,
            "model": model,
            "loss_arm": loss,
            "period": "post_2008_independent_confirmation",
            **metrics,
            "run_status": "success",
            "elapsed_seconds": round(time.time() - started, 3),
            "calibration_nse": calibration["nse"],
            "calibration_loss": calibration["loss"],
            "calibration_warmup_days": calibration["warmup_days"],
            "forcing": settings["forcing"],
            "pet_method": settings["pet_method"],
            "discharge_normalization": settings["discharge_normalization"],
            "bounds_preset": settings["bounds_preset"],
            "trials": settings["trials"],
            "restarts": settings["restarts"],
            "input_start": settings["input_start"],
            "input_end": settings["input_end"],
            "optimization_target_start": settings["optimization_target_start"],
            "confirmation_start": settings["confirmation_start"],
            "confirmation_end": settings["confirmation_end"],
            "state_init_mode": (
                f"reset_and_warm_{settings['state_warmup_start']}_through_{settings['state_warmup_end']}"
            ),
            "non_scientific_smoke": settings["non_scientific_smoke"],
        }
        for name, value in parameters.items():
            row[f"p_{name}"] = float(value)
        for name, value in _serialize_state(confirmation_state, definition.state_names).items():
            row[f"state_{name}"] = value

        model_directory = Path(model_directory)
        summary_path = model_directory / f"{basin_id}.csv"
        daily_path = model_directory / "daily" / f"{basin_id}.csv"
        if summary_path.exists() or daily_path.exists():
            raise FileExistsError(f"E04 basin artifacts already exist for {basin_id}")
        daily = pd.DataFrame({
            "basin_id": basin_id,
            "date": observations_confirmation.index,
            "observation": observations_confirmation.to_numpy(dtype=np.float64),
            "simulation": predictions,
        })
        _write_new(daily_path, _dataframe_csv(daily))
        _write_new(summary_path, _dataframe_csv(pd.DataFrame([row])))
        return row
    except Exception as error:
        return {
            "basin_id": basin_id,
            "model": model,
            "loss_arm": loss,
            "run_status": "failed",
            "error_message": f"{type(error).__name__}: {error}",
            "elapsed_seconds": round(time.time() - started, 3),
        }


def _compatible_existing(path: Path, *, model: str, loss: str, contract_hash: str, manifest_hash: str) -> bool:
    if not path.exists():
        return False
    row = pd.read_csv(path, dtype={"basin_id": str}).iloc[0]
    expected = {
        "experiment_id": EXPERIMENT_ID,
        "model": model,
        "loss_arm": loss,
        "contract_sha256": contract_hash,
        "basin_manifest_sha256": manifest_hash,
        "run_status": "success",
    }
    actual = {key: str(row[key]) for key in expected}
    if actual != {key: str(value) for key, value in expected.items()}:
        raise ValueError(f"existing E04 basin artifact is incompatible: {path}")
    return True


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)
    if args.workers < 1:
        raise ValueError("workers must be positive")
    contract = load_and_validate_contract(args.contract)
    settings = frozen_settings(contract, smoke=args.smoke)
    manifest_path = REPOSITORY_ROOT / contract["basin_manifest"]
    basins = _read_basin_ids(manifest_path, contract["required_basin_count"])
    if settings["basin_limit"] is not None:
        basins = basins[:settings["basin_limit"]]

    output_root = args.output_root
    if args.smoke:
        output_root = args.output_root.parent / "smoke" / "conceptual"
    model_directory = output_root / args.loss / args.model
    contract_hash = sha256(args.contract)
    manifest_hash = sha256(manifest_path)

    pending = []
    for basin_id in basins:
        summary_path = model_directory / f"{basin_id}.csv"
        daily_path = model_directory / "daily" / f"{basin_id}.csv"
        complete = _compatible_existing(
            summary_path,
            model=args.model,
            loss=args.loss,
            contract_hash=contract_hash,
            manifest_hash=manifest_hash,
        )
        if complete and daily_path.exists() and args.skip_existing:
            continue
        if complete or daily_path.exists():
            raise FileExistsError(f"incomplete or explicitly non-skipped E04 artifacts exist for {basin_id}")
        pending.append(basin_id)

    tasks = [
        (
            basin_id,
            args.model,
            args.loss,
            str(args.data_root.resolve()),
            str(model_directory),
            settings,
            contract_hash,
            manifest_hash,
        )
        for basin_id in pending
    ]
    rows: list[dict] = []
    if tasks:
        with ProcessPoolExecutor(max_workers=args.workers) as executor:
            futures = {executor.submit(_run_one, task): task[0] for task in tasks}
            for index, future in enumerate(as_completed(futures), start=1):
                row = future.result()
                rows.append(row)
                print(
                    f"[{index}/{len(tasks)}] {row['basin_id']} {row['run_status']} "
                    f"{row['elapsed_seconds']:.1f}s",
                    flush=True,
                )

    failures = [row for row in rows if row["run_status"] != "success"]
    if failures:
        failure_root = model_directory / "failures"
        failure_root.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        _write_new(failure_root / f"attempt_{stamp}.csv", _dataframe_csv(pd.DataFrame(failures)))

    completed = []
    for basin_id in basins:
        path = model_directory / f"{basin_id}.csv"
        daily = model_directory / "daily" / f"{basin_id}.csv"
        if path.exists() and daily.exists() and _compatible_existing(
            path,
            model=args.model,
            loss=args.loss,
            contract_hash=contract_hash,
            manifest_hash=manifest_hash,
        ):
            completed.append(pd.read_csv(path, dtype={"basin_id": str}))
    if len(completed) == len(basins):
        summary = pd.concat(completed, ignore_index=True).sort_values("basin_id")
        _write_new_or_verify(model_directory / "calibration_summary.csv", _dataframe_csv(summary))
        completion = {
            "experiment_id": EXPERIMENT_ID,
            "model": args.model,
            "loss_arm": args.loss,
            "basin_count": len(basins),
            "contract_sha256": contract_hash,
            "basin_manifest_sha256": manifest_hash,
            "settings": settings,
        }
        _write_new_or_verify(
            model_directory / "completion.json",
            json.dumps(completion, ensure_ascii=False, indent=2) + "\n",
        )
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
