"""Run NeuralHydrology with the isolated flow-regime loss extension installed.

Usage is identical to ``python -m neuralhydrology.nh_run``.  Example:

    python -X utf8 -m src.loss_mechanism_531.run_neural_loss_experiment \
        train --config-file path/to/config.yml --gpu 0
"""

from neuralhydrology import nh_run

from .neural_extension import install_neural_extension


def main() -> None:
    install_neural_extension()
    nh_run._main()


if __name__ == "__main__":
    main()
