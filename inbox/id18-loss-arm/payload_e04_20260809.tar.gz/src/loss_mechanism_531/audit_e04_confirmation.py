"""Independently recompute E04 metrics and verdict from raw daily predictions."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from src.lstm_fair_531.scripts.hydrological_process_diagnostics import (
    compute_event_metrics,
    identify_observed_events,
)
from src.lstm_fair_531.scripts.posthoc_cause_diagnostics import event_peak_concentration
from src.loss_mechanism_531.prepare_e04_confirmation import (
    CONTRACT_PATH,
    EXPERIMENT_ID,
    REPOSITORY_ROOT,
    _write_new_or_verify,
    load_and_validate_contract,
    sha256,
)
from src.loss_mechanism_531.score_flow_regime_loss_experiment import (
    _load_conceptual_daily,
    load_neural_ensemble,
)


ARMS = ("nse", "flow_regime_nse")
CONCEPTUAL_MODELS = ("gr4j", "hbv_lite", "xaj")
NEURAL_MODEL = "lstm_three_seed_ensemble"
MODELS = (*CONCEPTUAL_MODELS, NEURAL_MODEL)
EVENT_METRICS = (
    "aligned_peak_magnitude_bias",
    "event_peak_concentration",
    "absolute_peak_timing_error_days",
)
TOLERANCE = 1e-10


def compare_frames(
    expected: pd.DataFrame,
    actual: pd.DataFrame,
    *,
    key_columns: list[str],
    tolerance: float = TOLERANCE,
) -> dict:
    """Compare keyed tables with exact labels and one fixed numeric tolerance."""
    if tolerance < 0.0:
        raise ValueError("tolerance must be nonnegative")
    if set(expected.columns) != set(actual.columns):
        return {
            "passed": False,
            "reason": "column sets differ",
            "maximum_numeric_difference": float("inf"),
        }
    for frame, name in ((expected, "expected"), (actual, "actual")):
        if frame.duplicated(key_columns).any():
            raise ValueError(f"{name} frame has duplicate keys")
    left = expected.sort_values(key_columns).reset_index(drop=True)
    right = actual.sort_values(key_columns).reset_index(drop=True)
    if len(left) != len(right):
        return {
            "passed": False,
            "reason": "row counts differ",
            "maximum_numeric_difference": float("inf"),
        }
    maximum = 0.0
    labels_match = True
    numeric_match = True
    for column in left.columns:
        left_values = left[column]
        right_values = right[column]
        numeric = pd.api.types.is_numeric_dtype(left_values) and pd.api.types.is_numeric_dtype(right_values)
        if numeric:
            first = left_values.to_numpy(dtype=float)
            second = right_values.to_numpy(dtype=float)
            if not np.array_equal(np.isnan(first), np.isnan(second)):
                numeric_match = False
                continue
            finite = np.isfinite(first) & np.isfinite(second)
            first_infinite = np.isinf(first)
            second_infinite = np.isinf(second)
            if (
                not np.array_equal(first_infinite, second_infinite)
                or not np.array_equal(first[first_infinite], second[second_infinite])
            ):
                numeric_match = False
            if finite.any():
                difference = float(np.max(np.abs(first[finite] - second[finite])))
                maximum = max(maximum, difference)
                numeric_match = numeric_match and difference <= tolerance
        else:
            first = left_values.fillna("<NA>").astype(str).to_numpy()
            second = right_values.fillna("<NA>").astype(str).to_numpy()
            labels_match = labels_match and bool(np.array_equal(first, second))
    return {
        "passed": bool(labels_match and numeric_match),
        "reason": "match" if labels_match and numeric_match else "value mismatch",
        "maximum_numeric_difference": maximum,
        "tolerance": tolerance,
    }


def _bootstrap(values: np.ndarray, *, resamples: int, seed: int) -> tuple[float, float, float]:
    values = np.asarray(values, dtype=np.float64)
    values = values[np.isfinite(values)]
    if values.size == 0:
        return np.nan, np.nan, np.nan
    generator = np.random.default_rng(seed)
    statistics = np.empty(resamples, dtype=np.float64)
    for start in range(0, resamples, 1000):
        stop = min(start + 1000, resamples)
        indices = generator.integers(0, values.size, size=(stop - start, values.size))
        statistics[start:stop] = np.median(values[indices], axis=1)
    lower, upper = np.quantile(statistics, [0.025, 0.975])
    return float(np.median(values)), float(lower), float(upper)


def _arm_pair(frame: pd.DataFrame, model: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    subset = frame[frame["model"] == model]
    first = subset[subset["arm"] == "nse"].set_index("basin_id").sort_index()
    second = subset[subset["arm"] == "flow_regime_nse"].set_index("basin_id").sort_index()
    if set(first.index) != set(second.index):
        raise ValueError(f"independent paired basin sets differ for {model}")
    return first, second.loc[first.index]


def recompute_decision(full_metrics: pd.DataFrame, event_metrics: pd.DataFrame, contract: dict) -> tuple[pd.DataFrame, dict]:
    """Independent implementation of the four registered E04 gates."""
    bootstrap = contract["decision_rule"]["bootstrap"]
    resamples = int(bootstrap["resamples"])
    seed = int(bootstrap["seed"])
    rules = contract["decision_rule"]["criteria"]
    rows: list[dict] = []
    changes: dict[str, pd.Series] = {}
    responses: dict[str, float] = {}

    for offset, model in enumerate(MODELS):
        baseline, intervention = _arm_pair(full_metrics, model)
        variability = intervention["variability_ratio"] - baseline["variability_ratio"]
        correlation = intervention["correlation"] - baseline["correlation"]
        changes[model] = variability
        values = variability.abs() - correlation.abs()
        estimate, lower, upper = _bootstrap(values.to_numpy(dtype=float), resamples=resamples, seed=seed + offset)
        threshold = float(rules["variability_over_correlation"]["required_ci_lower_strictly_above"])
        rows.append({
            "criterion": "variability_over_correlation",
            "detail": model,
            "estimate": estimate,
            "ci_lower": lower,
            "ci_upper": upper,
            "threshold": threshold,
            "comparison": "ci_lower > threshold",
            "passed": bool(lower > threshold),
        })
        responses[model] = abs(
            float(intervention["variability_ratio"].median())
            - float(baseline["variability_ratio"].median())
        )

    peak_rule = rules["peak_over_shape"]
    primary = event_metrics[np.isclose(
        event_metrics["event_threshold_quantile"], float(peak_rule["event_threshold_quantile"])
    )]
    for model in MODELS:
        baseline, intervention = _arm_pair(primary, model)
        peak = abs(
            float(intervention["aligned_peak_magnitude_bias"].median())
            - float(baseline["aligned_peak_magnitude_bias"].median())
        )
        shape = abs(
            float(intervention["event_peak_concentration"].median())
            - float(baseline["event_peak_concentration"].median())
        )
        ratio = shape / peak if peak > 0.0 else float("inf")
        threshold = float(peak_rule["maximum_ratio_strictly_below"])
        rows.append({
            "criterion": "peak_over_shape",
            "detail": model,
            "estimate": ratio,
            "ci_lower": np.nan,
            "ci_upper": np.nan,
            "threshold": threshold,
            "comparison": "estimate < threshold",
            "passed": bool(ratio < threshold),
        })

    timing_rule = rules["timing_stability"]
    timing = event_metrics[np.isclose(
        event_metrics["event_threshold_quantile"], float(timing_rule["event_threshold_quantile"])
    )]
    for model in MODELS:
        baseline, intervention = _arm_pair(timing, model)
        estimate = abs(
            float(intervention["absolute_peak_timing_error_days"].median())
            - float(baseline["absolute_peak_timing_error_days"].median())
        )
        threshold = float(timing_rule["maximum_days"])
        rows.append({
            "criterion": "timing_stability",
            "detail": model,
            "estimate": estimate,
            "ci_lower": np.nan,
            "ci_upper": np.nan,
            "threshold": threshold,
            "comparison": "estimate <= threshold",
            "passed": bool(estimate <= threshold),
        })

    dependence = rules["model_dependence"]
    larger = str(dependence["larger_response_model"])
    smaller = str(dependence["smaller_response_model"])
    common = changes[larger].index.intersection(changes[smaller].index)
    values = changes[larger].loc[common].abs() - changes[smaller].loc[common].abs()
    estimate, lower, upper = _bootstrap(values.to_numpy(dtype=float), resamples=resamples, seed=seed + 100)
    threshold = float(dependence["required_ci_lower_strictly_above"])
    rows.append({
        "criterion": "model_dependence",
        "detail": f"{larger}_minus_{smaller}",
        "estimate": estimate,
        "ci_lower": lower,
        "ci_upper": upper,
        "threshold": threshold,
        "comparison": "ci_lower > threshold",
        "passed": bool(lower > threshold),
    })
    smallest = min(responses.values())
    ratio = max(responses.values()) / smallest if smallest > 0.0 else float("inf")
    threshold = float(dependence["minimum_ratio_of_largest_to_smallest_model_response"])
    rows.append({
        "criterion": "model_dependence",
        "detail": "largest_to_smallest_variability_response",
        "estimate": ratio,
        "ci_lower": np.nan,
        "ci_upper": np.nan,
        "threshold": threshold,
        "comparison": "estimate >= threshold",
        "passed": bool(ratio >= threshold),
    })

    criteria = pd.DataFrame(rows)
    gradient = bool(criteria[criteria["criterion"].isin(
        ["variability_over_correlation", "peak_over_shape", "timing_stability"]
    )]["passed"].all())
    model_dependence = bool(criteria[criteria["criterion"] == "model_dependence"]["passed"].all())
    verdict = (
        "CONFIRMED" if gradient and model_dependence
        else "GRADIENT_ONLY" if gradient
        else "MODEL_DEPENDENCE_ONLY" if model_dependence
        else "NOT_CONFIRMED"
    )
    return criteria, {
        "experiment_id": EXPERIMENT_ID,
        "gradient_passed": gradient,
        "model_dependence_passed": model_dependence,
        "verdict": verdict,
        "consequence": contract["decision_rule"]["verdicts"][verdict],
        "model_variability_responses": responses,
    }


def _segments(dates: pd.DatetimeIndex, observations: np.ndarray, minimum_length: int) -> list[np.ndarray]:
    dates = pd.DatetimeIndex(dates)
    observations = np.asarray(observations, dtype=np.float64)
    if dates.size != observations.size:
        raise ValueError("independent event inputs are not aligned")
    if dates.size > 1 and not np.all(np.diff(dates.values.astype("datetime64[D]")).astype(int) == 1):
        raise ValueError("independent confirmation dates are not continuous")
    finite = np.flatnonzero(np.isfinite(observations))
    if not finite.size:
        return []
    groups = np.split(finite, np.flatnonzero(np.diff(finite) != 1) + 1)
    return [group for group in groups if group.size >= minimum_length]


def _event_summary(
    dates: pd.DatetimeIndex,
    observations: np.ndarray,
    simulations: np.ndarray,
    quantile: float,
    definition: dict,
) -> tuple[dict[str, float], int]:
    finite = observations[np.isfinite(observations)]
    threshold = float(np.quantile(finite, quantile))
    half_window = int(definition["half_window_days"])
    frames = []
    for segment_number, indices in enumerate(_segments(dates, observations, 2 * half_window + 1), start=1):
        segment_dates = dates[indices]
        observed = observations[indices]
        simulated = simulations[indices]
        if not np.isfinite(simulated).all():
            raise ValueError("independent simulation contains non-finite event values")
        events = identify_observed_events(
            segment_dates,
            observed,
            threshold=threshold,
            merge_gap_days=int(definition["merge_gap_days"]),
            minimum_peak_separation_days=int(definition["minimum_peak_separation_days"]),
            half_window_days=half_window,
        )
        if events.empty:
            continue
        events = events.copy()
        events["event_id"] = [f"audit_{segment_number:04d}_{event}" for event in events["event_id"]]
        frames.append(compute_event_metrics(segment_dates, observed, simulated, events))
    if not frames:
        return {metric: np.nan for metric in EVENT_METRICS}, 0
    events = pd.concat(frames, ignore_index=True)
    events["event_peak_concentration"] = event_peak_concentration(
        events["aligned_peak_magnitude_bias"].to_numpy(dtype=float),
        events["seven_day_volume_bias"].to_numpy(dtype=float),
    )
    summary = {}
    for metric in EVENT_METRICS:
        values = pd.to_numeric(events[metric], errors="coerce")
        values = values[np.isfinite(values)]
        summary[metric] = float(values.median()) if len(values) else np.nan
    return summary, len(events)


def _amplitude(observations: np.ndarray, simulations: np.ndarray) -> dict:
    mask = np.isfinite(observations) & np.isfinite(simulations)
    observed = observations[mask]
    simulated = simulations[mask]
    if observed.size < 30:
        raise ValueError("independent recomputation has fewer than 30 paired days")
    observed_sd = float(np.std(observed, ddof=1))
    simulated_sd = float(np.std(simulated, ddof=1))
    if observed_sd <= 0.0:
        raise ValueError("independent observed standard deviation is not positive")
    correlation = float(np.corrcoef(observed, simulated)[0, 1]) if simulated_sd > 0.0 else np.nan
    return {
        "variability_ratio": simulated_sd / observed_sd,
        "correlation": correlation,
        "paired_day_count": int(mask.sum()),
    }


def _find_predictions(run_root: Path, arm: str) -> list[Path]:
    paths = []
    for seed in (100, 200, 300):
        matches = sorted((run_root / arm).glob(
            f"E04_daymet_confirmation_{arm}_s{seed}_*_ep30/test/model_epoch030/test_results.p"
        ))
        if len(matches) != 1:
            raise ValueError(f"independent audit expected one prediction for {arm}/seed-{seed}")
        paths.append(matches[0])
    return paths


def _load_series(result_root: Path, run_root: Path, expected_count: int) -> dict:
    series = {}
    for arm in ARMS:
        for model in CONCEPTUAL_MODELS:
            mapping = _load_conceptual_daily(result_root / "conceptual" / arm / model / "daily")
            if len(mapping) != expected_count:
                raise ValueError(f"independent audit found {len(mapping)} basins for {arm}/{model}")
            series[(arm, model)] = mapping
        mapping = load_neural_ensemble(_find_predictions(run_root, arm))
        if len(mapping) != expected_count:
            raise ValueError(f"independent audit found {len(mapping)} neural basins for {arm}")
        series[(arm, NEURAL_MODEL)] = mapping
    return series


def _align(mapping: dict, basin_id: str, dates: pd.DatetimeIndex) -> tuple[np.ndarray, np.ndarray]:
    actual_dates, observed, simulated = mapping[basin_id]
    if not pd.DatetimeIndex(actual_dates).equals(dates):
        raise ValueError(f"independent dates drifted for basin {basin_id}")
    return np.asarray(observed, dtype=np.float64), np.asarray(simulated, dtype=np.float64)


def recompute_metric_tables(series: dict, contract: dict) -> tuple[pd.DataFrame, pd.DataFrame]:
    dates = pd.date_range(contract["periods"]["confirmation_start"], contract["periods"]["confirmation_end"], freq="D")
    basins = set(next(iter(series.values())))
    if any(set(mapping) != basins for mapping in series.values()):
        raise ValueError("independent basin sets differ")
    definition = contract["event_definition"]
    quantiles = tuple(float(value) for value in definition["threshold_quantiles"].values())
    full_rows = []
    event_rows = []
    for basin_id in sorted(basins):
        reference, _ = _align(series[("nse", "gr4j")], basin_id, dates)
        for (arm, model), mapping in series.items():
            observed, simulated = _align(mapping, basin_id, dates)
            if not np.array_equal(np.isfinite(observed), np.isfinite(reference)):
                raise ValueError(f"independent observation masks differ for {basin_id}")
            if not np.allclose(observed, reference, rtol=1e-5, atol=1e-6, equal_nan=True):
                raise ValueError(f"independent observations differ for {basin_id}")
            full_rows.append({
                "basin_id": basin_id,
                "model": model,
                "arm": arm,
                **_amplitude(reference, simulated),
            })
            for quantile in quantiles:
                summary, count = _event_summary(dates, reference, simulated, quantile, definition)
                event_rows.append({
                    "basin_id": basin_id,
                    "model": model,
                    "arm": arm,
                    "event_threshold_quantile": quantile,
                    "event_count": count,
                    **summary,
                })
    return pd.DataFrame(full_rows), pd.DataFrame(event_rows)


def _compare_decisions(expected: dict, actual: dict, tolerance: float) -> dict:
    exact_keys = ("experiment_id", "gradient_passed", "model_dependence_passed", "verdict", "consequence")
    exact = all(expected.get(key) == actual.get(key) for key in exact_keys)
    expected_responses = expected.get("model_variability_responses", {})
    actual_responses = actual.get("model_variability_responses", {})
    if set(expected_responses) != set(actual_responses):
        return {"passed": False, "reason": "response model sets differ", "maximum_numeric_difference": float("inf")}
    differences = [abs(float(expected_responses[key]) - float(actual_responses[key])) for key in expected_responses]
    maximum = max(differences, default=0.0)
    return {
        "passed": bool(exact and maximum <= tolerance),
        "reason": "match" if exact and maximum <= tolerance else "decision mismatch",
        "maximum_numeric_difference": maximum,
        "tolerance": tolerance,
    }


def _build_parser() -> argparse.ArgumentParser:
    contract = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))
    result_root = REPOSITORY_ROOT / contract["registered_result_root"]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--result-root", type=Path, default=result_root)
    parser.add_argument("--neural-run-root", type=Path, default=REPOSITORY_ROOT / contract["neural_training_staging_root"])
    parser.add_argument("--analysis-name", default="analysis_confirmation_20260809")
    return parser


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)
    contract = load_and_validate_contract()
    series = _load_series(args.result_root, args.neural_run_root, int(contract["required_basin_count"]))
    full, events = recompute_metric_tables(series, contract)
    criteria, decision = recompute_decision(full, events, contract)

    analysis = args.result_root / args.analysis_name
    expected_full = pd.read_csv(analysis / "full_series_by_basin.csv", dtype={"basin_id": str})
    expected_events = pd.read_csv(analysis / "event_metrics_by_basin.csv", dtype={"basin_id": str})
    expected_criteria = pd.read_csv(analysis / "criterion_summary.csv")
    expected_decision = json.loads((analysis / "decision.json").read_text(encoding="utf-8"))
    comparisons = {
        "full_series": compare_frames(
            expected_full,
            full,
            key_columns=["model", "arm", "basin_id"],
        ),
        "events": compare_frames(
            expected_events,
            events,
            key_columns=["model", "arm", "event_threshold_quantile", "basin_id"],
        ),
        "criteria": compare_frames(
            expected_criteria,
            criteria,
            key_columns=["criterion", "detail"],
        ),
        "decision": _compare_decisions(expected_decision, decision, TOLERANCE),
    }
    passed = all(item["passed"] for item in comparisons.values())
    payload = {
        "experiment_id": EXPERIMENT_ID,
        "audit_status": "PASS" if passed else "HOLD",
        "tolerance": TOLERANCE,
        "contract_sha256": sha256(CONTRACT_PATH),
        "comparisons": comparisons,
        "recomputed_decision": decision,
        "formal_decision": expected_decision,
        "inference_boundaries": contract["inference_boundaries"],
    }
    _write_new_or_verify(
        args.result_root / "audit/e04_independent_recomputation.json",
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
    )
    print(json.dumps({"audit_status": payload["audit_status"], "verdict": decision["verdict"]}))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
