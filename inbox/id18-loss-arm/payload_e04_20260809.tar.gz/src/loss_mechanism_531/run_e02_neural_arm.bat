@echo off
REM Train the three registered seeds of the E02 reverse tail-emphasis arm.
REM Launched detached so a Claude Code session exit does not take the run with it.
cd /d G:\github\pycharm\projects\neuralhydrology\.worktrees\common-loss-robustness-20260714
set CFG=results\18_lstm_fair_531\E02_reverse_tail_emphasis_531\protocol\generated_configs
for %%S in (100 200 300) do (
    echo === seed %%S start %TIME% ===
    python -X utf8 -m src.loss_mechanism_531.run_neural_loss_experiment train --config-file %CFG%\tail_downweighted_nse_s%%S.yml --gpu 0
    echo === seed %%S exit code %ERRORLEVEL% at %TIME% ===
)
echo === ALL NEURAL DONE %DATE% %TIME% ===
