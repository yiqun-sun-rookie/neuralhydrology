"""Build the post-2008 confirmation cohort from observation availability only.

The paper evaluation period is sealed.  This module therefore reads streamflow files from
the end in binary blocks and keeps only the final 2,192 lines, which cover 2008-12-31 to
2014-12-31 in the CAMELS-US daily files.  It never scans from the beginning of a file.
"""

from __future__ import annotations

import argparse
from datetime import date
import math
from pathlib import Path


CONFIRMATION_START = "2009-01-01"
CONFIRMATION_END = "2014-12-31"
TAIL_LINE_COUNT = 2192
MINIMUM_COMPLETENESS = 0.95
EXPECTED_BASIN_COUNT = 482


def read_tail_lines(path: Path, line_count: int, *, block_size: int = 64 * 1024) -> list[str]:
    """Return at most ``line_count`` final text lines without reading the file prefix."""
    if line_count < 1 or block_size < 1:
        raise ValueError("line_count and block_size must be positive")
    path = Path(path)
    with path.open("rb") as handle:
        handle.seek(0, 2)
        position = handle.tell()
        payload = b""
        while position > 0 and payload.count(b"\n") <= line_count:
            amount = min(block_size, position)
            position -= amount
            handle.seek(position)
            payload = handle.read(amount) + payload
    return [line.decode("utf-8") for line in payload.splitlines()[-line_count:]]


def _iso_date(year: str, month: str, day: str) -> str:
    try:
        return date(int(year), int(month), int(day)).isoformat()
    except (TypeError, ValueError) as error:
        raise ValueError(f"malformed streamflow date: {year!r} {month!r} {day!r}") from error


def confirmation_coverage(
    lines: list[str],
    *,
    start_date: str = CONFIRMATION_START,
    end_date: str = CONFIRMATION_END,
) -> dict[str, int | float | str | None]:
    """Count finite nonnegative observations in the fixed confirmation period."""
    start = date.fromisoformat(start_date)
    end = date.fromisoformat(end_date)
    if end < start:
        raise ValueError("end_date must not precede start_date")

    observations: dict[str, float] = {}
    for raw_line in lines:
        fields = raw_line.strip().split()
        if len(fields) < 5:
            raise ValueError(f"malformed streamflow row: {raw_line!r}")
        current_iso = _iso_date(fields[1], fields[2], fields[3])
        current = date.fromisoformat(current_iso)
        if current < start or current > end:
            continue
        if current_iso in observations:
            raise ValueError(f"duplicate streamflow date: {current_iso}")
        try:
            observations[current_iso] = float(fields[4])
        except ValueError as error:
            raise ValueError(f"malformed streamflow value on {current_iso}: {fields[4]!r}") from error

    expected = (end - start).days + 1
    valid = sum(math.isfinite(value) and value >= 0.0 for value in observations.values())
    dates = sorted(observations)
    return {
        "expected_day_count": expected,
        "row_count": len(observations),
        "valid_observation_count": int(valid),
        "completeness": float(valid / expected),
        "first_date": dates[0] if dates else None,
        "last_date": dates[-1] if dates else None,
    }


def _read_basin_ids(path: Path) -> list[str]:
    basins = [line.strip().zfill(8) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(basins) != len(set(basins)):
        raise ValueError("source basin manifest contains duplicate identifiers")
    return basins


def _file_map(root: Path, pattern: str) -> dict[str, Path]:
    mapping: dict[str, Path] = {}
    for path in root.rglob(pattern):
        basin_id = path.name[:8]
        if basin_id in mapping:
            raise ValueError(f"duplicate data file for basin {basin_id}")
        mapping[basin_id] = path
    return mapping


def build_confirmation_cohort(source_manifest: Path, data_root: Path) -> tuple[list[str], dict[str, dict]]:
    """Select basins using only post-2008 observation completeness and forcing coverage."""
    source_basins = _read_basin_ids(source_manifest)
    streamflow = _file_map(data_root / "usgs_streamflow", "*_streamflow_qc.txt")
    daymet = _file_map(data_root / "basin_mean_forcing" / "daymet", "*_lump_cida_forcing_leap.txt")

    selected: list[str] = []
    audit: dict[str, dict] = {}
    for basin_id in source_basins:
        if basin_id not in streamflow:
            raise FileNotFoundError(f"missing streamflow file for basin {basin_id}")
        if basin_id not in daymet:
            raise FileNotFoundError(f"missing Daymet forcing file for basin {basin_id}")
        forcing_tail = read_tail_lines(daymet[basin_id], 1)
        if not forcing_tail or forcing_tail[0].split()[:3] != ["2014", "12", "31"]:
            raise ValueError(f"Daymet forcing does not end on 2014-12-31 for basin {basin_id}")
        coverage = confirmation_coverage(read_tail_lines(streamflow[basin_id], TAIL_LINE_COUNT))
        coverage["selected"] = bool(coverage["completeness"] >= MINIMUM_COMPLETENESS)
        audit[basin_id] = coverage
        if coverage["selected"]:
            selected.append(basin_id)

    selected.sort()
    if len(selected) != EXPECTED_BASIN_COUNT:
        raise ValueError(
            f"confirmation cohort drifted: selected {len(selected)} basins, expected {EXPECTED_BASIN_COUNT}"
        )
    return selected, audit


def _build_parser() -> argparse.ArgumentParser:
    repository_root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--source-manifest",
        type=Path,
        default=repository_root / "src/xaj_global_pilot/configs/conceptual_benchmark_camels_us_531_repro.txt",
    )
    parser.add_argument("--data-root", type=Path, default=repository_root / "data/camels_us")
    parser.add_argument(
        "--output",
        type=Path,
        default=repository_root / "src/loss_mechanism_531/configs/e04_daymet_confirmation_basins.txt",
    )
    parser.add_argument("--write", action="store_true", help="Write the deterministic manifest; otherwise only check.")
    return parser


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)
    selected, _ = build_confirmation_cohort(args.source_manifest, args.data_root)
    content = "\n".join(selected) + "\n"
    if args.write:
        if args.output.exists():
            if args.output.read_text(encoding="utf-8") != content:
                raise FileExistsError(f"refusing to overwrite a different confirmation manifest: {args.output}")
            print(f"verified {args.output} ({len(selected)} basins)")
        else:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            with args.output.open("x", encoding="utf-8", newline="") as handle:
                handle.write(content)
            print(f"wrote {args.output} ({len(selected)} basins)")
    elif args.output.exists() and args.output.read_text(encoding="utf-8") != content:
        raise ValueError(f"existing confirmation manifest differs from deterministic rebuild: {args.output}")
    else:
        print(f"confirmation cohort verified ({len(selected)} basins)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
