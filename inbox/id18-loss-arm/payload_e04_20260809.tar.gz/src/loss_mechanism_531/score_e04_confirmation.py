"""Score the frozen E04 response gradient and apply its registered decision rule."""

from __future__ import annotations

import argparse
import io
import json
from pathlib import Path

import numpy as np
import pandas as pd

from src.lstm_fair_531.scripts.hydrological_process_diagnostics import (
    EVENT_METRIC_COLUMNS,
    compute_event_metrics,
    identify_observed_events,
)
from src.lstm_fair_531.scripts.posthoc_cause_diagnostics import event_peak_concentration
from src.loss_mechanism_531.prepare_e04_confirmation import (
    CONTRACT_PATH,
    EXPERIMENT_ID,
    REPOSITORY_ROOT,
    _write_new_or_verify,
    load_and_validate_contract,
    sha256,
)
from src.loss_mechanism_531.score_flow_regime_loss_experiment import (
    _load_conceptual_daily,
    load_neural_ensemble,
)


ARMS = ("nse", "flow_regime_nse")
CONCEPTUAL_MODELS = ("gr4j", "hbv_lite", "xaj")
NEURAL_MODEL = "lstm_three_seed_ensemble"
MODELS = (*CONCEPTUAL_MODELS, NEURAL_MODEL)
EVENT_METRICS = (
    "aligned_peak_magnitude_bias",
    "event_peak_concentration",
    "absolute_peak_timing_error_days",
)
MINIMUM_PAIRED_DAYS = 30


def finite_observation_segments(
    dates: pd.DatetimeIndex,
    observations: np.ndarray,
    *,
    minimum_length: int,
) -> list[np.ndarray]:
    """Return contiguous finite-observation indices, never bridging a missing day."""
    dates = pd.DatetimeIndex(dates)
    observed = np.asarray(observations, dtype=np.float64)
    if observed.ndim != 1 or observed.size != dates.size:
        raise ValueError("dates and observations must be aligned one-dimensional arrays")
    if minimum_length < 1:
        raise ValueError("minimum_length must be positive")
    if dates.size > 1:
        steps = np.diff(dates.values.astype("datetime64[D]")).astype(int)
        if not np.all(steps == 1):
            raise ValueError("confirmation dates must form one continuous daily index")

    finite = np.flatnonzero(np.isfinite(observed))
    if finite.size == 0:
        return []
    breaks = np.flatnonzero(np.diff(finite) != 1) + 1
    groups = np.split(finite, breaks)
    return [group for group in groups if group.size >= minimum_length]


def collect_one_series_event_metrics(
    dates: pd.DatetimeIndex,
    observations: np.ndarray,
    simulations: np.ndarray,
    *,
    quantile: float,
    definition: dict,
) -> pd.DataFrame:
    """Score events inside finite segments so no event window touches a missing day."""
    dates = pd.DatetimeIndex(dates)
    observed = np.asarray(observations, dtype=np.float64)
    simulated = np.asarray(simulations, dtype=np.float64)
    if observed.shape != simulated.shape or observed.ndim != 1 or observed.size != dates.size:
        raise ValueError("event inputs must be aligned one-dimensional arrays")
    finite_observed = observed[np.isfinite(observed)]
    if finite_observed.size < MINIMUM_PAIRED_DAYS:
        raise ValueError("too few finite observations for event analysis")
    if not 0.0 < quantile < 1.0:
        raise ValueError("event threshold quantile must lie strictly between zero and one")
    threshold = float(np.quantile(finite_observed, quantile))
    half_window = int(definition["half_window_days"])
    segments = finite_observation_segments(dates, observed, minimum_length=2 * half_window + 1)

    rows: list[pd.DataFrame] = []
    for segment_number, indices in enumerate(segments, start=1):
        segment_dates = dates[indices]
        segment_observed = observed[indices]
        segment_simulated = simulated[indices]
        if not np.isfinite(segment_simulated).all():
            raise ValueError("simulation contains non-finite values within a valid event segment")
        events = identify_observed_events(
            segment_dates,
            segment_observed,
            threshold=threshold,
            merge_gap_days=int(definition["merge_gap_days"]),
            minimum_peak_separation_days=int(definition["minimum_peak_separation_days"]),
            half_window_days=half_window,
        )
        if events.empty:
            continue
        events = events.copy()
        events["event_id"] = [f"segment_{segment_number:04d}_{event_id}" for event_id in events["event_id"]]
        metrics = compute_event_metrics(segment_dates, segment_observed, segment_simulated, events)
        rows.append(metrics)
    if not rows:
        return pd.DataFrame(columns=[*EVENT_METRIC_COLUMNS, "event_peak_concentration"])
    combined = pd.concat(rows, ignore_index=True)
    combined["event_peak_concentration"] = event_peak_concentration(
        combined["aligned_peak_magnitude_bias"].to_numpy(dtype=float),
        combined["seven_day_volume_bias"].to_numpy(dtype=float),
    )
    return combined


def amplitude_geometry(observations: np.ndarray, simulations: np.ndarray) -> dict[str, float | int]:
    observed = np.asarray(observations, dtype=np.float64)
    simulated = np.asarray(simulations, dtype=np.float64)
    if observed.shape != simulated.shape or observed.ndim != 1:
        raise ValueError("full-series inputs must be aligned one-dimensional arrays")
    valid = np.isfinite(observed) & np.isfinite(simulated)
    if int(valid.sum()) < MINIMUM_PAIRED_DAYS:
        raise ValueError("too few paired finite days")
    observed = observed[valid]
    simulated = simulated[valid]
    observed_standard_deviation = float(np.std(observed, ddof=1))
    simulated_standard_deviation = float(np.std(simulated, ddof=1))
    if not np.isfinite(observed_standard_deviation) or observed_standard_deviation <= 0.0:
        raise ValueError("observed standard deviation must be finite and positive")
    correlation = (
        float(np.corrcoef(observed, simulated)[0, 1])
        if simulated_standard_deviation > 0.0
        else float("nan")
    )
    return {
        "variability_ratio": simulated_standard_deviation / observed_standard_deviation,
        "correlation": correlation,
        "paired_day_count": int(valid.sum()),
    }


def _bootstrap_median(values: np.ndarray, *, resamples: int, seed: int) -> tuple[float, float, float]:
    finite = np.asarray(values, dtype=np.float64)
    finite = finite[np.isfinite(finite)]
    if finite.size == 0:
        return np.nan, np.nan, np.nan
    generator = np.random.default_rng(seed)
    statistics = np.empty(resamples, dtype=np.float64)
    for start in range(0, resamples, 1000):
        stop = min(start + 1000, resamples)
        indices = generator.integers(0, finite.size, size=(stop - start, finite.size))
        statistics[start:stop] = np.median(finite[indices], axis=1)
    lower, upper = np.quantile(statistics, [0.025, 0.975])
    return float(np.median(finite)), float(lower), float(upper)


def _paired_by_arm(frame: pd.DataFrame, model: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    selected = frame[frame["model"] == model]
    baseline = selected[selected["arm"] == "nse"].set_index("basin_id").sort_index()
    intervention = selected[selected["arm"] == "flow_regime_nse"].set_index("basin_id").sort_index()
    if set(baseline.index) != set(intervention.index):
        raise ValueError(f"paired E04 basin sets differ for model {model}")
    return baseline, intervention.loc[baseline.index]


def build_decision(full_metrics: pd.DataFrame, event_metrics: pd.DataFrame, contract: dict) -> tuple[pd.DataFrame, dict]:
    """Apply only the four machine-readable criteria in the frozen contract."""
    bootstrap = contract["decision_rule"]["bootstrap"]
    resamples = int(bootstrap["resamples"])
    seed = int(bootstrap["seed"])
    rules = contract["decision_rule"]["criteria"]
    rows: list[dict] = []

    variability_changes: dict[str, pd.Series] = {}
    model_responses: dict[str, float] = {}
    for model_index, model in enumerate(MODELS):
        baseline, intervention = _paired_by_arm(full_metrics, model)
        delta_variability = intervention["variability_ratio"] - baseline["variability_ratio"]
        delta_correlation = intervention["correlation"] - baseline["correlation"]
        variability_changes[model] = delta_variability
        contrast = delta_variability.abs() - delta_correlation.abs()
        estimate, lower, upper = _bootstrap_median(
            contrast.to_numpy(dtype=float),
            resamples=resamples,
            seed=seed + model_index,
        )
        threshold = float(rules["variability_over_correlation"]["required_ci_lower_strictly_above"])
        rows.append({
            "criterion": "variability_over_correlation",
            "detail": model,
            "estimate": estimate,
            "ci_lower": lower,
            "ci_upper": upper,
            "threshold": threshold,
            "comparison": "ci_lower > threshold",
            "passed": bool(lower > threshold),
        })
        model_responses[model] = abs(
            float(intervention["variability_ratio"].median())
            - float(baseline["variability_ratio"].median())
        )

    peak_rule = rules["peak_over_shape"]
    primary_quantile = float(peak_rule["event_threshold_quantile"])
    primary_events = event_metrics[np.isclose(event_metrics["event_threshold_quantile"], primary_quantile)]
    for model in MODELS:
        baseline, intervention = _paired_by_arm(primary_events, model)
        peak_change = abs(
            float(intervention["aligned_peak_magnitude_bias"].median())
            - float(baseline["aligned_peak_magnitude_bias"].median())
        )
        shape_change = abs(
            float(intervention["event_peak_concentration"].median())
            - float(baseline["event_peak_concentration"].median())
        )
        ratio = shape_change / peak_change if peak_change > 0.0 else float("inf")
        threshold = float(peak_rule["maximum_ratio_strictly_below"])
        rows.append({
            "criterion": "peak_over_shape",
            "detail": model,
            "estimate": ratio,
            "ci_lower": np.nan,
            "ci_upper": np.nan,
            "threshold": threshold,
            "comparison": "estimate < threshold",
            "passed": bool(ratio < threshold),
        })

    timing_rule = rules["timing_stability"]
    timing_quantile = float(timing_rule["event_threshold_quantile"])
    timing_events = event_metrics[np.isclose(event_metrics["event_threshold_quantile"], timing_quantile)]
    for model in MODELS:
        baseline, intervention = _paired_by_arm(timing_events, model)
        change = abs(
            float(intervention["absolute_peak_timing_error_days"].median())
            - float(baseline["absolute_peak_timing_error_days"].median())
        )
        threshold = float(timing_rule["maximum_days"])
        rows.append({
            "criterion": "timing_stability",
            "detail": model,
            "estimate": change,
            "ci_lower": np.nan,
            "ci_upper": np.nan,
            "threshold": threshold,
            "comparison": "estimate <= threshold",
            "passed": bool(change <= threshold),
        })

    dependence_rule = rules["model_dependence"]
    larger = str(dependence_rule["larger_response_model"])
    smaller = str(dependence_rule["smaller_response_model"])
    common = variability_changes[larger].index.intersection(variability_changes[smaller].index)
    difference = (
        variability_changes[larger].loc[common].abs()
        - variability_changes[smaller].loc[common].abs()
    )
    estimate, lower, upper = _bootstrap_median(difference.to_numpy(dtype=float), resamples=resamples, seed=seed + 100)
    difference_threshold = float(dependence_rule["required_ci_lower_strictly_above"])
    rows.append({
        "criterion": "model_dependence",
        "detail": f"{larger}_minus_{smaller}",
        "estimate": estimate,
        "ci_lower": lower,
        "ci_upper": upper,
        "threshold": difference_threshold,
        "comparison": "ci_lower > threshold",
        "passed": bool(lower > difference_threshold),
    })
    smallest_response = min(model_responses.values())
    response_ratio = max(model_responses.values()) / smallest_response if smallest_response > 0.0 else float("inf")
    ratio_threshold = float(dependence_rule["minimum_ratio_of_largest_to_smallest_model_response"])
    rows.append({
        "criterion": "model_dependence",
        "detail": "largest_to_smallest_variability_response",
        "estimate": response_ratio,
        "ci_lower": np.nan,
        "ci_upper": np.nan,
        "threshold": ratio_threshold,
        "comparison": "estimate >= threshold",
        "passed": bool(response_ratio >= ratio_threshold),
    })

    criteria = pd.DataFrame(rows)
    gradient_passed = bool(criteria[criteria["criterion"].isin(
        ["variability_over_correlation", "peak_over_shape", "timing_stability"]
    )]["passed"].all())
    model_dependence_passed = bool(criteria[criteria["criterion"] == "model_dependence"]["passed"].all())
    if gradient_passed and model_dependence_passed:
        verdict = "CONFIRMED"
    elif gradient_passed:
        verdict = "GRADIENT_ONLY"
    elif model_dependence_passed:
        verdict = "MODEL_DEPENDENCE_ONLY"
    else:
        verdict = "NOT_CONFIRMED"
    return criteria, {
        "experiment_id": EXPERIMENT_ID,
        "gradient_passed": gradient_passed,
        "model_dependence_passed": model_dependence_passed,
        "verdict": verdict,
        "consequence": contract["decision_rule"]["verdicts"][verdict],
        "model_variability_responses": model_responses,
    }


def _expected_dates(contract: dict) -> pd.DatetimeIndex:
    return pd.date_range(contract["periods"]["confirmation_start"], contract["periods"]["confirmation_end"], freq="D")


def _find_neural_predictions(run_root: Path, arm: str) -> list[Path]:
    paths = []
    for seed in (100, 200, 300):
        matches = sorted((run_root / arm).glob(
            f"E04_daymet_confirmation_{arm}_s{seed}_*_ep30/test/model_epoch030/test_results.p"
        ))
        if len(matches) != 1:
            raise ValueError(f"expected one E04 neural prediction for {arm}/seed-{seed}, got {matches}")
        paths.append(matches[0])
    return paths


def load_all_series(result_root: Path, neural_run_root: Path, contract: dict) -> tuple[dict, list[Path]]:
    expected_count = int(contract["required_basin_count"])
    series: dict[tuple[str, str], dict] = {}
    prediction_paths: list[Path] = []
    for arm in ARMS:
        for model in CONCEPTUAL_MODELS:
            mapping = _load_conceptual_daily(result_root / "conceptual" / arm / model / "daily")
            if len(mapping) != expected_count:
                raise ValueError(f"{arm}/{model} has {len(mapping)} basins, expected {expected_count}")
            series[(arm, model)] = mapping
        paths = _find_neural_predictions(neural_run_root, arm)
        prediction_paths.extend(paths)
        mapping = load_neural_ensemble(paths)
        if len(mapping) != expected_count:
            raise ValueError(f"{arm}/{NEURAL_MODEL} has {len(mapping)} basins, expected {expected_count}")
        series[(arm, NEURAL_MODEL)] = mapping
    return series, prediction_paths


def _aligned(mapping: dict, basin_id: str, expected_dates: pd.DatetimeIndex) -> tuple[np.ndarray, np.ndarray]:
    dates, observations, simulations = mapping[basin_id]
    if not pd.DatetimeIndex(dates).equals(expected_dates):
        raise ValueError(f"E04 dates drifted for basin {basin_id}")
    return np.asarray(observations, dtype=np.float64), np.asarray(simulations, dtype=np.float64)


def collect_metric_tables(series: dict, contract: dict) -> tuple[pd.DataFrame, pd.DataFrame, float]:
    expected_dates = _expected_dates(contract)
    expected_basins = set(next(iter(series.values())))
    if any(set(mapping) != expected_basins for mapping in series.values()):
        raise ValueError("E04 basin sets differ across arms or models")
    definition = contract["event_definition"]
    quantiles = tuple(float(value) for value in definition["threshold_quantiles"].values())
    full_rows: list[dict] = []
    event_rows: list[dict] = []
    largest_observation_gap = 0.0

    for basin_id in sorted(expected_basins):
        reference_observed, _ = _aligned(series[("nse", "gr4j")], basin_id, expected_dates)
        reference_finite = np.isfinite(reference_observed)
        for (arm, model), mapping in series.items():
            observed, simulated = _aligned(mapping, basin_id, expected_dates)
            if not np.array_equal(np.isfinite(observed), reference_finite):
                raise ValueError(f"observation missingness differs across sources for basin {basin_id}")
            if not np.allclose(observed, reference_observed, rtol=1e-5, atol=1e-6, equal_nan=True):
                raise ValueError(f"observations differ across sources for basin {basin_id}")
            finite_difference = np.abs(observed[reference_finite] - reference_observed[reference_finite])
            if finite_difference.size:
                largest_observation_gap = max(largest_observation_gap, float(finite_difference.max()))
            full_rows.append({
                "basin_id": basin_id,
                "model": model,
                "arm": arm,
                **amplitude_geometry(reference_observed, simulated),
            })
            for quantile in quantiles:
                events = collect_one_series_event_metrics(
                    expected_dates,
                    reference_observed,
                    simulated,
                    quantile=quantile,
                    definition=definition,
                )
                row = {
                    "basin_id": basin_id,
                    "model": model,
                    "arm": arm,
                    "event_threshold_quantile": quantile,
                    "event_count": int(len(events)),
                }
                for metric in EVENT_METRICS:
                    values = pd.to_numeric(events[metric], errors="coerce")
                    finite = values[np.isfinite(values)]
                    row[metric] = float(finite.median()) if len(finite) else np.nan
                event_rows.append(row)
    return pd.DataFrame(full_rows), pd.DataFrame(event_rows), largest_observation_gap


def paired_changes(full_metrics: pd.DataFrame, event_metrics: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict] = []
    for model in MODELS:
        baseline, intervention = _paired_by_arm(full_metrics, model)
        for basin_id in baseline.index:
            rows.append({
                "basin_id": basin_id,
                "model": model,
                "event_threshold_quantile": np.nan,
                "metric": "variability_ratio",
                "change": intervention.loc[basin_id, "variability_ratio"] - baseline.loc[basin_id, "variability_ratio"],
            })
            rows.append({
                "basin_id": basin_id,
                "model": model,
                "event_threshold_quantile": np.nan,
                "metric": "correlation",
                "change": intervention.loc[basin_id, "correlation"] - baseline.loc[basin_id, "correlation"],
            })
        for quantile in sorted(event_metrics["event_threshold_quantile"].unique()):
            selected = event_metrics[np.isclose(event_metrics["event_threshold_quantile"], quantile)]
            baseline, intervention = _paired_by_arm(selected, model)
            for basin_id in baseline.index:
                for metric in EVENT_METRICS:
                    rows.append({
                        "basin_id": basin_id,
                        "model": model,
                        "event_threshold_quantile": quantile,
                        "metric": metric,
                        "change": intervention.loc[basin_id, metric] - baseline.loc[basin_id, metric],
                    })
    return pd.DataFrame(rows)


def _csv(frame: pd.DataFrame) -> str:
    buffer = io.StringIO()
    frame.to_csv(buffer, index=False, lineterminator="\n")
    return buffer.getvalue()


def _build_parser() -> argparse.ArgumentParser:
    contract = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))
    result_root = REPOSITORY_ROOT / contract["registered_result_root"]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--result-root", type=Path, default=result_root)
    parser.add_argument("--neural-run-root", type=Path, default=REPOSITORY_ROOT / contract["neural_training_staging_root"])
    parser.add_argument("--output-name", default="analysis_confirmation_20260809")
    return parser


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)
    contract = load_and_validate_contract()
    series, prediction_paths = load_all_series(args.result_root, args.neural_run_root, contract)
    full_metrics, event_metrics, observation_gap = collect_metric_tables(series, contract)
    changes = paired_changes(full_metrics, event_metrics)
    criteria, decision = build_decision(full_metrics, event_metrics, contract)

    output = args.result_root / args.output_name
    artifacts = {
        "full_series_by_basin.csv": _csv(full_metrics.sort_values(["model", "arm", "basin_id"])),
        "event_metrics_by_basin.csv": _csv(event_metrics.sort_values(
            ["model", "arm", "event_threshold_quantile", "basin_id"]
        )),
        "paired_changes.csv": _csv(changes.sort_values(
            ["model", "metric", "event_threshold_quantile", "basin_id"], na_position="first"
        )),
        "criterion_summary.csv": _csv(criteria),
        "decision.json": json.dumps(decision, ensure_ascii=False, indent=2) + "\n",
    }
    for name, content in artifacts.items():
        _write_new_or_verify(output / name, content)
    manifest = {
        "experiment_id": EXPERIMENT_ID,
        "derivation_id": args.output_name,
        "contract_sha256": sha256(CONTRACT_PATH),
        "basin_count": int(full_metrics["basin_id"].nunique()),
        "arms": list(ARMS),
        "models": list(MODELS),
        "largest_cross_source_observation_gap": observation_gap,
        "prediction_files": [
            {"path": str(path.resolve()), "sha256": sha256(path)} for path in prediction_paths
        ],
        "bootstrap": contract["decision_rule"]["bootstrap"],
        "decision": decision,
        "inference_boundaries": contract["inference_boundaries"],
        "outputs": {name: sha256(output / name) for name in artifacts},
    }
    _write_new_or_verify(
        output / "analysis_manifest.json",
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
    )
    print(json.dumps(decision, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
