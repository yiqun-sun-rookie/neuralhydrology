"""Independently recompute the registered loss experiment from persisted predictions."""

from __future__ import annotations

import argparse
import hashlib
import json
import pickle
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from ruamel.yaml import YAML

EXPERIMENT_ID = "E01_flow_regime_balanced_loss_531"
ARMS = ("nse", "flow_regime_nse")
CONCEPTUAL_MODELS = ("gr4j", "xaj", "hbv_lite")
NEURAL_MODEL = "lstm_three_seed_ensemble"
EXPECTED_DATES = pd.date_range("2005-10-01", "2008-09-30", freq="D")
BOOTSTRAP_RESAMPLES = 10_000
BOOTSTRAP_SEED = 20260728


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _variables(dataset) -> tuple[str, str]:
    observed = [name for name in dataset.data_vars if str(name).endswith("_obs")]
    simulated = [name for name in dataset.data_vars if str(name).endswith("_sim")]
    if len(observed) != 1 or len(simulated) != 1:
        raise ValueError(f"unexpected neural variables: {list(dataset.data_vars)}")
    return observed[0], simulated[0]


def _vector(dataset, name: str) -> np.ndarray:
    values = np.asarray(dataset[name].values)
    if values.ndim == 2 and values.shape[1] == 1:
        values = values[:, 0]
    if values.ndim != 1:
        raise ValueError(f"neural variable {name} is not one-dimensional: {values.shape}")
    return values.astype(np.float64)


def _load_neural(paths: list[Path]) -> dict[str, tuple[pd.DatetimeIndex, np.ndarray, np.ndarray]]:
    if len(paths) != 3:
        raise ValueError(f"independent audit expected three neural seeds, got {len(paths)}")
    payloads = [pickle.loads(path.read_bytes()) for path in paths]
    key_maps = [
        {str(key).zfill(8): key for key in payload}
        for payload in payloads
    ]
    basin_set = set(key_maps[0])
    if len(basin_set) != 531 or any(set(mapping) != basin_set for mapping in key_maps[1:]):
        raise ValueError("neural basin populations differ from the frozen 531-basin population")

    output = {}
    for basin_id in sorted(basin_set):
        observations = []
        simulations = []
        dates = []
        for payload, mapping in zip(payloads, key_maps):
            dataset = payload[mapping[basin_id]]["1D"]["xr"]
            observation_name, simulation_name = _variables(dataset)
            observations.append(_vector(dataset, observation_name))
            simulations.append(_vector(dataset, simulation_name))
            dates.append(pd.DatetimeIndex(dataset["date"].values))
        if any(not date_index.equals(EXPECTED_DATES) for date_index in dates):
            raise ValueError(f"neural seed has non-frozen dates for basin {basin_id}")
        if any(not np.allclose(values, observations[0], equal_nan=True) for values in observations[1:]):
            raise ValueError(f"neural observations differ between seeds for basin {basin_id}")
        output[basin_id] = (
            dates[0],
            observations[0],
            np.nanmedian(np.stack(simulations), axis=0),
        )
    return output


def _load_conceptual(directory: Path) -> dict[str, tuple[pd.DatetimeIndex, np.ndarray, np.ndarray]]:
    output = {}
    for path in sorted(directory.glob("*.csv")):
        frame = pd.read_csv(path, dtype={"basin_id": str}, parse_dates=["date"])
        basin_id = str(frame["basin_id"].iloc[0]).zfill(8)
        dates = pd.DatetimeIndex(frame["date"])
        if not dates.equals(EXPECTED_DATES):
            raise ValueError(f"conceptual daily dates differ from frozen holdout: {path}")
        output[basin_id] = (
            dates,
            frame["observation"].to_numpy(dtype=np.float64),
            frame["simulation"].to_numpy(dtype=np.float64),
        )
    if len(output) != 531:
        raise ValueError(f"conceptual daily directory has {len(output)} basins: {directory}")
    return output


def _metrics(observed: np.ndarray, simulated: np.ndarray) -> dict:
    valid = np.isfinite(observed) & np.isfinite(simulated)
    observed = observed[valid]
    simulated = simulated[valid]
    if observed.size < 30:
        raise ValueError("audit found fewer than 30 finite paired holdout values")
    count = observed.size
    tail_count = int(np.floor(0.1 * count))
    ranked = sorted(range(count), key=lambda index: (observed[index], index))
    low = np.asarray(ranked[:tail_count], dtype=int)
    middle = np.asarray(ranked[tail_count:count - tail_count], dtype=int)
    high = np.asarray(ranked[count - tail_count:], dtype=int)
    observed_mean = float(sum(observed) / count)
    high_observed_total = float(sum(observed[index] for index in high))
    squared_deviation = float(sum((value - observed_mean)**2 for value in observed))
    low_bias = float(sum(simulated[index] - observed[index] for index in low) / low.size / observed_mean)
    middle_bias = float(
        sum(simulated[index] - observed[index] for index in middle) / middle.size / observed_mean)
    high_bias = float(sum(simulated[index] - observed[index] for index in high) / high_observed_total)
    nse = float(1.0 - sum((sim - obs)**2 for obs, sim in zip(observed, simulated)) / squared_deviation)
    return {
        "low_flow_signed_bias": low_bias,
        "middle_flow_signed_bias": middle_bias,
        "high_flow_signed_bias": high_bias,
        "nse": nse,
        "valid_day_count": count,
        "low_day_count": low.size,
        "middle_day_count": middle.size,
        "high_day_count": high.size,
    }


def _audit_rows(
    mapping: dict[str, tuple[pd.DatetimeIndex, np.ndarray, np.ndarray]],
    *,
    model: str,
    arm: str,
) -> list[dict]:
    return [
        {
            "model": model,
            "arm": arm,
            "basin_id": basin_id,
            **_metrics(observed, simulated),
        }
        for basin_id, (_, observed, simulated) in sorted(mapping.items())
    ]


def _bootstrap(values: np.ndarray, seed: int) -> tuple[float, float, float]:
    values = np.asarray(values, dtype=np.float64)
    generator = np.random.default_rng(seed)
    bootstrap_medians = np.empty(BOOTSTRAP_RESAMPLES, dtype=np.float64)
    for start in range(0, BOOTSTRAP_RESAMPLES, 1000):
        stop = min(start + 1000, BOOTSTRAP_RESAMPLES)
        indices = generator.integers(0, len(values), size=(stop - start, len(values)))
        bootstrap_medians[start:stop] = np.median(values[indices], axis=1)
    return (
        float(np.median(values)),
        float(np.quantile(bootstrap_medians, 0.025)),
        float(np.quantile(bootstrap_medians, 0.975)),
    )


def _paired(audit_frame: pd.DataFrame) -> tuple[pd.DataFrame, str]:
    rows = []
    model_decisions = []
    for model, group in audit_frame.groupby("model", sort=True):
        baseline = group[group["arm"] == "nse"].set_index("basin_id").sort_index()
        intervention = group[group["arm"] == "flow_regime_nse"].set_index("basin_id").sort_index()
        if not baseline.index.equals(intervention.index):
            raise ValueError(f"audit paired basin identities differ for {model}")
        values_by_metric = {
            "low_absolute_bias_change": (
                intervention["low_flow_signed_bias"].abs() - baseline["low_flow_signed_bias"].abs()
            ).to_numpy(dtype=float),
            "high_absolute_bias_change": (
                intervention["high_flow_signed_bias"].abs() - baseline["high_flow_signed_bias"].abs()
            ).to_numpy(dtype=float),
            "nse_change": (
                intervention["nse"] - baseline["nse"]
            ).to_numpy(dtype=float),
        }
        summaries = {}
        for offset, (metric, values) in enumerate(values_by_metric.items()):
            summaries[metric] = _bootstrap(values, BOOTSTRAP_SEED + offset)
            rows.append({
                "model": model,
                "metric": metric,
                "basin_count": len(values),
                "median_change": summaries[metric][0],
                "ci_lower": summaries[metric][1],
                "ci_upper": summaries[metric][2],
            })
        passed = (
            summaries["low_absolute_bias_change"][2] < 0.0
            and summaries["high_absolute_bias_change"][2] < 0.0
            and summaries["nse_change"][0] >= -0.02
        )
        decision = "GO" if passed else "NO-GO"
        model_decisions.append(decision)
        rows.append({
            "model": model,
            "metric": "decision",
            "basin_count": len(baseline),
            "decision": decision,
        })
    overall = (
        "GO" if all(value == "GO" for value in model_decisions)
        else "PARTIAL" if any(value == "GO" for value in model_decisions)
        else "NO-GO"
    )
    return pd.DataFrame(rows), overall


def _compare_numeric(
    expected: pd.DataFrame,
    actual: pd.DataFrame,
    *,
    keys: list[str],
    columns: list[str],
    tolerance: float = 1e-10,
) -> float:
    merged = expected.merge(actual, on=keys, suffixes=("_expected", "_actual"), validate="one_to_one")
    if len(merged) != len(expected) or len(merged) != len(actual):
        raise ValueError("independent audit row identities differ from registered rows")
    maximum = 0.0
    for column in columns:
        difference = np.abs(
            merged[f"{column}_expected"].to_numpy(dtype=float)
            - merged[f"{column}_actual"].to_numpy(dtype=float)
        )
        maximum = max(maximum, float(np.nanmax(difference)))
    if maximum > tolerance:
        raise ValueError(f"independent audit drift {maximum} exceeds tolerance {tolerance}")
    return maximum


def _audit_run_configs(neural_run_root: Path) -> list[dict]:
    yaml = YAML(typ="safe")
    records = []
    for arm in ARMS:
        expected_loss = "BasinAverageNSE" if arm == "nse" else "BasinAverageFlowRegimeNSE"
        for seed in (100, 200, 300):
            matches = sorted((neural_run_root / arm).glob(f"E01_internal_holdout_{arm}_s{seed}_*_ep30/config.yml"))
            if len(matches) != 1:
                raise ValueError(f"audit expected one neural run configuration for {arm}/seed-{seed}")
            with matches[0].open("r", encoding="utf-8") as handle:
                config = yaml.load(handle)
            checks = {
                "seed": config["seed"] == seed,
                "loss": config["loss"] == expected_loss,
                "train_start": config["train_start_date"] == "30/09/2000",
                "train_end": config["train_end_date"] == "30/09/2005",
                "test_start": config["test_start_date"] == "01/10/2005",
                "test_end": config["test_end_date"] == "30/09/2008",
            }
            if not all(checks.values()):
                raise ValueError(f"neural run configuration failed frozen checks: {matches[0]} {checks}")
            records.append({
                "arm": arm,
                "seed": seed,
                "path": str(matches[0]),
                "sha256": _sha256(matches[0]),
            })
    return records


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--result-root",
        default=f"results/18_lstm_fair_531/{EXPERIMENT_ID}",
    )
    parser.add_argument("--neural-run-root", default="runs/e01_loss")
    return parser


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)
    result_root = Path(args.result_root)
    neural_run_root = Path(args.neural_run_root)
    manifest_path = result_root / "analysis" / "E01_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    for record in manifest["inputs"]:
        path = Path(record["path"])
        if _sha256(path) != record["sha256"]:
            raise ValueError(f"registered scoring input changed: {path}")

    rows = []
    for arm in ARMS:
        for model in CONCEPTUAL_MODELS:
            rows.extend(_audit_rows(
                _load_conceptual(result_root / "conceptual" / arm / model / "daily"),
                model=model,
                arm=arm,
            ))
        neural_paths = sorted(
            (neural_run_root / arm).glob("*/test/model_epoch030/test_results.p"))
        rows.extend(_audit_rows(
            _load_neural(neural_paths),
            model=NEURAL_MODEL,
            arm=arm,
        ))
    independently_recomputed = pd.DataFrame(rows)
    registered = pd.read_csv(
        result_root / "analysis" / "per_basin_regime_metrics.csv",
        dtype={"basin_id": str},
    )
    primary_maximum_drift = _compare_numeric(
        independently_recomputed,
        registered,
        keys=["model", "arm", "basin_id"],
        columns=[
            "low_flow_signed_bias",
            "middle_flow_signed_bias",
            "high_flow_signed_bias",
            "nse",
            "valid_day_count",
            "low_day_count",
            "middle_day_count",
            "high_day_count",
        ],
    )

    independently_paired, independent_decision = _paired(independently_recomputed)
    registered_paired = pd.read_csv(result_root / "analysis" / "paired_loss_effects.csv")
    paired_maximum_drift = _compare_numeric(
        independently_paired[independently_paired["metric"] != "decision"],
        registered_paired[registered_paired["metric"] != "decision"],
        keys=["model", "metric"],
        columns=["basin_count", "median_change", "ci_lower", "ci_upper"],
    )
    registered_decision = json.loads(
        (result_root / "analysis" / "decision.json").read_text(encoding="utf-8"))["decision"]
    if registered_decision != independent_decision:
        raise ValueError(
            f"registered decision {registered_decision} differs from independent decision {independent_decision}")

    run_configs = _audit_run_configs(neural_run_root)
    audit_directory = result_root / "audit"
    audit_directory.mkdir(parents=True, exist_ok=True)
    output_path = audit_directory / "E01_independent_recomputation.json"
    output = {
        "experiment_id": EXPERIMENT_ID,
        "audited_utc": datetime.now(timezone.utc).isoformat(),
        "status": "PASS",
        "independent_decision": independent_decision,
        "basin_count": 531,
        "model_count": 4,
        "arm_count": 2,
        "internal_holdout_start": str(EXPECTED_DATES[0].date()),
        "internal_holdout_end": str(EXPECTED_DATES[-1].date()),
        "forbidden_paper_evaluation_period_read": False,
        "primary_maximum_absolute_drift": primary_maximum_drift,
        "paired_summary_maximum_absolute_drift": paired_maximum_drift,
        "neural_run_configs": run_configs,
        "scoring_manifest_sha256": _sha256(manifest_path),
    }
    output_path.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": output["status"],
        "decision": independent_decision,
        "primary_maximum_absolute_drift": primary_maximum_drift,
        "paired_summary_maximum_absolute_drift": paired_maximum_drift,
        "output": str(output_path),
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
