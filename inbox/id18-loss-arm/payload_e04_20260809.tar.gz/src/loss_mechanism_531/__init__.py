"""Controlled loss-intervention experiment for the 531-basin LSTM comparison."""
