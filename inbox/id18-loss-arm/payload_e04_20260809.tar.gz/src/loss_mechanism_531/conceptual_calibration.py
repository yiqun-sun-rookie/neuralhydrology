"""Shared isolated CMA-ES calibration for the three conceptual models."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import sys
from typing import Callable

import cma
import numpy as np

from .flow_regime_balancing import calibration_loss_value

_REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
if str(_REPOSITORY_ROOT / "src") not in sys.path:
    sys.path.insert(0, str(_REPOSITORY_ROOT / "src"))

WARMUP_DAYS = 365


@dataclass(frozen=True)
class ConceptualModelDefinition:
    name: str
    parameter_names: tuple[str, ...]
    parameter_bounds: dict[str, tuple[float, float]]
    simulate: Callable
    constraint: Callable[[dict[str, float]], None] | None
    state_names: tuple[str, ...]


def resolve_model_definition(model: str, bounds_preset: str = "v1") -> ConceptualModelDefinition:
    """Resolve frozen equations and parameter bounds without modifying them."""
    if model == "gr4j":
        from xaj_global_pilot.gr4j_core import PDD_GR4J_PARAM_NAMES, STATE_NAMES
        from xaj_global_pilot.gr4j_model import resolve_gr4j_bounds, simulate_pdd_gr4j

        return ConceptualModelDefinition(
            name=model,
            parameter_names=tuple(PDD_GR4J_PARAM_NAMES),
            parameter_bounds=resolve_gr4j_bounds(bounds_preset),
            simulate=simulate_pdd_gr4j,
            constraint=None,
            state_names=tuple(STATE_NAMES),
        )
    if model == "xaj":
        from xaj_global_pilot.bounds_presets import resolve_xaj_bounds
        from xaj_global_pilot.xaj_model import (
            PARAM_BOUNDS,
            PDD_PARAM_BOUNDS,
            PDD_XAJ_PARAM_NAMES,
            _enforce_ki_kg,
            simulate_pdd_xaj,
        )

        return ConceptualModelDefinition(
            name=model,
            parameter_names=tuple(PDD_XAJ_PARAM_NAMES),
            parameter_bounds=resolve_xaj_bounds(bounds_preset, PDD_PARAM_BOUNDS, PARAM_BOUNDS),
            simulate=simulate_pdd_xaj,
            constraint=_enforce_ki_kg,
            state_names=("snow", "ice", "last_temp", "W", "WU", "WL", "WD", "S", "QS", "QI", "QG"),
        )
    if model == "hbv_lite":
        from scl_hydro.hbv_lite_numpy import (
            PARAM_NAMES,
            STATE_NAMES,
            resolve_hbv_bounds,
            simulate_hbv_lite,
        )

        return ConceptualModelDefinition(
            name=model,
            parameter_names=tuple(PARAM_NAMES),
            parameter_bounds=resolve_hbv_bounds(bounds_preset),
            simulate=simulate_hbv_lite,
            constraint=None,
            state_names=tuple(STATE_NAMES),
        )
    raise ValueError(f"Unknown conceptual model: {model}")


def _nse(observations: np.ndarray, predictions: np.ndarray) -> float:
    value = calibration_loss_value(observations, predictions, "nse")
    return 1.0 - value if np.isfinite(value) else float("nan")


def calibrate_conceptual_model(
    definition: ConceptualModelDefinition,
    rain: np.ndarray,
    potential_evapotranspiration: np.ndarray,
    temperature: np.ndarray,
    observations: np.ndarray,
    *,
    loss: str,
    n_trials: int,
    n_restarts: int,
    restart_seeds: tuple[int, ...] | None = None,
    init_mean: float = 0.5,
    init_sigma: float = 0.3,
) -> dict:
    """Calibrate one model with either frozen arm of the controlled experiment."""
    if loss not in {"nse", "flow_regime_nse", "tail_downweighted_nse"}:
        raise ValueError(f"Unknown controlled loss arm: {loss}")
    if n_trials < 1 or n_restarts < 1:
        raise ValueError("CMA-ES trials and restarts must both be positive")
    if restart_seeds is None:
        restart_seeds = tuple(42 + 1000 * restart for restart in range(n_restarts))
    if len(restart_seeds) != n_restarts or len(set(restart_seeds)) != n_restarts:
        raise ValueError("restart_seeds must contain one unique seed per restart")

    names = definition.parameter_names
    lower = np.asarray([definition.parameter_bounds[name][0] for name in names], dtype=np.float64)
    upper = np.asarray([definition.parameter_bounds[name][1] for name in names], dtype=np.float64)
    observations = np.asarray(observations, dtype=np.float64)
    warmup = min(WARMUP_DAYS, len(observations) // 4)
    optimization_observations = observations[warmup:]

    def decode(normalized: np.ndarray) -> dict[str, float]:
        values = lower + np.clip(normalized, 0.0, 1.0) * (upper - lower)
        parameters = dict(zip(names, values.tolist()))
        if definition.constraint is not None:
            definition.constraint(parameters)
        return parameters

    def objective(normalized: np.ndarray) -> float:
        try:
            parameters = decode(normalized)
            simulated, _ = definition.simulate(
                rain,
                potential_evapotranspiration,
                temperature,
                parameters,
                initial_state=None,
            )
            value = calibration_loss_value(
                optimization_observations,
                np.asarray(simulated, dtype=np.float64)[warmup:],
                loss,
            )
            return value if np.isfinite(value) else 1.0e12
        except Exception:
            return 1.0e12

    best_normalized = None
    best_loss = float("inf")
    for restart_seed in restart_seeds:
        evolution = cma.CMAEvolutionStrategy(
            [float(init_mean)] * len(names),
            float(init_sigma),
            {
                "bounds": [[0.0] * len(names), [1.0] * len(names)],
                "maxfevals": int(n_trials),
                "seed": int(restart_seed),
                "verbose": -9,
            },
        )
        evolution.optimize(objective)
        if float(evolution.result.fbest) < best_loss:
            best_normalized = np.asarray(evolution.result.xbest, dtype=np.float64).copy()
            best_loss = float(evolution.result.fbest)

    if best_normalized is None or not np.isfinite(best_loss) or best_loss >= 1.0e12:
        raise RuntimeError("CMA-ES did not produce a finite valid candidate")

    best_parameters = decode(best_normalized)
    best_simulation, final_state = definition.simulate(
        rain,
        potential_evapotranspiration,
        temperature,
        best_parameters,
        initial_state=None,
    )
    best_simulation = np.asarray(best_simulation, dtype=np.float64)
    return {
        "loss": float(best_loss),
        "nse": float(_nse(optimization_observations, best_simulation[warmup:])),
        "optimized_params": best_parameters,
        "qsim": best_simulation,
        "final_state": final_state,
        "warmup_days": int(warmup),
    }
