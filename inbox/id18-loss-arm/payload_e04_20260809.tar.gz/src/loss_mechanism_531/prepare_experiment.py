"""Validate and materialize the frozen loss-mechanism experiment protocol."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import psutil
from ruamel.yaml import YAML

EXPERIMENT_ID = "E01_flow_regime_balanced_loss_531"
REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
SOURCE_ROOT = REPOSITORY_ROOT / "src" / "loss_mechanism_531"
RESULT_ROOT = REPOSITORY_ROOT / "results" / "18_lstm_fair_531" / EXPERIMENT_ID
SEEDS = (100, 200, 300)
ARMS = {
    "nse": SOURCE_ROOT / "configs" / "e01_internal_holdout_basin_nse.yml",
    "flow_regime_nse": SOURCE_ROOT / "configs" / "e01_internal_holdout_flow_regime_nse.yml",
}


def _resolve_data_root() -> Path:
    candidates = (
        REPOSITORY_ROOT / "data" / "camels_us",
        REPOSITORY_ROOT.parents[1] / "data" / "camels_us",
    )
    marker = Path("basin_mean_forcing") / "maurer" / "01" / "01022500_lump_maurer_forcing_leap.txt"
    for candidate in candidates:
        if (candidate / marker).is_file():
            return candidate.resolve()
    raise FileNotFoundError(f"Cannot locate the canonical CAMELS-US data root in {candidates}")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _gpu_snapshot() -> dict:
    command = [
        "nvidia-smi",
        "--query-gpu=index,name,memory.total,memory.used,memory.free",
        "--format=csv,noheader,nounits",
    ]
    try:
        completed = subprocess.run(command, capture_output=True, text=True, check=True, timeout=20)
    except (FileNotFoundError, subprocess.SubprocessError) as error:
        return {"available": False, "error": f"{type(error).__name__}: {error}"}
    rows = []
    for line in completed.stdout.splitlines():
        if line.strip():
            index, name, total, used, free = [value.strip() for value in line.split(",", 4)]
            rows.append({
                "index": int(index),
                "name": name,
                "total_mib": int(total),
                "used_mib": int(used),
                "free_mib": int(free),
            })
    return {"available": bool(rows), "gpus": rows}


def _load_yaml(path: Path) -> dict:
    yaml = YAML(typ="safe")
    with path.open("r", encoding="utf-8") as handle:
        return yaml.load(handle)


def _write_yaml(path: Path, data: dict) -> None:
    yaml = YAML()
    yaml.default_flow_style = False
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        yaml.dump(data, handle)


def _materialize_formal_configs(protocol_directory: Path, data_root: Path) -> list[Path]:
    generated = []
    for arm, source_path in ARMS.items():
        source = _load_yaml(source_path)
        for seed in SEEDS:
            config = dict(source)
            config["seed"] = seed
            config["experiment_name"] = f"E01_internal_holdout_{arm}_s{seed}"
            config["data_dir"] = str(data_root)
            path = protocol_directory / "generated_configs" / f"{arm}_s{seed}.yml"
            _write_yaml(path, config)
            generated.append(path)
    return generated


def _materialize_smoke_configs(smoke_directory: Path, data_root: Path) -> tuple[Path, list[Path]]:
    manifest_source = REPOSITORY_ROOT / "src" / "xaj_global_pilot" / "configs" / \
        "conceptual_benchmark_camels_us_531_repro.txt"
    first_basin = next(
        line.strip().zfill(8)
        for line in manifest_source.read_text(encoding="utf-8").splitlines()
        if line.strip()
    )
    smoke_directory.mkdir(parents=True, exist_ok=True)
    manifest_path = smoke_directory / "one_basin.txt"
    manifest_path.write_text(first_basin + "\n", encoding="utf-8")

    generated = []
    for arm, source_path in ARMS.items():
        config = dict(_load_yaml(source_path))
        config.update({
            "experiment_name": f"E01_smoke_{arm}_s100",
            "run_dir": str(REPOSITORY_ROOT / "runs" / "e01_smoke" / arm),
            "data_dir": str(data_root),
            "train_basin_file": str(manifest_path),
            "validation_basin_file": str(manifest_path),
            "test_basin_file": str(manifest_path),
            "epochs": 1,
            "save_weights_every": 1,
            "max_updates_per_epoch": 1,
        })
        path = smoke_directory / "configs" / f"{arm}_s100.yml"
        _write_yaml(path, config)
        generated.append(path)
    return manifest_path, generated


def main() -> int:
    contract_path = SOURCE_ROOT / "configs" / "e01_flow_regime_loss_contract.json"
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    if contract["experiment_id"] != EXPERIMENT_ID:
        raise ValueError("experiment identifier differs from the frozen contract")
    manifest_path = REPOSITORY_ROOT / contract["basin_manifest"]
    basins = [
        line.strip().zfill(8)
        for line in manifest_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if len(basins) != len(set(basins)) or len(basins) != contract["required_basin_count"]:
        raise ValueError("frozen basin manifest does not contain 531 unique identifiers")

    protocol_directory = RESULT_ROOT / "protocol"
    protocol_directory.mkdir(parents=True, exist_ok=True)
    data_root = _resolve_data_root()
    generated_configs = _materialize_formal_configs(protocol_directory, data_root)
    smoke_manifest, smoke_configs = _materialize_smoke_configs(RESULT_ROOT / "smoke", data_root)

    memory = psutil.virtual_memory()
    disk = psutil.disk_usage(str(RESULT_ROOT.parent))
    gpu = _gpu_snapshot()
    system_free_gib = memory.available / 1024**3
    gpu_free_mib = (
        min(row["free_mib"] for row in gpu.get("gpus", []))
        if gpu.get("gpus")
        else None
    )
    resource_gate = {
        "system_free_gib": system_free_gib,
        "system_total_gib": memory.total / 1024**3,
        "disk_free_gib": disk.free / 1024**3,
        "gpu": gpu,
        "minimum_system_free_gib": 8.0,
        "minimum_gpu_free_mib": 2048,
        "passed": bool(
            system_free_gib >= 8.0
            and gpu_free_mib is not None
            and gpu_free_mib >= 2048
        ),
    }
    if not resource_gate["passed"]:
        raise RuntimeError(f"resource gate failed: {resource_gate}")

    tracked_sources = sorted(
        path
        for path in SOURCE_ROOT.rglob("*")
        if path.is_file() and "__pycache__" not in path.parts
    )
    git_head = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=REPOSITORY_ROOT,
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()
    preflight = {
        "experiment_id": EXPERIMENT_ID,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "git_head": git_head,
        "basin_count": len(basins),
        "resolved_data_root": str(data_root),
        "basin_manifest": {
            "path": str(manifest_path.relative_to(REPOSITORY_ROOT)),
            "sha256": _sha256(manifest_path),
        },
        "contract": {
            "path": str(contract_path.relative_to(REPOSITORY_ROOT)),
            "sha256": _sha256(contract_path),
        },
        "source_files": [
            {
                "path": str(path.relative_to(REPOSITORY_ROOT)),
                "sha256": _sha256(path),
            }
            for path in tracked_sources
        ],
        "generated_formal_configs": [
            {"path": str(path.relative_to(REPOSITORY_ROOT)), "sha256": _sha256(path)}
            for path in generated_configs
        ],
        "smoke_manifest": {
            "path": str(smoke_manifest.relative_to(REPOSITORY_ROOT)),
            "sha256": _sha256(smoke_manifest),
        },
        "smoke_configs": [
            {"path": str(path.relative_to(REPOSITORY_ROOT)), "sha256": _sha256(path)}
            for path in smoke_configs
        ],
        "resource_gate": resource_gate,
        "process_id": os.getpid(),
    }
    (protocol_directory / "preflight.json").write_text(
        json.dumps(preflight, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "preflight": str(protocol_directory / "preflight.json"),
        "resource_gate_passed": resource_gate["passed"],
        "system_free_gib": round(system_free_gib, 3),
        "gpu_free_mib": gpu_free_mib,
        "generated_config_count": len(generated_configs),
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
