"""Evaluation-only runtime repair for the isolated flow-regime loss.

The original formal preflight remains immutable.  This module is loaded only
by the post-failure repair entry point and does not change training behavior,
saved checkpoints, or formal scoring.
"""

from __future__ import annotations

import numpy as np
import torch

from neuralhydrology.datasetzoo.basedataset import BaseDataset

from .flow_regime_balancing import flow_regime_sample_weights
from .neural_extension import LOSS_NAME, WEIGHT_FUNCTIONS, install_neural_extension

_EVALUATION_REPAIR_INSTALLED = False


def build_evaluation_sample_weights(
        lookup_table: dict,
        normalized_targets_by_basin: dict[str, dict[str, torch.Tensor]],
        basin_ids: list[str],
        frequency: str,
        weight_function=None,
) -> dict[int, torch.Tensor]:
    """Build period-wide evaluation weights without changing model inputs.

    Missing targets receive zero weight and are removed by the loss mask.  The
    positive weights reproduce the equal-low/middle/high-regime objective when
    all period samples are evaluated together.  These weights affect only the
    diagnostic loss reported by NeuralHydrology; formal scores are recomputed
    from saved predictions by the registered scoring program.
    """
    if weight_function is None:
        weight_function = flow_regime_sample_weights
    if len(set(basin_ids)) != len(basin_ids):
        raise ValueError("evaluation basin identifiers must be unique")

    indexed_values: dict[str, list[tuple[int, float]]] = {basin: [] for basin in basin_ids}
    for item, (basin, indices) in lookup_table.items():
        if basin not in indexed_values:
            raise ValueError(f"evaluation lookup contains unexpected basin {basin}")
        target = normalized_targets_by_basin[basin][frequency][indices[0], 0]
        indexed_values[basin].append((int(item), float(target.item())))

    missing_basins = [basin for basin, values in indexed_values.items() if not values]
    if missing_basins:
        raise ValueError(f"evaluation basins have no lookup samples: {missing_basins}")

    finite_count = sum(
        int(np.count_nonzero(np.isfinite([value for _, value in values])))
        for values in indexed_values.values()
    )
    if finite_count == 0:
        raise ValueError("evaluation lookup has no finite targets")
    multiplier = finite_count / len(basin_ids)

    weights: dict[int, torch.Tensor] = {}
    for values in indexed_values.values():
        observations = np.asarray([value for _, value in values], dtype=np.float64)
        coefficients = weight_function(observations)
        for (item, _), coefficient in zip(values, coefficients):
            weight = multiplier * float(coefficient)
            if not np.isfinite(weight) or weight < 0.0:
                raise ValueError(f"invalid evaluation sample weight {weight} for item {item}")
            weights[item] = torch.tensor([[weight]], dtype=torch.float64)

    if set(weights) != set(lookup_table):
        raise RuntimeError("evaluation sample-weight coverage differs from the lookup table")
    return weights


def install_evaluation_repair() -> None:
    """Install the original extension plus the missing evaluation hooks."""
    global _EVALUATION_REPAIR_INSTALLED
    if _EVALUATION_REPAIR_INSTALLED:
        return

    install_neural_extension()

    import neuralhydrology.evaluation.tester as evaluation_tester
    import neuralhydrology.training as training

    original_load_data = BaseDataset._load_data

    def load_data(self):
        result = original_load_data(self)
        requested_loss = self.cfg.loss.lower()
        if not self.is_train and requested_loss in WEIGHT_FUNCTIONS:
            self._per_sample_flow_regime_nse_weights = build_evaluation_sample_weights(
                lookup_table=self.lookup_table,
                normalized_targets_by_basin=self._y,
                basin_ids=self.basins,
                frequency=self.frequencies[0],
                weight_function=WEIGHT_FUNCTIONS[requested_loss],
            )
        return result

    BaseDataset._load_data = load_data
    evaluation_tester.get_loss_obj = training.get_loss_obj
    _EVALUATION_REPAIR_INSTALLED = True


def evaluation_repair_is_installed() -> bool:
    """Return whether the post-failure evaluation hooks are active."""
    return _EVALUATION_REPAIR_INSTALLED
