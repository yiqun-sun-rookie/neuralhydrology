"""Score the frozen internal-holdout loss intervention without model selection."""

from __future__ import annotations

import argparse
import hashlib
import json
import pickle
from pathlib import Path

import numpy as np
import pandas as pd

from src.lstm_fair_531.scripts.hydrological_process_diagnostics import (
    compute_event_metrics,
    identify_observed_events,
)

EXPERIMENT_ID = "E01_flow_regime_balanced_loss_531"
ARMS = ("nse", "flow_regime_nse")
CONCEPTUAL_MODELS = ("gr4j", "xaj", "hbv_lite")
NEURAL_MODEL = "lstm_three_seed_ensemble"
BOOTSTRAP_RESAMPLES = 10_000
BOOTSTRAP_SEED = 20260728


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def compute_basin_regime_metrics(
    dates,
    observations,
    simulations,
    *,
    tail_fraction: float = 0.1,
) -> dict[str, float]:
    """Compute the three predeclared basin-level holdout metrics."""
    dates = pd.DatetimeIndex(pd.to_datetime(dates))
    observed = np.asarray(observations, dtype=np.float64)
    simulated = np.asarray(simulations, dtype=np.float64)
    if observed.shape != simulated.shape or observed.ndim != 1 or len(dates) != observed.size:
        raise ValueError("dates, observations, and simulations must be aligned one-dimensional arrays")
    valid = np.isfinite(observed) & np.isfinite(simulated)
    if valid.sum() < 30:
        raise ValueError("at least 30 finite paired holdout observations are required")
    observed = observed[valid]
    simulated = simulated[valid]
    dates = dates[valid]
    count = observed.size
    tail_count = int(np.floor(tail_fraction * count))
    if tail_count < 1 or count - 2 * tail_count < 1:
        raise ValueError("flow-regime tails or middle group are empty")
    order = np.lexsort((np.arange(count), observed))
    low = order[:tail_count]
    middle = order[tail_count:count - tail_count]
    high = order[count - tail_count:]

    full_mean = float(np.mean(observed, dtype=np.float64))
    high_total = float(np.sum(observed[high], dtype=np.float64))
    denominator = float(np.sum((observed - full_mean)**2, dtype=np.float64))
    if full_mean == 0.0 or high_total == 0.0 or denominator <= 0.0:
        raise ValueError("holdout observations do not define the registered metrics")

    low_bias = float(np.mean(simulated[low] - observed[low], dtype=np.float64) / full_mean)
    middle_bias = float(np.mean(simulated[middle] - observed[middle], dtype=np.float64) / full_mean)
    high_bias = float(np.sum(simulated[high] - observed[high], dtype=np.float64) / high_total)
    nse = float(1.0 - np.sum((simulated - observed)**2, dtype=np.float64) / denominator)

    event_concentration = float("nan")
    if valid.all() and len(dates) > 1:
        intervals = np.diff(dates.values.astype("datetime64[D]")).astype(int)
        if np.all(intervals == 1):
            threshold = float(np.quantile(observed, 0.9))
            events = identify_observed_events(dates, observed, threshold=threshold)
            if not events.empty:
                event_metrics = compute_event_metrics(dates, observed, simulated, events)
                denominator_shape = 1.0 + event_metrics["seven_day_volume_bias"].to_numpy(dtype=float)
                concentration = (
                    1.0 + event_metrics["aligned_peak_magnitude_bias"].to_numpy(dtype=float)
                ) / denominator_shape
                finite = np.isfinite(concentration) & (denominator_shape > 0.0)
                if finite.any():
                    event_concentration = float(np.median(concentration[finite]))

    return {
        "low_flow_signed_bias": low_bias,
        "middle_flow_signed_bias": middle_bias,
        "high_flow_signed_bias": high_bias,
        "nse": nse,
        "q90_event_peak_concentration": event_concentration,
        "valid_day_count": int(count),
        "low_day_count": int(low.size),
        "middle_day_count": int(middle.size),
        "high_day_count": int(high.size),
    }


def whole_basin_median_interval(
    values,
    *,
    n_resamples: int = BOOTSTRAP_RESAMPLES,
    seed: int = BOOTSTRAP_SEED,
) -> tuple[float, float, float]:
    """Return median and percentile interval from whole-basin resampling."""
    values = np.asarray(values, dtype=np.float64)
    values = values[np.isfinite(values)]
    if values.size < 2:
        raise ValueError("whole-basin bootstrap requires at least two finite basin values")
    generator = np.random.default_rng(seed)
    medians = np.empty(n_resamples, dtype=np.float64)
    for start in range(0, n_resamples, 1000):
        stop = min(start + 1000, n_resamples)
        indices = generator.integers(0, values.size, size=(stop - start, values.size))
        medians[start:stop] = np.median(values[indices], axis=1)
    return (
        float(np.median(values)),
        float(np.quantile(medians, 0.025)),
        float(np.quantile(medians, 0.975)),
    )


def paired_loss_effects(per_basin: pd.DataFrame) -> pd.DataFrame:
    """Compare intervention minus baseline using paired basins."""
    required = {
        "model",
        "arm",
        "basin_id",
        "low_flow_signed_bias",
        "high_flow_signed_bias",
        "nse",
    }
    missing = required.difference(per_basin.columns)
    if missing:
        raise ValueError(f"per-basin score table is missing columns: {sorted(missing)}")
    rows = []
    for model, model_rows in per_basin.groupby("model", sort=True):
        baseline = model_rows[model_rows["arm"] == "nse"].set_index("basin_id")
        intervention = model_rows[model_rows["arm"] == "flow_regime_nse"].set_index("basin_id")
        if set(baseline.index) != set(intervention.index):
            raise ValueError(f"paired basin sets differ for {model}")
        intervention = intervention.loc[baseline.index]
        changes = {
            "low_absolute_bias_change": (
                intervention["low_flow_signed_bias"].abs() - baseline["low_flow_signed_bias"].abs()
            ).to_numpy(dtype=float),
            "high_absolute_bias_change": (
                intervention["high_flow_signed_bias"].abs() - baseline["high_flow_signed_bias"].abs()
            ).to_numpy(dtype=float),
            "nse_change": (
                intervention["nse"] - baseline["nse"]
            ).to_numpy(dtype=float),
        }
        summaries = {}
        for offset, (metric, values) in enumerate(changes.items()):
            estimate, lower, upper = whole_basin_median_interval(values, seed=BOOTSTRAP_SEED + offset)
            summaries[metric] = (estimate, lower, upper)
            rows.append({
                "model": model,
                "metric": metric,
                "basin_count": len(values),
                "median_change": estimate,
                "ci_lower": lower,
                "ci_upper": upper,
            })
        low_pass = summaries["low_absolute_bias_change"][2] < 0.0
        high_pass = summaries["high_absolute_bias_change"][2] < 0.0
        nse_pass = summaries["nse_change"][0] >= -0.02
        rows.append({
            "model": model,
            "metric": "decision",
            "basin_count": len(baseline),
            "median_change": np.nan,
            "ci_lower": np.nan,
            "ci_upper": np.nan,
            "decision": "GO" if low_pass and high_pass and nse_pass else "NO-GO",
            "low_tail_pass": low_pass,
            "high_tail_pass": high_pass,
            "nse_noninferiority_pass": nse_pass,
        })
    return pd.DataFrame(rows)


def _prediction_variables(dataset) -> tuple[str, str]:
    observations = [name for name in dataset.data_vars if str(name).endswith("_obs")]
    simulations = [name for name in dataset.data_vars if str(name).endswith("_sim")]
    if len(observations) != 1 or len(simulations) != 1:
        raise ValueError(f"expected one observed and one simulated variable, got {list(dataset.data_vars)}")
    return observations[0], simulations[0]


def _one_dimensional(dataset, variable: str) -> np.ndarray:
    values = np.asarray(dataset[variable].values)
    if values.ndim == 2 and values.shape[1] == 1:
        values = values[:, 0]
    if values.ndim != 1:
        raise ValueError(f"unexpected shape for {variable}: {values.shape}")
    return values.astype(np.float64)


def load_neural_ensemble(prediction_paths: list[Path]) -> dict[str, tuple[pd.DatetimeIndex, np.ndarray, np.ndarray]]:
    """Load and median-ensemble the three frozen neural initializations."""
    if len(prediction_paths) != 3:
        raise ValueError(f"expected exactly three neural prediction files, got {len(prediction_paths)}")
    payloads = []
    for path in prediction_paths:
        payload = pickle.loads(path.read_bytes())
        if not isinstance(payload, dict):
            raise ValueError(f"neural result is not a basin dictionary: {path}")
        payloads.append(payload)
    basin_sets = [{str(basin).zfill(8) for basin in payload} for payload in payloads]
    if any(basins != basin_sets[0] for basins in basin_sets[1:]):
        raise ValueError("neural seed basin sets differ")

    result = {}
    for basin_id in sorted(basin_sets[0]):
        observations_by_seed = []
        simulations_by_seed = []
        dates_by_seed = []
        for payload in payloads:
            raw_key = next(key for key in payload if str(key).zfill(8) == basin_id)
            dataset = payload[raw_key]["1D"]["xr"]
            observation_variable, simulation_variable = _prediction_variables(dataset)
            observations_by_seed.append(_one_dimensional(dataset, observation_variable))
            simulations_by_seed.append(_one_dimensional(dataset, simulation_variable))
            dates_by_seed.append(pd.DatetimeIndex(dataset["date"].values))
        if any(not dates.equals(dates_by_seed[0]) for dates in dates_by_seed[1:]):
            raise ValueError(f"neural seed dates differ for basin {basin_id}")
        if not all(np.allclose(values, observations_by_seed[0], equal_nan=True)
                   for values in observations_by_seed[1:]):
            raise ValueError(f"neural seed observations differ for basin {basin_id}")
        result[basin_id] = (
            dates_by_seed[0],
            observations_by_seed[0],
            np.nanmedian(np.stack(simulations_by_seed), axis=0),
        )
    return result


def _score_daily_mapping(
    mapping: dict[str, tuple[pd.DatetimeIndex, np.ndarray, np.ndarray]],
    *,
    model: str,
    arm: str,
) -> list[dict]:
    rows = []
    for basin_id, (dates, observations, simulations) in sorted(mapping.items()):
        rows.append({
            "model": model,
            "arm": arm,
            "basin_id": basin_id,
            **compute_basin_regime_metrics(dates, observations, simulations),
        })
    return rows


def _load_conceptual_daily(directory: Path) -> dict[str, tuple[pd.DatetimeIndex, np.ndarray, np.ndarray]]:
    mapping = {}
    for path in sorted(directory.glob("*.csv")):
        frame = pd.read_csv(path, dtype={"basin_id": str}, parse_dates=["date"])
        basin_id = str(frame["basin_id"].iloc[0]).zfill(8)
        mapping[basin_id] = (
            pd.DatetimeIndex(frame["date"]),
            frame["observation"].to_numpy(dtype=np.float64),
            frame["simulation"].to_numpy(dtype=np.float64),
        )
    return mapping


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--result-root",
        default=f"results/18_lstm_fair_531/{EXPERIMENT_ID}",
    )
    parser.add_argument("--expected-basins", type=int, default=531)
    parser.add_argument("--neural-run-root", default="runs/e01_loss")
    return parser


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)
    result_root = Path(args.result_root)
    analysis_directory = result_root / "analysis"
    analysis_directory.mkdir(parents=True, exist_ok=True)
    input_paths: list[Path] = []
    rows: list[dict] = []

    for arm in ARMS:
        for model in CONCEPTUAL_MODELS:
            directory = result_root / "conceptual" / arm / model / "daily"
            mapping = _load_conceptual_daily(directory)
            if len(mapping) != args.expected_basins:
                raise ValueError(f"{arm}/{model} has {len(mapping)} basins, expected {args.expected_basins}")
            rows.extend(_score_daily_mapping(mapping, model=model, arm=arm))
            input_paths.extend(sorted(directory.glob("*.csv")))

        prediction_paths = sorted(
            (Path(args.neural_run_root) / arm).glob("*/test/model_epoch030/test_results.p"))
        mapping = load_neural_ensemble(prediction_paths)
        if len(mapping) != args.expected_basins:
            raise ValueError(f"{arm}/{NEURAL_MODEL} has {len(mapping)} basins, expected {args.expected_basins}")
        rows.extend(_score_daily_mapping(mapping, model=NEURAL_MODEL, arm=arm))
        input_paths.extend(prediction_paths)

    per_basin = pd.DataFrame(rows)
    per_basin_path = analysis_directory / "per_basin_regime_metrics.csv"
    per_basin.to_csv(per_basin_path, index=False)

    summary = per_basin.groupby(["model", "arm"], as_index=False).agg({
        "low_flow_signed_bias": "median",
        "middle_flow_signed_bias": "median",
        "high_flow_signed_bias": "median",
        "nse": "median",
        "q90_event_peak_concentration": "median",
    })
    summary_path = analysis_directory / "model_arm_summary.csv"
    summary.to_csv(summary_path, index=False)

    paired = paired_loss_effects(per_basin)
    paired_path = analysis_directory / "paired_loss_effects.csv"
    paired.to_csv(paired_path, index=False)
    decisions = paired[paired["metric"] == "decision"]["decision"].tolist()
    overall_decision = (
        "GO" if decisions and all(value == "GO" for value in decisions)
        else "PARTIAL" if any(value == "GO" for value in decisions)
        else "NO-GO"
    )
    decision_path = analysis_directory / "decision.json"
    decision_path.write_text(
        json.dumps({
            "experiment_id": EXPERIMENT_ID,
            "decision": overall_decision,
            "model_decisions": paired[paired["metric"] == "decision"][
                ["model", "decision", "low_tail_pass", "high_tail_pass", "nse_noninferiority_pass"]
            ].to_dict(orient="records"),
        }, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    output_paths = [per_basin_path, summary_path, paired_path, decision_path]
    manifest = {
        "experiment_id": EXPERIMENT_ID,
        "input_count": len(input_paths),
        "inputs": [{"path": str(path), "sha256": _sha256(path)} for path in input_paths],
        "outputs": [{"path": str(path), "sha256": _sha256(path)} for path in output_paths],
        "bootstrap_resamples": BOOTSTRAP_RESAMPLES,
        "bootstrap_seed": BOOTSTRAP_SEED,
    }
    (analysis_directory / "E01_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
