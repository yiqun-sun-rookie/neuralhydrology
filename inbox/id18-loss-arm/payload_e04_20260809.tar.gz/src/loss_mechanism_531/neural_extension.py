"""Runtime-only NeuralHydrology extension for the isolated loss experiment.

The R02 implementation files are provenance-locked.  This module therefore
installs the new loss in memory for one process without changing the core
package or the frozen R02 source hashes.
"""

from __future__ import annotations

from neuralhydrology.datasetzoo.basedataset import BaseDataset

from .flow_regime_balancing import (
    REVERSE_TAIL_MULTIPLIER,
    BasinAverageFlowRegimeNSELoss,
    build_lookup_sample_weights,
    flow_regime_sample_weights,
    tail_emphasis_sample_weights,
)

LOSS_NAME = "BasinAverageFlowRegimeNSE"
REVERSE_LOSS_NAME = "BasinAverageTailDownweightedNSE"


def _reverse_sample_weights(observations):
    return tail_emphasis_sample_weights(observations, tail_multiplier=REVERSE_TAIL_MULTIPLIER)


WEIGHT_FUNCTIONS = {
    LOSS_NAME.lower(): flow_regime_sample_weights,
    REVERSE_LOSS_NAME.lower(): _reverse_sample_weights,
}
_INSTALLED = False


def install_neural_extension() -> None:
    """Install the isolated dataset and loss hooks exactly once."""
    global _INSTALLED
    if _INSTALLED:
        return

    import neuralhydrology.training as training
    import neuralhydrology.training.basetrainer as basetrainer

    original_load_data = BaseDataset._load_data
    original_calculate_weights = BaseDataset._calculate_per_basin_nse_weights
    original_getitem = BaseDataset.__getitem__
    original_get_loss_obj = training.get_loss_obj

    def calculate_weights(self, raw_targets_by_basin, target_scale):
        original_calculate_weights(self, raw_targets_by_basin, target_scale)
        active = getattr(self, "_flow_regime_loss_active", None)
        if active:
            self._per_sample_flow_regime_nse_weights = build_lookup_sample_weights(
                lookup_table=self.lookup_table,
                raw_targets_by_basin=raw_targets_by_basin,
                basin_ids=self.basins,
                frequency=self.frequencies[0],
                target_scale=target_scale,
                weight_function=WEIGHT_FUNCTIONS[active],
            )

    def load_data(self):
        if not (self.is_train and self.cfg.loss.lower() in WEIGHT_FUNCTIONS):
            return original_load_data(self)

        self._flow_regime_loss_active = self.cfg.loss.lower()
        requested_loss = self.cfg.loss
        self.cfg.loss = "BasinAverageNSE"
        try:
            result = original_load_data(self)
        finally:
            self.cfg.loss = requested_loss
            self._flow_regime_loss_active = None

        expected_items = set(self.lookup_table)
        actual_items = set(self._per_sample_flow_regime_nse_weights)
        if actual_items != expected_items:
            raise RuntimeError(
                "Flow-regime sample-weight coverage differs from the training lookup table: "
                f"missing={len(expected_items - actual_items)}, extra={len(actual_items - expected_items)}")
        self._per_basin_target_nse_weights = {}
        return result

    def getitem(self, item):
        sample = original_getitem(self, item)
        weights = getattr(self, "_per_sample_flow_regime_nse_weights", None)
        if weights is not None:
            sample["per_sample_flow_regime_nse_weight"] = weights[item]
        return sample

    def get_loss_obj(cfg):
        if cfg.loss.lower() in WEIGHT_FUNCTIONS:
            return BasinAverageFlowRegimeNSELoss(cfg)
        return original_get_loss_obj(cfg)

    BaseDataset._calculate_per_basin_nse_weights = calculate_weights
    BaseDataset._load_data = load_data
    BaseDataset.__getitem__ = getitem
    training.get_loss_obj = get_loss_obj
    basetrainer.get_loss_obj = get_loss_obj
    _INSTALLED = True


def extension_is_installed() -> bool:
    """Return whether the runtime hooks have been installed in this process."""
    return _INSTALLED
