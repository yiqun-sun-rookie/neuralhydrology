"""Run NeuralHydrology with the post-failure evaluation repair installed."""

from neuralhydrology import nh_run

from .evaluation_repair import install_evaluation_repair


def main() -> None:
    install_evaluation_repair()
    nh_run._main()


if __name__ == "__main__":
    main()
