"""Run all frozen formal arms serially with resource and resume gates."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import psutil
from ruamel.yaml import YAML

EXPERIMENT_ID = "E01_flow_regime_balanced_loss_531"
REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
SOURCE_ROOT = REPOSITORY_ROOT / "src" / "loss_mechanism_531"
RESULT_ROOT = REPOSITORY_ROOT / "results" / "18_lstm_fair_531" / EXPERIMENT_ID
LOG_ROOT = REPOSITORY_ROOT / "logs" / "18_lstm_fair_531" / EXPERIMENT_ID
PROTOCOL_ROOT = RESULT_ROOT / "protocol"
STATE_PATH = PROTOCOL_ROOT / "formal_execution_state.json"
LOCK_PATH = PROTOCOL_ROOT / "formal_execution.lock.json"
CONCEPTUAL_JOBS = (
    ("gr4j", "nse", 4),
    ("gr4j", "flow_regime_nse", 4),
    ("xaj", "nse", 4),
    ("xaj", "flow_regime_nse", 4),
    ("hbv_lite", "nse", 2),
    ("hbv_lite", "flow_regime_nse", 2),
)
NEURAL_JOBS = tuple(
    (arm, seed)
    for seed in (100, 200, 300)
    for arm in ("nse", "flow_regime_nse")
)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def _load_state() -> dict:
    if STATE_PATH.exists():
        return _load_json(STATE_PATH)
    return {
        "experiment_id": EXPERIMENT_ID,
        "status": "running",
        "started_utc": _utc_now(),
        "updated_utc": _utc_now(),
        "process_id": os.getpid(),
        "jobs": [],
    }


def _save_state(state: dict) -> None:
    state["updated_utc"] = _utc_now()
    state["process_id"] = os.getpid()
    _write_json(STATE_PATH, state)


def _acquire_lock() -> None:
    if LOCK_PATH.exists():
        existing = _load_json(LOCK_PATH)
        process_id = int(existing.get("process_id", -1))
        if process_id > 0 and psutil.pid_exists(process_id):
            raise RuntimeError(f"formal experiment is already running in process {process_id}")
    _write_json(LOCK_PATH, {"process_id": os.getpid(), "created_utc": _utc_now()})


def _resource_snapshot() -> dict:
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage(str(RESULT_ROOT.parent))
    command = [
        "nvidia-smi",
        "--query-gpu=memory.free",
        "--format=csv,noheader,nounits",
    ]
    completed = subprocess.run(command, capture_output=True, text=True, timeout=20, check=True)
    gpu_free_mib = min(int(line.strip()) for line in completed.stdout.splitlines() if line.strip())
    snapshot = {
        "utc": _utc_now(),
        "system_free_gib": memory.available / 1024**3,
        "gpu_free_mib": gpu_free_mib,
        "disk_free_gib": disk.free / 1024**3,
    }
    snapshot["passed"] = (
        snapshot["system_free_gib"] >= 8.0
        and snapshot["gpu_free_mib"] >= 2048
        and snapshot["disk_free_gib"] >= 50.0
    )
    return snapshot


def _verify_preflight() -> dict:
    preflight_path = PROTOCOL_ROOT / "preflight.json"
    preflight = _load_json(preflight_path)
    if preflight["experiment_id"] != EXPERIMENT_ID or preflight["basin_count"] != 531:
        raise RuntimeError("preflight identity or basin population changed")
    for record in preflight["source_files"]:
        path = REPOSITORY_ROOT / record["path"]
        if _sha256(path) != record["sha256"]:
            raise RuntimeError(f"source changed after preflight: {path}")
    for record in preflight["generated_formal_configs"]:
        path = REPOSITORY_ROOT / record["path"]
        if _sha256(path) != record["sha256"]:
            raise RuntimeError(f"generated configuration changed after preflight: {path}")
    return preflight


def _run_logged(command: list[str], log_path: Path) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8") as log:
        log.write(f"\n[{_utc_now()}] COMMAND {subprocess.list2cmdline(command)}\n")
        log.flush()
        completed = subprocess.run(
            command,
            cwd=REPOSITORY_ROOT,
            stdout=log,
            stderr=subprocess.STDOUT,
            text=True,
        )
    if completed.returncode != 0:
        raise RuntimeError(f"command failed with exit code {completed.returncode}: {command}")


def _record_job(state: dict, *, kind: str, label: str, status: str, **extra) -> None:
    records = [
        record
        for record in state["jobs"]
        if not (record.get("kind") == kind and record.get("label") == label)
    ]
    records.append({
        "kind": kind,
        "label": label,
        "status": status,
        "updated_utc": _utc_now(),
        **extra,
    })
    state["jobs"] = records
    _save_state(state)


def _conceptual_complete(model: str, arm: str) -> bool:
    directory = RESULT_ROOT / "conceptual" / arm / model
    metadata_path = directory / "run_metadata.json"
    if not metadata_path.exists():
        return False
    metadata = _load_json(metadata_path)
    return (
        metadata.get("basin_count_requested") == 531
        and metadata.get("basin_count_success") == 531
        and len(list((directory / "daily").glob("*.csv"))) == 531
        and metadata.get("non_scientific_smoke") is False
    )


def _run_conceptual_jobs(state: dict, data_root: str) -> None:
    manifest = SOURCE_ROOT.parent / "xaj_global_pilot" / "configs" / \
        "conceptual_benchmark_camels_us_531_repro.txt"
    for model, arm, workers in CONCEPTUAL_JOBS:
        label = f"{model}/{arm}"
        if _conceptual_complete(model, arm):
            _record_job(state, kind="conceptual", label=label, status="completed", resumed=True)
            continue
        resources = _resource_snapshot()
        if not resources["passed"]:
            raise RuntimeError(f"resource gate failed before {label}: {resources}")
        _record_job(
            state,
            kind="conceptual",
            label=label,
            status="running",
            resources_before=resources,
            workers=workers,
        )
        command = [
            sys.executable,
            "-X",
            "utf8",
            "-m",
            "src.loss_mechanism_531.run_conceptual_loss_experiment",
            "--model",
            model,
            "--loss",
            arm,
            "--manifest",
            str(manifest),
            "--data-root",
            data_root,
            "--output-root",
            str(RESULT_ROOT / "conceptual"),
            "--workers",
            str(workers),
            "--trials",
            "5000",
            "--restarts",
            "3",
            "--bounds-preset",
            "v1",
        ]
        _run_logged(command, LOG_ROOT / "conceptual" / f"{model}_{arm}.log")
        if not _conceptual_complete(model, arm):
            raise RuntimeError(f"conceptual output failed completeness check: {label}")
        _record_job(state, kind="conceptual", label=label, status="completed", workers=workers)


def _read_yaml(path: Path) -> dict:
    yaml = YAML(typ="safe")
    with path.open("r", encoding="utf-8") as handle:
        return yaml.load(handle)


def _find_neural_run(arm: str, seed: int) -> Path | None:
    run_root = REPOSITORY_ROOT / "runs" / "e01_loss" / arm
    candidates = sorted(run_root.glob(f"E01_internal_holdout_{arm}_s{seed}_*_ep30"))
    complete = [path for path in candidates if (path / "model_epoch030.pt").exists()]
    if len(complete) > 1:
        raise RuntimeError(f"multiple complete formal neural runs found for {arm}/seed-{seed}")
    return complete[0] if complete else None


def _run_neural_jobs(state: dict) -> None:
    config_root = PROTOCOL_ROOT / "generated_configs"
    for arm, seed in NEURAL_JOBS:
        label = f"{arm}/seed-{seed}"
        run_directory = _find_neural_run(arm, seed)
        prediction_path = (
            run_directory / "test" / "model_epoch030" / "test_results.p"
            if run_directory is not None
            else None
        )
        if prediction_path is not None and prediction_path.exists():
            _record_job(
                state,
                kind="neural",
                label=label,
                status="completed",
                run_directory=str(run_directory),
                resumed=True,
            )
            continue

        resources = _resource_snapshot()
        if not resources["passed"]:
            raise RuntimeError(f"resource gate failed before {label}: {resources}")
        _record_job(
            state,
            kind="neural",
            label=label,
            status="running",
            resources_before=resources,
        )
        log_path = LOG_ROOT / "neural" / f"{arm}_s{seed}.log"
        if run_directory is None:
            config_path = config_root / f"{arm}_s{seed}.yml"
            config = _read_yaml(config_path)
            if config["seed"] != seed or config["loss"] not in {
                "BasinAverageNSE",
                "BasinAverageFlowRegimeNSE",
            }:
                raise RuntimeError(f"generated neural configuration differs from contract: {config_path}")
            _run_logged([
                sys.executable,
                "-X",
                "utf8",
                "-m",
                "src.loss_mechanism_531.run_neural_loss_experiment",
                "train",
                "--config-file",
                str(config_path),
                "--gpu",
                "0",
            ], log_path)
            run_directory = _find_neural_run(arm, seed)
            if run_directory is None:
                raise RuntimeError(f"training completed without epoch-30 checkpoint: {label}")

        _run_logged([
            sys.executable,
            "-X",
            "utf8",
            "-m",
            "src.loss_mechanism_531.run_neural_loss_experiment",
            "evaluate",
            "--run-dir",
            str(run_directory),
            "--period",
            "test",
            "--epoch",
            "30",
            "--gpu",
            "0",
        ], log_path)
        prediction_path = run_directory / "test" / "model_epoch030" / "test_results.p"
        if not prediction_path.exists():
            raise RuntimeError(f"evaluation completed without daily prediction artifact: {label}")
        _record_job(
            state,
            kind="neural",
            label=label,
            status="completed",
            run_directory=str(run_directory),
        )


def main() -> int:
    _acquire_lock()
    state = _load_state()
    state["status"] = "running"
    _save_state(state)
    try:
        preflight = _verify_preflight()
        data_root = preflight["resolved_data_root"]
        _run_conceptual_jobs(state, data_root)
        _run_neural_jobs(state)
        _run_logged([
            sys.executable,
            "-X",
            "utf8",
            "-m",
            "src.loss_mechanism_531.score_flow_regime_loss_experiment",
            "--result-root",
            str(RESULT_ROOT),
            "--neural-run-root",
            str(REPOSITORY_ROOT / "runs" / "e01_loss"),
        ], LOG_ROOT / "scoring.log")
        state["status"] = "scored_pending_independent_audit"
        state["completed_utc"] = _utc_now()
        _save_state(state)
        return 0
    except Exception as error:
        state["status"] = "failed"
        state["error"] = f"{type(error).__name__}: {error}"
        _save_state(state)
        raise
    finally:
        _write_json(LOCK_PATH, {
            "process_id": os.getpid(),
            "released_utc": _utc_now(),
            "status": state["status"],
        })


if __name__ == "__main__":
    raise SystemExit(main())
