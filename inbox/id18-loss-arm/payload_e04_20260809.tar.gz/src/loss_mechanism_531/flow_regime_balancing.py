"""Exact flow-regime-balanced objectives without modifying frozen R02 source files."""

from __future__ import annotations

from typing import Dict

import numpy as np
import torch

from neuralhydrology.training.loss import BaseLoss
from neuralhydrology.utils.config import Config


class FlowRegimeObjectiveError(ValueError):
    """Raised when the flow-regime-balanced objective is not defined."""


REVERSE_TAIL_MULTIPLIER = 0.3
"""Tail emphasis of the reverse arm, chosen to mirror the registered equal-regime arm.

The equal-regime arm raises each ten-percent tail to one third of the total weight, about
3.34 times its realized share. The reverse arm uses the reciprocal, 0.3, so the two arms sit
at equal distance either side of plain one-minus-NSE on a multiplicative scale.
"""


def _validated_observations(observations: np.ndarray, tail_fraction: float) -> tuple[np.ndarray, np.ndarray]:
    values = np.asarray(observations, dtype=np.float64)
    if values.ndim != 1:
        raise FlowRegimeObjectiveError(f"observations must be one-dimensional, got shape {values.shape}")
    if not np.isfinite(tail_fraction) or not 0.0 < tail_fraction < 0.5:
        raise FlowRegimeObjectiveError(f"tail_fraction must be finite and between zero and one half, got {tail_fraction}")
    finite_indices = np.flatnonzero(np.isfinite(values))
    if finite_indices.size < 30:
        raise FlowRegimeObjectiveError(
            f"flow-regime balancing requires at least 30 finite observations, got {finite_indices.size}")
    finite_values = values[finite_indices]
    denominator = float(np.sum((finite_values - np.mean(finite_values, dtype=np.float64))**2, dtype=np.float64))
    if not np.isfinite(denominator) or denominator <= 0.0:
        raise FlowRegimeObjectiveError(
            f"flow-regime balancing requires positive variance, got denominator {denominator}")
    return finite_indices, finite_values


def flow_regime_sample_weights(observations: np.ndarray, tail_fraction: float = 0.1) -> np.ndarray:
    """Return exact coefficients for equally weighted low, middle, and high regimes."""
    values = np.asarray(observations, dtype=np.float64)
    finite_indices, finite_values = _validated_observations(values, tail_fraction)
    finite_count = finite_indices.size
    tail_count = int(np.floor(tail_fraction * finite_count))
    middle_count = finite_count - 2 * tail_count
    if tail_count < 1 or middle_count < 1:
        raise FlowRegimeObjectiveError(
            f"tail_fraction {tail_fraction} creates an empty regime for {finite_count} observations")

    denominator = float(np.sum(
        (finite_values - np.mean(finite_values, dtype=np.float64))**2,
        dtype=np.float64,
    ))
    local_order = np.lexsort((finite_indices, finite_values))
    regimes = (
        local_order[:tail_count],
        local_order[tail_count:finite_count - tail_count],
        local_order[finite_count - tail_count:],
    )
    weights = np.zeros(values.shape, dtype=np.float64)
    for local_indices in regimes:
        weights[finite_indices[local_indices]] = finite_count / (
            3.0 * local_indices.size * denominator)
    return weights


def tail_emphasis_sample_weights(observations: np.ndarray,
                                 tail_multiplier: float,
                                 tail_fraction: float = 0.1) -> np.ndarray:
    """Return sample weights on the single tail-emphasis axis shared by every registered arm.

    A multiplier of one leaves each regime at its realized share of observations, which
    reproduces plain one-minus-NSE exactly. Multipliers above one emphasise both tails; the
    registered equal-regime arm sits near ``1 / (3 * tail_fraction)``, differing only because
    that arm fixes each regime at exactly one third rather than at a multiple of the realized
    tail share. Multipliers below one de-emphasise both tails and concentrate the objective on
    middle flow.

    The realized rather than nominal tail fraction is used because the tail boundary is taken
    by flooring, so a nominal one-tenth tail holds 53 of 531 observations, not 53.1.
    """
    values = np.asarray(observations, dtype=np.float64)
    if not np.isfinite(tail_multiplier) or tail_multiplier <= 0.0:
        raise FlowRegimeObjectiveError(f"tail_multiplier must be finite and positive, got {tail_multiplier}")
    finite_indices, finite_values = _validated_observations(values, tail_fraction)
    finite_count = finite_indices.size
    tail_count = int(np.floor(tail_fraction * finite_count))
    middle_count = finite_count - 2 * tail_count
    if tail_count < 1 or middle_count < 1:
        raise FlowRegimeObjectiveError(
            f"tail_fraction {tail_fraction} creates an empty regime for {finite_count} observations")

    realized_tail_fraction = tail_count / finite_count
    tail_share = realized_tail_fraction * tail_multiplier
    middle_share = 1.0 - 2.0 * tail_share
    if middle_share <= 0.0:
        raise FlowRegimeObjectiveError(
            f"tail_multiplier {tail_multiplier} leaves no weight for middle flow at tail_fraction {tail_fraction}")

    denominator = float(np.sum(
        (finite_values - np.mean(finite_values, dtype=np.float64))**2,
        dtype=np.float64,
    ))
    local_order = np.lexsort((finite_indices, finite_values))
    regimes = (
        local_order[:tail_count],
        local_order[tail_count:finite_count - tail_count],
        local_order[finite_count - tail_count:],
    )
    shares = (tail_share, middle_share, tail_share)
    weights = np.zeros(values.shape, dtype=np.float64)
    for share, local_indices in zip(shares, regimes):
        weights[finite_indices[local_indices]] = share * finite_count / (
            local_indices.size * denominator)
    return weights


def tail_emphasis_one_minus_nse(observations: np.ndarray,
                                predictions: np.ndarray,
                                tail_multiplier: float,
                                tail_fraction: float = 0.1) -> float:
    """Calculate the tail-emphasis squared-error objective for one basin."""
    observed = np.asarray(observations, dtype=np.float64)
    simulated = np.asarray(predictions, dtype=np.float64)
    if simulated.shape != observed.shape:
        raise FlowRegimeObjectiveError(
            f"simulation shape {simulated.shape} does not match observation shape {observed.shape}")
    valid_observations = np.isfinite(observed)
    if not np.all(np.isfinite(simulated[valid_observations])):
        raise FlowRegimeObjectiveError("simulation contains non-finite values on finite observation dates")
    weights = tail_emphasis_sample_weights(
        observed, tail_multiplier=tail_multiplier, tail_fraction=tail_fraction)
    residual = simulated[valid_observations] - observed[valid_observations]
    value = float(np.sum(weights[valid_observations] * residual**2, dtype=np.float64))
    if not np.isfinite(value):
        raise FlowRegimeObjectiveError(f"tail-emphasis objective is non-finite: {value}")
    return value


def flow_regime_balanced_one_minus_nse(observations: np.ndarray,
                                       predictions: np.ndarray,
                                       tail_fraction: float = 0.1) -> float:
    """Calculate the deterministic three-regime-balanced squared-error objective."""
    observed = np.asarray(observations, dtype=np.float64)
    simulated = np.asarray(predictions, dtype=np.float64)
    if simulated.shape != observed.shape:
        raise FlowRegimeObjectiveError(
            f"simulation shape {simulated.shape} does not match observation shape {observed.shape}")
    valid_observations = np.isfinite(observed)
    if not np.all(np.isfinite(simulated[valid_observations])):
        raise FlowRegimeObjectiveError("simulation contains non-finite values on finite observation dates")
    weights = flow_regime_sample_weights(observed, tail_fraction=tail_fraction)
    residual = simulated[valid_observations] - observed[valid_observations]
    value = float(np.sum(weights[valid_observations] * residual**2, dtype=np.float64))
    if not np.isfinite(value):
        raise FlowRegimeObjectiveError(f"flow-regime-balanced objective is non-finite: {value}")
    return value


def calibration_loss_value(observations: np.ndarray, predictions: np.ndarray, loss: str) -> float:
    """Calculate either arm of the controlled conceptual-model calibration."""
    observed = np.asarray(observations, dtype=np.float64)
    simulated = np.asarray(predictions, dtype=np.float64)
    mask = np.isfinite(observed)
    if mask.sum() < 30 or not np.all(np.isfinite(simulated[mask])):
        return float("nan")
    if loss == "flow_regime_nse":
        return flow_regime_balanced_one_minus_nse(observed, simulated)
    if loss == "tail_downweighted_nse":
        return tail_emphasis_one_minus_nse(observed, simulated, tail_multiplier=REVERSE_TAIL_MULTIPLIER)
    if loss == "nse":
        finite_observed = observed[mask]
        finite_simulated = simulated[mask]
        denominator = float(np.sum(
            (finite_observed - np.mean(finite_observed, dtype=np.float64))**2,
            dtype=np.float64,
        ))
        if denominator <= 0.0:
            return float("nan")
        return float(np.sum((finite_simulated - finite_observed)**2, dtype=np.float64) / denominator)
    raise ValueError(f"Unknown controlled loss arm: {loss}")


def build_lookup_sample_weights(lookup_table: dict,
                                raw_targets_by_basin: dict[str, dict[str, torch.Tensor]],
                                basin_ids: list[str],
                                frequency: str,
                                target_scale: float,
                                weight_function=None) -> dict[int, torch.Tensor]:
    """Build NeuralHydrology mini-batch weights from exact lookup target dates.

    ``weight_function`` maps one basin's optimization targets to per-sample coefficients and
    defaults to the registered equal-regime definition, so existing callers are unchanged.
    """
    if weight_function is None:
        weight_function = flow_regime_sample_weights
    if len(set(basin_ids)) != len(basin_ids):
        raise FlowRegimeObjectiveError("basin identifiers must be unique")
    if not np.isfinite(target_scale) or target_scale <= 0.0:
        raise FlowRegimeObjectiveError(f"target_scale must be finite and positive, got {target_scale}")
    lookup_by_basin: dict[str, list[tuple[int, float]]] = {basin: [] for basin in basin_ids}
    for item, (basin, indices) in lookup_table.items():
        if basin not in lookup_by_basin:
            raise FlowRegimeObjectiveError(f"lookup contains unexpected basin {basin}")
        target = raw_targets_by_basin[basin][frequency][indices[0], 0]
        if not torch.isfinite(target):
            raise FlowRegimeObjectiveError(f"lookup contains a non-finite target for basin {basin}")
        lookup_by_basin[basin].append((int(item), float(target.item())))
    missing = [basin for basin, values in lookup_by_basin.items() if not values]
    if missing:
        raise FlowRegimeObjectiveError(f"basins have no optimization samples: {missing}")

    total_count = len(lookup_table)
    multiplier = total_count * float(target_scale)**2 / len(basin_ids)
    weights: dict[int, torch.Tensor] = {}
    for basin, indexed_values in lookup_by_basin.items():
        reference = weight_function(np.asarray([value for _, value in indexed_values], dtype=np.float64))
        for (item, _), coefficient in zip(indexed_values, reference):
            weight = multiplier * float(coefficient)
            if not np.isfinite(weight) or weight <= 0.0:
                raise FlowRegimeObjectiveError(f"invalid sample weight {weight} for basin {basin}")
            weights[item] = torch.tensor([[weight]], dtype=torch.float64)
    return weights


class BasinAverageFlowRegimeNSELoss(BaseLoss):
    """Unbiased mini-batch estimator of the controlled equal-regime objective."""

    def __init__(self, cfg: Config):
        if len(cfg.target_variables) != 1:
            raise ValueError("BasinAverageFlowRegimeNSELoss requires exactly one target variable.")
        super().__init__(
            cfg,
            prediction_keys=["y_hat"],
            ground_truth_keys=["y"],
            additional_data=["per_sample_flow_regime_nse_weight"],
        )

    def _get_loss(self,
                  prediction: Dict[str, torch.Tensor],
                  ground_truth: Dict[str, torch.Tensor],
                  **kwargs) -> torch.Tensor:
        mask = ~torch.isnan(ground_truth["y"])
        if not torch.any(mask):
            raise ValueError("BasinAverageFlowRegimeNSELoss received no finite target values.")
        weights = kwargs["per_sample_flow_regime_nse_weight"].expand_as(prediction["y_hat"])[mask].to(
            dtype=torch.float64)
        if not torch.all(torch.isfinite(weights) & (weights > 0.0)):
            raise ValueError("BasinAverageFlowRegimeNSELoss weights must be finite and strictly positive.")
        predicted = prediction["y_hat"][mask].to(dtype=torch.float64)
        observed = ground_truth["y"][mask].to(dtype=torch.float64)
        return torch.mean(weights * (predicted - observed)**2)

    @staticmethod
    def _subset_additional_data(additional_data: Dict[str, torch.Tensor],
                                n_target: int) -> Dict[str, torch.Tensor]:
        return {key: value[:, :, n_target:n_target + 1] for key, value in additional_data.items()}
