"""Validate and materialize the frozen E04 independent-confirmation protocol."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path

from ruamel.yaml import YAML


EXPERIMENT_ID = "E04_daymet_post2008_objective_confirmation_482"
SEEDS = (100, 200, 300)
ARMS = {
    "nse": "e04_daymet_basin_nse.yml",
    "flow_regime_nse": "e04_daymet_flow_regime_nse.yml",
}
REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
SOURCE_ROOT = REPOSITORY_ROOT / "src" / "loss_mechanism_531"
CONFIG_ROOT = SOURCE_ROOT / "configs"
CONTRACT_PATH = CONFIG_ROOT / "e04_daymet_confirmation_contract.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _load_yaml(path: Path) -> dict:
    yaml = YAML(typ="safe")
    with Path(path).open("r", encoding="utf-8") as handle:
        return yaml.load(handle)


def _yaml_text(payload: dict) -> str:
    yaml = YAML()
    yaml.default_flow_style = False
    buffer = io.StringIO()
    yaml.dump(payload, buffer)
    return buffer.getvalue()


def _write_new_or_verify(path: Path, content: str) -> None:
    path = Path(path)
    if path.exists():
        if path.read_text(encoding="utf-8") != content:
            raise FileExistsError(f"refusing to overwrite a different frozen artifact: {path}")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8", newline="\n")


def load_and_validate_contract(contract_path: Path = CONTRACT_PATH) -> dict:
    contract = json.loads(Path(contract_path).read_text(encoding="utf-8"))
    if contract["experiment_id"] != EXPERIMENT_ID:
        raise ValueError("E04 experiment identifier drifted")
    manifest = REPOSITORY_ROOT / contract["basin_manifest"]
    source_manifest = REPOSITORY_ROOT / contract["source_basin_manifest"]
    basins = [line.strip().zfill(8) for line in manifest.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(basins) != len(set(basins)) or len(basins) != contract["required_basin_count"]:
        raise ValueError("E04 confirmation manifest count or uniqueness drifted")
    hashes = contract["frozen_hashes"]
    if sha256(manifest) != hashes["basin_manifest_sha256"]:
        raise ValueError("E04 confirmation manifest hash drifted")
    if sha256(source_manifest) != hashes["source_basin_manifest_sha256"]:
        raise ValueError("E04 source manifest hash drifted")
    return contract


def materialize_formal_configs(protocol_directory: Path, data_root: Path, run_root: Path) -> list[Path]:
    """Create the two arms by three seeds without modifying their source templates."""
    generated: list[Path] = []
    for arm, template_name in ARMS.items():
        source = _load_yaml(CONFIG_ROOT / template_name)
        for seed in SEEDS:
            config = dict(source)
            config["seed"] = seed
            config["experiment_name"] = f"E04_daymet_confirmation_{arm}_s{seed}"
            config["data_dir"] = str(Path(data_root).resolve())
            config["run_dir"] = str((Path(run_root) / arm).resolve())
            path = Path(protocol_directory) / "generated_configs" / f"{arm}_s{seed}.yml"
            _write_new_or_verify(path, _yaml_text(config))
            generated.append(path)
    return generated


def materialize_smoke_configs(smoke_directory: Path, data_root: Path, run_root: Path) -> tuple[Path, list[Path]]:
    """Create one-basin, one-epoch configs that cannot be mistaken for formal runs."""
    contract = load_and_validate_contract()
    source_manifest = REPOSITORY_ROOT / contract["basin_manifest"]
    first_basin = next(
        line.strip().zfill(8)
        for line in source_manifest.read_text(encoding="utf-8").splitlines()
        if line.strip()
    )
    smoke_directory = Path(smoke_directory)
    manifest = smoke_directory / "one_basin.txt"
    _write_new_or_verify(manifest, first_basin + "\n")

    generated: list[Path] = []
    for arm, template_name in ARMS.items():
        config = dict(_load_yaml(CONFIG_ROOT / template_name))
        config.update({
            "experiment_name": f"E04_daymet_confirmation_smoke_{arm}_s100",
            "run_dir": str((Path(run_root) / arm).resolve()),
            "data_dir": str(Path(data_root).resolve()),
            "train_basin_file": str(manifest.resolve()),
            "validation_basin_file": str(manifest.resolve()),
            "test_basin_file": str(manifest.resolve()),
            "epochs": 1,
            "save_weights_every": 1,
            "max_updates_per_epoch": 1,
            "seed": 100,
        })
        path = smoke_directory / "configs" / f"{arm}_s100.yml"
        _write_new_or_verify(path, _yaml_text(config))
        generated.append(path)
    return manifest, generated


def _source_inventory() -> list[dict[str, str]]:
    paths = [
        SOURCE_ROOT / "build_e04_confirmation_manifest.py",
        SOURCE_ROOT / "conceptual_calibration.py",
        SOURCE_ROOT / "flow_regime_balancing.py",
        SOURCE_ROOT / "neural_extension.py",
        SOURCE_ROOT / "evaluation_repair.py",
        SOURCE_ROOT / "run_neural_loss_experiment.py",
        SOURCE_ROOT / "run_neural_loss_evaluation_repair.py",
        SOURCE_ROOT / "score_flow_regime_loss_experiment.py",
        SOURCE_ROOT / "prepare_e04_confirmation.py",
        REPOSITORY_ROOT / "src/hydroagent/data_loading.py",
        REPOSITORY_ROOT / "src/scl_hydro/hbv_lite_numpy.py",
        REPOSITORY_ROOT / "src/xaj_global_pilot/bounds_presets.py",
        REPOSITORY_ROOT / "src/xaj_global_pilot/gr4j_core.py",
        REPOSITORY_ROOT / "src/xaj_global_pilot/gr4j_model.py",
        REPOSITORY_ROOT / "src/xaj_global_pilot/metrics.py",
        REPOSITORY_ROOT / "src/xaj_global_pilot/xaj_model.py",
        REPOSITORY_ROOT / "src/lstm_fair_531/scripts/hydrological_process_diagnostics.py",
        REPOSITORY_ROOT / "src/lstm_fair_531/scripts/posthoc_cause_diagnostics.py",
        CONFIG_ROOT / "e04_daymet_basin_nse.yml",
        CONFIG_ROOT / "e04_daymet_flow_regime_nse.yml",
        CONFIG_ROOT / "e04_daymet_confirmation_basins.txt",
        CONTRACT_PATH,
    ]
    for optional in (
        SOURCE_ROOT / "run_e04_conceptual.py",
        SOURCE_ROOT / "run_e04_neural.py",
        SOURCE_ROOT / "score_e04_confirmation.py",
        SOURCE_ROOT / "audit_e04_confirmation.py",
    ):
        if optional.exists():
            paths.append(optional)
    hpc_root = SOURCE_ROOT / "hpc"
    if hpc_root.exists():
        paths.extend(sorted(hpc_root.glob("e04_*.slurm")))
    return [
        {"path": path.relative_to(REPOSITORY_ROOT).as_posix(), "sha256": sha256(path)}
        for path in sorted(paths)
    ]


def _build_parser() -> argparse.ArgumentParser:
    contract = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, default=REPOSITORY_ROOT / "data/camels_us")
    parser.add_argument("--result-root", type=Path, default=REPOSITORY_ROOT / contract["registered_result_root"])
    parser.add_argument("--run-root", type=Path, default=REPOSITORY_ROOT / contract["neural_training_staging_root"])
    return parser


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)
    contract = load_and_validate_contract()
    if not (args.data_root / "basin_mean_forcing/daymet").is_dir():
        raise FileNotFoundError(f"Daymet forcing directory is missing: {args.data_root}")
    if not (args.data_root / "usgs_streamflow").is_dir():
        raise FileNotFoundError(f"streamflow directory is missing: {args.data_root}")

    protocol = args.result_root / "protocol"
    generated = materialize_formal_configs(protocol, args.data_root, args.run_root)
    smoke_manifest, smoke_configs = materialize_smoke_configs(
        args.result_root / "smoke",
        args.data_root,
        args.run_root.parent / f"{args.run_root.name}_smoke",
    )
    _write_new_or_verify(
        protocol / "e04_daymet_confirmation_contract.json",
        json.dumps(contract, ensure_ascii=False, indent=2) + "\n",
    )
    preflight = {
        "experiment_id": EXPERIMENT_ID,
        "contract_sha256": sha256(CONTRACT_PATH),
        "basin_manifest_sha256": contract["frozen_hashes"]["basin_manifest_sha256"],
        "source_basin_manifest_sha256": contract["frozen_hashes"]["source_basin_manifest_sha256"],
        "resolved_data_root": str(args.data_root.resolve()),
        "resolved_result_root": str(args.result_root.resolve()),
        "resolved_run_root": str(args.run_root.resolve()),
        "generated_configs": [
            {"path": path.relative_to(args.result_root).as_posix(), "sha256": sha256(path)}
            for path in generated
        ],
        "smoke_manifest": {
            "path": smoke_manifest.relative_to(args.result_root).as_posix(),
            "sha256": sha256(smoke_manifest),
        },
        "smoke_configs": [
            {"path": path.relative_to(args.result_root).as_posix(), "sha256": sha256(path)}
            for path in smoke_configs
        ],
        "source_files": _source_inventory(),
    }
    _write_new_or_verify(
        protocol / "preflight.json",
        json.dumps(preflight, ensure_ascii=False, indent=2) + "\n",
    )
    print(json.dumps({"experiment_id": EXPERIMENT_ID, "generated_config_count": len(generated)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
