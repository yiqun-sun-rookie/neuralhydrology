"""Prepare and content-pin common-loss conceptual-model daily predictions."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import math
import os
import shutil
import stat
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
import psutil

from src.lstm_fair_531.scripts.monitor_identical_basin_nse_resources import (
    MONITOR_INTERVAL_SECONDS,
    append_resource_row,
    collect_resource_snapshot,
    contains_nonfinite_training_signal,
    evaluate_stop_reason,
)
from src.lstm_fair_531.scripts.run_identical_basin_nse_replication import (
    _ArtifactStabilityGuard,
)


_PSUTIL_PROCESS_TYPE = psutil.Process
EXPERIMENT_ID = "R02_identical_basin_nse_531"
LOSS_PROTOCOL = "identical_basin_average_nse"
EVALUATION_START = pd.Timestamp("1989-10-01")
EVALUATION_END = pd.Timestamp("1999-09-30")
FIXED_CALIBRATION_SETTINGS = {
    "loss": "nse",
    "trials": 5000,
    "restarts": 3,
    "forcing": "maurer",
    "discharge_normalization": "common_forcing_header_float32",
    "pet_method": "priestley_taylor",
    "bounds_preset": "v1",
    "warmup_year": True,
}
FIXED_CMA_ARGUMENTS = {
    "kge_weight": 0.5,
    "init_mean": 0.5,
    "init_sigma": 0.3,
}


@dataclass(frozen=True)
class ConceptualModelSpec:
    label: str
    module_name: str
    model_name: str
    output_subdir: str
    default_workers: int


MODEL_SPECS = (
    ConceptualModelSpec(
        label="GR4J",
        module_name="src.xaj_global_pilot.scripts.run_gr4j_pdd_cma_repro_v01",
        model_name="gr4j_pdd_cma",
        output_subdir="gr4j_common_loss",
        default_workers=12,
    ),
    ConceptualModelSpec(
        label="XAJ",
        module_name="src.xaj_global_pilot.scripts.run_xaj_pdd_cma_repro_v01",
        model_name="xaj_pdd_cma",
        output_subdir="xaj_common_loss",
        default_workers=12,
    ),
    ConceptualModelSpec(
        label="HBV-lite",
        module_name="src.scl_hydro.scripts.run_hbv_lite_cma_repro_v01",
        model_name="hbv_lite_cma",
        output_subdir="hbv_lite_common_loss",
        default_workers=6,
    ),
)

CONCEPTUAL_MODEL_LABELS = tuple(spec.label for spec in MODEL_SPECS)


def select_model_specs(labels: Sequence[str]) -> list[ConceptualModelSpec]:
    """Return the requested model specifications in frozen execution order."""
    requested = list(labels)
    if not requested:
        raise ValueError("At least one conceptual model must be selected")
    if len(set(requested)) != len(requested):
        raise ValueError(f"Conceptual model selection repeats a model: {requested}")
    unknown = sorted(set(requested) - set(CONCEPTUAL_MODEL_LABELS))
    if unknown:
        raise ValueError(f"Conceptual model selection contains unknown models: {unknown}")
    return [spec for spec in MODEL_SPECS if spec.label in set(requested)]


def model_state_file_name(labels: Sequence[str]) -> str:
    """Name the execution state file so a partial arm never overwrites another."""
    selected = select_model_specs(labels)
    if len(selected) == len(MODEL_SPECS):
        return "execution_state.json"
    slugs = [spec.output_subdir.replace("_common_loss", "") for spec in selected]
    return f"execution_state_{'_'.join(slugs)}.json"


def _conceptual_source_roots() -> tuple[Path, ...]:
    """The runners add the repository root and its ``src`` directory to sys.path,
    so a first-party module name resolves against either root."""
    return (_REPOSITORY_ROOT, _REPOSITORY_ROOT / "src")


def _resolve_first_party_module(module_name: str, level: int, importer: Path) -> list[Path]:
    """Resolve an import to the first-party source files it names, or nothing.

    Third-party and standard-library names do not resolve under the repository
    roots and are ignored. A package name resolves to its ``__init__.py``; a
    ``from package import name`` additionally resolves ``name`` when it is itself
    a submodule file, so a leaf module imported by name is not missed.
    """
    if level and level > 0:
        base = importer.parent
        for _ in range(level - 1):
            base = base.parent
        bases = [base]
        parts = module_name.split(".") if module_name else []
    else:
        bases = list(_conceptual_source_roots())
        parts = module_name.split(".") if module_name else []
    resolved: list[Path] = []
    for base in bases:
        if parts:
            candidate_dir = base.joinpath(*parts)
            module_file = candidate_dir.with_suffix(".py")
            package_init = candidate_dir / "__init__.py"
            if module_file.is_file():
                resolved.append(module_file)
            elif package_init.is_file():
                resolved.append(package_init)
        elif level:
            package_init = base / "__init__.py"
            if package_init.is_file():
                resolved.append(package_init)
    return resolved


def _parent_package_inits(module_path: Path) -> list[Path]:
    """Return the ``__init__.py`` of every package directory Python runs before
    importing ``module_path``, from each source root down to the module.

    A dotted submodule import names only the leaf file, but Python executes each
    parent package initializer first, so those initializers must be hashed too.
    """
    module_path = module_path.resolve()
    inits: list[Path] = []
    for root in _conceptual_source_roots():
        root = root.resolve()
        try:
            relative = module_path.relative_to(root)
        except ValueError:
            continue
        directory = root
        for part in relative.parts[:-1]:
            directory = directory / part
            init_file = directory / "__init__.py"
            if init_file.is_file():
                inits.append(init_file)
        break
    return inits


def _first_party_import_closure(seed_files: Sequence[Path]) -> list[Path]:
    """Return the transitive first-party import closure of the seed files.

    Walks the abstract syntax tree of each file, following only imports that
    resolve to source under the repository roots, so cross-package dependencies
    such as ``hydroagent.data_loading`` and its transitive
    ``neuralhydrology.datasetzoo.camelsus`` are captured automatically instead of
    depending on a hand-maintained package list. Each resolved module also drags
    in the parent-package ``__init__.py`` files Python executes on import, and
    those initializers are themselves walked, so a package initializer that runs
    real code at import is covered rather than silently skipped.
    """
    seen: set[Path] = set()
    queue = [Path(path).resolve() for path in seed_files]
    while queue:
        current = queue.pop()
        if current in seen or not current.is_file():
            continue
        seen.add(current)
        # Every module Python runs -- including the seed runners themselves --
        # executes its parent-package initializers first, so enqueue them too.
        targets: list[Path] = list(_parent_package_inits(current))
        tree = ast.parse(current.read_bytes(), filename=str(current))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    targets.extend(_resolve_first_party_module(alias.name, 0, current))
            elif isinstance(node, ast.ImportFrom):
                targets.extend(
                    _resolve_first_party_module(node.module or "", node.level, current)
                )
                for alias in node.names:
                    child = f"{node.module}.{alias.name}" if node.module else alias.name
                    targets.extend(
                        _resolve_first_party_module(child, node.level, current)
                    )
        for target in list(targets):
            targets.extend(_parent_package_inits(target))
        for target in targets:
            resolved = target.resolve()
            if resolved not in seen:
                queue.append(resolved)
    return sorted(seen)


def collect_conceptual_source_provenance(
    specs: Sequence[ConceptualModelSpec],
) -> dict:
    """Record the science source each selected arm is about to be calibrated with.

    Arms are calibrated at different times, so without this record an edit to a
    loss, evapotranspiration, forcing, normalization or bounds path between arms
    would be invisible in the round artifacts. The record hashes the transitive
    first-party import closure of the selected runners, not a fixed package list,
    so every module that can change the numbers is covered.
    """

    def record(path: Path) -> dict:
        payload = path.read_bytes()
        return {"sha256": hashlib.sha256(payload).hexdigest(), "bytes": len(payload)}

    runner_modules = {}
    seed_files: list[Path] = []
    for spec in specs:
        runner_path = _REPOSITORY_ROOT / Path(*spec.module_name.split(".")).with_suffix(".py")
        if not runner_path.is_file():
            raise FileNotFoundError(f"Conceptual runner module does not exist: {runner_path}")
        runner_modules[spec.label] = {"path": str(runner_path), **record(runner_path)}
        seed_files.append(runner_path)
    closure = _first_party_import_closure(seed_files)
    source_closure_modules = {str(path): record(path) for path in closure}
    if not source_closure_modules:
        raise FileNotFoundError("No first-party conceptual source modules were found")
    return {
        "runner_modules": runner_modules,
        "source_roots": [str(root) for root in _conceptual_source_roots()],
        "source_closure_module_count": len(source_closure_modules),
        "source_closure_modules": source_closure_modules,
    }


CONCEPTUAL_RUNTIME_THRESHOLDS = {
    "minimum_free_system_memory_gib": 8.0,
    "minimum_free_accelerator_memory_gib": None,
    "minimum_free_disk_gib": 20.0,
}
HBV_LAUNCH_STABILITY_SAMPLE_COUNT = 3
HBV_LAUNCH_STABILITY_INTERVAL_SECONDS = 30.0

_REPOSITORY_ROOT = Path(__file__).resolve().parents[3]
_DEFAULT_RESULT_ROOT = (
    _REPOSITORY_ROOT / "results" / "18_lstm_fair_531" / EXPERIMENT_ID
)
_DEFAULT_PROTOCOL_PATH = _DEFAULT_RESULT_ROOT / "protocol" / "common_loss_protocol.json"
_DEFAULT_CONCEPTUAL_ROOT = _DEFAULT_RESULT_ROOT / "conceptual"
_DEFAULT_ATTEMPT_ROOT = _DEFAULT_CONCEPTUAL_ROOT / "attempts" / "common_loss_v1"
_DEFAULT_LOG_ROOT = (
    _REPOSITORY_ROOT / "logs" / "18_lstm_fair_531" / EXPERIMENT_ID / "conceptual"
)
_DEFAULT_HBV_RESOURCE_POLICY_PATH = (
    _REPOSITORY_ROOT
    / "src"
    / "lstm_fair_531"
    / "configs"
    / "hbv_lite_task_specific_resource_policy_v2.json"
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _strict_finite_number(value, *, label: str, positive: bool = False) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label} must be a finite number")
    normalized = float(value)
    if not math.isfinite(normalized) or (normalized <= 0.0 if positive else normalized < 0.0):
        qualifier = "positive finite" if positive else "finite non-negative"
        raise ValueError(f"{label} must be {qualifier}")
    return normalized


def _load_policy_evidence(
    record: dict, *, label: str, parse_json_object: bool
) -> tuple[Path, dict | None]:
    if not isinstance(record, dict) or set(record) != {"path", "sha256"}:
        raise ValueError(f"{label} evidence must contain exactly path and sha256")
    path = (_REPOSITORY_ROOT / str(record["path"])).resolve()
    if not path.is_file():
        raise FileNotFoundError(f"{label} evidence does not exist: {path}")
    actual_hash = _sha256(path)
    if actual_hash != record["sha256"]:
        raise ValueError(
            f"{label} SHA-256 does not match: expected {record['sha256']}, got {actual_hash}"
        )
    payload = None
    if parse_json_object:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise ValueError(f"{label} evidence must be a JSON object")
    return path, payload


def load_hbv_task_specific_resource_policy(path: Path) -> dict:
    """Validate reviewed HBV evidence and derive launch/runtime resource gates."""
    policy_path = Path(path).resolve()
    declaration = json.loads(policy_path.read_text(encoding="utf-8"))
    required_top_level = {
        "schema_version",
        "policy_id",
        "model",
        "target_basin_count",
        "workload",
        "physical_reserve_units_of_measured_peak",
        "commit_reserve_units_of_measured_peak",
        "disk_reserve_units_of_projected_output",
        "evidence",
    }
    if not isinstance(declaration, dict) or set(declaration) != required_top_level:
        raise ValueError("HBV task-specific resource policy has unexpected fields")
    if declaration["schema_version"] != 2:
        raise ValueError("HBV task-specific resource policy schema_version must equal 2")
    if declaration["policy_id"] != "hbv_lite_task_specific_resource_policy_v2":
        raise ValueError("HBV task-specific resource policy has the wrong policy_id")
    if declaration["model"] != "HBV-lite":
        raise ValueError("HBV task-specific resource policy model must equal HBV-lite")
    if type(declaration["target_basin_count"]) is not int or declaration["target_basin_count"] != 531:
        raise ValueError("HBV task-specific resource policy target_basin_count must equal 531")
    workload = declaration["workload"]
    if workload != {
        "workers": 2,
        "pool_task_limit": 4,
        "minimum_representative_basin_count": 81,
    }:
        raise ValueError("HBV task-specific resource policy workload does not match the reviewed probe")
    physical_reserve_units = _strict_finite_number(
        declaration["physical_reserve_units_of_measured_peak"],
        label="physical_reserve_units_of_measured_peak",
        positive=True,
    )
    commit_reserve_units = _strict_finite_number(
        declaration["commit_reserve_units_of_measured_peak"],
        label="commit_reserve_units_of_measured_peak",
        positive=True,
    )
    disk_reserve_units = _strict_finite_number(
        declaration["disk_reserve_units_of_projected_output"],
        label="disk_reserve_units_of_projected_output",
        positive=True,
    )
    if (
        physical_reserve_units != 1.0
        or commit_reserve_units != 1.0
        or disk_reserve_units != 1.0
    ):
        raise ValueError("HBV task-specific resource policy must retain one measured-peak reserve")

    evidence = declaration["evidence"]
    expected_evidence_labels = {
        "physical_probe_summary",
        "physical_probe_first_review",
        "physical_probe_second_verification",
        "commit_probe_summary",
        "commit_probe_first_review",
        "commit_probe_second_verification",
        "commit_probe_terminal_handoff",
        "hbv_runner",
        "basin_manifest",
        "protocol",
    }
    if not isinstance(evidence, dict) or set(evidence) != expected_evidence_labels:
        raise ValueError("HBV task-specific resource policy evidence set is incomplete")
    loaded = {
        label: _load_policy_evidence(
            evidence[label],
            label=label,
            parse_json_object=label not in {"hbv_runner", "basin_manifest"},
        )
        for label in sorted(expected_evidence_labels)
    }
    physical_probe = loaded["physical_probe_summary"][1]
    physical_first_review = loaded["physical_probe_first_review"][1]
    physical_second_verification = loaded["physical_probe_second_verification"][1]
    commit_probe = loaded["commit_probe_summary"][1]
    commit_first_review = loaded["commit_probe_first_review"][1]
    commit_second_verification = loaded["commit_probe_second_verification"][1]
    commit_terminal_handoff = loaded["commit_probe_terminal_handoff"][1]
    protocol = loaded["protocol"][1]

    for label, probe in (
        ("physical", physical_probe),
        ("commit", commit_probe),
    ):
        if probe.get("status") != "passed" or probe.get("stop_reasons") != []:
            raise ValueError(f"Reviewed HBV {label} probe must be complete with no stop reason")
    expected_probe_identity = {
        "workers": workload["workers"],
        "pool_task_limit": workload["pool_task_limit"],
        "limit": workload["minimum_representative_basin_count"],
        "basin_result_count": workload["minimum_representative_basin_count"],
        "daily_prediction_file_count": workload["minimum_representative_basin_count"],
        "result_and_daily_identity_match": True,
    }
    for label, probe in (("physical", physical_probe), ("commit", commit_probe)):
        for field, expected in expected_probe_identity.items():
            if type(probe.get(field)) is not type(expected) or probe.get(field) != expected:
                raise ValueError(
                    f"Reviewed HBV {label} probe field {field} must equal {expected!r}"
                )
    expected_scientific_settings = {
        **FIXED_CALIBRATION_SETTINGS,
        "write_daily_predictions": True,
    }
    reviewed_python_executables = []
    for label, probe in (("physical", physical_probe), ("commit", commit_probe)):
        probe_command = probe.get("command")
        if not isinstance(probe_command, list) or not probe_command:
            raise ValueError(f"Reviewed HBV {label} probe command is missing")
        reviewed_python_executables.append(Path(str(probe_command[0])).resolve())
        if probe.get("formal_scientific_settings") != expected_scientific_settings:
            raise ValueError(
                f"Reviewed HBV {label} probe settings do not match the frozen protocol"
            )
    reviewed_python_executable = reviewed_python_executables[0]
    if (
        any(path != reviewed_python_executable for path in reviewed_python_executables)
        or reviewed_python_executable != Path(sys.executable).resolve()
    ):
        raise ValueError("Current Python executable does not match both reviewed HBV probes")
    if physical_first_review.get("status") != "PASS" or not physical_first_review.get(
        "decision", {}
    ).get(
        "hbv_lite_representative_resource_gate_released"
    ):
        raise ValueError("First independent HBV physical resource review is not PASS")
    if physical_second_verification.get("status") != "PASS" or not physical_second_verification.get(
        "first_layer_comparison", {}
    ).get("first_layer_conclusion_supported"):
        raise ValueError("Second independent HBV physical resource verification is not PASS")
    if physical_second_verification.get("first_layer_comparison", {}).get(
        "actual_sha256"
    ) != evidence["physical_probe_first_review"]["sha256"]:
        raise ValueError("Second HBV physical verification does not bind the first review")
    if (
        commit_first_review.get("status") != "PASS"
        or commit_second_verification.get("decision") != "SUPPORT"
        or commit_terminal_handoff.get("status") != "PASS"
    ):
        raise ValueError("Reviewed HBV direct-commit evidence is not double-reviewed PASS")
    commit_review_identity = commit_second_verification.get("first_review_identity", {})
    if (
        commit_review_identity.get("observed_sha256")
        != evidence["commit_probe_first_review"]["sha256"]
        or commit_review_identity.get("match") is not True
    ):
        raise ValueError("Second HBV commit verification does not bind the first review")
    commit_claim_boundary = commit_second_verification.get(
        "first_review_claim_boundary_check", {}
    )
    if (
        commit_claim_boundary.get("requires_later_policy_with_explicit_safety_reserve")
        is not True
        or commit_claim_boundary.get("authorizes_formal_launch") is not False
    ):
        raise ValueError("HBV commit review has an invalid safety-reserve boundary")
    terminal_second = commit_terminal_handoff.get("second_verification", {})
    if (
        commit_terminal_handoff.get("first_review", {}).get("sha256")
        != evidence["commit_probe_first_review"]["sha256"]
        or terminal_second.get("sha256")
        != evidence["commit_probe_second_verification"]["sha256"]
        or commit_terminal_handoff.get("claim_boundary", {}).get(
            "formal_launch_authorized"
        )
        is not False
    ):
        raise ValueError("HBV commit terminal handoff does not bind the two reviews")
    basin_manifest_path = loaded["basin_manifest"][0]
    protocol_manifest_path = Path(str(protocol.get("basin_manifest_path", ""))).resolve()
    if (
        protocol.get("status") != "passed"
        or protocol.get("basin_count") != declaration["target_basin_count"]
        or protocol_manifest_path != basin_manifest_path
        or protocol.get("basin_manifest_sha256") != evidence["basin_manifest"]["sha256"]
    ):
        raise ValueError("Reviewed common-loss protocol does not bind the frozen 531-basin manifest")
    data_root = Path(str(protocol.get("data_dir", ""))).resolve()
    if not data_root.is_dir():
        raise FileNotFoundError(f"Reviewed common-loss data root does not exist: {data_root}")

    physical_candidates = []
    for label, probe in (("physical", physical_probe), ("commit", commit_probe)):
        for field in (
            "maximum_observed_system_memory_reduction_gib",
            "peak_runner_process_tree_rss_gib",
        ):
            physical_candidates.append(
                _strict_finite_number(
                    probe.get(field),
                    label=f"{label}_{field}",
                    positive=True,
                )
            )
    estimated_physical_peak = max(physical_candidates)
    estimated_commit_peak = _strict_finite_number(
        commit_probe.get("peak_owned_process_tree_private_commit_gib"),
        label="peak_owned_process_tree_private_commit_gib",
        positive=True,
    )
    review_commit_peak = _strict_finite_number(
        commit_second_verification.get("telemetry_recomputation", {}).get(
            "peak_owned_private_commit_gib"
        ),
        label="second verification peak_owned_private_commit_gib",
        positive=True,
    )
    terminal_commit_peak = _strict_finite_number(
        commit_terminal_handoff.get("confirmed_result", {}).get(
            "largest_directly_sampled_owned_private_commit_gib"
        ),
        label="terminal handoff largest_directly_sampled_owned_private_commit_gib",
        positive=True,
    )
    if estimated_commit_peak != review_commit_peak or estimated_commit_peak != terminal_commit_peak:
        raise ValueError("HBV commit probe does not match the second verification peak")
    monitor_intervals = [
        _strict_finite_number(
            probe.get("sample_interval_seconds"),
            label=f"{label}_sample_interval_seconds",
            positive=True,
        )
        for label, probe in (("physical", physical_probe), ("commit", commit_probe))
    ]
    if monitor_intervals[0] != monitor_intervals[1]:
        raise ValueError("Reviewed HBV probes used different monitor intervals")
    monitor_interval = monitor_intervals[0]
    physical_output_bytes = physical_second_verification.get("evidence_hashes", {}).get(
        "output_tree", {}
    ).get("total_bytes")
    commit_output_bytes = commit_second_verification.get(
        "output_tree_verification", {}
    ).get("total_size_bytes")
    if (
        type(physical_output_bytes) is not int
        or physical_output_bytes <= 0
        or type(commit_output_bytes) is not int
        or commit_output_bytes <= 0
    ):
        raise ValueError("Reviewed HBV output byte counts must be positive integers")
    output_bytes = max(physical_output_bytes, commit_output_bytes)

    runtime_physical_reserve = physical_reserve_units * estimated_physical_peak
    runtime_commit_reserve = commit_reserve_units * estimated_commit_peak
    launch_physical_requirement = estimated_physical_peak + runtime_physical_reserve
    launch_commit_requirement = estimated_commit_peak + runtime_commit_reserve
    projected_output_gib = (
        output_bytes
        * declaration["target_basin_count"]
        / workload["minimum_representative_basin_count"]
        / 1024**3
    )
    runtime_disk_reserve = disk_reserve_units * projected_output_gib
    launch_disk_requirement = projected_output_gib + runtime_disk_reserve
    evidence_bindings = {
        label: {
            "path": str(loaded[label][0]),
            "sha256": evidence[label]["sha256"],
        }
        for label in sorted(expected_evidence_labels)
    }
    return {
        "policy_id": declaration["policy_id"],
        "policy_path": str(policy_path),
        "policy_sha256": _sha256(policy_path),
        "model": declaration["model"],
        "target_basin_count": declaration["target_basin_count"],
        "workers": workload["workers"],
        "pool_task_limit": workload["pool_task_limit"],
        "monitor_interval_seconds": monitor_interval,
        "command_binding": {
            "python_executable": str(reviewed_python_executable),
            "module": "src.scl_hydro.scripts.run_hbv_lite_cma_repro_v01",
            "manifest_path": str(basin_manifest_path),
            "data_root": str(data_root),
            "output_subdir": "hbv_lite_common_loss",
        },
        "estimated_peak_task_physical_memory_gib": estimated_physical_peak,
        "estimated_peak_task_private_commit_gib": estimated_commit_peak,
        "physical_memory_reserve_gib": runtime_physical_reserve,
        "private_commit_reserve_gib": runtime_commit_reserve,
        "projected_output_gib": projected_output_gib,
        "launch_thresholds": {
            "minimum_free_system_memory_gib": launch_physical_requirement,
            "minimum_available_commit_memory_gib": launch_commit_requirement,
            "minimum_free_accelerator_memory_gib": None,
            "minimum_free_disk_gib": launch_disk_requirement,
        },
        "runtime_thresholds": {
            "minimum_free_system_memory_gib": runtime_physical_reserve,
            "minimum_available_commit_memory_gib": runtime_commit_reserve,
            "minimum_free_accelerator_memory_gib": None,
            "minimum_free_disk_gib": runtime_disk_reserve,
        },
        "evidence": evidence_bindings,
    }


def build_runner_arguments(
    spec: ConceptualModelSpec,
    *,
    manifest_path: Path,
    data_root: Path,
    attempt_root: Path,
    workers: int,
    pool_task_limit: int | None = None,
) -> list[str]:
    """Build the only accepted common-loss command arguments."""
    if int(workers) < 1:
        raise ValueError("Conceptual worker count must be at least one")
    arguments = [
        "--manifest", str(manifest_path),
        "--data-root", str(data_root),
        "--output-root", str(attempt_root),
        "--output-subdir", spec.output_subdir,
        "--workers", str(int(workers)),
        "--trials", str(FIXED_CALIBRATION_SETTINGS["trials"]),
        "--restarts", str(FIXED_CALIBRATION_SETTINGS["restarts"]),
        "--loss", FIXED_CALIBRATION_SETTINGS["loss"],
        "--kge-weight", str(FIXED_CMA_ARGUMENTS["kge_weight"]),
        "--forcing", FIXED_CALIBRATION_SETTINGS["forcing"],
        "--discharge-normalization", FIXED_CALIBRATION_SETTINGS["discharge_normalization"],
        "--pet-method", FIXED_CALIBRATION_SETTINGS["pet_method"],
        "--init-mean", str(FIXED_CMA_ARGUMENTS["init_mean"]),
        "--init-sigma", str(FIXED_CMA_ARGUMENTS["init_sigma"]),
        "--bounds-preset", FIXED_CALIBRATION_SETTINGS["bounds_preset"],
        "--warmup-year",
        "--write-daily-predictions",
        "--no-skip-existing",
    ]
    if pool_task_limit is not None:
        if int(pool_task_limit) < 1:
            raise ValueError("Conceptual pool task limit must be at least one")
        worker_position = arguments.index("--workers") + 2
        arguments[worker_position:worker_position] = ["--pool-task-limit", str(int(pool_task_limit))]
    return arguments


def build_execution_plans(
    *,
    manifest_path: Path,
    data_root: Path,
    attempt_root: Path,
    log_root: Path,
    python_executable: Path,
    workers_by_model: dict[str, int],
    pool_task_limits_by_model: Mapping[str, int] | None = None,
    selected_labels: Sequence[str] | None = None,
) -> list[dict]:
    """Build the selected explicit subprocess plans without starting them."""
    expected_labels = {spec.label for spec in MODEL_SPECS}
    if set(workers_by_model) != expected_labels:
        raise ValueError(
            f"Worker mapping must contain exactly {sorted(expected_labels)}, "
            f"got {sorted(workers_by_model)}"
        )
    pool_task_limits_by_model = dict(pool_task_limits_by_model or {})
    if not set(pool_task_limits_by_model).issubset(expected_labels):
        raise ValueError("Pool task limit mapping contains an unknown conceptual model")
    selected_specs = select_model_specs(
        CONCEPTUAL_MODEL_LABELS if selected_labels is None else selected_labels
    )
    plans = []
    for spec in selected_specs:
        arguments = build_runner_arguments(
            spec,
            manifest_path=Path(manifest_path),
            data_root=Path(data_root),
            attempt_root=Path(attempt_root),
            workers=int(workers_by_model[spec.label]),
            pool_task_limit=pool_task_limits_by_model.get(spec.label),
        )
        plans.append({
            "model": spec.label,
            "module": spec.module_name,
            "command": [
                str(python_executable),
                "-X",
                "utf8",
                "-m",
                spec.module_name,
                *arguments,
            ],
            "log_path": str(Path(log_root) / f"{spec.output_subdir}.log"),
        })
    return plans


ProcessIdentity = tuple[int, int | float]


def _process_identity(process: psutil.Process) -> ProcessIdentity:
    if os.name == "nt" and isinstance(process, _PSUTIL_PROCESS_TYPE):
        return int(process.pid), _windows_process_creation_ticks_for_pid(int(process.pid))
    return int(process.pid), float(process.create_time())


def _matches_process_identity(
    process: psutil.Process, expected_identity: ProcessIdentity
) -> bool:
    try:
        return bool(process.is_running()) and _process_identity(process) == expected_identity
    except (OSError, psutil.Error, TypeError, ValueError):
        return False


def _capture_owned_process_identity(process) -> ProcessIdentity | None:
    """Bind a process identifier to its creation time immediately after launch."""
    parent = psutil.Process(int(process.pid))
    identity = _process_identity(parent)
    if not _matches_process_identity(parent, identity):
        raise RuntimeError("Launched conceptual runner identity is not stable")
    if process.poll() is not None:
        return None
    return identity


def _stop_unbound_process_handle(process) -> None:
    """Stop the just-created process through its identity-safe operating-system handle."""
    try:
        process.terminate()
    except (AttributeError, OSError):
        return
    try:
        process.wait(timeout=10.0)
    except subprocess.TimeoutExpired:
        try:
            process.kill()
            process.wait(timeout=10.0)
        except (AttributeError, OSError, subprocess.TimeoutExpired):
            pass
    except (AttributeError, OSError):
        pass


def _collect_owned_descendants(
    parent: psutil.Process,
    parent_identity: ProcessIdentity,
) -> list[tuple[psutil.Process, ProcessIdentity]]:
    """Collect descendants through creation-time-stable direct parent edges."""
    if not _matches_process_identity(parent, parent_identity):
        return []
    try:
        children = parent.children(recursive=False)
    except (OSError, psutil.Error, TypeError, ValueError):
        return []
    owned: list[tuple[psutil.Process, ProcessIdentity]] = []
    for child in children:
        try:
            child_identity = _process_identity(child)
            child_parent_id = int(child.ppid())
        except (OSError, psutil.Error, TypeError, ValueError):
            continue
        if child_parent_id != int(parent.pid):
            continue
        if not _matches_process_identity(child, child_identity):
            continue
        if not _matches_process_identity(parent, parent_identity):
            continue
        owned.extend(_collect_owned_descendants(child, child_identity))
        owned.append((child, child_identity))
    return owned


def _windows_process_creation_ticks(handle: int) -> int:
    """Read raw Windows creation ticks through an already bound process handle."""
    if os.name != "nt":
        raise RuntimeError("Identity-bound process termination requires Windows")
    import ctypes
    from ctypes import wintypes

    class FileTime(ctypes.Structure):
        _fields_ = [
            ("low", wintypes.DWORD),
            ("high", wintypes.DWORD),
        ]

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    get_process_times = kernel32.GetProcessTimes
    get_process_times.argtypes = [
        wintypes.HANDLE,
        ctypes.POINTER(FileTime),
        ctypes.POINTER(FileTime),
        ctypes.POINTER(FileTime),
        ctypes.POINTER(FileTime),
    ]
    get_process_times.restype = wintypes.BOOL
    creation = FileTime()
    exit_time = FileTime()
    kernel = FileTime()
    user = FileTime()
    if not get_process_times(
        handle,
        ctypes.byref(creation),
        ctypes.byref(exit_time),
        ctypes.byref(kernel),
        ctypes.byref(user),
    ):
        raise ctypes.WinError(ctypes.get_last_error())
    return (int(creation.high) << 32) | int(creation.low)


def _windows_process_creation_ticks_for_pid(process_id: int) -> int:
    """Open a query handle and return the exact creation ticks for one process id."""
    if os.name != "nt":
        raise RuntimeError("Identity-bound process termination requires Windows")
    import _winapi

    process_query_limited_information = 0x1000
    access = process_query_limited_information | _winapi.SYNCHRONIZE
    handle = _winapi.OpenProcess(access, False, int(process_id))
    try:
        return _windows_process_creation_ticks(handle)
    finally:
        _winapi.CloseHandle(handle)


class _WindowsOwnedProcessHandle:
    """A retained Windows handle that cannot be redirected by process-id reuse."""

    def __init__(self, handle: int, identity: ProcessIdentity):
        self._handle = handle
        self.identity = identity

    def terminate(self) -> None:
        import _winapi

        _winapi.TerminateProcess(self._handle, 1)

    def wait(self, timeout: float) -> None:
        import _winapi

        milliseconds = max(0, math.ceil(float(timeout) * 1000.0))
        result = _winapi.WaitForSingleObject(self._handle, milliseconds)
        if result == _winapi.WAIT_TIMEOUT:
            raise subprocess.TimeoutExpired(str(self.identity[0]), timeout)
        if result != _winapi.WAIT_OBJECT_0:
            raise OSError(f"Unexpected Windows process wait result: {result}")

    def close(self) -> None:
        import _winapi

        if self._handle is not None:
            _winapi.CloseHandle(self._handle)
            self._handle = None


def _open_owned_process_handle(
    process: psutil.Process,
    identity: ProcessIdentity,
) -> _WindowsOwnedProcessHandle | None:
    """Open and validate the same operating-system process object before use."""
    if os.name != "nt":
        raise RuntimeError("Identity-bound process termination requires Windows")
    import _winapi

    process_id = int(process.pid)
    process_terminate = 0x0001
    process_query_limited_information = 0x1000
    access = process_terminate | process_query_limited_information | _winapi.SYNCHRONIZE
    try:
        handle = _winapi.OpenProcess(access, False, process_id)
    except OSError:
        return None
    try:
        handle_identity = (process_id, _windows_process_creation_ticks(handle))
        if handle_identity != identity:
            _winapi.CloseHandle(handle)
            return None
        state = _winapi.WaitForSingleObject(handle, 0)
        if state == _winapi.WAIT_OBJECT_0:
            _winapi.CloseHandle(handle)
            return None
        if state != _winapi.WAIT_TIMEOUT:
            raise OSError(f"Unexpected Windows process wait result: {state}")
        return _WindowsOwnedProcessHandle(handle, handle_identity)
    except BaseException:
        _winapi.CloseHandle(handle)
        raise


def _terminate_owned_process_tree(
    process, *, expected_identity: ProcessIdentity
) -> None:
    """Stop only a runner whose current process identity matches the launched one."""
    try:
        parent = psutil.Process(int(process.pid))
    except (psutil.Error, TypeError, ValueError):
        return
    if not _matches_process_identity(parent, expected_identity):
        return
    owned = _collect_owned_descendants(parent, expected_identity)
    owned.append((parent, expected_identity))
    handles = []
    try:
        for owned_process, identity in owned:
            if not _matches_process_identity(owned_process, identity):
                continue
            handle = _open_owned_process_handle(owned_process, identity)
            if handle is not None:
                handles.append(handle)
        for handle in handles:
            try:
                handle.terminate()
            except OSError:
                continue
        for handle in handles:
            try:
                handle.wait(timeout=10.0)
            except (OSError, subprocess.TimeoutExpired):
                continue
    finally:
        for handle in reversed(handles):
            try:
                handle.close()
            except OSError:
                continue


class _StableProcessTreeCpuTracker:
    """Monotonically retain processor time for one creation-time-bound process tree."""

    def __init__(self, parent: psutil.Process):
        self._parent = parent
        self._parent_identity = self._identity(parent)
        self._maximum_cpu_seconds_by_identity: dict[tuple[int, float], float] = {}

    @staticmethod
    def _identity(process: psutil.Process) -> tuple[int, float]:
        return int(process.pid), float(process.create_time())

    @classmethod
    def for_process_id(cls, process_id: int) -> "_StableProcessTreeCpuTracker":
        return cls(psutil.Process(int(process_id)))

    def sample(self) -> float | None:
        try:
            if not self._parent.is_running() or self._identity(self._parent) != self._parent_identity:
                return None
            processes = [self._parent, *self._parent.children(recursive=True)]
        except psutil.Error:
            return None
        for owned_process in processes:
            try:
                identity = self._identity(owned_process)
                times = owned_process.cpu_times()
            except psutil.Error:
                continue
            cpu_seconds = float(times.user) + float(times.system)
            previous = self._maximum_cpu_seconds_by_identity.get(identity, 0.0)
            self._maximum_cpu_seconds_by_identity[identity] = max(previous, cpu_seconds)
        if not self._maximum_cpu_seconds_by_identity:
            return None
        return sum(self._maximum_cpu_seconds_by_identity.values())


def _create_process_tree_cpu_collector(process_id: int) -> Callable[[], float | None]:
    tracker = _StableProcessTreeCpuTracker.for_process_id(process_id)
    return tracker.sample


def _new_nonfinite_log_detector(log_path: Path) -> Callable[[], bool]:
    log_path = Path(log_path)

    def detected() -> bool:
        if not log_path.exists():
            return False
        with log_path.open("r", encoding="utf-8", errors="replace") as handle:
            handle.seek(max(0, log_path.stat().st_size - 65_536))
            return contains_nonfinite_training_signal(handle.read())

    return detected


def _new_conceptual_selection_artifact_detector(
    *, conceptual_root: Path, attempt_root: Path
) -> Callable[[], bool]:
    """Detect content-inventory changes outside the isolated calibration attempt."""
    conceptual_root = Path(conceptual_root).resolve()
    attempt_root = Path(attempt_root).resolve()

    def external_inventory() -> dict[str, str]:
        inventory = {}
        if not conceptual_root.is_dir():
            return inventory
        for path in conceptual_root.rglob("*"):
            try:
                try:
                    path.relative_to(attempt_root)
                    continue
                except ValueError:
                    pass
                relative_path = str(path.relative_to(conceptual_root))
                if path.is_symlink():
                    inventory[relative_path] = f"symlink:{os.readlink(path)}"
                elif path.is_file():
                    inventory[relative_path] = f"file:{_sha256(path)}"
            except FileNotFoundError:
                continue
        return inventory

    baseline_inventory = external_inventory()
    baseline_external_symlinks = {
        path for path, fingerprint in baseline_inventory.items() if fingerprint.startswith("symlink:")
    }

    def detected() -> bool:
        return bool(baseline_external_symlinks) or external_inventory() != baseline_inventory

    return detected


def _single_command_option(command: Sequence[str], option: str) -> str:
    positions = [index for index, value in enumerate(command) if value == option]
    if len(positions) != 1 or positions[0] + 1 >= len(command):
        raise ValueError(f"HBV-lite command must contain exactly one {option} value")
    value = command[positions[0] + 1]
    if value.startswith("--"):
        raise ValueError(f"HBV-lite command option {option} is missing its value")
    return value


def _validate_hbv_resource_policy_command(
    command: Sequence[str],
    resource_policy: Mapping[str, object],
    *,
    workspace: Path,
) -> None:
    binding = resource_policy.get("command_binding")
    if not isinstance(binding, Mapping):
        raise ValueError("HBV-lite resource policy is missing its reviewed command binding")
    expected_python_executable = str(binding.get("python_executable"))
    if not command or str(command[0]) != expected_python_executable:
        raise ValueError("HBV-lite command must use the reviewed Python executable")
    expected_module = str(binding.get("module"))
    if len(command) < 5 or list(command[1:5]) != ["-X", "utf8", "-m", expected_module]:
        raise ValueError("HBV-lite command must use the exact canonical grammar")
    for option, expected_path in (
        ("--manifest", binding.get("manifest_path")),
        ("--data-root", binding.get("data_root")),
    ):
        actual_path = Path(_single_command_option(command, option))
        if not actual_path.is_absolute():
            actual_path = Path(workspace) / actual_path
        if actual_path.resolve() != Path(str(expected_path)).resolve():
            raise ValueError(f"HBV-lite command {option} is outside the reviewed binding")
    output_root = _single_command_option(command, "--output-root")
    spec = next(spec for spec in MODEL_SPECS if spec.label == "HBV-lite")
    expected_arguments = build_runner_arguments(
        spec,
        manifest_path=Path(str(binding["manifest_path"])),
        data_root=Path(str(binding["data_root"])),
        attempt_root=Path(output_root),
        workers=int(resource_policy["workers"]),
        pool_task_limit=int(resource_policy["pool_task_limit"]),
    )
    expected_command = [
        expected_python_executable,
        "-X",
        "utf8",
        "-m",
        expected_module,
        *expected_arguments,
    ]
    if list(command) != expected_command:
        raise ValueError("HBV-lite command must use the exact canonical grammar")


def _freshly_validate_hbv_resource_policy(resource_policy: Mapping[str, object]) -> dict:
    policy_path = resource_policy.get("policy_path")
    if not isinstance(policy_path, str):
        raise ValueError("HBV-lite resource policy is missing its source path")
    freshly_validated = load_hbv_task_specific_resource_policy(Path(policy_path))
    if dict(resource_policy) != freshly_validated:
        raise ValueError("HBV-lite resource policy does not match the freshly validated evidence")
    return freshly_validated


def execute_monitored_runner(
    command: Sequence[str],
    *,
    workspace: Path,
    log_path: Path,
    resource_log_path: Path,
    model_label: str,
    resource_policy: Mapping[str, object] | None = None,
    evaluation_leakage_detector: Callable[[], bool],
    popen_factory: Callable = subprocess.Popen,
    snapshot_collector: Callable = collect_resource_snapshot,
    row_writer: Callable = append_resource_row,
    sleep: Callable[[float], None] = time.sleep,
    clock: Callable[[], float] = time.monotonic,
    stop_process: Callable = _terminate_owned_process_tree,
    process_tree_cpu_collector_factory: Callable[
        [int], Callable[[], float | None]
    ] = _create_process_tree_cpu_collector,
    process_identity_factory: Callable[[object], ProcessIdentity | None] = (
        _capture_owned_process_identity
    ),
    nonfinite_signal_detector: Callable[[], bool] | None = None,
) -> int:
    """Run one conceptual command with its validated system-wide resource policy."""
    command = [str(value) for value in command]
    if not command:
        raise ValueError("Conceptual runner command must not be empty")
    workspace = Path(workspace).resolve()
    if model_label == "HBV-lite" and resource_policy is None:
        raise ValueError("HBV-lite requires a task-specific resource policy")
    disk_path = workspace
    if model_label == "HBV-lite":
        resource_policy = _freshly_validate_hbv_resource_policy(resource_policy)
    if resource_policy is None:
        launch_thresholds = CONCEPTUAL_RUNTIME_THRESHOLDS
        runtime_thresholds = CONCEPTUAL_RUNTIME_THRESHOLDS
        monitor_interval_seconds = MONITOR_INTERVAL_SECONDS
    else:
        if resource_policy.get("model") != model_label:
            raise ValueError(
                f"Resource policy model must equal {model_label!r}, got {resource_policy.get('model')!r}"
            )
        if model_label == "HBV-lite":
            _validate_hbv_resource_policy_command(
                command,
                resource_policy,
                workspace=workspace,
            )
            output_root = Path(_single_command_option(command, "--output-root"))
            if not output_root.is_absolute():
                output_root = workspace / output_root
            disk_path = output_root.resolve()
        launch_thresholds = resource_policy["launch_thresholds"]
        runtime_thresholds = resource_policy["runtime_thresholds"]
        monitor_interval_seconds = float(resource_policy["monitor_interval_seconds"])
    log_path = Path(log_path).resolve()
    if log_path.exists():
        raise FileExistsError(
            f"Conceptual runner log already exists and would be truncated: {log_path}"
        )
    resource_log_path = Path(resource_log_path).resolve()
    if nonfinite_signal_detector is None:
        nonfinite_signal_detector = _new_nonfinite_log_detector(log_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    resource_log_path.parent.mkdir(parents=True, exist_ok=True)
    creationflags = 0
    if os.name == "nt":
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(
            subprocess, "CREATE_NEW_PROCESS_GROUP", 0
        )
    preflight_sample_count = 1
    preflight_interval_seconds = 0.0
    if model_label == "HBV-lite":
        preflight_sample_count = HBV_LAUNCH_STABILITY_SAMPLE_COUNT
        preflight_interval_seconds = HBV_LAUNCH_STABILITY_INTERVAL_SECONDS
    for sample_index in range(preflight_sample_count):
        if sample_index:
            sleep(preflight_interval_seconds)
        if preflight_sample_count == 1:
            preflight_phase = f"conceptual_{model_label}_preflight"
        else:
            preflight_phase = (
                f"conceptual_{model_label}_preflight_"
                f"{sample_index + 1}_of_{preflight_sample_count}"
            )
        preflight_snapshot = snapshot_collector(
            workspace=workspace,
            disk_path=disk_path,
            phase=preflight_phase,
            seed=None,
            process_id=None,
            log_path=log_path,
        )
        preflight_stop_reason = evaluate_stop_reason(
            preflight_snapshot,
            launch_thresholds,
            seconds_since_progress=0.0,
            nonfinite_training_value=False,
            evaluation_leakage=bool(evaluation_leakage_detector()),
        )
        preflight_row = dict(preflight_snapshot)
        preflight_row.update({
            "phase": preflight_phase,
            "seed": None,
            "process_id": None,
            "seconds_since_progress": 0.0,
            "stop_reason": preflight_stop_reason or "",
        })
        row_writer(resource_log_path, preflight_row)
        if preflight_stop_reason is not None:
            raise RuntimeError(
                f"Conceptual runner {model_label} blocked before launch: "
                f"{preflight_stop_reason}"
            )
    log_descriptor = os.open(log_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    with open(log_descriptor, "w", encoding="utf-8", buffering=1) as log_file:
        process = popen_factory(
            command,
            cwd=str(workspace),
            stdout=log_file,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            shell=False,
            creationflags=creationflags,
        )
        identity_bound_stop = stop_process is _terminate_owned_process_tree
        process_identity = None
        if identity_bound_stop:
            try:
                process_identity = process_identity_factory(process)
            except BaseException:
                _stop_unbound_process_handle(process)
                raise
        stopped = False

        def stop_once() -> None:
            nonlocal stopped
            if not stopped:
                if identity_bound_stop:
                    if process_identity is not None:
                        stop_process(process, expected_identity=process_identity)
                else:
                    stop_process(process)
                stopped = True

        try:
            last_size = log_path.stat().st_size
            last_progress = clock()
            process_tree_cpu_collector = process_tree_cpu_collector_factory(process.pid)
            last_process_tree_cpu_seconds = process_tree_cpu_collector()
            while process.poll() is None:
                now = clock()
                process_tree_cpu_seconds = process_tree_cpu_collector()
                if (process_tree_cpu_seconds is not None
                        and last_process_tree_cpu_seconds is not None
                        and process_tree_cpu_seconds > last_process_tree_cpu_seconds):
                    last_progress = now
                if process_tree_cpu_seconds is not None:
                    last_process_tree_cpu_seconds = process_tree_cpu_seconds
                snapshot = snapshot_collector(
                    workspace=workspace,
                    disk_path=disk_path,
                    phase=f"conceptual_{model_label}_running",
                    seed=None,
                    process_id=process.pid,
                    log_path=log_path,
                )
                log_size = int(snapshot.get("log_size_bytes", 0))
                if log_size != last_size:
                    last_size = log_size
                    last_progress = now
                seconds_since_progress = max(0.0, now - last_progress)
                stop_reason = evaluate_stop_reason(
                    snapshot,
                    runtime_thresholds,
                    seconds_since_progress=seconds_since_progress,
                    nonfinite_training_value=bool(nonfinite_signal_detector()),
                    evaluation_leakage=bool(evaluation_leakage_detector()),
                )
                row = dict(snapshot)
                row.update({
                    "phase": f"conceptual_{model_label}_running",
                    "seed": None,
                    "process_id": process.pid,
                    "seconds_since_progress": seconds_since_progress,
                    "stop_reason": stop_reason or "",
                })
                row_writer(resource_log_path, row)
                if stop_reason is not None:
                    stop_once()
                    raise RuntimeError(
                        f"Conceptual runner {model_label} stopped by resource monitor: {stop_reason}"
                    )
                sleep(monitor_interval_seconds)
            return_code = int(process.returncode)
            terminal_snapshot = snapshot_collector(
                workspace=workspace,
                disk_path=disk_path,
                phase=f"conceptual_{model_label}_completed",
                seed=None,
                process_id=process.pid,
                log_path=log_path,
            )
            terminal_stop_reason = evaluate_stop_reason(
                terminal_snapshot,
                runtime_thresholds,
                seconds_since_progress=0.0,
                nonfinite_training_value=bool(nonfinite_signal_detector()),
                evaluation_leakage=bool(evaluation_leakage_detector()),
            )
            if terminal_stop_reason is None and return_code != 0:
                terminal_stop_reason = f"exit_code_{return_code}"
            terminal_row = dict(terminal_snapshot)
            terminal_row.update({
                "phase": f"conceptual_{model_label}_completed",
                "seed": None,
                "process_id": process.pid,
                "seconds_since_progress": 0.0,
                "stop_reason": terminal_stop_reason or "",
            })
            row_writer(resource_log_path, terminal_row)
            if terminal_stop_reason in {"nonfinite_training_value", "evaluation_leakage"}:
                raise RuntimeError(
                    f"Conceptual runner {model_label} stopped by scientific condition: "
                    f"{terminal_stop_reason}"
                )
            if return_code != 0:
                raise subprocess.CalledProcessError(return_code, command)
            return return_code
        except BaseException:
            if getattr(process, "returncode", None) is None:
                stop_once()
            raise


def run_conceptual_model_sequence(
    plans: Sequence[dict], *, execute: Callable[[dict], int]
) -> dict[str, int]:
    """Execute the selected frozen model families one after another, in frozen order."""
    actual_order = [str(plan.get("model")) for plan in plans]
    expected_order = [spec.label for spec in select_model_specs(actual_order)]
    if actual_order != expected_order:
        raise ValueError(f"Conceptual model order must be {expected_order}, got {actual_order}")
    results = {}
    for plan in plans:
        results[str(plan["model"])] = int(execute(plan))
    return results


def _normalize_basin_ids(values: Iterable) -> pd.Series:
    result = pd.Series(values, dtype=str).str.replace(r"\.0$", "", regex=True).str.strip().str.zfill(8)
    if result.eq("").any() or result.duplicated().any():
        raise ValueError("Expected basin identifiers must be non-empty and unique")
    return result


def _read_summary(path: Path, *, spec: ConceptualModelSpec, expected_ids: set[str]) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(f"Missing {spec.label} calibration summary: {path}")
    frame = pd.read_csv(path, dtype={"basin_id": str}, keep_default_na=False)
    required = {"basin_id", "period", "run_status", "nse", "discharge_normalization"}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"{spec.label} calibration summary is missing columns: {missing}")
    frame["basin_id"] = frame["basin_id"].astype(str).str.zfill(8)
    if frame["basin_id"].duplicated().any() or set(frame["basin_id"]) != expected_ids:
        raise ValueError(f"{spec.label} calibration summary basin set does not match the frozen manifest")
    if not frame["period"].astype(str).eq("evaluation").all():
        raise ValueError(f"{spec.label} calibration summary must contain only evaluation rows")
    if not frame["run_status"].astype(str).eq("success").all():
        failed = frame.loc[~frame["run_status"].astype(str).eq("success"), "basin_id"].tolist()
        raise ValueError(f"{spec.label} contains failed basins: {failed[:10]}")
    if not frame["discharge_normalization"].astype(str).eq(
        FIXED_CALIBRATION_SETTINGS["discharge_normalization"]
    ).all():
        raise ValueError(f"{spec.label} calibration summary uses the wrong discharge normalization")
    frame["nse"] = pd.to_numeric(frame["nse"], errors="raise").astype(float)
    if not np.isfinite(frame["nse"].to_numpy()).all():
        raise ValueError(f"{spec.label} calibration summary contains non-finite NSE values")
    return frame.sort_values("basin_id").reset_index(drop=True)


def _read_metadata(
    path: Path,
    *,
    spec: ConceptualModelSpec,
    expected_basin_count: int,
    expected_daily_dir: Path,
) -> dict:
    if not path.is_file():
        raise FileNotFoundError(f"Missing {spec.label} metadata: {path}")
    metadata = json.loads(path.read_text(encoding="utf-8"))
    expected_fields = {
        "protocol": "repro_v01",
        "protocol_version": "camels_us_531_repro_v01",
        "model": spec.model_name,
        "output_subdir": spec.output_subdir,
        "forcing": FIXED_CALIBRATION_SETTINGS["forcing"],
        "pet_method": FIXED_CALIBRATION_SETTINGS["pet_method"],
        "discharge_normalization": FIXED_CALIBRATION_SETTINGS["discharge_normalization"],
        "bounds_preset": FIXED_CALIBRATION_SETTINGS["bounds_preset"],
        "loss": FIXED_CALIBRATION_SETTINGS["loss"],
        "kge_weight": 0.5,
        "init_mean": 0.5,
        "init_sigma": 0.3,
        "warmup_year": FIXED_CALIBRATION_SETTINGS["warmup_year"],
        "calibration_start": "1999-10-01",
        "calibration_end": "2008-09-30",
        "evaluation_start": EVALUATION_START.strftime("%Y-%m-%d"),
        "evaluation_end": EVALUATION_END.strftime("%Y-%m-%d"),
        "trials": FIXED_CALIBRATION_SETTINGS["trials"],
        "restarts": FIXED_CALIBRATION_SETTINGS["restarts"],
        "n_basins_total": expected_basin_count,
        "n_skipped_existing": 0,
        "n_executed": expected_basin_count,
        "n_in_summary": expected_basin_count,
    }
    for field, expected in expected_fields.items():
        actual = metadata.get(field)
        if type(actual) is not type(expected) or actual != expected:
            raise ValueError(
                f"{spec.label} metadata field {field} must equal {expected!r}, got {actual!r}"
            )
    daily_predictions = metadata.get("daily_predictions")
    if not isinstance(daily_predictions, str) or Path(daily_predictions).resolve() != expected_daily_dir.resolve():
        raise ValueError(
            f"{spec.label} metadata field daily_predictions does not identify its daily output directory"
        )
    return metadata


def _read_daily(
    daily_dir: Path, *, spec: ConceptualModelSpec, expected_ids: Sequence[str]
) -> tuple[pd.DataFrame, list[dict]]:
    expected_paths = {basin_id: daily_dir / f"{basin_id}.csv" for basin_id in expected_ids}
    actual_paths = sorted(daily_dir.glob("*.csv")) if daily_dir.is_dir() else []
    if {path.stem for path in actual_paths} != set(expected_ids):
        raise ValueError(f"{spec.label} daily prediction files do not match the frozen basin manifest")
    frames = []
    inventory = []
    for basin_id, path in expected_paths.items():
        frame = pd.read_csv(path, dtype={"basin_id": str})
        if list(frame.columns) != ["basin_id", "date", "obs", "sim"]:
            raise ValueError(f"{spec.label} daily file has unexpected columns: {path}")
        frame["basin_id"] = frame["basin_id"].astype(str).str.zfill(8)
        if frame.empty or set(frame["basin_id"]) != {basin_id}:
            raise ValueError(f"{spec.label} daily file has the wrong basin identifier: {path}")
        frame["date"] = pd.to_datetime(frame["date"], errors="raise")
        frame["obs"] = pd.to_numeric(frame["obs"], errors="raise").astype(float)
        frame["sim"] = pd.to_numeric(frame["sim"], errors="raise").astype(float)
        if frame["date"].duplicated().any():
            raise ValueError(f"{spec.label} daily file contains duplicate dates: {path}")
        if frame["date"].min() < EVALUATION_START or frame["date"].max() > EVALUATION_END:
            raise ValueError(f"{spec.label} daily file contains dates outside the evaluation period: {path}")
        if not np.isfinite(frame[["obs", "sim"]].to_numpy(dtype=float)).all():
            raise ValueError(f"{spec.label} daily file contains non-finite values: {path}")
        frames.append(frame)
        inventory.append({"path": str(path.resolve()), "sha256": _sha256(path)})
    combined = pd.concat(frames, ignore_index=True).sort_values(["basin_id", "date"]).reset_index(drop=True)
    return combined, inventory


def _validate_summary_nse(spec: ConceptualModelSpec, summary: pd.DataFrame, daily: pd.DataFrame) -> None:
    recalculated = {}
    for basin_id, frame in daily.groupby("basin_id", sort=True):
        obs = frame["obs"].to_numpy(dtype=np.float64)
        sim = frame["sim"].to_numpy(dtype=np.float64)
        denominator = float(np.sum((obs - np.mean(obs))**2))
        if not np.isfinite(denominator) or denominator <= 0.0:
            raise ValueError(f"{spec.label} basin {basin_id} has a non-positive evaluation denominator")
        recalculated[str(basin_id)] = round(
            1.0 - float(np.sum((sim - obs)**2)) / denominator,
            6,
        )
    registered = summary.set_index("basin_id")["nse"].astype(float).to_dict()
    maximum_difference = max(abs(recalculated[basin_id] - registered[basin_id]) for basin_id in registered)
    if maximum_difference > 1e-10:
        raise ValueError(
            f"{spec.label} summary NSE does not match daily predictions; maximum difference {maximum_difference}"
        )


def _make_read_only(path: Path) -> None:
    Path(path).chmod(Path(path).stat().st_mode & ~stat.S_IWRITE)


def _remove_tree(path: Path) -> None:
    path = Path(path)
    if not path.exists():
        return
    for child in path.rglob("*"):
        if child.is_file():
            child.chmod(child.stat().st_mode | stat.S_IWRITE)
    shutil.rmtree(path)


def publish_registered_conceptual_outputs_from_model_roots(
    *,
    model_attempt_roots: Mapping[str, Path],
    conceptual_root: Path,
    protocol_manifest_path: Path,
    expected_basin_ids: Sequence[str],
) -> Path:
    """Validate model-specific attempts and atomically publish one registered bundle."""
    expected_model_labels = {spec.label for spec in MODEL_SPECS}
    if set(model_attempt_roots) != expected_model_labels:
        raise ValueError(
            "Model attempt roots must contain exactly the registered conceptual models: "
            f"expected={sorted(expected_model_labels)}, found={sorted(model_attempt_roots)}"
        )
    resolved_attempt_roots = {
        spec.label: Path(model_attempt_roots[spec.label]).resolve() for spec in MODEL_SPECS
    }
    conceptual_root = Path(conceptual_root).resolve()
    protocol_manifest_path = Path(protocol_manifest_path).resolve()
    expected_ids = _normalize_basin_ids(expected_basin_ids).tolist()
    expected_set = set(expected_ids)
    if not protocol_manifest_path.is_file():
        raise FileNotFoundError(f"Common-loss protocol manifest does not exist: {protocol_manifest_path}")
    manifest_path = conceptual_root / "conceptual_prediction_manifest.json"
    registered_root = conceptual_root / "registered_outputs"
    if manifest_path.exists() or registered_root.exists():
        raise FileExistsError(f"Registered conceptual output already exists: {conceptual_root}")

    source_guard_paths = [protocol_manifest_path]
    source_guard_directories = []
    for spec in MODEL_SPECS:
        attempt_root = resolved_attempt_roots[spec.label]
        summary_path = attempt_root / "summary" / f"{spec.output_subdir}_local_full.csv"
        metadata_path = summary_path.with_suffix(".metadata.json")
        if not metadata_path.is_file():
            raise FileNotFoundError(f"Missing {spec.label} metadata: {metadata_path}")
        source_guard_paths.append(summary_path)
        source_guard_paths.append(metadata_path)
        source_guard_directories.append(summary_path.parent)
        daily_dir = attempt_root / spec.output_subdir / "daily"
        source_guard_directories.append(daily_dir)
        source_guard_paths.extend(daily_dir / f"{basin_id}.csv" for basin_id in expected_ids)

    conceptual_root_was_created = not conceptual_root.exists()
    conceptual_root.mkdir(parents=True, exist_ok=True)
    staging_root = conceptual_root / f".registered_outputs.staging-{os.getpid()}-{time.time_ns()}"
    temporary_manifest = None
    try:
        with _ArtifactStabilityGuard(
            source_guard_paths,
            directories=source_guard_directories,
            watch_parent_directories=False,
        ):
            validated = []
            source_paths: list[tuple[Path, str]] = [
                (protocol_manifest_path, _sha256(protocol_manifest_path))
            ]
            first_keys = None
            first_obs = None
            for spec in MODEL_SPECS:
                attempt_root = resolved_attempt_roots[spec.label]
                summary_path = attempt_root / "summary" / f"{spec.output_subdir}_local_full.csv"
                metadata_path = summary_path.with_suffix(".metadata.json")
                daily_dir = attempt_root / spec.output_subdir / "daily"
                summary = _read_summary(summary_path, spec=spec, expected_ids=expected_set)
                _read_metadata(
                    metadata_path,
                    spec=spec,
                    expected_basin_count=len(expected_ids),
                    expected_daily_dir=daily_dir,
                )
                daily, inventory = _read_daily(
                    daily_dir,
                    spec=spec,
                    expected_ids=expected_ids,
                )
                _validate_summary_nse(spec, summary, daily)
                keys = pd.MultiIndex.from_frame(daily[["basin_id", "date"]])
                obs = daily["obs"].to_numpy(dtype=np.float64)
                if first_keys is None:
                    first_keys = keys
                    first_obs = obs
                elif not keys.equals(first_keys):
                    raise ValueError(
                        f"{spec.label} basin-date mask does not match {MODEL_SPECS[0].label}"
                    )
                elif not np.array_equal(obs, first_obs):
                    raise ValueError(
                        f"{spec.label} observations do not match {MODEL_SPECS[0].label}"
                    )
                source_summary_hash = _sha256(summary_path)
                source_metadata_hash = _sha256(metadata_path)
                source_paths.append((summary_path, source_summary_hash))
                source_paths.append((metadata_path, source_metadata_hash))
                source_paths.extend((Path(item["path"]), item["sha256"]) for item in inventory)
                validated.append(
                    (
                        spec,
                        attempt_root,
                        summary,
                        daily,
                        summary_path,
                        source_summary_hash,
                        metadata_path,
                        source_metadata_hash,
                        inventory,
                    )
                )

            staging_root.mkdir()
            artifact_records = []
            for (
                spec,
                attempt_root,
                summary,
                daily,
                summary_path,
                source_summary_hash,
                metadata_path,
                source_metadata_hash,
                inventory,
            ) in validated:
                model_dir = staging_root / spec.output_subdir
                model_dir.mkdir()
                output_summary = model_dir / "calibration_summary.csv"
                output_daily = model_dir / "daily_predictions.csv"
                source_inventory = model_dir / "source_inventory.json"
                summary.to_csv(output_summary, index=False)
                daily_to_write = daily.copy()
                daily_to_write["date"] = daily_to_write["date"].dt.strftime("%Y-%m-%d")
                daily_to_write.to_csv(output_daily, index=False)
                source_inventory.write_text(
                    json.dumps(
                        {
                            "summary": {
                                "path": str(summary_path.resolve()),
                                "sha256": source_summary_hash,
                            },
                            "metadata": {
                                "path": str(metadata_path.resolve()),
                                "sha256": source_metadata_hash,
                            },
                            "daily_files": inventory,
                        },
                        indent=2,
                        sort_keys=True,
                    ) + "\n",
                    encoding="utf-8",
                )
                for path in (output_summary, output_daily, source_inventory):
                    _make_read_only(path)
                final_model_dir = registered_root / spec.output_subdir
                artifact_records.append({
                    "model": spec.label,
                    "source_attempt_root": str(attempt_root),
                    "calibration_summary_path": str(final_model_dir / output_summary.name),
                    "calibration_summary_sha256": _sha256(output_summary),
                    "daily_predictions_path": str(final_model_dir / output_daily.name),
                    "daily_predictions_sha256": _sha256(output_daily),
                    "source_inventory_path": str(final_model_dir / source_inventory.name),
                    "source_inventory_sha256": _sha256(source_inventory),
                })
            staging_root.rename(registered_root)
            manifest = {
                "status": "completed",
                "experiment_id": EXPERIMENT_ID,
                "loss_protocol": LOSS_PROTOCOL,
                "calibration_settings": FIXED_CALIBRATION_SETTINGS,
                "protocol_manifest_path": str(protocol_manifest_path),
                "protocol_manifest_sha256": _sha256(protocol_manifest_path),
                "basin_count": len(expected_ids),
                "model_attempt_roots": {
                    spec.label: str(resolved_attempt_roots[spec.label]) for spec in MODEL_SPECS
                },
                "created_at_utc": datetime.now(timezone.utc).isoformat(),
                "artifacts": artifact_records,
            }
            temporary_manifest = conceptual_root / (
                f".{manifest_path.name}.tmp-{os.getpid()}-{time.time_ns()}"
            )
            temporary_manifest.write_text(
                json.dumps(manifest, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            temporary_manifest.replace(manifest_path)
            _make_read_only(manifest_path)

            from src.lstm_fair_531.scripts.analyze_identical_basin_nse_replication import (
                load_registered_conceptual_predictions,
            )

            registered_paths = [manifest_path]
            for record in artifact_records:
                registered_paths.extend([
                    Path(record["calibration_summary_path"]),
                    Path(record["daily_predictions_path"]),
                    Path(record["source_inventory_path"]),
                ])
            with _ArtifactStabilityGuard(
                registered_paths,
                directories=[registered_root],
            ):
                load_registered_conceptual_predictions(
                    manifest_path,
                    expected_basin_count=len(expected_ids),
                    expected_protocol_path=protocol_manifest_path,
                )
                for source_path, expected_hash in source_paths:
                    if _sha256(source_path) != expected_hash:
                        raise RuntimeError(
                            f"Conceptual source changed during registration: {source_path}"
                        )
                return manifest_path
    except BaseException:
        if manifest_path.exists():
            manifest_path.chmod(manifest_path.stat().st_mode | stat.S_IWRITE)
            manifest_path.unlink()
        if temporary_manifest is not None and temporary_manifest.exists():
            temporary_manifest.unlink()
        if registered_root.exists():
            _remove_tree(registered_root)
        _remove_tree(staging_root)
        if conceptual_root_was_created:
            conceptual_root.rmdir()
        raise


def publish_registered_conceptual_outputs(
    *,
    attempt_root: Path,
    conceptual_root: Path,
    protocol_manifest_path: Path,
    expected_basin_ids: Sequence[str],
) -> Path:
    """Publish three model outputs produced under one shared attempt root."""
    resolved_attempt_root = Path(attempt_root).resolve()
    return publish_registered_conceptual_outputs_from_model_roots(
        model_attempt_roots={spec.label: resolved_attempt_root for spec in MODEL_SPECS},
        conceptual_root=conceptual_root,
        protocol_manifest_path=protocol_manifest_path,
        expected_basin_ids=expected_basin_ids,
    )


def _write_json_atomic(path: Path, payload: dict) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = path.with_name(f".{path.name}.tmp-{os.getpid()}-{time.time_ns()}")
    try:
        temporary_path.write_text(
            json.dumps(payload, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        temporary_path.replace(path)
    finally:
        temporary_path.unlink(missing_ok=True)


class _UniqueModelSelection(argparse.Action):
    """Accept a model subset in frozen order and reject repeated labels."""

    def __call__(self, parser, namespace, values, option_string=None):
        try:
            selected = select_model_specs(list(values))
        except ValueError as error:
            parser.error(str(error))
            return
        setattr(namespace, self.dest, [spec.label for spec in selected])


def parse_model_attempt_roots(entries: Sequence[str] | None) -> dict[str, Path] | None:
    """Parse ``MODEL=PATH`` publication entries into one root per registered model."""
    if not entries:
        return None
    roots: dict[str, Path] = {}
    for entry in entries:
        label, separator, raw_path = str(entry).partition("=")
        if not separator or not label or not raw_path:
            raise ValueError(f"Model attempt root must look like MODEL=PATH, got {entry!r}")
        if label in roots:
            raise ValueError(f"Model attempt root repeats a model: {label}")
        roots[label] = Path(raw_path).resolve()
    missing = sorted(set(CONCEPTUAL_MODEL_LABELS) - set(roots))
    unknown = sorted(set(roots) - set(CONCEPTUAL_MODEL_LABELS))
    if missing or unknown:
        raise ValueError(
            "Model attempt roots must name exactly the registered conceptual models: "
            f"missing={missing}, unknown={unknown}"
        )
    return roots


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol-manifest", type=Path, default=_DEFAULT_PROTOCOL_PATH)
    parser.add_argument("--manifest", type=Path, default=None)
    parser.add_argument("--data-root", type=Path, default=None)
    parser.add_argument("--conceptual-root", type=Path, default=_DEFAULT_CONCEPTUAL_ROOT)
    parser.add_argument("--attempt-root", type=Path, default=_DEFAULT_ATTEMPT_ROOT)
    parser.add_argument("--log-root", type=Path, default=_DEFAULT_LOG_ROOT)
    parser.add_argument("--gr4j-workers", type=int, default=1)
    parser.add_argument("--xaj-workers", type=int, default=1)
    parser.add_argument("--hbv-lite-workers", type=int, default=2)
    parser.add_argument(
        "--models",
        nargs="+",
        action=_UniqueModelSelection,
        choices=list(CONCEPTUAL_MODEL_LABELS),
        default=list(CONCEPTUAL_MODEL_LABELS),
        help="Conceptual model arms to run; defaults to the frozen full set.",
    )
    parser.add_argument(
        "--model-attempt-root",
        action="append",
        default=None,
        metavar="MODEL=PATH",
        help="Attempt root for one model when publishing arms produced by separate runs.",
    )
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--run-all", action="store_true", default=False)
    mode.add_argument("--publish-existing-attempt", action="store_true", default=False)
    return parser


def _read_frozen_basin_ids(path: Path) -> list[str]:
    path = Path(path).resolve()
    basin_ids = [
        line.strip().zfill(8)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    normalized = _normalize_basin_ids(basin_ids).tolist()
    if len(normalized) != 531:
        raise ValueError(f"Conceptual replication requires exactly 531 basins, found {len(normalized)}")
    return normalized


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    from src.lstm_fair_531.scripts.run_identical_basin_nse_replication import (
        validate_protocol_manifest,
    )

    protocol_path = Path(args.protocol_manifest).resolve()
    protocol = validate_protocol_manifest(protocol_path)
    protocol_manifest_path = Path(protocol["basin_manifest_path"]).resolve()
    manifest_path = Path(args.manifest).resolve() if args.manifest is not None else protocol_manifest_path
    if manifest_path != protocol_manifest_path or _sha256(manifest_path) != protocol["basin_manifest_sha256"]:
        raise ValueError("Conceptual basin manifest does not match the passed common-loss protocol")
    expected_basin_ids = _read_frozen_basin_ids(manifest_path)
    protocol_data_root = Path(protocol["data_dir"]).resolve()
    data_root = Path(args.data_root).resolve() if args.data_root is not None else protocol_data_root
    if data_root != protocol_data_root:
        raise ValueError("Conceptual data root does not match the passed common-loss protocol")
    if not data_root.is_dir():
        raise FileNotFoundError(f"Conceptual data root does not exist: {data_root}")
    hbv_resource_policy = load_hbv_task_specific_resource_policy(
        _DEFAULT_HBV_RESOURCE_POLICY_PATH
    )
    if args.hbv_lite_workers != hbv_resource_policy["workers"]:
        raise ValueError(
            "HBV-lite worker count must match the reviewed task-specific resource policy"
        )

    attempt_root = Path(args.attempt_root).resolve()
    conceptual_root = Path(args.conceptual_root).resolve()
    log_root = Path(args.log_root).resolve()
    workers_by_model = {
        "GR4J": args.gr4j_workers,
        "XAJ": args.xaj_workers,
        "HBV-lite": args.hbv_lite_workers,
    }
    selected_labels = [spec.label for spec in select_model_specs(args.models)]
    model_attempt_roots = parse_model_attempt_roots(args.model_attempt_root)
    plans = build_execution_plans(
        manifest_path=manifest_path,
        data_root=data_root,
        attempt_root=attempt_root,
        log_root=log_root,
        python_executable=Path(sys.executable),
        workers_by_model=workers_by_model,
        pool_task_limits_by_model={
            "HBV-lite": int(hbv_resource_policy["pool_task_limit"]),
        },
        selected_labels=selected_labels,
    )

    if not args.run_all and not args.publish_existing_attempt:
        print(json.dumps({
            "mode": "prepare_only",
            "attempt_root": str(attempt_root),
            "conceptual_root": str(conceptual_root),
            "selected_models": selected_labels,
            "legacy_resource_thresholds_for_gr4j_and_xaj": CONCEPTUAL_RUNTIME_THRESHOLDS,
            "resource_policies": {"HBV-lite": hbv_resource_policy},
            "plans": plans,
        }, indent=2))
        return 0

    if args.publish_existing_attempt:
        if model_attempt_roots is None:
            publish_registered_conceptual_outputs(
                attempt_root=attempt_root,
                conceptual_root=conceptual_root,
                protocol_manifest_path=protocol_path,
                expected_basin_ids=expected_basin_ids,
            )
        else:
            publish_registered_conceptual_outputs_from_model_roots(
                model_attempt_roots=model_attempt_roots,
                conceptual_root=conceptual_root,
                protocol_manifest_path=protocol_path,
                expected_basin_ids=expected_basin_ids,
            )
        return 0

    runs_every_model = len(selected_labels) == len(MODEL_SPECS)
    if runs_every_model and attempt_root.exists():
        raise FileExistsError(
            f"Conceptual attempt root already exists; choose a new explicit path: {attempt_root}"
        )
    selected_specs = select_model_specs(selected_labels)
    for spec in selected_specs:
        model_output_root = attempt_root / spec.output_subdir
        if model_output_root.exists():
            raise FileExistsError(
                f"Conceptual output for {spec.label} already exists; choose a new explicit "
                f"attempt root: {model_output_root}"
            )
    for plan in plans:
        planned_log_path = Path(str(plan["log_path"]))
        if planned_log_path.exists():
            raise FileExistsError(
                f"Conceptual runner log for {plan['model']} already exists and would be "
                f"truncated; choose a new explicit log root: {planned_log_path}"
            )
    execution_state_path = attempt_root / model_state_file_name(selected_labels)
    if execution_state_path.exists():
        raise FileExistsError(
            f"Conceptual execution state already exists: {execution_state_path}"
        )
    evaluation_leakage_detector = _new_conceptual_selection_artifact_detector(
        conceptual_root=conceptual_root,
        attempt_root=attempt_root,
    )
    attempt_root.mkdir(parents=True, exist_ok=True)
    execution_state = {
        "status": "running",
        "experiment_id": EXPERIMENT_ID,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "protocol_manifest_path": str(protocol_path),
        "protocol_manifest_sha256": _sha256(protocol_path),
        "selected_models": selected_labels,
        "source_provenance": collect_conceptual_source_provenance(selected_specs),
        "calibration_settings": FIXED_CALIBRATION_SETTINGS,
        "legacy_resource_thresholds_for_gr4j_and_xaj": CONCEPTUAL_RUNTIME_THRESHOLDS,
        "resource_policies": {"HBV-lite": hbv_resource_policy},
        "plans": plans,
    }
    _write_json_atomic(execution_state_path, execution_state)
    resource_log_path = log_root / "resources.csv"
    try:
        run_conceptual_model_sequence(
            plans,
            execute=lambda plan: execute_monitored_runner(
                plan["command"],
                workspace=_REPOSITORY_ROOT,
                log_path=Path(plan["log_path"]),
                resource_log_path=resource_log_path,
                model_label=str(plan["model"]),
                resource_policy=(
                    hbv_resource_policy if plan["model"] == "HBV-lite" else None
                ),
                evaluation_leakage_detector=evaluation_leakage_detector,
            ),
        )
        execution_state.update({
            "status": "completed",
            "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        })
        if runs_every_model:
            manifest_output = publish_registered_conceptual_outputs(
                attempt_root=attempt_root,
                conceptual_root=conceptual_root,
                protocol_manifest_path=protocol_path,
                expected_basin_ids=expected_basin_ids,
            )
            execution_state.update({
                "conceptual_prediction_manifest_path": str(manifest_output),
                "conceptual_prediction_manifest_sha256": _sha256(manifest_output),
            })
        _write_json_atomic(execution_state_path, execution_state)
        return 0
    except BaseException as error:
        execution_state.update({
            "status": "failed",
            "failed_at_utc": datetime.now(timezone.utc).isoformat(),
            "error": f"{type(error).__name__}: {error}",
        })
        _write_json_atomic(execution_state_path, execution_state)
        raise


if __name__ == "__main__":
    raise SystemExit(main())
