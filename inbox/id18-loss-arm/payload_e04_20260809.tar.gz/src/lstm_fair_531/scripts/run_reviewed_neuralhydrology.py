"""Launch neuralhydrology from this reviewed repository."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def _repository_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _resolved_module_file(module, module_name: str) -> Path:
    actual_file = getattr(module, "__file__", None)
    if actual_file is None:
        raise RuntimeError(
            f"Cached {module_name} must have a verifiable file origin in the reviewed neuralhydrology package "
            "under the reviewed repository root"
        )
    try:
        actual_path = Path(actual_file).resolve(strict=True)
    except (OSError, TypeError, ValueError) as error:
        raise RuntimeError(
            f"Cached {module_name} must have a verifiable file origin in the reviewed neuralhydrology package "
            "under the reviewed repository root: "
            f"got {actual_file!r}"
        ) from error
    if not actual_path.is_file():
        raise RuntimeError(
            f"Cached {module_name} must have a verifiable file origin in the reviewed neuralhydrology package "
            "under the reviewed repository root: "
            f"got {actual_path}"
        )
    return actual_path


def _assert_module_origin(module, expected_path: Path, module_name: str) -> None:
    actual_path = _resolved_module_file(module, module_name)
    expected_path = Path(expected_path).resolve(strict=True)
    if actual_path != expected_path:
        raise RuntimeError(
            f"{module_name} must resolve from the reviewed neuralhydrology package under the reviewed repository root: "
            f"expected {expected_path}, got {actual_path}"
        )


def _assert_reviewed_neuralhydrology_cache(repository_root: Path) -> None:
    reviewed_package_root = (Path(repository_root) / "neuralhydrology").resolve(strict=True)
    for module_name, module in sorted(sys.modules.items()):
        if module_name != "neuralhydrology" and not module_name.startswith("neuralhydrology."):
            continue
        actual_path = _resolved_module_file(module, module_name)
        try:
            actual_path.relative_to(reviewed_package_root)
        except ValueError as error:
            raise RuntimeError(
                f"Cached {module_name} must resolve from the reviewed neuralhydrology package "
                "under the reviewed repository root: "
                f"expected a file under {reviewed_package_root}, got {actual_path}"
            ) from error


def _load_reviewed_neuralhydrology():
    repository_root = _repository_root()
    repository_root_text = str(repository_root)
    sys.path = [path for path in sys.path if path != repository_root_text]
    sys.path.insert(0, repository_root_text)
    _assert_reviewed_neuralhydrology_cache(repository_root)
    import neuralhydrology
    from neuralhydrology import nh_run

    _assert_reviewed_neuralhydrology_cache(repository_root)
    _assert_module_origin(
        neuralhydrology,
        repository_root / "neuralhydrology" / "__init__.py",
        "neuralhydrology",
    )
    _assert_module_origin(
        nh_run,
        repository_root / "neuralhydrology" / "nh_run.py",
        "neuralhydrology.nh_run",
    )
    return repository_root, neuralhydrology, nh_run


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--import-only", action="store_true")
    arguments, nh_run_arguments = parser.parse_known_args(argv)
    repository_root, neuralhydrology, nh_run = _load_reviewed_neuralhydrology()
    if arguments.import_only:
        if nh_run_arguments:
            parser.error("--import-only does not accept neuralhydrology arguments")
        print(
            json.dumps({
                "repository_root": str(repository_root),
                "neuralhydrology_init": str(Path(neuralhydrology.__file__).resolve()),
                "neuralhydrology_nh_run": str(Path(nh_run.__file__).resolve()),
            })
        )
        return 0

    original_argv = sys.argv
    try:
        sys.argv = [str(Path(__file__).resolve()), *nh_run_arguments]
        result = nh_run._main()
    finally:
        sys.argv = original_argv
    return 0 if result is None else int(result)


if __name__ == "__main__":
    raise SystemExit(main())
