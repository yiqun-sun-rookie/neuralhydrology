"""Run registered hydrological process diagnostics on the 531-basin benchmark."""
from __future__ import annotations

import argparse
import gc
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

from src.lstm_fair_531.scripts.analyze_identical_basin_nse_replication import FIXED_SEEDS
from src.lstm_fair_531.scripts.hydrological_process_diagnostics import (
    assign_flow_groups,
    compute_event_metrics,
    evaluate_diagnostic_gates,
    flow_duration_curve_bias,
    identify_observed_events,
    relative_signed_bias,
    standard_deviation_ratio,
    summarize_bias_rows,
    summarize_event_rows,
)
from src.lstm_fair_531.scripts.run_context_scale_threshold_robustness import (
    DEFAULT_CONCEPTUAL_MANIFEST,
    DEFAULT_REGIMES,
    DEFAULT_RUN_LEDGER,
    REPO_ROOT,
    _available_gib,
    _current_rss_gib,
    _load_neural_ensemble_low_memory,
    _load_regimes,
    _normalize_basin_id,
    _sha256,
    _source,
)


EXPERIMENT_ID = "D09_hydrological_process_diagnostics_20260726"
DEFAULT_OUTPUT_DIR = REPO_ROOT / "results/18_lstm_fair_531" / EXPERIMENT_ID
DEFAULT_CONFIG = REPO_ROOT / "src/lstm_fair_531/configs/hydrological_process_diagnostics_20260726.json"
DEFAULT_REGISTERED_Q10 = REPO_ROOT / (
    "results/18_lstm_fair_531/D07_context_scale_threshold_robustness_20260726/"
    "thresholds/q10_q90/flow_context_delta.csv"
)
EXPECTED_OUTPUTS = (
    "basin_model_bias_audit.csv",
    "regime_model_bias_summary.csv",
    "event_model_diagnostics_q90.csv",
    "event_model_diagnostics_q95.csv",
    "regime_season_event_summary.csv",
    "diagnostic_decision_gates.json",
    "D09_manifest.json",
)
FIXED_MODELS = ("LSTM", "GR4J", "Xinanjiang", "HBV-lite")
SOURCE_CONCEPTUAL_MODELS = ("GR4J", "XAJ", "HBV-lite")
MODEL_NAME_MAP = {"GR4J": "GR4J", "XAJ": "Xinanjiang", "HBV-lite": "HBV-lite"}


def _load_json(path: Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _validate_config(path: Path) -> dict:
    config = _load_json(path)
    if config.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("D09 configuration experiment identifier mismatch")
    if tuple(config.get("models", [])) != FIXED_MODELS:
        raise ValueError(f"D09 models must be exactly {FIXED_MODELS}")
    if int(config.get("basin_count", 0)) != 531:
        raise ValueError("D09 configuration must retain all 531 basins")
    if (config.get("evaluation_start"), config.get("evaluation_end")) != ("1989-10-01", "1999-09-30"):
        raise ValueError("D09 evaluation dates drifted")
    flow_quantiles = config.get("flow_quantiles", {})
    if (float(flow_quantiles.get("low", -1)), float(flow_quantiles.get("high", -1))) != (0.1, 0.9):
        raise ValueError("D09 flow quantiles must be exactly 0.1 and 0.9")
    if tuple(float(value) for value in config.get("event_threshold_quantiles", [])) != (0.9, 0.95):
        raise ValueError("D09 event threshold quantiles must be exactly 0.9 and 0.95")
    event_definition = config.get("event_definition", {})
    if (
            int(event_definition.get("merge_gap_days", -1)),
            int(event_definition.get("minimum_peak_separation_days", -1)),
            int(event_definition.get("half_window_days", -1)),
    ) != (2, 5, 3):
        raise ValueError("D09 event definition drifted")
    bootstrap = config.get("bootstrap", {})
    if (
            bootstrap.get("unit"),
            int(bootstrap.get("resamples", 0)),
            int(bootstrap.get("seed", -1)),
            float(bootstrap.get("confidence_level", 0)),
    ) != ("whole_basin", 10_000, 20260726, 0.95):
        raise ValueError("D09 bootstrap contract drifted")
    if float(config.get("minimum_available_memory_gib", 0)) != 4.0:
        raise ValueError("D09 memory floor must be exactly 4.0 GiB")
    if float(config.get("volume_bias_tolerance", -1)) != 0.05:
        raise ValueError("D09 volume-bias tolerance must be exactly 0.05")
    if float(config.get("flow_duration_curve_upper_tail_fraction", -1)) != 0.1:
        raise ValueError("D09 flow-duration-curve tail fraction must be exactly 0.1")
    if float(config.get("registered_q10_q90_crosscheck_tolerance", -1)) != 1e-10:
        raise ValueError("D09 registered cross-check tolerance must be exactly 1e-10")
    return config


def _validate_registry_contracts(ledger: dict, conceptual_manifest: dict) -> None:
    seeds = tuple(int(record.get("seed", -1)) for record in ledger.get("output_records", []))
    if ledger.get("status") != "completed" or seeds != FIXED_SEEDS:
        raise ValueError(f"D09 requires the eight fixed neural seeds {FIXED_SEEDS}")
    conceptual_models = tuple(item.get("model") for item in conceptual_manifest.get("artifacts", []))
    if (
            conceptual_manifest.get("status") != "completed"
            or int(conceptual_manifest.get("basin_count", 0)) != 531
            or set(conceptual_models) != set(SOURCE_CONCEPTUAL_MODELS)
            or len(conceptual_models) != 3
    ):
        raise ValueError(f"D09 requires exactly the three conceptual artifacts {SOURCE_CONCEPTUAL_MODELS}")


def _relative_to_root(path: Path, root: Path) -> str:
    resolved = Path(path).resolve()
    try:
        return resolved.relative_to(Path(root).resolve()).as_posix()
    except ValueError as error:
        raise ValueError(f"Artifact lies outside the declared root: {resolved}") from error


def _verify_sources_unchanged(sources: list[dict], *, repo_root: Path = REPO_ROOT) -> list[dict]:
    verified = []
    for source in sources:
        record = dict(source)
        path = Path(record["path"])
        if not path.is_absolute():
            path = Path(repo_root) / path
        after = _sha256(path)
        if after != record["sha256"]:
            raise ValueError(f"Registered input changed while being read: {record['role']}")
        record["sha256_after_read"] = after
        record["verified_unchanged"] = True
        verified.append(record)
    return verified


def _output_record(path: Path, *, repo_root: Path) -> dict:
    return {
        "path": _relative_to_root(path, repo_root),
        "bytes": Path(path).stat().st_size,
        "sha256": _sha256(path),
    }


def _build_manifest(
    *,
    config: dict,
    output_paths: list[Path],
    sources: list[dict],
    gates: dict,
    started_at_utc: str,
    runtime_seconds: float,
    available_before: float,
    available_after: float,
    peak_rss: float,
    repo_root: Path = REPO_ROOT,
    analysis_code_paths: list[Path] | None = None,
    exact_command: str = (
        "python -X utf8 -m src.lstm_fair_531.scripts.run_hydrological_process_diagnostics"
    ),
) -> dict:
    code_paths = analysis_code_paths if analysis_code_paths is not None else [
        Path(__file__),
        REPO_ROOT / "src/lstm_fair_531/scripts/hydrological_process_diagnostics.py",
    ]
    return {
        "schema_version": "1.0",
        "experiment_id": EXPERIMENT_ID,
        "status": "completed",
        "purpose": config["purpose"],
        "models": config["models"],
        "basin_count": 531,
        "contains_basin_04213075": True,
        "evaluation_start": config["evaluation_start"],
        "evaluation_end": config["evaluation_end"],
        "flow_quantiles": config["flow_quantiles"],
        "event_threshold_quantiles": config["event_threshold_quantiles"],
        "event_definition": config["event_definition"],
        "bootstrap": config["bootstrap"],
        "exact_command": exact_command,
        "working_directory": ".",
        "loader_mode": "eight_seed_accumulator_then_one_conceptual_csv_at_a_time",
        "mandatory_stages": ["bias_definition_audit", "observed_event_peak_diagnosis"],
        "conditional_branches_executed": [],
        "conditional_branch_status": "not_executed_in_mandatory_run",
        "inputs": sources,
        "analysis_code": [
            {"path": _relative_to_root(path, repo_root), "sha256": _sha256(path)} for path in code_paths
        ],
        "outputs": [_output_record(path, repo_root=repo_root) for path in sorted(output_paths)],
        "diagnostic_gates": gates,
        "started_at_utc": started_at_utc,
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "runtime_seconds": float(runtime_seconds),
        "available_memory_gib_before": float(available_before),
        "available_memory_gib_after": float(available_after),
        "peak_process_rss_gib_observed": float(peak_rss),
    }


def _verify_registered_q10_mae(audit: pd.DataFrame, registered: pd.DataFrame, *, tolerance: float) -> int:
    required_audit = {"basin_id", "model", "mae_low", "mae_mid", "mae_high"}
    required_registered = {"basin_id", "flow_group", "conceptual_model", "conceptual_mae", "lstm_mae"}
    if not required_audit.issubset(audit.columns) or not required_registered.issubset(registered.columns):
        raise ValueError("registered q10/q90 MAE cross-check columns are missing")
    audit_indexed = audit.copy()
    audit_indexed["basin_id"] = audit_indexed["basin_id"].map(_normalize_basin_id)
    if audit_indexed.duplicated(["basin_id", "model"]).any():
        raise ValueError("D09 audit has duplicate basin-model rows")
    audit_indexed = audit_indexed.set_index(["basin_id", "model"])
    registered_work = registered.copy()
    registered_work["basin_id"] = registered_work["basin_id"].map(_normalize_basin_id)
    registered_work["conceptual_model"] = registered_work["conceptual_model"].replace({
        "XAJ": "Xinanjiang",
        "HBV": "HBV-lite",
    })
    checked = 0
    for row in registered_work.itertuples(index=False):
        flow_group = str(row.flow_group)
        column = f"mae_{flow_group}"
        key = (row.basin_id, row.conceptual_model)
        neural_key = (row.basin_id, "LSTM")
        if (
                column not in audit_indexed.columns
                or key not in audit_indexed.index
                or neural_key not in audit_indexed.index
        ):
            raise ValueError(f"registered q10/q90 MAE row is missing from D09: {key}, {flow_group}")
        conceptual_actual = float(audit_indexed.loc[key, column])
        neural_actual = float(audit_indexed.loc[neural_key, column])
        if (
                abs(conceptual_actual - float(row.conceptual_mae)) > tolerance
                or abs(neural_actual - float(row.lstm_mae)) > tolerance
        ):
            raise ValueError(f"registered q10/q90 MAE mismatch for {key}, {flow_group}")
        checked += 1
    return checked


def _require_complete_registered_crosscheck(checked: int, registered: pd.DataFrame) -> None:
    expected = int(len(registered))
    if checked != expected:
        raise ValueError(f"D09 expected {expected} registered MAE rows; verified {checked}")


def _season_names(dates: pd.DatetimeIndex) -> np.ndarray:
    months = dates.month.to_numpy()
    return np.select(
        [np.isin(months, [12, 1, 2]), np.isin(months, [3, 4, 5]), np.isin(months, [6, 7, 8])],
        ["winter", "spring", "summer"],
        default="autumn",
    )


def _analyze_basin_model(
    *,
    basin_id: str,
    regime: str,
    model: str,
    dates: pd.DatetimeIndex,
    obs: np.ndarray,
    sim: np.ndarray,
    config: dict,
) -> tuple[dict, dict[float, pd.DataFrame]]:
    dates = pd.DatetimeIndex(dates)
    obs = np.asarray(obs, dtype=float)
    sim = np.asarray(sim, dtype=float)
    if len({len(dates), len(obs), len(sim)}) != 1 or obs.size == 0:
        raise ValueError(f"{model}, basin {basin_id} has unaligned or empty daily arrays")
    if not np.isfinite(np.column_stack([obs, sim])).all():
        raise ValueError(f"{model}, basin {basin_id} has non-finite daily values")
    if dates.size > 1:
        intervals = np.diff(dates.values.astype("datetime64[D]")).astype(int)
        if not np.all(intervals == 1):
            raise ValueError(f"{model}, basin {basin_id} does not have a continuous daily valid period")

    low_quantile = float(config["flow_quantiles"]["low"])
    high_quantile = float(config["flow_quantiles"]["high"])
    flow_groups = assign_flow_groups(obs, low_quantile=low_quantile, high_quantile=high_quantile)
    audit_row = {
        "basin_id": _normalize_basin_id(basin_id),
        "regime": str(regime),
        "model": model,
        "evaluation_day_count": int(obs.size),
        "flow_duration_curve_bias": flow_duration_curve_bias(
            obs,
            sim,
            upper_tail_fraction=float(config["flow_duration_curve_upper_tail_fraction"]),
        ),
        "standard_deviation_ratio": standard_deviation_ratio(obs, sim),
    }
    for flow_group in ("low", "mid", "high"):
        selected = flow_groups == flow_group
        selected_count = int(selected.sum())
        audit_row[f"n_days_{flow_group}"] = selected_count
        if selected_count == 0:
            audit_row[f"same_date_signed_bias_{flow_group}"] = np.nan
            audit_row[f"mae_{flow_group}"] = np.nan
        else:
            audit_row[f"same_date_signed_bias_{flow_group}"] = relative_signed_bias(obs[selected], sim[selected])
            audit_row[f"mae_{flow_group}"] = float(np.mean(np.abs(sim[selected] - obs[selected])))

    event_frames = {}
    event_definition = config["event_definition"]
    for threshold_quantile in config["event_threshold_quantiles"]:
        threshold_quantile = float(threshold_quantile)
        threshold = float(np.quantile(obs, threshold_quantile))
        events = identify_observed_events(
            dates,
            obs,
            threshold=threshold,
            merge_gap_days=int(event_definition["merge_gap_days"]),
            minimum_peak_separation_days=int(event_definition["minimum_peak_separation_days"]),
            half_window_days=int(event_definition["half_window_days"]),
        )
        metrics = compute_event_metrics(dates, obs, sim, events)
        context_columns = [
            "event_id", "start_date", "end_date", "peak_date", "window_start", "window_end"
        ]
        metrics = metrics.merge(events[context_columns], on="event_id", how="left", validate="one_to_one")
        metrics.insert(0, "event_threshold_quantile", threshold_quantile)
        metrics.insert(0, "model", model)
        metrics.insert(0, "season", _season_names(pd.DatetimeIndex(metrics["observed_peak_date"])))
        metrics.insert(0, "regime", str(regime))
        metrics.insert(0, "basin_id", _normalize_basin_id(basin_id))
        event_frames[threshold_quantile] = metrics
    return audit_row, event_frames


def _analyze_neural_ensemble(
    ensemble: dict,
    *,
    regime_map: dict[str, str],
    config: dict,
) -> tuple[pd.DataFrame, dict[float, pd.DataFrame]]:
    audit_rows = []
    event_frames = {0.9: [], 0.95: []}
    for basin_id in sorted(ensemble):
        record = ensemble[basin_id]
        audit_row, basin_events = _analyze_basin_model(
            basin_id=basin_id,
            regime=regime_map[basin_id],
            model="LSTM",
            dates=record["dates"],
            obs=record["obs"],
            sim=record["sim"],
            config=config,
        )
        audit_rows.append(audit_row)
        for threshold_quantile, frame in basin_events.items():
            event_frames[threshold_quantile].append(frame)
    return pd.DataFrame(audit_rows), {
        threshold: pd.concat(frames, ignore_index=True) for threshold, frames in event_frames.items()
    }


def _analyze_conceptual_predictions(
    *,
    ensemble: dict,
    conceptual_manifest_path: Path,
    regime_map: dict[str, str],
    config: dict,
) -> tuple[pd.DataFrame, dict[float, pd.DataFrame], list[dict], float]:
    manifest = _load_json(conceptual_manifest_path)
    sources = [_source("conceptual_prediction_manifest", conceptual_manifest_path)]
    protocol_path = Path(manifest["protocol_manifest_path"])
    sources.append(_source(
        "conceptual_common_loss_protocol",
        protocol_path,
        str(manifest["protocol_manifest_sha256"]),
    ))
    expected_rows = sum(len(record["obs"]) for record in ensemble.values())
    audit_frames = []
    event_frames = {0.9: [], 0.95: []}
    peak_rss = _current_rss_gib()
    artifacts = sorted(manifest["artifacts"], key=lambda item: SOURCE_CONCEPTUAL_MODELS.index(item["model"]))
    for artifact in artifacts:
        source_model = str(artifact["model"])
        model = MODEL_NAME_MAP[source_model]
        path = Path(artifact["daily_predictions_path"])
        expected_hash = str(artifact["daily_predictions_sha256"])
        sources.append(_source(f"conceptual_{source_model}_daily_predictions", path, expected_hash))
        daily = pd.read_csv(path, dtype={"basin_id": str}, parse_dates=["date"])
        daily["basin_id"] = daily["basin_id"].map(_normalize_basin_id)
        if len(daily) != expected_rows or daily["basin_id"].nunique() != 531:
            raise ValueError(f"{model} daily artifact does not match the registered 531-basin valid-day population")
        if daily.duplicated(["basin_id", "date"]).any():
            raise ValueError(f"{model} daily artifact has duplicate basin-date rows")
        model_audit_rows = []
        for basin_id, group in daily.groupby("basin_id", sort=True):
            group = group.sort_values("date").reset_index(drop=True)
            neural = ensemble[basin_id]
            dates = pd.DatetimeIndex(group["date"])
            if not dates.equals(neural["dates"]):
                raise ValueError(f"{model}, basin {basin_id} date mask differs from the neural ensemble")
            observation = group["obs"].to_numpy(dtype=float)
            if not np.allclose(observation, neural["obs"], rtol=1e-5, atol=1e-4):
                raise ValueError(f"{model}, basin {basin_id} observations differ from the neural ensemble")
            simulation = group["sim"].to_numpy(dtype=float)
            audit_row, basin_events = _analyze_basin_model(
                basin_id=basin_id,
                regime=regime_map[basin_id],
                model=model,
                dates=dates,
                obs=neural["obs"],
                sim=simulation,
                config=config,
            )
            model_audit_rows.append(audit_row)
            for threshold_quantile, frame in basin_events.items():
                event_frames[threshold_quantile].append(frame)
        if _sha256(path) != expected_hash:
            raise ValueError(f"{model} daily artifact changed while being read")
        audit_frames.append(pd.DataFrame(model_audit_rows))
        peak_rss = max(peak_rss, _current_rss_gib())
        del daily
        gc.collect()
    return (
        pd.concat(audit_frames, ignore_index=True),
        {threshold: pd.concat(frames, ignore_index=True) for threshold, frames in event_frames.items()},
        sources,
        peak_rss,
    )


def _build_bias_summary(audit: pd.DataFrame, *, config: dict) -> pd.DataFrame:
    bootstrap = config["bootstrap"]
    summary_frames = []
    for flow_group in ("low", "mid", "high"):
        work = audit[["basin_id", "regime", "model", f"same_date_signed_bias_{flow_group}"]].rename(
            columns={f"same_date_signed_bias_{flow_group}": "value"}
        )
        work["flow_group"] = flow_group
        summary = summarize_bias_rows(
            work,
            value_columns=["value"],
            n_resamples=int(bootstrap["resamples"]),
            seed=int(bootstrap["seed"]),
        )
        summary["diagnostic"] = "same_date_signed_bias"
        summary["reference_value"] = 0.0
        summary_frames.append(summary)

    for diagnostic, flow_group, column, reference in [
            ("flow_duration_curve_bias", "upper_tail", "flow_duration_curve_bias", 0.0),
            ("standard_deviation_ratio", "full_period", "standard_deviation_ratio", 1.0),
    ]:
        work = audit[["basin_id", "regime", "model", column]].rename(columns={column: "value"})
        if reference == 1.0:
            work["value"] = work["value"] - 1.0
        work["flow_group"] = flow_group
        summary = summarize_bias_rows(
            work,
            value_columns=["value"],
            n_resamples=int(bootstrap["resamples"]),
            seed=int(bootstrap["seed"]),
        )
        if reference == 1.0:
            for result_column in ("median", "ci_lower", "ci_upper"):
                summary[result_column] = summary[result_column] + 1.0
        summary["diagnostic"] = diagnostic
        summary["reference_value"] = reference
        summary_frames.append(summary)
    combined = pd.concat(summary_frames, ignore_index=True)
    combined = combined.rename(columns={"fraction_below_zero": "fraction_below_reference"})
    return combined.drop(columns=["metric"])


def _build_event_summary(event_rows: pd.DataFrame, *, config: dict) -> pd.DataFrame:
    bootstrap = config["bootstrap"]
    return summarize_event_rows(
        event_rows,
        value_columns=[
            "same_date_peak_bias",
            "aligned_peak_magnitude_bias",
            "peak_timing_error_days",
            "absolute_peak_timing_error_days",
            "seven_day_volume_bias",
        ],
        n_resamples=int(bootstrap["resamples"]),
        seed=int(bootstrap["seed"]),
    )


def run(
    *,
    output_dir: Path = DEFAULT_OUTPUT_DIR,
    config_path: Path = DEFAULT_CONFIG,
    run_ledger_path: Path = DEFAULT_RUN_LEDGER,
    conceptual_manifest_path: Path = DEFAULT_CONCEPTUAL_MANIFEST,
    regimes_path: Path = DEFAULT_REGIMES,
    registered_q10_path: Path = DEFAULT_REGISTERED_Q10,
    exact_command: str | None = None,
) -> dict:
    started = time.perf_counter()
    started_at_utc = datetime.now(timezone.utc).isoformat()
    available_before = _available_gib()
    if available_before < 4.0:
        raise MemoryError(f"D09 requires at least 4.0 GiB available; found {available_before:.2f} GiB")
    output_dir = Path(output_dir)
    if exact_command is None:
        command_parts = [
            "python",
            "-X",
            "utf8",
            "-m",
            "src.lstm_fair_531.scripts.run_hydrological_process_diagnostics",
        ]
        if output_dir != DEFAULT_OUTPUT_DIR:
            command_parts.extend(["--output-dir", str(output_dir)])
        exact_command = subprocess.list2cmdline(command_parts)
    if output_dir.exists():
        raise FileExistsError(f"D09 refuses to overwrite an existing output directory: {output_dir}")

    config = _validate_config(config_path)
    ledger = _load_json(run_ledger_path)
    conceptual_manifest = _load_json(conceptual_manifest_path)
    _validate_registry_contracts(ledger, conceptual_manifest)
    regimes = _load_regimes(regimes_path)
    regime_map = regimes.set_index("basin_id")["regime"].to_dict()
    output_dir.mkdir(parents=True)
    peak_rss = _current_rss_gib()

    ensemble, neural_sources = _load_neural_ensemble_low_memory(run_ledger_path)
    peak_rss = max(peak_rss, _current_rss_gib())
    neural_audit, neural_events = _analyze_neural_ensemble(
        ensemble,
        regime_map=regime_map,
        config=config,
    )
    conceptual_audit, conceptual_events, conceptual_sources, conceptual_peak_rss = _analyze_conceptual_predictions(
        ensemble=ensemble,
        conceptual_manifest_path=conceptual_manifest_path,
        regime_map=regime_map,
        config=config,
    )
    peak_rss = max(peak_rss, conceptual_peak_rss, _current_rss_gib())
    del ensemble
    gc.collect()

    audit = pd.concat([neural_audit, conceptual_audit], ignore_index=True)
    if (
            len(audit) != 531 * 4
            or audit["basin_id"].nunique() != 531
            or set(audit["model"]) != set(FIXED_MODELS)
            or "04213075" not in set(audit["basin_id"])
    ):
        raise ValueError("D09 mandatory audit does not contain all four models over the frozen 531 basins")
    events_by_threshold = {
        threshold: pd.concat([neural_events[threshold], conceptual_events[threshold]], ignore_index=True)
        for threshold in (0.9, 0.95)
    }

    registered = pd.read_csv(registered_q10_path, dtype={"basin_id": str})
    verified_mae_rows = _verify_registered_q10_mae(
        audit,
        registered,
        tolerance=float(config["registered_q10_q90_crosscheck_tolerance"]),
    )
    _require_complete_registered_crosscheck(verified_mae_rows, registered)

    bias_summary = _build_bias_summary(audit, config=config)
    all_events = pd.concat([events_by_threshold[0.9], events_by_threshold[0.95]], ignore_index=True)
    event_summary = _build_event_summary(all_events, config=config)
    gates = evaluate_diagnostic_gates(
        events_by_threshold[0.9],
        volume_bias_tolerance=float(config["volume_bias_tolerance"]),
        n_resamples=int(config["bootstrap"]["resamples"]),
        seed=int(config["bootstrap"]["seed"]),
    )
    peak_rss = max(peak_rss, _current_rss_gib())

    output_paths = [
        output_dir / EXPECTED_OUTPUTS[0],
        output_dir / EXPECTED_OUTPUTS[1],
        output_dir / EXPECTED_OUTPUTS[2],
        output_dir / EXPECTED_OUTPUTS[3],
        output_dir / EXPECTED_OUTPUTS[4],
        output_dir / EXPECTED_OUTPUTS[5],
    ]
    audit.to_csv(output_paths[0], index=False)
    bias_summary.to_csv(output_paths[1], index=False)
    events_by_threshold[0.9].to_csv(output_paths[2], index=False)
    events_by_threshold[0.95].to_csv(output_paths[3], index=False)
    event_summary.to_csv(output_paths[4], index=False)
    output_paths[5].write_text(json.dumps(gates, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    sources = [
        _source("d09_configuration", config_path),
        _source("frozen_basin_regimes", regimes_path),
        *neural_sources,
        *conceptual_sources,
        _source("registered_q10_q90_flow_context_delta", registered_q10_path),
    ]
    verified_sources = _verify_sources_unchanged(sources)
    manifest = _build_manifest(
        config=config,
        output_paths=output_paths,
        sources=verified_sources,
        gates=gates,
        started_at_utc=started_at_utc,
        runtime_seconds=time.perf_counter() - started,
        available_before=available_before,
        available_after=_available_gib(),
        peak_rss=peak_rss,
        exact_command=exact_command,
    )
    manifest["registered_q10_q90_mae_rows_verified"] = verified_mae_rows
    manifest["input_hash_verification"] = "all_before_and_after_hashes_match"
    manifest["event_counts"] = {
        "q90": int(len(events_by_threshold[0.9])),
        "q95": int(len(events_by_threshold[0.95])),
    }
    manifest_path = output_dir / EXPECTED_OUTPUTS[6]
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return manifest


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--run-ledger", type=Path, default=DEFAULT_RUN_LEDGER)
    parser.add_argument("--conceptual-manifest", type=Path, default=DEFAULT_CONCEPTUAL_MANIFEST)
    parser.add_argument("--regimes", type=Path, default=DEFAULT_REGIMES)
    parser.add_argument("--registered-q10", type=Path, default=DEFAULT_REGISTERED_Q10)
    return parser


def main(argv: list[str] | None = None) -> int:
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    args = _parser().parse_args(raw_argv)
    exact_command = subprocess.list2cmdline([
        "python",
        "-X",
        "utf8",
        "-m",
        "src.lstm_fair_531.scripts.run_hydrological_process_diagnostics",
        *raw_argv,
    ])
    manifest = run(
        output_dir=args.output_dir,
        config_path=args.config,
        run_ledger_path=args.run_ledger,
        conceptual_manifest_path=args.conceptual_manifest,
        regimes_path=args.regimes,
        registered_q10_path=args.registered_q10,
        exact_command=exact_command,
    )
    print(json.dumps({
        "experiment_id": manifest["experiment_id"],
        "status": manifest["status"],
        "runtime_seconds": manifest["runtime_seconds"],
        "peak_process_rss_gib_observed": manifest["peak_process_rss_gib_observed"],
        "diagnostic_gates": manifest["diagnostic_gates"],
    }, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
