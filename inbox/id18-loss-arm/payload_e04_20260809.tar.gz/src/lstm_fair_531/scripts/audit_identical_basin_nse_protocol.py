"""Audit the identical basin-averaged one-minus-NSE protocol before training."""

from __future__ import annotations

import argparse
from collections.abc import Sequence
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys
import time

import numpy as np
import pandas as pd
import psutil
import torch
import yaml

from neuralhydrology.datautils.utils import load_scaler
from neuralhydrology.datasetzoo import get_dataset
from neuralhydrology.datasetzoo.camelsus import (convert_discharge_to_mm_per_day, load_camels_us_discharge,
                                                 load_camels_us_forcings)
from neuralhydrology.training import get_loss_obj
from neuralhydrology.utils.config import Config
from src.hydroagent.data_loading import load_camels_basin


PUBLIC_TARGET_START = pd.Timestamp("2000-09-30")
PUBLIC_TARGET_END = pd.Timestamp("2008-09-30")
EXPECTED_BASIN_COUNT = 531
DENOMINATOR_TOLERANCE = 1e-10
WEIGHT_TOLERANCE = 1e-10
SINGLE_PRECISION_LOSS_TOLERANCE = 1e-6
TARGET_STATISTIC_TOLERANCE = 1e-12
SOURCE_FILES_FOR_AUDIT = (
    "neuralhydrology/datautils/utils.py",
    "neuralhydrology/datasetzoo/basedataset.py",
    "neuralhydrology/datasetzoo/camelsus.py",
    "neuralhydrology/training/__init__.py",
    "neuralhydrology/training/loss.py",
    "src/hydroagent/data_loading.py",
    "src/lstm_fair_531/common_basin_nse.py",
    "src/lstm_fair_531/scripts/audit_identical_basin_nse_protocol.py",
    "src/scl_hydro/hbv_lite_cma_calibrate.py",
    "src/xaj_global_pilot/xaj_model.py",
)
PACKAGE_DISTRIBUTIONS_FOR_AUDIT = (
    "torch",
    "numpy",
    "pandas",
    "xarray",
    "PyYAML",
    "ruamel.yaml",
    "scipy",
    "numba",
    "psutil",
    "neuralhydrology",
)


class ProtocolAuditError(ValueError):
    """Raised when two training paths do not implement the same public protocol."""


def load_runtime_config(config_path: Path, data_dir: Path, train_dir: Path) -> Config:
    """Load a frozen configuration with explicit local paths without modifying the source file."""
    config_path = Path(config_path)
    raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    raw["data_dir"] = str(Path(data_dir).resolve())
    cfg = Config(raw)
    train_path = Path(train_dir).resolve()
    train_path.mkdir(parents=True, exist_ok=True)
    cfg.train_dir = train_path
    return cfg


def date_sha256(dates: Sequence[pd.Timestamp] | pd.DatetimeIndex) -> str:
    """Hash an ordered daily target-date sequence in a platform-independent representation."""
    index = pd.DatetimeIndex(pd.to_datetime(dates))
    payload = "\n".join(index.strftime("%Y-%m-%d")).encode("ascii")
    return hashlib.sha256(payload).hexdigest()


def _finite_series(series: pd.Series, name: str) -> pd.Series:
    values = pd.Series(pd.to_numeric(series, errors="coerce").to_numpy(dtype=np.float64),
                       index=pd.DatetimeIndex(pd.to_datetime(series.index)),
                       name=name).sort_index()
    if values.index.duplicated().any():
        raise ProtocolAuditError(f"{name} contains duplicate dates")
    return values[np.isfinite(values.to_numpy())]


def _denominator(values: pd.Series) -> float:
    array = values.to_numpy(dtype=np.float64)
    if array.size < 2:
        return float("nan")
    return float(np.sum((array - np.mean(array, dtype=np.float64))**2, dtype=np.float64))


def build_basin_date_audit(basin_id: str, neural_observations: pd.Series,
                           conceptual_observations: pd.Series) -> tuple[dict[str, int | float | str], pd.DataFrame]:
    """Outer-align one basin's valid target observations and calculate public denominators."""
    neural = _finite_series(neural_observations, "neural observations")
    conceptual = _finite_series(conceptual_observations, "conceptual observations")
    if neural.empty and conceptual.empty:
        raise ProtocolAuditError(f"basin {basin_id} has no valid observations in either path")

    first_date = min(neural.index.min(), conceptual.index.min())
    last_date = max(neural.index.max(), conceptual.index.max())
    full_dates = pd.date_range(first_date, last_date, freq="D")
    neural_aligned = neural.reindex(full_dates)
    conceptual_aligned = conceptual.reindex(full_dates)
    neural_valid = neural_aligned.notna()
    conceptual_valid = conceptual_aligned.notna()

    rows = pd.DataFrame({
        "basin_id": str(basin_id).zfill(8),
        "date": full_dates,
        "neural_valid": neural_valid.to_numpy(dtype=bool),
        "conceptual_valid": conceptual_valid.to_numpy(dtype=bool),
        "neural_observation_mm_per_day": neural_aligned.to_numpy(dtype=np.float64),
        "conceptual_observation_mm_per_day": conceptual_aligned.to_numpy(dtype=np.float64),
    })
    summary = {
        "basin_id": str(basin_id).zfill(8),
        "neural_valid_count": len(neural),
        "conceptual_valid_count": len(conceptual),
        "neural_date_sha256": date_sha256(neural.index),
        "conceptual_date_sha256": date_sha256(conceptual.index),
        "reference_denominator": _denominator(neural),
        "conceptual_denominator": _denominator(conceptual),
    }
    return summary, rows


def canonical_discharge_mm_per_day(discharge_cfs: np.ndarray, area_m2: float) -> np.ndarray:
    """Convert cubic feet per second to millimetres per day using the NeuralHydrology formula."""
    discharge = np.asarray(discharge_cfs, dtype=np.float64)
    try:
        converted = convert_discharge_to_mm_per_day(discharge, area_m2=area_m2)
    except ValueError as exc:
        raise ProtocolAuditError(str(exc)) from exc
    converted[discharge < 0.0] = np.nan
    return converted


def normalize_canonical_observations_for_training(observations: np.ndarray, center: float,
                                                  scale: float) -> np.ndarray:
    """Reproduce float32 raw data normalized by xarray's float64 reduction statistics."""
    if not np.isfinite(scale) or scale <= 0.0:
        raise ProtocolAuditError(f"target scale must be finite and strictly positive, got {scale}")
    raw_float64_after_storage = np.asarray(observations, dtype=np.float32).astype(np.float64)
    return np.asarray((raw_float64_after_storage - np.float64(center)) / np.float64(scale), dtype=np.float32)


def count_extra_target_dates(old_start: str | pd.Timestamp, public_start: str | pd.Timestamp) -> int:
    """Return the number of daily targets before the public target start."""
    old = pd.Timestamp(old_start)
    public = pd.Timestamp(public_start)
    if old > public:
        raise ProtocolAuditError(f"old target start {old.date()} is after public target start {public.date()}")
    return int((public - old).days)


def validate_persisted_training_weight_evidence(expected_training_weights: dict[str, float],
                                                  persisted_training_weights: pd.Series,
                                                  evaluation_basin: str,
                                                  evaluation_weight: float) -> dict[str, float | int]:
    """Validate that evaluation restores the exact saved public-training basin weight."""
    expected = pd.Series(expected_training_weights, dtype=np.float64)
    persisted = pd.Series(persisted_training_weights, dtype=np.float64).copy()
    expected.index = expected.index.map(str)
    persisted.index = persisted.index.map(str)
    if not expected.index.is_unique or not persisted.index.is_unique or set(expected.index) != set(persisted.index):
        raise ProtocolAuditError("persisted training weight basin membership differs from the training dataset")
    persisted_values = persisted.to_numpy(dtype=np.float64)
    if not np.all(np.isfinite(persisted_values) & (persisted_values > 0.0)):
        raise ProtocolAuditError("persisted training weights must be finite and strictly positive")

    persisted = persisted.reindex(expected.index)
    maximum_difference = float(np.max(np.abs(persisted.to_numpy(dtype=np.float64)
                                                 - expected.to_numpy(dtype=np.float64))))
    if maximum_difference > WEIGHT_TOLERANCE:
        raise ProtocolAuditError(f"persisted training weight differs by {maximum_difference}")

    evaluation_basin = str(evaluation_basin)
    if evaluation_basin not in expected.index:
        raise ProtocolAuditError(f"evaluation probe basin {evaluation_basin} is absent from training weights")
    evaluation_difference = abs(float(evaluation_weight) - float(expected.loc[evaluation_basin]))
    if not np.isfinite(evaluation_difference) or evaluation_difference > WEIGHT_TOLERANCE:
        raise ProtocolAuditError(f"evaluation training weight differs by {evaluation_difference}")
    return {
        "persisted_training_weight_count": len(persisted),
        "persisted_training_weight_maximum_absolute_difference": maximum_difference,
        "evaluation_training_weight_absolute_difference": evaluation_difference,
    }


def validate_persisted_target_statistics_evidence(target: str,
                                                    expected_center: float,
                                                    expected_scale: float,
                                                    persisted_scaler: dict) -> dict[str, float | str]:
    """Validate the exact target statistics restored by the formal evaluation scaler loader."""
    statistics = {
        "center": ("xarray_feature_center", expected_center),
        "scale": ("xarray_feature_scale", expected_scale),
    }
    evidence: dict[str, float | str] = {}
    for label, (scaler_key, expected_value) in statistics.items():
        if scaler_key not in persisted_scaler or target not in persisted_scaler[scaler_key]:
            raise ProtocolAuditError(f"persisted target {label} is missing for {target}")
        persisted = persisted_scaler[scaler_key][target]
        if persisted.dtype != np.dtype(np.float64):
            raise ProtocolAuditError(f"persisted target {label} must be float64, got {persisted.dtype}")
        value = float(persisted.item())
        difference = abs(value - float(expected_value))
        if not np.isfinite(value) or not np.isfinite(difference):
            raise ProtocolAuditError(f"persisted target {label} must be finite")
        if label == "scale" and value <= 0.0:
            raise ProtocolAuditError(f"persisted target scale must be strictly positive, got {value}")
        if difference > TARGET_STATISTIC_TOLERANCE:
            raise ProtocolAuditError(f"persisted target {label} differs by {difference}")
        evidence[f"persisted_target_{label}"] = value
        evidence[f"persisted_target_{label}_absolute_difference"] = difference
        evidence[f"persisted_target_{label}_dtype"] = str(persisted.dtype)
    return evidence


def _require_columns(frame: pd.DataFrame, columns: set[str], name: str) -> None:
    missing = sorted(columns.difference(frame.columns))
    if missing:
        raise ProtocolAuditError(f"{name} is missing required columns: {missing}")


def _maximum_reference_difference(frame: pd.DataFrame, reference: str, comparisons: Sequence[str]) -> float:
    values = []
    reference_values = pd.to_numeric(frame[reference], errors="coerce").to_numpy(dtype=np.float64)
    for column in comparisons:
        comparison = pd.to_numeric(frame[column], errors="coerce").to_numpy(dtype=np.float64)
        values.append(np.abs(comparison - reference_values))
    return float(np.max(np.concatenate(values))) if values else 0.0


def validate_protocol_tables(basin_rows: pd.DataFrame,
                             date_rows: pd.DataFrame,
                             expected_basins: Sequence[str],
                             *,
                             actual_single_precision_loss: float,
                             double_precision_reference_loss: float,
                             actual_sine_single_precision_loss: float,
                             sine_double_precision_reference_loss: float,
                             actual_target_center: float,
                             actual_target_scale: float,
                             public_target_center: float,
                             public_target_scale: float,
                             denominator_tolerance: float = DENOMINATOR_TOLERANCE,
                             weight_tolerance: float = WEIGHT_TOLERANCE,
                             single_precision_loss_tolerance: float = SINGLE_PRECISION_LOSS_TOLERANCE,
                             target_statistic_tolerance: float = TARGET_STATISTIC_TOLERANCE,
                             observation_tolerance: float = 0.0) -> dict[str, int | float | str]:
    """Validate exact basin, date-mask, observation, denominator, and weight alignment."""
    expected = [str(basin).zfill(8) for basin in expected_basins]
    if len(expected) != EXPECTED_BASIN_COUNT or len(set(expected)) != EXPECTED_BASIN_COUNT:
        raise ProtocolAuditError(
            f"expected basin manifest must contain exactly 531 unique basins, got {len(set(expected))}")

    required_basin_columns = {
        "basin_id", "neural_target_start", "conceptual_target_start", "neural_target_end",
        "conceptual_target_end", "neural_valid_count", "conceptual_valid_count", "neural_date_sha256",
        "conceptual_date_sha256", "reference_denominator", "neural_denominator", "conceptual_denominator",
        "reference_weight", "neural_weight", "conceptual_weight"
    }
    required_date_columns = {
        "basin_id", "date", "neural_valid", "conceptual_valid", "neural_observation_mm_per_day",
        "conceptual_observation_mm_per_day"
    }
    _require_columns(basin_rows, required_basin_columns, "basin table")
    _require_columns(date_rows, required_date_columns, "date table")

    basins = basin_rows.copy()
    dates = date_rows.copy()
    basins["basin_id"] = basins["basin_id"].astype(str).str.zfill(8)
    dates["basin_id"] = dates["basin_id"].astype(str).str.zfill(8)

    if basins["basin_id"].duplicated().any():
        raise ProtocolAuditError("basin table must contain one row per unique basin")
    if len(basins) != EXPECTED_BASIN_COUNT or set(basins["basin_id"]) != set(expected):
        raise ProtocolAuditError(f"basin table must contain exactly 531 expected basins, got {len(basins)}")
    if set(dates["basin_id"]) != set(expected):
        raise ProtocolAuditError("date table does not contain exactly the expected basin set")

    dates["date"] = pd.to_datetime(dates["date"])
    if dates.duplicated(["basin_id", "date"]).any():
        raise ProtocolAuditError("date table contains a duplicate basin-date row")

    for column in ("neural_target_start", "conceptual_target_start"):
        parsed = pd.to_datetime(basins[column])
        if not (parsed == PUBLIC_TARGET_START).all():
            raise ProtocolAuditError(f"{column} does not equal the public target start {PUBLIC_TARGET_START.date()}")
    for column in ("neural_target_end", "conceptual_target_end"):
        parsed = pd.to_datetime(basins[column])
        if not (parsed == PUBLIC_TARGET_END).all():
            raise ProtocolAuditError(f"{column} does not equal the public target end {PUBLIC_TARGET_END.date()}")

    count_match = pd.to_numeric(basins["neural_valid_count"]) == pd.to_numeric(basins["conceptual_valid_count"])
    hash_match = basins["neural_date_sha256"].astype(str) == basins["conceptual_date_sha256"].astype(str)
    if not (count_match & hash_match).all():
        raise ProtocolAuditError("neural and conceptual date masks are not identical")

    denominator_columns = ["reference_denominator", "neural_denominator", "conceptual_denominator"]
    denominator_values = basins[denominator_columns].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=np.float64)
    if not np.all(np.isfinite(denominator_values) & (denominator_values > 0.0)):
        raise ProtocolAuditError("all 531 basin denominators must be finite and strictly positive")
    maximum_denominator_difference = _maximum_reference_difference(
        basins, "reference_denominator", ["neural_denominator", "conceptual_denominator"])
    if maximum_denominator_difference > denominator_tolerance:
        raise ProtocolAuditError(
            f"maximum denominator difference {maximum_denominator_difference} exceeds {denominator_tolerance}")

    weight_columns = ["reference_weight", "neural_weight", "conceptual_weight"]
    weight_values = basins[weight_columns].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=np.float64)
    if not np.all(np.isfinite(weight_values) & (weight_values > 0.0)):
        raise ProtocolAuditError("all basin weights must be finite and strictly positive")
    maximum_weight_difference = _maximum_reference_difference(
        basins, "reference_weight", ["neural_weight", "conceptual_weight"])
    if maximum_weight_difference > weight_tolerance:
        raise ProtocolAuditError(f"maximum weight difference {maximum_weight_difference} exceeds {weight_tolerance}")

    neural_valid = dates["neural_valid"].astype(bool).to_numpy()
    conceptual_valid = dates["conceptual_valid"].astype(bool).to_numpy()
    mask_difference_count = int(np.count_nonzero(neural_valid != conceptual_valid))
    if mask_difference_count:
        raise ProtocolAuditError(f"date mask differs on {mask_difference_count} basin-date rows")

    common_valid = neural_valid & conceptual_valid
    neural_observation = pd.to_numeric(
        dates.loc[common_valid, "neural_observation_mm_per_day"], errors="coerce").to_numpy(dtype=np.float64)
    conceptual_observation = pd.to_numeric(
        dates.loc[common_valid, "conceptual_observation_mm_per_day"], errors="coerce").to_numpy(dtype=np.float64)
    if not np.all(np.isfinite(neural_observation) & np.isfinite(conceptual_observation)):
        raise ProtocolAuditError("common valid rows contain a non-finite observation")
    maximum_observation_difference = float(np.max(np.abs(neural_observation - conceptual_observation)))
    if maximum_observation_difference > observation_tolerance:
        raise ProtocolAuditError(
            f"maximum observation difference {maximum_observation_difference} exceeds {observation_tolerance}")

    actual_loss = float(actual_single_precision_loss)
    reference_loss = float(double_precision_reference_loss)
    if not np.isfinite(actual_loss) or not np.isfinite(reference_loss):
        raise ProtocolAuditError("actual and reference losses must be finite")
    single_precision_loss_difference = abs(actual_loss - reference_loss)
    if single_precision_loss_difference > single_precision_loss_tolerance:
        raise ProtocolAuditError(
            f"single-precision loss difference {single_precision_loss_difference} exceeds "
            f"{single_precision_loss_tolerance}")
    actual_sine_loss = float(actual_sine_single_precision_loss)
    sine_reference_loss = float(sine_double_precision_reference_loss)
    if not np.isfinite(actual_sine_loss) or not np.isfinite(sine_reference_loss):
        raise ProtocolAuditError("actual and reference sine losses must be finite")
    sine_loss_difference = abs(actual_sine_loss - sine_reference_loss)
    if sine_loss_difference > single_precision_loss_tolerance:
        raise ProtocolAuditError(
            f"sine single-precision loss difference {sine_loss_difference} exceeds "
            f"{single_precision_loss_tolerance}")

    statistics = np.asarray(
        [actual_target_center, actual_target_scale, public_target_center, public_target_scale], dtype=np.float64)
    if not np.all(np.isfinite(statistics)) or actual_target_scale <= 0.0 or public_target_scale <= 0.0:
        raise ProtocolAuditError("actual and public target statistics must be finite with positive scales")
    target_center_difference = abs(float(actual_target_center) - float(public_target_center))
    target_scale_difference = abs(float(actual_target_scale) - float(public_target_scale))
    if target_center_difference > target_statistic_tolerance:
        raise ProtocolAuditError(
            f"target center difference {target_center_difference} exceeds {target_statistic_tolerance}")
    if target_scale_difference > target_statistic_tolerance:
        raise ProtocolAuditError(
            f"target scale difference {target_scale_difference} exceeds {target_statistic_tolerance}")

    return {
        "basin_count": EXPECTED_BASIN_COUNT,
        "positive_denominator_count": int(np.count_nonzero(denominator_values[:, 0] > 0.0)),
        "date_row_count": len(dates),
        "mask_difference_count": mask_difference_count,
        "maximum_observation_absolute_difference": maximum_observation_difference,
        "maximum_denominator_absolute_difference": maximum_denominator_difference,
        "maximum_weight_absolute_difference": maximum_weight_difference,
        "actual_single_precision_loss": actual_loss,
        "double_precision_reference_loss": reference_loss,
        "single_precision_loss_absolute_difference": single_precision_loss_difference,
        "actual_sine_single_precision_loss": actual_sine_loss,
        "sine_double_precision_reference_loss": sine_reference_loss,
        "sine_single_precision_loss_absolute_difference": sine_loss_difference,
        "public_target_center": float(public_target_center),
        "public_target_scale": float(public_target_scale),
        "target_center_absolute_difference": target_center_difference,
        "target_scale_absolute_difference": target_scale_difference,
        "target_start": PUBLIC_TARGET_START.date().isoformat(),
        "target_end": PUBLIC_TARGET_END.date().isoformat(),
    }


def file_sha256(path: Path) -> str:
    """Return the SHA-256 digest of a file without loading it fully into memory."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _git_output(repo_root: Path, *args: str) -> str:
    completed = subprocess.run(
        ["git", "-C", str(repo_root), *args],
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    if completed.returncode != 0:
        raise ProtocolAuditError(
            f"git {' '.join(args)} failed with exit code {completed.returncode}: {completed.stderr.strip()}")
    return completed.stdout.strip()


def build_reproducibility_metadata(repo_root: Path, data_dir: Path) -> dict:
    """Record the source tree, environment, and static-attribute inputs used by the audit."""
    repo_root = Path(repo_root).resolve()
    data_dir = Path(data_dir).resolve()
    status = _git_output(repo_root, "status", "--short", "--untracked-files=normal")
    source_files = {}
    for relative in SOURCE_FILES_FOR_AUDIT:
        path = repo_root / relative
        if not path.is_file():
            raise ProtocolAuditError(f"required audit source file does not exist: {path}")
        source_files[relative] = {
            "path": str(path),
            "bytes": path.stat().st_size,
            "sha256": file_sha256(path),
        }

    attributes_dir = data_dir / "camels_attributes_v2.0"
    attribute_paths = (sorted(path for path in attributes_dir.iterdir()
                              if path.is_file()) if attributes_dir.is_dir() else [])
    if not attribute_paths:
        raise ProtocolAuditError(f"no static attribute files found in {attributes_dir}")
    static_attribute_files = [{
        "name": path.name,
        "path": str(path),
        "bytes": path.stat().st_size,
        "sha256": file_sha256(path),
    } for path in attribute_paths]

    package_versions = {}
    for distribution in PACKAGE_DISTRIBUTIONS_FOR_AUDIT:
        try:
            package_versions[distribution] = importlib.metadata.version(distribution)
        except importlib.metadata.PackageNotFoundError:
            package_versions[distribution] = "not-installed"
    return {
        "git": {
            "head_commit": _git_output(repo_root, "rev-parse", "HEAD"),
            "branch": _git_output(repo_root, "branch", "--show-current"),
            "dirty": bool(status),
            "status_lines": status.splitlines() if status else [],
            "status_sha256": hashlib.sha256(status.encode("utf-8")).hexdigest(),
        },
        "environment": {
            "python_version": sys.version,
            "python_executable": sys.executable,
            "platform": platform.platform(),
        },
        "package_versions": package_versions,
        "source_files": source_files,
        "static_attribute_files": static_attribute_files,
    }


def _read_basins(path: Path) -> list[str]:
    basins = [line.strip().zfill(8) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(basins) != EXPECTED_BASIN_COUNT or len(set(basins)) != EXPECTED_BASIN_COUNT:
        raise ProtocolAuditError(f"basin manifest must contain exactly 531 unique basins, got {len(set(basins))}")
    return basins


def validate_dataset_basin_membership(dataset_basins: Sequence[str], manifest_basins: Sequence[str]) -> list[str]:
    """Require exact unique membership while treating order as non-semantic."""
    dataset = [str(basin).zfill(8) for basin in dataset_basins]
    manifest = [str(basin).zfill(8) for basin in manifest_basins]
    if len(dataset) != len(set(dataset)):
        raise ProtocolAuditError("neural dataset basin identifiers must be unique")
    if set(dataset) != set(manifest):
        missing = sorted(set(manifest).difference(dataset))
        extra = sorted(set(dataset).difference(manifest))
        raise ProtocolAuditError(f"neural dataset basin set differs from manifest; missing={missing}, extra={extra}")
    return sorted(dataset)


def _single_match(root: Path, pattern: str, description: str) -> Path:
    matches = sorted(root.glob(pattern))
    if len(matches) != 1:
        raise ProtocolAuditError(f"expected one {description}, found {len(matches)} for pattern {root / pattern}")
    return matches[0]


def _target_scaler_value(scaler: dict, key: str, target: str) -> float:
    value = scaler[key]
    try:
        scalar = value[target].item()
    except (KeyError, TypeError, ValueError, AttributeError) as exc:
        raise ProtocolAuditError(f"cannot read target {target!r} from scaler entry {key!r}") from exc
    scalar = float(scalar)
    if not np.isfinite(scalar):
        raise ProtocolAuditError(f"scaler entry {key!r} for {target!r} is not finite")
    return scalar


def _dataset_normalized_targets(dataset) -> dict[str, pd.Series]:
    frequency = dataset.frequencies[0]
    by_basin: dict[str, list[tuple[pd.Timestamp, float]]] = {basin: [] for basin in dataset.basins}
    for basin, indices in dataset.lookup_table.values():
        index = indices[0]
        date = pd.Timestamp(dataset._dates[basin][frequency][index])
        value = float(dataset._y[basin][frequency][index, 0].item())
        by_basin[basin].append((date, value))
    result = {}
    for basin, entries in by_basin.items():
        if not entries:
            raise ProtocolAuditError(f"neural dataset has no valid target samples for basin {basin}")
        dates, values = zip(*entries)
        series = pd.Series(np.asarray(values, dtype=np.float32), index=pd.DatetimeIndex(dates)).sort_index()
        if series.index.duplicated().any():
            raise ProtocolAuditError(f"neural dataset has duplicate target dates for basin {basin}")
        result[basin] = series
    return result


def calculate_real_loss_probe_evidence(loss_obj,
                                       normalized_targets_by_basin: Sequence[np.ndarray],
                                       normalized_weights_by_basin: Sequence[np.ndarray],
                                       raw_targets_by_basin: Sequence[np.ndarray],
                                       reference_denominators: Sequence[float],
                                       target_center: float,
                                       target_scale: float) -> dict[str, float]:
    """Calculate actual float32-model-path probes and independent raw-unit references."""
    basin_count = len(raw_targets_by_basin)
    lengths = {
        basin_count,
        len(normalized_targets_by_basin),
        len(normalized_weights_by_basin),
        len(reference_denominators),
    }
    if basin_count == 0 or len(lengths) != 1:
        raise ProtocolAuditError("loss probe inputs must contain the same positive number of basins")
    if not np.isfinite(target_center) or not np.isfinite(target_scale) or target_scale <= 0.0:
        raise ProtocolAuditError("loss probe target statistics must be finite with a positive scale")

    normalized_targets = []
    normalized_weights = []
    raw_targets = []
    denominators = np.asarray(reference_denominators, dtype=np.float64)
    if not np.all(np.isfinite(denominators) & (denominators > 0.0)):
        raise ProtocolAuditError("loss probe reference denominators must be finite and strictly positive")
    for basin_index, (target_values, weight_values, raw_values) in enumerate(
            zip(normalized_targets_by_basin, normalized_weights_by_basin, raw_targets_by_basin)):
        target_array = np.asarray(target_values)
        weight_array = np.asarray(weight_values)
        raw_array = np.asarray(raw_values, dtype=np.float64)
        if target_array.ndim != 1 or weight_array.ndim != 1 or raw_array.ndim != 1:
            raise ProtocolAuditError(f"loss probe basin {basin_index} inputs must be one-dimensional")
        if not (len(target_array) == len(weight_array) == len(raw_array)) or len(raw_array) == 0:
            raise ProtocolAuditError(f"loss probe basin {basin_index} inputs must have the same positive length")
        if target_array.dtype != np.float32:
            raise ProtocolAuditError(f"loss probe basin {basin_index} normalized targets must use float32")
        if weight_array.dtype != np.float64:
            raise ProtocolAuditError(f"loss probe basin {basin_index} training weights must use float64")
        if not np.all(np.isfinite(target_array)) or not np.all(np.isfinite(raw_array)):
            raise ProtocolAuditError(f"loss probe basin {basin_index} targets must be finite")
        if not np.all(np.isfinite(weight_array) & (weight_array > 0.0)):
            raise ProtocolAuditError(f"loss probe basin {basin_index} weights must be finite and strictly positive")
        normalized_targets.append(target_array)
        normalized_weights.append(weight_array)
        raw_targets.append(raw_array)

    flat_normalized_targets = np.concatenate(normalized_targets)
    flat_normalized_weights = np.concatenate(normalized_weights)
    flat_raw_targets = np.concatenate(raw_targets)
    total_count = len(flat_raw_targets)
    sine_prediction = np.asarray(
        2.5 * np.sin(np.arange(total_count, dtype=np.float64) * 0.000137), dtype=np.float32)
    loss_targets = torch.from_numpy(flat_normalized_targets).reshape(-1, 1, 1)
    loss_weights = torch.from_numpy(flat_normalized_weights).reshape(-1, 1, 1)
    with torch.no_grad():
        actual_zero_loss, _ = loss_obj(
            {"y_hat": torch.zeros_like(loss_targets)}, {
                "y": loss_targets,
                "per_basin_target_nse_weight": loss_weights,
            })
        actual_sine_loss, _ = loss_obj(
            {"y_hat": torch.from_numpy(sine_prediction).reshape(-1, 1, 1)}, {
                "y": loss_targets,
                "per_basin_target_nse_weight": loss_weights,
            })

    raw_sine_prediction = np.float64(target_center) + np.float64(target_scale) * sine_prediction.astype(np.float64)
    zero_reference_by_basin = []
    sine_reference_by_basin = []
    offset = 0
    for raw_values, denominator in zip(raw_targets, denominators):
        stop = offset + len(raw_values)
        zero_reference_by_basin.append(
            np.sum((np.float64(target_center) - raw_values)**2, dtype=np.float64) / denominator)
        sine_reference_by_basin.append(
            np.sum((raw_sine_prediction[offset:stop] - raw_values)**2, dtype=np.float64) / denominator)
        offset = stop

    public_target_center = float(np.mean(flat_raw_targets, dtype=np.float64))
    public_target_scale = float(np.std(flat_raw_targets, ddof=0, dtype=np.float64))
    if not np.isfinite(public_target_scale) or public_target_scale <= 0.0:
        raise ProtocolAuditError("public target scale must be finite and strictly positive")
    return {
        "actual_single_precision_loss": float(actual_zero_loss.item()),
        "double_precision_reference_loss": float(np.mean(zero_reference_by_basin, dtype=np.float64)),
        "actual_sine_single_precision_loss": float(actual_sine_loss.item()),
        "sine_double_precision_reference_loss": float(np.mean(sine_reference_by_basin, dtype=np.float64)),
        "public_target_center": public_target_center,
        "public_target_scale": public_target_scale,
    }


def validate_real_protocol_evidence(basin_rows: pd.DataFrame,
                                    date_rows: pd.DataFrame,
                                    expected_basins: Sequence[str],
                                    loss_probe_evidence: dict[str, float],
                                    actual_target_center: float,
                                    actual_target_scale: float) -> dict[str, int | float | str]:
    """Validate real tables using the complete loss-probe evidence schema."""
    required = {
        "actual_single_precision_loss",
        "double_precision_reference_loss",
        "actual_sine_single_precision_loss",
        "sine_double_precision_reference_loss",
        "public_target_center",
        "public_target_scale",
    }
    missing = sorted(required.difference(loss_probe_evidence))
    if missing:
        raise ProtocolAuditError(f"loss probe evidence is missing required values: {missing}")
    return validate_protocol_tables(
        basin_rows,
        date_rows,
        expected_basins,
        actual_single_precision_loss=loss_probe_evidence["actual_single_precision_loss"],
        double_precision_reference_loss=loss_probe_evidence["double_precision_reference_loss"],
        actual_sine_single_precision_loss=loss_probe_evidence["actual_sine_single_precision_loss"],
        sine_double_precision_reference_loss=loss_probe_evidence["sine_double_precision_reference_loss"],
        actual_target_center=actual_target_center,
        actual_target_scale=actual_target_scale,
        public_target_center=loss_probe_evidence["public_target_center"],
        public_target_scale=loss_probe_evidence["public_target_scale"],
    )


def _memory_snapshot() -> dict[str, float]:
    memory = psutil.virtual_memory()
    return {
        "available_system_memory_gib": memory.available / 1024**3,
        "used_system_memory_gib": memory.used / 1024**3,
        "system_memory_percent": float(memory.percent),
    }


def run_real_audit(config_path: Path, data_dir: Path, output_dir: Path) -> tuple[dict, pd.DataFrame, pd.DataFrame]:
    """Construct and validate the real 531-basin protocol evidence tables."""
    started = time.time()
    config_path = Path(config_path).resolve()
    data_dir = Path(data_dir).resolve()
    output_dir = Path(output_dir).resolve()
    if not data_dir.is_dir():
        raise ProtocolAuditError(f"data directory does not exist: {data_dir}")
    output_dir.mkdir(parents=True, exist_ok=True)

    train_dir = output_dir / "neural_dataset_staging" / "train_data"
    cfg = load_runtime_config(config_path, data_dir=data_dir, train_dir=train_dir)
    manifest_path = Path(cfg.train_basin_file).resolve()
    basins = _read_basins(manifest_path)
    if cfg.train_start_date != PUBLIC_TARGET_START or cfg.train_end_date != PUBLIC_TARGET_END:
        raise ProtocolAuditError(
            f"configuration target dates are {cfg.train_start_date.date()} to {cfg.train_end_date.date()}, expected "
            f"{PUBLIC_TARGET_START.date()} to {PUBLIC_TARGET_END.date()}")

    memory_before = _memory_snapshot()
    dataset = get_dataset(cfg=cfg, is_train=True, period="train")
    memory_after_dataset = _memory_snapshot()
    basins = validate_dataset_basin_membership(dataset.basins, basins)

    target = cfg.target_variables[0]
    target_center = _target_scaler_value(dataset.scaler, "xarray_feature_center", target)
    target_scale = _target_scaler_value(dataset.scaler, "xarray_feature_scale", target)
    if target_scale <= 0.0:
        raise ProtocolAuditError(f"target scale must be strictly positive, got {target_scale}")
    normalized_targets = _dataset_normalized_targets(dataset)
    neural_total_count = len(dataset.lookup_table)

    persisted_scaler = load_scaler(train_dir.parent)
    persisted_training_weights = persisted_scaler.get("basin_average_nse_training_weights")
    persisted_target_statistics_evidence = validate_persisted_target_statistics_evidence(
        target=target,
        expected_center=target_center,
        expected_scale=target_scale,
        persisted_scaler=persisted_scaler,
    )
    inference_probe_basin = basins[0]
    inference_dataset = get_dataset(cfg=cfg,
                                    is_train=False,
                                    period="train",
                                    basin=inference_probe_basin,
                                    scaler=persisted_scaler)
    inference_sample = inference_dataset[0]
    inference_weight = float(inference_sample["per_basin_target_nse_weight"].item())
    persisted_weight_evidence = validate_persisted_training_weight_evidence(
        expected_training_weights=dataset._per_basin_target_nse_reference_weights,
        persisted_training_weights=persisted_training_weights,
        evaluation_basin=inference_probe_basin,
        evaluation_weight=inference_weight,
    )
    inference_target = inference_sample["y"][-1:].unsqueeze(0)
    inference_prediction = torch.zeros_like(inference_target)
    inference_loss, _ = get_loss_obj(cfg)({"y_hat": inference_prediction}, {
        "y": inference_target,
        "per_basin_target_nse_weight": inference_sample["per_basin_target_nse_weight"].unsqueeze(0),
    })
    if not torch.isfinite(inference_loss):
        raise ProtocolAuditError("non-training data path produced a non-finite BasinAverageNSE loss")
    persisted_weight_evidence.update({
        "inference_probe_basin": inference_probe_basin,
        "inference_probe_period": "train",
        "inference_probe_reads_evaluation_period": False,
        "inference_probe_sample_count": len(inference_dataset),
        "inference_probe_loss": float(inference_loss.item()),
    })

    topographic_attributes = pd.read_csv(data_dir / "camels_attributes_v2.0" / "camels_topo.txt",
                                         sep=";",
                                         dtype={"gauge_id": str}).set_index("gauge_id")

    conceptual_calibration_start = pd.Timestamp("1999-10-01")
    conceptual_calibration_end = pd.Timestamp("2008-09-30")
    conceptual_target_start = conceptual_calibration_start + pd.Timedelta(days=365)
    if conceptual_target_start != PUBLIC_TARGET_START:
        raise ProtocolAuditError(f"conceptual target start is {conceptual_target_start.date()}")

    summary_rows: list[dict] = []
    date_frames: list[pd.DataFrame] = []
    normalized_targets_for_loss: list[np.ndarray] = []
    normalized_weights_for_loss: list[np.ndarray] = []
    raw_targets_for_loss: list[np.ndarray] = []
    reference_denominators_for_loss: list[float] = []
    maximum_normalized_target_difference = 0.0
    for basin in basins:
        forcing_path = _single_match(data_dir / "basin_mean_forcing" / "maurer",
                                     f"**/{basin}_*_forcing_leap.txt", "Maurer forcing file")
        streamflow_path = _single_match(data_dir / "usgs_streamflow", f"**/{basin}_streamflow_qc.txt",
                                        "streamflow file")
        _, forcing_header_area_m2 = load_camels_us_forcings(data_dir, basin, "maurer")
        neural_raw_full = load_camels_us_discharge(data_dir, basin, forcing_header_area_m2)
        neural_dates = normalized_targets[basin].index
        neural_raw = neural_raw_full.reindex(neural_dates).astype(np.float32)
        if not np.all(np.isfinite(neural_raw.to_numpy(dtype=np.float64))):
            raise ProtocolAuditError(f"neural lookup contains a non-finite raw observation for basin {basin}")

        expected_normalized = normalize_canonical_observations_for_training(
            neural_raw.to_numpy(dtype=np.float64), center=target_center, scale=target_scale)
        actual_normalized = normalized_targets[basin].to_numpy(dtype=np.float32)
        normalized_difference = float(np.max(np.abs(actual_normalized.astype(np.float64)
                                                      - expected_normalized.astype(np.float64))))
        maximum_normalized_target_difference = max(maximum_normalized_target_difference, normalized_difference)
        if not np.array_equal(actual_normalized, expected_normalized):
            mismatch_index = int(np.flatnonzero(actual_normalized.view(np.uint32)
                                                != expected_normalized.view(np.uint32))[0])
            raw_value = float(neural_raw.iloc[mismatch_index])
            float64_first = np.float32((raw_value - target_center) / target_scale)
            raise ProtocolAuditError(
                f"normalized neural targets differ from the canonical raw observations for basin {basin}; "
                f"maximum difference {normalized_difference}; "
                f"first mismatch date={neural_dates[mismatch_index].date()}, "
                f"raw={raw_value!r}, actual={float(actual_normalized[mismatch_index])!r}, "
                f"float32_first={float(expected_normalized[mismatch_index])!r}, "
                f"float64_first={float(float64_first)!r}, center={target_center!r}, scale={target_scale!r}")

        _, conceptual_full, conceptual_area_km2 = load_camels_basin(
            basin,
            data_root=data_dir,
            start_date=conceptual_calibration_start.strftime("%Y-%m-%d"),
            end_date=conceptual_calibration_end.strftime("%Y-%m-%d"),
            forcing="maurer",
            pet_method="priestley_taylor",
            keep_obs_nan_days=True,
            discharge_normalization="common_forcing_header_float32",
        )
        conceptual = conceptual_full.iloc[365:]
        basin_summary, basin_dates = build_basin_date_audit(basin, neural_raw, conceptual)
        training_weight = float(dataset._per_basin_target_nse_weights[basin].item())
        normalized_targets_for_loss.append(actual_normalized)
        normalized_weights_for_loss.append(np.full(actual_normalized.shape, training_weight, dtype=np.float64))
        raw_values = neural_raw.to_numpy(dtype=np.float64)
        raw_targets_for_loss.append(raw_values)
        reference_denominators_for_loss.append(float(basin_summary["reference_denominator"]))
        basin_summary.update({
            "neural_target_start": cfg.train_start_date,
            "conceptual_target_start": conceptual_target_start,
            "neural_target_end": cfg.train_end_date,
            "conceptual_target_end": conceptual_calibration_end,
            "neural_denominator": dataset._per_basin_target_nse_denominators[basin],
            "neural_training_weight_normalized": float(dataset._per_basin_target_nse_weights[basin].item()),
            "neural_reference_weight_normalized": dataset._per_basin_target_nse_reference_weights[basin],
            "forcing_header_area_m2": float(forcing_header_area_m2),
            "conceptual_common_area_m2": float(conceptual_area_km2 * 1_000_000.0),
            "historical_attribute_area_m2": float(topographic_attributes.loc[basin, "area_gages2"] * 1_000_000.0),
            "historical_area_relative_difference": (
                float(forcing_header_area_m2) - topographic_attributes.loc[basin, "area_gages2"] * 1_000_000.0)
            / (topographic_attributes.loc[basin, "area_gages2"] * 1_000_000.0),
            "normalized_target_max_abs_difference": normalized_difference,
            "forcing_path": str(forcing_path),
            "forcing_sha256": file_sha256(forcing_path),
            "streamflow_path": str(streamflow_path),
            "streamflow_sha256": file_sha256(streamflow_path),
        })
        summary_rows.append(basin_summary)
        date_frames.append(basin_dates)

    basin_table = pd.DataFrame(summary_rows)
    date_table = pd.concat(date_frames, ignore_index=True)
    conceptual_total_count = int(pd.to_numeric(basin_table["conceptual_valid_count"]).sum())
    basin_count = len(basins)
    basin_table["reference_weight"] = neural_total_count / (
        basin_count * basin_table["reference_denominator"].to_numpy(dtype=np.float64))
    basin_table["neural_weight"] = basin_table["neural_reference_weight_normalized"].to_numpy(
        dtype=np.float64) / target_scale**2
    basin_table["neural_training_weight_raw_equivalent"] = basin_table[
        "neural_training_weight_normalized"].to_numpy(dtype=np.float64) / target_scale**2
    basin_table["conceptual_weight"] = conceptual_total_count / (
        basin_count * basin_table["conceptual_denominator"].to_numpy(dtype=np.float64))

    loss_probe_evidence = calculate_real_loss_probe_evidence(
        loss_obj=get_loss_obj(cfg),
        normalized_targets_by_basin=normalized_targets_for_loss,
        normalized_weights_by_basin=normalized_weights_for_loss,
        raw_targets_by_basin=raw_targets_for_loss,
        reference_denominators=reference_denominators_for_loss,
        target_center=target_center,
        target_scale=target_scale,
    )
    reproducibility = build_reproducibility_metadata(
        repo_root=Path(__file__).resolve().parents[3],
        data_dir=data_dir,
    )

    protocol = {
        "experiment_id": "R02_identical_basin_nse_531",
        "status": "pending_validation",
        "public_loss": "equal mean across 531 basins of SSE divided by the basin observation denominator",
        "public_target_start": PUBLIC_TARGET_START.date().isoformat(),
        "public_target_end": PUBLIC_TARGET_END.date().isoformat(),
        "old_neural_extra_target_dates": count_extra_target_dates("1999-10-01", PUBLIC_TARGET_START),
        "basin_count": basin_count,
        "neural_total_valid_samples": neural_total_count,
        "conceptual_total_valid_samples": conceptual_total_count,
        "target_center": target_center,
        "target_scale": target_scale,
        "single_precision_loss_probe": "normalized prediction fixed at zero, equivalent to raw target center",
        "sine_single_precision_loss_probe": (
            "normalized prediction is float32(2.5 * sin(global_sample_index * 0.000137))"),
        "public_target_center": loss_probe_evidence["public_target_center"],
        "public_target_scale": loss_probe_evidence["public_target_scale"],
        "maximum_normalized_target_absolute_difference": maximum_normalized_target_difference,
        "canonical_cfs_per_km2_to_mm_per_day": 28_316_846.592 * 86_400.0 / 1_000_000_000_000.0,
        "historical_conceptual_cfs_per_km2_to_mm_per_day": 2.4466,
        "config_path": str(config_path),
        "config_sha256": file_sha256(config_path),
        "basin_manifest_path": str(manifest_path),
        "basin_manifest_sha256": file_sha256(manifest_path),
        "topographic_attributes_path": str(data_dir / "camels_attributes_v2.0" / "camels_topo.txt"),
        "topographic_attributes_sha256": file_sha256(data_dir / "camels_attributes_v2.0" / "camels_topo.txt"),
        "data_dir": str(data_dir),
        "memory_before": memory_before,
        "memory_after_dataset": memory_after_dataset,
        "persisted_target_statistics_evidence": persisted_target_statistics_evidence,
        "persisted_training_weight_evidence": persisted_weight_evidence,
        "reproducibility": reproducibility,
        "elapsed_seconds_before_validation": time.time() - started,
    }
    try:
        protocol["validation"] = validate_real_protocol_evidence(
            basin_rows=basin_table,
            date_rows=date_table,
            expected_basins=basins,
            loss_probe_evidence=loss_probe_evidence,
            actual_target_center=target_center,
            actual_target_scale=target_scale,
        )
        protocol["status"] = "passed"
    except ProtocolAuditError as exc:
        protocol["status"] = "failed"
        protocol["validation_error"] = str(exc)
    protocol["maximum_absolute_historical_area_relative_difference"] = float(
        np.max(np.abs(basin_table["historical_area_relative_difference"].to_numpy(dtype=np.float64))))
    protocol["median_absolute_historical_area_relative_difference"] = float(
        np.median(np.abs(basin_table["historical_area_relative_difference"].to_numpy(dtype=np.float64))))
    protocol["maximum_training_weight_raw_equivalent_absolute_difference"] = float(
        np.max(
            np.abs(basin_table["neural_training_weight_raw_equivalent"].to_numpy(dtype=np.float64)
                   - basin_table["reference_weight"].to_numpy(dtype=np.float64))))
    protocol["elapsed_seconds"] = time.time() - started
    protocol["memory_after_audit"] = _memory_snapshot()
    return protocol, basin_table, date_table


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        default="src/lstm_fair_531/configs/lstm_cudalstm_maurer_531_r02_identical_basin_nse.yml",
    )
    parser.add_argument("--data-dir", required=True)
    parser.add_argument(
        "--output-dir",
        default="results/18_lstm_fair_531/R02_identical_basin_nse_531/protocol",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    protocol_path = output_dir / "common_loss_protocol.json"
    basin_path = output_dir / "per_basin_common_loss.csv"
    date_path = output_dir / "common_dates.csv.gz"
    try:
        protocol, basin_table, date_table = run_real_audit(
            config_path=Path(args.config), data_dir=Path(args.data_dir), output_dir=output_dir)
        basin_table.to_csv(basin_path, index=False)
        date_table.to_csv(date_path, index=False, compression={"method": "gzip", "mtime": 0})
        protocol["per_basin_path"] = str(basin_path)
        protocol["per_basin_sha256"] = file_sha256(basin_path)
        protocol["common_dates_path"] = str(date_path)
        protocol["common_dates_sha256"] = file_sha256(date_path)
        protocol_path.write_text(json.dumps(protocol, indent=2, sort_keys=True), encoding="utf-8")
        print(json.dumps(protocol, indent=2, sort_keys=True))
        return 0 if protocol["status"] == "passed" else 1
    except Exception as exc:  # noqa: BLE001
        failure = {
            "experiment_id": "R02_identical_basin_nse_531",
            "status": "failed_before_tables",
            "error_type": type(exc).__name__,
            "error": str(exc),
        }
        protocol_path.write_text(json.dumps(failure, indent=2, sort_keys=True), encoding="utf-8")
        print(json.dumps(failure, indent=2, sort_keys=True))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
