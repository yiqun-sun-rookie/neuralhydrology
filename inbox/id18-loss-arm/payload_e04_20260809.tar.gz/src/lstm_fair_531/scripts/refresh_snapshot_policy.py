"""Regenerate the manuscript snapshot policy from what the package actually contains.

The policy pins every input the package generator reads and every file the package
ships, by content digest. It used to be hand-maintained, which does not survive the
package gaining a second benchmark protocol. This script derives it instead:

- ``external_inputs`` is the union of both protocols' registered inputs, so a checkout
  that carries the archive can rebuild either one.
- ``baseline_files`` is the package tree as it stands, classified by the same four
  definitions the policy already documented.

Run it after building the package and before rebuilding the external archive.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Dict, List

from src.lstm_fair_531.scripts.evidence_protocols import (
    HISTORICAL_PROTOCOL_ID,
    IDENTICAL_PROTOCOL_ID,
    get_protocol,
)

POLICY_PATH = Path("src/lstm_fair_531/configs/manuscript_snapshot_policy.json")
PACKAGE_ROOT = Path("draft/papers/10_18_conceptual_lstm_package")

_RECOMPUTE_COMMAND = "python -X utf8 -m src.lstm_fair_531.scripts.run_r02_key_point_recomputation"
_R02_ANALYSIS = "results/18_lstm_fair_531/R02_identical_basin_nse_531/analysis_key_points_20260724"
_STATIC_COMMAND = (
    "python -X utf8 -m src.lstm_fair_531.scripts.deep_dive_structure_diagnostics "
    f"--score-panel {_R02_ANALYSIS}/per_basin_combined_nse.csv "
    "--attr-root data/camels_us/camels_attributes_v2.0 "
    f"--out-dir {_R02_ANALYSIS}/D01_structure_diagnostic_r02"
)
_CONTEXT_LINK_COMMAND = (
    "python -X utf8 -m src.lstm_fair_531.scripts.population_residual_attribute_review "
    f"--dive-dir {_R02_ANALYSIS}/D04_population_r02 "
    f"--panel {_R02_ANALYSIS}/D01_structure_diagnostic_r02/tables/basin_attribute_panel.csv"
)
_D07_ROOT = "results/18_lstm_fair_531/D07_context_scale_threshold_robustness_20260726"
_D08_ROOT = "results/18_lstm_fair_531/D08_full_protocol_matrix_stability_20260726"
_D09_ROOT = "results/18_lstm_fair_531/D09_hydrological_process_diagnostics_20260726_attempt2"
_D10_ROOT = "results/18_lstm_fair_531/D10_posthoc_cause_diagnostics_20260726"
_D11_ROOT = "results/18_lstm_fair_531/D11_kge_component_diagnostics_20260727"
_E02_ROOT = "results/18_lstm_fair_531/E02_reverse_tail_emphasis_531"
_E02_DOSE_ROOT = f"{_E02_ROOT}/analysis_dose_response_20260807"
_E02_DOSE_COMMAND = "python -X utf8 -m src.lstm_fair_531.scripts.run_e02_dose_response"
_D07_COMMAND = "python -X utf8 -m src.lstm_fair_531.scripts.run_context_scale_threshold_robustness"
_D08_COMMAND = "python -X utf8 -m src.lstm_fair_531.scripts.full_protocol_matrix_stability"
_D09_COMMAND = (
    "python -X utf8 -m src.lstm_fair_531.scripts.run_hydrological_process_diagnostics "
    "--output-dir results/18_lstm_fair_531/D09_hydrological_process_diagnostics_20260726_attempt2"
)
_D10_COMMAND = "python -X utf8 -m src.lstm_fair_531.scripts.run_posthoc_cause_diagnostics"
_D11_COMMAND = "python -X utf8 -m src.lstm_fair_531.scripts.run_kge_component_diagnostics"


def _d07_delta_inputs() -> List[Dict[str, str]]:
    rows = []
    next_id = 17
    for threshold in ["q05_q95", "q10_q90", "q20_q80"]:
        for family in ["season", "flow", "joint"]:
            path = f"{_D07_ROOT}/thresholds/{threshold}/{family}_context_delta.csv"
            rows.append({
                "input_id": f"N{next_id:02d}",
                "path": path,
                "role": (
                    f"Basin-level {family} context deltas for the {threshold} fixed threshold arm; "
                    "preserved so clustered uncertainty can be independently audited."
                ),
                "source_command": _D07_COMMAND,
                "source_cwd": "repository_root",
                "source_artifact": path,
                "source_dependencies": "registered R02 daily predictions; frozen basin regimes; D07 configuration",
            })
            next_id += 1
    return rows


_ROBUSTNESS_CODE_INPUTS: List[Dict[str, str]] = [
    {"input_id": "C06", "path": "src/lstm_fair_531/scripts/context_scale_threshold_robustness.py",
     "digest_mode": "text_lf", "role": "Dimensionless advantage, fixed-threshold summaries, and basin bootstrap implementation."},
    {"input_id": "C07", "path": "src/lstm_fair_531/scripts/run_context_scale_threshold_robustness.py",
     "digest_mode": "text_lf", "role": "Low-memory registered runner for the scale and threshold robustness analysis."},
    {"input_id": "C08", "path": "src/lstm_fair_531/scripts/full_protocol_matrix_stability.py",
     "digest_mode": "text_lf", "role": "Complete matrix comparison across the historical and common benchmark protocols."},
    {"input_id": "C09", "path": "src/lstm_fair_531/configs/context_scale_threshold_robustness_20260726.json",
     "digest_mode": "text_lf", "role": "Frozen thresholds, bootstrap settings, models, and claim gates for D07."},
    {"input_id": "C10", "path": "src/lstm_fair_531/scripts/hydrological_process_diagnostics.py",
     "digest_mode": "text_lf", "role": "Observation-defined flow and event metrics used by D09."},
    {"input_id": "C11", "path": "src/lstm_fair_531/scripts/run_hydrological_process_diagnostics.py",
     "digest_mode": "text_lf", "role": "Low-memory registered runner and provenance checks for D09."},
    {"input_id": "C12", "path": "src/lstm_fair_531/configs/hydrological_process_diagnostics_20260726.json",
     "digest_mode": "text_lf", "role": "Frozen D09 flow groups, event definitions, bootstrap, and decision gates."},
    {"input_id": "C13", "path": "test/test_id18_hydrological_process_diagnostics.py",
     "digest_mode": "text_lf", "role": "Executable D09 metric, gate, memory, and provenance contracts."},
    {"input_id": "C14", "path": "src/lstm_fair_531/scripts/posthoc_cause_diagnostics.py",
     "digest_mode": "text_lf", "role": "Pure D10 amplitude, event-shape, forcing-association, and basin-bootstrap statistics."},
    {"input_id": "C15", "path": "src/lstm_fair_531/scripts/run_posthoc_cause_diagnostics.py",
     "digest_mode": "text_lf", "role": "Low-memory D10 runner with source inventory and before-after hash verification."},
    {"input_id": "C16", "path": "src/lstm_fair_531/configs/posthoc_cause_diagnostics_20260726.json",
     "digest_mode": "text_lf", "role": "Frozen D10 thresholds, forcing products, estimands, bootstrap, and inference boundaries."},
    {"input_id": "C17", "path": "test/test_id18_posthoc_cause_diagnostics.py",
     "digest_mode": "text_lf", "role": "Executable D10 metric, weighting, memory, provenance, and orchestration contracts."},
    {"input_id": "C18", "path": "src/lstm_fair_531/scripts/kge_component_diagnostics.py",
     "digest_mode": "text_lf", "role": "Pure D11 2009 Kling-Gupta efficiency components and exact six-order arithmetic attribution."},
    {"input_id": "C19", "path": "src/lstm_fair_531/scripts/run_kge_component_diagnostics.py",
     "digest_mode": "text_lf", "role": "Low-memory D11 runner with source inventory, registered replay, and hash checks."},
    {"input_id": "C20", "path": "src/lstm_fair_531/configs/kge_component_diagnostics_20260727.json",
     "digest_mode": "text_lf", "role": "Frozen D11 contexts, component definition, bootstrap settings, and interpretation boundaries."},
    {"input_id": "C21", "path": "test/test_id18_kge_component_diagnostics.py",
     "digest_mode": "text_lf", "role": "Executable D11 component, attribution, undefined-case, provenance, and resource contracts."},
]

_REPLICATION_COMMAND = "python -X utf8 -m src.lstm_fair_531.scripts.analyze_identical_basin_nse_replication"

#: Inputs the identical-loss protocol adds, in registration order.
_IDENTICAL_INPUTS: List[Dict[str, str]] = [
    {
        "input_id": "N01",
        "path": "results/18_lstm_fair_531/R02_identical_basin_nse_531/analysis_official_20260723/"
                "per_basin_nse.csv",
        "role": "Per-basin efficiencies of all four models under the common protocol, plus regime labels.",
        "source_command": _REPLICATION_COMMAND,
    },
    {
        "input_id": "N02",
        "path": "results/18_lstm_fair_531/R02_identical_basin_nse_531/registered_outputs/seed_100/"
                "test_metrics.csv",
        "role": "Single-initialisation neural efficiencies under the common protocol.",
        "source_command": _REPLICATION_COMMAND,
    },
    {
        "input_id": "N03",
        "path": "results/18_lstm_fair_531/R02_identical_basin_nse_531/conceptual/registered_outputs/"
                "gr4j_common_loss/calibration_summary.csv",
        "role": "GR4J diagnostics recalibrated under the common protocol.",
        "source_command": _REPLICATION_COMMAND,
    },
    {
        "input_id": "N04",
        "path": "results/18_lstm_fair_531/R02_identical_basin_nse_531/conceptual/registered_outputs/"
                "xaj_common_loss/calibration_summary.csv",
        "role": "Xinanjiang diagnostics recalibrated under the common protocol.",
        "source_command": _REPLICATION_COMMAND,
    },
    {
        "input_id": "N05",
        "path": "results/18_lstm_fair_531/R02_identical_basin_nse_531/conceptual/registered_outputs/"
                "hbv_lite_common_loss/calibration_summary.csv",
        "role": "HBV-lite diagnostics recalibrated under the common protocol.",
        "source_command": _REPLICATION_COMMAND,
    },
    {
        "input_id": "N06",
        "path": "draft/papers/10_18_conceptual_lstm_package/deep_dive/R02_common_protocol_20260724/"
                "tables/season_regime_advantage_concentration.csv",
        "role": "Season advantage concentration under the common protocol.",
        "source_cwd": "repository_root",
        "source_artifact": f"{_R02_ANALYSIS}/season_regime_advantage_concentration.csv",
        "source_dependencies": "registered R02 daily predictions and basin regimes; exact key-point reconstruction manifest",
        "source_command": _RECOMPUTE_COMMAND,
    },
    {
        "input_id": "N07",
        "path": "draft/papers/10_18_conceptual_lstm_package/deep_dive/R02_common_protocol_20260724/"
                "tables/flow_regime_advantage_concentration.csv",
        "role": "Flow-group advantage concentration under the common protocol.",
        "source_cwd": "repository_root",
        "source_artifact": f"{_R02_ANALYSIS}/flow_regime_advantage_concentration.csv",
        "source_dependencies": "registered R02 daily predictions and basin regimes; exact key-point reconstruction manifest",
        "source_command": _RECOMPUTE_COMMAND,
    },
    {
        "input_id": "N08",
        "path": "draft/papers/10_18_conceptual_lstm_package/deep_dive/R02_common_protocol_20260724/"
                "tables/joint_regime_advantage_concentration.csv",
        "role": "Joint season-by-flow advantage concentration under the common protocol.",
        "source_command": _RECOMPUTE_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_R02_ANALYSIS}/joint_regime_advantage_concentration.csv",
        "source_dependencies": "registered R02 daily predictions and basin regimes; exact key-point reconstruction manifest",
    },
    {
        "input_id": "N09",
        "path": "draft/papers/10_18_conceptual_lstm_package/deep_dive/R02_common_protocol_20260724/"
                "tables/primary_static_spearman.csv",
        "role": "Basin-attribute rank correlations under the common protocol, with the same "
                "false-discovery-rate family.",
        "source_command": _STATIC_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_R02_ANALYSIS}/D01_structure_diagnostic_r02/tables/primary_static_spearman.csv",
        "source_dependencies": (
            "registered R02 score panel; CAMELS-US static attributes under data/camels_us"
        ),
    },
    {
        "input_id": "N10",
        "path": "draft/papers/10_18_conceptual_lstm_package/deep_dive/R02_common_protocol_20260724/"
                "tables/seasonal_attribute_link_checks.csv",
        "role": "Season-context attribute links under the common protocol.",
        "source_command": _CONTEXT_LINK_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_R02_ANALYSIS}/D04_population_r02/tables/seasonal_attribute_link_checks.csv",
        "source_dependencies": "N09; registered R02 D04 case tables",
    },
    {
        "input_id": "N11",
        "path": "draft/papers/10_18_conceptual_lstm_package/deep_dive/R02_common_protocol_20260724/"
                "tables/flow_attribute_link_checks.csv",
        "role": "Flow-context attribute links under the common protocol.",
        "source_command": _CONTEXT_LINK_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_R02_ANALYSIS}/D04_population_r02/tables/flow_attribute_link_checks.csv",
        "source_dependencies": "N09; registered R02 D04 case tables",
    },
    {
        "input_id": "N12",
        "path": f"{_D07_ROOT}/context_scale_threshold_summary.csv",
        "role": "Absolute and dimensionless advantage summaries for all fixed threshold arms.",
        "source_command": _D07_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D07_ROOT}/context_scale_threshold_summary.csv",
        "source_dependencies": "registered R02 daily predictions; frozen basin regimes; D07 configuration",
    },
    {
        "input_id": "N13",
        "path": f"{_D07_ROOT}/bootstrap_concentration_intervals.csv",
        "role": "Whole-basin stratified bootstrap intervals for absolute and dimensionless concentration.",
        "source_command": _D07_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D07_ROOT}/bootstrap_concentration_intervals.csv",
        "source_dependencies": "N17-N25; D07 configuration",
    },
    {
        "input_id": "N14",
        "path": f"{_D07_ROOT}/fixed_contrasts.csv",
        "role": "Fixed flow, snow-regime, and snow-high seasonal contrasts with clustered intervals.",
        "source_command": _D07_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D07_ROOT}/fixed_contrasts.csv",
        "source_dependencies": "N17-N25; D07 configuration",
    },
    {
        "input_id": "N15",
        "path": f"{_D07_ROOT}/claim_gates.json",
        "role": "Machine-readable outcomes for the four bounded D07 scientific questions.",
        "source_command": _D07_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D07_ROOT}/claim_gates.json",
        "source_dependencies": "N12-N14; D07 manifest",
    },
    {
        "input_id": "N16",
        "path": f"{_D07_ROOT}/D07_manifest.json",
        "role": "D07 command, frozen inputs, output hashes, runtime, and memory record.",
        "source_command": _D07_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D07_ROOT}/D07_manifest.json",
        "source_dependencies": "registered R02 daily predictions; frozen basin regimes; D07 analysis code and configuration",
    },
    *_d07_delta_inputs(),
    {
        "input_id": "N26",
        "path": f"{_D08_ROOT}/protocol_matrix_stability_summary.csv",
        "role": "Full 16-, 12-, 48-cell and 39-attribute stability summary across benchmark protocols.",
        "source_command": _D08_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D08_ROOT}/protocol_matrix_stability_summary.csv",
        "source_dependencies": "registered historical-protocol and common-protocol complete matrices",
    },
    {
        "input_id": "N27",
        "path": f"{_D08_ROOT}/protocol_matrix_cell_deltas.csv",
        "role": "Cell-level protocol differences without selected-row filtering.",
        "source_command": _D08_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D08_ROOT}/protocol_matrix_cell_deltas.csv",
        "source_dependencies": "registered historical-protocol and common-protocol complete matrices",
    },
    {
        "input_id": "N28",
        "path": f"{_D08_ROOT}/D08_manifest.json",
        "role": "D08 command and pinned input/output hashes.",
        "source_command": _D08_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D08_ROOT}/D08_manifest.json",
        "source_dependencies": "N26-N27; D08 analysis code",
    },
    {
        "input_id": "N29",
        "path": f"{_D09_ROOT}/regime_model_bias_summary.csv",
        "role": "Whole-basin flow-group, upper-tail, and variability diagnostics for all four models.",
        "source_command": _D09_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D09_ROOT}/regime_model_bias_summary.csv",
        "source_dependencies": "registered R02 daily predictions; frozen basin regimes; D09 configuration",
    },
    {
        "input_id": "N30",
        "path": f"{_D09_ROOT}/regime_season_event_summary.csv",
        "role": "Observation-defined event magnitude, timing, volume, and hit-rate summaries.",
        "source_command": _D09_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D09_ROOT}/regime_season_event_summary.csv",
        "source_dependencies": "registered R02 daily predictions; N29; D09 configuration",
    },
    {
        "input_id": "N31",
        "path": f"{_D09_ROOT}/diagnostic_decision_gates.json",
        "role": "Predeclared outcomes for the shape-only and snow-specific forcing-proxy branches.",
        "source_command": _D09_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D09_ROOT}/diagnostic_decision_gates.json",
        "source_dependencies": "N29-N30; D09 configuration",
    },
    {
        "input_id": "N32",
        "path": f"{_D09_ROOT}/D09_manifest.json",
        "role": "D09 command, input and output hashes, runtime, memory, and registered-row cross-check.",
        "source_command": _D09_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D09_ROOT}/D09_manifest.json",
        "source_dependencies": "registered R02 daily predictions; frozen basin regimes; D09 analysis code",
    },
    {
        "input_id": "N33",
        "path": f"{_D09_ROOT}/D09_independent_audit.json",
        "role": "Independent raw-input recomputation audit for all four models and both event thresholds.",
        "source_command": "independent read-only recomputation recorded in the D09 audit sidecar",
        "source_cwd": "repository_root",
        "source_artifact": f"{_D09_ROOT}/D09_independent_audit.json",
        "source_dependencies": "N29-N32; eight registered neural result pickles; three conceptual daily-prediction files",
    },
    {
        "input_id": "N34",
        "path": f"{_D10_ROOT}/amplitude_geometry_summary.csv",
        "role": "Daily correlation, amplitude ratio, oracle moment-match, and negative-flow diagnostics for all four models.",
        "source_command": _D10_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D10_ROOT}/amplitude_geometry_summary.csv",
        "source_dependencies": "registered R02 daily predictions; D09 events; D10 configuration",
    },
    {
        "input_id": "N35",
        "path": f"{_D10_ROOT}/event_shape_summary.csv",
        "role": "Equal-basin event-peak concentration summaries at the fixed 90th- and 95th-percentile thresholds.",
        "source_command": _D10_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D10_ROOT}/event_shape_summary.csv",
        "source_dependencies": "registered R02 daily predictions; D09 observation-defined events; D10 configuration",
    },
    {
        "input_id": "N36",
        "path": f"{_D10_ROOT}/event_shape_pairwise_summary.csv",
        "role": "Paired basin-median LSTM event-shape contrasts with whole-basin bootstrap intervals.",
        "source_command": _D10_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D10_ROOT}/event_shape_pairwise_summary.csv",
        "source_dependencies": "N35; D10 fixed bootstrap settings",
    },
    {
        "input_id": "N37",
        "path": f"{_D10_ROOT}/neural_ensemble_shape_summary.csv",
        "role": "Eight individual neural initializations and ensemble event-shape sensitivity.",
        "source_command": _D10_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D10_ROOT}/neural_ensemble_shape_summary.csv",
        "source_dependencies": "eight registered R02 neural prediction files; D09 observation-defined events",
    },
    {
        "input_id": "N38",
        "path": f"{_D10_ROOT}/forcing_disagreement_summary.csv",
        "role": "Within-basin precipitation-product disagreement associations and whole-basin uncertainty.",
        "source_command": _D10_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D10_ROOT}/forcing_disagreement_summary.csv",
        "source_dependencies": "D09 events; Maurer Daymet and NLDAS daily precipitation; D10 configuration",
    },
    {
        "input_id": "N39",
        "path": f"{_D10_ROOT}/forcing_disagreement_quartiles.csv",
        "role": "Descriptive common event-volume error across within-basin precipitation-gap quartiles.",
        "source_command": _D10_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D10_ROOT}/forcing_disagreement_quartiles.csv",
        "source_dependencies": "N38",
    },
    {
        "input_id": "N40",
        "path": f"{_D10_ROOT}/hydroclimate_cause_associations.csv",
        "role": "Fixed hydroclimatic rank associations for common amplitude and high-flow errors.",
        "source_command": _D10_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D10_ROOT}/hydroclimate_cause_associations.csv",
        "source_dependencies": "N34; frozen basin attribute panel; D10 fixed attribute family",
    },
    {
        "input_id": "N41",
        "path": f"{_D10_ROOT}/D10_self_checks.json",
        "role": "D10 row counts, event-key checks, failed upstream-branch state, and undefined-case inventory.",
        "source_command": _D10_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D10_ROOT}/D10_self_checks.json",
        "source_dependencies": "N34-N40; upstream D09 manifest",
    },
    {
        "input_id": "N42",
        "path": f"{_D10_ROOT}/D10_manifest.json",
        "role": "D10 command, resource gate, full input inventory, before-after hashes, and output hashes.",
        "source_command": _D10_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D10_ROOT}/D10_manifest.json",
        "source_dependencies": "N34-N41; registered R02 predictions; D09 events; three forcing products; D10 analysis code",
    },
    {
        "input_id": "N43",
        "path": f"{_D10_ROOT}/D10_independent_audit.json",
        "role": "Independent raw-input recomputation and statistical-boundary audit for D10.",
        "source_command": "independent read-only recomputation recorded in the D10 audit sidecar",
        "source_cwd": "repository_root",
        "source_artifact": f"{_D10_ROOT}/D10_independent_audit.json",
        "source_dependencies": "N34-N42; D09 event files; registered R02 predictions; 1593 forcing files",
    },
    {
        "input_id": "N44",
        "path": f"{_D11_ROOT}/kge_components_by_basin_context.csv",
        "role": "Basin-level 2009 Kling-Gupta efficiency components for all registered models and contexts.",
        "source_command": _D11_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D11_ROOT}/kge_components_by_basin_context.csv",
        "source_dependencies": "registered R02 daily predictions; frozen D11 context definitions",
    },
    {
        "input_id": "N45",
        "path": f"{_D11_ROOT}/kge_component_summary.csv",
        "role": "Equal-basin component summaries and whole-basin intervals for the full period and hydrological contexts.",
        "source_command": _D11_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D11_ROOT}/kge_component_summary.csv",
        "source_dependencies": "N44; D11 frozen bootstrap settings",
    },
    {
        "input_id": "N46",
        "path": f"{_D11_ROOT}/kge_paired_attribution_by_basin_context.csv",
        "role": "Basin-level exact six-order arithmetic attribution of LSTM-versus-conceptual efficiency differences.",
        "source_command": _D11_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D11_ROOT}/kge_paired_attribution_by_basin_context.csv",
        "source_dependencies": "N44; D11 attribution definition",
    },
    {
        "input_id": "N47",
        "path": f"{_D11_ROOT}/kge_paired_attribution_summary.csv",
        "role": "Paired mean efficiency gaps, arithmetic component shares, and whole-basin intervals.",
        "source_command": _D11_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D11_ROOT}/kge_paired_attribution_summary.csv",
        "source_dependencies": "N46; D11 frozen bootstrap settings",
    },
    {
        "input_id": "N48",
        "path": f"{_D11_ROOT}/D11_self_checks.json",
        "role": "Population, undefined-case, reconstruction, closure, and registered conceptual replay checks.",
        "source_command": _D11_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D11_ROOT}/D11_self_checks.json",
        "source_dependencies": "N44-N47; registered conceptual summaries",
    },
    {
        "input_id": "N49",
        "path": f"{_D11_ROOT}/D11_manifest.json",
        "role": "D11 command, resource gate, input inventory, output hashes, runtime, and memory record.",
        "source_command": _D11_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_D11_ROOT}/D11_manifest.json",
        "source_dependencies": "N44-N48; registered R02 predictions; D11 analysis code and configuration",
    },
    {
        "input_id": "N50",
        "path": f"{_D11_ROOT}/D11_independent_audit.json",
        "role": "Independent raw-input recomputation of every D11 component, attribution, summary, bootstrap, and hash.",
        "source_command": "independent read-only recomputation recorded in the D11 audit sidecar",
        "source_cwd": "repository_root",
        "source_artifact": f"{_D11_ROOT}/D11_independent_audit.json",
        "source_dependencies": "N44-N49; registered R02 daily predictions; registered conceptual summaries",
    },
    {
        "input_id": "N51",
        "path": (f"{_R02_ANALYSIS}/D04_population_r02/tables/"
                 "conceptual_vs_lstm_by_case_flow_group.csv"),
        "role": "Row-level (basin x flow group) best-conceptual and LSTM MAE with day counts, used for the day-weighted flow accounting.",
        "source_command": "python -X utf8 -m src.lstm_fair_531.scripts.run_r02_key_point_recomputation",
        "source_cwd": "repository_root",
        "source_artifact": (f"{_R02_ANALYSIS}/D04_population_r02/tables/"
                            "conceptual_vs_lstm_by_case_flow_group.csv"),
        "source_dependencies": "registered R02 daily predictions; frozen flow-group context definitions",
    },
    {
        "input_id": "N52",
        "path": f"{_E02_DOSE_ROOT}/dose_response_summary.csv",
        "role": ("Median variability ratio and daily correlation for each model and objective arm, with the "
                 "paired change against the plain-NSE baseline and its whole-basin interval."),
        "source_command": _E02_DOSE_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_E02_DOSE_ROOT}/dose_response_summary.csv",
        "source_dependencies": "registered E01 and E02 daily predictions; three registered objective arms",
    },
    {
        "input_id": "N53",
        "path": f"{_E02_DOSE_ROOT}/dose_response_monotonicity.csv",
        "role": ("Whether each model moves monotonically along the objective axis, with the span of the "
                 "variability ratio and of the daily correlation."),
        "source_command": _E02_DOSE_COMMAND,
        "source_cwd": "repository_root",
        "source_artifact": f"{_E02_DOSE_ROOT}/dose_response_monotonicity.csv",
        "source_dependencies": "N52",
    },
    {
        "input_id": "N54",
        "path": f"{_E02_ROOT}/protocol/e02_reverse_tail_contract.json",
        "role": ("Pre-registered contract for the reverse arm, recording the predicted direction and the "
                 "falsifier before the run started."),
        "source_command": ("written before execution from "
                           "src/loss_mechanism_531/configs/e02_reverse_tail_contract.json"),
        "source_cwd": "repository_root",
        "source_artifact": f"{_E02_ROOT}/protocol/e02_reverse_tail_contract.json",
        "source_dependencies": "E01 contract; frozen period definitions",
    },
    {
        "input_id": "N55",
        "path": f"{_E02_ROOT}/protocol/source_provenance.json",
        "role": ("Objective-function source hashes as used for the reverse arm, compared with the E01 "
                 "preflight registry, because src/loss_mechanism_531 is not tracked by version control."),
        "source_command": "recorded read-only alongside the reverse-arm execution",
        "source_cwd": "repository_root",
        "source_artifact": f"{_E02_ROOT}/protocol/source_provenance.json",
        "source_dependencies": "E01 preflight source registry; current objective-function sources",
    },
]

_REGENERATED_PREFIXES = ("tables/", "figures/", "audit/stale_reference_audit")
_EXTERNAL_ARCHIVE_REASON = "Direct package-build evidence input preserved in the immutable external archive."
_VERSION_CONTROL_REASON = "Canonical top-level manuscript artifact retained for direct review."
_REGENERATE_REASON = "Deterministically generated by the single package-build command from registered inputs."
_EXCLUDE_REASON = "Not required to rebuild or audit the top-level manuscript artifacts in the minimal snapshot."


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _classify(relative: str, top_level_outputs: set, archived: set) -> tuple:
    if relative in archived:
        return "external_archive", _EXTERNAL_ARCHIVE_REASON
    if relative in top_level_outputs:
        return "version_control", _VERSION_CONTROL_REASON
    if any(relative.startswith(prefix) for prefix in _REGENERATED_PREFIXES):
        return "regenerate", _REGENERATE_REASON
    return "exclude", _EXCLUDE_REASON


DEFAULT_ARCHIVE = Path("results/paper_snapshot_archives/conceptual_lstm_531_external_inputs_20260726.zip")


def refresh(policy_path: Path = POLICY_PATH, package_root: Path = PACKAGE_ROOT,
            archive_path: Path = DEFAULT_ARCHIVE) -> dict:
    policy = json.loads(policy_path.read_text(encoding="utf-8"))

    historical_inputs = [item for item in policy["external_inputs"] if item["input_id"].startswith("I")]
    external_inputs = historical_inputs + [dict(item) for item in _IDENTICAL_INPUTS]

    seen = set()
    for item in external_inputs:
        path = Path(item["path"])
        if not path.is_file():
            raise FileNotFoundError(f"Registered input is missing: {path}")
        if item["path"] in seen:
            raise ValueError(f"Duplicate registered input path: {item['path']}")
        seen.add(item["path"])
        item["bytes"] = path.stat().st_size
        item["sha256"] = _sha256(path)
    policy["external_inputs"] = external_inputs

    retained_code_inputs = [
        item for item in policy["code_inputs"]
        if item["input_id"] not in {row["input_id"] for row in _ROBUSTNESS_CODE_INPUTS}
    ]
    policy["code_inputs"] = retained_code_inputs + [dict(item) for item in _ROBUSTNESS_CODE_INPUTS]
    overlay_additions = [
        *(item["path"] for item in _ROBUSTNESS_CODE_INPUTS),
        "test/test_id18_context_scale_threshold_robustness.py",
    ]
    policy["proposed_version_control_files"] = list(dict.fromkeys([
        *policy["proposed_version_control_files"],
        *overlay_additions,
    ]))

    # Re-pin the version-controlled model sources. These drifted once already: the
    # Xinanjiang calibration objective was hardened during the common-protocol work and
    # the policy was not updated, which silently broke --verify-snapshot.
    for item in policy["code_inputs"]:
        path = Path(item["path"])
        if not path.is_file():
            raise FileNotFoundError(f"Registered code input is missing: {path}")
        data = path.read_bytes()
        if item["digest_mode"] == "text_lf":
            data = data.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
        item["bytes"] = len(data)
        item["sha256"] = hashlib.sha256(data).hexdigest()

    # Every registered input that lives inside the package is shipped in the archive.
    archived = {
        Path(item["path"]).relative_to(package_root).as_posix()
        for item in external_inputs
        if Path(item["path"]).is_relative_to(package_root)
    }
    top_level_outputs = set(policy["top_level_outputs"])

    baseline = []
    for path in sorted(package_root.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(package_root).as_posix()
        if relative.split("/")[0] == "reproducibility":
            continue
        classification, reason = _classify(relative, top_level_outputs, archived)
        baseline.append({
            "path": relative,
            "bytes": path.stat().st_size,
            "sha256": _sha256(path),
            "classification": classification,
            "reason": reason,
        })
    policy["baseline_files"] = baseline
    policy["baseline_file_count"] = len(baseline)
    policy["baseline_total_bytes"] = sum(item["bytes"] for item in baseline)
    policy["classification_counts"] = {
        name: sum(1 for item in baseline if item["classification"] == name)
        for name in ["exclude", "regenerate", "version_control", "external_archive"]
    }
    policy["classification_byte_totals"] = {
        name: sum(item["bytes"] for item in baseline if item["classification"] == name)
        for name in ["exclude", "regenerate", "version_control", "external_archive"]
    }
    # Rebuild the transport archive and pin what was actually written. Registering the
    # digest before the bytes exist is what made this policy impossible to bootstrap.
    from src.lstm_fair_531.scripts.build_manuscript_evidence_package import build_external_archive

    bundle = policy["external_archive_bundle"]
    bundle["path"] = archive_path.as_posix()
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    build_external_archive(policy, archive_path)
    bundle["member_count"] = len(external_inputs)
    bundle["bytes"] = archive_path.stat().st_size
    bundle["sha256"] = _sha256(archive_path)
    bundle["source_command"] = (
        "python -X utf8 -m src.lstm_fair_531.scripts.build_manuscript_evidence_package "
        f"--build-external-archive {archive_path.as_posix()}"
    )
    policy["protocols"] = {
        "primary": IDENTICAL_PROTOCOL_ID,
        "registered": {
            protocol_id: {
                "loss_protocol": get_protocol(protocol_id).loss_protocol,
                "label": get_protocol(protocol_id).label,
                "description": get_protocol(protocol_id).description,
            }
            for protocol_id in [HISTORICAL_PROTOCOL_ID, IDENTICAL_PROTOCOL_ID]
        },
    }
    policy_path.write_text(json.dumps(policy, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return policy


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--policy", type=Path, default=POLICY_PATH)
    parser.add_argument("--package-root", type=Path, default=PACKAGE_ROOT)
    parser.add_argument("--archive", type=Path, default=DEFAULT_ARCHIVE)
    args = parser.parse_args()
    policy = refresh(args.policy, args.package_root, args.archive)
    print(f"external inputs: {len(policy['external_inputs'])}")
    print(f"baseline files:  {policy['baseline_file_count']}")
    print(f"classification:  {policy['classification_counts']}")
    bundle = policy["external_archive_bundle"]
    print(f"archive:         {bundle['path']} ({bundle['bytes']} bytes)")
    print(f"archive sha256:  {bundle['sha256']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
