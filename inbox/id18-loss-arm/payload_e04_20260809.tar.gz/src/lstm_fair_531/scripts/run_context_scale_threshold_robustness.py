"""Run the bounded D07 context scale and threshold robustness analysis.

The loader keeps only an accumulated eight-seed neural ensemble in memory and
reads one conceptual-model CSV at a time. This avoids the multi-gigabyte full
daily panel used by the historical reconstruction while preserving its exact
metric definitions.
"""
from __future__ import annotations

import argparse
import gc
import hashlib
import json
import os
import pickle
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import psutil

from src.lstm_fair_531.scripts.analyze_identical_basin_nse_replication import (
    EVALUATION_END,
    EVALUATION_START,
    FIXED_SEEDS,
    _prediction_variables,
    _xarray_series,
)
from src.lstm_fair_531.scripts.context_scale_threshold_robustness import (
    BOOTSTRAP_RESAMPLES,
    BOOTSTRAP_SEED,
    EXPERIMENT_ID,
    FLOW_THRESHOLD_ARMS,
    MIN_CONTEXT_DAYS,
    build_basin_model_context_rows,
    build_scale_targets,
    bootstrap_concentration_intervals,
    compute_fixed_contrasts,
    summarize_scale_concentration,
)


EXPECTED_OUTPUTS = (
    "context_scale_threshold_summary.csv",
    "bootstrap_concentration_intervals.csv",
    "fixed_contrasts.csv",
    "claim_gates.json",
    "D07_manifest.json",
)
DELTA_FAMILIES = ("season", "flow", "joint")
THRESHOLD_LABELS = ("q05_q95", "q10_q90", "q20_q80")
CONTEXT_COLUMNS = {"season": "season", "flow": "flow_group", "joint": "joint_context"}

REPO_ROOT = Path(__file__).resolve().parents[3]
R02_ROOT = REPO_ROOT / "results/18_lstm_fair_531/R02_identical_basin_nse_531"
DEFAULT_OUTPUT_DIR = REPO_ROOT / "results/18_lstm_fair_531" / EXPERIMENT_ID
DEFAULT_CONFIG = REPO_ROOT / "src/lstm_fair_531/configs/context_scale_threshold_robustness_20260726.json"
DEFAULT_RUN_LEDGER = R02_ROOT / "registry/run_ledger.json"
DEFAULT_CONCEPTUAL_MANIFEST = R02_ROOT / "conceptual/conceptual_prediction_manifest.json"
DEFAULT_REGIMES = REPO_ROOT / (
    "draft/papers/10_18_conceptual_lstm_package/deep_dive/"
    "D01_structure_diagnostic_20260709/tables/basin_attribute_panel.csv"
)
REGISTERED_Q10_ROOT = R02_ROOT / "analysis_key_points_20260724"
MIN_STREAMING_AVAILABLE_GIB = 4.0


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _relative(path: Path) -> str:
    resolved = Path(path).resolve()
    try:
        return resolved.relative_to(REPO_ROOT).as_posix()
    except ValueError as error:
        raise ValueError(f"Registered path lies outside the repository: {resolved}") from error


def _load_json(path: Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _source(role: str, path: Path, expected_sha256: str | None = None) -> dict:
    actual = _sha256(path)
    if expected_sha256 is not None and actual != expected_sha256:
        raise ValueError(f"Hash mismatch for {role}: {path}")
    return {"role": role, "path": _relative(path), "sha256": actual}


def _normalize_basin_id(value) -> str:
    return str(value).replace(".0", "").strip().zfill(8)


def _available_gib() -> float:
    return psutil.virtual_memory().available / 2**30


def _current_rss_gib() -> float:
    return psutil.Process(os.getpid()).memory_info().rss / 2**30



def manifest_evaluation_dates() -> dict[str, str]:
    """Serialize registered evaluation constants regardless of their source type."""
    return {
        "evaluation_start": str(pd.Timestamp(EVALUATION_START).date()),
        "evaluation_end": str(pd.Timestamp(EVALUATION_END).date()),
    }

def _validate_config(path: Path) -> dict:
    config = _load_json(path)
    if config.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("D07 configuration experiment identifier mismatch")
    arms = tuple(
        (float(item["low_quantile"]), float(item["high_quantile"]))
        for item in config.get("flow_threshold_arms", [])
    )
    if arms != FLOW_THRESHOLD_ARMS:
        raise ValueError(f"D07 thresholds must be exactly {FLOW_THRESHOLD_ARMS}; got {arms}")
    if int(config.get("basin_count", 0)) != 531:
        raise ValueError("D07 configuration must retain all 531 basins")
    if int(config["bootstrap"]["resamples"]) != BOOTSTRAP_RESAMPLES:
        raise ValueError("D07 bootstrap resample count drifted")
    if int(config["bootstrap"]["seed"]) != BOOTSTRAP_SEED:
        raise ValueError("D07 bootstrap seed drifted")
    return config


def _load_regimes(path: Path) -> pd.DataFrame:
    panel = pd.read_csv(path, dtype={"basin_id": str, "gauge_id": str})
    basin_column = "basin_id" if "basin_id" in panel.columns else "gauge_id"
    if "regime" not in panel.columns:
        raise ValueError("Basin attribute panel lacks the frozen regime column")
    regimes = panel[[basin_column, "regime"]].rename(columns={basin_column: "basin_id"})
    regimes["basin_id"] = regimes["basin_id"].map(_normalize_basin_id)
    regimes = regimes.drop_duplicates("basin_id").reset_index(drop=True)
    if len(regimes) != 531 or regimes["basin_id"].nunique() != 531:
        raise ValueError(f"Expected 531 frozen basin regimes; found {len(regimes)}")
    if "04213075" not in set(regimes["basin_id"]):
        raise ValueError("Frozen basin 04213075 is missing from D07")
    return regimes


def _load_neural_ensemble_low_memory(ledger_path: Path) -> tuple[dict, list[dict]]:
    ledger = _load_json(ledger_path)
    sources = [_source("neural_run_ledger", ledger_path)]
    if ledger.get("status") != "completed":
        raise ValueError("Neural run ledger is not completed")
    protocol_path = Path(ledger["protocol_manifest_path"])
    sources.append(
        _source("common_loss_protocol", protocol_path, str(ledger["protocol_manifest_sha256"]))
    )
    output_records = ledger.get("output_records", [])
    seeds = tuple(int(record.get("seed", -1)) for record in output_records)
    if seeds != FIXED_SEEDS:
        raise ValueError(f"Neural output seeds must be {FIXED_SEEDS}; got {seeds}")

    expected_dates = pd.date_range(EVALUATION_START, EVALUATION_END, freq="D")
    ensemble: dict[str, dict] = {}
    reference_basins: set[str] | None = None
    for seed, record in zip(FIXED_SEEDS, output_records):
        prediction_path = Path(record["predictions_path"])
        expected_hash = str(record["predictions_sha256"])
        source = _source(f"neural_seed_{seed}_predictions", prediction_path, expected_hash)
        with open(prediction_path, "rb") as handle:
            payload = pickle.load(handle)
        if _sha256(prediction_path) != expected_hash:
            raise ValueError(f"Seed {seed} prediction file changed while being read")
        if not isinstance(payload, dict) or len(payload) != 531:
            raise ValueError(f"Seed {seed} must contain exactly 531 basin prediction objects")
        current_basins = {_normalize_basin_id(value) for value in payload}
        if reference_basins is None:
            reference_basins = current_basins
        elif current_basins != reference_basins:
            raise ValueError(f"Seed {seed} basin set differs from the first seed")
        for raw_basin_id in sorted(payload, key=str):
            basin_id = _normalize_basin_id(raw_basin_id)
            dataset = payload[raw_basin_id]["1D"]["xr"]
            obs_variable, sim_variable = _prediction_variables(dataset)
            obs = _xarray_series(dataset, obs_variable)
            sim = _xarray_series(dataset, sim_variable)
            dates = pd.DatetimeIndex(dataset["date"].values)
            if not dates.equals(expected_dates):
                raise ValueError(f"Seed {seed}, basin {basin_id} has the wrong evaluation dates")
            valid = np.isfinite(obs)
            if np.any(valid & ~np.isfinite(sim)):
                raise ValueError(f"Seed {seed}, basin {basin_id} has a non-finite prediction")
            dates = dates[valid]
            obs = obs[valid].astype(float)
            sim = sim[valid].astype(float)
            if seed == FIXED_SEEDS[0]:
                ensemble[basin_id] = {"dates": dates, "obs": obs, "sim_sum": sim.copy()}
            else:
                reference = ensemble[basin_id]
                if not dates.equals(reference["dates"]):
                    raise ValueError(f"Seed {seed}, basin {basin_id} has a different valid-date mask")
                if not np.array_equal(obs, reference["obs"]):
                    raise ValueError(f"Seed {seed}, basin {basin_id} observations differ")
                reference["sim_sum"] += sim
        sources.append(source)
        del payload
        gc.collect()
    for record in ensemble.values():
        record["sim"] = record.pop("sim_sum") / len(FIXED_SEEDS)
    if len(ensemble) != 531 or "04213075" not in ensemble:
        raise ValueError("Low-memory ensemble did not retain the frozen 531-basin population")
    return ensemble, sources


def _build_all_delta_rows(
    *,
    ensemble: dict,
    conceptual_manifest_path: Path,
    regimes: pd.DataFrame,
) -> tuple[dict[str, pd.DataFrame], list[dict]]:
    manifest = _load_json(conceptual_manifest_path)
    sources = [_source("conceptual_prediction_manifest", conceptual_manifest_path)]
    if manifest.get("status") != "completed" or int(manifest.get("basin_count", 0)) != 531:
        raise ValueError("Conceptual prediction manifest is not a completed 531-basin artifact")
    protocol_path = Path(manifest["protocol_manifest_path"])
    sources.append(
        _source("conceptual_common_loss_protocol", protocol_path, str(manifest["protocol_manifest_sha256"]))
    )
    artifacts = manifest.get("artifacts", [])
    if {item.get("model") for item in artifacts} != {"GR4J", "XAJ", "HBV-lite"}:
        raise ValueError("D07 requires exactly GR4J, XAJ, and HBV-lite")
    regime_map = regimes.set_index("basin_id")["regime"].to_dict()
    frames_by_threshold: dict[str, list[pd.DataFrame]] = {label: [] for label in THRESHOLD_LABELS}
    for artifact in artifacts:
        model = str(artifact["model"])
        delta_model = "HBV" if model == "HBV-lite" else model
        path = Path(artifact["daily_predictions_path"])
        expected_hash = str(artifact["daily_predictions_sha256"])
        sources.append(_source(f"conceptual_{model}_daily_predictions", path, expected_hash))
        daily = pd.read_csv(path, dtype={"basin_id": str}, parse_dates=["date"])
        daily["basin_id"] = daily["basin_id"].map(_normalize_basin_id)
        if len(daily) != 1_939_212 or daily["basin_id"].nunique() != 531:
            raise ValueError(f"{model} daily artifact does not contain 1,939,212 rows over 531 basins")
        if daily.duplicated(["basin_id", "date"]).any():
            raise ValueError(f"{model} daily artifact has duplicate basin-date rows")
        for basin_id, group in daily.groupby("basin_id", sort=True):
            group = group.sort_values("date").reset_index(drop=True)
            neural = ensemble[basin_id]
            dates = pd.DatetimeIndex(group["date"])
            if not dates.equals(neural["dates"]):
                raise ValueError(f"{model}, basin {basin_id} date mask differs from the neural ensemble")
            observation = group["obs"].to_numpy(dtype=float)
            if not np.allclose(observation, neural["obs"], rtol=1e-5, atol=1e-4):
                raise ValueError(f"{model}, basin {basin_id} observations differ from the neural ensemble")
            conceptual_sim = group["sim"].to_numpy(dtype=float)
            for threshold_label, (low_quantile, high_quantile) in zip(
                THRESHOLD_LABELS, FLOW_THRESHOLD_ARMS
            ):
                frame = build_basin_model_context_rows(
                    basin_id=basin_id,
                    regime=regime_map[basin_id],
                    dates=neural["dates"],
                    obs=neural["obs"],
                    lstm_sim=neural["sim"],
                    conceptual_sim=conceptual_sim,
                    conceptual_model=delta_model,
                    low_quantile=low_quantile,
                    high_quantile=high_quantile,
                    minimum_joint_days=MIN_CONTEXT_DAYS,
                )
                frames_by_threshold[threshold_label].append(frame)
        if _sha256(path) != expected_hash:
            raise ValueError(f"{model} daily artifact changed while being read")
        del daily
        gc.collect()
    return {
        label: pd.concat(frames, ignore_index=True)
        for label, frames in frames_by_threshold.items()
    }, sources


def _family_delta(all_rows: pd.DataFrame, family: str) -> pd.DataFrame:
    context_column = CONTEXT_COLUMNS[family]
    selected = all_rows[all_rows["family"] == family].copy()
    selected[context_column] = selected["context"]
    selected["case_type"] = "population_all"
    columns = [
        "basin_id", "regime", "case_type", context_column, "conceptual_model",
        "mae_minus_lstm", "nse_minus_lstm", "conceptual_mae", "lstm_mae",
        "conceptual_nse", "lstm_nse", "n_days",
    ]
    return selected[columns].reset_index(drop=True)


def _verify_q10(summary: pd.DataFrame, family: str) -> None:
    registered_path = REGISTERED_Q10_ROOT / f"{family}_regime_advantage_concentration.csv"
    registered = pd.read_csv(registered_path)
    context_column = CONTEXT_COLUMNS[family]
    merged = summary.merge(
        registered,
        on=["regime", context_column],
        validate="one_to_one",
        suffixes=("_new", "_registered"),
    )
    if len(merged) != len(registered):
        raise ValueError(f"q10/q90 {family} key set does not match the registered table")
    pairs = {
        "n_contexts_new": "n_contexts_registered",
        "context_share_new": "context_share_registered",
        "positive_absolute_sum": "positive_best_gap_sum",
        "positive_absolute_share": "positive_best_gap_share",
        "absolute_concentration_ratio": "gap_concentration_ratio",
        "median_absolute_advantage": "median_best_conceptual_mae_minus_lstm",
        "shared_failure_rate_new": "shared_failure_rate_registered",
    }
    for actual, expected in pairs.items():
        np.testing.assert_allclose(
            pd.to_numeric(merged[actual]),
            pd.to_numeric(merged[expected]),
            rtol=0,
            atol=1e-12,
            err_msg=f"D07 q10/q90 drift in {family}: {actual}",
        )


def _claim_gates(summary: pd.DataFrame, intervals: pd.DataFrame, contrasts: pd.DataFrame) -> dict:
    flow = summary[(summary["family"] == "flow") & (summary["scope"] == "all_basins")]
    raw_high = flow[flow["flow_group"] == "high"]
    raw_supported = bool(
        len(raw_high) == 3 and raw_high["absolute_concentration_ratio"].gt(1).all()
    )
    relative_supported_by_threshold = {}
    for threshold_label in THRESHOLD_LABELS:
        arm = flow[flow["threshold_label"] == threshold_label].set_index("flow_group")
        ci = intervals[
            (intervals["threshold_label"] == threshold_label)
            & (intervals["family"] == "flow")
            & (intervals["scope"] == "all_basins")
            & (intervals["metric"] == "relative_concentration_ratio")
        ].set_index("flow_group")
        supported = bool(
            arm.loc["high", "relative_concentration_ratio"]
            == arm["relative_concentration_ratio"].max()
            and ci.loc["high", "ci_low"] > 1
        )
        relative_supported_by_threshold[threshold_label] = supported
    snow = contrasts[contrasts["family"] == "snow_vs_non_snow_by_flow"]
    snow_high = snow[snow["flow_group"] == "high"]
    q10_snow_high = snow_high[snow_high["threshold_label"] == "q10_q90"]
    snow_supported = bool(
        len(snow_high) == 3
        and snow_high["estimate"].gt(0).all()
        and len(q10_snow_high) == 1
        and q10_snow_high.iloc[0]["p_holm"] < 0.05
        and q10_snow_high.iloc[0]["ci_low"] > 0
    )
    seasonal = contrasts[
        (contrasts["family"] == "snow_high_season_pairwise")
        & (contrasts["threshold_label"] == "q10_q90")
    ]
    supported_seasonal_pairs = seasonal[
        (seasonal["p_holm"] < 0.05)
        & ((seasonal["ci_low"] > 0) | (seasonal["ci_high"] < 0))
    ][["left", "right", "estimate", "ci_low", "ci_high", "p_holm"]].to_dict("records")
    return {
        "raw_high_flow_dominates_absolute_error_savings": {
            "supported": raw_supported,
            "rule": "absolute concentration ratio above one in all three threshold arms",
        },
        "high_flow_dominates_scale_free_relative_skill": {
            "supported": all(relative_supported_by_threshold.values()),
            "by_threshold": relative_supported_by_threshold,
            "rule": "high is largest and its 95% interval excludes one in every arm",
        },
        "snow_amplifies_relative_advantage_beyond_flow_scale": {
            "supported": snow_supported,
            "rule": "positive in all arms and q10/q90 high-flow Holm-adjusted interval excludes zero",
        },
        "snow_high_season_ordering": {
            "supported_pairs_q10_q90": supported_seasonal_pairs,
            "rule": "common-basin Holm-adjusted interval excludes zero",
        },
    }


def run(
    *,
    output_dir: Path,
    config_path: Path,
    run_ledger_path: Path,
    conceptual_manifest_path: Path,
    regimes_path: Path,
) -> dict:
    started = time.perf_counter()
    started_utc = datetime.now(timezone.utc).isoformat()
    available_before = _available_gib()
    if available_before < MIN_STREAMING_AVAILABLE_GIB:
        raise MemoryError(
            f"Low-memory D07 requires at least {MIN_STREAMING_AVAILABLE_GIB:.1f} GiB available; "
            f"found {available_before:.2f} GiB"
        )
    output_dir = Path(output_dir)
    if output_dir.exists():
        raise FileExistsError(f"D07 refuses to overwrite an existing output directory: {output_dir}")
    output_dir.mkdir(parents=True)
    peak_rss = _current_rss_gib()

    config = _validate_config(config_path)
    regimes = _load_regimes(regimes_path)
    ensemble, neural_sources = _load_neural_ensemble_low_memory(run_ledger_path)
    peak_rss = max(peak_rss, _current_rss_gib())
    rows_by_threshold, conceptual_sources = _build_all_delta_rows(
        ensemble=ensemble,
        conceptual_manifest_path=conceptual_manifest_path,
        regimes=regimes,
    )
    peak_rss = max(peak_rss, _current_rss_gib())
    del ensemble
    gc.collect()

    all_summaries = []
    all_intervals = []
    all_contrasts = []
    targets_by_arm: dict[tuple[str, str], pd.DataFrame] = {}
    output_paths: list[Path] = []
    for threshold_label, (low_quantile, high_quantile) in zip(
        THRESHOLD_LABELS, FLOW_THRESHOLD_ARMS
    ):
        threshold_dir = output_dir / "thresholds" / threshold_label
        threshold_dir.mkdir(parents=True)
        all_rows = rows_by_threshold[threshold_label]
        for family in DELTA_FAMILIES:
            context_column = CONTEXT_COLUMNS[family]
            delta = _family_delta(all_rows, family)
            targets = build_scale_targets(delta, context_column)
            if family == "joint":
                split = targets["joint_context"].str.split("__", n=1, expand=True)
                targets["season"] = split[0]
                targets["flow_group"] = split[1]
            targets_by_arm[(threshold_label, family)] = targets
            regime_summary = summarize_scale_concentration(targets, context_column)
            if threshold_label == "q10_q90":
                _verify_q10(regime_summary, family)
            aggregate_targets = targets.copy()
            aggregate_targets["regime"] = "all_basins"
            aggregate_summary = summarize_scale_concentration(aggregate_targets, context_column)
            for scope, frame in (("regime_cell", regime_summary), ("all_basins", aggregate_summary)):
                frame = frame.copy()
                frame.insert(0, "scope", scope)
                frame.insert(0, "family", family)
                frame.insert(0, "high_quantile", high_quantile)
                frame.insert(0, "low_quantile", low_quantile)
                frame.insert(0, "threshold_label", threshold_label)
                all_summaries.append(frame)
            for scope, group_by_regime in (("regime_cell", True), ("all_basins", False)):
                intervals = bootstrap_concentration_intervals(
                    targets,
                    context_column,
                    group_by_regime=group_by_regime,
                    n_resamples=BOOTSTRAP_RESAMPLES,
                    seed=BOOTSTRAP_SEED,
                )
                intervals.insert(0, "scope", scope)
                intervals.insert(0, "family", family)
                intervals.insert(0, "high_quantile", high_quantile)
                intervals.insert(0, "low_quantile", low_quantile)
                intervals.insert(0, "threshold_label", threshold_label)
                all_intervals.append(intervals)

            delta_path = threshold_dir / f"{family}_context_delta.csv"
            targets_path = threshold_dir / f"{family}_scale_targets.csv"
            summary_path = threshold_dir / f"{family}_scale_summary.csv"
            delta.to_csv(delta_path, index=False)
            targets.to_csv(targets_path, index=False)
            pd.concat([regime_summary, aggregate_summary], ignore_index=True).to_csv(summary_path, index=False)
            output_paths.extend([delta_path, targets_path, summary_path])

        contrasts = compute_fixed_contrasts(
            targets_by_arm[(threshold_label, "flow")],
            targets_by_arm[(threshold_label, "joint")],
            n_resamples=BOOTSTRAP_RESAMPLES,
            seed=BOOTSTRAP_SEED,
        )
        contrasts.insert(0, "high_quantile", high_quantile)
        contrasts.insert(0, "low_quantile", low_quantile)
        contrasts.insert(0, "threshold_label", threshold_label)
        all_contrasts.append(contrasts)
        peak_rss = max(peak_rss, _current_rss_gib())

    summary = pd.concat(all_summaries, ignore_index=True)
    intervals = pd.concat(all_intervals, ignore_index=True)
    contrasts = pd.concat(all_contrasts, ignore_index=True)
    gates = _claim_gates(summary, intervals, contrasts)
    summary_path = output_dir / EXPECTED_OUTPUTS[0]
    intervals_path = output_dir / EXPECTED_OUTPUTS[1]
    contrasts_path = output_dir / EXPECTED_OUTPUTS[2]
    gates_path = output_dir / EXPECTED_OUTPUTS[3]
    summary.to_csv(summary_path, index=False)
    intervals.to_csv(intervals_path, index=False)
    contrasts.to_csv(contrasts_path, index=False)
    gates_path.write_text(json.dumps(gates, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    output_paths.extend([summary_path, intervals_path, contrasts_path, gates_path])

    sources = [
        _source("d07_configuration", config_path),
        _source("frozen_basin_regimes", regimes_path),
        *neural_sources,
        *conceptual_sources,
    ]
    for family in DELTA_FAMILIES:
        registered = REGISTERED_Q10_ROOT / f"{family}_regime_advantage_concentration.csv"
        sources.append(_source(f"registered_q10_{family}_summary", registered))
    code_paths = [Path(__file__), REPO_ROOT / "src/lstm_fair_531/scripts/context_scale_threshold_robustness.py"]
    manifest = {
        "schema_version": "1.0",
        "experiment_id": EXPERIMENT_ID,
        "status": "completed",
        "purpose": config["purpose"],
        "models": config["models"],
        "basin_count": 531,
        "contains_basin_04213075": True,
        **manifest_evaluation_dates(),
        "threshold_arms": config["flow_threshold_arms"],
        "minimum_joint_days": MIN_CONTEXT_DAYS,
        "bootstrap": config["bootstrap"],
        "exact_command": "python -X utf8 -m src.lstm_fair_531.scripts.run_context_scale_threshold_robustness",
        "working_directory": ".",
        "loader_mode": "sequential_seed_and_conceptual_model_low_memory",
        "q10_q90_registered_matrix_verification": "passed_all_16_12_48_cells",
        "inputs": sources,
        "analysis_code": [
            {"path": _relative(path), "sha256": _sha256(path)} for path in code_paths
        ],
        "outputs": [
            {"path": _relative(path), "bytes": path.stat().st_size, "sha256": _sha256(path)}
            for path in sorted(output_paths)
        ],
        "claim_gates": gates,
        "started_at_utc": started_utc,
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "runtime_seconds": time.perf_counter() - started,
        "available_memory_gib_before": available_before,
        "available_memory_gib_after": _available_gib(),
        "peak_process_rss_gib_observed": peak_rss,
    }
    manifest_path = output_dir / EXPECTED_OUTPUTS[4]
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return manifest


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--run-ledger", type=Path, default=DEFAULT_RUN_LEDGER)
    parser.add_argument("--conceptual-manifest", type=Path, default=DEFAULT_CONCEPTUAL_MANIFEST)
    parser.add_argument("--regimes", type=Path, default=DEFAULT_REGIMES)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    manifest = run(
        output_dir=args.output_dir,
        config_path=args.config,
        run_ledger_path=args.run_ledger,
        conceptual_manifest_path=args.conceptual_manifest,
        regimes_path=args.regimes,
    )
    print(json.dumps({
        "experiment_id": manifest["experiment_id"],
        "status": manifest["status"],
        "runtime_seconds": manifest["runtime_seconds"],
        "peak_process_rss_gib_observed": manifest["peak_process_rss_gib_observed"],
        "claim_gates": manifest["claim_gates"],
    }, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
