"""Scale-aware and threshold-robust context diagnostics for the ID18 paper.

The module is deliberately limited to post-hoc summaries of the registered
long short-term memory ensemble and the three registered conceptual models.
It does not train, calibrate, select, or add a model.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from src.lstm_fair_531.scripts.seasonal_residual_deep_dive import (
    flow_group_labels,
    nse_or_nan,
    season_labels,
)


EXPERIMENT_ID = "D07_context_scale_threshold_robustness_20260726"
MODELS = ("LSTM_ensemble_8seed", "GR4J", "XAJ", "HBV-lite")
FLOW_THRESHOLD_ARMS = ((0.05, 0.95), (0.10, 0.90), (0.20, 0.80))
MIN_CONTEXT_DAYS = 10
BOOTSTRAP_RESAMPLES = 10_000
BOOTSTRAP_SEED = 20260726


def symmetric_relative_advantage(conceptual_mae, lstm_mae):
    """Return the bounded, dimensionless conceptual-minus-neural MAE advantage.

    Positive values mean the conceptual error is larger. When both errors are
    zero the result is defined as zero. Scalars return ``float`` and array-like
    inputs return a NumPy array.
    """
    conceptual = np.asarray(conceptual_mae, dtype=float)
    neural = np.asarray(lstm_mae, dtype=float)
    denominator = conceptual + neural
    result = np.zeros(np.broadcast_shapes(conceptual.shape, neural.shape), dtype=float)
    conceptual, neural = np.broadcast_arrays(conceptual, neural)
    denominator = conceptual + neural
    np.divide(
        2.0 * (conceptual - neural),
        denominator,
        out=result,
        where=denominator != 0,
    )
    result = np.clip(result, -2.0, 2.0)
    if result.ndim == 0:
        return float(result)
    return result


def _basin_ids(values: pd.Series) -> pd.Series:
    return values.astype(str).str.replace(r"\.0$", "", regex=True).str.zfill(8)


def build_scale_targets(delta: pd.DataFrame, context_col: str) -> pd.DataFrame:
    """Collapse three conceptual rows to one best-MAE row per basin-context."""
    required = {
        "basin_id",
        "regime",
        context_col,
        "conceptual_model",
        "conceptual_mae",
        "lstm_mae",
        "mae_minus_lstm",
    }
    missing = sorted(required - set(delta.columns))
    if missing:
        raise ValueError(f"Missing scale-target columns: {missing}")

    work = delta.copy()
    work["basin_id"] = _basin_ids(work["basin_id"])
    for column in ("conceptual_mae", "lstm_mae", "mae_minus_lstm"):
        work[column] = pd.to_numeric(work[column], errors="coerce")

    rows = []
    group_columns = ["basin_id", "regime", context_col]
    for keys, group in work.groupby(group_columns, dropna=False, sort=False):
        valid = group.dropna(subset=["conceptual_mae", "lstm_mae"])
        if valid.empty:
            continue
        if valid["lstm_mae"].nunique(dropna=False) != 1:
            raise ValueError(f"LSTM MAE is not constant within basin-context {keys}")
        best = valid.sort_values(["conceptual_mae", "conceptual_model"], kind="mergesort").iloc[0]
        conceptual_mae = float(best["conceptual_mae"])
        lstm_mae = float(best["lstm_mae"])
        absolute_advantage = conceptual_mae - lstm_mae
        n_models = int(valid["conceptual_model"].nunique())
        rows.append({
            "basin_id": keys[0],
            "regime": keys[1],
            context_col: keys[2],
            "n_models": n_models,
            "best_conceptual_model": str(best["conceptual_model"]),
            "best_conceptual_mae": conceptual_mae,
            "lstm_mae": lstm_mae,
            "absolute_advantage": absolute_advantage,
            "relative_advantage": symmetric_relative_advantage(conceptual_mae, lstm_mae),
            "all_three_conceptual_worse_mae": bool(
                n_models == 3 and valid["mae_minus_lstm"].gt(0).all()
            ),
            "any_conceptual_lower_mae": bool(valid["mae_minus_lstm"].lt(0).any()),
        })
    return pd.DataFrame(rows)


def _share(numerator: float, denominator: float) -> float:
    if denominator <= 0 or not np.isfinite(denominator):
        return float("nan")
    return float(numerator / denominator)


def summarize_scale_concentration(targets: pd.DataFrame, context_col: str) -> pd.DataFrame:
    """Summarize absolute-error and dimensionless positive-gap concentration."""
    required = {
        "regime",
        context_col,
        "absolute_advantage",
        "relative_advantage",
        "all_three_conceptual_worse_mae",
    }
    missing = sorted(required - set(targets.columns))
    if missing:
        raise ValueError(f"Missing scale-summary columns: {missing}")
    if targets.empty:
        return pd.DataFrame()

    absolute = pd.to_numeric(targets["absolute_advantage"], errors="coerce")
    relative = pd.to_numeric(targets["relative_advantage"], errors="coerce")
    global_absolute = float(absolute.clip(lower=0).sum())
    global_relative = float(relative.clip(lower=0).sum())
    total_contexts = int(len(targets))
    rows = []
    for keys, group in targets.groupby(["regime", context_col], dropna=False, sort=False):
        group_absolute = pd.to_numeric(group["absolute_advantage"], errors="coerce")
        group_relative = pd.to_numeric(group["relative_advantage"], errors="coerce")
        n_contexts = int(len(group))
        context_share = n_contexts / total_contexts
        positive_absolute_sum = float(group_absolute.clip(lower=0).sum())
        positive_relative_sum = float(group_relative.clip(lower=0).sum())
        absolute_share = _share(positive_absolute_sum, global_absolute)
        relative_share = _share(positive_relative_sum, global_relative)
        rows.append({
            "regime": keys[0],
            context_col: keys[1],
            "n_contexts": n_contexts,
            "context_share": context_share,
            "positive_absolute_sum": positive_absolute_sum,
            "positive_absolute_share": absolute_share,
            "absolute_concentration_ratio": _share(absolute_share, context_share),
            "positive_relative_sum": positive_relative_sum,
            "positive_relative_share": relative_share,
            "relative_concentration_ratio": _share(relative_share, context_share),
            "median_absolute_advantage": float(group_absolute.median()),
            "median_relative_advantage": float(group_relative.median()),
            "lstm_win_rate": float(group_absolute.gt(0).mean()),
            "shared_failure_rate": float(group["all_three_conceptual_worse_mae"].mean()),
            "has_global_positive_absolute_advantage": global_absolute > 0,
            "has_global_positive_relative_advantage": global_relative > 0,
        })
    return pd.DataFrame(rows)


FROZEN_REGIMES = ("humid", "semi-humid", "semi-arid/arid", "snow-dominated")


def make_stratified_basin_draws(
    basin_regimes: pd.DataFrame,
    *,
    n_resamples: int = BOOTSTRAP_RESAMPLES,
    seed: int = BOOTSTRAP_SEED,
) -> np.ndarray:
    """Return integer basin-position draws stratified by frozen regime.

    Repeated positions are retained. Downstream code must therefore treat a
    repeated sampled basin as another bootstrap unit rather than de-duplicate
    it.
    """
    required = {"basin_id", "regime"}
    missing = sorted(required - set(basin_regimes.columns))
    if missing:
        raise ValueError(f"Missing basin-regime columns: {missing}")
    if n_resamples <= 0:
        raise ValueError("n_resamples must be positive")
    basins = basin_regimes[["basin_id", "regime"]].copy()
    basins["basin_id"] = _basin_ids(basins["basin_id"])
    if basins["basin_id"].duplicated().any():
        raise ValueError("Each basin must have exactly one regime row")
    missing_regimes = sorted(set(FROZEN_REGIMES) - set(basins["regime"]))
    extra_regimes = sorted(set(basins["regime"]) - set(FROZEN_REGIMES))
    if missing_regimes or extra_regimes:
        raise ValueError(
            f"Regime set must be {FROZEN_REGIMES}; missing={missing_regimes}, extra={extra_regimes}"
        )

    rng = np.random.default_rng(seed)
    draws = np.empty((n_resamples, len(basins)), dtype=np.int32)
    cursor = 0
    regime_values = basins["regime"].to_numpy()
    for regime in FROZEN_REGIMES:
        positions = np.flatnonzero(regime_values == regime).astype(np.int32)
        width = len(positions)
        draws[:, cursor:cursor + width] = rng.choice(
            positions,
            size=(n_resamples, width),
            replace=True,
        )
        cursor += width
    return draws


def fixed_contrast_inventory() -> pd.DataFrame:
    """Return the only predeclared inferential comparisons for D07."""
    rows = []
    for left, right in (("high", "mid"), ("high", "low"), ("mid", "low")):
        rows.append({"family": "flow_pairwise", "left": left, "right": right, "flow_group": ""})
    for flow_group in ("high", "mid", "low"):
        rows.append({
            "family": "snow_vs_non_snow_by_flow",
            "left": "snow-dominated",
            "right": "pooled_non_snow",
            "flow_group": flow_group,
        })
    seasons = ("DJF", "MAM", "JJA", "SON")
    for left_index, left in enumerate(seasons):
        for right in seasons[left_index + 1:]:
            rows.append({
                "family": "snow_high_season_pairwise",
                "left": left,
                "right": right,
                "flow_group": "high",
            })
    return pd.DataFrame(rows)


def holm_adjust(probabilities) -> np.ndarray:
    """Holm family-wise adjustment, preserving missing values."""
    raw = np.asarray(probabilities, dtype=float)
    adjusted = np.full(raw.shape, np.nan, dtype=float)
    finite_positions = np.flatnonzero(np.isfinite(raw))
    if finite_positions.size == 0:
        return adjusted
    finite = raw[finite_positions]
    if np.any((finite < 0) | (finite > 1)):
        raise ValueError("Probabilities must lie in [0, 1]")
    order = np.argsort(finite, kind="mergesort")
    ranked = finite[order]
    multipliers = np.arange(len(ranked), 0, -1)
    ranked_adjusted = np.maximum.accumulate(ranked * multipliers).clip(max=1.0)
    restored = np.empty_like(ranked_adjusted)
    restored[order] = ranked_adjusted
    adjusted[finite_positions] = restored
    return adjusted


def build_basin_model_context_rows(
    *,
    basin_id: str,
    regime: str,
    dates,
    obs,
    lstm_sim,
    conceptual_sim,
    conceptual_model: str,
    low_quantile: float,
    high_quantile: float,
    minimum_joint_days: int = MIN_CONTEXT_DAYS,
) -> pd.DataFrame:
    """Summarize one basin and one conceptual model without a full daily panel."""
    if conceptual_model not in {*MODELS[1:], "HBV"}:
        raise ValueError(f"Unregistered conceptual model: {conceptual_model}")
    if not 0 <= low_quantile < high_quantile <= 1:
        raise ValueError("Flow quantiles must satisfy 0 <= low < high <= 1")
    if minimum_joint_days < 1:
        raise ValueError("minimum_joint_days must be positive")

    date_index = pd.DatetimeIndex(dates)
    observation = np.asarray(obs, dtype=float)
    neural = np.asarray(lstm_sim, dtype=float)
    conceptual = np.asarray(conceptual_sim, dtype=float)
    lengths = {len(date_index), len(observation), len(neural), len(conceptual)}
    if len(lengths) != 1:
        raise ValueError("Dates, observations, and simulations must have equal lengths")
    if not np.isfinite(np.column_stack([observation, neural, conceptual])).all():
        raise ValueError("One-basin context inputs must be finite")

    daily = pd.DataFrame({
        "date": date_index,
        "obs": observation,
        "lstm_sim": neural,
        "conceptual_sim": conceptual,
    })
    daily["season"] = season_labels(date_index).to_numpy()
    daily["flow_group"] = flow_group_labels(
        daily["obs"], low_q=low_quantile, high_q=high_quantile
    ).to_numpy()
    daily["joint_context"] = daily["season"] + "__" + daily["flow_group"]

    rows = []
    families = (
        ("season", "season"),
        ("flow", "flow_group"),
        ("joint", "joint_context"),
    )
    normalized_basin = str(basin_id).replace(".0", "").zfill(8)
    for family, context_column in families:
        for context, group in daily.groupby(context_column, sort=True, dropna=False):
            n_days = int(len(group))
            if family == "joint" and n_days < minimum_joint_days:
                continue
            group_obs = group["obs"].to_numpy(dtype=float)
            group_neural = group["lstm_sim"].to_numpy(dtype=float)
            group_conceptual = group["conceptual_sim"].to_numpy(dtype=float)
            lstm_mae = float(np.mean(np.abs(group_neural - group_obs)))
            conceptual_mae = float(np.mean(np.abs(group_conceptual - group_obs)))
            lstm_nse = nse_or_nan(group_obs, group_neural)
            conceptual_nse = nse_or_nan(group_obs, group_conceptual)
            if family == "season":
                season = str(context)
                flow_group = ""
            elif family == "flow":
                season = ""
                flow_group = str(context)
            else:
                season, flow_group = str(context).split("__", maxsplit=1)
            rows.append({
                "basin_id": normalized_basin,
                "regime": str(regime),
                "family": family,
                "context": str(context),
                "season": season,
                "flow_group": flow_group,
                "conceptual_model": conceptual_model,
                "n_days": n_days,
                "mae_minus_lstm": conceptual_mae - lstm_mae,
                "nse_minus_lstm": (
                    conceptual_nse - lstm_nse
                    if np.isfinite(conceptual_nse) and np.isfinite(lstm_nse)
                    else float("nan")
                ),
                "conceptual_mae": conceptual_mae,
                "lstm_mae": lstm_mae,
                "conceptual_nse": conceptual_nse,
                "lstm_nse": lstm_nse,
            })
    return pd.DataFrame(rows)


def _basin_count_matrix(draws: np.ndarray, n_basins: int) -> np.ndarray:
    counts = np.empty((len(draws), n_basins), dtype=np.int16)
    for row_index, draw in enumerate(draws):
        counts[row_index] = np.bincount(draw, minlength=n_basins)
    return counts


def bootstrap_concentration_intervals(
    targets: pd.DataFrame,
    context_col: str,
    *,
    group_by_regime: bool = True,
    n_resamples: int = BOOTSTRAP_RESAMPLES,
    seed: int = BOOTSTRAP_SEED,
    confidence_level: float = 0.95,
) -> pd.DataFrame:
    """Percentile intervals for cell concentration with whole-basin clusters."""
    if not 0 < confidence_level < 1:
        raise ValueError("confidence_level must lie in (0, 1)")
    required = {"basin_id", "regime", context_col, "absolute_advantage", "relative_advantage"}
    missing = sorted(required - set(targets.columns))
    if missing:
        raise ValueError(f"Missing bootstrap target columns: {missing}")

    work = targets.copy()
    work["basin_id"] = _basin_ids(work["basin_id"])
    basin_regimes = work[["basin_id", "regime"]].drop_duplicates().reset_index(drop=True)
    inconsistent = basin_regimes.groupby("basin_id")["regime"].nunique()
    if inconsistent.gt(1).any():
        raise ValueError("A basin has more than one regime in the bootstrap targets")
    basin_regimes = basin_regimes.drop_duplicates("basin_id").reset_index(drop=True)
    draws = make_stratified_basin_draws(
        basin_regimes,
        n_resamples=n_resamples,
        seed=seed,
    )
    basin_counts = _basin_count_matrix(draws, len(basin_regimes)).astype(float)
    basin_positions = pd.Series(
        np.arange(len(basin_regimes), dtype=int),
        index=basin_regimes["basin_id"],
    )
    work["_basin_position"] = work["basin_id"].map(basin_positions)

    cell_columns = ["regime", context_col] if group_by_regime else [context_col]
    cell_frame = work[cell_columns].drop_duplicates().reset_index(drop=True)
    cell_index = pd.MultiIndex.from_frame(cell_frame)
    row_cells = pd.MultiIndex.from_frame(work[cell_columns])
    cell_positions = cell_index.get_indexer(row_cells)
    if (cell_positions < 0).any():
        raise RuntimeError("Failed to index bootstrap context cells")

    n_basins = len(basin_regimes)
    n_cells = len(cell_frame)
    context_by_basin = np.zeros((n_basins, n_cells), dtype=float)
    absolute_by_basin = np.zeros((n_basins, n_cells), dtype=float)
    relative_by_basin = np.zeros((n_basins, n_cells), dtype=float)
    row_basins = work["_basin_position"].to_numpy(dtype=int)
    np.add.at(context_by_basin, (row_basins, cell_positions), 1.0)
    np.add.at(
        absolute_by_basin,
        (row_basins, cell_positions),
        pd.to_numeric(work["absolute_advantage"], errors="coerce").clip(lower=0).fillna(0).to_numpy(),
    )
    np.add.at(
        relative_by_basin,
        (row_basins, cell_positions),
        pd.to_numeric(work["relative_advantage"], errors="coerce").clip(lower=0).fillna(0).to_numpy(),
    )

    boot_contexts = basin_counts @ context_by_basin
    total_contexts = boot_contexts.sum(axis=1, keepdims=True)
    point_work = work.copy()
    if not group_by_regime:
        point_work["regime"] = "all_basins"
    point = summarize_scale_concentration(point_work, context_col).set_index(["regime", context_col])
    alpha = (1.0 - confidence_level) / 2.0
    rows = []
    for metric, basin_values in (
        ("absolute_concentration_ratio", absolute_by_basin),
        ("relative_concentration_ratio", relative_by_basin),
    ):
        boot_positive = basin_counts @ basin_values
        total_positive = boot_positive.sum(axis=1, keepdims=True)
        with np.errstate(divide="ignore", invalid="ignore"):
            distribution = (boot_positive / total_positive) / (boot_contexts / total_contexts)
        for cell_position, cell in cell_frame.iterrows():
            values = distribution[:, cell_position]
            values = values[np.isfinite(values)]
            output_regime = cell["regime"] if group_by_regime else "all_basins"
            key = (output_regime, cell[context_col])
            estimate = float(point.loc[key, metric])
            if values.size:
                ci_low, ci_high = np.quantile(values, [alpha, 1.0 - alpha])
            else:
                ci_low, ci_high = np.nan, np.nan
            rows.append({
                "regime": output_regime,
                context_col: cell[context_col],
                "metric": metric,
                "estimate": estimate,
                "ci_low": float(ci_low),
                "ci_high": float(ci_high),
                "confidence_level": confidence_level,
                "bootstrap_unit": "whole_basin",
                "stratified_by": "regime",
                "resamples": n_resamples,
                "seed": seed,
                "finite_replicates": int(values.size),
            })
    return pd.DataFrame(rows)


def _draw_present_strata(
    basin_regimes: pd.DataFrame,
    *,
    n_resamples: int,
    seed: int,
) -> np.ndarray:
    regimes = basin_regimes["regime"].to_numpy()
    present = [regime for regime in FROZEN_REGIMES if regime in set(regimes)]
    rng = np.random.default_rng(seed)
    draws = np.empty((n_resamples, len(basin_regimes)), dtype=np.int32)
    cursor = 0
    for regime in present:
        positions = np.flatnonzero(regimes == regime).astype(np.int32)
        width = len(positions)
        draws[:, cursor:cursor + width] = rng.choice(
            positions,
            size=(n_resamples, width),
            replace=True,
        )
        cursor += width
    return draws


def _bootstrap_probability(distribution: np.ndarray) -> float:
    finite = distribution[np.isfinite(distribution)]
    if finite.size == 0:
        return float("nan")
    denominator = finite.size + 1
    lower = (int(np.count_nonzero(finite <= 0)) + 1) / denominator
    upper = (int(np.count_nonzero(finite >= 0)) + 1) / denominator
    return float(min(1.0, 2.0 * min(lower, upper)))


def _contrast_result(
    distribution: np.ndarray,
    estimate: float,
    *,
    confidence_level: float,
) -> tuple[float, float, float]:
    finite = distribution[np.isfinite(distribution)]
    if finite.size == 0:
        return float("nan"), float("nan"), float("nan")
    alpha = (1.0 - confidence_level) / 2.0
    ci_low, ci_high = np.quantile(finite, [alpha, 1.0 - alpha])
    return (
        float(min(ci_low, estimate)),
        float(max(ci_high, estimate)),
        _bootstrap_probability(finite),
    )


def _paired_relative_contrast(
    common: pd.DataFrame,
    left: str,
    right: str,
    *,
    n_resamples: int,
    seed: int,
    confidence_level: float,
) -> dict:
    complete = common.dropna(subset=[left, right]).reset_index(drop=True)
    if complete.empty:
        return {
            "estimate": np.nan,
            "ci_low": np.nan,
            "ci_high": np.nan,
            "p_raw": np.nan,
            "common_basin_count": 0,
            "left_basin_count": 0,
            "right_basin_count": 0,
        }
    difference = complete[left].to_numpy(dtype=float) - complete[right].to_numpy(dtype=float)
    draws = _draw_present_strata(
        complete[["basin_id", "regime"]],
        n_resamples=n_resamples,
        seed=seed,
    )
    distribution = np.median(difference[draws], axis=1)
    estimate = float(np.median(difference))
    ci_low, ci_high, p_raw = _contrast_result(
        distribution,
        estimate,
        confidence_level=confidence_level,
    )
    count = int(len(complete))
    return {
        "estimate": estimate,
        "ci_low": ci_low,
        "ci_high": ci_high,
        "p_raw": p_raw,
        "common_basin_count": count,
        "left_basin_count": count,
        "right_basin_count": count,
    }


def compute_fixed_contrasts(
    flow_targets: pd.DataFrame,
    joint_targets: pd.DataFrame,
    *,
    n_resamples: int = BOOTSTRAP_RESAMPLES,
    seed: int = BOOTSTRAP_SEED,
    confidence_level: float = 0.95,
) -> pd.DataFrame:
    """Compute the three predeclared relative-advantage contrast families."""
    inventory = fixed_contrast_inventory()
    flow = flow_targets.copy()
    joint = joint_targets.copy()
    for frame in (flow, joint):
        frame["basin_id"] = _basin_ids(frame["basin_id"])
    rows = []
    for contrast_index, contrast in inventory.iterrows():
        family = contrast["family"]
        left = contrast["left"]
        right = contrast["right"]
        contrast_seed = seed + int(contrast_index)
        if family == "flow_pairwise":
            common = flow.pivot_table(
                index=["basin_id", "regime"],
                columns="flow_group",
                values="relative_advantage",
                aggfunc="first",
            ).reset_index()
            result = _paired_relative_contrast(
                common,
                left,
                right,
                n_resamples=n_resamples,
                seed=contrast_seed,
                confidence_level=confidence_level,
            )
        elif family == "snow_vs_non_snow_by_flow":
            selected = flow[flow["flow_group"] == contrast["flow_group"]].dropna(
                subset=["relative_advantage"]
            ).reset_index(drop=True)
            snow = selected["regime"].eq("snow-dominated").to_numpy()
            non_snow = ~snow
            draws = make_stratified_basin_draws(
                selected[["basin_id", "regime"]],
                n_resamples=n_resamples,
                seed=contrast_seed,
            )
            values = selected["relative_advantage"].to_numpy(dtype=float)
            drawn_regimes = selected["regime"].to_numpy()[draws]
            drawn_values = values[draws]
            snow_values = np.where(drawn_regimes == "snow-dominated", drawn_values, np.nan)
            non_snow_values = np.where(drawn_regimes != "snow-dominated", drawn_values, np.nan)
            distribution = np.nanmedian(snow_values, axis=1) - np.nanmedian(non_snow_values, axis=1)
            estimate = float(np.median(values[snow]) - np.median(values[non_snow]))
            ci_low, ci_high, p_raw = _contrast_result(
                distribution,
                estimate,
                confidence_level=confidence_level,
            )
            result = {
                "estimate": estimate,
                "ci_low": ci_low,
                "ci_high": ci_high,
                "p_raw": p_raw,
                "common_basin_count": int(len(selected)),
                "left_basin_count": int(snow.sum()),
                "right_basin_count": int(non_snow.sum()),
            }
        else:
            selected = joint[
                joint["regime"].eq("snow-dominated") & joint["flow_group"].eq("high")
            ]
            common = selected.pivot_table(
                index=["basin_id", "regime"],
                columns="season",
                values="relative_advantage",
                aggfunc="first",
            ).reset_index()
            result = _paired_relative_contrast(
                common,
                left,
                right,
                n_resamples=n_resamples,
                seed=contrast_seed,
                confidence_level=confidence_level,
            )
        rows.append({**contrast.to_dict(), **result, "resamples": n_resamples, "seed": seed})

    output = pd.DataFrame(rows)
    output["p_holm"] = np.nan
    for _, positions in output.groupby("family").groups.items():
        output.loc[positions, "p_holm"] = holm_adjust(output.loc[positions, "p_raw"])
    return output
