"""Analyze the registered identical-loss replication without mixing historical results.

The real entry point is intentionally strict: it accepts only a completed eight-seed
run ledger, a completed conceptual daily-prediction manifest, the frozen basin-regime
table, and the passed common-loss protocol. Pure functions remain usable with small
artificial frames so every paper-facing calculation can be checked before expensive
runs exist.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import pickle
import stat
import tempfile
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd
import yaml

from src.lstm_fair_531.scripts.run_identical_basin_nse_replication import (
    __version__,
    _ArtifactStabilityGuard,
    _current_git_description,
    _registered_output_paths,
    _validate_run_configuration_matches_frozen,
    validate_fixed_configuration,
)


FIXED_SEEDS = (100, 200, 300, 400, 500, 600, 700, 800)
CONCEPTUAL_MODELS = ("GR4J", "XAJ", "HBV-lite")
NEURAL_MODEL = "LSTM_ensemble_8seed"
ALL_MODELS = (NEURAL_MODEL, *CONCEPTUAL_MODELS)
LOSS_PROTOCOL = "identical_basin_average_nse"
EXPECTED_EXPERIMENT_ID = "R02_identical_basin_nse_531"
FIXED_EPOCH = 30
EVALUATION_START = "1989-10-01"
EVALUATION_END = "1999-09-30"
BOOTSTRAP_RESAMPLES = 10_000
BOOTSTRAP_SEED = 20_260_714
FIXED_CONCEPTUAL_CALIBRATION_SETTINGS = {
    "loss": "nse",
    "trials": 5000,
    "restarts": 3,
    "forcing": "maurer",
    "discharge_normalization": "common_forcing_header_float32",
    "pet_method": "priestley_taylor",
    "bounds_preset": "v1",
    "warmup_year": True,
}

_REPOSITORY_ROOT = Path(__file__).resolve().parents[3]
_DEFAULT_RESULT_ROOT = _REPOSITORY_ROOT / "results" / "18_lstm_fair_531" / EXPECTED_EXPERIMENT_ID


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _assert_unchanged(path: Path, expected_sha256: str, *, label: str) -> None:
    actual = _sha256(path)
    if actual != expected_sha256:
        raise RuntimeError(
            f"{label} changed while it was being read: expected {expected_sha256}, got {actual}: {path}"
        )


def _read_bytes_snapshot(
    path: Path, *, label: str, expected_sha256: str | None = None
) -> tuple[bytes, str]:
    payload = Path(path).read_bytes()
    content_sha256 = hashlib.sha256(payload).hexdigest()
    if expected_sha256 is not None and content_sha256 != expected_sha256:
        raise ValueError(
            f"{label} hash mismatch: expected {expected_sha256}, got {content_sha256}: {path}"
        )
    return payload, content_sha256


def _load_json_snapshot(
    path: Path, *, label: str, expected_sha256: str | None = None
) -> tuple[dict, str]:
    encoded, content_sha256 = _read_bytes_snapshot(
        path, label=label, expected_sha256=expected_sha256
    )
    payload = json.loads(encoded.decode("utf-8"))
    _assert_unchanged(path, content_sha256, label=label)
    return payload, content_sha256


def _load_csv_snapshot(
    path: Path, *, label: str, expected_sha256: str | None = None, **read_csv_kwargs
) -> tuple[pd.DataFrame, str]:
    encoded, content_sha256 = _read_bytes_snapshot(
        path, label=label, expected_sha256=expected_sha256
    )
    frame = pd.read_csv(io.BytesIO(encoded), **read_csv_kwargs)
    _assert_unchanged(path, content_sha256, label=label)
    return frame, content_sha256


def _load_yaml_snapshot(
    path: Path, *, label: str, expected_sha256: str
) -> tuple[dict, str]:
    encoded, content_sha256 = _read_bytes_snapshot(
        path, label=label, expected_sha256=expected_sha256
    )
    payload = yaml.safe_load(encoded.decode("utf-8"))
    _assert_unchanged(path, content_sha256, label=label)
    return payload, content_sha256


def _require_columns(frame: pd.DataFrame, required: Iterable[str], *, label: str) -> None:
    missing = sorted(set(required) - set(frame.columns))
    if missing:
        raise ValueError(f"{label} is missing required columns: {missing}")


def _normalize_basin_ids(values: pd.Series) -> pd.Series:
    normalized = values.astype(str).str.replace(r"\.0$", "", regex=True).str.strip().str.zfill(8)
    if normalized.eq("").any() or normalized.eq("00000nan").any():
        raise ValueError("Basin identifiers must be non-empty")
    return normalized


def _normalize_daily_predictions(frame: pd.DataFrame, *, label: str) -> pd.DataFrame:
    _require_columns(frame, ["basin_id", "date", "obs", "sim"], label=label)
    out = frame.copy()
    out["basin_id"] = _normalize_basin_ids(out["basin_id"])
    out["date"] = pd.to_datetime(out["date"], errors="raise")
    out["obs"] = pd.to_numeric(out["obs"], errors="raise").astype(float)
    out["sim"] = pd.to_numeric(out["sim"], errors="raise").astype(float)
    if not np.isfinite(out[["obs", "sim"]].to_numpy(dtype=float)).all():
        raise ValueError(f"{label} contains non-finite observations or predictions")
    return out


def _validate_basin_count(frame: pd.DataFrame, expected_basin_count: int | None) -> None:
    if expected_basin_count is None:
        return
    actual = int(frame["basin_id"].nunique())
    if actual != expected_basin_count:
        raise ValueError(f"expected {expected_basin_count} basins, found {actual}")


def _sorted_keys(frame: pd.DataFrame) -> pd.MultiIndex:
    return pd.MultiIndex.from_frame(frame[["basin_id", "date"]].sort_values(["basin_id", "date"]))


def build_eight_seed_ensemble(seed_predictions: pd.DataFrame) -> pd.DataFrame:
    """Validate and arithmetic-average exactly the fixed eight daily predictions."""
    _require_columns(seed_predictions, ["seed", "basin_id", "date", "obs", "sim"], label="neural predictions")
    work = _normalize_daily_predictions(seed_predictions, label="neural predictions")
    work["seed"] = pd.to_numeric(work["seed"], errors="raise").astype(int)
    actual_seeds = tuple(sorted(work["seed"].unique().tolist()))
    if actual_seeds != FIXED_SEEDS:
        raise ValueError(f"Neural predictions must contain the exact fixed seeds {FIXED_SEEDS}; found {actual_seeds}")
    duplicate = work.duplicated(["seed", "basin_id", "date"], keep=False)
    if duplicate.any():
        raise ValueError("Neural predictions contain duplicate seed-basin-date rows")

    reference = work[work["seed"] == FIXED_SEEDS[0]].sort_values(["basin_id", "date"]).reset_index(drop=True)
    reference_keys = pd.MultiIndex.from_frame(reference[["basin_id", "date"]])
    reference_obs = reference["obs"].to_numpy(dtype=float)
    for seed in FIXED_SEEDS[1:]:
        candidate = work[work["seed"] == seed].sort_values(["basin_id", "date"]).reset_index(drop=True)
        candidate_keys = pd.MultiIndex.from_frame(candidate[["basin_id", "date"]])
        if not candidate_keys.equals(reference_keys):
            raise ValueError(f"Seed {seed} basin-date mask does not match seed {FIXED_SEEDS[0]}")
        if not np.array_equal(candidate["obs"].to_numpy(dtype=float), reference_obs):
            raise ValueError(f"Seed {seed} observations do not match seed {FIXED_SEEDS[0]}")

    ensemble = (
        work.groupby(["basin_id", "date"], sort=True, as_index=False)
        .agg(obs=("obs", "first"), **{NEURAL_MODEL: ("sim", "mean")})
        .sort_values(["basin_id", "date"])
        .reset_index(drop=True)
    )
    return ensemble


def build_daily_panel(
    ensemble: pd.DataFrame,
    conceptual_predictions: pd.DataFrame,
    basin_regimes: pd.DataFrame,
    *,
    expected_basin_count: int = 531,
) -> pd.DataFrame:
    """Join neural and conceptual predictions only after exact mask/observation checks."""
    _require_columns(ensemble, ["basin_id", "date", "obs", NEURAL_MODEL], label="neural ensemble")
    neural = ensemble.copy()
    neural["basin_id"] = _normalize_basin_ids(neural["basin_id"])
    neural["date"] = pd.to_datetime(neural["date"], errors="raise")
    neural["obs"] = pd.to_numeric(neural["obs"], errors="raise").astype(float)
    neural[NEURAL_MODEL] = pd.to_numeric(neural[NEURAL_MODEL], errors="raise").astype(float)
    if neural.duplicated(["basin_id", "date"]).any():
        raise ValueError("Neural ensemble contains duplicate basin-date rows")
    if not np.isfinite(neural[["obs", NEURAL_MODEL]].to_numpy(dtype=float)).all():
        raise ValueError("Neural ensemble contains non-finite values")
    neural = neural.sort_values(["basin_id", "date"]).reset_index(drop=True)

    _require_columns(
        conceptual_predictions,
        ["model", "basin_id", "date", "obs", "sim"],
        label="conceptual predictions",
    )
    conceptual = _normalize_daily_predictions(conceptual_predictions, label="conceptual predictions")
    actual_models = tuple(sorted(conceptual["model"].astype(str).unique().tolist()))
    if set(actual_models) != set(CONCEPTUAL_MODELS):
        raise ValueError(f"Conceptual predictions must contain exactly {CONCEPTUAL_MODELS}; found {actual_models}")
    if conceptual.duplicated(["model", "basin_id", "date"]).any():
        raise ValueError("Conceptual predictions contain duplicate model-basin-date rows")

    neural_keys = pd.MultiIndex.from_frame(neural[["basin_id", "date"]])
    neural_obs = neural["obs"].to_numpy(dtype=float)
    model_columns: dict[str, np.ndarray] = {}
    for model in CONCEPTUAL_MODELS:
        model_frame = conceptual[conceptual["model"].astype(str) == model].sort_values(
            ["basin_id", "date"]
        ).reset_index(drop=True)
        model_keys = pd.MultiIndex.from_frame(model_frame[["basin_id", "date"]])
        if not model_keys.equals(neural_keys):
            raise ValueError(f"{model} basin-date mask does not match the neural ensemble")
        # The neural (neuralhydrology float32 xarray) and conceptual (float32 CSV)
        # pipelines store the same observed discharge but agree only to float32
        # precision (~1e-6), so require float32-level equality rather than
        # bit-identity; a real target difference is orders of magnitude larger.
        if not np.allclose(
            model_frame["obs"].to_numpy(dtype=float), neural_obs, rtol=1e-5, atol=1e-4
        ):
            raise ValueError(f"{model} observations do not match the neural ensemble")
        model_columns[model] = model_frame["sim"].to_numpy(dtype=float)

    panel = neural.copy()
    for model in CONCEPTUAL_MODELS:
        panel[model] = model_columns[model]

    _require_columns(basin_regimes, ["basin_id", "regime"], label="basin regimes")
    regimes = basin_regimes[["basin_id", "regime"]].copy()
    regimes["basin_id"] = _normalize_basin_ids(regimes["basin_id"])
    if regimes.duplicated("basin_id").any():
        raise ValueError("Basin regimes contain duplicate basin identifiers")
    if regimes["regime"].isna().any() or regimes["regime"].astype(str).str.strip().eq("").any():
        raise ValueError("Basin regimes contain missing regime labels")
    panel_basins = set(panel["basin_id"])
    regime_basins = set(regimes["basin_id"])
    if panel_basins != regime_basins:
        raise ValueError(
            "Basin regime identifiers do not match daily prediction identifiers: "
            f"missing={sorted(panel_basins - regime_basins)[:5]}, extra={sorted(regime_basins - panel_basins)[:5]}"
        )
    panel = panel.merge(regimes, on="basin_id", how="left", validate="many_to_one")
    _validate_basin_count(panel, expected_basin_count)
    return panel[["basin_id", "date", "obs", *ALL_MODELS, "regime"]]


def label_daily_contexts(daily: pd.DataFrame, *, low_quantile: float = 0.1, high_quantile: float = 0.9) -> pd.DataFrame:
    """Apply the historical per-basin flow thresholds and fixed spring months."""
    _require_columns(daily, ["basin_id", "date", "obs"], label="daily panel")
    if not (0.0 <= low_quantile < high_quantile <= 1.0):
        raise ValueError("Flow quantiles must satisfy 0 <= low < high <= 1")
    out = daily.copy()
    out["basin_id"] = _normalize_basin_ids(out["basin_id"])
    out["date"] = pd.to_datetime(out["date"], errors="raise")
    out["obs"] = pd.to_numeric(out["obs"], errors="raise").astype(float)
    if out.duplicated(["basin_id", "date"]).any():
        raise ValueError("Daily panel contains duplicate basin-date rows")
    if not np.isfinite(out["obs"].to_numpy(dtype=float)).all():
        raise ValueError("Daily panel observations must be finite")
    low = out.groupby("basin_id", sort=False)["obs"].transform(lambda values: values.quantile(low_quantile))
    high = out.groupby("basin_id", sort=False)["obs"].transform(lambda values: values.quantile(high_quantile))
    labels = np.full(len(out), "mid", dtype=object)
    labels[out["obs"].to_numpy() <= low.to_numpy()] = "low"
    labels[out["obs"].to_numpy() >= high.to_numpy()] = "high"
    out["flow_group"] = labels
    out["is_spring"] = out["date"].dt.month.isin([3, 4, 5])
    out["is_spring_high"] = out["is_spring"] & out["flow_group"].eq("high")
    return out


def _nse(obs: np.ndarray, sim: np.ndarray, *, basin_id: str, model: str) -> float:
    denominator = float(np.sum((obs - obs.mean())**2))
    if not np.isfinite(denominator) or denominator <= 0.0:
        raise ValueError(f"Non-positive NSE denominator for basin {basin_id}, model {model}: {denominator}")
    return float(1.0 - np.sum((sim - obs)**2) / denominator)


def compute_per_basin_nse(daily_panel: pd.DataFrame, *, expected_basin_count: int = 531) -> pd.DataFrame:
    """Compute one evaluation-period Nash--Sutcliffe efficiency row per basin."""
    _require_columns(daily_panel, ["basin_id", "obs", *ALL_MODELS], label="daily panel")
    work = daily_panel.copy()
    work["basin_id"] = _normalize_basin_ids(work["basin_id"])
    _validate_basin_count(work, expected_basin_count)
    numeric = work[["obs", *ALL_MODELS]].apply(pd.to_numeric, errors="raise").astype(float)
    if not np.isfinite(numeric.to_numpy(dtype=float)).all():
        raise ValueError("Daily panel contains non-finite values")
    work[["obs", *ALL_MODELS]] = numeric
    rows = []
    for basin_id, group in work.groupby("basin_id", sort=True):
        obs = group["obs"].to_numpy(dtype=float)
        row: dict[str, object] = {"basin_id": basin_id}
        if "regime" in group:
            regimes = group["regime"].astype(str).unique()
            if len(regimes) != 1:
                raise ValueError(f"Basin {basin_id} has multiple regime labels")
            row["regime"] = regimes[0]
        for model in ALL_MODELS:
            row[model] = _nse(obs, group[model].to_numpy(dtype=float), basin_id=basin_id, model=model)
        rows.append(row)
    return pd.DataFrame(rows)


def summarize_nse(per_basin_nse: pd.DataFrame, *, expected_basin_count: int = 531) -> pd.DataFrame:
    """Summarize the exact common basin population without dropping failed rows."""
    _require_columns(per_basin_nse, ["basin_id", *ALL_MODELS], label="per-basin NSE")
    _validate_basin_count(per_basin_nse, expected_basin_count)
    rows = []
    for model in ALL_MODELS:
        values = pd.to_numeric(per_basin_nse[model], errors="raise").to_numpy(dtype=float)
        if values.size != expected_basin_count or not np.isfinite(values).all():
            raise ValueError(f"{model} does not have {expected_basin_count} finite basin NSE values")
        rows.append({
            "model": model,
            "basin_count": int(values.size),
            "median_nse": float(np.median(values)),
            "mean_nse": float(np.mean(values)),
        })
    return pd.DataFrame(rows)


def summarize_context_mae(daily_panel: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Calculate equal-basin MAE advantages for the fixed paper contexts."""
    _require_columns(daily_panel, ["basin_id", "date", "obs", "regime", *ALL_MODELS], label="daily panel")
    numeric = daily_panel[["obs", *ALL_MODELS]].apply(pd.to_numeric, errors="raise").to_numpy(dtype=float)
    if not np.isfinite(numeric).all():
        raise ValueError("Daily panel contains non-finite observations or model predictions")
    labeled = label_daily_contexts(daily_panel)
    context_masks = {
        "overall": pd.Series(True, index=labeled.index),
        "low": labeled["flow_group"].eq("low"),
        "high": labeled["flow_group"].eq("high"),
        "spring": labeled["is_spring"],
        "spring_high": labeled["is_spring_high"],
    }
    rows = []
    for basin_id, basin in labeled.groupby("basin_id", sort=True):
        regimes = basin["regime"].astype(str).unique()
        if len(regimes) != 1:
            raise ValueError(f"Basin {basin_id} has multiple regime labels")
        for context, global_mask in context_masks.items():
            group = basin[global_mask.reindex(basin.index).fillna(False)]
            if group.empty:
                continue
            mae = {
                model: float(np.mean(np.abs(group[model].to_numpy(dtype=float) - group["obs"].to_numpy(dtype=float))))
                for model in ALL_MODELS
            }
            best_model = min(CONCEPTUAL_MODELS, key=lambda name: (mae[name], CONCEPTUAL_MODELS.index(name)))
            best_mae = mae[best_model]
            neural_mae = mae[NEURAL_MODEL]
            rows.append({
                "basin_id": basin_id,
                "regime": regimes[0],
                "context": context,
                "n_days": int(len(group)),
                "lstm_mae": neural_mae,
                "gr4j_mae": mae["GR4J"],
                "xaj_mae": mae["XAJ"],
                "hbv_lite_mae": mae["HBV-lite"],
                "best_conceptual_model": best_model,
                "best_conceptual_mae": best_mae,
                "best_conceptual_mae_minus_lstm": float(best_mae - neural_mae),
                "all_conceptual_worse_mae": bool(all(mae[model] > neural_mae for model in CONCEPTUAL_MODELS)),
            })
    per_basin = pd.DataFrame(rows)
    summary_rows = []

    def append_summary(regime: str, context: str, group: pd.DataFrame) -> None:
        advantage = group["best_conceptual_mae_minus_lstm"].to_numpy(dtype=float)
        shared = group["all_conceptual_worse_mae"].astype(bool).to_numpy()
        summary_rows.append({
            "regime": regime,
            "context": context,
            "basin_count": int(group["basin_id"].nunique()),
            "mean_best_conceptual_mae_minus_lstm": float(np.mean(advantage)),
            "median_best_conceptual_mae_minus_lstm": float(np.median(advantage)),
            "shared_failure_count": int(shared.sum()),
            "shared_failure_rate": float(shared.mean()),
        })

    for (regime, context), group in per_basin.groupby(["regime", "context"], sort=True):
        append_summary(regime, context, group)
    for context, group in per_basin.groupby("context", sort=True):
        append_summary("all-basins", context, group)
    return per_basin.reset_index(drop=True), pd.DataFrame(summary_rows)


def paired_high_minus_low_bootstrap(
    per_basin_context: pd.DataFrame,
    *,
    regime: str = "snow-dominated",
    n_resamples: int = BOOTSTRAP_RESAMPLES,
    random_seed: int = BOOTSTRAP_SEED,
) -> dict:
    """Bootstrap equal-basin high-minus-low MAE advantages with fixed pairing."""
    _require_columns(
        per_basin_context,
        ["basin_id", "regime", "context", "best_conceptual_mae_minus_lstm"],
        label="per-basin context metrics",
    )
    if n_resamples != BOOTSTRAP_RESAMPLES:
        raise ValueError(f"This replication requires exactly {BOOTSTRAP_RESAMPLES} bootstrap resamples")
    selected = per_basin_context[
        per_basin_context["regime"].astype(str).eq(regime)
        & per_basin_context["context"].isin(["high", "low"])
    ].copy()
    if selected.duplicated(["basin_id", "context"]).any():
        raise ValueError(f"Duplicate high/low context rows for regime {regime}")
    pivot = selected.pivot(index="basin_id", columns="context", values="best_conceptual_mae_minus_lstm")
    if set(pivot.columns) != {"high", "low"} or pivot[["high", "low"]].isna().any().any():
        raise ValueError(f"Every {regime} basin must have paired high and low context values")
    high = pivot["high"].to_numpy(dtype=float)
    low = pivot["low"].to_numpy(dtype=float)
    if high.size < 2 or not np.isfinite(high).all() or not np.isfinite(low).all():
        raise ValueError(f"At least two finite paired {regime} basins are required")

    rng = np.random.default_rng(random_seed)
    median_differences = np.empty(n_resamples, dtype=np.float64)
    batch_size = 1_000
    for start in range(0, n_resamples, batch_size):
        stop = min(start + batch_size, n_resamples)
        indexes = rng.integers(0, high.size, size=(stop - start, high.size))
        median_differences[start:stop] = np.median(high[indexes], axis=1) - np.median(low[indexes], axis=1)
    lower, upper = np.percentile(median_differences, [2.5, 97.5])
    median_high = float(np.median(high))
    median_low = float(np.median(low))
    return {
        "regime": regime,
        "paired_basin_count": int(high.size),
        "n_resamples": int(n_resamples),
        "random_seed": int(random_seed),
        "median_high_mae_advantage": median_high,
        "median_low_mae_advantage": median_low,
        "median_high_minus_low_mae_advantage": float(median_high - median_low),
        "median_high_divided_by_low_mae_advantage": (
            float(median_high / median_low) if median_low != 0.0 else None
        ),
        "lower_95": float(lower),
        "upper_95": float(upper),
        "retain_high_flow_claim": bool(float(lower) > 0.0),
    }


def _resolve_registered_path(value: str | Path) -> Path:
    path = Path(value)
    if not path.is_absolute():
        path = _REPOSITORY_ROOT / path
    return path.resolve()


def _source_record(role: str, path: Path, *, expected_sha256: str | None = None) -> dict:
    resolved = path.resolve()
    if not resolved.is_file():
        raise FileNotFoundError(f"Registered source does not exist: {resolved}")
    actual_sha256 = _sha256(resolved)
    if expected_sha256 is not None and actual_sha256 != expected_sha256:
        raise RuntimeError(
            f"{role} changed while it was being read: expected {expected_sha256}, got {actual_sha256}: {resolved}"
        )
    return {"role": role, "path": str(resolved), "sha256": actual_sha256}


def _assert_registered_neural_artifacts_unchanged(output_records: Sequence[dict]) -> None:
    try:
        with _ArtifactStabilityGuard(_registered_output_paths(list(output_records))):
            for record in output_records:
                seed = int(record.get("seed", -1))
                for artifact in ("configuration", "checkpoint", "predictions", "metrics"):
                    path = _resolve_registered_path(record.get(f"{artifact}_path", ""))
                    expected_sha256 = str(record.get(f"{artifact}_sha256", ""))
                    if not expected_sha256 or _sha256(path) != expected_sha256:
                        raise RuntimeError(
                            f"Seed {seed} registered {artifact} archive artifact changed during analysis: {path}"
                        )
                    if path.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH):
                        raise RuntimeError(
                            f"Seed {seed} registered {artifact} archive artifact is no longer read-only: {path}"
                        )
    except RuntimeError as error:
        if "archive artifact" in str(error):
            raise
        raise RuntimeError(f"Neural archive artifacts changed during terminal validation: {error}") from error


def _xarray_series(dataset, variable: str) -> np.ndarray:
    values = np.asarray(dataset[variable].values)
    if values.ndim == 2 and values.shape[1] == 1:
        values = values[:, 0]
    if values.ndim != 1:
        raise ValueError(f"Unexpected dimensions for {variable}: {values.shape}")
    return values.astype(float)


def _prediction_variables(dataset) -> tuple[str, str]:
    observation_variables = [name for name in dataset.data_vars if str(name).endswith("_obs")]
    simulation_variables = [name for name in dataset.data_vars if str(name).endswith("_sim")]
    if len(observation_variables) != 1 or len(simulation_variables) != 1:
        raise ValueError(f"Expected one observed and one simulated variable; found {list(dataset.data_vars)}")
    return observation_variables[0], simulation_variables[0]


def _load_neural_pickle(
    path: Path, *, seed: int, expected_basin_count: int, expected_sha256: str
) -> pd.DataFrame:
    encoded, content_sha256 = _read_bytes_snapshot(
        path, label=f"Seed {seed} predictions", expected_sha256=expected_sha256
    )
    payload = pickle.loads(encoded)
    _assert_unchanged(path, content_sha256, label=f"Seed {seed} predictions")
    if not isinstance(payload, dict):
        raise ValueError(f"Neural result is not a basin dictionary: {path}")
    if len(payload) != expected_basin_count:
        raise ValueError(f"expected {expected_basin_count} basins, found {len(payload)} in {path}")
    rows = []
    for raw_basin_id in sorted(payload, key=str):
        basin_id = str(raw_basin_id).zfill(8)
        try:
            dataset = payload[raw_basin_id]["1D"]["xr"]
        except (KeyError, TypeError) as error:
            raise ValueError(f"Missing 1D xarray predictions for basin {basin_id} in {path}") from error
        obs_variable, sim_variable = _prediction_variables(dataset)
        obs = _xarray_series(dataset, obs_variable)
        sim = _xarray_series(dataset, sim_variable)
        dates = pd.DatetimeIndex(dataset["date"].values)
        expected_dates = pd.date_range(EVALUATION_START, EVALUATION_END, freq="D")
        if not dates.equals(expected_dates):
            raise ValueError(
                f"Seed {seed} basin {basin_id} does not contain the fixed evaluation dates "
                f"{EVALUATION_START} through {EVALUATION_END}"
            )
        if len(dates) != len(obs) or len(obs) != len(sim):
            raise ValueError(f"Date, observation, and prediction lengths differ for basin {basin_id}, seed {seed}")
        valid_obs = np.isfinite(obs)
        if np.any(valid_obs & ~np.isfinite(sim)):
            raise ValueError(f"Seed {seed} contains non-finite predictions for finite observations in basin {basin_id}")
        for date, observation, prediction in zip(dates[valid_obs], obs[valid_obs], sim[valid_obs]):
            rows.append({
                "seed": seed,
                "basin_id": basin_id,
                "date": pd.Timestamp(date),
                "obs": float(observation),
                "sim": float(prediction),
            })
    return pd.DataFrame(rows)


def load_registered_neural_predictions(
    run_ledger_path: Path,
    *,
    expected_basin_count: int = 531,
    expected_protocol_path: Path | None = None,
) -> tuple[pd.DataFrame, list[dict]]:
    """Load only fixed epoch-30 predictions named by a completed run ledger."""
    ledger_path = Path(run_ledger_path).resolve()
    ledger, ledger_sha256 = _load_json_snapshot(ledger_path, label="Neural run ledger")
    if ledger.get("status") != "completed":
        raise ValueError(f"Neural run ledger is not completed: {ledger.get('status')}")
    protocol_path = _resolve_registered_path(ledger.get("protocol_manifest_path", ""))
    protocol_sha256 = str(ledger.get("protocol_manifest_sha256", ""))
    if not protocol_sha256 or _sha256(protocol_path) != protocol_sha256:
        raise ValueError("Neural run ledger common-loss protocol hash mismatch")
    protocol, _ = _load_json_snapshot(
        protocol_path,
        label="Neural common-loss protocol",
        expected_sha256=protocol_sha256,
    )
    if protocol.get("status") != "passed" or int(protocol.get("basin_count", 0)) != expected_basin_count:
        raise ValueError(f"Neural common-loss protocol must pass exactly {expected_basin_count} basins")
    if expected_protocol_path is not None:
        requested_protocol_path = Path(expected_protocol_path).resolve()
        if protocol_path != requested_protocol_path or _sha256(requested_protocol_path) != protocol_sha256:
            raise ValueError("Neural run ledger does not match the requested common-loss protocol")
    records = ledger.get("seed_records")
    run_dirs = ledger.get("run_dirs")
    output_records = ledger.get("output_records")
    if not isinstance(records, list) or not isinstance(run_dirs, list) or len(records) != len(FIXED_SEEDS) or len(
        run_dirs
    ) != len(FIXED_SEEDS):
        raise ValueError("Neural run ledger must register exactly eight seed records and eight run directories")
    if not isinstance(output_records, list) or len(output_records) != len(FIXED_SEEDS):
        raise ValueError("Neural run ledger must register exactly eight fixed epoch output records")
    record_seeds = tuple(int(record.get("seed")) for record in records)
    if record_seeds != FIXED_SEEDS:
        raise ValueError(f"Neural run ledger seed order must be {FIXED_SEEDS}; found {record_seeds}")
    output_seeds = tuple(int(record.get("seed")) for record in output_records)
    if output_seeds != FIXED_SEEDS:
        raise ValueError(f"Neural output record seed order must be {FIXED_SEEDS}; found {output_seeds}")

    sources = [
        _source_record("neural_run_ledger", ledger_path, expected_sha256=ledger_sha256),
        _source_record("neural_common_loss_protocol", protocol_path, expected_sha256=protocol_sha256),
    ]
    frames = []
    archive_root = None
    # The commit the artifacts were trained at, taken from the first seed and then
    # required of the rest. Registered artifacts must all come from one code state,
    # but that state is whatever they were trained at -- not wherever HEAD has since
    # moved to.
    training_commit_hash: str | None = None
    for seed, record, run_dir_value, output_record in zip(FIXED_SEEDS, records, run_dirs, output_records):
        config_path = _resolve_registered_path(record["path"])
        expected_config_hash = str(record.get("sha256", ""))
        configuration, _ = _load_yaml_snapshot(
            config_path,
            label=f"Seed {seed} configuration",
            expected_sha256=expected_config_hash,
        )
        validate_fixed_configuration(configuration)
        expected_experiment_name = f"{EXPECTED_EXPERIMENT_ID}_s{seed}"
        if int(configuration.get("seed", -1)) != seed or configuration.get(
            "experiment_name"
        ) != expected_experiment_name:
            raise ValueError(
                f"Seed {seed} configuration must identify {expected_experiment_name}, got "
                f"seed={configuration.get('seed')}, experiment_name={configuration.get('experiment_name')}"
            )
        sources.append(
            _source_record(
                f"neural_seed_{seed}_generated_configuration",
                config_path,
                expected_sha256=expected_config_hash,
            )
        )
        run_dir = _resolve_registered_path(run_dir_value)
        if not run_dir.is_dir():
            raise FileNotFoundError(f"Seed {seed} registered original run directory does not exist: {run_dir}")
        expected_run_prefix = f"{EXPECTED_EXPERIMENT_ID}_s{seed}_"
        if not run_dir.name.startswith(expected_run_prefix):
            raise ValueError(f"Run directory does not identify the common-loss experiment and seed {seed}: {run_dir}")
        expected_names = {
            "configuration": "config.yml",
            "checkpoint": f"model_epoch{FIXED_EPOCH:03d}.pt",
            "predictions": "test_results.p",
            "metrics": "test_metrics.csv",
        }
        if _resolve_registered_path(output_record.get("run_dir", "")) != run_dir:
            raise ValueError(f"Seed {seed} registered run directory does not match the run ledger")
        registered_paths = {}
        for name, expected_name in expected_names.items():
            registered_path = _resolve_registered_path(output_record.get(f"{name}_path", ""))
            if registered_path.name != expected_name or registered_path.parent.name != f"seed_{seed}":
                raise ValueError(
                    f"Seed {seed} registered {name} path does not match the read-only fixed epoch-"
                    f"{FIXED_EPOCH} archive"
                )
            if registered_path.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH):
                raise ValueError(f"Seed {seed} registered {name} artifact must be read-only")
            current_archive_root = registered_path.parent.parent
            if archive_root is None:
                archive_root = current_archive_root
            elif current_archive_root != archive_root:
                raise ValueError("All neural output records must share one read-only archive root")
            registered_hash = str(output_record.get(f"{name}_sha256", ""))
            if not registered_hash or _sha256(registered_path) != registered_hash:
                raise ValueError(f"Seed {seed} registered {name} hash mismatch")
            registered_paths[name] = registered_path
        run_configuration_path = registered_paths["configuration"]
        checkpoint_path = registered_paths["checkpoint"]
        prediction_path = registered_paths["predictions"]
        metric_path = registered_paths["metrics"]
        run_configuration_sha256 = str(output_record["configuration_sha256"])
        run_configuration, _ = _load_yaml_snapshot(
            run_configuration_path,
            label=f"Seed {seed} run-local configuration",
            expected_sha256=run_configuration_sha256,
        )
        validate_fixed_configuration(run_configuration)
        if int(run_configuration.get("seed", -1)) != seed or run_configuration.get(
            "experiment_name"
        ) != expected_experiment_name:
            raise ValueError(
                f"Seed {seed} run-local configuration must identify {expected_experiment_name}, got "
                f"seed={run_configuration.get('seed')}, "
                f"experiment_name={run_configuration.get('experiment_name')}"
            )
        if training_commit_hash is None:
            training_commit_hash = str(run_configuration.get("commit_hash", "")).strip()
            if not training_commit_hash:
                raise ValueError(f"Seed {seed} run-local configuration is missing commit_hash")
        _validate_run_configuration_matches_frozen(
            run_configuration,
            configuration,
            run_dir=run_dir,
            expected_commit_hash=training_commit_hash,
        )
        sources.append(
            _source_record(
                f"neural_seed_{seed}_run_configuration",
                run_configuration_path,
                expected_sha256=run_configuration_sha256,
            )
        )
        prediction_sha256 = str(output_record["predictions_sha256"])
        frames.append(
            _load_neural_pickle(
                prediction_path,
                seed=seed,
                expected_basin_count=expected_basin_count,
                expected_sha256=prediction_sha256,
            )
        )
        _assert_unchanged(prediction_path, prediction_sha256, label=f"Seed {seed} predictions")
        sources.append(
            _source_record(
                f"neural_seed_{seed}_epoch_{FIXED_EPOCH}_checkpoint",
                checkpoint_path,
                expected_sha256=str(output_record["checkpoint_sha256"]),
            )
        )
        sources.append(
            _source_record(
                f"neural_seed_{seed}_epoch_{FIXED_EPOCH}_predictions",
                prediction_path,
                expected_sha256=prediction_sha256,
            )
        )
        sources.append(
            _source_record(
                f"neural_seed_{seed}_epoch_{FIXED_EPOCH}_metrics",
                metric_path,
                expected_sha256=str(output_record["metrics_sha256"]),
            )
        )
    predictions = pd.concat(frames, ignore_index=True)
    build_eight_seed_ensemble(predictions)
    _assert_registered_neural_artifacts_unchanged(output_records)
    return predictions, sources


def load_registered_conceptual_predictions(
    manifest_path: Path,
    *,
    expected_basin_count: int = 531,
    expected_protocol_path: Path | None = None,
) -> tuple[pd.DataFrame, list[dict]]:
    """Load exactly three content-pinned common-loss conceptual daily artifacts."""
    manifest_path = Path(manifest_path).resolve()
    manifest, manifest_sha256 = _load_json_snapshot(manifest_path, label="Conceptual prediction manifest")
    if manifest.get("status") != "completed":
        raise ValueError(f"Conceptual prediction manifest is not completed: {manifest.get('status')}")
    if manifest.get("experiment_id") != EXPECTED_EXPERIMENT_ID:
        raise ValueError(f"Unexpected conceptual experiment identifier: {manifest.get('experiment_id')}")
    if manifest.get("loss_protocol") != LOSS_PROTOCOL:
        raise ValueError(f"Unexpected conceptual loss protocol: {manifest.get('loss_protocol')}")
    if manifest.get("calibration_settings") != FIXED_CONCEPTUAL_CALIBRATION_SETTINGS:
        raise ValueError(
            "Conceptual calibration settings do not match the frozen common-loss replication: "
            f"expected {FIXED_CONCEPTUAL_CALIBRATION_SETTINGS}, got {manifest.get('calibration_settings')}"
        )
    protocol_path = _resolve_registered_path(manifest.get("protocol_manifest_path", ""))
    protocol_sha256 = str(manifest.get("protocol_manifest_sha256", ""))
    if _sha256(protocol_path) != protocol_sha256:
        raise ValueError("Conceptual common-loss protocol hash mismatch")
    if expected_protocol_path is not None:
        requested_protocol_path = Path(expected_protocol_path).resolve()
        if protocol_path != requested_protocol_path or _sha256(protocol_path) != _sha256(requested_protocol_path):
            raise ValueError("Conceptual manifest does not match the requested common-loss protocol")
    artifacts = manifest.get("artifacts")
    artifact_models = [str(item.get("model")) for item in artifacts] if isinstance(artifacts, list) else []
    if len(artifact_models) != len(CONCEPTUAL_MODELS) or any(
        artifact_models.count(model) != 1 for model in CONCEPTUAL_MODELS
    ):
        raise ValueError(f"Conceptual manifest must register exactly one artifact for each of {CONCEPTUAL_MODELS}")

    sources = [
        _source_record(
            "conceptual_prediction_manifest", manifest_path, expected_sha256=manifest_sha256
        ),
        _source_record(
            "conceptual_common_loss_protocol", protocol_path, expected_sha256=protocol_sha256
        ),
    ]
    frames = []
    for model in CONCEPTUAL_MODELS:
        record = next(item for item in artifacts if str(item.get("model")) == model)
        summary_path = _resolve_registered_path(record["calibration_summary_path"])
        summary_sha256 = str(record.get("calibration_summary_sha256", ""))
        summary, _ = _load_csv_snapshot(
            summary_path,
            label=f"{model} calibration summary",
            expected_sha256=summary_sha256,
            dtype={"basin_id": str},
        )
        _require_columns(summary, ["basin_id", "period", "run_status", "nse"], label=f"{model} summary")
        successful_evaluation = summary[
            summary["period"].astype(str).eq("evaluation")
            & summary["run_status"].astype(str).eq("success")
        ].copy()
        successful_evaluation["basin_id"] = _normalize_basin_ids(successful_evaluation["basin_id"])
        if successful_evaluation["basin_id"].duplicated().any():
            raise ValueError(f"{model} calibration summary contains duplicate evaluation basins")
        _validate_basin_count(successful_evaluation, expected_basin_count)
        if not np.isfinite(pd.to_numeric(successful_evaluation["nse"], errors="raise").to_numpy(dtype=float)).all():
            raise ValueError(f"{model} calibration summary contains non-finite evaluation NSE values")
        path = _resolve_registered_path(record["daily_predictions_path"])
        daily_sha256 = str(record.get("daily_predictions_sha256", ""))
        frame, actual_hash = _load_csv_snapshot(
            path,
            label=f"{model} daily predictions",
            expected_sha256=daily_sha256,
            dtype={"basin_id": str},
        )
        if "model" in frame and not frame["model"].astype(str).eq(model).all():
            raise ValueError(f"{model} daily file contains a different model label")
        frame["model"] = model
        frame = _normalize_daily_predictions(frame, label=f"{model} daily predictions")
        _validate_basin_count(frame, expected_basin_count)
        if set(successful_evaluation["basin_id"]) != set(frame["basin_id"]):
            raise ValueError(f"{model} summary and daily prediction basin sets differ")
        frames.append(frame[["model", "basin_id", "date", "obs", "sim"]])
        sources.extend([
            _source_record(
                f"conceptual_{model}_calibration_summary",
                summary_path,
                expected_sha256=summary_sha256,
            ),
            _source_record(
                f"conceptual_{model}_daily_predictions",
                path,
                expected_sha256=str(record["daily_predictions_sha256"]),
            ),
        ])
    combined = pd.concat(frames, ignore_index=True)
    first = combined[combined["model"] == CONCEPTUAL_MODELS[0]].sort_values(["basin_id", "date"])
    first_keys = pd.MultiIndex.from_frame(first[["basin_id", "date"]])
    first_obs = first["obs"].to_numpy(dtype=float)
    for model in CONCEPTUAL_MODELS[1:]:
        candidate = combined[combined["model"] == model].sort_values(["basin_id", "date"])
        if not pd.MultiIndex.from_frame(candidate[["basin_id", "date"]]).equals(first_keys):
            raise ValueError(f"{model} basin-date mask does not match {CONCEPTUAL_MODELS[0]}")
        if not np.array_equal(candidate["obs"].to_numpy(dtype=float), first_obs):
            raise ValueError(f"{model} observations do not match {CONCEPTUAL_MODELS[0]}")
    return combined, sources


def _validate_sources_unchanged(sources: Sequence[dict]) -> None:
    for record in sources:
        path = Path(str(record.get("path", "")))
        expected = str(record.get("sha256", ""))
        if not path.is_file() or _sha256(path) != expected:
            raise RuntimeError(
                "Registered source changed before analysis output: "
                f"role={record.get('role')}, expected_sha256={expected}, path={path}"
            )


def _remove_file(path: Path) -> None:
    path = Path(path)
    if path.exists():
        path.chmod(path.stat().st_mode | stat.S_IWRITE)
        path.unlink()


def _analysis_output_paths(output_dir: Path) -> dict[str, Path]:
    output_dir = Path(output_dir).resolve()
    return {
        "per_basin_nse": output_dir / "per_basin_nse.csv",
        "nse_summary": output_dir / "nse_summary.csv",
        "per_basin_context_mae": output_dir / "per_basin_context_mae.csv",
        "context_summary": output_dir / "context_summary.csv",
        "snow_high_minus_low_bootstrap": output_dir / "snow_high_minus_low_bootstrap.json",
    }


def _cleanup_analysis_outputs(output_dir: Path) -> None:
    output_dir = Path(output_dir).resolve()
    output_paths = _analysis_output_paths(output_dir)
    for path in [
        *output_paths.values(),
        *(path.with_suffix(path.suffix + ".sources.json") for path in output_paths.values()),
        output_dir / "analysis_manifest.json",
    ]:
        _remove_file(path)
    if output_dir.is_dir() and not any(output_dir.iterdir()):
        output_dir.rmdir()


def _assert_written_bundle_member(
    output_path: Path,
    sidecar_path: Path,
    sidecar: dict,
    *,
    expected_sidecar_text: str,
) -> None:
    if _sha256(output_path) != sidecar["table_sha256"]:
        raise RuntimeError(f"analysis output bundle changed after table write: {output_path}")
    expected_sidecar_sha256 = hashlib.sha256(expected_sidecar_text.encode("utf-8")).hexdigest()
    if _sha256(sidecar_path) != expected_sidecar_sha256:
        raise RuntimeError(f"analysis output bundle changed after sidecar write: {sidecar_path}")
    loaded_sidecar, _ = _load_json_snapshot(
        sidecar_path,
        label="Analysis source sidecar",
        expected_sha256=expected_sidecar_sha256,
    )
    if loaded_sidecar != sidecar:
        raise RuntimeError(f"analysis output bundle changed after sidecar write: {sidecar_path}")


def write_csv_with_sources(
    frame: pd.DataFrame,
    output_path: Path,
    sources: Sequence[dict],
    *,
    published_output_path: Path | None = None,
) -> dict:
    """Write a protocol-labeled table and an adjacent content-pinned source sidecar."""
    output_path = Path(output_path).resolve()
    sidecar_path = output_path.with_suffix(output_path.suffix + ".sources.json")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output = frame.copy()
    if "loss_protocol" in output:
        if not output["loss_protocol"].astype(str).eq(LOSS_PROTOCOL).all():
            raise ValueError("Output table contains a conflicting loss protocol")
    else:
        output.insert(0, "loss_protocol", LOSS_PROTOCOL)
    try:
        _validate_sources_unchanged(sources)
        output.to_csv(output_path, index=False)
        _validate_sources_unchanged(sources)
        sidecar = {
            "loss_protocol": LOSS_PROTOCOL,
            "table_path": str(Path(published_output_path).resolve()) if published_output_path else str(output_path),
            "table_sha256": _sha256(output_path),
            "sources": list(sources),
        }
        sidecar_text = json.dumps(sidecar, indent=2, sort_keys=True) + "\n"
        sidecar_path.write_text(sidecar_text, encoding="utf-8", newline="\n")
        _validate_sources_unchanged(sources)
        _assert_written_bundle_member(
            output_path,
            sidecar_path,
            sidecar,
            expected_sidecar_text=sidecar_text,
        )
        return sidecar
    except BaseException:
        _remove_file(output_path)
        _remove_file(sidecar_path)
        raise


def _write_json_with_sources(
    payload: dict,
    output_path: Path,
    sources: Sequence[dict],
    *,
    published_output_path: Path | None = None,
) -> dict:
    output_path = Path(output_path).resolve()
    sidecar_path = output_path.with_suffix(output_path.suffix + ".sources.json")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    document = {"loss_protocol": LOSS_PROTOCOL, **payload}
    try:
        _validate_sources_unchanged(sources)
        output_path.write_text(json.dumps(document, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        _validate_sources_unchanged(sources)
        sidecar = {
            "loss_protocol": LOSS_PROTOCOL,
            "table_path": str(Path(published_output_path).resolve()) if published_output_path else str(output_path),
            "table_sha256": _sha256(output_path),
            "sources": list(sources),
        }
        sidecar_text = json.dumps(sidecar, indent=2, sort_keys=True) + "\n"
        sidecar_path.write_text(sidecar_text, encoding="utf-8", newline="\n")
        _validate_sources_unchanged(sources)
        _assert_written_bundle_member(
            output_path,
            sidecar_path,
            sidecar,
            expected_sidecar_text=sidecar_text,
        )
        return sidecar
    except BaseException:
        _remove_file(output_path)
        _remove_file(sidecar_path)
        raise


def _validate_analysis_bundle(
    *,
    output_paths: dict[str, Path],
    published_output_paths: dict[str, Path],
    sidecars: dict[str, dict],
    manifest_path: Path,
    manifest: dict,
) -> None:
    manifest_text = json.dumps(manifest, indent=2, sort_keys=True) + "\n"
    manifest_sha256 = hashlib.sha256(manifest_text.encode("utf-8")).hexdigest()
    if _sha256(manifest_path) != manifest_sha256:
        raise RuntimeError(f"analysis output bundle changed after manifest write: {manifest_path}")
    loaded_manifest, _ = _load_json_snapshot(
        manifest_path,
        label="Analysis manifest",
        expected_sha256=manifest_sha256,
    )
    if loaded_manifest != manifest:
        raise RuntimeError(f"analysis output bundle changed after manifest write: {manifest_path}")
    for name, output_path in output_paths.items():
        record = manifest["outputs"][name]
        published_output_path = published_output_paths[name]
        sidecar_path = output_path.with_suffix(output_path.suffix + ".sources.json")
        published_sidecar_path = published_output_path.with_suffix(published_output_path.suffix + ".sources.json")
        if record["path"] != str(published_output_path) or record["sha256"] != _sha256(output_path):
            raise RuntimeError(f"analysis output bundle changed: {output_path}")
        if record["source_sidecar_path"] != str(published_sidecar_path):
            raise RuntimeError(f"analysis output bundle changed: {sidecar_path}")
        if record["source_sidecar_sha256"] != _sha256(sidecar_path):
            raise RuntimeError(f"analysis output bundle changed: {sidecar_path}")
        loaded_sidecar, _ = _load_json_snapshot(
            sidecar_path,
            label=f"Analysis source sidecar {name}",
            expected_sha256=record["source_sidecar_sha256"],
        )
        if loaded_sidecar != sidecars[name] or record["source_sidecar"] != sidecars[name]:
            raise RuntimeError(f"analysis output bundle changed: {sidecar_path}")
        if loaded_sidecar["table_path"] != str(published_output_path):
            raise RuntimeError(f"analysis output bundle changed: {sidecar_path}")
        if loaded_sidecar["table_sha256"] != record["sha256"]:
            raise RuntimeError(f"analysis output bundle changed: {output_path}")


def _make_analysis_bundle_read_only(paths: Sequence[Path]) -> None:
    for path in paths:
        path.chmod(path.stat().st_mode & ~stat.S_IWRITE)
    for path in paths:
        if path.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH):
            raise RuntimeError(f"Analysis output bundle is not read-only: {path}")


def _validate_published_analysis_bundle(output_dir: Path, manifest: dict) -> dict:
    output_dir = Path(output_dir).resolve()
    output_paths = _analysis_output_paths(output_dir)
    manifest_path = output_dir / "analysis_manifest.json"
    sidecar_paths = {
        name: path.with_suffix(path.suffix + ".sources.json") for name, path in output_paths.items()
    }
    expected_paths = {*output_paths.values(), *sidecar_paths.values(), manifest_path}
    try:
        actual_paths = set(output_dir.iterdir())
        if actual_paths != expected_paths:
            raise RuntimeError(
                f"expected exactly {len(expected_paths)} registered files, found {len(actual_paths)}"
            )
        manifest_text = json.dumps(manifest, indent=2, sort_keys=True) + "\n"
        manifest_sha256 = hashlib.sha256(manifest_text.encode("utf-8")).hexdigest()
        loaded_manifest, _ = _load_json_snapshot(
            manifest_path,
            label="Published analysis manifest",
            expected_sha256=manifest_sha256,
        )
        if loaded_manifest != manifest:
            raise RuntimeError("published manifest content does not match the completed transaction")
        _validate_sources_unchanged(manifest["sources"])
        for path in expected_paths:
            if path.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH):
                raise RuntimeError(f"published artifact is not read-only: {path}")
        for name, output_path in output_paths.items():
            record = manifest["outputs"][name]
            sidecar_path = sidecar_paths[name]
            if record["path"] != str(output_path) or record["sha256"] != _sha256(output_path):
                raise RuntimeError(f"published output hash or path mismatch: {output_path}")
            if record["source_sidecar_path"] != str(sidecar_path):
                raise RuntimeError(f"published source sidecar path mismatch: {sidecar_path}")
            if record["source_sidecar_sha256"] != _sha256(sidecar_path):
                raise RuntimeError(f"published source sidecar hash mismatch: {sidecar_path}")
            loaded_sidecar, _ = _load_json_snapshot(
                sidecar_path,
                label=f"Published analysis source sidecar {name}",
                expected_sha256=record["source_sidecar_sha256"],
            )
            if loaded_sidecar != record["source_sidecar"]:
                raise RuntimeError(f"published source sidecar content mismatch: {sidecar_path}")
            if loaded_sidecar["table_path"] != str(output_path):
                raise RuntimeError(f"published table path mismatch: {sidecar_path}")
            if loaded_sidecar["table_sha256"] != record["sha256"]:
                raise RuntimeError(f"published table hash mismatch: {output_path}")
        return manifest
    except Exception as error:
        raise RuntimeError(f"analysis output bundle changed after publish: {error}") from error


def _run_analysis_transaction(
    *,
    run_ledger_path: Path,
    conceptual_manifest_path: Path,
    basin_regimes_path: Path,
    protocol_manifest_path: Path,
    output_dir: Path,
    published_output_dir: Path | None = None,
) -> dict:
    """Compute and write one analysis transaction after the outer cleanup guard is installed."""
    protocol_path = Path(protocol_manifest_path).resolve()
    protocol, protocol_sha256 = _load_json_snapshot(protocol_path, label="Common-loss protocol")
    if protocol.get("status") != "passed" or int(protocol.get("basin_count", 0)) != 531:
        raise ValueError("Common-loss protocol must be passed for exactly 531 basins")
    neural, neural_sources = load_registered_neural_predictions(
        run_ledger_path,
        expected_basin_count=531,
        expected_protocol_path=protocol_path,
    )
    conceptual, conceptual_sources = load_registered_conceptual_predictions(
        conceptual_manifest_path,
        expected_basin_count=531,
        expected_protocol_path=protocol_path,
    )
    regime_path = Path(basin_regimes_path).resolve()
    regimes, regime_sha256 = _load_csv_snapshot(
        regime_path, label="Basin regime table", dtype={"basin_id": str}
    )
    ensemble = build_eight_seed_ensemble(neural)
    panel = build_daily_panel(ensemble, conceptual, regimes, expected_basin_count=531)
    per_basin_nse = compute_per_basin_nse(panel, expected_basin_count=531)
    nse_summary = summarize_nse(per_basin_nse, expected_basin_count=531)
    per_basin_context, context_summary = summarize_context_mae(panel)
    bootstrap = paired_high_minus_low_bootstrap(per_basin_context, regime="snow-dominated")

    sources = [
        _source_record("common_loss_protocol", protocol_path, expected_sha256=protocol_sha256),
        *neural_sources,
        *conceptual_sources,
        _source_record("basin_regime_table", regime_path, expected_sha256=regime_sha256),
    ]
    output_dir = Path(output_dir).resolve()
    published_output_dir = Path(published_output_dir or output_dir).resolve()
    output_paths = _analysis_output_paths(output_dir)
    published_output_paths = _analysis_output_paths(published_output_dir)
    manifest_path = output_dir / "analysis_manifest.json"
    try:
        sidecars = {
            "per_basin_nse": write_csv_with_sources(
                per_basin_nse,
                output_paths["per_basin_nse"],
                sources,
                published_output_path=published_output_paths["per_basin_nse"],
            ),
            "nse_summary": write_csv_with_sources(
                nse_summary,
                output_paths["nse_summary"],
                sources,
                published_output_path=published_output_paths["nse_summary"],
            ),
            "per_basin_context_mae": write_csv_with_sources(
                per_basin_context,
                output_paths["per_basin_context_mae"],
                sources,
                published_output_path=published_output_paths["per_basin_context_mae"],
            ),
            "context_summary": write_csv_with_sources(
                context_summary,
                output_paths["context_summary"],
                sources,
                published_output_path=published_output_paths["context_summary"],
            ),
            "snow_high_minus_low_bootstrap": _write_json_with_sources(
                bootstrap,
                output_paths["snow_high_minus_low_bootstrap"],
                sources,
                published_output_path=published_output_paths["snow_high_minus_low_bootstrap"],
            ),
        }
        manifest = {
            "experiment_id": EXPECTED_EXPERIMENT_ID,
            "status": "completed",
            "loss_protocol": LOSS_PROTOCOL,
            "historical_results_included": False,
            "historical_results_policy": "Original-loss results remain separate and are not read by this analysis.",
            "outputs": {
                name: {
                    "path": str(published_output_paths[name]),
                    "sha256": _sha256(path),
                    "source_sidecar_path": str(
                        published_output_paths[name].with_suffix(
                            published_output_paths[name].suffix + ".sources.json"
                        )
                    ),
                    "source_sidecar_sha256": _sha256(path.with_suffix(path.suffix + ".sources.json")),
                    "source_sidecar": sidecars[name],
                }
                for name, path in output_paths.items()
            },
            "sources": sources,
        }
        _validate_sources_unchanged(sources)
        manifest_path.write_text(
            json.dumps(manifest, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
            newline="\n",
        )
        _validate_sources_unchanged(sources)
        _validate_analysis_bundle(
            output_paths=output_paths,
            published_output_paths=published_output_paths,
            sidecars=sidecars,
            manifest_path=manifest_path,
            manifest=manifest,
        )
        bundle_paths = [
            *output_paths.values(),
            *(path.with_suffix(path.suffix + ".sources.json") for path in output_paths.values()),
            manifest_path,
        ]
        _make_analysis_bundle_read_only(bundle_paths)
        _validate_analysis_bundle(
            output_paths=output_paths,
            published_output_paths=published_output_paths,
            sidecars=sidecars,
            manifest_path=manifest_path,
            manifest=manifest,
        )
        return manifest
    except BaseException:
        _cleanup_analysis_outputs(output_dir)
        raise


def _registered_neural_guard_paths(run_ledger_path: Path) -> list[Path]:
    ledger_path = Path(run_ledger_path).resolve()
    ledger, _ = _load_json_snapshot(ledger_path, label="Neural run ledger for stability guard")
    output_records = ledger.get("output_records")
    if not isinstance(output_records, list) or len(output_records) != len(FIXED_SEEDS):
        raise ValueError("Neural run ledger must register eight output records before analysis")
    return [ledger_path, *_registered_output_paths(output_records)]


def _run_analysis_with_locked_sources(
    *,
    run_ledger_path: Path,
    conceptual_manifest_path: Path,
    basin_regimes_path: Path,
    protocol_manifest_path: Path,
    output_dir: Path,
) -> dict:
    """Run the real 531-basin analysis and atomically publish one read-only output directory."""
    output_dir = Path(output_dir).resolve()
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    staging_dir = Path(
        tempfile.mkdtemp(prefix=f".{output_dir.name}.staging-", dir=output_dir.parent)
    ).resolve()
    try:
        manifest = _run_analysis_transaction(
            run_ledger_path=run_ledger_path,
            conceptual_manifest_path=conceptual_manifest_path,
            basin_regimes_path=basin_regimes_path,
            protocol_manifest_path=protocol_manifest_path,
            output_dir=staging_dir,
            published_output_dir=output_dir,
        )
        _cleanup_analysis_outputs(output_dir)
        if output_dir.exists():
            raise RuntimeError(f"Analysis output directory contains unregistered files: {output_dir}")
        staging_dir.replace(output_dir)
        output_paths = _analysis_output_paths(output_dir)
        published_paths = [
            *output_paths.values(),
            *(path.with_suffix(path.suffix + ".sources.json") for path in output_paths.values()),
            output_dir / "analysis_manifest.json",
        ]
        with _ArtifactStabilityGuard(published_paths):
            return _validate_published_analysis_bundle(output_dir, manifest)
    except BaseException:
        if staging_dir.exists():
            _cleanup_analysis_outputs(staging_dir)
        _cleanup_analysis_outputs(output_dir)
        raise


def run_analysis(
    *,
    run_ledger_path: Path,
    conceptual_manifest_path: Path,
    basin_regimes_path: Path,
    protocol_manifest_path: Path,
    output_dir: Path,
) -> dict:
    """Lock neural archives through one atomic, terminally validated analysis publication."""
    output_dir = Path(output_dir).resolve()
    try:
        with _ArtifactStabilityGuard(_registered_neural_guard_paths(run_ledger_path)):
            return _run_analysis_with_locked_sources(
                run_ledger_path=run_ledger_path,
                conceptual_manifest_path=conceptual_manifest_path,
                basin_regimes_path=basin_regimes_path,
                protocol_manifest_path=protocol_manifest_path,
                output_dir=output_dir,
            )
    except BaseException:
        _cleanup_analysis_outputs(output_dir)
        raise


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--run-ledger",
        type=Path,
        default=_DEFAULT_RESULT_ROOT / "registry" / "run_ledger.json",
    )
    parser.add_argument(
        "--conceptual-manifest",
        type=Path,
        default=_DEFAULT_RESULT_ROOT / "conceptual" / "conceptual_prediction_manifest.json",
    )
    parser.add_argument(
        "--basin-regimes",
        type=Path,
        default=_REPOSITORY_ROOT
        / "draft"
        / "papers"
        / "10_18_conceptual_lstm_package"
        / "deep_dive"
        / "D01_structure_diagnostic_20260709"
        / "tables"
        / "basin_attribute_panel.csv",
    )
    parser.add_argument(
        "--protocol-manifest",
        type=Path,
        default=_DEFAULT_RESULT_ROOT / "protocol" / "common_loss_protocol.json",
    )
    parser.add_argument("--output-dir", type=Path, default=_DEFAULT_RESULT_ROOT / "analysis")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    manifest = run_analysis(
        run_ledger_path=args.run_ledger,
        conceptual_manifest_path=args.conceptual_manifest,
        basin_regimes_path=args.basin_regimes,
        protocol_manifest_path=args.protocol_manifest,
        output_dir=args.output_dir,
    )
    print(json.dumps({"status": manifest["status"], "outputs": manifest["outputs"]}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
