"""Assemble the three-point objective dose-response for the ID18 manuscript.

Every registered arm sits on one axis: the weight each ten-percent flow tail receives as a
multiple of its realized share of observations. The reverse arm is 0.3, the plain
one-minus-NSE baseline is 1, and the registered equal-regime arm is about 3.34.

This script recomputes the variability ratio and the daily correlation for all three arms
from registered daily predictions. It trains nothing and calibrates nothing.
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

from src.loss_mechanism_531.score_flow_regime_loss_experiment import (
    BOOTSTRAP_SEED,
    _load_conceptual_daily,
    load_neural_ensemble,
    whole_basin_median_interval,
)
from src.lstm_fair_531.scripts.run_e01_amplitude_response import amplitude_geometry

E01_ROOT = Path("results/18_lstm_fair_531/E01_flow_regime_balanced_loss_531")
E02_ROOT = Path("results/18_lstm_fair_531/E02_reverse_tail_emphasis_531")
CONCEPTUAL_MODELS = ("gr4j", "xaj", "hbv_lite")
NEURAL_MODEL = "lstm_three_seed_ensemble"

# (arm label, nominal tail multiplier, conceptual daily root, neural run root)
#
# The reverse and baseline arms set the multiplier directly, so their nominal value is exact.
# The equal-regime arm instead fixes each regime at exactly one third of the weight; because the
# tail boundary is floored, a nominal one-tenth tail holds slightly under a tenth of the days, so
# its realized multiplier is about 3.34 to 3.35 rather than the 3.333 recorded here. The ordering
# and the monotonicity check are unaffected; only the axis label carries this approximation.
ARMS = (
    ("tail_downweighted_nse", 0.3, E02_ROOT / "conceptual" / "tail_downweighted_nse",
     Path("runs/e02_loss/tail_downweighted_nse")),
    ("nse", 1.0, E01_ROOT / "conceptual" / "nse", Path("runs/e01_loss/nse")),
    ("flow_regime_nse", 10.0 / 3.0, E01_ROOT / "conceptual" / "flow_regime_nse",
     Path("runs/e01_loss/flow_regime_nse")),
)
NOMINAL_MULTIPLIER_IS_EXACT = {
    "tail_downweighted_nse": True,
    "nse": True,
    "flow_regime_nse": False,
}
METRICS = ("variability_ratio", "correlation")


def collect_rows(expected_basins: int, require_neural: bool) -> pd.DataFrame:
    rows: list[dict] = []
    for arm, multiplier, conceptual_root, neural_root in ARMS:
        for model in CONCEPTUAL_MODELS:
            mapping = _load_conceptual_daily(conceptual_root / model / "daily")
            if len(mapping) != expected_basins:
                raise ValueError(f"{arm}/{model} has {len(mapping)} basins, expected {expected_basins}")
            for basin_id, (_, observed, simulated) in mapping.items():
                rows.append({
                    "arm": arm, "tail_multiplier": multiplier, "model": model,
                    "basin_id": basin_id, **amplitude_geometry(observed, simulated)
                })
        prediction_paths = sorted(neural_root.glob("*/test/model_epoch030/test_results.p"))
        if not prediction_paths:
            if require_neural:
                raise ValueError(f"no registered neural predictions for arm {arm} under {neural_root}")
            print(f"skipping neural predictions for {arm}: none found under {neural_root}")
            continue
        mapping = load_neural_ensemble(prediction_paths)
        if len(mapping) != expected_basins:
            raise ValueError(f"{arm}/{NEURAL_MODEL} has {len(mapping)} basins, expected {expected_basins}")
        for basin_id, (_, observed, simulated) in mapping.items():
            rows.append({
                "arm": arm, "tail_multiplier": multiplier, "model": NEURAL_MODEL,
                "basin_id": basin_id, **amplitude_geometry(observed, simulated)
            })
    return pd.DataFrame(rows).sort_values(["model", "tail_multiplier", "basin_id"]).reset_index(drop=True)


def dose_response_summary(per_basin: pd.DataFrame) -> pd.DataFrame:
    """Median level per arm plus the paired change against the one-times baseline."""
    rows = []
    for model, model_rows in per_basin.groupby("model", sort=True):
        baseline = model_rows[model_rows["arm"] == "nse"].set_index("basin_id")
        for arm, multiplier, _, _ in ARMS:
            arm_rows = model_rows[model_rows["arm"] == arm]
            if arm_rows.empty:
                continue
            arm_rows = arm_rows.set_index("basin_id")
            common = baseline.index.intersection(arm_rows.index)
            if len(common) != len(baseline):
                raise ValueError(f"paired basin sets differ for {model}/{arm}")
            for offset, metric in enumerate(METRICS):
                change = (arm_rows.loc[common, metric] - baseline.loc[common, metric]).to_numpy(dtype=float)
                finite = change[np.isfinite(change)]
                if arm == "nse":
                    estimate, lower, upper = 0.0, 0.0, 0.0
                else:
                    estimate, lower, upper = whole_basin_median_interval(finite, seed=BOOTSTRAP_SEED + offset)
                rows.append({
                    "model": model, "arm": arm, "tail_multiplier": multiplier,
                    "tail_multiplier_is_exact": NOMINAL_MULTIPLIER_IS_EXACT[arm], "metric": metric,
                    "paired_basin_count": int(len(common)),
                    "defined_basin_count": int(np.isfinite(arm_rows.loc[common, metric]).sum()),
                    "change_basin_count": int(finite.size),
                    "arm_median": float(arm_rows.loc[common, metric].median()),
                    "median_change_from_baseline": estimate,
                    "ci_lower": lower, "ci_upper": upper,
                    "interval_excludes_zero": bool(lower > 0.0 or upper < 0.0),
                })
    return pd.DataFrame(rows)


def monotonicity_check(summary: pd.DataFrame) -> pd.DataFrame:
    """Report whether each model's variability ratio rises monotonically along the axis."""
    rows = []
    for (model, metric), group in summary.groupby(["model", "metric"], sort=True):
        ordered = group.sort_values("tail_multiplier")
        levels = ordered["arm_median"].to_numpy(dtype=float)
        rows.append({
            "model": model,
            "metric": metric,
            "arm_count": int(levels.size),
            "minimum_defined_basin_count": int(ordered["defined_basin_count"].min()),
            "level_at_lowest_multiplier": float(levels[0]),
            "level_at_highest_multiplier": float(levels[-1]),
            "span": float(levels.max() - levels.min()),
            "monotone_increasing": bool(levels.size >= 2 and np.all(np.diff(levels) > 0.0)),
        })
    return pd.DataFrame(rows)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-name", default="analysis_dose_response_20260807")
    parser.add_argument("--expected-basins", type=int, default=531)
    parser.add_argument("--allow-missing-neural", action="store_true",
                        help="summarize the conceptual models before the neural arm finishes training")
    return parser


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)
    output_directory = E02_ROOT / args.output_name
    output_directory.mkdir(parents=True, exist_ok=True)

    per_basin = collect_rows(args.expected_basins, require_neural=not args.allow_missing_neural)
    summary = dose_response_summary(per_basin)
    monotone = monotonicity_check(summary)

    per_basin_path = output_directory / "dose_response_by_basin.csv"
    summary_path = output_directory / "dose_response_summary.csv"
    monotone_path = output_directory / "dose_response_monotonicity.csv"
    per_basin.to_csv(per_basin_path, index=False)
    summary.to_csv(summary_path, index=False)
    monotone.to_csv(monotone_path, index=False)

    variability = monotone[monotone["metric"] == "variability_ratio"]
    manifest = {
        "experiment_ids": ["E01_flow_regime_balanced_loss_531", "E02_reverse_tail_emphasis_531"],
        "derivation_id": args.output_name,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "axis": "weight given to each ten-percent flow tail as a multiple of its realized share",
        "arm_multipliers": {arm: multiplier for arm, multiplier, _, _ in ARMS},
        "models_with_monotone_variability_ratio": int(variability["monotone_increasing"].sum()),
        "models_summarized": int(variability.shape[0]),
        "bootstrap": {"unit": "whole_basin", "resamples": 10000, "seed": BOOTSTRAP_SEED},
        "inference_boundary": ("Internal-holdout mechanism comparison, not paper evaluation-period "
                               "performance; the paper evaluation period was not read."),
    }
    (output_directory / "dose_response_manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"wrote {per_basin_path}")
    print(f"wrote {summary_path}")
    print(f"wrote {monotone_path}")
    print(monotone.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
