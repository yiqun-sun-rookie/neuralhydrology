"""Ask whether the objective moves event shape the way it moves flow variability.

The registered dose-response experiment measures the variability ratio and the daily
correlation across three points of the tail-emphasis axis. It never measured event shape,
so the manuscript's structural claim about event shape rests on a single objective.

This script closes that gap from registered daily predictions. It trains nothing and
calibrates nothing. Events are placed from the observations alone, so every arm and every
model shares one event set per basin and the comparison is paired by construction.

The contract in
``results/18_lstm_fair_531/E03_event_shape_dose_response_531/protocol/e03_event_shape_contract.json``
is registered before this analysis runs and fixes the decision thresholds.
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

from src.lstm_fair_531.scripts.hydrological_process_diagnostics import (
    compute_event_metrics,
    identify_observed_events,
)
from src.lstm_fair_531.scripts.posthoc_cause_diagnostics import event_peak_concentration
from src.lstm_fair_531.scripts.run_e02_dose_response import ARMS, NOMINAL_MULTIPLIER_IS_EXACT
from src.loss_mechanism_531.score_flow_regime_loss_experiment import (
    _load_conceptual_daily,
    load_neural_ensemble,
    whole_basin_median_interval,
)

E02_ROOT = Path("results/18_lstm_fair_531/E02_reverse_tail_emphasis_531")
OUTPUT_ROOT = Path("results/18_lstm_fair_531/E03_event_shape_dose_response_531")
CONTRACT_PATH = OUTPUT_ROOT / "protocol" / "e03_event_shape_contract.json"
VARIABILITY_SOURCE = (
    E02_ROOT / "analysis_dose_response_20260807" / "dose_response_summary.csv"
)

CONCEPTUAL_MODELS = ("gr4j", "xaj", "hbv_lite")
NEURAL_MODEL = "lstm_three_seed_ensemble"
BOOTSTRAP_RESAMPLES = 10_000
BOOTSTRAP_SEED = 20260808

# Amplitude, shape, and timing are reported separately on purpose. The aligned peak bias is
# the event-scale counterpart of the variability ratio and is expected to move; only the
# concentration divides the event volume out and therefore isolates shape.
METRICS = ("aligned_peak_magnitude_bias", "event_peak_concentration", "absolute_peak_timing_error_days")


def load_contract() -> dict:
    contract = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))
    definition = contract["event_definition"]
    if (
            int(definition["merge_gap_days"]),
            int(definition["minimum_peak_separation_days"]),
            int(definition["half_window_days"]),
    ) != (2, 5, 3):
        raise ValueError("E03 event definition drifted from the registered D09 definition")
    bootstrap = contract["summary_rule"]["bootstrap"]
    if (bootstrap["unit"], int(bootstrap["resamples"]), int(bootstrap["seed"])) != (
            "whole_basin", BOOTSTRAP_RESAMPLES, BOOTSTRAP_SEED):
        raise ValueError("E03 bootstrap contract drifted")
    return contract


def load_all_series(expected_basins: int) -> dict[tuple[str, str], dict]:
    """Return {(arm, model): {basin_id: (dates, observed, simulated)}} for every registered arm."""
    series: dict[tuple[str, str], dict] = {}
    for arm, _, conceptual_root, neural_root in ARMS:
        for model in CONCEPTUAL_MODELS:
            mapping = _load_conceptual_daily(conceptual_root / model / "daily")
            if len(mapping) != expected_basins:
                raise ValueError(f"{arm}/{model} has {len(mapping)} basins, expected {expected_basins}")
            series[(arm, model)] = mapping
        prediction_paths = sorted(neural_root.glob("*/test/model_epoch030/test_results.p"))
        if not prediction_paths:
            raise ValueError(f"no registered neural predictions for arm {arm} under {neural_root}")
        mapping = load_neural_ensemble(prediction_paths)
        if len(mapping) != expected_basins:
            raise ValueError(f"{arm}/{NEURAL_MODEL} has {len(mapping)} basins, expected {expected_basins}")
        series[(arm, NEURAL_MODEL)] = mapping
    return series


def _common_dates(series: dict[tuple[str, str], dict], basin_id: str) -> pd.DatetimeIndex:
    """Dates present in every arm and model for this basin, checked for daily continuity."""
    shared: pd.DatetimeIndex | None = None
    for mapping in series.values():
        dates = mapping[basin_id][0]
        shared = dates if shared is None else shared.intersection(dates)
    if shared is None or shared.size == 0:
        raise ValueError(f"no shared dates for basin {basin_id}")
    shared = shared.sort_values()
    if shared.size > 1:
        steps = np.diff(shared.values.astype("datetime64[D]")).astype(int)
        if not np.all(steps == 1):
            raise ValueError(f"shared dates for basin {basin_id} are not a continuous daily sequence")
    return shared


def _aligned(mapping: dict, basin_id: str, dates: pd.DatetimeIndex) -> tuple[np.ndarray, np.ndarray]:
    source_dates, observed, simulated = mapping[basin_id]
    positions = source_dates.get_indexer(dates)
    if (positions < 0).any():
        raise ValueError(f"date alignment failed for basin {basin_id}")
    return observed[positions], simulated[positions]


def collect_event_rows(series: dict[tuple[str, str], dict], contract: dict) -> tuple[pd.DataFrame, list[dict]]:
    """One row per (arm, model, basin, threshold, event); events come from observations only."""
    definition = contract["event_definition"]
    quantiles = (
        float(definition["threshold_quantiles"]["primary"]),
        float(definition["threshold_quantiles"]["sensitivity"]),
    )
    basin_ids = sorted(next(iter(series.values())).keys())
    rows: list[pd.DataFrame] = []
    skipped: list[dict] = []
    largest_observation_gap = [0.0]
    for basin_id in basin_ids:
        dates = _common_dates(series, basin_id)
        aligned = {key: _aligned(mapping, basin_id, dates) for key, mapping in series.items()}

        reference_observed = aligned[(ARMS[1][0], CONCEPTUAL_MODELS[0])][0]
        if not np.isfinite(reference_observed).all():
            skipped.append({"basin_id": basin_id, "reason": "observations contain non-finite values"})
            continue
        # The conceptual arms store six decimals in CSV while the neural arms come from pickled
        # arrays, so identical observations differ at storage precision. The tolerance admits that
        # and nothing more; the largest observed gap is recorded rather than assumed negligible.
        disagreeing = [
            f"{arm}/{model}" for (arm, model), (observed, _) in aligned.items()
            if not np.allclose(observed, reference_observed, rtol=1e-5, atol=1e-6, equal_nan=True)
        ]
        if disagreeing:
            raise ValueError(f"observations differ across sources for basin {basin_id}: {sorted(disagreeing)}")
        observation_gap = max(
            float(np.max(np.abs(observed - reference_observed))) for observed, _ in aligned.values()
        )
        largest_observation_gap[0] = max(largest_observation_gap[0], observation_gap)

        for quantile in quantiles:
            threshold = float(np.quantile(reference_observed, quantile))
            events = identify_observed_events(
                dates,
                reference_observed,
                threshold=threshold,
                merge_gap_days=int(definition["merge_gap_days"]),
                minimum_peak_separation_days=int(definition["minimum_peak_separation_days"]),
                half_window_days=int(definition["half_window_days"]),
            )
            if events.empty:
                skipped.append({
                    "basin_id": basin_id,
                    "reason": f"no events at the {quantile:.2f} threshold",
                })
                continue
            for (arm, model), (_, simulated) in aligned.items():
                if not np.isfinite(simulated).all():
                    skipped.append({
                        "basin_id": basin_id,
                        "reason": f"{arm}/{model} simulation contains non-finite values",
                    })
                    continue
                # Every model is scored against the one observation series that placed the events,
                # so the observed peak and seven-day volume denominators are identical across arms.
                metrics = compute_event_metrics(dates, reference_observed, simulated, events)
                metrics.insert(0, "event_threshold_quantile", quantile)
                metrics.insert(0, "basin_id", basin_id)
                metrics.insert(0, "model", model)
                metrics.insert(0, "arm", arm)
                rows.append(metrics)
    combined = pd.concat(rows, ignore_index=True)
    combined["event_peak_concentration"] = event_peak_concentration(
        pd.to_numeric(combined["aligned_peak_magnitude_bias"], errors="coerce").to_numpy(),
        pd.to_numeric(combined["seven_day_volume_bias"], errors="coerce").to_numpy(),
    )
    skipped.append({"largest_cross_source_observation_gap": largest_observation_gap[0]})
    return combined, skipped


def basin_level(event_rows: pd.DataFrame) -> pd.DataFrame:
    """Median across each basin's events, so every basin carries equal weight."""
    grouped = event_rows.groupby(["arm", "model", "basin_id", "event_threshold_quantile"], sort=True)
    frame = grouped[list(METRICS)].median().reset_index()
    frame["event_count"] = grouped.size().to_numpy()
    multipliers = {arm: multiplier for arm, multiplier, _, _ in ARMS}
    frame["tail_multiplier"] = frame["arm"].map(multipliers)
    return frame


def dose_response_summary(per_basin: pd.DataFrame) -> pd.DataFrame:
    """Median level per arm plus the paired change against the one-times baseline."""
    rows = []
    grouping = ["model", "event_threshold_quantile"]
    for (model, quantile), model_rows in per_basin.groupby(grouping, sort=True):
        baseline = model_rows[model_rows["arm"] == "nse"].set_index("basin_id")
        for arm, multiplier, _, _ in ARMS:
            arm_rows = model_rows[model_rows["arm"] == arm]
            if arm_rows.empty:
                continue
            arm_rows = arm_rows.set_index("basin_id")
            common = baseline.index.intersection(arm_rows.index)
            if len(common) != len(baseline):
                raise ValueError(f"paired basin sets differ for {model}/{arm} at q{quantile}")
            for offset, metric in enumerate(METRICS):
                change = (arm_rows.loc[common, metric] - baseline.loc[common, metric]).to_numpy(dtype=float)
                finite = change[np.isfinite(change)]
                if arm == "nse":
                    estimate, lower, upper = 0.0, 0.0, 0.0
                else:
                    estimate, lower, upper = whole_basin_median_interval(
                        finite, n_resamples=BOOTSTRAP_RESAMPLES, seed=BOOTSTRAP_SEED + offset)
                rows.append({
                    "model": model,
                    "event_threshold_quantile": float(quantile),
                    "arm": arm,
                    "tail_multiplier": multiplier,
                    "tail_multiplier_is_exact": NOMINAL_MULTIPLIER_IS_EXACT[arm],
                    "metric": metric,
                    "paired_basin_count": int(len(common)),
                    "defined_basin_count": int(np.isfinite(arm_rows.loc[common, metric]).sum()),
                    "change_basin_count": int(finite.size),
                    "arm_median": float(arm_rows.loc[common, metric].median()),
                    "median_change_from_baseline": estimate,
                    "ci_lower": lower,
                    "ci_upper": upper,
                    "interval_excludes_zero": bool(lower > 0.0 or upper < 0.0),
                })
    return pd.DataFrame(rows)


def _span(levels: np.ndarray) -> float:
    finite = levels[np.isfinite(levels)]
    return float(np.max(finite) - np.min(finite)) if finite.size else np.nan


def variability_ratio_spans() -> dict[str, float]:
    """Arm-to-arm span of the registered variability ratio, the yardstick for the decision rule."""
    summary = pd.read_csv(VARIABILITY_SOURCE)
    selected = summary[summary["metric"] == "variability_ratio"]
    return {
        str(model): _span(group["arm_median"].to_numpy(dtype=float))
        for model, group in selected.groupby("model", sort=True)
    }


def verdict_table(summary: pd.DataFrame, contract: dict) -> pd.DataFrame:
    """Apply the frozen decision rule without touching its thresholds."""
    reference = variability_ratio_spans()
    primary = float(contract["event_definition"]["threshold_quantiles"]["primary"])
    rows = []
    for (model, quantile, metric), group in summary.groupby(
            ["model", "event_threshold_quantile", "metric"], sort=True):
        ordered = group.sort_values("tail_multiplier")
        levels = ordered["arm_median"].to_numpy(dtype=float)
        metric_span = _span(levels)
        variability_span = reference.get(str(model), np.nan)
        ratio = metric_span / variability_span if np.isfinite(variability_span) and variability_span > 0 else np.nan
        differences = np.diff(levels[np.isfinite(levels)])
        rows.append({
            "model": model,
            "event_threshold_quantile": float(quantile),
            "metric": metric,
            "arm_span": metric_span,
            "variability_ratio_span": variability_span,
            "span_ratio": ratio,
            "monotone_increasing": bool(np.all(differences > 0)) if differences.size else False,
            "monotone_decreasing": bool(np.all(differences < 0)) if differences.size else False,
            "is_primary_threshold": bool(np.isclose(quantile, primary)),
        })
    return pd.DataFrame(rows)


def decide(verdicts: pd.DataFrame, contract: dict) -> dict:
    shape = verdicts[
        (verdicts["metric"] == "event_peak_concentration") & verdicts["is_primary_threshold"]
    ]
    worst = float(np.nanmax(shape["span_ratio"].to_numpy(dtype=float)))
    if worst <= 0.2:
        verdict = "SHAPE_IS_STRUCTURAL"
    elif worst >= 0.5:
        verdict = "SHAPE_MOVES_WITH_OBJECTIVE"
    else:
        verdict = "INCONCLUSIVE"
    consequence = next(
        rule["consequence"] for rule in contract["decision_rule"]["thresholds"]
        if rule["verdict"] == verdict
    )
    return {
        "max_span_ratio_across_models": worst,
        "verdict": verdict,
        "consequence": consequence,
        "per_model_span_ratio": {
            str(row.model): float(row.span_ratio) for row in shape.itertuples(index=False)
        },
    }


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-basins", type=int, default=531)
    parser.add_argument("--derivation-id", default="analysis_event_shape_20260808")
    return parser


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)
    contract = load_contract()
    series = load_all_series(args.expected_basins)
    event_rows, skipped = collect_event_rows(series, contract)
    per_basin = basin_level(event_rows)
    summary = dose_response_summary(per_basin)
    verdicts = verdict_table(summary, contract)
    decision = decide(verdicts, contract)

    out_dir = OUTPUT_ROOT / args.derivation_id
    out_dir.mkdir(parents=True, exist_ok=True)
    per_basin.to_csv(out_dir / "event_shape_by_basin.csv", index=False)
    summary.to_csv(out_dir / "event_shape_summary.csv", index=False)
    verdicts.to_csv(out_dir / "event_shape_spans.csv", index=False)
    manifest = {
        "experiment_id": contract["experiment_id"],
        "derivation_id": args.derivation_id,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "arm_multipliers": {arm: multiplier for arm, multiplier, _, _ in ARMS},
        "event_counts": {
            f"q{quantile:g}": int(count) for quantile, count in
            event_rows[event_rows["model"] == CONCEPTUAL_MODELS[0]]
            .groupby("event_threshold_quantile").size().items()
        },
        "basins_summarized": int(per_basin["basin_id"].nunique()),
        "skipped": skipped,
        "bootstrap": {"unit": "whole_basin", "resamples": BOOTSTRAP_RESAMPLES, "seed": BOOTSTRAP_SEED},
        "decision": decision,
        "inference_boundary": contract["period"]["rule"],
    }
    (out_dir / "event_shape_manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(decision, indent=2))
    print(f"wrote {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
