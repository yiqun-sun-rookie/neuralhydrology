"""Pure metrics for hydrological process diagnostics.

All event selection is observation-defined. Simulations are used only after
events and flow groups have been fixed.
"""

from __future__ import annotations

import math
from collections.abc import Sequence

import numpy as np
import pandas as pd


def _aligned_finite_arrays(obs: Sequence[float], sim: Sequence[float]) -> tuple[np.ndarray, np.ndarray]:
    obs_array = np.asarray(obs, dtype=float)
    sim_array = np.asarray(sim, dtype=float)
    if obs_array.shape != sim_array.shape or obs_array.ndim != 1 or obs_array.size == 0:
        raise ValueError("obs and sim must be non-empty aligned one-dimensional arrays")
    if not np.isfinite(obs_array).all() or not np.isfinite(sim_array).all():
        raise ValueError("obs and sim must contain only finite values")
    return obs_array, sim_array


def relative_signed_bias(obs: Sequence[float], sim: Sequence[float]) -> float:
    """Return mean(sim - obs) divided by mean(obs)."""
    obs_array, sim_array = _aligned_finite_arrays(obs, sim)
    denominator = float(obs_array.mean())
    return np.nan if denominator == 0.0 else float((sim_array - obs_array).mean() / denominator)


def assign_flow_groups(obs: Sequence[float], *, low_quantile: float = 0.1, high_quantile: float = 0.9) -> np.ndarray:
    """Assign low, middle, and high groups using observed-discharge thresholds."""
    obs_array = np.asarray(obs, dtype=float)
    if obs_array.ndim != 1 or obs_array.size == 0 or not np.isfinite(obs_array).all():
        raise ValueError("obs must be a non-empty finite one-dimensional array")
    if not 0.0 < low_quantile < high_quantile < 1.0:
        raise ValueError("quantiles must satisfy 0 < low_quantile < high_quantile < 1")
    low, high = np.quantile(obs_array, [low_quantile, high_quantile])
    labels = np.full(obs_array.size, "mid", dtype=object)
    labels[obs_array <= low] = "low"
    labels[obs_array >= high] = "high"
    return labels


def flow_duration_curve_bias(
    obs: Sequence[float],
    sim: Sequence[float],
    *,
    upper_tail_fraction: float = 0.1,
) -> float:
    """Return timing-independent signed bias over separately sorted upper tails."""
    obs_array, sim_array = _aligned_finite_arrays(obs, sim)
    if not 0.0 < upper_tail_fraction <= 1.0:
        raise ValueError("upper_tail_fraction must satisfy 0 < fraction <= 1")
    tail_count = max(1, int(math.ceil(obs_array.size * upper_tail_fraction)))
    obs_tail = np.sort(obs_array)[-tail_count:]
    sim_tail = np.sort(sim_array)[-tail_count:]
    return relative_signed_bias(obs_tail, sim_tail)


def standard_deviation_ratio(obs: Sequence[float], sim: Sequence[float]) -> float:
    """Return population standard deviation of simulation divided by observation."""
    obs_array, sim_array = _aligned_finite_arrays(obs, sim)
    denominator = float(np.std(obs_array, ddof=0))
    return np.nan if denominator == 0.0 else float(np.std(sim_array, ddof=0) / denominator)


EVENT_COLUMNS = [
    "event_id",
    "start_date",
    "end_date",
    "peak_date",
    "peak_index",
    "observed_peak",
    "threshold",
    "window_start",
    "window_end",
]


def identify_observed_events(
    dates: Sequence,
    obs: Sequence[float],
    *,
    threshold: float,
    merge_gap_days: int = 2,
    minimum_peak_separation_days: int = 5,
    half_window_days: int = 3,
) -> pd.DataFrame:
    """Identify high-flow events without using any simulated discharge."""
    date_index = pd.DatetimeIndex(pd.to_datetime(dates))
    obs_array = np.asarray(obs, dtype=float)
    if date_index.size != obs_array.size or obs_array.ndim != 1 or obs_array.size == 0:
        raise ValueError("dates and obs must be non-empty aligned one-dimensional arrays")
    if not np.isfinite(obs_array).all() or not np.isfinite(threshold):
        raise ValueError("obs and threshold must be finite")
    parameters = (merge_gap_days, minimum_peak_separation_days, half_window_days)
    if any(not isinstance(value, (int, np.integer)) or value < 0 for value in parameters):
        raise ValueError("event-window parameters must be non-negative integers")
    if date_index.size > 1:
        intervals = np.diff(date_index.values.astype("datetime64[D]")).astype(int)
        if not np.all(intervals == 1):
            raise ValueError("dates must be strictly increasing daily values")

    exceedance_indices = np.flatnonzero(obs_array > threshold)
    if exceedance_indices.size == 0:
        return pd.DataFrame(columns=EVENT_COLUMNS)

    merged_runs: list[tuple[int, int]] = []
    run_start = int(exceedance_indices[0])
    run_end = run_start
    for raw_index in exceedance_indices[1:]:
        index = int(raw_index)
        dry_gap_days = index - run_end - 1
        if dry_gap_days <= merge_gap_days:
            run_end = index
        else:
            merged_runs.append((run_start, run_end))
            run_start = run_end = index
    merged_runs.append((run_start, run_end))

    candidates: list[dict] = []
    for start_index, end_index in merged_runs:
        event_values = obs_array[start_index:end_index + 1]
        peak_index = start_index + int(np.argmax(event_values))
        if peak_index - half_window_days < 0 or peak_index + half_window_days >= obs_array.size:
            continue
        candidates.append({
            "start_index": start_index,
            "end_index": end_index,
            "peak_index": peak_index,
            "observed_peak": float(obs_array[peak_index]),
        })

    retained: list[dict] = []
    ranked_candidates = sorted(candidates, key=lambda row: (-row["observed_peak"], row["peak_index"]))
    for candidate in ranked_candidates:
        separated = all(
            abs(candidate["peak_index"] - existing["peak_index"]) >= minimum_peak_separation_days
            for existing in retained
        )
        if separated:
            retained.append(candidate)

    rows: list[dict] = []
    for event_number, candidate in enumerate(sorted(retained, key=lambda row: row["peak_index"]), start=1):
        peak_index = candidate["peak_index"]
        rows.append({
            "event_id": f"event_{event_number:04d}",
            "start_date": date_index[candidate["start_index"]],
            "end_date": date_index[candidate["end_index"]],
            "peak_date": date_index[peak_index],
            "peak_index": peak_index,
            "observed_peak": candidate["observed_peak"],
            "threshold": float(threshold),
            "window_start": date_index[peak_index - half_window_days],
            "window_end": date_index[peak_index + half_window_days],
        })
    return pd.DataFrame(rows, columns=EVENT_COLUMNS)


EVENT_METRIC_COLUMNS = [
    "event_id",
    "observed_peak_date",
    "simulated_peak_date",
    "observed_peak",
    "simulated_aligned_peak",
    "threshold",
    "same_date_peak_bias",
    "aligned_peak_magnitude_bias",
    "peak_timing_error_days",
    "absolute_peak_timing_error_days",
    "seven_day_volume_bias",
    "hit",
]


def compute_event_metrics(
    dates: Sequence,
    obs: Sequence[float],
    sim: Sequence[float],
    events: pd.DataFrame,
) -> pd.DataFrame:
    """Compute magnitude, timing, and volume diagnostics for fixed observed events."""
    obs_array, sim_array = _aligned_finite_arrays(obs, sim)
    date_index = pd.DatetimeIndex(pd.to_datetime(dates))
    if date_index.size != obs_array.size:
        raise ValueError("dates, obs, and sim must be aligned")
    if date_index.size > 1:
        intervals = np.diff(date_index.values.astype("datetime64[D]")).astype(int)
        if not np.all(intervals == 1):
            raise ValueError("dates must be strictly increasing daily values")
    missing_columns = set(EVENT_COLUMNS).difference(events.columns)
    if missing_columns:
        raise ValueError(f"events are missing required columns: {sorted(missing_columns)}")

    rows: list[dict] = []
    for event in events.itertuples(index=False):
        peak_index = int(event.peak_index)
        if peak_index < 0 or peak_index >= obs_array.size or date_index[peak_index] != pd.Timestamp(event.peak_date):
            raise ValueError("event peak index and date do not match the supplied series")
        start_index = int(date_index.get_loc(pd.Timestamp(event.window_start)))
        end_index = int(date_index.get_loc(pd.Timestamp(event.window_end)))
        if start_index > peak_index or end_index < peak_index:
            raise ValueError("event window must contain the observed peak")

        window_indices = np.arange(start_index, end_index + 1)
        simulated_window = sim_array[window_indices]
        simulated_peak = float(np.max(simulated_window))
        maximum_indices = window_indices[np.flatnonzero(simulated_window == simulated_peak)]
        simulated_peak_index = min(maximum_indices, key=lambda index: (abs(int(index) - peak_index), int(index)))
        simulated_peak_index = int(simulated_peak_index)
        hit = bool(simulated_peak > float(event.threshold))
        if hit:
            timing_error = float(simulated_peak_index - peak_index)
            absolute_timing_error = abs(timing_error)
            simulated_peak_date = date_index[simulated_peak_index]
        else:
            timing_error = np.nan
            absolute_timing_error = np.nan
            simulated_peak_date = pd.NaT

        observed_peak = float(event.observed_peak)
        rows.append({
            "event_id": event.event_id,
            "observed_peak_date": pd.Timestamp(event.peak_date),
            "simulated_peak_date": simulated_peak_date,
            "observed_peak": observed_peak,
            "simulated_aligned_peak": simulated_peak,
            "threshold": float(event.threshold),
            "same_date_peak_bias": float((sim_array[peak_index] - observed_peak) / observed_peak),
            "aligned_peak_magnitude_bias": float((simulated_peak - observed_peak) / observed_peak),
            "peak_timing_error_days": timing_error,
            "absolute_peak_timing_error_days": absolute_timing_error,
            "seven_day_volume_bias": relative_signed_bias(
                obs_array[start_index:end_index + 1], sim_array[start_index:end_index + 1]),
            "hit": hit,
        })
    return pd.DataFrame(rows, columns=EVENT_METRIC_COLUMNS)


def whole_basin_bootstrap_interval(
    rows: pd.DataFrame,
    *,
    value_column: str,
    basin_column: str = "basin_id",
    n_resamples: int = 10_000,
    seed: int = 20260726,
) -> tuple[float, float]:
    """Bootstrap the equal-basin median after reducing each basin to one median."""
    if basin_column not in rows.columns or value_column not in rows.columns:
        raise ValueError("bootstrap columns are missing")
    if n_resamples <= 0:
        raise ValueError("n_resamples must be positive")
    finite = rows.loc[np.isfinite(pd.to_numeric(rows[value_column], errors="coerce")), [basin_column, value_column]]
    if finite.empty:
        return np.nan, np.nan
    basin_values = finite.groupby(basin_column, sort=True)[value_column].median().to_numpy(dtype=float)
    rng = np.random.default_rng(seed)
    bootstrap_statistics = np.empty(n_resamples, dtype=float)
    for start in range(0, n_resamples, 1_000):
        stop = min(start + 1_000, n_resamples)
        sampled_indices = rng.integers(0, basin_values.size, size=(stop - start, basin_values.size))
        bootstrap_statistics[start:stop] = np.median(basin_values[sampled_indices], axis=1)
    lower, upper = np.quantile(bootstrap_statistics, [0.025, 0.975])
    return float(lower), float(upper)


def _add_pooled_regime(rows: pd.DataFrame) -> pd.DataFrame:
    if "regime" not in rows.columns:
        return rows.copy()
    pooled = rows.copy()
    pooled["regime"] = "pooled"
    return pd.concat([rows, pooled], ignore_index=True)


def _summarize_metric_rows(
    rows: pd.DataFrame,
    *,
    value_columns: Sequence[str],
    group_columns: Sequence[str],
    n_resamples: int,
    seed: int,
    include_event_fields: bool,
) -> pd.DataFrame:
    missing = set(group_columns).union(value_columns, {"basin_id"}).difference(rows.columns)
    if missing:
        raise ValueError(f"summary columns are missing: {sorted(missing)}")
    expanded = _add_pooled_regime(rows)
    summary_rows: list[dict] = []
    for group_key, group in expanded.groupby(list(group_columns), dropna=False, sort=True):
        key_values = group_key if isinstance(group_key, tuple) else (group_key, )
        identifiers = dict(zip(group_columns, key_values))
        for metric_index, value_column in enumerate(value_columns):
            values = pd.to_numeric(group[value_column], errors="coerce")
            finite_mask = np.isfinite(values)
            finite_group = group.loc[finite_mask].copy()
            finite_group[value_column] = values.loc[finite_mask].to_numpy(dtype=float)
            finite_values = finite_group[value_column].to_numpy(dtype=float)
            basin_values = finite_group.groupby("basin_id", sort=True)[value_column].median().to_numpy(dtype=float)
            lower, upper = whole_basin_bootstrap_interval(
                finite_group,
                value_column=value_column,
                n_resamples=n_resamples,
                seed=seed + metric_index,
            )
            row = {
                **identifiers,
                "metric": value_column,
                "median": float(np.median(basin_values)) if basin_values.size else np.nan,
                "ci_lower": lower,
                "ci_upper": upper,
                "fraction_below_zero": float(np.mean(basin_values < 0.0)) if basin_values.size else np.nan,
                "basin_count": int(group["basin_id"].nunique()),
            }
            if include_event_fields:
                if "hit" not in group.columns:
                    raise ValueError("event summaries require a hit column")
                row.update({
                    "event_count": int(len(group)),
                    "hit_rate": float(group["hit"].astype(bool).mean()),
                })
            summary_rows.append(row)
    return pd.DataFrame(summary_rows)


def summarize_bias_rows(
    rows: pd.DataFrame,
    *,
    value_columns: Sequence[str],
    group_columns: Sequence[str] = ("regime", "model", "flow_group"),
    n_resamples: int = 10_000,
    seed: int = 20260726,
) -> pd.DataFrame:
    """Summarize basin-level bias metrics for each regime and the pooled sample."""
    return _summarize_metric_rows(
        rows,
        value_columns=value_columns,
        group_columns=group_columns,
        n_resamples=n_resamples,
        seed=seed,
        include_event_fields=False,
    )


def summarize_event_rows(
    rows: pd.DataFrame,
    *,
    value_columns: Sequence[str],
    group_columns: Sequence[str] = ("regime", "season", "model", "event_threshold_quantile"),
    n_resamples: int = 10_000,
    seed: int = 20260726,
) -> pd.DataFrame:
    """Summarize event diagnostics with whole-basin bootstrap intervals."""
    return _summarize_metric_rows(
        rows,
        value_columns=value_columns,
        group_columns=group_columns,
        n_resamples=n_resamples,
        seed=seed,
        include_event_fields=True,
    )


def _bootstrap_median_contrast(
    first: np.ndarray,
    second: np.ndarray,
    *,
    n_resamples: int,
    seed: int,
) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    statistics = np.empty(n_resamples, dtype=float)
    for index in range(n_resamples):
        first_sample = rng.choice(first, size=first.size, replace=True)
        second_sample = rng.choice(second, size=second.size, replace=True)
        statistics[index] = np.median(first_sample) - np.median(second_sample)
    lower, upper = np.quantile(statistics, [0.025, 0.975])
    return float(lower), float(upper)


def evaluate_diagnostic_gates(
    event_rows: pd.DataFrame,
    *,
    volume_bias_tolerance: float = 0.05,
    n_resamples: int = 10_000,
    seed: int = 20260726,
) -> dict:
    """Evaluate predeclared shape and forcing-proxy gates on q90 events."""
    required = {
        "basin_id",
        "regime",
        "season",
        "model",
        "event_threshold_quantile",
        "aligned_peak_magnitude_bias",
        "seven_day_volume_bias",
    }
    missing_columns = required.difference(event_rows.columns)
    if missing_columns:
        raise ValueError(f"gate columns are missing: {sorted(missing_columns)}")
    q90 = event_rows.loc[np.isclose(event_rows["event_threshold_quantile"].astype(float), 0.9)].copy()

    shape_decisions = []
    for model, group in q90.groupby("model", sort=True):
        basin_medians = group.groupby("basin_id", sort=True)[
            ["aligned_peak_magnitude_bias", "seven_day_volume_bias"]].median()
        aligned_median = float(basin_medians["aligned_peak_magnitude_bias"].median())
        volume_median = float(basin_medians["seven_day_volume_bias"].median())
        eligible = bool(aligned_median < 0.0 and abs(volume_median) <= volume_bias_tolerance)
        shape_decisions.append({
            "model": str(model),
            "median_aligned_peak_bias": aligned_median,
            "median_seven_day_volume_bias": volume_median,
            "eligible": eligible,
        })
    eligible_models = sorted(row["model"] for row in shape_decisions if row["eligible"])
    shape_gate = {
        "supported": bool(eligible_models),
        "rule": "pooled q90 median aligned peak bias < 0 and absolute median seven-day volume bias <= tolerance",
        "volume_bias_tolerance": float(volume_bias_tolerance),
        "rows_used": int(len(q90)),
        "eligible_models": eligible_models,
        "numerical_decisions": shape_decisions,
    }
    if not eligible_models:
        shape_gate["reason"] = "No fixed model satisfies the pooled q90 magnitude-volume rule"

    basin_medians = q90.groupby(["basin_id", "regime", "season", "model"], as_index=False)[
        "aligned_peak_magnitude_bias"].median()
    conceptual_models = ["GR4J", "HBV-lite", "Xinanjiang"]
    seasons = ["winter", "spring"]
    contrast_decisions = []
    missing_contrasts = []
    contrast_index = 0
    for season in seasons:
        seasonal = basin_medians.loc[basin_medians["season"] == season]
        neural = seasonal.loc[seasonal["model"] == "LSTM", [
            "basin_id", "regime", "aligned_peak_magnitude_bias"
        ]].rename(columns={"aligned_peak_magnitude_bias": "neural_bias"})
        for conceptual_model in conceptual_models:
            conceptual = seasonal.loc[seasonal["model"] == conceptual_model, [
                "basin_id", "regime", "aligned_peak_magnitude_bias"
            ]].rename(columns={"aligned_peak_magnitude_bias": "conceptual_bias"})
            paired = neural.merge(conceptual, on=["basin_id", "regime"], how="inner", validate="one_to_one")
            paired["conceptual_deficit"] = paired["neural_bias"] - paired["conceptual_bias"]
            snow = paired.loc[paired["regime"] == "snow-dominated", "conceptual_deficit"].to_numpy(dtype=float)
            non_snow = paired.loc[paired["regime"] != "snow-dominated", "conceptual_deficit"].to_numpy(dtype=float)
            if snow.size == 0 or non_snow.size == 0:
                missing_contrasts.append(f"{season}:{conceptual_model}")
                contrast_index += 1
                continue
            contrast = float(np.median(snow) - np.median(non_snow))
            lower, upper = _bootstrap_median_contrast(
                snow,
                non_snow,
                n_resamples=n_resamples,
                seed=seed + contrast_index,
            )
            contrast_decisions.append({
                "season": season,
                "conceptual_model": conceptual_model,
                "snow_basin_count": int(snow.size),
                "non_snow_basin_count": int(non_snow.size),
                "contrast": contrast,
                "ci_lower": lower,
                "ci_upper": upper,
                "passes": bool(lower > 0.0),
            })
            contrast_index += 1

    forcing_supported = not missing_contrasts and len(contrast_decisions) == 6 and all(
        row["passes"] for row in contrast_decisions)
    forcing_gate = {
        "supported": bool(forcing_supported),
        "rule": (
            "all three conceptual models have positive lower 95% interval bounds for fixed "
            "snow-minus-non-snow q90 aligned-peak deficit contrasts in both winter and spring"
        ),
        "rows_used": int(len(q90)),
        "numerical_decisions": contrast_decisions,
    }
    if missing_contrasts:
        forcing_gate["reason"] = f"Missing fixed contrasts: {', '.join(missing_contrasts)}"
    elif not forcing_supported:
        forcing_gate["reason"] = (
            "At least one fixed winter or spring contrast does not have a positive lower interval bound"
        )

    return {
        "run_shape_stage": shape_gate,
        "run_forcing_proxy_stage": forcing_gate,
    }
