"""Derive the amplitude response of the registered E01 loss-intervention arms.

The registered E01 scoring produced flow-group biases, efficiency, and event-peak
concentration per basin, but not the variability ratio or the daily correlation.
Both quantities are required to state how the calibration objective moves model
amplitude while leaving day-to-day correspondence nearly unchanged.

This script recomputes them from the already registered E01 daily predictions.
It trains nothing, calibrates nothing, and writes only into a new directory.
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

from src.loss_mechanism_531.score_flow_regime_loss_experiment import (
    BOOTSTRAP_SEED,
    _load_conceptual_daily,
    load_neural_ensemble,
    whole_basin_median_interval,
)

EXPERIMENT_ID = "E01_flow_regime_balanced_loss_531"
ARMS = ("nse", "flow_regime_nse")
CONCEPTUAL_MODELS = ("gr4j", "xaj", "hbv_lite")
NEURAL_MODEL = "lstm_three_seed_ensemble"
MINIMUM_PAIRED_DAYS = 30


def amplitude_geometry(observations: np.ndarray, simulations: np.ndarray) -> dict:
    """Return the variability ratio and daily correlation for one basin and arm."""
    observed = np.asarray(observations, dtype=np.float64)
    simulated = np.asarray(simulations, dtype=np.float64)
    if observed.shape != simulated.shape or observed.ndim != 1:
        raise ValueError(f"shape mismatch: {observed.shape} against {simulated.shape}")
    valid = np.isfinite(observed) & np.isfinite(simulated)
    if int(valid.sum()) < MINIMUM_PAIRED_DAYS:
        raise ValueError(f"fewer than {MINIMUM_PAIRED_DAYS} paired finite days")
    observed = observed[valid]
    simulated = simulated[valid]
    observed_deviation = float(np.std(observed, ddof=1))
    simulated_deviation = float(np.std(simulated, ddof=1))
    if not np.isfinite(observed_deviation) or observed_deviation <= 0.0:
        raise ValueError("observed standard deviation must be finite and positive")
    if simulated_deviation <= 0.0:
        correlation = float("nan")
    else:
        correlation = float(np.corrcoef(observed, simulated)[0, 1])
    return {
        "variability_ratio": simulated_deviation / observed_deviation,
        "correlation": correlation,
        "variability_ratio_minus_correlation": simulated_deviation / observed_deviation - correlation,
        "paired_day_count": int(valid.sum()),
    }


def _rows_from_mapping(mapping: dict, model: str, arm: str) -> list[dict]:
    rows = []
    for basin_id in sorted(mapping):
        _, observed, simulated = mapping[basin_id]
        geometry = amplitude_geometry(observed, simulated)
        rows.append({"model": model, "arm": arm, "basin_id": basin_id, **geometry})
    return rows


def paired_amplitude_effects(per_basin: pd.DataFrame) -> pd.DataFrame:
    """Compare intervention minus baseline per model using paired basins."""
    metrics = ("variability_ratio", "correlation", "variability_ratio_minus_correlation")
    rows = []
    for model, model_rows in per_basin.groupby("model", sort=True):
        baseline = model_rows[model_rows["arm"] == "nse"].set_index("basin_id")
        intervention = model_rows[model_rows["arm"] == "flow_regime_nse"].set_index("basin_id")
        if set(baseline.index) != set(intervention.index):
            raise ValueError(f"paired basin sets differ for {model}")
        intervention = intervention.loc[baseline.index]
        for offset, metric in enumerate(metrics):
            change = (intervention[metric] - baseline[metric]).to_numpy(dtype=float)
            finite = change[np.isfinite(change)]
            estimate, lower, upper = whole_basin_median_interval(finite, seed=BOOTSTRAP_SEED + offset)
            rows.append({
                "model": model,
                "metric": metric,
                "basin_count": int(finite.size),
                "baseline_median": float(baseline[metric].median()),
                "intervention_median": float(intervention[metric].median()),
                "median_change": estimate,
                "ci_lower": lower,
                "ci_upper": upper,
                "interval_excludes_zero": bool(lower > 0.0 or upper < 0.0),
            })
        distance = {}
        for arm_name, frame in (("nse", baseline), ("flow_regime_nse", intervention)):
            to_optimum = (frame["variability_ratio"] - frame["correlation"]).abs()
            to_unity = (frame["variability_ratio"] - 1.0).abs()
            distance[arm_name] = float((to_optimum < to_unity).mean())
        rows.append({
            "model": model,
            "metric": "fraction_closer_to_correlation_than_unity",
            "basin_count": int(len(baseline)),
            "baseline_median": distance["nse"],
            "intervention_median": distance["flow_regime_nse"],
            "median_change": distance["flow_regime_nse"] - distance["nse"],
            "ci_lower": float("nan"),
            "ci_upper": float("nan"),
            "interval_excludes_zero": False,
        })
    return pd.DataFrame(rows)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--result-root", default=f"results/18_lstm_fair_531/{EXPERIMENT_ID}")
    parser.add_argument("--neural-run-root", default="runs/e01_loss")
    parser.add_argument("--output-name", default="analysis_amplitude_response_20260806")
    parser.add_argument("--expected-basins", type=int, default=531)
    return parser


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)
    result_root = Path(args.result_root)
    output_directory = result_root / args.output_name
    output_directory.mkdir(parents=True, exist_ok=True)

    rows: list[dict] = []
    for arm in ARMS:
        for model in CONCEPTUAL_MODELS:
            directory = result_root / "conceptual" / arm / model / "daily"
            mapping = _load_conceptual_daily(directory)
            if len(mapping) != args.expected_basins:
                raise ValueError(f"{arm}/{model} has {len(mapping)} basins, expected {args.expected_basins}")
            rows.extend(_rows_from_mapping(mapping, model=model, arm=arm))
        prediction_paths = sorted((Path(args.neural_run_root) / arm).glob("*/test/model_epoch030/test_results.p"))
        if not prediction_paths:
            raise ValueError(f"no registered neural predictions found for arm {arm}")
        mapping = load_neural_ensemble(prediction_paths)
        if len(mapping) != args.expected_basins:
            raise ValueError(f"{arm}/{NEURAL_MODEL} has {len(mapping)} basins, expected {args.expected_basins}")
        rows.extend(_rows_from_mapping(mapping, model=NEURAL_MODEL, arm=arm))

    per_basin = pd.DataFrame(rows).sort_values(["model", "arm", "basin_id"]).reset_index(drop=True)
    per_basin_path = output_directory / "amplitude_response_by_basin.csv"
    per_basin.to_csv(per_basin_path, index=False)

    paired = paired_amplitude_effects(per_basin)
    paired_path = output_directory / "amplitude_response_summary.csv"
    paired.to_csv(paired_path, index=False)

    manifest = {
        "experiment_id": EXPERIMENT_ID,
        "derivation_id": args.output_name,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": ("Variability ratio and daily correlation for both registered E01 loss arms, "
                    "recomputed from registered daily predictions without training or calibration."),
        "basin_count": int(per_basin["basin_id"].nunique()),
        "arms": list(ARMS),
        "models": list(CONCEPTUAL_MODELS) + [NEURAL_MODEL],
        "bootstrap": {"unit": "whole_basin", "resamples": 10000, "seed": BOOTSTRAP_SEED},
        "inference_boundary": ("Internal-holdout mechanism comparison, not paper evaluation-period performance; "
                               "the paper evaluation period was not read."),
        "outputs": {
            "per_basin": per_basin_path.as_posix(),
            "summary": paired_path.as_posix(),
        },
    }
    (output_directory / "amplitude_response_manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"wrote {per_basin_path}")
    print(f"wrote {paired_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
