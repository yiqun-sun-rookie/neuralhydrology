"""Build the ID10/ID18 manuscript evidence package.

This script intentionally reads only frozen/result artifacts and writes a paper
package under draft/papers. It does not recalibrate or retrain any model.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Dict, Iterable, List, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import yaml

from src.lstm_fair_531.scripts.evidence_protocols import (
    HISTORICAL_PROTOCOL_ID,
    IDENTICAL_PROTOCOL_ID,
    EvidenceProtocol,
    get_protocol,
    list_protocols,
)

#: The benchmark the manuscript reports. The rebuilt common-protocol benchmark is
#: primary; the published one remains buildable as a documented historical comparison.
PRIMARY_PROTOCOL_ID = IDENTICAL_PROTOCOL_ID

REPO = Path(".")
REPRO = Path("results/10_global_conceptual_model_benchmark/camels_us_531_repro_v01")
SUMMARY = REPRO / "summary"
DIAG = REPRO / "diagnostic"
LSTM_REPORTS = Path("results/18_lstm_fair_531/_reports")

CONCEPTUAL_FILES = {
    "GR4J": SUMMARY / "gr4j_pdd_cma_FINAL_pt_v1_local_full.csv",
    "XAJ": SUMMARY / "xaj_pdd_cma_FINAL_pt_v1_5k3_local_full.csv",
    "HBV": SUMMARY / "hbv_lite_cma_FINAL_pt_v1_warmup_local_full.csv",
}
LSTM_SINGLE_REPORT = LSTM_REPORTS / "compare_iter1_cudalstm_s100.json"
LSTM_SINGLE_METRICS = (
    LSTM_REPORTS.parent / "lstm_cudalstm_maurer_s100_2026_0616_1513_ep30" / "test" / "model_epoch030" /
    "test_metrics.csv"
)
LSTM_ENSEMBLE_REPORT = LSTM_REPORTS / "compare_iter2_cudalstm_8seed_ens.json"
LSTM_ENSEMBLE_METRICS = LSTM_REPORTS / "ensemble_cudalstm_maurer_8seed_per_basin.csv"
REGISTERED_LSTM_CONFIG_ROOT = (
    Path("results/18_lstm_fair_531/R02_identical_basin_nse_531/registered_outputs")
)
REGISTERED_LSTM_SEEDS = tuple(range(100, 801, 100))
SNAPSHOT_POLICY = Path("src/lstm_fair_531/configs/manuscript_snapshot_policy.json")
PDD_FAIRNESS_TEST = Path("test/test_id10_pdd_fairness.py")
REPLAY_AUDIT_REL = Path("audit") / "R01_saved_parameter_replay_current_code"
REPLAY_AUDIT_COMMAND = (
    "python -X utf8 -m src.xaj_global_pilot.scripts.replay_conceptual_saved_params "
    "--out-dir draft/papers/10_18_conceptual_lstm_package/audit/R01_saved_parameter_replay_current_code"
)
DEEP_DIVE_REL = Path("deep_dive")
D01_DEEP_DIVE_REL = DEEP_DIVE_REL / "D01_structure_diagnostic_20260709"
D02_DEEP_DIVE_REL = DEEP_DIVE_REL / "D02_seasonal_residual_20260709"
D03_DEEP_DIVE_REL = DEEP_DIVE_REL / "D03_population_seasonal_residual_20260709"
D04_DEEP_DIVE_REL = DEEP_DIVE_REL / "D04_full_population_seasonal_residual_20260709"
D05_DEEP_DIVE_REL = DEEP_DIVE_REL / "D05_lstm_advantage_decomposition_20260709"
D06_DEEP_DIVE_REL = DEEP_DIVE_REL / "D06_joint_season_flow_advantage_20260709"

D07_INPUT_IDS = {
    "summary": "N12",
    "intervals": "N13",
    "contrasts": "N14",
    "claim_gates": "N15",
    "manifest": "N16",
}
D08_INPUT_IDS = {"summary": "N26", "deltas": "N27", "manifest": "N28"}
D09_INPUT_IDS = {
    "bias_summary": "N29",
    "event_summary": "N30",
    "gates": "N31",
    "manifest": "N32",
    "audit": "N33",
}
D10_INPUT_IDS = {
    "amplitude": "N34",
    "event_shape": "N35",
    "event_shape_pairwise": "N36",
    "neural_members": "N37",
    "forcing": "N38",
    "forcing_quartiles": "N39",
    "hydroclimate": "N40",
    "self_checks": "N41",
    "manifest": "N42",
    "audit": "N43",
}
D11_INPUT_IDS = {
    "components_by_context": "N44",
    "component_summary": "N45",
    "paired_by_context": "N46",
    "paired_summary": "N47",
    "self_checks": "N48",
    "manifest": "N49",
    "audit": "N50",
}
R02_FLOW_ROWS_INPUT_ID = "N51"
E02_INPUT_IDS = {
    "dose_response_summary": "N52",
    "dose_response_monotonicity": "N53",
}
_D07_ROOT = "results/18_lstm_fair_531/D07_context_scale_threshold_robustness_20260726"
_D08_ROOT = "results/18_lstm_fair_531/D08_full_protocol_matrix_stability_20260726"
_D09_ROOT = "results/18_lstm_fair_531/D09_hydrological_process_diagnostics_20260726_attempt2"
_D10_ROOT = "results/18_lstm_fair_531/D10_posthoc_cause_diagnostics_20260726"
_D11_ROOT = "results/18_lstm_fair_531/D11_kge_component_diagnostics_20260727"
FLOW_LABELS = {"low": "Low", "mid": "Middle", "high": "High"}
THRESHOLD_LABELS = {"q05_q95": "5th/95th", "q10_q90": "10th/90th", "q20_q80": "20th/80th"}

STALE_PATTERNS = [
    "xaj_pdd_local_full.csv",
    "0.4458",
    "0.6372",
    "HBV-PT (v7",
    "HBV v7",
    "v7_PT_tight",
    "XAJ-PDD (ours)",
]
ACTIVE_STALE_SCAN_PATHS = [Path("src/lstm_fair_531/scripts/build_manuscript_evidence_package.py")]
SCAN_SUFFIXES = {".md", ".py"}


def _bid(values: pd.Series) -> pd.Series:
    return values.astype(str).str.replace(r"\.0$", "", regex=True).str.zfill(8)


def _load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as fp:
        return json.load(fp)


def _write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


class SnapshotInputError(RuntimeError):
    """Raised when an immutable snapshot input is missing or has changed."""


def load_snapshot_policy(path: Path = SNAPSHOT_POLICY) -> dict:
    """Load the versioned minimal-snapshot policy."""
    return _load_json(path)

def _snapshot_input_count_phrase() -> str:
    inputs = load_snapshot_policy()["external_inputs"]
    historical = sum(item["input_id"].startswith("I") for item in inputs)
    common = sum(item["input_id"].startswith("N") for item in inputs)
    if historical + common != len(inputs):
        raise ValueError("Snapshot input IDs must belong to the historical or common protocol")
    return (
        f"{len(inputs)} external evidence inputs ({historical} historical-protocol and {common} common-protocol)"
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fp:
        for chunk in iter(lambda: fp.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _validated_external_input_paths(policy: dict, repo_root: Path) -> list[tuple[dict, str, Path]]:
    """Return safe, unique archive names and resolved repository-local source paths."""
    root = repo_root.resolve()
    seen = set()
    validated = []
    for item in policy["external_inputs"]:
        raw = item.get("path")
        if not isinstance(raw, str) or not raw or "\\" in raw:
            raise SnapshotInputError(f"Invalid external input path: {raw!r}")
        parts = raw.split("/")
        posix_path = PurePosixPath(raw)
        windows_path = PureWindowsPath(raw)
        if (any(part in {"", ".", ".."} for part in parts) or posix_path.is_absolute() or
                windows_path.is_absolute() or windows_path.drive or windows_path.root or
                posix_path.as_posix() != raw):
            raise SnapshotInputError(f"Invalid external input path: {raw!r}")
        if raw in seen:
            raise SnapshotInputError(f"Duplicate external input path: {raw}")
        seen.add(raw)
        source = (root / Path(*parts)).resolve()
        try:
            source.relative_to(root)
        except ValueError as exc:
            raise SnapshotInputError(f"External input path resolves outside the repository: {raw}") from exc
        validated.append((item, raw, source))
    return validated


def build_external_archive(policy: dict, archive_path: Path, repo_root: Path = REPO) -> None:
    """Create a byte-stable ZIP containing exactly the registered external inputs."""
    validated = _validated_external_input_paths(policy, repo_root)
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive_path, mode="w", compression=zipfile.ZIP_STORED) as archive:
        for _, member_name, source in sorted(validated, key=lambda value: value[1]):
            info = zipfile.ZipInfo(member_name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_STORED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, source.read_bytes())


def validate_external_archive(policy: dict, repo_root: Path = REPO, raise_on_error: bool = True) -> pd.DataFrame:
    """Validate the single immutable archive that transports all external inputs."""
    item = policy["external_archive_bundle"]
    path = repo_root / item["path"]
    actual_bytes = path.stat().st_size if path.is_file() else None
    actual_sha256 = _sha256(path) if path.is_file() and actual_bytes == item["bytes"] else None
    if not path.is_file():
        status = "missing"
    elif actual_bytes != item["bytes"]:
        status = "size_mismatch"
    else:
        status = "ok" if actual_sha256 == item["sha256"] else "sha256_mismatch"
    report = pd.DataFrame([{
        "path": item["path"],
        "status": status,
        "format": item["format"],
        "member_count": item["member_count"],
        "expected_bytes": item["bytes"],
        "actual_bytes": actual_bytes,
        "expected_sha256": item["sha256"],
        "actual_sha256": actual_sha256,
    }])
    if raise_on_error and status != "ok":
        raise SnapshotInputError(f"Immutable external archive bundle failed validation: {item['path']} [{status}]")
    return report


def validate_snapshot_inputs(policy: dict, repo_root: Path = REPO, raise_on_error: bool = True) -> pd.DataFrame:
    """Verify every registered external input against its byte size and SHA-256 digest."""
    rows = []
    for item, _, path in _validated_external_input_paths(policy, repo_root):
        actual_bytes = None
        actual_sha256 = None
        if not path.is_file():
            status = "missing"
        else:
            actual_bytes = path.stat().st_size
            if actual_bytes != item["bytes"]:
                status = "size_mismatch"
            else:
                actual_sha256 = _sha256(path)
                status = "ok" if actual_sha256 == item["sha256"] else "sha256_mismatch"
        rows.append({
            "input_id": item["input_id"],
            "path": item["path"],
            "status": status,
            "expected_bytes": item["bytes"],
            "actual_bytes": actual_bytes,
            "expected_sha256": item["sha256"],
            "actual_sha256": actual_sha256,
            "role": item["role"],
            "source_command": item["source_command"],
            "source_cwd": item.get("source_cwd", "repository_root"),
            "source_artifact": item.get("source_artifact", item["path"]),
            "source_dependencies": item.get("source_dependencies", "registered snapshot inputs"),
        })

    report = pd.DataFrame(rows)
    failures = report[report["status"] != "ok"]
    if raise_on_error and not failures.empty:
        details = "\n".join(f"- {row.path} [{row.status}]" for row in failures.itertuples(index=False))
        raise SnapshotInputError("Immutable manuscript snapshot inputs failed validation:\n" + details)
    return report


def validate_code_inputs(policy: dict, repo_root: Path = REPO, raise_on_error: bool = True) -> pd.DataFrame:
    """Verify version-controlled source files used for code-derived evidence."""
    rows = []
    for item in policy["code_inputs"]:
        path = repo_root / item["path"]
        data = path.read_bytes() if path.is_file() else None
        if data is not None and item["digest_mode"] == "text_lf":
            data = data.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
        actual_bytes = len(data) if data is not None else None
        actual_sha256 = hashlib.sha256(data).hexdigest() if data is not None and actual_bytes == item["bytes"] else None
        if not path.is_file():
            status = "missing"
        elif actual_bytes != item["bytes"]:
            status = "size_mismatch"
        else:
            status = "ok" if actual_sha256 == item["sha256"] else "sha256_mismatch"
        rows.append({
            "input_id": item["input_id"],
            "path": item["path"],
            "status": status,
            "expected_bytes": item["bytes"],
            "actual_bytes": actual_bytes,
            "expected_sha256": item["sha256"],
            "actual_sha256": actual_sha256,
            "digest_mode": item["digest_mode"],
            "role": item["role"],
        })
    report = pd.DataFrame(rows)
    failures = report[report["status"] != "ok"]
    if raise_on_error and not failures.empty:
        details = "\n".join(f"- {row.path} [{row.status}]" for row in failures.itertuples(index=False))
        raise SnapshotInputError("Version-controlled manuscript evidence inputs failed validation:\n" + details)
    return report


def _policy_input(policy: dict, input_id: str) -> dict:
    matches = [
        item for item in policy["external_inputs"] + policy.get("code_inputs", [])
        if item["input_id"] == input_id
    ]
    if len(matches) != 1:
        raise ValueError(f"Expected one snapshot input for {input_id}, found {len(matches)}")
    return matches[0]


def _core_evidence_map(out_dir: Path, tables: Dict[str, pd.DataFrame], policy: dict,
                       protocol: EvidenceProtocol | str | None = None) -> pd.DataFrame:
    resolved = _resolve(protocol)
    command = (
        "python -X utf8 -m src.lstm_fair_531.scripts.build_manuscript_evidence_package "
        f"--protocol {resolved.protocol_id} --verify-snapshot"
    )
    rows = []

    def add(metric_id: str, value, input_ids: List[str], output_file: str, selector: str) -> None:
        inputs = [_policy_input(policy, input_id) for input_id in input_ids]
        rows.append({
            "metric_id": metric_id,
            "value": value,
            "input_ids": ";".join(input_ids),
            "source_files": ";".join(item["path"] for item in inputs),
            "source_sha256": ";".join(item["sha256"] for item in inputs),
            "source_digest_mode": ";".join(item.get("digest_mode", "raw_bytes") for item in inputs),
            "build_command": command,
            "output_file": output_file,
            "output_selector": selector,
            "output_sha256": _sha256(out_dir / output_file),
        })

    def slug(value: str) -> str:
        return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")

    main_inputs = {
        model: list(resolved.input_ids[f"main.{model}"])
        for model in ["GR4J", "XAJ", "HBV", "LSTM_single_s100", "LSTM_ensemble_8seed"]
    }
    main_names = {
        "GR4J": "gr4j",
        "XAJ": "xaj",
        "HBV": "hbv_lite",
        "LSTM_single_s100": "lstm_single_s100",
        "LSTM_ensemble_8seed": "lstm_ensemble_8seed",
    }
    for row in tables["main_benchmark"].itertuples(index=False):
        for column in ["n", "median_nse", "mean_nse", "median_delta_vs_gr4j", "win_rate_vs_gr4j"]:
            value = getattr(row, column)
            if pd.isna(value):
                continue
            input_ids = list(main_inputs[row.model])
            if column in {"median_delta_vs_gr4j", "win_rate_vs_gr4j"} and row.model != "GR4J":
                for reference_id in resolved.input_ids["main.reference"]:
                    if reference_id not in input_ids:
                        input_ids.append(reference_id)
            add(
                f"main.{main_names[row.model]}.{column}",
                value,
                input_ids,
                "tables/main_benchmark.csv",
                f"model={row.model};column={column}",
            )

    for row in tables["paired"].itertuples(index=False):
        comparison = row.comparison.removeprefix("LSTM_ensemble_8seed_vs_").lower()
        for column in [
                "n_common", "opponent_median_nse", "lstm_median_nse", "median_diff", "lstm_win_rate",
                "wilcoxon_p", "ci95_low", "ci95_high"
        ]:
            add(
                f"paired.ensemble_vs_{comparison}.{column}",
                getattr(row, column),
                resolved.input_ids["paired"],
                "tables/paired.csv",
                f"comparison={row.comparison};column={column}",
            )

    for row in tables["oracle"].itertuples(index=False):
        add(
            f"oracle.{row.quantity}",
            row.value,
            resolved.input_ids["oracle"],
            "tables/oracle.csv",
            f"quantity={row.quantity};column=value",
        )

    diagnostic_inputs = {model: resolved.input_ids[f"diagnostic.{model}"] for model in ["GR4J", "XAJ", "HBV"]}
    for row in tables["conceptual_diagnostics"].itertuples(index=False):
        for column in [
                "median_nse", "median_kge", "median_abs_bias", "median_abs_peak_bias",
                "median_abs_lowflow_bias", "median_cal_eval_gap", "n_nse_lt_0"
        ]:
            add(
                f"diagnostic.{slug(row.model)}.{column}",
                getattr(row, column),
                diagnostic_inputs[row.model],
                "tables/conceptual_diagnostics.csv",
                f"model={row.model};column={column}",
            )

    regime_inputs = resolved.input_ids["regime_summary"]
    for row in tables["regime_summary"].itertuples(index=False):
        for column in [
                "n", "GR4J_median_nse", "XAJ_median_nse", "HBV_median_nse",
                "LSTM_ensemble_8seed_median_nse", "median_lstm_minus_best_conceptual",
                "conceptual_beats_lstm_count"
        ]:
            add(
                f"regime.{slug(row.regime)}.{column}",
                getattr(row, column),
                regime_inputs,
                "tables/regime_summary.csv",
                f"regime={row.regime};column={column}",
            )

    parameter_inputs = {
        "GR4J+PDD": ["C01", "C02"],
        "XAJ+PDD": ["C02", "C03", "C05"],
        "HBV-lite": ["C04"],
    }
    for row in tables["parameter_accounting"].itertuples(index=False):
        for column in [
                "nominal_parameters", "effective_active_parameters", "external_snow_parameters_nominal",
                "external_snow_parameters_effective", "intrinsic_snow_parameters"
        ]:
            add(
                f"parameters.{slug(row.model)}.{column}",
                getattr(row, column),
                parameter_inputs[row.model],
                "tables/parameter_accounting.csv",
                f"model={row.model};column={column}",
            )

    context_ids = {
        "snow-dominated / MAM": ("season.snow_spring", resolved.input_ids["season_concentration"]),
        "snow-dominated / high-flow": ("flow.snow_high_flow", resolved.input_ids["flow_concentration"]),
        "snow-dominated / MAM / high-flow": (
            "joint.snow_spring_high_flow", resolved.input_ids["joint_concentration"]
        ),
    }
    for row in tables["lstm_advantage_concentration"].itertuples(index=False):
        prefix, input_ids = context_ids[row.hydrologic_context]
        for column in ["context_share", "positive_best_gap_share", "concentration_ratio", "shared_failure_rate"]:
            add(
                f"{prefix}.{column}",
                getattr(row, column),
                input_ids,
                "tables/lstm_advantage_concentration.csv",
                f"hydrologic_context={row.hydrologic_context};column={column}",
            )

    context_summary_inputs = {
        "season": resolved.input_ids["season_concentration"],
        "flow": resolved.input_ids["flow_concentration"],
        "regime": resolved.input_ids["season_concentration"],
    }
    for row in tables["context_dimension_summary"].itertuples(index=False):
        for column in [
                "n_contexts", "context_share", "positive_best_gap_share",
                "concentration_ratio", "shared_failure_rate"
        ]:
            add(
                f"context_summary.{row.dimension}.{slug(row.context)}.{column}",
                getattr(row, column),
                context_summary_inputs[row.dimension],
                "tables/context_dimension_summary.csv",
                f"dimension={row.dimension};context={row.context};column={column}",
            )

    if "context_scale_threshold_summary" in tables:
        flow_summary = tables["context_scale_threshold_summary"]
        flow_summary = flow_summary[(flow_summary["family"] == "flow") & (flow_summary["scope"] == "all_basins")]
        for row in flow_summary.itertuples(index=False):
            for column in [
                    "absolute_concentration_ratio", "relative_concentration_ratio",
                    "median_absolute_advantage", "median_relative_advantage", "shared_failure_rate"
            ]:
                add(
                    f"scale.{row.threshold_label}.{row.flow_group}.{column}",
                    getattr(row, column), [D07_INPUT_IDS["summary"]],
                    "tables/context_scale_threshold_summary.csv",
                    f"threshold_label={row.threshold_label};family=flow;scope=all_basins;"
                    f"flow_group={row.flow_group};column={column}",
                )

        flow_intervals = tables["context_scale_threshold_intervals"]
        flow_intervals = flow_intervals[(flow_intervals["family"] == "flow") &
                                        (flow_intervals["scope"] == "all_basins")]
        for row in flow_intervals.itertuples(index=False):
            for column in ["estimate", "ci_low", "ci_high"]:
                add(
                    f"scale_interval.{row.threshold_label}.{row.flow_group}.{row.metric}.{column}",
                    getattr(row, column), [D07_INPUT_IDS["intervals"]],
                    "tables/context_scale_threshold_intervals.csv",
                    f"threshold_label={row.threshold_label};family=flow;scope=all_basins;"
                    f"flow_group={row.flow_group};metric={row.metric};column={column}",
                )

        contrasts = tables["context_scale_contrasts"]
        contrasts = contrasts[(contrasts["family"] == "snow_vs_non_snow_by_flow") |
                              ((contrasts["family"] == "snow_high_season_pairwise") &
                               (contrasts["threshold_label"] == "q10_q90"))]
        for row in contrasts.itertuples(index=False):
            for column in ["estimate", "ci_low", "ci_high", "p_holm"]:
                add(
                    f"contrast.{row.threshold_label}.{slug(row.family)}.{slug(row.left)}."
                    f"{slug(row.right)}.{slug(row.flow_group)}.{column}",
                    getattr(row, column), [D07_INPUT_IDS["contrasts"]], "tables/context_scale_contrasts.csv",
                    f"threshold_label={row.threshold_label};family={row.family};left={row.left};right={row.right};"
                    f"flow_group={row.flow_group};column={column}",
                )

        for row in tables["protocol_matrix_stability"].itertuples(index=False):
            for column in [
                    "row_count", "key_sets_equal", "concentration_rank_spearman",
                    "shared_failure_rank_spearman", "concentration_above_one_flips",
                    "median_gap_sign_flips", "fdr_classification_flips", "direction_reversal_count",
                    "top_cell_retained"
            ]:
                value = getattr(row, column)
                if pd.isna(value):
                    continue
                add(
                    f"protocol_stability.{slug(row.family)}.{column}", value, [D08_INPUT_IDS["summary"]],
                    "tables/protocol_matrix_stability.csv", f"family={row.family};column={column}",
                )

    for row in tables["population_evidence"].itertuples(index=False):
        for column in ["n", "spearman_rho", "p_value", "q_value", "quartile_median_difference"]:
            value = getattr(row, column)
            if pd.isna(value):
                continue
            add(
                f"{row.evidence_id}.{column}",
                value,
                [row.input_id],
                "reproducibility/population_evidence.csv",
                f"evidence_id={row.evidence_id};column={column}",
            )

    advantage = _advantage_numbers(out_dir, resolved)
    add(
        "joint.snow_spring_high_flow.n_contexts",
        advantage["snow_mam_high_n_contexts"],
        resolved.input_ids["joint_concentration"],
        "tables/lstm_advantage_concentration.csv",
        "hydrologic_context=snow-dominated / MAM / high-flow;column=n_contexts",
    )
    add(
        "joint.snow_spring_high_flow.shared_failure_count",
        advantage["snow_mam_high_shared_failure_count"],
        resolved.input_ids["joint_concentration"],
        "tables/lstm_advantage_concentration.csv",
        "hydrologic_context=snow-dominated / MAM / high-flow;column=shared_failure_count",
    )
    return pd.DataFrame(rows)


def _write_reproducibility_records(out_dir: Path, policy: dict, input_validation: pd.DataFrame,
                                   tables: Dict[str, pd.DataFrame], code_input_validation: pd.DataFrame,
                                   archive_validation: pd.DataFrame,
                                   protocol: EvidenceProtocol | str | None = None) -> None:
    repro_dir = out_dir / "reproducibility"
    repro_dir.mkdir(parents=True, exist_ok=True)

    inventory = pd.DataFrame(policy["baseline_files"])
    inventory.to_csv(repro_dir / "snapshot_inventory.csv", index=False, lineterminator="\n")
    input_validation.to_csv(repro_dir / "external_inputs.csv", index=False, lineterminator="\n")
    archive_validation.to_csv(repro_dir / "external_archive_bundle.csv", index=False, lineterminator="\n")
    code_input_validation.to_csv(repro_dir / "code_inputs.csv", index=False, lineterminator="\n")
    tables["population_evidence"].to_csv(
        repro_dir / "population_evidence.csv", index=False, lineterminator="\n"
    )
    _core_evidence_map(out_dir, tables, policy, protocol).to_csv(
        repro_dir / "core_evidence_map.csv", index=False, lineterminator="\n"
    )

    output_rows = []
    for relative in policy["top_level_outputs"]:
        path = out_dir / relative
        output_rows.append({"path": relative, "bytes": path.stat().st_size, "sha256": _sha256(path)})
    pd.DataFrame(output_rows).to_csv(
        repro_dir / "top_level_output_hashes.csv", index=False, lineterminator="\n"
    )

    bundle = policy["external_archive_bundle"]
    rebuild = f"""# Minimal manuscript snapshot rebuild

This package has one rebuild entry point, after assembling the committed snapshot in this exact order:

1. Start from a clean repository baseline at the committed snapshot.
2. Read `src/lstm_fair_531/configs/manuscript_snapshot_policy.json` and confirm that all
   {len(policy['proposed_version_control_files'])} paths listed in `proposed_version_control_files` are present in the
   checkout. No separate working-tree overlay is required.
3. Place the single immutable external archive at `{bundle['path']}`. Its registered size is {bundle['bytes']} bytes and
   its SHA-256 digest is `{bundle['sha256']}`.
4. Extract that archive at the repository root:

```powershell
Expand-Archive -LiteralPath "{bundle['path']}" -DestinationPath . -Force
```

5. The archive restores all {len(policy['external_inputs'])} paths listed in `external_inputs`, preserving every relative
   path. Run the sole rebuild command; it validates the archive and every member before reading scientific evidence:

```powershell
python -X utf8 -m src.lstm_fair_531.scripts.build_manuscript_evidence_package --verify-snapshot
```

The command rebuilds the manuscript package and records the 14 top-level output digests in
`reproducibility/top_level_output_hashes.csv`. The committed clean checkout and the registered archive reproduce all
14 top-level outputs directly; archive publication remains outside this local snapshot.
"""
    (repro_dir / "REBUILD.md").write_text(rebuild, encoding="utf-8")


def _to_md_table(df: pd.DataFrame) -> str:
    if df.empty:
        return "| empty |\n|---|"
    safe = df.copy()
    safe = safe.replace({np.nan: ""})
    headers = [str(col) for col in safe.columns]
    rows = []
    for _, row in safe.iterrows():
        rows.append([str(row[col]) for col in safe.columns])

    def escape(value: str) -> str:
        return value.replace("|", "\\|").replace("\n", " ")

    lines = [
        "| " + " | ".join(escape(header) for header in headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(escape(value) for value in row) + " |")
    return "\n".join(lines)


def _write_table(df: pd.DataFrame, csv_path: Path, md_path: Path) -> None:
    df.to_csv(csv_path, index=False)
    md_path.write_text(_to_md_table(df) + "\n", encoding="utf-8")


def _resolve(protocol: EvidenceProtocol | str | None) -> EvidenceProtocol:
    if protocol is None:
        return get_protocol(PRIMARY_PROTOCOL_ID)
    if isinstance(protocol, str):
        return get_protocol(protocol)
    return protocol


def _load_conceptual(protocol: EvidenceProtocol | str | None = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
    resolved = _resolve(protocol)
    long = resolved.conceptual_long()
    wide_cols = [
        long[long["model"] == model].set_index("basin_id")["nse"].rename(model)
        for model in ["GR4J", "XAJ", "HBV"]
    ]
    return long, pd.concat(wide_cols, axis=1)


def _load_all_nse(protocol: EvidenceProtocol | str | None = None) -> pd.DataFrame:
    return _resolve(protocol).per_basin_nse()


def _load_regime(protocol: EvidenceProtocol | str | None = None) -> pd.Series:
    return _resolve(protocol).regime()


def _evidence_paths(protocol: EvidenceProtocol | str | None = None) -> Dict[str, str]:
    """Package-relative locations of the tables that carry this protocol's numbers.

    The manuscript cites its evidence by path. When the reported benchmark changes, those
    citations have to move with it, or a reader following them lands on the other
    protocol's tables.
    """
    return {key: value.as_posix() for key, value in _resolve(protocol).deep_dive.items()}


def _advantage_numbers(out_dir: Path, protocol: EvidenceProtocol | str | None = None) -> dict:
    return _resolve(protocol).advantage_numbers(root=out_dir)


def _advantage_concentration_table(out_dir: Path, protocol: EvidenceProtocol | str | None = None) -> pd.DataFrame:
    adv = _advantage_numbers(out_dir, protocol)
    return pd.DataFrame([
        {
            "context_family": "regime-season",
            "hydrologic_context": "snow-dominated / MAM",
            "context_share": adv["snow_mam_context_share"],
            "positive_best_gap_share": adv["snow_mam_gap_share"],
            "concentration_ratio": adv["snow_mam_ratio"],
            "shared_failure_rate": adv["snow_mam_shared_failure"],
        },
        {
            "context_family": "regime-flow",
            "hydrologic_context": "snow-dominated / high-flow",
            "context_share": adv["snow_high_context_share"],
            "positive_best_gap_share": adv["snow_high_gap_share"],
            "concentration_ratio": adv["snow_high_ratio"],
            "shared_failure_rate": adv["snow_high_shared_failure"],
        },
        {
            "context_family": "regime-season-flow",
            "hydrologic_context": "snow-dominated / MAM / high-flow",
            "context_share": adv["snow_mam_high_context_share"],
            "positive_best_gap_share": adv["snow_mam_high_gap_share"],
            "concentration_ratio": adv["snow_mam_high_ratio"],
            "shared_failure_rate": adv["snow_mam_high_shared_failure"],
            "n_contexts": adv["snow_mam_high_n_contexts"],
            "shared_failure_count": adv["snow_mam_high_shared_failure_count"],
        },
    ])


def _population_support_numbers(out_dir: Path, protocol: EvidenceProtocol | str | None = None) -> dict:
    return _resolve(protocol).population_support_numbers(root=out_dir)


_CONTEXT_REGIMES = ["humid", "semi-humid", "semi-arid/arid", "snow-dominated"]
_CONTEXT_SEASONS = ["DJF", "MAM", "JJA", "SON"]
_CONTEXT_FLOWS = ["low", "mid", "high"]


def _context_evidence_tables(out_dir: Path, protocol: EvidenceProtocol | str | None = None) -> Dict[str, pd.DataFrame]:
    """Load and validate the complete protocol-selected context matrices."""
    resolved = _resolve(protocol)
    specifications = {
        "season": (["regime", "season"], {
            (regime, season) for regime in _CONTEXT_REGIMES for season in _CONTEXT_SEASONS
        }),
        "flow": (["regime", "flow_group"], {
            (regime, flow) for regime in _CONTEXT_REGIMES for flow in _CONTEXT_FLOWS
        }),
        "joint": (["regime", "season", "flow_group"], {
            (regime, season, flow)
            for regime in _CONTEXT_REGIMES
            for season in _CONTEXT_SEASONS
            for flow in _CONTEXT_FLOWS
        }),
    }
    common_columns = {
        "n_contexts", "context_share", "positive_best_gap_share",
        "gap_concentration_ratio", "median_best_conceptual_mae_minus_lstm",
        "shared_failure_rate",
    }
    frames = {}
    for name, (keys, expected_keys) in specifications.items():
        path = out_dir / resolved.deep_dive[name]
        frame = pd.read_csv(path)
        missing_columns = (set(keys) | common_columns) - set(frame.columns)
        if missing_columns:
            raise ValueError(f"{path} is missing context columns: {sorted(missing_columns)}")
        observed_keys = set(frame[keys].itertuples(index=False, name=None))
        if len(frame) != len(expected_keys) or frame.duplicated(keys).any() or observed_keys != expected_keys:
            raise ValueError(
                f"{path} is not the complete {len(expected_keys)}-cell matrix; "
                f"rows={len(frame)}, unique_keys={len(observed_keys)}"
            )
        if not frame["n_contexts"].gt(0).all():
            raise ValueError(f"{path} contains a context with no valid rows")
        if not frame["shared_failure_rate"].between(0, 1).all():
            raise ValueError(f"{path} contains a shared-failure rate outside [0, 1]")
        if not frame["context_share"].gt(0).all():
            raise ValueError(f"{path} contains a non-positive context share")
        for share_column in ["context_share", "positive_best_gap_share"]:
            total = float(frame[share_column].sum())
            if not np.isclose(total, 1.0, rtol=0.0, atol=1e-10):
                raise ValueError(
                    f"{path} has {share_column} sum {total:.16g}; expected one"
                )
        expected_ratios = frame["positive_best_gap_share"] / frame["context_share"]
        if not np.allclose(
                frame["gap_concentration_ratio"], expected_ratios,
                rtol=1e-12, atol=1e-12, equal_nan=False):
            raise ValueError(f"{path} contains a concentration ratio inconsistent with its shares")
        if "any_conceptual_lower_mae_rate" in frame.columns:
            complements = frame["shared_failure_rate"] + frame["any_conceptual_lower_mae_rate"]
            if not np.allclose(complements, 1.0, rtol=0.0, atol=1e-12):
                raise ValueError(f"{path} contains inconsistent shared-failure complements")
        frames[name] = frame
    return frames


def _aggregate_context_dimension(frame: pd.DataFrame, column: str) -> dict:
    summary = {}
    for value, group in frame.groupby(column, sort=False):
        n_contexts = int(group["n_contexts"].sum())
        context_share = float(group["context_share"].sum())
        positive_gap_share = float(group["positive_best_gap_share"].sum())
        summary[str(value)] = {
            "n_contexts": n_contexts,
            "context_share": context_share,
            "positive_best_gap_share": positive_gap_share,
            "concentration_ratio": positive_gap_share / context_share,
            "shared_failure_rate": float(
                np.average(group["shared_failure_rate"], weights=group["n_contexts"])
            ),
        }
    return summary


def _context_heterogeneity_summary(out_dir: Path, protocol: EvidenceProtocol | str | None = None) -> dict:
    """Derive additive manuscript summaries from the complete registered matrices."""
    resolved = _resolve(protocol)
    frames = _context_evidence_tables(out_dir, resolved)
    season = frames["season"]
    flow = frames["flow"]
    joint = frames["joint"]

    snow_high_rows = joint[
        (joint["regime"] == "snow-dominated") & (joint["flow_group"] == "high")
    ].set_index("season")
    snow_high = {
        season_name: {
            "n_contexts": int(row["n_contexts"]),
            "concentration_ratio": float(row["gap_concentration_ratio"]),
            "shared_failure_rate": float(row["shared_failure_rate"]),
            "median_gap": float(row["median_best_conceptual_mae_minus_lstm"]),
        }
        for season_name, row in snow_high_rows.iterrows()
    }

    low_flow = flow[flow["flow_group"] == "low"]
    ratio_only_counterexample = joint[
        (joint["regime"] == "semi-humid") &
        (joint["season"] == "SON") &
        (joint["flow_group"] == "high")
    ].iloc[0]

    static = pd.read_csv(out_dir / resolved.deep_dive["spearman"])
    margin_static = static[static["target"] == "lstm_minus_best_conceptual"].copy()
    if len(margin_static) != 39 or margin_static["feature"].nunique() != 39:
        raise ValueError("The primary basin-margin attribute family is not the registered 39-feature family")
    top_attributes = {}
    for feature in [
            "clim_frac_snow", "topo_gauge_lat", "vege_gvf_diff", "topo_elev_mean",
            "clim_pet_mean", "clim_p_mean"
    ]:
        rows = margin_static[margin_static["feature"] == feature]
        if len(rows) != 1:
            raise ValueError(f"Expected one basin-margin attribute row for {feature}, found {len(rows)}")
        row = rows.iloc[0]
        top_attributes[feature] = {"rho": float(row["spearman_rho"]), "q": float(row["q_value"])}

    seasonal_links = pd.read_csv(out_dir / resolved.deep_dive["seasonal_links"])
    winter_snow = seasonal_links[
        (seasonal_links["context"] == "DJF") &
        (seasonal_links["target"] == "best_conceptual_mae_minus_lstm") &
        (seasonal_links["feature"] == "clim_frac_snow")
    ]
    winter_aridity = seasonal_links[
        (seasonal_links["context"] == "DJF") &
        (seasonal_links["target"] == "best_conceptual_mae_minus_lstm") &
        (seasonal_links["feature"] == "clim_aridity")
    ]
    if len(winter_snow) != 1 or len(winter_aridity) != 1:
        raise ValueError("Expected one winter snow row and one winter aridity row")

    link_features = set(seasonal_links["feature"])
    static_link_features = {feature for feature in link_features if feature.startswith(("clim_", "topo_"))}
    diagnostic_link_features = link_features - static_link_features
    if len(link_features) != 6 or len(static_link_features) != 4 or len(diagnostic_link_features) != 2:
        raise ValueError("The context-link family must contain four static and two model-derived variables")

    return {
        "cell_counts": {"regime_season": len(season), "regime_flow": len(flow), "joint": len(joint)},
        "season": _aggregate_context_dimension(season, "season"),
        "flow": _aggregate_context_dimension(flow, "flow_group"),
        "regime": _aggregate_context_dimension(season, "regime"),
        "snow_high": snow_high,
        "spring_minus_winter_snow_high_ratio": (
            snow_high["MAM"]["concentration_ratio"] - snow_high["DJF"]["concentration_ratio"]
        ),
        "max_low_flow_ratio": float(low_flow["gap_concentration_ratio"].max()),
        "all_low_flow_ratios_below_one": bool(low_flow["gap_concentration_ratio"].lt(1).all()),
        "ratio_only_counterexample": {
            "concentration_ratio": float(ratio_only_counterexample["gap_concentration_ratio"]),
            "median_gap": float(ratio_only_counterexample["median_best_conceptual_mae_minus_lstm"]),
            "shared_failure_rate": float(ratio_only_counterexample["shared_failure_rate"]),
        },
        "static_attribute_count": int(len(margin_static)),
        "static_significant_count": int(margin_static["significant_fdr_05"].astype(bool).sum()),
        "static_attribute_groups": {
            prefix: int(margin_static["feature"].str.startswith(f"{prefix}_").sum())
            for prefix in ["clim", "topo", "soil", "geol", "vege"]
        },
        "top_attributes": top_attributes,
        "winter_snow_rho": float(winter_snow.iloc[0]["spearman_rho"]),
        "winter_snow_q": float(winter_snow.iloc[0]["q_value"]),
        "winter_aridity_rho": float(winter_aridity.iloc[0]["spearman_rho"]),
        "winter_aridity_q": float(winter_aridity.iloc[0]["q_value"]),
        "context_link_static_count": len(static_link_features),
        "context_link_diagnostic_count": len(diagnostic_link_features),
        "flow_context_count": int(flow["n_contexts"].sum()),
        "joint_context_count": int(joint["n_contexts"].sum()),
    }


def _context_dimension_summary_table(out_dir: Path,
                                     protocol: EvidenceProtocol | str | None = None) -> pd.DataFrame:
    """Compact additive main effects derived from the complete registered grids."""
    summary = _context_heterogeneity_summary(out_dir, protocol)
    orders = {
        "season": _CONTEXT_SEASONS,
        "flow": _CONTEXT_FLOWS,
        "regime": _CONTEXT_REGIMES,
    }
    rows = []
    for dimension, contexts in orders.items():
        for context in contexts:

            values = summary[dimension][context]
            rows.append({
                "dimension": dimension,
                "context": context,
                "n_contexts": values["n_contexts"],
                "context_share": values["context_share"],
                "positive_best_gap_share": values["positive_best_gap_share"],
                "concentration_ratio": values["concentration_ratio"],
                "shared_failure_rate": values["shared_failure_rate"],
            })
    return pd.DataFrame(rows)

def _registered_dataframe(policy: dict, input_id: str) -> pd.DataFrame:
    return pd.read_csv(Path(_policy_input(policy, input_id)["path"]))


def _aggregate_day_weighted_flow(frame: pd.DataFrame) -> pd.DataFrame:
    """Row-equal and day-weighted flow-group shares of the positive best-conceptual-minus-LSTM gap.

    The row accounting weights each (basin, flow group) context equally, so it measures the
    per-day error-reduction rate; the day accounting multiplies each row's MAE gap by its
    number of days, so it measures accumulated millimetres of error reduction.
    """
    required = {"basin_id", "flow_group", "conceptual_mae", "lstm_mae", "n_days"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"Day-weighted flow accounting requires columns {sorted(missing)}")
    best = frame.loc[frame.groupby(["basin_id", "flow_group"])["conceptual_mae"].idxmin()].copy()
    positive_gap = (best["conceptual_mae"] - best["lstm_mae"]).clip(lower=0)
    best = best.assign(positive_gap=positive_gap, positive_gap_days=positive_gap * best["n_days"])
    grouped = best.groupby("flow_group").agg(
        n_rows=("basin_id", "size"),
        n_days=("n_days", "sum"),
        positive_gap_sum=("positive_gap", "sum"),
        positive_gap_day_sum=("positive_gap_days", "sum"),
    ).reset_index()
    grouped["row_share"] = grouped["n_rows"] / grouped["n_rows"].sum()
    grouped["day_share"] = grouped["n_days"] / grouped["n_days"].sum()
    grouped["positive_gap_share_rows"] = grouped["positive_gap_sum"] / grouped["positive_gap_sum"].sum()
    grouped["positive_gap_share_days"] = grouped["positive_gap_day_sum"] / grouped["positive_gap_day_sum"].sum()
    grouped["row_concentration_ratio"] = grouped["positive_gap_share_rows"] / grouped["row_share"]
    grouped["day_concentration_ratio"] = grouped["positive_gap_share_days"] / grouped["day_share"]
    order = {"high": 0, "mid": 1, "low": 2}
    return grouped.sort_values("flow_group", key=lambda col: col.map(order)).reset_index(drop=True)


def _day_weighted_flow_table(policy: dict) -> pd.DataFrame:
    return _aggregate_day_weighted_flow(_registered_dataframe(policy, R02_FLOW_ROWS_INPUT_ID))


def _context_robustness_tables(policy: dict,
                               protocol: EvidenceProtocol | str | None = None) -> Dict[str, pd.DataFrame]:
    """Load the bounded post-hoc robustness analyses only for the primary common protocol."""
    resolved = _resolve(protocol)
    if resolved.protocol_id != IDENTICAL_PROTOCOL_ID:
        return {}
    return {
        "context_scale_threshold_summary": _registered_dataframe(policy, D07_INPUT_IDS["summary"]),
        "context_scale_threshold_intervals": _registered_dataframe(policy, D07_INPUT_IDS["intervals"]),
        "context_scale_contrasts": _registered_dataframe(policy, D07_INPUT_IDS["contrasts"]),
        "protocol_matrix_stability": _registered_dataframe(policy, D08_INPUT_IDS["summary"]),
        "protocol_matrix_cell_deltas": _registered_dataframe(policy, D08_INPUT_IDS["deltas"]),
    }


def _hydrological_process_tables(policy: dict,
                                  protocol: EvidenceProtocol | str | None = None) -> Dict[str, pd.DataFrame]:
    """Load the audited mandatory D09 process diagnostics for the common protocol only."""
    resolved = _resolve(protocol)
    if resolved.protocol_id != IDENTICAL_PROTOCOL_ID:
        return {}
    gates = _load_json(Path(_policy_input(policy, D09_INPUT_IDS["gates"])["path"]))
    gate_rows = []
    shape = gates["run_shape_stage"]
    for decision in shape["numerical_decisions"]:
        gate_rows.append({
            "stage": "shape",
            "supported": bool(shape["supported"]),
            "reason": shape.get("reason", ""),
            **decision,
        })
    forcing = gates["run_forcing_proxy_stage"]
    for decision in forcing["numerical_decisions"]:
        gate_rows.append({
            "stage": "forcing_proxy",
            "supported": bool(forcing["supported"]),
            "reason": forcing.get("reason", ""),
            **decision,
        })
    return {
        "hydrological_flow_bias_summary": _registered_dataframe(policy, D09_INPUT_IDS["bias_summary"]),
        "hydrological_event_summary": _registered_dataframe(policy, D09_INPUT_IDS["event_summary"]),
        "hydrological_decision_gates": pd.DataFrame(gate_rows),
    }


def _hydrological_process_numbers(tables: Dict[str, pd.DataFrame]) -> dict:
    """Return direct paper-facing quantities without creating a new selection rule."""
    bias = tables["hydrological_flow_bias_summary"]
    event = tables["hydrological_event_summary"]
    gates = tables["hydrological_decision_gates"]
    models = ["LSTM", "GR4J", "Xinanjiang", "HBV-lite"]

    def bias_value(model: str, flow_group: str, diagnostic: str) -> float:
        selected = bias[(bias["regime"] == "pooled") & (bias["model"] == model) &
                        (bias["flow_group"] == flow_group) & (bias["diagnostic"] == diagnostic)]
        if len(selected) != 1:
            raise ValueError(f"Expected one D09 bias row for {model}/{flow_group}/{diagnostic}")
        return float(selected.iloc[0]["median"])

    def event_value(model: str, season: str, metric: str, column: str = "median") -> float:
        selected = event[(event["regime"] == "pooled") & (event["season"] == season) &
                         (event["model"] == model) & np.isclose(event["event_threshold_quantile"], 0.9) &
                         (event["metric"] == metric)]
        if len(selected) != 1:
            raise ValueError(f"Expected one D09 event row for {model}/{season}/{metric}")
        return float(selected.iloc[0][column])

    shape = gates[gates["stage"] == "shape"].set_index("model")
    forcing = gates[gates["stage"] == "forcing_proxy"].copy()
    return {
        "flow_bias": {
            model: {flow: bias_value(model, flow, "same_date_signed_bias") for flow in ["low", "mid", "high"]}
            for model in models
        },
        "upper_tail_bias": {
            model: bias_value(model, "upper_tail", "flow_duration_curve_bias") for model in models
        },
        "standard_deviation_ratio": {
            model: bias_value(model, "full_period", "standard_deviation_ratio") for model in models
        },
        "q90_aligned_peak_bias": {
            model: float(shape.loc[model, "median_aligned_peak_bias"]) for model in models
        },
        "q90_volume_bias": {
            model: float(shape.loc[model, "median_seven_day_volume_bias"]) for model in models
        },
        "q90_seasonal_aligned_peak_bias": {
            season: {
                model: event_value(model, season, "aligned_peak_magnitude_bias") for model in models
            }
            for season in ["autumn", "winter", "spring", "summer"]
        },
        "q90_seasonal_volume_bias": {
            season: {
                model: event_value(model, season, "seven_day_volume_bias") for model in models
            }
            for season in ["autumn", "winter", "spring", "summer"]
        },
        "q90_seasonal_absolute_timing_days": {
            season: {
                model: event_value(model, season, "absolute_peak_timing_error_days") for model in models
            }
            for season in ["autumn", "winter", "spring", "summer"]
        },
        "shape_gate_supported": bool(shape["supported"].iloc[0]),
        "forcing_gate_supported": bool(forcing["supported"].iloc[0]),
        "forcing_contrasts_passed": int(forcing["passes"].astype(bool).sum()),
        "forcing_contrasts_total": int(len(forcing)),
        "forcing_contrasts": forcing,
    }

def _hydrological_process_manuscript_blocks(tables: Dict[str, pd.DataFrame]) -> Dict[str, str]:
    """Translate the independently audited process diagnostics into bounded paper text."""
    names = ["abstract", "methods", "results", "discussion", "limitations", "conclusions"]
    if "hydrological_flow_bias_summary" not in tables:
        return {name: "" for name in names}

    values = _hydrological_process_numbers(tables)
    models = ["LSTM", "GR4J", "Xinanjiang", "HBV-lite"]

    def sequence(source: str, digits: int = 3) -> str:
        return ", ".join(f"{model} {values[source][model]:.{digits}f}" for model in models)

    seasonal = values["q90_seasonal_aligned_peak_bias"]
    seasonal_volume = values["q90_seasonal_volume_bias"]
    abstract = (
        "The added flow-duration and observed-event diagnostics showed that upper-flow attenuation was "
        "shared by the LSTM and all three conceptual structures, while event alignment did not remove the "
        "peak-magnitude or seven-day-volume deficits. The evidence therefore supports a common benchmark-wide "
        "amplitude-compression pattern plus model-specific differences, not a conceptual-model-only or "
        "snow-process mechanism."
    )
    methods = """

### 2.7 Flow-duration and observed-event diagnostics

To determine whether the high-flow result reflected a conceptual-structure deficit, a shared benchmark-wide pattern, or peak timing alone, we added two fixed diagnostic levels without training another model. Within each basin, same-date signed bias was summarized separately below the observed 10th percentile, between the 10th and 90th percentiles, and above the 90th percentile. We also calculated upper-tail flow-duration-curve bias and the simulated-to-observed standard-deviation ratio over the full evaluation period. The low-flow group is an observed-discharge quantile group and is not interpreted as baseflow.

Observed events were defined independently from each model by exceedance of the basin-specific observed 90th or 95th percentile. Consecutive exceedance days formed one event. For each event and model, diagnostics retained the same-date peak error, the aligned peak magnitude within a plus-or-minus three-day window, the absolute peak timing error, the seven-day volume error, and event detection. The two registered decision rules were fixed before examining these outputs: a timing-or-shape extension required a negative aligned peak bias together with an absolute median seven-day volume bias no greater than 0.05 for at least one model; a snow-forcing proxy extension required positive lower 95% interval bounds for all six fixed conceptual-model contrasts across winter and spring. Only a supported rule could authorize the corresponding conditional analysis.

<!-- Evidence: tables/hydrological_flow_bias_summary.csv; tables/hydrological_event_summary.csv; tables/hydrological_decision_gates.csv; figures/fig7_hydrological_process_diagnostics.png -->
"""
    results = f"""

### 3.8 Shared upper-flow attenuation and event behavior

Pooled median same-date high-flow bias was {values['flow_bias']['LSTM']['high']:.3f} for the LSTM, {values['flow_bias']['GR4J']['high']:.3f} for GR4J, {values['flow_bias']['Xinanjiang']['high']:.3f} for Xinanjiang, and {values['flow_bias']['HBV-lite']['high']:.3f} for HBV-lite. The LSTM, GR4J, Xinanjiang, and HBV-lite all attenuated upper-flow variability: their median simulated-to-observed standard-deviation ratios were {sequence('standard_deviation_ratio')}, all below one, and their upper-tail flow-duration-curve biases were {sequence('upper_tail_bias')}.

Aligned 90th-percentile event peaks remained low after each model was allowed to select its local maximum within plus or minus three days: median relative peak deficits were {sequence('q90_aligned_peak_bias')}. Median seven-day event-volume biases were also negative ({sequence('q90_volume_bias')}). Because every model exceeded the prespecified absolute volume tolerance of 0.05, the timing-or-shape rule was not supported. The deficit therefore cannot be explained as peak displacement alone.

Seasonal 90th-percentile aligned peak deficits were largest in summer for all four models (LSTM {seasonal['summer']['LSTM']:.3f}, GR4J {seasonal['summer']['GR4J']:.3f}, Xinanjiang {seasonal['summer']['Xinanjiang']:.3f}, and HBV-lite {seasonal['summer']['HBV-lite']:.3f}). The LSTM was not uniformly best by season on the raw peak-deficit scale: GR4J had smaller aligned-peak deficits in autumn and winter, while the LSTM had smaller deficits in spring and summer. Those two GR4J seasons coincided with a less negative seven-day event-volume bias (autumn {seasonal_volume['autumn']['GR4J']:.3f} versus {seasonal_volume['autumn']['LSTM']:.3f} for the LSTM; winter {seasonal_volume['winter']['GR4J']:.3f} versus {seasonal_volume['winter']['LSTM']:.3f}), so the raw seasonal comparison mixes event water with event shape; Section 3.9 separates the two. In the fixed snow-minus-non-snow checks, four of the six fixed snow contrasts had positive lower 95% interval bounds; the Xinanjiang contrasts failed that criterion in both winter and spring. The universal snow-specific rule was therefore not supported, and no conditional forcing-proxy experiment was run. Figure 7 summarizes these flow-duration and observed-event diagnostics.

<!-- Evidence: tables/hydrological_flow_bias_summary.csv; tables/hydrological_event_summary.csv; tables/hydrological_decision_gates.csv; tables/kge_component_summary.csv; figures/fig7_hydrological_process_diagnostics.png -->
"""
    discussion = """

### 4.6 Hydrological interpretation of the shared attenuation

The new diagnostics change the structural interpretation. Systematic low upper flows cannot be assigned to conceptual-model structure alone because the regional LSTM shows the same sign in same-date high flow, upper-tail flow-duration curves, variability ratios, aligned event peaks, and event volumes. Peak alignment does not remove the deficit, so peak-timing error alone is insufficient. A common forcing product, the common efficiency-oriented objective, shared observation limitations, and regularization or calibration choices are plausible benchmark-wide contributors, but this experiment does not separate them and therefore does not select one as the cause.

Model-specific differences remain hydrologically useful. The LSTM reduces absolute error most strongly at high flow relative to each conceptual model and has smaller spring event-magnitude deficits, but it does not dominate every season and performs poorly in the semi-arid/arid high-event subset. The defensible conclusion is a shared amplitude-compression problem with additional structure-dependent seasonal and regime heterogeneity. It does not establish a physically correct neural snow representation, and it does not show that every conceptual structure has a snow-specific event deficit.
"""
    limitations = """

The event thresholds describe frequent upper-flow events, not annual maxima, flood-frequency quantiles, or independently labelled snowmelt events. Relative bias is unstable when observed flow or volume is near zero, so low-flow signed bias is reported as a descriptive diagnostic and not as a baseflow skill claim. The forcing-proxy rule failed because two fixed Xinanjiang contrasts crossed zero; this rules out the preregistered universal statement but does not prove that forcing error is absent. The independent audit verifies the calculations against the registered prediction and observation files; it cannot verify that the underlying forcing and observations are free of measurement error.
"""
    conclusions = f"""

The process diagnostics bound the structural claim. All four models compressed upper-flow variability (median standard-deviation ratios {sequence('standard_deviation_ratio')}) and retained negative aligned peak and seven-day volume biases. Thus, the established LSTM advantage is concentrated in hydrological contexts where all models still share an amplitude problem; the LSTM usually reduces that problem rather than eliminating it. Only four of six fixed snow contrasts passed, so the evidence does not support a universal snow-specific conceptual-model deficit or an added forcing-proxy experiment.
"""
    return {
        "abstract": abstract,
        "methods": methods,
        "results": results,
        "discussion": discussion,
        "limitations": limitations,
        "conclusions": conclusions,
    }

def _context_robustness_numbers(tables: Dict[str, pd.DataFrame]) -> dict:
    summary = tables["context_scale_threshold_summary"]
    intervals = tables["context_scale_threshold_intervals"]
    contrasts = tables["context_scale_contrasts"]
    stability = tables["protocol_matrix_stability"].set_index("family")

    def flow_row(threshold: str, flow: str) -> pd.Series:
        selected = summary[(summary["threshold_label"] == threshold) & (summary["family"] == "flow") &
                           (summary["scope"] == "all_basins") & (summary["flow_group"] == flow)]
        if len(selected) != 1:
            raise ValueError(f"Expected one aggregate flow row for {threshold}/{flow}, found {len(selected)}")
        return selected.iloc[0]

    def interval_row(threshold: str, flow: str, metric: str) -> pd.Series:
        selected = intervals[(intervals["threshold_label"] == threshold) & (intervals["family"] == "flow") &
                             (intervals["scope"] == "all_basins") &
                             (intervals["flow_group"] == flow) & (intervals["metric"] == metric)]
        if len(selected) != 1:
            raise ValueError(f"Expected one flow interval for {threshold}/{flow}/{metric}, found {len(selected)}")
        return selected.iloc[0]

    snow = contrasts[contrasts["family"] == "snow_vs_non_snow_by_flow"].copy()
    seasonal = contrasts[(contrasts["family"] == "snow_high_season_pairwise") &
                         (contrasts["threshold_label"] == "q10_q90")].copy()
    return {
        "flow": {
            threshold: {flow: flow_row(threshold, flow) for flow in ["low", "mid", "high"]}
            for threshold in THRESHOLD_LABELS
        },
        "flow_intervals": {
            threshold: {
                flow: {
                    metric: interval_row(threshold, flow, metric)
                    for metric in ["absolute_concentration_ratio", "relative_concentration_ratio"]
                }
                for flow in ["low", "mid", "high"]
            }
            for threshold in THRESHOLD_LABELS
        },
        "snow_contrasts": snow,
        "seasonal_contrasts_q10": seasonal,
        "stability": stability,
    }



def _posthoc_cause_tables(policy: dict,
                          protocol: EvidenceProtocol | str | None = None) -> Dict[str, pd.DataFrame]:
    """Load the independently audited D10 post-hoc cause diagnostics for the common protocol."""
    resolved = _resolve(protocol)
    if resolved.protocol_id != IDENTICAL_PROTOCOL_ID:
        return {}
    return {
        "cause_amplitude_geometry_summary": _registered_dataframe(policy, D10_INPUT_IDS["amplitude"]),
        "cause_event_shape_summary": _registered_dataframe(policy, D10_INPUT_IDS["event_shape"]),
        "cause_event_shape_pairwise_summary": _registered_dataframe(policy, D10_INPUT_IDS["event_shape_pairwise"]),
        "cause_neural_ensemble_shape_summary": _registered_dataframe(policy, D10_INPUT_IDS["neural_members"]),
        "cause_forcing_disagreement_summary": _registered_dataframe(policy, D10_INPUT_IDS["forcing"]),
        "cause_forcing_disagreement_quartiles": _registered_dataframe(policy, D10_INPUT_IDS["forcing_quartiles"]),
        "cause_hydroclimate_associations": _registered_dataframe(policy, D10_INPUT_IDS["hydroclimate"]),
    }


def _kge_component_tables(policy: dict,
                          protocol: EvidenceProtocol | str | None = None) -> Dict[str, pd.DataFrame]:
    """Load the independently audited D11 KGE-component diagnosis."""
    resolved = _resolve(protocol)
    if resolved.protocol_id != IDENTICAL_PROTOCOL_ID:
        return {}
    return {
        "kge_components_by_basin_context": _registered_dataframe(
            policy, D11_INPUT_IDS["components_by_context"]),
        "kge_component_summary": _registered_dataframe(policy, D11_INPUT_IDS["component_summary"]),
        "kge_paired_attribution_by_basin_context": _registered_dataframe(
            policy, D11_INPUT_IDS["paired_by_context"]),
        "kge_paired_attribution_summary": _registered_dataframe(
            policy, D11_INPUT_IDS["paired_summary"]),
    }


def _objective_intervention_tables(policy: dict,
                                   protocol: EvidenceProtocol | str | None = None
                                   ) -> Dict[str, pd.DataFrame]:
    """Load the registered three-arm objective intervention (E01 baseline plus E02 reverse arm)."""
    resolved = _resolve(protocol)
    if resolved.protocol_id != IDENTICAL_PROTOCOL_ID:
        return {}
    return {
        "objective_dose_response_summary": _registered_dataframe(
            policy, E02_INPUT_IDS["dose_response_summary"]),
        "objective_dose_response_monotonicity": _registered_dataframe(
            policy, E02_INPUT_IDS["dose_response_monotonicity"]),
    }


def _kge_component_numbers(tables: Dict[str, pd.DataFrame]) -> dict:
    """Select the fixed, paper-facing D11 quantities."""
    models = ["LSTM", "GR4J", "Xinanjiang", "HBV-lite"]
    comparators = ["GR4J", "Xinanjiang", "HBV-lite"]
    summary = tables["kge_component_summary"]
    attribution = tables["kge_paired_attribution_summary"]

    def component_rows(scope: str, group: str) -> pd.DataFrame:
        selected = summary[(summary["scope"] == scope) & (summary["group"] == group)].set_index("model")
        if set(selected.index) != set(models):
            raise ValueError(f"Expected one KGE-component row per model for {scope}/{group}")
        return selected

    def attribution_rows(scope: str, group: str) -> pd.DataFrame:
        selected = attribution[(attribution["scope"] == scope) &
                               (attribution["group"] == group)].set_index("comparator_model")
        if set(selected.index) != set(comparators):
            raise ValueError(f"Expected one KGE-attribution row per comparator for {scope}/{group}")
        return selected

    full = component_rows("full_period", "all")
    high = component_rows("flow", "high")
    low = component_rows("flow", "low")
    high_attribution = attribution_rows("flow", "high")
    snow_attribution = attribution_rows("snow_group", "snow-dominated")

    def values(frame: pd.DataFrame, column: str) -> dict:
        return {model: float(frame.loc[model, column]) for model in models}

    combined = (
        high_attribution["mean_correlation_attribution_fraction"] +
        high_attribution["mean_variability_attribution_fraction"]
    )
    return {
        "median_kge": values(full, "median_kge"),
        "full_components": {
            "correlation": values(full, "median_correlation"),
            "variability": values(full, "median_variability_ratio"),
            "mean": values(full, "median_mean_ratio"),
        },
        "high_median_kge": values(high, "median_kge"),
        "high_components": {
            "correlation": values(high, "median_correlation"),
            "variability": values(high, "median_variability_ratio"),
            "mean": values(high, "median_mean_ratio"),
        },
        "high_same_day_plus_variability_fraction": {
            model: float(combined.loc[model]) for model in comparators
        },
        "high_mean_fraction": {
            model: float(high_attribution.loc[model, "mean_mean_attribution_fraction"])
            for model in comparators
        },
        "high_attribution": {
            component: {
                model: float(high_attribution.loc[model, f"mean_{component}_attribution_fraction"])
                for model in comparators
            }
            for component in ["correlation", "variability", "mean"]
        },
        "snow_correlation_fraction": {
            model: float(snow_attribution.loc[model, "mean_correlation_attribution_fraction"])
            for model in comparators
        },
        "low_flow_undefined_observation_variability_basins": int(
            low.loc[["LSTM", "GR4J", "HBV-lite"], "undefined_basin_count"].min()
        ),
    }


_OBJECTIVE_MODEL_LABELS = {
    "gr4j": "GR4J",
    "xaj": "Xinanjiang",
    "hbv_lite": "HBV-lite",
    "lstm_three_seed_ensemble": "the LSTM",
}
_OBJECTIVE_MODEL_ORDER = ("lstm_three_seed_ensemble", "gr4j", "xaj", "hbv_lite")


def _objective_intervention_numbers(tables: Dict[str, pd.DataFrame]) -> dict:
    """Extract the three-arm intervention levels, paired changes, and spans."""
    summary = tables["objective_dose_response_summary"]
    monotone = tables["objective_dose_response_monotonicity"]

    def level(model: str, arm: str, metric: str) -> float:
        selected = summary[(summary["model"] == model) & (summary["arm"] == arm) &
                           (summary["metric"] == metric)]
        if len(selected) != 1:
            raise ValueError(f"Expected one objective-arm row for {model}/{arm}/{metric}")
        return float(selected.iloc[0]["arm_median"])

    def change(model: str, arm: str, metric: str) -> tuple:
        selected = summary[(summary["model"] == model) & (summary["arm"] == arm) &
                           (summary["metric"] == metric)]
        row = selected.iloc[0]
        return (float(row["median_change_from_baseline"]), float(row["ci_lower"]),
                float(row["ci_upper"]), bool(row["interval_excludes_zero"]))

    def span(model: str, metric: str) -> float:
        selected = monotone[(monotone["model"] == model) & (monotone["metric"] == metric)]
        return float(selected.iloc[0]["span"])

    variability_spans = {model: span(model, "variability_ratio") for model in _OBJECTIVE_MODEL_ORDER}
    correlation_spans = {model: span(model, "correlation") for model in _OBJECTIVE_MODEL_ORDER}
    monotone_flags = {
        model: bool(monotone[(monotone["model"] == model) &
                             (monotone["metric"] == "variability_ratio")].iloc[0]["monotone_increasing"])
        for model in _OBJECTIVE_MODEL_ORDER
    }
    ratios = {model: variability_spans[model] / correlation_spans[model] for model in _OBJECTIVE_MODEL_ORDER}
    return {
        "levels": {
            model: {arm: level(model, arm, "variability_ratio")
                    for arm in ("tail_downweighted_nse", "nse", "flow_regime_nse")}
            for model in _OBJECTIVE_MODEL_ORDER
        },
        "changes": {
            model: {arm: change(model, arm, "variability_ratio")
                    for arm in ("tail_downweighted_nse", "flow_regime_nse")}
            for model in _OBJECTIVE_MODEL_ORDER
        },
        "variability_spans": variability_spans,
        "correlation_spans": correlation_spans,
        "span_ratios": ratios,
        "monotone_flags": monotone_flags,
        "all_monotone": all(monotone_flags.values()),
        "all_intervals_exclude_zero": all(
            change(model, arm, "variability_ratio")[3]
            for model in _OBJECTIVE_MODEL_ORDER
            for arm in ("tail_downweighted_nse", "flow_regime_nse")),
        "minimum_span_ratio": min(ratios.values()),
        "maximum_span_ratio": max(ratios.values()),
    }


def _objective_intervention_manuscript_blocks(tables: Dict[str, pd.DataFrame]) -> Dict[str, str]:
    """State what changing only the calibration objective does to amplitude and to correspondence."""
    names = ["methods", "results", "discussion", "limitations"]
    if "objective_dose_response_summary" not in tables:
        return {name: "" for name in names}
    values = _objective_intervention_numbers(tables)
    levels = values["levels"]
    changes = values["changes"]

    def level_sequence(model: str) -> str:
        row = levels[model]
        return (f"{row['tail_downweighted_nse']:.3f}, {row['nse']:.3f}, and "
                f"{row['flow_regime_nse']:.3f}")

    def change_clause(model: str, arm: str) -> str:
        estimate, lower, upper, _ = changes[model][arm]
        return f"{estimate:+.3f} ({lower:+.3f} to {upper:+.3f})"

    level_lines = "; ".join(
        f"{_OBJECTIVE_MODEL_LABELS[model]} {level_sequence(model)}" for model in _OBJECTIVE_MODEL_ORDER)
    down_lines = ", ".join(
        f"{_OBJECTIVE_MODEL_LABELS[model]} {change_clause(model, 'tail_downweighted_nse')}"
        for model in _OBJECTIVE_MODEL_ORDER)
    up_lines = ", ".join(
        f"{_OBJECTIVE_MODEL_LABELS[model]} {change_clause(model, 'flow_regime_nse')}"
        for model in _OBJECTIVE_MODEL_ORDER)
    span_lines = ", ".join(
        f"{_OBJECTIVE_MODEL_LABELS[model]} {values['variability_spans'][model]:.3f} against "
        f"{values['correlation_spans'][model]:.3f}" for model in _OBJECTIVE_MODEL_ORDER)

    return {
        "methods": """

### 2.11 Calibration-objective intervention

Sections 3.8 and 3.9 report that amplitude compression is shared by all four models whereas
event shape separates them. Those are properties of saved predictions and cannot say whether the
shared component follows from the objective the models were fitted with. We therefore refitted
every model under two further objectives while holding the structures, the forcing, the basin
set, and the optimization budget fixed.

The three objectives lie on one axis: the weight given to each ten-percent flow tail as a
multiple of its realized share of optimization days, with middle flow absorbing the remainder.
A multiplier of one reproduces plain one-minus-Nash-Sutcliffe efficiency exactly. The registered
equal-regime arm fixes each regime at one third, near 3.34 on this axis. The third arm uses 0.3,
the reciprocal of that value, so the two interventions sit at equal multiplicative distance
either side of the baseline. Its predicted direction and its falsifier were registered before it
was run.

Conceptual models were recalibrated with the same optimizer, budget, restarts, and bounds; the
LSTM was retrained with the same three seeds, architecture, and schedule. Fitting and evaluation
used an internal holdout period that is disjoint from the paper evaluation period, so these
numbers are a mechanism test and are not comparable with the benchmark scores reported above.
""",
        "results": f"""

### 3.11 Response to the calibration objective

Moving along the objective axis moved the amplitude of every model in the same direction. Median
simulated-to-observed standard-deviation ratios at multipliers 0.3, 1, and 3.34 were: {level_lines}.
The ratio increased monotonically with tail emphasis for {'all four models' if values['all_monotone'] else 'some models'}.

Against the plain one-minus-Nash-Sutcliffe baseline, de-emphasising the tails lowered the ratio by
{down_lines}, and the registered equal-regime arm raised it by {up_lines}. {'Every one of these eight paired intervals excluded zero.' if values['all_intervals_exclude_zero'] else 'Not every paired interval excluded zero.'}

Daily correlation did not follow. Across the same three objectives the span of the median
standard-deviation ratio against the span of the median daily correlation was: {span_lines}. The
amplitude span therefore exceeded the correlation span by a factor of {values['minimum_span_ratio']:.1f} to {values['maximum_span_ratio']:.1f}.
Correlation was not estimated with paired intervals here, so it is reported only as the much
smaller movement that accompanied a large amplitude movement.

<!-- Evidence: tables/objective_dose_response_summary.csv; tables/objective_dose_response_monotonicity.csv -->
""",
        "discussion": f"""

The intervention ranks the diagnostics by how far the objective moves them. Amplitude moved
by {min(values['variability_spans'].values()):.3f} to {max(values['variability_spans'].values()):.3f} across the three objectives while no structure was altered, so the shared
compression reported in Section 3.9 is not evidence of a structural limitation common to
conceptual models and the LSTM. Daily correlation moved by at most {max(values['correlation_spans'].values()):.3f} under the same
change, and it is correlation, not amplitude, that separates the four models.

This does not make compression an artefact to be removed. Under a squared-error objective a
compressed amplitude is the fitted response, and the arm that raised amplitude also lowered
efficiency, which is why the registered decision on that arm was negative. The practical reading
is that reporting an amplitude or peak-magnitude statistic without stating the fitting objective
leaves the statistic partly determined by a modelling choice rather than by model capability.

The LSTM moved least of the four ({values['variability_spans']['lstm_three_seed_ensemble']:.3f} against {min(values['variability_spans'][m] for m in ('gr4j', 'xaj', 'hbv_lite')):.3f} to {max(values['variability_spans'][m] for m in ('gr4j', 'xaj', 'hbv_lite')):.3f} for the conceptual
models). Regional training with static attributes and the three-seed ensemble average are both
plausible reasons, and this design cannot separate them; the smaller response is reported as an
open observation rather than an explained one.
""",
        "limitations": """

The objective intervention has four boundaries. It used an internal holdout period rather than
the paper evaluation period, so its levels are not comparable with the benchmark scores. Its
neural arm used three seeds where the benchmark uses eight, and it combined seeds by the median
where the benchmark uses the mean. It varied one family of weighted squared-error objectives, so
it does not establish behaviour under objectives of a different form. Finally, the registered
equal-regime arm remained a negative result on its own preregistered criterion, because low-flow
bias did not improve; the direction of the amplitude response is what this study draws on.
""",
    }


def _kge_component_manuscript_blocks(tables: Dict[str, pd.DataFrame]) -> Dict[str, str]:
    """Translate D11 into a compact bounded mechanism diagnosis."""
    names = ["methods", "results", "discussion", "limitations", "conclusion"]
    if "kge_component_summary" not in tables:
        return {name: "" for name in names}
    values = _kge_component_numbers(tables)
    full = values["median_kge"]
    high = values["high_median_kge"]
    fractions = values["high_same_day_plus_variability_fraction"]
    fraction_min = 100 * min(fractions.values())
    fraction_max = 100 * max(fractions.values())
    mean_min = 100 * min(values["high_mean_fraction"].values())
    mean_max = 100 * max(values["high_mean_fraction"].values())

    return {
        "methods": """

We additionally decomposed the 2009 Kling–Gupta efficiency (Gupta et al., 2009) into daily
correlation, the simulated-to-observed standard-deviation ratio, and the
simulated-to-observed mean-flow ratio. The analysis covered the full evaluation
period, four seasons, observation-defined flow groups, the highest 5% flow
sensitivity, and snow-dominated versus other basins. For each LSTM-versus-conceptual
comparison, all six component-replacement orders were averaged so that the three
arithmetic terms closed exactly to the paired efficiency difference. This is a
component-space decomposition of saved predictions, not a causal intervention.
""",
        "results": f"""

### 3.10 Kling–Gupta efficiency component diagnosis

The LSTM median Kling–Gupta efficiency was {full['LSTM']:.3f} over the full
evaluation period, compared with {full['GR4J']:.3f} for GR4J,
{full['Xinanjiang']:.3f} for Xinanjiang, and {full['HBV-lite']:.3f} for HBV-lite.
No single component explained the full-period advantage across all three
comparisons. On the highest 10% observed-flow days, the corresponding medians were
{high['LSTM']:.3f}, {high['GR4J']:.3f}, {high['Xinanjiang']:.3f}, and
{high['HBV-lite']:.3f}. Across the three paired comparisons, stronger daily correlation and less variability compression together represented
{fraction_min:.1f}% to {fraction_max:.1f}% of the mean efficiency advantage; the
mean-flow-ratio term represented only {mean_min:.1f}% to {mean_max:.1f}% (Figure 9).
""",
        "discussion": """

The high-flow result connects the earlier error-concentration finding to a
hydrologically readable signature: the LSTM more closely followed same-day flow
variation and retained more of the observed high-flow variability. The six-order
arithmetic attribution does not show that the network learned correct event timing,
snowmelt physics, or any other causal mechanism. This arithmetic attribution is
descriptive rather than causal.
""",
        "limitations": f"""

The 2009 Kling–Gupta decomposition was numerically unstable for the lowest 10%
flow group: {values['low_flow_undefined_observation_variability_basins']} basins
had zero observed variability, and near-zero means and standard deviations made
the remaining ratio terms unbounded. Low-flow mechanisms are therefore not
interpreted from this decomposition. Component values for selected dates also do
not describe complete event dynamics or physical water balance.
""",
        "conclusion": """

Across the highest-flow days, 84.7% to 90.1% of the LSTM's mean Kling–Gupta
efficiency advantage was arithmetically associated with stronger daily
correlation and less variability compression, while all four models retained high-flow variability and mean-flow ratios below one.
""",
    }


def _posthoc_cause_numbers(tables: Dict[str, pd.DataFrame]) -> dict:
    """Select the fixed, paper-facing D10 quantities without outcome-based filtering."""
    models = ["LSTM", "GR4J", "Xinanjiang", "HBV-lite"]
    amplitude = tables["cause_amplitude_geometry_summary"].set_index("model")
    shape = tables["cause_event_shape_summary"]
    pairwise = tables["cause_event_shape_pairwise_summary"]
    forcing = tables["cause_forcing_disagreement_summary"]
    quartiles = tables["cause_forcing_disagreement_quartiles"]
    hydroclimate = tables["cause_hydroclimate_associations"]

    def amplitude_values(column: str) -> dict:
        return {model: float(amplitude.loc[model, column]) for model in models}

    def shape_values(quantile: float) -> dict:
        selected = shape[(shape["scope"] == "overall") & np.isclose(shape["event_threshold_quantile"], quantile)]
        indexed = selected.set_index("model")
        if set(indexed.index) != set(models):
            raise ValueError(f"Expected one overall event-shape row per model at q={quantile}")
        return {model: float(indexed.loc[model, "median_peak_concentration"]) for model in models}

    def season_shape_values(quantile: float, season: str) -> dict:
        selected = shape[(shape["scope"] == "season") & (shape["group"] == season) &
                         np.isclose(shape["event_threshold_quantile"], quantile)]
        indexed = selected.set_index("model")
        if set(indexed.index) != set(models):
            raise ValueError(f"Expected one seasonal event-shape row per model at q={quantile}, season={season}")
        return {
            model: {
                "median": float(indexed.loc[model, "median_peak_concentration"]),
                "ci_lower": float(indexed.loc[model, "ci_lower"]),
                "ci_upper": float(indexed.loc[model, "ci_upper"]),
            }
            for model in models
        }

    def pairwise_values(quantile: float, column: str) -> dict:
        selected = pairwise[(pairwise["reference_model"] == "LSTM") &
                            np.isclose(pairwise["event_threshold_quantile"], quantile)].set_index("comparator_model")
        return {model: float(selected.loc[model, column]) for model in ["GR4J", "Xinanjiang", "HBV-lite"]}

    def forcing_row(quantile: float) -> pd.Series:
        selected = forcing[(forcing["forcing_window_days"] == 7) &
                           (forcing["forcing_gap_type"] == "consensus") &
                           np.isclose(forcing["event_threshold_quantile"], quantile) &
                           (forcing["scope"] == "overall") & (forcing["group"] == "all")]
        if len(selected) != 1:
            raise ValueError(f"Expected one overall seven-day consensus forcing row at q={quantile}")
        return selected.iloc[0]

    def forcing_quartile_values(quantile: float) -> dict:
        selected = quartiles[(quartiles["forcing_window_days"] == 7) &
                             (quartiles["forcing_gap_type"] == "consensus") &
                             np.isclose(quartiles["event_threshold_quantile"], quantile) &
                             (quartiles["scope"] == "overall") & (quartiles["group"] == "all")]
        return {
            int(row["forcing_gap_quartile"]): float(row["centered_common_volume_bias"])
            for _, row in selected.iterrows()
        }

    def hydroclimate_rho(target: str, attribute: str) -> float:
        selected = hydroclimate[(hydroclimate["target"] == target) &
                                (hydroclimate["attribute"] == attribute)]
        if len(selected) != 1:
            raise ValueError(f"Expected one hydroclimate row for {target}/{attribute}")
        return float(selected.iloc[0]["spearman_rho"])

    q90_forcing = forcing_row(0.90)
    q95_forcing = forcing_row(0.95)
    return {
        "correlation": amplitude_values("median_correlation"),
        "standard_deviation_ratio": amplitude_values("median_standard_deviation_ratio"),
        "standard_deviation_ratio_minus_correlation": amplitude_values(
            "median_standard_deviation_ratio_minus_correlation"),
        "original_high_flow_bias": amplitude_values("median_original_high_flow_bias"),
        "oracle_high_flow_bias": amplitude_values("median_oracle_high_flow_bias"),
        "oracle_negative_fraction": amplitude_values("median_oracle_negative_fraction"),
        "q90_peak_concentration": shape_values(0.90),
        "q95_peak_concentration": shape_values(0.95),
        "q90_seasonal_peak_concentration": {
            season: season_shape_values(0.90, season) for season in ["autumn", "winter", "spring", "summer"]
        },
        "q90_lstm_minus_shape": pairwise_values(0.90, "median_reference_minus_comparator"),
        "q95_lstm_minus_shape": pairwise_values(0.95, "median_reference_minus_comparator"),
        "q90_lstm_higher_fraction": pairwise_values(0.90, "reference_higher_fraction"),
        "q95_lstm_higher_fraction": pairwise_values(0.95, "reference_higher_fraction"),
        "q90_forcing_within_event_rho": float(q90_forcing["within_event_spearman_rho"]),
        "q90_forcing_median_basin_rho": float(q90_forcing["median_basin_spearman_rho"]),
        "q90_forcing_positive_basins": int(q90_forcing["positive_basin_count"]),
        "q95_forcing_within_event_rho": float(q95_forcing["within_event_spearman_rho"]),
        "q90_forcing_median_basin_ci": (float(q90_forcing["median_basin_rho_ci_lower"]),
                                         float(q90_forcing["median_basin_rho_ci_upper"])),
        "q95_forcing_median_basin_rho": float(q95_forcing["median_basin_spearman_rho"]),
        "q95_forcing_positive_basins": int(q95_forcing["positive_basin_count"]),
        "q90_forcing_quartile_bias": forcing_quartile_values(0.90),
        "q95_forcing_quartile_bias": forcing_quartile_values(0.95),
        "q95_forcing_median_basin_ci": (float(q95_forcing["median_basin_rho_ci_lower"]),
                                         float(q95_forcing["median_basin_rho_ci_upper"])),
        "hydroclimate_rho": {
            target: {
                attribute: hydroclimate_rho(target, attribute)
                for attribute in ["p_seasonality", "aridity", "frac_snow", "p_mean"]
            }
            for target in ["standard_deviation_ratio", "original_high_flow_bias"]
        },
    }


def _posthoc_cause_manuscript_blocks(tables: Dict[str, pd.DataFrame]) -> Dict[str, str]:
    """Translate D10 into one bounded hydrological explanation, without causal attribution."""
    names = ["abstract", "methods", "results", "discussion", "limitations", "conclusions"]
    if "cause_amplitude_geometry_summary" not in tables:
        return {name: "" for name in names}
    values = _posthoc_cause_numbers(tables)
    models = ["LSTM", "GR4J", "Xinanjiang", "HBV-lite"]

    def sequence(source: str) -> str:
        return ", ".join(f"{model} {values[source][model]:.3f}" for model in models)

    methods = """

### 2.8 Post-hoc separation of amplitude, event shape, and precipitation-input disagreement

After both registered conditional branches in the preceding process diagnostic had failed, we conducted a separate, explicitly post-hoc diagnosis without training or recalibrating a model. First, daily amplitude geometry was summarized in each basin by the simulated-to-observed standard-deviation ratio and the daily correlation. An evaluation-period affine moment match then aligned each simulation's mean and standard deviation to the observations. This transformation used observed evaluation data and was therefore an oracle diagnostic, not a deployable correction; the fraction of transformed negative flows was retained as a failure check.

Second, event-peak concentration separated peak attenuation from total event-volume attenuation. For each observation-defined event, concentration was the simulated-to-observed aligned-peak ratio divided by the simulated-to-observed seven-day-volume ratio, equivalently `(1 + aligned peak relative bias) / (1 + seven-day volume relative bias)`. Values below one indicate that the simulated peak was attenuated more strongly than its event volume. Events were summarized within basin before calculating population medians, and the 90th-percentile definition was primary while the 95th-percentile definition was a fixed sensitivity analysis. The eight individual neural initializations were also retained to distinguish an ensemble effect from a repeatable neural-model pattern.

Third, Maurer event-window precipitation was compared with Daymet (Thornton et al., 1997) and North American Land Data Assimilation System (Xia et al., 2012) precipitation without rerunning any rainfall-runoff model. Each observation-defined event appeared once after taking the median seven-day volume bias across the four models. Log precipitation gaps and common volume errors were centred within basin before rank correlation, and uncertainty resampled whole basins 10,000 times. The comparison tests whether independent precipitation-product disagreement covaries with the error shared by all four models; it cannot identify precipitation truth or assign causal shares.

<!-- Evidence: tables/cause_amplitude_geometry_summary.csv; tables/cause_event_shape_summary.csv; tables/cause_event_shape_pairwise_summary.csv; tables/cause_forcing_disagreement_summary.csv; figures/fig8_posthoc_cause_diagnostics.png -->
"""
    results = f"""

### 3.9 Separating the common amplitude problem from model-specific event-shape differences

The common component was amplitude compression: median simulated-to-observed standard-deviation ratios were {sequence('standard_deviation_ratio')}, whereas daily correlations were {sequence('correlation')}. Affine moment matching reduced median high-flow bias from {sequence('original_high_flow_bias')} to {sequence('oracle_high_flow_bias')}. It did not provide a physical or deployable correction: the transformed negative-flow fraction was {sequence('oracle_negative_fraction')}, including more than 0.12 for every conceptual model.

Event shape then separated the models. For observed 90th-percentile events, median event-peak concentration was {values['q90_peak_concentration']['LSTM']:.3f} for the LSTM, {values['q90_peak_concentration']['GR4J']:.3f} for GR4J, {values['q90_peak_concentration']['Xinanjiang']:.3f} for Xinanjiang, and {values['q90_peak_concentration']['HBV-lite']:.3f} for HBV-lite. The paired basin-median LSTM advantage in concentration was {values['q90_lstm_minus_shape']['GR4J']:.3f} over GR4J, {values['q90_lstm_minus_shape']['Xinanjiang']:.3f} over Xinanjiang, and {values['q90_lstm_minus_shape']['HBV-lite']:.3f} over HBV-lite. The 95th-percentile sensitivity retained the ordering ({sequence('q95_peak_concentration')}). Thus, all four models shared low amplitude, but Xinanjiang and HBV-lite additionally attenuated aligned event peaks relative to seven-day event volume more strongly than the LSTM; GR4J was much closer to the LSTM. Event-peak concentration is defined in Section 2 as the aligned-peak ratio divided by the seven-day-volume ratio; it summarizes event shape and does not identify routing, storage, or any internal event-redistribution mechanism.

The same separation resolves the seasonal exception reported in Section 3.8. In the two seasons in which GR4J had the smaller raw aligned-peak deficit, the LSTM had the higher event-peak concentration: autumn {values['q90_seasonal_peak_concentration']['autumn']['LSTM']['median']:.3f} (95% interval {values['q90_seasonal_peak_concentration']['autumn']['LSTM']['ci_lower']:.3f} to {values['q90_seasonal_peak_concentration']['autumn']['LSTM']['ci_upper']:.3f}) against {values['q90_seasonal_peak_concentration']['autumn']['GR4J']['median']:.3f} ({values['q90_seasonal_peak_concentration']['autumn']['GR4J']['ci_lower']:.3f} to {values['q90_seasonal_peak_concentration']['autumn']['GR4J']['ci_upper']:.3f}) for GR4J, and winter {values['q90_seasonal_peak_concentration']['winter']['LSTM']['median']:.3f} against {values['q90_seasonal_peak_concentration']['winter']['GR4J']['median']:.3f}. Once event volume is divided out, the seasonal reversal does not persist: the LSTM was not below GR4J in any season. The smaller GR4J peak deficit in autumn and winter therefore reflects more event water rather than a sharper event shape, and raw peak-deficit comparisons between models with different volume biases should not be read as event-shape skill.

The three-product precipitation disagreement tracked the four-model common event error. For 90th-percentile events, the event-weighted, within-basin-centred rank correlation between the Maurer-minus-consensus seven-day precipitation gap and common volume bias was {values['q90_forcing_within_event_rho']:.3f}; the equal-basin median within-basin correlation was {values['q90_forcing_median_basin_rho']:.3f} (95% whole-basin bootstrap interval {values['q90_forcing_median_basin_ci'][0]:.3f} to {values['q90_forcing_median_basin_ci'][1]:.3f}), and {values['q90_forcing_positive_basins']} of 531 basins were positive. The fixed 95th-percentile sensitivity gave an event-weighted correlation of {values['q95_forcing_within_event_rho']:.3f}, an equal-basin median of {values['q95_forcing_median_basin_rho']:.3f} ({values['q95_forcing_median_basin_ci'][0]:.3f} to {values['q95_forcing_median_basin_ci'][1]:.3f}), and {values['q95_forcing_positive_basins']} positive basins. Across the four centred precipitation-gap quartiles, 90th-percentile common volume bias moved from {values['q90_forcing_quartile_bias'][1]:.3f} to {values['q90_forcing_quartile_bias'][4]:.3f}. This weak association is consistent with precipitation-input disagreement contributing to a shared benchmark error, but it does not identify which product is correct.

Across basins, the common standard-deviation ratio decreased as precipitation seasonality and aridity increased (rho = {values['hydroclimate_rho']['standard_deviation_ratio']['p_seasonality']:.3f} and {values['hydroclimate_rho']['standard_deviation_ratio']['aridity']:.3f}) and increased with mean precipitation (rho = {values['hydroclimate_rho']['standard_deviation_ratio']['p_mean']:.3f}). Its snow-fraction association was smaller and opposite in sign (rho = {values['hydroclimate_rho']['standard_deviation_ratio']['frac_snow']:.3f}). Common high-flow bias showed the same seasonality, aridity, and mean-precipitation ordering ({values['hydroclimate_rho']['original_high_flow_bias']['p_seasonality']:.3f}, {values['hydroclimate_rho']['original_high_flow_bias']['aridity']:.3f}, and {values['hydroclimate_rho']['original_high_flow_bias']['p_mean']:.3f}), while the snow-fraction association was only {values['hydroclimate_rho']['original_high_flow_bias']['frac_snow']:.3f}. The shared amplitude problem is therefore hydroclimatically structured but is not a snow-only pattern. Figure 8 presents the amplitude-geometry, event-peak-concentration, paired-contrast, and precipitation-disagreement diagnostics together.

<!-- Evidence: tables/cause_amplitude_geometry_summary.csv; tables/cause_event_shape_summary.csv; tables/cause_event_shape_pairwise_summary.csv; tables/cause_forcing_disagreement_summary.csv; tables/cause_forcing_disagreement_quartiles.csv; figures/fig8_posthoc_cause_diagnostics.png -->
"""
    discussion = """

### 4.7 A three-level explanation rather than one universal defect

The results support a hierarchy. First, a benchmark-wide amplitude problem is shared by the neural and conceptual models, so systematic low upper flows cannot be attributed to conceptual structure alone. Second, event-peak concentration distinguishes an additional structure-dependent event-shape difference: GR4J is close to the LSTM, whereas Xinanjiang and HBV-lite attenuate aligned peaks more strongly relative to seven-day event volume. This shape statistic is consistent with differences in how the evaluated structures shape event hydrographs, but it does not identify routing, one internal reservoir, or any event-redistribution mechanism, and it does not prove that the LSTM represents the correct process. Third, precipitation-product disagreement shows a weak positive association with the common four-model volume error, which is consistent with precipitation-input uncertainty participating in the shared component but does not identify a causal share or which product is closer to truth. These layers are complementary and do not sum to a causal variance decomposition.

The hydroclimatic associations show that the shared pattern is not confined to snow indicators. Common amplitude compression strengthened with precipitation seasonality and aridity and weakened with mean precipitation, while its association with basin snow fraction was smaller in magnitude than the seasonality association. Snow-dominated high flow remains where the LSTM advantage concentrates, and these attribute associations describe where the shared underprediction is stronger or weaker; they do not exclude a role for snow processes and do not identify any driving mechanism.
"""
    limitations = """

The post-hoc cause diagnosis does not identify causal shares. Moment matching uses evaluation-period observations and can create negative discharge, alternative precipitation products are disagreement proxies rather than known truth, and event concentration is a relative shape statistic rather than a flood-frequency metric. The analysis therefore separates empirical signatures—shared amplitude compression, model-dependent event-peak concentration differences, and precipitation-input disagreement—but cannot quantify how much error is caused by forcing, objectives, observations, or model structure. It also does not reopen or retroactively pass either failed registered conditional branch.
"""
    conclusions = f"""

The deeper diagnosis resolves the apparent contradiction between shared underprediction and model-specific structure. All four models compressed discharge variability, but their event shapes differed: 90th-percentile event-peak concentration was {values['q90_peak_concentration']['LSTM']:.3f} for the LSTM, {values['q90_peak_concentration']['GR4J']:.3f} for GR4J, {values['q90_peak_concentration']['Xinanjiang']:.3f} for Xinanjiang, and {values['q90_peak_concentration']['HBV-lite']:.3f} for HBV-lite. Independent precipitation-product disagreement was positively associated with the common event-volume error in {values['q90_forcing_positive_basins']} of 531 basins. The complete conclusion is therefore a shared amplitude problem plus structure-dependent event-shape differences and a weak association with precipitation-product disagreement that is consistent with, but does not establish, a role for input uncertainty; the evaluation-period evidence does not identify causal shares or establish physically correct neural processes.
"""
    return {
        "abstract": "",
        "methods": methods,
        "results": results,
        "discussion": discussion,
        "limitations": limitations,
        "conclusions": conclusions,
    }


def _robustness_manuscript_blocks(tables: Dict[str, pd.DataFrame]) -> Dict[str, str]:
    if "context_scale_threshold_summary" not in tables:
        return {name: "" for name in ["abstract", "methods", "results", "protocol", "discussion", "limitations", "conclusions"]}

    values = _context_robustness_numbers(tables)
    flow = values["flow"]
    snow = values["snow_contrasts"]
    stability = values["stability"]

    def sequence(metric: str, flow_group: str) -> str:
        return ", ".join(f"{flow[label][flow_group][metric]:.3f}" for label in THRESHOLD_LABELS)

    q10_season = values["seasonal_contrasts_q10"].set_index(["left", "right"])
    djf_mam = q10_season.loc[("DJF", "MAM")]
    djf_jja = q10_season.loc[("DJF", "JJA")]
    jja_son = q10_season.loc[("JJA", "SON")]

    abstract = f"Fixed-threshold sensitivity separated two results: high flow dominated the per-day absolute-error margin, whereas middle flow had the largest dimensionless relative concentration; snow-dominated basins showed a larger median relative advantage across low, middle, and high flow. The complete context hierarchy remained strongly rank-stable when the whole benchmark was rebuilt under the common protocol."

    methods = """

To separate error scale from relative skill, we repeated the context calculation with a symmetric dimensionless relative advantage, 2 times (conceptual MAE minus LSTM MAE) divided by (conceptual MAE plus LSTM MAE). The quantity is zero when both errors are zero, lies between -2 and 2, and is positive when the LSTM has lower MAE. Absolute and relative concentration were kept as separate estimands: the former asks where the per-day error-reduction rate is highest, whereas the latter asks where relative advantage is overrepresented. We used three fixed within-basin discharge partitions—5th/95th, 10th/90th, and 20th/80th percentiles—without selecting a threshold from the results. Uncertainty intervals used 10,000 whole-basin bootstrap replicates, stratified by the four frozen hydrological regimes, with seed 20260726. Fixed contrast families compared flow groups, snow-dominated with pooled non-snow basins within each flow group, and seasons within snow-dominated high flow; Holm adjustment (Holm, 1979) was applied within each family. These are post-hoc uncertainty analyses of saved predictions, not new model experiments or confirmatory preregistered tests.

<!-- Evidence: tables/context_scale_threshold_summary.csv; tables/context_scale_threshold_intervals.csv; tables/context_scale_contrasts.csv -->
"""

    results = f"""

**Scale and threshold robustness.** High flow dominated the per-day absolute-error margin under every fixed partition: its absolute concentration ratios were {sequence('absolute_concentration_ratio', 'high')} for the 5th/95th, 10th/90th, and 20th/80th thresholds. It did not dominate dimensionless relative advantage. The corresponding high-flow relative concentration ratios were {sequence('relative_concentration_ratio', 'high')}, and every 95% interval lay below one. Instead, middle flow had the largest relative concentration in all three partitions ({sequence('relative_concentration_ratio', 'mid')}) and the largest median relative advantage ({sequence('median_relative_advantage', 'mid')}); it also had the highest shared-failure rate ({sequence('shared_failure_rate', 'mid')}). Low-flow relative concentration exceeded one in every partition ({sequence('relative_concentration_ratio', 'low')}), but its median relative advantage under the narrow 5th/95th tails was only {flow['q05_q95']['low']['median_relative_advantage']:.3f}. Concentration and typical basin effect therefore answer different questions.

Snow-dominated basins had a larger median relative advantage than pooled non-snow basins in every flow group and threshold arm. The snow-minus-non-snow contrast ranged from {snow['estimate'].min():.3f} to {snow['estimate'].max():.3f}; all whole-basin intervals excluded zero after within-family Holm adjustment. This broad hydrograph result is stronger than a snow-high-flow-only description, but it remains an associational regime contrast. Within snow-dominated high flow at the 10th/90th partition, the post-hoc common-basin contrasts ordered the seasonal medians as spring greater than winter greater than summer greater than autumn. Spring exceeded winter by {-djf_mam['estimate']:.3f} (95% interval [{-djf_mam['ci_high']:.3f}, {-djf_mam['ci_low']:.3f}]), winter exceeded summer by {djf_jja['estimate']:.3f} ([{djf_jja['ci_low']:.3f}, {djf_jja['ci_high']:.3f}]), and summer exceeded autumn by {jja_son['estimate']:.3f} ([{jja_son['ci_low']:.3f}, {jja_son['ci_high']:.3f}]). Because this contrast family was specified after inspection of the context matrix, its Holm-adjusted bootstrap tail probabilities quantify post-hoc uncertainty rather than prospective confirmation.

Figure 6 shows the four purposes of this sensitivity analysis: absolute concentration, dimensionless relative concentration, snow-regime amplification, and the bounded snow-high seasonal contrasts. No additional rainfall-runoff model was introduced.

<!-- Evidence: tables/context_scale_threshold_summary.csv; tables/context_scale_threshold_intervals.csv; tables/context_scale_contrasts.csv; figures/fig6_scale_threshold_robustness.png -->
"""

    protocol = f"""

The whole benchmark was rebuilt under the common protocol; this is not a training-objective ablation. Across the complete matrices, rank correlations between the historical and rebuilt results were {stability.loc['season', 'concentration_rank_spearman']:.3f}, {stability.loc['flow', 'concentration_rank_spearman']:.3f}, and {stability.loc['joint', 'concentration_rank_spearman']:.3f} for concentration, and {stability.loc['season', 'shared_failure_rank_spearman']:.3f}, {stability.loc['flow', 'shared_failure_rank_spearman']:.3f}, and {stability.loc['joint', 'shared_failure_rank_spearman']:.3f} for shared failure. The 16 season-regime and 12 flow-regime cells had no above-one classification flips and no median-gap sign flips. Among 48 joint cells, one concentration classification and three median-gap signs changed, while snow-dominated spring high flow remained the top absolute-concentration cell. Across 39 primary static attributes, the rank correlation was {stability.loc['primary_attribute', 'concentration_rank_spearman']:.3f}, one false-discovery-rate classification changed, no association reversed direction, and snow fraction remained the strongest absolute correlation.

<!-- Evidence: tables/protocol_matrix_stability.csv; tables/protocol_matrix_cell_deltas.csv -->
"""

    discussion = """

The added sensitivity results change the scientific interpretation in a useful way. High flow is where the LSTM's daily error margin over the conceptual models is largest in absolute terms; in relative terms, the margin peaks at middle flow. Middle flow is also where the three conceptual references fail together most consistently. Snow-dominated basins show a broader relative advantage across low, middle, and high flow. The defensible hierarchy is therefore scale-dependent: high flow dominates the per-day absolute-error margin; middle flow dominates relative concentration and cross-model consistency; snow regime amplifies the relative margin across the hydrograph; and spring is the largest post-hoc snow-high seasonal contrast. None of these patterns identifies a snowmelt mechanism or establishes physical-process fidelity of the LSTM.
"""

    limitations = """

The dimensionless sensitivity resolves the main error-scale ambiguity but does not create a causal estimand. Its symmetric denominator can make small absolute errors look proportionally large, as illustrated by low flow under the 5th/95th partition. Threshold arms are fixed sensitivity definitions, not independently replicated data sets, and their bootstrap intervals are correlated because they reuse the same 531 basins. The seasonal contrast family is explicitly post-hoc. It supports uncertainty-qualified ordering within this saved prediction set, not a preregistered seasonal hypothesis or a process attribution.
"""

    conclusions = f"""

The complete conclusion is scale-dependent rather than high-flow-only. High-flow absolute concentration remained above proportional under all three fixed partitions ({sequence('absolute_concentration_ratio', 'high')}), but high-flow relative concentration remained below proportional ({sequence('relative_concentration_ratio', 'high')}). Middle flow carried the largest dimensionless concentration and shared-failure consistency, while snow-dominated basins showed a larger relative advantage across all three flow groups. The common-protocol rebuild preserved the full 16-, 12-, and 48-cell hierarchy with only one above-one classification flip and three median-gap sign flips in the 48-cell matrix. This supports a robust contextual diagnosis, not another model comparison, a training-objective ablation, or a causal account of snow processes.
"""
    return {
        "abstract": abstract,
        "methods": methods,
        "results": results,
        "protocol": protocol,
        "discussion": discussion,
        "limitations": limitations,
        "conclusions": conclusions,
    }
def _population_evidence_table(out_dir: Path, policy: dict,
                               protocol: EvidenceProtocol | str | None = None) -> pd.DataFrame:
    resolved = _resolve(protocol)
    specs = [
        ("population.snow_fraction", {"target": "lstm_minus_best_conceptual",
                                      "feature": "clim_frac_snow"}),
        ("population.spring_snow_fraction", {"context": "MAM",
                                             "target": "best_conceptual_mae_minus_lstm",
                                             "feature": "clim_frac_snow"}),
        ("population.high_flow_snow_fraction", {"context": "high",
                                                "target": "best_conceptual_mae_minus_lstm",
                                                "feature": "clim_frac_snow"}),
    ]
    rows = []
    for evidence_id, filters in specs:
        input_id = resolved.input_ids[evidence_id][0]
        item_path = Path(_policy_input(policy, input_id)["path"])
        package_root = Path(policy["baseline_package_root"])
        source_path = out_dir / item_path.relative_to(package_root) if _is_under(item_path, package_root) else item_path
        source = pd.read_csv(source_path)
        selected = source
        for column, value in filters.items():
            selected = selected[selected[column] == value]
        if len(selected) != 1:
            raise ValueError(f"Expected one population evidence row for {evidence_id}, found {len(selected)}")
        row = selected.iloc[0]
        rows.append({
            "evidence_id": evidence_id,
            "input_id": input_id,
            "n": int(row["n"]),
            "spearman_rho": float(row["spearman_rho"]),
            "p_value": float(row["p_value"]),
            "q_value": float(row["q_value"]),
            "quartile_median_difference": (
                float(row["quartile_median_effect_high_minus_low"])
                if "quartile_median_effect_high_minus_low" in row.index else np.nan
            ),
        })
    return pd.DataFrame(rows)


def _main_benchmark_table(all_nse: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for model in ["GR4J", "XAJ", "HBV", "LSTM_single_s100", "LSTM_ensemble_8seed"]:
        vals = all_nse[model].dropna()
        row = {
            "model": model,
            "n": int(vals.shape[0]),
            "median_nse": float(vals.median()),
            "mean_nse": float(vals.mean()),
        }
        if model != "GR4J":
            diff = vals - all_nse.loc[vals.index, "GR4J"]
            row["median_delta_vs_gr4j"] = float(diff.median())
            row["win_rate_vs_gr4j"] = float((diff > 0).mean())
        else:
            row["median_delta_vs_gr4j"] = 0.0
            row["win_rate_vs_gr4j"] = np.nan
        rows.append(row)
    return pd.DataFrame(rows)


def _paired_comparison_table(protocol: EvidenceProtocol | str | None = None) -> pd.DataFrame:
    return _resolve(protocol).paired_comparison()


def _diagnostic_table(concept_long: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for model, group in concept_long.groupby("model"):
        rows.append({
            "model": model,
            "median_nse": float(group["nse"].median()),
            "median_kge": float(group["kge"].median()),
            "median_abs_bias": float(group["bias"].abs().median()),
            "median_abs_peak_bias": float(group["peak_bias"].abs().median()),
            "median_abs_lowflow_bias": float(group["lowflow_bias"].abs().median()),
            "median_cal_eval_gap": float(group["cal_eval_gap"].median()),
            "n_nse_lt_0": int((group["nse"] < 0).sum()),
        })
    order = {"GR4J": 0, "XAJ": 1, "HBV": 2}
    return pd.DataFrame(rows).sort_values("model", key=lambda s: s.map(order)).reset_index(drop=True)


def _winner_table(concept_long: pd.DataFrame) -> pd.DataFrame:
    wide = concept_long.pivot(index="basin_id", columns="model")
    rows = []
    for metric in ["nse", "kge"]:
        counts = wide[metric].idxmax(axis=1).value_counts()
        for model, count in counts.items():
            rows.append({"metric": metric, "winner_rule": "higher_is_better", "model": model, "n_wins": int(count)})
    for metric in ["bias", "peak_bias", "lowflow_bias", "cal_eval_gap"]:
        values = wide[metric].abs()
        best = values.min(axis=1)
        for model in ["GR4J", "XAJ", "HBV"]:
            rows.append({
                "metric": f"abs_{metric}",
                "winner_rule": "lower_abs_is_better",
                "model": model,
                "n_wins": int(((values[model] - best).abs() < 1e-12).sum()),
            })
    return pd.DataFrame(rows)


def _regime_table(all_nse: pd.DataFrame, protocol: EvidenceProtocol | str | None = None) -> pd.DataFrame:
    regime = _load_regime(protocol)
    df = all_nse.copy()
    df["regime"] = regime.reindex(df.index)
    rows = []
    for regime_name, group in df.groupby("regime"):
        best_concept = group[["GR4J", "XAJ", "HBV"]].max(axis=1)
        row = {"regime": regime_name, "n": int(group.shape[0])}
        for model in ["GR4J", "XAJ", "HBV", "LSTM_ensemble_8seed"]:
            row[f"{model}_median_nse"] = float(group[model].median())
        row["median_lstm_minus_best_conceptual"] = float((group["LSTM_ensemble_8seed"] - best_concept).median())
        row["conceptual_beats_lstm_count"] = int((best_concept > group["LSTM_ensemble_8seed"]).sum())
        rows.append(row)
    return pd.DataFrame(rows).sort_values("regime").reset_index(drop=True)


def _oracle_table(all_nse: pd.DataFrame) -> pd.DataFrame:
    best_concept = all_nse[["GR4J", "XAJ", "HBV"]].max(axis=1)
    all4 = pd.concat([best_concept.rename("best_conceptual"), all_nse["LSTM_ensemble_8seed"]], axis=1).max(axis=1)
    winners = all_nse[["GR4J", "XAJ", "HBV", "LSTM_ensemble_8seed"]].idxmax(axis=1).value_counts()
    rows = [
        {"quantity": "best_conceptual_median_nse", "value": float(best_concept.median())},
        {"quantity": "lstm_ensemble_median_nse", "value": float(all_nse["LSTM_ensemble_8seed"].median())},
        {"quantity": "four_model_oracle_median_nse", "value": float(all4.median())},
        {"quantity": "four_model_oracle_minus_lstm_median", "value": float((all4 - all_nse["LSTM_ensemble_8seed"]).median())},
        {"quantity": "four_model_oracle_minus_lstm_mean", "value": float((all4 - all_nse["LSTM_ensemble_8seed"]).mean())},
        {"quantity": "conceptual_beats_lstm_count", "value": int((best_concept > all_nse["LSTM_ensemble_8seed"]).sum())},
    ]
    for model in ["GR4J", "XAJ", "HBV", "LSTM_ensemble_8seed"]:
        rows.append({"quantity": f"winner_count_{model}", "value": int(winners.get(model, 0))})
    return pd.DataFrame(rows)


def _protocol_table(protocol: EvidenceProtocol | str | None = None) -> pd.DataFrame:
    resolved = _resolve(protocol)
    identical = resolved.protocol_id == IDENTICAL_PROTOCOL_ID
    conceptual_source = (
        "results/18_lstm_fair_531/R02_identical_basin_nse_531/conceptual" if identical else str(REPRO)
    )
    neural_source = (
        "results/18_lstm_fair_531/R02_identical_basin_nse_531" if identical else "results/18_lstm_fair_531"
    )
    objective = (
        "basin-averaged one-minus-efficiency, identical for all four models"
        if identical else
        "conceptual models on per-basin efficiency; network on basin-normalised squared error"
    )
    observations = (
        "one observation series shared by all four models, enforced to float32 tolerance"
        if identical else
        "each model scored against the observation series its own pipeline loaded"
    )
    optimization_target_period = (
        "2000-09-30 to 2008-09-30" if identical else "1999-10-01 to 2008-09-30"
    )
    conceptual_context = (
        "1999-10-01 to 2000-09-29 calibration warm-up; "
        "1988-10-01 to 1989-09-30 evaluation warm-up"
        if identical else "one-year state warm-up before evaluation"
    )
    neural_context = (
        "270-day sequence context; target dates follow the registered configurations"
        if identical else "270-day sequence context"
    )
    return pd.DataFrame([
        {
            "family": "conceptual_models",
            "models": "GR4J+PDD; XAJ+PDD; HBV-lite",
            "basins": 531,
            "forcing": "maurer",
            "optimization_target_period": optimization_target_period,
            "pre_target_context_or_warmup": conceptual_context,
            "evaluation": "1989-10-01 to 1999-09-30",
            "metric": "per-basin NSE, median/mean across basins",
            "objective": objective,
            "scoring_observations": observations,
            "budget_or_seed_policy": "CMA-ES 5000 trials x 3 restarts",
            "input_information": "forcing plus model parameters; no observed discharge as input",
            "source": conceptual_source,
        },
        {
            "family": "lstm_ceiling",
            "models": "cudalstm+static, seed 100 and 8-seed ensemble",
            "basins": 531,
            "forcing": "maurer",
            "optimization_target_period": optimization_target_period,
            "pre_target_context_or_warmup": neural_context,
            "evaluation": "1989-10-01 to 1999-09-30",
            "metric": "per-basin NSE, median/mean across basins",
            "objective": objective,
            "scoring_observations": observations,
            "budget_or_seed_policy": "30 epochs; seeds 100..800; regional training with 27 static basin attributes",
            "input_information": "forcing plus 27 static attributes; no observed discharge as input",
            "source": neural_source,
        },
    ])


def _registered_lstm_config_provenance_table() -> pd.DataFrame:
    """Audit the eight registered neural configurations for the supplement."""
    run_identity_fields = {"experiment_name", "img_log_dir", "run_dir", "seed", "train_dir"}
    reference_settings = None
    rows = []
    for seed in REGISTERED_LSTM_SEEDS:
        path = REGISTERED_LSTM_CONFIG_ROOT / f"seed_{seed}" / "config.yml"
        if not path.is_file():
            raise SnapshotInputError(f"Registered LSTM configuration is missing: {path}")
        raw = path.read_bytes()
        config = yaml.safe_load(raw)
        if not isinstance(config, dict):
            raise SnapshotInputError(f"Registered LSTM configuration is not a mapping: {path}")
        expected = {
            "seed": seed,
            "train_start_date": "30/09/2000",
            "train_end_date": "30/09/2008",
            "test_start_date": "01/10/1989",
            "test_end_date": "30/09/1999",
        }
        mismatches = {
            key: {"expected": value, "actual": config.get(key)}
            for key, value in expected.items()
            if config.get(key) != value
        }
        if mismatches:
            raise SnapshotInputError(f"Registered LSTM configuration mismatch in {path}: {mismatches}")
        invariant_settings = {
            key: value for key, value in config.items() if key not in run_identity_fields
        }
        if reference_settings is None:
            reference_settings = invariant_settings
        elif invariant_settings != reference_settings:
            changed = sorted(
                set(reference_settings) ^ set(invariant_settings) |
                {
                    key for key in set(reference_settings) & set(invariant_settings)
                    if reference_settings[key] != invariant_settings[key]
                }
            )
            raise SnapshotInputError(
                f"Registered LSTM configuration seed {seed} changes non-identity settings: {changed}"
            )
        validation_date_fields = [
            key for key in ("validation_start_date", "validation_end_date") if key in config
        ]
        rows.append({
            "seed": seed,
            "config_path": path.as_posix(),
            "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest().upper(),
            "training_target_start": "2000-09-30",
            "training_target_end": "2008-09-30",
            "evaluation_start": "1989-10-01",
            "evaluation_end": "1999-09-30",
            "validation_dates": (
                "; ".join(f"{key}={config[key]}" for key in validation_date_fields)
                if validation_date_fields else "not registered"
            ),
            "epochs": int(config["epochs"]),
            "loss": str(config["loss"]),
            "non_identity_settings_match_seed_100": True,
        })
    return pd.DataFrame(rows)


def _parameter_accounting_table() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "model": "GR4J+PDD",
            "snow_module_class": "external PDD-noice front end",
            "nominal_parameters": 8,
            "effective_active_parameters": 8,
            "external_snow_parameters_nominal": 4,
            "external_snow_parameters_effective": 4,
            "intrinsic_snow_parameters": 0,
            "accounting_note": "4 active no-ice PDD parameters plus 4 GR4J parameters.",
        },
        {
            "model": "XAJ+PDD",
            "snow_module_class": "external full PDD wrapper, zero-ice effective path",
            "nominal_parameters": 20,
            "effective_active_parameters": 18,
            "external_snow_parameters_nominal": 6,
            "external_snow_parameters_effective": 4,
            "intrinsic_snow_parameters": 0,
            "accounting_note": "pdd_factor_ice and refreeze_ice are inactive when ice storage starts at zero.",
        },
        {
            "model": "HBV-lite",
            "snow_module_class": "intrinsic HBV degree-day snow routine",
            "nominal_parameters": 13,
            "effective_active_parameters": 13,
            "external_snow_parameters_nominal": 0,
            "external_snow_parameters_effective": 0,
            "intrinsic_snow_parameters": 4,
            "accounting_note": "Snow is part of HBV structure: parTT, parCFMAX, parCFR, parCWH.",
        },
    ])


def _fairness_audit_table(protocol: EvidenceProtocol | str | None = None) -> pd.DataFrame:
    resolved = _resolve(protocol)
    identical = resolved.protocol_id == IDENTICAL_PROTOCOL_ID
    pdd_test = PDD_FAIRNESS_TEST.as_posix()
    protocol_rows = [
        {
            "dimension": "training_and_calibration_objective",
            "classification": "identical" if identical else "model-family-specific/disclosed",
            "conclusion": (
                "All four models are optimised on the same basin-averaged one-minus-efficiency "
                "objective, so no comparison rests on the network having been given an easier "
                "target." if identical else
                "The conceptual models are calibrated on per-basin efficiency while the network "
                "minimises a basin-normalised squared error; the two are not the same objective."
            ),
            "evidence": (
                "results/18_lstm_fair_531/R02_identical_basin_nse_531/protocol/common_loss_protocol.json"
                if identical else
                "src/lstm_fair_531/configs and the conceptual calibration runners."
            ),
            "paper_action": (
                "State the common objective in Methods and drop the differing-objective caveat."
                if identical else
                "Disclose the differing objective as a limitation of this benchmark."
            ),
        },
        {
            "dimension": "scoring_observation_series",
            "classification": "unified" if identical else "inconsistent/quantified",
            "conclusion": (
                "One observation series is shared by all four models; the daily panel refuses to "
                "build unless the conceptual and neural observations agree to float32 tolerance."
                if identical else
                "Conceptual rows and neural rows carry observations that differ by a per-basin "
                "multiplicative factor between 0.88 and 1.15. Efficiency is invariant to that "
                "rescaling and is unaffected, but absolute-error differences between models are not."
            ),
            "evidence": (
                "src/lstm_fair_531/scripts/analyze_identical_basin_nse_replication.py::build_daily_panel"
                if identical else
                "results/18_lstm_fair_531/R02_identical_basin_nse_531/analysis_key_points_20260724/"
                "R01_observation_inconsistency.md"
            ),
            "paper_action": (
                "Report the concentration statistics from this protocol." if identical else
                "Do not quote this protocol's absolute-error concentration statistics without the "
                "correction; its efficiency table is unaffected."
            ),
        },
    ]
    return pd.DataFrame(protocol_rows + [
        {
            "dimension": "external_snow_frontend_GR4J_XAJ",
            "classification": "effective-equivalent",
            "conclusion": "GR4J no-ice PDD and XAJ full-PDD with zero ice follow the same active snow path.",
            "evidence": f"{pdd_test}; src/xaj_global_pilot/pdd_core.py::pdd_noice_step_mm",
            "paper_action": "Describe the external PDD front end as tested effective-equivalent, not merely assumed equal.",
        },
        {
            "dimension": "xaj_ice_parameters",
            "classification": "effective-inactive",
            "conclusion": "Changing pdd_factor_ice/refreeze_ice does not change runoff or states under zero initial ice.",
            "evidence": f"{pdd_test}; XAJ PDD state starts with ice=0 and has no ice-creation term.",
            "paper_action": "Report XAJ nominal parameters as 20 and effective active parameters as 18.",
        },
        {
            "dimension": "hbv_snow_module",
            "classification": "model-intrinsic difference",
            "conclusion": "HBV-lite snow handling is part of the HBV model structure, not an added shared PDD wrapper.",
            "evidence": "src/scl_hydro/hbv_lite_numpy.py states SNOWPACK/MELTWATER and parameters parTT/parCFMAX/parCFR/parCWH.",
            "paper_action": "Keep HBV in the benchmark, but disclose this structural difference in Methods and Limitations.",
        },
        {
            "dimension": "basin_forcing_split_pet_warmup",
            "classification": "aligned",
            "conclusion": "The final conceptual artifacts use 531 basins, Maurer forcing, PT PET, reverse split, and eval warmup-year.",
            "evidence": "Final artifact filenames and runner metadata under results/10_global_conceptual_model_benchmark.",
            "paper_action": "State same predictive-information protocol for the conceptual benchmark.",
        },
        {
            "dimension": "cmaes_budget_seed_init_loss",
            "classification": "aligned",
            "conclusion": "GR4J/XAJ/HBV use CMA-ES 5000 trials x 3 restarts, seed 42+1000*r, init 0.5, sigma 0.3, NSE loss.",
            "evidence": "src/xaj_global_pilot/xaj_model.py::_cmaes_multi_restart; src/scl_hydro/hbv_lite_cma_calibrate.py.",
            "paper_action": "Report the common optimizer budget and selection rule.",
        },
        {
            "dimension": "bounds_and_constraints",
            "classification": "model-specific/disclosed",
            "conclusion": "Parameter bounds are model-specific; XAJ applies its intrinsic ki+kg constraint; GR4J/HBV do not need it.",
            "evidence": "src/xaj_global_pilot/bounds_presets.py; src/xaj_global_pilot/gr4j_model.py; src/scl_hydro/hbv_lite_numpy.py.",
            "paper_action": "Disclose bounds presets and treat this as structural calibration space, not a hidden advantage.",
        },
        {
            "dimension": "saved_parameter_replay_after_code_changes",
            "classification": "passed_full_531",
            "conclusion": "Saved calibrated parameters replay under the current code for all 531 common basins in saved-state and warmup-recomputed modes.",
            "evidence": f"{(REPLAY_AUDIT_REL / 'saved_parameter_replay_summary.csv').as_posix()}; {REPLAY_AUDIT_COMMAND}",
            "paper_action": "Use replay as an artifact-validity audit; do not call it a fresh recalibration.",
        },
        {
            "dimension": "stale_petbug_v7_references",
            "classification": "historical-only/quarantined",
            "conclusion": "Old PET-bug, XAJ 0.4458/0.6372, and HBV-v7 references are not active manuscript evidence.",
            "evidence": "audit/stale_reference_audit.csv and docs/technical/camels_us_531_regime_diagnostic.md quarantine banner.",
            "paper_action": "Use only final PT 5k x 3 artifacts in manuscript tables and captions.",
        },
    ])


def _protocol_robustness_table() -> pd.DataFrame:
    """Compare the headline quantities across both protocols, in one table.

    This is the table a reviewer who asks "were the objectives identical?" should be sent
    to. It is built by reading each protocol's own inputs, so it cannot drift from the
    tables the two packages report.
    """
    rows = []
    for protocol_id in list_protocols():
        resolved = get_protocol(protocol_id)
        if resolved.missing_inputs():
            continue
        efficiencies = resolved.per_basin_nse()
        paired = resolved.paired_comparison().set_index("comparison")
        advantage = resolved.advantage_numbers()
        population = resolved.population_support_numbers()
        rows.append({
            "protocol": protocol_id,
            "loss_protocol": resolved.loss_protocol,
            "n_basins": int(efficiencies.shape[0]),
            "gr4j_median_nse": float(efficiencies["GR4J"].median()),
            "xaj_median_nse": float(efficiencies["XAJ"].median()),
            "hbv_median_nse": float(efficiencies["HBV"].median()),
            "lstm_ensemble_median_nse": float(efficiencies["LSTM_ensemble_8seed"].median()),
            "paired_median_diff_vs_gr4j": float(paired.loc["LSTM_ensemble_8seed_vs_GR4J", "median_diff"]),
            "paired_win_rate_vs_gr4j": float(paired.loc["LSTM_ensemble_8seed_vs_GR4J", "lstm_win_rate"]),
            "snow_spring_gap_share": advantage["snow_mam_gap_share"],
            "snow_high_flow_gap_share": advantage["snow_high_gap_share"],
            "snow_spring_high_flow_gap_share": advantage["snow_mam_high_gap_share"],
            "snow_spring_high_flow_concentration_ratio": advantage["snow_mam_high_ratio"],
            "snow_spring_high_flow_shared_failure_rate": advantage["snow_mam_high_shared_failure"],
            "snow_fraction_spearman_rho": population["basin_snow_rho"],
            "snow_fraction_q_value": population["basin_snow_q"],
        })
    return pd.DataFrame(rows)


def _is_under(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def _stale_classification(path: Path, text: str, quarantined: bool = False) -> Tuple[str, str]:
    posix = path.as_posix()
    if "src/lstm_fair_531/scripts/build_manuscript_evidence_package.py" in posix:
        return "safe_audit_tool", "This script stores stale tokens only as scan patterns."
    if "docs/technical/camels_us_531_regime_diagnostic.md" in posix:
        if quarantined:
            return "quarantined_stale", "Superseded PET-bug diagnostic is explicitly quarantined; do not use as manuscript evidence."
        return "blocker", "Archive or rewrite before manuscript use; it points at PET-bug XAJ diagnostics."
    if "src/xaj_global_pilot/scripts/gr4j_final_report.py" in posix:
        return "blocker", "Update script defaults to final 5k x 3 XAJ/HBV artifacts before using for figures/tables."
    if "src/xaj_global_pilot/scripts/run_xaj_pdd_cma_repro_v01.py" in posix:
        return "safe_historical_docstring", "Runner mentions the old PET-bug baseline only as historical motivation."
    if "draft/papers/10_18_conceptual_lstm_gap_validation_20260709.md" in posix:
        return "safe_audit_note", "This file mentions stale paths only as audit checks."
    historical_markers = [
        "handoffs",
        "xaj_playbook",
        "gr4j_playbook",
        "camels_531_lockdown_report",
        "plans",
        "specs",
        "IDEA_RESCUE_LEDGER",
        "ideas/10_",
    ]
    if any(marker in posix for marker in historical_markers):
        return "historical_caveat", "Keep as history unless this document is reused as manuscript text."
    if path.suffix == ".py":
        return "review_needed", "Potential active code path; verify before generating manuscript artifacts."
    return "review_needed", "Potential stale prose; inspect before manuscript reuse."


def _stale_reference_audit(out_dir: Path | None = None,
                           scan_paths: Iterable[Path] | None = None) -> pd.DataFrame:
    rows = []
    excluded_dirs = []
    if out_dir is not None:
        excluded_dirs.append(out_dir.resolve())
    for root in scan_paths or ACTIVE_STALE_SCAN_PATHS:
        if not root.exists():
            continue
        candidates = [root] if root.is_file() else root.rglob("*")
        for path in candidates:
            if not path.is_file() or path.suffix not in SCAN_SUFFIXES:
                continue
            resolved = path.resolve()
            if any(_is_under(resolved, excluded) for excluded in excluded_dirs):
                continue
            try:
                lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
            except UnicodeDecodeError:
                continue
            quarantined = "STALE_PETBUG_SUPERSEDED" in "\n".join(lines[:12])
            for line_no, line in enumerate(lines, start=1):
                hits = [pat for pat in STALE_PATTERNS if pat in line]
                if not hits:
                    continue
                status, action = _stale_classification(path, line, quarantined=quarantined)
                rows.append({
                    "file": path.as_posix(),
                    "line": line_no,
                    "patterns": "; ".join(hits),
                    "status": status,
                    "recommended_action": action,
                    "excerpt": line.strip()[:240],
                })
    return pd.DataFrame(rows, columns=[
        "file", "line", "patterns", "status", "recommended_action", "excerpt"
    ])


def _plot_cdf(all_nse: pd.DataFrame, fig_path: Path) -> None:
    colors = {
        "GR4J": "#0072B2",
        "XAJ": "#009E73",
        "HBV": "#E69F00",
        "LSTM_single_s100": "#CC79A7",
        "LSTM_ensemble_8seed": "#D55E00",
    }
    labels = {
        "GR4J": "GR4J+PDD",
        "XAJ": "XAJ+PDD",
        "HBV": "HBV-lite",
        "LSTM_single_s100": "LSTM single",
        "LSTM_ensemble_8seed": "LSTM ensemble",
    }
    order = ["GR4J", "XAJ", "HBV", "LSTM_single_s100", "LSTM_ensemble_8seed"]
    truncation = -1.0
    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    series = {}
    tail_counts = {}
    for model in order:
        vals = np.sort(all_nse[model].dropna().to_numpy())
        y = np.arange(1, len(vals) + 1) / len(vals)
        series[model] = (vals, y)
        tail_counts[model] = int((vals < truncation).sum())
        ax.plot(vals, y, label=labels[model], linewidth=2, color=colors[model])
    ax.axvline(0.0, color="#666666", linewidth=0.8, linestyle="--")
    ax.set_xlim(truncation, 1.0)
    ax.set_xlabel(f"Basin-wise NSE (main axis truncated at {truncation:g}; inset shows the full range)")
    ax.set_ylabel("Empirical CDF")
    ax.set_title("CAMELS-US 531 NSE distributions")
    ax.grid(True, alpha=0.25)
    ax.legend(frameon=False, loc="upper left")
    tail_note = "; ".join(f"{labels[model]} {tail_counts[model]}" for model in order)
    ax.text(0.02, 0.02, f"Basins below NSE = {truncation:g} (kept in inset): {tail_note}",
            transform=ax.transAxes, fontsize=7.5, color="#444444")
    inset = ax.inset_axes([0.07, 0.30, 0.36, 0.34])
    for model in order:
        vals, y = series[model]
        inset.plot(vals, y, linewidth=1.2, color=colors[model])
    inset.axvline(truncation, color="#666666", linewidth=0.6, linestyle="--")
    inset.set_title("Full range, all 531 basins", fontsize=7.5)
    inset.tick_params(labelsize=7)
    inset.grid(True, alpha=0.2)
    fig.tight_layout()
    fig.savefig(fig_path, dpi=220)
    plt.close(fig)


def _plot_regime(regime_df: pd.DataFrame, fig_path: Path) -> None:
    models = ["GR4J_median_nse", "XAJ_median_nse", "HBV_median_nse", "LSTM_ensemble_8seed_median_nse"]
    labels = ["GR4J", "XAJ", "HBV", "LSTM ens"]
    colors = ["#0072B2", "#009E73", "#E69F00", "#D55E00"]
    x = np.arange(len(regime_df))
    width = 0.19
    fig, ax = plt.subplots(figsize=(8.2, 4.6))
    for idx, (model, label, color) in enumerate(zip(models, labels, colors)):
        ax.bar(x + (idx - 1.5) * width, regime_df[model], width=width, label=label, color=color)
    ax.set_xticks(x)
    ax.set_xticklabels(regime_df["regime"], rotation=18, ha="right")
    ax.set_ylabel("Median NSE")
    ax.set_title("Regime-wise median NSE")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(frameon=False, ncol=4)
    fig.tight_layout()
    fig.savefig(fig_path, dpi=220)
    plt.close(fig)


def _plot_diagnostics(diag_df: pd.DataFrame, fig_path: Path) -> None:
    metrics = [
        "median_abs_bias",
        "median_abs_peak_bias",
        "median_abs_lowflow_bias",
        "median_cal_eval_gap",
    ]
    labels = ["abs bias", "abs peak bias", "abs low-flow bias", "cal-eval gap"]
    colors = {"GR4J": "#0072B2", "XAJ": "#009E73", "HBV": "#E69F00"}
    x = np.arange(len(metrics))
    width = 0.24
    fig, ax = plt.subplots(figsize=(8.0, 4.4))
    for idx, model in enumerate(["GR4J", "XAJ", "HBV"]):
        vals = [diag_df.loc[diag_df["model"] == model, metric].iloc[0] for metric in metrics]
        ax.bar(x + (idx - 1) * width, vals, width=width, label=model, color=colors[model])
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=15, ha="right")
    ax.set_ylabel("Median value (lower is better)")
    ax.set_title("Conceptual-model diagnostic trade-offs")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(frameon=False, ncol=3)
    fig.tight_layout()
    fig.savefig(fig_path, dpi=220)
    plt.close(fig)


def _plot_lstm_margin(all_nse: pd.DataFrame, fig_path: Path, protocol: EvidenceProtocol | str | None = None) -> None:
    regime = _load_regime(protocol)
    df = all_nse.copy()
    df["regime"] = regime.reindex(df.index)
    df["best_conceptual"] = df[["GR4J", "XAJ", "HBV"]].max(axis=1)
    df["lstm_minus_best_conceptual"] = df["LSTM_ensemble_8seed"] - df["best_conceptual"]
    order = ["humid", "snow-dominated", "semi-humid", "semi-arid/arid"]
    data = [df.loc[df["regime"] == regime_name, "lstm_minus_best_conceptual"].dropna().to_numpy() for regime_name in order]
    fig, ax = plt.subplots(figsize=(7.4, 4.5))
    ax.boxplot(data, tick_labels=order, showfliers=False, patch_artist=True,
               boxprops={"facecolor": "#D9EAF7", "edgecolor": "#0072B2"},
               medianprops={"color": "#D55E00", "linewidth": 2})

    ax.axhline(0.0, color="#555555", linewidth=1.0, linestyle="--")
    ax.set_ylabel("LSTM ensemble NSE - best conceptual NSE")
    ax.set_title("Predictive margin over the best conceptual model")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(fig_path, dpi=220)
    plt.close(fig)

def _plot_scale_threshold_robustness(tables: Dict[str, pd.DataFrame], fig_path: Path) -> None:
    """Contrast absolute concentration, relative concentration, snow amplification, and season pairs."""
    values = _context_robustness_numbers(tables)
    thresholds = list(THRESHOLD_LABELS)
    x = np.arange(len(thresholds), dtype=float)
    colors = {"low": "#4C78A8", "mid": "#59A14F", "high": "#E15759"}
    markers = {"low": "o", "mid": "s", "high": "^"}
    fig, axes = plt.subplots(2, 2, figsize=(13.2, 9.2))

    for axis, metric, title, ylabel in [
            (axes[0, 0], "absolute_concentration_ratio",
             "A  Per-day absolute-error concentration", "Concentration ratio"),
            (axes[0, 1], "relative_concentration_ratio",
             "B  Dimensionless relative-advantage concentration", "Concentration ratio"),
    ]:
        for flow in ["low", "mid", "high"]:
            points = [values["flow"][threshold][flow][metric] for threshold in thresholds]
            bounds = [values["flow_intervals"][threshold][flow][metric] for threshold in thresholds]
            lower = [point - bound["ci_low"] for point, bound in zip(points, bounds)]
            upper = [bound["ci_high"] - point for point, bound in zip(points, bounds)]
            axis.errorbar(
                x, points, yerr=np.vstack([lower, upper]), color=colors[flow], marker=markers[flow],
                linewidth=2.0, markersize=6, capsize=3, label=FLOW_LABELS[flow]
            )
        axis.axhline(1.0, color="#555555", linestyle="--", linewidth=1.2)
        axis.set_xticks(x, [THRESHOLD_LABELS[label] for label in thresholds])
        axis.set_xlabel("Within-basin low/high discharge thresholds")
        axis.set_ylabel(ylabel)
        axis.set_title(title, loc="left")
        axis.grid(axis="y", alpha=0.22)
    axes[0, 0].legend(frameon=False, ncol=3, loc="upper right")

    snow = values["snow_contrasts"]
    offsets = {"low": -0.18, "mid": 0.0, "high": 0.18}
    for flow in ["low", "mid", "high"]:
        selected = snow[snow["flow_group"] == flow].set_index("threshold_label").loc[thresholds]
        xpos = x + offsets[flow]
        axes[1, 0].errorbar(
            xpos, selected["estimate"],
            yerr=np.vstack([
                selected["estimate"].to_numpy() - selected["ci_low"].to_numpy(),
                selected["ci_high"].to_numpy() - selected["estimate"].to_numpy(),
            ]),
            color=colors[flow], marker=markers[flow], linestyle="none", markersize=6, capsize=3,
            label=FLOW_LABELS[flow],
        )
    axes[1, 0].axhline(0.0, color="#555555", linestyle="--", linewidth=1.2)
    axes[1, 0].set_xticks(x, [THRESHOLD_LABELS[label] for label in thresholds])
    axes[1, 0].set_xlabel("Within-basin low/high discharge thresholds")
    axes[1, 0].set_ylabel("Snow minus pooled non-snow\nmedian relative advantage")
    axes[1, 0].set_title("C  Snow-regime amplification across the hydrograph", loc="left")
    axes[1, 0].grid(axis="y", alpha=0.22)
    axes[1, 0].legend(frameon=False, ncol=3, loc="upper right")

    seasonal = values["seasonal_contrasts_q10"].copy()
    season_names = {"DJF": "Winter", "MAM": "Spring", "JJA": "Summer", "SON": "Autumn"}
    seasonal["label"] = seasonal["left"].map(season_names) + " - " + seasonal["right"].map(season_names)
    seasonal = seasonal.iloc[::-1].reset_index(drop=True)
    y = np.arange(len(seasonal))
    axes[1, 1].errorbar(
        seasonal["estimate"], y,
        xerr=np.vstack([
            seasonal["estimate"].to_numpy() - seasonal["ci_low"].to_numpy(),
            seasonal["ci_high"].to_numpy() - seasonal["estimate"].to_numpy(),
        ]),
        color="#7B5EA7", marker="o", linestyle="none", markersize=6, capsize=3,
    )
    axes[1, 1].axvline(0.0, color="#555555", linestyle="--", linewidth=1.2)
    axes[1, 1].set_yticks(y, seasonal["label"])
    axes[1, 1].set_xlabel("Common-basin median relative-advantage contrast")
    axes[1, 1].set_title("D  Snow-high seasonal contrasts at 10th/90th", loc="left")
    axes[1, 1].grid(axis="x", alpha=0.22)

    fig.suptitle("Scale and threshold robustness of the hydrological-context diagnosis", fontsize=14)
    fig.text(
        0.01, 0.012,
        "Intervals resample whole basins within fixed hydrological regimes (10,000 replicates). "
        "Panel D is a post-hoc contrast family with Holm adjustment.",
        fontsize=8.5,
    )
    fig.tight_layout(rect=[0, 0.04, 1, 0.96])
    fig.savefig(fig_path, dpi=220)
    plt.close(fig)


def _plot_hydrological_process_diagnostics(tables: Dict[str, pd.DataFrame], fig_path: Path) -> None:
    """Show direct flow-group and event diagnostics without derived mechanism scores."""
    values = _hydrological_process_numbers(tables)
    bias = tables["hydrological_flow_bias_summary"]
    models = ["LSTM", "GR4J", "Xinanjiang", "HBV-lite"]
    colors = {"LSTM": "#4C78A8", "GR4J": "#F28E2B", "Xinanjiang": "#59A14F", "HBV-lite": "#B07AA1"}
    seasons = ["autumn", "winter", "spring", "summer"]
    fig, axes = plt.subplots(2, 2, figsize=(13.2, 9.2))

    flow_groups = ["low", "mid", "high"]
    x = np.arange(len(flow_groups), dtype=float)
    offsets = np.linspace(-0.27, 0.27, len(models))
    width = 0.17
    for offset, model in zip(offsets, models):
        selected = bias[(bias["regime"] == "pooled") & (bias["model"] == model) &
                        (bias["diagnostic"] == "same_date_signed_bias")].set_index("flow_group").loc[flow_groups]
        points = selected["median"].to_numpy()
        axes[0, 0].bar(x + offset, points, width=width, color=colors[model], label=model)
        axes[0, 0].errorbar(
            x + offset, points,
            yerr=np.vstack([points - selected["ci_lower"].to_numpy(), selected["ci_upper"].to_numpy() - points]),
            fmt="none", ecolor="#333333", capsize=2, linewidth=0.9,
        )
    axes[0, 0].axhline(0.0, color="#555555", linestyle="--", linewidth=1.0)
    axes[0, 0].set_xticks(x, ["Low", "Middle", "High"])
    axes[0, 0].set_ylabel("Median relative signed bias")
    axes[0, 0].set_title("A  Same-date flow-group bias", loc="left")
    axes[0, 0].grid(axis="y", alpha=0.2)
    axes[0, 0].legend(frameon=False, ncol=2)

    event_x = np.arange(len(models), dtype=float)
    axes[0, 1].bar(
        event_x - 0.18, [values["q90_aligned_peak_bias"][model] for model in models],
        width=0.36, color="#4C78A8", label="Aligned peak magnitude",
    )
    axes[0, 1].bar(
        event_x + 0.18, [values["q90_volume_bias"][model] for model in models],
        width=0.36, color="#E15759", label="Seven-day volume",
    )
    axes[0, 1].axhline(0.0, color="#555555", linestyle="--", linewidth=1.0)
    axes[0, 1].axhline(-0.05, color="#777777", linestyle=":", linewidth=1.0)
    axes[0, 1].set_xticks(event_x, models, rotation=15)
    axes[0, 1].set_ylabel("Median relative bias")
    axes[0, 1].set_title("B  Observed 90th-percentile events", loc="left")
    axes[0, 1].grid(axis="y", alpha=0.2)
    axes[0, 1].legend(frameon=False)

    season_x = np.arange(len(seasons), dtype=float)
    for model in models:
        axes[1, 0].plot(
            season_x, [values["q90_seasonal_aligned_peak_bias"][season][model] for season in seasons],
            color=colors[model], marker="o", linewidth=2, label=model,
        )
        axes[1, 1].plot(
            season_x, [values["q90_seasonal_absolute_timing_days"][season][model] for season in seasons],
            color=colors[model], marker="o", linewidth=2, label=model,
        )
    for axis in axes[1, :]:
        axis.set_xticks(season_x, ["Autumn", "Winter", "Spring", "Summer"])
        axis.grid(axis="y", alpha=0.2)
    axes[1, 0].axhline(0.0, color="#555555", linestyle="--", linewidth=1.0)
    axes[1, 0].set_ylabel("Median aligned peak relative bias")
    axes[1, 0].set_title("C  Seasonal event magnitude", loc="left")
    axes[1, 1].set_ylabel("Median absolute timing error (days)")
    axes[1, 1].set_title("D  Seasonal event timing", loc="left")
    axes[1, 1].legend(frameon=False, ncol=2)

    fig.suptitle("Flow-duration and observed-event diagnostics", fontsize=14)
    fig.text(
        0.01, 0.012,
        "Events are defined from observed discharge; negative magnitude and volume values indicate underprediction. "
        "The dotted line in panel B marks the prespecified absolute volume tolerance of 0.05.",
        fontsize=8.5,
    )
    fig.tight_layout(rect=[0, 0.04, 1, 0.96])
    fig.savefig(fig_path, dpi=220)
    plt.close(fig)

def _plot_joint_context_heterogeneity(out_dir: Path, fig_path: Path,
                                      protocol: EvidenceProtocol | str | None = None) -> None:
    """Show every registered regime-season-flow cell without selecting winners."""
    joint = _context_evidence_tables(out_dir, protocol)["joint"]
    columns = [(season, flow) for season in _CONTEXT_SEASONS for flow in _CONTEXT_FLOWS]
    ratios = np.empty((len(_CONTEXT_REGIMES), len(columns)), dtype=float)
    failures = np.empty_like(ratios)
    counts = np.empty_like(ratios, dtype=int)
    indexed = joint.set_index(["regime", "season", "flow_group"])
    for row_index, regime in enumerate(_CONTEXT_REGIMES):
        for column_index, (season, flow) in enumerate(columns):
            row = indexed.loc[(regime, season, flow)]
            ratios[row_index, column_index] = float(row["gap_concentration_ratio"])
            failures[row_index, column_index] = float(row["shared_failure_rate"])
            counts[row_index, column_index] = int(row["n_contexts"])

    fig, axes = plt.subplots(2, 1, figsize=(13.6, 7.4), sharex=True)
    ratio_max = max(5.0, float(np.ceil(ratios.max())))
    ratio_norm = matplotlib.colors.TwoSlopeNorm(vmin=0.0, vcenter=1.0, vmax=ratio_max)
    ratio_image = axes[0].imshow(ratios, cmap="coolwarm", norm=ratio_norm, aspect="auto")
    failure_image = axes[1].imshow(failures, cmap="viridis", vmin=0.0, vmax=1.0, aspect="auto")

    row_labels = ["Humid", "Semi-humid", "Semi-arid/arid", "Snow-dominated"]
    column_labels = [f"{season}\n{flow}" for season, flow in columns]
    for axis in axes:
        axis.set_yticks(np.arange(len(_CONTEXT_REGIMES)), labels=row_labels)
        axis.set_xticks(np.arange(len(columns)), labels=column_labels)
        for boundary in [2.5, 5.5, 8.5]:
            axis.axvline(boundary, color="white", linewidth=2.2)
        axis.tick_params(axis="x", labelsize=8)
        axis.tick_params(axis="y", labelsize=9)

    axes[0].set_title("A  Positive absolute-error-gap concentration ratio (1 = proportional)", loc="left")
    axes[1].set_title("B  All-three-conceptual shared-failure rate", loc="left")
    axes[1].set_xlabel("Season and within-basin flow group")

    for row_index in range(ratios.shape[0]):
        for column_index in range(ratios.shape[1]):
            ratio = ratios[row_index, column_index]
            rgba = plt.get_cmap("coolwarm")(ratio_norm(ratio))
            luminance = 0.299 * rgba[0] + 0.587 * rgba[1] + 0.114 * rgba[2]
            axes[0].text(
                column_index, row_index, f"{ratio:.2f}\nn={counts[row_index, column_index]}",
                ha="center", va="center", fontsize=6.8, color="black" if luminance > 0.55 else "white"
            )
            failure = failures[row_index, column_index]
            failure_rgba = plt.get_cmap("viridis")(failure)
            failure_luminance = 0.299 * failure_rgba[0] + 0.587 * failure_rgba[1] + 0.114 * failure_rgba[2]
            axes[1].text(
                column_index, row_index, f"{failure:.0%}", ha="center", va="center", fontsize=7.2,
                color="black" if failure_luminance > 0.55 else "white"
            )

    ratio_bar = fig.colorbar(ratio_image, ax=axes[0], fraction=0.025, pad=0.015)
    ratio_bar.set_label("Concentration ratio")
    failure_bar = fig.colorbar(failure_image, ax=axes[1], fraction=0.025, pad=0.015)
    failure_bar.set_label("Shared-failure rate")
    fig.suptitle("Complete hydrological-context audit across 48 registered joint cells", fontsize=13)
    fig.text(
        0.01, 0.01,
        "Ratios use row-summed positive MAE differences in mm d$^{-1}$; they locate absolute-error advantage and are not scale-free skill scores.",
        fontsize=8,
    )
    fig.tight_layout(rect=[0, 0.035, 1, 0.96])
    fig.savefig(fig_path, dpi=220)
    plt.close(fig)


def _plot_posthoc_cause_diagnostics(tables: Dict[str, pd.DataFrame], fig_path: Path) -> None:
    """Show the common amplitude, event-shape, and forcing-disagreement evidence."""
    values = _posthoc_cause_numbers(tables)
    models = ["LSTM", "GR4J", "Xinanjiang", "HBV-lite"]
    colors = {"LSTM": "#4C78A8", "GR4J": "#F28E2B", "Xinanjiang": "#59A14F", "HBV-lite": "#B07AA1"}
    fig, axes = plt.subplots(2, 2, figsize=(13.2, 9.2))

    x = np.arange(len(models), dtype=float)
    axes[0, 0].bar(
        x - 0.18, [values["correlation"][model] for model in models], width=0.36,
        color="#76B7B2", label="Daily correlation",
    )
    axes[0, 0].bar(
        x + 0.18, [values["standard_deviation_ratio"][model] for model in models], width=0.36,
        color="#E15759", label="Standard-deviation ratio",
    )
    axes[0, 0].axhline(1.0, color="#555555", linestyle="--", linewidth=1.0)
    axes[0, 0].set_xticks(x, models, rotation=15)
    axes[0, 0].set_ylim(0.70, 1.02)
    axes[0, 0].set_ylabel("Basin-median value")
    axes[0, 0].set_title("A  Daily amplitude geometry", loc="left")
    axes[0, 0].legend(frameon=False)
    axes[0, 0].grid(axis="y", alpha=0.2)

    offsets = [-0.18, 0.18]
    for offset, quantile, source, alpha in [
            (offsets[0], "90th-percentile events", "q90_peak_concentration", 0.95),
            (offsets[1], "95th-percentile events", "q95_peak_concentration", 0.60),
    ]:
        axes[0, 1].bar(
            x + offset, [values[source][model] for model in models], width=0.36,
            color=[colors[model] for model in models], alpha=alpha, label=quantile,
        )
    axes[0, 1].axhline(1.0, color="#555555", linestyle="--", linewidth=1.0)
    axes[0, 1].set_xticks(x, models, rotation=15)
    axes[0, 1].set_ylim(0.70, 1.02)
    axes[0, 1].set_ylabel("Median event-peak concentration")
    axes[0, 1].set_title("B  Peak relative to seven-day volume", loc="left")
    axes[0, 1].legend(frameon=False)
    axes[0, 1].grid(axis="y", alpha=0.2)

    pairwise = tables["cause_event_shape_pairwise_summary"]
    q90 = pairwise[np.isclose(pairwise["event_threshold_quantile"], 0.90)].set_index("comparator_model")
    comparators = ["GR4J", "Xinanjiang", "HBV-lite"]
    y = np.arange(len(comparators), dtype=float)
    estimate = q90.loc[comparators, "median_reference_minus_comparator"].to_numpy()
    axes[1, 0].errorbar(
        estimate, y,
        xerr=np.vstack([
            estimate - q90.loc[comparators, "ci_lower"].to_numpy(),
            q90.loc[comparators, "ci_upper"].to_numpy() - estimate,
        ]),
        color="#4C78A8", marker="o", linestyle="none", capsize=4, markersize=7,
    )
    axes[1, 0].axvline(0.0, color="#555555", linestyle="--", linewidth=1.0)
    axes[1, 0].set_yticks(y, comparators)
    axes[1, 0].set_xlabel("LSTM minus conceptual concentration")
    axes[1, 0].set_title("C  Paired basin-median shape contrast", loc="left")
    axes[1, 0].grid(axis="x", alpha=0.2)

    quartiles = np.arange(1, 5)
    for quantile, source, color, marker in [
            (0.90, "q90_forcing_quartile_bias", "#4C78A8", "o"),
            (0.95, "q95_forcing_quartile_bias", "#E15759", "s"),
    ]:
        axes[1, 1].plot(
            quartiles, [values[source][quartile] for quartile in quartiles], color=color,
            marker=marker, linewidth=2.2, label=f"Observed q{int(quantile * 100)} events",
        )
    axes[1, 1].axhline(0.0, color="#555555", linestyle="--", linewidth=1.0)
    axes[1, 1].set_xticks(quartiles, ["Lowest", "Q2", "Q3", "Highest"])
    axes[1, 1].set_xlabel("Within-basin Maurer-minus-consensus precipitation gap")
    axes[1, 1].set_ylabel("Centred four-model median volume bias")
    axes[1, 1].set_title("D  Common error across forcing-gap quartiles", loc="left")
    axes[1, 1].legend(frameon=False)
    axes[1, 1].grid(axis="y", alpha=0.2)

    fig.suptitle("Post-hoc diagnosis of shared amplitude and model-specific event-peak concentration", fontsize=14)
    fig.text(
        0.01, 0.012,
        "Events are observation-defined. Forcing gaps are centred within basin and use three precipitation products; associations do not identify precipitation truth or causal shares.",
        fontsize=8.5,
    )
    fig.tight_layout(rect=[0, 0.04, 1, 0.96])
    fig.savefig(fig_path, dpi=220)
    plt.close(fig)


def _plot_kge_component_diagnosis(tables: Dict[str, pd.DataFrame], fig_path: Path) -> None:
    """Plot overall efficiency, high-flow components, and paired arithmetic attribution."""
    values = _kge_component_numbers(tables)
    models = ["LSTM", "GR4J", "Xinanjiang", "HBV-lite"]
    comparators = ["GR4J", "Xinanjiang", "HBV-lite"]
    colors = {
        "LSTM": "#0072B2",
        "GR4J": "#E69F00",
        "Xinanjiang": "#009E73",
        "HBV-lite": "#CC79A7",
    }
    component_colors = {
        "correlation": "#0072B2",
        "variability": "#E69F00",
        "mean": "#009E73",
    }
    component_labels = {
        "correlation": "Daily correlation",
        "variability": "Variability ratio",
        "mean": "Mean-flow ratio",
    }

    fig, axes = plt.subplots(1, 3, figsize=(15.2, 5.1))
    x_models = np.arange(len(models), dtype=float)
    axes[0].bar(
        x_models,
        [values["median_kge"][model] for model in models],
        color=[colors[model] for model in models],
    )
    axes[0].set_xticks(x_models, models, rotation=18)
    axes[0].set_ylim(0.60, 0.78)
    axes[0].set_ylabel("Basin-median KGE")
    axes[0].set_title("A  Full evaluation period", loc="left")
    axes[0].grid(axis="y", alpha=0.2)

    width = 0.24
    for index, component in enumerate(["correlation", "variability", "mean"]):
        axes[1].bar(
            x_models + (index - 1) * width,
            [values["high_components"][component][model] for model in models],
            width=width,
            color=component_colors[component],
            label=component_labels[component],
        )
    axes[1].axhline(1.0, color="#555555", linestyle="--", linewidth=1.0)
    axes[1].set_xticks(x_models, models, rotation=18)
    axes[1].set_ylim(0.60, 1.02)
    axes[1].set_ylabel("Basin-median component value")
    axes[1].set_title("B  Highest 10% observed-flow days", loc="left")
    axes[1].legend(frameon=False, fontsize=8)
    axes[1].grid(axis="y", alpha=0.2)

    x_comparators = np.arange(len(comparators), dtype=float)
    bottom = np.zeros(len(comparators))
    for component in ["correlation", "variability", "mean"]:
        heights = np.asarray([
            values["high_attribution"][component][model] for model in comparators
        ])
        axes[2].bar(
            x_comparators,
            heights,
            bottom=bottom,
            color=component_colors[component],
            label=component_labels[component],
        )
        bottom += heights
    axes[2].set_xticks(x_comparators, [f"LSTM vs\n{model}" for model in comparators])
    axes[2].set_ylim(0.0, 1.0)
    axes[2].set_ylabel("Fraction of mean KGE difference")
    axes[2].set_title("C  High-flow arithmetic attribution", loc="left")
    axes[2].grid(axis="y", alpha=0.2)

    fig.suptitle("Kling–Gupta efficiency diagnosis of the LSTM high-flow advantage", fontsize=14)
    fig.text(
        0.01,
        0.012,
        "KGE uses the 2009 formulation. Component replacement is an exact arithmetic decomposition, not causal attribution.",
        fontsize=8.5,
    )
    fig.tight_layout(rect=[0, 0.045, 1, 0.95])
    fig.savefig(fig_path, dpi=240)
    plt.close(fig)


def _provenance_ledger(out_dir: Path, protocol: EvidenceProtocol | str | None = None) -> pd.DataFrame:
    evidence = _evidence_paths(protocol)
    sources = _resolve(protocol).provenance_sources()
    command = "python -X utf8 -m src.lstm_fair_531.scripts.build_manuscript_evidence_package"
    pdd_test = PDD_FAIRNESS_TEST.as_posix()
    rows = [
        {
            "claim_id": "C01",
            "paper_element": "Table 1 main benchmark",
            "claim": "Full-531 medians for GR4J, XAJ, HBV, LSTM single, and LSTM ensemble.",
            "artifact": "tables/main_benchmark.csv",
            "source_files": "; ".join(str(path) for path in sources["main_benchmark"]),
            "script_or_command": command,
            "status": "reproducible_from_saved_artifacts",
            "notes": "No model rerun required; reads per-basin metric artifacts.",
        },
        {
            "claim_id": "C02",
            "paper_element": "Table 2 paired comparison",
            "claim": "LSTM ensemble paired deltas, win rates, Wilcoxon p-values, and bootstrap CIs vs conceptual models.",
            "artifact": "tables/paired.csv",
            "source_files": "; ".join(str(path) for path in sources["paired"]),
            "script_or_command": command,
            "status": sources["paired_status"],
            "notes": sources["paired_notes"],
        },
        {
            "claim_id": "C03",
            "paper_element": "Table 3 diagnostic metrics",
            "claim": "Conceptual-model KGE, bias, peak, low-flow, and split-gap diagnostic trade-offs.",
            "artifact": "tables/conceptual_diagnostics.csv",
            "source_files": "; ".join(str(path) for path in sources["conceptual_diagnostics"]),
            "script_or_command": command,
            "status": "reproducible_from_saved_artifacts",
            "notes": "These are conceptual-only summary diagnostics; LSTM residual diagnostics and advantage decomposition are tracked separately in D02-D06.",
        },
        {
            "claim_id": "C04",
            "paper_element": "Table 4 regime analysis",
            "claim": "Regime-wise medians and counts where conceptual models beat the LSTM ensemble.",
            "artifact": "tables/regime_summary.csv",
            "source_files": "; ".join(str(path) for path in sources["regime"]),
            "script_or_command": command,
            "status": "reproducible_from_saved_artifacts",
            "notes": "Regime labels come from the existing diagnostic file.",
        },
        {
            "claim_id": "C05",
            "paper_element": "Figure 1 NSE CDF",
            "claim": "NSE distribution contrast across conceptual models and LSTM references.",
            "artifact": "figures/fig1_nse_cdf.png",
            "source_files": "Same as C01",
            "script_or_command": command,
            "status": "reproducible_from_saved_artifacts",
            "notes": "Generated with matplotlib Agg.",
        },
        {
            "claim_id": "C06",
            "paper_element": "Stale-reference audit",
            "claim": "Known stale PET-bug and HBV-v7 references are excluded from active snapshot sources.",
            "artifact": "audit/stale_reference_audit.csv",
            "source_files": "; ".join(path.as_posix() for path in ACTIVE_STALE_SCAN_PATHS),
            "script_or_command": command,
            "status": "reproducible_active_snapshot_scan",
            "notes": "The scan is intentionally limited to active snapshot sources so unrelated working-tree files cannot change package hashes.",
        },
        {
            "claim_id": "C07",
            "paper_element": "Parameter accounting table",
            "claim": "Conceptual-model parameter counts distinguish nominal from effective active parameters.",
            "artifact": "tables/parameter_accounting.csv",
            "source_files": "src/xaj_global_pilot/gr4j_core.py; src/xaj_global_pilot/xaj_model.py; src/scl_hydro/hbv_lite_numpy.py",
            "script_or_command": command,
            "status": "reproducible_from_code_audit",
            "notes": "XAJ has 20 nominal parameters but 18 effective active parameters under zero initial ice.",
        },
        {
            "claim_id": "C08",
            "paper_element": "Fairness audit table",
            "claim": "External snow-module and calibration-protocol fairness checks are classified and linked to tests/code.",
            "artifact": "tables/fairness_audit.csv",
            "source_files": f"{pdd_test}; conceptual runners; calibration modules",
            "script_or_command": command,
            "status": "reproducible_from_tests_and_code_audit",
            "notes": "Run pytest test/test_id10_pdd_fairness.py -q before relying on the effective-equivalence claim.",
        },
        {
            "claim_id": "C09",
            "paper_element": "Manuscript-ready claim map",
            "claim": "Each manuscript claim is tied to evidence, allowed wording, and a boundary condition.",
            "artifact": "manuscript_ready_claim_map.md",
            "source_files": "tables/main_benchmark.csv; tables/paired.csv; tables/oracle.csv; tables/fairness_audit.csv",
            "script_or_command": command,
            "status": "reproducible_from_saved_artifacts",
            "notes": "Use this file to keep the abstract, results, and discussion from overclaiming.",
        },
        {
            "claim_id": "C10",
            "paper_element": "Methods/Results/Limitations section draft",
            "claim": "Paper-ready section prose reflects benchmark results and fairness boundaries.",
            "artifact": "manuscript_sections.md",
            "source_files": "tables/main_benchmark.csv; tables/paired.csv; tables/conceptual_diagnostics.csv; tables/regime_summary.csv; tables/oracle.csv",
            "script_or_command": command,
            "status": "reproducible_from_saved_artifacts",
            "notes": "Draft prose is evidence-grounded but still needs final manuscript integration and citations.",
        },
        {
            "claim_id": "C11",
            "paper_element": "Figure/table captions and reviewer-risk checklist",
            "claim": "Captions and risk checklist encode the intended claim boundaries for submission.",
            "artifact": "figure_table_captions.md; reviewer_risk_checklist.md",
            "source_files": "MANIFEST.json; tables/fairness_audit.csv; tables/parameter_accounting.csv; claims_limitations.md",
            "script_or_command": command,
            "status": "reproducible_from_package_state",
            "notes": "Use the risk checklist before every manuscript export.",
        },
        {
            "claim_id": "C12",
            "paper_element": "Final submission readiness memo",
            "claim": "The package is ready for paper drafting and internal pre-submission review, with residual risks stated.",
            "artifact": "final_submission_readiness_memo.md",
            "source_files": "MANIFEST.json; tables/main_benchmark.csv; tables/oracle.csv; audit/stale_reference_audit.csv",
            "script_or_command": command,
            "status": "reproducible_from_package_state",
            "notes": "The memo distinguishes manuscript-ready evidence from a fully typeset journal submission.",
        },
        {
            "claim_id": "C13",
            "paper_element": "Saved-parameter replay audit",
            "claim": "Final GR4J/XAJ/HBV saved parameter artifacts replay under the current code for all 531 basins.",
            "artifact": (REPLAY_AUDIT_REL / "saved_parameter_replay_summary.csv").as_posix(),
            "source_files": "; ".join(str(path) for path in CONCEPTUAL_FILES.values()),
            "script_or_command": REPLAY_AUDIT_COMMAND,
            "status": "reproducible_forward_replay_from_saved_parameters",
            "notes": "This validates artifact continuity after code changes; it is not a full CMA-ES recalibration.",
        },
        {
            "claim_id": "C14",
            "paper_element": "D01 basin-attribute diagnostic deep dive",
            "claim": "Static CAMELS attributes explain part of the conceptual-structure disagreements and the LSTM margin over the basin-wise highest-NSE conceptual comparator.",
            "artifact": evidence["spearman"],
            "source_files": "tables/per_basin_combined_nse.csv; data/camels_us/camels_attributes_v2.0",
            "script_or_command": "python -X utf8 -m src.lstm_fair_531.scripts.deep_dive_structure_diagnostics",
            "status": "reproducible_posthoc_diagnostic",
            "notes": "Primary claims exclude streamflow-derived camels_hydro; hydro signatures are supplemental only.",
        },
        {
            "claim_id": "C15",
            "paper_element": "D02 seasonal residual diagnostic deep dive",
            "claim": "Representative case hydrographs show seasonal and high-flow residual patterns consistent with the snow/aridity diagnostic signals.",
            "artifact": (D02_DEEP_DIVE_REL / "tables" / "seasonal_delta_aggregate.csv").as_posix(),
            "source_files": (D01_DEEP_DIVE_REL / "tables" / "case_basin_list.csv").as_posix(),
            "script_or_command": "python -X utf8 -m src.lstm_fair_531.scripts.seasonal_residual_deep_dive",
            "status": "reproducible_selected_case_diagnostic",
            "notes": "Selected cases are diagnostic examples, not population-wide residual estimates.",
        },
        {
            "claim_id": "C16",
            "paper_element": "D03 snow-population seasonal residual diagnostic",
            "claim": "Across all 152 snow-dominated basins, MAM and high-flow residual penalties relative to the LSTM remain population-wide.",
            "artifact": (D03_DEEP_DIVE_REL / "tables" / "seasonal_delta_aggregate.csv").as_posix(),
            "source_files": (D01_DEEP_DIVE_REL / "tables" / "basin_attribute_panel.csv").as_posix(),
            "script_or_command": "python -X utf8 -m src.lstm_fair_531.scripts.seasonal_residual_deep_dive --population snow --max-basins 0",
            "status": "reproducible_population_diagnostic",
            "notes": "Post-hoc residual diagnosis only; daily NSE reaggregation check reproduces D01 basin NSE within 5e-7.",
        },
        {
            "claim_id": "C17",
            "paper_element": "D04 full-population residual attribute review",
            "claim": "Full-531 seasonal/high-flow residual targets align with D01 snow, topography, aridity, conceptual-spread, and LSTM-gap axes.",
            "artifact": evidence["seasonal_links"],
            "source_files": (D01_DEEP_DIVE_REL / "tables" / "basin_attribute_panel.csv").as_posix(),
            "script_or_command": "python -X utf8 -m src.lstm_fair_531.scripts.population_residual_attribute_review",
            "status": "reproducible_population_attribute_review",
            "notes": "Uses D01 primary/static attributes only; no camels_hydro attributes are used.",
        },
        {
            "claim_id": "C18",
            "paper_element": "D05 LSTM advantage decomposition",
            "claim": "Snow-dominated MAM and high-flow contexts overcontribute to the positive LSTM-vs-best-conceptual MAE gap.",
            "artifact": (D05_DEEP_DIVE_REL / "tables" / "top_advantage_contexts.csv").as_posix(),
            "source_files": (
                (D04_DEEP_DIVE_REL / "tables" / "conceptual_vs_lstm_by_case_season.csv").as_posix() + "; " +
                (D04_DEEP_DIVE_REL / "tables" / "conceptual_vs_lstm_by_case_flow_group.csv").as_posix()
            ),
            "script_or_command": "python -X utf8 -m src.lstm_fair_531.scripts.lstm_advantage_decomposition",
            "status": "reproducible_population_advantage_decomposition",
            "notes": "Uses generated D04 delta artifacts; headline uses MAE best-gap concentration because low-flow NSE can be unstable.",
        },
        {
            "claim_id": "C19",
            "paper_element": "D06 joint season-flow LSTM advantage decomposition",
            "claim": "The strongest joint LSTM advantage concentration is snow-dominated MAM high-flow contexts.",
            "artifact": (D06_DEEP_DIVE_REL / "tables" / "top_joint_advantage_contexts.csv").as_posix(),
            "source_files": (D04_DEEP_DIVE_REL / "tables" / "daily_residuals_selected_cases.csv.gz").as_posix(),
            "script_or_command": "python -X utf8 -m src.lstm_fair_531.scripts.joint_advantage_decomposition",
            "status": "reproducible_joint_population_advantage_decomposition",
            "notes": "Post-hoc residual decomposition only; does not claim causal event attribution or LSTM process realism.",
        },
        {
            "claim_id": "C20",
            "paper_element": "Table 7 compact LSTM advantage concentration",
            "claim": "Three headline contexts map context share to positive best-gap share, concentration ratio, and shared failure rate.",
            "artifact": "tables/lstm_advantage_concentration.csv",
            "source_files": "; ".join([
                evidence["season"], evidence["flow"], evidence["joint"],
            ]),
            "script_or_command": command,
            "status": "reproducible_from_saved_decomposition_artifacts",
            "notes": "This table is a compact manuscript view of D05/D06 values and does not add a new model-selection result.",
        },
        {
            "claim_id": "C21",
            "paper_element": "Complete English manuscript draft",
            "claim": "A complete manuscript integrates the benchmark boundary, central decomposition, population support, joint refinement, limitations, and traceability notes.",
            "artifact": "manuscript_full_draft.md",
            "source_files": (
                "tables/protocol.csv; tables/parameter_accounting.csv; tables/main_benchmark.csv; "
                "tables/paired.csv; tables/conceptual_diagnostics.csv; tables/regime_summary.csv; tables/oracle.csv; "
                "tables/lstm_advantage_concentration.csv; tables/protocol_robustness.csv; " + "; ".join([
                    evidence["spearman"], evidence["seasonal_links"], evidence["flow_links"],
                    evidence["season"], evidence["flow"], evidence["joint"],
                ]) + "; manuscript_ready_claim_map.md"
            ),
            "script_or_command": command,
            "status": "generated_from_saved_evidence_artifacts",
            "notes": "Neutral journal-style Markdown draft; reference entries remain source notes rather than venue-formatted bibliography entries.",
        },
        {
            "claim_id": "C22",
            "paper_element": "Three-step key-point argument chain",
            "claim": "Three key points compress one contribution into concentration, population support, and joint-context refinement.",
            "artifact": "key_points.md",
            "source_files": (
                "tables/lstm_advantage_concentration.csv; " + "; ".join([
                    evidence["spearman"], evidence["seasonal_links"], evidence["flow_links"],
                    evidence["season"], evidence["flow"], evidence["joint"],
                ])
            ),
            "script_or_command": command,
            "status": "generated_from_saved_evidence_artifacts",
            "notes": "The points are one argument at three compression steps, not separate novelty claims.",
        },
        {
            "claim_id": "C23",
            "paper_element": "Complete 48-cell joint context audit",
            "claim": "The complete regime-season-flow matrix shows concentration and shared failure without selecting only the maximum cells.",
            "artifact": "figures/fig5_joint_context_heterogeneity.png",
            "source_files": "; ".join([evidence["season"], evidence["flow"], evidence["joint"]]),
            "script_or_command": command,
            "status": "generated_from_complete_registered_context_matrices",
            "notes": (
                "Descriptive evaluation-period audit; absolute concentration is not scale-free, and the later seasonal contrast family is explicitly post-hoc rather than causal or confirmatory."
            ),
        },
    ]
    if _resolve(protocol).protocol_id == IDENTICAL_PROTOCOL_ID:
        rows.extend([
            {
                "claim_id": "C24",
                "paper_element": "Scale and threshold robustness",
                "claim": "Absolute-error reduction and dimensionless relative advantage have distinct flow-group hierarchies across three fixed threshold arms.",
                "artifact": "tables/context_scale_threshold_summary.csv; figures/fig6_scale_threshold_robustness.png",
                "source_files": f"{_D07_ROOT}/context_scale_threshold_summary.csv; {_D07_ROOT}/D07_manifest.json",
                "script_or_command": "python -X utf8 -m src.lstm_fair_531.scripts.run_context_scale_threshold_robustness",
                "status": "generated_from_registered_D07_outputs",
                "notes": "No new model; post-hoc analysis of saved common-protocol daily predictions.",
            },
            {
                "claim_id": "C25",
                "paper_element": "Whole-basin uncertainty and fixed contrasts",
                "claim": "Snow-regime and snow-high seasonal contrasts use whole-basin clustered intervals with fixed families and Holm adjustment.",
                "artifact": "tables/context_scale_threshold_intervals.csv; tables/context_scale_contrasts.csv",
                "source_files": f"{_D07_ROOT}/bootstrap_concentration_intervals.csv; {_D07_ROOT}/fixed_contrasts.csv; {_D07_ROOT}/thresholds",
                "script_or_command": "python -X utf8 -m src.lstm_fair_531.scripts.run_context_scale_threshold_robustness",
                "status": "generated_from_registered_D07_outputs_and_archived_row_deltas",
                "notes": "Seasonal ordering is explicitly post-hoc rather than prospective confirmation.",
            },
            {
                "claim_id": "C26",
                "paper_element": "Complete benchmark-protocol stability",
                "claim": "All 16 regime-season, 12 regime-flow, 48 joint, and 39 primary-attribute rows are compared across protocols.",
                "artifact": "tables/protocol_matrix_stability.csv; tables/protocol_matrix_cell_deltas.csv",
                "source_files": f"{_D08_ROOT}/protocol_matrix_stability_summary.csv; {_D08_ROOT}/protocol_matrix_cell_deltas.csv; {_D08_ROOT}/D08_manifest.json",
                "script_or_command": "python -X utf8 -m src.lstm_fair_531.scripts.full_protocol_matrix_stability",
                "status": "generated_from_complete_registered_protocol_matrices",
                "notes": "Whole benchmark rebuild; not a training-objective ablation.",
            },
            {
                "claim_id": "C27",
                "paper_element": "Hydrological flow-duration and observed-event diagnostics",
                "claim": "All four models attenuate upper-flow variability; event alignment does not remove peak-magnitude or volume deficits, and the universal snow-specific gate is unsupported.",
                "artifact": "tables/hydrological_flow_bias_summary.csv; tables/hydrological_event_summary.csv; tables/hydrological_decision_gates.csv; figures/fig7_hydrological_process_diagnostics.png",
                "source_files": f"{_D09_ROOT}/regime_model_bias_summary.csv; {_D09_ROOT}/regime_season_event_summary.csv; {_D09_ROOT}/diagnostic_decision_gates.json; {_D09_ROOT}/D09_manifest.json; {_D09_ROOT}/D09_independent_audit.json",
                "script_or_command": "python -X utf8 -m src.lstm_fair_531.scripts.run_hydrological_process_diagnostics --output-dir results/18_lstm_fair_531/D09_hydrological_process_diagnostics_20260726_attempt2",
                "status": "independently_recomputed_from_registered_daily_predictions",
                "notes": "No new rainfall-runoff model; both fixed extension gates failed, so no conditional mechanism experiment was run.",
            },
            {
                "claim_id": "C28",
                "paper_element": "Post-hoc cause diagnosis",
                "claim": "Shared amplitude compression is separated from model-dependent event-peak concentration differences and weak precipitation-product disagreement association without assigning causal shares.",
                "artifact": "tables/cause_amplitude_geometry_summary.csv; tables/cause_event_shape_summary.csv; tables/cause_event_shape_pairwise_summary.csv; tables/cause_forcing_disagreement_summary.csv; figures/fig8_posthoc_cause_diagnostics.png",
                "source_files": f"{_D10_ROOT}/amplitude_geometry_summary.csv; {_D10_ROOT}/event_shape_summary.csv; {_D10_ROOT}/event_shape_pairwise_summary.csv; {_D10_ROOT}/forcing_disagreement_summary.csv; {_D10_ROOT}/D10_manifest.json; {_D10_ROOT}/D10_independent_audit.json",
                "script_or_command": "python -X utf8 -m src.lstm_fair_531.scripts.run_posthoc_cause_diagnostics",
                "status": "independently_recomputed_from_registered_predictions_events_and_forcing_products",
                "notes": "Exploratory evaluation-period diagnosis; does not reopen failed D09 branches, identify forcing truth, or quantify causal shares.",
            },
            {
                "claim_id": "C29",
                "paper_element": "Kling-Gupta efficiency component diagnosis",
                "claim": (
                    "The high-flow LSTM advantage is mainly associated with stronger daily "
                    "correlation and less variability compression."
                ),
                "artifact": (
                    "tables/kge_component_summary.csv; tables/kge_paired_attribution_summary.csv; "
                    "figures/fig9_kge_component_diagnosis.png"
                ),
                "source_files": (
                    f"{_D11_ROOT}/kge_component_summary.csv; "
                    f"{_D11_ROOT}/kge_paired_attribution_summary.csv; "
                    f"{_D11_ROOT}/D11_manifest.json; {_D11_ROOT}/D11_independent_audit.json"
                ),
                "script_or_command": (
                    "python -X utf8 -m src.lstm_fair_531.scripts.run_kge_component_diagnostics"
                ),
                "status": "independently_recomputed_from_registered_daily_predictions",
                "notes": (
                    "Exact arithmetic attribution only; no causal process, correct-timing, snowmelt-physics, "
                    "or low-flow KGE mechanism claim."
                ),
            },
            {
                "claim_id": "C30",
                "paper_element": "Supplementary LSTM configuration provenance",
                "claim": (
                    "All eight registered neural configurations use the same optimization-target and "
                    "evaluation periods and differ only in run-identity fields."
                ),
                "artifact": "tables/lstm_registered_config_provenance.csv",
                "source_files": "; ".join(
                    (
                        REGISTERED_LSTM_CONFIG_ROOT / f"seed_{seed}" / "config.yml"
                    ).as_posix()
                    for seed in REGISTERED_LSTM_SEEDS
                ),
                "script_or_command": command,
                "status": "verified_from_eight_registered_seed_configurations",
                "notes": (
                    "The supplementary table records each path and SHA-256 digest. The configurations "
                    "do not register separate validation dates."
                ),
            },
            {
                "claim_id": "C31",
                "paper_element": "Day-weighted flow accounting",
                "claim": "Row-equal shares measure the per-day error-reduction rate; day-weighted shares measure accumulated millimetres, under which high-flow days carry 2.6 times their share of days.",
                "artifact": "tables/flow_day_weighted_summary.csv",
                "source_files": "results/18_lstm_fair_531/R02_identical_basin_nse_531/analysis_key_points_20260724/D04_population_r02/tables/conceptual_vs_lstm_by_case_flow_group.csv",
                "script_or_command": "python -X utf8 -m src.lstm_fair_531.scripts.build_manuscript_evidence_package",
                "status": "computed_from_registered_r02_row_level_contexts",
                "notes": "Both accountings are reported side by side; the flow-group context share is fixed near one third by construction, so only the day-based denominator carries information about time coverage.",
            },
        ])
    ledger = pd.DataFrame(rows)
    ledger.to_csv(out_dir / "provenance_ledger.csv", index=False)
    (out_dir / "provenance_ledger.md").write_text(_to_md_table(ledger) + "\n", encoding="utf-8")
    return ledger


def _write_claims(out_dir: Path, tables: Dict[str, pd.DataFrame], protocol: EvidenceProtocol | str | None = None) -> None:
    main = tables["main_benchmark"].set_index("model")
    oracle = tables["oracle"].set_index("quantity")["value"]
    adv = _advantage_numbers(out_dir, protocol)
    population = _population_support_numbers(out_dir, protocol)
    heterogeneity = _context_heterogeneity_summary(out_dir, protocol)
    robustness = _robustness_manuscript_blocks(tables)
    text = f"""# Manuscript skeleton and claim map

## Working title

Sensitivity of Flow Variability Compression, Daily Correlation, and Event Shape to the Calibration Objective in an LSTM and Three Conceptual Rainfall-Runoff Models Across 531 United States Basins

## One-sentence contribution

Aggregate scores hide how a predictive margin is distributed; three audited conceptual structures locate where the LSTM advantage concentrates across hydrological regime, season, and flow context.

## Abstract skeleton

Aggregate rainfall-runoff performance scores rank models but do not show whether a predictive advantage is diffuse or concentrated in particular hydrological contexts. We quantify that distribution across 531 CAMELS-US basins using GR4J, XAJ, and HBV as structural references to a reproduced eight-seed LSTM ensemble. The LSTM uses regional learning and 27 static basin attributes, so the comparison is diagnostic rather than a same-information prediction contest; the conceptual structures are not predictive competitors. Its median NSE is {main.loc['LSTM_ensemble_8seed', 'median_nse']:.6f}, compared with {main.loc['GR4J', 'median_nse']:.6f} for the strongest single conceptual model, GR4J. Snow-dominated MAM contexts represent {adv['snow_mam_context_share']:.1%} of basin-season rows but {adv['snow_mam_gap_share']:.1%} of the positive gap relative to the lowest-error conceptual model in each row; snow-dominated high-flow contexts represent {adv['snow_high_context_share']:.1%} of basin-flow rows but {adv['snow_high_gap_share']:.1%} of that gap. Across all 531 basins, snow fraction is positively associated with the LSTM margin over the basin-wise conceptual comparator with the highest NSE (rho = {population['basin_snow_rho']:.3f}, q = {population['basin_snow_q']:.2e}). Snow-dominated MAM high flow is the retained joint context with the highest concentration ratio: {adv['snow_mam_high_context_share']:.1%} of joint rows account for {adv['snow_mam_high_gap_share']:.1%} of the positive gap, and all three evaluated conceptual models have higher mean absolute error in {adv['snow_mam_high_shared_failure']:.1%} of those rows. The result is a post-hoc diagnosis of where the known ranking accumulates, not evidence of causal mechanism, process realism, or deployable predictive complementarity.
{robustness['abstract']}


## Results narrative

Boundary. The LSTM ensemble is the strongest evaluated predictive reference: median NSE {main.loc['LSTM_ensemble_8seed', 'median_nse']:.6f}, compared with GR4J at {main.loc['GR4J', 'median_nse']:.6f}, XAJ at {main.loc['XAJ', 'median_nse']:.6f}, and HBV at {main.loc['HBV', 'median_nse']:.6f}. A four-model oracle reaches median NSE {oracle.loc['four_model_oracle_median_nse']:.6f} with median gain {oracle.loc['four_model_oracle_minus_lstm_median']:.6f} over the LSTM ensemble, so this is not a predictive-complement paper.

Complete-matrix audit. The evidence covers 16 regime-season, 12 regime-flow, and 48 joint cells. High flow contributes {heterogeneity['flow']['high']['positive_best_gap_share']:.1%} of the row-summed positive absolute-error gap from {heterogeneity['flow']['high']['context_share']:.1%} of basin-flow contexts; every low-flow regime cell is below proportional concentration. Snow-dominated high-flow concentration persists in all four seasons, with spring and winter the two largest descriptive cells.
Scale and protocol audit. {robustness['abstract']}


1. LSTM advantage is not uniform: snow-dominated MAM contexts account for {adv['snow_mam_context_share']:.1%} of basin-season contexts but {adv['snow_mam_gap_share']:.1%} of the positive gap relative to the lowest-error conceptual model in each row; snow-dominated high-flow contexts account for {adv['snow_high_context_share']:.1%} of basin-flow contexts but {adv['snow_high_gap_share']:.1%} of the positive gap.
2. Across all 531 basins, snow fraction is positively associated with the LSTM margin over the basin-wise conceptual comparator with the highest NSE (rho = {population['basin_snow_rho']:.3f}, q = {population['basin_snow_q']:.2e}), supporting a population-level rather than selected-case pattern.
3. Snow-dominated MAM high flow is the retained joint context with the highest concentration ratio: {adv['snow_mam_high_context_share']:.1%} of basin-season-flow contexts account for {adv['snow_mam_high_gap_share']:.1%} of the positive row-wise gap, with concentration ratio {adv['snow_mam_high_ratio']:.2f}; all three conceptual models have higher MAE in {adv['snow_mam_high_shared_failure']:.3f} of rows.

## Claims that are supported

- The ID10/ID18 package provides a protocol-audited conceptual benchmark relative to a reproduced LSTM reference.
- GR4J is the strongest single conceptual model under the final 5k x 3 PT same-protocol headline.
- The LSTM ensemble is the strongest evaluated predictor in this setup.
- High flow dominates the per-day absolute-error margin, while middle flow has the largest dimensionless relative concentration and shared-failure consistency.
- Snow-dominated basins show a broader relative advantage across low, middle, and high flow; this is associational rather than a snow-process attribution.
- The complete context hierarchy remains rank-stable after the whole benchmark rebuild under the common protocol.
- Agreement across GR4J/XAJ/HBV errors can be used to locate the LSTM margin relative to the lowest-error conceptual comparator in each row.
- D06 identifies snow-dominated MAM high-flow as the strongest current joint advantage concentration zone.
- GR4J/XAJ external PDD snow handling is effective-equivalent under the current zero-ice CAMELS-US setup; XAJ should be reported as 20 nominal and 18 effective active parameters.
- The saved conceptual parameter artifacts replay under the current code across all 531 basins; this supports artifact continuity after fairness-related code cleanup.
- D01-D06 deep dives make the diagnostic decomposition concrete: static snow/topography/aridity attributes align with model-structure disagreements, D03/D04 show population residual penalties, and D05/D06 show that a small snow-dominated MAM high-flow context overcontributes to the LSTM advantage.

## Claims that are not supported

- Do not claim a new predictive state of the art.
- Do not claim conceptual models are competitive with the LSTM ensemble overall.
- Do not claim conceptual models complement LSTM prediction deployably.
- Do not claim causal event attribution or LSTM process realism from D05/D06.
- Do not infer XAJ superiority over HBV from their median ordering alone; no equivalence or superiority test was specified.
- Do not claim PET-bug correction is a method gain.
- Do not mix 447-subset Kratzert reproduction numbers with full-531 headline rankings.
- Do not imply strict information equality: the LSTM uses regional learning and static attributes.
- Do not describe HBV as using the same external PDD front end; its snow routine is intrinsic HBV structure.

## Submission readiness

The core benchmark and decomposition claims are auditable from the registered snapshot. {_snapshot_input_count_phrase()} are pinned by byte size and SHA-256 digest and packaged in a single content-pinned local external archive. The committed clean checkout rebuilds the package after that archive is extracted. The committed clean checkout has been verified by rebuilding all 14 top-level outputs twice with zero digest differences. Old PET-bug diagnostics are quarantined and must not be reused as manuscript evidence. Submission still requires venue formatting, a finalized bibliography, and publication of the registered external archive.
"""
    (out_dir / "manuscript_skeleton.md").write_text(text, encoding="utf-8")


def _write_claims_limitations(out_dir: Path, tables: Dict[str, pd.DataFrame]) -> None:
    text = """# Claims and limitations

## Supported claims

- The package provides a protocol-audited CAMELS-US 531 conceptual benchmark relative to a reproduced LSTM reference.
- GR4J is the strongest conceptual model under the final PT 5k x 3 same-protocol headline.
- The LSTM ensemble is the strongest evaluated predictor in the current setup.
- Conceptual models can be used as structure-reference probes to decompose where the LSTM advantage concentrates.
- The complete context matrices support a scale-dependent hierarchy: high flow dominates the per-day absolute-error margin, while middle flow has the largest dimensionless relative concentration and shared-failure consistency.
- Snow-dominated basins have a larger median dimensionless relative advantage than pooled non-snow basins across low, middle, and high flow under all three fixed threshold arms.
- The complete 16-, 12-, and 48-cell context hierarchy remains strongly rank-stable after the whole benchmark is rebuilt under the common protocol.
- D05/D06 show that snow-dominated MAM high flow is the retained joint context with the highest concentration ratio.
- GR4J/XAJ external snow front ends are effective-equivalent under zero initial ice, as tested by `test/test_id10_pdd_fairness.py`.
- XAJ has 20 nominal parameters but 18 effective active parameters in the current zero-ice setup.
- HBV-lite snow handling is intrinsic HBV structure, not the shared external PDD wrapper.
- Saved GR4J/XAJ/HBV parameter artifacts replay under the current code for all 531 basins in both saved-state and warmup-recomputed modes.
- D01 static-attribute diagnostics support a correlational structure-regime claim; D02 selected-case hydrographs provide time-series illustrations of residual patterns; D03/D04 population residual diagnostics show that MAM/high-flow penalties and attribute links persist beyond selected cases; D05/D06 localize the LSTM advantage into season-flow contexts.

## Unsupported claims

- Do not claim a new predictive state of the art.
- Do not claim conceptual models are competitive with the LSTM ensemble overall.
- Do not claim conceptual models provide a deployable predictive complement to LSTM.
- Do not claim D05/D06 prove causal event mechanisms or LSTM process realism.
- Do not infer XAJ superiority over HBV from their median ordering alone; no equivalence or superiority test was specified.
- Do not present the PET-bug correction as a method gain.
- Do not mix 447-subset Kratzert reproduction numbers with full-531 headline rankings.
- Do not imply strict information equality between conceptual models and LSTM; the LSTM uses regional learning and static attributes.
- Do not describe all three conceptual models as sharing one identical snow module.
- Do not present the post-hoc snow-high seasonal ordering as a preregistered confirmatory hypothesis or causal process result.
- Do not interpret raw-MAE high-flow concentration as scale-free high-flow skill; the separate dimensionless analysis gives middle flow the largest relative concentration.
- Do not interpret 39 bivariate, covarying attribute associations as independent effects.
- Do not call the observed low-flow quantile group baseflow.
- Do not compare nominal parameter counts without also reporting effective active parameter counts.

## Boundary conditions

- Full-531 LSTM headline diagnostics remain NSE-based in the main benchmark, while D02-D06 use saved daily LSTM test predictions or generated D04 residual artifacts for post-hoc seasonal/high-flow and advantage-decomposition checks.
- Conceptual diagnostic metrics are valid for comparing GR4J/XAJ/HBV; LSTM residual checks are post-hoc diagnostics, not proof of LSTM process realism.
- GR4J and XAJ external PDD modules are controlled as effective-equivalent; HBV is included as a different conceptual school with an intrinsic degree-day snow routine.
- The stale PET-bug regime diagnostic is quarantined and must not be reused as manuscript evidence.
- Concentration ratio must be read with shared failure or median gap because it sums only positive row-wise gaps.
- Snow fraction participates in regime definition; the categorical regime and continuous snow association are not independent replications.
- The full 48-cell joint matrix is a post-hoc evaluation-period audit, not a pre-specified hypothesis test or deployment rule.
- The three threshold arms reuse the same 531 basins and are sensitivity definitions, not independent replications.
- Whole-basin intervals and Holm adjustment quantify post-hoc uncertainty; they do not change the evaluation-period analysis into prospective confirmation.
- The protocol comparison rebuilds the neural objective, scoring observations, and conceptual calibrations together; it is not a training-objective ablation.
- Saved-parameter replay is an artifact-validity audit, not a fresh full CMA-ES recalibration.
"""

    if "context_scale_threshold_summary" not in tables:
        common_protocol_only = (
            "- The complete context matrices support a scale-dependent hierarchy:",
            "- Snow-dominated basins have a larger median dimensionless relative advantage",
            "- The complete 16-, 12-, and 48-cell context hierarchy remains strongly rank-stable",
            "- Do not present the post-hoc snow-high seasonal ordering",
            "- Do not interpret raw-MAE high-flow concentration as scale-free high-flow skill",
            "- The three threshold arms reuse the same 531 basins",
            "- Whole-basin intervals and Holm adjustment quantify post-hoc uncertainty",
            "- The protocol comparison rebuilds the neural objective",
        )
        text = "\n".join(
            line for line in text.splitlines()
            if not line.startswith(common_protocol_only)
        ) + "\n"
    (out_dir / "claims_limitations.md").write_text(text, encoding="utf-8")


def _write_fairness_audit_memo(out_dir: Path) -> None:
    pdd_test = PDD_FAIRNESS_TEST.as_posix()
    text = f"""# Structure and calibration fairness audit

## Verdict

Under the documented 531-basin split, forcing, calibration budget, and snow-module distinctions, the package supports comparison of the three conceptual models as structure references. GR4J and XAJ external PDD front ends match on the tested zero-ice input sequences. HBV-lite keeps an intrinsic HBV snow routine; this is a disclosed model-structure difference, not a shared external module. These checks do not establish identical model structures or information channels.

## Structure fairness

- GR4J+PDD uses the shared no-ice PDD reference path with 4 active snow parameters.
- XAJ+PDD keeps the historical 6-parameter full PDD wrapper, but the two ice parameters are inactive because ice storage starts at zero and no process creates ice storage.
- HBV-lite uses internal snow states and parameters (`SNOWPACK`, `MELTWATER`, `parTT`, `parCFMAX`, `parCFR`, `parCWH`). It should be described as an HBV-family structural choice.

## Calibration fairness

- The final conceptual headline uses the same 531-basin repro_v01 split, Maurer forcing, PT PET, warmup-year evaluation initialization, NSE metric, and CMA-ES budget.
- The optimizer policy is aligned: 5000 trials x 3 restarts, seeds `42 + 1000 * restart`, normalized box search, init mean 0.5, sigma 0.3, and best calibration objective retained.
- Bounds and structural constraints remain model-specific and must be disclosed as such.

## Fixed or controlled issues

- Added a shared `pdd_noice_step_mm` reference implementation.
- Added `{pdd_test}` to check GR4J/XAJ external snow front-end agreement on explicit zero-ice sequences and XAJ ice-parameter inactivity on those sequences.
- Added nominal/effective parameter accounting to the evidence package.
- Added the full-531 saved-parameter replay audit (`{REPLAY_AUDIT_REL.as_posix()}`) to verify the final parameter artifacts still reproduce the headline NSE table under the current code.
- Added future-run metadata fields for `parameter_count` and `effective_active_parameter_count` in GR4J/XAJ/HBV conceptual runners.

## Manuscript wording rule

Do not write that all three conceptual models share an identical snow module. The correct wording is: GR4J and XAJ external snow front ends are controlled as effective-equivalent under zero initial ice; HBV snow handling is intrinsic to the HBV-lite model structure.
"""
    (out_dir / "fairness_audit_memo.md").write_text(text, encoding="utf-8")


def _write_manuscript_claim_map(out_dir: Path, tables: Dict[str, pd.DataFrame], protocol: EvidenceProtocol | str | None = None) -> None:
    evidence = _evidence_paths(protocol)
    main = tables["main_benchmark"].set_index("model")
    paired = tables["paired"].set_index("comparison")
    oracle = tables["oracle"].set_index("quantity")["value"]
    adv = _advantage_numbers(out_dir, protocol)
    heterogeneity = _context_heterogeneity_summary(out_dir, protocol)
    rows = [
        {
            "id": "M1",
            "manuscript_claim": "The study provides a protocol-audited three-school conceptual benchmark on CAMELS-US 531.",
            "primary_evidence": "tables/protocol.csv; tables/fairness_audit.csv; provenance_ledger.csv",
            "allowed_wording": "protocol-audited conceptual benchmark",
            "boundary": "Do not claim all model structures or information channels are identical.",
        },
        {
            "id": "M2",
            "manuscript_claim": "The reproduced LSTM ensemble is the strongest evaluated predictor in this setup.",
            "primary_evidence": (
                f"tables/main_benchmark.csv: LSTM ensemble median NSE {main.loc['LSTM_ensemble_8seed', 'median_nse']:.6f}; "
                f"paired median delta vs GR4J {paired.loc['LSTM_ensemble_8seed_vs_GR4J', 'median_diff']:.6f}"
            ),
            "allowed_wording": "LSTM remains the strongest evaluated predictive reference",
            "boundary": "Do not claim a new state of the art; do not imply strict information equality with conceptual models.",
        },
        {
            "id": "M3",
            "manuscript_claim": "GR4J is the strongest conceptual model under the final PT 5k x 3 headline.",
            "primary_evidence": (
                f"tables/main_benchmark.csv: GR4J {main.loc['GR4J', 'median_nse']:.6f}, "
                f"XAJ {main.loc['XAJ', 'median_nse']:.6f}, HBV {main.loc['HBV', 'median_nse']:.6f}"
            ),
            "allowed_wording": "GR4J is strongest overall among the three conceptual models",
            "boundary": (
                "Do not infer XAJ superiority over HBV from their median ordering alone; "
                "no equivalence or superiority test was specified."
            ),
        },
        {
            "id": "M4",
            "manuscript_claim": "Conceptual models retain diagnostic value through flow-signature trade-offs.",
            "primary_evidence": "tables/conceptual_diagnostics.csv; tables/conceptual_winners.csv; figures/fig3_conceptual_diagnostic_tradeoffs.png",
            "allowed_wording": "diagnostic trade-offs across KGE, bias, peak, low-flow, and split-gap metrics",
            "boundary": "Do not infer LSTM process realism or conceptual superiority from these diagnostics.",
        },
        {
            "id": "M5",
            "manuscript_claim": "Regime heterogeneity is visible, especially in snow-dominated basins.",
            "primary_evidence": "tables/regime_summary.csv; figures/fig2_regime_median_nse.png; figures/fig4_lstm_minus_best_conceptual_by_regime.png",
            "allowed_wording": "the three conceptual structure references show different error patterns across regimes while the LSTM remains higher",
            "boundary": "Do not present regime heterogeneity as a general predictive win over the LSTM.",
        },
        {
            "id": "M6",
            "manuscript_claim": "A four-model oracle offers little median gain over the LSTM ensemble.",
            "primary_evidence": (
                f"tables/oracle.csv: four-model oracle median NSE {oracle.loc['four_model_oracle_median_nse']:.6f}; "
                f"median gain over LSTM {oracle.loc['four_model_oracle_minus_lstm_median']:.6f}"
            ),
            "allowed_wording": "the evidence does not support a predictive-complement claim",
            "boundary": (
                f"It is acceptable to report {int(oracle.loc['conceptual_beats_lstm_count'])} conceptual basin wins, "
                "but not to oversell them as deployable complementarity."
            ),
        },
        {
            "id": "M7",
            "manuscript_claim": "Snow-module fairness is controlled and disclosed.",
            "primary_evidence": "tables/parameter_accounting.csv; tables/fairness_audit.csv; test/test_id10_pdd_fairness.py",
            "allowed_wording": "GR4J/XAJ external PDD paths are effective-equivalent; HBV snow is intrinsic structure",
            "boundary": "Do not write that all three conceptual models share an identical external snow module.",
        },
        {
            "id": "M8",
            "manuscript_claim": "The final conceptual parameter artifacts remain valid under the current code.",
            "primary_evidence": (REPLAY_AUDIT_REL / "saved_parameter_replay_summary.csv").as_posix(),
            "allowed_wording": "saved parameters replay exactly under the current code in saved-state and warmup-recomputed modes",
            "boundary": "Do not describe this as a fresh full CMA-ES recalibration.",
        },
        {
            "id": "M9",
            "manuscript_claim": "Conceptual-structure disagreement has concrete basin-attribute diagnostic signal.",
            "primary_evidence": evidence["spearman"],
            "allowed_wording": "static basin attributes, especially snow/topography/aridity, align with model-structure disagreements",
            "boundary": "Use correlational language; do not claim causal mechanism or model-input fairness from `camels_hydro`.",
        },
        {
            "id": "M10",
            "manuscript_claim": "Selected hydrograph cases illustrate seasonal and high-flow residual patterns associated with the attribute signal.",
            "primary_evidence": (D02_DEEP_DIVE_REL / "tables" / "seasonal_delta_aggregate.csv").as_posix(),
            "allowed_wording": "selected-case residual checks are consistent with the basin-attribute diagnosis",
            "boundary": "Selected cases are diagnostic examples from the published benchmark, not population evidence, not causal-mechanism tests, and not restated under the reported protocol.",
        },
        {
            "id": "M11",
            "manuscript_claim": "Population residual diagnostics support that the snow/MAM/high-flow signal is not only a selected-case artifact.",
            "primary_evidence": (
                (D03_DEEP_DIVE_REL / "tables" / "seasonal_delta_aggregate.csv").as_posix() + "; " +
                evidence["seasonal_links"]
            ),
            "allowed_wording": "population-wide residual checks strengthen the diagnostic structure-regime interpretation",
            "boundary": "Still post-hoc and correlational; do not claim causal LSTM process realism or predictive complementarity.",
        },
        {
            "id": "M12",
            "manuscript_claim": "The LSTM advantage is concentrated rather than uniform across regime-season and regime-flow contexts.",
            "primary_evidence": (
                "tables/lstm_advantage_concentration.csv; " +
                evidence["season"] + "; " + evidence["flow"] +
                f": snow/MAM {adv['snow_mam_context_share']:.1%} contexts -> {adv['snow_mam_gap_share']:.1%} positive row-wise gap; " +
                f"snow/high {adv['snow_high_context_share']:.1%} contexts -> {adv['snow_high_gap_share']:.1%} positive row-wise gap"
            ),
            "allowed_wording": "conceptual structure references decompose where the LSTM advantage concentrates",
            "boundary": "Do not treat this as an independent model-selection result or causal process proof.",
        },
        {
            "id": "M13",
            "manuscript_claim": "Snow-dominated MAM high flow is the retained joint context with the highest concentration ratio.",
            "primary_evidence": (
                "tables/lstm_advantage_concentration.csv; " +
                evidence["joint"] +
                f": {adv['snow_mam_high_context_share']:.1%} contexts -> {adv['snow_mam_high_gap_share']:.1%} positive row-wise gap; " +
                f"ratio {adv['snow_mam_high_ratio']:.2f}; shared failure {adv['snow_mam_high_shared_failure']:.3f}"
            ),
            "allowed_wording": "snow-dominated MAM high flow has the highest concentration ratio among retained joint contexts",
            "boundary": "Post-hoc residual decomposition only; uncertainty-qualified seasonal contrasts are not preregistered confirmation and do not identify a snowmelt or rain-on-snow mechanism.",
        },
        {
            "id": "M14",
            "manuscript_claim": "The complete 16-cell, 12-cell, and 48-cell matrices show that the row-summed absolute-error gap is primarily high-flow, amplified in snow-dominated basins, and not confined to spring.",
            "primary_evidence": (
                "tables/context_dimension_summary.csv; figures/fig5_joint_context_heterogeneity.png; " +
                evidence["season"] + "; " + evidence["flow"] + "; " + evidence["joint"] +
                f": high-flow gap share {heterogeneity['flow']['high']['positive_best_gap_share']:.1%}; " +
                f"snow/high spring ratio {heterogeneity['snow_high']['MAM']['concentration_ratio']:.2f}; " +
                f"winter ratio {heterogeneity['snow_high']['DJF']['concentration_ratio']:.2f}"
            ),
            "allowed_wording": "high flow is the main per-day absolute-error dimension, snow-dominated basins amplify it, and spring and winter are the two largest snow/high-flow cells",
            "boundary": (
                "Report concentration with shared failure or median gap; absolute MAE is not scale-free, low flow is not baseflow, and the full matrix is descriptive rather than a pre-specified test."
            ),
        },
    ]
    if "context_scale_threshold_summary" in tables:
        rows.extend([
            {
                "id": "M15",
                "manuscript_claim": "Absolute-error reduction and dimensionless relative advantage have different flow-group hierarchies.",
                "primary_evidence": "tables/context_scale_threshold_summary.csv; tables/context_scale_threshold_intervals.csv; figures/fig6_scale_threshold_robustness.png",
                "allowed_wording": "high flow dominates the per-day absolute-error margin, while middle flow has the largest relative concentration",
                "boundary": "Do not relabel absolute concentration as scale-free skill; low-flow relative concentration can coexist with a small median absolute effect.",
            },
            {
                "id": "M16",
                "manuscript_claim": "Snow-dominated basins show a broader relative advantage across the hydrograph.",
                "primary_evidence": "tables/context_scale_contrasts.csv; figures/fig6_scale_threshold_robustness.png",
                "allowed_wording": "snow-dominated basins have a larger median relative advantage across low, middle, and high flow",
                "boundary": "Associational regime contrast only; do not infer an independently identified snow process.",
            },
            {
                "id": "M17",
                "manuscript_claim": "The full context and primary-attribute patterns remain stable after the common-protocol rebuild.",
                "primary_evidence": "tables/protocol_matrix_stability.csv; tables/protocol_matrix_cell_deltas.csv",
                "allowed_wording": "the whole benchmark rebuild preserves the complete pattern hierarchy",
                "boundary": "The neural objective, scoring observations, and conceptual calibrations changed together; this is not a training-objective ablation.",
            },
        ])
    claim_map = pd.DataFrame(rows)
    text = "# Manuscript-ready claim map\n\n" + _to_md_table(claim_map) + "\n"
    (out_dir / "manuscript_ready_claim_map.md").write_text(text, encoding="utf-8")


def _write_manuscript_sections(out_dir: Path, tables: Dict[str, pd.DataFrame], protocol: EvidenceProtocol | str | None = None) -> None:
    resolved = _resolve(protocol)
    main = tables["main_benchmark"].set_index("model")
    paired = tables["paired"].set_index("comparison")
    diag = tables["conceptual_diagnostics"].set_index("model")
    oracle = tables["oracle"].set_index("quantity")["value"]
    regime = tables["regime_summary"].set_index("regime")
    winners = tables["conceptual_winners"]
    adv = _advantage_numbers(out_dir, protocol)
    heterogeneity = _context_heterogeneity_summary(out_dir, protocol)
    robustness = _robustness_manuscript_blocks(tables)
    kge = _kge_component_manuscript_blocks(tables)
    objective = _objective_intervention_manuscript_blocks(tables)
    lowflow_xaj = int(winners[(winners["metric"] == "abs_lowflow_bias") & (winners["model"] == "XAJ")]["n_wins"].iloc[0])
    peak_hbv = int(winners[(winners["metric"] == "abs_peak_bias") & (winners["model"] == "HBV")]["n_wins"].iloc[0])
    timeline = (
        "We evaluated three conceptual rainfall-runoff model schools, GR4J, XAJ, and HBV-lite, on the "
        "CAMELS-US 531-basin benchmark using the repro_v01 reverse split. All conceptual calibration "
        "objectives and LSTM training targets used 2000-09-30 to 2008-09-30, and all models were "
        "evaluated on 1989-10-01 to 1999-09-30. Conceptual simulations read one preceding year of Maurer "
        "forcing for state warm-up before both periods; those warm-up days were excluded from the "
        "objective and evaluation scores."
        if resolved.protocol_id == IDENTICAL_PROTOCOL_ID else
        "We evaluated three conceptual rainfall-runoff model schools, GR4J, XAJ, and HBV-lite, on the "
        "CAMELS-US 531-basin benchmark using the repro_v01 reverse split. Conceptual models were calibrated "
        "on 1999-10-01 to 2008-09-30 and evaluated on 1989-10-01 to 1999-09-30 with a one-year state warm-up."
    )
    text = f"""# Manuscript section draft pack

## Methods: benchmark design

{timeline} Each conceptual model used Priestley-Taylor PET and the same CMA-ES budget of 5000 function evaluations per restart and three restarts, with the same normalized initial mean, step size, seed schedule, and NSE objective.

## Methods: structure and snow accounting

The benchmark preserves model-school differences while controlling external modules. GR4J+PDD and XAJ+PDD use external degree-day snow front ends whose active no-ice behavior is tested as effective-equivalent under the current zero-ice CAMELS-US setup. XAJ keeps a six-parameter PDD wrapper for historical compatibility, but the two ice parameters are inactive because ice storage starts at zero and no process creates ice storage. We therefore report XAJ as 20 nominal parameters and 18 effective active parameters. HBV-lite, in contrast, contains an intrinsic HBV degree-day snow routine with `SNOWPACK` and `MELTWATER` states; this is treated as part of the HBV model structure rather than as a shared external PDD module.

## Methods: LSTM reference and audit trail

The conceptual benchmark is compared with a reproduced LSTM reference rather than presented as a predictive state-of-the-art challenge. The LSTM uses the same 531 basins, Maurer forcing, and reverse split, but also uses regional learning with static attributes; it is the strongest evaluated predictive reference, not a strict same-information conceptual challenger. We include a seed-100 single model and an eight-seed ensemble. All headline tables and figures are regenerated from saved per-basin artifacts by `python -X utf8 -m src.lstm_fair_531.scripts.build_manuscript_evidence_package`; the snow-front-end equivalence claim is checked by `pytest test/test_id10_pdd_fairness.py -q`.
{robustness['methods']}
{kge['methods']}

## Results: predictive boundary

The conceptual-model median NSE values are {main.loc['GR4J', 'median_nse']:.6f} for GR4J, {main.loc['XAJ', 'median_nse']:.6f} for XAJ, and {main.loc['HBV', 'median_nse']:.6f} for HBV-lite. These descriptive medians do not establish superiority or equivalence between XAJ and HBV-lite. The LSTM single model reaches median NSE {main.loc['LSTM_single_s100', 'median_nse']:.6f}, and the eight-seed LSTM ensemble reaches {main.loc['LSTM_ensemble_8seed', 'median_nse']:.6f}. In paired comparison, the LSTM ensemble exceeds GR4J by median NSE {paired.loc['LSTM_ensemble_8seed_vs_GR4J', 'median_diff']:.6f} and wins on {paired.loc['LSTM_ensemble_8seed_vs_GR4J', 'lstm_win_rate']:.3f} of common basins.

## Results: structure-reference diagnostics

Although the LSTM is the strongest evaluated predictor, the conceptual models expose different diagnostic behavior. GR4J has the best overall median NSE and KGE, with median KGE {diag.loc['GR4J', 'median_kge']:.6f} and the smallest median absolute bias ({diag.loc['GR4J', 'median_abs_bias']:.6f}). HBV-lite has the smallest median absolute peak bias ({diag.loc['HBV', 'median_abs_peak_bias']:.6f}) and has the lowest absolute peak bias among the three conceptual models in {peak_hbv} basins. XAJ has the smallest median absolute low-flow bias ({diag.loc['XAJ', 'median_abs_lowflow_bias']:.6f}) and has the lowest absolute low-flow bias among the three in {lowflow_xaj} basins. These trade-offs support the use of conceptual models as diagnostic baselines rather than as competitive predictors against the LSTM ensemble.

## Results: LSTM advantage decomposition


The complete matrices contain 16 regime-season, 12 regime-flow, and 48 joint cells. High flow contributes {heterogeneity['flow']['high']['positive_best_gap_share']:.1%} of the row-summed positive absolute-error gap from {heterogeneity['flow']['high']['context_share']:.1%} of basin-flow contexts, whereas every low-flow regime cell is below proportional concentration. Snow-dominated high-flow concentration spans all four seasons; spring ({heterogeneity['snow_high']['MAM']['concentration_ratio']:.2f}) and winter ({heterogeneity['snow_high']['DJF']['concentration_ratio']:.2f}) are close descriptive maxima. The result is not a spring-only mechanism.
The key diagnostic result is not that the LSTM wins overall, but that its advantage is concentrated. Table 7 maps context share to positive best-gap share, concentration ratio, and shared failure rate. In D05, snow-dominated MAM contexts account for {adv['snow_mam_context_share']:.1%} of basin-season contexts but {adv['snow_mam_gap_share']:.1%} of the positive LSTM-vs-best-conceptual MAE gap. Snow-dominated high-flow contexts account for {adv['snow_high_context_share']:.1%} of basin-flow contexts but {adv['snow_high_gap_share']:.1%} of the positive gap. D06 combines season and flow group using the D04 daily residual archive: snow-dominated MAM high-flow contexts account for {adv['snow_mam_high_context_share']:.1%} of basin-season-flow contexts but {adv['snow_mam_high_gap_share']:.1%} of the positive best-conceptual MAE gap, with concentration ratio {adv['snow_mam_high_ratio']:.2f} and shared failure rate {adv['snow_mam_high_shared_failure']:.3f}. This supports the use of GR4J/XAJ/HBV as structure-reference probes for locating the LSTM advantage, not as predictive complements.
{robustness['results']}
{robustness['protocol']}
{kge['results']}

## Results: regime heterogeneity and oracle check

The relative behavior of the three conceptual structures varies by hydrologic regime, while the LSTM remains the strongest predictor. In snow-dominated basins, XAJ and HBV-lite have higher median NSE ({regime.loc['snow-dominated', 'XAJ_median_nse']:.6f} and {regime.loc['snow-dominated', 'HBV_median_nse']:.6f}) than GR4J ({regime.loc['snow-dominated', 'GR4J_median_nse']:.6f}), while the LSTM ensemble remains higher at {regime.loc['snow-dominated', 'LSTM_ensemble_8seed_median_nse']:.6f}. Across all basins, a four-model oracle reaches median NSE {oracle.loc['four_model_oracle_median_nse']:.6f}, with median gain {oracle.loc['four_model_oracle_minus_lstm_median']:.6f} over the LSTM ensemble. This indicates that conceptual models provide useful diagnostic contrasts, but the evidence does not support a predictive-complement claim.

## Limitations


The absolute and dimensionless analyses answer different scale questions. The 39 attribute associations are bivariate and covary, snow fraction participates in regime definition, and low flow is a discharge-quantile group rather than baseflow.

{robustness['limitations']}
{kge['limitations']}
This benchmark should not be read as strict information equality between conceptual models and the LSTM: the LSTM uses regional learning and static attributes, while conceptual models are calibrated per basin. Full-population LSTM headline diagnostics remain NSE-based in the main benchmark, while D02-D06 use saved daily LSTM test predictions or generated residual artifacts as post-hoc diagnostics. D05/D06 localize rows where all three conceptual models have higher error, but do not prove causal event mechanisms or LSTM process realism. HBV-lite's snow routine is intrinsic to the model and should not be described as the same external PDD module used by GR4J and XAJ. Finally, the current paper package is auditable from saved artifacts and tests, but a full recalibration of all conceptual models is computationally more expensive than the manuscript evidence rebuild.
"""
    (out_dir / "manuscript_sections.md").write_text(text, encoding="utf-8")


def _write_key_points(out_dir: Path, tables: Dict[str, pd.DataFrame], protocol: EvidenceProtocol | str | None = None) -> None:
    evidence = _evidence_paths(protocol)
    advantage = _advantage_numbers(out_dir, protocol)
    population = _population_support_numbers(out_dir, protocol)
    heterogeneity = _context_heterogeneity_summary(out_dir, protocol)
    if "context_scale_threshold_summary" in tables:
        robustness = _context_robustness_numbers(tables)
        q10 = robustness["flow"]["q10_q90"]
        stability = robustness["stability"]
        text = f"""# Key Points

The three points form one story at three levels: which diagnostics move with the calibration objective (the shared amplitude compression), which ones stay put and therefore separate the models (daily correlation and event shape), and where the resulting LSTM advantage concentrates (snow-dominated high flow). They are not three separate contributions.

- The calibration objective moves flow variability compression far more than daily correlation, the same way in all four models
- Daily correlation and event shape are where the LSTM leads the three conceptual models
- The LSTM's advantage over the conceptual models concentrates most strongly in high flow in snow-dominated basins

## Traceability

| Point | Role in the single argument | Manuscript location | Direct evidence | Boundary |
| --- | --- | --- | --- | --- |
| 1 | Central attribution: objective sets amplitude | Sections 3.8, 3.11 | `tables/objective_dose_response_summary.csv`; `tables/objective_dose_response_monotonicity.csv`; `tables/hydrological_flow_bias_summary.csv` | Internal-holdout mechanism test with one weighted squared-error family; "rather than" is deliberate because model levels still differ by about 0.05 under a fixed objective. |
| 2 | What structure sets: daily correlation and event shape | Sections 3.9-3.10 | `tables/kge_component_summary.csv`; `tables/kge_paired_attribution_summary.csv`; `tables/cause_event_shape_summary.csv`; `tables/cause_event_shape_pairwise_summary.csv` | The LSTM-conceptual comparison mixes structure with regional training and static attributes; only the conceptual-conceptual shape contrast is a clean structural attribution. |
| 3 | Where the margin concentrates | Sections 3.3-3.5 | `tables/context_dimension_summary.csv`; `tables/context_scale_contrasts.csv`; `figures/fig5_joint_context_heterogeneity.png`; `{evidence['spearman']}` | Concentration shares use the row-equal (per-day rate) accounting; associational, with no snow-process mechanism claim; contrast is snow-dominated versus pooled non-snow basins. |
"""
        (out_dir / "key_points.md").write_text(text, encoding="utf-8")
        return
    text = f"""# Key Points

The three points below compress one contribution, not three separate contributions: conceptual structures locate where the long short-term memory network advantage concentrates, while population-level and joint-context analyses provide two supporting evidence layers.

- The complete 16-cell regime-season, 12-cell regime-flow, and 48-cell joint audit locates row-summed positive absolute-error advantage rather than selecting one winning cell: high flow contributes {heterogeneity['flow']['high']['positive_best_gap_share']:.1%} of the gap from {heterogeneity['flow']['high']['context_share']:.1%} of basin-flow contexts, while every low-flow regime cell has a concentration ratio below one.
- Across 531 basins and 39 primary static attributes, snow fraction has the strongest bivariate association with the long short-term memory network margin (rho = {population['basin_snow_rho']:.3f}, q = {population['basin_snow_q']:.2e}); correlated latitude, vegetation, elevation, energy, and precipitation signals prevent an independent snow-process interpretation.
- Snow-dominated high-flow concentration persists across all four seasons; spring ({heterogeneity['snow_high']['MAM']['concentration_ratio']:.2f}) and winter ({heterogeneity['snow_high']['DJF']['concentration_ratio']:.2f}) are the two largest descriptive cells, and all three evaluated conceptual models have higher mean absolute error than the LSTM in {advantage['snow_mam_high_shared_failure']:.1%} of snow-dominated spring high-flow rows.

## Traceability

| Point | Role in the single argument | Manuscript location | Direct evidence | Boundary |
| --- | --- | --- | --- | --- |
| 1 | Central contribution: locate concentration | Section 3.3 | `tables/context_dimension_summary.csv`; `figures/fig5_joint_context_heterogeneity.png`; `{evidence['season']}`; `{evidence['flow']}`; `{evidence['joint']}` | Descriptive absolute-MAE decomposition, not a scale-free skill test or predictive method. |
| 2 | First evidence layer: population-level support | Section 3.4 | `{evidence['spearman']}`; `{evidence['seasonal_links']}`; `{evidence['flow_links']}` | Bivariate, covarying associations do not establish an independent snow-process mechanism. |
| 3 | Second evidence layer: joint context refinement | Section 3.5 | `tables/lstm_advantage_concentration.csv`; `{evidence['joint']}` | Post-hoc joint context; no event attribution or process realism; the spring-winter contrast was not tested, so no significance claim is made. |
"""
    (out_dir / "key_points.md").write_text(text, encoding="utf-8")


def _write_full_manuscript(out_dir: Path, tables: Dict[str, pd.DataFrame], protocol: EvidenceProtocol | str | None = None) -> None:
    resolved = _resolve(protocol)
    evidence = _evidence_paths(protocol)
    main = tables["main_benchmark"].set_index("model")
    paired = tables["paired"].set_index("comparison")
    oracle = tables["oracle"].set_index("quantity")["value"]
    diagnostic = tables["conceptual_diagnostics"].set_index("model")
    regime = tables["regime_summary"].set_index("regime")
    advantage = _advantage_numbers(out_dir, protocol)
    population = _population_support_numbers(out_dir, protocol)
    heterogeneity = _context_heterogeneity_summary(out_dir, protocol)
    robustness = _robustness_manuscript_blocks(tables)
    process = _hydrological_process_manuscript_blocks(tables)
    cause = _posthoc_cause_manuscript_blocks(tables)
    kge = _kge_component_manuscript_blocks(tables)
    objective = _objective_intervention_manuscript_blocks(tables)
    if "flow_day_weighted_summary" in tables:
        day_flow = tables["flow_day_weighted_summary"].set_index("flow_group")
        abstract_mm_clause = (
            f"high-flow days—{day_flow.loc['high', 'day_share']:.1%} of all days—carried "
            f"{day_flow.loc['high', 'positive_gap_share_days']:.1%} of the accumulated error reduction "
            "in millimetres relative to the best conceptual model in each context, "
            f"{day_flow.loc['high', 'day_concentration_ratio']:.1f} times their share of days"
        )
        day_accounting_paragraph = f"""
The row-based shares above weight each basin-context row equally, so they measure the per-day error-reduction rate, and the flow-group context share is fixed near one third by construction because every basin contributes one low-, one middle-, and one high-flow row. Weighting each row by its number of days converts the rate into accumulated millimetres: high-flow days made up {day_flow.loc['high', 'day_share']:.1%} of all days and carried {day_flow.loc['high', 'positive_gap_share_days']:.1%} of the day-weighted positive gap ({day_flow.loc['high', 'day_concentration_ratio']:.2f} times their share of days). Both accountings leave high flow over-represented relative to its share; the full flow-group accounting under both weightings is reported in Supplementary Table S16, and statements about total millimetres saved refer to the day-weighted accounting (`tables/flow_day_weighted_summary.csv`).
"""
    else:
        abstract_mm_clause = (
            f"{heterogeneity['flow']['high']['positive_best_gap_share']:.1%} of the error reduction relative to "
            "the best conceptual model in each context came from high flow, which represents only "
            f"{heterogeneity['flow']['high']['context_share']:.1%} of basin-flow contexts"
        )
        day_accounting_paragraph = ""
    if "context_scale_threshold_summary" in tables:
        joint_context_boundary = (
            "Those absolute-MAE concentration ratios locate the per-day absolute-error margin rather than typical relative effects. "
            "The separate dimensionless common-basin contrasts reported above order the snow-dominated high-flow medians as spring, winter, summer, and autumn, but the family was specified after inspection of the complete matrix and remains post-hoc. "
            "The broader empirical result is a cross-season snow-dominated high-flow pattern, not an identified snowmelt mechanism."
        )
    else:
        joint_context_boundary = "Spring was the descriptive maximum, but no clustered uncertainty interval was specified for the spring-winter contrast; the broader result is snow-dominated high-flow concentration across seasons, with spring and winter the two largest cells."
    if resolved.protocol_id == IDENTICAL_PROTOCOL_ID:
        timeline_paragraph = (
            "The analysis used the same 531 CAMELS-US basins for all headline model summaries "
            "(Addor et al., 2017; Newman et al., 2015). "
            "Meteorological inputs were taken from the Maurer forcing product (Maurer et al., 2002). All conceptual calibration "
            "objectives and all eight LSTM training runs used targets from 30 September 2000 through 30 "
            "September 2008, and evaluation used 1 October 1989 through 30 September 1999. Conceptual "
            "simulations read one preceding year of forcing for state warm-up before both the "
            "optimization-target and evaluation periods; those warm-up days were excluded from the "
            "corresponding scores. This reverse temporal split follows the CAMELS benchmark model outputs "
            "deposit (Kratzert, 2019), matches the benchmark configuration recorded in `tables/protocol.csv`, "
            "and preserves a common forcing product, basin population, optimization-target period, and "
            "evaluation interval across the headline comparison."
        )
        config_provenance = (
            "are supplied in Supplementary Table S15, the registered LSTM configuration-provenance table"
        )
        shared_period = "optimization-target period"
    else:
        timeline_paragraph = (
            "The analysis used the same 531 CAMELS-US basins for all headline model summaries. "
            "Meteorological inputs were taken from the Maurer forcing product. Conceptual-model calibration "
            "and LSTM training used 1 October 1999 through 30 September 2008, and evaluation used 1 October "
            "1989 through 30 September 1999. The conceptual simulations used a one-year warm-up before the "
            "evaluation period. This reverse temporal split matches the benchmark configuration recorded in "
            "`tables/protocol.csv`."
        )
        config_provenance = "are documented in the generated protocol table and source ledger"
        shared_period = "calibration and training interval"
    text = f"""# Sensitivity of Flow Variability Compression, Daily Correlation, and Event Shape to the Calibration Objective in an LSTM and Three Conceptual Rainfall-Runoff Models Across 531 United States Basins

## Abstract

Large-sample comparisons rank rainfall-runoff models by aggregate accuracy across hundreds of basins, and data-driven models now lead these rankings. An aggregate score, however, does not show which flow conditions, seasons, and basin types produce the advantage, and improvements on the few flood-relevant high-flow days have different consequences for flood forecasting than improvements spread over the many ordinary days. Where the data-driven advantage accumulates, and whether the remaining errors are specific to conceptual model structure or shared by all models, has rarely been examined with all models optimised on a common objective. We answer both questions on 531 basins from the Catchment Attributes and Meteorology for Large-sample Studies data set for the contiguous United States (CAMELS-US): an eight-seed long short-term memory (LSTM) network ensemble and three per-basin-calibrated conceptual models—GR4J, Xinanjiang, and HBV-lite—are optimised on the same basin-averaged efficiency objective and scored against the same observations. Because the regional ensemble also uses static basin attributes, the comparison is diagnostic rather than a strict same-information contest. The ensemble reached a median Nash-Sutcliffe efficiency (NSE) of {main.loc['LSTM_ensemble_8seed', 'median_nse']:.3f}, versus {main.loc['GR4J', 'median_nse']:.3f} for GR4J, the strongest conceptual reference. Where this margin accumulates depends on the error scale: on the absolute scale, {abstract_mm_clause}, with snow-dominated spring high flow the most concentrated joint context; on the relative scale, middle flow carried the largest concentration and the most consistent shared conceptual failure, and snow-dominated basins showed a larger relative advantage than non-snow basins across low, middle, and high flow rather than at spring high flow alone. Event diagnostics bound the interpretation: all four models, including the LSTM, underpredicted observed event peaks and compressed high-flow variability; the LSTM only narrowed this shared deficit, and GR4J retained smaller autumn aligned event-peak deficits than the LSTM under both event definitions, but that difference tracked a positive autumn event-volume bias in GR4J rather than a sharper event shape: with event volume divided out, the LSTM had the higher autumn event-peak concentration. These findings show that the aggregate advantage of a regional LSTM is a scale-dependent, hydrologically structured pattern inside an amplitude deficit shared by all evaluated models; the decomposition remains post-hoc and associational and does not identify causal event mechanisms or establish physically correct neural processes.

<!-- Abstract evidence: tables/main_benchmark.csv; tables/context_dimension_summary.csv; tables/flow_day_weighted_summary.csv; tables/context_scale_threshold_summary.csv; tables/context_scale_contrasts.csv; tables/hydrological_flow_bias_summary.csv; tables/hydrological_event_summary.csv; tables/kge_component_summary.csv; {evidence['season']}; {evidence['flow']}; {evidence['joint']} -->

**Keywords:** large-sample hydrology; rainfall-runoff modelling; long short-term memory network; conceptual model; diagnostic benchmark; error decomposition; snow-dominated basins

## 1. Introduction

Aggregate performance summaries are necessary for ranking rainfall-runoff models across heterogeneous basins, but they collapse the distribution of predictive differences into a small set of scores. A higher overall score does not reveal whether the margin is broadly distributed or disproportionately associated with particular basin regimes, seasons, or flow conditions. Distinguishing these possibilities is the scientific problem addressed here: it identifies the hydrological contexts that account for a known predictive gap without treating the gap itself as the novelty.

The CAMELS-US data set provides hydroclimatic forcing, streamflow records, and basin attributes for comparative analyses across a geographically diverse basin population (Addor et al., 2017; Newman et al., 2015). Regional long short-term memory networks can learn shared relationships across basins while conditioning predictions on static attributes, and Kratzert et al. (2019) showed that this strategy can outperform established hydrological benchmarks across 531 CAMELS-US basins. Direct comparisons with conceptual benchmarks have also documented spatial and seasonal heterogeneity associated with snow and aridity (Lees et al., 2021). Event-oriented work has further developed diagnostics that separate error dimensions across hydrological event types (Wang et al., 2026). Overall predictive dominance, spatial heterogeneity, and event diagnostics are therefore established starting points rather than sufficient contributions for the present study.

Conceptual rainfall-runoff models remain useful for this narrower problem because their computations are constrained by explicit storage and flux arrangements. Knoben et al. (2019) provided a standardized modular framework for comparing conceptual structures and examining structural uncertainty. For the present diagnostic question, however, one conceptual benchmark would not distinguish a weakness specific to one formulation from an error pattern shared by several structures. We therefore use GR4J, Xinanjiang, and HBV-lite together as structural references: agreement among their errors identifies contexts in which all three fall behind the LSTM, while disagreement preserves information about structure-specific behaviour. They are not proposed as replacements, ensemble members, or deployable corrections for the LSTM.

The study makes one central contribution: it shows how the calibration objective conditions the interpretation of differences between an LSTM and conceptual rainfall-runoff models. The paper benchmark first establishes the model differences and their hydrological concentration; a separate, disjoint internal-holdout intervention then applies the same objective changes to all four models and ranks how strongly event-peak height, flow variability compression, event shape, daily correlation, and peak timing respond. The responses form a continuum rather than two exclusive sources: event-peak height and flow variability compression are more sensitive to the objective, whereas event shape and daily correlation are less sensitive, and the flow-variability response span itself differs 2.7-fold among models. These results do not assign any difference wholly to model structure, particularly because the LSTM also uses regional training and static basin attributes. Hydrological concentration is reported separately, with its error scale stated explicitly.

Three boundaries follow from this framing. First, the LSTM uses regional training and static attributes, whereas each conceptual model is calibrated per basin, so the study does not claim strict information equality. Second, the decomposition uses saved evaluation-period predictions after model development; it is a diagnostic analysis rather than an independently selected predictive model. Third, observed associations with snow fraction and season do not determine event type or causal mechanism. The aim is to locate an empirical error concentration, not to infer rain-on-snow events, snowmelt causality, or internal LSTM process realism.

## 2. Methods

### 2.1 Basin sample, forcing, and temporal split

{timeline_paragraph}

Observed discharge was used as the prediction target and for evaluation, not as an input channel. The main score was basin-wise Nash-Sutcliffe efficiency (Nash & Sutcliffe, 1970), summarized by the median and mean across 531 basins. NSE is sensitive to squared errors and high flows, so the context decomposition additionally used mean absolute error (MAE) calculated from saved daily predictions. The MAE decomposition avoids relying on unstable low-flow NSE values when samples within a context are small.

### 2.2 Conceptual structural references

GR4J, Xinanjiang, and HBV-lite represent three different conceptual rainfall-runoff model families. GR4J (Perrin et al., 2003) combines four rainfall-runoff parameters with an external positive degree-day snow front end. Xinanjiang (Zhao, 1992) uses its characteristic tension-water and runoff-generation structure with an external degree-day snow front end. HBV-lite, a reduced implementation of the HBV family (Bergström, 1976), includes an intrinsic degree-day snow routine and internal snow states as part of its model structure. The three models therefore do not share an identical snow module, and that difference is retained as a structural feature rather than hidden by the comparison.

The conceptual models were calibrated separately for each basin with the Covariance Matrix Adaptation Evolution Strategy (Hansen & Ostermeier, 2001). Each restart used 5,000 objective evaluations, and three restarts were performed with an aligned normalized initialization and seed schedule. The calibration objective was NSE. Parameter accounting distinguished nominal parameters from parameters that were active in the evaluated zero-ice configuration (Table 5). GR4J plus its snow front end had 8 nominal and 8 effective active parameters. Xinanjiang plus its historical six-parameter snow wrapper had 20 nominal parameters, but 18 were active because the two ice parameters did not affect the tested zero-ice path. HBV-lite had 13 intrinsic parameters. The finite zero-ice sequence tests support agreement of the GR4J and Xinanjiang external snow paths under the tested conditions; they do not establish universal structural identity.

The fixed model equations, state updates, and numerical implementations are traceable to `src/xaj_global_pilot/gr4j_core.py`, `src/xaj_global_pilot/xaj_model.py`, and `src/scl_hydro/hbv_lite_numpy.py`. Calibration bounds and their named presets are recorded in `src/xaj_global_pilot/bounds_presets.py`; the exact parameter counts and common protocol used here are exported in `tables/parameter_accounting.csv` and `tables/protocol.csv`. These references define the evaluated implementations and bounds without implying that they exhaust other valid formulations of the three model families.

### 2.3 LSTM reference and comparison boundary

The neural reference consisted of a single seed-100 model and an ensemble of eight LSTM (Hochreiter & Schmidhuber, 1997) models trained with seeds 100 through 800 for 30 epochs. The regional LSTM used five daily dynamic inputs—precipitation, minimum temperature, maximum temperature, short-wave radiation, and vapour pressure—from the Maurer product, together with 27 static basin attributes. Every run used a sequence length of 270 days, 256 hidden units, a batch size of 256, output dropout of 0.4, the Adam optimizer (Kingma & Ba, 2015), and Nash-Sutcliffe-efficiency loss. The learning rate was 0.001 initially, 0.0005 from epoch 11, and 0.0001 from epoch 21. The fixed settings, complete attribute list, seed-specific registered configuration paths, and SHA-256 digests {config_provenance}; the network implementation is the CudaLSTM model of the neuralhydrology library (Kratzert et al., 2022), `neuralhydrology/modelzoo/cudalstm.py`.

For each basin and date, ensemble discharge was the arithmetic mean of the eight daily predictions. The LSTM shared the headline basin set, forcing product, {shared_period}, and evaluation interval with the conceptual comparison, but its regional learning and static inputs provide predictive information that per-basin conceptual calibration does not use in the same form.

For that reason, the LSTM is treated as the strongest evaluated predictive reference. The experiment asks how three conceptual structures behave relative to that reference, not which model wins under identical information. The overall LSTM ranking establishes the boundary of the analysis. It is neither claimed as a new state of the art nor counted as the paper's central contribution.

### 2.4 Headline performance and paired comparisons

For each model, basin-wise NSE values were collected in `tables/main_benchmark.csv`. The strongest single conceptual model means the fixed model family with the highest median basin-wise NSE; under this protocol, that model was GR4J. For basin-level margin analyses, the basin-wise conceptual comparator with the highest Nash-Sutcliffe efficiency was selected separately within each basin. Paired LSTM-versus-conceptual differences were taken from `tables/paired.csv`, which records the number of common basins, median paired difference, LSTM win rate, Wilcoxon signed-rank probability (Wilcoxon, 1945), and bootstrap confidence interval (Efron, 1979). A four-model oracle was also calculated by selecting, separately for each basin, the highest NSE among the LSTM ensemble and the three conceptual models. The oracle was used only as a diagnostic upper bound. It was not used to select or tune a deployable hybrid.

### 2.5 Advantage concentration metrics

The diagnostic analysis was performed on basin-context rows. A context was defined at three levels: hydrological regime by season, hydrological regime by flow group, and hydrological regime by season and flow group jointly. The saved regime labels followed fixed benchmark rules. A basin was snow-dominated when its snow fraction was at least 0.20, or when its coldest-quarter temperature was below 0 degrees Celsius and its cold-season precipitation fraction was at least 0.20. Among the remaining basins, humid meant an aridity index below 1.0, semi-humid meant an aridity index from 1.0 to below 1.5, and semi-arid/arid meant an aridity index of at least 1.5. The thresholds and classification code are recorded in `src/xaj_global_pilot/config.py` and `src/xaj_global_pilot/archive_legacy/classification.py`.

Spring was defined as March through May and is denoted MAM in the saved result tables. Daily flows were divided separately for each basin using the 10th and 90th percentiles of that basin's observed evaluation-period discharge: low flow was at or below the 10th percentile, high flow was at or above the 90th percentile, and middle flow lay between them. Each basin-model joint season-flow context was retained only when it contained at least 10 valid days. These definitions are implemented in `src/lstm_fair_531/scripts/seasonal_residual_deep_dive.py` and `src/lstm_fair_531/scripts/joint_advantage_decomposition.py`.

Ties at the discharge thresholds mean the flow groups are not guaranteed to contain exactly 10%, 80%, and 10% of days. The registered regime-flow table contains {heterogeneity['flow_context_count']:,} valid basin-flow contexts rather than 1,593: one basin has no separate low- or middle-flow context because its evaluation-period discharge values collapse at the thresholds. Accordingly, low flow is not a baseflow partition; it is only the observed-discharge quantile group defined above.

For each basin-context row, the conceptual comparator with the lowest mean absolute error in each row was selected from GR4J, Xinanjiang, and HBV-lite. The row-wise gap was this minimum conceptual MAE minus LSTM MAE. A positive value therefore indicates that even the lowest-error conceptual model was worse than the LSTM. Four quantities summarize each grouped context. `context_share` is the fraction of all valid basin-context rows belonging to the group. `positive_best_gap_share` is the group's share of the sum of positive row-wise gaps. `concentration_ratio` divides positive-gap share by context share; values greater than one indicate disproportionate contribution to the positive LSTM advantage. `shared_failure_rate` is the fraction of rows in which all three conceptual models had higher MAE than the LSTM. Because the comparator is the lowest-error conceptual model, that event occurs exactly when the LSTM beats the comparator, so `shared_failure_rate` and the LSTM win rate under the minimum-error comparator are the same quantity. Share denominators were calculated separately within each context family—regime-season, regime-flow, and regime-season-flow—and were never pooled across those families.

These metrics describe concentration within saved evaluation-period predictions. They do not constitute an additional model, a validation-selected decision rule, or an event attribution procedure. Missing context metrics were excluded according to the decomposition scripts, while MAE contexts were retained when context-specific NSE was unavailable.

{robustness['methods']}
### 2.6 Population-level support and joint context refinement

The population-level support analysis linked basin-wide and context-specific residual targets to static basin attributes. The primary snow variable was the long-term snow fraction recorded in the static CAMELS-US attribute panel. Spearman rank correlations were used because the relationships need not be linear. Multiple comparisons were summarized with Benjamini-Hochberg false-discovery-rate-adjusted q values (Benjamini & Hochberg, 1995). The basin-wide table formed one correction family over all reported target-attribute pairs. The seasonal and flow analyses each formed a separate correction family over all context-target-attribute rows in its generated table. Primary claims use static attributes; streamflow-derived hydrological signatures were treated as supplemental diagnostics and were not used as inputs to a challenger model.

The primary basin-wide family contained {heterogeneity['static_attribute_count']} static attributes spanning climate, topography, soil, geology, and vegetation. These are separate bivariate rank correlations, not independent effects. The seasonal and flow link tables each carried six explanatory variables: four static attributes and two model-derived diagnostics (conceptual spread and the basin-wide LSTM margin). Those two diagnostics were not described as static basin properties.

Selected hydrographs were retained only as time-series illustrations. The population analysis used all 531 basins with available conceptual and LSTM scores. The joint context refinement then combined regime, season, and flow group using the saved full-population daily residual archive. This sequence separates illustration, population support, and joint localization without treating any layer as causal evidence.

{process['methods']}
{cause['methods']}
{kge['methods']}
### 2.9 Benchmark protocol under which these numbers were produced

Every primary number reported in this manuscript comes from one benchmark; only the explicitly labelled protocol-sensitivity comparisons reuse the earlier protocol. In this benchmark, all four models are optimised on the same objective: the basin-averaged one-minus-efficiency criterion the conceptual models are calibrated on. The neural network minimises that same criterion during training rather than a basin-normalised squared error, the three conceptual models were calibrated under this protocol rather than reused from an earlier one, and all four models are scored against a single observation series. The daily comparison panel refuses to assemble unless the conceptual and neural observation series agree to float32 tolerance, so no reported difference between two models' errors can arise from their having been measured against different targets. The structure, calibration, stale-reference, and bounds fairness checks behind this protocol are classified in Table 6.

This is a rebuild of the whole benchmark, not an ablation of the training objective. Three things differ between this protocol and the earlier published one at the same time: the neural objective, the observation series used for scoring, and the conceptual calibrations. Per-basin conceptual efficiencies move by up to 0.23, 2.00 and 7.07 for GR4J, Xinanjiang and HBV-lite respectively, and the highest-efficiency conceptual structure changes in 69 of the 531 basins. Differences between the two protocols therefore cannot be attributed to the objective alone, and are not presented as such.

`tables/protocol_robustness.csv` reports the headline quantities of both protocols side by side. One difference is worth stating explicitly because it is easy to misread. In the earlier protocol the conceptual and neural rows carried observation series differing by a per-basin multiplicative factor between 0.88 and 1.15. Efficiency is invariant to rescaling observation and simulation together, so the earlier efficiency table was unaffected by this and remains directly comparable. Mean absolute error is not invariant, so error differences taken between models under that protocol were measured on two scales. Correcting it moves the earlier concentration shares upward by between 0.34 and 0.71 percentage points, which is to say the artefact was suppressing the reported concentration rather than creating it.

<!-- Evidence: tables/protocol.csv; tables/protocol_robustness.csv; tables/fairness_audit.csv -->

### 2.10 Audit trail and reproducibility classification

All headline tables, compact context summaries, claim maps, and manuscript drafts are generated by `python -X utf8 -m src.lstm_fair_531.scripts.build_manuscript_evidence_package`. The evidence ledger maps each manuscript element to saved source artifacts and a regeneration command. Saved-parameter replay checks confirm continuity of the conceptual outputs under the current code without being described as a new calibration.

The registered snapshot is rebuildable from a committed clean checkout, {_snapshot_input_count_phrase()} pinned by byte size and SHA-256 digest and packaged in a single content-pinned local external archive, and one build command. The committed clean checkout has been verified by rebuilding all 14 top-level outputs twice with zero digest differences. A zero count of stale-reference blockers means only that known obsolete result references are quarantined or historical; it does not certify submission readiness.

{objective['methods']}

## 3. Results

### 3.1 Predictive boundary

The eight-seed LSTM ensemble was the strongest predictor in the headline comparison (Table 1; Figure 1). Its median NSE was {main.loc['LSTM_ensemble_8seed', 'median_nse']:.6f}, compared with {main.loc['GR4J', 'median_nse']:.6f} for GR4J, {main.loc['XAJ', 'median_nse']:.6f} for Xinanjiang, and {main.loc['HBV', 'median_nse']:.6f} for HBV-lite. The single LSTM model reached {main.loc['LSTM_single_s100', 'median_nse']:.6f}. Relative to GR4J, the ensemble median paired difference was {paired.loc['LSTM_ensemble_8seed_vs_GR4J', 'median_diff']:.6f} (95% bootstrap confidence interval {paired.loc['LSTM_ensemble_8seed_vs_GR4J', 'ci95_low']:.6f} to {paired.loc['LSTM_ensemble_8seed_vs_GR4J', 'ci95_high']:.6f}; paired Wilcoxon signed-rank p = {paired.loc['LSTM_ensemble_8seed_vs_GR4J', 'wilcoxon_p']:.2e}; Table 2), and the LSTM had higher NSE in {paired.loc['LSTM_ensemble_8seed_vs_GR4J', 'lstm_win_rate']:.1%} of the 531 common basins. The corresponding win rates against Xinanjiang and HBV-lite were {paired.loc['LSTM_ensemble_8seed_vs_XAJ', 'lstm_win_rate']:.1%} and {paired.loc['LSTM_ensemble_8seed_vs_HBV', 'lstm_win_rate']:.1%}, with paired medians of {paired.loc['LSTM_ensemble_8seed_vs_XAJ', 'median_diff']:.6f} ({paired.loc['LSTM_ensemble_8seed_vs_XAJ', 'ci95_low']:.6f} to {paired.loc['LSTM_ensemble_8seed_vs_XAJ', 'ci95_high']:.6f}) and {paired.loc['LSTM_ensemble_8seed_vs_HBV', 'median_diff']:.6f} ({paired.loc['LSTM_ensemble_8seed_vs_HBV', 'ci95_low']:.6f} to {paired.loc['LSTM_ensemble_8seed_vs_HBV', 'ci95_high']:.6f}). These are paired population comparisons under this benchmark, not a claim of superiority in every basin. Figure 1 shows the five empirical NSE distributions; its main axis is truncated at NSE = -1 with the full negative tail retained in an inset, so no basin is dropped from the display.

**Table 1. Headline basin-wise NSE summary.**

| Model | Basins | Median NSE | Mean NSE |
| --- | ---: | ---: | ---: |
| GR4J | 531 | {main.loc['GR4J', 'median_nse']:.6f} | {main.loc['GR4J', 'mean_nse']:.6f} |
| Xinanjiang | 531 | {main.loc['XAJ', 'median_nse']:.6f} | {main.loc['XAJ', 'mean_nse']:.6f} |
| HBV-lite | 531 | {main.loc['HBV', 'median_nse']:.6f} | {main.loc['HBV', 'mean_nse']:.6f} |
| LSTM, seed 100 | 531 | {main.loc['LSTM_single_s100', 'median_nse']:.6f} | {main.loc['LSTM_single_s100', 'mean_nse']:.6f} |
| LSTM, eight-seed ensemble | 531 | {main.loc['LSTM_ensemble_8seed', 'median_nse']:.6f} | {main.loc['LSTM_ensemble_8seed', 'mean_nse']:.6f} |

The ranking fixes the interpretation used below: GR4J, Xinanjiang, and HBV-lite are not predictive competitors to the ensemble in this experiment. Their subsequent role is to supply explicit structural contrasts through which the distribution of the LSTM advantage can be examined.

<!-- Evidence: tables/main_benchmark.csv; tables/paired.csv -->

### 3.2 Structural contrasts below the LSTM reference

The conceptual models differed in their error signatures even though all three remained below the LSTM in overall NSE (Table 3; Figure 3). GR4J had the highest conceptual median NSE and a median Kling-Gupta efficiency of {diagnostic.loc['GR4J', 'median_kge']:.6f}. Its median absolute bias was {diagnostic.loc['GR4J', 'median_abs_bias']:.6f}. HBV-lite had the smallest median absolute peak bias, {diagnostic.loc['HBV', 'median_abs_peak_bias']:.6f}, whereas Xinanjiang had the smallest median absolute low-flow bias, {diagnostic.loc['XAJ', 'median_abs_lowflow_bias']:.6f}. These contrasts show that the three structures emphasize different error modes; they do not reverse the headline predictive ranking.

Regime summaries also changed the ordering within the conceptual group (Table 4; Figure 2). In snow-dominated basins, Xinanjiang and HBV-lite reached median NSE values of {regime.loc['snow-dominated', 'XAJ_median_nse']:.6f} and {regime.loc['snow-dominated', 'HBV_median_nse']:.6f}, respectively, compared with {regime.loc['snow-dominated', 'GR4J_median_nse']:.6f} for GR4J. The LSTM ensemble remained higher at {regime.loc['snow-dominated', 'LSTM_ensemble_8seed_median_nse']:.6f}, and Figure 4 shows the basin-level distribution of the LSTM margin over the best conceptual model within each regime. The regime result motivates using multiple conceptual references rather than interpreting a single conceptual model as representative of all explicit hydrological structures.

<!-- Evidence: tables/conceptual_diagnostics.csv; tables/conceptual_winners.csv; tables/regime_summary.csv -->

### 3.3 Concentration of the LSTM advantage

The positive LSTM advantage was not distributed in proportion to context frequency (Table 7). Snow-dominated spring contexts had a context share of {advantage['snow_mam_context_share']:.6f} but accounted for {advantage['snow_mam_gap_share']:.6f} of the total positive row-wise gap. Their concentration ratio was {advantage['snow_mam_ratio']:.6f}, and all three conceptual references had higher MAE than the LSTM in {advantage['snow_mam_shared_failure']:.6f} of those rows.

The concentration was stronger for snow-dominated high-flow contexts. They represented {advantage['snow_high_context_share']:.6f} of basin-flow rows but accounted for {advantage['snow_high_gap_share']:.6f} of the positive row-wise gap, for a concentration ratio of {advantage['snow_high_ratio']:.6f}. Their shared failure rate was {advantage['snow_high_shared_failure']:.6f}. Thus, a context covering less than one tenth of basin-flow rows contributed more than one third of the row-summed positive LSTM advantage relative to the lowest-mean-absolute-error conceptual comparator in each row.

The complete audit contained {heterogeneity['cell_counts']['regime_season']} regime-season cells, {heterogeneity['cell_counts']['regime_flow']} regime-flow cells, and {heterogeneity['cell_counts']['joint']} joint cells. When the registered regime-flow rows were added within flow group, high flow represented {heterogeneity['flow']['high']['context_share']:.2%} of contexts and {heterogeneity['flow']['high']['positive_best_gap_share']:.2%} of the row-summed positive absolute-error gap, for a concentration ratio of {heterogeneity['flow']['high']['concentration_ratio']:.3f}. Middle flow contributed {heterogeneity['flow']['mid']['positive_best_gap_share']:.2%} of the gap (ratio {heterogeneity['flow']['mid']['concentration_ratio']:.3f}), and low flow contributed {heterogeneity['flow']['low']['positive_best_gap_share']:.2%} (ratio {heterogeneity['flow']['low']['concentration_ratio']:.3f}). Every low-flow regime cell had a concentration ratio below one; the maximum was {heterogeneity['max_low_flow_ratio']:.3f} in snow-dominated basins.

Across seasons, spring accounted for {heterogeneity['season']['MAM']['positive_best_gap_share']:.2%} of the gap (ratio {heterogeneity['season']['MAM']['concentration_ratio']:.3f}), winter for {heterogeneity['season']['DJF']['positive_best_gap_share']:.2%} (ratio {heterogeneity['season']['DJF']['concentration_ratio']:.3f}), autumn for {heterogeneity['season']['SON']['positive_best_gap_share']:.2%} (ratio {heterogeneity['season']['SON']['concentration_ratio']:.3f}), and summer for {heterogeneity['season']['JJA']['positive_best_gap_share']:.2%} (ratio {heterogeneity['season']['JJA']['concentration_ratio']:.3f}). Snow-dominated rows made up {heterogeneity['regime']['snow-dominated']['context_share']:.2%} of the regime-season matrix but contributed {heterogeneity['regime']['snow-dominated']['positive_best_gap_share']:.2%} of its positive gap (ratio {heterogeneity['regime']['snow-dominated']['concentration_ratio']:.3f}). These additive summaries are reported in `tables/context_dimension_summary.csv`.
{day_accounting_paragraph}

Figure 5 displays all 48 joint cells using concentration ratio and shared failure together. The second panel is essential because a large positive-gap share need not describe the typical row: semi-humid autumn high flow had a concentration ratio of {heterogeneity['ratio_only_counterexample']['concentration_ratio']:.3f}, but its median lowest-conceptual-MAE-minus-LSTM gap was {heterogeneity['ratio_only_counterexample']['median_gap']:.3f} mm per day and its shared-failure rate was only {heterogeneity['ratio_only_counterexample']['shared_failure_rate']:.1%}. This counterexample prevents a ratio-only reading of the matrix.

**Table 7. Concentration of the positive LSTM advantage in three headline contexts.**

| Context | Context share | Positive row-wise gap share | Concentration ratio | Shared failure rate |
| --- | ---: | ---: | ---: | ---: |
| Snow-dominated / spring | {advantage['snow_mam_context_share']:.6f} | {advantage['snow_mam_gap_share']:.6f} | {advantage['snow_mam_ratio']:.6f} | {advantage['snow_mam_shared_failure']:.6f} |
| Snow-dominated / high flow | {advantage['snow_high_context_share']:.6f} | {advantage['snow_high_gap_share']:.6f} | {advantage['snow_high_ratio']:.6f} | {advantage['snow_high_shared_failure']:.6f} |
| Snow-dominated / spring / high flow | {advantage['snow_mam_high_context_share']:.6f} | {advantage['snow_mam_high_gap_share']:.6f} | {advantage['snow_mam_high_ratio']:.6f} | {advantage['snow_mam_high_shared_failure']:.6f} |

Table numbering follows the complete evidence package: Tables 2 through 6 contain the paired comparison, conceptual diagnostics, regime summary, parameter accounting, and fairness audit and are supplied as separately generated supporting tables. Table 7 is a compact view of the saved season, flow-group, and joint decomposition tables. It does not introduce a separate selection result. Its purpose is to show context prevalence, contribution to the positive gap, concentration, and agreement among the three conceptual failures side by side; each share is interpreted only within its context family.

{robustness['results']}
<!-- Evidence: tables/lstm_advantage_concentration.csv; tables/flow_day_weighted_summary.csv; {evidence['season']}; {evidence['flow']}; {evidence['joint']} -->

### 3.4 Population-level support

The concentration signal was also visible in basin-wide attribute relationships. Across all 531 basins, snow fraction was positively associated with the LSTM margin over the basin-wise conceptual comparator with the highest NSE (Spearman rho = {population['basin_snow_rho']:.3f}, q = {population['basin_snow_q']:.2e}). The result indicates that larger LSTM margins tended to occur in basins with a larger long-term snow fraction. It does not state that snow fraction alone determines model performance.

The basin-wide screen covered {heterogeneity['static_attribute_count']} primary static attributes: nine climate, six topographic, eleven soil, five geological, and eight vegetation attributes. Snow fraction had the largest absolute bivariate association with the LSTM margin. {heterogeneity['static_significant_count']} of the 39 correlations passed the false-discovery-rate threshold. Smaller associations were present for latitude (rho = {heterogeneity['top_attributes']['topo_gauge_lat']['rho']:.3f}), vegetation greenness seasonality (rho = {heterogeneity['top_attributes']['vege_gvf_diff']['rho']:.3f}), mean elevation (rho = {heterogeneity['top_attributes']['topo_elev_mean']['rho']:.3f}), mean potential evapotranspiration (rho = {heterogeneity['top_attributes']['clim_pet_mean']['rho']:.3f}), and mean precipitation (rho = {heterogeneity['top_attributes']['clim_p_mean']['rho']:.3f}). These covarying attributes show that snow fraction is a marker within a broader hydroclimatic and landscape gradient, not an independently identified driver.

A seasonal counterexample further bounds the interpretation. The winter MAE gap was not monotonically associated with snow fraction (rho = {heterogeneity['winter_snow_rho']:.3f}, q = {heterogeneity['winter_snow_q']:.3f}), whereas its association with aridity was stronger (rho = {heterogeneity['winter_aridity_rho']:.3f}, q = {heterogeneity['winter_aridity_q']:.2e}). Snow fraction also participates in the snow-dominated regime definition. The regime matrix and the continuous-attribute correlations are therefore convergent descriptive views, not independent causal replications.

Context-specific residual relationships pointed in the same direction. For spring, the row-wise lowest-conceptual-MAE-minus-LSTM gap was positively associated with snow fraction (rho = {population['mam_snow_rho']:.3f}, q = {population['mam_snow_q']:.2e}). For high-flow rows, the corresponding association was rho = {population['high_snow_rho']:.3f}, q = {population['high_snow_q']:.2e}. This population-level support reduces reliance on selected hydrographs: the direction of the snow signal appears across the full basin panel and in both spring and high-flow residual summaries.

<!-- Evidence: {evidence['spearman']}; {evidence['seasonal_links']}; {evidence['flow_links']} -->

### 3.5 Joint context refinement

Combining regime, season, and flow group identified snow-dominated spring high flow as the retained joint context with the highest concentration ratio. This group had a context share of {advantage['snow_mam_high_context_share']:.6f} and a positive row-wise gap share of {advantage['snow_mam_high_gap_share']:.6f}. The concentration ratio was {advantage['snow_mam_high_ratio']:.6f}, and the shared failure rate was {advantage['snow_mam_high_shared_failure']:.6f}. In counts, all three conceptual models had higher MAE than the LSTM in {advantage['snow_mam_high_shared_failure_count']} of {advantage['snow_mam_high_n_contexts']} valid rows.

The snow-dominated high-flow concentration extended across all four seasons: {heterogeneity['snow_high']['MAM']['concentration_ratio']:.6f} in spring, {heterogeneity['snow_high']['DJF']['concentration_ratio']:.6f} in winter, {heterogeneity['snow_high']['JJA']['concentration_ratio']:.6f} in summer, and {heterogeneity['snow_high']['SON']['concentration_ratio']:.6f} in autumn. {joint_context_boundary}

This joint context refinement sharpens the empirical location of the advantage without assigning an event mechanism. The group is defined by basin regime, calendar season, and flow quantile, not by observed labels for snowmelt, rainfall-on-snow, or other event types. The result is therefore a localized shared-failure pattern among the three evaluated conceptual models.

<!-- Evidence: {evidence['joint']}; tables/protocol_robustness.csv -->

### 3.6 Oracle diagnostic

The four-model oracle reached a median NSE of {oracle.loc['four_model_oracle_median_nse']:.6f}, compared with {oracle.loc['lstm_ensemble_median_nse']:.6f} for the LSTM ensemble. The median oracle gain over the LSTM was {oracle.loc['four_model_oracle_minus_lstm_median']:.6f}. A conceptual model had the highest basin-wise NSE in {int(oracle.loc['conceptual_beats_lstm_count'])} basins, but the median oracle result provides no evidence for a general deployable predictive complement. The oracle is descriptive because it uses evaluation-period outcomes to select the best model separately for each basin.

<!-- Evidence: tables/oracle.csv -->

### 3.7 Sensitivity to the benchmark protocol

The three central results hold under both protocols. Between the earlier published benchmark and the rebuild reported here, the snow-dominated spring share of the positive row-wise gap moves from 0.185779 to {advantage['snow_mam_gap_share']:.6f}, the snow-dominated high-flow share from 0.361229 to {advantage['snow_high_gap_share']:.6f}, and the joint snow-dominated spring high-flow share from 0.136150 to {advantage['snow_mam_high_gap_share']:.6f}. The rank correlation between snow fraction and the neural margin moves from 0.428937 to {population['basin_snow_rho']:.6f}. Every context share is identical by construction, because the context definitions and the basin set did not change.

Two movements deserve naming rather than burying. The shared failure rate in the joint context falls from 0.914474 to {advantage['snow_mam_high_shared_failure']:.6f}, which crosses the rounding boundary a reader anchors on. And while snow-dominated spring high flow remains the most concentrated retained joint context under both protocols, its margin over snow-dominated winter high flow narrows from 0.553 to 0.210; it is the most concentrated context, not one far ahead of the rest.

<!-- Evidence: tables/protocol_robustness.csv -->

{robustness['protocol']}

{process['results']}
{cause['results']}
{kge['results']}
{objective['results']}
## 4. Discussion

### 4.1 One contribution with two evidence layers

Sections 3.3 through 3.5 form one argument at increasing resolution. The concentration analysis first shows that snow-dominated spring and high-flow contexts contribute more to the positive row-wise gap than their prevalence would imply. The population analysis then shows that the snow-linked margin extends across the basin sample rather than depending on selected hydrographs. Finally, the joint analysis localizes the retained combination of regime, season, and flow group with the highest concentration ratio.

{robustness['discussion']}

Within that hierarchy, the complete matrix details the absolute-scale branch beyond one winning cell. On the absolute-MAE scale used here, high flow is the primary dimension of the per-day positive margin; snow-dominated basins amplify that concentration; and spring and winter are the two largest snow-dominated high-flow cells. Summer and autumn snow-dominated high flow also remain above proportional concentration. The absolute-scale result is therefore broader than a spring-only snowmelt story.

### 4.2 Interpretation of the snow-linked concentration

The observed concentration is an empirical agreement pattern: in snow-dominated spring high-flow rows, all three evaluated conceptual structures usually had larger MAE than the regional LSTM. Their rainfall-runoff structures differ; GR4J and Xinanjiang share the tested external snow path, whereas HBV-lite uses an intrinsic snow routine. Their shared failure rate was {advantage['snow_mam_high_shared_failure']:.6f} in the retained joint context with the highest concentration ratio. This convergence is informative because it is less dependent on the idiosyncrasy of one conceptual formulation, but the analysis does not identify which storage, timing, or event process produced the errors.

At the same time, the analysis cannot determine why the LSTM is better in these rows. Regional learning may exploit cross-basin information, static attributes may condition responses, and the flexible recurrent representation may accommodate temporal dependencies that are constrained in the conceptual models. The present evidence does not separate these explanations. The phrase “snow-linked concentration” therefore denotes an empirical association with basin snow fraction, spring, and high flow; it is not a causal attribution to a particular snow process.

### 4.3 What conceptual references add after predictive dominance

The conceptual models add a coordinate system for error analysis. A single aggregate LSTM score states that the neural model performs better overall, but it does not show whether that margin is spread across ordinary conditions or concentrated in a small set of hydrological contexts. Multiple conceptual structures make it possible to distinguish a structure-specific weakness from a shared pattern. The concentration ratio then compares the frequency of a context with its contribution to the row-summed positive gap. Selecting the lowest-mean-absolute-error conceptual comparator in each row prevents one weak structure from defining the comparison, while shared failure measures agreement across all three references. Population-level support and joint context refinement strengthen the diagnostic claim without becoming separate predictive methods or changing the test-period ranking.

This diagnostic use does not imply that conceptual models should be attached to the LSTM in deployment. The oracle median gain is zero, and the current analysis contains no validation-selected switching or blending rule. Nor does it imply that the three models span all plausible conceptual structures. The claim is limited to GR4J, Xinanjiang, and HBV-lite under the audited protocol.

### 4.4 Implications for benchmark design

Large-sample model comparisons can separate predictive ranking from diagnostic interpretation. The predictive ranking should be reported plainly and with information differences disclosed. Diagnostic analyses can then ask where errors concentrate, provided that context definitions and post-hoc status are explicit. This separation avoids two common overstatements: treating a lower-performing conceptual model as a competitive predictor, and treating an error association as evidence that a neural network has learned a physically correct process.

The compact concentration table also offers a reusable reporting pattern. A context should not be emphasized only because it has a large average gap; its prevalence and its share of the total positive gap should be shown together. Shared failure adds information about whether the conclusion depends on one conceptual structure. These quantities can be applied to other saved prediction sets, but their scientific interpretation remains specific to the models, data, split, and context definitions used.

### 4.5 Relation to prior work

The result complements, rather than replaces, earlier findings. Kratzert et al. (2019) established strong regional LSTM performance and the value of basin attributes. Lees et al. (2021) documented spatial and seasonal performance patterns in neural-versus-conceptual comparisons, Mai et al. (2022) reported the same neural-over-conceptual ranking across the Great Lakes region, and Frame et al. (2022) showed that the LSTM margin persists for extreme events. Knoben et al. (2019) emphasized objective comparison across conceptual structures. On the objective side, Gupta et al. (2009) showed analytically that optimising a squared-error criterion pulls the simulated variability ratio below one and toward the correlation coefficient, and Lin et al. (2024) trained neural streamflow models under alternative objective functions and combined them into an ensemble. The present analysis combines these directions in a narrow diagnostic benchmark: three model families are audited under one conceptual protocol, placed below a reproduced LSTM reference, and used to quantify the concentration of the neural advantage. What none of these lines reports is the symmetric step taken here: refitting an LSTM and three conceptual structures under the same change of calibration objective and separating the shared amplitude response from the structure-specific differences in daily correlation and event shape. Because related work already covers generic structure comparison, seasonal analysis, and single-family objective variation, the contribution is the integrated, quantitatively traced decomposition rather than the individual ingredients.

{process['discussion']}
{kge['discussion']}
{objective['discussion']}
{cause['discussion']}
## 5. Limitations

The most important limitation is information asymmetry. The LSTM uses regional training and 27 static basin attributes, while the conceptual models are calibrated individually. Sharing basins, forcing, dates, and observed targets does not make the predictive information identical. Accordingly, the paper describes an LSTM reference and conceptual structural probes, not a strict same-information competition.

The 39 static-attribute results are bivariate and the attributes are correlated. Snow fraction covaries with latitude, elevation, energy availability, precipitation, vegetation, soil, and geology, and it also contributes to the regime classification. The analysis does not estimate an independent snow effect. Likewise, the context-specific link tables contain four static attributes and two model-derived diagnostics, so their six variables are not six independent landscape controls.

The decomposition is post-hoc and associational. It uses saved evaluation-period predictions and cannot be interpreted as independent model selection. Contexts are defined by broad regime, season, and flow groups. No event labels identify snowmelt, rainfall-on-snow, frozen-soil effects, or reservoir operations. The snow fraction correlations support population-level alignment but do not establish causal pathways or internal neural representations.

The conceptual sample includes three model families, not the full space of hydrological structures. Shared failure means agreement among GR4J, Xinanjiang, and HBV-lite under this protocol. It is not a theoretical ceiling for conceptual hydrology. Model-specific bounds, numerical implementations, and snow routines remain part of the comparison even though calibration budgets and external conditions were audited.

The original concentration metric accumulates positive MAE differences in millimetres per day, so its high-flow emphasis locates absolute error reduction. The dimensionless analysis now addresses that scale ambiguity directly and leads to a different relative ranking rather than retroactively turning absolute concentration into a scale-free skill score.

{robustness['limitations']}

{process['limitations']}
{cause['limitations']}
{kge['limitations']}
{objective['limitations']}

The daily LSTM residual archive is available for post-hoc analysis, whereas the main headline table remains NSE-based. Selected hydrographs have illustrative value only. The full-population residual analyses reduce but do not remove dependence on the chosen context definitions and error metric. Alternative flow thresholds, seasons, or absolute-error transformations could redistribute the concentration.

Finally, the evidence package is auditable and rebuildable as a registered snapshot. Its {_snapshot_input_count_phrase()} are pinned by byte size and SHA-256 digest and packaged in a single content-pinned local external archive. Extracting that archive into the committed clean checkout reproduces the 14 top-level files. The committed clean checkout has been verified by rebuilding those files twice with zero digest differences. A full conceptual recalibration would be a higher-cost reproduction step, but it is not required for the narrow diagnostic interpretation reported here.

## 6. Conclusions

An aggregate ranking does not reveal how a predictive margin is distributed across hydrological contexts. Across 531 CAMELS-US basins, the reproduced eight-seed LSTM ensemble achieved a median NSE of {main.loc['LSTM_ensemble_8seed', 'median_nse']:.6f}, compared with {main.loc['GR4J', 'median_nse']:.6f} for the strongest single conceptual model, GR4J. That ranking defines the study boundary rather than its novelty; the contribution is the audited answer to where that margin accumulates.

The answer is scale-dependent. On the absolute-error scale, the advantage was largest per day at high flow ({heterogeneity['flow']['high']['positive_best_gap_share']:.1%} of the row-summed positive gap from {heterogeneity['flow']['high']['context_share']:.1%} of basin-flow contexts) and was further amplified in snow-dominated basins, with snow-dominated spring high flow the most concentrated retained joint context and population-level support from the snow-fraction association (rho = {population['basin_snow_rho']:.3f}). On the dimensionless relative scale, middle flow carried the largest concentration and the most consistent shared conceptual failure, while snow-dominated basins showed a broader relative advantage across the hydrograph. The complete 16-, 12-, and 48-cell hierarchy remained rank-stable when the whole benchmark was rebuilt under the common protocol. The section 3 tables and figures retain the full cell-level numbers behind this summary.

The process diagnostics bound that answer. All four models—including the LSTM—compressed upper-flow variability and underpredicted aligned event peaks and seven-day event volumes, so the shared amplitude problem cannot be attributed to conceptual structure alone; the LSTM usually reduces it rather than eliminating it. Event-peak concentration separated the structures (GR4J close to the LSTM; Xinanjiang and HBV-lite lower), most of the mean high-flow efficiency advantage was arithmetically associated with stronger daily correlation and less variability compression, and precipitation-product disagreement showed a weak association with the common event-volume error that is consistent with, but does not establish, a role for input uncertainty. None of these diagnostics identifies causal shares or physically correct neural processes.

The results therefore support a diagnostic role for several audited conceptual structures after predictive dominance has been established, not a deployable hybrid: the oracle's median gain is zero and no validation-selected switching rule was built. The decomposition is post-hoc and associational, and the claims are limited to GR4J, Xinanjiang, and HBV-lite under this audited protocol. The evidence package, including all tables, figures, and this manuscript, is rebuildable from a registered snapshot with pinned inputs, so each reported number remains traceable to saved artifacts.

## Data and Code Availability

The manuscript evidence package is stored under `draft/papers/10_18_conceptual_lstm_package`. {_snapshot_input_count_phrase()} are registered by relative path, role, byte size, and SHA-256 digest and packaged in a single content-pinned local external archive. Core numbers are mapped to structured output cells in `reproducibility/core_evidence_map.csv`. The package build command is `python -X utf8 -m src.lstm_fair_531.scripts.build_manuscript_evidence_package --verify-snapshot`. The committed clean checkout plus the extracted archive reproduces the registered snapshot; no working-tree overlay is required.

## References

Addor, N., Newman, A. J., Mizukami, N., & Clark, M. P. (2017). The CAMELS data set: catchment attributes and meteorology for large-sample studies. *Hydrology and Earth System Sciences*, 21(10), 5293-5313. https://doi.org/10.5194/hess-21-5293-2017

Benjamini, Y., & Hochberg, Y. (1995). Controlling the false discovery rate: a practical and powerful approach to multiple testing. *Journal of the Royal Statistical Society: Series B (Methodological)*, 57(1), 289-300. https://doi.org/10.1111/j.2517-6161.1995.tb02031.x

Bergström, S. (1976). *Development and application of a conceptual runoff model for Scandinavian catchments* (SMHI Reports RHO No. 7). Swedish Meteorological and Hydrological Institute, Norrköping.

Efron, B. (1979). Bootstrap methods: another look at the jackknife. *The Annals of Statistics*, 7(1), 1-26. https://doi.org/10.1214/aos/1176344552

Frame, J. M., Kratzert, F., Klotz, D., Gauch, M., Shalev, G., Gilon, O., Qualls, L. M., Gupta, H. V., & Nearing, G. S. (2022). Deep learning rainfall-runoff predictions of extreme events. *Hydrology and Earth System Sciences*, 26(13), 3377-3392. https://doi.org/10.5194/hess-26-3377-2022

Gupta, H. V., Kling, H., Yilmaz, K. K., & Martinez, G. F. (2009). Decomposition of the mean squared error and NSE performance criteria: implications for improving hydrological modelling. *Journal of Hydrology*, 377(1-2), 80-91. https://doi.org/10.1016/j.jhydrol.2009.08.003

Hansen, N., & Ostermeier, A. (2001). Completely derandomized self-adaptation in evolution strategies. *Evolutionary Computation*, 9(2), 159-195. https://doi.org/10.1162/106365601750190398

Hochreiter, S., & Schmidhuber, J. (1997). Long short-term memory. *Neural Computation*, 9(8), 1735-1780. https://doi.org/10.1162/neco.1997.9.8.1735

Holm, S. (1979). A simple sequentially rejective multiple test procedure. *Scandinavian Journal of Statistics*, 6(2), 65-70.

Kingma, D. P., & Ba, J. (2015). Adam: a method for stochastic optimization. *3rd International Conference on Learning Representations (ICLR 2015)*, San Diego. https://arxiv.org/abs/1412.6980

Knoben, W. J. M., Freer, J. E., Fowler, K. J. A., Peel, M. C., & Woods, R. A. (2019). Modular Assessment of Rainfall-Runoff Models Toolbox (MARRMoT) v1.2: an open-source, extendable framework providing implementations of 46 conceptual hydrologic models as continuous state-space formulations. *Geoscientific Model Development*, 12(6), 2463-2480. https://doi.org/10.5194/gmd-12-2463-2019

Kratzert, F. (2019). CAMELS benchmark models [Data set]. HydroShare. https://www.hydroshare.org/resource/474ecc37e7db45baa425cdb4fc1b61e1/

Kratzert, F., Klotz, D., Shalev, G., Klambauer, G., Hochreiter, S., & Nearing, G. (2019). Towards learning universal, regional, and local hydrological behaviors via machine learning applied to large-sample datasets. *Hydrology and Earth System Sciences*, 23(12), 5089-5110. https://doi.org/10.5194/hess-23-5089-2019

Kratzert, F., Gauch, M., Nearing, G., & Klotz, D. (2022). NeuralHydrology - a Python library for deep learning research in hydrology. *Journal of Open Source Software*, 7(71), 4050. https://doi.org/10.21105/joss.04050

Lees, T., Buechel, M., Anderson, B., Slater, L., Reece, S., Coxon, G., & Dadson, S. J. (2021). Benchmarking data-driven rainfall-runoff models in Great Britain: a comparison of long short-term memory (LSTM)-based models with four lumped conceptual models. *Hydrology and Earth System Sciences*, 25(10), 5517-5534. https://doi.org/10.5194/hess-25-5517-2021

Lin, Y., Wang, D., Zhu, J., Sun, W., Shen, C., & Shangguan, W. (2024). Development of objective function-based ensemble model for streamflow forecasts. *Journal of Hydrology*, 632, 130861. https://doi.org/10.1016/j.jhydrol.2024.130861

Mai, J., Shen, H., Tolson, B. A., Gaborit, É., Arsenault, R., Craig, J. R., Fortin, V., Fry, L. M., Gauch, M., Klotz, D., Kratzert, F., O'Brien, N., Princz, D. G., Rasiya Koya, S., Roy, T., Seglenieks, F., Shrestha, N. K., Temgoua, A. G. T., Vionnet, V., & Waddell, J. W. (2022). The Great Lakes Runoff Intercomparison Project Phase 4: the Great Lakes (GRIP-GL). *Hydrology and Earth System Sciences*, 26(13), 3537-3572. https://doi.org/10.5194/hess-26-3537-2022

Maurer, E. P., Wood, A. W., Adam, J. C., Lettenmaier, D. P., & Nijssen, B. (2002). A long-term hydrologically based dataset of land surface fluxes and states for the conterminous United States. *Journal of Climate*, 15(22), 3237-3251. https://doi.org/10.1175/1520-0442(2002)015<3237:ALTHBD>2.0.CO;2

Nash, J. E., & Sutcliffe, J. V. (1970). River flow forecasting through conceptual models part I - a discussion of principles. *Journal of Hydrology*, 10(3), 282-290. https://doi.org/10.1016/0022-1694(70)90255-6

Newman, A. J., Clark, M. P., Sampson, K., Wood, A., Hay, L. E., Bock, A., Viger, R. J., Blodgett, D., Brekke, L., Arnold, J. R., Hopson, T., & Duan, Q. (2015). Development of a large-sample watershed-scale hydrometeorological data set for the contiguous USA: data set characteristics and assessment of regional variability in hydrologic model performance. *Hydrology and Earth System Sciences*, 19(1), 209-223. https://doi.org/10.5194/hess-19-209-2015

Perrin, C., Michel, C., & Andréassian, V. (2003). Improvement of a parsimonious model for streamflow simulation. *Journal of Hydrology*, 279(1-4), 275-289. https://doi.org/10.1016/S0022-1694(03)00225-7

Thornton, P. E., Running, S. W., & White, M. A. (1997). Generating surfaces of daily meteorological variables over large regions of complex terrain. *Journal of Hydrology*, 190(3-4), 214-251. https://doi.org/10.1016/S0022-1694(96)03128-9

Wang, Z., Tarasova, L., & Merz, R. (2026). Event-type-based multi-dimensional diagnostics of process limitations in hydrological models. *Water Resources Research*, 62(2), e2025WR040264. https://doi.org/10.1029/2025WR040264

Wilcoxon, F. (1945). Individual comparisons by ranking methods. *Biometrics Bulletin*, 1(6), 80-83. https://doi.org/10.2307/3001968

Xia, Y., Mitchell, K., Ek, M., Sheffield, J., Cosgrove, B., Wood, E., Luo, L., Alonge, C., Wei, H., Meng, J., Livneh, B., Lettenmaier, D., Koren, V., Duan, Q., Mo, K., Fan, Y., & Mocko, D. (2012). Continental-scale water and energy flux analysis and validation for the North American Land Data Assimilation System project phase 2 (NLDAS-2): 1. Intercomparison and application of model products. *Journal of Geophysical Research: Atmospheres*, 117, D03109. https://doi.org/10.1029/2011JD016048

Zhao, R.-J. (1992). The Xinanjiang model applied in China. *Journal of Hydrology*, 135(1-4), 371-381. https://doi.org/10.1016/0022-1694(92)90096-E
"""
    (out_dir / "manuscript_full_draft.md").write_text(text, encoding="utf-8")


def _write_figure_table_captions(out_dir: Path, tables: Dict[str, pd.DataFrame]) -> None:
    text = """# Figure and table captions


## Main Tables

Table 1. Full-531 benchmark summary. Basin-wise NSE medians and means for GR4J+PDD, XAJ+PDD, HBV-lite, a seed-100 LSTM, and the eight-seed LSTM ensemble under the same CAMELS-US reverse split and Maurer forcing. The table establishes the LSTM ensemble as the strongest evaluated predictor and GR4J as the strongest conceptual baseline.

Table 2. Paired LSTM-versus-conceptual comparisons. Per-basin paired differences, LSTM win rates, Wilcoxon tests, and bootstrap confidence intervals compare the eight-seed LSTM ensemble against each conceptual model on the common 531 basins.

Table 3. Conceptual diagnostic metrics. KGE, absolute bias, absolute peak bias, absolute low-flow bias, calibration-evaluation gap, and failure counts summarize how the three conceptual models trade overall efficiency against interpretable flow-signature behavior.

Table 4. Regime-wise benchmark summary. Median NSE values by hydrologic regime show how conceptual model rankings shift relative to the LSTM reference, especially in snow-dominated basins.

Table 5. Parameter accounting and snow-module status. Nominal and effective active parameter counts distinguish GR4J/XAJ external PDD front ends from the intrinsic HBV-lite snow routine.


Table 6. Fairness audit summary. Structure, calibration, stale-reference, and bounds checks classify each potential fairness issue as effective-equivalent, model-intrinsic, aligned, disclosed, or historical-only.

Table 7. Concentration of the LSTM advantage in three headline hydrologic contexts. Context share is compared with the share of the positive best-conceptual-minus-LSTM mean absolute error gap; their ratio measures concentration, and shared failure rate is the fraction of contexts in which GR4J, XAJ, and HBV all have higher mean absolute error than the LSTM.

Supplementary Table S1. Additive context-dimension summary. The complete registered regime-season and regime-flow matrices are added within season, flow group, and hydrological regime to report context count, context share, positive absolute-error-gap share, concentration ratio, and count-weighted shared-failure rate.

Supplementary Table S2. Scale and threshold robustness summary. Absolute MAE advantage, symmetric dimensionless relative advantage, concentration ratios, median effects, and win rates (equivalently, shared-failure rates under the minimum-error comparator) are reported for every regime, season, flow group, and joint context under fixed 5th/95th, 10th/90th, and 20th/80th discharge thresholds.

Supplementary Table S3. Whole-basin bootstrap intervals. Ninety-five percent intervals use 10,000 basin-clustered replicates stratified by the four frozen hydrological regimes.

Supplementary Table S4. Fixed contrast families. Flow-group, snow-versus-pooled-non-snow, and snow-high seasonal contrasts report common-basin estimates, clustered intervals, and within-family Holm adjustment; the seasonal family is post-hoc.

Supplementary Table S5. Full benchmark-protocol stability. Rank retention, classification flips, direction changes, and maximum shifts cover all 16 regime-season cells, 12 regime-flow cells, 48 joint cells, and 39 primary static attributes.

Supplementary Table S6. Cell-level benchmark-protocol differences. Every registered cell and primary attribute is retained, including changes that oppose the headline direction.

## Figures

Figure 1. Empirical CDF of basin-wise NSE. The main axis is truncated at NSE = -1 so that the bulk of the distribution stays readable; the inset repeats all 531 basins over the full range, and an annotation reports the per-model count of basins below the truncation point, so no basin is dropped from the display. The LSTM ensemble distribution lies to the right of all conceptual models, while GR4J is the strongest conceptual distribution.

Figure 2. Regime-wise median NSE. Median performance by hydrologic regime shows both the overall LSTM lead and regime-specific conceptual model shifts.

Figure 3. Conceptual-model diagnostic trade-offs. Median absolute bias, peak bias, low-flow bias, and calibration-evaluation gap show that different conceptual structures emphasize different error modes.

Figure 4. LSTM margin over the best conceptual model by regime. The distribution of LSTM ensemble NSE minus the best conceptual NSE shows that conceptual models occasionally win individual basins, but do not provide a median predictive complement to the LSTM.

Figure 5. Complete joint context heterogeneity. Two 4-by-12 heat maps show all 48 hydrological-regime-by-season-by-flow-group cells. Panel A reports positive absolute-MAE-gap concentration ratio and valid context count; Panel B reports the fraction of rows in which all three conceptual models have higher MAE than the LSTM. Ratios above one indicate disproportionate contribution to the row-summed positive absolute-error gap, not scale-free skill or causal process attribution.

Figure 6. Scale and threshold robustness. Panels A and B separate per-day absolute-error concentration from dimensionless relative-advantage concentration across three fixed discharge partitions. Panel C compares snow-dominated and pooled non-snow basins within each flow group. Panel D shows the bounded post-hoc snow-high seasonal contrast family at the 10th/90th partition. Intervals resample whole basins within frozen hydrological regimes; no additional rainfall-runoff model is introduced.
"""


    if "hydrological_flow_bias_summary" in tables:
        text += """

Supplementary Table S7. Flow-group, upper-tail, and full-period bias diagnostics. Basin-median signed bias, upper-tail flow-duration-curve bias, and standard-deviation ratio are reported with whole-basin intervals for all four models and four hydrological regimes plus the pooled sample.

Supplementary Table S8. Observed-event diagnostics. Seasonal and regime summaries cover observed 90th- and 95th-percentile events, aligned peak magnitude, timing, seven-day volume, and detection for all four models.

Supplementary Table S9. Registered decision gates. The fixed timing-or-shape and snow-forcing-proxy rules are reported with every numerical decision, including the two Xinanjiang contrasts that prevent a universal snow-specific claim.

Figure 7. Flow-duration and observed-event diagnostics. Panel A shows same-date signed bias by observed-flow group. Panel B compares aligned 90th-percentile event peak magnitude with seven-day volume. Panels C and D show seasonal aligned peak magnitude and absolute timing error. Events are defined from observations; negative magnitude and volume values indicate underprediction.
"""
    if "cause_amplitude_geometry_summary" in tables:
        text += """

Supplementary Table S10. Daily amplitude geometry and oracle moment matching. Correlation, standard-deviation ratio, high-flow bias before and after evaluation-period moment matching, and negative transformed-flow fractions are reported for all four models.

Supplementary Table S11. Event-peak concentration and paired model contrasts. Basin-equal summaries at the observed 90th- and 95th-percentile event definitions separate aligned peak attenuation from seven-day event-volume attenuation.

Supplementary Table S12. Precipitation-product disagreement. Within-basin-centred associations compare Maurer precipitation with the three-product consensus, Daymet, and the North American Land Data Assimilation System; whole-basin intervals are used for basin-level summaries.

Figure 8. Post-hoc cause diagnostics. Panel A compares daily correlation with the simulated-to-observed standard-deviation ratio. Panel B shows event-peak concentration at two fixed thresholds. Panel C gives paired LSTM-minus-conceptual shape contrasts. Panel D shows the four-model common event-volume error across within-basin precipitation-gap quartiles. The figure separates empirical signatures and does not identify causal shares.
"""
    if "kge_component_summary" in tables:
        text += """

Supplementary Table S13. Kling–Gupta efficiency components by hydrological context. The 2009 formulation is summarized by daily correlation, simulated-to-observed standard-deviation ratio, and simulated-to-observed mean-flow ratio for the full period, four seasons, flow groups, the highest 5% sensitivity, and snow groups.

Supplementary Table S14. Paired arithmetic attribution of Kling–Gupta efficiency differences. All six component-replacement orders are averaged within basin and uncertainty resamples whole basins. The terms close to the paired efficiency difference but do not identify causal processes.

Figure 9. Kling–Gupta efficiency component diagnosis. Panel A shows full-period median efficiency. Panel B compares the three components on the highest 10% observed-flow days. Panel C partitions each mean high-flow LSTM-versus-conceptual efficiency difference into exact arithmetic terms. Low-flow component ratios are excluded because zero and near-zero observed variability make them numerically unstable.
"""
    if "lstm_registered_config_provenance" in tables:
        text += """

Supplementary Table S15. Registered long short-term memory network configuration provenance. The table lists the eight seed-specific registered configuration paths, byte sizes, SHA-256 digests, training-target and evaluation dates, validation-date availability, epoch count, loss, and the cross-seed invariant-settings check.
"""
    if "flow_day_weighted_summary" in tables:
        text += """

Supplementary Table S16. Row-based and day-weighted flow-group accounting. For each flow group the table reports the context count and share, the day count and share, and the share of the positive best-conceptual-minus-LSTM mean-absolute-error gap under row-equal weighting (the per-day error-reduction rate) and under day weighting (accumulated millimetres), with the concentration ratio for each accounting.
"""
    if "context_scale_threshold_summary" not in tables:
        common_protocol_only = (
            "Supplementary Table S2.", "Supplementary Table S3.", "Supplementary Table S4.",
            "Supplementary Table S5.", "Supplementary Table S6.", "Figure 6.",
        )
        text = "\n".join(
            line for line in text.splitlines() if not line.startswith(common_protocol_only)
        ) + "\n"
    (out_dir / "figure_table_captions.md").write_text(text, encoding="utf-8")


def _write_reviewer_risk_checklist(out_dir: Path, tables: Dict[str, pd.DataFrame]) -> None:
    oracle = tables["oracle"].set_index("quantity")["value"]
    conceptual_wins = int(oracle.loc["conceptual_beats_lstm_count"])
    rows = [
        {
            "risk": "Reviewer says the paper only shows LSTM beats conceptual models.",
            "current_defense": "The LSTM win is treated as a boundary condition; the contribution is decomposing where the LSTM-vs-best-conceptual advantage concentrates using GR4J/XAJ/HBV as structure-reference probes.",
            "audit_or_evidence": "manuscript_ready_claim_map.md M12-M13; deep_dive/D05_lstm_advantage_decomposition_20260709; deep_dive/D06_joint_season_flow_advantage_20260709",
            "remaining_action": "Keep the title, abstract, and discussion centered on advantage decomposition rather than predictive competition.",
        },
        {
            "risk": "Reviewer challenges snow-module fairness.",
            "current_defense": "GR4J/XAJ external PDD paths are tested as effective-equivalent; HBV snow is explicitly model-intrinsic.",
            "audit_or_evidence": "pytest test/test_id10_pdd_fairness.py -q; tables/fairness_audit.csv; tables/parameter_accounting.csv",
            "remaining_action": "Do not simplify wording to 'all models use the same snow module'.",
        },
        {
            "risk": "Reviewer challenges parameter-count fairness.",
            "current_defense": "The package reports nominal and effective active parameters, including XAJ 20 nominal / 18 effective active.",
            "audit_or_evidence": "tables/parameter_accounting.csv; fairness_audit_memo.md",
            "remaining_action": "Use nominal/effective wording in Methods and captions.",
        },
        {
            "risk": "Reviewer asks whether fairness-related code changes invalidated the old conceptual result table.",
            "current_defense": "A full-531 saved-parameter replay passes for GR4J/XAJ/HBV in both saved-state and warmup-recomputed modes, with zero NSE difference at the stored metric precision.",
            "audit_or_evidence": (REPLAY_AUDIT_REL / "saved_parameter_replay_summary.csv").as_posix(),
            "remaining_action": "Describe replay as artifact validation, not as a new calibration run.",
        },
        {
            "risk": "Reviewer says the LSTM has more information than conceptual models.",
            "current_defense": "The limitation is acknowledged: LSTM uses regional learning and static attributes; it is the strongest evaluated predictive reference, not a same-information conceptual challenger.",
            "audit_or_evidence": "claims_limitations.md; manuscript_sections.md",
            "remaining_action": "Avoid strict information-equality claims in Introduction and Abstract.",
        },
        {
            "risk": "Reviewer asks whether conceptual models are useful if the oracle gain is zero.",
            "current_defense": "Usefulness is diagnostic, not predictive-complementary; oracle median gain over LSTM is 0.000000.",
            "audit_or_evidence": "tables/oracle.csv; manuscript_ready_claim_map.md M6",
            "remaining_action": f"Report the {conceptual_wins} basin wins as heterogeneity, not as deployable complementarity.",
        },
        {
            "risk": "Reviewer asks why LSTM flow-signature diagnostics are not compared directly.",
            "current_defense": "The main benchmark stays NSE-based, while D02-D06 use saved daily LSTM test predictions or generated D04 residual artifacts for selected-case, population, and advantage-decomposition checks.",
            "audit_or_evidence": "claims_limitations.md; deep_dive/D02_seasonal_residual_20260709; deep_dive/D03_population_seasonal_residual_20260709; deep_dive/D04_full_population_seasonal_residual_20260709; deep_dive/D05_lstm_advantage_decomposition_20260709; deep_dive/D06_joint_season_flow_advantage_20260709; provenance_ledger.csv C15-C19",
            "remaining_action": "Do not imply that residual checks prove LSTM process realism; keep them as post-hoc diagnostics.",
        },
        {
            "risk": "Reviewer finds stale PET-bug or HBV-v7 references.",
            "current_defense": "Stale-reference audit has zero stale-reference blockers and quarantines old PET-bug diagnostics.",
            "audit_or_evidence": "MANIFEST.json stale_reference_blockers=[]; audit/stale_reference_audit.csv",
            "remaining_action": "Run the package rebuild before submission and inspect stale-reference blockers separately from reproducibility status.",
        },
        {
            "risk": "Reviewer says the paper selected only the largest snow/spring/high-flow cells.",
            "current_defense": "Figure 5 displays all 48 joint cells with concentration ratio, valid count, and shared-failure rate; the 16 regime-season and 12 regime-flow cells remain in full registered tables and additive summaries report every main-effect level.",
            "audit_or_evidence": "figures/fig5_joint_context_heterogeneity.png; tables/context_dimension_summary.csv; provenance_ledger.csv C23",
            "remaining_action": "Keep low-flow counterevidence and the ratio-versus-median counterexample in Results.",
        },
        {
            "risk": "Reviewer interprets high-flow concentration as scale-free high-flow skill.",
            "current_defense": "The separate dimensionless analysis resolves the scale ambiguity: high flow dominates the per-day absolute-error margin, but middle flow has the largest relative concentration and shared-failure consistency.",
            "audit_or_evidence": "tables/context_scale_threshold_summary.csv; tables/context_scale_threshold_intervals.csv; figures/fig6_scale_threshold_robustness.png",
            "remaining_action": "Report absolute and relative concentration as different estimands; do not collapse them into one high-flow skill claim.",
        },
        {
            "risk": "Reviewer treats spring or snow fraction as an independent causal explanation.",
            "current_defense": "Whole-basin post-hoc contrasts order snow-high seasonal medians as spring, winter, summer, and autumn, but the family was specified after matrix inspection; 39 attribute tests remain bivariate and covary, and snow fraction participates in regime definition.",
            "audit_or_evidence": "tables/context_scale_contrasts.csv; primary_static_spearman.csv; seasonal_attribute_link_checks.csv; figures/fig6_scale_threshold_robustness.png",
            "remaining_action": "Use post-hoc and associational wording; do not call the seasonal ordering prospective confirmation, snowmelt attribution, or an independent snow effect.",
        },
    ]

    if "context_scale_threshold_summary" not in tables:
        common_protocol_only = {
            "Reviewer interprets high-flow concentration as scale-free high-flow skill.",
            "Reviewer treats spring or snow fraction as an independent causal explanation.",
        }
        rows = [row for row in rows if row["risk"] not in common_protocol_only]
    df = pd.DataFrame(rows)
    text = "# Reviewer-risk checklist\n\n" + _to_md_table(df) + "\n"
    (out_dir / "reviewer_risk_checklist.md").write_text(text, encoding="utf-8")


def _write_final_submission_readiness_memo(out_dir: Path, tables: Dict[str, pd.DataFrame], stale: pd.DataFrame) -> None:
    main = tables["main_benchmark"].set_index("model")
    oracle = tables["oracle"].set_index("quantity")["value"]
    blockers = int((stale["status"] == "blocker").sum())
    if "context_scale_threshold_summary" in tables:
        values = _context_robustness_numbers(tables)
        q10 = values["flow"]["q10_q90"]
        stability = values["stability"]
        robustness_claims = (
            f"- Scale-dependent hierarchy: high-flow absolute concentration {q10['high']['absolute_concentration_ratio']:.3f}; "
            f"middle-flow relative concentration {q10['mid']['relative_concentration_ratio']:.3f} and shared failure {q10['mid']['shared_failure_rate']:.1%}.\n"
            f"- Whole-pattern protocol stability: concentration-rank correlations {stability.loc['season', 'concentration_rank_spearman']:.3f}, "
            f"{stability.loc['flow', 'concentration_rank_spearman']:.3f}, and {stability.loc['joint', 'concentration_rank_spearman']:.3f}.\n"
        )
        robustness_commands = (
            "pytest test/test_id18_context_scale_threshold_robustness.py -q\n"
            "python -X utf8 -m src.lstm_fair_531.scripts.run_context_scale_threshold_robustness\n"
            "python -X utf8 -m src.lstm_fair_531.scripts.full_protocol_matrix_stability\n"
        )
        robustness_status = "- Purpose-bounded additions: the scale-and-threshold analysis and full protocol-matrix stability analysis use saved predictions, add no rainfall-runoff model, and are registered with row-level inputs and manifests.\n"
        strongest_risk = "- The strongest remaining manuscript risk is conflating absolute-error reduction with dimensionless relative advantage, or presenting post-hoc seasonal contrasts as causal or prospectively confirmed."
    else:
        robustness_claims = robustness_commands = robustness_status = ""
        strongest_risk = "- The strongest remaining manuscript risk is overclaiming conceptual predictive competitiveness, strict information equality, or a shared HBV external PDD module."
    if "hydrological_flow_bias_summary" in tables:
        process_commands = (
            "pytest test/test_id18_hydrological_process_diagnostics.py -q\n"
            "python -X utf8 -m src.lstm_fair_531.scripts.run_hydrological_process_diagnostics --output-dir results/18_lstm_fair_531/D09_hydrological_process_diagnostics_20260726_attempt2\n"
        )
        process_status = "- Hydrological process diagnostics: independent raw-input recomputation passed for all four models, both event thresholds, all summary tables, and both fixed decision gates.\n"
    else:
        process_commands = process_status = ""
    if "cause_amplitude_geometry_summary" in tables:
        cause_values = _posthoc_cause_numbers(tables)
        cause_claims = (
            f"- Cause diagnosis: 90th-percentile event-peak concentration LSTM {cause_values['q90_peak_concentration']['LSTM']:.3f}, "
            f"GR4J {cause_values['q90_peak_concentration']['GR4J']:.3f}, Xinanjiang {cause_values['q90_peak_concentration']['Xinanjiang']:.3f}, "
            f"HBV-lite {cause_values['q90_peak_concentration']['HBV-lite']:.3f}; precipitation-disagreement median basin rho "
            f"{cause_values['q90_forcing_median_basin_rho']:.3f}.\n"
        )
        cause_commands = (
            "pytest test/test_id18_posthoc_cause_diagnostics.py -q\n"
            "python -X utf8 -m src.lstm_fair_531.scripts.run_posthoc_cause_diagnostics --output-dir results/18_lstm_fair_531/D10_posthoc_cause_diagnostics_rebuild_audit\n"
        )
        cause_status = "- Post-hoc cause diagnosis: independent recomputation matched amplitude, event-shape, forcing-association, and bootstrap outputs to at most 1.2e-16; all 1,593 forcing-file hashes matched.\n"
        strongest_risk = "- The strongest remaining manuscript risk is treating weak precipitation-product disagreement as identified forcing error, assigning causal shares, or describing the small GR4J-LSTM event-shape difference as equal to the larger Xinanjiang and HBV-lite differences."
    else:
        cause_claims = cause_commands = cause_status = ""
    text = f"""# Final submission readiness memo

## Verdict

The registered snapshot contains an evidence package and a complete English Markdown manuscript draft for the conceptual-model and long short-term memory network benchmark. {_snapshot_input_count_phrase()} are content-pinned in one local archive, and the committed clean checkout rebuilds the package after archive extraction. That clean-checkout rebuild has been verified twice with zero digest differences across all 14 top-level outputs; venue formatting and a finalized bibliography remain outside this snapshot.

## Fixed claim spine

- Main conceptual headline: GR4J {main.loc['GR4J', 'median_nse']:.6f}, XAJ {main.loc['XAJ', 'median_nse']:.6f}, HBV {main.loc['HBV', 'median_nse']:.6f}.
- Strongest evaluated predictor: eight-seed LSTM ensemble median NSE {main.loc['LSTM_ensemble_8seed', 'median_nse']:.6f}.
- Oracle check: four-model oracle median NSE {oracle.loc['four_model_oracle_median_nse']:.6f}, median gain over LSTM {oracle.loc['four_model_oracle_minus_lstm_median']:.6f}.
- Snow-module fairness: GR4J/XAJ external PDD paths are effective-equivalent under zero initial ice; HBV-lite snow is intrinsic structure.
- Parameter accounting: GR4J+PDD 8 nominal/effective, XAJ+PDD 20 nominal / 18 effective active, HBV-lite 13 nominal/effective.

{robustness_claims}
{cause_claims}
## Required audit commands before submission

```powershell
pytest test/test_id10_pdd_fairness.py -q
pytest test/test_id10_manuscript_evidence_package.py -q
{robustness_commands}{process_commands}{cause_commands}
python -X utf8 -m src.xaj_global_pilot.scripts.replay_conceptual_saved_params --out-dir draft/papers/10_18_conceptual_lstm_package/audit/R01_saved_parameter_replay_current_code
python -X utf8 -m src.lstm_fair_531.scripts.seasonal_residual_deep_dive --population snow --max-basins 0 --out-dir draft/papers/10_18_conceptual_lstm_package/deep_dive/D03_population_seasonal_residual_20260709
python -X utf8 -m src.lstm_fair_531.scripts.seasonal_residual_deep_dive --population all --max-basins 0 --out-dir draft/papers/10_18_conceptual_lstm_package/deep_dive/D04_full_population_seasonal_residual_20260709
python -X utf8 -m src.lstm_fair_531.scripts.population_residual_attribute_review --dive-dir draft/papers/10_18_conceptual_lstm_package/deep_dive/D04_full_population_seasonal_residual_20260709
python -X utf8 -m src.lstm_fair_531.scripts.lstm_advantage_decomposition
python -X utf8 -m src.lstm_fair_531.scripts.joint_advantage_decomposition
python -X utf8 -m src.lstm_fair_531.scripts.build_manuscript_evidence_package
```

## Current audit status

- Stale-reference blockers: {blockers}.
- Reproducibility status: committed clean-checkout rebuild verified with one content-pinned local external archive; all 14 top-level outputs matched the registered files across two consecutive builds.
- Main table, fairness audit, parameter accounting, claim map, three-step key points, complete manuscript draft, captions, reviewer-risk checklist, and readiness memo are regenerated by one package-build command.
- Saved-parameter replay audit: GR4J/XAJ/HBV replay all 531 basins under the current code in saved-state and warmup-recomputed modes; this validates artifact continuity without claiming a fresh recalibration.
- Diagnostic deep dives: basin-attribute, selected-case seasonal, snow-population, full-population residual, advantage-concentration, and joint season-flow analyses remain registered under `deep_dive/`.
{robustness_status}{process_status}{cause_status}{strongest_risk}

## Independent audit feasibility

An external reviewer can verify the main conclusion, snow-module fairness, stale-reference status, saved-parameter replay, and parameter accounting from the committed clean checkout and registered external inputs. The tested assembly reproduces all 14 top-level files twice with zero digest differences and requires no working-tree overlay. A full recalibration of all conceptual models is not required for the current narrow claims.
"""
    (out_dir / "final_submission_readiness_memo.md").write_text(text, encoding="utf-8")


def _write_independent_audit_conclusion(out_dir: Path, tables: Dict[str, pd.DataFrame], stale: pd.DataFrame) -> None:
    main = tables["main_benchmark"].set_index("model")
    oracle = tables["oracle"].set_index("quantity")["value"]
    n_blockers = int((stale["status"] == "blocker").sum())
    if "context_scale_threshold_summary" in tables:
        robustness_audit = (
            "- Scale and threshold robustness is auditable from three fixed discharge partitions, 10,000 whole-basin bootstrap replicates, row-level context tables, and a content-hashed manifest; no additional rainfall-runoff model was trained or added.\n"
            "- Full-pattern protocol stability is auditable across all 16 regime-season cells, 12 regime-flow cells, 48 joint cells, and 39 primary attributes.\n"
        )
        robustness_commands = (
            "pytest test/test_id18_context_scale_threshold_robustness.py -q\n"
            "python -X utf8 -m src.lstm_fair_531.scripts.run_context_scale_threshold_robustness\n"
            "python -X utf8 -m src.lstm_fair_531.scripts.full_protocol_matrix_stability\n"
        )
        robustness_inspect = (
            "- `tables/context_scale_threshold_summary.csv`\n- `tables/context_scale_threshold_intervals.csv`\n"
            "- `tables/context_scale_contrasts.csv`\n- `tables/protocol_matrix_stability.csv`\n- `tables/protocol_matrix_cell_deltas.csv`\n"
        )
    else:
        robustness_audit = robustness_commands = robustness_inspect = ""
    if "hydrological_flow_bias_summary" in tables:
        process_audit = (
            "- The hydrological process diagnostic is independently audited from the registered raw daily prediction files: input and output hashes, all summary rows, both event thresholds, decision gates, and direct daily-to-event reconstruction passed.\n"
        )
        process_commands = (
            "pytest test/test_id18_hydrological_process_diagnostics.py -q\n"
            "python -X utf8 -m src.lstm_fair_531.scripts.run_hydrological_process_diagnostics --output-dir results/18_lstm_fair_531/D09_hydrological_process_diagnostics_20260726_attempt2\n"
        )
        process_inspect = (
            "- `tables/hydrological_flow_bias_summary.csv`\n- `tables/hydrological_event_summary.csv`\n"
            "- `tables/hydrological_decision_gates.csv`\n- `figures/fig7_hydrological_process_diagnostics.png`\n"
        )
    else:
        process_audit = process_commands = process_inspect = ""
    if "cause_amplitude_geometry_summary" in tables:
        cause_audit = (
            "- The post-hoc cause diagnosis is independently auditable from D09 observation-defined events, registered R02 predictions, three precipitation products, and 1,593 rehashed forcing files; the maximum numerical reproduction difference was 1.2e-16.\n"
            "- Its supported interpretation is limited to shared amplitude compression, lower event-peak concentration for Xinanjiang and HBV-lite, a small GR4J-LSTM shape difference, and weak forcing-product disagreement association; causal shares are unsupported.\n"
        )
        cause_commands = (
            "pytest test/test_id18_posthoc_cause_diagnostics.py -q\n"
            "python -X utf8 -m src.lstm_fair_531.scripts.run_posthoc_cause_diagnostics --output-dir results/18_lstm_fair_531/D10_posthoc_cause_diagnostics_rebuild_audit\n"
        )
        cause_inspect = (
            "- `tables/cause_amplitude_geometry_summary.csv`\n- `tables/cause_event_shape_summary.csv`\n"
            "- `tables/cause_event_shape_pairwise_summary.csv`\n- `tables/cause_forcing_disagreement_summary.csv`\n"
            "- `figures/fig8_posthoc_cause_diagnostics.png`\n"
        )
    else:
        cause_audit = cause_commands = cause_inspect = ""
    text = f"""# Independent audit feasibility conclusion

## Verdict

Core benchmark claims and manuscript claim boundaries are independently auditable from the registered snapshot. The committed clean checkout and one content-pinned local external archive rebuild it without a working-tree overlay.

## Evidence

- Stale-reference blockers: {n_blockers}.
- Reproducibility status: committed clean-checkout reconstruction verified with one content-pinned local external archive; 14 top-level outputs matched across two consecutive builds.
- Main headline medians are regenerated from saved per-basin metric artifacts:
  - GR4J: {main.loc['GR4J', 'median_nse']:.6f}
  - XAJ: {main.loc['XAJ', 'median_nse']:.6f}
  - HBV: {main.loc['HBV', 'median_nse']:.6f}
  - LSTM ensemble: {main.loc['LSTM_ensemble_8seed', 'median_nse']:.6f}
- Four-model oracle median NSE is {oracle.loc['four_model_oracle_median_nse']:.6f}; median gain over LSTM is {oracle.loc['four_model_oracle_minus_lstm_median']:.6f}.
- PDD fairness is testable: GR4J/XAJ external snow front ends are effective-equivalent under zero initial ice, while XAJ ice parameters are inactive in this setup.
- Saved-parameter replay is testable: all GR4J/XAJ/HBV saved parameter artifacts replay under the current code for 531 basins in saved-state and warmup-recomputed modes.
- Parameter accounting is explicit: GR4J+PDD = 8 nominal/effective, XAJ+PDD = 20 nominal / 18 effective active, HBV-lite = 13 intrinsic parameters.
- Stale PET-bug diagnostics are classified as quarantined or historical, not as active manuscript evidence.
- Advantage-decomposition value is backed by D01 basin-attribute relationships, D02 selected-case seasonal residuals, D03 snow-population residuals, D04 full-population residual attribute checks, and D05/D06 concentration of the LSTM margin relative to the row-wise lowest-error conceptual comparator, with hydro signatures and daily residuals labeled as post-hoc diagnostics.
- Manuscript claim boundaries are captured in `key_points.md`, `manuscript_ready_claim_map.md`, `reviewer_risk_checklist.md`, and `final_submission_readiness_memo.md`.
{robustness_audit}{process_audit}{cause_audit}

## How to audit

Run:

```powershell
pytest test/test_id10_pdd_fairness.py -q
pytest test/test_id10_manuscript_evidence_package.py -q
{robustness_commands}{process_commands}{cause_commands}
python -X utf8 -m src.xaj_global_pilot.scripts.replay_conceptual_saved_params --out-dir draft/papers/10_18_conceptual_lstm_package/audit/R01_saved_parameter_replay_current_code
python -X utf8 -m src.lstm_fair_531.scripts.seasonal_residual_deep_dive --population snow --max-basins 0 --out-dir draft/papers/10_18_conceptual_lstm_package/deep_dive/D03_population_seasonal_residual_20260709
python -X utf8 -m src.lstm_fair_531.scripts.seasonal_residual_deep_dive --population all --max-basins 0 --out-dir draft/papers/10_18_conceptual_lstm_package/deep_dive/D04_full_population_seasonal_residual_20260709
python -X utf8 -m src.lstm_fair_531.scripts.population_residual_attribute_review --dive-dir draft/papers/10_18_conceptual_lstm_package/deep_dive/D04_full_population_seasonal_residual_20260709
python -X utf8 -m src.lstm_fair_531.scripts.lstm_advantage_decomposition
python -X utf8 -m src.lstm_fair_531.scripts.joint_advantage_decomposition
python -X utf8 -m src.lstm_fair_531.scripts.build_manuscript_evidence_package
```

Then inspect:

- `MANIFEST.json`
- `tables/main_benchmark.csv`
- `tables/paired.csv`
- `tables/conceptual_diagnostics.csv`
- `tables/regime_summary.csv`
- `tables/parameter_accounting.csv`
- `tables/fairness_audit.csv`
- `audit/R01_saved_parameter_replay_current_code/saved_parameter_replay_summary.csv`
- `deep_dive/D01_structure_diagnostic_20260709/README.md`
- `deep_dive/D02_seasonal_residual_20260709/README.md`
- `deep_dive/D03_population_seasonal_residual_20260709/README.md`
- `deep_dive/D04_full_population_seasonal_residual_20260709/README.md`
- `deep_dive/D04_full_population_seasonal_residual_20260709/population_residual_attribute_review.md`
- `deep_dive/D05_lstm_advantage_decomposition_20260709/D05_lstm_advantage_decomposition_memo.md`
- `deep_dive/D06_joint_season_flow_advantage_20260709/D06_joint_season_flow_advantage_memo.md`
{robustness_inspect}{process_inspect}{cause_inspect}
- `manuscript_ready_claim_map.md`
- `manuscript_sections.md`
- `key_points.md`
- `manuscript_full_draft.md`
- `figure_table_captions.md`
- `reviewer_risk_checklist.md`
- `final_submission_readiness_memo.md`
- `provenance_ledger.csv`
- `audit/stale_reference_audit.csv`

## Residual risk

The package contains a complete manuscript draft and a content-pinned registered snapshot. Final submission still requires venue formatting, a finalized bibliography, and publication of the registered external archive. Do not remove the snow-module distinction, nominal/effective parameter accounting, or strongest-evaluated-reference boundary from Methods/Limitations during manuscript polishing.
"""
    (out_dir / "independent_audit_conclusion.md").write_text(text, encoding="utf-8")


def build_package(out_dir: Path, verify_snapshot_inputs: bool = True,
                  protocol: EvidenceProtocol | str | None = None) -> None:
    resolved = _resolve(protocol)
    policy = load_snapshot_policy()
    archive_validation = validate_external_archive(policy, raise_on_error=verify_snapshot_inputs)
    input_validation = validate_snapshot_inputs(policy, raise_on_error=verify_snapshot_inputs)
    code_input_validation = validate_code_inputs(policy, raise_on_error=verify_snapshot_inputs)
    table_dir = out_dir / "tables"
    fig_dir = out_dir / "figures"
    audit_dir = out_dir / "audit"
    for path in [table_dir, fig_dir, audit_dir]:
        path.mkdir(parents=True, exist_ok=True)

    concept_long, _ = _load_conceptual(resolved)
    all_nse = _load_all_nse(resolved)

    tables = {
        "main_benchmark": _main_benchmark_table(all_nse),
        "paired": _paired_comparison_table(resolved),
        "conceptual_diagnostics": _diagnostic_table(concept_long),
        "conceptual_winners": _winner_table(concept_long),
        "regime_summary": _regime_table(all_nse, resolved),
        "oracle": _oracle_table(all_nse),
        "protocol": _protocol_table(resolved),
        "parameter_accounting": _parameter_accounting_table(),
        "fairness_audit": _fairness_audit_table(resolved),
        "context_dimension_summary": _context_dimension_summary_table(out_dir, resolved),
        "lstm_advantage_concentration": _advantage_concentration_table(out_dir, resolved),
        "population_evidence": _population_evidence_table(out_dir, policy, resolved),
        "protocol_robustness": _protocol_robustness_table(),
    }
    if resolved.protocol_id == IDENTICAL_PROTOCOL_ID:
        tables["lstm_registered_config_provenance"] = _registered_lstm_config_provenance_table()
        tables["flow_day_weighted_summary"] = _day_weighted_flow_table(policy)
    tables.update(_context_robustness_tables(policy, resolved))
    tables.update(_hydrological_process_tables(policy, resolved))
    tables.update(_posthoc_cause_tables(policy, resolved))
    tables.update(_kge_component_tables(policy, resolved))
    tables.update(_objective_intervention_tables(policy, resolved))
    for stale_population_table in [table_dir / "population_evidence.csv", table_dir / "population_evidence.md"]:
        stale_population_table.unlink(missing_ok=True)
    for name, df in tables.items():
        if name in {
                "population_evidence",
                "kge_components_by_basin_context",
                "kge_paired_attribution_by_basin_context",
        }:
            continue
        _write_table(df, table_dir / f"{name}.csv", table_dir / f"{name}.md")

    combined = all_nse.copy()
    combined["best_conceptual"] = combined[["GR4J", "XAJ", "HBV"]].max(axis=1)
    combined["conceptual_winner"] = combined[["GR4J", "XAJ", "HBV"]].idxmax(axis=1)
    combined["lstm_minus_best_conceptual"] = combined["LSTM_ensemble_8seed"] - combined["best_conceptual"]
    combined["regime"] = _load_regime(resolved).reindex(combined.index)
    combined.reset_index().rename(columns={"index": "basin_id"}).to_csv(table_dir / "per_basin_combined_nse.csv", index=False)

    _plot_cdf(all_nse, fig_dir / "fig1_nse_cdf.png")
    _plot_regime(tables["regime_summary"], fig_dir / "fig2_regime_median_nse.png")
    _plot_diagnostics(tables["conceptual_diagnostics"], fig_dir / "fig3_conceptual_diagnostic_tradeoffs.png")
    _plot_lstm_margin(all_nse, fig_dir / "fig4_lstm_minus_best_conceptual_by_regime.png", resolved)

    stale = _stale_reference_audit(out_dir=out_dir)
    stale.to_csv(audit_dir / "stale_reference_audit.csv", index=False)
    (audit_dir / "stale_reference_audit.md").write_text(_to_md_table(stale) + "\n", encoding="utf-8")

    _provenance_ledger(out_dir, resolved)
    _write_claims(out_dir, tables, resolved)
    _write_claims_limitations(out_dir, tables)
    _write_fairness_audit_memo(out_dir)
    _write_manuscript_claim_map(out_dir, tables, resolved)
    _write_manuscript_sections(out_dir, tables, resolved)
    _write_key_points(out_dir, tables, resolved)
    _write_full_manuscript(out_dir, tables, resolved)
    _plot_joint_context_heterogeneity(
        out_dir, fig_dir / "fig5_joint_context_heterogeneity.png", resolved)
    _write_figure_table_captions(out_dir, tables)
    if "context_scale_threshold_summary" in tables:
        _plot_scale_threshold_robustness(tables, fig_dir / "fig6_scale_threshold_robustness.png")
    if "hydrological_flow_bias_summary" in tables:
        _plot_hydrological_process_diagnostics(
            tables, fig_dir / "fig7_hydrological_process_diagnostics.png")
    if "cause_amplitude_geometry_summary" in tables:
        _plot_posthoc_cause_diagnostics(
            tables, fig_dir / "fig8_posthoc_cause_diagnostics.png")
    if "kge_component_summary" in tables:
        _plot_kge_component_diagnosis(
            tables, fig_dir / "fig9_kge_component_diagnosis.png")
    _write_reviewer_risk_checklist(out_dir, tables)
    _write_final_submission_readiness_memo(out_dir, tables, stale)
    _write_independent_audit_conclusion(out_dir, tables, stale)

    package_root = Path(policy["baseline_package_root"])
    archived_package_inputs = sorted(
        Path(item["path"]).relative_to(package_root).as_posix()
        for item in policy["external_inputs"]
        if _is_under(Path(item["path"]), package_root)
    )
    deep_dive_outputs = sorted(
        Path(path).relative_to(DEEP_DIVE_REL).as_posix()
        for path in archived_package_inputs
        if _is_under(Path(path), DEEP_DIVE_REL)
    )

    manifest = {
        "package": "ID10/ID18 manuscript evidence package",
        "out_dir": str(package_root),
        "source_artifacts": {
            **resolved.provenance_sources()["manifest"],
            "active_protocol_context_tables": {
                name: str(package_root / resolved.deep_dive[name])
                for name in ["season", "flow", "joint"]
            },
            "active_protocol_context_sha256": {
                name: _sha256(out_dir / resolved.deep_dive[name])
                for name in ["season", "flow", "joint"]
            },
            "saved_parameter_replay": str(package_root / REPLAY_AUDIT_REL),
            "context_scale_threshold_robustness": (
                _policy_input(policy, D07_INPUT_IDS["manifest"])["path"]
                if resolved.protocol_id == IDENTICAL_PROTOCOL_ID else None
            ),
            "full_protocol_matrix_stability": (
                _policy_input(policy, D08_INPUT_IDS["manifest"])["path"]
                if resolved.protocol_id == IDENTICAL_PROTOCOL_ID else None
            ),
            "hydrological_process_diagnostics": (
                _policy_input(policy, D09_INPUT_IDS["manifest"])["path"]
                if resolved.protocol_id == IDENTICAL_PROTOCOL_ID else None
            ),
            "hydrological_process_independent_audit": (
                _policy_input(policy, D09_INPUT_IDS["audit"])["path"]
                if resolved.protocol_id == IDENTICAL_PROTOCOL_ID else None
            ),
            "deep_dive_d01": str(package_root / D01_DEEP_DIVE_REL),
            "posthoc_cause_diagnostics": (
                _policy_input(policy, D10_INPUT_IDS["manifest"])["path"]
                if resolved.protocol_id == IDENTICAL_PROTOCOL_ID else None
            ),
            "posthoc_cause_independent_audit": (
                _policy_input(policy, D10_INPUT_IDS["audit"])["path"]
                if resolved.protocol_id == IDENTICAL_PROTOCOL_ID else None
            ),
            "kge_component_diagnostics": (
                _policy_input(policy, D11_INPUT_IDS["manifest"])["path"]
                if resolved.protocol_id == IDENTICAL_PROTOCOL_ID else None
            ),
            "kge_component_independent_audit": (
                _policy_input(policy, D11_INPUT_IDS["audit"])["path"]
                if resolved.protocol_id == IDENTICAL_PROTOCOL_ID else None
            ),
            "deep_dive_d02": str(package_root / D02_DEEP_DIVE_REL),
            "deep_dive_d03": str(package_root / D03_DEEP_DIVE_REL),
            "deep_dive_d04": str(package_root / D04_DEEP_DIVE_REL),
            "deep_dive_d05": str(package_root / D05_DEEP_DIVE_REL),
            "deep_dive_d06": str(package_root / D06_DEEP_DIVE_REL),
        },
        "outputs": {
            "tables": sorted(path.name for path in table_dir.glob("*.csv")),
            "figures": sorted(path.name for path in fig_dir.glob("*.png")),
            "audit": [
                (Path(REPLAY_AUDIT_REL.name) / "saved_parameter_replay_summary.csv").as_posix(),
                "stale_reference_audit.csv",
                "stale_reference_audit.md",
            ],
            "deep_dive": deep_dive_outputs,
            "archived_evidence_inputs": archived_package_inputs,
            "ledger": ["provenance_ledger.csv", "provenance_ledger.md"],
            "skeleton": "manuscript_skeleton.md",
            "claims_limitations": "claims_limitations.md",
            "fairness_audit_memo": "fairness_audit_memo.md",
            "manuscript_ready_claim_map": "manuscript_ready_claim_map.md",
            "manuscript_sections": "manuscript_sections.md",
            "key_points": "key_points.md",
            "full_manuscript": "manuscript_full_draft.md",
            "figure_table_captions": "figure_table_captions.md",
            "reviewer_risk_checklist": "reviewer_risk_checklist.md",
            "final_submission_readiness_memo": "final_submission_readiness_memo.md",
            "independent_audit_conclusion": "independent_audit_conclusion.md",
        },
        "stale_reference_blockers": stale[stale["status"] == "blocker"][
            ["file", "line", "patterns", "recommended_action"]
        ].to_dict("records"),
        "reproducibility": {
            "status": "registered_snapshot_rebuildable",
            "current_worktree_artifacts_auditable": True,
            "registered_external_inputs_verified": True,
            "single_external_archive_verified": True,
            "external_archive_path": policy["external_archive_bundle"]["path"],
            "proposed_overlay_rebuild_verified": True,
            "committed_clean_checkout_rebuild_verified": True,
            "notes": (
                "The committed snapshot rebuild is verified from a clean checkout using one content-pinned local "
                "external archive; archive publication remains unverified."
            ),
        },
    }
    _write_json(out_dir / "MANIFEST.json", manifest)
    _write_reproducibility_records(
        out_dir, policy, input_validation, tables, code_input_validation, archive_validation, resolved
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", default="draft/papers/10_18_conceptual_lstm_package")
    parser.add_argument("--protocol", default=PRIMARY_PROTOCOL_ID, choices=list_protocols(),
                        help="Which benchmark protocol the package reports.")
    parser.add_argument("--verify-snapshot", action="store_true",
                        help="Verify all immutable snapshot inputs before rebuilding the manuscript package.")
    parser.add_argument("--build-external-archive", type=Path,
                        help="Recreate the deterministic external-input archive at the requested path.")
    args = parser.parse_args()
    if args.build_external_archive is not None:
        policy = load_snapshot_policy()
        validate_snapshot_inputs(policy)
        build_external_archive(policy, args.build_external_archive)
        bundle = policy["external_archive_bundle"]
        if (args.build_external_archive.stat().st_size != bundle["bytes"] or
                _sha256(args.build_external_archive) != bundle["sha256"]):
            raise SnapshotInputError("Rebuilt external archive does not match the registered bundle digest.")
        print(f"wrote external archive: {args.build_external_archive}")
        print(f"sha256: {bundle['sha256']}")
        return
    out_dir = Path(args.out_dir)
    build_package(out_dir, verify_snapshot_inputs=True, protocol=args.protocol)
    print(f"wrote evidence package: {out_dir} [protocol={args.protocol}]")
    print(f"manifest: {out_dir / 'MANIFEST.json'}")


if __name__ == "__main__":
    main()
