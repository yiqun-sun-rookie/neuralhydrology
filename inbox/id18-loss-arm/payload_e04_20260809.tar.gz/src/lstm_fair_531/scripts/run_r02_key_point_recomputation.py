"""Produce the R02 (identical-loss) counterparts of the published Key Point tables.

Reads only registered, hash-pinned R02 artifacts, reshapes them into the historical
delta schema via ``recompute_r02_key_points``, and feeds them to the same
concentration code that produced the published R01 numbers.

Writes a fresh output directory; it never touches the locked official analysis
bundles.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import pandas as pd

from src.lstm_fair_531.scripts.analyze_identical_basin_nse_replication import (
    build_daily_panel,
    build_eight_seed_ensemble,
    load_registered_conceptual_predictions,
    load_registered_neural_predictions,
)
from src.lstm_fair_531.scripts.joint_advantage_decomposition import _split_joint_context
from src.lstm_fair_531.scripts.lstm_advantage_decomposition import (
    build_advantage_targets,
    summarize_advantage_concentration,
)
from src.lstm_fair_531.scripts.recompute_r02_key_points import (
    JOINT_MIN_DAYS,
    build_context_delta_table,
    build_r01_score_panel,
)

_RESULT_ROOT = Path("results/18_lstm_fair_531/R02_identical_basin_nse_531")
_DEFAULT_LEDGER = _RESULT_ROOT / "registry" / "run_ledger.json"
_DEFAULT_CONCEPTUAL = _RESULT_ROOT / "conceptual" / "conceptual_prediction_manifest.json"
_DEFAULT_PROTOCOL = _RESULT_ROOT / "protocol" / "common_loss_protocol.json"
_DEFAULT_REGIMES = Path(
    "draft/papers/10_18_conceptual_lstm_package/deep_dive/"
    "D01_structure_diagnostic_20260709/tables/basin_attribute_panel.csv"
)
_DEFAULT_OUT = _RESULT_ROOT / "analysis_key_points_20260724"

_HISTORICAL_DELTA_NAMES = {
    "season": "conceptual_vs_lstm_by_case_season.csv",
    "flow": "conceptual_vs_lstm_by_case_flow_group.csv",
}

_FAMILIES = (
    ("season", "season", "season_regime_advantage_concentration.csv"),
    ("flow", "flow_group", "flow_regime_advantage_concentration.csv"),
    ("joint", "joint_context", "joint_regime_advantage_concentration.csv"),
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_with_sources(frame: pd.DataFrame, path: Path, sources: list[dict]) -> None:
    """Write a table beside a sidecar recording every hash-pinned input it derives from.

    Mirrors the sidecar format the official analysis bundle uses, so the two
    directories can be audited the same way.
    """
    frame.to_csv(path, index=False)
    sidecar = {"loss_protocol": "identical_basin_average_nse", "sources": sources}
    path.with_suffix(path.suffix + ".sources.json").write_text(
        json.dumps(sidecar, indent=2, default=str), encoding="utf-8"
    )


def _load_basin_regimes(path: Path) -> pd.DataFrame:
    panel = pd.read_csv(path)
    if "regime" not in panel.columns:
        raise ValueError(f"{path} has no regime column")
    basin_column = "basin_id" if "basin_id" in panel.columns else "gauge_id"
    regimes = panel[[basin_column, "regime"]].rename(columns={basin_column: "basin_id"})
    regimes["basin_id"] = regimes["basin_id"].astype(str).str.replace(r"\.0$", "", regex=True).str.zfill(8)
    return regimes.drop_duplicates("basin_id").reset_index(drop=True)


def run(
    *,
    run_ledger_path: Path,
    conceptual_manifest_path: Path,
    protocol_manifest_path: Path,
    basin_regimes_path: Path,
    output_dir: Path,
    per_basin_nse_path_override: Path | None = None,
) -> dict:
    seed_predictions, neural_sources = load_registered_neural_predictions(
        run_ledger_path, expected_protocol_path=protocol_manifest_path
    )
    neural = build_eight_seed_ensemble(seed_predictions)
    del seed_predictions

    conceptual, conceptual_sources = load_registered_conceptual_predictions(
        conceptual_manifest_path, expected_protocol_path=protocol_manifest_path
    )
    regimes = _load_basin_regimes(basin_regimes_path)
    panel = build_daily_panel(neural, conceptual, regimes)
    del neural, conceptual

    output_dir.mkdir(parents=True, exist_ok=True)

    per_basin_nse_path = (
        per_basin_nse_path_override
        if per_basin_nse_path_override is not None
        else _RESULT_ROOT / "analysis_official_20260723" / "per_basin_nse.csv"
    )
    source_records = [
        {"path": str(Path(path).resolve()), "role": role, "sha256": _sha256(Path(path))}
        for path, role in [
            (run_ledger_path, "neural_run_ledger"),
            (conceptual_manifest_path, "conceptual_prediction_manifest"),
            (protocol_manifest_path, "common_loss_protocol"),
            (basin_regimes_path, "basin_regime_table"),
            (per_basin_nse_path, "official_per_basin_efficiency"),
        ]
    ]
    written = {}
    for family, context_col, filename in _FAMILIES:
        delta = build_context_delta_table(panel, family=family, min_days=JOINT_MIN_DAYS)
        targets = build_advantage_targets(delta, context_col)
        if family == "joint":
            targets = _split_joint_context(targets)
        concentration = summarize_advantage_concentration(targets, context_col)
        if family == "joint":
            concentration = _split_joint_context(concentration)
        concentration.insert(0, "loss_protocol", "identical_basin_average_nse")

        delta_path = output_dir / f"{family}_context_delta.csv"
        concentration_path = output_dir / filename
        _write_with_sources(delta, delta_path, source_records)
        _write_with_sources(concentration, concentration_path, source_records)

        # Also write the season and flow delta tables under the historical file
        # names, so population_residual_attribute_review.py -- which produces the
        # attribute-link tables the manuscript body cites -- can consume them with
        # no modification.
        historical_name = _HISTORICAL_DELTA_NAMES.get(family)
        if historical_name is not None:
            legacy_tables = output_dir / "D04_population_r02" / "tables"
            legacy_tables.mkdir(parents=True, exist_ok=True)
            _write_with_sources(delta, legacy_tables / historical_name, source_records)
        written[family] = {
            "delta_rows": int(len(delta)),
            "target_rows": int(len(targets)),
            "concentration_rows": int(len(concentration)),
            "delta_path": str(delta_path),
            "concentration_path": str(concentration_path),
        }

    # Key Point 2 is a Spearman correlation over the historical 6-target x
    # 39-attribute family, computed by the historical diagnostic script from a
    # per-basin score panel. Rebuild that panel from the registered R02
    # efficiencies so the correlation keeps its published definition.
    score_panel_path = output_dir / "per_basin_combined_nse.csv"
    score_panel = build_r01_score_panel(pd.read_csv(per_basin_nse_path))
    _write_with_sources(score_panel, score_panel_path, source_records)
    written["score_panel"] = {
        "rows": int(len(score_panel)),
        "path": str(score_panel_path),
        "source": str(per_basin_nse_path),
    }

    manifest = {
        "schema_version": "1.0",
        "experiment_id": "R02_identical_basin_nse_531",
        "loss_protocol": "identical_basin_average_nse",
        "purpose": (
            "Recompute the published Key Point concentration statistics on the "
            "identical-loss results using the historical definitions unchanged."
        ),
        "joint_min_days": JOINT_MIN_DAYS,
        "families": written,
        "sources": source_records,
        "downstream_directories": {
            "D01_structure_diagnostic_r02": (
                "Produced by deep_dive_structure_diagnostics from per_basin_combined_nse.csv. "
                "Its internal manifest still carries the historical experiment identifier "
                "because that script hard-codes it; the identifier there does not describe "
                "this experiment."
            ),
            "D04_population_r02": (
                "Historical-named copies of the season and flow delta tables, so "
                "population_residual_attribute_review can run unmodified."
            ),
        },
        "registered_source_records": {
            "neural": neural_sources,
            "conceptual": conceptual_sources,
        },
        "status": "completed",
    }
    manifest_path = output_dir / "key_point_recomputation_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")
    return manifest


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-ledger", type=Path, default=_DEFAULT_LEDGER)
    parser.add_argument("--conceptual-manifest", type=Path, default=_DEFAULT_CONCEPTUAL)
    parser.add_argument("--protocol-manifest", type=Path, default=_DEFAULT_PROTOCOL)
    parser.add_argument("--basin-regimes", type=Path, default=_DEFAULT_REGIMES)
    parser.add_argument("--out-dir", type=Path, default=_DEFAULT_OUT)
    parser.add_argument("--per-basin-nse", type=Path, default=None)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    manifest = run(
        run_ledger_path=args.run_ledger,
        conceptual_manifest_path=args.conceptual_manifest,
        protocol_manifest_path=args.protocol_manifest,
        basin_regimes_path=args.basin_regimes,
        output_dir=args.out_dir,
        per_basin_nse_path_override=args.per_basin_nse,
    )
    for family, info in manifest["families"].items():
        if "concentration_rows" in info:
            print(f"{family}: {info['concentration_rows']} concentration rows -> {info['concentration_path']}")
        else:
            print(f"{family}: {info['rows']} rows -> {info['path']}")
    print(
        "Key Point 2 correlations: run deep_dive_structure_diagnostics with "
        "--score-panel <out-dir>/per_basin_combined_nse.csv"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
