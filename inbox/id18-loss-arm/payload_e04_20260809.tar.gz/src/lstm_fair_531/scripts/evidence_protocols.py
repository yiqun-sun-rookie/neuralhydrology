"""Bind the manuscript evidence package to one benchmark protocol at a time.

Two protocols are registered. ``historical`` is the published R01 benchmark. ``identical``
is the R02 rebuild, in which the neural network is trained on the same basin-averaged
one-minus-efficiency objective the conceptual models are calibrated with, all four models
are scored against a single observation series, and the conceptual models are recalibrated
under that common protocol.

Nothing here reimplements a statistic. The per-basin efficiencies, the conceptual
diagnostics and the concentration tables are read from registered artifacts, and the one
quantity that has no registered counterpart under ``identical`` -- the paired comparison --
is computed with the historical bootstrap imported from ``compare_lstm_vs_conceptual``.
The test suite pins that by requiring the historical protocol to reproduce the committed
paired table cell for cell.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd

from src.lstm_fair_531.scripts.compare_lstm_vs_conceptual import boot_median_diff

HISTORICAL_PROTOCOL_ID = "historical"
IDENTICAL_PROTOCOL_ID = "identical"

PACKAGE_ROOT = Path("draft/papers/10_18_conceptual_lstm_package")

_R01_REPRO = Path("results/10_global_conceptual_model_benchmark/camels_us_531_repro_v01")
_R01_REPORTS = Path("results/18_lstm_fair_531/_reports")
_R02_ROOT = Path("results/18_lstm_fair_531/R02_identical_basin_nse_531")
_R02_KEY_POINTS = _R02_ROOT / "analysis_key_points_20260724"

#: Order the manuscript tables key on. R02 registers the third model as ``HBV-lite``.
MODEL_ORDER = ["GR4J", "XAJ", "HBV"]
_R02_MODEL_NAMES = {"HBV-lite": "HBV"}

#: Where each protocol's concentration and attribute-link tables live inside the package.
_R01_DEEP_DIVE = {
    "season": Path("deep_dive/D05_lstm_advantage_decomposition_20260709/tables/"
                   "season_regime_advantage_concentration.csv"),
    "flow": Path("deep_dive/D05_lstm_advantage_decomposition_20260709/tables/"
                 "flow_regime_advantage_concentration.csv"),
    "joint": Path("deep_dive/D06_joint_season_flow_advantage_20260709/tables/"
                  "joint_regime_advantage_concentration.csv"),
    "spearman": Path("deep_dive/D01_structure_diagnostic_20260709/tables/primary_static_spearman.csv"),
    "seasonal_links": Path("deep_dive/D04_full_population_seasonal_residual_20260709/tables/"
                           "seasonal_attribute_link_checks.csv"),
    "flow_links": Path("deep_dive/D04_full_population_seasonal_residual_20260709/tables/"
                       "flow_attribute_link_checks.csv"),
}
_R02_DEEP_DIVE_ROOT = Path("deep_dive/R02_common_protocol_20260724/tables")
_R02_DEEP_DIVE = {
    "season": _R02_DEEP_DIVE_ROOT / "season_regime_advantage_concentration.csv",
    "flow": _R02_DEEP_DIVE_ROOT / "flow_regime_advantage_concentration.csv",
    "joint": _R02_DEEP_DIVE_ROOT / "joint_regime_advantage_concentration.csv",
    "spearman": _R02_DEEP_DIVE_ROOT / "primary_static_spearman.csv",
    "seasonal_links": _R02_DEEP_DIVE_ROOT / "seasonal_attribute_link_checks.csv",
    "flow_links": _R02_DEEP_DIVE_ROOT / "flow_attribute_link_checks.csv",
}


def _bid(values: pd.Series) -> pd.Series:
    return values.astype(str).str.replace(r"\.0$", "", regex=True).str.zfill(8)


def _read_lstm_metrics(path: Path, label: str) -> pd.Series:
    frame = pd.read_csv(path)
    basin_column = "basin" if "basin" in frame.columns else frame.columns[0]
    nse_column = [column for column in frame.columns if column.upper() == "NSE"][0]
    frame["basin_id"] = _bid(frame[basin_column])
    return frame.set_index("basin_id")[nse_column].astype(float).rename(label)


def _paired_rows(lstm: pd.Series, conceptual: Dict[str, pd.Series]) -> pd.DataFrame:
    """Reproduce the published paired comparison, including its resampling order.

    The bootstrap draws integer positions, so the order of the paired vectors changes the
    resampled medians. The historical report intersects the neural index with each
    conceptual index and keeps the neural order; that is preserved here deliberately.
    """
    from scipy.stats import wilcoxon

    rows = []
    for model in MODEL_ORDER:
        series = conceptual[model]
        common = lstm.dropna().index.intersection(series.dropna().index)
        left, right = lstm.loc[common], series.loc[common]
        difference = left - right
        low, high = boot_median_diff(left, right)
        rows.append({
            "comparison": f"LSTM_ensemble_8seed_vs_{model}",
            "n_common": len(common),
            "opponent_median_nse": float(np.median(right)),
            "lstm_median_nse": float(np.median(left)),
            "median_diff": float(np.median(difference)),
            "lstm_win_rate": float((difference > 0).mean()),
            "wilcoxon_p": float(wilcoxon(left, right).pvalue),
            "ci95_low": low,
            "ci95_high": high,
        })
    return pd.DataFrame(rows)


@dataclass(frozen=True)
class EvidenceProtocol:
    """One benchmark protocol's inputs and the accessors the package builds from."""

    protocol_id: str
    label: str
    loss_protocol: str
    description: str
    deep_dive: Dict[str, Path]
    #: Logical evidence role -> the snapshot-policy input identifiers that back it.
    input_ids: Dict[str, List[str]]

    # ---- inputs -------------------------------------------------------------------
    def result_input_paths(self) -> List[Path]:
        raise NotImplementedError

    def package_input_paths(self) -> List[Path]:
        return [self.deep_dive[key] for key in sorted(self.deep_dive)]

    def registered_input_paths(self) -> List[Path]:
        return self.result_input_paths() + [PACKAGE_ROOT / path for path in self.package_input_paths()]

    def missing_inputs(self, root: Path = PACKAGE_ROOT) -> List[Path]:
        candidates = self.result_input_paths() + [root / path for path in self.package_input_paths()]
        return [path for path in candidates if not path.is_file()]

    # ---- evidence -----------------------------------------------------------------
    def per_basin_nse(self) -> pd.DataFrame:
        raise NotImplementedError

    def conceptual_long(self) -> pd.DataFrame:
        raise NotImplementedError

    def regime(self) -> pd.Series:
        raise NotImplementedError

    def lstm_ensemble_series(self) -> pd.Series:
        """The neural efficiencies in the order the paired bootstrap must resample them."""
        raise NotImplementedError

    def conceptual_series(self) -> Dict[str, pd.Series]:
        raise NotImplementedError

    def provenance_sources(self) -> Dict[str, object]:
        """Protocol-correct source files for the provenance ledger and MANIFEST.

        The manuscript package is built for one protocol at a time, so the provenance
        breadcrumbs a reader hand-traces must name the files that actually produced this
        protocol's numbers. Returned keys:

          ``main_benchmark``          -- files behind the main efficiency table (ledger C01)
          ``paired``                  -- files behind the paired comparison (ledger C02)
          ``paired_status``/``paired_notes`` -- how the paired numbers were obtained
          ``conceptual_diagnostics``  -- files behind the diagnostic table (ledger C03)
          ``regime``                  -- files behind the regime table (ledger C04)
          ``manifest``                -- the ``source_artifacts`` sub-block for MANIFEST.json
        """
        raise NotImplementedError

    def recomputed_paired_comparison(self) -> pd.DataFrame:
        """Compute the paired comparison from per-basin efficiencies, for every protocol.

        The historical protocol has a registered report to read instead; this path exists
        so the computation can be pinned against that report.
        """
        return _paired_rows(self.lstm_ensemble_series(), self.conceptual_series())

    def paired_comparison(self) -> pd.DataFrame:
        """The paired comparison the package reports for this protocol."""
        return self.recomputed_paired_comparison()

    def advantage_numbers(self, root: Path = PACKAGE_ROOT) -> dict:
        season = pd.read_csv(root / self.deep_dive["season"])
        flow = pd.read_csv(root / self.deep_dive["flow"])
        joint = pd.read_csv(root / self.deep_dive["joint"])

        snow_mam = season[(season["regime"] == "snow-dominated") & (season["season"] == "MAM")].iloc[0]
        snow_high = flow[(flow["regime"] == "snow-dominated") & (flow["flow_group"] == "high")].iloc[0]
        snow_mam_high = joint[(joint["regime"] == "snow-dominated") & (joint["season"] == "MAM") &
                              (joint["flow_group"] == "high")].iloc[0]
        n_contexts = int(snow_mam_high["n_contexts"])
        return {
            "snow_mam_context_share": float(snow_mam["context_share"]),
            "snow_mam_gap_share": float(snow_mam["positive_best_gap_share"]),
            "snow_mam_ratio": float(snow_mam["gap_concentration_ratio"]),
            "snow_mam_shared_failure": float(snow_mam["shared_failure_rate"]),
            "snow_high_context_share": float(snow_high["context_share"]),
            "snow_high_gap_share": float(snow_high["positive_best_gap_share"]),
            "snow_high_ratio": float(snow_high["gap_concentration_ratio"]),
            "snow_high_shared_failure": float(snow_high["shared_failure_rate"]),
            "snow_mam_high_context_share": float(snow_mam_high["context_share"]),
            "snow_mam_high_gap_share": float(snow_mam_high["positive_best_gap_share"]),
            "snow_mam_high_ratio": float(snow_mam_high["gap_concentration_ratio"]),
            "snow_mam_high_shared_failure": float(snow_mam_high["shared_failure_rate"]),
            "snow_mam_high_median_gap": float(snow_mam_high["median_best_conceptual_mae_minus_lstm"]),
            "snow_mam_high_n_contexts": n_contexts,
            "snow_mam_high_shared_failure_count": int(
                round(n_contexts * float(snow_mam_high["shared_failure_rate"]))
            ),
        }

    def population_support_numbers(self, root: Path = PACKAGE_ROOT) -> dict:
        spearman = pd.read_csv(root / self.deep_dive["spearman"])
        seasonal = pd.read_csv(root / self.deep_dive["seasonal_links"])
        flow = pd.read_csv(root / self.deep_dive["flow_links"])

        basin_snow = spearman[(spearman["target"] == "lstm_minus_best_conceptual") &
                              (spearman["feature"] == "clim_frac_snow")].iloc[0]
        mam_snow = seasonal[(seasonal["context"] == "MAM") &
                            (seasonal["target"] == "best_conceptual_mae_minus_lstm") &
                            (seasonal["feature"] == "clim_frac_snow")].iloc[0]
        high_snow = flow[(flow["context"] == "high") &
                         (flow["target"] == "best_conceptual_mae_minus_lstm") &
                         (flow["feature"] == "clim_frac_snow")].iloc[0]
        return {
            "basin_snow_rho": float(basin_snow["spearman_rho"]),
            "basin_snow_q": float(basin_snow["q_value"]),
            "mam_snow_rho": float(mam_snow["spearman_rho"]),
            "mam_snow_q": float(mam_snow["q_value"]),
            "high_snow_rho": float(high_snow["spearman_rho"]),
            "high_snow_q": float(high_snow["q_value"]),
        }


@dataclass(frozen=True)
class _HistoricalProtocol(EvidenceProtocol):
    conceptual_summaries: Dict[str, Path] = None
    lstm_single_metrics: Path = None
    lstm_ensemble_metrics: Path = None
    regime_table: Path = None
    paired_report: Path = None

    def result_input_paths(self) -> List[Path]:
        return [self.conceptual_summaries[model] for model in MODEL_ORDER] + [
            self.lstm_single_metrics,
            self.lstm_ensemble_metrics,
            self.regime_table,
            self.paired_report,
        ]

    def conceptual_long(self) -> pd.DataFrame:
        frames = []
        for model in MODEL_ORDER:
            frame = pd.read_csv(self.conceptual_summaries[model], dtype={"basin_id": str})
            if "period" in frame.columns:
                frame = frame[frame["period"] == "evaluation"].copy()
            frame["basin_id"] = _bid(frame["basin_id"])
            frame["model"] = model
            frame["cal_eval_gap"] = frame["_cal_nse"] - frame["nse"]
            frames.append(frame)
        return pd.concat(frames, ignore_index=True)

    def _conceptual_wide(self) -> pd.DataFrame:
        long = self.conceptual_long()
        columns = [
            long[long["model"] == model].set_index("basin_id")["nse"].rename(model)
            for model in MODEL_ORDER
        ]
        return pd.concat(columns, axis=1)

    def per_basin_nse(self) -> pd.DataFrame:
        single = _read_lstm_metrics(self.lstm_single_metrics, "LSTM_single_s100")
        ensemble = _read_lstm_metrics(self.lstm_ensemble_metrics, "LSTM_ensemble_8seed")
        return pd.concat([self._conceptual_wide(), single, ensemble], axis=1).dropna()

    def regime(self) -> pd.Series:
        frame = pd.read_csv(self.regime_table, dtype={"basin_id": str})
        frame["basin_id"] = _bid(frame["basin_id"])
        return frame.drop_duplicates("basin_id").set_index("basin_id")["regime"]

    def lstm_ensemble_series(self) -> pd.Series:
        return _read_lstm_metrics(self.lstm_ensemble_metrics, "LSTM_ensemble_8seed")

    def conceptual_series(self) -> Dict[str, pd.Series]:
        wide = self._conceptual_wide()
        return {model: wide[model] for model in MODEL_ORDER}

    def paired_comparison(self) -> pd.DataFrame:
        """Read the published report rather than recompute it.

        The historical branch must stay byte-for-byte what it was. The recomputation is
        pinned against this file by the test suite, which is what licenses using the
        computed path for the protocol that has no such report.
        """
        import json

        report = json.loads(Path(self.paired_report).read_text(encoding="utf-8"))
        rows = []
        for model in MODEL_ORDER:
            payload = report["full_531"]["vs"][model]
            rows.append({
                "comparison": f"LSTM_ensemble_8seed_vs_{model}",
                "n_common": payload["n_common"],
                "opponent_median_nse": payload["concept_median"],
                "lstm_median_nse": payload["lstm_median"],
                "median_diff": payload["median_diff"],
                "lstm_win_rate": payload["lstm_win_rate"],
                "wilcoxon_p": payload.get("wilcoxon_p"),
                "ci95_low": payload["median_diff_CI95"][0],
                "ci95_high": payload["median_diff_CI95"][1],
            })
        return pd.DataFrame(rows)

    def provenance_sources(self) -> Dict[str, object]:
        conceptual = {model: self.conceptual_summaries[model] for model in MODEL_ORDER}
        conceptual_files = list(conceptual.values())
        return {
            "conceptual": conceptual,
            "main_benchmark": conceptual_files + [self.lstm_single_metrics, self.lstm_ensemble_metrics],
            "paired": [self.paired_report],
            "paired_status": "auditable_from_saved_report",
            "paired_notes": "Statistical results are read from the audited ID18 compare report.",
            "conceptual_diagnostics": conceptual_files,
            "regime": [self.regime_table, self.lstm_ensemble_metrics],
            "manifest": {
                "conceptual": {model: str(path) for model, path in conceptual.items()},
                "lstm_single_metrics": str(self.lstm_single_metrics),
                "lstm_ensemble_metrics": str(self.lstm_ensemble_metrics),
                "lstm_ensemble_report": str(self.paired_report),
                "regime_source": str(self.regime_table),
            },
        }


@dataclass(frozen=True)
class _IdenticalProtocol(EvidenceProtocol):
    per_basin_nse_table: Path = None
    lstm_single_metrics: Path = None
    conceptual_summaries: Dict[str, Path] = None

    def result_input_paths(self) -> List[Path]:
        return [self.per_basin_nse_table, self.lstm_single_metrics] + [
            self.conceptual_summaries[model] for model in MODEL_ORDER
        ]

    def _registered_panel(self) -> pd.DataFrame:
        frame = pd.read_csv(self.per_basin_nse_table, dtype={"basin_id": str})
        frame["basin_id"] = _bid(frame["basin_id"])
        return frame.rename(columns=_R02_MODEL_NAMES).set_index("basin_id")

    def conceptual_long(self) -> pd.DataFrame:
        frames = []
        for model in MODEL_ORDER:
            frame = pd.read_csv(self.conceptual_summaries[model], dtype={"basin_id": str})
            if "period" in frame.columns:
                frame = frame[frame["period"] == "evaluation"].copy()
            frame["basin_id"] = _bid(frame["basin_id"])
            frame["model"] = model
            frame["cal_eval_gap"] = frame["_cal_nse"] - frame["nse"]
            frames.append(frame)
        return pd.concat(frames, ignore_index=True)

    def per_basin_nse(self) -> pd.DataFrame:
        panel = self._registered_panel()
        single = _read_lstm_metrics(self.lstm_single_metrics, "LSTM_single_s100")
        frame = panel[MODEL_ORDER + ["LSTM_ensemble_8seed"]].join(single, how="left")
        ordered = MODEL_ORDER + ["LSTM_single_s100", "LSTM_ensemble_8seed"]
        return frame[ordered].dropna()

    def regime(self) -> pd.Series:
        return self._registered_panel()["regime"]

    def lstm_ensemble_series(self) -> pd.Series:
        return self._registered_panel()["LSTM_ensemble_8seed"]

    def conceptual_series(self) -> Dict[str, pd.Series]:
        panel = self._registered_panel()
        return {model: panel[model] for model in MODEL_ORDER}

    def provenance_sources(self) -> Dict[str, object]:
        conceptual = {model: self.conceptual_summaries[model] for model in MODEL_ORDER}
        return {
            "conceptual": conceptual,
            "main_benchmark": [self.per_basin_nse_table, self.lstm_single_metrics],
            "paired": [self.per_basin_nse_table],
            "paired_status": "recomputed_from_saved_artifacts",
            "paired_notes": (
                "Paired deltas, win rates, Wilcoxon p-values, and bootstrap confidence intervals are "
                "recomputed from the per-basin efficiencies with the historical bootstrap (seed 0); this "
                "protocol has no pre-registered compare report."
            ),
            "conceptual_diagnostics": list(conceptual.values()),
            "regime": [self.per_basin_nse_table],
            "manifest": {
                "conceptual": {model: str(path) for model, path in conceptual.items()},
                "lstm_single_metrics": str(self.lstm_single_metrics),
                "per_basin_efficiencies": str(self.per_basin_nse_table),
                "paired_comparison": (
                    f"computed from {self.per_basin_nse_table.as_posix()} with the historical bootstrap; "
                    "no registered compare report exists under this protocol"
                ),
                "regime_source": str(self.per_basin_nse_table),
            },
        }


_PROTOCOLS: Dict[str, EvidenceProtocol] = {
    HISTORICAL_PROTOCOL_ID: _HistoricalProtocol(
        protocol_id=HISTORICAL_PROTOCOL_ID,
        label="Published benchmark",
        loss_protocol="published_nse_star",
        description=(
            "The published R01 benchmark: neural network trained on the basin-normalised "
            "squared-error objective, conceptual models calibrated per basin on efficiency."
        ),
        deep_dive=_R01_DEEP_DIVE,
        input_ids={
            "main.GR4J": ["I01"],
            "main.XAJ": ["I02"],
            "main.HBV": ["I03"],
            "main.LSTM_single_s100": ["I05"],
            "main.LSTM_ensemble_8seed": ["I07"],
            "main.reference": ["I01"],
            "diagnostic.GR4J": ["I01"],
            "diagnostic.XAJ": ["I02"],
            "diagnostic.HBV": ["I03"],
            "paired": ["I06"],
            "oracle": ["I01", "I02", "I03", "I07"],
            "regime_summary": ["I01", "I02", "I03", "I07", "I08"],
            "season_concentration": ["I12"],
            "flow_concentration": ["I13"],
            "joint_concentration": ["I14"],
            "population.snow_fraction": ["I09"],
            "population.spring_snow_fraction": ["I10"],
            "population.high_flow_snow_fraction": ["I11"],
        },
        conceptual_summaries={
            "GR4J": _R01_REPRO / "summary" / "gr4j_pdd_cma_FINAL_pt_v1_local_full.csv",
            "XAJ": _R01_REPRO / "summary" / "xaj_pdd_cma_FINAL_pt_v1_5k3_local_full.csv",
            "HBV": _R01_REPRO / "summary" / "hbv_lite_cma_FINAL_pt_v1_warmup_local_full.csv",
        },
        lstm_single_metrics=(
            Path("results/18_lstm_fair_531/lstm_cudalstm_maurer_s100_2026_0616_1513_ep30") /
            "test" / "model_epoch030" / "test_metrics.csv"
        ),
        lstm_ensemble_metrics=_R01_REPORTS / "ensemble_cudalstm_maurer_8seed_per_basin.csv",
        regime_table=_R01_REPRO / "diagnostic" / "cross_method_per_basin_nse.csv",
        paired_report=_R01_REPORTS / "compare_iter2_cudalstm_8seed_ens.json",
    ),
    IDENTICAL_PROTOCOL_ID: _IdenticalProtocol(
        protocol_id=IDENTICAL_PROTOCOL_ID,
        label="Common-protocol rebuild",
        loss_protocol="identical_basin_average_nse",
        description=(
            "The R02 rebuild: every model optimised on the same basin-averaged "
            "one-minus-efficiency objective and scored against one observation series, with "
            "the conceptual models recalibrated under that protocol."
        ),
        deep_dive=_R02_DEEP_DIVE,
        input_ids={
            "main.GR4J": ["N01"],
            "main.XAJ": ["N01"],
            "main.HBV": ["N01"],
            "main.LSTM_single_s100": ["N02"],
            "main.LSTM_ensemble_8seed": ["N01"],
            "main.reference": ["N01"],
            "diagnostic.GR4J": ["N03"],
            "diagnostic.XAJ": ["N04"],
            "diagnostic.HBV": ["N05"],
            "paired": ["N01"],
            "oracle": ["N01"],
            "regime_summary": ["N01"],
            "season_concentration": ["N06"],
            "flow_concentration": ["N07"],
            "joint_concentration": ["N08"],
            "population.snow_fraction": ["N09"],
            "population.spring_snow_fraction": ["N10"],
            "population.high_flow_snow_fraction": ["N11"],
        },
        per_basin_nse_table=_R02_ROOT / "analysis_official_20260723" / "per_basin_nse.csv",
        lstm_single_metrics=_R02_ROOT / "registered_outputs" / "seed_100" / "test_metrics.csv",
        conceptual_summaries={
            "GR4J": _R02_ROOT / "conceptual" / "registered_outputs" / "gr4j_common_loss" /
                    "calibration_summary.csv",
            "XAJ": _R02_ROOT / "conceptual" / "registered_outputs" / "xaj_common_loss" /
                   "calibration_summary.csv",
            "HBV": _R02_ROOT / "conceptual" / "registered_outputs" / "hbv_lite_common_loss" /
                   "calibration_summary.csv",
        },
    ),
}


def list_protocols() -> List[str]:
    return [HISTORICAL_PROTOCOL_ID, IDENTICAL_PROTOCOL_ID]


def get_protocol(protocol_id: str) -> EvidenceProtocol:
    if protocol_id not in _PROTOCOLS:
        raise KeyError(f"Unknown evidence protocol {protocol_id!r}; expected one of {list_protocols()}")
    return _PROTOCOLS[protocol_id]
