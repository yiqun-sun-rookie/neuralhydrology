"""Pure statistics for decomposing the 2009 Kling-Gupta efficiency."""

from __future__ import annotations

import itertools
from collections.abc import Sequence

import numpy as np
import pandas as pd


COMPONENTS = ("correlation", "variability", "mean")
COMPONENT_KEYS = {
    "correlation": "correlation",
    "variability": "variability_ratio",
    "mean": "mean_ratio",
}


def _aligned_finite_arrays(
    obs: Sequence[float],
    sim: Sequence[float],
) -> tuple[np.ndarray, np.ndarray]:
    obs_array = np.asarray(obs, dtype=float)
    sim_array = np.asarray(sim, dtype=float)
    if obs_array.shape != sim_array.shape:
        raise ValueError("observed and simulated discharge must have the same shape")
    valid = np.isfinite(obs_array) & np.isfinite(sim_array)
    return obs_array[valid], sim_array[valid]


def _undefined_component_record(sample_count: int, reason: str) -> dict:
    record = {
        "defined": False,
        "undefined_reason": reason,
        "sample_count": int(sample_count),
        "correlation": np.nan,
        "variability_ratio": np.nan,
        "mean_ratio": np.nan,
        "kge": np.nan,
        "dominant_penalty": "undefined",
    }
    for component in COMPONENTS:
        record[f"{component}_squared_penalty"] = np.nan
        record[f"{component}_penalty_share"] = np.nan
    return record


def kge_components(obs: Sequence[float], sim: Sequence[float]) -> dict:
    """Return the registered 2009 KGE and its three geometric components."""
    obs_array, sim_array = _aligned_finite_arrays(obs, sim)
    sample_count = len(obs_array)
    if sample_count < 2:
        return _undefined_component_record(sample_count, "fewer_than_two_pairs")

    obs_std = float(np.std(obs_array, ddof=0))
    sim_std = float(np.std(sim_array, ddof=0))
    obs_mean = float(np.mean(obs_array))
    if obs_std == 0.0:
        return _undefined_component_record(sample_count, "zero_observed_variability")
    if obs_mean == 0.0:
        return _undefined_component_record(sample_count, "zero_observed_mean")
    if sim_std == 0.0:
        return _undefined_component_record(sample_count, "zero_simulated_variability")

    correlation = float(np.corrcoef(obs_array, sim_array)[0, 1])
    variability_ratio = sim_std / obs_std
    mean_ratio = float(np.mean(sim_array)) / obs_mean
    values = {
        "correlation": correlation,
        "variability": variability_ratio,
        "mean": mean_ratio,
    }
    penalties = {component: float((value - 1.0)**2) for component, value in values.items()}
    squared_distance = float(sum(penalties.values()))
    if squared_distance == 0.0:
        shares = {component: 0.0 for component in COMPONENTS}
        dominant = "none"
    else:
        shares = {
            component: float(penalty / squared_distance)
            for component, penalty in penalties.items()
        }
        dominant = max(COMPONENTS, key=lambda component: penalties[component])

    record = {
        "defined": True,
        "undefined_reason": "",
        "sample_count": int(sample_count),
        "correlation": correlation,
        "variability_ratio": variability_ratio,
        "mean_ratio": mean_ratio,
        "kge": float(1.0 - np.sqrt(squared_distance)),
        "dominant_penalty": dominant,
    }
    for component in COMPONENTS:
        record[f"{component}_squared_penalty"] = penalties[component]
        record[f"{component}_penalty_share"] = shares[component]
    return record


def _kge_from_component_vector(vector: dict) -> float:
    squared_distance = sum(
        (float(vector[key]) - 1.0)**2
        for key in COMPONENT_KEYS.values()
    )
    return float(1.0 - np.sqrt(squared_distance))


def paired_kge_attribution(*, reference: dict, comparator: dict) -> dict:
    """Attribute a paired KGE difference by averaging all replacement orders."""
    values = [
        reference.get(key, np.nan)
        for key in COMPONENT_KEYS.values()
    ] + [
        comparator.get(key, np.nan)
        for key in COMPONENT_KEYS.values()
    ]
    if not np.isfinite(np.asarray(values, dtype=float)).all():
        return {
            "defined": False,
            "undefined_reason": "non_finite_component",
            "kge_reference": np.nan,
            "kge_comparator": np.nan,
            "kge_difference": np.nan,
            "closure_error": np.nan,
            **{f"{component}_attribution": np.nan for component in COMPONENTS},
        }

    marginal_changes = {component: [] for component in COMPONENTS}
    for order in itertools.permutations(COMPONENTS):
        state = {key: float(comparator[key]) for key in COMPONENT_KEYS.values()}
        before = _kge_from_component_vector(state)
        for component in order:
            key = COMPONENT_KEYS[component]
            state[key] = float(reference[key])
            after = _kge_from_component_vector(state)
            marginal_changes[component].append(after - before)
            before = after

    attributions = {
        component: float(np.mean(marginal_changes[component]))
        for component in COMPONENTS
    }
    kge_reference = _kge_from_component_vector(reference)
    kge_comparator = _kge_from_component_vector(comparator)
    difference = float(kge_reference - kge_comparator)
    closure_error = abs(float(sum(attributions.values()) - difference))
    return {
        "defined": True,
        "undefined_reason": "",
        "kge_reference": kge_reference,
        "kge_comparator": kge_comparator,
        "kge_difference": difference,
        "closure_error": closure_error,
        **{
            f"{component}_attribution": attribution
            for component, attribution in attributions.items()
        },
    }


def season_names(dates: Sequence) -> np.ndarray:
    """Return meteorological season names for the supplied dates."""
    months = pd.DatetimeIndex(dates).month.to_numpy()
    seasons = np.full(len(months), "", dtype=object)
    seasons[np.isin(months, [12, 1, 2])] = "winter"
    seasons[np.isin(months, [3, 4, 5])] = "spring"
    seasons[np.isin(months, [6, 7, 8])] = "summer"
    seasons[np.isin(months, [9, 10, 11])] = "autumn"
    return seasons


def observation_flow_groups(
    obs: Sequence[float],
    *,
    low_quantile: float = 0.1,
    high_quantile: float = 0.9,
) -> np.ndarray:
    """Assign observation-defined low, middle, and high flow groups."""
    obs_array = np.asarray(obs, dtype=float)
    if obs_array.ndim != 1 or obs_array.size == 0 or not np.isfinite(obs_array).all():
        raise ValueError("obs must be a non-empty finite one-dimensional array")
    if not 0.0 < low_quantile < high_quantile < 1.0:
        raise ValueError("quantiles must satisfy 0 < low_quantile < high_quantile < 1")
    low_threshold, high_threshold = np.quantile(
        obs_array, [low_quantile, high_quantile])
    groups = np.full(obs_array.size, "middle", dtype=object)
    groups[obs_array <= low_threshold] = "low"
    groups[obs_array >= high_threshold] = "high"
    return groups


def _snow_group(regime: str) -> str:
    return "snow-dominated" if str(regime) == "snow-dominated" else "non-snow"


def component_rows_for_series(
    *,
    basin_id: str,
    model: str,
    dates: Sequence,
    obs: Sequence[float],
    sim: Sequence[float],
    regime: str,
    low_quantile: float = 0.1,
    high_quantile: float = 0.9,
    sensitivity_high_quantile: float = 0.95,
) -> pd.DataFrame:
    """Compute full-period and prespecified context KGE component rows."""
    dates_index = pd.DatetimeIndex(dates)
    obs_array = np.asarray(obs, dtype=float)
    sim_array = np.asarray(sim, dtype=float)
    if len(dates_index) != len(obs_array) or obs_array.shape != sim_array.shape:
        raise ValueError("dates, observed discharge, and simulated discharge must align")
    valid = np.isfinite(obs_array) & np.isfinite(sim_array)
    dates_index = dates_index[valid]
    obs_array = obs_array[valid]
    sim_array = sim_array[valid]
    if len(obs_array) == 0:
        raise ValueError("series contains no paired finite discharge")

    seasons = season_names(dates_index)
    flow_groups = observation_flow_groups(
        obs_array,
        low_quantile=low_quantile,
        high_quantile=high_quantile,
    )
    q95_threshold = float(np.quantile(obs_array, sensitivity_high_quantile))
    contexts: list[tuple[str, str, np.ndarray]] = [
        ("full_period", "all", np.ones(len(obs_array), dtype=bool)),
    ]
    contexts.extend(
        ("season", season, seasons == season)
        for season in ("winter", "spring", "summer", "autumn")
    )
    contexts.extend(
        ("flow", group, flow_groups == group)
        for group in ("low", "middle", "high")
    )
    contexts.append(
        ("flow_sensitivity", "high_q95", obs_array >= q95_threshold))

    rows = []
    for scope, group, mask in contexts:
        if not np.any(mask):
            continue
        rows.append({
            "basin_id": str(basin_id),
            "model": str(model),
            "regime": str(regime),
            "snow_group": _snow_group(regime),
            "scope": scope,
            "group": group,
            **kge_components(obs_array[mask], sim_array[mask]),
        })
    return pd.DataFrame(rows)


def build_paired_attribution_rows(
    rows: pd.DataFrame,
    *,
    reference_model: str = "LSTM",
) -> pd.DataFrame:
    """Build exact per-basin KGE-gap attributions for each comparator."""
    required = {
        "basin_id",
        "model",
        "regime",
        "snow_group",
        "scope",
        "group",
        *COMPONENT_KEYS.values(),
    }
    missing = required - set(rows.columns)
    if missing:
        raise ValueError(f"component rows are missing columns: {sorted(missing)}")
    key_columns = ["basin_id", "regime", "snow_group", "scope", "group"]
    if rows.duplicated([*key_columns, "model"]).any():
        raise ValueError("component rows contain duplicate basin-model-context keys")

    reference = rows.loc[rows["model"] == reference_model].copy()
    comparators = [
        model
        for model in sorted(set(rows["model"]))
        if model != reference_model
    ]
    frames = []
    for comparator_model in comparators:
        comparator = rows.loc[rows["model"] == comparator_model].copy()
        merged = reference.merge(
            comparator,
            on=key_columns,
            how="inner",
            validate="one_to_one",
            suffixes=("_reference", "_comparator"),
        )
        for record in merged.to_dict("records"):
            reference_vector = {
                key: record[f"{key}_reference"]
                for key in COMPONENT_KEYS.values()
            }
            comparator_vector = {
                key: record[f"{key}_comparator"]
                for key in COMPONENT_KEYS.values()
            }
            frames.append({
                **{key: record[key] for key in key_columns},
                "reference_model": reference_model,
                "comparator_model": comparator_model,
                **paired_kge_attribution(
                    reference=reference_vector,
                    comparator=comparator_vector,
                ),
            })
    return pd.DataFrame(frames)


def _with_snow_group_view(rows: pd.DataFrame) -> pd.DataFrame:
    snow = rows.loc[rows["scope"] == "full_period"].copy()
    snow["scope"] = "snow_group"
    snow["group"] = snow["snow_group"]
    return pd.concat([rows, snow], ignore_index=True)


def _bootstrap_interval(
    values: np.ndarray,
    *,
    n_resamples: int,
    rng: np.random.Generator,
    statistic: str,
) -> tuple[float, float]:
    finite = np.asarray(values, dtype=float)
    finite = finite[np.isfinite(finite)]
    if len(finite) == 0:
        return np.nan, np.nan
    indices = rng.integers(0, len(finite), size=(n_resamples, len(finite)))
    samples = finite[indices]
    if statistic == "median":
        statistics = np.median(samples, axis=1)
    elif statistic == "mean":
        statistics = np.mean(samples, axis=1)
    else:
        raise ValueError(f"unknown bootstrap statistic: {statistic}")
    lower, upper = np.quantile(statistics, [0.025, 0.975])
    return float(lower), float(upper)


def summarize_component_rows(
    rows: pd.DataFrame,
    *,
    n_resamples: int,
    seed: int,
) -> pd.DataFrame:
    """Summarize KGE component distances without mixing context definitions."""
    rng = np.random.default_rng(seed)
    views = _with_snow_group_view(rows)
    summaries = []
    for (scope, group, model), frame in views.groupby(
        ["scope", "group", "model"],
        sort=True,
    ):
        valid = frame.loc[frame["defined"].astype(bool)].copy()
        record = {
            "scope": scope,
            "group": group,
            "model": model,
            "basin_count_total": int(frame["basin_id"].nunique()),
            "basin_count_valid": int(valid["basin_id"].nunique()),
            "undefined_basin_count": int(
                frame["basin_id"].nunique() - valid["basin_id"].nunique()),
            "median_kge": float(valid["kge"].median()) if len(valid) else np.nan,
        }
        kge_ci = _bootstrap_interval(
            valid["kge"].to_numpy(dtype=float),
            n_resamples=n_resamples,
            rng=rng,
            statistic="median",
        )
        record["median_kge_ci_lower"], record["median_kge_ci_upper"] = kge_ci
        for component, key in COMPONENT_KEYS.items():
            values = valid[key].to_numpy(dtype=float)
            distances = np.abs(values - 1.0)
            record[f"median_{key}"] = (
                float(np.median(values)) if len(values) else np.nan)
            record[f"median_{component}_distance"] = (
                float(np.median(distances)) if len(distances) else np.nan)
            lower, upper = _bootstrap_interval(
                distances,
                n_resamples=n_resamples,
                rng=rng,
                statistic="median",
            )
            record[f"median_{component}_distance_ci_lower"] = lower
            record[f"median_{component}_distance_ci_upper"] = upper
            record[f"median_{component}_penalty_share"] = (
                float(valid[f"{component}_penalty_share"].median())
                if len(valid)
                else np.nan
            )
            record[f"{component}_dominant_count"] = int(
                (valid["dominant_penalty"] == component).sum())
        summaries.append(record)
    return pd.DataFrame(summaries)


def summarize_paired_attribution(
    rows: pd.DataFrame,
    *,
    n_resamples: int,
    seed: int,
) -> pd.DataFrame:
    """Summarize paired KGE-gap attributions with whole-basin resampling."""
    rng = np.random.default_rng(seed)
    views = _with_snow_group_view(rows)
    summaries = []
    for (scope, group, comparator_model), frame in views.groupby(
        ["scope", "group", "comparator_model"],
        sort=True,
    ):
        valid = frame.loc[frame["defined"].astype(bool)].copy()
        difference = valid["kge_difference"].to_numpy(dtype=float)
        record = {
            "scope": scope,
            "group": group,
            "reference_model": str(frame["reference_model"].iloc[0]),
            "comparator_model": comparator_model,
            "basin_count_total": int(frame["basin_id"].nunique()),
            "basin_count_valid": int(valid["basin_id"].nunique()),
            "undefined_basin_count": int(
                frame["basin_id"].nunique() - valid["basin_id"].nunique()),
            "mean_kge_difference": (
                float(np.mean(difference)) if len(difference) else np.nan),
            "median_kge_difference": (
                float(np.median(difference)) if len(difference) else np.nan),
            "reference_higher_fraction": (
                float(np.mean(difference > 0.0)) if len(difference) else np.nan),
        }
        lower, upper = _bootstrap_interval(
            difference,
            n_resamples=n_resamples,
            rng=rng,
            statistic="mean",
        )
        record["mean_kge_difference_ci_lower"] = lower
        record["mean_kge_difference_ci_upper"] = upper
        for component in COMPONENTS:
            values = valid[f"{component}_attribution"].to_numpy(dtype=float)
            mean_value = float(np.mean(values)) if len(values) else np.nan
            record[f"mean_{component}_attribution"] = mean_value
            lower, upper = _bootstrap_interval(
                values,
                n_resamples=n_resamples,
                rng=rng,
                statistic="mean",
            )
            record[f"mean_{component}_attribution_ci_lower"] = lower
            record[f"mean_{component}_attribution_ci_upper"] = upper
            denominator = record["mean_kge_difference"]
            record[f"mean_{component}_attribution_fraction"] = (
                float(mean_value / denominator)
                if np.isfinite(denominator) and denominator != 0.0
                else np.nan
            )
        attribution_sum = sum(
            record[f"mean_{component}_attribution"]
            for component in COMPONENTS
        )
        record["mean_attribution_closure_error"] = abs(
            float(attribution_sum - record["mean_kge_difference"]))
        record["dominant_mean_attribution"] = max(
            COMPONENTS,
            key=lambda component: record[f"mean_{component}_attribution"],
        )
        summaries.append(record)
    return pd.DataFrame(summaries)
