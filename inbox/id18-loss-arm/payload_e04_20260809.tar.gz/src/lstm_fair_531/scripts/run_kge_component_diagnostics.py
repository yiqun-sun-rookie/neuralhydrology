"""Run the registered D11 Kling-Gupta efficiency component diagnosis."""

from __future__ import annotations

import argparse
import gc
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

from src.lstm_fair_531.scripts.kge_component_diagnostics import (
    COMPONENTS,
    COMPONENT_KEYS,
    build_paired_attribution_rows,
    component_rows_for_series,
    kge_components,
    summarize_component_rows,
    summarize_paired_attribution,
)
from src.lstm_fair_531.scripts.run_context_scale_threshold_robustness import (
    DEFAULT_CONCEPTUAL_MANIFEST,
    DEFAULT_REGIMES,
    DEFAULT_RUN_LEDGER,
    REPO_ROOT,
    _available_gib,
    _current_rss_gib,
    _load_neural_ensemble_low_memory,
    _load_regimes,
    _normalize_basin_id,
    _sha256,
    _source,
)
from src.lstm_fair_531.scripts.run_hydrological_process_diagnostics import (
    _output_record,
    _verify_sources_unchanged,
)


EXPERIMENT_ID = "D11_kge_component_diagnostics_20260727"
FIXED_MODELS = ("LSTM", "GR4J", "Xinanjiang", "HBV-lite")
MODEL_NAME_MAP = {
    "GR4J": "GR4J",
    "XAJ": "Xinanjiang",
    "HBV-lite": "HBV-lite",
}
DEFAULT_CONFIG = (
    REPO_ROOT
    / "src/lstm_fair_531/configs/kge_component_diagnostics_20260727.json"
)
DEFAULT_OUTPUT_DIR = REPO_ROOT / "results/18_lstm_fair_531" / EXPERIMENT_ID
EXPECTED_OUTPUTS = (
    "kge_components_by_basin_context.csv",
    "kge_component_summary.csv",
    "kge_paired_attribution_by_basin_context.csv",
    "kge_paired_attribution_summary.csv",
    "D11_self_checks.json",
    "D11_manifest.json",
)


def _load_json(path: Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _validate_config(path: Path) -> dict:
    config = _load_json(path)
    expected = {
        "experiment_id": EXPERIMENT_ID,
        "analysis_status": "posthoc_arithmetic_attribution",
        "basin_count": 531,
        "required_basin_id": "04213075",
        "models": list(FIXED_MODELS),
        "neural_seeds": [100, 200, 300, 400, 500, 600, 700, 800],
        "flow_quantiles": {
            "low": 0.1,
            "high": 0.9,
            "sensitivity_high": 0.95,
        },
        "bootstrap": {
            "unit": "whole_basin",
            "resamples": 10000,
            "seed": 20260727,
            "confidence_level": 0.95,
        },
    }
    for key, value in expected.items():
        if config.get(key) != value:
            raise ValueError(f"D11 configuration drifted for {key}")
    if float(config.get("minimum_available_memory_gib", 0.0)) != 4.0:
        raise ValueError("D11 minimum-memory gate drifted")
    kge_definition = config.get("kge_definition", {})
    if (
        kge_definition.get("version") != "Gupta_et_al_2009"
        or kge_definition.get("weights") != [1.0, 1.0, 1.0]
        or kge_definition.get("variability_component")
        != "population_standard_deviation_ratio"
        or kge_definition.get("bias_component") != "mean_ratio"
    ):
        raise ValueError("D11 KGE definition drifted")
    return config


def _population_self_checks(
    components: pd.DataFrame,
    paired: pd.DataFrame,
    *,
    expected_basin_count: int,
    required_basin_id: str,
) -> dict:
    component_key = ["basin_id", "model", "scope", "group"]
    paired_key = ["basin_id", "comparator_model", "scope", "group"]
    if components.duplicated(component_key).any():
        raise ValueError("duplicate basin-model-context component keys")
    if paired.duplicated(paired_key).any():
        raise ValueError("duplicate basin-comparator-context attribution keys")

    full = components.loc[components["scope"] == "full_period"].copy()
    population_complete = bool(
        full["basin_id"].nunique() == expected_basin_count
        and set(full["model"]) == set(FIXED_MODELS)
        and len(full) == expected_basin_count * len(FIXED_MODELS)
    )
    if not population_complete:
        raise ValueError("D11 full-period component population is incomplete")
    contains_required = required_basin_id in set(full["basin_id"].astype(str))
    if not contains_required:
        raise ValueError(f"D11 is missing required basin {required_basin_id}")

    defined = components.loc[components["defined"].astype(bool)].copy()
    reconstructed = 1.0 - np.sqrt(
        (defined["correlation"] - 1.0)**2
        + (defined["variability_ratio"] - 1.0)**2
        + (defined["mean_ratio"] - 1.0)**2
    )
    component_error = np.abs(reconstructed - defined["kge"])
    maximum_component_error = (
        float(component_error.max()) if len(component_error) else np.nan)
    maximum_closure_error = (
        float(pd.to_numeric(
            paired["closure_error"], errors="coerce").max())
        if len(paired)
        else np.nan
    )
    return {
        "population_complete": population_complete,
        "basin_count": int(full["basin_id"].nunique()),
        "model_count": int(full["model"].nunique()),
        "contains_required_basin": contains_required,
        "component_row_count": int(len(components)),
        "paired_row_count": int(len(paired)),
        "undefined_component_row_count": int((~components["defined"].astype(bool)).sum()),
        "undefined_attribution_row_count": int((~paired["defined"].astype(bool)).sum()),
        "maximum_component_reconstruction_error": maximum_component_error,
        "maximum_attribution_closure_error": maximum_closure_error,
    }


def _conceptual_registered_kge_crosscheck(
    components: pd.DataFrame,
    artifacts: list[dict],
    *,
    tolerance: float,
    expected_basin_count: int,
    artifact_observation_replay: pd.DataFrame | None = None,
) -> tuple[dict, list[dict]]:
    full = components.loc[
        components["scope"] == "full_period"
    ]
    checks = {}
    sources = []
    for artifact in artifacts:
        source_model = str(artifact["model"])
        model = MODEL_NAME_MAP[source_model]
        path = Path(artifact["calibration_summary_path"])
        expected_hash = str(artifact["calibration_summary_sha256"])
        sources.append(_source(
            f"conceptual_{source_model}_calibration_summary",
            path,
            expected_hash,
        ))
        registered = pd.read_csv(path, dtype={"basin_id": str})
        registered["basin_id"] = registered["basin_id"].map(_normalize_basin_id)
        registered["kge"] = pd.to_numeric(registered["kge"], errors="coerce")
        primary = full.loc[
            full["model"] == model,
            ["basin_id", "defined", "kge"],
        ].copy()
        replay_source = (
            artifact_observation_replay
            if artifact_observation_replay is not None
            else full
        )
        actual = replay_source.loc[
            replay_source["model"] == model,
            ["basin_id", "defined", "kge"],
        ].copy()
        merged = actual.merge(
            registered[["basin_id", "kge"]],
            on="basin_id",
            how="outer",
            validate="one_to_one",
            indicator=True,
            suffixes=("_recomputed", "_registered"),
        )
        if (
            len(merged) != expected_basin_count
            or not merged["_merge"].eq("both").all()
        ):
            raise ValueError(
                f"{model} registered KGE basin keys differ from D11 components")
        actual_undefined = set(
            merged.loc[
                (~merged["defined"].fillna(False).astype(bool))
                | merged["kge_recomputed"].isna(),
                "basin_id",
            ]
        )
        registered_undefined = set(
            merged.loc[merged["kge_registered"].isna(), "basin_id"])
        if actual_undefined != registered_undefined:
            raise ValueError(
                f"{model} registered and recomputed KGE undefined basin keys differ")
        defined = merged.loc[
            merged["kge_recomputed"].notna()
            & merged["kge_registered"].notna()
        ]
        differences = np.abs(
            defined["kge_recomputed"] - defined["kge_registered"])
        maximum = float(differences.max()) if len(differences) else np.nan
        if np.isfinite(maximum) and maximum > tolerance:
            raise ValueError(
                f"{model} registered KGE cross-check failed: "
                f"rows={len(merged)}, maximum_difference={maximum}"
            )
        primary_merged = primary.merge(
            registered[["basin_id", "kge"]],
            on="basin_id",
            how="inner",
            validate="one_to_one",
            suffixes=("_same_observation", "_registered"),
        )
        primary_differences = np.abs(
            primary_merged["kge_same_observation"]
            - primary_merged["kge_registered"]
        ).dropna()
        checks[model] = {
            "basin_count": int(len(merged)),
            "defined_basin_count": int(len(defined)),
            "undefined_basin_count": int(len(actual_undefined)),
            "undefined_basin_ids": sorted(actual_undefined),
            "maximum_absolute_difference": maximum,
            "same_observation_maximum_absolute_difference_from_registered": (
                float(primary_differences.max())
                if len(primary_differences)
                else np.nan
            ),
            "tolerance": float(tolerance),
        }
    return checks, sources


def _load_component_rows(
    *,
    config: dict,
    run_ledger_path: Path,
    conceptual_manifest_path: Path,
    regimes_path: Path,
) -> tuple[pd.DataFrame, pd.DataFrame, list[dict], float, list[dict]]:
    regimes = _load_regimes(regimes_path)
    regime_map = regimes.set_index("basin_id")["regime"].to_dict()
    sources = [_source("frozen_basin_regimes", regimes_path)]
    ensemble, neural_sources = _load_neural_ensemble_low_memory(run_ledger_path)
    sources.extend(neural_sources)
    peak_rss = _current_rss_gib()

    flow = config["flow_quantiles"]
    frames = []
    artifact_observation_replay_rows = []
    for basin_id in sorted(ensemble):
        record = ensemble[basin_id]
        frames.append(component_rows_for_series(
            basin_id=basin_id,
            model="LSTM",
            dates=record["dates"],
            obs=record["obs"],
            sim=record["sim"],
            regime=regime_map[basin_id],
            low_quantile=float(flow["low"]),
            high_quantile=float(flow["high"]),
            sensitivity_high_quantile=float(flow["sensitivity_high"]),
        ))

    conceptual_manifest = _load_json(conceptual_manifest_path)
    sources.append(_source(
        "conceptual_prediction_manifest",
        conceptual_manifest_path,
    ))
    if (
        conceptual_manifest.get("status") != "completed"
        or int(conceptual_manifest.get("basin_count", 0)) != 531
    ):
        raise ValueError("D11 requires the completed 531-basin conceptual manifest")
    artifacts = conceptual_manifest.get("artifacts", [])
    if {str(item.get("model")) for item in artifacts} != set(MODEL_NAME_MAP):
        raise ValueError("D11 requires GR4J, XAJ, and HBV-lite registered artifacts")
    protocol_path = Path(conceptual_manifest["protocol_manifest_path"])
    sources.append(_source(
        "conceptual_common_loss_protocol",
        protocol_path,
        str(conceptual_manifest["protocol_manifest_sha256"]),
    ))
    expected_rows = sum(len(record["obs"]) for record in ensemble.values())
    for artifact in sorted(artifacts, key=lambda item: str(item["model"])):
        source_model = str(artifact["model"])
        model = MODEL_NAME_MAP[source_model]
        path = Path(artifact["daily_predictions_path"])
        expected_hash = str(artifact["daily_predictions_sha256"])
        sources.append(_source(
            f"conceptual_{source_model}_daily_predictions",
            path,
            expected_hash,
        ))
        daily = pd.read_csv(path, dtype={"basin_id": str}, parse_dates=["date"])
        daily["basin_id"] = daily["basin_id"].map(_normalize_basin_id)
        if (
            len(daily) != expected_rows
            or daily["basin_id"].nunique() != 531
            or daily.duplicated(["basin_id", "date"]).any()
        ):
            raise ValueError(f"{model} registered daily population is invalid")
        for basin_id, group in daily.groupby("basin_id", sort=True):
            group = group.sort_values("date")
            reference = ensemble[basin_id]
            dates = pd.DatetimeIndex(group["date"])
            obs = group["obs"].to_numpy(dtype=float)
            if not dates.equals(reference["dates"]):
                raise ValueError(f"{model}, basin {basin_id} dates differ from LSTM")
            if not np.allclose(obs, reference["obs"], rtol=1e-5, atol=1e-4):
                raise ValueError(
                    f"{model}, basin {basin_id} observations differ from LSTM")
            artifact_components = kge_components(
                obs,
                group["sim"].to_numpy(dtype=float),
            )
            artifact_observation_replay_rows.append({
                "basin_id": basin_id,
                "model": model,
                "defined": artifact_components["defined"],
                "kge": artifact_components["kge"],
            })
            frames.append(component_rows_for_series(
                basin_id=basin_id,
                model=model,
                dates=dates,
                obs=reference["obs"],
                sim=group["sim"].to_numpy(dtype=float),
                regime=regime_map[basin_id],
                low_quantile=float(flow["low"]),
                high_quantile=float(flow["high"]),
                sensitivity_high_quantile=float(flow["sensitivity_high"]),
            ))
        if _sha256(path) != expected_hash:
            raise ValueError(f"{model} daily predictions changed while being read")
        peak_rss = max(peak_rss, _current_rss_gib())
        del daily
        gc.collect()
    del ensemble
    gc.collect()
    return (
        pd.concat(frames, ignore_index=True),
        pd.DataFrame(artifact_observation_replay_rows),
        sources,
        peak_rss,
        artifacts,
    )


def _write_json(path: Path, value: dict) -> None:
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def run(
    *,
    output_dir: Path = DEFAULT_OUTPUT_DIR,
    config_path: Path = DEFAULT_CONFIG,
    run_ledger_path: Path = DEFAULT_RUN_LEDGER,
    conceptual_manifest_path: Path = DEFAULT_CONCEPTUAL_MANIFEST,
    regimes_path: Path = DEFAULT_REGIMES,
) -> Path:
    """Execute D11 without modifying any registered prediction artifact."""
    config = _validate_config(config_path)
    available_before = float(_available_gib())
    minimum = float(config["minimum_available_memory_gib"])
    if available_before < minimum:
        raise MemoryError(
            f"D11 requires at least {minimum:.1f} GiB available memory; "
            f"found {available_before:.2f} GiB")

    output_dir = Path(output_dir)
    if output_dir.exists():
        raise FileExistsError(f"D11 refuses to overwrite existing output: {output_dir}")
    output_dir.mkdir(parents=True)
    started = time.perf_counter()
    started_at = datetime.now(timezone.utc)

    (
        components,
        artifact_observation_replay,
        sources,
        peak_rss,
        artifacts,
    ) = _load_component_rows(
        config=config,
        run_ledger_path=run_ledger_path,
        conceptual_manifest_path=conceptual_manifest_path,
        regimes_path=regimes_path,
    )
    paired = build_paired_attribution_rows(components)
    bootstrap = config["bootstrap"]
    component_summary = summarize_component_rows(
        components,
        n_resamples=int(bootstrap["resamples"]),
        seed=int(bootstrap["seed"]),
    )
    paired_summary = summarize_paired_attribution(
        paired,
        n_resamples=int(bootstrap["resamples"]),
        seed=int(bootstrap["seed"]) + 1,
    )
    checks = _population_self_checks(
        components,
        paired,
        expected_basin_count=int(config["basin_count"]),
        required_basin_id=str(config["required_basin_id"]),
    )
    if (
        checks["maximum_component_reconstruction_error"]
        > float(config["maximum_component_reconstruction_error"])
        or checks["maximum_attribution_closure_error"]
        > float(config["maximum_attribution_closure_error"])
    ):
        raise ValueError("D11 mathematical self-check tolerance failed")
    conceptual_checks, conceptual_sources = _conceptual_registered_kge_crosscheck(
        components,
        artifacts,
        tolerance=float(config["registered_conceptual_kge_tolerance"]),
        expected_basin_count=int(config["basin_count"]),
        artifact_observation_replay=artifact_observation_replay,
    )
    sources.extend(conceptual_sources)
    sources.extend([
        _source("d11_configuration", config_path),
        _source(
            "d11_component_statistics",
            REPO_ROOT / "src/lstm_fair_531/scripts/kge_component_diagnostics.py",
        ),
        _source(
            "d11_registered_runner",
            REPO_ROOT / "src/lstm_fair_531/scripts/run_kge_component_diagnostics.py",
        ),
    ])

    output_paths = [
        output_dir / "kge_components_by_basin_context.csv",
        output_dir / "kge_component_summary.csv",
        output_dir / "kge_paired_attribution_by_basin_context.csv",
        output_dir / "kge_paired_attribution_summary.csv",
    ]
    for frame, path in zip(
        [components, component_summary, paired, paired_summary],
        output_paths,
    ):
        frame.to_csv(path, index=False)
    checks["registered_conceptual_kge_crosscheck"] = conceptual_checks
    self_checks_path = output_dir / "D11_self_checks.json"
    _write_json(self_checks_path, checks)
    output_paths.append(self_checks_path)

    verified_sources = _verify_sources_unchanged(sources)
    completed_at = datetime.now(timezone.utc)
    manifest = {
        "schema_version": 1,
        "experiment_id": EXPERIMENT_ID,
        "status": "completed",
        "analysis_status": config["analysis_status"],
        "purpose": config["purpose"],
        "models": config["models"],
        "neural_seeds": config["neural_seeds"],
        "basin_count": config["basin_count"],
        "contains_basin_04213075": checks["contains_required_basin"],
        "evaluation_start": config["evaluation_start"],
        "evaluation_end": config["evaluation_end"],
        "kge_definition": config["kge_definition"],
        "flow_quantiles": config["flow_quantiles"],
        "bootstrap": config["bootstrap"],
        "inference_boundary": config["inference_boundary"],
        "exact_command": (
            "python -X utf8 -m "
            "src.lstm_fair_531.scripts.run_kge_component_diagnostics"
        ),
        "working_directory": str(REPO_ROOT),
        "inputs": verified_sources,
        "outputs": [
            _output_record(path, repo_root=REPO_ROOT)
            for path in sorted(output_paths)
        ],
        "self_checks": checks,
        "started_at_utc": started_at.isoformat(),
        "completed_at_utc": completed_at.isoformat(),
        "runtime_seconds": float(time.perf_counter() - started),
        "available_memory_gib_before": available_before,
        "available_memory_gib_after": float(_available_gib()),
        "peak_process_rss_gib_observed": float(max(peak_rss, _current_rss_gib())),
    }
    manifest_path = output_dir / "D11_manifest.json"
    _write_json(manifest_path, manifest)
    return manifest_path


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run the registered D11 Kling-Gupta component diagnosis.")
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    manifest_path = run(output_dir=args.output_dir, config_path=args.config)
    print(manifest_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
