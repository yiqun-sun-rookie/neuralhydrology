"""Guarded orchestration for the eight fixed identical-loss neural trainings."""

from __future__ import annotations

import argparse
import ast
import copy
import ctypes
import gc
import hashlib
import importlib
import json
import math
import os
import re
import shutil
import stat
import subprocess
import sys
import threading
import time
from ctypes import wintypes
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

import psutil
import yaml

from src.lstm_fair_531.scripts.monitor_identical_basin_nse_resources import (
    MINIMUM_SYSTEM_MEMORY_LAUNCH_FLOOR_GIB,
    RUNTIME_MINIMUM_SYSTEM_MEMORY_GIB,
    calculate_start_gates,
    collect_resource_snapshot,
    derive_runtime_thresholds,
    monitor_process,
)


def _reviewed_repository_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _read_version_literal(version_path: Path) -> str:
    """Read one literal ``__version__`` assignment without executing the file."""
    version_path = Path(version_path)
    try:
        syntax_tree = ast.parse(
            version_path.read_text(encoding="utf-8"), filename=str(version_path)
        )
    except (OSError, SyntaxError) as error:
        raise RuntimeError(f"Unable to parse reviewed package version file: {version_path}") from error
    assignments = [
        statement
        for statement in syntax_tree.body
        if isinstance(statement, ast.Assign)
        and len(statement.targets) == 1
        and isinstance(statement.targets[0], ast.Name)
        and statement.targets[0].id == "__version__"
    ]
    if len(assignments) != 1:
        raise RuntimeError(
            "Reviewed package version file must contain exactly one __version__ assignment: "
            f"{version_path}"
        )
    value = assignments[0].value
    if not isinstance(value, ast.Constant) or not isinstance(value.value, str):
        raise RuntimeError(f"Reviewed package version must be a literal string: {version_path}")
    return value.value


__version__ = _read_version_literal(
    _reviewed_repository_root() / "neuralhydrology" / "__about__.py"
)


FIXED_SEEDS = (100, 200, 300, 400, 500, 600, 700, 800)
FIXED_EPOCH = 30
PROTECTED_SOURCE_ROOTS = ("neuralhydrology", "src/lstm_fair_531")
PREFLIGHT_PROBE_MINIMUM_SYSTEM_MEMORY_GIB = MINIMUM_SYSTEM_MEMORY_LAUNCH_FLOOR_GIB
PREFLIGHT_PROBE_MINIMUM_ACCELERATOR_MEMORY_GIB = 2.0
PREFLIGHT_PROBE_MINIMUM_DISK_GIB = 20.0
MEASURED_PREFLIGHT_INCREMENTAL_SYSTEM_MEMORY_GIB = 2.8443069458007812
PREFLIGHT_DATA_LOAD_MINIMUM_SYSTEM_MEMORY_GIB = (
    MEASURED_PREFLIGHT_INCREMENTAL_SYSTEM_MEMORY_GIB + RUNTIME_MINIMUM_SYSTEM_MEMORY_GIB
)


def validate_fixed_configuration(configuration: dict) -> None:
    """Reject any change to a frozen scientific setting before work starts."""
    basin_manifest = "src/xaj_global_pilot/configs/conceptual_benchmark_camels_us_531_repro.txt"
    expected = {
        "dataset": "camels_us",
        "train_basin_file": basin_manifest,
        "validation_basin_file": basin_manifest,
        "test_basin_file": basin_manifest,
        "device": "cuda:0",
        "model": "cudalstm",
        "hidden_size": 256,
        "output_dropout": 0.4,
        "optimizer": "Adam",
        "loss": "BasinAverageNSE",
        "batch_size": 256,
        "num_workers": 0,
        "epochs": 30,
        "seq_length": 270,
        "predict_last_n": 1,
        "forcings": ["maurer"],
        "dynamic_inputs": ["PRCP(mm/day)", "Tmin(C)", "Tmax(C)", "SRAD(W/m2)", "Vp(Pa)"],
        "target_variables": ["QObs(mm/d)"],
        "static_attributes": [
            "p_mean",
            "pet_mean",
            "aridity",
            "p_seasonality",
            "frac_snow",
            "high_prec_freq",
            "high_prec_dur",
            "low_prec_freq",
            "low_prec_dur",
            "elev_mean",
            "slope_mean",
            "area_gages2",
            "frac_forest",
            "lai_max",
            "lai_diff",
            "gvf_max",
            "gvf_diff",
            "soil_depth_pelletier",
            "soil_depth_statsgo",
            "soil_porosity",
            "soil_conductivity",
            "max_water_content",
            "sand_frac",
            "silt_frac",
            "clay_frac",
            "carbonate_rocks_frac",
            "geol_permeability",
        ],
        "head": "regression",
        "initial_forget_bias": 5,
        "output_activation": "linear",
        "clip_gradient_norm": 1.0,
        "train_start_date": "30/09/2000",
        "train_end_date": "30/09/2008",
        "test_start_date": "01/10/1989",
        "test_end_date": "30/09/1999",
    }
    # neuralhydrology re-serializes path-valued settings with OS-native
    # separators (backslashes on Windows), so compare those by normalized path.
    path_valued_keys = {"train_basin_file", "validation_basin_file", "test_basin_file"}
    for key, value in expected.items():
        actual = configuration.get(key)
        if key in path_valued_keys and isinstance(actual, str):
            if actual.replace("\\", "/") == value:
                continue
        if actual != value:
            raise ValueError(f"Frozen setting {key} must equal {value!r}, got {configuration.get(key)!r}")
    expected_rates = {0: 0.001, 11: 0.0005, 21: 0.0001}
    serialized_rates = configuration.get("learning_rate", {})
    normalized_epochs = [int(epoch) for epoch in serialized_rates]
    if len(normalized_epochs) != len(set(normalized_epochs)):
        raise ValueError("Frozen setting learning_rate must use unique integer epochs")
    actual_rates = {int(epoch): float(rate) for epoch, rate in serialized_rates.items()}
    if actual_rates != expected_rates:
        raise ValueError(
            f"Frozen setting learning_rate must equal {expected_rates!r}, got {actual_rates!r}"
        )


def _validated_fixed_configuration(configuration: dict) -> dict:
    """Return one validated copy with numeric learning rates for the training stack."""
    validate_fixed_configuration(configuration)
    normalized = copy.deepcopy(configuration)
    normalized["learning_rate"] = {
        int(epoch): float(rate) for epoch, rate in normalized["learning_rate"].items()
    }
    return normalized


def _normalized_configuration_value(key: str, value):
    if any(key.endswith(suffix) for suffix in ("_dir", "_path", "_file", "_files")):
        if isinstance(value, list):
            return [str(Path(item).resolve()) for item in value]
        return None if value is None else str(Path(value).resolve())
    return value


def _current_git_description() -> str | None:
    try:
        return subprocess.check_output(
            ["git", "-C", str(Path(__file__).resolve().parents[3]), "describe", "--always"],
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=10,
        ).strip()
    except (OSError, subprocess.SubprocessError):
        return None


def _current_git_head() -> str:
    """Return the exact commit reviewed by the independent pre-training gate."""
    repository_root = Path(__file__).resolve().parents[3]
    try:
        head = subprocess.check_output(
            ["git", "-C", str(repository_root), "rev-parse", "HEAD"],
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=10,
        ).strip()
    except (OSError, subprocess.SubprocessError) as error:
        raise RuntimeError("Unable to resolve the current full git commit") from error
    if re.fullmatch(r"[0-9a-f]{40}", head) is None:
        raise RuntimeError(f"Current git commit must be 40 lowercase hexadecimal characters, got {head!r}")
    return head


def _validate_run_configuration_matches_frozen(
    run_configuration: dict,
    frozen_configuration: dict,
    *,
    run_dir: Path,
    expected_commit_hash: str | None = None,
) -> None:
    """Check a run-local configuration against the frozen seed configuration.

    ``expected_commit_hash`` defaults to the current repository description, which is
    the right reference while the launcher is registering a run it just produced. A
    caller that validates already-registered artifacts must pass the commit those
    artifacts were trained at instead: advancing HEAD by committing a document, a
    test, or a later fix does not change the code that produced them, and must not
    invalidate them. Training-era code is pinned by the protected-source hash
    binding, not by the current value of HEAD.
    """
    allowed_derived_keys = {
        "commit_hash",
        "img_log_dir",
        "number_of_basins",
        "package_version",
        "train_dir",
    }
    unexpected_keys = sorted(set(run_configuration) - set(frozen_configuration) - allowed_derived_keys)
    if unexpected_keys:
        raise ValueError(
            f"run-local configuration has fields absent from the frozen seed configuration: {unexpected_keys}"
        )
    for key, expected in frozen_configuration.items():
        if key == "run_dir":
            continue
        actual = run_configuration.get(key)
        if _normalized_configuration_value(key, actual) != _normalized_configuration_value(key, expected):
            raise ValueError(
                f"run-local configuration field {key} differs from the frozen seed configuration: "
                f"expected {expected!r}, got {actual!r}"
            )
    actual_run_dir = _normalized_configuration_value("run_dir", run_configuration.get("run_dir"))
    if actual_run_dir != str(Path(run_dir).resolve()):
        raise ValueError(
            "run-local configuration field run_dir does not identify its own directory: "
            f"expected {Path(run_dir).resolve()}, got {run_configuration.get('run_dir')!r}"
        )
    if "number_of_basins" in run_configuration and int(run_configuration["number_of_basins"]) != 531:
        raise ValueError("run-local configuration number_of_basins must equal 531")
    expected_versions = {
        "commit_hash": (
            expected_commit_hash if expected_commit_hash is not None else _current_git_description()
        ),
        "package_version": __version__,
    }
    for key, expected in expected_versions.items():
        if key not in run_configuration:
            raise ValueError(f"run-local configuration derived field {key} is required")
        if run_configuration[key] != expected:
            raise ValueError(
                f"run-local configuration derived field {key} differs from frozen seed configuration metadata: "
                f"expected {expected!r}, got {run_configuration[key]!r}"
            )
    expected_derived_directories = {
        "train_dir": Path(run_dir) / "train_data",
        "img_log_dir": Path(run_dir) / "img_log",
    }
    for key, expected in expected_derived_directories.items():
        if key in run_configuration and _normalized_configuration_value(
            key, run_configuration[key]
        ) != str(expected.resolve()):
            raise ValueError(
                f"run-local configuration derived field {key} must equal {expected.resolve()}, "
                f"got {run_configuration[key]!r}"
            )


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _collect_reviewed_source_sha256(repository_root: Path) -> dict[str, str]:
    """Hash tracked and non-ignored untracked files under the protected source roots."""
    repository_root = Path(repository_root).resolve()
    command = [
        "git",
        "-C",
        str(repository_root),
        "ls-files",
        "-z",
        "--cached",
        "--others",
        "--exclude-standard",
        "--",
        *PROTECTED_SOURCE_ROOTS,
    ]
    try:
        encoded_paths = subprocess.check_output(
            command,
            stderr=subprocess.PIPE,
            timeout=30,
        )
    except (OSError, subprocess.SubprocessError) as error:
        detail = getattr(error, "stderr", b"")
        if isinstance(detail, bytes):
            detail = detail.decode(errors="replace")
        raise RuntimeError(
            f"Unable to enumerate protected source files through Git: {str(detail).strip()}"
        ) from error

    relative_paths = sorted({os.fsdecode(item) for item in encoded_paths.split(b"\0") if item})
    source_sha256 = {}
    for relative_path in relative_paths:
        normalized_path = relative_path.replace("\\", "/")
        if not any(
            normalized_path == root or normalized_path.startswith(f"{root}/")
            for root in PROTECTED_SOURCE_ROOTS
        ):
            raise RuntimeError(f"Git returned a path outside the protected source roots: {normalized_path}")
        source_path = repository_root.joinpath(*normalized_path.split("/"))
        if not source_path.is_file():
            raise RuntimeError(f"Protected source file is missing: {normalized_path}")
        source_sha256[normalized_path] = _sha256(source_path)
    return source_sha256


def _assert_reviewed_source_sha256(
    reviewed_source_sha256,
    current_source_sha256: dict[str, str],
    *,
    stage: str,
) -> None:
    if not isinstance(reviewed_source_sha256, dict):
        raise RuntimeError(
            "Independent pre-training review reviewed_source_sha256 must be a path-to-SHA-256 mapping"
        )
    invalid_entries = sorted(
        repr(path)
        for path, digest in reviewed_source_sha256.items()
        if not isinstance(path, str)
        or not isinstance(digest, str)
        or re.fullmatch(r"[0-9a-f]{64}", digest) is None
    )
    if invalid_entries:
        raise RuntimeError(
            "Independent pre-training review reviewed_source_sha256 contains invalid entries: "
            f"{invalid_entries}"
        )

    reviewed_paths = set(reviewed_source_sha256)
    current_paths = set(current_source_sha256)
    missing_paths = sorted(current_paths - reviewed_paths)
    extra_paths = sorted(reviewed_paths - current_paths)
    changed_paths = sorted(
        path
        for path in reviewed_paths & current_paths
        if reviewed_source_sha256[path] != current_source_sha256[path]
    )
    if missing_paths or extra_paths or changed_paths:
        raise RuntimeError(
            f"Protected source bytes differ from reviewed_source_sha256 during {stage}: "
            f"missing={missing_paths}, extra={extra_paths}, changed={changed_paths}"
        )


def _assert_path_unchanged(path: Path, expected_sha256: str, *, label: str) -> None:
    actual_sha256 = _sha256(path)
    if actual_sha256 != expected_sha256:
        raise RuntimeError(
            f"{label} changed before experiment completion: expected {expected_sha256}, "
            f"got {actual_sha256}: {Path(path).resolve()}"
        )


class _ArtifactStabilityGuard:
    """Hold registered files against writes and detect directory changes during terminal validation."""

    _FILE_NOTIFY_FLAGS = 0x00000001 | 0x00000002 | 0x00000004 | 0x00000008 | 0x00000010 | 0x00000100

    def __init__(self, paths, *, directories=(), watch_parent_directories: bool = True) -> None:
        self.paths = tuple(dict.fromkeys(Path(path).resolve() for path in paths))
        self.directories = tuple(dict.fromkeys(Path(path).resolve() for path in directories))
        file_parents = [path.parent for path in self.paths] if watch_parent_directories else []
        self.parents = tuple(
            dict.fromkeys([*file_parents, *self.directories])
        )
        self._kernel32 = None
        self._file_handles = []
        self._change_handles = []
        self._initial_hashes = {}
        self._initial_modes = {}
        self._initial_entries = {}

    def __enter__(self):
        if not self.paths:
            raise ValueError("At least one registered artifact is required for terminal validation")
        for path in self.paths:
            if not path.is_file():
                raise FileNotFoundError(f"Registered artifact does not exist: {path}")
        for directory in self.directories:
            if not directory.is_dir():
                raise FileNotFoundError(
                    f"Registered artifact directory does not exist: {directory}"
                )
        if os.name == "nt":
            self._acquire_windows_guards()
        self._initial_hashes = {path: _sha256(path) for path in self.paths}
        self._initial_modes = {path: path.stat().st_mode for path in self.paths}
        self._initial_entries = {parent: set(parent.iterdir()) for parent in self.parents}
        return self

    def _acquire_windows_guards(self) -> None:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.FindFirstChangeNotificationW.argtypes = [wintypes.LPCWSTR, wintypes.BOOL, wintypes.DWORD]
        kernel32.FindFirstChangeNotificationW.restype = wintypes.HANDLE
        kernel32.FindCloseChangeNotification.argtypes = [wintypes.HANDLE]
        kernel32.CreateFileW.argtypes = [
            wintypes.LPCWSTR,
            wintypes.DWORD,
            wintypes.DWORD,
            wintypes.LPVOID,
            wintypes.DWORD,
            wintypes.DWORD,
            wintypes.HANDLE,
        ]
        kernel32.CreateFileW.restype = wintypes.HANDLE
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        kernel32.WaitForSingleObject.restype = wintypes.DWORD
        invalid_handle = ctypes.c_void_p(-1).value
        try:
            for parent in self.parents:
                handle = kernel32.FindFirstChangeNotificationW(
                    str(parent), False, self._FILE_NOTIFY_FLAGS
                )
                if handle == invalid_handle:
                    raise ctypes.WinError(ctypes.get_last_error())
                self._change_handles.append(handle)
            for path in self.paths:
                handle = kernel32.CreateFileW(
                    str(path),
                    0x80000000 | 0x00000080,
                    0x00000001,
                    None,
                    3,
                    0,
                    None,
                )
                if handle == invalid_handle:
                    raise ctypes.WinError(ctypes.get_last_error())
                self._file_handles.append(handle)
        except BaseException:
            self._kernel32 = kernel32
            self._close_windows_guards()
            raise
        self._kernel32 = kernel32

    def assert_stable(self) -> None:
        if self._kernel32 is not None:
            for parent, handle in zip(self.parents, self._change_handles):
                if self._kernel32.WaitForSingleObject(handle, 0) == 0:
                    raise RuntimeError(
                        f"Registered artifact directory changed during terminal validation: {parent}"
                    )
        for path in self.paths:
            if _sha256(path) != self._initial_hashes[path]:
                raise RuntimeError(f"Registered artifact changed during terminal validation: {path}")
            if path.stat().st_mode != self._initial_modes[path]:
                raise RuntimeError(f"Registered artifact mode changed during terminal validation: {path}")
        for parent, expected_entries in self._initial_entries.items():
            if set(parent.iterdir()) != expected_entries:
                raise RuntimeError(f"Registered artifact directory changed during terminal validation: {parent}")
        if self._kernel32 is not None:
            for parent, handle in zip(self.parents, self._change_handles):
                if self._kernel32.WaitForSingleObject(handle, 0) == 0:
                    raise RuntimeError(
                        f"Registered artifact directory changed during terminal validation: {parent}"
                    )

    def _close_windows_guards(self) -> None:
        if self._kernel32 is None:
            return
        for handle in reversed(self._file_handles):
            self._kernel32.CloseHandle(handle)
        for handle in reversed(self._change_handles):
            self._kernel32.FindCloseChangeNotification(handle)
        self._file_handles.clear()
        self._change_handles.clear()

    def __exit__(self, exc_type, exc_value, traceback) -> bool:
        try:
            if exc_type is None:
                self.assert_stable()
        finally:
            self._close_windows_guards()
        return False


def resolve_data_directory(base_config_path: Path, override: Path | None = None) -> Path:
    """Resolve the CAMELS-US data directory without assuming ignored data exists in a worktree."""
    if override is not None:
        candidate = Path(override).expanduser().resolve()
        if not candidate.is_dir():
            raise FileNotFoundError(f"CAMELS-US data directory does not exist: {candidate}")
        return candidate
    base_config_path = Path(base_config_path).resolve()
    configuration = yaml.safe_load(base_config_path.read_text(encoding="utf-8"))
    configured = Path(configuration["data_dir"])
    repository_root = base_config_path.parents[3]
    candidates = [configured] if configured.is_absolute() else [repository_root / configured]
    try:
        completed = subprocess.run(
            ["git", "rev-parse", "--git-common-dir"],
            cwd=repository_root,
            check=True,
            capture_output=True,
            text=True,
            timeout=10,
        )
        common_git_directory = Path(completed.stdout.strip())
        if not common_git_directory.is_absolute():
            common_git_directory = repository_root / common_git_directory
        candidates.append(common_git_directory.resolve().parent / configured)
    except subprocess.SubprocessError:
        pass
    for candidate in candidates:
        resolved = candidate.resolve()
        if resolved.is_dir():
            return resolved
    raise FileNotFoundError(
        "CAMELS-US data directory does not exist in any approved location: "
        + ", ".join(str(candidate) for candidate in candidates)
    )


def build_immutable_seed_configs(
    base_config_path: Path,
    output_dir: Path,
    data_dir: Path | None = None,
    expected_base_sha256: str | None = None,
) -> list[dict]:
    """Create the eight deterministic configurations or verify existing bytes exactly."""
    base_config_path = Path(base_config_path)
    base_bytes = base_config_path.read_bytes()
    actual_base_sha256 = hashlib.sha256(base_bytes).hexdigest()
    if expected_base_sha256 is not None and actual_base_sha256 != expected_base_sha256:
        raise RuntimeError(
            "The base configuration hash changed after protocol validation: "
            f"expected {expected_base_sha256}, got {actual_base_sha256}"
        )
    configuration = _validated_fixed_configuration(yaml.safe_load(base_bytes.decode("utf-8")))
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    experiment_prefix = re.sub(r"_s\d+$", "", str(configuration["experiment_name"]))
    records = []
    for seed in FIXED_SEEDS:
        seed_configuration = copy.deepcopy(configuration)
        seed_configuration["seed"] = seed
        seed_configuration["experiment_name"] = f"{experiment_prefix}_s{seed}"
        if data_dir is not None:
            seed_configuration["data_dir"] = str(Path(data_dir).resolve())
        encoded = yaml.safe_dump(
            seed_configuration, sort_keys=False, allow_unicode=True
        ).encode("utf-8")
        path = output_dir / f"seed_{seed}.yml"
        if path.exists() and path.read_bytes() != encoded:
            raise RuntimeError(f"Existing immutable seed configuration differs from frozen content: {path}")
        if not path.exists():
            path.write_bytes(encoded)
        records.append({"seed": seed, "path": str(path), "sha256": _sha256(path)})
    return records


def _reviewed_neuralhydrology_launcher_path() -> Path:
    """Return the manifest-covered launcher beside this reviewed runner."""
    return Path(__file__).resolve().with_name("run_reviewed_neuralhydrology.py")


def _resolved_module_file(module, module_name: str) -> Path:
    actual_file = getattr(module, "__file__", None)
    if actual_file is None:
        raise RuntimeError(
            f"Cached {module_name} must have a verifiable file origin in the reviewed neuralhydrology package "
            "under the reviewed repository root"
        )
    try:
        actual_path = Path(actual_file).resolve(strict=True)
    except (OSError, TypeError, ValueError) as error:
        raise RuntimeError(
            f"Cached {module_name} must have a verifiable file origin in the reviewed neuralhydrology package "
            "under the reviewed repository root: "
            f"got {actual_file!r}"
        ) from error
    if not actual_path.is_file():
        raise RuntimeError(
            f"Cached {module_name} must have a verifiable file origin in the reviewed neuralhydrology package "
            "under the reviewed repository root: "
            f"got {actual_path}"
        )
    return actual_path


def _assert_parent_neuralhydrology_origin() -> None:
    reviewed_package_root = (_reviewed_repository_root() / "neuralhydrology").resolve(strict=True)
    for module_name, module in sorted(sys.modules.items()):
        if module_name != "neuralhydrology" and not module_name.startswith("neuralhydrology."):
            continue
        actual_path = _resolved_module_file(module, module_name)
        try:
            actual_path.relative_to(reviewed_package_root)
        except ValueError as error:
            raise RuntimeError(
                f"Cached {module_name} must resolve from the reviewed neuralhydrology package "
                "under the reviewed repository root: "
                f"expected a file under {reviewed_package_root}, got {actual_path}"
            ) from error


def _assert_exact_reviewed_module_origin(module, expected_path: Path, module_name: str) -> None:
    actual_path = _resolved_module_file(module, module_name)
    expected_path = Path(expected_path).resolve(strict=True)
    if actual_path != expected_path:
        raise RuntimeError(
            f"{module_name} must resolve from the reviewed neuralhydrology package under the reviewed repository root: "
            f"expected {expected_path}, got {actual_path}"
        )


def _activate_reviewed_neuralhydrology():
    """Put the reviewed checkout first, then import and attest its package."""
    repository_root = _reviewed_repository_root()
    reviewed_root_entry = str(repository_root)
    sys.path[:] = [reviewed_root_entry] + [
        entry for entry in sys.path if Path(entry or ".").resolve() != repository_root
    ]
    _assert_parent_neuralhydrology_origin()
    neuralhydrology = importlib.import_module("neuralhydrology")
    expected_path = repository_root / "neuralhydrology" / "__init__.py"
    _assert_parent_neuralhydrology_origin()
    _assert_exact_reviewed_module_origin(neuralhydrology, expected_path, "neuralhydrology")
    return neuralhydrology


def build_seed_commands(records: list[dict]) -> list[dict]:
    """Build the fixed train-then-evaluate command order without executing it."""
    launcher_path = str(_reviewed_neuralhydrology_launcher_path())
    commands = []
    for record in records:
        seed = int(record["seed"])
        commands.append(
            {
                "seed": seed,
                "phase": "train",
                "command": [
                    sys.executable,
                    "-X",
                    "utf8",
                    launcher_path,
                    "train",
                    "--config-file",
                    str(record["path"]),
                ],
            }
        )
    for record in records:
        seed = int(record["seed"])
        commands.append(
            {
                "seed": seed,
                "phase": "evaluate",
                "command": [
                    sys.executable,
                    "-X",
                    "utf8",
                    launcher_path,
                    "evaluate",
                    "--run-dir",
                    f"{{run_dir:{seed}}}",
                    "--period",
                    "test",
                    "--epoch",
                    str(FIXED_EPOCH),
                ],
            }
        )
    return commands


def _assert_unchanged(record: dict) -> None:
    actual = _sha256(Path(record["path"]))
    if actual != record["sha256"]:
        raise RuntimeError(
            f"Seed {record['seed']} configuration changed after it was frozen: "
            f"expected {record['sha256']}, got {actual}"
        )


def run_seed_sequence(records: list[dict], execute: Callable[[list[str], str, int], Path | None]) -> list[Path]:
    """Train all seeds sequentially, then evaluate all fixed epoch-30 checkpoints."""
    run_dirs = []
    for record in records:
        seed = int(record["seed"])
        _assert_unchanged(record)
        train_command = build_seed_commands([record])[0]["command"]
        run_dir = execute(train_command, "train", seed)
        _assert_unchanged(record)
        if run_dir is None:
            raise RuntimeError(f"Training seed {seed} did not return a run directory")
        run_dir = Path(run_dir)
        run_dirs.append(run_dir)
    for record, run_dir in zip(records, run_dirs):
        seed = int(record["seed"])
        _assert_unchanged(record)
        evaluate_command = [
            sys.executable,
            "-X",
            "utf8",
            str(_reviewed_neuralhydrology_launcher_path()),
            "evaluate",
            "--run-dir",
            str(run_dir),
            "--period",
            "test",
            "--epoch",
            str(FIXED_EPOCH),
        ]
        execute(evaluate_command, "evaluate", seed)
        _assert_unchanged(record)
    return run_dirs


def _make_read_only(path: Path) -> None:
    path.chmod(path.stat().st_mode & ~(stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH))


def _remove_registered_output_tree(path: Path) -> None:
    if not path.exists():
        return
    for child in path.rglob("*"):
        if child.is_file():
            child.chmod(child.stat().st_mode | stat.S_IWRITE)
    shutil.rmtree(path)


def register_completed_outputs(
    records: list[dict], run_dirs: list[Path], *, archive_root: Path | None = None
) -> list[dict]:
    """Validate outputs, copy them to one atomic read-only archive, and content-pin the copies."""
    if len(records) != len(FIXED_SEEDS) or len(run_dirs) != len(FIXED_SEEDS):
        raise ValueError("Exactly eight seed records and eight run directories are required")
    if archive_root is None:
        archive_root = Path(records[0]["path"]).resolve().parent / "registered_outputs"
    archive_root = Path(archive_root).resolve()
    if archive_root.exists():
        raise FileExistsError(f"Registered output archive already exists: {archive_root}")
    source_artifacts = []
    for seed, record, run_dir_value in zip(FIXED_SEEDS, records, run_dirs):
        if int(record.get("seed", -1)) != seed:
            raise ValueError(f"Seed record order must be {FIXED_SEEDS}")
        _assert_unchanged(record)
        run_dir = Path(run_dir_value).resolve()
        expected_prefix = f"R02_identical_basin_nse_531_s{seed}_"
        if not run_dir.is_dir() or not run_dir.name.startswith(expected_prefix):
            raise ValueError(f"Run directory does not identify the common-loss experiment and seed {seed}: {run_dir}")
        evaluation_dir = run_dir / "test" / f"model_epoch{FIXED_EPOCH:03d}"
        run_configuration_path = run_dir / "config.yml"
        paths = {
            "configuration": run_configuration_path,
            "checkpoint": run_dir / f"model_epoch{FIXED_EPOCH:03d}.pt",
            "predictions": evaluation_dir / "test_results.p",
            "metrics": evaluation_dir / "test_metrics.csv",
        }
        missing = [name for name, path in paths.items() if not path.is_file()]
        if missing:
            raise FileNotFoundError(f"Seed {seed} is missing fixed epoch-{FIXED_EPOCH} artifacts: {missing}")
        frozen_configuration_bytes = Path(record["path"]).read_bytes()
        if hashlib.sha256(frozen_configuration_bytes).hexdigest() != record["sha256"]:
            raise RuntimeError(f"Seed {seed} frozen configuration changed while it was being registered")
        frozen_configuration = yaml.safe_load(frozen_configuration_bytes.decode("utf-8"))
        run_configuration_bytes = run_configuration_path.read_bytes()
        run_configuration_sha256 = hashlib.sha256(run_configuration_bytes).hexdigest()
        run_configuration = yaml.safe_load(run_configuration_bytes.decode("utf-8"))
        source_sha256 = {
            name: run_configuration_sha256 if name == "configuration" else _sha256(path)
            for name, path in paths.items()
        }
        try:
            validate_fixed_configuration(run_configuration)
            expected_experiment_name = f"R02_identical_basin_nse_531_s{seed}"
            if int(run_configuration.get("seed", -1)) != seed:
                raise ValueError(f"seed must equal {seed}, got {run_configuration.get('seed')!r}")
            if run_configuration.get("experiment_name") != expected_experiment_name:
                raise ValueError(
                    f"experiment_name must equal {expected_experiment_name!r}, "
                    f"got {run_configuration.get('experiment_name')!r}"
                )
            _validate_run_configuration_matches_frozen(
                run_configuration, frozen_configuration, run_dir=run_dir
            )
        except (AttributeError, TypeError, ValueError) as error:
            raise ValueError(f"Invalid run-local configuration for seed {seed}: {error}") from error
        source_artifacts.append({
            "seed": seed,
            "run_dir": run_dir,
            "paths": paths,
            "source_sha256": source_sha256,
        })

    staging_root = archive_root.with_name(
        f".{archive_root.name}.staging-{os.getpid()}-{time.time_ns()}"
    )
    staging_root.parent.mkdir(parents=True, exist_ok=True)
    staging_root.mkdir()
    archive_created = False
    registered = []
    archive_names = {
        "configuration": "config.yml",
        "checkpoint": f"model_epoch{FIXED_EPOCH:03d}.pt",
        "predictions": "test_results.p",
        "metrics": "test_metrics.csv",
    }
    try:
        for source_record in source_artifacts:
            seed = int(source_record["seed"])
            seed_staging_dir = staging_root / f"seed_{seed}"
            seed_staging_dir.mkdir()
            output_record: dict[str, object] = {
                "seed": seed,
                "run_dir": str(source_record["run_dir"]),
            }
            for name, source_path in source_record["paths"].items():
                staging_path = seed_staging_dir / archive_names[name]
                shutil.copy2(source_path, staging_path)
                content_sha256 = _sha256(staging_path)
                if content_sha256 != source_record["source_sha256"][name]:
                    raise RuntimeError(
                        f"Seed {seed} {name} changed before archival"
                    )
                _make_read_only(staging_path)
                final_path = archive_root / f"seed_{seed}" / archive_names[name]
                output_record[f"{name}_path"] = str(final_path)
                output_record[f"{name}_sha256"] = content_sha256
            registered.append(output_record)
        staging_root.rename(archive_root)
        archive_created = True
        _assert_registered_outputs_unchanged(registered)
        return registered
    except BaseException:
        _remove_registered_output_tree(staging_root)
        if archive_created:
            _remove_registered_output_tree(archive_root)
        raise


def _registered_output_paths(output_records: list[dict]) -> list[Path]:
    paths = []
    for record in output_records:
        for artifact in ("configuration", "checkpoint", "predictions", "metrics"):
            path_field = f"{artifact}_path"
            if path_field not in record:
                raise RuntimeError(f"Output record is missing {path_field}")
            paths.append(Path(str(record[path_field])).resolve())
    return paths


def _assert_registered_outputs_unchanged(output_records: list[dict]) -> None:
    with _ArtifactStabilityGuard(_registered_output_paths(output_records)):
        for record in output_records:
            seed = int(record.get("seed", -1))
            for artifact in ("configuration", "checkpoint", "predictions", "metrics"):
                hash_field = f"{artifact}_sha256"
                path_field = f"{artifact}_path"
                if hash_field not in record:
                    raise RuntimeError(f"Seed {seed} output record is missing {hash_field}")
                path = Path(str(record[path_field]))
                _assert_path_unchanged(
                    path,
                    str(record[hash_field]),
                    label=f"Seed {seed} registered {artifact}",
                )
                if path.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH):
                    raise RuntimeError(f"Seed {seed} registered {artifact} is not read-only: {path}")


def validate_protocol_manifest(path: Path, *, expected_sha256: str | None = None) -> dict:
    """Require the real-data protocol audit to have passed all 531 basins."""
    path = Path(path)
    encoded = path.read_bytes()
    content_sha256 = hashlib.sha256(encoded).hexdigest()
    if expected_sha256 is not None and content_sha256 != expected_sha256:
        raise RuntimeError(
            f"Protocol manifest changed: expected {expected_sha256}, got {content_sha256}: {path}"
        )
    data = yaml.safe_load(encoded.decode("utf-8"))

    def require(condition: bool, message: str) -> None:
        if not condition:
            raise RuntimeError(f"Invalid protocol evidence ({message}): {path}")

    require(isinstance(data, dict), "document must be a mapping")
    require(str(data.get("status", "")).lower() == "passed", "status must be passed")
    basin_count = int(data.get("basin_count", data.get("n_basins", 0)) or 0)
    require(basin_count == 531, "exactly 531 basins are required")
    require(data.get("experiment_id") == "R02_identical_basin_nse_531", "experiment identifier")
    require(data.get("public_target_start") == "2000-09-30", "public target start")
    require(data.get("public_target_end") == "2008-09-30", "public target end")
    require(
        data.get("public_loss")
        == "equal mean across 531 basins of SSE divided by the basin observation denominator",
        "public loss definition",
    )
    neural_samples = int(data.get("neural_total_valid_samples", 0) or 0)
    conceptual_samples = int(data.get("conceptual_total_valid_samples", 0) or 0)
    require(neural_samples > 0 and neural_samples == conceptual_samples, "equal positive sample counts")
    validation = data.get("validation", {})
    require(int(validation.get("basin_count", 0) or 0) == 531, "validation basin count")
    require(int(validation.get("positive_denominator_count", 0) or 0) == 531, "positive denominators")
    require(int(validation.get("mask_difference_count", -1)) == 0, "identical masks")
    require(float(validation.get("maximum_observation_absolute_difference", float("inf"))) <= 1e-12,
            "identical observations")
    require(float(validation.get("maximum_weight_absolute_difference", float("inf"))) <= 1e-10,
            "identical basin weights")
    require(float(validation.get("single_precision_loss_absolute_difference", float("inf"))) <= 1e-6,
            "single-precision loss gate")
    require(float(validation.get("sine_single_precision_loss_absolute_difference", float("inf"))) <= 1e-6,
            "second single-precision loss gate")
    require(validation.get("target_start") == "2000-09-30", "validation target start")
    require(validation.get("target_end") == "2008-09-30", "validation target end")
    statistics = data.get("persisted_target_statistics_evidence", {})
    require(float(statistics.get("persisted_target_center_absolute_difference", float("inf"))) <= 1e-12,
            "persisted target center")
    require(float(statistics.get("persisted_target_scale_absolute_difference", float("inf"))) <= 1e-12,
            "persisted target scale")
    weights = data.get("persisted_training_weight_evidence", {})
    require(int(weights.get("persisted_training_weight_count", 0) or 0) == 531,
            "persisted training weight count")
    require(float(weights.get("persisted_training_weight_maximum_absolute_difference", float("inf"))) <= 1e-10,
            "persisted training weights")
    require(weights.get("inference_probe_reads_evaluation_period") is False, "no evaluation-period inference read")
    for prefix in ("basin_manifest", "common_dates", "per_basin", "config"):
        artifact_path = Path(str(data.get(f"{prefix}_path", "")))
        require(artifact_path.is_file(), f"{prefix} artifact exists")
        require(_sha256(artifact_path) == data.get(f"{prefix}_sha256"), f"{prefix} artifact hash")
    source_files = data.get("reproducibility", {}).get("source_files", {})
    require(isinstance(source_files, dict) and len(source_files) >= 10, "ten source-file hashes")
    for source_name, record in source_files.items():
        source_path = Path(str(record.get("path", "")))
        require(source_path.is_file(), f"source file exists: {source_name}")
        require(_sha256(source_path) == record.get("sha256"), f"source file hash: {source_name}")
    _assert_path_unchanged(path, content_sha256, label="Common-loss protocol manifest")
    return data


def evaluate_preflight_gates(measurement: dict, gates: dict) -> dict:
    """Compare measured launch availability with every frozen start gate."""
    comparisons = (
        (
            "system_memory",
            "baseline_free_system_memory_gib",
            "required_free_system_memory_gib",
        ),
        (
            "accelerator_memory",
            "baseline_free_accelerator_memory_gib",
            "required_free_accelerator_memory_gib",
        ),
        ("disk", "baseline_free_disk_gib", "required_free_disk_gib"),
    )
    failed = [
        name for name, measured_key, required_key in comparisons
        if float(measurement[measured_key]) < float(gates[required_key])
    ]
    return {"passed": not failed, "failed_gates": failed}


def validate_preflight_manifest(
    path: Path,
    *,
    expected_sha256: str,
    expected_base_config_sha256: str,
    expected_protocol_sha256: str,
) -> dict:
    """Validate one completed preflight without rerunning or rewriting it."""
    path = Path(path)
    encoded = path.read_bytes()
    content_sha256 = hashlib.sha256(encoded).hexdigest()
    if content_sha256 != expected_sha256:
        raise RuntimeError(
            f"Preflight manifest changed: expected {expected_sha256}, got {content_sha256}: {path}"
        )
    data = yaml.safe_load(encoded.decode("utf-8"))

    def require(condition: bool, message: str) -> None:
        if not condition:
            raise RuntimeError(f"Invalid preflight evidence ({message}): {path}")

    require(isinstance(data, dict), "document must be a mapping")
    require(str(data.get("status", "")).lower() == "passed", "status must be passed")
    require(data.get("base_config_sha256") == expected_base_config_sha256, "base configuration hash")
    require(data.get("protocol_manifest_sha256") == expected_protocol_sha256, "protocol manifest hash")
    measurement = data.get("measurement", {})
    require(isinstance(measurement, dict), "measurement must be a mapping")

    def finite_number(mapping: dict, field: str, *, nonnegative: bool = False, positive: bool = False) -> float:
        value = mapping.get(field)
        require(
            isinstance(value, (int, float)) and not isinstance(value, bool),
            f"{field} must be a real number",
        )
        numeric = float(value)
        require(math.isfinite(numeric), f"finite {field}")
        if positive:
            require(numeric > 0.0, f"positive {field}")
        elif nonnegative:
            require(numeric >= 0.0, f"nonnegative {field}")
        return numeric

    measurement_fields = (
        "baseline_free_system_memory_gib",
        "minimum_free_system_memory_during_batch_gib",
        "incremental_system_memory_gib",
        "post_allocation_free_system_memory_gib",
        "baseline_free_accelerator_memory_gib",
        "total_accelerator_memory_gib",
        "peak_accelerator_memory_gib",
        "post_allocation_free_accelerator_memory_gib",
        "baseline_free_disk_gib",
    )
    measured = {
        field: finite_number(measurement, field, nonnegative=True) for field in measurement_fields
    }
    batch_size = finite_number(measurement, "batch_size", nonnegative=True)
    require(batch_size == 256.0, "exact 256-sample measurement")
    require(measurement.get("gradients_finite") is True, "finite gradients")
    finite_number(measurement, "loss")
    estimated_output_growth_gib = finite_number(
        data, "estimated_output_growth_gib", positive=True
    )
    require(
        measured["minimum_free_system_memory_during_batch_gib"]
        <= measured["baseline_free_system_memory_gib"],
        "minimum system memory does not exceed baseline sample",
    )
    require(
        measured["minimum_free_system_memory_during_batch_gib"]
        <= measured["post_allocation_free_system_memory_gib"],
        "minimum system memory does not exceed post-allocation sample",
    )
    total_accelerator_memory_gib = finite_number(
        measurement, "total_accelerator_memory_gib", positive=True
    )
    for field in (
        "baseline_free_accelerator_memory_gib",
        "post_allocation_free_accelerator_memory_gib",
        "peak_accelerator_memory_gib",
    ):
        require(
            measured[field] <= total_accelerator_memory_gib,
            f"{field} does not exceed total accelerator memory",
        )
    expected_incremental_system_memory_gib = max(
        0.0,
        measured["baseline_free_system_memory_gib"]
        - measured["minimum_free_system_memory_during_batch_gib"],
    )
    require(
        measured["incremental_system_memory_gib"] == expected_incremental_system_memory_gib,
        "incremental system memory matches baseline-minus-minimum measurement",
    )

    expected_start_gates = calculate_start_gates(
        incremental_system_memory_gib=measured["incremental_system_memory_gib"],
        peak_accelerator_memory_gib=measured["peak_accelerator_memory_gib"],
        estimated_output_growth_gib=estimated_output_growth_gib,
    )
    start_gates = data.get("start_gates")
    require(isinstance(start_gates, dict), "start gates must be a mapping")
    require(
        set(start_gates) == set(expected_start_gates),
        "start gate keys match measured formula outputs",
    )
    for field, expected_value in expected_start_gates.items():
        require(
            finite_number(start_gates, field) == expected_value,
            f"start gate {field} matches measured formula inputs",
        )

    expected_runtime_thresholds = derive_runtime_thresholds(
        post_allocation_free_system_memory_gib=measured[
            "post_allocation_free_system_memory_gib"
        ],
        post_allocation_free_accelerator_memory_gib=measured[
            "post_allocation_free_accelerator_memory_gib"
        ],
        estimated_output_growth_gib=estimated_output_growth_gib,
    )
    runtime_thresholds = data.get("runtime_thresholds")
    require(isinstance(runtime_thresholds, dict), "runtime thresholds must be a mapping")
    require(
        set(runtime_thresholds) == set(expected_runtime_thresholds),
        "runtime threshold keys match measured formula outputs",
    )
    for field, expected_value in expected_runtime_thresholds.items():
        require(
            finite_number(runtime_thresholds, field) == expected_value,
            f"runtime threshold {field} matches measured formula inputs",
        )

    expected_gate_result = evaluate_preflight_gates(measurement, expected_start_gates)
    gate_result = data.get("gate_result")
    require(isinstance(gate_result, dict), "gate result must be a mapping")
    require(
        set(gate_result) == set(expected_gate_result),
        "gate result keys match measured launch availability",
    )
    require(isinstance(gate_result["passed"], bool), "gate result passed must be boolean")
    require(isinstance(gate_result["failed_gates"], list), "gate result failed gates must be a list")
    require(
        gate_result["passed"] is expected_gate_result["passed"],
        "gate result passed matches measured launch availability",
    )
    require(
        gate_result["failed_gates"] == expected_gate_result["failed_gates"],
        "gate result failed gates match measured launch availability",
    )
    require(expected_gate_result["passed"] is True, "all measured launch gates passed")
    require(not expected_gate_result["failed_gates"], "no measured launch gate failed")
    _assert_path_unchanged(path, content_sha256, label="Preflight manifest")
    return data


def evaluate_current_launch_gates(availability: dict, gates: dict) -> dict:
    """Compare current lightweight telemetry with the task-specific measured launch gates."""
    comparisons = (
        ("system_memory", "free_system_memory_gib", "required_free_system_memory_gib"),
        ("accelerator_memory", "free_accelerator_memory_gib", "required_free_accelerator_memory_gib"),
        ("disk", "free_disk_gib", "required_free_disk_gib"),
    )
    failed = [
        name for name, available_key, required_key in comparisons
        if float(availability[available_key]) < float(gates[required_key])
    ]
    return {"passed": not failed, "failed_gates": failed}


def validate_preflight_probe_safety(
    *, free_system_memory_gib: float, free_accelerator_memory_gib: float, free_disk_gib: float
) -> None:
    """Protect the measurement batch itself with absolute minimum reserves."""
    failures = _preflight_probe_failures(
        free_system_memory_gib=free_system_memory_gib,
        free_accelerator_memory_gib=free_accelerator_memory_gib,
        free_disk_gib=free_disk_gib,
    )
    if failures:
        raise RuntimeError(f"Preflight probe safety floor failed: {', '.join(failures)}")


def validate_preflight_data_load_safety(
    *, free_system_memory_gib: float, free_accelerator_memory_gib: float, free_disk_gib: float
) -> None:
    """Reserve the measured data-loading peak plus the runtime stop floor after imports."""
    failures = _preflight_safety_failures(
        free_system_memory_gib=free_system_memory_gib,
        free_accelerator_memory_gib=free_accelerator_memory_gib,
        free_disk_gib=free_disk_gib,
        minimum_system_memory_gib=PREFLIGHT_DATA_LOAD_MINIMUM_SYSTEM_MEMORY_GIB,
    )
    if failures:
        raise RuntimeError(f"Preflight data-load safety floor failed: {', '.join(failures)}")


def _preflight_probe_failures(
    *, free_system_memory_gib: float, free_accelerator_memory_gib: float, free_disk_gib: float
) -> list[str]:
    return _preflight_safety_failures(
        free_system_memory_gib=free_system_memory_gib,
        free_accelerator_memory_gib=free_accelerator_memory_gib,
        free_disk_gib=free_disk_gib,
        minimum_system_memory_gib=PREFLIGHT_PROBE_MINIMUM_SYSTEM_MEMORY_GIB,
    )


def _preflight_safety_failures(
    *,
    free_system_memory_gib: float,
    free_accelerator_memory_gib: float,
    free_disk_gib: float,
    minimum_system_memory_gib: float,
) -> list[str]:
    failures = []
    if float(free_system_memory_gib) < float(minimum_system_memory_gib):
        failures.append("system_memory")
    if float(free_accelerator_memory_gib) < PREFLIGHT_PROBE_MINIMUM_ACCELERATOR_MEMORY_GIB:
        failures.append("accelerator_memory")
    if float(free_disk_gib) < PREFLIGHT_PROBE_MINIMUM_DISK_GIB:
        failures.append("disk")
    return failures


def collect_preflight_probe_availability(*, workspace: Path) -> dict[str, float]:
    """Collect a lightweight safety snapshot before importing the training stack or loading data."""
    snapshot = collect_resource_snapshot(
        workspace=Path(workspace),
        phase="preflight_probe",
        seed=None,
        process_id=os.getpid(),
        log_path=Path(workspace) / "protocol" / "preflight_probe.log",
    )
    free_accelerator = snapshot.get("free_accelerator_memory_gib")
    return {
        "free_system_memory_gib": float(snapshot["free_system_memory_gib"]),
        "free_accelerator_memory_gib": float(free_accelerator) if free_accelerator is not None else -1.0,
        "free_disk_gib": float(snapshot["free_disk_gib"]),
    }


def _move_batch_to_device(batch: dict, device) -> dict:
    for key in batch.keys():
        if key.startswith("x_d"):
            batch[key] = {name: value.to(device) for name, value in batch[key].items()}
        elif not key.startswith("date"):
            batch[key] = batch[key].to(device)
    return batch


def run_one_batch_preflight(*, base_config_path: Path, staging_root: Path, data_dir: Path) -> dict:
    """Measure one exact 256-sample forward, loss, backward, and optimizer step."""
    _activate_reviewed_neuralhydrology()
    import torch

    from neuralhydrology.training.basetrainer import BaseTrainer
    from neuralhydrology.utils.config import Config

    _assert_parent_neuralhydrology_origin()
    basetrainer_module = sys.modules["neuralhydrology.training.basetrainer"]
    config_module = sys.modules["neuralhydrology.utils.config"]
    reviewed_package_root = _reviewed_repository_root() / "neuralhydrology"
    _assert_exact_reviewed_module_origin(
        basetrainer_module,
        reviewed_package_root / "training" / "basetrainer.py",
        "neuralhydrology.training.basetrainer",
    )
    _assert_exact_reviewed_module_origin(
        config_module,
        reviewed_package_root / "utils" / "config.py",
        "neuralhydrology.utils.config",
    )
    if BaseTrainer is not getattr(basetrainer_module, "BaseTrainer", None):
        raise RuntimeError("BaseTrainer must come from the reviewed neuralhydrology.training.basetrainer module")
    if Config is not getattr(config_module, "Config", None):
        raise RuntimeError("Config must come from the reviewed neuralhydrology.utils.config module")

    base = _validated_fixed_configuration(
        yaml.safe_load(Path(base_config_path).read_text(encoding="utf-8"))
    )
    staging_root = Path(staging_root)
    staging_root.mkdir(parents=True, exist_ok=True)
    measurement_config = copy.deepcopy(base)
    measurement_config.update(
        {
            "experiment_name": f"R02_preflight_{time.time_ns()}",
            "run_dir": str(staging_root),
            "epochs": 1,
            "num_workers": 0,
            "log_tensorboard": False,
            "log_n_figures": 0,
            "data_dir": str(Path(data_dir).resolve()),
        }
    )

    if not torch.cuda.is_available():
        raise RuntimeError("The frozen configuration requires an available CUDA accelerator")
    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.synchronize()
    baseline_memory = psutil.virtual_memory()
    baseline_free_accelerator, total_accelerator = torch.cuda.mem_get_info(0)
    baseline_disk = shutil.disk_usage(staging_root)
    validate_preflight_data_load_safety(
        free_system_memory_gib=baseline_memory.available / 1024**3,
        free_accelerator_memory_gib=baseline_free_accelerator / 1024**3,
        free_disk_gib=baseline_disk.free / 1024**3,
    )
    system_available_samples = [baseline_memory.available]
    processor_samples = [psutil.cpu_percent(interval=None)]
    stop_sampling = threading.Event()

    def sample_system_resources() -> None:
        while not stop_sampling.wait(0.05):
            system_available_samples.append(psutil.virtual_memory().available)
            processor_samples.append(psutil.cpu_percent(interval=None))

    sampler = threading.Thread(target=sample_system_resources, daemon=True)
    sampler.start()
    started = time.perf_counter()
    torch.cuda.reset_peak_memory_stats(0)
    trainer = None
    batch = None
    predictions = None
    loss = None
    try:
        trainer = BaseTrainer(Config(measurement_config))
        trainer.initialize_training()
        batch = next(iter(trainer.loader))
        batch_size = int(batch["y"].shape[0])
        if batch_size != 256:
            raise RuntimeError(f"Preflight batch must contain exactly 256 samples, got {batch_size}")
        batch = _move_batch_to_device(batch, trainer.device)
        batch = trainer.model.pre_model_hook(batch, is_train=True)
        trainer.model.train()
        predictions = trainer.model(batch)
        loss, _ = trainer.loss_obj(predictions, batch)
        if not bool(torch.isfinite(loss).item()):
            raise RuntimeError(f"Preflight loss is non-finite: {loss.item()}")
        trainer.optimizer.zero_grad()
        loss.backward()
        gradients_finite = all(
            parameter.grad is None or bool(torch.isfinite(parameter.grad).all().item())
            for parameter in trainer.model.parameters()
        )
        if not gradients_finite:
            raise RuntimeError("Preflight gradients contain a non-finite value")
        if trainer.cfg.clip_gradient_norm is not None:
            torch.nn.utils.clip_grad_norm_(trainer.model.parameters(), trainer.cfg.clip_gradient_norm)
        trainer.optimizer.step()
        torch.cuda.synchronize()
        post_memory = psutil.virtual_memory()
        post_free_accelerator, _ = torch.cuda.mem_get_info(0)
        system_available_samples.append(post_memory.available)
        processor_samples.append(psutil.cpu_percent(interval=None))
        elapsed = time.perf_counter() - started
        peak_accelerator = torch.cuda.max_memory_reserved(0)
        return {
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "baseline_free_system_memory_gib": baseline_memory.available / 1024**3,
            "minimum_free_system_memory_during_batch_gib": min(system_available_samples) / 1024**3,
            "incremental_system_memory_gib": max(
                0.0, (baseline_memory.available - min(system_available_samples)) / 1024**3
            ),
            "post_allocation_free_system_memory_gib": post_memory.available / 1024**3,
            "baseline_free_accelerator_memory_gib": baseline_free_accelerator / 1024**3,
            "total_accelerator_memory_gib": total_accelerator / 1024**3,
            "peak_accelerator_memory_gib": peak_accelerator / 1024**3,
            "post_allocation_free_accelerator_memory_gib": post_free_accelerator / 1024**3,
            "baseline_free_disk_gib": baseline_disk.free / 1024**3,
            "peak_processor_percent": max(processor_samples),
            "elapsed_seconds": elapsed,
            "batch_size": batch_size,
            "loss": float(loss.detach().cpu().item()),
            "gradients_finite": gradients_finite,
            "staging_run_dir": str(trainer.cfg.run_dir),
        }
    finally:
        stop_sampling.set()
        sampler.join(timeout=2.0)
        del predictions, batch, loss, trainer
        gc.collect()
        torch.cuda.empty_cache()


def _validate_independent_review(
    path: Path,
    *,
    expected_reviewed_head: str,
    expected_preflight_sha256: str,
    expected_protocol_sha256: str,
    expected_reviewed_source_sha256: dict[str, str],
    expected_sha256: str | None = None,
) -> dict:
    encoded = Path(path).read_bytes()
    content_sha256 = hashlib.sha256(encoded).hexdigest()
    if expected_sha256 is not None and content_sha256 != expected_sha256:
        raise RuntimeError(
            f"Independent pre-training review changed: expected {expected_sha256}, "
            f"got {content_sha256}: {path}"
        )
    data = yaml.safe_load(encoded.decode("utf-8"))
    if not isinstance(data, dict):
        raise RuntimeError(f"Independent pre-training review must be a mapping: {path}")
    if str(data.get("status", "")).lower() != "passed":
        raise RuntimeError(f"Independent pre-training review has not passed: {path}")
    expected_bindings = {
        "reviewed_head": expected_reviewed_head,
        "preflight_sha256": expected_preflight_sha256,
        "protocol_sha256": expected_protocol_sha256,
        "reviewer_context": "independent_clean_context",
    }
    for field, expected in expected_bindings.items():
        actual = data.get(field)
        if actual != expected:
            raise RuntimeError(
                f"Independent pre-training review {field} must equal {expected!r}, got {actual!r}: {path}"
            )
    _assert_reviewed_source_sha256(
        data.get("reviewed_source_sha256"),
        expected_reviewed_source_sha256,
        stage="independent review validation",
    )
    _assert_path_unchanged(Path(path), content_sha256, label="Independent pre-training review")
    return data


def _find_run_dir(
    config_path: Path, *, preexisting_run_dirs: set[Path], started_ns: int
) -> Path:
    config = yaml.safe_load(Path(config_path).read_text(encoding="utf-8"))
    run_root = Path(config["run_dir"])
    candidates = []
    for path in run_root.glob(f"{config['experiment_name']}_*"):
        resolved_path = path.resolve()
        checkpoint = resolved_path / f"model_epoch{FIXED_EPOCH:03d}.pt"
        if resolved_path in preexisting_run_dirs or not checkpoint.is_file():
            continue
        if checkpoint.stat().st_mtime_ns < started_ns:
            continue
        candidates.append(resolved_path)
    if not candidates:
        raise RuntimeError(
            f"Training produced no new run directory with a fresh fixed epoch-{FIXED_EPOCH} "
            f"checkpoint for {config['experiment_name']}"
        )
    if len(candidates) != 1:
        raise RuntimeError(
            f"Training produced {len(candidates)} new run directories for {config['experiment_name']}; "
            "exactly one is required"
        )
    run_dir = candidates[0]
    checkpoint = run_dir / f"model_epoch{FIXED_EPOCH:03d}.pt"
    return run_dir


def _new_evaluation_artifact_detector(run_root: Path, started_ns: int) -> Callable[[], bool]:
    def detected() -> bool:
        for path in run_root.rglob("*"):
            try:
                if path.is_file() and "test" in path.parts and path.stat().st_mtime_ns >= started_ns:
                    return True
            except FileNotFoundError:
                continue
        return False

    return detected


def execute_monitored_command(
    *,
    command: list[str],
    phase: str,
    seed: int,
    log_root: Path,
    resource_log_path: Path,
    thresholds: dict,
    workspace: Path,
    expected_reviewed_source_sha256: dict[str, str],
    source_repository_root: Path,
) -> Path | None:
    """Run one child command and enforce the frozen monitor conditions."""
    source_repository_root = Path(source_repository_root).resolve()
    _assert_parent_neuralhydrology_origin()
    _assert_reviewed_source_sha256(
        expected_reviewed_source_sha256,
        _collect_reviewed_source_sha256(source_repository_root),
        stage=f"before seed {seed} {phase} subprocess",
    )
    log_root = Path(log_root)
    log_root.mkdir(parents=True, exist_ok=True)
    log_path = log_root / f"seed_{seed}_{phase}.log"
    environment = os.environ.copy()
    environment["TQDM_DISABLE"] = "1"
    config_path = Path(command[command.index("--config-file") + 1]) if "--config-file" in command else None
    if config_path is not None:
        config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        run_root = Path(config["run_dir"])
        preexisting_run_dirs = (
            {path.resolve() for path in run_root.iterdir() if path.is_dir()} if run_root.is_dir() else set()
        )
    else:
        run_root = Path(command[command.index("--run-dir") + 1]).parent
        preexisting_run_dirs = set()
    started_ns = time.time_ns()
    leakage_detector = (
        _new_evaluation_artifact_detector(run_root, started_ns) if phase == "train" else lambda: False
    )
    with log_path.open("w", encoding="utf-8") as log_handle:
        process = subprocess.Popen(
            command,
            cwd=source_repository_root,
            env=environment,
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            text=True,
        )
        stop_reason = monitor_process(
            process=process,
            phase=phase,
            seed=seed,
            log_path=log_path,
            resource_log_path=resource_log_path,
            thresholds=thresholds,
            workspace=source_repository_root,
            evaluation_leakage_detector=leakage_detector,
        )
        try:
            return_code = process.wait(timeout=30)
        except subprocess.TimeoutExpired:
            process.kill()
            return_code = process.wait(timeout=30)
    _assert_reviewed_source_sha256(
        expected_reviewed_source_sha256,
        _collect_reviewed_source_sha256(source_repository_root),
        stage=f"after seed {seed} {phase} subprocess",
    )
    if stop_reason is not None:
        raise RuntimeError(f"Seed {seed} {phase} stopped by frozen condition: {stop_reason}")
    if return_code != 0:
        raise RuntimeError(f"Seed {seed} {phase} exited with code {return_code}; see {log_path}")
    if phase == "train":
        return _find_run_dir(
            config_path, preexisting_run_dirs=preexisting_run_dirs, started_ns=started_ns
        )
    evaluation_dir = Path(command[command.index("--run-dir") + 1]) / "test" / f"model_epoch{FIXED_EPOCH:03d}"
    if not (evaluation_dir / "test_metrics.csv").exists():
        raise RuntimeError(f"Evaluation did not produce fixed epoch-{FIXED_EPOCH} metrics: {evaluation_dir}")
    return None


def write_state(path: Path, payload: dict) -> None:
    """Atomically replace the local run-state document."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    temporary.replace(path)


def _build_parser() -> argparse.ArgumentParser:
    repository_root = _reviewed_repository_root()
    result_root = repository_root / "results" / "18_lstm_fair_531" / "R02_identical_basin_nse_531"
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--preflight-only", action="store_true")
    mode.add_argument("--launch", action="store_true")
    parser.add_argument(
        "--base-config",
        type=Path,
        default=repository_root / "src" / "lstm_fair_531" / "configs"
        / "lstm_cudalstm_maurer_531_r02_identical_basin_nse.yml",
    )
    parser.add_argument(
        "--protocol-manifest",
        type=Path,
        default=result_root / "protocol" / "common_loss_protocol.json",
    )
    parser.add_argument("--result-root", type=Path, default=result_root)
    parser.add_argument("--data-dir", type=Path, default=None)
    parser.add_argument(
        "--log-root",
        type=Path,
        default=repository_root / "logs" / "18_lstm_fair_531" / "R02_identical_basin_nse_531",
    )
    parser.add_argument("--independent-review", type=Path, default=None)
    parser.add_argument("--estimated-output-gib", type=float, default=8.0)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    protocol_manifest_sha256 = _sha256(args.protocol_manifest)
    protocol = validate_protocol_manifest(
        args.protocol_manifest, expected_sha256=protocol_manifest_sha256
    )
    if _sha256(args.protocol_manifest) != protocol_manifest_sha256:
        raise RuntimeError("The protocol manifest hash changed during initial validation")
    actual_config_sha256 = _sha256(args.base_config)
    if actual_config_sha256 != protocol["config_sha256"]:
        raise RuntimeError(
            "The base configuration hash does not match the independently audited protocol: "
            f"expected {protocol['config_sha256']}, got {actual_config_sha256}"
        )
    base = yaml.safe_load(args.base_config.read_text(encoding="utf-8"))
    validate_fixed_configuration(base)
    data_dir = resolve_data_directory(args.base_config, args.data_dir)
    args.result_root.mkdir(parents=True, exist_ok=True)
    preflight_path = args.result_root / "protocol" / "preflight.json"
    state_path = args.result_root / "registry" / "run_ledger.json"
    probe_availability: dict[str, float] = {}

    def revalidate_protocol(stage: str) -> dict:
        try:
            actual_protocol_manifest_sha256 = _sha256(args.protocol_manifest)
            if actual_protocol_manifest_sha256 != protocol_manifest_sha256:
                raise RuntimeError(
                    f"The protocol manifest hash changed during {stage}: "
                    f"expected {protocol_manifest_sha256}, got {actual_protocol_manifest_sha256}"
                )
            return validate_protocol_manifest(
                args.protocol_manifest, expected_sha256=protocol_manifest_sha256
            )
        except Exception as error:
            failure = {
                "status": "protocol_changed",
                "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                "base_config_path": str(args.base_config),
                "protocol_manifest_path": str(args.protocol_manifest),
                "protocol_manifest_sha256": protocol_manifest_sha256,
                "data_dir": str(data_dir),
                "probe_availability": probe_availability,
                "stage": stage,
                "error": f"{type(error).__name__}: {error}",
            }
            if args.preflight_only:
                write_state(preflight_path, failure)
            write_state(state_path, failure)
            raise

    probe_availability = collect_preflight_probe_availability(workspace=args.result_root)
    if args.preflight_only:
        failed_probe_safety_floors = _preflight_probe_failures(**probe_availability)
        if failed_probe_safety_floors:
            blocked = {
                "status": "probe_blocked",
                "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                "base_config_path": str(args.base_config),
                "protocol_manifest_path": str(args.protocol_manifest),
                "data_dir": str(data_dir),
                "probe_availability": probe_availability,
                "probe_safety_floors": {
                    "minimum_free_system_memory_gib": PREFLIGHT_PROBE_MINIMUM_SYSTEM_MEMORY_GIB,
                    "minimum_free_accelerator_memory_gib": PREFLIGHT_PROBE_MINIMUM_ACCELERATOR_MEMORY_GIB,
                    "minimum_free_disk_gib": PREFLIGHT_PROBE_MINIMUM_DISK_GIB,
                },
                "failed_probe_safety_floors": failed_probe_safety_floors,
            }
            write_state(preflight_path, blocked)
            write_state(state_path, blocked)
            return 2
        try:
            measurement = run_one_batch_preflight(
                base_config_path=args.base_config,
                staging_root=args.result_root / "protocol" / "preflight_staging",
                data_dir=data_dir,
            )
        except Exception as error:
            failure = {
                "status": "measurement_failed",
                "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                "base_config_path": str(args.base_config),
                "protocol_manifest_path": str(args.protocol_manifest),
                "data_dir": str(data_dir),
                "probe_availability": probe_availability,
                "error": f"{type(error).__name__}: {error}",
            }
            write_state(preflight_path, failure)
            write_state(
                state_path,
                {**failure, "status": "preflight_failed"},
            )
            return 2
        protocol = revalidate_protocol("resource measurement")
        gates = calculate_start_gates(
            incremental_system_memory_gib=measurement["incremental_system_memory_gib"],
            peak_accelerator_memory_gib=measurement["peak_accelerator_memory_gib"],
            estimated_output_growth_gib=args.estimated_output_gib,
        )
        gate_result = evaluate_preflight_gates(measurement, gates)
        thresholds = derive_runtime_thresholds(
            post_allocation_free_system_memory_gib=measurement["post_allocation_free_system_memory_gib"],
            post_allocation_free_accelerator_memory_gib=measurement[
                "post_allocation_free_accelerator_memory_gib"
            ],
            estimated_output_growth_gib=args.estimated_output_gib,
        )
        preflight = {
            "status": "passed" if gate_result["passed"] else "blocked",
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "base_config_path": str(args.base_config),
            "base_config_sha256": _sha256(args.base_config),
            "data_dir": str(data_dir),
            "protocol_manifest_path": str(args.protocol_manifest),
            "protocol_manifest_sha256": _sha256(args.protocol_manifest),
            "estimated_output_growth_gib": args.estimated_output_gib,
            "measurement": measurement,
            "start_gates": gates,
            "gate_result": gate_result,
            "runtime_thresholds": thresholds,
        }
        write_state(preflight_path, preflight)
        if not gate_result["passed"]:
            write_state(
                state_path,
                {**preflight, "status": "preflight_blocked", "failed_gates": gate_result["failed_gates"]},
            )
            return 2
        write_state(state_path, {**preflight, "status": "preflight_passed"})
        return 0

    preflight_sha256 = _sha256(preflight_path)
    preflight = validate_preflight_manifest(
        preflight_path,
        expected_sha256=preflight_sha256,
        expected_base_config_sha256=actual_config_sha256,
        expected_protocol_sha256=protocol_manifest_sha256,
    )
    launch_gate_result = evaluate_current_launch_gates(
        probe_availability, preflight["start_gates"]
    )
    if not launch_gate_result["passed"]:
        write_state(state_path, {
            "status": "launch_blocked",
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "base_config_path": str(args.base_config),
            "protocol_manifest_path": str(args.protocol_manifest),
            "protocol_manifest_sha256": protocol_manifest_sha256,
            "preflight_path": str(preflight_path.resolve()),
            "preflight_sha256": preflight_sha256,
            "current_availability": probe_availability,
            "start_gates": preflight["start_gates"],
            "failed_gates": launch_gate_result["failed_gates"],
        })
        return 2
    thresholds = preflight["runtime_thresholds"]

    repository_root = Path(__file__).resolve().parents[3]
    reviewed_source_sha256 = _collect_reviewed_source_sha256(repository_root)
    review_path = Path(args.independent_review or args.result_root / "audit" / "pretraining_review.json").resolve()
    independent_review_sha256 = _sha256(review_path)
    review = _validate_independent_review(
        review_path,
        expected_sha256=independent_review_sha256,
        expected_reviewed_head=_current_git_head(),
        expected_preflight_sha256=preflight_sha256,
        expected_protocol_sha256=protocol_manifest_sha256,
        expected_reviewed_source_sha256=reviewed_source_sha256,
    )
    reviewed_source_sha256 = review["reviewed_source_sha256"]
    _assert_path_unchanged(preflight_path, preflight_sha256, label="Preflight manifest")
    protocol = revalidate_protocol("independent review")
    records = build_immutable_seed_configs(
        args.base_config,
        args.result_root / "configs",
        data_dir=data_dir,
        expected_base_sha256=protocol["config_sha256"],
    )
    resource_log_path = args.log_root / "resources.csv"
    base_config_path = Path(args.base_config).resolve()
    base_config_sha256 = _sha256(base_config_path)
    state = {
        "status": "running",
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "base_config_path": str(base_config_path),
        "base_config_sha256": base_config_sha256,
        "protocol_manifest_path": str(Path(args.protocol_manifest).resolve()),
        "protocol_manifest_sha256": protocol_manifest_sha256,
        "preflight_path": str(preflight_path.resolve()),
        "preflight_sha256": preflight_sha256,
        "independent_review_path": str(review_path),
        "independent_review_sha256": independent_review_sha256,
        "seed_records": records,
        "completed": [],
    }
    write_state(state_path, state)

    def execute(command: list[str], phase: str, seed: int) -> Path | None:
        state.update({"current_seed": seed, "current_phase": phase})
        write_state(state_path, state)
        output = execute_monitored_command(
            command=command,
            phase=phase,
            seed=seed,
            log_root=args.log_root,
            resource_log_path=resource_log_path,
            thresholds=thresholds,
            workspace=repository_root,
            expected_reviewed_source_sha256=reviewed_source_sha256,
            source_repository_root=repository_root,
        )
        state["completed"].append({
            "seed": seed,
            "phase": phase,
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        })
        write_state(state_path, state)
        return output

    def assert_completion_evidence() -> None:
        _assert_reviewed_source_sha256(
            reviewed_source_sha256,
            _collect_reviewed_source_sha256(repository_root),
            stage="experiment completion",
        )
        revalidate_protocol("experiment completion")
        _assert_path_unchanged(base_config_path, base_config_sha256, label="Base configuration")
        _assert_path_unchanged(preflight_path, preflight_sha256, label="Preflight manifest")
        _assert_path_unchanged(
            review_path,
            independent_review_sha256,
            label="Independent pre-training review",
        )
        for record in records:
            _assert_unchanged(record)
        _assert_registered_outputs_unchanged(output_records)

    try:
        run_dirs = run_seed_sequence(records, execute=execute)
        output_records = register_completed_outputs(
            records,
            run_dirs,
            archive_root=args.result_root / "registered_outputs",
        )
        with _ArtifactStabilityGuard(_registered_output_paths(output_records)):
            assert_completion_evidence()
            state.update({
                "status": "completed",
                "run_dirs": [str(Path(path).resolve()) for path in run_dirs],
                "output_records": output_records,
            })
            state.pop("current_seed", None)
            state.pop("current_phase", None)
            write_state(state_path, state)
            assert_completion_evidence()
            return 0
    except BaseException as error:
        state.update({"status": "failed", "error": f"{type(error).__name__}: {error}"})
        write_state(state_path, state)
        raise


if __name__ == "__main__":
    raise SystemExit(main())
