"""Pure statistics for the post-hoc hydrological cause diagnostics.

The functions in this module do not select models, read files, or write
artifacts. Event definitions are inherited from the registered D09 outputs.
"""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np
import pandas as pd
from scipy.stats import spearmanr


def _aligned_numeric_arrays(first: Sequence[float], second: Sequence[float]) -> tuple[np.ndarray, np.ndarray]:
    first_array = np.asarray(first, dtype=float)
    second_array = np.asarray(second, dtype=float)
    if (
            first_array.shape != second_array.shape
            or first_array.ndim != 1
            or first_array.size == 0
    ):
        raise ValueError("inputs must be non-empty aligned one-dimensional arrays")
    return first_array, second_array


def event_peak_concentration(
    aligned_peak_bias: Sequence[float],
    seven_day_volume_bias: Sequence[float],
) -> np.ndarray:
    """Return simulated-to-observed peak share of seven-day event volume.

    The ratio is ``(1 + peak bias) / (1 + volume bias)``. A non-positive
    simulated seven-day volume or a non-finite operand is undefined.
    """
    peak_bias, volume_bias = _aligned_numeric_arrays(aligned_peak_bias, seven_day_volume_bias)
    numerator = 1.0 + peak_bias
    denominator = 1.0 + volume_bias
    valid = (
        np.isfinite(numerator)
        & np.isfinite(denominator)
        & (numerator >= 0.0)
        & (denominator > 0.0)
    )
    result = np.full(peak_bias.shape, np.nan, dtype=float)
    result[valid] = numerator[valid] / denominator[valid]
    return result


def oracle_moment_match(obs: Sequence[float], sim: Sequence[float]) -> dict:
    """Match evaluation-period simulation mean and variance to observations.

    This is an intentionally non-deployable diagnostic. It is undefined when
    the simulated standard deviation is zero.
    """
    obs_array, sim_array = _aligned_numeric_arrays(obs, sim)
    if not np.isfinite(obs_array).all() or not np.isfinite(sim_array).all():
        raise ValueError("obs and sim must contain only finite values")
    simulated_std = float(np.std(sim_array, ddof=0))
    observed_std = float(np.std(obs_array, ddof=0))
    if simulated_std == 0.0:
        return {
            "defined": False,
            "corrected": None,
            "scale": np.nan,
            "offset": np.nan,
            "negative_fraction": np.nan,
        }
    scale = observed_std / simulated_std
    offset = float(np.mean(obs_array) - scale * np.mean(sim_array))
    corrected = scale * sim_array + offset
    return {
        "defined": True,
        "corrected": corrected,
        "scale": float(scale),
        "offset": offset,
        "negative_fraction": float(np.mean(corrected < 0.0)),
    }


def _bootstrap_array_statistics(
    values: np.ndarray,
    *,
    n_resamples: int,
    seed: int,
    statistic: str,
) -> tuple[float, float]:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if values.size == 0:
        return np.nan, np.nan
    if n_resamples <= 0:
        raise ValueError("n_resamples must be positive")
    rng = np.random.default_rng(seed)
    sampled_statistics = np.empty(n_resamples, dtype=float)
    for start in range(0, n_resamples, 1_000):
        stop = min(start + 1_000, n_resamples)
        indices = rng.integers(0, values.size, size=(stop - start, values.size))
        samples = values[indices]
        if statistic == "median":
            sampled_statistics[start:stop] = np.median(samples, axis=1)
        elif statistic == "positive_fraction":
            sampled_statistics[start:stop] = np.mean(samples > 0.0, axis=1)
        else:
            raise ValueError(f"unsupported bootstrap statistic: {statistic}")
    lower, upper = np.quantile(sampled_statistics, [0.025, 0.975])
    return float(lower), float(upper)


def _context_views(rows: pd.DataFrame):
    yield "overall", "all", rows
    if "season" in rows.columns:
        for season, group in rows.groupby("season", sort=True):
            yield "season", str(season), group
    if "regime" in rows.columns:
        snow_group = np.where(rows["regime"].astype(str) == "snow-dominated", "snow-dominated", "non-snow")
        expanded = rows.assign(_snow_group=snow_group)
        for name, group in expanded.groupby("_snow_group", sort=True):
            yield "snow_group", str(name), group.drop(columns="_snow_group")


def summarize_event_shape(
    rows: pd.DataFrame,
    *,
    n_resamples: int = 10_000,
    seed: int = 20260726,
) -> pd.DataFrame:
    """Summarize event peak concentration after equal-basin reduction."""
    required = {
        "basin_id",
        "regime",
        "season",
        "model",
        "event_threshold_quantile",
        "aligned_peak_magnitude_bias",
        "seven_day_volume_bias",
    }
    missing = required.difference(rows.columns)
    if missing:
        raise ValueError(f"event-shape columns are missing: {sorted(missing)}")
    work = rows.copy()
    work["peak_concentration"] = event_peak_concentration(
        pd.to_numeric(work["aligned_peak_magnitude_bias"], errors="coerce").to_numpy(),
        pd.to_numeric(work["seven_day_volume_bias"], errors="coerce").to_numpy(),
    )
    summaries: list[dict] = []
    group_columns = ["event_threshold_quantile", "model"]
    for group_index, (key, model_rows) in enumerate(work.groupby(group_columns, sort=True)):
        threshold, model = key
        for view_index, (scope, group_name, view_rows) in enumerate(_context_views(model_rows)):
            finite = view_rows.loc[np.isfinite(view_rows["peak_concentration"])].copy()
            basin_values = finite.groupby("basin_id", sort=True)["peak_concentration"].median()
            lower, upper = _bootstrap_array_statistics(
                basin_values.to_numpy(dtype=float),
                n_resamples=n_resamples,
                seed=seed + group_index * 100 + view_index,
                statistic="median",
            )
            summaries.append({
                "event_threshold_quantile": float(threshold),
                "model": str(model),
                "scope": scope,
                "group": group_name,
                "median_peak_concentration": (
                    float(basin_values.median()) if len(basin_values) else np.nan
                ),
                "ci_lower": lower,
                "ci_upper": upper,
                "fraction_below_one": (
                    float(np.mean(basin_values.to_numpy(dtype=float) < 1.0))
                    if len(basin_values)
                    else np.nan
                ),
                "basin_count_total": int(view_rows["basin_id"].nunique()),
                "basin_count_valid": int(finite["basin_id"].nunique()),
                "event_count_total": int(len(view_rows)),
                "event_count_valid": int(len(finite)),
                "undefined_event_count": int(len(view_rows) - len(finite)),
            })
    return pd.DataFrame(summaries)


def _safe_spearman(first: pd.Series, second: pd.Series) -> float:
    first_array = pd.to_numeric(first, errors="coerce").to_numpy(dtype=float)
    second_array = pd.to_numeric(second, errors="coerce").to_numpy(dtype=float)
    finite = np.isfinite(first_array) & np.isfinite(second_array)
    if finite.sum() < 3:
        return np.nan
    first_array = first_array[finite]
    second_array = second_array[finite]
    if np.unique(first_array).size < 2 or np.unique(second_array).size < 2:
        return np.nan
    return float(spearmanr(first_array, second_array).statistic)


def _forcing_event_panel(rows: pd.DataFrame) -> pd.DataFrame:
    required = {
        "basin_id",
        "event_threshold_quantile",
        "event_id",
        "observed_peak_date",
        "season",
        "regime",
        "model",
        "seven_day_volume_bias",
        "forcing_gap",
    }
    missing = required.difference(rows.columns)
    if missing:
        raise ValueError(f"forcing-association columns are missing: {sorted(missing)}")
    event_key = [
        "basin_id",
        "event_threshold_quantile",
        "event_id",
        "observed_peak_date",
    ]
    model_event_key = [*event_key, "model"]
    if rows.duplicated(model_event_key).any():
        raise ValueError("duplicate model-event keys in forcing-association rows")
    forcing_counts = rows.groupby(event_key, sort=True)["forcing_gap"].nunique(dropna=False)
    if (forcing_counts != 1).any():
        raise ValueError("forcing gap differs among model rows for the same event")
    metadata = rows.groupby(event_key, as_index=False, sort=True).agg({
        "season": "first",
        "regime": "first",
        "forcing_gap": "first",
        "seven_day_volume_bias": "median",
    }).rename(columns={"seven_day_volume_bias": "common_volume_bias"})
    centered = []
    for _, basin_rows in metadata.groupby(
            ["event_threshold_quantile", "basin_id"], sort=True, dropna=False):
        copy = basin_rows.copy()
        copy["centered_forcing_gap"] = (
            copy["forcing_gap"] - copy["forcing_gap"].median()
        )
        copy["centered_common_volume_bias"] = (
            copy["common_volume_bias"] - copy["common_volume_bias"].median()
        )
        centered.append(copy)
    return pd.concat(centered, ignore_index=True)


def _summarize_forcing_view(
    rows: pd.DataFrame,
    *,
    threshold: float,
    scope: str,
    group: str,
    n_resamples: int,
    seed: int,
) -> dict:
    pooled_rho = _safe_spearman(
        rows["centered_forcing_gap"], rows["centered_common_volume_bias"])
    basin_rhos = []
    for _, basin_rows in rows.groupby("basin_id", sort=True):
        rho = _safe_spearman(
            basin_rows["centered_forcing_gap"],
            basin_rows["centered_common_volume_bias"],
        )
        if np.isfinite(rho):
            basin_rhos.append(rho)
    basin_rhos_array = np.asarray(basin_rhos, dtype=float)
    rho_lower, rho_upper = _bootstrap_array_statistics(
        basin_rhos_array,
        n_resamples=n_resamples,
        seed=seed,
        statistic="median",
    )
    positive_lower, positive_upper = _bootstrap_array_statistics(
        basin_rhos_array,
        n_resamples=n_resamples,
        seed=seed + 1,
        statistic="positive_fraction",
    )
    return {
        "event_threshold_quantile": float(threshold),
        "scope": scope,
        "group": group,
        "unique_event_count": int(len(rows)),
        "basin_count": int(rows["basin_id"].nunique()),
        "basin_correlation_count": int(basin_rhos_array.size),
        "within_event_spearman_rho": pooled_rho,
        "median_basin_spearman_rho": (
            float(np.median(basin_rhos_array)) if basin_rhos_array.size else np.nan
        ),
        "median_basin_rho_ci_lower": rho_lower,
        "median_basin_rho_ci_upper": rho_upper,
        "positive_basin_count": int(np.sum(basin_rhos_array > 0.0)),
        "positive_basin_fraction": (
            float(np.mean(basin_rhos_array > 0.0)) if basin_rhos_array.size else np.nan
        ),
        "positive_fraction_ci_lower": positive_lower,
        "positive_fraction_ci_upper": positive_upper,
    }


def within_basin_forcing_association(
    rows: pd.DataFrame,
    *,
    n_resamples: int = 10_000,
    seed: int = 20260726,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Relate product disagreement to common event-volume bias within basins."""
    panel = _forcing_event_panel(rows)
    summaries: list[dict] = []
    quartile_rows: list[dict] = []
    for threshold_index, (threshold, threshold_rows) in enumerate(
            panel.groupby("event_threshold_quantile", sort=True)):
        views = list(_context_views(threshold_rows))
        for view_index, (scope, group, view_rows) in enumerate(views):
            summaries.append(_summarize_forcing_view(
                view_rows,
                threshold=float(threshold),
                scope=scope,
                group=group,
                n_resamples=n_resamples,
                seed=seed + threshold_index * 100 + view_index * 2,
            ))
        ranks = threshold_rows["centered_forcing_gap"].rank(method="first")
        bins = pd.qcut(ranks, q=4, labels=False) + 1
        quartile_work = threshold_rows.assign(forcing_gap_quartile=bins)
        for quartile, group_rows in quartile_work.groupby("forcing_gap_quartile", sort=True):
            quartile_rows.append({
                "event_threshold_quantile": float(threshold),
                "scope": "overall",
                "group": "all",
                "forcing_gap_quartile": int(quartile),
                "unique_event_count": int(len(group_rows)),
                "centered_forcing_gap": float(group_rows["centered_forcing_gap"].median()),
                "centered_common_volume_bias": float(
                    group_rows["centered_common_volume_bias"].median()),
            })
    return pd.DataFrame(summaries), pd.DataFrame(quartile_rows)


def daily_amplitude_geometry(
    obs: Sequence[float],
    sim: Sequence[float],
    *,
    high_quantile: float = 0.9,
) -> dict:
    """Return daily correlation, variability, and oracle-amplitude diagnostics."""
    obs_array, sim_array = _aligned_numeric_arrays(obs, sim)
    if not np.isfinite(obs_array).all() or not np.isfinite(sim_array).all():
        raise ValueError("obs and sim must contain only finite values")
    if not 0.0 < high_quantile < 1.0:
        raise ValueError("high_quantile must satisfy 0 < q < 1")
    observed_std = float(np.std(obs_array, ddof=0))
    simulated_std = float(np.std(sim_array, ddof=0))
    if observed_std == 0.0 or simulated_std == 0.0:
        correlation = np.nan
    else:
        correlation = float(np.corrcoef(obs_array, sim_array)[0, 1])
    standard_ratio = np.nan if observed_std == 0.0 else simulated_std / observed_std
    threshold = float(np.quantile(obs_array, high_quantile))
    selected = obs_array >= threshold

    def _bias(candidate: np.ndarray) -> float:
        denominator = float(np.mean(obs_array[selected]))
        if denominator == 0.0:
            return np.nan
        return float(np.mean(candidate[selected] - obs_array[selected]) / denominator)

    oracle = oracle_moment_match(obs_array, sim_array)
    return {
        "correlation": correlation,
        "standard_deviation_ratio": float(standard_ratio),
        "standard_deviation_ratio_minus_correlation": (
            float(standard_ratio - correlation)
            if np.isfinite(standard_ratio) and np.isfinite(correlation)
            else np.nan
        ),
        "original_high_flow_bias": _bias(sim_array),
        "oracle_defined": bool(oracle["defined"]),
        "oracle_high_flow_bias": (
            _bias(oracle["corrected"]) if oracle["defined"] else np.nan
        ),
        "oracle_negative_fraction": float(oracle["negative_fraction"]),
        "oracle_scale": float(oracle["scale"]),
        "oracle_offset": float(oracle["offset"]),
    }


def pairwise_event_shape_summary(
    rows: pd.DataFrame,
    *,
    reference_model: str = "LSTM",
    n_resamples: int = 10_000,
    seed: int = 20260726,
) -> pd.DataFrame:
    """Compare basin-median event concentration with a fixed reference model."""
    required = {
        "basin_id",
        "model",
        "event_threshold_quantile",
        "aligned_peak_magnitude_bias",
        "seven_day_volume_bias",
    }
    missing = required.difference(rows.columns)
    if missing:
        raise ValueError(f"pairwise shape columns are missing: {sorted(missing)}")
    work = rows.copy()
    work["peak_concentration"] = event_peak_concentration(
        pd.to_numeric(work["aligned_peak_magnitude_bias"], errors="coerce").to_numpy(),
        pd.to_numeric(work["seven_day_volume_bias"], errors="coerce").to_numpy(),
    )
    finite = work.loc[np.isfinite(work["peak_concentration"])]
    basin = finite.groupby(
        ["event_threshold_quantile", "model", "basin_id"], as_index=False, sort=True
    )["peak_concentration"].median()
    summaries = []
    for threshold_index, (threshold, threshold_rows) in enumerate(
            basin.groupby("event_threshold_quantile", sort=True)):
        reference = threshold_rows.loc[
            threshold_rows["model"] == reference_model,
            ["basin_id", "peak_concentration"],
        ].rename(columns={"peak_concentration": "reference"})
        comparators = sorted(set(threshold_rows["model"]).difference({reference_model}))
        for comparator_index, comparator in enumerate(comparators):
            comparison = threshold_rows.loc[
                threshold_rows["model"] == comparator,
                ["basin_id", "peak_concentration"],
            ].rename(columns={"peak_concentration": "comparator"})
            paired = reference.merge(comparison, on="basin_id", how="inner", validate="one_to_one")
            differences = (paired["reference"] - paired["comparator"]).to_numpy(dtype=float)
            lower, upper = _bootstrap_array_statistics(
                differences,
                n_resamples=n_resamples,
                seed=seed + threshold_index * 10 + comparator_index,
                statistic="median",
            )
            summaries.append({
                "event_threshold_quantile": float(threshold),
                "reference_model": reference_model,
                "comparator_model": comparator,
                "paired_basin_count": int(len(paired)),
                "median_reference_minus_comparator": float(np.median(differences)),
                "ci_lower": lower,
                "ci_upper": upper,
                "reference_higher_fraction": float(np.mean(differences > 0.0)),
            })
    return pd.DataFrame(summaries)


def summarize_amplitude_geometry_rows(rows: pd.DataFrame) -> pd.DataFrame:
    """Reduce basin-level amplitude diagnostics to one equal-basin model row."""
    required = {
        "basin_id",
        "model",
        "correlation",
        "standard_deviation_ratio",
        "standard_deviation_ratio_minus_correlation",
        "original_high_flow_bias",
        "oracle_defined",
        "oracle_high_flow_bias",
        "oracle_negative_fraction",
    }
    missing = required.difference(rows.columns)
    if missing:
        raise ValueError(f"amplitude geometry columns are missing: {sorted(missing)}")
    if rows.duplicated(["basin_id", "model"]).any():
        raise ValueError("amplitude geometry has duplicate basin-model rows")
    summaries = []
    for model, group in rows.groupby("model", sort=True):
        defined = group["oracle_defined"].astype(bool)
        summaries.append({
            "model": str(model),
            "basin_count": int(group["basin_id"].nunique()),
            "oracle_defined_basin_count": int(defined.sum()),
            "oracle_undefined_basin_count": int((~defined).sum()),
            "median_correlation": float(pd.to_numeric(group["correlation"], errors="coerce").median()),
            "median_standard_deviation_ratio": float(
                pd.to_numeric(group["standard_deviation_ratio"], errors="coerce").median()),
            "median_standard_deviation_ratio_minus_correlation": float(
                pd.to_numeric(
                    group["standard_deviation_ratio_minus_correlation"], errors="coerce").median()),
            "median_original_high_flow_bias": float(
                pd.to_numeric(group["original_high_flow_bias"], errors="coerce").median()),
            "median_oracle_high_flow_bias": float(
                pd.to_numeric(group["oracle_high_flow_bias"], errors="coerce").median()),
            "median_oracle_negative_fraction": float(
                pd.to_numeric(group["oracle_negative_fraction"], errors="coerce").median()),
        })
    return pd.DataFrame(summaries)


def _benjamini_hochberg(p_values: np.ndarray) -> np.ndarray:
    values = np.asarray(p_values, dtype=float)
    result = np.full(values.shape, np.nan, dtype=float)
    finite_indices = np.flatnonzero(np.isfinite(values))
    if finite_indices.size == 0:
        return result
    order = finite_indices[np.argsort(values[finite_indices])]
    ranked = values[order] * finite_indices.size / np.arange(1, finite_indices.size + 1)
    adjusted = np.minimum.accumulate(ranked[::-1])[::-1]
    result[order] = np.minimum(adjusted, 1.0)
    return result


def prespecified_cause_associations(
    geometry_rows: pd.DataFrame,
    attributes: pd.DataFrame,
    *,
    attribute_columns: dict[str, str],
) -> pd.DataFrame:
    """Associate common four-model compression with fixed hydroclimate attributes."""
    targets = ["standard_deviation_ratio", "original_high_flow_bias"]
    required_geometry = {"basin_id", "model", *targets}
    missing_geometry = required_geometry.difference(geometry_rows.columns)
    missing_attributes = {"basin_id", *attribute_columns.values()}.difference(attributes.columns)
    if missing_geometry or missing_attributes:
        raise ValueError(
            f"cause-association columns are missing: geometry={sorted(missing_geometry)}, "
            f"attributes={sorted(missing_attributes)}")
    work = geometry_rows.copy()
    work["basin_id"] = work["basin_id"].astype(str).str.zfill(8)
    model_counts = work.groupby("basin_id")["model"].nunique()
    if not (model_counts == 4).all():
        raise ValueError("cause associations require all four models in every basin")
    common = work.groupby("basin_id", as_index=False, sort=True)[targets].median()
    attribute_work = attributes.copy()
    attribute_work["basin_id"] = attribute_work["basin_id"].astype(str).str.zfill(8)
    merged = common.merge(attribute_work, on="basin_id", how="inner", validate="one_to_one")
    rows = []
    for target in targets:
        for attribute, column in attribute_columns.items():
            first = pd.to_numeric(merged[target], errors="coerce").to_numpy(dtype=float)
            second = pd.to_numeric(merged[column], errors="coerce").to_numpy(dtype=float)
            finite = np.isfinite(first) & np.isfinite(second)
            if finite.sum() < 3 or np.unique(first[finite]).size < 2 or np.unique(second[finite]).size < 2:
                rho = p_value = np.nan
            else:
                result = spearmanr(first[finite], second[finite])
                rho = float(result.statistic)
                p_value = float(result.pvalue)
            rows.append({
                "target": target,
                "attribute": attribute,
                "attribute_column": column,
                "basin_count": int(finite.sum()),
                "spearman_rho": rho,
                "p_value": p_value,
            })
    output = pd.DataFrame(rows)
    output["q_value"] = _benjamini_hochberg(output["p_value"].to_numpy(dtype=float))
    return output
