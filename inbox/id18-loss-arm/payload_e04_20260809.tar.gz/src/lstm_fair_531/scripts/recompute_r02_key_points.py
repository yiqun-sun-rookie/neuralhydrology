"""Collapse R02 registered daily predictions into the historical Key Point schema.

The three manuscript Key Points are stated on concentration statistics computed by
``lstm_advantage_decomposition.summarize_advantage_concentration`` (and its joint
counterpart) from a per-basin-context delta table. To restate those Key Points on
the identical-loss R02 results *without changing their definition*, this module
does one thing only: it turns the wide R02 daily panel into exactly the long delta
table the historical code already consumes.

Every metric definition is imported from the module that produced the published
numbers -- calendar seasons, per-basin 0.1/0.9 flow thresholds, group mean absolute
error, group Nash-Sutcliffe efficiency, and the conceptual-minus-neural delta. None
of them is reimplemented here, so the definitions cannot drift.

The one adaptation that is required: the historical delta function hard-codes the
conceptual model name ``HBV`` while the R02 pipeline registers the same model as
``HBV-lite``. That rename happens here and nowhere else.
"""
from __future__ import annotations

from typing import Iterable

import pandas as pd

from src.lstm_fair_531.scripts.analyze_identical_basin_nse_replication import (
    ALL_MODELS,
    NEURAL_MODEL,
)
from src.lstm_fair_531.scripts.seasonal_residual_deep_dive import (
    conceptual_vs_lstm_delta,
    flow_group_labels,
    season_labels,
    summarize_group_metrics,
)

# Matches the default of joint_advantage_decomposition.py, which produced the
# published joint concentration table.
JOINT_MIN_DAYS = 10

# The historical pipeline labelled the conceptual arm "HBV"; R02 registers it as
# "HBV-lite". conceptual_vs_lstm_delta looks the name up literally.
_R02_TO_R01_MODEL_NAMES = {"HBV-lite": "HBV"}

_FAMILY_CONTEXT_COLUMNS = {
    "season": "season",
    "flow": "flow_group",
    "joint": "joint_context",
}

# The historical tables carry a case-type column; R02 evaluates the whole
# population, which the historical run labelled "population_all".
_CASE_TYPE = "population_all"


def label_calendar_season(dates: Iterable[pd.Timestamp]) -> pd.Series:
    """Calendar seasons with December grouped into the following DJF."""
    return season_labels(pd.to_datetime(pd.Series(list(dates))))


def label_three_flow_groups(
    panel: pd.DataFrame, *, low_quantile: float = 0.1, high_quantile: float = 0.9
) -> pd.DataFrame:
    """Add the historical three-way per-basin flow grouping (high / mid / low)."""
    if "basin_id" not in panel.columns or "obs" not in panel.columns:
        raise ValueError("Panel must contain basin_id and obs columns")
    out = panel.copy()
    labels = []
    for _, group in out.groupby("basin_id", sort=False):
        labels.append(flow_group_labels(group["obs"], low_q=low_quantile, high_q=high_quantile))
    out["flow_group"] = pd.concat(labels).reindex(out.index)
    return out


def _label_all_contexts(panel: pd.DataFrame) -> pd.DataFrame:
    labeled = label_three_flow_groups(panel)
    labeled["season"] = label_calendar_season(labeled["date"]).to_numpy()
    labeled["joint_context"] = (
        labeled["season"].astype(str) + "__" + labeled["flow_group"].astype(str)
    )
    return labeled


def _to_long_predictions(labeled: pd.DataFrame) -> pd.DataFrame:
    """Wide one-column-per-model panel -> the long model/obs/sim rows the metrics expect."""
    keep = ["basin_id", "regime", "date", "obs", "season", "flow_group", "joint_context"]
    frames = []
    for model in ALL_MODELS:
        frame = labeled[keep + [model]].copy()
        frame = frame.rename(columns={model: "sim"})
        frame["model"] = _R02_TO_R01_MODEL_NAMES.get(model, model)
        frames.append(frame)
    long = pd.concat(frames, ignore_index=True)
    long["case_type"] = _CASE_TYPE
    return long


def build_context_delta_table(
    panel: pd.DataFrame, *, family: str, min_days: int = JOINT_MIN_DAYS
) -> pd.DataFrame:
    """Build the historical per-basin-context conceptual-minus-neural delta table.

    ``family`` is one of ``season`` (four calendar seasons), ``flow`` (high / mid /
    low) or ``joint`` (season x flow group, subject to the minimum-day filter that
    produced the published joint table).
    """
    if family not in _FAMILY_CONTEXT_COLUMNS:
        raise ValueError(f"family must be one of {sorted(_FAMILY_CONTEXT_COLUMNS)}; got {family!r}")
    required = {"basin_id", "date", "obs", "regime", *ALL_MODELS}
    missing = sorted(required - set(panel.columns))
    if missing:
        raise ValueError(f"Daily panel is missing required columns: {missing}")

    context_col = _FAMILY_CONTEXT_COLUMNS[family]
    labeled = _label_all_contexts(panel)
    long = _to_long_predictions(labeled)

    metrics = summarize_group_metrics(
        long, group_cols=["basin_id", "regime", "case_type", "model", context_col]
    )
    if family == "joint" and min_days > 0:
        metrics = metrics[metrics["n_days"] >= min_days].copy()

    delta = conceptual_vs_lstm_delta(
        metrics, group_cols=["basin_id", "regime", "case_type", context_col]
    )

    # Carry the day count through; it is identical across models within a
    # basin-context because every model shares the evaluation mask.
    day_counts = (
        metrics[metrics["model"] == NEURAL_MODEL][
            ["basin_id", "regime", "case_type", context_col, "n_days"]
        ]
        .drop_duplicates()
        .reset_index(drop=True)
    )
    delta = delta.merge(
        day_counts, on=["basin_id", "regime", "case_type", context_col], how="left"
    )
    if family == "joint" and min_days > 0:
        delta = delta[delta["n_days"] >= min_days].reset_index(drop=True)
    return delta


_R01_SCORE_PANEL_MODELS = ("GR4J", "XAJ", "HBV")


def build_r01_score_panel(per_basin_nse: pd.DataFrame) -> pd.DataFrame:
    """Rebuild the historical per-basin score panel from R02 per-basin efficiencies.

    Key Point 2 is stated on a Spearman correlation whose target is the neural
    margin over the *best-by-efficiency* conceptual comparator, which is a different
    selection rule from the mean-absolute-error rule used by Key Points 1 and 3. The
    historical diagnostic script consumes this panel, so rebuilding the panel is
    enough to restate Key Point 2 without touching its definition.
    """
    required = {"basin_id", "regime", NEURAL_MODEL, *_R02_TO_R01_MODEL_NAMES.keys()}
    columns = set(per_basin_nse.columns)
    missing = sorted({"basin_id", "regime", NEURAL_MODEL} - columns)
    if missing:
        raise ValueError(f"Per-basin efficiency table is missing columns: {missing}")

    panel = per_basin_nse.copy()
    panel = panel.rename(columns=_R02_TO_R01_MODEL_NAMES)
    absent = sorted(set(_R01_SCORE_PANEL_MODELS) - set(panel.columns))
    if absent:
        raise ValueError(f"Per-basin efficiency table is missing conceptual models: {absent}")

    conceptual = panel[list(_R01_SCORE_PANEL_MODELS)]
    panel["best_conceptual"] = conceptual.max(axis=1)
    panel["conceptual_winner"] = conceptual.idxmax(axis=1)
    panel["lstm_minus_best_conceptual"] = panel[NEURAL_MODEL] - panel["best_conceptual"]
    keep = [
        "basin_id",
        *_R01_SCORE_PANEL_MODELS,
        NEURAL_MODEL,
        "best_conceptual",
        "conceptual_winner",
        "lstm_minus_best_conceptual",
        "regime",
    ]
    return panel[keep]
