"""Apply a frozen post-hoc population overlay to the completed 531-basin analysis.

This module does not alter training, calibration, forcing, evaluation, or the
original analysis bundle. It exists only to produce a symmetric 530-basin
sensitivity analysis while retaining the one excluded input anomaly separately.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import re
import shutil
import stat
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd

from src.lstm_fair_531.scripts.analyze_identical_basin_nse_replication import (
    ALL_MODELS,
    LOSS_PROTOCOL,
    _load_csv_snapshot as _load_base_csv_snapshot,
    _load_json_snapshot as _load_base_json_snapshot,
    _validate_published_analysis_bundle,
    _validate_sources_unchanged,
    _write_json_with_sources,
    paired_high_minus_low_bootstrap,
    summarize_nse,
    write_csv_with_sources,
)
from src.lstm_fair_531.scripts.run_identical_basin_nse_replication import (
    _ArtifactStabilityGuard,
    _current_git_description,
)


EXPECTED_EXPERIMENT_ID = "R02_identical_basin_nse_531"
EXPECTED_OVERLAY_ID = "R02_identical_basin_nse_531_posthoc_population_v1"
EXPECTED_EXCLUDED_BASIN = "04213075"
EXPECTED_BASE_POPULATION_COUNT = 531
EXPECTED_COMPARISON_POPULATION_COUNT = 530
EXPECTED_SCOPE = "all_models_all_comparisons_all_contexts"
EXPECTED_BASIS = "input_quality_independent_of_model_performance"
EXPECTED_CLASSIFICATION = "posthoc_input_quality_sensitivity_analysis"
EXPECTED_FIXED_BOUNDARIES = {
    "train_and_retain_all_531_basins": True,
    "modify_raw_forcing": False,
    "modify_public_training_loss": False,
    "modify_evaluation_period": False,
    "modify_fixed_seeds": False,
    "modify_information_boundary": False,
    "modify_evaluation_metrics": False,
}
_SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")
_REPOSITORY_ROOT = Path(__file__).resolve().parents[3]
_DEFAULT_RESULT_ROOT = (
    _REPOSITORY_ROOT / "results" / "18_lstm_fair_531" / EXPECTED_EXPERIMENT_ID
)
_DEFAULT_OVERLAY_PATH = (
    _REPOSITORY_ROOT
    / "src"
    / "lstm_fair_531"
    / "configs"
    / "identical_basin_nse_population_overlay_v1.json"
)
_OUTPUT_FILENAMES = {
    "base_531_nse_summary": "base_531_nse_summary.csv",
    "base_531_context_summary": "base_531_context_summary.csv",
    "base_531_snow_high_minus_low_bootstrap": "base_531_snow_high_minus_low_bootstrap.json",
    "comparison_per_basin_nse": "comparison_530_per_basin_nse.csv",
    "excluded_anomaly_per_basin_nse": "excluded_anomaly_per_basin_nse.csv",
    "comparison_nse_summary": "comparison_530_nse_summary.csv",
    "comparison_per_basin_context_mae": "comparison_530_per_basin_context_mae.csv",
    "excluded_anomaly_per_basin_context_mae": "excluded_anomaly_per_basin_context_mae.csv",
    "comparison_context_summary": "comparison_530_context_summary.csv",
    "comparison_snow_high_minus_low_bootstrap": "comparison_530_snow_high_minus_low_bootstrap.json",
    "summary_sensitivity_delta": "summary_sensitivity_delta_531_to_530.csv",
}
_MANIFEST_FILENAME = "population_overlay_analysis_manifest.json"


def _require_fields(payload: dict, required: Iterable[str], *, label: str) -> None:
    missing = sorted(set(required) - set(payload))
    if missing:
        raise ValueError(f"{label} is missing required fields: {missing}")


def _normalize_basin_ids(values: pd.Series) -> pd.Series:
    normalized = values.astype(str).str.replace(r"\.0$", "", regex=True).str.strip().str.zfill(8)
    if normalized.eq("").any() or normalized.eq("00000nan").any():
        raise ValueError("Basin identifiers must be non-empty")
    return normalized


def _sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _read_json_snapshot(path: Path, *, label: str) -> tuple[dict, str]:
    path = Path(path).resolve()
    encoded = path.read_bytes()
    content_sha256 = hashlib.sha256(encoded).hexdigest()
    payload = json.loads(encoded.decode("utf-8"))
    if _sha256(path) != content_sha256:
        raise RuntimeError(f"{label} changed while it was being read: {path}")
    if not isinstance(payload, dict):
        raise ValueError(f"{label} must be a JSON object")
    return payload, content_sha256


def _source_record(role: str, path: Path, *, expected_sha256: str | None = None) -> dict:
    path = Path(path).resolve()
    actual_sha256 = _sha256(path)
    if expected_sha256 is not None and actual_sha256 != expected_sha256.lower():
        raise ValueError(
            f"Population overlay evidence hash mismatch for {role}: "
            f"expected {expected_sha256.lower()}, got {actual_sha256}: {path}"
        )
    return {"role": role, "path": str(path), "sha256": actual_sha256}


def _validate_overlay_core(payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("Population overlay must be a JSON object")
    _require_fields(
        payload,
        [
            "schema_version",
            "overlay_id",
            "experiment_id",
            "status",
            "classification",
            "base_population_count",
            "comparison_population_count",
            "common_loss_protocol_sha256",
            "fixed_boundaries",
            "excluded_basins",
        ],
        label="Population overlay",
    )
    if payload["schema_version"] != 1:
        raise ValueError("Population overlay schema_version must be 1")
    if payload["overlay_id"] != EXPECTED_OVERLAY_ID:
        raise ValueError(f"Population overlay_id must be {EXPECTED_OVERLAY_ID}")
    if payload["experiment_id"] != EXPECTED_EXPERIMENT_ID:
        raise ValueError(f"Population overlay experiment_id must be {EXPECTED_EXPERIMENT_ID}")
    if payload["status"] != "frozen":
        raise ValueError("Population overlay status must be frozen")
    if payload["classification"] != EXPECTED_CLASSIFICATION:
        raise ValueError("Population overlay must be classified as a post-hoc input-quality sensitivity analysis")
    if payload["base_population_count"] != EXPECTED_BASE_POPULATION_COUNT:
        raise ValueError("Population overlay must preserve exactly 531 base basins")
    if payload["comparison_population_count"] != EXPECTED_COMPARISON_POPULATION_COUNT:
        raise ValueError("Population overlay must define exactly 530 comparison basins")
    if payload["fixed_boundaries"] != EXPECTED_FIXED_BOUNDARIES:
        raise ValueError("Population overlay fixed boundaries do not match the authorized constraints")
    excluded = payload["excluded_basins"]
    if not isinstance(excluded, list) or len(excluded) != 1:
        raise ValueError("Population overlay must contain exactly one excluded basin")
    record = excluded[0]
    if not isinstance(record, dict):
        raise ValueError("Excluded-basin record must be a JSON object")
    _require_fields(
        record,
        [
            "basin_id",
            "reason_code",
            "exclusion_basis",
            "scope",
            "raw_forcing_path_relative_to_data_root",
            "raw_forcing_sha256",
        ],
        label="Excluded-basin record",
    )
    if str(record["basin_id"]).zfill(8) != EXPECTED_EXCLUDED_BASIN:
        raise ValueError(f"Population overlay may exclude only basin {EXPECTED_EXCLUDED_BASIN}")
    if record["reason_code"] != "maurer_temperature_forcing_anomaly":
        raise ValueError("Excluded basin must use the confirmed Maurer temperature-forcing anomaly reason")
    if record["exclusion_basis"] != EXPECTED_BASIS:
        raise ValueError("Exclusion basis must be independent of model performance")
    if record["scope"] != EXPECTED_SCOPE:
        raise ValueError("The exclusion must apply symmetrically to all models, comparisons, and contexts")
    expected_forcing_path = "basin_mean_forcing/maurer/04/04213075_lump_maurer_forcing_leap.txt"
    if str(record["raw_forcing_path_relative_to_data_root"]).replace("\\", "/") != expected_forcing_path:
        raise ValueError("Excluded basin raw Maurer forcing path is not the frozen target path")
    for label, value in (
        ("common-loss protocol", payload["common_loss_protocol_sha256"]),
        ("raw Maurer forcing", record["raw_forcing_sha256"]),
    ):
        if not isinstance(value, str) or _SHA256_PATTERN.fullmatch(value.lower()) is None:
            raise ValueError(f"Population overlay {label} hash must be a lowercase SHA-256 value")
    return copy.deepcopy(payload)


def validate_population_overlay(
    payload: dict,
    *,
    expected_protocol_sha256: str,
    actual_raw_forcing_sha256: str,
) -> dict:
    """Validate the sole authorized 531-to-530 population rule and its raw bindings."""
    validated = _validate_overlay_core(payload)
    if validated["common_loss_protocol_sha256"].lower() != expected_protocol_sha256.lower():
        raise ValueError("Population overlay common-loss protocol hash does not match the base analysis")
    forcing_hash = validated["excluded_basins"][0]["raw_forcing_sha256"].lower()
    if forcing_hash != actual_raw_forcing_sha256.lower():
        raise ValueError("Population overlay raw Maurer forcing hash does not match the data source")
    return validated


def load_population_overlay(
    overlay_path: Path,
    *,
    protocol_path: Path,
    repository_root: Path,
) -> tuple[dict, list[dict]]:
    """Load the overlay and bind it to the passed protocol, forcing, and diagnosis evidence."""
    overlay_path = Path(overlay_path).resolve()
    protocol_path = Path(protocol_path).resolve()
    repository_root = Path(repository_root).resolve()
    overlay, overlay_sha256 = _read_json_snapshot(overlay_path, label="Analysis population overlay")
    protocol, protocol_sha256 = _read_json_snapshot(protocol_path, label="Common-loss protocol")
    if protocol.get("status") != "passed" or protocol.get("basin_count") != EXPECTED_BASE_POPULATION_COUNT:
        raise ValueError("Common-loss protocol must be passed for exactly 531 basins")
    data_root_value = protocol.get("data_dir")
    if not isinstance(data_root_value, str) or not data_root_value.strip():
        raise ValueError("Common-loss protocol must register its data_dir")
    data_root = Path(data_root_value).resolve()
    core_validated = _validate_overlay_core(overlay)
    forcing_relative_path = Path(
        str(core_validated["excluded_basins"][0]["raw_forcing_path_relative_to_data_root"])
    )
    forcing_path = (data_root / forcing_relative_path).resolve()
    try:
        forcing_path.relative_to(data_root)
    except ValueError as error:
        raise ValueError("Raw forcing path escapes the common-loss data root") from error
    if not forcing_path.is_file():
        raise FileNotFoundError(f"Registered raw Maurer forcing file does not exist: {forcing_path}")
    validated = validate_population_overlay(
        overlay,
        expected_protocol_sha256=protocol_sha256,
        actual_raw_forcing_sha256=_sha256(forcing_path),
    )
    evidence_bindings = validated.get("evidence_bindings")
    if not isinstance(evidence_bindings, list) or not evidence_bindings:
        raise ValueError("Population overlay must bind at least one independent anomaly evidence artifact")
    sources = [
        _source_record("analysis_population_overlay", overlay_path, expected_sha256=overlay_sha256),
        _source_record("common_loss_protocol", protocol_path, expected_sha256=protocol_sha256),
        _source_record(
            "excluded_basin_raw_maurer_forcing",
            forcing_path,
            expected_sha256=validated["excluded_basins"][0]["raw_forcing_sha256"],
        ),
    ]
    seen_roles = set()
    for binding in evidence_bindings:
        if not isinstance(binding, dict):
            raise ValueError("Population overlay evidence binding must be a JSON object")
        _require_fields(
            binding,
            ["role", "path_relative_to_repository", "sha256"],
            label="Population overlay evidence binding",
        )
        role = str(binding["role"]).strip()
        if not role or role in seen_roles:
            raise ValueError("Population overlay evidence roles must be non-empty and unique")
        seen_roles.add(role)
        evidence_path = (repository_root / str(binding["path_relative_to_repository"])).resolve()
        try:
            evidence_path.relative_to(repository_root)
        except ValueError as error:
            raise ValueError("Population overlay evidence path escapes the repository root") from error
        sources.append(_source_record(role, evidence_path, expected_sha256=str(binding["sha256"])))
    return validated, sources


def apply_population_overlay(
    *,
    per_basin_nse: pd.DataFrame,
    per_basin_context: pd.DataFrame,
    overlay: dict,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split a complete 531-basin analysis into one shared 530 set and one anomaly."""
    validated = _validate_overlay_core(overlay)
    required_nse_columns = {"basin_id", *ALL_MODELS}
    missing_nse = sorted(required_nse_columns - set(per_basin_nse.columns))
    if missing_nse:
        raise ValueError(f"Per-basin NSE table is missing required columns: {missing_nse}")
    required_context_columns = {
        "basin_id",
        "regime",
        "context",
        "lstm_mae",
        "gr4j_mae",
        "xaj_mae",
        "hbv_lite_mae",
        "best_conceptual_mae_minus_lstm",
        "all_conceptual_worse_mae",
    }
    missing_context = sorted(required_context_columns - set(per_basin_context.columns))
    if missing_context:
        raise ValueError(f"Per-basin context table is missing required columns: {missing_context}")

    nse = per_basin_nse.copy()
    contexts = per_basin_context.copy()
    nse["basin_id"] = _normalize_basin_ids(nse["basin_id"])
    contexts["basin_id"] = _normalize_basin_ids(contexts["basin_id"])
    if nse["basin_id"].duplicated().any():
        raise ValueError("Per-basin NSE table contains duplicate basin identifiers")
    base_basins = set(nse["basin_id"])
    context_basins = set(contexts["basin_id"])
    if len(base_basins) != validated["base_population_count"]:
        raise ValueError("Population overlay requires exactly 531 unique basins in the base NSE table")
    if context_basins != base_basins:
        raise ValueError("Per-basin context table basin population does not match the base NSE table")

    excluded_basin = validated["excluded_basins"][0]["basin_id"]
    if excluded_basin not in base_basins:
        raise ValueError(f"Excluded basin {excluded_basin} is absent from the base population")
    excluded_nse = nse[nse["basin_id"] == excluded_basin].copy()
    filtered_nse = nse[nse["basin_id"] != excluded_basin].copy()
    excluded_contexts = contexts[contexts["basin_id"] == excluded_basin].copy()
    filtered_contexts = contexts[contexts["basin_id"] != excluded_basin].copy()

    comparison_basins = set(filtered_nse["basin_id"])
    if len(comparison_basins) != validated["comparison_population_count"]:
        raise ValueError("Population overlay did not produce exactly 530 comparison basins")
    if set(filtered_contexts["basin_id"]) != comparison_basins:
        raise ValueError("Filtered context table does not use the shared 530-basin population")
    if set(excluded_nse["basin_id"]) != {excluded_basin}:
        raise ValueError("Excluded NSE table must contain exactly the registered anomaly")
    if set(excluded_contexts["basin_id"]) != {excluded_basin}:
        raise ValueError("Excluded context table must contain exactly the registered anomaly")

    return tuple(
        frame.sort_values([column for column in ("basin_id", "context") if column in frame.columns])
        .reset_index(drop=True)
        for frame in (filtered_nse, excluded_nse, filtered_contexts, excluded_contexts)
    )


def summarize_context_rows(per_basin_context: pd.DataFrame) -> pd.DataFrame:
    """Recompute equal-basin context summaries from filtered per-basin rows."""
    required = {
        "basin_id",
        "regime",
        "context",
        "best_conceptual_mae_minus_lstm",
        "all_conceptual_worse_mae",
    }
    missing = sorted(required - set(per_basin_context.columns))
    if missing:
        raise ValueError(f"Per-basin context table is missing required columns: {missing}")
    work = per_basin_context.copy()
    work["basin_id"] = _normalize_basin_ids(work["basin_id"])
    if work.duplicated(["basin_id", "context"]).any():
        raise ValueError("Per-basin context table contains duplicate basin-context rows")
    work["best_conceptual_mae_minus_lstm"] = pd.to_numeric(
        work["best_conceptual_mae_minus_lstm"], errors="raise"
    ).astype(float)
    if not np.isfinite(work["best_conceptual_mae_minus_lstm"].to_numpy()).all():
        raise ValueError("Per-basin context advantages must be finite")
    if not pd.api.types.is_bool_dtype(work["all_conceptual_worse_mae"]):
        normalized_bool = work["all_conceptual_worse_mae"].astype(str).str.strip().str.lower()
        if not normalized_bool.isin({"true", "false"}).all():
            raise ValueError("all_conceptual_worse_mae must contain only booleans")
        work["all_conceptual_worse_mae"] = normalized_bool.eq("true")
    rows = []

    def append_summary(regime: str, context: str, group: pd.DataFrame) -> None:
        advantage = group["best_conceptual_mae_minus_lstm"].to_numpy(dtype=float)
        shared = group["all_conceptual_worse_mae"].to_numpy(dtype=bool)
        rows.append({
            "regime": regime,
            "context": context,
            "basin_count": int(group["basin_id"].nunique()),
            "mean_best_conceptual_mae_minus_lstm": float(np.mean(advantage)),
            "median_best_conceptual_mae_minus_lstm": float(np.median(advantage)),
            "shared_failure_count": int(shared.sum()),
            "shared_failure_rate": float(shared.mean()),
        })

    for (regime, context), group in work.groupby(["regime", "context"], sort=True):
        append_summary(str(regime), str(context), group)
    for context, group in work.groupby("context", sort=True):
        append_summary("all-basins", str(context), group)
    return pd.DataFrame(rows)


def _build_summary_sensitivity_delta(
    *,
    base_nse_summary: pd.DataFrame,
    comparison_nse_summary: pd.DataFrame,
    base_context_summary: pd.DataFrame,
    comparison_context_summary: pd.DataFrame,
    base_bootstrap: dict,
    comparison_bootstrap: dict,
) -> pd.DataFrame:
    rows = []

    def append_row(
        analysis_family: str,
        group: str,
        statistic: str,
        base_value: float,
        comparison_value: float,
    ) -> None:
        base_float = float(base_value)
        comparison_float = float(comparison_value)
        rows.append({
            "analysis_family": analysis_family,
            "group": group,
            "statistic": statistic,
            "base_531_value": base_float,
            "comparison_530_value": comparison_float,
            "comparison_minus_base": comparison_float - base_float,
        })

    base_nse = base_nse_summary.set_index("model")
    comparison_nse = comparison_nse_summary.set_index("model")
    if set(base_nse.index) != set(comparison_nse.index):
        raise ValueError("Base and comparison NSE summaries do not contain the same models")
    for model in sorted(base_nse.index):
        for statistic in ("basin_count", "median_nse", "mean_nse"):
            append_row(
                "nse",
                str(model),
                statistic,
                base_nse.loc[model, statistic],
                comparison_nse.loc[model, statistic],
            )

    context_keys = ["regime", "context"]
    base_context = base_context_summary.set_index(context_keys)
    comparison_context = comparison_context_summary.set_index(context_keys)
    if set(base_context.index) != set(comparison_context.index):
        raise ValueError("Base and comparison context summaries do not contain the same groups")
    context_statistics = (
        "basin_count",
        "mean_best_conceptual_mae_minus_lstm",
        "median_best_conceptual_mae_minus_lstm",
        "shared_failure_count",
        "shared_failure_rate",
    )
    for regime, context in sorted(base_context.index):
        group = f"{regime}::{context}"
        for statistic in context_statistics:
            append_row(
                "context",
                group,
                statistic,
                base_context.loc[(regime, context), statistic],
                comparison_context.loc[(regime, context), statistic],
            )

    bootstrap_statistics = (
        "paired_basin_count",
        "median_high_mae_advantage",
        "median_low_mae_advantage",
        "median_high_minus_low_mae_advantage",
        "lower_95",
        "upper_95",
    )
    for statistic in bootstrap_statistics:
        append_row(
            "bootstrap",
            str(base_bootstrap["regime"]),
            statistic,
            base_bootstrap[statistic],
            comparison_bootstrap[statistic],
        )
    return pd.DataFrame(rows)


def compute_population_overlay_tables(
    *,
    per_basin_nse: pd.DataFrame,
    per_basin_context: pd.DataFrame,
    overlay: dict,
) -> dict[str, pd.DataFrame | dict]:
    """Recompute the 531 control, 530 comparison, anomaly, and sensitivity deltas."""
    filtered_nse, excluded_nse, filtered_contexts, excluded_contexts = apply_population_overlay(
        per_basin_nse=per_basin_nse,
        per_basin_context=per_basin_context,
        overlay=overlay,
    )
    base_nse_summary = summarize_nse(
        per_basin_nse.copy(), expected_basin_count=EXPECTED_BASE_POPULATION_COUNT
    )
    comparison_nse_summary = summarize_nse(
        filtered_nse, expected_basin_count=EXPECTED_COMPARISON_POPULATION_COUNT
    )
    base_context_summary = summarize_context_rows(per_basin_context)
    comparison_context_summary = summarize_context_rows(filtered_contexts)
    base_bootstrap = paired_high_minus_low_bootstrap(per_basin_context, regime="snow-dominated")
    comparison_bootstrap = paired_high_minus_low_bootstrap(filtered_contexts, regime="snow-dominated")
    sensitivity_delta = _build_summary_sensitivity_delta(
        base_nse_summary=base_nse_summary,
        comparison_nse_summary=comparison_nse_summary,
        base_context_summary=base_context_summary,
        comparison_context_summary=comparison_context_summary,
        base_bootstrap=base_bootstrap,
        comparison_bootstrap=comparison_bootstrap,
    )
    return {
        "base_531_nse_summary": base_nse_summary,
        "base_531_context_summary": base_context_summary,
        "base_531_snow_high_minus_low_bootstrap": base_bootstrap,
        "comparison_per_basin_nse": filtered_nse,
        "excluded_anomaly_per_basin_nse": excluded_nse,
        "comparison_nse_summary": comparison_nse_summary,
        "comparison_per_basin_context_mae": filtered_contexts,
        "excluded_anomaly_per_basin_context_mae": excluded_contexts,
        "comparison_context_summary": comparison_context_summary,
        "comparison_snow_high_minus_low_bootstrap": comparison_bootstrap,
        "summary_sensitivity_delta": sensitivity_delta,
    }


def _prefixed_source(record: dict, *, prefix: str) -> dict:
    return {
        "role": f"{prefix}{record['role']}",
        "path": str(Path(record["path"]).resolve()),
        "sha256": str(record["sha256"]).lower(),
    }


def _load_base_analysis_inputs(
    base_analysis_dir: Path,
) -> tuple[pd.DataFrame, pd.DataFrame, list[dict], str, Path]:
    """Validate the immutable 531-basin analysis bundle and load only bottom-level rows."""
    base_analysis_dir = Path(base_analysis_dir).resolve()
    manifest_path = base_analysis_dir / "analysis_manifest.json"
    manifest, manifest_sha256 = _load_base_json_snapshot(
        manifest_path, label="Base 531-basin analysis manifest"
    )
    manifest = _validate_published_analysis_bundle(base_analysis_dir, manifest)
    if manifest.get("status") != "completed" or manifest.get("experiment_id") != EXPECTED_EXPERIMENT_ID:
        raise ValueError("Base analysis must be the completed registered 531-basin experiment")
    required_outputs = {"per_basin_nse", "per_basin_context_mae"}
    missing_outputs = sorted(required_outputs - set(manifest.get("outputs", {})))
    if missing_outputs:
        raise ValueError(f"Base analysis is missing required bottom-level outputs: {missing_outputs}")
    nse_record = manifest["outputs"]["per_basin_nse"]
    context_record = manifest["outputs"]["per_basin_context_mae"]
    nse_path = Path(nse_record["path"]).resolve()
    context_path = Path(context_record["path"]).resolve()
    per_basin_nse, _ = _load_base_csv_snapshot(
        nse_path,
        label="Base 531-basin per-basin NSE",
        expected_sha256=nse_record["sha256"],
        dtype={"basin_id": str},
    )
    per_basin_context, _ = _load_base_csv_snapshot(
        context_path,
        label="Base 531-basin per-basin context metrics",
        expected_sha256=context_record["sha256"],
        dtype={"basin_id": str},
    )
    protocol_sources = [
        record for record in manifest.get("sources", []) if record.get("role") == "common_loss_protocol"
    ]
    if len(protocol_sources) != 1:
        raise ValueError("Base analysis must bind exactly one common-loss protocol source")
    protocol_path = Path(protocol_sources[0]["path"]).resolve()
    if _sha256(protocol_path) != str(protocol_sources[0]["sha256"]).lower():
        raise ValueError("Base analysis common-loss protocol source hash changed")

    sources = [
        _source_record("base_analysis_manifest", manifest_path, expected_sha256=manifest_sha256),
        _source_record("base_531_per_basin_nse", nse_path, expected_sha256=nse_record["sha256"]),
        _source_record(
            "base_531_per_basin_context_mae",
            context_path,
            expected_sha256=context_record["sha256"],
        ),
        _source_record(
            "base_531_per_basin_nse_source_sidecar",
            Path(nse_record["source_sidecar_path"]),
            expected_sha256=nse_record["source_sidecar_sha256"],
        ),
        _source_record(
            "base_531_per_basin_context_source_sidecar",
            Path(context_record["source_sidecar_path"]),
            expected_sha256=context_record["source_sidecar_sha256"],
        ),
        *(_prefixed_source(record, prefix="base_analysis_source::") for record in manifest["sources"]),
    ]
    _validate_sources_unchanged(sources)
    return per_basin_nse, per_basin_context, sources, manifest_sha256, protocol_path


def _make_read_only(path: Path) -> None:
    path = Path(path)
    path.chmod(path.stat().st_mode & ~stat.S_IWRITE)


def _remove_output_tree(path: Path) -> None:
    path = Path(path)
    if not path.exists():
        return
    for child in path.rglob("*"):
        if child.is_file():
            child.chmod(child.stat().st_mode | stat.S_IWRITE)
    shutil.rmtree(path)


def _validate_published_overlay_bundle(output_dir: Path, expected_manifest: dict) -> dict:
    output_dir = Path(output_dir).resolve()
    manifest_path = output_dir / _MANIFEST_FILENAME
    manifest, manifest_sha256 = _read_json_snapshot(
        manifest_path, label="Published population-overlay analysis manifest"
    )
    if manifest != expected_manifest:
        raise RuntimeError("Published population-overlay manifest content changed")
    if manifest.get("status") != "completed":
        raise RuntimeError("Published population-overlay analysis is not completed")
    if manifest.get("base_population_count") != 531 or manifest.get("comparison_population_count") != 530:
        raise RuntimeError("Published population-overlay counts are not 531-to-530")
    if manifest.get("excluded_basin_ids") != [EXPECTED_EXCLUDED_BASIN]:
        raise RuntimeError("Published population-overlay anomaly record changed")
    _validate_sources_unchanged(manifest["sources"])
    expected_paths = {manifest_path}
    for name, filename in _OUTPUT_FILENAMES.items():
        output_path = output_dir / filename
        sidecar_path = output_path.with_suffix(output_path.suffix + ".sources.json")
        expected_paths.update({output_path, sidecar_path})
        record = manifest["outputs"].get(name)
        if not isinstance(record, dict):
            raise RuntimeError(f"Published population-overlay output is unregistered: {name}")
        if record.get("path") != str(output_path) or record.get("sha256") != _sha256(output_path):
            raise RuntimeError(f"Published population-overlay output hash or path mismatch: {output_path}")
        if record.get("source_sidecar_path") != str(sidecar_path):
            raise RuntimeError(f"Published population-overlay sidecar path mismatch: {sidecar_path}")
        if record.get("source_sidecar_sha256") != _sha256(sidecar_path):
            raise RuntimeError(f"Published population-overlay sidecar hash mismatch: {sidecar_path}")
    actual_paths = {path for path in output_dir.iterdir() if path.is_file()}
    if actual_paths != expected_paths:
        raise RuntimeError("Published population-overlay directory contains unregistered files")
    for path in expected_paths:
        if path.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH):
            raise RuntimeError(f"Published population-overlay artifact is not read-only: {path}")
    if _sha256(manifest_path) != manifest_sha256:
        raise RuntimeError("Published population-overlay manifest changed during validation")
    return manifest


def _write_population_overlay_bundle(
    *,
    outputs: dict[str, pd.DataFrame | dict],
    sources: list[dict],
    overlay: dict,
    base_manifest_sha256: str,
    staging_dir: Path,
    published_dir: Path,
) -> dict:
    staging_dir = Path(staging_dir).resolve()
    published_dir = Path(published_dir).resolve()
    output_records = {}
    written_paths = []
    for name, filename in _OUTPUT_FILENAMES.items():
        staging_path = staging_dir / filename
        published_path = published_dir / filename
        value = outputs[name]
        if isinstance(value, pd.DataFrame):
            sidecar = write_csv_with_sources(
                value,
                staging_path,
                sources,
                published_output_path=published_path,
            )
        else:
            sidecar = _write_json_with_sources(
                value,
                staging_path,
                sources,
                published_output_path=published_path,
            )
        staging_sidecar_path = staging_path.with_suffix(staging_path.suffix + ".sources.json")
        published_sidecar_path = published_path.with_suffix(published_path.suffix + ".sources.json")
        written_paths.extend([staging_path, staging_sidecar_path])
        output_records[name] = {
            "path": str(published_path),
            "sha256": _sha256(staging_path),
            "source_sidecar_path": str(published_sidecar_path),
            "source_sidecar_sha256": _sha256(staging_sidecar_path),
            "source_sidecar": sidecar,
        }
    manifest = {
        "schema_version": 1,
        "status": "completed",
        "experiment_id": EXPECTED_EXPERIMENT_ID,
        "overlay_id": overlay["overlay_id"],
        "classification": EXPECTED_CLASSIFICATION,
        "interpretation_boundary": (
            "Post-hoc input-quality sensitivity analysis; it does not replace or relabel the frozen "
            "531-basin primary protocol or its outputs."
        ),
        "loss_protocol": LOSS_PROTOCOL,
        "base_population_count": 531,
        "comparison_population_count": 530,
        "excluded_basin_ids": [EXPECTED_EXCLUDED_BASIN],
        "base_analysis_manifest_sha256": base_manifest_sha256,
        "repository_state": _current_git_description(),
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "sources": sources,
        "outputs": output_records,
    }
    _validate_sources_unchanged(sources)
    manifest_path = staging_dir / _MANIFEST_FILENAME
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    _validate_sources_unchanged(sources)
    for path in [*written_paths, manifest_path]:
        _make_read_only(path)
    return manifest


def run_population_overlay_analysis(
    *,
    base_analysis_dir: Path,
    overlay_path: Path,
    output_dir: Path,
    repository_root: Path = _REPOSITORY_ROOT,
) -> dict:
    """Atomically publish the read-only post-hoc 531-to-530 sensitivity bundle."""
    output_dir = Path(output_dir).resolve()
    if output_dir.exists():
        raise FileExistsError(f"Population-overlay analysis output already exists: {output_dir}")
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    per_basin_nse, per_basin_context, base_sources, base_manifest_sha256, protocol_path = (
        _load_base_analysis_inputs(base_analysis_dir)
    )
    overlay, overlay_sources = load_population_overlay(
        overlay_path,
        protocol_path=protocol_path,
        repository_root=repository_root,
    )
    sources = [*base_sources, *overlay_sources]
    source_paths = [Path(record["path"]) for record in sources]
    staging_dir = Path(
        tempfile.mkdtemp(prefix=f".{output_dir.name}.staging-", dir=output_dir.parent)
    ).resolve()
    try:
        with _ArtifactStabilityGuard(source_paths, watch_parent_directories=False):
            outputs = compute_population_overlay_tables(
                per_basin_nse=per_basin_nse,
                per_basin_context=per_basin_context,
                overlay=overlay,
            )
            manifest = _write_population_overlay_bundle(
                outputs=outputs,
                sources=sources,
                overlay=overlay,
                base_manifest_sha256=base_manifest_sha256,
                staging_dir=staging_dir,
                published_dir=output_dir,
            )
            staging_dir.replace(output_dir)
            return _validate_published_overlay_bundle(output_dir, manifest)
    except BaseException:
        _remove_output_tree(staging_dir)
        _remove_output_tree(output_dir)
        raise


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--base-analysis-dir",
        type=Path,
        default=_DEFAULT_RESULT_ROOT / "analysis",
    )
    parser.add_argument("--overlay", type=Path, default=_DEFAULT_OVERLAY_PATH)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=_DEFAULT_RESULT_ROOT / "analysis_population_overlay_v1",
    )
    parser.add_argument(
        "--protocol-manifest",
        type=Path,
        default=_DEFAULT_RESULT_ROOT / "protocol" / "common_loss_protocol.json",
        help="Used only by --validate-overlay-only before the base analysis exists.",
    )
    parser.add_argument("--validate-overlay-only", action="store_true", default=False)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    if args.validate_overlay_only:
        overlay, sources = load_population_overlay(
            args.overlay,
            protocol_path=args.protocol_manifest,
            repository_root=_REPOSITORY_ROOT,
        )
        print(json.dumps({
            "status": "passed",
            "mode": "validate_overlay_only",
            "overlay_id": overlay["overlay_id"],
            "base_population_count": overlay["base_population_count"],
            "comparison_population_count": overlay["comparison_population_count"],
            "excluded_basin_ids": [item["basin_id"] for item in overlay["excluded_basins"]],
            "sources": sources,
        }, indent=2, sort_keys=True))
        return 0
    manifest = run_population_overlay_analysis(
        base_analysis_dir=args.base_analysis_dir,
        overlay_path=args.overlay,
        output_dir=args.output_dir,
        repository_root=_REPOSITORY_ROOT,
    )
    print(json.dumps({
        "status": manifest["status"],
        "classification": manifest["classification"],
        "outputs": manifest["outputs"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
