"""Resource sampling and safe-stop logic for the identical-loss replication."""

from __future__ import annotations

import csv
import ctypes
import os
import re
import shutil
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterator

import psutil


MONITOR_INTERVAL_SECONDS = 30.0
INITIAL_MONITOR_INTERVAL_SECONDS = 5.0
INITIAL_MONITOR_DURATION_SECONDS = 600.0
STALL_LIMIT_SECONDS = 600.0
MINIMUM_SYSTEM_MEMORY_LAUNCH_FLOOR_GIB = 6.8443069458007812
SYSTEM_MEMORY_LAUNCH_RESERVE_GIB = 4.0
RUNTIME_MINIMUM_SYSTEM_MEMORY_GIB = 3.0

RESOURCE_FIELDS = (
    "timestamp_utc",
    "phase",
    "seed",
    "process_id",
    "monitor_process_rss_gib",
    "monitor_process_private_commit_gib",
    "runner_process_rss_gib",
    "runner_process_private_commit_gib",
    "runner_descendant_rss_gib",
    "runner_descendant_private_commit_gib",
    "runner_process_tree_rss_gib",
    "runner_process_tree_private_commit_gib",
    "runner_descendant_count",
    "runner_process_tree_count",
    "free_system_memory_gib",
    "total_system_memory_gib",
    "available_commit_memory_gib",
    "total_commit_memory_gib",
    "free_accelerator_memory_gib",
    "total_accelerator_memory_gib",
    "used_accelerator_memory_gib",
    "processor_percent",
    "disk_path",
    "free_disk_gib",
    "log_size_bytes",
    "seconds_since_progress",
    "stop_reason",
)


def calculate_start_gates(
    incremental_system_memory_gib: float,
    peak_accelerator_memory_gib: float,
    estimated_output_growth_gib: float,
) -> dict[str, float]:
    """Calculate the three frozen launch gates from the approved formulas."""
    return {
        "required_free_system_memory_gib": max(
            float(incremental_system_memory_gib) + SYSTEM_MEMORY_LAUNCH_RESERVE_GIB,
            MINIMUM_SYSTEM_MEMORY_LAUNCH_FLOOR_GIB,
        ),
        "required_free_accelerator_memory_gib": 1.25 * float(peak_accelerator_memory_gib),
        "required_free_disk_gib": 2.0 * float(estimated_output_growth_gib) + 20.0,
    }


def derive_runtime_thresholds(
    post_allocation_free_system_memory_gib: float,
    post_allocation_free_accelerator_memory_gib: float,
    estimated_output_growth_gib: float,
) -> dict[str, float]:
    """Freeze conservative stop reserves after the measured batch is allocated."""
    return {
        "minimum_free_system_memory_gib": RUNTIME_MINIMUM_SYSTEM_MEMORY_GIB,
        "minimum_free_accelerator_memory_gib": max(
            0.5, 0.5 * float(post_allocation_free_accelerator_memory_gib)
        ),
        "minimum_free_disk_gib": float(estimated_output_growth_gib) + 10.0,
    }


def contains_nonfinite_training_signal(text: str) -> bool:
    """Return whether a log explicitly reports a non-finite loss or gradient."""
    pattern = re.compile(
        r"\b(?:loss|gradient|gradients)\b[^\r\n]{0,80}\b(?:nan|inf|infinite|non[- ]finite)\b",
        flags=re.IGNORECASE,
    )
    reverse_pattern = re.compile(
        r"\b(?:nan|inf|infinite|non[- ]finite)\b[^\r\n]{0,80}\b(?:loss|gradient|gradients)\b",
        flags=re.IGNORECASE,
    )
    return bool(pattern.search(text) or reverse_pattern.search(text))


def evaluate_stop_reason(
    snapshot: dict,
    thresholds: dict,
    seconds_since_progress: float,
    nonfinite_training_value: bool,
    evaluation_leakage: bool,
) -> str | None:
    """Evaluate every approved safe-stop condition in deterministic priority order."""
    if nonfinite_training_value:
        return "nonfinite_training_value"
    if evaluation_leakage:
        return "evaluation_leakage"
    if float(seconds_since_progress) >= STALL_LIMIT_SECONDS:
        return "log_stall"
    if float(snapshot["free_system_memory_gib"]) < float(thresholds["minimum_free_system_memory_gib"]):
        return "system_memory"
    minimum_commit = thresholds.get("minimum_available_commit_memory_gib")
    available_commit = snapshot.get("available_commit_memory_gib")
    if minimum_commit is not None and available_commit is None:
        return "commit_memory_telemetry_unavailable"
    if (minimum_commit is not None and available_commit is not None
            and float(available_commit) < float(minimum_commit)):
        return "commit_memory"
    free_accelerator = snapshot.get("free_accelerator_memory_gib")
    minimum_accelerator = thresholds.get("minimum_free_accelerator_memory_gib")
    if minimum_accelerator is not None and free_accelerator is None:
        return "accelerator_telemetry_unavailable"
    if (minimum_accelerator is not None and free_accelerator is not None
            and float(free_accelerator) < float(minimum_accelerator)):
        return "accelerator_memory"
    if float(snapshot["free_disk_gib"]) < float(thresholds["minimum_free_disk_gib"]):
        return "disk"
    return None


def _accelerator_memory_gib() -> tuple[float | None, float | None, float | None]:
    try:
        completed = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=memory.free,memory.total,memory.used",
                "--format=csv,noheader,nounits",
                "--id=0",
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=10,
        )
        fields = [float(value.strip()) / 1024.0 for value in completed.stdout.splitlines()[0].split(",")]
        return fields[0], fields[1], fields[2]
    except (FileNotFoundError, IndexError, ValueError, subprocess.SubprocessError):
        return None, None, None


def _windows_commit_memory_gib() -> tuple[float | None, float | None]:
    """Return Windows commit-limit headroom and total commit limit in GiB."""
    if os.name != "nt":
        return None, None

    class MemoryStatusEx(ctypes.Structure):
        _fields_ = [
            ("dwLength", ctypes.c_ulong),
            ("dwMemoryLoad", ctypes.c_ulong),
            ("ullTotalPhys", ctypes.c_ulonglong),
            ("ullAvailPhys", ctypes.c_ulonglong),
            ("ullTotalPageFile", ctypes.c_ulonglong),
            ("ullAvailPageFile", ctypes.c_ulonglong),
            ("ullTotalVirtual", ctypes.c_ulonglong),
            ("ullAvailVirtual", ctypes.c_ulonglong),
            ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
        ]

    status = MemoryStatusEx()
    status.dwLength = ctypes.sizeof(status)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
        raise ctypes.WinError()
    gib = 1024**3
    return status.ullAvailPageFile / gib, status.ullTotalPageFile / gib


def _collect_process_memory_snapshot(process_id: int | None) -> dict:
    """Measure the monitor, launched runner, and sampled runner descendants separately."""
    gib = 1024**3
    monitor_rss_gib = None
    monitor_private_commit_gib = None
    try:
        monitor_memory = psutil.Process(os.getpid()).memory_info()
        monitor_rss_gib = monitor_memory.rss / gib
        monitor_private = getattr(monitor_memory, "private", None)
        if monitor_private is not None:
            monitor_private_commit_gib = int(monitor_private) / gib
    except psutil.Error:
        pass

    runner_rss_gib = None
    runner_private_commit_gib = None
    descendant_rss_gib = None
    descendant_private_commit_gib = None
    descendant_count = None
    process_tree_rss_gib = None
    process_tree_private_commit_gib = None
    process_tree_count = None
    if process_id is not None:
        try:
            runner = psutil.Process(int(process_id))
            runner_memory = runner.memory_info()
            runner_rss_gib = runner_memory.rss / gib
            runner_private = getattr(runner_memory, "private", None)
            if runner_private is not None:
                runner_private_commit_gib = int(runner_private) / gib
            descendants = runner.children(recursive=True)
            sampled_descendant_rss_bytes = 0
            sampled_descendant_private_bytes = 0
            descendant_private_complete = True
            sampled_descendant_count = 0
            for descendant in descendants:
                try:
                    descendant_memory = descendant.memory_info()
                    sampled_descendant_rss_bytes += int(descendant_memory.rss)
                    descendant_private = getattr(descendant_memory, "private", None)
                    if descendant_private is None:
                        descendant_private_complete = False
                    else:
                        sampled_descendant_private_bytes += int(descendant_private)
                    sampled_descendant_count += 1
                except psutil.Error:
                    continue
            descendant_rss_gib = sampled_descendant_rss_bytes / gib
            if descendant_private_complete:
                descendant_private_commit_gib = sampled_descendant_private_bytes / gib
            descendant_count = sampled_descendant_count
            process_tree_rss_gib = runner_rss_gib + descendant_rss_gib
            if runner_private_commit_gib is not None and descendant_private_commit_gib is not None:
                process_tree_private_commit_gib = (
                    runner_private_commit_gib + descendant_private_commit_gib
                )
            process_tree_count = 1 + sampled_descendant_count
        except psutil.Error:
            pass
    return {
        "monitor_process_rss_gib": monitor_rss_gib,
        "monitor_process_private_commit_gib": monitor_private_commit_gib,
        "runner_process_rss_gib": runner_rss_gib,
        "runner_process_private_commit_gib": runner_private_commit_gib,
        "runner_descendant_rss_gib": descendant_rss_gib,
        "runner_descendant_private_commit_gib": descendant_private_commit_gib,
        "runner_process_tree_rss_gib": process_tree_rss_gib,
        "runner_process_tree_private_commit_gib": process_tree_private_commit_gib,
        "runner_descendant_count": descendant_count,
        "runner_process_tree_count": process_tree_count,
    }


def collect_resource_snapshot(
    *,
    workspace: Path,
    phase: str,
    seed: int | None,
    process_id: int | None,
    log_path: Path,
    disk_path: Path | None = None,
) -> dict:
    """Collect one system-wide resource sample without mutating the running experiment."""
    memory = psutil.virtual_memory()
    available_commit, total_commit = _windows_commit_memory_gib()
    disk_path = Path(workspace if disk_path is None else disk_path).resolve()
    disk = shutil.disk_usage(disk_path)
    free_accelerator, total_accelerator, used_accelerator = _accelerator_memory_gib()
    snapshot = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "phase": phase,
        "seed": seed,
        "process_id": process_id,
        "free_system_memory_gib": memory.available / 1024**3,
        "total_system_memory_gib": memory.total / 1024**3,
        "available_commit_memory_gib": available_commit,
        "total_commit_memory_gib": total_commit,
        "free_accelerator_memory_gib": free_accelerator,
        "total_accelerator_memory_gib": total_accelerator,
        "used_accelerator_memory_gib": used_accelerator,
        "processor_percent": psutil.cpu_percent(interval=None),
        "disk_path": str(disk_path),
        "free_disk_gib": disk.free / 1024**3,
        "log_size_bytes": log_path.stat().st_size if log_path.exists() else 0,
    }
    snapshot.update(_collect_process_memory_snapshot(process_id))
    return snapshot


def append_resource_row(path: Path, row: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a+", newline="", encoding="utf-8") as handle:
        handle.seek(0)
        first_line = handle.readline()
        if first_line:
            existing_header = tuple(next(csv.reader([first_line])))
            if existing_header != RESOURCE_FIELDS:
                raise ValueError(
                    "Existing resource log header does not match the current schema"
                )
        handle.seek(0, os.SEEK_END)
        writer = csv.DictWriter(handle, fieldnames=RESOURCE_FIELDS, extrasaction="ignore")
        if not first_line:
            writer.writeheader()
        writer.writerow({field: row.get(field) for field in RESOURCE_FIELDS})


def _next_monotonic(values: Iterator[float] | None) -> float:
    return float(next(values)) if values is not None else time.monotonic()


def monitor_process(
    *,
    process,
    phase: str,
    seed: int | None,
    log_path: Path,
    resource_log_path: Path,
    thresholds: dict,
    workspace: Path | None = None,
    collect_snapshot: Callable[..., dict] = collect_resource_snapshot,
    sleep: Callable[[float], None] = time.sleep,
    monotonic_values: Iterator[float] | None = None,
    evaluation_leakage_detector: Callable[[], bool] = lambda: False,
) -> str | None:
    """Monitor a child process and terminate it on the first frozen stop condition."""
    workspace = workspace or Path.cwd()
    monitor_started = _next_monotonic(monotonic_values)
    last_progress = monitor_started
    last_log_size = log_path.stat().st_size if log_path.exists() else 0

    while process.poll() is None:
        now = _next_monotonic(monotonic_values)
        snapshot = collect_snapshot(
            workspace=workspace,
            phase=phase,
            seed=seed,
            process_id=getattr(process, "pid", None),
            log_path=log_path,
        )
        log_size = int(snapshot.get("log_size_bytes", log_path.stat().st_size if log_path.exists() else 0))
        if log_size > last_log_size:
            last_progress = now
            last_log_size = log_size
        recent_log = ""
        if log_path.exists():
            with log_path.open("r", encoding="utf-8", errors="replace") as handle:
                handle.seek(max(0, log_size - 65_536))
                recent_log = handle.read()
        seconds_since_progress = now - last_progress
        reason = evaluate_stop_reason(
            snapshot=snapshot,
            thresholds=thresholds,
            seconds_since_progress=seconds_since_progress,
            nonfinite_training_value=contains_nonfinite_training_signal(recent_log),
            evaluation_leakage=bool(evaluation_leakage_detector()),
        )
        snapshot.update(
            {
                "timestamp_utc": snapshot.get("timestamp_utc", datetime.now(timezone.utc).isoformat()),
                "phase": phase,
                "seed": seed,
                "process_id": getattr(process, "pid", None),
                "log_size_bytes": log_size,
                "seconds_since_progress": seconds_since_progress,
                "stop_reason": reason or "",
            }
        )
        append_resource_row(resource_log_path, snapshot)
        if reason is not None:
            process.terminate()
            return reason
        elapsed_since_monitor_start = max(0.0, now - monitor_started)
        interval = (
            INITIAL_MONITOR_INTERVAL_SECONDS
            if elapsed_since_monitor_start < INITIAL_MONITOR_DURATION_SECONDS
            else MONITOR_INTERVAL_SECONDS
        )
        sleep(interval)
    if bool(evaluation_leakage_detector()):
        return "evaluation_leakage"
    if log_path.exists():
        recent_log = log_path.read_text(encoding="utf-8", errors="replace")[-65_536:]
        if contains_nonfinite_training_signal(recent_log):
            return "nonfinite_training_value"
    return None
