"""Run the registered D10 post-hoc hydrological cause diagnostics."""

from __future__ import annotations

import argparse
import gc
import pickle
import subprocess
import time
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

from src.lstm_fair_531.scripts.run_context_scale_threshold_robustness import (
    REPO_ROOT,
    _available_gib,
    _sha256,
)
from src.lstm_fair_531.scripts.analyze_identical_basin_nse_replication import (
    _prediction_variables,
    _xarray_series,
)
from src.lstm_fair_531.scripts.posthoc_cause_diagnostics import (
    daily_amplitude_geometry,
    event_peak_concentration,
    oracle_moment_match,
    pairwise_event_shape_summary,
    prespecified_cause_associations,
    summarize_amplitude_geometry_rows,
    summarize_event_shape,
    within_basin_forcing_association,
)
from src.lstm_fair_531.scripts.run_context_scale_threshold_robustness import (
    DEFAULT_CONCEPTUAL_MANIFEST,
    DEFAULT_REGIMES,
    DEFAULT_RUN_LEDGER,
    _current_rss_gib,
    _load_neural_ensemble_low_memory,
    _load_regimes,
    _normalize_basin_id,
    _source,
)
from src.lstm_fair_531.scripts.run_hydrological_process_diagnostics import (
    _verify_sources_unchanged,
)


EXPERIMENT_ID = "D10_posthoc_cause_diagnostics_20260726"
FIXED_MODELS = ("LSTM", "GR4J", "Xinanjiang", "HBV-lite")
FIXED_SEEDS = (100, 200, 300, 400, 500, 600, 700, 800)
FIXED_FORCING_PRODUCTS = ("maurer", "daymet", "nldas")
DEFAULT_CONFIG = REPO_ROOT / "src/lstm_fair_531/configs/posthoc_cause_diagnostics_20260726.json"
DEFAULT_OUTPUT_DIR = REPO_ROOT / "results/18_lstm_fair_531" / EXPERIMENT_ID
DEFAULT_D09_ROOT = REPO_ROOT / (
    "results/18_lstm_fair_531/"
    "D09_hydrological_process_diagnostics_20260726_attempt2"
)
EXPECTED_OUTPUTS = (
    "amplitude_geometry_summary.csv",
    "event_shape_summary.csv",
    "event_shape_pairwise_summary.csv",
    "neural_ensemble_shape_summary.csv",
    "forcing_disagreement_summary.csv",
    "forcing_disagreement_quartiles.csv",
    "hydroclimate_cause_associations.csv",
    "D10_self_checks.json",
    "forcing_input_inventory.csv",
    "D10_manifest.json",
)
DEFAULT_REGISTERED_SEED_CONFIG = REPO_ROOT / (
    "results/18_lstm_fair_531/R02_identical_basin_nse_531/"
    "registered_outputs/seed_100/config.yml"
)
DEFAULT_ATTRIBUTES = DEFAULT_REGIMES
DEFAULT_D09_MANIFEST = DEFAULT_D09_ROOT / "D09_manifest.json"
DEFAULT_D09_Q90 = DEFAULT_D09_ROOT / "event_model_diagnostics_q90.csv"
DEFAULT_D09_Q95 = DEFAULT_D09_ROOT / "event_model_diagnostics_q95.csv"
MODEL_NAME_MAP = {"GR4J": "GR4J", "XAJ": "Xinanjiang", "HBV-lite": "HBV-lite"}
ATTRIBUTE_COLUMN_MAP = {
    "p_seasonality": "clim_p_seasonality",
    "aridity": "clim_aridity",
    "frac_snow": "clim_frac_snow",
    "p_mean": "clim_p_mean",
}
FORCING_GAP_COLUMNS = {
    "consensus": "maurer_vs_consensus_log_gap_{window}d",
    "daymet": "maurer_vs_daymet_log_gap_{window}d",
    "nldas": "maurer_vs_nldas_log_gap_{window}d",
}


def _load_json(path: Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _validate_config(path: Path) -> dict:
    config = _load_json(path)
    if config.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("D10 configuration experiment identifier mismatch")
    if config.get("analysis_status") != "posthoc_exploratory":
        raise ValueError("D10 must remain explicitly post-hoc exploratory")
    if tuple(config.get("models", [])) != FIXED_MODELS:
        raise ValueError(f"D10 models must be exactly {FIXED_MODELS}")
    if tuple(int(seed) for seed in config.get("neural_seeds", [])) != FIXED_SEEDS:
        raise ValueError(f"D10 neural seeds must be exactly {FIXED_SEEDS}")
    if tuple(config.get("forcing_products", [])) != FIXED_FORCING_PRODUCTS:
        raise ValueError(f"D10 forcing products must be exactly {FIXED_FORCING_PRODUCTS}")
    if int(config.get("basin_count", 0)) != 531:
        raise ValueError("D10 must retain all 531 basins")
    if (config.get("evaluation_start"), config.get("evaluation_end")) != (
            "1989-10-01", "1999-09-30"):
        raise ValueError("D10 evaluation dates drifted")
    if (
            float(config.get("primary_event_threshold_quantile", -1.0)),
            float(config.get("sensitivity_event_threshold_quantile", -1.0)),
    ) != (0.9, 0.95):
        raise ValueError("D10 event threshold roles drifted")
    bootstrap = config.get("bootstrap", {})
    if (
            bootstrap.get("unit"),
            int(bootstrap.get("resamples", 0)),
            int(bootstrap.get("seed", -1)),
            float(bootstrap.get("confidence_level", 0.0)),
    ) != ("whole_basin", 10_000, 20260726, 0.95):
        raise ValueError("D10 bootstrap contract drifted")
    if float(config.get("minimum_available_memory_gib", 0.0)) != 4.0:
        raise ValueError("D10 memory floor must be exactly 4.0 GiB")
    required_constraints = {
        "all_531_basins",
        "retain_and_report_04213075",
        "no_evaluation_period_selection",
        "no_model_training",
        "no_model_recalibration",
        "do_not_modify_registered_inputs",
        "do_not_retroactively_activate_D09_failed_branches",
        "q90_primary_q95_sensitivity_only",
    }
    if set(config.get("frozen_constraints", [])) != required_constraints:
        raise ValueError("D10 frozen constraints drifted")
    return config


def _data_root_from_registered_config(path: Path) -> Path:
    config = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(config, dict) or "data_dir" not in config:
        raise ValueError("registered neural configuration does not contain data_dir")
    root = Path(config["data_dir"]).expanduser().resolve()
    if root.name.lower() != "camels_us":
        raise ValueError(f"registered data root is not CAMELS-US: {root}")
    return root


def _index_forcing_files(
    forcing_root: Path,
    *,
    expected_basin_ids: set[str],
) -> dict[str, dict[str, Path]]:
    expected = {str(basin_id).zfill(8) for basin_id in expected_basin_ids}
    inventory: dict[str, dict[str, Path]] = {}
    for product in FIXED_FORCING_PRODUCTS:
        product_root = Path(forcing_root) / product
        if not product_root.is_dir():
            raise FileNotFoundError(f"forcing product directory is missing: {product_root}")
        indexed: dict[str, Path] = {}
        for path in sorted(product_root.rglob("*.txt")):
            basin_id = path.name[:8]
            if len(basin_id) != 8 or not basin_id.isdigit() or basin_id not in expected:
                continue
            if basin_id in indexed:
                raise ValueError(f"duplicate {product} forcing file for basin {basin_id}")
            indexed[basin_id] = path.resolve()
        missing = sorted(expected.difference(indexed))
        extra = sorted(set(indexed).difference(expected))
        if missing or extra:
            raise ValueError(
                f"{product} forcing inventory mismatch: "
                f"missing={missing[:5]}, extra={extra[:5]}")
        inventory[product] = indexed
    return inventory


def _validate_upstream_d09_manifest(manifest: dict) -> None:
    if manifest.get("experiment_id") != "D09_hydrological_process_diagnostics_20260726":
        raise ValueError("D10 requires the registered D09 manifest")
    if manifest.get("conditional_branches_executed") != []:
        raise ValueError("D09 conditional branches must remain unexecuted")
    gates = manifest.get("diagnostic_gates", {})
    for gate in ("run_shape_stage", "run_forcing_proxy_stage"):
        if gates.get(gate, {}).get("supported") is not False:
            raise ValueError(f"D09 failed gate must remain recorded: {gate}")


def _relative_output_path(path: Path, repo_root: Path) -> str:
    resolved = Path(path).resolve()
    try:
        return resolved.relative_to(Path(repo_root).resolve()).as_posix()
    except ValueError as error:
        raise ValueError(f"D10 output lies outside the declared root: {resolved}") from error


def _build_manifest(
    *,
    config: dict,
    output_paths: list[Path],
    sources: list[dict],
    undefined_cases: dict,
    started_at_utc: str,
    runtime_seconds: float,
    available_before: float,
    available_after: float,
    peak_rss: float,
    repo_root: Path = REPO_ROOT,
    analysis_code_paths: list[Path] | None = None,
    exact_command: str = (
        "python -X utf8 -m src.lstm_fair_531.scripts.run_posthoc_cause_diagnostics"
    ),
) -> dict:
    code_paths = analysis_code_paths if analysis_code_paths is not None else [
        Path(__file__),
        REPO_ROOT / "src/lstm_fair_531/scripts/posthoc_cause_diagnostics.py",
    ]
    return {
        "schema_version": "1.0",
        "experiment_id": EXPERIMENT_ID,
        "status": "completed",
        "analysis_status": "posthoc_exploratory",
        "purpose": config["purpose"],
        "models": config["models"],
        "neural_seeds": config["neural_seeds"],
        "forcing_products": config["forcing_products"],
        "basin_count": 531,
        "contains_basin_04213075": True,
        "evaluation_start": config["evaluation_start"],
        "evaluation_end": config["evaluation_end"],
        "primary_event_threshold_quantile": 0.9,
        "sensitivity_event_threshold_quantile": 0.95,
        "bootstrap": config["bootstrap"],
        "inference_boundary": (
            "Evaluation-period post-hoc diagnosis; no causal attribution, "
            "model selection, deployable correction, training, or recalibration."
        ),
        "upstream_d09_conditional_branches_executed": [],
        "undefined_cases": undefined_cases,
        "exact_command": exact_command,
        "working_directory": ".",
        "inputs": sources,
        "analysis_code": [
            {
                "path": _relative_output_path(path, REPO_ROOT),
                "sha256": _sha256(path),
            }
            for path in code_paths
        ],
        "outputs": [
            {
                "path": _relative_output_path(path, repo_root),
                "bytes": Path(path).stat().st_size,
                "sha256": _sha256(path),
            }
            for path in sorted(output_paths)
        ],
        "started_at_utc": started_at_utc,
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "runtime_seconds": float(runtime_seconds),
        "available_memory_gib_before": float(available_before),
        "available_memory_gib_after": float(available_after),
        "peak_process_rss_gib_observed": float(peak_rss),
    }




def _read_forcing_precipitation(
    path: Path,
    *,
    start: str,
    end: str,
) -> pd.Series:
    """Read one CAMELS-US forcing file and return an aligned precipitation series."""
    frame = pd.read_csv(path, sep=r"\s+", skiprows=3)
    normalized = {str(column).lower(): column for column in frame.columns}
    date_columns = []
    for name in ("year", "mnth", "day"):
        if name not in normalized:
            raise ValueError(f"forcing file is missing {name}: {path}")
        date_columns.append(normalized[name])
    precipitation_columns = [
        column for column in frame.columns if str(column).lower().startswith("prcp(")
    ]
    if len(precipitation_columns) != 1:
        raise ValueError(f"forcing file must contain one named precipitation column: {path}")
    dates = pd.to_datetime({
        "year": frame[date_columns[0]].astype(int),
        "month": frame[date_columns[1]].astype(int),
        "day": frame[date_columns[2]].astype(int),
    })
    precipitation = pd.Series(
        pd.to_numeric(frame[precipitation_columns[0]], errors="raise").to_numpy(dtype=float),
        index=pd.DatetimeIndex(dates),
        name="precipitation_mm_per_day",
    )
    if precipitation.index.has_duplicates or not precipitation.index.is_monotonic_increasing:
        raise ValueError(f"forcing dates must be unique and increasing: {path}")
    expected = pd.date_range(start, end, freq="D")
    selected = precipitation.reindex(expected)
    if selected.isna().any() or not np.isfinite(selected.to_numpy(dtype=float)).all():
        raise ValueError(f"forcing file does not cover the required daily period: {path}")
    return selected


def _event_forcing_panel(
    events: pd.DataFrame,
    *,
    forcing_by_product: dict[str, pd.Series],
) -> pd.DataFrame:
    """Attach seven-day and antecedent 30-day precipitation sums to events."""
    required = {
        "basin_id",
        "event_threshold_quantile",
        "event_id",
        "observed_peak_date",
        "window_start",
        "window_end",
        "season",
        "regime",
    }
    missing = required.difference(events.columns)
    if missing:
        raise ValueError(f"event forcing columns are missing: {sorted(missing)}")
    if set(forcing_by_product) != set(FIXED_FORCING_PRODUCTS):
        raise ValueError(f"forcing products must be exactly {FIXED_FORCING_PRODUCTS}")
    rows = []
    for event in events.itertuples(index=False):
        row = {
            "basin_id": str(event.basin_id).zfill(8),
            "event_threshold_quantile": float(event.event_threshold_quantile),
            "event_id": str(event.event_id),
            "observed_peak_date": pd.Timestamp(event.observed_peak_date),
            "season": str(event.season),
            "regime": str(event.regime),
        }
        windows = {
            7: pd.date_range(pd.Timestamp(event.window_start), pd.Timestamp(event.window_end), freq="D"),
            30: pd.date_range(pd.Timestamp(event.observed_peak_date) - pd.Timedelta(days=29),
                              pd.Timestamp(event.observed_peak_date), freq="D"),
        }
        for window_days, dates in windows.items():
            totals = {}
            for product, series in forcing_by_product.items():
                selected = series.reindex(dates)
                if selected.isna().any():
                    raise ValueError(
                        f"{product} forcing is incomplete for basin {row['basin_id']} event {row['event_id']}")
                totals[product] = float(selected.sum())
                row[f"{product}_precip_{window_days}d"] = totals[product]
            row[f"maurer_vs_consensus_log_gap_{window_days}d"] = (
                np.log1p(totals["maurer"])
                - 0.5 * (np.log1p(totals["daymet"]) + np.log1p(totals["nldas"]))
            )
            row[f"maurer_vs_daymet_log_gap_{window_days}d"] = (
                np.log1p(totals["maurer"]) - np.log1p(totals["daymet"]))
            row[f"maurer_vs_nldas_log_gap_{window_days}d"] = (
                np.log1p(totals["maurer"]) - np.log1p(totals["nldas"]))
        rows.append(row)
    return pd.DataFrame(rows)


def _event_key_columns() -> list[str]:
    return ["basin_id", "event_threshold_quantile", "event_id", "observed_peak_date"]


def _load_d09_events(q90_path: Path, q95_path: Path) -> pd.DataFrame:
    frames = []
    for threshold, path in [(0.9, q90_path), (0.95, q95_path)]:
        frame = pd.read_csv(path, dtype={"basin_id": str})
        frame["basin_id"] = frame["basin_id"].map(_normalize_basin_id)
        for column in [
                "observed_peak_date",
                "simulated_peak_date",
                "start_date",
                "end_date",
                "peak_date",
                "window_start",
                "window_end",
        ]:
            frame[column] = pd.to_datetime(frame[column])
        if not np.allclose(frame["event_threshold_quantile"].astype(float), threshold):
            raise ValueError(f"D09 event threshold differs from the registered file role: {path}")
        frames.append(frame)
    events = pd.concat(frames, ignore_index=True)
    model_event_key = [*_event_key_columns(), "model"]
    if events.duplicated(model_event_key).any():
        raise ValueError("D09 contains duplicate model-event rows")
    if set(events["model"]) != set(FIXED_MODELS):
        raise ValueError("D09 event rows do not contain the four fixed models")
    return events


def _event_shape_for_series(
    *,
    dates: pd.DatetimeIndex,
    obs: np.ndarray,
    sim: np.ndarray,
    event_rows: pd.DataFrame,
) -> pd.DataFrame:
    dates = pd.DatetimeIndex(dates)
    obs = np.asarray(obs, dtype=float)
    sim = np.asarray(sim, dtype=float)
    if len(dates) != len(obs) or len(obs) != len(sim):
        raise ValueError("event-shape daily arrays are not aligned")
    obs_series = pd.Series(obs, index=dates)
    sim_series = pd.Series(sim, index=dates)
    rows = []
    for event in event_rows.itertuples(index=False):
        window = pd.date_range(pd.Timestamp(event.window_start), pd.Timestamp(event.window_end), freq="D")
        observed_window = obs_series.reindex(window)
        simulated_window = sim_series.reindex(window)
        if observed_window.isna().any() or simulated_window.isna().any():
            raise ValueError(f"event window is outside the valid daily record: {event.event_id}")
        observed_volume = float(observed_window.sum())
        simulated_volume = float(simulated_window.sum())
        observed_peak = float(event.observed_peak)
        simulated_peak = float(simulated_window.max())
        peak_bias = np.nan if observed_peak == 0.0 else simulated_peak / observed_peak - 1.0
        volume_bias = np.nan if observed_volume == 0.0 else simulated_volume / observed_volume - 1.0
        concentration = event_peak_concentration([peak_bias], [volume_bias])[0]
        rows.append({
            "basin_id": _normalize_basin_id(event.basin_id),
            "event_threshold_quantile": float(event.event_threshold_quantile),
            "event_id": str(event.event_id),
            "observed_peak_date": pd.Timestamp(event.observed_peak_date),
            "aligned_peak_magnitude_bias": float(peak_bias),
            "seven_day_volume_bias": float(volume_bias),
            "peak_concentration": float(concentration),
        })
    return pd.DataFrame(rows)


def _corrected_event_rows(
    *,
    model: str,
    dates: pd.DatetimeIndex,
    obs: np.ndarray,
    sim: np.ndarray,
    event_rows: pd.DataFrame,
) -> tuple[dict, pd.DataFrame]:
    geometry = daily_amplitude_geometry(obs, sim, high_quantile=0.9)
    oracle = oracle_moment_match(obs, sim)
    if not oracle["defined"]:
        return geometry, pd.DataFrame(columns=[
            "basin_id",
            "model",
            "event_threshold_quantile",
            "oracle_aligned_peak_bias",
            "oracle_seven_day_volume_bias",
        ])
    shapes = _event_shape_for_series(
        dates=dates,
        obs=obs,
        sim=oracle["corrected"],
        event_rows=event_rows,
    )
    shapes = shapes.rename(columns={
        "aligned_peak_magnitude_bias": "oracle_aligned_peak_bias",
        "seven_day_volume_bias": "oracle_seven_day_volume_bias",
    })
    shapes.insert(1, "model", model)
    return geometry, shapes


def _summarize_oracle_events(rows: pd.DataFrame) -> pd.DataFrame:
    summaries = []
    if rows.empty:
        return pd.DataFrame(summaries)
    for (model, threshold), group in rows.groupby(
            ["model", "event_threshold_quantile"], sort=True):
        basin = group.groupby("basin_id", sort=True)[
            ["oracle_aligned_peak_bias", "oracle_seven_day_volume_bias"]
        ].median()
        summaries.append({
            "model": model,
            "event_threshold_quantile": float(threshold),
            "oracle_event_basin_count": int(len(basin)),
            "median_oracle_aligned_peak_bias": float(
                basin["oracle_aligned_peak_bias"].median()),
            "median_oracle_seven_day_volume_bias": float(
                basin["oracle_seven_day_volume_bias"].median()),
        })
    return pd.DataFrame(summaries)


def _merge_oracle_event_summary(
    amplitude: pd.DataFrame,
    oracle_events: pd.DataFrame,
) -> pd.DataFrame:
    output = amplitude.copy()
    summary = _summarize_oracle_events(oracle_events)
    for threshold, label in [(0.9, "q90"), (0.95, "q95")]:
        selected = summary.loc[np.isclose(summary["event_threshold_quantile"], threshold)].drop(
            columns="event_threshold_quantile")
        selected = selected.rename(columns={
            "oracle_event_basin_count": f"{label}_oracle_event_basin_count",
            "median_oracle_aligned_peak_bias": f"{label}_median_oracle_aligned_peak_bias",
            "median_oracle_seven_day_volume_bias": f"{label}_median_oracle_seven_day_volume_bias",
        })
        output = output.merge(selected, on="model", how="left", validate="one_to_one")
    return output


def _summarize_member_shape(
    rows: pd.DataFrame,
    *,
    member: str,
) -> list[dict]:
    summaries = []
    for threshold, group in rows.groupby("event_threshold_quantile", sort=True):
        finite = group.loc[np.isfinite(group["peak_concentration"])]
        basin = finite.groupby("basin_id", sort=True)["peak_concentration"].median()
        summaries.append({
            "member": member,
            "event_threshold_quantile": float(threshold),
            "median_peak_concentration": float(basin.median()) if len(basin) else np.nan,
            "basin_count_valid": int(len(basin)),
            "event_count_valid": int(len(finite)),
            "undefined_event_count": int(len(group) - len(finite)),
        })
    return summaries


def _load_single_seed_payload(
    record: dict,
    *,
    ensemble: dict,
    lstm_events: pd.DataFrame,
) -> tuple[pd.DataFrame, dict]:
    seed = int(record["seed"])
    path = Path(record["predictions_path"])
    expected_hash = str(record["predictions_sha256"])
    with open(path, "rb") as handle:
        payload = pickle.load(handle)
    if _sha256(path) != expected_hash:
        raise ValueError(f"neural seed {seed} changed while being read")
    if not isinstance(payload, dict) or len(payload) != 531:
        raise ValueError(f"neural seed {seed} does not contain 531 basins")
    frames = []
    for raw_basin_id in sorted(payload, key=str):
        basin_id = _normalize_basin_id(raw_basin_id)
        dataset = payload[raw_basin_id]["1D"]["xr"]
        obs_variable, sim_variable = _prediction_variables(dataset)
        obs = _xarray_series(dataset, obs_variable)
        sim = _xarray_series(dataset, sim_variable)
        dates = pd.DatetimeIndex(dataset["date"].values)
        valid = np.isfinite(obs)
        dates = dates[valid]
        obs = obs[valid].astype(float)
        sim = sim[valid].astype(float)
        reference = ensemble[basin_id]
        if not dates.equals(reference["dates"]) or not np.array_equal(obs, reference["obs"]):
            raise ValueError(f"neural seed {seed}, basin {basin_id} differs from the ensemble reference")
        basin_events = lstm_events.loc[lstm_events["basin_id"] == basin_id]
        frames.append(_event_shape_for_series(
            dates=dates,
            obs=obs,
            sim=sim,
            event_rows=basin_events,
        ))
    del payload
    gc.collect()
    return pd.concat(frames, ignore_index=True), {
        "role": f"neural_seed_{seed}_predictions",
        "path": path,
        "sha256": expected_hash,
    }


def _forcing_inventory_frame(
    inventory: dict[str, dict[str, Path]],
    *,
    data_root: Path,
) -> pd.DataFrame:
    rows = []
    for product in FIXED_FORCING_PRODUCTS:
        for basin_id, path in sorted(inventory[product].items()):
            rows.append({
                "product": product,
                "basin_id": basin_id,
                "path_relative_to_data_root": path.relative_to(data_root).as_posix(),
                "bytes": int(path.stat().st_size),
                "sha256_before": _sha256(path),
            })
    return pd.DataFrame(rows)


def _verify_forcing_inventory(
    frame: pd.DataFrame,
    *,
    data_root: Path,
) -> pd.DataFrame:
    verified = frame.copy()
    after = []
    for row in verified.itertuples(index=False):
        path = data_root / row.path_relative_to_data_root
        digest = _sha256(path)
        if digest != row.sha256_before:
            raise ValueError(f"forcing input changed while being read: {row.product}/{row.basin_id}")
        after.append(digest)
    verified["sha256_after_read"] = after
    verified["verified_unchanged"] = True
    return verified


def _aggregate_inventory_hash(frame: pd.DataFrame) -> str:
    import hashlib
    digest = hashlib.sha256()
    columns = ["product", "basin_id", "path_relative_to_data_root", "bytes", "sha256_before"]
    for row in frame.sort_values(["product", "basin_id"])[columns].itertuples(index=False, name=None):
        digest.update(("|".join(map(str, row)) + "\n").encode("utf-8"))
    return digest.hexdigest()


def _build_forcing_panel(
    unique_events: pd.DataFrame,
    *,
    inventory: dict[str, dict[str, Path]],
    config: dict,
) -> pd.DataFrame:
    frames = []
    read_start = str((pd.Timestamp(config["evaluation_start"]) - pd.Timedelta(days=29)).date())
    read_end = config["evaluation_end"]
    for basin_id, basin_events in unique_events.groupby("basin_id", sort=True):
        forcing = {
            product: _read_forcing_precipitation(
                inventory[product][basin_id],
                start=read_start,
                end=read_end,
            )
            for product in FIXED_FORCING_PRODUCTS
        }
        frames.append(_event_forcing_panel(basin_events, forcing_by_product=forcing))
    return pd.concat(frames, ignore_index=True)


def _attach_forcing_to_model_events(
    model_events: pd.DataFrame,
    forcing_panel: pd.DataFrame,
) -> pd.DataFrame:
    event_key = _event_key_columns()
    if forcing_panel.duplicated(event_key).any():
        raise ValueError("forcing panel contains duplicate event keys")
    attached = model_events.merge(
        forcing_panel,
        on=[*event_key, "season", "regime"],
        how="left",
        validate="many_to_one",
    )
    if attached["maurer_precip_7d"].isna().any():
        raise ValueError("at least one model event lacks forcing-product totals")
    return attached


def _forcing_association_outputs(
    attached_events: pd.DataFrame,
    *,
    config: dict,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    summaries = []
    quartiles = []
    bootstrap = config["bootstrap"]
    for window in config["forcing_accumulation_windows_days"]:
        for gap_index, (gap_name, template) in enumerate(FORCING_GAP_COLUMNS.items()):
            gap_column = template.format(window=window)
            input_rows = attached_events[[
                "basin_id",
                "event_threshold_quantile",
                "event_id",
                "observed_peak_date",
                "season",
                "regime",
                "model",
                "seven_day_volume_bias",
                gap_column,
            ]].rename(columns={gap_column: "forcing_gap"})
            summary, quartile = within_basin_forcing_association(
                input_rows,
                n_resamples=int(bootstrap["resamples"]),
                seed=int(bootstrap["seed"]) + int(window) * 10 + gap_index,
            )
            summary.insert(0, "forcing_gap_type", gap_name)
            summary.insert(0, "forcing_window_days", int(window))
            quartile.insert(0, "forcing_gap_type", gap_name)
            quartile.insert(0, "forcing_window_days", int(window))
            summaries.append(summary)
            quartiles.append(quartile)
    return pd.concat(summaries, ignore_index=True), pd.concat(quartiles, ignore_index=True)


def _undefined_shape_cases(events: pd.DataFrame) -> dict:
    work = events.copy()
    work["peak_concentration"] = event_peak_concentration(
        work["aligned_peak_magnitude_bias"].to_numpy(dtype=float),
        work["seven_day_volume_bias"].to_numpy(dtype=float),
    )
    output = {}
    for (model, threshold), group in work.groupby(
            ["model", "event_threshold_quantile"], sort=True):
        invalid = group.loc[~np.isfinite(group["peak_concentration"])]
        key = f"{model}_q{int(round(float(threshold) * 100))}"
        output[key] = {
            "undefined_event_count": int(len(invalid)),
            "basin_count_with_undefined_shape": int(invalid["basin_id"].nunique()),
            "basin_04213075_event_count": int((invalid["basin_id"] == "04213075").sum()),
        }
    return output


def _process_registered_predictions(
    *,
    events: pd.DataFrame,
    regimes: pd.DataFrame,
    run_ledger_path: Path,
    conceptual_manifest_path: Path,
) -> dict:
    regime_map = regimes.set_index("basin_id")["regime"].to_dict()
    ensemble, neural_sources = _load_neural_ensemble_low_memory(run_ledger_path)
    peak_rss = _current_rss_gib()
    geometry_rows = []
    oracle_event_frames = []
    lstm_events = events.loc[events["model"] == "LSTM"].copy()

    for basin_id in sorted(ensemble):
        record = ensemble[basin_id]
        basin_events = lstm_events.loc[lstm_events["basin_id"] == basin_id]
        geometry, corrected = _corrected_event_rows(
            model="LSTM",
            dates=record["dates"],
            obs=record["obs"],
            sim=record["sim"],
            event_rows=basin_events,
        )
        geometry_rows.append({
            "basin_id": basin_id,
            "regime": regime_map[basin_id],
            "model": "LSTM",
            **geometry,
        })
        if not corrected.empty:
            oracle_event_frames.append(corrected)

    ensemble_shape = lstm_events.copy()
    ensemble_shape["peak_concentration"] = event_peak_concentration(
        ensemble_shape["aligned_peak_magnitude_bias"].to_numpy(dtype=float),
        ensemble_shape["seven_day_volume_bias"].to_numpy(dtype=float),
    )
    member_shape_rows = _summarize_member_shape(ensemble_shape, member="ensemble_8seed")

    ledger = _load_json(run_ledger_path)
    output_records = ledger.get("output_records", [])
    if tuple(int(record["seed"]) for record in output_records) != FIXED_SEEDS:
        raise ValueError("D10 seed records drifted from the fixed eight-seed order")
    for record in output_records:
        seed_shapes, _ = _load_single_seed_payload(
            record,
            ensemble=ensemble,
            lstm_events=lstm_events,
        )
        member_shape_rows.extend(_summarize_member_shape(
            seed_shapes,
            member=f"seed_{int(record['seed'])}",
        ))
        peak_rss = max(peak_rss, _current_rss_gib())
        del seed_shapes
        gc.collect()

    conceptual_manifest = _load_json(conceptual_manifest_path)
    if (
            conceptual_manifest.get("status") != "completed"
            or int(conceptual_manifest.get("basin_count", 0)) != 531
    ):
        raise ValueError("D10 requires the completed 531-basin conceptual manifest")
    conceptual_sources = [_source("conceptual_prediction_manifest", conceptual_manifest_path)]
    protocol_path = Path(conceptual_manifest["protocol_manifest_path"])
    conceptual_sources.append(_source(
        "conceptual_common_loss_protocol",
        protocol_path,
        str(conceptual_manifest["protocol_manifest_sha256"]),
    ))
    artifacts = conceptual_manifest.get("artifacts", [])
    if {item.get("model") for item in artifacts} != set(MODEL_NAME_MAP):
        raise ValueError("D10 requires exactly GR4J, XAJ, and HBV-lite conceptual outputs")
    expected_rows = sum(len(record["obs"]) for record in ensemble.values())
    for artifact in sorted(artifacts, key=lambda item: str(item["model"])):
        source_model = str(artifact["model"])
        model = MODEL_NAME_MAP[source_model]
        path = Path(artifact["daily_predictions_path"])
        expected_hash = str(artifact["daily_predictions_sha256"])
        conceptual_sources.append(_source(
            f"conceptual_{source_model}_daily_predictions", path, expected_hash))
        daily = pd.read_csv(path, dtype={"basin_id": str}, parse_dates=["date"])
        daily["basin_id"] = daily["basin_id"].map(_normalize_basin_id)
        if len(daily) != expected_rows or daily["basin_id"].nunique() != 531:
            raise ValueError(f"{model} daily predictions do not retain the registered population")
        if daily.duplicated(["basin_id", "date"]).any():
            raise ValueError(f"{model} daily predictions contain duplicate basin-date rows")
        model_events = events.loc[events["model"] == model]
        for basin_id, group in daily.groupby("basin_id", sort=True):
            group = group.sort_values("date")
            reference = ensemble[basin_id]
            dates = pd.DatetimeIndex(group["date"])
            obs = group["obs"].to_numpy(dtype=float)
            sim = group["sim"].to_numpy(dtype=float)
            if not dates.equals(reference["dates"]):
                raise ValueError(f"{model}, basin {basin_id} dates differ from the LSTM reference")
            if not np.allclose(obs, reference["obs"], rtol=1e-5, atol=1e-4):
                raise ValueError(f"{model}, basin {basin_id} observations differ from the LSTM reference")
            basin_events = model_events.loc[model_events["basin_id"] == basin_id]
            geometry, corrected = _corrected_event_rows(
                model=model,
                dates=dates,
                obs=reference["obs"],
                sim=sim,
                event_rows=basin_events,
            )
            geometry_rows.append({
                "basin_id": basin_id,
                "regime": regime_map[basin_id],
                "model": model,
                **geometry,
            })
            if not corrected.empty:
                oracle_event_frames.append(corrected)
        if _sha256(path) != expected_hash:
            raise ValueError(f"{model} daily predictions changed while D10 was reading them")
        peak_rss = max(peak_rss, _current_rss_gib())
        del daily
        gc.collect()

    geometry = pd.DataFrame(geometry_rows)
    if (
            len(geometry) != 531 * 4
            or geometry["basin_id"].nunique() != 531
            or set(geometry["model"]) != set(FIXED_MODELS)
            or "04213075" not in set(geometry["basin_id"])
    ):
        raise ValueError("D10 amplitude geometry does not contain four models over all 531 basins")
    oracle_events = pd.concat(oracle_event_frames, ignore_index=True)
    del ensemble
    gc.collect()
    return {
        "geometry_rows": geometry,
        "oracle_event_rows": oracle_events,
        "member_shape_summary": pd.DataFrame(member_shape_rows),
        "sources": [*neural_sources, *conceptual_sources],
        "peak_rss": peak_rss,
    }


def _deduplicate_sources(sources: list[dict]) -> list[dict]:
    deduplicated = []
    seen = set()
    for source in sources:
        key = (str(source["role"]), str(source["path"]))
        if key not in seen:
            deduplicated.append(source)
            seen.add(key)
    return deduplicated


def _execute_registered_analysis(
    *,
    output_dir: Path,
    config: dict,
) -> dict:
    d09_manifest = _load_json(DEFAULT_D09_MANIFEST)
    _validate_upstream_d09_manifest(d09_manifest)
    output_hashes = {Path(record["path"]).name: record["sha256"] for record in d09_manifest["outputs"]}
    regular_sources = [
        _source("d10_configuration", DEFAULT_CONFIG),
        _source("upstream_D09_manifest", DEFAULT_D09_MANIFEST),
        _source("upstream_D09_q90_events", DEFAULT_D09_Q90, output_hashes[DEFAULT_D09_Q90.name]),
        _source("upstream_D09_q95_events", DEFAULT_D09_Q95, output_hashes[DEFAULT_D09_Q95.name]),
        _source("frozen_basin_attributes", DEFAULT_ATTRIBUTES),
        _source("registered_seed_configuration", DEFAULT_REGISTERED_SEED_CONFIG),
    ]
    events = _load_d09_events(DEFAULT_D09_Q90, DEFAULT_D09_Q95)
    regimes = _load_regimes(DEFAULT_REGIMES)
    event_shape = summarize_event_shape(
        events,
        n_resamples=int(config["bootstrap"]["resamples"]),
        seed=int(config["bootstrap"]["seed"]),
    )
    pairwise_shape = pairwise_event_shape_summary(
        events,
        reference_model="LSTM",
        n_resamples=int(config["bootstrap"]["resamples"]),
        seed=int(config["bootstrap"]["seed"]),
    )
    prediction_outputs = _process_registered_predictions(
        events=events,
        regimes=regimes,
        run_ledger_path=DEFAULT_RUN_LEDGER,
        conceptual_manifest_path=DEFAULT_CONCEPTUAL_MANIFEST,
    )
    regular_sources.extend(prediction_outputs["sources"])
    amplitude = summarize_amplitude_geometry_rows(prediction_outputs["geometry_rows"])
    amplitude = _merge_oracle_event_summary(amplitude, prediction_outputs["oracle_event_rows"])
    attributes = pd.read_csv(DEFAULT_ATTRIBUTES, dtype={"basin_id": str})
    associations = prespecified_cause_associations(
        prediction_outputs["geometry_rows"],
        attributes,
        attribute_columns=ATTRIBUTE_COLUMN_MAP,
    )

    data_root = _data_root_from_registered_config(DEFAULT_REGISTERED_SEED_CONFIG)
    expected_basins = set(regimes["basin_id"])
    forcing_inventory = _index_forcing_files(
        data_root / "basin_mean_forcing",
        expected_basin_ids=expected_basins,
    )
    inventory_frame = _forcing_inventory_frame(forcing_inventory, data_root=data_root)
    lstm_events = events.loc[events["model"] == "LSTM"].copy()
    forcing_event_columns = [
        *_event_key_columns(), "window_start", "window_end", "season", "regime"
    ]
    unique_events = lstm_events[forcing_event_columns].copy()
    if unique_events.duplicated(_event_key_columns()).any():
        raise ValueError("LSTM D09 rows contain duplicate event keys")
    forcing_panel = _build_forcing_panel(
        unique_events,
        inventory=forcing_inventory,
        config=config,
    )
    attached_events = _attach_forcing_to_model_events(events, forcing_panel)
    forcing_summary, forcing_quartiles = _forcing_association_outputs(
        attached_events,
        config=config,
    )
    inventory_frame = _verify_forcing_inventory(inventory_frame, data_root=data_root)
    inventory_hash = _aggregate_inventory_hash(inventory_frame)

    undefined_cases = _undefined_shape_cases(events)
    q90_dates = set(map(tuple, unique_events.loc[
        np.isclose(unique_events["event_threshold_quantile"], 0.9),
        ["basin_id", "observed_peak_date"],
    ].to_numpy()))
    q95_dates = set(map(tuple, unique_events.loc[
        np.isclose(unique_events["event_threshold_quantile"], 0.95),
        ["basin_id", "observed_peak_date"],
    ].to_numpy()))
    self_checks = {
        "analysis_status": "posthoc_exploratory",
        "upstream_D09_conditional_branches_executed": [],
        "upstream_D09_shape_gate_supported": False,
        "upstream_D09_forcing_proxy_gate_supported": False,
        "q90_model_event_row_count": int(np.isclose(events["event_threshold_quantile"], 0.9).sum()),
        "q95_model_event_row_count": int(np.isclose(events["event_threshold_quantile"], 0.95).sum()),
        "q90_unique_event_count": int(len(q90_dates)),
        "q95_unique_event_count": int(len(q95_dates)),
        "q95_peak_date_overlap_with_q90_fraction": float(len(q90_dates & q95_dates) / len(q95_dates)),
        "forcing_file_count": int(len(inventory_frame)),
        "forcing_inventory_aggregate_sha256": inventory_hash,
        "contains_basin_04213075": True,
        "undefined_shape_cases": undefined_cases,
        "ordinary_event_level_p_values_emitted": False,
    }

    output_paths = [output_dir / name for name in EXPECTED_OUTPUTS[:-1]]
    amplitude.to_csv(output_paths[0], index=False)
    event_shape.to_csv(output_paths[1], index=False)
    pairwise_shape.to_csv(output_paths[2], index=False)
    prediction_outputs["member_shape_summary"].to_csv(output_paths[3], index=False)
    forcing_summary.to_csv(output_paths[4], index=False)
    forcing_quartiles.to_csv(output_paths[5], index=False)
    associations.to_csv(output_paths[6], index=False)
    output_paths[7].write_text(
        json.dumps(self_checks, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    inventory_frame.to_csv(output_paths[8], index=False)

    verified_sources = _verify_sources_unchanged(_deduplicate_sources(regular_sources))
    verified_sources.append({
        "role": "camels_us_three_product_forcing_inventory",
        "path": str(data_root.resolve()),
        "file_count": int(len(inventory_frame)),
        "sha256": inventory_hash,
        "sha256_after_read": inventory_hash,
        "verified_unchanged": True,
        "inventory_output": output_paths[8].relative_to(REPO_ROOT).as_posix(),
    })
    return {
        "output_paths": output_paths,
        "sources": verified_sources,
        "undefined_cases": undefined_cases,
        "peak_rss": max(prediction_outputs["peak_rss"], _current_rss_gib()),
    }


def run(
    *,
    output_dir: Path = DEFAULT_OUTPUT_DIR,
    config_path: Path = DEFAULT_CONFIG,
    exact_command: str | None = None,
) -> dict:
    started = time.perf_counter()
    started_at_utc = datetime.now(timezone.utc).isoformat()
    available_before = _available_gib()
    if available_before < 4.0:
        raise MemoryError(
            f"D10 requires at least 4.0 GiB available; found {available_before:.2f} GiB")
    output_dir = Path(output_dir)
    if output_dir.exists():
        raise FileExistsError(f"D10 refuses to overwrite an existing output directory: {output_dir}")
    config = _validate_config(config_path)
    if exact_command is None:
        command = [
            "python", "-X", "utf8", "-m",
            "src.lstm_fair_531.scripts.run_posthoc_cause_diagnostics",
        ]
        if output_dir != DEFAULT_OUTPUT_DIR:
            command.extend(["--output-dir", str(output_dir)])
        exact_command = subprocess.list2cmdline(command)
    output_dir.mkdir(parents=True)
    execution = _execute_registered_analysis(output_dir=output_dir, config=config)
    resolved_output = output_dir.resolve()
    resolved_repo = REPO_ROOT.resolve()
    declared_root = REPO_ROOT if resolved_output.is_relative_to(resolved_repo) else output_dir.parent
    manifest = _build_manifest(
        config=config,
        output_paths=execution["output_paths"],
        sources=execution["sources"],
        undefined_cases=execution["undefined_cases"],
        started_at_utc=started_at_utc,
        runtime_seconds=time.perf_counter() - started,
        available_before=available_before,
        available_after=_available_gib(),
        peak_rss=max(float(execution["peak_rss"]), _current_rss_gib()),
        repo_root=declared_root,
        exact_command=exact_command,
    )
    manifest_path = output_dir / EXPECTED_OUTPUTS[-1]
    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return manifest


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    manifest = run(output_dir=args.output_dir, config_path=args.config)
    print(json.dumps({
        "experiment_id": manifest["experiment_id"],
        "status": manifest["status"],
        "output_dir": str(args.output_dir),
        "runtime_seconds": manifest["runtime_seconds"],
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
