"""Compare every registered context cell and primary attribute across R01 and R02."""
from __future__ import annotations

import argparse
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

from src.lstm_fair_531.scripts.evidence_protocols import (
    HISTORICAL_PROTOCOL_ID,
    IDENTICAL_PROTOCOL_ID,
    PACKAGE_ROOT,
    get_protocol,
)


EXPERIMENT_ID = "D08_full_protocol_matrix_stability_20260726"
EXPECTED_OUTPUTS = (
    "protocol_matrix_stability_summary.csv",
    "protocol_matrix_cell_deltas.csv",
    "D08_manifest.json",
)
EXPECTED_FAMILY_ROWS = {
    "season": 16,
    "flow": 12,
    "joint": 48,
    "primary_attribute": 39,
}
KEY_COLUMNS = {
    "season": ["regime", "season"],
    "flow": ["regime", "flow_group"],
    "joint": ["regime", "season", "flow_group"],
}
PRIMARY_ATTRIBUTE_TARGET = "lstm_minus_best_conceptual"

REPO_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_OUTPUT_DIR = REPO_ROOT / "results/18_lstm_fair_531" / EXPERIMENT_ID


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _relative(path: Path) -> str:
    return Path(path).resolve().relative_to(REPO_ROOT).as_posix()


def _cell_label(frame: pd.DataFrame, key_columns: list[str]) -> pd.Series:
    return frame[key_columns].astype(str).agg(" | ".join, axis=1)


def _require_matrix(frame: pd.DataFrame, key_columns: list[str], expected_rows: int, label: str) -> None:
    required = {
        *key_columns,
        "gap_concentration_ratio",
        "median_best_conceptual_mae_minus_lstm",
        "shared_failure_rate",
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"{label} is missing columns: {missing}")
    if len(frame) != expected_rows:
        raise ValueError(f"{label} must contain {expected_rows} rows; found {len(frame)}")
    if frame.duplicated(key_columns).any():
        raise ValueError(f"{label} has duplicate matrix keys")


def compare_context_matrix(
    historical: pd.DataFrame,
    rebuilt: pd.DataFrame,
    *,
    family: str,
    key_columns: list[str],
    expected_rows: int,
) -> tuple[dict, pd.DataFrame]:
    """Return complete cell deltas and a one-row stability summary."""
    _require_matrix(historical, key_columns, expected_rows, f"historical {family}")
    _require_matrix(rebuilt, key_columns, expected_rows, f"rebuilt {family}")
    historical_keys = set(map(tuple, historical[key_columns].astype(str).to_numpy()))
    rebuilt_keys = set(map(tuple, rebuilt[key_columns].astype(str).to_numpy()))
    keys_equal = historical_keys == rebuilt_keys
    if not keys_equal:
        raise ValueError(
            f"{family} protocol key sets differ: missing={sorted(historical_keys - rebuilt_keys)[:3]}, "
            f"extra={sorted(rebuilt_keys - historical_keys)[:3]}"
        )
    columns = key_columns + [
        "gap_concentration_ratio",
        "median_best_conceptual_mae_minus_lstm",
        "shared_failure_rate",
    ]
    merged = historical[columns].merge(
        rebuilt[columns],
        on=key_columns,
        validate="one_to_one",
        suffixes=("_r01", "_r02"),
    )
    merged.insert(0, "family", family)
    merged["cell"] = _cell_label(merged, key_columns)
    merged["concentration_delta"] = (
        merged["gap_concentration_ratio_r02"] - merged["gap_concentration_ratio_r01"]
    )
    merged["median_gap_delta"] = (
        merged["median_best_conceptual_mae_minus_lstm_r02"]
        - merged["median_best_conceptual_mae_minus_lstm_r01"]
    )
    merged["shared_failure_delta"] = (
        merged["shared_failure_rate_r02"] - merged["shared_failure_rate_r01"]
    )
    merged["concentration_above_one_r01"] = merged["gap_concentration_ratio_r01"] > 1
    merged["concentration_above_one_r02"] = merged["gap_concentration_ratio_r02"] > 1
    merged["median_gap_positive_r01"] = merged["median_best_conceptual_mae_minus_lstm_r01"] > 0
    merged["median_gap_positive_r02"] = merged["median_best_conceptual_mae_minus_lstm_r02"] > 0
    concentration_flips = (
        merged["concentration_above_one_r01"] != merged["concentration_above_one_r02"]
    )
    sign_flips = merged["median_gap_positive_r01"] != merged["median_gap_positive_r02"]
    top_r01 = merged.loc[merged["gap_concentration_ratio_r01"].idxmax(), "cell"]
    top_r02 = merged.loc[merged["gap_concentration_ratio_r02"].idxmax(), "cell"]
    summary = {
        "family": family,
        "row_count": int(len(merged)),
        "key_sets_equal": keys_equal,
        "concentration_rank_spearman": float(
            merged["gap_concentration_ratio_r01"].corr(
                merged["gap_concentration_ratio_r02"], method="spearman"
            )
        ),
        "shared_failure_rank_spearman": float(
            merged["shared_failure_rate_r01"].corr(
                merged["shared_failure_rate_r02"], method="spearman"
            )
        ),
        "concentration_above_one_flips": int(concentration_flips.sum()),
        "concentration_above_one_retention_count": int((~concentration_flips).sum()),
        "median_gap_sign_flips": int(sign_flips.sum()),
        "median_gap_direction_retention_count": int((~sign_flips).sum()),
        "max_abs_concentration_shift": float(merged["concentration_delta"].abs().max()),
        "max_abs_shared_failure_shift": float(merged["shared_failure_delta"].abs().max()),
        "largest_concentration_increase": float(merged["concentration_delta"].max()),
        "largest_concentration_decrease": float(merged["concentration_delta"].min()),
        "top_cell_r01": top_r01,
        "top_cell_r02": top_r02,
        "top_cell_retained": top_r01 == top_r02,
    }
    return summary, merged


def compare_primary_attributes(
    historical: pd.DataFrame,
    rebuilt: pd.DataFrame,
) -> tuple[dict, pd.DataFrame]:
    """Compare the 39 predeclared primary basin attributes only."""
    required = {"target", "feature", "spearman_rho", "q_value", "significant_fdr_05"}
    for label, frame in (("historical attributes", historical), ("rebuilt attributes", rebuilt)):
        missing = sorted(required - set(frame.columns))
        if missing:
            raise ValueError(f"{label} is missing columns: {missing}")
    left = historical[historical["target"] == PRIMARY_ATTRIBUTE_TARGET].copy()
    right = rebuilt[rebuilt["target"] == PRIMARY_ATTRIBUTE_TARGET].copy()
    for label, frame in (("historical primary attributes", left), ("rebuilt primary attributes", right)):
        if len(frame) != 39 or frame["feature"].duplicated().any():
            raise ValueError(f"{label} must contain exactly 39 unique features")
    left_features = set(left["feature"])
    right_features = set(right["feature"])
    if left_features != right_features:
        raise ValueError("Primary attribute feature sets differ between protocols")
    columns = ["target", "feature", "spearman_rho", "q_value", "significant_fdr_05"]
    merged = left[columns].merge(
        right[columns],
        on=["target", "feature"],
        validate="one_to_one",
        suffixes=("_r01", "_r02"),
    )
    merged.insert(0, "family", "primary_attribute")
    merged["cell"] = merged["feature"]
    merged["spearman_rho_delta"] = merged["spearman_rho_r02"] - merged["spearman_rho_r01"]
    merged["q_value_delta"] = merged["q_value_r02"] - merged["q_value_r01"]
    direction_tolerance = 1e-12
    rho_r01 = merged["spearman_rho_r01"].where(
        merged["spearman_rho_r01"].abs() > direction_tolerance, 0.0
    )
    rho_r02 = merged["spearman_rho_r02"].where(
        merged["spearman_rho_r02"].abs() > direction_tolerance, 0.0
    )
    merged["direction_reversed"] = rho_r01 * rho_r02 < 0
    merged["fdr_classification_changed"] = (
        merged["significant_fdr_05_r01"].astype(bool)
        != merged["significant_fdr_05_r02"].astype(bool)
    )
    top_r01 = merged.loc[merged["spearman_rho_r01"].abs().idxmax(), "feature"]
    top_r02 = merged.loc[merged["spearman_rho_r02"].abs().idxmax(), "feature"]
    summary = {
        "family": "primary_attribute",
        "row_count": int(len(merged)),
        "key_sets_equal": left_features == right_features,
        "concentration_rank_spearman": float(
            merged["spearman_rho_r01"].corr(merged["spearman_rho_r02"], method="spearman")
        ),
        "fdr_classification_flips": int(merged["fdr_classification_changed"].sum()),
        "direction_reversal_count": int(merged["direction_reversed"].sum()),
        "direction_retention_count": int((~merged["direction_reversed"]).sum()),
        "max_abs_rho_shift": float(merged["spearman_rho_delta"].abs().max()),
        "largest_rho_increase": float(merged["spearman_rho_delta"].max()),
        "largest_rho_decrease": float(merged["spearman_rho_delta"].min()),
        "top_cell_r01": top_r01,
        "top_cell_r02": top_r02,
        "top_cell_retained": top_r01 == top_r02,
    }
    return summary, merged


def run(output_dir: Path = DEFAULT_OUTPUT_DIR) -> dict:
    started = time.perf_counter()
    output_dir = Path(output_dir)
    if output_dir.exists():
        raise FileExistsError(f"D08 refuses to overwrite existing output: {output_dir}")
    output_dir.mkdir(parents=True)
    historical_protocol = get_protocol(HISTORICAL_PROTOCOL_ID)
    rebuilt_protocol = get_protocol(IDENTICAL_PROTOCOL_ID)
    summaries = []
    deltas = []
    inputs = []
    for family in ("season", "flow", "joint"):
        historical_path = REPO_ROOT / PACKAGE_ROOT / historical_protocol.deep_dive[family]
        rebuilt_path = REPO_ROOT / PACKAGE_ROOT / rebuilt_protocol.deep_dive[family]
        historical = pd.read_csv(historical_path)
        rebuilt = pd.read_csv(rebuilt_path)
        summary, family_deltas = compare_context_matrix(
            historical,
            rebuilt,
            family=family,
            key_columns=KEY_COLUMNS[family],
            expected_rows=EXPECTED_FAMILY_ROWS[family],
        )
        summaries.append(summary)
        deltas.append(family_deltas)
        inputs.extend([historical_path, rebuilt_path])

    historical_attribute_path = REPO_ROOT / PACKAGE_ROOT / historical_protocol.deep_dive["spearman"]
    rebuilt_attribute_path = REPO_ROOT / PACKAGE_ROOT / rebuilt_protocol.deep_dive["spearman"]
    attribute_summary, attribute_deltas = compare_primary_attributes(
        pd.read_csv(historical_attribute_path),
        pd.read_csv(rebuilt_attribute_path),
    )
    summaries.append(attribute_summary)
    deltas.append(attribute_deltas)
    inputs.extend([historical_attribute_path, rebuilt_attribute_path])

    summary_frame = pd.DataFrame(summaries)
    delta_frame = pd.concat(deltas, ignore_index=True, sort=False)
    summary_path = output_dir / EXPECTED_OUTPUTS[0]
    delta_path = output_dir / EXPECTED_OUTPUTS[1]
    summary_frame.to_csv(summary_path, index=False)
    delta_frame.to_csv(delta_path, index=False)
    manifest = {
        "schema_version": "1.0",
        "experiment_id": EXPERIMENT_ID,
        "status": "completed",
        "purpose": "Audit complete context and primary-attribute pattern stability after rebuilding the whole benchmark under one objective and observation series.",
        "interpretation_boundary": "This is not a training-objective ablation because the neural objective, scoring observations, and conceptual calibrations changed together.",
        "protocols": [HISTORICAL_PROTOCOL_ID, IDENTICAL_PROTOCOL_ID],
        "family_rows": EXPECTED_FAMILY_ROWS,
        "exact_command": "python -X utf8 -m src.lstm_fair_531.scripts.full_protocol_matrix_stability",
        "working_directory": ".",
        "inputs": [
            {"path": _relative(path), "sha256": _sha256(path)} for path in inputs
        ],
        "analysis_code": {"path": _relative(Path(__file__)), "sha256": _sha256(Path(__file__))},
        "outputs": [
            {"path": _relative(path), "bytes": path.stat().st_size, "sha256": _sha256(path)}
            for path in (summary_path, delta_path)
        ],
        "summary": summaries,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "runtime_seconds": time.perf_counter() - started,
    }
    manifest_path = output_dir / EXPECTED_OUTPUTS[2]
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return manifest


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    manifest = run(args.output_dir)
    print(json.dumps({
        "experiment_id": manifest["experiment_id"],
        "status": manifest["status"],
        "runtime_seconds": manifest["runtime_seconds"],
        "summary": manifest["summary"],
    }, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
