"""Saved-array holdout metrics; original gate is imported unchanged."""
import numpy as np
from training_math import candidate_gate
NAMES=['all_mse','all_mae','low_mse','low_mae','middle_mse','middle_mae','high_mse','high_mae','state_proxy']
def forecast_indices(start=2557,end=3288):
    issues=np.arange(start,end-3,dtype=np.int64)
    return issues,issues[:,None]+np.arange(1,4,dtype=np.int64)
def scores(prediction,target,proxy,mask,thresholds):
    prediction=np.asarray(prediction,dtype=np.float64);target=np.asarray(target,dtype=np.float64)
    proxy=np.asarray(proxy,dtype=np.float64);mask=np.asarray(mask,dtype=bool)
    assert prediction.shape==target.shape and prediction.ndim==2 and prediction.shape[1]==3
    assert proxy.shape==mask.shape and proxy.ndim==1
    assert all(np.isfinite(x).all() for x in [prediction,target,proxy,thresholds])
    groups=[np.ones(target.shape,dtype=bool),target<=thresholds[0],(target>thresholds[0])&(target<=thresholds[1]),target>thresholds[1]]
    counts=[int(g.sum()) for g in groups]
    if not all(counts) or not mask.any():raise ValueError('UNRESOLVED_EMPTY_GROUP_OR_STATE_MASK')
    e=prediction-target;values=[]
    for group in groups:values.extend([float(np.mean(e[group]**2)),float(np.mean(np.abs(e[group])))])
    values.append(float(np.mean(proxy[mask]**2)))
    return np.asarray(values,dtype=np.float64),counts
