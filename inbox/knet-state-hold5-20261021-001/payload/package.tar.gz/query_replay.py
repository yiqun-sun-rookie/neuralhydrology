"""Own-job read-only state query plus explicit startup nonce acknowledgement."""
import sys, json, datetime, subprocess, re, time, socket, hashlib, uuid
from pathlib import Path
import safe_io as s
from replay_protocol import TERMINAL, validate_response
BASE = Path(__file__).resolve().parent


def command(args):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=15)
        return dict(returncode=p.returncode, stdout=p.stdout, stderr=p.stderr)
    except subprocess.TimeoutExpired:
        return dict(returncode=124, stdout="", stderr="scheduler timeout")


def load(path):
    return json.loads(s.read_checked(path)) if path.is_file() else None


def query(job):
    identity = load(BASE/"submission.json")
    assert identity and identity["job_id"] == job and identity["remote_root"] == str(BASE)
    contract_sha = hashlib.sha256(s.read_checked(BASE/"replay_contract.json")).hexdigest()
    queue = command(["squeue", "-j", job, "-h", "-o", "%i|%j|%T|%M|%R"])
    control = command(["scontrol", "-o", "show", "job", job])
    fields = dict(re.findall(r"(\w+)=([^\s]+)", control["stdout"]))
    wanted = ["JobID", "State", "ExitCode", "ElapsedRaw", "AllocCPUS", "NodeList", "Start", "End", "WorkDir", "ReqMem"]
    supported = command(["sacct", "--helpformat"])
    assert supported["returncode"] == 0 and all(x in supported["stdout"].split() for x in wanted)
    acct = command(["sacct", "-j", job, "--noheader", "--parsable2", "--format="+",".join(wanted)])
    rows = [dict(zip(wanted, line.split("|"))) for line in acct["stdout"].splitlines() if line]
    own = [row for row in rows if row["JobID"] == job]
    terminal = bool(own and own[0]["State"].split()[0].rstrip("+") in TERMINAL)
    folder = BASE/"runs/02092500/attempt_001"
    snap = nonce = wait = None
    if not terminal and fields.get("JobState") == "RUNNING":
        assert fields["Command"] == str(BASE/"replay.slurm") and fields["WorkDir"] == str(BASE)
        nonce = uuid.uuid4().hex
        started = time.monotonic()
        request = dict(nonce=nonce, job_id=job, contract_sha256=contract_sha,
                       query_host=socket.gethostname(), utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        s.create("monitor_exchange/monitor_request_"+nonce+".json", request)
        response = folder/("monitor_response_"+nonce+".json")
        while time.monotonic()-started < 60:
            if response.exists():
                snap = load(response)
                controller = load(folder/"controller_started.json")
                assert validate_response(request, snap, controller, fields.get("NodeList"))
                if snap["phase"] == "WAITING_FOR_HANDSHAKE":
                    s.create("monitor_exchange/start_allowed_"+nonce+".json",
                             dict(nonce=nonce, job_id=job, contract_sha256=contract_sha,
                                  controller_pid=snap["controller_pid"],
                                  response_sha256=hashlib.sha256(s.read_checked(response)).hexdigest()))
                break
            if (folder/"receipt.json").exists():
                break
            time.sleep(.1)
        wait = time.monotonic()-started
    stat = command(["sstat", "-j", job+".batch", "--noheader", "--parsable2",
                    "--format=JobID,AveCPU,MaxRSS"]) if fields.get("JobState") == "RUNNING" else None
    return dict(job_id=job, identity=identity, remote_root=str(BASE),
                script_path=str(BASE/"replay.slurm"), contract_sha256=contract_sha,
                queried_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                queue=queue, scontrol=control, scheduler_fields=fields, accounting=acct,
                native_job_row=own, terminal=terminal,
                controller=load(folder/"controller_started.json"),
                worker=load(folder/"scientific_started.json"), receipt=load(folder/"receipt.json"),
                result=load(folder/"result.json"), resource=stat,
                startup_handshake=load(folder/"startup_handshake.json"),
                snapshot_nonce=nonce, snapshot_wait_seconds=wait, fresh_snapshot=snap)


if __name__ == "__main__":
    print("PROBE_STATUS_JSON="+json.dumps(query(sys.argv[1])), flush=True)
