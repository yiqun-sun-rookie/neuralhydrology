"""Small certified QP for an all-parameter proposal; no scientific model imports."""
import itertools
import numpy as np


def project(displacement, gradients, bounds=None, tolerance=1e-10):
    d = np.asarray(displacement, dtype=np.float64)
    g = np.asarray(gradients, dtype=np.float64)
    assert d.ndim == 1 and g.ndim == 2 and g.shape[1] == len(d)
    assert np.isfinite(d).all() and np.isfinite(g).all()
    norms = np.linalg.norm(g, axis=1)
    keep = norms > 0
    a = g[keep] / norms[keep, None]
    rhs = np.zeros(len(a)) if bounds is None else np.asarray(bounds)[keep]
    gram = a @ a.T
    ad = a @ d
    best = None
    for size in range(len(a) + 1):
        for active in itertools.combinations(range(len(a)), size):
            ix = list(active)
            lam = np.linalg.lstsq(gram[np.ix_(ix, ix)], ad[ix] - rhs[ix], rcond=None)[0] if ix else np.empty(0)
            products = ad - gram[:, ix] @ lam if ix else ad.copy()
            primal = max(0., float(np.max(products - rhs))) if len(a) else 0.
            equality = float(np.max(np.abs(products[ix] - rhs[ix]))) if ix else 0.
            dual = max(0., float(-lam.min())) if ix else 0.
            if max(primal, equality, dual) > tolerance:
                continue
            objective = float(lam @ gram[np.ix_(ix, ix)] @ lam) if ix else 0.
            if best is None or objective < best[0]:
                best = objective, ix, lam
    if best is None:
        return None, dict(status='UNRESOLVED', active_sets_examined=2**len(a))
    objective, ix, lam = best
    x = d - a[ix].T @ lam if ix else d.copy()
    products = a @ x
    primal = max(0., float(np.max(products - rhs))) if len(a) else 0.
    equality = float(np.max(np.abs(products[ix] - rhs[ix]))) if ix else 0.
    stationarity = float(np.linalg.norm(x - d + a[ix].T @ lam)) if ix else float(np.linalg.norm(x - d))
    dual = max(0., float(-lam.min())) if ix else 0.
    record = dict(status='KKT_VERIFIED' if max(primal, equality, stationarity, dual) <= tolerance else 'UNRESOLVED',
                  active=np.flatnonzero(keep)[ix].tolist(), multipliers=lam.tolist(),
                  primal_residual=primal, equality_residual=equality, stationarity_residual=stationarity,
                  dual_residual=dual, active_sets_examined=2**len(a), squared_distance=objective,
                  zero_gradient_rows=np.flatnonzero(~keep).tolist())
    return (x if record['status']=='KKT_VERIFIED' else None), record


def guarded(before, nominal, gradients, radius, tolerance=1e-10):
    before = np.asarray(before, dtype=np.float64)
    g = np.asarray(gradients, dtype=np.float64)
    lo = (before - radius).astype(np.float32)
    hi = (before + radius).astype(np.float32)
    gaps = np.maximum(np.abs(np.nextafter(lo, -np.inf, dtype=np.float32).astype(float) - lo),
                      np.abs(np.nextafter(hi, np.inf, dtype=np.float32).astype(float) - hi))
    norms = np.linalg.norm(g, axis=1)
    keep = norms > 0
    bounds = np.zeros(len(g))
    bounds[keep] = -(np.abs(g[keep]) / norms[keep, None]) @ (.5*gaps)
    x, certificate = project(nominal, g, bounds, tolerance)
    if x is None:
        return None, dict(status='GUARD_QP_UNRESOLVED', certificate=certificate)
    actual = (before + x).astype(np.float32).astype(float) - before
    products = g @ actual
    violation = max(0., float(np.max(products[keep]/norms[keep]))) if np.any(keep) else 0.
    inside = bool(np.max(np.abs(x)) <= radius) if len(x) else True
    valid = inside and violation <= tolerance
    record = dict(status='CERTIFIED' if valid else 'REJECTED_INSTALLATION', certificate=certificate,
                  radius=radius, normalized_bounds=bounds.tolist(), inside_rounding_box=inside,
                  maximum_normalized_violation=violation, actual_linear_changes=products.tolist(),
                  gradient_norms=norms.tolist(), actual_norm=float(np.linalg.norm(actual)),
                  quantized_zero=bool(not np.any(actual)), strict_state_descent_required=False)
    return (x if valid else None), record


def numerical_tolerance(reference, absolute=1e-10, relative=1e-7):
    return np.maximum(absolute, relative*np.abs(np.asarray(reference)))


def candidate_gate(scores, reference, relative_margin=1e-3, absolute=1e-10, relative=1e-7):
    scores = np.asarray(scores, dtype=float)
    reference = np.asarray(reference, dtype=float)
    tolerance = numerical_tolerance(reference, absolute, relative)
    flow_limit = reference[:8] * (1. + relative_margin) + tolerance[:8]
    state_limit = reference[8] + tolerance[8]
    failed = np.flatnonzero(scores[:8] > flow_limit).tolist()
    return dict(accepted=not failed and bool(scores[8] <= state_limit), failed_flow_indices=failed,
                state_gate_pass=bool(scores[8] <= state_limit), flow_limits=flow_limit.tolist(),
                state_limit=float(state_limit), reference=reference.tolist(),
                numerical_tolerances=tolerance.tolist(), relative_margin=relative_margin)
