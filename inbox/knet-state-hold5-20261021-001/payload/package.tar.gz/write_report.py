"""Report technical completeness separately from original gates and proxy benefit."""
from pathlib import Path
import json,csv,io,datetime
BASE=Path(__file__).resolve().parent
def obj(p):return json.loads(p.read_bytes())
def create(name,value):
    raw=value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2)+'\n'
    with (BASE/name).open('x',encoding='utf-8') as f:f.write(raw)
a=obj(BASE/'acceptance.json');c=obj(BASE/'replay_contract.json');archive=a['archive'];native=a['native_status'] or {};r=a['result'];receipt=a['receipt'] or {}
lines=['# 固定第5步检查点独立时段对照结果','',f"技术状态：**{a['status']}**；科学九门槛：**{None if a['nine_gates'] is None else a['nine_gates']['all_pass']}**；额外状态代理判读：**{a['classification']}**。",'',f"作业{a['job_id']}：{native.get('State')} / {native.get('ExitCode')}；原生耗时{native.get('ElapsedRaw')}秒，预算900秒。",'', '## 固定范围','', '流域02092500、训练种子20260922，冻结父作业245850两个第5步检查点。训练期1999-10-01至2006-09-30；评分期2006-10-01至2008-09-30。前置695天共同历史用于预热，评分期不重置记忆。', '这是既有开发验证期的时间外对照，不是从未用于开发的全新测试集。每个发行日只用当日及过去流量同化；预报使用已知未来气象强迫。两个网络权重全程冻结。','', '唯一一次独立审核PASS；固定窗口、原九门槛、mask生成方法和预算在执行前绑定SHA。','']
if a['status']=='ACCEPTED_HOLDOUT_ARTIFACTS':
    o=a['computed_scores']['original'];m=a['computed_scores']['state_constrained'];g=a['nine_gates'];e=a['evidence'];names=['all_mse','all_mae','low_mse','low_mae','middle_mse','middle_mae','high_mse','high_mae','state_proxy']
    lines+=['## 固定窗口九项结果','', '| 指标 | 原版step5 | MIX step5 | MIX减原版 | 相对变化 | 原上限 | 通过 |','|---|---:|---:|---:|---:|---:|:---:|']
    rows=[]
    for i,name in enumerate(names):
        delta=m[i]-o[i];percent=None if o[i]==0 else 100*delta/o[i];percent_text='原版为0，未定义' if percent is None else f'{percent:+.8g}%'
        lines.append(f'| {name} | {o[i]:.14g} | {m[i]:.14g} | {delta:+.9g} | {percent_text} | {g["limits"][i]:.14g} | {g["passed"][i]} |')
        rows.append(dict(metric=name,original=o[i],mix=m[i],difference=delta,relative_change_percent=percent,limit=g['limits'][i],passed=g['passed'][i]))
    stream=io.StringIO();w=csv.DictWriter(stream,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows);create('固定窗口九项对照.csv',stream.getvalue())
    bad=[names[i] for i in range(9) if m[i]>o[i]];failed=[names[i] for i in g['failed_indices']]
    lines+=['',f"状态mask事件{e['state_mask_events']}个；四个流量组计数{e['flow_group_counts']}。每臂728个发行日、2184个lead1/2/3误差事件。",f"S改善量（原版减MIX）={e['state_improvement']:.12g}；原数值容差={e['state_numerical_tolerance']:.12g}。超过数值容差不等于统计显著。",'', '## 全部不利项与适用范围','',f"相对原版数值变差的指标：{bad or '无'}；未通过原门槛的指标：{failed or '无'}。原九门槛保持原数值，没有按结果调参。", 'S是固定暖天、未训练参考轨迹先验无雪条件下的正向积雪修正惩罚，不是实测积雪误差。没有观测雪量真值、跨流域或多种子证据；本轮只评价两个短程训练检查点。', '预热允许两臂产生各自的水文状态与递归记忆；相同的是历史输入和起始物理状态，不是强行把其状态轨迹设为相同。','', '## 实际预算和保存数组验收','',f"实际计数：{json.dumps(r['counters'],ensure_ascii=False)}。本次新增训练更新、autograd和QP均为0。",f"三条轨迹耗时（秒）：{json.dumps({k:v['wall_seconds'] for k,v in r['trajectories'].items()})}。参考轨迹只生成mask，不做候选选择。", '逐项核验两份step5源SHA、评估后完整网络张量与输入检查点完全相同、三条轨迹1426日状态/实际修正、同一固定mask、训练分组阈值、发行日与目标日边界，以及float64独立九指标复算。验收不运行模型、梯度或QP。']
    summaries=e['state_summaries'];create('状态描述摘要.json',summaries)
    lines+=['','## 保存状态的描述性摘要','','三条轨迹使用同一个参考mask；下列是评分期首日和末日后验雪状态以及731日分布，仅作描述，不增加或替换科学门槛。11个状态分量的起始物理值、评分期先验/后验首末值、最小/最大/均值和5%/50%/95%分位数完整保存于状态描述摘要.json。','','| 轨迹 | mask数量 | 首日后验雪 | 末日后验雪 | 后验雪5% | 后验雪50% | 后验雪95% |','|---|---:|---:|---:|---:|---:|---:|']
    for label,summary in summaries.items():
        post=summary['posterior'];q=post['quantiles']
        lines.append(f"| {label} | {summary['mask_events']} | {post['first'][0]:.12g} | {post['last'][0]:.12g} | {q[0][0]:.12g} | {q[1][0]:.12g} | {q[2][0]:.12g} |")
    if g['all_pass'] and a['classification']=='STATE_PROXY_IMPROVEMENT':advice='这次支持该既有验证期内的代理收益保持。下一步再冻结小规模多种子或更独立时段复核；真实积雪精度需要可核验的观测，不凭此扩大结论。'
    elif not g['all_pass']:advice='原九项门槛没有全部通过，先利用已保存逐日数组定位流量分组及季节上的代价；保留失败，不换检查点、不调整mask或容差。依据诊断另行制定并审核后续方案。'
    else:advice='原门槛通过但没有检测到额外S收益；先用保存轨迹定位训练期收益为何未保持，再决定是否值得继续。'
else:
    lines+=['## 未完成与失败证据','',json.dumps(dict(receipt=receipt,result=r),ensure_ascii=False,indent=2)]
    advice='本轮技术证据不完整，保持失败原状，先定位明确原因；不据此宣称科学通过，不自动重提科学作业。'
failures=[]
for p in sorted((BASE/'monitoring').glob('*result.json')):
    x=obj(p)
    if x.get('status')=='MONITOR_FAILED':failures.append({k:v for k,v in x.items() if k!='current_status'})
lines+=['',f"归档：{archive['files']}文件，{archive['archive_bytes']}字节；分片、总包、逐文件SHA核验通过。SHA256：`{archive['archive_sha256']}`。",f"控制器墙钟上界{receipt.get('wall_seconds_upper')}秒，RSS峰值{receipt.get('combined_rss_peak_bytes')}字节；单CPU实际亲和性{receipt.get('affinity')}。",f"监控异常窗口完整保留：{json.dumps(failures,ensure_ascii=False)}。",'', '## 下一步建议','',advice,'','后续科学实验未执行。旧实验及共享receiver保持原状。','', '白话总结：把两份第5步权重锁住后比较训练之外的同一段时间；是否有收益，以这份报告的原九门槛和S差值分别判断。','']
create('运行报告.md','\n'.join(lines));registry=obj(BASE/'registry_frozen.json');registry.update(status=a['status'],job_id=a['job_id'],scientific_nine_gates=None if a['nine_gates'] is None else a['nine_gates']['all_pass'],classification=a['classification'],report='运行报告.md');create('registry_final.json',registry)
(BASE/'active_execution.json').write_text(json.dumps(dict(status='ACCEPTANCE_COMPLETE',job_id=a['job_id'],pending_queries=[],report='运行报告.md',classification=a['classification']),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
create('START_HERE.md',f"# SC-HOLDOUT5-01已验收\n\n先读运行报告.md、acceptance.json、registry_final.json；若delivery.json存在，不重复交付。\n")
print(json.dumps(dict(status='REPORT_WRITTEN',report=str(BASE/'运行报告.md'),classification=a['classification']),ensure_ascii=False))
