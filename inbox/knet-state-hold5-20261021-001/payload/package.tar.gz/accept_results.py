"""Independent saved-array acceptance; never invoke a model, gradient or QP."""
from pathlib import Path
import json,hashlib,datetime
import numpy as np
import torch
BASE=Path(__file__).resolve().parent;HPC=BASE/'hpc_results';RUN=HPC/'runs/02092500/attempt_001'
def obj(p):return json.loads(p.read_bytes())
def arr(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def state_summary(data,warm):
    summary=dict(mask_events=int(data['state_mask'].sum()),component_indices=list(range(11)),distribution_period='731 scoring days only',shared_initial_state=data['initial_state'].reshape(-1).tolist())
    for name,key in [('prior','prior_states'),('posterior','posterior_states')]:
        states=data[key][warm:,0,:]
        summary[name]=dict(first=states[0].tolist(),last=states[-1].tolist(),minimum=states.min(axis=0).tolist(),maximum=states.max(axis=0).tolist(),mean=states.mean(axis=0).tolist(),quantile_probabilities=[.05,.5,.95],quantiles=np.quantile(states,[.05,.5,.95],axis=0,method='linear').tolist())
    return summary
identity=obj(BASE/'execution_identity.json');archive=obj(BASE/'collection/verified.json');manifest=obj(HPC/'collection_manifest.json');contract=obj(HPC/'replay_contract.json')
assert archive['status']=='FULL_ARCHIVE_HASH_VERIFIED' and archive['job_id']==identity['job_id'] and manifest['identity']==identity
assert sha(HPC/'replay_contract.json')==identity['contract_sha256']==sha(BASE/'replay_contract.json')
for row in manifest['files']:
    path=HPC/row['path'];assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256']
for row in obj(HPC/'deployment_manifest.json')['files']:assert sha(HPC/row['path'])==row['sha256']
for row in contract['input_bindings']:assert sha(HPC/row['path'])==sha(BASE/row['path'])==row['sha256']
native_rows=manifest['native_status'].get('native_job_row',[]);native=native_rows[0] if len(native_rows)==1 else None
receipt=obj(RUN/'receipt.json') if (RUN/'receipt.json').exists() else None
result=obj(RUN/'result.json') if (RUN/'result.json').exists() else None
complete=bool(result and result['status']=='HOLDOUT_COMPLETE');computed={};gate=None;classification='INCOMPLETE';evidence={}
if complete:
    assert native and native['JobID']==identity['job_id'] and native['State']=='COMPLETED' and native['ExitCode']=='0:0'
    assert receipt['status']=='COMPLETED' and receipt['exit_code']==0 and receipt['startup_admission_verified']
    assert int(native['ElapsedRaw'])<=900 and receipt['wall_seconds_upper']<=890 and receipt['budget_pass']
    assert receipt['combined_rss_peak_bytes']<=6*1024**3 and receipt['system_free_min_bytes']>=2*1024**3 and len(receipt['affinity'])==1
    assert result['total_optimizer_calls']==receipt['total_optimizer_calls']==0 and result['total_effective_nonzero_steps']==0
    assert result['counters']==dict(filter_trajectories=3,filter_days=4278,forecast_batches=2,forecast_events=4368,optimizer_calls=0,autograd_calls=0,qp_calls=0)
    snapshot=arr(HPC/'inputs/input_snapshot.npz');shared=arr(RUN/'shared_arrays.npz');start=1862;score_start=2557;end=3288;warm=695
    for key in ['observations','forcing','dates_ns','thresholds']:np.testing.assert_array_equal(shared[key],snapshot[key])
    np.testing.assert_array_equal(shared['initial_state'],snapshot['training_open_loop'][1861])
    np.testing.assert_array_equal(shared['previous_observation'].reshape(-1),snapshot['observations'][1861:1862])
    np.testing.assert_array_equal(shared['filter_global_indices'],np.arange(1862,3288));np.testing.assert_array_equal(shared['score_global_indices'],np.arange(2557,3288))
    dates=shared['dates_ns'].astype('datetime64[ns]').astype('datetime64[D]');assert str(dates[2557])=='2006-10-01' and str(dates[-1])=='2008-09-30'
    issues=np.arange(2557,3285);targets=issues[:,None]+np.arange(1,4)
    np.testing.assert_array_equal(shared['issue_indices'],issues);np.testing.assert_array_equal(shared['target_indices'],targets)
    truth=snapshot['observations'][targets];np.testing.assert_array_equal(shared['target'],truth)
    q50,q90=np.quantile(snapshot['observations'][:2557],[.5,.9],method='linear');np.testing.assert_array_equal(shared['thresholds'][:2],[q50,q90])
    groups=[np.ones(truth.shape,dtype=bool),truth<=q50,(truth>q50)&(truth<=q90),truth>q90];counts=[int(g.sum()) for g in groups];assert all(counts) and counts[0]==2184
    initial=torch.load(HPC/'inputs/initial.pt',weights_only=True,map_location='cpu');scale=float(initial['network']['state_feature_scale'][0,0]);assert float(shared['snow_scale'])==scale
    reference=arr(RUN/'mask_reference_trace.npz');mask=(snapshot['forcing'][2557:3288,0,1]>=float(shared['temperature_threshold']))&(reference['prior_states'][warm:,0,0]<=0)
    assert mask.any() and mask.shape==(731,)
    arrays={};state_summaries={}
    for label in ['mask_reference','original','state_constrained']:
        data=reference if label=='mask_reference' else arr(RUN/label/'evaluation.npz');arrays[label]=data
        prior=data['prior_states'];post=data['posterior_states'];assert prior.shape==post.shape==(1426,1,11)
        assert np.isfinite(prior).all() and np.isfinite(post).all() and data['valid_updates'].shape==(1426,) and data['valid_updates'].all()
        np.testing.assert_array_equal(data['corrections'],post-prior);np.testing.assert_array_equal(data['state_mask'],mask)
        proxy=np.maximum(post[warm:,0,0]-prior[warm:,0,0],0)/scale;np.testing.assert_array_equal(data['state_proxy_values'],proxy)
        for key in ['initial_state','previous_observation']:np.testing.assert_array_equal(data[key],shared[key])
        cp=initial if label=='mask_reference' else torch.load(HPC/f'inputs/{label}_step5.pt',weights_only=True,map_location='cpu')
        after=torch.load(RUN/(label+'_network_after.pt'),weights_only=True,map_location='cpu')
        assert after.keys()==cp['network'].keys() and all(torch.equal(after[k],v) for k,v in cp['network'].items())
        proof=obj(RUN/(label+'_frozen_weights.json'));assert proof==result['trajectories'][label]
        assert proof['state_dict_sha_before']==proof['state_dict_sha_after'] and proof['parameter_sha_before']==proof['parameter_sha_after'] and proof['parameters_require_grad'] is False
        assert proof['filter_days']==1426 and proof['score_days']==731
        state_summaries[label]=state_summary(data,warm)
        if label!='mask_reference':
            assert cp['epoch']==cp['optimizer_calls']==cp['optimizer_steps']==5
            assert cp['parameter_sha256']==proof['parameter_sha_before']
            np.testing.assert_array_equal(data['issue_indices'],issues);np.testing.assert_array_equal(data['target_indices'],targets);np.testing.assert_array_equal(data['target'],truth)
            pred=data['prediction'];assert pred.shape==(728,3) and np.isfinite(pred).all()
            errors=pred.astype(np.float64)-truth.astype(np.float64);values=[]
            for group in groups:values.extend([float(np.mean(errors[group]**2)),float(np.mean(np.abs(errors[group])))])
            values.append(float(np.mean(proxy[mask]**2)));values=np.asarray(values)
            np.testing.assert_allclose(values,data['scores'],rtol=1e-12,atol=1e-14);np.testing.assert_allclose(values,result['metrics'][label]['scores'],rtol=1e-12,atol=1e-14)
            assert result['metrics'][label]['group_counts']==counts and result['metrics'][label]['state_events']==int(mask.sum())
            computed[label]=values.tolist()
    original=np.asarray(computed['original']);mixed=np.asarray(computed['state_constrained']);tolerance=np.maximum(1e-10,1e-7*np.abs(original));limits=np.r_[original[:8]*1.001+tolerance[:8],original[8]+tolerance[8]]
    passing=mixed<=limits;gate=dict(all_pass=bool(passing.all()),passed=passing.tolist(),limits=limits.tolist(),numerical_tolerances=tolerance.tolist(),failed_indices=np.flatnonzero(~passing).tolist())
    reported=result['nine_gates'];assert reported['accepted']==gate['all_pass'] and reported['failed_flow_indices']==[x for x in gate['failed_indices'] if x<8] and reported['state_gate_pass']==bool(passing[8])
    np.testing.assert_array_equal(reported['flow_limits'],limits[:8]);assert reported['state_limit']==limits[8]
    delta=float(original[8]-mixed[8]);assert delta==result['state_improvement'] and (delta>tolerance[8])==result['state_improvement_exceeds_tolerance']
    classification='STATE_PROXY_IMPROVEMENT' if delta>tolerance[8] else 'STATE_PROXY_WORSENING' if delta < -tolerance[8] else 'NO_DETECTED_STATE_PROXY_CHANGE'
    evidence=dict(state_mask_events=int(mask.sum()),flow_group_counts=counts,network_tensors_before_after_exact=True,shared_initial_state_and_history=True,training_validation_disjoint=True,target_indices_causal=True,known_future_forcing=True,three_trajectories_verified=True,score_period=['2006-10-01','2008-09-30'],state_improvement=delta,state_numerical_tolerance=float(tolerance[8]),predictions_exact_equal=bool(np.array_equal(arrays['original']['prediction'],arrays['state_constrained']['prediction'])))
    evidence['state_summaries']=state_summaries
acceptance=dict(status='ACCEPTED_HOLDOUT_ARTIFACTS' if complete else 'TECHNICALLY_INCOMPLETE',family='SC-HOLDOUT5-01',job_id=identity['job_id'],native_status=native,receipt=receipt,result=result,nine_gates=gate,computed_scores=computed,classification=classification,evidence=evidence,archive=archive,independent_review_rounds=1,acceptance_model_calls=0,acceptance_qp_calls=0,scope=contract['scope'],accepted_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
with (BASE/'acceptance.json').open('x',encoding='utf-8') as f:json.dump(acceptance,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({k:acceptance[k] for k in ['status','job_id','nine_gates','classification']},ensure_ascii=False))
