"""Three bounded causal filtering trajectories with frozen checkpoint weights."""
import os,sys,io,json,hashlib,time,datetime,traceback
from pathlib import Path
BASE=Path(__file__).resolve().parent
OUT='runs/02092500/attempt_001'
COUNTERS=dict(filter_trajectories=0,filter_days=0,forecast_batches=0,forecast_events=0,optimizer_calls=0,autograd_calls=0,qp_calls=0)

def main():
    import safe_io as s
    assert os.environ.get('SLURM_JOB_ID','').isdigit()
    assert json.loads(sys.stdin.readline())['resources_configured']
    raw=s.read_checked(BASE/'replay_contract.json');contract=json.loads(raw)
    auth=json.loads(s.read_checked(BASE/'execution_authorization.json'));assert auth['status']=='AUTHORIZED'
    for row in auth['files']:s.read_checked(BASE/row['path'],row['sha256'])
    assert contract['maximum_total_optimizer_calls']==contract['maximum_autograd_calls']==contract['maximum_qp_calls']==0
    template=BASE.parents[1]/'template'
    manifest=json.loads(s.read_checked(template/'bundle_manifest.json',auth['template_manifest_sha256']))
    for row in manifest['files']:s.read_checked(template/row['path'],row['sha256'])
    import numpy as np
    import torch
    from evaluation_math import scores,forecast_indices,candidate_gate
    torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    began=time.monotonic()
    os.chdir(template);sys.path.insert(0,str(template/'recipe'));os.environ['KNET_BASIN']='04105700'
    import common as C
    known={'basin_02092500.npz':'453d57eab87b0d774d5895f143d51c40644f9b92fd8702ce646a6f4841378eb6','basin_02092500.json':'1d888ac7e396def5d6d435574ad4af91a8adb89bf17845c87f15c5a2f2f4b0a3'}
    registered={}
    for entry in json.loads(s.read_checked(template/'recipe/evaluation_sources.json'))['files']:
        source=Path(entry['path']);assert not source.is_absolute() and '..' not in source.parts
        path=(template/source).resolve();name=path.name
        if name not in known:continue
        assert path.is_relative_to(template/'recipe/workspace/results') and entry['sha256']==known[name]
        key=str(path).lower()
        if key in C.DIGESTS:assert C.DIGESTS[key]==entry['sha256']
        C.DIGESTS[key]=entry['sha256'];registered[name]=entry['sha256']
    assert registered==known
    from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
    from global_hydrology.experiments import daily_camels_ukf_knet_parity_runner as parity
    from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
    from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import AccessLedger,CAUSAL_SHARED_SPINUP_MODE
    def arr(x):return x.detach().cpu().numpy().copy()
    def put(name,x):return s.create(OUT+'/'+name,x)
    def np_save(name,x):
        stream=io.BytesIO();np.savez_compressed(stream,**x);return put(name,stream.getvalue())
    def emit(event,**kwargs):
        print(json.dumps(dict(event=event,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-began,total_optimizer_calls=0,total_effective_nonzero_steps=0,**kwargs)),flush=True)
    bindings={row['path']:row for row in contract['input_bindings']}
    def read_input(name):return s.read_checked(BASE/name,bindings[name]['sha256'])
    initial=torch.load(io.BytesIO(read_input('inputs/initial.pt')),weights_only=True,map_location='cpu')
    assert initial['epoch']==initial['optimizer_steps']==0 and not initial['optimizer']['state']
    with np.load(io.BytesIO(read_input('inputs/input_snapshot.npz')),allow_pickle=False) as z:snapshot={k:z[k].copy() for k in z.files}
    runtime=per.load_per_basin_development_runtime(get_development_basin_specification('02092500'),ledger=AccessLedger(),initialization_mode=CAUSAL_SHARED_SPINUP_MODE,device='cpu')
    assert runtime.training_days==2557 and len(runtime.dates)==3288 and runtime.context.dimension==11
    for key,value in [('observations',arr(runtime.observations).reshape(-1)),('forcing',arr(runtime.forcing)),('dates_ns',runtime.dates.astype('datetime64[ns]').astype('int64'))]:np.testing.assert_array_equal(value,snapshot[key])
    thresholds=snapshot['thresholds'];np.testing.assert_array_equal(thresholds,np.quantile(snapshot['observations'][:2557],[.5,.9,.99],method='linear'))
    scales=parity.FeatureScales(observation_feature_scale=initial['network']['observation_feature_scale'].clone(),state_feature_scale=initial['network']['state_feature_scale'].clone(),fit_start_index=0,fit_end_exclusive=2557,floor=.1)
    per.fit_training_feature_scales=lambda r,*,floor=.1:scales
    start=contract['filter_start'];score_start=contract['score_start'];end=contract['score_end_exclusive'];warm=score_start-start
    assert (start,score_start,end,warm)==(1862,2557,3288,695)
    physical_initial=torch.as_tensor(snapshot['training_open_loop'][start-1],dtype=runtime.context.dtype).clone()
    previous=runtime.observations[start-1:start].clone();issues,targets=forecast_indices(score_start,end)
    assert targets.shape==(728,3) and targets.min()>2556 and targets.max()==3287
    TT=float(runtime.context.plain_model.params['parTT']);snow_scale=float(scales.state_feature_scale[0,0]);assert snow_scale>0
    shared=dict(filter_global_indices=np.arange(start,end),score_global_indices=np.arange(score_start,end),issue_indices=issues,target_indices=targets,target=snapshot['observations'][targets],dates_ns=snapshot['dates_ns'],observations=snapshot['observations'],forcing=snapshot['forcing'],thresholds=thresholds,initial_state=arr(physical_initial),previous_observation=arr(previous),temperature_threshold=np.asarray(TT),snow_scale=np.asarray(snow_scale))
    np_save('shared_arrays.npz',shared)
    records={};mask=None;metric_records={};buffer_digest=None
    for label in contract['trajectory_order']:
        assert COUNTERS['filter_trajectories']<3
        cp=initial if label=='mask_reference' else torch.load(io.BytesIO(read_input(f'inputs/{label}_step5.pt')),weights_only=True,map_location='cpu')
        if label!='mask_reference':
            assert cp['epoch']==cp['optimizer_steps']==cp['optimizer_calls']==5
            assert cp['parameter_sha256']==bindings[f'inputs/{label}_step5.pt']['parameter_sha256']
            assert cp['contract_sha256']==contract['parent_contract_sha256']
        net=per.build_exact_dimension_kalman_net(runtime,zero_gain=False,seed=contract['seed'],gain_initialization='near_zero_fc2_head',hidden=24,input_multiplier=10,output_multiplier=10,feature_scale_floor=.1,normalized_feature_guard=10.,correction_cap_in_state_scale_units=3.)
        net.load_state_dict(cp['network'],strict=True);net.eval()
        for parameter in net.parameters():parameter.requires_grad_(False)
        before=C.helpers.digest_tree(net.state_dict());parameter_before=parity.parameter_sha256(net)
        if label!='mask_reference':assert parameter_before==cp['parameter_sha256']
        current_buffer=C.helpers.digest_tree(dict(net.named_buffers()))
        if buffer_digest is None:buffer_digest=current_buffer
        assert current_buffer==buffer_digest
        context=parity._context_with_initial_state(runtime.context,physical_initial.clone())
        batch=parity.WindowBatch(purpose='frozen_holdout',global_start=start,global_end_exclusive=end,context=context,forcing=runtime.forcing[start:end],observations=runtime.observations[start:end],dates=runtime.dates[start:end],initial_state=physical_initial.clone(),issue_start_local=warm,issue_end_local=len(runtime.dates[start:end])-3)
        native=net.analysis_step;day=0;initial_memory={};run_start=time.monotonic()
        def observed(y,u):
            nonlocal day,initial_memory
            assert not torch.is_grad_enabled() and all(not q.requires_grad for q in net.parameters())
            if day==0:
                np.testing.assert_array_equal(arr(net.m1x_posterior),arr(physical_initial))
                initial_memory={k:C.helpers.digest_tree(getattr(net,k)) for k in C.probe.RECURRENCE_FIELDS}
            np.testing.assert_array_equal(arr(y).reshape(-1),snapshot['observations'][start+day:start+day+1])
            post=native(y,u);day+=1;COUNTERS['filter_days']+=1
            assert COUNTERS['filter_days']<=4278
            if day%32==0 or day==end-start:emit('validation_day_progress',arm=label,days=day,total=end-start,phase='warmup' if day<=warm else 'scoring',global_day=start+day-1)
            return post
        net.analysis_step=observed
        with torch.no_grad():trace=parity.run_knet_filter(net,batch,previous_observation=previous.clone())
        assert day==end-start==1426 and trace.valid_updates.all()
        COUNTERS['filter_trajectories']+=1
        prior=arr(trace.prior_states);post=arr(trace.posterior_states);correction=arr(trace.corrections)
        assert np.isfinite(prior).all() and np.isfinite(post).all()
        np.testing.assert_array_equal(correction,post-prior)
        proxy=np.maximum(correction[warm:,0,0],0)/snow_scale
        if label=='mask_reference':
            mask=(snapshot['forcing'][score_start:end,0,1]>=TT)&(prior[warm:,0,0]<=0)
            if not mask.any():raise ValueError('UNRESOLVED_EMPTY_STATE_MASK')
        arrays=dict(prior_states=prior,posterior_states=post,corrections=correction,requested_corrections=arr(trace.requested_corrections),valid_updates=arr(trace.valid_updates),state_proxy_values=proxy,state_mask=mask.copy(),initial_state=arr(physical_initial),previous_observation=arr(previous))
        if label!='mask_reference':
            assert COUNTERS['forecast_batches']<2
            with torch.no_grad():raw_forecasts=runtime.tukf06_module.multilead_torch(context.plain_model,trace.posterior_states[warm:,0,:],runtime.forcing[score_start:end])
            for lead in (1,2,3):np.testing.assert_array_equal(arr(raw_forecasts[lead][1])[:728],np.arange(lead,lead+728))
            prediction=np.stack([arr(raw_forecasts[k][0])[:728] for k in (1,2,3)],axis=1)
            values,counts=scores(prediction,shared['target'],proxy,mask,thresholds)
            COUNTERS['forecast_batches']+=1;COUNTERS['forecast_events']+=prediction.size
            arrays.update(prediction=prediction,target=shared['target'],issue_indices=issues,target_indices=targets,scores=values)
            metric_records[label]=dict(scores=values.tolist(),group_counts=counts,state_events=int(mask.sum()))
        after=C.helpers.digest_tree(net.state_dict());parameter_after=parity.parameter_sha256(net)
        assert before==after and parameter_before==parameter_after and C.helpers.digest_tree(dict(net.named_buffers()))==buffer_digest
        stream=io.BytesIO();torch.save({k:v.detach().cpu().clone() for k,v in net.state_dict().items()},stream)
        put(label+'_network_after.pt',stream.getvalue())
        identity=np_save(('mask_reference_trace.npz' if label=='mask_reference' else label+'/evaluation.npz'),arrays)
        records[label]=dict(state_dict_sha_before=before,state_dict_sha_after=after,parameter_sha_before=parameter_before,parameter_sha_after=parameter_after,buffers_sha256=buffer_digest,parameters_require_grad=False,initial_memory_hashes=initial_memory,checkpoint_epoch=cp['epoch'],filter_days=day,score_days=731,wall_seconds=time.monotonic()-run_start,arrays=identity)
        put(label+'_frozen_weights.json',records[label]);emit('phase_complete',arm=label,phase='frozen_evaluation',days=day)
        del trace,net
    assert COUNTERS==dict(filter_trajectories=3,filter_days=4278,forecast_batches=2,forecast_events=4368,optimizer_calls=0,autograd_calls=0,qp_calls=0)
    for name,binding in bindings.items():s.read_checked(BASE/name,binding['sha256'])
    gate=candidate_gate(metric_records['state_constrained']['scores'],metric_records['original']['scores'])
    improvement=metric_records['original']['scores'][8]-metric_records['state_constrained']['scores'][8]
    result=dict(status='HOLDOUT_COMPLETE',family=contract['family'],job_id=os.environ['SLURM_JOB_ID'],basin='02092500',metrics=metric_records,trajectories=records,counters=COUNTERS,total_optimizer_calls=0,total_effective_nonzero_steps=0,nine_gates=gate,state_improvement=improvement,state_improvement_exceeds_tolerance=bool(improvement>gate['numerical_tolerances'][8]),scope=contract['scope'],failure=None)
    put('result.json',result);print('HOLDOUT_RESULT='+json.dumps(result),flush=True)
    return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as exc:
        import safe_io as s
        failure=dict(status='HOLDOUT_FAILED',family='SC-HOLDOUT5-01',job_id=os.environ.get('SLURM_JOB_ID'),total_optimizer_calls=0,total_effective_nonzero_steps=0,counters=COUNTERS,error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc())
        if not (BASE/OUT/'result.json').exists():s.create(OUT+'/result.json',failure)
        print('HOLDOUT_FAILURE='+json.dumps(failure),flush=True)
        raise
