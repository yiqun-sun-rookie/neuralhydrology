"""Own-job training controller with native admission and same-node clock."""
import os, sys, json, time, threading, datetime, subprocess, re, signal, hashlib, traceback
from pathlib import Path
import psutil
import safe_io as s
from replay_protocol import process_start_lower, batch_elapsed, progress_key

BASE = Path(__file__).resolve().parent
OUT = "runs/02092500/attempt_001"


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def boot():
    return time.clock_gettime(time.CLOCK_BOOTTIME)


def main():
    child = None
    stop = error = result = clock = None
    chunks = []
    peak = 0
    minimum = None
    cpu = 0.
    wall = None
    proc = psutil.Process()
    job = os.environ["SLURM_JOB_ID"]
    node = os.uname().nodename
    raw = s.read_checked(BASE / "replay_contract.json")
    contract = json.loads(raw)
    sha = hashlib.sha256(raw).hexdigest()
    limits = contract["resource_limits"]
    assert not (BASE / OUT).exists()
    assert job.isdigit() and not os.environ.get("SLURM_ARRAY_TASK_ID")
    latest = None
    progress = {}
    regressions = []
    lock = threading.Lock()
    answered = {}
    acknowledged = None
    admitted = False
    reader = None
    worker_start_lower = None
    interrupted = []
    try:
        shell = int(os.environ["HPC_BATCH_SHELL_PID"])
        assert shell in [proc.pid] + [p.pid for p in proc.parents()]
        hz = os.sysconf("SC_CLK_TCK")
        origin = process_start_lower(s.read_checked(Path("/proc")/str(shell)/"stat").decode(), hz)

        def elapsed():
            return batch_elapsed(boot(), origin, hz)

        clock = dict(source="batch shell ticks / same-node CLOCK_BOOTTIME",
                     shell_pid=shell, start_lower_boottime_seconds=origin,
                     ticks_per_second=hz, node=node,
                     boot_id=s.read_checked(Path("/proc/sys/kernel/random/boot_id")).decode().strip())
        s.create(OUT + "/batch_clock.json", clock)
        details = subprocess.run(["scontrol", "-d", "show", "job", job],
                                 capture_output=True, text=True, timeout=15)
        s.create(OUT + "/scheduler_before_worker.json",
                 dict(returncode=details.returncode, stdout=details.stdout, stderr=details.stderr))
        assert details.returncode == 0
        fields = dict(re.findall(r"(\w+)=([^\s]+)", details.stdout))
        assert fields["JobId"] == job and fields["Command"] == str(BASE/"replay.slurm")
        assert fields["WorkDir"] == str(BASE) and fields["NodeList"] == node
        assert fields["JobState"] == "RUNNING"
        clock.update(raw_runtime=fields.get("RunTime"), raw_start=fields.get("StartTime"))
        allocated = set()
        for entry in re.findall(r"CPU_IDs=([0-9,-]+)", details.stdout):
            for item in entry.split(","):
                if "-" in item:
                    a, b = map(int, item.split("-"))
                    allocated.update(range(a, b+1))
                else:
                    allocated.add(int(item))
        eligible = sorted(allocated.intersection(proc.cpu_affinity()))
        assert eligible
        proc.cpu_affinity([eligible[0]])
        proc.nice(10)
        controller = dict(utc=now(), pid=proc.pid, creation_time=proc.create_time(),
                          job_id=job, node=node, contract_sha256=sha, clock=clock,
                          affinity=proc.cpu_affinity(), worker_pid=None)
        s.create(OUT + "/controller_started.json", controller)

        def sample():
            nonlocal peak, minimum, cpu
            processes = [proc]
            if child is not None and child.poll() is None:
                processes += [child] + child.children(recursive=True)
                ct = child.cpu_times()
                cpu = ct.user + ct.system
            rss = sum(p.memory_info().rss for p in processes)
            available = psutil.virtual_memory().available
            peak = max(peak, rss)
            minimum = available if minimum is None else min(minimum, available)
            return dict(child_cpu_seconds=cpu, combined_rss_bytes=rss,
                        free_bytes=available, affinity=proc.cpu_affinity())

        def check_resource(resource):
            if resource["combined_rss_bytes"] > limits["combined_rss_limit_bytes"]:
                return "RSS_LIMIT"
            if resource["free_bytes"] < limits["minimum_free_bytes"]:
                return "SYSTEM_FREE_LIMIT"
            if elapsed()[1] >= limits["work_cutoff_seconds"]:
                return "REMAINING_WALL_BUDGET"
            if interrupted:
                return "EXTERNAL_SIGNAL"
            return None

        def exchange(phase, resource):
            nonlocal acknowledged
            for path in sorted((BASE/"monitor_exchange").glob("monitor_request_*.json")):
                if path.name in answered:
                    continue
                request = json.loads(s.read_checked(path))
                nonce = request["nonce"]
                try:
                    assert re.fullmatch("[0-9a-f]{32}", nonce)
                    assert path.name == "monitor_request_"+nonce+".json"
                    assert request["job_id"] == job and request["contract_sha256"] == sha
                    with lock:
                        event = latest
                        items = list(progress.values())
                        bad = list(regressions)
                    response = dict(nonce=nonce, job_id=job, node=node,
                                    controller_pid=proc.pid,
                                    worker_pid=None if child is None else child.pid,
                                    contract_sha256=sha, utc=now(), phase=phase,
                                    batch_elapsed_upper_seconds=elapsed()[1],
                                    progress_age_upper_seconds=None if event is None else boot()-(worker_start_lower+event["elapsed_seconds"]),
                                    resource_age_upper_seconds=0.,
                                    latest_progress=event, progress_by_phase=items,
                                    progress_regressions=bad, resource=resource,
                                    optimizer_calls=None if event is None else event.get('total_optimizer_calls'), effective_nonzero_steps=None if event is None else event.get('total_effective_nonzero_steps'))
                    s.create(OUT+"/monitor_response_"+nonce+".json", response)
                    s.create(OUT+"/exchange_event_"+nonce+".json",
                             dict(request_seen=True, response_saved=True, utc=now(), phase=phase))
                    answered[path.name] = nonce
                except BaseException as exc:
                    s.create(OUT+"/exchange_error_"+nonce+".json",
                             dict(error=repr(exc), utc=now()))
                    raise
            if phase == "WAITING_FOR_HANDSHAKE":
                for nonce in answered.values():
                    ack_path = BASE/"monitor_exchange"/("start_allowed_"+nonce+".json")
                    if ack_path.exists():
                        ack = json.loads(s.read_checked(ack_path))
                        assert ack["nonce"] == nonce and ack["job_id"] == job
                        assert ack["contract_sha256"] == sha and ack["controller_pid"] == proc.pid
                        assert ack["response_sha256"] == hashlib.sha256(
                            s.read_checked(BASE/OUT/("monitor_response_"+nonce+".json"))).hexdigest()
                        acknowledged = nonce
                        return

        def interrupt(signum, frame):
            interrupted.append(signum)
            if child is not None and child.poll() is None:
                child.terminate()

        signal.signal(signal.SIGTERM, interrupt)
        signal.signal(signal.SIGINT, interrupt)
        resource = sample()
        stop = check_resource(resource)
        if stop:
            raise RuntimeError(stop)
        s.create(OUT+"/startup_admission.json",
                 dict(status="NATIVE_IDENTITY_AND_RESOURCES_VERIFIED", job_id=job, node=node,
                      controller_pid=proc.pid, contract_sha256=sha, resource=resource,
                      telemetry_ack_required=False, telemetry_handshake_confirmed=False,
                      utc=now()))
        admitted = True
        child = psutil.Popen([sys.executable, "-u", "-B", str(BASE/"replay_worker.py")],
                             cwd=str(BASE), stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        child.cpu_affinity(proc.cpu_affinity())
        child.nice(10)
        worker_start_lower = process_start_lower(
            s.read_checked(Path("/proc")/str(child.pid)/"stat").decode(), hz)
        worker = dict(utc=now(), pid=child.pid, creation_time=child.create_time(),
                      job_id=job, node=node, contract_sha256=sha,
                      start_lower_boottime_seconds=worker_start_lower,
                      affinity=child.cpu_affinity(), controller_pid=proc.pid)
        s.create(OUT+"/scientific_started.json", worker)

        def consume():
            nonlocal latest
            for line in iter(child.stdout.readline, b""):
                chunks.append(line)
                try:
                    record = json.loads(line)
                except (ValueError, UnicodeDecodeError):
                    print(line.decode(errors="replace").rstrip(), flush=True)
                    continue
                if isinstance(record, dict):
                    record.update(observed_boottime=boot(), job_id=job, worker_pid=child.pid, node=node)
                    key = progress_key(record)
                    if key:
                        with lock:
                            previous = progress.get(key[:2])
                            if previous is not None and key[2] < progress_key(previous)[2]:
                                regressions.append(record)
                            if previous is None or key[2] > progress_key(previous)[2]:
                                latest = record
                                progress[key[:2]] = record
                print(json.dumps(record), flush=True)

        reader = threading.Thread(target=consume, daemon=True)
        reader.start()
        child.stdin.write(b'{"resources_configured":true}\n')
        child.stdin.flush()
        child.stdin.close()
        last = -30
        while child.poll() is None:
            try:
                resource = sample()
                exchange("MODEL_RUNNING", resource)
                stop = check_resource(resource)
                if elapsed()[1]-last >= 30:
                    print(json.dumps(dict(event="resource_sample", utc=now(),
                                          batch_elapsed_upper_seconds=elapsed()[1], **resource)), flush=True)
                    last = elapsed()[1]
                if stop:
                    child.terminate()
                    break
            except psutil.NoSuchProcess:
                pass
            time.sleep(.25)
        try:
            child.wait(timeout=min(10, max(.1, limits["wall_limit_seconds"]-10-elapsed()[1])))
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait(timeout=5)
        reader.join(timeout=5)
        s.create(OUT+"/stdout.log", b"".join(chunks))
        if (BASE/OUT/"result.json").exists():
            result = json.loads(s.read_checked(BASE/OUT/"result.json"))
        wall = elapsed()[1]
    except BaseException as exc:
        error = dict(type=type(exc).__name__, message=str(exc), traceback=traceback.format_exc())
        if child is not None and child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=5)
        if clock:
            wall = elapsed()[1]
        if reader is not None:
            reader.join(timeout=5)
        if chunks and not (BASE/OUT/"stdout.log").exists():
            s.create(OUT+"/stdout.log", b"".join(chunks))
        s.create(OUT+"/controller_failure.json", error)
    passed = bool(not error and stop is None and result and result["status"] == "HOLDOUT_COMPLETE"
                  and child is not None and child.returncode == 0 and wall <= limits["wall_limit_seconds"])
    receipt = dict(status="COMPLETED" if passed else "FAILED", job_id=job, node=node,
                   contract_sha256=sha, worker_started=child is not None,
                   exit_code=None if child is None else child.returncode,
                   startup_nonce=acknowledged, startup_admission_verified=admitted, resource_stop=stop, error=error, clock=clock,
                   wall_seconds_upper=wall, budget_pass=wall is not None and wall <= limits["wall_limit_seconds"],
                   combined_rss_peak_bytes=peak, system_free_min_bytes=minimum, child_cpu_seconds=cpu,
                   affinity=proc.cpu_affinity(), mathematical_threads=1,
                   total_optimizer_calls=0 if child is None else None if result is None else result["total_optimizer_calls"],
                   total_effective_nonzero_steps=0 if child is None else None if result is None else result["total_effective_nonzero_steps"],
                   result_present=result is not None, ended_utc=now())
    s.create(OUT+"/receipt.json", receipt)
    print("PROBE_RECEIPT="+json.dumps(receipt), flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
