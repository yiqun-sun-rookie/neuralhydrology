"""Leak-free use of OpenHydroNet's embedding data assimilation (plan v2 §5.1).

Two pieces of the upstream engine (googlehydrology @ 011265446e11) read information from outside the assimilation
window; both are fixed here at run time, without editing Google's source:

1. ``multimet.py:378-390`` computes the per-basin target stds that weight the NSE assimilation loss on the period being
   evaluated (i.e. the whole test decade). ``use_train_period_stds`` replaces them with the training-period stds.
2. ``assimilation.py:593`` takes the early-stopping base level ``y_zero`` as the minimum of the *full* target sequence,
   which includes the ``lead_time`` future targets. ``SafeAssimilation`` hands the engine a copy of the batch whose
   future targets are NaN. The window and ``end_y`` only depend on tensor lengths, so nothing else changes; the
   untouched ``y`` is still used for scoring by the tester.

``subsample_issue_dates`` keeps every k-th issue date (plan v2 §5.3), counted from a fixed origin so that all arms
are scored on the same subset.
"""

from pathlib import Path

import numpy as np
import pandas as pd
import torch
import yaml

from googlehydrology.datasetzoo import get_dataset
from googlehydrology.datasetzoo.multimet import SampleIndexer
from googlehydrology.evaluation import get_tester
from googlehydrology.evaluation.assimilation import Assimilation
from googlehydrology.utils.config import Config

ISSUE_ORIGIN = pd.Timestamp('1989-10-01')


class SafeAssimilation(Assimilation):
    """Upstream engine, but the future (forecast-horizon) targets are invisible to it."""

    def assimilate(self, model, data):
        lead_time = self.cfg.lead_time
        masked = dict(data)
        y = data['y'].clone()
        y[:, -lead_time:] = float('nan')
        masked['y'] = y
        return super().assimilate(model, masked)


def use_train_period_stds(test_dataset, cfg: Config) -> None:
    """Replace the evaluation-period per-basin target stds by those of the training period (same scaler, same basins)."""
    if test_dataset._per_basin_target_stds is None:
        return
    train_dataset = get_dataset(cfg=cfg, is_train=False, period='train', basins=None, compute_scaler=False)
    train_stds = train_dataset._per_basin_target_stds
    test_basins = np.asarray(test_dataset._per_basin_target_stds['basin'].values)
    missing = set(test_basins) - set(np.asarray(train_stds['basin'].values))
    if missing:
        raise ValueError(f'no training-period std for basins {sorted(missing)[:5]}')
    # match by basin label (the evaluation set may be a subset / different order)
    test_dataset._per_basin_target_stds = train_stds.sel(basin=test_basins)


def subsample_issue_dates(dataset, every: int, origin: pd.Timestamp = ISSUE_ORIGIN) -> int:
    """Keep only samples whose issue date is ``origin + every * n``; returns the number of samples kept."""
    if every <= 1:
        return len(dataset._sample_index)
    index = dataset._sample_index
    date_positions = index.get_column('date')
    dates = pd.DatetimeIndex(np.asarray(dataset._dataset['date'].values))[date_positions]
    keep = ((dates - origin).days % every) == 0
    aligned = tuple((dim, np.asarray(col)[keep]) for dim, col in index._aligned_indices)
    dataset._sample_index = SampleIndexer(aligned)
    dataset._num_samples = int(keep.sum())
    return dataset._num_samples


def build_config(run_dir: Path, da_config: dict | None, overrides: dict | None = None) -> Config:
    """Run config of `run_dir` with the DA block appended and `run_dir` pointed at the (copied) run directory."""
    raw = yaml.safe_load((run_dir / 'config.yml').read_text())
    if da_config is not None:
        raw['assimilation_config'] = da_config
        raw['assimilate'] = True
    raw.update(overrides or {})
    cfg = Config(raw)
    cfg.run_dir = run_dir
    return cfg


def build_tester(run_dir: Path, da_config: dict | None, *, period: str = 'test', every: int = 1,
                 overrides: dict | None = None):
    """Tester with the leak-free engine and training-period stds; optionally on every k-th issue date."""
    cfg = build_config(run_dir, da_config, overrides)
    tester = get_tester(cfg=cfg, run_dir=run_dir, period=period, init_model=True)
    if da_config is not None:
        tester.assimilation = SafeAssimilation(cfg.assimilation_config)
        use_train_period_stds(tester.dataset, cfg)
    subsample_issue_dates(tester.dataset, every)
    return cfg, tester


def assert_finite_model(model: torch.nn.Module) -> None:
    for name, p in model.named_parameters():
        if not torch.isfinite(p).all():
            raise ValueError(f'non-finite weights in {name}')
