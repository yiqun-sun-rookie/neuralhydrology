"""P1b selection (plan v2 §5.2): score every grid setting on the tune_v0 held-out window (2006-10-01..2008-09-30),
100 basins, L=1..3; pick the setting with the highest mean of the three per-L median NSEs. Also reports the no-DA
tune_v0 reference on the same rows.

usage: python select_da.py <copies_root> <grid_dir> <tune_basins.txt> <out_dir>
  copies_root/<setting>/<run>/test/model_epoch050/test_results_data_assimilation.zarr
  copies_root/noda/<run>/test/model_epoch050/test_results.zarr   (plain evaluation of the same copy)
"""

import json
import shutil
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from score import load_by_target, nse_by_basin, pair  # noqa: E402

START, END = '2006-10-01', '2008-09-30'
LEADS = (1, 2, 3)


def main(copies: Path, grid: Path, basins_file: Path, out: Path):
    basins = set(basins_file.read_text().split())
    names = grid.joinpath('grid.txt').read_text().split()
    tables = {}
    for name in names + ['noda']:
        hits = sorted(copies.glob(f'{name}/*/test/model_epoch050/test_results*.zarr'))
        if not hits:
            print(f'MISSING {name}')
            continue
        t = load_by_target(hits[0], 'E1', leads=LEADS, start=START, end=END)
        tables[name] = t[t['basin'].isin(basins)]
    paired = pair(tables)
    rows = []
    for name in tables:
        n = nse_by_basin(paired, f'sim_{name}')
        med = n.groupby('L')['nse'].median()
        rows.append({'setting': name, **{f'L{L}': round(float(med[L]), 4) for L in LEADS},
                     'mean_L1_3': round(float(med.loc[list(LEADS)].mean()), 4), 'n_basins': int(n['basin'].nunique())})
    table = pd.DataFrame(rows).sort_values('mean_L1_3', ascending=False)
    out.mkdir(parents=True, exist_ok=True)
    table.to_csv(out / 'p1b_grid_scores.csv', index=False)
    best = table[table['setting'] != 'noda'].iloc[0]['setting']
    shutil.copy(grid / f'{best}.yml', out / 'da_selected.yml')
    (out / 'p1b_selection.json').write_text(json.dumps({'selected': best, 'rows_paired': int(len(paired)),
                                                        'window': [START, END]}, indent=1))
    print(table.to_string(index=False))
    print('SELECTED', best)


if __name__ == '__main__':
    main(Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4]))
