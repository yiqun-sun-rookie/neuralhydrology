"""Evaluate one (copied) OpenHydroNet run with leak-free embedding DA, or without DA, on a fixed issue-date subset.

usage:
  python run_eval_da.py --run-dir RUN --epoch 50 --da-config DA.yml [--every 3] [--period test] [--gpu 0]
  python run_eval_da.py --run-dir RUN --epoch 50 --no-da [--every 3]        # plain evaluation on the same subset

Outputs (written by the upstream tester into RUN): test/model_epochXXX/test_results[_data_assimilation].zarr.
Never point --run-dir at an original run: DA outputs and output.log are written into the run directory and a rerun
in the same directory deletes the previous DA results (tester.py:647-662). Use one copy per DA setting.
"""

import argparse
import json
import sys
import time
from pathlib import Path

import torch
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from safe_da import build_tester  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--run-dir', required=True, type=Path)
    ap.add_argument('--epoch', required=True, type=int)
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--da-config', type=Path)
    g.add_argument('--no-da', action='store_true')
    ap.add_argument('--every', type=int, default=1)
    ap.add_argument('--period', default='test')
    ap.add_argument('--gpu', type=int, default=0)
    ap.add_argument('--basins', type=Path, help='optional basin file overriding the period basin file')
    args = ap.parse_args()

    da_config = None if args.no_da else yaml.safe_load(args.da_config.read_text())
    overrides = {'device': f'cuda:{args.gpu}' if args.gpu >= 0 else 'cpu'}
    if args.basins:
        # same subset for the evaluated period and for the training-period stds (safe_da.use_train_period_stds)
        overrides[f'{args.period}_basin_file'] = str(args.basins)
        overrides['train_basin_file'] = str(args.basins)

    t0 = time.time()
    cfg, tester = build_tester(args.run_dir, da_config, period=args.period, every=args.every, overrides=overrides)
    n = len(tester.dataset._sample_index)
    print(f'run={args.run_dir} period={args.period} every={args.every} samples={n} da={da_config is not None}', flush=True)
    tester.evaluate(epoch=args.epoch, save_results=True, metrics=cfg.metrics, data_assimilation=da_config is not None)
    elapsed = time.time() - t0
    stamp = {'run_dir': str(args.run_dir), 'epoch': args.epoch, 'period': args.period, 'every': args.every,
             'samples': n, 'da_config': da_config, 'elapsed_s': round(elapsed, 1),
             'device': torch.cuda.get_device_name(0) if torch.cuda.is_available() and args.gpu >= 0 else 'cpu'}
    out = args.run_dir / f'da_eval_stamp_{args.period}_every{args.every}_{"da" if da_config else "noda"}.json'
    out.write_text(json.dumps(stamp, indent=1))
    print(f'EVAL_DONE elapsed_s={elapsed:.1f} samples={n}', flush=True)


if __name__ == '__main__':
    main()
