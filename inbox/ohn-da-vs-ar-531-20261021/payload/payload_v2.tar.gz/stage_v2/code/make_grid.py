"""Write the pre-registered DA tuning grid (plan v2 §5.2) as one yml per setting + an index file.

usage: python make_grid.py <out_dir>
"""

import itertools
import sys
from pathlib import Path

import yaml

BASE = {'assimilation_components': ['static_embedding', 'hindcast_embedding', 'forecast_embedding'],
        'epochs': 50, 'optimizer': 'Adam', 'loss': 'NSE', 'clip_gradient_norm': 1.0, 'early_stopping_tolerance': 0.05}
LRS = [1e-3, 1e-2, 5e-2]
REGS = [0.05, 0.5]
WINDOWS = [30, 90]


def main(out: Path):
    out.mkdir(parents=True, exist_ok=True)
    names = []
    for i, (lr, reg, win) in enumerate(itertools.product(LRS, REGS, WINDOWS)):
        name = f'g{i:02d}_lr{lr:g}_rw{reg:g}_w{win}'
        cfg = {**BASE, 'initial_learning_rate': lr, 'regularization_weight': reg, 'assimilation_window': win}
        (out / f'{name}.yml').write_text(yaml.safe_dump(cfg, sort_keys=False), encoding='utf-8', newline='\n')
        names.append(name)
    (out / 'grid.txt').write_text('\n'.join(names) + '\n', encoding='utf-8', newline='\n')
    print(len(names), 'settings ->', out)


if __name__ == '__main__':
    main(Path(sys.argv[1]))
