"""Build the hindcast-only QOBS product for the autoregression arm A1 (plan v2 §4).

qobs_lag1(basin, date j) = observed streamflow of day j-1 (float32, NaN where missing / at the first date).
No lead_time axis: multimet reads such products as hindcast-only (multimet.py:264-275, 495-501).

usage: python build_qobs.py <data_dir with streamflow.zarr> <new dynamics dir> <existing MAURER product dir>
The new dynamics dir gets QOBS/timeseries.zarr and a symlink MAURER -> existing product (read-only reuse).
"""

import os
import sys
from pathlib import Path

import numpy as np
import xarray as xr


def build_qobs(data_dir: Path, dynamics_dir: Path, maurer_src: Path | None = None) -> Path:
    store = dynamics_dir / 'QOBS' / 'timeseries.zarr'
    if store.exists():
        raise SystemExit(f'{store} exists; not overwriting')
    with xr.open_zarr(data_dir / 'streamflow.zarr', consolidated=False) as ds:
        q = ds['streamflow'].load()
    dates = q['date'].values
    if not (np.diff(dates) == np.timedelta64(1, 'D')).all():
        raise SystemExit('streamflow dates are not a contiguous daily axis')
    values = q.transpose('basin', 'date').values.astype('float32')
    lag = np.full_like(values, np.nan)
    lag[:, 1:] = values[:, :-1]
    out = xr.Dataset({'qobs_lag1': (('basin', 'date'), lag)}, coords={'basin': q['basin'].values, 'date': dates})
    store.parent.mkdir(parents=True, exist_ok=True)
    out.to_zarr(store, mode='w-', consolidated=False)
    if maurer_src is not None:
        link = dynamics_dir / 'MAURER'
        if not link.exists():
            os.symlink(maurer_src, link, target_is_directory=True)
    return store


def check_qobs(data_dir: Path, dynamics_dir: Path) -> dict:
    """Independent re-read: lag relation, dtype, coords."""
    with xr.open_zarr(data_dir / 'streamflow.zarr', consolidated=False) as a, \
            xr.open_zarr(dynamics_dir / 'QOBS' / 'timeseries.zarr', consolidated=False) as b:
        q = a['streamflow'].transpose('basin', 'date').values
        lag = b['qobs_lag1'].transpose('basin', 'date').values
        same_coords = np.array_equal(a['basin'].values, b['basin'].values) and np.array_equal(a['date'].values, b['date'].values)
    shifted_ok = np.array_equal(lag[:, 1:], q[:, :-1].astype('float32'), equal_nan=True)
    return {'dtype': str(lag.dtype), 'same_coords': bool(same_coords), 'lag_relation_ok': bool(shifted_ok),
            'first_date_all_nan': bool(np.isnan(lag[:, 0]).all()), 'shape': list(lag.shape)}


if __name__ == '__main__':
    d, dyn = Path(sys.argv[1]), Path(sys.argv[2])
    src = Path(sys.argv[3]) if len(sys.argv) > 3 else None
    print('built', build_qobs(d, dyn, src))
    print('check', check_qobs(d, dyn))
