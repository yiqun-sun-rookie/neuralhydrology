# Sourced by every job of this experiment. Old OpenHydroNet root is used read-only (env, Google source, data, runs).
NEW=/data1/home/sunyiq/ohn_da_vs_ar_531_20261021
OLD=/data1/home/sunyiq/openhydronet_531_20261015
source ~/miniconda3/etc/profile.d/conda.sh
conda activate nh_final || { echo CONDA_FAILED; exit 1; }
export MKL_THREADING_LAYER=GNU
export MKL_SERVICE_FORCE_INTEL=1
export PYTHONPATH="$OLD/pysite:$OLD/src/flood-forecasting:$NEW/code"

gpu_check() {
  python -u -c "import torch, sys; ok = torch.cuda.is_available(); print('torch', torch.__version__, 'cuda', ok, torch.cuda.get_device_name(0) if ok else '-'); sys.exit(0 if ok else 1)" \
    || { echo "[FATAL] no usable GPU on $(hostname)"; exit 1; }
}

run_cli() {
  python -u -c 'import sys; sys.argv[0] = "run"; from googlehydrology.run import _main; _main()' "$@"
}

# copy_run SRC DST : copy a trained run for inference (final weights, config, scaler), never the old results
copy_run() {
  local src=$1 dst=$2
  [ -e "$dst" ] && { echo "COPY_EXISTS $dst"; return 0; }
  mkdir -p "$dst"
  tar -C "$src" --exclude=./test --exclude=./validation --exclude=./train \
      --exclude='./model_epoch00*' --exclude='./model_epoch01*' --exclude='./model_epoch02*' \
      --exclude='./model_epoch03*' --exclude='./model_epoch04*' --exclude='./optimizer_state*' -cf - . \
    | tar -C "$dst" -xf -
  ls "$dst" | tr '\n' ' '; echo
  [ -f "$dst/model_epoch050.pt" ] || { echo "MISSING_WEIGHTS $dst"; return 1; }
}
