"""Derive the autoregression (A1) config from the frozen id18_nse config (plan v2 §4): only the QOBS input, the
missing-data mode, the dynamics dir, the run location and the seed change.

usage: python make_a1_config.py <id18_nse.yml> <out.yml> <experiment_name> <run_dir> <dynamics_dir> <seed>
         [--smoke]   (1 epoch x 50 updates)
"""

import sys
from pathlib import Path

import yaml


def make(base: Path, out: Path, name: str, run_dir: str, dynamics_dir: str, seed: int, smoke: bool = False):
    cfg = yaml.safe_load(base.read_text())
    cfg['experiment_name'] = name
    cfg['run_dir'] = run_dir
    cfg['dynamics_data_dir'] = dynamics_dir
    cfg['hindcast_inputs'] = {**cfg['hindcast_inputs'], 'qobs': ['qobs_lag1']}
    cfg['nan_handling_method'] = 'input_replacing'
    cfg['seed'] = int(seed)
    if smoke:
        cfg['epochs'] = 1
        cfg['max_updates_per_epoch'] = 50
    out.write_text(yaml.safe_dump(cfg, sort_keys=False), encoding='utf-8', newline='\n')
    return cfg


if __name__ == '__main__':
    a = sys.argv[1:]
    make(Path(a[0]), Path(a[1]), a[2], a[3], a[4], int(a[5]), smoke='--smoke' in a)
    print('wrote', a[1])
