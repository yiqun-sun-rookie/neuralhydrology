"""Scoring for plan v2 (§3, §7): align every arm by L = days since the last observation it used, pair arms on the same
(basin, target day), clip simulations at 0, per-basin NSE, medians and paired bootstrap of median differences.

Result zarrs (tester output): dims (basin, freq, date, time_step); row `date` d is the issue date, time_step tau targets
day d-1+tau (openhydronet_vs_nh_lstm_simulation_20261020.md §2). L = tau for E0 / E0-fp32 / E1 / A1+DA (their last
observation is day d-1) and L = tau+1 for A1 (its last observed input is Q(d-2)).
"""

import numpy as np
import pandas as pd
import xarray as xr

LEAD_SHIFT = {'E0': 0, 'E0fp32': 0, 'E1': 0, 'E1default': 0, 'A1DA': 0, 'A1': 1}


ISSUE_ORIGIN = pd.Timestamp('1989-10-01')


def load_by_target(zarr_path, arm: str, leads=range(1, 8), start=None, end=None, issue_every: int = 1) -> pd.DataFrame:
    """Long table (basin, L, target, obs, sim) for one result zarr; only rows with a finite simulation.

    issue_every > 1 keeps only the issue dates whose targets pair with the every-k DA subset (plan v2 §5.3):
    issue d with (d - origin) % k == 0 for L = tau arms, and d - 1 on that grid for A1 (its L = tau + 1).
    """
    ds = xr.open_zarr(zarr_path, consolidated=False)
    shift = LEAD_SHIFT[arm]
    all_dates = pd.DatetimeIndex(ds['date'].values)
    if issue_every > 1:
        keep = ((all_dates - ISSUE_ORIGIN).days - shift) % issue_every == 0
        ds = ds.isel(date=np.flatnonzero(keep))
    obs = ds['streamflow_obs'].isel(freq=0)
    sim = ds['streamflow_sim'].isel(freq=0)
    dates = pd.DatetimeIndex(ds['date'].values)
    basins = np.asarray(ds['basin'].values).astype(str)
    frames = []
    for L in leads:
        tau = L - shift
        if tau < 0 or tau >= ds.sizes['time_step']:
            continue
        o = obs.isel(time_step=tau).values          # (basin, date)
        s = sim.isel(time_step=tau).values
        target = dates + pd.Timedelta(days=tau - 1)
        bb, dd = np.meshgrid(np.arange(len(basins)), np.arange(len(dates)), indexing='ij')
        m = np.isfinite(s)
        frames.append(pd.DataFrame({'basin': basins[bb[m]], 'L': L, 'target': target[dd[m]],
                                    'obs': o[m].astype('float64'), 'sim': np.maximum(s[m], 0.0).astype('float64')}))
    df = pd.concat(frames, ignore_index=True)
    if start is not None:
        df = df[df['target'] >= pd.Timestamp(start)]
    if end is not None:
        df = df[df['target'] <= pd.Timestamp(end)]
    return df


def ensemble(tables: list[pd.DataFrame]) -> pd.DataFrame:
    """Mean simulation over members on their common (basin, L, target) rows."""
    keys = ['basin', 'L', 'target']
    merged = None
    for i, t in enumerate(tables):
        t = t[keys + ['obs', 'sim']].rename(columns={'sim': f'sim{i}', 'obs': f'obs{i}'})
        merged = t if merged is None else merged.merge(t.drop(columns=[f'obs{i}']), on=keys, how='inner')
    sims = merged[[c for c in merged.columns if c.startswith('sim')]]
    return merged[keys].assign(obs=merged['obs0'], sim=sims.mean(axis=1))


def pair(arms: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Inner-join arms on (basin, L, target) with finite obs; columns obs, sim_<arm>."""
    keys = ['basin', 'L', 'target']
    out = None
    for name, t in arms.items():
        t = t[keys + ['obs', 'sim']].rename(columns={'sim': f'sim_{name}'})
        out = t if out is None else out.merge(t.drop(columns=['obs']), on=keys, how='inner')
    return out[np.isfinite(out['obs'])]


def nse_by_basin(paired: pd.DataFrame, sim_col: str) -> pd.DataFrame:
    def nse(g):
        o, s = g['obs'].to_numpy(), g[sim_col].to_numpy()
        den = ((o - o.mean()) ** 2).sum()
        return np.nan if den == 0 else 1.0 - ((s - o) ** 2).sum() / den
    return paired.groupby(['L', 'basin']).apply(nse, include_groups=False).rename('nse').reset_index()


def paired_median_diff(a: pd.Series, b: pd.Series, n_boot: int = 20000, seed: int = 20221021) -> dict:
    """a, b: per-basin NSE indexed by basin. Median of (a-b), basin bootstrap 95% CI, share of basins a>b."""
    d = (a - b).dropna().to_numpy()
    rng = np.random.default_rng(seed)
    boots = np.median(d[rng.integers(0, len(d), size=(n_boot, len(d)))], axis=1)
    return {'n': len(d), 'median_diff': float(np.median(d)), 'ci_lo': float(np.quantile(boots, 0.025)),
            'ci_hi': float(np.quantile(boots, 0.975)), 'frac_better': float((d > 0).mean())}


def verdict(rows: dict[int, dict], min_effect: float = 0.02, equiv: float = 0.01) -> str:
    """Plan v2 §7 rule on L=1..3 comparison rows {L: paired_median_diff(...)}."""
    l1 = rows[1]
    pos = sum(rows[L]['ci_lo'] > 0 for L in (1, 2, 3))
    neg = sum(rows[L]['ci_hi'] < 0 for L in (1, 2, 3))
    if l1['median_diff'] >= min_effect and pos >= 2:
        return 'better'
    if l1['median_diff'] <= -min_effect and neg >= 2:
        return 'worse'
    if all(-equiv <= rows[L]['ci_lo'] and rows[L]['ci_hi'] <= equiv for L in (1, 2, 3)):
        return 'tie'
    return 'inconclusive'
