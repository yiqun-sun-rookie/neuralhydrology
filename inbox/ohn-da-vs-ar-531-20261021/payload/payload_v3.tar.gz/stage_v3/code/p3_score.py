"""P3 (plan v2 §7): 5-member ensembles per arm, pairing on (basin, L, target), per-basin NSE, H1-H3 verdicts.

usage: python p3_score.py <new_root> <old_root> <out_dir>
Arms: E0 (old fp16 inference, read-only), E0fp32 / E1 / E1default / A1DA (DA path, every 3rd issue date), A1 (own runs),
persistence Q(target - L). Confirmatory: H1 E1-E0fp32, H2 E1-A1, H3 A1DA-A1 (L=1..3 rule); the rest is exploratory.
"""

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import xarray as xr

sys.path.insert(0, str(Path(__file__).resolve().parent))
from score import ensemble, load_by_target, nse_by_basin, pair, paired_median_diff, verdict  # noqa: E402

START, END = '1989-10-01', '1999-09-30'
LEADS = range(1, 8)
EVERY = 3
OLD_RUNS = ['id18_nse_1510_225843', 'id18_nse_s101_1610_225041', 'id18_nse_s102_1610_225041',
            'id18_nse_s103_1610_211043', 'id18_nse_s104_1610_211024']


def sources(new: Path, old: Path) -> dict[str, list[Path]]:
    da = 'test/model_epoch050/test_results_data_assimilation.zarr'
    plain = 'test/model_epoch050/test_results.zarr'
    out = {'E0': [old / 'runs' / r / plain for r in OLD_RUNS]}
    for arm in ('E0fp32', 'E1', 'E1default', 'A1DA'):
        out[arm] = sorted((new / 'copies' / 'p2' / arm).glob(f'*/{da}'))
    out['A1'] = sorted((new / 'runs').glob(f'a1_s10*/{plain}'))
    return out


def persistence(data_dir: Path, template: pd.DataFrame) -> pd.DataFrame:
    with xr.open_zarr(data_dir / 'streamflow.zarr', consolidated=False) as ds:
        q = ds['streamflow'].load().to_series()                       # (basin, date)
    q.index = q.index.set_levels([q.index.levels[0].astype(str), q.index.levels[1]])
    keys = template[['basin', 'L', 'target']].drop_duplicates()
    src = pd.MultiIndex.from_arrays([keys['basin'], keys['target'] - pd.to_timedelta(keys['L'], unit='D')])
    return keys.assign(obs=np.nan, sim=q.reindex(src).to_numpy())


def main(new: Path, old: Path, out: Path):
    out.mkdir(parents=True, exist_ok=True)
    src = sources(new, old)
    counts = {a: len(v) for a, v in src.items()}
    print('members per arm:', counts, flush=True)
    ens = {}
    for arm, paths in src.items():
        if len(paths) != 5:
            print(f'SKIP {arm}: {len(paths)} members (need 5)')
            continue
        tables = [load_by_target(p, arm, leads=LEADS, start=START, end=END, issue_every=EVERY) for p in paths]
        ens[arm] = ensemble(tables)
        print(f'{arm}: {len(ens[arm])} rows', flush=True)
    base = next(iter(ens.values()))
    ens['persist'] = persistence(old / 'data' / 'id18_maurer', base)
    paired = pair(ens)
    print('paired rows', len(paired), 'basins', paired['basin'].nunique(), flush=True)

    nse = {arm: nse_by_basin(paired, f'sim_{arm}').set_index(['L', 'basin'])['nse'] for arm in ens}
    by_basin = pd.DataFrame(nse).reset_index()
    by_basin.to_csv(out / 'p3_nse_by_basin.csv', index=False)
    med = by_basin.groupby('L').median(numeric_only=True)
    med.to_csv(out / 'p3_median_nse_by_L.csv')
    print(med.round(4).to_string(), flush=True)

    comparisons = {'H1_E1_vs_E0fp32': ('E1', 'E0fp32'), 'H2_E1_vs_A1': ('E1', 'A1'), 'H3_A1DA_vs_A1': ('A1DA', 'A1'),
                   'x_E1_vs_E0': ('E1', 'E0'), 'x_E0fp32_vs_E0': ('E0fp32', 'E0'), 'x_E1default_vs_E1': ('E1default', 'E1'),
                   'x_A1_vs_E0': ('A1', 'E0'), 'x_A1DA_vs_persist': ('A1DA', 'persist'), 'x_A1_vs_persist': ('A1', 'persist')}
    rows, verdicts = [], {}
    for name, (a, b) in comparisons.items():
        if a not in nse or b not in nse:
            continue
        per_l = {}
        for L in LEADS:
            r = paired_median_diff(nse[a].xs(L, level='L'), nse[b].xs(L, level='L'))
            per_l[L] = r
            rows.append({'comparison': name, 'L': L, **{k: round(v, 5) if isinstance(v, float) else v for k, v in r.items()}})
        if name.startswith('H'):
            verdicts[name] = verdict(per_l)
    pd.DataFrame(rows).to_csv(out / 'p3_paired_comparisons.csv', index=False)
    (out / 'p3_verdicts.json').write_text(json.dumps({'verdicts': verdicts, 'members': counts,
                                                      'paired_rows': int(len(paired))}, indent=1))
    print('VERDICTS', verdicts, flush=True)


if __name__ == '__main__':
    main(Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]))
