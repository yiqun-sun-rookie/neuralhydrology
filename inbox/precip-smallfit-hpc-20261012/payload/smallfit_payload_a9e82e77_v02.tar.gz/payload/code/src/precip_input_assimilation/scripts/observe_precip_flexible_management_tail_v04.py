"""Observe the exact Windows supervisor exit using only standard-library metadata.

This helper holds a synchronization/query handle before publishing readiness.
It never opens scientific inputs, imports numerical modules, starts or kills
processes, acquires a budget lock, or edits the computation ledger.  Its result
is a wall-clock upper bound through observed native exit; it is not CPU time or
the exact instant at which the supervisor exited.
"""

import argparse
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import stat
import sys
import time


QUERY_AND_SYNCHRONIZE = 0x00100000 | 0x1000
WAIT_OBJECT_0 = 0
WAIT_TIMEOUT = 258
STILL_ACTIVE = 259
SCHEMA = "precip_flexible_management_tail_observer_v04"


def _utc():
    return datetime.now(timezone.utc).isoformat()


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode("utf-8")).hexdigest()


def _sha256_bytes(value):
    return hashlib.sha256(value).hexdigest()


def _sha(value):
    if not isinstance(value, str) or len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
        raise PermissionError("Metadata evidence requires an explicit lowercase SHA256")
    return value


def _identity(pid, creation):
    if not isinstance(pid, int) or isinstance(pid, bool) or not 0 < pid < 2**32:
        raise PermissionError("Exact supervisor PID must be a positive Windows process identifier")
    if not isinstance(creation, str) or not creation.isascii() or not creation.isdecimal() or \
            str(int(creation)) != creation or not 0 < int(creation) < 2**64:
        raise PermissionError("Exact supervisor creation identity must be canonical decimal FILETIME")
    return {"pid": pid, "windows_creation_identity": creation}


def _nonce(value):
    if not isinstance(value, str) or len(value) != 32 or any(c not in "0123456789abcdef" for c in value):
        raise PermissionError("A fresh lowercase UUID nonce is required")
    return value


def _finite_time(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
        raise PermissionError("Missing or invalid monotonic " + name)
    return float(value)


def _metadata_directory(value):
    root = Path(value)
    if not root.is_absolute() or not root.is_dir():
        raise PermissionError("An existing absolute metadata directory is required")
    for ancestor in (root, *root.parents):
        if ancestor.exists() and (ancestor.is_symlink() or
                getattr(ancestor.lstat(), "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT):
            raise PermissionError("Metadata path traverses a link or reparse point")
    return root.resolve()


def _safe_record(root, filename):
    path = root / filename
    if path.is_symlink() or (path.exists() and
            getattr(path.lstat(), "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT):
        raise PermissionError("Metadata record is a link or reparse point")
    return path


def _publish(path, value):
    """Publish once; the Windows rename refuses an existing immutable record."""
    path = Path(path)
    if path.exists():
        raise FileExistsError("Management observer evidence cannot be overwritten")
    temporary = path.with_name(path.name + ".pending")
    data = (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n").encode("utf-8")
    with temporary.open("xb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    # Only Windows native execution is admitted.  Tests use private synthetic
    # directories; the externally bound nonce has one metadata writer.
    if path.exists():
        raise FileExistsError("Management observer evidence appeared during publication")
    os.rename(temporary, path)


def _kernel():
    if os.name != "nt":
        raise PermissionError("Exact native supervisor-exit observation requires Windows")
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.GetCurrentProcess.argtypes = []
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    kernel.GetProcessId.argtypes = [wintypes.HANDLE]
    kernel.GetProcessId.restype = wintypes.DWORD
    kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
    kernel.GetProcessTimes.restype = wintypes.BOOL
    kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
    kernel.GetExitCodeProcess.restype = wintypes.BOOL
    kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    kernel.WaitForSingleObject.restype = wintypes.DWORD
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel.CloseHandle.restype = wintypes.BOOL
    return kernel


def _native_snapshot(kernel, handle):
    pid = kernel.GetProcessId(handle)
    if not pid:
        raise ctypes.WinError(ctypes.get_last_error())
    creation, exited, system, user = [wintypes.FILETIME() for _ in range(4)]
    if not kernel.GetProcessTimes(handle, *[ctypes.byref(value) for value in (creation, exited, system, user)]):
        raise ctypes.WinError(ctypes.get_last_error())
    wait = kernel.WaitForSingleObject(handle, 0)
    if wait not in {WAIT_OBJECT_0, WAIT_TIMEOUT}:
        raise ctypes.WinError(ctypes.get_last_error())
    code = wintypes.DWORD()
    if not kernel.GetExitCodeProcess(handle, ctypes.byref(code)):
        raise ctypes.WinError(ctypes.get_last_error())
    if wait == WAIT_TIMEOUT and code.value != STILL_ACTIVE:
        # Resolve the race in which the process exited after the first wait.
        wait = kernel.WaitForSingleObject(handle, 0)
        if wait != WAIT_OBJECT_0:
            raise PermissionError("Native process synchronization and exit-code queries disagree")
    return {"pid": int(pid), "windows_creation_identity":
            str((creation.dwHighDateTime << 32) | creation.dwLowDateTime),
            "status": "EXITED" if wait == WAIT_OBJECT_0 else "RUNNING",
            "native_wait_signaled": wait == WAIT_OBJECT_0, "native_exit_code": int(code.value),
            "native_query_succeeded": True, "native_process_handle_retained": True}


class NativeSupervisorHandle:
    """One held exact process object; a reused PID is never reopened/adopted."""

    def __init__(self, pid, creation):
        self.expected = _identity(pid, creation)
        self.kernel = _kernel()
        self.handle = self.kernel.OpenProcess(QUERY_AND_SYNCHRONIZE, False, pid)
        if not self.handle:
            raise ctypes.WinError(ctypes.get_last_error())
        try:
            self.snapshot()
        except BaseException:
            self.close()
            raise

    def snapshot(self):
        if not self.handle:
            raise PermissionError("Exact supervisor process handle is closed")
        value = _native_snapshot(self.kernel, self.handle)
        if _identity(value["pid"], value["windows_creation_identity"]) != self.expected:
            raise PermissionError("Held supervisor process object has a different creation identity")
        return value

    def observer_identity(self):
        value = _native_snapshot(self.kernel, self.kernel.GetCurrentProcess())
        if value["pid"] != os.getpid() or value["status"] != "RUNNING":
            raise PermissionError("Observer's own native creation identity cannot be confirmed")
        return _identity(value["pid"], value["windows_creation_identity"])

    def wait_for_exit(self):
        if not self.handle:
            raise PermissionError("Exact supervisor process handle is closed")
        while True:
            wait = self.kernel.WaitForSingleObject(self.handle, 1000)
            if wait == WAIT_TIMEOUT:
                continue
            if wait != WAIT_OBJECT_0:
                raise ctypes.WinError(ctypes.get_last_error())
            value = self.snapshot()
            if value["native_wait_signaled"] is not True or value["status"] != "EXITED":
                raise PermissionError("Held supervisor handle did not prove exact process exit")
            return value

    def close(self):
        if self.handle:
            if not self.kernel.CloseHandle(self.handle):
                raise ctypes.WinError(ctypes.get_last_error())
            self.handle = None


def _checked_native(value, expected, exited):
    if not isinstance(value, dict) or _identity(value.get("pid"), value.get("windows_creation_identity")) != expected or \
            value.get("native_query_succeeded") is not True or value.get("native_process_handle_retained") is not True:
        raise PermissionError("Exact retained native process identity/query proof is incomplete")
    required_status = "EXITED" if exited else "RUNNING"
    if value.get("status") != required_status or value.get("native_wait_signaled") is not exited:
        raise PermissionError("Native process proof does not match the required running/exited state")
    code = value.get("native_exit_code")
    if not isinstance(code, int) or isinstance(code, bool) or not 0 <= code < 2**32:
        raise PermissionError("Native exit code is missing or invalid")
    if not exited and code != STILL_ACTIVE:
        raise PermissionError("Running native process proof has a nonactive exit code")
    return value


def _tail_result(record, record_bytes, expected, nonce, ready_monotonic, observed_monotonic, exit_proof):
    if not isinstance(record, dict) or not isinstance(record.get("owner"), dict):
        raise PermissionError("Supervisor management-tail record lacks the original owner")
    owner = record["owner"]
    if _identity(owner.get("pid"), owner.get("windows_creation_identity")) != expected or owner.get("nonce") != nonce:
        raise PermissionError("Supervisor management-tail owner creation identity or nonce differs")
    if record.get("scope") != "pure_metadata_only_after_whole_numeric_exit_and_final_scientific_timing" or \
            record.get("exact_supervisor_exit_pending") is not True:
        raise PermissionError("Supervisor management-tail timing scope is not the registered metadata interval")
    boundary = _finite_time(record.get("boundary_monotonic"), "scientific boundary")
    through_unlock = _finite_time(record.get("through_unlock_monotonic"), "through-unlock boundary")
    partial = _finite_time(record.get("seconds_through_completed_reports_handles_and_os_unlock"), "through-unlock span")
    if not ready_monotonic <= boundary <= through_unlock <= observed_monotonic or \
            partial != through_unlock - boundary:
        raise PermissionError("Supervisor management-tail boundaries/span are inconsistent")
    extra = record.get("metadata_evidence_sha256", {})
    if not isinstance(extra, dict) or any(not isinstance(key, str) or not key for key in extra):
        raise PermissionError("Additional original metadata evidence binding is malformed")
    for value in extra.values():
        _sha(value)
    return {"boundary_monotonic": boundary, "through_unlock_monotonic": through_unlock,
            "observed_exact_supervisor_exit_monotonic": observed_monotonic,
            "seconds_through_completed_reports_handles_and_os_unlock": partial,
            "seconds_after_through_unlock_until_observed_exact_exit_upper_bound": observed_monotonic - through_unlock,
            "seconds_from_scientific_boundary_until_observed_exact_exit_upper_bound": observed_monotonic - boundary,
            "measurement_kind": "monotonic_wall_clock_upper_bound_through_observed_native_exact_exit",
            "measurement_limit": "Includes native wait/query return latency and observer scheduling delay; "
                                 "does not identify exact process exit instant or CPU time",
            "observer_metadata_after_observed_exit_excluded": True,
            "through_unlock_record_sha256": _sha256_bytes(record_bytes), "owner_sha256": _digest(owner),
            "original_metadata_evidence_sha256": extra, "owner": owner, "native_exact_exit_proof": exit_proof}


def observe(supervisor_pid, supervisor_creation, nonce, metadata_root, *,
            process_factory=NativeSupervisorHandle, clock=time.monotonic, clock_info=None):
    """Publish ready, await held exact object exit, then append completion.

    Injectable factory/clock are for synthetic test SOURCES, executed later in
    the reserved numerical test worker.  Production CLI supplies neither.
    """
    expected = _identity(supervisor_pid, supervisor_creation)
    nonce = _nonce(nonce)
    root = _metadata_directory(metadata_root)
    ready_path = _safe_record(root, "management_tail_observer_ready_" + nonce + ".json")
    complete_path = _safe_record(root, "management_tail_complete_" + nonce + ".json")
    failure_path = _safe_record(root, "management_tail_observer_failure_" + nonce + ".json")
    target = None
    exit_proof = None
    ready = None
    try:
        if ready_path.exists() or complete_path.exists() or failure_path.exists():
            raise FileExistsError("Observer nonce already has evidence; start only a fresh observer")
        if process_factory is NativeSupervisorHandle and sys.version_info < (3, 10):
            raise PermissionError("Shared Windows monotonic-clock comparison requires Python 3.10 or newer")
        if clock_info is None:
            info = time.get_clock_info("monotonic")
            clock_info = {"implementation": info.implementation, "monotonic": info.monotonic,
                          "adjustable": info.adjustable, "resolution_seconds": info.resolution}
        if clock_info.get("monotonic") is not True or clock_info.get("adjustable") is not False:
            raise PermissionError("Observer requires the nonadjustable shared monotonic clock")
        target = process_factory(supervisor_pid, supervisor_creation)
        running = _checked_native(target.snapshot(), expected, exited=False)
        observer = target.observer_identity()
        _identity(observer.get("pid"), observer.get("windows_creation_identity"))
        ready_monotonic = _finite_time(clock(), "observer readiness")
        ready = {"schema": SCHEMA, "status": "READY_EXACT_NATIVE_SUPERVISOR_HANDLE_RETAINED", "nonce": nonce,
                 "supervisor": expected, "supervisor_running_proof": running, "observer": observer,
                 "ready_monotonic": ready_monotonic, "clock": clock_info,
                 "python_version": list(sys.version_info[:3]), "python_executable": str(Path(sys.executable).resolve()),
                 "observer_source_sha256": _sha256_bytes(Path(__file__).read_bytes()), "utc": _utc()}
        _publish(ready_path, ready)
        original_ready_bytes = ready_path.read_bytes()
        if json.loads(original_ready_bytes.decode("utf-8")) != ready:
            raise PermissionError("Published readiness record changed before native wait")
        exit_proof = _checked_native(target.wait_for_exit(), expected, exited=True)
        observed_monotonic = _finite_time(clock(), "native exit observation")
        if ready_path.read_bytes() != original_ready_bytes or \
                _sha256_bytes(Path(__file__).read_bytes()) != ready["observer_source_sha256"]:
            raise PermissionError("Original observer source or readiness evidence changed while waiting")
        _publish(_safe_record(root, "management_tail_observed_exit_" + nonce + ".json"), {
            "schema": SCHEMA, "nonce": nonce, "supervisor": expected, "observer": observer,
            "observed_monotonic": observed_monotonic, "native_exact_exit_proof": exit_proof,
            "ready_record_sha256": _sha256_bytes(original_ready_bytes), "utc": _utc()})
        tail_path = _safe_record(root, "management_tail_through_unlock_" + nonce + ".json")
        if not tail_path.is_file():
            raise PermissionError("Exact supervisor exited without its through-unlock timing evidence")
        tail_bytes = tail_path.read_bytes()
        result = _tail_result(json.loads(tail_bytes.decode("utf-8")), tail_bytes, expected, nonce,
                              ready_monotonic, observed_monotonic, exit_proof)
        result.update({"schema": SCHEMA, "status": "COMPLETE_EXACT_SUPERVISOR_EXIT_OBSERVED", "nonce": nonce,
                       "supervisor": expected, "observer": observer, "clock": clock_info,
                       "python_version": ready["python_version"], "python_executable": ready["python_executable"],
                       "ready_record_sha256": _sha256_bytes(original_ready_bytes),
                       "observer_source_sha256": ready["observer_source_sha256"], "utc": _utc()})
        # Handle cleanup must succeed before claiming this observer complete.
        target.close()
        target = None
        _publish(complete_path, result)
        return result
    except BaseException as error:
        failure = {"schema": SCHEMA, "status": "INCOMPLETE_OBSERVER_FAILURE", "nonce": nonce,
                   "supervisor": expected, "native_exact_exit_proof": exit_proof,
                   "ready_record_sha256": _sha256_bytes(ready_path.read_bytes()) if ready_path.is_file() else None,
                   "error_type": type(error).__name__, "error": str(error), "utc": _utc()}
        if target is not None:
            try:
                target.close()
            except BaseException as close_error:
                failure["native_handle_cleanup_error"] = {
                    "error_type": type(close_error).__name__, "error": str(close_error)}
        try:
            _publish(failure_path, failure)
        except Exception:
            pass  # Keep existing/original evidence and the original exception.
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--supervisor-pid", type=int, required=True)
    parser.add_argument("--supervisor-creation", required=True)
    parser.add_argument("--nonce", required=True)
    parser.add_argument("--metadata-root", type=Path, required=True)
    args = parser.parse_args()
    observe(args.supervisor_pid, args.supervisor_creation, args.nonce, args.metadata_root)


if __name__ == "__main__":
    main()
