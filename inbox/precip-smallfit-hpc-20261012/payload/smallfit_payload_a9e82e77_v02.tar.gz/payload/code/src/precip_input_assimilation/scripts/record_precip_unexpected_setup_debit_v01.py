"""Record one reviewed conservative exception debit using only standard library.

This is a present-time administrative reservation and settlement, never a
fabricated earlier reservation or a claim of measured numerical setup time.
No scientific input, model, test, worker, or counter is opened or started.
"""

import argparse
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import errno
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import sys
import uuid


REPO = Path(__file__).resolve().parents[3]
FAMILY = REPO / "results/precip_input_da_2026_09/effect_first_v01"
META = FAMILY / "local_gradient_flexible_execution_20261011_v04"
RULE = META / "unexpected_setup_debit_rule_v01.json"
BINDING = META / "unexpected_import_original_tool_binding_v01.json"
FAILURE = META / "prelaunch_metadata_unexpected_numerical_import_failure_v04_03.json"
ORIGINAL_HELPER = REPO / "src/precip_input_assimilation/scripts/run_precip_effect_first_v02.py"
LEDGER = FAMILY / "cumulative_budget_v01.json"
OUTPUT = META / "unexpected_setup_debit_v01"
BASELINE_SHA = "1023a40c541a796927995575ee5e76eb3f00aaec005439f1dd52882a75af3b5e"
BINDING_SHA = "1aac419f19543af1536f022316665a54b57e9d890f3b6960e21af8bcb8fbdd0a"
FAILURE_SHA = "ee215f754756b1815526575907280ca551aebf58e01f06e7b3ddf30f64d612c7"
ORIGINAL_HELPER_SHA = "fd38ecbd0b669a23665138574237ad383171b4249cfd40e36900658520387baa"
PREFIX_SHA = "6bea1e2c82c666879cf9e1f683febe15b57a717bd2c5dc51e2ab9065662ff217"
PREFIX_BYTES = 21145718
LINES = (4693, 4695, 4761, 4763, 4777, 4779, 4822, 4825)
BEFORE_CLOCK = "2026-10-11 09:07:08 UTC"
AFTER_CLOCK = "2026-10-11 09:12:23 UTC"
TURN_ID = "01a129ff-d253-7123-b9ed-5e637629f6b5"
CALL_IDS = {"before_clock": "call_430151ade9814b81a69909cd76681379",
            "prelaunch": "call_eb768875e57847e9b15e31d5dc35fc2f",
            "exit_confirmation": "call_9043958938044561857d3aa4c3df8ec1",
            "after_clock": "call_8f5168b1817249cc93cc0a2a9197f821"}
CHARGE = 316
BEFORE_USED = 96089
AFTER_USED = 96405
TOTAL = 259200
SCOPE = "standard_library_management_exception_debit_only"
REASON = ("Conservative exception debit for the preserved unreserved prelaunch numerical import; "
          "315-second coarse external UTC bracket plus 1-second policy padding, not a "
          "monotonic measurement or exact setup time. This reservation is recorded now.")


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def safe_path(path, root=REPO, exists=True):
    path = Path(path).absolute()
    if not path.resolve().is_relative_to(Path(root).resolve()):
        raise PermissionError("Metadata path leaves its fixed root")
    for ancestor in (path, *path.parents):
        if os.path.lexists(ancestor) and (ancestor.is_symlink() or
                getattr(ancestor.lstat(), "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT):
            raise PermissionError("Metadata path traverses a link or reparse point")
    if exists and not path.is_file():
        raise FileNotFoundError("Required immutable metadata file is absent: " + str(path))
    return path


def sha256(path):
    value = hashlib.sha256()
    with safe_path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1048576), b""):
            value.update(block)
    return value.hexdigest()


def read_json(path):
    return json.loads(safe_path(path).read_text(encoding="utf-8"))


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True,
                       indent=2, allow_nan=False) + "\n").encode("utf-8")


def require_standard_library():
    for name in sys.modules:
        if any(name == root or name.startswith(root + ".") for root in ("torch", "numpy", "pandas")):
            raise PermissionError("Numerical libraries are prohibited in the exception debit helper")


def expected_rule():
    return {"schema": "precip_unexpected_setup_debit_rule_v01", "execution_scope": SCOPE,
            "baseline_ledger_sha256": BASELINE_SHA, "baseline_charged_seconds": BEFORE_USED,
            "baseline_events": 10, "baseline_closed_allocations": 5,
            "total_seconds": TOTAL, "conservative_charge_seconds": CHARGE,
            "resulting_charged_seconds": AFTER_USED, "external_utc_bracket_seconds": 315,
            "policy_padding_seconds": 1, "actual_setup_seconds": None,
            "actual_monotonic_elapsed_seconds": None, "clock_is_monotonic": False,
            "before_clock": BEFORE_CLOCK, "after_clock": AFTER_CLOCK,
            "original_tool_binding_sha256": BINDING_SHA, "original_failure_sha256": FAILURE_SHA,
            "original_budget_helper_sha256": ORIGINAL_HELPER_SHA,
            "source_prefix_bytes": PREFIX_BYTES, "source_prefix_sha256": PREFIX_SHA,
            "selected_original_lines": list(LINES), "original_call_ids": CALL_IDS,
            "original_process_session_id": 3854, "original_process_exit_code": 1,
            "present_time_reservation_and_settlement": True,
            "atomic_two_event_publication": True, "original_budget_reader_unchanged": True,
            "scientific_compute_started": False, "tests_started": False,
            "scientific_input_reads": False, "counters_modified": False,
            "new_subprocesses": 0, "management_operations_are_not_scientific_compute": True,
            "duplicate_attempts_forbidden": True, "reason": REASON}


def source_identity():
    files = (Path(__file__), RULE, BINDING, FAILURE, ORIGINAL_HELPER)
    return {safe_path(path).relative_to(REPO).as_posix(): sha256(path) for path in files}


def require_approval(path, identity, sources):
    if not re.fullmatch("[0-9a-f]{64}", identity) or sha256(path) != identity:
        raise PermissionError("Independent approval bytes changed")
    review = read_json(path)
    expected = {"schema": "precip_unexpected_setup_debit_review_v01", "status": "PASS",
                "pass": True, "source_identity": sources, "rule_sha256": sha256(RULE),
                "ledger_before_sha256": BASELINE_SHA, "conservative_charge_seconds": CHARGE,
                "execution_scope": SCOPE}
    if (review.get("pass") is not True or type(review.get("conservative_charge_seconds")) is not int or
            any(review.get(key) != value for key, value in expected.items())):
        raise PermissionError("Exact exception debit lacks independent approval")
    return review


def original_entry():
    if sha256(ORIGINAL_HELPER) != ORIGINAL_HELPER_SHA:
        raise PermissionError("Original budget helper changed")
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location("_precip_original_budget_exception_v01", ORIGINAL_HELPER)
    if spec is None or spec.loader is None:
        raise ImportError("Direct original budget helper loading is unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    require_standard_library()
    if module.TRIAL_ROOT.resolve() != FAMILY.resolve():
        raise PermissionError("Original budget helper family differs")
    return module


def output_objects(record):
    result = []
    for block in record["payload"].get("output", []):
        if block.get("type") == "input_text":
            try:
                value = json.loads(block["text"])
            except (ValueError, TypeError):
                continue
            if isinstance(value, dict):
                result.append(value)
    return result


def original_proof():
    if sha256(BINDING) != BINDING_SHA or sha256(FAILURE) != FAILURE_SHA:
        raise PermissionError("Original exception preservation bytes changed")
    binding, failure = read_json(BINDING), read_json(FAILURE)
    if (binding.get("source_prefix_bytes") != PREFIX_BYTES or
            binding.get("source_prefix_sha256") != PREFIX_SHA or binding.get("call_ids") != CALL_IDS or
            binding.get("full_external_utc_bracket_seconds") != 315 or
            binding.get("proposed_conservative_charge_seconds") != CHARGE or
            binding.get("actual_monotonic_elapsed_seconds") is not None or
            binding.get("exact_import_setup_seconds") is not None or
            binding.get("original_output_exit_code") != 1 or
            binding.get("unmodified_original_tool_records") is not True):
        raise PermissionError("Original tool binding is not the frozen exception")
    source = safe_path(binding["source_path"], root=Path(binding["source_path"]).anchor)
    with source.open("rb") as stream:
        prefix = stream.read(PREFIX_BYTES)
    if len(prefix) != PREFIX_BYTES or digest(prefix) != PREFIX_SHA or not prefix.endswith(b"\n"):
        raise PermissionError("Complete original session prefix bytes changed")
    selected = binding["selected_original_records"]
    if [row["line"] for row in selected] != list(LINES):
        raise PermissionError("Original tool records are incomplete or reordered")
    raw_by_line = {}
    offset = 0
    wanted = set(LINES)
    for number, raw in enumerate(prefix.splitlines(keepends=True), 1):
        if number in wanted:
            raw_by_line[number] = (offset, raw)
        offset += len(raw)
    records, preserved = [], []
    previous_ordinal, previous_timestamp = None, None
    for index, row in enumerate(selected):
        raw_offset, raw = raw_by_line[row["line"]]
        if raw_offset != row["offset"] or len(raw) != row["bytes"] or digest(raw) != row["sha256"]:
            raise PermissionError("Selected record differs from its full original session prefix")
        path = safe_path(row["path"], root=META)
        if path.read_bytes() != raw:
            raise PermissionError("Preserved original tool record bytes changed")
        value = json.loads(raw)
        payload = value["payload"]
        timestamp = datetime.fromisoformat(value["timestamp"].replace("Z", "+00:00"))
        if (value["ordinal"] != row["ordinal"] or value["timestamp"] != row["timestamp"] or
                value["type"] != "response_item" or payload["type"] != row["payload_type"] or
                payload["call_id"] != row["call_id"] or
                payload.get("internal_chat_message_metadata_passthrough", {}).get("turn_id") != TURN_ID or
                (previous_ordinal is not None and value["ordinal"] <= previous_ordinal) or
                (previous_timestamp is not None and timestamp < previous_timestamp)):
            raise PermissionError("Original tool sequence, thread, or record identity changed")
        expected_call = CALL_IDS[("before_clock", "prelaunch", "exit_confirmation", "after_clock")[index // 2]]
        expected_type = "custom_tool_call" if index % 2 == 0 else "custom_tool_call_output"
        if payload["call_id"] != expected_call or payload["type"] != expected_type:
            raise PermissionError("Original tool call and return association differs")
        if index % 2 == 0 and payload.get("name") != "exec":
            raise PermissionError("Original tool call is not its preserved orchestration call")
        records.append(value)
        preserved.append((path.name, raw))
        previous_ordinal, previous_timestamp = value["ordinal"], timestamp
    before = output_objects(records[1])
    after = output_objects(records[7])
    if (before != [{"current_time": BEFORE_CLOCK}] or
            [value for value in after if "current_time" in value] != [{"current_time": AFTER_CLOCK}] or
            "tools.clock__curr_time({})" not in records[0]["payload"]["input"] or
            "tools.clock__curr_time({})" not in records[6]["payload"]["input"]):
        raise PermissionError("Original external clock calls and returned values differ")
    start = datetime.strptime(BEFORE_CLOCK, "%Y-%m-%d %H:%M:%S UTC").replace(tzinfo=timezone.utc)
    end = datetime.strptime(AFTER_CLOCK, "%Y-%m-%d %H:%M:%S UTC").replace(tzinfo=timezone.utc)
    if (end - start).total_seconds() != 315:
        raise PermissionError("Frozen coarse external UTC window differs")
    launch = records[2]["payload"]["input"]
    if ("tools.exec_command({cmd:" not in launch or
            "from precip_input_assimilation.scripts import run_precip_local_gradient_small_sample_v03 as prior" not in launch or
            "assert value['numerical_modules_imported']==[]" not in launch or
            "\"login\":false" not in launch):
        raise PermissionError("Original metadata prelaunch call differs")
    launched = output_objects(records[3])
    exited = output_objects(records[5])
    if (len(launched) != 1 or launched[0].get("session_id") != 3854 or
            "exit_code" in launched[0] or launched[0].get("output") != "" or
            not re.fullmatch(r'text\(await tools\.write_stdin\(\{session_id:3854,chars:"","yield_time_ms":10000,"max_output_tokens":2200\}\)\);\s*',
                             records[4]["payload"]["input"]) or
            len(exited) != 1 or exited[0].get("exit_code") != 1 or
            "AssertionError" not in exited[0].get("output", "") or
            'File "<stdin>", line 25' not in exited[0].get("output", "")):
        raise PermissionError("Exact original process session and failure exit association differs")
    if (failure.get("status") != "FAILED_METADATA_PRELAUNCH_BEFORE_MODEL_AND_BUDGET" or
            failure.get("process_command_exit_code") != 1 or
            failure.get("original_ledger_unchanged_sha256") != BASELINE_SHA or
            failure.get("model_test_or_scientific_array_operation_started") is not False or
            failure.get("no_model_no_tests_no_counter_or_budget_mutation") is not True or
            failure.get("exact_process_elapsed_seconds") is not None or
            failure.get("exact_unmetered_import_time_seconds") is not None):
        raise PermissionError("Preserved failure contradicts the exception scope or unknown timing")
    proof = {"source_path": str(source), "source_prefix_bytes": len(prefix),
             "source_prefix_sha256": digest(prefix), "all_original_records_match_full_prefix": True,
             "selected_original_records": selected, "call_ids": CALL_IDS, "original_turn_id": TURN_ID,
             "original_process_session_id": 3854, "original_process_exit_code": 1,
             "before_clock_original_return": BEFORE_CLOCK, "after_clock_original_return": AFTER_CLOCK,
             "external_utc_bracket_seconds": 315, "policy_padding_seconds": 1,
             "conservative_charge_seconds": CHARGE, "actual_setup_seconds": None,
             "actual_monotonic_elapsed_seconds": None, "clock_is_monotonic": False,
             "original_failure_sha256": FAILURE_SHA, "reason": REASON}
    return proof, prefix, preserved


class NativeOwner:
    """A retained handle to the current process object; no PID-only ownership."""

    def __init__(self):
        if os.name != "nt":
            raise PermissionError("Exception debit requires exact native Windows ownership")
        self.kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel = self.kernel
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetProcessId.argtypes = [wintypes.HANDLE]
        kernel.GetProcessId.restype = wintypes.DWORD
        kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
        kernel.GetProcessTimes.restype = wintypes.BOOL
        kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        kernel.GetExitCodeProcess.restype = wintypes.BOOL
        kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        kernel.WaitForSingleObject.restype = wintypes.DWORD
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel.CloseHandle.restype = wintypes.BOOL
        self.handle = kernel.OpenProcess(0x1000 | 0x00100000, False, os.getpid())
        if not self.handle:
            raise ctypes.WinError(ctypes.get_last_error())
        try:
            self.identity = self.snapshot()
        except BaseException:
            self.close()
            raise
        self.nonce = uuid.uuid4().hex
        self.record = None

    def snapshot(self):
        kernel = self.kernel
        pid = kernel.GetProcessId(self.handle)
        fields = [wintypes.FILETIME() for _ in range(4)]
        if not pid or not kernel.GetProcessTimes(self.handle, *(ctypes.byref(value) for value in fields)):
            raise ctypes.WinError(ctypes.get_last_error())
        code = wintypes.DWORD()
        if not kernel.GetExitCodeProcess(self.handle, ctypes.byref(code)):
            raise ctypes.WinError(ctypes.get_last_error())
        wait = kernel.WaitForSingleObject(self.handle, 0)
        creation = str((fields[0].dwHighDateTime << 32) | fields[0].dwLowDateTime)
        if pid != os.getpid() or code.value != 259 or wait != 258 or int(creation) <= 0:
            raise PermissionError("Exact own native process object is not confirmed running")
        return {"pid": int(pid), "windows_creation_identity": creation,
                "native_process_handle_retained": True, "native_query_succeeded": True}

    def require(self):
        require_standard_library()
        if self.snapshot() != self.identity:
            raise PermissionError("Own native creation identity changed")
        if self.record is not None and read_json(OUTPUT / "management_owner.json") != self.record:
            raise PermissionError("Immutable management owner creation identity or nonce changed")

    def close(self):
        if self.handle:
            if not self.kernel.CloseHandle(self.handle):
                raise ctypes.WinError(ctypes.get_last_error())
            self.handle = None


def write_new(path, data, owner):
    owner.require()
    path = safe_path(path, root=OUTPUT, exists=False)
    with path.open("xb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())


def require_actual_lock(owner):
    import msvcrt
    owner.require()
    with safe_path(FAMILY / "exclusive.lock").open("r+b") as probe:
        probe.seek(0)
        try:
            msvcrt.locking(probe.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError as error:
            if error.errno != errno.EACCES:
                raise
            return
        msvcrt.locking(probe.fileno(), msvcrt.LK_UNLCK, 1)
    raise PermissionError("Original actual exclusive family lock was not held")


def require_baseline(original):
    if os.path.lexists(FAMILY / "STOP"):
        raise InterruptedError("Manual family stop marker is present")
    if os.path.lexists(OUTPUT):
        raise FileExistsError("Exception debit output exists; repeat attempts are forbidden")
    data = safe_path(LEDGER).read_bytes()
    if digest(data) != BASELINE_SHA:
        raise PermissionError("Original ledger differs from the exact fully settled baseline")
    journal, used, allocations, settled = original.load_budget(LEDGER)
    if (used != BEFORE_USED or journal["total_seconds"] != TOTAL or len(journal["events"]) != 10 or
            len(allocations) != 5 or len(settled) != 5 or set(allocations) != set(settled)):
        raise PermissionError("Original ledger has an open or unexpected allocation")
    known_outputs = {str(Path(record["payload"]["output"]).resolve()) for record in allocations.values()}
    manifests = []

    def walk_error(error):
        raise error

    for directory, children, files in os.walk(FAMILY, followlinks=False, onerror=walk_error):
        for name in children:
            safe_path(Path(directory) / name, root=FAMILY, exists=False)
        if "manifest.json" in files:
            path = safe_path(Path(directory) / "manifest.json", root=FAMILY)
            if str(path.parent.resolve()) not in known_outputs:
                raise PermissionError("Family scientific manifest has no known budget allocation")
            manifests.append({"path": path.relative_to(REPO).as_posix(), "sha256": sha256(path)})
    manifests.sort(key=lambda row: row["path"])
    return data, journal, manifests


def execute(approval_path, approval_sha):
    require_standard_library()
    if read_json(RULE) != expected_rule():
        raise PermissionError("Exception debit rule differs from its fixed conservative policy")
    sources = source_identity()
    require_approval(approval_path, approval_sha, sources)
    proof, prefix, raw_records = original_proof()
    original = original_entry()
    owner = NativeOwner()
    try:
        owner.require()
        # The existing original lock file is required; no new family lock is invented.
        safe_path(FAMILY / "exclusive.lock")
        if sha256(ORIGINAL_HELPER) != ORIGINAL_HELPER_SHA:
            raise PermissionError("Original family lock implementation changed")
        with original.exclusive_trial_lock():
            require_actual_lock(owner)
            if source_identity() != sources:
                raise PermissionError("Reviewed sources changed before the locked transaction")
            require_approval(approval_path, approval_sha, sources)
            proof_again, prefix_again, raw_again = original_proof()
            if proof_again != proof or prefix_again != prefix or raw_again != raw_records:
                raise PermissionError("Original source proof changed during admission")
            before_bytes, journal, manifests = require_baseline(original)
            owner.require()
            safe_path(OUTPUT, root=META, exists=False)
            OUTPUT.mkdir()
            record = dict(owner.identity, nonce=owner.nonce, created_utc=utc(),
                          schema="precip_unexpected_setup_debit_owner_v01", execution_scope=SCOPE,
                          source_identity=sources, approval_sha256=approval_sha)
            write_new(OUTPUT / "management_owner.json", json_bytes(record), owner)
            owner.record = record
            write_new(OUTPUT / "budget_before_original_bytes.json", before_bytes, owner)
            write_new(OUTPUT / "original_session_prefix.jsonl", prefix, owner)
            owner.require()
            (OUTPUT / "original_tool_records").mkdir()
            for name, data in raw_records:
                write_new(OUTPUT / "original_tool_records" / name, data, owner)
            owner.require()
            (OUTPUT / "reviewed_sources").mkdir()
            for relative, expected in sources.items():
                data = safe_path(REPO / relative).read_bytes()
                if digest(data) != expected:
                    raise PermissionError("Source bytes changed during preservation")
                write_new(OUTPUT / "reviewed_sources" / Path(relative).name, data, owner)
            approval_bytes = safe_path(approval_path).read_bytes()
            if digest(approval_bytes) != approval_sha:
                raise PermissionError("Independent approval changed during preservation")
            write_new(OUTPUT / "independent_approval.json", approval_bytes, owner)
            proof["source_identity"] = sources
            proof["known_scientific_manifests"] = manifests
            proof_bytes = json_bytes(proof)
            write_new(OUTPUT / "source_proof.json", proof_bytes, owner)
            run_id = owner.nonce
            common = {"exception_reason": REASON, "exception_kind": "unexpected_unreserved_import",
                      "actual_setup_seconds": None, "actual_monotonic_elapsed_seconds": None,
                      "external_utc_bracket_seconds": 315, "policy_padding_seconds": 1,
                      "original_tool_binding_sha256": BINDING_SHA, "original_failure_sha256": FAILURE_SHA,
                      "source_proof_sha256": digest(proof_bytes), "owner_nonce": owner.nonce,
                      "owner_pid": owner.identity["pid"],
                      "owner_windows_creation_identity": owner.identity["windows_creation_identity"],
                      "recorded_now_not_historical_reservation": True}
            reserve_payload = dict(common, kind="reserve", run_id=run_id, output=str(OUTPUT.resolve()),
                                   reserved_seconds=CHARGE, used_before_seconds=BEFORE_USED,
                                   config_sha256=sources[RULE.relative_to(REPO).as_posix()],
                                   script_sha256=sources[Path(__file__).relative_to(REPO).as_posix()],
                                   started_utc=utc(), previous_sha256=journal["events"][-1]["sha256"])
            reservation = {"payload": reserve_payload, "sha256": original.budget_hash(reserve_payload)}
            settle_payload = dict(common, kind="settle", run_id=run_id, charged_seconds=CHARGE,
                                  reservation_sha256=reservation["sha256"], ended_utc=utc(),
                                  previous_sha256=reservation["sha256"])
            settlement = {"payload": settle_payload, "sha256": original.budget_hash(settle_payload)}
            candidate = dict(journal, events=journal["events"] + [reservation, settlement])
            if candidate["events"][:10] != journal["events"]:
                raise PermissionError("Original ten-event budget prefix changed")
            write_new(OUTPUT / "reservation_event.json", json_bytes(reservation), owner)
            write_new(OUTPUT / "settlement_event.json", json_bytes(settlement), owner)
            candidate_bytes = json_bytes(candidate)
            candidate_path = OUTPUT / "budget_candidate.json"
            write_new(candidate_path, candidate_bytes, owner)
            validated, used, allocations, settled = original.load_budget(candidate_path)
            if (validated != candidate or used != AFTER_USED or len(validated["events"]) != 12 or
                    len(allocations) != 6 or set(allocations) != set(settled)):
                raise PermissionError("Original unchanged reader rejected the complete candidate chain")
            # Both new events are published in one replace; no settlement-only ledger is possible.
            publish_path = OUTPUT / "budget_publication_candidate.json"
            write_new(publish_path, candidate_bytes, owner)
            owner.require()
            require_actual_lock(owner)
            if os.path.lexists(FAMILY / "STOP") or sha256(LEDGER) != BASELINE_SHA or source_identity() != sources:
                raise PermissionError("Locked ledger, stop marker, or reviewed sources changed before publication")
            require_approval(approval_path, approval_sha, sources)
            if sha256(publish_path) != digest(candidate_bytes):
                raise PermissionError("Publication candidate bytes changed")
            owner.require()
            os.replace(publish_path, safe_path(LEDGER))
            final, used, allocations, settled = original.load_budget(LEDGER)
            after_sha = sha256(LEDGER)
            if (final != candidate or after_sha != digest(candidate_bytes) or used != AFTER_USED or
                    final["events"][:10] != journal["events"] or set(allocations) != set(settled)):
                raise PermissionError("Published ledger failed original reader or prefix verification")
            owner.require()
            receipt = {"schema": "precip_unexpected_setup_debit_receipt_v01", "status": "COMMITTED",
                       "recorded_utc": utc(), "execution_scope": SCOPE, "owner": record,
                       "approval_sha256": approval_sha, "source_identity": sources,
                       "rule_sha256": sources[RULE.relative_to(REPO).as_posix()],
                       "original_tool_binding_sha256": BINDING_SHA, "original_failure_sha256": FAILURE_SHA,
                       "source_proof_sha256": digest(proof_bytes), "ledger_before_sha256": BASELINE_SHA,
                       "ledger_after_sha256": after_sha, "budget_candidate_sha256": digest(candidate_bytes),
                       "original_event_prefix_sha256": original.budget_hash(journal["events"]),
                       "original_event_prefix_preserved": True, "original_ledger_bytes_saved": True,
                       "original_event_count": 10, "new_event_count": 12,
                       "reservation": reservation, "settlement": settlement,
                       "charged_before_seconds": BEFORE_USED, "charged_after_seconds": used,
                       "conservative_charge_seconds": CHARGE, "remaining_seconds": TOTAL - used,
                       "total_seconds": TOTAL, "open_allocations": 0, "actual_setup_seconds": None,
                       "actual_monotonic_elapsed_seconds": None, "external_utc_bracket_seconds": 315,
                       "policy_padding_seconds": 1, "clock_is_monotonic": False,
                       "atomic_two_event_publication": True, "original_reader_validation_passed": True,
                       "actual_exclusive_family_lock_held": True, "scientific_compute_started": False,
                       "scientific_input_reads": False, "tests_started": False, "counters_modified": False,
                       "new_subprocesses": 0, "reason": REASON,
                       "management_operations_are_not_scientific_compute": True}
            write_new(OUTPUT / "receipt.json", json_bytes(receipt), owner)
            print(json.dumps({"receipt": str(OUTPUT / "receipt.json"),
                              "receipt_sha256": sha256(OUTPUT / "receipt.json"),
                              "charged_seconds": used, "remaining_seconds": TOTAL - used,
                              "actual_setup_seconds": None, "ledger_after_sha256": after_sha}, indent=2))
            return receipt
    finally:
        owner.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--approval", type=Path, required=True)
    parser.add_argument("--approval-sha256", required=True)
    parser.add_argument("--execute-reviewed-exception-debit", action="store_true")
    args = parser.parse_args()
    if not args.execute_reviewed_exception_debit:
        parser.error("Explicit reviewed exception-debit execution flag is required")
    execute(args.approval, args.approval_sha256)


if __name__ == "__main__":
    main()
