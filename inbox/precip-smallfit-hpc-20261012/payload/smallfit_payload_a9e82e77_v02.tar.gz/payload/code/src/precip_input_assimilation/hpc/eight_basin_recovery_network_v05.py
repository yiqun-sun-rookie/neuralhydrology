"""Add pinned native HTTP reads for immutable Git commits and trees.

The original JSON wire format, bounded reader, receipt validators, publication
protocol, admission, ownership lock and prior two migrations remain in force.
Native reads retain complete or failed wire evidence without exposing tokens.
"""

import argparse
import base64
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time
import urllib.error
import uuid

import eight_basin_recovery_network_v04 as previous


driver = previous.driver
bounded = previous.bounded
metadata = previous.previous
SCHEMA = "eight-basin-native-fixed-git-network-v5"
PREVIOUS_MIGRATION = "7810d6e7889d3315ca721a57e6b6e3e16ebd15f9bededf0bdd616843d121f947"
CURL_PATH = Path(r"C:\Windows\System32\curl.exe")
CURL_SHA256 = "73d24149ff289afc49ec41f08918ef9faa727d39ad993e929757dc2ddafab805"
METADATA = re.compile(r"git/(commits|trees)/([0-9a-f]{40})\Z")


def migration_guard(home, migration_path, migration_sha256):
    transport = driver.transport
    home = transport.no_link_ancestors(home)
    if transport.no_link_ancestors(migration_path) != home / "network_migration_v05.json":
        raise driver.IntegrityError("Native migration belongs to another recovery directory")
    parent = previous.migration_guard(home, home / "network_migration_v04.json", PREVIOUS_MIGRATION)
    raw = driver.regular_bytes(migration_path, transport.MAX_METADATA)
    if not driver.HEX64.fullmatch(migration_sha256) or driver.digest(raw) != migration_sha256:
        raise driver.IntegrityError("Externally pinned native migration SHA256 differs")
    migration = transport.parse_json(raw)
    if (migration["schema"] != SCHEMA or migration["previous_migration_sha256"] != PREVIOUS_MIGRATION or
            migration["original_admission_sha256"] != bounded.ORIGINAL_ADMISSION or
            migration["home"] != str(transport.display_path(home)) or
            migration["original_sources"] != parent["original_sources"] or
            driver.file_digest(Path(__file__)) != migration["network_source_sha256"] or
            driver.file_digest(Path(__file__).parents[1] / "tests/test_eight_basin_recovery_network_v05.py") !=
            migration["network_tests_sha256"] or migration["curl_executable"] != str(CURL_PATH) or
            migration["curl_sha256"] != CURL_SHA256 or driver.file_digest(CURL_PATH) != CURL_SHA256):
        raise driver.IntegrityError("Native overlay changed an admitted source or executable identity")
    predecessor = migration["predecessor"]
    state_raw = driver.regular_bytes(transport.safe_path(home, predecessor["state_file"]), transport.MAX_METADATA)
    index_raw = driver.regular_bytes(transport.safe_path(home, predecessor["receipt_index_file"]), transport.MAX_METADATA)
    state, index = transport.parse_json(state_raw), transport.parse_json(index_raw)
    if (driver.digest(state_raw) != predecessor["state_sha256"] or
            driver.digest(index_raw) != predecessor["receipt_index_sha256"] or
            state["admission_sha256"] != bounded.ORIGINAL_ADMISSION or state["cursor"] != predecessor["cursor"] or
            state["pending"] != predecessor["pending"] or len(index["records"]) != state["cursor"]):
        raise driver.IntegrityError("Native overlay predecessor changed")
    pointer = transport.parse_json(driver.regular_bytes(home / "cursor.json"))
    current_raw = driver.regular_bytes(transport.safe_path(home, pointer["state_file"]), transport.MAX_METADATA)
    current = transport.parse_json(current_raw)
    current_index_raw = driver.regular_bytes(transport.safe_path(home, current["receipt_index_file"]), transport.MAX_METADATA)
    current_index = transport.parse_json(current_index_raw)
    if (pointer["admission_sha256"] != bounded.ORIGINAL_ADMISSION or
            current["admission_sha256"] != bounded.ORIGINAL_ADMISSION or
            driver.digest(current_raw) != pointer["state_sha256"] or
            driver.digest(current_index_raw) != current["receipt_index_sha256"] or
            current["cursor"] < state["cursor"] or current["generation"] < state["generation"] or
            len(current_index["records"]) != current["cursor"] or
            current_index["records"][:state["cursor"]] != index["records"]):
        raise driver.IntegrityError("Native overlay reversed accepted requests")
    return migration


response_headers = previous.response_headers
read_wire_file = previous.read_wire_file


class NativeFixedGitMailbox(previous.NativeBlobMailbox):
    def __init__(self, home, guard, migration_sha256):
        super().__init__(home, guard, migration_sha256)
        migration = guard()
        owner = driver.transport.parse_json(driver.regular_bytes(self.home / "owner.json"))
        driver.immutable_json(self.home, self.home / "network_owners_v05" /
                              (str(owner["process"]["pid"]) + "_" + owner["process"]["creation"] + ".json"), {
                                  "process": owner["process"], "original_admission_sha256": bounded.ORIGINAL_ADMISSION,
                                  "migration_sha256": migration_sha256, "previous_migration_sha256": PREVIOUS_MIGRATION,
                                  "network_source_sha256": migration["network_source_sha256"],
                                  "curl_executable": migration["curl_executable"], "curl_sha256": migration["curl_sha256"]})

    def native_metadata_get(self, path):
        match = METADATA.fullmatch(path)
        if match is None:
            raise driver.IntegrityError("Native metadata reads require a fixed commit or tree")
        if not re.fullmatch(r"[A-Za-z0-9_]+", self._token):
            raise driver.IntegrityError("Credential cannot be safely passed to native reader")
        directory = driver.transport.safe_path(self.home, "native_wire_v05/" + uuid.uuid4().hex, exists=False)
        directory.mkdir(parents=True, exist_ok=False)
        body, header = directory / "body.bin", directory / "headers.bin"
        args = [str(CURL_PATH), "--disable", "--config", "-", "--silent", "--show-error", "--fail",
                "--http1.1", "--request", "GET", "--proto", "=https", "--no-location",
                "--connect-timeout", "20", "--max-time", "60", "--max-filesize", str(bounded.MAX_RESPONSE),
                "--header", "Accept: application/vnd.github+json", "--header", "Accept-Encoding: identity",
                "--header", "User-Agent: isolated-precip-filter", "--output", str(body), "--dump-header", str(header),
                "https://api.github.com/repos/" + driver.mailbox_module.REPO + "/" + path]
        config = ('header = "Authorization: Bearer ' + self._token + '"\n').encode("ascii")
        self.guard()
        result, execution_error = None, None
        try:
            result = subprocess.run(args, input=config, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                    timeout=65, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except (subprocess.TimeoutExpired, OSError) as error:
            execution_error = type(error).__name__
        self.guard()
        raw_header = driver.regular_bytes(header, bounded.READ_SIZE) if header.exists() else b""
        driver.immutable_json(self.home, directory / "execution.json", {
            "path": path, "method": "GET", "returncode": result.returncode if result else None,
            "execution_error_type": execution_error, "curl_sha256": CURL_SHA256,
            "headers_sha256": driver.digest(raw_header), "stderr_bytes": len(result.stderr) if result else None,
            "stderr_sha256": driver.digest(result.stderr) if result else None, "credential_in_arguments": False,
            "science_verified": False, "metadata_kind": match.group(1),
            "network_source_sha256": driver.file_digest(Path(__file__))})
        try:
            status, headers = response_headers(raw_header)
        except bounded.ResponseReadError as error:
            partial = read_wire_file(body, {}) if body.exists() else b""
            raise bounded.ResponseReadError(str(error), partial) from None
        if execution_error or result.returncode not in {0, 22}:
            raw = read_wire_file(body, {}) if body.exists() else b""
            raise bounded.ResponseReadError("Native response interrupted", raw,
                                            int(headers["Content-Length"]) if headers.get("Content-Length", "").isdigit() else None)
        if status != 200:
            if body.exists():
                read_wire_file(body, {})
            raise urllib.error.HTTPError(path, status, "Native mailbox HTTP error", {}, None)
        raw = read_wire_file(body, headers) if body.exists() else b""
        if result.returncode != 0:
            raise bounded.ResponseReadError("Native response failed", raw)
        try:
            value = json.loads(raw)
            if not isinstance(value, dict):
                raise ValueError("Invalid fixed Git metadata JSON structure")
            if value.get("sha") != match.group(2):
                raise driver.IntegrityError("Native fixed Git metadata identity differs")
            tree = value.get("tree")
            if match.group(1) == "trees":
                if value.get("truncated") is not False or not isinstance(tree, list):
                    raise driver.IntegrityError("Native fixed Git directory is incomplete")
            elif (not isinstance(tree, dict) or not isinstance(tree.get("sha"), str) or
                  not driver.HEX40.fullmatch(tree["sha"])):
                raise driver.IntegrityError("Native fixed Git commit has no bound tree")
            return value
        except (ValueError, UnicodeError, KeyError, TypeError) as error:
            raise bounded.ResponseReadError("Incomplete native fixed Git metadata JSON", raw) from error

    def api(self, path, method="GET", body=None, missing=False):
        if method == "GET" and path.startswith("contents/outbox/" + driver.transport.CHANNEL + "/"):
            if body is not None:
                raise driver.IntegrityError("Receipt metadata reads cannot contain a body")
            # Use the unchanged four-edge validator, routed through this reader.
            return metadata.receipt_metadata(self.api, path, missing)
        if method != "GET" or not METADATA.fullmatch(path):
            return super().api(path, method, body, missing)
        if body is not None:
            raise driver.IntegrityError("Immutable fixed Git metadata reads cannot contain a body")
        for attempt in range(3):
            try:
                return self.native_metadata_get(path)
            except urllib.error.HTTPError as error:
                if missing and error.code == 404:
                    return None
                raise RuntimeError(f"Mailbox API HTTP {error.code} at {path}") from None
            except bounded.ResponseReadError as error:
                self.record_read_failure(path, method, error)
                if attempt == 2:
                    raise RuntimeError(f"Mailbox response incomplete at {path}") from None
                time.sleep(attempt + 1)


def run(home, migration_path, migration_sha256, poll_seconds=45, once=False):
    guard = lambda: migration_guard(home, migration_path, migration_sha256)
    guard()
    original = driver.mailbox_module.Mailbox
    driver.mailbox_module.Mailbox = lambda: NativeFixedGitMailbox(home, guard, migration_sha256)
    try:
        return driver.run(home, bounded.ORIGINAL_ADMISSION, poll_seconds, once)
    finally:
        driver.mailbox_module.Mailbox = original


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["run"])
    parser.add_argument("--home", type=Path, required=True)
    parser.add_argument("--migration", type=Path, required=True)
    parser.add_argument("--migration-sha256", required=True)
    parser.add_argument("--poll-seconds", type=int, default=45)
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()
    print(json.dumps(run(args.home, args.migration, args.migration_sha256, args.poll_seconds, args.once)), flush=True)


if __name__ == "__main__":
    main()
