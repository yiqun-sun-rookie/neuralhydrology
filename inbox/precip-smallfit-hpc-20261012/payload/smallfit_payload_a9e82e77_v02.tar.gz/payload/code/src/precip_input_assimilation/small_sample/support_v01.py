"""Original-path replay and identity helpers for the reviewed small-window plan.

This module does not reserve budget or execute work on import. Its caller must
hold the family lock, reserve the stage's computation, and supply its deadline.
Original protected source, checkpoint, prediction and contract files are read-only.
"""

from collections import OrderedDict
import copy
from dataclasses import dataclass
from datetime import date
import hashlib
import json
import math
from pathlib import Path
import random
import time
from typing import Callable

import numpy as np
import torch
from torch import nn

from ..dynamic_filter.protocol import Phase
from ..dynamic_filter.stream import ObservationStream
from ..scripts import run_precip_effect_first_v02 as original


REPO = original.REPO
PILOT = original.TRIAL_ROOT / "pilot_20261009_01487000_s1001_s1002_s1003_v02"
PILOT_MANIFEST_SHA = "262cc6d8e947fb363a8c65ecbfc30b2b896bd6cf3a27c51443ec2d8df0926822"
PILOT_RESULT_SHA = "f262ed00910cffad781976ccf5ea2172aca935cb1369026962e0a9319adacc9c"
PILOT_REVIEW = original.TRIAL_ROOT / "result_audit_20261010_v01/independent_result_adversarial_review_v01.json"
PILOT_REVIEW_SHA = "cb5f6ca075741f8f5832c2456e626162216a15eb387805ced27490505c260095"
ORIGINAL_ENTRY_SHA = "fd38ecbd0b669a23665138574237ad383171b4249cfd40e36900658520387baa"
ORIGINAL_CONFIG_SHA = "673bbe20be9d8dc3140994477fccff15dbc64d93d0aeed7c43a793473835f5e2"
SMALL_START = date(1980, 10, 1)
SMALL_END = date(1980, 11, 2)
CONTROL_SHAPE = (32, 100)
write_json = original.write_json
sha256 = original.sha256


def _read_bound_json(path, expected):
    path = Path(path)
    if sha256(path) != expected:
        raise PermissionError(f"Recorded source bytes changed: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def tensor_digest(tensor):
    value = tensor.detach().cpu().contiguous()
    digest = hashlib.sha256()
    digest.update(str(value.dtype).encode())
    digest.update(json.dumps(list(value.shape)).encode())
    digest.update(value.numpy().tobytes())
    return digest.hexdigest()


def state_snapshot(module):
    return OrderedDict((name, value.detach().cpu().clone()) for name, value in module.state_dict().items())


def state_digest(module_or_state):
    state = module_or_state.state_dict() if isinstance(module_or_state, nn.Module) else module_or_state
    digest = hashlib.sha256()
    for name, tensor in state.items():
        digest.update(name.encode("utf-8"))
        digest.update(tensor_digest(tensor).encode("ascii"))
    return digest.hexdigest()


def source_initial_hash(module):
    """Exactly the original network_for pilot's parameter-only byte algorithm."""
    return hashlib.sha256(b"".join(parameter.detach().cpu().numpy().tobytes()
                                    for parameter in module.parameters())).hexdigest()


def rng_snapshot():
    return {"python": copy.deepcopy(random.getstate()), "numpy": copy.deepcopy(np.random.get_state()),
            "torch_cpu": torch.get_rng_state().clone(),
            "torch_cuda": [value.clone() for value in torch.cuda.get_rng_state_all()]
            if torch.cuda.is_available() else []}


def _digest_any(value, digest):
    if isinstance(value, torch.Tensor):
        digest.update(b"torch:")
        digest.update(tensor_digest(value).encode())
    elif isinstance(value, np.ndarray):
        digest.update(b"numpy:")
        digest.update(str(value.dtype).encode())
        digest.update(json.dumps(list(value.shape)).encode())
        digest.update(value.tobytes())
    elif isinstance(value, dict):
        digest.update(b"dict:")
        for key in sorted(value, key=lambda key: str(key)):
            _digest_any(key, digest)
            _digest_any(value[key], digest)
    elif isinstance(value, (tuple, list)):
        digest.update(("tuple:" if isinstance(value, tuple) else "list:").encode())
        for item in value:
            _digest_any(item, digest)
    else:
        digest.update((type(value).__name__ + ":" + repr(value) + ";").encode())


def rng_digest(value=None):
    digest = hashlib.sha256()
    _digest_any(rng_snapshot() if value is None else value, digest)
    return digest.hexdigest()


def restore_rng(value):
    random.setstate(value["python"])
    np.random.set_state(value["numpy"])
    torch.set_rng_state(value["torch_cpu"])
    if value["torch_cuda"]:
        if not torch.cuda.is_available() or len(value["torch_cuda"]) != torch.cuda.device_count():
            raise PermissionError("CUDA random-state device count changed")
        torch.cuda.set_rng_state_all(value["torch_cuda"])


def snapshot(module, optimizer=None):
    return {"state_dict": state_snapshot(module),
            "modes": {name: child.training for name, child in module.named_modules()},
            "rng": rng_snapshot(),
            "optimizer": None if optimizer is None else copy.deepcopy(optimizer.state_dict())}


def restore_snapshot(module, value, optimizer=None):
    module.load_state_dict(value["state_dict"], strict=True)
    children = dict(module.named_modules())
    if set(children) != set(value["modes"]):
        raise PermissionError("Module tree changed during isolated checks")
    # Set each flag directly: recursive eval/train would change descendant flags.
    for name, mode in value["modes"].items():
        children[name].training = mode
    if optimizer is not None:
        if value["optimizer"] is None:
            raise PermissionError("Optimizer restoration has no original state")
        optimizer.load_state_dict(value["optimizer"])
    elif value["optimizer"] is not None:
        raise PermissionError("Optimizer state was supplied without its optimizer")
    restore_rng(value["rng"])


def require_finite_state(module_or_state):
    value = module_or_state.state_dict() if isinstance(module_or_state, nn.Module) else module_or_state
    if isinstance(value, dict):
        for item in value.values():
            require_finite_state(item)
    elif isinstance(value, (tuple, list)):
        for item in value:
            require_finite_state(item)
    elif isinstance(value, (torch.Tensor, np.ndarray)):
        finite = torch.isfinite(value).all().item() if isinstance(value, torch.Tensor) else np.isfinite(value).all()
        if not finite:
            raise FloatingPointError("Nonfinite tensor in parameter, buffer or optimizer state")
    elif isinstance(value, float) and not math.isfinite(value):
        raise FloatingPointError("Nonfinite scalar in parameter or optimizer state")


def frozen_modes(hydro):
    if not hasattr(hydro, "frozen"):
        return {}
    return {name: child.training for name, child in hydro.frozen.model.named_modules()}


def assert_frozen_mode(hydro, expected_modes=None):
    if not hasattr(hydro, "frozen"):
        if expected_modes not in (None, {}):
            raise PermissionError("Expected frozen model is absent")
        return
    model = hydro.frozen.model
    if model.training or not model.lstm.training or model.dropout.training:
        raise PermissionError("Original frozen model recurrent/dropout execution modes changed")
    if expected_modes is not None and frozen_modes(hydro) != expected_modes:
        raise PermissionError("Frozen model internal module modes changed")
    if any(parameter.requires_grad or parameter.grad is not None for parameter in model.parameters()):
        raise PermissionError("Frozen model parameter gradients must remain disabled")
    hydro.require_unchanged()


@dataclass(frozen=True)
class Trajectory:
    loss: torch.Tensor
    predictions: tuple
    updates: tuple
    ledgers: tuple = ()

    @property
    def dates(self):
        return tuple(item.date for item in self.predictions)

    @property
    def cutoffs(self):
        return tuple(item.observation_cutoff for item in self.predictions)


class TableCorrector(nn.Module):
    """32 update-date rows, each containing 100 historical-rain actions."""
    def __init__(self, controls=None, device=None):
        super().__init__()
        device = ("cpu" if controls is None else controls.device) if device is None else device
        value = torch.zeros(CONTROL_SHAPE, dtype=torch.float32, device=device) if controls is None else controls
        if not isinstance(value, torch.Tensor) or tuple(value.shape) != CONTROL_SHAPE:
            raise ValueError("Control table must contain exactly 32 by 100 actions")
        if not torch.isfinite(value).all():
            raise FloatingPointError("Control table is nonfinite")
        self.controls = nn.Parameter(value.detach().clone().to(device=device, dtype=torch.float32))

    def forward(self, *args, **kwargs):
        raise PermissionError("Table controls require a fresh terminal-aware replay adapter")


class TerminalCorrector(nn.Module):
    """A fresh counter per replay; day 33 only retains the preceding ledger."""
    def __init__(self, corrector):
        super().__init__()
        self.corrector = corrector
        self.calls = 0

    def forward(self, features, weather, previous_applied, lag):
        current = self.calls
        if current >= 33:
            raise PermissionError("Diagnostic correction advanced beyond its 33 dates")
        self.calls += 1
        if current == 32:
            return previous_applied
        if isinstance(self.corrector, TableCorrector):
            if previous_applied.shape != (100,):
                raise ValueError("A control row does not match the original 100-day action shape")
            return self.corrector.controls[current]
        return self.corrector(features, weather, previous_applied, lag)


@dataclass
class Context:
    inputs: object
    scaling: object
    hydro: object
    device: object
    output: Path
    deadline: float
    require_unchanged: Callable
    contract: object = None
    runtime: dict = None
    original_summary: dict = None
    mode_reference: dict = None
    original_identity: dict = None

    def __post_init__(self):
        self.output = Path(self.output)
        self.device = torch.device(self.device)
        if self.mode_reference is None:
            self.mode_reference = frozen_modes(self.hydro)

    @property
    def small_phase(self):
        return Phase("fit", SMALL_START, SMALL_END)

    @property
    def small_values(self):
        return self.inputs.observations_for(self.small_phase)

    @property
    def small_weather(self):
        return self.inputs.weather_for(self.small_phase)

    def check(self):
        self.require_unchanged()
        if not math.isfinite(self.deadline) or time.monotonic() >= self.deadline - 300:
            raise TimeoutError("Inherited stage deadline reached its exit reserve")
        if (self.output / "STOP").exists():
            raise InterruptedError("Manual stop marker preserved")
        assert_frozen_mode(self.hydro, self.mode_reference)

    def factory(self, corrector):
        from ..dynamic_filter_multibasin.controller import replay_factory
        self.check()
        return original.StopAwareReplay(
            replay_factory(self.hydro, self.inputs, self.scaling, "rain", deadline=self.deadline - 300)(corrector),
            self.output / "STOP")

    def small_forward(self, corrector, capture=False):
        return small_forward(self, corrector, capture=capture)

    def new_network(self, seed):
        from ..dynamic_filter_multibasin.controller import network_for
        if seed not in (1001, 1002, 1003):
            raise PermissionError("Network initialization is not registered")
        self.check()
        module = network_for("rain", self.scaling, seed, str(self.device))
        if self.original_summary is not None:
            values = [row["initial_tensors_sha256"] for row in self.original_summary["fits"] if row["seed"] == seed]
            if len(values) != 2 or values[0] != values[1] or source_initial_hash(module) != values[0]:
                raise PermissionError("Original network initialization tensors were not reproduced")
        return module


def small_forward(ctx, corrector, capture=False):
    ctx.check()
    values, weather, phase = ctx.small_values, ctx.small_weather, ctx.small_phase
    if len(values) != 33 or tuple(weather.shape) != (33, 5) or not np.isfinite(values).all():
        raise ValueError("Fixed 33-day diagnostic requires complete finite observations and weather")
    if not np.isfinite(weather).all() or (weather[:, 0] < 0).any():
        raise ValueError("Fixed-window weather is nonfinite or has negative precipitation")
    adapter = TerminalCorrector(corrector)
    replay = ctx.factory(adapter)
    source = ObservationStream(phase, values)
    predictions, updates, ledgers, terms = [], [], [], []
    for index, (current, row) in enumerate(zip(phase.dates, weather, strict=True)):
        ctx.check()
        prediction = replay.predict(current, row)
        if prediction.date != current or prediction.observation_cutoff >= current:
            raise PermissionError("Prediction has an invalid observation information cutoff")
        observation = source.release(prediction)
        predictions.append(prediction)
        if index:
            target = prediction.tensor.new_tensor(observation.value)
            terms.append(((prediction.tensor - target) / ctx.scaling.flow_std).square())
        update = replay.observe(current, observation.value)
        updates.append(update)
        if capture and index < 32:
            ledgers.append(replay.applied.detach().clone())
    if source.consumed != 33 or adapter.calls != 33 or len(terms) != 32:
        raise PermissionError("Diagnostic did not consume its exact observation/control schedule")
    # Terminal proposal is the prior feasible ledger sliced on the new day;
    # the original projection must leave those values exactly unchanged.
    if not torch.equal(updates[-1].applied, updates[-1].proposal):
        raise PermissionError("Terminal observer changed an already feasible ledger")
    loss = torch.stack(terms).mean()
    if not torch.isfinite(loss):
        raise FloatingPointError("Nonfinite fixed-window flow objective")
    ctx.check()
    return Trajectory(loss, tuple(predictions), tuple(updates), tuple(ledgers))


def bounds(ctx):
    ctx.check()
    lower, upper = [], []
    for current in ctx.small_phase.dates[:32]:
        index = ctx.inputs.dates.index(current)
        raw = torch.as_tensor(np.asarray(ctx.inputs.weather[index - 99:index + 1, 0]).copy(),
                              dtype=torch.float32, device=ctx.device)
        if raw.shape != (100,) or not torch.isfinite(raw).all() or (raw < 0).any():
            raise ValueError("Original 100-day control window has incomplete weather")
        cap = raw.new_tensor(ctx.scaling.cap)
        lower.append(-torch.minimum(raw, cap))
        upper.append(cap.expand_as(raw))
    return torch.stack(lower), torch.stack(upper)


def create_context(output, deadline, require_unchanged):
    """Enter the same guarded inputs, scaling and numerical runtime as the pilot."""
    from ..dynamic_filter_multibasin.contract import Contract, DATES
    from ..dynamic_filter_multibasin.controller import configure_numerics, numerical_runtime
    from ..dynamic_filter_multibasin.data import build_input_gate, load_inputs
    from ..dynamic_filter_multibasin.hydro import BasinHydro
    from ..dynamic_filter_multibasin.identity import require_sources
    output = Path(output)
    if not output.is_dir():
        raise FileNotFoundError("Reserved stage output must already exist")
    if time.monotonic() >= deadline - 300 or (output / "STOP").exists():
        raise InterruptedError("Stage already stopped before input construction")
    require_unchanged()
    manifest = _read_bound_json(PILOT / "manifest.json", PILOT_MANIFEST_SHA)
    summary = _read_bound_json(PILOT / "pilot_result.json", PILOT_RESULT_SHA)
    review = _read_bound_json(PILOT_REVIEW, PILOT_REVIEW_SHA)
    required_original = [PILOT / "input_gate.json", original.ORIGINAL_ROOT / "local_input_preflight_v01/01487000_input_gate.json"]
    required_original.extend(PILOT / "fits" / row["arm"] / f"seed_{row['seed']}" / name
                             for row in summary["fits"]
                             for name in ("fit_summary.json", "selected.pt", "selected_validation_predictions.npy"))
    original_identity = {}
    for path in required_original:
        relative = path.relative_to(REPO).as_posix()
        expected_identity = review["artifact_identity"].get(relative)
        if expected_identity is None or sha256(path) != expected_identity:
            raise PermissionError("Original pilot replay sources differ from its independent actual review")
        original_identity[str(path)] = expected_identity
    if sha256(Path(original.__file__)) != ORIGINAL_ENTRY_SHA or sha256(original.CONFIG) != ORIGINAL_CONFIG_SHA:
        raise PermissionError("Reviewed original entry or paired-trial configuration changed")
    configure_numerics()
    runtime = numerical_runtime(REPO, "cuda:0")
    if runtime != manifest["runtime"]:
        raise PermissionError("Complete numerical runtime differs from the original pilot")
    original.verify_original_guard()
    require_sources(REPO, manifest["original_sources"])
    for path, identity in manifest["original_transport_identity"].items():
        if sha256(path) != identity:
            raise PermissionError("Original completed transport bytes changed")
    contract = Contract.load(REPO / "src/precip_input_assimilation/configs/dynamic_filter_eight_basins_v01.json")
    contract = contract.bind(roster_lock=original.ORIGINAL_ROOT / "roster_locked.json")
    # The original reader authorizes dates before parsing numerical values.
    inputs = load_inputs(contract, "01487000", end=DATES["select"][1])
    gate = build_input_gate(contract, "01487000", inputs)
    expected = json.loads((original.ORIGINAL_ROOT / "local_input_preflight_v01/01487000_input_gate.json").read_text(
        encoding="utf-8"))
    pilot_gate = json.loads((PILOT / "input_gate.json").read_text(encoding="utf-8"))
    if gate != expected or gate != pilot_gate or gate["pass"] is not True:
        raise PermissionError("Complete permitted input identity does not match original preflight")
    write_json(output / "input_gate.json", gate)
    scaling = original.matched_scaling(inputs, output / "input_gate.json", output)
    write_json(output / "strict_fresh_scaling.json", scaling.as_dict())
    require_unchanged()
    hydro = BasinHydro(contract, "01487000", device="cuda:0")
    expected_models = {row["frozen_model_tensor_sha256"] for row in summary["fits"]}
    if expected_models != {hydro.state_hash()}:
        raise PermissionError("Frozen model tensors differ from the original pilot")
    ctx = Context(inputs, scaling, hydro, "cuda:0", output, deadline, require_unchanged,
                  contract=contract, runtime=runtime, original_summary=summary,
                  original_identity=original_identity)
    ctx.check()
    write_json(output / "context_identity.json", {
        "runtime": runtime, "runtime_strict_equal": True,
        "pilot_manifest_sha256": PILOT_MANIFEST_SHA, "pilot_result_sha256": PILOT_RESULT_SHA,
        "original_entry_sha256": ORIGINAL_ENTRY_SHA, "original_config_sha256": ORIGINAL_CONFIG_SHA,
        "pilot_review_sha256": PILOT_REVIEW_SHA, "original_replay_source_identity": original_identity,
        "original_protected_sources": manifest["original_sources"],
        "original_transport_identity": manifest["original_transport_identity"],
        "input_gate_sha256": sha256(output / "input_gate.json"), "scaling": scaling.as_dict(),
        "frozen_state_sha256": hydro.state_hash(), "frozen_modes": ctx.mode_reference,
        "score_numeric_reads_started": False, "new_hpc_jobs": 0})
    return ctx


def metrics(values, predicted, scaling):
    values, predicted = np.asarray(values), np.asarray(predicted)
    if values.shape != predicted.shape or not np.isfinite(predicted).all():
        raise ValueError("Prediction shape or finiteness changed")
    mask = np.isfinite(values)
    if not mask.any():
        raise ValueError("No finite fitting targets")
    errors = predicted[mask] - values[mask]
    mse = float(np.mean(errors ** 2))
    denominator = float(np.sum((values[mask] - np.mean(values[mask])) ** 2))
    return {"days": int(len(values)), "finite_days": int(mask.sum()),
            "mse_mm2_day2": mse, "rmse_mm_day": math.sqrt(mse),
            "normalized_mse": mse / scaling.flow_std ** 2,
            "nse": None if denominator <= 0 else 1. - float(np.sum(errors ** 2)) / denominator}


def _save_array(path, value):
    value = np.asarray(value)
    np.save(path, value, allow_pickle=False)
    loaded = np.load(path, allow_pickle=False)
    if loaded.shape != value.shape or loaded.dtype != value.dtype or not np.array_equal(loaded, value, equal_nan=True):
        raise PermissionError("Saved replay array failed byte/shape/type reconstruction")
    return {"file": str(path), "sha256": sha256(path), "dtype": str(value.dtype), "shape": list(value.shape)}


def stage_one(ctx):
    """Six safe weight reloads and original four-year + one-year continuous replay."""
    from ..dynamic_filter import training
    from ..dynamic_filter_multibasin.contract import DATES
    ctx.check()
    if ctx.original_summary is None or ctx.contract is None:
        raise PermissionError("Stage one requires original verified pilot context")
    fit, select = (Phase(name, *DATES[name]) for name in ("fit", "select"))
    if len(fit.dates) != 1461 or len(select.dates) != 365:
        raise PermissionError("Original replay windows changed")
    root = ctx.output / "six_weight_replay"
    root.mkdir(exist_ok=False)
    targets = {"fit": ctx.inputs.observations_for(fit), "select": ctx.inputs.observations_for(select)}
    target_files = {name: _save_array(root / f"{name}_observations.npy", values)
                    for name, values in targets.items()}
    dates = {"fit": [str(day) for day in fit.dates], "select": [str(day) for day in select.dates]}
    write_json(root / "dates.json", dates)
    dates_identity = {"file": str(root / "dates.json"), "sha256": sha256(root / "dates.json")}
    context_identity = {"file": str(ctx.output / "context_identity.json"),
                        "sha256": sha256(ctx.output / "context_identity.json")}
    reservation_path = ctx.output / "budget_reservation.json"
    reservation_identity = {"file": str(reservation_path), "sha256": sha256(reservation_path)}
    records = []
    for recorded in ctx.original_summary["fits"]:
        ctx.check()
        arm, seed = recorded["arm"], recorded["seed"]
        if arm not in original.EXPECTED_ARMS or seed not in (1001, 1002, 1003):
            raise PermissionError("Original checkpoint group is not registered")
        old = PILOT / "fits" / arm / f"seed_{seed}"
        checkpoint_path = old / "selected.pt"
        if ctx.original_identity is None or any(sha256(path) != identity for path, identity in
                ctx.original_identity.items()):
            raise PermissionError("Original independent replay source identities changed")
        if sha256(checkpoint_path) != recorded["checkpoint_sha256"]:
            raise PermissionError("Original selected checkpoint bytes changed")
        fit_summary = json.loads((old / "fit_summary.json").read_text(encoding="utf-8"))
        if fit_summary != recorded:
            raise PermissionError("Original fit summary differs from the bound pilot result")
        checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=True)
        required = {"state_dict", "seed", "epoch", "validation_nse", "loss_weights", "config_sha256",
                    "input_gate_sha256", "original_input_contract_sha256"}
        if not isinstance(checkpoint, dict) or set(checkpoint) != required:
            raise PermissionError("Checkpoint does not contain its exact original metadata")
        expected = {"seed": seed, "epoch": recorded["best_epoch"], "validation_nse": recorded["validation_nse"],
                    "loss_weights": original.EXPECTED_ARMS[arm], "config_sha256": ORIGINAL_CONFIG_SHA,
                    "input_gate_sha256": sha256(PILOT / "input_gate.json"),
                    "original_input_contract_sha256": ctx.contract.sha256}
        if {key: checkpoint[key] for key in expected} != expected:
            raise PermissionError("Checkpoint source, selection or contract metadata changed")
        network = ctx.new_network(seed)
        desired = network.state_dict()
        state = checkpoint["state_dict"]
        if list(state) != list(desired) or any(not isinstance(state[name], torch.Tensor) or
                state[name].shape != desired[name].shape or state[name].dtype != desired[name].dtype for name in desired):
            raise PermissionError("Checkpoint tensor names, shapes or dtypes changed")
        require_finite_state(state)
        network.load_state_dict(state, strict=True)
        if state_digest(network) != state_digest(state):
            raise PermissionError("Selected tensors changed on loading to the original device")
        network.eval()  # Do not eval() the frozen hydrology model.
        replay = ctx.factory(network)
        fit_predictions = training.replay_phase(replay, fit, ctx.inputs.weather_for(fit), targets["fit"])
        select_predictions = training.replay_phase(replay, select, ctx.inputs.weather_for(select), targets["select"])
        saved = np.load(old / "selected_validation_predictions.npy", allow_pickle=False)
        destination = root / arm / f"seed_{seed}"
        destination.mkdir(parents=True, exist_ok=False)
        artifacts = {"fit_predictions": _save_array(destination / "fit_predictions.npy", fit_predictions),
                     "select_predictions": _save_array(destination / "select_predictions.npy", select_predictions)}
        same = select_predictions.shape == saved.shape == (365,) and select_predictions.dtype == saved.dtype and \
            np.array_equal(select_predictions, saved)
        record = {"arm": arm, "seed": seed, "selected_epoch": checkpoint["epoch"],
                  "checkpoint_sha256": sha256(checkpoint_path), "state_digest": state_digest(network),
                  "checkpoint_path": str(checkpoint_path),
                  "old_summary_path": str(old / "fit_summary.json"),
                  "old_summary_sha256": sha256(old / "fit_summary.json"),
                  "old_predictions_path": str(old / "selected_validation_predictions.npy"),
                  "old_predictions_sha256": sha256(old / "selected_validation_predictions.npy"),
                  "strict_shape_dtype_value_equal": bool(same),
                  "fit_metrics": metrics(targets["fit"], fit_predictions, ctx.scaling),
                  "select_metrics": metrics(targets["select"], select_predictions, ctx.scaling),
                  "artifacts": artifacts, "frozen_modes": frozen_modes(ctx.hydro),
                  "dates": dates_identity, "flow_std": ctx.scaling.flow_std,
                  "target_files": target_files, "context_identity": context_identity,
                  "budget_reservation": reservation_identity,
                  "score_numeric_reads_started": False, "new_optimizer_created": False}
        write_json(destination / "replay_identity.json", record)
        records.append(record)
        write_json(root / "progress.json", {"records": records, "target_files": target_files})
        ctx.check()
        if not same:
            raise PermissionError("Selected-weight validation replay is not strictly identical; evidence preserved")
        if record["select_metrics"]["nse"] != recorded["validation_nse"]:
            raise PermissionError("Replayed validation metric differs from original exact score")
        del replay, network, checkpoint, state
    if len(records) != 6 or len({(row["arm"], row["seed"]) for row in records}) != 6:
        raise PermissionError("Stage one must verify all six distinct selected checkpoints")
    result = {"schema": "precip_small_sample_weight_replay_v01", "all_six_strict_replays_passed": True,
              "execution_complete": True,
              "records": records, "target_files": target_files, "dates": dates_identity,
              "flow_std": ctx.scaling.flow_std, "context_identity": context_identity,
              "budget_reservation": reservation_identity, "score_numeric_reads_started": False,
              "independent_actual_review_complete": False}
    write_json(ctx.output / "stage_one_result.json", result)
    ctx.check()
    return result
