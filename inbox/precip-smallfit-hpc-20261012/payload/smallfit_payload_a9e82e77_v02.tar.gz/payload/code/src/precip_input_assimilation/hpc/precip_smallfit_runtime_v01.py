"""Linux IPC owner, inherited operation chain and the remaining original budget."""
import hashlib
import json
import math
from multiprocessing.connection import Client
import os
from pathlib import Path
import time
import uuid

from precip_input_assimilation.small_sample.flexible_budget_v04 import CounterStore, digest
from precip_input_assimilation.scripts.run_precip_effect_first_v02 import budget_hash, load_budget


def write_json(path, value, *, replace=False):
    path = Path(path)
    raw = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()
    if replace:
        temp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
        with temp.open("xb") as f:
            f.write(raw); f.flush(); os.fsync(f.fileno())
        os.replace(temp, path)
    else:
        with path.open("xb") as f:
            f.write(raw); f.flush(); os.fsync(f.fileno())


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def validate_exploration(audit):
    if not (audit.get("independent_checks_passed") is True and audit.get("pass") is False
            and audit.get("raw_trajectories_checked") == 90 and audit.get("objective_directions_checked") == 18
            and audit.get("independent_model_replays") == 2 and audit.get("new_audit_forward_count") == 2
            and audit.get("scientific_context_bridge", {}).get("complete_metadata_strictly_equal") is True):
        raise PermissionError("Complete actual original audit and exact bases are required")
    rows = audit["decisions"]
    mse = [r for r in rows if r["objective"] == "pure_flow_mse"]
    keys = {(r["group"], r["direction_index"]) for r in mse}
    expected = {(g, i) for g in ("output_parameters", "encoder_parameters", "middle_parameters") for i in range(3)}
    failed = {(r["group"], r["direction_index"]) for r in rows if r["status"] != "PASS"}
    if len(rows) != 18 or len(mse) != 9 or keys != expected or any(r["status"] != "PASS" or r["effective"] is not True for r in mse):
        raise PermissionError("The nine actual training-loss directions must all independently pass")
    if failed != {("encoder_parameters", 0), ("encoder_parameters", 2), ("middle_parameters", 1)}:
        raise PermissionError("Original negative records must remain exactly unchanged")
    terminal = [r for r in rows if r["objective"] == "terminal_output"]
    if len(terminal) != 9 or any(r["status"] not in ("PASS", "NOT_CONVERGED") for r in terminal):
        raise PermissionError("Original terminal decisions were replaced")
    if set(audit.get("adjoint_counts", {})) != {"terminal_output", "pure_flow_mse"}:
        raise PermissionError("Both original complete adjoint inventories are required")
    for row in audit["adjoint_counts"].values():
        if row["positions"] != 3200 or row["missing"] or row["nonfinite"]:
            raise PermissionError("The complete 3200-position chain is required")
    return {"exploratory_fit_admitted": True, "training_loss_pass_count": 9,
            "original_full_gradient_pass": False, "preserved_not_converged": sorted(failed),
            "seed_scope": [1001], "formal_forecast_claim_allowed": False}


class Owner:
    def __init__(self, root, manifest):
        self.root, self.manifest = Path(root).resolve(), manifest
        self.owner_pid = os.getpid()
        self.owner_start = Path("/proc/self/stat").read_text().rsplit(")", 1)[1].split()[19]
        self.last_progress = 0.

    def check(self):
        if os.getpid() != self.owner_pid or Path("/proc/self/stat").read_text().rsplit(")", 1)[1].split()[19] != self.owner_start:
            raise PermissionError("Linux owner creation identity changed")
        if (self.root / "STOP").exists() or (self.root.parent / "STOP").exists():
            raise InterruptedError("Manual STOP remains in force")

    def verify_sources(self):
        self.check()
        payload = self.root / "payload"
        for item in self.manifest["files"]:
            rel = Path(item["path"])
            if rel.is_absolute() or ".." in rel.parts:
                raise PermissionError("Payload path escapes its private root")
            p = payload / rel
            if p.is_symlink() or p.resolve() != p.absolute() or p.stat().st_size != item["bytes"] or sha(p) != item["sha256"]:
                raise PermissionError("Original/private payload source changed: " + str(rel))

    def verify_dependencies(self):
        """Full installed identities at import admission and final closure only."""
        path = self.root / "records/private_dependencies.json"
        if sha(path) != self.manifest["dependency_manifest_sha256"]:
            raise PermissionError("Private dependency manifest identity changed")
        document = json.loads(path.read_text())
        site = self.root / "pysite"
        expected_paths = {row["path"] for row in document["files"]}
        actual_paths = {p.relative_to(site).as_posix() for p in site.rglob("*") if p.is_file()}
        if actual_paths != expected_paths:
            raise PermissionError("Private dependency file inventory changed")
        for row in document["files"]:
            rel = Path(row["path"])
            if rel.is_absolute() or ".." in rel.parts:
                raise PermissionError("Private dependency escapes its deployment")
            p = site / rel
            if p.is_symlink() or p.stat().st_size != row["bytes"] or sha(p) != row["sha256"]:
                raise PermissionError("Installed private dependency bytes changed")


class Budget:
    def __init__(self, root, manifest, owner):
        self.root, self.owner = Path(root), owner
        self.path = self.root / "runtime/budget.json"
        self.manifest = manifest
        original = self.root / "payload/records/budget_handoff.json"
        if sha(original) != manifest["budget_handoff_sha256"]:
            raise PermissionError("Original handoff budget bytes changed")
        journal, used, alloc, settled = load_budget(original)
        self.run_id = manifest["budget_reservation_id"]
        if set(alloc) - set(settled) != {self.run_id} or alloc[self.run_id]["sha256"] != manifest["budget_reservation_sha256"]:
            raise PermissionError("Only the exact inherited HPC reservation may be open")
        self.reserved = alloc[self.run_id]["payload"]["reserved_seconds"]
        remaining = 259200 - used + self.reserved
        if remaining != manifest["remaining_seconds"] or remaining <= 300:
            raise PermissionError("Cumulative remaining budget changed")
        self.journal = journal
        self.started = self.slice_started = time.monotonic()
        self.global_deadline = self.started + remaining
        write_json(self.path, journal)

    def append(self, event):
        event = dict(event, previous_sha256=self.journal["events"][-1]["sha256"])
        record = {"payload": event, "sha256": budget_hash(event)}
        self.journal["events"].append(record)
        write_json(self.path, self.journal, replace=True)
        return record

    def settle_slice(self):
        charged = math.ceil(time.monotonic() - self.slice_started)
        if charged > self.reserved:
            raise TimeoutError("The active original budget reservation was exceeded")
        allocation = next(r for r in self.journal["events"] if r["payload"].get("kind") == "reserve" and r["payload"]["run_id"] == self.run_id)
        return self.append({"kind": "settle", "run_id": self.run_id, "charged_seconds": charged,
                            "reservation_sha256": allocation["sha256"], "clock_domain": "hpc_monotonic",
                            "job_id": os.environ["SLURM_JOB_ID"]})

    def tick(self):
        self.owner.check()
        if time.monotonic() >= self.global_deadline - 300:
            raise TimeoutError("Original total budget reached its exit reserve")
        if time.monotonic() - self.slice_started >= self.reserved - 300:
            self.settle_slice()
            _, used, _, _ = load_budget(self.path)
            remaining = 259200 - used
            self.run_id = self.manifest["run_id"] + "/slice_" + uuid.uuid4().hex
            self.reserved = min(21600, remaining)
            self.append({"kind": "reserve", "run_id": self.run_id, "reserved_seconds": self.reserved,
                         "clock_domain": "hpc_monotonic", "job_id": os.environ["SLURM_JOB_ID"]})
            self.slice_started = time.monotonic()
            self.global_deadline = self.slice_started + remaining
        return {"global_deadline": self.global_deadline, "remaining_seconds": self.global_deadline - time.monotonic()}

    def close(self):
        self.settle_slice()
        _, used, allocations, settled = load_budget(self.path)
        if set(allocations) - set(settled):
            raise RuntimeError("A budget reservation remained open after worker exit")
        return {"used_seconds": used, "remaining_seconds": 259200 - used,
                "budget_sha256": sha(self.path), "worker_exit_before_settlement": True}


class Authority:
    def __init__(self, root, manifest, owner, budget):
        self.root, self.manifest, self.owner, self.budget = Path(root), manifest, owner, budget
        self.store = CounterStore(self.root / "runtime/counters", manifest["counter_binding"], owner.check)
        self.store.reopen(manifest["counter_snapshot_digest"], manifest["counter_head_sha256"],
                          manifest["counter_event_count"], manifest["counter_initialization_evidence_sha256"])
        self.attempts = {}

    def handle(self, message):
        operation = message["operation"]
        budget = self.budget.tick()
        if operation == "checkpoint":
            if message.get("full"):
                self.owner.verify_sources()
            return budget
        if operation == "counter_snapshot":
            return self.store.snapshot()
        if operation == "consume":
            key, kind = message["key"], message["kind"]
            attempt = message["attempt_id"] if kind == "audit_reconstruction" else self.manifest["run_id"] + "/" + key
            if attempt not in self.attempts:
                stage = "audit_reconstruction" if kind == "audit_reconstruction" else ("direct_science_update" if key == "direct_control" else "network_1001_science_update")
                if key not in ("direct_control", "seed_1001") and kind != "audit_reconstruction":
                    raise PermissionError("Only direct controls and seed1001 are authorized")
                self.store.admit_attempt(attempt, uuid.uuid4().hex, self.manifest["science_source_digest"], stage,
                                         self.attempts.get(attempt))
                self.attempts[attempt] = True
            return self.store.consume(kind, key, message["label"], message.get("bindings"),
                                      attempt_id=attempt, operation_nonce=uuid.uuid4().hex)
        if operation == "bind_audit":
            attempt, binding, updates = message["attempt_id"], message["binding"], message["updates"]
            if attempt in self.attempts or not updates:
                raise PermissionError("Audit binding must be unique and nonempty")
            value = {"saved_path": binding["saved_path"], "saved_path_sha256": binding["saved_path_sha256"], "updates": updates}
            self.store.admit_attempt(attempt, uuid.uuid4().hex, self.manifest["science_source_digest"], "audit_reconstruction", value)
            self.attempts[attempt] = True
            return value
        raise PermissionError("Unknown private worker operation")


class RuntimeClient:
    def __init__(self, root, nonce):
        self.connection = Client(str(Path(root) / "runtime/owner.sock"), family="AF_UNIX", authkey=bytes.fromhex(nonce))
        self.global_deadline = self.call({"operation": "checkpoint"})["global_deadline"]

    def call(self, value):
        self.connection.send(value)
        result = self.connection.recv()
        if not result.get("ok"):
            raise RuntimeError(result.get("error", "Parent owner failed"))
        data = result["value"]
        if isinstance(data, dict) and "global_deadline" in data:
            self.global_deadline = data["global_deadline"]
        return data

    def checkpoint(self, *, full=False):
        return self.call({"operation": "checkpoint", "full": full})

    def counter_snapshot(self):
        return self.call({"operation": "counter_snapshot"})

    def consume(self, kind, key, label, bindings=None):
        return self.call({"operation": "consume", "kind": kind, "key": key, "label": label,
                          "bindings": bindings or {}, "attempt_id": key})

    def bind_audit(self, attempt_id, binding, updates):
        return self.call({"operation": "bind_audit", "attempt_id": attempt_id, "binding": binding, "updates": updates})


class Guard:
    def __init__(self, client):
        self.client = client

    def __call__(self, numerical=True, begin_operation=True):
        return self.client.checkpoint()

    def verify_full_preservation(self, begin_operation=True):
        return self.client.checkpoint(full=True)
