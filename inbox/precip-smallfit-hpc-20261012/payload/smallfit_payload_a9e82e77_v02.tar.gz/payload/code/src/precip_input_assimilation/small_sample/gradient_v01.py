"""Fail-closed, versioned checks of the original small-window correction graph.

Nothing in this module executes on import.  The caller must already own the
family lock, reserve this stage's time, and verify the six historical replays.
All numerical work is bounded by Context.deadline and keeps its raw proofs.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
import hashlib
import json
import math
from pathlib import Path
import time

import numpy as np
import torch
from torch import nn

from ..dynamic_filter.network import project_rain
from ..dynamic_filter.stream import ObservationStream


SEED = 1001
PARAMETER_SCALES = (0.0001, 0.001, 0.01)
MIN_RESPONSE = 0.001
RELATIVE_LIMIT = 0.05
TARGET_INDICES = (1, 16, 32)  # predictions[0] is the uncorrected initial day.
UPDATE_DATES = tuple(date(1980, 10, 1) + timedelta(days=i) for i in range(32))
TERMINAL_DATE = date(1980, 11, 2)


class GradientStageFailure(RuntimeError):
    """Evidence is preserved, but later fitting stages must not start."""


def _json_write(path, content):
    Path(path).write_text(json.dumps(content, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def _cpu(value):
    if torch.is_tensor(value):
        return value.detach().cpu().clone()
    if isinstance(value, np.ndarray):
        # Keep NumPy's actual dtype and byte identity, including MT19937 uint32
        # random-state arrays which this Torch version cannot represent directly.
        return {"numpy_dtype": str(value.dtype), "shape": list(value.shape),
                "bytes_hex": value.tobytes(order="C").hex()}
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {k: _cpu(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return type(value)(_cpu(v) for v in value)
    if isinstance(value, (date, Path)):
        return str(value)
    return value


def _sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(65536), b""):
            digest.update(block)
    return digest.hexdigest()


def _synchronize(ctx):
    if torch.device(ctx.device).type == "cuda":
        torch.cuda.synchronize(ctx.device)


def _before(ctx, label):
    _synchronize(ctx)
    if time.monotonic() >= ctx.deadline - 300:
        raise TimeoutError(f"No new gradient computation in the final 300 seconds: {label}")
    ctx.require_unchanged()


def _after(ctx, label, began):
    _synchronize(ctx)
    elapsed = time.perf_counter() - began
    ctx.require_unchanged()
    if time.monotonic() >= ctx.deadline:
        raise TimeoutError(f"Gradient computation crossed the reserved deadline: {label}")
    return elapsed


def _forward(ctx, corrector, label, capture=True):
    _before(ctx, label)
    began = time.perf_counter()
    trajectory = ctx.small_forward(corrector, capture=capture)
    seconds = _after(ctx, label, began)
    require_calendar(trajectory)
    if not torch.isfinite(trajectory.loss):
        raise GradientStageFailure(f"Nonfinite pure flow loss in {label}")
    return trajectory, seconds


def _normalized_output(ctx, prediction):
    return (prediction.tensor - ctx.scaling.flow_mean) / ctx.scaling.flow_std


def require_calendar(trajectory):
    """Reject off-by-one supervision and any premature observation release."""
    expected = UPDATE_DATES + (TERMINAL_DATE,)
    if len(trajectory.predictions) != 33 or len(trajectory.updates) != 33:
        raise GradientStageFailure("The registered window needs exactly 33 predictions and observations")
    for index, (pred, update) in enumerate(zip(trajectory.predictions, trajectory.updates, strict=True)):
        current = expected[index]
        if (pred.date != current or update.as_of_date != current or not pred.locked or
                pred.observation_cutoff != current - timedelta(days=1)):
            raise GradientStageFailure("Prediction/update calendar or information cutoff differs")
        dates = tuple(current - timedelta(days=99 - lag) for lag in range(100))
        if tuple(update.rain_dates) != dates:
            raise GradientStageFailure("Update rows are not the current and preceding 99 dates")
        if update.missing:
            raise GradientStageFailure("A registered observation is missing")
        for name in ("raw", "proposal", "applied", "violation"):
            tensor = getattr(update, name)
            if tensor.shape != (100,) or not torch.isfinite(tensor).all():
                raise GradientStageFailure(f"Malformed/nonfinite {name} in update {current}")
        if not torch.isfinite(pred.tensor):
            raise GradientStageFailure("Nonfinite predicted flow")


def branches(trajectory):
    """Return all 3,200 projection branches; equality is never smooth."""
    require_calendar(trajectory)
    pieces = []
    for update in trajectory.updates[:32]:
        cap = update.proposal.new_tensor(update.cap)
        lower = -torch.minimum(update.raw, cap)
        proposal = update.proposal.detach()
        branch = torch.full_like(proposal, 2, dtype=torch.int8)
        branch[proposal < lower] = 0
        branch[proposal == lower] = 1
        branch[proposal == cap] = 3
        branch[proposal > cap] = 4
        pieces.append(branch.cpu())
    return torch.stack(pieces)


def classify_direction(automatic, finite_differences, usable=None):
    """Apply the registered relative-only rule without hiding zero derivatives.

    All usable adjacent pairs and all amplitudes are retained.  Any disagreement
    at an informative amplitude fails, even if another scale pair agrees.
    """
    automatic = float(automatic)
    values = tuple(None if v is None else float(v) for v in finite_differences)
    if len(values) != 3:
        raise ValueError("Exactly three pre-registered perturbation scales are required")
    usable = tuple(v is not None for v in values) if usable is None else tuple(bool(v) for v in usable)
    if len(usable) != 3:
        raise ValueError("Scale validity must have length three")
    record = {"automatic": automatic if math.isfinite(automatic) else None,
              "finite_differences": [v if v is None or math.isfinite(v) else None for v in values],
              "usable": list(usable), "stable_pairs": [], "effective": False}
    if not math.isfinite(automatic) or any(v is not None and not math.isfinite(v) for v in values):
        record["status"] = "NONFINITE"
        return record
    present = [v for v, allowed in zip(values, usable, strict=True) if allowed and v is not None]

    def same_sign(a, b):
        return a * b > 0

    def close(a, b):
        return abs(a - b) <= RELATIVE_LIMIT * max(abs(a), abs(b))

    # Informative incompatible scales must not disappear by choosing a good pair.
    informative_disagreement = any(
        max(abs(automatic), abs(v)) >= MIN_RESPONSE and
        (not same_sign(automatic, v) or not close(automatic, v)) for v in present)
    for left in (0, 1):
        right = left + 1
        a, b = values[left], values[right]
        if usable[left] and usable[right] and a is not None and b is not None and same_sign(a, b) and close(a, b):
            record["stable_pairs"].append([left, right])
    if informative_disagreement:
        record["status"] = "INCONSISTENT"
    elif not record["stable_pairs"]:
        record["status"] = "NO_SMOOTH_ADJACENT_PAIR" if not all(usable) else "FINITE_DIFFERENCE_NOT_CONVERGED"
    elif abs(automatic) < MIN_RESPONSE or any(abs(values[i]) < MIN_RESPONSE
                                            for pair in record["stable_pairs"] for i in pair):
        record["status"] = "LOW_SENSITIVITY"
    elif any(not same_sign(automatic, values[i]) or not close(automatic, values[i])
             for pair in record["stable_pairs"] for i in pair):
        record["status"] = "INCONSISTENT"
    else:
        record["status"], record["effective"] = "PASS", True
    return record


def require_direction_groups(records, groups):
    """No pre-registered bad direction can be covered by a good direction."""
    for group in groups:
        found = [record for record in records if record["group"] == group]
        if len(found) != 3 or not any(record["effective"] for record in found):
            raise GradientStageFailure(f"No three registered directions with an effective response: {group}")
        if any(record["status"] != "PASS" for record in found):
            raise GradientStageFailure(f"Unconfirmed registered direction in {group}")


def _proof(trajectory):
    return {"loss": trajectory.loss.detach().cpu(),
            "predictions": [{"date": str(pred.date), "observation_cutoff": str(pred.observation_cutoff),
                             "locked": pred.locked, "state_digest": pred.state_digest,
                             "tensor": pred.tensor.detach().cpu()} for pred in trajectory.predictions],
            "updates": [{"as_of_date": str(update.as_of_date), "rain_dates": [str(d) for d in update.rain_dates],
                         "raw": update.raw.detach().cpu(), "proposal": update.proposal.detach().cpu(),
                         "applied": update.applied.detach().cpu(), "violation": update.violation.detach().cpu(),
                         "missing": update.missing, "cap": update.cap} for update in trajectory.updates],
            "ledgers": [ledger.detach().cpu() for ledger in trajectory.ledgers]}


def _frozen_proof(ctx):
    """Copy the existing frozen model; never reconstruct it or change its modes."""
    model = ctx.hydro.frozen.model
    return {"state_dict": {name: tensor.detach().cpu().clone() for name, tensor in model.state_dict().items()},
            "modes": {name: child.training for name, child in model.named_modules()},
            "requires_grad": {name: parameter.requires_grad for name, parameter in model.named_parameters()},
            "grad_is_none": {name: parameter.grad is None for name, parameter in model.named_parameters()},
            "gradients": {name: None if parameter.grad is None else parameter.grad.detach().cpu().clone()
                          for name, parameter in model.named_parameters()}}


class _Recorder:
    def __init__(self, ctx):
        self.ctx, self.root = ctx, Path(ctx.output) / "gradient_proofs"
        self.root.mkdir(exist_ok=False)
        self.records, self.artifacts = [], []

    def save(self, label, payload):
        path = self.root / f"{len(self.artifacts):03d}_{label}.pt"
        if path.exists():
            raise FileExistsError(path)
        torch.save(_cpu(payload), path)
        item = {"path": str(path), "sha256": _sha(path), "bytes": path.stat().st_size}
        self.artifacts.append(item)
        return item

    def event(self, label, record):
        self.records.append({"label": label, **record})
        _json_write(self.root / f"event_{len(self.records):03d}.json", self.records[-1])


class DateBoundCorrector(nn.Module):
    """Independent calendar adapter for the nonzero equivalence check only."""
    def __init__(self, table):
        super().__init__()
        if table.shape != (32, 100) or not torch.isfinite(table).all():
            raise ValueError("Date-bound controls must have shape 32 by 100")
        self.register_buffer("table", table.detach().clone())
        self.current = None
        self.visited = []

    def set_date(self, current):
        expected = UPDATE_DATES + (TERMINAL_DATE,)
        if len(self.visited) >= 33 or current != expected[len(self.visited)]:
            raise GradientStageFailure("Date-bound adapter received a repeated, future, or wrong day")
        self.current = current

    def forward(self, features, lag_weather, previous_applied, lag_days):
        if self.current is None:
            raise GradientStageFailure("The calendar adapter has no bound update day")
        current, self.current = self.current, None
        self.visited.append(current)
        if current == TERMINAL_DATE:
            return previous_applied
        if previous_applied.shape != (100,):
            raise GradientStageFailure("Wrong history width in the calendar adapter")
        return self.table[(current - UPDATE_DATES[0]).days]


def require_adapter_equivalence(reference, actual, table, warmup_dates, warmup_applied):
    """Check every overwrite against an independently constructed calendar ledger."""
    require_calendar(reference)
    require_calendar(actual)
    if table.shape != (32, 100) or len(reference.ledgers) != 32 or len(actual.ledgers) != 32:
        raise GradientStageFailure("Missing row, transposed controls, or incomplete captured ledgers")
    expected_dates = list(warmup_dates)
    expected = warmup_applied.detach().clone()
    if len(expected) != len(expected_dates) or not torch.equal(expected, torch.zeros_like(expected)):
        raise GradientStageFailure("The reference must begin at the registered zero ledger")
    for index, current in enumerate(UPDATE_DATES):
        expected_dates.append(current)
        expected = torch.cat((expected, expected.new_zeros(1)))
        rain_dates = tuple(current - timedelta(days=99 - lag) for lag in range(100))
        positions = [expected_dates.index(day) for day in rain_dates]
        if positions != list(range(len(expected_dates) - 100, len(expected_dates))):
            raise GradientStageFailure("Calendar coverage is not the previous 100 dates")
        update = reference.updates[index]
        _, row, _ = project_rain(update.raw, table[index], update.cap)
        # Replace, rather than accumulate, the latest 100 calendar values.
        expected = torch.cat((expected[:-100], row.detach()))
        other = actual.updates[index]
        if (tuple(other.rain_dates) != rain_dates or not torch.equal(update.proposal, table[index]) or
                not torch.equal(other.proposal, table[index]) or
                not torch.equal(update.raw, other.raw) or not torch.equal(update.applied, row) or
                not torch.equal(other.applied, row) or not torch.equal(reference.ledgers[index], expected) or
                not torch.equal(actual.ledgers[index], expected)):
            raise GradientStageFailure(f"Direct-control overwrite differs on {current}")
    for first, second in zip(reference.predictions, actual.predictions, strict=True):
        if (first.date != second.date or first.observation_cutoff != second.observation_cutoff or
                first.state_digest != second.state_digest or not torch.equal(first.tensor, second.tensor)):
            raise GradientStageFailure("The nonzero direct adapter changes prediction identity or values")
    # Replay appends the terminal day's uncorrected zero before observe.
    terminal_previous = torch.cat((expected, expected.new_zeros(1)))[-100:]
    for update in (reference.updates[-1], actual.updates[-1]):
        if not torch.equal(update.proposal, terminal_previous) or not torch.equal(update.applied, terminal_previous):
            raise GradientStageFailure("The terminal day indexed a new control or changed the ledger")
    if not torch.equal(reference.loss, actual.loss):
        raise GradientStageFailure("Equivalent nonzero adapters changed the target loss")


@dataclass
class _Captured:
    loss: torch.Tensor
    predictions: tuple
    updates: tuple
    ledgers: tuple


def _adapter_check(ctx, recorder):
    from .support_v01 import TableCorrector, bounds
    cap = float(ctx.scaling.cap)
    template, _ = bounds(ctx)
    rows = torch.arange(32, dtype=template.dtype, device=template.device).reshape(32, 1)
    lags = torch.arange(100, dtype=template.dtype, device=template.device).reshape(1, 100)
    table = cap * (0.01 + 0.001 * torch.remainder(rows, 2) + 0.00001 * lags)
    corrector = DateBoundCorrector(table)
    _before(ctx, "date_bound_nonzero_reference")
    began = time.perf_counter()
    replay = ctx.factory(corrector)
    warmup_dates, warmup_applied, warmup_weather = tuple(replay.dates), replay.applied.detach().clone(), replay.raw.detach().clone()
    source = ObservationStream(ctx.small_phase, ctx.small_values)
    predictions, updates, ledgers, terms = [], [], [], []
    with torch.no_grad():
        for index, (current, weather) in enumerate(zip(ctx.small_phase.dates, ctx.small_weather, strict=True)):
            corrector.set_date(current)
            prediction = replay.predict(current, weather)
            observation = source.release(prediction)
            update = replay.observe(current, observation.value)
            predictions.append(prediction)
            updates.append(update)
            if index:
                terms.append(((prediction.tensor - observation.value) / ctx.scaling.flow_std).square())
            if index < 32:
                ledgers.append(replay.applied.detach().clone())
    if source.consumed != 33 or tuple(corrector.visited) != UPDATE_DATES + (TERMINAL_DATE,):
        raise GradientStageFailure("Nonzero reference did not release precisely the registered observations")
    reference = _Captured(torch.stack(terms).mean(), tuple(predictions), tuple(updates), tuple(ledgers))
    reference_seconds = _after(ctx, "date_bound_nonzero_reference", began)
    direct = TableCorrector(table)
    with torch.no_grad():
        actual, actual_seconds = _forward(ctx, direct, "table_nonzero_equivalence")
    raw = recorder.save("nonzero_adapter", {"table": table, "warmup_dates": warmup_dates,
                        "warmup_weather": warmup_weather, "warmup_applied": warmup_applied,
                        "reference": _proof(reference), "actual": _proof(actual)})
    require_adapter_equivalence(reference, actual, table, warmup_dates, warmup_applied)
    recorder.event("nonzero_adapter", {"status": "PASS", "proof": raw,
                                      "seconds": reference_seconds + actual_seconds,
                                      "effective_updates": 32, "terminal_new_control": False})


def _directions(shape, count=3):
    generator = torch.Generator(device="cpu")
    generator.manual_seed(SEED)
    for _ in range(count):
        direction = torch.randn(shape, generator=generator, dtype=torch.float32)
        maximum = direction.abs().max()
        if not torch.isfinite(direction).all() or maximum <= 0:
            raise GradientStageFailure("A registered deterministic direction is invalid")
        yield direction / maximum


def _input_checks(ctx, recorder):
    from .support_v01 import TableCorrector, bounds, rng_snapshot, restore_rng, rng_digest
    lower, upper = bounds(ctx)
    center = (lower + upper) / 2
    if center.shape != (32, 100) or not bool(((center > lower) & (center < upper)).all()):
        raise GradientStageFailure("The registered midpoint is not strictly inside all input bounds")
    base_rng = rng_snapshot()
    records = []
    try:
        for target in TARGET_INDICES:
            corrector = TableCorrector(center.detach().clone())
            restore_rng(base_rng)
            trajectory, seconds = _forward(ctx, corrector, f"input_base_target_{target}")
            objective = _normalized_output(ctx, trajectory.predictions[target])
            _before(ctx, f"input_autograd_target_{target}")
            began = time.perf_counter()
            gradient = torch.autograd.grad(objective, corrector.controls, allow_unused=True)[0] if objective.requires_grad else None
            gradient_seconds = _after(ctx, f"input_autograd_target_{target}", began)
            gradient_status = "MISSING" if gradient is None else "FINITE" if torch.isfinite(gradient).all() else "NONFINITE"
            base_artifact = recorder.save(f"input_base_{target}", {"lower": lower, "upper": upper,
                            "center": center, "target_prediction_index": target, "previous_update_index": target - 1,
                            "gradient": gradient, "gradient_status": gradient_status, "trajectory": _proof(trajectory),
                            "rng": base_rng})
            for direction_index, host_direction in enumerate(_directions((100,))):
                direction = host_direction.to(center.device)
                automatic = float("nan") if gradient_status == "NONFINITE" else 0. if gradient is None else float(
                    (gradient[target - 1].detach() * direction).sum())
                differences, valid, scale_proofs = [], [], []
                for scale in PARAMETER_SCALES:
                    delta = float(ctx.scaling.cap) * scale
                    plus, minus = center.detach().clone(), center.detach().clone()
                    plus[target - 1] += delta * direction
                    minus[target - 1] -= delta * direction
                    interior = bool(((plus > lower) & (plus < upper) & (minus > lower) & (minus < upper)).all())
                    if not interior:
                        differences.append(None)
                        valid.append(False)
                        scale_proofs.append({"delta_mm": delta, "strictly_interior": False})
                        continue
                    restore_rng(base_rng)
                    with torch.no_grad():
                        pos, pos_seconds = _forward(ctx, TableCorrector(plus), f"input_plus_{target}_{direction_index}_{scale}")
                    restore_rng(base_rng)
                    with torch.no_grad():
                        neg, neg_seconds = _forward(ctx, TableCorrector(minus), f"input_minus_{target}_{direction_index}_{scale}")
                    p, m = float(_normalized_output(ctx, pos.predictions[target])), float(_normalized_output(ctx, neg.predictions[target]))
                    derivative = (p - m) / (2 * delta)
                    artifact = recorder.save(f"input_{target}_{direction_index}_{scale}", {
                        "direction": host_direction, "delta_mm": delta, "plus_controls": plus, "minus_controls": minus,
                        "plus": _proof(pos), "minus": _proof(neg), "automatic": automatic,
                        "finite_difference": derivative, "seconds": pos_seconds + neg_seconds})
                    differences.append(derivative)
                    valid.append(True)
                    scale_proofs.append({"delta_mm": delta, "strictly_interior": True, "proof": artifact})
                record = classify_direction(automatic, differences, valid)
                record.update({"group": f"input_target_{target}", "direction_index": direction_index,
                               "base_proof": base_artifact, "scales": scale_proofs,
                               "gradient_status": gradient_status, "base_seconds": seconds + gradient_seconds})
                records.append(record)
                recorder.event("input_direction", record)
            del trajectory, corrector, gradient
    finally:
        restore_rng(base_rng)
        if rng_digest() != rng_digest(base_rng):
            raise GradientStageFailure("Input gradient diagnostics did not restore the exact random state")
        recorder.save("input_rng_restoration", {"before": base_rng, "after": rng_snapshot(),
                                               "before_digest": rng_digest(base_rng), "after_digest": rng_digest()})
    require_direction_groups(records, [f"input_target_{target}" for target in TARGET_INDICES])
    return records


def _gradient_record(network, prefix):
    result, gradients = {}, {}
    for name, parameter in sorted(network.named_parameters()):
        if not name.startswith(prefix):
            continue
        gradient = parameter.grad
        gradients[name] = None if gradient is None else gradient.detach().cpu().clone()
        result[name] = {"status": "MISSING" if gradient is None else "NONFINITE" if not torch.isfinite(gradient).all()
                       else "ZERO" if not (gradient != 0).any() else "FINITE_NONZERO",
                       "elements": parameter.numel()}
    if not result:
        raise GradientStageFailure(f"No original network parameters matched {prefix}")
    return result, gradients


def _require_nonzero_group(record, label):
    if any(item["status"] in ("MISSING", "NONFINITE") for item in record.values()) or not any(
            item["status"] == "FINITE_NONZERO" for item in record.values()):
        raise GradientStageFailure(f"The {label} gradient is missing, nonfinite, or all zero")


def _network_checks(ctx, recorder):
    from .support_v01 import snapshot, restore_snapshot, state_digest, rng_digest, rng_snapshot, restore_rng, require_finite_state
    outer_rng = rng_snapshot()
    network = ctx.new_network(SEED)
    optimizer = torch.optim.Adam(network.parameters(), lr=0.001, betas=(0.9, 0.999), eps=1e-8, weight_decay=0.)
    initial = snapshot(network, optimizer)
    recorder.save("temporary_network_initial", initial)
    try:
        first, first_seconds = _forward(ctx, network, "temporary_network_first")
        optimizer.zero_grad(set_to_none=True)
        _before(ctx, "temporary_network_first_backward")
        began = time.perf_counter()
        first.loss.backward()
        first_seconds += _after(ctx, "temporary_network_first_backward", began)
        output, output_grads = _gradient_record(network, "decoder.2.")
        encoder, encoder_grads = _gradient_record(network, "encoder.")
        raw = recorder.save("temporary_first_backward", {"trajectory": _proof(first), "output_gradients": output_grads,
                            "encoder_gradients": encoder_grads, "network": network.state_dict(), "rng": rng_snapshot()})
        recorder.event("temporary_first_backward", {"output": output, "encoder": encoder, "seconds": first_seconds, "proof": raw})
        _require_nonzero_group(output, "initial output layer")
        if any(item["status"] != "ZERO" for item in encoder.values()):
            raise GradientStageFailure("The zero-initialized output layer did not produce the expected zero encoder gradients")
        for parameter in network.parameters():
            if parameter.grad is None or not torch.isfinite(parameter.grad).all():
                raise GradientStageFailure("A temporary network parameter has missing/nonfinite gradients before the only step")
        _before(ctx, "temporary_single_adam_step")
        began = time.perf_counter()
        try:
            optimizer.step()
        finally:
            # Preserve the actual post-step state before *any* finite/deadline
            # gate.  A partially failed optimizer step must also remain visible.
            updated = snapshot(network, optimizer)
            recorder.save("temporary_network_after_only_step", updated)
        step_seconds = _after(ctx, "temporary_single_adam_step", began)
        require_finite_state(network)
        for state in optimizer.state.values():
            if any(torch.is_tensor(value) and not torch.isfinite(value).all() for value in state.values()):
                raise GradientStageFailure("The only temporary optimizer step produced nonfinite state")
        recorder.event("temporary_optimizer", {"optimizer_updates": 1, "lr": 0.001, "seconds": step_seconds})
        optimizer.zero_grad(set_to_none=True)
        second, second_seconds = _forward(ctx, network, "temporary_network_second")
        _before(ctx, "temporary_network_second_backward")
        began = time.perf_counter()
        second.loss.backward()
        second_seconds += _after(ctx, "temporary_network_second_backward", began)
        encoder, encoder_grads = _gradient_record(network, "encoder.")
        output, output_grads = _gradient_record(network, "decoder.2.")
        raw = recorder.save("temporary_second_backward", {"trajectory": _proof(second), "encoder_gradients": encoder_grads,
                            "output_gradients": output_grads, "network": network.state_dict(), "rng": rng_snapshot()})
        recorder.event("temporary_second_backward", {"encoder": encoder, "output": output, "seconds": second_seconds, "proof": raw})
        _require_nonzero_group(encoder, "post-step encoder")
        _require_nonzero_group(output, "post-step output layer")
        all_gradient_status = {name: "MISSING" if parameter.grad is None else "NONFINITE" if not torch.isfinite(
            parameter.grad).all() else "FINITE" for name, parameter in network.named_parameters()}
        recorder.event("temporary_second_all_gradients", {"parameters": all_gradient_status})
        if any(status != "FINITE" for status in all_gradient_status.values()):
            raise GradientStageFailure("A temporary network parameter has missing/nonfinite gradients after the only step")
        # No second optimizer step.  Finite differences hold this exact state fixed.
        del first, second
        fixed = snapshot(network, optimizer)
        fixed_state, fixed_rng = state_digest(network), rng_digest()
        groups = {"output_parameters": "decoder.2.", "encoder_parameters": "encoder."}
        records = []
        try:
            for group, prefix in groups.items():
                parameters = [(name, p) for name, p in sorted(network.named_parameters()) if name.startswith(prefix)]
                sizes = [p.numel() for _, p in parameters]
                restore_snapshot(network, fixed, optimizer)
                base, base_seconds = _forward(ctx, network, f"parameter_base_{group}")
                objective = _normalized_output(ctx, base.predictions[-1])
                _before(ctx, f"parameter_autograd_{group}")
                began = time.perf_counter()
                gradients = torch.autograd.grad(objective, [p for _, p in parameters], allow_unused=True) if objective.requires_grad else [None] * len(parameters)
                base_seconds += _after(ctx, f"parameter_autograd_{group}", began)
                status = "MISSING" if any(g is None for g in gradients) else "NONFINITE" if any(
                    not torch.isfinite(g).all() for g in gradients) else "FINITE"
                flat_gradient = None if status != "FINITE" else torch.cat([g.detach().reshape(-1) for g in gradients])
                base_branches = branches(base)
                base_smooth = not bool(((base_branches == 1) | (base_branches == 3)).any())
                base_artifact = recorder.save(f"parameter_base_{group}", {"trajectory": _proof(base),
                    "branches": base_branches, "sorted_parameter_names": [name for name, _ in parameters],
                    "sizes": sizes, "gradients": list(gradients), "gradient_status": status, "snapshot": fixed})
                for direction_index, host_direction in enumerate(_directions((sum(sizes),))):
                    direction = host_direction.to(ctx.device)
                    automatic = float("nan") if status == "NONFINITE" else 0. if flat_gradient is None else float((flat_gradient * direction).sum())
                    differences, valid, scale_proofs = [], [], []
                    for delta in PARAMETER_SCALES:
                        trajectories, timings = [], []
                        for sign in (1., -1.):
                            restore_snapshot(network, fixed, optimizer)
                            offset = 0
                            with torch.no_grad():
                                for _, parameter in parameters:
                                    count = parameter.numel()
                                    parameter.add_(sign * delta * direction[offset:offset + count].reshape(parameter.shape))
                                    offset += count
                            require_finite_state(network)
                            with torch.no_grad():
                                trajectory, elapsed = _forward(ctx, network, f"parameter_{group}_{direction_index}_{delta}_{sign}")
                            trajectories.append(trajectory)
                            timings.append(elapsed)
                        pos, neg = trajectories
                        pos_branches, neg_branches = branches(pos), branches(neg)
                        smooth = base_smooth and torch.equal(base_branches, pos_branches) and torch.equal(base_branches, neg_branches)
                        derivative = (float(_normalized_output(ctx, pos.predictions[-1])) -
                                      float(_normalized_output(ctx, neg.predictions[-1]))) / (2 * delta)
                        artifact = recorder.save(f"parameter_{group}_{direction_index}_{delta}", {
                            "direction": host_direction, "sorted_parameter_names": [name for name, _ in parameters],
                            "sizes": sizes, "delta": delta, "plus": _proof(pos), "minus": _proof(neg),
                            "base_branches": base_branches, "plus_branches": pos_branches, "minus_branches": neg_branches,
                            "smooth": smooth, "automatic": automatic, "finite_difference": derivative, "seconds": sum(timings)})
                        differences.append(derivative)
                        valid.append(bool(smooth))
                        scale_proofs.append({"delta": delta, "smooth": bool(smooth), "proof": artifact})
                    record = classify_direction(automatic, differences, valid)
                    record.update({"group": group, "direction_index": direction_index, "gradient_status": status,
                                   "base_proof": base_artifact, "base_seconds": base_seconds, "scales": scale_proofs})
                    records.append(record)
                    recorder.event("parameter_direction", record)
                del base, gradients, flat_gradient
        finally:
            restore_snapshot(network, fixed, optimizer)
            if state_digest(network) != fixed_state or rng_digest() != fixed_rng:
                raise GradientStageFailure("Network finite differences did not restore exact parameters/buffers/random state")
            recorder.save("network_raw_restoration", {"before": fixed, "after": snapshot(network, optimizer),
                "before_state_digest": fixed_state, "after_state_digest": state_digest(network),
                "before_rng_digest": fixed_rng, "after_rng_digest": rng_digest()})
        recorder.event("network_restoration", {"status": "PASS", "state_digest": fixed_state, "rng_digest": fixed_rng,
                                               "optimizer_updates": 1, "temporary_weights_reusable": False})
        require_direction_groups(records, list(groups))
        return records
    finally:
        # The only update is preserved as evidence; never expose it as a fit start.
        restore_rng(outer_rng)
        del optimizer, network


def run_gradient_stage(ctx):
    """Run stage two once; exceptions preserve partial proofs and stop the caller."""
    recorder = _Recorder(ctx)
    began = time.perf_counter()
    result = {"schema": "precip_small_sample_gradient_v01", "status": "RUNNING", "seed": SEED,
              "input_target_indices": list(TARGET_INDICES), "minimum_directional_response": MIN_RESPONSE,
              "relative_only_limit": RELATIVE_LIMIT, "parameter_scales": list(PARAMETER_SCALES),
              "temporary_optimizer_updates_allowed": 1, "scientific_fit_confirmed": False}
    try:
        result["frozen_before"] = recorder.save("frozen_before", _frozen_proof(ctx))
        recorder.save("bound_inputs", {"dates": ctx.small_phase.dates, "weather": ctx.small_weather,
                                       "observations": ctx.small_values, "scaling": ctx.scaling.as_dict(),
                                       "frozen_modes": getattr(ctx, "mode_reference", None)})
        _adapter_check(ctx, recorder)
        result["input_directions"] = _input_checks(ctx, recorder)
        result["parameter_directions"] = _network_checks(ctx, recorder)
        ctx.require_unchanged()
        result["status"], result["execution_complete"] = "PASS", True
        return result
    except BaseException as error:
        result.update({"status": "FAILED_OR_UNCONFIRMED", "error_type": type(error).__name__, "error": str(error)})
        raise
    finally:
        _synchronize(ctx)
        result["frozen_after"] = recorder.save("frozen_after", _frozen_proof(ctx))
        result.update({"seconds": time.perf_counter() - began, "artifacts": recorder.artifacts,
                       "completed_records": recorder.records, "no_later_stage_without_pass": True})
        path = Path(ctx.output) / "gradient_result.json"
        if path.exists():
            raise FileExistsError("Refusing to overwrite a gradient stage result")
        _json_write(path, result)
