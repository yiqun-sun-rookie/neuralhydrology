"""Independent, metered audits of saved small-sample diagnostic evidence.

The phase-one audit opens only current authorized saved arrays and the six
original selected validation predictions; original weights remain opaque bytes.
Later audits are delegated to a separate reviewer and may reconstruct models
inside the same metered phase. No auditor opens raw scoring-period values.
The caller must hold the real family lock and the existing stage reservation.
"""

from datetime import date, datetime, timedelta, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import stat
import time


REPO = Path(__file__).resolve().parents[3]
FAMILY = REPO / "results/precip_input_da_2026_09/effect_first_v01"
PILOT = FAMILY / "pilot_20261009_01487000_s1001_s1002_s1003_v02"
ORIGINAL = REPO / "results/precip_input_da_2026_09/dynamic_filter_v03/eight_basin_fixed_recipe_v01_20261003_230000_d5028d71"
GUARD = ORIGINAL / "recovery_prelaunch_guard_v01.json"
GUARD_SHA = "53b0bfaad7c6cfe9600125e5d32391bd47d44be819f1ca41dd8646b316562096"
PILOT_RESULT_SHA = "f262ed00910cffad781976ccf5ea2172aca935cb1369026962e0a9319adacc9c"
PLAN_SHA = "49ed97c6f2f34af0f1408ed8ea07ec72c5ecc293efcbbd24c3256fd000f00393"
PHASE_ROOTS = {1: "small_sample_weight_replay_20261010_v01", 2: "small_sample_gradient_20261010_v01",
               3: "small_sample_direct_control_20261010_v01", 4: "small_sample_network_20261010_v01"}
PHASE_SECONDS = {1: 1800, 2: 1200, 3: 3600, 4: 5400}
PHASE_NUMBERS = {"weight_replay": 1, "gradient": 2, "direct_control": 3, "network": 4}
SEEDS = (1001, 1002, 1003)
ARMS = ("original_penalties", "no_penalties")


def _get(ctx, name):
    return ctx[name] if isinstance(ctx, dict) else getattr(ctx, name)


def _sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _canonical_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode("utf-8")).hexdigest()


def _read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _safe(path, root):
    path, root = Path(path).absolute(), Path(root).resolve()
    if not path.resolve().is_relative_to(root):
        raise PermissionError(f"Audit input escaped its authorized root: {path}")
    for parent in (path, *path.parents):
        if parent.exists() and (parent.is_symlink() or
                getattr(parent.lstat(), "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)):
            raise PermissionError(f"Audit input traverses a link or reparse point: {path}")
        if parent.resolve() == root:
            break
    return path


def _require(condition, message):
    if not condition:
        raise PermissionError(message)


def _check_time(ctx):
    deadline = float(_get(ctx, "deadline"))
    _require(math.isfinite(deadline), "Audit deadline is not finite")
    if time.monotonic() >= deadline - 300:
        raise TimeoutError("Independent audit reached the same stage's exit reserve")
    output = Path(_get(ctx, "output"))
    if (output / "STOP").exists() or (FAMILY / "STOP").exists():
        raise InterruptedError("Manual stop applies to the independent audit")


def _write_new(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        handle.write("\n")


def _dates(start, end):
    first, last = date.fromisoformat(start), date.fromisoformat(end)
    return [(first + timedelta(days=i)).isoformat() for i in range((last - first).days + 1)]


def _array(path, root, shape, dtype=None):
    import numpy as np
    value = np.load(_safe(path, root), allow_pickle=False)
    _require(value.shape == shape, f"Unexpected audit array shape: {path}")
    _require(value.dtype.kind == "f", f"Audit array is not floating point: {path}")
    if dtype is not None:
        _require(str(value.dtype) == dtype, f"Unexpected audit array dtype: {path}")
    return value


def _metrics(obs, predictions, flow_std):
    import numpy as np
    _require(obs.shape == predictions.shape, "Observation/prediction grid differs")
    keep = np.isfinite(obs)
    _require(bool(keep.any()), "No valid observations for independent metrics")
    _require(bool(np.isfinite(predictions).all()), "Nonfinite saved predictions")
    values = obs[keep]
    squared = (predictions[keep] - values) ** 2
    denominator = np.sum((values - values.mean()) ** 2)
    mse = float(np.mean(squared))
    return {"valid_count": int(keep.sum()), "total_count": int(len(obs)), "mse": mse,
            "rmse": math.sqrt(mse), "standardized_mse": mse / flow_std ** 2,
            "nse": None if len(values) < 2 or denominator <= 0 else
            float(1. - np.sum(squared) / denominator)}


def _protection(ctx):
    _check_time(ctx)
    _require(_sha(GUARD) == GUARD_SHA, "Original 67-file protection record changed")
    guard = _read_json(GUARD)
    roots = {"sealed_sources": REPO, "original_sources": REPO,
             "frozen_model": REPO / "results/precip_input_da_2026_09/received/seq1/pida_0b1/C4_s100"}
    expected = {"sealed_sources": 42, "original_sources": 22, "frozen_model": 3}
    rows = []
    for name, root in roots.items():
        section = guard["checks"][name]
        _require(not section["changed"] and len(section["hashes"]) == expected[name],
                 f"Original protection count/adverse evidence differs: {name}")
        for relative, locked in section["hashes"].items():
            _check_time(ctx)
            path = _safe(root / relative, root)
            actual = _sha(path)
            _require(actual == locked, f"Protected original bytes changed: {name}/{relative}")
            rows.append({"group": name, "path": str(path), "sha256": actual})
    _require(len(rows) == 67, "Incomplete original protection audit")
    return rows


def _budget(ctx, stage, manifest):
    output = _safe(_get(ctx, "output"), FAMILY)
    _require(output.name == PHASE_ROOTS[stage] and output.parent.resolve() == FAMILY.resolve(),
             "Independent audit output is not the registered unique phase root")
    reservation = _read_json(output / "budget_reservation.json")
    _require(_canonical_sha(reservation["payload"]) == reservation["sha256"], "Invalid reservation digest")
    _require(reservation["payload"]["output"] == str(output.resolve()), "Reservation/output path differs")
    _require(reservation["payload"]["reserved_seconds"] == PHASE_SECONDS[stage], "Wrong phase reservation")
    _require(manifest["budget_reservation_sha256"] == reservation["sha256"], "Manifest reservation differs")
    journal = _read_json(FAMILY / "cumulative_budget_v01.json")
    _require(journal["schema"] == "precip_effect_first_budget_v01" and
             journal["original_used_seconds"] == 86562 and journal["total_seconds"] == 259200,
             "Wrong cumulative budget origin")
    previous, allocations, settled = None, {}, {}
    for row in journal["events"]:
        event = row["payload"]
        _require(_canonical_sha(event) == row["sha256"] and event["previous_sha256"] == previous,
                 "Budget event digest/order differs")
        previous = row["sha256"]
        if event["kind"] == "reserve":
            seconds = event["reserved_seconds"]
            _require(event["run_id"] not in allocations and isinstance(seconds, int) and
                     not isinstance(seconds, bool) and 0 < seconds <= 21600, "Invalid budget reservation")
            allocations[event["run_id"]] = row
        elif event["kind"] == "settle":
            original = allocations.get(event["run_id"])
            seconds = event["charged_seconds"]
            _require(original is not None and event["run_id"] not in settled and
                     event["reservation_sha256"] == original["sha256"] and isinstance(seconds, int) and
                     not isinstance(seconds, bool) and seconds >= 0, "Invalid budget settlement")
            settled[event["run_id"]] = seconds
        else:
            raise PermissionError("Unknown budget event type")
    run_id = reservation["payload"]["run_id"]
    _require(allocations.get(run_id) == reservation and run_id not in settled,
             "Audit must execute inside its still-open original reservation")
    _require([key for key in allocations if key not in settled] == [run_id],
             "Another family computation reservation remains open")
    used = 86562 + sum(settled.get(key, row["payload"]["reserved_seconds"]) for key, row in allocations.items())
    _require(used <= 259200, "Cumulative budget exceeded")
    started = datetime.fromisoformat(reservation["payload"]["started_utc"])
    _require((datetime.now(timezone.utc) - started).total_seconds() < PHASE_SECONDS[stage] - 300,
             "Independent audit did not start within the existing stage compute interval")
    _check_time(ctx)
    return {"reservation_sha256": reservation["sha256"], "run_id": run_id,
            "reserved_seconds": PHASE_SECONDS[stage], "currently_charged_including_open_seconds": used,
            "same_deadline": float(_get(ctx, "deadline")), "reservation_open_during_audit": True}


def classify_direction(automatic, finite_differences, usable=(True, True, True)):
    """Recompute the plan's directional gate without importing its implementer.

    Both neighboring pairs are examined. A contradictory stable pair cannot be
    hidden by another favorable pair. Exact zero/zero is low sensitivity.
    """
    scalars = [float(automatic), *[float(value) for value in finite_differences]]
    _require(len(scalars) == 4 and all(math.isfinite(value) for value in scalars),
             "Directional evidence is missing or nonfinite")
    _require(len(usable) == 3 and all(type(value) is bool for value in usable), "Malformed smooth-scale evidence")
    g, values = scalars[0], scalars[1:]
    pairs = []
    for index in range(2):
        if not (usable[index] and usable[index + 1]):
            continue
        first, second = values[index:index + 2]
        scale = max(abs(first), abs(second))
        stable = ((first == second == 0.) or (first * second > 0. and abs(first - second) <= .05 * scale))
        if not stable:
            continue
        consistent = ((g == first == second == 0.) or
                      (g * first > 0. and g * second > 0. and
                       abs(g - first) <= .05 * max(abs(g), abs(first)) and
                       abs(g - second) <= .05 * max(abs(g), abs(second))))
        amplitude = min(abs(g), abs(first), abs(second)) >= .001
        any_effective = max(abs(g), abs(first), abs(second)) >= .001
        # A zero against a sub-threshold response is still never effective pass.
        mismatch = (not consistent) and any_effective
        status = "inconsistent" if mismatch else "effective_pass" if consistent and amplitude else "low_sensitivity"
        pairs.append({"indices": [index, index + 1], "stable": stable, "consistent": consistent,
                      "effective_amplitude": amplitude, "status": status})
    status = ("difference_not_converged" if not pairs else "inconsistent"
              if any(row["status"] == "inconsistent" for row in pairs) else "effective_pass"
              if any(row["status"] == "effective_pass" for row in pairs) else "low_sensitivity")
    return {"automatic": g, "finite_differences": values, "usable": list(usable),
            "pairs": pairs, "status": status, "pass": status == "effective_pass"}


def audit_stage(stage, ctx, result):
    """Fail closed until saved evidence has passed an independent actual audit."""
    stage = PHASE_NUMBERS[stage] if isinstance(stage, str) and stage in PHASE_NUMBERS else int(stage)
    _require(stage in PHASE_ROOTS, "Unknown independent-audit phase")
    stage_name = next(name for name, number in PHASE_NUMBERS.items() if number == stage)
    output = _safe(_get(ctx, "output"), FAMILY)
    name = "actual_weight_replay_audit.json" if stage == 1 else f"actual_stage{stage}_audit.json"
    report = {"schema": "precip_small_sample_independent_actual_audit_v01", "stage": stage_name, "stage_number": stage,
              "auditor_source_sha256": _sha(__file__), "started_utc": datetime.now(timezone.utc).isoformat(),
              "pass": False, "status": "BLOCKED", "model_inference_by_auditor": False,
              "raw_score_values_read": False, "new_numeric_audit": True}
    try:
        _check_time(ctx)
        manifest = _read_json(output / "manifest.json")
        _require(_read_json(output / "stage_result.json") == result,
                 "Saved stage-result bytes differ from the result presented for independent audit")
        _require(list(output.rglob("manifest.json")) == [output / "manifest.json"],
                 "Each phase must have only its one reserved root manifest")
        _require(manifest["deadline_monotonic"] == float(_get(ctx, "deadline")) and
                 manifest["pid"] == os.getpid() and manifest["plan_sha256"] == PLAN_SHA and
                 manifest["score_numeric_reads_allowed"] is False, "Actual stage identity/deadline differs")
        for relative, locked in manifest["source_identity"].items():
            _check_time(ctx)
            _require(_sha(_safe(REPO / relative, REPO)) == locked, f"Reviewed implementation bytes changed: {relative}")
        report["budget"] = _budget(ctx, stage, manifest)
        report["protected_original_files"] = _protection(ctx)
        if stage == 1:
            report.update(_audit_weights(ctx, result, manifest, report))
        else:
            from .audit_later_v01 import audit_gradient, audit_optimization
            details = audit_gradient(ctx, result) if stage == 2 else audit_optimization(stage_name, ctx, result)
            _require(details.get("independent_checks_passed") is True,
                     "Later phase lacks complete independent checks of its actual saved evidence")
            report.update(details)
        _check_time(ctx)
        report["pass"], report["status"] = True, "PASS"
    except Exception as error:
        report["first_failure"] = {"type": type(error).__name__, "message": str(error)}
    report["ended_utc"] = datetime.now(timezone.utc).isoformat()
    path = output / name
    _write_new(path, report)
    return {"pass": report["pass"], "status": report["status"], "stage": stage_name, "report_path": str(path),
            "sha256": _sha(path)}


def _audit_weights(ctx, result, manifest, report):
    import numpy as np
    output = Path(_get(ctx, "output"))
    root = output / "six_weight_replay"
    _require(result["execution_complete"] is True and result["all_six_strict_replays_passed"] is True,
             "Phase one does not record complete six-checkpoint execution")
    _require(result["score_numeric_reads_started"] is False, "Forbidden score reads recorded")
    _require(_sha(PILOT / "pilot_result.json") == PILOT_RESULT_SHA, "Original six-fit pilot result changed")
    old_result = _read_json(PILOT / "pilot_result.json")
    original_manifest = _read_json(PILOT / "manifest.json")
    _require(_sha(PILOT / "manifest.json") ==
             "262cc6d8e947fb363a8c65ecbfc30b2b896bd6cf3a27c51443ec2d8df0926822",
             "Original complete runtime manifest changed")
    _require(manifest["runtime"] == original_manifest["runtime"] == _get(ctx, "runtime"),
             "Entire original runtime dictionary differs")
    _require(manifest["plan_sha256"] == PLAN_SHA, "Actual replay plan binding differs")
    proof = _read_json(output / "context_identity.json")
    _require(proof["runtime"] == manifest["runtime"] and proof["runtime_strict_equal"] is True and
             proof["score_numeric_reads_started"] is False, "Context runtime/read evidence differs")
    modes = proof["frozen_modes"]
    _require(isinstance(modes, dict) and modes.get("") is False and modes.get("lstm") is True and
             modes.get("dropout") is False and all(type(value) is bool for value in modes.values()),
             "Original frozen recurrent/dropout module modes were not retained")
    _require(all(value is False for name, value in modes.items() if name != "lstm"),
             "An unregistered frozen module was placed in training mode")
    flow_std = float(proof["scaling"]["flow_std"])
    _require(math.isfinite(flow_std) and flow_std > 0 and result["flow_std"] == flow_std and
             proof["scaling"]["start"] == "1980-10-01" and proof["scaling"]["end"] == "1984-09-30" and
             proof["scaling"]["cap"] == 32.21650314331055, "Original complete-fitting scaling differs")
    _require(proof["scaling"] == _read_json(output / "strict_fresh_scaling.json"),
             "Saved fresh scaling and context scaling disagree")
    scaling_proof = ORIGINAL / "monitoring_3h_v01/scaling_numpy233_20261008T233546Z_v01/result.json"
    _require(_sha(scaling_proof) == "2e6608d25866455df8a26bdaf096c00b8822647c74fb6779cf26d83c2d84565c",
             "Original isolated NumPy 2.3.3 scaling proof changed")
    locked_scaling = [entry["locked"] for entry in _read_json(scaling_proof)["results"]
                      if entry["basin"] == "01487000"]
    _require(locked_scaling == [proof["scaling"]], "Entire saved scaling dictionary differs from original lock")
    expected_dates = {"fit": _dates("1980-10-01", "1984-09-30"),
                      "select": _dates("1984-10-01", "1985-09-30")}
    dates_path = _safe(root / "dates.json", output)
    _require(_read_json(dates_path) == expected_dates, "Actual replay dates differ from sealed fit/select calendar")
    _require(result["dates"] == {"file": str(dates_path), "sha256": _sha(dates_path)},
             "Phase-one date bytes are not bound")
    old_review_path = FAMILY / "result_audit_20261010_v01/independent_result_adversarial_review_v01.json"
    _require(_sha(old_review_path) == "cb5f6ca075741f8f5832c2456e626162216a15eb387805ced27490505c260095",
             "Original independent pilot artifact review changed")
    old_artifacts = _read_json(old_review_path)["artifact_identity"]
    gate = _read_json(output / "input_gate.json")
    _require(gate == _read_json(PILOT / "input_gate.json") and gate["pass"] is True,
             "Current complete input gate differs from original pilot")
    targets, identities = {}, []
    report["phase_one_progress"] = {"saved_observations": identities, "actual_metric_checks": []}
    for phase, length in (("fit", 1461), ("select", 365)):
        _check_time(ctx)
        path = _safe(root / f"{phase}_observations.npy", output)
        meta = result["target_files"][phase]
        _require(meta == {"file": str(path), "sha256": _sha(path), "shape": [length], "dtype": "float64"},
                 f"{phase} observations metadata differs from actual bytes")
        targets[phase] = _array(path, output, (length,), "float64")
        # The same canonical text representation used by the guarded original
        # reader ties these legal saved observations back to its input gate.
        from io import StringIO
        stream = StringIO()
        stream.write(f"basin=01487000;phase={phase};start={expected_dates[phase][0]};end={expected_dates[phase][-1]}\n")
        stream.write("date,QObs(mm/d)\n")
        for day, value in zip(expected_dates[phase], targets[phase], strict=True):
            rendered = "NA" if not np.isfinite(value) else format(float(value), ".17g")
            stream.write(day + "," + rendered + "\n")
        canonical = hashlib.sha256(stream.getvalue().encode("utf-8")).hexdigest()
        _require(canonical == gate["canonical_inputs"]["flow"][phase]["canonical_sha256"],
                 f"{phase} saved observations do not reproduce their guarded input identity")
        identities.append({"phase": phase, **meta, "guarded_canonical_sha256": canonical})
    records = result["records"]
    expected_pairs = {(arm, seed) for arm in ARMS for seed in SEEDS}
    _require(len(records) == 6 and {(row["arm"], row["seed"]) for row in records} == expected_pairs,
             "All six distinct old selected fits are required")
    audited = []
    for row in records:
        _check_time(ctx)
        arm, seed = row["arm"], row["seed"]
        directory = _safe(root / arm / f"seed_{seed}", output)
        _require(_read_json(directory / "replay_identity.json") == row,
                 "Stage result differs from the actual per-fit identity")
        old = PILOT / "fits" / arm / f"seed_{seed}"
        old_summary = _read_json(old / "fit_summary.json")
        bound = [entry for entry in old_result["fits"] if entry["arm"] == arm and entry["seed"] == seed]
        _require(bound == [old_summary], "Original fit summary differs from the frozen pilot result")
        for name in ("fit_summary.json", "selected.pt", "selected_validation_predictions.npy"):
            path = _safe(old / name, PILOT)
            relative = path.relative_to(REPO).as_posix()
            _require(_sha(path) == old_artifacts[relative], f"Original actual artifact bytes changed: {relative}")
        _require(row["old_summary_path"] == str(old / "fit_summary.json") and
                 row["old_summary_sha256"] == _sha(old / "fit_summary.json") and
                 row["checkpoint_path"] == str(old / "selected.pt") and
                 row["checkpoint_sha256"] == _sha(old / "selected.pt") == old_summary["checkpoint_sha256"] and
                 row["selected_epoch"] == old_summary["best_epoch"] and
                 row["flow_std"] == flow_std and row["frozen_modes"] == modes and
                 row["new_optimizer_created"] is False and row["score_numeric_reads_started"] is False,
                 "Fixed selected-weight replay identity differs")
        _require(proof["frozen_state_sha256"] == old_summary["frozen_model_tensor_sha256"],
                 "Frozen runoff tensor identity differs from old fit")
        predictions, recomputed = {}, {}
        for phase, length in (("fit", 1461), ("select", 365)):
            path = _safe(directory / f"{phase}_predictions.npy", output)
            meta = row["artifacts"][f"{phase}_predictions"]
            _require(meta == {"file": str(path), "sha256": _sha(path), "shape": [length], "dtype": "float64"},
                     f"Saved {phase} predictions bytes/shape/dtype differ")
            predictions[phase] = _array(path, output, (length,), "float64")
            measured = _metrics(targets[phase], predictions[phase], flow_std)
            actual = {"days": measured["total_count"], "finite_days": measured["valid_count"],
                      "mse_mm2_day2": measured["mse"], "rmse_mm_day": measured["rmse"],
                      "normalized_mse": measured["standardized_mse"], "nse": measured["nse"]}
            report["phase_one_progress"]["actual_metric_checks"].append({"arm": arm, "seed": seed,
                    "phase": phase, "recomputed": actual, "reported": row[f"{phase}_metrics"]})
            _require(actual == row[f"{phase}_metrics"],
                     f"Implementer {phase} metrics differ from independent actual recomputation: {arm}/seed_{seed}")
            recomputed[phase] = actual
        old_path = old / "selected_validation_predictions.npy"
        old_predictions = _array(old_path, PILOT, (365,), "float64")
        _require(row["old_predictions_path"] == str(old_path) and row["old_predictions_sha256"] == _sha(old_path),
                 "Original select prediction identity differs")
        _require(predictions["select"].dtype == old_predictions.dtype and
                 predictions["select"].shape == old_predictions.shape and
                 np.array_equal(predictions["select"], old_predictions), "Actual six-weight strict select replay differs")
        _require(recomputed["select"]["nse"] == old_summary["validation_nse"],
                 "Actual selected-weight efficiency differs from original fit summary")
        _require(row["target_files"] == result["target_files"] and row["dates"] == result["dates"] and
                 row["context_identity"] == result["context_identity"] and
                 row["budget_reservation"] == result["budget_reservation"], "Per-fit evidence linkage differs")
        audited.append({"arm": arm, "seed": seed, "selected_epoch": row["selected_epoch"],
                        "checkpoint_sha256": row["checkpoint_sha256"], "strict_select_array_equal": True,
                        "fit_metrics": recomputed["fit"], "select_metrics": recomputed["select"]})
    _require(result["context_identity"] == {"file": str(output / "context_identity.json"),
             "sha256": _sha(output / "context_identity.json")} and result["budget_reservation"] ==
             {"file": str(output / "budget_reservation.json"), "sha256": _sha(output / "budget_reservation.json")},
             "Root replay context or reservation bytes changed")
    return {"audited_fit_count": len(audited), "required_fit_count": 6, "all_six_actual_strict_replays_passed": True,
            "saved_observation_identities": identities, "actual_recomputed_records": audited,
            "complete_runtime_dictionary_equal": True, "frozen_module_modes": modes,
            "fixed_weight_training_errors_newly_computed": True,
            "old_online_training_loss_used_as_fixed_weight_error": False}


def audit_failure(stage, ctx, error):
    """Verify saved blocking evidence, never turn an incomplete phase into PASS.

    This is called before the original reservation is settled. If its compute
    interval has ended, the failure remains unreviewed and only metadata is
    written during exit; no missing model work is performed by this function.
    """
    _require(stage in PHASE_NUMBERS, "Unknown failed phase")
    number = PHASE_NUMBERS[stage]
    output = _safe(_get(ctx, "output"), FAMILY)
    path = output / f"actual_{stage}_failure_audit.json"
    report = {"schema": "precip_small_sample_independent_failure_audit_v01", "stage": stage,
              "stage_number": number, "auditor_source_sha256": _sha(__file__),
              "started_utc": datetime.now(timezone.utc).isoformat(), "pass": False,
              "status": "BLOCKED_UNREVIEWED", "blocking_failure_verified": False,
              "original_failure": {"type": type(error).__name__, "message": str(error)},
              "model_inference_by_auditor": False, "raw_score_values_read": False,
              "missing_computations_added": False, "new_numeric_audit": False}
    try:
        _check_time(ctx)
        _require(stage == "gradient", "Independent saved partial-failure audit is limited to phase two")
        manifest = _read_json(output / "manifest.json")
        _require(manifest["deadline_monotonic"] == float(_get(ctx, "deadline")) and
                 manifest["pid"] == os.getpid() and manifest["plan_sha256"] == PLAN_SHA and
                 manifest["score_numeric_reads_allowed"] is False, "Failed phase identity/deadline differs")
        report["budget"] = _budget(ctx, number, manifest)
        report["protected_original_files"] = _protection(ctx)
        for relative, locked in manifest["source_identity"].items():
            _check_time(ctx)
            _require(_sha(_safe(REPO / relative, REPO)) == locked,
                     f"Failed-phase reviewed implementation bytes changed: {relative}")
        failed_path = output / "failure.json"
        partial_path = output / "gradient_result.json"
        _require(failed_path.is_file() and partial_path.is_file(), "No complete saved first failure/partial gradient record")
        partial = _read_json(partial_path)
        _require(partial["status"] == "FAILED_OR_UNCONFIRMED",
                 "Partial gradient result does not record an incomplete failed phase")
        report["bound_failure_records"] = {"failure": {"path": str(failed_path), "sha256": _sha(failed_path)},
                                           "gradient_result": {"path": str(partial_path), "sha256": _sha(partial_path)}}
        from .audit_later_v01 import audit_gradient_failure
        report["new_numeric_audit"] = True
        details = audit_gradient_failure(ctx, partial)
        _require(details.get("blocking_failure_verified") is True and details.get("independent_checks_passed") is False and
                 details.get("model_inference_by_auditor", False) is False,
                 "Saved partial evidence does not independently confirm the blocking fact")
        report.update(details)
        _check_time(ctx)
        report["pass"], report["status"] = False, "CONFIRMED_BLOCK"
    except Exception as audit_error:
        report["independent_review_limitation"] = {"type": type(audit_error).__name__, "message": str(audit_error)}
        report["pass"], report["status"], report["blocking_failure_verified"] = False, "BLOCKED_UNREVIEWED", False
    report["ended_utc"] = datetime.now(timezone.utc).isoformat()
    _write_new(path, report)
    return {"pass": False, "stage": stage, "status": report["status"],
            "blocking_failure_verified": report["blocking_failure_verified"], "report_path": str(path),
            "sha256": _sha(path)}
