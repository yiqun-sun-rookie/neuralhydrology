"""Standard-library supervisor of one preserved-gradient independent audit.

The original ninety-two numerical calls remain historical evidence. Only two
new independent baseline calls may start, after the complete paid test gate.
No fitting, primary diagnosis, scoring or remote operation is admitted here.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import queue
import re
import subprocess
import stat
import sys
import threading
import time
import traceback
from types import ModuleType
import uuid
import xml.etree.ElementTree as ET
from multiprocessing.connection import Listener

REPO = Path(__file__).resolve().parents[3]
FAMILY = REPO / "results/precip_input_da_2026_09/effect_first_v01"
CONFIG = REPO / "src/precip_input_assimilation/configs/precip_local_gradient_preserved_audit_v09.json"
OWNER = FAMILY / "local_gradient_flexible_owner_v04.json"
PLAN_SHA = "c9fe5cabc407adf5e716e5b64cd725955bd629ca9dc5fe9731d65f8f231d9ae3"
PLAN_REVIEW_SHA = "476bd8f3739cf2353dc0a34ef571b09de42e4dd00dbb2791645a60a5a00ce2d0"
BOUND_SHA = "4165be37e56dfd8938d5c2bd0ea0493a00a7dfa194bd1dfe5563ae689ce2ac6f"
BASELINE_SHA = "1023a40c541a796927995575ee5e76eb3f00aaec005439f1dd52882a75af3b5e"
PRE_ADMISSION_META = "results/precip_input_da_2026_09/effect_first_v01/local_gradient_flexible_execution_20261011_v04/"
PRE_ADMISSION_REPAIR_PINS = [
    {"path": PRE_ADMISSION_META + "candidate_sources_v04_04.json",
     "sha256": "567fb4f3c33e0683c6802b397d4064e958213a21377096a87af23a17c266180d"},
    {"path": PRE_ADMISSION_META + "independent_code_review_v04_04.json",
     "sha256": "4227d76dfdcc1af64838a1a40b88ca89a780e4a999107c99483b0fe83d241135"},
    {"path": PRE_ADMISSION_META + "independent_code_review_v04_04.md",
     "sha256": "eb80e88b976b9941c409bdec6fdf8dd87d4854d1750daccec8ac59a60be2a90b"},
    {"path": PRE_ADMISSION_META + "actual_metadata_directory_startup_failure_v04.json",
     "sha256": "cfa423704041304bb4e3c0c734c8015f182bd377b091689cfe1152c2dba6ad2a"},
    {"path": PRE_ADMISSION_META + "actual_supervisor_stderr_20261011T095049Z.log",
     "sha256": "0f6f8c232ac609410adab0e2e0555032809f879f210ee13a2bd20beb27d414cd"},
    {"path": PRE_ADMISSION_META + "actual_supervisor_stdout_20261011T095049Z.log",
     "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"},
    {"path": PRE_ADMISSION_META + "actual_launch_20261011T095049Z.json",
     "sha256": "31c8786b4406324b996fb5fc4a16f22d86cc304e5419efc3038dadce33a27c41"},
    {"path": PRE_ADMISSION_META + "actual_metadata_directory_startup_failure_independent_review_v04.json",
     "sha256": "5ee4b785faf289df574a73f045b057a0349ab9c2a97bad3399a5cc5a356d80d4"},
    {"path": PRE_ADMISSION_META + "actual_metadata_directory_startup_failure_independent_review_v04.md",
     "sha256": "8318ecaa2a0023030a1e54d553b819180c8266c18ed07a10f8fcd46b38a27312"},
    {"path": PRE_ADMISSION_META + "independent_actual_unexpected_setup_debit_review_v02.json",
     "sha256": "25af3359ae2217ce549d1c84a09058c34d739c9fb53681da83d38d4842626074"},
    {"path": PRE_ADMISSION_META + "independent_actual_unexpected_setup_debit_review_v02.md",
     "sha256": "759c8f04c084c3977bfe452e6fd4eff5ee66061f29a1e17f1797661f5c49cb76"}]


def require_standard_library_supervisor():
    if any(name == library or name.startswith(library + ".")
           for name in sys.modules for library in ("torch", "numpy", "pandas")):
        raise PermissionError("Numerical library import is prohibited in the metadata supervisor")


def install_metadata_package_namespace():
    """Resolve exact submodules without executing the eager scientific initializer."""
    require_standard_library_supervisor()
    name = "precip_input_assimilation"
    location = str(REPO / "src" / name)
    existing = sys.modules.get(name)
    if existing is not None:
        if (getattr(existing, "_metadata_namespace_root", None) != location
                or getattr(existing, "__path__", None) != [location]
                or getattr(existing, "__package__", None) != name):
            raise PermissionError("Existing scientific package cannot become a metadata namespace")
        return
    package = ModuleType(name)
    package.__path__ = [location]
    package.__package__ = name
    package._metadata_namespace_root = location
    sys.modules[name] = package


def sha256(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1048576), b""):
            value.update(block)
    return value.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    from precip_input_assimilation.scripts.run_precip_small_sample_diagnostic_v01 import old_entry
    old_entry().write_json(path, value)


def safe_file(path, must_exist=True):
    from precip_input_assimilation.small_sample.saved_boundaries_v01 import safe_path
    return safe_path(Path(path), REPO, must_exist=must_exist)


def safe_directory(path, must_exist=True):
    """Require a real scoped directory, or only an absent final component.

    Every ancestor query and strict resolution must succeed. This directory
    gate does not weaken the unchanged regular-file gate used for evidence.
    """
    path, root = Path(path).absolute(), REPO.absolute()
    if ".." in path.parts or not path.is_relative_to(root):
        raise PermissionError("Directory path is outside the exact repository scope")
    missing_leaf = False
    for current in (path, *path.parents):
        try:
            info = current.lstat()
        except FileNotFoundError:
            if current == path and not must_exist:
                missing_leaf = True
                continue
            raise
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise PermissionError("Directory path contains a link or reparse point")
        if not stat.S_ISDIR(info.st_mode):
            raise NotADirectoryError("Directory path or ancestor is not a directory: " + str(current))
    resolved_root = root.resolve(strict=True)
    if missing_leaf:
        resolved = path.parent.resolve(strict=True) / path.name
    else:
        resolved = path.resolve(strict=True)
    if resolved != path or not resolved.is_relative_to(resolved_root):
        raise PermissionError("Directory resolution changed its admitted scope")
    return path


def require_pre_admission_repair_metadata(recipe):
    """Bind the actual pre-budget directory failure and all 63 frozen sources."""
    pins = recipe.get("pre_admission_repair_pinned_metadata")
    if pins != PRE_ADMISSION_REPAIR_PINS:
        raise PermissionError("Pre-admission directory repair evidence changed")
    identities = {}
    for row in pins:
        path = safe_file(REPO / row["path"])
        if sha256(path) != row["sha256"]:
            raise PermissionError("Pre-admission repair preservation bytes changed")
        identities[row["path"]] = row["sha256"]
    inventory = read_json(REPO / pins[0]["path"])
    approval = read_json(REPO / pins[1]["path"])
    prior_sources = inventory.get("source_identity")
    if (not isinstance(prior_sources, dict) or len(prior_sources) != 63
            or inventory.get("source_count") != 63
            or approval.get("status") != "PASS_STATIC_REQUIRE_REGISTERED_TESTS"
            or approval.get("pass") is not True or approval.get("source_identity") != prior_sources
            or "src/precip_input_assimilation/scripts/run_precip_local_gradient_small_sample_v04.py" not in prior_sources
            or "src/precip_input_assimilation/configs/precip_local_gradient_small_sample_v04.json" not in prior_sources):
        raise PermissionError("Frozen fourth-version approval/source inventory is incomplete")
    for name, expected in prior_sources.items():
        if sha256(safe_file(REPO / name)) != expected:
            raise PermissionError("A frozen fourth-version source changed during directory repair")
        identities[name] = expected
    failure = read_json(REPO / pins[3]["path"])
    absent = ("owner_absent", "counter_origin_absent", "counter_store_absent", "numeric_output_absent")
    not_started = ("numerical_libraries_loaded", "tests_started", "scientific_compute_started",
                   "new_numerical_reservation_created")
    launch = read_json(REPO / pins[6]["path"])
    if (failure.get("status") != "FAILED_BEFORE_NUMERICAL_ADMISSION"
            or failure.get("cause") != "existing metadata directory incorrectly passed to a regular-file guard"
            or failure.get("charged_seconds") != 96405 or failure.get("event_count") != 12
            or failure.get("open_allocations") != 0
            or any(failure.get(name) is not True for name in absent)
            or any(failure.get(name) is not False for name in not_started)
            or launch.get("approval_sha256") != pins[1]["sha256"]
            or failure.get("log_identities") != {row["path"]: row["sha256"] for row in pins[4:7]}):
        raise PermissionError("Actual failure cannot be treated as an unstarted metadata-only repair")
    return identities


def config(config_path=CONFIG):
    recipe = read_json(safe_file(config_path))
    bindings = (("plan", "plan_sha256", PLAN_SHA),
                ("plan_review", "plan_review_sha256", PLAN_REVIEW_SHA),
                ("boundary_evidence_config", "boundary_evidence_config_sha256", BOUND_SHA))
    for path_key, hash_key, expected in bindings:
        if recipe.get(hash_key) != expected or sha256(safe_file(REPO / recipe[path_key])) != expected:
            raise PermissionError("Reviewed plan or protected boundary bytes changed")
    if read_json(REPO / recipe["plan_review"]).get("status") != "PASS_STATIC_PLAN_ONLY":
        raise PermissionError("Independent flexible plan review did not pass")
    required = {"schema": "precip_local_gradient_preserved_audit_v09", "basin": "01487000",
                "seeds": [1001, 1002, 1003], "target_start": "1980-10-02", "target_end": "1980-11-02",
                "max_steps": 1000, "checkpoint_interval": 10, "mse_threshold": .0001,
                "relative_reduction": .99, "network_learning_rate": .001, "control_learning_rate_mm": .1,
                "soft_penalties": {"magnitude": 0., "violation": 0.}, "soft_penalties_graph": "absent",
                "score_numeric_reads_allowed": False, "new_remote_jobs": 0, "exit_reserve_seconds": 300,
                "parameter_scales": [.0001, .0003, .001, .003, .01], "max_full_forwards": 100,
                "gradient_relative_error": .05, "minimum_terminal_direction_response": .001,
                "parameter_direction_error_limit": .001, "parameter_midpoint_error_per_scale_limit": .001,
                "scalar_minimum_ulp_multiple": 32, "audit_only": True,
                "original_evidence_forward_count": 92, "new_audit_forward_count": 2}
    for key, value in required.items():
        if recipe.get(key) != value:
            raise PermissionError("Unregistered scientific recipe field: " + key)
    policy = {"cumulative_seconds_max": 259200, "single_reservation_seconds_max": 21600,
              "stage_seconds_max": None, "single_attempt_per_stage": False,
              "pure_metadata_tail_separately_reported": True, "whole_numeric_group_exit_required": True,
              "atomic_slice_rollover_required": True}
    if recipe.get("resource_policy") != policy or "repair_protocol" in recipe:
        raise PermissionError("Unreviewed resource policy")
    attempt = recipe.get("attempt", {})
    ordinal = attempt.get("ordinal")
    if (type(ordinal) is not int or ordinal != 5
            or not re.fullmatch(r"flexible_[0-9]{8}_v04_attempt_[0-9]{3}", attempt.get("id", ""))
            or not attempt["id"].endswith("attempt_" + str(ordinal).zfill(3))
            or attempt.get("id") != "flexible_20261011_v04_attempt_005"
            or attempt.get("start_stage") != "gradient"
            or attempt.get("retry_admission") is None):
        raise PermissionError("Attempt identity or explicit repair admission changed")
    expected_stages = {"gradient": {"output": "gradient/attempt_005", "previous": None}}
    if recipe.get("stages") != expected_stages:
        raise PermissionError("Stage order or new output identity changed")
    old_tests = read_json(safe_file(REPO / "src/precip_input_assimilation/configs/precip_local_gradient_small_sample_v08.json"))["registered_tests"]
    if recipe.get("registered_tests") != old_tests + ["test_preserved_gradient_audit_entry_v09.py",
                                                     "test_local_gradient_preserved_audit_v05.py"]:
        raise PermissionError("Original complete registered tests or the new audit guards were dropped")
    for key in ("budget_baseline", "counter_initialization_evidence", "old_v03_config", "setup_debit_receipt"):
        row = recipe[key]
        if sha256(safe_file(REPO / row["path"])) != row["sha256"]:
            raise PermissionError("Historical or counter initialization evidence changed")
    evidence = recipe["setup_debit_pinned_metadata"]
    if (not isinstance(evidence, list) or not evidence
            or len({row["path"] for row in evidence}) != len(evidence)):
        raise PermissionError("Unexpected setup debit lacks unique fixed evidence")
    for row in evidence:
        if sha256(safe_file(REPO / row["path"])) != row["sha256"]:
            raise PermissionError("Unexpected setup debit source evidence changed")
    if recipe["budget_baseline"]["sha256"] != BASELINE_SHA:
        raise PermissionError("Original settled budget baseline changed")
    if attempt["retry_admission"] is not None:
        record = attempt["retry_admission"]
        if sha256(safe_file(REPO / record["path"])) != record["sha256"]:
            raise PermissionError("Explicit technical repair admission bytes changed")
    for key in ("preserved_gradient_audit_binding", "technical_recovery_plan", "technical_recovery_plan_review"):
        row = recipe.get(key)
        if (not isinstance(row, dict) or set(row) != {"path", "sha256"}
                or sha256(safe_file(REPO / row["path"])) != row["sha256"]):
            raise PermissionError("Preserved-audit technical source bytes changed: " + key)
    recovery_review = read_json(REPO / recipe["technical_recovery_plan_review"]["path"])
    if (recovery_review.get("status") != "PASS_STATIC_PLAN_REQUIRE_CODE_REVIEW_AND_PAID_ORIGINAL_BIT_EVIDENCE"
            or recovery_review.get("pass") is not True or recovery_review.get("static_blockers") != []
            or recovery_review.get("actual_numerical_execution_or_runtime_admission_proven") is not False
            or recovery_review.get("scientific_acceptance") is not False
            or recovery_review.get("plan_sha256") != recipe["technical_recovery_plan"]["sha256"]):
        raise PermissionError("Audit-only recovery lacks an independent technical plan review")
    require_preserved_binding(recipe)
    return recipe


def source_identity(recipe, config_path=CONFIG):
    files = [Path(__file__), Path(config_path),
             REPO / "src/precip_input_assimilation/tests/conftest.py",
             REPO / "src/precip_input_assimilation/scripts/make_toy_run.py",
             REPO / "src/precip_input_assimilation/__init__.py",
             REPO / "src/precip_input_assimilation/scripts/run_precip_local_gradient_preserved_audit_worker_v05.py",
             REPO / "src/precip_input_assimilation/scripts/observe_precip_flexible_management_tail_v04.py",
             REPO / "src/precip_input_assimilation/scripts/run_precip_local_gradient_small_sample_v03.py",
             REPO / "src/precip_input_assimilation/scripts/run_precip_small_sample_diagnostic_v01.py",
             REPO / "src/precip_input_assimilation/scripts/run_precip_effect_first_v02.py",
             *sorted((REPO / "src/precip_input_assimilation/small_sample").glob("*.py")),
             *[REPO / "src/precip_input_assimilation/tests" / name for name in recipe["registered_tests"]],
             REPO / recipe["plan"], REPO / recipe["plan_review"],
             REPO / recipe["boundary_evidence_config"],
             *[REPO / recipe[key]["path"] for key in
               ("budget_baseline", "counter_initialization_evidence", "old_v03_config", "setup_debit_receipt")],
             *[REPO / row["path"] for row in recipe["setup_debit_pinned_metadata"]],
             *[REPO / recipe[key]["path"] for key in
               ("preserved_gradient_audit_binding", "technical_recovery_plan", "technical_recovery_plan_review")]]
    if recipe["attempt"]["retry_admission"] is not None:
        files.append(REPO / recipe["attempt"]["retry_admission"]["path"])
        admission = read_json(files[-1])
        for row in admission["pinned_metadata"]:
            path = safe_file(REPO / row["path"])
            if sha256(path) != row["sha256"]:
                raise PermissionError("Repair source metadata differs from its pinned admission")
            files.append(path)
    sources = {safe_file(p).relative_to(REPO).as_posix(): sha256(p) for p in files}
    preserved = require_pre_admission_repair_metadata(recipe)
    if any(sources.get(name, expected) != expected for name, expected in preserved.items()):
        raise PermissionError("Current candidate conflicts with frozen pre-admission repair evidence")
    return dict(preserved, **sources)


def safe_future_directory(path):
    """Validate an absent nested output without creating any component."""
    path = Path(path).absolute()
    if ".." in path.parts or not path.is_relative_to(REPO.absolute()):
        raise PermissionError("Future audit output escaped the repository")
    for current in (path, *path.parents):
        try:
            info = current.lstat()
        except FileNotFoundError:
            continue
        if (stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400
                or not stat.S_ISDIR(info.st_mode) or current.resolve(strict=True) != current):
            raise PermissionError("Future audit output has an unsafe existing ancestor")
    return path


def require_preserved_binding(recipe):
    """Read only fixed metadata; tensor decoding belongs to the paid worker."""
    row = recipe["preserved_gradient_audit_binding"]
    path = safe_file(REPO / row["path"])
    if sha256(path) != row["sha256"]:
        raise PermissionError("Preserved gradient binding bytes changed")
    binding = read_json(path)
    old = FAMILY / "local_gradient_small_sample_flexible_20261011_v08"
    proof = old / "gradient/attempt_004"
    new = FAMILY / "local_gradient_preserved_audit_20261011_v09"
    required = {"schema": "precip_preserved_gradient_audit_binding_v05",
                "family_root": str(FAMILY.as_posix()), "evidence_root": old.as_posix(),
                "proof_root": proof.as_posix(), "report_root": (new / "gradient/attempt_005").as_posix(),
                "original_attempt_id": "flexible_20261011_v04_attempt_004",
                "original_counter_attempt_id": "flexible_20261011_v04_attempt_004_gradient_full_forward",
                "new_attempt_id": recipe["attempt"]["id"], "original_evidence_forward_count": 92,
                "new_audit_forward_count": 2, "cumulative_limit": 100}
    if (any(binding.get(key) != value for key, value in required.items())
            or Path(REPO / recipe["output_root"]).absolute() != new.absolute()):
        raise PermissionError("Preserved audit scope or fixed counts changed")
    for directory in (FAMILY, old, proof):
        safe_directory(directory)
    safe_future_directory(new / "gradient/attempt_005")
    if any((directory / "STOP").exists() for directory in (FAMILY, old, proof, new, new / "gradient/attempt_005")):
        raise InterruptedError("Manual stop in original or new evidence scope remains in force")
    files = {"result_identity": proof / "stage_result.json",
             "local_result_identity": proof / "local_gradient_result.json",
             "original_stage_context_identity": proof / "context_identity.json",
             "manifest_identity": proof / "stage_manifest.json", "failure_identity": old / "worker_failure.json"}
    for key, expected_path in files.items():
        identity = binding.get(key)
        if (not isinstance(identity, dict) or set(identity) != {"path", "sha256", "bytes"}
                or type(identity["bytes"]) is not int or identity["bytes"] <= 0
                or not isinstance(identity["sha256"], str)
                or re.fullmatch(r"[0-9a-f]{64}", identity["sha256"]) is None
                or Path(identity["path"]).absolute() != expected_path.absolute()
                or not Path(identity["path"]).is_absolute()):
            raise PermissionError("Preserved audit file identity changed: " + key)
        admitted = safe_file(expected_path)
        if admitted.stat().st_size != identity["bytes"] or sha256(admitted) != identity["sha256"]:
            raise PermissionError("Preserved audit original bytes changed: " + key)
    result = read_json(files["result_identity"])
    local_result = read_json(files["local_result_identity"])
    if (local_result != {key: value for key, value in result.items() if key != "registered_tests"}
            or result.get("execution_complete") is not True or result.get("numerical_gate_pass") is not False
            or result.get("full_forward_count") != 92 or result.get("cumulative_full_forward_count") != 92
            or len(result.get("full_forward_receipts", [])) != 92
            or len(result.get("completed_records", [])) != 18
            or sha256(files["result_identity"]) != "08836dc655a23fe7a17d1efd3ee0ae0957e3fb3ce00a8849c3ce92470985cf3f"
            or sha256(files["local_result_identity"]) != "b361df9f7a26cb7717d648212683d552f6f9e8bda2aac7a4eb4157852b5d0fc4"):
        raise PermissionError("Original ninety-two calls or adverse classifications changed")
    manifest, failure = read_json(files["manifest_identity"]), read_json(files["failure_identity"])
    if (manifest.get("stage") != "gradient" or manifest.get("attempt_id") != binding["original_attempt_id"]
            or failure.get("error_type") != "IndependentAuditFailure"
            or failure.get("error") != "Tensor bytes differ: physical terminal preserves feasible controls"):
        raise PermissionError("Original audit failure or primary manifest changed")
    admission = read_json(REPO / recipe["attempt"]["retry_admission"]["path"])
    snapshot_row = admission["counter_snapshot"]
    snapshot_path = safe_file(REPO / snapshot_row["path"])
    if sha256(snapshot_path) != snapshot_row["sha256"]:
        raise PermissionError("Original counter snapshot bytes changed")
    frozen = read_json(snapshot_path)
    require_preserved_counter_state(frozen, binding, frozen, None, for_admission=True)
    return binding, frozen


def require_preserved_counter_state(snapshot, binding, frozen, source_digest, *, for_admission=False):
    """Allow only an unchanged old prefix, one fresh attempt and two starts."""
    prefix_count = binding["counter_prefix_event_count"]
    receipts = snapshot.get("receipts")
    prior = frozen.get("receipts")
    old_id, new_id = binding["original_counter_attempt_id"], binding["new_attempt_id"] + "_gradient_full_forward"
    old_attempt = frozen.get("attempts", {}).get(old_id, {})
    if (type(prefix_count) is not int or prefix_count != 94
            or not isinstance(receipts, list) or not isinstance(prior, list) or len(prior) != prefix_count
            or receipts[:prefix_count] != prior or len(receipts) < prefix_count
            or snapshot.get("event_count") != len(receipts)
            or frozen.get("event_count") != prefix_count
            or frozen.get("head_sha256") != binding["counter_prefix_head_sha256"]
            or prior[-1].get("sha256") != binding["counter_prefix_head_sha256"]
            or prior[0].get("sha256") != binding["counter_genesis_sha256"]
            or snapshot.get("binding") != binding["counter_binding"] or frozen.get("binding") != binding["counter_binding"]
            or snapshot.get("initialization_evidence_sha256") != binding["counter_initialization_evidence_sha256"]
            or frozen.get("initialization_evidence_sha256") != binding["counter_initialization_evidence_sha256"]
            or old_attempt.get("attempt_nonce") != binding["original_counter_attempt_nonce"]
            or old_attempt.get("source_sha256") != binding["original_source_digest"]
            or old_attempt.get("stage") != "gradient_full_forward"
            or frozen.get("counts", {}).get("gradient_full_forward") != 92
            or any(value != 0 for key, value in frozen.get("counts", {}).items() if key != "gradient_full_forward")
            or snapshot.get("initial_counts") != frozen.get("initial_counts")
            or snapshot.get("audit_counts") != frozen.get("audit_counts")):
        raise PermissionError("Original durable counter prefix or provenance changed")
    extra = receipts[prefix_count:]
    if for_admission:
        if extra or snapshot != frozen or new_id in snapshot.get("attempts", {}):
            raise PermissionError("Preserved audit requires a genuinely fresh zero-count attempt")
        return {"counter_id": new_id, "new_started": 0}
    if not 1 <= len(extra) <= 3:
        raise PermissionError("Preserved audit has no unique registration or exceeded two starts")
    registration = extra[0].get("payload", {}).get("event", {})
    expected_registration = {"kind": "attempt", "attempt_id": new_id,
                             "attempt_nonce": registration.get("attempt_nonce"), "source_sha256": source_digest,
                             "stage": "gradient_full_forward", "audit_binding": None}
    if (registration != expected_registration or not registration.get("attempt_nonce")
            or snapshot.get("attempts") != dict(frozen["attempts"], **{new_id: registration})):
        raise PermissionError("New audit attempt registration has another source or identity")
    for index, record in enumerate(extra[1:], 1):
        event = record.get("payload", {}).get("event", {})
        if (event.get("kind") != "operation" or event.get("attempt_id") != new_id
                or event.get("attempt_nonce") != registration["attempt_nonce"]
                or event.get("source_sha256") != source_digest or event.get("counter") != "gradient_full_forward"
                or event.get("update_id") is not None or event.get("cumulative_count") != 92 + index):
            raise PermissionError("Preserved audit counter receipt is not a fresh independent forward")
    count = len(extra) - 1
    expected_counts = dict(frozen["counts"], gradient_full_forward=92 + count)
    if snapshot.get("counts") != expected_counts or snapshot.get("head_sha256") != receipts[-1].get("sha256"):
        raise PermissionError("New audit count does not match its actual durable starts")
    return {"counter_id": new_id, "new_started": count}


def require_preserved_consume(body, state, attempt_id):
    if (type(state.get("new_started")) is not int or not 0 <= state["new_started"] < 2
            or body.get("kind") != "full_forward" or body.get("key") != "gradient"
            or body.get("label") != ("independent_base_original", "independent_base_extension")[state["new_started"]]
            or not isinstance(body.get("bindings"), dict)
            or body["bindings"] != {"attempt_id": attempt_id, "next_attempt_count": state["new_started"] + 1}
            or state["new_started"] >= 2):
        raise PermissionError("Audit-only entry permits exactly two new gradient baseline calls")
    return state["counter_id"]


def require_registered_test_admission(result, xml_summary, expected_sources, group_snapshot):
    summary = result.get("summary", {})
    if (result.get("returncode") != 0 or type(summary.get("tests")) is not int or summary["tests"] < 552
            or set(summary) != {"tests", "failures", "errors", "skipped"} or summary != xml_summary
            or any(type(summary[key]) is not int or summary[key] != 0 for key in ("failures", "errors", "skipped"))
            or result.get("test_sources") != expected_sources
            or result.get("all_tests_inside_metered_group") is not True):
        raise PermissionError("Complete paid registered tests have not all passed")
    identity = result.get("child_identity", {}).get("identity", {})
    observed = group_snapshot.get("all_observed", [])
    matches = [item for item in observed if item.get("pid") == identity.get("pid")
               and item.get("windows_creation_identity") == identity.get("windows_creation_identity")]
    worker = group_snapshot.get("worker", {})
    if (type(identity.get("pid")) is not int or not identity.get("windows_creation_identity")
            or len(matches) != 1 or matches[0].get("status") != "EXITED"
            or matches[0].get("wait_signaled") is not True or matches[0].get("exit_code") != 0
            or matches[0].get("native_process_handle_retained") is not True
            or matches[0].get("registered_as_job_member") is not True
            or group_snapshot.get("native_query_succeeded") is not True
            or any(item.get("status") != "EXITED" for item in observed
                   if (item.get("pid"), item.get("windows_creation_identity"))
                   != (worker.get("pid"), worker.get("windows_creation_identity")))):
        raise PermissionError("Paid test descendants lack complete exact owned native exit proof")
    return True


def load_registered_test_admission(output, recipe, group):
    folder = safe_directory(output / "registered_tests")
    result_path, xml_path = safe_file(folder / "result.json"), safe_file(folder / "report.xml")
    tree = ET.parse(xml_path).getroot()
    suites = [tree] if tree.tag == "testsuite" else list(tree.iter("testsuite"))
    summary = {key: sum(int(suite.get(key, "0")) for suite in suites)
               for key in ("tests", "failures", "errors", "skipped")}
    paths = [safe_file(REPO / "src/precip_input_assimilation/tests" / name
                       if Path(name).name == name else REPO / name) for name in recipe["registered_tests"]]
    if len(paths) != len(set(paths)):
        raise PermissionError("Registered tests are duplicated")
    expected = {str(path): sha256(path) for path in paths}
    result, snapshot = read_json(result_path), group.snapshot()
    require_registered_test_admission(result, summary, expected, snapshot)
    return {"result_path": str(result_path), "result_sha256": sha256(result_path),
            "xml_sha256": sha256(xml_path), "summary": summary, "native_group": snapshot}


def require_preserved_actual_audit(actual, original_result, binding, attempt_id, source_digest):
    required = {"status": "BLOCKED_OR_UNCONFIRMED", "pass": False, "stage": "gradient",
                "independent_checks_passed": True, "raw_trajectories_checked": 90,
                "objective_directions_checked": 18, "independent_model_replays": 2,
                "full_forward_count": 2, "cumulative_full_forward_count": 94,
                "preserved_evidence_mode": True, "original_evidence_forward_count": 92,
                "new_audit_forward_count": 2, "combined_evidence_forward_count": 94,
                "later_fitting_prohibited": True, "new_fitting_executed": False,
                "scientific_fit_or_forecast_claim": False}
    if (any(actual.get(key) != value for key, value in required.items())
            or actual.get("pass") is not False or actual.get("independent_checks_passed") is not True
            or actual.get("original_result_identity") != binding["result_identity"]
            or actual.get("original_failure_identity") != binding["failure_identity"]
            or actual.get("original_forward_receipts") != original_result["full_forward_receipts"]
            or len(actual.get("decisions", [])) != 18
            or sum(row.get("effective") is True for row in actual["decisions"]) != 15
            or sum(row.get("effective") is False for row in actual["decisions"]) != 3
            or len(actual.get("new_actual_base_proofs", [])) != 2):
        raise PermissionError("Preserved independent audit changed original adverse decisions or exact two-call evidence")
    receipts = actual.get("full_forward_receipts")
    if not isinstance(receipts, list) or len(receipts) != 2:
        raise PermissionError("Historical calls were copied into the new attempt's receipts")
    persistent = actual.get("persistent_counters", {})
    counter_id = attempt_id + "_gradient_full_forward"
    registration = persistent.get("attempts", {}).get(counter_id, {})
    raw_receipts = persistent.get("receipts", [])[-2:]
    if (registration.get("attempt_id") != counter_id or registration.get("source_sha256") != source_digest
            or not registration.get("attempt_nonce") or len(raw_receipts) != 2):
        raise PermissionError("New report is missing its actual registered counter attempt")
    for index, receipt in enumerate(receipts, 1):
        if (not isinstance(receipt, dict) or set(receipt) != {"record", "cumulative_count"}
                or type(receipt["cumulative_count"]) is not int or receipt["cumulative_count"] != 92 + index
                or receipt["record"] != raw_receipts[index - 1]):
            raise PermissionError("Forward response differs from its actual durable counter receipt")
        record = receipt["record"]
        event = record.get("payload", {}).get("event", {})
        identity = hashlib.sha256(json.dumps(record.get("payload"), sort_keys=True, separators=(",", ":"),
                                             allow_nan=False).encode("utf-8")).hexdigest()
        if (set(record) != {"payload", "sha256"} or record["sha256"] != identity
                or event.get("kind") != "operation" or event.get("counter") != "gradient_full_forward"
                or event.get("attempt_id") != attempt_id + "_gradient_full_forward"
                or event.get("attempt_nonce") != registration["attempt_nonce"]
                or event.get("label") != ("independent_base_original", "independent_base_extension")[index - 1]
                or event.get("source_sha256") != source_digest or event.get("cumulative_count") != 92 + index):
            raise PermissionError("New independent forward receipt has another attempt or source")
    return True


def require_finished_preserved_audit(body, output, binding, frozen_snapshot, snapshot, source_digest):
    result = body.get("result", {})
    required = {"status": "SCIENTIFIC_BLOCKED_OR_UNCONFIRMED", "stage": "gradient", "audit_only": True,
                "summaries": [], "original_evidence_forward_count": 92, "new_audit_forward_count": 2,
                "cumulative_full_forward_count": 94, "independent_checks_passed": True,
                "new_fitting_executed": False, "later_fitting_prohibited": True,
                "scientific_forecast_improvement_claim": False}
    if any(result.get(key) != value for key, value in required.items()):
        raise PermissionError("Audit worker claimed an unregistered completion or scientific result")
    state = require_preserved_counter_state(snapshot, binding, frozen_snapshot, source_digest)
    if state["new_started"] != 2:
        raise PermissionError("Independent audit completion needs exactly two durable numerical starts")
    report_root = safe_directory(output / "gradient/attempt_005")
    report = result.get("actual_audit", {})
    actual_path = safe_file(Path(report.get("report_path", "")))
    if actual_path != report_root / "actual_independent_gradient_audit.json" or sha256(actual_path) != report.get("sha256"):
        raise PermissionError("Worker completion has no exact new actual audit report")
    actual = read_json(actual_path)
    original = read_json(safe_file(Path(binding["result_identity"]["path"])))
    require_preserved_actual_audit(actual, original, binding, binding["new_attempt_id"], source_digest)
    if actual.get("persistent_counters") != snapshot:
        raise PermissionError("Independent final audit counter snapshot changed")
    wrapper = read_json(safe_file(report_root / "independent_actual_audit.json"))
    stage = read_json(safe_file(report_root / "stage_result.json"))
    blocked = read_json(safe_file(report_root / "fitting_blocked.json"))
    if (wrapper != report or stage.get("schema") != "precip_preserved_gradient_audit_result_v09"
            or stage.get("execution_complete") is not True or stage.get("independent_checks_passed") is not True
            or stage.get("numerical_gate_pass") is not False or stage.get("audit_only") is not True
            or stage.get("new_fitting_executed") is not False or stage.get("score_numeric_reads_allowed") is not False
            or stage.get("original_result_identity") != binding["result_identity"]
            or stage.get("original_local_result_identity") != binding["local_result_identity"]
            or stage.get("actual_audit_sha256") != report["sha256"]
            or stage.get("full_forward_count") != 2 or stage.get("new_audit_forward_count") != 2
            or stage.get("cumulative_full_forward_count") != 94
            or stage.get("full_forward_receipts") != actual["full_forward_receipts"]
            or blocked.get("new_fitting_executed") is not False or blocked.get("later_fitting_prohibited") is not True
            or (report_root / "stage_complete.json").exists()):
        raise PermissionError("New saved audit was substituted for scientific acceptance or original evidence")
    return True


def require_setup_debit(recipe, original):
    """Close the preserved unreserved setup deviation before any new numeric admission."""
    row = recipe["setup_debit_receipt"]
    receipt_path = safe_file(REPO / row["path"])
    if sha256(receipt_path) != row["sha256"]:
        raise PermissionError("Unexpected setup receipt identity changed")
    receipt = read_json(receipt_path)
    required = {"schema": "precip_unexpected_setup_debit_receipt_v01", "status": "COMMITTED",
                "execution_scope": "standard_library_management_exception_debit_only",
                "ledger_before_sha256": BASELINE_SHA, "original_event_count": 10, "new_event_count": 12,
                "charged_before_seconds": 96089, "charged_after_seconds": 96405,
                "conservative_charge_seconds": 316, "remaining_seconds": 162795, "total_seconds": 259200,
                "open_allocations": 0, "actual_setup_seconds": None, "actual_monotonic_elapsed_seconds": None,
                "external_utc_bracket_seconds": 315, "policy_padding_seconds": 1, "clock_is_monotonic": False,
                "original_event_prefix_preserved": True, "original_ledger_bytes_saved": True,
                "atomic_two_event_publication": True, "original_reader_validation_passed": True,
                "actual_exclusive_family_lock_held": True, "scientific_compute_started": False,
                "scientific_input_reads": False, "tests_started": False, "counters_modified": False,
                "new_subprocesses": 0, "management_operations_are_not_scientific_compute": True}
    if any(receipt.get(key) != value for key, value in required.items()):
        raise PermissionError("Unexpected unreserved setup deviation has not been closed")
    pinned = {item["path"]: item["sha256"] for item in recipe["setup_debit_pinned_metadata"]}
    def bound(path, expected):
        path = safe_file(path)
        relative = path.relative_to(REPO).as_posix()
        if pinned.get(relative) != expected or sha256(path) != expected:
            raise PermissionError("Setup debit evidence is absent from the current fixed admission")
        return path
    for name, expected in receipt["source_identity"].items():
        bound(REPO / name, expected)
    approval_path = bound(receipt_path.parent / "independent_approval.json", receipt["approval_sha256"])
    approval = read_json(approval_path)
    if (approval.get("schema") != "precip_unexpected_setup_debit_review_v01"
            or approval.get("status") != "PASS" or approval.get("pass") is not True
            or approval.get("source_identity") != receipt["source_identity"]
            or approval.get("conservative_charge_seconds") != 316
            or approval.get("rule_sha256") != receipt["rule_sha256"]
            or approval.get("ledger_before_sha256") != BASELINE_SHA
            or approval.get("execution_scope") != receipt["execution_scope"]):
        raise PermissionError("Unexpected setup debit lacks exact independent approval")
    bound(receipt_path.parent / "source_proof.json", receipt["source_proof_sha256"])
    before_path = bound(receipt_path.parent / "budget_before_original_bytes.json", BASELINE_SHA)
    candidate_path = bound(receipt_path.parent / "budget_candidate.json", receipt["budget_candidate_sha256"])
    before, before_used, before_allocations, before_settled = original.load_budget(before_path)
    candidate, candidate_used, candidate_allocations, candidate_settled = original.load_budget(candidate_path)
    journal, used, allocations, settled = original.load_budget(FAMILY / "cumulative_budget_v01.json")
    reserve, settle = receipt["reservation"], receipt["settlement"]
    if (len(before["events"]) != 10 or before_used != 96089 or set(before_allocations) != set(before_settled)
            or len(candidate["events"]) != 12 or candidate_used != 96405
            or set(candidate_allocations) != set(candidate_settled)
            or candidate["events"] != before["events"] + [reserve, settle]
            or journal["events"][:12] != candidate["events"] or used < 96405
            or set(allocations) != set(settled)
            or original.budget_hash(before["events"]) != receipt["original_event_prefix_sha256"]
            or receipt["ledger_after_sha256"] != receipt["budget_candidate_sha256"]):
        raise PermissionError("Setup debit is not a closed member of the original cumulative budget chain")
    rp, sp = reserve["payload"], settle["payload"]
    if (reserve["sha256"] != original.budget_hash(rp) or settle["sha256"] != original.budget_hash(sp)
            or rp.get("kind") != "reserve" or sp.get("kind") != "settle"
            or rp.get("reserved_seconds") != 316 or sp.get("charged_seconds") != 316
            or rp.get("used_before_seconds") != 96089 or rp.get("output") != str(receipt_path.parent.resolve())
            or rp.get("previous_sha256") != before["events"][-1]["sha256"]
            or sp.get("previous_sha256") != reserve["sha256"]
            or sp.get("reservation_sha256") != reserve["sha256"] or rp.get("run_id") != sp.get("run_id")
            or any(payload.get("actual_setup_seconds") is not None
                   or payload.get("actual_monotonic_elapsed_seconds") is not None
                   or payload.get("recorded_now_not_historical_reservation") is not True
                   for payload in (rp, sp))):
        raise PermissionError("Setup debit changed its conservative present-time event identity")
    require_standard_library_supervisor()
    return {"receipt_sha256": row["sha256"], "conservative_charge_seconds": 316,
            "actual_setup_seconds": None, "original_prefix_preserved": True,
            "closed_in_original_budget": True, "used_before_numeric_admission_seconds": used}


def require_approval(path, identity, sources, recipe):
    if sha256(safe_file(path)) != identity:
        raise PermissionError("Independent code approval identity changed")
    review = read_json(path)
    if (review.get("status") != "PASS_STATIC_REQUIRE_REGISTERED_TESTS"
            or review.get("pass") is not True or review.get("source_identity") != sources
            or review.get("registered_tests_before_scientific_model") is not True
            or review.get("resource_policy_static_pass") is not True
            or review.get("numerical_execution_authorized") is not True
            or set(review.get("stage_scope", [])) != {"gradient"}
            or review.get("preserved_gradient_audit_only") is not True
            or review.get("new_audit_forward_count") != 2
            or review.get("registered_tests") != recipe["registered_tests"]):
        raise PermissionError("Exact fourth-version implementation lacks independent admission")
    return review


def actual_lock_held():
    import errno
    import msvcrt
    with (FAMILY / "exclusive.lock").open("r+b") as probe:
        probe.seek(0)
        try:
            msvcrt.locking(probe.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError as error:
            if error.errno != errno.EACCES:
                raise
            return True
        msvcrt.locking(probe.fileno(), msvcrt.LK_UNLCK, 1)
    raise PermissionError("Actual exclusive family lock unexpectedly available")


def verify_preservation(recipe, sources, transport, query_old=False, config_path=CONFIG):
    from precip_input_assimilation.scripts import run_precip_local_gradient_small_sample_v03 as prior
    if source_identity(recipe, config_path) != sources:
        raise PermissionError("Approved current implementation changed")
    old_recipe = read_json(REPO / recipe["old_v03_config"]["path"])
    failure = prior.verify_failure_binding(old_recipe, query_owner=query_old)
    original = prior.original_entry()
    original.verify_original_guard()
    protection = prior.protected_identity(recipe)
    prior.verify_protected(protection)
    if any(sha256(safe_file(Path(path))) != expected for path, expected in transport.items()):
        raise PermissionError("Completed original transport identity changed")
    return failure, protection


def verify_original_predecessor():
    from precip_input_assimilation.scripts import run_precip_local_gradient_small_sample_v03 as prior
    # Only the original weight stage is used here; the old gradient runtime
    # allocation and once-only repair rules are never called.
    return prior.require_predecessor({"stages": {"gradient": {"previous": None}}}, "gradient")


def stage_acceptance(output, stage, attempt_id=None):
    """Metadata acceptance never replaces an actual raw-proof audit."""
    output = safe_directory(output)
    complete = read_json(output / "stage_complete.json")
    result = read_json(output / "stage_result.json")
    wrapper = read_json(output / "independent_actual_audit.json")
    actual_path = safe_file(Path(wrapper["report_path"]))
    actual = read_json(actual_path)
    if (complete.get("stage") != stage or complete.get("pass") is not True
            or complete.get("pending_numeric_group_exit") is not True
            or (attempt_id is not None and complete.get("attempt_id") != attempt_id)
            or result.get("execution_complete") is not True
            or result.get("window_uninformative") is True
            or (stage == "gradient" and result.get("numerical_gate_pass") is not True)
            or wrapper.get("pass") is not True or wrapper.get("stage") != stage
            or actual.get("pass") is not True or actual.get("stage") != stage
            or actual.get("independent_checks_passed") is not True
            or (output / "failure.json").exists()
            or complete["stage_result_sha256"] != sha256(output / "stage_result.json")
            or complete["audit_sha256"] != sha256(output / "independent_actual_audit.json")
            or complete["actual_audit_sha256"] != wrapper["sha256"]):
        raise PermissionError("Stage does not have byte-bound complete actual acceptance")
    if wrapper["sha256"] != sha256(actual_path) or complete["actual_audit_sha256"] != wrapper["sha256"]:
        raise PermissionError("Independent actual report identity changed")
    return {"pass": True, "complete_path": str(output / "stage_complete.json"),
            "sha256": sha256(output / "stage_complete.json"),
            "stage_result_sha256": complete["stage_result_sha256"],
            "audit_sha256": complete["audit_sha256"], "actual_audit_sha256": wrapper["sha256"]}


def repair_admission(recipe, original):
    """A new reviewed configuration binds the exact settled prior attempt."""
    from precip_input_assimilation.small_sample.flexible_budget_v04 import digest
    record = recipe["attempt"]["retry_admission"]
    if record is None:
        return None, {}
    admission = read_json(safe_file(REPO / record["path"]))
    if (admission.get("schema") != "precip_flexible_technical_retry_admission_v04"
            or admission.get("technical_failure_diagnosed") is not True
            or not admission.get("technical_repair_description")
            or admission.get("prior_attempt_id") == recipe["attempt"]["id"]):
        raise PermissionError("An unexamined scientific or technical failure cannot be retried")
    def pinned(row):
        p = safe_file(REPO / row["path"])
        if sha256(p) != row["sha256"]:
            raise PermissionError("Prior technical retry evidence bytes changed")
        if row not in admission["pinned_metadata"]:
            raise PermissionError("Prior retry evidence was not included in source admission")
        return p
    prior_path = pinned(admission["prior_supervisor_report"])
    prior = read_json(prior_path)
    if (prior.get("numeric_group_exited") is not True or prior.get("budget_closure_confirmed") is not True
            or prior.get("source_identity_unchanged") is not True
            or prior.get("final_native_handle_cleanup_confirmed") is not True
            or prior.get("technical_failure") is not True):
        raise PermissionError("Prior attempt is not a completely exited, settled technical failure")
    for name, expected in prior["source_identity"].items():
        if sha256(safe_file(REPO / name)) != expected:
            raise PermissionError("Frozen prior attempt source changed during technical repair")
    oldroot = prior_path.parent
    exit_row = admission["prior_numeric_exit"]
    exit_path = pinned(exit_row)
    if exit_path.parent != oldroot:
        raise PermissionError("Prior group exit belongs to another attempt")
    exited = read_json(exit_path)
    if exited.get("entire_group_exited") is not True or exited.get("native_query_succeeded") is not True:
        raise PermissionError("Prior complete native numerical exit was not proven")
    settlement_path = pinned(admission["prior_budget_settlement"])
    settlement = read_json(settlement_path)
    if (prior.get("numeric_exit_evidence_sha256") != sha256(exit_path)
            or prior.get("budget_settlement_file_sha256") != sha256(settlement_path)
            or settlement["timing"]["exit_proof_sha256"] != digest(exited)):
        raise PermissionError("Prior exact numerical exit is not bound by its final timing and report")
    journal, _, allocations, settled = original.load_budget(FAMILY / "cumulative_budget_v01.json")
    event = settlement["settlement"]
    if (event not in journal["events"] or event["payload"]["run_id"] not in settled
            or allocations[event["payload"]["run_id"]]["sha256"] != event["payload"]["reservation_sha256"]
            or settlement_path.parent != oldroot
            or prior["budget"]["settlement"] != event):
        raise PermissionError("Prior final settlement is not a member of the original ledger")
    names = ["gradient", "direct_control", "network"]
    prefix = names[:names.index(recipe["attempt"]["start_stage"])]
    completed = admission["completed_predecessors"]
    prior_accepted = prior.get("final_stage_acceptance")
    if (not isinstance(prior_accepted, dict)
            or set(prior_accepted) != set(prefix)
            or set(completed) != set(prior_accepted)
            or any(not isinstance(prior_accepted[stage], dict)
                   or prior_accepted[stage].get("pass") is not True for stage in prior_accepted)):
        raise PermissionError("Retry must reuse exactly the already accepted stage prefix")
    for stage, row in completed.items():
        output = safe_directory(Path(row["output"]))
        if not output.resolve().is_relative_to(FAMILY.resolve()):
            raise PermissionError("Prior accepted stage escaped this experiment family")
        accepted = stage_acceptance(output, stage)
        if prior_accepted[stage] != accepted:
            raise PermissionError("Retry discarded or changed prior final accepted stage evidence")
        report_path = safe_file(Path(row["final_supervisor_report_path"]))
        report = read_json(report_path)
        if (sha256(report_path) != row["final_supervisor_report_sha256"]
                or report.get("numeric_group_exited") is not True
                or report.get("budget_closure_confirmed") is not True
                or report.get("source_identity_unchanged") is not True
                or report.get("final_native_handle_cleanup_confirmed") is not True
                or report.get("final_stage_acceptance", {}).get(stage) != accepted
                or any(row.get(key) != accepted[key] for key in accepted if key != "pass")):
            raise PermissionError("Accepted prefix lacks final numerical exit and settlement binding")
        for name, expected in report["source_identity"].items():
            if sha256(safe_file(REPO / name)) != expected:
                raise PermissionError("Frozen accepted prefix implementation bytes changed")
        prefix_exit_path = safe_file(report_path.parent / "numeric_group_exit_evidence.json")
        prefix_settle_path = safe_file(report_path.parent / "budget_settlement.json")
        for evidence_path in (report_path, prefix_exit_path, prefix_settle_path):
            evidence_row = {"path": evidence_path.relative_to(REPO).as_posix(), "sha256": sha256(evidence_path)}
            pinned(evidence_row)
        prefix_exit = read_json(prefix_exit_path)
        prefix_settlement = read_json(prefix_settle_path)
        prefix_event = prefix_settlement["settlement"]
        if (prefix_exit.get("entire_group_exited") is not True
                or prefix_exit.get("native_query_succeeded") is not True
                or prefix_event not in journal["events"]
                or prefix_event["payload"]["run_id"] not in settled
                or allocations[prefix_event["payload"]["run_id"]]["sha256"] != prefix_event["payload"]["reservation_sha256"]
                or report["budget"]["settlement"] != prefix_event
                or report.get("numeric_exit_evidence_sha256") != sha256(prefix_exit_path)
                or report.get("budget_settlement_file_sha256") != sha256(prefix_settle_path)
                or prefix_settlement["timing"]["exit_proof_sha256"] != digest(prefix_exit)):
            raise PermissionError("Accepted prefix exact exit or original ledger settlement changed")
        raw_result = read_json(output / "stage_result.json")
        artifacts = raw_result.get("artifacts", []) if stage == "gradient" else raw_result["fit_raw_artifacts"]
        for item in artifacts:
            path = safe_file(Path(item["path"]))
            if not path.resolve().is_relative_to(output.resolve()) or path.stat().st_size != item["bytes"] or sha256(path) != item["sha256"]:
                raise PermissionError("Prior accepted raw fitting bytes changed")
    return admission, completed


def admit_counters(recipe, metadata, owner, sources, assert_owner, admission, counter_type, digest):
    root = safe_directory(REPO / recipe["counter_store_root"], must_exist=False)
    origin_path = safe_file(REPO / recipe["counter_origin_binding_path"], must_exist=False)
    zero_row = recipe["counter_initialization_evidence"]
    if admission is None:
        if origin_path.exists() or root.exists():
            raise PermissionError("Existing counter origin cannot be initialized again")
        binding = {"scope": "precip_local_gradient_flexible_v04", "nonce": owner["nonce"],
                   "source_sha256": digest(sources)}
        counters = counter_type(root, binding, assert_owner)
        counters.initialize(read_json(REPO / zero_row["path"])["initial_counts"], zero_row["sha256"])
        write_json(origin_path, {"binding": binding, "store_path": str(root),
                                "initialization_evidence_sha256": zero_row["sha256"],
                                "source_identity": sources, "first_owner": owner})
        return counters
    origin_row, snapshot_row = admission["counter_origin_binding"], admission["counter_snapshot"]
    if origin_row not in admission["pinned_metadata"] or snapshot_row not in admission["pinned_metadata"]:
        raise PermissionError("Counter repair evidence is not pinned by this source admission")
    if (safe_file(REPO / origin_row["path"]) != origin_path
            or sha256(origin_path) != origin_row["sha256"]):
        raise PermissionError("Original counter binding path or bytes changed")
    origin = read_json(origin_path)
    snapshot_path = safe_file(REPO / snapshot_row["path"])
    if (origin["store_path"] != str(root) or origin["initialization_evidence_sha256"] != zero_row["sha256"]
            or sha256(snapshot_path) != snapshot_row["sha256"]):
        raise PermissionError("Retry counter origin/snapshot does not match its explicit admission")
    frozen = read_json(snapshot_path)
    counters = counter_type(root, origin["binding"], assert_owner)
    counters.reopen(digest(frozen), frozen["head_sha256"], frozen["event_count"], zero_row["sha256"])
    return counters


def main():
    sys.dont_write_bytecode = True
    sys.path[:0] = [str(REPO), str(REPO / "src")]
    install_metadata_package_namespace()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=CONFIG)
    parser.add_argument("--approval", type=Path, required=True)
    parser.add_argument("--approval-sha256", required=True)
    parser.add_argument("--execute-reviewed-flexible-plan", action="store_true")
    args = parser.parse_args()
    if not args.execute_reviewed_flexible_plan:
        raise PermissionError("Explicit flexible-plan execution authorization is required")
    if Path(sys.executable).resolve() != Path("C:/Users/yiqun/anaconda3/python.exe").resolve():
        raise PermissionError("Original Python executable required")
    from precip_input_assimilation.scripts import run_precip_local_gradient_small_sample_v03 as prior
    from precip_input_assimilation.small_sample.flexible_budget_v04 import BudgetSession, CounterStore, digest
    from precip_input_assimilation.small_sample.windows_numeric_group_v05 import WindowsNumericGroup
    from precip_input_assimilation.small_sample.flexible_ipc_v04 import native_identity
    config_path = safe_file(args.config)
    recipe = config(config_path)
    audit_binding, original_counter_snapshot = require_preserved_binding(recipe)
    sources = source_identity(recipe, config_path)
    require_approval(args.approval, args.approval_sha256, sources, recipe)
    predecessor = verify_original_predecessor()
    original = prior.original_entry()
    output = original.check_output_path(REPO / recipe["output_root"])
    metadata = safe_directory(REPO / recipe["implementation_metadata_root"])
    transport = read_json(FAMILY / "pilot_20261009_01487000_s1001_s1002_s1003_v02/manifest.json")["original_transport_identity"]
    nonce, attempt_id = uuid.uuid4().hex, recipe["attempt"]["id"]
    owner = {"status": "RUNNING", "pid": os.getpid(),
             "windows_creation_identity": native_identity(os.getpid())["creation_identity"],
             "nonce": nonce, "attempt_id": attempt_id, "output": str(output),
             "source_digest": digest(sources), "started_utc": datetime.now(timezone.utc).isoformat(),
             "plan_sha256": PLAN_SHA}
    child = group = listener = session = counters = server_connection = None
    worker_identity = None
    lock_active = published_owner = stopped = hello_accepted = False
    finished = failure = settlement = None
    failure_records = []
    messages = queue.Queue()
    last_sequence = 0
    counter_attempts, audit_attempts = {}, set()
    metadata_tail_boundary = None
    tail_through_unlock = None
    completed, selected, stages = {}, [], {}
    management_observer = None
    final_report_path = final_report_value = None

    def record_failure(label, error):
        nonlocal failure
        value = {"error_type": type(error).__name__, "error": str(error),
                 "traceback": traceback.format_exc(), "utc": datetime.now(timezone.utc).isoformat()}
        for name in ("native_query_evidence", "native_transition_observations",
                     "native_transition_evidence_overflow"):
            if hasattr(error, name):
                value[name] = getattr(error, name)
        if failure is None:
            failure = value
        path = (output if output.exists() else metadata) / (
            "failure_" + nonce + "_" + str(len(failure_records)).zfill(3) + "_" + label + ".json")
        failure_records.append(str(path))
        try:
            write_json(path, value)
        except BaseException as save_error:
            print("Failure evidence write error: " + repr(save_error), file=sys.stderr, flush=True)

    def assert_owner():
        require_standard_library_supervisor()
        actual = native_identity(owner["pid"])
        if (not lock_active or actual["status"] != "RUNNING"
                or actual.get("creation_identity") != owner["windows_creation_identity"]
                or not published_owner or read_json(OWNER) != owner):
            raise PermissionError("Exact supervisor ownership changed")
        actual_lock_held()

    def before_request():
        assert_owner()
        paths = [FAMILY / "STOP", output / "STOP"]
        paths += [output / item["output"] / "STOP" for item in recipe["stages"].values()]
        paths += [Path(audit_binding["evidence_root"]) / "STOP", Path(audit_binding["proof_root"]) / "STOP"]
        if any(path.exists() for path in paths):
            raise InterruptedError("Manual or technical stop remains in force")
        if source_identity(recipe, config_path) != sources:
            raise PermissionError("Current reviewed source identity changed during computation")
        original.verify_original_guard()
        prior.verify_failure_binding(read_json(REPO / recipe["old_v03_config"]["path"]))
        if any(sha256(path) != expected for path, expected in transport.items()):
            raise PermissionError("Original completed transport changed")

    def startup_group_exited():
        if hello_accepted:
            return False
        if group is not None and group.pids():
            return False
        if child is None:
            return True
        if child.poll() is None or worker_identity is None:
            return False
        if group is None:
            raise PermissionError("Startup child has no native query facility for its exact Popen handle")
        current = group._handle_state(int(child._handle))
        return (current["status"] == "EXITED" and current["pid"] == child.pid
                and current["windows_creation_identity"] == worker_identity["creation_identity"])

    def stop_and_wait_owned_group(reason):
        """Retain the actual family lock until the private job is empty."""
        nonlocal worker_identity
        if child is not None and worker_identity is None and group is not None:
            exact_startup = group._handle_state(int(child._handle))
            if exact_startup["pid"] != child.pid:
                raise PermissionError("Supervisor-created startup handle identity changed")
            worker_identity = {"status": exact_startup["status"], "pid": child.pid,
                               "creation_identity": exact_startup["windows_creation_identity"],
                               "identity_source": "retained_supervisor_created_Popen_native_handle"}
        if child is not None and group is not None and group.bound_worker is not None:
            if child.poll() is None or group.pids():
                target = group.terminate_owned(assert_owner, reason)
                write_json(metadata / ("owned_numeric_stop_" + nonce + "_" + uuid.uuid4().hex + ".json"), target)
            while child.poll() is None or group.pids():
                assert_owner()
                group.snapshot()  # Query errors never become an exit proof.
                time.sleep(.1)
            child.wait()
            if not group.verify_exited(child):
                raise PermissionError("Owned numerical group exit is unconfirmed")
        elif child is not None and child.poll() is None:
            # No accepted hello means no scientific import or child launch was
            # authorized. Popen's exact native handle is used, never a PID kill.
            assert_owner()
            actual = group._handle_state(int(child._handle)) if group is not None else None
            if actual is None or actual["pid"] != child.pid:
                raise PermissionError("Unbound startup child creation identity is unconfirmed")
            if worker_identity is None:
                # This exact Popen handle was created by this supervisor. A
                # failed PID query never authorizes a PID-based replacement.
                worker_identity = {"status": actual["status"], "pid": child.pid,
                                   "creation_identity": actual["windows_creation_identity"],
                                   "identity_source": "retained_supervisor_created_Popen_native_handle"}
            if actual["windows_creation_identity"] != worker_identity["creation_identity"]:
                raise PermissionError("Unbound startup child native object identity changed")
            write_json(metadata / ("startup_child_stop_" + nonce + ".json"),
                       {"identity": worker_identity, "reason": reason, "hello_accepted": False,
                        "exact_native_popen_handle": True})
            child.terminate()
            child.wait()
            if not startup_group_exited():
                raise PermissionError("Pure startup child exit remains unconfirmed")

    with original.exclusive_trial_lock():
        lock_active = True
        try:
            actual_lock_held()
            if OWNER.exists():
                previous_owner = read_json(OWNER)
                actual = native_identity(previous_owner["pid"])
                if actual["status"] == "RUNNING" and actual.get("creation_identity") == previous_owner["windows_creation_identity"]:
                    raise PermissionError("Exact prior flexible owner is still active")
            if (FAMILY / "STOP").exists():
                raise InterruptedError("Manual family stop preserved")
            repair_context, protection = verify_preservation(recipe, sources, transport, query_old=True,
                                                              config_path=config_path)
            _, _, allocations, settled = original.load_budget(FAMILY / "cumulative_budget_v01.json")
            if set(allocations) != set(settled):
                raise PermissionError("Any open reservation blocks execution")
            setup_debit = require_setup_debit(recipe, original)
            admission, completed = repair_admission(recipe, original)
            stage_names = ["gradient"]
            selected = stage_names[stage_names.index(recipe["attempt"]["start_stage"]):]
            stages = {name: completed[name]["output"] if name in completed else str(output / item["output"])
                      for name, item in recipe["stages"].items()}
            write_json(OWNER, owner)
            published_owner = True
            counters = admit_counters(recipe, metadata, owner, sources, assert_owner, admission, CounterStore, digest)
            require_preserved_counter_state(counters.snapshot(), audit_binding, original_counter_snapshot,
                                            digest(sources), for_admission=True)
            session = BudgetSession(FAMILY / "cumulative_budget_v01.json",
                                    metadata / "budget_tx_v04" / str(recipe["attempt"]["ordinal"]).zfill(3),
                                    (REPO / recipe["budget_baseline"]["path"]).read_bytes(), attempt_id, nonce,
                                    digest(sources), sha256(config_path), sha256(__file__), owner, assert_owner)
            first = session.start(output)
            output.mkdir(parents=True, exist_ok=False)
            for name in selected:
                Path(stages[name]).mkdir(parents=True, exist_ok=False)
            observer_script = REPO / "src/precip_input_assimilation/scripts/observe_precip_flexible_management_tail_v04.py"
            observer_command = [sys.executable, "-B", "-X", "utf8", str(observer_script),
                                "--supervisor-pid", str(owner["pid"]),
                                "--supervisor-creation", owner["windows_creation_identity"],
                                "--nonce", nonce, "--metadata-root", str(metadata)]
            with (metadata / ("management_observer_stdout_" + nonce + ".log")).open("xb") as observer_stdout, \
                    (metadata / ("management_observer_stderr_" + nonce + ".log")).open("xb") as observer_stderr:
                management_observer = subprocess.Popen(observer_command, cwd=REPO,
                    stdout=observer_stdout, stderr=observer_stderr, creationflags=subprocess.CREATE_NO_WINDOW)
            ready_path = metadata / ("management_tail_observer_ready_" + nonce + ".json")
            observer_deadline = min(time.monotonic() + 60., session.slice_deadline - 300.)
            while not ready_path.exists():
                assert_owner()
                if management_observer.poll() is not None or time.monotonic() >= observer_deadline:
                    raise TimeoutError("Pure metadata exact-exit observer did not establish its native handle")
                time.sleep(.1)
            ready = read_json(ready_path)
            observer_identity = native_identity(management_observer.pid)
            if (ready.get("nonce") != nonce or ready.get("observer_source_sha256") != sha256(observer_script)
                    or ready.get("status") != "READY_EXACT_NATIVE_SUPERVISOR_HANDLE_RETAINED"
                    or management_observer.poll() is not None or observer_identity["status"] != "RUNNING"
                    or ready.get("python_version") != list(sys.version_info[:3])
                    or ready.get("python_executable") != str(Path(sys.executable).resolve())
                    or ready.get("clock", {}).get("monotonic") is not True
                    or ready.get("clock", {}).get("adjustable") is not False
                    or ready.get("clock", {}).get("implementation") != time.get_clock_info("monotonic").implementation
                    or ready.get("observer", {}).get("pid") != management_observer.pid
                    or ready.get("observer", {}).get("windows_creation_identity") != observer_identity["creation_identity"]
                    or ready.get("supervisor", {}).get("pid") != owner["pid"]
                    or ready.get("supervisor", {}).get("windows_creation_identity") != owner["windows_creation_identity"]):
                raise PermissionError("Exact-supervisor metadata observer admission changed")
            write_json(output / "budget_reservation.json", first["reservation"])
            write_json(output / "config_snapshot.json", recipe)
            write_json(output / "manifest.json", {"schema": "precip_local_gradient_flexible_actual_v04",
                       "owner": owner, "source_identity": sources, "predecessor": predecessor,
                       "repair_context": repair_context, "protected_identity": protection,
                       "original_transport_identity": transport, "config_sha256": sha256(config_path),
                       "approval_path": str(args.approval), "approval_sha256": args.approval_sha256,
                       "completed_predecessors": completed, "start_stage": recipe["attempt"]["start_stage"],
                       "budget_reservation_sha256": first["reservation"]["sha256"],
                       "score_numeric_reads_allowed": False, "new_remote_jobs": 0})
            endpoint = r"\\.\pipe\precip_flexible_v04_" + nonce
            auth = os.urandom(32)
            listener = Listener(endpoint, family="AF_PIPE", authkey=auth)
            session_path = output / "worker_session.json"
            write_json(session_path, {"endpoint": endpoint, "auth_hex": auth.hex(), "nonce": nonce,
                        "attempt_id": attempt_id, "owner": owner, "owner_path": str(OWNER),
                        "global_deadline": session.global_deadline, "source_identity": sources,
                        "source_digest": digest(sources), "config_sha256": sha256(config_path),
                        "approval_path": str(args.approval), "approval_sha256": args.approval_sha256,
                        "run_root": str(output), "stage_outputs": stages, "completed_predecessors": completed,
                        "protection": protection, "transport": transport, "oldfailure": repair_context,
                        "predecessor": predecessor, "budget_reservation": first["reservation"],
                        "old_v03_config": recipe["old_v03_config"],
                        "slice_deadline": session.slice_deadline,
                        "preserved_gradient_audit_binding": recipe["preserved_gradient_audit_binding"]})
            group = WindowsNumericGroup()
            command = [sys.executable, "-B", "-X", "utf8",
                       str(REPO / "src/precip_input_assimilation/scripts/run_precip_local_gradient_preserved_audit_worker_v05.py"),
                       "--config", str(config_path), "--session", str(session_path),
                       "--stage", recipe["attempt"]["start_stage"]]
            with (output / "numeric_stdout.log").open("xb") as stdout, (output / "numeric_stderr.log").open("xb") as stderr:
                child = subprocess.Popen(command, cwd=REPO, stdout=stdout, stderr=stderr,
                                         creationflags=subprocess.CREATE_NO_WINDOW)
            worker_identity = native_identity(child.pid)
            if worker_identity["status"] != "RUNNING":
                raise PermissionError("New numeric worker did not establish its creation identity")
            group.assign(child, worker_identity["creation_identity"])
            group_binding = {"supervisor": owner, "worker": group.bound_worker,
                             "windows_job_group": True, "command_sha256": digest(command)}
            session.bind_worker_group(group_binding)
            write_json(output / "numeric_group_binding.json",
                       {"binding": group_binding, "worker_group_sha256": session.worker_group_sha256})

            def receive():
                nonlocal server_connection
                try:
                    server_connection = listener.accept()
                    while True:
                        messages.put(("request", server_connection.recv()))
                except (EOFError, OSError) as error:
                    messages.put(("eof", repr(error)))
                except BaseException as error:
                    messages.put(("ipc_error", repr(error)))
            threading.Thread(target=receive, daemon=True).start()
            first_hello_deadline = min(time.monotonic() + 60., session.slice_deadline - 300.)
            stop_requested = False
            while child.poll() is None or group.pids():
                group.snapshot()
                now = time.monotonic()
                cutoff = min(session.global_deadline, session.slice_deadline)
                if not hello_accepted and now >= first_hello_deadline:
                    raise TimeoutError("Bound worker did not establish the admission handshake")
                if now >= session.global_deadline - 300 and not stop_requested:
                    write_json(output / "STOP", {"reason": "Total budget exit margin", "owner": owner})
                    stop_requested = True
                if now >= cutoff - 30:
                    raise TimeoutError("No synchronized budget continuation before reserved exit margin")
                try:
                    typ, message = messages.get(timeout=.25)
                except queue.Empty:
                    continue
                if typ != "request":
                    if finished is None:
                        raise ConnectionError("Owned numerical communication ended before the exit record: " + message)
                    continue
                response = {"sequence": message.get("sequence"), "nonce": nonce,
                            "source_digest": digest(sources), "global_deadline": session.global_deadline,
                            "slice_deadline": session.slice_deadline}
                try:
                    if (message.get("nonce") != nonce or message.get("sequence") != last_sequence + 1
                            or message.get("pid") != child.pid
                            or message.get("windows_creation_identity") != group.bound_worker["windows_creation_identity"]):
                        raise PermissionError("Unbound or out-of-order numeric IPC request")
                    last_sequence = message["sequence"]
                    actual = native_identity(child.pid)
                    if actual["status"] != "RUNNING" or actual.get("creation_identity") != group.bound_worker["windows_creation_identity"]:
                        raise PermissionError("Numeric request creation identity changed")
                    before_request()
                    operation, body = message["op"], message["body"]
                    result = {}
                    if operation == "checkpoint":
                        if body.get("device_synchronized") is not True or body.get("new_operations_paused") is not True:
                            raise PermissionError("Continuation requires paused, synchronized numerical state")
                        if session.needs_rotation:
                            session.rotate({"device_synchronized": True, "new_operations_paused": True,
                                            "worker_group_sha256": session.worker_group_sha256,
                                            "owner_sha256": session.owner_sha256, "attempt_nonce": nonce})
                        result = session.check_operation(body.get("begin_operation", True))
                        result["reservation"] = session.reservation
                    elif operation == "admit_preserved_audit":
                        session.check_operation()
                        counter_id = attempt_id + "_gradient_full_forward"
                        if (body != {"binding_sha256": recipe["preserved_gradient_audit_binding"]["sha256"]}
                                or counter_attempts or audit_attempts):
                            raise PermissionError("Repeated or unbound preserved audit admission")
                        tests_proof = load_registered_test_admission(output, recipe, group)
                        require_preserved_counter_state(counters.snapshot(), audit_binding, original_counter_snapshot,
                                                        digest(sources), for_admission=True)
                        registration = counters.admit_attempt(counter_id, uuid.uuid4().hex, digest(sources),
                                                              "gradient_full_forward")
                        counter_attempts[counter_id] = True
                        admitted_snapshot = counters.snapshot()
                        state = require_preserved_counter_state(admitted_snapshot, audit_binding,
                                                                original_counter_snapshot, digest(sources))
                        if state["new_started"] != 0:
                            raise PermissionError("Fresh audit registration cannot seed historical forwards")
                        result = {"registration": registration, "counter_snapshot": admitted_snapshot,
                                  "new_started": 0, "registered_tests": tests_proof}
                        write_json(output / "preserved_audit_admission.json", result)
                    elif operation == "consume":
                        session.check_operation()
                        state = require_preserved_counter_state(counters.snapshot(), audit_binding,
                                                                original_counter_snapshot, digest(sources))
                        counter_id = require_preserved_consume(body, state, attempt_id)
                        if counter_id not in counter_attempts:
                            raise PermissionError("Paid test admission must precede every independent forward")
                        record = counters.consume(body["kind"], body["key"], body.get("label", ""), body["bindings"],
                                                  attempt_id=counter_id, operation_nonce=uuid.uuid4().hex)
                        require_preserved_counter_state(counters.snapshot(), audit_binding,
                                                        original_counter_snapshot, digest(sources))
                        result = {"record": record, "cumulative_count": record["payload"]["event"]["cumulative_count"]}
                    elif operation == "bind_audit":
                        raise PermissionError("Fitting and training reconstruction are prohibited in this audit-only attempt")
                    elif operation == "counter_snapshot":
                        session.check_operation(begin_operation=False)
                        result = counters.snapshot()
                    elif operation == "register_child":
                        result = {"identity": group.register(body["pid"]), "group": group.snapshot()}
                    elif operation == "hello":
                        if hello_accepted:
                            raise PermissionError("Repeated startup admission forbidden")
                        result = session.check_operation()
                        result.update({"reservation": session.reservation, "numeric_group": group_binding})
                        hello_accepted = True
                    elif operation == "finished":
                        session.check_operation(begin_operation=False)
                        if finished is not None:
                            raise PermissionError("Repeated numerical exit evidence")
                        if body.get("result", {}).get("status") == "SCIENTIFIC_BLOCKED_OR_UNCONFIRMED":
                            require_finished_preserved_audit(body, output, audit_binding, original_counter_snapshot,
                                                            counters.snapshot(), digest(sources))
                        finished = body
                        result = {"numeric_exit_still_required": True}
                    else:
                        raise PermissionError("Unknown numeric IPC operation")
                    response.update({"ok": True, "result": result, "global_deadline": session.global_deadline,
                                     "slice_deadline": session.slice_deadline})
                    write_json(output / "supervisor_progress.json", {"utc": datetime.now(timezone.utc).isoformat(),
                               "sequence": last_sequence, "operation": operation, "label": body.get("label"),
                               "budget": session.check_operation(begin_operation=False), "numeric_pid": child.pid})
                except BaseException as error:
                    record_failure("request", error)
                    response.update({"ok": False, "error": type(error).__name__ + ": " + str(error)})
                server_connection.send(response)
                if not response["ok"]:
                    raise RuntimeError("Numeric admission failed; preserve and stop the owned group")
            child.wait()
        except BaseException as error:
            record_failure("supervision", error)
        finally:
            if published_owner:
                try:
                    stop_and_wait_owned_group("Technical failure or completion cleanup")
                except BaseException as error:
                    record_failure("owned_exit", error)
                    # Never release the lock with still-live owned numerical
                    # descendants. Query failures stay unconfirmed, not absent.
                    while True:
                        try:
                            stop_and_wait_owned_group("Repeated exact-owner exit verification")
                            if group is not None:
                                confirmed = (group.verify_exited(child) if group.bound_worker is not None
                                             else group.verify_exited(None) and startup_group_exited())
                            else:
                                confirmed = startup_group_exited()
                            if confirmed:
                                break
                            raise PermissionError("Exact owned numerical exit is still unconfirmed")
                        except BaseException as repeated:
                            print("Unconfirmed owned numerical exit: " + repr(repeated), file=sys.stderr, flush=True)
                            time.sleep(1.)
                try:
                    regular_exit = child is not None and group is not None and group.bound_worker is not None and group.verify_exited(child)
                    startup_exit = not hello_accepted and startup_group_exited()
                    if not regular_exit and not startup_exit:
                        raise PermissionError("Whole numerical group remains unconfirmed")
                    if session is not None and session.reservation is not None:
                        if session.worker_group_sha256 is None:
                            if not startup_exit:
                                raise PermissionError("Missing admitted group cannot be replaced by an empty proof")
                            session.bind_worker_group({"startup_failure_no_numeric_admission": True,
                                                       "supervisor": owner, "child_identity": worker_identity,
                                                       "exact_startup_child_exited": child is None or child.poll() is not None})
                        verify_preservation(recipe, sources, transport, config_path=config_path)
                        actual_exit = group.snapshot() if group is not None else {
                            "native_query_succeeded": True, "entire_group_exited": startup_exit,
                            "no_child_launched": child is None, "numeric_hello_never_accepted": True}
                        proof = {**actual_exit, "entire_group_exited": True,
                                 "worker_group_sha256": session.worker_group_sha256,
                                 "owner_sha256": session.owner_sha256, "attempt_nonce": nonce,
                                 "numeric_hello_accepted": hello_accepted}
                        exit_evidence_path = (output / "numeric_group_exit_evidence.json" if output.exists()
                                   else metadata / ("startup_group_exit_" + nonce + ".json"))
                        write_json(exit_evidence_path, proof)
                        snapshot = counters.snapshot()
                        settlement = session.final_settle(proof, lambda value: group.verify_exited(child) if regular_exit else startup_group_exited())
                        metadata_tail_boundary = settlement["timing"]["boundary_monotonic"]
                        settlement_evidence_path = (output / "budget_settlement.json" if output.exists()
                                   else metadata / ("startup_budget_settlement_" + nonce + ".json"))
                        write_json(settlement_evidence_path, settlement)
                        final_status = None if finished is None else finished.get("result", {}).get("status")
                        valid_statuses = {"SCIENTIFIC_BLOCKED_OR_UNCONFIRMED"}
                        technical = (failure is not None or child is None or child.returncode != 0
                                     or finished is None or finished.get("exit_guard_error") is not None
                                     or final_status not in valid_statuses
                                     or settlement["timing"]["allocation_overrun"]
                                     or settlement["timing"]["global_deadline_exceeded"])
                        acceptance = dict((stage, {key: row[key] for key in
                                    ("complete_path", "sha256", "stage_result_sha256", "audit_sha256", "actual_audit_sha256")}
                                    | {"pass": True}) for stage, row in completed.items())
                        for stage in selected:
                            folder = Path(stages[stage])
                            if (folder / "stage_complete.json").exists():
                                raise PermissionError("Preserved audit cannot authorize fitting or scientific stage acceptance")
                        write_json(output / "final_counter_snapshot.json" if output.exists()
                                   else metadata / ("startup_counter_snapshot_" + nonce + ".json"), snapshot)
                        final_report_path = (output / "final_supervisor_report.json" if output.exists()
                                   else metadata / ("startup_final_supervisor_report_" + nonce + ".json"))
                        final_report_value = {"attempt_id": attempt_id, "child_returncode": None if child is None else child.returncode,
                                    "numeric_group_exited": True, "budget_closure_confirmed": True,
                                    "technical_failure": technical, "execution_status": final_status,
                                    "failure": failure, "failure_records": failure_records, "worker_report": finished,
                                    "source_identity": sources, "source_identity_unchanged": True,
                                    "protected_identity_verified": True, "transport_unchanged": True,
                                    "budget": settlement, "counter_snapshot_sha256": digest(snapshot),
                                    "unexpected_setup_debit": setup_debit,
                                    "numeric_exit_evidence_sha256": sha256(exit_evidence_path),
                                    "budget_settlement_file_sha256": sha256(settlement_evidence_path),
                                    "final_stage_acceptance": acceptance, "forecast_improvement_established": False,
                                    "full_management_tail_pending_exact_supervisor_exit": True}
                        stopped = True
                        if technical and failure is None:
                            failure = {"error_type": "TechnicalIncomplete",
                                       "error": "Numeric return status or exit record is incomplete"}
                    else:
                        # There was no reserved or admitted numerical operation.
                        stopped = child is None and session is None or startup_exit
                except BaseException as error:
                    record_failure("finalization", error)
                try:
                    if server_connection is not None:
                        server_connection.close()
                    if listener is not None:
                        listener.close()
                    if group is not None:
                        group.close()
                except BaseException as error:
                    record_failure("native_handle_cleanup", error)
                    stopped = False
                write_json(OWNER, {**owner, "status": "STOPPED" if stopped else "EXIT_UNCONFIRMED",
                           "numeric_group_exit_and_settlement_confirmed": stopped,
                           "finished_utc": datetime.now(timezone.utc).isoformat()})
                if final_report_value is not None:
                    final_report_value.update({"failure": failure, "failure_records": failure_records,
                        "technical_failure": final_report_value["technical_failure"] or failure is not None,
                        "final_native_handle_cleanup_confirmed": stopped,
                        "final_owner_sha256": sha256(OWNER)})
                    write_json(final_report_path, final_report_value)
        lock_active = False
    if metadata_tail_boundary is not None:
        tail_through_unlock = time.monotonic()
        write_json(metadata / ("management_tail_through_unlock_" + nonce + ".json"),
                   {"boundary_monotonic": metadata_tail_boundary, "through_unlock_monotonic": tail_through_unlock,
                    "seconds_through_completed_reports_handles_and_os_unlock": tail_through_unlock - metadata_tail_boundary,
                    "scope": "pure_metadata_only_after_whole_numeric_exit_and_final_scientific_timing",
                    "exact_supervisor_exit_pending": True, "owner": owner,
                    "metadata_evidence_sha256": {"final_owner": sha256(OWNER),
                        "budget_settlement": digest(settlement),
                        **({"final_supervisor_report": sha256(output / "final_supervisor_report.json")}
                           if (output / "final_supervisor_report.json").exists() else {})} })
    if failure is not None or not stopped:
        raise RuntimeError("Diagnostic stopped with preserved technical failure evidence")


if __name__ == "__main__":
    main()
