"""Independent raw-proof audits with persistent, separate reconstruction receipts.

No work runs on import.  The caller supplies the existing exclusive ownership,
source/date gates, reservation, deadline, and shared full-forward counter.
This module does not import the primary derivative or fitting implementation.
"""

from __future__ import annotations

from datetime import date, timedelta
import copy
import hashlib
import io
import json
import math
from pathlib import Path
import random
import time

import numpy as np
import torch
from torch import nn

from .saved_context_v04 import require_full_preservation


CAP = 32.21650314331055
SCALES = (.0001, .0003, .001, .003, .01)
OBJECTIVES = ("terminal_output", "pure_flow_mse")
DAYS = tuple(date(1980, 10, 1) + timedelta(days=i) for i in range(33))
WARMUP = tuple(date(1980, 1, 1) + timedelta(days=i) for i in range(274))
GROUP_SIZES = {"decoder.2.": 33, "encoder.": 4320, "decoder.0.": 1280}


class IndependentAuditFailure(RuntimeError):
    """A raw-proof or independent-recomputation gate failed closed."""


def _require(condition, message):
    if not condition:
        raise IndependentAuditFailure(message)


def _persistent_receipts(ctx, receipts, counter):
    """Reconcile actual evidence with the supervisor's validated durable chain."""
    snapshot = ctx.operation_runtime.counter_snapshot()
    records = snapshot.get("receipts")
    _require(isinstance(records, list) and records, "Missing authoritative durable operation receipts")
    authority = {record["sha256"]: record for record in records}
    for receipt in receipts:
        record = receipt.get("record")
        _require(isinstance(record, dict) and authority.get(record.get("sha256")) == record,
                 "Evidence operation receipt is absent from the authoritative persisted chain")
        event = record["payload"]["event"]
        _require(event.get("kind") == "operation" and event.get("counter") == counter
                 and event.get("cumulative_count") == receipt.get("cumulative_count"),
                 "Evidence receipt counter or cumulative count differs from authority")
    return snapshot


def _tick(ctx, *, new_forward=False, require_checkpoint=True):
    if require_checkpoint:
        ctx.require_unchanged()
    deadline = getattr(ctx, "deadline", None)
    _require(isinstance(deadline, (int, float)) and math.isfinite(deadline), "Missing inherited deadline")
    limit = deadline - 300 if new_forward else deadline
    if time.monotonic() >= limit:
        raise TimeoutError("Independent audit reached the cumulative total deadline")
    if (Path(ctx.output) / "STOP").exists():
        raise InterruptedError("Independent audit preserved the manual stop marker")


def _sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _safe(path, root):
    """Validate lexical and resolved location and every link before file reads."""
    path, root = Path(path), Path(root)
    _require(path.is_absolute() and root.is_absolute() and ".." not in path.parts,
             "Proof path is relative or contains parent traversal")
    lexical_root = root.absolute()
    _require(path.absolute().is_relative_to(lexical_root), "Proof lexical path escapes its permitted root")
    for current in (path, *path.parents):
        _require(not current.is_symlink(), "Proof path traverses a symbolic link")
        if current.exists():
            # Windows junctions/reparse points also need rejection.
            attributes = getattr(current.lstat(), "st_file_attributes", 0)
            _require(not attributes & 0x400, "Proof path traverses a reparse point")
    _require(path.resolve(strict=True).is_relative_to(root.resolve(strict=True)),
             "Resolved proof path escapes its permitted root")
    _require(path.is_file(), "Proof is not a regular file")
    return path


def _decode(value):
    if isinstance(value, dict) and set(value) == {"numpy_dtype", "shape", "bytes_hex"}:
        dtype = np.dtype(value["numpy_dtype"])
        shape = value["shape"]
        _require(dtype.kind in "fiub" and not dtype.hasobject and isinstance(shape, list)
                 and all(type(n) is int and n >= 0 for n in shape), "Invalid serialized NumPy type or shape")
        raw = bytes.fromhex(value["bytes_hex"])
        _require(len(raw) == math.prod(shape) * dtype.itemsize, "Serialized NumPy byte count differs")
        return np.frombuffer(raw, dtype=dtype).copy().reshape(shape)
    if isinstance(value, dict):
        return {name: _decode(item) for name, item in value.items()}
    if isinstance(value, (list, tuple)):
        return type(value)(_decode(item) for item in value)
    return value


def _finite(value, label):
    if isinstance(value, torch.Tensor):
        _require(bool(torch.isfinite(value).all()), "Nonfinite tensor: " + label)
    elif isinstance(value, np.ndarray):
        _require(value.dtype.kind in "fiub" and bool(np.isfinite(value).all()), "Invalid array: " + label)
    elif isinstance(value, dict):
        for name, item in value.items():
            _finite(item, label + "/" + str(name))
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _finite(item, label + "/" + str(index))
    elif isinstance(value, float):
        _require(math.isfinite(value), "Nonfinite scalar: " + label)


def _equal(left, right, label):
    if isinstance(left, torch.Tensor) or isinstance(right, torch.Tensor):
        _require(isinstance(left, torch.Tensor) and isinstance(right, torch.Tensor)
                 and left.dtype == right.dtype and left.shape == right.shape
                 and left.detach().cpu().contiguous().numpy().tobytes()
                 == right.detach().cpu().contiguous().numpy().tobytes(), "Tensor bytes differ: " + label)
    elif isinstance(left, np.ndarray) or isinstance(right, np.ndarray):
        _require(isinstance(left, np.ndarray) and isinstance(right, np.ndarray)
                 and left.dtype == right.dtype and left.shape == right.shape
                 and left.tobytes() == right.tobytes(), "Array bytes differ: " + label)
    elif isinstance(left, dict) or isinstance(right, dict):
        _require(isinstance(left, dict) and isinstance(right, dict) and set(left) == set(right),
                 "Dictionary fields differ: " + label)
        for key in left:
            _equal(left[key], right[key], label + "/" + str(key))
    elif isinstance(left, (list, tuple)) or isinstance(right, (list, tuple)):
        _require(type(left) is type(right) and len(left) == len(right), "Sequence differs: " + label)
        for index, (a, b) in enumerate(zip(left, right, strict=True)):
            _equal(a, b, label + "/" + str(index))
    else:
        _require(type(left) is type(right) and left == right, "Scalar differs: " + label)


def _algebra_equal(left, right, label):
    # Signed zero is the same real derivative/value. Stored-state identity
    # comparisons still use _equal's byte check; this gate has no tolerance.
    _require(left.dtype == right.dtype and left.shape == right.shape and torch.equal(left,right),
             "Exact algebra differs: " + label)


class _Reader:
    def __init__(self, ctx, artifacts):
        self.ctx, self.root = ctx, Path(ctx.output)
        self.items, self.used = {}, set()
        _require(isinstance(artifacts, list) and artifacts, "Missing complete raw-artifact manifest")
        for item in artifacts:
            _require(set(item) >= {"path", "sha256", "bytes"}, "Incomplete artifact identity")
            path = _safe(item["path"], self.root)
            key = str(path)
            _require(key not in self.items and len(item["sha256"]) == 64,
                     "Duplicate or invalid raw-artifact identity")
            _tick(ctx)
            _require(path.stat().st_size == item["bytes"] and _sha(path) == item["sha256"],
                     "Artifact bytes changed before numeric loading")
            self.items[key] = item

    def read(self, value):
        _tick(self.ctx)
        path = _safe(value["path"] if isinstance(value, dict) else value, self.root)
        item = self.items.get(str(path))
        _require(item is not None, "Numeric read is not bound to the stage artifact manifest")
        if isinstance(value, dict):
            _equal(value, item, "artifact reference")
        raw = path.read_bytes()
        _require(len(raw) == item["bytes"] and hashlib.sha256(raw).hexdigest() == item["sha256"],
                 "Artifact changed between admission and load")
        if path.suffix in (".pt", ".npy", ".npz"):
            require_full_preservation(self.ctx.require_unchanged)
        if path.suffix == ".pt":
            result = _decode(torch.load(io.BytesIO(raw), map_location="cpu", weights_only=True))
        elif path.suffix == ".json":
            result = json.loads(raw.decode("utf-8"))
        elif path.suffix == ".npy":
            result = np.load(io.BytesIO(raw), allow_pickle=False)
        elif path.suffix == ".npz":
            with np.load(io.BytesIO(raw), allow_pickle=False) as data:
                result = {name: data[name].copy() for name in data.files}
        else:
            raise IndependentAuditFailure("Unsupported proof file type")
        self.used.add(str(path))
        _finite(result, str(path))
        _tick(self.ctx)
        return result


def _rng():
    return {"python": copy.deepcopy(random.getstate()), "numpy": copy.deepcopy(np.random.get_state()),
            "torch_cpu": torch.get_rng_state().clone(),
            "torch_cuda": [x.clone() for x in torch.cuda.get_rng_state_all()] if torch.cuda.is_available() else []}


def _restore_rng(value):
    value = _decode(value)
    random.setstate(value["python"])
    np.random.set_state(value["numpy"])
    torch.set_rng_state(value["torch_cpu"])
    _require(len(value["torch_cuda"]) == (torch.cuda.device_count() if torch.cuda.is_available() else 0),
             "Random-state device inventory differs")
    if value["torch_cuda"]:
        torch.cuda.set_rng_state_all(value["torch_cuda"])


def _restore_model(model, value, optimizer=None):
    model.load_state_dict(value["state_dict"], strict=True)
    modules = dict(model.named_modules())
    _require(set(value["modes"]) == set(modules), "Restoration module inventory differs")
    for name, mode in value["modes"].items():
        _require(type(mode) is bool, "Restoration mode is not boolean")
        modules[name].training = mode
    parameters = dict(model.named_parameters())
    if "requires_grad" in value:
        _require(set(value["requires_grad"]) == set(parameters), "Restoration trainability inventory differs")
        for name, parameter in parameters.items():
            parameter.requires_grad_(value["requires_grad"][name])
    for name, parameter in parameters.items():
        saved = value.get("gradients", {}).get(name)
        parameter.grad = None if saved is None else saved.detach().to(parameter.device).clone()
    if optimizer is not None:
        optimizer.load_state_dict(value["optimizer"])
    _restore_rng(value["rng"])


def _frozen(ctx):
    model = ctx.hydro.frozen.model
    result = {"state_dict": {n: t.detach().cpu().clone() for n, t in model.state_dict().items()},
              "modes": {n: m.training for n, m in model.named_modules()},
              "requires_grad": {n: p.requires_grad for n, p in model.named_parameters()},
              "gradients": {n: None if p.grad is None else p.grad.detach().cpu().clone()
                            for n, p in model.named_parameters()}}
    _finite(result, "frozen model")
    _require(result["modes"] == ctx.mode_reference and not result["modes"].get("")
             and result["modes"].get("lstm") and not result["modes"].get("dropout")
             and not any(result["requires_grad"].values())
             and all(g is None for g in result["gradients"].values()), "Frozen model modes or gradients changed")
    return result


def _inputs(ctx, bound, warmup=None):
    _require(tuple(bound["dates"]) == tuple(str(d) for d in DAYS), "Saved input dates differ")
    weather, observations = bound["weather"], bound["observations"]
    _require(isinstance(weather, np.ndarray) and weather.shape == (33, 5)
             and isinstance(observations, np.ndarray) and observations.shape == (33,), "Saved input shapes differ")
    _equal(weather, ctx.small_weather, "admitted saved weather")
    _equal(observations, ctx.small_values, "admitted saved observations")
    _equal(bound["scaling"], ctx.scaling.as_dict(), "saved scaling identity")
    _require(bound["scaling"]["cap"] == CAP and bound["scaling"]["flow_std"] > 0,
             "Saved physical cap or flow standard deviation differs")
    warmup = bound if warmup is None else warmup
    _require(tuple(warmup["warmup_dates"]) == tuple(str(d) for d in WARMUP), "Incomplete 274-day warmup")
    warm_weather = warmup["warmup_weather"]
    if isinstance(warm_weather, np.ndarray):
        warm_weather = torch.as_tensor(warm_weather, dtype=torch.float32)
    _require(warm_weather.shape == (274, 5) and warm_weather.dtype == torch.float32,
             "Saved warmup shape or precision differs")
    _equal(warm_weather, torch.as_tensor(ctx.inputs.weather[:274], dtype=torch.float32), "saved full warmup")
    _equal(warmup["warmup_applied"], torch.zeros(274, dtype=torch.float32), "initial zero rain ledger")
    _require(tuple(ctx.inputs.dates[:274]) == WARMUP and (warm_weather[:, 0] >= 0).all(),
             "Saved weather calendar or precipitation differs")
    _finite((weather, observations, warm_weather), "admitted inputs")
    return {"weather": torch.as_tensor(weather, dtype=torch.float32), "observations": observations,
            "warmup_weather": warm_weather, "flow_mean": float(ctx.scaling.flow_mean),
            "flow_std": float(ctx.scaling.flow_std)}


def branch_codes(proof):
    """Classify all 3,200 original points; boundary equality remains explicit."""
    codes = []
    _require(len(proof["updates"]) == 33, "Missing original update rows")
    for update in proof["updates"][:32]:
        raw, proposal = update["raw"], update["proposal"]
        lower = -torch.minimum(raw, raw.new_tensor(CAP))
        code = torch.full_like(proposal, 2, dtype=torch.int8)
        code[proposal < lower], code[proposal == lower] = 0, 1
        code[proposal == CAP], code[proposal > CAP] = 3, 4
        codes.append(code)
    return torch.stack(codes)


def _trajectory(ctx, proof, inputs, fixed=None, terminal=None):
    """Rebuild every calendar row, pre-update window, bound and overwrite."""
    _finite(proof, "raw trajectory")
    _require(len(proof["predictions"]) == len(proof["updates"]) == 33
             and len(proof["ledgers"]) == 32, "Incomplete 33-day trajectory")
    weather, ledger = inputs["warmup_weather"].clone(), torch.zeros(274, dtype=torch.float32)
    terms, output = [], None
    for index, current in enumerate(DAYS):
        _tick(ctx)
        pred, update = proof["predictions"][index], proof["updates"][index]
        _require(pred["date"] == str(current) and pred["locked"] is True
                 and pred["observation_cutoff"] == str(current - timedelta(days=1))
                 and update["as_of_date"] == str(current) and update["missing"] is False
                 and update["cap"] == CAP, "Prediction dates or information cutoff differ")
        _require(update["rain_dates"] == [str(current - timedelta(days=99-lag)) for lag in range(100)],
                 "Control row transposes or changes the 100 rain dates")
        weather = torch.cat((weather, inputs["weather"][index:index+1]))
        ledger = torch.cat((ledger, ledger.new_zeros(1)))
        window = weather[-270:].clone()
        window[:, 0] += ledger[-270:]
        _require(pred["state_digest"] == hashlib.sha256(window.numpy().tobytes()).hexdigest(),
                 "Prediction state does not use the current pre-observation ledger")
        q = pred["tensor"]
        _require(q.dtype == torch.float32 and q.shape == (), "Predicted scalar precision differs")
        device_q = q.to(ctx.device)
        if index:
            terms.append(((device_q-device_q.new_tensor(float(inputs["observations"][index])))
                          / inputs["flow_std"]).square())
        output = ((device_q-inputs["flow_mean"])/inputs["flow_std"]).detach().cpu()
        for name in ("raw", "proposal", "applied", "violation"):
            _require(update[name].dtype == torch.float32 and update[name].shape == (100,),
                     "Update precision or shape differs")
        _equal(update["raw"], weather[-100:, 0], "unmodified historical precipitation")
        lower = -torch.minimum(update["raw"], update["raw"].new_tensor(CAP))
        proposal = update["proposal"]
        physical = torch.maximum(lower, torch.minimum(proposal, proposal.new_tensor(CAP)))
        expected = physical if fixed is None or index == 32 else torch.where(
            fixed[index] == 0, lower, torch.where(fixed[index] == 4, proposal.new_tensor(CAP), proposal))
        violation = (torch.relu(lower-proposal)+torch.relu(proposal-CAP))/CAP
        _algebra_equal(update["applied"], expected, "independent selected projection rule")
        _equal(update["violation"], violation, "raw soft-violation diagnostic")
        before = ledger.clone()
        if index == 32:
            _equal(proposal, before[-100:], "terminal adapter retains preceding controls")
            if fixed is None:
                _equal(expected, proposal, "physical terminal preserves feasible controls")
        ledger = torch.cat((ledger[:-100], expected))
        if index < 32:
            _equal(proof["ledgers"][index], ledger, "latest control overwrites previous ledger")
        if fixed is None:
            _require(bool((weather[:, 0]+ledger >= 0).all()), "Physical corrected rain is negative")
        if index == 32 and terminal is not None:
            for name in ("proposal", "applied", "violation"):
                _equal(terminal[name], update[name], "terminal " + name)
            _equal(terminal["ledger_before_observe"], before, "terminal ledger before")
            _equal(terminal["ledger_after_observe"], ledger, "terminal ledger after")
            _require(terminal["targets_formed_before_observe"] is True
                     and terminal["terminal_proposal_objective_grad"] == [None, None]
                     and terminal["terminal_applied_objective_grad"] == [None, None],
                     "Terminal projection entered a registered objective")
    loss = torch.stack(terms).mean().detach().cpu()
    _equal(proof["loss"], loss, "pure 32-day standardized MSE")
    return {"terminal_output": output, "pure_flow_mse": loss}


def _features(ctx, proof, inputs):
    """Rebuild live recurrent inputs from this trajectory, never original-base features."""
    device = ctx.device
    weather = inputs["warmup_weather"].to(device)
    ledger = weather.new_zeros(274)
    def calendar(day, template):
        first = date(day.year, 1, 1)
        angle = 2.*math.pi*(day-first).days/(date(day.year+1, 1, 1)-first).days
        return template.new_tensor([math.sin(angle), math.cos(angle)])
    rows = [torch.cat((ctx.scaling.weather(row), row.new_tensor([0., 0., 0., 1.]), calendar(day, row)))
            for day, row in zip(WARMUP[-100:], weather[-100:], strict=True)]
    result = []
    for index, day in enumerate(DAYS[:32]):
        _tick(ctx)
        today = inputs["weather"][index].to(device)
        weather = torch.cat((weather, today[None]))
        ledger = torch.cat((ledger, ledger.new_zeros(1)))
        q = proof["predictions"][index]["tensor"].to(device)
        obs = q.new_tensor(float(inputs["observations"][index]))
        normalized_obs = (obs-inputs["flow_mean"])/inputs["flow_std"]
        normalized_prior = (q-inputs["flow_mean"])/inputs["flow_std"]
        error = (obs-q)/inputs["flow_std"]
        row = torch.cat((ctx.scaling.weather(today), torch.stack((normalized_obs, normalized_prior, error,
                                                                 error.new_zeros(()))), calendar(day, today)))
        rows = (rows+[row])[-100:]
        result.append([x.detach().cpu().clone() for x in (torch.stack(rows), ctx.scaling.weather(weather[-100:]),
            ledger[-100:], torch.arange(99, -1, -1, dtype=weather.dtype, device=device))])
        ledger = torch.cat((ledger[:-100], proof["updates"][index]["applied"].to(device)))
    return result


def relative_error(a, b):
    denominator = max(abs(a), abs(b))
    return None if denominator == 0 else abs(a-b)/denominator


def scalar_screen(plus, minus):
    _require(plus.dtype == minus.dtype == torch.float32 and plus.shape == minus.shape == (),
             "Objective scalar is not original float32")
    a, b = np.float32(float(plus)), np.float32(float(minus))
    spacing = max(float(np.nextafter(x, np.float32(np.inf))-x) for x in (a, b))
    spacing = max(spacing, *(float(x-np.nextafter(x, np.float32(-np.inf))) for x in (a, b)))
    difference = abs(float(a)-float(b))
    return {"spacing": spacing, "absolute_difference": difference,
            "resolved": math.isfinite(spacing) and difference >= 32.*spacing}


def representation_screen(base, plus, minus, direction, delta):
    _require(base.dtype == plus.dtype == minus.dtype == direction.dtype == torch.float32
             and base.shape == plus.shape == minus.shape == direction.shape,
             "Parameter representation shape or precision differs")
    b, p, m, d = (x.detach().cpu().double() for x in (base, plus, minus, direction))
    direction_error = float(((p-m)/(2.*delta)-d).abs().max())
    midpoint_error = float(((p+m)/2.-b).abs().max())
    return {"max_direction_deviation": direction_error, "max_midpoint_deviation": midpoint_error,
            "representation_pass": direction_error <= .001 and midpoint_error <= delta*.001}


def classify_local_direction(automatic, rows, objective):
    """Choose the first admitted adjacent pair before any AD comparison."""
    _require(objective in OBJECTIVES and len(rows) == 5
             and [r["delta"] for r in rows] == list(SCALES), "Unregistered direction/scale inventory")
    pair = next(([i, i+1] for i in range(4)
                 if rows[i]["representation_pass"] and rows[i]["resolved"]
                 and rows[i+1]["representation_pass"] and rows[i+1]["resolved"]), None)
    record = {"automatic": automatic, "reference_pair": pair, "effective": False,
              "status": "NUMERICAL_UNCONFIRMED", "smaller_resolved_indices": [], "larger_scale_indices": []}
    if not math.isfinite(automatic) or any(not math.isfinite(r["finite_difference"]) for r in rows):
        record["status"] = "NONFINITE"
        return record
    if pair is None:
        return record
    a, b = (rows[i]["finite_difference"] for i in pair)
    smaller = [i for i in range(pair[0]) if rows[i]["representation_pass"] and rows[i]["resolved"]]
    record["smaller_resolved_indices"], record["larger_scale_indices"] = smaller, list(range(pair[1]+1, 5))
    same = lambda x, y: x*y > 0
    close = lambda x, y: relative_error(x, y) is not None and relative_error(x, y) <= .05
    # A resolved smaller contradiction is never excused by low sensitivity.
    if not same(a, b) or not close(a, b):
        record["status"] = "NOT_CONVERGED"
    elif any(not same(automatic, rows[i]["finite_difference"])
             or not close(automatic, rows[i]["finite_difference"]) for i in smaller + pair):
        record["status"] = "LOCAL_DERIVATIVE_INCONSISTENT"
    elif objective == "terminal_output" and min(abs(automatic), abs(a), abs(b)) < .001:
        record["status"] = "LOW_SENSITIVITY"
    else:
        record["status"], record["effective"] = "PASS", True
    return record


def _original_sources(ctx):
    # This registry supplies only pinned path/date/byte admission. Numerical
    # interpretation, reconstruction, and every decision remain in this file.
    from .saved_context_v04 import OriginalProofRegistry
    registry = OriginalProofRegistry(ctx.require_unchanged)
    rows = registry.result["completed_records"]
    def event(label):
        found = [r for r in rows if r["label"] == label]
        _require(len(found) == 1, "Original event is not unique: " + label)
        return found[0]
    def by_label(label):
        found = [r for r in registry.result["artifacts"]
                 if Path(r["path"]).stem.split("_", 1)[-1] == label]
        _require(len(found) == 1, "Original artifact is not unique: " + label)
        _tick(ctx)
        return _decode(registry.load(found[0]))
    originals = {"bound_inputs": by_label("bound_inputs"), "frozen_before": by_label("frozen_before"),
                 "adapter": _decode(registry.load(event("nonzero_adapter")["proof"])), "groups": {}}
    for group in ("output_parameters", "encoder_parameters"):
        found = [r for r in rows if r["label"] == "parameter_direction" and r["group"] == group]
        _require(len(found) == 3 and [r["direction_index"] for r in found] == [0, 1, 2],
                 "Original six-direction inventory differs")
        base = _decode(registry.load(found[0]["base_proof"]))
        directions = []
        for row in found:
            _equal(row["base_proof"], found[0]["base_proof"], "same original base binding")
            saved = [_decode(registry.load(scale["proof"])) for scale in row["scales"]]
            _require([v["delta"] for v in saved] == [.0001, .001, .01], "Original scales changed")
            for proof in saved[1:]:
                _equal(proof["direction"], saved[0]["direction"], "unchanged original direction bytes")
            directions.append(saved[0]["direction"])
        originals["groups"][group] = {"base": base, "directions": directions}
    a, b = (originals["groups"][g]["base"] for g in ("output_parameters", "encoder_parameters"))
    _equal(a["snapshot"], b["snapshot"], "two original snapshots")
    _equal(a["trajectory"], b["trajectory"], "two original trajectories")
    original_snapshot = _decode(registry.load(registry.config["only_step_proof"]))
    restored = _decode(registry.load(registry.config["restoration_proof"]))
    for proof in (a["snapshot"], restored["before"], restored["after"]):
        _equal(proof, original_snapshot, "original post-update snapshot chain")
    originals["snapshot"] = original_snapshot
    originals["admission"] = registry.identity
    return originals


def _proof(predictions, updates, ledgers, loss):
    return {"loss": loss.detach().cpu().clone(),
            "predictions": [{"date": str(p.date), "observation_cutoff": str(p.observation_cutoff),
                             "locked": p.locked, "state_digest": p.state_digest,
                             "tensor": p.tensor.detach().cpu().clone()} for p in predictions],
            "updates": [{"as_of_date": str(u.as_of_date), "rain_dates": [str(d) for d in u.rain_dates],
                         "raw": u.raw.detach().cpu().clone(), "proposal": u.proposal.detach().cpu().clone(),
                         "applied": u.applied.detach().cpu().clone(), "violation": u.violation.detach().cpu().clone(),
                         "missing": u.missing, "cap": u.cap} for u in updates],
            "ledgers": [v.detach().cpu().clone() for v in ledgers]}


def _independent_forward(ctx, model, inputs, *, fixed=None, derivatives=False, label):
    """Close every complete-window attempt with one full preservation check."""
    try:
        return _independent_forward_body(ctx, model, inputs, fixed=fixed, derivatives=derivatives, label=label)
    finally:
        require_full_preservation(ctx.require_unchanged, begin_operation=False)
        _tick(ctx, require_checkpoint=False)


def _independent_forward_body(ctx, model, inputs, *, fixed=None, derivatives=False, label):
    """Replay unchanged daily observation logic, with an auditor-owned adapter."""
    from ..dynamic_filter import rollout
    from ..dynamic_filter.stream import ObservationStream
    from ..dynamic_filter.protocol import Phase
    _tick(ctx, new_forward=True)
    counter = getattr(ctx, "full_forward_counter", None)
    _require(counter is not None and callable(getattr(counter, "consume", None)),
             "A shared charged full-forward counter is required before model replay")
    counter.consume(label)
    limit = getattr(ctx, "full_forward_limit", 100)
    _require(limit is None or getattr(counter,"count",101) <= limit, "Shared complete-forward cap exceeded")
    if torch.device(ctx.device).type == "cuda":
        torch.cuda.synchronize(ctx.device)
    features = []
    class Adapter(nn.Module):
        def __init__(self):
            super().__init__()
            self.original, self.calls = model, 0
        def forward(self, a, b, c, d):
            index, self.calls = self.calls, self.calls + 1
            _require(index < 33, "Independent adapter exceeded its 33 update dates")
            if index == 32:
                return c
            features.append([t.detach().cpu().clone() for t in (a, b, c, d)])
            if hasattr(self.original, "controls"):
                return self.original.controls[index]
            return self.original(a, b, c, d)
    original_project = rollout.project_rain
    calls = 0
    def extension(raw, proposal, cap):
        nonlocal calls
        index, calls = calls, calls + 1
        _require(index < 33, "Independent extension exceeded 33 projections")
        if index == 32:
            return original_project(raw, proposal, cap)
        codes = fixed[index].to(proposal.device)
        lower, upper = -torch.minimum(raw, proposal.new_tensor(cap)), proposal.new_tensor(cap)
        applied = torch.where(codes == 0, lower, torch.where(codes == 4, upper, proposal))
        violation = (torch.relu(lower-proposal)+torch.relu(proposal-upper))/upper
        return raw+applied, applied, violation
    if fixed is not None:
        rollout.project_rain = extension
    try:
        adapter = Adapter()
        replay = rollout.Replay(ctx.hydro, adapter, ctx.scaling, WARMUP,
                                inputs["warmup_weather"].to(ctx.device), kind="rain", deadline=ctx.deadline-300)
        stream = ObservationStream(Phase("fit", DAYS[0], DAYS[-1]), inputs["observations"])
        predictions, updates, ledgers, terms = [], [], [], []
        for index, current in enumerate(DAYS):
            _tick(ctx)
            pred = replay.predict(current, inputs["weather"][index].to(ctx.device))
            obs = stream.release(pred)
            predictions.append(pred)
            if index:
                terms.append(((pred.tensor-pred.tensor.new_tensor(float(obs.value)))/inputs["flow_std"]).square())
            if index == 32:
                targets = {"terminal_output": (pred.tensor-inputs["flow_mean"])/inputs["flow_std"],
                           "pure_flow_mse": torch.stack(terms).mean()}
                before = replay.applied.detach().cpu().clone()
            updates.append(replay.observe(current, obs.value))
            if index < 32:
                ledgers.append(replay.applied.detach().clone())
        _require(adapter.calls == stream.consumed == 33 and (fixed is None or calls == 33),
                 "Independent replay did not consume the exact schedule")
        terminal = {"proposal": updates[-1].proposal.detach().cpu().clone(),
                    "applied": updates[-1].applied.detach().cpu().clone(),
                    "violation": updates[-1].violation.detach().cpu().clone(),
                    "ledger_before_observe": before, "ledger_after_observe": replay.applied.detach().cpu().clone(),
                    "targets_formed_before_observe": True, "terminal_proposal_objective_grad": [],
                    "terminal_applied_objective_grad": []}
        gradients, adjoints, group_gradients = {}, {}, {}
        if derivatives:
            named = sorted(model.named_parameters())
            for name in OBJECTIVES:
                parameters = [p for _, p in named]
                proposal = [u.proposal for u in updates[:32]]
                applied = [u.applied for u in updates[:32]]
                if name == "terminal_output":
                    for group, prefix in (("output_parameters", "decoder.2."), ("encoder_parameters", "encoder.")):
                        members = [(n, p) for n, p in named if n.startswith(prefix)]
                        values = torch.autograd.grad(targets[name], [p for _, p in members], allow_unused=True,
                                                     retain_graph=True)
                        _require(all(g is not None for g in values), "Original group adjoint is missing")
                        group_gradients[group] = {"names": [n for n, _ in members],
                                                  "sizes": [p.numel() for _, p in members],
                                                  "gradients": [g.detach().cpu().clone() for g in values]}
                # Terminal outputs must remain connected to their preceding
                # ledger but not to the tensors produced by terminal observe.
                pg = torch.autograd.grad(targets[name], parameters, allow_unused=True, retain_graph=True)
                ag = torch.autograd.grad(targets[name], proposal+applied, allow_unused=True, retain_graph=True)
                tg = [torch.autograd.grad(targets[name], t, allow_unused=True, retain_graph=True)[0]
                      for t in (updates[-1].proposal, updates[-1].applied)]
                _require(all(g is not None for g in pg+ag), "Independent objective has a missing gradient")
                _require(tg == [None, None], "Terminal projection enters an objective graph")
                gradients[name] = {n: g.detach().cpu().clone() for (n, _), g in zip(named, pg, strict=True)}
                adjoints[name] = {"proposal": [g.detach().cpu().clone() for g in ag[:32]],
                                  "applied": [g.detach().cpu().clone() for g in ag[32:]]}
                terminal["terminal_proposal_objective_grad"].append(None)
                terminal["terminal_applied_objective_grad"].append(None)
        else:
            terminal["terminal_proposal_objective_grad"] = [None, None]
            terminal["terminal_applied_objective_grad"] = [None, None]
        proof = _proof(predictions, updates, ledgers, targets["pure_flow_mse"])
        calculated = _trajectory(ctx, proof, inputs, fixed=fixed, terminal=terminal)
        _equal(calculated, {n: t.detach().cpu().clone() for n, t in targets.items()}, "replayed objectives")
        return {"trajectory": proof, "targets": calculated, "gradients": gradients,
                "adjoints": adjoints, "features": features, "terminal": terminal,
                "saved_group_gradients": group_gradients}
    finally:
        rollout.project_rain = original_project
        _require(rollout.project_rain is original_project, "Independent extension leaked its module reference")
        if torch.device(ctx.device).type == "cuda":
            torch.cuda.synchronize(ctx.device)


def _check_parameters(model, snapshot):
    named = dict(model.named_parameters())
    _require(sum(p.numel() for p in named.values()) == 5633
             and all(p.dtype == torch.float32 and p.requires_grad for p in named.values()),
             "Original 5,633-parameter constructor or trainability differs")
    _require(set(snapshot["requires_grad"]) == set(named) and all(snapshot["requires_grad"].values()),
             "New explicit constructor trainability proof differs")
    for prefix, expected in GROUP_SIZES.items():
        _require(sum(p.numel() for n, p in named.items() if n.startswith(prefix)) == expected,
                 "Original layer parameter count differs")
    return named


def _adjoint_gate(base, codes):
    mask = (codes == 2).to(torch.float32)
    counts = {}
    for objective in OBJECTIVES:
        pair = base["adjoints"][objective]
        _require(len(pair["proposal"]) == len(pair["applied"]) == 32, "Incomplete proposal/applied adjoints")
        for label in ("proposal", "applied"):
            _require(all(t is not None and t.dtype == torch.float32 and t.shape == (100,)
                         for t in pair[label]), "Missing or malformed action adjoint")
        a, b = torch.stack(pair["proposal"]), torch.stack(pair["applied"])
        _finite((a, b), "actual action adjoints")
        _algebra_equal(a, b*mask, "all 3,200 analytical clipping derivatives")
        if "statuses" in pair:
            for label in ("proposal", "applied"):
                expected = ["ZERO" if bool((t == 0).all()) else "FINITE_NONZERO" for t in pair[label]]
                _equal(pair["statuses"][label], expected, "explicit adjoint zero/nonzero status")
        counts[objective] = {"positions": 3200, "proposal_exact_zero": int((a == 0).sum()),
                             "applied_exact_zero": int((b == 0).sum()), "missing": 0, "nonfinite": 0}
    return counts


def _flat(mapping, names):
    return torch.cat([mapping[name].detach().cpu().reshape(-1) for name in names])


def audit_gradient_stage(ctx, result):
    """Recompute 90 raw trajectories and 18 decisions, then replay both bases."""
    _tick(ctx)
    _require(result.get("schema") == "precip_local_branch_gradient_v02"
             and result.get("execution_complete") is True and result.get("optimizer_updates") == 0
             and result.get("scales") == list(SCALES) and result.get("objectives") == list(OBJECTIVES),
             "The complete registered derivative evidence is missing")
    reader = _Reader(ctx, result["artifacts"])
    originals = _original_sources(ctx)
    for key in ("registry_sha256", "gradient_result_sha256", "context_identity_sha256", "input_gate_sha256"):
        _equal(result["source_identity"][key], originals["admission"][key], "original fixed source admission")
    saved = originals["snapshot"]
    inputs = _inputs(ctx, originals["bound_inputs"], originals["adapter"])
    outer_rng, frozen = _rng(), _frozen(ctx)
    counter = getattr(ctx, "full_forward_counter", None)
    _require(counter is not None and counter.count == result["full_forward_count"]
             and counter.count <= 98 and list(counter.labels) == result["full_forward_labels"],
             "Raw forward receipt differs or has no room for the two charged base replays")
    _require(counter.count == 92 and type(counter.cumulative_count) is int
             and counter.cumulative_count == result.get("cumulative_full_forward_count")
             and counter.cumulative_count <= 98,
             "Expected 92 current-attempt calls and space for two cumulative charged replays")
    _equal(result.get("full_forward_receipts"), counter.receipts, "persistent main forward receipts")
    _persistent_receipts(ctx, counter.receipts, "gradient_full_forward")
    bases = {name: reader.read(item) for name, item in result["base_proofs"].items()}
    _require(set(bases) == {"original", "extension"}, "Exactly two registered raw bases are required")
    original, extension = bases["original"], bases["extension"]
    original_trajectory = originals["groups"]["output_parameters"]["base"]["trajectory"]
    _equal(original["trajectory"], original_trajectory, "original saved base trajectory")
    codes = branch_codes(original["trajectory"])
    _require(codes.shape == (32, 100) and int((codes == 0).sum()) == 1253
             and int((codes == 2).sum()) == 1947 and not bool(((codes == 1)|(codes == 3)|(codes == 4)).any()),
             "Original complete clipping branch counts differ")
    for key in ("trajectory", "features", "targets", "gradients", "adjoints", "saved_group_gradients",
                "branch_codes", "parameters", "restored_snapshot", "snapshot_before", "requires_grad"):
        _equal(original[key], extension[key], "physical and algebraic base " + key)
    for base in bases.values():
        _equal(base["snapshot_before"], saved, "base exact original restoration before")
        _equal(base["restored_snapshot"], saved, "base exact original restoration after")
        _equal(base["branch_codes"], codes, "independently reconstructed clipping mask")
        _equal(base["parameters"], {n: saved["state_dict"][n] for n in base["parameters"]}, "base parameter bytes")
        _equal(base["targets"], _trajectory(ctx, base["trajectory"], inputs, terminal=base["terminal"]),
               "independently reconstructed base objectives")
        _require(base["terminal"].get("terminal_new_network_call") is False, "Terminal added a network call")
        _equal(base["terminal"]["targets_before_observe"], base["targets"], "objectives formed before terminal")
        _equal(base["features"], _features(ctx, base["trajectory"], inputs), "live closed-loop base features")
        for group in originals["groups"]:
            old = originals["groups"][group]["base"]
            _equal(base["saved_group_gradients"][group],
                   {"names": old["sorted_parameter_names"], "sizes": old["sizes"], "gradients": old["gradients"]},
                   "original separately requested group-only gradient")
    adjoint_counts = _adjoint_gate(original, codes)
    model = None
    decisions, trajectories = [], 0
    try:
        model = ctx.new_network(1001)
        named = _check_parameters(model, original)
        _require(set(original["parameters"]) == set(named), "Raw base parameter inventory differs")
        for objective in OBJECTIVES:
            _require(set(original["gradients"][objective]) == set(named), "Incomplete full-parameter objective gradient")
            for name, parameter in named.items():
                gradient = original["gradients"][objective][name]
                _require(gradient is not None and gradient.dtype == torch.float32 and gradient.shape == parameter.shape,
                         "Missing full-parameter gradient or wrong shape")
        expected_inventory = [("output_parameters", "decoder.2.", i) for i in range(3)] + [
            ("encoder_parameters", "encoder.", i) for i in range(3)] + [
            ("middle_decoder_parameters", "decoder.0.", i) for i in range(3)]
        actual_inventory = [(r["group"], r["prefix"], r["direction_index"]) for r in result["directions"]]
        # The third group's human label does not define mathematical identity;
        # the prescribed prefix, order, dimensions and generator do.
        _require(len(actual_inventory) == 9 and [x[1:] for x in actual_inventory] == [x[1:] for x in expected_inventory]
                 and actual_inventory[:6] == expected_inventory[:6], "Nine-direction registration changed")
        generator = torch.Generator(device="cpu")
        generator.manual_seed(1001)
        for registered in result["directions"]:
            direction_proof = reader.read(registered["direction_proof"])
            prefix, group, index = registered["prefix"], registered["group"], registered["direction_index"]
            names = sorted(n for n in named if n.startswith(prefix))
            sizes = [named[n].numel() for n in names]
            _equal(registered["names"], names, "direction sorted names")
            _equal(registered["sizes"], sizes, "direction storage sizes")
            for name in ("names", "sizes", "group", "prefix", "direction_index"):
                _equal(direction_proof[name], registered[name], "direction proof identity")
            direction = direction_proof["direction"]
            _require(direction.dtype == torch.float32 and direction.shape == (GROUP_SIZES[prefix],)
                     and float(direction.abs().max()) == 1., "Direction representation or normalization differs")
            if prefix != "decoder.0.":
                _equal(direction, originals["groups"][group]["directions"][index], "original six direction bytes")
                _require(direction_proof["generator_before"] is None and direction_proof["generator_after"] is None
                         and direction_proof["original_saved_direction"] is True, "Original direction was redrawn")
            else:
                _equal(direction_proof["generator_before"], generator.get_state(), "supplemental generator before")
                sample = torch.randn((1280,), generator=generator, dtype=torch.float32)
                _equal(direction, sample/sample.abs().max(), "fixed supplemental CPU direction")
                _equal(direction_proof["generator_after"], generator.get_state(), "supplemental generator after")
                _require(direction_proof["generator_seed"] == 1001
                         and direction_proof["original_saved_direction"] is False, "Supplemental generator identity differs")
            automatic = {objective: float((_flat(original["gradients"][objective], names).to(ctx.device)
                                         * direction.to(ctx.device)).sum()) for objective in OBJECTIVES}
            _equal(registered["automatic"], automatic, "independent float32 directional derivative")
            _require([s["delta"] for s in registered["scales"]] == list(SCALES), "Five-scale inventory changed")
            rows = {objective: [] for objective in OBJECTIVES}
            for scale in registered["scales"]:
                delta, proof = scale["delta"], reader.read(scale["proof"])
                for name in ("group", "prefix", "direction_index", "names", "sizes"):
                    _equal(proof[name], registered[name], "pair registration")
                _equal(proof["direction"], direction, "pair direction bytes")
                _equal(proof["base_parameters"], original["parameters"], "pair exact original base")
                _equal(proof["base_branches"], codes, "pair fixed original branch mask")
                _equal(proof["automatic"], automatic, "pair independently computed AD")
                targets = {}
                for sign, endpoint_name in ((1., "plus"), (-1., "minus")):
                    endpoint = proof[endpoint_name]
                    _equal(endpoint["snapshot_before"], saved, "endpoint restored before")
                    _equal(endpoint["restored_snapshot"], saved, "endpoint restored after")
                    _require(set(endpoint["parameters"]) == set(named), "Endpoint parameter inventory differs")
                    offset = 0
                    for name, parameter in sorted(named.items()):
                        expected = original["parameters"][name].to(ctx.device).clone()
                        if name in names:
                            count = expected.numel()
                            expected.add_(sign*delta*direction[offset:offset+count].to(ctx.device).reshape(expected.shape))
                            offset += count
                        _equal(endpoint["parameters"][name], expected.detach().cpu(), "actual float32 parameter offset")
                    targets[endpoint_name] = _trajectory(ctx, endpoint["trajectory"], inputs, fixed=codes,
                                                        terminal=endpoint["terminal"])
                    _equal(endpoint["targets"], targets[endpoint_name], "independently rebuilt endpoint objective")
                    _require(len(endpoint["features"]) == 32 and not endpoint["terminal"]["terminal_new_network_call"],
                             "Endpoint did not run current complete network on exactly 32 updates")
                    _equal(endpoint["terminal"]["targets_before_observe"], targets[endpoint_name],
                           "endpoint terminal objective exclusion")
                    _equal(endpoint["features"], _features(ctx, endpoint["trajectory"], inputs),
                           "current endpoint complete closed-loop features")
                    trajectories += 1
                representation = representation_screen(_flat(original["parameters"], names),
                    _flat(proof["plus"]["parameters"], names), _flat(proof["minus"]["parameters"], names), direction, delta)
                for name in ("max_direction_deviation", "max_midpoint_deviation"):
                    _equal(proof["representation"][name], representation[name], "parameter representation metadata")
                _equal(proof["representation"]["resolved"], representation["representation_pass"],
                       "parameter screen decision")
                b, p, m = (_flat(source, names).double() for source in
                           (original["parameters"], proof["plus"]["parameters"], proof["minus"]["parameters"]))
                _equal(proof["representation"]["actual_center_direction"], (p-m)/(2*delta), "actual central direction")
                _equal(proof["representation"]["actual_midpoint"], (p+m)/2, "actual parameter midpoint")
                for objective in OBJECTIVES:
                    screen = scalar_screen(targets["plus"][objective], targets["minus"][objective])
                    scalar = proof["scalar_resolution"][objective]
                    _equal(scalar, {"plus": float(targets["plus"][objective]), "minus": float(targets["minus"][objective]),
                                    "unit_spacing": screen["spacing"], "difference_absolute": screen["absolute_difference"],
                                    "required_spacing_multiple": 32, "resolved": screen["resolved"]},
                           "independent ULP screen")
                    rows[objective].append({"delta": delta, "finite_difference": (scalar["plus"]-scalar["minus"])/(2*delta),
                        "representation_pass": representation["representation_pass"], "resolved": screen["resolved"],
                        "primary_row": {"delta": delta, "finite_difference": (scalar["plus"]-scalar["minus"])/(2*delta),
                            "representation_resolved": representation["representation_pass"], "scalar_resolved": screen["resolved"],
                            "plus": scalar["plus"], "minus": scalar["minus"],
                            "max_direction_deviation": representation["max_direction_deviation"],
                            "max_midpoint_deviation": representation["max_midpoint_deviation"],
                            "unit_spacing": screen["spacing"], "difference_absolute": screen["absolute_difference"],
                            "proof": scale["proof"]}})
            for objective in OBJECTIVES:
                decision = classify_local_direction(automatic[objective], rows[objective], objective)
                found = [r for r in result["numerical_records"] if r["group"] == group
                         and r["direction_index"] == index and r["objective"] == objective]
                _require(len(found) == 1, "A registered objective decision is missing or duplicated")
                primary = found[0]
                for name in ("automatic", "status", "reference_pair", "effective"):
                    _equal(primary[name], decision[name], "independent unique-reference decision")
                _equal(primary["rows"], [r["primary_row"] for r in rows[objective]], "all five independent scalar rows")
                pair = decision["reference_pair"]
                large = [] if pair is None else [i for i in range(pair[1]+1, 5)
                    if automatic[objective]*rows[objective][i]["finite_difference"] <= 0
                    or relative_error(automatic[objective], rows[objective][i]["finite_difference"]) is None
                    or relative_error(automatic[objective], rows[objective][i]["finite_difference"]) > .05]
                _equal(primary["larger_scale_curvature_rows"], large, "preserved larger-scale differences")
                decision.update({"objective": objective, "group": group, "direction_index": index})
                decisions.append(decision)
        _require(trajectories == 90 and len(decisions) == len(result["numerical_records"]) == 18,
                 "Incomplete 90-trajectory / 18-objective independent recomputation")
        final = reader.read(result["final_restoration"])
        _equal(final["snapshot"], saved, "final original runtime restoration")
        _require(final["all_gradients_none"] is True and result["projection_reference_restored"] is True,
                 "Runtime restoration is incomplete")
        rng_proof = reader.read(result["outer_rng_restoration"])
        _equal(rng_proof["before"], rng_proof["after"], "primary outer random-state restoration")
        for name in ("frozen_before", "frozen_after"):
            raw_frozen = reader.read(result[name])
            _equal(raw_frozen["state_dict"], frozen["state_dict"], "protected frozen state " + name)
            _equal(raw_frozen["modes"], frozen["modes"], "protected frozen modes " + name)
        # These two original-model replays are the only additional complete
        # forwards; both consume the caller's shared count and deadline.
        for name, fixed in (("original", None), ("extension", codes)):
            _restore_model(model, saved)
            rebuilt = _independent_forward(ctx, model, inputs, fixed=fixed, derivatives=True,
                                           label="independent_base_"+name)
            for key in ("trajectory", "targets", "gradients", "features", "saved_group_gradients"):
                _equal(rebuilt[key], bases[name][key], "independent actual base replay " + key)
            for objective in OBJECTIVES:
                for label in ("proposal", "applied"):
                    _equal(rebuilt["adjoints"][objective][label], bases[name]["adjoints"][objective][label],
                           "independent actual base adjoints")
            _adjoint_gate(rebuilt, codes)
        _equal(frozen, _frozen(ctx), "independent auditor frozen-model invariance")
        _require(counter.count == 94 and type(counter.cumulative_count) is int and counter.cumulative_count <= 100,
                 "Exactly 94 current-attempt complete calls and the cumulative 100-call cap are required")
        _persistent_receipts(ctx, counter.receipts, "gradient_full_forward")
        passed = all(r["effective"] for r in decisions)
        _require(reader.used == set(reader.items), "Unconsumed raw artifact in the complete proof inventory")
        return {"status": "PASS" if passed else "BLOCKED_OR_UNCONFIRMED", "pass": passed,
                "stage": "gradient", "independent_checks_passed": True, "raw_trajectories_checked": trajectories,
                "objective_directions_checked": 18, "decisions": decisions, "adjoint_counts": adjoint_counts,
                "independent_model_replays": 2, "full_forward_count": counter.count,
                "cumulative_full_forward_count": counter.cumulative_count,
                "full_forward_receipts": list(counter.receipts),
                "persistent_counters": ctx.operation_runtime.counter_snapshot(),
                "original_admission": originals["admission"], "model_inference_by_auditor": True,
                "scientific_fit_or_forecast_claim": False}
    finally:
        if model is not None:
            _restore_model(model, saved)
        _restore_rng(outer_rng)
        _equal(outer_rng, _rng(), "independent auditor random-state restoration")
        _equal(frozen, _frozen(ctx), "independent auditor frozen state on exit")
        _tick(ctx)


class _Controls(nn.Module):
    def __init__(self, values, device):
        super().__init__()
        _require(values.shape == (32, 100) and values.dtype == torch.float32, "Malformed direct control table")
        self.controls = nn.Parameter(values.detach().to(device).clone())


def _optimizer_gate(value, model, step, lr):
    _require(len(value["param_groups"]) == 1, "Adam group inventory differs")
    group = value["param_groups"][0]
    expected = {"lr": lr, "betas": (.9, .999), "eps": 1e-8, "weight_decay": 0., "amsgrad": False,
                "maximize": False, "foreach": None, "capturable": False, "differentiable": False, "fused": None}
    _require(all(group.get(k) == v for k, v in expected.items()), "Original Adam prescription changed")
    parameters = list(model.parameters())
    _require(group["params"] == list(range(len(parameters))), "Adam parameter order differs")
    _require(set(value["state"]) == (set() if step == 0 else set(group["params"])), "Adam moment inventory differs")
    for key, parameter in zip(group["params"], parameters, strict=True):
        if step:
            state = value["state"][key]
            _require(set(state) == {"step", "exp_avg", "exp_avg_sq"} and float(state["step"]) == step,
                     "Adam state step differs from the evaluated parameter state")
            _require(state["exp_avg"].shape == state["exp_avg_sq"].shape == parameter.shape
                     and state["exp_avg"].dtype == state["exp_avg_sq"].dtype == torch.float32,
                     "Adam state precision or shape differs")


def _diagnostics(reader, directory, k, model, trajectory):
    values = reader.read(directory / f"step_{k:04d}_diagnostics.npz")
    named = list(model.named_parameters())
    names = [n for n, _ in named]
    expected = {"predictions", "proposal", "applied", "raw", "proposal_gradient", "applied_gradient",
                "proposal_gradient_missing", "applied_gradient_missing", "parameter_gradient_missing",
                *("parameter_gradient__"+n.replace(".", "_") for n in names)}
    _require(set(values) == expected, "Raw fitting gradient archive inventory differs")
    for name in ("proposal", "applied", "raw"):
        _equal(values[name], torch.stack([u[name] for u in trajectory["updates"][:32]]).numpy(), "fitting raw " + name)
    _equal(values["predictions"], np.asarray([float(p["tensor"]) for p in trajectory["predictions"]]),
           "fitting raw predictions")
    gradients = []
    missing = values["parameter_gradient_missing"]
    _require(missing.shape == (len(named),) and missing.dtype == np.bool_ and not missing.any(),
             "A fitting parameter gradient is missing")
    for name, parameter in named:
        gradient = values["parameter_gradient__"+name.replace(".", "_")]
        _require(gradient.dtype == np.float32 and gradient.shape == tuple(parameter.shape),
                 "Fitting parameter gradient shape/precision differs")
        gradients.append(torch.from_numpy(gradient.copy()).to(parameter.device))
    for name in ("proposal", "applied"):
        _require(values[name+"_gradient_missing"].shape == (32,)
                 and values[name+"_gradient_missing"].dtype == np.bool_
                 and not values[name+"_gradient_missing"].any(), "A fitting action gradient is missing")
        _require(values[name+"_gradient"].shape == (32, 100)
                 and values[name+"_gradient"].dtype == np.float32, "Fitting action gradient shape differs")
    codes = branch_codes(trajectory)
    outside = ((codes == 0)|(codes == 4)).numpy()
    _require(not (values["proposal_gradient"][outside] != 0).any(), "Clipped fitting action retains a proposal gradient")
    return gradients


def audit_fit_stage(ctx, result):
    """Rebuild all states and Adam updates; actually reload the earliest best."""
    _tick(ctx)
    stage = result.get("stage")
    _require(stage in ("direct_control", "network") and result.get("execution_complete") is True
             and result.get("forecast_efficacy_confirmed") is False, "Incomplete registered fitting stage")
    seeds = [None] if stage == "direct_control" else [1001, 1002, 1003]
    _require([r["seed"] for r in result["runs"]] == seeds and result["run_denominator"] == len(seeds),
             "Missing or replaced registered fitting initialization")
    reader = _Reader(ctx, result["fit_raw_artifacts"])
    sources = _original_sources(ctx)
    outer_rng, frozen = _rng(), _frozen(ctx)
    reports, replay_count, updates_checked, reconstruction_receipts = [], 0, 0, []
    try:
        for run in result["runs"]:
            _tick(ctx)
            seed = run["seed"]
            ctx.forward_key = "direct_control" if seed is None else "seed_" + str(seed)
            directory = Path(ctx.output) / ("control" if seed is None else f"seed_{seed}")
            _require(run["output"] == str(directory) and run["algorithm_completed"] is True
                     and run["forecast_efficacy_claim"] is False, "Run identity or scientific scope changed")
            _equal(reader.read(directory/"fit_result.json"), run, "saved fit result")
            last = run["updates_completed"]
            _require(type(last) is int and 0 <= last <= 1000, "Unregistered optimizer update count")
            update_paths = [str(directory / f"update_{k:04d}_before_projection.pt") for k in range(1, last+1)]
            audit_attempt = str(ctx.attempt_id) + "/audit_" + stage + ("_control" if seed is None else f"_seed_{seed}")
            binding = {"saved_path": str(directory / "fit_result.json"),
                       "saved_path_sha256": _sha(directory / "fit_result.json"),
                       "stage": stage, "seed": seed, "updates": update_paths}
            if update_paths:
                ctx.operation_runtime.bind_audit(audit_attempt, binding, update_paths)
            _require(run.get("technical_incomplete_due_to_cumulative_update_limit") is False,
                     "A shortened technical-repair path cannot receive complete scientific negative acceptance")
            training_receipts = run.get("scientific_update_receipts")
            before_count = run.get("scientific_update_count_before_attempt")
            _require(isinstance(training_receipts, list) and len(training_receipts) == last
                     and type(before_count) is int and 0 <= before_count <= 1000
                     and before_count + last == run.get("cumulative_scientific_updates") <= 1000,
                     "Scientific training receipts/cumulative count do not bind the actual path")
            _persistent_receipts(ctx, training_receipts,
                "direct_science_update" if seed is None else "network_" + str(seed) + "_science_update")
            for pattern, expected in (("state_*.pt", {f"state_{k:04d}.pt" for k in range(last+1)}),
                ("step_*.json", {f"step_{k:04d}.json" for k in range(last+1)}),
                ("update_*_before_projection.pt", {f"update_{k:04d}_before_projection.pt" for k in range(1,last+1)})):
                _require({p.name for p in directory.glob(pattern)} == expected, "Missing or hidden fitting state/update")
            bound = reader.read(directory/"bound_inputs.pt")
            inputs = _inputs(ctx, bound)
            _equal(bound["frozen_before"], frozen["state_dict"], "bound frozen model")
            _equal(bound["hydro_modes"], frozen["modes"], "bound frozen model modes")
            model = _Controls(torch.zeros((32,100), dtype=torch.float32), ctx.device) if seed is None else ctx.new_network(seed)
            initial_reference = {n: v.detach().cpu().clone() for n, v in model.state_dict().items()}
            initial = reader.read(directory/"initial.pt")
            _require(initial["seed"] == seed and initial["updates_completed"] == 0, "Incorrect formal initialization")
            _equal(initial["state_dict"], initial_reference, "original zero-output formal initialization")
            for key in ("state_dict", "optimizer", "rng"):
                _equal(initial[key], initial["snapshot"][key], "initial full snapshot binding")
            lr = .1 if seed is None else .001
            optimizer = torch.optim.Adam(model.parameters(), lr=lr, betas=(.9,.999), eps=1e-8, weight_decay=0.)
            _optimizer_gate(initial["optimizer"], model, 0, lr)
            states, errors, best_step, best_loss, checkpoints = {}, [], None, math.inf, []
            for k in range(last+1):
                _tick(ctx)
                state = reader.read(directory/f"state_{k:04d}.pt")
                states[k] = state
                _require(state["updates_completed"] == k, "Evaluated state has the wrong update count")
                for key in ("state_dict", "optimizer"):
                    _equal(state[key], state["snapshot"][key], "evaluated state/snapshot binding")
                if k == 0:
                    _equal(state["state_dict"], initial_reference, "state zero original initialization")
                    _equal(state["optimizer"], initial["optimizer"], "state zero original empty Adam")
                _restore_model(model, state["snapshot"], optimizer)
                _optimizer_gate(state["optimizer"], model, k, lr)
                targets = _trajectory(ctx, state["trajectory"], inputs)
                loss = float(targets["pure_flow_mse"])
                _require(state["mse"] == loss, "Recorded fitting loss differs from all 32 actual targets")
                errors.append(loss)
                if loss < best_loss:
                    best_step, best_loss = k, loss
                step = reader.read(directory/f"step_{k:04d}.json")
                _require(step["updates_completed"] == k and step["mse"] == loss and step["best_step"] == best_step
                         and step["best_mse"] == best_loss
                         and step["parameter_names"] == [n for n, _ in model.named_parameters()],
                         "Earliest best state or update/loss binding differs")
                lower = torch.stack([-torch.minimum(u["raw"], u["raw"].new_tensor(CAP))
                                     for u in state["trajectory"]["updates"][:32]])
                upper = torch.full_like(lower, CAP)
                _equal(bound["lower"], lower, "physical lower rain limits")
                _equal(bound["upper"], upper, "physical upper rain limits")
                proposal = torch.stack([u["proposal"] for u in state["trajectory"]["updates"][:32]])
                applied = torch.stack([u["applied"] for u in state["trajectory"]["updates"][:32]])
                counts = {"proposal_items":3200, "strictly_below":int((proposal < lower).sum()),
                          "strictly_above":int((proposal > upper).sum()), "at_lower":int((proposal == lower).sum()),
                          "at_upper":int((proposal == upper).sum())}
                _require(all(step[n] == value for n, value in counts.items()), "Recorded physical bound counts differ")
                if seed is None:
                    _equal(proposal, state["state_dict"]["controls"], "direct controls equal actual proposals")
                    _equal(proposal, applied, "direct controls remain feasible before evaluation")
                gradients = _diagnostics(reader, directory, k, model, state["trajectory"])
                checkpoint = k % 10 == 0 or k == last
                if checkpoint:
                    checkpoints.append(k)
                    proof = reader.read(directory/f"best_proof_at_{k:04d}.pt")
                    _require(proof["current_step"] == k and proof["best_step"] == best_step
                             and proof["best_mse"] == best_loss, "Checkpoint selected a later/nonminimal loss state")
                    _equal(proof["best_state_dict"], states[best_step]["state_dict"], "checkpoint selected parameter bytes")
                    proof_loss = float(_trajectory(ctx, proof["trajectory"], inputs)["pure_flow_mse"])
                    imported_loss = float(_trajectory(ctx, proof["imported"], inputs)["pure_flow_mse"])
                    _require(proof_loss == imported_loss == best_loss, "Checkpoint best loss or feasible-table loss differs")
                    controls = reader.read(directory/f"best_controls_at_{k:04d}.pt")
                    _equal(controls, torch.stack([u["applied"] for u in proof["trajectory"]["updates"][:32]]),
                           "checkpoint full feasible control table")
                    _require(bool(((controls >= lower)&(controls <= upper)).all()), "Saved best controls violate bounds")
                    _equal(proof["trajectory"]["predictions"], proof["imported"]["predictions"], "network/control checkpoint predictions")
                    _equal(proof["trajectory"]["ledgers"], proof["imported"]["ledgers"], "network/control checkpoint ledgers")
                    _equal(reader.read(directory/f"best_replay_at_{k:04d}.npy"),
                           np.asarray([float(p["tensor"]) for p in proof["trajectory"]["predictions"]]),
                           "checkpoint prediction record")
                    gate = errors[0] > .0001 and best_loss <= .0001 and 1.-best_loss/errors[0] >= .99
                    _equal(step["best_replay"], {"mse":best_loss,"achieved":gate,"initial_already_satisfied":errors[0]<=.0001},
                           "both prespecified fitting thresholds")
                    _require(not gate or k == last, "Fitting continued after registered success")
                if k < last:
                    _restore_model(model, state["snapshot"], optimizer)
                    for parameter, gradient in zip(model.parameters(), gradients, strict=True):
                        parameter.grad = gradient.detach().clone()
                    training_receipt = reader.read(directory/f"scientific_update_receipt_{k+1:04d}.json")
                    _equal(training_receipt, training_receipts[k], "actual scientific update receipt")
                    _require(training_receipt.get("cumulative_count") == before_count + k + 1,
                             "Scientific cumulative update receipt differs")
                    event = training_receipt["record"]["payload"]["event"]
                    _require(event.get("label") == f"{stage}/{seed}/update_{k+1:04d}"
                             and event.get("update_id") is None,
                             "Scientific training receipt does not bind the saved update without audit exemption")
                    update_id = update_paths[k]
                    # Rebuilding an already saved update cannot advance any
                    # training state or candidate. This audit owns its model.
                    _tick(ctx)
                    receipt = ctx.operation_runtime.consume("audit_reconstruction", audit_attempt,
                        f"rebuild_{k+1:04d}", bindings={"update_id": update_id,
                        "saved_path_sha256": _sha(update_id), "audit_binding": binding})
                    reconstruction_receipts.append(receipt)
                    optimizer.step()
                    _finite((model.state_dict(),optimizer.state_dict()), "independently rebuilt Adam update")
                    updated = {n:v.detach().cpu().clone() for n,v in model.state_dict().items()}
                    proof = reader.read(directory/f"update_{k+1:04d}_before_projection.pt")
                    _require(proof["updates_completed"] == k+1, "Updated Adam state count differs")
                    _equal(proof["before_state_dict"], state["state_dict"], "saved pre-update parameters")
                    _equal(proof["state_dict"], updated, "independent Adam parameter update")
                    _equal(proof["optimizer"], optimizer.state_dict(), "independent Adam moment update")
                    if seed is None:
                        projection = reader.read(directory/f"projection_{k+1:04d}.pt")
                        _require(projection["update"] == k+1, "Direct physical projection update count differs")
                        _equal(projection["before_projection"], updated["controls"], "unprojected Adam controls")
                        with torch.no_grad():
                            model.controls.copy_(torch.maximum(lower.to(ctx.device),torch.minimum(model.controls,upper.to(ctx.device))))
                        _equal(projection["after_projection"], model.controls.detach().cpu(), "independent physical projection")
                    following = reader.read(directory/f"state_{k+1:04d}.pt")
                    _equal(following["state_dict"], {n:v.detach().cpu() for n,v in model.state_dict().items()},
                           "next evaluated state follows one Adam update")
                    _equal(following["optimizer"], optimizer.state_dict(), "next evaluated Adam moments")
                    change = max(float((following["state_dict"][n]-v).abs().max()) for n,v in state["state_dict"].items())
                    _equal(reader.read(directory/f"parameter_change_{k+1:04d}.json"),
                           {"from_step":k,"to_step":k+1,"absolute_max":change}, "parameter change record")
                    updates_checked += 1
            _require(run["initial_mse"] == errors[0] and run["last_mse"] == errors[-1]
                     and run["best_mse"] == best_loss and run["best_step"] == best_step,
                     "Final fit summary is not bound to the evaluated earliest best")
            uninformative = errors[0] <= .0001
            _require(run["initial_already_satisfied"] is uninformative
                     and (not uninformative or last == 0),
                     "An already-satisfied window must stop without scientific updates")
            gate = errors[0] > .0001 and best_loss <= .0001 and 1.-best_loss/errors[0] >= .99
            _require(run["fit_gate_pass"] is gate and (gate or last == 1000 or uninformative),
                     "Incomplete optimizer search was labeled complete")
            best = reader.read(directory/"best.pt")
            _require(best["updates_completed"] == best_step and best["mse"] == best_loss, "Best checkpoint count/loss differs")
            _equal(best["state_dict"], states[best_step]["state_dict"], "best checkpoint full state")
            selected = states[best_step]
            _restore_model(model, selected["snapshot"])
            with torch.no_grad():
                rebuilt = _independent_forward(ctx, model, inputs, label=f"independent_best_{seed}")
            replay_count += 1
            _equal(rebuilt["trajectory"], selected["trajectory"], "actual reloaded minimum-loss parameters")
            _require(float(rebuilt["targets"]["pure_flow_mse"]) == best_loss, "Actual reloaded minimum loss differs")
            controls = torch.stack([u["applied"] for u in rebuilt["trajectory"]["updates"][:32]])
            with torch.no_grad():
                imported = _independent_forward(ctx, _Controls(controls,ctx.device), inputs,
                                                label=f"independent_best_controls_{seed}")
            replay_count += 1
            for key in ("predictions","ledgers","loss"):
                _equal(rebuilt["trajectory"][key], imported["trajectory"][key], "actual reloaded best/control equivalence")
            initial_predictions = reader.read(directory/"initial_predictions.npy")
            _equal(initial_predictions, np.asarray([float(p["tensor"]) for p in states[0]["trajectory"]["predictions"]]),
                   "original initialization prediction record")
            if seed is None:
                zero = reader.read(directory/"zero_network_baseline.pt")
                network = ctx.new_network(1001)
                _equal(zero["state_dict"], {n:v.detach().cpu() for n,v in network.state_dict().items()},
                       "original zero-output network initialization")
                with torch.no_grad():
                    baseline = _independent_forward(ctx,network,inputs,label="independent_zero_network_baseline")
                replay_count += 1
                _equal(zero["trajectory"],baseline["trajectory"], "actual original zero-network baseline")
                _equal(baseline["trajectory"],states[0]["trajectory"], "zero-network and zero-control initial trajectory")
            else:
                predecessor_root = getattr(ctx,"direct_control_output",None)
                predecessor_artifacts = getattr(ctx,"direct_control_artifacts",None)
                _require(predecessor_root is not None and predecessor_artifacts is not None,
                         "Missing byte-bound new direct-control predecessor")
                prior_ctx = copy.copy(ctx)
                prior_ctx.output = Path(predecessor_root)
                prior = _Reader(prior_ctx,predecessor_artifacts)
                _equal(initial_predictions,prior.read(Path(predecessor_root)/"control/initial_predictions.npy"),
                       "all three network seeds versus new direct-control zero baseline")
            after = reader.read(directory/"hydro_after.pt")
            _equal(after["frozen_after"],frozen["state_dict"], "fit did not change frozen-model state")
            _equal(after["modes"],frozen["modes"], "fit did not change frozen-model modes")
            reports.append({"seed":seed,"updates_completed_verified":last,"evaluated_states_verified":last+1,
                            "initial_mse":errors[0],"last_mse":errors[-1],"selected_step":best_step,
                            "selected_mse":best_loss,"relative_reduction":None if errors[0] == 0 else 1.-best_loss/errors[0],
                            "fit_gate_pass":gate,"checkpoints_verified":checkpoints,
                            "all_updates_rebuilt":True,"actual_best_reloaded":True,
                            "window_uninformative":uninformative,"audit_binding":binding,
                            "scientific_updates_verified":last,
                            "scientific_cumulative_updates":before_count+last})
        _require(result["fit_gate_pass_count"] == sum(r["fit_gate_pass"] for r in reports),
                 "Reported passing-seed count differs")
        _equal(frozen,_frozen(ctx),"independent fitting audit frozen-model invariance")
        _persistent_receipts(ctx,reconstruction_receipts,"audit_reconstruction")
        return {"status":"PASS","pass":True,"stage":stage,"independent_checks_passed":True,
                "model_inference_by_auditor":True,"independent_model_replays":replay_count,
                "optimizer_updates_independently_rebuilt":updates_checked,"audited_runs":reports,
                "audit_reconstruction_receipts":reconstruction_receipts,
                "persistent_counters":ctx.operation_runtime.counter_snapshot(),
                "window_uninformative":any(r["window_uninformative"] for r in reports),
                "scientific_fit_or_forecast_claim":False,"no_fit_failure_implies_mathematical_unreachability":True}
    finally:
        _restore_rng(outer_rng)
        _equal(outer_rng,_rng(),"independent fitting audit random-state restoration")
        _equal(frozen,_frozen(ctx),"independent fitting audit frozen state on exit")
        _tick(ctx)
