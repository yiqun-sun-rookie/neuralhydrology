"""Independent reconstruction of previously saved hard-boundary evidence.

No numerical package is imported at module import time.  The caller supplies
the original lock, one 600-second reservation, and its fail-closed time/source
guard.  This auditor creates no model, perturbation, direction, or optimizer.
It returns a report; the caller is responsible for exclusively writing it.
"""

from datetime import date, datetime, timedelta, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import stat
import sys


REPO = Path(__file__).absolute().parents[3]
OLD = REPO / "results/precip_input_da_2026_09/effect_first_v01/small_sample_gradient_20261010_v01"
PROOFS = OLD / "gradient_proofs"
OUTPUT = REPO / "results/precip_input_da_2026_09/effect_first_v01/saved_gradient_boundary_evidence_20261010_v01"
CAP = 32.21650314331055
SCALES = (0.0001, 0.001, 0.01)
GROUPS = ("output_parameters", "encoder_parameters")
ORIGINAL_JSON = {
    "gradient_result.json": "83792e6e0030f164dab78123f31affdedb5f5b74b52e770cc710410af8bde700",
    "failure.json": "3518fda11380d50da8d24658286b2c9942a1d5ffe3e98241e876a56302e8da5b",
    "actual_gradient_failure_audit.json": "cf569aaaa5a8f8c252289c262a55643e6fca2bdba507195167622973f496b615",
}
UPDATE_DAYS = tuple(date(1980, 10, 1) + timedelta(days=i) for i in range(33))


def _require(condition, message):
    if not condition:
        raise PermissionError(message)


def _path(path, root, must_exist=True):
    """Check lexical membership and every parent before any read/resolve."""
    value = Path(path).absolute()
    base = Path(root).absolute()
    _require(value.is_relative_to(base), f"Independent audit path escapes root: {value}")
    for part in (value, *value.parents):
        if os.path.lexists(part):
            entry = part.lstat()
            _require(not stat.S_ISLNK(entry.st_mode) and not
                     (getattr(entry, "st_file_attributes", 0) &
                      getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)),
                     f"Independent audit rejects link/reparse path: {part}")
    _require(value.resolve().is_relative_to(base.resolve()), f"Resolved input escapes root: {value}")
    if must_exist:
        _require(value.is_file(), f"Independent audit input missing: {value}")
    return value


def _sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def _tensor_bytes(value):
    # A byte view avoids any dependency on NumPy's arithmetic or promotion.
    import torch
    t = value.detach().cpu().contiguous()
    return bytes(t.reshape(-1).view(torch.uint8).reshape(-1).tolist())


def _array_identity(value):
    raw = _tensor_bytes(value)
    return {"dtype": str(value.dtype), "shape": list(value.shape),
            "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def _described(value):
    import torch
    if torch.is_tensor(value):
        return _array_identity(value)
    if isinstance(value, dict):
        _require(len({str(k) for k in value}) == len(value), "Ambiguous dictionary key strings")
        return {str(k): _described(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [_described(v) for v in value]
    return value


def _digest(value):
    rendered = json.dumps(_described(value), sort_keys=True, separators=(",", ":"),
                          ensure_ascii=True, allow_nan=False)
    return hashlib.sha256(rendered.encode("utf-8")).hexdigest()


def _exact(first, second, label):
    import torch
    if torch.is_tensor(first) or torch.is_tensor(second):
        _require(torch.is_tensor(first) and torch.is_tensor(second) and
                 first.dtype == second.dtype and first.shape == second.shape and
                 _tensor_bytes(first) == _tensor_bytes(second), f"Saved tensor bytes differ: {label}")
    elif isinstance(first, dict) or isinstance(second, dict):
        _require(isinstance(first, dict) and isinstance(second, dict) and first.keys() == second.keys(),
                 f"Saved mapping keys differ: {label}")
        for key in first:
            _exact(first[key], second[key], label + "/" + str(key))
    elif isinstance(first, (tuple, list)) or isinstance(second, (tuple, list)):
        _require(type(first) is type(second) and len(first) == len(second), f"Saved sequence differs: {label}")
        for i, (a, b) in enumerate(zip(first, second, strict=True)):
            _exact(a, b, label + "/" + str(i))
    else:
        _require(type(first) is type(second) and first == second, f"Saved scalar metadata differs: {label}")


def _finite(value, label):
    import torch
    if torch.is_tensor(value):
        _require(value.device.type == "cpu" and bool(torch.isfinite(value).all()),
                 f"Nonfinite or non-CPU evidence: {label}")
    elif isinstance(value, float):
        _require(math.isfinite(value), f"Nonfinite evidence metadata: {label}")
    elif isinstance(value, dict):
        for k, v in value.items():
            _finite(v, label + "/" + str(k))
    elif isinstance(value, (list, tuple)):
        for i, v in enumerate(value):
            _finite(v, label + "/" + str(i))


def _scalar(value):
    return {"dtype": str(value.dtype), "value": float(value),
            "bytes_hex": _tensor_bytes(value).hex()}


def _positions(mask):
    return [tuple(int(i) for i in pair) for pair in mask.nonzero(as_tuple=False).tolist()]


def _row(arrays, i, j):
    current = UPDATE_DAYS[i]
    result = {"update_index": i, "lag_index": j, "update_date": current.isoformat(),
              "rain_date": (current - timedelta(days=99 - j)).isoformat(),
              "branch": int(arrays["branches"][i, j])}
    for name in ("raw", "proposal", "lower", "upper", "applied", "violation"):
        result[name] = _scalar(arrays[name][i, j])
    result["proposal_minus_lower"] = _scalar(arrays["proposal"][i, j] - arrays["lower"][i, j])
    result["upper_minus_proposal"] = _scalar(arrays["upper"][i, j] - arrays["proposal"][i, j])
    return result


def _trajectory(proof, before, label):
    """Reconstruct all saved coordinates, projection, branches and ledgers."""
    import torch
    before("independent_trajectory_" + label)
    _finite(proof, label)
    _require(set(proof) == {"loss", "predictions", "updates", "ledgers"}, "Unexpected trajectory schema")
    _require(len(proof["predictions"]) == len(proof["updates"]) == 33 and len(proof["ledgers"]) == 32,
             "Incomplete registered 33-day trajectory")
    _require(torch.is_tensor(proof["loss"]) and proof["loss"].shape == () and
             proof["loss"].dtype == torch.float32, "Original loss type/shape differs")
    values = {name: [] for name in ("raw", "proposal", "lower", "upper", "applied", "violation", "branches")}
    ledger = torch.zeros(274, dtype=torch.float32)
    for i, current in enumerate(UPDATE_DAYS):
        pred, update = proof["predictions"][i], proof["updates"][i]
        _require(pred["date"] == current.isoformat() and pred["locked"] is True and
                 pred["observation_cutoff"] == (current - timedelta(days=1)).isoformat() and
                 update["as_of_date"] == current.isoformat() and update["missing"] is False,
                 "Saved prediction/update date or cutoff mismatch")
        _require(update["rain_dates"] == [(current - timedelta(days=99 - j)).isoformat()
                                          for j in range(100)], "Wrong saved 100-day rain calendar")
        _require(update["cap"] == CAP and type(update["cap"]) is float, "Original cap differs")
        _require(isinstance(pred["state_digest"], str) and len(pred["state_digest"]) == 64,
                 "Prediction lacks original state digest")
        _require(torch.is_tensor(pred["tensor"]) and pred["tensor"].shape == () and
                 pred["tensor"].dtype == torch.float32, "Prediction scalar shape/type differs")
        for key in ("raw", "proposal", "applied", "violation"):
            _require(torch.is_tensor(update[key]) and update[key].dtype == torch.float32 and
                     update[key].shape == (100,), f"Original {key} shape/type differs")
        raw, proposal = update["raw"], update["proposal"]
        _require(bool((raw >= 0).all()), "Saved original rain is negative")
        if i:
            _exact(proof["updates"][i - 1]["raw"][1:], raw[:-1], "saved raw rain overlapping dates")
        cap = torch.tensor(CAP, dtype=proposal.dtype)
        lower = -torch.minimum(raw, cap)
        upper = torch.full_like(proposal, cap)
        # Use the original floating-point primitive order, including signed
        # zero, without calling the implementer's projection helper.
        projected = torch.clamp(proposal, min=lower, max=cap)
        violated = (torch.relu(lower - proposal) + torch.relu(proposal - cap)) / cap
        _exact(projected, update["applied"], "independently reconstructed projection")
        _exact(violated, update["violation"], "independently reconstructed violation")
        ledger = torch.cat((ledger, ledger.new_zeros(1)))
        if i < 32:
            ledger = torch.cat((ledger[:-100], projected))
            _exact(ledger, proof["ledgers"][i], "saved calendar overwrite ledger")
            branch = torch.full((100,), 2, dtype=torch.int8)
            branch[proposal < lower] = 0
            branch[proposal == lower] = 1
            branch[proposal == cap] = 3
            branch[proposal > cap] = 4
            for key, value in (("raw", raw), ("proposal", proposal), ("lower", lower), ("upper", upper),
                               ("applied", projected), ("violation", violated), ("branches", branch)):
                values[key].append(value)
        else:
            _exact(proposal, ledger[-100:], "terminal returns held previous controls")
            _exact(update["applied"], ledger[-100:], "terminal keeps previous controls")
        _require(bool((raw + projected >= 0).all()), "Projected rain violates nonnegative boundary")
    arrays = {name: torch.stack(rows) for name, rows in values.items()}
    branch = arrays["branches"]
    _require(branch.shape == (32, 100), "Original active branch denominator is not 3200")
    equality = (branch == 1) | (branch == 3)
    interior = branch == 2
    margin = torch.minimum(arrays["proposal"] - arrays["lower"], arrays["upper"] - arrays["proposal"])
    minimum = float(margin[interior].min()) if bool(interior.any()) else None
    _require(minimum is None or minimum > 0, "Strict interior has nonpositive signed margin")
    summary = {"label": label, "denominator": 3200, "counts": {str(i): int((branch == i).sum()) for i in range(5)},
               "array_identity": {name: _array_identity(value) for name, value in arrays.items()},
               "trajectory_sha256": _digest(proof),
               "equal_boundary_positions": [_row(arrays, i, j) for i, j in _positions(equality)],
               "strict_interior_min_margin": _scalar(margin[interior].min()) if minimum is not None else None,
               "strict_interior_positions": int(interior.sum()),
               "calendar_pass": True, "terminal_hold_pass": True,
               "projection_and_violation_pass": True, "overwrite_ledgers_pass": True}
    _require(sum(summary["counts"].values()) == 3200, "Branch partition does not cover every original item")
    return summary, arrays


def _perturbed_summary(proof, base_arrays, before, label):
    summary, arrays = _trajectory(proof, before, label)
    _exact(base_arrays["raw"], arrays["raw"], "perturbation preserves complete original rain")
    _exact(base_arrays["lower"], arrays["lower"], "perturbation preserves all lower bounds")
    _exact(base_arrays["upper"], arrays["upper"], "perturbation preserves all upper bounds")
    switched = arrays["branches"] != base_arrays["branches"]
    locations = _positions(switched)
    summary["switched_count"] = len(locations)
    summary["switches"] = [{"update_index": i, "lag_index": j,
                            "update_date": UPDATE_DAYS[i].isoformat(),
                            "rain_date": (UPDATE_DAYS[i] - timedelta(days=99 - j)).isoformat(),
                            "base_branch": int(base_arrays["branches"][i, j]),
                            "new_branch": int(arrays["branches"][i, j]),
                            "base": _row(base_arrays, i, j), "perturbed": _row(arrays, i, j)}
                           for i, j in locations]
    return summary, arrays


def _proof_file(config, identity, before, load=True):
    before("independent_saved_file_" + Path(identity["path"]).name)
    root = _path(identity["path"], PROOFS)
    guarded = config["read_path_guard"](root)
    _require(guarded is None or Path(guarded).absolute() == root, "Caller guard redirected original evidence")
    _require(root.parent == PROOFS and root.stat().st_size == identity["bytes"] and
             _sha(root) == identity["sha256"], "Independent raw evidence byte identity mismatch")
    if not load:
        return None
    before("independent_safe_tensor_load_" + root.name)
    import torch
    with root.open("rb") as stream:
        value = torch.load(stream, map_location="cpu", weights_only=True)
    _finite(value, root.name)
    return value


def audit(config, output, before):
    """Return independently recomputed verification of the main result JSON.

    Required config: gradient_result, raw_inventory, read_path_guard,
    expected_runtime, cap, parameter_scales.  ``before(label)`` must enforce
    the same reservation/deadline/source checks before every numerical unit.
    """
    before("independent_boundary_audit_start")
    import torch
    _require(callable(before) and callable(config["read_path_guard"]), "Missing runtime or path guard")
    _require(config["cap"] == CAP and tuple(config["parameter_scales"]) == SCALES,
             "Audit configuration changed old cap or scales")
    runtime = config["expected_runtime"]
    _require(sys.version == runtime["python_version"] and
             Path(sys.executable).absolute() == Path(runtime["python_executable"]).absolute() and
             torch.__version__ == runtime["torch_version"] == "2.2.2", "Actual safe-loading runtime differs")
    output = _path(output, OUTPUT, must_exist=False)
    _require(output == OUTPUT, "Unregistered independent audit output root")
    result_path = _path(output / "boundary_result.json", output)
    before("independent_read_main_result")
    main = json.loads(result_path.read_text(encoding="utf-8"))
    original = {}
    for name, expected in ORIGINAL_JSON.items():
        before("independent_original_json_" + name)
        path = _path(OLD / name, OLD)
        config["read_path_guard"](path)
        _require(_sha(path) == expected, "Bound original JSON bytes changed: " + name)
        original[name] = json.loads(path.read_text(encoding="utf-8"))
    old = original["gradient_result.json"]
    old_audit = original["actual_gradient_failure_audit.json"]
    _require(old == config["gradient_result"] and old["status"] == "FAILED_OR_UNCONFIRMED" and
             old["scientific_fit_confirmed"] is False and old["no_later_stage_without_pass"] is True,
             "Old failure state/configuration differs")
    inventory = config["raw_inventory"]
    _require(inventory == old["artifacts"] == old_audit["raw_partial_artifact_identity"] and
             len(inventory) == 60 and len({str(Path(i["path"]).absolute()) for i in inventory}) == 60,
             "Original complete 60-file inventory differs")
    _require(old_audit["status"] == "CONFIRMED_BLOCK" and old_audit["pass"] is False and
             old_audit["blocking_failure_verified"] is True and old_audit["later_stage_authorized"] is False,
             "Original independent blocking fact changed")
    for identity in inventory:
        _proof_file(config, identity, before, load=False)
    _require(main["schema"] == "precip_saved_gradient_boundary_result_v01" and
             main["status"] == "SAVED_BOUNDARY_DETAILS_COMPLETE" and main["pass"] is True and
             main["original_gradient_status"] == "CONFIRMED_BLOCK" and
             main["later_stage_authorized"] is False and main["raw_inventory"] == inventory,
             "Main boundary report altered scope or raw source inventory")
    records = [row for row in old["completed_records"] if row["label"] == "parameter_direction"]
    _require(len(records) == 6 and [(r["group"], r["direction_index"]) for r in records] ==
             [(g, i) for g in GROUPS for i in range(3)], "Original six-direction order differs")
    _require(len(main["directions"]) == 6, "Main report omitted a registered direction")
    cache = {}

    def loaded(identity):
        _require(identity in inventory, "Referenced proof outside bound original inventory")
        if identity["path"] not in cache:
            cache[identity["path"]] = _proof_file(config, identity, before)
        return cache[identity["path"]]

    step = loaded(config["only_step_proof"])
    restored = loaded(config["restoration_proof"])
    bases, base_arrays, base_summaries = {}, {}, {}
    for group in GROUPS:
        before("independent_base_group_" + group)
        group_records = [row for row in records if row["group"] == group]
        identity = group_records[0]["base_proof"]
        _require(all(r["base_proof"] == identity for r in group_records), "Registered group has different bases")
        base = loaded(identity)
        # RNG after the later saved forward is held by the fixed snapshot and
        # restoration proof.  The one-step proof precedes that forward, so its
        # RNG need not be asserted equal; its actual parameters/optimizer/modes
        # are the exact preserved post-step point.
        for key in ("state_dict", "optimizer", "modes"):
            _exact(base["snapshot"][key], step[key], "fixed base retains exact one-step " + key)
        _exact(base["snapshot"], restored["before"], "base binds original restoration before snapshot")
        _exact(restored["before"], restored["after"], "original restoration retained all snapshot fields")
        _require(restored["before_state_digest"] == restored["after_state_digest"] and
                 restored["before_rng_digest"] == restored["after_rng_digest"], "Original restoration digests differ")
        names, sizes = base["sorted_parameter_names"], base["sizes"]
        prefix = "decoder.2." if group == "output_parameters" else "encoder."
        _require(names == sorted(names) and names == [n for n in sorted(step["state_dict"]) if n.startswith(prefix)] and
                 sizes == [step["state_dict"][n].numel() for n in names], "Saved parameter name/size binding differs")
        _require(base["gradient_status"] == "FINITE" and len(base["gradients"]) == len(names),
                 "Original base gradient status/inventory differs")
        for name, gradient in zip(names, base["gradients"], strict=True):
            _require(torch.is_tensor(gradient) and gradient.dtype == step["state_dict"][name].dtype and
                     gradient.shape == step["state_dict"][name].shape,
                     "Saved original gradient parameter shape/dtype differs")
        summary, arrays = _trajectory(base["trajectory"], before, group + "_base")
        _exact(base["branches"], arrays["branches"], "saved base branches")
        reported = main["bases"][group]
        _require(reported["proof"] == identity and reported["snapshot_sha256"] == _digest(base["snapshot"]) and
                 reported["trajectory"] == summary, "Main complete base details differ from independent reconstruction")
        bases[group], base_arrays[group], base_summaries[group] = base, arrays, summary
    _exact(bases[GROUPS[0]]["snapshot"], bases[GROUPS[1]]["snapshot"], "two bases share original snapshot")
    _exact(bases[GROUPS[0]]["trajectory"], bases[GROUPS[1]]["trajectory"], "two complete base trajectories")
    _require(main["base_trajectories_strict_equal"] is True, "Main did not bind identical complete base trajectories")
    audited_directions = []
    trajectories = 0
    for record, reported in zip(records, main["directions"], strict=True):
        before("independent_direction_" + record["group"] + "_" + str(record["direction_index"]))
        group, index = record["group"], record["direction_index"]
        base, arrays = bases[group], base_arrays[group]
        _require(reported["group"] == group and reported["direction_index"] == index and
                 reported["base_proof"] == record["base_proof"] and
                 reported["sorted_parameter_names"] == base["sorted_parameter_names"] and
                 reported["sizes"] == base["sizes"] and len(reported["scales"]) == 3,
                 "Main registered direction identity differs")
        _require(record["status"] == "NO_SMOOTH_ADJACENT_PAIR" and record["usable"] == [False] * 3,
                 "Old failed gradient direction was modified")
        same_direction = None
        reason_rows = []
        for delta, oldscale, newscale in zip(SCALES, record["scales"], reported["scales"], strict=True):
            proof = loaded(oldscale["proof"])
            _require(proof["delta"] == oldscale["delta"] == newscale["delta"] == delta and
                     newscale["proof"] == oldscale["proof"] and
                     proof["sorted_parameter_names"] == base["sorted_parameter_names"] and
                     proof["sizes"] == base["sizes"], "Original scale/parameter identity differs")
            direction = proof["direction"]
            _require(direction.dtype == torch.float32 and direction.shape == (sum(base["sizes"]),) and
                     float(direction.abs().max()) == 1., "Saved normalized direction shape/dtype differs")
            if same_direction is None:
                same_direction = direction
            else:
                _exact(direction, same_direction, "all scales retain same original direction")
            _require(reported["direction_identity"] == _array_identity(direction), "Main direction tensor identity differs")
            _exact(proof["base_branches"], arrays["branches"], "pair proof preserves original base branches")
            pos, pos_arrays = _perturbed_summary(proof["plus"], arrays, before, f"{group}_{index}_{delta}_plus")
            neg, neg_arrays = _perturbed_summary(proof["minus"], arrays, before, f"{group}_{index}_{delta}_minus")
            trajectories += 2
            _exact(proof["plus_branches"], pos_arrays["branches"], "saved positive branches")
            _exact(proof["minus_branches"], neg_arrays["branches"], "saved negative branches")
            conditions = {"base_has_no_equal_boundaries": not bool(base_summaries[group]["equal_boundary_positions"]),
                          "plus_branches_equal_base": pos["switched_count"] == 0,
                          "minus_branches_equal_base": neg["switched_count"] == 0}
            smooth = all(conditions.values())
            switches = pos["switched_count"] + neg["switched_count"]
            equality = not conditions["base_has_no_equal_boundaries"]
            reason = ("BASE_EQUALITY_AND_SWITCH" if equality and switches else "BASE_EQUALITY_ONLY" if equality else
                      "PERTURBATION_SWITCH_ONLY" if switches else "NO_BOUNDARY_BLOCK")
            _require(proof["smooth"] is oldscale["smooth"] is smooth and smooth is False and
                     newscale["conditions"] == conditions and newscale["smooth_reconstructed"] is smooth and
                     newscale["smooth_saved"] is smooth and newscale["reason"] == reason,
                     "Rebuilt old smooth conjunction or cause differs")
            _require(newscale["plus"] == pos and newscale["minus"] == neg,
                     "Main complete perturbation counts/locations/values/bytes differ")
            reason_rows.append({"delta": delta, "conditions": conditions, "reason": reason,
                                "plus_switches": pos["switched_count"], "minus_switches": neg["switched_count"]})
        audited_directions.append({"group": group, "direction_index": index, "scales": reason_rows})
    before("independent_boundary_final_source_hashes")
    for identity in inventory:
        _proof_file(config, identity, before, load=False)
    for name, expected in ORIGINAL_JSON.items():
        _require(_sha(_path(OLD / name, OLD)) == expected, "Original JSON changed during independent audit")
    _require(trajectories == 36 and len(cache) == 22, "Incomplete independent saved-tensor reconstruction")
    return {"schema": "precip_saved_gradient_boundary_independent_actual_audit_v01", "pass": True,
            "status": "SAVED_BOUNDARY_DETAILS_INDEPENDENTLY_VERIFIED", "original_gradient_status": "CONFIRMED_BLOCK",
            "later_stage_authorized": False, "scientific_fit_or_forecast_claim": False,
            "main_result": {"path": str(result_path), "sha256": _sha(result_path)},
            "auditor_source_sha256": _sha(__file__), "ended_utc": datetime.now(timezone.utc).isoformat(),
            "raw_source_files_byte_verified": 60, "original_tensor_files_loaded": len(cache),
            "base_trajectories_rebuilt": 2, "perturbed_trajectories_rebuilt": trajectories,
            "branches_per_trajectory": 3200, "all_33_day_projections_and_ledgers_checked": True,
            "complete_base_trajectories_and_snapshots_equal": True,
            "complete_counts_positions_values_dtypes_bytes_equal_main": True,
            "old_eighteen_smooth_booleans_independently_rebuilt": True,
            "original_600_second_reservation_owned_by_caller": True,
            "numerical_scope": "saved original proposals, rain and boundaries only",
            "model_inference": 0, "optimizer_steps": 0, "new_directions_or_perturbations": 0,
            "raw_streamflow_files_read": False, "score_numeric_values_read": False,
            "bases": {group: {"counts": base_summaries[group]["counts"],
                               "equal_boundary_count": len(base_summaries[group]["equal_boundary_positions"]),
                               "strict_interior_min_margin": base_summaries[group]["strict_interior_min_margin"]}
                      for group in GROUPS}, "directions": audited_directions,
            "conclusion_limit_zh": "恰等边界和有限扰动切换解释旧平滑条件失败；不能单独证明总映射不可微或自动梯度错误。"}
