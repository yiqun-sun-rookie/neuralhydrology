"""Versioned audit wrapper: original gates, isolated NumPy 2.3.3 scaling only."""
import hashlib,json,importlib.util,sys,subprocess,datetime
from pathlib import Path
if not __debug__:raise RuntimeError('Optimization forbidden')
REPO=Path('G:/github/pycharm/projects/neuralhydrology')
ROOT=REPO/'results/precip_input_da_2026_09/dynamic_filter_v03/eight_basin_fixed_recipe_v01_20261003_230000_d5028d71'
MONITOR=ROOT/'monitoring_3h_v01'
ORIGINAL=REPO/'src/precip_input_assimilation/hpc/eight_basin_offline_audit_v01.py'
CHILD=MONITOR/'scaling_numpy233_20261008T233546Z_v01/numpy233_original_scaling_child.py'
MANIFEST=MONITOR/'check_20261008T233546Z_numpy233_installed_manifest_v01.json'
PINS={ORIGINAL:'f1ed53590e9096d5c12959b29bd4a61e97b533d5efc659506ac976dc4721e2e7',CHILD:'2d0450ac43e8297d0721634bed4173a5480a4aa99752c2c1069d718cf5590e51',MANIFEST:'a3835c1025d3030607560ae2673f7d680a0d1ac1e30fa4181b2484a58f57c114'}
def check_pins():
 for p,h in PINS.items():
  if hashlib.sha256(p.read_bytes()).hexdigest()!=h:raise PermissionError('Pinned numerical source changed')
check_pins()
spec=importlib.util.spec_from_file_location('original_audit_numpy233_wrapper',ORIGINAL);a=importlib.util.module_from_spec(spec);sys.modules[spec.name]=a;spec.loader.exec_module(a)
WORK=None
CALLS=[]
def validate_result(result,raw_sha,identity):
 if result.get('numpy')!='2.3.3' or result.get('arrays_sha256')!=raw_sha or result.get('installed_manifest_sha256')!=PINS[MANIFEST] or result.get('score_numeric_reads') is not False:raise PermissionError('Numerical subprocess identity differs')
 values=result.get('results');
 if not isinstance(values,list) or len(values)!=1:raise PermissionError('Numerical result count differs')
 row=values[0]
 if row.get('input_identity')!=identity or row.get('locked') is not None or row.get('original')!=row.get('offline') or row.get('original_function_equals_offline') is not True:raise PermissionError('Original numerical functions disagree')
 expected={'weather_mean','weather_std','flow_mean','flow_std','cap','start','end'}
 if set(row['offline'])!=expected or row['offline']['start']!='1980-10-01' or row['offline']['end']!='1984-09-30':raise PermissionError('Scaling output escaped original fitting dates')
 return row['offline']
def fit_scaling(series):
 check_pins()
 if not series.dates or max(series.dates)>a.DATES['select'][1] or not series.observations or max(series.observations)>a.DATES['select'][1]:raise PermissionError('Numerical input escaped fitting/selection dates')
 if any(d not in series.observations for d in a.dates_between(*a.DATES['fit'])):raise PermissionError('Missing original fitting date')
 identity=series.score_identity
 if not isinstance(identity,dict) or not a.transport().HEX64.fullmatch(identity.get('pre_score_gate_sha256','')):raise PermissionError('No bound current fitting input identity')
 data=[{'basin':'current_bound_fit_input','dates':[str(d) for d in series.dates],'weather':series.weather.tolist(),'observations':{str(d):v for d,v in series.observations.items()},'scaling':None,'input_identity':identity}]
 raw=json.dumps(data,sort_keys=True).encode();raw_sha=hashlib.sha256(raw).hexdigest();out=WORK/('scaling_call_'+str(len(CALLS)).zfill(2));out.mkdir(exist_ok=False);arrays=out/'current_arrays.json';arrays.write_bytes(raw)
 command=[sys.executable,'-I','-B',str(CHILD),str(arrays),raw_sha,str(REPO),str(MANIFEST)]
 failure={'arrays_sha256':raw_sha,'input_identity':identity,'command':command,'source_pins':{str(p):h for p,h in PINS.items()},'status':'FAILED','score_permission_granted':False}
 try:
  try:proc=subprocess.run(command,capture_output=True,timeout=120)
  except (subprocess.TimeoutExpired,OSError) as exc:
   (out/'stdout.txt').write_bytes(getattr(exc,'stdout',None) or b'');(out/'stderr.txt').write_bytes(getattr(exc,'stderr',None) or b'')
   raise
  (out/'stdout.txt').write_bytes(proc.stdout);(out/'stderr.txt').write_bytes(proc.stderr);failure['returncode']=proc.returncode
  if proc.returncode:raise RuntimeError('Isolated numerical subprocess failed; original error retained')
  result=json.loads(proc.stdout);answer=validate_result(result,raw_sha,identity);check_pins()
  if hashlib.sha256(arrays.read_bytes()).hexdigest()!=raw_sha:raise PermissionError('Current arrays changed during numerical execution')
  proof={'arrays_sha256':raw_sha,'stdout_sha256':hashlib.sha256(proc.stdout).hexdigest(),'source_pins':{str(p):h for p,h in PINS.items()},'input_identity':identity,'scaling':answer,'used_original_locked_value':False,'score_read_in_subprocess':False,'status':'SUCCESS'}
  (out/'binding.json').write_text(json.dumps(proof,sort_keys=True),encoding='utf-8');CALLS.append(proof)
 except Exception as exc:
  failure['error_type']=type(exc).__name__;failure['error']=str(exc)
  (out/'failure.json').write_text(json.dumps(failure,sort_keys=True),encoding='utf-8');CALLS.append(failure)
  raise
 return answer

def main():
 global WORK
 # Original main validates all 72 checkpoints and selections before any scoring reads.
 WORK=MONITOR/'numpy233_actual_audit_calls_20261008T233546Z_v03';WORK.mkdir(exist_ok=False)
 a.fit_scaling=fit_scaling
 (WORK/'execution_source.json').write_text(json.dumps({'wrapper_file':str(Path(__file__).resolve()),'wrapper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'original_audit_sha256':PINS[ORIGINAL],'only_replaced_function':'fit_scaling','strict_comparison_unchanged':True,'all72_original_gates_unchanged':True}),encoding='utf-8')
 try:a.main()
 finally:(WORK/'completed_calls.json').write_text(json.dumps({'calls':CALLS,'call_count':len(CALLS),'new_science_experiments':0,'record_does_not_grant_score_permission':True},sort_keys=True),encoding='utf-8')
if __name__=='__main__':main()
