"""Separate, bounded diagnostics of fixed-window precipitation-control fitting."""
