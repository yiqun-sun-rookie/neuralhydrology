"""Independent numerical audits, executed only inside the caller's open stage.

Importing this file performs no numerical work.  Actual calls read only the
stage's newly saved evidence and the accepted first-stage fitting observations.
They use the protected original Replay and network constructor, never the new
small_forward, optimizer driver, or directional classifier.  Every read and
new calculation inherits the caller's deadline, including its 300 s reserve.
"""

from datetime import date, timedelta
import copy
import hashlib
import json
import math
from pathlib import Path

from .audit_v01 import FAMILY, PILOT, PHASE_ROOTS, _check_time, _read_json, _require, _safe, _sha


CAP = 32.21650314331055
SCALES = (.0001, .001, .01)
DAYS = tuple(date(1980, 10, 1) + timedelta(days=i) for i in range(33))
WARMUP = tuple(date(1980, 1, 1) + timedelta(days=i) for i in range(274))
PARAMETERS = ("encoder.weight_ih_l0", "encoder.weight_hh_l0", "encoder.bias_ih_l0",
              "encoder.bias_hh_l0", "decoder.0.weight", "decoder.0.bias",
              "decoder.2.weight", "decoder.2.bias")


def _tick(ctx):
    _check_time(ctx)
    ctx.require_unchanged()


def _finite(value, label):
    import numpy as np
    import torch
    if isinstance(value, torch.Tensor):
        _require(bool(torch.isfinite(value).all()), "Nonfinite audit tensor: " + label)
    elif isinstance(value, np.ndarray):
        _require(value.dtype.kind in "fiu b".replace(" ", "") and bool(np.isfinite(value).all()),
                 "Nonfinite/unapproved audit array: " + label)
    elif isinstance(value, dict):
        for key, item in value.items():
            _finite(item, label + "/" + str(key))
    elif isinstance(value, (tuple, list)):
        for i, item in enumerate(value):
            _finite(item, label + "/" + str(i))
    elif isinstance(value, float):
        _require(math.isfinite(value), "Nonfinite audit scalar: " + label)


def _decode(value):
    """Decode only the reviewed byte-preserving NumPy evidence representation."""
    import numpy as np
    if isinstance(value, dict) and set(value) == {"numpy_dtype", "shape", "bytes_hex"}:
        dtype = np.dtype(value["numpy_dtype"])
        _require(dtype.kind in "fiub" and not dtype.hasobject, "Unapproved encoded array dtype")
        shape = value["shape"]
        _require(isinstance(shape, list) and all(type(x) is int and x >= 0 for x in shape),
                 "Malformed encoded array shape")
        raw = bytes.fromhex(value["bytes_hex"])
        _require(len(raw) == math.prod(shape) * dtype.itemsize, "Encoded array byte count differs")
        return np.frombuffer(raw, dtype=dtype).copy().reshape(shape)
    if isinstance(value, dict):
        return {key: _decode(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return type(value)(_decode(item) for item in value)
    return value


def _equal(first, second, label):
    import numpy as np
    import torch
    if isinstance(first, torch.Tensor) or isinstance(second, torch.Tensor):
        _require(isinstance(first, torch.Tensor) and isinstance(second, torch.Tensor) and
                 first.dtype == second.dtype and first.shape == second.shape and
                 torch.equal(first.detach().cpu(), second.detach().cpu()), "Tensor identity differs: " + label)
    elif isinstance(first, np.ndarray) or isinstance(second, np.ndarray):
        _require(isinstance(first, np.ndarray) and isinstance(second, np.ndarray) and
                 first.dtype == second.dtype and first.shape == second.shape and
                 np.array_equal(first, second), "Array identity differs: " + label)
    elif isinstance(first, dict) or isinstance(second, dict):
        _require(isinstance(first, dict) and isinstance(second, dict) and set(first) == set(second),
                 "Dictionary identity differs: " + label)
        for key in first:
            _equal(first[key], second[key], label + "/" + str(key))
    elif isinstance(first, (list, tuple)) or isinstance(second, (list, tuple)):
        _require(type(first) is type(second) and len(first) == len(second), "Sequence identity differs: " + label)
        for i, (left, right) in enumerate(zip(first, second, strict=True)):
            _equal(left, right, label + "/" + str(i))
    else:
        _require(type(first) is type(second) and first == second, "Scalar identity differs: " + label)


def _pt(ctx, path, root, identity=None, require_finite=True):
    import torch
    _tick(ctx)
    path = _safe(path, root)
    if identity is not None:
        _require(identity["path"] == str(path) and identity["sha256"] == _sha(path) and
                 identity["bytes"] == path.stat().st_size, "Raw proof byte identity differs")
    value = _decode(torch.load(path, map_location="cpu", weights_only=True))
    if require_finite:
        _finite(value, str(path))
    _tick(ctx)
    return value


def _npy(ctx, path, root, shape, require_finite=True):
    import numpy as np
    _tick(ctx)
    value = np.load(_safe(path, root), allow_pickle=False)
    _require(value.shape == shape and value.dtype.kind == "f" and
             (not require_finite or np.isfinite(value).all()),
             "Malformed/nonfinite saved predictions")
    _tick(ctx)
    return value


def _rng():
    import numpy as np
    import random
    import torch
    return {"python": random.getstate(), "numpy": np.random.get_state(),
            "torch_cpu": torch.get_rng_state().clone(),
            "torch_cuda": [x.clone() for x in torch.cuda.get_rng_state_all()] if torch.cuda.is_available() else []}


def _restore_rng(value):
    import numpy as np
    import random
    import torch
    random.setstate(value["python"])
    np.random.set_state(value["numpy"])
    torch.set_rng_state(value["torch_cpu"])
    if value["torch_cuda"]:
        _require(torch.cuda.is_available() and len(value["torch_cuda"]) == torch.cuda.device_count(),
                 "Audit random-state device count differs")
        torch.cuda.set_rng_state_all(value["torch_cuda"])


def _frozen(ctx):
    import torch
    _tick(ctx)
    model = ctx.hydro.frozen.model
    modes = {name: child.training for name, child in model.named_modules()}
    _require(modes == ctx.mode_reference and modes.get("") is False and
             modes.get("lstm") is True and modes.get("dropout") is False,
             "Frozen hydrology execution modes differ")
    _require(all(not p.requires_grad and p.grad is None for p in model.parameters()),
             "Frozen hydrology parameters received gradients")
    digest = hashlib.sha256()
    for name, tensor in model.state_dict().items():
        _require(torch.isfinite(tensor).all().item(), "Frozen hydrology state is nonfinite")
        digest.update(name.encode("utf-8"))
        digest.update(tensor.detach().cpu().contiguous().numpy().tobytes())
    context = _read_json(_safe(Path(ctx.output) / "context_identity.json", ctx.output))
    _require(digest.hexdigest() == context["frozen_state_sha256"], "Frozen hydrology tensor identity differs")
    return {"state_sha256": digest.hexdigest(), "modes": modes, "all_requires_grad_false": True,
            "all_parameter_gradients_absent": True}


def _inputs(ctx, bound, warmup=None):
    import numpy as np
    import torch
    _tick(ctx)
    _require(tuple(str(x) for x in bound["dates"]) == tuple(str(x) for x in DAYS),
             "Bound diagnostic calendar differs")
    weather, obs = bound["weather"], bound["observations"]
    _require(isinstance(weather, np.ndarray) and weather.shape == (33, 5) and
             isinstance(obs, np.ndarray) and obs.shape == (33,), "Bound input shape/dtype differs")
    _finite(weather, "bound weather")
    _finite(obs, "bound observations")
    _require(bool((weather[:, 0] >= 0).all()), "Negative bound precipitation")
    scaling = _read_json(_safe(Path(ctx.output) / "strict_fresh_scaling.json", ctx.output))
    _require(bound["scaling"] == scaling == ctx.scaling.as_dict() and scaling["cap"] == CAP and
             scaling["start"] == "1980-10-01" and scaling["end"] == "1984-09-30" and
             math.isfinite(scaling["flow_std"]) and scaling["flow_std"] > 0,
             "Complete-fitting scaling identity differs")
    identity = _read_json(_safe(Path(ctx.output) / "context_identity.json", ctx.output))
    original_runtime = _read_json(_safe(PILOT / "manifest.json", PILOT))["runtime"]
    _require(identity["runtime"] == ctx.runtime == original_runtime and identity["runtime_strict_equal"] is True and
             identity["score_numeric_reads_started"] is False, "Complete original runtime/input-read identity differs")
    # Accepted first-stage arrays are observations of the original permitted fit
    # period, never the sealed scoring period or the original validation scores.
    first_root = _safe(FAMILY / PHASE_ROOTS[1], FAMILY)
    first_result = _read_json(first_root / "stage_result.json")
    meta = first_result["target_files"]["fit"]
    fit_path = _safe(first_root / "six_weight_replay/fit_observations.npy", first_root)
    _require(meta["file"] == str(fit_path) and meta["sha256"] == _sha(fit_path),
             "Accepted fitting observation evidence changed")
    fit = _npy(ctx, fit_path, first_root, (1461,), require_finite=False)
    _equal(obs, fit[:33], "small targets versus accepted complete fitting observations")
    first = ctx.inputs.dates.index(DAYS[0])
    _require(tuple(ctx.inputs.dates[:first]) == WARMUP, "Warmup calendar differs")
    _equal(weather, ctx.inputs.weather[first:first + 33], "bound weather versus guarded source")
    source = bound if warmup is None else warmup
    _require(tuple(str(x) for x in source["warmup_dates"]) == tuple(str(x) for x in WARMUP),
             "Saved warmup calendar differs")
    warm_weather = source["warmup_weather"]
    if isinstance(warm_weather, np.ndarray):
        warm_weather = torch.as_tensor(warm_weather, dtype=torch.float32)
    _equal(warm_weather, torch.as_tensor(ctx.inputs.weather[:first], dtype=torch.float32),
           "saved warmup versus guarded source")
    if "warmup_applied" in source:
        _equal(source["warmup_applied"], torch.zeros(274, dtype=torch.float32), "zero warmup rain ledger")
    _require(tuple(warm_weather.shape) == (274, 5), "Warmup weather shape differs")
    return {"weather": torch.as_tensor(weather, dtype=torch.float32), "observations": obs,
            "warmup_weather": warm_weather, "flow_std": float(scaling["flow_std"]),
            "flow_mean": float(scaling["flow_mean"])}


def _branches(proof):
    import torch
    values = []
    for update in proof["updates"][:32]:
        lower = -torch.minimum(update["raw"], update["raw"].new_tensor(CAP))
        proposal = update["proposal"]
        branch = torch.full((100,), 2, dtype=torch.int8)
        branch[proposal < lower] = 0
        branch[proposal == lower] = 1
        branch[proposal == CAP] = 3
        branch[proposal > CAP] = 4
        values.append(branch)
    return torch.stack(values)


def _trajectory(ctx, proof, inputs):
    """Reconstruct dates, pre-observation windows, projection and overwrite ledger."""
    import torch
    _tick(ctx)
    _finite(proof, "trajectory proof")
    _require(len(proof["predictions"]) == len(proof["updates"]) == 33 and
             len(proof["ledgers"]) == 32, "Incomplete actual trajectory")
    weather = inputs["warmup_weather"].clone()
    ledger = torch.zeros(274, dtype=weather.dtype)
    errors, predictions = [], []
    for index, current in enumerate(DAYS):
        _tick(ctx)
        prediction, update = proof["predictions"][index], proof["updates"][index]
        _require(prediction["date"] == str(current) and prediction["locked"] is True and
                 prediction["observation_cutoff"] == str(current - timedelta(days=1)) and
                 update["as_of_date"] == str(current) and update["missing"] is False and update["cap"] == CAP,
                 "Actual predict-then-observe calendar/cutoff differs")
        _require(update["rain_dates"] == [str(current - timedelta(days=99 - lag)) for lag in range(100)],
                 "Actual control row has a wrong rain-day index")
        weather = torch.cat((weather, inputs["weather"][index:index + 1]))
        ledger = torch.cat((ledger, ledger.new_zeros(1)))
        window = weather[-270:].clone()
        window[:, 0] = window[:, 0] + ledger[-270:]
        _require(prediction["state_digest"] == hashlib.sha256(window.numpy().tobytes()).hexdigest(),
                 "Prediction state is not the pre-observation rain ledger")
        q = prediction["tensor"]
        _require(isinstance(q, torch.Tensor) and q.shape == () and q.dtype == torch.float32,
                 "Saved predicted flow scalar shape/precision differs")
        predictions.append(float(q))
        if index:
            device_q = q.to(ctx.device)
            target = device_q.new_tensor(float(inputs["observations"][index]))
            errors.append(((device_q - target) / inputs["flow_std"]).square())
        for field in ("raw", "proposal", "applied", "violation"):
            _require(update[field].shape == (100,) and update[field].dtype == torch.float32,
                     "Actual update tensor shape/precision differs")
        _equal(update["raw"], weather[-100:, 0], "unmodified source rain in actual update")
        lower = -torch.minimum(update["raw"], update["raw"].new_tensor(CAP))
        expected = torch.maximum(lower, torch.minimum(update["proposal"], update["proposal"].new_tensor(CAP)))
        violation = (torch.relu(lower - update["proposal"]) + torch.relu(update["proposal"] - CAP)) / CAP
        _equal(update["applied"], expected, "independent hard-bound projection")
        _equal(update["violation"], violation, "independent raw violation diagnostic")
        if index == 32:
            _equal(update["proposal"], ledger[-100:], "terminal returned previous applied controls")
            _equal(update["applied"], ledger[-100:], "terminal preserved feasible ledger")
        else:
            ledger = torch.cat((ledger[:-100], expected))
            _equal(proof["ledgers"][index], ledger, "calendar overwrite ledger")
        _require(bool((weather[:, 0] + ledger >= 0).all()), "Actual corrected rain violates nonnegativity")
    loss = torch.stack(errors).mean().detach().cpu()
    _equal(proof["loss"], loss, "pure 32-target standardized flow objective")
    return {"mse": float(loss), "predictions": predictions, "branches": _branches(proof)}


def _proof(predictions, updates, ledgers, loss):
    return {"loss": loss.detach().cpu(),
            "predictions": [{"date": str(p.date), "observation_cutoff": str(p.observation_cutoff),
                             "locked": p.locked, "state_digest": p.state_digest,
                             "tensor": p.tensor.detach().cpu()} for p in predictions],
            "updates": [{"as_of_date": str(u.as_of_date), "rain_dates": [str(d) for d in u.rain_dates],
                         "raw": u.raw.detach().cpu(), "proposal": u.proposal.detach().cpu(),
                         "applied": u.applied.detach().cpu(), "violation": u.violation.detach().cpu(),
                         "missing": u.missing, "cap": u.cap} for u in updates],
            "ledgers": [value.detach().cpu() for value in ledgers]}


def _forward(ctx, model, inputs, rng=None):
    """Replay the protected original graph through the auditor's date adapter."""
    import torch
    from torch import nn
    from ..dynamic_filter.rollout import Replay
    from ..dynamic_filter.stream import ObservationStream
    from ..dynamic_filter.protocol import Phase
    _tick(ctx)
    if rng is not None:
        _restore_rng(rng)

    class CalendarAdapter(nn.Module):
        def __init__(self):
            super().__init__()
            self.original = model
            self.current, self.visited = None, []

        def forward(self, features, weather, previous, lag):
            _require(len(self.visited) < 33 and self.current == DAYS[len(self.visited)],
                     "Independent replay received duplicate or out-of-order observations")
            current = self.current
            self.visited.append(current)
            if current == DAYS[-1]:
                return previous
            if hasattr(self.original, "controls"):
                return self.original.controls[(current - DAYS[0]).days]
            return self.original(features, weather, previous, lag)

    adapter = CalendarAdapter()
    replay = Replay(ctx.hydro, adapter, ctx.scaling, WARMUP,
                    inputs["warmup_weather"].to(ctx.device), kind="rain", deadline=ctx.deadline - 300)
    source = ObservationStream(Phase("fit", DAYS[0], DAYS[-1]), inputs["observations"])
    predictions, updates, ledgers, errors = [], [], [], []
    for index, current in enumerate(DAYS):
        _tick(ctx)
        adapter.current = current
        pred = replay.predict(current, inputs["weather"][index].to(ctx.device))
        obs = source.release(pred)
        predictions.append(pred)
        if index:
            target = pred.tensor.new_tensor(float(obs.value))
            errors.append(((pred.tensor - target) / inputs["flow_std"]).square())
        updates.append(replay.observe(current, obs.value))
        if index < 32:
            ledgers.append(replay.applied.detach().clone())
    _require(source.consumed == 33 and tuple(adapter.visited) == DAYS,
             "Independent replay did not consume its exact schedule")
    loss = torch.stack(errors).mean()
    raw = _proof(predictions, updates, ledgers, loss)
    _trajectory(ctx, raw, inputs)
    _tick(ctx)
    return raw, predictions, updates, loss


def _controls(ctx, table):
    import torch
    from torch import nn
    _require(table.shape == (32, 100) and table.dtype == torch.float32, "Independent controls shape differs")
    model = nn.Module()
    model.register_parameter("controls", nn.Parameter(table.detach().clone().to(ctx.device)))
    return model


def _network(ctx, seed, state=None):
    import torch
    from ..dynamic_filter_multibasin.controller import network_for
    _tick(ctx)
    model = network_for("rain", ctx.scaling, seed, str(ctx.device))
    _require(tuple(name for name, _ in model.named_parameters()) == PARAMETERS and
             sum(p.numel() for p in model.parameters()) == 5633, "Original network parameter tree differs")
    digest = hashlib.sha256(b"".join(p.detach().cpu().numpy().tobytes() for p in model.parameters())).hexdigest()
    expected = _read_json(_safe(PILOT / f"fits/no_penalties/seed_{seed}/fit_summary.json", PILOT))
    _require(digest == expected["initial_tensors_sha256"], "Original network initialization digest differs")
    if state is not None:
        model.load_state_dict(state, strict=True)
    _tick(ctx)
    return model


def _restore_model(model, snapshot):
    model.load_state_dict(snapshot["state_dict"], strict=True)
    modes = dict(model.named_modules())
    _require(set(modes) == set(snapshot["modes"]), "Saved module-mode tree differs")
    for name, mode in snapshot["modes"].items():
        _require(type(mode) is bool, "Saved mode is not Boolean")
        modes[name].training = mode
    _restore_rng(snapshot["rng"])


def _directions(shape):
    import torch
    generator = torch.Generator(device="cpu")
    generator.manual_seed(1001)
    answer = []
    for _ in range(3):
        value = torch.randn(shape, generator=generator, dtype=torch.float32)
        answer.append(value / value.abs().max())
    return answer


def _direction_gate(automatic, finite_differences, usable):
    """Independent relative-only gate; all registered bad directions stop."""
    _require(len(finite_differences) == len(usable) == 3 and
             all(type(x) is bool for x in usable), "Missing registered derivative scales")
    _require(math.isfinite(automatic) and all(x is None or math.isfinite(x) for x in finite_differences),
             "Nonfinite derivative")
    active = [x for x, allowed in zip(finite_differences, usable, strict=True) if allowed and x is not None]
    if any(max(abs(automatic), abs(x)) >= .001 and
           (automatic * x <= 0 or abs(automatic - x) > .05 * max(abs(automatic), abs(x))) for x in active):
        return "INCONSISTENT"
    pairs = [(i, i + 1) for i in (0, 1) if usable[i] and usable[i + 1] and
             finite_differences[i] is not None and finite_differences[i + 1] is not None and
             finite_differences[i] * finite_differences[i + 1] > 0 and
             abs(finite_differences[i] - finite_differences[i + 1]) <=
             .05 * max(abs(finite_differences[i]), abs(finite_differences[i + 1]))]
    if not pairs:
        return "FINITE_DIFFERENCE_NOT_CONVERGED" if all(usable) else "NO_SMOOTH_ADJACENT_PAIR"
    if abs(automatic) < .001 or any(abs(finite_differences[i]) < .001 for pair in pairs for i in pair):
        return "LOW_SENSITIVITY"
    if any(automatic * finite_differences[i] <= 0 or
           abs(automatic - finite_differences[i]) > .05 * max(abs(automatic), abs(finite_differences[i]))
           for pair in pairs for i in pair):
        return "INCONSISTENT"
    return "PASS"


def _derivative(ctx, plus, minus, target, delta, inputs):
    p = (plus["predictions"][target]["tensor"].to(ctx.device) - inputs["flow_mean"]) / inputs["flow_std"]
    m = (minus["predictions"][target]["tensor"].to(ctx.device) - inputs["flow_mean"]) / inputs["flow_std"]
    return (float(p) - float(m)) / (2 * delta)


def _gradient_status(value):
    import torch
    return "MISSING" if value is None else "NONFINITE" if not torch.isfinite(value).all().item() else \
        "ZERO" if not (value != 0).any().item() else "FINITE_NONZERO"


def _optimizer_shape(optimizer, parameters, step, lr):
    import torch
    _finite(optimizer, "optimizer state")
    _require(len(optimizer["param_groups"]) == 1, "Optimizer has unexpected groups")
    group = optimizer["param_groups"][0]
    _require(group["lr"] == lr and tuple(group["betas"]) == (.9, .999) and group["eps"] == 1e-8 and
             group["weight_decay"] == 0 and group.get("amsgrad", False) is False and
             group.get("maximize", False) is False and group.get("capturable", False) is False and
             group.get("differentiable", False) is False and group.get("fused") in (False, None) and
             len(group["params"]) == len(parameters), "Adam prescription differs")
    states = optimizer["state"]
    if step == 0:
        _require(states == {}, "Initial Adam state is not empty")
    else:
        _require(set(states) == set(group["params"]), "A registered parameter has no Adam state")
        for key, parameter in zip(group["params"], parameters, strict=True):
            state = states[key]
            _require(set(state) == {"step", "exp_avg", "exp_avg_sq"} and float(state["step"]) == step and
                     state["exp_avg"].shape == state["exp_avg_sq"].shape == parameter.shape and
                     state["exp_avg"].dtype == state["exp_avg_sq"].dtype == parameter.dtype,
                     "Adam moments or completed-update count differ")


def audit_gradient(ctx, result):
    """Audit all nine input and six parameter directions on the original graph."""
    import torch
    _tick(ctx)
    outer_rng, frozen_before = _rng(), _frozen(ctx)
    artifacts = result["artifacts"]
    root = _safe(Path(ctx.output) / "gradient_proofs", ctx.output)
    paths = [Path(item["path"]) for item in artifacts]
    _require(len(paths) == len(set(paths)) and all(path.parent == root for path in paths),
             "Gradient proof inventory has duplicates or escapes")
    loaded = {}

    def evidence(label):
        matches = [item for item in artifacts if Path(item["path"]).name.endswith("_" + label + ".pt")]
        _require(len(matches) == 1, "Missing/duplicate gradient raw evidence: " + label)
        path = matches[0]["path"]
        if path not in loaded:
            loaded[path] = _pt(ctx, path, root, matches[0])
        return loaded[path]

    def referenced(item):
        _require(item in artifacts, "Directional evidence is absent from raw inventory")
        path = item["path"]
        if path not in loaded:
            loaded[path] = _pt(ctx, path, root, item)
        return loaded[path]

    replays = 0
    try:
        _require(result["schema"] == "precip_small_sample_gradient_v01" and result["execution_complete"] is True and
                 result["seed"] == 1001 and result["input_target_indices"] == [1, 16, 32] and
                 result["parameter_scales"] == list(SCALES) and result["minimum_directional_response"] == .001 and
                 result["relative_only_limit"] == .05 and result["temporary_optimizer_updates_allowed"] == 1,
                 "Gradient registration differs")
        tests = result["synthetic_tests"]
        test_root = _safe(Path(ctx.output) / "synthetic_tests", ctx.output)
        _require(tests["returncode"] == 0 and
                 tests["same_stage_reservation"] == _sha(Path(ctx.output) / "budget_reservation.json") and
                 tests["report_sha256"] == _sha(test_root / "report.xml") and
                 tests["stdout_sha256"] == _sha(test_root / "stdout.log") and
                 tests["stderr_sha256"] == _sha(test_root / "stderr.log"),
                 "Metered synthetic rejection/logging test evidence differs")
        manifest_sources = _read_json(Path(ctx.output) / "manifest.json")["source_identity"]
        expected_test_names = {"test_small_sample_support_v01.py", "test_small_sample_gradient_v01.py",
                               "test_small_sample_training_v01.py"}
        _require({Path(p).name for p in tests["test_sources"]} == expected_test_names,
                 "Registered numerical test source inventory differs")
        for path, digest in tests["test_sources"].items():
            _tick(ctx)
            legal = _safe(path, Path(__file__).resolve().parents[3])
            relative = legal.relative_to(Path(__file__).resolve().parents[3]).as_posix()
            _require(digest == _sha(legal) == manifest_sources[relative], "Metered numerical test source changed")
        from xml.etree import ElementTree
        xml = ElementTree.parse(_safe(test_root / "report.xml", test_root)).getroot()
        _require(len(xml.findall(".//testcase")) > 0 and not xml.findall(".//failure") and
                 not xml.findall(".//error") and not xml.findall(".//skipped"),
                 "Registered numerical rejection/logging checks are failed, empty or skipped")
        adapter = evidence("nonzero_adapter")
        for label in ("frozen_before", "frozen_after"):
            frozen_proof = referenced(result[label])
            _equal(frozen_proof["state_dict"], {n: t.detach().cpu()
                   for n, t in ctx.hydro.frozen.model.state_dict().items()}, "raw frozen hydrology tensors")
            _equal(frozen_proof["modes"], frozen_before["modes"], "raw frozen module execution modes")
            frozen_names = {n for n, _ in ctx.hydro.frozen.model.named_parameters()}
            _require(set(frozen_proof["requires_grad"]) == set(frozen_proof["grad_is_none"]) ==
                     set(frozen_proof["gradients"]) == frozen_names and
                     all(value is False for value in frozen_proof["requires_grad"].values()) and
                     all(value is True for value in frozen_proof["grad_is_none"].values()) and
                     all(value is None for value in frozen_proof["gradients"].values()),
                     "Saved frozen hydrology parameter-gradient proof differs")
        _equal(referenced(result["frozen_before"]), referenced(result["frozen_after"]),
               "raw stage-two frozen parameters/modes/gradients invariance")
        inputs = _inputs(ctx, evidence("bound_inputs"), adapter)
        rows = torch.arange(32, dtype=torch.float32).reshape(32, 1)
        lags = torch.arange(100, dtype=torch.float32).reshape(1, 100)
        fixture = CAP * (.01 + .001 * torch.remainder(rows, 2) + .00001 * lags)
        _equal(adapter["table"], fixture, "predeclared nonzero calendar fixture")
        _trajectory(ctx, adapter["reference"], inputs)
        _trajectory(ctx, adapter["actual"], inputs)
        _equal(adapter["reference"], adapter["actual"], "nonzero adapter actual proof")
        with torch.no_grad():
            raw, _, _, _ = _forward(ctx, _controls(ctx, fixture), inputs)
        replays += 1
        _equal(raw, adapter["actual"], "independent nonzero calendar replay")
        input_records = result["input_directions"]
        _require([(x["group"], x["direction_index"]) for x in input_records] ==
                 [(f"input_target_{target}", i) for target in (1, 16, 32) for i in range(3)],
                 "Nine registered input directions are incomplete or reordered")
        for target in (1, 16, 32):
            base = evidence(f"input_base_{target}")
            lower = torch.stack([-torch.minimum(u["raw"], u["raw"].new_tensor(CAP))
                                 for u in base["trajectory"]["updates"][:32]])
            upper = torch.full_like(lower, CAP)
            center = (lower + upper) / 2
            _equal(base["lower"], lower, "original-rain lower controls")
            _equal(base["upper"], upper, "original cap upper controls")
            _equal(base["center"], center, "fixed control midpoint")
            _require(bool(((center > lower) & (center < upper)).all()) and
                     base["target_prediction_index"] == target and base["previous_update_index"] == target - 1,
                     "Input gradient is not at its registered point")
            model = _controls(ctx, center)
            raw, predictions, _, _ = _forward(ctx, model, inputs, base["rng"])
            replays += 1
            _equal(raw, base["trajectory"], "independent input base replay")
            _tick(ctx)
            gradient = torch.autograd.grad((predictions[target].tensor - inputs["flow_mean"]) /
                                           inputs["flow_std"], model.controls)[0]
            _equal(base["gradient"], gradient.detach().cpu(), "independent original input autograd")
            _require(base["gradient_status"] == "FINITE", "Original input gradient is unconfirmed")
            for i, direction in enumerate(_directions((100,))):
                record = input_records[(target == 16) * 3 + (target == 32) * 6 + i]
                _require(record["base_proof"] in artifacts and referenced(record["base_proof"]) is base,
                         "Input direction is bound to a different base")
                automatic = float((gradient[target - 1].detach() * direction.to(ctx.device)).sum())
                differences, usable = [], []
                for scale, item in zip(SCALES, record["scales"], strict=True):
                    delta = CAP * scale
                    proof = referenced(item["proof"])
                    _equal(proof["direction"], direction, "registered input direction tensor")
                    plus, minus = center.clone(), center.clone()
                    plus[target - 1] += delta * direction
                    minus[target - 1] -= delta * direction
                    _equal(proof["plus_controls"], plus, "positive registered input perturbation")
                    _equal(proof["minus_controls"], minus, "negative registered input perturbation")
                    interior = bool(((plus > lower) & (plus < upper) & (minus > lower) & (minus < upper)).all())
                    _require(proof["delta_mm"] == item["delta_mm"] == delta and
                             item["strictly_interior"] is interior, "Input perturbation scale/interior differs")
                    for controls, side in ((plus, "plus"), (minus, "minus")):
                        _trajectory(ctx, proof[side], inputs)
                        with torch.no_grad():
                            rebuilt, _, _, _ = _forward(ctx, _controls(ctx, controls), inputs, base["rng"])
                        replays += 1
                        _equal(rebuilt, proof[side], "independent input perturbation replay")
                    derivative = _derivative(ctx, proof["plus"], proof["minus"], target, delta, inputs)
                    _require(proof["automatic"] == automatic and proof["finite_difference"] == derivative,
                             "Input derivative is not derived from saved raw scalars")
                    differences.append(derivative)
                    usable.append(interior)
                status = _direction_gate(automatic, differences, usable)
                _require(record["automatic"] == automatic and record["finite_differences"] == differences and
                         record["usable"] == usable and record["status"] == status == "PASS" and
                         record["effective"] is True, "Input derivative direction failed independent gate")
        restoration = evidence("input_rng_restoration")
        _equal(restoration["before"], restoration["after"], "raw input random-state restoration")
        initial = evidence("temporary_network_initial")
        updated = evidence("temporary_network_after_only_step")
        network = _network(ctx, 1001)
        _equal(initial["state_dict"], {name: value.detach().cpu() for name, value in network.state_dict().items()},
               "temporary network original initialization")
        optimizer = torch.optim.Adam(network.parameters(), lr=.001, betas=(.9, .999), eps=1e-8, weight_decay=0.)
        _optimizer_shape(initial["optimizer"], list(network.parameters()), 0, .001)
        for step, label in ((0, "temporary_first_backward"), (1, "temporary_second_backward")):
            saved = initial if step == 0 else updated
            _restore_model(network, saved)
            optimizer.load_state_dict(saved["optimizer"])
            optimizer.zero_grad(set_to_none=True)
            proof = evidence(label)
            raw, _, _, loss = _forward(ctx, network, inputs, saved["rng"])
            replays += 1
            _equal(raw, proof["trajectory"], "independent isolated network replay")
            _equal(proof["network"], saved["state_dict"], "isolated backward parameter state")
            _tick(ctx)
            loss.backward()
            for prefix, key in (("decoder.2.", "output_gradients"), ("encoder.", "encoder_gradients")):
                names = sorted(name for name, _ in network.named_parameters() if name.startswith(prefix))
                _require(sorted(proof[key]) == names, "Isolated gradient parameter inventory differs")
                statuses = []
                for name in names:
                    actual = dict(network.named_parameters())[name].grad
                    _equal(proof[key][name], None if actual is None else actual.detach().cpu(),
                           "independent isolated network gradient")
                    statuses.append(_gradient_status(actual))
                _require(all(x not in ("MISSING", "NONFINITE") for x in statuses), "Missing/nonfinite isolated gradient")
                if step == 0 and prefix == "encoder.":
                    _require(all(x == "ZERO" for x in statuses), "Initial zero encoder gradient differs")
                else:
                    _require("FINITE_NONZERO" in statuses, "Isolated original graph has no nonzero gradient")
            if step == 0:
                _tick(ctx)
                optimizer.step()
                _equal(updated["state_dict"], {name: value.detach().cpu() for name, value in network.state_dict().items()},
                       "independent only Adam update")
                _equal(updated["optimizer"], _decode(copy.deepcopy(optimizer.state_dict())),
                       "independent temporary Adam state")
                _optimizer_shape(updated["optimizer"], list(network.parameters()), 1, .001)
        parameter_records = result["parameter_directions"]
        groups = ("output_parameters", "encoder_parameters")
        _require([(x["group"], x["direction_index"]) for x in parameter_records] ==
                 [(group, i) for group in groups for i in range(3)], "Six parameter directions are incomplete")
        for group_index, group in enumerate(groups):
            base = evidence("parameter_base_" + group)
            fixed = base["snapshot"]
            _equal(fixed["state_dict"], updated["state_dict"], "post-one-update finite-difference point")
            _equal(fixed["optimizer"], updated["optimizer"], "no second diagnostic optimizer update")
            _restore_model(network, fixed)
            parameters = [(name, parameter) for name, parameter in sorted(network.named_parameters())
                          if name.startswith("decoder.2." if group_index == 0 else "encoder.")]
            names, sizes = [n for n, _ in parameters], [p.numel() for _, p in parameters]
            _require(base["sorted_parameter_names"] == names and base["sizes"] == sizes and
                     base["gradient_status"] == "FINITE", "Parameter derivative source/sort differs")
            raw, predictions, _, _ = _forward(ctx, network, inputs, fixed["rng"])
            replays += 1
            _equal(raw, base["trajectory"], "independent fixed parameter base replay")
            _tick(ctx)
            gradients = torch.autograd.grad((predictions[-1].tensor - inputs["flow_mean"]) /
                                            inputs["flow_std"], [p for _, p in parameters])
            _equal(base["gradients"], [g.detach().cpu() for g in gradients], "independent parameter autograd")
            flat = torch.cat([g.detach().reshape(-1) for g in gradients])
            base_branches = _branches(raw)
            _equal(base["branches"], base_branches, "full base projection branch map")
            for i, direction in enumerate(_directions((sum(sizes),))):
                record = parameter_records[group_index * 3 + i]
                automatic = float((flat * direction.to(ctx.device)).sum())
                differences, usable = [], []
                for delta, item in zip(SCALES, record["scales"], strict=True):
                    proof = referenced(item["proof"])
                    _equal(proof["direction"], direction, "registered parameter direction")
                    _require(proof["sorted_parameter_names"] == names and proof["sizes"] == sizes and
                             proof["delta"] == item["delta"] == delta, "Parameter direction scale/sort differs")
                    for sign, side in ((1., "plus"), (-1., "minus")):
                        _restore_model(network, fixed)
                        offset = 0
                        with torch.no_grad():
                            for _, parameter in parameters:
                                count = parameter.numel()
                                parameter.add_(sign * delta * direction[offset:offset + count].to(ctx.device).reshape(parameter.shape))
                                offset += count
                            rebuilt, _, _, _ = _forward(ctx, network, inputs, fixed["rng"])
                        replays += 1
                        _equal(rebuilt, proof[side], "independent parameter perturbation replay")
                    plus_branches, minus_branches = _branches(proof["plus"]), _branches(proof["minus"])
                    _equal(proof["base_branches"], base_branches, "raw base branches")
                    _equal(proof["plus_branches"], plus_branches, "raw plus branches")
                    _equal(proof["minus_branches"], minus_branches, "raw minus branches")
                    smooth = not bool(((base_branches == 1) | (base_branches == 3)).any()) and \
                        torch.equal(base_branches, plus_branches) and torch.equal(base_branches, minus_branches)
                    derivative = _derivative(ctx, proof["plus"], proof["minus"], 32, delta, inputs)
                    _require(proof["smooth"] is smooth and item["smooth"] is smooth and
                             proof["automatic"] == automatic and proof["finite_difference"] == derivative,
                             "Parameter raw derivatives or branch admissibility differ")
                    differences.append(derivative)
                    usable.append(smooth)
                status = _direction_gate(automatic, differences, usable)
                _require(record["automatic"] == automatic and record["finite_differences"] == differences and
                         record["usable"] == usable and record["status"] == status == "PASS" and
                         record["effective"] is True, "Parameter derivative failed independent gate")
        restoration = evidence("network_raw_restoration")
        _equal(restoration["before"], restoration["after"], "full parameters/buffers/optimizer/RNG restoration")
        _equal(restoration["before"]["state_dict"], updated["state_dict"], "restoration preserved the only update")
        for item in artifacts:
            referenced(item)
        _require(len(loaded) == len(artifacts), "Raw proof inventory is incomplete")
        probes = [(0., [.000105] * 3), (0., [.01] * 3), (-.01, [.01] * 3), (.001, [.01] * 3)]
        _require(all(_direction_gate(g, differences, [True] * 3) != "PASS" for g, differences in probes),
                 "Independent gate accepted a registered zero/sign/scale rejection case")
        _equal(frozen_before, _frozen(ctx), "frozen hydrology audit invariance")
        return {"independent_checks_passed": True, "model_inference_by_auditor": True,
                "independent_model_replays": replays, "input_directions_verified": 9,
                "parameter_directions_verified": 6, "input_perturbations_verified": 54,
                "parameter_perturbations_verified": 36, "temporary_optimizer_updates_verified": 1,
                "raw_proof_artifacts_verified": len(loaded), "derivative_rejection_cases_verified": 4,
                "frozen_invariance": frozen_before, "all_registered_directions_effective": True,
                "scientific_fit_or_forecast_claim": False}
    finally:
        _restore_rng(outer_rng)
        _equal(outer_rng, _rng(), "independent audit random-state restoration")


def audit_gradient_failure(ctx, result):
    """Confirm a saved blocking fact without extending a failed diagnostic.

    No model, perturbation, optimizer, replacement direction or additional
    scientific computation is created.  Insufficient raw evidence remains
    unreviewed rather than being inferred from the implementer's error string.
    """
    import torch
    _tick(ctx)
    _require(result["schema"] == "precip_small_sample_gradient_v01" and
             result["status"] == "FAILED_OR_UNCONFIRMED", "Not a preserved failed gradient diagnostic")
    root = _safe(Path(ctx.output) / "gradient_proofs", ctx.output)
    artifacts = result["artifacts"]
    _require(len({item["path"] for item in artifacts}) == len(artifacts), "Duplicate partial proof paths")
    cache = {}

    def evidence(item):
        _require(item in artifacts and Path(item["path"]).parent == root,
                 "Partial raw proof is outside its registered inventory")
        if item["path"] not in cache:
            cache[item["path"]] = _pt(ctx, item["path"], root, item, require_finite=False)
        return cache[item["path"]]

    def scalar_failures(value, location):
        import numpy as np
        if isinstance(value, torch.Tensor) and not torch.isfinite(value).all().item():
            return [location]
        if isinstance(value, np.ndarray) and value.dtype.kind in "fiub" and not np.isfinite(value).all():
            return [location]
        if isinstance(value, float) and not math.isfinite(value):
            return [location]
        if isinstance(value, dict):
            return [failure for key, item in value.items()
                    for failure in scalar_failures(item, location + "/" + str(key))]
        if isinstance(value, (tuple, list)):
            return [failure for i, item in enumerate(value)
                    for failure in scalar_failures(item, location + "/" + str(i))]
        return []

    blocking = []
    for item in artifacts:
        _tick(ctx)
        proof = evidence(item)
        nonfinite = scalar_failures(proof, Path(item["path"]).name)
        if nonfinite:
            blocking.append({"kind": "nonfinite_raw_evidence", "locations": nonfinite,
                             "proof_sha256": item["sha256"]})
        filename = Path(item["path"]).name
        groups = ("output_gradients",) if filename.endswith("_temporary_first_backward.pt") else \
            ("output_gradients", "encoder_gradients") if filename.endswith("_temporary_second_backward.pt") else ()
        for group in groups:
            raw_gradients = proof[group]
            _require(isinstance(raw_gradients, dict) and bool(raw_gradients), "Failed group has no raw gradient inventory")
            statuses = {name: _gradient_status(value) for name, value in raw_gradients.items()}
            if any(value in ("MISSING", "NONFINITE") for value in statuses.values()) or \
                    all(value == "ZERO" for value in statuses.values()):
                blocking.append({"kind": "unconfirmed_temporary_network_gradient", "group": group,
                                 "raw_parameter_statuses": statuses, "proof_sha256": item["sha256"]})
    # Direction events are emitted before the implementation's all-directions
    # stop gate.  On failure they can exist even if no returned group was assigned.
    for record in result.get("completed_records", []):
        if record.get("label") not in ("input_direction", "parameter_direction"):
            continue
        base = evidence(record["base_proof"])
        if scalar_failures(base, "base"):
            continue
        directions, differences, usable = [], [], []
        automatic = None
        _require(len(record["scales"]) == 3 and type(record["direction_index"]) is int and
                 0 <= record["direction_index"] < 3, "Partial registered scale/direction inventory differs")
        for scale_index, item in enumerate(record["scales"]):
            if "proof" not in item:
                # No unexecuted perturbation is supplied or silently completed.
                differences.append(None)
                usable.append(False)
                continue
            proof = evidence(item["proof"])
            if scalar_failures(proof, "direction"):
                break
            direction = proof["direction"]
            _require(direction.dtype == torch.float32 and float(direction.abs().max()) == 1.,
                     "Partial direction tensor is not the registered normalized direction")
            _equal(direction, _directions(tuple(direction.shape))[record["direction_index"]],
                   "failed registered deterministic direction")
            if record["label"] == "input_direction":
                target = base["target_prediction_index"]
                _require(target in (1, 16, 32) and base["previous_update_index"] == target - 1,
                         "Partial input derivative has a wrong date binding")
                gradient = base["gradient"]
                value = 0. if gradient is None else float((gradient[target - 1].to(ctx.device) *
                                                           direction.to(ctx.device)).sum())
                delta = proof["delta_mm"]
                _require(delta == CAP * SCALES[scale_index] == item["delta_mm"],
                         "Failed input scale/order is not registered")
                lower, upper, center = base["lower"], base["upper"], base["center"]
                plus, minus = center.clone(), center.clone()
                plus[target - 1] += delta * direction
                minus[target - 1] -= delta * direction
                _equal(proof["plus_controls"], plus, "failed positive input perturbation")
                _equal(proof["minus_controls"], minus, "failed negative input perturbation")
                allowed = bool(((plus > lower) & (plus < upper) & (minus > lower) & (minus < upper)).all())
            else:
                target, delta = 32, proof["delta"]
                _require(delta == SCALES[scale_index] == item["delta"], "Failed parameter scale/order is not registered")
                _require(proof["sorted_parameter_names"] == base["sorted_parameter_names"] and
                         proof["sizes"] == base["sizes"], "Partial parameter derivative sort differs")
                gradients = base["gradients"]
                value = 0. if any(g is None for g in gradients) else float((torch.cat(
                    [g.reshape(-1).to(ctx.device) for g in gradients]) * direction.to(ctx.device)).sum())
                branches = _branches(base["trajectory"])
                plus_branches, minus_branches = _branches(proof["plus"]), _branches(proof["minus"])
                _equal(proof["base_branches"], branches, "failed raw base branches")
                _equal(proof["plus_branches"], plus_branches, "failed raw plus branches")
                _equal(proof["minus_branches"], minus_branches, "failed raw minus branches")
                allowed = not bool(((branches == 1) | (branches == 3)).any()) and \
                    torch.equal(branches, plus_branches) and torch.equal(branches, minus_branches)
            if automatic is None:
                automatic = value
            _require(automatic == value and proof["automatic"] == value, "Failed raw automatic derivative differs")
            for side in ("plus", "minus"):
                trajectory = proof[side]
                _require(len(trajectory["predictions"]) == len(trajectory["updates"]) == 33,
                         "Failed directional raw evidence lacks its actual 33-day schedule")
                for index, current in enumerate(DAYS):
                    prediction, update = trajectory["predictions"][index], trajectory["updates"][index]
                    _require(prediction["date"] == str(current) and prediction["locked"] is True and
                             prediction["observation_cutoff"] == str(current - timedelta(days=1)) and
                             update["as_of_date"] == str(current) and update["missing"] is False and
                             update["rain_dates"] == [str(current - timedelta(days=99 - lag)) for lag in range(100)],
                             "Failed directional raw date, cutoff or rain-day index differs")
            scaling_path = _safe(Path(ctx.output) / "strict_fresh_scaling.json", ctx.output)
            scaling = _read_json(scaling_path)
            inputs = {"flow_mean": scaling["flow_mean"], "flow_std": scaling["flow_std"]}
            derivative = _derivative(ctx, proof["plus"], proof["minus"], target, delta, inputs)
            _require(derivative == proof["finite_difference"], "Failed raw center difference differs")
            differences.append(derivative)
            usable.append(allowed)
            directions.append(direction)
        else:
            if automatic is not None and len(differences) == 3:
                _require(record["automatic"] == automatic and record["finite_differences"] == differences and
                         record["usable"] == usable, "Failed direction summary differs from raw evidence")
                status = _direction_gate(automatic, differences, usable)
                _require(record["status"] == status, "Failed directional classification differs")
                if status != "PASS":
                    blocking.append({"kind": "unconfirmed_registered_direction", "group": record["group"],
                                     "direction_index": record["direction_index"], "raw_status": status,
                                     "automatic": automatic, "finite_differences": differences, "usable": usable})
    _require(bool(blocking), "Saved partial evidence does not independently confirm a blocking fact")
    _tick(ctx)
    return {"independent_checks_passed": False, "blocking_failure_verified": True,
            "model_inference_by_auditor": False, "independent_model_replays": 0,
            "raw_partial_artifacts_read": len(cache), "blocking_facts": blocking,
            "raw_partial_artifact_identity": [{"path": item["path"], "sha256": item["sha256"], "bytes": item["bytes"]}
                                              for item in artifacts if item["path"] in cache],
            "unexecuted_checks_completed_by_auditor": False, "later_stage_authorized": False,
            "scientific_fit_or_forecast_claim": False}


def audit_optimization(stage, ctx, result):
    """Rebuild every recorded Adam update and independently replay checkpoints.

    A complete finite search can pass the integrity audit without meeting the
    fitting threshold.  That fact cannot be relabeled as mathematical
    unreachability, recovered true precipitation, or forecast improvement.
    """
    import numpy as np
    import torch
    _tick(ctx)
    _require(stage in ("direct_control", "network"), "Unknown optimization audit stage")
    _require(result["stage"] == stage and result["execution_complete"] is True and
             result["forecast_efficacy_confirmed"] is False, "Optimization completion or scientific scope differs")
    expected_seeds = [None] if stage == "direct_control" else [1001, 1002, 1003]
    _require([run["seed"] for run in result["runs"]] == expected_seeds and
             result["run_denominator"] == len(expected_seeds), "Registered initialization inventory differs")
    outer_rng, frozen_before = _rng(), _frozen(ctx)
    reports, replays, updates_verified = [], 0, 0
    try:
        for run in result["runs"]:
            _tick(ctx)
            seed = run["seed"]
            directory = _safe(Path(ctx.output) / ("control" if seed is None else f"seed_{seed}"), ctx.output)
            _require(run["output"] == str(directory) and run["algorithm_completed"] is True and
                     run["forecast_efficacy_claim"] is False, "Run identity or conclusion scope differs")
            _equal(run, _read_json(_safe(directory / "fit_result.json", directory)), "saved fitting result")
            last = run["updates_completed"]
            _require(type(last) is int and 0 <= last <= 1000, "Completed optimizer updates exceed prescription")
            _require({path.name for path in directory.glob("state_*.pt")} ==
                     {f"state_{k:04d}.pt" for k in range(last + 1)} and
                     {path.name for path in directory.glob("step_*.json")} ==
                     {f"step_{k:04d}.json" for k in range(last + 1)} and
                     {path.name for path in directory.glob("update_*_before_projection.pt")} ==
                     {f"update_{k:04d}_before_projection.pt" for k in range(1, last + 1)},
                     "Saved state/step/update inventory hides missing or unreported updates")
            bound = _pt(ctx, directory / "bound_inputs.pt", directory)
            inputs = _inputs(ctx, bound)
            _equal(bound["hydro_modes"], frozen_before["modes"], "saved hydrology module modes")
            _equal(bound["frozen_before"], {n: t.detach().cpu() for n, t in ctx.hydro.frozen.model.state_dict().items()},
                   "saved frozen hydrology before optimization")
            initial = _pt(ctx, directory / "initial.pt", directory)
            _require(initial["seed"] == seed and initial["updates_completed"] == 0,
                     "Formal optimization did not start from state zero")
            model = _controls(ctx, torch.zeros((32, 100), dtype=torch.float32)) if seed is None else _network(ctx, seed)
            initial_reference = {n: t.detach().cpu() for n, t in model.state_dict().items()}
            _equal(initial["state_dict"], initial_reference, "formal original initialization tensors and buffers")
            _equal(initial["state_dict"], initial["snapshot"]["state_dict"], "initial snapshot parameters")
            _equal(initial["optimizer"], initial["snapshot"]["optimizer"], "initial snapshot optimizer")
            _equal(initial["rng"], initial["snapshot"]["rng"], "initial snapshot random state")
            lr = .1 if seed is None else .001
            _optimizer_shape(initial["optimizer"], list(model.parameters()), 0, lr)
            states, errors, best_step, best_error, checkpoints = {}, [], None, math.inf, []
            optimizer = torch.optim.Adam(model.parameters(), lr=lr, betas=(.9, .999), eps=1e-8, weight_decay=0.)
            for k in range(last + 1):
                _tick(ctx)
                state = _pt(ctx, directory / f"state_{k:04d}.pt", directory)
                states[k] = state
                _require(state["updates_completed"] == k, "E_k is bound to a different parameter state")
                _equal(state["state_dict"], state["snapshot"]["state_dict"], "state snapshot parameter identity")
                _equal(state["optimizer"], state["snapshot"]["optimizer"], "state snapshot Adam identity")
                if k == 0:
                    _equal(state["state_dict"], initial_reference, "state zero retained original initialization")
                _restore_model(model, state["snapshot"])
                optimizer.load_state_dict(state["optimizer"])
                _optimizer_shape(state["optimizer"], list(model.parameters()), k, lr)
                raw_summary = _trajectory(ctx, state["trajectory"], inputs)
                error = raw_summary["mse"]
                _require(state["mse"] == error, "Recorded E_k differs from its actual fixed-state objective")
                errors.append(error)
                if error < best_error:
                    best_step, best_error = k, error
                status = _read_json(_safe(directory / f"step_{k:04d}.json", directory))
                names = [n for n, _ in model.named_parameters()]
                _require(status["updates_completed"] == k and status["mse"] == error and
                         status["best_step"] == best_step and status["best_mse"] == best_error and
                         status["parameter_names"] == names, "Best selection or state/step identity differs")
                lower = torch.stack([-torch.minimum(u["raw"], u["raw"].new_tensor(CAP))
                                     for u in state["trajectory"]["updates"][:32]])
                upper = torch.full_like(lower, CAP)
                _equal(bound["lower"], lower, "saved direct-control lower bounds")
                _equal(bound["upper"], upper, "saved direct-control upper bounds")
                proposals = torch.stack([u["proposal"] for u in state["trajectory"]["updates"][:32]])
                applied = torch.stack([u["applied"] for u in state["trajectory"]["updates"][:32]])
                raw_rain = torch.stack([u["raw"] for u in state["trajectory"]["updates"][:32]])
                counts = {"proposal_items": 3200, "strictly_below": int((proposals < lower).sum()),
                          "strictly_above": int((proposals > upper).sum()),
                          "at_lower": int((proposals == lower).sum()), "at_upper": int((proposals == upper).sum())}
                _require(all(status[key] == value for key, value in counts.items()),
                         "Projection saturation counts or denominators differ")
                if seed is None:
                    _equal(proposals, state["state_dict"]["controls"], "direct state parameters are actual proposals")
                    _equal(proposals, applied, "direct variables are feasible before every forward")
                _tick(ctx)
                diag_path = _safe(directory / f"step_{k:04d}_diagnostics.npz", directory)
                with np.load(diag_path, allow_pickle=False) as data:
                    diagnostics = {name: data[name].copy() for name in data.files}
                _finite(diagnostics, "raw diagnostic archive")
                required = {"predictions", "proposal", "applied", "raw", "proposal_gradient", "applied_gradient",
                            "proposal_gradient_missing", "applied_gradient_missing", "parameter_gradient_missing",
                            *("parameter_gradient__" + n.replace(".", "_") for n in names)}
                _require(set(diagnostics) == required, "Raw gradient archive inventory differs")
                for key, tensor in (("proposal", proposals), ("applied", applied), ("raw", raw_rain)):
                    _equal(diagnostics[key], tensor.numpy(), "diagnostic " + key)
                expected_predictions = np.asarray(raw_summary["predictions"], dtype=np.float64)
                _equal(diagnostics["predictions"], expected_predictions, "raw diagnostic predictions")
                for key in ("proposal_gradient_missing", "applied_gradient_missing"):
                    _require(diagnostics[key].shape == (32,) and diagnostics[key].dtype == np.bool_,
                             "Action gradient missing mask differs")
                for key in ("proposal_gradient", "applied_gradient"):
                    _require(diagnostics[key].shape == (32, 100) and diagnostics[key].dtype == np.float32,
                             "Action gradient shape/precision differs")
                missing = diagnostics["parameter_gradient_missing"]
                _require(missing.shape == (len(names),) and missing.dtype == np.bool_,
                         "Parameter gradient missing mask differs")
                gradients = []
                for index, (name, parameter) in enumerate(model.named_parameters()):
                    gradient = diagnostics["parameter_gradient__" + name.replace(".", "_")]
                    _require(gradient.shape == tuple(parameter.shape) and gradient.dtype == np.float32 and
                             not bool(missing[index]), "A registered optimization gradient is missing or malformed")
                    gradients.append(torch.as_tensor(gradient).to(ctx.device))
                for label in ("proposal", "applied"):
                    mask = diagnostics[label + "_gradient_missing"]
                    _require(not bool(mask.any()), "A recorded action-gradient path is missing")
                outside = (proposals < lower) | (proposals > upper)
                _require(not bool((torch.as_tensor(diagnostics["proposal_gradient"])[outside] != 0).any()),
                         "Strictly clipped proposal retained a flow gradient")
                checkpoint = k % 10 == 0 or k == last
                if checkpoint:
                    checkpoints.append(k)
                    _restore_model(model, state["snapshot"])
                    optimizer.zero_grad(set_to_none=True)
                    rebuilt, _, replay_updates, loss = _forward(ctx, model, inputs, state["snapshot"]["rng"])
                    replays += 1
                    _equal(rebuilt, state["trajectory"], "independent checkpoint current-state replay")
                    for update in replay_updates[:32]:
                        if update.proposal.requires_grad:
                            update.proposal.retain_grad()
                        if update.applied.requires_grad:
                            update.applied.retain_grad()
                    _tick(ctx)
                    loss.backward()
                    for index, (_, parameter) in enumerate(model.named_parameters()):
                        _equal(parameter.grad.detach().cpu(), gradients[index].detach().cpu(),
                               "independent checkpoint parameter gradient")
                    for label in ("proposal", "applied"):
                        raw_gradients = []
                        for update in replay_updates[:32]:
                            tensor = getattr(update, label)
                            _require(tensor.grad is not None, "Independent action-gradient path is absent")
                            raw_gradients.append(tensor.grad.detach().cpu())
                        _equal(torch.stack(raw_gradients).numpy(), diagnostics[label + "_gradient"],
                               "independent checkpoint action gradients")
                    proof = _pt(ctx, directory / f"best_proof_at_{k:04d}.pt", directory)
                    _require(proof["current_step"] == k and proof["best_step"] == best_step and
                             proof["best_mse"] == best_error, "Checkpoint omitted an earlier better state")
                    selected = states[best_step]
                    _equal(proof["best_state_dict"], selected["state_dict"], "saved selected parameter state")
                    _restore_model(model, selected["snapshot"])
                    with torch.no_grad():
                        rebuilt_best, _, _, _ = _forward(ctx, model, inputs, selected["snapshot"]["rng"])
                    replays += 1
                    _equal(rebuilt_best, proof["trajectory"], "independent saved best-state replay")
                    rebuilt_error = _trajectory(ctx, proof["trajectory"], inputs)["mse"]
                    _require(rebuilt_error == best_error, "Best error was not evaluated with its own parameters")
                    controls = _pt(ctx, directory / f"best_controls_at_{k:04d}.pt", directory)
                    _equal(controls, torch.stack([u["applied"] for u in rebuilt_best["updates"][:32]]),
                           "saved dual-date feasible control table")
                    _require(controls.shape == (32, 100) and bool(((controls >= lower) & (controls <= upper)).all()),
                             "Saved successful control table is infeasible")
                    with torch.no_grad():
                        imported, _, _, _ = _forward(ctx, _controls(ctx, controls), inputs, proof["rng"])
                    replays += 1
                    _equal(imported, proof["imported"], "independent saved feasible-table import replay")
                    # Network proposals can exceed their hard bounds.  Their
                    # applied controls, windows, predictions and ledgers agree.
                    for first, second in zip(imported["predictions"], rebuilt_best["predictions"], strict=True):
                        _equal(first, second, "network/table identical controlled predictions")
                    _equal(imported["ledgers"], rebuilt_best["ledgers"], "network/table overwrite equality")
                    _equal(imported["loss"], rebuilt_best["loss"], "network/table pure objective equality")
                    saved_predictions = _npy(ctx, directory / f"best_replay_at_{k:04d}.npy", directory, (33,))
                    _equal(saved_predictions, np.asarray([float(p["tensor"]) for p in rebuilt_best["predictions"]]),
                           "saved best replay prediction bytes")
                    achieved = errors[0] > .0001 and best_error <= .0001 and 1. - best_error / errors[0] >= .99
                    _require(status["best_replay"] == {"mse": best_error, "achieved": achieved,
                                                      "initial_already_satisfied": errors[0] <= .0001},
                             "Absolute/relative fitting gate differs")
                    _require(not achieved or k == last, "Optimization continued after a verified success checkpoint")
                if k < last:
                    _restore_model(model, state["snapshot"])
                    optimizer.load_state_dict(state["optimizer"])
                    for parameter, gradient in zip(model.parameters(), gradients, strict=True):
                        parameter.grad = gradient.detach().clone()
                    _tick(ctx)
                    optimizer.step()
                    update = _pt(ctx, directory / f"update_{k+1:04d}_before_projection.pt", directory)
                    _require(update["updates_completed"] == k + 1, "Post-update state has a wrong completed count")
                    _equal(update["before_state_dict"], state["state_dict"], "raw pre-update parameters")
                    rebuilt_state = {name: tensor.detach().cpu().clone() for name, tensor in model.state_dict().items()}
                    _equal(update["state_dict"], rebuilt_state, "independent Adam updated parameters")
                    _equal(update["optimizer"], copy.deepcopy(optimizer.state_dict()), "independent Adam updated moments")
                    if seed is None:
                        projection = _pt(ctx, directory / f"projection_{k+1:04d}.pt", directory)
                        _require(projection["update"] == k + 1, "Direct projection has a wrong update number")
                        _equal(projection["before_projection"], rebuilt_state["controls"], "raw pre-projection controls")
                        with torch.no_grad():
                            model.controls.copy_(torch.maximum(lower.to(ctx.device),
                                                               torch.minimum(model.controls, upper.to(ctx.device))))
                        _equal(projection["after_projection"], model.controls.detach().cpu(), "independent direct projection")
                    following = _pt(ctx, directory / f"state_{k+1:04d}.pt", directory)
                    _equal(following["state_dict"], {name: value.detach().cpu() for name, value in model.state_dict().items()},
                           "state k+1 follows exactly one update/projection")
                    _equal(following["optimizer"], copy.deepcopy(optimizer.state_dict()), "state k+1 optimizer moments")
                    change = _read_json(_safe(directory / f"parameter_change_{k+1:04d}.json", directory))
                    maximum = max(float((following["state_dict"][n] - v).abs().max())
                                  for n, v in state["state_dict"].items())
                    _require(change == {"from_step": k, "to_step": k + 1, "absolute_max": maximum},
                             "Raw parameter update magnitude differs")
                    updates_verified += 1
            _require(run["initial_mse"] == errors[0] and run["last_mse"] == errors[-1] and
                     run["best_mse"] == best_error and run["best_step"] == best_step,
                     "Final current/best/last summary differs from actual evaluated states")
            _require(errors[0] > .0001 and run["initial_already_satisfied"] is False,
                     "An already-satisfied zero baseline cannot become a learning-success claim")
            gate = best_error <= .0001 and 1. - best_error / errors[0] >= .99
            _require(run["fit_gate_pass"] is gate and (gate or last == 1000),
                     "Run stopped early without success or exceeded its finite-step search rule")
            best_file = _pt(ctx, directory / "best.pt", directory)
            _require(best_file["updates_completed"] == best_step and best_file["mse"] == best_error,
                     "Final selected checkpoint step/error differs")
            _equal(best_file["state_dict"], states[best_step]["state_dict"], "final selected checkpoint parameters")
            initial_predictions = _npy(ctx, directory / "initial_predictions.npy", directory, (33,))
            _equal(initial_predictions, np.asarray([float(p["tensor"]) for p in states[0]["trajectory"]["predictions"]]),
                   "initial prediction record")
            if seed is None:
                zero = _pt(ctx, directory / "zero_network_baseline.pt", directory)
                original_network = _network(ctx, 1001)
                _equal(zero["state_dict"], {n: t.detach().cpu() for n, t in original_network.state_dict().items()},
                       "original zero-output network identity")
                with torch.no_grad():
                    rebuilt_zero, _, _, _ = _forward(ctx, original_network, inputs)
                replays += 1
                _equal(zero["trajectory"], rebuilt_zero, "independent original zero-network baseline replay")
                _equal(rebuilt_zero, states[0]["trajectory"], "zero controls versus original zero network")
            else:
                direct_root = _safe(FAMILY / PHASE_ROOTS[3], FAMILY)
                baseline = _npy(ctx, direct_root / "control/initial_predictions.npy", direct_root, (33,))
                _equal(initial_predictions, baseline, "all formal network starts versus direct zero baseline")
            after = _pt(ctx, directory / "hydro_after.pt", directory)
            _equal(after["frozen_after"], bound["frozen_before"], "saved frozen hydrology optimization invariance")
            _equal(after["modes"], bound["hydro_modes"], "saved frozen module-mode optimization invariance")
            reports.append({"seed": seed, "updates_completed_verified": last, "evaluated_states_verified": last + 1,
                            "independent_replay_checkpoints": checkpoints, "initial_mse": errors[0],
                            "last_mse": errors[-1], "selected_step": best_step, "selected_mse": best_error,
                            "fit_gate_pass": gate, "zero_baseline_strict_equal": True,
                            "all_updates_rebuilt": True, "feasible_controls_replayed": True,
                            "claim_scope": "existence_in_this_fixed_training_window_only" if gate else
                            "finite_optimizer_search_did_not_find_the_registered_fit"})
        _equal(frozen_before, _frozen(ctx), "independent optimization audit frozen invariance")
        _require(result["fit_gate_pass_count"] == sum(x["fit_gate_pass"] for x in reports),
                 "Overall passing-seed count differs")
        return {"independent_checks_passed": True, "model_inference_by_auditor": True,
                "independent_model_replays": replays, "optimizer_updates_independently_rebuilt": updates_verified,
                "audited_runs": reports, "frozen_invariance": frozen_before,
                "scientific_fit_or_forecast_claim": False,
                "no_fit_failure_implies_mathematical_unreachability": False}
    finally:
        _restore_rng(outer_rng)
        _equal(outer_rng, _rng(), "independent optimization audit random-state restoration")
