"""Generate a bounded inventory command that omits only certified pytest scratch.

The original transport helper remains byte-for-byte unchanged. No network,
model, compression, real observations or remote execution occurs in this CLI.
"""

import argparse
import ast
import hashlib
import inspect
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import stat

import eight_basin_results_transport_v01 as transport


TRANSPORT_SHA256 = "ee095ba61daccf73f30eeb6b2b923ba8706762eee3ed523e399bdbd78d50b051"
EXCLUSION_TECHNICAL_GATE_SHA256 = None
SCRATCH_RELATIVE = "runtime/synthetic/synthetic_tmp"


def scratch_exclusion(root, technical_sha256):
    """Describe test-only links without following them or reading fixture bytes."""
    scratch = root / SCRATCH_RELATIVE
    candidate = root
    for part in SCRATCH_RELATIVE.split("/"):
        candidate = candidate / part
        try:
            info = candidate.lstat()
        except FileNotFoundError:
            return None
        if transport._is_link(candidate) or not stat.S_ISDIR(info.st_mode):
            raise PermissionError("The scratch root or its ancestor is linked or non-directory")
    raw = transport.read_bounded(root, "runtime/synthetic/technical_gate.json")
    if not re.fullmatch(r"[0-9a-f]{64}", technical_sha256 or "") or transport.digest(raw) != technical_sha256:
        raise PermissionError("Scratch exclusion lacks its fixed successful technical certificate")
    gate = transport.parse_json(raw)
    command = gate.get("command")
    if (gate.get("success") is not True or gate.get("kind") != "synthetic" or
            not isinstance(command, list) or command.count("--basetemp") != 1):
        raise PermissionError("Only the successful synthetic test certificate may authorize scratch omission")
    position = command.index("--basetemp")
    if position + 1 >= len(command) or not isinstance(command[position + 1], str):
        raise PermissionError("Missing certified pytest scratch path")
    pytest_root = command[position + 1]
    prefix = scratch.as_posix() + "/"
    if (not pytest_root.startswith(prefix) or PurePosixPath(pytest_root).as_posix() != pytest_root or
            not re.fullmatch(r"eight_[0-9a-f]{32}/pytest", pytest_root[len(prefix):])):
        raise PermissionError("Synthetic scratch path is outside the exact certified subtree")
    before = transport.file_stat(scratch)
    links, entries = [], 0
    for current, directories, files in os.walk(scratch, topdown=True, followlinks=False):
        for name in directories + files:
            path = Path(current) / name
            entries += 1
            if entries > 50000:
                raise RuntimeError("Synthetic scratch metadata limit exceeded")
            if transport._is_link(path):
                if len(links) >= 256:
                    raise RuntimeError("Synthetic scratch link metadata limit exceeded")
                links.append({"path": transport.display_path(path).relative_to(root).as_posix(),
                              "target": os.readlink(path), "lstat_mode": path.lstat().st_mode})
        directories[:] = [name for name in directories if not transport._is_link(Path(current) / name)]
    if transport.file_stat(scratch) != before:
        raise RuntimeError("Synthetic scratch root changed during metadata enumeration")
    return {"path": SCRATCH_RELATIVE, "reason": "Certified synthetic pytest scratch; no fixture bytes recovered",
            "technical_gate_sha256": technical_sha256, "pytest_basetemp": pytest_root,
            "stat": before, "entries_metadata_only": entries, "links": links, "links_followed": False}


def artifact_members(root, technical_sha256):
    exclusion = scratch_exclusion(root, technical_sha256)
    names = {"submission_receipt.txt"}
    scratch = root / SCRATCH_RELATIVE
    for directory in ("runtime", "logs"):
        base = transport.no_link_ancestors(root / directory)
        if not base.exists():
            continue
        for current, directories, files in os.walk(base, topdown=True, followlinks=False):
            retained = []
            for name in directories:
                path = Path(current) / name
                if transport.display_path(path) == scratch and exclusion is not None:
                    continue
                if transport._is_link(path):
                    raise PermissionError("Result inventory contains a linked directory: " + str(transport.display_path(path).relative_to(root)))
                retained.append(name)
            directories[:] = retained
            for name in files:
                path = Path(current) / name
                if transport._is_link(path):
                    raise PermissionError("Result inventory contains a linked file: " + str(transport.display_path(path).relative_to(root)))
                if path.is_file():
                    names.add(transport.display_path(path).relative_to(root).as_posix())
    return names, [exclusion] if exclusion is not None else []


def inventory_v02(root, job_id, job_record=None, allow_incomplete=False):
    root = transport.remote_root(root)
    if type(job_id) is not int or job_id <= 0:
        raise ValueError("An explicit positive job identifier is required")
    job = transport.accounting(job_id) if job_record is None else job_record
    if job["job_id"] != job_id or job["state"].split()[0] not in {
            "COMPLETED", "FAILED", "CANCELLED", "TIMEOUT", "OUT_OF_MEMORY", "NODE_FAIL", "PREEMPTED"}:
        raise PermissionError("The job has no matching terminal state")
    receipt = transport.read_bounded(root, "submission_receipt.txt").decode("utf-8").strip()
    if receipt not in (str(job_id), "Submitted batch job " + str(job_id)):
        raise PermissionError("Submission receipt does not bind this job")
    finished = (root / "runtime/job_complete.json").is_file() and transport.read_metadata(
        root, "runtime/job_complete.json").get("success") is True
    if not finished and not allow_incomplete:
        raise PermissionError("The full job did not complete; use explicit incomplete preservation")
    names, exclusions = artifact_members(root, EXCLUSION_TECHNICAL_GATE_SHA256)
    controls = ("submission.slurm", "offline_acceptance.json", "payload/bundle_manifest.json",
                "payload/manifest.sha256", "payload/source_manifest.json", "payload/records/roster_locked.json",
                "payload/records/budget_snapshot.json",
                "payload/code/src/precip_input_assimilation/configs/dynamic_filter_eight_basins_v01.json",
                "payload/code/docs/plans/2026-10-03-precip-dynamic-neural-filter-eight-basin-plan-v0.2.md",
                "payload/code/docs/plans/2026-10-03-precip-dynamic-neural-filter-eight-basin-roster-v0.1.json")
    names.update(name for name in controls if (root / name).exists())
    bindings = transport.source_bindings(root)
    files = {name: dict(transport.file_stat(transport.safe_path(root, name)), source_binding=bindings.get(name))
             for name in sorted(names)}
    counts = {"predictions": sum(name.startswith("runtime/scoring/basins/") and name.endswith("/predictions.csv") for name in files),
              "rain_ledgers": sum(name.startswith("runtime/scoring/basins/") and name.endswith("/rain_versions.csv") for name in files),
              "selected_checkpoints": sum(name.startswith("runtime/training/basins/") and name.endswith("/selected.pt") for name in files)}
    full = finished and job["state"] == "COMPLETED" and job["exit_code"] == "0:0" and counts == {
        "predictions": 88, "rain_ledgers": 48, "selected_checkpoints": 72}
    if not full and not allow_incomplete:
        raise RuntimeError("The required 88 trajectories, 48 rain ledgers and 72 selections are incomplete")
    value = {"schema": transport.SCHEMA, "kind": "inventory", "root": root.as_posix(), "job": job,
             "expected_file_counts_complete": full, "science_verified": False, "counts": counts, "files": files,
             "unbound_files": [name for name, item in files.items() if item["source_binding"] is None],
             "binding_limit": "Stage manifests do not bind all result-file SHA256 values. Unbound files have transport integrity only and require independent scientific reconstruction.",
             "local_path_mapping": {"logical_training_root": (root / "runtime/training").as_posix(),
                                    "local_training_root_relative": "runtime/training"},
             "excluded_subtrees": exclusions}
    value["inventory_sha256"] = transport.digest(transport.canonical(value))
    if any(transport.file_stat(transport.safe_path(root, name)) != {key: info[key] for key in (
            "bytes", "mtime_ns", "ctime_ns", "device", "inode")} for name, info in files.items()):
        raise RuntimeError("Source stat changed during inventory; preserve evidence and stop")
    return value


def build_command(root, job_id, python, technical_sha256):
    transport.registered_root_name(root)
    if type(job_id) is not int or job_id <= 0 or not re.fullmatch(r"[0-9a-f]{64}", technical_sha256):
        raise ValueError("Positive job and fixed technical certificate SHA256 are required")
    if (not re.fullmatch(r"/[A-Za-z0-9_./-]+", python) or PurePosixPath(python).as_posix() != python or
            any(part in ("", ".", "..") for part in python.split("/")[1:])):
        raise ValueError("Explicit canonical remote Python required")
    source_path = Path(transport.__file__)
    raw = source_path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != TRANSPORT_SHA256:
        raise PermissionError("The pinned original transport helper changed")
    source = raw.decode("utf-8").replace("\r\n", "\n")
    tree = ast.parse(source)
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "inventory"]
    guards = [node for node in tree.body if isinstance(node, ast.If) and ast.unparse(node.test) == "__name__ == '__main__'"]
    if len(functions) != 1 or len(guards) != 1 or tree.body[-1] is not guards[0]:
        raise PermissionError("The original helper shape changed")
    lines = source.splitlines(keepends=True)
    function, guard = functions[0], guards[0]
    additions = ("\n" + inspect.getsource(scratch_exclusion) + "\n" + inspect.getsource(artifact_members) + "\n").replace("transport.", "")
    replacement = inspect.getsource(inventory_v02).replace("def inventory_v02(", "def inventory(", 1).replace("transport.", "")
    body = "".join(lines[:function.lineno - 1]) + additions + replacement + "".join(lines[function.end_lineno:guard.lineno - 1])
    # The injected functions share the exact checked helper namespace.
    preamble = ("import sys, re\nfrom pathlib import PurePosixPath\n"
                "EXCLUSION_TECHNICAL_GATE_SHA256 = " + repr(technical_sha256) + "\n"
                "SCRATCH_RELATIVE = " + repr(SCRATCH_RELATIVE) + "\n")
    request = {"root": root, "job_id": job_id, "allow_incomplete": False}
    import base64
    encoded = base64.b64encode(transport.canonical(request)).decode()
    preamble += "sys.argv = " + repr(["eight_basin_inventory_v02", "inventory-remote", "--request", encoded]) + "\n"
    script = preamble + body + "\nmain()\n"
    compile(script, "eight_basin_inventory_v02_remote", "exec")
    return "#!/usr/bin/env bash\nset -euo pipefail\n" + shlex.join([python, "-B", "-"]) + " <<'EIGHT_INVENTORY_V02'\n" + script + "EIGHT_INVENTORY_V02\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True)
    parser.add_argument("--job-id", required=True, type=int)
    parser.add_argument("--python", required=True)
    parser.add_argument("--technical-record-sha256", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    transport.immutable_bytes(args.output, build_command(args.root, args.job_id, args.python,
                                                       args.technical_record_sha256).encode())


if __name__ == "__main__":
    main()
