"""Sequential direct controls and predeclared seed1001; no forecast evaluation."""
import argparse
import json
from pathlib import Path
import sys
import traceback

from precip_input_assimilation.hpc.precip_smallfit_runtime_v01 import RuntimeClient, sha, validate_exploration, write_json


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", required=True, type=Path)
    p.add_argument("--manifest-sha256", required=True)
    a = p.parse_args()
    root = a.root.resolve()
    path = root / "payload/manifest.json"
    if sha(path) != a.manifest_sha256:
        raise PermissionError("Approved payload manifest changed")
    manifest = json.loads(path.read_text())
    client = RuntimeClient(root, manifest["nonce"])
    try:
        client.checkpoint(full=True)
        audit_path = root / "payload" / manifest["saved_sources"]["completed_audit"]["path"]
        admission = validate_exploration(json.loads(audit_path.read_text()))
        write_json(root / "runtime/exploratory_admission.json", admission)
        # The parent has reserved the original remaining budget before the
        # first numerical import, including environment checks and test work.
        from precip_input_assimilation.small_sample.hpc_saved_context_v01 import create_context
        from precip_input_assimilation.small_sample.fit_v04 import optimize
        from precip_input_assimilation.small_sample.hpc_fit_audit_v01 import audit_fit_stage
        recipe = manifest["recipe"]
        previous = None
        reports = []
        for stage in ("direct_control", "network"):
            output = root / "runtime" / stage
            output.mkdir()
            ctx = create_context(root, manifest, client, output, stage)
            if previous is not None:
                ctx.direct_control_output = root / "runtime/direct_control"
                ctx.direct_control_artifacts = previous["fit_raw_artifacts"]
            print("STAGE_BEGIN " + stage, flush=True)
            result = optimize(ctx, recipe, stage)
            write_json(output / "stage_result.json", result)
            if not result["execution_complete"]:
                raise RuntimeError("Fitting ended without the declared complete algorithm path")
            check = audit_fit_stage(ctx, result)
            write_json(output / "independent_fit_audit.json", check)
            if check.get("pass") is not True:
                raise RuntimeError("Saved fitting states failed the independent reconstruction")
            previous = result
            reports.append({"stage": stage, "runs": result["runs"], "audit_pass": True,
                            "audit_sha256": sha(output / "independent_fit_audit.json")})
            print("STAGE_COMPLETE " + stage, flush=True)
            if result["window_uninformative"]:
                break
        client.checkpoint(full=True)
        write_json(root / "runtime/fit_execution_complete.json", {
            "execution_complete": True, "seed_scope": [1001], "stages": reports,
            "formal_forecast_improvement_established": False, "original_full_gradient_gate": False,
            "original_three_negative_decisions_preserved": True, "counter_snapshot": client.counter_snapshot()})
    except BaseException as error:
        write_json(root / "runtime/worker_failure.json", {"type": type(error).__name__, "error": str(error),
                                                       "traceback": traceback.format_exc(), "fit_or_forecast_claim": False})
        raise
    finally:
        client.connection.close()


if __name__ == "__main__":
    main()
