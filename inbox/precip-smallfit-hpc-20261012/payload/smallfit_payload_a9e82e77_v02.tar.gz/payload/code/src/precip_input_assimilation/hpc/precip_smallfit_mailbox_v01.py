"""Task-owned mailbox publication and exact Git-blob receipts; no scientific imports."""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import re
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynamic_filter_mailbox import Mailbox

CHANNEL = "precip-smallfit-hpc-20261012"
BRANCH = "hpc-mailbox"


def verified_text(box, path, head, missing=False):
    item = box.api("contents/" + path + "?ref=" + head, missing=missing)
    if item is None:
        return None
    if item.get("encoding") != "base64":
        item = box.api("git/blobs/" + item["sha"])
    raw = base64.b64decode("".join(item["content"].split()), validate=True)
    if len(raw) != item["size"] or hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest() != item["sha"]:
        raise RuntimeError("Receipt bytes do not match the fixed Git object")
    return raw


def publish(box, sequence, command, archive=None):
    encoded = Path(command).read_bytes()
    if b"\r" in encoded:
        raise ValueError("Mailbox command needs LF line endings")
    digest = hashlib.sha256(encoded).hexdigest()
    head = box.api("git/ref/heads/" + BRANCH)["object"]["sha"]
    if not re.fullmatch("[0-9a-f]{40}", head):
        raise RuntimeError("Invalid fixed mailbox head")
    seq = verified_text(box, "inbox/" + CHANNEL + "/seq", head, missing=True)
    previous = 0 if seq is None else int(seq.strip())
    if previous == sequence:
        saved = verified_text(box, "inbox/" + CHANNEL + "/cmd.sh", head)
        if hashlib.sha256(saved).hexdigest() != digest:
            raise RuntimeError("Sequence belongs to a different command")
        return {"sequence": sequence, "commit": head, "command_sha256": digest, "already_published": True}
    if previous != sequence - 1:
        raise RuntimeError("Unexpected owned-channel sequence")
    entries = []
    if previous:
        receipt = verified_text(box, "outbox/" + CHANNEL + "/result_" + str(previous) + ".txt", head, missing=True)
        if receipt is None or not re.search(rb"### ---------- end ----------\r?\n### exit_code=-?[0-9]+\r?\n### finished=[^\r\n]+\r?\n?\Z", receipt):
            raise RuntimeError("Previous owned command has no complete receipt")
    else:
        registry = verified_text(box, "CHANNELS.md", head).decode()
        if CHANNEL in registry or seq is not None:
            raise RuntimeError("New owned channel is occupied")
        registry = registry.rstrip() + "\n\n| " + CHANNEL + " | Precipitation direct controls and seed1001 fitting | 2026-10-14 | Isolated precip_smallfit_hpc_20261012_v01 root; preserve all existing jobs and shared environments |\n"
        entries.append({"path": "CHANNELS.md", "mode": "100644", "type": "blob", "content": registry})
    entries += [{"path": "inbox/" + CHANNEL + "/cmd.sh", "mode": "100755", "type": "blob", "content": encoded.decode()},
                {"path": "inbox/" + CHANNEL + "/seq", "mode": "100644", "type": "blob", "content": str(sequence)}]
    if archive:
        archive = Path(archive)
        if not re.fullmatch("[A-Za-z0-9_.-]+", archive.name):
            raise ValueError("Unsafe archive name")
        raw = archive.read_bytes()
        blob = box.api("git/blobs", "POST", {"encoding": "base64", "content": base64.b64encode(raw).decode()})
        expected = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        if blob["sha"] != expected:
            raise RuntimeError("Uploaded payload object differs")
        entries.append({"path": "inbox/" + CHANNEL + "/payload/" + archive.name, "mode": "100644", "type": "blob", "sha": expected})
    commit = box.api("git/commits/" + head)
    tree = box.api("git/trees", "POST", {"base_tree": commit["tree"]["sha"], "tree": entries})
    proposed = box.api("git/commits", "POST", {"message": "Run: " + CHANNEL + " seq=" + str(sequence), "tree": tree["sha"], "parents": [head]})
    # A failed/uncertain PATCH is inspected with this exact command and sequence,
    # never automatically repeated and never force-pushed.
    box.api("git/refs/heads/" + BRANCH, "PATCH", {"sha": proposed["sha"], "force": False})
    return {"sequence": sequence, "commit": proposed["sha"], "parent": head, "command_sha256": digest, "already_published": False}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("mode", choices=("publish", "read"))
    p.add_argument("--sequence", required=True, type=int)
    p.add_argument("--command", type=Path)
    p.add_argument("--archive", type=Path)
    p.add_argument("--output", required=True, type=Path)
    a = p.parse_args()
    box = Mailbox()
    if a.mode == "publish":
        result = publish(box, a.sequence, a.command, a.archive)
        with a.output.open("x", encoding="utf-8", newline="\n") as f:
            json.dump(result, f, indent=2)
    else:
        head = box.api("git/ref/heads/" + BRANCH)["object"]["sha"]
        raw = verified_text(box, "outbox/" + CHANNEL + "/result_" + str(a.sequence) + ".txt", head, missing=True)
        if raw is None:
            print(json.dumps({"pending": True, "sequence": a.sequence}))
            return
        with a.output.open("xb") as f:
            f.write(raw)
        result = {"sequence": a.sequence, "commit": head, "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw), "receipt": str(a.output)}
    print(json.dumps(result))


if __name__ == "__main__":
    main()
