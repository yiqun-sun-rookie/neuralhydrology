"""Source-gated saved-input context for the reviewed local derivative protocol.

Nothing runs on import.  The caller must hold the family lock and an active,
settled-predecessor budget reservation before calling any numerical function.
Original input files and fit-only scaling are never re-read or re-fitted here.
"""

from __future__ import annotations

from collections import OrderedDict
import copy
from dataclasses import dataclass
from datetime import date, timedelta
import hashlib
import io
import json
import math
from pathlib import Path
import stat
import time

import numpy as np
import torch

from . import support_v01 as support


REPO = support.REPO
FAMILY = support.original.TRIAL_ROOT
OLD_ROOT = FAMILY / "small_sample_gradient_20261010_v01"
SOURCE_CONFIG = REPO / "src/precip_input_assimilation/configs/precip_saved_gradient_boundaries_v01.json"
SOURCE_CONFIG_SHA = "4165be37e56dfd8938d5c2bd0ea0493a00a7dfa194bd1dfe5563ae689ce2ac6f"
CONTEXT_SHA = "195a66041565ae7e7cec3869e66059eb8c924ded011b4b0d8ab4dd69fff6383c"
GATE_SHA = "4df8bd151ce8b4dacbe4223b4eb320edf28e66346504bcfa694a97f50946cb5a"
SCALING_SHA = "817a24d91019419b794825003c64f652a6ee1f3670348a4a79b307d5a8c81c09"
GRADIENT_SHA = "83792e6e0030f164dab78123f31affdedb5f5b74b52e770cc710410af8bde700"
WARM_DATES = tuple(date(1980, 1, 1) + timedelta(days=i) for i in range(274))
SMALL_DATES = tuple(date(1980, 10, 1) + timedelta(days=i) for i in range(33))


def guarded_existing(path, root):
    """Reject lexical escape, worktrees, symlinks and Windows reparse points."""
    path, root = Path(path), Path(root)
    if ".." in path.parts or ".." in root.parts:
        raise PermissionError("Parent traversal is not an admitted saved path")
    path, root = path.absolute(), root.absolute()
    if any(part.casefold() == ".worktrees" for candidate in (path, root) for part in candidate.parts):
        raise PermissionError("Worktree evidence is forbidden")
    if not path.is_relative_to(root):
        raise PermissionError("Saved source is outside its lexical root")
    # Check each existing ancestor before resolve/open; a junction inside the
    # root must not redirect even to another currently admitted source.
    for candidate in (path, *path.parents, root, *root.parents):
        info = candidate.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise PermissionError("Linked or reparse source is forbidden")
    resolved, resolved_root = path.resolve(strict=True), root.resolve(strict=True)
    if resolved != path or resolved_root != root or not resolved.is_relative_to(resolved_root):
        raise PermissionError("Resolved saved source differs from its admitted deployment")
    return resolved


def _bound_json(path, identity, root=REPO):
    path = guarded_existing(path, root)
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != identity:
        raise PermissionError(f"Source bytes differ: {path}")
    return json.loads(raw)


def require_date_provenance(gate, context, manifest):
    """Only pinned metadata, before any saved tensor is deserialized."""
    if gate.get("basin") != "01487000" or gate.get("pass") is not True:
        raise PermissionError("Saved input provenance has no original admitted basin")
    if context.get("score_numeric_reads_started") is not False or manifest.get("score_numeric_reads_allowed") is not False:
        raise PermissionError("Saved provenance permits scoring reads")
    if context.get("input_gate_sha256") != GATE_SHA or context.get("runtime") != manifest.get("runtime"):
        raise PermissionError("Saved gate/runtime provenance changed")
    expected = {"warmup": ("1980-01-01", "1980-09-30", 274),
                "fit": ("1980-10-01", "1984-09-30", 1461),
                "select": ("1984-10-01", "1985-09-30", 365)}
    canonical = gate.get("canonical_inputs", {})
    if set(canonical) != {"weather", "flow"}:
        raise PermissionError("Unexpected input provenance classes")
    for kind in ("weather", "flow"):
        segments = canonical[kind]
        permitted = set(expected) if kind == "weather" else {"fit", "select"}
        if set(segments) != permitted:
            raise PermissionError("Saved source has an unregistered date segment")
        for phase, row in segments.items():
            if (row.get("start"), row.get("end"), row.get("days")) != expected[phase]:
                raise PermissionError("Saved source date range differs before tensor loading")
            if date.fromisoformat(row["end"]) > date(1985, 9, 30):
                raise PermissionError("Forbidden saved input dates")
    scaling = context.get("scaling", {})
    if (scaling.get("start"), scaling.get("end")) != expected["fit"][:2]:
        raise PermissionError("Scaling was not bound to the original fitting dates")
    if scaling.get("cap") != 32.21650314331055:
        raise PermissionError("Original rainfall cap changed")


class OriginalProofRegistry:
    """Only the immutable 60-file registry can grant a tensor read."""

    def __init__(self):
        self.config = _bound_json(SOURCE_CONFIG, SOURCE_CONFIG_SHA)
        if self.config.get("schema") != "precip_saved_gradient_boundaries_config_v01":
            raise PermissionError("Unknown saved-source registry")
        if Path(self.config["source_gradient_root"]).absolute() != OLD_ROOT.absolute():
            raise PermissionError("Original proof root was substituted")
        self.context = _bound_json(OLD_ROOT / "context_identity.json", CONTEXT_SHA)
        self.gate = _bound_json(OLD_ROOT / "input_gate.json", GATE_SHA)
        self.manifest = _bound_json(OLD_ROOT / "manifest.json",
                                  self.config["auxiliary_identity"][str(OLD_ROOT / "manifest.json")])
        require_date_provenance(self.gate, self.context, self.manifest)
        self.result = _bound_json(OLD_ROOT / "gradient_result.json", GRADIENT_SHA)
        artifacts = self.config["raw_artifacts"]
        if len(artifacts) != 60 or artifacts != self.result["artifacts"]:
            raise PermissionError("The original complete saved artifact registry changed")
        self.allowed = {str(Path(item["path"]).absolute()): item for item in artifacts}
        if len(self.allowed) != 60:
            raise PermissionError("Duplicate saved artifacts")
        self.identity = {"registry_sha256": SOURCE_CONFIG_SHA, "gradient_result_sha256": GRADIENT_SHA,
                         "context_identity_sha256": CONTEXT_SHA, "input_gate_sha256": GATE_SHA,
                         "loaded_proofs": []}

    def load(self, item):
        # The supplied path/hash/length alone never grants permission. It must
        # be exactly a member of the complete immutable registry.
        key = str(Path(item["path"]).absolute())
        if item != self.allowed.get(key):
            raise PermissionError("Proof is not an exact member of the original accepted registry")
        current_context = _bound_json(OLD_ROOT / "context_identity.json", CONTEXT_SHA)
        current_gate = _bound_json(OLD_ROOT / "input_gate.json", GATE_SHA)
        require_date_provenance(current_gate, current_context, self.manifest)
        path = guarded_existing(item["path"], OLD_ROOT / "gradient_proofs")
        # Capture immutable bytes once, then hash and deserialize that exact
        # buffer. Reusing a live file handle would still permit an external
        # in-place writer to change its content between hash and deserialization.
        with path.open("rb") as handle:
            raw = handle.read()
        if hashlib.sha256(raw).hexdigest() != item["sha256"] or len(raw) != item["bytes"]:
            raise PermissionError("Original saved proof bytes/length changed")
        value = torch.load(io.BytesIO(raw), map_location="cpu", weights_only=True)
        # The buffer was admitted before loading; a concurrent source change
        # still must stop before any reconstructed value reaches its caller.
        if support.sha256(guarded_existing(path, OLD_ROOT / "gradient_proofs")) != item["sha256"]:
            raise PermissionError("Original saved source changed during tensor loading")
        self.identity["loaded_proofs"].append(dict(item))
        return value


def safe_load_original_proof(item):
    return OriginalProofRegistry().load(item)


def decode_numpy_wrappers(value):
    """Restore the original typed RNG array wrapper without pickle evaluation."""
    if isinstance(value, dict):
        if set(value) == {"numpy_dtype", "shape", "bytes_hex"}:
            dtype = np.dtype(value["numpy_dtype"])
            if dtype.hasobject or dtype.fields is not None:
                raise PermissionError("Unsafe NumPy wrapper dtype")
            shape = value["shape"]
            if not isinstance(shape, list) or any(type(n) is not int or n < 0 for n in shape):
                raise PermissionError("Invalid typed NumPy wrapper shape")
            size = math.prod(shape) * dtype.itemsize
            raw = bytes.fromhex(value["bytes_hex"])
            if len(raw) != size:
                raise PermissionError("Typed NumPy wrapper has a different byte count")
            return np.frombuffer(raw, dtype=dtype).reshape(shape).copy()
        if "numpy_dtype" in value or "bytes_hex" in value:
            raise PermissionError("Malformed typed NumPy wrapper")
        return {key: decode_numpy_wrappers(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return type(value)(decode_numpy_wrappers(item) for item in value)
    return value


def _equal(left, right):
    if isinstance(left, dict) and isinstance(right, dict):
        # The old proof serializer converted OrderedDict to ordinary dict while
        # retaining its insertion order; these are the same saved state mapping.
        return list(left) == list(right) and all(_equal(left[key], right[key]) for key in left)
    if type(left) is not type(right):
        return False
    if isinstance(left, torch.Tensor):
        return left.dtype == right.dtype and left.shape == right.shape and torch.equal(left, right)
    if isinstance(left, np.ndarray):
        return left.dtype == right.dtype and left.shape == right.shape and np.array_equal(left, right)
    if isinstance(left, (tuple, list)):
        return len(left) == len(right) and all(_equal(a, b) for a, b in zip(left, right))
    return left == right


def load_saved_sources():
    """Resolve recorded labels, not file-number guesses; never run a model."""
    registry = OriginalProofRegistry()
    result = registry.result
    records = result["completed_records"]
    def unique(label):
        found = [row for row in records if row["label"] == label]
        if len(found) != 1:
            raise PermissionError(f"Expected one original recorded event: {label}")
        return found[0]
    # These labels are original recorder labels; each resolved member must also
    # occur in the fixed whole-artifact registry.
    by_label = {}
    for label in ("bound_inputs", "frozen_before"):
        found = [row for row in result["artifacts"] if Path(row["path"]).stem.split("_", 1)[-1] == label]
        if len(found) != 1:
            raise PermissionError(f"Missing exact original artifact label {label}")
        by_label[label] = registry.load(found[0])
    adapter = registry.load(unique("nonzero_adapter")["proof"])
    groups, directions, bases = {}, {}, {}
    for group in ("output_parameters", "encoder_parameters"):
        rows = [row for row in records if row["label"] == "parameter_direction" and row["group"] == group]
        if len(rows) != 3 or [row["direction_index"] for row in rows] != [0, 1, 2]:
            raise PermissionError("Original direction registration changed")
        if any(row["base_proof"] != rows[0]["base_proof"] for row in rows):
            raise PermissionError("A parameter group does not share its original base")
        base = registry.load(rows[0]["base_proof"])
        bases[group] = base
        groups[group] = {"names": base["sorted_parameter_names"], "sizes": base["sizes"],
                         "gradients": base["gradients"]}
        directions[group] = []
        for row in rows:
            saved = [registry.load(scale["proof"]) for scale in row["scales"]]
            if any(not _equal(saved[0]["direction"], item["direction"]) for item in saved):
                raise PermissionError("A saved original direction changed between scales")
            directions[group].append(saved[0]["direction"])
    snapshot = decode_numpy_wrappers(bases["output_parameters"]["snapshot"])
    if not _equal(snapshot, decode_numpy_wrappers(bases["encoder_parameters"]["snapshot"])) or not _equal(
            bases["output_parameters"]["trajectory"], bases["encoder_parameters"]["trajectory"]):
        raise PermissionError("The two original base snapshots or trajectories differ")
    only_step = decode_numpy_wrappers(registry.load(registry.config["only_step_proof"]))
    restored = decode_numpy_wrappers(registry.load(registry.config["restoration_proof"]))
    if not _equal(snapshot, only_step) or not _equal(snapshot, restored["before"]) or not _equal(snapshot, restored["after"]):
        raise PermissionError("Saved post-step/restoration chain does not bind the exact same point")
    return {"saved_snapshot": snapshot, "saved_base_trajectory": bases["output_parameters"]["trajectory"],
            "saved_group_gradients": groups, "saved_directions": directions,
            "bound_inputs": by_label["bound_inputs"], "frozen_before": by_label["frozen_before"],
            "nonzero_adapter": adapter, "source_identity": registry.identity,
            "original_context": registry.context, "input_gate": registry.gate,
            "original_registry": registry.config}


def restore_original_snapshot(module, value, optimizer=None):
    """Explicitly reconstruct missing grad flags; they were not saved originally."""
    value = decode_numpy_wrappers(value)
    if set(value) != {"state_dict", "modes", "rng", "optimizer"}:
        raise PermissionError("Original snapshot fields changed")
    flags = getattr(module, "_local_constructor_requires_grad_v02", None)
    if flags is None:
        flags = {name: parameter.requires_grad for name, parameter in module.named_parameters()}
        if not flags or not all(flags.values()):
            raise PermissionError("The protected correction constructor must make every parameter trainable")
        module._local_constructor_requires_grad_v02 = dict(flags)
    if set(flags) != {name for name, _ in module.named_parameters()}:
        raise PermissionError("Constructor parameter registration changed")
    support.restore_snapshot(module, value, optimizer)
    for name, parameter in module.named_parameters():
        parameter.requires_grad_(flags[name])
        parameter.grad = None
    if not _equal(support.snapshot(module, optimizer), value):
        raise PermissionError("Original full state/modes/optimizer/RNG was not restored")
    return {"original_did_not_save_grad_or_requires_grad": True,
            "constructor_requires_grad": dict(flags), "all_new_gradients_cleared": True}


def runtime_snapshot(module, optimizer=None):
    value = support.snapshot(module, optimizer)
    value["requires_grad"] = {name: parameter.requires_grad for name, parameter in module.named_parameters()}
    value["gradients"] = {name: None if parameter.grad is None else parameter.grad.detach().cpu().clone()
                          for name, parameter in module.named_parameters()}
    return value


def restore_runtime_snapshot(module, value, optimizer=None):
    value = decode_numpy_wrappers(value)
    if set(value) != {"state_dict", "modes", "rng", "optimizer", "requires_grad", "gradients"}:
        raise PermissionError("New runtime snapshot fields changed")
    base = {key: value[key] for key in ("state_dict", "modes", "rng", "optimizer")}
    support.restore_snapshot(module, base, optimizer)
    named = dict(module.named_parameters())
    if set(named) != set(value["requires_grad"]) or set(named) != set(value["gradients"]):
        raise PermissionError("New gradient binding registration changed")
    for name, parameter in named.items():
        parameter.requires_grad_(value["requires_grad"][name])
        gradient = value["gradients"][name]
        if gradient is not None and (gradient.shape != parameter.shape or gradient.dtype != parameter.dtype):
            raise PermissionError("Saved new gradient shape/type changed")
        parameter.grad = None if gradient is None else gradient.to(parameter.device).clone()
    if not _equal(runtime_snapshot(module, optimizer), value):
        raise PermissionError("New full runtime snapshot was not restored")


@dataclass(frozen=True)
class SavedInputs:
    dates: tuple
    weather: np.ndarray
    observations: np.ndarray

    def weather_for(self, phase):
        if (phase.name, phase.start, phase.end) != ("fit", SMALL_DATES[0], SMALL_DATES[-1]):
            raise PermissionError("Saved context has no admitted values outside its registered 33 days")
        return self.weather[-33:]

    def observations_for(self, phase):
        self.weather_for(phase)
        return self.observations


class FullForwardCounter:
    def __init__(self, context):
        self.context, self.count, self.labels = context, 0, []

    def consume(self, label):
        limit = self.context.full_forward_limit
        if limit is not None and self.count >= limit:
            raise PermissionError("Registered full-window forward limit reached")
        self.count += 1
        self.labels.append(str(label))


class SavedContext(support.Context):
    """Same replay API, with a shared counter for all complete-replay attempts."""

    full_forward_limit = 100

    def __post_init__(self):
        super().__post_init__()
        self.full_forward_counter = FullForwardCounter(self)

    def factory(self, corrector):
        self.check()
        # Each factory creates precisely one fresh full-calendar replay. Partial
        # attempts count too, so an error cannot silently refund its computation.
        self.full_forward_counter.consume(getattr(self, "forward_label", type(corrector).__name__))
        return super().factory(corrector)


def _decode_inputs(bound, adapter):
    if tuple(date.fromisoformat(str(item)) for item in bound["dates"]) != SMALL_DATES:
        raise PermissionError("Saved bound input dates differ")
    if tuple(date.fromisoformat(str(item)) for item in adapter["warmup_dates"]) != WARM_DATES:
        raise PermissionError("Saved warmup calendar differs")
    weather = decode_numpy_wrappers(bound["weather"])
    observations = decode_numpy_wrappers(bound["observations"])
    warm = adapter["warmup_weather"]
    if not isinstance(weather, np.ndarray) or weather.dtype != np.float32 or weather.shape != (33, 5):
        raise PermissionError("Saved diagnostic weather shape/type differs")
    if not isinstance(observations, np.ndarray) or observations.dtype != np.float64 or observations.shape != (33,):
        raise PermissionError("Saved observations shape/type differs")
    if not isinstance(warm, torch.Tensor) or warm.dtype != torch.float32 or warm.shape != (274, 5):
        raise PermissionError("Saved warmup weather shape/type differs")
    if not torch.equal(adapter["warmup_applied"], torch.zeros(274, dtype=torch.float32)):
        raise PermissionError("Saved warmup precipitation ledger is not the original zero state")
    combined = np.concatenate((warm.numpy(), weather), axis=0)
    if not np.isfinite(combined).all() or not np.isfinite(observations).all() or (combined[:, 0] < 0).any():
        raise PermissionError("Saved lawful inputs contain nonfinite values or negative rain")
    combined.setflags(write=False)
    observations = observations.copy()
    observations.setflags(write=False)
    return SavedInputs(WARM_DATES + SMALL_DATES, combined, observations)


def _saved_hydro(contract, gate, expected):
    """Use original model methods with the bound saved static row, no data reader."""
    from ..dynamic_filter_multibasin.hydro import BasinHydro, StaticBinding, STATIC_NAMES, require_model_identity
    from ..dynamic_filter_multibasin.contract import object_sha256
    from ..selfrule.data import load_normalization
    from ..selfrule.model import FrozenC4
    from ..dynamic_filter_multibasin.data import WEATHER_NAMES
    recorded = gate["static_identity"]
    if recorded["basin"] != "01487000" or tuple(recorded["names"]) != STATIC_NAMES or any(recorded["missing"]):
        raise PermissionError("Saved static attribute basin/order/missing mask differs")
    content = {key: recorded[key] for key in ("basin", "names", "raw", "missing", "normalized", "sources")}
    if object_sha256(content) != recorded["sha256"]:
        raise PermissionError("Saved static binding object identity differs")
    cfg, names, center, scale, q_center, q_scale = load_normalization(contract.model_root)
    if tuple(names) != WEATHER_NAMES or cfg.seq_length != 270 or cfg.hidden_size != 256 or tuple(cfg.static_attributes) != STATIC_NAMES:
        raise PermissionError("Frozen model context dimensions/order differ")
    normalized = np.asarray([float(value) for value in recorded["normalized"]], dtype=np.float32)
    if normalized.shape != (27,) or not np.isfinite(normalized).all():
        raise PermissionError("Saved static row is malformed")
    normalized.setflags(write=False)
    # Do not invoke BasinHydro.__init__: its raw-static loader is deliberately
    # excluded from the saved-only context. All retained prediction/state guards
    # are the unchanged original BasinHydro methods.
    hydro = BasinHydro.__new__(BasinHydro)
    hydro.contract, hydro.basin = contract, "01487000"
    hydro.model_identity = require_model_identity(contract)
    if hydro.model_identity != gate["model_identity"]:
        raise PermissionError("Frozen artifact identities differ from original input gate")
    hydro.binding = StaticBinding("01487000", STATIC_NAMES, tuple(float(value) for value in recorded["raw"]),
                                 tuple(recorded["missing"]), normalized, recorded["sha256"], copy.deepcopy(recorded["sources"]))
    if hydro.binding.as_dict() != recorded:
        raise PermissionError("Saved static binding failed exact text/float reconstruction")
    hydro.static_identity = hydro.binding.as_dict()
    hydro.device = torch.device("cuda:0")
    hydro.frozen = FrozenC4(contract.model_root, "cuda:0", names, center, scale, q_center, q_scale)
    hydro.static = torch.tensor(normalized.copy(), dtype=torch.float32, device=hydro.device)
    hydro._static_reference, hydro._static_version = hydro.static, hydro.static._version
    hydro.sequence_length = hydro.frozen.sequence_length
    hydro._initial_state = hydro.state_hash()
    if hydro._initial_state != expected["frozen_state_sha256"]:
        raise PermissionError("Original frozen tensor identity differs")
    support.assert_frozen_mode(hydro, expected["frozen_modes"])
    return hydro


def create_saved_context(output, deadline, require_unchanged):
    """Budget-owned construction equivalent to Context, using saved legal inputs."""
    from ..dynamic_filter_multibasin.contract import Contract, PINNED
    from ..dynamic_filter_multibasin.controller import configure_numerics, numerical_runtime
    from ..dynamic_filter.protocol import Scaling
    output = Path(output)
    if not output.is_dir() or not math.isfinite(deadline) or time.monotonic() >= deadline - 300:
        raise PermissionError("An existing reserved output and active parent deadline are required")
    if (output / "STOP").exists():
        raise InterruptedError("Manual stop remains in force")
    require_unchanged()
    recorded = _bound_json(OLD_ROOT / "context_identity.json", CONTEXT_SHA)
    configure_numerics()
    runtime = numerical_runtime(REPO, "cuda:0")
    if runtime != recorded["runtime"]:
        raise PermissionError("Complete original numerical runtime differs")
    sources = load_saved_sources()
    if sources["original_context"] != recorded:
        raise PermissionError("Original context changed before saved tensor admission")
    inputs = _decode_inputs(sources["bound_inputs"], sources["nonzero_adapter"])
    scaling_dict = sources["bound_inputs"]["scaling"]
    original_scaling = _bound_json(OLD_ROOT / "strict_fresh_scaling.json", SCALING_SHA)
    if scaling_dict != recorded["scaling"] or scaling_dict != original_scaling:
        raise PermissionError("Saved fit-only scaling binding differs")
    scaling = Scaling(np.asarray(scaling_dict["weather_mean"], dtype=np.float32),
                      np.asarray(scaling_dict["weather_std"], dtype=np.float32),
                      scaling_dict["flow_mean"], scaling_dict["flow_std"], scaling_dict["cap"],
                      date.fromisoformat(scaling_dict["start"]), date.fromisoformat(scaling_dict["end"]))
    if scaling.as_dict() != scaling_dict:
        raise PermissionError("Original scaling failed exact reconstruction")
    contract = Contract.load(REPO / "src/precip_input_assimilation/configs/dynamic_filter_eight_basins_v01.json")
    contract = contract.bind(roster_lock=support.original.ORIGINAL_ROOT / "roster_locked.json")
    if contract.sha256 != sources["input_gate"]["contract_sha256"]:
        raise PermissionError("Saved input contract differs")
    for name, digest in PINNED.items():
        path = guarded_existing(contract.model_root / name, contract.model_root)
        if support.sha256(path) != digest:
            raise PermissionError("Frozen model artifact changed before numerical construction")
    hydro = _saved_hydro(contract, sources["input_gate"], recorded)
    frozen = sources["frozen_before"]
    if not _equal(support.state_snapshot(hydro.frozen.model), frozen["state_dict"]):
        raise PermissionError("Fixed frozen model differs from saved original frozen proof")
    summary = _bound_json(support.PILOT / "pilot_result.json", support.PILOT_RESULT_SHA)
    ctx = SavedContext(inputs, scaling, hydro, "cuda:0", output, deadline, require_unchanged,
                          contract=contract, runtime=runtime, original_summary=summary,
                          original_identity=recorded["original_replay_source_identity"])
    ctx.saved_sources = sources
    ctx.check()
    support.write_json(output / "context_identity.json", {
        "schema": "precip_saved_only_context_v02", "original_context_sha256": CONTEXT_SHA,
        "original_input_gate_sha256": GATE_SHA, "runtime": runtime, "scaling": scaling.as_dict(),
        "source_identity": sources["source_identity"], "frozen_state_sha256": hydro.state_hash(),
        "frozen_modes": ctx.mode_reference, "static_identity": hydro.static_identity,
        "warmup_days": 274, "update_days": 33, "first_weather_date": str(inputs.dates[0]),
        "last_weather_date": str(inputs.dates[-1]), "observation_start": str(SMALL_DATES[0]),
        "observation_end": str(SMALL_DATES[-1]), "raw_input_readers_called": False,
        "new_scaling_fit_called": False, "score_numeric_reads_started": False})
    return ctx
