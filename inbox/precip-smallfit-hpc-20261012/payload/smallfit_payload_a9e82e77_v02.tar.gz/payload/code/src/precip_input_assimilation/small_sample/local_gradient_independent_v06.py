"""Version-six source-bound terminal proof schema and preserved-proof-only recovery.

No work runs on import.  The caller supplies the existing exclusive ownership,
source/date gates, reservation, deadline, and shared full-forward counter.
This module does not import the primary derivative or fitting implementation.
"""

from __future__ import annotations

from datetime import date, timedelta
import copy
import hashlib
import io
import json
import math
from pathlib import Path
import random
import time

import numpy as np
import torch
from torch import nn

from .saved_context_v04 import require_full_preservation


CAP = 32.21650314331055
SCALES = (.0001, .0003, .001, .003, .01)
OBJECTIVES = ("terminal_output", "pure_flow_mse")
DAYS = tuple(date(1980, 10, 1) + timedelta(days=i) for i in range(33))
WARMUP = tuple(date(1980, 1, 1) + timedelta(days=i) for i in range(274))
GROUP_SIZES = {"decoder.2.": 33, "encoder.": 4320, "decoder.0.": 1280}


class IndependentAuditFailure(RuntimeError):
    """A raw-proof or independent-recomputation gate failed closed."""


def _require(condition, message):
    if not condition:
        raise IndependentAuditFailure(message)


def _persistent_receipts(ctx, receipts, counter):
    """Reconcile actual evidence with the supervisor's validated durable chain."""
    snapshot = ctx.operation_runtime.counter_snapshot()
    records = snapshot.get("receipts")
    _require(isinstance(records, list) and records, "Missing authoritative durable operation receipts")
    authority = {record["sha256"]: record for record in records}
    for receipt in receipts:
        record = receipt.get("record")
        _require(isinstance(record, dict) and authority.get(record.get("sha256")) == record,
                 "Evidence operation receipt is absent from the authoritative persisted chain")
        event = record["payload"]["event"]
        _require(event.get("kind") == "operation" and event.get("counter") == counter
                 and event.get("cumulative_count") == receipt.get("cumulative_count"),
                 "Evidence receipt counter or cumulative count differs from authority")
    return snapshot


def _tick(ctx, *, new_forward=False, require_checkpoint=True):
    if require_checkpoint:
        ctx.require_unchanged()
    deadline = getattr(ctx, "deadline", None)
    _require(isinstance(deadline, (int, float)) and math.isfinite(deadline), "Missing inherited deadline")
    limit = deadline - 300 if new_forward else deadline
    if time.monotonic() >= limit:
        raise TimeoutError("Independent audit reached the cumulative total deadline")
    if (Path(ctx.output) / "STOP").exists():
        raise InterruptedError("Independent audit preserved the manual stop marker")
    for root in getattr(ctx, "preserved_stop_roots", ()):
        if (Path(root) / "STOP").exists():
            raise InterruptedError("Preserved independent audit respected an original/family manual stop marker")


def _sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _safe(path, root):
    """Validate lexical and resolved location and every link before file reads."""
    path, root = Path(path), Path(root)
    _require(path.is_absolute() and root.is_absolute() and ".." not in path.parts,
             "Proof path is relative or contains parent traversal")
    lexical_root = root.absolute()
    _require(path.absolute().is_relative_to(lexical_root), "Proof lexical path escapes its permitted root")
    for current in (path, *path.parents):
        _require(not current.is_symlink(), "Proof path traverses a symbolic link")
        if current.exists():
            # Windows junctions/reparse points also need rejection.
            attributes = getattr(current.lstat(), "st_file_attributes", 0)
            _require(not attributes & 0x400, "Proof path traverses a reparse point")
    _require(path.resolve(strict=True).is_relative_to(root.resolve(strict=True)),
             "Resolved proof path escapes its permitted root")
    _require(path.is_file(), "Proof is not a regular file")
    return path


def _decode(value):
    if isinstance(value, dict) and set(value) == {"numpy_dtype", "shape", "bytes_hex"}:
        dtype = np.dtype(value["numpy_dtype"])
        shape = value["shape"]
        _require(dtype.kind in "fiub" and not dtype.hasobject and isinstance(shape, list)
                 and all(type(n) is int and n >= 0 for n in shape), "Invalid serialized NumPy type or shape")
        raw = bytes.fromhex(value["bytes_hex"])
        _require(len(raw) == math.prod(shape) * dtype.itemsize, "Serialized NumPy byte count differs")
        return np.frombuffer(raw, dtype=dtype).copy().reshape(shape)
    if isinstance(value, dict):
        return {name: _decode(item) for name, item in value.items()}
    if isinstance(value, (list, tuple)):
        return type(value)(_decode(item) for item in value)
    return value


def _finite(value, label):
    if isinstance(value, torch.Tensor):
        _require(bool(torch.isfinite(value).all()), "Nonfinite tensor: " + label)
    elif isinstance(value, np.ndarray):
        _require(value.dtype.kind in "fiub" and bool(np.isfinite(value).all()), "Invalid array: " + label)
    elif isinstance(value, dict):
        for name, item in value.items():
            _finite(item, label + "/" + str(name))
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _finite(item, label + "/" + str(index))
    elif isinstance(value, float):
        _require(math.isfinite(value), "Nonfinite scalar: " + label)


def _equal(left, right, label):
    if isinstance(left, torch.Tensor) or isinstance(right, torch.Tensor):
        _require(isinstance(left, torch.Tensor) and isinstance(right, torch.Tensor)
                 and left.dtype == right.dtype and left.shape == right.shape
                 and left.detach().cpu().contiguous().numpy().tobytes()
                 == right.detach().cpu().contiguous().numpy().tobytes(), "Tensor bytes differ: " + label)
    elif isinstance(left, np.ndarray) or isinstance(right, np.ndarray):
        _require(isinstance(left, np.ndarray) and isinstance(right, np.ndarray)
                 and left.dtype == right.dtype and left.shape == right.shape
                 and left.tobytes() == right.tobytes(), "Array bytes differ: " + label)
    elif isinstance(left, dict) or isinstance(right, dict):
        _require(isinstance(left, dict) and isinstance(right, dict) and set(left) == set(right),
                 "Dictionary fields differ: " + label)
        for key in left:
            _equal(left[key], right[key], label + "/" + str(key))
    elif isinstance(left, (list, tuple)) or isinstance(right, (list, tuple)):
        _require(type(left) is type(right) and len(left) == len(right), "Sequence differs: " + label)
        for index, (a, b) in enumerate(zip(left, right, strict=True)):
            _equal(a, b, label + "/" + str(index))
    else:
        _require(type(left) is type(right) and left == right, "Scalar differs: " + label)


def _algebra_equal(left, right, label):
    # Signed zero is the same real derivative/value. Stored-state identity
    # comparisons still use _equal's byte check; this gate has no tolerance.
    _require(left.dtype == right.dtype and left.shape == right.shape and torch.equal(left,right),
             "Exact algebra differs: " + label)


def _physical_projection(lower, proposal):
    """Independent clamp algebra; feasible proposals retain their exact bytes."""
    _require(lower.dtype == proposal.dtype == torch.float32 and lower.shape == proposal.shape,
             "Physical projection shape or precision differs")
    _finite((lower, proposal), "physical projection inputs")
    upper = proposal.new_tensor(CAP)
    return torch.where(proposal < lower, lower, torch.where(proposal > upper, upper, proposal))


def _canonical_digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode("utf-8")).hexdigest()


_PRESERVED_BINDING_FIELDS = {
    "schema", "family_root", "evidence_root", "proof_root", "report_root",
    "result_identity", "local_result_identity", "manifest_identity", "failure_identity",
    "original_stage_context_identity", "original_attempt_id",
    "original_counter_attempt_id", "original_counter_attempt_nonce", "original_source_digest",
    "counter_binding", "counter_initialization_evidence_sha256", "counter_genesis_sha256",
    "counter_prefix_event_count", "counter_prefix_head_sha256", "new_attempt_id",
    "original_science_prefix_event_count", "original_science_prefix_head_sha256",
    "inherited_failed_audit_attempt_id", "inherited_failed_audit_attempt_nonce",
    "inherited_failed_audit_source_digest", "failed_predecessor_counter_snapshot_identity",
    "original_evidence_forward_count", "new_audit_forward_count", "cumulative_limit"}


def _directory(path, parent=None):
    path = Path(path)
    _require(path.is_absolute() and ".." not in path.parts, "Audit directory is relative or traverses parents")
    for current in (path, *path.parents):
        _require(not current.is_symlink(), "Audit directory traverses a symbolic link")
        if current.exists():
            _require(not getattr(current.lstat(), "st_file_attributes", 0) & 0x400,
                     "Audit directory traverses a reparse point")
    _require(path.is_dir(), "Audit directory is absent")
    resolved = path.resolve(strict=True)
    if parent is not None:
        parent = Path(parent)
        _require(path.absolute().is_relative_to(parent.absolute())
                 and resolved.is_relative_to(parent.resolve(strict=True)), "Audit directory escapes its family")
    return path


def _read_bound_json(ctx, item, root):
    _require(isinstance(item, dict) and set(item) == {"path", "sha256", "bytes"}
             and type(item["bytes"]) is int and item["bytes"] > 0
             and isinstance(item["sha256"], str) and len(item["sha256"]) == 64,
             "Incomplete preserved JSON identity")
    _tick(ctx)
    path = _safe(item["path"], root)
    raw = path.read_bytes()
    _require(len(raw) == item["bytes"] and hashlib.sha256(raw).hexdigest() == item["sha256"],
             "Preserved JSON bytes changed before admission")
    value = json.loads(raw.decode("utf-8"))
    _require(isinstance(value, dict), "Preserved JSON is not a record")
    _tick(ctx)
    return value


def _original_labels():
    return ["base_original", "base_extension"] + [f"{group}_{index}_{scale}_{sign}"
        for group in ("output_parameters", "encoder_parameters", "middle_parameters")
        for index in range(3) for scale in SCALES for sign in ("plus", "minus")]


def _preserved_receipts(ctx, result, binding, *, final=False):
    """Keep historical calls historical; only two new receipts belong to this audit."""
    snapshot = ctx.operation_runtime.counter_snapshot()
    records = snapshot.get("receipts")
    _require(isinstance(records, list) and type(snapshot.get("event_count")) is int
             and snapshot["event_count"] == len(records), "Incomplete authoritative counter chain")
    prefix = binding["counter_prefix_event_count"]
    _require(type(prefix) is int and prefix == 95 and len(records) >= prefix,
             "Complete inherited 95-event counter prefix is absent")
    _equal(snapshot.get("binding"), binding["counter_binding"], "original counter ownership binding")
    _equal(snapshot.get("initialization_evidence_sha256"), binding["counter_initialization_evidence_sha256"],
           "original counter initialization identity")
    _require(records[0]["sha256"] == binding["counter_genesis_sha256"]
             and records[prefix-1]["sha256"] == binding["counter_prefix_head_sha256"],
             "Original counter genesis or complete prefix changed")
    hashes = []
    for index, record in enumerate(records):
        _require(isinstance(record, dict) and set(record) == {"payload", "sha256"},
                 "Authoritative receipt shape differs")
        payload = record["payload"]
        _require(_canonical_digest(payload) == record["sha256"]
                 and payload.get("sequence") == index and payload.get("binding") == binding["counter_binding"],
                 "Authoritative receipt digest, sequence or source binding differs")
        if index:
            _require(payload.get("previous_sha256") == hashes[-1], "Authoritative receipt prefix chain differs")
        hashes.append(record["sha256"])
    _require(len(set(hashes)) == len(hashes) and snapshot.get("head_sha256") == hashes[-1],
             "Authoritative receipt is duplicated or head differs")
    _failed_predecessor_prefix(ctx, binding, snapshot)
    _require(len(records) == prefix + 1 + (2 if final else 0),
             "Inherited attempt or fresh counter events were hidden, duplicated or omitted")
    initialization = records[0]["payload"]["event"]
    _require(initialization.get("kind") == "initialize"
             and initialization.get("evidence_sha256") == binding["counter_initialization_evidence_sha256"],
             "Original initialization receipt changed")
    authority = {r["sha256"]: r for r in records}
    old = result.get("full_forward_receipts")
    _require(isinstance(old, list) and len(old) == 92 and len(result.get("artifacts", [])) == 60
             and result.get("full_forward_count") == result.get("cumulative_full_forward_count") == 92
             and result.get("full_forward_labels") == _original_labels(),
             "Original 92-call inventory, labels or 60-proof inventory differs")
    old_hashes, old_nonces = [], []
    for number, (receipt, label) in enumerate(zip(old, _original_labels(), strict=True), 1):
        _require(isinstance(receipt, dict) and set(receipt) == {"record", "cumulative_count"},
                 "Original forward receipt shape differs")
        record = receipt["record"]
        _require(isinstance(record, dict) and authority.get(record.get("sha256")) == record
                 and record == records[number+1], "Original receipt is absent or not in its exact prefix position")
        event = record["payload"]["event"]
        _require(event.get("kind") == "operation" and event.get("counter") == "gradient_full_forward"
                 and event.get("attempt_id") == binding["original_counter_attempt_id"]
                 and event.get("attempt_nonce") == binding["original_counter_attempt_nonce"]
                 and event.get("source_sha256") == binding["original_source_digest"]
                 and event.get("label") == label and event.get("update_id") is None
                 and event.get("cumulative_count") == receipt["cumulative_count"] == number,
                 "Original receipt attempt, source, label or cumulative count differs")
        old_hashes.append(record["sha256"])
        old_nonces.append(event.get("operation_nonce"))
    _require(len(set(old_hashes)) == len(old_hashes) and len(set(old_nonces)) == len(old_nonces)
             and all(isinstance(n, str) and n for n in old_nonces), "Original receipts or operation nonces duplicate")
    old_attempt = records[1]["payload"]["event"]
    _require(old_attempt.get("kind") == "attempt" and old_attempt.get("stage") == "gradient_full_forward"
             and old_attempt.get("attempt_id") == binding["original_counter_attempt_id"]
             and old_attempt.get("attempt_nonce") == binding["original_counter_attempt_nonce"]
             and old_attempt.get("source_sha256") == binding["original_source_digest"]
             and old_attempt.get("audit_binding") is None, "Original admitted counter attempt changed")
    counter = getattr(ctx, "full_forward_counter", None)
    _require(counter is not None and getattr(ctx, "forward_key", None) == "gradient"
             and ctx.attempt_id == binding["new_attempt_id"]
             and binding["new_attempt_id"] != binding["original_attempt_id"], "New audit attempt or counter route differs")
    runtime_session = getattr(ctx.operation_runtime, "session", None)
    _require(isinstance(runtime_session, dict) and runtime_session.get("attempt_id") == ctx.attempt_id,
             "New audit lacks the authenticated supervisor attempt")
    new_digest = runtime_session.get("source_digest")
    _require(isinstance(new_digest, str) and len(new_digest) == 64
             and new_digest != binding["original_source_digest"], "New audit source digest is absent or reused")
    new_attempt_id = ctx.attempt_id + "_gradient_full_forward"
    new_attempt = snapshot.get("attempts", {}).get(new_attempt_id)
    _require(isinstance(new_attempt, dict) and new_attempt.get("kind") == "attempt"
             and new_attempt.get("attempt_id") == new_attempt_id
             and new_attempt.get("stage") == "gradient_full_forward"
             and new_attempt.get("source_sha256") == new_digest
             and new_attempt.get("attempt_nonce") != binding["original_counter_attempt_nonce"]
             and new_attempt.get("audit_binding") is None,
             "New audit has no separately admitted original scientific counter attempt")
    _equal(records[prefix]["payload"]["event"], new_attempt, "exact fresh attempt registration after inherited prefix")
    _require(set(snapshot["attempts"]) == {binding["original_counter_attempt_id"],
             _FAILED_AUDIT_ATTEMPT, new_attempt_id}, "An unaccounted counter attempt appeared in the inherited audit")
    expected_count = 2 if final else 0
    _require(type(counter.count) is int and counter.count == expected_count
             and len(counter.receipts) == len(counter.labels) == expected_count,
             "New audit counter must be genuinely zero before work and exactly two after work")
    _require(counter.labels == (["independent_base_original", "independent_base_extension"] if final else []),
             "New audit contains an unexpected complete forward")
    if not final:
        _require(counter.cumulative_count is None, "Fresh audit counter has copied historical state")
    else:
        _require(type(counter.cumulative_count) is int and counter.cumulative_count == 94,
                 "Two new replays must finish at cumulative 94, within the original 100-call cap")
    expected_cumulative = 92 + expected_count
    counts = snapshot.get("counts", {})
    initial = snapshot.get("initial_counts", {})
    _require(set(counts) == set(initial) and len(counts) == 9
             and all(type(v) is int and v == 0 for v in initial.values())
             and counts.get("gradient_full_forward") == expected_cumulative
             and all(type(v) is int and v == 0 for n, v in counts.items() if n != "gradient_full_forward")
             and expected_cumulative <= binding["cumulative_limit"] == 100,
             "Preserved audit changed original cumulative counters or admitted any fitting")
    fresh_hashes, fresh_nonces = [], []
    for number, (receipt, label) in enumerate(zip(counter.receipts, counter.labels, strict=True), 93):
        record = receipt.get("record")
        _require(isinstance(record, dict) and authority.get(record.get("sha256")) == record,
                 "New audit receipt is not in the authoritative original chain")
        _equal(record, records[prefix + 1 + number - 93], "fresh forward exact chain position")
        event = record["payload"]["event"]
        _require(event.get("kind") == "operation" and event.get("counter") == "gradient_full_forward"
                 and event.get("attempt_id") == new_attempt_id and event.get("source_sha256") == new_digest
                 and event.get("attempt_nonce") == new_attempt.get("attempt_nonce")
                 and event.get("label") == label and event.get("update_id") is None
                 and event.get("cumulative_count") == receipt.get("cumulative_count") == number,
                 "New audit receipt attempt, source, label or cumulative count differs")
        fresh_hashes.append(record["sha256"])
        fresh_nonces.append(event.get("operation_nonce"))
    _require(len(set(fresh_hashes + old_hashes)) == len(fresh_hashes) + len(old_hashes)
             and len(set(fresh_nonces + old_nonces)) == len(fresh_nonces) + len(old_nonces),
             "New audit copied an old receipt or reused an operation nonce")
    all_forward_records = [r for r in records if r["payload"]["event"].get("kind") == "operation"
                           and r["payload"]["event"].get("counter") == "gradient_full_forward"]
    _require([r["sha256"] for r in all_forward_records] == old_hashes + fresh_hashes,
             "Unaccounted complete forward appeared in preserved audit")
    return snapshot


def _preserved_admission(ctx, result, binding):
    _require(isinstance(binding, dict) and set(binding) == _PRESERVED_BINDING_FIELDS
             and binding.get("schema") == "precip_preserved_gradient_audit_binding_v06"
             and binding.get("original_evidence_forward_count") == 92
             and binding.get("new_audit_forward_count") == 2 and binding.get("cumulative_limit") == 100,
             "Preserved audit binding fields or fixed operation counts differ")
    binding = copy.deepcopy(binding)
    family = _directory(binding["family_root"])
    evidence = _directory(binding["evidence_root"], family)
    proof = _directory(binding["proof_root"], evidence)
    report = _directory(binding["report_root"], family)
    ctx.preserved_stop_roots = (family, evidence, proof)
    _tick(ctx)
    _require(Path(ctx.output) == report and not report.resolve().is_relative_to(evidence.resolve())
             and not evidence.resolve().is_relative_to(report.resolve()), "New reports overlap immutable original evidence")
    _require(Path(binding["result_identity"]["path"]).parent == proof
             and Path(binding["local_result_identity"]["path"]).parent == proof
             and Path(binding["manifest_identity"]["path"]).parent == proof
             and Path(binding["original_stage_context_identity"]["path"]) == proof / "context_identity.json",
             "Original stage result or manifest escapes its exact proof directory")
    admitted_result = _read_bound_json(ctx, binding["result_identity"], evidence)
    _equal(result, admitted_result, "entire original stage result, including all original decisions")
    local_result = _read_bound_json(ctx, binding["local_result_identity"], evidence)
    _equal(local_result, {n: v for n, v in result.items() if n != "registered_tests"},
           "original result before unchanged registered-test binding")
    manifest = _read_bound_json(ctx, binding["manifest_identity"], evidence)
    failure = _read_bound_json(ctx, binding["failure_identity"], evidence)
    _require(manifest.get("stage") == "gradient" and manifest.get("attempt_id") == binding["original_attempt_id"]
             and isinstance(manifest.get("source_identity"), dict)
             and _canonical_digest(manifest["source_identity"]) == binding["original_source_digest"],
             "Original stage manifest, attempt or complete producer source identity differs")
    _require(binding["original_counter_attempt_id"] == binding["original_attempt_id"] + "_gradient_full_forward",
             "Original scientific counter attempt mapping differs")
    _require(failure.get("error_type") == "IndependentAuditFailure"
             and failure.get("error") == "Tensor bytes differ: physical terminal preserves feasible controls"
             and failure.get("later_fitting_prohibited") is True,
             "Original physical-terminal failure was not preserved")
    _require(result.get("status") == "BLOCKED_OR_UNCONFIRMED" and result.get("numerical_gate_pass") is False
             and result.get("independent_actual_review_complete") is False,
             "Original unsigned blocked result was rewritten as accepted")
    rows = result.get("numerical_records", [])
    expected = [(g, i, o) for g in ("output_parameters", "encoder_parameters", "middle_parameters")
                for i in range(3) for o in OBJECTIVES]
    _require(len(rows) == 18 and [(r.get("group"), r.get("direction_index"), r.get("objective")) for r in rows] == expected,
             "Original eighteen decisions changed their exact inventory or order")
    negative = [(r["group"], r["direction_index"], r["objective"]) for r in rows if r.get("status") == "NOT_CONVERGED"]
    _require(negative == [("encoder_parameters", 0, "terminal_output"),
                          ("encoder_parameters", 2, "terminal_output"),
                          ("middle_parameters", 1, "terminal_output")]
             and all(r.get("status") in ("PASS", "NOT_CONVERGED")
                     and r.get("effective") is (r.get("status") == "PASS") for r in rows),
             "The three original nonconverged directions were omitted or relabeled")
    _preserved_receipts(ctx, result, binding)
    return binding


def _preserved_context_bridge(ctx, binding):
    """Bind both actual metadata files; never substitute the new file for old admission."""
    old = _read_bound_json(ctx, binding["original_stage_context_identity"], binding["evidence_root"])
    new_path = _safe(Path(ctx.output) / "context_identity.json", Path(ctx.output))
    new_identity = {"path": str(new_path), "sha256": _sha(new_path), "bytes": new_path.stat().st_size}
    new = _read_bound_json(ctx, new_identity, Path(ctx.output))
    _equal(new, old, "complete old/current saved-only scientific context metadata bridge")
    _require(new.get("schema") == "precip_saved_only_context_v02"
             and new.get("raw_input_readers_called") is False and new.get("new_scaling_fit_called") is False
             and new.get("score_numeric_reads_started") is False,
             "Preserved context added raw/scoring reads or refit scaling")
    # The original metadata writer serializes torch's version-string subclass
    # as a JSON string. Compare that exact JSON projection, with every field;
    # do not weaken the general stored-tensor/type identity gate.
    actual_runtime_metadata = json.loads(json.dumps(ctx.runtime, allow_nan=False))
    _equal(actual_runtime_metadata, new["runtime"], "actual current runtime and bridged metadata")
    _equal(ctx.scaling.as_dict(), new["scaling"], "actual current scaling and bridged metadata")
    _equal(ctx.hydro.state_hash(), new["frozen_state_sha256"], "actual current protected model and bridged metadata")
    _equal(ctx.mode_reference, new["frozen_modes"], "actual current frozen modes and bridged metadata")
    _equal(ctx.hydro.static_identity, new["static_identity"], "actual current static input and bridged metadata")
    return {"original_context_identity": binding["original_stage_context_identity"],
            "new_actual_context_identity": new_identity, "complete_metadata_strictly_equal": True,
            "original_registry_admission_not_replaced": True}


def _float32_hex(tensor):
    _require(isinstance(tensor, torch.Tensor) and tensor.dtype == torch.float32 and tensor.shape == (),
             "Bit-pattern scalar is not original float32")
    return tensor.detach().cpu().contiguous().numpy().tobytes().hex()


def _terminal_bit_patterns(base):
    """Read raw saved tensors only; do not call a model or alter a saved tensor."""
    proof, terminal = base["trajectory"], base["terminal"]
    _require(len(proof["updates"]) == 33 and len(proof["ledgers"]) == 32,
             "Terminal bit diagnostic lacks the complete original calendar")
    update = proof["updates"][-1]
    raw, proposal, actual = (update[n] for n in ("raw", "proposal", "applied"))
    _require(all(isinstance(t, torch.Tensor) and t.dtype == torch.float32 and t.shape == (100,)
                 for t in (raw, proposal, actual)), "Terminal diagnostic tensor shape or precision differs")
    _finite((raw, proposal, actual, terminal), "saved terminal bit diagnostic")
    _require(update.get("as_of_date") == str(DAYS[-1]) and update.get("cap") == CAP
             and update.get("rain_dates") == [str(DAYS[-1]-timedelta(days=99-i)) for i in range(100)]
             and bool((raw >= 0).all()), "Terminal diagnostic dates, cap or original raw rain differ")
    lower = -torch.minimum(raw, raw.new_tensor(CAP))
    old_algebra = torch.maximum(lower, torch.minimum(proposal, proposal.new_tensor(CAP)))
    conditional = _physical_projection(lower, proposal)
    before, after = terminal["ledger_before_observe"], terminal["ledger_after_observe"]
    _equal(before, torch.cat((proof["ledgers"][-1], proof["ledgers"][-1].new_zeros(1))),
           "terminal bit diagnostic preceding complete ledger and appended current zero")
    _equal(proposal, before[-100:], "terminal bit diagnostic exact original proposal source")
    for name in ("proposal", "applied", "violation"):
        _equal(terminal[name], update[name], "terminal bit diagnostic preserved " + name)
    rows = [{"index": i, "rain_date": update["rain_dates"][i],
             "raw_hex": _float32_hex(raw[i]), "lower_hex": _float32_hex(lower[i]),
             "proposal_hex": _float32_hex(proposal[i]), "original_applied_hex": _float32_hex(actual[i]),
             "old_algebra_expected_hex": _float32_hex(old_algebra[i]),
             "new_conditional_projection_hex": _float32_hex(conditional[i])} for i in range(100)]
    changed = [r for r in rows if r["old_algebra_expected_hex"] != r["proposal_hex"]]
    failures = []
    if not bool(((proposal >= lower) & (proposal <= CAP)).all()):
        failures.append("Original feasible terminal proposal is genuinely out of bounds")
    if not torch.equal(old_algebra, proposal):
        failures.append("Old algebra has a nonzero numeric difference from the original proposal")
    if not torch.equal(conditional, proposal):
        failures.append("Conditional projection has a nonzero numeric difference")
    if any(r["original_applied_hex"] != r["proposal_hex"] for r in rows):
        failures.append("Original actual applied bytes differ from original proposal bytes")
    if any(r["new_conditional_projection_hex"] != r["proposal_hex"] for r in rows):
        failures.append("Conditional projection failed to preserve feasible proposal bytes")
    if any({r["old_algebra_expected_hex"], r["proposal_hex"]} != {"00000000", "00000080"} for r in changed):
        failures.append("Old algebra byte differences are not exclusively signed zeros")
    if before.shape != after.shape or before.dtype != after.dtype or \
            before.contiguous().numpy().tobytes() != after.contiguous().numpy().tobytes():
        failures.append("Original actual terminal projection changed full ledger bytes")
    _require("terminal_proposal_objective_grad" in terminal, "Mandatory base terminal graph evidence is absent")
    _equal(terminal["terminal_proposal_objective_grad"], [None, None], "terminal proposal objective exclusion")
    _require("terminal_applied_objective_grad" in terminal, "Mandatory base terminal graph evidence is absent")
    _equal(terminal["terminal_applied_objective_grad"], [None, None], "terminal applied objective exclusion")
    _require(terminal.get("targets_formed_before_observe") is True
             and terminal.get("terminal_new_network_call") is False, "Terminal added a network call or entered an objective")
    return {"pass": not failures, "failures": failures, "rows": rows,
            "old_algebra_signed_zero_byte_differences": len(changed),
            "nonzero_numeric_differences": int((old_algebra != proposal).sum()),
            "original_actual_nonzero_numeric_differences": int((actual != proposal).sum()),
            "new_conditional_nonzero_numeric_differences": int((conditional != proposal).sum()),
            "original_actual_proposal_byte_differences": sum(r["original_applied_hex"] != r["proposal_hex"] for r in rows),
            "original_genuine_out_of_bounds": int(((proposal < lower) | (proposal > CAP)).sum()),
            "ledger_before_hex": before.contiguous().numpy().tobytes().hex(),
            "ledger_after_hex": after.contiguous().numpy().tobytes().hex()}


def _write_new_report(ctx, name, value):
    root = _directory(ctx.output)
    path = root / name
    _require(path.parent == root and path.name == name and not path.exists(),
             "Refusing to replace an existing preserved-audit report")
    _tick(ctx)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
    _tick(ctx)
    return {"path": str(path), "sha256": _sha(path), "bytes": path.stat().st_size}


def _save_new_audit_base(ctx, name, rebuilt, result, binding):
    """Persist a new actual base before byte comparison; never replace old proof."""
    root = _directory(ctx.output)
    path = root / ("preserved_new_base_" + name + "_v05.pt")
    _require(name in ("original", "extension") and not path.exists(), "New base proof name exists or differs")
    _tick(ctx)
    require_full_preservation(ctx.require_unchanged)
    payload = {"schema": "precip_preserved_new_actual_base_v05", "base_name": name,
               "original_base_identity": result["base_proofs"][name],
               "original_result_identity": binding["result_identity"],
               "binding_sha256": _canonical_digest(binding),
               "new_attempt_id": ctx.attempt_id,
               "new_forward_receipt": copy.deepcopy(ctx.full_forward_counter.receipts[-1]),
               "actual_rebuilt_base": rebuilt}
    _finite(payload, "new actual base proof")
    with path.open("xb") as handle:
        torch.save(payload, handle)
    _tick(ctx)
    return {"path": str(path), "sha256": _sha(path), "bytes": path.stat().st_size}


def _preserved_terminal_diagnostic(ctx, bases, result, binding):
    value = {"schema": "precip_preserved_terminal_bit_diagnostic_v05", "pass": False,
             "original_result_identity": binding["result_identity"],
             "original_failure_identity": binding["failure_identity"],
             "binding_sha256": _canonical_digest(binding), "raw_artifacts": result["artifacts"],
             "diagnostic_uses_model_forward": False, "new_fitting_executed": False, "bases": {}}
    try:
        for name in ("original", "extension"):
            _tick(ctx)
            value["bases"][name] = _terminal_bit_patterns(bases[name])
        value["pass"] = all(v["pass"] for v in value["bases"].values()) and \
            value["bases"]["original"]["old_algebra_signed_zero_byte_differences"] > 0
        if not value["pass"]:
            value["stop_reason"] = "Exact saved bit patterns do not confirm an exclusively signed-zero audit defect"
    except BaseException as error:
        value["error_type"], value["error"] = type(error).__name__, str(error)
        identity = _write_new_report(ctx, "preserved_terminal_bit_diagnostic_v05.json", value)
        raise IndependentAuditFailure("Preserved terminal bit diagnostic failed; evidence at " + identity["path"]) from error
    identity = _write_new_report(ctx, "preserved_terminal_bit_diagnostic_v05.json", value)
    _require(value["pass"], "Preserved terminal bit diagnostic blocked; original evidence remains unchanged")
    return identity


def audit_gradient_stage(ctx, result):
    """Default complete-run audit retains the original 92 plus two replay semantics."""
    return _audit_gradient_stage(ctx, result)


def audit_gradient_preserved_stage(ctx, result, binding):
    """Audit 92 immutable old proofs, charge only two fresh bases, and never fit."""
    return _audit_gradient_stage(ctx, result, preserved_binding=binding)


class _Reader:
    def __init__(self, ctx, artifacts, *, proof_root=None):
        self.ctx, self.root = ctx, Path(ctx.output if proof_root is None else proof_root)
        self.items, self.used, self._last_verified_load = {}, set(), None
        _require(isinstance(artifacts, list) and artifacts, "Missing complete raw-artifact manifest")
        for item in artifacts:
            _require(set(item) >= {"path", "sha256", "bytes"}, "Incomplete artifact identity")
            path = _safe(item["path"], self.root)
            key = str(path)
            _require(key not in self.items and len(item["sha256"]) == 64,
                     "Duplicate or invalid raw-artifact identity")
            _tick(ctx)
            _require(path.stat().st_size == item["bytes"] and _sha(path) == item["sha256"],
                     "Artifact bytes changed before numeric loading")
            self.items[key] = item

    def read(self, value):
        _tick(self.ctx)
        path = _safe(value["path"] if isinstance(value, dict) else value, self.root)
        item = self.items.get(str(path))
        _require(item is not None, "Numeric read is not bound to the stage artifact manifest")
        if isinstance(value, dict):
            _equal(value, item, "artifact reference")
        raw = path.read_bytes()
        _require(len(raw) == item["bytes"] and hashlib.sha256(raw).hexdigest() == item["sha256"],
                 "Artifact changed between admission and load")
        if path.suffix in (".pt", ".npy", ".npz"):
            require_full_preservation(self.ctx.require_unchanged)
        if path.suffix == ".pt":
            result = _decode(torch.load(io.BytesIO(raw), map_location="cpu", weights_only=True))
        elif path.suffix == ".json":
            result = json.loads(raw.decode("utf-8"))
        elif path.suffix == ".npy":
            result = np.load(io.BytesIO(raw), allow_pickle=False)
        elif path.suffix == ".npz":
            with np.load(io.BytesIO(raw), allow_pickle=False) as data:
                result = {name: data[name].copy() for name in data.files}
        else:
            raise IndependentAuditFailure("Unsupported proof file type")
        self.used.add(str(path))
        self._last_verified_load = (str(path), result)
        _finite(result, str(path))
        _tick(self.ctx)
        return result


def _rng():
    return {"python": copy.deepcopy(random.getstate()), "numpy": copy.deepcopy(np.random.get_state()),
            "torch_cpu": torch.get_rng_state().clone(),
            "torch_cuda": [x.clone() for x in torch.cuda.get_rng_state_all()] if torch.cuda.is_available() else []}


def _restore_rng(value):
    value = _decode(value)
    random.setstate(value["python"])
    np.random.set_state(value["numpy"])
    torch.set_rng_state(value["torch_cpu"])
    _require(len(value["torch_cuda"]) == (torch.cuda.device_count() if torch.cuda.is_available() else 0),
             "Random-state device inventory differs")
    if value["torch_cuda"]:
        torch.cuda.set_rng_state_all(value["torch_cuda"])


def _restore_model(model, value, optimizer=None):
    model.load_state_dict(value["state_dict"], strict=True)
    modules = dict(model.named_modules())
    _require(set(value["modes"]) == set(modules), "Restoration module inventory differs")
    for name, mode in value["modes"].items():
        _require(type(mode) is bool, "Restoration mode is not boolean")
        modules[name].training = mode
    parameters = dict(model.named_parameters())
    if "requires_grad" in value:
        _require(set(value["requires_grad"]) == set(parameters), "Restoration trainability inventory differs")
        for name, parameter in parameters.items():
            parameter.requires_grad_(value["requires_grad"][name])
    for name, parameter in parameters.items():
        saved = value.get("gradients", {}).get(name)
        parameter.grad = None if saved is None else saved.detach().to(parameter.device).clone()
    if optimizer is not None:
        optimizer.load_state_dict(value["optimizer"])
    _restore_rng(value["rng"])


def _frozen(ctx):
    model = ctx.hydro.frozen.model
    result = {"state_dict": {n: t.detach().cpu().clone() for n, t in model.state_dict().items()},
              "modes": {n: m.training for n, m in model.named_modules()},
              "requires_grad": {n: p.requires_grad for n, p in model.named_parameters()},
              "gradients": {n: None if p.grad is None else p.grad.detach().cpu().clone()
                            for n, p in model.named_parameters()}}
    _finite(result, "frozen model")
    _require(result["modes"] == ctx.mode_reference and not result["modes"].get("")
             and result["modes"].get("lstm") and not result["modes"].get("dropout")
             and not any(result["requires_grad"].values())
             and all(g is None for g in result["gradients"].values()), "Frozen model modes or gradients changed")
    return result


def _inputs(ctx, bound, warmup=None):
    _require(tuple(bound["dates"]) == tuple(str(d) for d in DAYS), "Saved input dates differ")
    weather, observations = bound["weather"], bound["observations"]
    _require(isinstance(weather, np.ndarray) and weather.shape == (33, 5)
             and isinstance(observations, np.ndarray) and observations.shape == (33,), "Saved input shapes differ")
    _equal(weather, ctx.small_weather, "admitted saved weather")
    _equal(observations, ctx.small_values, "admitted saved observations")
    _equal(bound["scaling"], ctx.scaling.as_dict(), "saved scaling identity")
    _require(bound["scaling"]["cap"] == CAP and bound["scaling"]["flow_std"] > 0,
             "Saved physical cap or flow standard deviation differs")
    warmup = bound if warmup is None else warmup
    _require(tuple(warmup["warmup_dates"]) == tuple(str(d) for d in WARMUP), "Incomplete 274-day warmup")
    warm_weather = warmup["warmup_weather"]
    if isinstance(warm_weather, np.ndarray):
        warm_weather = torch.as_tensor(warm_weather, dtype=torch.float32)
    _require(warm_weather.shape == (274, 5) and warm_weather.dtype == torch.float32,
             "Saved warmup shape or precision differs")
    _equal(warm_weather, torch.as_tensor(ctx.inputs.weather[:274], dtype=torch.float32), "saved full warmup")
    _equal(warmup["warmup_applied"], torch.zeros(274, dtype=torch.float32), "initial zero rain ledger")
    _require(tuple(ctx.inputs.dates[:274]) == WARMUP and (warm_weather[:, 0] >= 0).all(),
             "Saved weather calendar or precipitation differs")
    _finite((weather, observations, warm_weather), "admitted inputs")
    return {"weather": torch.as_tensor(weather, dtype=torch.float32), "observations": observations,
            "warmup_weather": warm_weather, "flow_mean": float(ctx.scaling.flow_mean),
            "flow_std": float(ctx.scaling.flow_std)}


def branch_codes(proof):
    """Classify all 3,200 original points; boundary equality remains explicit."""
    codes = []
    _require(len(proof["updates"]) == 33, "Missing original update rows")
    for update in proof["updates"][:32]:
        raw, proposal = update["raw"], update["proposal"]
        lower = -torch.minimum(raw, raw.new_tensor(CAP))
        code = torch.full_like(proposal, 2, dtype=torch.int8)
        code[proposal < lower], code[proposal == lower] = 0, 1
        code[proposal == CAP], code[proposal > CAP] = 3, 4
        codes.append(code)
    return torch.stack(codes)



_ORIGINAL_WRITER_RELATIVE_PATH = "src/precip_input_assimilation/small_sample/branch_gradient_v04.py"
_ORIGINAL_WRITER_SHA256 = "7ced39b3e578aa00de53a9440438a00f0601789e127536d38b4dc71e314903ba"
_FAILED_COUNTER_SNAPSHOT_RAW_SHA256 = "7d58c46b3cddaaa3b8269a413754a886f6fb1e006a562f4e454991d35dd8839f"
_FAILED_COUNTER_SNAPSHOT_CANONICAL_SHA256 = "179416b57e0a387313516b7c7f2df57f1fc04867d7df219d7df900449e7d92bc"
_SCIENCE_PREFIX_HEAD_SHA256 = "0f053637251175a26ef6c2751f056d1e26abac396a2517f9f2c9a7194bcb7a38"
_FAILED_AUDIT_ATTEMPT = "flexible_20261011_v04_attempt_006_gradient_full_forward"
_FAILED_AUDIT_NONCE = "f53ee3b61a2647328da2311420b6b3a1"
_FAILED_AUDIT_SOURCE = "9e1fe3c27a7c19c514f1ac28af55059f7c734e1f597c50e5259d881df3713795"


def _failed_predecessor_prefix(ctx, binding, current):
    """Require all 95 raw inherited records, including the zero-forward failed registration."""
    identity = binding["failed_predecessor_counter_snapshot_identity"]
    path = Path(binding["family_root"]) / "local_gradient_preserved_audit_20261011_v10" / "final_counter_snapshot.json"
    # Both lexical and resolved absolute paths receive the original no-link /
    # no-reparse-point root guard before comparing the same Windows file.
    # The producer writes as_posix(); slash spelling is not a file identity.
    actual_path = _safe(identity["path"], binding["family_root"])
    fixed_path = _safe(path, binding["family_root"])
    _require(actual_path == fixed_path and actual_path.resolve(strict=True) == fixed_path.resolve(strict=True)
             and identity["sha256"] == _FAILED_COUNTER_SNAPSHOT_RAW_SHA256,
             "Inherited failed snapshot is not the fixed actual raw-byte identity")
    old = _read_bound_json(ctx, identity, binding["family_root"])
    _require(_canonical_digest(old) == _FAILED_COUNTER_SNAPSHOT_CANONICAL_SHA256,
             "Inherited failed snapshot canonical digest differs from its separately pinned raw bytes")
    _require(binding["original_science_prefix_event_count"] == 94
             and binding["original_science_prefix_head_sha256"] == _SCIENCE_PREFIX_HEAD_SHA256
             and binding["inherited_failed_audit_attempt_id"] == _FAILED_AUDIT_ATTEMPT
             and binding["inherited_failed_audit_attempt_nonce"] == _FAILED_AUDIT_NONCE
             and binding["inherited_failed_audit_source_digest"] == _FAILED_AUDIT_SOURCE,
             "Original science or inherited failed-attempt identity differs")
    _require(old["event_count"] == len(old["receipts"]) == binding["counter_prefix_event_count"] == 95
             and old["receipts"][93]["sha256"] == _SCIENCE_PREFIX_HEAD_SHA256
             and old["head_sha256"] == old["receipts"][94]["sha256"] == binding["counter_prefix_head_sha256"],
             "Original 94 science records or the complete 95-event failed prefix differs")
    _equal(current["receipts"][:95], old["receipts"], "all inherited failed-prefix raw receipt fields")
    for name in ("binding", "initialization_evidence_sha256", "initial_counts"):
        _equal(current[name], old[name], "inherited counter authority " + name)
    _require(old["counts"]["gradient_full_forward"] == 92 and len(old["counts"]) == 9
             and all(type(v) is int and v == 0 for n, v in old["counts"].items() if n != "gradient_full_forward")
             and all(type(v) is int and v == 0 for v in old["initial_counts"].values())
             and old["audit_counts"] == {}, "Inherited failure performed an unaccounted numerical operation")
    failed = {"kind": "attempt", "stage": "gradient_full_forward", "attempt_id": _FAILED_AUDIT_ATTEMPT,
              "attempt_nonce": _FAILED_AUDIT_NONCE, "source_sha256": _FAILED_AUDIT_SOURCE, "audit_binding": None}
    _equal(old["receipts"][94]["payload"]["event"], failed, "complete zero-forward failed attempt event")
    _equal(old["attempts"][_FAILED_AUDIT_ATTEMPT], failed, "failed attempt table/event binding")
    _require(set(old["attempts"]) == {binding["original_counter_attempt_id"], _FAILED_AUDIT_ATTEMPT},
             "Inherited failed counter has an unexpected attempt")
    for name, event in old["attempts"].items():
        _equal(current["attempts"][name], event, "inherited attempt registration " + name)


_TERMINAL_COMMON_FIELDS = frozenset({"ledger_before_observe", "targets_formed_before_observe",
    "targets_before_observe", "proposal", "applied", "violation", "raw", "cap", "ledger_after_observe",
    "terminal_new_network_call"})
_TERMINAL_GRADIENT_FIELDS = frozenset({"terminal_proposal_objective_grad", "terminal_applied_objective_grad"})
_BASE_PROOF_FIELDS = frozenset({"snapshot_before", "restoration_binding", "requires_grad", "trajectory", "features",
    "targets", "gradients", "adjoints", "saved_group_gradients", "branch_codes", "terminal", "parameters",
    "restored_snapshot", "final_restoration_binding"})
_ENDPOINT_PROOF_FIELDS = frozenset({"snapshot_before", "restoration_binding", "parameters", "trajectory", "features",
    "targets", "terminal", "restored_snapshot", "final_restoration_binding"})
_PAIR_PROOF_FIELDS = frozenset({"group", "prefix", "direction_index", "delta", "direction", "names", "sizes",
    "base_parameters", "base_branches", "automatic", "representation", "scalar_resolution", "plus", "minus"})


def _terminal_schema(payload, kind):
    """Actual fixed writer emits derivative fields only for its two _gradients bases."""
    _require(kind in ("derivative_base", "numeric_parameter_endpoint"), "Unregistered terminal proof kind")
    fields = _BASE_PROOF_FIELDS if kind == "derivative_base" else _ENDPOINT_PROOF_FIELDS
    _require(isinstance(payload, dict) and set(payload) == fields, "Fixed writer proof field inventory differs")
    terminal = payload["terminal"]
    expected = _TERMINAL_COMMON_FIELDS | (_TERMINAL_GRADIENT_FIELDS if kind == "derivative_base" else frozenset())
    _require(isinstance(terminal, dict) and set(terminal) == expected,
             "Fixed writer terminal kind or mandatory field inventory differs")
    if kind == "derivative_base":
        for field in sorted(_TERMINAL_GRADIENT_FIELDS):
            _equal(terminal[field], [None, None], "mandatory base objective graph exclusion " + field)
    _require(terminal["targets_formed_before_observe"] is True and terminal["terminal_new_network_call"] is False,
             "Terminal target timing or extra network call differs")
    _equal(terminal["targets_before_observe"], payload["targets"], "fixed-writer pre-observe objective identity")
    _require(len(payload["features"]) == 32 and len(payload["trajectory"]["predictions"]) == 33
             and len(payload["trajectory"]["updates"]) == 33 and len(payload["trajectory"]["ledgers"]) == 32,
             "Fixed writer did not record exactly 32 network calls and the complete 33-day calendar")


class _TerminalEvidence:
    """No kind switch: a token is valid only in its source-bound issuing registry."""
    __slots__ = ("_registry", "_key")

    def __init__(self, registry, key):
        _require(key in registry._issued, "Unissued terminal evidence token")
        self._registry, self._key = registry, key


class _TerminalEvidenceRegistry:
    """Seal writer-derived kinds against complete original artifacts and actual verified loads.

    The old proofs have no self-declared kind field. Kind comes from the pinned
    writer's unique artifact position and the entire admitted direction/scale
    inventory. No model runs during this structural preflight.
    """
    def __init__(self, ctx, reader, result, binding):
        self.ctx, self.reader, self.result, self.binding = ctx, reader, result, binding
        self._issued, self._bases, self._directions = {}, {}, {}
        manifest = _read_bound_json(ctx, binding["manifest_identity"], binding["evidence_root"])
        repo = Path(__file__).resolve().parents[3]
        writer = _safe(repo / _ORIGINAL_WRITER_RELATIVE_PATH, repo)
        _require(manifest["source_identity"][_ORIGINAL_WRITER_RELATIVE_PATH] == _ORIGINAL_WRITER_SHA256
                 and _sha(writer) == _ORIGINAL_WRITER_SHA256
                 and _canonical_digest(manifest["source_identity"]) == binding["original_source_digest"],
                 "Fixed original numeric-endpoint writer or its full producer-source binding differs")
        self.writer_identity = {"path": str(writer), "sha256": _ORIGINAL_WRITER_SHA256, "bytes": writer.stat().st_size}
        expected_directions = [(g, p, i) for g, p in (("output_parameters", "decoder.2."),
            ("encoder_parameters", "encoder."), ("middle_parameters", "decoder.0.")) for i in range(3)]
        _require([(r["group"], r["prefix"], r["direction_index"]) for r in result["directions"]] == expected_directions,
                 "Complete fixed writer direction identity/order differs")
        labels = [("frozen_before", "frozen"), ("base_original", "derivative_base"), ("base_extension", "derivative_base")]
        labels += [(f"direction_{g}_{i}", "direction") for g, _, i in expected_directions]
        labels += [(f"pair_{g}_{i}_{delta}", "numeric_pair") for g, _, i in expected_directions for delta in SCALES]
        labels += [("final_restoration", "restoration"), ("outer_rng_restoration", "rng"), ("frozen_after", "frozen")]
        _require(len(result["artifacts"]) == len(labels) == 60, "Fixed writer 60-artifact inventory differs")
        self._inventory = {}
        for index, (item, (label, kind)) in enumerate(zip(result["artifacts"], labels, strict=True)):
            path = Path(item["path"])
            _require(path.parent == Path(binding["proof_root"]) / "local_gradient_proofs"
                     and path.name == f"{index:03d}_{label}.pt", "Actual artifact kind, unique position or label differs")
            self._inventory[str(path)] = (item, label, kind)
        for name, index in (("original", 1), ("extension", 2)):
            _equal(result["base_proofs"][name], result["artifacts"][index], "registered parent base artifact")
        for index, registered in enumerate(result["directions"]):
            _equal(registered["direction_proof"], result["artifacts"][3 + index], "registered direction artifact")
            _require([s["delta"] for s in registered["scales"]] == list(SCALES), "Registered endpoint scales differ")
            for scale_index, scale in enumerate(registered["scales"]):
                _equal(scale["proof"], result["artifacts"][12 + 5*index + scale_index], "registered numeric pair artifact")
        rows, failure = [], None
        try:
            for item in result["artifacts"]:
                payload = reader.read(item)
                label, kind = self._inventory[item["path"]][1:]
                row = {"artifact_identity": copy.deepcopy(item), "label": label, "writer_derived_kind": kind,
                       "actual_top_level_keys": sorted(payload) if isinstance(payload, dict) else None}
                rows.append(row)
                _require(isinstance(payload, dict), "Original writer artifact is not a record")
                if kind == "derivative_base":
                    row["actual_terminal_keys"] = sorted(payload["terminal"])
                    _terminal_schema(payload, "derivative_base")
                elif kind == "numeric_pair":
                    _require(set(payload) == _PAIR_PROOF_FIELDS, "Original numeric pair keys differ")
                    row["actual_endpoint_keys"] = {}
                    row["actual_endpoint_terminal_keys"] = {}
                    for sign in ("plus", "minus"):
                        row["actual_endpoint_keys"][sign] = sorted(payload[sign])
                        row["actual_endpoint_terminal_keys"][sign] = sorted(payload[sign]["terminal"])
                        _terminal_schema(payload[sign], "numeric_parameter_endpoint")
                elif kind == "direction":
                    registered = result["directions"][len(self._directions)]
                    for name in ("group", "prefix", "direction_index", "names", "sizes"):
                        _equal(payload[name], registered[name], "preflight direction registration " + name)
                    self._directions[(registered["group"], registered["direction_index"])] = payload
        except BaseException as error:
            failure = {"type": type(error).__name__, "error": str(error)}
            raise
        finally:
            self.preflight_identity = _write_new_report(ctx, "preserved_original_proof_schema_preflight_v06.json", {
                "schema": "precip_preserved_terminal_evidence_registry_v06", "structural_preflight_pass": failure is None,
                "complete_numerical_audit": False, "new_model_forwards": 0, "new_fitting_executed": False,
                "writer_identity": self.writer_identity, "original_producer_source_digest": binding["original_source_digest"],
                "original_result_identity": binding["result_identity"], "binding_sha256": _canonical_digest(binding),
                "artifacts": rows, "failure": failure})
        _require(not hasattr(ctx, "_active_terminal_evidence_registry"),
                 "A terminal evidence registry is already active in this scientific context")
        ctx._active_terminal_evidence_registry = self

    def _load_binding(self, item, payload, kind):
        _require(self.reader._last_verified_load is not None
                 and self.reader._last_verified_load[0] == item["path"]
                 and self.reader._last_verified_load[1] is payload,
                 "Terminal evidence is not the actual last hash-verified artifact load")
        _equal(item, self._inventory[item["path"]][0], "exact terminal artifact identity")
        _require(self._inventory[item["path"]][2] == kind, "Attempted terminal kind exemption from another artifact")

    def _issue(self, payload, kind, identity):
        key = object()
        self._issued[key] = (payload["trajectory"], payload["terminal"], kind, copy.deepcopy(identity))
        return _TerminalEvidence(self, key)

    def base(self, name, payload):
        _require(name in ("original", "extension") and name not in self._bases, "Duplicated or foreign parent base")
        item = self.result["base_proofs"][name]
        self._load_binding(item, payload, "derivative_base")
        _terminal_schema(payload, "derivative_base")
        self._bases[name] = payload
        return self._issue(payload, "derivative_base", {"base_name": name, "artifact_identity": item,
            "original_source_digest": self.binding["original_source_digest"], "writer_sha256": _ORIGINAL_WRITER_SHA256})

    def endpoints(self, registered, scale, pair):
        _require(set(self._bases) == {"original", "extension"}, "Endpoint lacks its two authenticated parent bases")
        matches = [r for r in self.result["directions"] if r is registered]
        _require(len(matches) == 1 and any(s is scale for s in registered["scales"]), "Unregistered endpoint direction or scale object")
        self._load_binding(scale["proof"], pair, "numeric_pair")
        _require(set(pair) == _PAIR_PROOF_FIELDS, "Numeric pair mandatory field inventory differs")
        for name in ("group", "prefix", "direction_index", "names", "sizes"):
            _equal(pair[name], registered[name], "terminal numeric pair registration " + name)
        _equal(pair["delta"], scale["delta"], "terminal numeric pair exact scale")
        registered_direction = self._directions[(registered["group"], registered["direction_index"])]["direction"]
        _equal(pair["direction"], registered_direction, "terminal numeric pair exact fixed direction")
        _equal(pair["base_parameters"], self._bases["original"]["parameters"], "terminal numeric pair parent parameter bytes")
        _equal(pair["base_branches"], self._bases["original"]["branch_codes"], "terminal numeric pair parent branch bytes")
        tokens = {}
        for sign_name, sign in (("plus", 1.), ("minus", -1.)):
            endpoint = pair[sign_name]
            _terminal_schema(endpoint, "numeric_parameter_endpoint")
            _equal(endpoint["snapshot_before"], self._bases["original"]["snapshot_before"],
                   "terminal endpoint exact original starting snapshot")
            _equal(endpoint["restored_snapshot"], self._bases["original"]["restored_snapshot"],
                   "terminal endpoint exact original restored snapshot")
            _require(set(endpoint["parameters"]) == set(pair["base_parameters"]),
                     "Terminal endpoint parameter inventory differs")
            offset = 0
            for name in sorted(pair["base_parameters"]):
                expected = pair["base_parameters"][name].to(self.ctx.device).clone()
                if name in registered["names"]:
                    count = expected.numel()
                    expected.add_(sign * scale["delta"] * registered_direction[offset:offset+count].to(
                        self.ctx.device).reshape(expected.shape))
                    offset += count
                _equal(endpoint["parameters"][name], expected.detach().cpu(),
                       "source-bound endpoint sign/scale/direction parameter bytes")
            _require(offset == registered_direction.numel(), "Endpoint direction dimensions or names differ")
            tokens[sign_name] = self._issue(endpoint, "numeric_parameter_endpoint", {
                "artifact_identity": scale["proof"], "group": registered["group"], "prefix": registered["prefix"],
                "direction_index": registered["direction_index"], "delta": scale["delta"], "sign_name": sign_name,
                "sign": sign, "parent_base_identity": self.result["base_proofs"]["original"],
                "original_source_digest": self.binding["original_source_digest"], "writer_sha256": _ORIGINAL_WRITER_SHA256})
        return tokens

    def validate(self, evidence, proof, terminal):
        _require(type(evidence) is _TerminalEvidence and evidence._registry is self
                 and evidence._key in self._issued, "Forged or foreign terminal proof exemption")
        saved_proof, saved_terminal, kind, identity = self._issued[evidence._key]
        _require(proof is saved_proof and terminal is saved_terminal,
                 "Terminal token applied to a different endpoint, sign or parent proof")
        item = identity["artifact_identity"]
        _require(self._inventory[item["path"]][2] == ("derivative_base" if kind == "derivative_base" else "numeric_pair")
                 and identity["original_source_digest"] == self.binding["original_source_digest"]
                 and identity["writer_sha256"] == _ORIGINAL_WRITER_SHA256,
                 "Terminal proof token writer, source or kind changed")
        if kind == "derivative_base":
            for field in sorted(_TERMINAL_GRADIENT_FIELDS):
                _require(field in terminal, "Derivative base is missing mandatory terminal graph evidence")
                _equal(terminal[field], [None, None], "mandatory derivative terminal graph evidence " + field)
        else:
            _require(kind == "numeric_parameter_endpoint" and set(terminal) == _TERMINAL_COMMON_FIELDS,
                     "Numeric endpoint has forged or partial derivative terminal fields")
        return kind



def _trajectory(ctx, proof, inputs, fixed=None, terminal=None, *, terminal_evidence=None):
    """Rebuild every calendar row, pre-update window, bound and overwrite."""
    if terminal_evidence is not None:
        _require(type(terminal_evidence) is _TerminalEvidence and terminal is not None
                 and type(terminal_evidence._registry) is _TerminalEvidenceRegistry
                 and getattr(ctx, "_active_terminal_evidence_registry", None) is terminal_evidence._registry,
                 "Invalid registered terminal evidence token")
        terminal_evidence._registry.validate(terminal_evidence, proof, terminal)
    _finite(proof, "raw trajectory")
    _require(len(proof["predictions"]) == len(proof["updates"]) == 33
             and len(proof["ledgers"]) == 32, "Incomplete 33-day trajectory")
    weather, ledger = inputs["warmup_weather"].clone(), torch.zeros(274, dtype=torch.float32)
    terms, output = [], None
    for index, current in enumerate(DAYS):
        _tick(ctx)
        pred, update = proof["predictions"][index], proof["updates"][index]
        _require(pred["date"] == str(current) and pred["locked"] is True
                 and pred["observation_cutoff"] == str(current - timedelta(days=1))
                 and update["as_of_date"] == str(current) and update["missing"] is False
                 and update["cap"] == CAP, "Prediction dates or information cutoff differ")
        _require(update["rain_dates"] == [str(current - timedelta(days=99-lag)) for lag in range(100)],
                 "Control row transposes or changes the 100 rain dates")
        weather = torch.cat((weather, inputs["weather"][index:index+1]))
        ledger = torch.cat((ledger, ledger.new_zeros(1)))
        window = weather[-270:].clone()
        window[:, 0] += ledger[-270:]
        _require(pred["state_digest"] == hashlib.sha256(window.numpy().tobytes()).hexdigest(),
                 "Prediction state does not use the current pre-observation ledger")
        q = pred["tensor"]
        _require(q.dtype == torch.float32 and q.shape == (), "Predicted scalar precision differs")
        device_q = q.to(ctx.device)
        if index:
            terms.append(((device_q-device_q.new_tensor(float(inputs["observations"][index])))
                          / inputs["flow_std"]).square())
        output = ((device_q-inputs["flow_mean"])/inputs["flow_std"]).detach().cpu()
        for name in ("raw", "proposal", "applied", "violation"):
            _require(update[name].dtype == torch.float32 and update[name].shape == (100,),
                     "Update precision or shape differs")
        _equal(update["raw"], weather[-100:, 0], "unmodified historical precipitation")
        lower = -torch.minimum(update["raw"], update["raw"].new_tensor(CAP))
        proposal = update["proposal"]
        physical = _physical_projection(lower, proposal)
        expected = physical if fixed is None or index == 32 else torch.where(
            fixed[index] == 0, lower, torch.where(fixed[index] == 4, proposal.new_tensor(CAP), proposal))
        violation = (torch.relu(lower-proposal)+torch.relu(proposal-CAP))/CAP
        _algebra_equal(update["applied"], expected, "independent selected projection rule")
        _equal(update["violation"], violation, "raw soft-violation diagnostic")
        before = ledger.clone()
        if index == 32:
            _equal(proposal, before[-100:], "terminal adapter retains preceding controls")
            if fixed is None:
                _equal(expected, proposal, "physical terminal preserves feasible controls")
        ledger = torch.cat((ledger[:-100], expected))
        if index < 32:
            _equal(proof["ledgers"][index], ledger, "latest control overwrites previous ledger")
        if fixed is None:
            _require(bool((weather[:, 0]+ledger >= 0).all()), "Physical corrected rain is negative")
        if index == 32 and terminal is not None:
            for name in ("proposal", "applied", "violation"):
                _equal(terminal[name], update[name], "terminal " + name)
            _equal(terminal["ledger_before_observe"], before, "terminal ledger before")
            _equal(terminal["ledger_after_observe"], ledger, "terminal ledger after")
            _require(terminal["targets_formed_before_observe"] is True,
                     "Terminal targets were not formed before its observation")
            if terminal_evidence is None:
                for field in sorted(_TERMINAL_GRADIENT_FIELDS):
                    _require(field in terminal, "Unregistered terminal is missing mandatory derivative graph evidence")
                    _equal(terminal[field], [None, None], "unregistered derivative terminal graph exclusion " + field)
            else:
                terminal_evidence._registry.validate(terminal_evidence, proof, terminal)
                _require(terminal["terminal_new_network_call"] is False, "Terminal added a network call")
                _equal(terminal["targets_before_observe"],
                       {"terminal_output": output, "pure_flow_mse": torch.stack(terms).mean().detach().cpu()},
                       "registered terminal full objectives before observe")
    loss = torch.stack(terms).mean().detach().cpu()
    _equal(proof["loss"], loss, "pure 32-day standardized MSE")
    return {"terminal_output": output, "pure_flow_mse": loss}


def _features(ctx, proof, inputs):
    """Rebuild live recurrent inputs from this trajectory, never original-base features."""
    device = ctx.device
    weather = inputs["warmup_weather"].to(device)
    ledger = weather.new_zeros(274)
    def calendar(day, template):
        first = date(day.year, 1, 1)
        angle = 2.*math.pi*(day-first).days/(date(day.year+1, 1, 1)-first).days
        return template.new_tensor([math.sin(angle), math.cos(angle)])
    rows = [torch.cat((ctx.scaling.weather(row), row.new_tensor([0., 0., 0., 1.]), calendar(day, row)))
            for day, row in zip(WARMUP[-100:], weather[-100:], strict=True)]
    result = []
    for index, day in enumerate(DAYS[:32]):
        _tick(ctx)
        today = inputs["weather"][index].to(device)
        weather = torch.cat((weather, today[None]))
        ledger = torch.cat((ledger, ledger.new_zeros(1)))
        q = proof["predictions"][index]["tensor"].to(device)
        obs = q.new_tensor(float(inputs["observations"][index]))
        normalized_obs = (obs-inputs["flow_mean"])/inputs["flow_std"]
        normalized_prior = (q-inputs["flow_mean"])/inputs["flow_std"]
        error = (obs-q)/inputs["flow_std"]
        row = torch.cat((ctx.scaling.weather(today), torch.stack((normalized_obs, normalized_prior, error,
                                                                 error.new_zeros(()))), calendar(day, today)))
        rows = (rows+[row])[-100:]
        result.append([x.detach().cpu().clone() for x in (torch.stack(rows), ctx.scaling.weather(weather[-100:]),
            ledger[-100:], torch.arange(99, -1, -1, dtype=weather.dtype, device=device))])
        ledger = torch.cat((ledger[:-100], proof["updates"][index]["applied"].to(device)))
    return result


def relative_error(a, b):
    denominator = max(abs(a), abs(b))
    return None if denominator == 0 else abs(a-b)/denominator


def scalar_screen(plus, minus):
    _require(plus.dtype == minus.dtype == torch.float32 and plus.shape == minus.shape == (),
             "Objective scalar is not original float32")
    a, b = np.float32(float(plus)), np.float32(float(minus))
    spacing = max(float(np.nextafter(x, np.float32(np.inf))-x) for x in (a, b))
    spacing = max(spacing, *(float(x-np.nextafter(x, np.float32(-np.inf))) for x in (a, b)))
    difference = abs(float(a)-float(b))
    return {"spacing": spacing, "absolute_difference": difference,
            "resolved": math.isfinite(spacing) and difference >= 32.*spacing}


def representation_screen(base, plus, minus, direction, delta):
    _require(base.dtype == plus.dtype == minus.dtype == direction.dtype == torch.float32
             and base.shape == plus.shape == minus.shape == direction.shape,
             "Parameter representation shape or precision differs")
    b, p, m, d = (x.detach().cpu().double() for x in (base, plus, minus, direction))
    direction_error = float(((p-m)/(2.*delta)-d).abs().max())
    midpoint_error = float(((p+m)/2.-b).abs().max())
    return {"max_direction_deviation": direction_error, "max_midpoint_deviation": midpoint_error,
            "representation_pass": direction_error <= .001 and midpoint_error <= delta*.001}


def classify_local_direction(automatic, rows, objective):
    """Choose the first admitted adjacent pair before any AD comparison."""
    _require(objective in OBJECTIVES and len(rows) == 5
             and [r["delta"] for r in rows] == list(SCALES), "Unregistered direction/scale inventory")
    pair = next(([i, i+1] for i in range(4)
                 if rows[i]["representation_pass"] and rows[i]["resolved"]
                 and rows[i+1]["representation_pass"] and rows[i+1]["resolved"]), None)
    record = {"automatic": automatic, "reference_pair": pair, "effective": False,
              "status": "NUMERICAL_UNCONFIRMED", "smaller_resolved_indices": [], "larger_scale_indices": []}
    if not math.isfinite(automatic) or any(not math.isfinite(r["finite_difference"]) for r in rows):
        record["status"] = "NONFINITE"
        return record
    if pair is None:
        return record
    a, b = (rows[i]["finite_difference"] for i in pair)
    smaller = [i for i in range(pair[0]) if rows[i]["representation_pass"] and rows[i]["resolved"]]
    record["smaller_resolved_indices"], record["larger_scale_indices"] = smaller, list(range(pair[1]+1, 5))
    same = lambda x, y: x*y > 0
    close = lambda x, y: relative_error(x, y) is not None and relative_error(x, y) <= .05
    # A resolved smaller contradiction is never excused by low sensitivity.
    if not same(a, b) or not close(a, b):
        record["status"] = "NOT_CONVERGED"
    elif any(not same(automatic, rows[i]["finite_difference"])
             or not close(automatic, rows[i]["finite_difference"]) for i in smaller + pair):
        record["status"] = "LOCAL_DERIVATIVE_INCONSISTENT"
    elif objective == "terminal_output" and min(abs(automatic), abs(a), abs(b)) < .001:
        record["status"] = "LOW_SENSITIVITY"
    else:
        record["status"], record["effective"] = "PASS", True
    return record


def _original_sources(ctx):
    # This registry supplies only pinned path/date/byte admission. Numerical
    # interpretation, reconstruction, and every decision remain in this file.
    from .saved_context_v04 import OriginalProofRegistry
    registry = OriginalProofRegistry(ctx.require_unchanged)
    rows = registry.result["completed_records"]
    def event(label):
        found = [r for r in rows if r["label"] == label]
        _require(len(found) == 1, "Original event is not unique: " + label)
        return found[0]
    def by_label(label):
        found = [r for r in registry.result["artifacts"]
                 if Path(r["path"]).stem.split("_", 1)[-1] == label]
        _require(len(found) == 1, "Original artifact is not unique: " + label)
        _tick(ctx)
        return _decode(registry.load(found[0]))
    originals = {"bound_inputs": by_label("bound_inputs"), "frozen_before": by_label("frozen_before"),
                 "adapter": _decode(registry.load(event("nonzero_adapter")["proof"])), "groups": {}}
    for group in ("output_parameters", "encoder_parameters"):
        found = [r for r in rows if r["label"] == "parameter_direction" and r["group"] == group]
        _require(len(found) == 3 and [r["direction_index"] for r in found] == [0, 1, 2],
                 "Original six-direction inventory differs")
        base = _decode(registry.load(found[0]["base_proof"]))
        directions = []
        for row in found:
            _equal(row["base_proof"], found[0]["base_proof"], "same original base binding")
            saved = [_decode(registry.load(scale["proof"])) for scale in row["scales"]]
            _require([v["delta"] for v in saved] == [.0001, .001, .01], "Original scales changed")
            for proof in saved[1:]:
                _equal(proof["direction"], saved[0]["direction"], "unchanged original direction bytes")
            directions.append(saved[0]["direction"])
        originals["groups"][group] = {"base": base, "directions": directions}
    a, b = (originals["groups"][g]["base"] for g in ("output_parameters", "encoder_parameters"))
    _equal(a["snapshot"], b["snapshot"], "two original snapshots")
    _equal(a["trajectory"], b["trajectory"], "two original trajectories")
    original_snapshot = _decode(registry.load(registry.config["only_step_proof"]))
    restored = _decode(registry.load(registry.config["restoration_proof"]))
    for proof in (a["snapshot"], restored["before"], restored["after"]):
        _equal(proof, original_snapshot, "original post-update snapshot chain")
    originals["snapshot"] = original_snapshot
    originals["admission"] = registry.identity
    return originals


def _proof(predictions, updates, ledgers, loss):
    return {"loss": loss.detach().cpu().clone(),
            "predictions": [{"date": str(p.date), "observation_cutoff": str(p.observation_cutoff),
                             "locked": p.locked, "state_digest": p.state_digest,
                             "tensor": p.tensor.detach().cpu().clone()} for p in predictions],
            "updates": [{"as_of_date": str(u.as_of_date), "rain_dates": [str(d) for d in u.rain_dates],
                         "raw": u.raw.detach().cpu().clone(), "proposal": u.proposal.detach().cpu().clone(),
                         "applied": u.applied.detach().cpu().clone(), "violation": u.violation.detach().cpu().clone(),
                         "missing": u.missing, "cap": u.cap} for u in updates],
            "ledgers": [v.detach().cpu().clone() for v in ledgers]}


def _independent_forward(ctx, model, inputs, *, fixed=None, derivatives=False, label):
    """Close every complete-window attempt with one full preservation check."""
    try:
        return _independent_forward_body(ctx, model, inputs, fixed=fixed, derivatives=derivatives, label=label)
    finally:
        require_full_preservation(ctx.require_unchanged, begin_operation=False)
        _tick(ctx, require_checkpoint=False)


def _independent_forward_body(ctx, model, inputs, *, fixed=None, derivatives=False, label):
    """Replay unchanged daily observation logic, with an auditor-owned adapter."""
    from ..dynamic_filter import rollout
    from ..dynamic_filter.stream import ObservationStream
    from ..dynamic_filter.protocol import Phase
    _tick(ctx, new_forward=True)
    counter = getattr(ctx, "full_forward_counter", None)
    _require(counter is not None and callable(getattr(counter, "consume", None)),
             "A shared charged full-forward counter is required before model replay")
    counter.consume(label)
    limit = getattr(ctx, "full_forward_limit", 100)
    _require(limit is None or getattr(counter,"count",101) <= limit, "Shared complete-forward cap exceeded")
    if torch.device(ctx.device).type == "cuda":
        torch.cuda.synchronize(ctx.device)
    features = []
    class Adapter(nn.Module):
        def __init__(self):
            super().__init__()
            self.original, self.calls = model, 0
        def forward(self, a, b, c, d):
            index, self.calls = self.calls, self.calls + 1
            _require(index < 33, "Independent adapter exceeded its 33 update dates")
            if index == 32:
                return c
            features.append([t.detach().cpu().clone() for t in (a, b, c, d)])
            if hasattr(self.original, "controls"):
                return self.original.controls[index]
            return self.original(a, b, c, d)
    original_project = rollout.project_rain
    calls = 0
    def extension(raw, proposal, cap):
        nonlocal calls
        index, calls = calls, calls + 1
        _require(index < 33, "Independent extension exceeded 33 projections")
        if index == 32:
            return original_project(raw, proposal, cap)
        codes = fixed[index].to(proposal.device)
        lower, upper = -torch.minimum(raw, proposal.new_tensor(cap)), proposal.new_tensor(cap)
        applied = torch.where(codes == 0, lower, torch.where(codes == 4, upper, proposal))
        violation = (torch.relu(lower-proposal)+torch.relu(proposal-upper))/upper
        return raw+applied, applied, violation
    if fixed is not None:
        rollout.project_rain = extension
    try:
        adapter = Adapter()
        replay = rollout.Replay(ctx.hydro, adapter, ctx.scaling, WARMUP,
                                inputs["warmup_weather"].to(ctx.device), kind="rain", deadline=ctx.deadline-300)
        stream = ObservationStream(Phase("fit", DAYS[0], DAYS[-1]), inputs["observations"])
        predictions, updates, ledgers, terms = [], [], [], []
        for index, current in enumerate(DAYS):
            _tick(ctx)
            pred = replay.predict(current, inputs["weather"][index].to(ctx.device))
            obs = stream.release(pred)
            predictions.append(pred)
            if index:
                terms.append(((pred.tensor-pred.tensor.new_tensor(float(obs.value)))/inputs["flow_std"]).square())
            if index == 32:
                targets = {"terminal_output": (pred.tensor-inputs["flow_mean"])/inputs["flow_std"],
                           "pure_flow_mse": torch.stack(terms).mean()}
                before = replay.applied.detach().cpu().clone()
            updates.append(replay.observe(current, obs.value))
            if index < 32:
                ledgers.append(replay.applied.detach().clone())
        _require(adapter.calls == stream.consumed == 33 and (fixed is None or calls == 33),
                 "Independent replay did not consume the exact schedule")
        terminal = {"proposal": updates[-1].proposal.detach().cpu().clone(),
                    "applied": updates[-1].applied.detach().cpu().clone(),
                    "violation": updates[-1].violation.detach().cpu().clone(),
                    "ledger_before_observe": before, "ledger_after_observe": replay.applied.detach().cpu().clone(),
                    "targets_formed_before_observe": True, "terminal_proposal_objective_grad": [],
                    "terminal_applied_objective_grad": []}
        gradients, adjoints, group_gradients = {}, {}, {}
        if derivatives:
            named = sorted(model.named_parameters())
            for name in OBJECTIVES:
                parameters = [p for _, p in named]
                proposal = [u.proposal for u in updates[:32]]
                applied = [u.applied for u in updates[:32]]
                if name == "terminal_output":
                    for group, prefix in (("output_parameters", "decoder.2."), ("encoder_parameters", "encoder.")):
                        members = [(n, p) for n, p in named if n.startswith(prefix)]
                        values = torch.autograd.grad(targets[name], [p for _, p in members], allow_unused=True,
                                                     retain_graph=True)
                        _require(all(g is not None for g in values), "Original group adjoint is missing")
                        group_gradients[group] = {"names": [n for n, _ in members],
                                                  "sizes": [p.numel() for _, p in members],
                                                  "gradients": [g.detach().cpu().clone() for g in values]}
                # Terminal outputs must remain connected to their preceding
                # ledger but not to the tensors produced by terminal observe.
                pg = torch.autograd.grad(targets[name], parameters, allow_unused=True, retain_graph=True)
                ag = torch.autograd.grad(targets[name], proposal+applied, allow_unused=True, retain_graph=True)
                tg = [torch.autograd.grad(targets[name], t, allow_unused=True, retain_graph=True)[0]
                      for t in (updates[-1].proposal, updates[-1].applied)]
                _require(all(g is not None for g in pg+ag), "Independent objective has a missing gradient")
                _require(tg == [None, None], "Terminal projection enters an objective graph")
                gradients[name] = {n: g.detach().cpu().clone() for (n, _), g in zip(named, pg, strict=True)}
                adjoints[name] = {"proposal": [g.detach().cpu().clone() for g in ag[:32]],
                                  "applied": [g.detach().cpu().clone() for g in ag[32:]]}
                terminal["terminal_proposal_objective_grad"].append(None)
                terminal["terminal_applied_objective_grad"].append(None)
        else:
            terminal["terminal_proposal_objective_grad"] = [None, None]
            terminal["terminal_applied_objective_grad"] = [None, None]
        proof = _proof(predictions, updates, ledgers, targets["pure_flow_mse"])
        calculated = _trajectory(ctx, proof, inputs, fixed=fixed, terminal=terminal)
        _equal(calculated, {n: t.detach().cpu().clone() for n, t in targets.items()}, "replayed objectives")
        return {"trajectory": proof, "targets": calculated, "gradients": gradients,
                "adjoints": adjoints, "features": features, "terminal": terminal,
                "saved_group_gradients": group_gradients}
    finally:
        rollout.project_rain = original_project
        _require(rollout.project_rain is original_project, "Independent extension leaked its module reference")
        if torch.device(ctx.device).type == "cuda":
            torch.cuda.synchronize(ctx.device)


def _check_parameters(model, snapshot):
    named = dict(model.named_parameters())
    _require(sum(p.numel() for p in named.values()) == 5633
             and all(p.dtype == torch.float32 and p.requires_grad for p in named.values()),
             "Original 5,633-parameter constructor or trainability differs")
    _require(set(snapshot["requires_grad"]) == set(named) and all(snapshot["requires_grad"].values()),
             "New explicit constructor trainability proof differs")
    for prefix, expected in GROUP_SIZES.items():
        _require(sum(p.numel() for n, p in named.items() if n.startswith(prefix)) == expected,
                 "Original layer parameter count differs")
    return named


def _adjoint_gate(base, codes):
    mask = (codes == 2).to(torch.float32)
    counts = {}
    for objective in OBJECTIVES:
        pair = base["adjoints"][objective]
        _require(len(pair["proposal"]) == len(pair["applied"]) == 32, "Incomplete proposal/applied adjoints")
        for label in ("proposal", "applied"):
            _require(all(t is not None and t.dtype == torch.float32 and t.shape == (100,)
                         for t in pair[label]), "Missing or malformed action adjoint")
        a, b = torch.stack(pair["proposal"]), torch.stack(pair["applied"])
        _finite((a, b), "actual action adjoints")
        _algebra_equal(a, b*mask, "all 3,200 analytical clipping derivatives")
        if "statuses" in pair:
            for label in ("proposal", "applied"):
                expected = ["ZERO" if bool((t == 0).all()) else "FINITE_NONZERO" for t in pair[label]]
                _equal(pair["statuses"][label], expected, "explicit adjoint zero/nonzero status")
        counts[objective] = {"positions": 3200, "proposal_exact_zero": int((a == 0).sum()),
                             "applied_exact_zero": int((b == 0).sum()), "missing": 0, "nonfinite": 0}
    return counts


def _flat(mapping, names):
    return torch.cat([mapping[name].detach().cpu().reshape(-1) for name in names])


def _audit_gradient_stage(ctx, result, preserved_binding=None):
    """Recompute 90 raw trajectories and 18 decisions, then replay both bases."""
    _tick(ctx)
    _require(result.get("schema") == "precip_local_branch_gradient_v02"
             and result.get("execution_complete") is True and result.get("optimizer_updates") == 0
             and result.get("scales") == list(SCALES) and result.get("objectives") == list(OBJECTIVES),
             "The complete registered derivative evidence is missing")
    preserved = None if preserved_binding is None else _preserved_admission(ctx, result, preserved_binding)
    context_bridge = None if preserved is None else _preserved_context_bridge(ctx, preserved)
    reader = _Reader(ctx, result["artifacts"],
                     proof_root=None if preserved is None else preserved["proof_root"])
    originals = _original_sources(ctx)
    for key in ("registry_sha256", "gradient_result_sha256", "context_identity_sha256", "input_gate_sha256"):
        _equal(result["source_identity"][key], originals["admission"][key], "original fixed source admission")
    saved = originals["snapshot"]
    inputs = _inputs(ctx, originals["bound_inputs"], originals["adapter"])
    outer_rng, frozen = _rng(), _frozen(ctx)
    counter = getattr(ctx, "full_forward_counter", None)
    if preserved is None:
        _require(counter is not None and counter.count == result["full_forward_count"]
                 and counter.count <= 98 and list(counter.labels) == result["full_forward_labels"],
                 "Raw forward receipt differs or has no room for the two charged base replays")
        _require(counter.count == 92 and type(counter.cumulative_count) is int
                 and counter.cumulative_count == result.get("cumulative_full_forward_count")
                 and counter.cumulative_count <= 98,
                 "Expected 92 current-attempt calls and space for two cumulative charged replays")
        _equal(result.get("full_forward_receipts"), counter.receipts, "persistent main forward receipts")
        _persistent_receipts(ctx, counter.receipts, "gradient_full_forward")
    terminal_registry = None if preserved is None else _TerminalEvidenceRegistry(ctx, reader, result, preserved)
    bases, base_terminal_evidence = {}, {}
    for name, item in result["base_proofs"].items():
        base = reader.read(item)
        bases[name] = base
        if terminal_registry is not None:
            base_terminal_evidence[name] = terminal_registry.base(name, base)
    _require(set(bases) == {"original", "extension"}, "Exactly two registered raw bases are required")
    terminal_diagnostic = None if preserved is None else _preserved_terminal_diagnostic(ctx, bases, result, preserved)
    original, extension = bases["original"], bases["extension"]
    original_trajectory = originals["groups"]["output_parameters"]["base"]["trajectory"]
    _equal(original["trajectory"], original_trajectory, "original saved base trajectory")
    codes = branch_codes(original["trajectory"])
    _require(codes.shape == (32, 100) and int((codes == 0).sum()) == 1253
             and int((codes == 2).sum()) == 1947 and not bool(((codes == 1)|(codes == 3)|(codes == 4)).any()),
             "Original complete clipping branch counts differ")
    for key in ("trajectory", "features", "targets", "gradients", "adjoints", "saved_group_gradients",
                "branch_codes", "parameters", "restored_snapshot", "snapshot_before", "requires_grad"):
        _equal(original[key], extension[key], "physical and algebraic base " + key)
    for base_name, base in bases.items():
        _equal(base["snapshot_before"], saved, "base exact original restoration before")
        _equal(base["restored_snapshot"], saved, "base exact original restoration after")
        _equal(base["branch_codes"], codes, "independently reconstructed clipping mask")
        _equal(base["parameters"], {n: saved["state_dict"][n] for n in base["parameters"]}, "base parameter bytes")
        _equal(base["targets"], _trajectory(ctx, base["trajectory"], inputs, terminal=base["terminal"],
                                          terminal_evidence=base_terminal_evidence[base_name] if terminal_registry is not None else None),
               "independently reconstructed base objectives")
        _require(base["terminal"].get("terminal_new_network_call") is False, "Terminal added a network call")
        _equal(base["terminal"]["targets_before_observe"], base["targets"], "objectives formed before terminal")
        _equal(base["features"], _features(ctx, base["trajectory"], inputs), "live closed-loop base features")
        for group in originals["groups"]:
            old = originals["groups"][group]["base"]
            _equal(base["saved_group_gradients"][group],
                   {"names": old["sorted_parameter_names"], "sizes": old["sizes"], "gradients": old["gradients"]},
                   "original separately requested group-only gradient")
    adjoint_counts = _adjoint_gate(original, codes)
    model = None
    decisions, trajectories = [], 0
    try:
        model = ctx.new_network(1001)
        named = _check_parameters(model, original)
        _require(set(original["parameters"]) == set(named), "Raw base parameter inventory differs")
        for objective in OBJECTIVES:
            _require(set(original["gradients"][objective]) == set(named), "Incomplete full-parameter objective gradient")
            for name, parameter in named.items():
                gradient = original["gradients"][objective][name]
                _require(gradient is not None and gradient.dtype == torch.float32 and gradient.shape == parameter.shape,
                         "Missing full-parameter gradient or wrong shape")
        expected_inventory = [("output_parameters", "decoder.2.", i) for i in range(3)] + [
            ("encoder_parameters", "encoder.", i) for i in range(3)] + [
            ("middle_decoder_parameters", "decoder.0.", i) for i in range(3)]
        actual_inventory = [(r["group"], r["prefix"], r["direction_index"]) for r in result["directions"]]
        # The third group's human label does not define mathematical identity;
        # the prescribed prefix, order, dimensions and generator do.
        _require(len(actual_inventory) == 9 and [x[1:] for x in actual_inventory] == [x[1:] for x in expected_inventory]
                 and actual_inventory[:6] == expected_inventory[:6], "Nine-direction registration changed")
        generator = torch.Generator(device="cpu")
        generator.manual_seed(1001)
        for registered in result["directions"]:
            direction_proof = reader.read(registered["direction_proof"])
            prefix, group, index = registered["prefix"], registered["group"], registered["direction_index"]
            names = sorted(n for n in named if n.startswith(prefix))
            sizes = [named[n].numel() for n in names]
            _equal(registered["names"], names, "direction sorted names")
            _equal(registered["sizes"], sizes, "direction storage sizes")
            for name in ("names", "sizes", "group", "prefix", "direction_index"):
                _equal(direction_proof[name], registered[name], "direction proof identity")
            direction = direction_proof["direction"]
            _require(direction.dtype == torch.float32 and direction.shape == (GROUP_SIZES[prefix],)
                     and float(direction.abs().max()) == 1., "Direction representation or normalization differs")
            if prefix != "decoder.0.":
                _equal(direction, originals["groups"][group]["directions"][index], "original six direction bytes")
                _require(direction_proof["generator_before"] is None and direction_proof["generator_after"] is None
                         and direction_proof["original_saved_direction"] is True, "Original direction was redrawn")
            else:
                _equal(direction_proof["generator_before"], generator.get_state(), "supplemental generator before")
                sample = torch.randn((1280,), generator=generator, dtype=torch.float32)
                _equal(direction, sample/sample.abs().max(), "fixed supplemental CPU direction")
                _equal(direction_proof["generator_after"], generator.get_state(), "supplemental generator after")
                _require(direction_proof["generator_seed"] == 1001
                         and direction_proof["original_saved_direction"] is False, "Supplemental generator identity differs")
            automatic = {objective: float((_flat(original["gradients"][objective], names).to(ctx.device)
                                         * direction.to(ctx.device)).sum()) for objective in OBJECTIVES}
            _equal(registered["automatic"], automatic, "independent float32 directional derivative")
            _require([s["delta"] for s in registered["scales"]] == list(SCALES), "Five-scale inventory changed")
            rows = {objective: [] for objective in OBJECTIVES}
            for scale in registered["scales"]:
                delta, proof = scale["delta"], reader.read(scale["proof"])
                endpoint_terminal_evidence = None if terminal_registry is None else terminal_registry.endpoints(registered, scale, proof)
                for name in ("group", "prefix", "direction_index", "names", "sizes"):
                    _equal(proof[name], registered[name], "pair registration")
                _equal(proof["direction"], direction, "pair direction bytes")
                _equal(proof["base_parameters"], original["parameters"], "pair exact original base")
                _equal(proof["base_branches"], codes, "pair fixed original branch mask")
                _equal(proof["automatic"], automatic, "pair independently computed AD")
                targets = {}
                for sign, endpoint_name in ((1., "plus"), (-1., "minus")):
                    endpoint = proof[endpoint_name]
                    _equal(endpoint["snapshot_before"], saved, "endpoint restored before")
                    _equal(endpoint["restored_snapshot"], saved, "endpoint restored after")
                    _require(set(endpoint["parameters"]) == set(named), "Endpoint parameter inventory differs")
                    offset = 0
                    for name, parameter in sorted(named.items()):
                        expected = original["parameters"][name].to(ctx.device).clone()
                        if name in names:
                            count = expected.numel()
                            expected.add_(sign*delta*direction[offset:offset+count].to(ctx.device).reshape(expected.shape))
                            offset += count
                        _equal(endpoint["parameters"][name], expected.detach().cpu(), "actual float32 parameter offset")
                    targets[endpoint_name] = _trajectory(ctx, endpoint["trajectory"], inputs, fixed=codes,
                                                        terminal=endpoint["terminal"],
                                                        terminal_evidence=endpoint_terminal_evidence[endpoint_name] if terminal_registry is not None else None)
                    _equal(endpoint["targets"], targets[endpoint_name], "independently rebuilt endpoint objective")
                    _require(len(endpoint["features"]) == 32 and not endpoint["terminal"]["terminal_new_network_call"],
                             "Endpoint did not run current complete network on exactly 32 updates")
                    _equal(endpoint["terminal"]["targets_before_observe"], targets[endpoint_name],
                           "endpoint terminal objective exclusion")
                    _equal(endpoint["features"], _features(ctx, endpoint["trajectory"], inputs),
                           "current endpoint complete closed-loop features")
                    trajectories += 1
                representation = representation_screen(_flat(original["parameters"], names),
                    _flat(proof["plus"]["parameters"], names), _flat(proof["minus"]["parameters"], names), direction, delta)
                for name in ("max_direction_deviation", "max_midpoint_deviation"):
                    _equal(proof["representation"][name], representation[name], "parameter representation metadata")
                _equal(proof["representation"]["resolved"], representation["representation_pass"],
                       "parameter screen decision")
                b, p, m = (_flat(source, names).double() for source in
                           (original["parameters"], proof["plus"]["parameters"], proof["minus"]["parameters"]))
                _equal(proof["representation"]["actual_center_direction"], (p-m)/(2*delta), "actual central direction")
                _equal(proof["representation"]["actual_midpoint"], (p+m)/2, "actual parameter midpoint")
                for objective in OBJECTIVES:
                    screen = scalar_screen(targets["plus"][objective], targets["minus"][objective])
                    scalar = proof["scalar_resolution"][objective]
                    _equal(scalar, {"plus": float(targets["plus"][objective]), "minus": float(targets["minus"][objective]),
                                    "unit_spacing": screen["spacing"], "difference_absolute": screen["absolute_difference"],
                                    "required_spacing_multiple": 32, "resolved": screen["resolved"]},
                           "independent ULP screen")
                    rows[objective].append({"delta": delta, "finite_difference": (scalar["plus"]-scalar["minus"])/(2*delta),
                        "representation_pass": representation["representation_pass"], "resolved": screen["resolved"],
                        "primary_row": {"delta": delta, "finite_difference": (scalar["plus"]-scalar["minus"])/(2*delta),
                            "representation_resolved": representation["representation_pass"], "scalar_resolved": screen["resolved"],
                            "plus": scalar["plus"], "minus": scalar["minus"],
                            "max_direction_deviation": representation["max_direction_deviation"],
                            "max_midpoint_deviation": representation["max_midpoint_deviation"],
                            "unit_spacing": screen["spacing"], "difference_absolute": screen["absolute_difference"],
                            "proof": scale["proof"]}})
            for objective in OBJECTIVES:
                decision = classify_local_direction(automatic[objective], rows[objective], objective)
                found = [r for r in result["numerical_records"] if r["group"] == group
                         and r["direction_index"] == index and r["objective"] == objective]
                _require(len(found) == 1, "A registered objective decision is missing or duplicated")
                primary = found[0]
                for name in ("automatic", "status", "reference_pair", "effective"):
                    _equal(primary[name], decision[name], "independent unique-reference decision")
                _equal(primary["rows"], [r["primary_row"] for r in rows[objective]], "all five independent scalar rows")
                pair = decision["reference_pair"]
                large = [] if pair is None else [i for i in range(pair[1]+1, 5)
                    if automatic[objective]*rows[objective][i]["finite_difference"] <= 0
                    or relative_error(automatic[objective], rows[objective][i]["finite_difference"]) is None
                    or relative_error(automatic[objective], rows[objective][i]["finite_difference"]) > .05]
                _equal(primary["larger_scale_curvature_rows"], large, "preserved larger-scale differences")
                decision.update({"objective": objective, "group": group, "direction_index": index})
                decisions.append(decision)
        _require(trajectories == 90 and len(decisions) == len(result["numerical_records"]) == 18,
                 "Incomplete 90-trajectory / 18-objective independent recomputation")
        final = reader.read(result["final_restoration"])
        _equal(final["snapshot"], saved, "final original runtime restoration")
        _require(final["all_gradients_none"] is True and result["projection_reference_restored"] is True,
                 "Runtime restoration is incomplete")
        rng_proof = reader.read(result["outer_rng_restoration"])
        _equal(rng_proof["before"], rng_proof["after"], "primary outer random-state restoration")
        for name in ("frozen_before", "frozen_after"):
            raw_frozen = reader.read(result[name])
            _equal(raw_frozen["state_dict"], frozen["state_dict"], "protected frozen state " + name)
            _equal(raw_frozen["modes"], frozen["modes"], "protected frozen modes " + name)
        # These two original-model replays are the only additional complete
        # forwards; both consume the caller's shared count and deadline.
        new_base_proofs = []
        for name, fixed in (("original", None), ("extension", codes)):
            _restore_model(model, saved)
            rebuilt = _independent_forward(ctx, model, inputs, fixed=fixed, derivatives=True,
                                           label="independent_base_"+name)
            if preserved is not None:
                new_base_proofs.append(_save_new_audit_base(ctx, name, rebuilt, result, preserved))
            for key in ("trajectory", "targets", "gradients", "features", "saved_group_gradients"):
                _equal(rebuilt[key], bases[name][key], "independent actual base replay " + key)
            for objective in OBJECTIVES:
                for label in ("proposal", "applied"):
                    _equal(rebuilt["adjoints"][objective][label], bases[name]["adjoints"][objective][label],
                           "independent actual base adjoints")
            _adjoint_gate(rebuilt, codes)
        _equal(frozen, _frozen(ctx), "independent auditor frozen-model invariance")
        if preserved is None:
            _require(counter.count == 94 and type(counter.cumulative_count) is int and counter.cumulative_count <= 100,
                     "Exactly 94 current-attempt complete calls and the cumulative 100-call cap are required")
        else:
            _preserved_receipts(ctx, result, preserved, final=True)
            _equal(_preserved_context_bridge(ctx, preserved), context_bridge,
                   "unchanged complete old/current context bridge after independent work")
        _persistent_receipts(ctx, counter.receipts, "gradient_full_forward")
        passed = all(r["effective"] for r in decisions)
        _require(reader.used == set(reader.items), "Unconsumed raw artifact in the complete proof inventory")
        report = {"status": "PASS" if passed else "BLOCKED_OR_UNCONFIRMED", "pass": passed,
                "stage": "gradient", "independent_checks_passed": True, "raw_trajectories_checked": trajectories,
                "objective_directions_checked": 18, "decisions": decisions, "adjoint_counts": adjoint_counts,
                "independent_model_replays": 2, "full_forward_count": counter.count,
                "cumulative_full_forward_count": counter.cumulative_count,
                "full_forward_receipts": list(counter.receipts),
                "persistent_counters": ctx.operation_runtime.counter_snapshot(),
                "original_admission": originals["admission"], "model_inference_by_auditor": True,
                "scientific_fit_or_forecast_claim": False}
        if preserved is not None:
            _require(not passed, "The three preserved nonconverged decisions cannot become a pass")
            report.update({"preserved_evidence_mode": True, "original_evidence_forward_count": 92,
                           "new_audit_forward_count": 2, "combined_evidence_forward_count": 94,
                           "original_result_identity": preserved["result_identity"],
                           "original_failure_identity": preserved["failure_identity"],
                           "original_forward_receipts": result["full_forward_receipts"],
                           "binding_sha256": _canonical_digest(preserved),
                           "scientific_context_bridge": context_bridge,
                           "terminal_bit_pattern_diagnostic": terminal_diagnostic,
                           "terminal_evidence_schema": "precip_preserved_terminal_evidence_registry_v06",
                           "terminal_schema_preflight": terminal_registry.preflight_identity,
                           "fixed_original_writer_identity": terminal_registry.writer_identity,
                           "new_actual_base_proofs": new_base_proofs,
                           "later_fitting_prohibited": True, "new_fitting_executed": False})
        return report
    finally:
        if model is not None:
            _restore_model(model, saved)
        _restore_rng(outer_rng)
        _equal(outer_rng, _rng(), "independent auditor random-state restoration")
        _equal(frozen, _frozen(ctx), "independent auditor frozen state on exit")
        _tick(ctx)


class _Controls(nn.Module):
    def __init__(self, values, device):
        super().__init__()
        _require(values.shape == (32, 100) and values.dtype == torch.float32, "Malformed direct control table")
        self.controls = nn.Parameter(values.detach().to(device).clone())


def _optimizer_gate(value, model, step, lr):
    _require(len(value["param_groups"]) == 1, "Adam group inventory differs")
    group = value["param_groups"][0]
    expected = {"lr": lr, "betas": (.9, .999), "eps": 1e-8, "weight_decay": 0., "amsgrad": False,
                "maximize": False, "foreach": None, "capturable": False, "differentiable": False, "fused": None}
    _require(all(group.get(k) == v for k, v in expected.items()), "Original Adam prescription changed")
    parameters = list(model.parameters())
    _require(group["params"] == list(range(len(parameters))), "Adam parameter order differs")
    _require(set(value["state"]) == (set() if step == 0 else set(group["params"])), "Adam moment inventory differs")
    for key, parameter in zip(group["params"], parameters, strict=True):
        if step:
            state = value["state"][key]
            _require(set(state) == {"step", "exp_avg", "exp_avg_sq"} and float(state["step"]) == step,
                     "Adam state step differs from the evaluated parameter state")
            _require(state["exp_avg"].shape == state["exp_avg_sq"].shape == parameter.shape
                     and state["exp_avg"].dtype == state["exp_avg_sq"].dtype == torch.float32,
                     "Adam state precision or shape differs")


def _diagnostics(reader, directory, k, model, trajectory):
    values = reader.read(directory / f"step_{k:04d}_diagnostics.npz")
    named = list(model.named_parameters())
    names = [n for n, _ in named]
    expected = {"predictions", "proposal", "applied", "raw", "proposal_gradient", "applied_gradient",
                "proposal_gradient_missing", "applied_gradient_missing", "parameter_gradient_missing",
                *("parameter_gradient__"+n.replace(".", "_") for n in names)}
    _require(set(values) == expected, "Raw fitting gradient archive inventory differs")
    for name in ("proposal", "applied", "raw"):
        _equal(values[name], torch.stack([u[name] for u in trajectory["updates"][:32]]).numpy(), "fitting raw " + name)
    _equal(values["predictions"], np.asarray([float(p["tensor"]) for p in trajectory["predictions"]]),
           "fitting raw predictions")
    gradients = []
    missing = values["parameter_gradient_missing"]
    _require(missing.shape == (len(named),) and missing.dtype == np.bool_ and not missing.any(),
             "A fitting parameter gradient is missing")
    for name, parameter in named:
        gradient = values["parameter_gradient__"+name.replace(".", "_")]
        _require(gradient.dtype == np.float32 and gradient.shape == tuple(parameter.shape),
                 "Fitting parameter gradient shape/precision differs")
        gradients.append(torch.from_numpy(gradient.copy()).to(parameter.device))
    for name in ("proposal", "applied"):
        _require(values[name+"_gradient_missing"].shape == (32,)
                 and values[name+"_gradient_missing"].dtype == np.bool_
                 and not values[name+"_gradient_missing"].any(), "A fitting action gradient is missing")
        _require(values[name+"_gradient"].shape == (32, 100)
                 and values[name+"_gradient"].dtype == np.float32, "Fitting action gradient shape differs")
    codes = branch_codes(trajectory)
    outside = ((codes == 0)|(codes == 4)).numpy()
    _require(not (values["proposal_gradient"][outside] != 0).any(), "Clipped fitting action retains a proposal gradient")
    return gradients


def audit_fit_stage(ctx, result):
    """Rebuild all states and Adam updates; actually reload the earliest best."""
    _tick(ctx)
    stage = result.get("stage")
    _require(stage in ("direct_control", "network") and result.get("execution_complete") is True
             and result.get("forecast_efficacy_confirmed") is False, "Incomplete registered fitting stage")
    seeds = [None] if stage == "direct_control" else [1001, 1002, 1003]
    _require([r["seed"] for r in result["runs"]] == seeds and result["run_denominator"] == len(seeds),
             "Missing or replaced registered fitting initialization")
    reader = _Reader(ctx, result["fit_raw_artifacts"])
    sources = _original_sources(ctx)
    outer_rng, frozen = _rng(), _frozen(ctx)
    reports, replay_count, updates_checked, reconstruction_receipts = [], 0, 0, []
    try:
        for run in result["runs"]:
            _tick(ctx)
            seed = run["seed"]
            ctx.forward_key = "direct_control" if seed is None else "seed_" + str(seed)
            directory = Path(ctx.output) / ("control" if seed is None else f"seed_{seed}")
            _require(run["output"] == str(directory) and run["algorithm_completed"] is True
                     and run["forecast_efficacy_claim"] is False, "Run identity or scientific scope changed")
            _equal(reader.read(directory/"fit_result.json"), run, "saved fit result")
            last = run["updates_completed"]
            _require(type(last) is int and 0 <= last <= 1000, "Unregistered optimizer update count")
            update_paths = [str(directory / f"update_{k:04d}_before_projection.pt") for k in range(1, last+1)]
            audit_attempt = str(ctx.attempt_id) + "/audit_" + stage + ("_control" if seed is None else f"_seed_{seed}")
            binding = {"saved_path": str(directory / "fit_result.json"),
                       "saved_path_sha256": _sha(directory / "fit_result.json"),
                       "stage": stage, "seed": seed, "updates": update_paths}
            if update_paths:
                ctx.operation_runtime.bind_audit(audit_attempt, binding, update_paths)
            _require(run.get("technical_incomplete_due_to_cumulative_update_limit") is False,
                     "A shortened technical-repair path cannot receive complete scientific negative acceptance")
            training_receipts = run.get("scientific_update_receipts")
            before_count = run.get("scientific_update_count_before_attempt")
            _require(isinstance(training_receipts, list) and len(training_receipts) == last
                     and type(before_count) is int and 0 <= before_count <= 1000
                     and before_count + last == run.get("cumulative_scientific_updates") <= 1000,
                     "Scientific training receipts/cumulative count do not bind the actual path")
            _persistent_receipts(ctx, training_receipts,
                "direct_science_update" if seed is None else "network_" + str(seed) + "_science_update")
            for pattern, expected in (("state_*.pt", {f"state_{k:04d}.pt" for k in range(last+1)}),
                ("step_*.json", {f"step_{k:04d}.json" for k in range(last+1)}),
                ("update_*_before_projection.pt", {f"update_{k:04d}_before_projection.pt" for k in range(1,last+1)})):
                _require({p.name for p in directory.glob(pattern)} == expected, "Missing or hidden fitting state/update")
            bound = reader.read(directory/"bound_inputs.pt")
            inputs = _inputs(ctx, bound)
            _equal(bound["frozen_before"], frozen["state_dict"], "bound frozen model")
            _equal(bound["hydro_modes"], frozen["modes"], "bound frozen model modes")
            model = _Controls(torch.zeros((32,100), dtype=torch.float32), ctx.device) if seed is None else ctx.new_network(seed)
            initial_reference = {n: v.detach().cpu().clone() for n, v in model.state_dict().items()}
            initial = reader.read(directory/"initial.pt")
            _require(initial["seed"] == seed and initial["updates_completed"] == 0, "Incorrect formal initialization")
            _equal(initial["state_dict"], initial_reference, "original zero-output formal initialization")
            for key in ("state_dict", "optimizer", "rng"):
                _equal(initial[key], initial["snapshot"][key], "initial full snapshot binding")
            lr = .1 if seed is None else .001
            optimizer = torch.optim.Adam(model.parameters(), lr=lr, betas=(.9,.999), eps=1e-8, weight_decay=0.)
            _optimizer_gate(initial["optimizer"], model, 0, lr)
            states, errors, best_step, best_loss, checkpoints = {}, [], None, math.inf, []
            for k in range(last+1):
                _tick(ctx)
                state = reader.read(directory/f"state_{k:04d}.pt")
                states[k] = state
                _require(state["updates_completed"] == k, "Evaluated state has the wrong update count")
                for key in ("state_dict", "optimizer"):
                    _equal(state[key], state["snapshot"][key], "evaluated state/snapshot binding")
                if k == 0:
                    _equal(state["state_dict"], initial_reference, "state zero original initialization")
                    _equal(state["optimizer"], initial["optimizer"], "state zero original empty Adam")
                _restore_model(model, state["snapshot"], optimizer)
                _optimizer_gate(state["optimizer"], model, k, lr)
                targets = _trajectory(ctx, state["trajectory"], inputs)
                loss = float(targets["pure_flow_mse"])
                _require(state["mse"] == loss, "Recorded fitting loss differs from all 32 actual targets")
                errors.append(loss)
                if loss < best_loss:
                    best_step, best_loss = k, loss
                step = reader.read(directory/f"step_{k:04d}.json")
                _require(step["updates_completed"] == k and step["mse"] == loss and step["best_step"] == best_step
                         and step["best_mse"] == best_loss
                         and step["parameter_names"] == [n for n, _ in model.named_parameters()],
                         "Earliest best state or update/loss binding differs")
                lower = torch.stack([-torch.minimum(u["raw"], u["raw"].new_tensor(CAP))
                                     for u in state["trajectory"]["updates"][:32]])
                upper = torch.full_like(lower, CAP)
                _equal(bound["lower"], lower, "physical lower rain limits")
                _equal(bound["upper"], upper, "physical upper rain limits")
                proposal = torch.stack([u["proposal"] for u in state["trajectory"]["updates"][:32]])
                applied = torch.stack([u["applied"] for u in state["trajectory"]["updates"][:32]])
                counts = {"proposal_items":3200, "strictly_below":int((proposal < lower).sum()),
                          "strictly_above":int((proposal > upper).sum()), "at_lower":int((proposal == lower).sum()),
                          "at_upper":int((proposal == upper).sum())}
                _require(all(step[n] == value for n, value in counts.items()), "Recorded physical bound counts differ")
                if seed is None:
                    _equal(proposal, state["state_dict"]["controls"], "direct controls equal actual proposals")
                    _equal(proposal, applied, "direct controls remain feasible before evaluation")
                gradients = _diagnostics(reader, directory, k, model, state["trajectory"])
                checkpoint = k % 10 == 0 or k == last
                if checkpoint:
                    checkpoints.append(k)
                    proof = reader.read(directory/f"best_proof_at_{k:04d}.pt")
                    _require(proof["current_step"] == k and proof["best_step"] == best_step
                             and proof["best_mse"] == best_loss, "Checkpoint selected a later/nonminimal loss state")
                    _equal(proof["best_state_dict"], states[best_step]["state_dict"], "checkpoint selected parameter bytes")
                    proof_loss = float(_trajectory(ctx, proof["trajectory"], inputs)["pure_flow_mse"])
                    imported_loss = float(_trajectory(ctx, proof["imported"], inputs)["pure_flow_mse"])
                    _require(proof_loss == imported_loss == best_loss, "Checkpoint best loss or feasible-table loss differs")
                    controls = reader.read(directory/f"best_controls_at_{k:04d}.pt")
                    _equal(controls, torch.stack([u["applied"] for u in proof["trajectory"]["updates"][:32]]),
                           "checkpoint full feasible control table")
                    _require(bool(((controls >= lower)&(controls <= upper)).all()), "Saved best controls violate bounds")
                    _equal(proof["trajectory"]["predictions"], proof["imported"]["predictions"], "network/control checkpoint predictions")
                    _equal(proof["trajectory"]["ledgers"], proof["imported"]["ledgers"], "network/control checkpoint ledgers")
                    _equal(reader.read(directory/f"best_replay_at_{k:04d}.npy"),
                           np.asarray([float(p["tensor"]) for p in proof["trajectory"]["predictions"]]),
                           "checkpoint prediction record")
                    gate = errors[0] > .0001 and best_loss <= .0001 and 1.-best_loss/errors[0] >= .99
                    _equal(step["best_replay"], {"mse":best_loss,"achieved":gate,"initial_already_satisfied":errors[0]<=.0001},
                           "both prespecified fitting thresholds")
                    _require(not gate or k == last, "Fitting continued after registered success")
                if k < last:
                    _restore_model(model, state["snapshot"], optimizer)
                    for parameter, gradient in zip(model.parameters(), gradients, strict=True):
                        parameter.grad = gradient.detach().clone()
                    training_receipt = reader.read(directory/f"scientific_update_receipt_{k+1:04d}.json")
                    _equal(training_receipt, training_receipts[k], "actual scientific update receipt")
                    _require(training_receipt.get("cumulative_count") == before_count + k + 1,
                             "Scientific cumulative update receipt differs")
                    event = training_receipt["record"]["payload"]["event"]
                    _require(event.get("label") == f"{stage}/{seed}/update_{k+1:04d}"
                             and event.get("update_id") is None,
                             "Scientific training receipt does not bind the saved update without audit exemption")
                    update_id = update_paths[k]
                    # Rebuilding an already saved update cannot advance any
                    # training state or candidate. This audit owns its model.
                    _tick(ctx)
                    receipt = ctx.operation_runtime.consume("audit_reconstruction", audit_attempt,
                        f"rebuild_{k+1:04d}", bindings={"update_id": update_id,
                        "saved_path_sha256": _sha(update_id), "audit_binding": binding})
                    reconstruction_receipts.append(receipt)
                    optimizer.step()
                    _finite((model.state_dict(),optimizer.state_dict()), "independently rebuilt Adam update")
                    updated = {n:v.detach().cpu().clone() for n,v in model.state_dict().items()}
                    proof = reader.read(directory/f"update_{k+1:04d}_before_projection.pt")
                    _require(proof["updates_completed"] == k+1, "Updated Adam state count differs")
                    _equal(proof["before_state_dict"], state["state_dict"], "saved pre-update parameters")
                    _equal(proof["state_dict"], updated, "independent Adam parameter update")
                    _equal(proof["optimizer"], optimizer.state_dict(), "independent Adam moment update")
                    if seed is None:
                        projection = reader.read(directory/f"projection_{k+1:04d}.pt")
                        _require(projection["update"] == k+1, "Direct physical projection update count differs")
                        _equal(projection["before_projection"], updated["controls"], "unprojected Adam controls")
                        with torch.no_grad():
                            model.controls.copy_(torch.maximum(lower.to(ctx.device),torch.minimum(model.controls,upper.to(ctx.device))))
                        _equal(projection["after_projection"], model.controls.detach().cpu(), "independent physical projection")
                    following = reader.read(directory/f"state_{k+1:04d}.pt")
                    _equal(following["state_dict"], {n:v.detach().cpu() for n,v in model.state_dict().items()},
                           "next evaluated state follows one Adam update")
                    _equal(following["optimizer"], optimizer.state_dict(), "next evaluated Adam moments")
                    change = max(float((following["state_dict"][n]-v).abs().max()) for n,v in state["state_dict"].items())
                    _equal(reader.read(directory/f"parameter_change_{k+1:04d}.json"),
                           {"from_step":k,"to_step":k+1,"absolute_max":change}, "parameter change record")
                    updates_checked += 1
            _require(run["initial_mse"] == errors[0] and run["last_mse"] == errors[-1]
                     and run["best_mse"] == best_loss and run["best_step"] == best_step,
                     "Final fit summary is not bound to the evaluated earliest best")
            uninformative = errors[0] <= .0001
            _require(run["initial_already_satisfied"] is uninformative
                     and (not uninformative or last == 0),
                     "An already-satisfied window must stop without scientific updates")
            gate = errors[0] > .0001 and best_loss <= .0001 and 1.-best_loss/errors[0] >= .99
            _require(run["fit_gate_pass"] is gate and (gate or last == 1000 or uninformative),
                     "Incomplete optimizer search was labeled complete")
            best = reader.read(directory/"best.pt")
            _require(best["updates_completed"] == best_step and best["mse"] == best_loss, "Best checkpoint count/loss differs")
            _equal(best["state_dict"], states[best_step]["state_dict"], "best checkpoint full state")
            selected = states[best_step]
            _restore_model(model, selected["snapshot"])
            with torch.no_grad():
                rebuilt = _independent_forward(ctx, model, inputs, label=f"independent_best_{seed}")
            replay_count += 1
            _equal(rebuilt["trajectory"], selected["trajectory"], "actual reloaded minimum-loss parameters")
            _require(float(rebuilt["targets"]["pure_flow_mse"]) == best_loss, "Actual reloaded minimum loss differs")
            controls = torch.stack([u["applied"] for u in rebuilt["trajectory"]["updates"][:32]])
            with torch.no_grad():
                imported = _independent_forward(ctx, _Controls(controls,ctx.device), inputs,
                                                label=f"independent_best_controls_{seed}")
            replay_count += 1
            for key in ("predictions","ledgers","loss"):
                _equal(rebuilt["trajectory"][key], imported["trajectory"][key], "actual reloaded best/control equivalence")
            initial_predictions = reader.read(directory/"initial_predictions.npy")
            _equal(initial_predictions, np.asarray([float(p["tensor"]) for p in states[0]["trajectory"]["predictions"]]),
                   "original initialization prediction record")
            if seed is None:
                zero = reader.read(directory/"zero_network_baseline.pt")
                network = ctx.new_network(1001)
                _equal(zero["state_dict"], {n:v.detach().cpu() for n,v in network.state_dict().items()},
                       "original zero-output network initialization")
                with torch.no_grad():
                    baseline = _independent_forward(ctx,network,inputs,label="independent_zero_network_baseline")
                replay_count += 1
                _equal(zero["trajectory"],baseline["trajectory"], "actual original zero-network baseline")
                _equal(baseline["trajectory"],states[0]["trajectory"], "zero-network and zero-control initial trajectory")
            else:
                predecessor_root = getattr(ctx,"direct_control_output",None)
                predecessor_artifacts = getattr(ctx,"direct_control_artifacts",None)
                _require(predecessor_root is not None and predecessor_artifacts is not None,
                         "Missing byte-bound new direct-control predecessor")
                prior_ctx = copy.copy(ctx)
                prior_ctx.output = Path(predecessor_root)
                prior = _Reader(prior_ctx,predecessor_artifacts)
                _equal(initial_predictions,prior.read(Path(predecessor_root)/"control/initial_predictions.npy"),
                       "all three network seeds versus new direct-control zero baseline")
            after = reader.read(directory/"hydro_after.pt")
            _equal(after["frozen_after"],frozen["state_dict"], "fit did not change frozen-model state")
            _equal(after["modes"],frozen["modes"], "fit did not change frozen-model modes")
            reports.append({"seed":seed,"updates_completed_verified":last,"evaluated_states_verified":last+1,
                            "initial_mse":errors[0],"last_mse":errors[-1],"selected_step":best_step,
                            "selected_mse":best_loss,"relative_reduction":None if errors[0] == 0 else 1.-best_loss/errors[0],
                            "fit_gate_pass":gate,"checkpoints_verified":checkpoints,
                            "all_updates_rebuilt":True,"actual_best_reloaded":True,
                            "window_uninformative":uninformative,"audit_binding":binding,
                            "scientific_updates_verified":last,
                            "scientific_cumulative_updates":before_count+last})
        _require(result["fit_gate_pass_count"] == sum(r["fit_gate_pass"] for r in reports),
                 "Reported passing-seed count differs")
        _equal(frozen,_frozen(ctx),"independent fitting audit frozen-model invariance")
        _persistent_receipts(ctx,reconstruction_receipts,"audit_reconstruction")
        return {"status":"PASS","pass":True,"stage":stage,"independent_checks_passed":True,
                "model_inference_by_auditor":True,"independent_model_replays":replay_count,
                "optimizer_updates_independently_rebuilt":updates_checked,"audited_runs":reports,
                "audit_reconstruction_receipts":reconstruction_receipts,
                "persistent_counters":ctx.operation_runtime.counter_snapshot(),
                "window_uninformative":any(r["window_uninformative"] for r in reports),
                "scientific_fit_or_forecast_claim":False,"no_fit_failure_implies_mathematical_unreachability":True}
    finally:
        _restore_rng(outer_rng)
        _equal(outer_rng,_rng(),"independent fitting audit random-state restoration")
        _equal(frozen,_frozen(ctx),"independent fitting audit frozen state on exit")
        _tick(ctx)
