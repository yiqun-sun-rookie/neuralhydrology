"""SLURM-owned Linux supervisor; no numeric import in the controlling process."""
import argparse
import fcntl
import json
from multiprocessing.connection import Listener
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import traceback

from precip_input_assimilation.hpc.precip_smallfit_runtime_v01 import Authority, Budget, Owner, sha, validate_exploration, write_json


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", required=True, type=Path)
    p.add_argument("--manifest-sha256", required=True)
    a = p.parse_args()
    root = a.root.absolute()
    expected_parent = Path("/data1/home/sunyiq/precip_smallfit_hpc_20261012_v01")
    if root.parent != expected_parent or root.is_symlink() or root.resolve() != root or not os.environ.get("SLURM_JOB_ID"):
        raise PermissionError("Only the private task root on a SLURM compute node is admitted")
    manifest_path = root / "payload/manifest.json"
    if sha(manifest_path) != a.manifest_sha256:
        raise PermissionError("Payload does not match the independent code approval")
    manifest = json.loads(manifest_path.read_text())
    if manifest["remote_root"] != str(root) or manifest["recipe"]["seeds"] != [1001]:
        raise PermissionError("Private run identity or seed scope changed")
    lock = (expected_parent / "exclusive.lock").open("a+b")
    fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    (root / "runtime").mkdir()
    (root / "logs").mkdir(exist_ok=True)
    owner = Owner(root, manifest)
    write_json(root / "runtime/owner.json", {"pid": os.getpid(), "creation_ticks": owner.owner_start,
               "job_id": os.environ["SLURM_JOB_ID"], "nonce": manifest["nonce"], "status": "RUNNING"})
    owner.verify_sources()
    audit = json.loads((root / "payload" / manifest["saved_sources"]["completed_audit"]["path"]).read_text())
    validate_exploration(audit)
    counters = root / "runtime/counters"
    import shutil
    shutil.copytree(root / "payload/counters", counters)
    budget = Budget(root, manifest, owner)
    authority = Authority(root, manifest, owner, budget)
    child, tests, listener, connection = None, None, None, None
    failure = None
    try:
        owner.verify_dependencies()
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTEST_DISABLE_PLUGIN_AUTOLOAD="1")
        test_file = root / "payload/code/src/precip_input_assimilation/tests/test_hpc_smallfit_admission_v01.py"
        with (root / "logs/targeted_checks.log").open("xb") as log:
            tests = subprocess.Popen([sys.executable, "-B", str(test_file)], env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            while tests.poll() is None:
                budget.tick(); time.sleep(.25)
            write_json(root / "runtime/targeted_checks.json", {"tests": 4, "returncode": tests.returncode,
                       "log_sha256": sha(root / "logs/targeted_checks.log"), "original_990_reexecuted": False})
            if tests.returncode:
                raise RuntimeError("The four targeted HPC checks failed before science")
        owner.verify_sources()
        listener = Listener(str(root / "runtime/owner.sock"), family="AF_UNIX", authkey=bytes.fromhex(manifest["nonce"]))
        listener._listener._socket.settimeout(1.)
        worker = root / "payload/code/src/precip_input_assimilation/hpc/precip_smallfit_worker_v01.py"
        with (root / "logs/numerical_worker.log").open("xb") as log:
            child = subprocess.Popen([sys.executable, "-u", "-B", str(worker), "--root", str(root),
                                      "--manifest-sha256", a.manifest_sha256], env=env, stdout=log, stderr=subprocess.STDOUT,
                                     start_new_session=True)
            write_json(root / "runtime/numerical_worker_identity.json", {"pid": child.pid,
                       "creation_ticks": Path("/proc/" + str(child.pid) + "/stat").read_text().rsplit(")", 1)[1].split()[19],
                       "pgid": child.pid, "job_id": os.environ["SLURM_JOB_ID"]})
            while connection is None:
                budget.tick()
                if child.poll() is not None:
                    raise RuntimeError("Worker exited before connecting to its budget owner")
                try:
                    connection = listener.accept()
                except socket.timeout:
                    pass
            while child.poll() is None:
                budget.tick()
                if connection.poll(.5):
                    try:
                        message = connection.recv()
                    except EOFError:
                        child.wait(timeout=300)
                        break
                    try:
                        value = authority.handle(message)
                        response = {"ok": True, "value": value}
                    except BaseException as error:
                        response = {"ok": False, "error": type(error).__name__ + ": " + str(error)}
                        failure = response["error"]
                    connection.send(response)
                if time.monotonic() - owner.last_progress > 5:
                    write_json(root / "runtime/supervisor_progress.json", {
                        "worker_pid": child.pid, "remaining_seconds": budget.global_deadline - time.monotonic(),
                        "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}, replace=True)
                    owner.last_progress = time.monotonic()
            if child.returncode or not (root / "runtime/fit_execution_complete.json").is_file():
                raise RuntimeError("Worker did not finish the complete fixed-scope fitting path")
            owner.verify_sources()
            owner.verify_dependencies()
    except BaseException as error:
        failure = type(error).__name__ + ": " + str(error)
        write_json(root / "runtime/supervisor_failure.json", {"error": failure, "traceback": traceback.format_exc()})
    finally:
        for owned in (tests, child):
            if owned is not None and owned.poll() is None:
                # Only our newly created private process groups.
                os.killpg(owned.pid, signal.SIGTERM)
                try:
                    owned.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    os.killpg(owned.pid, signal.SIGKILL); owned.wait()
        if connection is not None:
            connection.close()
        if listener is not None:
            listener.close()
        settlement = budget.close()
        write_json(root / "runtime/final_supervisor_report.json", {
            "execution_complete": failure is None, "failure": failure, "budget": settlement,
            "counter_snapshot": authority.store.snapshot(), "numeric_process_exited": child is None or child.poll() is not None,
            "forecast_improvement_established": False})
        write_json(root / "runtime/owner.json", {"pid": os.getpid(), "creation_ticks": owner.owner_start,
                   "job_id": os.environ["SLURM_JOB_ID"], "nonce": manifest["nonce"], "status": "STOPPED"}, replace=True)
        fcntl.flock(lock.fileno(), fcntl.LOCK_UN); lock.close()
    if failure:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
