"""Bounded HTTP reads around the unchanged, admitted recovery driver.

The supplemental migration pins this file and the original admission/sources.
The original run loop, ownership lock, publisher and byte validators are reused.
No initialization, cursor editing, scientific jobs or scoring is provided here.
"""

import argparse
import datetime
import http.client
import json
from pathlib import Path
import time
import urllib.error
import urllib.request
import uuid

import eight_basin_recovery_driver_v01 as driver


SCHEMA = "eight-basin-bounded-network-v2"
ORIGINAL_ADMISSION = "14f5c653573614e7a50d32c625f8328f7e1a498a8ef8b2af40f405355387d989"
READ_SIZE = 65536
MAX_RESPONSE = 16 * 1024 * 1024
BaseMailbox = driver.mailbox_module.Mailbox


class ResponseReadError(RuntimeError):
    def __init__(self, message, partial=b"", expected=None):
        super().__init__(message)
        self.partial = partial
        self.expected = expected


def read_response(response):
    """Never accept EOF with a missing declared byte or unbounded response."""
    header = response.headers.get("Content-Length")
    expected = None
    if header is not None:
        if not header.isdigit():
            raise ResponseReadError("Invalid response length")
        expected = int(header)
        if expected > MAX_RESPONSE:
            raise ResponseReadError("Response exceeds byte bound", expected=expected)
    blocks, size = [], 0
    while True:
        try:
            block = response.read(min(READ_SIZE, MAX_RESPONSE + 1 - size))
        except http.client.IncompleteRead as error:
            partial = b"".join(blocks) + error.partial
            raise ResponseReadError("Interrupted response", partial[:MAX_RESPONSE], expected) from error
        except OSError as error:
            raise ResponseReadError("Response connection interrupted", b"".join(blocks), expected) from error
        if not block:
            break
        blocks.append(block)
        size += len(block)
        if size > MAX_RESPONSE:
            raise ResponseReadError("Response exceeds byte bound", b"".join(blocks)[:MAX_RESPONSE], expected)
    raw = b"".join(blocks)
    if expected is not None and size != expected:
        raise ResponseReadError("Response length differs", raw, expected)
    return raw


def migration_guard(home, migration_path, migration_sha256):
    """Keep the old admission immutable and pin the explicit network overlay."""
    transport = driver.transport
    home = transport.no_link_ancestors(home)
    migration_path = transport.no_link_ancestors(migration_path)
    if migration_path != home / "network_migration_v02.json":
        raise driver.IntegrityError("Migration belongs to another recovery directory")
    raw = driver.regular_bytes(migration_path, transport.MAX_METADATA)
    if not driver.HEX64.fullmatch(migration_sha256) or driver.digest(raw) != migration_sha256:
        raise driver.IntegrityError("Externally pinned migration SHA256 differs")
    migration = transport.parse_json(raw)
    if (migration["schema"] != SCHEMA or migration["original_admission_sha256"] != ORIGINAL_ADMISSION or
            migration["home"] != str(transport.display_path(home))):
        raise driver.IntegrityError("Migration changed original recovery admission")
    admission_raw = driver.regular_bytes(home / "admission.json", transport.MAX_METADATA)
    admission = transport.parse_json(admission_raw)
    if (driver.digest(admission_raw) != ORIGINAL_ADMISSION or
            driver.source_hashes() != admission["sources"] or migration["original_sources"] != admission["sources"] or
            driver.file_digest(Path(__file__)) != migration["network_source_sha256"] or
            driver.file_digest(Path(__file__).parents[1] / "tests/test_eight_basin_recovery_network_v02.py") !=
            migration["network_tests_sha256"]):
        raise driver.IntegrityError("Original or supplemental source identity changed")
    previous = migration["predecessor"]
    previous_state_raw = driver.regular_bytes(transport.safe_path(home, previous["state_file"]), transport.MAX_METADATA)
    previous_index_raw = driver.regular_bytes(transport.safe_path(home, previous["receipt_index_file"]), transport.MAX_METADATA)
    if (driver.digest(previous_state_raw) != previous["state_sha256"] or
            driver.digest(previous_index_raw) != previous["receipt_index_sha256"]):
        raise driver.IntegrityError("Migration predecessor evidence changed")
    previous_state = transport.parse_json(previous_state_raw)
    previous_index = transport.parse_json(previous_index_raw)
    if (previous_state["admission_sha256"] != ORIGINAL_ADMISSION or
            previous_state["cursor"] != previous["cursor"] or previous_state["pending"] != previous["pending"] or
            len(previous_index["records"]) != previous["cursor"]):
        raise driver.IntegrityError("Migration predecessor cursor/pending differs")
    pointer = transport.parse_json(driver.regular_bytes(home / "cursor.json"))
    current_raw = driver.regular_bytes(transport.safe_path(home, pointer["state_file"]), transport.MAX_METADATA)
    if driver.digest(current_raw) != pointer["state_sha256"]:
        raise driver.IntegrityError("Current migration state identity differs")
    current = transport.parse_json(current_raw)
    index_raw = driver.regular_bytes(transport.safe_path(home, current["receipt_index_file"]), transport.MAX_METADATA)
    index = transport.parse_json(index_raw)
    if (pointer["admission_sha256"] != ORIGINAL_ADMISSION or current["admission_sha256"] != ORIGINAL_ADMISSION or
            current["cursor"] < previous["cursor"] or current["generation"] < previous_state["generation"] or
            driver.digest(index_raw) != current["receipt_index_sha256"] or len(index["records"]) != current["cursor"] or
            index["records"][:previous["cursor"]] != previous_index["records"]):
        raise driver.IntegrityError("Migration reversed or changed accepted request history")
    return migration


class BoundedReadMailbox(BaseMailbox):
    def __init__(self, home, guard, migration_sha256):
        self.home = driver.transport.no_link_ancestors(home)
        self.guard = guard
        migration = self.guard()
        super().__init__()
        owner = driver.transport.parse_json(driver.regular_bytes(self.home / "owner.json"))
        if (owner["status"] != "RUNNING" or owner["process"] != driver.process_identity() or
                owner["admission_sha256"] != ORIGINAL_ADMISSION):
            raise driver.IntegrityError("Network adapter requires the admitted process owner")
        driver.immutable_json(self.home, self.home / "network_owners_v02" /
                              (str(owner["process"]["pid"]) + "_" + owner["process"]["creation"] + ".json"), {
                                  "process": owner["process"], "original_admission_sha256": ORIGINAL_ADMISSION,
                                  "migration_sha256": migration_sha256,
                                  "network_source_sha256": migration["network_source_sha256"]})

    def record_read_failure(self, path, method, error):
        name = "network_errors_v02/" + uuid.uuid4().hex
        partial = getattr(error, "partial", b"")
        if partial:
            driver.immutable_evidence(self.home, self.home / (name + ".body.bin"), partial)
        driver.immutable_json(self.home, self.home / (name + ".json"), {
            "checked_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "path": path, "method": method, "type": type(error).__name__,
            "partial_bytes": len(partial), "partial_sha256": driver.digest(partial),
            "expected_response_bytes": getattr(error, "expected", None), "science_verified": False})

    def api(self, path, method="GET", body=None, missing=False):
        if method not in {"GET", "POST", "PATCH"}:
            raise driver.IntegrityError("Unexpected mailbox HTTP method")
        request = urllib.request.Request(f"https://api.github.com/repos/{driver.mailbox_module.REPO}/{path}",
                                         data=None if body is None else json.dumps(body).encode(), method=method,
                                         headers={"Authorization": f"Bearer {self._token}",
                                                  "Accept": "application/vnd.github+json", "Accept-Encoding": "identity",
                                                  "Content-Type": "application/json", "User-Agent": "isolated-precip-filter"})
        for attempt in range(3 if method == "GET" else 1):
            self.guard()
            try:
                with urllib.request.urlopen(request, timeout=60) as response:
                    raw = read_response(response)
                try:
                    return json.loads(raw)
                except (ValueError, UnicodeError) as error:
                    raise ResponseReadError("Incomplete JSON response", raw) from error
            except urllib.error.HTTPError as error:
                if missing and error.code == 404:
                    return None
                raise RuntimeError(f"Mailbox API HTTP {error.code} at {path}") from None
            except (ResponseReadError, urllib.error.URLError, TimeoutError, ConnectionError) as error:
                self.record_read_failure(path, method, error)
                if method != "GET" or attempt == 2:
                    raise RuntimeError(f"Mailbox response incomplete at {path}") from None
                time.sleep(attempt + 1)


def run(home, migration_path, migration_sha256, poll_seconds=45, once=False):
    """Inject only the guarded network client into the original run function."""
    guard = lambda: migration_guard(home, migration_path, migration_sha256)
    guard()
    original = driver.mailbox_module.Mailbox
    driver.mailbox_module.Mailbox = lambda: BoundedReadMailbox(home, guard, migration_sha256)
    try:
        return driver.run(home, ORIGINAL_ADMISSION, poll_seconds, once)
    finally:
        driver.mailbox_module.Mailbox = original


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["run"])
    parser.add_argument("--home", type=Path, required=True)
    parser.add_argument("--migration", type=Path, required=True)
    parser.add_argument("--migration-sha256", required=True)
    parser.add_argument("--poll-seconds", type=int, default=45)
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()
    result = run(args.home, args.migration, args.migration_sha256, args.poll_seconds, args.once)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
