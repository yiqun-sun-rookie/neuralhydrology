"""Resume the exact pre-science handoff after a preserved Windows packing failure."""
import argparse
import ast
import hashlib
import importlib.util
import json
import msvcrt
import os
from pathlib import Path
import shutil
import sys
import tarfile
import time

REPO = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO / "src"))
from precip_input_assimilation.hpc.precip_smallfit_runtime_v01 import validate_exploration, write_json
from precip_input_assimilation.small_sample.flexible_budget_v04 import CounterStore, digest
from precip_input_assimilation.scripts.run_precip_effect_first_v02 import budget_hash, load_budget

FAMILY = REPO / "results/precip_input_da_2026_09/effect_first_v01"
LOCAL_AUDIT = FAMILY / "local_gradient_preserved_audit_20261012_v13"


def native_path(path):
    absolute = str(Path(path).absolute())
    return (chr(92) * 2 + "?" + chr(92) + absolute) if os.name == "nt" else absolute


def raw(path):
    with open(native_path(path), "rb") as f:
        return f.read()


def sha(path):
    return hashlib.sha256(raw(path)).hexdigest()


def iter_source_files(folder):
    def failed(error):
        raise error
    for current, dirs, names in os.walk(folder, onerror=failed):
        dirs[:] = sorted(d for d in dirs if d not in ("_tmp", "__pycache__", ".git"))
        for name in sorted(names):
            if name.endswith(".py"):
                yield Path(current) / name


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--deployment-root", required=True, type=Path)
    p.add_argument("--approval", required=True, type=Path)
    p.add_argument("--approval-sha256", required=True)
    p.add_argument("--dependency-manifest-sha256", required=True)
    a = p.parse_args()
    root = a.deployment_root.absolute()
    identity = json.loads(raw(root / "deployment_identity.json"))
    if root.parent != FAMILY or identity["channel"] != "precip-smallfit-hpc-20261012":
        raise PermissionError("Unknown private deployment identity")
    if sha(a.approval) != a.approval_sha256:
        raise PermissionError("Independent code approval bytes changed")
    approval = json.loads(raw(a.approval))
    if approval["status"] not in ("PASS", "PASS_STATIC_REQUIRE_TARGETED_CHECKS") or approval.get("blocking_findings"):
        raise PermissionError("The new HPC entry lacks independent code approval")
    for name, expected in approval["source_identities"].items():
        if sha(REPO / name) != expected:
            raise PermissionError("Reviewed new code changed before packing")
    final = json.loads(raw(LOCAL_AUDIT / "final_supervisor_report.json"))
    if final["child_returncode"] != 0 or not final["numeric_group_exited"] or not final["budget_closure_confirmed"] or final["technical_failure"]:
        raise PermissionError("Original local numerical group has not closed and settled")
    tail_path = FAMILY / "local_gradient_flexible_execution_20261011_v04/management_tail_observed_exit_a62653d407a240a796f316b9c0f85fee.json"
    tail = json.loads(raw(tail_path))["native_exact_exit_proof"]
    if tail["status"] != "EXITED" or tail["windows_creation_identity"] != "134362682575034996" or not tail["native_wait_signaled"]:
        raise PermissionError("Original exact supervisor exit is missing")
    audit_path = LOCAL_AUDIT / "gradient/attempt_009/actual_independent_gradient_audit.json"
    audit = json.loads(raw(audit_path))
    admission = validate_exploration(audit)
    # One full pre-deployment check, not a repeated per-calendar scan.
    for name, expected in final["source_identity"].items():
        if sha(REPO / name) != expected:
            raise PermissionError("Original accepted source changed: " + name)
    write_json(root / "original_source_predeployment_check_v02.json", {
        "files_checked": len(final["source_identity"]), "all_sha256_equal": True,
        "final_report_sha256": sha(LOCAL_AUDIT / "final_supervisor_report.json")})
    for stop in (FAMILY / "STOP", LOCAL_AUDIT / "STOP", root / "STOP"):
        if stop.exists():
            raise InterruptedError("Manual stop remains in force")
    lock = (FAMILY / "exclusive.lock").open("r+b")
    lock.seek(0); msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
    try:
        owner_path = FAMILY / "local_gradient_flexible_owner_v04.json"
        current_owner = json.loads(raw(owner_path))
        old_owner = raw(root / "predecessor_owner_original_bytes.json")
        if json.loads(old_owner)["status"] != "STOPPED":
            raise PermissionError("Original stopped owner bytes are not preserved")
        if (current_owner["status"] != "DELEGATED_HPC_PREPARING" or
                current_owner["nonce"] != identity["nonce"] or
                current_owner["remote_root"] != identity["remote_root"] or
                current_owner["old_owner_sha256"] != hashlib.sha256(old_owner).hexdigest()):
            raise PermissionError("The preserved delegation belongs to another owner")
        failure = json.loads(raw(root / "preparation_failure.json"))
        if failure["type"] != "FileNotFoundError" or "tests" not in failure["error"] or "_tmp" not in failure["error"]:
            raise PermissionError("Only the recorded pre-science temporary-path failure is resumed")
        budget_path = FAMILY / "cumulative_budget_v01.json"
        before_path = root / "budget_before_handoff_original_bytes.json"
        before = raw(before_path)
        predecessor, prior_used, prior_alloc, prior_settled = load_budget(before_path)
        journal, used, allocations, settled = load_budget(budget_path)
        reservation_id = identity["run_id"] + "/handoff"
        if (prior_used != 201612 or set(prior_alloc) - set(prior_settled) or
                journal["events"][:-1] != predecessor["events"] or
                set(allocations) - set(settled) != {reservation_id} or
                current_owner["budget_reservation_id"] != reservation_id):
            raise PermissionError("The original exact budget prefix or existing handoff changed")
        record = journal["events"][-1]
        reservation = record["payload"]
        if (reservation["run_id"] != reservation_id or reservation["nonce"] != identity["nonce"] or
                reservation["remote_root"] != identity["remote_root"] or
                reservation["clock_domain"] != "hpc_job_start_monotonic" or
                reservation["reserved_seconds"] != 21600 or used != 223212):
            raise PermissionError("The sole exact existing reservation is not intact")
        remaining = 259200 - prior_used
        write_json(root / "packing_resume_identity_v02.json", {
            "failure_sha256": sha(root / "preparation_failure.json"),
            "original_budget_prefix_sha256": sha(before_path),
            "existing_handoff_budget_sha256": sha(budget_path),
            "same_reservation": reservation_id, "new_budget_events": 0,
            "old_partial_staging_preserved": str(REPO / "results" / ("psfit_" + identity["nonce"][:8] + "_payload"))})
        staging = REPO / "results" / ("psfit_" + identity["nonce"][:8] + "_payload_v02")
        staging.mkdir()
        code = staging / "code"; code.mkdir()
        records = staging / "records"; records.mkdir()
        (records / "budget_handoff.json").write_bytes(raw(budget_path))
        (records / "budget_before_handoff_original_bytes.json").write_bytes(before)
        (records / "exploratory_admission.json").write_text(json.dumps(admission, indent=2) + "\n")
        (records / "independent_code_review.json").write_bytes(raw(a.approval))
        for folder in ("neuralhydrology", "src/precip_input_assimilation"):
            for source in iter_source_files(REPO / folder):
                rel = source.relative_to(REPO)
                if "__pycache__" in rel.parts or "_tmp" in rel.parts or ("tests" in rel.parts and source.name != "test_hpc_smallfit_admission_v01.py"):
                    continue
                destination = code / rel
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(raw(source))
                ast.parse(raw(source).decode("utf-8-sig"))
        contract_path = REPO / "src/precip_input_assimilation/configs/dynamic_filter_eight_basins_v01.json"
        contract = json.loads(raw(contract_path))
        copied = {contract_path.relative_to(REPO).as_posix()}
        copied.add("src/precip_input_assimilation/hpc/precip_smallfit_v01.slurm")
        copied.update((Path(contract["model_root"]) / name).as_posix() for name in contract["model_sha256"])
        pilot = FAMILY / "pilot_20261009_01487000_s1001_s1002_s1003_v02"
        copied.add((pilot / "fits/no_penalties/seed_1001/fit_summary.json").relative_to(REPO).as_posix())
        for name in copied:
            destination = code / name; destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(raw(REPO / name))
        old = FAMILY / "small_sample_gradient_20261010_v01"
        registry_path = REPO / "src/precip_input_assimilation/configs/precip_saved_gradient_boundaries_v01.json"
        registry = json.loads(raw(registry_path))
        refs = {}
        selected = {"original_context": old / "context_identity.json", "input_gate": old / "input_gate.json",
                    "original_manifest": old / "manifest.json", "strict_scaling": old / "strict_fresh_scaling.json",
                    "source_registry": registry_path, "pilot_result": pilot / "pilot_result.json",
                    "completed_audit": audit_path}
        for name, source in selected.items():
            destination = records / "sources" / (name + ".json"); destination.parent.mkdir(exist_ok=True)
            destination.write_bytes(raw(source))
            refs[name] = {"path": destination.relative_to(staging).as_posix(), "sha256": sha(source), "bytes": len(raw(source))}
        for label in ("bound_inputs", "nonzero_adapter", "frozen_before"):
            found = [r for r in registry["raw_artifacts"] if Path(r["path"]).stem.split("_", 1)[-1] == label]
            if len(found) != 1:
                raise PermissionError("Missing unique original saved lawful tensor")
            item = found[0]; source = Path(item["path"])
            value = raw(source)
            if len(value) != item["bytes"] or hashlib.sha256(value).hexdigest() != item["sha256"]:
                raise PermissionError("Original lawful tensor bytes differ")
            destination = records / "sources" / (label + ".pt"); destination.write_bytes(value)
            refs[label] = {"path": destination.relative_to(staging).as_posix(), "sha256": item["sha256"],
                           "bytes": item["bytes"], "original_identity": item}
        counter_root = FAMILY / "local_gradient_flexible_execution_20261011_v04/durable_operation_counters_v04"
        document = json.loads(raw(counter_root / "operation_counters_v04.json"))
        store = CounterStore(native_path(counter_root), document["binding"], lambda: None)
        snapshot = store.snapshot()
        if snapshot["counts"]["gradient_full_forward"] != 94 or snapshot["counts"]["direct_science_update"] or snapshot["counts"]["network_1001_science_update"]:
            raise PermissionError("Original fitting counters changed before transfer")
        shutil.copytree(native_path(counter_root), staging / "counters")
        files = [{"path": f.relative_to(staging).as_posix(), "sha256": sha(f), "bytes": f.stat().st_size}
                 for f in sorted(staging.rglob("*")) if f.is_file()]
        manifest = dict(identity, schema="precip_hpc_smallfit_manifest_v01", files=files, saved_sources=refs,
                        dependency_manifest_sha256=a.dependency_manifest_sha256,
                        budget_handoff_sha256=sha(records / "budget_handoff.json"), remaining_seconds=remaining,
                        budget_reservation_id=reservation["run_id"], budget_reservation_sha256=record["sha256"],
                        counter_binding=document["binding"], counter_snapshot_digest=digest(snapshot),
                        counter_head_sha256=snapshot["head_sha256"], counter_event_count=snapshot["event_count"],
                        counter_initialization_evidence_sha256=snapshot["initialization_evidence_sha256"],
                        science_source_digest=digest(files), code_approval_sha256=a.approval_sha256,
                        recipe={"seeds": [1001], "max_steps": 1000, "checkpoint_interval": 10,
                                "mse_threshold": .0001, "relative_reduction": .99,
                                "network_learning_rate": .001, "control_learning_rate_mm": .1,
                                "soft_penalties": {"magnitude": 0., "violation": 0.}})
        write_json(staging / "manifest.json", manifest)
        archive = root / ("smallfit_payload_" + identity["nonce"][:8] + "_v02.tar.gz")
        with tarfile.open(archive, "w:gz") as tf:
            for f in sorted(staging.rglob("*")):
                if f.is_file():
                    tf.add(f, arcname="payload/" + f.relative_to(staging).as_posix())
        write_json(root / "prepared_payload_v02.json", {"manifest_sha256": sha(staging / "manifest.json"),
                   "archive": str(archive), "archive_sha256": sha(archive), "bytes": archive.stat().st_size,
                   "staging": str(staging), "remaining_seconds": remaining, "files": len(files)})
        print(json.dumps({"archive": str(archive), "bytes": archive.stat().st_size,
                          "manifest_sha256": sha(staging / "manifest.json"), "remaining_seconds": remaining}))
    except BaseException as error:
        write_json(root / "preparation_failure_v02.json", {"type": type(error).__name__, "error": str(error)})
        raise
    finally:
        lock.seek(0); msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1); lock.close()


if __name__ == "__main__":
    main()
