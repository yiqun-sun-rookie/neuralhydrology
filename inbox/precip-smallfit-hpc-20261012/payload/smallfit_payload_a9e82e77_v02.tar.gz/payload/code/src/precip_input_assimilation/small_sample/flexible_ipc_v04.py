"""Authenticated local IPC; standard library only, with no numerical imports."""
import json
import math
import os
from pathlib import Path
import time
from multiprocessing.connection import Client


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def native_identity(pid):
    from precip_input_assimilation.scripts.run_precip_local_gradient_small_sample_v03 import process_identity
    return process_identity(pid)


class RuntimeClient:
    def __init__(self, session_path):
        self.session_path = Path(session_path)
        self.session = read_json(self.session_path)
        self.global_deadline = self._finite_deadline(self.session["global_deadline"], "total")
        self.slice_deadline = self._finite_deadline(self.session["slice_deadline"], "slice")
        if self.slice_deadline > self.global_deadline:
            raise PermissionError("Initial slice deadline exceeds the total budget deadline")
        self.sequence = 0
        self._stopped = False
        self.identity = native_identity(os.getpid())
        if self.identity["status"] != "RUNNING":
            raise PermissionError("Numeric worker identity was not established")
        self.connection = Client(self.session["endpoint"], family="AF_PIPE",
                                 authkey=bytes.fromhex(self.session["auth_hex"]))
        self._rpc("hello", {})

    @staticmethod
    def _finite_deadline(value, label):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise PermissionError(label + " budget deadline is not a finite number")
        try:
            deadline = float(value)
        except (OverflowError, ValueError) as error:
            raise PermissionError(label + " budget deadline is not a finite number") from error
        if not math.isfinite(deadline):
            raise PermissionError(label + " budget deadline is not a finite number")
        return deadline

    @staticmethod
    def _connection_call(method, *args):
        try:
            return method(*args)
        except (EOFError, OSError) as error:
            raise ConnectionError("Supervisor IPC disconnected; numerical authorization stopped") from error

    def _check_deadlines(self):
        now = time.monotonic()
        if now >= self.global_deadline:
            raise TimeoutError("Cumulative budget elapsed while waiting for supervisor")
        if now >= self.slice_deadline:
            raise TimeoutError("Current reserved slice elapsed while waiting for supervisor")
        return min(self.global_deadline, self.slice_deadline) - now

    def _require_owner(self):
        owner = self.session["owner"]
        actual = native_identity(owner["pid"])
        if actual["status"] != "RUNNING" or actual.get("creation_identity") != owner["windows_creation_identity"]:
            raise PermissionError("Exact budget supervisor is no longer running")
        current = read_json(self.session["owner_path"])
        if (current.get("status") != "RUNNING" or current.get("nonce") != self.session["nonce"]
                or current.get("windows_creation_identity") != owner["windows_creation_identity"]):
            raise PermissionError("Budget supervisor persistent ownership changed")

    def _rpc(self, operation, body):
        if self._stopped:
            raise RuntimeError("Runtime client already stopped; further numerical authorization is prohibited")
        try:
            self._check_deadlines()
            self._require_owner()
            self.sequence += 1
            request = {"op": operation, "body": body, "sequence": self.sequence,
                       "nonce": self.session["nonce"], "pid": os.getpid(),
                       "windows_creation_identity": self.identity["creation_identity"]}
            self._connection_call(self.connection.send, request)
            while True:
                remaining = self._check_deadlines()
                ready = self._connection_call(self.connection.poll, min(1.0, remaining))
                self._require_owner()
                self._check_deadlines()
                if ready:
                    response = self._connection_call(self.connection.recv)
                    break
            if (not isinstance(response, dict) or response.get("sequence") != self.sequence
                    or response.get("nonce") != self.session["nonce"]
                    or response.get("source_digest") != self.session["source_digest"]):
                raise PermissionError("IPC response identity changed")
            if response.get("ok") is not True:
                raise RuntimeError("Supervisor stopped computation: " + str(response.get("error")))
            cutoff = self._finite_deadline(response.get("global_deadline"), "total")
            slice_cutoff = self._finite_deadline(response.get("slice_deadline"), "slice")
            if cutoff > self.global_deadline:
                raise PermissionError("Total budget deadline was extended")
            if slice_cutoff > cutoff:
                raise PermissionError("Reserved slice deadline exceeds the total budget deadline")
            # Only a successful response bound to this exact sequence, nonce and
            # source may renew a slice. It can never renew the total budget.
            self.global_deadline, self.slice_deadline = cutoff, slice_cutoff
            self._check_deadlines()
            result = response.get("result", {})
            if not isinstance(result, dict):
                raise PermissionError("IPC result is not a structured authorization")
            return result
        except BaseException:
            self._stopped = True
            raise

    def checkpoint(self, label, begin_operation=True):
        return self._rpc("checkpoint", {"label": label, "begin_operation": bool(begin_operation),
                                        "device_synchronized": True, "new_operations_paused": True})

    def consume(self, kind, key, label, bindings=None):
        return self._rpc("consume", {"kind": kind, "key": key, "label": label,
                                     "bindings": bindings or {}})

    def bind_audit(self, attempt_id, run_identity, updates):
        return self._rpc("bind_audit", {"attempt_id": attempt_id,
                                        "run_identity": run_identity, "updates": list(updates)})

    def counter_snapshot(self):
        return self._rpc("counter_snapshot", {})

    def register_child(self, pid):
        return self._rpc("register_child", {"pid": int(pid)})

    def finished(self, value):
        return self._rpc("finished", value)

    def close(self):
        self.connection.close()
