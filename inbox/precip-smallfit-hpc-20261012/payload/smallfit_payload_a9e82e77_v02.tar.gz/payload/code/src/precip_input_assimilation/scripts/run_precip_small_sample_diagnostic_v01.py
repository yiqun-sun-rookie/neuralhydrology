"""Bounded staged diagnostic; frozen experiment sources and prior artifacts are read-only."""

import argparse
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import sys
import subprocess
import time
import traceback

REPO = Path(__file__).resolve().parents[3]
FAMILY = REPO / "results/precip_input_da_2026_09/effect_first_v01"
CONFIG = REPO / "src/precip_input_assimilation/configs/precip_small_sample_diagnostic_v01.json"
OLD_ENTRY = REPO / "src/precip_input_assimilation/scripts/run_precip_effect_first_v02.py"
OLD_ENTRY_SHA = "fd38ecbd0b669a23665138574237ad383171b4249cfd40e36900658520387baa"
PLAN_REVIEW = FAMILY / "small_sample_planning_20261010_v01/independent_plan_review_v02.json"
PLAN_REVIEW_SHA = "2956396528309b5d2eabe152f96607ee87faed38834d2f4034e124bde72f8684"


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda: f.read(1048576), b""):
            h.update(b)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def old_entry():
    if sha256(OLD_ENTRY) != OLD_ENTRY_SHA:
        raise PermissionError("Original reviewed entry changed")
    spec = importlib.util.spec_from_file_location("small_sample_original_entry", OLD_ENTRY)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def config():
    value = read_json(CONFIG)
    if (value["plan_sha256"] != "49ed97c6f2f34af0f1408ed8ea07ec72c5ecc293efcbbd24c3256fd000f00393"
            or sha256(REPO / value["plan"]) != value["plan_sha256"]
            or sha256(PLAN_REVIEW) != PLAN_REVIEW_SHA
            or read_json(PLAN_REVIEW)["status"] != "PASS"):
        raise PermissionError("Reviewed plan binding changed")
    expected = {"weight_replay": (1800, None), "gradient": (1200, "weight_replay"),
                "direct_control": (3600, "gradient"), "network": (5400, "direct_control")}
    if (value["basin"] != "01487000" or value["seeds"] != [1001, 1002, 1003]
            or value["target_start"] != "1980-10-02" or value["target_end"] != "1980-11-02"
            or value["max_steps"] != 1000 or value["checkpoint_interval"] != 10
            or value["mse_threshold"] != .0001 or value["relative_reduction"] != .99
            or value["network_learning_rate"] != .001 or value["control_learning_rate_mm"] != .1
            or value["soft_penalties"] != {"magnitude": 0., "violation": 0.}
            or value["score_numeric_reads_allowed"] is not False or value["new_remote_jobs"] != 0
            or value["exit_reserve_seconds"] != 300 or set(value["stages"]) != set(expected)):
        raise PermissionError("Diagnostic recipe differs from approved plan")
    for stage, (seconds, previous) in expected.items():
        item = value["stages"][stage]
        if (item["seconds"], item["previous"]) != (seconds, previous):
            raise PermissionError("Stage budget or ordering changed")
        if item["output"] != "small_sample_" + stage + "_20261010_v01":
            raise PermissionError("New stage output identity changed")
    return value


def source_identity():
    directory = REPO / "src/precip_input_assimilation/small_sample"
    files = [Path(__file__), CONFIG, OLD_ENTRY, *sorted(directory.glob("*.py")),
             *sorted((REPO / "src/precip_input_assimilation/tests").glob("test_small_sample*_v01.py"))]
    return {str(p.relative_to(REPO)).replace("\\", "/"): sha256(p) for p in files}


def require_approval(path, identity, sources, stage):
    if sha256(path) != identity:
        raise PermissionError("Independent code approval bytes differ")
    review = read_json(path)
    if (review.get("status") != "PASS" or review.get("source_identity") != sources
            or stage not in review.get("stage_scope", [])):
        raise PermissionError("Exact diagnostic implementation lacks independent code approval")
    return review


def require_predecessor(recipe, stage):
    previous = recipe["stages"][stage]["previous"]
    if previous is None:
        return None
    root = FAMILY / recipe["stages"][previous]["output"]
    result, audit, final = (read_json(root / name) for name in
                            ("stage_result.json", "independent_actual_audit.json", "stage_complete.json"))
    if (result.get("execution_complete") is not True or audit.get("status") != "PASS"
            or final.get("stage") != previous or final.get("pass") is not True
            or (root / "failure.json").exists() or not (root / "budget_settlement.json").exists()
            or final["stage_result_sha256"] != sha256(root / "stage_result.json")
            or final["audit_sha256"] != sha256(root / "independent_actual_audit.json")):
        raise PermissionError("Previous stage has no complete independently verified actual evidence")
    actual = require_actual_audit(root, previous, audit)
    if final.get("actual_audit_sha256") != audit["sha256"]:
        raise PermissionError("Underlying independent actual report changed")
    return {"stage": previous, "output": str(root), "complete_sha256": sha256(root / "stage_complete.json")}


def require_actual_audit(output, stage, audit):
    if audit.get("pass") is not True or audit.get("status") != "PASS" or audit.get("stage") != stage:
        raise PermissionError("Independent actual audit did not pass this exact stage")
    path = Path(audit["report_path"]).resolve()
    if not path.is_relative_to(output.resolve()) or sha256(path) != audit["sha256"]:
        raise PermissionError("Independent actual report path or bytes differ")
    actual = read_json(path)
    if actual.get("pass") is not True or actual.get("status") != "PASS" or actual.get("stage") != stage:
        raise PermissionError("Underlying independent actual report did not pass")
    return actual


def creation_identity():
    if os.name != "nt":
        return None
    import ctypes
    from ctypes import wintypes
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
    times = [wintypes.FILETIME() for _ in range(4)]
    if not kernel.GetProcessTimes(kernel.GetCurrentProcess(), *(ctypes.byref(t) for t in times)):
        raise ctypes.WinError(ctypes.get_last_error())
    return str((times[0].dwHighDateTime << 32) | times[0].dwLowDateTime)


def finite_tree(value, label):
    import torch
    if isinstance(value, torch.Tensor):
        if not torch.isfinite(value).all():
            raise RuntimeError("Nonfinite " + label)
    elif isinstance(value, dict):
        for key, item in value.items():
            finite_tree(item, label + "/" + str(key))
    elif isinstance(value, (list, tuple)):
        for i, item in enumerate(value):
            finite_tree(item, label + "/" + str(i))
    elif isinstance(value, float) and not math.isfinite(value):
        raise RuntimeError("Nonfinite " + label)


def state_copy(module):
    return {k: v.detach().cpu().clone() for k, v in module.state_dict().items()}


def parameter_digest(module):
    return hashlib.sha256(b"".join(p.detach().cpu().numpy().tobytes()
                                   for p in module.parameters())).hexdigest()


def save_tensors(value, path):
    import numpy as np
    import torch
    def cpu(item):
        if torch.is_tensor(item):
            return item.detach().cpu().clone()
        if isinstance(item, np.ndarray):
            return {"numpy_dtype": str(item.dtype), "shape": list(item.shape),
                    "bytes_hex": item.tobytes(order="C").hex()}
        if isinstance(item, np.generic):
            return item.item()
        if isinstance(item, dict):
            return {k: cpu(v) for k, v in item.items()}
        if isinstance(item, (tuple, list)):
            return type(item)(cpu(v) for v in item)
        return item
    torch.save(cpu(value), path)


def training_step(ctx, model, optimizer, *, diagnostics=False):
    """One complete fixed-parameter graph; logging has no additional forward or RNG use."""
    import torch
    ctx.require_unchanged()
    optimizer.zero_grad(set_to_none=True)
    trajectory = ctx.small_forward(model, capture=diagnostics)
    finite_tree(trajectory.loss, "flow loss")
    for update in trajectory.updates[:32]:
        finite_tree({"proposal": update.proposal, "applied": update.applied}, "update")
        if diagnostics:
            for tensor in (update.proposal, update.applied):
                if tensor.requires_grad:
                    tensor.retain_grad()
    trajectory.loss.backward()
    gradients = {name: p.grad for name, p in model.named_parameters()}
    finite_tree(gradients, "parameter gradients")
    finite_tree(model.state_dict(), "parameters before update")
    finite_tree(optimizer.state_dict(), "optimizer before update")
    return trajectory, gradients


def trajectory_record(trajectory, model, gradients):
    import numpy as np
    def array(t):
        return t.detach().cpu().numpy().copy()
    # Missing gradients use an explicit mask; absent values are not numeric diagnostic NaNs.
    def grad_values(t):
        return np.zeros(tuple(t.shape), dtype=np.float32) if t.grad is None else array(t.grad)
    updates = trajectory.updates[:32]
    return {"predictions": np.asarray([p.q_mm_day for p in trajectory.predictions]),
            "proposal": np.stack([array(u.proposal) for u in updates]),
            "applied": np.stack([array(u.applied) for u in updates]),
            "raw": np.stack([array(u.raw) for u in updates]),
            "proposal_gradient": np.stack([grad_values(u.proposal) for u in updates]),
            "applied_gradient": np.stack([grad_values(u.applied) for u in updates]),
            "proposal_gradient_missing": np.asarray([u.proposal.grad is None for u in updates]),
            "applied_gradient_missing": np.asarray([u.applied.grad is None for u in updates]),
            **{"parameter_gradient__" + n.replace(".", "_"): np.zeros(tuple(p.shape), dtype=np.float32)
               if gradients[n] is None else array(gradients[n]) for n, p in model.named_parameters()},
            "parameter_gradient_missing": np.asarray([gradients[n] is None for n, _ in model.named_parameters()])}


def trajectory_proof(trajectory):
    """Raw calendar, controlled actions and complete ledgers; detach only after the actual graph."""
    return {"loss": trajectory.loss.detach().cpu().clone(),
            "predictions": [{"date": p.date.isoformat(), "observation_cutoff": p.observation_cutoff.isoformat(),
                             "locked": p.locked, "state_digest": p.state_digest,
                             "tensor": p.tensor.detach().cpu().clone()} for p in trajectory.predictions],
            "updates": [{"as_of_date": u.as_of_date.isoformat(), "rain_dates": [d.isoformat() for d in u.rain_dates],
                         "proposal": u.proposal.detach().cpu().clone(),
                         "applied": u.applied.detach().cpu().clone(), "raw": u.raw.detach().cpu().clone(),
                         "violation": u.violation.detach().cpu().clone(), "cap": u.cap,
                         "missing": u.missing} for u in trajectory.updates],
            "ledgers": [v.detach().cpu().clone() for v in trajectory.ledgers]}


def optimize(ctx, recipe, kind):
    import numpy as np
    import torch
    from precip_input_assimilation.small_sample.support_v01 import (TableCorrector, bounds, rng_snapshot,
                                                                    snapshot, state_snapshot, frozen_modes)
    from precip_input_assimilation.dynamic_filter_multibasin.controller import network_for
    from precip_input_assimilation.dynamic_filter.report import nse
    original = old_entry()
    runs = []
    lower, upper = bounds(ctx)
    seeds = [None] if kind == "direct_control" else recipe["seeds"]
    old_root = FAMILY / "pilot_20261009_01487000_s1001_s1002_s1003_v02"
    for seed in seeds:
        ctx.require_unchanged()
        directory = ctx.output / ("control" if seed is None else "seed_" + str(seed))
        directory.mkdir(exist_ok=False)
        if seed is None:
            model = TableCorrector(torch.zeros_like(lower))
            lr = recipe["control_learning_rate_mm"]
        else:
            model = network_for("rain", ctx.scaling, seed, ctx.device)
            expected = read_json(old_root / f"fits/no_penalties/seed_{seed}/fit_summary.json")
            if parameter_digest(model) != expected["initial_tensors_sha256"]:
                raise PermissionError("Network initialization differs from original paired seed")
            lr = recipe["network_learning_rate"]
        optimizer = torch.optim.Adam(model.parameters(), lr=lr, betas=(.9, .999), eps=1e-8, weight_decay=0.)
        warmup = ctx.factory(model)
        save_tensors({"dates": [d.isoformat() for d in ctx.small_phase.dates],
                    "weather": ctx.small_weather, "observations": ctx.small_values,
                    "scaling": ctx.scaling.as_dict(), "lower": lower.cpu(), "upper": upper.cpu(),
                    "warmup_dates": [d.isoformat() for d in warmup.dates], "warmup_weather": warmup.raw,
                    "warmup_applied": warmup.applied,
                    "frozen_before": state_snapshot(ctx.hydro.frozen.model), "hydro_modes": frozen_modes(ctx.hydro)},
                   directory / "bound_inputs.pt")
        del warmup
        save_tensors({"state_dict": state_copy(model), "seed": seed, "rng": rng_snapshot(),
                    "optimizer": copy.deepcopy(optimizer.state_dict()), "updates_completed": 0,
                    "snapshot": snapshot(model, optimizer)}, directory / "initial.pt")
        initial, best_loss, best_step, best_state = None, float("inf"), None, None
        achieved = False
        last_loss = None
        for k in range(recipe["max_steps"] + 1):
            ctx.require_unchanged()
            began = time.monotonic()
            torch.cuda.synchronize(ctx.device)
            trajectory, gradients = training_step(ctx, model, optimizer, diagnostics=True)
            current = float(trajectory.loss.detach())
            if initial is None:
                initial = current
                initial_predictions = np.asarray([p.q_mm_day for p in trajectory.predictions])
                np.save(directory / "initial_predictions.npy", initial_predictions)
                if seed is None:
                    baseline_network = network_for("rain", ctx.scaling, 1001, ctx.device)
                    with torch.no_grad():
                        zero_network = ctx.small_forward(baseline_network, capture=True)
                    expected_initial = np.asarray([p.q_mm_day for p in zero_network.predictions])
                    save_tensors({"trajectory": trajectory_proof(zero_network),
                                "state_dict": state_copy(baseline_network)}, directory / "zero_network_baseline.pt")
                    del baseline_network, zero_network
                else:
                    initial_file = FAMILY / recipe["stages"]["direct_control"]["output"] / "control/initial_predictions.npy"
                    expected_initial = np.load(initial_file, allow_pickle=False)
                if (initial_predictions.dtype != expected_initial.dtype or initial_predictions.shape != expected_initial.shape
                        or not np.array_equal(initial_predictions, expected_initial)):
                    raise RuntimeError("Zero-control and zero-network initial predictions differ")
            if current < best_loss:
                best_loss, best_step, best_state = current, k, state_copy(model)
                torch.save({"state_dict": best_state, "updates_completed": best_step, "mse": best_loss}, directory / "best.pt")
            record = trajectory_record(trajectory, model, gradients)
            finite_tree(record, "diagnostic values")
            for v in record.values():
                if not np.isfinite(v).all():
                    raise RuntimeError("Nonfinite detached diagnostic value")
            np.savez_compressed(directory / f"step_{k:04d}_diagnostics.npz", **record)
            save_tensors({"state_dict": state_copy(model), "optimizer": copy.deepcopy(optimizer.state_dict()),
                        "updates_completed": k, "mse": current, "snapshot": snapshot(model, optimizer),
                        "trajectory": trajectory_proof(trajectory)}, directory / f"state_{k:04d}.pt")
            status = {"updates_completed": k, "mse": current, "best_step": best_step, "best_mse": best_loss,
                      "parameter_names": [n for n, _ in model.named_parameters()],
                      "proposal_items": int(record["proposal"].size),
                      "strictly_below": int(np.sum(record["proposal"] < -np.minimum(record["raw"],ctx.scaling.cap))),
                      "strictly_above": int(np.sum(record["proposal"] > ctx.scaling.cap)),
                      "at_lower": int(np.sum(record["proposal"] == -np.minimum(record["raw"],ctx.scaling.cap))),
                      "at_upper": int(np.sum(record["proposal"] == ctx.scaling.cap))}
            if k % recipe["checkpoint_interval"] == 0 or k == recipe["max_steps"]:
                current_state = state_copy(model)
                saved_best = torch.load(directory / "best.pt", map_location="cpu", weights_only=True)
                if saved_best["updates_completed"] != best_step or saved_best["mse"] != best_loss:
                    raise RuntimeError("Saved best checkpoint step or error differs")
                model.load_state_dict(saved_best["state_dict"], strict=True)
                with torch.no_grad():
                    replay = ctx.small_forward(model, capture=True)
                rebuilt = float(replay.loss)
                if rebuilt != best_loss:
                    raise RuntimeError("Saved best state does not strictly reproduce its fixed-parameter error")
                np.save(directory / f"best_replay_at_{k:04d}.npy", np.asarray([p.q_mm_day for p in replay.predictions]))
                # Existence of a feasible network trajectory is independently represented by its controls.
                control = torch.stack([u.applied.detach().clone() for u in replay.updates[:32]])
                with torch.no_grad():
                    imported = ctx.small_forward(TableCorrector(control), capture=True)
                a = np.asarray([p.q_mm_day for p in imported.predictions]); b = np.asarray([p.q_mm_day for p in replay.predictions])
                if a.dtype != b.dtype or a.shape != b.shape or not np.array_equal(a, b):
                    raise RuntimeError("Saved fitted trajectory is not equivalent to its direct control table")
                torch.save(control.cpu(), directory / f"best_controls_at_{k:04d}.pt")
                save_tensors({"best_state_dict": saved_best["state_dict"], "best_step": best_step, "best_mse": best_loss,
                            "trajectory": trajectory_proof(replay), "imported": trajectory_proof(imported),
                            "rng": rng_snapshot(), "current_step": k}, directory / f"best_proof_at_{k:04d}.pt")
                model.load_state_dict(current_state, strict=True)
                achieved = (initial > recipe["mse_threshold"] and rebuilt <= recipe["mse_threshold"]
                            and 1. - rebuilt / initial >= recipe["relative_reduction"])
                status["best_replay"] = {"mse": rebuilt, "achieved": achieved,
                                          "initial_already_satisfied": initial <= recipe["mse_threshold"]}
            original.write_json(directory / f"step_{k:04d}.json", status)
            last_loss = current
            torch.cuda.synchronize(ctx.device)
            print(f"stage={kind} seed={seed} step={k} mse={current:.9g} best={best_loss:.9g} seconds={time.monotonic()-began:.2f}", flush=True)
            if achieved or initial <= recipe["mse_threshold"] or k == recipe["max_steps"]:
                break
            before = state_copy(model)
            optimizer.step()
            # Preserve the first bad update before checking it; no following step is permitted.
            save_tensors({"state_dict": state_copy(model), "optimizer": copy.deepcopy(optimizer.state_dict()),
                        "updates_completed": k+1, "before_state_dict": before},
                       directory / f"update_{k+1:04d}_before_projection.pt")
            finite_tree(model.state_dict(), "parameters after update")
            finite_tree(optimizer.state_dict(), "optimizer after update")
            if seed is None:
                preprojection = model.controls.detach().clone()
                with torch.no_grad():
                    model.controls.copy_(torch.clamp(model.controls, min=lower, max=upper))
                torch.save({"before_projection": preprojection.cpu(), "after_projection": model.controls.detach().cpu(),
                            "update": k+1}, directory / f"projection_{k+1:04d}.pt")
            original.write_json(directory / f"parameter_change_{k+1:04d}.json", {
                "from_step": k, "to_step": k+1,
                "absolute_max": max(float((model.state_dict()[n].detach().cpu()-v).abs().max()) for n,v in before.items())})
            ctx.hydro.require_unchanged()
        result = {"seed": seed, "initial_mse": initial, "last_mse": last_loss, "best_mse": best_loss,
                  "best_step": best_step, "updates_completed": k, "fit_gate_pass": achieved,
                  "initial_already_satisfied": initial <= recipe["mse_threshold"],
                  "algorithm_completed": True, "output": str(directory), "forecast_efficacy_claim": False}
        save_tensors({"frozen_after": state_snapshot(ctx.hydro.frozen.model), "modes": frozen_modes(ctx.hydro)},
                   directory / "hydro_after.pt")
        original.write_json(directory / "fit_result.json", result)
        runs.append(result)
        if initial <= recipe["mse_threshold"]:
            raise RuntimeError("Initial baseline already satisfies threshold; learning diagnosis is uninformative")
    return {"stage": kind, "execution_complete": True, "runs": runs,
            "fit_gate_pass_count": sum(r["fit_gate_pass"] for r in runs), "run_denominator": len(runs),
            "forecast_efficacy_confirmed": False}


def run_registered_synthetic_tests(ctx):
    """All numerical synthetic checks consume this stage's one existing reservation."""
    ctx.require_unchanged()
    directory = REPO / "src/precip_input_assimilation/tests"
    tests = [directory / name for name in ("test_small_sample_support_v01.py",
             "test_small_sample_gradient_v01.py", "test_small_sample_training_v01.py")]
    timeout = ctx.deadline - 300 - time.monotonic()
    if timeout <= 0:
        raise TimeoutError("No remaining registered test time")
    output = ctx.output / "synthetic_tests"
    output.mkdir(exist_ok=False)
    command = [sys.executable, "-B", "-m", "pytest", "-q", "-p", "no:cacheprovider",
               "--junitxml=" + str(output / "report.xml"), *(str(p) for p in tests)]
    with (output / "stdout.log").open("wb") as stdout, (output / "stderr.log").open("wb") as stderr:
        process = subprocess.Popen(command, cwd=REPO, stdout=stdout, stderr=stderr)
        try:
            returncode = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            raise TimeoutError("Registered synthetic tests reached the exit reserve")
    summary = {"returncode": returncode, "test_sources": {str(p): sha256(p) for p in tests},
               "report_sha256": sha256(output / "report.xml") if (output / "report.xml").exists() else None,
               "stdout_sha256": sha256(output / "stdout.log"), "stderr_sha256": sha256(output / "stderr.log"),
               "same_stage_reservation": sha256(ctx.output / "budget_reservation.json")}
    old_entry().write_json(output / "result.json", summary)
    ctx.require_unchanged()
    if returncode != 0:
        raise RuntimeError("Registered synthetic rejection or logging checks failed; raw test evidence retained")
    return summary


def main():
    sys.dont_write_bytecode = True
    sys.path[:0] = [str(REPO), str(REPO / "src")]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", required=True, choices=("weight_replay", "gradient", "direct_control", "network"))
    parser.add_argument("--approval", required=True, type=Path)
    parser.add_argument("--approval-sha256", required=True)
    args = parser.parse_args()
    own_creation = creation_identity()
    recipe = config(); original = old_entry(); sources = source_identity()
    require_approval(args.approval, args.approval_sha256, sources, args.stage)
    predecessor = require_predecessor(recipe, args.stage)
    output = original.check_output_path(FAMILY / recipe["stages"][args.stage]["output"])
    original.verify_original_guard()
    original_manifest = read_json(FAMILY / "pilot_20261009_01487000_s1001_s1002_s1003_v02/manifest.json")
    transport = original_manifest["original_transport_identity"]
    for path, expected in transport.items():
        if sha256(path) != expected:
            raise PermissionError("Completed transport evidence changed")
    with original.exclusive_trial_lock():
        if (FAMILY / "STOP").exists():
            raise InterruptedError("Manual family stop is present")
        reservation = original.reserve_budget(FAMILY / "cumulative_budget_v01.json", output,
                        sha256(CONFIG), sha256(__file__), recipe["stages"][args.stage]["seconds"])
        began = time.monotonic(); deadline = began + recipe["stages"][args.stage]["seconds"]
        manifest = {"schema": "precip_small_sample_actual_stage_v01", "stage": args.stage,
                    "source_identity": sources, "plan_sha256": recipe["plan_sha256"],
                    "approval_path": str(args.approval), "approval_sha256": args.approval_sha256,
                    "predecessor": predecessor, "original_transport_identity": transport,
                    "budget_reservation_sha256": reservation["sha256"], "pid": os.getpid(),
                    "windows_creation_identity": own_creation, "started_utc": datetime.now(timezone.utc).isoformat(),
                    "deadline_monotonic": deadline, "score_numeric_reads_allowed": False}

        def require_unchanged():
            if time.monotonic() >= deadline - 300:
                raise TimeoutError("Stage reached its fixed 300-second exit reserve")
            if (output / "STOP").exists() or (FAMILY / "STOP").exists():
                raise InterruptedError("Manual stop marker preserved")
            if source_identity() != sources:
                raise PermissionError("New implementation changed during stage")
            original.verify_original_guard()
            if any(sha256(p) != expected for p, expected in transport.items()):
                raise PermissionError("Original complete transport evidence changed")

        ctx = None
        try:
            output.mkdir(parents=True, exist_ok=False)
            original.write_json(output / "budget_reservation.json", reservation)
            original.write_json(output / "config_snapshot.json", recipe)
            original.write_json(output / "manifest.json", manifest)
            from precip_input_assimilation.small_sample.support_v01 import create_context, stage_one
            from precip_input_assimilation.small_sample.audit_v01 import audit_stage
            ctx = create_context(output, deadline, require_unchanged)
            manifest["runtime"] = ctx.runtime
            original.write_json(output / "manifest.json", manifest)
            if args.stage == "weight_replay":
                result = stage_one(ctx)
            elif args.stage == "gradient":
                from precip_input_assimilation.small_sample.gradient_v01 import run_gradient_stage
                tests = run_registered_synthetic_tests(ctx)
                result = run_gradient_stage(ctx)
                result["synthetic_tests"] = tests
            else:
                result = optimize(ctx, recipe, args.stage)
            if result.get("execution_complete") is not True:
                raise RuntimeError("Stage execution is incomplete")
            original.write_json(output / "stage_result.json", result)
            require_unchanged()
            audit = audit_stage(args.stage, ctx, result)
            require_actual_audit(output, args.stage, audit)
            original.write_json(output / "independent_actual_audit.json", audit)
            require_unchanged()
            original.write_json(output / "stage_complete.json", {"stage": args.stage, "pass": True,
                "stage_result_sha256": sha256(output / "stage_result.json"),
                "audit_sha256": sha256(output / "independent_actual_audit.json"),
                "actual_audit_sha256": audit["sha256"],
                "scientific_forecast_improvement_claim": False})
        except BaseException as error:
            failure_path = output / "failure.json" if output.is_dir() else FAMILY / (
                "small_sample_setup_failure_" + reservation["payload"]["run_id"] + ".json")
            original.write_json(failure_path, {"error_type": type(error).__name__, "error": str(error),
                "traceback": traceback.format_exc(), "elapsed_seconds": time.monotonic()-began,
                "stage": args.stage, "score_numeric_reads_started": False})
            if ctx is not None and args.stage == "gradient":
                try:
                    from precip_input_assimilation.small_sample.audit_v01 import audit_failure
                    review = audit_failure(args.stage, ctx, error)
                except Exception as audit_error:
                    review = {"pass": False, "status": "BLOCKED_UNREVIEWED", "stage": args.stage,
                              "audit_error_type": type(audit_error).__name__, "audit_error": str(audit_error),
                              "first_failure_preserved": True, "model_inference_by_auditor": False}
                original.write_json(output / "independent_failure_audit.json", review)
            raise
        finally:
            settlement = original.settle_budget(FAMILY / "cumulative_budget_v01.json", reservation, time.monotonic()-began)
            evidence_root = output if output.is_dir() else FAMILY
            suffix = "" if output.is_dir() else "_" + reservation["payload"]["run_id"]
            original.write_json(evidence_root / ("budget_settlement" + suffix + ".json"), settlement)
            original.write_json(evidence_root / ("exit_evidence" + suffix + ".json"), {"elapsed_seconds": time.monotonic()-began,
                "source_identity_unchanged": source_identity()==sources,
                "transport_unchanged": all(sha256(p)==h for p,h in transport.items()),
                "windows_creation_identity": manifest["windows_creation_identity"],
                "budget": settlement})


if __name__ == "__main__":
    main()
