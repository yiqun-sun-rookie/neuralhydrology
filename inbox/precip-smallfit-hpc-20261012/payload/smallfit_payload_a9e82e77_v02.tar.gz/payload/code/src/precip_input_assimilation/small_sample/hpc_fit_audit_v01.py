"""Original complete fit audit with the predeclared single-seed HPC scope."""
import ast
import copy
import hashlib
from pathlib import Path

ORIGINAL_SHA256 = "646cc3b020d015574b3f21f6ccfbf8d4d74dbb4423497c7505d07183c8a12a3b"


def adapted_function_ast(raw):
    if hashlib.sha256(raw).hexdigest() != ORIGINAL_SHA256:
        raise PermissionError("Original full fit audit bytes changed")
    tree = ast.parse(raw.decode("utf-8-sig"))
    function = copy.deepcopy(next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "audit_fit_stage"))
    changes = []
    for node in ast.walk(function):
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "seeds" for t in node.targets):
            if not isinstance(node.value, ast.IfExp) or ast.literal_eval(node.value.orelse) != [1001, 1002, 1003]:
                raise PermissionError("Unexpected original fit seed policy")
            node.value.orelse = ast.List(elts=[ast.Constant(1001)], ctx=ast.Load())
            changes.append("fixed_seed_1001")
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "_original_sources":
            node.func = ast.Attribute(value=ast.Name(id="ctx", ctx=ast.Load()), attr="verify_saved_source_admission", ctx=ast.Load())
            node.args = []
            changes.append("relocated_source_admission")
    if sorted(changes) != ["fixed_seed_1001", "relocated_source_admission"]:
        raise PermissionError("Only the two reviewed scope/path adaptations are permitted")
    return ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[]))


def audit_fit_stage(ctx, result):
    if ctx.seed_scope != [1001]:
        raise PermissionError("Fitting audit seed scope was not predeclared as 1001")
    from . import local_gradient_independent_v06 as original
    path = Path(original.__file__)
    tree = adapted_function_ast(path.read_bytes())
    namespace = dict(vars(original))
    exec(compile(tree, str(path) + ":hpc_scope_v01", "exec"), namespace)
    return namespace["audit_fit_stage"](ctx, result)
