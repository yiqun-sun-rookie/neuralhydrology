"""Standard-library budget transactions and durable, pre-operation counters.

This module does not acquire a second lock, supervise processes, run numerical
code, or recover open reservations.  The external supervisor holds the original
OS family lock for its complete lifetime and verifies its exact creation
identity in ``assert_owner``.  Only that supervisor may instantiate these APIs.
The original budget reader is loaded from its exact pinned, unmodified bytes.

All failures leave evidence.  A budget rotation replaces the live ledger once,
with BOTH the settlement and successor reservation.  A counter registration is
charged before its receipt is returned, including operations that later fail.
Detached counter event receipts are immutable; an incomplete commit fails
closed on subsequent reads instead of assuming a missing counter means zero.
"""

import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import stat
import time
import uuid


TOTAL_SECONDS = 259200
OLD_BASELINE_SECONDS = 96089
MAX_RESERVATION_SECONDS = 21600
EXIT_MARGIN_SECONDS = 300
ORIGINAL_HELPER_SHA256 = "fd38ecbd0b669a23665138574237ad383171b4249cfd40e36900658520387baa"
ORIGINAL_HELPER = Path(__file__).resolve().parents[1] / "scripts/run_precip_effect_first_v02.py"
COUNTER_LIMITS = {
    "gradient_full_forward": 100,
    "direct_science_update": 1000,
    "network_1001_science_update": 1000,
    "network_1002_science_update": 1000,
    "network_1003_science_update": 1000,
}
FIT_COUNTERS = {
    "direct_control": "fit_direct_full_forward",
    "seed_1001": "fit_network_1001_full_forward",
    "seed_1002": "fit_network_1002_full_forward",
    "seed_1003": "fit_network_1003_full_forward",
}
ALL_COUNTER_NAMES = tuple(COUNTER_LIMITS) + tuple(FIT_COUNTERS.values())
STAGE_FIT_COUNTER = {
    "direct_science_update": FIT_COUNTERS["direct_control"],
    "network_1001_science_update": FIT_COUNTERS["seed_1001"],
    "network_1002_science_update": FIT_COUNTERS["seed_1002"],
    "network_1003_science_update": FIT_COUNTERS["seed_1003"],
}
COUNTER_SCHEMA = "precip_flexible_operation_counters_v04"


def digest(value):
    """Hash canonical JSON, with undefined floating-point values forbidden."""
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode("utf-8")).hexdigest()


def _file_sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _sha(value):
    if not isinstance(value, str) or len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
        raise PermissionError("A binding must contain an explicit lowercase SHA256")
    return value


def _text(value, name):
    if not isinstance(value, str) or not value.strip():
        raise PermissionError("Missing explicit " + name)
    return value


def _utc():
    return datetime.now(timezone.utc).isoformat()


def _json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")


def _write_new_bytes(path, data):
    """Exclusive create plus fsync; an existing evidence file is never changed."""
    with Path(path).open("xb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())


def _write_new_json(path, value):
    _write_new_bytes(path, _json_bytes(value))


def _record_failure(directory, error):
    # The underlying failure, candidate, and preimage remain even if this final
    # metadata write also fails (e.g. the disk is full).
    try:
        _write_new_json(Path(directory) / "failure.json", {
            "error_type": type(error).__name__, "error": str(error), "utc": _utc()})
    except Exception:
        pass


def _load_original_helper(path):
    path = Path(path)
    if _file_sha256(path) != ORIGINAL_HELPER_SHA256:
        raise PermissionError("The original budget helper's exact bytes changed")
    spec = importlib.util.spec_from_file_location("precip_original_budget_reader_v04", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _append_budget_event(helper, journal, event):
    event = dict(event, previous_sha256=journal["events"][-1]["sha256"] if journal["events"] else None)
    record = {"payload": event, "sha256": helper.budget_hash(event)}
    journal["events"].append(record)
    return record


def _ordinary_absolute_path(path):
    """Normalize logical paths without filesystem resolution or hidden errors."""
    value = os.fspath(path)
    if not isinstance(value, str):
        raise TypeError("Family manifest paths must be text")
    if os.name == "nt":
        if value.startswith("\\\\?\\UNC\\"):
            value = "\\\\" + value[8:]
        elif value.startswith("\\\\?\\"):
            value = value[4:]
        if value.startswith("\\\\.\\") or value.startswith("\\??\\"):
            raise PermissionError("Device paths are not family filesystem paths")
    return Path(os.path.abspath(os.path.normpath(value)))


def _extended_filesystem_path(path):
    """Use the actual Windows extended namespace for every traversal query."""
    value = str(_ordinary_absolute_path(path))
    if os.name != "nt":
        return value
    if value.startswith("\\\\"):
        return "\\\\?\\UNC\\" + value[2:]
    return "\\\\?\\" + value


def _strict_manifest_lstat(path):
    # No exists(), is_dir(), glob(), or resolve(): none may hide a query error.
    identity = os.lstat(_extended_filesystem_path(path))
    if stat.S_ISLNK(identity.st_mode) or \
            getattr(identity, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
        raise PermissionError("Family traversal encountered a link or reparse point")
    return identity


def _strict_family_manifests(root):
    """Visit all directories or raise; long paths and missing entries cannot skip."""
    root = _ordinary_absolute_path(root)
    for ancestor in (*reversed(root.parents), root):
        if not stat.S_ISDIR(_strict_manifest_lstat(ancestor).st_mode):
            raise NotADirectoryError("Family traversal ancestor is not a directory: " + str(ancestor))
    pending = [root]
    while pending:
        directory = pending.pop()
        if not stat.S_ISDIR(_strict_manifest_lstat(directory).st_mode):
            raise NotADirectoryError("Family directory changed during traversal: " + str(directory))
        # scandir entry/iteration/close errors propagate directly to admission.
        with os.scandir(_extended_filesystem_path(directory)) as entries:
            for entry in entries:
                child = directory / entry.name
                identity = _strict_manifest_lstat(child)
                if stat.S_ISDIR(identity.st_mode):
                    pending.append(child)
                elif (entry.name.casefold() if os.name == "nt" else entry.name) == "manifest.json":
                    if not stat.S_ISREG(identity.st_mode):
                        raise PermissionError("A family manifest is not a regular file")
                    yield child


def _require_registered_family_manifests(root, allocations):
    known_outputs = {os.path.normcase(str(_ordinary_absolute_path(record["payload"]["output"])))
                     for record in allocations.values()}
    for manifest in _strict_family_manifests(root):
        logical_parent = os.path.normcase(str(_ordinary_absolute_path(manifest.parent)))
        if logical_parent not in known_outputs:
            raise PermissionError("Existing trial manifest has no budget reservation")


class BudgetSession:
    """One attempt, one external owner, and successive original-schema slices.

    ``baseline_bytes`` is the preserved pre-implementation ledger, not the
    current ledger bytes after append.  It must verify as 96089 charged seconds
    and have no open allocations.  Later sessions require that entire baseline
    event prefix, plus every event already observed in the current session.
    The caller must separately audit earlier attempts and unaccounted manifests.

    ``assert_owner()`` must raise unless the caller still holds the actual OS
    lock and has its original creation identity and nonce.  No Boolean file is
    a substitute for that check.  ``fault_hook`` is solely for reserved-budget
    synthetic fault injection; production callers leave it unspecified.
    """

    def __init__(self, ledger_path, receipt_dir, baseline_bytes, attempt_id, nonce,
                 source_sha256, config_sha256, script_sha256, owner_binding,
                 assert_owner, helper_path=ORIGINAL_HELPER, clock=time.monotonic,
                 fault_hook=None):
        self.ledger_path = Path(ledger_path)
        self.receipt_dir = Path(receipt_dir)
        self.attempt_id = _text(attempt_id, "attempt identity")
        self.nonce = _text(nonce, "attempt nonce")
        self.source_sha256 = _sha(source_sha256)
        self.config_sha256, self.script_sha256 = _sha(config_sha256), _sha(script_sha256)
        if not isinstance(owner_binding, dict) or not owner_binding:
            raise PermissionError("Exact supervisor creation identity is required")
        self.owner_binding = copy.deepcopy(owner_binding)
        self.owner_sha256 = digest(owner_binding)
        self.assert_owner, self.clock, self.fault_hook = assert_owner, clock, fault_hook
        self.helper = _load_original_helper(helper_path)
        if not isinstance(baseline_bytes, bytes):
            raise TypeError("Preserved baseline must be exact bytes")
        self.baseline_bytes = baseline_bytes
        self.baseline = json.loads(baseline_bytes.decode("utf-8"))
        self._known_events = copy.deepcopy(self.baseline["events"])
        self.reservation = None
        self.worker_group_sha256 = None
        self.global_deadline = None
        self.slice_deadline = None
        self.slice_started = None
        self.output = None
        self.slice_index = 0
        self._busy = False
        self._failed = False
        self._closed = False
        self.receipts = []
        self._actual_seconds = 0.0
        self._charged_seconds = 0

    def _fault(self, point):
        if self.fault_hook is not None:
            self.fault_hook(point)

    def _owner(self):
        if self._closed or self._failed:
            raise PermissionError("Closed or failed attempt cannot resume numerical work")
        self.assert_owner()

    def _read(self):
        self._owner()
        if not self.ledger_path.is_file():
            raise PermissionError("Missing ledger cannot be treated as unused budget")
        raw = self.ledger_path.read_bytes()
        journal, used, allocations, settled = self.helper.load_budget(self.ledger_path)
        if journal["events"][:len(self._known_events)] != self._known_events:
            raise PermissionError("Preserved budget event prefix was changed or removed")
        if self.reservation is not None and journal["events"] != self._known_events:
            raise PermissionError("Another writer changed this owner's active ledger")
        self._known_events = copy.deepcopy(journal["events"])
        return raw, journal, used, allocations, settled

    def _commit(self, raw, journal, open_run_id, operation, timing):
        """Validate a FULL archived candidate before one live-ledger replace."""
        transaction_id = uuid.uuid4().hex
        transaction = self.receipt_dir / ("transaction_" + transaction_id)
        transaction.mkdir(parents=True, exist_ok=False)
        stage = self.ledger_path.with_name(self.ledger_path.name + ".v04." + transaction_id + ".partial")
        try:
            _write_new_bytes(transaction / "old_budget_bytes.json", raw)
            _write_new_json(transaction / "prepared.json", {
                "operation": operation, "attempt_id": self.attempt_id, "attempt_nonce": self.nonce,
                "source_sha256": self.source_sha256, "owner_sha256": self.owner_sha256,
                "worker_group_sha256": self.worker_group_sha256, "timing": timing,
                "old_file_sha256": hashlib.sha256(raw).hexdigest(), "utc": _utc()})
            candidate_path = transaction / "candidate_budget.json"
            _write_new_json(candidate_path, journal)
            self._fault("candidate_written")
            checked, used, allocations, settled = self.helper.load_budget(candidate_path)
            expected_open = set() if open_run_id is None else {open_run_id}
            if checked != journal or set(allocations) - set(settled) != expected_open:
                raise PermissionError("Candidate is not the intended complete budget transaction")
            if checked["events"][:len(self._known_events)] != self._known_events:
                raise PermissionError("Candidate changed the original budget prefix")
            _write_new_json(transaction / "validated.json", {
                "candidate_sha256": _file_sha256(candidate_path), "used_seconds": used,
                "open_run_ids": sorted(expected_open), "utc": _utc()})
            self._fault("candidate_validated")
            _write_new_bytes(stage, candidate_path.read_bytes())
            # The file actually passed to os.replace is independently validated.
            staged, _, _, _ = self.helper.load_budget(stage)
            if staged != checked:
                raise PermissionError("Staged budget differs from validated candidate")
            self._owner()
            if self.ledger_path.read_bytes() != raw:
                raise PermissionError("Active ledger changed during the locked transaction")
            self._fault("before_replace")
            os.replace(stage, self.ledger_path)
            self._fault("after_replace")
            self._known_events = copy.deepcopy(journal["events"])
            result = {"transaction_id": transaction_id, "operation": operation,
                      "candidate_sha256": _file_sha256(candidate_path), "used_seconds": used,
                      "open_run_id": open_run_id, "timing": timing, "utc": _utc()}
            _write_new_json(transaction / "committed.json", result)
            self.receipts.append(result)
            return result
        except BaseException as error:
            self._failed = True
            _record_failure(transaction, error)
            raise

    def _reservation_event(self, journal, seconds, used):
        # Keep all original keys and exact original maximum.  Additional slice
        # metadata lives in transaction receipts, not the old ledger schema.
        return _append_budget_event(self.helper, journal, {
            "kind": "reserve", "run_id": uuid.uuid4().hex, "output": str(self.output.resolve()),
            "config_sha256": self.config_sha256, "script_sha256": self.script_sha256,
            "reserved_seconds": seconds, "used_before_seconds": used, "started_utc": _utc()})

    def start(self, output):
        """Reserve before creating the new run directory or starting its group."""
        self._owner()
        if self.reservation is not None or self._busy:
            raise PermissionError("An attempt can only start once")
        boundary = self.clock()
        raw, journal, used, allocations, settled = self._read()
        if set(allocations) - set(settled):
            raise PermissionError("An unsettled reservation blocks a new owner")
        self.output = Path(output)
        if self.output.exists():
            raise FileExistsError("An existing numerical output cannot be reused")
        _require_registered_family_manifests(self.ledger_path.parent, allocations)
        remaining = TOTAL_SECONDS - used
        if remaining <= EXIT_MARGIN_SECONDS:
            raise TimeoutError("No new numerical work within the total exit margin")
        self.receipt_dir.mkdir(parents=True, exist_ok=True)
        baseline_path = self.receipt_dir / "preserved_baseline_budget.json"
        _write_new_bytes(baseline_path, self.baseline_bytes)
        baseline, baseline_used, baseline_allocations, baseline_settled = self.helper.load_budget(baseline_path)
        if baseline != self.baseline or baseline_used != OLD_BASELINE_SECONDS or \
                set(baseline_allocations) - set(baseline_settled):
            raise PermissionError("Preserved original 96089-second baseline is not valid and settled")
        candidate = copy.deepcopy(journal)
        seconds = min(MAX_RESERVATION_SECONDS, remaining)
        reservation = self._reservation_event(candidate, seconds, used)
        self.global_deadline = boundary + remaining
        self.slice_started, self.slice_deadline = boundary, boundary + seconds
        result = self._commit(raw, candidate, reservation["payload"]["run_id"], "initial_reserve", {
            "boundary_monotonic": boundary, "slice_seconds": seconds,
            "global_deadline": self.global_deadline})
        self.reservation, self.slice_index = reservation, 1
        result["reservation"] = copy.deepcopy(reservation)
        return result

    def bind_worker_group(self, binding):
        """Bind startup metadata; real process identity checks stay external."""
        self._owner()
        if self.reservation is None or self.worker_group_sha256 is not None:
            raise PermissionError("Worker group binding is allowed exactly once after reserve")
        if not isinstance(binding, dict) or not binding:
            raise PermissionError("Exact worker creation identity and group binding are required")
        identity = digest(binding)
        _write_new_json(self.receipt_dir / "bound_worker_group.json", {
            "binding": binding, "sha256": identity, "owner_sha256": self.owner_sha256,
            "attempt_nonce": self.nonce, "source_sha256": self.source_sha256, "utc": _utc()})
        self.worker_group_sha256 = identity
        return identity

    def check_operation(self, begin_operation=True):
        self._owner()
        if self.reservation is None or self.worker_group_sha256 is None:
            raise PermissionError("Numerical operations require an active bound group")
        self._read()
        now = self.clock()
        if now > self.global_deadline or now > self.slice_deadline:
            raise TimeoutError("Actual computation crossed its reserved or cumulative deadline")
        if begin_operation and self.global_deadline - now <= EXIT_MARGIN_SECONDS:
            raise TimeoutError("Total-budget exit margin blocks new numerical work")
        return {"global_deadline": self.global_deadline, "slice_deadline": self.slice_deadline,
                "slice_index": self.slice_index, "reservation_sha256": self.reservation["sha256"],
                "remaining_seconds": self.global_deadline - now,
                "owner_sha256": self.owner_sha256, "worker_group_sha256": self.worker_group_sha256}

    @property
    def needs_rotation(self):
        self.check_operation(begin_operation=False)
        return self.slice_deadline - self.clock() <= EXIT_MARGIN_SECONDS

    def _check_proof(self, proof, fields):
        if not isinstance(proof, dict) or proof.get("owner_sha256") != self.owner_sha256 or \
                proof.get("worker_group_sha256") != self.worker_group_sha256 or \
                proof.get("attempt_nonce") != self.nonce or any(proof.get(key) is not True for key in fields):
            raise PermissionError("Missing or mismatched synchronized/group-exit proof")

    def rotate(self, checkpoint_proof):
        """Same measured boundary settles the old slice and starts the new one."""
        entered = False
        try:
            # Pre-candidate failures must also stop the attempt.  A recursive
            # rejected call must not clear the outer call's rotation flag.
            self._owner()
            if self._busy:
                raise PermissionError("Budget rotation cannot recursively invoke itself")
            self._busy = True
            entered = True
            self._check_proof(checkpoint_proof, ("device_synchronized", "new_operations_paused"))
            self.check_operation(begin_operation=False)
            boundary = self.clock()
            elapsed = boundary - self.slice_started
            if not math.isfinite(elapsed) or elapsed < 0 or boundary > self.slice_deadline:
                raise TimeoutError("An overrun cannot be hidden as a normal rotation")
            raw, journal, used, allocations, settled = self._read()
            run_id = self.reservation["payload"]["run_id"]
            if allocations.get(run_id) != self.reservation or run_id in settled:
                raise PermissionError("Current reservation is changed or already settled")
            charged = math.ceil(elapsed)
            used_after_settle = used - self.reservation["payload"]["reserved_seconds"] + charged
            remaining = TOTAL_SECONDS - used_after_settle
            shortened_deadline = min(self.global_deadline, boundary + remaining)
            if shortened_deadline - boundary <= EXIT_MARGIN_SECONDS:
                raise TimeoutError("The total remaining budget cannot support a new slice")
            seconds = min(MAX_RESERVATION_SECONDS, remaining)
            candidate = copy.deepcopy(journal)
            settlement = _append_budget_event(self.helper, candidate, {
                "kind": "settle", "run_id": run_id, "reservation_sha256": self.reservation["sha256"],
                "charged_seconds": charged, "ended_utc": _utc()})
            reservation = self._reservation_event(candidate, seconds, used_after_settle)
            timing = {"boundary_monotonic": boundary, "old_started_monotonic": self.slice_started,
                      "old_actual_seconds": elapsed, "old_charged_seconds": charged,
                      "rounding_seconds": charged - elapsed, "global_deadline": shortened_deadline,
                      "new_slice_seconds": seconds, "checkpoint_proof_sha256": digest(checkpoint_proof)}
            result = self._commit(raw, candidate, reservation["payload"]["run_id"], "rotate", timing)
            self._actual_seconds += elapsed
            self._charged_seconds += charged
            self.global_deadline = shortened_deadline
            self.slice_started, self.slice_deadline = boundary, boundary + seconds
            self.reservation = reservation
            self.slice_index += 1
            result.update({"settlement": settlement, "reservation": reservation})
            return result
        except BaseException:
            # Even pre-candidate failures stop new work.  Final settlement after
            # genuine group exit remains permitted through the dedicated API.
            self._failed = True
            raise
        finally:
            if entered:
                self._busy = False

    def final_settle(self, exit_proof, verify_exit):
        """Only externally verified WHOLE-group exit permits the final boundary.

        A failed attempt may be settled after a proven group exit only if its
        active ledger still matches its own current open reservation.  A crash
        or ambiguous commit is not automatically recovered by this API.
        """
        if self._closed or self.reservation is None or self.worker_group_sha256 is None:
            raise PermissionError("Final settlement needs this attempt's open bound group")
        self.assert_owner()
        self._check_proof(exit_proof, ("entire_group_exited",))
        if verify_exit(copy.deepcopy(exit_proof)) is not True:
            raise PermissionError("Supervisor did not prove all exact bound identities exited")
        # Query/verification and numeric exit evidence are included in elapsed.
        boundary = self.clock()
        was_failed = self._failed
        self._failed = False
        try:
            raw, journal, used, allocations, settled = self._read()
            run_id = self.reservation["payload"]["run_id"]
            if allocations.get(run_id) != self.reservation or run_id in settled:
                raise PermissionError("Final reservation differs from this owner")
            elapsed = boundary - self.slice_started
            if not math.isfinite(elapsed) or elapsed < 0:
                raise PermissionError("Final elapsed time is not a valid measured interval")
            charged = math.ceil(elapsed)
            candidate = copy.deepcopy(journal)
            settlement = _append_budget_event(self.helper, candidate, {
                "kind": "settle", "run_id": run_id, "reservation_sha256": self.reservation["sha256"],
                "charged_seconds": charged, "ended_utc": _utc()})
            timing = {"boundary_monotonic": boundary, "old_started_monotonic": self.slice_started,
                      "old_actual_seconds": elapsed, "old_charged_seconds": charged,
                      "rounding_seconds": charged - elapsed, "exit_proof_sha256": digest(exit_proof),
                      "allocation_overrun": charged > self.reservation["payload"]["reserved_seconds"],
                      "global_deadline_exceeded": boundary > self.global_deadline}
            result = self._commit(raw, candidate, None, "final_settle", timing)
            self._actual_seconds += elapsed
            self._charged_seconds += charged
            self._closed = True
            result.update({"settlement": settlement, "actual_seconds": self._actual_seconds,
                           "charged_seconds": self._charged_seconds,
                           "rounding_seconds": self._charged_seconds - self._actual_seconds,
                           "metadata_management_seconds_before_receipt_write": self.clock() - boundary,
                           "failed_attempt": was_failed})
            _write_new_json(self.receipt_dir / "final_metadata_receipt.json", result)
            # The returned duration includes the receipt write.  Any later
            # supervisor reporting/unlock time must be measured by that caller.
            result["metadata_management_seconds"] = self.clock() - boundary
            result["metadata_management_scope"] = "through_completed_budget_receipt_write"
            return result
        except BaseException:
            self._failed = True
            raise


class CounterStore:
    """Hash-chained registration receipts, persisted BEFORE operation starts.

    Initialization requires nine explicit verified counts and an independent
    initialization-evidence hash.  Existing stores never initialize/reset on a
    missing or damaged file.  Every new repair attempt binds its own nonce and
    source hash while retaining all preceding counts and immutable receipts.
    Audits bind one saved path and a unique list of saved string update IDs;
    each member can be reconstructed once per audit attempt, at most 1000.
    """

    def __init__(self, root, binding, assert_owner, fault_hook=None):
        self.root = Path(root)
        self.path = self.root / "operation_counters_v04.json"
        if not isinstance(binding, dict) or set(binding) != {"scope", "nonce", "source_sha256"}:
            raise PermissionError("Counter store requires exact scope, nonce and source binding")
        _text(binding["scope"], "counter scope")
        _text(binding["nonce"], "counter-store nonce")
        _sha(binding["source_sha256"])
        self.binding = copy.deepcopy(binding)
        self.assert_owner, self.fault_hook = assert_owner, fault_hook
        self._known_events = None
        self._cached_document = None
        self._cached_state = None
        self._expected_head_bytes = None
        self._failed_commit = False
        self._write_admitted = False

    def _require_write_admission(self):
        self.assert_owner()
        if not self._write_admitted:
            raise PermissionError("Existing counters require explicit verified reopen before any new starts")
        if self._failed_commit:
            raise PermissionError("An incomplete counter commit blocks further starts in this attempt")

    def _fault(self, point):
        if self.fault_hook is not None:
            self.fault_hook(point)

    def _validate(self, document, check_receipts=True, incremental=False):
        if not isinstance(document, dict) or set(document) != {"schema", "binding", "initial_counts",
                                                              "initialization_evidence_sha256", "events"} or \
                document["schema"] != COUNTER_SCHEMA or document["binding"] != self.binding:
            raise PermissionError("Counter schema or immutable source/nonce binding differs")
        _sha(document["initialization_evidence_sha256"])
        counts = copy.deepcopy(document["initial_counts"])
        if not isinstance(counts, dict) or set(counts) != set(ALL_COUNTER_NAMES):
            raise PermissionError("All nine initial counters must explicitly exist")
        for kind in ALL_COUNTER_NAMES:
            limit = COUNTER_LIMITS.get(kind)
            value = counts[kind]
            if not isinstance(value, int) or isinstance(value, bool) or value < 0 or \
                    (limit is not None and value > limit):
                raise PermissionError("An initial operation counter is invalid")
        events = document["events"]
        if not isinstance(events, list) or not events:
            raise PermissionError("Counter genesis receipt is missing")
        if incremental:
            if self._cached_state is None or events[:-1] != self._known_events:
                raise PermissionError("Incremental counter validation has no exact verified prefix")
            state = copy.deepcopy(self._cached_state)
            counts, attempts = state["counts"], state["attempts"]
            operation_nonces, audit_consumed = state["operation_nonces"], state["audit_consumed"]
            attempt_nonces = state["attempt_nonces"]
            start = len(events) - 1
            previous = events[start - 1]["sha256"]
        else:
            previous, attempts, operation_nonces, audit_consumed = digest({
                key: value for key, value in document.items() if key != "events"}), {}, set(), {}
            attempt_nonces = set()
            start = 0
        for sequence in range(start, len(events)):
            record = events[sequence]
            if not isinstance(record, dict) or set(record) != {"payload", "sha256"}:
                raise PermissionError("Counter receipt shape differs")
            payload = record["payload"]
            if digest(payload) != record["sha256"] or payload.get("sequence") != sequence or \
                    payload.get("previous_sha256") != previous or payload.get("binding") != self.binding:
                raise PermissionError("Counter chain, source, nonce, or sequence differs")
            previous = record["sha256"]
            if check_receipts:
                receipt = self.root / "events" / (str(sequence).zfill(6) + "_" + record["sha256"] + ".json")
                if not receipt.is_file() or json.loads(receipt.read_text(encoding="utf-8")) != record:
                    raise PermissionError("Immutable durable counter receipt is missing or altered")
            event = payload.get("event")
            if sequence == 0:
                if event != {"kind": "initialize", "evidence_sha256": document["initialization_evidence_sha256"]}:
                    raise PermissionError("Counter genesis does not match explicit initialization")
                continue
            if event.get("kind") == "attempt":
                attempt_id = _text(event.get("attempt_id"), "counter attempt")
                attempt_nonce = _text(event.get("attempt_nonce"), "counter attempt nonce")
                _sha(event.get("source_sha256"))
                if attempt_id in attempts or attempt_nonce in attempt_nonces or \
                        event.get("stage") not in set(COUNTER_LIMITS) | {"audit_reconstruction"}:
                    raise PermissionError("Duplicate attempt or unknown fixed counter stage")
                attempt_nonces.add(attempt_nonce)
                if event["stage"] == "audit_reconstruction":
                    audit = event.get("audit_binding")
                    if not isinstance(audit, dict) or set(audit) != {"saved_path", "saved_path_sha256", "updates"}:
                        raise PermissionError("Audit requires a persisted saved-path/update-list binding")
                    saved_path = Path(_text(audit["saved_path"], "audit saved path"))
                    _sha(audit["saved_path_sha256"])
                    updates = audit["updates"]
                    if not saved_path.is_absolute() or not isinstance(updates, list) or not 0 < len(updates) <= 1000 or \
                            any(not isinstance(item, str) or not item for item in updates) or len(set(updates)) != len(updates):
                        raise PermissionError("Audit saved update list is invalid or exceeds 1000")
                    audit_consumed[attempt_id] = set()
                elif event.get("audit_binding") is not None:
                    raise PermissionError("Scientific counters cannot carry an audit update list")
                attempts[attempt_id] = event
            elif event.get("kind") == "operation":
                attempt_id, nonce = event.get("attempt_id"), _text(event.get("operation_nonce"), "operation nonce")
                if attempt_id not in attempts or nonce in operation_nonces:
                    raise PermissionError("Operation has no admitted attempt or reused nonce")
                operation_nonces.add(nonce)
                attempt = attempts[attempt_id]
                allowed = {attempt["stage"]}
                if attempt["stage"] in STAGE_FIT_COUNTER:
                    allowed.add(STAGE_FIT_COUNTER[attempt["stage"]])
                elif attempt["stage"] == "audit_reconstruction":
                    allowed.update(FIT_COUNTERS.values())
                if event.get("attempt_nonce") != attempt["attempt_nonce"] or \
                        event.get("source_sha256") != attempt["source_sha256"] or event.get("counter") not in allowed:
                    raise PermissionError("Operation's source/nonce/stage binding differs")
                counter = event["counter"]
                if counter == "audit_reconstruction":
                    update_id = event.get("update_id")
                    if update_id not in attempt["audit_binding"]["updates"] or update_id in audit_consumed[attempt_id]:
                        raise PermissionError("Audit update is absent or already reconstructed in this attempt")
                    audit_consumed[attempt_id].add(update_id)
                    cumulative = len(audit_consumed[attempt_id])
                else:
                    if event.get("update_id") is not None and counter not in FIT_COUNTERS.values():
                        raise PermissionError("Scientific training cannot use the audit-update exemption")
                    counts[counter] += 1
                    cumulative = counts[counter]
                    if counter in COUNTER_LIMITS and cumulative > COUNTER_LIMITS[counter]:
                        raise PermissionError("Cumulative fixed scientific counter exceeded")
                if event.get("cumulative_count") != cumulative:
                    raise PermissionError("Stored count does not match all preceding durable starts")
            else:
                raise PermissionError("Unknown counter event")
        if check_receipts:
            receipts = list((self.root / "events").glob("*.json"))
            if len(receipts) != len(events):
                raise PermissionError("Uncommitted or missing counter receipt requires independent audit")
        if self._known_events is not None and events[:len(self._known_events)] != self._known_events:
            raise PermissionError("Previously observed counter prefix was removed or changed")
        return {"counts": counts, "attempts": attempts, "audit_consumed": audit_consumed,
                "operation_nonces": operation_nonces, "attempt_nonces": attempt_nonces}

    def _head(self, document):
        """Constant-size commit head; immutable event receipts carry the chain."""
        head = {key: value for key, value in document.items() if key != "events"}
        head.update({"event_count": len(document["events"]),
                     "head_sha256": document["events"][-1]["sha256"],
                     "genesis_sha256": document["events"][0]["sha256"]})
        return head

    def _read(self, full=False):
        self.assert_owner()
        if not self.path.is_file():
            raise PermissionError("Missing durable counter file cannot default to zero")
        raw = self.path.read_bytes()
        head = json.loads(raw.decode("utf-8"))
        if not isinstance(head, dict) or set(head) != {"schema", "binding", "initial_counts",
                                                     "initialization_evidence_sha256", "event_count",
                                                     "head_sha256", "genesis_sha256"}:
            raise PermissionError("Counter commit head is missing or has an altered schema")
        if self._cached_document is not None and not full:
            if raw != self._expected_head_bytes:
                raise PermissionError("Exact observed counter commit head changed outside this owner")
            last = self._cached_document["events"][-1]
            receipt_path = self.root / "events" / (
                str(last["payload"]["sequence"]).zfill(6) + "_" + last["sha256"] + ".json")
            if not receipt_path.is_file() or json.loads(receipt_path.read_text(encoding="utf-8")) != last:
                raise PermissionError("Latest persisted operation receipt is missing or changed")
            # Cache is allowed only under this same exact externally checked OS
            # owner.  Independent/stage/final snapshots re-read EVERY receipt.
            document = {key: copy.deepcopy(value) for key, value in self._cached_document.items() if key != "events"}
            document["events"] = list(self._cached_document["events"])
            return raw, document, copy.deepcopy(self._cached_state)
        event_count = head["event_count"]
        if not isinstance(event_count, int) or isinstance(event_count, bool) or event_count <= 0:
            raise PermissionError("Counter head has no explicit valid event count")
        receipts = sorted((self.root / "events").glob("*.json"))
        if len(receipts) != event_count:
            raise PermissionError("Orphan, missing or truncated operation receipts require independent audit")
        document = {key: value for key, value in head.items()
                    if key not in {"event_count", "head_sha256", "genesis_sha256"}}
        document["events"] = [json.loads(path.read_text(encoding="utf-8")) for path in receipts]
        snapshot = self._validate(document)
        if self._head(document) != head:
            raise PermissionError("Counter commit head does not bind the full persisted receipt chain")
        self._known_events = copy.deepcopy(document["events"])
        self._cached_document = copy.deepcopy(document)
        self._cached_state = copy.deepcopy(snapshot)
        self._expected_head_bytes = raw
        return raw, document, snapshot

    def _append(self, document, event):
        sequence = len(document["events"])
        previous = document["events"][-1]["sha256"] if sequence else digest({
            key: value for key, value in document.items() if key != "events"})
        payload = {"sequence": sequence, "previous_sha256": previous, "binding": self.binding,
                   "event": event, "registered_utc": _utc()}
        record = {"payload": payload, "sha256": digest(payload)}
        document["events"].append(record)
        return record

    def _commit(self, raw, document, record):
        self.assert_owner()
        if raw is not None:
            self._require_write_admission()
        if self._failed_commit:
            raise PermissionError("An incomplete counter commit blocks further starts in this attempt")
        transaction = self.root / ("transaction_" + uuid.uuid4().hex)
        transaction.mkdir(parents=True, exist_ok=False)
        stage = self.path.with_name(self.path.name + "." + transaction.name + ".partial")
        receipt_persisted = False
        try:
            if raw is not None:
                _write_new_bytes(transaction / "old_counter_bytes.json", raw)
            # Archive only the new receipt and constant-size head.  Rewriting
            # the full history per start would produce quadratic disk growth.
            head = self._head(document)
            _write_new_json(transaction / "candidate_counter_head.json", head)
            _write_new_json(transaction / "candidate_counter_record.json", record)
            state = self._validate(document, check_receipts=False, incremental=raw is not None)
            self._fault("counter_candidate_validated")
            (self.root / "events").mkdir(exist_ok=True)
            sequence = record["payload"]["sequence"]
            _write_new_json(self.root / "events" / (str(sequence).zfill(6) + "_" + record["sha256"] + ".json"), record)
            receipt_persisted = True
            self._fault("counter_receipt_persisted")
            staged_bytes = _json_bytes(head)
            _write_new_bytes(stage, staged_bytes)
            self.assert_owner()
            if raw is None:
                if self.path.exists():
                    raise PermissionError("Counter initialization raced an existing store")
            elif self.path.read_bytes() != raw:
                raise PermissionError("Counter prefix changed during locked registration")
            os.replace(stage, self.path)
            self._fault("counter_committed")
            # Records are private immutable dictionaries; callers receive deep
            # copies.  Copy only the list, avoiding repeated copies of history.
            self._known_events = list(document["events"])
            self._cached_document = dict(document, events=list(document["events"]))
            self._cached_state = copy.deepcopy(state)
            self._expected_head_bytes = staged_bytes
            _write_new_json(transaction / "committed.json", {"receipt_sha256": record["sha256"], "utc": _utc()})
            return copy.deepcopy(record)
        except BaseException as error:
            if receipt_persisted:
                self._failed_commit = True
            _record_failure(transaction, error)
            raise

    def initialize(self, initial_counts, initialization_evidence_sha256):
        """An explicit one-time origin; no automatic creation during reads."""
        self.assert_owner()
        if self.root.exists() and any(self.root.iterdir()):
            raise FileExistsError("Counter initialization requires a new empty store")
        self.root.mkdir(parents=True, exist_ok=True)
        document = {"schema": COUNTER_SCHEMA, "binding": self.binding,
                    "initial_counts": copy.deepcopy(initial_counts),
                    "initialization_evidence_sha256": _sha(initialization_evidence_sha256), "events": []}
        record = self._append(document, {"kind": "initialize", "evidence_sha256": initialization_evidence_sha256})
        receipt = self._commit(None, document, record)
        self._write_admitted = True
        return receipt

    def reopen(self, expected_snapshot_sha256, expected_head_sha256, event_count,
               initialization_evidence_sha256):
        """Admit a new owner against an externally frozen FULL snapshot.

        The expected snapshot hash is ``digest(parsed_snapshot)``, not the raw
        file hash.  The supervisor must first verify that external snapshot
        file's original bytes and the first store binding file; this instance
        must use that ORIGINAL scope, nonce, and source binding unchanged.
        Fresh attempt nonces and sources are appended by ``admit_attempt``.

        This method reads every event and checks every immutable receipt.  It
        writes nothing, never resets counts, and does not recover orphan or
        incomplete commits.  Snapshot inspection alone grants no write access.
        """
        self.assert_owner()
        if self._write_admitted or self._failed_commit:
            raise PermissionError("Reopen is only for a fresh, unadmitted counter-store instance")
        _sha(expected_snapshot_sha256)
        _sha(expected_head_sha256)
        _sha(initialization_evidence_sha256)
        if not isinstance(event_count, int) or isinstance(event_count, bool) or event_count <= 0:
            raise PermissionError("Reopen requires the explicit frozen positive event count")
        snapshot = self.snapshot()
        if snapshot["binding"] != self.binding or snapshot["head_sha256"] != expected_head_sha256 or \
                snapshot["event_count"] != event_count or \
                snapshot["initialization_evidence_sha256"] != initialization_evidence_sha256 or \
                digest(snapshot) != expected_snapshot_sha256:
            raise PermissionError("Counter history does not exactly match the frozen reopen evidence")
        self.assert_owner()
        if self.path.read_bytes() != self._expected_head_bytes:
            raise PermissionError("Counter commit head changed during reopen admission")
        self._write_admitted = True
        return copy.deepcopy(snapshot)

    def snapshot(self):
        """Fully re-read all persisted receipts; use at stage/audit/final bounds."""
        _, document, state = self._read(full=True)
        return {"counts": state["counts"], "attempts": copy.deepcopy(state["attempts"]),
                "audit_counts": {key: len(value) for key, value in state["audit_consumed"].items()},
                "head_sha256": document["events"][-1]["sha256"], "event_count": len(document["events"]),
                "receipts": copy.deepcopy(document["events"]), "binding": copy.deepcopy(self.binding),
                "initial_counts": copy.deepcopy(document["initial_counts"]),
                "initialization_evidence_sha256": document["initialization_evidence_sha256"]}

    def admit_attempt(self, attempt_id, attempt_nonce, source_sha256, stage, audit_binding=None):
        self._require_write_admission()
        raw, document, _ = self._read()
        event = {"kind": "attempt", "attempt_id": _text(attempt_id, "attempt identity"),
                 "attempt_nonce": _text(attempt_nonce, "attempt nonce"), "source_sha256": _sha(source_sha256),
                 "stage": stage, "audit_binding": copy.deepcopy(audit_binding)}
        record = self._append(document, event)
        return self._commit(raw, document, record)

    def register_before_start(self, attempt_id, kind, operation_nonce, update_id=None, label=""):
        self._require_write_admission()
        raw, document, state = self._read()
        counts, attempts, audit_consumed = state["counts"], state["attempts"], state["audit_consumed"]
        if attempt_id not in attempts:
            raise PermissionError("Operation requires an admitted attempt for this exact counter")
        attempt = attempts[attempt_id]
        cumulative = len(audit_consumed[attempt_id]) + 1 if kind == "audit_reconstruction" else counts[kind] + 1
        record = self._append(document, {
            "kind": "operation", "attempt_id": attempt_id, "attempt_nonce": attempt["attempt_nonce"],
            "source_sha256": attempt["source_sha256"], "counter": kind,
            "operation_nonce": _text(operation_nonce, "operation nonce"), "update_id": update_id,
            "cumulative_count": cumulative, "label": str(label)})
        return self._commit(raw, document, record)

    def consume(self, kind, key, label, bindings=None, *, attempt_id, operation_nonce):
        """Thin mapping for the supervisor IPC; never called by worker directly."""
        self._require_write_admission()
        bindings = {} if bindings is None else bindings
        if kind == "full_forward" and key == "gradient":
            counter = "gradient_full_forward"
        elif kind in {"full_forward", "fit_full_forward"} and key in FIT_COUNTERS:
            counter = FIT_COUNTERS[key]
        elif kind in {"training_update", "scientific_update"}:
            counter = {"direct_control": "direct_science_update",
                       "seed_1001": "network_1001_science_update",
                       "seed_1002": "network_1002_science_update",
                       "seed_1003": "network_1003_science_update"}.get(key)
            if counter is None:
                raise PermissionError("Unknown fixed scientific training key")
        elif kind == "audit_reconstruction" and key == attempt_id:
            counter = "audit_reconstruction"
        else:
            raise PermissionError("Unknown scientific operation kind or fixed key")
        return self.register_before_start(attempt_id, counter, operation_nonce,
                                          update_id=bindings.get("update_id"), label=label)
