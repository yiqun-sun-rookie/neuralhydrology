"""Record completion of the existing paired pilot; never train or read raw data."""

import argparse
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import time


REPO = Path(__file__).resolve().parents[3]
ROOT = REPO / "results/precip_input_da_2026_09/effect_first_v01"
RUN_ID = "pilot_20261009_01487000_s1001_s1002_s1003_v02"
ENTRY = REPO / "src/precip_input_assimilation/scripts/run_precip_effect_first_v02.py"
ENTRY_SHA = "fd38ecbd0b669a23665138574237ad383171b4249cfd40e36900658520387baa"
CONFIG_SHA = "673bbe20be9d8dc3140994477fccff15dbc64d93d0aeed7c43a793473835f5e2"
REVIEW_SHA = "3e18744991e3a34246b72cb693796ae23a94b73e4386dcc47e85c7b23d38ee00"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write(path, record):
    path = Path(path)
    temporary = path.with_name(path.name + ".observer_partial")
    temporary.write_text(json.dumps(record, ensure_ascii=False, indent=2, sort_keys=True,
                                    allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def final_state(output, exit_code):
    """Validate fresh selected-artifact identities; reported gains are not a scientific audit."""
    if (output / "failure.json").is_file():
        return {"status": "failed_preserved", "failure_sha256": digest(output / "failure.json")}
    if exit_code != 0 or any(not (output / name).is_file() for name in
                            ("pilot_result.json", "exit_evidence.json", "budget_settlement.json")):
        return {"status": "stopped_without_complete_evidence"}
    result, exit_record = read(output / "pilot_result.json"), read(output / "exit_evidence.json")
    if not exit_record["original_sources_unchanged"] or not exit_record["original_transport_unchanged"]:
        raise PermissionError("Pilot exit evidence reports changed protected bytes")
    if result["score_values_read"] is not False or result["test_period_efficacy_confirmed"] is not False:
        raise PermissionError("Validation pilot cannot claim scoring-period acceptance")
    expected = {(arm, seed) for arm in ("original_penalties", "no_penalties") for seed in (1001, 1002, 1003)}
    rows = result["fits"]
    if len(rows) != 6 or {(row["arm"], row["seed"]) for row in rows} != expected:
        raise PermissionError("Pilot does not contain all six paired fits")
    for row in rows:
        directory = output / "fits" / row["arm"] / f"seed_{row['seed']}"
        coefficients = {"magnitude": .0001, "violation": .01} if row["arm"] == "original_penalties" else {
            "magnitude": 0., "violation": 0.}
        if read(directory / "fit_summary.json") != row or row["loss_weights"] != coefficients or \
                row["config_sha256"] != CONFIG_SHA or row["checkpoint_sha256"] != digest(directory / "selected.pt"):
            raise PermissionError("Selected-artifact identity differs from its fit proof")
        if not math.isfinite(row["validation_nse"]):
            raise PermissionError("Nonfinite validation result")
    gains = [next(row["validation_nse"] for row in rows if row["arm"] == "no_penalties" and row["seed"] == seed) -
             next(row["validation_nse"] for row in rows if row["arm"] == "original_penalties" and row["seed"] == seed)
             for seed in (1001, 1002, 1003)]
    median = sorted(gains)[1]
    if gains != result["paired_validation_gains"] or median != result["median_paired_validation_gain"] or \
            result["expansion_criterion_met"] != (median >= .005 and sum(gain > 0 for gain in gains) >= 2):
        raise PermissionError("Reported comparison arithmetic differs from the paired fit proofs")
    for seed in (1001, 1002, 1003):
        initial = [row["initial_tensors_sha256"] for row in rows if row["seed"] == seed]
        if initial[0] != initial[1]:
            raise PermissionError("Paired initial tensor identity differs")
    return {"status": "completed_validation_pilot_pending_independent_result_review",
            "pilot_result_sha256": digest(output / "pilot_result.json"),
            "reported_median_validation_gain": median,
            "reported_expansion_criterion_met": result["expansion_criterion_met"],
            "scoring_period_accepted": False, "independent_scientific_result_review_complete": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, required=True)
    args = parser.parse_args()
    evidence = args.evidence.absolute()
    if not evidence.resolve().is_relative_to(ROOT.resolve()) or evidence.exists():
        raise PermissionError("Observation evidence must be a fresh file in the trial root")
    if digest(ENTRY) != ENTRY_SHA:
        raise PermissionError("Reviewed training entry changed")
    launch = read(ROOT / (RUN_ID + "_launch.json"))
    output = ROOT / RUN_ID
    if Path(launch["output"]).resolve() != output.resolve() or launch["review_sha256"] != REVIEW_SHA:
        raise PermissionError("Observation launch binding differs from the reviewed pilot")
    if digest(launch["review_path"]) != REVIEW_SHA or read(output / "manifest.json")["script_sha256"] != ENTRY_SHA:
        raise PermissionError("Reviewed source or runtime binding changed")
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.GetProcessTimes.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(wintypes.FILETIME)] * 4)]
    kernel.GetProcessTimes.restype = wintypes.BOOL
    kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    kernel.WaitForSingleObject.restype = wintypes.DWORD
    kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
    kernel.GetExitCodeProcess.restype = wintypes.BOOL
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    # Retain this handle: PID reuse can never turn a later process into the owner.
    handle = kernel.OpenProcess(0x00100000 | 0x1000, False, launch["pid"])
    if not handle:
        raise OSError(ctypes.get_last_error(), "Original process identity query failed; exit is unknown")
    try:
        times = [wintypes.FILETIME() for _ in range(4)]
        if not kernel.GetProcessTimes(handle, *[ctypes.byref(value) for value in times]):
            raise OSError(ctypes.get_last_error(), "Original creation identity query failed")
        actual = str((times[0].dwHighDateTime << 32) + times[0].dwLowDateTime)
        if actual != launch["windows_creation_filetime"]:
            raise PermissionError("PID belongs to another creation identity; observation stops")
        print("Retained original process handle; observing existing pilot only", flush=True)
        deadline = time.monotonic() + 22200
        while True:
            state = kernel.WaitForSingleObject(handle, 0)
            if state == 0:
                code = wintypes.DWORD()
                if not kernel.GetExitCodeProcess(handle, ctypes.byref(code)):
                    raise OSError(ctypes.get_last_error(), "Original exit code query failed")
                conclusion = final_state(output, code.value)
                record = dict(conclusion, observed_utc=datetime.now(timezone.utc).isoformat(),
                              pid=launch["pid"], windows_creation_filetime=actual, actual_exit_code=code.value,
                              original_handle_signaled=True, observer_source_sha256=digest(__file__),
                              observer_scientific_input_reads=False, new_training_processes_started=0)
                write(evidence, record)
                registry_path = ROOT / "experiment_registry_v01.json"
                registry = read(registry_path)
                row = next(row for row in registry["experiments"] if row["exp_id"] == RUN_ID)
                if Path(row["run_dir"]).resolve() != output.resolve() or row["base_config_sha256"] != CONFIG_SHA:
                    raise PermissionError("Registry identity changed; preserved final evidence only")
                row.update(status=conclusion["status"], final_observation_path=str(evidence),
                           final_observation_sha256=digest(evidence))
                write(registry_path, registry)
                print(json.dumps(record, ensure_ascii=False), flush=True)
                return
            if state != 258:
                raise OSError(ctypes.get_last_error(), "Original process state query failed; exit is unknown")
            if time.monotonic() >= deadline:
                write(evidence, {"status": "observation_timeout_owner_not_stopped",
                                "pid": launch["pid"], "windows_creation_filetime": actual})
                return
            time.sleep(30)
    finally:
        kernel.CloseHandle(handle)


if __name__ == "__main__":
    main()
