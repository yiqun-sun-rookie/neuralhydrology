"""New fixed-window fitting bridge; original loss/projection helpers remain unchanged."""
import copy
import hashlib
import io
from pathlib import Path
import time
from precip_input_assimilation.scripts.run_precip_small_sample_diagnostic_v01 import (
    FAMILY, old_entry, read_json, sha256, finite_tree, state_copy, parameter_digest,
    save_tensors, training_step, trajectory_record, trajectory_proof)


def load_predecessor_initial(ctx, recipe):
    """Validate the settled direct-control baseline before any array decoding."""
    import numpy as np
    from .saved_context_v02 import guarded_existing
    root = FAMILY / recipe["stages"]["direct_control"]["output"]
    if Path(ctx.direct_control_output).absolute() != root.absolute():
        raise PermissionError("Direct-control baseline root changed")
    path = guarded_existing(root / "control/initial_predictions.npy", root)
    found = [item for item in ctx.direct_control_artifacts if Path(item["path"]).absolute() == path]
    if len(found) != 1:
        raise PermissionError("Direct-control baseline lacks one bound predecessor source")
    raw = path.read_bytes()
    if len(raw) != found[0]["bytes"] or hashlib.sha256(raw).hexdigest() != found[0]["sha256"]:
        raise PermissionError("Direct-control baseline bytes changed before array decoding")
    return np.load(io.BytesIO(raw), allow_pickle=False)

def optimize(ctx, recipe, kind):
    import numpy as np
    import torch
    from precip_input_assimilation.small_sample.support_v01 import (TableCorrector, bounds, rng_snapshot,
                                                                    snapshot, state_snapshot, frozen_modes)
    from precip_input_assimilation.dynamic_filter_multibasin.controller import network_for
    original = old_entry()
    runs = []
    lower, upper = bounds(ctx)
    seeds = [None] if kind == "direct_control" else recipe["seeds"]
    old_root = FAMILY / "pilot_20261009_01487000_s1001_s1002_s1003_v02"
    for seed in seeds:
        ctx.require_unchanged()
        directory = ctx.output / ("control" if seed is None else "seed_" + str(seed))
        directory.mkdir(exist_ok=False)
        if seed is None:
            model = TableCorrector(torch.zeros_like(lower))
            lr = recipe["control_learning_rate_mm"]
        else:
            model = network_for("rain", ctx.scaling, seed, ctx.device)
            expected = read_json(old_root / f"fits/no_penalties/seed_{seed}/fit_summary.json")
            if parameter_digest(model) != expected["initial_tensors_sha256"]:
                raise PermissionError("Network initialization differs from original paired seed")
            lr = recipe["network_learning_rate"]
        optimizer = torch.optim.Adam(model.parameters(), lr=lr, betas=(.9, .999), eps=1e-8, weight_decay=0.)
        warmup = ctx.factory(model)
        save_tensors({"dates": [d.isoformat() for d in ctx.small_phase.dates],
                    "weather": ctx.small_weather, "observations": ctx.small_values,
                    "scaling": ctx.scaling.as_dict(), "lower": lower.cpu(), "upper": upper.cpu(),
                    "warmup_dates": [d.isoformat() for d in warmup.dates], "warmup_weather": warmup.raw,
                    "warmup_applied": warmup.applied,
                    "frozen_before": state_snapshot(ctx.hydro.frozen.model), "hydro_modes": frozen_modes(ctx.hydro)},
                   directory / "bound_inputs.pt")
        del warmup
        save_tensors({"state_dict": state_copy(model), "seed": seed, "rng": rng_snapshot(),
                    "optimizer": copy.deepcopy(optimizer.state_dict()), "updates_completed": 0,
                    "snapshot": snapshot(model, optimizer)}, directory / "initial.pt")
        initial, best_loss, best_step, best_state = None, float("inf"), None, None
        achieved = False
        last_loss = None
        for k in range(recipe["max_steps"] + 1):
            ctx.require_unchanged()
            began = time.monotonic()
            torch.cuda.synchronize(ctx.device)
            trajectory, gradients = training_step(ctx, model, optimizer, diagnostics=True)
            current = float(trajectory.loss.detach())
            if initial is None:
                initial = current
                initial_predictions = np.asarray([p.q_mm_day for p in trajectory.predictions])
                np.save(directory / "initial_predictions.npy", initial_predictions)
                if seed is None:
                    baseline_network = network_for("rain", ctx.scaling, 1001, ctx.device)
                    with torch.no_grad():
                        zero_network = ctx.small_forward(baseline_network, capture=True)
                    expected_initial = np.asarray([p.q_mm_day for p in zero_network.predictions])
                    save_tensors({"trajectory": trajectory_proof(zero_network),
                                "state_dict": state_copy(baseline_network)}, directory / "zero_network_baseline.pt")
                    del baseline_network, zero_network
                else:
                    expected_initial = load_predecessor_initial(ctx, recipe)
                if (initial_predictions.dtype != expected_initial.dtype or initial_predictions.shape != expected_initial.shape
                        or not np.array_equal(initial_predictions, expected_initial)):
                    raise RuntimeError("Zero-control and zero-network initial predictions differ")
            if current < best_loss:
                best_loss, best_step, best_state = current, k, state_copy(model)
                torch.save({"state_dict": best_state, "updates_completed": best_step, "mse": best_loss}, directory / "best.pt")
            record = trajectory_record(trajectory, model, gradients)
            finite_tree(record, "diagnostic values")
            for v in record.values():
                if not np.isfinite(v).all():
                    raise RuntimeError("Nonfinite detached diagnostic value")
            np.savez_compressed(directory / f"step_{k:04d}_diagnostics.npz", **record)
            save_tensors({"state_dict": state_copy(model), "optimizer": copy.deepcopy(optimizer.state_dict()),
                        "updates_completed": k, "mse": current, "snapshot": snapshot(model, optimizer),
                        "trajectory": trajectory_proof(trajectory)}, directory / f"state_{k:04d}.pt")
            status = {"updates_completed": k, "mse": current, "best_step": best_step, "best_mse": best_loss,
                      "parameter_names": [n for n, _ in model.named_parameters()],
                      "proposal_items": int(record["proposal"].size),
                      "strictly_below": int(np.sum(record["proposal"] < -np.minimum(record["raw"],ctx.scaling.cap))),
                      "strictly_above": int(np.sum(record["proposal"] > ctx.scaling.cap)),
                      "at_lower": int(np.sum(record["proposal"] == -np.minimum(record["raw"],ctx.scaling.cap))),
                      "at_upper": int(np.sum(record["proposal"] == ctx.scaling.cap))}
            if k % recipe["checkpoint_interval"] == 0 or k == recipe["max_steps"]:
                current_state = state_copy(model)
                saved_best = torch.load(directory / "best.pt", map_location="cpu", weights_only=True)
                if saved_best["updates_completed"] != best_step or saved_best["mse"] != best_loss:
                    raise RuntimeError("Saved best checkpoint step or error differs")
                model.load_state_dict(saved_best["state_dict"], strict=True)
                with torch.no_grad():
                    replay = ctx.small_forward(model, capture=True)
                rebuilt = float(replay.loss)
                if rebuilt != best_loss:
                    raise RuntimeError("Saved best state does not strictly reproduce its fixed-parameter error")
                np.save(directory / f"best_replay_at_{k:04d}.npy", np.asarray([p.q_mm_day for p in replay.predictions]))
                # Existence of a feasible network trajectory is independently represented by its controls.
                control = torch.stack([u.applied.detach().clone() for u in replay.updates[:32]])
                with torch.no_grad():
                    imported = ctx.small_forward(TableCorrector(control), capture=True)
                a = np.asarray([p.q_mm_day for p in imported.predictions]); b = np.asarray([p.q_mm_day for p in replay.predictions])
                if a.dtype != b.dtype or a.shape != b.shape or not np.array_equal(a, b):
                    raise RuntimeError("Saved fitted trajectory is not equivalent to its direct control table")
                torch.save(control.cpu(), directory / f"best_controls_at_{k:04d}.pt")
                save_tensors({"best_state_dict": saved_best["state_dict"], "best_step": best_step, "best_mse": best_loss,
                            "trajectory": trajectory_proof(replay), "imported": trajectory_proof(imported),
                            "rng": rng_snapshot(), "current_step": k}, directory / f"best_proof_at_{k:04d}.pt")
                model.load_state_dict(current_state, strict=True)
                achieved = (initial > recipe["mse_threshold"] and rebuilt <= recipe["mse_threshold"]
                            and 1. - rebuilt / initial >= recipe["relative_reduction"])
                status["best_replay"] = {"mse": rebuilt, "achieved": achieved,
                                          "initial_already_satisfied": initial <= recipe["mse_threshold"]}
            original.write_json(directory / f"step_{k:04d}.json", status)
            last_loss = current
            torch.cuda.synchronize(ctx.device)
            print(f"stage={kind} seed={seed} step={k} mse={current:.9g} best={best_loss:.9g} seconds={time.monotonic()-began:.2f}", flush=True)
            if achieved or initial <= recipe["mse_threshold"] or k == recipe["max_steps"]:
                break
            before = state_copy(model)
            ctx.check()
            optimizer.step()
            # Preserve the first bad update before checking it; no following step is permitted.
            save_tensors({"state_dict": state_copy(model), "optimizer": copy.deepcopy(optimizer.state_dict()),
                        "updates_completed": k+1, "before_state_dict": before},
                       directory / f"update_{k+1:04d}_before_projection.pt")
            finite_tree(model.state_dict(), "parameters after update")
            finite_tree(optimizer.state_dict(), "optimizer after update")
            if seed is None:
                preprojection = model.controls.detach().clone()
                with torch.no_grad():
                    model.controls.copy_(torch.clamp(model.controls, min=lower, max=upper))
                torch.save({"before_projection": preprojection.cpu(), "after_projection": model.controls.detach().cpu(),
                            "update": k+1}, directory / f"projection_{k+1:04d}.pt")
            original.write_json(directory / f"parameter_change_{k+1:04d}.json", {
                "from_step": k, "to_step": k+1,
                "absolute_max": max(float((model.state_dict()[n].detach().cpu()-v).abs().max()) for n,v in before.items())})
            ctx.hydro.require_unchanged()
        result = {"seed": seed, "initial_mse": initial, "last_mse": last_loss, "best_mse": best_loss,
                  "best_step": best_step, "updates_completed": k, "fit_gate_pass": achieved,
                  "initial_already_satisfied": initial <= recipe["mse_threshold"],
                  "algorithm_completed": True, "output": str(directory), "forecast_efficacy_claim": False}
        save_tensors({"frozen_after": state_snapshot(ctx.hydro.frozen.model), "modes": frozen_modes(ctx.hydro)},
                   directory / "hydro_after.pt")
        original.write_json(directory / "fit_result.json", result)
        runs.append(result)
        if initial <= recipe["mse_threshold"]:
            raise RuntimeError("Initial baseline already satisfies threshold; learning diagnosis is uninformative")
    artifacts = [{"path": str(p), "sha256": sha256(p), "bytes": p.stat().st_size}
                 for p in sorted(ctx.output.rglob("*")) if p.is_file() and p.name != "manifest.json"]
    return {"fit_raw_artifacts": artifacts, "stage": kind, "execution_complete": True, "runs": runs,
            "fit_gate_pass_count": sum(r["fit_gate_pass"] for r in runs), "run_denominator": len(runs),
            "forecast_efficacy_confirmed": False}

