"""Resume one owned, read-only eight-basin raw-result transport.

Initialization is offline. Running requires an externally pinned admission
SHA256, an exclusive local owner lock, and the existing mailbox publisher.
No scientific job, model, metric, compression, or automation is executed.
"""

import argparse
import base64
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
import urllib.parse
import uuid

import eight_basin_results_transport_v01 as transport
import dynamic_filter_eight_basins_mailbox as publisher
import dynamic_filter_mailbox as mailbox_module


SCHEMA = "eight-basin-persistent-recovery-v1"
JOB_ID = 236356
MIN_FIRST_SEQUENCE = 27
HEX40 = re.compile(r"[0-9a-f]{40}\Z")
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
MAX_RECEIPT = 12 * 1024 * 1024


class IntegrityError(RuntimeError):
    pass


class ChannelOccupied(IntegrityError):
    pass


class NetworkUncertain(RuntimeError):
    pass


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def blob_identity(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def canonical(value):
    return transport.canonical(value) + b"\n"


def source_paths():
    return {"driver": Path(__file__), "transport": Path(transport.__file__),
            "publisher": Path(publisher.__file__), "mailbox": Path(mailbox_module.__file__)}


def source_hashes():
    return {key: digest(transport.no_link_ancestors(path).read_bytes()) for key, path in source_paths().items()}


def regular_bytes(path, maximum=MAX_RECEIPT):
    path = transport.no_link_ancestors(path)
    if not path.is_file() or path.stat().st_size > maximum:
        raise IntegrityError("Expected a bounded regular evidence file")
    before = transport.file_stat(path)
    raw = path.read_bytes()
    if transport.file_stat(path) != before:
        raise IntegrityError("Local evidence changed during read")
    return raw


def file_digest(path):
    path = transport.no_link_ancestors(path)
    if not path.is_file():
        raise IntegrityError("Hash anchor is not a regular file")
    before = transport.file_stat(path)
    accumulator = hashlib.sha256()
    with path.open("rb") as handle:
        for raw in iter(lambda: handle.read(transport.MAX_CHUNK), b""):
            accumulator.update(raw)
    if transport.file_stat(path) != before:
        raise IntegrityError("Hash anchor changed during verification")
    return accumulator.hexdigest()


def write_fsynced(path, raw):
    with path.open("xb") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())


def rename_without_replace(source, target):
    """Publish a complete file atomically without replacing any existing name."""
    if os.name == "nt":
        os.rename(source, target)  # Windows rename refuses an existing target.
    elif sys.platform.startswith("linux"):
        libc = ctypes.CDLL(None, use_errno=True)
        function = getattr(libc, "renameat2", None)
        if function is None:
            raise IntegrityError("Atomic exclusive rename is unavailable on this host")
        function.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
        function.restype = ctypes.c_int
        if function(-100, os.fsencode(source), -100, os.fsencode(target), 1):
            code = ctypes.get_errno()
            raise OSError(code, os.strerror(code), str(target))
        descriptor = os.open(target.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    else:
        raise IntegrityError("Only Windows and Linux have reviewed exclusive rename support")


def immutable_evidence(home, path, raw):
    """A crash may leave a temp prefix, never a prefix under final identity."""
    home, path = transport.no_link_ancestors(home), transport.no_link_ancestors(path)
    root = home.resolve(strict=True)
    if not path.resolve().is_relative_to(root):
        raise IntegrityError("Immutable evidence target escaped its owned recovery root")
    path.parent.mkdir(parents=True, exist_ok=True)
    transport.no_link_ancestors(path)
    if path.exists():
        if regular_bytes(path, transport.MAX_METADATA) != raw:
            raise FileExistsError("Existing immutable evidence differs; refusing overwrite")
        return
    temporary_root = transport.no_link_ancestors(home / "atomic_pending")
    temporary_root.mkdir(parents=True, exist_ok=True)
    temporary = transport.no_link_ancestors(temporary_root / (uuid.uuid4().hex + ".part"))
    write_fsynced(temporary, raw)
    if (not temporary.resolve(strict=True).is_relative_to(root) or not path.resolve().is_relative_to(root)):
        raise IntegrityError("Immutable evidence publication escaped its owned root")
    transport.no_link_ancestors(path)
    try:
        rename_without_replace(temporary, path)
    except FileExistsError:
        if regular_bytes(path, transport.MAX_METADATA) != raw:
            raise FileExistsError("Existing immutable evidence differs; refusing overwrite") from None


def immutable_json(home, path, value):
    immutable_evidence(home, path, canonical(value))


def require_complete_inventory(value):
    """Independently count the fixed population instead of trusting its flag."""
    if (value["job"]["job_id"] != JOB_ID or value["job"].get("state") != "COMPLETED" or
            value["job"].get("exit_code") != "0:0" or value.get("expected_file_counts_complete") is not True or
            value.get("science_verified") is not False or value.get("counts") != {
                "predictions": 88, "rain_ledgers": 48, "selected_checkpoints": 72}):
        raise IntegrityError("A completed successful fixed 88/48/72 inventory is required")
    methods = ("rain", "flow", "historical")
    names = ("base", "persistence") + tuple(f"{method}_s{seed}" for method in methods for seed in (1001, 1002, 1003))
    expected_predictions = {f"runtime/scoring/basins/{basin}/scoring/{name}/predictions.csv"
                            for basin in transport.BASINS for name in names}
    expected_ledgers = {f"runtime/scoring/basins/{basin}/scoring/{method}_s{seed}/rain_versions.csv"
                       for basin in transport.BASINS for method in ("rain", "historical") for seed in (1001, 1002, 1003)}
    expected_checkpoints = {f"runtime/training/basins/{basin}/fits/{method}/seed_{seed}/selected.pt"
                           for basin in transport.BASINS for method in methods for seed in (1001, 1002, 1003)}
    files = value["files"]
    actual_predictions = {name for name in files if name.startswith("runtime/scoring/basins/") and name.endswith("/predictions.csv")}
    actual_ledgers = {name for name in files if name.startswith("runtime/scoring/basins/") and name.endswith("/rain_versions.csv")}
    actual_checkpoints = {name for name in files if name.startswith("runtime/training/basins/") and name.endswith("/selected.pt")}
    if (actual_predictions != expected_predictions or actual_ledgers != expected_ledgers or
            actual_checkpoints != expected_checkpoints or "runtime/job_complete.json" not in files):
        raise IntegrityError("Inventory files do not contain the exact fixed 88/48/72 population and job-completion evidence")


class PublicationMailbox:
    """Recheck each genuine parent read inside the frozen publisher itself."""

    def __init__(self, mailbox, sequence, command_sha256, prior_command_sha256, prior_receipt):
        self.mailbox = mailbox
        self.sequence = sequence
        self.command_sha256 = command_sha256
        self.prior_command_sha256 = prior_command_sha256
        self.prior_receipt = prior_receipt

    def api(self, path, method="GET", body=None, missing=False):
        # Use the existing client's unchanged API; no credential is copied.
        result = self.mailbox.api(path, method=method, body=body, missing=missing)
        if method == "GET" and path == f"git/ref/heads/{mailbox_module.BRANCH}":
            head = result["object"]["sha"]
            if not HEX40.fullmatch(head):
                raise IntegrityError("Publisher read a malformed actual parent")
            last = self.mailbox.text(f"inbox/{transport.CHANNEL}/seq", head)
            command = self.mailbox.text(f"inbox/{transport.CHANNEL}/cmd.sh", head)
            if last is None or command is None or not re.fullmatch(r"[0-9]+\n?", last):
                raise ChannelOccupied("Publisher actual parent has no fixed owned command")
            expected = (self.prior_command_sha256 if int(last.strip()) == self.sequence - 1 else
                        self.command_sha256 if int(last.strip()) == self.sequence else None)
            if expected is None or digest(command.encode()) != expected:
                raise ChannelOccupied("Publisher actual parent belongs to another command")
            proof = self.prior_receipt
            name = f"outbox/{transport.CHANNEL}/result_{proof['sequence']}.txt"
            item = self.mailbox.api("contents/" + urllib.parse.quote(name, safe="/") + "?ref=" + head, missing=True)
            if (item is None or item.get("type") != "file" or item.get("sha") != proof["git_blob_sha1"] or
                    item.get("size") != proof["bytes"]):
                raise ChannelOccupied("Publisher actual parent changed the fixed previous receipt")
        return result

    def text(self, path, ref=mailbox_module.BRANCH):
        return self.mailbox.text(path, ref)


def atomic_json(path, value):
    """Only the cursor/owner are mutable; evidence itself is immutable."""
    path = transport.no_link_ancestors(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not path.is_file():
        raise IntegrityError("Mutable state target is not a regular file")
    temporary = transport.no_link_ancestors(path.parent / (path.name + ".tmp_" + uuid.uuid4().hex))
    with temporary.open("xb") as handle:
        handle.write(canonical(value))
        handle.flush()
        os.fsync(handle.fileno())
    transport.no_link_ancestors(path)
    os.replace(temporary, path)


def process_identity(pid=None):
    """Return creation identity, not PID alone, including Windows FILETIME."""
    pid = os.getpid() if pid is None else pid
    if type(pid) is not int or pid <= 0:
        raise IntegrityError("Invalid process identifier")
    if os.name == "nt":
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
        kernel.GetProcessTimes.restype = wintypes.BOOL
        kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        kernel.GetExitCodeProcess.restype = wintypes.BOOL
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.OpenProcess(0x1000, False, pid)
        if not handle:
            return None
        try:
            exit_code = wintypes.DWORD()
            if not kernel.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                raise IntegrityError("Cannot establish Windows process liveness")
            if exit_code.value != 259:
                return None
            values = [wintypes.FILETIME() for _ in range(4)]
            if not kernel.GetProcessTimes(handle, *[ctypes.byref(value) for value in values]):
                raise IntegrityError("Cannot establish Windows process creation identity")
            created = (values[0].dwHighDateTime << 32) | values[0].dwLowDateTime
            return {"pid": pid, "creation": str(created), "kind": "windows-filetime"}
        finally:
            kernel.CloseHandle(handle)
    try:
        # Field 22 remains unambiguous even when the command name contains spaces.
        fields = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
        if fields[0] == "Z":
            return None
        boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
        return {"pid": pid, "creation": fields[19], "kind": "linux-start-ticks", "boot_id": boot}
    except FileNotFoundError:
        return None


class OwnerLock:
    """OS lock prevents races during stale-owner inspection and replacement."""

    def __init__(self, home, admission_sha256):
        self.home = transport.no_link_ancestors(home)
        self.admission = admission_sha256
        self.handle = None
        self.owner = None

    def __enter__(self):
        path = transport.no_link_ancestors(self.home / "driver.lock")
        if path.exists() and not path.is_file():
            raise IntegrityError("Owner lock target is not a regular file")
        self.handle = path.open("a+b")
        self.handle.seek(0, 2)
        if not self.handle.tell():
            self.handle.write(b"0")
            self.handle.flush()
        self.handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            self.handle.close()
            self.handle = None
            raise IntegrityError("Another recovery driver owns the local lock") from error
        try:
            old = self.home / "owner.json"
            if old.exists():
                prior = transport.parse_json(regular_bytes(old))
                if prior.get("status") == "RUNNING" and process_identity(prior["process"]["pid"]) == prior["process"]:
                    raise IntegrityError("The previous process owner is still alive")
            identity = process_identity()
            if identity is None:
                raise IntegrityError("Cannot establish current process creation identity")
            self.owner = {"schema": SCHEMA, "status": "RUNNING", "process": identity,
                          "admission_sha256": self.admission, "token": uuid.uuid4().hex}
            atomic_json(self.home / "owner.json", self.owner)
            return self
        except BaseException:
            self._unlock()
            raise

    def assert_owned(self):
        if self.handle is None or self.owner is None:
            raise IntegrityError("Exclusive process ownership is required")
        if (transport.parse_json(regular_bytes(self.home / "owner.json")) != self.owner or
                process_identity() != self.owner["process"]):
            raise IntegrityError("Recovery process ownership changed")

    def _unlock(self):
        if self.handle is not None:
            if os.name == "nt":
                import msvcrt
                self.handle.seek(0)
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
            self.handle.close()
            self.handle = None

    def __exit__(self, kind, error, traceback):
        try:
            self.assert_owned()
            atomic_json(self.home / "owner.json", dict(self.owner, status="STOPPED"))
        finally:
            self._unlock()


def initialize(home, manifest, remote_python, expected_sources, first_sequence, prior_command_sha256, stop_files=()):
    if (type(first_sequence) is not int or first_sequence < MIN_FIRST_SEQUENCE or
            not HEX64.fullmatch(prior_command_sha256) or set(expected_sources) != set(source_paths())):
        raise IntegrityError("An explicit starting sequence, prior command SHA256 and all four source identities are required")
    if expected_sources != source_hashes():
        raise IntegrityError("Reviewed recovery sources changed")
    home = transport.no_link_ancestors(home)
    if home.exists() and not home.is_dir():
        raise IntegrityError("Recovery home already names a non-directory source")
    home.mkdir(parents=True, exist_ok=True)
    wrapper = transport.load_manifest(manifest)
    value, proof = wrapper["inventory"], wrapper["receipt_identity"]
    require_complete_inventory(value)
    if proof["sequence"] != first_sequence - 1:
        raise IntegrityError("A fixed complete inventory for the registered job and preceding sequence is required")
    requests = transport.requests_for(value)
    order = sorted(range(len(requests)), key=lambda index: (
        any(item["name"].endswith("/rain_versions.csv") for item in requests[index]["members"]), index))
    # Generation validates remote Python syntax without executing a remote command.
    for request in requests:
        command = transport.remote_command("fragments-remote", {"inventory": value, "request": request}, remote_python)
        immutable_evidence(home, home / "commands" / f"command_{request['index']:06d}.sh", command.encode())
    manifest_path = home / "inventory_manifest.json"
    immutable_evidence(home, manifest_path, regular_bytes(manifest, transport.MAX_METADATA))
    immutable_evidence(home, manifest_path.with_suffix(".receipt.txt"), regular_bytes(Path(manifest).with_suffix(".receipt.txt")))
    admission = {"schema": SCHEMA, "home": str(transport.display_path(home)), "job_id": JOB_ID,
                 "channel": transport.CHANNEL, "branch": mailbox_module.BRANCH, "repository": mailbox_module.REPO,
                 "manifest_sha256": digest(regular_bytes(manifest_path, transport.MAX_METADATA)),
                 "inventory_receipt": proof, "sources": expected_sources, "remote_python": remote_python,
                 "first_sequence": first_sequence, "prior_command_sha256": prior_command_sha256, "order": order,
                 "order_sha256": digest(transport.canonical(order)), "stop_files": [str(transport.display_path(
                     transport.no_link_ancestors(path))) for path in stop_files]}
    raw = canonical(admission)
    immutable_evidence(home, home / "admission.json", raw)
    admission_sha = digest(raw)
    index = {"schema": SCHEMA, "admission_sha256": admission_sha, "inventory_receipt": proof,
             "order_sha256": admission["order_sha256"], "records": [], "science_verified": False}
    index_name, index_sha = save_index(home, index)
    if not (home / "cursor.json").exists():
        state = {"schema": SCHEMA, "admission_sha256": admission_sha, "generation": 0,
                 "previous_state_sha256": None, "cursor": 0, "next_sequence": first_sequence,
                 "pending": None, "status": "READY", "receipt_index_file": index_name,
                 "receipt_index_sha256": index_sha, "order_sha256": admission["order_sha256"]}
        save_state(home, state)
    return {"admission_sha256": admission_sha, "requests": len(requests), "science_verified": False}


def save_index(home, value):
    raw = canonical(value)
    identity = digest(raw)
    name = f"indices/index_{len(value['records']):06d}_{identity}.json"
    immutable_evidence(home, home / name, raw)
    return name, identity


def save_state(home, value):
    raw = canonical(value)
    identity = digest(raw)
    name = f"state/history/{value['generation']:06d}_{identity}.json"
    immutable_evidence(home, home / name, raw)
    atomic_json(home / "cursor.json", {"state_file": name, "state_sha256": identity,
                                      "generation": value["generation"], "admission_sha256": value["admission_sha256"]})


class Driver:
    def __init__(self, home, admission_sha256, mailbox, owner, publish=publisher.publish):
        self.home = transport.no_link_ancestors(home)
        self.expected_admission = admission_sha256
        self.mailbox = mailbox
        self.owner = owner
        self.publish = publish
        raw = regular_bytes(self.home / "admission.json", transport.MAX_METADATA)
        if not HEX64.fullmatch(admission_sha256) or digest(raw) != admission_sha256:
            raise IntegrityError("Externally pinned admission SHA256 differs")
        self.admission = transport.parse_json(raw)
        if self.admission["home"] != str(transport.display_path(self.home)):
            raise IntegrityError("Admission belongs to another recovery directory")
        self.manifest = self.home / "inventory_manifest.json"
        self.wrapper = transport.load_manifest(self.manifest)
        self.inventory = self.wrapper["inventory"]
        require_complete_inventory(self.inventory)
        self.requests = transport.requests_for(self.inventory)
        self.piece_stats = {}
        self.validate_local()
        # On every process restart, independently repeat commit-to-blob membership
        # checks for the inventory and every accepted raw receipt before continuing.
        self.check_membership(self.wrapper["receipt_identity"])
        _, index = self.load_state()
        for record in index["records"]:
            self.check_membership(record)
            self.verify_accepted_pieces(record)
        state, _ = self.load_state()
        if state["status"] == "TRANSPORT_COMPLETE":
            self.validate_completion(state)
            transport.finalize(self.inventory, self.home / "pieces_store", self.home / "restored", manifest_path=self.manifest)
            self.cache_restored_stats()

    def stopped(self):
        paths = [self.home / "STOP_REQUESTED"] + [Path(path) for path in self.admission["stop_files"]]
        return any(transport.no_link_ancestors(path).exists() for path in paths)

    def command(self, index):
        path = transport.safe_path(self.home, f"commands/command_{index:06d}.sh")
        raw = regular_bytes(path, transport.MAX_METADATA)
        expected = transport.remote_command("fragments-remote", {"inventory": self.inventory,
                                            "request": self.requests[index]}, self.admission["remote_python"]).encode()
        if raw != expected:
            raise IntegrityError("Saved read-only command differs from the reviewed source/inventory")
        return raw.decode()

    def load_state(self):
        pointer = transport.parse_json(regular_bytes(self.home / "cursor.json"))
        if pointer["admission_sha256"] != self.expected_admission or type(pointer["generation"]) is not int:
            raise IntegrityError("Cursor belongs to another admission")
        identity, generation = pointer["state_sha256"], pointer["generation"]
        expected_name = f"state/history/{generation:06d}_{identity}.json"
        if pointer["state_file"] != expected_name or generation < 0 or not HEX64.fullmatch(identity):
            raise IntegrityError("Cursor state identity is malformed")
        latest, newer, checked_indices = None, None, set()
        while generation >= 0:
            raw = regular_bytes(transport.safe_path(self.home, f"state/history/{generation:06d}_{identity}.json"), transport.MAX_METADATA)
            if digest(raw) != identity:
                raise IntegrityError("Saved state history SHA256 differs")
            state = transport.parse_json(raw)
            if (state["schema"] != SCHEMA or state["admission_sha256"] != self.expected_admission or
                    state["generation"] != generation or state["order_sha256"] != self.admission["order_sha256"]):
                raise IntegrityError("State history identity differs")
            if state["receipt_index_file"] not in checked_indices:
                archived = regular_bytes(transport.safe_path(self.home, state["receipt_index_file"]), transport.MAX_METADATA)
                if digest(archived) != state["receipt_index_sha256"]:
                    raise IntegrityError("Historical receipt index SHA256 differs")
                checked_indices.add(state["receipt_index_file"])
            if newer is not None and (state["cursor"] > newer["cursor"] or newer["cursor"] - state["cursor"] > 1):
                raise IntegrityError("State history skipped or reversed a request")
            latest = state if latest is None else latest
            newer = state
            identity = state["previous_state_sha256"]
            generation -= 1
            if generation >= 0 and (not isinstance(identity, str) or not HEX64.fullmatch(identity)):
                raise IntegrityError("State history predecessor is missing")
            if generation < 0 and identity is not None:
                raise IntegrityError("Initial state must have no predecessor")
            if generation < 0 and (state["cursor"] != 0 or state["pending"] is not None or
                                   state["next_sequence"] != self.admission["first_sequence"] or state["status"] != "READY"):
                raise IntegrityError("Initial state was not the admitted empty transport cursor")
        state = latest
        cursor = state["cursor"]
        if (type(cursor) is not int or not 0 <= cursor <= len(self.requests) or
                state["next_sequence"] != self.admission["first_sequence"] + cursor):
            raise IntegrityError("Saved transport cursor/sequence is inconsistent")
        name = state["receipt_index_file"]
        raw = regular_bytes(transport.safe_path(self.home, name), transport.MAX_METADATA)
        if digest(raw) != state["receipt_index_sha256"]:
            raise IntegrityError("Saved receipt index SHA256 differs")
        index = transport.parse_json(raw)
        if (index["admission_sha256"] != self.expected_admission or index["inventory_receipt"] != self.wrapper["receipt_identity"] or
                index["order_sha256"] != self.admission["order_sha256"] or len(index["records"]) != cursor):
            raise IntegrityError("Saved receipt index differs from cursor/admission")
        for position, record in enumerate(index["records"]):
            request_index = self.admission["order"][position]
            if (record["order_position"] != position or record["request_index"] != request_index or
                    record["sequence"] != self.admission["first_sequence"] + position or
                    record["request_sha256"] != self.requests[request_index]["request_sha256"] or
                    record["command_sha256"] != digest(self.command(request_index).encode())):
                raise IntegrityError("Accepted receipt index skipped, duplicated or changed a request")
            path = transport.safe_path(self.home, record["receipt_file"])
            if digest(regular_bytes(path)) != record["receipt_sha256"]:
                raise IntegrityError("Saved original receipt SHA256 differs")
            envelope, evidence = transport.extract_receipt(path, record["sequence"], record["git_blob_sha1"], record["mailbox_commit"])
            if evidence != {key: record[key] for key in evidence} or envelope.get("index") != request_index:
                raise IntegrityError("Saved receipt identity/request differs from its index")
        pending = state["pending"]
        if pending is not None:
            if cursor == len(self.requests):
                raise IntegrityError("Completed cursor cannot contain a pending request")
            request_index = self.admission["order"][cursor]
            if (pending["order_position"] != cursor or pending["request_index"] != request_index or
                    pending["sequence"] != self.admission["first_sequence"] + cursor or
                    pending["command_sha256"] != digest(self.command(request_index).encode()) or
                    pending["phase"] not in {"PREPARED", "PUBLICATION_UNCERTAIN", "PUBLISHED"}):
                raise IntegrityError("Pending request identity differs")
        self.state_sha = pointer["state_sha256"]
        return state, index

    def validate_local(self):
        self.owner.assert_owned()
        if (regular_bytes(self.home / "admission.json", transport.MAX_METADATA) != canonical(self.admission) or
                source_hashes() != self.admission["sources"] or
                digest(regular_bytes(self.manifest, transport.MAX_METADATA)) != self.admission["manifest_sha256"] or
                transport.load_manifest(self.manifest) != self.wrapper):
            raise IntegrityError("Reviewed source, admission or original inventory evidence changed")
        order = sorted(range(len(self.requests)), key=lambda i: (any(
            item["name"].endswith("/rain_versions.csv") for item in self.requests[i]["members"]), i))
        if (self.admission["order"] != order or digest(transport.canonical(order)) != self.admission["order_sha256"] or
                self.admission["job_id"] != JOB_ID or self.admission["first_sequence"] < MIN_FIRST_SEQUENCE or
                self.admission["channel"] != transport.CHANNEL or self.admission["branch"] != mailbox_module.BRANCH or
                self.admission["repository"] != mailbox_module.REPO):
            raise IntegrityError("Fixed processing order or owned channel identity changed")
        for name, expected in self.piece_stats.items():
            try:
                actual = transport.file_stat(transport.safe_path(self.home, name))
            except (FileNotFoundError, PermissionError) as error:
                raise IntegrityError("An already accepted fragment anchor disappeared") from error
            if actual != expected["stat"] or file_digest(transport.safe_path(self.home, name)) != expected["sha256"]:
                raise IntegrityError("An already verified fragment anchor changed")
        return self.load_state()

    def verify_accepted_pieces(self, record):
        """Rehash every piece at process start; then check immutable file stats.

        The byte digests come from preserved, commit-bound raw receipts. Every
        step rehashes these anchors, including Windows same-length rewrites.
        """
        path = transport.safe_path(self.home, record["receipt_file"])
        inventory_name = "pieces_store/inventory.json"
        saved_inventory = transport.safe_path(self.home, inventory_name)
        if transport.parse_json(regular_bytes(saved_inventory, transport.MAX_METADATA)) != self.inventory:
            raise IntegrityError("Accepted piece inventory differs from original admission")
        self.cache_anchor(inventory_name)
        envelope, proof = transport.extract_receipt(path, record["sequence"], record["git_blob_sha1"], record["mailbox_commit"])
        request = self.requests[record["request_index"]]
        for key in ("root", "job_id", "index", "inventory_sha256", "request_sha256"):
            if envelope.get(key) != request[key]:
                raise IntegrityError("Accepted receipt differs from its frozen fragment request")
        if len(envelope["members"]) != len(request["members"]):
            raise IntegrityError("Accepted receipt fragment count differs")
        members = []
        for item, expected in zip(envelope["members"], request["members"], strict=True):
            if any(item[key] != expected[key] for key in ("name", "offset", "length", "stat")):
                raise IntegrityError("Accepted receipt fragment order differs")
            metadata = {key: item[key] for key in ("name", "offset", "length", "stat", "chunk_sha256")}
            members.append(metadata)
            stem = "pieces_store/pieces/" + digest(item["name"].encode()) + "/" + f"{item['offset']:016d}"
            piece = transport.safe_path(self.home, stem + ".bin")
            raw = regular_bytes(piece, transport.MAX_CHUNK)
            if len(raw) != item["length"] or digest(raw) != item["chunk_sha256"]:
                raise IntegrityError("Accepted local fragment differs from its original raw receipt")
            sidecar = transport.safe_path(self.home, stem + ".json")
            if transport.parse_json(regular_bytes(sidecar, transport.MAX_METADATA)) != metadata:
                raise IntegrityError("Accepted fragment sidecar differs from raw receipt")
            self.cache_anchor(stem + ".bin")
            self.cache_anchor(stem + ".json")
        request_name = f"pieces_store/requests/{record['request_index']:06d}.json"
        saved = transport.safe_path(self.home, request_name)
        if transport.parse_json(regular_bytes(saved, transport.MAX_METADATA)) != {"request_sha256": request["request_sha256"], "members": members}:
            raise IntegrityError("Accepted local request differs from its original raw receipt")
        self.cache_anchor(request_name)
        evidence_name = (f"pieces_store/receipts/{record['request_index']:06d}_{record['mailbox_commit']}_"
                         f"{record['sequence']}_{record['git_blob_sha1']}.json")
        evidence_path = transport.safe_path(self.home, evidence_name)
        if transport.parse_json(regular_bytes(evidence_path)) != proof:
            raise IntegrityError("Accepted local receipt proof differs")
        self.cache_anchor(evidence_name)
        blob_name = f"pieces_store/receipt_blobs/{record['git_blob_sha1']}.txt"
        blob_path = transport.safe_path(self.home, blob_name)
        if digest(regular_bytes(blob_path)) != record["receipt_sha256"]:
            raise IntegrityError("Accepted raw blob copy differs")
        self.cache_anchor(blob_name)

    def cache_anchor(self, name):
        path = transport.safe_path(self.home, name)
        self.piece_stats[name] = {"sha256": file_digest(path), "stat": transport.file_stat(path)}

    def api(self, path, missing=False):
        try:
            return self.mailbox.api(path, missing=missing)
        except (TimeoutError, ConnectionError) as error:
            raise NetworkUncertain("Temporary mailbox connection failed; fixed identities are preserved") from error
        except RuntimeError as error:
            if ("response incomplete" in str(error) or re.search(r"HTTP (429|5[0-9]{2})\b", str(error))):
                raise NetworkUncertain("Temporary mailbox read failed; fixed identities are preserved") from error
            raise

    def snapshot(self):
        head = self.api(f"git/ref/heads/{mailbox_module.BRANCH}")["object"]["sha"]
        if not HEX40.fullmatch(head):
            raise IntegrityError("Remote branch head is malformed")
        last_text = self.text(f"inbox/{transport.CHANNEL}/seq", head)
        if last_text is None or not re.fullmatch(r"[0-9]+\n?", last_text):
            raise IntegrityError("Owned remote channel sequence is malformed")
        last = int(last_text.strip())
        command = self.text(f"inbox/{transport.CHANNEL}/cmd.sh", head)
        if command is None:
            raise IntegrityError("Owned remote channel command is missing")
        return head, last, digest(command.encode())

    def text(self, path, head):
        try:
            return self.mailbox.text(path, head)
        except (TimeoutError, ConnectionError) as error:
            raise NetworkUncertain("Temporary mailbox connection failed; fixed identities are preserved") from error
        except RuntimeError as error:
            if ("response incomplete" in str(error) or re.search(r"HTTP (429|5[0-9]{2})\b", str(error))):
                raise NetworkUncertain("Temporary mailbox read failed; fixed identities are preserved") from error
            raise

    def check_membership(self, evidence):
        commit, blob, sequence = evidence["mailbox_commit"], evidence["git_blob_sha1"], evidence["sequence"]
        if not HEX40.fullmatch(commit) or not HEX40.fullmatch(blob):
            raise IntegrityError("Receipt has an invalid fixed commit/blob identity")
        name = f"outbox/{transport.CHANNEL}/result_{sequence}.txt"
        item = self.api("contents/" + urllib.parse.quote(name, safe="/") + "?ref=" + commit, missing=True)
        if (item is None or item.get("type") != "file" or item.get("sha") != blob or
                item.get("size") != evidence["bytes"]):
            raise IntegrityError("Receipt blob is not a member of its fixed genuine commit")
        return item

    def receive(self, head, sequence):
        name = f"outbox/{transport.CHANNEL}/result_{sequence}.txt"
        item = self.api("contents/" + urllib.parse.quote(name, safe="/") + "?ref=" + head, missing=True)
        if item is None:
            return None
        if (item.get("type") != "file" or not HEX40.fullmatch(item.get("sha", "")) or
                type(item.get("size")) is not int or not 0 <= item["size"] <= MAX_RECEIPT):
            raise IntegrityError("Remote receipt is not a bounded genuine Git blob")
        blob = self.api("git/blobs/" + item["sha"])
        if blob.get("sha") != item["sha"] or blob.get("encoding") != "base64":
            raise IntegrityError("Git blob API returned another receipt identity")
        raw = base64.b64decode(re.sub(r"\s", "", blob["content"]), validate=True)
        if len(raw) != item["size"] or blob_identity(raw) != item["sha"]:
            raise IntegrityError("Remote receipt Git blob bytes differ")
        local = f"receipts/result_{sequence}_{item['sha']}.txt"
        immutable_evidence(self.home, self.home / local, raw)
        envelope, evidence = transport.extract_receipt(self.home / local, sequence, item["sha"], head)
        self.check_membership(evidence)
        return envelope, evidence, local

    def commit_state(self, state, **changes):
        newer = dict(state, **changes, generation=state["generation"] + 1, previous_state_sha256=self.state_sha)
        save_state(self.home, newer)
        self.state_sha = digest(canonical(newer))
        return newer

    def prior_receipt(self, index):
        return (transport.safe_path(self.home, index["records"][-1]["receipt_file"]) if index["records"] else
                transport.no_link_ancestors(self.manifest.with_suffix(".receipt.txt")))

    def step(self):
        state, index = self.validate_local()
        if self.stopped():
            return {"status": "STOP_REQUESTED", "science_verified": False, "accepted": state["cursor"]}
        if state["status"] == "TRANSPORT_COMPLETE":
            self.validate_completion(state)
            return {"status": "TRANSPORT_COMPLETE", "science_verified": False, "accepted": state["cursor"]}
        if state["cursor"] == len(self.requests):
            return self.complete(state, index)
        pending = state["pending"]
        if pending is None:
            request_index = self.admission["order"][state["cursor"]]
            pending = {"order_position": state["cursor"], "request_index": request_index,
                       "sequence": state["next_sequence"], "command_sha256": digest(self.command(request_index).encode()),
                       "phase": "PREPARED"}
            state = self.commit_state(state, pending=pending, status="RECOVERING")
        head, last, command_sha = self.snapshot()
        sequence = pending["sequence"]
        if last not in (sequence - 1, sequence):
            raise ChannelOccupied("Owned channel moved outside the exact pending/previous sequence")
        if last == sequence:
            if command_sha != pending["command_sha256"]:
                raise ChannelOccupied("Pending sequence belongs to another command")
            if pending["phase"] != "PUBLISHED":
                pending = dict(pending, phase="PUBLISHED", publication_commit=head)
                state = self.commit_state(state, pending=pending)
        else:
            if pending["phase"] == "PUBLISHED":
                raise ChannelOccupied("Remote channel rolled back an already confirmed publication")
            expected_previous = (index["records"][-1]["command_sha256"] if index["records"] else self.admission["prior_command_sha256"])
            if command_sha != expected_previous:
                raise ChannelOccupied("Previous owned sequence now belongs to another command")
            prior = self.prior_receipt(index)
            # Confirm the previous receipt at the current fixed branch commit,
            # including its Git tree membership, before invoking the publisher.
            proof = index["records"][-1] if index["records"] else self.wrapper["receipt_identity"]
            self.check_membership(dict(proof, mailbox_commit=head))
            if self.stopped():
                return {"status": "STOP_REQUESTED", "science_verified": False, "accepted": state["cursor"]}
            pending = dict(pending, phase="PUBLICATION_UNCERTAIN")
            state = self.commit_state(state, pending=pending)
            try:
                guarded = PublicationMailbox(self.mailbox, sequence, pending["command_sha256"], expected_previous, proof)
                result = self.publish(guarded, sequence, self.command(pending["request_index"]), prior)
            except (TimeoutError, ConnectionError) as error:
                raise NetworkUncertain("Publication connection failed; inspect the same sequence and command SHA256") from error
            except RuntimeError as error:
                if ("response incomplete" in str(error) or re.search(r"HTTP (422|429|5[0-9]{2})\b", str(error))):
                    raise NetworkUncertain("Publication outcome uncertain; inspect the same sequence and command SHA256") from error
                raise
            if (result["sequence"] != sequence or result["command_sha256"] != pending["command_sha256"] or
                    not HEX40.fullmatch(result["commit"])):
                raise IntegrityError("Publisher returned another sequence/command identity")
            # A result alone is insufficient: re-observe the owned channel.
            head, last, command_sha = self.snapshot()
            if last != sequence or command_sha != pending["command_sha256"]:
                raise ChannelOccupied("Publication cannot be confirmed at the exact owned channel")
            pending = dict(pending, phase="PUBLISHED", publication_commit=result["commit"])
            state = self.commit_state(state, pending=pending)
        received = self.receive(head, sequence)
        if received is None:
            return {"status": "AWAITING_RECEIPT", "accepted": state["cursor"], "sequence": sequence, "science_verified": False}
        envelope, evidence, local = received
        request_index = pending["request_index"]
        if envelope.get("index") != request_index:
            raise IntegrityError("Pending receipt contains a different original request index")
        # Keep the unchanged validator's potentially interrupted writes in a
        # unique staging tree. Only fully validated bytes acquire final names.
        stage_name = "accepting/request_" + f"{request_index:06d}_" + uuid.uuid4().hex
        state = self.commit_state(state, pending=dict(pending, acceptance_stage=stage_name))
        stage = transport.no_link_ancestors(self.home / stage_name)
        transport.accept_fragments(self.home / local, self.inventory, stage,
                                   sequence, evidence["git_blob_sha1"], evidence["mailbox_commit"])
        for path in sorted(stage.rglob("*")):
            transport.no_link_ancestors(path)
            if path.is_file():
                relative = path.relative_to(stage).as_posix()
                source = transport.safe_path(stage, relative)
                immutable_evidence(self.home, self.home / "pieces_store" / relative,
                                   regular_bytes(source, transport.MAX_METADATA))
        record = dict(evidence, request_index=request_index, order_position=state["cursor"],
                      command_sha256=pending["command_sha256"], request_sha256=self.requests[request_index]["request_sha256"],
                      receipt_file=local, commit_tree_membership_verified=True)
        self.verify_accepted_pieces(record)
        updated_index = dict(index, records=index["records"] + [record])
        index_name, index_sha = save_index(self.home, updated_index)
        self.commit_state(state, cursor=state["cursor"] + 1, next_sequence=sequence + 1, pending=None,
                          receipt_index_file=index_name, receipt_index_sha256=index_sha)
        return {"status": "FRAGMENT_ACCEPTED", "accepted": state["cursor"] + 1,
                "total": len(self.requests), "request_index": request_index, "science_verified": False}

    def complete(self, state, index):
        restored = transport.no_link_ancestors(self.home / "restored")
        if restored.exists() and not restored.is_dir():
            raise IntegrityError("Restored result root already names a non-directory source")
        if restored.exists():
            result = transport.finalize(self.inventory, self.home / "pieces_store", restored, manifest_path=self.manifest)
        else:
            # A crash during a whole-file write must not strand a partial file
            # under its final immutable identity. Preserve each abandoned stage.
            stage_name = "finalizing/reconstruction_" + uuid.uuid4().hex
            state = self.commit_state(state, finalizing_directory=stage_name)
            stage = transport.no_link_ancestors(self.home / stage_name)
            result = transport.finalize(self.inventory, self.home / "pieces_store", stage, manifest_path=self.manifest)
            root = self.home.resolve(strict=True)
            if (not stage.resolve(strict=True).is_relative_to(root) or not restored.resolve().is_relative_to(root) or
                    restored.exists()):
                raise IntegrityError("Final reconstruction move escaped its owned recovery root or target appeared")
            os.rename(stage, restored)
        completed_job = transport.parse_json(regular_bytes(restored / "runtime/job_complete.json", transport.MAX_METADATA))
        if completed_job.get("success") is not True:
            raise IntegrityError("Recovered original job-completion evidence is not successful")
        immutable_json(self.home, self.home / "receipt_index.json", index)
        final = {"schema": SCHEMA, "status": "TRANSPORT_COMPLETE", "admission_sha256": self.expected_admission,
                 "inventory_sha256": self.inventory["inventory_sha256"], "requests": len(self.requests),
                 "receipt_index_sha256": digest(regular_bytes(self.home / "receipt_index.json", transport.MAX_METADATA)),
                 "transport_reconstruction_sha256": digest(regular_bytes(self.home / "restored/transport_reconstruction.json", transport.MAX_METADATA)),
                 "files": len(result["files"]), "science_verified": False}
        immutable_json(self.home, self.home / "transport_complete.json", final)
        self.commit_state(state, status="TRANSPORT_COMPLETE", completion_sha256=digest(canonical(final)))
        self.cache_restored_stats()
        return final

    def cache_restored_stats(self):
        for name in self.inventory["files"]:
            relative = "restored/" + name
            self.cache_anchor(relative)

    def validate_completion(self, state):
        raw = regular_bytes(self.home / "transport_complete.json", transport.MAX_METADATA)
        final = transport.parse_json(raw)
        if (digest(raw) != state["completion_sha256"] or final["science_verified"] is not False or
                final["receipt_index_sha256"] != digest(regular_bytes(self.home / "receipt_index.json", transport.MAX_METADATA)) or
                final["transport_reconstruction_sha256"] != digest(regular_bytes(
                    self.home / "restored/transport_reconstruction.json", transport.MAX_METADATA))):
            raise IntegrityError("Saved transport completion evidence changed")

    def record_error(self, error):
        # Exception class and controlled text only; never serialize mailbox/token.
        error_text = str(error)
        if len(error_text) > 2000 or "Bearer " in error_text or "password" in error_text.casefold():
            error_text = "Error details withheld to avoid credential exposure"
        name = "errors/" + time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()) + "_" + uuid.uuid4().hex + ".json"
        immutable_json(self.home, self.home / name, {"type": type(error).__name__, "message": error_text,
                             "cursor_sha256": digest(regular_bytes(self.home / "cursor.json")), "science_verified": False})


def run(home, admission_sha256, poll_seconds=45, once=False):
    if not 30 <= poll_seconds <= 60:
        raise ValueError("Mailbox polling must remain between 30 and 60 seconds")
    with OwnerLock(home, admission_sha256) as owner:
        admission_raw = regular_bytes(transport.no_link_ancestors(home) / "admission.json", transport.MAX_METADATA)
        admission = transport.parse_json(admission_raw)
        if digest(admission_raw) != admission_sha256 or source_hashes() != admission["sources"]:
            raise IntegrityError("Startup admission/source identities changed before mailbox access")
        stop_paths = [transport.no_link_ancestors(home) / "STOP_REQUESTED"] + [Path(path) for path in admission["stop_files"]]

        def bootstrap_stopped():
            return any(transport.no_link_ancestors(path).exists() for path in stop_paths)

        mailbox = None
        initialization_failures = 0
        while True:
            if bootstrap_stopped():
                return {"status": "STOP_REQUESTED", "science_verified": False}
            try:
                mailbox = mailbox_module.Mailbox() if mailbox is None else mailbox
                driver = Driver(home, admission_sha256, mailbox, owner)
                break
            except NetworkUncertain:
                initialization_failures += 1
                delay = min(60, poll_seconds * 2 ** min(initialization_failures - 1, 2))
                name = "errors/bootstrap_" + uuid.uuid4().hex + ".json"
                immutable_json(transport.no_link_ancestors(home), transport.no_link_ancestors(home) / name, {
                    "type": "NetworkUncertain", "message": "Temporary fixed-identity startup membership read failed",
                    "delay_seconds": delay, "science_verified": False})
                if once:
                    raise
                deadline = time.monotonic() + delay
                while time.monotonic() < deadline:
                    if bootstrap_stopped():
                        return {"status": "STOP_REQUESTED", "science_verified": False}
                    time.sleep(min(1, max(0, deadline - time.monotonic())))
        failures = 0
        while True:
            try:
                result = driver.step()
                failures = 0
                print(json.dumps(result), flush=True)
                if once or result["status"] in {"STOP_REQUESTED", "TRANSPORT_COMPLETE"}:
                    return result
                if result["status"] == "FRAGMENT_ACCEPTED":
                    # Confirmed progress permits preparing the next exact
                    # sequence immediately; unchanged polling still backs off.
                    continue
                delay = poll_seconds
            except NetworkUncertain as error:
                driver.record_error(error)
                failures += 1
                delay = min(60, max(30, poll_seconds) * 2 ** min(failures - 1, 2))
                print(json.dumps({"status": "NETWORK_BACKOFF", "retry_same_identity": True,
                                  "delay_seconds": delay, "science_verified": False}), flush=True)
                if once:
                    raise
            except BaseException as error:
                driver.record_error(error)
                raise
            # Local STOP polling does not issue network requests.
            deadline = time.monotonic() + delay
            while time.monotonic() < deadline:
                if driver.stopped():
                    return {"status": "STOP_REQUESTED", "science_verified": False}
                time.sleep(min(1, max(0, deadline - time.monotonic())))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="mode", required=True)
    init = subparsers.add_parser("initialize")
    init.add_argument("--home", required=True, type=Path)
    init.add_argument("--manifest", required=True, type=Path)
    init.add_argument("--python", required=True)
    init.add_argument("--first-sequence", required=True, type=int)
    init.add_argument("--prior-command-sha256", required=True)
    for name in source_paths():
        init.add_argument("--" + name + "-sha256", required=True)
    init.add_argument("--stop-file", type=Path, action="append", default=[])
    execute = subparsers.add_parser("run")
    execute.add_argument("--home", required=True, type=Path)
    execute.add_argument("--admission-sha256", required=True)
    execute.add_argument("--poll-seconds", type=int, default=45)
    execute.add_argument("--once", action="store_true")
    args = parser.parse_args()
    if args.mode == "initialize":
        result = initialize(args.home, args.manifest, args.python, {
            name: getattr(args, name + "_sha256") for name in source_paths()}, args.first_sequence,
            args.prior_command_sha256, stop_files=args.stop_file)
    else:
        result = run(args.home, args.admission_sha256, args.poll_seconds, args.once)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
