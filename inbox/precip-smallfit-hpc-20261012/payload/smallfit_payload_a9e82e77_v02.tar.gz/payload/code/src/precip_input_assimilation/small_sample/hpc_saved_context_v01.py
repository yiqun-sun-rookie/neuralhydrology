"""Relocate exact saved lawful inputs; reuse the original context and model methods."""
from datetime import date
import hashlib
import io
import json
from pathlib import Path


def create_context(root, manifest, client, output, stage):
    import numpy as np
    import torch
    from . import saved_context_v04 as original
    from . import support_v01 as support
    from ..dynamic_filter_multibasin.contract import Contract
    from ..dynamic_filter_multibasin.controller import configure_numerics, numerical_runtime
    from ..dynamic_filter.protocol import Scaling
    from ..hpc.precip_smallfit_runtime_v01 import Guard, write_json

    payload, code = Path(root) / "payload", Path(root) / "payload/code"
    guard = Guard(client)
    guard.verify_full_preservation()
    refs = manifest["saved_sources"]

    def raw(name):
        row = refs[name]
        path = payload / row["path"]
        value = path.read_bytes()
        if path.is_symlink() or len(value) != row["bytes"] or hashlib.sha256(value).hexdigest() != row["sha256"]:
            raise PermissionError("Exact saved source bytes changed before decoding: " + name)
        return value

    recorded, gate, gradient_manifest = (json.loads(raw(name)) for name in ("original_context", "input_gate", "original_manifest"))
    # Original date/provenance gate runs before any saved tensor is deserialized.
    original.require_date_provenance(gate, recorded, gradient_manifest)
    registry = json.loads(raw("source_registry"))
    for name in ("bound_inputs", "nonzero_adapter", "frozen_before"):
        identity = refs[name]["original_identity"]
        if registry["raw_artifacts"].count(identity) != 1:
            raise PermissionError("Relocated tensor lacks exact original registry membership")
    guard.verify_full_preservation()
    tensors = {name: torch.load(io.BytesIO(raw(name)), map_location="cpu", weights_only=True)
               for name in ("bound_inputs", "nonzero_adapter", "frozen_before")}
    inputs = original._decode_inputs(tensors["bound_inputs"], tensors["nonzero_adapter"])
    scale = tensors["bound_inputs"]["scaling"]
    if scale != recorded["scaling"] or scale != json.loads(raw("strict_scaling")):
        raise PermissionError("Original full normalization dictionary changed")
    scaling = Scaling(np.asarray(scale["weather_mean"], dtype=np.float32), np.asarray(scale["weather_std"], dtype=np.float32),
                      scale["flow_mean"], scale["flow_std"], scale["cap"], date.fromisoformat(scale["start"]), date.fromisoformat(scale["end"]))
    if scaling.as_dict() != scale:
        raise PermissionError("Saved scaling did not reconstruct strictly")
    configure_numerics()
    if torch.__version__.split("+")[0] != "2.2.2" or np.__version__ != "1.26.4" or torch.version.cuda != "12.1":
        raise PermissionError("Private original Torch/NumPy/CUDA versions were not reproduced")
    contract = Contract.load(code / "src/precip_input_assimilation/configs/dynamic_filter_eight_basins_v01.json")
    if contract.sha256 != gate["contract_sha256"]:
        raise PermissionError("Original fixed scientific contract bytes changed")
    hydro = original._saved_hydro(contract, gate, recorded, guard)
    if not original._equal(support.state_snapshot(hydro.frozen.model), tensors["frozen_before"]["state_dict"]):
        raise PermissionError("Original frozen tensor proof differs")
    runtime = numerical_runtime(code, "cuda:0")
    summary = json.loads(raw("pilot_result"))
    ctx = original.SavedContext(inputs, scaling, hydro, "cuda:0", Path(output), client.global_deadline, guard,
                                contract=contract, runtime=runtime, original_summary=summary,
                                original_identity=recorded["original_replay_source_identity"])
    ctx.operation_runtime, ctx.attempt_id, ctx.stage = client, manifest["run_id"], stage
    ctx.full_forward_limit, ctx.seed_scope = None, [1001]
    ctx.stage_outputs = {"direct_control": Path(root) / "runtime/direct_control", "network": Path(root) / "runtime/network"}

    def verify_saved_source_admission():
        guard.verify_full_preservation()
        original.require_date_provenance(json.loads(raw("input_gate")), json.loads(raw("original_context")), gradient_manifest)
        return {"original_registry_sha256": refs["source_registry"]["sha256"], "raw_inputs_reopened": False,
                "original_source_bytes_preserved": True, "numeric_date_gate_before_decode": True}

    ctx.verify_saved_source_admission = verify_saved_source_admission
    ctx.check()
    write_json(Path(output) / "context_identity.json", {
        "schema": "precip_hpc_saved_context_v01", "seed_scope": [1001], "runtime": runtime,
        "original_runtime": recorded["runtime"], "original_source_admission": verify_saved_source_admission(),
        "original_scaling": scale, "frozen_state_sha256": hydro.state_hash(), "raw_input_readers_called": False,
        "new_scaling_fit_called": False, "score_numeric_reads_started": False,
        "platform_migration_declared": True, "cross_platform_bitwise_equivalence_claim": False})
    return ctx
