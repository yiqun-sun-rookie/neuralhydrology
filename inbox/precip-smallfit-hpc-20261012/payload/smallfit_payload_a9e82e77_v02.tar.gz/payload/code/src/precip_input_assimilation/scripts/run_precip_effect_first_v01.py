"""Separate, validation-only paired trial of removing BOTH precipitation penalties.

Original contracts, source files, trajectories and checkpoints are read-only.
Original guarded readers remain responsible for date checks BEFORE numeric reads.
"""

import argparse
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import stat
import sys
import time
from types import SimpleNamespace


REPO = Path(__file__).resolve().parents[3]
ORIGINAL_ROOT = REPO / "results/precip_input_da_2026_09/dynamic_filter_v03/eight_basin_fixed_recipe_v01_20261003_230000_d5028d71"
CONFIG = REPO / "src/precip_input_assimilation/configs/precip_effect_first_v01.json"
EXPECTED_ARMS = {"original_penalties": {"magnitude": .0001, "violation": .01},
                 "no_penalties": {"magnitude": 0., "violation": 0.}}
WRAPPER = REPO / "src/precip_input_assimilation/hpc/eight_basin_offline_audit_numpy233_v03.py"
WRAPPER_SHA = "555b5955a1d8ac4ed55d1cba13a00f42c5131d8fe50288cd32c7aad920d48908"
SCALING_PROOF = ORIGINAL_ROOT / "monitoring_3h_v01/scaling_numpy233_20261008T233546Z_v01/result.json"
SCALING_PROOF_SHA = "2e6608d25866455df8a26bdaf096c00b8822647c74fb6779cf26d83c2d84565c"
ORIGINAL_GUARD = ORIGINAL_ROOT / "recovery_prelaunch_guard_v01.json"
ORIGINAL_GUARD_SHA = "53b0bfaad7c6cfe9600125e5d32391bd47d44be819f1ca41dd8646b316562096"


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1048576), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".partial")
    temporary.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    indent=2, allow_nan=False) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def verify_original_guard():
    if sha256(ORIGINAL_GUARD) != ORIGINAL_GUARD_SHA:
        raise PermissionError("Original 67-file preservation evidence changed")
    guard = json.loads(ORIGINAL_GUARD.read_text(encoding="utf-8"))
    roots = {"sealed_sources": REPO, "original_sources": REPO,
             "frozen_model": REPO / "results/precip_input_da_2026_09/received/seq1/pida_0b1/C4_s100"}
    expected_counts = {"sealed_sources": 42, "original_sources": 22, "frozen_model": 3}
    for group, root in roots.items():
        section = guard["checks"][group]
        if section["changed"] or len(section["hashes"]) != expected_counts[group]:
            raise PermissionError("Original preservation record is incomplete or adverse")
        for relative, identity in section["hashes"].items():
            path = root / relative
            if not path.resolve().is_relative_to(root.resolve()) or sha256(path) != identity:
                raise PermissionError(f"Original protected bytes changed: {group}/{relative}")


def validate_recipe(recipe):
    expected = {"family": "precip_effect_first_v01", "basin": "01487000",
                "seeds": [1001, 1002, 1003], "kind": "rain", "arms": EXPECTED_ARMS,
                "fit": ["1980-10-01", "1984-09-30"], "select": ["1984-10-01", "1985-09-30"],
                "score_reads_allowed": False, "learning_rate": .001, "max_epochs": 60,
                "patience": 10, "max_runtime_seconds": 21600, "previous_gpu_seconds": 86562,
                "cumulative_budget_seconds": 259200, "expansion_median_validation_gain": .005,
                "expansion_minimum_positive_pairs": 2, "automatic_expansion": False,
                "hard_projection_unchanged": True}
    if recipe != expected:
        raise PermissionError("Trial recipe differs from the registered paired pilot")
    if recipe["previous_gpu_seconds"] + recipe["max_runtime_seconds"] > recipe["cumulative_budget_seconds"]:
        raise PermissionError("Trial exceeds the original cumulative computation budget")


def segment_loss(flow_terms, magnitude, violations, magnitude_weight, violation_weight):
    """Zero coefficients SKIP auxiliary graphs, including nonfinite diagnostics."""
    import torch
    if any(not math.isfinite(w) or w < 0 for w in (magnitude_weight, violation_weight)):
        raise ValueError("Loss coefficients must be finite and nonnegative")
    terms = [torch.stack(flow_terms).mean()] if flow_terms else []
    if magnitude_weight and magnitude:
        terms.append(magnitude_weight * torch.cat([t.reshape(-1) for t in magnitude]).mean())
    if violation_weight and violations:
        terms.append(violation_weight * torch.cat([t.reshape(-1) for t in violations]).mean())
    return sum(terms) if terms else None


@contextmanager
def use_loss(module, weights):
    original = module.segment_loss

    def replacement(flow_terms, magnitude, violations, penalty):
        if penalty != weights["magnitude"]:
            raise PermissionError("Declared amplitude coefficient differs from the executed loss")
        return segment_loss(flow_terms, magnitude, violations, weights["magnitude"], weights["violation"])

    module.segment_loss = replacement
    try:
        yield
    finally:
        module.segment_loss = original


def check_output_path(output):
    output = Path(output).absolute()
    allowed = REPO / "results/precip_input_da_2026_09/effect_first_v01"
    if not output.resolve().is_relative_to(allowed.resolve()) or output.resolve() == allowed.resolve():
        raise PermissionError("Output must be a NEW child of the separate effect-first root")
    for ancestor in (output, *output.parents):
        if ancestor.exists() and (ancestor.is_symlink() or
                getattr(ancestor.lstat(), "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT):
            raise PermissionError("Output traverses a link or reparse point")
    if output.exists():
        raise FileExistsError("Never reuse a prior output directory")
    return output


@contextmanager
def exclusive_trial_lock():
    root = REPO / "results/precip_input_da_2026_09/effect_first_v01"
    root.mkdir(parents=True, exist_ok=True)
    with (root / "exclusive.lock").open("a+b") as handle:
        if handle.seek(0, 2) == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle, fcntl.LOCK_UN)


class StopAwareReplay:
    def __init__(self, replay, stop_path):
        self.replay, self.stop_path = replay, Path(stop_path)

    def __getattr__(self, name):
        return getattr(self.replay, name)

    def predict(self, *args, **kwargs):
        if self.stop_path.exists():
            raise InterruptedError("Manual stop marker preserved; trial stopped")
        return self.replay.predict(*args, **kwargs)

    def observe(self, *args, **kwargs):
        if self.stop_path.exists():
            raise InterruptedError("Manual stop marker preserved; trial stopped")
        return self.replay.observe(*args, **kwargs)


def matched_scaling(inputs, gate, output):
    if sha256(WRAPPER) != WRAPPER_SHA or sha256(SCALING_PROOF) != SCALING_PROOF_SHA:
        raise PermissionError("Reviewed isolated numerical helper or original proof changed")
    spec = importlib.util.spec_from_file_location("effect_first_reviewed_scaling", WRAPPER)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.WORK = output / "fresh_numpy233_scaling"
    helper.WORK.mkdir(exist_ok=False)
    observations = {day: float(value) for block in inputs.flow_blocks.values()
                    for day, value in zip(block.dates, block.values, strict=True)}
    series = SimpleNamespace(dates=inputs.dates, weather=inputs.weather, observations=observations,
                             score_identity={"pre_score_gate_sha256": sha256(gate)})
    result = helper.fit_scaling(series)
    proof = json.loads(SCALING_PROOF.read_text(encoding="utf-8"))
    locked = next(row["locked"] for row in proof["results"] if row["basin"] == inputs.basin)
    if result != locked:
        raise PermissionError("Fresh complete fitting scaling differs from the original strict lock")
    from precip_input_assimilation.dynamic_filter.protocol import Scaling
    import numpy as np
    return Scaling(np.asarray(result["weather_mean"], dtype=np.float32),
                   np.asarray(result["weather_std"], dtype=np.float32), result["flow_mean"],
                   result["flow_std"], result["cap"], date.fromisoformat(result["start"]),
                   date.fromisoformat(result["end"]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--probe-only", action="store_true")
    args = parser.parse_args()
    sys.dont_write_bytecode = True
    sys.path[:0] = [str(REPO), str(REPO / "src")]
    import numpy as np
    import torch
    from precip_input_assimilation.dynamic_filter import training
    from precip_input_assimilation.dynamic_filter.protocol import Phase
    from precip_input_assimilation.dynamic_filter.report import nse
    from precip_input_assimilation.dynamic_filter_multibasin.contract import Contract, DATES
    from precip_input_assimilation.dynamic_filter_multibasin.data import build_input_gate, load_inputs
    from precip_input_assimilation.dynamic_filter_multibasin.hydro import BasinHydro
    from precip_input_assimilation.dynamic_filter_multibasin.controller import (
        configure_numerics, network_for, numerical_runtime, replay_factory)
    from precip_input_assimilation.dynamic_filter_multibasin.identity import (
        multibasin_source_snapshot, require_sources)
    recipe = json.loads(CONFIG.read_text(encoding="utf-8"))
    validate_recipe(recipe)
    output = check_output_path(args.output)
    configure_numerics()
    verify_original_guard()
    config_sha, script_sha = sha256(CONFIG), sha256(__file__)
    sources = multibasin_source_snapshot(REPO)
    original_files = [ORIGINAL_ROOT / "recovery_driver_v01" / name for name in
                      ("cursor.json", "receipt_index.json", "transport_complete.json")]
    original_identity = {str(p): sha256(p) for p in original_files if p.is_file()}
    if len(original_identity) != 3:
        raise PermissionError("Completed original transport evidence is missing")
    started = time.monotonic()
    deadline = started + recipe["max_runtime_seconds"] - 300
    completed = []
    with exclusive_trial_lock():
        output.mkdir(parents=True, exist_ok=False)
        write_json(output / "config_snapshot.json", recipe)
        manifest = {"config_sha256": config_sha, "script_sha256": script_sha, "original_sources": sources,
                    "original_transport_identity": original_identity, "started_utc": datetime.now(timezone.utc).isoformat(),
                    "pid": os.getpid(), "runtime": numerical_runtime(REPO, "cuda:0"),
                    "score_numeric_reads_allowed": False, "new_hpc_jobs": 0, "probe_only": args.probe_only}
        write_json(output / "manifest.json", manifest)

        def require_unchanged():
            if sha256(CONFIG) != config_sha or sha256(__file__) != script_sha:
                raise PermissionError("Trial configuration or program changed during execution")
            require_sources(REPO, sources)
            verify_original_guard()
            if any(sha256(Path(p)) != identity for p, identity in original_identity.items()):
                raise PermissionError("Original completed transport evidence changed")
            if time.monotonic() >= deadline:
                raise TimeoutError("Trial allocation reached its inherited exit reserve")
            if (output / "STOP").exists():
                raise InterruptedError("Manual stop marker preserved")

        try:
            contract = Contract.load(REPO / "src/precip_input_assimilation/configs/dynamic_filter_eight_basins_v01.json")
            contract = contract.bind(roster_lock=ORIGINAL_ROOT / "roster_locked.json")
            inputs = load_inputs(contract, recipe["basin"], end=DATES["select"][1])
            gate = build_input_gate(contract, recipe["basin"], inputs)
            expected = json.loads((ORIGINAL_ROOT / "local_input_preflight_v01/01487000_input_gate.json").read_text(encoding="utf-8"))
            if gate != expected or gate["pass"] is not True:
                raise PermissionError("Full permitted input/static/area identity differs from original preflight")
            write_json(output / "input_gate.json", gate)
            scaling = matched_scaling(inputs, output / "input_gate.json", output)
            write_json(output / "strict_fresh_scaling.json", scaling.as_dict())
            hydro = BasinHydro(contract, recipe["basin"], device="cuda:0")
            initial_model = hydro.state_hash()
            fit, select = (Phase(name, *DATES[name]) for name in ("fit", "select"))

            def factory(network):
                require_unchanged()
                return StopAwareReplay(replay_factory(hydro, inputs, scaling, "rain", deadline=deadline)(network), output / "STOP")

            probe = Phase("fit", fit.start, fit.start + timedelta(days=63))
            probe_records = []
            for arm, weights in recipe["arms"].items():
                network = network_for("rain", scaling, 1001, "cuda:0")
                before = time.monotonic()
                with use_loss(training, weights):
                    records = training.train_epoch(factory(network), probe, inputs.weather_for(probe),
                                inputs.observations_for(probe), torch.optim.Adam(network.parameters(), lr=.001), weights["magnitude"])
                torch.cuda.synchronize()
                if not any(r["flow_supervised"] and r["nonzero_grad_parameters"] > 0 for r in records):
                    raise RuntimeError("Real probe has no nonzero supervised gradient")
                hydro.require_unchanged()
                probe_records.append({"arm": arm, "seconds": time.monotonic() - before, "segments": records})
            write_json(output / "resource_probe.json", {"real_fitting_only": True, "arms": probe_records,
                       "peak_cuda_bytes": torch.cuda.max_memory_allocated(), "score_values_read": False})
            if args.probe_only:
                write_json(output / "probe_complete.json", {"technical_only": True, "scientific_improvement_confirmed": False})
                return
            for seed in recipe["seeds"]:
                seed_initial = None
                for arm, weights in recipe["arms"].items():
                    require_unchanged()
                    directory = output / "fits" / arm / f"seed_{seed}"
                    directory.mkdir(parents=True, exist_ok=False)
                    network = network_for("rain", scaling, seed, "cuda:0")
                    initial = hashlib.sha256(b"".join(p.detach().cpu().numpy().tobytes() for p in network.parameters())).hexdigest()
                    if seed_initial is not None and initial != seed_initial:
                        raise RuntimeError("Paired initial network tensors differ")
                    seed_initial = initial
                    optimizer = torch.optim.Adam(network.parameters(), lr=recipe["learning_rate"])
                    best, best_epoch, epochs = -float("inf"), None, 0
                    with use_loss(training, weights):
                        for epoch in range(1, recipe["max_epochs"] + 1):
                            require_unchanged()
                            write_json(output / "progress.json", {"arm": arm, "seed": seed, "epoch": epoch,
                                       "completed_fits": completed, "score_values_read": False})
                            before = time.monotonic()
                            network.train()
                            segments = training.train_epoch(factory(network), fit, inputs.weather_for(fit),
                                       inputs.observations_for(fit), optimizer, weights["magnitude"])
                            if not any(r["flow_supervised"] and r["nonzero_grad_parameters"] > 0 for r in segments):
                                raise RuntimeError("Full epoch has no nonzero supervised gradient; no automatic recipe changes")
                            if any(r["loss"] is not None and not math.isfinite(r["loss"]) for r in segments):
                                raise RuntimeError("Nonfinite training loss preserved")
                            network.eval()
                            replay = factory(network)
                            training.replay_phase(replay, fit, inputs.weather_for(fit), inputs.observations_for(fit))
                            predicted = training.replay_phase(replay, select, inputs.weather_for(select), inputs.observations_for(select))
                            score = nse(inputs.observations_for(select), predicted)
                            if score is None or not math.isfinite(score):
                                raise RuntimeError("Validation efficiency is undefined")
                            better = score > best
                            if better:
                                best, best_epoch = score, epoch
                                torch.save({"state_dict": network.state_dict(), "seed": seed, "epoch": epoch,
                                            "validation_nse": score, "loss_weights": weights,
                                            "config_sha256": config_sha, "input_gate_sha256": sha256(output / "input_gate.json"),
                                            "original_input_contract_sha256": contract.sha256}, directory / "selected.pt")
                                np.save(directory / "selected_validation_predictions.npy", predicted)
                            hydro.require_unchanged()
                            torch.cuda.synchronize()
                            record = {"epoch": epoch, "validation_nse": score, "selected": better, "segments": segments,
                                      "seconds": time.monotonic() - before, "loss_weights": weights}
                            write_json(directory / f"epoch_{epoch:03d}.json", record)
                            print(f"arm={arm} seed={seed} epoch={epoch} validation_nse={score:.8f} seconds={record['seconds']:.1f}", flush=True)
                            epochs = epoch
                            if epoch - best_epoch >= recipe["patience"]:
                                break
                    require_unchanged()
                    summary = {"arm": arm, "seed": seed, "validation_nse": best, "best_epoch": best_epoch,
                               "epochs": epochs, "loss_weights": weights, "initial_tensors_sha256": initial,
                               "checkpoint_sha256": sha256(directory / "selected.pt"), "config_sha256": config_sha,
                               "frozen_model_tensor_sha256": initial_model, "score_values_read": False}
                    write_json(directory / "fit_summary.json", summary)
                    completed.append(summary)
            gains = [next(r["validation_nse"] for r in completed if r["seed"] == seed and r["arm"] == "no_penalties") -
                     next(r["validation_nse"] for r in completed if r["seed"] == seed and r["arm"] == "original_penalties")
                     for seed in recipe["seeds"]]
            median = float(np.median(gains))
            write_json(output / "pilot_result.json", {"basin": recipe["basin"], "paired_validation_gains": gains,
                       "median_paired_validation_gain": median, "fits": completed,
                       "expansion_criterion_met": median >= .005 and sum(g > 0 for g in gains) >= 2,
                       "test_period_efficacy_confirmed": False, "score_values_read": False,
                       "gpu_elapsed_seconds": time.monotonic() - started,
                       "cumulative_upper_seconds": recipe["previous_gpu_seconds"] + time.monotonic() - started})
        except Exception as error:
            import traceback
            write_json(output / "failure.json", {"error_type": type(error).__name__, "error": str(error),
                       "traceback": traceback.format_exc(), "completed_fits": completed, "score_values_read": False,
                       "elapsed_seconds": time.monotonic() - started})
            raise
        finally:
            final = {"original_sources_unchanged": multibasin_source_snapshot(REPO) == sources,
                     "original_transport_unchanged": all(sha256(Path(p)) == h for p, h in original_identity.items()),
                     "elapsed_seconds": time.monotonic() - started}
            write_json(output / "exit_evidence.json", final)


if __name__ == "__main__":
    main()
