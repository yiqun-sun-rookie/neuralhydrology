"""Retained native Windows process identities for one private numerical job."""
import ctypes
from ctypes import wintypes
import os
import time


QUERY_AND_SYNCHRONIZE = 0x1000 | 0x00100000
WAIT_OBJECT_0 = 0
WAIT_TIMEOUT = 258
STILL_ACTIVE = 259
ERROR_INVALID_PARAMETER = 87
ERROR_MORE_DATA = 234


class WindowsNumericGroup:
    """The supervisor keeps this job and all observed process handles until exit.

    A held handle identifies a process object even if its PID is later reused.
    There is deliberately no kill-on-close flag: stopping requires an explicit
    owner assertion and preserved target evidence before TerminateJobObject.
    """

    def __init__(self):
        if os.name != "nt":
            raise PermissionError("This registered execution requires Windows")
        self.kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        self.kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
        self.kernel.CreateJobObjectW.restype = wintypes.HANDLE
        self.kernel.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        self.kernel.AssignProcessToJobObject.restype = wintypes.BOOL
        self.kernel.QueryInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int,
                                                         ctypes.c_void_p, wintypes.DWORD,
                                                         ctypes.POINTER(wintypes.DWORD)]
        self.kernel.QueryInformationJobObject.restype = wintypes.BOOL
        self.kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.kernel.OpenProcess.restype = wintypes.HANDLE
        self.kernel.GetProcessId.argtypes = [wintypes.HANDLE]
        self.kernel.GetProcessId.restype = wintypes.DWORD
        self.kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
        self.kernel.GetProcessTimes.restype = wintypes.BOOL
        self.kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        self.kernel.GetExitCodeProcess.restype = wintypes.BOOL
        self.kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        self.kernel.WaitForSingleObject.restype = wintypes.DWORD
        self.kernel.IsProcessInJob.argtypes = [wintypes.HANDLE, wintypes.HANDLE, ctypes.POINTER(wintypes.BOOL)]
        self.kernel.IsProcessInJob.restype = wintypes.BOOL
        self.kernel.TerminateJobObject.argtypes = [wintypes.HANDLE, wintypes.UINT]
        self.kernel.TerminateJobObject.restype = wintypes.BOOL
        self.kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        self.kernel.CloseHandle.restype = wintypes.BOOL
        self.handle = self.kernel.CreateJobObjectW(None, None)
        if not self.handle:
            raise ctypes.WinError(ctypes.get_last_error())
        self.bound_worker = None
        self.observed = {}
        self._assigned_child = None
        self._assigned_child_handle = None
        self.last_termination = None

    def _require_open(self):
        if not self.handle:
            raise PermissionError("Native numerical job handle is closed")

    def _handle_state(self, handle):
        pid = self.kernel.GetProcessId(handle)
        if not pid:
            raise ctypes.WinError(ctypes.get_last_error())
        creation, exited, system, user = [wintypes.FILETIME() for _ in range(4)]
        if not self.kernel.GetProcessTimes(handle, *[ctypes.byref(value)
                                                   for value in (creation, exited, system, user)]):
            raise ctypes.WinError(ctypes.get_last_error())
        wait = self.kernel.WaitForSingleObject(handle, 0)
        if wait not in {WAIT_OBJECT_0, WAIT_TIMEOUT}:
            raise ctypes.WinError(ctypes.get_last_error())
        code = wintypes.DWORD()
        if not self.kernel.GetExitCodeProcess(handle, ctypes.byref(code)):
            raise ctypes.WinError(ctypes.get_last_error())
        # An exited process may itself return 259. The synchronized handle, not
        # that code alone, determines whether the exact object has exited.
        if wait == WAIT_TIMEOUT and code.value != STILL_ACTIVE:
            wait = self.kernel.WaitForSingleObject(handle, 0)
            if wait != WAIT_OBJECT_0:
                raise PermissionError("Native wait and exit-code queries disagree")
        return {"pid": int(pid), "windows_creation_identity":
                str((creation.dwHighDateTime << 32) | creation.dwLowDateTime),
                "status": "EXITED" if wait == WAIT_OBJECT_0 else "RUNNING",
                "exit_code": int(code.value), "wait_signaled": wait == WAIT_OBJECT_0}

    def _record_state(self, record):
        value = self._handle_state(record["handle"])
        if (value["pid"] != record["pid"]
                or value["windows_creation_identity"] != record["windows_creation_identity"]):
            raise PermissionError("Held native process object identity changed")
        return {**value, "native_process_handle_retained": True,
                "registered_as_job_member": True}

    def register(self, pid, creation_identity=None):
        """Hold a query-and-synchronize handle only after exact job membership.

        A failed or external PID is never adopted as an owned numerical process.
        Separate process objects with a reused PID receive separate records.
        """
        self._require_open()
        if isinstance(pid, bool) or not isinstance(pid, int) or not 0 < pid < 2**32:
            raise PermissionError("Native process registration requires a valid PID")
        handle = self.kernel.OpenProcess(QUERY_AND_SYNCHRONIZE, False, pid)
        if not handle:
            raise ctypes.WinError(ctypes.get_last_error())
        retain = False
        try:
            value = self._handle_state(handle)
            if value["pid"] != pid or (creation_identity is not None
                                       and value["windows_creation_identity"] != creation_identity):
                raise PermissionError("Native process creation identity does not match registration")
            member = wintypes.BOOL()
            if not self.kernel.IsProcessInJob(handle, self.handle, ctypes.byref(member)):
                raise ctypes.WinError(ctypes.get_last_error())
            if not member.value:
                raise PermissionError("Exact process object is outside the owned native job")
            key = (pid, value["windows_creation_identity"])
            if key not in self.observed:
                self.observed[key] = {"pid": pid, "windows_creation_identity": key[1], "handle": handle}
                retain = True
            return self._record_state(self.observed[key])
        finally:
            if not retain and not self.kernel.CloseHandle(handle):
                raise ctypes.WinError(ctypes.get_last_error())

    def assign(self, child, creation_identity):
        self._require_open()
        if self.bound_worker is not None:
            raise PermissionError("Only one numeric worker may be assigned")
        if child.poll() is not None:
            raise PermissionError("Numeric worker exited before native group binding")
        child_handle = int(child._handle)
        actual = self._handle_state(child_handle)
        if (actual["status"] != "RUNNING" or actual["pid"] != child.pid
                or actual["windows_creation_identity"] != creation_identity):
            raise PermissionError("Numeric worker native creation identity changed before assignment")
        if not self.kernel.AssignProcessToJobObject(self.handle, child_handle):
            raise ctypes.WinError(ctypes.get_last_error())
        # Retain the exact Popen binding immediately after assignment, including
        # the conservative failure path if opening its separate handle fails.
        self.bound_worker = {"pid": child.pid, "windows_creation_identity": creation_identity}
        self._assigned_child = child
        self._assigned_child_handle = child_handle
        self.register(child.pid, creation_identity)

    def pids(self):
        self._require_open()
        # Two ULONG counts, followed by pointer-sized process identifiers.
        size = 65536
        while size <= 16 * 1024 * 1024:
            buffer = ctypes.create_string_buffer(size)
            returned = wintypes.DWORD()
            if not self.kernel.QueryInformationJobObject(self.handle, 3, buffer, size, ctypes.byref(returned)):
                error = ctypes.get_last_error()
                if error == ERROR_MORE_DATA:
                    size *= 2
                    continue
                raise ctypes.WinError(error)
            assigned = wintypes.DWORD.from_buffer(buffer, 0).value
            listed = wintypes.DWORD.from_buffer(buffer, 4).value
            if assigned != listed or listed > (size - 8) // ctypes.sizeof(ctypes.c_size_t):
                size *= 2
                continue
            array = (ctypes.c_size_t * listed).from_buffer(buffer, 8)
            pids = [int(pid) for pid in array]
            if len(set(pids)) != len(pids) or any(pid <= 0 for pid in pids):
                raise PermissionError("Native numerical job process list is invalid")
            return pids
        raise PermissionError("Native numerical job process list cannot be completely queried")

    def snapshot(self):
        self._require_open()
        queried = self.pids()
        current_keys = {}
        for unused in range(16):
            for pid in queried:
                try:
                    registered = self.register(pid)
                    current_keys[pid] = (pid, registered["windows_creation_identity"])
                except PermissionError as error:
                    # A reused external PID must never become an owned target.
                    # A fresh job query must confirm it is no longer a member.
                    if "outside the owned native job" not in str(error) or pid in self.pids():
                        raise
                    current_keys.pop(pid, None)
                except OSError as error:
                    # A very short-lived member may disappear before OpenProcess.
                    # Only this specific absent-object error plus a fresh,
                    # successful job query permits continuing the observation.
                    if getattr(error, "winerror", None) != ERROR_INVALID_PARAMETER or pid in self.pids():
                        raise
                    current_keys.pop(pid, None)
            current_pids = self.pids()
            if set(current_pids) == set(queried):
                break
            queried = current_pids
        else:
            raise PermissionError("Native numerical job membership did not stabilize for proof")
        observed_by_key = {key: self._record_state(record) for key, record in sorted(self.observed.items())}
        observed = list(observed_by_key.values())
        current = []
        for pid in current_pids:
            if pid not in current_keys or current_keys[pid] not in observed_by_key:
                raise PermissionError("Current native numerical job member lacks exact held-handle proof")
            current.append(observed_by_key[current_keys[pid]])
        all_exited = all(value["status"] == "EXITED" for value in observed)
        return {"worker": self.bound_worker, "current": current, "all_observed": observed,
                "native_query_succeeded": True, "native_job_member_pids": current_pids,
                "all_observed_handles_exited": all_exited,
                "entire_group_exited": not current_pids and all_exited,
                "observation_scope": "All observed exact process objects; successful empty native job query "
                                     "proves no surviving descendant, including unobserved short-lived members"}

    def verify_exited(self, child):
        if self.bound_worker is None:
            if child is not None:
                raise PermissionError("Unassigned child cannot prove owned numerical job exit")
        else:
            if (child is not self._assigned_child or child.pid != self.bound_worker["pid"]
                    or int(child._handle) != self._assigned_child_handle):
                raise PermissionError("Numerical exit proof requires the exact assigned child object")
            exact = self._handle_state(self._assigned_child_handle)
            if (exact["pid"] != self.bound_worker["pid"]
                    or exact["windows_creation_identity"] != self.bound_worker["windows_creation_identity"]):
                raise PermissionError("Exact assigned child creation identity changed")
            if exact["status"] != "EXITED" or child.poll() is None:
                return False
        # snapshot queries the job and every retained object; failures propagate.
        return self.snapshot()["entire_group_exited"] is True

    def terminate_owned(self, assert_owner, reason):
        """Assert exact supervisor identity and its real lock, then stop this job.

        The supplied guard must verify both creation identity and actual held
        operating-system lock. The caller preserves the returned target proof
        and waits for verify_exited before settlement, close, or lock release.
        """
        if not callable(assert_owner) or not isinstance(reason, str) or not reason.strip():
            raise PermissionError("Explicit owned-job stop requires an owner guard and reason")
        assert_owner()
        before = self.snapshot()
        proof = {"reason": reason, "targets": before["current"], "before": before,
                 "private_native_job_handle": int(self.handle), "target_snapshot_monotonic": time.monotonic(),
                 "operation": "TerminateJobObject on this private native job only",
                 "owner_guard_checked": True, "termination_requested": False}
        self.last_termination = proof
        assert_owner()
        if before["native_job_member_pids"]:
            if not self.kernel.TerminateJobObject(self.handle, 1):
                proof["native_termination_error"] = ctypes.get_last_error()
                raise ctypes.WinError(proof["native_termination_error"])
            proof["termination_requested"] = True
        proof["termination_call_monotonic"] = time.monotonic()
        return proof

    def close(self):
        if not self.handle:
            return
        if not self.verify_exited(self._assigned_child):
            raise PermissionError("Cannot close native job while any exact numerical member remains alive")
        for key, record in list(self.observed.items()):
            if not self.kernel.CloseHandle(record["handle"]):
                raise ctypes.WinError(ctypes.get_last_error())
            del self.observed[key]
        if not self.kernel.CloseHandle(self.handle):
            raise ctypes.WinError(ctypes.get_last_error())
        self.handle = None
