"""One budgeted, independently checked diagnostic of already saved gradient evidence."""

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import stat
import subprocess
import sys
import time
import traceback

REPO = Path(__file__).absolute().parents[3]
FAMILY = REPO / "results/precip_input_da_2026_09/effect_first_v01"
CONFIG = REPO / "src/precip_input_assimilation/configs/precip_saved_gradient_boundaries_v01.json"
OLD_ENTRY = REPO / "src/precip_input_assimilation/scripts/run_precip_effect_first_v02.py"
OLD_SHA = "fd38ecbd0b669a23665138574237ad383171b4249cfd40e36900658520387baa"
REVIEW_ROOT = FAMILY / "saved_gradient_boundary_implementation_review_20261010_v01"
SOURCES = [Path(__file__), CONFIG,
           REPO / "src/precip_input_assimilation/small_sample/saved_boundaries_v01.py",
           REPO / "src/precip_input_assimilation/small_sample/saved_boundaries_independent_v01.py",
           REPO / "src/precip_input_assimilation/tests/test_saved_gradient_boundaries_v01.py"]


def safe_path(path, root=None, must_exist=True):
    """Check lexical containment and every ancestor before any file read/write."""
    path = Path(path)
    if not path.is_absolute() or ".." in path.parts:
        raise PermissionError("An absolute, lexical non-traversing path is required")
    if root is not None and not path.is_relative_to(Path(root)):
        raise PermissionError("Path is outside its declared root")
    for parent in reversed((path, *path.parents)):
        try:
            info = parent.lstat()
        except FileNotFoundError:
            if parent == path and must_exist:
                raise
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise PermissionError("Linked/reparse path is prohibited: " + str(parent))
    if must_exist and not path.exists():
        raise FileNotFoundError(path)
    if path.exists() and path.resolve() != path.absolute():
        raise PermissionError("Resolved path differs from lexical path")
    return path


def sha(path):
    path = safe_path(path)
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1048576), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    return json.loads(safe_path(path).read_text(encoding="utf-8"))


def write_json(path, data, output):
    path = safe_path(path, output, must_exist=False)
    if path.exists():
        raise FileExistsError(path)
    text = json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    with path.open("x", encoding="utf-8") as handle:
        handle.write(text)


def source_identity():
    return {str(p.relative_to(REPO)).replace("\\", "/"): sha(p) for p in SOURCES}


def original_entry():
    if sha(OLD_ENTRY) != OLD_SHA:
        raise PermissionError("Original reviewed budget/lock entry changed")
    spec = importlib.util.spec_from_file_location("saved_boundary_original_budget", OLD_ENTRY)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def creation_identity():
    import ctypes
    from ctypes import wintypes
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
    fields = [wintypes.FILETIME() for _ in range(4)]
    if not kernel.GetProcessTimes(kernel.GetCurrentProcess(), *(ctypes.byref(t) for t in fields)):
        raise ctypes.WinError(ctypes.get_last_error())
    return str((fields[0].dwHighDateTime << 32) | fields[0].dwLowDateTime)


def validate_config(value):
    if (value["schema"] != "precip_saved_gradient_boundaries_config_v01"
            or value["max_seconds"] != 600 or value["exit_reserve_seconds"] != 300
            or value["output"] != str(FAMILY / "saved_gradient_boundary_evidence_20261010_v01")
            or value["cap"] != 32.21650314331055
            or value["parameter_scales"] != [.0001, .001, .01]
            or value["new_model_forwards"] != 0 or value["later_stage_authorized"] is not False
            or len(value["raw_artifacts"]) != 60 or len(value["original_source_identity"]) != 12):
        raise PermissionError("Configuration differs from independently reviewed scope")
    if (value["plan_sha256"] != "4b68bb8dbd55c74ccca74f10d8c1d0b8509ebb179e6c2f866072eeca1c5e39bd"
            or sha(value["plan_path"]) != value["plan_sha256"]
            or value["plan_review_sha256"] != "944cf57e7a22ec417c2579c36b5c302904d8178e3cf40a69926ea1ae8d67d557"
            or sha(value["plan_review_path"]) != value["plan_review_sha256"]):
        raise PermissionError("Original independently reviewed plan identity changed")
    prior = read_json(value["plan_review_path"])
    if not prior["pass"] or prior["status"] != "PASS_FOR_STATIC_PLAN_ONLY":
        raise PermissionError("Plan did not receive independent review")
    gradient = read_json(value["gradient_result_path"])
    audit = read_json(value["original_failure_audit_path"])
    if gradient["artifacts"] != value["raw_artifacts"] or audit["raw_partial_artifact_identity"] != value["raw_artifacts"]:
        raise PermissionError("60-file inventory does not match both original evidence records")
    if audit["status"] != "CONFIRMED_BLOCK" or audit["pass"] is not False or audit["later_stage_authorized"] is not False:
        raise PermissionError("Original blocked outcome differs")
    return gradient


def protection_check(value, sources):
    if source_identity() != sources:
        raise PermissionError("New approved implementation bytes changed")
    for path, identity in value["protected_identity"].items():
        if sha(path) != identity:
            raise PermissionError("Protected input changed: " + path)
    for item in value["raw_artifacts"]:
        path = safe_path(item["path"], value["source_gradient_root"])
        if path.stat().st_size != item["bytes"] or sha(path) != item["sha256"]:
            raise PermissionError("Saved raw tensor identity changed")


def main():
    entry_started = time.monotonic()
    sys.dont_write_bytecode = True
    sys.path[:0] = [str(REPO), str(REPO / "src")]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--approval", required=True)
    parser.add_argument("--approval-sha256", required=True)
    args = parser.parse_args()
    approved = safe_path(args.approval, REVIEW_ROOT)
    if approved != REVIEW_ROOT / "code_review_v01.json" or sha(approved) != args.approval_sha256:
        raise PermissionError("Exact independent implementation approval is required")
    sources = source_identity()
    review = read_json(approved)
    if review["status"] != "PASS" or review["source_identity"] != sources:
        raise PermissionError("Independent review does not approve these exact source bytes")
    recipe = read_json(CONFIG)
    gradient = validate_config(recipe)
    protection_check(recipe, sources)
    original = original_entry()
    safe_path(original.ORIGINAL_GUARD, REPO)
    original.verify_original_guard()
    output = safe_path(recipe["output"], FAMILY, must_exist=False)
    if output.exists():
        raise FileExistsError("Unique output already exists; no retry/overwrite")
    safe_path(FAMILY / "cumulative_budget_v01.json", FAMILY)
    safe_path(FAMILY / "exclusive.lock", FAMILY)
    budget_partial = safe_path(FAMILY / "cumulative_budget_v01.json.partial", FAMILY, False)
    if budget_partial.exists():
        raise PermissionError("An existing budget partial file must be preserved and investigated")
    own_creation = creation_identity()
    with original.exclusive_trial_lock():
        if (FAMILY / "STOP").exists():
            raise InterruptedError("Manual family stop is present")
        _, _, allocations, settled = original.load_budget(FAMILY / "cumulative_budget_v01.json")
        if set(allocations) != set(settled):
            raise PermissionError("Another unresolved computation reservation exists")
        reservation = original.reserve_budget(FAMILY / "cumulative_budget_v01.json", output,
                                               sha(CONFIG), sha(__file__), 600)
        started = entry_started
        deadline = started + 600
        manifest = {"schema": "precip_saved_gradient_boundaries_execution_v01",
                    "started_utc": datetime.now(timezone.utc).isoformat(), "pid": os.getpid(),
                    "windows_creation_identity": own_creation, "source_identity": sources,
                    "plan_sha256": recipe["plan_sha256"], "approval_sha256": args.approval_sha256,
                    "budget_reservation_sha256": reservation["sha256"], "deadline_monotonic": deadline,
                    "new_model_forwards": 0, "original_failure_preserved": True,
                    "later_stage_authorized": False, "config_sha256": sha(CONFIG)}
        created = False
        try:
            output.mkdir(exist_ok=False)
            created = True
            write_json(output / "manifest.json", manifest, output)
            write_json(output / "budget_reservation.json", reservation, output)
            write_json(output / "config_snapshot.json", recipe, output)

            def before(label):
                if time.monotonic() >= deadline - 300:
                    raise TimeoutError("Fixed 300-second exit reserve reached: " + label)
                if (FAMILY / "STOP").exists() or (output / "STOP").exists():
                    raise InterruptedError("Manual stop is present")
                safe_path(output, FAMILY)

            before("import fixed CPU tensor runtime")
            import torch
            if platform.python_version() != "3.11.5" or torch.__version__ != "2.2.2":
                raise PermissionError("Frozen Python/PyTorch version differs")
            torch.set_num_threads(2)
            before("synthetic checks")
            command = [sys.executable, "-B", "-m", "pytest", "-q", "--noconftest", "-p", "no:cacheprovider",
                       str(SOURCES[-1]), "--basetemp=" + str(output / "synthetic_tmp"),
                       "--junitxml=" + str(output / "synthetic_tests.xml")]
            env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",
                       PYTHONPATH=str(REPO / "src") + os.pathsep + str(REPO))
            test_timeout = deadline - 300 - time.monotonic()
            if test_timeout <= 0:
                raise TimeoutError("Exit reserve reached before launching synthetic checks")
            completed = subprocess.run(command, cwd=REPO, env=env, capture_output=True, text=True,
                                       timeout=test_timeout, creationflags=0x08000000)
            for name, content in (("synthetic_stdout.log", completed.stdout), ("synthetic_stderr.log", completed.stderr)):
                target = safe_path(output / name, output, False)
                with target.open("x", encoding="utf-8") as handle:
                    handle.write(content)
            write_json(output / "synthetic_status.json", {"returncode": completed.returncode,
                "command": command, "xml_sha256": sha(output / "synthetic_tests.xml")}, output)
            if completed.returncode:
                raise RuntimeError("Registered synthetic rejection checks failed")
            raw_allowlist = {str(Path(item["path"])) for item in recipe["raw_artifacts"]}
            read_allowlist = raw_allowlist | set(recipe["auxiliary_identity"])

            def read_path_guard(path):
                path = safe_path(path, recipe["source_gradient_root"])
                if str(path) not in read_allowlist:
                    raise PermissionError("Read is outside the exact raw/auxiliary allowlist")
                return path

            config = dict(recipe, gradient_result=gradient, raw_inventory=recipe["raw_artifacts"],
                          read_path_guard=read_path_guard, expected_runtime=recipe["original_runtime"])
            protection_check(recipe, sources)
            from precip_input_assimilation.small_sample.saved_boundaries_v01 import run
            from precip_input_assimilation.small_sample.saved_boundaries_independent_v01 import audit
            before("actual saved trajectory diagnostic")
            result = run(config, output, before)
            before("independent saved trajectory reconstruction")
            independent = audit(config, output, before)
            write_json(output / "independent_boundary_audit.json", independent, output)
            if independent.get("pass") is not True:
                raise PermissionError("Independent actual boundary diagnostic did not pass")
            before("final source protection")
            protection_check(recipe, sources)
            original.verify_original_guard()
            write_json(output / "boundary_diagnostic_complete.json", {
                "status": "SAVED_BOUNDARY_DETAILS_VERIFIED", "pass": True,
                "result_sha256": sha(output / "boundary_result.json"),
                "independent_audit_sha256": sha(output / "independent_boundary_audit.json"),
                "old_gradient_pass": False, "later_stage_authorized": False,
                "new_model_forwards": 0, "directions": 6, "original_failure_preserved": True}, output)
            print(json.dumps({"output": str(output), "status": "SAVED_BOUNDARY_DETAILS_VERIFIED",
                              "elapsed_seconds": time.monotonic() - started}, ensure_ascii=False), flush=True)
        except BaseException as error:
            if created:
                write_json(output / "failure.json", {"error_type": type(error).__name__, "error": str(error),
                    "traceback": traceback.format_exc(), "elapsed_seconds": time.monotonic()-started,
                    "original_failure_preserved": True, "later_stage_authorized": False}, output)
            raise
        finally:
            unchanged = True
            protection_error = None
            try:
                protection_check(recipe, sources)
                original.verify_original_guard()
            except BaseException as error:
                unchanged = False
                protection_error = error
                if created:
                    write_json(output / "protection_failure.json", {"type": type(error).__name__, "error": str(error)}, output)
            safe_path(FAMILY / "cumulative_budget_v01.json", FAMILY)
            safe_path(budget_partial, FAMILY, False)
            if budget_partial.exists():
                raise PermissionError("Budget partial appeared; reservation remains charged")
            settlement = original.settle_budget(FAMILY / "cumulative_budget_v01.json", reservation, time.monotonic()-started)
            if created:
                write_json(output / "budget_settlement.json", settlement, output)
                write_json(output / "exit_evidence.json", {"elapsed_seconds": time.monotonic()-started,
                    "protected_identity_unchanged": unchanged, "pid": os.getpid(),
                    "windows_creation_identity": own_creation, "new_model_forwards": 0,
                    "later_stage_authorized": False, "budget": settlement}, output)
            if protection_error is not None:
                raise protection_error


if __name__ == "__main__":
    main()
