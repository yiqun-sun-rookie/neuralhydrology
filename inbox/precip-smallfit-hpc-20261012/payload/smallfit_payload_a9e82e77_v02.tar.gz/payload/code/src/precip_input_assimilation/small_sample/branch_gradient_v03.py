"""Local algebraic derivative evidence at an immutable saved parameter point.

This module does not open scientific inputs, reserve time, or run on import.
Its caller owns the family lock and time reservation and supplies the reviewed,
identity-gated saved Context.  Diagnostic continuations must never be trained
or delivered as physical precipitation predictions.
"""

from __future__ import annotations

from contextlib import contextmanager
import json
import math
from pathlib import Path
import time

import numpy as np
import torch

from ..dynamic_filter import rollout
from ..dynamic_filter.network import project_rain as ORIGINAL_PROJECT
from ..dynamic_filter.stream import ObservationStream
from . import gradient_v01 as old
from .support_v01 import TerminalCorrector, Trajectory, rng_digest, rng_snapshot, restore_rng, snapshot


SCALES = (0.0001, 0.0003, 0.001, 0.003, 0.01)
OBJECTIVES = ("terminal_output", "pure_flow_mse")
GROUPS = (("output_parameters", "decoder.2.", 33),
          ("encoder_parameters", "encoder.", 4320),
          ("middle_parameters", "decoder.0.", 1280))
RELATIVE_LIMIT = 0.05
MAX_FORWARDS = 100


class LocalDerivativeFailure(RuntimeError):
    """Raw partial evidence must remain; no subsequent fitting may start."""


def strict_equal(first, second):
    """Identity of shape, type and values, including typed saved RNG arrays."""
    if torch.is_tensor(first) or torch.is_tensor(second):
        return (torch.is_tensor(first) and torch.is_tensor(second) and first.shape == second.shape and
                first.dtype == second.dtype and torch.equal(first.detach().cpu(), second.detach().cpu()))
    if isinstance(first, np.ndarray) or isinstance(second, np.ndarray):
        return (isinstance(first, np.ndarray) and isinstance(second, np.ndarray) and
                first.shape == second.shape and first.dtype == second.dtype and
                first.tobytes(order="C") == second.tobytes(order="C"))
    if isinstance(first, dict) or isinstance(second, dict):
        return (isinstance(first, dict) and isinstance(second, dict) and list(first) == list(second) and
                all(strict_equal(first[key], second[key]) for key in first))
    if isinstance(first, (tuple, list)) or isinstance(second, (tuple, list)):
        return (type(first) is type(second) and len(first) == len(second) and
                all(strict_equal(a, b) for a, b in zip(first, second, strict=True)))
    return type(first) is type(second) and first == second


def strict_branch_codes(raw, proposal, cap):
    if raw.shape != proposal.shape or proposal.dtype != torch.float32 or not torch.isfinite(proposal).all():
        raise LocalDerivativeFailure("Malformed proposal in analytical branch evidence")
    cap = proposal.new_tensor(cap)
    lower = -torch.minimum(raw, cap)
    codes = torch.full_like(proposal, 2, dtype=torch.int8)
    codes[proposal < lower] = 0
    codes[proposal == lower] = 1
    codes[proposal == cap] = 3
    codes[proposal > cap] = 4
    return codes


def project_at_saved_branch(raw, proposal, cap, codes):
    """Select current tensor expressions, never saved intermediate values."""
    if codes.shape != proposal.shape or not bool(((codes == 0) | (codes == 2) | (codes == 4)).all()):
        raise LocalDerivativeFailure("The saved extension mask contains equality or invalid branches")
    cap_tensor = proposal.new_tensor(cap)
    lower = -torch.minimum(raw, cap_tensor)
    mask = codes.to(device=proposal.device)
    applied = torch.where(mask == 0, lower, torch.where(mask == 4, cap_tensor, proposal))
    violation = (torch.relu(lower - proposal) + torch.relu(proposal - cap_tensor)) / cap_tensor
    return raw + applied, applied, violation


@contextmanager
def fixed_branch_projector(rows):
    """Scoped replacement in the already isolated numerical process only."""
    if tuple(rows.shape) != (32, 100) or rollout.project_rain is not ORIGINAL_PROJECT:
        raise LocalDerivativeFailure("Wrong registered mask or pre-existing projector replacement")
    calls = []

    def project(raw, proposal, cap):
        index = len(calls)
        if index >= 33:
            raise LocalDerivativeFailure("The extension consumed more than 33 updates")
        calls.append(index)
        if index == 32:
            return ORIGINAL_PROJECT(raw, proposal, cap)
        return project_at_saved_branch(raw, proposal, cap, rows[index])

    rollout.project_rain = project
    try:
        yield calls
    finally:
        current = rollout.project_rain
        rollout.project_rain = ORIGINAL_PROJECT
        if current is not project:
            raise LocalDerivativeFailure("A foreign projector replaced the owned diagnostic context")


def scalar_resolution(plus, minus):
    """Pre-registered representation screen, not a model error bound."""
    for value in (plus, minus):
        if not torch.is_tensor(value) or value.shape != () or value.dtype != torch.float32:
            raise LocalDerivativeFailure("The objective scalar is not the original float32 scalar")
    a, b = float(plus.detach().cpu()), float(minus.detach().cpu())
    if not math.isfinite(a) or not math.isfinite(b):
        raise LocalDerivativeFailure("Nonfinite objective cannot enter a resolution screen")

    def ulp(value):
        item = np.float32(value)
        above = np.nextafter(item, np.float32(np.inf))
        below = np.nextafter(item, np.float32(-np.inf))
        return max(float(above) - float(item), float(item) - float(below))

    spacing = max(ulp(a), ulp(b))
    difference = abs(a - b)
    return {"plus": a, "minus": b, "unit_spacing": spacing, "difference_absolute": difference,
            "required_spacing_multiple": 32, "resolved": difference >= 32 * spacing}


def parameter_representation(base, plus, minus, direction, delta):
    """Double precision is used only to inspect stored parameter metadata."""
    if any(value.dtype != torch.float32 or value.shape != base.shape for value in (plus, minus, direction)):
        raise LocalDerivativeFailure("Parameter representation identity changed")
    base, plus, minus, direction = [item.detach().cpu().to(torch.float64)
                                   for item in (base, plus, minus, direction)]
    actual = (plus - minus) / (2 * delta)
    midpoint = (plus + minus) / 2
    direction_error = float((actual - direction).abs().max())
    midpoint_error = float((midpoint - base).abs().max())
    return {"max_direction_deviation": direction_error, "max_midpoint_deviation": midpoint_error,
            "direction_limit": 0.001, "midpoint_limit": delta * 0.001,
            "resolved": direction_error <= 0.001 and midpoint_error <= delta * 0.001,
            "actual_center_direction": actual, "actual_midpoint": midpoint}


def _same_sign(first, second):
    return first * second > 0


def _relative_close(first, second):
    denominator = max(abs(first), abs(second))
    return denominator > 0 and abs(first - second) / denominator <= RELATIVE_LIMIT


def classify_local_direction(automatic, rows, objective):
    """The first screen-qualified adjacent pair cannot be chosen by AD fit."""
    if objective not in OBJECTIVES or len(rows) != 5 or tuple(row["delta"] for row in rows) != SCALES:
        raise ValueError("Classification requires the five registered scales and a distinct objective")
    automatic = float(automatic)
    record = {"objective": objective, "automatic": automatic if math.isfinite(automatic) else None,
              "rows": rows, "reference_pair": None, "effective": False,
              "larger_scale_curvature_rows": []}
    differences = [row["finite_difference"] for row in rows]
    if not math.isfinite(automatic) or any(not math.isfinite(value) for value in differences):
        record["status"] = "NONFINITE"
        return record
    usable = [bool(row["representation_resolved"] and row["scalar_resolved"]) for row in rows]
    pair = next(([index, index + 1] for index in range(4) if usable[index] and usable[index + 1]), None)
    record["reference_pair"] = pair
    if pair is None:
        record["status"] = "NUMERICAL_UNCONFIRMED"
        return record
    left, right = pair
    a, b = differences[left], differences[right]
    record["larger_scale_curvature_rows"] = [index for index in range(right + 1, 5)
        if not _same_sign(automatic, differences[index]) or not _relative_close(automatic, differences[index])]
    if not _same_sign(a, b) or not _relative_close(a, b):
        record["status"] = "NOT_CONVERGED"
    elif any(usable[index] and (not _same_sign(automatic, differences[index]) or
                              not _relative_close(automatic, differences[index]))
             for index in range(right + 1)):
        record["status"] = "LOCAL_DERIVATIVE_INCONSISTENT"
    elif objective == "terminal_output" and min(abs(automatic), abs(a), abs(b)) < 0.001:
        record["status"] = "LOW_SENSITIVITY"
    else:
        record["status"], record["effective"] = "PASS", True
    return record


class ForwardCounter:
    """Shared with the independent auditor, including failed call starts."""
    def __init__(self, limit=MAX_FORWARDS):
        if limit != MAX_FORWARDS:
            raise ValueError("The approved complete-forward ceiling is exactly 100")
        self.limit, self.count, self.labels = limit, 0, []

    def consume(self, label):
        if self.count >= self.limit:
            raise LocalDerivativeFailure("The complete 33-day forward ceiling is exhausted")
        self.count += 1
        self.labels.append(str(label))


def _synchronize(ctx):
    if torch.device(ctx.device).type == "cuda":
        torch.cuda.synchronize(ctx.device)


def _before(ctx, label):
    _synchronize(ctx)
    ctx.require_unchanged()
    if time.monotonic() >= ctx.deadline - 300:
        raise TimeoutError(f"No new local computation in the final 300 seconds: {label}")
    ctx.check()


def _after(ctx, label):
    _synchronize(ctx)
    ctx.require_unchanged()
    if time.monotonic() >= ctx.deadline:
        raise TimeoutError(f"Local computation crossed its reservation: {label}")


class _Recorder:
    def __init__(self, output):
        self.root = Path(output) / "local_gradient_proofs"
        self.root.mkdir(exist_ok=False)
        self.artifacts, self.events = [], []

    def save(self, label, payload):
        path = self.root / f"{len(self.artifacts):03d}_{label}.pt"
        if path.exists():
            raise FileExistsError(path)
        torch.save(old._cpu(payload), path)
        item = {"path": str(path), "sha256": old._sha(path), "bytes": path.stat().st_size}
        self.artifacts.append(item)
        return item

    def event(self, label, payload):
        event = {"label": label, **payload}
        path = self.root / f"event_{len(self.events):03d}.json"
        if path.exists():
            raise FileExistsError(path)
        path.write_text(json.dumps(event, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
        self.events.append(event)


def _raw_targets(ctx, trajectory):
    return {"terminal_output": old._normalized_output(ctx, trajectory.predictions[-1]),
            "pure_flow_mse": trajectory.loss}


def _forward(ctx, network, label, rows=None):
    """Call original predict/observe; form targets before terminal projection."""
    _before(ctx, label)
    # SavedContext.factory is the single shared accounting point, also for a
    # partial/failed replay.  Explicit consume here would double-charge calls.
    ctx.forward_label = label
    adapter = TerminalCorrector(network)
    replay = ctx.factory(adapter)
    phase, values, weather = ctx.small_phase, ctx.small_values, ctx.small_weather
    source = ObservationStream(phase, values)
    predictions, updates, ledgers, terms, features = [], [], [], [], []
    terminal = {}

    def capture(module, arguments):
        features.append([item.detach().cpu().clone() for item in arguments])

    handle = network.register_forward_pre_hook(capture)
    manager = fixed_branch_projector(rows) if rows is not None else _original_projector_context()
    try:
        with manager as project_calls:
            for index, (current, row) in enumerate(zip(phase.dates, weather, strict=True)):
                ctx.check()
                prediction = replay.predict(current, row)
                observation = source.release(prediction)
                predictions.append(prediction)
                if index:
                    target = prediction.tensor.new_tensor(observation.value)
                    terms.append(((prediction.tensor - target) / ctx.scaling.flow_std).square())
                if index == 32:
                    # Do not construct either target from the terminal observer.
                    loss = torch.stack(terms).mean()
                    output = old._normalized_output(ctx, prediction)
                    terminal["ledger_before_observe"] = replay.applied.detach().clone()
                    terminal["targets_formed_before_observe"] = True
                    terminal["targets_before_observe"] = {"terminal_output": output, "pure_flow_mse": loss}
                update = replay.observe(current, observation.value)
                updates.append(update)
                if index < 32:
                    ledgers.append(replay.applied.detach().clone())
                else:
                    terminal.update({"proposal": update.proposal, "applied": update.applied,
                                     "violation": update.violation, "raw": update.raw, "cap": update.cap,
                                     "ledger_after_observe": replay.applied.detach().clone(),
                                     "terminal_new_network_call": False})
            if rows is not None and project_calls != list(range(33)):
                raise LocalDerivativeFailure("Registered projector rows were not consumed exactly once")
    except BaseException as error:
        recorder = getattr(ctx, "local_gradient_recorder", None)
        if recorder is not None:
            recorder.save("failed_forward_partial", {
                "label": label, "error_type": type(error).__name__, "error": str(error),
                "prediction_rows": [{"date": str(pred.date), "tensor": pred.tensor,
                                     "observation_cutoff": str(pred.observation_cutoff), "locked": pred.locked}
                                    for pred in predictions],
                "update_rows": [{"date": str(update.as_of_date), "raw": update.raw,
                                 "proposal": update.proposal, "applied": update.applied,
                                 "violation": update.violation} for update in updates],
                "ledgers": ledgers, "terms": terms, "features": features, "terminal": terminal,
                "replay_dates": replay.dates, "replay_raw": replay.raw, "replay_applied": replay.applied,
                "adapter_calls": adapter.calls, "observations_consumed": source.consumed})
        raise
    finally:
        handle.remove()
    if source.consumed != 33 or adapter.calls != 33 or len(features) != 32 or len(terms) != 32:
        raise LocalDerivativeFailure("Original observation/control calendar changed")
    trajectory = Trajectory(loss, tuple(predictions), tuple(updates), tuple(ledgers))
    old.require_calendar(trajectory)
    for value in (loss, output):
        if value.dtype != torch.float32 or value.shape != () or not torch.isfinite(value):
            raise LocalDerivativeFailure("Nonfinite or non-original objective representation")
    if not torch.equal(trajectory.updates[-1].proposal, terminal["ledger_before_observe"][-100:]):
        raise LocalDerivativeFailure("The terminal adapter did not return the current previous ledger")
    _, projected, violation = ORIGINAL_PROJECT(terminal["raw"], terminal["proposal"], terminal["cap"])
    if not torch.equal(projected, terminal["applied"]) or not torch.equal(violation, terminal["violation"]):
        raise LocalDerivativeFailure("Terminal behavior differs from the original physical projector")
    if not torch.equal(terminal["ledger_after_observe"][-100:], projected):
        raise LocalDerivativeFailure("Terminal original projection is not reflected in its actual ledger")
    _after(ctx, label)
    return trajectory, features, terminal


@contextmanager
def _original_projector_context():
    if rollout.project_rain is not ORIGINAL_PROJECT:
        raise LocalDerivativeFailure("Original replay is using a foreign projector")
    yield None
    if rollout.project_rain is not ORIGINAL_PROJECT:
        raise LocalDerivativeFailure("Original projector reference changed")


def _parameter_maps(network):
    pairs = list(sorted(network.named_parameters()))
    if sum(parameter.numel() for _, parameter in pairs) != 5633 or any(
            not parameter.requires_grad or parameter.dtype != torch.float32 for _, parameter in pairs):
        raise LocalDerivativeFailure("The original 5,633-parameter trainable constructor changed")
    return pairs


def _gradients(ctx, network, trajectory, terminal):
    """Save the two objectives' actual graph adjoints, not cached gradients."""
    params = _parameter_maps(network)
    proposals = [row.proposal for row in trajectory.updates[:32]]
    applied = [row.applied for row in trajectory.updates[:32]]
    codes = torch.stack([strict_branch_codes(row.raw, row.proposal, row.cap)
                         for row in trajectory.updates[:32]])
    if bool(((codes == 1) | (codes == 3)).any()):
        raise LocalDerivativeFailure("The saved base is on a projection equality boundary")
    gradients, adjoints, groups = {}, {}, {}
    for objective, target in _raw_targets(ctx, trajectory).items():
        _before(ctx, f"backward_{objective}")
        # Reproduce the exact old group-only backward request separately.
        group_gradients = {}
        if objective == "terminal_output":
            for group, prefix, _ in GROUPS[:2]:
                members = [(name, parameter) for name, parameter in params if name.startswith(prefix)]
                raw = torch.autograd.grad(target, [parameter for _, parameter in members],
                                          retain_graph=True, allow_unused=True)
                group_gradients[group] = {"names": [name for name, _ in members],
                                         "sizes": [parameter.numel() for _, parameter in members],
                                         "gradients": list(raw)}
            groups = group_gradients
        parameter_gradients = torch.autograd.grad(target, [parameter for _, parameter in params],
                                                 retain_graph=True, allow_unused=True)
        raw_adjoints = torch.autograd.grad(target, proposals + applied, retain_graph=True, allow_unused=True)
        terminal_proposal = torch.autograd.grad(target, terminal["proposal"], retain_graph=True, allow_unused=True)
        terminal_applied = torch.autograd.grad(target, terminal["applied"], retain_graph=True, allow_unused=True)
        if terminal_proposal != (None,) or terminal_applied != (None,):
            raise LocalDerivativeFailure("A terminal observer expression entered an earlier target")
        if any(value is None or not torch.isfinite(value).all()
               for value in list(parameter_gradients) + list(raw_adjoints)):
            raise LocalDerivativeFailure(f"Missing/nonfinite actual graph gradient: {objective}")
        proposal_adjoints, applied_adjoints = list(raw_adjoints[:32]), list(raw_adjoints[32:])
        mask = (codes == 2).to(proposal_adjoints[0].dtype)
        for index, (first, second) in enumerate(zip(proposal_adjoints, applied_adjoints, strict=True)):
            if not torch.equal(first, second * mask[index]):
                raise LocalDerivativeFailure(f"Actual projection adjoint differs from analytic 0/1: {objective}/{index}")
        gradients[objective] = {name: value.detach().cpu().clone()
                                for (name, _), value in zip(params, parameter_gradients, strict=True)}
        adjoints[objective] = {"proposal": proposal_adjoints, "applied": applied_adjoints,
                               "statuses": {"proposal": [_tensor_gradient_status(value) for value in proposal_adjoints],
                                            "applied": [_tensor_gradient_status(value) for value in applied_adjoints]}}
        _after(ctx, f"backward_{objective}")
    terminal["terminal_proposal_objective_grad"] = [None, None]
    terminal["terminal_applied_objective_grad"] = [None, None]
    return gradients, adjoints, groups, codes.detach().cpu()


def _tensor_gradient_status(value):
    if value is None:
        return "MISSING"
    if not torch.isfinite(value).all():
        return "NONFINITE"
    return "ZERO" if not bool((value != 0).any()) else "FINITE_NONZERO"


def _restored(network, optimizer, saved):
    from .saved_context_v03 import restore_original_snapshot
    binding = restore_original_snapshot(network, saved, optimizer)
    actual = snapshot(network, optimizer)
    if not strict_equal(actual, saved):
        raise LocalDerivativeFailure("Original complete snapshot/RNG did not restore exactly")
    if any(parameter.grad is not None for parameter in network.parameters()):
        raise LocalDerivativeFailure("New gradient state was not cleared during restoration")
    return actual, binding


def _base(ctx, network, optimizer, saved, label, recorder, rows=None):
    before, binding = _restored(network, optimizer, saved)
    try:
        trajectory, features, terminal = _forward(ctx, network, label, rows)
        gradients, adjoints, groups, codes = _gradients(ctx, network, trajectory, terminal)
        if not torch.equal(trajectory.updates[-1].applied, trajectory.updates[-1].proposal):
            raise LocalDerivativeFailure("An original/extension base failed physical terminal ledger holding")
        payload = {"snapshot_before": before, "restoration_binding": binding,
                   "requires_grad": {name: parameter.requires_grad for name, parameter in network.named_parameters()},
                   "trajectory": old._proof(trajectory), "features": features,
                   "targets": _raw_targets(ctx, trajectory), "gradients": gradients,
                   "adjoints": adjoints, "saved_group_gradients": groups, "branch_codes": codes,
                   "terminal": terminal, "parameters": {name: parameter.detach().cpu().clone()
                                                         for name, parameter in sorted(network.named_parameters())}}
    finally:
        restored, final_binding = _restored(network, optimizer, saved)
    payload["restored_snapshot"], payload["final_restoration_binding"] = restored, final_binding
    payload = old._cpu(payload)
    artifact = recorder.save(label, payload)
    return payload, artifact


def _directions(network, bundle, recorder):
    params, result = _parameter_maps(network), []
    for group, prefix, size in GROUPS:
        members = [(name, parameter) for name, parameter in params if name.startswith(prefix)]
        names, sizes = [name for name, _ in members], [parameter.numel() for _, parameter in members]
        if sum(sizes) != size:
            raise LocalDerivativeFailure("Registered parameter group changed")
        if group in bundle["saved_directions"]:
            directions = bundle["saved_directions"][group]
            generator = None
        else:
            generator = torch.Generator(device="cpu")
            generator.manual_seed(1001)
            directions = [None] * 3
        if len(directions) != 3:
            raise LocalDerivativeFailure("An original direction was dropped or added")
        for index, direction in enumerate(directions):
            before = None if generator is None else generator.get_state().clone()
            if generator is not None:
                value = torch.randn((size,), generator=generator, dtype=torch.float32)
                direction = value / value.abs().max()
            after = None if generator is None else generator.get_state().clone()
            if direction.device.type != "cpu" or direction.dtype != torch.float32 or tuple(direction.shape) != (size,):
                raise LocalDerivativeFailure("Direction raw type, dimension or host source changed")
            if not torch.isfinite(direction).all() or float(direction.abs().max()) != 1.0:
                raise LocalDerivativeFailure("Direction normalisation differs from the registered rule")
            artifact = recorder.save(f"direction_{group}_{index}", {
                "group": group, "prefix": prefix, "direction_index": index, "names": names, "sizes": sizes,
                "direction": direction, "generator_before": before, "generator_after": after,
                "original_saved_direction": generator is None, "generator_seed": None if generator is None else 1001,
                "source_identity": bundle["source_identity"]})
            result.append({"group": group, "prefix": prefix, "direction_index": index,
                           "direction": direction, "names": names, "sizes": sizes, "direction_proof": artifact})
    return result


def _parameter_endpoint(ctx, network, optimizer, saved, members, direction, delta, sign, rows, label):
    before, binding = _restored(network, optimizer, saved)
    try:
        _before(ctx, label + "_offset")
        offset = 0
        with torch.no_grad():
            for _, parameter in members:
                count = parameter.numel()
                parameter.add_(sign * delta * direction[offset:offset + count].reshape(parameter.shape))
                offset += count
        parameters = {name: parameter.detach().cpu().clone() for name, parameter in sorted(network.named_parameters())}
        if any(not torch.isfinite(parameter).all() for parameter in parameters.values()):
            raise LocalDerivativeFailure("Nonfinite perturbed parameters")
        with torch.no_grad():
            trajectory, features, terminal = _forward(ctx, network, label, rows)
        payload = {"snapshot_before": before, "restoration_binding": binding, "parameters": parameters,
                   "trajectory": old._proof(trajectory), "features": features,
                   "targets": _raw_targets(ctx, trajectory), "terminal": terminal}
    finally:
        restored, final_binding = _restored(network, optimizer, saved)
    payload["restored_snapshot"], payload["final_restoration_binding"] = restored, final_binding
    return old._cpu(payload)


def _flatten(parameters, names):
    return torch.cat([parameters[name].detach().reshape(-1) for name in names])


def run_gradient_stage(ctx, recipe=None):
    """Produce unsigned raw evidence; independent actual review is mandatory."""
    recipe = {} if recipe is None else recipe
    bundle = recipe.get("saved_sources", getattr(ctx, "saved_sources", None))
    if bundle is None or not getattr(ctx, "full_forward_counter", None):
        raise LocalDerivativeFailure("Guarded saved bundle and shared forward counter are required")
    required = {"saved_snapshot", "saved_base_trajectory", "saved_group_gradients", "saved_directions", "source_identity"}
    if not required.issubset(bundle):
        raise LocalDerivativeFailure("The gated saved-source recipe is incomplete")
    recorder, began, outer_rng = _Recorder(ctx.output), time.perf_counter(), rng_snapshot()
    ctx.local_gradient_recorder = recorder
    result = {"schema": "precip_local_branch_gradient_v02", "status": "RUNNING", "scales": list(SCALES),
              "objectives": list(OBJECTIVES), "optimizer_updates": 0, "execution_complete": False,
              "numerical_gate_pass": False, "independent_actual_review_complete": False,
              "scientific_fit_confirmed": False, "source_identity": bundle["source_identity"],
              "base_proofs": {}, "directions": [], "numerical_records": []}
    network = optimizer = None
    try:
        _before(ctx, "constructor")
        frozen_before = old._frozen_proof(ctx)
        result["frozen_before"] = recorder.save("frozen_before", frozen_before)
        network = ctx.new_network(1001)
        optimizer = torch.optim.Adam(network.parameters(), lr=0.001, betas=(0.9, 0.999), eps=1e-8, weight_decay=0.)
        saved = bundle["saved_snapshot"]
        original, artifact = _base(ctx, network, optimizer, saved, "base_original", recorder)
        result["base_proofs"]["original"] = artifact
        if not strict_equal(original["trajectory"], bundle["saved_base_trajectory"]):
            raise LocalDerivativeFailure("Fresh original trajectory differs from the immutable saved base")
        if not strict_equal(original["saved_group_gradients"], bundle["saved_group_gradients"]):
            raise LocalDerivativeFailure("Original terminal-output gradient groups did not reproduce strictly")
        codes = original["branch_codes"]
        extension, artifact = _base(ctx, network, optimizer, saved, "base_extension", recorder, codes)
        result["base_proofs"]["extension"] = artifact
        for key in ("trajectory", "features", "targets", "gradients", "adjoints", "saved_group_gradients",
                    "branch_codes", "parameters", "restored_snapshot"):
            if not strict_equal(original[key], extension[key]):
                raise LocalDerivativeFailure(f"Original/extension base is not strictly identical: {key}")
        directions = _directions(network, bundle, recorder)
        all_pairs = _parameter_maps(network)
        for item in directions:
            names, group, index = item["names"], item["group"], item["direction_index"]
            members = [(name, parameter) for name, parameter in all_pairs if name in names]
            host_direction, device_direction = item["direction"], item["direction"].to(ctx.device)
            automatic = {}
            for objective in OBJECTIVES:
                # Match the original actual-device multiplication and sum order.
                gradient = _flatten(original["gradients"][objective], names).to(ctx.device)
                automatic[objective] = float((gradient * device_direction).sum())
            record = {key: value for key, value in item.items() if key != "direction"}
            record.update({"automatic": automatic, "scales": []})
            rows_by_objective = {objective: [] for objective in OBJECTIVES}
            for delta in SCALES:
                endpoints = {}
                for sign, label in ((1., "plus"), (-1., "minus")):
                    endpoints[label] = _parameter_endpoint(ctx, network, optimizer, saved, members,
                        device_direction, delta, sign, codes, f"{group}_{index}_{delta}_{label}")
                representation = parameter_representation(_flatten(original["parameters"], names),
                    _flatten(endpoints["plus"]["parameters"], names),
                    _flatten(endpoints["minus"]["parameters"], names), host_direction, delta)
                scalar_rows = {}
                for objective in OBJECTIVES:
                    screen = scalar_resolution(endpoints["plus"]["targets"][objective],
                                               endpoints["minus"]["targets"][objective])
                    scalar_rows[objective] = screen
                    rows_by_objective[objective].append({"delta": delta,
                        "finite_difference": (screen["plus"] - screen["minus"]) / (2 * delta),
                        "representation_resolved": representation["resolved"], "scalar_resolved": screen["resolved"],
                        "plus": screen["plus"], "minus": screen["minus"],
                        "max_direction_deviation": representation["max_direction_deviation"],
                        "max_midpoint_deviation": representation["max_midpoint_deviation"],
                        "unit_spacing": screen["unit_spacing"], "difference_absolute": screen["difference_absolute"]})
                artifact = recorder.save(f"pair_{group}_{index}_{delta}", {
                    "group": group, "prefix": item["prefix"], "direction_index": index, "delta": delta,
                    "direction": host_direction, "names": names, "sizes": item["sizes"],
                    "base_parameters": original["parameters"], "base_branches": codes, "automatic": automatic,
                    "representation": representation, "scalar_resolution": scalar_rows,
                    "plus": endpoints["plus"], "minus": endpoints["minus"]})
                record["scales"].append({"delta": delta, "proof": artifact})
                for objective in OBJECTIVES:
                    rows_by_objective[objective][-1]["proof"] = artifact
            result["directions"].append(record)
            for objective in OBJECTIVES:
                decision = classify_local_direction(automatic[objective], rows_by_objective[objective], objective)
                decision.update({"group": group, "direction_index": index, "direction_proof": item["direction_proof"]})
                result["numerical_records"].append(decision)
                recorder.event("direction_classification", decision)
        _restored(network, optimizer, saved)
        ctx.require_unchanged()
        result["execution_complete"] = True
        result["numerical_gate_pass"] = len(result["numerical_records"]) == 18 and all(
            record["effective"] for record in result["numerical_records"])
        result["status"] = "PASS_UNSIGNED" if result["numerical_gate_pass"] else "BLOCKED_OR_UNCONFIRMED"
        return result
    except BaseException as error:
        result.update({"status": "FAILED_OR_UNCONFIRMED", "error_type": type(error).__name__, "error": str(error)})
        raise
    finally:
        if network is not None and optimizer is not None:
            try:
                restored, binding = _restored(network, optimizer, bundle["saved_snapshot"])
                result["final_restoration"] = recorder.save("final_restoration", {
                    "snapshot": restored, "binding": binding, "all_gradients_none": True})
            except BaseException as error:
                result["final_restoration_error"] = {"type": type(error).__name__, "error": str(error)}
                result["numerical_gate_pass"] = False
                result["execution_complete"] = False
                result["status"] = "FAILED_OR_UNCONFIRMED"
        try:
            restore_rng(outer_rng)
            rng_equal = rng_digest() == rng_digest(outer_rng)
            result["outer_rng_restoration"] = recorder.save("outer_rng_restoration", {
                "before": outer_rng, "after": rng_snapshot(), "strict_equal": rng_equal})
            if not rng_equal:
                raise LocalDerivativeFailure("The execution did not restore the caller's original random state")
        except BaseException as error:
            result["outer_rng_restoration_error"] = {"type": type(error).__name__, "error": str(error)}
            result["numerical_gate_pass"], result["execution_complete"] = False, False
            result["status"] = "FAILED_OR_UNCONFIRMED"
        frozen_after = old._frozen_proof(ctx)
        result["frozen_after"] = recorder.save("frozen_after", frozen_after)
        if "frozen_before" in locals() and not strict_equal(frozen_before, frozen_after):
            result["frozen_model_changed"] = True
            result["numerical_gate_pass"], result["execution_complete"] = False, False
            result["status"] = "FAILED_OR_UNCONFIRMED"
        result.update({"seconds": time.perf_counter() - began, "artifacts": recorder.artifacts,
                       "completed_records": recorder.events, "full_forward_count": ctx.full_forward_counter.count,
                       "full_forward_labels": list(ctx.full_forward_counter.labels), "no_later_stage_without_pass": True,
                       "projection_reference_restored": rollout.project_rain is ORIGINAL_PROJECT})
        if not result["projection_reference_restored"]:
            result["numerical_gate_pass"], result["execution_complete"] = False, False
            result["status"] = "FAILED_OR_UNCONFIRMED"
        path = Path(ctx.output) / "local_gradient_result.json"
        if path.exists():
            raise FileExistsError("Refusing to overwrite local derivative evidence")
        path.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
