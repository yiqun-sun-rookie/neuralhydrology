"""Execute the independently reviewed local derivative / small-window diagnostic once."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

REPO = Path(__file__).resolve().parents[3]
FAMILY = REPO / "results/precip_input_da_2026_09/effect_first_v01"
CONFIG = REPO / "src/precip_input_assimilation/configs/precip_local_gradient_small_sample_v03.json"
OWNER = FAMILY / "local_gradient_owner_v03.json"
PLAN_SHA = "f9c4ca87a21982a9b88d74e5e5645356492632684b88c705069748b9f0f03a83"
REVIEW_SHA = "4ccd85651c3b032158d6bf4c1c022e87abbe49ff1fb70a6a6fd97001c29361f0"
BOUND_SHA = "4165be37e56dfd8938d5c2bd0ea0493a00a7dfa194bd1dfe5563ae689ce2ac6f"


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def original_entry():
    # This module imports only the standard library before a charged stage begins.
    from precip_input_assimilation.scripts.run_precip_small_sample_diagnostic_v01 import old_entry
    return old_entry()


def config():
    v = read_json(CONFIG)
    if (v["plan_sha256"] != PLAN_SHA or sha256(REPO / v["plan"]) != PLAN_SHA
            or v["plan_review_sha256"] != REVIEW_SHA or sha256(REPO / v["plan_review"]) != REVIEW_SHA
            or read_json(REPO / v["plan_review"])["status"] != "PASS"
            or v["boundary_evidence_config_sha256"] != BOUND_SHA
            or sha256(REPO / v["boundary_evidence_config"]) != BOUND_SHA):
        raise PermissionError("Approved plan / original evidence binding changed")
    required = {"basin": "01487000", "seeds": [1001, 1002, 1003], "target_start": "1980-10-02",
                "target_end": "1980-11-02", "max_steps": 1000, "checkpoint_interval": 10,
                "mse_threshold": .0001, "relative_reduction": .99, "network_learning_rate": .001,
                "control_learning_rate_mm": .1, "soft_penalties": {"magnitude": 0., "violation": 0.},
                "soft_penalties_graph": "absent", "score_numeric_reads_allowed": False, "new_remote_jobs": 0,
                "exit_reserve_seconds": 300, "parameter_scales": [.0001, .0003, .001, .003, .01],
                "max_full_forwards": 100, "gradient_relative_error": .05,
                "minimum_terminal_direction_response": .001, "parameter_direction_error_limit": .001,
                "parameter_midpoint_error_per_scale_limit": .001, "scalar_minimum_ulp_multiple": 32}
    for key, expected in required.items():
        if v.get(key) != expected:
            raise PermissionError("Unregistered recipe field: " + key)
    stages = {"gradient": {"seconds": 1187, "output": "local_branch_gradient_20261011_v03", "previous": None},
              "direct_control": {"seconds": 3600, "output": "small_sample_direct_control_20261010_v02", "previous": "gradient"},
              "network": {"seconds": 5400, "output": "small_sample_network_20261010_v02", "previous": "direct_control"}}
    if v["stages"] != stages:
        raise PermissionError("Stage order / output / budget changed")
    repair = {"path": "draft/2026-10-11-precip-local-gradient-device-repair-admission-v0.1.md",
              "sha256": "7b1087b8ac9b3fbef6aff597d37bd35e5b414501cd8b61ccafdc02376680f91c",
              "failure_binding_path": "results/precip_input_da_2026_09/effect_first_v01/local_gradient_device_repair_review_20261011_v03/failure_preservation_binding_v03.json",
              "failure_binding_sha256": "f665266cea88624eb3eb5086d08c2fd78a3c0e602866a27e25c9d6301e207576",
              "previous_charged_seconds": 13, "previous_full_forwards": 0,
              "total_gradient_seconds": 1200,
              "explicit_second_reservation_acknowledgement_required": True,
              "automatic_retry_allowed": False}
    if v.get("repair_protocol") != repair or sha256(REPO / repair["path"]) != repair["sha256"]:
        raise PermissionError("Unregistered technical repair protocol")
    return v


def source_identity():
    files = [Path(__file__), CONFIG,
             REPO / "src/precip_input_assimilation/scripts/run_precip_small_sample_diagnostic_v01.py",
             REPO / "src/precip_input_assimilation/scripts/run_precip_effect_first_v02.py",
             *sorted((REPO / "src/precip_input_assimilation/small_sample").glob("*.py")),
             *sorted((REPO / "src/precip_input_assimilation/tests").glob("test_local*_v02.py")),
             *sorted((REPO / "src/precip_input_assimilation/tests").glob("test_local*_v03.py")),
             REPO / "draft/2026-10-11-precip-local-gradient-device-repair-admission-v0.1.md",
             REPO / "results/precip_input_da_2026_09/effect_first_v01/local_gradient_device_repair_review_20261011_v03/failure_preservation_binding_v03.json",
             *sorted((REPO / "src/precip_input_assimilation/tests").glob("test_small_sample*_v01.py"))]
    return {p.relative_to(REPO).as_posix(): sha256(p) for p in files}


def require_approval(path, identity, sources, stage):
    if sha256(path) != identity:
        raise PermissionError("Independent code review bytes changed")
    a = read_json(path)
    if (a.get("status") != "PASS_STATIC_REQUIRE_REGISTERED_TESTS" or a.get("source_identity") != sources
            or stage not in a.get("stage_scope", [])
            or a.get("registered_tests_before_scientific_model") is not True
            or a.get("repair_protocol_static_pass") is not True
            or a.get("requires_explicit_repair_authorization") is not True):
        raise PermissionError("Exact new implementation lacks independent code approval")
    return a


def protected_identity(recipe):
    b = read_json(REPO / recipe["boundary_evidence_config"])
    if len(b["protected_identity"]) != 410 or len(b["raw_artifacts"]) != 60:
        raise PermissionError("Original preservation coverage changed")
    return b["protected_identity"]


def verify_protected(identity):
    from precip_input_assimilation.small_sample.saved_boundaries_v01 import safe_path
    for name, expected in identity.items():
        path = safe_path(name, REPO)
        if sha256(path) != expected:
            raise PermissionError("Original protected bytes changed: " + str(path))


def require_actual_audit(output, stage, audit):
    if audit.get("status") != "PASS" or audit.get("pass") is not True:
        raise PermissionError("Independent actual verification did not pass")
    path = Path(audit["report_path"])
    if (not path.resolve().is_relative_to(output.resolve()) or path.is_symlink()
            or sha256(path) != audit["sha256"]):
        raise PermissionError("Independent actual report identity changed")
    actual = read_json(path)
    if actual.get("status") != "PASS" or actual.get("pass") is not True or actual.get("stage") != stage:
        raise PermissionError("Independent underlying actual report did not pass")
    return actual


def require_predecessor(recipe, stage):
    previous = recipe["stages"][stage]["previous"]
    if previous is None:
        root = FAMILY / "small_sample_weight_replay_20261010_v01"
        if sha256(root / "actual_weight_replay_audit.json") != "eef44a4da0ef8c85260fe6b66de2f9312055da40ab797e9e77e49d6c5ab0c40a":
            raise PermissionError("Original weight / nine input-direction acceptance changed")
        previous = "weight_replay"
    else:
        root = FAMILY / recipe["stages"][previous]["output"]
    r, a, f = [read_json(root / n) for n in ("stage_result.json", "independent_actual_audit.json", "stage_complete.json")]
    if ((root / "failure.json").exists() or r.get("execution_complete") is not True or f.get("pass") is not True
            or f.get("stage") != previous or f["stage_result_sha256"] != sha256(root / "stage_result.json")
            or f["audit_sha256"] != sha256(root / "independent_actual_audit.json")
            or not (root / "budget_settlement.json").exists()):
        raise PermissionError("Previous actual stage incomplete or failed")
    require_actual_audit(root, previous, a)
    if f.get("actual_audit_sha256") != a["sha256"]:
        raise PermissionError("Previous actual report binding changed")
    settlement = read_json(root / "budget_settlement.json")
    if settlement.get("allocation_overrun") is not False:
        raise PermissionError("Previous stage exceeded its allocation")
    if previous != "weight_replay":
        exited = read_json(root / "exit_evidence.json")
        if (exited.get("source_identity_unchanged") is not True or exited.get("transport_unchanged") is not True
                or exited.get("protected_identity_verified") is not True or exited.get("completed") is not True):
            raise PermissionError("Previous stage did not leave a fully verified exit")
    if previous == "gradient" and r.get("numerical_gate_pass") is not True:
        raise PermissionError("Local derivative gate unconfirmed or failed; fitting prohibited")
    return {"stage": previous, "complete_path": str(root / "stage_complete.json"),
            "sha256": sha256(root / "stage_complete.json")}


def process_identity(pid):
    """Native query; query failures are not evidence that an owner exited."""
    import ctypes
    from ctypes import wintypes
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenProcess.restype = wintypes.HANDLE
    handle = kernel.OpenProcess(0x1000, False, pid)
    if not handle:
        error = ctypes.get_last_error()
        if error == 87:
            return {"status": "ABSENT", "windows_error": error}
        raise OSError(error, "Native owner query failed; exit remains unconfirmed")
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    try:
        creation, exited, system, user = [wintypes.FILETIME() for _ in range(4)]
        kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
        if not kernel.GetProcessTimes(handle, *[ctypes.byref(x) for x in (creation, exited, system, user)]):
            raise ctypes.WinError(ctypes.get_last_error())
        code = wintypes.DWORD()
        kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        if not kernel.GetExitCodeProcess(handle, ctypes.byref(code)):
            raise ctypes.WinError(ctypes.get_last_error())
        return {"status": "RUNNING" if code.value == 259 else "EXITED", "exit_code": code.value,
                "creation_identity": str((creation.dwHighDateTime << 32) | creation.dwLowDateTime)}
    finally:
        kernel.CloseHandle(handle)


def require_no_prior_owner():
    if OWNER.exists():
        old = read_json(OWNER)
        if old.get("status") == "RUNNING":
            query = process_identity(old["pid"])
            if query["status"] == "RUNNING":
                # A recycled process is never stopped; both cases block automatic concurrency.
                raise PermissionError("Prior owner PID is still active or recycled: " + str(query))
            return query
    return {"status": "NO_UNSETTLED_OWNER"}



def verify_failure_binding(recipe, *, query_owner=False):
    """Hash old bytes only; no failed proof is deserialized or used as success."""
    import stat
    repair = recipe["repair_protocol"]
    p = REPO / repair["failure_binding_path"]
    if sha256(p) != repair["failure_binding_sha256"]:
        raise PermissionError("Original technical failure binding changed")
    binding = read_json(p)
    root = REPO / binding["old_output"]
    for name, expected_source in binding["failed_source_identity"].items():
        if sha256(REPO / name) != expected_source:
            raise PermissionError("Original failed implementation bytes changed")
    expected = set()
    for row in binding["original_files"] + [binding["old_owner"]]:
        q = REPO / row["path"]
        if ".." in q.parts or not q.is_relative_to(REPO):
            raise PermissionError("Original failure path escaped")
        for parent in (q, *q.parents):
            info = parent.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
                raise PermissionError("Original failure path redirected")
        if q.stat().st_size != row["bytes"] or sha256(q) != row["sha256"]:
            raise PermissionError("Original technical failure bytes changed")
        if q.is_relative_to(root):
            expected.add(q.relative_to(root).as_posix())
    if {q.relative_to(root).as_posix() for q in root.rglob("*") if q.is_file()} != expected:
        raise PermissionError("Original failed output inventory changed")
    exited = read_json(root / "exit_evidence.json")
    settlement = read_json(root / "budget_settlement.json")
    if (binding["charged_seconds"] != 13 or binding["full_forward_count"] != 0
            or exited["full_forward_count"] != 0 or exited["completed"] is not False
            or exited["source_identity_unchanged"] is not True
            or exited["protected_identity_verified"] is not True
            or exited["transport_unchanged"] is not True
            or settlement["allocation_overrun"] is not False
            or settlement["settlement"]["payload"]["charged_seconds"] != 13
            or read_json(root / "registered_tests/result.json")["returncode"] != 0
            or (root / "stage_complete.json").exists() or (root / "stage_result.json").exists()):
        raise PermissionError("Original failed zero-forward/13-second admission differs")
    old = read_json(REPO / binding["old_owner"]["path"])
    if old["status"] != "STOPPED" or old["windows_creation_identity"] != exited["windows_creation_identity"]:
        raise PermissionError("Original failed owner does not bind its stopped exit")
    if query_owner:
        query = process_identity(old["pid"])
        if query["status"] == "RUNNING" and query.get("creation_identity") == old["windows_creation_identity"]:
            raise PermissionError("Exact original owner is still active; cannot admit repair: " + str(query))
        if query["status"] not in {"ABSENT", "EXITED", "RUNNING"}:
            raise PermissionError("Original owner exit is unconfirmed")
        # A successful native query with a different creation identity proves
        # PID reuse, not a live original owner. Never stop that unrelated process.
        return {"failure_binding_sha256": repair["failure_binding_sha256"], "old_native_query": query,
                "prior_charged_seconds": 13, "prior_full_forward_count": 0}
    return {"failure_binding_sha256": repair["failure_binding_sha256"]}


def run_registered_tests(output, deadline, before):
    before()
    tests = [REPO / "src/precip_input_assimilation/tests" / name for name in (
        "test_local_saved_context_v03.py", "test_local_branch_gradient_v03.py",
        "test_local_gradient_independent_v02.py", "test_local_gradient_driver_v03.py")]
    folder = output / "registered_tests"
    folder.mkdir(exist_ok=False)
    command = [sys.executable, "-B", "-m", "pytest", "-q", "-p", "no:cacheprovider",
               "--junitxml=" + str(folder / "report.xml"), *(str(p) for p in tests)]
    with (folder / "stdout.log").open("wb") as stdout, (folder / "stderr.log").open("wb") as stderr:
        child = subprocess.Popen(command, cwd=REPO, stdout=stdout, stderr=stderr)
        try:
            code = child.wait(timeout=max(0.01, deadline - 300 - time.monotonic()))
        except subprocess.TimeoutExpired:
            # This exact child was created here, has not exited, and cannot have been recycled.
            child.kill()
            child.wait()
            raise TimeoutError("Registered tests reached fixed exit reserve")
    result = {"returncode": code, "test_sources": {str(p): sha256(p) for p in tests},
              "stdout_sha256": sha256(folder / "stdout.log"), "stderr_sha256": sha256(folder / "stderr.log"),
              "report_sha256": sha256(folder / "report.xml") if (folder / "report.xml").exists() else None,
              "same_stage_reservation_sha256": sha256(output / "budget_reservation.json")}
    original_entry().write_json(folder / "result.json", result)
    before()
    if code != 0:
        raise RuntimeError("Targeted checks failed; original test evidence retained; no scientific model started")
    return result


def main():
    sys.dont_write_bytecode = True
    sys.path[:0] = [str(REPO), str(REPO / "src")]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("gradient", "direct_control", "network"), required=True)
    parser.add_argument("--approval", type=Path, required=True)
    parser.add_argument("--approval-sha256", required=True)
    parser.add_argument("--allow-reviewed-single-repair", action="store_true",
                        help="Use only after explicit user approval of the reviewed one-time reservation exception")
    args = parser.parse_args()
    if args.stage == "gradient" and not args.allow_reviewed_single_repair:
        raise PermissionError("Second reservation requires explicit user-authorized repair exception; no computation started")
    if Path(sys.executable).resolve() != Path("C:/Users/yiqun/anaconda3/python.exe").resolve():
        raise PermissionError("Original Python executable required")
    recipe, original, sources = config(), original_entry(), source_identity()
    require_approval(args.approval, args.approval_sha256, sources, args.stage)
    predecessor = require_predecessor(recipe, args.stage)
    output = original.check_output_path(FAMILY / recipe["stages"][args.stage]["output"])
    protection = protected_identity(recipe)
    transport = read_json(FAMILY / "pilot_20261009_01487000_s1001_s1002_s1003_v02/manifest.json")["original_transport_identity"]
    from precip_input_assimilation.scripts.run_precip_small_sample_diagnostic_v01 import creation_identity
    identity = creation_identity()
    with original.exclusive_trial_lock():
        prior_query = require_no_prior_owner()
        repair_context = verify_failure_binding(recipe, query_owner=True)
        original.verify_original_guard()
        verify_protected(protection)
        if any(sha256(p) != h for p, h in transport.items()):
            raise PermissionError("Completed transport evidence changed")
        journal, used, allocations, settled = original.load_budget(FAMILY / "cumulative_budget_v01.json")
        if args.stage == "gradient":
            binding = read_json(REPO / recipe["repair_protocol"]["failure_binding_path"])
            if used != 96089 or sha256(FAMILY / "cumulative_budget_v01.json") != binding["old_budget"]["sha256"]:
                raise PermissionError("Failed-stage settlement head changed; no second repair is registered")
        if len(allocations) != len(settled):
            raise PermissionError("Existing science reservation is unsettled")
        if (FAMILY / "STOP").exists():
            raise InterruptedError("Manual family stop preserved")
        owner = {"status": "RUNNING", "pid": os.getpid(), "windows_creation_identity": identity,
                 "output": str(output), "stage": args.stage,
                 "prior_native_query": prior_query, "exclusive_os_lock_acquired": True,
                 "started_utc": datetime.now(timezone.utc).isoformat()}

        def before():
            if time.monotonic() >= deadline - 300:
                raise TimeoutError("Fixed 300-second exit reserve reached")
            if (output / "STOP").exists() or (FAMILY / "STOP").exists():
                raise InterruptedError("Manual stop preserved")
            if source_identity() != sources:
                raise PermissionError("Reviewed implementation bytes changed during stage")
            original.verify_original_guard()
            verify_failure_binding(recipe)
            if any(sha256(p) != h for p, h in transport.items()):
                raise PermissionError("Original transport evidence changed")

        ctx, result, completed = None, None, False
        began = time.monotonic()
        reservation = original.reserve_budget(FAMILY / "cumulative_budget_v01.json", output,
            sha256(CONFIG), sha256(__file__), recipe["stages"][args.stage]["seconds"])
        try:
            deadline = began + recipe["stages"][args.stage]["seconds"]
            owner["reservation_sha256"] = reservation["sha256"]
            original.write_json(OWNER, owner)
            output.mkdir(parents=True, exist_ok=False)
            original.write_json(output / "budget_reservation.json", reservation)
            original.write_json(output / "config_snapshot.json", recipe)
            manifest = {**owner, "schema": "precip_local_gradient_small_sample_device_repair_actual_v03",
                        "repair_context": repair_context, "second_reservation_acknowledged": args.allow_reviewed_single_repair,
                        "plan_sha256": PLAN_SHA, "source_identity": sources, "predecessor": predecessor,
                        "approval_path": str(args.approval), "approval_sha256": args.approval_sha256,
                        "original_transport_identity": transport, "protected_identity": protection,
                        "score_numeric_reads_allowed": False, "deadline_monotonic": deadline,
                        "budget_used_before_seconds": used}
            original.write_json(output / "manifest.json", manifest)
            if args.stage == "gradient":
                tests = run_registered_tests(output, deadline, before)
            else:
                tests = read_json(FAMILY / recipe["stages"]["gradient"]["output"] / "registered_tests/result.json")
                if tests["returncode"] != 0 or tests["test_sources"] != {
                    p: sha256(p) for p in tests["test_sources"]}:
                    raise PermissionError("Predecessor registered checks changed")
            from precip_input_assimilation.small_sample.saved_context_v03 import create_saved_context
            ctx = create_saved_context(output, deadline, before)
            ctx.full_forward_limit = recipe["max_full_forwards"] if args.stage == "gradient" else None
            if args.stage == "network":
                direct = FAMILY / recipe["stages"]["direct_control"]["output"]
                direct_result = read_json(direct / "stage_result.json")
                ctx.direct_control_output = direct
                ctx.direct_control_artifacts = direct_result["fit_raw_artifacts"]
            manifest["runtime"] = ctx.runtime
            original.write_json(output / "manifest.json", manifest)
            if args.stage == "gradient":
                from precip_input_assimilation.small_sample.branch_gradient_v03 import run_gradient_stage
                result = run_gradient_stage(ctx, recipe)
            else:
                from precip_input_assimilation.small_sample.fit_v02 import optimize
                result = optimize(ctx, recipe, args.stage)
            result["registered_tests"] = tests
            original.write_json(output / "stage_result.json", result)
            if result.get("execution_complete") is not True:
                raise RuntimeError("Actual execution incomplete")
            from precip_input_assimilation.small_sample.local_gradient_independent_v02 import (
                audit_gradient_stage, audit_fit_stage)
            actual_audit = audit_gradient_stage(ctx, result) if args.stage == "gradient" else audit_fit_stage(ctx, result)
            actual_path = output / ("actual_independent_" + args.stage + "_audit.json")
            original.write_json(actual_path, actual_audit)
            audit = {"status": actual_audit["status"], "pass": actual_audit["pass"], "stage": args.stage,
                     "report_path": str(actual_path), "sha256": sha256(actual_path)}
            original.write_json(output / "independent_actual_audit.json", audit)
            before()
            verify_protected(protection)
            if args.stage == "gradient" and actual_audit["pass"] != result.get("numerical_gate_pass"):
                raise PermissionError("Primary and independent actual gate decisions differ")
            if (args.stage == "gradient" and result.get("numerical_gate_pass") is not True
                    and actual_audit.get("independent_checks_passed") is True):
                original.write_json(output / "fitting_blocked.json", {"reason": "Local derivative gate not passed",
                    "original_failure_preserved": True, "new_fitting_executed": False})
                return
            require_actual_audit(output, args.stage, audit)
            original.write_json(output / "stage_complete.json", {"stage": args.stage, "pass": True,
                "stage_result_sha256": sha256(output / "stage_result.json"),
                "audit_sha256": sha256(output / "independent_actual_audit.json"), "actual_audit_sha256": audit["sha256"],
                "forecast_improvement_claim": False})
            completed = True
        except BaseException as error:
            target = output if output.exists() else FAMILY
            name = "failure.json" if output.exists() else "local_gradient_setup_failure_" + reservation["payload"]["run_id"] + ".json"
            original.write_json(target / name, {"stage": args.stage, "error_type": type(error).__name__,
                "error": str(error), "traceback": traceback.format_exc(), "elapsed_seconds": time.monotonic() - began,
                "score_numeric_reads_started": False, "later_fitting_prohibited": True})
            raise
        finally:
            preservation_error = None
            try:
                verify_protected(protection)
                original.verify_original_guard()
                verify_failure_binding(recipe)
            except BaseException as error:
                preservation_error = {"error_type": type(error).__name__, "error": str(error)}
            elapsed = time.monotonic() - began
            settlement = original.settle_budget(FAMILY / "cumulative_budget_v01.json", reservation, elapsed)
            target = output if output.exists() else FAMILY
            original.write_json(target / "budget_settlement.json", settlement)
            original.write_json(target / "exit_evidence.json", {"elapsed_seconds": elapsed,
                "source_identity_unchanged": source_identity() == sources,
                "protected_identity_verified": preservation_error is None, "preservation_error": preservation_error,
                "transport_unchanged": all(sha256(p) == h for p, h in transport.items()),
                "full_forward_count": getattr(getattr(ctx, "full_forward_counter", None), "count", None),
                "windows_creation_identity": identity, "completed": completed, "budget": settlement,
                "prior_gradient_charged_seconds": 13, "prior_gradient_full_forward_count": 0,
                "logical_gradient_charged_seconds": (13 + settlement["settlement"]["payload"]["charged_seconds"])
                    if args.stage == "gradient" else None})
            original.write_json(OWNER, {**owner, "status": "STOPPED", "completed": completed,
                                      "ended_utc": datetime.now(timezone.utc).isoformat()})
            if preservation_error is not None:
                raise PermissionError("Original evidence preservation failed: " + str(preservation_error))


if __name__ == "__main__":
    main()
