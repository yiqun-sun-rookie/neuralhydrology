"""Owned-channel transport via verified Git blobs when Contents reads truncate.

This helper preserves the existing transport and scientific runtime unchanged.
"""

import argparse
import base64
import hashlib
import json
from pathlib import Path
import time

from dynamic_filter_mailbox import BRANCH, CHANNEL, Mailbox


class BlobMailbox(Mailbox):
    def __init__(self):
        super().__init__()
        self._trees = {}
        self._roots = {}

    def api(self, path, method="GET", body=None, missing=False):
        # Request a fresh HTTP response while commit and blob hashes pin content.
        # Writes retain the original single-attempt and non-forced behavior.
        if method == "GET":
            separator = "&" if "?" in path else "?"
            path = f"{path}{separator}read_nonce={time.time_ns()}"
        return super().api(path, method, body, missing)

    def tree(self, sha):
        if sha not in self._trees:
            self._trees[sha] = self.api(f"git/trees/{sha}")["tree"]
        return self._trees[sha]

    def text(self, path, ref=BRANCH):
        if path != "CHANNELS.md" and not path.startswith((f"inbox/{CHANNEL}/", f"outbox/{CHANNEL}/")):
            raise PermissionError("Only this owned channel and its registry may be read")
        if ref == BRANCH:
            ref = self.api(f"git/ref/heads/{BRANCH}")["object"]["sha"]
        if ref not in self._roots:
            self._roots[ref] = self.api(f"git/commits/{ref}")["tree"]["sha"]
        sha = self._roots[ref]
        parts = path.split("/")
        for index, part in enumerate(parts):
            entry = next((item for item in self.tree(sha) if item["path"] == part), None)
            if entry is None:
                return None
            if index < len(parts) - 1 and entry["type"] != "tree":
                raise RuntimeError("Intermediate mailbox path is not a tree")
            sha = entry["sha"]
        if entry["type"] != "blob":
            raise RuntimeError("Mailbox file is not a blob")
        blob = self.api(f"git/blobs/{sha}")
        if blob["encoding"] != "base64":
            raise RuntimeError("Unsupported blob encoding")
        raw = base64.b64decode(blob["content"])
        prefix = b"blob " + str(len(raw)).encode() + bytes([0])
        if hashlib.sha1(prefix + raw).hexdigest() != sha or len(raw) != blob["size"]:
            raise RuntimeError("Mailbox blob integrity failed")
        return raw.decode("utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("inspect", "read", "publish"))
    parser.add_argument("--sequence", type=int)
    parser.add_argument("--command", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError("Preserve existing evidence; choose an unused output path")
    box = BlobMailbox()
    head = box.api(f"git/ref/heads/{BRANCH}")["object"]["sha"]
    if args.mode == "inspect":
        sequence = box.text(f"inbox/{CHANNEL}/seq", head)
        result = {"channel": CHANNEL, "sequence": int(sequence), "commit": head}
    elif args.mode == "read":
        receipt = box.text(f"outbox/{CHANNEL}/result_{args.sequence}.txt", head)
        if receipt is None:
            print(json.dumps({"pending": True, "sequence": args.sequence, "commit": head}))
            return
        with args.output.open("x", encoding="utf-8", newline="\n") as handle:
            handle.write(receipt)
        print(json.dumps({"pending": False, "sequence": args.sequence, "commit": head,
                          "receipt": str(args.output), "sha256": hashlib.sha256(receipt.encode()).hexdigest()}))
        return
    else:
        if args.command is None or args.sequence is None:
            raise ValueError("An explicit command and sequence are required")
        current = int(box.text(f"inbox/{CHANNEL}/seq", head))
        if current == args.sequence - 1:
            previous = box.text(f"outbox/{CHANNEL}/result_{current}.txt", head)
            if previous is None or "### ---------- end ----------" not in previous:
                raise RuntimeError("Previous receipt is not complete")
            footer = previous.split("### ---------- end ----------", 1)[1]
            if "### exit_code=" not in footer or "### finished=" not in footer:
                raise RuntimeError("Previous receipt lacks its final status")
        result = box.publish(args.sequence, args.command.read_text(encoding="utf-8"))
    with args.output.open("x", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
