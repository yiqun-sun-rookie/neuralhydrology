"""Use commit-bound Git trees for receipt identity, retaining version-two reads.

Only the owned receipt contents GET is replaced by small identity queries.
The original byte validators, publication protocol and run/lock are unchanged.
Both supplemental migrations and both reviewed network sources stay pinned.
"""

import argparse
import json
from pathlib import Path
import re

import eight_basin_recovery_network_v02 as previous


driver = previous.driver
SCHEMA = "eight-basin-receipt-metadata-network-v3"
PREVIOUS_MIGRATION = "45ad38a07c41cacb1f135e9f5cd451bcd4c858af0e949e4481b336309dcadbb8"
RECEIPT = re.compile(r"contents/(outbox/" + re.escape(driver.transport.CHANNEL) +
                     r"/result_[0-9]+\.txt)\?ref=([0-9a-f]{40})\Z")


def receipt_metadata(api, path, missing=False):
    """Verify every commit-to-tree-to-blob edge without downloading blob bytes."""
    match = RECEIPT.fullmatch(path)
    if match is None:
        raise driver.IntegrityError("Receipt metadata requires the owned path and a fixed commit")
    name, commit_sha = match.groups()
    commit = api("git/commits/" + commit_sha)
    if commit.get("sha") != commit_sha or not driver.HEX40.fullmatch(commit["tree"]["sha"]):
        raise driver.IntegrityError("Receipt metadata commit identity differs")
    tree_sha = commit["tree"]["sha"]
    parts = name.split("/")
    for position, part in enumerate(parts):
        tree = api("git/trees/" + tree_sha)
        if tree.get("sha") != tree_sha or tree.get("truncated") is not False:
            raise driver.IntegrityError("Receipt metadata tree identity is incomplete")
        entries = [entry for entry in tree["tree"] if entry["path"] == part]
        if not entries:
            if missing:
                return None
            raise RuntimeError(f"Mailbox API HTTP 404 at {path}")
        if len(entries) != 1 or not driver.HEX40.fullmatch(entries[0]["sha"]):
            raise driver.IntegrityError("Receipt metadata entry is ambiguous")
        entry = entries[0]
        if position < len(parts) - 1:
            if entry["type"] != "tree" or entry["mode"] != "040000":
                raise driver.IntegrityError("Receipt metadata ancestor is not a genuine directory")
            tree_sha = entry["sha"]
        elif (entry["type"] != "blob" or entry["mode"] != "100644" or type(entry["size"]) is not int or
              not 0 <= entry["size"] <= driver.MAX_RECEIPT):
            raise driver.IntegrityError("Receipt metadata is not a bounded regular blob")
    return {"type": "file", "path": name, "sha": entry["sha"], "size": entry["size"], "encoding": "none"}


def migration_guard(home, migration_path, migration_sha256):
    transport = driver.transport
    home = transport.no_link_ancestors(home)
    if transport.no_link_ancestors(migration_path) != home / "network_migration_v03.json":
        raise driver.IntegrityError("Metadata migration belongs to another recovery directory")
    parent = previous.migration_guard(home, home / "network_migration_v02.json", PREVIOUS_MIGRATION)
    raw = driver.regular_bytes(migration_path, transport.MAX_METADATA)
    if not driver.HEX64.fullmatch(migration_sha256) or driver.digest(raw) != migration_sha256:
        raise driver.IntegrityError("Externally pinned metadata migration SHA256 differs")
    migration = transport.parse_json(raw)
    if (migration["schema"] != SCHEMA or migration["previous_migration_sha256"] != PREVIOUS_MIGRATION or
            migration["original_admission_sha256"] != previous.ORIGINAL_ADMISSION or
            migration["home"] != str(transport.display_path(home)) or
            migration["original_sources"] != parent["original_sources"] or
            driver.file_digest(Path(__file__)) != migration["network_source_sha256"] or
            driver.file_digest(Path(__file__).parents[1] / "tests/test_eight_basin_recovery_network_v03.py") !=
            migration["network_tests_sha256"]):
        raise driver.IntegrityError("Metadata overlay changed an admitted source identity")
    predecessor = migration["predecessor"]
    state_raw = driver.regular_bytes(transport.safe_path(home, predecessor["state_file"]), transport.MAX_METADATA)
    index_raw = driver.regular_bytes(transport.safe_path(home, predecessor["receipt_index_file"]), transport.MAX_METADATA)
    state = transport.parse_json(state_raw)
    index = transport.parse_json(index_raw)
    if (driver.digest(state_raw) != predecessor["state_sha256"] or
            driver.digest(index_raw) != predecessor["receipt_index_sha256"] or
            state["admission_sha256"] != previous.ORIGINAL_ADMISSION or state["cursor"] != predecessor["cursor"] or
            state["pending"] != predecessor["pending"] or len(index["records"]) != state["cursor"]):
        raise driver.IntegrityError("Metadata overlay predecessor changed")
    pointer = transport.parse_json(driver.regular_bytes(home / "cursor.json"))
    current_raw = driver.regular_bytes(transport.safe_path(home, pointer["state_file"]), transport.MAX_METADATA)
    current = transport.parse_json(current_raw)
    current_index_raw = driver.regular_bytes(transport.safe_path(home, current["receipt_index_file"]), transport.MAX_METADATA)
    current_index = transport.parse_json(current_index_raw)
    if (driver.digest(current_raw) != pointer["state_sha256"] or
            driver.digest(current_index_raw) != current["receipt_index_sha256"] or
            current["cursor"] < state["cursor"] or current["generation"] < state["generation"] or
            len(current_index["records"]) != current["cursor"] or
            current_index["records"][:state["cursor"]] != index["records"]):
        raise driver.IntegrityError("Metadata overlay reversed accepted requests")
    return migration


class MetadataMailbox(previous.BoundedReadMailbox):
    def __init__(self, home, guard, migration_sha256):
        super().__init__(home, guard, migration_sha256)
        migration = guard()
        owner = driver.transport.parse_json(driver.regular_bytes(self.home / "owner.json"))
        driver.immutable_json(self.home, self.home / "network_owners_v03" /
                              (str(owner["process"]["pid"]) + "_" + owner["process"]["creation"] + ".json"), {
                                  "process": owner["process"], "original_admission_sha256": previous.ORIGINAL_ADMISSION,
                                  "migration_sha256": migration_sha256, "previous_migration_sha256": PREVIOUS_MIGRATION,
                                  "network_source_sha256": migration["network_source_sha256"]})

    def api(self, path, method="GET", body=None, missing=False):
        if method == "GET" and path.startswith("contents/outbox/" + driver.transport.CHANNEL + "/"):
            if body is not None:
                raise driver.IntegrityError("Receipt metadata reads cannot contain a body")
            return receipt_metadata(super().api, path, missing)
        return super().api(path, method, body, missing)


def run(home, migration_path, migration_sha256, poll_seconds=45, once=False):
    guard = lambda: migration_guard(home, migration_path, migration_sha256)
    guard()
    original = driver.mailbox_module.Mailbox
    driver.mailbox_module.Mailbox = lambda: MetadataMailbox(home, guard, migration_sha256)
    try:
        return driver.run(home, previous.ORIGINAL_ADMISSION, poll_seconds, once)
    finally:
        driver.mailbox_module.Mailbox = original


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["run"])
    parser.add_argument("--home", type=Path, required=True)
    parser.add_argument("--migration", type=Path, required=True)
    parser.add_argument("--migration-sha256", required=True)
    parser.add_argument("--poll-seconds", type=int, default=45)
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()
    print(json.dumps(run(args.home, args.migration, args.migration_sha256, args.poll_seconds, args.once)), flush=True)


if __name__ == "__main__":
    main()
