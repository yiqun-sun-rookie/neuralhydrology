"""One supervised numerical process; no numerical import precedes admission/tests.

Only the supervisor owns a lock, reservations, counter writes and settlement.
This worker retains its loaded context and live models through synchronous
checkpoints. A stage marker is provisional until the entire numerical job exits.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import stat
import subprocess
import sys
import time
import traceback
from types import ModuleType
import xml.etree.ElementTree as ET

REPO = Path(__file__).resolve().parents[3]
FAMILY = REPO / "results/precip_input_da_2026_09/effect_first_v01"
STAGES = ("gradient", "direct_control", "network")
REQUIRED_OLD_TESTS = (
    "test_local_saved_context_v03.py", "test_local_branch_gradient_v03.py",
    "test_local_gradient_independent_v02.py", "test_local_gradient_driver_v03.py")


def install_metadata_package_namespace():
    """Establish communication before any eager scientific package initialization."""
    if any(name == library or name.startswith(library + ".")
           for name in sys.modules for library in ("torch", "numpy", "pandas")):
        raise PermissionError("Numerical library import before worker admission is prohibited")
    name = "precip_input_assimilation"
    location = str(REPO / "src" / name)
    existing = sys.modules.get(name)
    if existing is not None:
        if (getattr(existing, "_metadata_namespace_root", None) != location
                or getattr(existing, "__path__", None) != [location]
                or getattr(existing, "__package__", None) != name):
            raise PermissionError("Existing scientific package cannot become a metadata namespace")
        return
    package = ModuleType(name)
    package.__path__ = [location]
    package.__package__ = name
    package._metadata_namespace_root = location
    sys.modules[name] = package


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_new(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def safe_existing(path, root):
    path, root = Path(path).absolute(), Path(root).absolute()
    if ".." in path.parts or not path.is_relative_to(root):
        raise PermissionError("Worker path escaped the exact admitted root")
    for current in (path, *path.parents, root, *root.parents):
        info = current.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise PermissionError("Worker source/output contains a link or reparse point")
    if path.resolve(strict=True) != path or root.resolve(strict=True) != root:
        raise PermissionError("Worker deployment path changed")
    return path


def require_sources(identity):
    if not isinstance(identity, dict) or not identity:
        raise PermissionError("Missing complete reviewed source identities")
    for name, expected in identity.items():
        path = safe_existing(REPO / name, REPO)
        if sha256(path) != expected:
            raise PermissionError("Reviewed source bytes changed: " + name)


class SynchronousCheckpoints:
    """Synchronize the live device before any owner/reservation checkpoint.

    No model, optimizer, graph or random state is rebuilt here. The total
    deadline can shorten; the slice deadline never becomes a replay deadline.
    """

    def __init__(self, runtime, synchronize, require_unchanged, full_preservation=None):
        self.runtime, self.synchronize, self.require_unchanged = runtime, synchronize, require_unchanged
        self.full_preservation = full_preservation
        self.context = None
        self.active = False

    def __call__(self, numerical=True, begin_operation=True):
        return self._checkpoint(numerical, begin_operation, full=False)

    def verify_full_preservation(self, numerical=True, begin_operation=True):
        """One synchronized owner checkpoint, then all original disk guards."""
        return self._checkpoint(numerical, begin_operation, full=True)

    def _checkpoint(self, numerical, begin_operation, *, full):
        if self.active:
            raise RuntimeError("Recursive numerical budget checkpoint is forbidden")
        self.active = True
        try:
            if numerical:
                self.synchronize()
            receipt = self.runtime.checkpoint("numerical_checkpoint" if numerical else "metadata_checkpoint",
                begin_operation=begin_operation)
            self.require_unchanged()
            if self.context is not None:
                self.context.deadline = min(self.context.deadline, self.runtime.global_deadline)
            if full:
                if not callable(self.full_preservation):
                    raise PermissionError("A numerical boundary lacks its complete preservation guard")
                self.full_preservation()
            return receipt
        finally:
            self.active = False


def stage_suffix(recipe, session, selected_stage):
    """Choose the fixed remaining stages without repeating an accepted prefix."""
    attempt = recipe.get("attempt")
    if not isinstance(attempt, dict) or set(attempt) != {"id", "ordinal", "start_stage", "retry_admission"}:
        raise PermissionError("Missing exact attempt/start-stage/retry admission")
    if (not isinstance(attempt["id"], str) or not attempt["id"]
            or attempt["id"] != session.get("attempt_id")
            or type(attempt["ordinal"]) is not int or attempt["ordinal"] < 1
            or selected_stage not in STAGES or attempt["start_stage"] != selected_stage):
        raise PermissionError("Selected stage does not match the admitted attempt")
    if attempt["ordinal"] == 1:
        if selected_stage != "gradient" or attempt["retry_admission"] is not None:
            raise PermissionError("First attempt must begin at the original gradient stage")
    else:
        retry = attempt["retry_admission"]
        if not isinstance(retry, dict) or set(retry) != {"path", "sha256"}:
            raise PermissionError("A technical retry requires its exact reviewed admission")
    prefix = session.get("completed_predecessors")
    index = STAGES.index(selected_stage)
    if not isinstance(prefix, dict) or set(prefix) != set(STAGES[:index]):
        raise PermissionError("The completed prefix is missing, repeated or exceeds the selected start stage")
    stages = STAGES[index:]
    if any(stage in prefix for stage in stages):
        raise PermissionError("An independently completed stage cannot be executed again")
    return stages


def require_stage_outputs(recipe, session, selected_stage):
    stages = stage_suffix(recipe, session, selected_stage)
    run_root = safe_existing(session["run_root"], FAMILY)
    outputs, prefix = session.get("stage_outputs"), session["completed_predecessors"]
    if not isinstance(outputs, dict) or set(outputs) != set(STAGES):
        raise PermissionError("Worker stage output inventory changed")
    for stage, output in outputs.items():
        path = safe_existing(output, FAMILY)
        if stage in stages:
            safe_existing(path, run_root)
        elif (not isinstance(prefix[stage], dict) or prefix[stage].get("stage") != stage
                or Path(prefix[stage].get("output", "")).absolute() != path
                or path.is_relative_to(run_root)):
            raise PermissionError("An accepted predecessor output was replaced by a new-attempt directory")
    return stages


def require_static_admission(config_path, session, selected_stage):
    config_path = safe_existing(config_path, REPO)
    if sha256(config_path) != session["config_sha256"]:
        raise PermissionError("Worker configuration differs from its supervised admission")
    recipe = read_json(config_path)
    require_sources(session["source_identity"])
    approval_path = safe_existing(session["approval_path"], REPO)
    if sha256(approval_path) != session["approval_sha256"]:
        raise PermissionError("Independent static approval bytes changed")
    approval = read_json(approval_path)
    if (approval.get("status") != "PASS_STATIC_REQUIRE_REGISTERED_TESTS"
            or approval.get("source_identity") != session["source_identity"]
            or approval.get("registered_tests_before_scientific_model") is not True):
        raise PermissionError("Exact worker sources lack independent static admission")
    required = {"basin": "01487000", "seeds": [1001, 1002, 1003], "max_steps": 1000,
        "checkpoint_interval": 10, "target_start": "1980-10-02", "target_end": "1980-11-02",
        "control_learning_rate_mm": .1, "network_learning_rate": .001, "mse_threshold": .0001,
        "relative_reduction": .99, "soft_penalties": {"magnitude": 0., "violation": 0.},
        "soft_penalties_graph": "absent", "score_numeric_reads_allowed": False,
        "max_full_forwards": 100, "parameter_scales": [.0001, .0003, .001, .003, .01],
        "gradient_relative_error": .05, "minimum_terminal_direction_response": .001,
        "parameter_direction_error_limit": .001, "parameter_midpoint_error_per_scale_limit": .001,
        "scalar_minimum_ulp_multiple": 32, "exit_reserve_seconds": 300, "new_remote_jobs": 0}
    for name, expected in required.items():
        if recipe.get(name) != expected:
            raise PermissionError("Worker scientific recipe differs: " + name)
    require_stage_outputs(recipe, session, selected_stage)
    verify_completed_predecessors(session)
    retry = recipe["attempt"]["retry_admission"]
    if retry is not None:
        path = safe_existing(REPO / retry["path"], REPO)
        if sha256(path) != retry["sha256"]:
            raise PermissionError("Technical retry admission bytes changed before numerical imports")
    return recipe


def run_registered_tests(runtime, recipe, run_root, guard):
    """The only child command; admission, waits and output remain metered."""
    listed = recipe.get("registered_tests")
    if not isinstance(listed, list) or not listed:
        raise PermissionError("Missing explicit registered test inventory")
    tests = [safe_existing(REPO / "src/precip_input_assimilation/tests" / name
                           if Path(name).name == name else REPO / name, REPO) for name in listed]
    names = [path.name for path in tests]
    if len(tests) != len(set(tests)) or not set(REQUIRED_OLD_TESTS).issubset(names):
        raise PermissionError("Original 102-test inventory was dropped or duplicated")
    if "test_precip_local_gradient_runtime_v04.py" not in names:
        raise PermissionError("The fourth-version scientific runtime tests are not registered")
    folder = Path(run_root) / "registered_tests"
    folder.mkdir(exist_ok=False)
    guard(numerical=False)
    reservation = runtime.checkpoint("registered_tests_start", begin_operation=True)
    slice_deadline = reservation.get("slice_deadline")
    if not isinstance(slice_deadline, (int, float)) or not math.isfinite(slice_deadline):
        raise PermissionError("Tests have no active reserved slice deadline")
    command = [sys.executable, "-B", "-m", "pytest", "-q", "-p", "no:cacheprovider",
               "--junitxml=" + str(folder / "report.xml"), *(str(path) for path in tests)]
    began = time.monotonic()
    with (folder / "stdout.log").open("x", encoding="utf-8") as stdout, \
            (folder / "stderr.log").open("x", encoding="utf-8") as stderr:
        child = subprocess.Popen(command, cwd=REPO, stdout=stdout, stderr=stderr,
                                 creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
        child_identity = None
        try:
            child_identity = runtime.register_child(child.pid)
            while child.poll() is None:
                runtime._require_owner()
                if ((Path(run_root) / "STOP").exists() or (Path(run_root).parent / "STOP").exists() or
                        time.monotonic() >= min(slice_deadline, runtime.global_deadline) - 300):
                    raise TimeoutError("Tests cannot reach a paused checkpoint within the admitted reserve")
                try:
                    child.wait(timeout=1.)
                except subprocess.TimeoutExpired:
                    pass
        except BaseException:
            if child.poll() is None:
                child.terminate()
            child.wait()
            raise
    runtime.checkpoint("registered_tests_exited", begin_operation=False)
    report = ET.parse(folder / "report.xml").getroot()
    suites = [report] if report.tag == "testsuite" else list(report.iter("testsuite"))
    summary = {name: sum(int(suite.get(name, "0")) for suite in suites)
               for name in ("tests", "failures", "errors", "skipped")}
    result = {"returncode": child.returncode, "summary": summary,
              "test_sources": {str(path): sha256(path) for path in tests},
              "seconds": time.monotonic() - began, "child_identity": child_identity,
              "all_tests_inside_metered_group": True}
    write_new(folder / "result.json", result)
    if child.returncode != 0 or summary["tests"] == 0 or any(summary[name] for name in ("failures", "errors", "skipped")):
        raise RuntimeError("Registered tests failed or skipped; no scientific model may start")
    return result


def require_actual(output, stage, report):
    path = safe_existing(report["report_path"], output)
    if sha256(path) != report["sha256"]:
        raise PermissionError("Independent actual report bytes changed")
    actual = read_json(path)
    if (actual.get("status") != "PASS" or actual.get("pass") is not True
            or actual.get("stage") != stage or actual.get("independent_checks_passed") is not True):
        raise PermissionError("Independent actual numerical evidence did not pass")
    return actual


def require_predecessor(runtime, session, stage):
    previous = {"gradient": None, "direct_control": "gradient", "network": "direct_control"}[stage]
    if previous is None:
        # The original accepted weight replay is metadata admission only. Its
        # source/date/60-proof guards are checked again by the saved context.
        predecessor = session.get("predecessor")
        if not isinstance(predecessor, dict) or predecessor.get("stage") != "weight_replay":
            raise PermissionError("Missing original independently accepted weight replay predecessor")
        path = safe_existing(predecessor["complete_path"], REPO)
        if sha256(path) != predecessor["sha256"]:
            raise PermissionError("Original accepted predecessor bytes changed")
        return predecessor
    output = safe_existing(session["stage_outputs"][previous], FAMILY)
    final = read_json(safe_existing(output / "stage_complete.json", output))
    result = read_json(safe_existing(output / "stage_result.json", output))
    audit = read_json(safe_existing(output / "independent_actual_audit.json", output))
    if (final.get("pass") is not True or final.get("stage") != previous
            or final["stage_result_sha256"] != sha256(output / "stage_result.json")
            or final["audit_sha256"] != sha256(output / "independent_actual_audit.json")
            or final.get("actual_audit_sha256") != audit.get("sha256")
            or result.get("execution_complete") is not True or (output / "failure.json").exists()):
        raise PermissionError("Predecessor lacks complete exact raw/audit bindings")
    actual = require_actual(output, previous, audit)
    if previous == "gradient" and result.get("numerical_gate_pass") is not True:
        raise PermissionError("Local derivative gate blocks all physical fitting")
    if result.get("window_uninformative") or actual.get("window_uninformative"):
        raise PermissionError("The low-error initialization stops the entire learning window")
    completed = session.get("completed_predecessors", {})
    if previous in completed:
        bound = completed[previous]
        required = {"stage", "output", "complete_path", "sha256", "stage_result_sha256", "audit_sha256",
                    "actual_audit_sha256", "final_supervisor_report_path", "final_supervisor_report_sha256"}
        if not isinstance(bound, dict) or set(bound) != required:
            raise PermissionError("An external completed predecessor lacks its exact acceptance binding")
        complete_path = safe_existing(bound["complete_path"], output)
        if (bound["stage"] != previous or Path(bound["output"]).absolute() != output
                or complete_path != output / "stage_complete.json"
                or sha256(complete_path) != bound["sha256"]
                or bound["stage_result_sha256"] != final["stage_result_sha256"]
                or bound["audit_sha256"] != final["audit_sha256"]
                or bound["actual_audit_sha256"] != audit["sha256"]
                or not isinstance(final.get("attempt_id"), str) or not final["attempt_id"]
                or final["attempt_id"] == session["attempt_id"]):
            raise PermissionError("External completed stage bytes or attempt identity changed")
        report_path = safe_existing(bound["final_supervisor_report_path"], FAMILY)
        if sha256(report_path) != bound["final_supervisor_report_sha256"]:
            raise PermissionError("External final supervisor report bytes changed")
        report = read_json(report_path)
        accepted = report.get("final_stage_acceptance", {}).get(previous)
        expected = {"pass": True, "complete_path": str(complete_path), "sha256": bound["sha256"],
                    "stage_result_sha256": bound["stage_result_sha256"], "audit_sha256": bound["audit_sha256"],
                    "actual_audit_sha256": bound["actual_audit_sha256"]}
        if (report.get("numeric_group_exited") is not True or report.get("budget_closure_confirmed") is not True
                or report.get("source_identity_unchanged") is not True or accepted != expected):
            raise PermissionError("External prefix has no exact process-group exit, settlement and final stage acceptance")
        return dict(bound)
    if (final.get("attempt_id") != session["attempt_id"]
            or final.get("pending_numeric_group_exit") is not True
            or not output.is_relative_to(Path(session["run_root"]).absolute())):
        raise PermissionError("An internal predecessor does not bind the live current attempt")
    return {"stage": previous, "complete_path": str(output / "stage_complete.json"),
            "sha256": sha256(output / "stage_complete.json")}


def verify_completed_predecessors(session):
    completed = session.get("completed_predecessors")
    if not isinstance(completed, dict) or any(stage not in STAGES for stage in completed):
        raise PermissionError("Completed predecessor registry is missing or has an unknown stage")
    following = {"gradient": "direct_control", "direct_control": "network"}
    for previous in completed:
        if previous not in following:
            raise PermissionError("No completed network stage can be scheduled for repeated learning")
        require_predecessor(None, session, following[previous])


def verify_full_preservation(session):
    """Keep every original guard at reads, complete forwards and acceptance.

    Frequent checkpoints still obtain the supervisor's authenticated source,
    owner, lock, stop and reservation checks. This additional worker check
    retains the original 410-file protection inventory without re-pinning it.
    """
    require_sources(session["source_identity"])
    from precip_input_assimilation.scripts.run_precip_local_gradient_small_sample_v03 import (
        original_entry, verify_protected, verify_failure_binding)
    original_entry().verify_original_guard()
    verify_protected(session["protection"])
    bound = session.get("old_v03_config")
    if not isinstance(bound, dict) or set(bound) != {"path", "sha256"}:
        raise PermissionError("Missing exact source-bound original failure configuration")
    path = safe_existing(REPO / bound["path"], REPO)
    if session["source_identity"].get(path.relative_to(REPO).as_posix()) != bound["sha256"]:
        raise PermissionError("Original failure configuration is outside the reviewed source identity")
    content = path.read_bytes()
    if hashlib.sha256(content).hexdigest() != bound["sha256"]:
        raise PermissionError("Original failure configuration bytes changed")
    # Read only the preserved failure binding; obsolete stage caps and repair
    # protocol admission in the old entry point are not invoked.
    verify_failure_binding(json.loads(content.decode("utf-8")))
    for name, expected in session["transport"].items():
        if sha256(safe_existing(name, REPO)) != expected:
            raise PermissionError("Completed original transport bytes changed")
    require_predecessor(None, session, "gradient")
    verify_completed_predecessors(session)


def execute(runtime, recipe, session, selected_stage, tests, guard):
    from precip_input_assimilation.small_sample.saved_context_v04 import create_saved_context, FullForwardCounter
    from precip_input_assimilation.small_sample.branch_gradient_v04 import run_gradient_stage
    from precip_input_assimilation.small_sample.fit_v04 import optimize
    from precip_input_assimilation.small_sample.local_gradient_independent_v04 import audit_gradient_stage, audit_fit_stage
    from precip_input_assimilation.small_sample import support_v01 as support
    import torch
    stages = require_stage_outputs(recipe, session, selected_stage)
    ctx, summaries = None, []
    for stage in stages:
        predecessor = require_predecessor(runtime, session, stage)
        output = Path(session["stage_outputs"][stage])
        if stage == "gradient":
            counters = runtime.counter_snapshot()
            consumed = counters.get("counts", {}).get("gradient_full_forward")
            if type(consumed) is not int or not 0 <= consumed <= 6:
                raise RuntimeError("A complete original-base retry requires 94 of the cumulative 100 calls")
        guard.verify_full_preservation()
        if ctx is None:
            ctx = create_saved_context(output, runtime.global_deadline, guard, operation_runtime=runtime,
                                       attempt_id=session["attempt_id"], stage=stage)
            guard.context = ctx
        else:
            ctx.output, ctx.stage = output, stage
            ctx.deadline = min(ctx.deadline, runtime.global_deadline)
            ctx.full_forward_limit = 100 if stage == "gradient" else None
            ctx.full_forward_counter = FullForwardCounter(ctx)
        ctx.stage_outputs = session["stage_outputs"]
        if stage == "network":
            direct = Path(session["stage_outputs"]["direct_control"])
            ctx.direct_control_output = direct
            ctx.direct_control_artifacts = read_json(direct / "stage_result.json")["fit_raw_artifacts"]
        write_new(output / "stage_manifest.json", {"stage": stage, "attempt_id": session["attempt_id"],
            "source_identity": session["source_identity"], "predecessor": predecessor,
            "runtime": ctx.runtime, "global_deadline": ctx.deadline, "no_stage_deadline": True,
            "same_numeric_process": os.getpid(), "context_reconstructed_for_budget_slice": False})
        result = run_gradient_stage(ctx, recipe) if stage == "gradient" else optimize(ctx, recipe, stage)
        result["registered_tests"] = tests
        write_new(output / "stage_result.json", result)
        if result.get("execution_complete") is not True:
            write_new(output / "technical_incomplete.json", {"stage": stage,
                "scientific_negative_result": False, "later_fitting_prohibited": True})
            return {"status": "TECHNICAL_INCOMPLETE", "summaries": summaries, "stage": stage}
        actual = audit_gradient_stage(ctx, result) if stage == "gradient" else audit_fit_stage(ctx, result)
        actual_path = output / ("actual_independent_" + stage + "_audit.json")
        write_new(actual_path, actual)
        report = {"status": actual["status"], "pass": actual["pass"], "stage": stage,
                  "report_path": str(actual_path), "sha256": sha256(actual_path)}
        write_new(output / "independent_actual_audit.json", report)
        if stage == "gradient" and actual["pass"] != result.get("numerical_gate_pass"):
            raise PermissionError("Independent and main local derivative classifications differ")
        if stage == "gradient" and not actual["pass"] and actual.get("independent_checks_passed") is True:
            write_new(output / "fitting_blocked.json", {"stage": stage, "reason": "Local derivative not confirmed",
                "new_fitting_executed": False, "scientific_fit_claim": False})
            return {"status": "SCIENTIFIC_BLOCKED_OR_UNCONFIRMED", "summaries": summaries, "stage": stage}
        require_actual(output, stage, report)
        guard.verify_full_preservation()
        write_new(output / "stage_complete.json", {"stage": stage, "pass": True,
            "attempt_id": session["attempt_id"], "pending_numeric_group_exit": True,
            "stage_result_sha256": sha256(output / "stage_result.json"),
            "audit_sha256": sha256(output / "independent_actual_audit.json"),
            "actual_audit_sha256": report["sha256"], "forecast_improvement_claim": False})
        summaries.append({"stage": stage, "raw_result_sha256": sha256(output / "stage_result.json"),
                          "actual_audit_sha256": report["sha256"]})
        if result.get("window_uninformative") or actual.get("window_uninformative"):
            return {"status": "WINDOW_UNINFORMATIVE", "summaries": summaries,
                    "all_later_window_optimization_prohibited": True}
    torch.cuda.synchronize(ctx.device)
    support.assert_frozen_mode(ctx.hydro, ctx.mode_reference)
    return {"status": "NUMERICAL_STAGES_AUDITED_PENDING_GROUP_EXIT", "summaries": summaries,
            "scientific_forecast_improvement_claim": False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--session", type=Path, required=True)
    parser.add_argument("--stage", choices=STAGES, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(REPO / "src"))
    install_metadata_package_namespace()
    from precip_input_assimilation.small_sample.flexible_ipc_v04 import RuntimeClient
    runtime = RuntimeClient(args.session)
    session, session_sha = runtime.session, sha256(args.session)
    run_root, result, numerical_imported = Path(session["run_root"]), None, False
    def verify_unchanged():
        if sha256(args.session) != session_sha:
            raise PermissionError("Exact immutable worker session changed")
        if (run_root / "STOP").exists() or (run_root.parent / "STOP").exists():
            raise InterruptedError("Manual stop remains in force")
    def synchronize():
        if numerical_imported:
            import torch
            torch.cuda.synchronize("cuda:0")
    guard = SynchronousCheckpoints(runtime, synchronize, verify_unchanged,
                                   lambda: verify_full_preservation(session))
    try:
        guard.verify_full_preservation(numerical=False)
        recipe = require_static_admission(args.config, session, args.stage)
        tests = run_registered_tests(runtime, recipe, run_root, guard)
        guard.verify_full_preservation(numerical=False)
        numerical_imported = True
        result = execute(runtime, recipe, session, args.stage, tests, guard)
    except BaseException as error:
        result = {"status": "FAILED_OR_TECHNICAL_INCOMPLETE", "error_type": type(error).__name__,
                  "error": str(error), "traceback": traceback.format_exc(),
                  "later_fitting_prohibited": True, "scientific_negative_result": False}
        write_new(run_root / "worker_failure.json", result)
        raise
    finally:
        exit_error = None
        try:
            if numerical_imported:
                import torch
                torch.cuda.synchronize("cuda:0")
            guard.verify_full_preservation(numerical=False, begin_operation=False)
        except BaseException as error:
            exit_error = {"type": type(error).__name__, "error": str(error)}
        evidence = {"schema": "precip_numeric_worker_exit_v04", "result": result,
                    "exit_guard_error": exit_error, "numeric_process_identity": runtime.identity,
                    "numeric_exit_record_utc": datetime.now(timezone.utc).isoformat(),
                    "pending_exact_numeric_group_exit": True, "budget_settled_by_worker": False}
        write_new(run_root / "numeric_exit_record.json", evidence)
        try:
            runtime.finished(evidence)
        finally:
            runtime.close()
        if exit_error is not None:
            raise RuntimeError("Worker exit preservation/synchronization failed: " + str(exit_error))


if __name__ == "__main__":
    main()
