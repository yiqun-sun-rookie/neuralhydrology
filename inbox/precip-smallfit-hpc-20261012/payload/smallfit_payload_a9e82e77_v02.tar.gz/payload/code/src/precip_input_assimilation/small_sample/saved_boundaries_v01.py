"""Metered, saved-evidence-only boundary reconstruction.

No numerical dependency is imported and no evidence is loaded on import. The
caller owns the original family lock and open reservation and supplies before.
This module never constructs a model, changes a saved point, or releases a fit.
"""

from datetime import date, timedelta
import hashlib
import json
import math
from pathlib import Path
import stat


CAP = 32.21650314331055
SCALES = (0.0001, 0.001, 0.01)
GROUPS = ("output_parameters", "encoder_parameters")
DAYS = tuple(str(date(1980, 10, 1) + timedelta(days=i)) for i in range(33))
PARAMETER_NAMES = {
    "output_parameters": ["decoder.2.bias", "decoder.2.weight"],
    "encoder_parameters": ["encoder.bias_hh_l0", "encoder.bias_ih_l0",
                           "encoder.weight_hh_l0", "encoder.weight_ih_l0"],
}


class BoundaryEvidenceError(RuntimeError):
    """Stop without changing the old failure or authorizing further fitting."""


def require(condition, message):
    if not condition:
        raise BoundaryEvidenceError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def safe_path(path, root, must_exist=True):
    """Check lexical and resolved scope and every existing parent, including root."""
    path, root = Path(path).absolute(), Path(root).absolute()
    require(".." not in Path(path).parts, "Parent traversal is forbidden")
    require(path.is_relative_to(root), "Evidence path is outside the allowed root")
    for candidate in (path, *path.parents):
        if candidate.exists() or candidate.is_symlink():
            info = candidate.lstat()
            require(not candidate.is_symlink() and not bool(
                getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 1024)),
                "Linked/reparse path is forbidden")
    require(path.resolve().is_relative_to(root.resolve()), "Resolved path is outside the allowed root")
    if must_exist:
        require(path.is_file(), "Saved evidence file is missing")
    return path


def verify_item(item, root, guard=None):
    require(isinstance(item, dict) and set(item) == {"path", "bytes", "sha256"},
            "Malformed saved artifact identity")
    require(type(item["bytes"]) is int and item["bytes"] > 0 and
            isinstance(item["sha256"], str) and len(item["sha256"]) == 64,
            "Malformed saved artifact byte identity")
    path = safe_path(item["path"], root)
    if guard is not None:
        guarded = guard(path)
        if guarded is not None:
            require(Path(guarded).absolute() == path, "Path guard changed the evidence path")
    require(path.stat().st_size == item["bytes"] and sha(path) == item["sha256"],
            "Saved evidence byte identity changed")
    return path


def _torch():
    import torch
    return torch


def tensor_identity(value):
    torch = _torch()
    require(isinstance(value, torch.Tensor) and value.device.type == "cpu", "Expected CPU saved tensor")
    raw = value.detach().contiguous().reshape(-1).numpy().tobytes()
    return {"dtype": str(value.dtype), "shape": list(value.shape), "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest()}


def scalar_identity(value):
    torch = _torch()
    require(isinstance(value, torch.Tensor) and value.numel() == 1 and bool(torch.isfinite(value).all()),
            "Malformed/nonfinite scalar detail")
    return {"dtype": str(value.dtype), "value": float(value),
            "bytes_hex": value.detach().cpu().contiguous().reshape(1).numpy().tobytes().hex()}


def normalized_identity(value):
    torch = _torch()
    if isinstance(value, torch.Tensor):
        return tensor_identity(value)
    if isinstance(value, dict):
        require(len({str(key) for key in value}) == len(value), "Ambiguous snapshot dictionary keys")
        return {str(key): normalized_identity(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [normalized_identity(item) for item in value]
    require(value is None or type(value) in (bool, int, float, str), "Unapproved saved metadata type")
    if isinstance(value, float):
        require(math.isfinite(value), "Nonfinite saved metadata")
    return value


def recursive_digest(value):
    data = json.dumps(normalized_identity(value), sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def strict_equal(first, second, label):
    require(normalized_identity(first) == normalized_identity(second), "Saved identity differs: " + label)


def tensor_equal(first, second, label):
    torch = _torch()
    require(isinstance(first, torch.Tensor) and isinstance(second, torch.Tensor) and
            first.dtype == second.dtype and first.shape == second.shape and torch.equal(first, second),
            "Exact saved tensor values differ: " + label)


def float_tensor(value, shape, label):
    torch = _torch()
    require(isinstance(value, torch.Tensor) and value.device.type == "cpu" and
            value.dtype == torch.float32 and tuple(value.shape) == tuple(shape) and
            bool(torch.isfinite(value).all()), "Malformed/nonfinite saved float32 tensor: " + label)


def finite_saved(value, label):
    torch = _torch()
    if isinstance(value, torch.Tensor):
        require(value.device.type == "cpu" and bool(torch.isfinite(value).all()), "Nonfinite/remote " + label)
    elif isinstance(value, dict):
        for key, item in value.items():
            finite_saved(item, label + "/" + str(key))
    elif isinstance(value, (tuple, list)):
        for index, item in enumerate(value):
            finite_saved(item, label + "/" + str(index))
    elif isinstance(value, float):
        require(math.isfinite(value), "Nonfinite metadata: " + label)


def validate_trajectory(proof, before):
    """Validate 33 dates, saved raw rolling windows and the unchanged projection."""
    torch = _torch()
    require(isinstance(proof, dict) and set(proof) == {"loss", "predictions", "updates", "ledgers"},
            "Malformed saved trajectory fields")
    require(len(proof["predictions"]) == len(proof["updates"]) == 33 and len(proof["ledgers"]) == 32,
            "Registered trajectory needs 33 dates and 32 overwrite ledgers")
    float_tensor(proof["loss"], (), "saved loss")
    ledger = torch.zeros(274, dtype=torch.float32)
    fields = {name: [] for name in ("raw", "proposal", "lower", "upper", "applied", "violation", "branches")}
    previous_raw = None
    for index, current in enumerate(DAYS):
        before("saved_boundary_trajectory_update")
        update, prediction = proof["updates"][index], proof["predictions"][index]
        today = date.fromisoformat(current)
        require(prediction["date"] == update["as_of_date"] == current and prediction["locked"] is True and
                prediction["observation_cutoff"] == str(today - timedelta(days=1)) and
                update["missing"] is False and type(update["cap"]) is float and update["cap"] == CAP,
                "Saved calendar, observation cutoff, missing flag or cap differs")
        require(update["rain_dates"] == [str(today - timedelta(days=99 - lag)) for lag in range(100)],
                "Saved rain-day calendar differs")
        require(isinstance(prediction["state_digest"], str) and len(prediction["state_digest"]) == 64,
                "Saved prediction state identity is malformed")
        float_tensor(prediction["tensor"], (), "prediction")
        for name in ("raw", "proposal", "applied", "violation"):
            float_tensor(update[name], (100,), name)
        raw, proposal = update["raw"], update["proposal"]
        require(bool((raw >= 0).all()), "Saved raw precipitation is negative")
        if previous_raw is not None:
            tensor_equal(raw[:-1], previous_raw[1:], "successive raw rainfall windows")
        previous_raw = raw
        cap = proposal.new_tensor(CAP)
        lower = -torch.minimum(raw, cap)
        upper = torch.full_like(raw, CAP)
        projected = torch.clamp(proposal, min=lower, max=cap)
        violation = (torch.relu(lower - proposal) + torch.relu(proposal - cap)) / cap
        tensor_equal(update["applied"], projected, "unchanged hard projection")
        tensor_equal(update["violation"], violation, "unchanged bound violation")
        require(bool((raw + update["applied"] >= 0).all()), "Projected saved rain is negative")
        ledger = torch.cat((ledger, ledger.new_zeros(1)))
        if index == 32:
            tensor_equal(proposal, ledger[-100:], "terminal proposal holds the prior feasible controls")
            tensor_equal(update["applied"], ledger[-100:], "terminal applied holds the prior feasible controls")
        else:
            ledger = torch.cat((ledger[:-100], projected))
            float_tensor(proof["ledgers"][index], (275 + index,), "overwrite ledger")
            tensor_equal(proof["ledgers"][index], ledger, "full saved overwrite ledger")
            branch = torch.full_like(proposal, 2, dtype=torch.int8)
            branch[proposal < lower] = 0
            branch[proposal == lower] = 1
            branch[proposal == cap] = 3
            branch[proposal > cap] = 4
            for name, value in (("raw", raw), ("proposal", proposal), ("lower", lower), ("upper", upper),
                                ("applied", update["applied"]), ("violation", update["violation"]),
                                ("branches", branch)):
                fields[name].append(value)
    return {name: torch.stack(values) for name, values in fields.items()}


def position_row(fields, row, lag):
    today = date.fromisoformat(DAYS[row])
    item = {"update_index": row, "lag_index": lag, "update_date": DAYS[row],
            "rain_date": str(today - timedelta(days=99 - lag)), "branch": int(fields["branches"][row, lag])}
    for name in ("raw", "proposal", "lower", "upper", "applied", "violation"):
        item[name] = scalar_identity(fields[name][row, lag])
    item["proposal_minus_lower"] = scalar_identity(fields["proposal"][row, lag] - fields["lower"][row, lag])
    item["upper_minus_proposal"] = scalar_identity(fields["upper"][row, lag] - fields["proposal"][row, lag])
    return item


def summarize_trajectory(proof, saved_branches, label, before):
    torch = _torch()
    fields = validate_trajectory(proof, before)
    branches = fields["branches"]
    require(isinstance(saved_branches, torch.Tensor) and saved_branches.dtype == torch.int8 and
            tuple(saved_branches.shape) == (32, 100), "Saved branch shape/type differs")
    tensor_equal(branches, saved_branches, "full saved branch map")
    equal_positions = ((branches == 1) | (branches == 3)).nonzero().tolist()
    interior = branches == 2
    margin = torch.minimum(fields["proposal"] - fields["lower"], fields["upper"] - fields["proposal"])[interior]
    require(not margin.numel() or bool((margin > 0).all()), "Strictly interior margin is not positive")
    summary = {
        "label": label, "denominator": 3200, "counts": {str(i): int((branches == i).sum()) for i in range(5)},
        "array_identity": {name: tensor_identity(value) for name, value in fields.items()},
        "trajectory_sha256": recursive_digest(proof), "calendar_pass": True, "terminal_hold_pass": True,
        "projection_and_violation_pass": True, "overwrite_ledgers_pass": True,
        "equal_boundary_positions": [position_row(fields, row, lag) for row, lag in equal_positions],
        "strict_interior_positions": int(interior.sum()),
        "strict_interior_min_margin": None if not margin.numel() else scalar_identity(margin.min()),
    }
    require(sum(summary["counts"].values()) == 3200, "Branch counts have the wrong denominator")
    return summary, fields


def add_switches(summary, fields, base_fields):
    positions = (fields["branches"] != base_fields["branches"]).nonzero().tolist()
    summary["switched_count"] = len(positions)
    summary["switches"] = [{"update_index": row, "lag_index": lag, "update_date": DAYS[row],
                           "rain_date": position_row(fields, row, lag)["rain_date"],
                           "base_branch": int(base_fields["branches"][row, lag]),
                           "new_branch": int(fields["branches"][row, lag]),
                           "base": position_row(base_fields, row, lag),
                           "perturbed": position_row(fields, row, lag)} for row, lag in positions]


def smooth_conditions(base_fields, plus_fields, minus_fields):
    torch = _torch()
    base = base_fields["branches"]
    conditions = {"base_has_no_equal_boundaries": not bool(((base == 1) | (base == 3)).any()),
                  "plus_branches_equal_base": torch.equal(base, plus_fields["branches"]),
                  "minus_branches_equal_base": torch.equal(base, minus_fields["branches"])}
    return conditions, all(conditions.values())


def reason_for(conditions):
    equality = not conditions["base_has_no_equal_boundaries"]
    switch = not conditions["plus_branches_equal_base"] or not conditions["minus_branches_equal_base"]
    return ("BASE_EQUALITY_AND_SWITCH" if equality and switch else "BASE_EQUALITY_ONLY" if equality else
            "PERTURBATION_SWITCH_ONLY" if switch else "NO_BOUNDARY_BLOCK")


def _write(path, value, output, before):
    before("saved_boundary_write")
    path = safe_path(path, output, must_exist=False)
    require(not path.exists(), "Boundary evidence output cannot be overwritten")
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, ensure_ascii=True, allow_nan=False)
        stream.write("\n")


def run(config, output, before):
    """Rebuild only fixed saved trajectories. A valid caller already owns budget."""
    torch = _torch()
    before("saved_boundary_run")
    require(config["cap"] == CAP and config["parameter_scales"] == list(SCALES),
            "Boundary diagnostic registration differs")
    source_root, output = Path(config["source_gradient_root"]), Path(output)
    require(output.is_dir() and not (output / "boundary_result.json").exists(), "Missing/nonfresh boundary output")
    raw_inventory = config.get("raw_inventory", config.get("raw_artifacts"))
    require(isinstance(raw_inventory, list) and len(raw_inventory) == 60 and
            len({item["path"] for item in raw_inventory}) == 60, "Original 60-artifact inventory differs")
    inventory = {item["path"]: item for item in raw_inventory}
    guard = config.get("read_path_guard")
    for item in raw_inventory:
        before("saved_boundary_inventory_hash")
        verify_item(item, source_root, guard)
    result = config["gradient_result"]
    require(result["artifacts"] == raw_inventory and result["schema"] == "precip_small_sample_gradient_v01" and
            result["parameter_scales"] == list(SCALES) and result["temporary_optimizer_updates_allowed"] == 1 and
            result["seed"] == 1001 and result["scientific_fit_confirmed"] is False,
            "Bound original gradient registration differs")
    records = [item for item in result["completed_records"] if item["label"] == "parameter_direction"]
    require([(x["group"], x["direction_index"]) for x in records] ==
            [(group, index) for group in GROUPS for index in range(3)], "Registered six directions differ")
    require(all(x["usable"] == [False, False, False] and x["status"] == "NO_SMOOTH_ADJACENT_PAIR" and
                x["effective"] is False for x in records), "Original parameter rejection differs")
    loaded = {}

    def load(item):
        before("saved_boundary_safe_weights_load")
        require(item["path"] in inventory and item == inventory[item["path"]], "Artifact absent from original inventory")
        path = verify_item(item, source_root, guard)
        if item["path"] not in loaded:
            value = torch.load(path, map_location="cpu", weights_only=True)
            finite_saved(value, str(path))
            loaded[item["path"]] = value
        before("saved_boundary_loaded")
        return loaded[item["path"]]

    # These identities are explicit configuration members, not filename guesses.
    updated = load(config["only_step_proof"])
    restored = load(config["restoration_proof"])
    bases, base_fields, base_payloads = {}, {}, {}
    for group in GROUPS:
        before("saved_boundary_base")
        item = records[0 if group == GROUPS[0] else 3]["base_proof"]
        payload = load(item)
        require(payload["sorted_parameter_names"] == PARAMETER_NAMES[group] and
                payload["gradient_status"] == "FINITE", "Registered sorted parameter names/status differ")
        require(payload["sizes"] == [payload["snapshot"]["state_dict"][name].numel()
                                     for name in payload["sorted_parameter_names"]], "Registered parameter sizes differ")
        for key in ("state_dict", "optimizer", "modes"):
            strict_equal(payload["snapshot"][key], updated[key], "post-only-step base " + key)
        strict_equal(payload["snapshot"], restored["before"], "original restoration before")
        strict_equal(payload["snapshot"], restored["after"], "original restoration after")
        summary, fields = summarize_trajectory(payload["trajectory"], payload["branches"], group + "_base", before)
        bases[group] = {"proof": item, "snapshot_sha256": recursive_digest(payload["snapshot"]),
                        "trajectory": summary}
        base_fields[group], base_payloads[group] = fields, payload
    strict_equal(base_payloads[GROUPS[0]]["snapshot"], base_payloads[GROUPS[1]]["snapshot"], "two full base snapshots")
    strict_equal(base_payloads[GROUPS[0]]["trajectory"], base_payloads[GROUPS[1]]["trajectory"], "two full base trajectories")
    directions = []
    for record in records:
        before("saved_boundary_direction")
        group, index = record["group"], record["direction_index"]
        base = base_payloads[group]
        require(record["base_proof"] == bases[group]["proof"] and record["gradient_status"] == "FINITE",
                "Direction base identity/status differs")
        require([x["delta"] for x in record["scales"]] == list(SCALES), "Registered three scales differ")
        direction_summary = {"group": group, "direction_index": index, "base_proof": record["base_proof"],
                             "sorted_parameter_names": base["sorted_parameter_names"], "sizes": base["sizes"],
                             "direction_identity": None, "scales": []}
        saved_direction = None
        for delta, item in zip(SCALES, record["scales"], strict=True):
            before("saved_boundary_scale")
            payload = load(item["proof"])
            require(payload["delta"] == delta and payload["sorted_parameter_names"] == base["sorted_parameter_names"] and
                    payload["sizes"] == base["sizes"], "Saved direction scale/name/size differs")
            float_tensor(payload["direction"], (sum(base["sizes"]),), "saved parameter direction")
            if saved_direction is None:
                saved_direction = payload["direction"]
                direction_summary["direction_identity"] = tensor_identity(saved_direction)
            else:
                strict_equal(saved_direction, payload["direction"], "same registered direction across scales")
            tensor_equal(payload["base_branches"], base_fields[group]["branches"], "bound saved base branches")
            parts, arrays = {}, {}
            for side in ("plus", "minus"):
                before("saved_boundary_perturbation")
                parts[side], arrays[side] = summarize_trajectory(payload[side], payload[side + "_branches"],
                                                               f"{group}_{index}_{delta}_{side}", before)
                tensor_equal(arrays[side]["raw"], base_fields[group]["raw"], "perturbation unmodified raw input")
                add_switches(parts[side], arrays[side], base_fields[group])
            conditions, smooth = smooth_conditions(base_fields[group], arrays["plus"], arrays["minus"])
            require(type(payload["smooth"]) is bool and type(item["smooth"]) is bool and
                    payload["smooth"] == item["smooth"] == smooth == record["usable"][list(SCALES).index(delta)] and
                    smooth is False, "Old smooth=false is not explained by saved branch conditions")
            require(payload["automatic"] == record["automatic"] and
                    payload["finite_difference"] == record["finite_differences"][list(SCALES).index(delta)],
                    "Saved original derivatives differ from direction events")
            direction_summary["scales"].append({"delta": delta, "proof": item["proof"], "conditions": conditions,
                                                 "smooth_reconstructed": smooth, "smooth_saved": item["smooth"],
                                                 "reason": reason_for(conditions), "plus": parts["plus"],
                                                 "minus": parts["minus"]})
        directions.append(direction_summary)
    before("saved_boundary_end_inventory_hash")
    for item in raw_inventory:
        verify_item(item, source_root, guard)
    report = {"schema": "precip_saved_gradient_boundary_result_v01", "status": "SAVED_BOUNDARY_DETAILS_COMPLETE",
              "pass": True, "original_gradient_status": "CONFIRMED_BLOCK", "later_stage_authorized": False,
              "scientific_fit_or_forecast_claim": False, "model_inference": False, "optimizer_steps": 0,
              "regenerated_parameter_directions": False, "raw_inventory": raw_inventory, "bases": bases,
              "base_trajectories_strict_equal": True, "directions": directions, "raw_inventory_unchanged": True,
              "registered_directions": 6, "registered_scales_per_direction": 3, "saved_perturbed_trajectories": 36,
              "interpretation_limit": "Boundary equality or finite perturbation switching explains the old rejection only; "
              "it does not establish total-map nondifferentiability, incorrect automatic gradients, fitting ability, or forecast benefit."}
    _write(output / "boundary_result.json", report, output, before)
    return report
