"""Read-only relocated-result audit; original Linux locks are never rewritten.

Only the new report directory is writable. Scoring reads require complete local
validation of all 72 selections. Saved trajectories are audited, not replayed.
"""

import argparse
import csv
from dataclasses import dataclass
from datetime import date, timedelta
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import struct
import sys
from types import MappingProxyType


BASINS = ("01487000", "12040500", "09312600", "08198500", "03078000", "05362000", "08267500", "07145700")
METHODS, SEEDS = ("rain", "flow", "historical"), (1001, 1002, 1003)
PENALTIES = {"rain": .0001, "flow": .001, "historical": .0001}
DATES = {"warmup": (date(1980, 1, 1), date(1980, 9, 30)),
         "fit": (date(1980, 10, 1), date(1984, 9, 30)),
         "select": (date(1984, 10, 1), date(1985, 9, 30)),
         "score": (date(1985, 10, 1), date(1989, 9, 30))}
WEATHER_NAMES = ("PRCP(mm/day)", "Tmin(C)", "Tmax(C)", "SRAD(W/m2)", "Vp(Pa)")
CFS_TO_MM = 28316846.592 * 86400. / 1_000_000.
TRANSPORT_SHA256 = "ee095ba61daccf73f30eeb6b2b923ba8706762eee3ed523e399bdbd78d50b051"
_TRANSPORT, _ISSUED = None, {}


def transport():
    global _TRANSPORT
    if _TRANSPORT is None:
        path = Path(__file__).with_name("eight_basin_results_transport_v01.py")
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != TRANSPORT_SHA256:
            raise PermissionError("The independently sealed result transport helper changed")
        spec = importlib.util.spec_from_file_location("eight_basin_readonly_transport", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _TRANSPORT = module
    return _TRANSPORT


def canonical_digest(value):
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()
    return hashlib.sha256(raw).hexdigest()


def dates_between(start, end):
    return tuple(start + timedelta(days=index) for index in range((end - start).days + 1))


def float32(value):
    return struct.unpack("f", struct.pack("f", float(value)))[0]


def file_sha(path):
    digest = hashlib.sha256()
    with transport().no_link_ancestors(path).open("rb") as handle:
        for raw in iter(lambda: handle.read(transport().MAX_CHUNK), b""):
            digest.update(raw)
    return digest.hexdigest()


def json_file(path):
    return transport().parse_json(transport().no_link_ancestors(path).read_bytes())


class PathMap:
    def __init__(self, original_root, recovered_root, logical_training_root):
        t = transport()
        original_root = t.registered_root_name(original_root)
        expected = original_root + "/runtime/training"
        if (not PurePosixPath(original_root).is_absolute() or
                str(PurePosixPath(logical_training_root)) != logical_training_root or logical_training_root != expected):
            raise PermissionError("The Linux training root differs from the one fixed recovery mapping")
        self.original_root, self.logical_training_root = original_root, expected
        self.recovered_root = t.no_link_ancestors(recovered_root).resolve(strict=True)
        self.training_root = t.no_link_ancestors(self.recovered_root / "runtime/training").resolve(strict=True)
        if not self.training_root.is_relative_to(self.recovered_root) or not self.training_root.is_dir():
            raise PermissionError("Mapped training directory escaped its local recovery root")

    def training(self, logical_root, relative):
        if (logical_root != self.logical_training_root or not PurePosixPath(logical_root).is_absolute() or
                PurePosixPath(logical_root).as_posix() != logical_root):
            raise PermissionError("An arbitrary external training root cannot be remapped")
        return transport().safe_path(self.training_root, relative)

    def restored(self, relative):
        return transport().safe_path(self.recovered_root, relative)


class SourceAnchor:
    """External inventory and receipt-index hashes anchor each original fragment."""
    def __init__(self, manifest_path, pieces_root, expected_receipt, receipt_index_path, receipt_index_sha256):
        t = transport()
        wrapper = t.load_manifest(manifest_path)
        keys = ("sequence", "mailbox_commit", "git_blob_sha1", "receipt_sha256")
        if set(expected_receipt) != set(keys) or any(wrapper["receipt_identity"][key] != expected_receipt[key] for key in keys):
            raise PermissionError("Inventory differs from the externally pinned original Git receipt")
        if not t.HEX64.fullmatch(receipt_index_sha256) or file_sha(receipt_index_path) != receipt_index_sha256:
            raise PermissionError("Receipt index differs from its externally fixed SHA256")
        index = json_file(receipt_index_path)
        self.value, self.provenance = wrapper["inventory"], wrapper["receipt_identity"]
        if index["inventory_sha256"] != self.value["inventory_sha256"]:
            raise PermissionError("Receipt index belongs to another inventory")
        self.requests, self.receipts, self._cache = t.requests_for(self.value), {}, {}
        self.cache = MappingProxyType(self._cache)
        for item in index["receipts"]:
            number = item["request_index"]
            if type(number) is not int or not 0 <= number < len(self.requests) or number in self.receipts:
                raise PermissionError("Receipt index has missing, duplicate or illegal request identities")
            if (type(item["sequence"]) is not int or item["sequence"] <= 0 or
                    not t.HEX40.fullmatch(item["mailbox_commit"]) or not t.HEX40.fullmatch(item["git_blob_sha1"]) or
                    not t.HEX64.fullmatch(item["receipt_sha256"])):
                raise PermissionError("Receipt index has an invalid fixed Git identity")
            self.receipts[number] = item
        if set(self.receipts) != set(range(len(self.requests))):
            raise PermissionError("Every fragment request needs an externally fixed receipt identity")
        self.pieces_root = t.no_link_ancestors(pieces_root).resolve(strict=True)
        self.receipt_index_sha256 = receipt_index_sha256

    def _members(self, index):
        if index not in self._cache:
            t, proof, request = transport(), self.receipts[index], self.requests[index]
            path = t.safe_path(self.pieces_root, f"receipt_blobs/{proof['git_blob_sha1']}.txt")
            envelope, verified = t.extract_receipt(path, proof["sequence"], proof["git_blob_sha1"], proof["mailbox_commit"])
            if verified["receipt_sha256"] != proof["receipt_sha256"] or any(envelope.get(key) != request[key]
                    for key in ("schema", "root", "job_id", "index", "inventory_sha256", "request_sha256")):
                raise PermissionError("Original fragment receipt differs from its external anchor")
            if envelope.get("kind") != "fragments" or len(envelope["members"]) != len(request["members"]):
                raise PermissionError("Original fragment receipt has a different population")
            records = []
            for actual, expected in zip(envelope["members"], request["members"], strict=True):
                if any(actual[key] != expected[key] for key in ("name", "offset", "length", "stat")):
                    raise PermissionError("Original fragment has different fixed metadata")
                if not t.HEX64.fullmatch(actual["chunk_sha256"]):
                    raise PermissionError("Original fragment hash is invalid")
                records.append(tuple(actual[key] for key in ("name", "offset", "length", "chunk_sha256")))
            self._cache[index] = tuple(records)
        return tuple(dict(zip(("name", "offset", "length", "chunk_sha256"), item, strict=True)) for item in self._cache[index])

    def verify(self, mapping, name):
        t = transport()
        if (self.value["root"] != mapping.original_root or self.value["local_path_mapping"]["logical_training_root"] !=
                mapping.logical_training_root or name not in self.value["files"]):
            raise PermissionError("Restored file is outside its original fixed inventory")
        path, digest = mapping.restored(name), hashlib.sha256()
        before = t.file_stat(path)
        expected = self.value["files"][name]
        if before["bytes"] != expected["bytes"]:
            raise PermissionError("Restored file length differs from its original inventory")
        chunks = [member for index, request in enumerate(self.requests) if any(item["name"] == name for item in request["members"])
                  for member in self._members(index) if member["name"] == name]
        with path.open("rb") as handle:
            for member in chunks:
                if handle.tell() != member["offset"]:
                    raise PermissionError("Fragments are missing, overlapping or reordered")
                raw = handle.read(member["length"])
                if len(raw) != member["length"] or t.digest(raw) != member["chunk_sha256"]:
                    raise PermissionError("Restored bytes differ from their fixed original receipt fragment")
                digest.update(raw)
            if handle.read(1):
                raise PermissionError("Restored file has extra unregistered bytes")
        if t.file_stat(path) != before:
            raise PermissionError("Restored file changed while being independently read")
        actual = digest.hexdigest()
        binding = expected["source_binding"]
        if binding and actual != binding["sha256"]:
            raise PermissionError("Restored file differs from its original run digest")
        return actual


def require_completed_run(mapping, anchor):
    """An incomplete preservation inventory cannot authorize a scientific audit."""
    value = anchor.value
    expected = {"predictions": 88, "rain_ledgers": 48, "selected_checkpoints": 72}
    actual = {
        "predictions": sum(name.startswith("runtime/scoring/basins/") and name.endswith("/predictions.csv") for name in value["files"]),
        "rain_ledgers": sum(name.startswith("runtime/scoring/basins/") and name.endswith("/rain_versions.csv") for name in value["files"]),
        "selected_checkpoints": sum(name.startswith("runtime/training/basins/") and name.endswith("/selected.pt") for name in value["files"])}
    if (value["job"]["state"] != "COMPLETED" or value["job"]["exit_code"] != "0:0" or
            value["expected_file_counts_complete"] is not True or value["counts"] != expected or actual != expected):
        raise PermissionError("Complete successful job evidence and all original 88/48/72 artifacts are required before scoring reads")
    markers = {}
    for name in ("runtime/job_complete.json", "runtime/scoring/complete.json"):
        markers[name] = anchor.verify(mapping, name)
        item = json_file(mapping.restored(name))
        if item.get("success") is not True or (name.endswith("scoring/complete.json") and item.get("stage") != "score"):
            raise PermissionError("Original job and scoring success markers are required before scoring reads")
    return {"job": dict(value["job"]), "actual_inventory_counts": actual, "original_success_marker_sha256": markers}


@dataclass
class InputSeries:
    dates: tuple
    weather: object
    observations: dict
    score_identity: dict


def expected_shapes(kind):
    result = {"encoder.weight_ih_l0": [96, 11], "encoder.weight_hh_l0": [96, 32],
              "encoder.bias_ih_l0": [96], "encoder.bias_hh_l0": [96], "decoder.0.weight": [32, 39],
              "decoder.0.bias": [32], "decoder.2.weight": [1, 32], "decoder.2.bias": [1], "cap": []}
    if kind == "flow":
        result["flow_std"] = []
    return result


def validate_checkpoint(actual, fit, scaling):
    expected = {"kind": fit["kind"], "basin": fit["basin"], "seed": fit["seed"], "penalty": fit["penalty"],
                "epoch": fit["best_epoch"], "validation_nse": fit["validation_nse"],
                "input_identity_sha256": fit["input_identity_sha256"], "contract_sha256": fit["contract_sha256"]}
    if (actual["metadata"] != expected or actual["parameter_count"] != 5633 or actual["finite"] is not True or
            actual["shapes"] != expected_shapes(fit["kind"]) or type(expected["epoch"]) is not int or
            not 1 <= expected["epoch"] <= 60 or not math.isfinite(float(expected["validation_nse"]))):
        raise PermissionError("Actual checkpoint method/seed/epoch/value/tensor metadata differs from the locked fit")
    buffers = {"cap": float32(5. * scaling["flow_std"] if fit["kind"] == "flow" else scaling["cap"])}
    if fit["kind"] == "flow":
        buffers["flow_std"] = float32(scaling["flow_std"])
    if actual["buffers"] != buffers:
        raise PermissionError("Actual checkpoint buffers differ from its fitting-only scaling")


def fit_scaling(series):
    import numpy as np
    fit = dates_between(*DATES["fit"])
    values = np.asarray([series.observations[day] for day in fit], dtype=np.float64)
    positions = {day: index for index, day in enumerate(series.dates)}
    weather = np.asarray([series.weather[positions[day]] for day in fit], dtype=np.float32)
    valid, wet = values[np.isfinite(values)], weather[weather[:, 0] >= .1, 0]
    if (weather.shape != (len(fit), 5) or not np.isfinite(weather).all() or (weather[:, 0] < 0).any() or
            len(valid) < 2 or np.std(valid) <= 0 or not len(wet)):
        raise RuntimeError("Fitting inputs have undefined scaling")
    std = weather.std(axis=0)
    return {"weather_mean": weather.mean(axis=0).tolist(), "weather_std": np.where(std > 0, std, 1.).tolist(),
            "flow_mean": float(valid.mean()), "flow_std": float(valid.std()),
            "cap": float(np.quantile(wet, .99, method="linear")), "start": str(fit[0]), "end": str(fit[-1])}


def validate_epochs(mapping, anchor, fit, observations):
    count, best, best_epoch = fit["epochs"], -math.inf, None
    if type(count) is not int or not 1 <= count <= 60:
        raise PermissionError("Fitting epoch count escaped the fixed recipe")
    parent = mapping.training(mapping.logical_training_root, fit["checkpoint"]).parent
    names = {path.name for path in parent.iterdir() if path.name.startswith("epoch_")}
    if names != {f"epoch_{epoch:03d}.json" for epoch in range(1, count + 1)}:
        raise PermissionError("Fitting epoch history is missing, extra or noncontiguous")
    days = dates_between(*DATES["fit"])
    for epoch in range(1, count + 1):
        relative = PurePosixPath(fit["checkpoint"]).parent / f"epoch_{epoch:03d}.json"
        name = "runtime/training/" + relative.as_posix()
        anchor.verify(mapping, name)
        item = json_file(mapping.restored(name))
        score = item["validation_nse"]
        better = score > best
        if item["epoch"] != epoch or not math.isfinite(float(score)) or item["selected"] is not better:
            raise PermissionError("Epoch history violates strict improvement or earliest tie selection")
        if better:
            best, best_epoch = score, epoch
        if epoch < count and (epoch == 60 or epoch - best_epoch >= 10):
            raise PermissionError("Fitting continued after the fixed patience stop")
        expected_segments = [(start, min(start + 32, len(days)), start + 32 if start + 32 < len(days) else None)
                             for start in range(0, len(days), 32)]
        if len(item["segments"]) != len(expected_segments):
            raise PermissionError("Fitting epoch has an incomplete 32-day segment population")
        terms, supervised = 0, False
        for segment, (start, stop, closing) in zip(item["segments"], expected_segments, strict=True):
            paid = list(range(start + int(start > 0), stop)) + ([] if closing is None else [closing])
            finite = sum(math.isfinite(observations[days[index]]) for index in paid)
            if (segment["start"] != str(days[start]) or segment["stop"] != str(days[stop - 1]) or
                    segment["closing"] != (None if closing is None else str(days[closing])) or segment["flow_terms"] != finite or
                    segment["missing_closing_followup"] != int(closing is not None and not math.isfinite(observations[days[closing]]))):
                raise PermissionError("Fitting segment calendar, closing supervision or valid-flow count differs")
            if ((segment["loss"] is not None and not math.isfinite(float(segment["loss"]))) or
                    not math.isfinite(float(segment["gradient_norm"])) or segment["gradient_norm"] < 0 or
                    type(segment["nonzero_grad_parameters"]) is not int or segment["nonzero_grad_parameters"] < 0):
                raise PermissionError("Fitting epoch contains invalid loss or gradient evidence")
            if segment["regularization_only"] != (segment["differentiable"] and not segment["flow_supervised"]):
                raise PermissionError("Gradient supervision label contradicts the fitting segment")
            supervised |= bool(segment["flow_supervised"] and segment["differentiable"] and finite > 0 and
                               segment["nonzero_grad_parameters"] > 0 and segment["gradient_norm"] > 0)
            terms += segment["flow_terms"]
        if terms != sum(math.isfinite(observations[day]) for day in days) or not supervised:
            raise PermissionError("Fitting epoch lacks legal nonzero supervision or double-counted flow labels")
    if count != 60 and count - best_epoch != 10:
        raise PermissionError("Fitting stopped before the fixed 60-epoch or patience endpoint")
    if best_epoch != fit["best_epoch"] or best != fit["validation_nse"]:
        raise PermissionError("Selected checkpoint is not the earliest best epoch in complete history")
    return {"epochs": count, "best_epoch": best_epoch, "validation_nse": best, "segments_per_epoch": 46}


@dataclass(frozen=True, init=False)
class ScorePermit:
    contract: object
    mapping: object
    anchor: object
    selections: dict
    inputs: dict
    global_sha256: str
    identity_report: dict
    frozen_stats: dict
    watched_stats: dict
    frozen_paths: dict
    watched_directories: tuple


def validate_all(contract, mapping, anchor, global_sha256, services):
    t = transport()
    if tuple(contract.basins) != BASINS or tuple(contract.seeds) != SEEDS or dict(contract.penalties) != PENALTIES:
        raise PermissionError("Offline validation requires the original complete eight-basin recipe")
    completion = require_completed_run(mapping, anchor) if isinstance(anchor, SourceAnchor) else None
    lock_name = "runtime/locked/global_selection_locked.json"
    if not t.HEX64.fullmatch(global_sha256) or anchor.verify(mapping, lock_name) != global_sha256:
        raise PermissionError("Global selection differs from its externally fixed original digest")
    lock = json_file(mapping.restored(lock_name))
    if (lock["contract_sha256"] != contract.sha256 or tuple(lock["basins"]) != BASINS or
            lock["checkpoint_count"] != 72 or lock["score_observations_read"] is not False or
            len(lock["selections"]) != 8 or tuple(item["basin"] for item in lock["selections"]) != BASINS):
        raise PermissionError("All original 72 selections must be complete before any scoring value is read")
    selections, inputs, epochs, watched = {}, {}, {}, {}
    frozen = {lock_name: t.file_stat(mapping.restored(lock_name))}
    if completion is not None:
        for name in ("runtime/job_complete.json", "runtime/scoring/complete.json"):
            frozen[name] = t.file_stat(mapping.restored(name))
    for item in lock["selections"]:
        basin, relative = item["basin"], item["selection_file"]
        if relative != f"basins/{basin}/selection_locked.json":
            raise PermissionError("A selection path is bound to another basin")
        path = mapping.training(item["training_root"], relative)
        name = "runtime/training/" + relative
        if anchor.verify(mapping, name) != item["selection_sha256"]:
            raise PermissionError("Original basin selection bytes changed")
        selection = json_file(path)
        if (canonical_digest(selection) != item["selection_identity"] or selection["basin"] != basin or
                selection["contract_sha256"] != contract.sha256 or selection["score_observations_read"] is not False or
                selection["training_root"] != mapping.logical_training_root):
            raise PermissionError("Original selection identity or Linux training root changed")
        frozen[name] = t.file_stat(path)
        gate_relative = selection["input_gate"]
        if gate_relative != f"basins/{basin}/input_gate.json":
            raise PermissionError("Input gate points to a different basin")
        gate_path = mapping.training(selection["training_root"], gate_relative)
        gate_name = "runtime/training/" + gate_relative
        if anchor.verify(mapping, gate_name) != selection["input_gate_sha256"]:
            raise PermissionError("Original input gate bytes changed")
        gate = json_file(gate_path)
        if (canonical_digest(gate) != selection["input_identity_sha256"] or gate["basin"] != basin or
                gate.get("pass") is not True or gate["contract_sha256"] != contract.sha256 or
                gate["sources"] != selection["sources"] or gate["model_identity"] != selection["model_identity"]):
            raise PermissionError("Input/static/model/source identity differs from original selection")
        if len(gate["sources"]) != 42 or services.verify_sources(contract.repo, gate["sources"]) != gate["sources"]:
            raise PermissionError("The exact sealed 42-file source inventory changed")
        for relative_source in gate["sources"]:
            source = t.safe_path(contract.repo, relative_source)
            watched[str(source)] = t.file_stat(source)
        if hasattr(contract, "data_root"):
            for group in gate["canonical_inputs"].values():
                for block in group.values():
                    source = t.safe_path(contract.data_root, block["source"])
                    watched[str(source)] = t.file_stat(source)
            for filename in ("camels_clim.txt", "camels_topo.txt", "camels_vege.txt", "camels_soil.txt", "camels_geol.txt", "camels_name.txt"):
                source = t.safe_path(contract.data_root, "camels_attributes_v2.0/" + filename)
                watched[str(source)] = t.file_stat(source)
        if hasattr(contract, "model_root"):
            for model_name in gate["model_identity"]:
                source = t.safe_path(contract.model_root, model_name)
                watched[str(source)] = t.file_stat(source)
        for control in (getattr(contract, "roster_lock", None), getattr(contract, "path", None)):
            if control is not None:
                source = t.no_link_ancestors(control)
                watched[str(source)] = t.file_stat(source)
        series = services.fresh_fit_select(contract, basin, gate)
        if (tuple(series.dates) != dates_between(DATES["warmup"][0], DATES["select"][1]) or
                series.score_identity.get("pre_score_gate_sha256") != canonical_digest(gate)):
            raise PermissionError("Fitting input reader escaped the pre-scoring calendar")
        if fit_scaling(series) != selection["scaling"]:
            raise PermissionError("Selected normalization differs from independently reconstructed fitting inputs")
        fits, found = selection["selected"], set()
        if len(fits) != 9:
            raise PermissionError("Each basin must contain exactly nine original complete fits")
        for fit in fits:
            pair = (fit["kind"], fit["seed"])
            if pair not in {(kind, seed) for kind in METHODS for seed in SEEDS} or pair in found:
                raise PermissionError("Repeated, absent or relabelled method/seed combination")
            found.add(pair)
            if (fit["penalty"] != PENALTIES[fit["kind"]] or fit["complete"] is not True or fit["basin"] != basin or
                    fit["contract_sha256"] != contract.sha256 or fit["input_identity_sha256"] != selection["input_identity_sha256"] or
                    fit["model_tensor_sha256"] != selection["model_tensor_sha256"]):
                raise PermissionError("Fit was not completed under its exact original contract and input identity")
            prefix = f"basins/{basin}/fits/{fit['kind']}/seed_{fit['seed']}"
            if fit["checkpoint"] != prefix + "/selected.pt" or fit["fit_summary"] != prefix + "/fit_summary.json":
                raise PermissionError("Fit artifacts point to another method or seed")
            checkpoint = mapping.training(selection["training_root"], fit["checkpoint"])
            checkpoint_name = "runtime/training/" + fit["checkpoint"]
            if anchor.verify(mapping, checkpoint_name) != fit["checkpoint_sha256"]:
                raise PermissionError("The actual selected checkpoint changed")
            summary_name = "runtime/training/" + fit["fit_summary"]
            anchor.verify(mapping, summary_name)
            summary = json_file(mapping.training(selection["training_root"], fit["fit_summary"]))
            if (canonical_digest(summary) != fit["fit_summary_identity"] or
                    summary != {key: value for key, value in fit.items() if key not in ("fit_summary", "fit_summary_identity")}):
                raise PermissionError("Actual fit summary contents differ from the original locked fit")
            validate_checkpoint(services.checkpoint_metadata(checkpoint), fit, selection["scaling"])
            epochs[f"{basin}/{fit['kind']}/{fit['seed']}"] = validate_epochs(mapping, anchor, fit, series.observations)
            for epoch in range(1, fit["epochs"] + 1):
                epoch_name = "runtime/training/" + prefix + f"/epoch_{epoch:03d}.json"
                frozen[epoch_name] = t.file_stat(mapping.restored(epoch_name))
            frozen[checkpoint_name] = t.file_stat(checkpoint)
            frozen[summary_name] = t.file_stat(mapping.restored(summary_name))
        frozen[gate_name] = t.file_stat(gate_path)
        selections[basin], inputs[basin] = selection, series
    # This capability exists only after every basin, every fit and every input passed.
    permit = object.__new__(ScorePermit)
    report = {"identity_verified": True, "checkpoint_count": 72, "method_seed_combinations_per_basin": 9,
              "source_file_count": 42, "global_lock_sha256": global_sha256, "epochs": epochs,
              "original_json_roots_preserved": True, "completed_run_evidence": completion}
    frozen_paths = {name: str(mapping.restored(name)) for name in frozen}
    watched_directories = tuple(sorted({str(parent) for path in list(frozen_paths.values()) + list(watched)
                                       for parent in Path(path).parents}))
    for key, value in {"contract": contract, "mapping": mapping, "anchor": anchor, "selections": selections,
                       "inputs": inputs, "global_sha256": global_sha256, "identity_report": report,
                       "frozen_stats": frozen, "watched_stats": watched,
                       "frozen_paths": frozen_paths, "watched_directories": watched_directories}.items():
        object.__setattr__(permit, key, value)
    _ISSUED[id(permit)] = (permit, contract, mapping, anchor, _permit_binding(permit))
    return permit


def source_snapshot(repo):
    """Independently enumerate the same sealed source set without importing it."""
    t = transport()
    repo = t.no_link_ancestors(repo).resolve(strict=True)
    stem = repo / "src/precip_input_assimilation"
    files = list((stem / "dynamic_filter").glob("*.py"))
    files += list((stem / "dynamic_filter_multibasin").glob("*.py"))
    files += list((stem / "scripts").glob("*dynamic_filter*.py"))
    files += list((stem / "tests").glob("test_dynamic_filter*.py"))
    files += [stem / "selfrule" / name for name in ("data.py", "model.py")]
    files += list((stem / "hpc").glob("dynamic_filter_eight_basins*"))
    files += [stem / "configs/dynamic_filter_eight_basins_v01.json"]
    files += [repo / name for name in ("neuralhydrology/modelzoo/cudalstm.py", "neuralhydrology/modelzoo/inputlayer.py",
        "neuralhydrology/modelzoo/head.py", "neuralhydrology/modelzoo/__init__.py", "neuralhydrology/datasetzoo/basedataset.py",
        "neuralhydrology/datasetzoo/camelsus.py", "neuralhydrology/utils/config.py")]
    result = {}
    for path in sorted(set(files)):
        relative = path.relative_to(repo).as_posix()
        result[relative] = file_sha(t.safe_path(repo, relative))
    return result


def _modules(repo):
    import importlib
    repo = transport().no_link_ancestors(repo).resolve(strict=True)
    sys.path[:0] = [str(repo / "src"), str(repo)]
    modules = {}
    for name in ("identity", "contract", "data", "audit"):
        module = importlib.import_module("precip_input_assimilation.dynamic_filter_multibasin." + name)
        location = transport().no_link_ancestors(module.__file__).resolve(strict=True)
        if not location.is_relative_to(repo):
            raise PermissionError("Frozen helper was imported outside its explicitly registered repository")
        modules[name] = module
    return modules


class ProductionServices:
    def __init__(self, repo):
        self.repo, self.modules = repo, None

    def verify_sources(self, repo, expected):
        actual = source_snapshot(repo)
        if actual != expected or len(actual) != 42:
            raise PermissionError("Original complete source inventory differs")
        self.modules = _modules(repo)
        return actual

    def fresh_fit_select(self, contract, basin, gate):
        # Reject registered metadata paths that traverse a reparse point before
        # using the unchanged pre-scoring readers.
        for group in gate["canonical_inputs"].values():
            for block in group.values():
                transport().safe_path(contract.data_root, block["source"])
        for filename in ("camels_clim.txt", "camels_topo.txt", "camels_vege.txt", "camels_soil.txt", "camels_geol.txt"):
            transport().safe_path(contract.data_root, "camels_attributes_v2.0/" + filename)
        inputs = self.modules["data"].load_inputs(contract, basin, end=DATES["select"][1])
        fresh = self.modules["identity"].make_input_identity(contract, basin, inputs=inputs, sources=source_snapshot(contract.repo))
        if canonical_digest(fresh) != canonical_digest(gate):
            raise PermissionError("Original fitting weather/flow/static/area/model identity changed")
        observations = {day: float(value) for block in inputs.flow_blocks.values()
                        for day, value in zip(block.dates, block.values, strict=True)}
        return InputSeries(inputs.dates, inputs.weather, observations,
                           {"pre_score_gate_sha256": canonical_digest(fresh)})

    def checkpoint_metadata(self, path):
        import torch
        payload = torch.load(path, map_location="cpu", weights_only=True)
        keys = ("kind", "basin", "seed", "penalty", "epoch", "validation_nse", "input_identity_sha256", "contract_sha256")
        if not isinstance(payload, dict) or not isinstance(payload.get("state_dict"), dict) or any(key not in payload for key in keys):
            raise PermissionError("Checkpoint lacks its complete actual locked metadata")
        state = payload["state_dict"]
        if any(not isinstance(value, torch.Tensor) or value.dtype != torch.float32 for value in state.values()):
            raise PermissionError("Checkpoint state contains unsupported nonfloating tensors")
        buffers = {name: float(state[name]) for name in ("cap", "flow_std") if name in state and state[name].numel() == 1}
        return {"metadata": {key: payload[key] for key in keys},
                "parameter_count": sum(value.numel() for name, value in state.items() if name not in ("cap", "flow_std")),
                "finite": all(bool(torch.isfinite(value).all()) for value in state.values()),
                "shapes": {name: list(value.shape) for name, value in state.items()}, "buffers": buffers}

    def score_inputs(self, permit, basin):
        return read_permitted_inputs(permit, basin)


def canonical_series(basin, phase, days, names, values, precision):
    digest = hashlib.sha256()
    digest.update(f"basin={basin};phase={phase};start={days[0]};end={days[-1]}\n".encode())
    digest.update(("date," + ",".join(names) + "\n").encode())
    for day, row in zip(days, values, strict=True):
        tokens = [format(float(value), f".{precision}g") if math.isfinite(float(value)) else "NA" for value in row]
        digest.update((str(day) + "," + ",".join(tokens) + "\n").encode())
    return digest.hexdigest()


def _raw_permission(permit, path, basin, start, end, kind):
    require_permit(permit, basin)
    lower = DATES["warmup"][0] if kind == "weather" else DATES["fit"][0]
    if (basin not in BASINS or not isinstance(start, date) or not isinstance(end, date) or
            not lower <= start <= end <= DATES["score"][1]):
        raise PermissionError("Raw input request escaped the fixed permitted basin/date bounds")
    root = transport().no_link_ancestors(permit.contract.data_root).resolve(strict=True)
    target = transport().no_link_ancestors(path).resolve(strict=True)
    if not target.is_relative_to(root):
        raise PermissionError("Raw input is outside its explicitly registered local data root")
    gate_name = "runtime/training/" + permit.selections[basin]["input_gate"]
    permit.anchor.verify(permit.mapping, gate_name)
    gate = json_file(permit.mapping.training(permit.mapping.logical_training_root, permit.selections[basin]["input_gate"]))
    if canonical_digest(gate) != permit.selections[basin]["input_identity_sha256"]:
        raise PermissionError("Raw input permission no longer has its original locked gate")
    group = "weather" if kind == "weather" else "flow"
    expected = transport().safe_path(root, gate["canonical_inputs"][group]["fit"]["source"])
    if target != expected.resolve(strict=True):
        raise PermissionError("Raw input belongs to another source path or basin")
    return gate["area_identity"]["forcing_area_m2"]


def weather_raw(path, basin, start, end, *, permit=None):
    """Date checks precede value parsing, including the first future row."""
    _raw_permission(permit, path, basin, start, end, "weather")
    path = transport().no_link_ancestors(path)
    rows, days, lines = [], [], []
    with path.open(encoding="utf-8") as handle:
        latitude, elevation, area_token = handle.readline().strip(), handle.readline().strip(), handle.readline().strip()
        area, header = float(area_token), tuple(handle.readline().split())
        if (not math.isfinite(area) or area <= 0 or tuple(header[:4]) != ("Year", "Mnth", "Day", "Hr") or
                len(header) != len(set(header)) or any(name not in header for name in WEATHER_NAMES)):
            raise PermissionError("Weather header, units or area differs from the approved reader")
        columns, previous = tuple(header.index(name) for name in WEATHER_NAMES), None
        for line in handle:
            fields = line.split()
            if len(fields) < 4:
                raise RuntimeError("Weather row has malformed date fields")
            current = date(*(int(value) for value in fields[:3]))
            if previous is not None and current <= previous:
                raise RuntimeError("Weather dates are not strictly increasing")
            previous = current
            if current < start:
                continue
            if current > end:
                break
            if len(fields) != len(header):
                raise RuntimeError("Weather row count differs from its registered columns")
            row = [float32(fields[column]) for column in columns]
            if not all(math.isfinite(value) for value in row) or row[0] < 0:
                raise RuntimeError("Weather contains invalid values or negative precipitation")
            days.append(current)
            rows.append(row)
            lines.append(" ".join(fields) + "\n")
            if current == end:
                break
    if tuple(days) != dates_between(start, end):
        raise RuntimeError("Weather does not cover the complete permitted daily grid")
    mapping = {"header": list(header), "columns_zero_based": list(columns), "weather_names": list(WEATHER_NAMES),
               "area_token_m2": area_token, "latitude_header": latitude, "elevation_header": elevation,
               "source_version": "historical_source_unknown_current_mapping_explicit", "float32_mapping_exact": True,
               "minimum_maximum_temperature_equal_days": sum(row[1] == row[2] for row in rows)}
    return tuple(days), rows, area, lines, mapping


def flow_raw(path, basin, start, end, area, *, permit=None):
    expected_area = _raw_permission(permit, path, basin, start, end, "flow")
    if not math.isfinite(float(area)) or area <= 0 or area != expected_area:
        raise PermissionError("Flow conversion area differs from this basin's original locked area")
    values, lines, previous = {}, {}, None
    with transport().no_link_ancestors(path).open(encoding="utf-8") as handle:
        for line in handle:
            fields = line.split()
            if len(fields) < 4:
                raise RuntimeError("Flow row has malformed date fields")
            current = date(*(int(value) for value in fields[1:4]))
            if fields[0] != basin or (previous is not None and current <= previous):
                raise PermissionError("Flow row belongs to another basin or is not increasing")
            previous = current
            if current < start:
                continue
            if current > end:
                break
            if len(fields) < 5:
                raise RuntimeError("Permitted flow row has no value")
            raw = float(fields[4])
            values[current] = math.nan if raw < 0 or not math.isfinite(raw) else CFS_TO_MM * raw / area
            lines[current] = " ".join(fields) + "\n"
            if current == end:
                break
    days = dates_between(start, end)
    return {day: values.get(day, math.nan) for day in days}, lines


def read_permitted_inputs(permit, basin):
    require_permit(permit, basin)
    gate_path = permit.mapping.training(permit.mapping.logical_training_root, permit.selections[basin]["input_gate"])
    gate = json_file(gate_path)
    weather_source = gate["canonical_inputs"]["weather"]["fit"]["source"]
    flow_source = gate["canonical_inputs"]["flow"]["fit"]["source"]
    weather_path = transport().safe_path(permit.contract.data_root, weather_source)
    flow_path = transport().safe_path(permit.contract.data_root, flow_source)
    days, weather, area, lines, mapping = weather_raw(weather_path, basin, DATES["warmup"][0], DATES["score"][1], permit=permit)
    if area != gate["area_identity"]["forcing_area_m2"]:
        raise PermissionError("Scoring flow conversion area differs from the original basin input identity")
    observations, flow_lines = flow_raw(flow_path, basin, DATES["fit"][0], DATES["score"][1], area, permit=permit)
    positions = {day: index for index, day in enumerate(days)}
    identities = {}
    for phase, (start, end) in DATES.items():
        phase_days = dates_between(start, end)
        phase_weather = [weather[positions[day]] for day in phase_days]
        wh = canonical_series(basin, phase, phase_days, WEATHER_NAMES, phase_weather, 9)
        wr = hashlib.sha256("".join(lines[positions[day]] for day in phase_days).encode()).hexdigest()
        if phase != "score":
            expected = gate["canonical_inputs"]["weather"][phase]
            expected_mapping = dict(mapping, minimum_maximum_temperature_equal_days=sum(row[1] == row[2] for row in phase_weather))
            if (wh != expected["canonical_sha256"] or wr != expected["raw_sha256"] or expected["mapping"] != expected_mapping):
                raise PermissionError("Original pre-scoring weather identity changed during local scoring permission")
        if phase == "warmup":
            continue
        q = [observations[day] for day in phase_days]
        fh = canonical_series(basin, phase, phase_days, ("QObs(mm/d)",), [[value] for value in q], 17)
        fr = hashlib.sha256("".join(flow_lines[day] for day in phase_days if day in flow_lines).encode()).hexdigest()
        if phase != "score":
            expected = gate["canonical_inputs"]["flow"][phase]
            if fh != expected["canonical_sha256"] or fr != expected["raw_sha256"]:
                raise PermissionError("Original pre-scoring flow identity changed during local scoring permission")
        else:
            identities = {"weather_canonical_sha256": wh, "weather_raw_sha256": wr,
                          "flow_canonical_sha256": fh, "flow_raw_sha256": fr}
    return InputSeries(days, weather, observations, identities)


def persistence_beta(observations, base, days):
    errors = [observations[day] - base[day] for day in days]
    pairs = [(a, b) for a, b in zip(errors[:-1], errors[1:], strict=True) if math.isfinite(a) and math.isfinite(b)]
    denominator = math.fsum(a * a for a, _ in pairs)
    return max(0., min(1., math.fsum(a * b for a, b in pairs) / denominator)) if denominator > 0 else 0.


def audit_helpers():
    # The registered source files were verified before a production permit was
    # issued; the helpers perform stable-sum arithmetic, not model evaluation.
    from precip_input_assimilation.dynamic_filter_multibasin.audit import stable_nse, audit_rain_ledger, summarize_eight
    return stable_nse, audit_rain_ledger, summarize_eight


def score_artifact(permit, basin, relative):
    require_permit(permit, basin)
    name = f"runtime/scoring/basins/{basin}/" + transport().relative_name(relative)
    permit.anchor.verify(permit.mapping, name)
    return permit.mapping.restored(name)


def audit_station(permit, basin, series, ledger_reader=None):
    require_permit(permit, basin)
    stable_nse, rain_reader, _ = audit_helpers()
    if ledger_reader is None:
        ledger_reader = rain_reader
    selection = permit.selections[basin]
    if tuple(series.dates) != dates_between(DATES["warmup"][0], DATES["score"][1]):
        raise PermissionError("Scoring reader escaped the full permitted calendar")
    identity = json_file(score_artifact(permit, basin, "score_input_locked.json"))
    if (identity["basin"] != basin or identity["global_selection_lock_sha256"] != permit.global_sha256 or
            any(identity[key] != series.score_identity[key] for key in ("weather_canonical_sha256", "weather_raw_sha256",
                                                                       "flow_canonical_sha256", "flow_raw_sha256"))):
        raise PermissionError("Original scoring input identity changed")
    expected = json_file(score_artifact(permit, basin, "summary.json"))
    score_days, complete_days = dates_between(*DATES["score"]), dates_between(DATES["fit"][0], DATES["score"][1])
    dates, observations = [], []
    with score_artifact(permit, basin, "score_observations.csv").open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            day = date.fromisoformat(row["date"])
            value = math.nan if row["q_mm_day"] == "NA" else float(row["q_mm_day"])
            reference = series.observations[day]
            if math.isfinite(value) != math.isfinite(reference) or (math.isfinite(value) and value != reference):
                raise RuntimeError("Saved observations differ from original score-locked daily input")
            dates.append(day)
            observations.append(value)
    if tuple(dates) != score_days:
        raise RuntimeError("Saved observations are duplicated, missing or reordered")
    names = ["base", "persistence"] + [f"{kind}_s{seed}" for kind in METHODS for seed in SEEDS]
    checkpoints = {f"{fit['kind']}_s{fit['seed']}": fit["checkpoint_sha256"] for fit in selection["selected"]}
    checkpoints.update(base="frozen_base", persistence=f"fit_beta={selection['beta']:.17g}")
    coverage = {str(year): sum(math.isfinite(series.observations[day]) for day in dates_between(date(year - 1, 10, 1), date(year, 9, 30))) /
                len(dates_between(date(year - 1, 10, 1), date(year, 9, 30))) for year in range(1986, 1990)}
    if expected["coverage"] != coverage or expected["common_valid_count"] != sum(math.isfinite(value) for value in observations):
        raise RuntimeError("Stored coverage/count differs from independently recomputed actual observations")
    methods, negatives, ledgers, baseline = {}, {}, {}, {}
    missing = {day: not math.isfinite(series.observations[day]) for day in complete_days}
    for name in names:
        predictions, all_days = {}, []
        with score_artifact(permit, basin, f"scoring/{name}/predictions.csv").open(encoding="utf-8", newline="") as handle:
            for row in csv.DictReader(handle):
                day, value = date.fromisoformat(row["date"]), float(row["q_mm_day"])
                if (row["checkpoint"] != checkpoints[name] or date.fromisoformat(row["observation_cutoff"]) != day - timedelta(days=1) or
                        not math.isfinite(value) or day in predictions or not transport().HEX64.fullmatch(row["state_digest"])):
                    raise RuntimeError("Prediction violates checkpoint identity, causal cutoff, finite value or state provenance")
                if name.startswith("flow_"):
                    applied = float(row["direct_flow_applied_mm_day"])
                    if not math.isfinite(applied) or abs(applied) > 5 * selection["scaling"]["flow_std"] + 2e-6 * (1 + abs(applied)):
                        raise RuntimeError("Saved direct flow correction escaped its fitting-only cap")
                predictions[day] = value
                all_days.append(day)
        if tuple(all_days) != complete_days:
            raise RuntimeError("Prediction does not cover the exact complete fit/select/score daily calendar")
        values = [predictions[day] for day in score_days]
        annual = {str(year): stable_nse([series.observations[day] for day in dates_between(date(year - 1, 10, 1), date(year, 9, 30))],
                                      [predictions[day] for day in dates_between(date(year - 1, 10, 1), date(year, 9, 30))])
                  for year in range(1986, 1990)}
        full = stable_nse(observations, values)
        methods[name] = {"full": full, "annual": annual}
        original = expected["methods"][name]
        for actual, stored in [(full, original["full"])] + [(annual[year], original["annual"][year]) for year in annual]:
            if actual is None or stored is None or not math.isfinite(float(stored)) or abs(actual - stored) > 1e-12:
                raise RuntimeError("Independent stable-sum efficiency disagrees with the original stored summary")
        negatives[name] = {"count": sum(value < 0 for value in values), "minimum": min(values)}
        if name in ("base", "persistence"):
            baseline[name] = predictions
        if name.startswith(("rain_", "historical_")):
            ledger = ledger_reader(score_artifact(permit, basin, f"scoring/{name}/rain_versions.csv"), series.dates,
                [row[0] for row in series.weather], expected_updates=3287, expected_cap=selection["scaling"]["cap"], missing_by_date=missing)
            if ledger["updates"] != 3287 or ledger["rows"] != 328700:
                raise RuntimeError("Rain ledger has an incomplete fixed population")
            ledgers[name] = ledger
    beta = persistence_beta(series.observations, baseline["base"], dates_between(*DATES["fit"]))
    if not 0 <= selection["beta"] <= 1 or abs(beta - selection["beta"]) > 1e-12:
        raise RuntimeError("Yesterday-error coefficient differs from independent fitting-only reconstruction")
    previous, maximum = 0., 0.
    for day in complete_days:
        reference = baseline["base"][day] + selection["beta"] * previous
        difference = abs(baseline["persistence"][day] - reference)
        if difference > 1e-5 * (1 + abs(reference)):
            raise RuntimeError("Yesterday-error trajectory differs from prior arrived observations")
        maximum = max(maximum, difference)
        previous = series.observations[day] - baseline["base"][day] if math.isfinite(series.observations[day]) else 0.
    return {"basin": basin, "methods": methods, "coverage": coverage}, {"negatives": negatives, "rain_ledgers": ledgers,
              "beta_recomputed": beta, "persistence_reconstruction_maximum_difference": maximum,
              "probe_reference_tolerance": 1e-5 * (1 + max(abs(baseline["base"][day]) for day in complete_days[:64]))}


def ledger_diagnostic_totals(path):
    """After-update row totals differ from the pre-prediction online statistic."""
    totals, dry_totals, final, absolute, dry, current = [], [], {}, [], [], None
    with transport().no_link_ancestors(path).open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            if current is not None and row["as_of_date"] != current:
                totals.append(math.fsum(absolute))
                dry_totals.append(math.fsum(dry))
                absolute, dry = [], []
            current = row["as_of_date"]
            raw, applied = float(row["raw_mm"]), float(row["applied_mm"])
            if not math.isfinite(raw) or not math.isfinite(applied):
                raise RuntimeError("Diagnostic reconstruction encountered a nonfinite rain ledger")
            absolute.append(abs(applied))
            dry.append(max(applied, 0.) if raw < .1 else 0.)
            final[row["rain_date"]] = (raw, applied)
    totals.append(math.fsum(absolute))
    dry_totals.append(math.fsum(dry))
    return {"absolute_revision_mm": math.fsum(totals), "dry_added_mm": math.fsum(dry_totals),
            "final_dry_added_mm": math.fsum(max(applied, 0.) if raw < .1 else 0. for raw, applied in final.values())}


def audit_diagnostics(permit, basin, series, details):
    selection = permit.selections[basin]
    score_identity = json_file(score_artifact(permit, basin, "score_input_locked.json"))
    checkpoints = {f"{fit['kind']}_s{fit['seed']}": fit["checkpoint_sha256"] for fit in selection["selected"]}
    checkpoints.update(base="frozen_base", persistence=f"fit_beta={selection['beta']:.17g}")
    missing = sum(not math.isfinite(series.observations[day]) for day in dates_between(DATES["fit"][0], DATES["score"][1]))
    evidence = {}
    for name, checkpoint in checkpoints.items():
        item = json_file(score_artifact(permit, basin, f"scoring/{name}/diagnostics.json"))
        if (item["checkpoint_sha256"] != checkpoint or item["score_input_identity"] != canonical_digest(score_identity) or
                item["updates"] != 3287 or item["missing_updates"] != missing):
            raise PermissionError("Trajectory diagnostic checkpoint, input or update provenance differs")
        if name in details["rain_ledgers"]:
            ledger = details["rain_ledgers"][name]
            totals = ledger_diagnostic_totals(score_artifact(permit, basin, f"scoring/{name}/rain_versions.csv"))
            for key, expected in (("rain_versions", ledger["rows"]), ("touch_upper", ledger["touch_upper"]),
                                  ("touch_lower", ledger["touch_lower"])):
                if item[key] != expected:
                    raise RuntimeError("Diagnostic rain-row/cap counts disagree with independently read ledger")
            for key, expected in list(totals.items()) + [("final_daily_absolute_correction_mm", ledger["final_unique_date_absolute_mm"])]:
                if not math.isfinite(float(item[key])) or abs(item[key] - expected) > 2e-6 * (1 + abs(expected)):
                    raise RuntimeError("Stored diagnostic accumulated rain statistic differs from ledger reconstruction")
        elif item["rain_versions"] != 0:
            raise RuntimeError("A non-rain trajectory unexpectedly reported rain revisions")
        evidence[name] = {"checkpoint_and_input_provenance_verified": True,
                          "update_count": item["updates"], "missing_count": missing,
                          "after_update_row_totals_recomputed": name in details["rain_ledgers"]}
    return evidence


def audit_probe_certificates(permit, details):
    require_permit(permit, BASINS[0])
    mapping, anchor = permit.mapping, permit.anchor
    name = "runtime/probe/probe_gate.json"
    anchor.verify(mapping, name)
    gate = json_file(mapping.restored(name))
    sources = permit.selections[BASINS[0]]["sources"]
    if (gate["success"] is not True or gate["kind"] != "eight_basin_probe" or gate["contract_sha256"] != permit.contract.sha256 or
            gate["sources"] != sources or len(gate["basins"]) != 8 or tuple(item["basin"] for item in gate["basins"]) != BASINS or
            not all(value is True for value in gate["tests"].values())):
        raise PermissionError("Original complete probe certificate changed its source, contract or roster")
    evidence = {}
    for measurement in gate["basins"]:
        basin = measurement["basin"]
        measure_name = f"runtime/probe/{basin}/resource_measurement.json"
        anchor.verify(mapping, measure_name)
        if json_file(mapping.restored(measure_name)) != measurement:
            raise PermissionError("Per-basin probe record differs from the original consolidated gate")
        technical = measurement["technical_64_days"]
        tolerance = details[basin]["probe_reference_tolerance"]
        if (measurement["input_identity_sha256"] != permit.selections[basin]["input_identity_sha256"] or
                technical["days"] != 64 or technical["legal_nonzero_supervised_gradient"] is not True or
                technical["observation_causality"] is not True or technical["weather_causality"] is not True or
                technical["frozen_model_tensor_sha256"] != permit.selections[basin]["model_tensor_sha256"] or
                not math.isfinite(float(technical["zero_correction_maximum_difference"])) or
                not 0 <= technical["zero_correction_maximum_difference"] <= technical["zero_correction_tolerance"] or
                abs(technical["zero_correction_tolerance"] - tolerance) > 1e-12 * (1 + tolerance)):
            raise PermissionError("Original 64-day zero-correction/causality certificate violates its locked identities")
        isolation_name = f"runtime/probe/{basin}/adapter_isolation.json"
        if anchor.verify(mapping, isolation_name) != measurement["adapter_isolation"]["record_sha256"]:
            raise PermissionError("Original independent-process adapter probe changed")
        record = json_file(mapping.restored(isolation_name))
        reference, candidate = record["reference"], record["after_other_basin"]
        bound_keys = ("basin", "seed", "dates", "numeric_runtime", "sources", "input_identity_sha256",
                      "static_identity", "area_identity", "model_tensor_sha256")
        original_gate = json_file(mapping.training(mapping.logical_training_root, permit.selections[basin]["input_gate"]))
        if (any(reference[key] != candidate[key] for key in bound_keys) or reference["basin"] != basin or reference["seed"] != SEEDS[0] or
                reference["dates"] != [str(day) for day in dates_between(DATES["fit"][0], DATES["fit"][0] + timedelta(days=63))] or
                reference["sources"] != sources or reference["input_identity_sha256"] != permit.selections[basin]["input_identity_sha256"] or
                reference["static_identity"] != original_gate["static_identity"] or reference["area_identity"] != original_gate["area_identity"] or
                reference["model_tensor_sha256"] != permit.selections[basin]["model_tensor_sha256"]):
            raise PermissionError("Original adapter probes have different basin/static/area/input/runtime identities")
        if len(reference["trajectory"]) != 64 or len(candidate["trajectory"]) != 64 or any(
                not math.isfinite(float(value)) for value in reference["trajectory"] + candidate["trajectory"]):
            raise RuntimeError("Original independent-process probe trajectories are incomplete or nonfinite")
        maximum = max(abs(a - b) for a, b in zip(reference["trajectory"], candidate["trajectory"], strict=True))
        bound = 1e-5 * (1 + max(abs(value) for value in reference["trajectory"]))
        if (record["success"] is not True or maximum > bound or record["maximum_absolute_difference"] != maximum or
                record["tolerance"] != bound or record["other_basin_run_first"] != BASINS[(BASINS.index(basin) - 1) % 8] or
                measurement["adapter_isolation"]["success"] is not True or
                measurement["adapter_isolation"]["maximum_absolute_difference"] != maximum or measurement["adapter_isolation"]["tolerance"] != bound):
            raise RuntimeError("Stored adapter isolation difference does not reconstruct from its original two trajectories")
        evidence[basin] = {"original_probe_certificate_verified": True, "adapter_record_difference_recomputed": maximum,
                           "zero_correction_model_replay": "not_executed"}
    return evidence


def audit_scores(permit, services):
    scores, details, diagnostics = {}, {}, {}
    for basin in BASINS:
        # Full original byte proofs, sealed sources and bounded fit/select input
        # reconstruction are repeated before each basin's scoring reads.
        revalidate_before_scoring(permit, services)
        series = services.score_inputs(permit, basin)
        scores[basin], details[basin] = audit_station(permit, basin, series)
        diagnostics[basin] = audit_diagnostics(permit, basin, series, details[basin])
    top_name = "runtime/scoring/scores.json"
    permit.anchor.verify(permit.mapping, top_name)
    original_scores = json_file(permit.mapping.restored(top_name))
    if set(original_scores) != set(BASINS):
        raise RuntimeError("Original consolidated scores do not contain the fixed eight basins")
    for basin in BASINS:
        stored = original_scores[basin]
        if stored["methods"] != json_file(score_artifact(permit, basin, "summary.json"))["methods"] or stored["coverage"] != scores[basin]["coverage"]:
            raise RuntimeError("Consolidated scores disagree with independently reconstructed station scores")
    _, _, summarize_eight = audit_helpers()
    summary = summarize_eight(scores, BASINS, permit.contract.strata)
    original_audit_name = "runtime/scoring/independent_reconstruction.json"
    permit.anchor.verify(permit.mapping, original_audit_name)
    original_audit = json_file(permit.mapping.restored(original_audit_name))
    if original_audit["success"] is not True or original_audit["global_lock_sha256"] != permit.global_sha256:
        raise PermissionError("Original independent reconstruction is bound to another selection")
    def compare_numeric(actual, stored):
        if isinstance(actual, dict):
            if set(actual) != set(stored):
                raise RuntimeError("Original regional gate fields differ")
            for key in actual:
                compare_numeric(actual[key], stored[key])
        elif isinstance(actual, list):
            if len(actual) != len(stored):
                raise RuntimeError("Original regional gate population differs")
            for a, b in zip(actual, stored, strict=True):
                compare_numeric(a, b)
        elif isinstance(actual, float):
            if not isinstance(stored, (float, int)) or not math.isfinite(stored) or abs(actual - stored) > 1e-12:
                raise RuntimeError("Full-precision regional gates disagree with original reconstruction")
        elif actual != stored:
            raise RuntimeError("Original regional gate or its stated scope differs")
    compare_numeric(summary, original_audit["summary"])
    for basin in BASINS:
        observations_name = f"runtime/scoring/basins/{basin}/score_observations.csv"
        if permit.anchor.verify(permit.mapping, observations_name) != original_audit["details"][basin]["observations_sha256"]:
            raise PermissionError("Stored scoring observation CSV differs from the original independently recorded raw SHA")
        compare_numeric(details[basin]["rain_ledgers"], original_audit["details"][basin]["rain_ledgers"])
        compare_numeric(details[basin]["negatives"], original_audit["details"][basin]["negatives"])
        compare_numeric(details[basin]["persistence_reconstruction_maximum_difference"],
                        original_audit["details"][basin]["persistence_reconstruction_maximum_difference"])
    certificates = audit_probe_certificates(permit, details)
    revalidate_before_scoring(permit, services)
    return {"identity_verified": True, "original_contract_audit_complete": True, "original_contract_summary": summary,
            "scores": scores, "details": details, "diagnostics": diagnostics, "probe_certificates": certificates,
            "population": {"basins": 8, "checkpoints": 72, "trajectories": 88, "prediction_rows": 289256,
                           "rain_ledgers": 48, "rain_rows": 15777600},
            "additional_model_replay": "not_executed", "trajectories_not_replayed": True,
            "state_digest_limit": "Recorded digest shape and checkpoint provenance were checked; network state was not independently regenerated.",
            "separate_context_scientific_acceptance_pending": True,
            "all_training_sha_revalidated_before_each_station_and_at_completion": True,
            "identity_report": permit.identity_report}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("original-root", "global-lock-sha256", "inventory-commit", "inventory-blob-sha1", "inventory-receipt-sha256", "receipt-index-sha256"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--inventory-sequence", required=True, type=int)
    for name in ("recovered-root", "repo", "data-root", "model-root", "contract", "roster-lock", "manifest", "pieces-root", "receipt-index", "output"):
        parser.add_argument("--" + name, required=True, type=Path)
    args = parser.parse_args()
    t = transport()
    output = t.no_link_ancestors(args.output)
    for source in (args.recovered_root, args.data_root, args.model_root, args.pieces_root):
        resolved = t.no_link_ancestors(source).resolve(strict=True)
        if output.resolve().is_relative_to(resolved) or resolved.is_relative_to(output.resolve()):
            raise PermissionError("Audit report output may not overlap any read-only recovery/input/model/fragment root")
    output.mkdir(parents=True, exist_ok=False)
    permit, scoring_started = None, False
    try:
        anchor = SourceAnchor(args.manifest, args.pieces_root, {"sequence": args.inventory_sequence,
            "mailbox_commit": args.inventory_commit, "git_blob_sha1": args.inventory_blob_sha1,
            "receipt_sha256": args.inventory_receipt_sha256}, args.receipt_index, args.receipt_index_sha256)
        mapping = PathMap(args.original_root, args.recovered_root, anchor.value["local_path_mapping"]["logical_training_root"])
        require_completed_run(mapping, anchor)
        # Bootstrap imports only after the original first gate and all 42 source
        # files are authenticated; no daily or score value is read here.
        anchor.verify(mapping, "runtime/locked/global_selection_locked.json")
        lock = json_file(mapping.restored("runtime/locked/global_selection_locked.json"))
        first = lock["selections"][0]
        selection_name = "runtime/training/" + transport().relative_name(first["selection_file"])
        anchor.verify(mapping, selection_name)
        selection = json_file(mapping.training(first["training_root"], first["selection_file"]))
        gate_name = "runtime/training/" + transport().relative_name(selection["input_gate"])
        anchor.verify(mapping, gate_name)
        gate = json_file(mapping.training(selection["training_root"], selection["input_gate"]))
        if source_snapshot(args.repo) != gate["sources"] or len(gate["sources"]) != 42:
            raise PermissionError("The original 42 sources must match before importing frozen helpers")
        modules = _modules(args.repo)
        contract_path = t.no_link_ancestors(args.contract).resolve(strict=True)
        repo = t.no_link_ancestors(args.repo).resolve(strict=True)
        if not contract_path.is_relative_to(repo):
            raise PermissionError("Contract is outside its explicitly bound local repository")
        contract = modules["contract"].Contract.load(contract_path).bind(repo=repo,
            data_root=t.no_link_ancestors(args.data_root), model_root=t.no_link_ancestors(args.model_root),
            roster_lock=t.no_link_ancestors(args.roster_lock))
        contract.verify_roster_lock()
        services = ProductionServices(repo)
        permit = validate_all(contract, mapping, anchor, args.global_lock_sha256, services)
        scoring_started = True
        result = audit_scores(permit, services)
        result["external_anchors"] = {"inventory_receipt": anchor.provenance,
            "receipt_index_sha256": anchor.receipt_index_sha256,
            "git_commit_blob_membership": {"status": "required_from_upstream",
                "limit": "This tool checks externally pinned Git blob bytes and receipt-index SHA256; it does not query Git commit tree membership."}}
        result["offline_sources"] = {Path(__file__).name: file_sha(__file__), "transport_helper_sha256": TRANSPORT_SHA256}
        t.json_write(output / "offline_audit.json", result)
        print(json.dumps({"identity_verified": True, "original_contract_audit_complete": True,
                          "continue_regional_research": result["original_contract_summary"]["continue_regional_research"],
                          "additional_model_replay": "not_executed"}))
    except Exception as error:
        t.json_write(output / "failure.json", {"identity_verified": permit is not None,
            "original_contract_audit_complete": False, "score_numeric_reads_started": scoring_started,
            "error_type": type(error).__name__, "error": str(error), "original_lock_files_written": False})
        raise


def require_permit(permit, basin):
    issued = _ISSUED.get(id(permit))
    if (type(permit) is not ScorePermit or issued is None or issued[0] is not permit or basin not in BASINS or
            issued[1] is not permit.contract or issued[2] is not permit.mapping or issued[3] is not permit.anchor or
            issued[4] != _permit_binding(permit)):
        raise PermissionError("Missing, forged or changed complete-selection score capability")
    for name, expected in permit.frozen_stats.items():
        path = Path(permit.frozen_paths[name])
        if transport()._is_link(path) or transport().file_stat(path) != expected:
            raise PermissionError("Original selection/checkpoint identity changed since local permission")
    for name, expected in permit.watched_stats.items():
        path = Path(name)
        if transport()._is_link(path) or transport().file_stat(path) != expected:
            raise PermissionError("A registered source/input/model file changed since local permission")
    for name in permit.watched_directories:
        if transport()._is_link(Path(name)):
            raise PermissionError("Registered artifact ancestors became links or directory junctions")
    return permit


def _permit_binding(permit):
    deployment = [str(transport().no_link_ancestors(getattr(permit.contract, name)).resolve())
                  for name in ("repo", "data_root", "model_root") if hasattr(permit.contract, name)]
    input_identities = {}
    for basin, series in permit.inputs.items():
        weather = [[float(value) for value in row] for row in series.weather]
        observations = {str(day): format(float(value), ".17g") if math.isfinite(float(value)) else "NA"
                        for day, value in series.observations.items()}
        input_identities[basin] = canonical_digest({"dates": [str(day) for day in series.dates], "weather": weather,
                                                   "observations": observations, "score_identity": series.score_identity})
    return canonical_digest({"selections": permit.selections, "input_identities": input_identities,
             "stats": permit.frozen_stats, "watched_stats": permit.watched_stats, "frozen_paths": permit.frozen_paths,
             "watched_directories": permit.watched_directories, "original_root": permit.mapping.original_root,
             "recovered_root": str(permit.mapping.recovered_root), "training_root": str(permit.mapping.training_root),
             "logical_root": permit.mapping.logical_training_root, "deployment": deployment,
             "contract_sha256": permit.contract.sha256, "global_sha256": permit.global_sha256,
             "identity_report": permit.identity_report,
             "anchor": ({"inventory": permit.anchor.value, "receipts": permit.anchor.receipts,
                         "requests": permit.anchor.requests, "receipt_index_sha256": permit.anchor.receipt_index_sha256,
                         "pieces_root": str(permit.anchor.pieces_root), "provenance": permit.anchor.provenance}
                        if isinstance(permit.anchor, SourceAnchor) else {"explicit_test_double": type(permit.anchor).__name__})})


def revalidate_before_scoring(permit, services):
    require_permit(permit, BASINS[0])
    for name in permit.frozen_stats:
        permit.anchor.verify(permit.mapping, name)
    for basin, selection in permit.selections.items():
        if services.verify_sources(permit.contract.repo, selection["sources"]) != selection["sources"]:
            raise PermissionError("Sealed source bytes changed before scoring")
        gate = json_file(permit.mapping.training(permit.mapping.logical_training_root, selection["input_gate"]))
        fresh = services.fresh_fit_select(permit.contract, basin, gate)
        if fresh.score_identity.get("pre_score_gate_sha256") != selection["input_identity_sha256"]:
            raise PermissionError("Fitting input/static/area/model identity changed before scoring")


if __name__ == "__main__":
    main()
