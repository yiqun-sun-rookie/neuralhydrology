"""Exactly four HPC migration checks; no model forwards or training."""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest

from precip_input_assimilation.hpc.precip_smallfit_runtime_v01 import Owner, validate_exploration
from precip_input_assimilation.small_sample.hpc_fit_audit_v01 import adapted_function_ast
from precip_input_assimilation.small_sample.flexible_budget_v04 import CounterStore, digest
from precip_input_assimilation.scripts.run_precip_effect_first_v02 import load_budget

CODE = Path(__file__).resolve().parents[3]
ROOT = CODE.parent.parent


class TargetedChecks(unittest.TestCase):
    def test_exploration_requires_actual_nine_and_preserves_three_negatives(self):
        manifest = json.loads((ROOT / "payload/manifest.json").read_text())
        audit = json.loads((ROOT / "payload" / manifest["saved_sources"]["completed_audit"]["path"]).read_text())
        self.assertTrue(validate_exploration(audit)["exploratory_fit_admitted"])
        bad = copy.deepcopy(audit)
        next(r for r in bad["decisions"] if r["objective"] == "pure_flow_mse")["effective"] = False
        with self.assertRaises(PermissionError):
            validate_exploration(bad)
        bad = copy.deepcopy(audit)
        next(r for r in bad["decisions"] if r["status"] == "NOT_CONVERGED")["status"] = "PASS"
        with self.assertRaises(PermissionError):
            validate_exploration(bad)

    def test_audit_adapts_only_seed_and_relocated_admission(self):
        path = CODE / "src/precip_input_assimilation/small_sample/local_gradient_independent_v06.py"
        adapted = adapted_function_ast(path.read_bytes()).body[0]
        original = next(n for n in ast.parse(path.read_text()).body if isinstance(n, ast.FunctionDef) and n.name == "audit_fit_stage")
        for node in ast.walk(adapted):
            if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "seeds" for t in node.targets):
                self.assertEqual(ast.literal_eval(node.value.orelse), [1001])
                node.value.orelse = ast.List(elts=[ast.Constant(i) for i in [1001,1002,1003]], ctx=ast.Load())
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "verify_saved_source_admission":
                node.func, node.args = ast.Name(id="_original_sources", ctx=ast.Load()), [ast.Name(id="ctx", ctx=ast.Load())]
        self.assertEqual(ast.dump(original, include_attributes=False), ast.dump(adapted, include_attributes=False))
        context = ast.parse((CODE / "src/precip_input_assimilation/small_sample/hpc_saved_context_v01.py").read_text())
        gate = [n.lineno for n in ast.walk(context) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "require_date_provenance"]
        loads = [n.lineno for n in ast.walk(context) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "load" and isinstance(n.func.value, ast.Name) and n.func.value.id == "torch"]
        self.assertLess(min(gate), min(loads))

    def test_exact_inherited_budget_and_counter_chain(self):
        manifest = json.loads((ROOT / "payload/manifest.json").read_text())
        _, used, allocations, settled = load_budget(ROOT / "payload/records/budget_handoff.json")
        reserve = allocations[manifest["budget_reservation_id"]]["payload"]["reserved_seconds"]
        self.assertEqual(259200 - used + reserve, manifest["remaining_seconds"])
        self.assertEqual(set(allocations) - set(settled), {manifest["budget_reservation_id"]})
        store = CounterStore(ROOT / "payload/counters", manifest["counter_binding"], lambda: None)
        snapshot = store.reopen(manifest["counter_snapshot_digest"], manifest["counter_head_sha256"],
                                manifest["counter_event_count"], manifest["counter_initialization_evidence_sha256"])
        self.assertEqual(snapshot["counts"]["gradient_full_forward"], 94)
        self.assertEqual(snapshot["counts"]["direct_science_update"], 0)
        self.assertEqual(snapshot["counts"]["network_1001_science_update"], 0)

    def test_fast_checkpoint_and_boundary_tamper_stop(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); (root / "payload").mkdir()
            p = root / "payload/source"; p.write_bytes(b"original")
            manifest = {"files": [{"path": "source", "bytes": 8, "sha256": hashlib.sha256(b"original").hexdigest()}]}
            owner = Owner(root, manifest)
            owner.verify_sources()
            p.write_bytes(b"modified")
            owner.check()  # Ordinary calendar checkpoint does no full scan.
            with self.assertRaises(PermissionError):
                owner.verify_sources()
            (root / "STOP").touch()
            with self.assertRaises(InterruptedError):
                owner.check()


if __name__ == "__main__":
    unittest.main(verbosity=2)
