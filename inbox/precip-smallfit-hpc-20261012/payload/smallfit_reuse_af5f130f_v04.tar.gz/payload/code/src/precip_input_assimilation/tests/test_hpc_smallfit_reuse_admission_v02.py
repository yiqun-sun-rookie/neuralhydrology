"""Original four HPC checks with the inherited direct650 count, not zero.

Run only inside the new HPC deployment. No numerical library is imported.
"""
import ast
import copy
import hashlib
import importlib.util
from pathlib import Path
import sys
import types
import unittest

ORIGINAL_SHA = 'f22592b349caed97edb27bbfb95ccf3fc588ad1e95ff5e04db6c1e8d619bad50'


def adapted_counter_test(raw):
    if hashlib.sha256(raw).hexdigest() != ORIGINAL_SHA:
        raise PermissionError('Original four admission checks changed')
    cls = next(n for n in ast.parse(raw).body if isinstance(n, ast.ClassDef) and n.name == 'TargetedChecks')
    fn = copy.deepcopy(next(n for n in cls.body if isinstance(n, ast.FunctionDef)
                            and n.name == 'test_exact_inherited_budget_and_counter_chain'))
    count = 0
    for node in ast.walk(fn):
        if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                and node.func.attr == 'assertEqual' and len(node.args) == 2
                and ast.dump(node.args[0]) == ast.dump(ast.parse("snapshot['counts']['direct_science_update']", mode='eval').body)):
            if ast.literal_eval(node.args[1]) != 0:
                raise PermissionError('Unexpected old direct-update admission')
            node.args[1] = ast.Constant(650)
            count += 1
    if count != 1:
        raise PermissionError('Expected exactly one inherited-count substitution')
    return ast.fix_missing_locations(ast.Module(body=[fn], type_ignores=[]))


def main():
    folder = Path(__file__).resolve().parent
    raw = (folder / 'test_hpc_smallfit_admission_v01.py').read_bytes()
    tree = adapted_counter_test(raw)
    package = types.ModuleType('precip_input_assimilation')
    package.__path__ = [str(folder.parent)]
    sys.modules[package.__name__] = package
    spec = importlib.util.spec_from_file_location('_original_hpc_admission', folder / 'test_hpc_smallfit_admission_v01.py')
    original = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(original)
    namespace = dict(vars(original))
    exec(compile(tree, str(spec.origin) + ':reuse650', 'exec'), namespace)
    original.TargetedChecks.test_exact_inherited_budget_and_counter_chain = namespace['test_exact_inherited_budget_and_counter_chain']
    if {'torch', 'numpy', 'pandas'} & set(sys.modules):
        raise PermissionError('Numerical libraries were imported before HPC admission')
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(original.TargetedChecks))
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__ == '__main__':
    main()
