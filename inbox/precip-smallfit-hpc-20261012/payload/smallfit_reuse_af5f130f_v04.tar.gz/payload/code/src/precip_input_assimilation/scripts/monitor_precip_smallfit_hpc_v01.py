"""One owned mailbox request at a time, with durable terminal artifact download."""
import argparse
import base64
import hashlib
import json
import msvcrt
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import sys
import tarfile
import time
import zlib

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'hpc'))
from precip_smallfit_mailbox_v01 import BRANCH, CHANNEL, Mailbox, publish, verified_text


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()


def save(path, data):
    temp = path.with_suffix(path.suffix + '.partial')
    temp.write_text(json.dumps(data, sort_keys=True, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    os.replace(temp, path)


def native(path):
    return chr(92) * 2 + '?' + chr(92) + str(path.absolute()) if os.name == 'nt' else str(path)


def immutable(path, raw):
    os.makedirs(native(path.parent), exist_ok=True)
    if os.path.exists(native(path)):
        with open(native(path), 'rb') as f:
            if f.read() != raw:
                raise PermissionError('Existing received bytes differ')
    else:
        with open(native(path), 'xb') as f:
            f.write(raw)


def finish_delivery(root, index):
    archive = root / 'delivery' / index['archive']
    if not archive.exists():
        with archive.open('xb') as out:
            for row in index['chunks']:
                p = root / 'delivery' / ('chunk_%06d.bin' % row['index'])
                if p.stat().st_size != row['bytes'] or sha(p) != row['sha256']:
                    raise PermissionError('Received chunk identity changed')
                with p.open('rb') as f:
                    shutil.copyfileobj(f, out)
    if archive.stat().st_size != index['bytes'] or sha(archive) != index['sha256']:
        raise PermissionError('Complete terminal archive identity differs')
    with tarfile.open(archive, 'r:gz') as tf:
        members = tf.getmembers()
        if len({m.name for m in members}) != len(members) or any(not m.isfile() for m in members):
            raise PermissionError('Nonregular or duplicate terminal member')
        manifest_raw = tf.extractfile('_FILE_MANIFEST.json').read()
        if hashlib.sha256(manifest_raw).hexdigest() != index['file_manifest_sha256']:
            raise PermissionError('Terminal file manifest identity differs')
        rows = json.loads(manifest_raw)
        if {m.name for m in members} != {'_FILE_MANIFEST.json'} | {r['path'] for r in rows}:
            raise PermissionError('Terminal member set differs')
        for row in rows:
            rel = PurePosixPath(row['path'])
            if rel.is_absolute() or '..' in rel.parts or '\\' in row['path']:
                raise PermissionError('Terminal member escapes local result directory')
            data = tf.extractfile(row['path']).read()
            if len(data) != row['bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
                raise PermissionError('Terminal original artifact identity differs')
            immutable(root / 'received_originals' / Path(*rel.parts), data)
    save(root / 'terminal_delivery_verified.json', {'archive_sha256': index['sha256'],
         'archive_bytes': index['bytes'], 'files_verified': len(rows), 'all_original_bytes_verified': True})


def request_command(config, state):
    args = ['--root', config['remote_root'], '--nonce', config['nonce']]
    kind = 'status'
    if state.get('delivery'):
        index = state['delivery']
        missing = [r for r in index['chunks']
                   if not (Path(config['local_root']) / 'delivery' / ('chunk_%06d.bin' % r['index'])).exists()]
        if not missing:
            return None, None
        kind = 'chunk'
        args += ['--chunk', str(missing[0]['index']), '--archive-sha256', index['sha256']]
    script = config['remote_root'] + '/payload/code/src/precip_input_assimilation/hpc/precip_smallfit_return_v01.py'
    # All arguments come from our frozen UUID/path manifest; shell quoting is explicit.
    import shlex
    text = '#!/bin/bash\nset -eo pipefail\nexport PYTHONDONTWRITEBYTECODE=1\n'
    text += '/data1/home/sunyiq/miniconda3/envs/nh_final/bin/python -B ' + ' '.join(shlex.quote(x) for x in [script] + args) + '\n'
    return text, kind


def run(root, seconds, replies):
    config = json.loads((root / 'monitor_config.json').read_bytes())
    state_path = root / 'monitor_state.json'
    state = json.loads(state_path.read_bytes())
    box = Mailbox()
    deadline, received = time.monotonic() + seconds, 0
    while received < replies:
        if state.get('delivery_complete'):
            return state
        if state.get('delivery') and all((root / 'delivery' / ('chunk_%06d.bin' % r['index'])).exists()
                                         for r in state['delivery']['chunks']):
            finish_delivery(root, state['delivery'])
            state['delivery_complete'] = True
            save(state_path, state)
            return state
        if not state.get('pending_sequence'):
            command, kind = request_command(config, state)
            sequence = state['last_completed_sequence'] + 1
            path = root / 'mailbox' / ('request_%06d.sh' % sequence)
            immutable(path, command.encode())
            # Publish intent first, so uncertain POST/PATCH outcomes never skip a sequence.
            state.update(pending_sequence=sequence, pending_kind=kind,
                         pending_command_sha256=hashlib.sha256(command.encode()).hexdigest(),
                         pending_since_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
            save(state_path, state)
            result = publish(box, sequence, path)
            save(root / 'mailbox' / ('publication_%06d.json' % sequence), result)
        sequence = state['pending_sequence']
        head = box.api('git/ref/heads/' + BRANCH)['object']['sha']
        remote_seq = int(verified_text(box, 'inbox/' + CHANNEL + '/seq', head).strip())
        if remote_seq == sequence:
            command = verified_text(box, 'inbox/' + CHANNEL + '/cmd.sh', head)
            if hashlib.sha256(command).hexdigest() != state['pending_command_sha256']:
                raise PermissionError('Owned pending sequence command identity changed')
        elif remote_seq == sequence - 1 and state['pending_kind'] != 'deployment':
            path = root / 'mailbox' / ('request_%06d.sh' % sequence)
            publish(box, sequence, path)  # Previous attempt never reached the ref; same exact read-only command.
        else:
            raise PermissionError('Owned sequence advanced unexpectedly; inspect without resubmitting')
        raw = verified_text(box, 'outbox/' + CHANNEL + '/result_' + str(sequence) + '.txt', head, missing=True)
        if raw is None:
            if time.monotonic() >= deadline:
                return state
            time.sleep(min(10, max(0, deadline - time.monotonic())))
            continue
        footer = re.search(rb'### exit_code=(-?[0-9]+)\r?\n### finished=[^\r\n]+\r?\n?\Z', raw)
        if not raw.startswith(('### channel=' + CHANNEL + ' seq=' + str(sequence)).encode()) or not footer:
            immutable(root / 'mailbox' / ('failed_receipt_%06d.txt' % sequence), raw)
            raise RuntimeError('Owned receipt identity/footer incomplete; preserve pending request')
        if int(footer.group(1)) != 0:
            immutable(root / 'mailbox' / ('failed_receipt_%06d.txt' % sequence), raw)
            if state['pending_kind'] == 'deployment':
                raise RuntimeError('Deployment failed; inspect original submission evidence, never resubmit')
            state['last_command_error'] = {'sequence': sequence, 'exit_code': int(footer.group(1)),
                                           'raw_sha256': hashlib.sha256(raw).hexdigest()}
            state.update(last_completed_sequence=sequence, pending_sequence=None, pending_kind=None)
            save(state_path, state)
            return state  # Report the error now; next activation makes a fresh read-only request.
        immutable(root / 'mailbox' / ('receipt_%06d.txt' % sequence), raw)
        save(root / 'mailbox' / ('receipt_%06d_identity.json' % sequence),
             {'commit': head, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
        if state['pending_kind'] == 'deployment':
            marker = json.loads(next(l.split('=', 1)[1] for l in raw.decode().splitlines() if l.startswith('SUBMISSION_JSON=')))
            if marker['nonce'] != config['nonce'] or marker['manifest_sha256'] != config['manifest_sha256']:
                raise PermissionError('Submission belongs to a different continuation')
            save(root / 'actual_submission.json', marker)
            state['job_id'] = marker['job_id']
        else:
            encoded = next(l.split('=', 1)[1] for l in raw.decode().splitlines() if l.startswith('SMALLFIT_RETURN_V01='))
            result = json.loads(zlib.decompress(base64.b64decode(encoded, validate=True)))
            if result['job_id'] != state['job_id']:
                raise PermissionError('Response job identity differs')
            if result['kind'] == 'status':
                if result['nonce'] != config['nonce']:
                    raise PermissionError('Response nonce differs')
                save(root / 'latest_status.json', result)
                state['scheduler_state'] = result['state']
                state['last_observed_utc'] = result['observed_utc']
                if result.get('delivery'):
                    state['delivery'] = result['delivery']
                    (root / 'delivery').mkdir(exist_ok=True)
            else:
                index = state['delivery']
                row = index['chunks'][result['index']]
                data = base64.b64decode(result['base64'], validate=True)
                if result['archive_sha256'] != index['sha256'] or len(data) != row['bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
                    raise PermissionError('Immutable terminal chunk differs')
                immutable(root / 'delivery' / ('chunk_%06d.bin' % row['index']), data)
        state.update(last_completed_sequence=sequence, pending_sequence=None, pending_kind=None)
        save(state_path, state)
        received += 1
        if state.get('scheduler_state') not in (None, 'UNKNOWN') and not state.get('delivery'):
            return state
        if time.monotonic() >= deadline:
            return state
    return state


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', required=True, type=Path)
    p.add_argument('--wait-seconds', type=int, default=90)
    p.add_argument('--max-replies', type=int, default=8)
    a = p.parse_args()
    root = a.root.absolute()
    lock = (root / 'monitor.lock').open('a+b')
    try:
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
    except OSError:
        print(json.dumps({'monitor_already_active': True}))
        return
    try:
        state = run(root, a.wait_seconds, a.max_replies)
        print(json.dumps({k: v for k, v in state.items() if k != 'delivery'}, sort_keys=True))
    finally:
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
        lock.close()


if __name__ == '__main__':
    main()
