"""Read-only admission of job242770 artifacts into a fresh HPC authority.

No numerical imports or job submission. The new payload must include the
completed original delivery certificate; a partial download is not admitted.
"""
import hashlib
import json
import os
from pathlib import Path

OLD_ROOT = Path('/data1/home/sunyiq/precip_smallfit_hpc_20261012_v01/20261015T062534Z_26ac3faf_v03')
OLD_NONCE = '26ac3faff4e34c7ba4eea6e485377376'
# Expected original-writer serialization of the complete verified seq63
# object; raw stage_result bytes must also match after complete delivery.
STAGE_SHA = 'bdc19314ab6fd5da67548799b15316e62635a983d8f4d52dac11077de772cf34'
CONTROL_RESULT_SHA = 'af465dcbc45e018ef73815e9b1521b453c159c72a3ebbae1683a6da9d6fb9300'
BUDGET_SHA = 'fe92c27a30ca97cf275e6734a735eb22f16e0478f0c82009833bf4dc6efeadf5'
ARCHIVE_SHA = 'b5a585e152de663cca03a65c46d33f0903a6516c0f9a62e6077fdd1e0ab4f7aa'
INITIAL_SHA = 'f1d46ad3c27ec2ad652888b68267ce45ea6250b2fb2ef5e6528283f112f6139e'
COUNTER_HEAD = 'baa30343f4501e60a25ad048ab349cc4a897dcb936a2121d34de67a66dacd794'


def checked_file(path, root, digest=None):
    path, root = Path(path), Path(root)
    if not path.is_absolute() or '..' in path.parts or not path.is_relative_to(root):
        raise PermissionError('Reuse source escaped its admitted root')
    for parent in (path, *path.parents):
        if parent.is_symlink() or getattr(parent.lstat(), 'st_file_attributes', 0) & 0x400:
            raise PermissionError('Linked reuse sources are not admitted')
    if path.resolve(strict=True) != path or not path.is_file():
        raise PermissionError('Reuse source is not an original regular file')
    raw = path.read_bytes()
    if digest is not None and hashlib.sha256(raw).hexdigest() != digest:
        raise PermissionError('Original reuse source bytes changed: ' + str(path))
    return raw


def payload_reference(root, manifest, name):
    ref = manifest['reuse_direct'][name]
    rows = [r for r in manifest['files'] if r['path'] == ref['path']]
    if rows != [ref]:
        raise PermissionError('Reuse reference lacks unique payload membership')
    path = root / 'payload' / ref['path']
    raw = checked_file(path, root / 'payload', ref['sha256'])
    if len(raw) != ref['bytes']:
        raise PermissionError('Reuse reference length changed')
    return path, raw


def require_stopped_predecessor():
    if any((p / 'STOP').exists() for p in (OLD_ROOT, OLD_ROOT.parent, OLD_ROOT / 'runtime/direct_control')):
        raise InterruptedError('Predecessor/family manual stop remains in force')
    owner = json.loads(checked_file(OLD_ROOT / 'runtime/owner.json', OLD_ROOT))
    if (owner['status'] != 'STOPPED' or owner['nonce'] != OLD_NONCE or str(owner['job_id']) != '242770'):
        raise PermissionError('Predecessor ownership or terminal identity changed')
    # Successful /proc absence or a different creation identity is required;
    # permission/read errors propagate, rather than being called an exit.
    proc = Path('/proc') / str(owner['pid']) / 'stat'
    try:
        ticks = proc.read_text().rsplit(')', 1)[1].split()[19]
    except FileNotFoundError:
        pass
    else:
        if ticks == owner['creation_ticks']:
            raise PermissionError('Predecessor owner is still alive')


def admit(root, manifest):
    root = Path(root)
    if (os.name != 'posix' or root == OLD_ROOT or root.parent != OLD_ROOT.parent
            or root.resolve() != root or manifest['remote_root'] != str(root)
            or manifest['nonce'] == OLD_NONCE or str(os.environ.get('SLURM_JOB_ID', '')) in ('', '242770')):
        raise PermissionError('A separately authorized fresh SLURM root is required')
    if manifest['recipe']['seeds'] != [1001] or manifest['remaining_seconds'] != 44168:
        raise PermissionError('Seed scope or conservatively reconciled total budget differs')
    require_stopped_predecessor()
    _, raw = payload_reference(root, manifest, 'terminal_delivery')
    delivery = json.loads(raw)
    if delivery != {'archive_sha256': ARCHIVE_SHA, 'archive_bytes': 163376288,
                    'files_verified': 15718, 'all_original_bytes_verified': True}:
        raise PermissionError('Complete original delivery has not been admitted')
    initial, raw = payload_reference(root, manifest, 'original_initial')
    if hashlib.sha256(raw).hexdigest() != INITIAL_SHA:
        raise PermissionError('Original seed1001 checkpoint differs')
    old_budget = json.loads(checked_file(OLD_ROOT / 'runtime/budget.json', OLD_ROOT, BUDGET_SHA))
    new_budget = json.loads(checked_file(root / 'payload/records/budget_handoff.json', root / 'payload',
                                       manifest['budget_handoff_sha256']))
    prefix = old_budget['events']
    if len(prefix) != 44 or new_budget['events'][:44] != prefix or len(new_budget['events']) != 47:
        raise PermissionError('Original budget prefix plus gap settlement and new reservation are required')
    gap_reserve, gap_settle = [r['payload'] for r in new_budget['events'][44:46]]
    if (gap_reserve['kind'] != 'reserve' or gap_reserve['reserved_seconds'] != 13
            or gap_settle['kind'] != 'settle' or gap_settle['charged_seconds'] != 13
            or gap_settle['run_id'] != gap_reserve['run_id']
            or gap_settle['reservation_sha256'] != new_budget['events'][44]['sha256']):
        raise PermissionError('Slurm/entry 13-second gap has not been charged exactly')
    # The original Budget and CounterStore already validate their complete
    # chains. Here require the actual old raw counters to be the new prefix.
    old_counters, new_counters = OLD_ROOT / 'runtime/counters', root / 'runtime/counters'
    old_paths = {p.relative_to(old_counters) for p in old_counters.rglob('*') if p.is_file()}
    new_paths = {p.relative_to(new_counters) for p in new_counters.rglob('*') if p.is_file()}
    if old_paths != new_paths:
        raise PermissionError('Continuation counter file inventory differs')
    for rel in old_paths:
        if checked_file(old_counters / rel, old_counters) != checked_file(new_counters / rel, new_counters):
            raise PermissionError('Continuation changed an original counter receipt')
    counter = json.loads(checked_file(old_counters / 'operation_counters_v04.json', old_counters))
    if (counter['event_count'] != 2189 or counter['head_sha256'] != COUNTER_HEAD
            or manifest['counter_event_count'] != 2189 or manifest['counter_head_sha256'] != COUNTER_HEAD):
        raise PermissionError('Original completed counter prefix differs')
    result = json.loads(checked_file(OLD_ROOT / 'runtime/direct_control/stage_result.json', OLD_ROOT, STAGE_SHA))
    control_path = OLD_ROOT / 'runtime/direct_control/control/fit_result.json'
    controls = [row for row in result['fit_raw_artifacts'] if row['path'] == str(control_path)]
    raw = checked_file(control_path, OLD_ROOT, CONTROL_RESULT_SHA)
    if controls != [{'path': str(control_path), 'bytes': len(raw), 'sha256': CONTROL_RESULT_SHA}]:
        raise PermissionError('Control fit_result lacks its separate original inventory identity')
    if (result['stage'] != 'direct_control' or not result['execution_complete']
            or result['technical_incomplete'] or len(result['runs']) != 1
            or result['runs'][0]['updates_completed'] != 650):
        raise PermissionError('Only the preserved complete 650-update direct stage can be reused')
    return result, initial
