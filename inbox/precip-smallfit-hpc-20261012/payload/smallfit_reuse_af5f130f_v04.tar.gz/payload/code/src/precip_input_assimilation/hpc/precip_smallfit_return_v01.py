"""Owned Slurm metadata and immutable terminal-file delivery; no numeric imports."""
import argparse
import base64
import fcntl
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import tarfile
import time
import uuid
import zlib

PARENT = Path('/data1/home/sunyiq/precip_smallfit_hpc_20261012_v01')
CHUNK_BYTES = 262144
TERMINAL = {'COMPLETED', 'FAILED', 'CANCELLED', 'TIMEOUT', 'OUT_OF_MEMORY',
            'NODE_FAIL', 'BOOT_FAIL', 'PREEMPTED', 'DEADLINE', 'REVOKED'}


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(path.read_bytes()) if path.is_file() else None


def terminal_archive(root):
    delivery = root / 'delivery'
    delivery.mkdir(exist_ok=True)
    index_path = delivery / 'terminal_index_v01.json'
    if index_path.exists():
        return read(index_path)
    files = [root / 'job.slurm', root / 'payload/manifest.json']
    for name in ('runtime', 'logs', 'records'):
        files += sorted(p for p in (root / name).rglob('*') if p.is_file())
    files = sorted(set(files))
    rows = []
    for p in files:
        if p.is_symlink() or not p.resolve().is_relative_to(root) or not stat.S_ISREG(p.stat().st_mode):
            raise PermissionError('Nonregular or escaping terminal artifact')
        rows.append({'path': p.relative_to(root).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p)})
    manifest = (json.dumps(rows, sort_keys=True, indent=2) + '\n').encode()
    partial = delivery / ('terminal_' + uuid.uuid4().hex + '.partial')
    with tarfile.open(partial, 'w:gz', compresslevel=1) as tf:
        item = tarfile.TarInfo('_FILE_MANIFEST.json')
        item.size = len(manifest)
        tf.addfile(item, io.BytesIO(manifest))
        for p, row in zip(files, rows):
            tf.add(p, arcname=row['path'], recursive=False)
    archive = delivery / 'terminal_originals_v01.tar.gz'
    if archive.exists():
        raise FileExistsError('Archive exists without its complete index; retain and inspect')
    os.rename(partial, archive)
    chunks = []
    with archive.open('rb') as f:
        while True:
            raw = f.read(CHUNK_BYTES)
            if not raw:
                break
            chunks.append({'index': len(chunks), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    result = {'archive': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive),
              'chunk_bytes': CHUNK_BYTES, 'chunks': chunks, 'files': len(rows),
              'file_manifest_sha256': hashlib.sha256(manifest).hexdigest()}
    with index_path.open('x') as f:
        json.dump(result, f, sort_keys=True, indent=2)
    return result


def collect(root, nonce, chunk=None, expected_archive=None):
    root = Path(root).absolute()
    if root.parent != PARENT or root.resolve() != root:
        raise PermissionError('Not the isolated owned root')
    marker = read(root / 'records/submission.json')
    if not marker or marker['nonce'] != nonce:
        raise PermissionError('Actual owned submission identity missing')
    job = str(marker['job_id'])
    if chunk is not None:
        index = read(root / 'delivery/terminal_index_v01.json')
        if not index or index['sha256'] != expected_archive or not 0 <= chunk < len(index['chunks']):
            raise PermissionError('Wrong immutable delivery identity or chunk')
        row = index['chunks'][chunk]
        with (root / 'delivery' / index['archive']).open('rb') as f:
            f.seek(chunk * CHUNK_BYTES)
            raw = f.read(row['bytes'])
        if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
            raise PermissionError('Terminal archive chunk changed')
        return {'kind': 'chunk', 'job_id': int(job), 'archive_sha256': expected_archive,
                **row, 'base64': base64.b64encode(raw).decode()}
    commands = [
        ['squeue', '-j', job, '-h', '-o', '%i|%T|%R'],
        ['sacct', '-S', '2026-10-14', '-X', '-j', job, '-n', '-P', '-o',
         'JobIDRaw,State,ExitCode,Submit,Start,End,Elapsed,NodeList']]
    scheduler = []
    for args in commands:
        q = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30)
        scheduler.append({'args': args, 'returncode': q.returncode,
                          'text': q.stdout.decode(errors='replace')})
    state = 'UNKNOWN'
    if scheduler[1]['returncode'] == 0:
        for line in scheduler[1]['text'].splitlines():
            fields = line.split('|')
            if fields[0] == job:
                state = fields[1].split()[0].rstrip('+')
    if scheduler[0]['returncode'] == 0 and scheduler[0]['text'].strip():
        state = scheduler[0]['text'].strip().split('|')[1]
    lock_free = False
    with (PARENT / 'exclusive.lock').open('r+b') as f:
        try:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            pass
        else:
            lock_free = True
            fcntl.flock(f, fcntl.LOCK_UN)
    values = {}
    names = ['owner.json', 'numerical_worker_identity.json', 'supervisor_progress.json',
             'worker_failure.json', 'supervisor_failure.json', 'targeted_checks.json',
             'exploratory_admission.json', 'final_supervisor_report.json', 'fit_execution_complete.json',
             'counters/operation_counters_v04.json', 'budget.json']
    for stage in ('direct_control', 'network'):
        names += [stage + '/stage_result.json', stage + '/independent_fit_audit.json']
        candidates = sorted((root / 'runtime' / stage).glob('*/step_*.json'))
        if candidates:
            names.append(candidates[-1].relative_to(root / 'runtime').as_posix())
    for name in names:
        value = read(root / 'runtime' / name)
        if value is not None:
            values[name] = value
    tails = {}
    for name in ('numerical_worker.log', 'slurm-' + job + '.out', 'slurm-' + job + '.err'):
        path = root / 'logs' / name
        if path.is_file():
            with path.open('rb') as f:
                f.seek(max(0, path.stat().st_size - 5000))
                tails[name] = f.read().decode(errors='replace')
    result = {'kind': 'status', 'observed_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
              'job_id': int(job), 'nonce': nonce, 'state': state, 'scheduler': scheduler,
              'actual_family_lock_free': lock_free, 'records': values, 'log_tails': tails,
              'terminal': state in TERMINAL and not scheduler[0]['text'].strip().startswith(job + '|')}
    if result['terminal'] and lock_free:
        result['delivery'] = terminal_archive(root)
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', required=True)
    p.add_argument('--nonce', required=True)
    p.add_argument('--chunk', type=int)
    p.add_argument('--archive-sha256')
    a = p.parse_args()
    result = collect(a.root, a.nonce, a.chunk, a.archive_sha256)
    raw = json.dumps(result, sort_keys=True, allow_nan=False).encode()
    print('SMALLFIT_RETURN_V01=' + base64.b64encode(zlib.compress(raw)).decode(), flush=True)


if __name__ == '__main__':
    main()
