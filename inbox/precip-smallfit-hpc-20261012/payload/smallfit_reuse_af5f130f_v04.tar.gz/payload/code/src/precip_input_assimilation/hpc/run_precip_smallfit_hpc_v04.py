"""Original supervisor with worker/test paths for exact-byte reuse.

Candidate only. No submission is performed here. The original actual family
lock, process ownership, budget settlement and IPC loop are unchanged.
"""
import ast
import copy
import hashlib
from pathlib import Path
import time
import sys
import types

ENTRY_STARTED = time.monotonic()
SUPERVISOR_SHA = '69f012f5010cc7fc83556c51e2728317dfb53056436e646c2cb7cdd791623f51'


def adapted_main(raw):
    if hashlib.sha256(raw).hexdigest() != SUPERVISOR_SHA:
        raise PermissionError('Original supervisor changed')
    fn = copy.deepcopy(next(n for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef) and n.name == 'main'))
    substitutions = {
        'payload/code/src/precip_input_assimilation/hpc/precip_smallfit_worker_v01.py':
            'payload/code/src/precip_input_assimilation/hpc/precip_smallfit_worker_v02.py',
        'payload/code/src/precip_input_assimilation/tests/test_hpc_smallfit_admission_v01.py':
            'payload/code/src/precip_input_assimilation/tests/test_hpc_smallfit_reuse_admission_v02.py',
    }
    changes = []
    for node in ast.walk(fn):
        if isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value in substitutions:
            changes.append(node.value)
            node.value = substitutions[node.value]
    if sorted(changes) != sorted(substitutions):
        raise PermissionError('Expected exactly the private worker and inherited-counter test paths')
    return ast.fix_missing_locations(ast.Module(body=[fn], type_ignores=[]))


def main():
    folder = Path(__file__).resolve().parent
    for name, expected in {
        'precip_smallfit_runtime_v01.py': '23cec65abd5b12ec1101a9fc0168d6eef20310f5debd84425d032842600b788f',
        'precip_smallfit_runtime_v02.py': '62e1bd957972030473d15f4fee86a37c732f59d3ae212caa80b41b7c63423d9d',
    }.items():
        if hashlib.sha256((folder / name).read_bytes()).hexdigest() != expected:
            raise PermissionError('Original runtime changed: ' + name)
    raw = (folder / 'run_precip_smallfit_hpc_v01.py').read_bytes()
    tree = adapted_main(raw)
    if __package__ in (None, ''):
        package = types.ModuleType('precip_input_assimilation')
        package.__path__ = [str(folder.parent)]
        sys.modules[package.__name__] = package
    from precip_input_assimilation.hpc import run_precip_smallfit_hpc_v01 as original
    from precip_input_assimilation.hpc.precip_smallfit_runtime_v02 import Authority
    from precip_input_assimilation.small_sample.hpc_reuse_admission_v01 import require_stopped_predecessor

    class Owner(original.Owner):
        def check(self):
            super().check()
            require_stopped_predecessor()

    class Budget(original.Budget):
        def __init__(self, root, manifest, owner):
            super().__init__(root, manifest, owner)
            self.started = self.slice_started = ENTRY_STARTED
            self.global_deadline = ENTRY_STARTED + manifest['remaining_seconds']

    namespace = dict(vars(original), Authority=Authority, Owner=Owner, Budget=Budget)
    exec(compile(tree, str(folder / 'run_precip_smallfit_hpc_v01.py') + ':reuse_v04', 'exec'), namespace)
    namespace['main']()


if __name__ == '__main__':
    main()
