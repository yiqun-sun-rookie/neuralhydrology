"""Four bounded stdlib-only checks; no numerical model is imported or run."""
import ast
import copy
import importlib.util
import json
from pathlib import Path
import sys
import types
import unittest

REPO = Path(__file__).resolve().parents[3]
SOURCE = REPO / 'src/precip_input_assimilation/small_sample'
FAMILY = REPO / 'results/precip_input_da_2026_09/effect_first_v01'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


package = types.ModuleType('_initfix_metadata_test')
package.__path__ = [str(SOURCE)]
sys.modules[package.__name__] = package
storage = load(package.__name__ + '.initial_bytes_v01', SOURCE / 'initial_bytes_v01.py')
repair = load(package.__name__ + '.hpc_initial_state_v02', SOURCE / 'hpc_initial_state_v02.py')
fit = load(package.__name__ + '.hpc_fit_v05', SOURCE / 'hpc_fit_v05.py')


class InitRepairChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (FAMILY / 'small_sample_gradient_20261010_v01/gradient_proofs/034_temporary_network_initial.pt').read_bytes()
        cls.summary = json.loads((REPO / 'results/psfit_26ac3faf_continuation_v03/records/sources/pilot_result.json').read_bytes())

    def test_real_preserved_initial_matches_original_pair(self):
        result = repair.validate_initial_bytes(self.raw, self.summary)
        self.assertEqual(result['parameter_sha256'], storage.PILOT_INITIAL_SHA256)
        self.assertEqual(sum(x['bytes'] for x in result['parameters']), 5633 * 4)
        self.assertTrue(result['output_layer_exact_positive_zero'])

    def test_corrupt_source_or_wrong_pair_is_rejected(self):
        with self.assertRaises(PermissionError):
            repair.validate_initial_bytes(self.raw[:-1] + bytes([self.raw[-1] ^ 1]), self.summary)
        changed = copy.deepcopy(self.summary)
        changed['fits'][0]['initial_tensors_sha256'] = '0' * 64
        with self.assertRaises(PermissionError):
            repair.validate_initial_bytes(self.raw, changed)
        with self.assertRaises(PermissionError):
            repair.paired_initial(self.summary, 1002)

    def test_fit_body_only_changes_two_factories_and_paired_metadata(self):
        raw = (SOURCE / 'fit_v04.py').read_bytes()
        old = next(n for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef) and n.name == 'optimize')
        changed = fit.adapted_ast(raw).body[0]
        # Normalize only the three intended expressions, then compare the
        # whole algorithm, including Adam, hard projection and stopping gates.
        def normalize(fn):
            fn = copy.deepcopy(fn)
            for node in ast.walk(fn):
                if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'expected' for t in node.targets):
                    node.value = ast.Constant('ORIGINAL_PAIRED_SUMMARY')
                if isinstance(node, ast.Call):
                    if isinstance(node.func, ast.Name) and node.func.id == 'network_for':
                        node.args = [node.args[2]]
                        node.func = ast.Name(id='ORIGINAL_INITIAL_FACTORY', ctx=ast.Load())
                    elif isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == 'ctx' and node.func.attr == 'new_network':
                        node.func = ast.Name(id='ORIGINAL_INITIAL_FACTORY', ctx=ast.Load())
            return ast.dump(fn, include_attributes=False)
        self.assertEqual(normalize(old), normalize(changed))
        with self.assertRaises(PermissionError):
            fit.adapted_ast(raw + b'\n')

    def test_no_numerical_library_or_execution_on_import(self):
        with self.assertRaises(PermissionError):
            fit.optimize(None, None, 'direct_control')
        self.assertFalse({'torch', 'numpy', 'pandas'} & set(sys.modules))
        for name in ('initial_bytes_v01.py', 'hpc_initial_state_v02.py', 'hpc_fit_v05.py', 'hpc_reuse_direct_audit_v02.py'):
            compile((SOURCE / name).read_bytes(), str(SOURCE / name), 'exec')


if __name__ == '__main__':
    unittest.main(verbosity=2)
