"""One guarded successor sbatch; preserve the failed predecessor without edits."""
import base64
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import tarfile
import time


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()


def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, sort_keys=True, indent=2)


def deploy(config):
    root = Path(config['remote_root'])
    parent = Path('/data1/home/sunyiq/precip_smallfit_hpc_20261012_v01')
    old = parent / '20261014T130222Z_a9e82e77_v01'
    if root.parent != parent or root.name != config['run_id'] or not re.fullmatch('[0-9a-f]{32}', config['nonce']):
        raise PermissionError('Not a unique owned continuation root')
    root.mkdir(exist_ok=True)
    if root.resolve() != root:
        raise PermissionError('Continuation root is redirected')
    (root / 'records').mkdir(exist_ok=True)
    with (root / 'records/submission.lock').open('a+b') as submission_lock:
        fcntl.flock(submission_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        submitted = root / 'records/submission.json'
        if submitted.exists():
            record = json.loads(submitted.read_bytes())
            if record['nonce'] != config['nonce'] or record['manifest_sha256'] != config['manifest_sha256']:
                raise PermissionError('Existing submission belongs to a different manifest')
            print('SUBMISSION_JSON=' + json.dumps(record), flush=True)
            return
        if (root / 'records/submission_attempt.json').exists():
            raise RuntimeError('Submission outcome already attempted; reconcile original job, never repeat sbatch')
        with (parent / 'exclusive.lock').open('r+b') as family:
            fcntl.flock(family, fcntl.LOCK_EX | fcntl.LOCK_NB)
            for p in (parent / 'STOP', old / 'STOP', root / 'STOP'):
                if p.exists():
                    raise InterruptedError('Manual STOP remains in force')
            q = subprocess.run(['sacct', '-S', '2026-10-14', '-X', '-j', '242474', '-n', '-P', '-o', 'JobIDRaw,State,ExitCode'],
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30)
            if q.returncode or not any(line.startswith(b'242474|FAILED|1:0') for line in q.stdout.splitlines()):
                raise PermissionError('Exact predecessor FAILED state not reconfirmed')
            queue = subprocess.run(['squeue', '-u', 'sunyiq', '-h', '-o', '%i|%j|%T|%Z'],
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30)
            if queue.returncode:
                raise RuntimeError('Cannot confirm absence of a parallel owned job')
            owned_active = [line for line in queue.stdout.decode().splitlines()
                            if '|psfit_' in line or str(parent) in line]
            if owned_active:
                raise PermissionError('An owned precipitation fit job is already active: ' + repr(owned_active))
            archive = Path.home() / 'hpc_mailbox/inbox/precip-smallfit-hpc-20261012/payload' / config['archive_name']
            if sha(archive) != config['archive_sha256']:
                raise PermissionError('Continuation archive changed')
            payload = root / 'payload'
            payload.mkdir()
            with tarfile.open(archive, 'r:gz') as tf:
                seen = set()
                for member in tf.getmembers():
                    rel = PurePosixPath(member.name)
                    if not member.isfile() or rel.is_absolute() or rel.parts[0] != 'payload' or '..' in rel.parts or member.name in seen:
                        raise PermissionError('Unsafe payload member')
                    seen.add(member.name)
                    dest = root.joinpath(*rel.parts)
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    if dest.resolve() != dest.absolute():
                        raise PermissionError('Payload path escaped')
                    with dest.open('xb') as f:
                        shutil.copyfileobj(tf.extractfile(member), f)
            if sha(payload / 'manifest.json') != config['manifest_sha256']:
                raise PermissionError('Manifest differs from approved continuation')
            manifest = json.loads((payload / 'manifest.json').read_bytes())
            if manifest['nonce'] != config['nonce'] or manifest['remote_root'] != str(root) or manifest['remaining_seconds'] != 57245:
                raise PermissionError('Continuation identity or remaining original budget changed')
            for path, expected in (
                (old / 'runtime/budget.json', manifest['predecessor_budget_sha256']),
                (old / 'runtime/counters/operation_counters_v04.json', manifest['predecessor_counter_head_sha256']),
                (old / 'runtime/final_supervisor_report.json', manifest['predecessor_final_sha256'])):
                if sha(path) != expected:
                    raise PermissionError('Actual predecessor evidence changed')
            final = json.loads((old / 'runtime/final_supervisor_report.json').read_bytes())
            if not final['numeric_process_exited'] or final['execution_complete']:
                raise PermissionError('Predecessor numerical group not confirmed failed and exited')
            for record in final['counter_snapshot']['receipts']:
                name = str(record['payload']['sequence']).zfill(6) + '_' + record['sha256'] + '.json'
                if (old / 'runtime/counters/events' / name).read_bytes() != (payload / 'counters/events' / name).read_bytes():
                    raise PermissionError('Original failed-job counter prefix changed')
            for row in manifest['files']:
                rel = PurePosixPath(row['path'])
                if rel.is_absolute() or '..' in rel.parts:
                    raise PermissionError('Escaping manifest member')
                path = payload.joinpath(*rel.parts)
                if path.is_symlink() or path.stat().st_size != row['bytes'] or sha(path) != row['sha256']:
                    raise PermissionError('Extracted continuation file changed')
            review_raw = base64.b64decode(config['review_base64'], validate=True)
            review = json.loads(review_raw)
            if review['status'] != 'PASS' or review.get('blocking_findings'):
                raise PermissionError('Continuation lacks independent review')
            for name, expected in review['source_identities'].items():
                if sha(payload / 'code' / name) != expected:
                    raise PermissionError('Reviewed continuation source differs')
            with (root / 'records/independent_continuation_review.json').open('xb') as f:
                f.write(review_raw)
            shutil.copyfile(old / 'records/private_dependencies.json', root / 'records/private_dependencies.json')
            if sha(root / 'records/private_dependencies.json') != manifest['dependency_manifest_sha256']:
                raise PermissionError('Private dependency provenance changed')
            # Separate paths, same immutable installed files; no shared environment writes or reinstall.
            shutil.copytree(old / 'pysite', root / 'pysite', copy_function=os.link)
            script = base64.b64decode(config['job_base64'], validate=True)
            if hashlib.sha256(script).hexdigest() != config['job_script_sha256']:
                raise PermissionError('Exact Slurm script changed')
            with (root / 'job.slurm').open('xb') as f:
                f.write(script)
            (root / 'logs').mkdir()
            attempt = {k: config[k] for k in ('nonce', 'manifest_sha256', 'archive_sha256', 'job_script_sha256', 'remote_root')}
            attempt.update(job_name='psfit_' + config['nonce'][:8], predecessor_job_id=242474,
                           observed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
            save(root / 'records/submission_attempt.json', attempt)
            # The compute supervisor takes this SAME nonblocking lock. Release
            # before sbatch so an immediate scheduler start cannot race us.
            # submission.lock and the durable attempt still prevent resubmission.
            fcntl.flock(family, fcntl.LOCK_UN)
            result = subprocess.run(['sbatch', str(root / 'job.slurm')], stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, timeout=45)
            with (root / 'records/sbatch_original_stdout.txt').open('xb') as f:
                f.write(result.stdout)
            print(result.stdout.decode(errors='replace'), flush=True)
            jobs = re.findall(rb'^Submitted batch job ([0-9]+)\s*$', result.stdout, re.M)
            if result.returncode or len(jobs) != 1:
                raise RuntimeError('No unique submission outcome; retain attempt and do not submit again')
            record = dict(attempt, job_id=int(jobs[0]), sbatch_returncode=result.returncode,
                          stdout_sha256=hashlib.sha256(result.stdout).hexdigest())
            save(submitted, record)
            print('SUBMISSION_JSON=' + json.dumps(record, sort_keys=True), flush=True)
            print('SMALLFIT_CONTINUATION_SUBMISSION_COMPLETE', flush=True)


if __name__ == '__main__':
    deploy(json.loads(base64.b64decode(os.environ['SMALLFIT_CONTINUATION_CONFIG'], validate=True)))
