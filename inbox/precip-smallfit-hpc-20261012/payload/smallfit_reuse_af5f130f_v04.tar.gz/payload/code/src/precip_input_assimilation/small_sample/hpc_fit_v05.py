"""Original fit algorithm with the exact saved initialization factory.

No optimizer, loss, seed, stopping threshold or historical artifact is changed.
For reuse of the completed direct stage, call the audit, not this optimizer.
"""
import ast
import copy
import hashlib
from pathlib import Path

ORIGINAL_SHA256 = 'efa3b5020122cb8345b4da9177b31755c0c6d06a004cbee5f73ca6eb23512752'


def adapted_ast(raw):
    if hashlib.sha256(raw).hexdigest() != ORIGINAL_SHA256:
        raise PermissionError('Original fitting source changed')
    tree = ast.parse(raw.decode('utf-8-sig'))
    function = copy.deepcopy(next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'optimize'))
    changes = []
    for node in ast.walk(function):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'network_for':
            if (len(node.args) != 4 or ast.literal_eval(node.args[0]) != 'rain'
                    or not isinstance(node.args[1], ast.Attribute) or node.args[1].attr != 'scaling'):
                raise PermissionError('Unexpected original network constructor')
            node.func = ast.Attribute(value=ast.Name(id='ctx', ctx=ast.Load()), attr='new_network', ctx=ast.Load())
            node.args = [node.args[2]]
            changes.append('exact_original_initializer')
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'expected' for t in node.targets):
            if not isinstance(node.value, ast.Call) or not isinstance(node.value.func, ast.Name) or node.value.func.id != 'read_json':
                raise PermissionError('Unexpected pilot-summary read')
            node.value = ast.Call(func=ast.Name(id='_paired_initial', ctx=ast.Load()), args=[
                ast.Attribute(value=ast.Name(id='ctx', ctx=ast.Load()), attr='original_summary', ctx=ast.Load()),
                ast.Name(id='seed', ctx=ast.Load())], keywords=[])
            changes.append('same_paired_summary_from_bound_context')
    if sorted(changes) != ['exact_original_initializer', 'exact_original_initializer', 'same_paired_summary_from_bound_context']:
        raise PermissionError('Original fitting adaptation count differs')
    return ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[]))


def optimize(ctx, recipe, kind):
    if kind != 'network':
        raise PermissionError('This repair reuses job242770 direct controls; direct optimization is forbidden')
    if getattr(ctx, 'seed_scope', None) != [1001] or recipe['seeds'] != [1001]:
        raise PermissionError('Only the declared seed1001 continuation is permitted')
    if not getattr(ctx, 'exact_seed1001_installed', False):
        raise PermissionError('Install the exact original initializer before numerical fitting')
    from . import fit_v04 as original
    from .hpc_initial_state_v02 import paired_initial
    # Catch initialization identity problems before the first fitted forward.
    preflight = ctx.new_network(1001)
    del preflight
    namespace = dict(vars(original), _paired_initial=paired_initial)
    path = Path(original.__file__)
    exec(compile(adapted_ast(path.read_bytes()), str(path) + ':exact_initial_v05', 'exec'), namespace)
    return namespace['optimize'](ctx, recipe, kind)
