"""Restore the original worker receipt envelope after the v01 IPC migration.

The inherited owner persists each operation exactly once. Only its return value
is adapted; the durable record, counters, budget and scientific code are intact.
"""
from precip_input_assimilation.hpc.precip_smallfit_runtime_v01 import Authority as OriginalAuthority


class Authority(OriginalAuthority):
    def handle(self, message):
        result = super().handle(message)
        if message["operation"] == "consume":
            return {"record": result,
                    "cumulative_count": result["payload"]["event"]["cumulative_count"]}
        return result
