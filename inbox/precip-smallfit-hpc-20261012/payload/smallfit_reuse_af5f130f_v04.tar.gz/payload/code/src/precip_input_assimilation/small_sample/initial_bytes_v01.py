"""Inspect saved tensor storage bytes without importing or executing a model.

Only serialization metadata is rebuilt. Float arrays are never materialized;
the original initialization fingerprint is computed from raw ZIP members.
"""
from collections import OrderedDict
import hashlib
import io
import math
import pickle
import zipfile

PARAMETERS = (
    ('encoder.weight_ih_l0', (96, 11)), ('encoder.weight_hh_l0', (96, 32)),
    ('encoder.bias_ih_l0', (96,)), ('encoder.bias_hh_l0', (96,)),
    ('decoder.0.weight', (32, 39)), ('decoder.0.bias', (32,)),
    ('decoder.2.weight', (1, 32)), ('decoder.2.bias', (1,)),
)
PILOT_INITIAL_SHA256 = '0851550494955db3b406f0e99059f757d2c172d45e58f7d621d6318a182766eb'
ORIGINAL_INITIAL_FILE_SHA256 = 'f1d46ad3c27ec2ad652888b68267ce45ea6250b2fb2ef5e6528283f112f6139e'


class TensorMetadata:
    def __init__(self, storage, offset, shape, stride, requires_grad, hooks, metadata=None):
        self.storage, self.offset = storage, offset
        self.shape, self.stride = tuple(shape), tuple(stride)


class MetadataReader(pickle.Unpickler):
    def find_class(self, module, name):
        if (module, name) == ('torch._utils', '_rebuild_tensor_v2'):
            return TensorMetadata
        if (module, name) == ('collections', 'OrderedDict'):
            return OrderedDict
        if module == 'torch' and name in ('FloatStorage', 'ByteStorage', 'LongStorage'):
            return name
        raise pickle.UnpicklingError('Unsupported metadata global: ' + module + '.' + name)

    def persistent_load(self, identity):
        if not isinstance(identity, tuple) or len(identity) != 5 or identity[0] != 'storage':
            raise pickle.UnpicklingError('Unexpected storage metadata')
        return identity


def initial_storage_bytes(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        names = archive.namelist()
        metadata = [n for n in names if n.endswith('/data.pkl')]
        if len(metadata) != 1 or len(names) != len(set(names)):
            raise PermissionError('Ambiguous tensor archive')
        prefix = metadata[0][:-len('data.pkl')]
        if archive.read(prefix + 'byteorder') != b'little':
            raise PermissionError('Unexpected stored byte order')
        data = MetadataReader(io.BytesIO(archive.read(metadata[0]))).load()
        state = data['state_dict']
        expected = ('cap',) + tuple(n for n, _ in PARAMETERS)
        if tuple(state) != expected:
            raise PermissionError('Original parameter/buffer names or order changed')
        result = {}
        for name, shape in (('cap', ()),) + PARAMETERS:
            tensor = state[name]
            if not isinstance(tensor, TensorMetadata):
                raise PermissionError('Missing tensor metadata')
            storage = tensor.storage
            stride = tuple(math.prod(shape[i+1:]) for i in range(len(shape)))
            if (storage[1] != 'FloatStorage' or tensor.offset != 0 or tensor.shape != shape
                    or tensor.stride != stride or storage[4] != math.prod(shape)):
                raise PermissionError('Original contiguous float32 tensor layout changed: ' + name)
            value = archive.read(prefix + 'data/' + str(storage[2]))
            if len(value) != 4 * math.prod(shape):
                raise PermissionError('Stored tensor byte count changed: ' + name)
            result[name] = value
        return result


def identity(raw):
    values = initial_storage_bytes(raw)
    return {
        'file_sha256': hashlib.sha256(raw).hexdigest(), 'file_bytes': len(raw),
        'parameter_sha256': hashlib.sha256(b''.join(values[n] for n, _ in PARAMETERS)).hexdigest(),
        'parameters': [{'name': n, 'shape': list(shape), 'bytes': len(values[n]),
                        'sha256': hashlib.sha256(values[n]).hexdigest()} for n, shape in PARAMETERS],
        'cap_bytes_hex': values['cap'].hex(),
        'output_layer_exact_positive_zero': all(values[n] == bytes(len(values[n]))
                                                 for n in ('decoder.2.weight', 'decoder.2.bias')),
        'numeric_model_imported': False, 'numeric_model_executed': False,
    }
