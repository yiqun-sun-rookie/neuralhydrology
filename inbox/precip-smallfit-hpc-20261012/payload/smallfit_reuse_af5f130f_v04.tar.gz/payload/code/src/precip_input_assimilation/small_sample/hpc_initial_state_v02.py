"""Exact seed1001 initialization from the preserved, pre-update original.

This module neither submits work nor runs on import. A caller must own the
HPC budget/counter authority and supply the byte-verified original checkpoint.
All historical source files and the original strict fingerprint remain intact.
"""
import hashlib
import io
import json
from pathlib import Path
import types
import uuid

from .initial_bytes_v01 import (ORIGINAL_INITIAL_FILE_SHA256, PARAMETERS,
                               PILOT_INITIAL_SHA256, identity)


def paired_initial(summary, seed):
    if seed != 1001:
        raise PermissionError('Only the originally authorized seed1001 is supported')
    rows = [row for row in summary['fits'] if row['seed'] == seed]
    if (len(rows) != 2 or {r['arm'] for r in rows} != {'original_penalties', 'no_penalties'}
            or any(r['initial_tensors_sha256'] != PILOT_INITIAL_SHA256 for r in rows)):
        raise PermissionError('Original paired seed1001 initialization binding differs')
    return next(row for row in rows if row['arm'] == 'no_penalties')


def validate_initial_bytes(raw, summary):
    paired_initial(summary, 1001)
    if hashlib.sha256(raw).hexdigest() != ORIGINAL_INITIAL_FILE_SHA256:
        raise PermissionError('Original pre-update seed1001 checkpoint bytes differ')
    proof = identity(raw)
    if (proof['parameter_sha256'] != PILOT_INITIAL_SHA256
            or not proof['output_layer_exact_positive_zero'] or proof['cap_bytes_hex'] != 'b3dd0042'):
        raise PermissionError('Original seed1001 tensor/cap/zero-output identity differs')
    return proof


def install_original_initialization(ctx, initial_path, source_root, evidence_root):
    """Install on this context only; never replace the global network factory."""
    from .saved_context_v04 import guarded_existing, require_full_preservation
    path = guarded_existing(initial_path, source_root)
    evidence_root = guarded_existing(evidence_root, evidence_root)
    raw = path.read_bytes()
    proof = validate_initial_bytes(raw, ctx.original_summary)
    require_full_preservation(ctx.require_unchanged)

    def create(this, seed):
        paired_initial(this.original_summary, seed)
        this.check()
        require_full_preservation(this.require_unchanged)
        current = guarded_existing(path, source_root).read_bytes()
        validate_initial_bytes(current, this.original_summary)
        # No numerical library is imported before the original byte gates.
        import torch
        from ..dynamic_filter_multibasin.controller import network_for
        from .support_v01 import source_initial_hash
        model = network_for('rain', this.scaling, seed, str(this.device))
        generated = source_initial_hash(model)
        saved = torch.load(io.BytesIO(current), map_location='cpu', weights_only=True)['state_dict']
        actual = model.state_dict()
        if (tuple(actual) != tuple(saved)
                or tuple(n for n, _ in model.named_parameters()) != tuple(n for n, _ in PARAMETERS)
                or any(actual[n].shape != saved[n].shape or actual[n].dtype != saved[n].dtype for n in saved)
                or not torch.equal(actual['cap'].detach().cpu(), saved['cap'])):
            raise PermissionError('Network schema/dtype or current scientific cap changed')
        model.load_state_dict(saved, strict=True)
        if source_initial_hash(model) != PILOT_INITIAL_SHA256:
            raise PermissionError('Restored original initialization fails its unchanged strict digest')
        if any(not torch.equal(v.detach().cpu(), saved[n]) for n, v in model.state_dict().items()):
            raise PermissionError('Restored full state differs from original tensor bytes')
        this.check()
        record = dict(proof, generated_before_restore_sha256=generated,
                      restored_sha256=source_initial_hash(model), seed=seed,
                      original_source_path=str(path), strict_original_gate_pass=True,
                      original_records_changed=False)
        target = evidence_root / ('initial1001_' + uuid.uuid4().hex + '.json')
        with target.open('x', encoding='utf-8') as handle:
            json.dump(record, handle, sort_keys=True, indent=2)
        return model

    ctx.new_network = types.MethodType(create, ctx)
    ctx.exact_seed1001_installed = True
    return proof
