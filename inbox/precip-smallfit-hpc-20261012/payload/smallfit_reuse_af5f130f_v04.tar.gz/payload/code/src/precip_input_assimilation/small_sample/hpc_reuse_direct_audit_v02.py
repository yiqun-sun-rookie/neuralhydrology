"""Re-audit immutable job242770 controls; never repeat its 650 fit updates.

The historical zero-output baseline keeps its own exact saved state. A further
charged original-initialization replay must strictly reproduce that baseline.
Execution requires a new explicitly admitted HPC authority; this is not a job
launcher, a result acceptance shortcut, or a modification of the old audit.
"""
import hashlib
import io
from pathlib import Path

from .initial_bytes_v01 import identity

ZERO_FILE_SHA256 = 'c1aa78febf811c4119a64f17c7be5e172bdbae14d73a292ad653b039e75432e8'
OLD_ROOT = Path('/data1/home/sunyiq/precip_smallfit_hpc_20261012_v01/20261015T062534Z_26ac3faf_v03/runtime/direct_control')


def audit_saved_direct(ctx, result):
    from .saved_context_v04 import guarded_existing, require_full_preservation
    from . import local_gradient_independent_v06 as audit
    from .hpc_fit_audit_v01 import audit_fit_stage
    import torch
    if (Path(ctx.output) != OLD_ROOT or result['stage'] != 'direct_control'
            or len(result['runs']) != 1 or result['runs'][0]['updates_completed'] != 650
            or result['runs'][0]['cumulative_scientific_updates'] != 650):
        raise PermissionError('Reuse is restricted to the preserved job242770 direct-control run')
    if not getattr(ctx, 'exact_seed1001_installed', False):
        raise PermissionError('Install the byte-verified original initializer before auditing')
    path = guarded_existing(OLD_ROOT / 'control/zero_network_baseline.pt', OLD_ROOT)
    rows = [r for r in result['fit_raw_artifacts'] if r['path'] == str(path)]
    raw = path.read_bytes()
    if (len(rows) != 1 or len(raw) != rows[0]['bytes']
            or hashlib.sha256(raw).hexdigest() != rows[0]['sha256']
            or rows[0]['sha256'] != ZERO_FILE_SHA256):
        raise PermissionError('Historical direct-control zero-baseline binding differs')
    proof = identity(raw)
    if not proof['output_layer_exact_positive_zero'] or proof['cap_bytes_hex'] != 'b3dd0042':
        raise PermissionError('Historical baseline lost its exact zero head or original cap')
    require_full_preservation(ctx.require_unchanged)
    original_factory = ctx.new_network
    outer_rng, frozen = audit._rng(), audit._frozen(ctx)
    calls = []

    def historical_factory(seed):
        # The strict original seed gate still runs; only the historical direct
        # baseline subsequently restores its separately bound original bytes.
        model = original_factory(seed)
        require_full_preservation(ctx.require_unchanged)
        current = guarded_existing(path, OLD_ROOT).read_bytes()
        if hashlib.sha256(current).hexdigest() != ZERO_FILE_SHA256:
            raise PermissionError('Historical baseline changed after admission')
        state = torch.load(io.BytesIO(current), map_location='cpu', weights_only=True)['state_dict']
        model.load_state_dict(state, strict=True)
        audit._require(all(torch.isfinite(v).all() for v in model.state_dict().values()), 'Nonfinite baseline')
        calls.append(seed)
        return model

    try:
        ctx.new_network = historical_factory
        # All saved trajectories, all 650 Adam reconstructions, the earliest
        # best reload and all original source/counter checks remain mandatory.
        report = audit_fit_stage(ctx, result)
        if report.get('pass') is not True or calls != [1001]:
            raise PermissionError('Complete historical audit or exact baseline call failed')
        ctx.new_network = original_factory
        reader = audit._Reader(ctx, result['fit_raw_artifacts'])
        inputs = audit._inputs(ctx, reader.read(OLD_ROOT / 'control/bound_inputs.pt'))
        zero = reader.read(path)
        model = original_factory(1001)
        with torch.no_grad():
            canonical = audit._independent_forward(ctx, model, inputs, label='original_seed1001_zero_baseline_bridge')
        audit._equal(canonical['trajectory'], zero['trajectory'], 'original seed1001 versus saved HPC zero baseline')
        report.update(historical_baseline_identity=proof, original_seed1001_baseline_bridge_pass=True,
                      direct_optimization_repeated=False, original_direct_updates_reused=650,
                      independent_model_replays=report['independent_model_replays'] + 1,
                      persistent_counters=ctx.operation_runtime.counter_snapshot())
        return report
    finally:
        ctx.new_network = original_factory
        audit._restore_rng(outer_rng)
        audit._equal(outer_rng, audit._rng(), 'reuse audit RNG restoration')
        audit._equal(frozen, audit._frozen(ctx), 'reuse audit frozen model invariance')
