"""Single authorized direct650 reuse submission, using the reviewed prior deployer.

Preparation never calls this entry. It requires an exact packet review and
explicit one-job authorization in addition to the original durable attempt.
"""
import ast
import base64
import hashlib
import json
import os
from pathlib import Path

DEPLOYER_SHA = '5a37ea9eb2509071514b3864811f657218c373c72a25d46dcec1fad292401c49'


def verify_predecessor_owner(old):
    owner = json.loads((old / 'runtime/owner.json').read_bytes())
    if (owner['status'] != 'STOPPED' or owner['nonce'] != '26ac3faff4e34c7ba4eea6e485377376'
            or str(owner['job_id']) != '242770'):
        raise PermissionError('Original stopped owner identity differs')
    process = Path('/proc') / str(owner['pid']) / 'stat'
    try:
        ticks = process.read_text().rsplit(')', 1)[1].split()[19]
    except FileNotFoundError:
        return
    if ticks == owner['creation_ticks']:
        raise PermissionError('Original owner remains alive')


def adapted_deployer(raw):
    if hashlib.sha256(raw).hexdigest() != DEPLOYER_SHA:
        raise PermissionError('Original single-attempt deployer changed')
    tree = ast.parse(raw)
    substitutions = {
        '20261014T130222Z_a9e82e77_v01': '20261015T062534Z_26ac3faf_v03',
        '2026-10-14': '2026-10-15', '242474': '242770',
        b'242474|FAILED|1:0': b'242770|FAILED|1:0', 242474: 242770, 57245: 44168,
    }
    counts = {key: 0 for key in substitutions}
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, (str, bytes, int)) and node.value in substitutions:
            key = node.value
            counts[key] += 1
            node.value = substitutions[key]
    if counts != {key: 1 for key in substitutions}:
        raise PermissionError('Unexpected predecessor/budget substitutions: ' + repr(counts))
    # The successor requires the exact-packet verdict, not the predecessor's
    # generic code-review verdict. Keep the original refusal and source gates.
    review_gates = [node for node in ast.walk(tree) if isinstance(node, ast.Compare)
                    and ast.unparse(node.left) == "review['status']"
                    and len(node.comparators) == 1
                    and isinstance(node.comparators[0], ast.Constant)
                    and node.comparators[0].value == 'PASS']
    if len(review_gates) != 1:
        raise PermissionError('Original independent-review verdict boundary changed')
    review_gates[0].comparators[0].value = 'PASS_EXACT_PACKET'
    # Query the actual creation identity while holding the original family lock.
    fn = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'deploy')
    found = 0
    for node in ast.walk(fn):
        if isinstance(node, ast.With) and any(isinstance(item.optional_vars, ast.Name)
                                           and item.optional_vars.id == 'family' for item in node.items):
            index = next(i for i, statement in enumerate(node.body) if isinstance(statement, ast.Assign)
                         and any(isinstance(target, ast.Name) and target.id == 'q' for target in statement.targets))
            node.body.insert(index, ast.parse('verify_predecessor_owner(old)').body[0])
            found += 1
    if found != 1:
        raise PermissionError('Original family-lock admission boundary changed')
    # Drop only its CLI entry; callers invoke the unchanged deploy function once.
    tree.body = [node for node in tree.body if not isinstance(node, ast.If)]
    return ast.fix_missing_locations(tree)


def deploy(config):
    if config.get('one_new_job_authorized') is not True or config.get('authorized_sbatch_calls') != 1:
        raise PermissionError('Explicit authorization for this one new continuation is required')
    review = json.loads(base64.b64decode(config['review_base64'], validate=True))
    if review.get('status') != 'PASS_EXACT_PACKET' or review.get('blocking_findings'):
        raise PermissionError('An independent exact-packet acceptance is required')
    for key in ('nonce', 'remote_root', 'manifest_sha256', 'archive_sha256', 'job_script_sha256'):
        if review.get('packet_identity', {}).get(key) != config[key]:
            raise PermissionError('Independent review does not bind this exact packet: ' + key)
    original = Path(__file__).with_name('deploy_precip_smallfit_continuation_v03.py')
    namespace = {'__name__': '_reviewed_reuse_deployer', 'verify_predecessor_owner': verify_predecessor_owner}
    exec(compile(adapted_deployer(original.read_bytes()), str(original) + ':reuse_v04', 'exec'), namespace)
    namespace['deploy'](config)


if __name__ == '__main__':
    deploy(json.loads(base64.b64decode(os.environ['SMALLFIT_CONTINUATION_CONFIG'], validate=True)))
