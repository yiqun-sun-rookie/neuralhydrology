"""Three metadata-only regressions for the observed receipt format failure."""
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

from precip_input_assimilation.hpc.precip_smallfit_runtime_v01 import Authority as OriginalAuthority
from precip_input_assimilation.hpc.precip_smallfit_runtime_v02 import Authority
from precip_input_assimilation.small_sample.flexible_budget_v04 import ALL_COUNTER_NAMES, CounterStore


class ReceiptRegression(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.store = CounterStore(Path(self.temp.name) / "counters",
                                  {"scope": "synthetic-receipt-check", "nonce": "fixture",
                                   "source_sha256": "a" * 64}, lambda: None)
        self.store.initialize({name: 0 for name in ALL_COUNTER_NAMES}, "b" * 64)

    def authority(self, cls):
        instance = cls.__new__(cls)
        instance.store = self.store
        instance.attempts = {}
        instance.manifest = {"run_id": "synthetic", "science_source_digest": "c" * 64}
        instance.budget = SimpleNamespace(tick=lambda: {"remaining_seconds": 500})
        return instance

    def message(self, kind, key):
        return {"operation": "consume", "kind": kind, "key": key, "label": "metadata-only",
                "attempt_id": key, "bindings": {}}

    def check_persisted_once(self, reply, counter, expected):
        self.assertEqual(set(reply), {"record", "cumulative_count"})
        self.assertIs(type(reply["cumulative_count"]), int)
        self.assertEqual(reply["cumulative_count"], expected)
        record = reply["record"]
        self.assertEqual(record["payload"]["event"]["counter"], counter)
        snapshot = self.store.snapshot()
        self.assertEqual(snapshot["counts"][counter], expected)
        self.assertEqual(snapshot["receipts"].count(record), 1)
        paths = list((self.store.root / "events").glob("*_" + record["sha256"] + ".json"))
        self.assertEqual(len(paths), 1)
        self.assertEqual(json.loads(paths[0].read_bytes()), record)

    def test_original_failure_then_preserved_forward_count(self):
        old = self.authority(OriginalAuthority)
        message = self.message("full_forward", "direct_control")
        raw = old.handle(message)
        self.assertIsNone(raw.get("cumulative_count"))  # Actual v01 failure contract.
        self.assertEqual(raw["payload"]["event"]["cumulative_count"], 1)
        fixed = self.authority(Authority)
        fixed.attempts = old.attempts
        reply = fixed.handle(message)
        self.check_persisted_once(reply, "fit_direct_full_forward", 2)
        self.assertIn(raw, self.store.snapshot()["receipts"])

    def test_direct_and_seed1001_update_receipts(self):
        fixed = self.authority(Authority)
        for key, counter in (("direct_control", "direct_science_update"),
                             ("seed_1001", "network_1001_science_update")):
            reply = fixed.handle(self.message("training_update", key))
            self.check_persisted_once(reply, counter, 1)

    def test_checkpoint_snapshot_and_errors_unchanged(self):
        fixed = self.authority(Authority)
        self.assertEqual(fixed.handle({"operation": "checkpoint"}), {"remaining_seconds": 500})
        self.assertEqual(fixed.handle({"operation": "counter_snapshot"}), self.store.snapshot())
        before = self.store.snapshot()
        with self.assertRaises(PermissionError):
            fixed.handle(self.message("training_update", "seed_1002"))
        self.assertEqual(self.store.snapshot(), before)


if __name__ == "__main__":
    unittest.main(verbosity=2)
