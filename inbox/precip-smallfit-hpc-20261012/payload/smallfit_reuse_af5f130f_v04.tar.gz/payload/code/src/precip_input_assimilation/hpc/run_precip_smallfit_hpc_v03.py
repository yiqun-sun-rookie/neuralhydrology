"""Receipt-fixed continuation, charging setup from this entry's first instant."""
import hashlib
from pathlib import Path
import time

ENTRY_STARTED = time.monotonic()


def main():
    folder = Path(__file__).resolve().parent
    expected = {
        "precip_smallfit_runtime_v01.py": "23cec65abd5b12ec1101a9fc0168d6eef20310f5debd84425d032842600b788f",
        "run_precip_smallfit_hpc_v01.py": "69f012f5010cc7fc83556c51e2728317dfb53056436e646c2cb7cdd791623f51",
        "precip_smallfit_runtime_v02.py": "62e1bd957972030473d15f4fee86a37c732f59d3ae212caa80b41b7c63423d9d",
    }
    for name, digest in expected.items():
        if hashlib.sha256((folder / name).read_bytes()).hexdigest() != digest:
            raise PermissionError("Reviewed implementation changed: " + name)
    from precip_input_assimilation.hpc import run_precip_smallfit_hpc_v01 as original
    from precip_input_assimilation.hpc.precip_smallfit_runtime_v02 import Authority

    class Budget(original.Budget):
        def __init__(self, root, manifest, owner):
            super().__init__(root, manifest, owner)
            self.started = self.slice_started = ENTRY_STARTED
            self.global_deadline = ENTRY_STARTED + manifest["remaining_seconds"]

    original.Authority, original.Budget = Authority, Budget
    original.main()


if __name__ == "__main__":
    main()
