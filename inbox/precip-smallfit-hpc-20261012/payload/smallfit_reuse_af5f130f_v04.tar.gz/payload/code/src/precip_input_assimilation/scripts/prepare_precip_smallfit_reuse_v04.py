"""Prepare the single direct650-reuse continuation; never submit or adopt a budget.

Only standard-library metadata and original bytes are read here. Full delivery
is a prerequisite, so a partial download cannot create a deployable packet.
Linux CounterStore verification remains in the reviewed HPC admission.
"""
import argparse
import ast
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import tarfile
import uuid

REPO = Path(__file__).resolve().parents[3]
FAMILY = REPO / 'results/precip_input_da_2026_09/effect_first_v01'
OLD = FAMILY / 'hpc_small_sample_20261015T062534Z_26ac3faf_v03'
MONITOR = OLD / 'monitoring'
OLD_REMOTE = '/data1/home/sunyiq/precip_smallfit_hpc_20261012_v01/20261015T062534Z_26ac3faf_v03'
OLD_NONCE = '26ac3faff4e34c7ba4eea6e485377376'
ARCHIVE_SHA = 'b5a585e152de663cca03a65c46d33f0903a6516c0f9a62e6077fdd1e0ab4f7aa'
FILE_MANIFEST_SHA = '689c5c3930f34d262bdbbdce48772158a387bdb95e80537f93ed3132efccf580'
CANDIDATE_SHA = 'f8de94017b67d9a5ab9fb7d2ad609fef2537682c62719cb006f9d65f0d123969'
REVIEW_SHA = '06c79e5ba08398bae191c06fdf3b36af10f9f4c901be95f49dcc0d260c4d4d3f'
BUDGET_SOURCE_SHA = 'fd38ecbd0b669a23665138574237ad383171b4249cfd40e36900658520387baa'
BUDGET_SHA = 'fe92c27a30ca97cf275e6734a735eb22f16e0478f0c82009833bf4dc6efeadf5'
LOCAL_BUDGET_SHA = '7435bc20dea45f3f0294ffe59f8691926e6dd9a9ead832134af9cd7aae8923f1'
STAGE_SHA = 'bdc19314ab6fd5da67548799b15316e62635a983d8f4d52dac11077de772cf34'
CONTROL_SHA = 'af465dcbc45e018ef73815e9b1521b453c159c72a3ebbae1683a6da9d6fb9300'
COUNTER_HEAD = 'baa30343f4501e60a25ad048ab349cc4a897dcb936a2121d34de67a66dacd794'
DELIVERY = {'archive_sha256': ARCHIVE_SHA, 'archive_bytes': 163376288,
            'files_verified': 15718, 'all_original_bytes_verified': True}


def native(path):
    path = Path(path).absolute()
    return '\\\\?\\' + str(path) if os.name == 'nt' else str(path)


def raw(path):
    with open(native(path), 'rb') as stream:
        return stream.read()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def checked(path, expected):
    data = raw(path)
    if sha(data) != expected:
        raise PermissionError('Original bytes changed: ' + str(path))
    return data


def put(path, data):
    os.makedirs(native(Path(path).parent), exist_ok=True)
    with open(native(path), 'xb') as stream:
        stream.write(data)


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def digest(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode())


def relative(name):
    p = PurePosixPath(name)
    if not name or p.is_absolute() or '..' in p.parts or '\\' in name or ':' in name or p.as_posix() != name:
        raise PermissionError('Noncanonical original member path')
    return Path(*p.parts)


def original_budget_reader():
    source = checked(REPO / 'src/precip_input_assimilation/scripts/run_precip_effect_first_v02.py', BUDGET_SOURCE_SHA)
    tree = ast.parse(source)
    functions = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in ('budget_hash', 'load_budget')]
    if len(functions) != 2:
        raise PermissionError('Original budget function selection changed')
    namespace = {'hashlib': hashlib, 'json': json, 'Path': Path}
    exec(compile(ast.Module(body=functions, type_ignores=[]), '<unchanged_original_budget_functions>', 'exec'), namespace)
    return namespace['load_budget']


def append(journal, event):
    event = dict(event, previous_sha256=journal['events'][-1]['sha256'])
    row = {'payload': event, 'sha256': digest(event)}
    journal['events'].append(row)
    return row


def successor_budget(original, local, run_id, nonce):
    if len(original['events']) != 44 or len(local['events']) != 43 or original['events'][:43] != local['events']:
        raise PermissionError('Exact original 43-event local prefix is required')
    budget = copy.deepcopy(original)
    gap_id = run_id + '/job242770_startup_gap'
    gap = append(budget, {'kind': 'reserve', 'run_id': gap_id, 'reserved_seconds': 13,
                         'reason': 'Slurm13077 minus original registered13064', 'job_id': '242770'})
    append(budget, {'kind': 'settle', 'run_id': gap_id, 'charged_seconds': 13,
                    'reservation_sha256': gap['sha256']})
    reservation = append(budget, {'kind': 'reserve', 'run_id': run_id + '/handoff',
                                  'reserved_seconds': 21600, 'clock_domain': 'hpc_entry_monotonic',
                                  'nonce': nonce, 'remaining_before_seconds': 44168})
    return budget, reservation


def sealed_payload(root=OLD):
    """Terminal delivery contains the old manifest, not its code/input payload."""
    packet = json.loads(raw(root / 'prepared_continuation_v03.json'))
    archive = Path(packet['archive'])
    expected = '39da7f0e9b6e7be94c15fb208b99abe3ee0e267ee30a780a66de13bbd4cdfc85'
    if (archive.stat().st_size != 3372945 or packet['archive_sha256'] != expected
            or sha(raw(archive)) != expected):
        raise PermissionError('Original submitted input archive changed')
    files = {}
    with tarfile.open(native(archive), 'r:gz') as stream:
        for member in stream.getmembers():
            rel = relative(member.name)
            if not member.isfile() or rel.parts[0] != 'payload' or len(rel.parts) < 2 or member.name in files:
                raise PermissionError('Original submitted archive member differs')
            files[member.name] = stream.extractfile(member).read()
    manifest_raw = files.pop('payload/manifest.json')
    manifest_sha = '717d3bbf33db47adee4274bddaec0e1cb084b711fdb775ce5f4a76441f6ee5b7'
    if sha(manifest_raw) != manifest_sha or packet['manifest_sha256'] != manifest_sha:
        raise PermissionError('Original submitted payload manifest differs')
    manifest = json.loads(manifest_raw)
    rows = manifest['files']
    if len(rows) != 735 or len({row['path'] for row in rows}) != 735:
        raise PermissionError('Original payload inventory differs')
    if set(files) != {'payload/' + row['path'] for row in rows}:
        raise PermissionError('Original submitted payload member set differs')
    for row in rows:
        relative(row['path'])
        data = files['payload/' + row['path']]
        if len(data) != row['bytes'] or sha(data) != row['sha256']:
            raise PermissionError('Original submitted payload member changed')
    return manifest_raw, {name[len('payload/'):]: data for name, data in files.items()}


def validate_originals(root=OLD):
    root = Path(root)
    # This gate is deliberately before any new identity, directory or budget.
    if json.loads(raw(root / 'terminal_delivery_verified.json')) != DELIVERY:
        raise PermissionError('Complete original delivery has not passed')
    state = json.loads(raw(root / 'monitor_state.json'))
    if not state['delivery_complete'] or state['pending_sequence'] is not None:
        raise PermissionError('Original transport has not closed its final receipt')
    archive = root / 'delivery/terminal_originals_v01.tar.gz'
    if archive.stat().st_size != DELIVERY['archive_bytes'] or sha(raw(archive)) != ARCHIVE_SHA:
        raise PermissionError('Complete original archive differs')
    with tarfile.open(native(archive), 'r:gz') as stream:
        manifest_raw = stream.extractfile('_FILE_MANIFEST.json').read()
    if sha(manifest_raw) != FILE_MANIFEST_SHA:
        raise PermissionError('Original full-file manifest differs')
    rows = json.loads(manifest_raw)
    if len(rows) != 15718 or len({row['path'] for row in rows}) != 15718:
        raise PermissionError('Original file manifest count or uniqueness differs')
    originals = root / 'received_originals'
    found = {Path(folder).joinpath(name).relative_to(Path(native(originals))).as_posix()
             for folder, _, names in os.walk(native(originals)) for name in names}
    if found != {row['path'] for row in rows}:
        raise PermissionError('Received original file set differs')
    for row in rows:
        data = raw(originals / relative(row['path']))
        if len(data) != row['bytes'] or sha(data) != row['sha256']:
            raise PermissionError('Received original member changed: ' + row['path'])
    submission = json.loads(raw(root / 'actual_submission.json'))
    owner = json.loads(raw(originals / 'runtime/owner.json'))
    final = json.loads(raw(originals / 'runtime/final_supervisor_report.json'))
    if (submission['job_id'] != 242770 or submission['nonce'] != OLD_NONCE
            or owner['status'] != 'STOPPED' or owner['nonce'] != OLD_NONCE or str(owner['job_id']) != '242770'
            or not final['numeric_process_exited'] or final['execution_complete']):
        raise PermissionError('Failed predecessor identity or complete exit differs')
    stage = json.loads(checked(originals / 'runtime/direct_control/stage_result.json', STAGE_SHA))
    checked(originals / 'runtime/direct_control/control/fit_result.json', CONTROL_SHA)
    if not stage['execution_complete'] or stage['technical_incomplete'] or stage['runs'][0]['updates_completed'] != 650:
        raise PermissionError('The original completed 650-update stage is required')
    snapshot = final['counter_snapshot']
    if (snapshot['event_count'] != 2189 or snapshot['head_sha256'] != COUNTER_HEAD
            or snapshot['counts']['direct_science_update'] != 650
            or snapshot['counts']['network_1001_science_update'] != 0):
        raise PermissionError('Completed counter snapshot differs')
    payload_manifest_raw, payload_files = sealed_payload(root)
    if raw(originals / 'payload/manifest.json') != payload_manifest_raw:
        raise PermissionError('Returned and original submitted payload manifests differ')
    old_events = {name: data for name, data in payload_files.items() if name.startswith('counters/events/')}
    if len(old_events) != 100:
        raise PermissionError('Original 100 counter event files are required')
    for name, data in old_events.items():
        if data != raw(originals / 'runtime' / relative(name)):
            raise PermissionError('Original 100-event raw prefix differs')
    checked(originals / 'runtime/budget.json', BUDGET_SHA)
    load_budget = original_budget_reader()
    budget, used, allocations, settled = load_budget(originals / 'runtime/budget.json')
    if used != 215019 or set(allocations) != set(settled):
        raise PermissionError('All original reservations must be settled')
    return originals, rows, budget, snapshot, payload_files


def prepare():
    for path in (FAMILY / 'STOP', OLD / 'STOP'):
        if path.exists():
            raise InterruptedError('Manual STOP remains in force')
    originals, original_rows, budget, snapshot, files = validate_originals()
    candidate_path = MONITOR / 'init1001_repair_candidate_v03/manifest.json'
    candidate = json.loads(checked(candidate_path, CANDIDATE_SHA))
    review = checked(MONITOR / 'heartbeat_20261016T080611Z_independent_reuse_review_v04.json', REVIEW_SHA)
    local_before = checked(FAMILY / 'cumulative_budget_v01.json', LOCAL_BUDGET_SHA)
    local = json.loads(local_before)
    old_manifest_raw = raw(originals / 'payload/manifest.json')
    old_manifest = json.loads(old_manifest_raw)
    if sha(old_manifest_raw) != '717d3bbf33db47adee4274bddaec0e1cb084b711fdb775ce5f4a76441f6ee5b7':
        raise PermissionError('Original payload manifest differs')
    nonce = uuid.uuid4().hex
    run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '_' + nonce[:8] + '_v04'
    out = FAMILY / ('hpc_small_sample_' + run_id)
    staging = REPO / 'results' / ('psfit_' + nonce[:8] + '_reuse_v04')
    out.mkdir()
    staging.mkdir()
    identity = {'run_id': run_id, 'nonce': nonce, 'remote_root': OLD_REMOTE.rsplit('/', 1)[0] + '/' + run_id,
                'local_root': str(out), 'channel': 'precip-smallfit-hpc-20261012', 'predecessor_job_id': 242770}
    # Reuse original payload inputs/code verbatim except the counter/budget handoff.
    files = {k: v for k, v in files.items() if not k.startswith('counters/')}
    for row in original_rows:
        if row['path'].startswith('runtime/counters/'):
            files[row['path'].replace('runtime/counters/', 'counters/', 1)] = raw(originals / relative(row['path']))
    new_budget, reservation = successor_budget(budget, local, run_id, nonce)
    files['records/budget_handoff.json'] = encode(new_budget)
    files['records/predecessor_closed_budget_original_bytes.json'] = raw(originals / 'runtime/budget.json')
    files['records/predecessor_final_original_bytes.json'] = raw(originals / 'runtime/final_supervisor_report.json')
    files['records/reuse_terminal_delivery.json'] = raw(OLD / 'terminal_delivery_verified.json')
    files['records/reuse_original_file_manifest.json'] = encode(original_rows)
    files['records/reuse_source_review.json'] = review
    initial = candidate['original_initial']
    files['records/original_seed1001_initial.pt'] = checked(initial['original_path'], initial['sha256'])
    for row in candidate['files']:
        files['code/' + row['path']] = checked(REPO / relative(row['path']), row['sha256'])
    for name in ('scripts/prepare_precip_smallfit_reuse_v04.py', 'hpc/deploy_precip_smallfit_reuse_v04.py'):
        data = raw(REPO / 'src/precip_input_assimilation' / name)
        ast.parse(data)
        files['code/src/precip_input_assimilation/' + name] = data
    rows = [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())]
    by_name = {row['path']: row for row in rows}
    manifest = dict(old_manifest, **identity, files=rows, remaining_seconds=44168,
                    budget_handoff_sha256=sha(files['records/budget_handoff.json']),
                    budget_reservation_id=reservation['payload']['run_id'], budget_reservation_sha256=reservation['sha256'],
                    counter_snapshot_digest=digest(snapshot), counter_head_sha256=COUNTER_HEAD, counter_event_count=2189,
                    science_source_digest=digest(rows), predecessor_remote_root=OLD_REMOTE,
                    predecessor_budget_sha256=BUDGET_SHA,
                    predecessor_counter_head_sha256=sha(raw(originals / 'runtime/counters/operation_counters_v04.json')),
                    predecessor_final_sha256=sha(files['records/predecessor_final_original_bytes.json']),
                    reuse_direct={'terminal_delivery': by_name['records/reuse_terminal_delivery.json'],
                                  'original_initial': by_name['records/original_seed1001_initial.pt']},
                    continuation_code_review_required=True)
    for name, data in files.items():
        put(staging / relative(name), data)
    put(staging / 'manifest.json', encode(manifest))
    parsed, used, alloc, settled = original_budget_reader()(staging / 'records/budget_handoff.json')
    if (parsed != new_budget or len(parsed['events']) != 47 or set(alloc) - set(settled) != {reservation['payload']['run_id']}
            or 259200 - used + 21600 != 44168):
        raise PermissionError('Prepared budget failed original parser')
    put(out / 'local_budget_before_original_bytes.json', local_before)
    put(out / 'local_owner_before_original_bytes.json', raw(FAMILY / 'local_gradient_flexible_owner_v04.json'))
    manifest_sha = sha(raw(staging / 'manifest.json'))
    template = checked(REPO / 'src/precip_input_assimilation/hpc/precip_smallfit_v01.slurm',
                       '55c357606071fb2ec47f200a155a5478e1568de95474c64fc748b6c4501b04f6').decode()
    for old, new in {'__JOB_NAME__': 'psfit_' + nonce[:8], '__RUN_ROOT__': identity['remote_root'],
                     '__REMAINING_TIME__': '12:16:08', '__MANIFEST_SHA256__': manifest_sha,
                     'run_precip_smallfit_hpc_v01.py': 'run_precip_smallfit_hpc_v04.py'}.items():
        if old not in template:
            raise PermissionError('Original Slurm substitution absent')
        template = template.replace(old, new)
    put(out / 'job.slurm', template.encode())
    archive = out / ('smallfit_reuse_' + nonce[:8] + '_v04.tar.gz')
    with tarfile.open(native(archive), 'w:gz') as stream:
        for row in rows + [{'path': 'manifest.json'}]:
            stream.add(native(staging / relative(row['path'])), arcname='payload/' + row['path'], recursive=False)
    packet = dict(identity, staging=str(staging), archive=str(archive), archive_sha256=sha(raw(archive)),
                  archive_bytes=archive.stat().st_size, manifest_sha256=manifest_sha,
                  job_script_sha256=sha(template.encode()), remaining_seconds=44168,
                  budget_reservation_id=reservation['payload']['run_id'], counter_event_count=2189,
                  payload_files=len(rows), direct_updates_reused=650, repeat_direct_optimization=False,
                  local_budget_adopted=False, new_submission_authorized=False, deployment_ready=False,
                  required_before_deployment=['independent exact-packet review', 'explicit one-job user authorization',
                                              'locked local budget handoff with preserved original bytes'])
    put(out / 'prepared_reuse_v04.json', encode(packet))
    print(json.dumps(packet))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--validate-only', action='store_true')
    args = parser.parse_args()
    if args.validate_only:
        originals, rows, budget, snapshot, payload_files = validate_originals()
        print(json.dumps({'complete_originals_verified': True, 'files': len(rows), 'counter_events': snapshot['event_count']}))
    else:
        prepare()
