"""Package a unique zero-update continuation from job242474's actual closed chain."""
import argparse
import ast
import copy
import hashlib
import json
import msvcrt
import os
from pathlib import Path, PurePosixPath
import sys
import tarfile
from datetime import datetime, timezone
import uuid

REPO = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO / 'src'))
from precip_input_assimilation.small_sample.flexible_budget_v04 import CounterStore, digest
from precip_input_assimilation.scripts.run_precip_effect_first_v02 import budget_hash, load_budget

FAMILY = REPO / 'results/precip_input_da_2026_09/effect_first_v01'
OLD = FAMILY / 'hpc_small_sample_20261014T130222Z_a9e82e77_v01'
NEW_FILES = [
    'hpc/precip_smallfit_runtime_v02.py', 'hpc/run_precip_smallfit_hpc_v03.py',
    'hpc/precip_smallfit_return_v01.py', 'hpc/deploy_precip_smallfit_continuation_v03.py',
    'scripts/monitor_precip_smallfit_hpc_v01.py', 'scripts/prepare_precip_smallfit_continuation_v03.py',
    'tests/test_hpc_smallfit_receipt_v02.py']


def native(p):
    return chr(92) * 2 + '?' + chr(92) + str(p.absolute())


def raw(p):
    with open(native(p), 'rb') as f:
        return f.read()


def put(p, data):
    os.makedirs(native(p.parent), exist_ok=True)
    with open(native(p), 'wb') as f:
        f.write(data)


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def append(journal, event):
    event = dict(event, previous_sha256=journal['events'][-1]['sha256'])
    row = {'payload': event, 'sha256': budget_hash(event)}
    journal['events'].append(row)
    return row


def prepare():
    nonce = uuid.uuid4().hex
    run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '_' + nonce[:8] + '_v03'
    out = FAMILY / ('hpc_small_sample_' + run_id)
    out.mkdir()
    staging = REPO / 'results' / ('psfit_' + nonce[:8] + '_continuation_v03')
    staging.mkdir()
    packet = json.loads(raw(OLD / 'prepared_payload_v02.json'))
    archive = Path(packet['archive'])
    if hashlib.sha256(raw(archive)).hexdigest() != packet['archive_sha256']:
        raise PermissionError('Original sealed payload archive changed')
    with tarfile.open(archive, 'r:gz') as tf:
        for member in tf.getmembers():
            rel = PurePosixPath(member.name)
            if not member.isfile() or rel.is_absolute() or rel.parts[0] != 'payload' or '..' in rel.parts:
                raise PermissionError('Unsafe original archive member')
            put(staging.joinpath(*rel.parts[1:]), tf.extractfile(member).read())
    old_manifest = json.loads(raw(staging / 'manifest.json'))
    if hashlib.sha256(raw(staging / 'manifest.json')).hexdigest() != packet['manifest_sha256']:
        raise PermissionError('Original manifest differs')
    for row in old_manifest['files']:
        data = raw(staging / row['path'])
        if len(data) != row['bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
            raise PermissionError('Original payload member changed')
    preserved = OLD / 'failed_job_242474_original_metadata_v01'
    original_final = json.loads(raw(preserved / 'runtime/final_supervisor_report.json'))
    snapshot = original_final['counter_snapshot']
    if snapshot['event_count'] != 100 or snapshot['counts']['gradient_full_forward'] != 94 or \
            snapshot['counts']['direct_science_update'] or snapshot['counts']['network_1001_science_update']:
        raise PermissionError('This continuation is only for the proven zero-update failure')
    for p in (preserved / 'runtime/counters').rglob('*.json'):
        put(staging / 'counters' / p.relative_to(preserved / 'runtime/counters'), raw(p))
    store = CounterStore(native(staging / 'counters'), old_manifest['counter_binding'], lambda: None)
    if store.snapshot() != snapshot:
        raise PermissionError('Complete actual100-event counter prefix did not reconstruct')
    budget_path = preserved / 'runtime/budget.json'
    journal, used, allocations, settled = load_budget(budget_path)
    if used != 201891 or set(allocations) - set(settled):
        raise PermissionError('Failed job budget not fully closed')
    local_before = raw(FAMILY / 'cumulative_budget_v01.json')
    local = json.loads(local_before)
    if journal['events'][:len(local['events'])] != local['events'] or len(journal['events']) != len(local['events']) + 1:
        raise PermissionError('Local budget does not match original failed-job handoff prefix')
    budget = copy.deepcopy(journal)
    gap_id = run_id + '/job242474_startup_gap'
    gap = append(budget, {'kind': 'reserve', 'run_id': gap_id, 'reserved_seconds': 64,
                         'reason': 'Slurm343 minus original registered279; preserve both observations', 'job_id': '242474'})
    append(budget, {'kind': 'settle', 'run_id': gap_id, 'charged_seconds': 64, 'reservation_sha256': gap['sha256']})
    reservation = append(budget, {'kind': 'reserve', 'run_id': run_id + '/handoff',
                                  'reserved_seconds': 21600, 'clock_domain': 'hpc_entry_monotonic',
                                  'nonce': nonce, 'remaining_before_seconds': 57245})
    remote = '/data1/home/sunyiq/precip_smallfit_hpc_20261012_v01/' + run_id
    identity = {'run_id': run_id, 'nonce': nonce, 'remote_root': remote, 'local_root': str(out),
                'channel': 'precip-smallfit-hpc-20261012', 'predecessor_job_id': 242474}
    put(out / 'deployment_identity.json', encode(identity))
    put(out / 'local_budget_before_original_bytes.json', local_before)
    put(out / 'local_owner_before_original_bytes.json', raw(FAMILY / 'local_gradient_flexible_owner_v04.json'))
    put(staging / 'records/budget_handoff.json', encode(budget))
    put(staging / 'records/predecessor_closed_budget_original_bytes.json', raw(budget_path))
    put(staging / 'records/predecessor_final_original_bytes.json', raw(preserved / 'runtime/final_supervisor_report.json'))
    for name in NEW_FILES:
        source = REPO / 'src/precip_input_assimilation' / name
        data = raw(source)
        ast.parse(data.decode('utf-8-sig'))
        put(staging / 'code/src/precip_input_assimilation' / name, data)
    rows = []
    for current, dirs, names in os.walk(native(staging)):
        for name in sorted(names):
            p = Path(current) / name
            rel = p.relative_to(Path(native(staging))).as_posix()
            if rel == 'manifest.json':
                continue
            data = p.read_bytes()
            rows.append({'path': rel, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    rows.sort(key=lambda r: r['path'])
    manifest = dict(old_manifest, **identity, files=rows,
                    budget_handoff_sha256=hashlib.sha256(raw(staging / 'records/budget_handoff.json')).hexdigest(),
                    remaining_seconds=57245, budget_reservation_id=reservation['payload']['run_id'],
                    budget_reservation_sha256=reservation['sha256'], counter_snapshot_digest=digest(snapshot),
                    counter_head_sha256=snapshot['head_sha256'], counter_event_count=100,
                    science_source_digest=digest(rows), predecessor_remote_root=old_manifest['remote_root'],
                    predecessor_budget_sha256=hashlib.sha256(raw(budget_path)).hexdigest(),
                    predecessor_counter_head_sha256=hashlib.sha256(raw(preserved / 'runtime/counters/operation_counters_v04.json')).hexdigest(),
                    predecessor_final_sha256=hashlib.sha256(raw(preserved / 'runtime/final_supervisor_report.json')).hexdigest(),
                    continuation_code_review_required=True)
    put(staging / 'manifest.json', encode(manifest))
    manifest_sha = hashlib.sha256(raw(staging / 'manifest.json')).hexdigest()
    template = raw(REPO / 'src/precip_input_assimilation/hpc/precip_smallfit_v01.slurm').decode()
    for old, new in {'__JOB_NAME__': 'psfit_' + nonce[:8], '__RUN_ROOT__': remote,
                     '__REMAINING_TIME__': '15:54:05', '__MANIFEST_SHA256__': manifest_sha,
                     'run_precip_smallfit_hpc_v01.py': 'run_precip_smallfit_hpc_v03.py'}.items():
        if old not in template:
            raise ValueError('Missing original Slurm substitution')
        template = template.replace(old, new)
    put(out / 'job.slurm', template.encode())
    archive = out / ('smallfit_continuation_' + nonce[:8] + '_v03.tar.gz')
    with tarfile.open(archive, 'w:gz') as tf:
        for row in rows + [{'path': 'manifest.json'}]:
            tf.add(native(staging / row['path']), arcname='payload/' + row['path'], recursive=False)
    packet = dict(identity, staging=str(staging), archive=str(archive),
                  archive_sha256=hashlib.sha256(raw(archive)).hexdigest(), archive_bytes=archive.stat().st_size,
                  manifest_sha256=manifest_sha, job_script_sha256=hashlib.sha256(template.encode()).hexdigest(),
                  budget_reservation_id=reservation['payload']['run_id'], remaining_seconds=57245,
                  counter_event_count=100, scientific_updates_before=0, payload_files=len(rows))
    put(out / 'prepared_continuation_v03.json', encode(packet))
    print(json.dumps(packet))


def commit(root):
    packet = json.loads(raw(root / 'prepared_continuation_v03.json'))
    manifest = json.loads(raw(Path(packet['staging']) / 'manifest.json'))
    lock = (FAMILY / 'exclusive.lock').open('r+b')
    lock.seek(0)
    msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
    try:
        for p in (FAMILY / 'STOP', OLD / 'STOP', root / 'STOP'):
            if p.exists():
                raise InterruptedError('Manual stop remains in force')
        current = raw(FAMILY / 'cumulative_budget_v01.json')
        if current != raw(root / 'local_budget_before_original_bytes.json'):
            raise PermissionError('Local budget changed since preparation; no second handoff')
        owner_path = FAMILY / 'local_gradient_flexible_owner_v04.json'
        if raw(owner_path) != raw(root / 'local_owner_before_original_bytes.json'):
            raise PermissionError('Local owner changed since preparation')
        budget = raw(Path(packet['staging']) / 'records/budget_handoff.json')
        put(root / 'budget_handoff_committed_original_bytes.json', budget)
        temp = FAMILY / ('budget_' + packet['nonce'] + '.partial')
        put(temp, budget)
        os.replace(temp, FAMILY / 'cumulative_budget_v01.json')
        owner = dict(packet, status='DELEGATED_HPC_PREPARING', predecessor_job_id=242474,
                     predecessor_failed_counter_head=manifest['counter_head_sha256'],
                     local_scientific_compute_started=False)
        temp = FAMILY / ('owner_' + packet['nonce'] + '.partial')
        put(temp, encode(owner))
        os.replace(temp, owner_path)
        print(json.dumps({'handoff_committed': True, 'reservation': packet['budget_reservation_id']}))
    finally:
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
        lock.close()


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--commit-handoff', type=Path)
    a = p.parse_args()
    commit(a.commit_handoff) if a.commit_handoff else prepare()
