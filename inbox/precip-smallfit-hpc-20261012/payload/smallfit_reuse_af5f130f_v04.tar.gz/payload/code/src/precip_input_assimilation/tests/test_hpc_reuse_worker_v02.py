"""Bounded orchestration checks without importing or running numerical models."""
import ast
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace, ModuleType
import unittest
from unittest.mock import Mock, patch

REPO = Path(__file__).resolve().parents[3]
package = ModuleType('precip_input_assimilation')
package.__path__ = [str(REPO / 'src/precip_input_assimilation')]
sys.modules[package.__name__] = package
from precip_input_assimilation.hpc import precip_smallfit_worker_v02 as worker
from precip_input_assimilation.hpc import run_precip_smallfit_hpc_v04 as supervisor
from precip_input_assimilation.small_sample import hpc_reuse_admission_v01 as admission


class ReuseWorkerChecks(unittest.TestCase):
    def exercise(self, root, direct_check):
        runtime = root / 'runtime'
        runtime.mkdir()
        contexts, calls = [], []
        old_root = root / 'predecessor'
        baseline = old_root / 'runtime/direct_control/control/initial_predictions.npy'
        baseline.parent.mkdir(parents=True)
        raw = b'original baseline bytes; decoded only by a test sentinel'
        baseline.write_bytes(raw)
        baseline_ref = {'path': str(baseline), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

        def create_context(root, manifest, client, output, stage):
            self.assertTrue(output.is_relative_to(runtime))
            # Real exclusive write catches accidental reuse of the old
            # create_context output directory, without any model loading.
            (output / 'context_identity.json').write_text('{}')
            ctx = SimpleNamespace(output=output, attempt_id='fresh_attempt', stage=stage,
                                  stage_outputs={'direct_control': root / 'runtime/direct_control'},
                                  require_unchanged=lambda: None)
            contexts.append(ctx)
            return ctx

        def fit(ctx, recipe, stage):
            calls.append(stage)
            self.assertEqual(stage, 'network')
            self.assertEqual(ctx.direct_control_output, old_root / 'runtime/direct_control')
            self.assertEqual(ctx.attempt_id, 'fresh_attempt')
            # Execute the UNCHANGED predecessor loader with sentinel decode
            # and filesystem guards, not a numerical library or model.
            source = (REPO / 'src/precip_input_assimilation/small_sample/fit_v04.py').read_bytes()
            fn = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef)
                      and n.name == 'load_predecessor_initial')
            scope = {'__package__': 'precip_input_assimilation.small_sample', 'Path': Path,
                     'hashlib': hashlib, 'io': io}
            exec(compile(ast.Module(body=[fn], type_ignores=[]), 'unchanged_predecessor_loader', 'exec'), scope)
            fake_numpy = ModuleType('numpy')
            sentinel = object()
            fake_numpy.load = Mock(return_value=sentinel)
            guards = ModuleType('precip_input_assimilation.small_sample.saved_context_v04')
            guards.guarded_existing = lambda path, base: path
            guards.require_full_preservation = lambda callback: callback()
            with patch.dict(sys.modules, {'numpy': fake_numpy, guards.__name__: guards}):
                self.assertIs(scope['load_predecessor_initial'](ctx, recipe), sentinel)
                broken = copy.copy(ctx)
                broken.stage_outputs = {'direct_control': root / 'runtime/direct_control'}
                with self.assertRaisesRegex(PermissionError, 'baseline root changed'):
                    scope['load_predecessor_initial'](broken, recipe)
            self.assertEqual(fake_numpy.load.call_count, 1)
            return {'execution_complete': True, 'runs': [{'seed': 1001}]}

        kwargs = dict(create_context=create_context, install_initial=Mock(),
                      audit_direct=Mock(return_value=direct_check), optimize_network=fit,
                      audit_network=Mock(return_value={'pass': True}))
        direct = {'window_uninformative': False, 'runs': [{'updates_completed': 650}], 'fit_raw_artifacts': [baseline_ref]}
        with patch.object(worker, 'checked_file', return_value=b'original'), patch.object(worker, 'OLD_ROOT', old_root):
            return worker.run_stages(root, {'recipe': {'seeds': [1001]}}, None, direct,
                                     root / 'payload/original.pt', **kwargs), calls, contexts

    def test_reuse_writes_only_new_records_then_runs_only_network(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            checks = {'pass': True, 'original_seed1001_baseline_bridge_pass': True,
                      'original_direct_updates_reused': 650, 'direct_optimization_repeated': False}
            reports, calls, contexts = self.exercise(root, checks)
            self.assertEqual(calls, ['network'])
            self.assertEqual(contexts[0].output, root / 'predecessor/runtime/direct_control')
            self.assertEqual(reports[0]['new_optimization_updates'], 0)
            self.assertTrue((root / 'runtime/direct_control_recheck/independent_fit_audit.json').is_file())
            self.assertFalse((root / 'runtime/direct_control').exists())

    def test_audit_or_zero_bridge_failure_stops_before_network(self):
        for failure in ({'pass': False}, {'pass': True, 'original_seed1001_baseline_bridge_pass': False}):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp).resolve()
                with self.assertRaisesRegex(RuntimeError, 'reuse audit'):
                    self.exercise(root, failure)
                self.assertFalse((root / 'runtime/network').exists())

    def test_reference_requires_exact_file_membership_and_original_bytes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            (root / 'payload').mkdir()
            path = root / 'payload/proof.json'
            raw = b'{"complete":true}'
            path.write_bytes(raw)
            ref = {'path': 'proof.json', 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
            manifest = {'reuse_direct': {'terminal_delivery': ref}, 'files': [ref]}
            self.assertEqual(admission.payload_reference(root, manifest, 'terminal_delivery')[1], raw)
            path.write_bytes(b'{"complete":false}')
            with self.assertRaises(PermissionError):
                admission.payload_reference(root, manifest, 'terminal_delivery')
            manifest['files'] = []
            with self.assertRaises(PermissionError):
                admission.payload_reference(root, manifest, 'terminal_delivery')

    def test_supervisor_changes_only_entry_paths_and_no_numerical_import(self):
        raw = (REPO / 'src/precip_input_assimilation/hpc/run_precip_smallfit_hpc_v01.py').read_bytes()
        original = next(n for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef) and n.name == 'main')
        adapted = supervisor.adapted_main(raw).body[0]
        old = 'payload/code/src/precip_input_assimilation/hpc/precip_smallfit_worker_v01.py'
        new = old.replace('_v01.py', '_v02.py')
        old_test = 'payload/code/src/precip_input_assimilation/tests/test_hpc_smallfit_admission_v01.py'
        new_test = old_test.replace('smallfit_admission_v01', 'smallfit_reuse_admission_v02')
        for node in ast.walk(adapted):
            if isinstance(node, ast.Constant) and node.value == new:
                node.value = old
            elif isinstance(node, ast.Constant) and node.value == new_test:
                node.value = old_test
        self.assertEqual(ast.dump(original, include_attributes=False), ast.dump(adapted, include_attributes=False))
        with self.assertRaises(PermissionError):
            supervisor.adapted_main(raw + b'\n')
        path = REPO / 'src/precip_input_assimilation/tests/test_hpc_smallfit_reuse_admission_v02.py'
        spec = importlib.util.spec_from_file_location('_reuse_admission_checks', path)
        checks = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(checks)
        old_tests = path.with_name('test_hpc_smallfit_admission_v01.py').read_bytes()
        fn = checks.adapted_counter_test(old_tests).body[0]
        originals = next(n for n in ast.parse(old_tests).body if isinstance(n, ast.ClassDef))
        original_fn = next(n for n in originals.body if isinstance(n, ast.FunctionDef) and n.name == fn.name)
        for node in ast.walk(fn):
            if isinstance(node, ast.Constant) and node.value == 650:
                node.value = 0
        self.assertEqual(ast.dump(fn, include_attributes=False), ast.dump(original_fn, include_attributes=False))
        self.assertFalse({'torch', 'numpy', 'pandas'} & set(sys.modules))
        root = REPO / 'results/precip_input_da_2026_09/effect_first_v01/hpc_small_sample_20261015T062534Z_26ac3faf_v03'
        stage = json.loads((root / 'latest_status.json').read_text())['records']['direct_control/stage_result.json']
        raw = (json.dumps(stage, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
        self.assertEqual(hashlib.sha256(raw).hexdigest(), admission.STAGE_SHA)
        control = next(r for r in stage['fit_raw_artifacts'] if r['path'].endswith('/control/fit_result.json'))
        self.assertEqual(control['sha256'], admission.CONTROL_RESULT_SHA)
        self.assertNotEqual(admission.STAGE_SHA, admission.CONTROL_RESULT_SHA)


if __name__ == '__main__':
    unittest.main(verbosity=2)
