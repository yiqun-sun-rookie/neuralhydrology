"""Recheck preserved direct650, then fit seed1001 from its exact initial bytes.

This is a candidate worker, not a launcher. It requires a fresh admitted
SLURM owner and cannot optimize the old direct-control stage.
"""
import argparse
import json
from pathlib import Path
import sys
import traceback
import types

# Standalone entry: the ordinary package __init__ imports numerical code.
# This task intentionally imports its explicit submodules after budget entry.
if __package__ in (None, ''):
    package = types.ModuleType('precip_input_assimilation')
    package.__path__ = [str(Path(__file__).resolve().parents[1])]
    sys.modules[package.__name__] = package

from precip_input_assimilation.hpc.precip_smallfit_runtime_v01 import RuntimeClient, sha, validate_exploration, write_json
from precip_input_assimilation.small_sample.hpc_reuse_admission_v01 import OLD_ROOT, STAGE_SHA, admit, checked_file, require_stopped_predecessor


def run_stages(root, manifest, client, direct, initial, *, create_context, install_initial, audit_direct,
               optimize_network, audit_network):
    """All new records/counters belong to root; old output is a read-only input."""
    reports = []
    output = root / 'runtime/direct_control_recheck'
    output.mkdir()
    ctx = create_context(root, manifest, client, output, 'direct_control')
    # create_context exclusively writes context_identity, so construct it in
    # the new root BEFORE selecting the historical audit input directory.
    ctx.output = OLD_ROOT / 'runtime/direct_control'
    ctx.preserved_stop_roots = (OLD_ROOT, OLD_ROOT.parent)
    install_initial(ctx, initial, root / 'payload', output)
    print('STAGE_BEGIN direct_control_saved_650_recheck', flush=True)
    check = audit_direct(ctx, direct)
    write_json(output / 'independent_fit_audit.json', check)
    if (check.get('pass') is not True or check.get('original_seed1001_baseline_bridge_pass') is not True
            or check.get('original_direct_updates_reused') != 650 or check.get('direct_optimization_repeated') is not False):
        raise RuntimeError('Original 650-update reuse audit did not pass completely')
    checked_file(OLD_ROOT / 'runtime/direct_control/stage_result.json', OLD_ROOT, STAGE_SHA)
    reports.append({'stage': 'direct_control', 'runs': direct['runs'], 'audit_pass': True,
                    'original_updates_reused': 650, 'new_optimization_updates': 0,
                    'source_root': str(ctx.output), 'source_result_sha256': STAGE_SHA,
                    'audit_sha256': sha(output / 'independent_fit_audit.json')})
    print('STAGE_COMPLETE direct_control_saved_650_recheck', flush=True)
    if direct['window_uninformative']:
        return reports
    output = root / 'runtime/network'
    output.mkdir()
    ctx = create_context(root, manifest, client, output, 'network')
    ctx.preserved_stop_roots = (OLD_ROOT, OLD_ROOT.parent)
    ctx.direct_control_output = OLD_ROOT / 'runtime/direct_control'
    ctx.stage_outputs['direct_control'] = ctx.direct_control_output
    ctx.direct_control_artifacts = direct['fit_raw_artifacts']
    install_initial(ctx, initial, root / 'payload', output)
    print('STAGE_BEGIN network_seed1001_exact_original_initial', flush=True)
    result = optimize_network(ctx, manifest['recipe'], 'network')
    write_json(output / 'stage_result.json', result)
    if not result['execution_complete']:
        raise RuntimeError('Seed1001 fitting did not complete its declared algorithm path')
    check = audit_network(ctx, result)
    write_json(output / 'independent_fit_audit.json', check)
    if check.get('pass') is not True:
        raise RuntimeError('Saved seed1001 fitting states failed independent reconstruction')
    reports.append({'stage': 'network', 'runs': result['runs'], 'audit_pass': True,
                    'audit_sha256': sha(output / 'independent_fit_audit.json')})
    print('STAGE_COMPLETE network_seed1001', flush=True)
    return reports


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--manifest-sha256', required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    path = root / 'payload/manifest.json'
    if sha(path) != args.manifest_sha256:
        raise PermissionError('Approved repair payload manifest changed')
    manifest = json.loads(path.read_text())
    client = RuntimeClient(root, manifest['nonce'])
    try:
        client.checkpoint(full=True)
        direct, initial = admit(root, manifest)
        audit_path = root / 'payload' / manifest['saved_sources']['completed_audit']['path']
        write_json(root / 'runtime/exploratory_admission.json', validate_exploration(json.loads(audit_path.read_text())))
        # Admission and the original supervisor budget precede numeric imports.
        from precip_input_assimilation.small_sample.hpc_saved_context_v01 import create_context
        from precip_input_assimilation.small_sample.hpc_initial_state_v02 import install_original_initialization
        from precip_input_assimilation.small_sample.hpc_reuse_direct_audit_v02 import audit_saved_direct
        from precip_input_assimilation.small_sample.hpc_fit_v05 import optimize
        from precip_input_assimilation.small_sample.hpc_fit_audit_v01 import audit_fit_stage
        reports = run_stages(root, manifest, client, direct, initial, create_context=create_context,
                             install_initial=install_original_initialization, audit_direct=audit_saved_direct,
                             optimize_network=optimize, audit_network=audit_fit_stage)
        client.checkpoint(full=True)
        require_stopped_predecessor()
        write_json(root / 'runtime/fit_execution_complete.json', {
            'execution_complete': True, 'seed_scope': [1001], 'stages': reports,
            'direct_optimization_repeated': False, 'original_job_id': 242770,
            'formal_forecast_improvement_established': False, 'original_full_gradient_gate': False,
            'original_three_negative_decisions_preserved': True, 'counter_snapshot': client.counter_snapshot()})
    except BaseException as error:
        write_json(root / 'runtime/worker_failure.json', {'type': type(error).__name__, 'error': str(error),
                   'traceback': traceback.format_exc(), 'fit_or_forecast_claim': False})
        raise
    finally:
        client.connection.close()


if __name__ == '__main__':
    main()
