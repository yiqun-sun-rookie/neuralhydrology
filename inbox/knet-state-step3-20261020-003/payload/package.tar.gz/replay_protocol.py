"""Clock and observation rules, independent of cross-host wall time."""
import re

MEMORY_ENV = ('SBATCH_MEM_PER_NODE', 'SBATCH_MEM_PER_CPU', 'SBATCH_MEM_PER_GPU')
TERMINAL = {'COMPLETED','FAILED','TIMEOUT','CANCELLED','OUT_OF_MEMORY','NODE_FAIL','PREEMPTED','BOOT_FAIL','DEADLINE','REVOKED'}

def submission_env(source):
    return {k:v for k,v in source.items() if k not in MEMORY_ENV}

def process_start_lower(proc_stat, ticks_per_second):
    # Fields after the final ') ' start at field 3; starttime is field 22.
    fields=proc_stat.rsplit(') ',1)[1].split()
    assert ticks_per_second>0
    return int(fields[19])/ticks_per_second

def batch_elapsed(boot_now, start_lower, ticks_per_second):
    lower=boot_now-start_lower-1/ticks_per_second
    upper=boot_now-start_lower
    if lower<0 or upper<lower:raise ValueError('Invalid same-node batch clock')
    return lower,upper

def progress_key(event):
    if event.get('event')=='training_segment_progress':return (event['arm'],'training',event['segments'])
    if event.get('event')=='validation_day_progress':return (event['arm'],'validation',event['days'])
    if event.get('event')=='phase_complete':return (event['arm'],event['phase'],event.get('segments',event.get('days')))
    return None


def validate_response(request,snapshot,controller,node):
    return bool(controller and snapshot and
        request['nonce']==snapshot.get('nonce') and
        request['job_id']==snapshot.get('job_id')==controller.get('job_id') and
        request['contract_sha256']==snapshot.get('contract_sha256')==controller.get('contract_sha256') and
        snapshot.get('controller_pid')==controller.get('pid') and
        snapshot.get('node')==controller.get('node')==node)

def assess(row,upper):
    if row['terminal']:return dict(status='TERMINAL_READY_FOR_COLLECTION',healthy=False)
    fields=row['scheduler_fields'];state=fields.get('JobState')
    if state=='PENDING' and fields.get('Reason') in ('Priority','Resources'):
        return dict(status='VERIFIED_QUEUED' if 0<=upper<=600 else 'MONITOR_FAILED',healthy=0<=upper<=600)
    if state!='RUNNING':return dict(status='MONITOR_FAILED',healthy=False,reason='Unknown scheduler state')
    c,w,snap=row.get('controller'),row.get('worker'),row.get('fresh_snapshot')
    request=dict(nonce=row.get('snapshot_nonce'),job_id=row['job_id'],contract_sha256=row['contract_sha256'])
    identity=validate_response(request,snap,c,fields.get('NodeList'))
    identity=identity and fields.get('Command')==row['script_path'] and fields.get('WorkDir')==row['remote_root']
    if not identity:return dict(status='MONITOR_FAILED',healthy=False,reason='Fresh nonce or identity evidence missing')
    resource=snap.get('resource');stat=row.get('resource')
    resource_ok=bool(resource and resource['combined_rss_bytes']<=6442450944 and resource['free_bytes']>=2147483648 and len(resource['affinity'])==1 and 0<=snap['resource_age_upper_seconds'] and upper+snap['resource_age_upper_seconds']<=600)
    if snap['phase']=='WAITING_FOR_HANDSHAKE':
        ok=resource_ok and 0<=upper<=600 and snap['batch_elapsed_upper_seconds']<=300
        return dict(status='VERIFIED_STARTUP_HANDSHAKE' if ok else 'MONITOR_FAILED',healthy=ok,science_started=False)
    worker_ok=bool(w and w['pid']==snap['worker_pid'] and w['controller_pid']==c['pid'] and w['job_id']==row['job_id'] and w['node']==snap['node'] and w['contract_sha256']==snap['contract_sha256'])
    age=snap.get('progress_age_upper_seconds')
    healthy=bool(worker_ok and resource_ok and 0<=upper<=600 and age is not None and age>=0 and upper+age<=600 and not snap['progress_regressions'])
    return dict(status='VERIFIED_REPLAY_PROGRESS' if healthy else 'MONITOR_FAILED',healthy=healthy,progress_age_upper_seconds=age,identity_verified=worker_ok,resource_verified=resource_ok)
