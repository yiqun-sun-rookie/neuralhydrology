"""Fixed call3 replay: saved proposal/gradients, zero Adam and backward."""
import os,sys,io,json,hashlib,time,datetime,traceback
from pathlib import Path
import safe_io as s
BASE=Path(__file__).resolve().parent

def main():
    assert os.environ.get('SLURM_JOB_ID','').isdigit()
    assert json.loads(sys.stdin.readline())['resources_configured']
    raw_contract=s.read_checked(BASE/'replay_contract.json')
    contract=json.loads(raw_contract)
    auth=json.loads(s.read_checked(BASE/'execution_authorization.json'))
    assert auth['status']=='AUTHORIZED'
    for row in auth['files']:s.read_checked(BASE/row['path'],row['sha256'])
    plan=contract['original_contract'];basin='02092500';coordinate=0
    conf=plan['basins'][0];began=time.monotonic();out='runs/02092500/attempt_001'
    import numpy as np
    import torch
    import random
    from training_math import guarded,candidate_gate
    from gap_math import project_gap,guard_gap
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    random.seed(plan['seed']);np.random.seed(plan['seed']);torch.manual_seed(plan['seed'])
    template=BASE.parents[1]/'template'
    manifest=json.loads(s.read_checked(template/'bundle_manifest.json',auth['template_manifest_sha256']))
    for row in manifest['files']:s.read_checked(template/row['path'],row['sha256'])
    os.chdir(template);sys.path.insert(0,str(template/'recipe'));os.environ['KNET_BASIN']='04105700'
    import common as C
    known={'basin_02092500.npz':'453d57eab87b0d774d5895f143d51c40644f9b92fd8702ce646a6f4841378eb6',
           'basin_02092500.json':'1d888ac7e396def5d6d435574ad4af91a8adb89bf17845c87f15c5a2f2f4b0a3'}
    registered={}
    for entry in json.loads(s.read_checked(template/'recipe/evaluation_sources.json'))['files']:
        source=Path(entry['path']);assert not source.is_absolute() and '..' not in source.parts
        path=(template/source).resolve();name=path.name
        if name not in known:continue
        assert path.is_relative_to(template/'recipe/workspace/results') and entry['sha256']==known[name]
        key=str(path).lower()
        if key in C.DIGESTS:assert C.DIGESTS[key]==entry['sha256']
        C.DIGESTS[key]=entry['sha256'];registered[name]=entry['sha256']
    assert registered==known
    from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
    from global_hydrology.experiments import daily_camels_ukf_knet_parity_runner as parity
    from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
    from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import AccessLedger,CAUSAL_SHARED_SPINUP_MODE
    def arr(x):return x.detach().cpu().numpy().copy()
    def plain(v):
        if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
        if isinstance(v,(list,tuple)):return [plain(x) for x in v]
        if isinstance(v,np.ndarray):return v.tolist()
        if isinstance(v,np.generic):return v.item()
        return v
    def put(name,value):return s.create(out+'/'+name,value if isinstance(value,bytes) else plain(value))
    def np_save(name,value):
        stream=io.BytesIO();np.savez_compressed(stream,**value);return put(name,stream.getvalue())
    def load_np(name):
        with np.load(io.BytesIO(s.read_checked(BASE/'inputs'/name)),allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
    def emit(event,**values):
        entry=dict(event=event,basin=basin,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-began)
        entry.update(plain(values));print(json.dumps(entry,allow_nan=False),flush=True)
    digest=C.helpers.digest_tree
    cp=torch.load(io.BytesIO(s.read_checked(BASE/'inputs/checkpoint_000.pt')),weights_only=True,map_location='cpu')
    runtime=per.load_per_basin_development_runtime(get_development_basin_specification(basin),ledger=AccessLedger(),initialization_mode=CAUSAL_SHARED_SPINUP_MODE,device='cpu')
    assert runtime.training_days==2557 and len(runtime.dates)==3288
    states=parity.training_open_loop_states(runtime)
    scales=parity.fit_training_feature_scales(runtime,floor=.1)
    per.fit_training_feature_scales=lambda r,*,floor=.1:scales
    TT=float(runtime.context.plain_model.params['parTT'])
    observations=arr(runtime.observations).reshape(-1);forcing=arr(runtime.forcing)
    dates=runtime.dates.astype('datetime64[ns]').astype('int64')
    thresholds=np.quantile(observations[:2557],[.5,.9,.99],method='linear')
    snapshot=load_np('input_snapshot.npz')
    for key,value in [('observations',observations),('forcing',forcing),('dates_ns',dates),('thresholds',thresholds),('training_open_loop',arr(states))]:
        np.testing.assert_array_equal(value,snapshot[key])
    def groups(y):return [np.ones(y.shape,dtype=bool),y<=thresholds[0],(y>thresholds[0])&(y<=thresholds[1]),y>thresholds[1]]
    training_counts=sum((np.array([m.sum() for m in groups(observations[start+np.arange(695,797)[:,None]+np.arange(1,4)])]) for start in plan['base_starts']),start=np.zeros(4,dtype=np.int64))
    assert training_counts[0]==7650 and np.all(training_counts>0)
    net=per.build_exact_dimension_kalman_net(runtime,zero_gain=False,seed=plan['seed'],gain_initialization='near_zero_fc2_head',hidden=24,input_multiplier=10,output_multiplier=10,feature_scale_floor=.1,normalized_feature_guard=10.,correction_cap_in_state_scale_units=3.)
    net.load_state_dict(cp['network'],strict=True)
    for p in net.parameters():p.requires_grad_(True)
    params=list(net.parameters());names=[n for n,p in net.named_parameters()]
    initialization=json.loads(s.read_checked(BASE/'inputs/initialization_gate.json'))
    assert names==initialization['trainable_names'] and sum(p.numel() for p in params)==63217
    state=dict(arm='replay',net=net,parameters=params,names=names,calls=0,effective=0,trace=None,count=0,step=3,phase='replay')
    native=net.analysis_step
    def wrapped(native,net,state):
        def update(y,u):
            previous=net.m1x_posterior;post=native(y,u);i=state['count'];state['count']+=1
            if i==650:
                state['boundary']={k:bool(getattr(net,k).grad_fn is not None) for k in C.probe.RECURRENCE_FIELDS}
            if state['trace'] is not None and i>=state['record_after']:
                state['trace'].append(dict(prior=net.m1x_prior,posterior=post,previous=previous,requested=net.last_correction,prior_flow=net.m1y.reshape(())))
            return post
        return update
    net.analysis_step=wrapped(native,net,state)
    def vector(state):return np.concatenate([arr(p).reshape(-1) for p in state['parameters']]).astype(np.float64)
    def install(state,values):
        offset=0
        with torch.no_grad():
            for p in state['parameters']:
                size=p.numel();p.copy_(torch.as_tensor(values[offset:offset+size].reshape(tuple(p.shape)),dtype=p.dtype));offset+=size
        assert offset==len(values)
    def state_mask(trace,start):
        previous=np.stack([arr(r['previous']).reshape(-1) for r in trace]);prior=np.stack([arr(r['prior']).reshape(-1) for r in trace]);ix=np.arange(start,start+len(trace))
        if coordinate==0:return (forcing[ix,0,1]>=TT)&(prior[:,0]<=0)
        return (forcing[ix,0,0]==0)&(previous[:,0]<=0)&(previous[:,1]<=0)&(observations[ix]<=thresholds[0])&(observations[ix]<=observations[ix-1])
    def state_values(trace,start,state):
        if coordinate==0:
            values=torch.stack([torch.relu((r['posterior']-r['prior'])[0,0]) for r in trace]);scale=float(state['net'].state_feature_scale[0,0])
        else:
            pf=torch.stack([r['prior_flow'] for r in trace]);values=torch.relu(pf-torch.as_tensor(observations[start:start+len(trace)],dtype=pf.dtype));scale=float(state['net'].observation_feature_scale.reshape(()))
        return values/scale
    masks={};state_count=0;validation_mask=None
    def training(state,gradient=False,freeze_masks=False,label='training'):
        nonlocal state_count
        net=state['net'];net.train();scores=np.zeros(9);g=np.zeros((9,len(vector(state)))) if gradient else None
        predictions=[];proxy=[];segment_gradient_norms=[];history_graph=[]
        for number,start in enumerate(plan['base_starts']):
            initial=runtime.context.initial_state.clone() if start==0 else states[start-1].clone()
            context=parity._context_with_initial_state(runtime.context,initial)
            batch=parity.WindowBatch(purpose='training_segment',global_start=start,global_end_exclusive=start+800,context=context,forcing=runtime.forcing[start:start+800],observations=runtime.observations[start:start+800],dates=runtime.dates[start:start+800],initial_state=initial,issue_start_local=695,issue_end_local=797)
            state['trace']=[];state['count']=0;state['record_after']=650
            with torch.set_grad_enabled(gradient):
                filtered=parity.run_knet_filter(net,batch,previous_observation=parity.previous_observation_before_window(runtime,batch))
                assert state['count']==800 and len(state['trace'])==150
                if gradient:assert any(state['boundary'].values()),'Full historical graph was lost'
                history_graph.append(dict(start=start,gradient=gradient,day650=state['boundary']))
                raw=runtime.tukf06_module.multilead_torch(batch.context.plain_model,filtered.posterior_states[:,0,:],batch.forcing)
                pred=torch.stack([raw[k][0][695:797] for k in (1,2,3)],dim=1)
                y=runtime.observations[start+torch.arange(695,797)[:,None]+torch.arange(1,4),0];error=pred-y;losses=[]
                for group,denom in zip(groups(arr(y)),training_counts):
                    selected=error[torch.as_tensor(group)];losses.extend([selected.square().sum()/int(denom),selected.abs().sum()/int(denom)])
                if freeze_masks:masks[start]=state_mask(state['trace'],start+650);state_count+=int(masks[start].sum())
                values=state_values(state['trace'],start+650,state);mask=torch.as_tensor(masks[start],dtype=torch.bool)
                # Initial mask discovery uses a sum; it is divided after the total count is known.
                target=values[mask].square().sum()/(1 if freeze_masks else state_count)
                objectives=losses+[target];scores+=np.array([float(x.detach()) for x in objectives])
                predictions.append(arr(pred));proxy.append(arr(values))
                if gradient:
                    needed=list(range(9)) if state['arm']=='state_constrained' else [0]
                    local=[]
                    for j,index in enumerate(needed):
                        pieces=torch.autograd.grad(objectives[index],state['parameters'],retain_graph=j<len(needed)-1,allow_unused=True)
                        flat=np.concatenate([np.zeros(p.numel()) if q is None else arr(q).reshape(-1) for p,q in zip(state['parameters'],pieces)])
                        g[index]+=flat;local.append(float(np.linalg.norm(flat)))
                    segment_gradient_norms.append(local)
            state['trace']=None
            emit('training_segment_progress',arm=state['arm'],step=state['step'],label=label,segments=number+1,total=25,gradient=gradient,optimizer_calls=state['calls'])
        if freeze_masks:
            assert state_count>0,'No untrained-origin fixed proxy events';scores[8]/=state_count
        if not np.isfinite(scores).all() or gradient and not np.isfinite(g).all():raise FloatingPointError('nonfinite objective or gradient')
        arrays=dict(prediction=np.stack(predictions),state_proxy_values=np.stack(proxy),state_mask=np.stack([masks[x] for x in plan['base_starts']]),scores=scores)
        if segment_gradient_norms:arrays['segment_gradient_norms']=np.array(segment_gradient_norms)
        if gradient and state['step'] in (1,121):put(state['arm']+f'/history_graph_{state["step"]:03d}.json',history_graph)
        return scores,g,arrays

    masks={int(k):v for k,v in load_np('fixed_training_masks.npz').items()}
    state_count=int(sum(v.sum() for v in masks.values()))
    proof=load_np('constrained_proposal_003.npz');before=proof['before'];G=proof['gradients'];proposal=proof['proposal'];f0=proof['pre_scores'];reference=proof['reference']
    assert G.shape==(9,63217)
    epoch=json.loads(s.read_checked(BASE/'inputs/constrained_epoch_003.json'))
    buffers={k:v.detach().clone() for k,v in net.named_buffers()}
    counters=dict(optimizer_calls=0,backward=0,training_continuation_updates=0,validation_replays=0,completed_replays=0,completed_segments=0,filter_days=0,qp_main=0,qp_guard=0,nonzero_temporary_installs=0,diagnostic_accepted_variants=0)
    results={};recoveries=[];cache={};failed=None;phase='recovery_pre'
    def restore(values):
        install(state,values)
        np.testing.assert_array_equal(vector(state),values.astype(np.float32).astype(np.float64))
        for k,v in net.named_buffers():assert torch.equal(v,buffers[k])
    def replay(name,values,expected=None):
        assert counters['completed_replays']<11
        restore(values)
        if np.any(values-before):counters['nonzero_temporary_installs']+=1
        state['arm']=name
        rng=torch.get_rng_state().clone()
        score,_,data=training(state,gradient=False,label=name)
        assert torch.equal(rng,torch.get_rng_state()),'RNG_CHANGED_DURING_FORWARD'
        for k,v in net.named_buffers():assert torch.equal(v,buffers[k])
        counters['completed_replays']+=1;counters['completed_segments']+=25;counters['filter_days']+=20000
        ident=np_save(name+'_training.npz',data)
        np_save(name+'_parameters.npz',dict(parameters=vector(state),actual=vector(state)-before))
        if expected is not None:
            want=load_np(expected)
            for k in ['prediction','state_proxy_values','state_mask','scores']:
                assert data[k].shape==want[k].shape and data[k].dtype==want[k].dtype
                np.testing.assert_array_equal(data[k],want[k],err_msg=name+'/'+k)
            recoveries.append(dict(name=name,status='EXACT_ARRAY_MATCH',archive=ident))
        return score,data
    try:
        restore(before)
        np.testing.assert_array_equal(vector(state),before)
        replay('recovery_pre',before,'constrained_training_003.npz')
        phase='recovery_reference'
        op=load_np('original_proposal_003.npz')
        replay('recovery_reference',op['before']+op['actual'],'original_training_003.npz')
        phase='recovery_H0'
        radius=2*float(np.linalg.norm(proposal))+float(np.finfo(np.float32).eps)
        counters['qp_guard']+=1
        x,guard=guarded(before,proof['exact'],G,radius,tolerance=1e-10)
        assert x is not None and guard['status']=='CERTIFIED','OLD_GUARD_RECONSTRUCTION_FAILED'
        installed=(before+x).astype(np.float32).astype(np.float64)
        old_score,_=replay('H0_factor1',installed,'constrained_candidate_003_1p0.npz')
        old_gate=candidate_gate(old_score,reference)
        assert old_gate==epoch['candidates'][0]['gate']
        put('H0_guard.json',guard)
        put('recovery_gate.json',dict(status='PASS',recoveries=recoveries,full_adam_restored=False,rng_epoch3_restored=False,scope='same-point forward replay only'))
        limits=np.r_[old_gate['flow_limits'],old_gate['state_limit']]
        geometry=dict(reference=reference,pre=f0,limits=limits,gradient_norms=np.linalg.norm(G,axis=1),radius=radius)
        put('geometry.json',geometry)
        for variant in ['F','FS']:
            phase=variant
            raw=limits-f0
            if variant=='F':raw[8]=0.
            counters['qp_main']+=1
            d,certificate=project_gap(proposal,G,raw)
            item=dict(raw_bounds=raw,main_certificate=certificate,accepted=False,candidates=[])
            results[variant]=item
            if d is None:item['status']='QP_UNRESOLVED';continue
            np_save(variant+'_main.npz',dict(direction=d,raw_bounds=raw))
            for alpha in [1.,.5,.25,.125]:
                label=variant+'_'+str(alpha).replace('.','p')
                counters['qp_guard']+=1
                x,cert=guard_gap(before,alpha*d,G,raw,radius)
                entry=dict(factor=alpha,guard=cert);item['candidates'].append(entry)
                if x is None:continue
                installed=(before+x).astype(np.float32).astype(np.float64)
                actual=installed-before;param_sha=hashlib.sha256(installed.tobytes()).hexdigest()
                np_save(label+'_direction.npz',dict(nominal=alpha*d,guarded=x,installed=installed,actual=actual,raw_bounds=raw))
                if param_sha in cache:
                    score=cache[param_sha]['score'];entry['reused_replay']=cache[param_sha]['name']
                else:
                    score,_=replay(label,installed);cache[param_sha]=dict(score=score,name=label)
                gate=candidate_gate(score,reference)
                entry.update(scores=score,gate=gate,parameter_sha256=param_sha,
                             actual_linear_changes=G@actual,observed_changes=score-f0,
                             nonlinear_remainder=score-f0-G@actual,actual_norm=float(np.linalg.norm(actual)))
                put(label+'_result.json',entry)
                if gate['accepted']:
                    item.update(accepted=True,accepted_factor=alpha,status='NONLINEAR_GATE_PASSED')
                    counters['diagnostic_accepted_variants']+=1
                    break
                restore(before)
            if not item['accepted']:item.setdefault('status','NO_ACCEPTED_CANDIDATE')
        restore(before)
        put('comparison.json',dict(results=results,counters=counters))
        status='MECHANISM_REPLAY_COMPLETE'
    except BaseException as exc:
        failed=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),phase=phase)
        put('failure.json',failed)
        status='RECOVERY_FAILED' if len(recoveries)<3 else 'REPLAY_FAILED'
    put('result.json',dict(status=status,job_id=os.environ['SLURM_JOB_ID'],family='SC-STEP3-REPLAY-01',basin=basin,call=3,counters=counters,recoveries=recoveries,results=results,failure=failed,total_optimizer_calls=0,total_effective_nonzero_steps=0))
    emit('replay_complete',status=status,counters=counters)
    return 0 if status=='MECHANISM_REPLAY_COMPLETE' else 1

if __name__=='__main__':raise SystemExit(main())
