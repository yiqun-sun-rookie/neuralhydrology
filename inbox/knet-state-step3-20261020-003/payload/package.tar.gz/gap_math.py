"""Affine RHS adapter and installed-float32 certification around frozen solver."""
import numpy as np
from training_math import project


def normalized_rows(gradients, raw_bounds):
    g = np.asarray(gradients, dtype=np.float64)
    b = np.asarray(raw_bounds, dtype=np.float64)
    assert g.ndim == 2 and b.shape == (len(g),)
    if not np.isfinite(g).all() or not np.isfinite(b).all():
        raise ValueError("NONFINITE_INPUT")
    n = np.linalg.norm(g, axis=1)
    keep = n > 0
    if np.any((~keep) & (b < 0)):
        return n, keep, None
    rhs = np.zeros(len(b))
    rhs[keep] = b[keep] / n[keep]
    return n, keep, rhs


def project_gap(proposal, gradients, raw_bounds, tolerance=1e-10):
    g = np.asarray(gradients, dtype=np.float64)
    n, keep, rhs = normalized_rows(g, raw_bounds)
    if rhs is None:
        return None, dict(status="ZERO_ROW_LOCAL_INFEASIBLE")
    d, record = project(proposal, g, bounds=rhs, tolerance=tolerance)
    record.update(raw_bounds=np.asarray(raw_bounds).tolist(), normalized_bounds=rhs.tolist())
    if d is None:
        return None, record
    active = record["active"]
    lam = np.asarray(record["multipliers"])
    residual = (g[keep] @ d - np.asarray(raw_bounds)[keep]) / n[keep]
    active_residual = (g[active] @ d - np.asarray(raw_bounds)[active]) / n[active]
    complementarity = float(np.max(np.abs(lam * active_residual))) if len(active) else 0.
    record["complementarity_residual"] = complementarity
    record["raw_recomputed_normalized_violation"] = max(0., float(residual.max())) if len(residual) else 0.
    if max(complementarity, record["raw_recomputed_normalized_violation"]) > tolerance:
        record["status"] = "UNRESOLVED"
        return None, record
    return d, record


def guard_gap(before, nominal, gradients, raw_bounds, radius, tolerance=1e-10):
    before = np.asarray(before, dtype=np.float64)
    g = np.asarray(gradients, dtype=np.float64)
    raw_bounds = np.asarray(raw_bounds, dtype=np.float64)
    n, keep, rhs = normalized_rows(g, raw_bounds)
    if rhs is None:
        return None, dict(status="ZERO_ROW_LOCAL_INFEASIBLE")
    lo = (before - radius).astype(np.float32)
    hi = (before + radius).astype(np.float32)
    gaps = np.maximum(np.abs(np.nextafter(lo, -np.inf, dtype=np.float32).astype(float) - lo),
                      np.abs(np.nextafter(hi, np.inf, dtype=np.float32).astype(float) - hi))
    guard_rhs = rhs.copy()
    guard_rhs[keep] -= (np.abs(g[keep]) / n[keep, None]) @ (.5 * gaps)
    # project_gap accepts RAW bounds, while frozen project accepts NORMALIZED bounds.
    guard_raw = np.zeros(len(g))
    guard_raw[keep] = guard_rhs[keep] * n[keep]
    x, certificate = project_gap(nominal, g, guard_raw, tolerance)
    if x is None:
        return None, dict(status="GUARD_QP_UNRESOLVED", certificate=certificate)
    installed = (before + x).astype(np.float32)
    actual = installed.astype(np.float64) - before
    changes = g @ actual
    violation = max(0., float(np.max((changes[keep] - raw_bounds[keep]) / n[keep]))) if np.any(keep) else 0.
    inside = bool(np.max(np.abs(x)) <= radius) if len(x) else True
    finite = bool(np.isfinite(installed).all() and np.isfinite(actual).all())
    valid = inside and finite and violation <= tolerance
    record = dict(status="CERTIFIED" if valid else "REJECTED_INSTALLATION",
                  certificate=certificate, radius=radius, inside_rounding_box=inside,
                  normalized_bounds=guard_rhs.tolist(), raw_target_bounds=raw_bounds.tolist(),
                  maximum_normalized_violation=violation, actual_linear_changes=changes.tolist(),
                  gradient_norms=n.tolist(), actual_norm=float(np.linalg.norm(actual)),
                  quantized_zero=bool(not np.any(actual)))
    return (x if valid else None), record
