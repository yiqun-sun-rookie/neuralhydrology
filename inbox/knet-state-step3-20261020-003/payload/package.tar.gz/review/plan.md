# SC-STEP3-PLAN-01：020首个拒绝点的固定现场机制回放计划

> **For agentic workers:** 后续实施按本文任务逐项进行；适用时使用 superpowers:executing-plans。当前交付为计划和一次独立审核，不执行本计划中的科学计算。

**Goal:** 在02092500第3次约束调用的同一个已保存现场，区分流量差距约束、状态局部限制和非线性误差对首次拒绝的作用。

**Architecture:** 直接使用旧档保存的参数、Adam提议、9项全历史梯度和同轮原版门槛。先复现固定现场和旧候选，再比较两个预先定义的约束变体；新优化器调用和反向传播均为0。

**Tech Stack:** Python / NumPy / PyTorch、原冻结KalmanNet/HBV模板、原active-set QP、Slurm CPU单线程。

**状态：PLAN_ONLY，execution_authorized=false，当前HPC提交/模型前向/Adam/backward/QP均为0。**

本轮已完成的是只读旧数组核对、内积计算和计划编制。用户指令为“给出下一步计划，独立审核一次”；科学回放属于后续执行范围。32份来源及SHA见 `evidence_manifest.json`，恢复核查见 `recovery_audit.json`，9项数值见 `saved_step3_geometry.csv`，复算脚本为 `inspect_saved_step3.py`。

## 1. 结论与为什么调整原方向

041初始化检查已经通过（245567、COMPLETED/0、103秒、49文件、两臂0调用/0改参），此处直接承接。首个运行期nonce快照缺失仍是独立工程问题。

020第3次调用是按训练期“首次拒绝”选定的唯一位置。旧第1、2次接受，第3次4个候选全部拒绝；这次不根据验证集选择轮次、因子或方法。

|第3次调用、高流量MSE|值|
|---|---:|
|约束臂pre|6.628728593370779|
|同轮原版允许上限|6.533336356874145|
|旧因子1候选|6.5352427034447755|
|候选超限|0.0019063465706308231|
|旧实际安装方向的一阶预测变化（旧guard记录）|-0.09951326056648613|
|保存轨迹的真实变化|-0.09348588992600337|
|真实变化减去一阶预测|0.006027370640482754|

这说明旧方向在高流量MSE上**一阶预测已经足以跨过门槛，但真实回放没有跨过**。因此不能把这次拒绝简单归结为“QP没有填补已有差距”，也不能预先认定加差距右端就会解决。

还有一条直接由保存数组得到的事实：原始Adam提议满足全部9条 `g·d <= L-f(pre)`；但它的状态代理一阶变化为正。若同时把状态右端从0改为正余量，则原始提议本身就是该主QP的零距离最优解。它通过真实状态门槛与否尚未知。

因此采用下述小对照：

|标识|8项流量线性右端|状态线性右端|回答的问题|
|---|---|---|---|
|H0 旧方案锚点|0|0|恢复现场与旧因子1候选是否可信|
|F 流量差距|`L_flow-f_flow(pre)`|0|只在流量侧补差距能否改变首次拒绝|
|FS 全差距|`L_flow-f_flow(pre)`|`L_state-f_state(pre)`|允许使用原有状态门槛余量后能否通过|

F相对H0只改变流量右端。FS相对F只改变状态右端；FS不能被称为“只补流量差距”的效果。此处全部流量pre超限，状态pre低于上限；FS不再保留旧局部状态不增条件，但保留原真实状态门槛。

## 2. 已恢复什么，什么尚未恢复

令 `S=../hpc_state_channel_scratch_20261017_001/`，`R=S/hpc_results/runs/02092500/attempt_001/`。未来输入只从本方案清单、原冻结模板及对应明确白名单读取。

|对象|当前直接证据|对下一步的影响|
|---|---|---|
|第3次调用前参数|`R/state_constrained/proposal_003.npz:before`，63217维；46个张量名称/顺序在`R/initialization_gate.json`|逐元素可恢复；已核epoch0→第1次→第2次→第3次pre参数链严格相同|
|该次Adam提议与梯度|同文件`proposal`、`gradients(9,63217)`；梯度来自完整25×800天历史|直接固定使用；不重新调用Adam或计算梯度|
|参数形状与固定buffer|`R/state_constrained/checkpoint_000.pt`|按已保存名称/shape填入before；buffer从epoch0取，真实回放前后逐项核对|
|训练输入和初始水文状态|`R/input_snapshot.npz`、原模板、`S/hpc_results/inputs/02092500/initial.pt`|强迫/观测/日期/OL逐项匹配；仅使用训练段，模板加载的验证数据不得进入评价或选择|
|固定mask与分组|`R/fixed_training_masks.npz`、输入快照thresholds、旧契约|原版epoch0 mask原样使用，不重选|
|同轮原版参考|`R/original/training_003.npz`及约束proof的reference严格相同|不重跑原版训练；未来只做一次原版第3步post参数的无梯度回放核对|
|旧pre轨迹|`R/state_constrained/training_003.npz`|第3次被拒，保存的就是pre轨迹；可用于恢复验收|
|旧被拒候选|`candidate_003_1p0.npz`保存轨迹，epoch JSON保存guard内积、证书|没有完整安装参数，必须经旧guard重建后回放验证，不能拿`alpha*exact`直接冒充|
|完整Adam/RNG|只有epoch0空Adam和RNG，后续仅有Adam摘要哈希；没有第2/3轮完整checkpoint|不宣称恢复了可继续训练的完整状态；本计划使用已存提议，根本不消费Adam状态|
|循环历史|冻结`run_knet_filter`每个800天片段调用`initialize_filter`，恢复水文初值、上一观测及循环状态|不能直接套用epoch0隐藏向量；用当前安装参数按原函数重新初始化每个片段，完整走800天|

冻结模板清单SHA：
`34afa64ad7f77df8dd365a16030c770e96b281da5ff2f0d8e48890a927b637d7`。
旧归档966文件验收仍保留；本轮只核所需文件与归档文件清单的SHA，不重传整包。

**恢复状态为“单步回放输入齐备，真实前向恢复尚未验证”。** 第3步RNG未直接保存，不把epoch0 RNG称作第3步RNG。未来使用同一冻结、无dropout的前向路径，记录前后RNG不变；任何新增随机算子或恢复不一致均停在恢复失败，不开始比较F/FS。整个方案不接续第4步训练。

## 3. 冻结的数学定义

按旧顺序使用9指标：overall/low/middle/high各MSE、MAE，最后状态代理。记 `p` 为已存Adam提议、`theta`为已存before、`G`为已存梯度、`f0`为已存无梯度pre分数、`r`为同轮原版post分数。

```
eps_i = max(1e-10, 1e-7*abs(r_i))
L_i   = 1.001*r_i + eps_i                 # i=0..7
L_8   = r_8 + eps_8
b_F   = [L_0-f0_0, ..., L_7-f0_7, 0]
b_FS  = L-f0
```

每个主QP解 `min_d 0.5*||d-p||²`，约束 `G d <= b`。不加罚项、可调系数或新学习率。实际调用旧 `project` 的bounds参数时须传**归一化右端**；旧函数内部只归一化梯度，不替调用者归一化bounds。

```python
# 计划中的核心接口；不在本轮运行。
def normalized_rows(G, raw_b):
    norms = np.linalg.norm(G, axis=1)
    if not np.isfinite(G).all() or not np.isfinite(raw_b).all():
        raise ValueError("NONFINITE_INPUT")
    keep = norms > 0
    if np.any((~keep) & (raw_b < 0)):
        return None, None, None, "ZERO_ROW_LOCAL_INFEASIBLE"
    rhs = np.zeros(len(raw_b), dtype=np.float64)
    rhs[keep] = raw_b[keep] / norms[keep]
    return norms, keep, rhs, "OK"
```

零梯度且负右端只证明该局部线性系统不可行；求解器返回UNRESOLVED只说明未得到数值证书。两者都不证明真实非线性问题全局不可行。当前保存的9项梯度范数均非零。

保留旧 `linear_normalized=1e-10`，KKT需逐项核原始行映射、乘子非负、原始/对偶残差、平稳性和互补性；证书未通过的方向不进入模型。不得把正常方程求解失败称为不可行证明。

**float32安装守卫也须使用相同的非零右端。** 固定原rounding-box半径 `radius=2*||p||₂+float32_eps`，不因F/FS失败加大半径；这沿用的是逐坐标舍入包络范围，不冒称L2信赖域。

对每一因子 `alpha ∈ [1,.5,.25,.125]`，以 `alpha*d` 为guard的名义目标，仍投影到同一个完整右端，不能将右端乘alpha。计算方式：

```
n_i = ||g_i||₂
a_i = g_i/n_i
rho_j = 0.5*max(float32向外ULP(theta_j-radius),
               float32向外ULP(theta_j+radius))
guard_rhs_i = b_i/n_i - sum_j |a_ij|*rho_j
x = project(alpha*d, G, bounds=guard_rhs)
theta_installed = float32(theta+x)
delta_installed = float64(theta_installed)-theta
```

检查`max(abs(x))<=radius`、所有值有限，并用**实际安装参数**重算 `max_i((g_i·delta_installed-b_i)/n_i)<=1e-10`。对零梯度行仍单独核raw_b。保存theta_installed完整向量；不能用名义x替代实际delta。guard返回的x可能不同于alpha*d，特别是负右端要求最小改善时，缩小名义目标并不保证实际步长缩小；如产生完全相同的安装向量，记录重复并复用同一回放结果，不当作多个独立证据。

每个变体按照固定因子顺序取首个满足原9项真实门槛的候选；未通过继续至最多4个，无扩展因子、补步或自动重试。所有候选都从同一个theta安装，不能累积更新。F与FS分别独立判定，即使F成功也完成FS的既定对照。

FS主QP中原始提议已满足全部仿射约束，数学上d=p、乘子全0即可验证；未来仍需经过同一float32守卫与真实回放。这项解析事实不算FS真实通过。

## 4. 最小执行顺序与输出

未来执行家族：`SC-STEP3-REPLAY-01`。
未来本地根：同级 `hpc_state_channel_step3_replay_20261020_001/`。
未来远端根：`/data1/home/sunyiq/knet_camels_hpc_20261012_001/attempts/state_channel_step3_replay_20261020_001`。
未来通道：`knet-state-step3-20261020-001`（尚未注册；执行时独占新建）。

### 任务A：封装恢复与候选生成

**新增文件及接口：**

- `replay_contract.json`：本方案的固定输入SHA、seed=20260922、调用3、两变体、预算和指标。
- `prepare_replay.py`：按本计划来源清单复制所需旧文件，写`source_manifest.json`、`source_diff.patch`及`registry.json`；不执行模型。
- `gap_math.py`：从归档`training_math.py`复制active-set求解器，新增`project_gap(proposal, gradients, raw_bounds)`与`guard_gap(before, nominal, gradients, raw_bounds, radius)`；按第3节定义处理raw/normalized bounds、零梯度和实际安装证书。
- `replay_worker.py`：`restore_point(inputs)`重建网络；`replay_training(network, fixed_inputs)`沿旧`training(..., gradient=False)`返回scores和全部训练数组；`run_variants(point)`输出固定比较结果。

- [ ] 根据新执行指令登记本次授权及送审计划/审核SHA；冻结一份新输入与代码清单。旧所有原件只读。
- [ ] 从原冻结模板按旧构造参数创建网络，按46个名称和shape把before写入float32参数；重新读出的向量须与before逐元素相同。
- [ ] 按旧训练函数走25个800天完整无梯度片段，issue 695:797、leads 1/2/3、7650个预测事件、原分组与mask；保持原020分数归约顺序，不将041新reducer混进此对照。
- [ ] 每次回放都按该参数重新调用`initialize_filter`，buffer前后逐项相同，RNG前后相同；前向设为旧`net.train()`并包`torch.no_grad()`，不启用随机新路径。
- [ ] 只对本次修改做三个小合成检查：右端尺度/零梯度、float32守卫、请求握手，合计本地≤60秒、RSS≤512MiB；不导入科学模型或做完整训练测试。

最小数学检查的固定例子：

```python
# project_gap接口在gap_math.py实现；生产9行，测试仅低维合成。
G = np.array([[2.0, 0.0]])
b = np.array([-2.0])
p = np.array([0.0, 0.0])
d, cert = project_gap(p, G, b)
assert cert["status"] == "KKT_VERIFIED"
np.testing.assert_allclose(d, [-1., 0.], rtol=0, atol=1e-10)
d2, _ = project_gap(p, 7*G, 7*b)
np.testing.assert_allclose(d2, d, rtol=0, atol=1e-10)
_, bad = project_gap(p, np.zeros((1, 2)), np.array([-1.0]))
assert bad["status"] == "ZERO_ROW_LOCAL_INFEASIBLE"
```

float32检查使用可精确表示before=`[1.,1.]`、`G=[[1.,0.]]`、raw_b=`[-1e-4]`、nominal=`[-2e-4,0]`、radius=`.01`：返回候选必须以实际float32安装位移核证；另用超出radius的单方向例子确认拒绝而非扩大radius。握手检查覆盖延迟超过原5秒后同nonce响应与错误JobId/nonce拒绝；用模拟时钟，不耗时等待。

### 任务B：在同一作业内先恢复、再比较

**新增文件：** `replay.slurm`、`replay_controller.py`、`query_replay.py`、`recovery_gate.json`、`geometry.json`、`candidate_*.npz`、`candidate_parameters_*.npz`、`comparison.json`。

- [ ] 完成第5节规定的一次运行期握手后才允许模型前向。
- [ ] **恢复核验1：约束pre。** 用已存before做1次完整训练回放，对照`state_constrained/training_003.npz`。
- [ ] **恢复核验2：原版参考。** 按`original/proposal_003.npz`的before+actual恢复原版第3步post，做1次完整训练回放，对照`original/training_003.npz`；不构造或调用Adam。
- [ ] **恢复核验3：旧H0因子1。** 从保存exact及原guard算法重建旧候选，保存完整重建安装参数并做1次回放，对照`candidate_003_1p0.npz`。旧参数未直接保存，状态明确标“重建回放匹配”，不能标“原参数文件已找回”。
- [ ] 三个核验要求prediction、state_proxy_values、state_mask及scores的shape、dtype、顺序和数组值逐元素相同；参数与buffer同样严格比较。失败即`RECOVERY_FAILED`，不靠放宽阈值继续。恢复严格相等的可达性待本次现场验证。
- [ ] 固定使用旧proof的G/p/f0/r，分别生成F和FS；每变体至多1次主QP、4次guard，逐一真实回放。主QP不通过则该分支标`QP_UNRESOLVED`，另一分支仍按原预算完成；某个guard失败只跳过该因子，无模型调用。
- [ ] 比较每项`g·delta`、真实`f(candidate)-f0`、线性剩余裕量、真实门槛裕量，以及二者之差；所有结果保留，尤其是状态代理是否增加、流量门槛是否失败。
- [ ] 各变体首个全门槛通过因子记为诊断accepted；完成后恢复theta，不继续训练，不把临时安装次数当Adam更新。

最多3次恢复回放+F最多4次+FS最多4次，共**11次完整无梯度训练回放、275片段、220000个滤波日步**，另计多提前期forecast运算；不称为220000次优化器调用。若安装参数完全重复，可减少真实回放次数，保留各因子映射。

最多11次QP求解调用：H0 guard 1次，F/FS各主QP1次+guard4次；FS若直接验证p证书则少1次。每次active-set穷举至多512个子集，无额外搜索。任何求解耗时都计入总墙钟。

预算计数必须分别报告：完整/未完成回放、片段与滤波日步、QP主求解/guard调用、候选临时非零安装、诊断接受候选。**新增Adam=0、backward=0、训练继续更新=0、验证回放=0。**

### 任务C：收档和报告

**新增文件：** `collect_terminal.py`、`collection/verified.json`、`analysis/第3次调用机制回放_交付.md`。

- [ ] 沿既有8MiB分片收档协议，收新契约/源码/提交回执/原生终态/资源/模型结果/恢复数组/所有候选完整参数与轨迹/证书；总包、分片和文件清单SHA一致才标完整。
- [ ] 科学判定由保存数组、真实安装参数与证书支持；原生COMPLETED/0与包完整单独列。
- [ ] 固定报告H0、F、FS全9指标；列原版参考、pre、线性预测、非线性实际、每因子去向和计数。
- [ ] 不追加验证集评价。报告只回答这个固定训练现场，后续长期训练与泛化需要新方案。

## 5. 工程预算与监护修复

- 一个非数组作业，一次提交，无requeue；`hgpu4`、1节点/1 task/1 CPU、一个科学worker、数学线程1、CPU affinity绑定、nice=10、无GPU。
- **新作业总墙钟3600秒**，包含环境激活、握手、恢复、全部QP/回放与失败；3540秒停止科学工作，最多60秒收尾，Slurm一小时硬限。排队与终态后传输单列。这个上限是有限诊断预算，不是保证11次回放能完成的估算。
- 内存由平台自动分配，不写`--mem`或`--mem-per-*`，清除本次提交环境中的内存注入项；合计RSS停止阈值6GiB，available下限2GiB。不得把保护阈值说成已预留内存。
- 计时沿已通过的batch shell启动ticks与同节点CLOCK_BOOTTIME；保留原生RunTime=INVALID，终态核ElapsedRaw，不用跨主机UTC差校正。
- 监护修复仅在自有目录：请求原子写入统一的`monitor_exchange`；控制器从启动阶段开始响应，保存请求发现/解析/响应落盘事件及失败原因，不等科学worker开始后才处理。
- 查询端把5秒等待改为最多60秒，期间同nonce持续观察，不产生新查询号。响应必须匹配JobId、目录、contract SHA、nonce、控制器身份；ready阶段worker PID可以为null，不能据此宣称科学启动。
- 同一个作业在模型启动前，需查询端见到该响应后写入同nonce的`start_allowed`确认；控制器核对后放行。等待与激活合计最多300秒，仍计总墙钟；逾期记录`MONITOR_STARTUP_FAILED`并收档，不另投工程试验。
- 模型阶段通常每2分钟查询；一次未收齐只续同号。新nonce响应的往返上界加同节点进度年龄须≤600秒；控制器心跳不替代已完成片段。运行中监护失败保留原记录并诊断，不冒称连续监护通过；资源与墙钟控制继续由本作业控制器/Slurm执行。
- 准备阶段仅做上述三个小检查；不重复041初始化或旧传输套件，不动共享receiver/锁或旧暂停自动化。若受预算、恢复、监护或数值阻断，本批交付实际完成部分，不加预算、不自动重新提交。

## 6. 预先固定的结论分支

|结果|可以得出的结论|接下来|
|---|---|---|
|恢复不匹配|当前不能做可信的同现场对照|定位恢复差异；本批停止F/FS|
|F通过真实9项门槛|在保持局部状态不增的条件下，流量差距约束修复了这个首次拒绝点|记录单步机制证据，后续再设计短序列检验|
|F失败、FS通过|支持状态局部限制与当前可用门槛余量之间的矛盾参与了该点拒绝|明确这是状态条件变化的效果，不能宣传为纯流量补差距成功|
|F、FS均通过|分别报告，不按验证挑胜者|比较真实状态变化与线性误差；不据一次通过确定长期方案|
|线性/安装证书通过、真实回放失败|该候选的一阶局部模型不足以保证真实门槛|记录具体失败指标与非线性剩余；本批不临时拟合曲率或调安全系数|
|数值求解未核证、半径超限、零梯度负缺口|分别报告数值未知、固定包络失败或局部线性不可行|不推断全局不可行，不扩搜索|
|资源/时间/采集不完整|没有完成约定证据链|保留实际计数和失败，不把部分结果说成整批成功|

无独立雪储量真值；状态代理通过不等于雪储量更准确。共同轮76、固定121缺失及旧48小时失败结论均不因本试验改变。

## 7. 本轮独立审核与交付

- 作者将此文件及`recovery_audit.json`、`saved_step3_geometry.csv`、`evidence_manifest.json`绑定SHA提交给一名新独立审核者。
- 审核者自行读取计划、关键旧源码及数组，检查恢复边界、F/FS因果区别、非零右端归一化、float32守卫、非线性验收、预算与监护；只做证据读取/已有数组算术，不运行模型、优化器、新QP、远端或自动化。
- 审核仅一轮，输出`independent_review.md/json`，给出PASS/REVISE/BLOCKED、阻断数、定位证据及送审SHA。作者保存`review_response.md`；如有修订，保留送审稿与原审核，不声称审核覆盖未读的新版本，不自动做第二轮审核。
- 审核通过代表方案成立且可进入后续实施准备，不代表实现已验证或科学机制有效；本轮不生成“已授权执行”登记。

白话总结：先在020第一次卡住的现场做一个小对照，查清是流量差距、状态限制，还是线性预测不准在起作用。直接用旧档里的提议和梯度，新增Adam调用为0。
