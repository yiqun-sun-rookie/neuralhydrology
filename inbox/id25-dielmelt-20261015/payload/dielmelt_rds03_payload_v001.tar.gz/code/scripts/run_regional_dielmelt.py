"""One zero-training RDS03 forward contrast; 2008 gates precede any application read."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from id25.regional_daily_storage_dielmelt import RegionalDailyStorageDielMelt, positive_temperature
from id25.regional_storage_observation import center_on_fit_windows, project_storage


def now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    temp = path.with_suffix('.pending')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    temp.replace(path)


def read_npz(path):
    with np.load(path, allow_pickle=False) as z:
        return {k: z[k] for k in z.files}


def describe(p, y):
    p, y = np.asarray(p, dtype=float), np.asarray(y, dtype=float)
    if not np.isfinite(p).all() or not np.isfinite(y).all():
        raise ValueError('Nonfinite predictions or targets')
    if np.any(y.std(0) <= 1e-6):
        raise ValueError('Nonvarying storage targets')
    ratio = p.std(0) / y.std(0)
    # A zero predicted amplitude fails the amplitude gate without hiding it in JSON Infinity.
    amplitude = np.abs(np.log(np.maximum(ratio, np.finfo(float).tiny)))
    return dict(pooled_rmse_cm=float(np.sqrt(np.mean((p-y)**2))),
                regional_rmse_cm=np.sqrt(np.mean((p-y)**2, axis=0)).tolist(),
                regional_bias_cm=(p-y).mean(0).tolist(), sd_ratio=ratio.tolist(),
                absolute_log_sd_ratio=amplitude.tolist(), residual_count=int(p.size))


def integrity(initial, states, fluxes, precip):
    previous = torch.cat([initial.sum(1)[None], states[:-1].sum(-1)])
    residual = states.sum(-1) - previous - precip + fluxes[...,1] + fluxes[...,2]
    return dict(finite=bool(torch.isfinite(states).all() and torch.isfinite(fluxes).all()),
                minimum_stock_mm=float(states.min()), max_daily_balance_residual_mm=float(residual.abs().max()))


def save_states(path, dates, ids, daily, states, fluxes):
    np.savez_compressed(path, dates=dates, region_ids=np.array(ids), daily_mean_total_mm=daily,
                        states_mm=states, fluxes_mm_day=fluxes,
                        state_names=np.array(['snow','fast','slow']),
                        flux_names=np.array(['melt','evaporation','drainage','recharge']))


def tables_and_figure(out, name, sids, ids, baseline, candidate, observed, cold):
    bm, cm = describe(baseline, observed), describe(candidate, observed)
    with (out / (name + '_regional_metrics.csv')).open('w', newline='', encoding='utf-8-sig') as f:
        fields = ['region_id','rds01_rmse_cm','candidate_rmse_cm','rds01_sd_ratio','candidate_sd_ratio']
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for i, rid in enumerate(ids):
            writer.writerow(dict(region_id=rid, rds01_rmse_cm=bm['regional_rmse_cm'][i],
                                 candidate_rmse_cm=cm['regional_rmse_cm'][i],
                                 rds01_sd_ratio=bm['sd_ratio'][i], candidate_sd_ratio=cm['sd_ratio'][i]))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(2, 1, figsize=(10,7), sharex=True)
    x = np.array([sid[-7:]+'-15' for sid in sids],dtype='datetime64[D]')
    for ax, k in zip(axes, cold):
        ax.plot(x, observed[:,k], 'ko-', ms=3, label='Existing storage proxy')
        ax.plot(x, baseline[:,k], color='#c1542d', label='Fixed RDS01')
        ax.plot(x, candidate[:,k], color='#168080', label='Fixed-weight diel-melt candidate')
        ax.set_title(ids[k]); ax.set_ylabel('Storage anomaly (cm)'); ax.grid(alpha=.2)
        ax.legend(fontsize=8)
    fig.suptitle(name + ' | zero training, same windows')
    fig.tight_layout()
    fig.savefig(out / (name+'_cold_regions.png'),dpi=150)
    plt.close(fig)


def run(root):
    if not os.environ.get('SLURM_JOB_ID'):
        raise RuntimeError('Scientific execution requires a Slurm compute job')
    out = root / 'output'
    out.mkdir(exist_ok=True)
    if (out/'report.json').exists():
        report=json.loads((out/'report.json').read_text())
        if report['state']=='COMPLETED':
            print('ALREADY_COMPLETED_NO_REPLAY',flush=True); return
    config=json.loads((root/'config.json').read_text())
    metadata=json.loads((root/'parent/metadata.json').read_text())
    torch.set_num_threads(4); torch.set_num_interop_threads(1)
    torch.manual_seed(20261015)
    started=time.monotonic()
    status=dict(state='RUNNING', exp_id=config['candidate_id'],job_id=os.environ['SLURM_JOB_ID'],
                training_epochs=0, optimizer_steps=0, application_inputs_opened=False, started_at=now())
    write_json(out/'status.json',status)
    data=read_npz(root/'inputs/inputs.npz')
    original=read_npz(root/'baseline_monthly.npz')
    ids=data['support_ids'].astype(str).tolist()
    fit=data['fit_mask']; val=~fit
    if (ids!=metadata['region_ids'] or ids!=original['support_ids'].astype(str).tolist()
            or len(ids)!=119 or not np.array_equal(data['solution_ids'],original['solution_ids'])
            or not np.array_equal(fit,original['fit_mask']) or int(fit.sum())!=66 or int(val.sum())!=12
            or str(data['dates'][0])!='1998-08-01' or str(data['dates'][-1])!='2008-12-31'):
        raise ValueError('Frozen input identities or dates changed')
    forcing=torch.from_numpy(data['forcing']); statics=torch.from_numpy(data['static_features'])
    if not torch.isfinite(forcing).all() or bool((forcing[:,:,4]>forcing[:,:,3]).any()):
        raise ValueError('Invalid temperature extremes')
    tr=metadata['transforms']
    model=RegionalDailyStorageDielMelt(statics.shape[1],tr['dynamic_mean'],tr['dynamic_scale']).eval()
    weights_file=root/'parent/weights.pt'
    parent_hash=hashlib.sha256(weights_file.read_bytes()).hexdigest()
    parent_weights=torch.load(weights_file,map_location='cpu',weights_only=True)
    model.load_state_dict(parent_weights,strict=True)
    if any(p.requires_grad for p in model.parameters()):
        raise RuntimeError('All parent parameters must be frozen')
    # One formula check covers fully cold, warm, crossing-zero, and equal extrema cases.
    torch.testing.assert_close(positive_temperature(torch.tensor([-4.,2.,-2.,0.,3.]),
                                                   torch.tensor([-1.,4.,2.,0.,3.])),
                               torch.tensor([0.,3.,.5,0.,3.]))
    print(json.dumps(dict(event='FORWARD_1998_2008',job_id=os.environ['SLURM_JOB_ID'],
                          regions=119,training_epochs=0,optimizer_steps=0,parent_sha256=parent_hash)),flush=True)
    with torch.inference_mode():
        _, initial=model.initialize(statics)
        daily,final,states,fluxes=model(forcing,statics,record=True)
        pred=project_storage(daily,torch.from_numpy(data['sampling_weights']))
        centered,observed,pref,yref,_=center_on_fit_windows(pred,torch.from_numpy(data['targets_cm']),torch.from_numpy(fit))
        health=integrity(initial,states,fluxes,forcing[:,:,0])
    cp,obs=centered.numpy(),observed.numpy()
    if not np.allclose(obs,original['observed_anomaly_cm'],atol=1e-5,rtol=0):
        raise ValueError('Observed reference changed')
    cold=[ids.index(k) for k in config['focus_regions']]
    rest=[i for i in range(119) if i not in cold]
    bp=original['prediction_anomaly_cm'][val]
    yy=original['observed_anomaly_cm'][val]
    baseline={'cold':describe(bp[:,cold],yy[:,cold]),'rest':describe(bp[:,rest],yy[:,rest])}
    candidate={'cold':describe(cp[val][:,cold],yy[:,cold]),'rest':describe(cp[val][:,rest],yy[:,rest])}
    b,c=baseline['cold'],candidate['cold']; g=config['gates']
    unchanged=all(torch.equal(model.state_dict()[k],v) for k,v in parent_weights.items())
    checks={
        'cold_pooled_rmse_reduced_at_least_10_percent':c['pooled_rmse_cm']<=b['pooled_rmse_cm']*g['cold_pooled_rmse_max_fraction_of_rds01'],
        'each_cold_rmse_not_worse':bool(np.all(np.array(c['regional_rmse_cm'])<=np.array(b['regional_rmse_cm']))),
        'each_cold_amplitude_error_not_worse':bool(np.all(np.array(c['absolute_log_sd_ratio'])<=np.array(b['absolute_log_sd_ratio']))),
        'other_117_pooled_rmse_within_2_percent':candidate['rest']['pooled_rmse_cm']<=baseline['rest']['pooled_rmse_cm']*g['other_117_pooled_rmse_max_fraction_of_rds01'],
        'finite_states_and_fluxes':health['finite'],
        'nonnegative_stocks':health['minimum_stock_mm']>=g['minimum_stock_mm'],
        'daily_water_balance':health['max_daily_balance_residual_mm']<=g['max_daily_balance_residual_mm'],
        'parent_weights_unchanged':unchanged}
    eligible=all(checks.values())
    selection=dict(state='DECIDED',selection_period='2008',eligible=eligible,checks=checks,
                   decision='CONTINUE_2009_2010' if eligible else 'RETAIN_RDS01',baseline=baseline,
                   candidate=candidate,health=health,decided_at=now(),application_inputs_opened=False)
    write_json(out/'selection.json',selection)
    np.savez_compressed(out/'history_predictions.npz',solution_ids=data['solution_ids'],region_ids=np.array(ids),
                        prediction_anomaly_cm=cp,observed_anomaly_cm=obs,fit_mask=fit,
                        prediction_reference_cm=pref.numpy(),observation_reference_cm=yref.numpy())
    mask=data['dates']>=np.datetime64('2008-01-01')
    save_states(out/'daily_states_2008.npz',data['dates'][mask],ids,daily.numpy()[mask],states.numpy()[mask],fluxes.numpy()[mask])
    np.savez_compressed(out/'state_2008-12-31.npz',stocks_mm=final.numpy(),region_ids=np.array(ids),
                        model_id=np.array(config['candidate_id']),last_forcing_date=np.array('2008-12-31'),
                        state_at_utc=np.array('2009-01-01T00:00:00Z'))
    tables_and_figure(out,'2008',data['solution_ids'][val].astype(str),ids,bp,cp[val],yy,cold)
    print(json.dumps(dict(event='GATE_2008',eligible=eligible,checks=checks,
                          cold_rmse_cm=c['pooled_rmse_cm'],rest_rmse_cm=candidate['rest']['pooled_rmse_cm'])),flush=True)
    report=dict(status,state='COMPLETED',parent_sha256=parent_hash,parent_weights_unchanged=unchanged,
                region_count=119,validation_2008=selection,decision=selection['decision'],
                continuation_2009_2010_started=False,forward_segments_completed=1)
    if eligible:
        # No application forcing/targets are opened above this gate.
        app=read_npz(root/'application_inputs.npz')
        if app['region_ids'].astype(str).tolist()!=ids or str(app['dates'][0])!='2009-01-01' or str(app['dates'][-1])!='2010-12-31':
            raise ValueError('Application identities changed')
        with torch.inference_mode():
            af=torch.from_numpy(app['forcing'])
            ad,astate,astocks,aflux=model(af,statics,initial=final,record=True)
            app_health=integrity(final,astocks,aflux,af[:,:,0])
            pc=project_storage(ad,torch.from_numpy(app['sampling_weights']))-pref
        if (not app_health['finite'] or app_health['minimum_stock_mm']<0 or
                app_health['max_daily_balance_residual_mm']>.001):
            raise ValueError('Application numerical integrity failed')
        app_observed=app['observed_anomaly_cm']
        save_states(out/'daily_states_2009_2010.npz',app['dates'],ids,ad.numpy(),astocks.numpy(),aflux.numpy())
        np.savez_compressed(out/'application_predictions.npz',solution_ids=app['solution_ids'],region_ids=np.array(ids),
                            prediction_anomaly_cm=pc.numpy(),observed_anomaly_cm=app_observed,
                            prediction_reference_cm=pref.numpy(),observation_reference_cm=yref.numpy())
        np.savez_compressed(out/'state_2010-12-31.npz',stocks_mm=astate.numpy(),region_ids=np.array(ids),
                            model_id=np.array(config['candidate_id']),last_forcing_date=np.array('2010-12-31'),
                            state_at_utc=np.array('2011-01-01T00:00:00Z'))
        tables_and_figure(out,'2009_2010',app['solution_ids'].astype(str),ids,
                          app['rds01_prediction_anomaly_cm'],pc.numpy(),app_observed,cold)
        report.update(application_inputs_opened=True,continuation_2009_2010_started=True,
                      forward_segments_completed=2,application_health=app_health,
                      application_2009_2010={'candidate_cold':describe(pc.numpy()[:,cold],app_observed[:,cold]),
                          'baseline_cold':describe(app['rds01_prediction_anomaly_cm'][:,cold],app_observed[:,cold]),
                          'candidate_all':describe(pc.numpy(),app_observed),
                          'baseline_all':describe(app['rds01_prediction_anomaly_cm'],app_observed)})
    if not all(torch.equal(model.state_dict()[k],v) for k,v in parent_weights.items()):
        raise RuntimeError('A parent tensor changed')
    report.update(finished_at=now(),elapsed_seconds=time.monotonic()-started)
    write_json(out/'report.json',report); write_json(out/'status.json',report)
    print(json.dumps(dict(event='COMPLETED',decision=report['decision'],application_started=report['continuation_2009_2010_started'])),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args()
    try:
        run(args.root)
    except Exception as exc:
        (args.root/'output').mkdir(exist_ok=True)
        write_json(args.root/'output/status.json',dict(state='FAILED',error=str(exc),time=now(),job_id=os.environ.get('SLURM_JOB_ID')))
        traceback.print_exc(); sys.exit(1)
