"""Fixed RDS01 weights; replace only the positive-temperature term in melt."""
from typing import List, Optional

import torch
from torch import Tensor
from torch.nn import functional as F

from .regional_daily_storage import RegionalDailyStorage


@torch.jit.script
def positive_temperature(tmin: Tensor, tmax: Tensor):
    mean = .5 * (tmin + tmax)
    # The mixed branch has positive width. The clamp avoids unused 0/0 branches.
    mixed = tmax.square() / (2 * (tmax - tmin).clamp_min(1e-12))
    return torch.where(tmax <= 0, torch.zeros_like(mean), torch.where(tmin >= 0, mean, mixed))


@torch.jit.script
def dielmelt_scan(precip: Tensor, temp: Tensor, positive: Tensor, demand: Tensor,
                  params: Tensor, initial: Tensor, record: bool = False):
    snow, fast, slow = initial[:, 0], initial[:, 1], initial[:, 2]
    means = torch.jit.annotate(List[Tensor], [])
    states = torch.jit.annotate(List[Tensor], [])
    fluxes = torch.jit.annotate(List[Tensor], [])
    melt_c, kf, kr, kg, gamma = (params[:, 0], params[:, 1], params[:, 2], params[:, 3], params[:, 4])
    partition = torch.sigmoid(-temp)
    potential_melt = positive * melt_c
    for day in range(precip.size(0)):
        previous = snow + fast + slow
        ps = precip[day] * partition[day]
        available = snow + ps
        melt = torch.minimum(available, potential_melt[day])
        snow = available - melt
        u = fast + precip[day] - ps + melt
        ef = torch.minimum(u, demand[day])
        u1 = u - ef
        qf = kf * u1
        recharge = kr * (u1 - qf)
        fast = u1 - qf - recharge
        v = slow + recharge
        eg = torch.minimum(v, gamma * torch.relu(demand[day] - ef))
        qg = kg * (v - eg)
        slow = v - eg - qg
        means.append((previous + snow + fast + slow) * .5)
        if record:
            states.append(torch.stack([snow, fast, slow], dim=-1))
            fluxes.append(torch.stack([melt, ef + eg, qf + qg, recharge], dim=-1))
    final = torch.stack([snow, fast, slow], dim=-1)
    if record:
        return torch.stack(means), final, torch.stack(states), torch.stack(fluxes)
    return torch.stack(means), final, initial.new_empty((0,)), initial.new_empty((0,))


class RegionalDailyStorageDielMelt(RegionalDailyStorage):
    def __init__(self, static_size, dynamic_mean, dynamic_scale):
        super().__init__(static_size, dynamic_mean, dynamic_scale)
        self.requires_grad_(False)

    def forward(self, forcing: Tensor, statics: Tensor, initial: Optional[Tensor] = None,
                record: bool = False):
        temp = .5 * (forcing[:, :, 3] + forcing[:, :, 4])
        dynamic = torch.stack([temp, forcing[:, :, 1], forcing[:, :, 5]], dim=-1)
        dynamic = (dynamic - self.dynamic_mean) / self.dynamic_scale
        static_days = statics.unsqueeze(0).expand(forcing.size(0), -1, -1)
        demand = F.softplus(self.demand_net(torch.cat([dynamic, static_days], dim=-1))).squeeze(-1)
        params, configured_initial = self.initialize(statics)
        positive = positive_temperature(forcing[:, :, 4], forcing[:, :, 3])
        return dielmelt_scan(forcing[:, :, 0], temp, positive, demand, params,
                            configured_initial if initial is None else initial, record)
