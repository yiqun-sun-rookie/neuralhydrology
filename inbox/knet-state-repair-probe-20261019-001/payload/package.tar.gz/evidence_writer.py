"""Immutable commit and call-marker protocol; deliberately no resume operation."""
import json,hashlib,re
from pathlib import Path
import safe_io as s

class EvidenceWriter:
    def __init__(self,relative):
        self.relative=relative;self.folder=s.checked_path(s.ROOT/relative,False)
    def put(self,name,raw):
        assert Path(name).name==name and not name.endswith('.partial')
        return s.create(self.relative+'/'+name,raw)
    def begin_call(self,step):
        status=self.inspect()
        assert not status['unresolved_calls'],'Unresolved call forbids further calls'
        assert step==status['confirmed_calls']+1
        return self.put(f'call_intent_{step:03d}.json',dict(step=step,phase='before_call'))
    def mark_call(self,step):
        intent=json.loads(s.read_checked(self.folder/f'call_intent_{step:03d}.json'));assert intent['step']==step
        return self.put(f'call_marker_{step:03d}.json',dict(step=step,phase='after_call'))
    def commit(self,step,files,counters):
        assert counters['optimizer_calls']==step
        for record in files:s.read_checked(s.ROOT/record['path'],record['sha256'])
        if step:
            status=self.inspect();assert not status['unresolved_calls'] and status['confirmed_calls']==step
        return self.put(f'epoch_commit_{step:03d}.json',dict(step=step,files=files,counters=counters))
    def inspect(self):
        if not self.folder.exists():return dict(last_complete_epoch=None,confirmed_calls=0,unresolved_calls=[],uncommitted_files=[])
        paths=[p for p in self.folder.iterdir() if p.is_file()];intents=[];markers=[];commits=[];committed=set()
        for p in paths:
            s.checked_path(p)
            m=re.fullmatch(r'call_intent_(\d+)\.json',p.name)
            if m:intents.append(int(m[1]))
            m=re.fullmatch(r'call_marker_(\d+)\.json',p.name)
            if m:markers.append(int(m[1]))
            m=re.fullmatch(r'epoch_commit_(\d+)\.json',p.name)
            if m:
                entry=json.loads(s.read_checked(p));assert entry['step']==int(m[1])
                for r in entry['files']:s.read_checked(s.ROOT/r['path'],r['sha256']);committed.add(Path(r['path']).name)
                commits.append(int(m[1]));committed.add(p.name)
        assert sorted(markers)==list(range(1,len(markers)+1))
        assert set(markers)<=set(intents)
        unresolved=sorted(set(intents)-set(markers));assert len(unresolved)<=1
        return dict(last_complete_epoch=max(commits) if commits else None,confirmed_calls=len(markers),unresolved_calls=unresolved,uncommitted_files=sorted(p.name for p in paths if p.name not in committed and not p.name.startswith(('call_intent_','call_marker_'))))
