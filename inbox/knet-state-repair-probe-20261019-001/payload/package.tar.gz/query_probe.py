"""Owned read-only scheduler/progress query, optionally export terminal evidence."""
import sys,json,datetime,subprocess,re,time,socket,io,tarfile,gzip,hashlib,base64
from pathlib import Path
import safe_io as s
BASE=Path(__file__).resolve().parent
assert BASE.name=='state_channel_repair_probe_20261019_001'
job=sys.argv[1];token=sys.argv[2];assert job.isdigit()
submission=json.loads(s.read_checked(BASE/'submission.json'));assert submission['job_id']==job
def command(args):
    try:
        p=subprocess.run(args,capture_output=True,text=True,timeout=15)
        return dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
    except subprocess.TimeoutExpired:return dict(returncode=124,stdout='',stderr='scheduler query timeout')
def load(path):return json.loads(s.read_checked(path)) if path.is_file() else None
def tail(path):
    if not s.checked_path(path,False).is_file():return dict(exists=False)
    raw=s.read_checked(path);lines=raw.decode(errors='replace').splitlines();events=[]
    for line in lines:
        try:item=json.loads(line)
        except ValueError:continue
        if isinstance(item,dict) and 'event' in item:events.append(item)
    return dict(exists=True,bytes=len(raw),mtime_age_seconds=max(0,time.time()-path.stat().st_mtime),events=events[-10:],tail=lines[-5:])
queue=command(['squeue','-j',job,'-h','-o','%i|%j|%T|%M|%R'])
control=command(['scontrol','-o','show','job',job]);fields=dict(re.findall(r'(\w+)=([^\s]+)',control['stdout']))
accounting=command(['sacct','-j',job,'--noheader','--parsable2','--format=JobID,State,ExitCode,ElapsedRaw,AllocCPUS,NodeList,Start,End'])
rows=[line.split('|') for line in accounting['stdout'].splitlines() if line]
own=[row for row in rows if row[0]==job]
terminal_states={'COMPLETED','FAILED','TIMEOUT','CANCELLED','OUT_OF_MEMORY','NODE_FAIL','PREEMPTED','BOOT_FAIL','DEADLINE','REVOKED'}
terminal=bool(own and own[0][1].split()[0].rstrip('+') in terminal_states)
folder=BASE/'runs/04105700/attempt_001';stdout=tail(BASE/'logs'/('probe-'+job+'.out'))
result=load(folder/'result.json');receipt=load(folder/'receipt.json')
stat=command(['sstat','-j',job+'.batch','--noheader','--parsable2','--format=JobID,AveCPU,MaxRSS']) if fields.get('JobState')=='RUNNING' else None
record=dict(job_id=job,token=token,queried_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),query_host=socket.gethostname(),queue=queue,scontrol=control,scheduler_fields=fields,accounting=accounting,native_job_row=own,terminal=terminal,controller=load(folder/'controller_started.json'),worker=load(folder/'scientific_started.json'),resource=stat,receipt=receipt,result=result,stdout=stdout,stderr=tail(BASE/'logs'/('probe-'+job+'.err')))
print('PROBE_STATUS_JSON='+json.dumps(record),flush=True)
if terminal:
    # Flat immutable evidence, including any interrupted .partial files. No model run.
    sources=[]
    for name in ['submission.json','submission_started.json','execution_authorization.json','deployment_manifest.json','probe_contract.json','user_authorization.json','initializer_probe.py','baseline_reducer.py','evidence_writer.py','probe_controller.py','query_probe.py','safe_io.py','probe.slurm','remote_preflight.json']:
        path=BASE/name
        if path.is_file():sources.append(path)
    for relative in ['logs','runs/04105700/attempt_001','runs/04105700/attempt_001/original','runs/04105700/attempt_001/state_constrained']:
        d=s.checked_path(BASE/relative,False)
        if d.is_dir():
            for p in d.iterdir():
                s.checked_path(p)
                if p.is_file():sources.append(p)
    manifest=[];data_by_path={}
    for p in sorted(set(sources)):
        raw=s.read_checked(p);rel=str(p.relative_to(BASE)).replace('\\','/');data_by_path[rel]=raw
        manifest.append(dict(path=rel,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
    metadata=dict(schema='initialization_probe_terminal_archive_v1',identity=submission,accounting=rows,files=manifest)
    data_by_path['collection_manifest.json']=(json.dumps(metadata,indent=2)+'\n').encode()
    stream=io.BytesIO()
    with tarfile.open(fileobj=stream,mode='w') as tar:
        for rel,raw in data_by_path.items():
            item=tarfile.TarInfo(rel);item.size=len(raw);item.mtime=0;tar.addfile(item,io.BytesIO(raw))
    payload=gzip.compress(stream.getvalue(),mtime=0)
    assert len(payload)<=8*1024**2,'Probe archive exceeds small single-part contract; preserve, diagnose, no science retry'
    print('PROBE_ARCHIVE_METADATA='+json.dumps(dict(bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest(),files=len(data_by_path))),flush=True)
    print('PROBE_ARCHIVE_BASE64='+base64.b64encode(payload).decode(),flush=True)
