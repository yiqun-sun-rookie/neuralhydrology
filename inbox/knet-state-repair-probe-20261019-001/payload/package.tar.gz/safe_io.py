"""Checked local/compute-node reads and exclusive atomic evidence publication."""
import os, json, hashlib, re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DENY=re.compile(r'formal[-_]evaluation|phase_a_results|unseal',re.I)

def checked_path(path,exists=True):
    p=Path(path)
    if not p.is_absolute() or '..' in p.parts or DENY.search(str(p)):raise PermissionError('forbidden path')
    for a in (p,*p.parents):
        if a.exists() and (a.is_symlink() or getattr(a.lstat(),'st_file_attributes',0)&0x400):raise PermissionError('linked path')
    if exists and os.path.normcase(str(p.resolve(strict=True)))!=os.path.normcase(str(p)):raise PermissionError('different resolved path')
    return p

def read_checked(path,digest=None):
    p=checked_path(path)
    flags=os.O_RDONLY|getattr(os,'O_BINARY',0)|getattr(os,'O_NOFOLLOW',0)
    with os.fdopen(os.open(p,flags),'rb') as f:
        if os.name=='nt':
            import ctypes,msvcrt
            fn=ctypes.windll.kernel32.GetFinalPathNameByHandleW
            fn.argtypes=[ctypes.c_void_p,ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_uint32];fn.restype=ctypes.c_uint32
            buf=ctypes.create_unicode_buffer(32768);n=fn(msvcrt.get_osfhandle(f.fileno()),buf,len(buf),0)
            if not 0<n<len(buf) or os.path.normcase(buf.value.removeprefix('\\\\?\\'))!=os.path.normcase(str(p)):raise PermissionError('opened target differs')
        elif os.readlink('/proc/self/fd/'+str(f.fileno()))!=str(p):raise PermissionError('opened target differs')
        before=os.fstat(f.fileno());raw=f.read();after=os.fstat(f.fileno())
    if (before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_ino,after.st_size,after.st_mtime_ns):raise RuntimeError('source changed')
    if digest and hashlib.sha256(raw).hexdigest()!=digest:raise RuntimeError('SHA256 differs')
    return raw

def create(relative,value):
    p=checked_path(ROOT/relative,False)
    if not p.is_relative_to(ROOT):raise PermissionError('write outside owned execution root')
    raw=value if isinstance(value,bytes) else (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
    p.parent.mkdir(parents=True,exist_ok=True)
    tmp=checked_path(p.with_name(p.name+'.partial'),False)
    with tmp.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    digest=hashlib.sha256(raw).hexdigest();assert read_checked(tmp,digest)==raw
    # A hard-link publish is atomic and fails if the immutable final name exists.
    # Remove only our completed temporary name; interrupted .partial files survive.
    os.link(tmp,p);tmp.unlink()
    if os.name!='nt':
        fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    return dict(path=relative,bytes=len(raw),sha256=digest)
