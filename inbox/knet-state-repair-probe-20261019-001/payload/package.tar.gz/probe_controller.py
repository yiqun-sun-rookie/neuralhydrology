"""Single owned initialization child, 1740s work cutoff and 1800s total cap."""
import os,sys,json,time,threading,datetime,subprocess,re,signal
from pathlib import Path
import psutil
import safe_io as s
BASE=Path(__file__).resolve().parent
BEGAN=time.monotonic()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert os.environ.get('SLURM_JOB_ID','').isdigit(),'Slurm allocation required'
assert not os.environ.get('SLURM_ARRAY_TASK_ID'),'A single non-array job is required'
plan=json.loads(s.read_checked(BASE/'probe_contract.json'));limits=plan['resource_limits']
assert plan['total_optimizer_calls']==0 and limits['total_wall_seconds']==1800
out='runs/04105700/attempt_001';assert not (BASE/out).exists(),'One attempt only'
os.environ['HPC_BASIN']='04105700';proc=psutil.Process()
details=subprocess.run(['scontrol','-d','show','job',os.environ['SLURM_JOB_ID']],capture_output=True,text=True,check=True,timeout=15)
start=re.search(r'\bStartTime=([^\s]+)',details.stdout)
assert start and os.environ.get('TZ')=='UTC','UTC Slurm allocation start required'
allocation_start=datetime.datetime.fromisoformat(start[1]).replace(tzinfo=datetime.timezone.utc)
allocation_age=time.time()-allocation_start.timestamp();assert allocation_age>=0
BEGAN=time.monotonic()-allocation_age
allocated=set()
for field in re.findall(r'CPU_IDs=([0-9,-]+)',details.stdout):
    for item in field.split(','):
        if '-' in item:
            first,last=map(int,item.split('-'));allocated.update(range(first,last+1))
        else:allocated.add(int(item))
eligible=sorted(allocated.intersection(proc.cpu_affinity()));assert eligible
proc.cpu_affinity([eligible[0]]);proc.nice(10)
child=None;interrupted=[]
def stop_signal(signum,frame):
    interrupted.append(signum)
    if child is not None and child.poll() is None:child.terminate()
signal.signal(signal.SIGTERM,stop_signal);signal.signal(signal.SIGINT,stop_signal)
s.create(out+'/controller_started.json',dict(utc=now(),pid=proc.pid,creation_time=proc.create_time(),job_id=os.environ['SLURM_JOB_ID'],node=os.uname().nodename,allocation_start_utc=allocation_start.isoformat(),allocated_cpu_ids=sorted(allocated),affinity=proc.cpu_affinity(),priority_nice=proc.nice(),scontrol=details.stdout,zero_call_only=True))
child=psutil.Popen([sys.executable,'-u','-B',str(BASE/'initializer_probe.py'),out],cwd=str(BASE),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
child.cpu_affinity(proc.cpu_affinity());child.nice(10)
s.create(out+'/scientific_started.json',dict(utc=now(),pid=child.pid,creation_time=child.create_time(),job_id=os.environ['SLURM_JOB_ID'],affinity=child.cpu_affinity(),priority_nice=child.nice()))
chunks=[]
def consume():
    for line in iter(child.stdout.readline,b''):
        chunks.append(line);print(line.decode(errors='replace').rstrip(),flush=True)
reader=threading.Thread(target=consume,daemon=True);reader.start()
child.stdin.write(b'{"resources_configured":true}\n');child.stdin.flush();child.stdin.close()
peak=0;free_min=None;cpu=0.;stop=None;last=0.
while child.poll() is None:
    elapsed=time.monotonic()-BEGAN
    try:
        rss=sum(p.memory_info().rss for p in [proc,child]+child.children(recursive=True));free=psutil.virtual_memory().available;ct=child.cpu_times();cpu=ct.user+ct.system
        peak=max(peak,rss);free_min=free if free_min is None else min(free_min,free)
        if elapsed-last>=30 or not last:
            print(json.dumps(dict(event='resource_sample',utc=now(),job_id=os.environ['SLURM_JOB_ID'],worker_pid=child.pid,elapsed_seconds=elapsed,child_cpu_seconds=cpu,combined_rss_bytes=rss,free_bytes=free,affinity=child.cpu_affinity())),flush=True);last=elapsed
        if rss>limits['combined_rss_limit_bytes']:stop='RSS_LIMIT'
        elif free<limits['minimum_free_bytes']:stop='SYSTEM_FREE_LIMIT'
        elif elapsed>=limits['work_cutoff_seconds']:stop='WORK_CUTOFF_1740'
        elif interrupted:stop='EXTERNAL_SIGNAL'
        if stop:child.terminate();break
    except psutil.NoSuchProcess:pass
    time.sleep(.25)
try:child.wait(timeout=min(10,max(.1,1800-(time.monotonic()-BEGAN))))
except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
reader.join(timeout=5)
log=s.create(out+'/stdout.log',b''.join(chunks));rp=BASE/out/'result.json';result=json.loads(s.read_checked(rp)) if rp.exists() else None
wall=time.monotonic()-BEGAN
passed=bool(child.returncode==0 and stop is None and result and result['status']=='INITIALIZATION_ONLY_PASS' and wall<=1800 and peak<=limits['combined_rss_limit_bytes'] and free_min is not None and free_min>=limits['minimum_free_bytes'])
receipt=dict(status='COMPLETED' if passed else 'FAILED',job_id=os.environ['SLURM_JOB_ID'],basin='04105700',node=os.uname().nodename,exit_code=child.returncode,resource_stop=stop,wall_seconds=wall,work_cutoff_seconds=1740,total_wall_limit_seconds=1800,budget_pass=wall<=1800,combined_rss_peak_bytes=peak,system_free_min_bytes=free_min,child_cpu_seconds=cpu,affinity=proc.cpu_affinity(),priority_nice=proc.nice(),mathematical_threads=1,gpu_requested=0,total_optimizer_calls=None if result is None else result['total_optimizer_calls'],total_effective_nonzero_steps=None if result is None else result['total_effective_nonzero_steps'],result_present=result is not None,log=log,ended_utc=now())
s.create(out+'/receipt.json',receipt);print('PROBE_RECEIPT='+json.dumps(receipt),flush=True)
raise SystemExit(0 if passed else 1)
