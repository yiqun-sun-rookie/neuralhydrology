"""Canonical initialization-only reduction and strict independent-arm checks."""
import numpy as np

def proxy_score(values,mask):
    values=np.asarray(values);mask=np.asarray(mask)
    assert values.shape==mask.shape and mask.dtype==np.bool_ and mask.any()
    assert np.isfinite(values).all()
    # Fixed segment order, float64 numerator accumulation, one final division.
    if values.ndim==1:values=values[None,:];mask=mask[None,:]
    numerators=[float(np.sum(row[m].astype(np.float64)**2,dtype=np.float64)) for row,m in zip(values,mask)]
    total=np.float64(0.)
    for value in numerators:total+=np.float64(value)
    return float(total/int(mask.sum()))

def compare_baselines(left,right,identity_left,identity_right):
    assert identity_left==identity_right,'Initial identities differ'
    assert set(left)==set(right),'Array fields differ'
    report={}
    for key in left:
        a,b=np.asarray(left[key]),np.asarray(right[key])
        assert a.shape==b.shape and a.dtype==b.dtype,'Array shape/dtype differs: '+key
        assert np.isfinite(a).all() and np.isfinite(b).all(),'Nonfinite baseline: '+key
        if key=='scores':
            tolerance=np.maximum(1e-10,1e-7*np.abs(b));difference=np.abs(a-b)
            assert np.all(difference<=tolerance),'Derived scores differ beyond fixed tolerance'
            report[key]=dict(exact_equal=bool(np.array_equal(a,b)),max_abs_difference=float(difference.max()),tolerances=tolerance.tolist())
        else:
            assert np.array_equal(a,b),'Raw baseline differs: '+key
            report[key]=dict(exact_equal=True,shape=list(a.shape),dtype=str(a.dtype))
    return report
