"""Four authorized 20-call arms, split into two serial Slurm array elements."""
import os, sys, io, json, hashlib, time, datetime, importlib.util, traceback
from pathlib import Path


def main():
    base = Path(__file__).resolve().parent
    template = base.parents[1] / 'template'
    spec = importlib.util.spec_from_file_location('safe_io', base/'safe_io.py')
    s = importlib.util.module_from_spec(spec); sys.modules['safe_io'] = s; spec.loader.exec_module(s)
    assert os.environ.get('SLURM_JOB_ID', '').isdigit()
    assert json.loads(sys.stdin.readline())['resources_configured']
    raw_plan = s.read_checked(base/'plan_contract.json'); plan = json.loads(raw_plan)
    auth = json.loads(s.read_checked(base/'execution_authorization.json'))
    assert auth['status'] == 'AUTHORIZED' and plan['optimizer_steps_per_arm'] == 20
    for row in auth['files']: s.read_checked(base/row['path'], row['sha256'])
    manifest = json.loads(s.read_checked(template/'bundle_manifest.json', auth['template_manifest_sha256']))
    for row in manifest['files']: s.read_checked(template/row['path'], row['sha256'])
    import numpy as np
    import torch
    import random
    from constrained_step import project_displacement, feasible_scores
    torch.set_num_threads(1); torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    random.seed(plan['seed']); np.random.seed(plan['seed']); torch.manual_seed(plan['seed'])
    basin = os.environ['HPC_BASIN']; conf = next(x for x in plan['basins'] if x['basin']==basin)
    coordinate = conf['output_row']; out = sys.argv[1]; began = time.monotonic()
    os.chdir(template); sys.path.insert(0, str(template/'recipe')); os.environ['KNET_BASIN']='04105700'
    import common as C
    # Restore only the two already-frozen 02092500 registry entries.
    if basin=='02092500':
        known={
            'basin_02092500.npz':'453d57eab87b0d774d5895f143d51c40644f9b92fd8702ce646a6f4841378eb6',
            'basin_02092500.json':'1d888ac7e396def5d6d435574ad4af91a8adb89bf17845c87f15c5a2f2f4b0a3'}
        registered={}
        for entry in json.loads(s.read_checked(template/'recipe/evaluation_sources.json'))['files']:
            source=Path(entry['path'])
            assert not source.is_absolute() and '..' not in source.parts
            path=(template/source).resolve();name=path.name
            if name not in known:continue
            assert path.is_relative_to(template/'recipe/workspace/results')
            assert entry['sha256']==known[name]
            key=str(path.resolve()).lower()
            if key in C.DIGESTS:assert C.DIGESTS[key]==entry['sha256']
            C.DIGESTS[key]=entry['sha256'];registered[name]=entry['sha256']
        assert registered==known
    from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
    from global_hydrology.experiments import daily_camels_ukf_knet_parity_runner as parity
    from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
    from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import AccessLedger, CAUSAL_SHARED_SPINUP_MODE
    def arr(x): return x.detach().cpu().numpy().copy()
    def put(name, value): return s.create(out+'/'+name, value)
    def np_save(name, values):
        stream=io.BytesIO(); np.savez_compressed(stream, **values); return put(name,stream.getvalue())
    def pt_save(name, values):
        stream=io.BytesIO(); torch.save(values,stream); return put(name,stream.getvalue())
    def load_np(name):
        with np.load(io.BytesIO(s.read_checked(base/'inputs'/basin/name)),allow_pickle=False) as z:
            return {k:z[k].copy() for k in z.files}
    def emit(event, **values):
        print(json.dumps(dict(event=event,basin=basin,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            elapsed_seconds=time.monotonic()-began,**values),allow_nan=False),flush=True)
    cp=torch.load(io.BytesIO(s.read_checked(base/'inputs'/basin/'checkpoint.pt',conf['checkpoint_sha256'])),weights_only=True,map_location='cpu')
    runtime=per.load_per_basin_development_runtime(get_development_basin_specification(basin),
        ledger=AccessLedger(),initialization_mode=CAUSAL_SHARED_SPINUP_MODE,device='cpu')
    assert runtime.training_days==2557 and len(runtime.dates)==3288
    states=parity.training_open_loop_states(runtime)
    scales=parity.fit_training_feature_scales(runtime,floor=.1)
    per.fit_training_feature_scales=lambda r,*,floor=.1:scales
    advance=parity._advance_open_loop
    parity._advance_open_loop=lambda context,forcing,*,end_exclusive:states[-1].clone() if context is runtime.context and end_exclusive==2557 else advance(context,forcing,end_exclusive=end_exclusive)
    window=parity.select_window(runtime,'recovery'); TT=float(runtime.context.plain_model.params['parTT'])
    K2=float(runtime.context.plain_model.params['parK2'])
    CFMAX=float(runtime.context.plain_model.params['parCFMAX'])
    observations=arr(runtime.observations).reshape(-1); forcing=arr(runtime.forcing)
    dates=runtime.dates.astype('datetime64[ns]').astype('int64'); issues=np.arange(2557,3285)
    targets=observations[issues[:,None]+np.arange(1,4)]
    thresholds=np.quantile(observations[:2557],[.5,.9,.99],method='linear')
    if basin=='02092500':
        ref=load_np('reference.npz'); old=load_np('original.npz')
        original_prediction=old['prediction']; original_posterior=old['posterior']; ukf=ref['ukf_prediction']
        assert np.array_equal(arr(window.initial_state).reshape(-1),ref['initial_state'])
    else:
        ref=load_np('main.npz'); original_prediction=ref['knet_prediction']
        original_posterior=ref['knet_posterior']; ukf=ref['ukf_prediction']
    assert np.array_equal(targets,ref['target']) and np.array_equal(issues,ref['issue_indices'])
    assert np.array_equal(dates[issues[:,None]+np.arange(1,4)],ref['target_dates_ns'])
    np_save('input_snapshot.npz',dict(observations=observations,forcing=forcing,dates_ns=dates,thresholds=thresholds,
        training_open_loop=arr(states),initial_validation_state=arr(window.initial_state),ukf_prediction=ukf))
    def groups(y):
        return [y==y,y<=thresholds[0],(y>thresholds[0])&(y<=thresholds[1]),y>thresholds[1]]
    training_counts=np.zeros(4,dtype=np.int64)
    for start in plan['base_starts']:
        y=observations[start+np.arange(695,797)[:,None]+np.arange(1,4)]
        training_counts += np.array([m.sum() for m in groups(y)])
    assert training_counts[0]==7650 and np.all(training_counts>0)
    arms={}; initial_hashes={}; initial_snapshots={}
    for arm in plan['arms']:
        net=per.build_exact_dimension_kalman_net(runtime,zero_gain=False,seed=plan['seed'],
            gain_initialization='near_zero_fc2_head',hidden=24,input_multiplier=10,output_multiplier=10,
            feature_scale_floor=.1,normalized_feature_guard=10.,correction_cap_in_state_scale_units=3.)
        net.load_state_dict(cp['network'],strict=True)
        assert parity.parameter_sha256(net)==conf['parameter_sha256']
        for p in net.parameters(): p.requires_grad_(False)
        head=net.FC2[-1]; head.weight.requires_grad_(True); head.bias.requires_grad_(True)
        assert head.out_features==runtime.context.dimension and net.n==1
        hp=[head.weight,head.bias]
        opt=torch.optim.Adam(hp,lr=plan['optimizer']['lr'],weight_decay=0.,betas=(.9,.999),eps=1e-8)
        state=dict(net=net,head=head,parameters=hp,optimizer=opt,calls=0,effective=0,history=[],
            frozen={k:v.detach().clone() for k,v in net.state_dict().items()},trace=None,step=0,
            rng=torch.get_rng_state().clone(),count=0,phase='initialization',record_after=0)
        native=net.analysis_step
        def wrapped(native,net,state):
            def update(y,u):
                previous=net.m1x_posterior
                post=native(y,u); i=state['count']; state['count']+=1
                if state['trace'] is not None and i>=state['record_after']:
                    state['trace'].append(dict(prior=net.m1x_prior,posterior=post,previous=previous,
                        requested=net.last_correction,prior_flow=net.m1y.reshape(()),
                        posterior_flow=net.h(post).reshape(()),gain=net.KGain.reshape(-1)))
                return post
            return update
        net.analysis_step=wrapped(native,net,state)
        identities=[]
        for start in [*plan['base_starts'],2557]:
            initial=runtime.context.initial_state.clone() if start==0 else states[start-1].clone()
            previous=None if start==0 else runtime.observations[start-1:start].clone()
            net.initialize_filter(initial,731 if start==2557 else 800,previous_observation=previous)
            identities.append({key:C.helpers.digest_tree(getattr(net,key)) for key in C.probe.RECURRENCE_FIELDS})
        initial_snapshots[arm]=identities
        initial_hashes[arm]=dict(network=C.helpers.digest_tree(net.state_dict()),optimizer=C.helpers.digest_tree(opt.state_dict()),rng=C.helpers.digest_tree(state['rng']))
        arms[arm]=state
    assert initial_hashes['flow_control']==initial_hashes['state_constrained']
    assert initial_snapshots['flow_control']==initial_snapshots['state_constrained']
    head_names=[name for name,p in arms['flow_control']['net'].named_parameters() if any(p is h for h in arms['flow_control']['parameters'])]
    put('initialization_gate.json',dict(status='PASS',basin=basin,checkpoint_epoch=conf['epoch'],hashes=initial_hashes,
        initial_snapshots=initial_snapshots,trainable_tensor_names=head_names,output_row=coordinate,
        trainable_parameter_count=arms['flow_control']['head'].in_features+1))

    def vector(state):
        return np.concatenate([arr(state['head'].weight[coordinate]),arr(state['head'].bias[coordinate:coordinate+1])]).astype(np.float64)
    def install(state,values):
        with torch.no_grad():
            state['head'].weight[coordinate].copy_(torch.as_tensor(values[:-1],dtype=state['head'].weight.dtype))
            state['head'].bias[coordinate].copy_(torch.as_tensor(values[-1],dtype=state['head'].bias.dtype))
    def frozen_check(state):
        for name,value in state['net'].state_dict().items():
            old_value=state['frozen'][name]
            if name in head_names:
                mask=torch.ones(value.shape[0],dtype=torch.bool);mask[coordinate]=False
                assert torch.equal(value[mask],old_value[mask]),'non-target output row changed'
            else: assert torch.equal(value,old_value),'frozen parameter/buffer changed: '+name

    def metric_values(pred,y):
        error=pred-y; result={}
        for label,mask in zip(plan['flow_groups'],groups(y)):
            e=error[mask]; truth=y[mask];den=float(np.sum((truth-truth.mean())**2))
            result[label]=dict(count=int(mask.sum()),mse=float(np.mean(e**2)),mae=float(np.mean(np.abs(e))),
                bias=float(np.mean(e)),nse=None if den==0 else 1-float(np.sum(e**2))/den)
        return result
    def state_mask(trace,start):
        previous=np.stack([arr(r['previous']).reshape(-1) for r in trace])
        prior=np.stack([arr(r['prior']).reshape(-1) for r in trace])
        indices=np.arange(start,start+len(trace))
        if coordinate==0:return (forcing[indices,0,1]>=TT)&(prior[:,0]<=0)
        return ((forcing[indices,0,0]==0)&(previous[:,0]<=0)&(previous[:,1]<=0)&
            (observations[indices]<=thresholds[0])&(observations[indices]<=observations[indices-1]))
    def state_terms(trace,mask,start,state):
        if coordinate==0:
            values=torch.stack([torch.relu((r['posterior']-r['prior'])[0,0]) for r in trace])
            scale=float(state['net'].state_feature_scale[0,0])
        else:
            prior_flow=torch.stack([r['prior_flow'] for r in trace])
            values=torch.relu(prior_flow-torch.as_tensor(observations[start:start+len(trace)],dtype=prior_flow.dtype))
            scale=float(state['net'].observation_feature_scale.reshape(()))
        selected=values[torch.as_tensor(mask,dtype=torch.bool)]
        return (selected/scale).square().sum(), selected.sum(), values

    masks={}; state_count=0
    def training(state,gradient=False,freeze_masks=False):
        nonlocal state_count
        net=state['net'];net.train();metrics=np.zeros(8);target_sum=0.;positive_sum=0.
        grads=np.zeros((9,len(vector(state)))) if gradient else None
        for number,start in enumerate(plan['base_starts']):
            initial=runtime.context.initial_state.clone() if start==0 else states[start-1].clone()
            context=parity._context_with_initial_state(runtime.context,initial)
            batch=parity.WindowBatch(purpose='training_segment',global_start=start,global_end_exclusive=start+800,
                context=context,forcing=runtime.forcing[start:start+800],observations=runtime.observations[start:start+800],
                dates=runtime.dates[start:start+800],initial_state=initial,issue_start_local=695,issue_end_local=797)
            state['trace']=[];state['count']=0;state['record_after']=650
            cut_count=[0]
            def detach(network): C.probe.detach_recurrence(network);cut_count[0]+=1
            with torch.set_grad_enabled(gradient):
                with C.diag.analysis_observer(net,650,detach,{},start,batch.dates):
                    filtered=parity.run_knet_filter(net,batch,previous_observation=parity.previous_observation_before_window(runtime,batch))
                assert cut_count[0]==1 and len(state['trace'])==150
                raw=runtime.tukf06_module.multilead_torch(batch.context.plain_model,filtered.posterior_states[:,0,:],batch.forcing)
                predictions=torch.stack([raw[k][0][695:797] for k in (1,2,3)],dim=1)
                y=runtime.observations[start+torch.arange(695,797)[:,None]+torch.arange(1,4),0]
                error=predictions-y;losses=[]
                for group,denom in zip(groups(arr(y)),training_counts):
                    selected=error[torch.as_tensor(group)]
                    losses.extend([selected.square().sum()/int(denom),selected.abs().sum()/int(denom)])
                if freeze_masks:
                    masks[start]=state_mask(state['trace'],start+650);state_count+=int(masks[start].sum())
                target,positive,values=state_terms(state['trace'],masks[start],start+650,state)
                target_sum+=float(target.detach());positive_sum+=float(positive.detach())
                metrics+=np.array([float(v.detach()) for v in losses])
                if gradient:
                    objectives=losses+[target/state_count]
                    needed=[0] if state['arm']=='flow_control' else list(range(9))
                    for j,index in enumerate(needed):
                        g=torch.autograd.grad(objectives[index],state['parameters'],retain_graph=j<len(needed)-1,allow_unused=True)
                        grads[index,:-1] += 0 if g[0] is None else arr(g[0][coordinate])
                        grads[index,-1] += 0 if g[1] is None else float(g[1][coordinate])
            state['trace']=None
            if gradient and number in (4,9,14,19,24):
                emit('training_segment_progress',arm=state['arm'],step=state['step'],segments=number+1,total=25)
        if not np.isfinite(metrics).all() or not np.isfinite(target_sum):raise FloatingPointError('nonfinite training objective')
        if gradient and not np.isfinite(grads).all():raise FloatingPointError('nonfinite row gradient')
        return dict(flow_metrics=metrics.tolist(),state_target=target_sum/max(state_count,1),
            state_positive_sum=positive_sum,state_mask_events=state_count,gradients=grads)

    validation_mask=None
    def validation(state,freeze_mask=False):
        nonlocal validation_mask
        net=state['net'];net.eval();state['trace']=[];state['count']=0;state['record_after']=0
        with torch.no_grad():
            trace=parity.run_knet_filter(net,window,previous_observation=parity.previous_observation_before_window(runtime,window))
            forecasts=parity.aligned_forecasts_from_posterior(runtime,window,trace.posterior_states)
            pairs=parity.forecast_pairs(window.observations,forecasts,issue_start=0,issue_end=728,leads=(1,2,3))
        pred=np.stack([pairs.predictions[k] for k in (1,2,3)],axis=1)
        native_mask=state_mask(state['trace'],2557)
        if freeze_mask: validation_mask=native_mask.copy()
        target,positive,values=state_terms(state['trace'],validation_mask,2557,state)
        data={k:np.stack([arr(r[k]).reshape(-1) for r in state['trace']]) for k in state['trace'][0]}
        data.update(prediction=pred,target=targets,issue_indices=issues,target_dates_ns=dates[issues[:,None]+np.arange(1,4)],
            state_mask=validation_mask,native_state_mask=native_mask,state_proxy_values=arr(values))
        state['trace']=None
        changes=data['posterior']-data['prior']
        # The native snow routine adds snowfall then melts only when T > TT.
        temperature=forcing[2557:3288,0,1]
        snow_before_melt=data['previous'][:,0]+np.where(temperature<TT,forcing[2557:3288,0,0],0.)
        data['native_snow_melt']=np.minimum(np.maximum(CFMAX*(temperature-TT),0.),snow_before_melt)
        metric=dict(mask_count=int(validation_mask.sum()),target=float(target)/max(int(validation_mask.sum()),1),
            positive_sum=float(positive),positive_mean=float(positive)/max(int(validation_mask.sum()),1),
            native_mask_count=int(native_mask.sum()),native_positive_sum=float(arr(values)[native_mask].sum()),
            mean_storages=data['posterior'][:,:5].mean(axis=0).tolist(),max_storages=data['posterior'][:,:5].max(axis=0).tolist(),
            positive_correction_sum=changes[:,:5].clip(min=0).sum(axis=0).tolist(),negative_correction_sum=changes[:,:5].clip(max=0).sum(axis=0).tolist(),
            mean_slow_baseflow_potential=float(np.mean(data['posterior'][:,4])*K2),
            snow_melt_sum=float(data['native_snow_melt'].sum()),
            snow_stock_day_sum=float(data['posterior'][:,0].sum()))
        return metric_values(pred,targets),metric,data

    def checkpoint(state):
        return dict(basin=basin,arm=state['arm'],optimizer_calls=state['calls'],effective_nonzero_steps=state['effective'],
            network={k:v.detach().cpu().clone() for k,v in state['net'].state_dict().items()},optimizer=state['optimizer'].state_dict(),
            torch_rng_state=state['rng'].clone(),parameter_sha256=parity.parameter_sha256(state['net']),contract_sha256=hashlib.sha256(raw_plan).hexdigest())

    initial_training=None;initial_validation=None;failure=None;active_arm=None;active_step=0
    for arm,state in arms.items():state['arm']=arm
    try:
        for arm,state in arms.items():
            torch.set_rng_state(state['rng'])
            train=training(state,freeze_masks=arm=='flow_control');train.pop('gradients')
            if arm=='flow_control':
                initial_training=train
                assert state_count>0,'no fixed training proxy events'
                np_save('fixed_training_masks.npz',{str(k):v for k,v in masks.items()})
            else:
                assert np.allclose(train['flow_metrics'],initial_training['flow_metrics'],rtol=0,atol=1e-12)
                assert abs(train['state_target']-initial_training['state_target'])<=1e-12
            flow,proxy,data=validation(state,freeze_mask=arm=='flow_control')
            if arm=='flow_control':
                initial_validation=(flow,proxy)
                pd=float(np.max(np.abs(data['prediction']-original_prediction)))
                sd=float(np.max(np.abs(data['posterior']-original_posterior)/arr(state['net'].state_feature_scale).reshape(1,-1)))
                assert pd<=1e-5 and sd<=64*np.finfo(np.float32).eps,'original archive replay mismatch'
                put('archive_replay_gate.json',dict(status='PASS',prediction_max_abs=pd,normalized_state_max_abs=sd,
                    state_tolerance=64*float(np.finfo(np.float32).eps),prediction_tolerance=1e-5))
            else:
                assert flow==initial_validation[0] and proxy==initial_validation[1]
            np_save(arm+'/trace_000.npz',data);pt_save(arm+'/checkpoint_000.pt',checkpoint(state))
            record=dict(step=0,optimizer_calls=0,effective_nonzero_steps=0,training=train,flow=flow,state_proxy=proxy)
            state['history'].append(record);put(arm+'/epoch_000.json',record)
        put('training_reference.json',initial_training)
        emit('initialization_and_reference_complete',state_mask_events=state_count,validation_mask_events=int(validation_mask.sum()))
        for active_step in range(1,21):
            for active_arm,state in arms.items():
                state['step']=active_step;state['phase']='gradient';torch.set_rng_state(state['rng'])
                train=training(state,gradient=True);grads=train.pop('gradients');before=vector(state)
                target_gradient=grads[0] if active_arm=='flow_control' else grads[8]
                grad_norm=float(np.linalg.norm(target_gradient));clipped=target_gradient*min(1.,10./max(grad_norm,1e-300))
                opt=state['optimizer'];opt.zero_grad(set_to_none=True)
                for p in state['parameters']:p.grad=torch.zeros_like(p)
                state['head'].weight.grad[coordinate].copy_(torch.as_tensor(clipped[:-1],dtype=state['head'].weight.dtype))
                state['head'].bias.grad[coordinate].copy_(torch.as_tensor(clipped[-1],dtype=state['head'].bias.dtype))
                state['phase']='optimizer';opt.step();state['calls']+=1
                proposal=vector(state)-before;line=[];solver=None;accepted=True;factor=1.
                if active_arm=='state_constrained':
                    projected,solver=project_displacement(proposal,grads,**dict(max_cycles=200,tolerance=1e-10))
                    accepted=False;factor=0.;install(state,before)
                    for alpha in plan['constraint_solver']['backtracking_factors']:
                        install(state,before+alpha*projected)
                        if np.array_equal(vector(state),before):
                            line.append(dict(factor=alpha,quantized_zero_step=True));break
                        state['phase']='training_constraint_check';after=training(state);after.pop('gradients')
                        good=feasible_scores(after['flow_metrics'],initial_training['flow_metrics'],after['state_target'],train['state_target'])
                        line.append(dict(factor=alpha,accepted=good,training=after))
                        if good:accepted=True;factor=alpha;break
                    if not accepted:install(state,before)
                changed=not np.array_equal(vector(state),before);state['effective']+=int(changed)
                frozen_check(state)
                if not np.isfinite(vector(state)).all():raise FloatingPointError('nonfinite updated parameters')
                state['phase']='validation';flow,proxy,data=validation(state)
                state['rng']=torch.get_rng_state().clone()
                state['phase']='record';cp_id=pt_save(active_arm+f'/checkpoint_{active_step:03d}.pt',checkpoint(state))
                if active_step==20:trace_id=np_save(active_arm+'/trace_020.npz',data)
                else:trace_id=None
                record=dict(step=active_step,optimizer_calls=state['calls'],effective_nonzero_steps=state['effective'],
                    parameter_changed=changed,gradient_norm=grad_norm,state_gradient_norm=float(np.linalg.norm(grads[8])),
                    flow_training_pre=train,solver=solver,line_search=line,accepted_factor=factor,accepted_displacement=accepted,
                    flow=flow,state_proxy=proxy,checkpoint=cp_id,trace=trace_id,frozen_rows_verified=True)
                state['history'].append(record);put(active_arm+f'/epoch_{active_step:03d}.json',record)
                emit('epoch_complete',arm=active_arm,step=active_step,optimizer_calls=state['calls'],effective_nonzero_steps=state['effective'],
                    validation_mse=flow['overall']['mse'],state_proxy=proxy['target'],accepted_factor=factor)
    except BaseException as error:
        failure=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc(),arm=active_arm,step=active_step)
        put('failure.json',failure);emit('failure',**{k:failure[k] for k in ['type','message','arm','step']})
    results={}
    for arm,state in arms.items():
        put(arm+'/history.json',state['history'])
        results[arm]=dict(optimizer_calls=state['calls'],effective_nonzero_steps=state['effective'],
            initial=state['history'][0] if state['history'] else None,last=state['history'][-1] if state['history'] else None)
    put('result.json',dict(status='COMPLETE' if failure is None else 'FAILED',basin=basin,channel=conf['channel'],
        job_id=os.environ['SLURM_JOB_ID'],array_job_id=os.environ.get('SLURM_ARRAY_JOB_ID'),array_task_id=os.environ.get('SLURM_ARRAY_TASK_ID'),
        original_epoch=conf['epoch'],arms=results,total_optimizer_calls=sum(s['calls'] for s in arms.values()),failure=failure,
        flow_metric_order=[g+'_'+m for g in plan['flow_groups'] for m in ['mse','mae']],state_target_count=state_count,
        TT=TT,K2=K2,CFMAX=CFMAX,thresholds=thresholds.tolist(),
        state_feature_scale=arr(arms['flow_control']['net'].state_feature_scale).reshape(-1).tolist(),
        observation_feature_scale=float(arms['flow_control']['net'].observation_feature_scale.reshape(())),
        finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    if failure:raise SystemExit(1)
    assert all(s['calls']==20 for s in arms.values())
    emit('basin_complete',total_optimizer_calls=40)


if __name__=='__main__':main()
