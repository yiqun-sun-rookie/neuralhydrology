"""One owned scientific child per serial array element; no retries or new attempts."""
import os,sys,json,time,threading,datetime,subprocess,re
from pathlib import Path
import psutil
import safe_io as s
BASE=Path(__file__).resolve().parent
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert os.environ.get('SLURM_JOB_ID','').isdigit(),'Slurm allocation required'
plan=json.loads(s.read_checked(BASE/'plan_contract.json'));limits=plan['resource_limits']
index=int(os.environ['SLURM_ARRAY_TASK_ID']);assert index==0
repair=json.loads(s.read_checked(BASE/'startup_repair_authorization.json'))
assert repair['status']=='AUTHORIZED_STARTUP_REPAIR' and repair['original_optimizer_calls']==0
assert repair['basin']=='02092500' and repair['remaining_optimizer_calls_per_arm']==20
limits=dict(limits)
assert repair['remaining_wall_seconds']==limits['cumulative_compute_wall_seconds']-repair['previous_wall_seconds']
limits['cumulative_compute_wall_seconds']=repair['remaining_wall_seconds']
basin=plan['basins'][index]['basin'];out='runs/'+basin+'/attempt_001'
assert not (BASE/out).exists(),'Scientific attempt already exists; automatic replay forbidden'
os.environ['HPC_BASIN']=basin
info=subprocess.run(['scontrol','-d','show','job',os.environ['SLURM_JOB_ID']],capture_output=True,text=True,check=True)
allocated=set()
for field in re.findall(r'CPU_IDs=([0-9,-]+)',info.stdout):
    for item in field.split(','):
        if '-' in item:
            first,last=map(int,item.split('-'));allocated.update(range(first,last+1))
        else:allocated.add(int(item))
proc=psutil.Process();allowed=proc.cpu_affinity();eligible=sorted(allocated.intersection(allowed))
assert eligible,'cannot bind a verified allocated CPU'
proc.cpu_affinity([eligible[0]]);proc.nice(10)
s.create(out+'/controller_started.json',dict(utc=now(),pid=proc.pid,creation_time=proc.create_time(),
    job_id=os.environ['SLURM_JOB_ID'],array_job_id=os.environ['SLURM_ARRAY_JOB_ID'],array_task_id=index,
    basin=basin,node=os.uname().nodename,allowed_affinity=allowed,allocated_cpu_ids=sorted(allocated),
    bound_affinity=proc.cpu_affinity(),priority_nice=proc.nice(),scontrol_details=info.stdout))
began=time.monotonic();chunks=[];peak=0;free_min=None;cpu_last=0;samples=0;stop=None
child=psutil.Popen([sys.executable,'-u','-B',str(BASE/'worker.py'),out],cwd=str(BASE),
    stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
child.cpu_affinity(proc.cpu_affinity());child.nice(10)
s.create(out+'/scientific_started.json',dict(utc=now(),pid=child.pid,creation_time=child.create_time(),
    job_id=os.environ['SLURM_JOB_ID'],basin=basin,affinity=child.cpu_affinity(),priority_nice=child.nice()))
def consume():
    for line in iter(child.stdout.readline,b''):
        chunks.append(line);print(line.decode('utf-8',errors='replace').rstrip(),flush=True)
reader=threading.Thread(target=consume,daemon=True);reader.start()
child.stdin.write(b'{"resources_configured":true}\n');child.stdin.flush();child.stdin.close()
while child.poll() is None:
    try:
        rss=sum(x.memory_info().rss for x in [proc,child]+child.children(recursive=True))
        free=psutil.virtual_memory().available;ct=child.cpu_times();cpu_last=ct.user+ct.system
        peak=max(peak,rss);free_min=free if free_min is None else min(free_min,free);samples+=1
        if rss>limits['combined_rss_limit_bytes']:stop='COMBINED_RSS_LIMIT'
        elif free<limits['minimum_free_bytes']:stop='SYSTEM_FREE_LIMIT'
        elif time.monotonic()-began>limits['cumulative_compute_wall_seconds']:stop='WALL_LIMIT'
        if stop:child.terminate();break
    except psutil.NoSuchProcess:pass
    time.sleep(.25)
try:child.wait(timeout=10)
except subprocess.TimeoutExpired:child.kill();child.wait()
reader.join(timeout=5)
log=s.create(out+'/stdout.log',b''.join(chunks));result_path=BASE/out/'result.json'
result=json.loads(s.read_checked(result_path)) if result_path.is_file() else None
complete=child.returncode==0 and stop is None and result and result['status']=='COMPLETE'
receipt=dict(status='COMPLETED' if complete else 'FAILED',job_id=os.environ['SLURM_JOB_ID'],
    array_job_id=os.environ['SLURM_ARRAY_JOB_ID'],array_task_id=index,basin=basin,node=os.uname().nodename,
    exit_code=child.returncode,resource_stop=stop,wall_seconds=time.monotonic()-began,
    combined_python_rss_peak_bytes=peak,system_free_min_bytes=free_min,child_cpu_seconds=cpu_last,
    resource_samples=samples,scientific_affinity=proc.cpu_affinity(),priority_nice=proc.nice(),
    mathematical_threads=1,gpu_requested=0,total_optimizer_calls=None if result is None else result['total_optimizer_calls'],
    log=log,result_present=result is not None,ended_utc=now(),
    prior_failed_wall_seconds=repair['previous_wall_seconds'],remaining_wall_budget_seconds=repair['remaining_wall_seconds'])
s.create(out+'/receipt.json',receipt);print(json.dumps(receipt),flush=True)
raise SystemExit(0 if complete else 1)
