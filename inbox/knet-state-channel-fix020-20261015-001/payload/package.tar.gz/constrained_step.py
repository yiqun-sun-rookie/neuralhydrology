"""Deterministic small-vector constraint solver; no runtime/data imports."""
import numpy as np


def project_displacement(displacement, gradients, max_cycles=200, tolerance=1e-10):
    x = np.asarray(displacement, dtype=np.float64).copy()
    a = np.asarray(gradients, dtype=np.float64).reshape(-1, len(x))
    if not np.isfinite(x).all() or not np.isfinite(a).all():
        raise FloatingPointError('nonfinite projection input')
    norms = np.linalg.norm(a, axis=1)
    a = a[norms > 0] / norms[norms > 0, None]
    if not len(a):
        return x, dict(feasible=True, cycles=0, maximum_normalized_violation=0.)
    residual = np.zeros_like(a)
    for cycle in range(max_cycles):
        before = x.copy()
        for j, normal in enumerate(a):
            trial = x + residual[j]
            x = trial - max(float(normal @ trial), 0.) * normal
            residual[j] = trial - x
        violation = max(float(np.max(a @ x)), 0.)
        if violation <= tolerance and np.linalg.norm(x-before) <= tolerance:
            return x, dict(feasible=True, cycles=cycle+1, maximum_normalized_violation=violation)
    violation = max(float(np.max(a @ x)), 0.)
    feasible = violation <= tolerance
    return (x if feasible else np.zeros_like(x)), dict(feasible=feasible, cycles=max_cycles,
        maximum_normalized_violation=violation, fallback_zero=not feasible)


def feasible_scores(scores, baseline, state_score, previous_state, tolerance=1e-12):
    x, b = np.asarray(scores, dtype=float), np.asarray(baseline, dtype=float)
    return bool(np.isfinite(x).all() and np.isfinite(state_score) and
                np.all(x <= b+tolerance) and state_score <= previous_state+tolerance)
