"""Fail-closed completeness and hash audit for the registered Nearing et al. closure."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile
import tempfile
from typing import Iterable
import zipfile

import pandas as pd


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from aggregate_registered_results import _registered_run  # noqa: E402
from audit_formal_artifacts import sha256_file  # noqa: E402
from prepare_evaluation_run import resolve_source_run  # noqa: E402


EVALUATION_AGGREGATION_FILES = (
    "aggregation_summary.json",
    "per_basin_metrics.csv",
    "time_simulation_per_basin_metrics.csv",
    "median_matrix.csv",
    "time_split_vs_author.csv",
    "basin_split_vs_author.csv",
)
HYPERPARAMETER_AGGREGATION_FILES = (
    "selection_summary.json",
    "per_basin_metrics.csv",
    "scores.csv",
)
REFERENCE_RESULT_RELATIVE_PATH = Path("test/model_epoch030/test_results.p")
IGNORED_EXTRA_TREE_PARTS = {"__pycache__", ".pytest_cache"}
FINAL_LAYER_COUNTS = {"data": 8, "method": 13, "model": 10, "result": 11}
FINAL_CONFLICT_IDS = {"D05", "P09", "P10", "P12", "P13", "L04", "L08", "L09"}
FINAL_NOT_AUDITABLE_IDS = {"P11", "R10", "R11"}
HEADLINE_RECOVERY_COORDINATES = {
    "simulation": ("training", "N22-TS-SIM-S0"),
    "autoregression": ("training", "N22-TS-AR-L01-H000-S0"),
    "assimilation": ("evaluation", "N22-EVAL-TS-DA-L01-TE000-S0"),
}
EXPECTED_DATA_MANIFEST = {
    "basin_count": 531,
    "file_count": 2131,
    "total_bytes": 1313175181,
    "basin_list_sha256": "cd2d3d466aca736fcd32042d2b0bde3d0b58e42ba37fe552d97480bd914b9e85",
    "dataset_sha256": "a3cb1f81e6b2f25e2b919c0d5b315e46fe82f8ed9c9d8a4bd56671da5500a35f",
}
EXPECTED_AUTHOR_SOURCE_ARCHIVES = {
    "experiment_zenodo_v1_0": {
        "kind": "zenodo_zip",
        "bytes": 5187841,
        "md5": "c2c449b68798637281038b53e7d20b82",
        "sha256": "5b6ac24a946d3516af6e1f8464ebceed99fd4ee09c6c8a8650a7716338dd7906",
        "file_entries": 58,
        "internal_root": "grey-nearing-lstm-data-assimilation-b254529/",
        "commit": "b254529deb75d950f6417b67e51a7292b7aed430",
        "tree": "1ab781e3a479abcde3a1f8d80fc72643141b69d3",
    },
    "model_zenodo_v1_3_0": {
        "kind": "zenodo_zip",
        "bytes": 5935555,
        "md5": "08d6ab31df0dbb3ea26be43b39521c62",
        "sha256": "91aefc74675aa83d0cc63695a48b69cec89f43605bb68c836424d839d212603d",
        "file_entries": 213,
        "internal_root": "grey-nearing-neuralhydrology-public-a4c284b/",
        "commit": "a4c284b92934ee973c8b3fedf8a60df60c8feae1",
        "tree": "0cfe36f4931fe634dd5a5b86c69ab319a0f1aeab",
    },
    "model_assimilation_git_bundle": {
        "kind": "git_bundle",
        "bytes": 11639604,
        "sha256": "c8a2e694f68450eca2f8bdfddda28a1468b9033e85ef60563d0b87c168bfadb4",
        "ref": "refs/heads/nearing2022-assimilation",
        "commit": "a3f8bfc0781af44bfee4ed3b4fdfae5ec5aa9a70",
        "tree": "ba5a6a110ed1b0b93f9c1bb8b79d7fd35a99df76",
        "tracked_file_count": 216,
        "complete_history": True,
    },
}


def _safe_manifest_member_path(relative: object, *, label: str) -> PurePosixPath:
    """Return a canonical relative POSIX path or reject the archive entry."""
    if not isinstance(relative, str) or not relative or "\\" in relative:
        raise ValueError(f"{label} must be a non-empty canonical POSIX path")
    path = PurePosixPath(relative)
    if path.is_absolute() or path.as_posix() != relative or any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError(f"Unsafe or non-canonical {label}: {relative!r}")
    return path


def _load_closure_manifest(
    manifest_path: Path,
) -> tuple[dict[str, object], Path, str, tuple[tuple[dict[str, object], Path], ...], int, str]:
    """Load and structurally validate a closure manifest before using any paths from it."""
    manifest_path = Path(manifest_path).resolve()
    if not manifest_path.is_file():
        raise FileNotFoundError(f"Closure manifest does not exist: {manifest_path}")
    manifest_bytes = manifest_path.read_bytes()
    manifest = json.loads(manifest_bytes.decode("utf-8"))
    if manifest.get("schema") != "nearing2022-registered-closure-manifest-v1":
        raise ValueError(f"Unsupported closure manifest schema in {manifest_path}")

    root_value = manifest.get("root")
    if not isinstance(root_value, str) or not root_value:
        raise ValueError("Closure manifest root must be a non-empty path")
    root = (manifest_path.parent / root_value).resolve()
    if not root.is_dir():
        raise FileNotFoundError(f"Closure manifest root does not exist: {root}")
    try:
        manifest_relative = manifest_path.relative_to(root).as_posix()
    except ValueError as exc:
        raise ValueError(f"Closure manifest is outside its declared root: {manifest_path}") from exc
    _safe_manifest_member_path(manifest_relative, label="manifest archive path")

    raw_entries = manifest.get("files")
    if not isinstance(raw_entries, list):
        raise ValueError("Closure manifest files must be a list")
    if manifest.get("file_count") != len(raw_entries):
        raise ValueError("Closure manifest file_count does not match files")

    seen_relative: set[str] = set()
    seen_sources: set[Path] = set()
    entries: list[tuple[dict[str, object], Path]] = []
    total_bytes = 0
    for index, raw_entry in enumerate(raw_entries):
        if not isinstance(raw_entry, dict):
            raise ValueError(f"Closure manifest file entry {index} is not an object")
        entry = dict(raw_entry)
        relative = entry.get("path")
        pure_path = _safe_manifest_member_path(relative, label=f"manifest file path at index {index}")
        assert isinstance(relative, str)
        if relative in seen_relative:
            raise ValueError(f"Closure manifest contains a duplicate path: {relative}")
        if relative == manifest_relative:
            raise ValueError("Closure manifest cannot hash itself")
        seen_relative.add(relative)

        byte_count = entry.get("bytes")
        if isinstance(byte_count, bool) or not isinstance(byte_count, int) or byte_count < 0:
            raise ValueError(f"Invalid byte count for closure artifact: {relative}")
        digest = entry.get("sha256")
        if (
            not isinstance(digest, str)
            or len(digest) != 64
            or digest.lower() != digest
            or any(character not in "0123456789abcdef" for character in digest)
        ):
            raise ValueError(f"Invalid SHA-256 for closure artifact: {relative}")

        source = (root / Path(*pure_path.parts)).resolve()
        try:
            source.relative_to(root)
        except ValueError as exc:
            raise ValueError(f"Closure artifact resolves outside the declared root: {relative}") from exc
        if source in seen_sources:
            raise ValueError(f"Closure manifest maps multiple paths to one file: {relative}")
        seen_sources.add(source)
        entries.append((entry, source))
        total_bytes += byte_count

    if manifest.get("total_bytes") != total_bytes:
        raise ValueError("Closure manifest total_bytes does not match files")
    return (
        manifest,
        root,
        manifest_relative,
        tuple(entries),
        len(manifest_bytes),
        hashlib.sha256(manifest_bytes).hexdigest(),
    )


def _read_registry(path: Path, id_column: str) -> pd.DataFrame:
    registry = pd.read_csv(path, keep_default_na=False, dtype=str)
    if id_column not in registry or not registry[id_column].is_unique:
        raise ValueError(f"Registry {path} lacks a unique {id_column} column")
    return registry


def _metrics_path(result_path: Path) -> Path:
    if result_path.name == "test_results.p":
        return result_path.with_name("test_metrics.csv")
    if result_path.name == "test_results_data_assimilation.p":
        return result_path.with_name("test_metrics_data_assimilation.csv")
    raise ValueError(f"Unsupported registered result filename: {result_path.name}")


def extra_tree_files(root: Path) -> tuple[Path, ...]:
    """Return stable source/protocol files while excluding generated interpreter caches."""
    root = Path(root).resolve()
    if not root.is_dir():
        raise FileNotFoundError(f"Extra artifact tree is not a directory: {root}")
    return tuple(
        path
        for path in sorted(root.rglob("*"), key=lambda item: item.as_posix())
        if path.is_file()
        and not any(part in IGNORED_EXTRA_TREE_PARTS for part in path.relative_to(root).parts)
        and path.suffix != ".pyc"
    )


def comparison_evidence_artifacts(
    repo_root: Path,
    comparison_register_path: Path,
) -> tuple[tuple[Path, str, str], ...]:
    """Resolve every comparison-register evidence reference to regular files inside the repository root."""
    repo_root = Path(repo_root).resolve()
    comparison_register_path = Path(comparison_register_path).resolve()
    register = json.loads(comparison_register_path.read_text(encoding="utf-8"))
    layers = register.get("layers")
    if not isinstance(layers, dict):
        raise ValueError("Comparison register lacks evidence layers")

    resolved: set[tuple[Path, str, str]] = set()
    for layer_name, items in layers.items():
        if not isinstance(items, list):
            raise ValueError(f"Comparison-register layer {layer_name!r} is not a list")
        for item in items:
            if not isinstance(item, dict) or not isinstance(item.get("id"), str) or not item["id"]:
                raise ValueError(f"Comparison-register layer {layer_name!r} has an invalid item")
            identifier = item["id"]
            references = item.get("evidence")
            if not isinstance(references, list) or not references:
                raise ValueError(f"Comparison-register item {identifier} has no evidence references")
            for reference in references:
                pure_reference = _safe_manifest_member_path(
                    reference,
                    label=f"comparison evidence path for {identifier}",
                )
                assert isinstance(reference, str)
                candidate = (repo_root / Path(*pure_reference.parts)).resolve()
                try:
                    candidate.relative_to(repo_root)
                except ValueError as exc:
                    raise ValueError(
                        f"Comparison evidence for {identifier} resolves outside the repository: {reference}"
                    ) from exc

                if candidate.is_file():
                    files = (candidate,)
                elif candidate.is_dir():
                    files = extra_tree_files(candidate)
                    if not files:
                        raise ValueError(
                            f"Comparison evidence directory for {identifier} contains no files: {reference}"
                        )
                else:
                    raise FileNotFoundError(
                        f"Comparison evidence for {identifier} does not exist: {reference}"
                    )
                for path in files:
                    resolved_path = path.resolve()
                    try:
                        resolved_path.relative_to(repo_root)
                    except ValueError as exc:
                        raise ValueError(
                            f"Comparison evidence for {identifier} contains a file outside the repository: {path}"
                        ) from exc
                    resolved.add((resolved_path, identifier, reference))
    return tuple(sorted(resolved, key=lambda row: (row[0].as_posix(), row[1], row[2])))


def verify_headline_artifact_recovery(
    repo_root: Path,
    training_registry_path: Path,
    evaluation_registry_path: Path,
    binding_path: Path,
) -> dict[str, object]:
    """Match the independently recovered three-condition hashes to the registered server artifacts."""
    repo_root = Path(repo_root).resolve()
    binding_path = Path(binding_path).resolve()
    binding = json.loads(binding_path.read_text(encoding="utf-8"))
    if binding.get("schema") != "nearing2022-headline-artifact-recovery-binding-v1":
        raise ValueError("Unsupported headline artifact recovery binding")
    raw_conditions = binding.get("conditions")
    if not isinstance(raw_conditions, list):
        raise ValueError("Headline artifact recovery binding lacks conditions")

    conditions_by_name: dict[str, dict[str, object]] = {}
    for raw_condition in raw_conditions:
        if not isinstance(raw_condition, dict) or not isinstance(raw_condition.get("condition"), str):
            raise ValueError("Headline artifact recovery binding has an invalid condition")
        name = raw_condition["condition"]
        if name in conditions_by_name:
            raise ValueError(f"Duplicate headline artifact recovery condition: {name}")
        conditions_by_name[name] = raw_condition
    observed_coordinates = {
        name: (condition.get("registry_kind"), condition.get("registry_id"))
        for name, condition in conditions_by_name.items()
    }
    if observed_coordinates != HEADLINE_RECOVERY_COORDINATES:
        raise ValueError("Headline artifact recovery binding changed the frozen three coordinates")

    training = _read_registry(training_registry_path, "exp_id")
    evaluations = _read_registry(evaluation_registry_path, "eval_id")
    artifacts: set[Path] = set()
    condition_summaries: dict[str, dict[str, object]] = {}
    for name, (registry_kind, registry_id) in HEADLINE_RECOVERY_COORDINATES.items():
        condition = conditions_by_name[name]
        if registry_kind == "training":
            run = resolve_source_run(repo_root, training, registry_id)
        else:
            rows = evaluations[evaluations["eval_id"] == registry_id]
            if len(rows) != 1:
                raise ValueError(f"Expected one registered headline evaluation for {registry_id}")
            run = _registered_run(repo_root, training, rows.iloc[0])
        run = Path(run).resolve()
        try:
            run.relative_to(repo_root)
        except ValueError as exc:
            raise ValueError(f"Headline artifact run is outside the repository root: {run}") from exc

        raw_files = condition.get("files")
        if not isinstance(raw_files, list) or condition.get("file_count") != len(raw_files):
            raise ValueError(f"Headline artifact file count is inconsistent for {name}")
        seen_paths: set[str] = set()
        total_bytes = 0
        for index, raw_file in enumerate(raw_files):
            if not isinstance(raw_file, dict):
                raise ValueError(f"Headline artifact entry {index} for {name} is not an object")
            relative = raw_file.get("path")
            pure_relative = _safe_manifest_member_path(
                relative,
                label=f"headline artifact path for {name} at index {index}",
            )
            assert isinstance(relative, str)
            if relative in seen_paths:
                raise ValueError(f"Duplicate headline artifact path for {name}: {relative}")
            seen_paths.add(relative)
            byte_count = raw_file.get("bytes")
            digest = raw_file.get("sha256")
            if isinstance(byte_count, bool) or not isinstance(byte_count, int) or byte_count < 0:
                raise ValueError(f"Invalid headline artifact byte count for {name}: {relative}")
            if (
                not isinstance(digest, str)
                or len(digest) != 64
                or any(character not in "0123456789abcdef" for character in digest)
            ):
                raise ValueError(f"Invalid headline artifact SHA-256 for {name}: {relative}")
            artifact = (run / Path(*pure_relative.parts)).resolve()
            try:
                artifact.relative_to(run)
            except ValueError as exc:
                raise ValueError(f"Headline artifact escapes its registered run: {artifact}") from exc
            if not artifact.is_file():
                raise FileNotFoundError(f"Recovered headline artifact is missing for {name}: {artifact}")
            if artifact.stat().st_size != byte_count:
                raise ValueError(f"Recovered headline artifact size changed for {name}: {relative}")
            if sha256_file(artifact) != digest:
                raise ValueError(f"Recovered headline artifact hash changed for {name}: {relative}")
            artifacts.add(artifact)
            total_bytes += byte_count
        if condition.get("total_bytes") != total_bytes:
            raise ValueError(f"Headline artifact total_bytes is inconsistent for {name}")
        condition_summaries[name] = {
            "registry_kind": registry_kind,
            "registry_id": registry_id,
            "run": str(run),
            "file_count": len(raw_files),
            "total_bytes": total_bytes,
        }
    return {
        "ok": True,
        "binding": str(binding_path),
        "conditions": condition_summaries,
        "file_count": len(artifacts),
        "artifacts": tuple(sorted(artifacts, key=lambda path: path.as_posix())),
    }


def verify_data_manifest_equivalence(
    local_manifest_path: Path,
    hpc_manifest_path: Path,
    execution_manifest_path: Path,
) -> dict[str, object]:
    """Validate and compare the local, transferred HPC, and execution-copy data manifests."""
    paths = {
        "local": Path(local_manifest_path).resolve(),
        "hpc_evidence": Path(hpc_manifest_path).resolve(),
        "hpc_execution": Path(execution_manifest_path).resolve(),
    }
    normalized: dict[str, dict[str, object]] = {}
    source_sha256: dict[str, str] = {}
    for label, path in paths.items():
        payload_bytes = path.read_bytes()
        payload = json.loads(payload_bytes.decode("utf-8"))
        if payload.get("schema") != "nearing2022-camels-us-data-manifest-v1":
            raise ValueError(f"Unsupported CAMELS-US data manifest schema: {label}")
        if payload.get("data_root") != ".":
            raise ValueError(f"CAMELS-US data manifest must use a logical relative root: {label}")
        for key, expected in EXPECTED_DATA_MANIFEST.items():
            if payload.get(key) != expected:
                raise ValueError(f"CAMELS-US data manifest {label} changed {key}")
        raw_files = payload.get("files")
        if not isinstance(raw_files, list) or len(raw_files) != EXPECTED_DATA_MANIFEST["file_count"]:
            raise ValueError(f"CAMELS-US data manifest file list is inconsistent: {label}")
        seen: set[tuple[str, str, str]] = set()
        byte_total = 0
        dataset_digest = hashlib.sha256()
        for index, entry in enumerate(raw_files):
            if not isinstance(entry, dict):
                raise ValueError(f"CAMELS-US data manifest entry {index} is invalid: {label}")
            role = entry.get("role")
            basin = entry.get("basin")
            relative = entry.get("path")
            byte_count = entry.get("bytes")
            digest = entry.get("sha256")
            if not isinstance(role, str) or not isinstance(basin, str):
                raise ValueError(f"CAMELS-US data manifest identity is invalid at entry {index}: {label}")
            _safe_manifest_member_path(relative, label=f"CAMELS-US path at entry {index}")
            assert isinstance(relative, str)
            identity = (role, basin, relative)
            if identity in seen:
                raise ValueError(f"CAMELS-US data manifest contains a duplicate entry: {identity}")
            seen.add(identity)
            if isinstance(byte_count, bool) or not isinstance(byte_count, int) or byte_count < 0:
                raise ValueError(f"CAMELS-US data manifest byte count is invalid: {identity}")
            if (
                not isinstance(digest, str)
                or len(digest) != 64
                or any(character not in "0123456789abcdef" for character in digest)
            ):
                raise ValueError(f"CAMELS-US data manifest SHA-256 is invalid: {identity}")
            byte_total += byte_count
            dataset_digest.update(f"{role}\t{basin}\t{relative}\t{byte_count}\t{digest}\n".encode("utf-8"))
        if byte_total != EXPECTED_DATA_MANIFEST["total_bytes"]:
            raise ValueError(f"CAMELS-US data manifest byte total is inconsistent: {label}")
        dataset_digest.update(
            f"basin_list\t{EXPECTED_DATA_MANIFEST['basin_count']}\t"
            f"{EXPECTED_DATA_MANIFEST['basin_list_sha256']}\n".encode("utf-8")
        )
        if dataset_digest.hexdigest() != EXPECTED_DATA_MANIFEST["dataset_sha256"]:
            raise ValueError(f"CAMELS-US data manifest aggregate digest is inconsistent: {label}")
        normalized[label] = {key: value for key, value in payload.items() if key != "created_utc"}
        source_sha256[label] = hashlib.sha256(payload_bytes).hexdigest()
    if not (normalized["local"] == normalized["hpc_evidence"] == normalized["hpc_execution"]):
        raise ValueError("Local, HPC evidence, and HPC execution CAMELS-US manifests are not equivalent")
    return {
        "ok": True,
        **EXPECTED_DATA_MANIFEST,
        "source_sha256": source_sha256,
        "paths": {label: str(path) for label, path in paths.items()},
    }


def verify_author_source_archives(repo_root: Path, binding_path: Path) -> dict[str, object]:
    """Verify the exact official source archives and the self-contained assimilation Git bundle."""
    root = Path(repo_root).resolve()
    binding_path = Path(binding_path).resolve()
    try:
        binding_path.relative_to(root)
    except ValueError as exc:
        raise ValueError("Author source archive binding is outside the repository root") from exc
    payload = json.loads(binding_path.read_text(encoding="utf-8"))
    if payload.get("schema") != "nearing2022-author-source-archive-binding-v1":
        raise ValueError("Unsupported author source archive binding schema")
    raw_archives = payload.get("archives")
    if not isinstance(raw_archives, list):
        raise ValueError("Author source archive binding must contain an archives list")
    archives_by_id: dict[str, dict[str, object]] = {}
    for index, raw_archive in enumerate(raw_archives):
        if not isinstance(raw_archive, dict):
            raise ValueError(f"Author source archive entry {index} is not an object")
        archive_id = raw_archive.get("id")
        if not isinstance(archive_id, str) or archive_id in archives_by_id:
            raise ValueError(f"Invalid or duplicate author source archive id: {archive_id!r}")
        archives_by_id[archive_id] = raw_archive
    if set(archives_by_id) != set(EXPECTED_AUTHOR_SOURCE_ARCHIVES):
        raise ValueError("Author source archive binding does not contain the exact required archive set")

    archive_paths: list[Path] = []
    summaries: dict[str, dict[str, object]] = {}
    for archive_id, expected in EXPECTED_AUTHOR_SOURCE_ARCHIVES.items():
        archive = archives_by_id[archive_id]
        for key, expected_value in expected.items():
            if archive.get(key) != expected_value:
                raise ValueError(f"Author source archive {archive_id} changed {key}")
        relative = archive.get("path")
        pure_path = _safe_manifest_member_path(relative, label=f"author source archive path {archive_id}")
        archive_path = (root / Path(*pure_path.parts)).resolve()
        try:
            archive_path.relative_to(root)
        except ValueError as exc:
            raise ValueError(f"Author source archive escapes the repository root: {archive_id}") from exc
        if not archive_path.is_file():
            raise FileNotFoundError(f"Author source archive is missing: {archive_path}")
        if archive_path.stat().st_size != expected["bytes"]:
            raise ValueError(f"Author source archive size changed: {archive_id}")
        if sha256_file(archive_path) != expected["sha256"]:
            raise ValueError(f"Author source archive SHA-256 changed: {archive_id}")

        if expected["kind"] == "zenodo_zip":
            md5 = hashlib.md5()  # noqa: S324 - required only to compare with the Zenodo deposit checksum
            with archive_path.open("rb") as source:
                for chunk in iter(lambda: source.read(1024 * 1024), b""):
                    md5.update(chunk)
            if md5.hexdigest() != expected["md5"]:
                raise ValueError(f"Author Zenodo archive MD5 changed: {archive_id}")
            seen_names: set[str] = set()
            file_entries = 0
            with zipfile.ZipFile(archive_path, "r") as archive_zip:
                for info in archive_zip.infolist():
                    name = info.filename
                    if name in seen_names:
                        raise ValueError(f"Author Zenodo archive contains a duplicate entry: {name}")
                    seen_names.add(name)
                    if not name.startswith(str(expected["internal_root"])):
                        raise ValueError(f"Author Zenodo archive entry has the wrong root: {name}")
                    canonical_name = name[:-1] if name.endswith("/") else name
                    _safe_manifest_member_path(canonical_name, label=f"ZIP entry in {archive_id}")
                    mode = (info.external_attr >> 16) & 0o170000
                    if mode == 0o120000:
                        raise ValueError(f"Author Zenodo archive contains a symbolic link: {name}")
                    if not info.is_dir():
                        file_entries += 1
                if archive_zip.testzip() is not None:
                    raise ValueError(f"Author Zenodo archive failed its CRC check: {archive_id}")
            if file_entries != expected["file_entries"]:
                raise ValueError(f"Author Zenodo archive file count changed: {archive_id}")
            summaries[archive_id] = {
                "kind": expected["kind"],
                "bytes": expected["bytes"],
                "sha256": expected["sha256"],
                "file_entries": file_entries,
                "commit": expected["commit"],
                "tree": expected["tree"],
            }
        elif expected["kind"] == "git_bundle":
            with tempfile.TemporaryDirectory(prefix="nearing2022-bundle-") as temporary:
                temporary_root = Path(temporary)
                empty_repository = temporary_root / "verify.git"
                cloned_repository = temporary_root / "source.git"
                subprocess.run(
                    ["git", "init", "--bare", "--quiet", str(empty_repository)],
                    check=True,
                    capture_output=True,
                    text=True,
                )
                verification = subprocess.run(
                    ["git", "bundle", "verify", str(archive_path)],
                    cwd=empty_repository,
                    check=True,
                    capture_output=True,
                    text=True,
                )
                heads = subprocess.run(
                    ["git", "bundle", "list-heads", str(archive_path)],
                    check=True,
                    capture_output=True,
                    text=True,
                ).stdout.splitlines()
                expected_head = f"{expected['commit']} {expected['ref']}"
                if heads != [expected_head]:
                    raise ValueError("Assimilation Git bundle does not contain the exact required head")
                subprocess.run(
                    ["git", "clone", "--bare", "--quiet", str(archive_path), str(cloned_repository)],
                    check=True,
                    capture_output=True,
                    text=True,
                )
                resolved_commit = subprocess.run(
                    ["git", "rev-parse", str(expected["ref"])],
                    cwd=cloned_repository,
                    check=True,
                    capture_output=True,
                    text=True,
                ).stdout.strip()
                resolved_tree = subprocess.run(
                    ["git", "rev-parse", f"{expected['commit']}^{{tree}}"],
                    cwd=cloned_repository,
                    check=True,
                    capture_output=True,
                    text=True,
                ).stdout.strip()
                tracked_files = subprocess.run(
                    ["git", "ls-tree", "-rz", "--name-only", str(expected["commit"])],
                    cwd=cloned_repository,
                    check=True,
                    capture_output=True,
                ).stdout.rstrip(b"\0").split(b"\0")
                subprocess.run(
                    ["git", "fsck", "--full", "--strict", "--no-dangling"],
                    cwd=cloned_repository,
                    check=True,
                    capture_output=True,
                    text=True,
                )
            if resolved_commit != expected["commit"] or resolved_tree != expected["tree"]:
                raise ValueError("Assimilation Git bundle commit or tree identity changed")
            if len(tracked_files) != expected["tracked_file_count"]:
                raise ValueError("Assimilation Git bundle tracked-file count changed")
            summaries[archive_id] = {
                "kind": expected["kind"],
                "bytes": expected["bytes"],
                "sha256": expected["sha256"],
                "commit": resolved_commit,
                "tree": resolved_tree,
                "tracked_file_count": len(tracked_files),
                "complete_history_verified_in_empty_repository": verification.returncode == 0,
            }
        else:  # pragma: no cover - fixed schema prevents this branch
            raise ValueError(f"Unsupported author source archive kind: {expected['kind']}")
        archive_paths.append(archive_path)
    return {
        "ok": True,
        "binding": str(binding_path),
        "archives": summaries,
        "artifacts": tuple(archive_paths),
    }


def _record_artifact(
    artifacts: dict[Path, list[dict[str, str]]],
    missing: list[dict[str, str]],
    path: Path,
    coordinate_type: str,
    coordinate_id: str,
    role: str,
) -> None:
    path = Path(path).resolve()
    binding = {
        "coordinate_type": coordinate_type,
        "coordinate_id": coordinate_id,
        "role": role,
    }
    if path.is_file():
        artifacts.setdefault(path, []).append(binding)
    else:
        missing.append({**binding, "path": str(path)})


def _record_resolution_failure(
    missing: list[dict[str, str]],
    coordinate_type: str,
    coordinate_id: str,
    exc: Exception,
    *,
    role: str = "run_resolution",
) -> None:
    missing.append({
        "coordinate_type": coordinate_type,
        "coordinate_id": coordinate_id,
        "role": role,
        "path": "",
        "error": f"{type(exc).__name__}: {exc}",
    })


def audit_registered_closure(
    repo_root: Path,
    training_registry_path: Path,
    evaluation_registry_path: Path,
    hyperparameter_registry_path: Path,
    evaluation_aggregation_dir: Path,
    hyperparameter_aggregation_dir: Path,
    *,
    expected_training: int = 46,
    expected_evaluations: int = 180,
    expected_hyperparameters: int = 660,
    extra_files: Iterable[Path] = (),
    comparison_evidence: Iterable[tuple[Path, str, str]] = (),
) -> dict[str, object]:
    """Bind every registered coordinate to the files required for a defensible reproduction."""
    repo_root = Path(repo_root).resolve()
    training_registry_path = Path(training_registry_path).resolve()
    evaluation_registry_path = Path(evaluation_registry_path).resolve()
    hyperparameter_registry_path = Path(hyperparameter_registry_path).resolve()
    training = _read_registry(training_registry_path, "exp_id")
    evaluations = _read_registry(evaluation_registry_path, "eval_id")
    hyperparameters = _read_registry(hyperparameter_registry_path, "eval_id")
    counts = {
        "training": len(training),
        "evaluations": len(evaluations),
        "hyperparameters": len(hyperparameters),
    }
    expected_counts = {
        "training": expected_training,
        "evaluations": expected_evaluations,
        "hyperparameters": expected_hyperparameters,
    }
    missing: list[dict[str, str]] = []
    for name, expected in expected_counts.items():
        if counts[name] != expected:
            missing.append({
                "coordinate_type": "registry",
                "coordinate_id": name,
                "role": "coordinate_count",
                "path": "",
                "error": f"expected {expected}, found {counts[name]}",
            })

    artifacts: dict[Path, list[dict[str, str]]] = {}
    for path, identifier in (
        (training_registry_path, "training"),
        (evaluation_registry_path, "evaluations"),
        (hyperparameter_registry_path, "hyperparameters"),
    ):
        _record_artifact(artifacts, missing, path, "registry", identifier, "registry")

    for _, row in training.iterrows():
        identifier = row["exp_id"]
        try:
            run = resolve_source_run(repo_root, training, identifier)
        except (FileNotFoundError, KeyError, ValueError) as exc:
            _record_resolution_failure(missing, "training", identifier, exc)
            continue
        roles = {
            "run_config": run / "config.yml",
            "checkpoint_epoch030": run / "model_epoch030.pt",
            "training_log": run / "output.log",
            "train_data_scaler": run / "train_data" / "train_data_scaler.yml",
        }
        for role, path in roles.items():
            _record_artifact(artifacts, missing, path, "training", identifier, role)

    for _, row in evaluations.iterrows():
        identifier = row["eval_id"]
        try:
            run = _registered_run(repo_root, training, row)
        except (FileNotFoundError, KeyError, ValueError) as exc:
            _record_resolution_failure(missing, "evaluation", identifier, exc, role="candidate_run_resolution")
        else:
            result = run / row["result_file"]
            roles = {
                "run_config": run / "config.yml",
                "checkpoint_epoch030": run / "model_epoch030.pt",
                "evaluation_log": run / "output.log",
                "prediction": result,
                "metrics": _metrics_path(result),
            }
            for role, path in roles.items():
                _record_artifact(artifacts, missing, path, "evaluation", identifier, role)

        try:
            reference_run = resolve_source_run(repo_root, training, row["reference_exp_id"])
        except (FileNotFoundError, KeyError, ValueError) as exc:
            _record_resolution_failure(missing, "evaluation", identifier, exc, role="reference_run_resolution")
        else:
            reference_result = reference_run / REFERENCE_RESULT_RELATIVE_PATH
            _record_artifact(
                artifacts, missing, reference_result, "evaluation", identifier, "reference_prediction"
            )
            _record_artifact(
                artifacts,
                missing,
                _metrics_path(reference_result),
                "evaluation",
                identifier,
                "reference_metrics",
            )

    for _, row in hyperparameters.iterrows():
        identifier = row["eval_id"]
        run = Path(row["run_dir"])
        run = run if run.is_absolute() else repo_root / run
        result = run / row["result_file"]
        roles = {
            "run_config": run / "config.yml",
            "checkpoint_epoch030": run / "model_epoch030.pt",
            "evaluation_log": run / "output.log",
            "prediction": result,
            "metrics": _metrics_path(result),
        }
        for role, path in roles.items():
            _record_artifact(artifacts, missing, path, "hyperparameter", identifier, role)

        try:
            reference_run = resolve_source_run(repo_root, training, row["source_exp_id"])
        except (FileNotFoundError, KeyError, ValueError) as exc:
            _record_resolution_failure(missing, "hyperparameter", identifier, exc, role="reference_run_resolution")
        else:
            reference_result = reference_run / REFERENCE_RESULT_RELATIVE_PATH
            _record_artifact(
                artifacts, missing, reference_result, "hyperparameter", identifier, "reference_prediction"
            )
            _record_artifact(
                artifacts,
                missing,
                _metrics_path(reference_result),
                "hyperparameter",
                identifier,
                "reference_metrics",
            )

    for name in EVALUATION_AGGREGATION_FILES:
        _record_artifact(
            artifacts,
            missing,
            Path(evaluation_aggregation_dir) / name,
            "aggregation",
            "evaluations",
            name,
        )
    for name in HYPERPARAMETER_AGGREGATION_FILES:
        _record_artifact(
            artifacts,
            missing,
            Path(hyperparameter_aggregation_dir) / name,
            "aggregation",
            "hyperparameters",
            name,
        )
    for index, path in enumerate(extra_files):
        _record_artifact(artifacts, missing, path, "provenance", f"extra_{index:03d}", "provenance")
    for path, identifier, reference in comparison_evidence:
        _record_artifact(
            artifacts,
            missing,
            path,
            "comparison_evidence",
            identifier,
            f"evidence:{reference}",
        )

    artifact_rows = [
        {"path": str(path), "bindings": sorted(bindings, key=lambda item: tuple(item.values()))}
        for path, bindings in sorted(artifacts.items(), key=lambda item: item[0].as_posix())
    ]
    return {
        "schema": "nearing2022-registered-closure-audit-v1",
        "complete": not missing,
        "counts": counts,
        "expected_counts": expected_counts,
        "missing": missing,
        "artifacts": artifact_rows,
    }


def write_closure_manifest(audit: dict[str, object], root: Path, output_path: Path) -> dict[str, object]:
    """Hash a complete audit without accepting partial coordinates or files outside the closure root."""
    if not audit.get("complete"):
        raise ValueError("Refusing to hash an incomplete registered closure")
    root = Path(root).resolve()
    output_path = Path(output_path).resolve()
    if output_path.exists():
        raise FileExistsError(f"Refusing to overwrite closure manifest: {output_path}")
    entries: list[dict[str, object]] = []
    for artifact in audit["artifacts"]:
        path = Path(artifact["path"]).resolve()
        try:
            relative = path.relative_to(root)
        except ValueError as exc:
            raise ValueError(f"Artifact is outside closure root: {path}") from exc
        entries.append({
            "path": relative.as_posix(),
            "bytes": path.stat().st_size,
            "sha256": sha256_file(path),
            "bindings": artifact["bindings"],
        })
    relative_root = Path(os.path.relpath(root, output_path.parent)).as_posix()
    manifest = {
        "schema": "nearing2022-registered-closure-manifest-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "root": relative_root,
        "counts": audit["counts"],
        "file_count": len(entries),
        "total_bytes": sum(int(entry["bytes"]) for entry in entries),
        "files": entries,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = output_path.with_suffix(output_path.suffix + ".tmp")
    if temporary.exists():
        raise FileExistsError(f"Refusing to reuse closure manifest temporary file: {temporary}")
    temporary.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    temporary.replace(output_path)
    return manifest


def verify_closure_manifest(manifest_path: Path) -> dict[str, object]:
    _, _, _, entries, _, _ = _load_closure_manifest(manifest_path)
    missing: list[str] = []
    size_mismatches: list[str] = []
    hash_mismatches: list[str] = []
    for entry, path in entries:
        relative = str(entry["path"])
        if not path.is_file():
            missing.append(relative)
            continue
        if path.stat().st_size != int(entry["bytes"]):
            size_mismatches.append(relative)
        if sha256_file(path) != entry["sha256"]:
            hash_mismatches.append(relative)
    return {
        "ok": not missing and not size_mismatches and not hash_mismatches,
        "missing_files": sorted(missing),
        "size_mismatches": sorted(size_mismatches),
        "hash_mismatches": sorted(hash_mismatches),
    }


def verify_frozen_numerical_gate(
    gate_output_path: Path,
    gate_details_path: Path,
    gate_log_path: Path,
) -> dict[str, object]:
    """Prove the gate files still match the SHA-256 values emitted by their completed Slurm job."""
    targets = tuple(Path(path).resolve() for path in (gate_output_path, gate_details_path))
    gate_log_path = Path(gate_log_path).resolve()
    if not gate_log_path.is_file():
        raise FileNotFoundError(f"Numerical-gate Slurm log does not exist: {gate_log_path}")
    recorded: dict[Path, list[str]] = {target: [] for target in targets}
    for line in gate_log_path.read_text(encoding="utf-8", errors="replace").splitlines():
        fields = line.strip().split(maxsplit=1)
        if len(fields) != 2:
            continue
        digest, raw_path = fields
        if len(digest) != 64 or any(character not in "0123456789abcdef" for character in digest):
            continue
        candidate = Path(raw_path.lstrip("*")).resolve()
        if candidate in recorded:
            recorded[candidate].append(digest)

    verified: dict[str, str] = {}
    for target in targets:
        digests = recorded[target]
        if len(digests) != 1:
            raise ValueError(f"Expected one frozen SHA-256 record for {target}, found {len(digests)}")
        if not target.is_file():
            raise FileNotFoundError(f"Frozen numerical-gate artifact does not exist: {target}")
        current = sha256_file(target)
        if current != digests[0]:
            raise ValueError(f"Frozen numerical-gate artifact changed after Slurm completion: {target}")
        verified[str(target)] = current
    gate = json.loads(targets[0].read_text(encoding="utf-8"))
    input_artifacts = gate.get("input_artifacts")
    required_inputs = {"time_comparisons", "basin_comparisons", "hyperparameter_scores", "acceptance"}
    if not isinstance(input_artifacts, dict) or set(input_artifacts) != required_inputs:
        raise ValueError("Frozen numerical gate does not bind exactly its three comparison inputs and acceptance")
    verified_inputs: dict[str, str] = {}
    for label in sorted(required_inputs):
        artifact = input_artifacts[label]
        if not isinstance(artifact, dict):
            raise ValueError(f"Frozen numerical-gate input record is invalid: {label}")
        raw_path = artifact.get("path")
        byte_count = artifact.get("bytes")
        digest = artifact.get("sha256")
        if not isinstance(raw_path, str) or not raw_path:
            raise ValueError(f"Frozen numerical-gate input path is invalid: {label}")
        if isinstance(byte_count, bool) or not isinstance(byte_count, int) or byte_count < 0:
            raise ValueError(f"Frozen numerical-gate input byte count is invalid: {label}")
        if (
            not isinstance(digest, str)
            or len(digest) != 64
            or any(character not in "0123456789abcdef" for character in digest)
        ):
            raise ValueError(f"Frozen numerical-gate input SHA-256 is invalid: {label}")
        path = Path(raw_path).resolve()
        if not path.is_file():
            raise FileNotFoundError(f"Frozen numerical-gate input does not exist: {path}")
        if path.stat().st_size != byte_count:
            raise ValueError(f"Frozen numerical-gate input size changed after decision: {path}")
        current = sha256_file(path)
        if current != digest:
            raise ValueError(f"Frozen numerical-gate input changed after decision: {path}")
        verified_inputs[label] = current
    return {
        "gate_log": str(gate_log_path),
        "verified_sha256": verified,
        "verified_input_sha256": verified_inputs,
    }


class _HashingReader:
    """Hash the exact bytes consumed by tarfile while preserving streaming behavior."""

    def __init__(self, stream):
        self._stream = stream
        self._hasher = hashlib.sha256()
        self.bytes_read = 0

    def read(self, size: int = -1) -> bytes:
        chunk = self._stream.read(size)
        self._hasher.update(chunk)
        self.bytes_read += len(chunk)
        return chunk

    @property
    def sha256(self) -> str:
        return self._hasher.hexdigest()


def _canonical_tar_info(source: Path, archive_name: str) -> tarfile.TarInfo:
    """Create stable metadata for one regular file without archiving links or directories."""
    source_stat = source.stat()
    info = tarfile.TarInfo(name=archive_name)
    info.size = source_stat.st_size
    info.mode = source_stat.st_mode & 0o777
    info.type = tarfile.REGTYPE
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    info.mtime = 0
    info.pax_headers = {}
    return info


def _write_tar_member(
    archive: tarfile.TarFile,
    source: Path,
    archive_name: str,
    expected_bytes: int,
    expected_sha256: str,
) -> None:
    if not source.is_file():
        raise FileNotFoundError(f"Closure artifact does not exist: {source}")
    info = _canonical_tar_info(source, archive_name)
    if info.size != expected_bytes:
        raise ValueError(f"Closure artifact size changed before export: {archive_name}")
    with source.open("rb") as source_stream:
        reader = _HashingReader(source_stream)
        archive.addfile(info, reader)
    if reader.bytes_read != expected_bytes:
        raise ValueError(f"Closure artifact byte count changed during export: {archive_name}")
    if reader.sha256 != expected_sha256:
        raise ValueError(f"Closure artifact hash changed during export: {archive_name}")


def _sha256_stream(stream) -> str:
    hasher = hashlib.sha256()
    while True:
        chunk = stream.read(1024 * 1024)
        if not chunk:
            return hasher.hexdigest()
        hasher.update(chunk)


def verify_closure_export(manifest_path: Path, archive_path: Path) -> dict[str, object]:
    """Verify that an export contains exactly every manifest-bound byte plus the manifest itself."""
    _, _, manifest_relative, entries, manifest_bytes, manifest_sha256 = _load_closure_manifest(manifest_path)
    archive_path = Path(archive_path).resolve()
    if not archive_path.is_file():
        raise FileNotFoundError(f"Closure export does not exist: {archive_path}")

    expected: dict[str, tuple[int, str]] = {
        str(entry["path"]): (int(entry["bytes"]), str(entry["sha256"])) for entry, _ in entries
    }
    expected[manifest_relative] = (manifest_bytes, manifest_sha256)
    duplicate_members: list[str] = []
    unsafe_members: list[str] = []
    non_regular_members: list[str] = []
    size_mismatches: list[str] = []
    hash_mismatches: list[str] = []
    members_by_name: dict[str, tarfile.TarInfo] = {}

    with tarfile.open(archive_path, mode="r:gz") as archive:
        for member in archive.getmembers():
            try:
                _safe_manifest_member_path(member.name, label="archive member path")
            except ValueError:
                unsafe_members.append(member.name)
                continue
            if member.name in members_by_name:
                duplicate_members.append(member.name)
                continue
            members_by_name[member.name] = member
            if not member.isfile():
                non_regular_members.append(member.name)

        missing_members = sorted(set(expected) - set(members_by_name))
        extra_members = sorted(set(members_by_name) - set(expected))
        for name, (expected_bytes, expected_digest) in expected.items():
            member = members_by_name.get(name)
            if member is None or not member.isfile():
                continue
            if member.size != expected_bytes:
                size_mismatches.append(name)
                continue
            member_stream = archive.extractfile(member)
            if member_stream is None:
                non_regular_members.append(name)
                continue
            with member_stream:
                if _sha256_stream(member_stream) != expected_digest:
                    hash_mismatches.append(name)

    return {
        "ok": not any((
            missing_members,
            extra_members,
            duplicate_members,
            unsafe_members,
            non_regular_members,
            size_mismatches,
            hash_mismatches,
        )),
        "expected_members": len(expected),
        "archive_members": len(members_by_name),
        "missing_members": missing_members,
        "extra_members": extra_members,
        "duplicate_members": sorted(set(duplicate_members)),
        "unsafe_members": sorted(set(unsafe_members)),
        "non_regular_members": sorted(set(non_regular_members)),
        "size_mismatches": sorted(set(size_mismatches)),
        "hash_mismatches": sorted(set(hash_mismatches)),
    }


def build_closure_export(manifest_path: Path, archive_path: Path) -> dict[str, object]:
    """Build an atomic, deterministic, self-contained archive from a frozen closure manifest."""
    manifest_path = Path(manifest_path).resolve()
    archive_path = Path(archive_path).resolve()
    if archive_path.exists():
        raise FileExistsError(f"Refusing to overwrite closure export: {archive_path}")
    _, _, manifest_relative, entries, manifest_bytes, manifest_sha256 = _load_closure_manifest(manifest_path)
    temporary = archive_path.with_name(f".{archive_path.name}.{os.getpid()}.tmp")
    if temporary.exists():
        raise FileExistsError(f"Refusing to reuse closure export temporary file: {temporary}")
    archive_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        with temporary.open("xb") as raw_stream:
            with gzip.GzipFile(
                filename="", mode="wb", compresslevel=6, fileobj=raw_stream, mtime=0
            ) as compressed_stream:
                with tarfile.open(fileobj=compressed_stream, mode="w", format=tarfile.PAX_FORMAT) as archive:
                    for entry, source in sorted(entries, key=lambda item: str(item[0]["path"])):
                        _write_tar_member(
                            archive,
                            source,
                            str(entry["path"]),
                            int(entry["bytes"]),
                            str(entry["sha256"]),
                        )
                    _write_tar_member(
                        archive,
                        manifest_path,
                        manifest_relative,
                        manifest_bytes,
                        manifest_sha256,
                    )
        verification = verify_closure_export(manifest_path, temporary)
        if not verification["ok"]:
            raise ValueError(f"Built closure export failed verification: {verification}")
        temporary.replace(archive_path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise

    return {
        "archive": str(archive_path),
        "archive_bytes": archive_path.stat().st_size,
        "archive_sha256": sha256_file(archive_path),
        "verification": verification,
    }


def validate_final_decision_artifacts(
    comparison_register_path: Path,
    source_scope_audit_path: Path,
    audit_report_path: Path,
    gate_output_path: Path,
) -> dict[str, object]:
    """Reject a final archive when its numerical, protocol, and publication decisions disagree."""
    register = json.loads(Path(comparison_register_path).read_text(encoding="utf-8"))
    if register.get("schema") != "nearing2022-reproduction-comparison-register-v1":
        raise ValueError("Unsupported final comparison-register schema")
    layers = register.get("layers")
    if not isinstance(layers, dict) or {name: len(items) for name, items in layers.items()} != FINAL_LAYER_COUNTS:
        raise ValueError("Final comparison register must contain the frozen 8/13/10/11 layer counts")
    items = [item for layer in layers.values() for item in layer]
    identifiers = [item.get("id") for item in items]
    if len(identifiers) != len(set(identifiers)) or len(identifiers) != sum(FINAL_LAYER_COUNTS.values()):
        raise ValueError("Final comparison register must contain 42 unique identifiers")
    pending = sorted(item["id"] for item in items if item.get("status") == "pending")
    if pending:
        raise ValueError(f"Final comparison register still has pending items: {pending}")
    allowed_final_statuses = {"verified", "verified_with_boundary", "conflict", "not_auditable"}
    invalid_statuses = sorted({str(item.get("status")) for item in items} - allowed_final_statuses)
    if invalid_statuses:
        raise ValueError(f"Final comparison register has unsupported statuses: {invalid_statuses}")
    incomplete_evidence = sorted(
        item["id"]
        for item in items
        if not isinstance(item.get("current_reproduction"), str)
        or not item["current_reproduction"].strip()
        or not isinstance(item.get("evidence"), list)
        or not item["evidence"]
        or any(not isinstance(path, str) or not path.strip() for path in item["evidence"])
    )
    if incomplete_evidence:
        raise ValueError(f"Final comparison register has incomplete evidence fields: {incomplete_evidence}")
    conflict_ids = {item["id"] for item in items if item.get("status") == "conflict"}
    not_auditable_ids = {item["id"] for item in items if item.get("status") == "not_auditable"}
    if not FINAL_CONFLICT_IDS <= conflict_ids:
        raise ValueError("Final comparison register dropped a known paper-versus-release conflict")
    if not FINAL_NOT_AUDITABLE_IDS <= not_auditable_ids:
        raise ValueError("Final comparison register dropped a known publication-scope gap")
    if register.get("overall_status") != "PARTIALLY_REPRODUCIBLE":
        raise ValueError("Final comparison register overall status must be PARTIALLY_REPRODUCIBLE")

    gate = json.loads(Path(gate_output_path).read_text(encoding="utf-8"))
    if gate.get("schema") != "nearing2022-full-reproduction-gate-v1":
        raise ValueError("Unsupported or missing final numerical-gate schema")
    numerical_status = gate.get("released_code_numerical_status")
    if numerical_status not in {"GO", "NO_GO"}:
        raise ValueError("Final numerical gate must decide GO or NO_GO")
    decisions = register.get("decision_targets")
    if not isinstance(decisions, dict):
        raise ValueError("Final comparison register lacks the three decision targets")
    main_decision = str(decisions.get("released_main_numerical_matrix", ""))
    literal_decision = str(decisions.get("literal_paper_text", ""))
    study_decision = str(decisions.get("complete_published_study", ""))
    if numerical_status not in main_decision:
        raise ValueError("Released-main-matrix decision does not match the numerical gate")
    if "partially reproducible" not in literal_decision.lower():
        raise ValueError("Literal-paper decision must remain partially reproducible")
    if "not fully reproducible" not in study_decision.lower():
        raise ValueError("Complete-study decision must remain not fully reproducible")

    source_scope = json.loads(Path(source_scope_audit_path).read_text(encoding="utf-8"))
    if source_scope.get("schema") != "nearing2022-author-release-scope-audit-v1":
        raise ValueError("Unsupported or missing author-release scope audit")
    coverage = {item.get("component"): item for item in source_scope.get("published_output_coverage", [])}
    for component in ("basin-attribute attribution and spatial maps", "computational runtime comparison"):
        if coverage.get(component, {}).get("status") != "not_auditable":
            raise ValueError(f"Author-release scope gap was not preserved: {component}")

    report = Path(audit_report_path).read_text(encoding="utf-8")
    required_report_decisions = (
        f"作者发布主数值矩阵：**{numerical_status}**",
        "论文字面协议：**部分可复现**",
        "完整已发表研究：**不能完整复现**",
    )
    missing_report_decisions = [text for text in required_report_decisions if text not in report]
    if missing_report_decisions:
        raise ValueError(f"Final audit report lacks explicit three-level decisions: {missing_report_decisions}")
    if "**当前判定：HOLD。**" in report:
        raise ValueError("Final audit report still contains the phase HOLD heading")
    return {
        "comparison_items": len(items),
        "conflicts": len(conflict_ids),
        "not_auditable": len(not_auditable_ids),
        "released_code_numerical_status": numerical_status,
        "report_decisions": list(required_report_decisions),
    }


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--training-registry", type=Path, required=True)
    parser.add_argument("--evaluation-registry", type=Path, required=True)
    parser.add_argument("--hyperparameter-registry", type=Path, required=True)
    parser.add_argument("--evaluation-aggregation-dir", type=Path, required=True)
    parser.add_argument("--hyperparameter-aggregation-dir", type=Path, required=True)
    parser.add_argument("--manifest-output", type=Path)
    parser.add_argument("--comparison-register", type=Path, required=True)
    parser.add_argument("--source-scope-audit", type=Path, required=True)
    parser.add_argument("--audit-report", type=Path, required=True)
    parser.add_argument("--gate-output", type=Path, required=True)
    parser.add_argument("--gate-details", type=Path, required=True)
    parser.add_argument("--gate-log", type=Path, required=True)
    parser.add_argument("--headline-artifact-binding", type=Path, required=True)
    parser.add_argument("--author-source-archive-binding", type=Path, required=True)
    parser.add_argument("--local-data-manifest", type=Path, required=True)
    parser.add_argument("--hpc-data-manifest", type=Path, required=True)
    parser.add_argument("--execution-data-manifest", type=Path, required=True)
    parser.add_argument("--extra-file", type=Path, action="append", default=[])
    parser.add_argument("--extra-tree", type=Path, action="append", default=[])
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    final_decisions = validate_final_decision_artifacts(
        args.comparison_register,
        args.source_scope_audit,
        args.audit_report,
        args.gate_output,
    )
    frozen_gate = verify_frozen_numerical_gate(args.gate_output, args.gate_details, args.gate_log)
    headline_recovery = verify_headline_artifact_recovery(
        args.repo_root,
        args.training_registry,
        args.evaluation_registry,
        args.headline_artifact_binding,
    )
    author_source_archives = verify_author_source_archives(
        args.repo_root,
        args.author_source_archive_binding,
    )
    data_manifests = verify_data_manifest_equivalence(
        args.local_data_manifest,
        args.hpc_data_manifest,
        args.execution_data_manifest,
    )
    comparison_evidence = comparison_evidence_artifacts(args.repo_root, args.comparison_register)
    extra_files = [
        *args.extra_file,
        args.comparison_register,
        args.source_scope_audit,
        args.audit_report,
        args.gate_output,
        args.gate_details,
        args.gate_log,
        args.headline_artifact_binding,
        *headline_recovery["artifacts"],
        args.author_source_archive_binding,
        *author_source_archives["artifacts"],
        args.local_data_manifest,
        args.hpc_data_manifest,
        args.execution_data_manifest,
    ]
    for tree in args.extra_tree:
        extra_files.extend(extra_tree_files(tree))
    audit = audit_registered_closure(
        args.repo_root,
        args.training_registry,
        args.evaluation_registry,
        args.hyperparameter_registry,
        args.evaluation_aggregation_dir,
        args.hyperparameter_aggregation_dir,
        extra_files=extra_files,
        comparison_evidence=comparison_evidence,
    )
    summary = {
        "complete": audit["complete"],
        "counts": audit["counts"],
        "final_decisions": final_decisions,
        "frozen_gate": frozen_gate,
        "headline_recovery": {
            key: value for key, value in headline_recovery.items() if key != "artifacts"
        },
        "author_source_archives": {
            key: value for key, value in author_source_archives.items() if key != "artifacts"
        },
        "data_manifests": data_manifests,
        "missing_count": len(audit["missing"]),
        "missing_first": audit["missing"][:10],
    }
    if not audit["complete"]:
        print(json.dumps(summary, indent=2, sort_keys=True))
        return 2
    if args.manifest_output is not None:
        manifest = write_closure_manifest(audit, args.repo_root, args.manifest_output)
        verification = verify_closure_manifest(args.manifest_output)
        summary.update({
            "manifest": str(args.manifest_output),
            "file_count": manifest["file_count"],
            "total_bytes": manifest["total_bytes"],
            "manifest_verification": verification,
        })
        if not verification["ok"]:
            print(json.dumps(summary, indent=2, sort_keys=True))
            return 3
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
