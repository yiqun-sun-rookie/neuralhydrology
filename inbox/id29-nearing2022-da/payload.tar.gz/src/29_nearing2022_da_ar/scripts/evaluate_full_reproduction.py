"""Apply frozen numerical gates to the complete released Nearing et al. matrix."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable, Mapping

import numpy as np
import pandas as pd


METRICS = ("NSE", "KGE", "Alpha-NSE", "Pearson-r", "Beta-NSE", "Peak-Timing", "Missed-Peaks")
TIME_FAMILY_COORDINATES = {
    "time_simulation": 1,
    "time_autoregression": 125,
    "time_assimilation": 25,
}
BASIN_FAMILIES = ("basin_simulation", "basin_autoregression", "basin_assimilation")


def _require_columns(frame: pd.DataFrame, columns: Iterable[str], label: str) -> None:
    missing = sorted(set(columns) - set(frame.columns))
    if missing:
        raise ValueError(f"{label} lacks required columns: {missing}")


def _validate_acceptance(acceptance: Mapping[str, object]) -> None:
    if acceptance.get("schema") != "nearing2022-reproduction-acceptance-v1":
        raise ValueError("Unsupported or missing reproduction acceptance schema")
    scope = acceptance.get("scope")
    if not isinstance(scope, Mapping) or scope.get("numerical_target") != "released_code":
        raise ValueError("Acceptance contract must identify the released-code numerical target")
    if scope.get("hyperparameter_evaluation_period") != "test":
        raise ValueError("Released-code hyperparameter evidence must be labeled as test-period evaluation")
    if scope.get("paper_text_hyperparameter_evaluation_period") != "validation":
        raise ValueError("Acceptance contract must preserve the paper-text validation-period discrepancy")
    expected = acceptance.get("expected")
    if not isinstance(expected, Mapping):
        raise ValueError("Acceptance contract lacks expected counts")
    fixed_counts = {
        "time_comparison_rows": sum(TIME_FAMILY_COORDINATES.values()) * len(METRICS),
        "basin_comparison_rows": len(BASIN_FAMILIES) * len(METRICS),
        "hyperparameter_coordinates": 660,
    }
    if {key: int(expected.get(key, -1)) for key in fixed_counts} != fixed_counts:
        raise ValueError(f"Acceptance expected counts do not match the released matrix: {expected}")
    for key in ("absolute_difference_tolerance", "median_signed_difference_tolerance"):
        values = acceptance.get(key)
        if not isinstance(values, Mapping) or set(values) != set(METRICS):
            raise ValueError(f"Acceptance {key} must define exactly {METRICS}")
        if any(float(values[metric]) < 0 for metric in METRICS):
            raise ValueError(f"Acceptance {key} contains a negative tolerance")


def _comparison_details(
    frame: pd.DataFrame,
    *,
    component: str,
    coordinate_columns: list[str],
    tolerances: Mapping[str, object],
) -> pd.DataFrame:
    _require_columns(frame, [*coordinate_columns, "family", "metric", "reproduction", "author", "difference"], component)
    details = frame.copy()
    if details.duplicated([*coordinate_columns, "metric"]).any():
        raise ValueError(f"{component} contains duplicate coordinate/metric rows")
    if set(details["metric"]) != set(METRICS):
        raise ValueError(f"{component} metric set does not match the released seven metrics")
    for column in ("reproduction", "author", "difference"):
        details[column] = pd.to_numeric(details[column], errors="raise")
        if not np.isfinite(details[column]).all():
            raise ValueError(f"{component} contains non-finite {column} values")
    recomputed = details["reproduction"] - details["author"]
    if not np.allclose(recomputed, details["difference"], rtol=0.0, atol=1e-10):
        raise ValueError(f"{component} difference column is inconsistent with reproduction minus author")
    details.insert(0, "component", component)
    details["coordinate_id"] = details[coordinate_columns].astype(str).agg("|".join, axis=1)
    details["abs_difference"] = details["difference"].abs()
    details["tolerance"] = details["metric"].map({metric: float(tolerances[metric]) for metric in METRICS})
    details["within_tolerance"] = details["abs_difference"] <= details["tolerance"] + 1e-12
    return details[[
        "component",
        "coordinate_id",
        "family",
        "metric",
        "reproduction",
        "author",
        "difference",
        "abs_difference",
        "tolerance",
        "within_tolerance",
    ]]


def _validate_time_shape(frame: pd.DataFrame) -> None:
    expected_rows = sum(TIME_FAMILY_COORDINATES.values()) * len(METRICS)
    if len(frame) != expected_rows:
        raise ValueError(f"Expected {expected_rows} time comparison rows, found {len(frame)}")
    for family, coordinates in TIME_FAMILY_COORDINATES.items():
        family_frame = frame.loc[frame["family"] == family]
        if len(family_frame) != coordinates * len(METRICS):
            raise ValueError(f"{family} must contain {coordinates * len(METRICS)} rows, found {len(family_frame)}")
        groups = family_frame.groupby("eval_id")["metric"].agg(lambda values: set(values))
        if len(groups) != coordinates or any(values != set(METRICS) for values in groups):
            raise ValueError(f"{family} does not contain exactly seven metrics for each coordinate")
    unknown = sorted(set(frame["family"]) - set(TIME_FAMILY_COORDINATES))
    if unknown:
        raise ValueError(f"Unknown time comparison families: {unknown}")


def _validate_basin_shape(frame: pd.DataFrame) -> None:
    expected_rows = len(BASIN_FAMILIES) * len(METRICS)
    if len(frame) != expected_rows:
        raise ValueError(f"Expected {expected_rows} basin comparison rows, found {len(frame)}")
    if set(frame["family"]) != set(BASIN_FAMILIES):
        raise ValueError("Basin comparison families do not match the three released methods")
    for family in BASIN_FAMILIES:
        metrics = set(frame.loc[frame["family"] == family, "metric"])
        if metrics != set(METRICS):
            raise ValueError(f"{family} does not contain exactly the released seven metrics")


def _hyperparameter_gate(scores: pd.DataFrame, acceptance: Mapping[str, object]) -> dict[str, object]:
    required = [
        "grid_index",
        "eval_id",
        "window",
        "epochs",
        "history",
        "learning_rate",
        "drop_factor",
        "targets",
        "NSE",
    ]
    _require_columns(scores, required, "hyperparameter scores")
    expected = int(acceptance["expected"]["hyperparameter_coordinates"])
    if len(scores) != expected or scores["eval_id"].nunique() != expected or scores["grid_index"].nunique() != expected:
        raise ValueError("Hyperparameter scores must contain 660 unique registered coordinates")
    scores = scores.copy()
    scores["NSE"] = pd.to_numeric(scores["NSE"], errors="raise")
    if not np.isfinite(scores["NSE"]).all():
        raise ValueError("Hyperparameter scores contain non-finite NSE values")
    default = acceptance["released_default"]
    mask = (
        (pd.to_numeric(scores["window"], errors="raise") == int(default["window"]))
        & (pd.to_numeric(scores["epochs"], errors="raise") == int(default["epochs"]))
        & (pd.to_numeric(scores["history"], errors="raise") == int(default["history"]))
        & np.isclose(pd.to_numeric(scores["learning_rate"], errors="raise"), float(default["learning_rate"]))
        & np.isclose(pd.to_numeric(scores["drop_factor"], errors="raise"), float(default["drop_factor"]))
        & (scores["targets"].astype(str) == str(default["targets"]))
    )
    selected = scores.loc[mask]
    if len(selected) != 1:
        raise ValueError(f"Expected one released-default hyperparameter coordinate, found {len(selected)}")
    best_nse = float(scores["NSE"].max())
    default_nse = float(selected.iloc[0]["NSE"])
    deficit = max(0.0, best_nse - default_nse)
    maximum = float(acceptance["hyperparameter_default_max_nse_deficit"])
    descending = scores.sort_values(["NSE", "grid_index"], ascending=[False, True]).reset_index(drop=True)
    default_rank = int(descending.index[descending["eval_id"] == selected.iloc[0]["eval_id"]][0]) + 1
    return {
        "coordinates": len(scores),
        "best_eval_id": str(descending.iloc[0]["eval_id"]),
        "best_nse": best_nse,
        "released_default_eval_id": str(selected.iloc[0]["eval_id"]),
        "released_default_nse": default_nse,
        "released_default_rank": default_rank,
        "released_default_exact_best": bool(np.isclose(default_nse, best_nse, rtol=0.0, atol=1e-12)),
        "released_default_nse_deficit": deficit,
        "maximum_allowed_nse_deficit": maximum,
        "within_functional_tolerance": bool(deficit <= maximum + 1e-12),
    }


def evaluate_reproduction_gate(
    time_comparisons: pd.DataFrame,
    basin_comparisons: pd.DataFrame,
    hyperparameter_scores: pd.DataFrame,
    acceptance: Mapping[str, object],
) -> tuple[dict[str, object], pd.DataFrame]:
    """Return a complete numerical gate and one row per published comparison."""
    _validate_acceptance(acceptance)
    _validate_time_shape(time_comparisons)
    _validate_basin_shape(basin_comparisons)
    absolute_tolerances = acceptance["absolute_difference_tolerance"]
    time_details = _comparison_details(
        time_comparisons,
        component="time_split",
        coordinate_columns=["eval_id"],
        tolerances=absolute_tolerances,
    )
    basin_details = _comparison_details(
        basin_comparisons,
        component="basin_split",
        coordinate_columns=["family"],
        tolerances=absolute_tolerances,
    )
    details = pd.concat([time_details, basin_details], ignore_index=True)
    systematic_tolerances = {
        metric: float(acceptance["median_signed_difference_tolerance"][metric]) for metric in METRICS
    }
    systematic_rows = []
    for metric in METRICS:
        signed_median = float(details.loc[details["metric"] == metric, "difference"].median())
        tolerance = systematic_tolerances[metric]
        systematic_rows.append({
            "metric": metric,
            "median_signed_difference": signed_median,
            "tolerance": tolerance,
            "within_tolerance": bool(abs(signed_median) <= tolerance + 1e-12),
        })
    hyperparameter = _hyperparameter_gate(hyperparameter_scores, acceptance)
    individual_failures = int((~details["within_tolerance"]).sum())
    systematic_failures = sum(not row["within_tolerance"] for row in systematic_rows)
    passed = individual_failures == 0 and systematic_failures == 0 and hyperparameter["within_functional_tolerance"]
    gate = {
        "schema": "nearing2022-full-reproduction-gate-v1",
        "acceptance_frozen_at": acceptance.get("frozen_at", "test-contract"),
        "numerical_target": acceptance["scope"]["numerical_target"],
        "hyperparameter_evaluation_period": acceptance["scope"]["hyperparameter_evaluation_period"],
        "paper_text_hyperparameter_evaluation_period": acceptance["scope"][
            "paper_text_hyperparameter_evaluation_period"
        ],
        "released_code_numerical_status": "GO" if passed else "NO_GO",
        "comparison_rows": len(details),
        "individual_tolerance_failures": individual_failures,
        "systematic_bias_failures": systematic_failures,
        "systematic_bias": systematic_rows,
        "hyperparameter_selection": hyperparameter,
    }
    return gate, details


def _atomic_json(payload: Mapping[str, object], path: Path) -> None:
    if path.exists():
        raise FileExistsError(f"Refusing to overwrite frozen numerical gate: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    if temporary.exists():
        raise FileExistsError(f"Refusing to reuse numerical-gate temporary file: {temporary}")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    temporary.replace(path)


def _atomic_csv(frame: pd.DataFrame, path: Path) -> None:
    if path.exists():
        raise FileExistsError(f"Refusing to overwrite frozen numerical details: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    if temporary.exists():
        raise FileExistsError(f"Refusing to reuse numerical-details temporary file: {temporary}")
    frame.to_csv(temporary, index=False, lineterminator="\n", float_format="%.12g")
    temporary.replace(path)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--time-comparisons", type=Path, required=True)
    parser.add_argument("--basin-comparisons", type=Path, required=True)
    parser.add_argument("--hyperparameter-scores", type=Path, required=True)
    parser.add_argument("--acceptance", type=Path, required=True)
    parser.add_argument("--gate-output", type=Path, required=True)
    parser.add_argument("--details-output", type=Path, required=True)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    acceptance = json.loads(args.acceptance.read_text(encoding="utf-8"))
    gate, details = evaluate_reproduction_gate(
        pd.read_csv(args.time_comparisons, keep_default_na=False),
        pd.read_csv(args.basin_comparisons, keep_default_na=False),
        pd.read_csv(args.hyperparameter_scores, keep_default_na=False),
        acceptance,
    )
    _atomic_csv(details, args.details_output)
    _atomic_json(gate, args.gate_output)
    print(json.dumps(gate, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
