# 复现 Nearing 等 2022：LSTM 变分同化 vs 自回归

起点交接：`draft/handoffs/2026-08-07_nearing2022_da_ar_reproduction_handoff.md`
论文：Nearing et al. (2022), *HESS* 26, 5493–5513, https://hess.copernicus.org/articles/26/5493/2022/

本目录只放复现所需的配置与脚本。同化功能本身已经移植进核心包，不在这里。

## 0. 2026-08-10 正式审计状态（覆盖下文旧的“全部完成”表述）

**结论：论文头条三条件可复现；整项研究目前为 HOLD，不能再写成“已完整复现”。**

已确认事实：

- 原始配置、训练日志、第 30 轮检查点、缩放参数和 531 流域逐日预测已从高性能计算集群取回并固定哈希。
- 使用独立实现、完整共同观测记录重算的中位纳什–萨特克利夫效率为：仿真 `0.792329`、自回归 `0.882910`、变分数据同化 `0.863494`；分别与作者表中的 `0.796 / 0.879 / 0.862` 相差 `−0.003671 / +0.003910 / +0.001494`。
- 本地与服务器实际训练数据逐文件一致：531 个流域、2,131 个输入文件、1,313,175,181 字节，整体 SHA-256 为 `a3cb1f81e6b2f25e2b919c0d5b315e46fe82f8ed9c9d8a4bd56671da5500a35f`。
- 作者发布代码定义的 46 个训练坐标、180 个评价坐标和 660 个数据同化超参数坐标已经冻结。训练作业为 `202214`、`202215`、`202216`；评价和超参数作业为 `202222`、`202226`、`202227`、`202238`、`202228`；成功完成全部上游任务后才运行的独立汇总作业为 `202229`、`202230`，增强后的最终全角色哈希闸门和导出作业分别为 `202280`、`202281`。

尚未完成：训练扣除 50% 观测的第四列、完整“训练缺测率 × 测试缺测率 × 预见期”矩阵、十折未参与训练流域实验和 660 坐标超参数证据仍在运行。只有这些作业完成、原始结果重新计分并与作者发布的逐流域统计比较后，才能把整项研究状态改为“可复现”。

## 1. 代码来源与移植状态

| 来源 | 内容 | 本仓状态 |
|---|---|---|
| `grey-nearing/neuralhydrology-public` 分支 `assimilation`（单 commit `a3f8bfc`，基于 tag `v.1.3.0`） | 变分同化实现 | **已移植**，见下 |
| `grey-nearing/lstm-data-assimilation` tag `v1.0` | 复现脚本、531 流域列表、结果统计 | 流域列表与头条表已取回本目录 |

移植落点（全部为增量改动，不改变既有行为）：

- `neuralhydrology/evaluation/assimilation.py`（新）—— 同化主体
- `neuralhydrology/utils/assimilationconfig.py`（新）—— `assimilation_config` 配置块
- `neuralhydrology/modelzoo/cudalstm.py` —— 接受 `h_n`/`c_n` 作为初始状态并原样返回
- `neuralhydrology/modelzoo/basemodel.py` —— `state_var_names`
- `neuralhydrology/modelzoo/__init__.py` —— `ASSIMILATION_MODELS` 守卫
- `neuralhydrology/training/__init__.py` —— `get_optimizer` 同时接受 Module 和张量列表
- `neuralhydrology/utils/config.py` —— `assimilation_config` 属性
- `neuralhydrology/evaluation/tester.py`、`evaluation/evaluate.py`、`nh_run.py` —— `--data-assimilation` 通路
- `test/test_assimilation.py`（新）—— 16 项测试

作者的 fork 是 v1.3.0，本仓是 1.12.0。移植时只有三处需要真改，其余是机械搬运：

1. `data['x_d']` 在 1.12.0 是 **dict**（每个特征一个张量），v1.3.0 是单个 `[batch, seq, feature]` 张量。所有时间切片和 NaN 掩码改成按特征处理。
2. `BaseLoss.forward` 在 1.12.0 返回 `(total_loss, all_losses)` 元组，v1.3.0 返回标量。
3. batch 里现在有非张量条目（`date`），克隆/掩码时要放行。

作者那个 commit 里还有一处 `import pdb; pdb.set_trace()` 的调试残留和一次 `Config`→`BaseConfig`/`AssimilationConfig` 的重构，两者都没有移植（前者是垃圾，后者会跟本仓的 `Config` 冲突）。

## 2. 复现目标（作者放出的原始表，`reference/author_headline_table.txt`）

531 流域中位数，**单 seed（seed 0），不是集成**；滞后 1 天、测试期不扣观测：

| 指标 | 仿真 | AR（训练扣 0%） | AR（训练扣 50%） | 变分同化 |
|---|---|---|---|---|
| NSE | 0.796 | **0.879** | 0.872 | **0.862** |
| KGE | 0.795 | 0.896 | 0.896 | 0.878 |
| Alpha-NSE | 0.874 | 0.942 | 0.945 | 0.913 |
| Pearson-r | 0.902 | 0.939 | 0.937 | 0.932 |
| Beta-NSE | −0.027 | −0.007 | −0.002 | −0.014 |
| Peak-Timing | 0.263 | 0.385 | 0.368 | 0.444 |
| Missed-Peaks | 0.352 | 0.250 | 0.262 | 0.250 |

精确坐标（来自 `analysis_time_split.ipynb` 第 49 格）：仿真 = seed 0；AR = `(train_holdout, test_holdout, lead, seed) = (0.0, 0.0, 1, 0)` 与 `(0.5, 0.0, 1, 0)`；同化 = `(holdout, lead, seed) = (0.0, 1, 0)`。

本仓 531 流域列表与作者的 `531_basin_list.txt` **逐字节相同**（已核对）。

## 3. 论文正文与放出代码不一致的地方

复现按**放出的代码**走，因为那是真正产出上表的东西。逐条列出以便日后追溯：

| 项 | 论文正文 | 放出的配置/代码 | 本仓采用 |
|---|---|---|---|
| LSTM 细胞状态数 | 128 | **256** | 256 |
| 静态属性个数 | 引 Kratzert 2019 Table 1（27 个） | **26 个**，缺 `p_seasonality` | 26 |
| 同化学习率衰减因子 | 0.9 | **0.1** | 0.1 |
| 同化早停阈值 | 学习率 < 1e-6 | 代码硬编码 **1e-5**（另有 loss < 1e-5） | 1e-5 |
| 同化窗口数（history） | 正文未给具体值 | **20**，即同化跨度 20×5 = 100 步 | 20 |
| 同化目标函数覆盖范围 | Eq. D1 写的是整个窗口 `‖y[t−s:t] − ŷ[t−s:t]‖²` | `predict_last_n: 1` 使得**只有每个窗口的最后一步进入损失** | 照代码 |
| 同化超参数选择时期 | 1980–1989 验证期 | 发布的调度命令未传 `--period validation`，模型代码默认使用 **1989–1999 测试期**；`hypertuning_analysis.py` 也读取 `test` 结果 | 测试期，并明确标为“发布代码复现” |

后两条直接影响方法解释：一个“5 步同化窗口”实际是**用 1 个观测约束 5 步模型积分**，然后这样的窗口顺序做 20 次；同时，当前 660 坐标超参数证据只能验证作者发布代码的测试期选择行为，不能证明论文所写的独立验证期选择。

代码里还有两个正文没写、但确实改变算法行为的实现细节（已在 `assimilation.py` 顶部注释标出，移植时原样保留）：

1. 一旦某次更新使损失变大，`assim_data` 被重新绑定到一份快照，而优化器仍持有原来的叶张量。**从此该窗口的数值不再变化**，只剩学习率继续衰减直到触发早停。所谓"回退"回退的是数值，但优化器与数据已经脱钩。
2. 学习率在窗口循环**之外**初始化，因此衰减后的值会带到下一个同化窗口。

配合 `learning_rate_drop_factor: 0.1` 和 `learning_rate_epoch_drop: 1001`（后者等于关掉"连续成功后降 lr"这条路径），实际行为是：**第一次失败的更新之后不久就停**，而不是跑满 100 步。

## 3.4 复现结果：三条臂全部通过（2026-08-10 06:15）

HPC 作业 `201858`（仿真）、`201890`（变分同化）和 `201893`（自回归）均为 `COMPLETED 0:0`。作业 `202159` 用共同的完整观测记录重新计算三臂对比，亦为 `COMPLETED 0:0`。三条臂均有 **531 个流域**进入计分。

下表每格依次为“本次复现 / 论文 / 差值”：

| 指标 | 仿真 | 自回归（训练扣 0%） | 变分同化 |
|---|---|---|---|
| **NSE** | **0.792 / 0.796 / −0.004** | **0.883 / 0.879 / +0.004** | **0.863 / 0.862 / +0.001** |
| KGE | 0.801 / 0.795 / +0.006 | 0.896 / 0.896 / −0.000 | 0.877 / 0.878 / −0.001 |
| Alpha-NSE | 0.866 / 0.874 / −0.008 | 0.933 / 0.942 / −0.009 | 0.915 / 0.913 / +0.002 |
| Pearson-r | 0.902 / 0.902 / −0.000 | 0.941 / 0.939 / +0.002 | 0.932 / 0.932 / −0.000 |
| Beta-NSE | −0.026 / −0.027 / +0.001 | −0.004 / −0.007 / +0.003 | −0.014 / −0.014 / +0.000 |
| Peak-Timing | 0.263 / 0.263 / +0.000 | 0.368 / 0.385 / −0.017 | 0.467 / 0.444 / +0.023 |
| Missed-Peaks | 0.355 / 0.352 / +0.003 | 0.246 / 0.250 / −0.004 | 0.250 / 0.250 / +0.000 |

**结论：论文头条三条件通过；不能据此判定整项研究已经复现。** 三条臂的中位 NSE 差值均远小于 ±0.02；其余六项指标没有系统性偏离。需如实保留的最大单项差异是变分同化的 Peak-Timing（峰值时间误差指标）`+0.023`。本次自回归和变分同化相对仿真的 NSE 增益分别为 `+0.091` 和 `+0.071`，论文对应值为 `+0.083` 和 `+0.066`。

结果链：三条臂均评估 `model_epoch030`；运行目录、作业编号和计分数量见 `results/29_nearing2022_da_ar/reproduction_audit.md`，当前决定性表见 `results/29_nearing2022_da_ar/formal_closure/headline_three_arm_vs_paper.csv`。

这三条结果共同验证了 extended 强迫数据、反向划分、NSE* 损失、531 流域列表，并且**坐实了第 3 节的取值方针**：论文正文与作者放出的配置冲突时按实际产出结果的配置取值（`hidden_size: 256` 而非正文的 128、静态属性 26 个而非正文引用的 27 个）。

## 3.5 管线冒烟：三条臂已在真实 CAMELS 上跑通（2026-08-08）

20 流域、3 轮、用本地可得的 maurer/nldas/daymet（**不是** extended）。**这些数不是复现**，只证明管线通并测出成本。配置见 `configs/smoke_*.yml`，产物在 `results/29_nearing2022_da_ar/smoke/`。

| 指标 | 仿真 | AR（滞后 1） | 同化 | 论文 仿真 | 论文 AR | 论文 DA |
|---|---|---|---|---|---|---|
| NSE | 0.737 | 0.840 | 0.844 | 0.796 | 0.879 | 0.862 |
| KGE | 0.801 | 0.860 | 0.877 | 0.795 | 0.896 | 0.878 |
| Alpha-NSE | 0.855 | 0.880 | 0.912 | 0.874 | 0.942 | 0.913 |
| Beta-NSE | −0.050 | −0.031 | −0.015 | −0.027 | −0.007 | −0.014 |
| Pearson-r | 0.877 | 0.925 | 0.919 | 0.902 | 0.939 | 0.932 |
| Peak-Timing | 0.265 | 0.372 | 0.523 | 0.263 | 0.385 | 0.444 |
| Missed-Peaks | 0.341 | 0.310 | 0.278 | 0.352 | 0.250 | 0.250 |

相对仿真的 NSE 增益：AR +0.103、DA +0.107（论文 +0.083、+0.066）。定性结构对上了。这里 DA ≈ AR 而论文里 AR > DA，20 流域 3 轮下这个次序没有意义——模型欠训练时状态离最优更远，同化能捞回的更多。

**实测成本（RTX 4070 Ti 12 GB）**：20 流域 3 轮下，仿真训练 2m25s、AR 训练 8m13s（慢 3.6 倍，ARLSTM 要逐步喂回预测，用不了 cuDNN 融合 LSTM）、DA 在整个测试期推理 7m09s。

外推到 531 流域 30 轮：**仿真约 9 小时、AR 约 32 小时、DA 推理约 3 小时，串行合计约 44 小时。**

## 4. 数据缺口

作者三套强迫全喂，其中两套写的是 **extended** 版。本仓 `data/camels_us/basin_mean_forcing/` 只有 `daymet`、`maurer`、`nldas` 三个目录，没有带 `_extended` 后缀的。但逐个查过内容之后，缺口比目录名显示的小：

| 本地目录 | 时间范围 | 列名大小写 | 判断 |
|---|---|---|---|
| `daymet` | 1980–2014 | 小写 | 与作者配置里的 `*_daymet` 一致 |
| `nldas` | 1980–**2014** | 大写 | 时间与列名都符合 `nldas_extended` 的特征（原始 CAMELS NLDAS 到 2008） |
| `maurer` | 1980–**2008** | 大写 | `maurer_extended` 是小写列名且到 2014，**这份不是** |

本实验的训练/验证/测试期全部结束于 2008-09-30，所以"延长到 2014"这部分差异用不上。**唯一未知的是 1980–2008 区间内 maurer 与 maurer_extended 的数值是否不同**——尚未核实，不要当已知处理。（`data/CAMELS_US/_maurer_header_fix_backup_20260616/` 显示本仓 2026-06-16 曾把 4 个分区的 maurer 表头从小写无日期列改写成 daymet 式大写，属本地改动，与 extended 无关。）

因此有两条路：补齐 `maurer_extended` 后完全照配置跑；或先用本地 `maurer` 跑并把这条记为明确偏差。选后者时要改 `forcings` 和 `dynamic_inputs` 的大小写，参照 `configs/smoke_*.yml`。

## 5. 怎么跑

三条臂里前两条要训练（各 30 轮 × 531 流域，需要 GPU），第三条不训练。

```bash
# 臂 1：仿真基线
python -m neuralhydrology.nh_run train --config-file src/29_nearing2022_da_ar/configs/simulation_531.yml --gpu 0

# 臂 2：自回归（本仓自带 ARLSTM，不需要重写）
python -m neuralhydrology.nh_run train --config-file src/29_nearing2022_da_ar/configs/autoregression_531_lead1_holdout0.yml --gpu 0

# 臂 3：变分同化——复用臂 1 的权重，不训练
python src/29_nearing2022_da_ar/scripts/make_assimilation_run.py \
    --simulation-run-dir results/29_nearing2022_da_ar/<臂1的 run 目录> --lead 1 --holdout 0.0
python -m neuralhydrology.nh_run evaluate --run-dir <上一步打印的目录> --period test --data-assimilation
```

同化结果写入 `test_results_data_assimilation.p` / `test_metrics_data_assimilation.csv`，不会覆盖开环结果。

## 5.5 HPC（河海 hpcbh）

用户 2026-08-08 决定完整 531 复现上 HPC 跑。落点 `~/nearing2022_da`，**不碰 `~/neuralhydrology`**（那里有 78 个未提交文件）。

- 代码：从本地打包经 GitHub 信箱通道送过去（channel `id29-nearing2022-da`，见 `docs/hpc/HPC_AGENT_GUIDE.md`）
- CAMELS 主数据：软链到 `~/neuralhydrology_backup_20260304/data/camels_us`（675 maurer / 677 daymet / 675 nldas / 674 流量）
- extended 强迫：HPC 直连 HydroShare 自己下的（HPC 可达，不用从本地传 855 MB），落 `~/nearing2022_da/data/camels_us/basin_mean_forcing/{maurer,nldas}_extended`。HPC 上验出的日较差与本地逐位一致
- 环境：`nh_final` = Python 3.11.13 / torch 2.4.0 / CUDA 12.1；NH 依赖齐（缺 sklearn，核心用不到）
- 分区：`hgpu4`（节点 4 卡，A40）、`hgpu8`（8 卡）、`hgpu2`

**A40 实测**（6 流域 1 轮环境冒烟，作业 201839，9 分 36 秒）：训练 1 轮 6.5 秒；DA 推理 **40 秒/流域**（整个 10 年测试期）；仿真 NSE 0.4232 → 同化 0.6942。

外推 531 流域：仿真训练约 **3 h**、AR 训练约 **11 h**、DA 推理约 **6 h**。两条训练臂独立可并行。

SLURM 脚本在信箱 `inbox/id29_{simulation,autoregression,smoke}.slurm`。

## 6. 算指标时的坑

扣观测比例 > 0 的实验里，观测记录本身被打了洞。**指标必须拿仿真 run（无扣除）里的完整观测记录来算**，不能用 DA/AR 结果文件里自带的观测——作者在 `analysis_time_split.ipynb` 第 21 格明确这么做。头条那一列扣除比例是 0，不受影响；做扣除扫描时必须照办。

另外 AR 臂扣的是 `QObs(mm/d)_shift1`（移位后的输入列），DA 臂扣的是 `QObs(mm/d)`（原始列，同时也是评价目标）。两条臂的扣除语义不对称，这正是上面那条要求存在的原因。

## 7. 不要重做的事

- **自回归不要重写**：`neuralhydrology/modelzoo/arlstm.py` 就是作者本人的实现，上游已吸收。
- **"拉长预见期会翻盘"已被否掉**：完美强迫下滞后与预见期是同一个轴，作者测到滞后 10 天，各档下 AR 始终优于其 DA。
- 本仓 531 的 0.7589（8 seed 集成中位）用的是仅 Maurer + repro_v01 划分，**不能**和这里的 0.796 直接比。
