from __future__ import annotations

from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import pickle
import tarfile

import numpy as np
import pandas as pd
import pytest
import xarray as xr
import yaml

from neuralhydrology.evaluation import metrics as nh_metrics


REPO_ROOT = Path(__file__).resolve().parents[1]
IDEA_ROOT = REPO_ROOT / "src" / "29_nearing2022_da_ar"
SCRIPT_PATH = IDEA_ROOT / "scripts" / "build_full_experiment_registry.py"
AUDIT_SCRIPT_PATH = IDEA_ROOT / "scripts" / "audit_formal_artifacts.py"
SCORER_SCRIPT_PATH = IDEA_ROOT / "scripts" / "score_reproduction_matrix.py"
DATA_MANIFEST_SCRIPT_PATH = IDEA_ROOT / "scripts" / "build_data_manifest.py"
EVALUATION_REGISTRY_SCRIPT_PATH = IDEA_ROOT / "scripts" / "build_evaluation_registry.py"
TRAINING_SLURM_PATH = IDEA_ROOT / "hpc" / "run_registered_training.slurm"
TRAINING_ARRAY_SLURM_PATH = IDEA_ROOT / "hpc" / "run_registered_training_array.slurm"
EVALUATION_ARRAY_SLURM_PATH = IDEA_ROOT / "hpc" / "run_registered_evaluation_array.slurm"
PREPARE_EVALUATION_SCRIPT_PATH = IDEA_ROOT / "scripts" / "prepare_evaluation_run.py"
AGGREGATION_SCRIPT_PATH = IDEA_ROOT / "scripts" / "aggregate_registered_results.py"
AGGREGATION_SLURM_PATH = IDEA_ROOT / "hpc" / "run_registered_aggregation.slurm"
CLOSURE_VERIFIER_SCRIPT_PATH = IDEA_ROOT / "scripts" / "verify_registered_closure.py"
INDEPENDENT_EXPORT_VERIFIER_SCRIPT_PATH = IDEA_ROOT / "scripts" / "independent_verify_closure_export.py"
SERVER_PRECLOSURE_SCRIPT_PATH = IDEA_ROOT / "scripts" / "run_server_preclosure_check.py"
CLOSURE_GATE_SCRIPT_PATH = IDEA_ROOT / "scripts" / "evaluate_full_reproduction.py"
CLOSURE_GATE_SLURM_PATH = IDEA_ROOT / "hpc" / "run_registered_numerical_gate.slurm"
CLOSURE_MANIFEST_SLURM_PATH = IDEA_ROOT / "hpc" / "run_registered_closure_manifest.slurm"
CLOSURE_EXPORT_SLURM_PATH = IDEA_ROOT / "hpc" / "run_registered_closure_export.slurm"
PRECLOSURE_VALIDATION_SLURM_PATH = IDEA_ROOT / "hpc" / "run_preclosure_validation.slurm"
COMPARISON_REGISTER_PATH = (
    REPO_ROOT / "results" / "29_nearing2022_da_ar" / "formal_closure" / "reproduction_comparison_register.json"
)
FINAL_REPORT_PATH = REPO_ROOT / "results" / "29_nearing2022_da_ar" / "formal_closure" / "final_reproduction_report.md"
SOURCE_SCOPE_AUDIT_PATH = (
    REPO_ROOT / "results" / "29_nearing2022_da_ar" / "formal_closure" / "author_release_scope_audit.json"
)
AUTHOR_SOURCE_ARCHIVE_BINDING_PATH = (
    REPO_ROOT
    / "results"
    / "29_nearing2022_da_ar"
    / "formal_closure"
    / "author_source_archives"
    / "source_archive_binding.json"
)
RELEASED_PROTOCOL_PATH = IDEA_ROOT / "reference" / "released_protocol.json"


def _load_script(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _load_registry_module():
    return _load_script("nearing2022_registry", SCRIPT_PATH)


def test_reproduction_comparison_register_covers_all_four_evidence_layers():
    payload = json.loads(COMPARISON_REGISTER_PATH.read_text(encoding="utf-8"))

    assert payload["schema"] == "nearing2022-reproduction-comparison-register-v1"
    assert payload["overall_status"] == "HOLD"
    assert set(payload["layers"]) == {"data", "method", "model", "result"}
    assert {name: len(items) for name, items in payload["layers"].items()} == {
        "data": 8,
        "method": 13,
        "model": 10,
        "result": 11,
    }

    items = [item for layer in payload["layers"].values() for item in layer]
    ids = [item["id"] for item in items]
    assert len(ids) == len(set(ids)) == 42
    assert {item["status"] for item in items} == {
        "verified",
        "verified_with_boundary",
        "conflict",
        "pending",
        "not_auditable",
    }
    assert {"D05", "P09", "P10", "P12", "P13", "L04", "L08", "L09"} <= {
        item["id"] for item in items if item["status"] == "conflict"
    }
    assert {"P11", "R10", "R11"} <= {
        item["id"] for item in items if item["status"] == "not_auditable"
    }
    l08 = next(item for item in items if item["id"] == "L08")
    assert "Table F1 best drop factor 0.1" in l08["paper"]
    assert "early stop below 1e-5" in l08["released_code"]
    assert "early-stop threshold difference is definite" in l08["unknown"]

    required_fields = {
        "id",
        "comparison",
        "paper",
        "released_code",
        "current_reproduction",
        "evidence",
        "status",
        "unknown",
    }
    for item in items:
        assert required_fields <= set(item)
        assert item["evidence"], item["id"]
        for relative_path in item["evidence"]:
            assert (REPO_ROOT / relative_path).exists(), (item["id"], relative_path)


def test_author_release_scope_audit_records_unrecoverable_paper_components():
    payload = json.loads(SOURCE_SCOPE_AUDIT_PATH.read_text(encoding="utf-8"))

    assert payload["schema"] == "nearing2022-author-release-scope-audit-v1"
    experiment = payload["source_snapshots"]["released_experiment_code"]
    model = payload["source_snapshots"]["released_model_code"]
    assert experiment["commit"] == "b254529deb75d950f6417b67e51a7292b7aed430"
    assert experiment["tree"] == "1ab781e3a479abcde3a1f8d80fc72643141b69d3"
    assert experiment["tracked_file_count"] == 58
    assert experiment["zenodo"]["version"] == "v1.0"
    assert experiment["zenodo"]["archive_md5"] == "c2c449b68798637281038b53e7d20b82"
    assert experiment["zenodo"]["archive_sha256"] == (
        "5b6ac24a946d3516af6e1f8464ebceed99fd4ee09c6c8a8650a7716338dd7906"
    )
    assert experiment["zenodo"]["archive_file_entries"] == experiment["tracked_file_count"]
    assert experiment["zenodo"]["exact_tag_blob_match"] is True
    assert experiment["zenodo"]["content_mismatch_count"] == 0
    assert experiment["zenodo"]["missing_tag_blob_count"] == 0
    assert model["commit"] == "a3f8bfc0781af44bfee4ed3b4fdfae5ec5aa9a70"
    assert model["tree"] == "ba5a6a110ed1b0b93f9c1bb8b79d7fd35a99df76"
    assert model["tracked_file_count"] == 216
    assert model["zenodo"]["tag_commit"] == "a4c284b92934ee973c8b3fedf8a60df60c8feae1"
    assert model["zenodo"]["archive_sha256"] == (
        "91aefc74675aa83d0cc63695a48b69cec89f43605bb68c836424d839d212603d"
    )
    assert model["zenodo"]["archive_file_entries"] == 213
    assert model["zenodo"]["exact_tag_blob_match"] is True
    assert model["zenodo"]["content_mismatch_count"] == 0
    assert model["zenodo"]["missing_tag_blob_count"] == 0
    assert model["zenodo"]["assimilation_py_entries"] == 0
    assert model["zenodo"]["assimilation_commit_is_one_child_after_tag"] is True
    assert model["zenodo"]["files_added_or_modified_by_assimilation_commit"] == 19
    config_history = payload["released_configuration_history"]
    assert config_history["configuration_files_changed_after_first_public_commit"] is False
    assert config_history["hidden_size_values_across_simulation_autoregression_and_assimilation_configs"] == [256]
    assert config_history["p_seasonality_occurrences_across_all_13_public_commits"] == 0
    missed_peaks = payload["missed_peaks_metric_provenance"]
    assert missed_peaks["cited_model_code"]["missed_peaks_implementation_present"] is False
    assert missed_peaks["released_experiment_history"]["time_split_statistics_first_missed_peaks_commit"] == (
        "20af1fe0032e63c5ee97715592a8ae90d4032409"
    )
    assert missed_peaks["released_experiment_history"]["final_refresh_changed_time_statistics_pickle"] is False
    assert missed_peaks["public_neuralhydrology_implementation"]["commit"] == (
        "f28c69a1cc9d3da5210cb7818e01cb68e5587d81"
    )
    assert missed_peaks["public_neuralhydrology_implementation"]["matches_paper_appendix_e_defaults"] is True
    assert missed_peaks["public_neuralhydrology_implementation"]["parent_count"] == 1
    assert missed_peaks["public_neuralhydrology_implementation"]["squashed_commit"] is True
    assert missed_peaks["public_neuralhydrology_implementation"][
        "intermediate_feature_commits_available_in_public_ancestry"
    ] is False
    assert missed_peaks["status"] == "verified_with_boundary"

    coverage = {item["component"]: item for item in payload["published_output_coverage"]}
    assert coverage["basin-attribute attribution and spatial maps"]["status"] == "not_auditable"
    history = coverage["basin-attribute attribution and spatial maps"]["release_search"]["public_history"]
    assert history["commit_count"] == 13
    assert history["all_commit_trees_searched"] is True
    assert history["matching_implementation_or_output_paths"] == []
    assert coverage["computational runtime comparison"]["status"] == "not_auditable"
    runtime_history = coverage["computational runtime comparison"]["public_history_search"]
    assert runtime_history["commit_count"] == 13
    assert runtime_history["timing_log_job_environment_or_scheduler_paths"] == 0
    assert runtime_history["main_runtime_raw_record_found"] is False
    assert payload["hyperparameter_provenance"]["directory_generator_notebook"][
        "generated_coordinate_count"
    ] == 660
    assert payload["hyperparameter_provenance"]["paper"]["table_f1"]["histories"] == [1, 5, 20, 50]
    drop_wording = payload["hyperparameter_provenance"]["paper"]["drop_factor_wording"]
    assert drop_wording["table_f1_reported_best"] == 0.1
    assert drop_wording["released_config_value"] == 0.1
    assert drop_wording["status"] == "paper_internal_ambiguity_table_and_released_code_agree_on_0.1"
    assert payload["hyperparameter_provenance"]["directory_generator_notebook"]["histories"] == [1, 5, 20]
    monitor_grid = payload["hyperparameter_provenance"]["monitoring_script_hardcoded_index"]
    assert monitor_grid["cartesian_coordinate_count"] == 320
    assert monitor_grid["coordinates_excluded_by_window_times_history_above_300"] == 16
    assert monitor_grid["coordinate_count_after_generator_exclusion"] == 304
    assert monitor_grid["matches_notebook_saved_output_coordinate_count"] is True
    assert payload["hyperparameter_provenance"]["execution_period_path"]["command_line_default_period"] == "test"
    notebook_audit = payload["hyperparameter_provenance"]["released_notebook_executability"]
    assert notebook_audit["syntax_error_count"] == 1
    assert notebook_audit["syntax_error"]["file"] == "create_hypertuning_directories.ipynb"
    assert notebook_audit["saved_execution_mismatch"]["source_implied_coordinate_count"] == 660
    assert notebook_audit["saved_execution_mismatch"]["saved_output_coordinate_count"] == 304
    history_trace = notebook_audit["public_history_trace"]
    assert history_trace["first_public_source_implied_coordinate_count"] == 660
    assert history_trace["first_public_saved_output_coordinate_count"] == 304
    assert history_trace["last_python3_parseable_commit"] == "db370d91e16880a42c0efa6a776598bc64bb0251"
    assert history_trace["syntax_error_introduced_commit"] == "6be29c3cca7ef42ccc181f7d1394ca833c966baf"

    protocol = json.loads(RELEASED_PROTOCOL_PATH.read_text(encoding="utf-8"))["released_code_over_paper_text"]
    assert protocol["paper_assimilation_drop_factor_table_f1_best"] == 0.1
    assert protocol["assimilation_learning_rate_drop_factor"] == 0.1
    assert protocol["assimilation_early_stop_threshold"] == 0.00001

    inventory = payload["published_component_inventory"]
    assert inventory["counts"] == {
        "figures": 13,
        "tables": 4,
        "appendices": 8,
        "runtime_claim_groups": 1,
    }
    register = json.loads(COMPARISON_REGISTER_PATH.read_text(encoding="utf-8"))
    registered_ids = {item["id"] for layer in register["layers"].values() for item in layer}
    referenced_ids = set(inventory["runtime"])
    for group in ("figures", "tables", "appendices"):
        for ids in inventory[group].values():
            referenced_ids.update(ids)
    assert referenced_ids <= registered_ids


def test_current_audit_report_keeps_released_code_and_literal_paper_decisions_separate():
    report = FINAL_REPORT_PATH.read_text(encoding="utf-8")

    assert "**当前判定：HOLD。**" in report
    assert "作者发布的主数值实验矩阵能否复现" in report
    assert "论文文字方法能否原样复现" in report
    assert "整篇已发表研究能否从发布材料完整复现" in report
    assert "训练 `6/46`、评价 `6/180`、参数 `0/660`" in report
    assert "202293" in report
    assert "202294" in report
    assert "作业 `202293` 不得释放" in report
    assert "35 项旧登记表" in report
    assert "author_release_scope_audit.json" in report


@pytest.fixture()
def registry_module():
    return _load_registry_module()


@pytest.fixture()
def audit_module():
    return _load_script("nearing2022_artifact_audit", AUDIT_SCRIPT_PATH)


@pytest.fixture()
def scorer_module():
    return _load_script("nearing2022_independent_scorer", SCORER_SCRIPT_PATH)


@pytest.fixture()
def data_manifest_module():
    return _load_script("nearing2022_data_manifest", DATA_MANIFEST_SCRIPT_PATH)


@pytest.fixture()
def evaluation_registry_module():
    return _load_script("nearing2022_evaluation_registry", EVALUATION_REGISTRY_SCRIPT_PATH)


@pytest.fixture()
def prepare_evaluation_module():
    return _load_script("nearing2022_prepare_evaluation", PREPARE_EVALUATION_SCRIPT_PATH)


@pytest.fixture()
def aggregation_module():
    return _load_script("nearing2022_aggregation", AGGREGATION_SCRIPT_PATH)


@pytest.fixture()
def closure_verifier_module():
    return _load_script("nearing2022_closure_verifier", CLOSURE_VERIFIER_SCRIPT_PATH)


@pytest.fixture()
def independent_export_verifier_module():
    return _load_script("nearing2022_independent_export_verifier", INDEPENDENT_EXPORT_VERIFIER_SCRIPT_PATH)


@pytest.fixture()
def closure_gate_module():
    return _load_script("nearing2022_closure_gate", CLOSURE_GATE_SCRIPT_PATH)


def _read_ids(path: Path) -> list[str]:
    return [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def test_released_training_matrix_has_exactly_46_unique_rows(registry_module):
    registry = registry_module.build_registry(REPO_ROOT)

    assert len(registry) == 46
    assert registry["family"].value_counts().to_dict() == {
        "time_autoregression": 25,
        "basin_simulation": 10,
        "basin_autoregression": 10,
        "time_simulation": 1,
    }
    assert registry["exp_id"].is_unique
    assert registry["config_path"].is_unique
    assert set(registry["seed"]) == {"0"}
    assert set(registry["best_checkpoint"]) == {"model_epoch030"}


def test_time_split_coordinates_match_author_notebook(registry_module):
    registry = registry_module.build_registry(REPO_ROOT)
    autoregression = registry.loc[registry["family"] == "time_autoregression"]

    coordinates = {
        (int(row.lead), float(row.train_holdout), int(row.seed))
        for row in autoregression.itertuples(index=False)
    }
    expected = {
        (lead, holdout, 0)
        for lead in (1, 2, 4, 8, 10)
        for holdout in (0.0, 0.25, 0.5, 0.75, 1.0)
    }
    assert coordinates == expected


def test_basin_split_coordinates_match_author_notebook(registry_module):
    registry = registry_module.build_registry(REPO_ROOT)
    simulation = registry.loc[registry["family"] == "basin_simulation"]
    autoregression = registry.loc[registry["family"] == "basin_autoregression"]

    assert set(simulation["fold"].astype(int)) == set(range(10))
    assert set(autoregression["fold"].astype(int)) == set(range(10))
    assert set(autoregression["lead"].astype(int)) == {1}
    assert set(autoregression["train_holdout"].astype(float)) == {0.5}


def test_released_evaluation_matrix_has_exactly_180_coordinates(evaluation_registry_module):
    registry = evaluation_registry_module.build_evaluation_registry()

    assert len(registry) == 180
    assert registry["family"].value_counts().to_dict() == {
        "time_autoregression": 125,
        "time_assimilation": 25,
        "basin_simulation": 10,
        "basin_autoregression": 10,
        "basin_assimilation": 10,
    }
    assert registry["eval_id"].is_unique


def test_evaluation_sources_all_exist_in_training_registry(registry_module, evaluation_registry_module):
    training_ids = set(registry_module.build_registry(REPO_ROOT)["exp_id"])
    evaluations = evaluation_registry_module.build_evaluation_registry()

    assert set(evaluations["source_exp_id"]) <= training_ids
    assert set(evaluations["reference_exp_id"]) <= training_ids


def test_assimilation_hyperparameter_grid_has_exactly_660_frozen_rows(evaluation_registry_module):
    registry = evaluation_registry_module.build_hyperparameter_registry()

    assert len(registry) == 660
    assert registry["eval_id"].is_unique
    assert set(registry["grid_index"].astype(int)) == set(range(660))
    assert (registry["window"].astype(int) * registry["history"].astype(int) <= 300).all()
    selected = registry.loc[
        (registry["window"] == "5")
        & (registry["epochs"] == "100")
        & (registry["history"] == "20")
        & (registry["learning_rate"] == "0.1")
        & (registry["drop_factor"] == "0.1")
        & (registry["targets"] == "c_n")
    ]
    assert len(selected) == 1


def test_released_protocol_preserves_hyperparameter_period_discrepancy():
    protocol = json.loads((IDEA_ROOT / "reference" / "released_protocol.json").read_text(encoding="utf-8"))

    grid = protocol["assimilation_hyperparameter_grid"]
    assert grid["released_code_evaluation_period"] == "test"
    assert grid["paper_text_evaluation_period"] == "validation"


def test_evaluation_batches_cover_all_derived_coordinates(evaluation_registry_module):
    evaluations = evaluation_registry_module.build_evaluation_registry()
    hyperparameters = evaluation_registry_module.build_hyperparameter_registry()
    batches = evaluation_registry_module.build_batches(evaluations, hyperparameters)

    assert len(batches["time_split_evaluation_batch.txt"]) == 150
    assert len(batches["time_split_existing_source_evaluation_batch.txt"]) == 30
    assert len(batches["time_split_pending_source_evaluation_batch.txt"]) == 120
    assert len(batches["basin_direct_evaluation_batch.txt"]) == 20
    assert len(batches["basin_assimilation_evaluation_batch.txt"]) == 10
    assert len(batches["hyperparameter_evaluation_batch.txt"]) == 660
    assert set(batches["time_split_evaluation_batch.txt"]) == set(
        evaluations.loc[evaluations["family"].str.startswith("time_"), "eval_id"]
    )
    assert not set(batches["time_split_existing_source_evaluation_batch.txt"]) & set(
        batches["time_split_pending_source_evaluation_batch.txt"]
    )
    assert set(batches["basin_direct_evaluation_batch.txt"]) == set(
        evaluations.loc[evaluations["family"].isin({"basin_simulation", "basin_autoregression"}), "eval_id"]
    )
    producing_batches = (
        batches["time_split_existing_source_evaluation_batch.txt"],
        batches["time_split_pending_source_evaluation_batch.txt"],
        batches["basin_direct_evaluation_batch.txt"],
        batches["basin_assimilation_evaluation_batch.txt"],
    )
    assigned = [identifier for batch in producing_batches for identifier in batch]
    assert len(assigned) == 180
    assert len(set(assigned)) == 180
    assert set(assigned) == set(evaluations["eval_id"])


def test_evaluation_array_registration_preserves_completed_coordinates(evaluation_registry_module):
    registry = evaluation_registry_module.build_evaluation_registry()
    hyperparameters = evaluation_registry_module.build_hyperparameter_registry()
    batches = evaluation_registry_module.build_batches(registry, hyperparameters)
    identifiers = batches["time_split_existing_source_evaluation_batch.txt"]

    updated = evaluation_registry_module.register_array_submission(
        registry,
        identifiers,
        array_job_id="202222",
        submitted_at="2026-08-10T12:44:38+08:00",
    )

    completed = updated.loc[updated["status"] == "completed_unverified"]
    submitted = updated.loc[updated["slurm_job_id"].str.startswith("202222_")]
    assert len(completed) == 2
    assert len(submitted) == 28
    assert set(submitted["status"]) == {"submitted"}


def test_author_pub_folds_partition_all_531_basins_once_as_test():
    all_basins = set(_read_ids(IDEA_ROOT / "basin_lists" / "531_basin_list.txt"))
    test_counts: Counter[str] = Counter()

    for fold in range(10):
        train = set(_read_ids(IDEA_ROOT / "basin_lists" / "author_pub" / f"train_kfold_{fold}_seed_0.txt"))
        test = set(_read_ids(IDEA_ROOT / "basin_lists" / "author_pub" / f"test_kfold_{fold}_seed_0.txt"))
        assert not train & test
        assert train | test == all_basins
        assert len(train) + len(test) == 531
        test_counts.update(test)

    assert set(test_counts) == all_basins
    assert set(test_counts.values()) == {1}


def test_generated_configs_freeze_released_protocol(registry_module, tmp_path):
    registry = registry_module.build_registry(REPO_ROOT)
    generated = registry_module.write_frozen_configs(REPO_ROOT, tmp_path, registry)

    assert len(generated) == 46
    assert len(set(generated)) == 46

    time_ar = yaml.safe_load((tmp_path / "time_split" / "autoregression" / "lead_4_holdout_0.25_seed_0.yml").read_text())
    assert time_ar["epochs"] == 30
    assert time_ar["hidden_size"] == 256
    assert time_ar["forcings"] == ["maurer_extended", "nldas_extended", "daymet"]
    assert time_ar["lagged_features"]["QObs(mm/d)"] == [4]
    assert time_ar["autoregressive_inputs"] == ["QObs(mm/d)_shift4"]
    assert time_ar["random_holdout_from_dynamic_features"]["QObs(mm/d)_shift4"] == {
        "missing_fraction": 0.25,
        "mean_missing_length": 5,
    }

    basin_ar = yaml.safe_load((tmp_path / "basin_split" / "autoregression" / "fold_3_holdout_0.5_seed_0.yml").read_text())
    assert basin_ar["lagged_features"]["QObs(mm/d)"] == [1]
    assert basin_ar["autoregressive_inputs"] == ["QObs(mm/d)_shift1"]
    assert basin_ar["train_basin_file"].endswith("train_kfold_3_seed_0.txt")
    assert basin_ar["validation_basin_file"].endswith("test_kfold_3_seed_0.txt")
    assert basin_ar["test_basin_file"].endswith("test_kfold_3_seed_0.txt")


def test_registry_round_trip_is_stable(registry_module, tmp_path):
    first = registry_module.build_registry(REPO_ROOT)
    output = tmp_path / "experiment_registry.csv"
    registry_module.write_registry(first, output)
    second = pd.read_csv(output, keep_default_na=False, dtype=str)

    pd.testing.assert_frame_equal(first.reset_index(drop=True), second, check_dtype=False)


def test_execution_update_changes_only_mutable_fields(registry_module):
    registry = registry_module.build_registry(REPO_ROOT)
    updated = registry_module.update_execution(
        registry,
        "N22-TS-AR-L01-H050-S0",
        status="submitted",
        slurm_job_id="202214",
        submitted_at="2026-08-10T11:59:09+08:00",
    )

    row = updated.loc[updated["exp_id"] == "N22-TS-AR-L01-H050-S0"].iloc[0]
    assert row["status"] == "submitted"
    assert row["slurm_job_id"] == "202214"
    assert row["submitted_at"] == "2026-08-10T11:59:09+08:00"
    with pytest.raises(KeyError, match="immutable"):
        registry_module.update_execution(updated, "N22-TS-AR-L01-H050-S0", lead="2")


def test_array_submission_maps_batch_order_to_unique_slurm_tasks(registry_module):
    registry = registry_module.build_registry(REPO_ROOT)
    config_paths = list(registry.loc[registry["status"] == "planned", "config_path"].iloc[:3])

    updated = registry_module.register_array_submission(
        registry,
        config_paths,
        array_job_id="202215",
        submitted_at="2026-08-10T12:37:59+08:00",
    )

    rows = updated.loc[updated["config_path"].isin(config_paths)].set_index("config_path")
    assert list(rows.loc[config_paths, "slurm_job_id"]) == ["202215_0", "202215_1", "202215_2"]
    assert set(rows["status"]) == {"submitted"}
    with pytest.raises(ValueError, match="duplicate"):
        registry_module.register_array_submission(registry, [config_paths[0], config_paths[0]], "1", "now")


def test_artifact_audit_rejects_summary_without_raw_results(audit_module, tmp_path):
    (tmp_path / "headline_table.csv").write_text("NSE,0.792\n", encoding="utf-8")

    report = audit_module.audit_run(tmp_path, epoch=30, assimilation=False)

    assert report.status == "partially_reproducible"
    assert "test_results" in report.missing_roles
    assert "checkpoint_epoch030" in report.missing_roles


def test_artifact_manifest_detects_mutation(audit_module, tmp_path):
    artifact = tmp_path / "test_results.p"
    artifact.write_bytes(b"original")
    manifest_path = tmp_path / "manifest.json"
    audit_module.write_manifest([artifact], tmp_path, manifest_path)

    assert audit_module.verify_manifest(manifest_path).ok

    artifact.write_bytes(b"mutated")
    verification = audit_module.verify_manifest(manifest_path)
    assert not verification.ok
    assert verification.hash_mismatches == ("test_results.p",)


def test_data_manifest_hashes_every_required_file(data_manifest_module, tmp_path):
    data_root = tmp_path / "camels_us"
    basin_file = tmp_path / "basins.txt"
    basin_ids = ("01013500", "02014000")
    basin_file.write_text("\n".join(basin_ids) + "\n", encoding="utf-8")

    attribute_root = data_root / "camels_attributes_v2.0"
    attribute_root.mkdir(parents=True)
    for filename in data_manifest_module.ATTRIBUTE_FILES:
        (attribute_root / filename).write_text(filename, encoding="utf-8")
    (attribute_root / "camels_name.txt").write_text(
        "gauge_id;huc_02;gauge_name\n01013500;01;one\n02014000;03;two\n", encoding="utf-8"
    )

    for _, _, path in data_manifest_module.expected_files(data_root, basin_ids):
        if not path.is_file():
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(path.as_posix(), encoding="utf-8")

    manifest = data_manifest_module.build_manifest(data_root, basin_file, expected_basins=2)

    assert manifest["basin_count"] == 2
    assert manifest["file_count"] == 15
    assert {entry["role"] for entry in manifest["files"]} == {
        "forcing:daymet",
        "forcing:maurer_extended",
        "forcing:nldas_extended",
        "streamflow",
        "static_attributes",
    }
    assert (data_root / "usgs_streamflow" / "03" / "02014000_streamflow_qc.txt").is_file()
    first_digest = manifest["dataset_sha256"]
    mutated = data_root / "usgs_streamflow" / "01" / "01013500_streamflow_qc.txt"
    mutated.write_text("mutated", encoding="utf-8")
    assert data_manifest_module.build_manifest(data_root, basin_file)["dataset_sha256"] != first_digest


def test_local_and_hpc_execution_data_manifests_are_equivalent(closure_verifier_module, tmp_path):
    provenance = COMPARISON_REGISTER_PATH.parent / "provenance"
    local_manifest = provenance / "local_camels_us_manifest_v2.json"
    hpc_manifest = provenance / "hpc_camels_us_manifest_v2.json"

    verified = closure_verifier_module.verify_data_manifest_equivalence(
        local_manifest, hpc_manifest, hpc_manifest
    )

    assert verified["ok"]
    assert verified["basin_count"] == 531
    assert verified["file_count"] == 2131
    assert verified["total_bytes"] == 1313175181
    assert verified["dataset_sha256"] == (
        "a3cb1f81e6b2f25e2b919c0d5b315e46fe82f8ed9c9d8a4bd56671da5500a35f"
    )

    mutated = json.loads(hpc_manifest.read_text(encoding="utf-8"))
    mutated["files"][0]["sha256"] = "0" * 64
    mutated_path = tmp_path / "mutated_hpc_manifest.json"
    mutated_path.write_text(json.dumps(mutated), encoding="utf-8")
    with pytest.raises(ValueError, match="aggregate digest is inconsistent"):
        closure_verifier_module.verify_data_manifest_equivalence(
            local_manifest, mutated_path, hpc_manifest
        )


def test_official_author_source_archives_are_bound_and_offline_verifiable(closure_verifier_module):
    verifier_source = CLOSURE_VERIFIER_SCRIPT_PATH.read_text(encoding="utf-8")
    assert '["git", "-C"' not in verifier_source

    verified = closure_verifier_module.verify_author_source_archives(
        REPO_ROOT, AUTHOR_SOURCE_ARCHIVE_BINDING_PATH
    )

    assert verified["ok"]
    assert set(verified["archives"]) == {
        "experiment_zenodo_v1_0",
        "model_zenodo_v1_3_0",
        "model_assimilation_git_bundle",
    }
    assert verified["archives"]["experiment_zenodo_v1_0"]["file_entries"] == 58
    assert verified["archives"]["model_zenodo_v1_3_0"]["file_entries"] == 213
    assimilation = verified["archives"]["model_assimilation_git_bundle"]
    assert assimilation["commit"] == "a3f8bfc0781af44bfee4ed3b4fdfae5ec5aa9a70"
    assert assimilation["tree"] == "ba5a6a110ed1b0b93f9c1bb8b79d7fd35a99df76"
    assert assimilation["tracked_file_count"] == 216
    assert assimilation["complete_history_verified_in_empty_repository"]


def _metric_fixture() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    dates = pd.date_range("2000-01-01", periods=500, freq="D").values
    x = np.arange(500, dtype=float)
    obs = 2.0 + 0.4 * np.sin(x / 11.0) + 0.2 * np.cos(x / 23.0)
    for idx, magnitude in ((80, 5.0), (210, 7.0), (360, 6.0), (470, 8.0)):
        obs[idx] += magnitude
    sim = np.roll(obs, 1) * 0.95 + 0.08
    sim[0] = obs[0]
    return dates, obs, sim


def test_independent_metrics_match_neuralhydrology_definitions(scorer_module):
    dates, obs, sim = _metric_fixture()
    obs_xr = xr.DataArray(obs, coords={"date": dates}, dims=["date"])
    sim_xr = xr.DataArray(sim, coords={"date": dates}, dims=["date"])
    expected = nh_metrics.calculate_metrics(
        obs_xr,
        sim_xr,
        metrics=["NSE", "KGE", "Alpha-NSE", "Pearson-r", "Beta-NSE", "Peak-Timing", "Missed-Peaks"],
    )

    actual = scorer_module.independent_metrics(dates, obs, sim)

    assert actual.keys() == expected.keys()
    for metric, expected_value in expected.items():
        assert actual[metric] == pytest.approx(expected_value, abs=1e-12, nan_ok=True)


def test_score_result_pickles_uses_complete_simulation_observations(scorer_module, tmp_path):
    dates, obs, sim = _metric_fixture()
    candidate = sim + 0.1
    simulation_path = tmp_path / "simulation.p"
    candidate_path = tmp_path / "candidate.p"

    def _payload(sim_values: np.ndarray, obs_values: np.ndarray) -> dict:
        dataset = xr.Dataset(
            {
                "QObs(mm/d)_obs": (("date", "time_step"), obs_values[:, None]),
                "QObs(mm/d)_sim": (("date", "time_step"), sim_values[:, None]),
            },
            coords={"date": dates, "time_step": [0]},
        )
        return {"01013500": {"1D": {"xr": dataset}}}

    with simulation_path.open("wb") as fp:
        pickle.dump(_payload(sim, obs), fp)
    candidate_obs_with_holes = obs.copy()
    candidate_obs_with_holes[::4] = np.nan
    with candidate_path.open("wb") as fp:
        pickle.dump(_payload(candidate, candidate_obs_with_holes), fp)

    scored = scorer_module.score_result_pickles(simulation_path, candidate_path)

    assert list(scored["basin"]) == ["01013500"]
    assert int(scored.loc[0, "n_common"]) == 500
    expected = scorer_module.independent_metrics(dates, obs, candidate)
    assert scored.loc[0, "NSE"] == pytest.approx(expected["NSE"])


def test_registered_training_slurm_is_fail_closed_and_isolated():
    script = TRAINING_SLURM_PATH.read_text(encoding="utf-8")

    assert "set -eo pipefail" in script
    assert "CONFIG_REL:?" in script
    assert "closure_20260810/logs" in script
    assert "--exclude=ngu002" in script
    assert "python -m neuralhydrology.nh_run train" in script
    assert "--mem" not in script


def test_training_batches_cover_every_remaining_released_training_config(registry_module):
    registry = registry_module.build_registry(REPO_ROOT)
    expected = set(registry.loc[registry["status"] == "planned", "config_path"])
    time_batch = set(_read_ids(IDEA_ROOT / "registry" / "time_split_remaining_training_batch.txt"))
    basin_batch = set(_read_ids(IDEA_ROOT / "registry" / "basin_split_training_batch.txt"))
    headline = {
        "src/29_nearing2022_da_ar/configs/full_reproduction/time_split/autoregression/"
        "lead_1_holdout_0.5_seed_0.yml"
    }

    assert not time_batch & basin_batch
    assert len(time_batch) == 23
    assert len(basin_batch) == 20
    assert time_batch | basin_batch | headline == expected


def test_registered_training_array_is_fail_closed_and_duplicate_safe():
    script = TRAINING_ARRAY_SLURM_PATH.read_text(encoding="utf-8")

    assert "set -eo pipefail" in script
    assert "BATCH_FILE_REL:?" in script
    assert "SLURM_ARRAY_TASK_ID:?" in script
    assert "SKIPPED_COMPLETED" in script
    assert "model_epoch030.pt" in script
    assert "python -m neuralhydrology.nh_run train" in script
    assert "--mem" not in script


def test_prepare_evaluation_changes_test_holdout_without_touching_source(prepare_evaluation_module, tmp_path):
    source = tmp_path / "source_run"
    (source / "train_data").mkdir(parents=True)
    (source / "model_epoch030.pt").write_bytes(b"checkpoint")
    (source / "train_data" / "train_data_scaler.yml").write_text("x: 1\n", encoding="utf-8")
    source_config = {
        "experiment_name": "source",
        "run_dir": str(tmp_path),
        "random_holdout_from_dynamic_features": {
            "QObs(mm/d)_shift1": {
                "missing_fraction": 0.5,
                "mean_missing_length": 5,
            }
        },
    }
    (source / "config.yml").write_text(yaml.safe_dump(source_config), encoding="utf-8")
    training_path = tmp_path / "training.csv"
    pd.DataFrame([
        {
            "exp_id": "SOURCE",
            "run_dir": str(source),
            "config_path": "unused.yml",
        }
    ]).to_csv(training_path, index=False)
    target = tmp_path / "target"
    evaluation_path = tmp_path / "evaluation.csv"
    pd.DataFrame([
        {
            "eval_id": "EVAL",
            "family": "time_autoregression",
            "evaluation_mode": "autoregression",
            "source_exp_id": "SOURCE",
            "test_holdout": "0.0",
            "run_dir": str(target),
            "result_file": "test/model_epoch030/test_results.p",
        }
    ]).to_csv(evaluation_path, index=False)

    prepared = prepare_evaluation_module.prepare_run(tmp_path, training_path, evaluation_path, "EVAL")

    assert prepared.status == "prepared"
    prepared_config = yaml.safe_load((target / "config.yml").read_text(encoding="utf-8"))
    assert prepared_config["random_holdout_from_dynamic_features"]["QObs(mm/d)_shift1"]["missing_fraction"] == 0.0
    original_config = yaml.safe_load((source / "config.yml").read_text(encoding="utf-8"))
    assert original_config["random_holdout_from_dynamic_features"]["QObs(mm/d)_shift1"]["missing_fraction"] == 0.5
    with pytest.raises(FileExistsError, match="incomplete"):
        prepare_evaluation_module.prepare_run(tmp_path, training_path, evaluation_path, "EVAL")


def test_prepare_direct_basin_evaluation_reuses_frozen_source(prepare_evaluation_module, tmp_path):
    source = tmp_path / "source_run"
    (source / "train_data").mkdir(parents=True)
    (source / "model_epoch030.pt").write_bytes(b"checkpoint")
    (source / "train_data" / "train_data_scaler.yml").write_text("x: 1\n", encoding="utf-8")
    (source / "config.yml").write_text("experiment_name: source\n", encoding="utf-8")
    training_path = tmp_path / "training.csv"
    pd.DataFrame([{
        "exp_id": "SOURCE",
        "run_dir": str(source),
        "config_path": "unused.yml",
    }]).to_csv(training_path, index=False)
    evaluation_path = tmp_path / "evaluation.csv"
    pd.DataFrame([{
        "eval_id": "DIRECT",
        "family": "basin_simulation",
        "evaluation_mode": "simulation",
        "source_exp_id": "SOURCE",
        "test_holdout": "0.0",
        "run_dir": str(tmp_path / "must_not_be_created"),
        "result_file": "test/model_epoch030/test_results.p",
    }]).to_csv(evaluation_path, index=False)

    prepared = prepare_evaluation_module.prepare_run(tmp_path, training_path, evaluation_path, "DIRECT")

    assert prepared.run_dir == source.resolve()
    assert prepared.status == "prepared"
    assert not prepared.data_assimilation
    assert not (tmp_path / "must_not_be_created").exists()
    result = source / "test" / "model_epoch030" / "test_results.p"
    result.parent.mkdir(parents=True)
    result.write_bytes(b"results")
    completed = prepare_evaluation_module.prepare_run(tmp_path, training_path, evaluation_path, "DIRECT")
    assert completed.status == "completed"


def test_registered_evaluation_array_is_fail_closed_and_isolated():
    script = EVALUATION_ARRAY_SLURM_PATH.read_text(encoding="utf-8")

    assert "set -eo pipefail" in script
    assert "REGISTRY_KIND:?" in script
    assert "SLURM_ARRAY_TASK_ID:?" in script
    assert "prepare_evaluation_run.py" in script
    assert "SKIPPED_COMPLETED" in script
    assert "python -m neuralhydrology.nh_run evaluate" in script
    assert "--data-assimilation" in script
    assert "--mem" not in script


def test_author_statistics_pickle_is_loadable_and_matches_headline(aggregation_module):
    simulation, autoregression, assimilation = aggregation_module.load_legacy_pandas_pickle(
        IDEA_ROOT / "reference" / "author_time_split_statistics.pkl"
    )

    assert simulation["NSE"].shape == (531, 1)
    assert autoregression["NSE"].shape == (531, 125)
    assert assimilation["NSE"].shape == (531, 25)
    assert float(simulation["NSE"].median().iloc[0]) == pytest.approx(0.796, abs=0.0005)
    assert float(autoregression["NSE"][(0.0, 0.0, 1, 0)].median()) == pytest.approx(0.879, abs=0.0005)
    assert float(assimilation["NSE"][(0.0, 1, 0)].median()) == pytest.approx(0.862, abs=0.0005)


def test_registered_aggregation_is_fail_closed_and_runs_under_slurm():
    script = AGGREGATION_SLURM_PATH.read_text(encoding="utf-8")

    assert "set -eo pipefail" in script
    assert "AGGREGATION_KIND:?" in script
    assert "aggregate_registered_results.py" in script
    assert "python \"$SCRIPT\" evaluations" in script
    assert "python \"$SCRIPT\" hyperparameters" in script
    assert "--mem" not in script


def test_registered_closure_verifier_requires_every_bound_artifact(closure_verifier_module, tmp_path):
    root = tmp_path.resolve()
    training_run = root / "training_run"
    (training_run / "train_data").mkdir(parents=True)
    (training_run / "test" / "model_epoch030").mkdir(parents=True)
    (training_run / "config.yml").write_text("experiment_name: training\n", encoding="utf-8")
    (training_run / "model_epoch030.pt").write_bytes(b"checkpoint")
    (training_run / "output.log").write_text("complete\n", encoding="utf-8")
    (training_run / "train_data" / "train_data_scaler.yml").write_text("x: 1\n", encoding="utf-8")
    (training_run / "test" / "model_epoch030" / "test_results.p").write_bytes(b"prediction")
    (training_run / "test" / "model_epoch030" / "test_metrics.csv").write_text("NSE\n0.5\n", encoding="utf-8")

    hyper_run = root / "hyper_run"
    (hyper_run / "test" / "model_epoch030").mkdir(parents=True)
    (hyper_run / "config.yml").write_text("experiment_name: hyper\n", encoding="utf-8")
    (hyper_run / "model_epoch030.pt").write_bytes(b"checkpoint")
    hyper_log = hyper_run / "output.log"
    hyper_log.write_text("complete\n", encoding="utf-8")
    (hyper_run / "test" / "model_epoch030" / "test_results_data_assimilation.p").write_bytes(b"prediction")
    hyper_metrics = hyper_run / "test" / "model_epoch030" / "test_metrics_data_assimilation.csv"
    hyper_metrics.write_text("NSE\n0.6\n", encoding="utf-8")

    training_path = root / "training.csv"
    pd.DataFrame([{
        "exp_id": "TRAIN",
        "family": "basin_simulation",
        "run_dir": str(training_run),
        "config_path": "unused.yml",
    }]).to_csv(training_path, index=False)
    evaluation_path = root / "evaluation.csv"
    pd.DataFrame([{
        "eval_id": "EVAL",
        "family": "basin_simulation",
        "source_exp_id": "TRAIN",
        "reference_exp_id": "TRAIN",
        "run_dir": "unused",
        "result_file": "test/model_epoch030/test_results.p",
    }]).to_csv(evaluation_path, index=False)
    hyper_path = root / "hyper.csv"
    pd.DataFrame([{
        "eval_id": "HYPER",
        "source_exp_id": "TRAIN",
        "run_dir": str(hyper_run),
        "result_file": "test/model_epoch030/test_results_data_assimilation.p",
    }]).to_csv(hyper_path, index=False)

    evaluation_aggregation = root / "aggregation" / "evaluations"
    hyper_aggregation = root / "aggregation" / "hyperparameters"
    evaluation_aggregation.mkdir(parents=True)
    hyper_aggregation.mkdir(parents=True)
    for name in closure_verifier_module.EVALUATION_AGGREGATION_FILES:
        (evaluation_aggregation / name).write_text("ok\n", encoding="utf-8")
    for name in closure_verifier_module.HYPERPARAMETER_AGGREGATION_FILES:
        (hyper_aggregation / name).write_text("ok\n", encoding="utf-8")
    comparison_evidence_file = root / "comparison_evidence.txt"
    comparison_evidence_file.write_text("direct evidence\n", encoding="utf-8")

    audit = closure_verifier_module.audit_registered_closure(
        root,
        training_path,
        evaluation_path,
        hyper_path,
        evaluation_aggregation,
        hyper_aggregation,
        expected_training=1,
        expected_evaluations=1,
        expected_hyperparameters=1,
        comparison_evidence=[(comparison_evidence_file, "D01", "comparison_evidence.txt")],
    )
    assert audit["complete"]
    assert audit["counts"] == {"training": 1, "evaluations": 1, "hyperparameters": 1}
    bindings = [binding for artifact in audit["artifacts"] for binding in artifact["bindings"]]
    assert {
        "coordinate_type": "evaluation",
        "coordinate_id": "EVAL",
        "role": "reference_prediction",
    } in bindings
    assert {
        "coordinate_type": "evaluation",
        "coordinate_id": "EVAL",
        "role": "reference_metrics",
    } in bindings
    assert {
        "coordinate_type": "hyperparameter",
        "coordinate_id": "HYPER",
        "role": "reference_prediction",
    } in bindings
    assert {
        "coordinate_type": "hyperparameter",
        "coordinate_id": "HYPER",
        "role": "reference_metrics",
    } in bindings
    assert {
        "coordinate_type": "comparison_evidence",
        "coordinate_id": "D01",
        "role": "evidence:comparison_evidence.txt",
    } in bindings
    manifest_path = root / "manifest.json"
    manifest = closure_verifier_module.write_closure_manifest(audit, root, manifest_path)
    assert manifest["file_count"] == len({entry["path"] for entry in manifest["files"]})
    assert closure_verifier_module.verify_closure_manifest(manifest_path)["ok"]
    with pytest.raises(FileExistsError, match="Refusing to overwrite"):
        closure_verifier_module.write_closure_manifest(audit, root, manifest_path)

    hyper_log.unlink()
    missing_log = closure_verifier_module.audit_registered_closure(
        root,
        training_path,
        evaluation_path,
        hyper_path,
        evaluation_aggregation,
        hyper_aggregation,
        expected_training=1,
        expected_evaluations=1,
        expected_hyperparameters=1,
    )
    assert not missing_log["complete"]
    assert any(
        item["coordinate_id"] == "HYPER" and item["role"] == "evaluation_log" for item in missing_log["missing"]
    )
    hyper_log.write_text("complete\n", encoding="utf-8")
    hyper_metrics.unlink()
    incomplete = closure_verifier_module.audit_registered_closure(
        root,
        training_path,
        evaluation_path,
        hyper_path,
        evaluation_aggregation,
        hyper_aggregation,
        expected_training=1,
        expected_evaluations=1,
        expected_hyperparameters=1,
    )
    assert not incomplete["complete"]
    assert any(item["coordinate_id"] == "HYPER" and item["role"] == "metrics" for item in incomplete["missing"])


def test_closure_source_tree_excludes_generated_python_caches(closure_verifier_module, tmp_path):
    source = tmp_path / "source"
    cache = source / "__pycache__"
    cache.mkdir(parents=True)
    kept = source / "protocol.json"
    kept.write_text("{}\n", encoding="utf-8")
    (cache / "module.pyc").write_bytes(b"cache")

    assert closure_verifier_module.extra_tree_files(source) == (kept.resolve(),)


def test_comparison_register_evidence_is_resolved_and_bound(closure_verifier_module, tmp_path):
    root = tmp_path / "repo"
    evidence_root = root / "evidence"
    tree = evidence_root / "tree"
    cache = tree / "__pycache__"
    cache.mkdir(parents=True)
    direct = evidence_root / "direct.json"
    nested = tree / "nested.txt"
    direct.write_text("{}\n", encoding="utf-8")
    nested.write_text("evidence\n", encoding="utf-8")
    (cache / "ignored.pyc").write_bytes(b"cache")
    register_path = root / "register.json"
    register_path.write_text(json.dumps({
        "layers": {
            "data": [{
                "id": "D01",
                "evidence": ["evidence/direct.json", "evidence/tree"],
            }],
        },
    }), encoding="utf-8")

    resolved = closure_verifier_module.comparison_evidence_artifacts(root, register_path)

    assert {row[0] for row in resolved} == {direct.resolve(), nested.resolve()}
    assert {row[1] for row in resolved} == {"D01"}
    assert {row[2] for row in resolved} == {"evidence/direct.json", "evidence/tree"}

    register_path.write_text(json.dumps({
        "layers": {"data": [{"id": "D01", "evidence": ["../outside.txt"]}]},
    }), encoding="utf-8")
    with pytest.raises(ValueError, match="Unsafe or non-canonical"):
        closure_verifier_module.comparison_evidence_artifacts(root, register_path)

    register_path.write_text(json.dumps({
        "layers": {"data": [{"id": "D01", "evidence": ["evidence/missing.txt"]}]},
    }), encoding="utf-8")
    with pytest.raises(FileNotFoundError, match="does not exist"):
        closure_verifier_module.comparison_evidence_artifacts(root, register_path)


def test_headline_recovery_binding_matches_frozen_registered_coordinates(closure_verifier_module, tmp_path):
    root = tmp_path / "repo"
    runs = {}
    for name in closure_verifier_module.HEADLINE_RECOVERY_COORDINATES:
        run = root / name
        run.mkdir(parents=True)
        artifact = run / "model_epoch030.pt"
        artifact.write_bytes(f"{name} artifact".encode("utf-8"))
        runs[name] = run

    training_path = root / "training.csv"
    pd.DataFrame([
        {
            "exp_id": "N22-TS-SIM-S0",
            "run_dir": str(runs["simulation"]),
            "config_path": "unused.yml",
        },
        {
            "exp_id": "N22-TS-AR-L01-H000-S0",
            "run_dir": str(runs["autoregression"]),
            "config_path": "unused.yml",
        },
    ]).to_csv(training_path, index=False)
    evaluation_path = root / "evaluation.csv"
    pd.DataFrame([{
        "eval_id": "N22-EVAL-TS-DA-L01-TE000-S0",
        "family": "time_assimilation",
        "run_dir": str(runs["assimilation"]),
        "source_exp_id": "N22-TS-SIM-S0",
    }]).to_csv(evaluation_path, index=False)

    conditions = []
    for name, (kind, identifier) in closure_verifier_module.HEADLINE_RECOVERY_COORDINATES.items():
        artifact = runs[name] / "model_epoch030.pt"
        conditions.append({
            "condition": name,
            "registry_kind": kind,
            "registry_id": identifier,
            "file_count": 1,
            "total_bytes": artifact.stat().st_size,
            "files": [{
                "path": "model_epoch030.pt",
                "bytes": artifact.stat().st_size,
                "sha256": hashlib.sha256(artifact.read_bytes()).hexdigest(),
            }],
        })
    binding_path = root / "headline_binding.json"
    binding_path.write_text(json.dumps({
        "schema": "nearing2022-headline-artifact-recovery-binding-v1",
        "conditions": conditions,
    }), encoding="utf-8")

    verified = closure_verifier_module.verify_headline_artifact_recovery(
        root, training_path, evaluation_path, binding_path
    )

    assert verified["ok"]
    assert verified["file_count"] == 3
    assert set(verified["conditions"]) == {"simulation", "autoregression", "assimilation"}

    (runs["assimilation"] / "model_epoch030.pt").write_bytes(b"mutated")
    with pytest.raises(ValueError, match="size changed|hash changed"):
        closure_verifier_module.verify_headline_artifact_recovery(
            root, training_path, evaluation_path, binding_path
        )


def test_registered_closure_manifest_job_is_fail_closed_and_cpu_only(closure_verifier_module):
    assert "time_simulation_per_basin_metrics.csv" in closure_verifier_module.EVALUATION_AGGREGATION_FILES

    script = CLOSURE_MANIFEST_SLURM_PATH.read_text(encoding="utf-8")

    assert "set -eo pipefail" in script
    assert 'python "$GATE_SCRIPT"' not in script
    assert "final_reproduction_gate.json" in script
    assert "final_reproduction_differences.csv" in script
    assert "N22-gate_202315.out" in script
    assert "N22-gate_202315.err" in script
    assert "evaluate_full_reproduction_pre_immutability_patch_f6548d2c.py" in script
    assert "numerical_gate_source_update_receipt.json" in script
    assert "evaluate_full_reproduction_pre_input_binding_820ce3cb.py" in script
    assert "numerical_gate_input_binding_receipt.json" in script
    assert "evaluate_full_reproduction_pre_exact_input_bytes_784e5b8d.py" in script
    assert "numerical_gate_exact_input_bytes_receipt.json" in script
    assert "execution_environment.json" in script
    assert "pip_freeze.txt" in script
    assert "reproduction_comparison_register.json" in script
    assert "author_release_scope_audit.json" in script
    assert "final_reproduction_report.md" in script
    assert "headline_artifact_recovery_binding.json" in script
    assert "source_archive_binding.json" in script
    assert "local_camels_us_manifest_v2.json" in script
    assert "hpc_camels_us_manifest_v2.json" in script
    assert '--extra-tree "$ROOT/neuralhydrology"' in script
    assert '--extra-tree "$PROVENANCE"' in script
    assert "#SBATCH --nodelist=ngu003" in script
    assert "verify_registered_closure.py" in script
    assert "--manifest-output" in script
    assert "OUTPUT_CHECKSUM" in script
    assert 'sha256sum "$OUTPUT" > "$CHECKSUM_TEMPORARY"' in script
    assert "--comparison-register" in script
    assert "--source-scope-audit" in script
    assert "--audit-report" in script
    assert "--gate-output" in script
    assert "--gate-details" in script
    assert "--gate-log" in script
    assert "--headline-artifact-binding" in script
    assert "--author-source-archive-binding" in script
    assert "--local-data-manifest" in script
    assert "--hpc-data-manifest" in script
    assert "--execution-data-manifest" in script
    assert 'test ! -e "$OUTPUT"' in script
    assert "--extra-file" in script
    assert "--extra-tree" in script
    assert "run_server_preclosure_check.py" in script
    assert "python -m pytest" not in script
    assert "--gres=gpu" not in script
    assert "--mem" not in script


def test_closure_manifest_always_includes_its_decision_and_provenance_inputs():
    source = CLOSURE_VERIFIER_SCRIPT_PATH.read_text(encoding="utf-8")
    start = source.index("extra_files = [")
    end = source.index("    ]", start)
    required_block = source[start:end]

    for argument in (
        "args.comparison_register",
        "args.source_scope_audit",
        "args.audit_report",
        "args.gate_output",
        "args.gate_details",
        "args.gate_log",
        "args.headline_artifact_binding",
        "args.author_source_archive_binding",
        "args.local_data_manifest",
        "args.hpc_data_manifest",
        "args.execution_data_manifest",
    ):
        assert argument in required_block


def test_registered_numerical_gate_job_is_isolated_and_cpu_only():
    script = CLOSURE_GATE_SLURM_PATH.read_text(encoding="utf-8")

    assert "set -eo pipefail" in script
    assert "evaluate_full_reproduction.py" in script
    assert "time_split_vs_author.csv" in script
    assert "basin_split_vs_author.csv" in script
    assert "hyperparameters/scores.csv" in script
    assert "final_reproduction_gate.json" in script
    assert "final_reproduction_differences.csv" in script
    assert 'test ! -e "$GATE_OUTPUT"' in script
    assert 'test ! -e "$GATE_DETAILS"' in script
    assert "sha256sum" in script
    assert "--gres=gpu" not in script
    assert "--mem" not in script


def test_preclosure_validation_job_checks_the_offline_and_runtime_contracts():
    script = PRECLOSURE_VALIDATION_SLURM_PATH.read_text(encoding="utf-8")
    runner = SERVER_PRECLOSURE_SCRIPT_PATH.read_text(encoding="utf-8")

    assert "set -eo pipefail" in script
    assert "run_registered_numerical_gate.slurm" in script
    assert "run_registered_closure_manifest.slurm" in script
    assert "run_registered_closure_export.slurm" in script
    assert "source_archive_binding.json" in script
    assert "run_server_preclosure_check.py" in script
    assert "#SBATCH --nodelist=ngu003" in script
    assert "python -m pytest" not in script
    assert "github-grey-nearing-neuralhydrology-public-assimilation-a3f8bfc.bundle" in script
    assert "verify_local_pytest_receipt" in runner
    assert "verify_author_source_archives" in runner
    assert "verify_data_manifest_equivalence" in runner
    assert "verify_headline_artifact_recovery" in runner
    assert "comparison_evidence_artifacts" in runner
    assert "local_contract_validation_junit.xml" in runner
    assert "--gres=gpu" not in script
    assert "--mem" not in script


def test_final_decision_artifacts_require_three_consistent_completed_decisions(closure_verifier_module, tmp_path):
    layers = {}
    for layer, count in closure_verifier_module.FINAL_LAYER_COUNTS.items():
        prefix = {"data": "D", "method": "P", "model": "L", "result": "R"}[layer]
        layers[layer] = [{
            "id": f"{prefix}{index:02d}",
            "status": "verified",
            "current_reproduction": "direct evidence complete",
            "evidence": ["evidence.json"],
        } for index in range(1, count + 1)]
    by_id = {item["id"]: item for items in layers.values() for item in items}
    for identifier in closure_verifier_module.FINAL_CONFLICT_IDS:
        by_id[identifier]["status"] = "conflict"
    for identifier in closure_verifier_module.FINAL_NOT_AUDITABLE_IDS:
        by_id[identifier]["status"] = "not_auditable"
    register = {
        "schema": "nearing2022-reproduction-comparison-register-v1",
        "overall_status": "PARTIALLY_REPRODUCIBLE",
        "decision_targets": {
            "released_main_numerical_matrix": "GO",
            "literal_paper_text": "partially reproducible",
            "complete_published_study": "not fully reproducible",
        },
        "layers": layers,
    }
    source_scope = {
        "schema": "nearing2022-author-release-scope-audit-v1",
        "published_output_coverage": [{
            "component": component,
            "status": "not_auditable",
        } for component in (
            "basin-attribute attribution and spatial maps",
            "computational runtime comparison",
        )],
    }
    gate = {
        "schema": "nearing2022-full-reproduction-gate-v1",
        "released_code_numerical_status": "GO",
    }
    report = "\n".join((
        "作者发布主数值矩阵：**GO**",
        "论文字面协议：**部分可复现**",
        "完整已发表研究：**不能完整复现**",
    ))
    register_path = tmp_path / "register.json"
    source_scope_path = tmp_path / "source_scope.json"
    gate_path = tmp_path / "gate.json"
    report_path = tmp_path / "report.md"
    register_path.write_text(json.dumps(register), encoding="utf-8")
    source_scope_path.write_text(json.dumps(source_scope), encoding="utf-8")
    gate_path.write_text(json.dumps(gate), encoding="utf-8")
    report_path.write_text(report, encoding="utf-8")

    validated = closure_verifier_module.validate_final_decision_artifacts(
        register_path, source_scope_path, report_path, gate_path
    )
    assert validated["comparison_items"] == 42
    assert validated["released_code_numerical_status"] == "GO"

    by_id["R04"]["status"] = "pending"
    register_path.write_text(json.dumps(register), encoding="utf-8")
    with pytest.raises(ValueError, match="pending items"):
        closure_verifier_module.validate_final_decision_artifacts(
            register_path, source_scope_path, report_path, gate_path
        )


def test_frozen_numerical_gate_must_match_completed_slurm_log(closure_verifier_module, tmp_path):
    gate_path = tmp_path / "final_reproduction_gate.json"
    details_path = tmp_path / "final_reproduction_differences.csv"
    log_path = tmp_path / "N22-gate_202315.out"
    input_artifacts = {}
    for label in ("time_comparisons", "basin_comparisons", "hyperparameter_scores", "acceptance"):
        path = tmp_path / f"{label}.txt"
        path.write_text(f"{label}\n", encoding="utf-8")
        input_artifacts[label] = {
            "path": str(path.resolve()),
            "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
    gate_path.write_text(json.dumps({
        "released_code_numerical_status": "GO",
        "input_artifacts": input_artifacts,
    }) + "\n", encoding="utf-8")
    details_path.write_text("metric,difference\nNSE,0.001\n", encoding="utf-8")

    def digest(path: Path) -> str:
        return hashlib.sha256(path.read_bytes()).hexdigest()

    log_path.write_text(
        f"{digest(gate_path)}  {gate_path.resolve()}\n{digest(details_path)}  {details_path.resolve()}\n",
        encoding="utf-8",
    )
    verified = closure_verifier_module.verify_frozen_numerical_gate(gate_path, details_path, log_path)
    assert verified["verified_sha256"][str(gate_path.resolve())] == digest(gate_path)
    assert set(verified["verified_input_sha256"]) == set(input_artifacts)

    details_path.write_text("metric,difference\nNSE,0.1\n", encoding="utf-8")
    with pytest.raises(ValueError, match="changed after Slurm completion"):
        closure_verifier_module.verify_frozen_numerical_gate(gate_path, details_path, log_path)
    details_path.write_text("metric,difference\nNSE,0.001\n", encoding="utf-8")

    input_path = Path(input_artifacts["time_comparisons"]["path"])
    input_path.write_text("changed comparisons\n", encoding="utf-8")
    with pytest.raises(ValueError, match="input size changed|input changed"):
        closure_verifier_module.verify_frozen_numerical_gate(gate_path, details_path, log_path)


def test_full_reproduction_gate_uses_frozen_per_metric_thresholds(closure_gate_module):
    metrics = tuple(closure_gate_module.METRICS)
    acceptance = {
        "schema": "nearing2022-reproduction-acceptance-v1",
        "scope": {
            "numerical_target": "released_code",
            "hyperparameter_evaluation_period": "test",
            "paper_text_hyperparameter_evaluation_period": "validation",
        },
        "expected": {
            "time_comparison_rows": 151 * len(metrics),
            "basin_comparison_rows": 3 * len(metrics),
            "hyperparameter_coordinates": 660,
        },
        "absolute_difference_tolerance": {metric: 0.02 if metric == "NSE" else 0.05 for metric in metrics},
        "median_signed_difference_tolerance": {metric: 0.01 for metric in metrics},
        "hyperparameter_default_max_nse_deficit": 0.005,
        "released_default": {
            "window": 5,
            "epochs": 100,
            "history": 20,
            "learning_rate": 0.1,
            "drop_factor": 0.1,
            "targets": "c_n",
        },
    }

    time_rows = []
    family_sizes = {"time_simulation": 1, "time_autoregression": 125, "time_assimilation": 25}
    for family, size in family_sizes.items():
        for coordinate in range(size):
            for metric in metrics:
                time_rows.append({
                    "eval_id": f"{family}-{coordinate}",
                    "family": family,
                    "metric": metric,
                    "reproduction": 0.8,
                    "author": 0.795,
                    "difference": 0.005,
                })
    basin_rows = []
    for family in ("basin_simulation", "basin_autoregression", "basin_assimilation"):
        for metric in metrics:
            basin_rows.append({
                "family": family,
                "metric": metric,
                "reproduction": 0.8,
                "author": 0.795,
                "difference": 0.005,
            })
    hyper_rows = [{
        "grid_index": index,
        "eval_id": f"HYP-{index}",
        "window": 1,
        "epochs": 5,
        "history": 1,
        "learning_rate": 0.0001,
        "drop_factor": 0.5,
        "targets": "c_n",
        "NSE": 0.89,
    } for index in range(659)]
    hyper_rows.append({
        "grid_index": 659,
        "eval_id": "HYP-DEFAULT",
        "window": 5,
        "epochs": 100,
        "history": 20,
        "learning_rate": 0.1,
        "drop_factor": 0.1,
        "targets": "c_n",
        "NSE": 0.9,
    })

    gate, details = closure_gate_module.evaluate_reproduction_gate(
        pd.DataFrame(time_rows),
        pd.DataFrame(basin_rows),
        pd.DataFrame(hyper_rows),
        acceptance,
    )

    assert gate["released_code_numerical_status"] == "GO"
    assert gate["hyperparameter_evaluation_period"] == "test"
    assert gate["paper_text_hyperparameter_evaluation_period"] == "validation"
    assert gate["comparison_rows"] == 151 * len(metrics) + 3 * len(metrics)
    assert details["within_tolerance"].all()
    time_rows[0]["reproduction"] = 0.821
    time_rows[0]["difference"] = 0.026
    failed, _ = closure_gate_module.evaluate_reproduction_gate(
        pd.DataFrame(time_rows),
        pd.DataFrame(basin_rows),
        pd.DataFrame(hyper_rows),
        acceptance,
    )
    assert failed["released_code_numerical_status"] == "NO_GO"
    assert failed["individual_tolerance_failures"] == 1


def test_numerical_gate_fingerprints_the_exact_input_bytes_it_parses(closure_gate_module, tmp_path):
    path = tmp_path / "comparisons.csv"
    original = b"metric,value\nNSE,0.5\n"
    path.write_bytes(original)

    payload, fingerprint = closure_gate_module._read_fingerprinted_artifact(path)
    path.write_bytes(b"metric,value\nNSE,0.1\n")

    assert payload == original
    assert fingerprint["bytes"] == len(original)
    assert fingerprint["sha256"] == hashlib.sha256(original).hexdigest()
    assert fingerprint["sha256"] != hashlib.sha256(path.read_bytes()).hexdigest()
    assert 'pd.read_csv(io.BytesIO(time_bytes)' in Path(closure_gate_module.__file__).read_text(encoding="utf-8")


def test_frozen_numerical_gate_outputs_refuse_overwrite(closure_gate_module, tmp_path):
    gate_path = tmp_path / "gate.json"
    details_path = tmp_path / "details.csv"
    closure_gate_module._atomic_json({"status": "GO"}, gate_path)
    closure_gate_module._atomic_csv(pd.DataFrame([{"metric": "NSE"}]), details_path)

    with pytest.raises(FileExistsError, match="Refusing to overwrite frozen numerical gate"):
        closure_gate_module._atomic_json({"status": "NO_GO"}, gate_path)
    with pytest.raises(FileExistsError, match="Refusing to overwrite frozen numerical details"):
        closure_gate_module._atomic_csv(pd.DataFrame([{"metric": "KGE"}]), details_path)


def test_closure_export_contains_and_rehashes_every_manifest_artifact(
    closure_verifier_module, independent_export_verifier_module, tmp_path
):
    root = tmp_path / "root"
    first = root / "runs" / "first.bin"
    second = root / "aggregation" / "second.csv"
    first.parent.mkdir(parents=True)
    second.parent.mkdir(parents=True)
    first.write_bytes(b"raw-prediction-bytes")
    second.write_text("metric,value\nNSE,0.8\n", encoding="utf-8")
    audit = {
        "complete": True,
        "counts": {"training": 1, "evaluations": 1, "hyperparameters": 1},
        "artifacts": [
            {"path": str(first.resolve()), "bindings": []},
            {"path": str(second.resolve()), "bindings": []},
        ],
    }
    manifest_path = root / "closure" / "final_artifact_manifest.json"
    manifest = closure_verifier_module.write_closure_manifest(audit, root, manifest_path)
    archive_path = root / "export" / "closure.tar.gz"

    built = closure_verifier_module.build_closure_export(manifest_path, archive_path)

    assert built["verification"]["ok"]
    assert built["verification"]["expected_members"] == manifest["file_count"] + 1
    checksum_path = archive_path.with_name(archive_path.name + ".sha256")
    checksum_path.write_text(
        f"{built['archive_sha256']}  {archive_path.resolve()}\n", encoding="utf-8"
    )
    manifest_sha256 = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    independent = independent_export_verifier_module.verify_archive(
        archive_path, checksum_path, manifest_sha256
    )
    assert independent["ok"]
    assert independent["archive_sha256"] == built["archive_sha256"]
    assert independent["manifest_binding_verified"]
    assert independent["manifest_file_count"] == manifest["file_count"]
    with pytest.raises(ValueError, match="independently recovered manifest"):
        independent_export_verifier_module.verify_archive(archive_path, checksum_path, "0" * 64)
    with tarfile.open(archive_path, mode="r:gz") as archive:
        members = {member.name for member in archive.getmembers()}
    assert members == {
        *(entry["path"] for entry in manifest["files"]),
        "closure/final_artifact_manifest.json",
    }

    first.write_bytes(b"mutated-after-export")
    assert closure_verifier_module.verify_closure_export(manifest_path, archive_path)["ok"]

    incomplete_archive = root / "export" / "incomplete.tar.gz"
    with tarfile.open(incomplete_archive, mode="w:gz") as archive:
        archive.add(manifest_path, arcname="closure/final_artifact_manifest.json", recursive=False)
    incomplete = closure_verifier_module.verify_closure_export(manifest_path, incomplete_archive)
    assert not incomplete["ok"]
    assert set(incomplete["missing_members"]) == {entry["path"] for entry in manifest["files"]}
    independent_incomplete = independent_export_verifier_module.verify_archive(incomplete_archive)
    assert not independent_incomplete["ok"]
    assert set(independent_incomplete["missing_members"]) == {entry["path"] for entry in manifest["files"]}


def test_closure_manifest_rejects_path_traversal(closure_verifier_module, tmp_path):
    root = tmp_path / "root"
    manifest_path = root / "closure" / "manifest.json"
    manifest_path.parent.mkdir(parents=True)
    manifest_path.write_text(json.dumps({
        "schema": "nearing2022-registered-closure-manifest-v1",
        "root": "..",
        "counts": {},
        "file_count": 1,
        "total_bytes": 0,
        "files": [{"path": "../escape", "bytes": 0, "sha256": "0" * 64, "bindings": []}],
    }), encoding="utf-8")

    with pytest.raises(ValueError, match="Unsafe or non-canonical"):
        closure_verifier_module.verify_closure_manifest(manifest_path)


def test_registered_closure_export_job_builds_manifest_complete_archive():
    script = CLOSURE_EXPORT_SLURM_PATH.read_text(encoding="utf-8")

    assert "set -eo pipefail" in script
    assert "build_closure_export" in script
    assert "verify_closure_export" in script
    assert "summary['verification']['ok']" in script
    assert "final_artifact_manifest.json" in script
    assert "MANIFEST_CHECKSUM" in script
    assert "Final artifact manifest disagrees with its frozen checksum sidecar" in script
    assert "Final artifact manifest changed during closure export" in script
    assert "tar -czf" not in script
    assert "Checksum exists without closure export" in script
    assert "reused_existing_archive" in script
    assert "Existing checksum sidecar disagrees" in script
    assert "checksum_temporary.replace(checksum_path)" in script
    assert "#SBATCH --time=1-00:00:00" in script
    assert "--gres=gpu" not in script
    assert "--mem" not in script
