from typing import Any, Dict, List, Union

from pathlib import Path

from ruamel.yaml import YAML


class AssimilationConfig(object):
    """Configuration class for the data assimilation specific arguments.

    This is a slim, standalone counterpart to :py:class:`neuralhydrology.utils.config.Config`. It only holds the
    settings that are needed while assimilating at inference time and additionally exposes the handful of properties
    that the loss- and optimizer-factories in :py:mod:`neuralhydrology.training` expect from a config object.

    The settings are usually not passed as a separate file but as a nested ``assimilation_config`` block inside a
    regular run configuration.

    Parameters
    ----------
    yml_path_or_dict : Union[Path, dict]
        Either a path to a config file or a dictionary of configuration values.
    dev_mode : bool, optional
        If dev_mode is off (default), the config creation fails if there are unrecognized keys in the passed
        specification.

    Raises
    ------
    ValueError
        If the passed configuration specification is neither a Path nor a dict, or if `dev_mode` is off and the
        specification contains unrecognized keys.
    """

    # kept for symmetry with `Config`; no deprecated or metadata keys exist for the assimilation block (yet).
    _deprecated_keys = []
    _metadata_keys = []

    def __init__(self, yml_path_or_dict: Union[Path, dict], dev_mode: bool = False):
        if isinstance(yml_path_or_dict, Path):
            yaml = YAML(typ="safe")
            with yml_path_or_dict.open('r') as fp:
                self._cfg = yaml.load(fp)
        elif isinstance(yml_path_or_dict, dict):
            self._cfg = dict(yml_path_or_dict)
        else:
            raise ValueError(f'Cannot create an assimilation config from input of type {type(yml_path_or_dict)}.')

        if not (self._cfg.get('dev_mode', False) or dev_mode):
            AssimilationConfig._check_cfg_keys(self._cfg)

    def as_dict(self) -> dict:
        """Return the config as a dictionary."""
        return dict(self._cfg)

    def _get_value_verbose(self, key: str) -> Any:
        """Use this function internally to return attributes of the config that are mandatory"""
        if key not in self._cfg.keys():
            raise ValueError(f"{key} is not specified in the assimilation config (.yml).")
        elif self._cfg[key] is None:
            raise ValueError(f"{key} is mandatory but 'None' in the assimilation config.")
        else:
            return self._cfg[key]

    @staticmethod
    def _as_default_list(value: Any) -> list:
        if value is None:
            return []
        elif isinstance(value, list):
            return value
        else:
            return [value]

    @staticmethod
    def _check_cfg_keys(cfg: dict):
        """Checks the config for unknown keys."""
        property_names = [p for p in dir(AssimilationConfig) if isinstance(getattr(AssimilationConfig, p), property)]

        unknown_keys = [
            k for k in cfg.keys() if k not in property_names and k not in AssimilationConfig._deprecated_keys and
            k not in AssimilationConfig._metadata_keys and k != 'dev_mode'
        ]
        if unknown_keys:
            raise ValueError(f'{unknown_keys} are not recognized assimilation config keys.')

    @property
    def assimilation_lead_time(self) -> int:
        """Number of time steps between the last assimilated observation and the end of the input sequence."""
        return self._get_value_verbose("assimilation_lead_time")

    @property
    def assimilation_targets(self) -> List[str]:
        """Names of the model states that are updated during assimilation (e.g. ``c_n``)."""
        assimilation_targets = self._as_default_list(self._cfg.get("assimilation_targets", []))
        if not assimilation_targets:
            raise ValueError("At least one assimilation target has to be specified")
        return assimilation_targets

    @property
    def assimilation_window(self) -> int:
        """Number of time steps in one assimilation window."""
        return self._get_value_verbose("assimilation_window")

    @property
    def epochs(self) -> int:
        """Maximum number of update steps per assimilation window."""
        return self._cfg.get("epochs", 200)

    @property
    def history(self) -> int:
        """Number of assimilation windows, i.e. how far back assimilation starts (in units of `assimilation_window`)."""
        return self._get_value_verbose("history")

    @property
    def learning_rate(self) -> Dict[int, float]:
        if ("learning_rate" in self._cfg.keys()) and (self._cfg["learning_rate"] is not None):
            if isinstance(self._cfg["learning_rate"], float):
                return {0: self._cfg["learning_rate"]}
            elif isinstance(self._cfg["learning_rate"], int):
                return {0: float(self._cfg["learning_rate"])}
            elif isinstance(self._cfg["learning_rate"], dict):
                return self._cfg["learning_rate"]
            else:
                raise ValueError("Unsupported data type for learning rate. Use either dict (epoch to float) or float.")
        else:
            raise ValueError("No learning rate specified in the assimilation config (.yml).")

    @property
    def learning_rate_drop_factor(self) -> float:
        """Factor the learning rate is multiplied with whenever an update step made the loss worse."""
        return self._cfg.get("learning_rate_drop_factor", 0.9)

    @property
    def learning_rate_epoch_drop(self) -> int:
        """Number of consecutive successful updates after which the learning rate is reduced."""
        return self._cfg.get("learning_rate_epoch_drop", 5)

    @property
    def loss(self) -> str:
        return self._get_value_verbose("loss")

    @property
    def model_dropout(self) -> bool:
        """If True, the full model is set to train mode during assimilation (i.e. dropout stays active)."""
        model_dropout = self._cfg.get("model_dropout", False)
        return bool(model_dropout) if model_dropout is not None else False

    @property  # required by the loss class
    def no_loss_frequencies(self) -> List[str]:
        return self._as_default_list(self._cfg.get("no_loss_frequencies", []))

    @property
    def optimizer(self) -> str:
        return self._get_value_verbose("optimizer")

    @property  # required by the loss class
    def predict_last_n(self) -> int:
        return self._get_value_verbose("predict_last_n")

    @property
    def regularization(self) -> List[str]:
        return self._as_default_list(self._cfg.get("regularization", []))

    @property
    def seq_length(self) -> int:
        return self._get_value_verbose("seq_length")

    @property  # required by the loss class
    def target_loss_weights(self) -> List[float]:
        return self._cfg.get("target_loss_weights", None)

    @property  # required by the loss class
    def target_variables(self) -> List[str]:
        return self._get_value_verbose("target_variables")

    @property
    def timestep_dropout(self) -> float:
        """Fraction of observations within an assimilation window that is randomly dropped at each update step."""
        timestep_dropout = self._cfg.get("timestep_dropout", 0.0)
        if timestep_dropout is None:
            return 0.0
        if timestep_dropout >= 1.0:
            raise ValueError("'timestep_dropout' has to be smaller than 1.0 (and larger or equal to 0.0)")
        return timestep_dropout
