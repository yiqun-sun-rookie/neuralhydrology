"""Variational data assimilation at inference time.

This is a port of the ``assimilation`` branch of https://github.com/grey-nearing/neuralhydrology-public (commit
``a3f8bfc``, on top of tag ``v.1.3.0``), the implementation released with

    Nearing, G. S., Klotz, D., Frame, J. M., Gauch, M., Gilon, O., Kratzert, F., Sampson, A. K., Shalev, G., and
    Nevo, S. (2022): Technical note: Data assimilation and autoregression for using near-real-time streamflow
    observations in long short-term memory networks. Hydrol. Earth Syst. Sci., 26, 5493-5513.

Model weights stay frozen. Instead, the LSTM states at the beginning of an assimilation window are treated as free
variables and updated by backpropagating the mismatch between predictions and observations *within that window*. The
optimized states are then carried forward to produce the predictions after the assimilation period.

The algorithm is kept bit-for-bit faithful to the released implementation, including two behaviours that are not
described in the paper and that materially change what the method does (both are flagged inline below):

1. After the first update step that increases the loss, the working copy of the assimilation targets is replaced by a
   *snapshot* of the last good state. The optimizer keeps pointing at the original leaf tensors, so from that point on
   the values fed to the model no longer change -- the window is effectively frozen at its last good state while the
   learning rate keeps decaying until the early-stopping criterion trips.
2. The learning rate is initialized once, before the loop over windows, and therefore carries its decayed value over
   from one assimilation window to the next.
3. The loss is subset by ``predict_last_n`` of the assimilation config before it is evaluated. With the released
   setting of ``predict_last_n: 1`` this means only the *last* time step of each window enters the objective, not the
   whole window as written in Eq. D1 of the paper. An assimilation window is therefore 5 steps of model integration
   against a single observation, and ``history`` such windows are assimilated sequentially.

Adaptations required by the current neuralhydrology API (v1.12), none of which change the algorithm:

* ``data['x_d']`` is a ``dict`` of per-feature tensors here, whereas it was a single ``[batch, seq, features]`` tensor
  in v1.3. All time slicing and NaN masking is done per feature.
* ``BaseLoss.forward`` returns a ``(total_loss, all_losses)`` tuple instead of a scalar.
* The batch dict may contain non-tensor entries (e.g. ``date``), which are passed through untouched.
"""

from typing import Any, Dict, List, Optional

import torch
import torch.nn as nn

from neuralhydrology.modelzoo.basemodel import BaseModel
from neuralhydrology.training import get_loss_obj, get_optimizer, get_regularization_obj
from neuralhydrology.utils.assimilationconfig import AssimilationConfig


def _clone(value: Any, detach: bool = False) -> Any:
    """Clone tensors (recursing into dicts) and pass everything else through untouched."""
    if isinstance(value, dict):
        return {k: _clone(v, detach=detach) for k, v in value.items()}
    if isinstance(value, torch.Tensor):
        return value.detach().clone() if detach else value.clone()
    return value


def _slice_time(value: Any, start: Optional[int], end: Optional[int]) -> Any:
    """Slice the time dimension (dim 1) of tensors, recursing into dicts. Non-tensors are passed through."""
    if isinstance(value, dict):
        return {k: _slice_time(v, start, end) for k, v in value.items()}
    if isinstance(value, torch.Tensor) and value.dim() >= 2:
        return value[:, start:end].clone()
    return value


def _sequence_length(x_d: Dict[str, torch.Tensor]) -> int:
    """Length of the time dimension of a dict of dynamic inputs."""
    for tensor in x_d.values():
        if isinstance(tensor, torch.Tensor) and tensor.dim() >= 2:
            return tensor.shape[1]
    raise ValueError("Could not determine the sequence length from the dynamic inputs.")


def _finite_sample_mask(x_d: Dict[str, torch.Tensor]) -> Optional[torch.Tensor]:
    """Boolean mask of samples in the batch whose dynamic inputs contain no NaN in the current slice.

    Equivalent to ``~torch.isnan(x_d).any(1).any(1)`` in the original implementation, where ``x_d`` was one tensor.
    """
    mask = None
    for tensor in x_d.values():
        if not isinstance(tensor, torch.Tensor) or tensor.dim() < 2:
            continue
        feature_mask = ~torch.isnan(tensor).flatten(start_dim=1).any(dim=1)
        mask = feature_mask if mask is None else (mask & feature_mask)
    return mask


def _apply_mask(value: Any, mask: torch.Tensor) -> Any:
    """Subset the batch dimension of tensors, recursing into dicts. Non-tensors are passed through."""
    if isinstance(value, dict):
        return {k: _apply_mask(v, mask) for k, v in value.items()}
    if isinstance(value, torch.Tensor) and value.dim() >= 1 and value.shape[0] == mask.shape[0]:
        return value[mask]
    return value


class Assimilation(object):
    """Variational assimilation of model states at inference time.

    Parameters
    ----------
    cfg : AssimilationConfig
        The assimilation configuration, i.e. the ``assimilation_config`` block of the run configuration.
    """

    def __init__(self, cfg: AssimilationConfig):
        self.cfg = cfg

        # start and end index of the assimilation period
        self._end_timestep = cfg.seq_length - cfg.assimilation_lead_time
        self._start_timestep = self._end_timestep - (cfg.history * cfg.assimilation_window)

        if self._start_timestep < 0:
            raise ValueError("The sum of the warmup and assimilation period has to be smaller than the sequence length")

        # initialize loss object
        self._loss_obj = get_loss_obj(cfg)
        self._loss_obj.set_regularization_terms(get_regularization_obj(cfg=cfg))

    def assimilate(self, model: BaseModel, data: Dict[str, Any], x_d_key: str = 'x_d') -> Dict[str, torch.Tensor]:
        """Assimilate observations into the model states and predict beyond the assimilation period.

        Parameters
        ----------
        model : BaseModel
            The trained model. Its weights are not modified.
        data : Dict[str, Any]
            One batch, as returned by the data loader.
        x_d_key : str, optional
            Key of the dynamic inputs in `data`. Only single-frequency models are supported.

        Returns
        -------
        Dict[str, torch.Tensor]
            Dictionary with the key ``y_hat``, holding predictions for the full input sequence.
        """
        if not model.state_var_names:
            raise RuntimeError(f"{model.__class__.__name__} does not expose state variables required for assimilation.")

        seq_length = _sequence_length(data[x_d_key])
        if seq_length != self.cfg.seq_length:
            raise ValueError(f"Sequence length of the batch ({seq_length}) does not match the assimilation config "
                             f"({self.cfg.seq_length}).")

        # Track gradients through all parts of the model. cuDNN layers only track gradients in train mode, so we either
        # run the whole model in train mode (which also activates dropout, if configured as a regularization strategy)
        # or put only the recurrent parts into train mode and leave dropout untouched.
        if self.cfg.model_dropout:
            model.train()
        else:
            for module in model.modules():
                if isinstance(module, (nn.LSTM, nn.GRU)):
                    module.train()

        # during assimilation, we can also use dropout on the timesteps, to add additional stochasticity
        timestep_dropout = self.cfg.timestep_dropout > 0.0
        if timestep_dropout:
            mask_sampler = torch.distributions.bernoulli.Bernoulli(torch.tensor([1 - self.cfg.timestep_dropout]))

        # perform forward pass through the warmup period until the first assimilation step
        assim_data = {k: (_slice_time(v, None, self._start_timestep) if k == x_d_key else _clone(v))
                      for k, v in data.items()}
        pred = model(assim_data)

        # store the predictions of all time steps in a list, which we concatenate at the end
        y_hat = [pred['y_hat'].detach().clone()]

        # NOTE (faithful to the released implementation): the learning rate is initialized once here, so its decayed
        # value carries over from one assimilation window to the next.
        learning_rate = self.cfg.learning_rate[0]

        for timestep in range(self._start_timestep, self._end_timestep, self.cfg.assimilation_window):

            # slice input sequence only for the specific assimilation window
            window_end = timestep + self.cfg.assimilation_window
            assim_data[x_d_key] = _slice_time(data[x_d_key], timestep, window_end)
            assim_data['y'] = data['y'][:, timestep:window_end].clone()

            # add states of the last time step to the input data dictionary
            for var in model.state_var_names:
                assim_data[var] = pred[var].detach().clone()

            # make sure we calculate gradients for the assimilation targets
            for var in self.cfg.assimilation_targets:
                assim_data[var].requires_grad = True

            # create a copy of the data, so we can go back one iteration step, if the update makes the results worse
            last_assim_data = {k: _clone(v) for k, v in assim_data.items()}

            optimizer = get_optimizer([assim_data[var] for var in self.cfg.assimilation_targets], self.cfg)
            for param_group in optimizer.param_groups:
                param_group["lr"] = learning_rate

            # compute predictions with unchanged inputs
            pred = model(assim_data)

            # counter for the manual learning rate decrease after a set number of successful updates
            counter = 0

            for epoch in range(self.cfg.epochs):

                # perform one update step
                optimizer.zero_grad()

                mask = _finite_sample_mask(assim_data[x_d_key])
                # mask all outputs required for loss computation. Currently exclude states, since those have shape
                # [batch, 1, hidden] for cudalstm and would require some extra steps
                masked_pred = {k: pred[k][mask] for k in self._loss_obj._prediction_keys}
                masked_data = {k: _apply_mask(assim_data[k], mask) for k in data.keys()}

                if timestep_dropout:
                    # sample and apply dropout mask
                    timestep_mask = mask_sampler.sample(masked_data["y"].shape).bool().squeeze(-1).to(data["y"].device)
                    # We "apply" dropout by setting the targets to NaN, which excludes those timesteps in the loss
                    masked_data["y"][timestep_mask] = torch.tensor(float("nan")).to(data["y"].device)

                initial_loss_value, _ = self._loss_obj(masked_pred, masked_data)
                initial_loss_value.backward()
                optimizer.step()

                # perform another forward pass with updated model inputs and compute the loss after the update
                pred = model(assim_data)
                mask = _finite_sample_mask(assim_data[x_d_key])
                masked_pred = {k: pred[k][mask] for k in self._loss_obj._prediction_keys}
                masked_data = {k: _apply_mask(assim_data[k], mask) for k in data.keys()}

                if timestep_dropout:
                    # Same mask, to make the results comparable
                    masked_data["y"][timestep_mask] = torch.tensor(float("nan")).to(data["y"].device)

                loss_after_update, _ = self._loss_obj(masked_pred, masked_data)

                # if the loss is increasing rather than decreasing, reset the inputs to the previous state and reduce
                # the learning rate.
                # NOTE (faithful to the released implementation): this rebinds `assim_data` to fresh snapshot tensors
                # while the optimizer keeps holding the original leaves. From here on the values seen by the model no
                # longer change; the window is frozen at its last good state and only the learning rate keeps decaying
                # until the early-stopping criterion below trips.
                if initial_loss_value < loss_after_update:
                    assim_data = {k: _clone(v) for k, v in last_assim_data.items()}
                    learning_rate = learning_rate * self.cfg.learning_rate_drop_factor
                    for param_group in optimizer.param_groups:
                        param_group["lr"] = learning_rate
                    # reset counter
                    counter = 0
                else:
                    # store last "good" data so we can go back if loss increases on subsequent epoch
                    counter += 1
                    last_assim_data = {k: _clone(v, detach=True) for k, v in assim_data.items()}

                    # check the counter with the user defined constant learning rate step size and optionally reduce lr
                    if counter == self.cfg.learning_rate_epoch_drop:
                        learning_rate = learning_rate * self.cfg.learning_rate_drop_factor
                        for param_group in optimizer.param_groups:
                            param_group["lr"] = learning_rate
                        # reset counter
                        counter = 0

                # heuristic values for early stopping
                if learning_rate < 1e-5 or loss_after_update < 1e-5:
                    break

                # we don't want to overfit to earlier parts of the assimilation period, so those only get a limited
                # number of epochs until we reached the final assimilation window.
                if (timestep < self._end_timestep - self.cfg.assimilation_window) and (epoch >= 5):
                    break

            y_hat.append(pred["y_hat"])

        # finally, make predictions beyond the assimilation period, starting from the assimilated states
        if self._end_timestep < seq_length:
            assim_data = {k: _clone(v, detach=True) for k, v in data.items()}
            for var in model.state_var_names:
                assim_data[var] = pred[var].detach().clone()
            assim_data[x_d_key] = _slice_time(data[x_d_key], self._end_timestep, None)
            pred = model(assim_data)
            y_hat.append(pred["y_hat"])

        return {'y_hat': torch.cat(y_hat, 1)}
