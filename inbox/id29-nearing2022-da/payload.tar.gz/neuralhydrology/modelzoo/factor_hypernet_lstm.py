"""Factorized hypernetwork LSTM for basin-specific recurrent weights."""
from __future__ import annotations

from typing import Dict

import torch
import torch.nn as nn

from neuralhydrology.modelzoo.basemodel import BaseModel
from neuralhydrology.modelzoo.head import get_head
from neuralhydrology.modelzoo.inputlayer import InputLayer
from neuralhydrology.utils.config import Config


class FactorHypernetwork(nn.Module):
    """Map static attributes to low-rank LSTM parameter deltas."""

    def __init__(
            self,
            static_size: int,
            input_size: int,
            hidden_size: int,
            rank: int,
            hyper_hidden_size: int,
            init_delta_scale: float = 0.0,
    ):
        super().__init__()
        if static_size <= 0:
            raise ValueError("FactorHypernetwork requires at least one static input.")
        if input_size <= 0:
            raise ValueError("FactorHypernetwork requires at least one dynamic input.")
        if hidden_size <= 0:
            raise ValueError("hidden_size must be positive.")
        if rank <= 0:
            raise ValueError("rank must be positive.")
        if hyper_hidden_size <= 0:
            raise ValueError("hyper_hidden_size must be positive.")

        self.input_size = input_size
        self.hidden_size = hidden_size
        self.rank = rank
        self.init_delta_scale = float(init_delta_scale)

        gate_size = 4 * hidden_size
        self.encoder = nn.Sequential(
            nn.Linear(static_size, hyper_hidden_size),
            nn.Tanh(),
        )
        self.ih_left = nn.Linear(hyper_hidden_size, input_size * rank)
        self.ih_right = nn.Linear(hyper_hidden_size, rank * gate_size)
        self.hh_left = nn.Linear(hyper_hidden_size, hidden_size * rank)
        self.hh_right = nn.Linear(hyper_hidden_size, rank * gate_size)
        self.bias = nn.Linear(hyper_hidden_size, gate_size)

    def forward(self, static: torch.Tensor) -> Dict[str, torch.Tensor]:
        z = self.encoder(static)
        batch_size = static.shape[0]
        gate_size = 4 * self.hidden_size

        ih_left = self.ih_left(z).view(batch_size, self.input_size, self.rank)
        ih_right = self.ih_right(z).view(batch_size, self.rank, gate_size)
        hh_left = self.hh_left(z).view(batch_size, self.hidden_size, self.rank)
        hh_right = self.hh_right(z).view(batch_size, self.rank, gate_size)

        scale = self.init_delta_scale
        return {
            "delta_weight_ih": scale * torch.bmm(ih_left, ih_right),
            "delta_weight_hh": scale * torch.bmm(hh_left, hh_right),
            "delta_bias": scale * self.bias(z),
        }


class FactorHypernetLSTM(BaseModel):
    """LSTM whose effective recurrent parameters receive basin-specific low-rank deltas."""

    module_parts = ["embedding_net", "hypernetwork", "head"]

    def __init__(self, cfg: Config):
        super().__init__(cfg=cfg)
        self._hidden_size = cfg.hidden_size
        self.embedding_net = InputLayer(cfg)
        if self.embedding_net.statics_output_size == 0:
            raise ValueError("FactorHypernetLSTM requires static inputs.")

        input_size = self.embedding_net.dynamics_output_size
        gate_size = 4 * self._hidden_size
        self.weight_ih = nn.Parameter(torch.empty(input_size, gate_size))
        self.weight_hh = nn.Parameter(torch.empty(self._hidden_size, gate_size))
        self.bias = nn.Parameter(torch.empty(gate_size))
        self._reset_parameters()

        self.hypernetwork = FactorHypernetwork(
            static_size=self.embedding_net.statics_output_size,
            input_size=input_size,
            hidden_size=self._hidden_size,
            rank=cfg.hypernet_rank,
            hyper_hidden_size=cfg.hypernet_hidden_size,
            init_delta_scale=cfg.hypernet_init_delta_scale,
        )
        self.dropout = nn.Dropout(p=cfg.output_dropout)
        self.head = get_head(cfg=cfg, n_in=self._hidden_size, n_out=self.output_size)

    def _reset_parameters(self):
        nn.init.orthogonal_(self.weight_ih)
        eye = torch.eye(self._hidden_size)
        self.weight_hh.data = eye.repeat(1, 4)
        nn.init.zeros_(self.bias)
        if self.cfg.initial_forget_bias is not None:
            self.bias.data[self._hidden_size:2 * self._hidden_size] = self.cfg.initial_forget_bias

    def forward(self, data: dict[str, torch.Tensor | dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        x_d, x_s = self.embedding_net(data, concatenate_output=False)
        if x_s is None:
            raise ValueError("FactorHypernetLSTM requires static inputs.")

        deltas = self.hypernetwork(x_s)
        delta_weight_ih = deltas["delta_weight_ih"]
        delta_weight_hh = deltas["delta_weight_hh"]
        delta_bias = deltas["delta_bias"]

        batch_size = x_d.shape[1]
        h_t = x_d.new_zeros(batch_size, self._hidden_size)
        c_t = x_d.new_zeros(batch_size, self._hidden_size)
        h_n, c_n = [], []

        for x_dt in x_d:
            shared_gates = x_dt @ self.weight_ih + h_t @ self.weight_hh + self.bias
            basin_gates = (
                torch.bmm(x_dt.unsqueeze(1), delta_weight_ih).squeeze(1)
                + torch.bmm(h_t.unsqueeze(1), delta_weight_hh).squeeze(1)
                + delta_bias
            )
            gates = shared_gates + basin_gates
            i, f, g, o = gates.chunk(4, dim=-1)
            i = torch.sigmoid(i)
            f = torch.sigmoid(f)
            g = torch.tanh(g)
            o = torch.sigmoid(o)
            c_t = f * c_t + i * g
            h_t = o * torch.tanh(c_t)
            h_n.append(h_t)
            c_n.append(c_t)

        h_n = torch.stack(h_n, 0).transpose(0, 1)
        c_n = torch.stack(c_n, 0).transpose(0, 1)

        pred = {"h_n": h_n, "c_n": c_n}
        pred.update(self.head(self.dropout(h_n)))
        return pred
