# GRAiCE author-code adaptation B02

Upstream: https://github.com/PalIre/GRAiCE
Commit: beef77f1583fdbb32bd761b64eeb153e079a2581 (unchanged files under provenance/upstream).

03_model_training.py model_config -> id25/graice_lstmnosif.py build_model:
same intended unidirectional LSTM, tanh hidden Dense and linear TWSA Dense;
repair model-type shadowing/dispatch, explicit Input, modern LSTM instead of CuDNNLSTM.
get_datasets -> fit_scalers/transform_x/transform_y/inverse_y: training-only per-region RobustScalers;
the target origin is changed from first observation to the 2002-2007 fit mean.
load_data/extract_pixdata -> daily_features/sequences: existing regional arrays, five noSIF fields,
11 previous calendar means + current exact GRACE-weighted window. Downward shortwave is
an explicit substitution for surface net solar radiation. RH and mean temperature are approximations.
Original per-pixel loop -> train_graice_lstmnosif.py fit_region: one attempt per region,
fixed 32 LSTM / 16 Dense units, 2002-2007 fit, 2008 checkpoint/early-stop selection.
Original fit(MSE, Adam, batch32) -> equivalent explicit per-epoch batches/GradientTape,
allowing an atomic optimizer/model/best/counter checkpoint every epoch.
Original 5-attempt/last-training-MAE selection -> one attempt, same val_ref_mse_cm2
for selected weights and patience=30; max1000 cumulative epochs per regional model.
04_apply_model.py -> same sequences and frozen scalers/references; output keyed by solution.
Existing RDS01 centered window outputs are copied without re-running or re-centering RDS01.
No SIF, static features, published optimal hyperparameters, or pretrained author weights are used.
