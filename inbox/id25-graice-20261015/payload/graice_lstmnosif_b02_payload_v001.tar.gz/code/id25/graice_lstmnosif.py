"""119-region adapter for PalIre/GRAiCE LSTMnoSIF (beef77f1583f).

Derived interfaces: 03_model_training.py load_data/extract_pixdata/get_datasets/
model_config. Preserve the intended per-pixel LSTM + tanh Dense + linear head;
replace pixel rasters, split, timing and checkpoint selection as documented in
draft/2026-10-15-id25-graice-author-comparator-plan-v1.md.
TensorFlow is deliberately imported only inside build_model().
"""
import hashlib
import json
from pathlib import Path
import zipfile

import numpy as np

AUTHOR_COMMIT = "beef77f1583fdbb32bd761b64eeb153e079a2581"
FEATURES = ["pcp_mean_daily_m", "tmp_K", "swe_m", "downward_shortwave_mean_daily_J_m2", "rh_approx_percent"]


def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_name(path.name + ".pending")
    pending.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    pending.replace(path)


def save_npz(path, **arrays):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_name(path.name + ".pending")
    with pending.open("wb") as handle:
        np.savez_compressed(handle, **arrays)
    pending.replace(path)


def read_selected(path, member, rows, columns):
    """Read existing selected forcing cells; adapted from the RDS01 exporter."""
    rr, cc = list(map(int, rows)), list(map(int, columns))
    if len(rr) != len(set(rr)) or len(cc) != len(set(cc)):
        raise ValueError("Duplicate source selection")
    with zipfile.ZipFile(path) as archive, archive.open(member + ".npy") as handle:
        version = np.lib.format.read_magic(handle)
        readers = {(1, 0): np.lib.format.read_array_header_1_0,
                   (2, 0): np.lib.format.read_array_header_2_0}
        shape, fortran, dtype = readers[version](handle)
        if fortran or len(shape) != 3 or dtype.hasobject:
            raise ValueError("Expected C-order numeric forcing")
        if min(rr) < 0 or max(rr) >= shape[0] or min(cc) < 0 or max(cc) >= shape[1]:
            raise ValueError("Selection outside existing export")
        result = np.empty((len(rr), len(cc), shape[2]), dtype=dtype)
        destination = dict(zip(rr, range(len(rr))))
        size = shape[1] * shape[2] * dtype.itemsize
        for row in range(shape[0]):
            raw = handle.read(size)
            if len(raw) != size:
                raise EOFError("Truncated forcing member")
            if row in destination:
                values = [np.frombuffer(raw, dtype=dtype, count=shape[2],
                                        offset=col * shape[2] * dtype.itemsize) for col in cc]
                result[destination[row]] = np.stack(values)
    return result


def daily_features(forcing):
    """Transform [P,ssrd,SWE,Tmax,Tmin,vp] before temporal averaging."""
    values = np.asarray(forcing, dtype=np.float64)
    if values.shape[-1] != 6 or not np.isfinite(values).all():
        raise ValueError("Six finite original forcing fields required")
    temp_c = .5 * (values[..., 3] + values[..., 4])
    es = 611.2 * np.exp(17.67 * temp_c / (temp_c + 243.5))
    raw_rh = 100.0 * values[..., 5] / es
    features = np.stack([values[..., 0] / 1000., temp_c + 273.15,
                         values[..., 2] / 1000., values[..., 1] * 86400.,
                         np.clip(raw_rh, 0., 100.)], axis=-1)
    clipped = (raw_rh < 0.) | (raw_rh > 100.)
    if not np.isfinite(features).all():
        raise ValueError("Nonfinite derived feature")
    return features, clipped


def sequences(dates, features, windows, lag=12):
    """Previous lag-1 calendar months + the exact current GRACE support."""
    dates = np.asarray(dates).astype("datetime64[D]")
    if not np.all(np.diff(dates).astype(int) == 1):
        raise ValueError("Continuous daily forcing required")
    months = dates.astype("datetime64[M]")
    month_means = {}
    for month in np.unique(months):
        start = month.astype("datetime64[D]")
        stop = (month + 1).astype("datetime64[D]")
        idx = np.flatnonzero(months == month)
        if len(idx) == int((stop - start).astype(int)):
            month_means[str(month)] = features[idx].mean(axis=0)
    day_index = {str(day): i for i, day in enumerate(dates)}
    output, receipts = [], []
    for window in windows:
        used = window["dates"]
        weights = np.asarray(window["weights"], dtype=np.float64)
        if len(used) != len(set(used)) or len(used) != len(weights) or not len(used):
            raise ValueError("Unique nonempty observation support required")
        if not np.isfinite(weights).all() or np.any(weights < 0) or weights.sum() <= 0:
            raise ValueError("Invalid observation weights")
        weights = weights / weights.sum()
        last = max(used)
        anchor = np.datetime64(last, "M")
        history = [str(anchor - i) for i in range(lag - 1, 0, -1)]
        if any(month not in month_means for month in history):
            raise ValueError("Incomplete lag history: " + window["solution_id"])
        current = np.tensordot(weights, features[[day_index[d] for d in used]], axes=(0, 0))
        sample = np.stack([month_means[m] for m in history] + [current], axis=1)
        # Region x lag x feature; none of the historical calendar slots is future.
        if str((anchor - 1).astype("datetime64[M]")) != history[-1]:
            raise AssertionError("History anchor mismatch")
        output.append(sample)
        receipts.append({"solution_id": window["solution_id"], "history_months": history,
                         "last_input_day": last, "current_sampled_days": len(used),
                         "current_support_weight_sum": float(weights.sum())})
    return np.asarray(output, dtype=np.float32), receipts


def build_model(config):
    """Repair author's model-type dispatch and CuDNNLSTM compatibility path."""
    import tensorflow as tf
    if config["model_type"] != "LSTM":
        raise ValueError("This fixed experiment accepts only unidirectional LSTM")
    network = tf.keras.Sequential(name="GRAiCE_LSTMnoSIF_119region")
    network.add(tf.keras.Input(shape=(config["lag_months"], len(FEATURES)), name="monthly_forcing"))
    network.add(tf.keras.layers.LSTM(config["lstm_units"], activation="tanh",
                                     recurrent_activation="sigmoid", unit_forget_bias=True,
                                     dropout=0., recurrent_dropout=0., name="author_lstm"))
    network.add(tf.keras.layers.Dense(config["dense_units"], activation="tanh", name="author_dense"))
    network.add(tf.keras.layers.Dense(1, activation=None, name="twsa"))
    return network


def fit_scalers(x_fit, y_fit):
    """Author's training-only RobustScalers, with fixed fit-mean target origin."""
    from sklearn.preprocessing import RobustScaler
    sx = RobustScaler().fit(np.asarray(x_fit).reshape(-1, len(FEATURES)))
    y_ref = float(np.mean(y_fit, dtype=np.float64))
    sy = RobustScaler().fit((np.asarray(y_fit, dtype=np.float64) - y_ref).reshape(-1, 1))
    return {"x_center": sx.center_.tolist(), "x_scale": sx.scale_.tolist(),
            "y_center": float(sy.center_[0]), "y_scale": float(sy.scale_[0]),
            "observation_reference_cm": y_ref,
            "fit_sample_count": len(y_fit), "x_fit_rows": int(np.prod(x_fit.shape[:2]))}


def transform_x(x, scaler):
    return ((np.asarray(x) - np.asarray(scaler["x_center"])) /
            np.asarray(scaler["x_scale"])).astype(np.float32)


def transform_y(y, scaler):
    return ((np.asarray(y) - scaler["observation_reference_cm"] - scaler["y_center"]) /
            scaler["y_scale"]).astype(np.float32)


def inverse_y(y, scaler):
    # Result already has observation_reference_cm removed by target construction.
    return np.asarray(y, dtype=np.float64).reshape(-1) * scaler["y_scale"] + scaler["y_center"]


def centered_validation(fit_output, val_output, val_targets, scaler):
    reference = float(np.mean(inverse_y(fit_output, scaler)))
    predictions = inverse_y(val_output, scaler) - reference
    targets = np.asarray(val_targets) - scaler["observation_reference_cm"]
    return float(np.mean((predictions - targets) ** 2)), reference


def array_interface_check(data, config):
    """One combined non-training check: units, irregular window, scaling, IDs."""
    x, apply_x = data["x_history"], data["x_application"]
    if x.shape != (78, 119, 12, 5) or apply_x.shape != (24, 119, 12, 5):
        raise AssertionError("Unexpected fixed experiment interface")
    if not np.isfinite(x).all() or not np.isfinite(apply_x).all():
        raise AssertionError("Nonfinite sequence features")
    if len(set(data["support_ids"].astype(str))) != 119:
        raise AssertionError("Region identity is not unique")
    if len(set(data["solution_ids"].astype(str))) != 102:
        raise AssertionError("Solution identity is not unique")
    if int(data["fit_mask"].sum()) != 66:
        raise AssertionError("Fit split changed")
    forcing = np.array([[[10., 100., 20., 10., 0., 611.2]]])
    derived, _ = daily_features(forcing)
    expected_rh = 100. / np.exp(17.67 * 5. / (5. + 243.5))
    np.testing.assert_allclose(derived[0, 0], [.01, 278.15, .02, 8640000., expected_rh], rtol=1e-7)
    days = np.arange(np.datetime64("2000-01-01"), np.datetime64("2001-02-01"))
    toy = np.broadcast_to(np.arange(len(days))[:, None, None], (len(days), 1, 5)).copy()
    window = {"solution_id": "toy_2001-01", "dates": ["2001-01-01", "2001-01-03"], "weights": [.25, .75]}
    seq, receipt = sequences(days, toy, [window])
    np.testing.assert_allclose(seq[0, 0, -1], .25 * 366 + .75 * 368)
    if receipt[0]["last_input_day"] != "2001-01-03":
        raise AssertionError("Window cutoff changed")
    fit = np.asarray(data["fit_mask"], dtype=bool)
    scaler = fit_scalers(x[fit, 0], data["targets_cm"][fit, 0])
    transformed = transform_y(data["targets_cm"][fit, 0], scaler)
    np.testing.assert_allclose(inverse_y(transformed, scaler),
                               data["targets_cm"][fit, 0] - scaler["observation_reference_cm"], atol=1e-5)
    return {"state": "PASS", "training_started": False, "regions": 119,
            "history_shape": list(x.shape), "application_shape": list(apply_x.shape),
            "checks": ["five_feature_units", "irregular_window_weighting_and_cutoff",
                       "chronological_split", "identity_and_finiteness", "fit_scaler_roundtrip"],
            "network_check_location": "HPC compute node before the first fit"}
