"""Single-attempt author-derived LSTMnoSIF, 119 independent regional fits.

Author mapping: 03_model_training.py model_config/get_datasets/training loop;
see code/ADAPTATION.md in the deployment for changes from the pinned source.
Run only on a Slurm compute node. Never reads application targets while fitting.
"""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import time

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from id25.graice_lstmnosif import (array_interface_check, build_model, centered_validation, digest,
                                  fit_scalers, inverse_y, save_npz, transform_x, transform_y, write_json)


def now():
    return datetime.now(timezone.utc).isoformat()


def optimizer_variables(optimizer):
    variables = optimizer.variables
    return list(variables() if callable(variables) else variables)


def save_last(path, network, optimizer, best_weights, metadata):
    arrays = {f"w_{i:03}": value for i, value in enumerate(network.get_weights())}
    arrays.update({f"o_{i:03}": var.numpy() for i, var in enumerate(optimizer_variables(optimizer))})
    arrays.update({f"b_{i:03}": value for i, value in enumerate(best_weights)})
    metadata = dict(metadata, weight_count=len(network.get_weights()),
                    optimizer_variable_count=len(optimizer_variables(optimizer)))
    arrays["metadata"] = np.array(json.dumps(metadata, allow_nan=False))
    save_npz(path, **arrays)


def restore_last(path, network, optimizer, fingerprint, region_id):
    with np.load(path, allow_pickle=False) as z:
        metadata = json.loads(str(z["metadata"]))
        if metadata["fingerprint"] != fingerprint or metadata["region_id"] != region_id:
            raise ValueError("Resume identity/config/input mismatch")
        network.set_weights([z[f"w_{i:03}"] for i in range(metadata["weight_count"])])
        variables = optimizer_variables(optimizer)
        if len(variables) != metadata["optimizer_variable_count"]:
            raise ValueError("Optimizer state shape changed")
        for i, variable in enumerate(variables):
            variable.assign(z[f"o_{i:03}"])
        best_weights = [z[f"b_{i:03}"].copy() for i in range(metadata["weight_count"])]
    return metadata, best_weights


def network_interface_check(tf, config, dataset, output):
    path = output / "interface_check"
    path.mkdir(exist_ok=True)
    tf.keras.backend.clear_session()
    tf.keras.utils.set_random_seed(config["seed"])
    model = build_model(config)
    fit = dataset["fit_mask"].astype(bool)
    scaler = fit_scalers(dataset["x_history"][fit, 0], dataset["targets_cm"][fit, 0])
    sample = transform_x(dataset["x_history"][:2, 0], scaler)
    expected = model(sample, training=False).numpy()
    layer = model.get_layer("author_lstm")
    if type(layer).__name__ != "LSTM" or layer.go_backwards or expected.shape != (2, 1):
        raise AssertionError("Unidirectional author model interface failed")
    model.save(path / "roundtrip.keras")
    loaded = tf.keras.models.load_model(path / "roundtrip.keras", compile=False)
    np.testing.assert_allclose(loaded(sample, training=False).numpy(), expected, atol=1e-7, rtol=1e-6)
    local = json.loads((output / "inputs/array_interface_check.json").read_text())
    if local["state"] != "PASS":
        raise ValueError("Prepared array interface check did not pass")
    receipt = {"state": "PASS", "array_check": local, "network": "unidirectional_LSTM_32_Dense16_Dense1",
               "network_output_shape": list(expected.shape), "parameter_count": model.count_params(),
               "save_load_inference": "PASS", "optimizer_steps": 0, "training_started": False,
               "tensorflow_version": tf.__version__, "job_id": os.environ["SLURM_JOB_ID"], "finished_at": now()}
    write_json(output / "interface_check.json", receipt)
    print(json.dumps({"event": "INTERFACE_CHECK_PASSED", "parameter_count": model.count_params()}), flush=True)
    del loaded, model
    tf.keras.backend.clear_session()


def fit_region(tf, config, data, column, output, fingerprint):
    region_id = str(data["support_ids"][column])
    run = output / "runs" / region_id
    run.mkdir(parents=True, exist_ok=True)
    report_path = run / "report.json"
    if report_path.exists():
        previous = json.loads(report_path.read_text())
        if previous["state"] == "COMPLETED" and previous["fingerprint"] == fingerprint:
            if not (run / "predictions.npz").exists() or not (run / "best.keras").exists():
                raise ValueError("Completed region is missing its saved artifacts")
            return previous
    x_all = data["x_history"][:, column]
    y_all = data["targets_cm"][:, column]
    fit = data["fit_mask"].astype(bool) & np.isfinite(y_all)
    val = (~data["fit_mask"].astype(bool)) & np.isfinite(y_all)
    if int(fit.sum()) < 2 or int(val.sum()) < 2:
        raise ValueError("Missing fixed fit or validation support: " + region_id)
    scaler = fit_scalers(x_all[fit], y_all[fit])
    scaler_path = run / "scalers.json"
    if scaler_path.exists():
        if json.loads(scaler_path.read_text()) != scaler:
            raise ValueError("Frozen regional scalers changed on resume")
    else:
        write_json(scaler_path, scaler)
    x_fit = transform_x(x_all[fit], scaler)
    y_fit = transform_y(y_all[fit], scaler)[:, None]
    x_val = transform_x(x_all[val], scaler)
    x_history = transform_x(x_all, scaler)
    x_app = transform_x(data["x_application"][:, column], scaler)
    tf.keras.backend.clear_session()
    tf.keras.utils.set_random_seed(config["seed"])
    network = build_model(config)
    optimizer = tf.keras.optimizers.Adam(learning_rate=config["learning_rate"])
    optimizer.build(network.trainable_variables)

    @tf.function(input_signature=[tf.TensorSpec([None, config["lag_months"], 5], tf.float32),
                                  tf.TensorSpec([None, 1], tf.float32)])
    def train_batch(x, y):
        with tf.GradientTape() as tape:
            residual = network(x, training=True) - y
            loss = tf.reduce_mean(tf.square(residual))
        gradients = tape.gradient(loss, network.trainable_variables)
        optimizer.apply_gradients(zip(gradients, network.trainable_variables))
        return loss

    @tf.function(input_signature=[tf.TensorSpec([None, config["lag_months"], 5], tf.float32)])
    def predict(x):
        return network(x, training=False)

    last_path = run / "last.npz"
    if last_path.exists():
        state, best_weights = restore_last(last_path, network, optimizer, fingerprint, region_id)
        print(json.dumps({"event": "RESUME_REGION", "region_id": region_id,
                          "last_epoch": state["epoch"], "wait": state["wait"]}), flush=True)
    else:
        state = {"region_id": region_id, "fingerprint": fingerprint, "epoch": 0,
                 "best_epoch": 0, "best_mse_cm2": None, "best_prediction_reference_cm": None,
                 "wait": 0, "state": "RUNNING", "seed": config["seed"], "started_at": now()}
        best_weights = network.get_weights()
    history_path = run / "metrics.jsonl"
    # A crash between atomic last.npz and append must not lose the final row.
    last_logged = 0
    if history_path.exists():
        lines = history_path.read_text().splitlines()
        if lines:
            last_logged = json.loads(lines[-1])["epoch"]
    if state["epoch"] > last_logged and "last_metrics" in state:
        with history_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(state["last_metrics"], allow_nan=False) + "\n")
    for epoch in range(state["epoch"] + 1, config["max_epochs"] + 1):
        if state["wait"] >= config["patience"]:
            break
        started = time.monotonic()
        # Epoch-indexed permutation reconstructs shuffling exactly after resume.
        rng = np.random.default_rng(np.random.SeedSequence([config["seed"], epoch]))
        permutation = rng.permutation(len(x_fit))
        total_loss = 0.
        for start in range(0, len(permutation), config["batch_size"]):
            ids = permutation[start:start + config["batch_size"]]
            loss = float(train_batch(x_fit[ids], y_fit[ids]).numpy())
            if not np.isfinite(loss):
                raise FloatingPointError("Nonfinite training loss: " + region_id)
            total_loss += loss * len(ids)
        fit_output = predict(x_fit).numpy()
        val_output = predict(x_val).numpy()
        val_mse, p_ref = centered_validation(fit_output, val_output, y_all[val], scaler)
        if not np.isfinite(val_mse):
            raise FloatingPointError("Nonfinite validation loss: " + region_id)
        improved = state["best_mse_cm2"] is None or val_mse < state["best_mse_cm2"]
        if improved:
            state.update(best_epoch=epoch, best_mse_cm2=val_mse, best_prediction_reference_cm=p_ref, wait=0)
            best_weights = network.get_weights()
        else:
            state["wait"] += 1
        metrics = {"epoch": epoch, "train_scaled_mse": total_loss / len(x_fit),
                   "val_ref_mse_cm2": val_mse, "best_val_ref_mse_cm2": state["best_mse_cm2"],
                   "best_epoch": state["best_epoch"], "wait": state["wait"],
                   "epoch_seconds": time.monotonic() - started, "updated_at": now()}
        state.update(epoch=epoch, last_metrics=metrics, updated_at=now(), job_id=os.environ["SLURM_JOB_ID"])
        # One atomic file contains optimizer, model, selected model and counters.
        # No early-stop or maximum-epoch budget is reset by resumption.
        save_last(last_path, network, optimizer, best_weights, state)
        with history_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(metrics, allow_nan=False) + "\n")
        if epoch == 1 or epoch % 10 == 0 or state["wait"] >= config["patience"]:
            progress = {"state": "RUNNING", "phase": "FIT", "region_id": region_id,
                        "region_number": column + 1, "region_count": config["region_count"],
                        "job_id": os.environ["SLURM_JOB_ID"], **metrics}
            write_json(output / "status.json", progress)
        if epoch == 1 or epoch % 100 == 0:
            print(json.dumps({"event": "REGION_EPOCH", "region_id": region_id, **metrics}), flush=True)
    network.set_weights(best_weights)
    prediction_reference = state["best_prediction_reference_cm"]
    history_pred = inverse_y(predict(x_history).numpy(), scaler) - prediction_reference
    application_pred = inverse_y(predict(x_app).numpy(), scaler) - prediction_reference
    best = {"region_id": region_id, "best_epoch": state["best_epoch"], "fingerprint": fingerprint,
            "prediction_reference_cm": prediction_reference, "scaler": scaler,
            "val_ref_mse_cm2": state["best_mse_cm2"]}
    save_npz(run / "best.npz", metadata=np.array(json.dumps(best)),
             **{f"w_{i:03}": value for i, value in enumerate(best_weights)})
    network.save(run / "best.keras")
    save_npz(run / "predictions.npz", history_anomaly_cm=history_pred,
             application_anomaly_cm=application_pred, prediction_reference_cm=np.array(prediction_reference),
             observation_reference_cm=np.array(scaler["observation_reference_cm"]))
    report = {"state": "COMPLETED", "region_id": region_id, "fingerprint": fingerprint,
              "epochs_completed": state["epoch"], "best_epoch": state["best_epoch"],
              "best_val_rmse_cm": state["best_mse_cm2"] ** .5,
              "prediction_reference_cm": prediction_reference,
              "observation_reference_cm": scaler["observation_reference_cm"],
              "fit_windows": int(fit.sum()), "validation_windows": int(val.sum()),
              "stop_reason": "PATIENCE" if state["wait"] >= config["patience"] else "MAX_EPOCHS",
              "wait": state["wait"], "seed": config["seed"], "attempt_count": 1,
              "job_id": os.environ["SLURM_JOB_ID"], "finished_at": now()}
    write_json(report_path, report)
    print(json.dumps({"event": "REGION_COMPLETED", **report}), flush=True)
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    if not os.environ.get("SLURM_JOB_ID"):
        raise RuntimeError("This entry point is restricted to a Slurm compute allocation")
    root = args.root.resolve()
    config = json.loads((root / "config.json").read_text())
    input_file = root / "inputs/sequences.npz"
    fingerprint = digest(root / "config.json") + ":" + digest(input_file)
    with np.load(input_file, allow_pickle=False) as z:
        data = {key: z[key] for key in z.files}
    if len(data["support_ids"]) != config["region_count"]:
        raise ValueError("Fixed 119-region cohort changed")
    # Dedicated CPU TensorFlow runtime; shared nh_final and GPUs are untouched.
    os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
    os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
    os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "0")
    import tensorflow as tf
    if tf.__version__ != config["tensorflow_version"]:
        raise RuntimeError("Unexpected TensorFlow version: " + tf.__version__)
    tf.config.threading.set_inter_op_parallelism_threads(1)
    tf.config.threading.set_intra_op_parallelism_threads(config["threads"])
    tf.config.experimental.enable_op_determinism()
    if not (root / "interface_check.json").exists():
        network_interface_check(tf, config, data, root)
    reports = []
    for column, region_id in enumerate(data["support_ids"].astype(str)):
        write_json(root / "status.json", {"state": "RUNNING", "phase": "REGION_START", "region_id": region_id,
                   "region_number": column + 1, "regions_completed": len(reports), "region_count": len(data["support_ids"]),
                   "job_id": os.environ["SLURM_JOB_ID"], "updated_at": now()})
        reports.append(fit_region(tf, config, data, column, root, fingerprint))
        write_json(root / "regional_completion.json", reports)
    history, application = [], []
    for region_id in data["support_ids"].astype(str):
        with np.load(root / "runs" / region_id / "predictions.npz", allow_pickle=False) as z:
            history.append(z["history_anomaly_cm"])
            application.append(z["application_anomaly_cm"])
    # All 119 candidates and references are fixed before evaluation targets load.
    save_npz(root / "predictions.npz", support_ids=data["support_ids"], solution_ids=data["solution_ids"],
             history_anomaly_cm=np.stack(history, axis=1), application_anomaly_cm=np.stack(application, axis=1),
             fit_mask=data["fit_mask"], selection_references_cm=np.array([r["prediction_reference_cm"] for r in reports]))
    write_json(root / "selection.json", {"state": "FROZEN", "selection_year": 2008, "region_count": 119,
               "fingerprint": fingerprint, "regions": reports, "frozen_at": now()})
    write_json(root / "status.json", {"state": "RUNNING", "phase": "COMPARISON", "regions_completed": 119,
               "job_id": os.environ["SLURM_JOB_ID"], "updated_at": now()})
    from compare_graice_lstmnosif import compare
    comparison = compare(root, data)
    report = {"state": "COMPLETED", "exp_id": config["exp_id"], "region_count": 119,
              "attempts_per_region": 1, "seed": config["seed"], "max_epochs_per_region": config["max_epochs"],
              "job_id": os.environ["SLURM_JOB_ID"], "fingerprint": fingerprint,
              "tensorflow_version": tf.__version__, "comparison": comparison,
              "finished_at": now(), "model_root": "runs", "prediction_file": "predictions.npz"}
    write_json(root / "report.json", report)
    write_json(root / "status.json", report)
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        if "--root" in sys.argv:
            root_arg = Path(sys.argv[sys.argv.index("--root") + 1])
            write_json(root_arg / "failure.json", {"state": "TECHNICAL_FAILURE", "type": type(error).__name__,
                       "message": str(error), "job_id": os.environ.get("SLURM_JOB_ID"), "updated_at": now()})
        raise
