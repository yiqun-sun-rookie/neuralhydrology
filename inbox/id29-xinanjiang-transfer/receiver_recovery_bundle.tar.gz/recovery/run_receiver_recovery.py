"""Recover exactly two pre-model input-gate failures in a new isolated root."""
from __future__ import annotations

import hashlib
import json
import os
import platform
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

ORIGINAL_ROOT = Path("/data1/home/sunyiq/id29_xinanjiang_transfer_20260907_v01")
RECOVERY_ROOT = Path("/data1/home/sunyiq/id29_xinanjiang_transfer_20260907_v01_recovery_01")
FAILED_BASINS = ["05120500", "09492400"]
ORIGINAL_SUMMARY_SHA256 = "0d01d9643f7725432a89dade8a4854b008f6f015baf0edc6c0f847f9d0264da9"
TRANSFER_SHA256 = "5f644f707c9b67eacf89562e7484cfc42f859dfcdad597b1eeb58584a99a2d04"
BUNDLE_MANIFEST_SHA256 = "59a8f8b50776086c5b1263e441cfc9cf80299b80feca24a60919d582d5d21545"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_exclusive(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def validate_original(root=ORIGINAL_ROOT):
    require(digest(root / "receiver/summary.json") == ORIGINAL_SUMMARY_SHA256, "failed summary changed")
    require(digest(root / "development/frozen_transfer.json") == TRANSFER_SHA256, "transfer changed")
    require(digest(root / "bundle/MANIFEST.json") == BUNDLE_MANIFEST_SHA256, "bundle identity changed")
    require((root / "receiver_job_id.txt").read_text().strip().split(";")[0] == "223833", "failed job identity")
    summary = read(root / "receiver/summary.json")
    require(summary["status"] == "failed" and summary["successful_arm_basins"] == 2864
            and summary["main_comparison"]["finite_pairs"] == 358, "failed-stage count identity")
    folders = sorted(p for p in (root / "receiver/evaluation").iterdir() if p.is_dir())
    require(len(folders) == 360, "original receiver basin directories")
    failed, successful = [], 0
    for folder in folders:
        result = read(folder / "result.json")
        if result["status"] == "success":
            require(len(result["arms"]) == 8 and all(a["status"] == "success" for a in result["arms"]),
                    "original successful basin is incomplete")
            successful += 1
        else:
            require(len(result.get("arms", [])) == 8
                    and all(a["status"] == "not_run" and a.get("error") ==
                            "basin stage failed: HPC raw input differs from local frozen source"
                            for a in result["arms"]), "failure is not the reviewed pre-model input gate")
            failed.append(folder.name)
    require(successful == 358 and failed == FAILED_BASINS, "unexpected recovery basin set")


def verify_manifest(root, manifest_name="MANIFEST.json"):
    manifest = read(root / manifest_name)
    for name, expected in manifest.items():
        require(digest(root / name) == expected, "recovery input changed: " + name)
    return manifest


def verify_original_inventory():
    manifest = read(RECOVERY_ROOT / "source_receiver_manifest.json")
    current = {p.relative_to(ORIGINAL_ROOT).as_posix(): digest(p)
               for p in sorted((ORIGINAL_ROOT / "receiver").rglob("*")) if p.is_file()}
    require(current == manifest, "original failed receiver evidence changed")


def recover_one(basin):
    from xinanjiang_transfer_noise import runner
    runner.DATA_ROOT = RECOVERY_ROOT / "inputs/camels_us"
    return runner.evaluate_basin((basin, str(RECOVERY_ROOT / "receiver"), "receiver"))


def main():
    require(os.environ.get("SLURM_JOB_ID") is not None, "recovery computation requires Slurm")
    require(RECOVERY_ROOT.exists() and not (RECOVERY_ROOT / "receiver").exists(), "recovery output already exists")
    validate_original()
    verify_manifest(RECOVERY_ROOT)
    contract = read(RECOVERY_ROOT / "recovery_contract.json")
    require(contract["experiment_id"] == "xinanjiang_receiver_recovery_20260908_v01"
            and contract["basins"] == FAILED_BASINS and contract["expected_successful_arms"] == 16
            and contract["maximum_cpus"] == 2 and contract["maximum_hours"] == 1,
            "recovery contract changed")
    require(digest(RECOVERY_ROOT / "development/frozen_transfer.json") == TRANSFER_SHA256,
            "recovery transfer copy changed")
    expected_raw = read(ORIGINAL_ROOT / "bundle/inputs/raw_input_hashes.json")
    recovered_raw = sorted(p for p in (RECOVERY_ROOT / "inputs/camels_us").rglob("*") if p.is_file())
    require(len(recovered_raw) == 5, "recovery raw-input file count")
    for path in recovered_raw:
        relative = path.relative_to(RECOVERY_ROOT / "inputs/camels_us").as_posix()
        require(expected_raw.get(relative) == digest(path), "recovery raw input is not frozen: " + relative)
    verify_original_inventory()
    from xinanjiang_transfer_noise.runner import verify_bundle
    require(verify_bundle() == BUNDLE_MANIFEST_SHA256, "complete frozen bundle verification")
    write_exclusive(RECOVERY_ROOT / "execution.json", {
        "job_id": os.environ["SLURM_JOB_ID"], "stage": "receiver_recovery_two_input_gate_failures",
        "workers": 2, "basins": FAILED_BASINS, "python": platform.python_version(),
        "source_job": "223833", "source_summary_sha256": ORIGINAL_SUMMARY_SHA256,
        "bundle_manifest_sha256": BUNDLE_MANIFEST_SHA256, "transfer_sha256": TRANSFER_SHA256,
    })
    with ProcessPoolExecutor(max_workers=2) as executor:
        results = list(executor.map(recover_one, FAILED_BASINS))
    results = sorted(results, key=lambda r: r["basin_id"])
    ok = (len(results) == 2 and [r["basin_id"] for r in results] == FAILED_BASINS
          and all(r["status"] == "success" and len(r["arms"]) == 8
                  and all(a["status"] == "success" for a in r["arms"]) for r in results))
    verify_original_inventory()
    summary = {"status": "success" if ok else "failed", "source_job": "223833",
               "recovered_basins": FAILED_BASINS, "successful_basins": sum(r["status"] == "success" for r in results),
               "successful_arms": sum(a["status"] == "success" for r in results for a in r.get("arms", [])),
               "results": results, "source_summary_sha256": ORIGINAL_SUMMARY_SHA256,
               "transfer_sha256": TRANSFER_SHA256, "bundle_manifest_sha256": BUNDLE_MANIFEST_SHA256}
    write_exclusive(RECOVERY_ROOT / "receiver/summary.json", summary)
    print(json.dumps(summary, sort_keys=True, allow_nan=False), flush=True)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
