"""Eight independent millimetre Xinanjiang states; legacy kernels stay read-only."""
from __future__ import annotations

import numpy as np

from xaj_global_pilot.xaj_numba import coupled_pdd_xaj_step_numba

PARAMETER_BOUNDS = {
    "pdd_factor_snow": (.5, 10.), "pdd_factor_ice": (1., 15.),
    "refreeze_snow": (0., .5), "refreeze_ice": (0., .5),
    "temp_snow": (-3., 1.), "temp_rain": (.5, 4.),
    "kc": (.3, 1.8), "b": (.05, 4.), "wum": (2., 120.),
    "wlm": (5., 200.), "wdm": (2., 150.), "sm": (2., 120.),
    "imp": (.001, .35), "c": (.01, .35), "ex": (.1, 4.),
    "ki": (.01, .55), "kg": (.01, .55), "cs": (.1, .9),
    "ci": (.3, .95), "cg": (.5, .998),
}
STATE_NAMES = ("snow", "WU", "WL", "WD", "S", "QS", "QI", "QG")
ACTIVE = np.array([0, 4, 5, 6, 7, 8, 9, 10])


def validate_parameters(parameters, *, allow_reversed_thresholds=False):
    if set(parameters) != set(PARAMETER_BOUNDS):
        raise ValueError("expected exactly the frozen 20 hydrological parameters")
    for k, (low, high) in PARAMETER_BOUNDS.items():
        v = parameters[k]
        if not np.isfinite(v) or not low <= v <= high:
            raise ValueError(f"parameter {k} outside v1 bounds")
    if parameters["ki"] + parameters["kg"] > .7 + 1e-12:
        raise ValueError("ki + kg exceeds 0.7")
    if not allow_reversed_thresholds and parameters["temp_snow"] >= parameters["temp_rain"]:
        raise ValueError("rain-snow thresholds must be strictly ordered")


def compact_state(legacy):
    x = np.asarray(legacy, dtype=float).reshape(-1)
    if x.shape != (11,) or not np.isfinite(x).all():
        raise ValueError("legacy state must contain eleven finite entries")
    if x[1] != 0:
        raise ValueError("nonzero glacier ice is outside the frozen no-ice protocol")
    if not np.isclose(x[3], x[4:7].sum(), atol=1e-9, rtol=1e-10):
        raise ValueError("redundant total soil water disagrees with its layers")
    return x[ACTIVE].copy()


def expand_state(compact, temperature=0.):
    x = np.asarray(compact, dtype=float)
    if x.shape != (8,) or not np.isfinite(x).all() or not np.isfinite(temperature):
        raise ValueError("compact state must contain eight finite entries")
    full = np.zeros(11)
    full[ACTIVE] = x
    full[2] = temperature
    full[3] = x[1:4].sum()
    return full


class Adapter:
    def __init__(self, parameters):
        validate_parameters(parameters)
        self.p = dict(parameters)
        p = self.p
        wm = p["wum"] + p["wlm"] + p["wdm"]
        self.wmm = wm * (1 + p["b"]) / (1 - p["imp"])
        self.ms = p["sm"] * (1 + p["ex"])
        self.xp = tuple(np.array([v], dtype=float) for v in (
            p["kc"], p["ki"], p["kg"], p["cs"], p["ci"], p["cg"],
            p["wum"], p["wlm"], p["wdm"], p["sm"], p["imp"], p["c"],
            p["b"], p["ex"], 1., self.wmm, self.ms))
        self.pp = tuple(np.array([p[k]], dtype=float) for k in (
            "pdd_factor_snow", "pdd_factor_ice", "refreeze_snow", "refreeze_ice"))
        self.limits = np.array([np.inf, p["wum"], p["wlm"], p["wdm"], p["sm"],
                                np.inf, np.inf, np.inf])
        self._diagnostics = {}
        self.forcing = None

    def initial_state(self):
        return np.array([0., self.p["wum"]*.5, self.p["wlm"]*.5,
                         self.p["wdm"]*.5, self.p["sm"]*.5, 0., 0., 0.])

    def project(self, state, stage="posterior"):
        x = np.asarray(state, dtype=float)
        if x.shape != (8,) or not np.isfinite(x).all():
            raise ValueError("nonfinite or incorrectly shaped state before projection")
        projected = np.clip(x, 0., self.limits)
        delta = projected - x
        d = self._diagnostics.setdefault(stage, {"calls": 0, "changed_calls": 0,
            "signed_correction": np.zeros(8), "absolute_correction": np.zeros(8),
            "changed_by_dimension": np.zeros(8, dtype=int)})
        d["calls"] += 1
        d["changed_calls"] += int(np.any(delta != 0))
        d["signed_correction"] += delta
        d["absolute_correction"] += abs(delta)
        d["changed_by_dimension"] += delta != 0
        return projected

    def diagnostics(self):
        return {stage: {k: v.tolist() if isinstance(v, np.ndarray) else v for k, v in d.items()}
                for stage, d in self._diagnostics.items()}

    def set_forcing(self, rain, pet, temperature):
        if not np.isfinite([rain, pet, temperature]).all() or rain < 0 or pet < 0:
            raise ValueError("forcing must be finite with nonnegative rain and PET")
        self.forcing = (float(rain), float(pet), float(temperature))

    def __call__(self, state):
        if self.forcing is None:
            raise RuntimeError("set forcing before transition")
        rain, pet, temperature = self.forcing
        p = self.p
        s = self.project(state, "transition_sigma")
        fraction = np.clip((p["temp_rain"] - temperature) /
                           (p["temp_rain"] - p["temp_snow"] + 1e-12), 0., 1.)
        result, _ = coupled_pdd_xaj_step_numba(
            expand_state(s, temperature)[None, :], np.array([temperature]),
            np.array([rain * (1. - fraction)]), np.array([rain * fraction]),
            np.array([pet]), self.pp, self.xp)
        return compact_state(result)

    def observation(self, state):
        # Explicit observation-domain projection; do not modify sigma state itself.
        return float(self.project(state, "observation_sigma")[5:].sum())

    def simulate(self, rain, pet, temperature, initial=None):
        s = self.initial_state() if initial is None else np.asarray(initial).copy()
        states = np.empty((len(rain), 8))
        for i in range(len(rain)):
            self.set_forcing(rain[i], pet[i], temperature[i])
            s = self(s)
            states[i] = s
        return states, np.maximum(states[:, 5:].sum(axis=1), 0.)

    def reference_step(self, state, rain, pet, temperature):
        from xaj_global_pilot.pdd_core import pdd_step
        from xaj_global_pilot.xaj_core import xaj_step_vec
        p = {k: np.array([v]) for k, v in self.p.items()}
        p.update(wm=np.array([self.p["wum"] + self.p["wlm"] + self.p["wdm"]]),
                 wmm=np.array([self.wmm]), ms=np.array([self.ms]), uf=np.ones(1))
        full = expand_state(state, temperature)
        snow_m = full[:3].copy()[None, :]
        snow_m[:, :2] /= 1000.
        next_snow, runoff_m = pdd_step(snow_m, np.array([temperature]), np.array([rain]), p)
        hydro = xaj_step_vec(full[3:][None, :], runoff_m * 1000., np.array([pet]), p)
        result = np.concatenate((next_snow[0] * np.array([1000., 1000., 1.]), hydro[0]))
        return compact_state(result)
