"""Validate immutable inputs and create a new, non-overwriting input snapshot."""
from __future__ import annotations

import csv
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUTPUT = ROOT / "results/29_transferable_filter_noise/xinanjiang_v01"
CALIBRATION = Path("G:/github/pycharm/projects/neuralhydrology/results/"
                   "10_global_conceptual_model_benchmark/camels_us_531_repro_v01/summary/"
                   "xaj_pdd_cma_FINAL_oudin_warmup_local_full.csv")
EXPECTED_CALIBRATION = "2b183390ea9f5fdaf5b6c17df5205a08035e30a572bb00ed17f362191e301ad1"
EXPECTED_METADATA = "0bdf59730c29b3164c211927c5141d12a369b9e750c2f54d18258e25dbeeb152"
OLD = ROOT / "results/23_camels_switch_confirmation"
PROTECTED = [
    "src/camels_switch_confirmation/run_online_noise_pilot.py",
    "src/hydroagent/data_loading.py", "src/scl_hydro/hbv_lite_cma_calibrate.py",
    "src/scl_hydro/hbv_lite_numpy.py",
    "docs/plans/2026-09-03-parameter-axis-probe-stage0-and-0.5-results-v01.md",
    "docs/plans/2026-09-03-parameter-axis-probe-stage1-context-reset-handoff-v01.md",
    "docs/plans/2026-09-03-parameter-axis-stage1-filter-arms-prereg-draft-v01.md",
    "docs/plans/2026-09-03-parameter-axis-stage1-filter-arms-prereg-draft-v02.md",
    "src/camels_switch_confirmation/parameter_axis_openloop_probe.py",
    "src/camels_switch_confirmation/scripts/run_parameter_axis_probe.py",
    "test/test_parameter_axis_probe.py",
]


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def read_csv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_json(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def prepare():
    # Validate first, write second. Incomplete snapshots are retained and never reused.
    from .adapter import validate_parameters, compact_state, PARAMETER_BOUNDS
    metadata_path = CALIBRATION.with_suffix(".metadata.json")
    require(digest(CALIBRATION) == EXPECTED_CALIBRATION, "calibration hash mismatch")
    require(digest(metadata_path) == EXPECTED_METADATA, "calibration metadata hash mismatch")
    sources = {
        "calibration": CALIBRATION, "calibration_metadata": metadata_path,
        "development": OLD / "noise_axis_step2_learned_q_20260827_local/evaluation_per_basin.csv",
        "receivers": OLD / "noise_axis_391_global_card_confirmation_20260901_local/frozen_basin_list.csv",
        "observation_error": OLD / "g1_precheck_v01/g1_precheck.csv",
    }
    dev = sorted(r["basin_id"].zfill(8) for r in read_csv(sources["development"]))
    rec = sorted(r["basin_id"].zfill(8) for r in read_csv(sources["receivers"])
                 if r["included"].lower() == "true")
    require(len(set(dev)) == len(dev) == 52 and len(set(rec)) == len(rec) == 391, "original basin count")
    require(not set(dev) & set(rec), "overlapping basin roles")
    sigmas = {r["basin_id"].zfill(8): float(r["sigma_obs"])
              for r in read_csv(sources["observation_error"])}
    audit, contexts, invalid = [], {}, set()
    rows = read_csv(sources["calibration"])
    require(len(rows) == len({r["basin_id"].zfill(8) for r in rows}) == 531, "calibration count")
    import math
    for row in rows:
        basin = row["basin_id"].zfill(8)
        params = {k: float(row[f"p_{k}"]) for k in PARAMETER_BOUNDS}
        require(row["run_status"] == "success", f"unsuccessful calibration {basin}")
        validate_parameters(params, allow_reversed_thresholds=True)
        legacy = [float(row["state_" + s]) for s in
                  ("snow", "ice", "last_temp", "W", "WU", "WL", "WD", "S", "QS", "QI", "QG")]
        compact_state(legacy)  # Checks finite, zero ice and deterministic soil total.
        valid = params["temp_snow"] < params["temp_rain"]
        if not valid:
            invalid.add(basin)
        role = "development" if basin in dev else "receiver" if basin in rec else "outside"
        audit.append({"basin_id": basin, "original_role": role, "included": valid and role != "outside",
                      "temp_snow": params["temp_snow"], "temp_rain": params["temp_rain"],
                      "physical_threshold_valid": valid,
                      "exclusion_reason": "" if valid else "temp_snow_greater_than_or_equal_to_temp_rain"})
        if valid and role != "outside":
            require(math.isfinite(sigmas[basin]) and sigmas[basin] > 0, f"invalid observation error {basin}")
            contexts[basin] = {"parameters": params, "sigma_obs": sigmas[basin], "role": role}
    require(len(invalid) == 36 and len(set(dev) & invalid) == 3 and len(set(rec) & invalid) == 31,
            "unexpected physical exclusion counts")
    admitted_dev, admitted_rec = sorted(set(dev) - invalid), sorted(set(rec) - invalid)
    require(len(admitted_dev) == 49 and len(admitted_rec) == 360 and len(contexts) == 409,
            "unexpected admitted basin counts")
    inputs = OUTPUT / "inputs"
    inputs.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(sources["calibration"], inputs / "calibration.csv")
    shutil.copyfile(metadata_path, inputs / "calibration.metadata.json")
    write_json(inputs / "development_basins.json", admitted_dev)
    write_json(inputs / "receiver_basins.json", admitted_rec)
    write_json(inputs / "contexts.json", contexts)
    write_json(inputs / "qualification_531.json", audit)
    write_json(inputs / "source_hashes.json", {k: {"path": str(p), "sha256": digest(p)}
                                                for k, p in sources.items()})
    write_json(inputs / "protected_hashes.json", {p: digest(ROOT / p) for p in PROTECTED})
    from .data import basin_files
    data_root = ROOT / "data/camels_us"
    raw_files = {p.relative_to(data_root).as_posix(): p
                 for basin in contexts for p in basin_files(data_root, basin).values()}
    write_json(inputs / "raw_input_hashes.json", {p: digest(v) for p, v in sorted(raw_files.items())})
    write_json(inputs / "manifest.json", {p.name: digest(p) for p in sorted(inputs.iterdir())})
    print(json.dumps({"prepared": str(inputs), "development": 49, "receivers": 360,
                      "excluded_target_basins": 34}))


if __name__ == "__main__":
    prepare()
