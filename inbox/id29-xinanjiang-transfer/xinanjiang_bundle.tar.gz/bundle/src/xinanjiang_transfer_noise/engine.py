"""Frozen one-step-prior filtering and finite-budget noise learning."""
from __future__ import annotations

import importlib.util
import json
import sys
import time
from pathlib import Path

import numpy as np

from .adapter import Adapter

PROTOCOL = json.loads(Path(__file__).with_name("protocol.json").read_text(encoding="utf-8"))
# Do not import hbv_joint_uncertainty.__init__: it imports protected HBV files.
_path = Path(__file__).resolve().parents[1] / "hbv_joint_uncertainty/sigma_filter.py"
_spec = importlib.util.spec_from_file_location("xinanjiang_frozen_sigma_filter", _path)
_module = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = _module
_spec.loader.exec_module(_module)
ModifiedUnscentedFilter = _module.ModifiedUnscentedFilter


def anchors():
    out = [("small", np.full(8, .001)), ("uniform", np.full(8, .02)),
           ("large", np.full(8, .2))]
    for name, indices in [("snow", [0]), ("soil", [1, 2, 3]), ("free_water", [4]),
                          ("surface", [5]), ("slow_flow", [6, 7])]:
        v = np.full(8, .001)
        v[indices] = .2
        out.append((name, v))
    return out


def amplitudes(states, days):
    x = np.asarray(states, dtype=float)[:days]
    if x.shape != (days, 8) or not np.isfinite(x).all():
        raise ValueError("invalid amplitude prefix")
    return np.maximum(np.sqrt(np.mean(x*x, axis=0)), PROTOCOL["amplitude_floor"])


def log_pool(rows, exclude=None):
    values = np.array([v for k, v in sorted(rows.items()) if k != exclude])
    if values.ndim != 2 or values.shape[1] != 8 or not np.isfinite(values).all() or (values <= 0).any():
        raise ValueError("pool requires nonempty finite positive eight-vectors")
    return np.exp(np.median(np.log(values), axis=0))


def filter_run(parameters, rain, pet, temp, observations, sigma_obs, std):
    std = np.asarray(std, dtype=float)
    if std.shape != (8,) or not np.isfinite(std).all() or (std <= 0).any():
        raise ValueError("invalid process standard deviations")
    a = Adapter(parameters)
    s = a.initial_state()
    p0 = np.diag((PROTOCOL["initial_covariance_fraction"] * np.maximum(abs(s), 1.))**2)
    f = ModifiedUnscentedFilter(s, p0, a, a.observation, np.diag(std**2), [[sigma_obs**2]],
                               state_projector=a.project, alpha=PROTOCOL["alpha"],
                               beta=PROTOCOL["beta"], kappa=PROTOCOL["kappa"])
    prior, variance = np.empty(len(rain)), np.empty(len(rain))
    started = time.perf_counter()
    for day in range(len(rain)):
        a.set_forcing(rain[day], pet[day], temp[day])
        if not np.isfinite(observations[day]):
            raise ValueError("real-data filter requires complete finite observations")
        result = f.step(float(observations[day]))
        prior[day] = result.prior_observation[0]
        variance[day] = result.innovation_covariance[0, 0]
    return {"prior": prior, "variance": variance, "projection": a.diagnostics(),
            "elapsed_seconds": time.perf_counter() - started}


def score(prior, observed, start):
    y, q = np.asarray(observed)[start:], np.asarray(prior)[start:]
    if len(y) == 0 or len(y) != len(q) or not np.isfinite(y).all() or not np.isfinite(q).all():
        raise ValueError("score requires finite paired series")
    denominator = float(np.sum((y-y.mean())**2))
    if not np.isfinite(denominator) or denominator <= 0:
        raise ValueError("constant observations cannot be scored by Nash efficiency")
    value = 1. - float(np.sum((q-y)**2)) / denominator
    if not np.isfinite(value):
        raise ValueError("nonfinite efficiency coefficient")
    return value


def search_anchor(task, amplitude, basin, index, record_candidate):
    import cma
    name, start = anchors()[index]
    es = cma.CMAEvolutionStrategy(np.log(start), PROTOCOL["search_sigma"], {
        "popsize": PROTOCOL["population"], "seed": (int(basin)*100 + index) % (2**31),
        "verbose": -9, "verb_disp": 0, "verb_log": 0,
    })
    best, best_rho, failures, count, max_seconds = np.inf, None, 0, 0, 0.
    n = PROTOCOL["training_days"]
    for generation in range(PROTOCOL["generations"]):
        candidates, fitness = es.ask(), []
        if len(candidates) != PROTOCOL["population"]:
            raise RuntimeError("search population changed")
        for j, candidate in enumerate(candidates):
            rho = np.exp(np.clip(candidate, *np.log(PROTOCOL["ratio_bounds"])))
            error, started = None, time.perf_counter()
            try:
                r = filter_run(task["parameters"], task["rain"][:n], task["pet"][:n],
                               task["temp"][:n], task["obs"][:n], task["sigma_obs"], rho*amplitude)
                diff = r["prior"][PROTOCOL["burn_in_days"]:] - task["obs"][PROTOCOL["burn_in_days"]:n]
                value = float(np.mean(diff**2))
                if not np.isfinite(value) or value >= PROTOCOL["failure_penalty"]:
                    raise ValueError("nonfinite or unreasonably large training objective")
            except (ValueError, np.linalg.LinAlgError, FloatingPointError) as exc:
                error, value = f"{type(exc).__name__}: {exc}", PROTOCOL["failure_penalty"]
                failures += 1
            elapsed = time.perf_counter() - started
            record_candidate({"anchor": index, "generation": generation, "candidate": j,
                              "rho": rho.tolist(), "objective": value, "error": error,
                              "elapsed_seconds": elapsed})
            max_seconds = max(max_seconds, time.perf_counter() - started)
            fitness.append(value)
            count += 1
            if error is None and value < best:
                best, best_rho = value, rho.copy()
        es.tell(candidates, fitness)
    if best_rho is None:
        raise ValueError(f"no finite candidate for {basin} anchor {index}")
    return {"anchor": index, "name": name, "rho": best_rho.tolist(), "objective": best,
            "evaluations": count, "failed_candidates": failures, "max_candidate_seconds": max_seconds}
