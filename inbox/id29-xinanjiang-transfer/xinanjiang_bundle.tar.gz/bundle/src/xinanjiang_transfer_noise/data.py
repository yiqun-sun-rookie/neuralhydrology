"""Window-strict read-only CAMELS reader; no import of another session's loader."""
from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np
import pandas as pd


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def basin_files(data_root, basin):
    root = Path(data_root)
    found = {}
    for kind, subdir, name in [
        ("forcing", "basin_mean_forcing/maurer", f"{basin}_lump_maurer_forcing_leap.txt"),
        ("streamflow", "usgs_streamflow", f"{basin}_streamflow_qc.txt"),
    ]:
        matches = sorted((root / subdir).glob("*/" + name))
        if len(matches) != 1:
            raise ValueError(f"expected one {kind} file for {basin}, got {len(matches)}")
        found[kind] = matches[0]
    found["topography"] = root / "camels_attributes_v2.0/camels_topo.txt"
    return found


def load_window(data_root, basin, start, days):
    files = basin_files(data_root, basin)
    before = {k: sha256(p) for k, p in files.items()}
    dates = pd.date_range(start, periods=days, freq="D")
    with files["forcing"].open(encoding="utf-8") as stream:
        for _ in range(3):
            next(stream)
        names = next(stream).split()
    if "Year" not in names:
        names = ["Year", "Mnth", "Day", "Hr"] + names
    raw = pd.read_csv(files["forcing"], skiprows=4, header=None, names=names, sep=r"\s+")
    raw.index = pd.to_datetime(raw[["Year", "Mnth", "Day"]].rename(
        columns={"Year": "year", "Mnth": "month", "Day": "day"}))
    if not raw.index.is_unique:
        raise ValueError("duplicate forcing dates")
    raw = raw.reindex(dates)

    def column(prefix):
        names = [c for c in raw.columns if c.lower().startswith(prefix)]
        if len(names) != 1:
            raise ValueError(f"ambiguous forcing column {prefix}")
        return raw[names[0]].to_numpy(dtype=float)

    rain, tmax, tmin = column("prcp"), column("tmax"), column("tmin")
    if not np.isfinite([rain, tmax, tmin]).all() or (rain < 0).any():
        raise ValueError("invalid raw precipitation or temperature")
    temp = (tmax + tmin) / 2.
    radiation, daylight = column("srad"), column("dayl")
    if (not np.isfinite([radiation, daylight]).all() or (radiation < 0).any()
            or (daylight < 0).any() or (daylight > 86400).any()):
        raise ValueError("invalid shortwave radiation or daylight duration")
    pet = np.where(temp > -5., radiation*daylight/1e6*(temp+5.)/245., 0.)
    pet = np.maximum(pet, 0.)
    topo = pd.read_csv(files["topography"], sep=";", dtype={"gauge_id": str})
    area = topo.loc[topo["gauge_id"].str.zfill(8) == basin, "area_gages2"].to_numpy(dtype=float)
    if len(area) != 1 or not np.isfinite(area[0]) or area[0] <= 0:
        raise ValueError("invalid basin area")
    first, last = dates[0].date(), dates[-1].date()
    observed = {}
    from datetime import date
    with files["streamflow"].open(encoding="utf-8") as stream:
        for line in stream:
            fields = line.split()
            if not fields:
                continue
            stamp = date(int(fields[1]), int(fields[2]), int(fields[3]))
            if stamp < first or stamp > last:
                continue  # Do not convert discharge outside the requested window.
            if stamp in observed:
                raise ValueError("duplicate observation date")
            observed[stamp] = float(fields[4]) * (2.4466 / area[0])
    obs = np.array([observed.get(d.date(), np.nan) for d in dates])
    if not np.isfinite(np.array([rain, pet, temp, obs])).all():
        raise ValueError(f"missing or nonfinite input for {basin}")
    if (rain < 0).any() or (pet < 0).any() or (obs < 0).any():
        raise ValueError(f"negative precipitation, PET or observed discharge for {basin}")
    after = {k: sha256(p) for k, p in files.items()}
    if before != after:
        raise ValueError("raw inputs changed during read")
    return {"rain": rain, "pet": pet, "temp": temp, "obs": obs,
            "dates": dates.strftime("%Y-%m-%d").to_numpy(dtype="U10"),
            "raw_hashes": {k: {"relative_path": p.relative_to(data_root).as_posix(), "sha256": before[k]}
                           for k, p in files.items()}}
