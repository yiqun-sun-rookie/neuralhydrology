"""Isolated, frozen second-model replication; no legacy package side effects."""
