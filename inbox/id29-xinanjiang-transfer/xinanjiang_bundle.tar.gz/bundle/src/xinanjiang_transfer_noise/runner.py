"""Gated HPC stages. Every execution/output is immutable; no implicit retries."""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import platform
import time
import traceback
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np

from .adapter import Adapter, compact_state
from .data import load_window, sha256
from .engine import PROTOCOL, amplitudes, anchors, filter_run, log_pool, score, search_anchor
from .prepare import read_csv, write_json

BUNDLE = Path(__file__).resolve().parents[2]
INPUTS = BUNDLE / "inputs"
DATA_ROOT = Path("/data1/home/sunyiq/neuralhydrology/data/camels_us")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save_npz(path, **values):
    with Path(path).open("xb") as stream:
        np.savez_compressed(stream, **values)


def verify_bundle():
    for name, expected in read_json(BUNDLE / "MANIFEST.json").items():
        if sha256(BUNDLE / name) != expected:
            raise ValueError(f"bundle hash mismatch: {name}")
    for name, expected in read_json(INPUTS / "manifest.json").items():
        if sha256(INPUTS / name) != expected:
            raise ValueError(f"input hash mismatch: {name}")
    return sha256(BUNDLE / "MANIFEST.json")


def task_for(basin, role):
    context = read_json(INPUTS / "contexts.json")[basin]
    if context["role"] != role:
        raise ValueError("basin role mismatch")
    prefix = "development" if role == "development" else "receiver"
    task = load_window(DATA_ROOT, basin, PROTOCOL[prefix + "_start"], PROTOCOL[prefix + "_days"])
    expected = read_json(INPUTS / "raw_input_hashes.json")
    for item in task["raw_hashes"].values():
        if expected[item["relative_path"]] != item["sha256"]:
            raise ValueError("HPC raw input differs from local frozen source")
    task.update(context)
    states, prior = Adapter(task["parameters"]).simulate(task["rain"], task["pet"], task["temp"])
    count = PROTOCOL["training_days"] if role == "development" else PROTOCOL["adaptation_days"]
    task.update(amplitude=amplitudes(states, count), open_loop=prior)
    return task


def persist_arm(directory, name, task, std, start):
    started = time.perf_counter()
    try:
        result = filter_run(task["parameters"], task["rain"], task["pet"], task["temp"],
                            task["obs"], task["sigma_obs"], std)
        nse = score(result["prior"], task["obs"], start)
        save_npz(directory / (name + ".npz"), prior=result["prior"], variance=result["variance"],
                 observations=task["obs"], dates=task["dates"])
        record = {"status": "success", "arm": name, "nse": nse, "std": np.asarray(std).tolist(),
                  "projection": result["projection"], "elapsed_seconds": time.perf_counter()-started}
    except Exception as exc:
        record = {"status": "failed", "arm": name, "error": f"{type(exc).__name__}: {exc}",
                  "traceback": traceback.format_exc(), "elapsed_seconds": time.perf_counter()-started}
    write_json(directory / (name + ".json"), record)
    return record


def persist_context(directory, task):
    write_json(directory / "context.json", {"amplitude": task["amplitude"].tolist(),
                "parameters": task["parameters"], "sigma_obs": task["sigma_obs"],
                "raw_hashes": task["raw_hashes"]})


def candidate_sink(path):
    stream = path.open("x", encoding="utf-8", newline="\n")

    def record(value):
        stream.write(json.dumps(value, allow_nan=False, sort_keys=True) + "\n")
        stream.flush()
    return stream, record


def pilot_basin(job):
    basin, stage = job
    directory = Path(stage) / basin
    directory.mkdir(exist_ok=False)
    started = time.perf_counter()
    try:
        task = task_for(basin, "development")
        persist_context(directory, task)
        context_seconds = time.perf_counter() - started
        a = Adapter(task["parameters"])
        expected = a.initial_state()
        actual_states, actual_q = a.simulate(task["rain"], task["pet"], task["temp"])
        max_error = 0.
        for day in range(len(task["rain"])):
            expected = a.reference_step(expected, task["rain"][day], task["pet"][day], task["temp"][day])
            np.testing.assert_allclose(actual_states[day], expected, atol=1e-9, rtol=1e-10)
            max_error = max(max_error, float(np.max(abs(actual_states[day] - expected))))
        # Historical checkpoint is used ONLY for its registered historical date.
        old_row = next(r for r in read_csv(INPUTS / "calibration.csv") if r["basin_id"].zfill(8) == basin)
        old_state = [float(old_row["state_" + s]) for s in
                     ("snow", "ice", "last_temp", "W", "WU", "WL", "WD", "S", "QS", "QI", "QG")]
        import pandas as pd
        n_old = (pd.Timestamp("1999-09-30") - pd.Timestamp("1989-10-01")).days + 1
        old = load_window(DATA_ROOT, basin, "1989-10-01", n_old)
        _, old_q = Adapter(task["parameters"]).simulate(old["rain"], old["pet"], old["temp"],
                                                      initial=compact_state(old_state))
        old_nse = score(old_q, old["obs"], 0)
        if abs(old_nse - float(old_row["nse"])) > 5e-6:
            raise ValueError(f"historical calibration replay mismatch {old_nse} vs {old_row['nse']}")
        fixed = [persist_arm(directory, f"anchor_{i}", task, rho*task["amplitude"], 840)
                 for i, (_, rho) in enumerate(anchors())]
        if not all(r["status"] == "success" for r in fixed):
            raise ValueError("technical fixed-anchor filtering failure")
        stream, sink = candidate_sink(directory / "candidates.jsonl")
        search_start = time.perf_counter()
        try:
            endpoint = search_anchor(task, task["amplitude"], basin, 0, sink)
        finally:
            stream.close()
        search_seconds = time.perf_counter() - search_start
        if endpoint["evaluations"] != 96 or endpoint["failed_candidates"]/96 > .01:
            raise ValueError("technical search count/failure gate")
        candidates = [json.loads(line) for line in (directory / "candidates.jsonl").read_text().splitlines()]
        overhead_per_candidate = max(0., search_seconds-sum(r["elapsed_seconds"] for r in candidates))/96
        record = {"status": "success", "basin_id": basin, "parity_max_absolute": max_error,
                  "historical_nse_replay": old_nse, "historical_nse_registered": float(old_row["nse"]),
                  "endpoint": endpoint, "context_seconds": context_seconds,
                  "max_candidate_seconds": endpoint["max_candidate_seconds"]+overhead_per_candidate,
                  "max_1260_seconds": max(r["elapsed_seconds"] for r in fixed)}
    except Exception as exc:
        record = {"status": "failed", "basin_id": basin, "error": str(exc), "traceback": traceback.format_exc()}
    write_json(directory / "result.json", record)
    return record


def learn_basin(job):
    basin, stage = job
    directory = Path(stage) / "learning" / basin
    directory.mkdir(parents=True, exist_ok=False)
    try:
        task = task_for(basin, "development")
        persist_context(directory, task)
        stream, sink = candidate_sink(directory / "candidates.jsonl")
        try:
            endpoints = [search_anchor(task, task["amplitude"], basin, i, sink) for i in range(8)]
        finally:
            stream.close()
        winner = min(endpoints, key=lambda r: (r["objective"], r["anchor"]))
        result = {"status": "success", "basin_id": basin, "endpoints": endpoints,
                  "winner": winner, "amplitude": task["amplitude"].tolist(),
                  "evaluations": sum(r["evaluations"] for r in endpoints),
                  "failed_candidates": sum(r["failed_candidates"] for r in endpoints)}
    except Exception as exc:
        result = {"status": "failed", "basin_id": basin, "error": str(exc), "traceback": traceback.format_exc()}
    write_json(directory / "result.json", result)
    return result


def evaluate_basin(job):
    basin, stage, role = job
    stage = Path(stage)
    directory = stage / "evaluation" / basin
    directory.mkdir(parents=True, exist_ok=False)
    records = []
    try:
        task = task_for(basin, role)
        persist_context(directory, task)
        start = 840 if role == "development" else 1735
        choices = [(f"uniform_{i}", np.full(8, rho)*task["amplitude"])
                   for i, rho in enumerate(PROTOCOL["uniform_ratios"])]
        if role == "development":
            learned = read_json(stage / "learned.json")
            own = learned[basin]
            choices.extend((f"fixed_anchor_{i}", rho*task["amplitude"])
                           for i, (_, rho) in enumerate(anchors()))
            choices.extend((f"learned_anchor_{i}", np.array(e["rho"])*task["amplitude"])
                           for i, e in enumerate(own["endpoints"]))
            ratios = {b: r["winner"]["rho"] for b, r in learned.items()}
            absolute = {b: np.array(r["winner"]["rho"])*r["amplitude"] for b, r in learned.items()}
            choices += [("pooled_ratio", log_pool(ratios, basin)*task["amplitude"]),
                        ("pooled_absolute", log_pool(absolute, basin))]
        else:
            frozen = read_json(stage.parent / "development" / "frozen_transfer.json")
            choices += [("pooled_ratio", np.array(frozen["ratio"])*task["amplitude"]),
                        ("pooled_absolute", np.array(frozen["absolute_std"]))]
        for name, std in choices:
            records.append(persist_arm(directory, name, task, std, start))
        open_record = {"arm": "open_loop", "status": "success", "nse": score(task["open_loop"], task["obs"], start)}
        save_npz(directory / "open_loop.npz", prior=task["open_loop"], observations=task["obs"], dates=task["dates"])
        write_json(directory / "open_loop.json", open_record)
        records.append(open_record)
        result = {"status": "success" if all(r["status"] == "success" for r in records) else "failed",
                  "basin_id": basin, "arms": records}
    except Exception as exc:
        seen = {r["arm"] for r in records}
        for name in expected_arms(role):
            if name not in seen:
                path = directory / (name + ".json")
                if path.exists():
                    records.append(read_json(path))
                else:
                    record = {"arm": name, "status": "not_run", "error": f"basin stage failed: {exc}"}
                    write_json(path, record)
                    records.append(record)
        result = {"status": "failed", "basin_id": basin, "arms": records,
                  "error": str(exc), "traceback": traceback.format_exc()}
    write_json(directory / "result.json", result)
    return result


def pool(function, jobs, workers):
    results = []
    with ProcessPoolExecutor(max_workers=workers) as executor:
        submitted = {executor.submit(function, j): j for j in jobs}
        for future in as_completed(submitted):
            result = future.result()
            results.append(result)
            print(json.dumps({"finished": len(results), "total": len(jobs),
                              "basin": result["basin_id"], "status": result["status"]}), flush=True)
    return sorted(results, key=lambda r: r["basin_id"])


def paired_summary(before, after):
    diff = np.array(after)-np.array(before)
    finite = diff[np.isfinite(diff)]
    return {"total": len(diff), "finite_pairs": len(finite), "wins": int((finite > 0).sum()),
            "ties": int((finite == 0).sum()), "losses": int((finite < 0).sum()),
            "quantiles_10_50_90": np.quantile(finite, [.1, .5, .9]).tolist() if len(finite) else None,
            "minimum": float(finite.min()) if len(finite) else None,
            "declines_gt_0_01": int((finite < -.01).sum()), "declines_gt_0_05": int((finite < -.05).sum()),
            "declines_gt_0_10": int((finite < -.1).sum())}


def expected_arms(role):
    names = [f"uniform_{i}" for i in range(5)]
    if role == "development":
        names += [f"fixed_anchor_{i}" for i in range(8)] + [f"learned_anchor_{i}" for i in range(8)]
    elif role != "receiver":
        raise ValueError("unknown basin role")
    return names + ["pooled_ratio", "pooled_absolute", "open_loop"]


def complete_evaluation(records, basins, role):
    if len(records) != len(basins) or {r["basin_id"] for r in records} != set(basins):
        return False
    expected = set(expected_arms(role))
    return all(r["status"] == "success" and len(r.get("arms", [])) == len(expected)
               and {a["arm"] for a in r["arms"]} == expected
               and all(a["status"] == "success" and np.isfinite(a.get("nse", np.nan)) for a in r["arms"])
               for r in records)


def choose_baseline(records, basins):
    if len(basins) != 49 or not complete_evaluation(records, basins, "development"):
        raise ValueError("development requires 1176/1176 successful arms")
    medians = [float(np.median([next(a["nse"] for a in r["arms"] if a["arm"] == f"uniform_{i}")
                               for r in records])) for i in range(5)]
    return int(np.argmax(medians)), medians


def check_approval(root, stage, identity):
    approval = read_json(root / f"approve_{stage}.json")
    prerequisite = root / ("pilot" if stage == "development" else "development") / "summary.json"
    if (approval.get("bundle_manifest_sha256") != identity or approval.get("approved") is not True
            or approval.get("prerequisite_sha256") != sha256(prerequisite)
            or read_json(prerequisite).get("status") != "success"):
        raise ValueError("independent stage approval is missing, stale or unsuccessful")


def science_pass(complete, comparison):
    return bool(complete and comparison["finite_pairs"] == 360 and comparison["wins"] >= 181
                and comparison["quantiles_10_50_90"][1] > .01)


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("stage", choices=["pilot", "development", "receiver"])
    p.add_argument("--root", required=True)
    p.add_argument("--workers", type=int, required=True)
    args = p.parse_args(argv)
    if os.environ.get("SLURM_JOB_ID") is None:
        raise RuntimeError("real model computation is allowed only inside a Slurm allocation")
    root = Path(args.root)
    if str(root) != PROTOCOL["remote_root"]:
        raise ValueError("unexpected remote root")
    if args.workers < 1 or args.workers > (2 if args.stage == "pilot" else 24):
        raise ValueError("worker budget exceeded")
    identity = verify_bundle()
    # Gate records are externally reviewed, immutable, and bound to bundle/results.
    if args.stage != "pilot":
        check_approval(root, args.stage, identity)
    stage = root / args.stage
    stage.mkdir(exist_ok=False)
    write_json(stage / "execution.json", {"stage": args.stage, "workers": args.workers,
               "job_id": os.environ["SLURM_JOB_ID"], "bundle_manifest_sha256": identity,
               "python": platform.python_version(), "numpy": np.__version__, "pid": os.getpid()})
    try:
        if args.stage == "pilot":
            results = pool(pilot_basin, [(b, str(stage)) for b in PROTOCOL["pilot_basins"]], args.workers)
            ok = all(r["status"] == "success" for r in results)
            summary = {"status": "success" if ok else "failed", "basins": results}
            if ok:
                t840 = max(r["max_candidate_seconds"] for r in results)
                t1260 = max(r["max_1260_seconds"] for r in results)
                tc = max(r["context_seconds"] for r in results)
                # Context includes first kernel compilation; count it again conservatively.
                dev = 1.5*(math.ceil(49/24)*(768*t840+24*t1260+tc+10)+tc+120)
                rec = 1.5*(math.ceil(360/24)*(8*(3561/1260)*t1260+(3561/1260)*tc+10)+tc+120)
                summary["estimated_seconds"] = {"development": dev, "receiver": rec,
                                                 "receiver_is_extrapolated": True}
                summary["resource_gate"] = dev <= 16*3600 and rec <= 6*3600
                if not summary["resource_gate"]:
                    summary["status"] = "resource_hold"
        elif args.stage == "development":
            basins = read_json(INPUTS / "development_basins.json")
            results = pool(learn_basin, [(b, str(stage)) for b in basins], args.workers)
            if not all(r["status"] == "success" for r in results):
                raise ValueError("development optimization incomplete")
            n = sum(r["evaluations"] for r in results)
            failed = sum(r["failed_candidates"] for r in results)
            if n != 37632 or failed/n > .01:
                raise ValueError("development candidate count/failure gate")
            learned = {r["basin_id"]: r for r in results}
            write_json(stage / "learned.json", learned)
            evaluated = pool(evaluate_basin, [(b, str(stage), "development") for b in basins], args.workers)
            write_json(stage / "evaluation_records.json", evaluated)
            winner, medians = choose_baseline(evaluated, basins)
            frozen = {"ratio": log_pool({b: r["winner"]["rho"] for b, r in learned.items()}).tolist(),
                      "absolute_std": log_pool({b: np.array(r["winner"]["rho"])*r["amplitude"]
                                                for b, r in learned.items()}).tolist(),
                      "baseline": f"uniform_{winner}", "uniform_development_medians": medians,
                      "donors": basins, "bundle_manifest_sha256": identity}
            write_json(stage / "frozen_transfer.json", frozen)
            anchor_comparisons = []
            for i in range(8):
                before = [next(a["nse"] for a in r["arms"] if a["arm"] == f"fixed_anchor_{i}") for r in evaluated]
                after = [next(a["nse"] for a in r["arms"] if a["arm"] == f"learned_anchor_{i}") for r in evaluated]
                anchor_comparisons.append({"anchor": i, **paired_summary(before, after)})
            summary = {"status": "success", "candidate_evaluations": n, "failed_candidates": failed,
                       "successful_arm_basins": 1176, "optimized_vs_fixed_anchor": anchor_comparisons,
                       "transfer_sha256": sha256(stage / "frozen_transfer.json")}
        else:
            basins = read_json(INPUTS / "receiver_basins.json")
            frozen_path = root / "development/frozen_transfer.json"
            if read_json(root / "development/summary.json")["transfer_sha256"] != sha256(frozen_path):
                raise ValueError("frozen transfer hash mismatch")
            frozen = read_json(frozen_path)
            evaluated = pool(evaluate_basin, [(b, str(stage), "receiver") for b in basins], args.workers)
            write_json(stage / "evaluation_records.json", evaluated)
            def values(arm):
                return [next((a.get("nse", np.nan) for a in r.get("arms", []) if a["arm"] == arm), np.nan)
                        for r in evaluated]
            main_result = paired_summary(values(frozen["baseline"]), values("pooled_ratio"))
            ok = complete_evaluation(evaluated, basins, "receiver")
            passed = science_pass(ok, main_result)
            uniform_diagnostics = [{"arm": f"uniform_{i}",
                "finite_count": int(np.isfinite(values(f"uniform_{i}")).sum()),
                "median": float(np.median(values(f"uniform_{i}")))
                    if np.isfinite(values(f"uniform_{i}")).all() else None,
                "pooled_ratio_comparison": paired_summary(values(f"uniform_{i}"), values("pooled_ratio"))}
                for i in range(5)]
            summary = {"status": "success" if ok else "failed", "science_pass": passed,
                       "main_comparison": main_result, "baseline": frozen["baseline"],
                       "posthoc_uniform_diagnostics_not_primary_selection": uniform_diagnostics,
                       "normalized_vs_absolute": paired_summary(values("pooled_absolute"), values("pooled_ratio")),
                       "transfer_sha256": sha256(frozen_path),
                       "successful_arm_basins": sum(a["status"] == "success" for r in evaluated for a in r.get("arms", []))}
    except Exception as exc:
        summary = {"status": "failed", "error": f"{type(exc).__name__}: {exc}", "traceback": traceback.format_exc()}
    write_json(stage / "summary.json", summary)
    print(json.dumps(summary, allow_nan=False), flush=True)
    return 0 if summary["status"] == "success" else 1


if __name__ == "__main__":
    raise SystemExit(main())
