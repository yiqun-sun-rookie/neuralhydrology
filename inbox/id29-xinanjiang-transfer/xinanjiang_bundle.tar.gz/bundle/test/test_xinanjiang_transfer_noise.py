"""Synthetic-only gates for the independently scoped second-model extension."""
import importlib.util
import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from xinanjiang_transfer_noise.adapter import (  # noqa: E402
    Adapter, PARAMETER_BOUNDS, compact_state, expand_state, validate_parameters,
)


@pytest.fixture
def parameters():
    return {k: (v[0] + v[1]) / 2 for k, v in PARAMETER_BOUNDS.items()}


def test_compact_state_round_trip(parameters):
    a = Adapter(parameters)
    state = a.initial_state()
    state[0] = 37.0
    np.testing.assert_array_equal(compact_state(expand_state(state, 4.0)), state)


@pytest.mark.parametrize("bad", ["ice", "total", "nan"])
def test_reject_nonindependent_legacy_state(parameters, bad):
    s = expand_state(Adapter(parameters).initial_state(), 2.0)
    s[{"ice": 1, "total": 3, "nan": 0}[bad]] += 1 if bad != "nan" else np.nan
    with pytest.raises(ValueError):
        compact_state(s)


def test_reversed_thresholds_are_rejected(parameters):
    parameters.update(temp_snow=0.9, temp_rain=0.6)
    with pytest.raises(ValueError, match="threshold"):
        validate_parameters(parameters)


def synthetic_forcing(n=120):
    # Includes persistent drought, snow accumulation, melt, and a large storm.
    rain = np.resize(np.array([0., 0., 0., 4., 20., 0., 100., 2.]), n)
    pet = np.resize(np.array([0., 2., 4., 0.5, 1., 12., 0., 3.]), n)
    temp = np.resize(np.array([-8., -4., 0., 5., 20., 12., -2., 10.]), n)
    return rain, pet, temp


def test_complete_trajectory_matches_canonical_and_independent_reference(parameters):
    from xaj_global_pilot.xaj_numba import simulate_pdd_xaj_fast
    a = Adapter(parameters)
    rain, pet, temp = synthetic_forcing()
    states, q = a.simulate(rain, pet, temp)
    expected_q, final = simulate_pdd_xaj_fast(rain, pet, temp, parameters)
    np.testing.assert_allclose(q, expected_q, atol=1e-9, rtol=1e-10)
    np.testing.assert_allclose(states[-1], compact_state(final), atol=1e-9, rtol=1e-10)
    s = a.initial_state()
    for t in range(len(rain)):
        s = a.reference_step(s, rain[t], pet[t], temp[t])
        np.testing.assert_allclose(states[t], s, atol=1e-9, rtol=1e-10)


def test_segmented_restart_keeps_all_states(parameters):
    a = Adapter(parameters)
    r, p, t = synthetic_forcing()
    full, _ = a.simulate(r, p, t)
    first, _ = a.simulate(r[:53], p[:53], t[:53])
    last, _ = a.simulate(r[53:], p[53:], t[53:], initial=first[-1])
    np.testing.assert_array_equal(last, full[53:])


def test_projection_is_bounded_and_diagnosed_by_dimension(parameters):
    a = Adapter(parameters)
    state = np.array([-1., 1000., -3., 1000., 1000., -5., 2., -6.])
    actual = a.project(state, "posterior")
    assert np.all(actual >= 0)
    assert np.all(actual[1:5] <= a.limits[1:5])
    d = a.diagnostics()["posterior"]
    np.testing.assert_array_equal(d["signed_correction"], actual - state)
    np.testing.assert_array_equal(d["absolute_correction"], abs(actual - state))


def test_observation_uses_three_routing_memories(parameters):
    a = Adapter(parameters)
    s = a.initial_state()
    s[5:] = [-1, 2, 3]
    assert a.observation(s) == 5


def test_today_observation_changes_only_tomorrow_prior(parameters):
    from xinanjiang_transfer_noise.engine import filter_run
    rain, pet, temp = synthetic_forcing(12)
    obs = np.ones(12)
    original = filter_run(parameters, rain, pet, temp, obs, .2, np.full(8, .05))
    changed = obs.copy()
    changed[6] = 3.
    perturbed = filter_run(parameters, rain, pet, temp, changed, .2, np.full(8, .05))
    np.testing.assert_array_equal(original["prior"][:7], perturbed["prior"][:7])
    assert original["prior"][7] != perturbed["prior"][7]
    assert np.all(original["variance"] > 0)


def test_amplitudes_use_only_prefix():
    from xinanjiang_transfer_noise.engine import amplitudes
    x = np.ones((20, 8))
    expected = amplitudes(x, 10)
    x[10:] = 1e9
    np.testing.assert_array_equal(amplitudes(x, 10), expected)


def test_pool_excludes_receiver():
    from xinanjiang_transfer_noise.engine import log_pool
    rows = {"a": np.full(8, .01), "b": np.full(8, .1), "c": np.full(8, 1.)}
    expected = log_pool(rows, exclude="a")
    rows["a"] = np.full(8, 1e-4)
    np.testing.assert_array_equal(log_pool(rows, exclude="a"), expected)


def test_anchor_dimensions_counts_and_bounds():
    from xinanjiang_transfer_noise.engine import anchors, PROTOCOL
    assert len(anchors()) == 8
    assert all(np.shape(r) == (8,) for _, r in anchors())
    assert len(anchors()) * PROTOCOL["population"] * PROTOCOL["generations"] * 49 == 37632


def test_non_overwrite_result_writer(tmp_path):
    from xinanjiang_transfer_noise.prepare import write_json
    p = tmp_path / "test.json"
    write_json(p, {"ok": 1})
    with pytest.raises(FileExistsError):
        write_json(p, {"ok": 2})


def test_linear_observation_and_missing_observation_covariance():
    from xinanjiang_transfer_noise.engine import ModifiedUnscentedFilter
    f = ModifiedUnscentedFilter(np.ones(8), np.eye(8), lambda s: s,
                               lambda s: s[-3:].sum(), np.eye(8)*.1, [[.04]])
    result = f.step(4.)
    assert abs(result.prior_observation[0] - 3.) < 1e-12
    assert abs(result.innovation_covariance[0, 0] - 3.34) < 1e-12
    np.testing.assert_allclose(result.posterior_covariance, result.posterior_covariance.T, atol=1e-12)
    assert np.linalg.eigvalsh(result.posterior_covariance).min() >= -1e-12
    prior, cov = f.predict_without_observation()
    np.testing.assert_array_equal(f.state, prior)
    np.testing.assert_array_equal(f.covariance, cov)


def make_camels_files(tmp_path, forcing_rows=None, flow_rows=None):
    forcing = tmp_path / "basin_mean_forcing/maurer/01/01144000_lump_maurer_forcing_leap.txt"
    flow = tmp_path / "usgs_streamflow/01/01144000_streamflow_qc.txt"
    topo = tmp_path / "camels_attributes_v2.0/camels_topo.txt"
    for p in [forcing, flow, topo]:
        p.parent.mkdir(parents=True, exist_ok=True)
    rows = forcing_rows or ["1989 10 1 12 2 -8 -8 100 40000", "1989 10 2 12 1 5 5 100 40000"]
    forcing.write_text("1\n2\n3\nYear Mnth Day Hr PRCP Tmax Tmin SRAD dayl\n" + "\n".join(rows) + "\n")
    flow.write_text("\n".join(flow_rows or ["01144000 1989 10 1 1 A", "01144000 1989 10 2 2 A"]) + "\n")
    topo.write_text("gauge_id;area_gages2\n01144000;100\n")
    return tmp_path


def test_negative_temperature_and_outside_window_observation_are_allowed(tmp_path):
    from xinanjiang_transfer_noise.data import load_window
    root = make_camels_files(tmp_path, flow_rows=["01144000 1989 9 30 not_a_number A",
        "01144000 1989 10 1 1 A", "01144000 1989 10 2 2 A", "01144000 1989 10 3 not_a_number A"])
    out = load_window(root, "01144000", "1989-10-01", 2)
    assert out["temp"][0] == -8.
    assert out["pet"][0] == 0.
    assert out["pet"][1] == pytest.approx(100*40000/1e6*10/245)


@pytest.mark.parametrize("row", [
    "1989 10 1 12 -2 -8 -8 100 40000", "1989 10 1 12 2 -8 -8 -100 40000",
    "1989 10 1 12 2 -8 -8 100 86401", "1989 10 1 12 2 -8 -8 100 -1",
    "1989 10 1 12 2 -8 -8 nan 40000", "1989 10 1 12 2 -8 -8 100 nan",
    "1989 10 1 12 2 nan -8 100 40000",
])
def test_bad_raw_forcing_not_hidden_by_winter_pet_branch(tmp_path, row):
    from xinanjiang_transfer_noise.data import load_window
    root = make_camels_files(tmp_path, forcing_rows=[row, "1989 10 2 12 1 5 5 100 40000"])
    with pytest.raises(ValueError):
        load_window(root, "01144000", "1989-10-01", 2)


@pytest.mark.parametrize("flow_rows", [
    ["01144000 1989 10 1 1 A"],
    ["01144000 1989 10 1 1 A", "01144000 1989 10 1 2 A"],
    ["01144000 1989 10 1 -1 A", "01144000 1989 10 2 2 A"],
])
def test_missing_duplicate_or_negative_observed_days_rejected(tmp_path, flow_rows):
    from xinanjiang_transfer_noise.data import load_window
    root = make_camels_files(tmp_path, flow_rows=flow_rows)
    with pytest.raises(ValueError):
        load_window(root, "01144000", "1989-10-01", 2)


def test_search_budget_failure_handling_and_proposal_repair(monkeypatch):
    import types
    from xinanjiang_transfer_noise import engine
    proposals = []
    class Strategy:
        def __init__(self, *args):
            pass
        def ask(self):
            p = [np.full(8, -20. + j) for j in range(8)]
            proposals.append(p)
            return p
        def tell(self, candidates, fitnesses):
            assert candidates is proposals[-1]
            assert len(fitnesses) == 8
    monkeypatch.setitem(sys.modules, "cma", types.SimpleNamespace(CMAEvolutionStrategy=Strategy))
    calls = []
    def fake_filter(*args):
        std = args[-1]
        assert np.all(std >= 1e-4 - 1e-18)
        calls.append(1)
        if len(calls) == 1:
            raise ValueError("deliberate candidate failure")
        return {"prior": np.zeros(840)}
    monkeypatch.setattr(engine, "filter_run", fake_filter)
    task = {"parameters": {}, "rain": np.ones(840), "pet": np.ones(840),
            "temp": np.ones(840), "obs": np.ones(840), "sigma_obs": .1}
    records = []
    out = engine.search_anchor(task, np.ones(8), "01144000", 0, records.append)
    assert out["evaluations"] == len(calls) == len(records) == 96
    assert out["failed_candidates"] == 1 and out["objective"] == 1.
    assert records[0]["error"] is not None and records[0]["objective"] == 1e30
    def all_failed(*args):
        raise ValueError("all failed")
    monkeypatch.setattr(engine, "filter_run", all_failed)
    with pytest.raises(ValueError, match="no finite candidate"):
        engine.search_anchor(task, np.ones(8), "01144000", 0, lambda r: None)


@pytest.mark.parametrize("y,q", [(np.array([]), np.array([])),
    (np.array([1e300, -1e300]), np.zeros(2)), (np.array([1., 2.]), np.array([1e300, 1e300]))])
def test_score_rejects_empty_or_overflowed_values(y, q):
    from xinanjiang_transfer_noise.engine import score
    with np.errstate(over="ignore", invalid="ignore"), pytest.raises(ValueError):
        score(q, y, 0)


def test_real_computation_refuses_non_slurm_environment(monkeypatch):
    from xinanjiang_transfer_noise import runner
    monkeypatch.delenv("SLURM_JOB_ID", raising=False)
    with pytest.raises(RuntimeError, match="Slurm"):
        runner.main(["pilot", "--root", runner.PROTOCOL["remote_root"], "--workers", "2"])


def test_arm_failure_is_persisted_not_scored_as_success(tmp_path, monkeypatch):
    from xinanjiang_transfer_noise import runner
    def fail(*args):
        raise ValueError("deliberate test failure")
    monkeypatch.setattr(runner, "filter_run", fail)
    task = {"parameters": {}, "rain": [0], "pet": [0], "temp": [0], "obs": [1], "sigma_obs": .1}
    record = runner.persist_arm(tmp_path, "arm", task, np.ones(8), 0)
    assert record["status"] == "failed" and "nse" not in record
    assert (tmp_path / "arm.json").exists()
    assert not (tmp_path / "arm.npz").exists()


def test_paired_summary_keeps_failure_denominator():
    from xinanjiang_transfer_noise.runner import paired_summary
    s = paired_summary([0., 1., 1., np.nan], [1., 1., .8, 2.])
    assert s["total"] == 4 and s["finite_pairs"] == 3
    assert (s["wins"], s["ties"], s["losses"]) == (1, 1, 1)


def test_data_reader_rejects_missing_or_duplicate_forcing_dates(tmp_path):
    from xinanjiang_transfer_noise.data import load_window
    root = make_camels_files(tmp_path, forcing_rows=["1989 10 1 12 2 -8 -8 100 40000"])
    with pytest.raises(ValueError):
        load_window(root, "01144000", "1989-10-01", 2)
    root = make_camels_files(tmp_path, forcing_rows=["1989 10 1 12 2 -8 -8 100 40000"]*2)
    with pytest.raises(ValueError, match="duplicate"):
        load_window(root, "01144000", "1989-10-01", 2)


def test_missing_and_stale_approval_rejected(tmp_path):
    from xinanjiang_transfer_noise.runner import check_approval
    from xinanjiang_transfer_noise.prepare import write_json
    with pytest.raises(FileNotFoundError):
        check_approval(tmp_path, "development", "manifest")
    (tmp_path / "pilot").mkdir()
    write_json(tmp_path / "pilot/summary.json", {"status": "success"})
    write_json(tmp_path / "approve_development.json", {"approved": True,
        "bundle_manifest_sha256": "manifest", "prerequisite_sha256": "stale"})
    with pytest.raises(ValueError, match="stale"):
        check_approval(tmp_path, "development", "manifest")


def test_incomplete_development_and_baseline_tie():
    from xinanjiang_transfer_noise.runner import choose_baseline, expected_arms
    basins = [str(i) for i in range(49)]
    records = [{"basin_id": b, "status": "success", "arms": [
        {"arm": a, "status": "success", "nse": .5} for a in expected_arms("development")]} for b in basins]
    assert choose_baseline(records, basins)[0] == 0
    with pytest.raises(ValueError):
        choose_baseline(records[:-1], basins)
    duplicate_basin = records[:-1] + [records[0]]
    with pytest.raises(ValueError):
        choose_baseline(duplicate_basin, basins)
    original_arm = records[0]["arms"][-1]
    records[0]["arms"][-1] = records[0]["arms"][0]
    with pytest.raises(ValueError):
        choose_baseline(records, basins)
    records[0]["arms"][-1] = original_arm
    records[0]["arms"].pop()
    with pytest.raises(ValueError):
        choose_baseline(records, basins)


@pytest.mark.parametrize("complete,n,wins,gain,passed", [
    (True, 360, 181, .01001, True), (True, 360, 181, .01, False),
    (True, 360, 180, .02, False), (True, 359, 181, .02, False),
    (False, 360, 181, .02, False),
])
def test_science_gate_strict_boundaries(complete, n, wins, gain, passed):
    from xinanjiang_transfer_noise.runner import science_pass
    assert science_pass(complete, {"finite_pairs": n, "wins": wins, "quantiles_10_50_90": [0, gain, 1]}) is passed


def test_context_failure_still_persists_all_receiver_arm_statuses(tmp_path, monkeypatch):
    from xinanjiang_transfer_noise import runner
    def fail(*args):
        raise ValueError("input is missing")
    monkeypatch.setattr(runner, "task_for", fail)
    result = runner.evaluate_basin(("01144000", str(tmp_path), "receiver"))
    assert len(result["arms"]) == 8 and result["status"] == "failed"
    assert all(a["status"] == "not_run" for a in result["arms"])
