"""Matched 5,633-parameter neural correction channels."""

import torch
from torch import nn


def project_rain(raw_rain, proposal, cap):
    cap = torch.as_tensor(cap, dtype=proposal.dtype, device=proposal.device)
    if bool((cap <= 0).any()):
        raise ValueError("Rain cap must be positive")
    lower = -torch.minimum(raw_rain, cap)
    applied = torch.clamp(proposal, min=lower, max=cap)
    violation = (torch.relu(lower - proposal) + torch.relu(proposal - cap)) / cap
    return raw_rain + applied, applied, violation


class RainCorrector(nn.Module):
    def __init__(self, cap: float, historical: bool = False):
        super().__init__()
        self.encoder = nn.GRU(11, 32, batch_first=True)
        self.decoder = nn.Sequential(nn.Linear(39, 32), nn.SiLU(), nn.Linear(32, 1))
        nn.init.zeros_(self.decoder[-1].weight)
        nn.init.zeros_(self.decoder[-1].bias)
        self.register_buffer("cap", torch.tensor(float(cap)))
        self.historical = historical

    def forward(self, features, lag_weather, previous_applied, lag_days):
        states, _ = self.encoder(features.unsqueeze(0))
        states = states[0]
        summary = states if self.historical else states[-1:].expand(len(states), -1)
        decoder_input = torch.cat((summary, lag_weather, (previous_applied / self.cap)[:, None],
                                   (lag_days / 99.)[:, None]), dim=-1)
        return self.decoder(decoder_input).squeeze(-1) * self.cap


class FlowCorrector(nn.Module):
    def __init__(self, flow_std: float):
        super().__init__()
        self.encoder = nn.GRU(11, 32, batch_first=True)
        self.decoder = nn.Sequential(nn.Linear(39, 32), nn.SiLU(), nn.Linear(32, 1))
        nn.init.zeros_(self.decoder[-1].weight)
        nn.init.zeros_(self.decoder[-1].bias)
        self.register_buffer("flow_std", torch.tensor(float(flow_std)))
        self.register_buffer("cap", torch.tensor(5. * float(flow_std)))

    def forward(self, features, weather, normalized_base, previous_applied):
        states, _ = self.encoder(features.unsqueeze(0))
        inputs = torch.cat((states[0, -1], weather, normalized_base.reshape(1),
                            (previous_applied / self.flow_std).reshape(1)))
        proposal = self.decoder(inputs).squeeze() * self.flow_std
        applied = torch.clamp(proposal, min=-self.cap, max=self.cap)
        violation = (torch.relu(-self.cap - proposal) + torch.relu(proposal - self.cap)) / self.cap
        return proposal, applied, violation
