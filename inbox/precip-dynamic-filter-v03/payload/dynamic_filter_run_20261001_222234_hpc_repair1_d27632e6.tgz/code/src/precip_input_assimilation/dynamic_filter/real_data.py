"""Explicit allowed-period data preparation and a direct frozen model adapter."""

from dataclasses import dataclass
from datetime import date
from pathlib import Path
import hashlib

import numpy as np
import torch

from ..selfrule.data import (find_unique, load_normalization, load_normalized_attributes,
                             read_maurer_forcing)
from ..selfrule.model import FrozenC4
from .protocol import BASIN, WEATHER_START, Phase, Scaling
from .report import require_identity, require_no_forbidden_imports, sha256
from .rollout import Replay
from .stream import canonical_flow_hash, read_flow


@dataclass
class Inputs:
    dates: tuple
    weather: np.ndarray
    flow_path: Path
    area_m2: float
    flow: dict
    hashes: dict

    def weather_for(self, phase):
        first = self.dates.index(phase.start)
        last = self.dates.index(phase.end)
        return self.weather[first:last + 1]

    def observations_for(self, phase):
        key = (phase.name, phase.start, phase.end)
        if key not in self.flow:
            dates, values = read_flow(self.flow_path, BASIN, self.area_m2, phase)
            self.flow[key] = values
            self.hashes[f"flow_{phase.name}_{phase.start}_{phase.end}"] = canonical_flow_hash(dates, values)
        return self.flow[key]


def load_inputs(data_dir, model_dir, end, repo):
    require_identity(repo, model_dir)
    # No dataset factory: it would read complete observation files before slicing.
    forcing = read_maurer_forcing(Path(data_dir), BASIN, WEATHER_START, end)
    dates = tuple(date.fromisoformat(str(day)) for day in forcing.dates)
    if (forcing.values[:, 0] < 0).any():
        raise ValueError("Raw Maurer rain contains negative values")
    flow_path = find_unique(Path(data_dir) / "usgs_streamflow", f"{BASIN}_streamflow_qc.txt")
    return Inputs(dates, forcing.values, flow_path, forcing.area_m2, {},
                  {"weather_canonical": forcing.canonical_sha256})


class FrozenHydro:
    def __init__(self, data_dir, model_dir, device):
        cfg, names, center, scale, q_center, q_scale = load_normalization(Path(model_dir))
        expected = ("PRCP(mm/day)", "Tmin(C)", "Tmax(C)", "SRAD(W/m2)", "Vp(Pa)")
        if tuple(names) != expected or cfg.seq_length != 270 or cfg.hidden_size != 256:
            raise RuntimeError("Frozen model identity/config is incompatible with the approved adapter")
        self.frozen = FrozenC4(Path(model_dir), device, names, center, scale, q_center, q_scale)
        self.static = torch.as_tensor(load_normalized_attributes(Path(data_dir), Path(model_dir), [BASIN])[0],
                                      dtype=torch.float32, device=device)
        self.sequence_length = self.frozen.sequence_length
        self.device = torch.device(device)
        require_no_forbidden_imports()

    def __call__(self, window):
        return self.frozen.predict(window, self.static,
                                   torch.tensor([len(window) - 1], device=self.device))[0]

    def direct(self, weather, indices, batch=128):
        raw = torch.as_tensor(weather, dtype=torch.float32, device=self.device)
        pieces = []
        with torch.no_grad():
            for begin in range(0, len(indices), batch):
                positions = torch.as_tensor(indices[begin:begin + batch], dtype=torch.int64, device=self.device)
                pieces.append(self.frozen.predict(raw, self.static, positions).cpu().numpy())
        return np.concatenate(pieces)

    def state_hash(self):
        digest = hashlib.sha256()
        for name, parameter in self.frozen.model.state_dict().items():
            digest.update(name.encode())
            digest.update(parameter.detach().cpu().contiguous().numpy().tobytes())
        return digest.hexdigest()


def replay_factory(hydro, inputs, scaling, kind, sink=None, beta=0., base_cache=None, deadline=None):
    first = inputs.dates.index(scaling.start)
    warmup = torch.as_tensor(inputs.weather[:first], dtype=torch.float32, device=hydro.device)

    def factory(network):
        return Replay(hydro, network, scaling, inputs.dates[:first], warmup,
                      kind=kind, sink=sink, beta=beta, base_cache=base_cache, deadline=deadline)

    return factory


def source_snapshot(repo):
    repo = Path(repo)
    files = list((repo / "src/precip_input_assimilation/dynamic_filter").glob("*.py"))
    files += list((repo / "src/precip_input_assimilation/scripts").glob("*dynamic_filter*.py"))
    files += list((repo / "src/precip_input_assimilation/tests").glob("test_dynamic_filter*.py"))
    files += [repo / path for path in (
        "src/precip_input_assimilation/selfrule/model.py", "src/precip_input_assimilation/selfrule/data.py",
        "neuralhydrology/modelzoo/cudalstm.py", "neuralhydrology/modelzoo/inputlayer.py",
        "neuralhydrology/modelzoo/head.py", "neuralhydrology/modelzoo/__init__.py",
        "neuralhydrology/datasetzoo/basedataset.py", "neuralhydrology/datasetzoo/camelsus.py",
        "neuralhydrology/utils/config.py")]
    return {str(p.relative_to(repo)).replace("\\", "/"): sha256(p) for p in sorted(files)}


def require_sources(repo, expected):
    for name, identity in expected.items():
        if sha256(Path(repo) / name) != identity:
            raise RuntimeError(f"Source changed since identity was frozen: {name}")
