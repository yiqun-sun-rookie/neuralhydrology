"""Date-gated value parsing and observations released only after locked predictions."""

from dataclasses import dataclass
from datetime import date
from pathlib import Path
import hashlib
import math

import numpy as np

from .protocol import BASIN, Phase

CFS_TO_MM = 28316846.592 * 86400. / 1_000_000.


def read_flow(path: Path, basin: str, area_m2: float, phase: Phase, start=None, end=None):
    start, end = start or phase.start, end or phase.end
    phase.require(start, end)  # Must precede even opening the file.
    if phase.name != "synthetic" and basin != BASIN:
        raise PermissionError("The approved pilot contains exactly one fixed basin")
    if area_m2 <= 0:
        raise ValueError("Invalid catchment area")
    dates = tuple(d for d in phase.dates if start <= d <= end)
    values = {}
    previous = None
    with Path(path).open(encoding="utf-8") as handle:
        for number, line in enumerate(handle, 1):
            fields = line.split()
            if len(fields) < 4:
                raise ValueError(f"Invalid date metadata at line {number}")
            current = date(*(int(x) for x in fields[1:4]))
            if fields[0] != basin or (previous is not None and current <= previous):
                raise ValueError("Unexpected basin or non-increasing dates")
            previous = current
            if current < start:
                continue
            if current > end:
                break
            raw = float(fields[4])  # Never evaluated outside the allowed phase.
            values[current] = float("nan") if raw < 0 or not math.isfinite(raw) else CFS_TO_MM * raw / area_m2
            if current == end:
                break  # Do not even request the next line after the endpoint.
    return dates, np.array([values.get(d, float("nan")) for d in dates], dtype=np.float64)


@dataclass(frozen=True)
class Observation:
    date: date
    value: float


class ObservationStream:
    """The corrector receives individual values, never this source or a future mask."""
    def __init__(self, phase, values):
        if len(values) != len(phase.dates):
            raise ValueError("Observation source has the wrong number of days")
        self.phase = phase
        self._values = values
        self._cursor = 0

    def release(self, prediction):
        if not prediction.locked or self._cursor >= len(self.phase.dates):
            raise PermissionError("Observation requested without a locked prediction")
        expected = self.phase.dates[self._cursor]
        if prediction.date != expected:
            raise PermissionError("Observation date must equal the next locked prediction")
        value = float(self._values[self._cursor])
        self._cursor += 1
        return Observation(expected, value)

    @property
    def consumed(self):
        return self._cursor


def canonical_flow_hash(dates, values):
    digest = hashlib.sha256()
    for day, value in zip(dates, values, strict=True):
        rendered = format(float(value), ".17g") if np.isfinite(value) else "NA"
        digest.update(f"{day},{rendered}\n".encode())
    return digest.hexdigest()
