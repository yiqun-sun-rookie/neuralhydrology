"""Thirty-two-day truncated graphs with one-day closing supervision."""

from dataclasses import dataclass
import math
import time

import numpy as np
import torch

from .protocol import MAX_EPOCHS, PATIENCE, SEGMENT
from .report import nse
from .stream import ObservationStream


@dataclass(frozen=True)
class Segment:
    start: int
    stop: int  # Exclusive update endpoint.
    closing: int | None


def segments(length, width=SEGMENT):
    if length < 1 or width < 1:
        raise ValueError("Empty sequence or invalid segment width")
    return [Segment(i, min(i + width, length), i + width if i + width < length else None)
            for i in range(0, length, width)]


def flow_loss(prediction, observation, scaling):
    if not math.isfinite(observation.value):
        return None
    return ((prediction.tensor - observation.value) / scaling.flow_std).square()


def segment_loss(flow_terms, magnitude, violations, penalty):
    terms = []
    if flow_terms:
        terms.append(torch.stack(flow_terms).mean())
    if magnitude:
        terms.append(penalty * torch.cat([t.reshape(-1) for t in magnitude]).mean())
    if violations:
        terms.append(.01 * torch.cat([t.reshape(-1) for t in violations]).mean())
    return sum(terms) if terms else None


def train_epoch(replay, phase, weather, values, optimizer, penalty, width=SEGMENT):
    if phase.name not in ("fit", "probe", "synthetic"):
        raise PermissionError("Training labels must be in the fitting phase")
    if len(weather) != len(phase.dates):
        raise ValueError("Training weather length differs from bound dates")
    source = ObservationStream(phase, values)
    pending = None
    records = []
    for segment in segments(len(phase.dates), width):
        started = time.perf_counter()
        flow_terms, magnitude, violations = [], [], []
        invalid_followup = 0

        def predict_and_release(index):
            pred = replay.predict(phase.dates[index], weather[index])
            obs = source.release(pred)
            term = flow_loss(pred, obs, replay.scaling)
            if term is not None:
                flow_terms.append(term)
            if replay.kind == "flow":
                magnitude.append(pred.direct_applied.abs() / replay.corrector.cap)
                violations.append(pred.direct_violation)
            return pred, obs

        for index in range(segment.start, segment.stop):
            if pending is None:
                prediction, observation = predict_and_release(index)
            else:
                prediction, observation = pending
                pending = None  # This prediction's loss was paid by the preceding segment.
            terminal = index == len(phase.dates) - 1
            if terminal:
                with torch.no_grad():
                    replay.observe(prediction.date, observation.value)
            else:
                update = replay.observe(prediction.date, observation.value)
                if replay.kind in ("rain", "historical") and not update.missing:
                    magnitude.append(update.applied.abs() / update.cap)
                    violations.append(update.violation)
        if segment.closing is not None:
            prediction, observation = predict_and_release(segment.closing)
            if not math.isfinite(observation.value):
                invalid_followup = 1
            pending = (prediction, observation)

        loss = segment_loss(flow_terms, magnitude, violations, penalty)
        differentiable = loss is not None and loss.requires_grad
        supervised = any(t.requires_grad for t in flow_terms)
        gradient_norm, nonzero_grad_parameters = 0., 0
        if optimizer is not None:
            optimizer.zero_grad(set_to_none=True)
        if differentiable:
            loss.backward()
            parameters = list(replay.corrector.parameters())
            if any(p.grad is not None and not torch.isfinite(p.grad).all() for p in parameters):
                raise RuntimeError("Nonfinite correction gradient")
            gradient_norm = float(sum(p.grad.detach().square().sum() for p in parameters if p.grad is not None).sqrt())
            nonzero_grad_parameters = sum(p.grad is not None and bool((p.grad != 0).any()) for p in parameters)
            if optimizer is not None:
                optimizer.step()
        records.append({"start": str(phase.dates[segment.start]), "stop": str(phase.dates[segment.stop - 1]),
                        "closing": None if segment.closing is None else str(phase.dates[segment.closing]),
                        "flow_terms": len(flow_terms), "magnitude_items": sum(t.numel() for t in magnitude),
                        "violation_items": sum(t.numel() for t in violations), "differentiable": differentiable,
                        "flow_supervised": supervised, "regularization_only": differentiable and not supervised,
                        "gradient_norm": gradient_norm, "nonzero_grad_parameters": nonzero_grad_parameters,
                        "missing_closing_followup": invalid_followup,
                        "loss": None if loss is None else float(loss.detach()),
                        "seconds": time.perf_counter() - started})
        replay.detach_history()
        if pending is not None:
            pending = (replay.last_prediction, pending[1])
    if source.consumed != len(phase.dates):
        raise RuntimeError("Training did not consume precisely the bound dates")
    return records


def replay_phase(replay, phase, weather, values):
    source = ObservationStream(phase, values)
    predictions = []
    with torch.no_grad():
        for current, row in zip(phase.dates, weather, strict=True):
            prediction = replay.predict(current, row)
            observation = source.release(prediction)
            predictions.append(prediction.q_mm_day)
            replay.observe(current, observation.value)
    return np.asarray(predictions)


def train_one(network, factory, fit_phase, fit_weather, fit_values, select_phase, select_weather,
              select_values, penalty, output, seed, max_epochs=MAX_EPOCHS, patience=PATIENCE):
    """Each validation evaluation reconstructs state using the current fixed checkpoint."""
    from .report import write_json

    optimizer = torch.optim.Adam(network.parameters(), lr=.001)
    best_score, best_epoch = -float("inf"), None
    history = []
    for epoch in range(1, max_epochs + 1):
        began = time.perf_counter()
        network.train()
        training = train_epoch(factory(network), fit_phase, fit_weather, fit_values, optimizer, penalty)
        network.eval()
        validation = factory(network)
        replay_phase(validation, fit_phase, fit_weather, fit_values)
        predicted = replay_phase(validation, select_phase, select_weather, select_values)
        score = nse(select_values, predicted)
        if score is None:
            raise RuntimeError("Validation efficiency is undefined")
        better = score > best_score
        if better:
            best_score, best_epoch = score, epoch
            # This path belongs to this new fit. Replacing its incumbent is checkpoint selection,
            # never modification of a previous run's artifact.
            torch.save({"state_dict": network.state_dict(), "seed": seed, "penalty": penalty,
                        "epoch": epoch, "validation_nse": score}, output / "selected.pt")
        item = {"epoch": epoch, "validation_nse": score, "selected": better,
                "segments": training, "seconds": time.perf_counter() - began}
        history.append(item)
        write_json(output / f"epoch_{epoch:03d}.json", item)
        print(f"epoch={epoch} select_nse={score:.6f} seconds={item['seconds']:.1f}", flush=True)
        if epoch - best_epoch >= patience:
            break
    return {"seed": seed, "penalty": penalty, "best_epoch": best_epoch,
            "validation_nse": best_score, "epochs": len(history)}
