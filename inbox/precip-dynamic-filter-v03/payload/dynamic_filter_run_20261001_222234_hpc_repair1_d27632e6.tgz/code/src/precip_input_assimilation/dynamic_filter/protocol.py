"""Frozen study windows, phase access gates, and fit-only normalization."""

from dataclasses import dataclass
from datetime import date, timedelta

import numpy as np
import torch

FIT_START = date(1980, 10, 1)
FIT_END = date(1984, 9, 30)
SELECT_START = date(1984, 10, 1)
SELECT_END = date(1985, 9, 30)
SCORE_START = date(1985, 10, 1)
SCORE_END = date(1989, 9, 30)
WEATHER_START = date(1980, 1, 1)
SEEDS = (1001, 1002, 1003)
PENALTIES = (0.0001, 0.001, 0.01)
BASIN = "01022500"
WINDOW = 100
SEGMENT = 32
MAX_EPOCHS = 60
PATIENCE = 10


@dataclass(frozen=True)
class Phase:
    name: str
    start: date
    end: date

    def __post_init__(self):
        bounds = {"fit": (FIT_START, FIT_END), "select": (SELECT_START, SELECT_END),
                  "score": (SCORE_START, SCORE_END), "probe": (FIT_START, FIT_START + timedelta(days=63))}
        if self.name == "synthetic":
            if self.start > self.end:
                raise ValueError("Reversed synthetic interval")
            return
        if self.name not in bounds:
            raise ValueError(f"Unknown phase {self.name}")
        lower, upper = bounds[self.name]
        if not lower <= self.start <= self.end <= upper:
            raise PermissionError(f"{self.name}: forbidden interval {self.start}..{self.end}")

    def require(self, start: date, end: date):
        if not self.start <= start <= end <= self.end:
            raise PermissionError(f"Request outside bound phase {self.name}")

    @property
    def dates(self):
        return tuple(self.start + timedelta(days=i) for i in range((self.end - self.start).days + 1))


@dataclass(frozen=True)
class Scaling:
    weather_mean: np.ndarray
    weather_std: np.ndarray
    flow_mean: float
    flow_std: float
    cap: float
    start: date
    end: date

    @classmethod
    def fit(cls, weather, flow, phase: Phase):
        if phase.name not in ("fit", "probe", "synthetic"):
            raise PermissionError("Normalization may only use fit/probe observations")
        weather, flow = np.asarray(weather), np.asarray(flow)
        if len(weather) != len(phase.dates) or len(flow) != len(weather):
            raise ValueError("Normalization dates and values do not match")
        if weather.shape[1:] != (5,) or not np.isfinite(weather).all() or (weather[:, 0] < 0).any():
            raise ValueError("Missing, malformed or negative-rain weather")
        valid = flow[np.isfinite(flow)]
        wet = weather[weather[:, 0] >= 0.1, 0]
        if len(valid) < 2 or np.std(valid) <= 0 or len(wet) == 0:
            raise ValueError("No valid flow variance or wet days; basin cannot execute")
        std = weather.std(axis=0)
        # A constant weather feature contains no variation; centering maps it to zero.
        std = np.where(std > 0, std, 1.0)
        return cls(weather.mean(axis=0), std, float(valid.mean()), float(valid.std()),
                   float(np.quantile(wet, .99, method="linear")), phase.start, phase.end)

    def weather(self, value: torch.Tensor):
        mean = torch.as_tensor(self.weather_mean, dtype=value.dtype, device=value.device)
        std = torch.as_tensor(self.weather_std, dtype=value.dtype, device=value.device)
        return (value - mean) / std

    def as_dict(self):
        return {"weather_mean": self.weather_mean.tolist(), "weather_std": self.weather_std.tolist(),
                "flow_mean": self.flow_mean, "flow_std": self.flow_std, "cap": self.cap,
                "start": self.start.isoformat(), "end": self.end.isoformat()}
