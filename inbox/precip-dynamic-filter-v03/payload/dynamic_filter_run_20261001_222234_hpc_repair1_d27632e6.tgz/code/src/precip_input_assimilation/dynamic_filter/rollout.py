"""Functional rain ledger and predict-then-observe daily advancement."""

from dataclasses import dataclass, replace
from datetime import date, timedelta
import hashlib
import math
import time

import torch

from .network import project_rain
from .protocol import WINDOW


@dataclass(frozen=True)
class Prediction:
    date: date
    q_mm_day: float
    observation_cutoff: date
    state_digest: str
    tensor: torch.Tensor
    locked: bool = True
    direct_applied: torch.Tensor | None = None
    direct_violation: torch.Tensor | None = None


@dataclass(frozen=True)
class Update:
    as_of_date: date
    rain_dates: tuple
    raw: torch.Tensor
    proposal: torch.Tensor
    applied: torch.Tensor
    violation: torch.Tensor
    missing: bool
    cap: float


def calendar_features(current, template):
    first = date(current.year, 1, 1)
    days = (date(current.year + 1, 1, 1) - first).days
    angle = 2. * math.pi * (current - first).days / days
    return template.new_tensor([math.sin(angle), math.cos(angle)])


class Replay:
    def __init__(self, hydro, corrector, scaling, warmup_dates, warmup_weather,
                 kind="rain", sink=None, beta=0., base_cache=None, deadline=None):
        if kind not in ("rain", "historical", "flow", "base", "persistence"):
            raise ValueError(kind)
        self.hydro, self.corrector, self.scaling = hydro, corrector, scaling
        self.kind, self.sink, self.beta, self.base_cache = kind, sink, beta, base_cache
        self.deadline = deadline
        self.raw = warmup_weather.clone()
        self.dates = list(warmup_dates)
        if self.raw.ndim != 2 or self.raw.shape != (len(self.dates), 5) or not self.dates:
            raise ValueError("Warmup weather does not match dates")
        if not torch.isfinite(self.raw).all() or (self.raw[:, 0] < 0).any():
            raise ValueError("Invalid warmup weather")
        if any(b - a != timedelta(days=1) for a, b in zip(self.dates, self.dates[1:])):
            raise ValueError("Warmup dates are not continuous")
        self.applied = self.raw.new_zeros(len(self.raw))
        self._rows = [self._missing_row(d, w, None) for d, w in
                      zip(self.dates[-WINDOW:], self.raw[-WINDOW:], strict=True)]
        self._last = None
        self._outstanding = False
        self._cutoff = self.dates[-1]
        self._flow_applied = self.raw.new_zeros(())
        self._base_today = self.raw.new_zeros(())
        self._yesterday_error = 0.

    def _missing_row(self, current, weather, prediction):
        prior = weather.new_zeros(()) if prediction is None else (
            prediction - self.scaling.flow_mean) / self.scaling.flow_std
        zero = weather.new_zeros(())
        return torch.cat((self.scaling.weather(weather), torch.stack((zero, prior, zero, zero + 1.)),
                          calendar_features(current, weather)))

    def _features(self):
        rows = self._rows[-WINDOW:]
        if len(rows) < WINDOW:
            blank = self.raw.new_zeros(11)
            blank[8] = 1.
            rows = [blank] * (WINDOW - len(rows)) + rows
        return torch.stack(rows)

    def predict(self, current: date, weather_today):
        if self.deadline is not None and time.monotonic() >= self.deadline:
            raise TimeoutError("Bounded technical probe exceeded its deadline")
        if self._outstanding or current != self.dates[-1] + timedelta(days=1):
            raise PermissionError("Predict must advance one day after the preceding observation update")
        weather = torch.as_tensor(weather_today, dtype=self.raw.dtype, device=self.raw.device)
        if weather.shape != (5,) or not torch.isfinite(weather).all() or weather[0] < 0:
            raise ValueError("Missing, malformed or negative-rain daily weather")
        self.raw = torch.cat((self.raw, weather[None]))
        self.applied = torch.cat((self.applied, self.raw.new_zeros(1)))
        self.dates.append(current)
        length = self.hydro.sequence_length
        if len(self.raw) < length:
            raise ValueError("Insufficient weather for the frozen hydrologic window")
        window = self.raw[-length:]
        if self.kind in ("rain", "historical"):
            window = torch.cat(((window[:, 0] + self.applied[-length:])[:, None], window[:, 1:]), dim=1)
        if self.base_cache is not None and self.kind in ("base", "flow", "persistence"):
            base = self.raw.new_tensor(self.base_cache[current])
        else:
            base = self.hydro(window).reshape(())
        self._base_today = base
        direct_applied = direct_violation = None
        if self.kind == "flow":
            _, direct_applied, direct_violation = self.corrector(
                self._features(), self.scaling.weather(weather),
                (base - self.scaling.flow_mean) / self.scaling.flow_std, self._flow_applied)
            self._flow_applied = direct_applied
            predicted = base + direct_applied
        elif self.kind == "persistence":
            predicted = base + self.beta * self._yesterday_error
        else:
            predicted = base
        value = float(predicted.detach())
        if not math.isfinite(value):
            raise RuntimeError("Nonfinite pre-assimilation prediction")
        digest = hashlib.sha256(window.detach().cpu().numpy().tobytes()).hexdigest()
        self._last = Prediction(current, value, self._cutoff, digest, predicted,
                                direct_applied=direct_applied, direct_violation=direct_violation)
        self._outstanding = True
        if self.sink is not None:
            self.sink.prediction(self._last)  # Lock/save before any current observation arrives.
        return self._last

    def observe(self, current, q_mm_day_or_none):
        if not self._outstanding or current != self._last.date:
            raise PermissionError("Observe needs the matching locked prediction and may only occur once")
        missing = q_mm_day_or_none is None or not math.isfinite(float(q_mm_day_or_none))
        weather = self.raw[-1]
        if missing:
            row = self._missing_row(current, weather, self._last.tensor)
            self._yesterday_error = 0.
        else:
            observed = self.raw.new_tensor(float(q_mm_day_or_none))
            normalized_obs = (observed - self.scaling.flow_mean) / self.scaling.flow_std
            normalized_prior = (self._last.tensor - self.scaling.flow_mean) / self.scaling.flow_std
            error = (observed - self._last.tensor) / self.scaling.flow_std
            row = torch.cat((self.scaling.weather(weather), torch.stack(
                (normalized_obs, normalized_prior, error, error.new_zeros(()))), calendar_features(current, weather)))
            self._yesterday_error = float(observed.detach() - self._base_today.detach())
        self._rows = (self._rows + [row])[-WINDOW:]
        begin = max(0, len(self.raw) - WINDOW)
        previous = self.applied[begin:]
        if not missing and self.kind in ("rain", "historical"):
            count = len(previous)
            padding = WINDOW - count
            lag_weather = self.scaling.weather(self.raw[begin:])
            padded_weather = torch.cat((self.raw.new_zeros(padding, 5), lag_weather))
            padded_applied = torch.cat((self.raw.new_zeros(padding), previous))
            lag = torch.arange(WINDOW - 1, -1, -1, dtype=self.raw.dtype, device=self.raw.device)
            proposal = self.corrector(self._features(), padded_weather, padded_applied, lag)[-count:]
            if not torch.isfinite(proposal).all():
                raise RuntimeError("Nonfinite rain proposal")
            _, applied, violation = project_rain(self.raw[begin:, 0], proposal, self.scaling.cap)
            self.applied = torch.cat((self.applied[:begin], applied))
        else:
            proposal = previous
            applied = previous
            violation = previous.new_zeros(previous.shape)
        update = Update(current, tuple(self.dates[begin:]), self.raw[begin:, 0], proposal, applied,
                        violation, missing, self.scaling.cap)
        self._cutoff = current
        self._outstanding = False
        if self.sink is not None:
            self.sink.update(update)
        return update

    def detach_history(self):
        self.applied = self.applied.detach()
        self._rows = [row.detach() for row in self._rows]
        self._flow_applied = self._flow_applied.detach()
        self._base_today = self._base_today.detach()
        if self._last is not None:
            self._last = replace(self._last, tensor=self._last.tensor.detach(),
                                 direct_applied=None if self._last.direct_applied is None else self._last.direct_applied.detach(),
                                 direct_violation=None if self._last.direct_violation is None else self._last.direct_violation.detach())

    @property
    def last_prediction(self):
        return self._last


class ToyHydro:
    sequence_length = 4

    def __call__(self, window):
        return .6 * window[-2, 0] + .2 * window[-4, 0]
