"""Isolated output, artifact identity, and common-date scoring."""

import hashlib
import csv
import json
from pathlib import Path
import sys
import time

import numpy as np

PINNED = {"model_epoch030.pt": "1c755b0d6ce977db38a8332b50160f2a62a732cb7835be8814d7c23f12a70e00",
          "config.yml": "c5487945a42b04662a7ff9fd744dd78c1993d34bfadf31f6457a620cc74dfbfd",
          "train_data/train_data_scaler.yml": "d2a6ce291e137bcf30dbb39f140692882769760f59f71a29d674b02eafde14db"}
PROTECTED = {"neuralhydrology/evaluation/assimilation.py":
             "d924534387faac80f822260c0a70be44b0acb16cc06a2ab9a622e28445773659",
             "neuralhydrology/utils/assimilationconfig.py":
             "f079eb9d6424fa60c95af0d560dc5988d8cf8adb09921cb6877717ec689eff04"}


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def require_identity(repo, run_dir):
    result = {}
    for name, expected in PINNED.items():
        actual = sha256(Path(run_dir) / name)
        if actual != expected:
            raise RuntimeError(f"Frozen artifact changed: {name}")
        result[name] = actual
    for name, expected in PROTECTED.items():
        actual = sha256(Path(repo) / name)
        if actual != expected:
            raise RuntimeError(f"Protected source changed: {name}")
        result[name] = actual
    require_no_forbidden_imports()
    return result


def require_no_forbidden_imports():
    forbidden = {"neuralhydrology.evaluation.assimilation", "neuralhydrology.utils.assimilationconfig"}
    hit = forbidden.intersection(sys.modules)
    if hit:
        raise RuntimeError(f"Forbidden import: {sorted(hit)}")


def new_output(path):
    path = Path(path)
    path.mkdir(parents=True, exist_ok=False)
    return path


def write_json(path, content):
    with Path(path).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(content, handle, indent=2, ensure_ascii=False, allow_nan=False)
        handle.write("\n")


def nse(obs, pred):
    obs, pred = np.asarray(obs), np.asarray(pred)
    if obs.shape != pred.shape:
        raise ValueError("Prediction shape differs from fixed observation grid")
    keep = np.isfinite(obs)
    if not np.isfinite(pred[keep]).all():
        raise RuntimeError("Technical failure: missing/nonfinite prediction on common scoring dates")
    values = obs[keep]
    if len(values) < 2 or np.sum((values - values.mean()) ** 2) <= 0:
        return None
    return float(1. - np.sum((pred[keep] - values) ** 2) / np.sum((values - values.mean()) ** 2))


def score_predictions(dates, obs, predictions):
    obs = np.asarray(obs)
    summary = {name: {"full": nse(obs, values), "annual": {}} for name, values in predictions.items()}
    coverage = {}
    for year in range(1986, 1990):
        begin, end = f"{year-1}-10-01", f"{year}-10-01"
        mask = (np.asarray(dates, dtype="datetime64[D]") >= np.datetime64(begin)) & (
            np.asarray(dates, dtype="datetime64[D]") < np.datetime64(end))
        if not mask.any():
            coverage[str(year)] = 0.
        else:
            coverage[str(year)] = float(np.isfinite(obs[mask]).mean())
        for name, values in predictions.items():
            summary[name]["annual"][str(year)] = nse(obs[mask], np.asarray(values)[mask])
    return {"common_valid_count": int(np.isfinite(obs).sum()), "coverage": coverage, "methods": summary}


def expansion_gate(scores):
    methods = scores["methods"]
    base, persistence = methods["base"], methods["persistence"]
    selected = [methods[f"rain_s{seed}"] for seed in (1001, 1002, 1003)]
    defined = base["full"] is not None and persistence["full"] is not None and all(
        m["full"] is not None and all(v is not None for v in m["annual"].values()) for m in [base] + selected)
    if not defined or any(x < .9 for x in scores["coverage"].values()):
        return {"expand": False, "reason": "undefined efficiency or annual observation coverage below 90%"}
    gains = [m["full"] - base["full"] for m in selected]
    annual = {y: float(np.median([m["annual"][y] - base["annual"][y] for m in selected]))
              for y in base["annual"]}
    delta_persistence = float(np.median([m["full"] - persistence["full"] for m in selected]))
    tests = {"median_gain_at_least_0.005": float(np.median(gains)) >= .005,
             "two_seeds_positive": sum(g > 0 for g in gains) >= 2,
             "three_years_positive": sum(g > 0 for g in annual.values()) >= 3,
             "beats_yesterday_error": delta_persistence > 0}
    return {"expand": all(tests.values()), "tests": tests, "seed_gains": gains,
            "median_gain": float(np.median(gains)), "annual_median_gains": annual,
            "median_gain_over_persistence": delta_persistence,
            "scope": "single-basin flow-estimation evidence; not recovered true precipitation"}


class CsvSink:
    """Pre-observation prediction rows and append-only dated rain versions."""
    def __init__(self, root, checkpoint, write_rain=True):
        self.checkpoint = checkpoint
        self.io_seconds = 0.
        self.pred_handle = (Path(root) / "predictions.csv").open("x", encoding="utf-8", newline="")
        self.rain_handle = (Path(root) / "rain_versions.csv").open("x", encoding="utf-8", newline="") if write_rain else None
        self.pred_writer = csv.writer(self.pred_handle)
        self.rain_writer = csv.writer(self.rain_handle) if write_rain else None
        self.pred_writer.writerow(["date", "q_mm_day", "observation_cutoff", "state_digest", "checkpoint",
                                   "direct_flow_applied_mm_day"])
        if self.rain_writer is not None:
            self.rain_writer.writerow(["rain_date", "as_of_date", "raw_mm", "proposal_mm", "applied_mm", "cap_mm", "missing"])
        self.diagnostics = {"updates": 0, "missing_updates": 0, "rain_versions": 0,
                            "absolute_revision_mm": 0., "dry_added_mm": 0., "touch_upper": 0, "touch_lower": 0}

    def prediction(self, prediction):
        started = time.perf_counter()
        self.pred_writer.writerow([prediction.date, prediction.q_mm_day, prediction.observation_cutoff,
                                   prediction.state_digest, self.checkpoint,
                                   None if prediction.direct_applied is None else float(prediction.direct_applied.detach())])
        self.pred_handle.flush()
        self.io_seconds += time.perf_counter() - started

    def update(self, update):
        started = time.perf_counter()
        self.diagnostics["updates"] += 1
        self.diagnostics["missing_updates"] += int(update.missing)
        if self.rain_writer is None:
            self.io_seconds += time.perf_counter() - started
            return
        raw, proposal, applied = [x.detach().cpu().numpy() for x in (update.raw, update.proposal, update.applied)]
        for day, p, r, a in zip(update.rain_dates, raw, proposal, applied, strict=True):
            self.rain_writer.writerow([day, update.as_of_date, float(p), float(r), float(a), update.cap, int(update.missing)])
            self.diagnostics["rain_versions"] += 1
            self.diagnostics["absolute_revision_mm"] += abs(float(a))
            self.diagnostics["dry_added_mm"] += float(max(a, 0)) if p < .1 else 0.
            self.diagnostics["touch_upper"] += int(a >= update.cap - 1e-6)
            self.diagnostics["touch_lower"] += int(a <= -min(p, update.cap) + 1e-6)
        self.io_seconds += time.perf_counter() - started

    def close(self):
        self.pred_handle.close()
        if self.rain_handle is not None:
            self.rain_handle.close()
