"""Synthetic gate or bounded 64-day real frozen-model resource probe."""

from pathlib import Path
import argparse
from datetime import timedelta, datetime, timezone
import json
import os
import subprocess
import sys
import time
import threading

REPO = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(REPO), str(REPO / "src")]
sys.dont_write_bytecode = True

import numpy as np
import psutil
import torch

from precip_input_assimilation.dynamic_filter.network import RainCorrector
from precip_input_assimilation.dynamic_filter.protocol import FIT_START, Phase, Scaling
from precip_input_assimilation.dynamic_filter.real_data import (FrozenHydro, load_inputs, replay_factory,
                                                               require_sources, source_snapshot)
from precip_input_assimilation.dynamic_filter.report import CsvSink, new_output, require_identity, sha256, write_json
from precip_input_assimilation.dynamic_filter.training import replay_phase, train_epoch
from precip_input_assimilation.selfrule.model import configure_determinism


def synthetic(root):
    temp = REPO / "src/precip_input_assimilation/tests/_tmp" / root.name
    temp.mkdir(parents=True, exist_ok=False)
    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",
                       OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", TMP=str(temp), TEMP=str(temp), TMPDIR=str(temp))
    names = ("projection", "causality", "training")
    command = [sys.executable, "-B", "-m", "pytest", "--noconftest", "-p", "no:cacheprovider",
               "--basetemp", str(temp / "pytest"), "--junitxml", str(root / "tests.xml")]
    command += [str(REPO / f"src/precip_input_assimilation/tests/test_dynamic_filter_{name}.py") for name in names]
    command += ["-q"]
    started = time.perf_counter()
    process = subprocess.run(command, cwd=REPO, env=environment, capture_output=True, text=True, timeout=600)
    with (root / "tests_stdout.txt").open("x", encoding="utf-8") as handle:
        handle.write(process.stdout + process.stderr)
    result = {"success": process.returncode == 0, "kind": "synthetic", "command": command,
              "seconds": time.perf_counter() - started, "exit_code": process.returncode,
              "sources": source_snapshot(REPO), "scope": "no real weather, flow, model weights or HPC"}
    write_json(root / "technical_gate.json", result)
    print(process.stdout, flush=True)
    if not result["success"]:
        raise RuntimeError("Synthetic gate failed")


def synchronize(device):
    if str(device).startswith("cuda"):
        torch.cuda.synchronize(device)


def probe(args, root):
    technical = json.loads(Path(args.technical_record).read_text(encoding="utf-8"))
    if not technical["success"] or technical["kind"] != "synthetic":
        raise RuntimeError("A successful synthetic gate is required")
    require_sources(REPO, technical["sources"])
    identities = require_identity(REPO, args.model_dir)
    memory_before = psutil.virtual_memory().available
    if str(args.device).startswith("cuda"):
        gpu_free_before, gpu_total = torch.cuda.mem_get_info(args.device)
        torch.cuda.reset_peak_memory_stats(args.device)
    else:
        gpu_free_before = gpu_total = 0
    torch.set_num_threads(2)
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False
    samples = {"device_used_peak": 0, "process_ram_sampled_peak": 0}
    stop_sampling = threading.Event()

    def sample():
        while not stop_sampling.is_set():
            samples["process_ram_sampled_peak"] = max(samples["process_ram_sampled_peak"], psutil.Process().memory_info().rss)
            if str(args.device).startswith("cuda"):
                free, total = torch.cuda.mem_get_info(args.device)
                samples["device_used_peak"] = max(samples["device_used_peak"], total - free)
            stop_sampling.wait(.1)

    sampler = threading.Thread(target=sample, daemon=True)
    sampler.start()
    configure_determinism(1001)
    began = time.perf_counter()
    phase = Phase("probe", FIT_START, FIT_START + timedelta(days=63))
    inputs = load_inputs(args.data_dir, args.model_dir, phase.end, REPO)
    observations = inputs.observations_for(phase)
    weather = inputs.weather_for(phase)
    scaling = Scaling.fit(weather, observations, phase)
    hydro = FrozenHydro(args.data_dir, args.model_dir, args.device)
    state_before = hydro.state_hash()
    loading_seconds = time.perf_counter() - began
    deadline = time.monotonic() + max(0., 1800. - loading_seconds)
    factory = replay_factory(hydro, inputs, scaling, "rain", deadline=deadline)
    network = RainCorrector(scaling.cap).to(args.device)
    started = time.perf_counter()
    logging_root = new_output(root / "zero_parity_logging")
    sink = CsvSink(logging_root, "frozen_zero_head")
    logging_factory = replay_factory(hydro, inputs, scaling, "rain", deadline=deadline, sink=sink)
    try:
        zero = replay_phase(logging_factory(network), phase, weather, observations)
    finally:
        sink.close()
    synchronize(args.device)
    replay_seconds = time.perf_counter() - started
    positions = np.array([inputs.dates.index(day) for day in phase.dates])
    reference = hydro.direct(inputs.weather, positions, batch=1)
    batched_reference = hydro.direct(inputs.weather, positions, batch=64)
    batch64_difference = float(np.max(np.abs(reference - batched_reference)))
    maximum_difference = float(np.max(np.abs(zero - reference)))
    tolerance = 1e-5 * (1. + float(np.max(np.abs(reference))))
    if maximum_difference > tolerance:
        raise RuntimeError(f"Zero-rain parity failed: {maximum_difference} > {tolerance}")
    training_phase = Phase("probe", phase.start, phase.start + timedelta(days=32))
    optimizer = torch.optim.Adam(network.parameters(), lr=.001)
    training = train_epoch(factory(network), training_phase, weather[:33], observations[:33], optimizer, .001)
    synchronize(args.device)
    if not any(record["gradient_norm"] > 0 and record["nonzero_grad_parameters"] > 0 for record in training):
        raise RuntimeError("Real correction gradient is zero")
    if any(parameter.grad is not None or parameter.requires_grad for parameter in hydro.frozen.model.parameters()):
        raise RuntimeError("Frozen hydrologic weights received parameter gradients")
    state_after = hydro.state_hash()
    if state_before != state_after:
        raise RuntimeError("Frozen tensor weights changed")
    if hydro.frozen.model.dropout.training:
        raise RuntimeError("Output dropout was activated")
    require_sources(REPO, technical["sources"])
    require_identity(REPO, args.model_dir)
    cuda_allocated = torch.cuda.max_memory_allocated(args.device) if str(args.device).startswith("cuda") else 0
    cuda_reserved = torch.cuda.max_memory_reserved(args.device) if str(args.device).startswith("cuda") else 0
    process_memory = psutil.Process().memory_info()
    ram_peak = int(getattr(process_memory, "peak_wset", process_memory.rss))
    stop_sampling.set()
    sampler.join(timeout=1.)
    train_segment_seconds = training[0]["seconds"]
    no_grad_day_seconds = replay_seconds / 64.
    training_upper = 27 * 60 * 46 * train_segment_seconds
    validation_upper = 27 * 60 * 1826 * no_grad_day_seconds
    scoring_upper = 11 * 3287 * no_grad_day_seconds
    estimate = 1.25 * (loading_seconds + training_upper + validation_upper + scoring_upper)
    enough_gpu = not str(args.device).startswith("cuda") or gpu_free_before >= 1.25 * cuda_reserved
    enough_ram = memory_before >= 1.25 * ram_peak
    report = {"success": True, "kind": "probe", "device": args.device,
              "date_utc": datetime.now(timezone.utc).isoformat(), "basin": "01022500",
              "phase": [str(phase.start), str(phase.end)], "normalization": scaling.as_dict(),
              "normalization_scope": "64-day probe only; not the scientific fit normalization",
              "identity": identities, "model_tensor_sha256": state_after,
              "sources": technical["sources"], "synthetic_gate_sha256": sha256(args.technical_record),
              "data_canonical_hashes": inputs.hashes, "zero_parity_max_error": maximum_difference,
              "reference_batch_size": 1, "batch64_fp32_diagnostic_max_error": batch64_difference,
              "numeric_runtime": {"cudnn_tf32": False, "matmul_tf32": False},
              "zero_parity_tolerance": tolerance, "frozen_parameter_grads_empty": True,
              "output_dropout_disabled": True, "training_segments": training,
              "seconds": {"load": loading_seconds, "no_grad_64_days": replay_seconds,
                          "result_save_64_days": sink.io_seconds,
                          "train_32_plus_closing": train_segment_seconds,
                          "estimated_full_worst_with_25_percent_margin": estimate},
              "resources": {"cuda_allocated_peak": cuda_allocated, "cuda_reserved_peak": cuda_reserved,
                            "cuda_free_before": gpu_free_before, "cuda_total": gpu_total,
                            "system_ram_available_before": memory_before, "process_ram_peak": ram_peak,
                            "sampled_device_used_peak": samples["device_used_peak"],
                            "sampled_process_ram_peak": samples["process_ram_sampled_peak"],
                            "headroom_factor": 1.25},
              "resource_gate": {"enough_gpu": enough_gpu, "enough_ram": enough_ram,
                                "needs_hpc": estimate > 6 * 3600 or not enough_gpu or not enough_ram},
              "historical_model_selection": "unknown, disclosed; does not authorize protected-year reads"}
    write_json(root / "probe_gate.json", report)
    print(json.dumps({"max_error": maximum_difference, "tolerance": tolerance,
                      "gradient_norm": training[0]["gradient_norm"], "train_segment_seconds": train_segment_seconds,
                      "no_grad_64_seconds": replay_seconds, "full_upper_hours": estimate / 3600.,
                      "resource_gate": report["resource_gate"]}), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("synthetic", "probe"))
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--technical-record", type=Path)
    parser.add_argument("--model-dir", type=Path, default=REPO / "results/precip_input_da_2026_09/received/seq1/pida_0b1/C4_s100")
    parser.add_argument("--data-dir", type=Path, default=REPO / "data/camels_us")
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()
    root = new_output(args.output)
    try:
        if args.mode == "synthetic":
            synthetic(root)
        else:
            if args.technical_record is None:
                raise ValueError("--technical-record is required for a real probe")
            probe(args, root)
    except Exception as error:
        write_json(root / "failure.json", {"type": type(error).__name__, "error": str(error), "scope": args.mode})
        raise


if __name__ == "__main__":
    main()
