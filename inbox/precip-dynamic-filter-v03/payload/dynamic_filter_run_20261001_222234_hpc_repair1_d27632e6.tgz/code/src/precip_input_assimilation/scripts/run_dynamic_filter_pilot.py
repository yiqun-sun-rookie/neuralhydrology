"""The approved fixed single-basin 27-fit pilot; no automatic expansion."""

from pathlib import Path
import argparse
from datetime import datetime, timezone
import json
import sys
import time

REPO = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(REPO), str(REPO / "src")]
sys.dont_write_bytecode = True

import numpy as np
import torch

from precip_input_assimilation.dynamic_filter.network import FlowCorrector, RainCorrector
from precip_input_assimilation.dynamic_filter.protocol import (FIT_START, FIT_END, SELECT_START, SELECT_END,
                                                            SCORE_START, SCORE_END, Phase, Scaling, SEEDS, PENALTIES)
from precip_input_assimilation.dynamic_filter.real_data import (FrozenHydro, load_inputs, replay_factory,
                                                               require_sources, source_snapshot)
from precip_input_assimilation.dynamic_filter.report import (CsvSink, expansion_gate, new_output,
                                                            require_identity, score_predictions, sha256, write_json)
from precip_input_assimilation.dynamic_filter.training import replay_phase, train_one
from precip_input_assimilation.selfrule.model import configure_determinism


def network_for(kind, scaling, seed, device):
    configure_determinism(seed)
    net = FlowCorrector(scaling.flow_std) if kind == "flow" else RainCorrector(scaling.cap, historical=kind == "historical")
    return net.to(device)


def require_probe(path, device):
    probe = json.loads(Path(path).read_text(encoding="utf-8"))
    if not probe["success"] or probe["kind"] != "probe":
        raise RuntimeError("A successful bounded real probe is required")
    require_sources(REPO, probe["sources"])
    if device.startswith("cuda"):
        free, _ = torch.cuda.mem_get_info(device)
        if free < 1.25 * probe["resources"]["cuda_reserved_peak"]:
            raise RuntimeError("Current GPU cannot meet the measured headroom requirement")
    import psutil
    if psutil.virtual_memory().available < 1.25 * probe["resources"]["process_ram_peak"]:
        raise RuntimeError("Current system memory cannot meet the measured headroom requirement")
    return probe


def baseline_cache(hydro, inputs, start, end):
    dates = tuple(d for d in inputs.dates if start <= d <= end)
    indices = np.asarray([inputs.dates.index(day) for day in dates])
    return dict(zip(dates, hydro.direct(inputs.weather, indices, batch=1), strict=True))


def persistence_coefficient(fit_phase, fit_values, base_cache):
    error = fit_values - np.asarray([base_cache[d] for d in fit_phase.dates])
    valid = np.isfinite(error[:-1]) & np.isfinite(error[1:])
    x, y = error[:-1][valid], error[1:][valid]
    denominator = float(np.dot(x, x))
    return float(np.clip(np.dot(x, y) / denominator, 0., 1.)) if denominator > 0 else 0.


def frozen_contract():
    return {"basin": "01022500", "fit": [str(FIT_START), str(FIT_END)],
            "select": [str(SELECT_START), str(SELECT_END)], "score": [str(SCORE_START), str(SCORE_END)],
            "seeds": list(SEEDS), "penalties": list(PENALTIES), "max_epochs": 60, "patience": 10,
            "learning_rate": .001, "window": 100, "segment_days": 32, "horizon_semantics":
            "same-day-weather daily estimate locked before current flow; not an issued day-ahead forecast",
            "historical_model_selection": "unknown and disclosed", "old_multiplier_gpu_seconds": 5312,
            "track": "standalone past-observed-flow single-basin pilot; no track0 claim",
            "automatic_expansion": False}


def train_stage(args, root, probe):
    fit_phase, select_phase = Phase("fit", FIT_START, FIT_END), Phase("select", SELECT_START, SELECT_END)
    identities = require_identity(REPO, args.model_dir)
    inputs = load_inputs(args.data_dir, args.model_dir, SELECT_END, REPO)
    fit_values, select_values = inputs.observations_for(fit_phase), inputs.observations_for(select_phase)
    fit_weather, select_weather = inputs.weather_for(fit_phase), inputs.weather_for(select_phase)
    scaling = Scaling.fit(fit_weather, fit_values, fit_phase)
    hydro = FrozenHydro(args.data_dir, args.model_dir, args.device)
    before = hydro.state_hash()
    cache = baseline_cache(hydro, inputs, FIT_START, SELECT_END)
    beta = persistence_coefficient(fit_phase, fit_values, cache)
    manifest = {"contract": frozen_contract(), "scaling": scaling.as_dict(), "identity": identities,
                "sources": probe["sources"], "data": inputs.hashes, "beta": beta,
                "probe_gate_sha256": sha256(args.probe_record), "device": args.device,
                "date_utc": datetime.now(timezone.utc).isoformat()}
    write_json(root / "run_manifest.json", manifest)
    records = []
    for kind in ("rain", "flow", "historical"):
        for penalty in PENALTIES:
            for seed in SEEDS:
                require_sources(REPO, probe["sources"])
                directory = new_output(root / "fits" / kind / f"penalty_{penalty:g}" / f"seed_{seed}")
                network = network_for(kind, scaling, seed, args.device)
                factory = replay_factory(hydro, inputs, scaling, kind, base_cache=cache)
                print(f"fit_start kind={kind} penalty={penalty:g} seed={seed}", flush=True)
                fitted = train_one(network, factory, fit_phase, fit_weather, fit_values,
                                   select_phase, select_weather, select_values, penalty, directory, seed)
                fitted.update(kind=kind, checkpoint=str((directory / "selected.pt").relative_to(root)))
                fitted["checkpoint_sha256"] = sha256(directory / "selected.pt")
                records.append(fitted)
                write_json(directory / "fit_summary.json", fitted)
                if hydro.state_hash() != before:
                    raise RuntimeError("Frozen tensor identity changed during training")
                require_identity(REPO, args.model_dir)
                require_sources(REPO, probe["sources"])
    selected = []
    for kind in ("rain", "flow", "historical"):
        mean_scores = {penalty: float(np.mean([r["validation_nse"] for r in records
                                             if r["kind"] == kind and r["penalty"] == penalty])) for penalty in PENALTIES}
        penalty = max(PENALTIES, key=lambda p: (mean_scores[p], p))
        selected.extend(r for r in records if r["kind"] == kind and r["penalty"] == penalty)
        print(f"selection_locked kind={kind} penalty={penalty:g} validation_mean={mean_scores[penalty]:.6f}", flush=True)
    selection = {"selected": selected, "all_fits": records, "scaling": scaling.as_dict(), "beta": beta,
                 "run_manifest_sha256": sha256(root / "run_manifest.json"),
                 "model_tensor_sha256": before, "sources": probe["sources"],
                 "score_observations_read": False}
    write_json(root / "selection_locked.json", selection)
    return selection


def score_stage(args, root, training_root, selection, probe):
    # Only now, after all methods/settings/checkpoints are selected and recorded, open scoring values.
    require_sources(REPO, selection["sources"])
    require_identity(REPO, args.model_dir)
    phases = [Phase("fit", FIT_START, FIT_END), Phase("select", SELECT_START, SELECT_END),
              Phase("score", SCORE_START, SCORE_END)]
    inputs = load_inputs(args.data_dir, args.model_dir, SCORE_END, REPO)
    values = {p.name: inputs.observations_for(p) for p in phases}
    fit_weather = inputs.weather_for(phases[0])
    scaling = Scaling.fit(fit_weather, values["fit"], phases[0])
    if scaling.as_dict() != selection["scaling"]:
        raise RuntimeError("Fit-only normalization changed since selection")
    hydro = FrozenHydro(args.data_dir, args.model_dir, args.device)
    if hydro.state_hash() != selection["model_tensor_sha256"]:
        raise RuntimeError("Frozen tensor identity differs from training")
    cache = baseline_cache(hydro, inputs, FIT_START, SCORE_END)
    predictions = {}
    candidates = [{"kind": "base"}, {"kind": "persistence"}] + selection["selected"]
    for candidate in candidates:
        kind = candidate["kind"]
        name = kind if "seed" not in candidate else f"{kind}_s{candidate['seed']}"
        directory = new_output(root / "scoring" / name)
        network = None
        checkpoint_hash = "frozen_base" if kind == "base" else f"fit_beta={selection['beta']:.17g}"
        if "checkpoint" in candidate:
            checkpoint = training_root / candidate["checkpoint"]
            if sha256(checkpoint) != candidate["checkpoint_sha256"]:
                raise RuntimeError("Selected checkpoint changed after locking")
            network = network_for(kind, scaling, candidate["seed"], args.device)
            network.load_state_dict(torch.load(checkpoint, map_location=args.device, weights_only=True)["state_dict"])
            network.eval()
            checkpoint_hash = candidate["checkpoint_sha256"]
        sink = CsvSink(directory, checkpoint_hash, write_rain=kind in ("rain", "historical"))
        factory = replay_factory(hydro, inputs, scaling, kind, sink=sink, beta=selection["beta"], base_cache=cache)
        replay = factory(network)
        score_values = None
        try:
            for phase in phases:
                result = replay_phase(replay, phase, inputs.weather_for(phase), values[phase.name])
                if phase.name == "score":
                    score_values = result
        finally:
            sink.close()
        predictions[name] = score_values
        raw = replay.raw[:, 0].detach().cpu().numpy()
        final_applied = replay.applied.detach().cpu().numpy()
        diagnostics = dict(sink.diagnostics,
                           final_daily_absolute_correction_mm=float(np.abs(final_applied).sum()),
                           final_dry_added_mm=float(np.maximum(final_applied[raw < .1], 0).sum()),
                           final_correction_scope="final as-of record over weather warmup plus fit/select/score",
                           checkpoint_sha256=checkpoint_hash)
        write_json(directory / "diagnostics.json", diagnostics)
        print(f"scoring_done method={name} days={len(score_values)}", flush=True)
    scores = score_predictions(phases[-1].dates, values["score"], predictions)
    scores["expansion_gate"] = expansion_gate(scores)
    scores["data_hashes"] = inputs.hashes
    scores["contract"] = frozen_contract()
    scores["selection_locked_sha256"] = sha256(training_root / "selection_locked.json")
    require_sources(REPO, probe["sources"])
    require_identity(REPO, args.model_dir)
    if hydro.state_hash() != selection["model_tensor_sha256"]:
        raise RuntimeError("Frozen hydrologic state tensors changed during scoring")
    write_json(root / "summary.json", scores)
    print(json.dumps(scores["expansion_gate"], ensure_ascii=False), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=("all", "train", "score"), default="all")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--probe-record", required=True, type=Path)
    parser.add_argument("--training-root", type=Path)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--data-dir", type=Path, default=REPO / "data/camels_us")
    parser.add_argument("--model-dir", type=Path, default=REPO / "results/precip_input_da_2026_09/received/seq1/pida_0b1/C4_s100")
    args = parser.parse_args()
    root = new_output(args.output)
    try:
        torch.set_num_threads(2)
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cuda.matmul.allow_tf32 = False
        probe = require_probe(args.probe_record, args.device)
        require_identity(REPO, args.model_dir)
        if args.stage in ("all", "train"):
            selection = train_stage(args, root, probe)
            training_root = root
        else:
            if args.training_root is None:
                raise ValueError("--training-root required for scoring selected fits")
            training_root = args.training_root
            selection = json.loads((training_root / "selection_locked.json").read_text(encoding="utf-8"))
        if args.stage in ("all", "score"):
            score_stage(args, root, training_root, selection, probe)
        write_json(root / "complete.json", {"stage": args.stage, "success": True, "automatic_expansion": False})
    except Exception as error:
        write_json(root / "failure.json", {"type": type(error).__name__, "error": str(error), "stage": args.stage})
        raise


if __name__ == "__main__":
    main()
