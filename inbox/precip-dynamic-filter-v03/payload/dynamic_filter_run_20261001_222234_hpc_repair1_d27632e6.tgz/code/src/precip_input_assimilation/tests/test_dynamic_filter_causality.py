"""Nonzero positive controls test the actual closed-loop replay."""

from datetime import date, timedelta
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

import numpy as np
import pytest
import torch
from torch import nn

from precip_input_assimilation.dynamic_filter.network import FlowCorrector, RainCorrector
from precip_input_assimilation.dynamic_filter.protocol import Scaling
from precip_input_assimilation.dynamic_filter.rollout import Replay, ToyHydro


class MemorySink:
    def __init__(self):
        self.predictions, self.updates = [], []

    def prediction(self, prediction):
        self.predictions.append((prediction.date, prediction.q_mm_day, prediction.state_digest))

    def update(self, update):
        self.updates.append((update.as_of_date, update.rain_dates, update.applied.detach().clone()))


class Innovation(nn.Module):
    def forward(self, features, lag_weather, previous_applied, lag_days):
        return torch.cat((previous_applied[:-1], (.1 * features[-1, 7]).reshape(1)))


class ConstantRain(nn.Module):
    def __init__(self, amount=.2):
        super().__init__()
        self.amount = nn.Parameter(torch.tensor(amount, dtype=torch.float64))

    def forward(self, features, lag_weather, previous_applied, lag_days):
        return self.amount.expand(100)


def scaling():
    return Scaling(np.zeros(5), np.ones(5), 0., 1., 10., date(2010, 1, 1), date(2010, 1, 2))


def make_replay(network, sink=None, warmup=10):
    start = date(2010, 1, 1)
    days = tuple(start - timedelta(days=i) for i in range(warmup, 0, -1))
    return Replay(ToyHydro(), network, scaling(), days,
                  torch.full((warmup, 5), .5, dtype=torch.float64), sink=sink)


def run(network_type, changed_obs=False, changed_weather=False):
    torch.manual_seed(11)
    network = Innovation() if network_type == "fixture" else RainCorrector(10.).double()
    if network_type == "actual":
        for p in network.parameters():
            nn.init.constant_(p, .01)
    sink = MemorySink()
    replay = make_replay(network, sink)
    with torch.no_grad():
        for i in range(160):
            current = date(2010, 1, 1) + timedelta(days=i)
            weather = torch.full((5,), 3. if changed_weather and i >= 120 else .5, dtype=torch.float64)
            replay.predict(current, weather)
            replay.observe(current, 2. + (2. if changed_obs and i == 119 else 0.))
    return sink


@pytest.mark.parametrize("network_type", ["fixture", "actual"])
def test_current_observation_changes_update_but_never_locked_prediction(network_type):
    original, changed = run(network_type), run(network_type, changed_obs=True)
    assert original.predictions[:120] == changed.predictions[:120]
    assert not torch.equal(original.updates[119][2], changed.updates[119][2])
    assert abs(original.predictions[120][1] - changed.predictions[120][1]) > 1e-12


def test_future_weather_cannot_change_prior_estimates():
    original, changed = run("actual"), run("actual", changed_weather=True)
    assert original.predictions[:120] == changed.predictions[:120]


def test_direct_flow_control_uses_only_past_observed_flow():
    results = []
    for changed in (False, True):
        network = FlowCorrector(1.).double()
        for p in network.parameters():
            nn.init.constant_(p, .01)
        replay = make_replay(network)
        replay.kind = "flow"
        values = []
        with torch.no_grad():
            for i in range(125):
                day = date(2010, 1, 1) + timedelta(days=i)
                pred = replay.predict(day, torch.full((5,), .5, dtype=torch.float64))
                values.append(pred.q_mm_day)
                replay.observe(day, 2. + (2. if changed and i == 119 else 0.))
        results.append(values)
    assert results[0][:120] == results[1][:120]
    assert abs(results[0][120] - results[1][120]) > 1e-12


def test_total_correction_does_not_accumulate_and_old_dates_finalize():
    replay = make_replay(ConstantRain())
    with torch.no_grad():
        for i in range(140):
            current = date(2010, 1, 1) + timedelta(days=i)
            replay.predict(current, torch.full((5,), .5, dtype=torch.float64))
            replay.observe(current, 1.)
    torch.testing.assert_close(replay.applied, torch.full_like(replay.applied, .2))
    old = replay.applied[:-99].clone()
    replay.corrector.amount.data.fill_(.3)
    replay.predict(date(2010, 1, 1) + timedelta(days=140), torch.full((5,), .5, dtype=torch.float64))
    replay.observe(date(2010, 1, 1) + timedelta(days=140), 1.)
    torch.testing.assert_close(old, replay.applied[:len(old)])


def test_zero_output_parity_missing_recovery_leap_and_duplicate_observation():
    replay = make_replay(RainCorrector(10).double(), warmup=3)
    before = replay.predict(date(2010, 1, 1), torch.full((5,), .5, dtype=torch.float64))
    assert before.q_mm_day == pytest.approx(.4)
    replay.observe(before.date, None)
    with pytest.raises(PermissionError):
        replay.observe(before.date, 1.)
    for i in range(1, 10):
        pred = replay.predict(date(2010, 1, 1) + timedelta(days=i), torch.full((5,), .5, dtype=torch.float64))
        replay.observe(pred.date, float("nan") if i < 5 else 1.)
        assert pred.q_mm_day == pytest.approx(.4)
    assert before.q_mm_day == pytest.approx(.4)
    from precip_input_assimilation.dynamic_filter.rollout import calendar_features
    a = calendar_features(date(2012, 2, 29), torch.zeros(1, dtype=torch.float64))
    assert torch.isfinite(a).all()
    with pytest.raises(PermissionError):
        replay.predict(date(2010, 1, 20), torch.full((5,), .5, dtype=torch.float64))
