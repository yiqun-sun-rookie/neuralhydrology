"""Segment closure, terminal/empty segments, and fixed-weight numerical parity."""

from datetime import date, timedelta
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

import numpy as np
import torch
from torch import nn

from precip_input_assimilation.dynamic_filter.network import RainCorrector
from precip_input_assimilation.dynamic_filter.protocol import Phase, Scaling
from precip_input_assimilation.dynamic_filter.rollout import Replay, ToyHydro
from precip_input_assimilation.dynamic_filter.training import segments, train_epoch


def setup(network, length, sink=None, hydro=None):
    first = date(1980, 10, 1)
    phase = Phase("synthetic", first, first + timedelta(days=length - 1))
    scale = Scaling(np.zeros(5), np.ones(5), 0., 1., 10., phase.start, phase.end)
    replay = Replay(hydro or ToyHydro(), network, scale,
                    tuple(first - timedelta(days=i) for i in range(10, 0, -1)),
                    torch.full((10, 5), .5, dtype=torch.float64), sink=sink)
    return replay, phase, torch.full((length, 5), .5, dtype=torch.float64)


class Day32(nn.Module):
    def __init__(self):
        super().__init__()
        self.value = nn.Parameter(torch.tensor(.2, dtype=torch.float64))
        self.calls = 0

    def forward(self, features, lag_weather, previous_applied, lag_days):
        self.calls += 1
        last = self.value.reshape(1) if self.calls == 32 else previous_applied[-1:]
        return torch.cat((previous_applied[:-1], last))


def test_day_32_update_gets_day_33_flow_gradient():
    network = Day32()
    replay, phase, weather = setup(network, 33)
    records = train_epoch(replay, phase, weather, np.ones(33), None, 0.)
    assert records[0]["closing"] == str(phase.end)
    assert network.value.grad is not None and torch.isfinite(network.value.grad)
    assert network.value.grad.abs().item() > 0


def test_1461_day_layout_has_terminal_21_without_next_year_target():
    layout = segments(1461)
    assert len(layout) == 46
    assert layout[-1].stop - layout[-1].start == 21 and layout[-1].closing is None
    network = RainCorrector(10.).double()
    replay, phase, weather = setup(network, 53)
    before = [p.detach().clone() for p in network.parameters()]
    optimizer = torch.optim.Adam(network.parameters(), lr=.001)
    records = train_epoch(replay, phase, weather, np.full(53, np.nan), optimizer, .001)
    assert records[-1]["closing"] is None and records[-1]["stop"] == str(phase.end)
    assert all(not r["differentiable"] for r in records)
    assert records[0]["missing_closing_followup"] == 1
    assert all(torch.equal(p, old) for p, old in zip(network.parameters(), before))


def test_regularization_only_is_not_recorded_as_flow_learning():
    class ConstantHydro:
        sequence_length = 4

        def __call__(self, window):
            return window.new_zeros(())

    network = RainCorrector(10.).double()
    network.decoder[-1].bias.data.fill_(.01)
    replay, phase, weather = setup(network, 4, hydro=ConstantHydro())
    records = train_epoch(replay, phase, weather, np.ones(4), None, .001)
    assert records[0]["regularization_only"] and not records[0]["flow_supervised"]
    assert records[0]["magnitude_items"] == 11 + 12 + 13


def test_fixed_weights_full_and_truncated_numeric_rollouts_match():
    class Sink:
        def __init__(self):
            self.values = []

        def prediction(self, p):
            self.values.append(p.q_mm_day)

        def update(self, update):
            pass

    results = []
    for width in (32, 64):
        network = RainCorrector(10.).double()
        for p in network.parameters():
            nn.init.constant_(p, .01)
        sink = Sink()
        replay, phase, weather = setup(network, 64, sink)
        train_epoch(replay, phase, weather, np.linspace(1., 2., 64), None, .001, width=width)
        results.append(sink.values)
    np.testing.assert_allclose(results[0], results[1], rtol=0, atol=1e-12)


def test_same_local_losses_and_detached_entrance_have_identical_gradients():
    gradients = []
    for width in (32, 64):
        network = RainCorrector(10.).double()
        for p in network.parameters():
            nn.init.constant_(p, .01)
        replay, _, _ = setup(network, 64)
        with torch.no_grad():
            for i in range(32):
                day = date(1980, 10, 1) + timedelta(days=i)
                replay.predict(day, torch.full((5,), .5, dtype=torch.float64))
                replay.observe(day, 1.)
        replay.detach_history()
        phase = Phase("synthetic", date(1980, 11, 2), date(1980, 12, 3))
        train_epoch(replay, phase, torch.full((32, 5), .5, dtype=torch.float64), np.ones(32), None,
                    .001, width=width)
        gradients.append(torch.cat([p.grad.reshape(-1) for p in network.parameters()]))
    torch.testing.assert_close(gradients[0], gradients[1], rtol=0, atol=1e-12)
