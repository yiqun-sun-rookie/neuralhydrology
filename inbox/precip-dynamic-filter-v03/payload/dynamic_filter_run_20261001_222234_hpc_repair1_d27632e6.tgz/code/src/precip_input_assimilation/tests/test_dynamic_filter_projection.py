"""Projection, data-access sentinels and identical scoring date checks."""

from datetime import date, timedelta
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

import numpy as np
import pytest
import torch

from precip_input_assimilation.dynamic_filter.network import FlowCorrector, RainCorrector, project_rain
from precip_input_assimilation.dynamic_filter.protocol import FIT_END, FIT_START, Phase, Scaling
from precip_input_assimilation.dynamic_filter.report import nse, require_no_forbidden_imports
from precip_input_assimilation.dynamic_filter.stream import ObservationStream, read_flow


@pytest.mark.parametrize("proposal,expected", [(-5., -1), (15., 1)])
def test_exterior_penalty_points_back_to_legal_interval(proposal, expected):
    r = torch.tensor([proposal], requires_grad=True)
    _, a, v = project_rain(torch.zeros(1), r, 10.)
    v.sum().backward()
    assert torch.isfinite(r.grad).all() and r.grad.item() * expected > 0
    assert 0 <= a.item() <= 10


def test_zero_rain_day_can_receive_rain_gradient():
    r = torch.zeros(1, requires_grad=True)
    rain, _, _ = project_rain(torch.zeros(1), r, 10.)
    rain.sum().backward()
    assert r.grad.item() == 1.


def test_total_correction_and_bounds():
    p = torch.tensor([0., 3., 40.])
    _, a, _ = project_rain(p, torch.tensor([-2., -20., -100.]), 10.)
    torch.testing.assert_close(a, torch.tensor([0., -3., -10.]))
    assert torch.all(p + a >= 0)


def test_matched_network_capacity():
    nets = [RainCorrector(10), RainCorrector(10, historical=True), FlowCorrector(1)]
    assert [sum(p.numel() for p in n.parameters()) for n in nets] == [5633] * 3
    assert all(torch.count_nonzero(n.decoder[-1].weight) == 0 for n in nets)


def test_forbidden_request_fails_before_opening(tmp_path):
    phase = Phase("fit", FIT_START, FIT_END)
    with pytest.raises(PermissionError):
        read_flow(tmp_path / "does_not_exist", "01022500", 1., phase, end=date(1989, 10, 1))
    with pytest.raises(PermissionError):
        Phase("score", date(1989, 10, 1), date(1990, 1, 1))


def test_date_gate_does_not_parse_outside_values(tmp_path):
    path = tmp_path / "flow.txt"
    path.write_text("01022500 1980 09 30 DO_NOT_PARSE\n01022500 1980 10 01 1\n"
                    "01022500 1980 10 02 2\n01022500 1980 10 03 DO_NOT_PARSE\n", encoding="utf-8")
    phase = Phase("probe", FIT_START, FIT_START + timedelta(days=1))
    dates, values = read_flow(path, "01022500", 1., phase)
    assert len(dates) == 2 and np.isfinite(values).all()


def test_observation_release_requires_lock_and_does_not_evaluate_future():
    from types import SimpleNamespace

    class Sentinel:
        def __float__(self):
            raise AssertionError("Future observation was evaluated")

    phase = Phase("synthetic", date(2010, 1, 1), date(2010, 1, 2))
    source = ObservationStream(phase, [1., Sentinel()])
    with pytest.raises(PermissionError):
        source.release(SimpleNamespace(locked=False, date=phase.start))
    assert source.release(SimpleNamespace(locked=True, date=phase.start)).value == 1.
    with pytest.raises(PermissionError):
        source.release(SimpleNamespace(locked=True, date=phase.start))


def test_normalization_cannot_use_selection_or_score():
    phase = Phase("select", date(1984, 10, 1), date(1984, 10, 2))
    with pytest.raises(PermissionError):
        Scaling.fit(np.ones((2, 5)), [1., 2.], phase)


def test_nonfinite_prediction_is_failure_not_a_dropped_day():
    with pytest.raises(RuntimeError):
        nse([1., 2., 3.], [1., float("nan"), 3.])
    assert nse([1., float("nan"), 3.], [1., float("nan"), 3.]) == 1.
    assert nse([1., 1.], [1., 1.]) is None


def test_imports_do_not_use_protected_assimilation():
    require_no_forbidden_imports()
