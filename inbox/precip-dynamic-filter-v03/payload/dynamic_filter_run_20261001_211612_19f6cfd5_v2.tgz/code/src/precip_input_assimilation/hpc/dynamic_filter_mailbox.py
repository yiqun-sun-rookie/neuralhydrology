"""Atomic GitHub-API mailbox transport; never modifies a local git worktree."""

import argparse
import base64
import hashlib
import http.client
import json
import os
from pathlib import Path
import re
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request

BRANCH = "hpc-mailbox"
CHANNEL = "precip-dynamic-filter-v03"
REPO = "yiqun-sun-rookie/neuralhydrology"


class Mailbox:
    def __init__(self):
        result = subprocess.run(["git", "credential", "fill"], input="protocol=https\nhost=github.com\n\n",
                                text=True, capture_output=True,
                                env=dict(os.environ, GIT_TERMINAL_PROMPT="0"), check=True)
        credentials = dict(line.split("=", 1) for line in result.stdout.splitlines() if "=" in line)
        self._token = credentials["password"]

    def api(self, path, method="GET", body=None, missing=False):
        request = urllib.request.Request(f"https://api.github.com/repos/{REPO}/{path}",
                                         data=None if body is None else json.dumps(body).encode(), method=method,
                                         headers={"Authorization": f"Bearer {self._token}", "Accept": "application/vnd.github+json",
                                                  "Content-Type": "application/json", "User-Agent": "isolated-precip-filter"})
        for attempt in range(3 if method == "GET" else 1):
            try:
                with urllib.request.urlopen(request, timeout=60) as response:
                    return json.load(response)
            except urllib.error.HTTPError as error:
                if missing and error.code == 404:
                    return None
                raise RuntimeError(f"Mailbox API HTTP {error.code} at {path}") from None
            except (http.client.IncompleteRead, urllib.error.URLError):
                if method != "GET" or attempt == 2:
                    raise RuntimeError(f"Mailbox response incomplete at {path}") from None
                time.sleep(attempt + 1)

    def text(self, path):
        item = self.api("contents/" + urllib.parse.quote(path, safe="/") + "?ref=" + BRANCH, missing=True)
        if item is None:
            return None
        if item.get("encoding") != "base64":
            item = self.api(f"git/blobs/{item['sha']}")
        return base64.b64decode(item["content"]).decode("utf-8")

    def publish(self, sequence, command, new_channel=False, payload=None):
        encoded = command.encode("utf-8")
        if "\r" in command:
            raise ValueError("Mailbox commands must have LF line endings")
        digest = hashlib.sha256(encoded).hexdigest()
        for attempt in range(5):
            ref = self.api(f"git/ref/heads/{BRANCH}")
            parent = ref["object"]["sha"]
            if not re.fullmatch(r"[0-9a-f]{40}", parent):
                raise RuntimeError("Empty or malformed mailbox parent; refusing ref operation")
            existing = self.text(f"inbox/{CHANNEL}/seq")
            last = 0 if existing is None else int(existing.strip())
            if last == sequence:
                remote = self.text(f"inbox/{CHANNEL}/cmd.sh")
                if remote is not None and hashlib.sha256(remote.encode()).hexdigest() == digest:
                    return {"sequence": sequence, "commit": parent, "command_sha256": digest,
                            "already_published": True}
                raise RuntimeError("Sequence already used by another command")
            if last != sequence - 1:
                raise RuntimeError(f"Sequence mismatch: remote={last}, requested={sequence}")
            registry = (self.text("CHANNELS.md") or "") if new_channel else ""
            if new_channel:
                if last != 0 or existing is not None or CHANNEL in registry:
                    raise RuntimeError("Dedicated channel name collision")
            elif last == 0:
                raise RuntimeError("An existing owned channel is required")
            if last and self.text(f"outbox/{CHANNEL}/result_{last}.txt") is None:
                raise RuntimeError("Previous command lacks a receipt; refusing overwrite")
            commit = self.api(f"git/commits/{parent}")
            entries = [{"path": f"inbox/{CHANNEL}/cmd.sh", "mode": "100755", "type": "blob", "content": command},
                       {"path": f"inbox/{CHANNEL}/seq", "mode": "100644", "type": "blob", "content": str(sequence) + "\n"}]
            if new_channel:
                entries.append({"path": "CHANNELS.md", "mode": "100644", "type": "blob", "content": registry.rstrip() +
                                "\n\n| precip-dynamic-filter-v03 | Single-basin dynamic neural rain correction | 2026-10-01 |\n"})
            if payload is not None:
                blob = self.api("git/blobs", "POST", {"content": base64.b64encode(Path(payload).read_bytes()).decode(),
                                                       "encoding": "base64"})
                entries.append({"path": f"inbox/{CHANNEL}/payload/{Path(payload).name}", "mode": "100644",
                                "type": "blob", "sha": blob["sha"]})
            tree = self.api("git/trees", "POST", {"base_tree": commit["tree"]["sha"], "tree": entries})
            proposed = self.api("git/commits", "POST", {"message": f"Run: {CHANNEL} command {sequence}",
                                                         "tree": tree["sha"], "parents": [parent]})["sha"]
            if not re.fullmatch(r"[0-9a-f]{40}", proposed):
                raise RuntimeError("Malformed proposed commit; refusing ref operation")
            try:
                self.api(f"git/refs/heads/{BRANCH}", "PATCH", {"sha": proposed, "force": False})
                return {"sequence": sequence, "commit": proposed, "command_sha256": digest,
                        "already_published": False}
            except RuntimeError as error:
                if "HTTP 422" not in str(error) or attempt == 4:
                    raise
        raise RuntimeError("Mailbox head changed repeatedly; command not confirmed")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("inspect", "publish", "read"))
    parser.add_argument("--sequence", type=int)
    parser.add_argument("--command", type=Path)
    parser.add_argument("--payload", type=Path)
    parser.add_argument("--new-channel", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    mailbox = Mailbox()
    if args.mode == "inspect":
        sequence = mailbox.text(f"inbox/{CHANNEL}/seq")
        registry = mailbox.text("CHANNELS.md") or ""
        print(json.dumps({"channel": CHANNEL, "sequence": sequence, "registered": CHANNEL in registry}))
    elif args.mode == "publish":
        if args.command is None or args.sequence is None:
            raise ValueError("A command file and explicit sequence are required")
        result = mailbox.publish(args.sequence, args.command.read_text(encoding="utf-8"), args.new_channel, args.payload)
        if args.output is not None:
            with args.output.open("x", encoding="utf-8") as handle:
                json.dump(result, handle, indent=2)
        print(json.dumps(result))
    else:
        receipt = mailbox.text(f"outbox/{CHANNEL}/result_{args.sequence}.txt")
        if receipt is None:
            print(json.dumps({"pending": True, "sequence": args.sequence}))
        elif args.output is None:
            print(receipt)
        else:
            with args.output.open("x", encoding="utf-8", newline="\n") as handle:
                handle.write(receipt)
            print(json.dumps({"pending": False, "sequence": args.sequence, "receipt": str(args.output),
                              "sha256": hashlib.sha256(receipt.encode()).hexdigest()}))


if __name__ == "__main__":
    main()
