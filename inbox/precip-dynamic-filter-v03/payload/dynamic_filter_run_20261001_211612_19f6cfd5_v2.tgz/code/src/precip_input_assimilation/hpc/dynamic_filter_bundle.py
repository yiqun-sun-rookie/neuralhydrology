"""Reproducible, immutable code/model snapshot for the isolated HPC run."""

import argparse
import gzip
import hashlib
import io
import json
import importlib.util
from pathlib import Path
import tarfile


def digest(value):
    return hashlib.sha256(value).hexdigest()


def pack(repo, output, technical, probe, run_id):
    repo = Path(repo)
    sources = {}
    for base in (repo / "neuralhydrology", repo / "src/precip_input_assimilation"):
        for path in base.rglob("*"):
            relative = path.relative_to(repo).as_posix()
            if not path.is_file() or "_tmp" in path.parts or "__pycache__" in path.parts:
                continue
            if path.name == "dynamic_filter_deploy.sh":
                continue  # Its transport digest must not be embedded in its own payload.
            if path.suffix not in (".py", ".slurm", ".sh", ".yml", ".txt"):
                continue
            # The core is a byte-identical frozen instrument snapshot, never new core logic.
            if "test_" in path.name and not path.name.startswith("test_dynamic_filter_"):
                continue
            sources["code/" + relative] = path.read_bytes()
    model = repo / "results/precip_input_da_2026_09/received/seq1/pida_0b1/C4_s100"
    for name in ("model_epoch030.pt", "config.yml", "train_data/train_data_scaler.yml"):
        sources["artifacts/frozen_model/" + name] = (model / name).read_bytes()
    # Reuse existing pure-Python validation dependencies in this run only. No public
    # environment installation is needed even if the cluster lacks pytest.
    for package in ("pytest", "_pytest", "pluggy", "iniconfig", "packaging", "pygments"):
        specification = importlib.util.find_spec(package)
        if specification is None or specification.submodule_search_locations is None:
            raise RuntimeError(f"Required existing validation package missing locally: {package}")
        base = Path(list(specification.submodule_search_locations)[0])
        for path in base.rglob("*.py"):
            sources[f"vendor/{package}/" + path.relative_to(base).as_posix()] = path.read_bytes()
    sources["records/local_synthetic_gate.json"] = Path(technical).read_bytes()
    sources["records/local_probe_gate.json"] = Path(probe).read_bytes()
    measured = json.loads(sources["records/local_probe_gate.json"])
    for name, expected in measured["sources"].items():
        if "code/" + name not in sources or digest(sources["code/" + name]) != expected:
            raise RuntimeError(f"Source changed since the successful resource probe: {name}")
    sources["bundle_manifest.json"] = json.dumps({"run_id": run_id, "channel": "precip-dynamic-filter-v03",
                                                 "max_gpu_hours": 72, "gpu_count": 1, "cpus": 2,
                                                 "files": {name: digest(value) for name, value in sorted(sources.items())},
                                                 "mutable_existing_worktrees": False,
                                                 "core_snapshot": "byte-identical instrument copy, read only; never import frozen assimilation modules"},
                                                indent=2, ensure_ascii=False).encode()
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode="w") as archive:
        for name, content in sorted(sources.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mtime, info.uid, info.gid = len(content), 0, 0, 0
            info.mode = 0o444
            archive.addfile(info, io.BytesIO(content))
    payload = gzip.compress(stream.getvalue(), mtime=0)
    with Path(output).open("xb") as handle:
        handle.write(payload)
    print(json.dumps({"payload": str(output), "bytes": len(payload), "sha256": digest(payload),
                      "files": len(sources), "run_id": run_id}))


def verify(root):
    root = Path(root).resolve()
    manifest = json.loads((root / "bundle_manifest.json").read_text(encoding="utf-8"))
    for name, expected in manifest["files"].items():
        path = (root / name).resolve()
        if not path.is_relative_to(root) or digest(path.read_bytes()) != expected:
            raise RuntimeError(f"Snapshot identity mismatch: {name}")
    print(json.dumps({"verified": len(manifest["files"]), "run_id": manifest["run_id"]}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("pack", "verify"))
    parser.add_argument("--root", type=Path)
    parser.add_argument("--repo", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--technical", type=Path)
    parser.add_argument("--probe", type=Path)
    parser.add_argument("--run-id")
    args = parser.parse_args()
    if args.mode == "pack":
        pack(args.repo, args.output, args.technical, args.probe, args.run_id)
    else:
        verify(args.root)
