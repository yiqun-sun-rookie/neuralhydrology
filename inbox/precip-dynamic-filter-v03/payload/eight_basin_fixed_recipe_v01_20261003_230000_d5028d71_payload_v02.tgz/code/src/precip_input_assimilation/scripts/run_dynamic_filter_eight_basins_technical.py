"""Isolated synthetic gate, bounded real probes, and one-job stage supervision.

The help path uses only the standard library and has no model or data side effects.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import uuid

REPO = Path(__file__).resolve().parents[3]
sys.dont_write_bytecode = True
TEST_NAMES = (
    "test_dynamic_filter_projection.py", "test_dynamic_filter_causality.py",
    "test_dynamic_filter_training.py", "test_dynamic_filter_multibasin_boundary.py",
    "test_dynamic_filter_multibasin_isolation.py", "test_dynamic_filter_multibasin_summary.py",
    "test_dynamic_filter_multibasin_bundle.py")
GIB = 1024 ** 3
STATIC_TABLES = ("camels_topo.txt", "camels_clim.txt", "camels_name.txt",
                 "camels_vege.txt", "camels_soil.txt", "camels_geol.txt")


def write_json(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        handle.write("\n")


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bounded_process(command, timeout, environment=None, stdout=None, own_group=False):
    """Kill this stage's descendants only when its inherited deadline expires."""
    kwargs = {"cwd": REPO, "env": environment, "text": True,
              "start_new_session": own_group and os.name == "posix"}
    if stdout is None:
        kwargs.update(stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    else:
        kwargs.update(stdout=stdout, stderr=subprocess.STDOUT)
    process = subprocess.Popen(command, **kwargs)
    try:
        out, error = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        if own_group and os.name == "posix":
            os.killpg(process.pid, signal.SIGKILL)
        elif (os.name == "posix" and os.environ.get("EIGHT_OWNED_STAGE_GROUP") == "1"
              and os.getpgrp() == os.getpid()):
            # Only this parent-led stage group can contain the real reference child.
            # Killing the group preserves partial files and prevents orphan GPU use.
            os.killpg(os.getpgrp(), signal.SIGKILL)
        else:
            process.kill()
        process.communicate()
        raise
    return subprocess.CompletedProcess(command, process.returncode, out, error)


def modules():
    sys.path[:0] = [str(REPO / "src"), str(REPO)]
    return importlib.import_module("precip_input_assimilation.dynamic_filter_multibasin.identity")


def numerical_runtime(device="cpu"):
    """Set the actual flags before any real model can be constructed."""
    import numpy as np
    import torch
    torch.set_num_threads(2)
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    for module in ("neuralhydrology.evaluation.assimilation", "neuralhydrology.utils.assimilationconfig"):
        if module in sys.modules:
            raise RuntimeError(f"Forbidden module import: {module}")
    paths = {}
    for name in ("neuralhydrology", "precip_input_assimilation.dynamic_filter_multibasin.identity"):
        module = importlib.import_module(name)
        location = Path(module.__file__).resolve()
        if not location.is_relative_to(REPO):
            raise RuntimeError(f"Module was imported outside private payload: {name}")
        paths[name] = str(location)
    return {"python_executable": sys.executable, "python_version": sys.version, "numpy_version": np.__version__,
            "torch_version": torch.__version__, "cuda_version": torch.version.cuda,
            "cudnn_version": torch.backends.cudnn.version(), "torch_threads": torch.get_num_threads(),
            "cudnn_tf32": torch.backends.cudnn.allow_tf32,
            "matmul_tf32": torch.backends.cuda.matmul.allow_tf32,
            "cudnn_deterministic": torch.backends.cudnn.deterministic,
            "cudnn_benchmark": torch.backends.cudnn.benchmark,
            "device": device, "gpu_name": torch.cuda.get_device_name(device) if device.startswith("cuda") else None,
            "gpu_capability": list(torch.cuda.get_device_capability(device)) if device.startswith("cuda") else None,
            "imports": paths, "environment": {key: os.environ.get(key) for key in (
                "OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_THREADING_LAYER",
                "MKL_SERVICE_FORCE_INTEL")}}


def prepare_synthetic_inputs(root):
    """Expose only six static tables to fixtures; daily series stay synthetic."""
    payload = REPO.parent
    data_override = os.environ.get("EIGHT_TEST_DATA_ROOT")
    model_override = os.environ.get("EIGHT_TEST_MODEL_ROOT")
    if data_override:
        source = Path(data_override) / "camels_attributes_v2.0"
    elif (payload / "provenance/metadata").is_dir():
        source = payload / "provenance/metadata"
    else:
        from precip_input_assimilation.dynamic_filter_multibasin.contract import Contract
        contract = Contract.load(REPO / "src/precip_input_assimilation/configs/dynamic_filter_eight_basins_v01.json")
        source = contract.data_root / "camels_attributes_v2.0"
    if model_override:
        model = Path(model_override).resolve()
    elif (payload / "artifacts/frozen_model").is_dir():
        model = payload / "artifacts/frozen_model"
    else:
        from precip_input_assimilation.dynamic_filter_multibasin.contract import Contract
        contract = Contract.load(REPO / "src/precip_input_assimilation/configs/dynamic_filter_eight_basins_v01.json")
        model = contract.model_root
    target = root / "synthetic_inputs" / "camels_attributes_v2.0"
    target.mkdir(parents=True, exist_ok=False)
    identities = {}
    for name in STATIC_TABLES:
        shutil.copyfile(source / name, target / name)
        identities[name] = sha256(target / name)
    return {"data_root": str(target.parent.resolve()), "model_root": str(model.resolve()),
            "static_table_sha256": identities,
            "scope": "six permitted metadata tables only; no real daily weather or flow copied"}


def synthetic_temporary_root(root, platform_name=None):
    """Keep Windows pytest paths short without deriving a new root from code/."""
    root = Path(root).resolve()
    platform_name = os.name if platform_name is None else platform_name
    if platform_name == "nt":
        ancestors = (root, *root.parents)
        allowed = next((path for path in ancestors
            if path.name.casefold() == "dynamic_filter_v03"
            and path.parent.name.casefold() == "precip_input_da_2026_09"
            and path.parent.parent.name.casefold() == "results"), None)
        if allowed is None:
            raise PermissionError("Windows synthetic temporary root needs the registered results ancestor")
        base = allowed / "_tmp"
        temp = base / ("e_" + uuid.uuid4().hex[:12])
        if not temp.resolve().is_relative_to(allowed):
            raise PermissionError("Synthetic temporary path escaped its registered results ancestor")
    else:
        temp = root / "synthetic_tmp" / ("eight_" + uuid.uuid4().hex)
        allowed = root
    parts = tuple(part.casefold() for part in temp.resolve().parts)
    if ".worktrees" in parts or any(parts[index:index + 2] == ("payload", "code")
                                     for index in range(len(parts) - 1)):
        raise PermissionError("Synthetic temporary files cannot enter payload/code or a worktree")
    for parent in (temp, *temp.parents):
        if parent.is_symlink() or (hasattr(parent, "is_junction") and parent.is_junction()):
            raise PermissionError("Synthetic temporary paths cannot traverse links or junctions")
        if parent == allowed:
            break
    temp.mkdir(parents=True, exist_ok=False)
    return temp


def pytest_summary(stdout):
    statistics = [line.strip().strip("=").strip() for line in stdout.splitlines()
                  if re.search(r"\d+ (?:passed|failed|errors?|skipped|xfailed|xpassed)", line)]
    return statistics[-1][:300] if statistics else "pytest produced no final statistics; inspect saved stdout"


def synthetic(root):
    identity = modules()
    runtime = numerical_runtime()
    inputs = prepare_synthetic_inputs(root)
    # Runtime temporary files must not add undeclared members to the frozen payload.
    temp = synthetic_temporary_root(root)
    config = temp / "pytest.ini"
    config.write_text("[pytest]\n", encoding="utf-8")
    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",
                       OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", TMP=str(temp), TEMP=str(temp), TMPDIR=str(temp),
                       EIGHT_TEST_DATA_ROOT=inputs["data_root"], EIGHT_TEST_MODEL_ROOT=inputs["model_root"])
    command = [sys.executable, "-B", "-m", "pytest", "--noconftest", "-p", "no:cacheprovider",
               "-c", str(config), "--rootdir", str(REPO / "src/precip_input_assimilation"),
               "--basetemp", str(temp / "pytest"), "--junitxml", str(root / "tests.xml")]
    command += [str(REPO / "src/precip_input_assimilation/tests" / name) for name in TEST_NAMES]
    began = time.monotonic()
    result = subprocess.run(command + ["-q"], cwd=REPO, env=environment, capture_output=True, text=True, timeout=600)
    with (root / "tests_stdout.txt").open("x", encoding="utf-8") as handle:
        handle.write(result.stdout + result.stderr)
    record = {"success": result.returncode == 0, "kind": "synthetic", "command": command + ["-q"],
              "environment": {key: environment[key] for key in (
                  "PYTHONDONTWRITEBYTECODE", "PYTEST_DISABLE_PLUGIN_AUTOLOAD", "OMP_NUM_THREADS",
                  "MKL_NUM_THREADS", "TMP", "TEMP", "TMPDIR", "EIGHT_TEST_DATA_ROOT",
                  "EIGHT_TEST_MODEL_ROOT")}, "numeric_runtime": runtime, "synthetic_inputs": inputs,
              "exit_code": result.returncode, "seconds": time.monotonic() - began,
              "temporary_root": str(temp), "pytest_summary": pytest_summary(result.stdout),
              "tests_xml_sha256": sha256(root / "tests.xml") if (root / "tests.xml").is_file() else None,
              "stdout_sha256": sha256(root / "tests_stdout.txt"),
              "sources": identity.multibasin_source_snapshot(REPO),
              "scope": "synthetic daily values only; no real daily weather or flow; frozen runoff artifacts hashed for identity only; runoff model not executed"}
    write_json(root / "technical_gate.json", record)
    print(json.dumps({"success": record["success"], "exit_code": record["exit_code"],
        "pytest_summary": record["pytest_summary"], "stdout_file": str(root / "tests_stdout.txt"),
        "temporary_root": str(temp)}, ensure_ascii=False), flush=True)
    if result.returncode:
        raise RuntimeError("Isolated synthetic gate failed")


def remaining_budget(path):
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if value.get("budget_total_seconds") != 259200 or value.get("used_gpu_seconds", -1) < 24378:
        raise RuntimeError("Invalid cumulative budget record")
    if value.get("unsettled_jobs") != [] or value.get("unsettled_reserved_seconds", -1) < 0:
        raise RuntimeError("An unsettled prior job prevents execution")
    remaining = 259200 - value["used_gpu_seconds"] - value["unsettled_reserved_seconds"]
    if remaining != value.get("remaining_gpu_seconds") or remaining <= 300:
        raise RuntimeError("Budget remainder is invalid")
    return value, remaining


def verify_technical(path):
    identity = modules()
    record = json.loads(Path(path).read_text(encoding="utf-8"))
    if record.get("success") is not True or record.get("kind") != "synthetic":
        raise RuntimeError("Successful synthetic acceptance is required before real probes")
    if record["sources"] != identity.multibasin_source_snapshot(REPO):
        raise RuntimeError("Code changed after synthetic acceptance")
    return record


def probe_child(args, root):
    technical = verify_technical(args.technical_record)
    runtime = numerical_runtime(args.device)
    import psutil
    import torch
    from precip_input_assimilation.dynamic_filter_multibasin.contract import Contract
    from precip_input_assimilation.dynamic_filter_multibasin.controller import probe_basin
    contract = Contract.load(args.contract).bind(repo=REPO, data_root=args.data_root,
        model_root=args.model_root, roster_lock=args.roster_lock)
    budget, remaining = remaining_budget(args.budget_record)
    began = float(os.environ["EIGHT_PROBE_STARTED_MONOTONIC"])
    deadline = min(args.deadline_monotonic, began + 1800.)
    if not args.device.startswith("cuda") or not os.environ.get("SLURM_JOB_ID"):
        raise RuntimeError("Real probes require the one scheduled GPU job")
    if torch.cuda.device_count() != 1:
        raise RuntimeError("Exactly one visible GPU is required")
    torch.cuda.synchronize(args.device)
    gpu_free, gpu_total = torch.cuda.mem_get_info(args.device)
    ram_free = psutil.virtual_memory().available
    if shutil.disk_usage(root).free < 5 * GIB:
        raise RuntimeError("Remote free disk space is below 5 GiB")
    measurements = []
    for basin in contract.basins:
        if time.monotonic() >= deadline:
            raise TimeoutError("Eight-basin probe budget exhausted")
        basin_root = root / basin
        torch.cuda.synchronize(args.device)
        one_started = time.monotonic()
        value = probe_basin(contract, basin, basin_root, deadline)
        torch.cuda.synchronize(args.device)
        value = dict(value, basin=basin, occupied_probe_seconds=time.monotonic() - one_started)
        if set(value["epoch_seconds"]) != {"rain", "flow", "historical"}:
            raise RuntimeError("Resource probe omitted a method")
        numbers = [*value["epoch_seconds"].values(), value["replay_seconds_per_day"],
                   value["peak_cuda_bytes"], value["peak_system_bytes"],
                   value["audit_seconds_estimate"], value["c_seconds"]]
        if not all(math.isfinite(number) and number >= 0 for number in numbers):
            raise RuntimeError("Resource probe produced invalid measurements")
        if any(number <= 0 for number in value["epoch_seconds"].values()) or value["replay_seconds_per_day"] <= 0:
            raise RuntimeError("Epoch or ledger replay timing is missing")
        measurements.append(value)
        write_json(basin_root / "resource_measurement.json", value)
    torch.cuda.synchronize(args.device)
    occupied = time.monotonic() - began
    if occupied >= 1800.:
        raise TimeoutError("Real probes exceeded their cumulative 1800-second limit")
    training = sum(3 * 60 * sum(value["epoch_seconds"].values()) for value in measurements)
    scoring = sum(11 * 3287 * value["replay_seconds_per_day"] for value in measurements)
    preparation_audit = sum(value["c_seconds"] + value["audit_seconds_estimate"] for value in measurements)
    estimate = 1.25 * (training + scoring + preparation_audit)
    elapsed = time.monotonic() - budget["job_started_monotonic"]
    left = min(remaining - elapsed - 300., args.deadline_monotonic - time.monotonic())
    cuda_peak = max(value["peak_cuda_bytes"] for value in measurements)
    ram_peak = max(value["peak_system_bytes"] for value in measurements)
    tests = {"complete_eight_basins": len(measurements) == 8,
             "within_probe_1800_seconds": occupied < 1800., "enough_gpu": gpu_free >= 1.25 * cuda_peak,
             "enough_ram": ram_free >= 1.25 * ram_peak,
             "enough_remote_disk": shutil.disk_usage(root).free >= 5 * GIB,
             "fits_remaining_budget": estimate <= left}
    record = {"success": all(tests.values()), "kind": "eight_basin_probe", "tests": tests,
              "basins": measurements, "date_utc": datetime.now(timezone.utc).isoformat(),
              "contract_sha256": contract.sha256, "roster_lock_sha256": sha256(args.roster_lock),
              "technical_gate_sha256": sha256(args.technical_record), "sources": technical["sources"],
              "numeric_runtime": runtime, "probe_seconds": occupied,
              "seconds": {"training_max_60_epochs": training, "scoring_with_rain_ledger": scoring,
                          "preparation_and_audit": preparation_audit,
                          "estimated_remaining_with_25_percent_margin": estimate,
                          "remaining_after_current_job_and_exit_reserve": left,
                          "current_job_elapsed": elapsed},
              "resources": {"cuda_free_before": gpu_free, "cuda_total": gpu_total,
                            "cuda_peak": cuda_peak, "ram_free_before": ram_free, "ram_peak": ram_peak,
                            "remote_disk_free": shutil.disk_usage(root).free},
              "scope": "fit/select only; checkpoints discarded for selection; no score-period numerical reads"}
    write_json(root / "probe_gate.json", record)
    if not record["success"]:
        raise RuntimeError("Measured eight-basin resource gate failed")
    verify_technical(args.technical_record)


def probe(args, root):
    """Bound the real-data child process including loading and device timing."""
    began = time.monotonic()
    timeout = min(1800., args.deadline_monotonic - began)
    if timeout <= 0:
        raise TimeoutError("No real-probe budget remains")
    environment = dict(os.environ, EIGHT_PROBE_STARTED_MONOTONIC=str(began),
                       EIGHT_PROBE_CHILD_ROOT=str(root.resolve()))
    command = [sys.executable, "-B", str(Path(__file__).resolve()), "probe", "--probe-child",
               "--output", str(root), "--technical-record", str(args.technical_record),
               "--contract", str(args.contract), "--data-root", str(args.data_root),
               "--model-root", str(args.model_root), "--roster-lock", str(args.roster_lock),
               "--budget-record", str(args.budget_record), "--deadline-monotonic", str(args.deadline_monotonic),
               "--device", args.device]
    result = bounded_process(command, timeout, environment=environment)
    with (root / "probe_process.txt").open("x", encoding="utf-8") as handle:
        handle.write(result.stdout + result.stderr)
    write_json(root / "probe_process.json", {"command": command, "exit_code": result.returncode,
                                             "total_seconds": time.monotonic() - began, "hard_timeout": timeout})
    if result.returncode:
        raise RuntimeError("Real probe process failed; its partial records are preserved")


def job(args, root):
    """One parent deadline across synthetic, input, probe, fit, lock and score."""
    if not os.environ.get("SLURM_JOB_ID"):
        raise RuntimeError("The job supervisor can run only inside the scheduled job")
    # Every child stage receives the same registered mutable root outside payload/code.
    os.environ["EIGHT_BASIN_OUTPUT_ROOT"] = str(root.resolve())
    snapshot, remaining = remaining_budget(args.budget_record)
    requested = math.floor(remaining / 60.) * 60
    allocated_since = float(os.environ["EIGHT_JOB_STARTED_UNIX"])
    started = time.monotonic() - max(0., time.time() - allocated_since)
    deadline = started + requested - 300.
    budget = dict(snapshot, job_started_monotonic=started, job_deadline_monotonic=deadline,
                  requested_gpu_seconds=requested, gpu_count=1, job_id=os.environ["SLURM_JOB_ID"])
    budget_path = root / "budget_runtime.json"
    write_json(budget_path, budget)
    main_entry = REPO / "src/precip_input_assimilation/scripts/run_dynamic_filter_eight_basins.py"
    common = ["--contract", str(args.contract), "--repo", str(REPO), "--data-root", str(args.data_root),
              "--model-root", str(args.model_root), "--roster-lock", str(args.roster_lock),
              "--deadline-monotonic", str(deadline), "--budget-record", str(budget_path), "--device", args.device]
    calls = [
        [sys.executable, "-B", str(Path(__file__).resolve()), "synthetic", "--output", str(root / "synthetic")],
        [sys.executable, "-B", str(main_entry), "preflight", *common, "--output", str(root / "preflight")],
        [sys.executable, "-B", str(Path(__file__).resolve()), "probe", "--output", str(root / "probe"),
         "--technical-record", str(root / "synthetic/technical_gate.json"),
         "--contract", str(args.contract), "--data-root", str(args.data_root), "--model-root", str(args.model_root),
         "--roster-lock", str(args.roster_lock), "--deadline-monotonic", str(deadline),
         "--budget-record", str(budget_path), "--device", args.device],
        [sys.executable, "-B", str(main_entry), "train", *common, "--output", str(root / "training"),
         "--preflight-root", str(root / "preflight"), "--probe-record", str(root / "probe/probe_gate.json")],
        [sys.executable, "-B", str(main_entry), "lock", *common, "--output", str(root / "locked"),
         "--training-root", str(root / "training")],
        [sys.executable, "-B", str(main_entry), "score", *common, "--output", str(root / "scoring"),
         "--global-lock", str(root / "locked/global_selection_locked.json")],
    ]
    completed = []
    try:
        for index, command in enumerate(calls):
            available = deadline - time.monotonic()
            if available <= 0:
                raise TimeoutError("Shared job deadline reached; preserving the 300-second exit reserve")
            with (root / f"stage_{index}.txt").open("x", encoding="utf-8") as handle:
                environment = dict(os.environ, EIGHT_OWNED_STAGE_GROUP="1")
                result = bounded_process(command, available, environment=environment, stdout=handle, own_group=True)
            record = {"index": index, "command": command, "exit_code": result.returncode,
                      "job_elapsed_seconds": time.monotonic() - started}
            write_json(root / f"stage_{index}.json", record)
            completed.append(record)
            if result.returncode:
                raise RuntimeError(f"Stage {index} failed; no later stage was started")
        write_json(root / "job_complete.json", {"success": True, "stages": completed,
                    "job_elapsed_seconds": time.monotonic() - started, "deadline_monotonic": deadline})
    finally:
        write_json(root / "budget_parent_exit.json", {"job_id": os.environ["SLURM_JOB_ID"],
                    "parent_elapsed_seconds": time.monotonic() - started,
                    "requested_gpu_seconds": requested, "scheduler_accounting_still_required": True})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_subparsers(dest="mode", required=True)
    synthetic_parser = modes.add_parser("synthetic")
    synthetic_parser.add_argument("--output", type=Path, required=True)
    for name in ("probe", "job"):
        command = modes.add_parser(name)
        for flag in ("output", "contract", "technical-record", "data-root", "model-root", "roster-lock", "budget-record"):
            command.add_argument("--" + flag, type=Path, required=flag != "technical-record" or name == "probe")
        command.add_argument("--device", default="cuda:0")
        if name == "probe":
            command.add_argument("--deadline-monotonic", type=float, required=True)
            command.add_argument("--probe-child", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    root = args.output.resolve()
    if args.mode == "probe" and args.probe_child:
        if os.environ.get("EIGHT_PROBE_CHILD_ROOT") != str(root) or not root.is_dir():
            raise PermissionError("Probe child root was not created by its bounded parent")
    else:
        root.mkdir(parents=True, exist_ok=False)
    try:
        if args.mode == "synthetic":
            synthetic(root)
        elif args.mode == "probe" and args.probe_child:
            probe_child(args, root)
        elif args.mode == "probe":
            probe(args, root)
        else:
            job(args, root)
    except Exception as error:
        failure = root / ("child_failure.json" if getattr(args, "probe_child", False) else "failure.json")
        write_json(failure, {"type": type(error).__name__, "error": str(error), "mode": args.mode})
        raise


if __name__ == "__main__":
    main()
