"""Four explicit stages for the approved fixed eight-basin experiment.

Argument parsing occurs before any package import: --help loads no inputs/models.
"""

import argparse
import os
from pathlib import Path
import sys


def parser_for_cli():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("preflight", "train", "lock", "score"))
    parser.add_argument("--contract", required=True, type=Path)
    parser.add_argument("--repo", type=Path, default=Path(__file__).resolve().parents[3])
    parser.add_argument("--data-root", required=True, type=Path)
    parser.add_argument("--model-root", required=True, type=Path)
    parser.add_argument("--roster-lock", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--deadline-monotonic", required=True, type=float)
    parser.add_argument("--budget-record", required=True, type=Path)
    parser.add_argument("--preflight-root", type=Path)
    parser.add_argument("--probe-record", type=Path)
    parser.add_argument("--training-root", type=Path)
    parser.add_argument("--global-lock", type=Path)
    parser.add_argument("--resume-root", type=Path)
    return parser


def main():
    args = parser_for_cli().parse_args()
    repo = args.repo.resolve()
    # Only after --help has exited may dependencies or explicit contract be loaded.
    sys.dont_write_bytecode = True
    sys.path[:0] = [str(repo), str(repo / "src")]
    from precip_input_assimilation.dynamic_filter_multibasin.contract import Contract
    from precip_input_assimilation.dynamic_filter_multibasin.controller import (
        check_budget_record, configure_numerics, lock_all, numerical_runtime, preflight, score_all, train_basin)
    from precip_input_assimilation.dynamic_filter_multibasin.identity import (
        BasinSelection, bound_path, canonical_digest, read_json, require_sources, sha256, write_json)
    import time
    import traceback
    root = args.output
    allowed = Path(os.environ.get("EIGHT_BASIN_OUTPUT_ROOT", str(
        repo / "results/precip_input_da_2026_09/dynamic_filter_v03"))).resolve()
    target = root.resolve()
    if not target.is_relative_to(allowed) or any(part.casefold() == ".worktrees" for part in target.parts):
        raise PermissionError("Output must stay inside the registered new experiment output root")
    for parent in (root.absolute(), *root.absolute().parents):
        if parent.is_symlink() or (hasattr(parent, "is_junction") and parent.is_junction()):
            raise PermissionError("Output may not traverse a link or directory junction")
        if parent == allowed:
            break
    root.mkdir(parents=True, exist_ok=False)
    try:
        contract = Contract.load(args.contract).bind(repo=repo, data_root=args.data_root,
                                                   model_root=args.model_root, roster_lock=args.roster_lock)
        contract.verify_roster_lock()
        budget = check_budget_record(args.budget_record, args.deadline_monotonic)
        configure_numerics()
        runtime = numerical_runtime(repo, args.device)
        write_json(root / "stage_manifest.json", {"stage": args.stage, "contract_sha256": contract.sha256,
                   "roster_lock_sha256": sha256(args.roster_lock), "budget_record_sha256": sha256(args.budget_record),
                   "deadline_monotonic": args.deadline_monotonic, "started_monotonic": time.monotonic(),
                   "device": args.device, "previous_gpu_seconds": budget["used_gpu_seconds"],
                   "numeric_runtime": runtime})
        if args.stage == "preflight":
            preflight(contract, root)
        elif args.stage == "train":
            if args.preflight_root is None or args.probe_record is None:
                raise ValueError("Training requires --preflight-root and --probe-record")
            gate = read_json(args.preflight_root / "preflight_gate.json")
            if (gate.get("success") is not True or gate.get("contract_sha256") != contract.sha256 or
                    tuple(gate.get("basins", ())) != tuple(contract.basins) or
                    gate.get("score_observations_read") is not False):
                raise PermissionError("Complete uncontaminated preflight is required")
            probe = read_json(args.probe_record)
            if probe.get("success") is not True or probe.get("kind") != "eight_basin_probe":
                raise PermissionError("A successful real eight-basin resource gate is required")
            if probe.get("contract_sha256") != contract.sha256:
                raise PermissionError("Resource probe used a different contract")
            if probe.get("numeric_runtime") != runtime:
                raise PermissionError("Training numerical environment differs from its measured technical gate")
            require_sources(repo, gate["sources"])
            require_sources(repo, probe["sources"])
            if gate["sources"] != probe["sources"]:
                raise PermissionError("Preflight and probe source identities differ")
            seconds = probe["seconds"]
            estimate = seconds["estimated_remaining_with_25_percent_margin"]
            if estimate > args.deadline_monotonic - time.monotonic() - 300:
                raise TimeoutError("Measured full experiment no longer fits the cumulative remaining budget")
            inputs = {item["basin"]: item for item in gate["inputs"]}
            for basin in contract.basins:
                item = inputs[basin]
                path = bound_path(args.preflight_root, item["input_gate"])
                if sha256(path) != item["input_gate_sha256"]:
                    raise PermissionError("Preflight input gate changed")
                expected = read_json(path)
                if canonical_digest(expected) != item["input_identity_sha256"]:
                    raise PermissionError("Preflight input identity changed")
                train_basin(contract, basin, root, args.deadline_monotonic, device=args.device,
                            expected_gate=expected, resume_root=args.resume_root)
        elif args.stage == "lock":
            if args.training_root is None:
                raise ValueError("Global locking requires --training-root")
            training_manifest = read_json(args.training_root / "stage_manifest.json")
            if training_manifest["deadline_monotonic"] != args.deadline_monotonic:
                raise PermissionError("Lock stage attempted to reset the training deadline")
            if training_manifest["numeric_runtime"] != runtime:
                raise PermissionError("Lock numerical environment differs from training")
            selections = [BasinSelection.from_dict(read_json(
                args.training_root / "basins" / basin / "selection_locked.json")) for basin in contract.basins]
            lock_all(contract, selections, root)
        else:
            if args.global_lock is None:
                raise ValueError("Scoring requires --global-lock")
            locking_manifest = read_json(args.global_lock.parent / "stage_manifest.json")
            if locking_manifest["deadline_monotonic"] != args.deadline_monotonic:
                raise PermissionError("Score stage attempted to reset the global deadline")
            if locking_manifest["numeric_runtime"] != runtime:
                raise PermissionError("Score numerical environment differs from locked training")
            score_all(contract, args.global_lock, root, args.deadline_monotonic, device=args.device)
        write_json(root / "complete.json", {"stage": args.stage, "success": True,
                                            "automatic_expansion": False})
    except Exception as error:
        write_json(root / "failure.json", {"stage": args.stage, "type": type(error).__name__,
                                           "error": str(error), "traceback": traceback.format_exc(),
                                           "automatic_expansion": False})
        raise


if __name__ == "__main__":
    main()
