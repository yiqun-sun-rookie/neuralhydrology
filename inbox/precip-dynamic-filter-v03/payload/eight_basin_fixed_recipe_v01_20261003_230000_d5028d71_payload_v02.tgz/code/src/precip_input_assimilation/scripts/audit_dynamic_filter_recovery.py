"""Reconstruct the frozen pilot from exported artifacts, without running models.

Observation values are parsed only inside the three approved 1980s phases.
No original scoring function, hydrologic model, or assimilation module is used.
"""

import argparse
import csv
from datetime import date, datetime, timedelta, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import sys
import xml.etree.ElementTree as ET

import numpy as np

REPO = Path(__file__).resolve().parents[3]
APPROVED_RESULTS = REPO / 'results/precip_input_da_2026_09/dynamic_filter_v03'
BASIN = '01022500'
PHASES = {
    'fit': (date(1980, 10, 1), date(1984, 9, 30)),
    'select': (date(1984, 10, 1), date(1985, 9, 30)),
    'score': (date(1985, 10, 1), date(1989, 9, 30)),
}
SEEDS = (1001, 1002, 1003)
PENALTIES = (0.0001, 0.001, 0.01)
KINDS = ('rain', 'flow', 'historical')
NAMES = ('PRCP(mm/day)', 'Tmin(C)', 'Tmax(C)', 'SRAD(W/m2)', 'Vp(Pa)')
SCORE_TOLERANCE = 1e-12


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, value):
    with path.open('x', encoding='utf-8') as handle:
        json.dump(value, handle, indent=2, ensure_ascii=False, allow_nan=False)


def days(start, end):
    return tuple(start + timedelta(days=i) for i in range((end - start).days + 1))


def unique(root, pattern):
    matches = list(root.glob('**/' + pattern))
    require(len(matches) == 1, 'Expected one approved file: ' + pattern)
    require(matches[0].resolve().is_relative_to(root.resolve()), 'Resolved input escapes approved data root')
    require('.worktrees' not in matches[0].resolve().parts, 'Input unexpectedly enters a worktree')
    return matches[0]


def read_weather(data):
    start, end = date(1980, 1, 1), PHASES['score'][1]
    require(end < date(1989, 10, 1), 'Weather boundary changed')
    path = unique(data / 'basin_mean_forcing/maurer', BASIN + '_*_forcing_leap.txt')
    result, rows = [], []
    with path.open(encoding='utf-8') as handle:
        handle.readline()
        handle.readline()
        area = int(handle.readline().strip())
        header = handle.readline().split()
        columns = [header.index(name) for name in NAMES]
        previous = None
        for line in handle:
            fields = line.split()
            if len(fields) < 4:
                continue
            current = date(*(int(x) for x in fields[:3]))
            require(previous is None or current > previous, 'Weather dates are not ordered')
            previous = current
            if current < start:
                continue
            if current > end:
                break
            rows.append([float(fields[column]) for column in columns])
            result.append(current)
            if current == end:
                break
    require(tuple(result) == days(start, end), 'Incomplete allowed weather grid')
    array = np.asarray(rows, dtype=np.float32)
    require(np.isfinite(array).all() and (array[:, 0] >= 0).all(), 'Invalid allowed weather')
    digest = hashlib.sha256()
    digest.update(('date,' + ','.join(NAMES) + chr(10)).encode())
    for current, row in zip(result, array, strict=True):
        rendered = ','.join(format(float(value), '.9g') for value in row)
        digest.update((f'{current},{rendered}' + chr(10)).encode())
    return tuple(result), array, area, digest.hexdigest(), path


def read_flow(data, area, phase):
    # Bounds are decided before opening the raw file or parsing a numeric value.
    require(phase in PHASES and area > 0, 'Unknown phase or invalid area')
    start, end = PHASES[phase]
    require(date(1980, 10, 1) <= start <= end < date(1989, 10, 1), 'Forbidden observation interval')
    path = unique(data / 'usgs_streamflow', BASIN + '_streamflow_qc.txt')
    records = {}
    previous = None
    conversion = 28316846.592 * 86400. / 1_000_000.
    with path.open(encoding='utf-8') as handle:
        for line in handle:
            fields = line.split()
            current = date(*(int(x) for x in fields[1:4]))
            require(fields[0] == BASIN and (previous is None or current > previous), 'Observation metadata mismatch')
            previous = current
            if current < start:
                continue
            if current > end:
                break
            raw = float(fields[4])
            records[current] = math.nan if raw < 0 or not math.isfinite(raw) else conversion * raw / area
            if current == end:
                break
    grid = days(start, end)
    values = [records.get(current, math.nan) for current in grid]
    digest = hashlib.sha256()
    for current, value in zip(grid, values, strict=True):
        rendered = format(value, '.17g') if math.isfinite(value) else 'NA'
        digest.update((f'{current},{rendered}' + chr(10)).encode())
    return grid, values, digest.hexdigest(), path


def efficiency(obs, pred):
    require(len(obs) == len(pred), 'Scoring grids differ')
    pairs = [(o, p) for o, p in zip(obs, pred, strict=True) if math.isfinite(o)]
    require(all(math.isfinite(p) for _, p in pairs), 'Nonfinite prediction on a common scoring date')
    if len(pairs) < 2:
        return None
    mean = math.fsum(o for o, _ in pairs) / len(pairs)
    denominator = math.fsum((o - mean) ** 2 for o, _ in pairs)
    if denominator <= 0:
        return None
    return 1. - math.fsum((p - o) ** 2 for o, p in pairs) / denominator


def check_training(root, selection):
    import torch

    expected = {(kind, penalty, seed) for kind in KINDS for penalty in PENALTIES for seed in SEEDS}
    fits, evidence = {}, []
    epoch_total, segment_total, loss_total = 0, 0, 0
    gradient_min, gradient_max = math.inf, 0.
    for path in sorted((root / 'pilot/fits').rglob('fit_summary.json')):
        fit = load(path)
        key = (fit['kind'], fit['penalty'], fit['seed'])
        require(key not in fits, 'Duplicate fit identity')
        fits[key] = fit
        folder = path.parent
        epochs = sorted(folder.glob('epoch_*.json'))
        require(len(epochs) == fit['epochs'] and 1 <= len(epochs) <= 60, 'Missing or excessive training epochs')
        best, best_epoch = -math.inf, None
        for number, record_path in enumerate(epochs, 1):
            record = load(record_path)
            require(record['epoch'] == number and math.isfinite(record['validation_nse']), 'Epoch sequence or value invalid')
            better = record['validation_nse'] > best
            require(record['selected'] == better, 'Selection event differs from validation-only improvement')
            if better:
                best, best_epoch = record['validation_nse'], number
            segments = record['segments']
            require(len(segments) == 46, 'Training segments incomplete')
            terms = 0
            for index, segment in enumerate(segments):
                start = PHASES['fit'][0] + timedelta(days=32 * index)
                stop = min(start + timedelta(days=31), PHASES['fit'][1])
                closing = (stop + timedelta(days=1)).isoformat() if stop < PHASES['fit'][1] else None
                require((segment['start'], segment['stop'], segment['closing']) ==
                        (start.isoformat(), stop.isoformat(), closing), 'Segment crosses the frozen fit boundary')
                gradient = segment['gradient_norm']
                require(math.isfinite(gradient) and gradient >= 0, 'Nonfinite training gradient')
                require(segment['loss'] is None or math.isfinite(segment['loss']), 'Nonfinite training loss')
                gradient_min, gradient_max = min(gradient_min, gradient), max(gradient_max, gradient)
                terms += segment['flow_terms']
            require(terms == 1461, 'Training loss dates omitted or duplicated')
            epoch_total += 1
            segment_total += len(segments)
            loss_total += terms
        require(best_epoch == fit['best_epoch'] and best == fit['validation_nse'], 'Fit summary differs from validation history')
        require(len(epochs) == 60 or len(epochs) - best_epoch == 10, 'Early stopping differs from frozen patience')
        checkpoint = root / 'pilot' / fit['checkpoint']
        require(checkpoint.resolve() == (folder / 'selected.pt').resolve(), 'Checkpoint path differs from its fit')
        require(sha(checkpoint) == fit['checkpoint_sha256'], 'Checkpoint hash differs from frozen fit record')
        contents = torch.load(checkpoint, map_location='cpu', weights_only=True)
        for key_name in ('seed', 'penalty', 'epoch', 'validation_nse'):
            expected_value = fit['best_epoch'] if key_name == 'epoch' else fit[key_name]
            require(contents[key_name] == expected_value, 'Checkpoint metadata mismatch: ' + key_name)
        buffers = {'cap', 'flow_std'} if fit['kind'] == 'flow' else {'cap'}
        state = contents['state_dict']
        require(sum(tensor.numel() for name, tensor in state.items() if name not in buffers) == 5633,
                'Unequal trainable network parameter count')
        require(all(torch.isfinite(tensor).all() for tensor in state.values()), 'Nonfinite checkpoint tensor')
        expected_cap = 5 * selection['scaling']['flow_std'] if fit['kind'] == 'flow' else selection['scaling']['cap']
        require(float(state['cap']) == float(np.float32(expected_cap)), 'Frozen correction cap changed in the checkpoint')
        if fit['kind'] == 'flow':
            require(float(state['flow_std']) == float(np.float32(selection['scaling']['flow_std'])),
                    'Frozen flow scale changed in the checkpoint')
        evidence.append({**fit, 'checkpoint_verified': True})
    require(set(fits) == expected, 'The full 27-fit grid is not present')
    recorded = {(x['kind'], x['penalty'], x['seed']): x for x in selection['all_fits']}
    require(recorded == fits, 'Locked selection does not contain every fit exactly')
    selected_keys, means = set(), {}
    for kind in KINDS:
        means[kind] = {str(p): statistics.mean(fits[(kind, p, seed)]['validation_nse'] for seed in SEEDS)
                       for p in PENALTIES}
        chosen = max(PENALTIES, key=lambda p: (means[kind][str(p)], p))
        selected_keys.update((kind, chosen, seed) for seed in SEEDS)
    selected = {(x['kind'], x['penalty'], x['seed']): x for x in selection['selected']}
    require(set(selected) == selected_keys and all(selected[key] == fits[key] for key in selected),
            'Settings were not selected by the prescribed three-seed validation mean')
    return {'fit_count': len(fits), 'checkpoint_count': len(fits), 'selected_checkpoint_count': len(selected),
            'epoch_count': epoch_total, 'segment_count': segment_total, 'flow_loss_items': loss_total,
            'gradient_norm_min': gradient_min, 'gradient_norm_max': gradient_max,
            'validation_means': means, 'fits': evidence}


def check_rain_versions(root, collection, weather_dates, weather, cap):
    raw_weather = {d: float(row[0]) for d, row in zip(weather_dates, weather, strict=True)}
    grid = days(PHASES['fit'][0], PHASES['score'][1])
    reports = {}
    for name, expected in collection['rain_version_originals'].items():
        path = root / name
        require(path.is_file() and path.stat().st_size == expected['bytes'] and sha(path) == expected['sha256'],
                'Original rain ledger missing or changed')
        latest, revisions = {}, {}
        absolute_all_versions, dry_all_versions, actual_revision_magnitude = 0., 0., 0.
        upper, lower, negative_proposals, negative_clipped, rows = 0, 0, 0, 0, 0
        last_as_of = None
        with path.open(encoding='utf-8', newline='') as handle:
            for row in csv.DictReader(handle):
                as_of, rain_day = date.fromisoformat(row['as_of_date']), date.fromisoformat(row['rain_date'])
                update_index, lag_position = divmod(rows, 100)
                require(update_index < len(grid) and as_of == grid[update_index] and
                        rain_day == as_of - timedelta(days=99 - lag_position), 'Rain revisions violate daily order or the 100-day window')
                raw, proposal, applied, row_cap = (float(row[key]) for key in ('raw_mm', 'proposal_mm', 'applied_mm', 'cap_mm'))
                require(all(math.isfinite(value) for value in (raw, proposal, applied, row_cap)), 'Nonfinite rain version')
                require(raw == raw_weather[rain_day] and row_cap == cap and row['missing'] == '0', 'Rain source, cap, or availability differs')
                bound = -min(raw, cap)
                require(applied == min(max(proposal, bound), cap) and raw + applied >= 0,
                        'Rain projection differs from the frozen bound or gives negative rainfall')
                absolute_all_versions += abs(applied)
                dry_all_versions += max(applied, 0.) if raw < .1 else 0.
                actual_revision_magnitude += abs(applied - latest.get(rain_day, 0.))
                latest[rain_day] = applied
                revisions[rain_day] = revisions.get(rain_day, 0) + 1
                upper += int(applied >= cap - 1e-6)
                lower += int(applied <= bound + 1e-6)
                negative_proposals += int(proposal < 0)
                negative_clipped += int(proposal < bound)
                last_as_of, rows = as_of, rows + 1
        require(rows == 100 * len(grid) and last_as_of == PHASES['score'][1], 'Rain ledger is incomplete')
        diagnostics = load(path.parent / 'diagnostics.json')
        require(rows == diagnostics['rain_versions'] and absolute_all_versions == diagnostics['absolute_revision_mm'] and
                dry_all_versions == diagnostics['dry_added_mm'], 'All-version rain diagnostics differ from original ledger')
        require(upper == diagnostics['touch_upper'] and lower == diagnostics['touch_lower'], 'Projection-bound counts differ')
        final_abs = math.fsum(abs(value) for value in latest.values())
        final_dry = math.fsum(max(value, 0.) for d, value in latest.items() if raw_weather[d] < .1)
        # Original final totals were reduced in float32. Check that representation
        # separately; preserve higher-precision ledger totals for reporting.
        final_array = np.array([latest.get(d, 0.) for d in weather_dates], dtype=np.float32)
        require(float(np.abs(final_array).sum()) == diagnostics['final_daily_absolute_correction_mm'], 'Final absolute rain total differs')
        require(float(np.maximum(final_array[weather[:, 0] < .1], 0.).sum()) == diagnostics['final_dry_added_mm'], 'Final dry-day addition differs')
        score_days = days(*PHASES['score'])
        raw_total = math.fsum(raw_weather[d] for d in score_days)
        net_total = math.fsum(latest[d] for d in score_days)
        method = path.parent.name
        reports[method] = {
            'rows': rows, 'updates': len(grid), 'unique_rain_dates_revised': len(latest),
            'latest_applied_absolute_mm_all_phases_float64': final_abs,
            'latest_dry_added_mm_all_phases_float64': final_dry,
            'all_version_applied_absolute_sum_mm': absolute_all_versions,
            'all_version_dry_addition_sum_mm': dry_all_versions,
            'actual_total_revision_magnitude_mm': actual_revision_magnitude,
            'upper_bound_versions': upper, 'lower_bound_versions': lower,
            'lower_bound_version_fraction': lower / rows,
            'negative_proposal_versions': negative_proposals,
            'negative_proposals_clipped_versions': negative_clipped,
            'score_period_final_ledger': {
                'raw_total_mm': raw_total, 'net_change_mm': net_total,
                'corrected_total_mm': raw_total + net_total,
                'net_change_fraction_of_raw': net_total / raw_total,
                'dry_added_mm': math.fsum(max(latest[d], 0.) for d in score_days if raw_weather[d] < .1),
                'absolute_change_mm': math.fsum(abs(latest[d]) for d in score_days),
                'days_rain_reduced_to_zero': sum(raw_weather[d] >= .1 and raw_weather[d] + latest[d] == 0 for d in score_days)},
            'scope': 'Latest as-of ledger may include later observation revisions; not precipitation available on each original prediction date.',
            'diagnostic_semantics': 'Original absolute_revision_mm and dry_added_mm sum applied totals across every version, counting a rain day repeatedly.'
        }
    return reports


def audit(root, data):
    collection = load(root / 'collection_manifest.json')
    require(collection['job'] == 235201 and collection['total_this_network_gpu_seconds'] <= 72 * 3600,
            'Run identity or total GPU budget differs')
    for name, metadata in collection['files'].items():
        path = root / name
        require(path.resolve().is_relative_to(root.resolve()) and path.is_file(), 'Missing or escaping recovered artifact')
        require(path.stat().st_size == metadata['bytes'] and sha(path) == metadata['sha256'], 'Recovered artifact integrity mismatch')
    selection = load(root / 'pilot/selection_locked.json')
    manifest = load(root / 'pilot/run_manifest.json')
    summary = load(root / 'pilot/summary.json')
    require(selection['run_manifest_sha256'] == sha(root / 'pilot/run_manifest.json'), 'Run manifest link broken')
    require(summary['selection_locked_sha256'] == sha(root / 'pilot/selection_locked.json'), 'Selection lock link broken')
    require(selection['score_observations_read'] is False, 'Selection record does not exclude scoring observations')
    require(summary['contract'] == manifest['contract'], 'Scoring contract differs from training contract')
    contract = manifest['contract']
    required = {'basin': BASIN, 'seeds': list(SEEDS), 'penalties': list(PENALTIES), 'max_epochs': 60,
                'patience': 10, 'learning_rate': .001, 'window': 100, 'segment_days': 32,
                'automatic_expansion': False, 'historical_model_selection': 'unknown and disclosed'}
    required.update({key: [start.isoformat(), end.isoformat()] for key, (start, end) in PHASES.items()})
    require(all(contract[key] == value for key, value in required.items()), 'Frozen protocol differs from the approved plan')
    require(load(root / 'pilot/complete.json') == {'stage': 'all', 'success': True, 'automatic_expansion': False},
            'Completion marker does not cover the full experiment')
    probe = load(root / 'probe/probe_gate.json')
    technical = load(root / 'synthetic/technical_gate.json')
    require(probe['success'] and technical['success'], 'Historical technical gates are missing or failed')
    require(manifest['probe_gate_sha256'] == sha(root / 'probe/probe_gate.json'), 'Probe identity link broken')
    require(manifest['sources'] == selection['sources'] == probe['sources'], 'Runtime source links differ')
    require(all(sha(REPO / name) == wanted for name, wanted in manifest['sources'].items()), 'Local original runtime source changed')
    cases = ET.parse(root / 'synthetic/tests.xml').getroot().findall('.//testcase')
    require(len(cases) == 22 and not any(case.find('failure') is not None or case.find('error') is not None for case in cases),
            'The 22 synthetic checks are not all successful')
    training = check_training(root, selection)

    weather_dates, weather, area, weather_hash, weather_path = read_weather(data)
    require(weather_hash == summary['data_hashes']['weather_canonical'], 'Allowed weather differs from the cluster input')
    observations, obs_evidence = {}, {}
    for phase in PHASES:
        grid, values, identity, path = read_flow(data, area, phase)
        start, end = PHASES[phase]
        key = f'flow_{phase}_{start}_{end}'
        require(identity == summary['data_hashes'][key], 'Allowed observation values differ from the cluster input')
        if phase != 'score':
            require(identity == manifest['data'][key], 'Training observation identity changed')
        observations[phase] = dict(zip(grid, values, strict=True))
        obs_evidence[phase] = {'start': str(start), 'end': str(end), 'parsed_values': len(values),
                               'valid_count': sum(math.isfinite(v) for v in values), 'canonical_sha256': identity,
                               'path': path.as_posix()}
    fit_weather = weather[[PHASES['fit'][0] <= d <= PHASES['fit'][1] for d in weather_dates]]
    fit_flow = np.array(list(observations['fit'].values()))
    wet = fit_weather[fit_weather[:, 0] >= .1, 0]
    cap_linear_float64 = float(np.quantile(wet, .99, method='linear'))
    measured = {'weather_mean': fit_weather.mean(axis=0).tolist(), 'weather_std': fit_weather.std(axis=0).tolist(),
                'flow_mean': float(fit_flow[np.isfinite(fit_flow)].mean()),
                'flow_std': float(fit_flow[np.isfinite(fit_flow)].std()),
                'cap': float(np.float32(cap_linear_float64)), 'start': str(PHASES['fit'][0]), 'end': str(PHASES['fit'][1])}
    # The cluster scalar and every checkpoint cap use this exact float32 value.
    # Preserve the double-precision quantile and the first exact-scalar failure;
    # this does not relax the scoring tolerance or alter any experiment artifact.
    require(measured == manifest['scaling'] == selection['scaling'], 'Fit-only normalization or rain cap differs')

    full_grid = days(PHASES['fit'][0], PHASES['score'][1])
    score_grid = days(*PHASES['score'])
    obs = [observations['score'][d] for d in score_grid]
    coverage, calculated, prediction_maps = {}, {}, {}
    candidates = {f"{x['kind']}_s{x['seed']}": x['checkpoint_sha256'] for x in selection['selected']}
    candidates.update(base='frozen_base', persistence=f"fit_beta={selection['beta']:.17g}")
    for name, checkpoint_hash in candidates.items():
        path = root / 'pilot/scoring' / name / 'predictions.csv'
        records = {}
        with path.open(encoding='utf-8', newline='') as handle:
            for row in csv.DictReader(handle):
                current = date.fromisoformat(row['date'])
                require(current not in records and full_grid[0] <= current <= full_grid[-1], 'Duplicate or forbidden prediction date')
                require(date.fromisoformat(row['observation_cutoff']) == current - timedelta(days=1), 'Prediction used same-day or later observed flow')
                require(row['checkpoint'] == checkpoint_hash and re.fullmatch('[0-9a-f]{64}', row['state_digest']), 'Prediction provenance mismatch')
                value = float(row['q_mm_day'])
                require(math.isfinite(value), 'Missing or nonfinite prediction')
                if name.startswith('flow_'):
                    applied = float(row['direct_flow_applied_mm_day'])
                    require(math.isfinite(applied) and abs(applied) <= 5 * measured['flow_std'] + 1e-5, 'Direct flow correction exceeds its bound')
                records[current] = value
        require(tuple(records) == full_grid, 'Prediction replay omitted days or phases')
        prediction_maps[name] = records
        result = {'full': efficiency(obs, [records[d] for d in score_grid]), 'annual': {}}
        for year in range(1986, 1990):
            annual_grid = days(date(year - 1, 10, 1), date(year, 9, 30))
            annual_obs = [observations['score'][d] for d in annual_grid]
            coverage[str(year)] = sum(math.isfinite(v) for v in annual_obs) / len(annual_obs)
            result['annual'][str(year)] = efficiency(annual_obs, [records[d] for d in annual_grid])
        calculated[name] = result
        diagnostics = load(root / 'pilot/scoring' / name / 'diagnostics.json')
        require(diagnostics['updates'] == len(full_grid) and diagnostics['checkpoint_sha256'] == checkpoint_hash,
                'Scoring diagnostics omit daily updates or a checkpoint identity')
    fit_grid = days(*PHASES['fit'])
    errors = np.asarray([observations['fit'][d] - prediction_maps['base'][d] for d in fit_grid])
    valid = np.isfinite(errors[:-1]) & np.isfinite(errors[1:])
    x, y = errors[:-1][valid], errors[1:][valid]
    denominator = math.fsum(float(value) * float(value) for value in x)
    numerator = math.fsum(float(a) * float(b) for a, b in zip(x, y, strict=True))
    beta = min(max(numerator / denominator, 0.), 1.) if denominator > 0 else 0.
    require(beta == manifest['beta'] == selection['beta'], 'Persistence coefficient differs from fit-only least squares')
    all_obs = {d: value for records in observations.values() for d, value in records.items()}
    persistence_difference = 0.
    for index, current in enumerate(full_grid):
        correction = 0.
        if index and math.isfinite(all_obs[full_grid[index - 1]]):
            yesterday = full_grid[index - 1]
            error = float(np.float32(all_obs[yesterday]) - np.float32(prediction_maps['base'][yesterday]))
            correction = beta * error
        expected = float(np.float32(np.float32(prediction_maps['base'][current]) + np.float32(correction)))
        persistence_difference = max(persistence_difference, abs(expected - prediction_maps['persistence'][current]))
    require(persistence_difference == 0., 'Persistence predictions differ from prior-day-only float32 reconstruction')
    require(set(calculated) == set(summary['methods']), 'A scoring method was dropped or added')
    differences = [abs(calculated[name][scope] - summary['methods'][name][scope]) for name in calculated for scope in ['full']]
    differences += [abs(calculated[name]['annual'][year] - summary['methods'][name]['annual'][year])
                    for name in calculated for year in coverage]
    require(max(differences) <= SCORE_TOLERANCE, 'Recomputed efficiency differs from the cluster summary')
    require(coverage == summary['coverage'] and sum(math.isfinite(v) for v in obs) == summary['common_valid_count'], 'Common date coverage mismatch')

    base = calculated['base']
    gains = [calculated[f'rain_s{seed}']['full'] - base['full'] for seed in SEEDS]
    annual = {year: statistics.median(calculated[f'rain_s{seed}']['annual'][year] - base['annual'][year] for seed in SEEDS)
              for year in coverage}
    over_persistence = statistics.median(calculated[f'rain_s{seed}']['full'] - calculated['persistence']['full'] for seed in SEEDS)
    gates = {'median_gain_at_least_0.005': statistics.median(gains) >= .005,
             'two_seeds_positive': sum(v > 0 for v in gains) >= 2,
             'three_years_positive': sum(v > 0 for v in annual.values()) >= 3,
             'beats_yesterday_error': over_persistence > 0}
    expansion = all(gates.values()) and all(value >= .9 for value in coverage.values())
    require(gates == summary['expansion_gate']['tests'] and expansion == summary['expansion_gate']['expand'], 'Gate reconstruction differs')
    require(abs(statistics.median(gains) - summary['expansion_gate']['median_gain']) <= SCORE_TOLERANCE and
            abs(over_persistence - summary['expansion_gate']['median_gain_over_persistence']) <= SCORE_TOLERANCE, 'Reported gain differs')
    medians = {kind: statistics.median(calculated[f'{kind}_s{seed}']['full'] for seed in SEEDS) for kind in KINDS}
    rain_diagnostics = check_rain_versions(root, collection, weather_dates, weather, selection['scaling']['cap'])
    return {'collected_at_utc': datetime.now(timezone.utc).isoformat(), 'success': True,
            'scope': 'Independent artifact and arithmetic reconstruction; no model rerun or independent precipitation truth.',
            'job': 235201, 'recovery_root': root.as_posix(), 'collection_manifest_sha256': sha(root / 'collection_manifest.json'),
            'integrity_file_count': len(collection['files']), 'synthetic_tests': len(cases), 'training': training,
            'input_access': {'observation_phases': obs_evidence, 'area_m2': area, 'weather_sha256': weather_hash,
                             'weather_path': weather_path.as_posix(), 'protected_period_numeric_values_parsed': 0},
            'scaling_recomputed': measured,
            'cap_representation': {'linear_quantile_float64': cap_linear_float64,
                                   'recorded_and_checkpoint_float32': measured['cap'],
                                   'difference_float64_minus_recorded': cap_linear_float64 - measured['cap'],
                                   'comparison_rule': 'exact identity after float32 rounding; other normalization fields exact'},
            'weather_input_diagnostics': {'allowed_weather_days': len(weather_dates),
                                           'equal_minimum_maximum_temperature_days': int((weather[:, 1] == weather[:, 2]).sum())},
            'common_valid_count': summary['common_valid_count'], 'coverage': coverage,
            'prediction_methods': len(calculated), 'replay_days_per_method': len(full_grid),
            'persistence_reconstruction': {'fit_only_beta': beta, 'max_absolute_prediction_difference': persistence_difference},
            'recomputed_methods': calculated, 'max_absolute_efficiency_difference': max(differences),
            'efficiency_tolerance': SCORE_TOLERANCE, 'full_period_network_medians': medians,
            'expansion_gate': {'satisfied': expansion, 'tests': gates, 'seed_gains': gains,
                               'median_gain': statistics.median(gains), 'annual_median_gains': annual,
                               'median_gain_over_persistence': over_persistence},
            'gpu_seconds_this_network': collection['total_this_network_gpu_seconds'],
            'old_multiplier_gpu_seconds_separate': 5312,
            'rain_versions': collection['rain_version_originals'],
            'rain_ledgers_recovered_and_reconstructed': rain_diagnostics,
            'score_period_negative_prediction_days': {name: sum(records[d] < 0 for d in score_grid)
                                                       for name, records in prediction_maps.items()},
            'limitations': ['No hydrologic or corrector checkpoint was rerun.',
                            'Historical base-model validation and recipe-selection provenance remains unknown.',
                            'Final rain ledgers include later observation revisions and are not evidence of true precipitation recovery.',
                            'One fixed basin and same-day weather with previously arrived flow; not day-ahead forecasting.',
                            'This test cannot establish true precipitation recovery or transfer to other basins.']}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--recovery-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root, output = args.recovery_root.resolve(), args.output.resolve()
    require(root.is_relative_to(APPROVED_RESULTS.resolve()) and output.is_relative_to(APPROVED_RESULTS.resolve()),
            'Audit inputs and outputs must stay within this experiment evidence root')
    output.mkdir(parents=True, exist_ok=False)
    try:
        result = audit(root, REPO / 'data/camels_us')
        require(not {'neuralhydrology.evaluation.assimilation', 'neuralhydrology.utils.assimilationconfig'}.intersection(sys.modules),
                'A protected assimilation module was imported')
        write(output / 'audit.json', result)
        print(json.dumps({key: result[key] for key in ('success', 'job', 'integrity_file_count', 'prediction_methods',
                         'max_absolute_efficiency_difference', 'full_period_network_medians', 'expansion_gate')}, ensure_ascii=False))
    except Exception as error:
        write(output / 'failure.json', {'type': type(error).__name__, 'error': str(error), 'scope': 'recovery audit, not experiment failure'})
        raise


if __name__ == '__main__':
    main()
