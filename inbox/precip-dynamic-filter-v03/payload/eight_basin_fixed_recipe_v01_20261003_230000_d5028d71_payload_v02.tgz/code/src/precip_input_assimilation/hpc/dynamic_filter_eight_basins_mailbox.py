"""Owned-channel transport with a locally verified, commit-bound prior receipt."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import urllib.parse

from dynamic_filter_mailbox import BRANCH, CHANNEL, Mailbox


def receipt_identity(mailbox, parent, sequence, path):
    """Check a cached large receipt against its exact remote Git blob identity."""
    remote = mailbox.api("contents/" + urllib.parse.quote(
        f"outbox/{CHANNEL}/result_{sequence}.txt", safe="/") + "?ref=" + parent,
        missing=True)
    if remote is None:
        raise RuntimeError("Previous command has no committed receipt")
    path = Path(path)
    count = path.stat().st_size
    digest = hashlib.sha1(f"blob {count}".encode() + bytes([0]))
    tail = b""
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
            tail = (tail + block)[-4096:]
    if count != remote["size"] or digest.hexdigest() != remote["sha"]:
        raise RuntimeError("Cached prior receipt differs from the pinned remote blob")
    footer = rb"### ---------- end ----------\r?\n### exit_code=0\r?\n### finished=[^\r\n]+\r?\n?\Z"
    if not re.search(footer, tail):
        raise RuntimeError("Prior receipt is not a complete successful command")
    return {"sequence": sequence, "commit": parent, "blob_sha": remote["sha"],
            "bytes": count, "exit_code": 0}


def publish(mailbox, sequence, command, prior_receipt, payload=None, support_files=()):
    if "\r" in command:
        raise ValueError("Commands must use LF endings")
    digest = hashlib.sha256(command.encode()).hexdigest()
    for attempt in range(5):
        parent = mailbox.api(f"git/ref/heads/{BRANCH}")["object"]["sha"]
        if not re.fullmatch(r"[0-9a-f]{40}", parent):
            raise RuntimeError("Invalid remote head")
        last = int(mailbox.text(f"inbox/{CHANNEL}/seq", parent).strip())
        if last == sequence:
            saved = mailbox.text(f"inbox/{CHANNEL}/cmd.sh", parent)
            if hashlib.sha256(saved.encode()).hexdigest() == digest:
                return {"sequence": sequence, "commit": parent,
                        "command_sha256": digest, "already_published": True}
            raise RuntimeError("Requested sequence belongs to a different command")
        if last != sequence - 1:
            raise RuntimeError(f"Sequence changed: remote={last}, requested={sequence}")
        receipt = receipt_identity(mailbox, parent, last, prior_receipt)
        previous = mailbox.api(f"git/commits/{parent}")
        entries = [
            {"path": f"inbox/{CHANNEL}/cmd.sh", "mode": "100755", "type": "blob", "content": command},
            {"path": f"inbox/{CHANNEL}/seq", "mode": "100644", "type": "blob", "content": str(sequence) + "\n"},
        ]
        support_names = set()
        for source in support_files:
            source = Path(source)
            if source.name in support_names or not re.fullmatch(r"[A-Za-z0-9_.-]+", source.name):
                raise ValueError("Duplicate or unsafe support file name")
            support_names.add(source.name)
            content = source.read_bytes().decode("utf-8")
            remote_path = f"inbox/{CHANNEL}/payload/{source.name}"
            present = mailbox.text(remote_path, parent)
            if present is not None and present != content:
                raise RuntimeError("A different support file already uses this remote identity")
            entries.append({"path": remote_path, "mode": "100644", "type": "blob", "content": content})
        if payload is not None:
            import base64
            payload = Path(payload)
            blob = mailbox.api("git/blobs", "POST", {
                "content": base64.b64encode(payload.read_bytes()).decode(), "encoding": "base64"})
            entries.append({"path": f"inbox/{CHANNEL}/payload/{payload.name}",
                            "mode": "100644", "type": "blob", "sha": blob["sha"]})
        tree = mailbox.api("git/trees", "POST", {"base_tree": previous["tree"]["sha"], "tree": entries})
        proposed = mailbox.api("git/commits", "POST", {
            "message": f"Run: {CHANNEL} command {sequence}", "tree": tree["sha"], "parents": [parent]})["sha"]
        if not re.fullmatch(r"[0-9a-f]{40}", proposed):
            raise RuntimeError("Invalid proposed commit")
        try:
            mailbox.api(f"git/refs/heads/{BRANCH}", "PATCH", {"sha": proposed, "force": False})
            return {"sequence": sequence, "commit": proposed, "command_sha256": digest,
                    "already_published": False, "previous_receipt": receipt}
        except RuntimeError as error:
            if "HTTP 422" not in str(error) or attempt == 4:
                raise
    raise RuntimeError("Publication could not be confirmed")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sequence", required=True, type=int)
    parser.add_argument("--command", required=True, type=Path)
    parser.add_argument("--prior-receipt", required=True, type=Path)
    parser.add_argument("--payload", type=Path)
    parser.add_argument("--support-file", action="append", type=Path, default=[])
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    result = publish(Mailbox(), args.sequence, args.command.read_text(encoding="utf-8"),
                     args.prior_receipt, args.payload, args.support_file)
    with args.output.open("x", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
