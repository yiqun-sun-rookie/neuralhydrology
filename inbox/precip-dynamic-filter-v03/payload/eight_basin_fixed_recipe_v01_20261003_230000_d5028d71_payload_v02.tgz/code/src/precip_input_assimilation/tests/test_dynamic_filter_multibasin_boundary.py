"""Synthetic numeric inputs, real frozen static selection, and adversarial read gates."""

from datetime import date, timedelta
import json
import os
from pathlib import Path
import shutil
import sys

import numpy as np
import pytest

REPO = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO / "src"))
from precip_input_assimilation.dynamic_filter_multibasin.contract import Contract, ReadPermit, guarded_path
from precip_input_assimilation.dynamic_filter_multibasin.data import read_weather, read_flow, CFS_TO_MM


@pytest.fixture
def contract(tmp_path):
    source = REPO / "src/precip_input_assimilation/configs/dynamic_filter_eight_basins_v01.json"
    instance = Contract.load(source)
    # The immutable deployment carries metadata and model artifacts outside code/.
    # These overrides never point at real daily files: only metadata is copied,
    # and every test creates its weather/flow rows in the fresh fixture directory.
    instance = instance.bind(
        data_root=Path(os.environ.get("EIGHT_TEST_DATA_ROOT", str(instance.data_root))),
        model_root=Path(os.environ.get("EIGHT_TEST_MODEL_ROOT", str(instance.model_root))))
    synthetic = tmp_path / "synthetic_data"
    attributes = synthetic / "camels_attributes_v2.0"
    attributes.mkdir(parents=True)
    # Static metadata is allowed. No real basin's daily file is opened/copied.
    for name in ("camels_topo.txt", "camels_clim.txt", "camels_name.txt", "camels_geol.txt",
                 "camels_soil.txt", "camels_vege.txt"):
        shutil.copyfile(instance.data_root / "camels_attributes_v2.0" / name, attributes / name)
    return instance.bind(data_root=synthetic).lock_roster(tmp_path / "roster_locked.json")


def synthetic_files(contract, basin=None):
    basin = basin or contract.basins[0]
    weather = contract.data_root / "basin_mean_forcing/maurer/02" / (basin + "_synthetic_forcing_leap.txt")
    flow = contract.data_root / "usgs_streamflow/02" / (basin + "_streamflow_qc.txt")
    weather.parent.mkdir(parents=True, exist_ok=True)
    flow.parent.mkdir(parents=True, exist_ok=True)
    weather.write_text("38\n2\n187410000\nYear Mnth Day Hr PRCP(mm/day) Tmin(C) Tmax(C) SRAD(W/m2) Vp(Pa)\n"
                       "1980 9 30 12 FORBIDDEN FORBIDDEN FORBIDDEN FORBIDDEN FORBIDDEN\n"
                       "1980 10 1 12 1 2 3 4 5\n1980 10 2 12 6 7 8 9 10\n"
                       "1980 10 3 12 FORBIDDEN FORBIDDEN FORBIDDEN FORBIDDEN FORBIDDEN\n",
                       encoding="utf-8")
    flow.write_text(f"{basin} 1980 9 30 FORBIDDEN A\n{basin} 1980 10 1 11 A\n"
                    f"{basin} 1980 10 2 12 A\n{basin} 1980 10 3 FORBIDDEN A\n"
                    f"{basin} 1990 10 1 FORBIDDEN A\n", encoding="utf-8")
    return weather, flow


def test_exact_static_only_roster_reconstruction(contract):
    record = contract.reconstruct_roster()
    assert record["candidate_count"] == 431
    assert tuple(row["basin"] for row in record["selection"]) == contract.basins
    assert len({row["huc02"] for row in record["selection"]}) == 8


@pytest.mark.parametrize("basin,phase,start,end", [
    ("01022500", "fit", date(1980, 10, 1), date(1980, 10, 2)),
    ("01487000", "synthetic", date(1980, 10, 1), date(1980, 10, 2)),
    ("01487000", "fit", date(1980, 9, 30), date(1980, 10, 1)),
    ("01487000", "select", date(1985, 9, 30), date(1985, 10, 1)),
    ("01487000", "score", date(1989, 9, 30), date(1989, 10, 1)),
])
def test_invalid_request_fails_before_open(contract, monkeypatch, basin, phase, start, end):
    def forbidden_open(*args, **kwargs):
        raise AssertionError("A rejected request opened a file")
    monkeypatch.setattr(Path, "open", forbidden_open)
    with pytest.raises(PermissionError):
        contract.authorize(basin, phase, start, end)


@pytest.mark.parametrize("forged", [None, {"verified": True, "phase": "score"}, "fit"])
def test_missing_or_caller_forged_capabilities_fail_before_open(contract, monkeypatch, forged):
    monkeypatch.setattr(Path, "open", lambda *a, **k: pytest.fail("Forged permission opened a file"))
    with pytest.raises(PermissionError):
        read_weather(contract, contract.basins[0], "fit", date(1980, 10, 1), date(1980, 10, 2), forged)


def test_lookalike_and_mutated_permit_not_authority(contract, monkeypatch):
    permit = contract.authorize(contract.basins[0], "fit", date(1980, 10, 1), date(1980, 10, 2))
    fake = object.__new__(ReadPermit)
    for name, value in vars(permit).items():
        object.__setattr__(fake, name, value)
    monkeypatch.setattr(Path, "open", lambda *a, **k: pytest.fail("Forged permission opened a file"))
    for tested in (fake, permit):
        if tested is permit:
            object.__setattr__(tested, "basin", contract.basins[1])
        with pytest.raises(PermissionError):
            read_weather(contract, tested.basin, "fit", tested.start, tested.end, tested)


def test_warmup_flow_rejected_before_open(contract, monkeypatch):
    permit = contract.authorize(contract.basins[0], "warmup", date(1980, 1, 1), date(1980, 1, 2))
    monkeypatch.setattr(Path, "open", lambda *a, **k: pytest.fail("Warmup flow attempted to open a file"))
    with pytest.raises(PermissionError):
        read_flow(contract, contract.basins[0], "warmup", permit.start, permit.end, permit)


def test_only_permitted_daily_values_are_evaluated(contract):
    synthetic_files(contract)
    start, end = date(1980, 10, 1), date(1980, 10, 2)
    permit = contract.authorize(contract.basins[0], "fit", start, end)
    weather = read_weather(contract, contract.basins[0], "fit", start, end, permit)
    flow = read_flow(contract, contract.basins[0], "fit", start, end, permit)
    np.testing.assert_array_equal(weather.values, np.arange(1, 11).reshape(2, 5))
    np.testing.assert_allclose(flow.values, np.asarray([11, 12]) * CFS_TO_MM / 187410000)
    assert not weather.values.flags.writeable and not flow.values.flags.writeable
    assert flow.conversion["area_m2"] == weather.area_m2


def test_wrong_basin_area_rejected(contract):
    synthetic_files(contract)
    start, end = date(1980, 10, 1), date(1980, 10, 2)
    permit = contract.authorize(contract.basins[0], "fit", start, end)
    with pytest.raises(PermissionError, match="conversion area"):
        read_flow(contract, contract.basins[0], "fit", start, end, permit, area_m2=123456)


def test_row_basin_mismatch_rejected(contract):
    _, flow = synthetic_files(contract)
    flow.write_text("12040500 1980 10 1 1 A\n", encoding="utf-8")
    permit = contract.authorize(contract.basins[0], "fit", date(1980, 10, 1), date(1980, 10, 1))
    with pytest.raises(PermissionError):
        read_flow(contract, contract.basins[0], "fit", permit.start, permit.end, permit)


def test_permit_bound_to_exact_date_basin_and_deployment(contract, tmp_path, monkeypatch):
    start, end = date(1980, 10, 1), date(1980, 10, 2)
    permit = contract.authorize(contract.basins[0], "fit", start, end)
    monkeypatch.setattr(Path, "open", lambda *a, **k: pytest.fail("Mismatched permission opened a file"))
    for instance, basin, last in ((contract, contract.basins[1], end), (contract, contract.basins[0], start),
                                  (contract.bind(data_root=tmp_path / "other"), contract.basins[0], end)):
        with pytest.raises(PermissionError):
            read_weather(instance, basin, "fit", start, last, permit)


def test_symlink_path_escape_rejected_before_daily_open(contract, tmp_path, monkeypatch):
    start, end = date(1980, 10, 1), date(1980, 10, 2)
    permit = contract.authorize(contract.basins[0], "fit", start, end)
    directory = contract.data_root / "basin_mean_forcing/maurer"
    directory.mkdir(parents=True)
    outside = tmp_path / (contract.basins[0] + "_outside_forcing_leap.txt")
    outside.write_text("DO NOT OPEN", encoding="utf-8")
    link = directory / (contract.basins[0] + "_symlink_forcing_leap.txt")
    try:
        link.symlink_to(outside)
    except OSError:
        pytest.skip("This Windows account does not permit symlink creation")
    original = Path.open
    def spy(path, *args, **kwargs):
        if path.resolve() == outside.resolve():
            pytest.fail("Escaped daily file was opened")
        return original(path, *args, **kwargs)
    monkeypatch.setattr(Path, "open", spy)
    with pytest.raises(PermissionError):
        read_weather(contract, contract.basins[0], "fit", start, end, permit)


@pytest.mark.parametrize("relative", ["../outside.txt", ".worktrees/forbidden.txt"])
def test_lexical_and_resolved_path_escape_without_symlink_privilege(contract, monkeypatch, relative):
    monkeypatch.setattr(Path, "open", lambda *a, **k: pytest.fail("Invalid path was opened"))
    with pytest.raises(PermissionError):
        guarded_path(contract.data_root / relative, contract.data_root)


def test_no_global_selection_lock_no_scoring(contract, monkeypatch):
    opened = []
    original = Path.open
    def spy(path, *args, **kwargs):
        if "basin_mean_forcing" in path.parts or "usgs_streamflow" in path.parts:
            opened.append(path)
        return original(path, *args, **kwargs)
    monkeypatch.setattr(Path, "open", spy)
    with pytest.raises(PermissionError):
        contract.authorize(contract.basins[0], "score", date(1985, 10, 1), date(1989, 9, 30))
    assert not opened


def test_incomplete_global_selection_lock_cannot_issue_score_permit(contract, tmp_path):
    lock = tmp_path / "global_selection_locked.json"
    lock.write_text(json.dumps({"contract_sha256": contract.sha256, "basins": list(contract.basins),
                               "checkpoint_count": 71, "score_observations_read": False}), encoding="utf-8")
    with pytest.raises(PermissionError):
        contract.authorize(contract.basins[0], "score", date(1985, 10, 1), date(1989, 9, 30), lock)


def test_input_changes_with_preserved_mean_change_canonical_identity(contract):
    weather_path, _ = synthetic_files(contract)
    start, end = date(1980, 10, 1), date(1980, 10, 2)
    permit = contract.authorize(contract.basins[0], "fit", start, end)
    before = read_weather(contract, contract.basins[0], "fit", start, end, permit)
    text = weather_path.read_text(encoding="utf-8")
    text = text.replace("1980 10 1 12 1 2 3 4 5", "1980 10 1 12 6 7 8 9 10")
    text = text.replace("1980 10 2 12 6 7 8 9 10", "1980 10 2 12 1 2 3 4 5")
    weather_path.write_text(text, encoding="utf-8")
    after = read_weather(contract, contract.basins[0], "fit", start, end, permit)
    np.testing.assert_array_equal(before.values.mean(axis=0), after.values.mean(axis=0))
    np.testing.assert_array_equal(before.values.var(axis=0), after.values.var(axis=0))
    assert before.canonical_sha256 != after.canonical_sha256


def test_static_mapping_matches_frozen_attribute_reader_without_model_execution(contract):
    from precip_input_assimilation.dynamic_filter_multibasin.hydro import load_static_binding, STATIC_NAMES
    from precip_input_assimilation.selfrule.data import load_normalized_attributes
    expected = load_normalized_attributes(contract.data_root, contract.model_root, contract.basins)
    for index, basin in enumerate(contract.basins):
        binding = load_static_binding(contract, basin)
        assert binding.basin == basin and binding.names == STATIC_NAMES and len(binding.raw) == 27
        np.testing.assert_array_equal(binding.normalized, expected[index])


def test_static_identity_records_area_raw_values_and_missing_flags(contract):
    from precip_input_assimilation.dynamic_filter_multibasin.hydro import load_static_binding
    before = load_static_binding(contract, contract.basins[0])
    topo = contract.data_root / "camels_attributes_v2.0/camels_topo.txt"
    original = topo.read_text(encoding="utf-8")
    lines = original.splitlines()
    columns = lines[0].split(";")
    index = columns.index("area_gages2")
    for row, line in enumerate(lines[1:], 1):
        fields = line.split(";")
        if fields[0] == contract.basins[0]:
            fields[index] = str(float(fields[index]) + 1)
            lines[row] = ";".join(fields)
            break
    topo.write_text("\n".join(lines) + "\n", encoding="utf-8")
    # A metadata mutation cannot be adopted as the same locked roster.
    with pytest.raises(PermissionError, match="metadata changed"):
        load_static_binding(contract, contract.basins[0])
    assert before.raw[before.names.index("area_gages2")] == 187.41
    assert len(before.missing) == 27


def test_complete_input_gate_rejects_foreign_static_and_modified_numeric_array(contract, monkeypatch):
    from precip_input_assimilation.dynamic_filter_multibasin import hydro
    from precip_input_assimilation.dynamic_filter_multibasin.data import load_inputs, build_input_gate
    basin = contract.basins[1]
    weather, flow = synthetic_files(contract, basin)
    weather_rows = ["47", "2", "1153440000",
                    "Year Mnth Day Hr PRCP(mm/day) Tmin(C) Tmax(C) SRAD(W/m2) Vp(Pa)"]
    flow_rows = []
    current, last = date(1980, 1, 1), date(1985, 9, 30)
    while current <= last:
        offset = (current - date(1980, 1, 1)).days
        weather_rows.append(f"{current.year} {current.month} {current.day} 12 {1 + offset % 3} 2 3 4 5")
        flow_rows.append(f"{basin} {current.year} {current.month} {current.day} {10 + offset % 19} A")
        current += timedelta(days=1)
    weather.write_text("\n".join(weather_rows) + "\n", encoding="utf-8")
    flow.write_text("\n".join(flow_rows) + "\n", encoding="utf-8")
    inputs = load_inputs(contract, basin)
    gate = build_input_gate(contract, basin, inputs=inputs)
    assert gate["pass"] and gate["area_identity"]["forcing_area_m2"] == 1153440000
    assert gate["static_identity"]["basin"] == basin
    foreign = hydro.load_static_binding(contract, contract.basins[0])
    with monkeypatch.context() as patch:
        patch.setattr(hydro, "load_static_binding", lambda *a, **k: foreign)
        with pytest.raises(PermissionError, match="different basin"):
            build_input_gate(contract, basin, inputs=inputs)
    inputs.weather = inputs.weather.copy()
    inputs.weather[300, 0] += .125
    with pytest.raises(PermissionError, match="numeric arrays changed"):
        build_input_gate(contract, basin, inputs=inputs)
