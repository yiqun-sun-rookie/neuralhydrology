"""Adversarial immutable member and offline entry checks; entirely synthetic."""

import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import time
from types import SimpleNamespace

import pytest

REPO = Path(__file__).resolve().parents[3]
SPEC = importlib.util.spec_from_file_location("eight_bundle_tested", REPO /
    "src/precip_input_assimilation/hpc/dynamic_filter_eight_basins_bundle.py")
BUNDLE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BUNDLE)


def fixture_files():
    files = {name: b"synthetic\n" for name in BUNDLE.REQUIRED}
    for name in files:
        if name.startswith("code/") and name.endswith(".py"):
            files[name] = b"# Synthetic module, no data access.\n"
    for entry in ("scripts/run_dynamic_filter_eight_basins.py",
                  "scripts/run_dynamic_filter_eight_basins_technical.py",
                  "hpc/dynamic_filter_eight_basins_bundle.py"):
        files["code/" + BUNDLE.PREFIX + entry] = b"import argparse\nargparse.ArgumentParser().parse_args()\n"
    budget = {"budget_total_seconds": 259200, "used_gpu_seconds": 24378,
              "unsettled_reserved_seconds": 0, "unsettled_jobs": [], "remaining_gpu_seconds": 234822}
    files["records/budget_snapshot.json"] = BUNDLE.json_bytes(budget)
    files["source_manifest.json"] = BUNDLE.json_bytes({name[5:]: BUNDLE.digest(value)
        for name, value in files.items() if name.startswith("code/") and Path(name).suffix in (".py", ".sh", ".slurm")})
    identity_paths = {"contract_sha256": "code/" + BUNDLE.CONTRACT,
        "roster_sha256": "code/" + BUNDLE.ROSTER, "plan_sha256": "code/" + BUNDLE.PLAN,
        "roster_lock_sha256": "records/roster_locked.json", "budget_snapshot_sha256": "records/budget_snapshot.json"}
    metadata = dict(run_id="synthetic_only", remaining_gpu_seconds=234822,
                    **{key: BUNDLE.digest(files[path]) for key, path in identity_paths.items()})
    return files, metadata


def payload(tmp_path, files):
    path = tmp_path / "synthetic.tgz"
    result = BUNDLE.write_archive(files, path)
    return path, result["sha256"]


def test_complete_explicit_bundle_seals_all_members(tmp_path):
    files, metadata = fixture_files()
    sealed = BUNDLE.seal_files(files, metadata)
    BUNDLE.verify_files(sealed)
    path, digest = payload(tmp_path, sealed)
    target = tmp_path / "new_output"
    report = BUNDLE.offline(path, target, digest)
    assert report["success"]
    assert len(report["checks"]) == 3
    assert BUNDLE.verify(target)["run_id"] == "synthetic_only"
    with pytest.raises(FileExistsError):
        BUNDLE.safe_extract(path, target, digest)


@pytest.mark.parametrize("missing", ["code/" + BUNDLE.CONTRACT,
    "code/" + BUNDLE.ROSTER, "code/" + BUNDLE.PREFIX + "dynamic_filter_multibasin/data.py",
    "provenance/metadata/camels_vege.txt", "provenance/metadata/camels_soil.txt",
    "provenance/metadata/camels_geol.txt"])
def test_omitted_json_roster_or_adapter_rejected_even_when_resealed(missing):
    files, metadata = fixture_files()
    del files[missing]
    with pytest.raises(RuntimeError, match="Required files omitted"):
        BUNDLE.verify_files(BUNDLE.seal_files(files, metadata))


def test_source_tampering_missing_and_extra_files_rejected():
    files, metadata = fixture_files()
    original = BUNDLE.seal_files(files, metadata)
    changed = dict(original)
    changed["code/" + BUNDLE.PREFIX + "dynamic_filter_multibasin/controller.py"] += b"# change\n"
    with pytest.raises(RuntimeError, match="identity mismatch"):
        BUNDLE.verify_files(changed)
    changed = dict(original, **{"undeclared.txt": b"extra"})
    with pytest.raises(RuntimeError, match="undeclared"):
        BUNDLE.verify_files(changed)
    changed = dict(original)
    del changed["records/roster_locked.json"]
    with pytest.raises(RuntimeError, match="undeclared"):
        BUNDLE.verify_files(changed)


def test_source_manifest_cannot_omit_new_module():
    files, metadata = fixture_files()
    sources = json.loads(files["source_manifest.json"])
    del sources[BUNDLE.PREFIX + "dynamic_filter_multibasin/data.py"]
    files["source_manifest.json"] = BUNDLE.json_bytes(sources)
    with pytest.raises(RuntimeError, match="Incomplete source"):
        BUNDLE.verify_files(BUNDLE.seal_files(files, metadata))


@pytest.mark.parametrize("name", ["/abs.txt", "../parent.txt", "code/../parent.txt",
    "C:/drive.txt", "code\\bad.py", "code/.worktrees/x.py", "code/./file.py"])
def test_unsafe_member_fails_before_extraction(tmp_path, name):
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode="w") as archive:
        info = tarfile.TarInfo(name)
        info.size = 1
        archive.addfile(info, io.BytesIO(b"x"))
    path = tmp_path / "unsafe.tgz"
    path.write_bytes(gzip.compress(stream.getvalue(), mtime=0))
    with pytest.raises((ValueError, RuntimeError)):
        BUNDLE.archive_files(path)
    assert not (tmp_path / "parent.txt").exists()


@pytest.mark.parametrize("kind", ["symbolic", "hard", "duplicate", "case_collision"])
def test_archive_links_and_duplicates_rejected(tmp_path, kind):
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode="w") as archive:
        info = tarfile.TarInfo("code/test.py")
        if kind in ("symbolic", "hard"):
            info.type = tarfile.SYMTYPE if kind == "symbolic" else tarfile.LNKTYPE
            info.linkname = "../outside.py"
            archive.addfile(info)
        else:
            for name in ("code/test.py", "code/Test.py" if kind == "case_collision" else "code/test.py"):
                info = tarfile.TarInfo(name)
                info.size = 1
                archive.addfile(info, io.BytesIO(b"x"))
    path = tmp_path / "bad.tgz"
    path.write_bytes(gzip.compress(stream.getvalue(), mtime=0))
    with pytest.raises(RuntimeError):
        BUNDLE.archive_files(path)


def test_archive_digest_mismatch_rejected_before_output_creation(tmp_path):
    files, metadata = fixture_files()
    path, _ = payload(tmp_path, BUNDLE.seal_files(files, metadata))
    output = tmp_path / "not_created"
    with pytest.raises(RuntimeError, match="Outer archive identity"):
        BUNDLE.safe_extract(path, output, "0" * 64)
    assert not output.exists()


@pytest.mark.parametrize("change", [{"used_gpu_seconds": 0}, {"unsettled_jobs": ["running"]},
    {"remaining_gpu_seconds": 259200}, {"used_gpu_seconds": 259200, "remaining_gpu_seconds": 0}])
def test_budget_cannot_reset_ignore_unsettled_or_exhaust(change):
    value = {"budget_total_seconds": 259200, "used_gpu_seconds": 24378,
             "unsettled_reserved_seconds": 0, "unsettled_jobs": [], "remaining_gpu_seconds": 234822}
    value.update(change)
    with pytest.raises(RuntimeError):
        BUNDLE.budget_remaining(value)


@pytest.mark.parametrize("entry", ["scripts/run_dynamic_filter_eight_basins.py",
    "scripts/run_dynamic_filter_eight_basins_technical.py", "hpc/dynamic_filter_eight_basins_bundle.py"])
def test_real_entry_help_never_imports_numeric_or_model_modules(tmp_path, entry):
    guard = tmp_path / "sitecustomize.py"
    guard.write_text("import sys\nclass NoModels:\n    def find_spec(self, fullname, path=None, target=None):\n"
                     "        if fullname.split('.')[0] in ('torch', 'numpy', 'neuralhydrology'):\n"
                     "            raise RuntimeError('Help imported a numeric/model dependency')\n"
                     "sys.meta_path.insert(0, NoModels())\n", encoding="utf-8")
    environment = dict(os.environ, PYTHONPATH=str(tmp_path), PYTHONDONTWRITEBYTECODE="1")
    result = subprocess.run([sys.executable, "-B", str(REPO / BUNDLE.PREFIX / entry), "--help"],
                            env=environment, cwd=tmp_path, capture_output=True, text=True, timeout=30)
    assert result.returncode == 0, result.stderr
    assert "usage:" in result.stdout


def test_job_supervisor_inherits_one_runtime_root_for_all_stages(tmp_path, monkeypatch):
    specification = importlib.util.spec_from_file_location("eight_technical_tested", REPO /
        "src/precip_input_assimilation/scripts/run_dynamic_filter_eight_basins_technical.py")
    technical = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(technical)
    root = tmp_path / "run" / "runtime"
    root.mkdir(parents=True)
    budget = tmp_path / "budget.json"
    budget.write_bytes(BUNDLE.json_bytes({"budget_total_seconds": 259200, "used_gpu_seconds": 24378,
        "unsettled_reserved_seconds": 0, "unsettled_jobs": [], "remaining_gpu_seconds": 234822}))
    monkeypatch.setenv("SLURM_JOB_ID", "synthetic_only")
    monkeypatch.setenv("EIGHT_JOB_STARTED_UNIX", str(time.time()))
    monkeypatch.delenv("EIGHT_BASIN_OUTPUT_ROOT", raising=False)
    calls = []

    def stage(command, timeout, environment=None, stdout=None, own_group=False):
        assert os.environ["EIGHT_BASIN_OUTPUT_ROOT"] == str(root.resolve())
        assert Path(command[command.index("--output") + 1]).is_relative_to(root)
        assert timeout > 0
        calls.append(command)
        return subprocess.CompletedProcess(command, 0, "", "")

    monkeypatch.setattr(technical, "bounded_process", stage)
    args = SimpleNamespace(contract=tmp_path / "contract.json", data_root=tmp_path / "data",
        model_root=tmp_path / "model", roster_lock=tmp_path / "roster.json", budget_record=budget, device="cuda:0")
    technical.job(args, root)
    assert len(calls) == 6
    assert (root / "job_complete.json").is_file()
    assert not (root.parent / "payload").exists()


def test_synthetic_input_mapping_copies_six_static_tables_only(tmp_path, monkeypatch):
    specification = importlib.util.spec_from_file_location("eight_technical_metadata", REPO /
        "src/precip_input_assimilation/scripts/run_dynamic_filter_eight_basins_technical.py")
    technical = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(technical)
    source = tmp_path / "input_source"
    attributes = source / "camels_attributes_v2.0"
    attributes.mkdir(parents=True)
    for name in technical.STATIC_TABLES:
        (attributes / name).write_text("SYNTHETIC_STATIC_" + name, encoding="utf-8")
    (source / "NEVER_COPY_DAILY.txt").write_text("FORBIDDEN_DAILY", encoding="utf-8")
    model = tmp_path / "model_mapping"
    model.mkdir()
    monkeypatch.setenv("EIGHT_TEST_DATA_ROOT", str(source))
    monkeypatch.setenv("EIGHT_TEST_MODEL_ROOT", str(model))
    root = tmp_path / "runtime"
    root.mkdir()
    mapping = technical.prepare_synthetic_inputs(root)
    target = Path(mapping["data_root"])
    assert mapping["model_root"] == str(model.resolve())
    assert set(mapping["static_table_sha256"]) == set(technical.STATIC_TABLES)
    assert sorted(path.relative_to(target).as_posix() for path in target.rglob("*") if path.is_file()) == sorted(
        "camels_attributes_v2.0/" + name for name in technical.STATIC_TABLES)
    assert not (target / "NEVER_COPY_DAILY.txt").exists()
    for name in technical.STATIC_TABLES:
        assert mapping["static_table_sha256"][name] == hashlib.sha256((attributes / name).read_bytes()).hexdigest()


def test_windows_synthetic_temp_uses_short_registered_results_ancestor(tmp_path):
    specification = importlib.util.spec_from_file_location("eight_technical_short_tmp", REPO /
        "src/precip_input_assimilation/scripts/run_dynamic_filter_eight_basins_technical.py")
    technical = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(technical)
    allowed = next((path for path in (tmp_path, *tmp_path.parents)
        if path.name == "dynamic_filter_v03" and path.parent.name == "precip_input_da_2026_09"
        and path.parent.parent.name == "results"),
        tmp_path / "results/precip_input_da_2026_09/dynamic_filter_v03")
    deep_output = allowed / "synthetic_path_fixture" / ("deeper_payload_snapshot" * 5) / "runtime/synthetic"
    temporary = technical.synthetic_temporary_root(deep_output, platform_name="nt")
    assert temporary.parent == allowed / "_tmp"
    assert len(str(temporary)) < len(str(deep_output))
    assert len(temporary.name) == 14
    assert temporary.is_dir()
    with pytest.raises(PermissionError, match="registered results ancestor"):
        technical.synthetic_temporary_root(Path(tmp_path.anchor) / "synthetic_unregistered_test", platform_name="nt")


def test_linux_synthetic_temp_stays_outside_payload_and_summary_is_short(tmp_path):
    specification = importlib.util.spec_from_file_location("eight_technical_linux_tmp", REPO /
        "src/precip_input_assimilation/scripts/run_dynamic_filter_eight_basins_technical.py")
    technical = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(technical)
    root = tmp_path / "runtime"
    temporary = technical.synthetic_temporary_root(root, platform_name="posix")
    assert temporary.parent == root / "synthetic_tmp"
    assert temporary.is_dir()
    assert technical.pytest_summary("trace\n" * 1000 + "===== 46 passed, 74 errors in 2.0s =====\n") == (
        "46 passed, 74 errors in 2.0s")
    with pytest.raises(PermissionError, match="payload/code"):
        technical.synthetic_temporary_root(tmp_path / "payload/code/runtime", platform_name="posix")


@pytest.mark.parametrize("escape", [False, True])
def test_main_cli_runtime_output_allowed_and_escape_rejected_before_reads(tmp_path, escape):
    """Exercise the actual CLI path gate with synthetic dependencies that forbid reads."""
    stub = tmp_path / "sitecustomize.py"
    stub.write_text(
        "import sys,types,json\nfrom pathlib import Path\n"
        "for name in ('precip_input_assimilation','precip_input_assimilation.dynamic_filter_multibasin'):\n"
        "    module=types.ModuleType(name); module.__path__=[]; sys.modules[name]=module\n"
        "stem='precip_input_assimilation.dynamic_filter_multibasin.'\n"
        "for name in ('contract','controller','identity'):\n"
        "    sys.modules[stem+name]=types.ModuleType(stem+name)\n"
        "class Contract:\n"
        "    @staticmethod\n"
        "    def load(path):\n"
        "        raise RuntimeError('SYNTHETIC_REACHED_CONTRACT_NO_INPUT_READ')\n"
        "sys.modules[stem+'contract'].Contract=Contract\n"
        "for name in ('check_budget_record','configure_numerics','lock_all','numerical_runtime',"
        "'preflight','score_all','train_basin'):\n"
        "    setattr(sys.modules[stem+'controller'],name,lambda *a,**k: None)\n"
        "for name in ('BasinSelection','bound_path','canonical_digest','read_json','require_sources','sha256'):\n"
        "    setattr(sys.modules[stem+'identity'],name,lambda *a,**k: None)\n"
        "def write_json(path,value):\n"
        "    Path(path).write_text(json.dumps(value),encoding='utf-8')\n"
        "sys.modules[stem+'identity'].write_json=write_json\n", encoding="utf-8")
    runtime = tmp_path / "private_run" / "runtime"
    runtime.mkdir(parents=True)
    output = runtime.parent / "escape" if escape else runtime / "preflight"
    environment = dict(os.environ, PYTHONPATH=str(tmp_path), PYTHONDONTWRITEBYTECODE="1",
                       EIGHT_BASIN_OUTPUT_ROOT=str(runtime))
    main = REPO / BUNDLE.PREFIX / "scripts/run_dynamic_filter_eight_basins.py"
    command = [sys.executable, "-B", str(main), "preflight", "--repo", str(tmp_path / "payload/code"),
        "--contract", str(tmp_path / "unread_contract"), "--data-root", str(tmp_path / "unread_data"),
        "--model-root", str(tmp_path / "unread_model"), "--roster-lock", str(tmp_path / "unread_roster"),
        "--output", str(output), "--deadline-monotonic", str(time.monotonic() + 1000),
        "--budget-record", str(tmp_path / "unread_budget")]
    process = subprocess.run(command, cwd=tmp_path, env=environment, capture_output=True, text=True, timeout=30)
    assert process.returncode != 0
    if escape:
        assert "Output must stay inside the registered" in process.stderr
        assert "SYNTHETIC_REACHED_CONTRACT" not in process.stderr
        assert not output.exists()
    else:
        assert "SYNTHETIC_REACHED_CONTRACT_NO_INPUT_READ" in process.stderr
        assert (output / "failure.json").is_file()
