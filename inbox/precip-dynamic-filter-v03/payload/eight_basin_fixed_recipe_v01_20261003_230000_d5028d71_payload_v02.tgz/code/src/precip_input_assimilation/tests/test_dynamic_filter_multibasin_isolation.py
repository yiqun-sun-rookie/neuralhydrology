"""Synthetic isolation and adversarial selection/input identity counterexamples."""

from datetime import date, timedelta
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from types import SimpleNamespace

import numpy as np
import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from precip_input_assimilation.dynamic_filter.protocol import Phase, Scaling
from precip_input_assimilation.dynamic_filter.network import FlowCorrector, RainCorrector
from precip_input_assimilation.dynamic_filter.rollout import Replay, ToyHydro
from precip_input_assimilation.dynamic_filter_multibasin import identity
from precip_input_assimilation.dynamic_filter_multibasin.contract import BASINS, PENALTIES, SEEDS
from precip_input_assimilation.dynamic_filter_multibasin.data import canonical_series


def _contract(tmp_path):
    return SimpleNamespace(basins=BASINS, seeds=SEEDS, penalties=PENALTIES, sha256="contract", repo=tmp_path)


def _complete_lock(tmp_path, monkeypatch):
    contract = _contract(tmp_path)
    monkeypatch.setattr(identity, "require_sources", lambda *_: None)
    monkeypatch.setattr(identity, "require_input_identity", lambda *_, **__: None)
    records = []
    for basin in BASINS:
        directory = tmp_path / "basins" / basin
        directory.mkdir(parents=True)
        gate = {"basin": basin, "sources": {"source.py": "source"}, "model_identity": {"model": "frozen"}}
        identity.write_json(directory / "input_gate.json", gate)
        fits = []
        for kind in identity.METHODS:
            for seed in SEEDS:
                target = directory / "fits" / kind / f"seed_{seed}"
                target.mkdir(parents=True)
                torch.manual_seed(seed)
                network = FlowCorrector(1.) if kind == "flow" else RainCorrector(1., historical=kind == "historical")
                torch.save({"state_dict": network.state_dict(), "kind": kind, "basin": basin,
                            "seed": seed, "penalty": PENALTIES[kind], "epoch": 1,
                            "validation_nse": .75, "contract_sha256": "contract",
                            "input_identity_sha256": identity.canonical_digest(gate)}, target / "selected.pt")
                fit = {"basin": basin, "kind": kind, "seed": seed, "penalty": PENALTIES[kind],
                       "complete": True, "contract_sha256": "contract",
                       "best_epoch": 1, "validation_nse": .75,
                       "input_identity_sha256": identity.canonical_digest(gate),
                       "checkpoint": (target / "selected.pt").relative_to(tmp_path).as_posix(),
                       "checkpoint_sha256": identity.sha256(target / "selected.pt")}
                identity.write_json(target / "fit_summary.json", fit)
                fits.append(dict(fit, fit_summary=(target / "fit_summary.json").relative_to(tmp_path).as_posix(),
                                 fit_summary_identity=identity.canonical_digest(fit)))
        selection = identity.BasinSelection(basin, tuple(fits), {}, 0.,
                    (directory / "input_gate.json").relative_to(tmp_path).as_posix(),
                    identity.sha256(directory / "input_gate.json"), identity.canonical_digest(gate),
                    gate["sources"], gate["model_identity"], "tensors", "contract", str(tmp_path))
        selection_path = directory / "selection_locked.json"
        identity.write_json(selection_path, selection.as_dict())
        records.append({"basin": basin, "training_root": str(tmp_path),
                        "selection_file": selection_path.relative_to(tmp_path).as_posix(),
                        "selection_sha256": identity.sha256(selection_path),
                        "selection_identity": identity.canonical_digest(selection.as_dict())})
    lock = {"contract_sha256": "contract", "basins": list(BASINS), "checkpoint_count": 72,
            "selections": records, "score_observations_read": False}
    identity.write_json(tmp_path / "global.json", lock)
    return contract, tmp_path / "global.json", lock


def _replace_json(path, value):
    path.write_text(json.dumps(value), encoding="utf-8")


def test_all_72_locked_files_are_verified_before_scoring(tmp_path, monkeypatch):
    contract, path, _ = _complete_lock(tmp_path, monkeypatch)
    assert identity.validate_global_lock(contract, path) == identity.sha256(path)
    checkpoint = tmp_path / "basins" / BASINS[-1] / "fits/historical/seed_1003/selected.pt"
    checkpoint.write_bytes(b"tampered last of all 72")
    with pytest.raises(PermissionError, match="checkpoint changed"):
        identity.validate_global_lock(contract, path)


@pytest.mark.parametrize("damage", ("71", "duplicate_basin", "duplicate_seed", "wrong_penalty", "wrong_method"))
def test_partial_duplicate_or_wrong_recipe_cannot_unlock_score(tmp_path, monkeypatch, damage):
    contract, path, lock = _complete_lock(tmp_path, monkeypatch)
    if damage == "71":
        lock["checkpoint_count"] = 71
    elif damage == "duplicate_basin":
        lock["selections"][-1]["basin"] = BASINS[0]
    else:
        item = lock["selections"][0]
        selection_path = tmp_path / item["selection_file"]
        selection = identity.read_json(selection_path)
        fit = selection["selected"][1]
        fit["seed"] = 1001 if damage == "duplicate_seed" else fit["seed"]
        fit["penalty"] = .01 if damage == "wrong_penalty" else fit["penalty"]
        fit["kind"] = "unknown" if damage == "wrong_method" else fit["kind"]
        _replace_json(selection_path, selection)
        item["selection_sha256"] = identity.sha256(selection_path)
        item["selection_identity"] = identity.canonical_digest(selection)
    _replace_json(path, lock)
    with pytest.raises(PermissionError):
        identity.validate_global_lock(contract, path)


@pytest.mark.parametrize("damage", ("reused_seed_payload", "wrong_epoch", "wrong_method_payload",
                                    "wrong_penalty_payload", "wrong_validation_payload", "summary_disagrees"))
def test_actual_payload_and_summary_must_match_even_when_all_outer_hashes_are_updated(tmp_path, monkeypatch, damage):
    contract, path, lock = _complete_lock(tmp_path, monkeypatch)
    item = lock["selections"][0]
    selection_path = tmp_path / item["selection_file"]
    selection = identity.read_json(selection_path)
    fit = selection["selected"][1]
    checkpoint = tmp_path / fit["checkpoint"]
    if damage == "reused_seed_payload":
        checkpoint.write_bytes((tmp_path / selection["selected"][0]["checkpoint"]).read_bytes())
    elif damage == "summary_disagrees":
        fit["best_epoch"] = 2
    else:
        payload = torch.load(checkpoint, map_location="cpu", weights_only=True)
        key, replacement = {"wrong_epoch": ("epoch", 2), "wrong_method_payload": ("kind", "flow"),
                            "wrong_penalty_payload": ("penalty", .01),
                            "wrong_validation_payload": ("validation_nse", .76)}[damage]
        payload[key] = replacement
        torch.save(payload, checkpoint)
    fit["checkpoint_sha256"] = identity.sha256(checkpoint)
    if damage != "summary_disagrees":
        summary = {key: value for key, value in fit.items() if key not in ("fit_summary", "fit_summary_identity")}
        _replace_json(tmp_path / fit["fit_summary"], summary)
        fit["fit_summary_identity"] = identity.canonical_digest(summary)
    _replace_json(selection_path, selection)
    item["selection_sha256"] = identity.sha256(selection_path)
    item["selection_identity"] = identity.canonical_digest(selection)
    _replace_json(path, lock)
    with pytest.raises(PermissionError, match="metadata differs|summary contents differ"):
        identity.validate_global_lock(contract, path)


@pytest.mark.parametrize("damage", (None, "static", "area", "numeric_runtime", "trajectory"))
def test_real_probe_orchestrator_binds_static_area_runtime_and_independent_reference(tmp_path, monkeypatch, damage):
    from precip_input_assimilation.dynamic_filter_multibasin import controller
    contract = SimpleNamespace(basins=BASINS, path=tmp_path / "contract.json", repo=tmp_path,
                               data_root=tmp_path / "data", model_root=tmp_path / "model",
                               roster_lock=tmp_path / "roster.json")
    calls = []

    def injected_trajectory(_, basin, device, deadline):
        calls.append(basin)
        return {"basin": basin, "seed": 1001, "dates": ["1980-10-01", "1980-10-02"],
                "trajectory": [1., 2.], "numeric_runtime": {"device": device, "torch": "synthetic"},
                "sources": {"controller.py": "source"}, "input_identity_sha256": basin,
                "static_identity": {"basin": basin, "values": [1., 2.]},
                "area_identity": {"basin": basin, "forcing_area_m2": 100.},
                "model_tensor_sha256": "frozen"}

    def injected_reference(command, **kwargs):
        parameters = json.loads(command[-1])
        reference = injected_trajectory(contract, parameters["basin"], parameters["device"], parameters["deadline"])
        if damage == "static":
            reference["static_identity"]["values"][0] = 3.
        elif damage == "area":
            reference["area_identity"]["forcing_area_m2"] = 101.
        elif damage == "numeric_runtime":
            reference["numeric_runtime"]["torch"] = "different"
        elif damage == "trajectory":
            reference["trajectory"][0] = 10.
        identity.write_json(Path(parameters["output"]), reference)
        assert kwargs["timeout"] <= parameters["deadline"] - time.monotonic() + 1.
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr(controller, "_isolation_trajectory", injected_trajectory)
    monkeypatch.setattr(controller.subprocess, "run", injected_reference)
    if damage is None:
        result = controller.probe_adapter_isolation(contract, BASINS[0], tmp_path, time.monotonic() + 60., "cpu")
        assert result["maximum_absolute_difference"] == 0.
        assert result["reference"]["numeric_runtime"] == result["after_other_basin"]["numeric_runtime"]
        assert calls == [BASINS[-1], BASINS[0], BASINS[0]]
    else:
        with pytest.raises((PermissionError, RuntimeError)):
            controller.probe_adapter_isolation(contract, BASINS[0], tmp_path, time.monotonic() + 60., "cpu")


@pytest.mark.parametrize("damage", ("weather_order", "flow_order", "missing_position", "static", "area"))
def test_full_input_identity_rejects_equal_statistics_and_static_changes(tmp_path, monkeypatch, damage):
    days = tuple(date(1981, 1, 1) + timedelta(days=i) for i in range(4))
    weather = np.asarray([[1., 2., 3., 4., 5.], [6., 2., 3., 4., 5.],
                          [2., 2., 3., 4., 5.], [5., 2., 3., 4., 5.]], dtype=np.float32)
    flow = np.asarray([1., 3., np.nan, 2.])

    def gate():
        return {"weather": canonical_series(BASINS[0], "fit", days, ("P", "T1", "T2", "S", "V"), weather, 9),
                "flow": canonical_series(BASINS[0], "fit", days, ("Q",), flow, 17),
                "static": [1., 2.], "area": 100.}

    expected = gate()
    if damage == "weather_order":
        weather[[0, 1]] = weather[[1, 0]]
    elif damage == "flow_order":
        flow[[0, 1]] = flow[[1, 0]]
    elif damage == "missing_position":
        flow[[2, 3]] = flow[[3, 2]]
    fresh = gate()
    if damage == "static":
        fresh["static"][0] = 2.
    if damage == "area":
        fresh["area"] = 101.
    monkeypatch.setattr(identity, "make_input_identity", lambda *_: fresh)
    with pytest.raises(PermissionError, match="identity changed"):
        identity.require_input_identity(_contract(tmp_path), BASINS[0], expected)
    with pytest.raises(PermissionError):
        identity.require_recovery_identity(_contract(tmp_path), BASINS[0],
              {"complete": True, "basin": BASINS[0], "contract_sha256": "contract",
               "input_identity_sha256": identity.canonical_digest(expected)}, identity.canonical_digest(fresh))


def _causal_trajectory(change_at=None):
    torch.manual_seed(1001)
    net = RainCorrector(3.)
    with torch.no_grad():
        net.decoder[-1].weight.fill_(.02)
        net.decoder[-1].bias.fill_(.03)
    phase = Phase("synthetic", date(2000, 1, 1), date(2000, 1, 30))
    weather = np.tile([1., 2., 3., 4., 5.], (30, 1)).astype(np.float32)
    observations = np.linspace(.1, 1.5, 30)
    scaling = Scaling.fit(weather, observations, phase)
    warmup_dates = tuple(phase.start - timedelta(days=100 - index) for index in range(100))
    warmup = torch.tensor(np.tile([1., 2., 3., 4., 5.], (100, 1)), dtype=torch.float32)
    replay = Replay(ToyHydro(), net, scaling, warmup_dates, warmup)
    predictions = []
    with torch.no_grad():
        for index, day in enumerate(phase.dates):
            prediction = replay.predict(day, weather[index])
            predictions.append(prediction.q_mm_day)
            value = observations[index] + (10. if change_at == index else 0.)
            replay.observe(day, value)
    return predictions


def test_nonzero_network_future_observation_changes_only_later_predictions():
    reference, perturbed = _causal_trajectory(), _causal_trajectory(change_at=15)
    assert reference[:16] == perturbed[:16]
    assert any(a != b for a, b in zip(reference[16:], perturbed[16:]))


def test_basin_replay_after_another_basin_matches_independent_process():
    module_path = str(Path(__file__).resolve().parents[2])
    code = """
import json,sys
sys.path.insert(0, sys.argv[1])
from datetime import date,timedelta
import numpy as np,torch
from precip_input_assimilation.dynamic_filter.protocol import Phase,Scaling
from precip_input_assimilation.dynamic_filter.rollout import Replay,ToyHydro
from precip_input_assimilation.dynamic_filter.network import RainCorrector
def run(seed,rain):
 torch.manual_seed(seed)
 phase=Phase('synthetic',date(2001,1,1),date(2001,1,10))
 weather=np.tile([rain,2.,3.,4.,5.],(10,1)).astype(np.float32)
 values=np.arange(1.,11.)
 scale=Scaling.fit(weather,values,phase)
 net=RainCorrector(scale.cap)
 with torch.no_grad(): net.decoder[-1].weight.fill_(.03)
 warm=tuple(phase.start-timedelta(days=100-i) for i in range(100))
 replay=Replay(ToyHydro(),net,scale,warm,torch.tensor(np.tile(weather[0],(100,1))))
 result=[]
 with torch.no_grad():
  for day,row,value in zip(phase.dates,weather,values):
   prediction=replay.predict(day,row);result.append(prediction.q_mm_day);replay.observe(day,value)
 return result
if sys.argv[2]=='after':run(1002,2.)
print(json.dumps(run(1001,1.)))
"""
    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")
    results = [json.loads(subprocess.run([sys.executable, "-B", "-c", code, module_path, mode],
                           capture_output=True, text=True, check=True, env=environment, timeout=60).stdout)
               for mode in ("independent", "after")]
    tolerance = 1e-5 * (1 + max(map(abs, results[0])))
    assert max(abs(a - b) for a, b in zip(*results, strict=True)) <= tolerance
