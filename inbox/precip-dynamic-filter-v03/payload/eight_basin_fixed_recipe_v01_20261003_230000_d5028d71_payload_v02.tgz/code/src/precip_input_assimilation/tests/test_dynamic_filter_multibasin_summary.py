"""Pure synthetic tests of fixed population, seed identity and unrounded gates."""

import copy
import csv
from datetime import date, timedelta
import math
from pathlib import Path
from statistics import median
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from precip_input_assimilation.dynamic_filter_multibasin.audit import audit_rain_ledger, basin_gate, stable_nse, summarize_eight
from precip_input_assimilation.dynamic_filter_multibasin.contract import BASINS


STRATA = dict(zip(BASINS, ("humid_small", "humid_large", "dry_small", "dry_large") * 2, strict=True))


def station(rain=.8, flow=.7, base=.4):
    methods = {"base": {"full": base, "annual": {str(year): base for year in range(1986, 1990)}},
               "persistence": {"full": .5, "annual": {str(year): .5 for year in range(1986, 1990)}}}
    for kind, value in (("rain", rain), ("flow", flow), ("historical", .6)):
        for seed in (1001, 1002, 1003):
            methods[f"{kind}_s{seed}"] = {"full": value, "annual": {str(year): value for year in range(1986, 1990)}}
    return {"methods": methods, "coverage": {str(year): 1. for year in range(1986, 1990)}}


def test_difference_of_group_medians_is_not_median_paired_differences():
    rain, flow = [.2, .8, .9], [.1, .7, .0]
    scores = station()
    for seed, a, b in zip((1001, 1002, 1003), rain, flow, strict=True):
        scores["methods"][f"rain_s{seed}"]["full"] = a
        scores["methods"][f"flow_s{seed}"]["full"] = b
    assert basin_gate(scores)["D"] == pytest.approx(.7)
    assert median([a - b for a, b in zip(rain, flow)]) == pytest.approx(.1)


def test_complete_positive_eight_and_256_descriptive_combinations():
    result = summarize_eight({basin: station() for basin in BASINS}, BASINS, STRATA)
    assert result["continue_regional_research"]
    assert result["positive_D_count"] == 8
    assert result["stratified_descriptive_range"]["combinations"] == 256


def test_missing_station_cannot_change_denominator_to_seven():
    result = summarize_eight({basin: station() for basin in BASINS[:-1]}, BASINS, STRATA)
    assert not result["technical_complete"]
    assert not result["continue_regional_research"]


@pytest.mark.parametrize("damage", ("missing_seed", "duplicate_seed", "low_coverage", "nonfinite", "missing_year"))
def test_failed_seed_or_year_is_a_technical_failure(damage):
    scores = station()
    if damage == "missing_seed":
        del scores["methods"]["rain_s1003"]
    elif damage == "duplicate_seed":
        scores["methods"]["rain_s1001_copy"] = scores["methods"].pop("rain_s1003")
    elif damage == "low_coverage":
        scores["coverage"]["1988"] = .8999
    elif damage == "nonfinite":
        scores["methods"]["flow_s1002"]["full"] = float("nan")
    else:
        del scores["methods"]["rain_s1001"]["annual"]["1988"]
    assert not basin_gate(scores)["technical_complete"]


def test_full_precision_positive_gain_threshold():
    exact = station(rain=.005, flow=0., base=0.)
    exact["methods"]["persistence"]["full"] = -.1
    below = copy.deepcopy(exact)
    for seed in (1001, 1002, 1003):
        below["methods"][f"rain_s{seed}"]["full"] = math.nextafter(.005, 0.)
    assert basin_gate(exact)["tests"]["median_gain_at_least_0.005"]
    assert not basin_gate(below)["tests"]["median_gain_at_least_0.005"]


def test_full_precision_median_difference_and_regression_boundaries():
    exact = {basin: station(rain=.005, flow=0., base=-.1) for basin in BASINS}
    for scores in exact.values():
        scores["methods"]["persistence"]["full"] = -.2
    assert summarize_eight(exact, BASINS, STRATA)["tests"]["median_D_at_least_0.005"]
    below = copy.deepcopy(exact)
    for scores in below.values():
        for seed in (1001, 1002, 1003):
            scores["methods"][f"rain_s{seed}"]["full"] = math.nextafter(.005, 0.)
    assert not summarize_eight(below, BASINS, STRATA)["tests"]["median_D_at_least_0.005"]
    for seed in (1001, 1002, 1003):
        exact[BASINS[0]]["methods"][f"rain_s{seed}"]["full"] = -.05
    assert summarize_eight(exact, BASINS, STRATA)["tests"]["no_D_below_minus_0.05"]
    for seed in (1001, 1002, 1003):
        exact[BASINS[0]]["methods"][f"rain_s{seed}"]["full"] = math.nextafter(-.05, -math.inf)
    assert not summarize_eight(exact, BASINS, STRATA)["tests"]["no_D_below_minus_0.05"]


def test_a_stratum_with_two_nonpositive_stations_blocks_continuation():
    scores = {basin: station() for basin in BASINS}
    for basin in (BASINS[0], BASINS[4]):
        scores[basin] = station(rain=.68, flow=.7)
    result = summarize_eight(scores, BASINS, STRATA)
    assert result["positive_D_count"] == 6
    assert not result["tests"]["each_stratum_has_positive_D"]
    assert not result["continue_regional_research"]


def test_independent_efficiency_keeps_common_calendar_and_nonfinite_failure():
    assert stable_nse([1., 2., float("nan"), 3.], [1., 2., -100., 3.]) == 1.
    with pytest.raises(RuntimeError):
        stable_nse([1., 2., 3.], [1., float("nan"), 3.])


def _ledger(tmp_path, damage=None):
    dates = tuple(date(2000, 1, 1) + timedelta(days=index) for index in range(103))
    path = tmp_path / "rain.csv"
    inherited = {}
    with path.open("x", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["rain_date", "as_of_date", "raw_mm", "proposal_mm", "applied_mm", "cap_mm", "missing"])
        for index in range(100, 103):
            missing = index == 101
            for rain_day in dates[index - 99:index + 1]:
                proposal = inherited.get(rain_day, 0.) if missing else .2
                applied = proposal
                raw = 1.
                if damage == "missing_changed" and missing and rain_day == dates[index - 99]:
                    applied = .4
                if damage == "raw_changed" and index == 100 and rain_day == dates[index - 99]:
                    raw = 2.
                if damage == "outside_window" and index == 100 and rain_day == dates[index - 99]:
                    rain_day = dates[0]
                cap = 100. if damage == "cap_changed" else 1.
                if damage == "cap_changed":
                    proposal = inherited.get(rain_day, 0.) if missing else 50.
                    applied = proposal
                reported_missing = False if damage == "false_missing_calendar" and index == 101 else missing
                inherited[rain_day] = applied
                writer.writerow([rain_day, dates[index], raw, proposal, applied, cap, int(reported_missing)])
    return path, dates


def test_rain_versions_reconstruct_unique_final_and_online_ledgers(tmp_path):
    path, dates = _ledger(tmp_path)
    result = audit_rain_ledger(path, dates, [1.] * len(dates), expected_updates=3, expected_cap=1.,
                              missing_by_date={dates[index]: index == 101 for index in range(100, 103)})
    assert result["rows"] == 300
    assert result["updates"] == 3
    assert result["final_unique_date_absolute_mm"] == pytest.approx(20.4)


@pytest.mark.parametrize("damage", ("missing_changed", "raw_changed", "outside_window",
                                    "cap_changed", "false_missing_calendar"))
def test_rain_ledger_rejects_changed_missing_update_raw_input_or_window(tmp_path, damage):
    path, dates = _ledger(tmp_path, damage)
    with pytest.raises(RuntimeError):
        audit_rain_ledger(path, dates, [1.] * len(dates), expected_updates=3, expected_cap=1.,
                          missing_by_date={dates[index]: index == 101 for index in range(100, 103)})
