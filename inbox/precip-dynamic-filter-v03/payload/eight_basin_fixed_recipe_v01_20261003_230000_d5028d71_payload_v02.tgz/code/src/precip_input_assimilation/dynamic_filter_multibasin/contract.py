"""Immutable recipe, metadata-only roster reconstruction and issued read capabilities.

Capabilities are registered by object identity: constructing a lookalike, changing a
phase string, or supplying a caller-created ``verified`` flag grants no access.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass, field, replace
from datetime import date, timedelta
import hashlib
import json
from pathlib import Path
from types import MappingProxyType
from typing import Mapping


BASINS = ("01487000", "12040500", "09312600", "08198500", "03078000",
          "05362000", "08267500", "07145700")
SEEDS = (1001, 1002, 1003)
PENALTIES = {"rain": .0001, "flow": .001, "historical": .0001}
ROSTER_SHA256 = "e7d43804b20f6c6eafcaf152ada68f11a68a04b42e0426f20ca2650b6c5a2ff6"
DATES = {"warmup": (date(1980, 1, 1), date(1980, 9, 30)),
         "fit": (date(1980, 10, 1), date(1984, 9, 30)),
         "select": (date(1984, 10, 1), date(1985, 9, 30)),
         "score": (date(1985, 10, 1), date(1989, 9, 30)),
         "probe": (date(1980, 10, 1), date(1980, 12, 3))}
PINNED = {"model_epoch030.pt": "1c755b0d6ce977db38a8332b50160f2a62a732cb7835be8814d7c23f12a70e00",
          "config.yml": "c5487945a42b04662a7ff9fd744dd78c1993d34bfadf31f6457a620cc74dfbfd",
          "train_data/train_data_scaler.yml": "d2a6ce291e137bcf30dbb39f140692882769760f59f71a29d674b02eafde14db"}


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_json(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def object_sha256(value) -> str:
    return hashlib.sha256((canonical_json(value) + "\n").encode("utf-8")).hexdigest()


def _immutable(value):
    if isinstance(value, dict):
        return MappingProxyType({key: _immutable(item) for key, item in value.items()})
    if isinstance(value, list):
        return tuple(_immutable(item) for item in value)
    return value


def guarded_path(path: Path, root: Path) -> Path:
    """Validate lexical and resolved paths before the caller may open a file."""
    path, root = Path(path).absolute(), Path(root).absolute()
    for candidate in (path, root, path.resolve(), root.resolve()):
        if any(part.casefold() == ".worktrees" for part in candidate.parts):
            raise PermissionError("Worktree inputs are forbidden")
    try:
        path.relative_to(root)
        path.resolve().relative_to(root.resolve())
    except ValueError as exc:
        raise PermissionError("Input path is outside its registered root") from exc
    return path.resolve()


@dataclass(frozen=True, init=False)
class ReadPermit:
    contract_sha256: str
    basin: str
    phase: str
    start: date
    end: date
    selection_lock: Path | None
    selection_lock_sha256: str | None
    _deployment: tuple = field(repr=False)


# Strong references prevent id reuse. These capabilities are process-local and
# deliberately cannot be recovered by unpickling or accepted from a JSON file.
_ISSUED: dict[int, tuple] = {}


@dataclass(frozen=True)
class Contract:
    path: Path
    sha256: str
    repo: Path
    data_root: Path
    model_root: Path
    roster_lock: Path | None
    recipe: Mapping = field(repr=False)

    @classmethod
    def load(cls, path: Path) -> "Contract":
        path = Path(path).resolve()
        # Only this explicit contract is read; no daily inputs are touched.
        raw = path.read_bytes()
        recipe = json.loads(raw)
        if recipe.get("family") != "eight_basin_fixed_recipe_v01":
            raise PermissionError("Unknown experiment family")
        if tuple(recipe.get("basins", ())) != BASINS or tuple(recipe.get("seeds", ())) != SEEDS:
            raise PermissionError("Fixed roster or initialization recipe changed")
        if recipe.get("penalties") != PENALTIES or recipe.get("max_epochs") != 60:
            raise PermissionError("Fixed fitting recipe changed")
        expected_dates = {key: [start.isoformat(), end.isoformat()] for key, (start, end) in DATES.items()}
        if recipe.get("phases") != expected_dates or recipe.get("model_sha256") != PINNED:
            raise PermissionError("Frozen dates or runoff artifact identity changed")
        if recipe.get("budget_total_seconds") != 259200 or recipe.get("budget_used_seconds") != 24378:
            raise PermissionError("Cumulative budget snapshot changed")
        # Never accept an arbitrary editable numerical recipe under the same family.
        constants = {"learning_rate": .001, "patience": 10, "window": 100,
                     "segment": 32, "violation_penalty": .01,
                     "minimum_coverage": .9, "wet_threshold_mm": .1, "rain_cap_quantile": .99,
                     "probe_max_seconds": 1800, "exit_reserve_seconds": 300,
                     "required_checkpoints": 72, "required_prediction_trajectories": 88,
                     "required_rain_ledgers": 48, "roster_sha256": ROSTER_SHA256,
                     "selection_salt": "precip-dynamic-eight-basin-20261003-v1:"}
        if any(recipe.get(key) != value for key, value in constants.items()):
            raise PermissionError("Frozen numerical recipe changed")
        repo = path.parents[3]
        return cls(path, hashlib.sha256(raw).hexdigest(), repo,
                   repo / recipe["data_root"], repo / recipe["model_root"], None,
                   _immutable(recipe))

    @property
    def basins(self):
        return BASINS

    @property
    def seeds(self):
        return SEEDS

    @property
    def penalties(self):
        return MappingProxyType(PENALTIES)

    @property
    def strata(self):
        return dict(zip(BASINS, ("humid_small", "humid_large", "dry_small", "dry_large") * 2, strict=True))

    @property
    def budget_total_seconds(self):
        return int(self.recipe["budget_total_seconds"])

    @property
    def budget_used_seconds(self):
        return int(self.recipe["budget_used_seconds"])

    @property
    def roster_path(self):
        return guarded_path(self.repo / self.recipe["roster_file"], self.repo)

    @property
    def deployment(self):
        return (str(self.repo.resolve()), str(self.data_root.resolve()), str(self.model_root.resolve()),
                str(self.roster_lock.resolve()) if self.roster_lock else None)

    def bind(self, *, repo=None, data_root=None, model_root=None, roster_lock=None):
        return replace(self, repo=Path(repo or self.repo).resolve(),
                       data_root=Path(data_root or self.data_root).resolve(),
                       model_root=Path(model_root or self.model_root).resolve(),
                       roster_lock=Path(roster_lock).resolve() if roster_lock else self.roster_lock)

    def metadata_path(self, relative: str) -> Path:
        if relative.startswith("data/camels_us/"):
            return guarded_path(self.data_root / relative[len("data/camels_us/"):], self.data_root)
        return guarded_path(self.repo / relative, self.repo)

    def verify_contract(self):
        if file_sha256(self.path) != self.sha256:
            raise PermissionError("Experiment contract changed after loading")

    def reconstruct_roster(self) -> dict:
        self.verify_contract()
        if file_sha256(self.roster_path) != self.recipe["roster_sha256"]:
            raise PermissionError("Frozen roster evidence changed")
        evidence = json.loads(self.roster_path.read_text(encoding="utf-8"))
        for relative, expected in evidence["input_sha256"].items():
            if file_sha256(self.metadata_path(relative)) != expected:
                raise PermissionError(f"Roster metadata changed: {relative}")

        def identifiers(relative):
            values = self.metadata_path(relative).read_text(encoding="utf-8").splitlines()
            values = [v.strip() for v in values if v.strip()]
            if len(values) != len(set(values)) or any(len(v) != 8 or not v.isdigit() for v in values):
                raise PermissionError("Malformed basin identifier list")
            return values

        frame = identifiers("src/fair_benchmark/frozen/track0_forcing_only_basins.txt")
        excluded = {"01022500"}
        for relative in self.recipe["exclusion_files"]:
            excluded.update(identifiers(relative))
        tables = {}
        for filename in ("camels_topo.txt", "camels_clim.txt", "camels_name.txt"):
            source = self.metadata_path("data/camels_us/camels_attributes_v2.0/" + filename)
            with source.open(encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle, delimiter=";"))
            table = {row["gauge_id"]: row for row in rows}
            if len(table) != len(rows):
                raise PermissionError("Duplicate static metadata identifier")
            tables[filename] = table
        candidates, pools = [], {key: [] for key in self.recipe["strata"]}
        for basin in frame:
            if basin in excluded:
                continue
            topo, clim, name = (tables[filename][basin]
                                for filename in ("camels_topo.txt", "camels_clim.txt", "camels_name.txt"))
            area, aridity = float(topo["area_gages2"]), float(clim["aridity"])
            group = ("dry" if aridity > 1 else "humid") + ("_small" if area < 300 else "_large")
            item = {"basin": basin, "group": group, "area_km2": area, "aridity": aridity,
                    "huc02": str(name["huc_02"]).zfill(2), "name": name["gauge_name"],
                    "latitude": float(topo["gauge_lat"]), "longitude": float(topo["gauge_lon"]),
                    "rank": hashlib.sha256((self.recipe["selection_salt"] + basin).encode()).hexdigest()}
            candidates.append(item)
            pools[group].append(item)
        for group in pools:
            pools[group].sort(key=lambda row: (row["rank"], row["basin"]))

        def choose(index, selected):
            if index == len(self.recipe["stratum_order"]):
                return selected
            used = {item["huc02"] for item in selected}
            for item in pools[self.recipe["stratum_order"][index]]:
                if item["huc02"] not in used:
                    answer = choose(index + 1, selected + [item])
                    if answer is not None:
                        return answer
            return None

        actual = {"frame_count": len(frame), "excluded_union_count": len(excluded),
                  "excluded_in_frame": len(set(frame).intersection(excluded)),
                  "candidate_count": len(candidates), "pool_counts": {g: len(p) for g, p in pools.items()},
                  "selection": choose(0, []), "input_sha256": evidence["input_sha256"]}
        if any(actual[key] != evidence[key] for key in actual) or tuple(
                row["basin"] for row in actual["selection"]) != BASINS:
            raise PermissionError("Static-only reconstruction does not reproduce the fixed eight basins")
        return actual

    def lock_roster(self, path: Path) -> "Contract":
        content = self.reconstruct_roster()
        content.update(contract_sha256=self.sha256, roster_sha256=self.recipe["roster_sha256"],
                       roster_content_sha256=object_sha256(content), status="locked_metadata_only")
        with Path(path).open("x", encoding="utf-8", newline="\n") as handle:
            json.dump(content, handle, indent=2, ensure_ascii=False, allow_nan=False)
            handle.write("\n")
        return self.bind(roster_lock=path)

    def verify_roster_lock(self):
        if self.roster_lock is None:
            raise PermissionError("Metadata roster has not been locked")
        actual = self.reconstruct_roster()
        lock = json.loads(self.roster_lock.read_text(encoding="utf-8"))
        if lock.get("contract_sha256") != self.sha256 or lock.get("roster_sha256") != self.recipe["roster_sha256"]:
            raise PermissionError("Roster lock belongs to a different contract")
        if lock.get("roster_content_sha256") != object_sha256(actual) or any(
                lock.get(key) != value for key, value in actual.items()):
            raise PermissionError("Roster lock differs from its reconstructed metadata")

    def require_access(self, basin, phase, start, end, selection_lock=None):
        if basin not in BASINS or phase not in DATES:
            raise PermissionError("Unknown basin or unapproved phase")
        lower, upper = DATES[phase]
        if not isinstance(start, date) or not isinstance(end, date) or not lower <= start <= end <= upper:
            raise PermissionError("Requested dates are outside the permitted phase")
        self.verify_roster_lock()
        if phase == "score":
            if selection_lock is None:
                raise PermissionError("Scoring requires all 72 checkpoints and input identities")
            from .identity import validate_global_lock
            validate_global_lock(self, Path(selection_lock), revalidate_inputs=True)

    def authorize(self, basin, phase, start, end, selection_lock=None):
        self.require_access(basin, phase, start, end, selection_lock)
        lock = Path(selection_lock).resolve() if selection_lock else None
        permit = object.__new__(ReadPermit)
        for key, value in {"contract_sha256": self.sha256, "basin": basin, "phase": phase,
                           "start": start, "end": end, "selection_lock": lock,
                           "selection_lock_sha256": file_sha256(lock) if lock else None,
                           "_deployment": self.deployment}.items():
            object.__setattr__(permit, key, value)
        _ISSUED[id(permit)] = (permit, self.sha256, basin, phase, start, end, self.deployment,
                               permit.selection_lock, permit.selection_lock_sha256)
        return permit

    def validate_permit(self, permit, basin, phase, start, end, *, kind):
        record = _ISSUED.get(id(permit))
        if type(permit) is not ReadPermit or record is None or record[0] is not permit:
            raise PermissionError("Missing, forged or deserialized read capability")
        expected = (self.sha256, basin, phase, start, end, self.deployment)
        actual = (permit.contract_sha256, permit.basin, permit.phase, permit.start, permit.end, permit._deployment)
        if expected != actual or record[1:7] != actual or record[7:] != (
                permit.selection_lock, permit.selection_lock_sha256) or (kind == "flow" and phase == "warmup"):
            raise PermissionError("Read capability does not match this request")
        self.require_access(basin, phase, start, end, permit.selection_lock)
        if permit.selection_lock is not None and file_sha256(permit.selection_lock) != permit.selection_lock_sha256:
            raise PermissionError("Selection lock changed since permission was issued")
