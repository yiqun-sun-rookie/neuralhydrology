"""Fixed-recipe fits, complete global selection, causal scoring and hard deadlines."""

from datetime import timedelta
import math
from pathlib import Path
import os
import shutil
import sys
import subprocess
import threading
import time

import numpy as np
import torch

from ..dynamic_filter.network import FlowCorrector, RainCorrector
from ..dynamic_filter.protocol import (FIT_START, FIT_END, SELECT_START, SELECT_END, SCORE_START,
                                       SCORE_END, Phase, Scaling)
from ..dynamic_filter.report import CsvSink, nse, score_predictions
from ..dynamic_filter.training import replay_phase, train_epoch
from .data import load_inputs
from .hydro import BasinHydro
from .identity import (BasinSelection, METHODS, bound_path, canonical_digest, make_input_identity,
                       multibasin_source_snapshot, read_json, require_input_identity,
                       require_checkpoint_metadata, require_recovery_identity, require_sources, sha256, validate_global_lock,
                       validate_selection, write_json)


EXIT_RESERVE = 300.


def replay_factory(*args, **kwargs):
    # Delay model/config dependency imports until an actual replay is requested.
    from ..dynamic_filter.real_data import replay_factory as frozen_factory
    return frozen_factory(*args, **kwargs)


def configure_numerics():
    torch.set_num_threads(2)
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def numerical_runtime(repo, device="cpu"):
    import importlib
    configure_numerics()
    paths = {}
    for name in ("neuralhydrology", "precip_input_assimilation.dynamic_filter_multibasin.identity"):
        module = importlib.import_module(name)
        location = Path(module.__file__).resolve()
        if not location.is_relative_to(Path(repo).resolve()):
            raise PermissionError(f"Module was imported outside its registered private code root: {name}")
        paths[name] = str(location)
    from ..dynamic_filter.report import require_no_forbidden_imports
    require_no_forbidden_imports()
    return {"python_executable": sys.executable, "python_version": sys.version, "numpy_version": np.__version__,
            "torch_version": torch.__version__, "cuda_version": torch.version.cuda,
            "cudnn_version": torch.backends.cudnn.version(), "torch_threads": torch.get_num_threads(),
            "cudnn_tf32": torch.backends.cudnn.allow_tf32, "matmul_tf32": torch.backends.cuda.matmul.allow_tf32,
            "cudnn_deterministic": torch.backends.cudnn.deterministic,
            "cudnn_benchmark": torch.backends.cudnn.benchmark, "device": device,
            "gpu_name": torch.cuda.get_device_name(device) if device.startswith("cuda") else None,
            "gpu_capability": list(torch.cuda.get_device_capability(device)) if device.startswith("cuda") else None,
            "imports": paths, "environment": {key: os.environ.get(key) for key in (
                "OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_THREADING_LAYER",
                "MKL_SERVICE_FORCE_INTEL")}}


def synchronize(device):
    if str(device).startswith("cuda"):
        torch.cuda.synchronize(device)


def require_time(deadline, reserve=EXIT_RESERVE):
    if not math.isfinite(deadline) or time.monotonic() >= deadline - reserve:
        raise TimeoutError("The inherited cumulative-budget deadline has reached its exit reserve")


def check_budget_record(path, deadline):
    record = read_json(path)
    total = float(record["budget_total_seconds"])
    used = float(record["used_gpu_seconds"])
    reserved = float(record["unsettled_reserved_seconds"])
    remaining = total - used - reserved
    if (total != 259200 or used < 24378 or reserved < 0 or record["unsettled_jobs"] or
            remaining <= EXIT_RESERVE or remaining != float(record["remaining_gpu_seconds"])):
        raise PermissionError("Cumulative budget is inconsistent or has an unsettled job")
    started = record.get("job_started_monotonic")
    inherited = record.get("job_deadline_monotonic", record.get("deadline_monotonic"))
    if inherited is not None and float(inherited) != deadline:
        raise PermissionError("A stage attempted to reset its inherited deadline")
    if started is not None and deadline > float(started) + remaining + 1e-6:
        raise PermissionError("Deadline exceeds the cumulative remaining allocation")
    if deadline > time.monotonic() + remaining + 1e-6:
        raise PermissionError("Deadline exceeds the cumulative remaining allocation")
    require_time(deadline)
    return record


def network_for(kind, scaling, seed, device):
    from ..selfrule.model import configure_determinism
    configure_determinism(seed)
    net = FlowCorrector(scaling.flow_std) if kind == "flow" else RainCorrector(
        scaling.cap, historical=kind == "historical")
    if sum(parameter.numel() for parameter in net.parameters()) != 5633:
        raise RuntimeError("Correction-network parameter count changed")
    return net.to(device)


def baseline_cache(hydro, inputs, start, end, deadline, reserve=EXIT_RESERVE):
    require_time(deadline, reserve=reserve)
    dates = tuple(day for day in inputs.dates if start <= day <= end)
    indices = [inputs.dates.index(day) for day in dates]
    values = []
    # Bound each direct forward by the same parent deadline; batch size remains one.
    for index in indices:
        require_time(deadline, reserve=reserve)
        values.extend(hydro.direct(inputs.weather, np.asarray([index]), batch=1))
    return dict(zip(dates, values, strict=True))


def persistence_coefficient(phase, values, cache):
    errors = values - np.asarray([cache[day] for day in phase.dates])
    valid = np.isfinite(errors[:-1]) & np.isfinite(errors[1:])
    previous, current = errors[:-1][valid], errors[1:][valid]
    denominator = float(np.dot(previous, previous))
    return float(np.clip(np.dot(previous, current) / denominator, 0., 1.)) if denominator > 0 else 0.


def preflight(contract, root):
    root = Path(root)
    sources = multibasin_source_snapshot(contract.repo)
    records = []
    for basin in contract.basins:
        directory = root / "basins" / basin
        directory.mkdir(parents=True, exist_ok=False)
        try:
            inputs = load_inputs(contract, basin, end=SELECT_END)
            gate = make_input_identity(contract, basin, inputs=inputs, sources=sources)
        except Exception as error:
            gate = {"basin": basin, "pass": False, "error_type": type(error).__name__, "error": str(error),
                    "sources": sources, "contract_sha256": contract.sha256, "score_observations_read": False}
        write_json(directory / "input_gate.json", gate)
        records.append({"basin": basin, "input_gate": str((directory / "input_gate.json").relative_to(root)),
                        "input_gate_sha256": sha256(directory / "input_gate.json"),
                        "input_identity_sha256": canonical_digest(gate), "pass": gate["pass"]})
    record = {"success": all(item["pass"] for item in records), "contract_sha256": contract.sha256,
              "basins": list(contract.basins),
              "sources": sources, "inputs": records, "score_observations_read": False}
    write_json(root / "preflight_gate.json", record)
    if not record["success"]:
        raise RuntimeError("The fixed eight-basin input gate failed; all eight outcomes were preserved")
    return record


def _train_fixed(network, factory, fit, select, inputs, penalty, directory, seed, deadline, device,
                 input_identity, kind, basin, contract_identity):
    optimizer = torch.optim.Adam(network.parameters(), lr=.001)
    best, best_epoch, epochs = -float("inf"), None, 0
    for epoch in range(1, 61):
        require_time(deadline)
        synchronize(device)
        began = time.perf_counter()
        network.train()
        segments = train_epoch(factory(network), fit, inputs.weather_for(fit),
                               inputs.observations_for(fit), optimizer, penalty)
        if not any(item["flow_supervised"] and item["nonzero_grad_parameters"] > 0 for item in segments):
            raise RuntimeError("A complete epoch has no nonzero legal supervised gradient")
        if any(item["loss"] is not None and not math.isfinite(item["loss"]) for item in segments):
            raise RuntimeError("Nonfinite training loss")
        network.eval()
        replay = factory(network)
        replay_phase(replay, fit, inputs.weather_for(fit), inputs.observations_for(fit))
        predicted = replay_phase(replay, select, inputs.weather_for(select), inputs.observations_for(select))
        score = nse(inputs.observations_for(select), predicted)
        if score is None or not math.isfinite(score):
            raise RuntimeError("Selection efficiency is undefined")
        better = score > best  # Ties retain the earliest epoch.
        if better:
            best, best_epoch = score, epoch
            torch.save({"state_dict": network.state_dict(), "seed": seed, "penalty": penalty,
                        "epoch": epoch, "validation_nse": score,
                        "input_identity_sha256": input_identity, "kind": kind, "basin": basin,
                        "contract_sha256": contract_identity}, directory / "selected.pt")
        synchronize(device)
        item = {"epoch": epoch, "validation_nse": score, "selected": better,
                "segments": segments, "seconds": time.perf_counter() - began}
        write_json(directory / f"epoch_{epoch:03d}.json", item)
        epochs = epoch
        print(f"epoch={epoch} select_nse={score:.8g} seconds={item['seconds']:.1f}", flush=True)
        if epoch - best_epoch >= 10:
            break
    return {"seed": seed, "penalty": penalty, "best_epoch": best_epoch,
            "validation_nse": best, "epochs": epochs}


def _import_completed_fit(contract, basin, kind, seed, previous_root, destination, input_identity):
    source = Path(previous_root) / "basins" / basin / "fits" / kind / f"seed_{seed}"
    summary_path = source / "fit_summary.json"
    if not summary_path.exists():
        return None  # Interrupted fits are restarted from their prescribed initialization.
    record = read_json(summary_path)
    require_recovery_identity(contract, basin, record, input_identity)
    if record["kind"] != kind or record["seed"] != seed or record["penalty"] != contract.penalties[kind]:
        raise PermissionError("Recovery fit is not the prescribed method/seed/coefficient")
    checkpoint = bound_path(previous_root, record["checkpoint"])
    if sha256(checkpoint) != record["checkpoint_sha256"]:
        raise PermissionError("Recovery checkpoint identity changed")
    require_checkpoint_metadata(checkpoint, record)
    source_gate = read_json(Path(previous_root) / "basins" / basin / "input_gate.json")
    if canonical_digest(source_gate) != input_identity:
        raise PermissionError("Recovery prior input gate changed")
    require_input_identity(contract, basin, source_gate)
    shutil.copytree(source, destination, dirs_exist_ok=False)
    return record


def train_basin(contract, basin, root, deadline, device="cuda:0", expected_gate=None, resume_root=None):
    require_time(deadline)
    directory = Path(root) / "basins" / basin
    directory.mkdir(parents=True, exist_ok=False)
    inputs = load_inputs(contract, basin, end=SELECT_END)
    gate = make_input_identity(contract, basin, inputs=inputs)
    if expected_gate is not None and canonical_digest(gate) != canonical_digest(expected_gate):
        raise PermissionError("Preflight inputs changed before training")
    write_json(directory / "input_gate.json", gate)
    input_identity = canonical_digest(gate)
    fit, select = Phase("fit", FIT_START, FIT_END), Phase("select", SELECT_START, SELECT_END)
    scaling = Scaling.fit(inputs.weather_for(fit), inputs.observations_for(fit), fit)
    hydro = BasinHydro(contract, basin, device=device)
    frozen_before = hydro.state_hash()
    cache = baseline_cache(hydro, inputs, FIT_START, SELECT_END, deadline)
    beta = persistence_coefficient(fit, inputs.observations_for(fit), cache)
    records = []
    for kind in METHODS:
        for seed in contract.seeds:
            require_time(deadline)
            # Re-read the real allowed sequences, static inputs, area and sources for every fit.
            require_input_identity(contract, basin, gate)
            fit_dir = directory / "fits" / kind / f"seed_{seed}"
            recovered = None if resume_root is None else _import_completed_fit(
                contract, basin, kind, seed, resume_root, fit_dir, input_identity)
            if recovered is None:
                fit_dir.mkdir(parents=True, exist_ok=False)
                network = network_for(kind, scaling, seed, device)
                factory = replay_factory(hydro, inputs, scaling, kind, base_cache=cache,
                                         deadline=deadline - EXIT_RESERVE)
                result = _train_fixed(network, factory, fit, select, inputs, contract.penalties[kind],
                                      fit_dir, seed, deadline, device, input_identity, kind, basin, contract.sha256)
            else:
                result = {key: recovered[key] for key in
                          ("seed", "penalty", "best_epoch", "validation_nse", "epochs")}
                # Imported completed summaries are retained as provenance, never overwritten.
                (fit_dir / "fit_summary.json").rename(fit_dir / "recovered_fit_summary.json")
                result["recovered_from"] = str(Path(resume_root).resolve())
            result.update(kind=kind, basin=basin, complete=True, contract_sha256=contract.sha256,
                          input_identity_sha256=input_identity,
                          checkpoint=(fit_dir / "selected.pt").relative_to(root).as_posix(),
                          checkpoint_sha256=sha256(fit_dir / "selected.pt"),
                          model_tensor_sha256=frozen_before)
            if hydro.state_hash() != frozen_before:
                raise RuntimeError("Frozen hydrologic tensors changed during training")
            hydro.require_unchanged()
            require_input_identity(contract, basin, gate)
            write_json(fit_dir / "fit_summary.json", result)
            locked = dict(result, fit_summary=(fit_dir / "fit_summary.json").relative_to(root).as_posix(),
                          fit_summary_identity=canonical_digest(result))
            records.append(locked)
    selection = BasinSelection(basin, tuple(records), scaling.as_dict(), beta,
                               (directory / "input_gate.json").relative_to(root).as_posix(),
                               sha256(directory / "input_gate.json"), input_identity, gate["sources"],
                               gate["model_identity"], frozen_before, contract.sha256,
                               str(Path(root).resolve()))
    validate_selection(contract, selection)
    write_json(directory / "selection_locked.json", selection.as_dict())
    return selection


def lock_all(contract, selections, root):
    if tuple(item.basin for item in selections) != tuple(contract.basins) or len(selections) != 8:
        raise PermissionError("Global selection requires all eight prescribed basins in order")
    records = []
    for selection in selections:
        validate_selection(contract, selection)
        relative = f"basins/{selection.basin}/selection_locked.json"
        path = bound_path(selection.training_root, relative)
        records.append({"basin": selection.basin, "training_root": selection.training_root,
                        "selection_file": relative, "selection_sha256": sha256(path),
                        "selection_identity": canonical_digest(selection.as_dict())})
    path = Path(root) / "global_selection_locked.json"
    write_json(path, {"contract_sha256": contract.sha256, "basins": list(contract.basins),
                      "checkpoint_count": 72, "selections": records, "score_observations_read": False})
    validate_global_lock(contract, path)
    return path


def _score_identity(inputs, basin, lock_digest):
    weather = inputs.weather_blocks["score"]
    flow = inputs.flow_blocks["score"]
    return {"basin": basin, "global_selection_lock_sha256": lock_digest,
            "weather_canonical_sha256": weather.canonical_sha256,
            "flow_canonical_sha256": flow.canonical_sha256,
            "weather_raw_sha256": weather.raw_sha256, "flow_raw_sha256": flow.raw_sha256}


def score_all(contract, global_lock, root, deadline, device="cuda:0"):
    require_time(deadline)
    lock_digest = validate_global_lock(contract, global_lock)
    lock = read_json(global_lock)
    phases = (Phase("fit", FIT_START, FIT_END), Phase("select", SELECT_START, SELECT_END),
              Phase("score", SCORE_START, SCORE_END))
    all_scores = {}
    for item in lock["selections"]:
        basin = item["basin"]
        selection = read_json(bound_path(item["training_root"], item["selection_file"]))
        validate_selection(contract, selection)
        inputs = load_inputs(contract, basin, end=SCORE_END, selection_lock=Path(global_lock))
        score_identity = _score_identity(inputs, basin, lock_digest)
        directory = Path(root) / "basins" / basin
        directory.mkdir(parents=True, exist_ok=False)
        write_json(directory / "score_input_locked.json", score_identity)
        observations = inputs.observations_for(phases[-1])
        with (directory / "score_observations.csv").open("x", encoding="utf-8", newline="") as handle:
            import csv
            writer = csv.writer(handle)
            writer.writerow(["date", "q_mm_day"])
            for day, value in zip(phases[-1].dates, observations, strict=True):
                writer.writerow([day.isoformat(), "NA" if not np.isfinite(value) else format(float(value), ".17g")])
        scaling = Scaling.fit(inputs.weather_for(phases[0]), inputs.observations_for(phases[0]), phases[0])
        if scaling.as_dict() != selection["scaling"]:
            raise PermissionError("Fitting-only scaling changed since selection")
        hydro = BasinHydro(contract, basin, device=device)
        if hydro.state_hash() != selection["model_tensor_sha256"]:
            raise PermissionError("Frozen hydrologic tensors differ from selected fits")
        cache = baseline_cache(hydro, inputs, FIT_START, SCORE_END, deadline)
        # Cached meteorological base predictions do not expose observations to correction networks.
        predictions = {}
        candidates = [{"kind": "base"}, {"kind": "persistence"}] + selection["selected"]
        for candidate in candidates:
            require_time(deadline)
            require_sources(contract.repo, selection["sources"])
            fresh = load_inputs(contract, basin, end=SCORE_END, selection_lock=Path(global_lock))
            if _score_identity(fresh, basin, lock_digest) != score_identity:
                raise PermissionError("Scoring input identity changed between methods")
            kind = candidate["kind"]
            name = kind if "seed" not in candidate else f"{kind}_s{candidate['seed']}"
            target = directory / "scoring" / name
            target.mkdir(parents=True, exist_ok=False)
            network = None
            checkpoint_hash = "frozen_base" if kind == "base" else f"fit_beta={selection['beta']:.17g}"
            if "checkpoint" in candidate:
                checkpoint = bound_path(item["training_root"], candidate["checkpoint"])
                if sha256(checkpoint) != candidate["checkpoint_sha256"]:
                    raise PermissionError("Selected checkpoint changed after global locking")
                require_checkpoint_metadata(checkpoint, candidate)
                network = network_for(kind, scaling, candidate["seed"], device)
                payload = torch.load(checkpoint, map_location=device, weights_only=True)
                require_checkpoint_metadata(checkpoint, candidate, payload=payload)
                if payload["input_identity_sha256"] != selection["input_identity_sha256"]:
                    raise PermissionError("Checkpoint input binding differs from selected input")
                network.load_state_dict(payload["state_dict"])
                network.eval()
                checkpoint_hash = candidate["checkpoint_sha256"]
            sink = CsvSink(target, checkpoint_hash, write_rain=kind in ("rain", "historical"))
            replay = replay_factory(hydro, inputs, scaling, kind, sink=sink, beta=selection["beta"],
                                    base_cache=cache, deadline=deadline - EXIT_RESERVE)(network)
            try:
                for phase in phases:
                    trajectory = replay_phase(replay, phase, inputs.weather_for(phase), inputs.observations_for(phase))
                    if phase.name == "score":
                        predictions[name] = trajectory
            finally:
                sink.close()
            raw, applied = replay.raw[:, 0].detach().cpu().numpy(), replay.applied.detach().cpu().numpy()
            write_json(target / "diagnostics.json", dict(
                sink.diagnostics, final_daily_absolute_correction_mm=float(np.abs(applied).sum()),
                final_dry_added_mm=float(np.maximum(applied[raw < .1], 0).sum()),
                final_ledger_scope="final as-of date; includes warmup, fit, select and score",
                checkpoint_sha256=checkpoint_hash, score_input_identity=canonical_digest(score_identity)))
            if hydro.state_hash() != selection["model_tensor_sha256"]:
                raise RuntimeError("Frozen tensors changed during scoring")
            hydro.require_unchanged()
        scores = score_predictions(phases[-1].dates, observations, predictions)
        scores["basin"] = basin
        scores["global_lock_sha256"] = lock_digest
        scores["score_input_identity"] = canonical_digest(score_identity)
        write_json(directory / "summary.json", scores)
        all_scores[basin] = scores
    write_json(Path(root) / "scores.json", all_scores)
    from .audit import audit_run
    audit = audit_run(contract, root, global_lock=global_lock)
    write_json(Path(root) / "independent_reconstruction.json", audit)
    return audit


def _real_probe_64(hydro, inputs, scaling, contract, deadline, device, cache):
    phase = Phase("fit", FIT_START, FIT_START + timedelta(days=63))
    weather, values = inputs.weather_for(phase), inputs.observations_for(phase)
    frozen_identity = hydro.state_hash()
    network = network_for("rain", scaling, contract.seeds[0], device)
    factory = replay_factory(hydro, inputs, scaling, "rain", deadline=deadline)
    predicted = replay_phase(factory(network), phase, weather, values)
    reference = np.asarray([cache[day] for day in phase.dates])
    difference = float(np.max(np.abs(predicted - reference)))
    tolerance = 1e-5 * (1 + float(np.max(np.abs(reference))))
    if difference > tolerance:
        raise RuntimeError("Real 64-day zero-correction parity failed")
    optimizer = torch.optim.Adam(network.parameters(), lr=.001)
    training = train_epoch(factory(network), phase, weather, values, optimizer, contract.penalties["rain"])
    if not any(row["flow_supervised"] and row["nonzero_grad_parameters"] for row in training):
        raise RuntimeError("Real 64-day correction supervision has no gradient")
    network.eval()
    reference = replay_phase(factory(network), phase, weather, values)
    observations_changed = np.asarray(values).copy()
    finite = np.flatnonzero(np.isfinite(observations_changed[:50]))
    if not len(finite):
        raise RuntimeError("Real causal probe has no observation perturbation date")
    index = int(finite[len(finite) // 2])
    observations_changed[index] += 3. * scaling.flow_std
    response = replay_phase(factory(network), phase, weather, observations_changed)
    if not np.array_equal(reference[:index + 1], response[:index + 1]):
        raise RuntimeError("An observation perturbation changed a prediction already locked before arrival")
    if not np.any(reference[index + 1:] != response[index + 1:]):
        raise RuntimeError("Real observation causality check has no nonzero post-arrival response")
    weather_changed = np.asarray(weather).copy()
    weather_changed[index, 0] += float(scaling.cap)
    response_weather = replay_phase(factory(network), phase, weather_changed, values)
    if not np.array_equal(reference[:index], response_weather[:index]):
        raise RuntimeError("A weather perturbation changed a prediction before its arrival")
    if not np.any(reference[index:] != response_weather[index:]):
        raise RuntimeError("Real weather causality check has no nonzero post-arrival response")
    hydro.require_unchanged()
    if hydro.state_hash() != frozen_identity:
        raise RuntimeError("Real 64-day probe changed fixed runoff tensors")
    return {"days": 64, "zero_correction_maximum_difference": difference,
            "zero_correction_tolerance": tolerance, "legal_nonzero_supervised_gradient": True,
            "observation_causality": True, "weather_causality": True,
            "frozen_model_tensor_sha256": frozen_identity}


def _isolation_trajectory(contract, basin, device, deadline):
    """Use the new readers, explicit static/area adapter and a nonzero fixed network."""
    require_time(deadline, reserve=0.)
    configure_numerics()
    inputs = load_inputs(contract, basin, end=SELECT_END)
    fit = Phase("fit", FIT_START, FIT_END)
    phase = Phase("fit", FIT_START, FIT_START + timedelta(days=63))
    scaling = Scaling.fit(inputs.weather_for(fit), inputs.observations_for(fit), fit)
    hydro = BasinHydro(contract, basin, device=device)
    network = network_for("rain", scaling, contract.seeds[0], device)
    # A nonzero decoder avoids a constant-zero correction passing causality by construction.
    with torch.no_grad():
        network.decoder[-1].weight.fill_(.02)
        network.decoder[-1].bias.fill_(.03)
    network.eval()
    replay = replay_factory(hydro, inputs, scaling, "rain", deadline=deadline)(network)
    trajectory = replay_phase(replay, phase, inputs.weather_for(phase), inputs.observations_for(phase))
    synchronize(device)
    hydro.require_unchanged()
    gate = make_input_identity(contract, basin, inputs=inputs)
    return {"basin": basin, "seed": contract.seeds[0], "dates": [str(day) for day in phase.dates],
            "trajectory": trajectory.tolist(), "numeric_runtime": numerical_runtime(contract.repo, device),
            "sources": gate["sources"], "input_identity_sha256": canonical_digest(gate),
            "static_identity": hydro.static_identity, "area_identity": gate["area_identity"],
            "model_tensor_sha256": hydro.state_hash(),
            "cuda_reserved_peak": torch.cuda.max_memory_reserved(device) if str(device).startswith("cuda") else 0}


def isolation_reference(payload):
    """Clean-process reference invoked only by the bounded real probe supervisor."""
    import json
    from .contract import Contract
    parameters = json.loads(payload)
    contract = Contract.load(Path(parameters["contract"])).bind(
        repo=Path(parameters["repo"]), data_root=Path(parameters["data_root"]),
        model_root=Path(parameters["model_root"]), roster_lock=Path(parameters["roster_lock"]))
    require_sources(contract.repo, parameters["sources"])
    result = _isolation_trajectory(contract, parameters["basin"], parameters["device"], parameters["deadline"])
    write_json(Path(parameters["output"]), result)


def probe_adapter_isolation(contract, basin, root, deadline, device="cuda:0"):
    """Compare B after another real adapter A with a fresh process running B alone."""
    import json
    require_time(deadline, reserve=0.)
    other = contract.basins[(contract.basins.index(basin) - 1) % len(contract.basins)]
    other_result = _isolation_trajectory(contract, other, device, deadline)
    candidate = _isolation_trajectory(contract, basin, device, deadline)
    synchronize(device)
    reference_file = Path(root) / "isolation_reference.json"
    parameters = {"contract": str(contract.path), "repo": str(contract.repo),
                  "data_root": str(contract.data_root), "model_root": str(contract.model_root),
                  "roster_lock": str(contract.roster_lock), "basin": basin, "device": device,
                  "deadline": deadline, "sources": candidate["sources"], "output": str(reference_file)}
    code = ("import sys; sys.dont_write_bytecode=True; "
            "sys.path[:0]=[sys.argv[1],sys.argv[2]]; "
            "from precip_input_assimilation.dynamic_filter_multibasin.controller import isolation_reference; "
            "isolation_reference(sys.argv[3])")
    timeout = deadline - time.monotonic()
    if timeout <= 0:
        raise TimeoutError("No inherited probe time remains for the independent adapter reference")
    command = [sys.executable, "-B", "-c", code, str(contract.repo), str(contract.repo / "src"),
               json.dumps(parameters, allow_nan=False)]
    completed = subprocess.run(command, capture_output=True, text=True, timeout=timeout,
                               env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"), start_new_session=False)
    synchronize(device)
    write_json(Path(root) / "isolation_reference_process.json", {
        "returncode": completed.returncode, "stdout": completed.stdout, "stderr": completed.stderr,
        "deadline_monotonic": deadline, "command_kind": "private controller clean-process 64-day reference"})
    if completed.returncode:
        raise RuntimeError("Independent adapter reference failed; its process record is preserved")
    reference = read_json(reference_file)
    identity_keys = ("basin", "seed", "dates", "numeric_runtime", "sources", "input_identity_sha256",
                     "static_identity", "area_identity", "model_tensor_sha256")
    if any(reference[key] != candidate[key] for key in identity_keys):
        raise PermissionError("Independent and sequential basin adapters used different bound identities")
    differences = np.abs(np.asarray(candidate["trajectory"]) - np.asarray(reference["trajectory"]))
    maximum = float(np.max(differences))
    tolerance = 1e-5 * (1 + float(np.max(np.abs(reference["trajectory"]))))
    result = {"success": maximum <= tolerance, "basin": basin, "other_basin_run_first": other,
              "maximum_absolute_difference": maximum, "tolerance": tolerance,
              "reference": reference, "after_other_basin": candidate,
              "other_basin_input_identity_sha256": other_result["input_identity_sha256"],
              "interpretation": "measured adapter isolation; no prior contamination is alleged"}
    write_json(Path(root) / "adapter_isolation.json", result)
    if not result["success"]:
        raise RuntimeError("Real basin adapter isolation exceeds the fixed numerical tolerance")
    return result


def probe_basin(contract, basin, root, deadline, device="cuda:0"):
    """Full fit+selection epoch timings; no probe checkpoint can enter selection."""
    require_time(deadline, reserve=0.)
    from .audit import audit_rain_ledger
    directory = Path(root)
    directory.mkdir(parents=True, exist_ok=False)
    began = time.perf_counter()
    import psutil
    process = psutil.Process()
    ram_peak = [process.memory_info().rss]
    sample_stop = threading.Event()
    sample_errors = []

    def sample_ram():
        while not sample_stop.wait(.02):
            try:
                current = process.memory_info().rss
                for child in process.children(recursive=True):
                    try:
                        current += child.memory_info().rss
                    except (psutil.NoSuchProcess, psutil.ZombieProcess):
                        # A reference process may finish between discovery and sampling.
                        continue
                ram_peak[0] = max(ram_peak[0], current)
            except Exception as error:
                sample_errors.append(error)
                return

    sampler = threading.Thread(target=sample_ram, daemon=True)
    sampler.start()
    inputs = load_inputs(contract, basin, end=SELECT_END)
    fit, select = Phase("fit", FIT_START, FIT_END), Phase("select", SELECT_START, SELECT_END)
    scaling = Scaling.fit(inputs.weather_for(fit), inputs.observations_for(fit), fit)
    hydro = BasinHydro(contract, basin, device=device)
    original = hydro.state_hash()
    if str(device).startswith("cuda"):
        torch.cuda.reset_peak_memory_stats(device)
    cache = baseline_cache(hydro, inputs, FIT_START, SELECT_END, deadline, reserve=0.)
    technical64 = _real_probe_64(hydro, inputs, scaling, contract, deadline, device, cache)
    adapter_isolation = probe_adapter_isolation(contract, basin, directory, deadline, device)
    c_seconds = time.perf_counter() - began
    timings, replay_timings, audits = {}, [], []
    for kind in METHODS:
        network = network_for(kind, scaling, contract.seeds[0], device)
        factory = replay_factory(hydro, inputs, scaling, kind, base_cache=cache, deadline=deadline)
        optimizer = torch.optim.Adam(network.parameters(), lr=.001)
        synchronize(device)
        started = time.perf_counter()
        training = train_epoch(factory(network), fit, inputs.weather_for(fit), inputs.observations_for(fit),
                               optimizer, contract.penalties[kind])
        if not any(row["flow_supervised"] and row["nonzero_grad_parameters"] for row in training):
            raise RuntimeError("Real probe did not have legal supervised gradients")
        network.eval()
        replay = factory(network)
        replay_phase(replay, fit, inputs.weather_for(fit), inputs.observations_for(fit))
        replay_phase(replay, select, inputs.weather_for(select), inputs.observations_for(select))
        synchronize(device)
        timings[kind] = time.perf_counter() - started
        target = directory / kind
        target.mkdir(exist_ok=False)
        sink = CsvSink(target, "probe_only_never_selected", write_rain=kind != "flow")
        replay = replay_factory(hydro, inputs, scaling, kind, sink=sink, base_cache=cache,
                                deadline=deadline)(network)
        synchronize(device)
        started = time.perf_counter()
        try:
            replay_phase(replay, fit, inputs.weather_for(fit), inputs.observations_for(fit))
            replay_phase(replay, select, inputs.weather_for(select), inputs.observations_for(select))
        finally:
            sink.close()
        synchronize(device)
        replay_timings.append((time.perf_counter() - started) / (len(fit.dates) + len(select.dates)))
        if kind != "flow":
            started = time.perf_counter()
            audit_rain_ledger(target / "rain_versions.csv", inputs.dates, inputs.weather[:, 0],
                              expected_updates=len(fit.dates) + len(select.dates), expected_cap=scaling.cap,
                              missing_by_date={day: not math.isfinite(float(value)) for phase in (fit, select)
                                               for day, value in zip(phase.dates, inputs.observations_for(phase), strict=True)})
            audits.append(time.perf_counter() - started)
    if hydro.state_hash() != original:
        raise RuntimeError("Probe changed frozen hydrologic tensors")
    sample_stop.set()
    sampler.join(timeout=1.)
    if sample_errors:
        raise RuntimeError("Probe process-tree memory sampling failed") from sample_errors[0]
    ram_peak[0] = max(ram_peak[0], process.memory_info().rss)
    result = {"basin": basin, "epoch_seconds": timings, "replay_seconds_per_day": max(replay_timings),
              "peak_cuda_bytes": (torch.cuda.max_memory_reserved(device) +
                                  adapter_isolation["reference"]["cuda_reserved_peak"]) if str(device).startswith("cuda") else 0,
              "peak_system_bytes": ram_peak[0],
              "audit_seconds_estimate": max(audits) * 6 * (3287 / 1826), "c_seconds": c_seconds,
              "seconds": time.perf_counter() - began, "probe_only": True, "technical_64_days": technical64,
              "adapter_isolation": {"success": adapter_isolation["success"],
                                    "maximum_absolute_difference": adapter_isolation["maximum_absolute_difference"],
                                    "tolerance": adapter_isolation["tolerance"],
                                    "record_sha256": sha256(directory / "adapter_isolation.json")},
              "input_identity_sha256": canonical_digest(make_input_identity(contract, basin, inputs=inputs))}
    write_json(directory / "probe_record.json", result)
    return result
