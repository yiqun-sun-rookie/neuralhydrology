"""Complete input, checkpoint and source identities for the fixed eight-basin study.

This module never opens scoring-period inputs. A scoring permit is conditional on
the entire selection lock and a fresh reconstruction of allowed earlier inputs.
"""

from dataclasses import asdict, dataclass
import hashlib
import json
import math
from pathlib import Path


METHODS = ("rain", "flow", "historical")
SEEDS = (1001, 1002, 1003)
PENALTIES = {"rain": .0001, "flow": .001, "historical": .0001}


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for piece in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(piece)
    return digest.hexdigest()


def canonical_digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=False, allow_nan=False).encode("utf-8")).hexdigest()


def write_json(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, ensure_ascii=False, allow_nan=False)
        handle.write("\n")


def read_json(path):
    with Path(path).open(encoding="utf-8") as handle:
        return json.load(handle)


def _checkpoint_metadata(payload):
    if not isinstance(payload, dict) or not isinstance(payload.get("state_dict"), dict):
        raise PermissionError("Selected checkpoint is not a correction-network payload")
    keys = ("kind", "basin", "seed", "penalty", "epoch", "validation_nse", "input_identity_sha256",
            "contract_sha256")
    if any(key not in payload for key in keys):
        raise PermissionError("Selected checkpoint lacks its complete actual fitting metadata")
    return {key: payload[key] for key in keys}


def read_checkpoint_metadata(path):
    """Read the selected network payload itself, never infer identity from its filename."""
    import torch
    return _checkpoint_metadata(torch.load(Path(path), map_location="cpu", weights_only=True))


def require_checkpoint_metadata(path, fit, payload=None):
    actual = read_checkpoint_metadata(path) if payload is None else _checkpoint_metadata(payload)
    expected = {"kind": fit["kind"], "basin": fit["basin"], "seed": fit["seed"],
                "penalty": fit["penalty"], "epoch": fit["best_epoch"],
                "validation_nse": fit["validation_nse"],
                "input_identity_sha256": fit["input_identity_sha256"],
                "contract_sha256": fit["contract_sha256"]}
    if actual != expected or not isinstance(actual["epoch"], int) or not 1 <= actual["epoch"] <= 60:
        raise PermissionError("Selected checkpoint metadata differs from its locked method/seed/epoch/input")
    if not math.isfinite(float(actual["validation_nse"])):
        raise PermissionError("Selected checkpoint contains a nonfinite validation score")
    return actual


def bound_path(root, relative):
    root = Path(root).resolve(strict=True)
    name = Path(relative)
    if name.is_absolute() or ".." in name.parts:
        raise PermissionError("Artifact paths must be relative and stay in their registered run root")
    lexical = root / name
    resolved = lexical.resolve(strict=True)
    if not resolved.is_relative_to(root) or any(part == ".worktrees" for part in resolved.parts):
        raise PermissionError("Artifact path escaped its registered run root")
    for ancestor in (lexical, *lexical.parents):
        if ancestor == root.parent:
            break
        if ancestor.is_symlink() or (hasattr(ancestor, "is_junction") and ancestor.is_junction()):
            raise PermissionError("Artifact links and directory junctions are forbidden")
    if not resolved.is_file():
        raise PermissionError("Locked artifact is not a regular file")
    return resolved


def multibasin_source_snapshot(repo):
    """Explicit source inventory; includes the new controller, JSON and HPC files."""
    repo = Path(repo).resolve()
    stem = repo / "src/precip_input_assimilation"
    files = list((stem / "dynamic_filter").glob("*.py"))
    files += list((stem / "dynamic_filter_multibasin").glob("*.py"))
    files += list((stem / "scripts").glob("*dynamic_filter*.py"))
    files += list((stem / "tests").glob("test_dynamic_filter*.py"))
    files += [stem / "selfrule" / name for name in ("data.py", "model.py")]
    files += list((stem / "hpc").glob("dynamic_filter_eight_basins*"))
    files += [stem / "configs/dynamic_filter_eight_basins_v01.json"]
    files += [repo / name for name in (
        "neuralhydrology/modelzoo/cudalstm.py", "neuralhydrology/modelzoo/inputlayer.py",
        "neuralhydrology/modelzoo/head.py", "neuralhydrology/modelzoo/__init__.py",
        "neuralhydrology/datasetzoo/basedataset.py", "neuralhydrology/datasetzoo/camelsus.py",
        "neuralhydrology/utils/config.py")]
    if not files or any(not path.is_file() for path in files):
        raise RuntimeError("A required frozen or multi-basin source is missing")
    return {path.relative_to(repo).as_posix(): sha256(path) for path in sorted(set(files))}


def require_sources(repo, expected):
    for name, expected_digest in expected.items():
        if sha256(bound_path(repo, name)) != expected_digest:
            raise PermissionError(f"Locked source changed: {name}")
    if multibasin_source_snapshot(repo) != expected:
        raise PermissionError("Source inventory changed after it was locked")


def make_input_identity(contract, basin, inputs=None, sources=None):
    from .data import build_input_gate
    result = build_input_gate(contract, basin, inputs=inputs)
    result["sources"] = multibasin_source_snapshot(contract.repo) if sources is None else sources
    result["contract_sha256"] = contract.sha256
    result["basin"] = basin
    return result


def require_input_identity(contract, basin, expected):
    fresh = make_input_identity(contract, basin)
    if canonical_digest(fresh) != canonical_digest(expected):
        raise PermissionError(f"Input/static/area/source identity changed for basin {basin}")
    return fresh


@dataclass(frozen=True)
class BasinSelection:
    basin: str
    selected: tuple
    scaling: dict
    beta: float
    input_gate: str
    input_gate_sha256: str
    input_identity_sha256: str
    sources: dict
    model_identity: dict
    model_tensor_sha256: str
    contract_sha256: str
    training_root: str
    score_observations_read: bool = False

    def as_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, value):
        item = dict(value)
        item["selected"] = tuple(item["selected"])
        return cls(**item)


def validate_selection(contract, selection, revalidate_inputs=True):
    if isinstance(selection, BasinSelection):
        selection = selection.as_dict()
    basin = selection.get("basin")
    if basin not in contract.basins or selection.get("contract_sha256") != contract.sha256:
        raise PermissionError("Selection has a wrong basin or contract")
    if selection.get("score_observations_read") is not False:
        raise PermissionError("Selection was contaminated by scoring observations")
    root = Path(selection["training_root"])
    gate_path = bound_path(root, selection["input_gate"])
    if sha256(gate_path) != selection["input_gate_sha256"]:
        raise PermissionError("Input gate file changed")
    gate = read_json(gate_path)
    if canonical_digest(gate) != selection["input_identity_sha256"]:
        raise PermissionError("Input identity does not match the selected fits")
    if gate["basin"] != basin or gate["sources"] != selection["sources"]:
        raise PermissionError("Cross-basin or cross-source input binding")
    if gate["model_identity"] != selection["model_identity"]:
        raise PermissionError("Frozen model identity differs from input binding")
    expected = {(method, seed) for method in METHODS for seed in contract.seeds}
    found = set()
    if len(selection["selected"]) != len(expected):
        raise PermissionError("Each basin must have exactly nine complete fits")
    for fit in selection["selected"]:
        key = (fit["kind"], fit["seed"])
        if key not in expected or key in found or fit["penalty"] != contract.penalties[fit["kind"]]:
            raise PermissionError("Duplicate fit or wrong method, seed or fixed coefficient")
        found.add(key)
        if (fit.get("complete") is not True or fit.get("basin") != basin or
                fit.get("input_identity_sha256") != selection["input_identity_sha256"] or
                fit.get("contract_sha256") != contract.sha256):
            raise PermissionError("Fit has not completed under the full input identity")
        checkpoint_path = bound_path(root, fit["checkpoint"])
        if sha256(checkpoint_path) != fit["checkpoint_sha256"]:
            raise PermissionError("Selected checkpoint changed")
        summary = read_json(bound_path(root, fit["fit_summary"]))
        if canonical_digest(summary) != fit["fit_summary_identity"]:
            raise PermissionError("Completed fit record changed")
        locked_summary = {key: value for key, value in fit.items()
                          if key not in ("fit_summary", "fit_summary_identity")}
        if summary != locked_summary:
            raise PermissionError("Completed fit summary contents differ from the locked fitting record")
        require_checkpoint_metadata(checkpoint_path, fit)
    require_sources(contract.repo, selection["sources"])
    if revalidate_inputs:
        require_input_identity(contract, basin, gate)
    return selection


def validate_global_lock(contract, lock_path, revalidate_inputs=True):
    """Called by the bottom-level score permit before any scoring file is opened."""
    path = Path(lock_path).resolve(strict=True)
    lock = read_json(path)
    if lock.get("contract_sha256") != contract.sha256 or lock.get("score_observations_read") is not False:
        raise PermissionError("Global lock contract/phase is invalid")
    if tuple(lock.get("basins", ())) != tuple(contract.basins) or lock.get("checkpoint_count") != 72:
        raise PermissionError("All eight basins and all 72 fits must be locked before scoring")
    selections = lock.get("selections", [])
    if len(selections) != 8 or tuple(item.get("basin") for item in selections) != tuple(contract.basins):
        raise PermissionError("Global lock has missing, repeated or reordered basins")
    for item in selections:
        selection_file = bound_path(item["training_root"], item["selection_file"])
        if sha256(selection_file) != item["selection_sha256"]:
            raise PermissionError("A basin selection file changed")
        selection = read_json(selection_file)
        if canonical_digest(selection) != item["selection_identity"] or selection["basin"] != item["basin"]:
            raise PermissionError("Global lock has a different basin selection")
        validate_selection(contract, selection, revalidate_inputs=revalidate_inputs)
    return sha256(path)


# Keep a descriptive alias for deployment callers; both perform the complete check.
verify_global_lock = validate_global_lock


def require_recovery_identity(contract, basin, previous_fit, current_input_identity):
    if (previous_fit.get("complete") is not True or previous_fit.get("basin") != basin or
            previous_fit.get("contract_sha256") != contract.sha256 or
            previous_fit.get("input_identity_sha256") != current_input_identity):
        raise PermissionError("Only complete fits with identical contract/input/source identities can resume")
    return True
