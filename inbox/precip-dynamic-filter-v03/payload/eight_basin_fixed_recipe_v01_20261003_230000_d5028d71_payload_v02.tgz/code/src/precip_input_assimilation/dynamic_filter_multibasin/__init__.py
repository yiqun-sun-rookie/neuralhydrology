"""Fixed eight-basin repeat experiment; imports do not open inputs or load models."""

