"""Explicit basin static/area binding around the unchanged frozen runoff model."""

from __future__ import annotations

import csv
from dataclasses import dataclass
import hashlib
import math
from pathlib import Path

import numpy as np

from .contract import PINNED, file_sha256, guarded_path, object_sha256
from .data import WEATHER_NAMES


STATIC_NAMES = ("p_mean", "pet_mean", "aridity", "p_seasonality", "frac_snow", "high_prec_freq",
                "high_prec_dur", "low_prec_freq", "low_prec_dur", "elev_mean", "slope_mean", "area_gages2",
                "frac_forest", "lai_max", "lai_diff", "gvf_max", "gvf_diff", "soil_depth_pelletier",
                "soil_depth_statsgo", "soil_porosity", "soil_conductivity", "max_water_content",
                "sand_frac", "silt_frac", "clay_frac", "carbonate_rocks_frac", "geol_permeability")
ATTRIBUTE_FILES = {
    "camels_clim.txt": set(STATIC_NAMES[:9]),
    "camels_topo.txt": set(STATIC_NAMES[9:12]),
    "camels_vege.txt": set(STATIC_NAMES[12:17]),
    "camels_soil.txt": set(STATIC_NAMES[17:25]),
    "camels_geol.txt": set(STATIC_NAMES[25:]),
}


def require_model_identity(contract, model_dir=None):
    root = Path(model_dir or contract.model_root).resolve()
    if root != contract.model_root.resolve():
        raise PermissionError("Runoff model root differs from the registered deployment")
    actual = {}
    for relative, expected in PINNED.items():
        path = guarded_path(root / relative, root)
        actual[relative] = file_sha256(path)
        if actual[relative] != expected:
            raise PermissionError(f"Frozen runoff artifact changed: {relative}")
    return actual


@dataclass(frozen=True)
class StaticBinding:
    basin: str
    names: tuple[str, ...]
    raw: tuple[float, ...]
    missing: tuple[bool, ...]
    normalized: np.ndarray
    sha256: str
    sources: dict

    def as_dict(self):
        return {"basin": self.basin, "names": list(self.names),
                "raw": [format(value, ".17g") if math.isfinite(value) else "NA" for value in self.raw],
                "missing": list(self.missing),
                "normalized": [format(float(value), ".17g") for value in self.normalized],
                "sha256": self.sha256, "sources": self.sources}


def load_static_binding(contract, basin):
    if basin not in contract.basins:
        raise PermissionError("Static attributes requested for an unregistered basin")
    contract.verify_roster_lock()
    require_model_identity(contract)
    # These existing helpers load configuration/scaling only, never a model or Q.
    from ..selfrule.data import load_normalization
    from neuralhydrology.datautils.utils import load_scaler
    cfg, names, _, _, _, _ = load_normalization(contract.model_root)
    if tuple(names) != WEATHER_NAMES or tuple(cfg.static_attributes) != STATIC_NAMES:
        raise PermissionError("Frozen model attribute order or forcing mapping differs")
    if int(cfg.seq_length) != 270 or int(cfg.hidden_size) != 256:
        raise PermissionError("Frozen model dimensions differ from the approved recipe")
    scaler = load_scaler(contract.model_root)
    raw, sources = {}, {}
    for filename, permitted in ATTRIBUTE_FILES.items():
        # Explicit whitelist; camels_hydro cannot be opened by this adapter.
        path = guarded_path(contract.data_root / "camels_attributes_v2.0" / filename, contract.data_root)
        rows = []
        with path.open(encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle, delimiter=";")
            if not permitted.issubset(reader.fieldnames or ()):
                raise ValueError("Missing approved static columns")
            for row in reader:
                if row["gauge_id"] == basin:
                    rows.append(row)
        if len(rows) != 1:
            raise ValueError(f"{basin}: expected exactly one static row in {filename}")
        row = rows[0]
        sources[filename] = {"file_sha256": file_sha256(path),
                             "row_sha256": object_sha256({name: row[name] for name in sorted(permitted)}),
                             "columns": sorted(permitted)}
        for name in permitted:
            token = row[name]
            raw[name] = float("nan") if token.strip().casefold() in ("", "nan", "na", "n/a") else float(token)
    values = tuple(raw[name] for name in STATIC_NAMES)
    missing = tuple(not math.isfinite(value) for value in values)
    normalized = []
    normalization = {}
    for name, value in zip(STATIC_NAMES, values, strict=True):
        center, scale = float(scaler["attribute_means"][name]), float(scaler["attribute_stds"][name])
        if not math.isfinite(center) or not math.isfinite(scale) or scale <= 0:
            raise ValueError("Invalid frozen static normalization")
        normalized.append((value - center) / scale)
        normalization[name] = {"center": format(center, ".17g"), "scale": format(scale, ".17g")}
    array = np.asarray(normalized, dtype=np.float32)
    if not np.isfinite(array).all():
        raise ValueError("Static attributes are missing or nonfinite after frozen normalization")
    array.setflags(write=False)
    sources["normalization"] = normalization
    content = {"basin": basin, "names": list(STATIC_NAMES),
               "raw": [format(value, ".17g") if math.isfinite(value) else "NA" for value in values],
               "missing": list(missing), "normalized": [format(float(value), ".17g") for value in array],
               "sources": sources}
    return StaticBinding(basin, STATIC_NAMES, values, missing, array, object_sha256(content), sources)


class BasinHydro:
    """Each instance permanently binds one basin and has no shared mutable state."""

    def __init__(self, contract, basin, model_dir=None, device="cpu"):
        import torch
        from ..selfrule.data import load_normalization
        from ..selfrule.model import FrozenC4
        from ..dynamic_filter.report import require_no_forbidden_imports
        if basin not in contract.basins:
            raise PermissionError("Hydrology adapter requested for an unregistered basin")
        self.contract, self.basin = contract, basin
        self.model_identity = require_model_identity(contract, model_dir)
        self.binding = load_static_binding(contract, basin)
        self.static_identity = self.binding.as_dict()
        cfg, names, center, scale, q_center, q_scale = load_normalization(contract.model_root)
        if tuple(names) != WEATHER_NAMES or cfg.seq_length != 270 or cfg.hidden_size != 256:
            raise PermissionError("Frozen runoff mapping or architecture differs")
        self.device = torch.device(device)
        self.frozen = FrozenC4(contract.model_root, device, names, center, scale, q_center, q_scale)
        self.static = torch.tensor(self.binding.normalized.copy(), dtype=torch.float32, device=self.device)
        self._static_reference = self.static
        self._static_version = self.static._version
        self.sequence_length = self.frozen.sequence_length
        require_no_forbidden_imports()
        self._initial_state = self.state_hash()

    def __call__(self, window):
        import torch
        self._require_static_binding()
        return self.frozen.predict(window, self.static,
                                   torch.tensor([len(window) - 1], device=self.device))[0]

    def direct(self, weather, indices, batch=1):
        import torch
        self._require_static_binding()
        raw = torch.as_tensor(np.asarray(weather).copy(), dtype=torch.float32, device=self.device)
        pieces = []
        with torch.no_grad():
            for begin in range(0, len(indices), batch):
                positions = torch.as_tensor(indices[begin:begin + batch], dtype=torch.int64, device=self.device)
                pieces.append(self.frozen.predict(raw, self.static, positions).cpu().numpy())
        return np.concatenate(pieces) if pieces else np.empty(0)

    def state_hash(self):
        if hasattr(self, "_static_reference"):
            self._require_static_binding()
        digest = hashlib.sha256()
        for name, parameter in self.frozen.model.state_dict().items():
            digest.update(name.encode("utf-8"))
            digest.update(parameter.detach().cpu().contiguous().numpy().tobytes())
        return digest.hexdigest()

    def _require_static_binding(self):
        if (self.binding.basin != self.basin or self.static is not self._static_reference or
                self.static._version != self._static_version):
            raise PermissionError("Frozen hydrology static tensor was replaced, edited or bound to another basin")

    def require_unchanged(self):
        if self.state_hash() != self._initial_state or any(
                parameter.requires_grad or parameter.grad is not None for parameter in self.frozen.model.parameters()):
            raise RuntimeError("Frozen runoff state changed or received parameter gradients")
