"""Independent row readers which test basin, phase and date before numeric parsing."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
import hashlib
import math
from pathlib import Path

import numpy as np

from .contract import Contract, DATES, ReadPermit, guarded_path, object_sha256


WEATHER_NAMES = ("PRCP(mm/day)", "Tmin(C)", "Tmax(C)", "SRAD(W/m2)", "Vp(Pa)")
CFS_TO_MM = 28316846.592 * 86400. / 1_000_000.


def daily_dates(start, end):
    return tuple(start + timedelta(days=i) for i in range((end - start).days + 1))


def canonical_series(basin, phase, dates, names, values, precision):
    if not dates:
        raise ValueError("Empty input segment")
    digest = hashlib.sha256()
    digest.update(f"basin={basin};phase={phase};start={dates[0]};end={dates[-1]}\n".encode())
    digest.update(("date," + ",".join(names) + "\n").encode("utf-8"))
    array = np.asarray(values).reshape(len(dates), len(names))
    for day, row in zip(dates, array, strict=True):
        tokens = [format(float(value), f".{precision}g") if math.isfinite(float(value)) else "NA" for value in row]
        digest.update((str(day) + "," + ",".join(tokens) + "\n").encode("utf-8"))
    return digest.hexdigest()


@dataclass(frozen=True)
class WeatherBlock:
    basin: str
    dates: tuple[date, ...]
    names: tuple[str, ...]
    values: np.ndarray
    area_m2: float
    source_path: Path
    canonical_sha256: str
    raw_sha256: str
    mapping: dict


@dataclass(frozen=True)
class FlowBlock:
    basin: str
    dates: tuple[date, ...]
    values: np.ndarray
    source_path: Path
    canonical_sha256: str
    raw_sha256: str
    conversion: dict


def find_unique(contract, root, pattern):
    root = guarded_path(root, contract.data_root)
    matches = list(root.glob("**/" + pattern))
    if len(matches) != 1:
        raise FileNotFoundError(f"Expected exactly one registered file matching {pattern}; found {len(matches)}")
    return guarded_path(matches[0], contract.data_root)


def weather_path(contract, basin):
    return find_unique(contract, contract.data_root / "basin_mean_forcing/maurer",
                       basin + "_*_forcing_leap.txt")


def _header(handle, path):
    latitude, elevation = handle.readline().strip(), handle.readline().strip()
    area_token = handle.readline().strip()
    area = float(area_token)
    header = tuple(handle.readline().split())
    if area <= 0 or not math.isfinite(area) or len(header) != len(set(header)):
        raise ValueError("Invalid Maurer area or duplicate weather header")
    if tuple(header[:4]) != ("Year", "Mnth", "Day", "Hr"):
        raise ValueError("Maurer date and hour fields have an unapproved layout")
    if any(name not in header for name in WEATHER_NAMES):
        raise ValueError("Maurer fields are missing or have incompatible names/units")
    columns = tuple(header.index(name) for name in WEATHER_NAMES)
    return area, {"header": list(header), "columns_zero_based": list(columns),
                  "weather_names": list(WEATHER_NAMES), "area_token_m2": area_token,
                  "latitude_header": latitude, "elevation_header": elevation,
                  "source_version": "historical_source_unknown_current_mapping_explicit"}, columns


def read_weather(contract: Contract, basin: str, phase: str, start: date, end: date,
                 permit: ReadPermit | None = None) -> WeatherBlock:
    # All permission checks happen before file discovery and opening.
    contract.validate_permit(permit, basin, phase, start, end, kind="weather")
    path = weather_path(contract, basin)
    rows, actual_dates, raw_digest = [], [], hashlib.sha256()
    with path.open("r", encoding="utf-8") as handle:
        area, mapping, columns = _header(handle, path)
        previous = None
        for number, line in enumerate(handle, 5):
            fields = line.split()
            if len(fields) < 4:
                raise ValueError(f"Malformed Maurer date at line {number}")
            current = date(*(int(token) for token in fields[:3]))
            if previous is not None and current <= previous:
                raise ValueError("Weather dates are not strictly increasing")
            previous = current
            if current < start:
                continue
            if current > end:
                break
            if len(fields) != len(mapping["header"]):
                raise ValueError("Weather value count differs from approved header")
            row = [float(fields[column]) for column in columns]
            actual_dates.append(current)
            rows.append(row)
            raw_digest.update((" ".join(fields) + "\n").encode("utf-8"))
            if current == end:
                break  # Do not request a future row after the last allowed date.
    dates = daily_dates(start, end)
    values = np.asarray(rows, dtype=np.float32)
    if tuple(actual_dates) != dates or values.shape != (len(dates), 5):
        raise ValueError("Weather is not a complete permitted daily grid")
    if not np.isfinite(values).all() or (values[:, 0] < 0).any():
        raise ValueError("Weather contains missing, nonfinite or negative-rain values")
    # Row conversion is exactly the original float -> float32 field mapping.
    mapping["float32_mapping_exact"] = bool(np.array_equal(values, np.asarray(rows, dtype=np.float32)))
    mapping["minimum_maximum_temperature_equal_days"] = int(np.sum(values[:, 1] == values[:, 2]))
    values.setflags(write=False)
    return WeatherBlock(basin, dates, WEATHER_NAMES, values, area, path,
                        canonical_series(basin, phase, dates, WEATHER_NAMES, values, 9),
                        raw_digest.hexdigest(), mapping)


def read_flow(contract: Contract, basin: str, phase: str, start: date, end: date,
              permit: ReadPermit | None = None, *, area_m2=None) -> FlowBlock:
    contract.validate_permit(permit, basin, phase, start, end, kind="flow")
    # The conversion area is independently tied to THIS basin's forcing header;
    # an area supplied by another basin or a caller-created scalar is rejected.
    forcing = weather_path(contract, basin)
    with forcing.open("r", encoding="utf-8") as handle:
        actual_area, _, _ = _header(handle, forcing)
    if area_m2 is not None and float(area_m2) != actual_area:
        raise PermissionError("Flow conversion area differs from this basin's forcing header")
    path = find_unique(contract, contract.data_root / "usgs_streamflow", basin + "_streamflow_qc.txt")
    values, previous, raw_digest = {}, None, hashlib.sha256()
    with path.open("r", encoding="utf-8") as handle:
        for number, line in enumerate(handle, 1):
            fields = line.split()
            if len(fields) < 4:
                raise ValueError(f"Malformed flow date at line {number}")
            current = date(*(int(token) for token in fields[1:4]))
            if fields[0] != basin or (previous is not None and current <= previous):
                raise PermissionError("Flow row has the wrong basin or non-increasing date")
            previous = current
            if current < start:
                continue
            if current > end:
                break
            if len(fields) < 5:
                raise ValueError("Missing flow value in permitted row")
            raw = float(fields[4])  # This token is never evaluated before the date check.
            values[current] = float("nan") if raw < 0 or not math.isfinite(raw) else CFS_TO_MM * raw / actual_area
            raw_digest.update((" ".join(fields) + "\n").encode("utf-8"))
            if current == end:
                break
    dates = daily_dates(start, end)
    array = np.asarray([values.get(day, float("nan")) for day in dates], dtype=np.float64)
    array.setflags(write=False)
    source = str(forcing.relative_to(contract.data_root)).replace("\\", "/")
    conversion = {"raw_unit": "ft3/s", "output_unit": "mm/day", "constant": CFS_TO_MM,
                  "area_m2": actual_area, "area_unit": "m2", "area_source": source}
    return FlowBlock(basin, dates, array, path,
                     canonical_series(basin, phase, dates, ("QObs(mm/d)",), array, 17),
                     raw_digest.hexdigest(), conversion)


@dataclass
class Inputs:
    basin: str
    dates: tuple[date, ...]
    weather: np.ndarray
    area_m2: float
    weather_blocks: dict[str, WeatherBlock]
    flow_blocks: dict[str, FlowBlock]
    hashes: dict

    def weather_for(self, phase):
        first, last = self.dates.index(phase.start), self.dates.index(phase.end)
        return self.weather[first:last + 1]

    def observations_for(self, phase):
        block = self.flow_blocks.get(phase.name)
        if block is None or not block.dates[0] <= phase.start <= phase.end <= block.dates[-1]:
            raise PermissionError("Requested observations were not loaded under this phase permission")
        return block.values[block.dates.index(phase.start):block.dates.index(phase.end) + 1]

    @property
    def flow_path(self):
        return self.flow_blocks["fit"].source_path


def load_inputs(contract, basin, end=DATES["select"][1], selection_lock=None):
    if end not in (DATES["select"][1], DATES["score"][1], DATES["probe"][1]):
        raise PermissionError("Input loader only accepts approved complete endpoints")
    weather_blocks, flow_blocks = {}, {}
    phases = ["warmup", "probe"] if end == DATES["probe"][1] else ["warmup", "fit", "select"]
    if end == DATES["score"][1]:
        phases.append("score")
    for phase in phases:
        start, stop = DATES[phase]
        permit = contract.authorize(basin, phase, start, stop, selection_lock if phase == "score" else None)
        weather_blocks[phase] = read_weather(contract, basin, phase, start, stop, permit)
        if phase != "warmup":
            flow_blocks[phase] = read_flow(contract, basin, phase, start, stop, permit,
                                          area_m2=weather_blocks[phase].area_m2)
    blocks = list(weather_blocks.values())
    area = blocks[0].area_m2
    if any(block.area_m2 != area for block in blocks):
        raise PermissionError("Weather area changed between permitted segments")
    dates = tuple(day for block in blocks for day in block.dates)
    weather = np.concatenate([block.values for block in blocks])
    weather.setflags(write=False)
    hashes = {"weather_" + phase: block.canonical_sha256 for phase, block in weather_blocks.items()}
    hashes.update({"flow_" + phase: block.canonical_sha256 for phase, block in flow_blocks.items()})
    return Inputs(basin, dates, weather, area, weather_blocks, flow_blocks, hashes)


def flow_coverage(block, water_years):
    result = {}
    for year in water_years:
        start, stop = date(year - 1, 10, 1), date(year, 9, 30)
        mask = np.asarray([start <= day <= stop for day in block.dates])
        values = block.values[mask]
        valid = values[np.isfinite(values)]
        fraction = float(len(valid) / len(values)) if len(values) else 0.
        variance = float(np.var(valid)) if len(valid) >= 2 else 0.
        result[str(year)] = {"days": len(values), "valid_count": len(valid), "coverage": fraction,
                             "variance": variance, "pass": bool(fraction >= .9 and len(valid) >= 2 and variance > 0)}
    return result


def build_input_gate(contract, basin, inputs=None):
    """Stable evidence from allowed input segments; never constructs a model."""
    from .hydro import load_static_binding, require_model_identity
    inputs = inputs or load_inputs(contract, basin)
    if inputs.basin != basin or basin not in contract.basins:
        raise PermissionError("Input object is bound to another basin")
    if not {"warmup", "fit", "select"}.issubset(inputs.weather_blocks) or not {"fit", "select"}.issubset(inputs.flow_blocks):
        raise PermissionError("Input gate requires all permitted pre-scoring segments")
    static = load_static_binding(contract, basin)
    if static.basin != basin:
        raise PermissionError("Static binding belongs to a different basin")
    coverage = {"fit": flow_coverage(inputs.flow_blocks["fit"], range(1981, 1985)),
                "select": flow_coverage(inputs.flow_blocks["select"], (1985,))}
    weather = {}
    for phase in ("warmup", "fit", "select"):
        block = inputs.weather_blocks[phase]
        expected_dates = daily_dates(*DATES[phase])
        if (block.basin != basin or block.dates != expected_dates or block.names != WEATHER_NAMES or
                block.area_m2 != inputs.area_m2):
            raise PermissionError("Weather block has a different basin, area, column order or phase dates")
        actual_hash = canonical_series(basin, phase, block.dates, block.names, block.values, 9)
        first, last = inputs.dates.index(expected_dates[0]), inputs.dates.index(expected_dates[-1])
        if actual_hash != block.canonical_sha256 or not np.array_equal(inputs.weather[first:last + 1], block.values):
            raise PermissionError("Weather numeric arrays changed since the permitted read")
        weather[phase] = {"start": str(block.dates[0]), "end": str(block.dates[-1]), "days": len(block.dates),
                          "names": list(block.names), "canonical_sha256": block.canonical_sha256,
                          "raw_sha256": block.raw_sha256,
                          "source": str(block.source_path.relative_to(contract.data_root)).replace("\\", "/"),
                          "mapping": block.mapping}
    flows = {}
    for phase in ("fit", "select"):
        block = inputs.flow_blocks[phase]
        if (block.basin != basin or block.conversion["area_m2"] != inputs.area_m2 or
                block.dates != daily_dates(*DATES[phase])):
            raise PermissionError("Flow block or conversion area belongs to another basin")
        if canonical_series(basin, phase, block.dates, ("QObs(mm/d)",), block.values, 17) != block.canonical_sha256:
            raise PermissionError("Flow numeric array changed since the permitted read")
        flows[phase] = {"start": str(block.dates[0]), "end": str(block.dates[-1]), "days": len(block.dates),
                       "canonical_sha256": block.canonical_sha256, "raw_sha256": block.raw_sha256,
                       "conversion": block.conversion,
                       "source": str(block.source_path.relative_to(contract.data_root)).replace("\\", "/")}
    gate = {"basin": basin, "contract_sha256": contract.sha256,
            "canonical_inputs": {"weather": weather, "flow": flows},
            "static_identity": static.as_dict(),
            "area_identity": {"basin": basin, "forcing_area_m2": inputs.area_m2,
                              "static_area_km2": static.raw[static.names.index("area_gages2")],
                              "conversion": inputs.flow_blocks["fit"].conversion},
            "model_identity": require_model_identity(contract), "coverage": coverage,
            "temperature_mapping": "current_mapping_explicit_historical_source_unknown",
            "pass": all(item["pass"] for phase in coverage.values() for item in phase.values())}
    if not gate["pass"]:
        raise ValueError(f"{basin}: pre-scoring flow coverage/variance gate failed: {coverage}")
    gate["input_sha256"] = object_sha256(gate["canonical_inputs"])
    return gate
