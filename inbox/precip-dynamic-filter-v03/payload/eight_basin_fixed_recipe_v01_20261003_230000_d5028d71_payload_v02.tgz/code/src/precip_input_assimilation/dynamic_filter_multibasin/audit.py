"""Independent stable-sum metrics, eight-basin gates and append-only rain checks.

Does not import the production metric or gate functions. The scorer's stored
observations are used only after complete selection; no original flow is opened.
"""

import csv
from datetime import date, timedelta
from itertools import product
import math
from pathlib import Path
from statistics import median

from .identity import METHODS, SEEDS, read_json, sha256


def stable_nse(observations, predictions):
    if len(observations) != len(predictions):
        raise ValueError("Observation and prediction calendars differ")
    pairs = [(float(observation), float(prediction)) for observation, prediction in
             zip(observations, predictions, strict=True) if math.isfinite(float(observation))]
    if any(not math.isfinite(prediction) for _, prediction in pairs):
        raise RuntimeError("Nonfinite prediction on the common observation calendar")
    if len(pairs) < 2:
        return None
    mean = math.fsum(observation for observation, _ in pairs) / len(pairs)
    denominator = math.fsum((observation - mean) ** 2 for observation, _ in pairs)
    if denominator <= 0:
        return None
    return 1. - math.fsum((observation - prediction) ** 2 for observation, prediction in pairs) / denominator


def basin_gate(scores):
    methods, coverage = scores["methods"], scores["coverage"]
    expected = {"base", "persistence"} | {f"{method}_s{seed}" for method in METHODS for seed in SEEDS}
    complete = set(methods) == expected and set(coverage) == {"1986", "1987", "1988", "1989"}
    finite = complete and all(item["full"] is not None and math.isfinite(item["full"]) and
                              set(item["annual"]) == set(coverage) and
                              all(value is not None and math.isfinite(value) for value in item["annual"].values())
                              for item in methods.values())
    technical = finite and all(value >= .9 for value in coverage.values())
    if not technical:
        return {"technical_complete": False, "station_pass": False, "D": None,
                "reason": "missing method/seed/year, undefined efficiency or insufficient annual coverage"}
    base, persistence = methods["base"], methods["persistence"]
    rain = [methods[f"rain_s{seed}"] for seed in SEEDS]
    flow = [methods[f"flow_s{seed}"] for seed in SEEDS]
    gains = [item["full"] - base["full"] for item in rain]
    annual = {year: median([item["annual"][year] - base["annual"][year] for item in rain])
              for year in coverage}
    tests = {"median_gain_at_least_0.005": median(gains) >= .005,
             "two_seeds_positive": sum(value > 0 for value in gains) >= 2,
             "three_years_positive": sum(value > 0 for value in annual.values()) >= 3,
             "beats_yesterday_error": median([item["full"] for item in rain]) > persistence["full"]}
    return {"technical_complete": True, "station_pass": all(tests.values()), "tests": tests,
            "rain_median": median([item["full"] for item in rain]),
            "flow_median": median([item["full"] for item in flow]),
            "D": median([item["full"] for item in rain]) - median([item["full"] for item in flow]),
            "seed_gains": gains, "annual_median_gains": annual}


def _linear_quantile(values, probability):
    values = sorted(values)
    position = (len(values) - 1) * probability
    lower = math.floor(position)
    upper = math.ceil(position)
    return values[lower] + (values[upper] - values[lower]) * (position - lower)


def summarize_eight(scores, basins, strata):
    if len(basins) != 8 or len(set(basins)) != 8 or set(scores) != set(basins):
        return {"continue_regional_research": False, "technical_complete": False,
                "reason": "The complete fixed set of eight basins is required"}
    stations = {basin: basin_gate(scores[basin]) for basin in basins}
    technical = all(item["technical_complete"] for item in stations.values())
    if not technical:
        return {"continue_regional_research": False, "technical_complete": False, "stations": stations}
    groups = {}
    for basin in basins:
        groups.setdefault(strata[basin], []).append(basin)
    if len(groups) != 4 or any(len(group) != 2 for group in groups.values()):
        raise ValueError("The four predeclared strata must each contain exactly two basins")
    differences = [stations[basin]["D"] for basin in basins]
    positive_by_stratum = {name: sum(stations[basin]["D"] > 0 for basin in group)
                           for name, group in groups.items()}
    tests = {"all_eight_technically_complete": technical,
             "six_station_gates": sum(item["station_pass"] for item in stations.values()) >= 6,
             "six_positive_D": sum(value > 0 for value in differences) >= 6,
             "median_D_at_least_0.005": median(differences) >= .005,
             "each_stratum_has_positive_D": all(value >= 1 for value in positive_by_stratum.values()),
             "no_D_below_minus_0.05": all(value >= -.05 for value in differences)}
    choices = [list(product(group, repeat=2)) for group in groups.values()]
    resamples = [median([stations[basin]["D"] for pair in combination for basin in pair])
                 for combination in product(*choices)]
    assert len(resamples) == 256
    return {"continue_regional_research": all(tests.values()), "technical_complete": technical,
            "tests": tests, "stations": stations, "D_in_roster_order": differences,
            "median_D": median(differences), "positive_D_count": sum(value > 0 for value in differences),
            "station_pass_count": sum(item["station_pass"] for item in stations.values()),
            "positive_by_stratum": positive_by_stratum,
            "stratified_descriptive_range": {"combinations": 256, "lower": _linear_quantile(resamples, .025),
                                              "upper": _linear_quantile(resamples, .975),
                                              "meaning": "sensitivity within these eight basins; not a national confidence interval"},
            "scope": "separately fitted fixed recipe, retrospective fixed runoff model; no true-rainfall claim"}


def audit_rain_ledger(path, weather_dates, raw_rain, expected_updates, expected_cap, missing_by_date):
    if not math.isfinite(float(expected_cap)) or expected_cap <= 0:
        raise ValueError("The independently locked rain cap must be finite and positive")
    raw_by_date = dict(zip(weather_dates, map(float, raw_rain), strict=True))
    positions = {day: index for index, day in enumerate(weather_dates)}
    previous, current, seen, final = None, None, set(), {}
    rows, updates, touch_upper, touch_lower = 0, 0, 0, 0
    online_abs = []
    group_missing = None

    def finish_group():
        nonlocal updates
        if current is None:
            return
        endpoint = positions[current]
        expected = set(weather_dates[max(0, endpoint - 99):endpoint + 1])
        if seen != expected:
            raise RuntimeError("Rain ledger omitted, repeated or added a date outside its 100-day window")
        updates += 1

    with Path(path).open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            rain_day, as_of = date.fromisoformat(row["rain_date"]), date.fromisoformat(row["as_of_date"])
            if as_of != current:
                finish_group()
                if current is not None and as_of != current + timedelta(days=1):
                    raise RuntimeError("Rain versions do not advance in daily order")
                # The previous ledger is the one available when today's prediction was locked.
                online_abs.append(math.fsum(abs(value) for value in final.values()))
                previous, current, seen = current, as_of, set()
                group_missing = int(row["missing"])
            if rain_day in seen or rain_day not in raw_by_date or as_of not in positions:
                raise RuntimeError("Rain ledger has a repeated or unregistered date")
            seen.add(rain_day)
            if not as_of - timedelta(days=99) <= rain_day <= as_of:
                raise RuntimeError("Rain revision escaped the allowed trailing 100-day window")
            raw, proposal, applied, cap = [float(row[name]) for name in ("raw_mm", "proposal_mm", "applied_mm", "cap_mm")]
            if not all(math.isfinite(value) for value in (raw, proposal, applied, cap)) or cap <= 0:
                raise RuntimeError("Nonfinite rain ledger or invalid cap")
            if cap != float(expected_cap):
                raise RuntimeError("Rain ledger cap differs from the independently selected fitting-only cap")
            if as_of not in missing_by_date or int(row["missing"]) != int(missing_by_date[as_of]):
                raise RuntimeError("Rain ledger missing flag differs from the independently bound observation calendar")
            tolerance = 2e-6 * (1 + max(abs(raw), cap))
            if abs(raw - raw_by_date[rain_day]) > tolerance:
                raise RuntimeError("Rain ledger raw precipitation differs from its input")
            lower = -min(raw, cap)
            if applied < lower - tolerance or applied > cap + tolerance or raw + applied < -tolerance:
                raise RuntimeError("Rain revision violates additive bounds or nonnegativity")
            if int(row["missing"]) != group_missing:
                raise RuntimeError("A daily missing-data update flag is inconsistent")
            if group_missing and abs(applied - final.get(rain_day, 0.)) > tolerance:
                raise RuntimeError("Missing observation changed its inherited rain ledger")
            if not group_missing and abs(applied - min(cap, max(lower, proposal))) > tolerance:
                raise RuntimeError("Applied rain differs from the bounded proposal")
            final[rain_day] = applied
            touch_upper += int(applied >= cap - 1e-6)
            touch_lower += int(applied <= lower + 1e-6)
            rows += 1
    finish_group()
    if (updates != expected_updates or not online_abs or
            current != weather_dates[-1]):
        raise RuntimeError("Rain ledger does not have precisely one update per prediction date")
    return {"updates": updates, "rows": rows, "touch_upper": touch_upper, "touch_lower": touch_lower,
            "final_unique_date_absolute_mm": math.fsum(abs(value) for value in final.values()),
            "online_pre_prediction_absolute_mm_sum": math.fsum(online_abs),
            "online_scope": "sum of per-prediction ledger diagnostics; repeated dates are not unique rainfall totals",
            "final_scope": "one last available revision per unique rain date"}


def _observations(path):
    dates, values = [], []
    with Path(path).open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            dates.append(date.fromisoformat(row["date"]))
            values.append(float("nan") if row["q_mm_day"] == "NA" else float(row["q_mm_day"]))
    return dates, values


def audit_run(contract, root, global_lock=None):
    from ..dynamic_filter.protocol import FIT_START, FIT_END, SELECT_START, SELECT_END, SCORE_START, SCORE_END, Phase
    from .data import load_inputs
    from .identity import bound_path, validate_global_lock
    if global_lock is None:
        raise PermissionError("Independent result reconstruction requires the full global selection lock")
    lock_digest = validate_global_lock(contract, global_lock)
    selection_items = {item["basin"]: item for item in read_json(global_lock)["selections"]}
    root = Path(root)
    all_scores, details = {}, {}
    for basin in contract.basins:
        directory = root / "basins" / basin
        item = selection_items[basin]
        selection = read_json(bound_path(item["training_root"], item["selection_file"]))
        checkpoint_by_name = {f"{fit['kind']}_s{fit['seed']}": fit["checkpoint_sha256"]
                              for fit in selection["selected"]}
        checkpoint_by_name.update(base="frozen_base", persistence=f"fit_beta={selection['beta']:.17g}")
        expected = read_json(directory / "summary.json")
        score_identity = read_json(directory / "score_input_locked.json")
        if score_identity["global_selection_lock_sha256"] != lock_digest:
            raise PermissionError("Scoring input is bound to another global selection")
        dates, observations = _observations(directory / "score_observations.csv")
        if tuple(dates) != Phase("score", SCORE_START, SCORE_END).dates:
            raise RuntimeError("Stored observations are missing or reorder scoring dates")
        fresh = load_inputs(contract, basin, end=SCORE_END, selection_lock=Path(global_lock))
        flow = fresh.flow_blocks["score"]
        weather_block = fresh.weather_blocks["score"]
        if (flow.canonical_sha256 != score_identity["flow_canonical_sha256"] or
                weather_block.canonical_sha256 != score_identity["weather_canonical_sha256"] or
                flow.raw_sha256 != score_identity["flow_raw_sha256"] or
                weather_block.raw_sha256 != score_identity["weather_raw_sha256"]):
            raise PermissionError("Original scoring inputs changed after scoring")
        source_values = fresh.observations_for(Phase("score", SCORE_START, SCORE_END))
        if any((math.isfinite(a) != math.isfinite(float(b))) or
               (math.isfinite(a) and a != float(b)) for a, b in zip(observations, source_values, strict=True)):
            raise RuntimeError("Stored observations differ from the score-locked input")
        phases = (Phase("fit", FIT_START, FIT_END), Phase("select", SELECT_START, SELECT_END),
                  Phase("score", SCORE_START, SCORE_END))
        observations_all = {day: float(value) for phase in phases
                            for day, value in zip(phase.dates, fresh.observations_for(phase), strict=True)}
        missing_by_date = {day: not math.isfinite(value) for day, value in observations_all.items()}
        methods, negatives, ledger_audits, baseline_trajectories = {}, {}, {}, {}
        for name in ["base", "persistence"] + [f"{method}_s{seed}" for method in METHODS for seed in SEEDS]:
            trajectory = directory / "scoring" / name
            predicted = {}
            with (trajectory / "predictions.csv").open(encoding="utf-8", newline="") as handle:
                all_days = []
                for row in csv.DictReader(handle):
                    if row["checkpoint"] != checkpoint_by_name[name]:
                        raise PermissionError("Prediction trajectory was produced by an unlocked checkpoint")
                    day = date.fromisoformat(row["date"])
                    if date.fromisoformat(row["observation_cutoff"]) != day - timedelta(days=1):
                        raise RuntimeError("A prediction used an observation arriving after its allowed cutoff")
                    value = float(row["q_mm_day"])
                    if not math.isfinite(value) or day in predicted:
                        raise RuntimeError("Nonfinite or duplicated prediction")
                    all_days.append(day)
                    predicted[day] = value
            expected_days = Phase("synthetic", FIT_START, SCORE_END).dates
            if tuple(all_days) != expected_days:
                raise RuntimeError("Trajectory did not replay the complete fit/select/score calendar")
            if name in ("base", "persistence"):
                baseline_trajectories[name] = predicted
            values = [predicted[day] for day in dates]
            full, annual = stable_nse(observations, values), {}
            coverage = {}
            for year in range(1986, 1990):
                mask = [index for index, day in enumerate(dates)
                        if date(year - 1, 10, 1) <= day < date(year, 10, 1)]
                obs_year, pred_year = [observations[i] for i in mask], [values[i] for i in mask]
                coverage[str(year)] = sum(math.isfinite(value) for value in obs_year) / len(mask)
                annual[str(year)] = stable_nse(obs_year, pred_year)
            methods[name] = {"full": full, "annual": annual}
            original = expected["methods"][name]
            for actual, stored in [(full, original["full"])] + [(annual[y], original["annual"][y]) for y in annual]:
                if actual is None or stored is None or abs(actual - stored) > 1e-12:
                    raise RuntimeError("Independent stable-sum efficiency disagrees with production summary")
            negatives[name] = {"count": sum(value < 0 for value in values), "minimum": min(values)}
            if name.startswith(("rain_", "historical_")):
                ledger_audits[name] = audit_rain_ledger(trajectory / "rain_versions.csv", fresh.dates,
                                                       fresh.weather[:, 0], expected_updates=3287,
                                                       expected_cap=selection["scaling"]["cap"],
                                                       missing_by_date=missing_by_date)
        reconstructed = {"basin": basin, "methods": methods, "coverage": coverage}
        beta = float(selection["beta"])
        if not 0 <= beta <= 1:
            raise RuntimeError("Yesterday-error coefficient escaped its fitting-only bounds")
        yesterday_error, persistence_maximum_difference = 0., 0.
        for day in expected_days:
            base = baseline_trajectories["base"][day]
            prediction = baseline_trajectories["persistence"][day]
            reference = base + beta * yesterday_error
            difference = abs(prediction - reference)
            if difference > 1e-5 * (1 + abs(reference)):
                raise RuntimeError("Yesterday-error trajectory does not reconstruct from prior arrived flow")
            persistence_maximum_difference = max(persistence_maximum_difference, difference)
            yesterday_error = observations_all[day] - base if math.isfinite(observations_all[day]) else 0.
        all_scores[basin] = reconstructed
        details[basin] = {"negatives": negatives, "rain_ledgers": ledger_audits,
                         "persistence_reconstruction_maximum_difference": persistence_maximum_difference,
                         "observations_sha256": sha256(directory / "score_observations.csv")}
    summary = summarize_eight(all_scores, tuple(contract.basins), contract.strata)
    return {"success": True, "global_lock_sha256": lock_digest, "summary": summary, "details": details,
            "method": "independent calendar reconstruction and math.fsum; production metrics were not called",
            "separate_context_review_pending": True}
