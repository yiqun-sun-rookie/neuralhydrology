"""Leave-one-out transfer test for the step-2 learned process noise.

Preregistration (frozen 2026-08-28, user-approved):
docs/plans/2026-08-28-noise-axis-transfer-loo-prereg-v01.md

Zero new search. The 52 winner rho vectors from step 2 are borrowed across basins:
only the dimensionless ratios travel; the receiver keeps its own frozen amplitudes and
the frozen G1 observation noise. The receiver's own rho never enters its candidates,
neither directly nor through the median.

Arms (all deterministic, no seeds):
    e1  per-group log-median of the 51 other winners ("median profile")
    e2  the single donor whose paired gain median over the OTHER receivers is best
        (leave-one-out selection; carries the three gates)
    oracle  best donor picked with hindsight on the receiver's holdout (upper bound only)
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from camels_switch_confirmation.noise_axis_learned_q import GROUP_NAMES

RHO_COLUMNS = tuple(f"rho_{name}" for name in GROUP_NAMES)

T1_MIN_WINS = 27
T2_GAIN_THRESHOLD = 0.01
T3_HEADROOM_THRESHOLD = 0.01503  # step-2 median cross-anchor IQR, copied verbatim
CRASH_CELL_LIMIT = 135           # 5% of 2,704 scheduled runs


def donor_rho_table(evaluation: pd.DataFrame) -> pd.DataFrame:
    """The 52 winner rho vectors, indexed by basin, columns ordered as GROUP_NAMES."""
    table = evaluation.set_index("basin_id")[list(RHO_COLUMNS)].astype(np.float64)
    if table.isna().any().any() or (table <= 0.0).any().any():
        raise ValueError("winner rho table must be finite and positive")
    return table.sort_index()


def median_arm_rho(donors: pd.DataFrame, receiver: str) -> np.ndarray:
    """e1: per-group log-median over the 51 donors, the receiver itself excluded."""
    others = donors.drop(index=receiver)
    if len(others) != len(donors) - 1:
        raise ValueError(f"receiver {receiver} not found in the donor table")
    return np.exp(np.median(np.log(others.to_numpy(dtype=np.float64)), axis=0))


def select_loo_donor(gain: pd.DataFrame, receiver: str) -> str:
    """e2 selection: argmax over donors j of median_k gain[j, k], k not in {receiver, j}.

    The receiver's own column never enters the selection (its holdout stays sealed until
    scoring). Ties break to the smallest basin id; NaN cells (diagonal, crashes) are
    dropped from the median.
    """
    best_donor, best_score = None, -np.inf
    for donor in sorted(gain.index):
        if donor == receiver:
            continue
        row = gain.loc[donor].drop(labels=[receiver, donor], errors="ignore")
        score = float(np.nanmedian(row.to_numpy(dtype=np.float64)))
        if score > best_score:
            best_donor, best_score = donor, score
    if best_donor is None:
        raise ValueError("no eligible donor")
    return best_donor


def oracle_donor(gain: pd.DataFrame, receiver: str) -> str:
    """Hindsight best donor on the receiver's own holdout. Upper bound only, never a score."""
    column = gain[receiver].drop(labels=[receiver], errors="ignore")
    return column.idxmax()


def settle_gates(e2_gains: pd.Series, oracle_gains: pd.Series) -> dict:
    """The three prelocked gates, all on the e2 arm (prereg section three)."""
    e2 = e2_gains.to_numpy(dtype=np.float64)
    oracle = oracle_gains.to_numpy(dtype=np.float64)
    e2_median = float(np.median(e2))
    oracle_median = float(np.median(oracle))
    wins = int(np.sum(e2 > 0.0))
    return {
        "e2_gain_median": e2_median,
        "e2_wins": wins,
        "oracle_gain_median": oracle_median,
        "headroom": oracle_median - e2_median,
        "gate_T1": bool(e2_median > 0.0 and wins >= T1_MIN_WINS),
        "gate_T2": bool(e2_median > T2_GAIN_THRESHOLD),
        "gate_T3": bool(oracle_median - e2_median > T3_HEADROOM_THRESHOLD),
    }
