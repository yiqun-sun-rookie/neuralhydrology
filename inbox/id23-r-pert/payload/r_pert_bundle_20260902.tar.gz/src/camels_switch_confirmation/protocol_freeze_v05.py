"""Fail-closed freezing and recoverable registration for the fifth version.

This module validates the pure draft, builds the approved frozen credential
and canonical formal configuration, and registers exactly one byte-appended
registry record.  It never imports basin-data loaders or an optimizer.
"""

from __future__ import annotations

import hashlib
import json
import re
import uuid
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from typing import Any, Mapping

from camels_switch_confirmation import protocol_freeze_v04
from scl_hydro.hbv_lite_numpy import (
    REAL_REGIME_V05_PAR_K2_LOWER,
    resolve_hbv_bounds,
)


ProtocolNotFrozenError = protocol_freeze_v04.ProtocolNotFrozenError

FROZEN_PROTOCOL_ID = "real_regime_parameter_k2_memory_v05"
FROZEN_PROTOCOL_SCOPE = "parameter_axis_development_v05"
FROZEN_APPROVED_AT = "2026-08-25T12:02:01+08:00"
FROZEN_APPROVAL_EVIDENCE = (
    "The user replied 'go' after the exact fifth-version single-factor contract "
    "was listed. This authorizes the non-draft principle, frozen credential, "
    "formal configuration, and one atomic registry row, but does not authorize "
    "the full 27-restart calibration execution."
)
V05_EXPERIMENT_ID = "real_regime_parameter_calibration_development_screen_v05"
V05_PARAMETER_BOUNDS_PRESET = "real_regime_k2_memory_v05"
V04_BASE_EXPERIMENT_ID = "real_regime_parameter_calibration_development_screen_v04"
V04_BASE_CONFIG_RELATIVE_PATH = (
    "src/camels_switch_confirmation/configs/"
    "real_regime_parameter_calibration_development_screen_v04.json"
)
V04_BASE_CONFIG_SHA256 = (
    "b68826537e78883cbc71bba3105eff21c693322a03e92027621bb1da7bdc6b72"
)
V05_CONFIG_RELATIVE_PATH = (
    "src/camels_switch_confirmation/configs/"
    "real_regime_parameter_calibration_development_screen_v05.json"
)
V05_PROTOCOL_RELATIVE_PATH = (
    "src/camels_switch_confirmation/protocols/"
    "real_regime_parameter_k2_memory_v05.freeze.json"
)
V05_HUMAN_PROTOCOL_DRAFT_RELATIVE_PATH = (
    "docs/plans/"
    "2026-08-24-real-regime-k2-lower-bound-principle-v05-draft.md"
)
V05_HUMAN_PROTOCOL_RELATIVE_PATH = (
    "docs/plans/"
    "2026-08-25-real-regime-k2-lower-bound-principle-v05.md"
)

V05_REGISTRY_HYPOTHESIS = (
    "An analytical one-year five-percent lower-zone memory bound can produce "
    "usable all-flow low-flow and high-flow fixed parameter candidates"
)
V05_REGISTRY_FIXED_FACTORS = (
    "basins; forcing; potential evapotranspiration; routing; warmup fit and "
    "validation periods; flow groups; optimization threshold; seeds; fit-only "
    "selection; restart stability; initialization and hydrograph response gates; "
    "boundary and cross-basin gates"
)
V05_REGISTRY_NOTES = (
    "Single-factor lower bound change for parK2 on exposed development basins only; "
    "registered but not run; no process-noise axis, joint axis, formal evaluation, "
    "online switching, parameter identification, or scientific claim is authorized."
)

FROZEN_CHANGED_FACTORS = ("parameter_domain.bounds.parK2[0]",)

_V05_BOUNDS = resolve_hbv_bounds(V05_PARAMETER_BOUNDS_PRESET)
V05_PARAMETER_DOMAIN = {
    "preset": V05_PARAMETER_BOUNDS_PRESET,
    "source": "fourth_version_domain_with_one_year_lower_zone_memory_limit",
    "bounds": {name: [lower, upper] for name, (lower, upper) in _V05_BOUNDS.items()},
    "one_year_memory": {
        "parameter": "parK2",
        "days": 365,
        "retained_fraction_formula": "(1 - parK2) ** days",
        "retained_fraction": 0.05,
        "lower_bound_formula": "1 - 0.05 ** (1 / 365)",
        "maximum_half_life_days": 84.45304780331165,
    },
    "post_run_expansion_allowed": False,
}

V05_INITIALIZATION_COMPATIBILITY = deepcopy(
    protocol_freeze_v04.V04_INITIALIZATION_COMPATIBILITY
)
V05_INITIALIZATION_COMPATIBILITY["analytical_memory"].update({
    "lower_bound": REAL_REGIME_V05_PAR_K2_LOWER,
    "worst_case_retained_fraction": (
        (1.0 - REAL_REGIME_V05_PAR_K2_LOWER)
        ** V05_INITIALIZATION_COMPATIBILITY["warmup_days"]
    ),
    "one_year_memory": {
        "days": 365,
        "retained_fraction_formula": "(1 - parK2) ** days",
        "retained_fraction_max": 0.05,
        "worst_case_retained_fraction": (
            (1.0 - REAL_REGIME_V05_PAR_K2_LOWER) ** 365
        ),
        "comparison_operator": "less_than_or_equal",
    },
})

V05_UNCHANGED_BASE_CONTRACT = {
    "rule": "all_fourth_version_fields_unchanged_except_listed_paths",
    "base_config_sha256": V04_BASE_CONFIG_SHA256,
    "scientific_changed_paths": list(FROZEN_CHANGED_FACTORS),
    "identity_binding_paths": [
        "experiment_id",
        "parameter_bounds_preset",
        "protocol_id",
        "protocol_scope",
        "protocol_credential",
        "protocol_credential_sha256",
    ],
    "derived_metadata_paths": [
        "initialization_compatibility.analytical_memory.lower_bound",
        "initialization_compatibility.analytical_memory.worst_case_retained_fraction",
        "initialization_compatibility.analytical_memory.one_year_memory",
    ],
}
V05_EVIDENCE_CONTRACT = deepcopy(protocol_freeze_v04.V04_EVIDENCE_CONTRACT)
V05_LIFECYCLE = deepcopy(protocol_freeze_v04.V04_LIFECYCLE)
V05_LIFECYCLE["execution_authorization"] = False
V05_INTERPRETATION_PERMISSIONS = deepcopy(
    protocol_freeze_v04.V04_INTERPRETATION_PERMISSIONS
)

V05_PROTOCOL_DRAFT = {
    "schema_version": 1,
    "protocol_id": FROZEN_PROTOCOL_ID,
    "protocol_status": "draft",
    "protocol_scope": FROZEN_PROTOCOL_SCOPE,
    "execution_authorization": False,
    "human_protocol_draft_path": V05_HUMAN_PROTOCOL_DRAFT_RELATIVE_PATH,
    "base_experiment_id": V04_BASE_EXPERIMENT_ID,
    "base_config_path": V04_BASE_CONFIG_RELATIVE_PATH,
    "base_config_sha256": V04_BASE_CONFIG_SHA256,
    "changed_factors": list(FROZEN_CHANGED_FACTORS),
    "parameter_domain": V05_PARAMETER_DOMAIN,
    "initialization_compatibility": V05_INITIALIZATION_COMPATIBILITY,
    "unchanged_base_contract": V05_UNCHANGED_BASE_CONTRACT,
    "evidence_contract": V05_EVIDENCE_CONTRACT,
    "lifecycle": V05_LIFECYCLE,
    "interpretation_permissions": V05_INTERPRETATION_PERMISSIONS,
}


def v05_protocol_draft() -> dict[str, Any]:
    """Return an isolated copy of the unapproved fifth-version contract."""

    return deepcopy(V05_PROTOCOL_DRAFT)


def _strict_copy(value: Any, label: str) -> Any:
    try:
        return json.loads(json.dumps(value, allow_nan=False))
    except (TypeError, ValueError) as error:
        raise ProtocolNotFrozenError(f"{label} is not finite JSON") from error


def validate_v05_protocol_contract(document: Mapping[str, Any]) -> dict[str, Any]:
    """Validate the exact pure draft contract without claiming approval."""

    if type(document) is not dict:
        raise ProtocolNotFrozenError("fifth-version protocol contract must be a plain object")
    try:
        protocol_freeze_v04._require_strict_tree(
            document,
            V05_PROTOCOL_DRAFT,
            "fifth-version protocol contract",
        )
    except ProtocolNotFrozenError as error:
        raise ProtocolNotFrozenError(
            f"fifth-version protocol contract differs from the single-factor draft: {error}"
        ) from error
    return _strict_copy(document, "fifth-version protocol contract")


def build_v05_frozen_protocol_document(repo_root: Path) -> dict[str, Any]:
    """Build the sole approved frozen credential from repository evidence."""

    root = Path(repo_root).resolve()
    protocol_freeze_v04._safe_repo_file(
        root,
        V04_BASE_CONFIG_RELATIVE_PATH,
        V04_BASE_CONFIG_SHA256,
        "fourth-version base configuration",
    )
    human_protocol = root / V05_HUMAN_PROTOCOL_RELATIVE_PATH
    if not human_protocol.is_file():
        raise ProtocolNotFrozenError(
            f"fifth-version human protocol is missing: {human_protocol}"
        )
    document = v05_protocol_draft()
    document["protocol_status"] = "frozen"
    document.pop("human_protocol_draft_path")
    document.update({
        "approved_at": FROZEN_APPROVED_AT,
        "approval_evidence": FROZEN_APPROVAL_EVIDENCE,
        "human_protocol_path": V05_HUMAN_PROTOCOL_RELATIVE_PATH,
        "human_protocol_sha256": protocol_freeze_v04._sha256(human_protocol),
    })
    return _strict_copy(document, "fifth-version frozen protocol credential")


def validate_v05_protocol_document(
    repo_root: Path,
    document: Mapping[str, Any],
) -> dict[str, Any]:
    """Validate the exact approved frozen credential."""

    if type(document) is not dict:
        raise ProtocolNotFrozenError("fifth-version protocol credential must be a plain object")
    if document.get("protocol_status") != "frozen":
        raise ProtocolNotFrozenError("fifth-version protocol credential is not frozen")
    try:
        approved = datetime.fromisoformat(str(document.get("approved_at", "")))
    except ValueError as error:
        raise ProtocolNotFrozenError("fifth-version approved_at must be ISO-8601") from error
    if approved.tzinfo is None or approved.utcoffset() is None:
        raise ProtocolNotFrozenError("fifth-version approved_at must include a timezone")
    expected = build_v05_frozen_protocol_document(repo_root)
    try:
        protocol_freeze_v04._require_strict_tree(
            document,
            expected,
            "fifth-version frozen protocol credential",
        )
    except ProtocolNotFrozenError as error:
        raise ProtocolNotFrozenError(
            f"fifth-version frozen credential differs from the approved contract: {error}"
        ) from error
    return _strict_copy(document, "fifth-version protocol credential")


def load_frozen_protocol(
    repo_root: Path,
    credential_path: Path,
    *,
    expected_sha256: str,
) -> dict[str, Any]:
    """Load strict JSON and bind it to the caller's exact file digest."""

    path = Path(credential_path).resolve()
    if (
        type(expected_sha256) is not str
        or re.fullmatch(r"[0-9a-f]{64}", expected_sha256) is None
        or not path.is_file()
        or protocol_freeze_v04._sha256(path) != expected_sha256
    ):
        raise ProtocolNotFrozenError(
            "fifth-version protocol credential hash differs from the configuration"
        )
    try:
        document = json.loads(
            path.read_text(encoding="utf-8"),
            parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)),
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
        raise ProtocolNotFrozenError(
            "fifth-version protocol credential is not strict finite JSON"
        ) from error
    return validate_v05_protocol_document(repo_root, document)


def validate_v05_registration_config(
    repo_root: Path,
    config: Mapping[str, Any],
) -> dict[str, Any]:
    """Require a frozen credential and the v04 config plus only v05 bindings."""

    if type(config) is not dict:
        raise ProtocolNotFrozenError("fifth-version configuration must be a plain object")
    required = {
        "protocol_id",
        "protocol_scope",
        "protocol_credential",
        "protocol_credential_sha256",
    }
    if not required.issubset(config):
        raise ProtocolNotFrozenError(
            "fifth-version configuration lacks frozen protocol binding"
        )
    if (
        config["protocol_id"] != FROZEN_PROTOCOL_ID
        or config["protocol_scope"] != FROZEN_PROTOCOL_SCOPE
    ):
        raise ProtocolNotFrozenError("fifth-version protocol identity differs")
    if type(config["protocol_credential"]) is not str:
        raise ProtocolNotFrozenError("fifth-version credential path must be a string")
    relative = Path(config["protocol_credential"])
    if (
        relative.is_absolute()
        or ".." in relative.parts
        or relative.as_posix() != V05_PROTOCOL_RELATIVE_PATH
    ):
        raise ProtocolNotFrozenError("fifth-version credential path is noncanonical")
    root = Path(repo_root).resolve()
    credential = load_frozen_protocol(
        root,
        root / relative,
        expected_sha256=config["protocol_credential_sha256"],
    )
    base_path = protocol_freeze_v04._safe_repo_file(
        root,
        credential["base_config_path"],
        V04_BASE_CONFIG_SHA256,
        "fourth-version base configuration",
    )
    base = protocol_freeze_v04._load_strict_json(
        base_path,
        "fourth-version base configuration",
    )
    expected = deepcopy(base)
    expected.update({
        "experiment_id": V05_EXPERIMENT_ID,
        "parameter_bounds_preset": V05_PARAMETER_BOUNDS_PRESET,
        "protocol_id": FROZEN_PROTOCOL_ID,
        "protocol_scope": FROZEN_PROTOCOL_SCOPE,
        "protocol_credential": V05_PROTOCOL_RELATIVE_PATH,
        "protocol_credential_sha256": config["protocol_credential_sha256"],
        "initialization_compatibility": V05_INITIALIZATION_COMPATIBILITY,
    })
    try:
        protocol_freeze_v04._require_strict_tree(
            config,
            expected,
            "fifth-version configuration",
        )
    except ProtocolNotFrozenError as error:
        raise ProtocolNotFrozenError(
            "fifth-version configuration differs outside the approved single-factor "
            f"contract: {error}"
        ) from error
    return credential


def build_v05_registration_config(
    repo_root: Path,
    *,
    protocol_credential_sha256: str,
) -> dict[str, Any]:
    """Derive the sole fifth-version formal configuration from the v04 base."""

    root = Path(repo_root).resolve()
    load_frozen_protocol(
        root,
        root / V05_PROTOCOL_RELATIVE_PATH,
        expected_sha256=protocol_credential_sha256,
    )
    base_path = protocol_freeze_v04._safe_repo_file(
        root,
        V04_BASE_CONFIG_RELATIVE_PATH,
        V04_BASE_CONFIG_SHA256,
        "fourth-version base configuration",
    )
    config = deepcopy(
        protocol_freeze_v04._load_strict_json(
            base_path,
            "fourth-version base configuration",
        )
    )
    config.update({
        "experiment_id": V05_EXPERIMENT_ID,
        "parameter_bounds_preset": V05_PARAMETER_BOUNDS_PRESET,
        "protocol_id": FROZEN_PROTOCOL_ID,
        "protocol_scope": FROZEN_PROTOCOL_SCOPE,
        "protocol_credential": V05_PROTOCOL_RELATIVE_PATH,
        "protocol_credential_sha256": protocol_credential_sha256,
        "initialization_compatibility": deepcopy(V05_INITIALIZATION_COMPATIBILITY),
    })
    validate_v05_registration_config(root, config)
    return _strict_copy(config, "fifth-version configuration")


def canonical_v05_config_payload(repo_root: Path, config: Mapping[str, Any]) -> bytes:
    """Return the sole canonical byte representation of a v05 configuration."""

    validate_v05_registration_config(repo_root, config)
    try:
        value = json.dumps(
            config,
            indent=2,
            sort_keys=True,
            ensure_ascii=False,
            allow_nan=False,
        ) + "\n"
    except (TypeError, ValueError) as error:
        raise ProtocolNotFrozenError(
            "fifth-version configuration is not finite JSON"
        ) from error
    return value.encode("utf-8")


def build_v05_registry_row(
    repo_root: Path,
    config: Mapping[str, Any],
    config_path: Path,
    *,
    updated_at: str | None = None,
) -> dict[str, str]:
    """Derive the complete registry row from the canonical v05 configuration."""

    root = Path(repo_root).resolve()
    validate_v05_registration_config(root, config)
    config_relative = protocol_freeze_v04._repo_relative(
        root,
        config_path,
        "configuration",
    )
    if config_relative != V05_CONFIG_RELATIVE_PATH:
        raise ProtocolNotFrozenError(
            f"configuration path must remain {V05_CONFIG_RELATIVE_PATH}"
        )
    manifest_relative = Path(str(config["basin_manifest"])).as_posix()
    manifest = root / manifest_relative
    if not manifest.is_file():
        raise ProtocolNotFrozenError("basin manifest is missing")
    output = root / str(config["results_root"]) / V05_EXPERIMENT_ID
    payload = canonical_v05_config_payload(root, config)
    timestamp = protocol_freeze_v04._validated_timestamp(
        datetime.now().astimezone().isoformat() if updated_at is None else updated_at
    )
    row = {
        "experiment_id": V05_EXPERIMENT_ID,
        "classification": "development_screen",
        "hypothesis": V05_REGISTRY_HYPOTHESIS,
        "config_path": config_relative,
        "config_sha256": hashlib.sha256(payload).hexdigest(),
        "basin_manifest": manifest_relative,
        "basin_manifest_sha256": protocol_freeze_v04._sha256(manifest),
        "changed_factor": ";".join(FROZEN_CHANGED_FACTORS),
        "fixed_factors": V05_REGISTRY_FIXED_FACTORS,
        "restart_seeds": ";".join(
            str(seed) for seed in config["optimizer"]["restart_seeds"]
        ),
        "status": "registered_not_run",
        "output_dir": protocol_freeze_v04._repo_relative(root, output, "output"),
        "metrics_path": "validation_metrics.csv",
        "paper_name": "development_only",
        "notes": V05_REGISTRY_NOTES,
        "updated_at": timestamp,
        "error": "",
    }
    return {
        column: row[column]
        for column in protocol_freeze_v04.V04_REGISTRY_COLUMNS
    }


def _validate_v05_registry_row(
    repo_root: Path,
    config: Mapping[str, Any],
    config_path: Path,
    row: Mapping[str, Any],
) -> dict[str, str]:
    columns = protocol_freeze_v04.V04_REGISTRY_COLUMNS
    if type(row) is not dict or set(row) != set(columns):
        raise ProtocolNotFrozenError("fifth-version registry row fields differ")
    for field, value in row.items():
        if type(value) is not str or "\r" in value or "\n" in value:
            raise ProtocolNotFrozenError(
                f"fifth-version registry row {field} must be a single-line string"
            )
    expected = build_v05_registry_row(
        repo_root,
        config,
        config_path,
        updated_at=protocol_freeze_v04._validated_timestamp(row["updated_at"]),
    )
    protocol_freeze_v04._require_strict_tree(
        dict(row),
        expected,
        "fifth-version registry row",
    )
    return expected


def register_frozen_protocol_atomically(
    repo_root: Path,
    config: Mapping[str, Any],
    config_path: Path,
    registry_path: Path,
    registry_row: Mapping[str, Any],
) -> str:
    """Register the canonical v05 config and one recoverable registry row."""

    root = Path(repo_root).resolve()
    payload = canonical_v05_config_payload(root, config)
    target_config = Path(config_path).absolute()
    registry = Path(registry_path).absolute()
    if (
        protocol_freeze_v04._repo_relative(
            root,
            target_config,
            "configuration",
        )
        != V05_CONFIG_RELATIVE_PATH
    ):
        raise ProtocolNotFrozenError("fifth-version configuration path is noncanonical")
    protocol_freeze_v04._repo_relative(root, registry, "registry")
    protocol_freeze_v04._require_regular(registry, "registry")
    declared_registry = root / str(config["experiment_registry"])
    if declared_registry.resolve() != registry.resolve():
        raise ProtocolNotFrozenError(
            "registry path differs from the fifth-version configuration"
        )
    row = _validate_v05_registry_row(
        root,
        config,
        target_config,
        registry_row,
    )
    output = root / row["output_dir"]
    incomplete = output.with_name(output.name + ".incomplete")

    with protocol_freeze_v04._exclusive_registry_registration_lock(registry) as handle:
        recovered = protocol_freeze_v04._recover_transaction(
            root,
            registry,
            handle,
            payload,
            row,
            expected_experiment_id=V05_EXPERIMENT_ID,
            expected_config_relative_path=V05_CONFIG_RELATIVE_PATH,
        )
        if recovered is not None and recovered["status"] == "committed":
            return hashlib.sha256(payload).hexdigest()
        before, rows, terminator = protocol_freeze_v04._parse_registry_exact(
            protocol_freeze_v04._read_locked_registry(handle)
        )
        protocol_freeze_v04._assert_absent(target_config, "configuration")
        if V05_EXPERIMENT_ID in {item["experiment_id"] for item in rows}:
            raise FileExistsError(
                f"experiment identifier already exists: {V05_EXPERIMENT_ID}"
            )
        if protocol_freeze_v04._lexists(output) or protocol_freeze_v04._lexists(
            incomplete
        ):
            raise FileExistsError("final or incomplete experiment output already exists")
        append = protocol_freeze_v04._registry_append_bytes(row, terminator)
        transaction_id = uuid.uuid4().hex
        paths = protocol_freeze_v04._transaction_paths(
            target_config,
            registry,
            transaction_id,
        )
        for path in paths.values():
            protocol_freeze_v04._repo_relative(
                root,
                path,
                "registration artifact",
            )
            protocol_freeze_v04._assert_absent(path, "registration artifact")
        document: dict[str, Any] = {
            "schema_version": 1,
            "transaction_id": transaction_id,
            "phase": "declared",
            "experiment_id": V05_EXPERIMENT_ID,
            "config_path": V05_CONFIG_RELATIVE_PATH,
            "registry_path": protocol_freeze_v04._repo_relative(
                root,
                registry,
                "registry",
            ),
            "config_stage_path": protocol_freeze_v04._repo_relative(
                root,
                paths["config_stage"],
                "config stage",
            ),
            "registry_stage_path": protocol_freeze_v04._repo_relative(
                root,
                paths["registry_stage"],
                "registry stage",
            ),
            "config_after": protocol_freeze_v04._byte_identity(payload),
            "registry_before": protocol_freeze_v04._byte_identity(before),
            "registry_append": {
                **protocol_freeze_v04._byte_identity(append),
                "csv_record_count": 1,
            },
            "registry_after": protocol_freeze_v04._byte_identity(before + append),
        }
        paths["config"] = target_config
        journal_written = False
        config_published = False
        try:
            protocol_freeze_v04._create_journal(paths["journal"], document)
            journal_written = True
            protocol_freeze_v04._write_durable(
                paths["config_stage"],
                payload,
                exclusive=True,
            )
            protocol_freeze_v04._write_durable(
                paths["registry_stage"],
                append,
                exclusive=True,
            )
            protocol_freeze_v04._set_journal_phase(
                paths["journal"],
                document,
                "prepared",
            )
            staged_config = protocol_freeze_v04._stage_bytes(
                paths["config_stage"],
                document["config_after"],
                "configuration",
            )
            staged_append = protocol_freeze_v04._stage_bytes(
                paths["registry_stage"],
                {
                    "size": document["registry_append"]["size"],
                    "sha256": document["registry_append"]["sha256"],
                },
                "registry",
            )
            protocol_freeze_v04._publish_config_payload_exclusive(
                staged_config,
                target_config,
                paths["config_install"],
            )
            config_published = True
            protocol_freeze_v04._set_journal_phase(
                paths["journal"],
                document,
                "config_visible",
            )
            protocol_freeze_v04._append_registry_suffix(
                handle,
                registry,
                before,
                staged_append,
            )
            protocol_freeze_v04._verify_after(
                protocol_freeze_v04._read_locked_registry(handle),
                document,
            )
            protocol_freeze_v04._set_journal_phase(
                paths["journal"],
                document,
                "committed",
            )
            protocol_freeze_v04._cleanup_registration_transaction(
                paths["journal"],
                paths,
            )
        except Exception:
            if not journal_written:
                raise
            if protocol_freeze_v04._rollback_transaction(
                registry,
                handle,
                document,
                paths,
                before,
                append,
                config_published=config_published,
            ):
                return document["config_after"]["sha256"]
            raise
    return hashlib.sha256(payload).hexdigest()
