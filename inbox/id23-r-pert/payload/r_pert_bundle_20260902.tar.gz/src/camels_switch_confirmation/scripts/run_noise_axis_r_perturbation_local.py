"""A0 parity arm and the 2-basin smoke run, on this machine only.

Preregistration: ``docs/plans/2026-09-01-noise-axis-r-perturbation-robustness-prereg-v01.md``
(sha256 ``c9773ba120960831d387c21a1168da9fb0f5e869b3ed801f648292c2232a2f5a``).

A0 (prereg 3.2) is the hard prerequisite for the whole line: R-old driven through the *new*
code path -- meaning ``r_source`` is supplied and the daily assigner really writes R every day
-- must reproduce the frozen stage-3 CTRL m1_c0 forecasts.  Gate: bitwise 0.0, or <= 1e-9 with
the NSE impact quantified.  This local run is same-platform implementation verification; the
run on the cluster is the registered G0 and must precede every production arm.

The smoke run (prereg section 5, change 0.11) exercises A1/A1m over the full window and A2
over a single anchor on 2 basins, purely to measure peak memory and wall clock.  Its products
land under ``smoke/`` and enter no gate.

Usage (from the repository root):
    python src/camels_switch_confirmation/scripts/run_noise_axis_r_perturbation_local.py --mode a0
    python src/camels_switch_confirmation/scripts/run_noise_axis_r_perturbation_local.py --mode smoke
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

_SRC = Path(__file__).resolve().parents[2]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation import noise_axis_learned_q as learned_q  # noqa: E402
from camels_switch_confirmation.noise_axis_filtering import (  # noqa: E402
    LegacyGridNoise,
    assert_single_member_posterior_exact,
    load_stage3_control_task,
    run_noise_axis_filter,
)
from camels_switch_confirmation.noise_axis_r_perturbation import (  # noqa: E402
    calibration_diagnostic,
    make_r_source,
)
from camels_switch_confirmation.run_online_noise_pilot import RESULTS  # noqa: E402
from camels_switch_confirmation.run_online_noise_real_obs import OUTPUT_ROOT as STAGE3_ROOT  # noqa: E402

PREREG_SHA256 = "c9773ba120960831d387c21a1168da9fb0f5e869b3ed801f648292c2232a2f5a"
CONTROL_CELL = LegacyGridNoise(m=1.0, c=0.0)
CONTROL_DIR = STAGE3_ROOT / "grid" / "CTRL" / CONTROL_CELL.cell_tag / "probs"
OUTPUT_DIR = RESULTS / "noise_axis_r_perturbation_20260902_local"

GATE_BITWISE = 0.0
GATE_DEGRADED = 1e-9
SMOKE_BASINS = ("01144000", "01435000")
SMOKE_ANCHOR_INDEX = 0


# ---------------------------------------------------------------------------
# resource reporting (user standing rule: report memory and wall clock, unasked)
# ---------------------------------------------------------------------------

def _memory_snapshot() -> dict:
    import psutil

    process = psutil.Process()
    info = process.memory_info()
    virtual = psutil.virtual_memory()
    return {
        "process_rss_gib": info.rss / 2**30,
        "process_peak_gib": getattr(info, "peak_wset", info.rss) / 2**30,
        "system_used_gib": virtual.used / 2**30,
        "system_available_gib": virtual.available / 2**30,
        "system_total_gib": virtual.total / 2**30,
    }


def _print_memory(tag: str, snapshot: dict) -> None:
    print(
        f"[{tag}] process peak {snapshot['process_peak_gib']:.3f} GiB "
        f"(rss {snapshot['process_rss_gib']:.3f}) | system used "
        f"{snapshot['system_used_gib']:.1f} / {snapshot['system_total_gib']:.1f} GiB, "
        f"available {snapshot['system_available_gib']:.1f} GiB"
    )


# ---------------------------------------------------------------------------
# A0
# ---------------------------------------------------------------------------

def admitted_basins() -> list[str]:
    path = STAGE3_ROOT / "precheck" / "admission.csv"
    frame = pd.read_csv(path, dtype={"basin_id": str})
    basins = sorted(frame["basin_id"].str.zfill(8))
    control = sorted(p.stem for p in CONTROL_DIR.glob("*.npz"))
    if basins != control:
        raise ValueError(
            f"admitted basins and frozen control products disagree: "
            f"{len(basins)} admitted vs {len(control)} control npz"
        )
    return basins


def _frozen_forecast(basin: str) -> np.ndarray:
    with np.load(CONTROL_DIR / f"{basin}.npz", allow_pickle=False) as archive:
        return archive["one_step_forecast"].copy()


def _nse(forecast: np.ndarray, observed: np.ndarray) -> float:
    denominator = float(np.sum(np.square(observed - observed.mean())))
    return 1.0 - float(np.sum(np.square(forecast - observed))) / denominator


def a0_one_basin(basin: str) -> dict:
    """R-old through the new daily-R path, compared bit for bit with the frozen control."""
    task = load_stage3_control_task(basin)
    result = run_noise_axis_filter(task, basin, CONTROL_CELL, make_r_source("R-old"))
    posterior_deviation = assert_single_member_posterior_exact(result["posterior_probabilities"])

    forecast = result["one_step_forecast"]
    observed = result["observations"]
    reference = _frozen_forecast(basin)
    difference = np.abs(forecast - reference)
    max_diff = float(np.max(difference))

    diagnostic = calibration_diagnostic(
        forecast,
        observed,
        result["forecast_variance"],
        result["sigma_obs"],
        result["observation_variance"],
        burn_in=learned_q.BURN_IN_DAYS,
    )
    record = {
        "basin_id": basin,
        "n_days": int(len(forecast)),
        "max_abs_forecast_diff": max_diff,
        "n_days_bitwise_identical": int(np.count_nonzero(difference == 0.0)),
        "posterior_max_deviation": posterior_deviation,
        "sigma_obs": result["sigma_obs"],
        "nse_new_path": _nse(forecast, observed),
        "nse_frozen": _nse(reference, observed),
        "filter_seconds": result["filter_seconds"],
        "passes_bitwise": bool(max_diff == GATE_BITWISE),
        "passes_degraded": bool(max_diff <= GATE_DEGRADED),
    }
    record["nse_abs_diff"] = abs(record["nse_new_path"] - record["nse_frozen"])
    record.update(diagnostic)
    return record


def run_a0() -> int:
    basins = admitted_basins()
    print(
        f"A0 parity: {len(basins)} basins, R-old through the daily-R path, "
        f"gate bitwise 0.0 (degraded <= {GATE_DEGRADED:.0e})"
    )
    before = _memory_snapshot()
    _print_memory("before", before)

    records = []
    wall_start = time.perf_counter()
    for position, basin in enumerate(basins, start=1):
        record = a0_one_basin(basin)
        records.append(record)
        print(
            f"  [{position:2d}/{len(basins)}] {basin}  max|diff|={record['max_abs_forecast_diff']:.3e}  "
            f"z2_mean={record['z2_mean']:.1f}  filter={record['filter_seconds']:.2f}s  "
            f"{'BITWISE' if record['passes_bitwise'] else ('DEGRADED' if record['passes_degraded'] else 'FAIL')}"
        )
    wall_seconds = time.perf_counter() - wall_start
    after = _memory_snapshot()
    _print_memory("after", after)

    frame = pd.DataFrame(records)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    frame.to_csv(OUTPUT_DIR / "a0_parity_per_basin.csv", index=False)

    n_bitwise = int(frame["passes_bitwise"].sum())
    n_degraded = int(frame["passes_degraded"].sum())
    verdict = (
        "PASS_BITWISE" if n_bitwise == len(frame)
        else "PASS_DEGRADED" if n_degraded == len(frame)
        else "FAIL"
    )
    summary = {
        "arm": "A0",
        "preregistration_sha256": PREREG_SHA256,
        "platform": "local_windows",
        "note": "same-platform implementation verification; the cluster run is the registered G0",
        "n_basins": len(frame),
        "max_abs_forecast_diff_over_all_basins": float(frame["max_abs_forecast_diff"].max()),
        "n_basins_bitwise": n_bitwise,
        "n_basins_within_degraded_gate": n_degraded,
        "max_nse_abs_diff": float(frame["nse_abs_diff"].max()),
        "verdict": verdict,
        "failing_basins": frame.loc[~frame["passes_degraded"], "basin_id"].tolist(),
        "calibration_r_old_direct": {
            "z2_mean_median_over_basins": float(frame["z2_mean"].median()),
            "z2_median_median_over_basins": float(frame["z2_median"].median()),
            "n_basins_z2_mean_above_one": int((frame["z2_mean"] > 1.0).sum()),
            "z2_mean_median_low": float(frame["z2_mean_low"].median()),
            "z2_mean_median_mid": float(frame["z2_mean_mid"].median()),
            "z2_mean_median_high": float(frame["z2_mean_high"].median()),
            "abs_error_median_over_sigma_median": float(
                frame["abs_error_median_over_sigma"].median()
            ),
            "burn_in_days_excluded": learned_q.BURN_IN_DAYS,
        },
        "timing": {
            "filter_seconds_median": float(frame["filter_seconds"].median()),
            "filter_seconds_total": float(frame["filter_seconds"].sum()),
            "wall_seconds": wall_seconds,
        },
        "memory": {"before": before, "after": after},
    }
    (OUTPUT_DIR / "a0_parity_summary.json").write_text(
        json.dumps(summary, indent=1), encoding="utf-8"
    )
    print(f"\nA0 verdict: {verdict}  wall {wall_seconds / 60.0:.1f} min")
    print(f"  written: {OUTPUT_DIR / 'a0_parity_summary.json'}")
    return 0 if verdict != "FAIL" else 1


# ---------------------------------------------------------------------------
# smoke
# ---------------------------------------------------------------------------

def run_smoke() -> int:
    smoke_dir = OUTPUT_DIR / "smoke"
    print(
        f"smoke: {len(SMOKE_BASINS)} basins; A1/A1m full window, A2 anchor "
        f"{SMOKE_ANCHOR_INDEX} only.  Products enter no gate."
    )
    before = _memory_snapshot()
    _print_memory("before", before)

    records = []
    wall_start = time.perf_counter()
    for basin in SMOKE_BASINS:
        task = load_stage3_control_task(basin)
        amplitudes = learned_q.training_amplitudes(learned_q.open_loop_states(task, basin))

        for variant in ("R-shape", "R-mag"):
            r_source = make_r_source(variant)
            start = time.perf_counter()
            result = run_noise_axis_filter(task, basin, CONTROL_CELL, r_source)
            elapsed = time.perf_counter() - start
            forecast = result["one_step_forecast"]
            observed = result["observations"]
            diagnostic = calibration_diagnostic(
                forecast,
                observed,
                result["forecast_variance"],
                result["sigma_obs"],
                result["observation_variance"],
                burn_in=learned_q.BURN_IN_DAYS,
            )
            record = {
                "basin_id": basin,
                "arm": "A1" if variant == "R-shape" else "A1m",
                "r_variant": variant,
                "nse_holdout": learned_q.nse(
                    forecast[learned_q.TRAIN_DAYS:], observed[learned_q.TRAIN_DAYS:]
                ),
                "seconds": elapsed,
            }
            record.update(diagnostic)
            records.append(record)
            print(
                f"  {basin} {record['arm']:>3} ({variant})  NSE_holdout={record['nse_holdout']:.4f}  "
                f"z2_mean={record['z2_mean']:.1f}  floor_share={record['floor_share']:.2f}  {elapsed:.1f}s"
            )

        anchor_name, anchor_rho = learned_q.anchor_table()[SMOKE_ANCHOR_INDEX]
        start = time.perf_counter()
        anchor = learned_q.search_one_anchor(
            task, basin, amplitudes, SMOKE_ANCHOR_INDEX, anchor_rho, make_r_source("R-shape")
        )
        elapsed = time.perf_counter() - start
        records.append({
            "basin_id": basin,
            "arm": "A2_smoke",
            "r_variant": "R-shape",
            "anchor_name": anchor_name,
            "best_objective": anchor["best_objective"],
            "n_evaluations": anchor["n_evaluations"],
            "n_crashes": len(anchor["crashes"]),
            "seconds": elapsed,
        })
        print(
            f"  {basin} A2  anchor={anchor_name}  evals={anchor['n_evaluations']}  "
            f"crashes={len(anchor['crashes'])}  {elapsed / 60.0:.1f} min"
        )

    wall_seconds = time.perf_counter() - wall_start
    after = _memory_snapshot()
    _print_memory("after", after)

    smoke_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(records).to_csv(smoke_dir / "smoke_per_run.csv", index=False)
    a2_rows = [r for r in records if r["arm"] == "A2_smoke"]
    summary = {
        "arm": "smoke",
        "preregistration_sha256": PREREG_SHA256,
        "enters_gates": False,
        "basins": list(SMOKE_BASINS),
        "wall_seconds": wall_seconds,
        "a2_seconds_per_anchor_median": float(np.median([r["seconds"] for r in a2_rows])),
        "a2_projected_seconds_per_basin_8_anchors": float(
            np.median([r["seconds"] for r in a2_rows]) * learned_q.ANCHOR_COUNT
        ),
        "memory": {"before": before, "after": after},
    }
    (smoke_dir / "smoke_summary.json").write_text(json.dumps(summary, indent=1), encoding="utf-8")
    print(f"\nsmoke wall {wall_seconds / 60.0:.1f} min; written: {smoke_dir / 'smoke_summary.json'}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("a0", "smoke"), required=True)
    arguments = parser.parse_args()
    return run_a0() if arguments.mode == "a0" else run_smoke()


if __name__ == "__main__":
    raise SystemExit(main())
