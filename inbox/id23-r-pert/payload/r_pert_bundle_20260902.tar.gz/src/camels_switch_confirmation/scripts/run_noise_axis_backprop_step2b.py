"""Runner for noise-axis step 2B: backprop rerun of per-basin grouped-noise learning.

Preregistration: docs/plans/2026-08-28-noise-axis-backprop-step2b-prereg-v01.md

Phases (run from the repository root, by path, cwd = repo root):
    python src/camels_switch_confirmation/scripts/run_noise_axis_backprop_step2b.py parity
    python src/camels_switch_confirmation/scripts/run_noise_axis_backprop_step2b.py smoke
    python src/camels_switch_confirmation/scripts/run_noise_axis_backprop_step2b.py search --n-iter N
    python src/camels_switch_confirmation/scripts/run_noise_axis_backprop_step2b.py evaluate

Frozen upstream inputs are sha256-verified before any phase touches them. All official
scores come from the frozen numpy filter; torch only proposes candidates (prereg 3.1).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd

_SRC = Path(__file__).resolve().parents[2]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

RESULTS = Path(r"G:\wt\camels-rising\results\23_camels_switch_confirmation")
STEP2_ROOT = RESULTS / "noise_axis_step2_learned_q_20260827_local"
TRANSFER_ROOT = RESULTS / "noise_axis_transfer_loo_20260828_local"
OUTPUT_ROOT = RESULTS / "noise_axis_backprop_step2b_20260828_local"

FROZEN_INPUT_SHA256 = {
    STEP2_ROOT / "amplitudes_frozen.csv":
        "5be4aa3c8f5e20dfb5a83edc50d49884818e22732c2f9fddc9c84e018995b434",
    STEP2_ROOT / "evaluation_per_basin.csv":
        "b747f69ac4c41d13927aa4814525168c07a30d665f93085ff06032d823c611e1",
    STEP2_ROOT / "baselines_per_basin.csv":
        "68ea45fbdb2fc696ee337c9e2238b5da1473d2562fe321d589f72fb2c22b7619",
    TRANSFER_ROOT / "transfer_per_basin.csv":
        "dd05744fe2d7043242be39deac608cbca9d58c6c13d808536f025e35fe78a8fc",
}

PARITY_BASINS = ("01144000", "11451100", "14316700")
PARITY_SETTINGS = ("uniform", "large_q", "cma_winner")
PARITY_PASS = 1e-6
PARITY_DEGRADED = 1e-3
SMOKE_BASIN = "01144000"
DEFAULT_WORKERS = 6
TORCH_THREADS_PER_WORKER = 2

B1_THRESHOLD = 0.005
B2_MEDIAN_THRESHOLD = 0.01
B2_WINS_THRESHOLD = 27


def _verify_frozen_inputs() -> None:
    for path, expected in FROZEN_INPUT_SHA256.items():
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != expected:
            raise RuntimeError(f"frozen input hash mismatch for {path}: {digest}")


def _frozen_tables() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    _verify_frozen_inputs()
    amplitudes = pd.read_csv(STEP2_ROOT / "amplitudes_frozen.csv", dtype={"basin_id": str})
    evaluation = pd.read_csv(STEP2_ROOT / "evaluation_per_basin.csv", dtype={"basin_id": str})
    baselines = pd.read_csv(STEP2_ROOT / "baselines_per_basin.csv", dtype={"basin_id": str})
    transfer = pd.read_csv(TRANSFER_ROOT / "transfer_per_basin.csv", dtype={"basin_id": str})
    for frame in (amplitudes, evaluation, baselines, transfer):
        frame.set_index("basin_id", inplace=True)
    return amplitudes, evaluation, baselines, transfer


def _basin_amplitudes(amplitudes: pd.DataFrame, basin: str) -> np.ndarray:
    from camels_switch_confirmation.noise_axis_learned_q import GROUP_NAMES

    return amplitudes.loc[basin, [f"A_{name}" for name in GROUP_NAMES]].to_numpy(np.float64)


def _cma_winner_rho(evaluation: pd.DataFrame, basin: str) -> np.ndarray:
    from camels_switch_confirmation.noise_axis_learned_q import GROUP_NAMES

    return evaluation.loc[basin, [f"rho_{name}" for name in GROUP_NAMES]].to_numpy(np.float64)


def _load_bundle(basin: str):
    from camels_switch_confirmation.noise_axis_backprop import BasinBundle

    amplitudes, _, _, _ = _frozen_tables()
    return BasinBundle.load(basin, _basin_amplitudes(amplitudes, basin))


def _numpy_forecasts(bundle, rho: np.ndarray) -> np.ndarray:
    from camels_switch_confirmation.noise_axis_filtering import run_noise_axis_filter
    from camels_switch_confirmation.noise_axis_learned_q import GroupedProcessNoise

    noise = GroupedProcessNoise(tuple(np.asarray(rho, np.float64)), tuple(bundle.amplitudes))
    return run_noise_axis_filter(bundle.task, bundle.basin_id, noise)["one_step_forecast"]


def _parity_setting_rho(setting: str, evaluation: pd.DataFrame, basin: str) -> np.ndarray:
    from camels_switch_confirmation.noise_axis_learned_q import anchor_table

    if setting == "cma_winner":
        return _cma_winner_rho(evaluation, basin)
    for name, rho in anchor_table():
        if name == setting:
            return rho
    raise ValueError(f"unknown parity setting {setting}")


def phase_parity() -> None:
    from camels_switch_confirmation.noise_axis_backprop import run_filter_torch_full
    from camels_switch_confirmation.noise_axis_learned_q import (
        TRAIN_DAYS, WINDOW_DAYS, nse,
    )

    _, evaluation, _, _ = _frozen_tables()
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    records = []
    worst = 0.0
    for basin in PARITY_BASINS:
        bundle = _load_bundle(basin)
        observed = np.asarray(bundle.task["obs"], np.float64)
        for setting in PARITY_SETTINGS:
            rho = _parity_setting_rho(setting, evaluation, basin)
            start = time.perf_counter()
            torch_forecast = run_filter_torch_full(bundle, rho, WINDOW_DAYS)
            torch_seconds = time.perf_counter() - start
            start = time.perf_counter()
            numpy_forecast = _numpy_forecasts(bundle, rho)
            numpy_seconds = time.perf_counter() - start
            max_abs = float(np.max(np.abs(torch_forecast - numpy_forecast)))
            worst = max(worst, max_abs)
            record = {
                "basin_id": basin,
                "setting": setting,
                "max_abs_forecast_diff": max_abs,
                "nse_holdout_torch": nse(torch_forecast[TRAIN_DAYS:], observed[TRAIN_DAYS:]),
                "nse_holdout_numpy": nse(numpy_forecast[TRAIN_DAYS:], observed[TRAIN_DAYS:]),
                "torch_seconds": torch_seconds,
                "numpy_seconds": numpy_seconds,
            }
            records.append(record)
            print(f"parity {basin} {setting}: max|diff|={max_abs:.3e} "
                  f"torch={torch_seconds:.1f}s numpy={numpy_seconds:.1f}s", flush=True)
    if worst <= PARITY_PASS:
        verdict = "PASS_same_filter"
    elif worst <= PARITY_DEGRADED:
        verdict = "DEGRADED_surrogate_filter"
    else:
        verdict = "FAIL_stop"
    payload = {"records": records, "worst_max_abs_diff": worst, "verdict": verdict,
               "thresholds": {"pass": PARITY_PASS, "degraded": PARITY_DEGRADED}}
    (OUTPUT_ROOT / "parity.json").write_text(json.dumps(payload, indent=1))
    print(f"parity verdict: {verdict} (worst {worst:.3e})")
    if verdict == "FAIL_stop":
        raise SystemExit(2)


def phase_smoke(n_iter: int) -> None:
    from camels_switch_confirmation.noise_axis_backprop import (
        numpy_training_objective, train_basin,
    )

    _, evaluation, _, _ = _frozen_tables()
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    bundle = _load_bundle(SMOKE_BASIN)
    start = time.perf_counter()
    record = train_basin(bundle, _cma_winner_rho(evaluation, SMOKE_BASIN), n_iter=n_iter)
    wall = time.perf_counter() - start
    per_iter = wall / (n_iter + 1)
    start = time.perf_counter()
    numpy_training_objective(bundle, _cma_winner_rho(evaluation, SMOKE_BASIN))
    numpy_objective_seconds = time.perf_counter() - start
    payload = {
        "basin_id": SMOKE_BASIN,
        "n_iter": n_iter,
        "wall_seconds": wall,
        "seconds_per_iteration": per_iter,
        "numpy_objective_seconds": numpy_objective_seconds,
        "projected_hours_per_basin": {
            str(candidate): candidate * per_iter / 3600.0 for candidate in (80, 120, 160, 200)
        },
        "best_torch_losses": {r.name: r.best_torch_loss for r in record["starts"]},
    }
    try:
        import psutil

        payload["process_peak_rss_gb"] = psutil.Process().memory_info().rss / 1024**3
        payload["available_ram_gb"] = psutil.virtual_memory().available / 1024**3
    except ImportError:
        pass
    (OUTPUT_ROOT / "smoke.json").write_text(json.dumps(payload, indent=1))
    print(json.dumps(payload, indent=1))


def _search_one(args) -> str:
    basin, n_iter = args
    import torch

    torch.set_num_threads(TORCH_THREADS_PER_WORKER)
    from camels_switch_confirmation.noise_axis_backprop import train_basin

    out_path = OUTPUT_ROOT / "search" / f"{basin}.json"
    if out_path.exists():
        return f"{basin}: skipped (exists)"
    _, evaluation, _, _ = _frozen_tables()
    bundle = _load_bundle(basin)
    record = train_basin(bundle, _cma_winner_rho(evaluation, basin), n_iter=n_iter)
    payload = {
        "basin_id": record["basin_id"],
        "n_iter": record["n_iter"],
        "lr": record["lr"],
        "chunk_days": record["chunk_days"],
        "wall_seconds": record["wall_seconds"],
        "starts": [
            {
                "name": r.name,
                "start_rho": r.start_rho.tolist(),
                "best_log_rho": r.best_log_rho.tolist(),
                "best_torch_loss": r.best_torch_loss,
                "dead": r.dead,
                "loss_curve": r.loss_curve,
            }
            for r in record["starts"]
        ],
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = out_path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, indent=1))
    tmp.replace(out_path)
    return f"{basin}: done in {record['wall_seconds']:.0f}s"


def phase_search(n_iter: int, workers: int) -> None:
    _, evaluation, _, _ = _frozen_tables()
    basins = list(evaluation.index)
    (OUTPUT_ROOT / "search").mkdir(parents=True, exist_ok=True)
    tasks = [(basin, n_iter) for basin in basins]
    done = 0
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for message in pool.map(_search_one, tasks):
            done += 1
            print(f"[{done}/{len(tasks)}] {message}", flush=True)


def _evaluate_one(basin: str) -> dict:
    import torch

    torch.set_num_threads(TORCH_THREADS_PER_WORKER)
    from camels_switch_confirmation.noise_axis_backprop import (
        numpy_full_evaluation,
        numpy_training_objective,
        outer_5pct_count,
        select_winner,
        training_nse_from_mse,
    )

    search = json.loads((OUTPUT_ROOT / "search" / f"{basin}.json").read_text())
    _, evaluation, baselines, transfer = _frozen_tables()
    bundle = _load_bundle(basin)
    observations = np.asarray(bundle.task["obs"], np.float64)

    candidate_names = [entry["name"] for entry in search["starts"]]
    candidate_rhos = [np.exp(np.asarray(entry["best_log_rho"], np.float64))
                      for entry in search["starts"]]
    objectives = np.array(
        [numpy_training_objective(bundle, rho) for rho in candidate_rhos], dtype=np.float64
    )
    winner_index = select_winner(objectives)
    winner_rho = candidate_rhos[winner_index]
    winner_eval = numpy_full_evaluation(bundle, winner_rho)

    cma_rho = _cma_winner_rho(evaluation, basin)
    cma_objective = numpy_training_objective(bundle, cma_rho)

    train_nse_bp = training_nse_from_mse(float(objectives[winner_index]), observations)
    train_nse_cma = training_nse_from_mse(float(cma_objective), observations)
    registered_train_cma = float(
        baselines.loc[basin, "m1c0_nse_train_after_burnin"] + evaluation.loc[basin, "gain_train"]
    )
    if abs(train_nse_cma - registered_train_cma) > 1e-6:
        raise RuntimeError(
            f"basin {basin}: recomputed CMA train NSE {train_nse_cma!r} does not match "
            f"registered {registered_train_cma!r}"
        )

    anchor_objectives = objectives[:8]  # dispersion diagnostic across the 8 frozen anchors
    finite_anchor = anchor_objectives[np.isfinite(anchor_objectives)]
    if len(finite_anchor) >= 2:
        q75, q25 = np.percentile(finite_anchor, [75, 25])
        objective_relative_iqr = float((q75 - q25) / np.median(finite_anchor))
    else:
        objective_relative_iqr = float("nan")

    return {
        "basin_id": basin,
        "winner_start": candidate_names[winner_index],
        "winner_rho": winner_rho.tolist(),
        "objective_bp": float(objectives[winner_index]),
        "objective_cma": float(cma_objective),
        "train_nse_bp": train_nse_bp,
        "train_nse_cma": train_nse_cma,
        "dtrain_nse_bp_minus_cma": train_nse_bp - train_nse_cma,
        "nse_holdout_bp": winner_eval["nse_holdout"],
        "nse_holdout_cma": float(evaluation.loc[basin, "nse_holdout_learned"]),
        "nse_holdout_e2_borrowed": float(transfer.loc[basin, "e2_nse"]),
        "nse_holdout_m1c0": float(baselines.loc[basin, "m1c0_nse_holdout"]),
        "nse_full_bp": winner_eval["nse_full"],
        "nse_train_after_burnin_bp": winner_eval["nse_train_after_burnin"],
        "gain_bp_vs_m1c0": winner_eval["nse_holdout"] - float(baselines.loc[basin, "m1c0_nse_holdout"]),
        "dholdout_bp_minus_cma": winner_eval["nse_holdout"]
        - float(evaluation.loc[basin, "nse_holdout_learned"]),
        "dholdout_bp_minus_e2": winner_eval["nse_holdout"] - float(transfer.loc[basin, "e2_nse"]),
        "outer_5pct_winner": outer_5pct_count(np.log(winner_rho)),
        "objective_relative_iqr_anchors": objective_relative_iqr,
        "n_dead_starts": int(sum(1 for entry in search["starts"] if entry["dead"])),
        "winner_is_polish": candidate_names[winner_index] == "cma_polish",
        "objectives_all_starts": {n: float(o) for n, o in zip(candidate_names, objectives)},
    }


def phase_evaluate(workers: int) -> None:
    _, evaluation, _, _ = _frozen_tables()
    basins = list(evaluation.index)
    missing = [b for b in basins if not (OUTPUT_ROOT / "search" / f"{b}.json").exists()]
    if missing:
        raise RuntimeError(f"search results missing for {len(missing)} basins: {missing[:5]} ...")
    with ProcessPoolExecutor(max_workers=workers) as pool:
        rows = list(pool.map(_evaluate_one, basins))
    frame = pd.DataFrame(rows).set_index("basin_id").loc[basins]
    csv_frame = frame.drop(columns=["objectives_all_starts", "winner_rho"]).copy()
    for group_index, name in enumerate(
        ("SNOWPACK", "MELTWATER", "SM", "SUZ", "SLZ", "ROUTING")
    ):
        csv_frame[f"rho_{name}"] = [row[group_index] for row in frame["winner_rho"]]
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    csv_frame.to_csv(OUTPUT_ROOT / "evaluation_per_basin.csv")

    dtrain = frame["dtrain_nse_bp_minus_cma"].to_numpy(np.float64)
    d_cma = frame["dholdout_bp_minus_cma"].to_numpy(np.float64)
    d_e2 = frame["dholdout_bp_minus_e2"].to_numpy(np.float64)
    gain_m1c0 = frame["gain_bp_vs_m1c0"].to_numpy(np.float64)

    def gate_b2(diffs: np.ndarray) -> dict:
        return {
            "median": float(np.median(diffs)),
            "wins": int(np.sum(diffs > 0.0)),
            "passed": bool(
                np.median(diffs) > B2_MEDIAN_THRESHOLD and np.sum(diffs > 0.0) >= B2_WINS_THRESHOLD
            ),
        }

    b1_median = float(np.median(dtrain))
    summary = {
        "preregistration": "docs/plans/2026-08-28-noise-axis-backprop-step2b-prereg-v01.md",
        "n_basins": len(frame),
        "gate_B1": {
            "median_dtrain_nse": b1_median,
            "wins": int(np.sum(dtrain > 0.0)),
            "classification": (
                "search_left_headroom" if b1_median > B1_THRESHOLD else "search_was_adequate"
            ),
            "threshold": B1_THRESHOLD,
        },
        "gate_B2a_bp_vs_cma_own": gate_b2(d_cma),
        "gate_B2b_bp_vs_e2_borrowed": gate_b2(d_e2),
        "bp_vs_m1c0": {
            "median_gain": float(np.median(gain_m1c0)),
            "wins": int(np.sum(gain_m1c0 > 0.0)),
            "median_nse_holdout_bp": float(np.median(frame["nse_holdout_bp"])),
        },
        "reference_medians": {
            "m1c0": float(np.median(frame["nse_holdout_m1c0"])),
            "cma_own": float(np.median(frame["nse_holdout_cma"])),
            "e2_borrowed": float(np.median(frame["nse_holdout_e2_borrowed"])),
        },
        "diagnostics": {
            "winner_start_counts": frame["winner_start"].value_counts().to_dict(),
            "winner_is_polish_count": int(frame["winner_is_polish"].sum()),
            "median_objective_relative_iqr_anchors": float(
                np.nanmedian(frame["objective_relative_iqr_anchors"])
            ),
            "max_objective_relative_iqr_anchors": float(
                np.nanmax(frame["objective_relative_iqr_anchors"])
            ),
            "outer_5pct_total": int(frame["outer_5pct_winner"].sum()),
            "basins_with_dead_starts": int((frame["n_dead_starts"] > 0).sum()),
            "case_basins": {
                basin: {
                    "dtrain": float(frame.loc[basin, "dtrain_nse_bp_minus_cma"]),
                    "dholdout_vs_cma": float(frame.loc[basin, "dholdout_bp_minus_cma"]),
                    "gain_vs_m1c0": float(frame.loc[basin, "gain_bp_vs_m1c0"]),
                    "winner_start": str(frame.loc[basin, "winner_start"]),
                }
                for basin in ("11451100", "11522500", "11482500")
            },
        },
    }
    (OUTPUT_ROOT / "summary.json").write_text(json.dumps(summary, indent=1))
    print(json.dumps(summary, indent=1))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("parity", "smoke", "search", "evaluate"))
    parser.add_argument("--n-iter", type=int, default=None)
    parser.add_argument("--workers", type=int, default=DEFAULT_WORKERS)
    args = parser.parse_args()
    if args.phase == "parity":
        phase_parity()
    elif args.phase == "smoke":
        phase_smoke(args.n_iter if args.n_iter is not None else 20)
    elif args.phase == "search":
        if args.n_iter is None:
            raise SystemExit("search requires --n-iter (the frozen budget from the prereg)")
        phase_search(args.n_iter, args.workers)
    else:
        phase_evaluate(args.workers)


if __name__ == "__main__":
    main()
