"""Cold-start holdout test: reset filter state at day 841, rerun the 420-day holdout.

Preregistration: docs/plans/2026-08-31-noise-axis-coldstart-holdout-prereg-v01.md
Run from the repo root by path. Single invocation: wiring check (P0) -> 4 arms x 52
basins cold runs (checkpointed) -> summary with frozen gates C1/C2/C3.

The filter code is untouched: a cold start IS the frozen construction fed only the
last 420 days (build_runtime always starts from the day-1 state0/p0).
"""
from __future__ import annotations

import hashlib
import json
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd

_SRC = Path(__file__).resolve().parents[2]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

RESULTS = Path(r"G:\wt\camels-rising\results\23_camels_switch_confirmation")
STEP2 = RESULTS / "noise_axis_step2_learned_q_20260827_local"
TRANSFER = RESULTS / "noise_axis_transfer_loo_20260828_local"
OUT = RESULTS / "noise_axis_coldstart_holdout_20260831_local"

SHA = {
    STEP2 / "amplitudes_frozen.csv": "5be4aa3c8f5e20dfb5a83edc50d49884818e22732c2f9fddc9c84e018995b434",
    STEP2 / "evaluation_per_basin.csv": "b747f69ac4c41d13927aa4814525168c07a30d665f93085ff06032d823c611e1",
    STEP2 / "baselines_per_basin.csv": "68ea45fbdb2fc696ee337c9e2238b5da1473d2562fe321d589f72fb2c22b7619",
    TRANSFER / "transfer_per_basin.csv": "dd05744fe2d7043242be39deac608cbca9d58c6c13d808536f025e35fe78a8fc",
}
TRAIN_DAYS = 840
COLD_BURN = 60
ARMS = ("fixed_m1c0", "own_learned", "borrowed_e2", "borrowed_e2_prospective")


def load_tables():
    for path, expected in SHA.items():
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise RuntimeError(f"hash mismatch: {path}")
    amp = pd.read_csv(STEP2 / "amplitudes_frozen.csv", dtype={"basin_id": str}).set_index("basin_id")
    ev = pd.read_csv(STEP2 / "evaluation_per_basin.csv", dtype={"basin_id": str}).set_index("basin_id")
    base = pd.read_csv(STEP2 / "baselines_per_basin.csv", dtype={"basin_id": str}).set_index("basin_id")
    tr = pd.read_csv(
        TRANSFER / "transfer_per_basin.csv",
        dtype={"basin_id": str, "e2_donor": str, "oracle_donor": str},
    ).set_index("basin_id")
    return amp, ev, base, tr


def rho_of(ev: pd.DataFrame, basin: str) -> np.ndarray:
    from camels_switch_confirmation.noise_axis_learned_q import GROUP_NAMES

    return ev.loc[basin, [f"rho_{g}" for g in GROUP_NAMES]].to_numpy(np.float64)


def amps_of(amp: pd.DataFrame, basin: str) -> np.ndarray:
    from camels_switch_confirmation.noise_axis_learned_q import GROUP_NAMES

    return amp.loc[basin, [f"A_{g}" for g in GROUP_NAMES]].to_numpy(np.float64)


def load_matrix(basins):
    hold, train = {}, {}
    for i in basins:
        runs = json.loads((TRANSFER / "matrix" / f"{i}.json").read_text())["runs"]
        for j, v in runs.items():
            if j in basins:
                hold[(j, i)] = v["nse_holdout"]
                train[(j, i)] = v["nse_train_after_burnin"]
    return hold, train


def select_donor(i, basins, metric, base, col):
    best_j, best = None, -np.inf
    for j in basins:
        if j == i:
            continue
        gains = [metric[(j, k)] - base.loc[k, col] for k in basins if k not in (i, j)]
        med = float(np.median(gains))
        if med > best or (med == best and (best_j is None or j < best_j)):
            best_j, best = j, med
    return best_j


def _nse(f, o):
    return 1.0 - float(np.sum((f - o) ** 2)) / float(np.sum((o - o.mean()) ** 2))


def _cold_one(args):
    basin, donors = args
    out_path = OUT / "cells" / f"{basin}.json"
    if out_path.exists():
        return f"{basin}: skipped"
    from camels_switch_confirmation.noise_axis_filtering import (
        LegacyGridNoise,
        load_stage3_control_task,
        run_noise_axis_filter,
    )
    from camels_switch_confirmation.noise_axis_learned_q import GroupedProcessNoise

    amp, ev, base, tr = load_tables()
    task = load_stage3_control_task(basin)
    tail = dict(task)
    for key in ("rain", "pet", "temp", "obs"):
        tail[key] = np.asarray(task[key])[TRAIN_DAYS:]
    amps = amps_of(amp, basin)
    noises = {
        "fixed_m1c0": LegacyGridNoise(1.0, 0.0),
        "own_learned": GroupedProcessNoise(tuple(rho_of(ev, basin)), tuple(amps)),
        "borrowed_e2": GroupedProcessNoise(tuple(rho_of(ev, donors["e2"])), tuple(amps)),
        "borrowed_e2_prospective": GroupedProcessNoise(tuple(rho_of(ev, donors["e2p"])), tuple(amps)),
    }
    record = {"basin_id": basin, "donor_e2": donors["e2"], "donor_e2_prospective": donors["e2p"]}
    for arm, noise in noises.items():
        res = run_noise_axis_filter(tail, basin, noise)
        f, o = res["one_step_forecast"], res["observations"]
        record[f"{arm}_nse_cold_main"] = _nse(f[COLD_BURN:], o[COLD_BURN:])
        record[f"{arm}_nse_cold_full420"] = _nse(f, o)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = out_path.with_suffix(".tmp")
    tmp.write_text(json.dumps(record, indent=1))
    tmp.replace(out_path)
    return f"{basin}: done"


def wiring_check():
    from camels_switch_confirmation.noise_axis_filtering import (
        LegacyGridNoise,
        load_stage3_control_task,
        run_noise_axis_filter,
    )
    from camels_switch_confirmation.noise_axis_learned_q import GroupedProcessNoise

    amp, ev, base, tr = load_tables()
    basins = list(ev.index)
    for basin in ("01144000", "14316700"):
        task = load_stage3_control_task(basin)
        res = run_noise_axis_filter(task, basin, LegacyGridNoise(1.0, 0.0))
        got = _nse(res["one_step_forecast"][TRAIN_DAYS:], res["observations"][TRAIN_DAYS:])
        want = float(base.loc[basin, "m1c0_nse_holdout"])
        if abs(got - want) > 1e-10:
            raise RuntimeError(f"P0 fixed arm mismatch {basin}: {got} vs {want}")
        res = run_noise_axis_filter(
            task, basin, GroupedProcessNoise(tuple(rho_of(ev, basin)), tuple(amps_of(amp, basin)))
        )
        got = _nse(res["one_step_forecast"][TRAIN_DAYS:], res["observations"][TRAIN_DAYS:])
        want = float(ev.loc[basin, "nse_holdout_learned"])
        if abs(got - want) > 1e-10:
            raise RuntimeError(f"P0 own arm mismatch {basin}: {got} vs {want}")
    hold, train = load_matrix(basins)
    donors = {}
    for i in basins:
        j_frozen = select_donor(i, basins, hold, base, "m1c0_nse_holdout")
        if j_frozen != tr.loc[i, "e2_donor"] or abs(hold[(j_frozen, i)] - tr.loc[i, "e2_nse"]) > 1e-12:
            raise RuntimeError(f"P0 frozen-selection replay mismatch for {i}")
        donors[i] = {
            "e2": j_frozen,
            "e2p": select_donor(i, basins, train, base, "m1c0_nse_train_after_burnin"),
        }
    print("P0 wiring check passed (2 basins x 2 arms replay + 52 frozen selections)")
    return donors


def main():
    donors = wiring_check()
    amp, ev, base, tr = load_tables()
    basins = list(ev.index)
    tasks = [(b, donors[b]) for b in basins]
    with ProcessPoolExecutor(max_workers=6) as pool:
        for n, msg in enumerate(pool.map(_cold_one, tasks), 1):
            print(f"[{n}/{len(tasks)}] {msg}", flush=True)
    rows = [json.loads((OUT / "cells" / f"{b}.json").read_text()) for b in basins]
    frame = pd.DataFrame(rows).set_index("basin_id").loc[basins]
    frame.to_csv(OUT / "coldstart_per_basin.csv")

    def gates(caliber):
        g = {}
        fixed = frame[f"fixed_m1c0_nse_cold_{caliber}"]
        for arm in ("own_learned", "borrowed_e2", "borrowed_e2_prospective"):
            d = frame[f"{arm}_nse_cold_{caliber}"] - fixed
            g[f"{arm}_vs_fixed"] = {"median": float(d.median()), "wins": int((d > 0).sum())}
        d3 = frame[f"borrowed_e2_nse_cold_{caliber}"] - frame[f"own_learned_nse_cold_{caliber}"]
        g["e2_vs_own"] = {
            "median": float(d3.median()),
            "wins": int((d3 > 0).sum()),
            "losses": int((d3 < 0).sum()),
        }
        g["medians"] = {
            a: float(frame[f"{a}_nse_cold_{caliber}"].median()) for a in ARMS
        }
        return g

    main_g = gates("main")
    c1 = main_g["own_learned_vs_fixed"]
    c2 = main_g["borrowed_e2_vs_fixed"]
    c3 = main_g["e2_vs_own"]
    summary = {
        "preregistration": "docs/plans/2026-08-31-noise-axis-coldstart-holdout-prereg-v01.md",
        "caliber_main_days": "cold window days 61..420 (calendar 901..1260)",
        "gate_C1_own_vs_fixed": {**c1, "passed": c1["median"] > 0.01 and c1["wins"] >= 27},
        "gate_C2_e2_vs_fixed": {**c2, "passed": c2["median"] > 0.01 and c2["wins"] >= 27},
        "gate_C3_tie_maintained": {**c3, "tie": abs(c3["median"]) <= 0.01},
        "main_caliber": main_g,
        "full420_caliber": gates("full420"),
        "warm_reference": {
            "own_vs_fixed": "+0.0213 (43/52)",
            "e2_vs_fixed": "+0.0409 (38/52)",
            "e2_vs_own": "-0.0006 (25:27)",
        },
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=1))
    print(json.dumps(summary, indent=1))


if __name__ == "__main__":
    main()
