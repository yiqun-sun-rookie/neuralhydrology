"""Wet/dry split-year calibration survey over the 90 design basins.

Predefined gates (locked before running, announced in chat):
- Water years 2000..2008 ranked by mean observed flow; driest 4 = dry group,
  wettest 4 = wet group, middle 1 excluded.
- Basin is "judgeable" only if each group has >= 730 finite obs days and all
  9 calibrations (dry/wet/all x seeds 42/1042/2042) complete.
- Per-parameter shift (applied identically to all 13 parameters):
  (a) direction: sign of (dry - wet) agrees across all 3 seeds;
  (b) magnitude: |median(dry) - median(wet)| / (hi - lo) >= 0.10;
  (c) robustness: |median(dry) - median(wet)| > max(seed range dry, seed range wet).
- Primary gate: parFC prevalence >= 25% of judgeable basins keeps the
  parameter axis; below kills it.
- Secondary (exploratory): rank all 13 parameters by prevalence; a non-parFC
  winner >= 25% replaces parFC as the candidate parameter (flagged as
  exploratory, to be tested by the real-case experiment).

Exposure note: this run newly exposes 1999-10-01..2008-09-30 discharge of the
90 design basins (all permanently excluded from the 391-basin holdout).
The forbidden holdout window 1980-01-01..1989-09-30 is never requested.
Scratchpad diagnostic - NOT a registered experiment.
"""
import csv
import json
import sys
import traceback
from pathlib import Path

import numpy as np
import pandas as pd

REPO = Path(r"G:\wt\camels-rising")
sys.path.insert(0, str(REPO / "src"))

from hydroagent.data_loading import load_camels_basin
from scl_hydro.hbv_lite_cma_calibrate import calibrate_hbv_lite_cma

FREEZE = REPO / "src/camels_switch_confirmation/protocols/real_regime_parameter_k2_memory_v05.freeze.json"
BOUNDS = {k: tuple(v) for k, v in json.loads(FREEZE.read_text())["parameter_domain"]["bounds"].items()}
COVERAGE = REPO / "docs/plans/2026-08-10-camels-parfc-state-interaction-design90-coverage-v01.csv"

START, END = "1989-10-01", "2008-09-30"
WARMUP_END = pd.Timestamp("1999-09-30")
SEEDS = (42, 1042, 2042)
MIN_GROUP_DAYS = 730
OUT_DIR = Path(__file__).parent / "design90_survey"
OUT_DIR.mkdir(exist_ok=True)

def run_basin(basin: str) -> None:
    out = OUT_DIR / f"basin_{basin}.json"
    if out.exists():
        return
    record = {"basin": basin, "status": "ok", "runs": []}
    try:
        fdf, obs, area = load_camels_basin(
            basin,
            data_root=str(REPO / "data" / "camels_us"),
            start_date=START,
            end_date=END,
            forcing="maurer",
            pet_method="oudin",
            keep_obs_nan_days=True,
            strict_streamflow_window=True,
        )
        dates = fdf.index
        rain = fdf["prcp"].to_numpy(float)
        pet = fdf["ep"].to_numpy(float)
        temp = fdf["tmean"].to_numpy(float)
        q = obs.reindex(dates).to_numpy(float)
        wy = np.array([d.year + (1 if d.month >= 10 else 0) for d in dates])
        scoring = dates > WARMUP_END
        finite = np.isfinite(q)

        years = list(range(2000, 2009))
        mean_flow = {}
        for y in years:
            sel = (wy == y) & scoring & finite
            mean_flow[y] = float(np.mean(q[sel])) if sel.any() else float("nan")
        if any(not np.isfinite(v) for v in mean_flow.values()):
            record["status"] = "insufficient_water_year_data"
            record["water_year_mean_flow"] = mean_flow
            out.write_text(json.dumps(record, indent=1), encoding="utf-8")
            return
        order = sorted(years, key=lambda y: mean_flow[y])
        dry_years, wet_years = order[:4], order[-4:]
        record.update({
            "area_km2": float(area),
            "water_year_mean_flow": mean_flow,
            "dry_years": dry_years,
            "wet_years": wet_years,
            "excluded_middle_year": order[4],
        })
        groups = {"dry": dry_years, "wet": wet_years, "all": years}
        masks = {g: scoring & finite & np.isin(wy, ys) for g, ys in groups.items()}
        if int(masks["dry"].sum()) < MIN_GROUP_DAYS or int(masks["wet"].sum()) < MIN_GROUP_DAYS:
            record["status"] = "insufficient_group_days"
            record["group_days"] = {g: int(m.sum()) for g, m in masks.items()}
            out.write_text(json.dumps(record, indent=1), encoding="utf-8")
            return
        record["group_days"] = {g: int(m.sum()) for g, m in masks.items()}

        for gname in ("dry", "wet", "all"):
            for seed in SEEDS:
                res = calibrate_hbv_lite_cma(
                    rain, pet, temp, q,
                    n_trials=5000,
                    n_restarts=1,
                    loss="nse",
                    param_bounds=BOUNDS,
                    lag_kernel="rising",
                    objective_mask=masks[gname],
                    restart_seeds=[seed],
                )
                record["runs"].append({
                    "group": gname,
                    "seed": seed,
                    "fit_nse": float(res.get("nse", float("nan"))),
                    "params": {k: float(v) for k, v in res["optimized_params"].items()},
                })
    except Exception:
        record["status"] = "load_or_calibration_error"
        record["error"] = traceback.format_exc(limit=3)
    out.write_text(json.dumps(record, indent=1), encoding="utf-8")

def main(worker_index: int, worker_count: int) -> None:
    with COVERAGE.open(encoding="utf-8-sig") as fh:
        basins = [row["basin_id"].zfill(8) for row in csv.DictReader(fh)]
    mine = [b for i, b in enumerate(sorted(basins)) if i % worker_count == worker_index]
    for basin in mine:
        run_basin(basin)
        print(f"done {basin}", flush=True)

if __name__ == "__main__":
    main(int(sys.argv[1]), int(sys.argv[2]))
