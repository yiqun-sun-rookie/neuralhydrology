"""Held-out test: do regime-specific parameters actually forecast better?

Predefined gates (locked in chat before running):
- Rank water years 2000..2008 by mean observed flow. Hold out the single driest
  year D1 and the single wettest year W1; neither enters ANY calibration.
- dry-specialist  : calibrated on the remaining 3 dry years
- wet-specialist  : calibrated on the remaining 3 wet years
- generalist      : calibrated on the 7 years excluding D1 and W1
- Score on the held-out years only: NSE(dry-spec, D1) vs NSE(generalist, D1)
  and NSE(wet-spec, W1) vs NSE(generalist, W1).
- "Effect present" on a side requires >= 65% of judgeable basins improving AND
  a median NSE gain > 0.01 on that side.
- Basin judgeable only if D1 and W1 each have >= 200 finite observation days
  and all three calibrations complete.

Development data only (90 exposed design basins). The forbidden holdout window
1980-01-01..1989-09-30 is never requested. Scratchpad diagnostic.
"""
import csv
import json
import sys
import traceback
from pathlib import Path

import numpy as np
import pandas as pd

REPO = Path(r"G:\wt\camels-rising")
sys.path.insert(0, str(REPO / "src"))

from hydroagent.data_loading import load_camels_basin
from scl_hydro.hbv_lite_cma_calibrate import calibrate_hbv_lite_cma
from scl_hydro.hbv_lite_numpy import simulate_hbv_lite

FREEZE = REPO / "src/camels_switch_confirmation/protocols/real_regime_parameter_k2_memory_v05.freeze.json"
BOUNDS = {k: tuple(v) for k, v in json.loads(FREEZE.read_text())["parameter_domain"]["bounds"].items()}
COVERAGE = REPO / "docs/plans/2026-08-10-camels-parfc-state-interaction-design90-coverage-v01.csv"

START, END = "1989-10-01", "2008-09-30"
WARMUP_END = pd.Timestamp("1999-09-30")
SEED = 42
MIN_YEAR_DAYS = 200
OUT_DIR = Path(__file__).parent / "holdout_regime_value"
OUT_DIR.mkdir(exist_ok=True)


def _nse(obs, sim, mask):
    o, s = obs[mask], sim[mask]
    denom = float(np.sum((o - o.mean()) ** 2))
    if denom <= 0:
        return float("nan")
    return 1.0 - float(np.sum((o - s) ** 2)) / denom


def run_basin(basin: str) -> None:
    out = OUT_DIR / f"basin_{basin}.json"
    if out.exists():
        return
    rec = {"basin": basin, "status": "ok"}
    try:
        fdf, obs_series, area = load_camels_basin(
            basin, data_root=str(REPO / "data" / "camels_us"),
            start_date=START, end_date=END, forcing="maurer", pet_method="oudin",
            keep_obs_nan_days=True, strict_streamflow_window=True,
        )
        dates = fdf.index
        rain = fdf["prcp"].to_numpy(float)
        pet = fdf["ep"].to_numpy(float)
        temp = fdf["tmean"].to_numpy(float)
        q = obs_series.reindex(dates).to_numpy(float)
        wy = np.array([d.year + (1 if d.month >= 10 else 0) for d in dates])
        scoring = np.asarray(dates > WARMUP_END, dtype=bool)
        finite = np.isfinite(q)

        years = list(range(2000, 2009))
        mean_flow = {}
        for y in years:
            sel = (wy == y) & scoring & finite
            mean_flow[y] = float(np.mean(q[sel])) if sel.any() else float("nan")
        if any(not np.isfinite(v) for v in mean_flow.values()):
            rec["status"] = "insufficient_water_year_data"
            out.write_text(json.dumps(rec, indent=1)); return

        order = sorted(years, key=lambda y: mean_flow[y])
        dry4, wet4 = order[:4], order[-4:]
        d1, w1 = order[0], order[-1]           # driest / wettest held out
        dry_fit = [y for y in dry4 if y != d1]  # 3 years
        wet_fit = [y for y in wet4 if y != w1]  # 3 years
        gen_fit = [y for y in years if y not in (d1, w1)]  # 7 years

        d1_mask = (wy == d1) & scoring & finite
        w1_mask = (wy == w1) & scoring & finite
        if int(d1_mask.sum()) < MIN_YEAR_DAYS or int(w1_mask.sum()) < MIN_YEAR_DAYS:
            rec["status"] = "insufficient_holdout_days"
            rec["holdout_days"] = [int(d1_mask.sum()), int(w1_mask.sum())]
            out.write_text(json.dumps(rec, indent=1)); return

        rec.update({
            "area_km2": float(area), "water_year_mean_flow": mean_flow,
            "held_out_dry_year": d1, "held_out_wet_year": w1,
            "dry_fit_years": dry_fit, "wet_fit_years": wet_fit, "gen_fit_years": gen_fit,
            "holdout_days": [int(d1_mask.sum()), int(w1_mask.sum())],
        })

        params = {}
        for label, fit_years in (("dry", dry_fit), ("wet", wet_fit), ("generalist", gen_fit)):
            mask = scoring & finite & np.isin(wy, fit_years)
            res = calibrate_hbv_lite_cma(
                rain, pet, temp, q, n_trials=5000, n_restarts=1, loss="nse",
                param_bounds=BOUNDS, lag_kernel="rising",
                objective_mask=mask, restart_seeds=[SEED],
            )
            p = res["optimized_params"]
            if not p:
                raise RuntimeError(f"{label} calibration returned no parameters")
            params[label] = {k: float(v) for k, v in p.items()}
            rec[f"{label}_fit_days"] = int(mask.sum())

        # Held-out scoring: continuous simulation over the full record.
        scores = {}
        for label, p in params.items():
            qsim, _ = simulate_hbv_lite(rain, pet, temp, p, lag_kernel="rising")
            qsim = np.maximum(np.asarray(qsim, float), 0.0)
            scores[label] = {
                "nse_d1": _nse(q, qsim, d1_mask),
                "nse_w1": _nse(q, qsim, w1_mask),
            }
        rec["parameters"] = params
        rec["scores"] = scores
        rec["dry_side_gain"] = scores["dry"]["nse_d1"] - scores["generalist"]["nse_d1"]
        rec["wet_side_gain"] = scores["wet"]["nse_w1"] - scores["generalist"]["nse_w1"]
    except Exception:
        rec["status"] = "error"
        rec["error"] = traceback.format_exc(limit=3)
    out.write_text(json.dumps(rec, indent=1))


def main(worker_index: int, worker_count: int) -> None:
    with COVERAGE.open(encoding="utf-8-sig") as fh:
        basins = [row["basin_id"].zfill(8) for row in csv.DictReader(fh)]
    for i, b in enumerate(sorted(basins)):
        if i % worker_count == worker_index:
            run_basin(b)
            print(f"done {b}", flush=True)


if __name__ == "__main__":
    main(int(sys.argv[1]), int(sys.argv[2]))
