"""Runner for the leave-one-out transfer test (prereg frozen 2026-08-28).

Preregistration:
docs/plans/2026-08-28-noise-axis-transfer-loo-prereg-v01.md
(sha256 957099a734f800442e4641557574c7c94f3a379891b515431cea895f4009fa8b)

Phases (run in order from the repository root):
    matrix    52 receivers x (51 donors + 1 median arm) = 2,704 full-window filter runs,
              10 processes, resumable per receiver; scalars only, no per-day forecasts
    evaluate  build the borrow matrix, settle the e1/e2/oracle arms and the three gates

Usage:
    python src/camels_switch_confirmation/scripts/run_noise_axis_transfer_loo.py <phase>
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import numpy as np
import pandas as pd

_SRC = Path(__file__).resolve().parents[2]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation import noise_axis_learned_q as learned_q  # noqa: E402
from camels_switch_confirmation import noise_axis_transfer_loo as transfer  # noqa: E402
from camels_switch_confirmation.noise_axis_filtering import load_stage3_control_task  # noqa: E402
from camels_switch_confirmation.run_online_noise_pilot import RESULTS  # noqa: E402
from camels_switch_confirmation.run_online_noise_real_obs import OUTPUT_ROOT as STAGE3_ROOT  # noqa: E402

PREREGISTRATION = "docs/plans/2026-08-28-noise-axis-transfer-loo-prereg-v01.md"
PREREG_SHA256 = "957099a734f800442e4641557574c7c94f3a379891b515431cea895f4009fa8b"
STEP2_ROOT = RESULTS / "noise_axis_step2_learned_q_20260827_local"
STEP2_EVALUATION_SHA256 = "b747f69ac4c41d13927aa4814525168c07a30d665f93085ff06032d823c611e1"
STEP2_BASELINES_SHA256 = "68ea45fbdb2fc696ee337c9e2238b5da1473d2562fe321d589f72fb2c22b7619"
OUTPUT_ROOT = RESULTS / "noise_axis_transfer_loo_20260828_local"
MEDIAN_ARM = "median_loo"
WORKERS = 10


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _read_checked(path: Path, expected: str) -> pd.DataFrame:
    if _sha256(path) != expected:
        raise ValueError(f"{path} does not match its registered sha256; refusing to run")
    return pd.read_csv(path, dtype={"basin_id": str})


def frozen_inputs() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """The three frozen step-2 inputs, each verified against its registered hash."""
    if _sha256(Path(PREREGISTRATION)) != PREREG_SHA256:
        raise ValueError("preregistration file changed after freezing; refusing to run")
    evaluation = _read_checked(STEP2_ROOT / "evaluation_per_basin.csv", STEP2_EVALUATION_SHA256)
    baselines = _read_checked(STEP2_ROOT / "baselines_per_basin.csv", STEP2_BASELINES_SHA256)
    amplitudes_path = STEP2_ROOT / "amplitudes_frozen.csv"
    freeze = json.loads((STEP2_ROOT / "amplitudes_freeze.json").read_text(encoding="utf-8"))
    if _sha256(amplitudes_path) != freeze["csv_sha256"]:
        raise ValueError("amplitude table changed since it was frozen; refusing to run")
    amplitudes = pd.read_csv(amplitudes_path, dtype={"basin_id": str})
    return evaluation, baselines, amplitudes


def admitted_basins() -> list[str]:
    frame = pd.read_csv(STAGE3_ROOT / "precheck" / "admission.csv", dtype={"basin_id": str})
    basins = sorted(frame["basin_id"].str.zfill(8))
    if len(basins) != 52:
        raise ValueError(f"expected 52 admitted basins, found {len(basins)}")
    return basins


def _receiver_amplitudes(amplitudes: pd.DataFrame, basin: str) -> np.ndarray:
    row = amplitudes.set_index("basin_id").loc[basin]
    return np.array([float(row[f"A_{name}"]) for name in learned_q.GROUP_NAMES], dtype=np.float64)


# --------------------------------------------------------------------------
# phase: matrix
# --------------------------------------------------------------------------

def run_one_receiver(args) -> dict:
    """All borrowed settings on one receiver: 51 donors plus the e1 median profile."""
    receiver, candidates, amplitudes_list = args
    record_path = OUTPUT_ROOT / "matrix" / f"{receiver}.json"
    if record_path.exists():
        return {"basin_id": receiver, "skipped": True}
    amplitudes = np.asarray(amplitudes_list, dtype=np.float64)
    task = load_stage3_control_task(receiver)
    wall_start = time.perf_counter()
    runs, crashes = {}, []
    for label, rho in candidates:
        try:
            result = learned_q.evaluate_full_run(
                task, receiver,
                learned_q.GroupedProcessNoise(tuple(np.asarray(rho, dtype=np.float64)),
                                              tuple(amplitudes)),
            )
            runs[label] = {
                "nse_holdout": result["nse_holdout"],
                "nse_full": result["nse_full"],
                "nse_train_after_burnin": result["nse_train_after_burnin"],
            }
        except Exception as exc:  # noqa: BLE001 - crashes are data, prelocked handling
            runs[label] = None
            crashes.append({"donor": label, "error": f"{type(exc).__name__}: {exc}"})
    record = {
        "basin_id": receiver,
        "preregistration": PREREGISTRATION,
        "runs": runs,
        "crashes": crashes,
        "wall_seconds": time.perf_counter() - wall_start,
    }
    record_path.parent.mkdir(parents=True, exist_ok=True)
    record_path.write_text(json.dumps(record, indent=1), encoding="utf-8")
    return {"basin_id": receiver, "skipped": False, "n_runs": len(runs),
            "n_crashes": len(crashes), "wall_seconds": record["wall_seconds"]}


def phase_matrix() -> None:
    evaluation, _, amplitudes = frozen_inputs()
    donors = transfer.donor_rho_table(evaluation)
    basins = admitted_basins()
    if sorted(donors.index) != basins:
        raise ValueError("donor table basins and admitted basins disagree")
    jobs = []
    for receiver in basins:
        candidates = [(donor, donors.loc[donor].to_numpy())
                      for donor in basins if donor != receiver]
        candidates.append((MEDIAN_ARM, transfer.median_arm_rho(donors, receiver)))
        jobs.append((receiver, candidates, _receiver_amplitudes(amplitudes, receiver).tolist()))
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    done = 0
    with ProcessPoolExecutor(max_workers=WORKERS) as pool:
        for outcome in pool.map(run_one_receiver, jobs):
            done += 1
            if outcome.get("skipped"):
                print(f"[{done}/52] {outcome['basin_id']} already done, skipped")
            else:
                print(f"[{done}/52] {outcome['basin_id']}  {outcome['n_runs']} runs  "
                      f"{outcome['n_crashes']} crashes  {outcome['wall_seconds']:.0f}s")


# --------------------------------------------------------------------------
# phase: evaluate
# --------------------------------------------------------------------------

def phase_evaluate() -> None:
    evaluation, baselines, _ = frozen_inputs()
    basins = admitted_basins()
    m1c0 = baselines.set_index("basin_id")["m1c0_nse_holdout"].astype(np.float64)
    own = evaluation.set_index("basin_id")["nse_holdout_learned"].astype(np.float64)

    nse = pd.DataFrame(np.nan, index=basins + [MEDIAN_ARM], columns=basins, dtype=np.float64)
    crash_log = []
    for receiver in basins:
        record = json.loads(
            (OUTPUT_ROOT / "matrix" / f"{receiver}.json").read_text(encoding="utf-8")
        )
        for label, run in record["runs"].items():
            if run is None:
                continue
            nse.loc[label, receiver] = run["nse_holdout"]
        crash_log.extend(record["crashes"])
    if len(crash_log) > transfer.CRASH_CELL_LIMIT:
        raise ValueError(f"{len(crash_log)} crashed cells exceed the prelocked 5% limit; stopping")

    gain = nse.subtract(m1c0, axis=1)
    donor_gain = gain.drop(index=MEDIAN_ARM)

    rows = []
    for receiver in basins:
        e2 = transfer.select_loo_donor(donor_gain, receiver)
        oracle = transfer.oracle_donor(donor_gain, receiver)
        rows.append({
            "basin_id": receiver,
            "m1c0_nse_holdout": float(m1c0[receiver]),
            "e1_nse": float(nse.loc[MEDIAN_ARM, receiver]),
            "e1_gain": float(gain.loc[MEDIAN_ARM, receiver]),
            "e2_donor": e2,
            "e2_nse": float(nse.loc[e2, receiver]),
            "e2_gain": float(gain.loc[e2, receiver]),
            "oracle_donor": oracle,
            "oracle_nse": float(nse.loc[oracle, receiver]),
            "oracle_gain": float(gain.loc[oracle, receiver]),
            "own_learned_nse": float(own[receiver]),
            "own_learned_gain": float(own[receiver] - m1c0[receiver]),
        })
    frame = pd.DataFrame(rows)
    frame["premium_own_minus_e2"] = frame["own_learned_gain"] - frame["e2_gain"]

    gates = transfer.settle_gates(frame["e2_gain"], frame["oracle_gain"])
    faulty = ["11522500", "11482500"]
    summary = {
        "preregistration": PREREGISTRATION,
        "preregistration_sha256": PREREG_SHA256,
        "n_scheduled_runs": 52 * 52,
        "n_crashed_cells": len(crash_log),
        "gates": gates,
        "medians": {
            "e1_gain": float(frame["e1_gain"].median()),
            "e2_gain": float(frame["e2_gain"].median()),
            "oracle_gain": float(frame["oracle_gain"].median()),
            "own_learned_gain": float(frame["own_learned_gain"].median()),
            "e1_nse": float(frame["e1_nse"].median()),
            "e2_nse": float(frame["e2_nse"].median()),
            "m1c0_nse": float(frame["m1c0_nse_holdout"].median()),
        },
        "wins_vs_m1c0": {
            "e1": int((frame["e1_gain"] > 0).sum()),
            "e2": int((frame["e2_gain"] > 0).sum()),
        },
        "e2_donor_counts": frame["e2_donor"].value_counts().to_dict(),
        "oracle_donor_counts": frame["oracle_donor"].value_counts().to_dict(),
        "faulty_donor_diagnostics": {
            donor: {
                "column_median_gain_as_donor": float(np.nanmedian(
                    donor_gain.loc[donor].to_numpy(dtype=np.float64))),
                "times_selected_by_e2": int((frame["e2_donor"] == donor).sum()),
            } for donor in faulty
        },
        "crash_log": crash_log,
    }

    matrix_path = OUTPUT_ROOT / "borrow_matrix_nse_holdout.csv"
    nse.rename_axis("donor").to_csv(matrix_path)
    per_basin_path = OUTPUT_ROOT / "transfer_per_basin.csv"
    frame.to_csv(per_basin_path, index=False)
    summary["artifact_sha256"] = {
        "borrow_matrix_nse_holdout.csv": _sha256(matrix_path),
        "transfer_per_basin.csv": _sha256(per_basin_path),
    }
    (OUTPUT_ROOT / "transfer_summary.json").write_text(
        json.dumps(summary, indent=1), encoding="utf-8"
    )
    print(json.dumps({k: v for k, v in summary.items() if k != "crash_log"}, indent=1))


def main() -> None:
    phases = {"matrix": phase_matrix, "evaluate": phase_evaluate}
    if len(sys.argv) != 2 or sys.argv[1] not in phases:
        raise SystemExit(f"usage: {Path(sys.argv[0]).name} {{{'|'.join(phases)}}}")
    phases[sys.argv[1]]()


if __name__ == "__main__":
    main()
