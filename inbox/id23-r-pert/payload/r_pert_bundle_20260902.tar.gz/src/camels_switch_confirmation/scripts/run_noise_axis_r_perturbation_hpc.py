"""Production arms of the R-perturbation robustness test, for the cluster.

Preregistration: ``docs/plans/2026-09-01-noise-axis-r-perturbation-robustness-prereg-v01.md``
(sha256 ``c9773ba120960831d387c21a1168da9fb0f5e869b3ed801f648292c2232a2f5a``).

One stage per invocation, resumable: every unit of work writes its own file and an existing
file is skipped, so a re-submission after a timeout picks up where the last one stopped.

    --stage a0    R-old through the new path vs the frozen control   (52 units)  = G0
    --stage a1    fixed cell m1_c0 under R-shape                     (52 units)
    --stage a1m   fixed cell m1_c0 under R-mag                       (52 units)
    --stage a2    per-basin CMA-ES relearn under R-shape             (416 units: 52 x 8 anchors)
    --stage a3    leave-one-out borrowing under R-shape              (2,704 units)
    --stage a4    15-cell causal pruned weighting under R-shape      (780 units)

Stage order is A0 -> {A1, A1m, A2} -> A3 -> A4; A3 consumes A2's winners.  **G0 gates
everything**: if stage a0's verdict is not a pass, no other stage may be submitted (prereg
3.2).  The runner enforces this by refusing to start any other stage until A0's summary exists
and passes.

Parallelism is in-node multiprocessing.  The CPU queues bill whole nodes (playbook 13.4), so
the intended shape is one ``hcpu48`` node with ``--workers 48``, not a 52-way array.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd

_SRC = Path(__file__).resolve().parents[2]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation import noise_axis_learned_q as learned_q  # noqa: E402
from camels_switch_confirmation.noise_axis_filtering import (  # noqa: E402
    LegacyGridNoise,
    assert_single_member_posterior_exact,
    load_stage3_control_task,
    run_noise_axis_filter,
)
from camels_switch_confirmation.noise_axis_r_perturbation import (  # noqa: E402
    calibration_diagnostic,
    make_r_source,
)
from camels_switch_confirmation.run_online_noise_pilot import RESULTS  # noqa: E402
from camels_switch_confirmation.run_online_noise_real_obs import OUTPUT_ROOT as STAGE3_ROOT  # noqa: E402

PREREG_SHA256 = "c9773ba120960831d387c21a1168da9fb0f5e869b3ed801f648292c2232a2f5a"
CONTROL_CELL = LegacyGridNoise(m=1.0, c=0.0)
CONTROL_DIR = STAGE3_ROOT / "grid" / "CTRL" / CONTROL_CELL.cell_tag / "probs"
OUTPUT_DIR = Path(
    os.environ.get("R_PERTURBATION_OUTPUT", RESULTS / "noise_axis_r_perturbation_20260902_hpc")
)
GATE_DEGRADED = 1e-9

# Frozen amplitudes from step 2 (open-loop, therefore R-independent -- prereg change 0.4).
AMPLITUDES_CSV = RESULTS / "noise_axis_step2_learned_q_20260827_local" / "amplitudes_frozen.csv"
# The stage-3 15-cell grid A4 re-runs under R-shape -- imported, never restated, so the A4
# candidate library cannot drift from the frozen one.
from camels_switch_confirmation.run_online_noise_pilot import GRID_C, GRID_M  # noqa: E402
A4_SELECT_DAY = learned_q.TRAIN_DAYS   # day 840: causal top-5 by cumulative squared error
A4_TOP_K = 5


def admitted_basins() -> list[str]:
    frame = pd.read_csv(STAGE3_ROOT / "precheck" / "admission.csv", dtype={"basin_id": str})
    return sorted(frame["basin_id"].str.zfill(8))


def frozen_amplitudes(basin: str) -> np.ndarray:
    frame = pd.read_csv(AMPLITUDES_CSV, dtype={"basin_id": str})
    frame["basin_id"] = frame["basin_id"].str.zfill(8)
    row = frame.set_index("basin_id").loc[basin]
    return np.array([float(row[name]) for name in learned_q.GROUP_NAMES], dtype=np.float64)


def _nse(forecast: np.ndarray, observed: np.ndarray) -> float:
    denominator = float(np.sum(np.square(observed - observed.mean())))
    return 1.0 - float(np.sum(np.square(forecast - observed))) / denominator


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".partial")
    temporary.write_text(json.dumps(payload, indent=1), encoding="utf-8")
    temporary.replace(path)  # atomic rename: a killed job never leaves a half-written unit


# ---------------------------------------------------------------------------
# units of work (each returns a small dict; each is skipped if its file exists)
# ---------------------------------------------------------------------------

def unit_a0(basin: str) -> dict:
    task = load_stage3_control_task(basin)
    result = run_noise_axis_filter(task, basin, CONTROL_CELL, make_r_source("R-old"))
    deviation = assert_single_member_posterior_exact(result["posterior_probabilities"])
    forecast = result["one_step_forecast"]
    observed = result["observations"]
    with np.load(CONTROL_DIR / f"{basin}.npz", allow_pickle=False) as archive:
        reference = archive["one_step_forecast"].copy()
    difference = np.abs(forecast - reference)
    max_diff = float(np.max(difference))
    record = {
        "basin_id": basin,
        "max_abs_forecast_diff": max_diff,
        "n_days_bitwise_identical": int(np.count_nonzero(difference == 0.0)),
        "posterior_max_deviation": deviation,
        "nse_new_path": _nse(forecast, observed),
        "nse_frozen": _nse(reference, observed),
        "passes_bitwise": bool(max_diff == 0.0),
        "passes_degraded": bool(max_diff <= GATE_DEGRADED),
        "filter_seconds": result["filter_seconds"],
    }
    record["nse_abs_diff"] = abs(record["nse_new_path"] - record["nse_frozen"])
    record.update(
        calibration_diagnostic(
            forecast, observed, result["forecast_variance"], result["sigma_obs"],
            result["observation_variance"], burn_in=learned_q.BURN_IN_DAYS,
        )
    )
    return record


def _fixed_cell_unit(basin: str, variant: str) -> dict:
    task = load_stage3_control_task(basin)
    result = run_noise_axis_filter(task, basin, CONTROL_CELL, make_r_source(variant))
    forecast = result["one_step_forecast"]
    observed = result["observations"]
    record = {
        "basin_id": basin,
        "r_variant": variant,
        "nse_holdout": _nse(forecast[learned_q.TRAIN_DAYS:], observed[learned_q.TRAIN_DAYS:]),
        "nse_train_after_burnin": _nse(
            forecast[learned_q.BURN_IN_DAYS:learned_q.TRAIN_DAYS],
            observed[learned_q.BURN_IN_DAYS:learned_q.TRAIN_DAYS],
        ),
        "filter_seconds": result["filter_seconds"],
    }
    record.update(
        calibration_diagnostic(
            forecast, observed, result["forecast_variance"], result["sigma_obs"],
            result["observation_variance"], burn_in=learned_q.BURN_IN_DAYS,
        )
    )
    return record


def unit_a1(basin: str) -> dict:
    return _fixed_cell_unit(basin, "R-shape")


def unit_a1m(basin: str) -> dict:
    return _fixed_cell_unit(basin, "R-mag")


def unit_a2(basin: str, anchor_index: int) -> dict:
    """One (basin, anchor) CMA-ES search under R-shape; the frozen budget, only R changed."""
    task = load_stage3_control_task(basin)
    amplitudes = frozen_amplitudes(basin)
    anchor_name, anchor_rho = learned_q.anchor_table()[anchor_index]
    r_source = make_r_source("R-shape")
    anchor = learned_q.search_one_anchor(
        task, basin, amplitudes, anchor_index, anchor_rho, r_source
    )
    rho = np.exp(anchor["best_log_rho"])
    evaluation = learned_q.evaluate_full_run(
        task, basin, learned_q.GroupedProcessNoise(tuple(rho), tuple(amplitudes)), r_source
    )
    return {
        "basin_id": basin,
        "anchor_index": anchor_index,
        "anchor_name": anchor_name,
        "best_rho": rho.tolist(),
        "best_objective": anchor["best_objective"],
        "n_evaluations": anchor["n_evaluations"],
        "n_crashes": len(anchor["crashes"]),
        "exact_boundary": anchor["exact_boundary"],
        "outer_5pct": anchor["outer_5pct"],
        "nse_holdout": evaluation["nse_holdout"],
        "nse_train_after_burnin": evaluation["nse_train_after_burnin"],
    }


def unit_a3(donor: str, receiver: str) -> dict:
    """Run the receiver under the donor's learned rho, rescaled by the receiver's amplitudes."""
    winners = _a2_winners()
    task = load_stage3_control_task(receiver)
    amplitudes = frozen_amplitudes(receiver)
    rho = np.asarray(winners.loc[donor, "best_rho"], dtype=np.float64)
    evaluation = learned_q.evaluate_full_run(
        task,
        receiver,
        learned_q.GroupedProcessNoise(tuple(rho), tuple(amplitudes)),
        make_r_source("R-shape"),
    )
    return {
        "donor": donor,
        "receiver": receiver,
        "nse_holdout": evaluation["nse_holdout"],
        "nse_train_after_burnin": evaluation["nse_train_after_burnin"],
    }


def unit_a4(basin: str, cell_index: int) -> dict:
    """One of the 15 stage-3 grid cells re-run under R-shape (the multi-candidate library)."""
    m = GRID_M[cell_index // len(GRID_C)]
    c = GRID_C[cell_index % len(GRID_C)]
    task = load_stage3_control_task(basin)
    result = run_noise_axis_filter(
        task, basin, LegacyGridNoise(m=m, c=c), make_r_source("R-shape")
    )
    forecast = result["one_step_forecast"]
    return {
        "basin_id": basin,
        "cell_index": cell_index,
        "grid_m": m,
        "grid_c": c,
        "one_step_forecast": forecast.tolist(),
        "nse_holdout": _nse(
            forecast[learned_q.TRAIN_DAYS:],
            np.asarray(result["observations"])[learned_q.TRAIN_DAYS:],
        ),
    }


# ---------------------------------------------------------------------------
# stage drivers
# ---------------------------------------------------------------------------

_A2_WINNER_CACHE = {}


def _a2_winners() -> pd.DataFrame:
    """Per-basin winning rho from stage a2 (lowest training objective across the 8 anchors)."""
    if "frame" not in _A2_WINNER_CACHE:
        records = [
            json.loads(path.read_text(encoding="utf-8"))
            for path in sorted((OUTPUT_DIR / "a2").glob("*.json"))
        ]
        if not records:
            raise FileNotFoundError(f"stage a2 produced nothing under {OUTPUT_DIR / 'a2'}")
        frame = pd.DataFrame(records)
        winners = frame.loc[frame.groupby("basin_id")["best_objective"].idxmin()]
        _A2_WINNER_CACHE["frame"] = winners.set_index("basin_id")
    return _A2_WINNER_CACHE["frame"]


def _stage_units(stage: str, basins: list[str]) -> list[tuple]:
    if stage == "a0":
        return [(b,) for b in basins]
    if stage in ("a1", "a1m"):
        return [(b,) for b in basins]
    if stage == "a2":
        return [(b, a) for b in basins for a in range(learned_q.ANCHOR_COUNT)]
    if stage == "a3":
        return [(d, r) for d in basins for r in basins if d != r]
    if stage == "a4":
        return [(b, i) for b in basins for i in range(len(GRID_M) * len(GRID_C))]
    raise ValueError(f"unknown stage {stage!r}")


_UNIT_FUNCTIONS = {
    "a0": unit_a0, "a1": unit_a1, "a1m": unit_a1m,
    "a2": unit_a2, "a3": unit_a3, "a4": unit_a4,
}


def _unit_path(stage: str, arguments: tuple) -> Path:
    return OUTPUT_DIR / stage / ("_".join(str(a) for a in arguments) + ".json")


def _run_unit(stage: str, arguments: tuple) -> str:
    path = _unit_path(stage, arguments)
    if path.exists():
        return "skipped"
    payload = _UNIT_FUNCTIONS[stage](*arguments)
    _write_json(path, payload)
    return "done"


def _assert_g0_passed() -> None:
    """Prereg 3.2: nothing runs before the cluster's own A0 has passed."""
    summary = OUTPUT_DIR / "a0_summary.json"
    if not summary.exists():
        raise SystemExit(
            "G0 has not been settled on this platform: run --stage a0 first "
            f"(expected {summary})"
        )
    verdict = json.loads(summary.read_text(encoding="utf-8"))["verdict"]
    if verdict not in ("PASS_BITWISE", "PASS_DEGRADED"):
        raise SystemExit(f"G0 verdict is {verdict}; prereg 3.2 forbids running any other stage")


def summarize_a0() -> dict:
    records = [
        json.loads(p.read_text(encoding="utf-8")) for p in sorted((OUTPUT_DIR / "a0").glob("*.json"))
    ]
    frame = pd.DataFrame(records)
    frame.to_csv(OUTPUT_DIR / "a0_parity_per_basin.csv", index=False)
    n_bitwise = int(frame["passes_bitwise"].sum())
    n_degraded = int(frame["passes_degraded"].sum())
    verdict = (
        "PASS_BITWISE" if n_bitwise == len(frame)
        else "PASS_DEGRADED" if n_degraded == len(frame)
        else "FAIL"
    )
    summary = {
        "arm": "A0",
        "preregistration_sha256": PREREG_SHA256,
        "platform": "hpc_linux",
        "is_registered_g0": True,
        "n_basins": len(frame),
        "max_abs_forecast_diff_over_all_basins": float(frame["max_abs_forecast_diff"].max()),
        "n_basins_bitwise": n_bitwise,
        "n_basins_within_degraded_gate": n_degraded,
        "max_nse_abs_diff": float(frame["nse_abs_diff"].max()),
        "verdict": verdict,
        "failing_basins": frame.loc[~frame["passes_degraded"], "basin_id"].tolist(),
        "calibration_r_old_direct": {
            "z2_mean_median_over_basins": float(frame["z2_mean"].median()),
            "z2_median_median_over_basins": float(frame["z2_median"].median()),
            "n_basins_z2_mean_above_one": int((frame["z2_mean"] > 1.0).sum()),
            "z2_mean_median_low": float(frame["z2_mean_low"].median()),
            "z2_mean_median_mid": float(frame["z2_mean_mid"].median()),
            "z2_mean_median_high": float(frame["z2_mean_high"].median()),
        },
    }
    _write_json(OUTPUT_DIR / "a0_summary.json", summary)
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", required=True, choices=sorted(_UNIT_FUNCTIONS))
    parser.add_argument("--workers", type=int, default=int(os.environ.get("SLURM_NTASKS", 4)))
    arguments = parser.parse_args()

    if arguments.stage != "a0":
        _assert_g0_passed()

    basins = admitted_basins()
    units = _stage_units(arguments.stage, basins)
    (OUTPUT_DIR / arguments.stage).mkdir(parents=True, exist_ok=True)
    pending = [u for u in units if not _unit_path(arguments.stage, u).exists()]
    print(
        f"stage {arguments.stage}: {len(units)} units, {len(pending)} pending, "
        f"{arguments.workers} workers, output {OUTPUT_DIR}",
        flush=True,
    )

    start = time.perf_counter()
    done = failed = 0
    with ProcessPoolExecutor(max_workers=arguments.workers) as pool:
        futures = {pool.submit(_run_unit, arguments.stage, u): u for u in pending}
        for position, future in enumerate(as_completed(futures), start=1):
            unit = futures[future]
            try:
                future.result()
                done += 1
            except Exception as exc:  # noqa: BLE001 - a crashed unit is data, not a stop
                failed += 1
                print(f"  UNIT FAILED {unit}: {type(exc).__name__}: {exc}", flush=True)
            if position % 50 == 0 or position == len(pending):
                elapsed = time.perf_counter() - start
                print(
                    f"  [{position}/{len(pending)}] done={done} failed={failed} "
                    f"elapsed={elapsed / 60.0:.1f} min",
                    flush=True,
                )

    print(f"stage {arguments.stage} finished: done={done} failed={failed} "
          f"wall={(time.perf_counter() - start) / 60.0:.1f} min", flush=True)
    if arguments.stage == "a0":
        summary = summarize_a0()
        print(f"G0 verdict: {summary['verdict']} "
              f"(max|diff|={summary['max_abs_forecast_diff_over_all_basins']:.3e})", flush=True)
        return 0 if summary["verdict"] != "FAIL" else 1
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
