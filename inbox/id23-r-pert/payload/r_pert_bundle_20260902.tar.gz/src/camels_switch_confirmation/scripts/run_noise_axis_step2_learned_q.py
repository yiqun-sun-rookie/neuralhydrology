"""Step-2 runner: baselines, frozen amplitude table, smoke, CMA-ES search, gate settlement.

Preregistration (frozen, user-approved 2026-08-27):
docs/plans/2026-08-27-noise-axis-step2-learned-noise-prereg-draft-v01.md

Phases (run in order; each writes its artifacts before the next may start):
    baselines   recompute m1_c0 / open-loop NSE per basin from the frozen CTRL npz
    amplitudes  compute and freeze the per-basin 6-group amplitude table (CSV + sha256)
    smoke       1 basin x 1 anchor x 2 generations end-to-end, verifies pipeline + timing
    search      full 52-basin x 8-anchor CMA-ES (10 processes), resumable per basin
    evaluate    holdout gains, the three prelocked gates, diagnostics, CRPS/PIT sidecar

Usage (repository root):
    python src/camels_switch_confirmation/scripts/run_noise_axis_step2_learned_q.py <phase>
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import numpy as np
import pandas as pd

_SRC = Path(__file__).resolve().parents[2]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation import noise_axis_learned_q as learned_q  # noqa: E402
from camels_switch_confirmation.g2_switch_confirmation import _atomic_save_npz  # noqa: E402
from camels_switch_confirmation.noise_axis_filtering import (  # noqa: E402
    LegacyGridNoise,
    load_stage3_control_task,
    run_noise_axis_filter,
)
from camels_switch_confirmation.run_online_noise_pilot import RESULTS  # noqa: E402
from camels_switch_confirmation.run_online_noise_real_obs import OUTPUT_ROOT as STAGE3_ROOT  # noqa: E402

PREREGISTRATION = "docs/plans/2026-08-27-noise-axis-step2-learned-noise-prereg-draft-v01.md"
OUTPUT_ROOT = RESULTS / "noise_axis_step2_learned_q_20260827_local"
CONTROL_DIR = STAGE3_ROOT / "grid" / "CTRL" / "m1_c0" / "probs"
WORKERS = 10


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def admitted_basins() -> list[str]:
    frame = pd.read_csv(STAGE3_ROOT / "precheck" / "admission.csv", dtype={"basin_id": str})
    basins = sorted(frame["basin_id"].str.zfill(8))
    control = sorted(p.stem for p in CONTROL_DIR.glob("*.npz"))
    if basins != control or len(basins) != 52:
        raise ValueError("admitted basins and frozen control products disagree")
    return basins


# --------------------------------------------------------------------------
# phase: baselines
# --------------------------------------------------------------------------

def phase_baselines() -> None:
    """Recompute every baseline from the frozen artifacts; register deltas vs the old docs."""
    admission = pd.read_csv(
        STAGE3_ROOT / "precheck" / "admission.csv", dtype={"basin_id": str}
    ).set_index("basin_id")
    records = []
    for basin in admitted_basins():
        with np.load(CONTROL_DIR / f"{basin}.npz", allow_pickle=False) as archive:
            forecast = archive["one_step_forecast"].copy()
            observed = archive["observations"].copy()
        records.append({
            "basin_id": basin,
            "m1c0_nse_full": learned_q.nse(forecast, observed),
            "m1c0_nse_holdout": learned_q.nse(
                forecast[learned_q.TRAIN_DAYS:], observed[learned_q.TRAIN_DAYS:]
            ),
            "m1c0_nse_train_after_burnin": learned_q.nse(
                forecast[learned_q.BURN_IN_DAYS:learned_q.TRAIN_DAYS],
                observed[learned_q.BURN_IN_DAYS:learned_q.TRAIN_DAYS],
            ),
            "openloop_nse_full_admission": float(admission.loc[basin, "nse_m1"]),
        })
    frame = pd.DataFrame(records)
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    path = OUTPUT_ROOT / "baselines_per_basin.csv"
    frame.to_csv(path, index=False)
    summary = {
        "preregistration": PREREGISTRATION,
        "m1c0_nse_full_median": float(frame["m1c0_nse_full"].median()),
        "m1c0_nse_holdout_median": float(frame["m1c0_nse_holdout"].median()),
        "openloop_nse_full_median": float(frame["openloop_nse_full_admission"].median()),
        "old_doc_values": {"m1c0_full": 0.705, "openloop_full": 0.640,
                           "best_single_cell_full": 0.709},
        "delta_vs_old_doc": {
            "m1c0_full": float(frame["m1c0_nse_full"].median()) - 0.705,
            "openloop_full": float(frame["openloop_nse_full_admission"].median()) - 0.640,
        },
        "csv_sha256": _sha256(path),
    }
    (OUTPUT_ROOT / "baselines_summary.json").write_text(
        json.dumps(summary, indent=1), encoding="utf-8"
    )
    print(json.dumps(summary, indent=1))


# --------------------------------------------------------------------------
# phase: amplitudes (freeze before any search)
# --------------------------------------------------------------------------

def _amplitude_row(basin: str) -> dict:
    task = load_stage3_control_task(basin)
    states = learned_q.open_loop_states(task, basin)
    amplitudes = learned_q.training_amplitudes(states)
    row = {"basin_id": basin}
    row.update({f"A_{name}": float(a) for name, a in zip(learned_q.GROUP_NAMES, amplitudes)})
    row.update({
        f"floored_{name}": bool(a <= learned_q.AMPLITUDE_FLOOR_MM)
        for name, a in zip(learned_q.GROUP_NAMES, amplitudes)
    })
    return row


def phase_amplitudes() -> None:
    records = [_amplitude_row(basin) for basin in admitted_basins()]
    frame = pd.DataFrame(records)
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    path = OUTPUT_ROOT / "amplitudes_frozen.csv"
    frame.to_csv(path, index=False)
    freeze = {
        "preregistration": PREREGISTRATION,
        "definition": "open-loop RMS over training days 1..840, floor 0.01 mm; "
                      "routing group pooled over the 10 delay states",
        "csv_sha256": _sha256(path),
        "n_basins": len(frame),
        "n_floored_snow_groups": int(frame["floored_SNOWPACK"].sum() + frame["floored_MELTWATER"].sum()),
    }
    (OUTPUT_ROOT / "amplitudes_freeze.json").write_text(
        json.dumps(freeze, indent=1), encoding="utf-8"
    )
    print(json.dumps(freeze, indent=1))


def frozen_amplitudes() -> pd.DataFrame:
    path = OUTPUT_ROOT / "amplitudes_frozen.csv"
    freeze = json.loads((OUTPUT_ROOT / "amplitudes_freeze.json").read_text(encoding="utf-8"))
    if _sha256(path) != freeze["csv_sha256"]:
        raise ValueError("amplitude table has changed since it was frozen; refusing to search")
    return pd.read_csv(path, dtype={"basin_id": str}).set_index("basin_id")


def _basin_amplitudes(table: pd.DataFrame, basin: str) -> np.ndarray:
    return np.array(
        [float(table.loc[basin, f"A_{name}"]) for name in learned_q.GROUP_NAMES],
        dtype=np.float64,
    )


# --------------------------------------------------------------------------
# phase: search (parallel over basins, serial anchors within a basin)
# --------------------------------------------------------------------------

def search_one_basin(args) -> dict:
    basin, amplitudes_list = args
    out_dir = OUTPUT_ROOT / "search"
    record_path = out_dir / f"{basin}.json"
    if record_path.exists():
        return {"basin_id": basin, "skipped": True}
    amplitudes = np.asarray(amplitudes_list, dtype=np.float64)
    task = load_stage3_control_task(basin)
    wall_start = time.perf_counter()
    anchors = []
    for index, (name, rho) in enumerate(learned_q.anchor_table()):
        result = learned_q.search_one_anchor(task, basin, amplitudes, index, rho)
        holdout = learned_q.evaluate_full_run(
            task, basin,
            learned_q.GroupedProcessNoise(
                tuple(np.exp(result["best_log_rho"])), tuple(amplitudes)
            ),
        )
        anchors.append({
            "anchor_name": name,
            "anchor_index": index,
            "best_log_rho": result["best_log_rho"].tolist(),
            "best_rho": np.exp(result["best_log_rho"]).tolist(),
            "best_objective": result["best_objective"],
            "n_evaluations": result["n_evaluations"],
            "exact_boundary": result["exact_boundary"],
            "outer_5pct": result["outer_5pct"],
            "crashes": result["crashes"],
            "nse_holdout": holdout["nse_holdout"],
            "nse_full": holdout["nse_full"],
            "nse_train_after_burnin": holdout["nse_train_after_burnin"],
        })
    winner = min(anchors, key=lambda a: a["best_objective"])
    winner_noise = learned_q.GroupedProcessNoise(
        tuple(np.asarray(winner["best_rho"], dtype=np.float64)), tuple(amplitudes)
    )
    final = learned_q.evaluate_full_run(task, basin, winner_noise)
    out_dir.mkdir(parents=True, exist_ok=True)
    _atomic_save_npz(
        out_dir / f"{basin}_winner.npz",
        one_step_forecast=final["one_step_forecast"],
        forecast_variance=final["forecast_variance"],
        observations=final["observations"],
        rho=np.asarray(winner["best_rho"], dtype=np.float64),
        amplitudes=amplitudes,
        basin_id=np.array(basin),
        winner_anchor=np.array(winner["anchor_name"]),
    )
    record = {
        "basin_id": basin,
        "preregistration": PREREGISTRATION,
        "anchors": anchors,
        "winner_anchor": winner["anchor_name"],
        "wall_seconds": time.perf_counter() - wall_start,
    }
    record_path.write_text(json.dumps(record, indent=1), encoding="utf-8")
    return {"basin_id": basin, "skipped": False,
            "wall_seconds": record["wall_seconds"],
            "winner": winner["anchor_name"],
            "gain_holdout_raw": winner["nse_holdout"]}


def phase_smoke() -> None:
    """1 basin x 1 anchor x 2 generations: pipeline works, timing assumption holds."""
    basin = admitted_basins()[0]
    table = frozen_amplitudes()
    amplitudes = _basin_amplitudes(table, basin)
    task = load_stage3_control_task(basin)
    name, rho = learned_q.anchor_table()[0]
    generations_backup = learned_q.CMA_GENERATIONS
    learned_q.CMA_GENERATIONS = 2  # smoke only; the frozen budget is untouched for `search`
    try:
        start = time.perf_counter()
        result = learned_q.search_one_anchor(task, basin, amplitudes, 0, rho)
        elapsed = time.perf_counter() - start
    finally:
        learned_q.CMA_GENERATIONS = generations_backup
    per_eval = elapsed / result["n_evaluations"]
    projection_hours = per_eval * learned_q.EVALS_PER_ANCHOR * learned_q.ANCHOR_COUNT * 52 / 3600
    print(json.dumps({
        "basin": basin, "anchor": name,
        "n_evaluations": result["n_evaluations"],
        "seconds_per_training_eval": per_eval,
        "best_objective": result["best_objective"],
        "crashes": len(result["crashes"]),
        "projected_serial_hours_52_basins": projection_hours,
        "projected_hours_at_10_workers": projection_hours / WORKERS,
    }, indent=1))


def phase_search() -> None:
    basins = admitted_basins()
    table = frozen_amplitudes()
    work = [(basin, _basin_amplitudes(table, basin).tolist()) for basin in basins]
    (OUTPUT_ROOT / "search").mkdir(parents=True, exist_ok=True)
    start = time.perf_counter()
    with ProcessPoolExecutor(max_workers=WORKERS) as pool:
        for record in pool.map(search_one_basin, work):
            flag = "skip" if record.get("skipped") else "done"
            extra = "" if record.get("skipped") else (
                f"  {record['wall_seconds']:.0f}s  winner={record['winner']}"
            )
            print(f"  [{flag}] {record['basin_id']}{extra}", flush=True)
    print(f"search wall total: {(time.perf_counter() - start) / 3600:.2f} h")


# --------------------------------------------------------------------------
# phase: evaluate (gates + diagnostics + CRPS/PIT sidecar)
# --------------------------------------------------------------------------

def _crps_and_pit(forecast: np.ndarray, variance: np.ndarray, observed: np.ndarray) -> dict:
    from camels_switch_confirmation.real_case_metrics import (
        mixture_crps,
        mixture_pit,
        pit_calibration_index,
    )
    means = forecast[learned_q.TRAIN_DAYS:, None]
    variances = np.maximum(variance[learned_q.TRAIN_DAYS:, None], 1e-12)
    weights = np.ones_like(means)
    observed_holdout = observed[learned_q.TRAIN_DAYS:]
    crps = float(np.mean(mixture_crps(means, variances, weights, observed_holdout)))
    pit = float(pit_calibration_index(mixture_pit(means, variances, weights, observed_holdout)))
    return {"crps_holdout_mean": crps, "pit_calibration_index": pit}


def phase_evaluate() -> None:
    basins = admitted_basins()
    baselines = pd.read_csv(
        OUTPUT_ROOT / "baselines_per_basin.csv", dtype={"basin_id": str}
    ).set_index("basin_id")
    rows, crash_total = [], 0
    for basin in basins:
        record = json.loads((OUTPUT_ROOT / "search" / f"{basin}.json").read_text(encoding="utf-8"))
        winner = next(a for a in record["anchors"] if a["anchor_name"] == record["winner_anchor"])
        m1c0_holdout = float(baselines.loc[basin, "m1c0_nse_holdout"])
        m1c0_train = float(baselines.loc[basin, "m1c0_nse_train_after_burnin"])
        anchor_gains = [a["nse_holdout"] - m1c0_holdout for a in record["anchors"]]
        quart = np.percentile(anchor_gains, [25, 75])
        objectives = np.array([a["best_objective"] for a in record["anchors"]], dtype=np.float64)
        finite = objectives[np.isfinite(objectives)]
        rel_iqr = float(
            (np.percentile(finite, 75) - np.percentile(finite, 25)) / abs(np.median(finite))
        ) if len(finite) >= 2 and np.median(finite) != 0 else float("nan")
        crash_total += sum(len(a["crashes"]) for a in record["anchors"])
        with np.load(OUTPUT_ROOT / "search" / f"{basin}_winner.npz", allow_pickle=False) as archive:
            learn_prob = _crps_and_pit(
                archive["one_step_forecast"], archive["forecast_variance"], archive["observations"]
            )
            rho = archive["rho"].copy()
            amplitudes = archive["amplitudes"].copy()
        variance_share = np.empty(learned_q.N_GROUPS)
        std = rho * amplitudes
        contributions = np.square(std)
        contributions[-1] *= 10  # the routing group holds 10 states
        variance_share = contributions / contributions.sum()
        rows.append({
            "basin_id": basin,
            "winner_anchor": record["winner_anchor"],
            "nse_holdout_learned": winner["nse_holdout"],
            "nse_holdout_m1c0": m1c0_holdout,
            "gain_holdout": winner["nse_holdout"] - m1c0_holdout,
            "gain_train": winner["nse_train_after_burnin"] - m1c0_train,
            "anchor_gain_iqr": float(quart[1] - quart[0]),
            "objective_relative_iqr": rel_iqr,
            "exact_boundary": winner["exact_boundary"],
            "outer_5pct": winner["outer_5pct"],
            **{f"rho_{name}": float(r) for name, r in zip(learned_q.GROUP_NAMES, rho)},
            **{f"share_{name}": float(s) for name, s in zip(learned_q.GROUP_NAMES, variance_share)},
            **{f"learn_{k}": v for k, v in learn_prob.items()},
        })
    frame = pd.DataFrame(rows)
    path = OUTPUT_ROOT / "evaluation_per_basin.csv"
    frame.to_csv(path, index=False)

    gains = frame["gain_holdout"].to_numpy(dtype=np.float64)
    gate1 = int(np.sum(gains > 0))
    gate2 = float(np.median(gains))
    gate3_dispersion = float(frame["anchor_gain_iqr"].median())
    summary = {
        "preregistration": PREREGISTRATION,
        "n_basins": len(frame),
        "gate1_basins_improved": gate1,
        "gate1_threshold": 34,
        "gate1_pass": bool(gate1 >= 34),
        "gate2_median_gain": gate2,
        "gate2_threshold": 0.01,
        "gate2_pass": bool(gate2 > 0.01),
        "gate3_median_anchor_iqr": gate3_dispersion,
        "gate3_pass": bool(gate2 > gate3_dispersion),
        "verdict": None,
        "nse_holdout_learned_median": float(frame["nse_holdout_learned"].median()),
        "nse_holdout_m1c0_median": float(frame["nse_holdout_m1c0"].median()),
        "gain_train_median": float(frame["gain_train"].median()),
        "boundary_exact_total": int(frame["exact_boundary"].sum()),
        "basins_with_any_exact_boundary": int((frame["exact_boundary"] > 0).sum()),
        "basins_with_any_outer5pct": int((frame["outer_5pct"] > 0).sum()),
        "objective_relative_iqr_median": float(frame["objective_relative_iqr"].median()),
        "objective_relative_iqr_max": float(frame["objective_relative_iqr"].max()),
        "winner_anchor_counts": frame["winner_anchor"].value_counts().to_dict(),
        "variance_share_medians": {
            name: float(frame[f"share_{name}"].median()) for name in learned_q.GROUP_NAMES
        },
        "crash_total": crash_total,
        "csv_sha256": _sha256(path),
    }
    summary["verdict"] = (
        "PASS" if summary["gate1_pass"] and summary["gate2_pass"] and summary["gate3_pass"]
        else "FAIL"
    )
    (OUTPUT_ROOT / "evaluation_summary.json").write_text(
        json.dumps(summary, indent=1), encoding="utf-8"
    )
    print(json.dumps(summary, indent=1))


def phase_ctrl_variance() -> None:
    """Sidecar: rerun the bitwise-proven m1_c0 machine once per basin, saving variance."""
    out_dir = OUTPUT_ROOT / "ctrl_variance"
    out_dir.mkdir(parents=True, exist_ok=True)
    cell = LegacyGridNoise(m=1.0, c=0.0)
    rows = []
    for basin in admitted_basins():
        out_path = out_dir / f"{basin}.npz"
        if not out_path.exists():
            task = load_stage3_control_task(basin)
            result = run_noise_axis_filter(task, basin, cell)
            with np.load(CONTROL_DIR / f"{basin}.npz", allow_pickle=False) as archive:
                if float(np.max(np.abs(
                    result["one_step_forecast"] - archive["one_step_forecast"]
                ))) != 0.0:
                    raise ValueError(f"basin {basin}: variance rerun is no longer bitwise")
            _atomic_save_npz(
                out_path,
                one_step_forecast=result["one_step_forecast"],
                forecast_variance=result["forecast_variance"],
                observations=result["observations"],
                basin_id=np.array(basin),
            )
        with np.load(out_path, allow_pickle=False) as archive:
            rows.append({
                "basin_id": basin,
                **{f"ctrl_{k}": v for k, v in _crps_and_pit(
                    archive["one_step_forecast"], archive["forecast_variance"],
                    archive["observations"],
                ).items()},
            })
    pd.DataFrame(rows).to_csv(out_dir / "ctrl_crps_pit.csv", index=False)
    print(f"ctrl variance sidecar: {len(rows)} basins")


PHASES = {
    "baselines": phase_baselines,
    "amplitudes": phase_amplitudes,
    "smoke": phase_smoke,
    "search": phase_search,
    "ctrl_variance": phase_ctrl_variance,
    "evaluate": phase_evaluate,
}


if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] not in PHASES:
        raise SystemExit(f"usage: {Path(sys.argv[0]).name} {{{'|'.join(PHASES)}}}")
    PHASES[sys.argv[1]]()
