"""Step 1 of the noise axis: prove the pluggable-noise implementation is the frozen filter.

Design: docs/plans/2026-08-26-noise-axis-learned-noise-design-v02.md section 5, step 1.

Hard gate (prelocked, not negotiable here): for every one of the 52 stage-3 admitted basins,
the day-by-day one-step forecast produced by ``noise_axis_filtering`` under
``LegacyGridNoise(m=1, c=0)`` must match the frozen stage-3 single-member control npz to a
maximum absolute difference of 1e-8 or less.  Failing the gate stops the line; it must not be
walked past with a non-equivalent implementation.

This step produces NO scientific claim.  It deliberately does not compute NSE or any skill
metric: design v02 section 4 requires every baseline of the new round to be recomputed from
the control npz under the step-2 protocol, and producing skill numbers here would put them
outside that protocol.

Second deliverable: an uncontended per-basin wall-clock timing of one filter pass, so step 2's
search budget can be frozen from measurement rather than guessed (TUKF13 showed empirically
that changing the budget changed the conclusion).  The run is therefore serial on purpose --
a contended parallel timing would understate the per-evaluation cost.

Usage (from the repository root -- the CAMELS loader resolves ``data/camels_us`` relatively,
and ``src/`` is not on the default import path, so the script bootstraps it itself):
    python src/camels_switch_confirmation/scripts/verify_noise_axis_step1_reproduction.py
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

_SRC = Path(__file__).resolve().parents[2]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation.noise_axis_filtering import (  # noqa: E402
    LegacyGridNoise,
    assert_single_member_posterior_exact,
    load_stage3_control_task,
    run_noise_axis_filter,
)
from camels_switch_confirmation.run_online_noise_real_obs import OUTPUT_ROOT as STAGE3_ROOT  # noqa: E402
from camels_switch_confirmation.run_online_noise_pilot import RESULTS  # noqa: E402

REPRODUCTION_CELL = LegacyGridNoise(m=1.0, c=0.0)
GATE_MAX_ABS_DIFF = 1e-8
POSTERIOR_TOLERANCE = 1e-12
CONTROL_DIR = STAGE3_ROOT / "grid" / "CTRL" / REPRODUCTION_CELL.cell_tag / "probs"
OUTPUT_DIR = RESULTS / "noise_axis_step1_reproduction_20260827_local"


def admitted_basins() -> list[str]:
    """The 52 stage-3 admitted basins, cross-checked against the frozen control products."""
    path = STAGE3_ROOT / "precheck" / "admission.csv"
    if not path.exists():
        raise FileNotFoundError(f"stage-3 admission table is missing: {path}")
    frame = pd.read_csv(path, dtype={"basin_id": str})
    basins = sorted(frame["basin_id"].str.zfill(8))
    control_basins = sorted(p.stem for p in CONTROL_DIR.glob("*.npz"))
    if basins != control_basins:
        raise ValueError(
            f"admitted basins and frozen control products disagree: "
            f"{len(basins)} admitted vs {len(control_basins)} control npz"
        )
    return basins


def _reference(basin: str) -> dict:
    with np.load(CONTROL_DIR / f"{basin}.npz", allow_pickle=False) as archive:
        return {name: archive[name].copy() for name in archive.files}


def verify_one(basin: str) -> dict:
    """Reproduce one basin and compare it to the frozen control day by day."""
    load_start = time.perf_counter()
    task = load_stage3_control_task(basin)
    load_seconds = time.perf_counter() - load_start

    result = run_noise_axis_filter(task, basin, REPRODUCTION_CELL)
    posterior_deviation = assert_single_member_posterior_exact(
        result["posterior_probabilities"], POSTERIOR_TOLERANCE
    )

    reference = _reference(basin)
    forecast_diff = np.abs(result["one_step_forecast"] - reference["one_step_forecast"])
    observation_diff = np.abs(result["observations"] - reference["observations"])
    max_diff = float(np.max(forecast_diff))
    return {
        "basin_id": basin,
        "n_days": int(len(forecast_diff)),
        "max_abs_forecast_diff": max_diff,
        "n_days_bitwise_identical": int(np.count_nonzero(forecast_diff == 0.0)),
        "max_abs_observation_diff": float(np.max(observation_diff)),
        "posterior_max_deviation": posterior_deviation,
        "sigma_obs": result["sigma_obs"],
        "load_seconds": load_seconds,
        "filter_seconds": result["filter_seconds"],
        "passes_gate": bool(max_diff <= GATE_MAX_ABS_DIFF),
    }


def main() -> int:
    basins = admitted_basins()
    print(f"step-1 reproduction: {len(basins)} basins, cell {REPRODUCTION_CELL.cell_tag}, "
          f"gate max|diff| <= {GATE_MAX_ABS_DIFF:.0e}")
    records = []
    wall_start = time.perf_counter()
    for position, basin in enumerate(basins, start=1):
        record = verify_one(basin)
        records.append(record)
        print(f"  [{position:2d}/{len(basins)}] {basin}  max|diff|={record['max_abs_forecast_diff']:.3e}  "
              f"filter={record['filter_seconds']:.2f}s  {'PASS' if record['passes_gate'] else 'FAIL'}")
    wall_seconds = time.perf_counter() - wall_start

    frame = pd.DataFrame(records)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    frame.to_csv(OUTPUT_DIR / "step1_reproduction_per_basin.csv", index=False)

    filter_seconds = frame["filter_seconds"].to_numpy(dtype=np.float64)
    failures = frame[~frame["passes_gate"]]
    summary = {
        "experiment_id": "NOISE_AXIS_STEP1_REPRODUCTION_01",
        "design_document": "docs/plans/2026-08-26-noise-axis-learned-noise-design-v02.md",
        "cell": REPRODUCTION_CELL.cell_tag,
        "gate_max_abs_diff": GATE_MAX_ABS_DIFF,
        "n_basins": int(len(frame)),
        "n_days_per_basin": int(frame["n_days"].max()),
        "max_abs_forecast_diff_over_all_basins": float(frame["max_abs_forecast_diff"].max()),
        "n_basins_bitwise_identical": int((frame["max_abs_forecast_diff"] == 0.0).sum()),
        "n_basins_passing_gate": int(frame["passes_gate"].sum()),
        "gate_verdict": "PASS" if failures.empty else "FAIL",
        "failing_basins": sorted(failures["basin_id"].tolist()),
        "max_abs_observation_diff": float(frame["max_abs_observation_diff"].max()),
        "max_posterior_deviation": float(frame["posterior_max_deviation"].max()),
        "timing_smoke": {
            "measurement": "serial, uncontended, one filter pass over 1260 days per basin",
            "filter_seconds_median": float(np.median(filter_seconds)),
            "filter_seconds_min": float(filter_seconds.min()),
            "filter_seconds_max": float(filter_seconds.max()),
            "filter_seconds_mean": float(filter_seconds.mean()),
            "filter_seconds_total_52_basins": float(filter_seconds.sum()),
            "load_seconds_median": float(np.median(frame["load_seconds"].to_numpy(dtype=np.float64))),
            "wall_seconds_total": wall_seconds,
        },
    }
    (OUTPUT_DIR / "step1_reproduction_summary.json").write_text(
        json.dumps(summary, indent=1), encoding="utf-8"
    )

    print()
    print(f"verdict: {summary['gate_verdict']}  "
          f"({summary['n_basins_passing_gate']}/{summary['n_basins']} basins pass, "
          f"{summary['n_basins_bitwise_identical']} bitwise identical)")
    print(f"max|diff| over all basins = {summary['max_abs_forecast_diff_over_all_basins']:.3e}")
    print(f"timing smoke: median {summary['timing_smoke']['filter_seconds_median']:.2f}s per filter pass "
          f"(min {summary['timing_smoke']['filter_seconds_min']:.2f}, "
          f"max {summary['timing_smoke']['filter_seconds_max']:.2f})")
    print(f"outputs: {OUTPUT_DIR}")
    return 0 if failures.empty else 1


if __name__ == "__main__":
    raise SystemExit(main())
