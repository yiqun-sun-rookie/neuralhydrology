"""Fail-closed lifecycle helpers for the frozen parameter-axis v03 protocol.

This module validates a human-approved credential before a runnable
configuration can be accepted or registered.  It deliberately has no data
loading or optimizer imports, so lifecycle failures occur before either can be
entered.
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import os
import re
import stat
import uuid
from collections.abc import Mapping, Sequence
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any


FROZEN_PROTOCOL_ID = "real_regime_parameter_output_functional_stability_v03"
FROZEN_PROTOCOL_SCOPE = "parameter_axis_development_v03"
FROZEN_CHANGED_FACTOR = (
    "independent_restart_parameter_distance_replaced_by_output_distance_only"
)
FROZEN_PROTOCOL_SHA256 = (
    "5a796c7f115a13adb1b6fa749bd2fd24022a9472019a9a328aa1338962bd2d9f"
)
V03_CONFIG_RELATIVE_PATH = (
    "src/camels_switch_confirmation/configs/"
    "real_regime_parameter_calibration_development_screen_v03.json"
)
V03_REGISTRY_COLUMNS = (
    "experiment_id",
    "classification",
    "hypothesis",
    "config_path",
    "config_sha256",
    "basin_manifest",
    "basin_manifest_sha256",
    "changed_factor",
    "fixed_factors",
    "restart_seeds",
    "status",
    "output_dir",
    "metrics_path",
    "paper_name",
    "notes",
    "updated_at",
    "error",
)
V03_REGISTRY_HYPOTHESIS = (
    "Fit-selected all-flow low-flow and high-flow parameter candidates can be supported "
    "when independent restarts have equivalent daily validation hydrographs"
)
V03_REGISTRY_FIXED_FACTORS = (
    "basins; forcing; potential evapotranspiration; parameter bounds; routing; dates; "
    "optimization budget; seeds; selected and support boundary gates; validation effect "
    "gates; cross-basin gates"
)
V03_REGISTRY_NOTES = (
    "Output-functional stability replaces only the independent-restart parameter-distance "
    "qualification; no noise axis; joint axis; formal evaluation; or scientific claim is "
    "authorized."
)
PLACEHOLDER_PATTERN = re.compile(
    r"^(?:tbd|todo|pending|placeholder|not[_ -]?set|fill[_ -]?me|unknown)$",
    flags=re.IGNORECASE,
)


class ProtocolNotFrozenError(ValueError):
    """Raised when a protocol credential is absent, incomplete, or altered."""


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _exact_keys(value: Any, expected: set[str], label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping) or set(value) != expected:
        actual = sorted(value) if isinstance(value, Mapping) else type(value).__name__
        raise ProtocolNotFrozenError(
            f"{label} must contain exactly {sorted(expected)}; received {actual}"
        )
    return value


def _require_strict_tree(value: Any, expected: Any, label: str) -> None:
    """Compare JSON-shaped values without Python's bool/int coercions."""

    if isinstance(expected, dict):
        if type(value) is not dict:  # Exact JSON container type is part of the freeze.
            raise ProtocolNotFrozenError(f"{label} must be a JSON object")
        expected_keys = set(expected)
        actual_keys = set(value)
        if actual_keys != expected_keys:
            missing = sorted(expected_keys - actual_keys)
            extra = sorted(actual_keys - expected_keys)
            raise ProtocolNotFrozenError(
                f"{label} fields differ; missing={missing}, extra={extra}"
            )
        for key in expected:
            _require_strict_tree(value[key], expected[key], f"{label}.{key}")
        return
    if isinstance(expected, list):
        if type(value) is not list:
            raise ProtocolNotFrozenError(f"{label} must be a JSON array")
        if len(value) != len(expected):
            raise ProtocolNotFrozenError(
                f"{label} must contain exactly {len(expected)} items"
            )
        for index, (item, expected_item) in enumerate(zip(value, expected)):
            _require_strict_tree(item, expected_item, f"{label}[{index}]")
        return
    if type(value) is not type(expected):
        raise ProtocolNotFrozenError(
            f"{label} must retain type {type(expected).__name__}; "
            f"received {type(value).__name__}"
        )
    if isinstance(value, float) and not math.isfinite(value):
        raise ProtocolNotFrozenError(f"{label} must be finite")
    if value != expected:
        raise ProtocolNotFrozenError(f"{label} must remain {expected!r}")


def _require_exact(value: Any, expected: Any, label: str) -> None:
    _require_strict_tree(value, expected, label)


def _reject_incomplete(value: Any, label: str = "credential") -> None:
    if value is None:
        raise ProtocolNotFrozenError(f"{label} must not be null")
    if isinstance(value, str):
        if not value.strip() or PLACEHOLDER_PATTERN.fullmatch(value.strip()):
            raise ProtocolNotFrozenError(f"{label} contains a placeholder string")
        return
    if isinstance(value, bool):
        return
    if isinstance(value, (int, float)):
        if isinstance(value, float) and not math.isfinite(value):
            raise ProtocolNotFrozenError(f"{label} must contain only finite numbers")
        return
    if isinstance(value, Mapping):
        for key, item in value.items():
            _reject_incomplete(item, f"{label}.{key}")
        return
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        if not value:
            raise ProtocolNotFrozenError(f"{label} must not be empty")
        for index, item in enumerate(value):
            _reject_incomplete(item, f"{label}[{index}]")
        return
    raise ProtocolNotFrozenError(f"{label} contains an unsupported value type")


def _safe_repo_file(
    repo_root: Path,
    raw_path: Any,
    expected_digest: Any,
    label: str,
) -> Path:
    relative = Path(str(raw_path))
    if relative.is_absolute() or ".." in relative.parts:
        raise ProtocolNotFrozenError(f"{label} must be a repository-relative safe path")
    resolved = (repo_root / relative).resolve()
    # The repository intentionally exposes CAMELS-US through a directory
    # junction.  The declared path must be lexically repository-relative, but
    # its resolved target may therefore live in the shared data checkout.
    if not resolved.is_file():
        raise ProtocolNotFrozenError(f"{label} is missing: {resolved}")
    digest = str(expected_digest).lower()
    if re.fullmatch(r"[0-9a-f]{64}", digest) is None or _sha256(resolved) != digest:
        raise ProtocolNotFrozenError(f"{label} hash differs from the frozen credential")
    return resolved


def _validate_exact_schema(document: Mapping[str, Any]) -> None:
    _exact_keys(
        document,
        {
            "schema_version",
            "protocol_id",
            "protocol_status",
            "protocol_scope",
            "approved_at",
            "approval_evidence",
            "human_protocol_path",
            "human_protocol_sha256",
            "base_experiment_id",
            "base_config_path",
            "base_config_sha256",
            "changed_factor",
            "fixed_factors",
            "output_functional_stability",
            "evidence_contract",
            "lifecycle",
            "interpretation_permissions",
        },
        "protocol credential",
    )
    fixed = _exact_keys(
        document["fixed_factors"],
        {
            "basin_ids",
            "basin_manifest_path",
            "basin_manifest_sha256",
            "development_universe_path",
            "development_universe_sha256",
            "input_manifest_path",
            "input_manifest_sha256",
            "topography_path",
            "topography_sha256",
            "forcing",
            "potential_evapotranspiration_method",
            "parameter_bounds_preset",
            "routing_kernel",
            "parameter_groups",
            "periods",
            "flow_regime_quantiles",
            "flow_log_offset_mm_day",
            "coverage_policy",
            "optimizer",
            "validation_gates",
            "parameter_range_gates",
            "cross_basin_gates",
        },
        "fixed_factors",
    )
    periods = _exact_keys(
        fixed["periods"],
        {"warmup", "fit", "validation", "forbidden_holdout"},
        "fixed_factors.periods",
    )
    _exact_keys(periods["warmup"], {"start", "end"}, "periods.warmup")
    _exact_keys(periods["fit"], {"start", "end", "expected_days"}, "periods.fit")
    _exact_keys(
        periods["validation"],
        {"start", "end", "expected_days"},
        "periods.validation",
    )
    _exact_keys(periods["forbidden_holdout"], {"start", "end"}, "periods.forbidden_holdout")
    _exact_keys(
        fixed["flow_regime_quantiles"],
        {"low", "high", "method", "source_period"},
        "fixed_factors.flow_regime_quantiles",
    )
    coverage = _exact_keys(
        fixed["coverage_policy"],
        {"minimum_target_days_per_water_year", "fit", "validation"},
        "fixed_factors.coverage_policy",
    )
    coverage_keys = {
        "minimum_total_target_days",
        "minimum_qualifying_water_years",
        "expected_water_years",
    }
    _exact_keys(coverage["fit"], coverage_keys, "coverage_policy.fit")
    _exact_keys(coverage["validation"], coverage_keys, "coverage_policy.validation")
    _exact_keys(
        fixed["optimizer"],
        {
            "function_evaluations_per_restart",
            "evaluation_budget_semantics",
            "restart_seeds",
            "selection_period",
            "selection_rule",
            "validation_may_promote_restart",
            "expected_restart_count",
        },
        "fixed_factors.optimizer",
    )
    _exact_keys(
        fixed["optimizer"]["evaluation_budget_semantics"],
        {
            "config_field",
            "pycma_option",
            "declared_stop_threshold",
            "stop_check_boundary",
            "actual_objective_calls_may_exceed_threshold",
            "actual_objective_call_count_authority",
        },
        "fixed_factors.optimizer.evaluation_budget_semantics",
    )
    _exact_keys(
        fixed["validation_gates"],
        {
            "target_relative_improvement_min",
            "minimum_improved_water_years",
            "all_flow_nse_drop_max",
            "opposite_regime_relative_degradation_max",
            "must_beat_other_specialist",
        },
        "fixed_factors.validation_gates",
    )
    _exact_keys(
        fixed["parameter_range_gates"],
        {
            "near_boundary_fraction",
            "strongly_saturated_fraction",
            "maximum_near_boundary_parameters",
            "maximum_strongly_saturated_parameters",
            "applies_to_selected_vectors",
            "applies_to_support_restarts",
            "cross_basin_same_side_fraction",
            "cross_basin_same_side_saturation_fails",
        },
        "fixed_factors.parameter_range_gates",
    )
    _exact_keys(
        fixed["cross_basin_gates"],
        {
            "all_generalist_groups_must_pass",
            "minimum_complete_candidate_groups",
            "number_of_development_basins",
        },
        "fixed_factors.cross_basin_gates",
    )
    stability = _exact_keys(
        document["output_functional_stability"],
        {
            "comparison",
            "fit_loss_ratio_max",
            "minimum_support_restarts",
            "available_additional_restarts",
            "maximum_distance",
            "comparison_operator",
            "all_three_day_sets_must_pass",
            "day_sets",
            "numerator",
            "denominator",
            "variance_ddof",
            "invalid_when_denominator_not_finite_positive",
            "invalid_when_prediction_nonfinite_or_negative",
            "parameter_distance",
        },
        "output_functional_stability",
    )
    day_sets = _exact_keys(
        stability["day_sets"],
        {"all_flow", "low_flow", "high_flow"},
        "output_functional_stability.day_sets",
    )
    _exact_keys(day_sets["all_flow"], {"transform"}, "day_sets.all_flow")
    _exact_keys(
        day_sets["low_flow"],
        {"transform", "offset_mm_day", "membership"},
        "day_sets.low_flow",
    )
    _exact_keys(
        day_sets["high_flow"],
        {"transform", "membership"},
        "day_sets.high_flow",
    )
    _exact_keys(
        stability["parameter_distance"],
        {"record", "qualification_gate", "second_version_threshold_recorded_for_audit"},
        "output_functional_stability.parameter_distance",
    )
    _exact_keys(
        document["evidence_contract"],
        {
            "restart_parameter_vector_rows",
            "fit_restart_hydrograph_rows",
            "validation_restart_hydrograph_rows",
            "required_artifacts",
            "same_parameter_fingerprint_required_across_artifacts",
            "independent_raw_recomputation_required",
            "telemetry_on_off_optimization_equivalence_required",
        },
        "evidence_contract",
    )
    _exact_keys(
        document["lifecycle"],
        {
            "code_and_tests_before_registration",
            "real_optimizer_calls_before_registration",
            "registration_must_be_atomic",
            "execution_requires_separate_user_authorization",
            "one_terminal_result_per_experiment_id",
        },
        "lifecycle",
    )
    _exact_keys(
        document["interpretation_permissions"],
        {
            "fixed_parameter_continuous_replay_development",
            "online_parameter_switching",
            "filter_state_mapping",
            "parameter_identification",
            "process_noise_axis",
            "joint_parameter_process_noise_axis",
            "formal_holdout_evaluation",
            "scientific_claim",
        },
        "interpretation_permissions",
    )


def validate_protocol_document(repo_root: Path, document: Mapping[str, Any]) -> dict[str, Any]:
    """Validate the complete frozen v03 credential and all source identities."""

    root = Path(repo_root).resolve()
    if not root.is_dir():
        raise ProtocolNotFrozenError(f"repository root is missing: {root}")
    if not isinstance(document, Mapping):
        raise ProtocolNotFrozenError("protocol credential must be a JSON object")
    _reject_incomplete(document)
    _validate_exact_schema(document)
    _require_exact(document["schema_version"], 1, "schema_version")
    _require_exact(document["protocol_id"], FROZEN_PROTOCOL_ID, "protocol_id")
    _require_exact(document["protocol_status"], "frozen", "protocol_status")
    _require_exact(document["protocol_scope"], FROZEN_PROTOCOL_SCOPE, "protocol_scope")
    _require_exact(document["changed_factor"], FROZEN_CHANGED_FACTOR, "changed_factor")
    try:
        approved = datetime.fromisoformat(str(document["approved_at"]))
    except ValueError as error:
        raise ProtocolNotFrozenError("approved_at must be an ISO-8601 timestamp") from error
    if approved.tzinfo is None or approved.utcoffset() is None:
        raise ProtocolNotFrozenError("approved_at must include a timezone offset")

    _require_exact(
        document["base_experiment_id"],
        "real_regime_parameter_calibration_development_screen_v02",
        "base_experiment_id",
    )
    _safe_repo_file(
        root,
        document["human_protocol_path"],
        document["human_protocol_sha256"],
        "human protocol",
    )
    _safe_repo_file(
        root,
        document["base_config_path"],
        document["base_config_sha256"],
        "base configuration",
    )

    fixed = document["fixed_factors"]
    for path_key, hash_key, label in (
        ("basin_manifest_path", "basin_manifest_sha256", "basin manifest"),
        ("development_universe_path", "development_universe_sha256", "development universe"),
        ("input_manifest_path", "input_manifest_sha256", "input manifest"),
        ("topography_path", "topography_sha256", "topography"),
    ):
        _safe_repo_file(root, fixed[path_key], fixed[hash_key], label)
    exact_fixed = {
        "basin_ids": ["04015330", "08109700", "11481200"],
        "forcing": "maurer",
        "potential_evapotranspiration_method": "oudin",
        "parameter_bounds_preset": "v5",
        "routing_kernel": "rising",
        "parameter_groups": ["all_flow", "low_flow", "high_flow"],
        "periods": {
            "warmup": {"start": "1998-10-01", "end": "1999-09-30"},
            "fit": {"start": "1999-10-01", "end": "2005-09-30", "expected_days": 2192},
            "validation": {
                "start": "2005-10-01",
                "end": "2008-09-30",
                "expected_days": 1096,
            },
            "forbidden_holdout": {"start": "1980-01-01", "end": "1989-09-30"},
        },
        "flow_regime_quantiles": {
            "low": 0.3,
            "high": 0.7,
            "method": "linear",
            "source_period": "fit",
        },
        "flow_log_offset_mm_day": 0.01,
        "coverage_policy": {
            "minimum_target_days_per_water_year": 30,
            "fit": {
                "minimum_total_target_days": 180,
                "minimum_qualifying_water_years": 4,
                "expected_water_years": 6,
            },
            "validation": {
                "minimum_total_target_days": 90,
                "minimum_qualifying_water_years": 2,
                "expected_water_years": 3,
            },
        },
        "optimizer": {
            "function_evaluations_per_restart": 5000,
            "evaluation_budget_semantics": {
                "config_field": "function_evaluations_per_restart",
                "pycma_option": "maxfevals",
                "declared_stop_threshold": 5000,
                "stop_check_boundary": "after_complete_generation",
                "actual_objective_calls_may_exceed_threshold": True,
                "actual_objective_call_count_authority": (
                    "restart_execution.csv:objective_call_count"
                ),
            },
            "restart_seeds": [42, 1042, 2042],
            "selection_period": "fit",
            "selection_rule": "minimum_fit_objective_loss",
            "validation_may_promote_restart": False,
            "expected_restart_count": 27,
        },
        "validation_gates": {
            "target_relative_improvement_min": 0.05,
            "minimum_improved_water_years": 2,
            "all_flow_nse_drop_max": 0.03,
            "opposite_regime_relative_degradation_max": 0.2,
            "must_beat_other_specialist": True,
        },
        "parameter_range_gates": {
            "near_boundary_fraction": 0.01,
            "strongly_saturated_fraction": 0.001,
            "maximum_near_boundary_parameters": 2,
            "maximum_strongly_saturated_parameters": 1,
            "applies_to_selected_vectors": True,
            "applies_to_support_restarts": True,
            "cross_basin_same_side_fraction": 0.01,
            "cross_basin_same_side_saturation_fails": True,
        },
        "cross_basin_gates": {
            "all_generalist_groups_must_pass": True,
            "minimum_complete_candidate_groups": 2,
            "number_of_development_basins": 3,
        },
    }
    for key, expected in exact_fixed.items():
        _require_exact(fixed[key], expected, f"fixed_factors.{key}")

    stability = document["output_functional_stability"]
    exact_stability = {
        "comparison": "fit_selected_restart_to_each_additional_restart",
        "fit_loss_ratio_max": 1.05,
        "minimum_support_restarts": 1,
        "available_additional_restarts": 2,
        "maximum_distance": 0.03,
        "comparison_operator": "less_than_or_equal",
        "all_three_day_sets_must_pass": True,
        "day_sets": {
            "all_flow": {"transform": "identity"},
            "low_flow": {
                "transform": "log_q_plus_offset",
                "offset_mm_day": 0.01,
                "membership": "observed_flow_less_than_or_equal_to_fit_low_quantile",
            },
            "high_flow": {
                "transform": "identity",
                "membership": "observed_flow_greater_than_or_equal_to_fit_high_quantile",
            },
        },
        "numerator": (
            "validation_mean_squared_daily_difference_between_restart_and_selected_transformed_flows"
        ),
        "denominator": (
            "fit_population_variance_of_transformed_observed_flow_on_same_day_set"
        ),
        "variance_ddof": 0,
        "invalid_when_denominator_not_finite_positive": True,
        "invalid_when_prediction_nonfinite_or_negative": True,
        "parameter_distance": {
            "record": True,
            "qualification_gate": False,
            "second_version_threshold_recorded_for_audit": 0.2,
        },
    }
    _require_exact(stability, exact_stability, "output_functional_stability")
    _require_exact(
        document["evidence_contract"],
        {
            "restart_parameter_vector_rows": 27,
            "fit_restart_hydrograph_rows": 59184,
            "validation_restart_hydrograph_rows": 29592,
            "required_artifacts": [
                "restart_parameter_vectors.csv",
                "fit_restart_hydrographs.csv",
                "validation_restart_hydrographs.csv",
                "functional_stability_metrics.csv",
                "restart_execution.csv",
                "run_manifest.json",
                "run_events.jsonl",
                "stdout.log",
                "stderr.log",
                "python_packages.txt",
                "conda_explicit.txt",
            ],
            "same_parameter_fingerprint_required_across_artifacts": True,
            "independent_raw_recomputation_required": True,
            "telemetry_on_off_optimization_equivalence_required": True,
        },
        "evidence_contract",
    )
    _require_exact(
        document["lifecycle"],
        {
            "code_and_tests_before_registration": True,
            "real_optimizer_calls_before_registration": 0,
            "registration_must_be_atomic": True,
            "execution_requires_separate_user_authorization": True,
            "one_terminal_result_per_experiment_id": True,
        },
        "lifecycle",
    )
    _require_exact(
        document["interpretation_permissions"],
        {
            "fixed_parameter_continuous_replay_development": True,
            "online_parameter_switching": False,
            "filter_state_mapping": False,
            "parameter_identification": False,
            "process_noise_axis": False,
            "joint_parameter_process_noise_axis": False,
            "formal_holdout_evaluation": False,
            "scientific_claim": False,
        },
        "interpretation_permissions",
    )
    return json.loads(json.dumps(document, allow_nan=False))


def load_frozen_protocol(
    repo_root: Path,
    credential_path: Path,
    *,
    expected_sha256: str | None = None,
) -> dict[str, Any]:
    """Load and validate a credential whose file digest is explicitly bound."""

    path = Path(credential_path).resolve()
    if not path.is_file():
        raise ProtocolNotFrozenError(f"protocol credential is missing: {path}")
    digest = _sha256(path)
    expected = FROZEN_PROTOCOL_SHA256 if expected_sha256 is None else str(expected_sha256).lower()
    if re.fullmatch(r"[0-9a-f]{64}", expected) is None or digest != expected:
        raise ProtocolNotFrozenError("protocol credential hash differs from the configuration")
    try:
        document = json.loads(
            path.read_text(encoding="utf-8"),
            parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)),
        )
    except (json.JSONDecodeError, ValueError) as error:
        raise ProtocolNotFrozenError("protocol credential is not strict finite JSON") from error
    return validate_protocol_document(Path(repo_root), document)


def validate_config_binding(repo_root: Path, config: Mapping[str, Any]) -> dict[str, Any]:
    """Require a runnable configuration to match the exact frozen credential."""

    if not isinstance(config, Mapping):
        raise ProtocolNotFrozenError("configuration must be a mapping")
    required = {
        "protocol_id",
        "protocol_scope",
        "protocol_credential",
        "protocol_credential_sha256",
    }
    missing = sorted(required - set(config))
    if missing:
        raise ProtocolNotFrozenError(f"configuration lacks protocol binding fields: {missing}")
    _require_exact(config["protocol_id"], FROZEN_PROTOCOL_ID, "configuration protocol_id")
    _require_exact(config["protocol_scope"], FROZEN_PROTOCOL_SCOPE, "configuration protocol_scope")
    relative = Path(str(config["protocol_credential"]))
    if relative.is_absolute() or ".." in relative.parts:
        raise ProtocolNotFrozenError("configuration protocol credential path is unsafe")
    path = (Path(repo_root).resolve() / relative).resolve()
    credential = load_frozen_protocol(
        Path(repo_root),
        path,
        expected_sha256=str(config["protocol_credential_sha256"]),
    )
    return credential


def validate_v03_registration_config(
    repo_root: Path,
    config: Mapping[str, Any],
) -> dict[str, Any]:
    """Prove that a proposed v03 config changes only the frozen support rule."""

    root = Path(repo_root).resolve()
    credential = validate_config_binding(root, config)
    base_path = _safe_repo_file(
        root,
        credential["base_config_path"],
        credential["base_config_sha256"],
        "base configuration",
    )
    try:
        base = json.loads(
            base_path.read_text(encoding="utf-8"),
            parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)),
        )
    except (json.JSONDecodeError, ValueError) as error:
        raise ProtocolNotFrozenError("base configuration is not strict finite JSON") from error
    if type(base) is not dict:
        raise ProtocolNotFrozenError("base configuration must be a mapping")
    _reject_incomplete(base, "base configuration")
    expected = json.loads(json.dumps(base, allow_nan=False))
    expected["experiment_id"] = "real_regime_parameter_calibration_development_screen_v03"
    expected["parameter_quality_gates"] = {
        "generalist_nse_min": 0.30,
        "support_fit_loss_ratio_max": 1.05,
        "support_output_functional_distance_max": 0.03,
        "diagnostic_parameter_distance_reference": 0.20,
        "maximum_near_boundary_parameters": 2,
        "maximum_strongly_saturated_parameters": 1,
        "minimum_support_restarts": 1,
    }
    expected.update({
        "protocol_id": FROZEN_PROTOCOL_ID,
        "protocol_scope": FROZEN_PROTOCOL_SCOPE,
        "protocol_credential": (
            "src/camels_switch_confirmation/protocols/"
            "real_regime_parameter_output_functional_stability_v03.freeze.json"
        ),
        "protocol_credential_sha256": FROZEN_PROTOCOL_SHA256,
    })
    try:
        _require_strict_tree(config, expected, "proposed v03 configuration")
    except ProtocolNotFrozenError as error:
        raise ProtocolNotFrozenError(
            "proposed v03 configuration differs outside the frozen single-factor contract: "
            + str(error)
        ) from error
    return credential


def canonical_v03_config_payload(repo_root: Path, config: Mapping[str, Any]) -> bytes:
    """Return the only byte representation accepted for a new v03 configuration."""

    validate_v03_registration_config(Path(repo_root), config)
    try:
        text = json.dumps(
            config,
            indent=2,
            sort_keys=True,
            ensure_ascii=False,
            allow_nan=False,
        ) + "\n"
    except (TypeError, ValueError) as error:
        raise ProtocolNotFrozenError("configuration is not strict finite JSON") from error
    return text.encode("utf-8")


def _repo_relative_path(repo_root: Path, path: Path, label: str) -> str:
    resolved = Path(path).resolve()
    try:
        relative = resolved.relative_to(Path(repo_root).resolve())
    except ValueError as error:
        raise ProtocolNotFrozenError(f"{label} path leaves the repository") from error
    return relative.as_posix()


def _validated_registration_timestamp(value: Any) -> str:
    if type(value) is not str:
        raise ProtocolNotFrozenError("registry updated_at must be a string")
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError as error:
        raise ProtocolNotFrozenError("registry updated_at must be an ISO-8601 timestamp") from error
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ProtocolNotFrozenError("registry updated_at must include a timezone offset")
    return value


def build_v03_registry_row(
    repo_root: Path,
    config: Mapping[str, Any],
    config_path: Path,
    *,
    updated_at: str | None = None,
) -> dict[str, str]:
    """Build the complete registry row bound to the canonical config payload."""

    root = Path(repo_root).resolve()
    credential = validate_v03_registration_config(root, config)
    config_relative = _repo_relative_path(root, Path(config_path), "configuration")
    if config_relative != V03_CONFIG_RELATIVE_PATH:
        raise ProtocolNotFrozenError(
            f"configuration path must remain {V03_CONFIG_RELATIVE_PATH}"
        )
    manifest_relative = Path(str(config["basin_manifest"])).as_posix()
    if manifest_relative != credential["fixed_factors"]["basin_manifest_path"]:
        raise ProtocolNotFrozenError("configuration basin manifest differs from the credential")
    manifest = _safe_repo_file(
        root,
        manifest_relative,
        credential["fixed_factors"]["basin_manifest_sha256"],
        "basin manifest",
    )
    output = (root / str(config["results_root"]) / str(config["experiment_id"])).resolve()
    output_relative = _repo_relative_path(root, output, "output")
    registered_at = _validated_registration_timestamp(
        datetime.now().astimezone().isoformat() if updated_at is None else updated_at
    )
    payload = canonical_v03_config_payload(root, config)
    row = {
        "experiment_id": str(config["experiment_id"]),
        "classification": "development_screen",
        "hypothesis": V03_REGISTRY_HYPOTHESIS,
        "config_path": config_relative,
        "config_sha256": hashlib.sha256(payload).hexdigest(),
        "basin_manifest": manifest_relative,
        "basin_manifest_sha256": _sha256(manifest),
        "changed_factor": FROZEN_CHANGED_FACTOR,
        "fixed_factors": V03_REGISTRY_FIXED_FACTORS,
        "restart_seeds": ";".join(str(seed) for seed in config["optimizer"]["restart_seeds"]),
        "status": "registered_not_run",
        "output_dir": output_relative,
        "metrics_path": "validation_metrics.csv",
        "paper_name": "development_only",
        "notes": V03_REGISTRY_NOTES,
        "updated_at": registered_at,
        "error": "",
    }
    return {column: row[column] for column in V03_REGISTRY_COLUMNS}


def _validate_v03_registry_row(
    repo_root: Path,
    config: Mapping[str, Any],
    config_path: Path,
    registry_row: Mapping[str, Any],
) -> dict[str, str]:
    if type(registry_row) is not dict:
        raise ProtocolNotFrozenError("registry row must be a plain mapping")
    if set(registry_row) != set(V03_REGISTRY_COLUMNS):
        missing = sorted(set(V03_REGISTRY_COLUMNS) - set(registry_row))
        extra = sorted(set(registry_row) - set(V03_REGISTRY_COLUMNS))
        raise ProtocolNotFrozenError(
            f"registry row fields differ; missing={missing}, extra={extra}"
        )
    for column, value in registry_row.items():
        if type(value) is not str or "\r" in value or "\n" in value:
            raise ProtocolNotFrozenError(
                f"registry row {column} must be a single-line string"
            )
    updated_at = _validated_registration_timestamp(registry_row["updated_at"])
    expected = build_v03_registry_row(
        repo_root,
        config,
        config_path,
        updated_at=updated_at,
    )
    try:
        _require_strict_tree(dict(registry_row), expected, "registry row")
    except ProtocolNotFrozenError as error:
        raise ProtocolNotFrozenError(f"registry row is not canonical: {error}") from error
    return expected


def _parse_registry_exact(raw: bytes) -> tuple[bytes, list[dict[str, str]], str]:
    if not raw.endswith(b"\n"):
        raise ProtocolNotFrozenError(
            "registry must already end with a line terminator before byte-preserving append"
        )
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ProtocolNotFrozenError("registry must be strict UTF-8") from error
    if b"\r\n" in raw:
        remainder = raw.replace(b"\r\n", b"")
        if b"\r" in remainder or b"\n" in remainder:
            raise ProtocolNotFrozenError("registry uses mixed line terminators")
        line_terminator = "\r\n"
    else:
        if b"\r" in raw:
            raise ProtocolNotFrozenError("registry uses an unsupported line terminator")
        line_terminator = "\n"
    try:
        records = list(csv.reader(io.StringIO(text, newline=""), strict=True))
    except csv.Error as error:
        raise ProtocolNotFrozenError("registry is not strict comma-separated values") from error
    if not records or tuple(records[0]) != V03_REGISTRY_COLUMNS:
        raise ProtocolNotFrozenError("registry columns or column order differ from the contract")
    rows: list[dict[str, str]] = []
    for row_index, values in enumerate(records[1:], start=2):
        if len(values) != len(V03_REGISTRY_COLUMNS):
            raise ProtocolNotFrozenError(f"registry row {row_index} has the wrong field count")
        if any("\r" in value or "\n" in value for value in values):
            raise ProtocolNotFrozenError(
                f"registry row {row_index} contains an embedded line break"
            )
        rows.append(dict(zip(V03_REGISTRY_COLUMNS, values)))
    identifiers = [row["experiment_id"] for row in rows]
    if len(set(identifiers)) != len(identifiers):
        raise ProtocolNotFrozenError("registry contains duplicate experiment identifiers")
    return raw, rows, line_terminator


def _read_registry_exact(path: Path) -> tuple[bytes, list[dict[str, str]], str]:
    """Read a registry without following a final symbolic link or reparse point."""

    return _parse_registry_exact(_read_regular_file_nofollow(Path(path), "registry"))


def _registry_append_bytes(registry_row: Mapping[str, str], line_terminator: str) -> bytes:
    output = io.StringIO(newline="")
    writer = csv.writer(output, lineterminator=line_terminator, quoting=csv.QUOTE_MINIMAL)
    writer.writerow([registry_row[column] for column in V03_REGISTRY_COLUMNS])
    encoded = output.getvalue().encode("utf-8")
    parsed = list(
        csv.reader(io.StringIO(encoded.decode("utf-8"), newline=""), strict=True)
    )
    expected = [registry_row[column] for column in V03_REGISTRY_COLUMNS]
    if parsed != [expected]:
        raise ProtocolNotFrozenError("registry append must encode exactly one canonical row")
    return encoded


def _byte_identity(value: bytes) -> dict[str, Any]:
    return {"size": len(value), "sha256": hashlib.sha256(value).hexdigest()}


_WINDOWS_REPARSE_POINT = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)


def _lexists(path: Path) -> bool:
    """Return true for every directory entry, including dangling links."""

    return os.path.lexists(os.fspath(path))


def _is_link_or_reparse(metadata: os.stat_result) -> bool:
    return stat.S_ISLNK(metadata.st_mode) or bool(
        getattr(metadata, "st_file_attributes", 0) & _WINDOWS_REPARSE_POINT
    )


def _lexical_absolute(path: Path) -> Path:
    """Make a path absolute without resolving its final directory entry."""

    return Path(os.path.abspath(os.fspath(path)))


def _validate_auxiliary_parent(repo_root: Path, path: Path, label: str) -> Path:
    """Require an existing parent whose resolved location remains in the repository."""

    root = Path(repo_root).resolve()
    candidate = _lexical_absolute(Path(path))
    try:
        parent = candidate.parent.resolve(strict=True)
    except (FileNotFoundError, OSError) as error:
        raise ProtocolNotFrozenError(f"{label} parent is missing") from error
    try:
        parent.relative_to(root)
    except ValueError as error:
        raise ProtocolNotFrozenError(
            f"{label} parent resolves outside the repository"
        ) from error
    if not parent.is_dir():
        raise ProtocolNotFrozenError(f"{label} parent is not a directory")
    return candidate


def _lstat_regular(path: Path, label: str, *, required: bool = True) -> os.stat_result | None:
    """Inspect a lexical entry and reject symbolic links and Windows reparse points."""

    candidate = Path(path)
    try:
        metadata = os.lstat(candidate)
    except FileNotFoundError:
        if _lexists(candidate):
            raise ProtocolNotFrozenError(f"{label} changed during lexical inspection")
        if required:
            raise FileNotFoundError(f"{label} is missing: {candidate}")
        return None
    if _is_link_or_reparse(metadata):
        raise ProtocolNotFrozenError(f"{label} must not be a symbolic link or reparse point")
    if not stat.S_ISREG(metadata.st_mode):
        raise ProtocolNotFrozenError(f"{label} must be a regular file")
    return metadata


def _assert_absent_entry(path: Path, label: str) -> None:
    """Require lexical absence; dangling links count as occupied unsafe entries."""

    if not _lexists(path):
        return
    metadata = os.lstat(path)
    if _is_link_or_reparse(metadata):
        raise ProtocolNotFrozenError(f"{label} must not be a symbolic link or reparse point")
    raise FileExistsError(f"{label} already exists: {path}")


def _open_regular_nofollow(path: Path, flags: int, label: str) -> int:
    """Open an existing regular file and prove the lexical entry was not swapped."""

    before = _lstat_regular(path, label)
    open_flags = flags | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(path, open_flags)
    try:
        opened = os.fstat(descriptor)
        after = _lstat_regular(path, label)
        if not stat.S_ISREG(opened.st_mode):
            raise ProtocolNotFrozenError(f"{label} opened object is not a regular file")
        if not os.path.samestat(before, opened) or not os.path.samestat(after, opened):
            raise ProtocolNotFrozenError(f"{label} changed while it was opened")
        return descriptor
    except Exception:
        os.close(descriptor)
        raise


def _read_regular_file_nofollow(path: Path, label: str) -> bytes:
    descriptor = _open_regular_nofollow(Path(path), os.O_RDONLY, label)
    try:
        chunks: list[bytes] = []
        while True:
            block = os.read(descriptor, 1024 * 1024)
            if not block:
                break
            chunks.append(block)
        return b"".join(chunks)
    finally:
        os.close(descriptor)


def _path_identity(path: Path, label: str = "transaction path") -> dict[str, Any] | None:
    if not _lexists(path):
        return None
    return _byte_identity(_read_regular_file_nofollow(Path(path), label))


def _identity_matches(path: Path, identity: Mapping[str, Any], label: str = "transaction path") -> bool:
    return _path_identity(path, label) == dict(identity)


def _assert_open_path_same(path: Path, handle, label: str) -> None:
    current = _lstat_regular(path, label)
    opened = os.fstat(handle.fileno())
    if not os.path.samestat(current, opened):
        raise ProtocolNotFrozenError(f"{label} path no longer names the locked file")


@contextmanager
def _exclusive_registry_registration_lock(registry: Path):
    """Lock the real registry file, not a replaceable sidecar lock anchor."""

    registry = _lexical_absolute(Path(registry))
    descriptor = _open_regular_nofollow(registry, os.O_RDWR, "registry")
    try:
        handle = os.fdopen(descriptor, "r+b", buffering=0)
    except Exception:
        os.close(descriptor)
        raise
    locked = False
    try:
        handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            locked = True
        except OSError as error:
            raise FileExistsError(
                f"registry registration lock is already held: {registry}"
            ) from error
        _assert_open_path_same(registry, handle, "registry")
        yield handle
    finally:
        try:
            if locked:
                handle.seek(0)
                if os.name == "nt":
                    import msvcrt

                    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        finally:
            handle.close()


def _transaction_paths(
    target_config: Path,
    registry: Path,
    transaction_id: str,
) -> dict[str, Path]:
    return {
        "journal": registry.with_name(registry.name + ".registration.journal.json"),
        "journal_temporary": registry.with_name(
            registry.name + ".registration.journal.json.tmp"
        ),
        "config_stage": target_config.with_name(
            f".{target_config.name}.{transaction_id}.registration.stage"
        ),
        "registry_stage": registry.with_name(
            f".{registry.name}.{transaction_id}.registration.stage"
        ),
        "config_install": target_config.with_name(
            target_config.name + ".registration.install"
        ),
        "registry_install": registry.with_name(registry.name + ".registration.install"),
    }


def _write_all(descriptor: int, value: bytes) -> None:
    view = memoryview(value)
    while view:
        written = os.write(descriptor, view)
        if written <= 0:
            raise OSError("durable write made no progress")
        view = view[written:]


def _write_durable_bytes(path: Path, value: bytes, *, exclusive: bool = False) -> None:
    """Write without following a final link; transaction writes are exclusive."""

    candidate = Path(path)
    flags = os.O_WRONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    if exclusive:
        _assert_absent_entry(candidate, "transaction artifact")
        flags |= os.O_CREAT | os.O_EXCL
    else:
        _lstat_regular(candidate, "transaction artifact")
        flags |= os.O_TRUNC
    descriptor = os.open(candidate, flags, 0o600)
    try:
        _write_all(descriptor, value)
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _unlink_regular(path: Path, label: str) -> None:
    if not _lexists(path):
        return
    _lstat_regular(path, label)
    os.unlink(path)


def _publish_config_payload_exclusive(
    payload: bytes,
    destination: Path,
    install: Path,
) -> None:
    """Atomically create an absent configuration from already-validated bytes."""

    _assert_absent_entry(destination, "configuration")
    _assert_absent_entry(install, "configuration install")
    _write_durable_bytes(install, payload, exclusive=True)
    try:
        # This hard link is an atomic absent-only publication. It cannot
        # replace a configuration that appears after the preceding check.
        os.link(install, destination, follow_symlinks=False)
    except Exception:
        # Retain the install and immutable stages as recovery evidence.
        raise
    if _path_identity(destination, "published configuration") != _byte_identity(payload):
        raise ProtocolNotFrozenError("published configuration hash differs")
    _unlink_regular(install, "configuration install")


def _write_transaction_journal(path: Path, document: Mapping[str, Any]) -> None:
    """Create the journal once; recovery uses identities rather than its phase."""

    temporary = path.with_name(path.name + ".tmp")
    payload = (
        json.dumps(document, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        + "\n"
    ).encode("utf-8")
    _assert_absent_entry(path, "registration journal")
    _assert_absent_entry(temporary, "registration journal temporary")
    _write_durable_bytes(temporary, payload, exclusive=True)
    try:
        os.link(temporary, path, follow_symlinks=False)
    except Exception:
        # A competing entry is unknown; retain the temporary evidence.
        raise
    _unlink_regular(temporary, "registration journal temporary")


def _cleanup_registration_transaction(
    journal: Path,
    paths: Mapping[str, Path],
) -> None:
    for key in (
        "config_stage",
        "registry_stage",
        "config_install",
        "registry_install",
        "journal_temporary",
    ):
        _unlink_regular(Path(paths[key]), f"registration {key}")
    _unlink_regular(Path(journal), "registration journal")


def _journal_identity(value: Any, label: str) -> dict[str, Any]:
    if type(value) is not dict or set(value) != {"size", "sha256"}:
        raise ProtocolNotFrozenError(f"{label} identity has the wrong fields")
    size = value["size"]
    digest = value["sha256"]
    if isinstance(size, bool) or not isinstance(size, int) or size < 0:
        raise ProtocolNotFrozenError(f"{label} size is invalid")
    if type(digest) is not str or re.fullmatch(r"[0-9a-f]{64}", digest) is None:
        raise ProtocolNotFrozenError(f"{label} digest is invalid")
    return {"size": size, "sha256": digest}


def _repo_relative_auxiliary(repo_root: Path, path: Path, label: str) -> str:
    root = Path(repo_root).resolve()
    candidate = _validate_auxiliary_parent(root, path, label)
    try:
        return candidate.relative_to(root).as_posix()
    except ValueError as error:
        raise ProtocolNotFrozenError(f"{label} path leaves the repository") from error


def _load_registration_journal(
    repo_root: Path,
    registry: Path,
) -> tuple[dict[str, Any], dict[str, Path]] | None:
    root = Path(repo_root).resolve()
    fixed_journal = registry.with_name(registry.name + ".registration.journal.json")
    temporary = fixed_journal.with_name(fixed_journal.name + ".tmp")
    _validate_auxiliary_parent(root, fixed_journal, "registration journal")
    _validate_auxiliary_parent(root, temporary, "registration journal temporary")
    journal_present = _lexists(fixed_journal)
    temporary_present = _lexists(temporary)
    if temporary_present:
        temporary_bytes = _read_regular_file_nofollow(
            temporary, "registration journal temporary"
        )
        if journal_present:
            journal_bytes = _read_regular_file_nofollow(
                fixed_journal, "registration journal"
            )
            if temporary_bytes != journal_bytes:
                raise ProtocolNotFrozenError(
                    "registration journal and temporary have unknown identities; "
                    "evidence retained"
                )
            _unlink_regular(temporary, "registration journal temporary")
        else:
            _assert_absent_entry(fixed_journal, "registration journal")
            os.link(temporary, fixed_journal, follow_symlinks=False)
            _unlink_regular(temporary, "registration journal temporary")
            journal_present = True
    if not journal_present:
        return None
    payload = _read_regular_file_nofollow(fixed_journal, "registration journal")
    try:
        document = json.loads(
            payload.decode("utf-8"),
            parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)),
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
        raise ProtocolNotFrozenError(
            "registration journal is not strict finite JSON"
        ) from error
    expected_keys = {
        "schema_version",
        "transaction_id",
        "phase",
        "experiment_id",
        "config_path",
        "registry_path",
        "config_stage_path",
        "registry_stage_path",
        "config_after",
        "registry_before",
        "registry_append",
        "registry_after",
    }
    if type(document) is not dict or set(document) != expected_keys:
        raise ProtocolNotFrozenError("registration journal fields differ from the contract")
    if type(document["schema_version"]) is not int or document["schema_version"] != 1:
        raise ProtocolNotFrozenError("registration journal schema version is invalid")
    transaction_id = document["transaction_id"]
    if (
        type(transaction_id) is not str
        or re.fullmatch(r"[0-9a-f]{32}", transaction_id) is None
    ):
        raise ProtocolNotFrozenError(
            "registration journal transaction identifier is invalid"
        )
    if document["phase"] not in {
        "declared",
        "prepared",
        "config_visible",
        "committed",
    }:
        raise ProtocolNotFrozenError("registration journal phase is invalid")
    identifier = document["experiment_id"]
    if type(identifier) is not str or re.fullmatch(
        r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", identifier
    ) is None:
        raise ProtocolNotFrozenError(
            "registration journal experiment identifier is invalid"
        )
    if identifier != "real_regime_parameter_calibration_development_screen_v03":
        raise ProtocolNotFrozenError(
            "registration journal experiment identifier is noncanonical"
        )
    if document["config_path"] != V03_CONFIG_RELATIVE_PATH:
        raise ProtocolNotFrozenError(
            "registration journal names a noncanonical configuration"
        )
    config = _lexical_absolute(root / str(document["config_path"]))
    recorded_registry = _lexical_absolute(root / str(document["registry_path"]))
    if (
        _repo_relative_auxiliary(root, config, "journal configuration")
        != document["config_path"]
    ):
        raise ProtocolNotFrozenError(
            "registration journal configuration path is noncanonical"
        )
    if (
        _repo_relative_auxiliary(root, recorded_registry, "journal registry")
        != document["registry_path"]
    ):
        raise ProtocolNotFrozenError(
            "registration journal registry path is noncanonical"
        )
    if os.path.normcase(os.fspath(recorded_registry)) != os.path.normcase(
        os.fspath(registry)
    ):
        raise ProtocolNotFrozenError(
            "registration journal names a different registry"
        )
    paths = _transaction_paths(config, registry, transaction_id)
    for key, path in paths.items():
        _validate_auxiliary_parent(root, path, f"registration {key}")
    if document["config_stage_path"] != _repo_relative_auxiliary(
        root, paths["config_stage"], "journal configuration stage"
    ):
        raise ProtocolNotFrozenError(
            "registration journal configuration stage is noncanonical"
        )
    if document["registry_stage_path"] != _repo_relative_auxiliary(
        root, paths["registry_stage"], "journal registry stage"
    ):
        raise ProtocolNotFrozenError(
            "registration journal registry stage is noncanonical"
        )
    document["config_after"] = _journal_identity(
        document["config_after"], "journal configuration"
    )
    document["registry_before"] = _journal_identity(
        document["registry_before"], "journal old registry"
    )
    document["registry_after"] = _journal_identity(
        document["registry_after"], "journal new registry"
    )
    append = document["registry_append"]
    if (
        type(append) is not dict
        or set(append) != {"size", "sha256", "csv_record_count"}
    ):
        raise ProtocolNotFrozenError(
            "journal registry append identity has the wrong fields"
        )
    append_identity = _journal_identity(
        {"size": append["size"], "sha256": append["sha256"]},
        "journal registry append",
    )
    if (
        type(append["csv_record_count"]) is not int
        or append["csv_record_count"] != 1
    ):
        raise ProtocolNotFrozenError(
            "journal registry append must contain one record"
        )
    document["registry_append"] = {
        **append_identity,
        "csv_record_count": 1,
    }
    if document["registry_after"]["size"] != (
        document["registry_before"]["size"]
        + document["registry_append"]["size"]
    ):
        raise ProtocolNotFrozenError(
            "journal registry sizes do not form one append"
        )
    paths["journal"] = fixed_journal
    paths["journal_temporary"] = temporary
    paths["config"] = config
    return document, paths


def _read_locked_registry(handle, registry: Path) -> bytes:
    _assert_open_path_same(registry, handle, "registry")
    handle.seek(0)
    value = handle.read()
    _assert_open_path_same(registry, handle, "registry")
    return value


def _registry_transaction_state(
    current: bytes,
    before: bytes,
    append: bytes,
) -> str:
    if current == before:
        return "before"
    if current == before + append:
        return "after"
    if current.startswith(before):
        suffix = current[len(before):]
        if suffix and len(suffix) < len(append) and append.startswith(suffix):
            return "partial"
    return "unknown"


def _verify_new_registry_identity(
    value: bytes,
    document: Mapping[str, Any],
) -> None:
    before_size = int(document["registry_before"]["size"])
    prefix = value[:before_size]
    suffix = value[before_size:]
    if (
        _byte_identity(value) != document["registry_after"]
        or _byte_identity(prefix) != document["registry_before"]
        or _byte_identity(suffix)
        != {
            "size": document["registry_append"]["size"],
            "sha256": document["registry_append"]["sha256"],
        }
    ):
        raise ProtocolNotFrozenError(
            "new registry does not preserve the complete old-byte prefix plus one append"
        )


def _journal_expected_material(
    document: Mapping[str, Any],
    current_registry: bytes,
    payload: bytes,
    canonical_row: Mapping[str, str],
) -> tuple[bytes, bytes]:
    """Bind recovery to the caller's exact timestamped canonical registry row."""

    if document["config_after"] != _byte_identity(payload):
        raise ProtocolNotFrozenError(
            "registration recovery configuration differs from the caller; "
            "evidence retained"
        )
    before_size = int(document["registry_before"]["size"])
    if len(current_registry) < before_size:
        raise ProtocolNotFrozenError(
            "registration recovery found a registry with an unknown identity; "
            "evidence retained"
        )
    before = current_registry[:before_size]
    if _byte_identity(before) != document["registry_before"]:
        raise ProtocolNotFrozenError(
            "registration recovery found a registry with an unknown identity; "
            "evidence retained"
        )
    _, _, line_terminator = _parse_registry_exact(before)
    append = _registry_append_bytes(canonical_row, line_terminator)
    append_identity = {
        **_byte_identity(append),
        "csv_record_count": 1,
    }
    if append_identity != document["registry_append"]:
        raise ProtocolNotFrozenError(
            "registration recovery append differs from the caller canonical row; "
            "evidence retained"
        )
    if _byte_identity(before + append) != document["registry_after"]:
        raise ProtocolNotFrozenError(
            "registration recovery after-identity differs from the caller append; "
            "evidence retained"
        )
    return before, append


def _stage_bytes(
    stage: Path,
    identity: Mapping[str, Any],
    label: str,
) -> bytes:
    if not _lexists(stage):
        raise ProtocolNotFrozenError(f"{label} recovery stage is missing")
    value = _read_regular_file_nofollow(
        stage, f"{label} recovery stage"
    )
    if _byte_identity(value) != dict(identity):
        raise ProtocolNotFrozenError(f"{label} recovery stage hash differs")
    return value


def _append_registry_suffix(
    handle,
    registry: Path,
    before: bytes,
    append: bytes,
) -> None:
    """Append only the missing canonical suffix under the real registry lock."""

    current = _read_locked_registry(handle, registry)
    state = _registry_transaction_state(current, before, append)
    if state == "after":
        return
    if state not in {"before", "partial"}:
        raise ProtocolNotFrozenError(
            "registration found an unknown registry identity; evidence retained"
        )
    already = len(current) - len(before)
    remaining = append[already:]
    handle.seek(0, os.SEEK_END)
    view = memoryview(remaining)
    while view:
        written = handle.write(view)
        if written is None or written <= 0:
            raise OSError("registry append made no progress")
        view = view[written:]
    handle.flush()
    os.fsync(handle.fileno())
    if _read_locked_registry(handle, registry) != before + append:
        raise ProtocolNotFrozenError(
            "registry append did not produce the exact old prefix plus "
            "canonical suffix"
        )


def _recover_registration_transaction(
    repo_root: Path,
    registry: Path,
    registry_handle,
    payload: bytes,
    canonical_row: Mapping[str, str],
) -> dict[str, Any] | None:
    loaded = _load_registration_journal(repo_root, registry)
    if loaded is None:
        return None
    document, paths = loaded
    current_registry = _read_locked_registry(registry_handle, registry)
    before, append = _journal_expected_material(
        document,
        current_registry,
        payload,
        canonical_row,
    )
    registry_state = _registry_transaction_state(
        current_registry,
        before,
        append,
    )
    if registry_state == "unknown":
        raise ProtocolNotFrozenError(
            "registration recovery found a registry with an unknown identity; "
            "evidence retained"
        )
    config_identity = _path_identity(
        paths["config"], "recovery configuration"
    )
    if config_identity is None:
        config_state = "absent"
    elif config_identity == document["config_after"]:
        config_state = "after"
    else:
        raise ProtocolNotFrozenError(
            "registration recovery found a configuration with an unknown "
            "identity; evidence retained"
        )

    if (registry_state, config_state) == ("before", "absent"):
        _cleanup_registration_transaction(paths["journal"], paths)
        return {"status": "rolled_back", **document}
    if registry_state in {"before", "partial"} and config_state == "after":
        if _read_regular_file_nofollow(
            paths["config"], "recovery configuration"
        ) != payload:
            raise ProtocolNotFrozenError(
                "recovery configuration bytes differ"
            )
        staged_append = _stage_bytes(
            paths["registry_stage"],
            {
                "size": document["registry_append"]["size"],
                "sha256": document["registry_append"]["sha256"],
            },
            "registry",
        )
        if staged_append != append:
            raise ProtocolNotFrozenError(
                "registry recovery stage differs from caller append"
            )
        _append_registry_suffix(
            registry_handle,
            registry,
            before,
            staged_append,
        )
    elif registry_state == "after" and config_state == "absent":
        staged_config = _stage_bytes(
            paths["config_stage"],
            document["config_after"],
            "configuration",
        )
        if staged_config != payload:
            raise ProtocolNotFrozenError(
                "configuration recovery stage differs from caller payload"
            )
        _publish_config_payload_exclusive(
            staged_config,
            paths["config"],
            paths["config_install"],
        )
    elif registry_state == "after" and config_state == "after":
        if _read_regular_file_nofollow(
            paths["config"], "recovery configuration"
        ) != payload:
            raise ProtocolNotFrozenError(
                "recovery configuration bytes differ"
            )
    else:
        raise ProtocolNotFrozenError(
            "registration recovery state is unsupported; evidence retained"
        )

    final_registry = _read_locked_registry(registry_handle, registry)
    _verify_new_registry_identity(final_registry, document)
    if not _identity_matches(
        paths["config"],
        document["config_after"],
        "recovery configuration",
    ):
        raise ProtocolNotFrozenError(
            "registration recovery could not restore the configuration"
        )
    _cleanup_registration_transaction(paths["journal"], paths)
    return {"status": "committed", **document}


def _truncate_owned_partial_append(
    handle,
    registry: Path,
    before: bytes,
    append: bytes,
) -> None:
    current = _read_locked_registry(handle, registry)
    state = _registry_transaction_state(current, before, append)
    if state == "before":
        return
    if state != "partial":
        raise ProtocolNotFrozenError(
            "same-process rollback found an unknown registry identity; "
            "evidence retained"
        )
    handle.truncate(len(before))
    handle.flush()
    os.fsync(handle.fileno())
    if _read_locked_registry(handle, registry) != before:
        raise ProtocolNotFrozenError(
            "same-process registry rollback did not restore old bytes"
        )


def _rollback_registration_transaction(
    registry: Path,
    registry_handle,
    document: Mapping[str, Any],
    paths: Mapping[str, Path],
    before: bytes,
    append: bytes,
    *,
    config_published: bool,
) -> bool:
    """Rollback only bytes and files proven to belong to this process."""

    registry_bytes = _read_locked_registry(registry_handle, registry)
    registry_state = _registry_transaction_state(
        registry_bytes,
        before,
        append,
    )
    config_identity = _path_identity(
        paths["config"], "configuration"
    )
    if (
        registry_state == "after"
        and config_identity == document["config_after"]
    ):
        _cleanup_registration_transaction(paths["journal"], paths)
        return True
    if registry_state not in {"before", "partial"}:
        raise ProtocolNotFrozenError(
            "same-process rollback found an unknown registry identity; "
            "evidence retained"
        )
    if config_published:
        if config_identity != document["config_after"]:
            raise ProtocolNotFrozenError(
                "same-process rollback refuses to remove an unknown "
                "configuration; evidence retained"
            )
    elif config_identity is not None:
        raise ProtocolNotFrozenError(
            "same-process rollback found a concurrently created configuration; "
            "evidence retained"
        )
    _truncate_owned_partial_append(
        registry_handle,
        registry,
        before,
        append,
    )
    if config_published:
        _unlink_regular(paths["config"], "published configuration")
    _cleanup_registration_transaction(paths["journal"], paths)
    return False


def _entry_exists_fail_closed(path: Path, label: str) -> bool:
    if not _lexists(path):
        return False
    metadata = os.lstat(path)
    if _is_link_or_reparse(metadata):
        raise ProtocolNotFrozenError(
            f"{label} must not be a symbolic link or reparse point"
        )
    return True


def register_frozen_protocol_atomically(
    repo_root: Path,
    config: Mapping[str, Any],
    config_path: Path,
    registry_path: Path,
    registry_row: Mapping[str, Any],
) -> str:
    """Register v03 with an absent-only config create and locked registry append."""

    root = Path(repo_root).resolve()
    payload = canonical_v03_config_payload(root, config)
    identifier = str(config.get("experiment_id", ""))
    if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", identifier) is None:
        raise ProtocolNotFrozenError("experiment_id is invalid")
    target_config = _validate_auxiliary_parent(
        root,
        _lexical_absolute(Path(config_path)),
        "configuration",
    )
    registry = _validate_auxiliary_parent(
        root,
        _lexical_absolute(Path(registry_path)),
        "registry",
    )
    config_relative = _repo_relative_auxiliary(
        root,
        target_config,
        "configuration",
    )
    if config_relative != V03_CONFIG_RELATIVE_PATH:
        raise ProtocolNotFrozenError(
            f"configuration path must remain {V03_CONFIG_RELATIVE_PATH}"
        )
    _lstat_regular(registry, "registry")
    declared_relative = Path(str(config["experiment_registry"]))
    if declared_relative.is_absolute() or ".." in declared_relative.parts:
        raise ProtocolNotFrozenError(
            "configuration registry path is not repository-relative"
        )
    declared_registry = _lexical_absolute(root / declared_relative)
    if os.path.normcase(os.fspath(registry)) != os.path.normcase(
        os.fspath(declared_registry)
    ):
        raise ProtocolNotFrozenError(
            "registry path differs from the configuration"
        )
    canonical_row = _validate_v03_registry_row(
        root,
        config,
        target_config,
        registry_row,
    )
    results_root = Path(str(config.get("results_root", "")))
    if not results_root.is_absolute():
        results_root = root / results_root
    output = _lexical_absolute(results_root / identifier)
    incomplete = output.with_name(output.name + ".incomplete")

    with _exclusive_registry_registration_lock(registry) as registry_handle:
        recovered = _recover_registration_transaction(
            root,
            registry,
            registry_handle,
            payload,
            canonical_row,
        )
        if recovered is not None and recovered["status"] == "committed":
            if (
                recovered["experiment_id"] != identifier
                or recovered["config_path"] != config_relative
                or recovered["config_after"] != _byte_identity(payload)
            ):
                raise ProtocolNotFrozenError(
                    "committed recovery identity differs from the caller; "
                    "evidence retained"
                )
            if (
                _entry_exists_fail_closed(
                    output, "final experiment output"
                )
                or _entry_exists_fail_closed(
                    incomplete, "incomplete experiment output"
                )
            ):
                raise FileExistsError(
                    "final or incomplete experiment output already exists"
                )
            return hashlib.sha256(payload).hexdigest()

        old_registry, rows, line_terminator = _parse_registry_exact(
            _read_locked_registry(registry_handle, registry)
        )
        _assert_absent_entry(target_config, "configuration")
        if identifier in {row["experiment_id"] for row in rows}:
            raise FileExistsError(
                f"experiment identifier already exists in registry: {identifier}"
            )
        if (
            _entry_exists_fail_closed(output, "final experiment output")
            or _entry_exists_fail_closed(
                incomplete, "incomplete experiment output"
            )
        ):
            raise FileExistsError(
                "final or incomplete experiment output already exists"
            )

        append = _registry_append_bytes(
            canonical_row,
            line_terminator,
        )
        next_registry = old_registry + append
        transaction_id = uuid.uuid4().hex
        if re.fullmatch(r"[0-9a-f]{32}", transaction_id) is None:
            raise ProtocolNotFrozenError(
                "generated registration transaction identifier is invalid"
            )
        paths = _transaction_paths(
            target_config,
            registry,
            transaction_id,
        )
        paths["config"] = target_config
        for key, path in paths.items():
            if key == "config":
                continue
            _validate_auxiliary_parent(
                root,
                path,
                f"registration {key}",
            )
            _assert_absent_entry(path, f"registration {key}")
        document: dict[str, Any] = {
            "schema_version": 1,
            "transaction_id": transaction_id,
            "phase": "declared",
            "experiment_id": identifier,
            "config_path": config_relative,
            "registry_path": _repo_relative_auxiliary(
                root, registry, "registry"
            ),
            "config_stage_path": _repo_relative_auxiliary(
                root,
                paths["config_stage"],
                "configuration stage",
            ),
            "registry_stage_path": _repo_relative_auxiliary(
                root,
                paths["registry_stage"],
                "registry stage",
            ),
            "config_after": _byte_identity(payload),
            "registry_before": _byte_identity(old_registry),
            "registry_append": {
                **_byte_identity(append),
                "csv_record_count": 1,
            },
            "registry_after": _byte_identity(next_registry),
        }
        journal_written = False
        config_published = False
        try:
            _write_transaction_journal(
                paths["journal"],
                document,
            )
            journal_written = True
            _write_durable_bytes(
                paths["config_stage"],
                payload,
                exclusive=True,
            )
            _write_durable_bytes(
                paths["registry_stage"],
                append,
                exclusive=True,
            )
            staged_config = _stage_bytes(
                paths["config_stage"],
                document["config_after"],
                "configuration",
            )
            staged_append = _stage_bytes(
                paths["registry_stage"],
                {
                    "size": document["registry_append"]["size"],
                    "sha256": document["registry_append"]["sha256"],
                },
                "registry",
            )
            _publish_config_payload_exclusive(
                staged_config,
                target_config,
                paths["config_install"],
            )
            config_published = True
            _append_registry_suffix(
                registry_handle,
                registry,
                old_registry,
                staged_append,
            )
            _verify_new_registry_identity(
                _read_locked_registry(registry_handle, registry),
                document,
            )
            _cleanup_registration_transaction(
                paths["journal"],
                paths,
            )
        except Exception:
            if not journal_written:
                raise
            committed = _rollback_registration_transaction(
                registry,
                registry_handle,
                document,
                paths,
                old_registry,
                append,
                config_published=config_published,
            )
            if committed:
                return document["config_after"]["sha256"]
            raise
    return hashlib.sha256(payload).hexdigest()
