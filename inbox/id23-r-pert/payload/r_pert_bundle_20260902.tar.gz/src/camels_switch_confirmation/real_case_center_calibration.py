"""Per-basin center-model calibration for the joint param-noise real-case line.

Implements Task 1 of docs/superpowers/plans/2026-08-25-joint-param-noise-real-case-runner.md.
The center model is one conventionally calibrated HBV-Lite parameter vector per basin
(window 1999-10-01..2008-09-30, NSE loss over all finite observation days, ten-year warmup
excluded), from which the 3x3 perturbation candidates are derived mechanically.

The loader is always invoked with the fixed 1989-10-01..2008-09-30 window, so no date in the
forbidden holdout 1980-01-01..1989-09-30 is ever requested by this module.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd

from hydroagent.data_loading import load_camels_basin
from scl_hydro.hbv_lite_cma_calibrate import calibrate_hbv_lite_cma

REPO_ROOT = Path(__file__).resolve().parents[2]
BOUNDS_CREDENTIAL = (
    REPO_ROOT / "src/camels_switch_confirmation/protocols/real_regime_parameter_k2_memory_v05.freeze.json"
)

LOAD_START = "1989-10-01"
LOAD_END = "2008-09-30"
WARMUP_END = pd.Timestamp("1999-09-30")
DEFAULT_RESTART_SEEDS = (42, 1042, 2042)
DEFAULT_FUNCTION_EVALUATIONS = 5000
MINIMUM_OBJECTIVE_DAYS = 730


def load_center_bounds() -> dict[str, tuple[float, float]]:
    """Return the frozen fifth-version parameter bounds used for center calibration."""
    credential = json.loads(BOUNDS_CREDENTIAL.read_text(encoding="utf-8"))
    bounds = credential["parameter_domain"]["bounds"]
    return {name: (float(pair[0]), float(pair[1])) for name, pair in bounds.items()}


def _masked_nse(observed: np.ndarray, simulated: np.ndarray, mask: np.ndarray) -> float:
    residual = observed[mask] - simulated[mask]
    anomaly = observed[mask] - float(np.mean(observed[mask]))
    denominator = float(np.sum(anomaly ** 2))
    if denominator <= 0.0:
        return float("nan")
    return 1.0 - float(np.sum(residual ** 2)) / denominator


def calibrate_center(
    basin_id: str,
    *,
    data_root: str | Path,
    n_trials: int = DEFAULT_FUNCTION_EVALUATIONS,
    restart_seeds: tuple[int, ...] = DEFAULT_RESTART_SEEDS,
    loader: Callable[..., tuple[pd.DataFrame, pd.Series, float]] = load_camels_basin,
    calibrator: Callable[..., dict[str, Any]] = calibrate_hbv_lite_cma,
    minimum_objective_days: int = MINIMUM_OBJECTIVE_DAYS,
) -> dict[str, Any]:
    """Calibrate one center parameter vector for one basin.

    Returns a JSON-serializable record with the selected parameter vector, the masked-day
    fit NSE recomputed independently of the calibrator, and restart provenance.
    """
    forcing, observations, area_km2 = loader(
        basin_id,
        data_root=str(data_root),
        start_date=LOAD_START,
        end_date=LOAD_END,
        forcing="maurer",
        pet_method="oudin",
        keep_obs_nan_days=True,
        strict_streamflow_window=True,
    )
    dates = forcing.index
    rain = forcing["prcp"].to_numpy(float)
    pet = forcing["ep"].to_numpy(float)
    temperature = forcing["tmean"].to_numpy(float)
    observed = observations.reindex(dates).to_numpy(float)

    objective_mask = np.asarray(dates > WARMUP_END, dtype=bool) & np.isfinite(observed)
    objective_days = int(objective_mask.sum())
    if objective_days < int(minimum_objective_days):
        raise ValueError(
            f"basin {basin_id} has {objective_days} objective days; "
            f"center calibration requires at least {int(minimum_objective_days)}"
        )

    bounds = load_center_bounds()
    telemetry: list[dict[str, Any]] = []
    result = calibrator(
        rain,
        pet,
        temperature,
        observed,
        n_trials=int(n_trials),
        n_restarts=len(restart_seeds),
        loss="nse",
        param_bounds=bounds,
        lag_kernel="rising",
        objective_mask=objective_mask,
        restart_seeds=[int(seed) for seed in restart_seeds],
        telemetry_collector=telemetry,
    )

    parameters = result.get("optimized_params")
    if not isinstance(parameters, dict) or not parameters:
        raise ValueError(f"basin {basin_id} center calibration returned empty optimized_params")
    for name, value in parameters.items():
        low, high = bounds[name]
        if not (low - 1e-9 <= float(value) <= high + 1e-9):
            raise ValueError(f"basin {basin_id} parameter {name}={value} escapes bounds [{low}, {high}]")

    simulated = np.asarray(result["qsim"], dtype=float)
    fit_nse = _masked_nse(observed, simulated, objective_mask)

    return {
        "basin_id": str(basin_id),
        "area_km2": float(area_km2),
        "load_window": {"start": LOAD_START, "end": LOAD_END},
        "warmup_end": "1999-09-30",
        "objective_days": objective_days,
        "parameters": {name: float(value) for name, value in parameters.items()},
        "objective_loss": float(result.get("objective_loss", float("nan"))),
        "fit_nse": float(fit_nse),
        "restart_seeds": [int(seed) for seed in restart_seeds],
        "selected_restart_seed": result.get("selected_restart_seed"),
        "function_evaluation_budget_per_restart": int(n_trials),
        "parameter_bounds_preset": "real_regime_k2_memory_v05",
    }
