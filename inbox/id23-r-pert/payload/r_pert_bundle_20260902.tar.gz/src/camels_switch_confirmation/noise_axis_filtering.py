"""Noise-axis filtering: the frozen forward model and filter with a pluggable noise source.

Design: docs/plans/2026-08-26-noise-axis-learned-noise-design-v02.md (step 1 of three).

The learned-noise line must compare a learning arm against the fixed reasonable cell
(``m1_c0``) without any other difference leaking in.  Design v02 section 6 requires the two
arms to share one forward model, one filter implementation and one holdout split, differing
only in *where the noise comes from*.  This module makes that literal: it reuses the frozen
stage-3 construction verbatim (``_load_real_task`` -> ``_make_real_estimator`` -> IMM step)
and factors out the per-day quantity step 2 learns -- the process covariance -- behind
:class:`NoiseSource`.

The observation covariance is factored out separately behind :class:`ObservationNoiseSource`
(R-perturbation prereg 2026-09-01, change 0.9).  It is a distinct protocol because R is *not*
a learning target: the R-perturbation line varies it as a fixed, preregistered setting while
step 2's Q search runs unchanged on top.  Callers that pass no ``r_source`` keep the frozen
construction's constant R untouched.

Step 1 therefore implements exactly one noise source, :class:`LegacyGridNoise`, which
reassembles the stage-3 ``_common_q`` two-scalar covariance.  Its purpose is the correctness
gate: with ``m=1, c=0`` this module must reproduce the stage-3 CTRL cell day by day.  The
step-2 seven-parameter group source is deliberately NOT implemented here -- its ranges and
anchors are undecided (design v02 section 9 items 3 and 4) and step 2 is not authorized.

Data boundary: the 1,260-day window is 1989-10-01..1993-03-13 on the 52 stage-3 admitted
basins, all inside the exposed development universe.  Nothing here can reach the sealed
1980-01-01..1989-09-30 holdout flows.
"""
from __future__ import annotations

import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

import numpy as np

_SRC = Path(__file__).resolve().parents[1]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation.g2_switch_confirmation import (  # noqa: E402
    N_STATE,
    assign_common_process_covariance,
    build_state_dependent_lower_groundwater_covariance,
)

# Index of the lower-groundwater (SLZ) state inside the 15-state vector; the stage-3 grid's
# ``m`` axis scales this state's process variance.
SLZ_INDEX = 4
# Index of the soil-moisture (SM) state; the stage-3 grid's ``c`` axis drives this state's
# process variance from the day's rainfall.
SM_INDEX = 2

STAGE3_CONTROL_ARM = "CTRL"

# R-perturbation prereg (2026-09-01, sha256 c9773ba1...2a2f5a) section 2.  SHAPE_FRACTION is
# the same 0.10 the frozen constant uses (``g1_precheck.SIGMA_OBS_FRACTION``); it is restated
# here rather than imported so the filtering module stays free of the precheck's data loading,
# and ``test_noise_axis_r_channel`` asserts the two never drift apart.
SHAPE_FRACTION = 0.10
# Audited ratio of the median daily error to sigma_obs (measured 2.48, rounded).
MAGNITUDE_MULTIPLIER = 2.5


class NoiseSource(Protocol):
    """The one quantity step 2 will learn: the filter's noise, rebuilt every day.

    Implementations must be deterministic and causal -- ``build_process_covariance`` may use
    the day-t *prior* state prediction and the day-t forcing (both known before the day-t
    observation is read), never the observation itself.
    """

    def build_process_covariance(self, predicted_state: np.ndarray, rain_today: float) -> np.ndarray:
        """Return the (N_STATE, N_STATE) process covariance for this day."""


class ObservationNoiseSource(Protocol):
    """The filter's observation-noise variance, rebuilt every day (R-perturbation prereg 3.1).

    Causality: an implementation may use the day-t forcing and observations through day t-1,
    never the day-t observation and never the filter's own belief.  ``prev_obs`` is therefore
    ``obs[day - 1]``; on ``day == 0`` it is not defined and callers pass NaN, which every
    implementation must handle by falling back to the frozen constant.
    """

    def observation_variance(self, sigma_obs: float, day: int, prev_obs: float) -> float:
        """Return the scalar observation-noise variance for this day."""


@dataclass(frozen=True)
class LegacyGridNoise:
    """The frozen stage-3 two-scalar noise cell, re-expressed as a noise source.

    Reproduces ``run_online_noise_pilot._common_q`` exactly: an SLZ process variance
    proportional to the predicted lower-groundwater state and scaled by ``m``, plus an SM
    process variance equal to ``(c * rain)**2``.  Only 2 of the 15 states carry noise, and at
    ``c=0`` only 1 does -- which is the "dimension is too narrow" hypothesis design v02
    section 3.3 raises against the stage-3 death cause.

    Observation noise is the frozen G1 precheck constant, unchanged by the cell.
    """

    m: float
    c: float

    def __post_init__(self) -> None:
        if not np.isfinite(self.m) or self.m <= 0.0:
            raise ValueError("grid m must be finite and positive")
        if not np.isfinite(self.c) or self.c < 0.0:
            raise ValueError("grid c must be finite and nonnegative")

    @property
    def cell_tag(self) -> str:
        return f"m{self.m:g}_c{self.c:g}"

    def build_process_covariance(self, predicted_state: np.ndarray, rain_today: float) -> np.ndarray:
        covariance = build_state_dependent_lower_groundwater_covariance(
            np.asarray(predicted_state, dtype=np.float64)[SLZ_INDEX], self.m
        )
        covariance[SM_INDEX, SM_INDEX] = (self.c * max(float(rain_today), 0.0))**2
        return covariance

@dataclass(frozen=True)
class LegacyConstantR:
    """R-old: the frozen G1 constant, unchanged by the day (prereg section 2)."""

    def observation_variance(self, sigma_obs: float, day: int, prev_obs: float) -> float:
        del day, prev_obs  # constant by construction
        return _checked_sigma(sigma_obs)**2


@dataclass(frozen=True)
class ShapePerturbedR:
    """R-shape (main variant): ``sigma_t = max(0.10 * y_{t-1}, sigma_old)``, day 0 = sigma_old.

    Only-upward by construction (the max keeps the frozen constant as a floor), which is the
    point: a plain linear ``0.10 * y_t`` shrinks R at the low-flow end and worsens the already
    measured overconfidence there.  ``y_{t-1}`` -- the previous day's *measured* discharge --
    keeps the rule causal and independent of the filter's own belief.
    """

    fraction: float = SHAPE_FRACTION

    def __post_init__(self) -> None:
        if not np.isfinite(self.fraction) or self.fraction <= 0.0:
            raise ValueError("shape fraction must be finite and positive")

    def observation_variance(self, sigma_obs: float, day: int, prev_obs: float) -> float:
        sigma_old = _checked_sigma(sigma_obs)
        if int(day) == 0:
            return sigma_old**2
        previous = float(prev_obs)
        if not np.isfinite(previous):
            raise ValueError(
                f"day {int(day)}: previous observation is not finite ({previous!r}); "
                "the R-shape rule has no registered fallback for gaps"
            )
        return max(self.fraction * previous, sigma_old)**2


@dataclass(frozen=True)
class MagnitudePerturbedR:
    """R-mag (decomposition arm): ``sigma = 2.5 * sigma_old``, constant (prereg section 2).

    2.5 is the audited ratio of the median daily error to sigma_obs (measured 2.48, rounded).
    This arm carries no gate; it exists only to separate shape from magnitude.
    """

    multiplier: float = MAGNITUDE_MULTIPLIER

    def __post_init__(self) -> None:
        if not np.isfinite(self.multiplier) or self.multiplier <= 0.0:
            raise ValueError("magnitude multiplier must be finite and positive")

    def observation_variance(self, sigma_obs: float, day: int, prev_obs: float) -> float:
        del day, prev_obs  # constant by construction
        return (self.multiplier * _checked_sigma(sigma_obs))**2


def _checked_sigma(sigma_obs: float) -> float:
    """Mirror ``g2_switch_confirmation.build_filter_observation_covariance``'s sigma check."""
    sigma = float(sigma_obs)
    if not np.isfinite(sigma) or sigma <= 0.0:
        raise ValueError("observation sigma must be finite and positive")
    return sigma


def assign_common_observation_covariance(estimator, variance: float) -> None:
    """Assign one identical (1, 1) observation covariance to every candidate.

    The daily-R twin of :func:`assign_common_process_covariance`.  It lives here rather than in
    ``g2_switch_confirmation`` on purpose: that module is the shared frozen machine behind a
    dozen registered artifacts and the R-perturbation prereg (change 0.3) forbids writing to it.
    """
    value = float(variance)
    if not np.isfinite(value) or value <= 0.0:
        raise ValueError("observation variance must be finite and positive")
    if not getattr(estimator, "filters", None):
        raise ValueError("estimator must contain at least one filter")
    matrix = np.array([[value]], dtype=np.float64)
    for candidate in estimator.filters:
        if candidate.observation_covariance.shape != (1, 1):
            raise ValueError(
                "daily R requires a scalar observation; got shape "
                f"{candidate.observation_covariance.shape}"
            )
        candidate.observation_covariance = matrix.copy()


def _assert_single_member(runtime_members: Any) -> None:
    """Stage-3 amendment 01b: the control bank holds exactly one member.

    A single member makes the interact-mixing step a one-addend product (bitwise exact) and
    the posterior structurally equal to 1.  The learned-noise line inherits that contract: the
    thing being compared is one calibrated model filtered, not a mixture.
    """
    if len(runtime_members) != 1:
        raise ValueError(f"noise-axis filtering requires a single-member bank, got {len(runtime_members)}")


def load_stage3_control_task(basin: str) -> dict:
    """Load one basin's frozen stage-3 control task (single center member, real observations)."""
    from camels_switch_confirmation.run_online_noise_real_obs import _load_real_task

    task = _load_real_task(basin, STAGE3_CONTROL_ARM)
    _assert_single_member(task["members"])
    return task


def build_runtime(task: dict, basin: str):
    """Build the frozen single-member estimator for one basin; no noise decision is made here."""
    from camels_switch_confirmation.run_online_noise_real_obs import _make_real_estimator

    _assert_single_member(task["members"])
    return _make_real_estimator(task, basin, STAGE3_CONTROL_ARM)


def run_noise_axis_filter(
    task: dict,
    basin: str,
    noise: NoiseSource,
    r_source: ObservationNoiseSource | None = None,
) -> dict:
    """Run one basin continuously under one noise source; return daily causal forecasts.

    Causality: the day-t process covariance is built from the day-t prior state prediction and
    the day-t forcing, and the day-t forecast is read off the estimator's *prior* combined
    observation, so both depend on discharge through day t-1 only.  This is the same order the
    frozen stage-3 runner uses.

    ``r_source`` is the R-perturbation channel (prereg change 0.9).  Left at ``None`` the
    observation covariance stays exactly as the frozen construction built it -- that is the
    path every pre-existing caller takes, and the A0 parity arm proves it is bit-identical to
    the frozen artefacts.  Supplied, the day-t observation variance is assigned before the
    day-t update, from ``obs[t-1]`` only.
    """
    estimator, transitions = build_runtime(task, basin)
    observations = np.asarray(task["obs"], dtype=np.float64)
    rain = np.asarray(task["rain"], dtype=np.float64)
    pet = np.asarray(task["pet"], dtype=np.float64)
    temperature = np.asarray(task["temp"], dtype=np.float64)
    sigma_obs = float(task["sigma"])

    n_days = len(observations)
    forecast = np.empty(n_days, dtype=np.float64)
    forecast_variance = np.empty(n_days, dtype=np.float64)
    posterior = np.empty((n_days, len(task["members"])), dtype=np.float64)

    observation_variance = np.full(n_days, np.nan, dtype=np.float64)

    start = time.perf_counter()
    for day in range(n_days):
        for transition in transitions:
            transition.set_forcing(rain[day], pet[day], temperature[day])
        predicted_state = transitions[0](estimator.state.copy())
        assign_common_process_covariance(
            estimator, noise.build_process_covariance(predicted_state, rain[day])
        )
        if r_source is not None:
            previous = observations[day - 1] if day > 0 else np.nan
            daily_variance = r_source.observation_variance(sigma_obs, day, previous)
            assign_common_observation_covariance(estimator, daily_variance)
            observation_variance[day] = daily_variance
        result = estimator.step(np.array([observations[day]]))
        forecast[day] = float(np.ravel(result.combined_prior_observation)[0])
        forecast_variance[day] = float(
            result.candidate_results[0].innovation_covariance[0, 0]
        )
        posterior[day] = result.posterior_probabilities
    elapsed = time.perf_counter() - start

    if not np.all(np.isfinite(forecast)):
        raise ValueError(f"basin {basin}: one-step forecast contains nonfinite values")
    return {
        "basin_id": basin,
        "one_step_forecast": forecast,
        "forecast_variance": forecast_variance,
        "posterior_probabilities": posterior,
        "observations": observations,
        "sigma_obs": sigma_obs,
        "observation_variance": observation_variance,
        "filter_seconds": elapsed,
    }


def assert_single_member_posterior_exact(probabilities: np.ndarray, tolerance: float = 1e-12) -> float:
    """Hard integrity gate inherited from stage-3 amendment 01b: the posterior must equal one."""
    array = np.asarray(probabilities, dtype=np.float64)
    if array.ndim != 2 or array.shape[1] != 1:
        raise ValueError(f"single-member posterior must have shape (days, 1), got {array.shape}")
    deviation = float(np.max(np.abs(array - 1.0)))
    if deviation > tolerance:
        raise ValueError(
            f"single-member posterior deviates from the identity: max |p-1| = {deviation:.3e} > {tolerance:.0e}"
        )
    return deviation
