"""One-shot prospective confirmation of the global noise cards on the 391 holdout basins.

Preregistration (frozen before any run):
docs/plans/2026-09-01-noise-axis-391-global-card-confirmation-prereg-v01.md

Everything here reuses the frozen dev-line machinery verbatim; the only new logic is
(a) a window-parameterized task builder (the dev loader hardcodes the 1,260-day window),
(b) amplitudes over the 1,735-day initialization segment instead of the 840-day dev
training segment, and (c) the mechanical basin screening.  Every data request passes
:func:`assert_data_request_allowed` before any loader call.
"""
from __future__ import annotations

import csv
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd

from camels_switch_confirmation.noise_axis_filtering import (
    LegacyGridNoise,
    run_noise_axis_filter,
)
from camels_switch_confirmation.noise_axis_learned_q import (
    AMPLITUDE_FLOOR_MM,
    GROUP_NAMES,
    N_GROUPS,
    TRAIN_DAYS as DEV_TRAIN_DAYS,
    GroupedProcessNoise,
    nse,
    open_loop_states,
)
from camels_switch_confirmation.run_online_noise_pilot import RESULTS
from camels_switch_confirmation.run_real_case_hindcast import assert_data_request_allowed
from camels_switch_confirmation.run_online_noise_real_obs import (
    LAG_KERNEL,
    PARAM_KEYS,
    STATE_NAMES,
    _calibration_row,
    _g1_frame,
    control_members,
)
from camels_switch_confirmation.bank import build_bank

# ---- frozen design constants (prereg sections 2-3) --------------------------------
HOLDOUT_START = "1980-01-01"
HOLDOUT_DAYS = 3561
INIT_DAYS = 1735          # 1980-01-01..1984-09-30, filter adaptation only
DEV_START = "1989-10-01"  # P0 replication window
DEV_DAYS = 1260

CARD_DONOR_NOLEAK = "04233000"
CARD_DONOR_FROZEN = "14316700"
CARD_ARMS = ("card_median52", "card_selected_noleak", "card_selected_frozen")
ALL_ARMS = ("open_loop", "m1_c0") + CARD_ARMS

STEP2_EVALUATION_CSV = (
    RESULTS / "noise_axis_step2_learned_q_20260827_local" / "evaluation_per_basin.csv"
)
DESIGN90_CSV = Path("docs/plans/2026-08-10-camels-parfc-state-interaction-design90-coverage-v01.csv")
OUTPUT_ROOT = RESULTS / "noise_axis_391_global_card_confirmation_20260901_local"

G1_MEDIAN_WINS_MIN = 0.5   # G1: > half the paired basins improve
G2_GAIN_THRESHOLD = 0.01   # G2: same threshold as dev-line T2


def window_end(start: str, n_days: int) -> str:
    return str((pd.Timestamp(start) + pd.Timedelta(days=n_days - 1)).date())


def load_forcing_obs(basin: str, start: str, n_days: int):
    """Guarded, window-parameterized twin of the dev loader (same columns, same checks)."""
    from hydroagent.data_loading import load_camels_basin

    end = window_end(start, n_days)
    assert_data_request_allowed(basin, start, end)
    forcing, obs, _ = load_camels_basin(
        basin,
        data_root="data/camels_us",
        start_date=start,
        end_date=end,
        forcing="maurer",
        pet_method="oudin",
        keep_obs_nan_days=True,
    )
    rain = forcing["prcp"].values.astype(np.float64)
    pet_col = "ep" if "ep" in forcing.columns else "pet"
    pet = forcing[pet_col].values.astype(np.float64)
    temp = (
        forcing["tmean"].values.astype(np.float64)
        if "tmean" in forcing.columns
        else np.zeros_like(rain)
    )
    observations = np.asarray(obs, dtype=np.float64)
    if len(rain) != n_days or len(observations) != n_days:
        raise ValueError(f"basin {basin}: expected {n_days} forcing/obs days, got "
                         f"{len(rain)}/{len(observations)}")
    if not (np.all(np.isfinite(rain)) and np.all(np.isfinite(pet)) and np.all(np.isfinite(temp))):
        raise ValueError(f"basin {basin}: forcing contains non-finite days")
    if not np.all(np.isfinite(observations)):
        raise ValueError(f"basin {basin}: observations contain non-finite days")
    if np.any(observations < 0.0):
        raise ValueError(f"basin {basin}: observations contain negative days")
    return rain, pet, temp, observations


def build_task(basin: str, start: str, n_days: int) -> dict:
    """Same shape as the frozen `_load_real_task` CTRL task, window parameterized."""
    from scl_hydro.hbv_lite_numpy import resolve_hbv_bounds

    row = _calibration_row(basin)
    if str(row.get("run_status", "success")) != "success":
        raise ValueError(f"basin {basin}: calibration run_status is not success")
    params = {k: float(row[f"p_{k}"]) for k in PARAM_KEYS}
    members, _ = build_bank(params, resolve_hbv_bounds("v5")["parFC"])
    members = control_members(members)
    rain, pet, temp, observations = load_forcing_obs(basin, start, n_days)
    sigma = float(_g1_frame().loc[basin, "sigma_obs"])
    if not (np.isfinite(sigma) and sigma > 0.0):
        raise ValueError(f"basin {basin}: sigma_obs is not finite positive")
    return {
        "members": members,
        "rain": rain,
        "pet": pet,
        "temp": temp,
        "obs": observations,
        "sigma": sigma,
        "source": f"real_obs_391:{basin}:{start}:{window_end(start, n_days)}",
    }


def windowed_amplitudes(states: np.ndarray, n_days: int) -> np.ndarray:
    """Dev `training_amplitudes` formula verbatim, with the segment length a parameter."""
    from camels_switch_confirmation.g2_switch_confirmation import N_HYDRO, N_STATE

    segment = np.asarray(states, dtype=np.float64)[:n_days]
    if segment.shape != (n_days, N_STATE):
        raise ValueError(f"expected ({n_days}, {N_STATE}) init states, got {segment.shape}")

    def rms(values: np.ndarray) -> float:
        return float(np.sqrt(np.mean(np.square(values))))

    amplitudes = np.array(
        [rms(segment[:, 0]), rms(segment[:, 1]), rms(segment[:, 2]), rms(segment[:, 3]),
         rms(segment[:, 4]), rms(segment[:, N_HYDRO:])],
        dtype=np.float64,
    )
    return np.maximum(amplitudes, AMPLITUDE_FLOOR_MM)


def load_cards() -> dict[str, np.ndarray]:
    """The three frozen global cards, copied digit-for-digit from the step-2 registry."""
    frame = pd.read_csv(STEP2_EVALUATION_CSV, dtype={"basin_id": str})
    frame["basin_id"] = frame["basin_id"].str.zfill(8)
    rho_cols = [f"rho_{g}" for g in GROUP_NAMES]
    if len(frame) != 52:
        raise ValueError(f"step-2 registry must hold 52 basins, got {len(frame)}")
    by_basin = {r["basin_id"]: np.array([float(r[c]) for c in rho_cols], dtype=np.float64)
                for _, r in frame.iterrows()}
    log_all = np.log(frame[rho_cols].to_numpy(dtype=np.float64))
    median52 = np.exp(np.median(log_all, axis=0))
    return {
        "card_median52": median52,
        "card_selected_noleak": by_basin[CARD_DONOR_NOLEAK],
        "card_selected_frozen": by_basin[CARD_DONOR_FROZEN],
    }


def open_loop_nse(task: dict, basin: str, score_from: int) -> dict:
    """Open-loop arm: center-member simulation, scored on the scoring segment."""
    from scl_hydro.hbv_lite_numpy import simulate_hbv_lite

    row = _calibration_row(basin)
    init_state = {s: float(row[f"state_{s}"]) for s in STATE_NAMES}
    simulated, _ = simulate_hbv_lite(
        task["rain"], task["pet"], task["temp"], task["members"][0],
        initial_state=init_state, lag_kernel=LAG_KERNEL,
    )
    simulated = np.asarray(simulated, dtype=np.float64)
    observed = task["obs"]
    return {
        "nse_score": nse(simulated[score_from:], observed[score_from:]),
        "nse_full": nse(simulated, observed),
        "seconds": 0.0,
    }


def filter_arm_nse(task: dict, basin: str, noise, score_from: int) -> dict:
    result = run_noise_axis_filter(task, basin, noise)
    forecast = result["one_step_forecast"]
    observed = result["observations"]
    return {
        "nse_score": nse(forecast[score_from:], observed[score_from:]),
        "nse_full": nse(forecast, observed),
        "seconds": float(result["filter_seconds"]),
    }


def run_basin_all_arms(basin: str, cards: dict[str, np.ndarray]) -> dict:
    """One holdout basin, all five frozen arms; crashes are recorded per arm, not raised."""
    record: dict = {"basin_id": basin, "arms": {}, "status": "success"}
    try:
        task = build_task(basin, HOLDOUT_START, HOLDOUT_DAYS)
        states = open_loop_states(task, basin)
        amplitudes = windowed_amplitudes(states, INIT_DAYS)
        record["sigma_obs"] = task["sigma"]
        record["amplitudes"] = [float(a) for a in amplitudes]
    except Exception as exc:  # noqa: BLE001 - prereg section 5
        record["status"] = "task_failed"
        record["error"] = f"{type(exc).__name__}: {exc}"
        return record
    for arm in ALL_ARMS:
        try:
            if arm == "open_loop":
                outcome = open_loop_nse(task, basin, INIT_DAYS)
            elif arm == "m1_c0":
                outcome = filter_arm_nse(task, basin, LegacyGridNoise(m=1.0, c=0.0), INIT_DAYS)
            else:
                noise = GroupedProcessNoise(tuple(cards[arm]), tuple(record["amplitudes"]))
                outcome = filter_arm_nse(task, basin, noise, INIT_DAYS)
            record["arms"][arm] = {"status": "success", **outcome}
        except Exception as exc:  # noqa: BLE001 - prereg section 5
            record["arms"][arm] = {"status": "failed", "error": f"{type(exc).__name__}: {exc}"}
    return record


# ---- P0 replication on the exposed dev window (prereg section 8.1) ----------------

def p0_check(tolerance: float = 1e-8) -> dict:
    """Replicate 2 registered dev numbers per arm through the NEW task builder."""
    baselines = pd.read_csv(
        RESULTS / "noise_axis_step2_learned_q_20260827_local" / "baselines_per_basin.csv",
        dtype={"basin_id": str},
    ).set_index("basin_id")
    transfer = pd.read_csv(
        RESULTS / "noise_axis_transfer_loo_20260828_local" / "transfer_per_basin.csv",
        dtype={"basin_id": str, "e2_donor": str},
    ).set_index("basin_id")
    transfer["e2_donor"] = transfer["e2_donor"].str.zfill(8)
    cards = load_cards()
    picked = [b for b in transfer.index if transfer.loc[b, "e2_donor"] == CARD_DONOR_FROZEN][:2]
    rows = []
    for basin in picked:
        task = build_task(basin, DEV_START, DEV_DAYS)
        states = open_loop_states(task, basin)
        amplitudes = windowed_amplitudes(states, DEV_TRAIN_DAYS)
        m1c0 = filter_arm_nse(task, basin, LegacyGridNoise(m=1.0, c=0.0), DEV_TRAIN_DAYS)
        card = filter_arm_nse(
            task, basin,
            GroupedProcessNoise(tuple(cards["card_selected_frozen"]), tuple(amplitudes)),
            DEV_TRAIN_DAYS,
        )
        rows.append({
            "basin_id": basin,
            "m1c0_new": m1c0["nse_score"],
            "m1c0_registered": float(baselines.loc[basin, "m1c0_nse_holdout"]),
            "card_new": card["nse_score"],
            "card_registered": float(transfer.loc[basin, "e2_nse"]),
        })
    for row in rows:
        row["m1c0_abs_diff"] = abs(row["m1c0_new"] - row["m1c0_registered"])
        row["card_abs_diff"] = abs(row["card_new"] - row["card_registered"])
    worst = max(max(r["m1c0_abs_diff"], r["card_abs_diff"]) for r in rows)
    return {"rows": rows, "worst_abs_diff": worst, "tolerance": tolerance,
            "passed": bool(worst <= tolerance)}


# ---- mechanical screening (prereg section 2, after the credential exists) ---------

def candidate_universe() -> list[str]:
    params = pd.read_csv(
        # same table `_calibration_row` reads; only basin ids and run_status used here
        Path(r"results/10_global_conceptual_model_benchmark/camels_us_531_repro_v01"
             r"/summary/hbv_lite_cma_rising_local_full.csv"),
        dtype={"basin_id": str},
    )
    params["basin_id"] = params["basin_id"].str.zfill(8)
    with DESIGN90_CSV.open(encoding="utf-8-sig") as handle:
        design = frozenset(r["basin_id"].zfill(8) for r in csv.DictReader(handle))
    return sorted(b for b in params["basin_id"] if b not in design)


def screen_one(basin: str) -> dict:
    row = {"basin_id": basin, "included": False, "reason": ""}
    try:
        build_task(basin, HOLDOUT_START, HOLDOUT_DAYS)
    except Exception as exc:  # noqa: BLE001 - mechanical rule, reason recorded
        row["reason"] = f"{type(exc).__name__}: {exc}"
        return row
    row["included"] = True
    return row
