"""Continuous causal filtering arms for the joint param-noise real-case line.

Implements Task 3 of docs/superpowers/plans/2026-08-25-joint-param-noise-real-case-runner.md.
Reuses the committed synthetic-line machinery (ModifiedUnscentedFilter, ForcingTransition,
conservative parFC state mapping, state-dependent lower-groundwater process covariance,
InteractingMultipleModel) and generalizes candidate construction from the balanced replay's
fixed two-parameter grid to the real-case 3x3 grid.

Causality: the day-t forecast quantities (prior probabilities, per-candidate prior
observations and innovation covariances, combined prior observation) are computed inside the
estimator step before the day-t observation enters the update, so they depend on discharge
through day t-1 only.  ``test_real_case_filtering.py`` locks this with a perturbation test.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

import numpy as np

from camels_switch_confirmation.g2_switch_confirmation import (
    N_STATE,
    RisingRoutedObservation,
    build_state_dependent_lower_groundwater_covariance,
)
from camels_switch_confirmation.joint_param_noise_precheck import (
    FC_FACTORS,
    NOISE_CANDIDATES,
)

FILTER_ARMS = ("param_only", "noise_only", "joint")
ALL_ARMS = ("open_loop_center",) + FILTER_ARMS

_SIGMA_ALPHA = 0.6874
_SIGMA_BETA = 2.0
_SIGMA_KAPPA = -2.0
_DEFAULT_INITIAL_STATE_VARIANCE = 1.0


def arm_candidate_pairs(arm: str) -> tuple[tuple[int, int], ...]:
    """(parameter index, noise index) pairs for one filtering arm."""
    if arm == "param_only":
        return tuple((param_index, 0) for param_index in range(len(FC_FACTORS)))
    if arm == "noise_only":
        return tuple((0, noise_index) for noise_index in range(len(NOISE_CANDIDATES)))
    if arm == "joint":
        return tuple(
            (param_index, noise_index)
            for param_index in range(len(FC_FACTORS))
            for noise_index in range(len(NOISE_CANDIDATES))
        )
    raise ValueError(f"unknown arm: {arm}")


@dataclass
class RealCaseRuntime:
    """One arm's estimator plus its registered candidate coordinates."""

    arm: str
    estimator: Any
    transitions: list[Any]
    candidate_pairs: tuple[tuple[int, int], ...]
    members: tuple[dict, ...]
    bounds: dict
    sigma_obs: float

    def set_forcing(self, rain: float, pet: float, temperature: float) -> None:
        for transition in self.transitions:
            transition.set_forcing(rain, pet, temperature)

    def assign_process_covariances(self, reference_slz: float) -> None:
        level = max(float(reference_slz), 0.0)
        if not np.isfinite(level):
            raise ValueError("reference lower-groundwater state must be finite")
        for candidate, (_, noise_index) in zip(self.estimator.filters, self.candidate_pairs):
            candidate.process_covariance = build_state_dependent_lower_groundwater_covariance(
                level, NOISE_CANDIDATES[noise_index]
            )


def _default_initial_state(center_parameters: Mapping[str, float]) -> np.ndarray:
    from hbv_joint_uncertainty.hbv_adapter import initial_state_vector

    return initial_state_vector(dict(center_parameters))


def build_real_case_runtime(
    arm: str,
    members: Sequence[Mapping[str, float]],
    *,
    sigma_obs: float,
    bounds: Mapping[str, tuple[float, float]],
    initial_state: np.ndarray | None = None,
    initial_covariance: np.ndarray | None = None,
    transition_matrix: np.ndarray | None = None,
) -> RealCaseRuntime:
    """Build one filtering arm around the center (member 0) initial condition."""
    from hbv_joint_uncertainty.hbv_state_mapping import (
        project_hbv_state_conserving_soil_excess,
        remap_parfc_moments,
    )
    from hbv_joint_uncertainty.imm import InteractingMultipleModel
    from hbv_joint_uncertainty.preflight import ForcingTransition
    from hbv_joint_uncertainty.sigma_filter import ModifiedUnscentedFilter, ScaledSigmaPoints

    if arm not in FILTER_ARMS:
        raise ValueError(f"unknown filter arm: {arm}")
    if len(members) != len(FC_FACTORS):
        raise ValueError(f"expected {len(FC_FACTORS)} parameter members, got {len(members)}")
    member_values = tuple(dict(member) for member in members)
    pairs = arm_candidate_pairs(arm)

    state = (
        _default_initial_state(member_values[0])
        if initial_state is None
        else np.asarray(initial_state, dtype=np.float64)
    )
    covariance = (
        np.eye(N_STATE, dtype=np.float64) * _DEFAULT_INITIAL_STATE_VARIANCE
        if initial_covariance is None
        else np.asarray(initial_covariance, dtype=np.float64)
    )
    if state.shape != (N_STATE,) or not np.all(np.isfinite(state)):
        raise ValueError(f"initial state must be finite with shape ({N_STATE},)")
    if covariance.shape != (N_STATE, N_STATE) or not np.all(np.isfinite(covariance)):
        raise ValueError(f"initial covariance must be finite with shape ({N_STATE}, {N_STATE})")
    observation_sigma = float(sigma_obs)
    if not np.isfinite(observation_sigma) or observation_sigma <= 0.0:
        raise ValueError("observation sigma must be finite and positive")

    candidate_count = len(pairs)
    if transition_matrix is None:
        transitions_matrix = np.eye(candidate_count, dtype=np.float64)
    else:
        transitions_matrix = np.asarray(transition_matrix, dtype=np.float64)
        if transitions_matrix.shape != (candidate_count, candidate_count):
            raise ValueError("transition matrix shape must match the candidate count")
        if not np.allclose(transitions_matrix.sum(axis=1), 1.0, atol=1e-12):
            raise ValueError("transition matrix rows must sum to one")

    sigma_generator = ScaledSigmaPoints(
        N_STATE, alpha=_SIGMA_ALPHA, beta=_SIGMA_BETA, kappa=_SIGMA_KAPPA
    )
    filters: list[Any] = []
    transitions: list[Any] = []
    observation_covariance = np.array([[observation_sigma**2]], dtype=np.float64)
    reference_level = max(float(state[4]), 0.0)
    for param_index, noise_index in pairs:
        params = member_values[param_index]
        mapped_state, mapped_covariance = remap_parfc_moments(
            state, covariance, member_values[0], params, sigma_generator
        )
        projector = lambda values, p=params: project_hbv_state_conserving_soil_excess(values, p)
        transition = ForcingTransition(params, parameter_bounds=dict(bounds), state_projector=projector)
        filters.append(
            ModifiedUnscentedFilter(
                state=np.asarray(mapped_state, dtype=np.float64),
                covariance=np.asarray(mapped_covariance, dtype=np.float64),
                transition=transition,
                observation=RisingRoutedObservation(params),
                process_covariance=build_state_dependent_lower_groundwater_covariance(
                    reference_level, NOISE_CANDIDATES[noise_index]
                ),
                observation_covariance=observation_covariance.copy(),
                state_projector=projector,
                alpha=_SIGMA_ALPHA,
                beta=_SIGMA_BETA,
                kappa=_SIGMA_KAPPA,
            )
        )
        transitions.append(transition)

    def pairwise_transform(source, destination, mean, pair_covariance):
        return remap_parfc_moments(
            mean,
            pair_covariance,
            member_values[pairs[source][0]],
            member_values[pairs[destination][0]],
            filters[source].sigma_generator,
        )

    estimator = InteractingMultipleModel(
        filters=filters,
        transition_matrix=transitions_matrix,
        initial_probabilities=np.full(candidate_count, 1.0 / candidate_count, dtype=np.float64),
        parameter_groups=list(range(candidate_count)),
        pairwise_moment_transform=pairwise_transform,
        model_evidence_scorer=None,
    )
    estimator.interaction_mode = "full"
    estimator.parameter_state_mapping = "conservative_parfc"
    return RealCaseRuntime(
        arm=arm,
        estimator=estimator,
        transitions=transitions,
        candidate_pairs=pairs,
        members=member_values,
        bounds=dict(bounds),
        sigma_obs=observation_sigma,
    )


def _validated_series(rain: Any, pet: Any, temperature: Any) -> tuple[np.ndarray, ...]:
    series = tuple(np.asarray(values, dtype=np.float64) for values in (rain, pet, temperature))
    lengths = {len(values) for values in series}
    if len(lengths) != 1:
        raise ValueError("forcing series must have identical lengths")
    for values in series:
        if not np.all(np.isfinite(values)):
            raise ValueError("forcing series must be finite")
    return series


def run_filter_arm(
    runtime: RealCaseRuntime,
    rain: Any,
    pet: Any,
    temperature: Any,
    observations: Any,
) -> dict[str, np.ndarray]:
    """Run one arm continuously; return daily causal forecast and probability arrays."""
    rain_values, pet_values, temperature_values = _validated_series(rain, pet, temperature)
    observed = np.asarray(observations, dtype=np.float64)
    if len(observed) != len(rain_values):
        raise ValueError("observations must match the forcing length")
    if not np.all(np.isfinite(observed)):
        raise ValueError("observations must be finite for every day of the continuous run")

    n_days = len(observed)
    n_candidates = len(runtime.candidate_pairs)
    forecast_mean = np.empty(n_days, dtype=np.float64)
    prior_probabilities = np.empty((n_days, n_candidates), dtype=np.float64)
    posterior_probabilities = np.empty((n_days, n_candidates), dtype=np.float64)
    candidate_means = np.empty((n_days, n_candidates), dtype=np.float64)
    candidate_variances = np.empty((n_days, n_candidates), dtype=np.float64)

    reference_index = next(
        index for index, (param_index, _) in enumerate(runtime.candidate_pairs) if param_index == 0
    )
    for day in range(n_days):
        runtime.set_forcing(rain_values[day], pet_values[day], temperature_values[day])
        predicted_reference = runtime.transitions[reference_index](
            runtime.estimator.state.copy()
        )
        runtime.assign_process_covariances(float(predicted_reference[4]))
        result = runtime.estimator.step(np.array([observed[day]]))
        forecast_mean[day] = float(result.combined_prior_observation[0])
        prior_probabilities[day] = result.prior_probabilities
        posterior_probabilities[day] = result.posterior_probabilities
        for position, candidate_result in enumerate(result.candidate_results):
            candidate_means[day, position] = float(candidate_result.prior_observation[0])
            candidate_variances[day, position] = float(candidate_result.innovation_covariance[0, 0])

    for label, values in (
        ("forecast_mean", forecast_mean),
        ("prior_probabilities", prior_probabilities),
        ("posterior_probabilities", posterior_probabilities),
        ("candidate_forecast_means", candidate_means),
        ("candidate_forecast_variances", candidate_variances),
    ):
        if not np.all(np.isfinite(values)):
            raise ValueError(f"{label} contains nonfinite values; numerical instability")
    return {
        "arm": runtime.arm,
        "forecast_mean": forecast_mean,
        "prior_probabilities": prior_probabilities,
        "posterior_probabilities": posterior_probabilities,
        "candidate_forecast_means": candidate_means,
        "candidate_forecast_variances": candidate_variances,
    }


def run_open_loop_arm(
    center_parameters: Mapping[str, float],
    rain: Any,
    pet: Any,
    temperature: Any,
    *,
    bounds: Mapping[str, tuple[float, float]],
    initial_state: np.ndarray | None = None,
) -> dict[str, Any]:
    """Deterministic center-model control: same transition path, no assimilation."""
    from hbv_joint_uncertainty.hbv_state_mapping import project_hbv_state_conserving_soil_excess
    from hbv_joint_uncertainty.preflight import ForcingTransition

    rain_values, pet_values, temperature_values = _validated_series(rain, pet, temperature)
    params = dict(center_parameters)
    projector = lambda values: project_hbv_state_conserving_soil_excess(values, params)
    transition = ForcingTransition(params, parameter_bounds=dict(bounds), state_projector=projector)
    observation = RisingRoutedObservation(params)
    state = (
        _default_initial_state(params)
        if initial_state is None
        else np.asarray(initial_state, dtype=np.float64).copy()
    )
    forecast_mean = np.empty(len(rain_values), dtype=np.float64)
    for day in range(len(rain_values)):
        transition.set_forcing(rain_values[day], pet_values[day], temperature_values[day])
        state = transition(state)
        forecast_mean[day] = float(observation(state)[0])
    if not np.all(np.isfinite(forecast_mean)):
        raise ValueError("open-loop forecast contains nonfinite values")
    return {"arm": "open_loop_center", "forecast_mean": forecast_mean, "final_state": state}
