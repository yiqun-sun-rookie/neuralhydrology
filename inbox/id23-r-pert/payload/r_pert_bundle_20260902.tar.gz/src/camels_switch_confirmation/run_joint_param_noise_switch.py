"""JOINT-X1: joint parameter x noise identification experiment (switch + null control).

Preregistration: docs/plans/2026-08-20-joint-param-noise-switch-prereg-v01.md
(frozen before any filter run; hash recorded below and in every npz).

Nine 15-state unscented filters span the 3x3 candidate grid

    parameter axis i : parFC x (1.0, 0.5, 2.0)     -- the dynamics hypothesis
    noise     axis j : SLZ Q multiplier (1.0, 0.1, 10.0)  -- the noise hypothesis

so the filter is uncertain on BOTH axes at once, which is the project's headline
condition and has never been run.  Truth walks a 7-stage sequence containing two
parameter-only, two noise-only and two joint transitions; the null control keeps
truth at the calibrated cell (0,0) for the whole window with everything else
bit-identical, which is the paired baseline the noise line proved necessary.

Two frozen upstream conventions collide here and the preregistration fixes the
merge: Q must vary along the noise axis (that IS the hypothesis) but must NOT
vary along the parameter axis (member-specific Q biases the likelihood toward
the small-FC member, diagnosed 2026-08-07).  Therefore Q depends on j only and
is built from ONE shared reference SLZ prediction.

The frozen filter stack (imm.py / sigma_filter.py / preflight.py) and the g2 /
bank machinery are imported, never modified.

Usage:
    python -X utf8 -m camels_switch_confirmation.run_joint_param_noise_switch --run --workers 10
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

for _variable in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
                  "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ.setdefault(_variable, "1")

import numpy as np
import pandas as pd

_SRC = Path(__file__).resolve().parents[1]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation.bank import build_bank  # noqa: E402
from camels_switch_confirmation.g1_precheck import (  # noqa: E402
    PARAM_KEYS,
    STATE_NAMES,
    WINDOW_START,
    _window_end,
)
from camels_switch_confirmation.g2_switch_confirmation import (  # noqa: E402
    INITIAL_COVARIANCE_FRACTION,
    LAG_CAP,
    N_HYDRO,
    N_STATE,
    TRANSITION_DIAGONAL,
    RisingRoutedObservation,
    _atomic_save_npz,
    build_state_dependent_lower_groundwater_covariance,
    rising_routed_discharge,
)
from camels_switch_confirmation.joint_param_noise_precheck import (  # noqa: E402
    FC_FACTORS,
    NOISE_CANDIDATES,
    N_CELLS,
    N_NOISE,
    N_PARAM,
    OUTPUT_ROOT as PRECHECK_ROOT,
    SEQUENCE,
    STAGE_DAYS,
    WINDOW_DAYS,
    cell_index,
    cell_pair,
    injection_sigma,
)
from camels_switch_confirmation.run_online_noise_pilot import (  # noqa: E402
    PARAMETER_TABLE,
    RESULTS,
)

PREREGISTRATION = "docs/plans/2026-08-20-joint-param-noise-switch-prereg-v01.md"
PREREGISTRATION_SHA256 = (
    "257faf765a09a5c8cf16a90498e6ab23f03c533e4f654970829a2fe473dec83f")
OUTPUT_ROOT = RESULTS / "joint_param_noise_switch_01_20260820_local"
ADMISSION_CSV = PRECHECK_ROOT / "admission.csv"
G1_CSV = RESULTS / "g1_precheck_v01" / "g1_precheck.csv"
DATA_ROOT = "data/camels_us"
BOUNDS_PRESET = "v5"

NULL_SEQUENCE = ((0, 0),) * len(SEQUENCE)
SCENARIOS = {"switch": SEQUENCE, "null": NULL_SEQUENCE}
ARM_MODES = {"C": "full", "P": "pairwise_path_postcollapse"}
SEEDS = (4, 5)                 # design seeds 0-3 exhausted on this line
SEED_ENTROPY = 20260820
TRUTH_STREAM_TAG = 20
OBS_STREAM_TAG = 21
WORKERS = 10


def joint_transition_matrix(diagonal=TRANSITION_DIAGONAL) -> np.ndarray:
    """kron(P_param, P_noise): the two axes are independently sticky.

    Row/column order follows cell_index = 3*i + j, so the Kronecker product is
    exactly the joint law P((i,j) -> (i',j')) = P_param[i,i'] * P_noise[j,j'].
    """
    from hbv_joint_uncertainty.preflight import build_transition_matrix
    parameter_matrix = build_transition_matrix(N_PARAM, diagonal)
    noise_matrix = build_transition_matrix(N_NOISE, diagonal)
    return np.kron(parameter_matrix, noise_matrix)


def stage_days_where(predicate, sequence=SEQUENCE, stage_days=STAGE_DAYS):
    """Calendar days of the stages whose (param, noise) pair satisfies predicate."""
    blocks = [np.arange(position * stage_days, (position + 1) * stage_days)
              for position, cell in enumerate(sequence) if predicate(position, cell)]
    if not blocks:
        return np.zeros(0, dtype=np.int64)
    return np.concatenate(blocks)


def switch_events(sequence=SEQUENCE, stage_days=STAGE_DAYS, n_days=WINDOW_DAYS):
    """(day, source cell, destination cell) for every stage boundary that moves."""
    events = []
    for position in range(1, len(sequence)):
        day = position * stage_days
        if day >= n_days:
            break
        if sequence[position] != sequence[position - 1]:
            events.append((day, sequence[position - 1], sequence[position]))
    return events


def generate_truth(sequence, members, rain, pet, temp, init_hydro, rng, bounds,
                   stage_days=STAGE_DAYS):
    """15-state truth walking the (parameter, noise) sequence; one normal/day."""
    from hbv_joint_uncertainty.hbv_adapter import advance_state
    state = np.zeros(N_STATE, dtype=np.float64)
    state[:N_HYDRO] = init_hydro
    n_days = min(len(rain), len(sequence) * stage_days)
    truth_q = np.zeros(n_days, dtype=np.float64)
    truth_param = np.zeros(n_days, dtype=np.int64)
    truth_noise = np.zeros(n_days, dtype=np.int64)
    truth_cell = np.zeros(n_days, dtype=np.int64)
    truth_parfc = np.zeros(n_days, dtype=np.float64)
    clips = 0
    day = 0
    for param_index, noise_index in sequence:
        params = members[param_index]
        sigma = injection_sigma(NOISE_CANDIDATES[noise_index])
        for _ in range(stage_days):
            if day >= n_days:
                break
            truth_param[day] = param_index
            truth_noise[day] = noise_index
            truth_cell[day] = cell_index(param_index, noise_index)
            truth_parfc[day] = float(params["parFC"])
            state = advance_state(state, rain[day], pet[day], temp[day], params,
                                  bounds=bounds)
            noisy = state[4] * np.exp(rng.normal(-0.5 * sigma ** 2, sigma))
            if not np.isfinite(noisy) or noisy < 0.0:
                clips += 1
                noisy = max(noisy, 0.0) if np.isfinite(noisy) else 0.0
            state[4] = noisy
            truth_q[day] = rising_routed_discharge(state, params["lag_time"])
            day += 1
    return truth_q, truth_param, truth_noise, truth_cell, truth_parfc, clips


def build_joint_bank(members, init_hydro, sigma_obs, bounds, interaction_mode):
    """Nine filters on the 3x3 grid: parFC varies along i, Q varies along j only."""
    from hbv_joint_uncertainty.imm import (
        InteractingMultipleModel,
        PairwisePathMultipleModel,
    )
    from hbv_joint_uncertainty.hbv_state_mapping import (
        project_hbv_state_conserving_soil_excess,
        remap_parfc_moments,
    )
    from hbv_joint_uncertainty.preflight import ForcingTransition
    from hbv_joint_uncertainty.sigma_filter import (
        ModifiedUnscentedFilter,
        ScaledSigmaPoints,
    )

    shared_state0 = np.zeros(N_STATE, dtype=np.float64)
    shared_state0[:N_HYDRO] = init_hydro
    common_state0 = project_hbv_state_conserving_soil_excess(shared_state0,
                                                             members[0])
    common_scales = np.maximum(np.abs(common_state0), 1.0)
    common_p0 = np.diag((INITIAL_COVARIANCE_FRACTION * common_scales) ** 2)
    initial_sigma_points = ScaledSigmaPoints(N_STATE, alpha=0.6874, beta=2.0,
                                             kappa=-2.0)
    common_r = np.array([[sigma_obs ** 2]], dtype=np.float64)
    reference_level = max(float(common_state0[4]), 0.0)

    filters, transitions = [], []
    for flat in range(N_CELLS):
        param_index, noise_index = cell_pair(flat)
        params = members[param_index]
        state0, p0 = remap_parfc_moments(common_state0, common_p0, members[0],
                                         params, initial_sigma_points)
        state_projector = (
            lambda values, p=params: project_hbv_state_conserving_soil_excess(values, p)
        )
        transition = ForcingTransition(params, parameter_bounds=bounds,
                                       state_projector=state_projector)
        filters.append(ModifiedUnscentedFilter(
            state=state0, covariance=p0,
            transition=transition,
            observation=RisingRoutedObservation(params),
            # Q depends on the NOISE index only -- see preregistration section 4
            process_covariance=build_state_dependent_lower_groundwater_covariance(
                reference_level, NOISE_CANDIDATES[noise_index]),
            observation_covariance=common_r.copy(),
            state_projector=state_projector,
            alpha=0.6874, beta=2.0, kappa=-2.0,
        ))
        transitions.append(transition)

    def pairwise_moment_transform(source, destination, mean, covariance):
        return remap_parfc_moments(
            mean, covariance,
            members[cell_pair(source)[0]], members[cell_pair(destination)[0]],
            filters[source].sigma_generator,
        )

    transition_matrix = joint_transition_matrix()
    initial_probabilities = np.full(N_CELLS, 1.0 / N_CELLS)
    if interaction_mode == "pairwise_path_postcollapse":
        estimator = PairwisePathMultipleModel(
            filters=filters,
            transition_matrix=transition_matrix,
            initial_probabilities=initial_probabilities,
            pairwise_moment_transform=pairwise_moment_transform,
            model_evidence_scorer=None,
        )
        estimator.recursive_probability_representation = "ordinary_float"
    else:
        estimator = InteractingMultipleModel(
            filters=filters,
            transition_matrix=transition_matrix,
            initial_probabilities=initial_probabilities,
            parameter_groups=list(range(N_CELLS)),
            pairwise_moment_transform=pairwise_moment_transform,
            model_evidence_scorer=None,
        )
    estimator.interaction_mode = interaction_mode
    estimator.parameter_state_mapping = "conservative_parfc"
    return estimator, transitions


def assign_cell_process_covariances(estimator, reference_slz):
    """One shared SLZ reference -> Q varies with the noise index alone."""
    level = max(float(reference_slz), 0.0)
    for flat in range(N_CELLS):
        _, noise_index = cell_pair(flat)
        estimator.filters[flat].process_covariance = (
            build_state_dependent_lower_groundwater_covariance(
                level, NOISE_CANDIDATES[noise_index]))


def _run_task(args_tuple):
    (basin_id, seed, arm, scenario, output_root, window_days) = args_tuple
    import sys as _sys
    if str(_SRC) not in _sys.path:
        _sys.path.insert(0, str(_SRC))
    from hydroagent.data_loading import load_camels_basin
    from scl_hydro.hbv_lite_numpy import resolve_hbv_bounds

    started = time.time()
    task_id = f"{basin_id}_s{seed}_{arm}_{scenario}"
    target = (Path(output_root) / "arms" / arm / scenario / "probs"
              / f"{basin_id}_s{seed}.npz")
    if target.exists():
        return {"task_id": task_id, "run_status": "skipped_existing",
                "error_message": "", "_elapsed_s": 0.0}
    try:
        sequence = SCENARIOS[scenario]
        table = pd.read_csv(PARAMETER_TABLE, dtype={"basin_id": str})
        table["basin_id"] = table["basin_id"].str.zfill(8)
        row = table[table["basin_id"] == basin_id].iloc[0]
        params = {key: float(row[f"p_{key}"]) for key in PARAM_KEYS}
        lag_capped = params["lag_time"] > LAG_CAP
        params["lag_time"] = min(params["lag_time"], LAG_CAP)
        init_hydro = np.array([float(row[f"state_{name}"])
                               for name in STATE_NAMES])

        bounds = resolve_hbv_bounds(BOUNDS_PRESET)
        members, clipped = build_bank(params, bounds["parFC"])

        g1 = pd.read_csv(G1_CSV, dtype={"basin_id": str})
        g1["basin_id"] = g1["basin_id"].str.zfill(8)
        sigma_obs = float(g1.set_index("basin_id").loc[basin_id, "sigma_obs"])

        forcing, _obs, _area = load_camels_basin(
            basin_id, data_root=DATA_ROOT, start_date=WINDOW_START,
            end_date=_window_end(), forcing="maurer", pet_method="oudin",
            keep_obs_nan_days=True)
        rain = forcing["prcp"].values.astype(np.float64)[:window_days]
        pet_column = "ep" if "ep" in forcing.columns else "pet"
        pet = forcing[pet_column].values.astype(np.float64)[:window_days]
        temp = (forcing["tmean"].values.astype(np.float64)
                if "tmean" in forcing.columns
                else np.zeros_like(rain))[:window_days]

        truth_rng = np.random.default_rng(np.random.SeedSequence(
            (SEED_ENTROPY, int(basin_id), int(seed), TRUTH_STREAM_TAG)))
        obs_rng = np.random.default_rng(np.random.SeedSequence(
            (SEED_ENTROPY, int(basin_id), int(seed), OBS_STREAM_TAG)))

        (truth_q, truth_param, truth_noise, truth_cell, truth_parfc,
         clips) = generate_truth(sequence, members, rain, pet, temp, init_hydro,
                                 truth_rng, bounds)
        n_days = len(truth_q)
        observations = truth_q + obs_rng.normal(0.0, sigma_obs, size=n_days)

        estimator, transitions = build_joint_bank(
            members, init_hydro, sigma_obs, bounds, ARM_MODES[arm])
        probabilities = np.zeros((n_days, N_CELLS), dtype=np.float64)
        log_probabilities = np.zeros_like(probabilities)
        reference_slz = np.zeros(n_days, dtype=np.float64)
        for day in range(n_days):
            for transition in transitions:
                transition.set_forcing(rain[day], pet[day], temp[day])
            predicted_reference = transitions[cell_index(0, 0)](
                estimator.state.copy())
            reference_slz[day] = float(predicted_reference[4])
            assign_cell_process_covariances(estimator, predicted_reference[4])
            result = estimator.step(np.array([observations[day]]))
            probabilities[day] = result.posterior_probabilities
            log_probabilities[day] = result.posterior_log_probabilities

        events = switch_events(sequence, n_days=n_days)
        _atomic_save_npz(
            target,
            probabilities=probabilities,
            log_probabilities=log_probabilities,
            truth_q=truth_q,
            observations=observations,
            truth_param_indices=truth_param,
            truth_noise_indices=truth_noise,
            truth_cell_indices=truth_cell,
            truth_parfc=truth_parfc,
            sequence=np.asarray(sequence, dtype=np.int64),
            stage_days=np.array(STAGE_DAYS, dtype=np.int64),
            switch_days=np.array([d for d, _, _ in events], dtype=np.int64),
            fc_factors=np.asarray(FC_FACTORS, dtype=np.float64),
            noise_candidates=np.asarray(NOISE_CANDIDATES, dtype=np.float64),
            reference_slz_prediction=reference_slz,
            observation_sigma=np.array(sigma_obs, dtype=np.float64),
            truth_clip_count=np.array(clips, dtype=np.int64),
            parfc_clipped=np.asarray(clipped, dtype=bool),
            basin_id=np.array(str(basin_id)),
            seed=np.array(int(seed), dtype=np.int64),
            arm_id=np.array(str(arm)),
            scenario=np.array(str(scenario)),
            state_interaction_mode=np.array(ARM_MODES[arm]),
            parameter_state_mapping=np.array("conservative_parfc"),
            lag_capped=np.array(bool(lag_capped)),
            preregistration_sha256=np.array(PREREGISTRATION_SHA256),
        )
        return {"task_id": task_id, "run_status": "success",
                "error_message": "", "truth_clip_count": int(clips),
                "lag_capped": bool(lag_capped),
                "_elapsed_s": round(time.time() - started, 2)}
    except Exception as exception:  # noqa: BLE001 - recorded, never fatal
        return {"task_id": task_id, "run_status": "failed",
                "error_message": f"{type(exception).__name__}: {exception}",
                "_elapsed_s": round(time.time() - started, 2)}


def admitted_basins():
    admitted = pd.read_csv(ADMISSION_CSV, dtype={"basin_id": str})
    admitted["basin_id"] = admitted["basin_id"].str.zfill(8)
    if "admitted" in admitted.columns:
        admitted = admitted[admitted["admitted"]]
    return admitted["basin_id"].tolist()


def run_all(arguments) -> None:
    basins = [basin.zfill(8) for basin in (arguments.basins or admitted_basins())]
    output_root = Path(arguments.output_root)
    if arguments.window_days != WINDOW_DAYS and output_root == OUTPUT_ROOT:
        raise ValueError("shortened windows must write to a non-default root")
    tasks = [(basin, seed, arm, scenario, str(output_root), arguments.window_days)
             for basin in basins for seed in arguments.seeds
             for arm in arguments.arms for scenario in arguments.scenarios]
    print(f"[joint-switch] tasks={len(tasks)} basins={len(basins)} "
          f"seeds={arguments.seeds} arms={arguments.arms} "
          f"scenarios={arguments.scenarios} window={arguments.window_days}d")
    for arm in arguments.arms:
        for scenario in arguments.scenarios:
            (output_root / "arms" / arm / scenario / "probs").mkdir(
                parents=True, exist_ok=True)
    if arguments.workers > 1 and len(tasks) > 1:
        with ProcessPoolExecutor(max_workers=arguments.workers) as pool:
            records = list(pool.map(_run_task, tasks, chunksize=1))
    else:
        records = [_run_task(task) for task in tasks]
    (output_root / "verification").mkdir(parents=True, exist_ok=True)
    failures = [record for record in records if record["run_status"] == "failed"]
    with open(output_root / "verification" / "run_failures.json", "w",
              encoding="utf-8") as handle:
        json.dump(failures, handle, indent=2, ensure_ascii=False)
    done = sum(record["run_status"] == "success" for record in records)
    skipped = sum(record["run_status"] == "skipped_existing" for record in records)
    elapsed = [record["_elapsed_s"] for record in records
               if record["run_status"] == "success"]
    manifest = {
        "preregistration": PREREGISTRATION,
        "preregistration_sha256": PREREGISTRATION_SHA256,
        "n_tasks": len(tasks), "n_success": done, "n_skipped": skipped,
        "n_failed": len(failures),
        "basins": basins, "seeds": list(arguments.seeds),
        "arms": list(arguments.arms), "scenarios": list(arguments.scenarios),
        "median_task_seconds": (float(np.median(elapsed)) if elapsed else None),
        "total_truth_clips": int(sum(record.get("truth_clip_count", 0)
                                     for record in records)),
        "n_lag_capped_tasks": int(sum(bool(record.get("lag_capped", False))
                                      for record in records)),
    }
    with open(output_root / "verification" / "run_manifest.json", "w",
              encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, ensure_ascii=False)
    print(f"[joint-switch] success={done} skipped={skipped} "
          f"failed={len(failures)}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--basins", nargs="*", default=None)
    parser.add_argument("--seeds", nargs="*", type=int, default=list(SEEDS))
    parser.add_argument("--arms", nargs="*", default=list(ARM_MODES))
    parser.add_argument("--scenarios", nargs="*", default=list(SCENARIOS))
    parser.add_argument("--workers", type=int, default=WORKERS)
    parser.add_argument("--window-days", type=int, default=WINDOW_DAYS)
    parser.add_argument("--output-root", default=str(OUTPUT_ROOT))
    arguments = parser.parse_args()
    if not arguments.run:
        parser.error("pass --run")
    run_all(arguments)


if __name__ == "__main__":
    main()
