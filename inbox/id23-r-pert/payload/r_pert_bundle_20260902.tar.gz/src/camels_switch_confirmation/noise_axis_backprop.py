"""Step 2B of the noise axis: the same six-ratio learning problem, optimized by backprop.

Preregistration (frozen 2026-08-28, launched on the user's explicit instruction):
docs/plans/2026-08-28-noise-axis-backprop-step2b-prereg-v01.md

The learning problem is byte-identical to step 2 (``noise_axis_learned_q``): six
process-noise ratios per basin on log bounds [ln 1e-4, ln 1.0], frozen RMS amplitudes,
frozen G1 observation sigma, MSE-of-one-step-forecast training objective over days
61..840, winner by training objective. The ONLY manipulated variable is the optimizer:
Adam gradient descent through a torch re-implementation of the frozen filter chain,
replacing CMA-ES sampling search.

Torch is a search surrogate ONLY. Every number that enters the results -- training
objectives, winner selection, holdout NSE -- is rescored with the frozen numpy filter
(``training_objective`` / ``evaluate_full_run``), so torch/numpy float drift cannot
contaminate the science. The parity gate (prereg P0) quantifies that drift anyway.
"""
from __future__ import annotations

import math
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch

_SRC = Path(__file__).resolve().parents[1]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation.g2_switch_confirmation import N_HYDRO, N_STATE  # noqa: E402
from camels_switch_confirmation.noise_axis_filtering import (  # noqa: E402
    build_runtime,
    load_stage3_control_task,
)
from camels_switch_confirmation.noise_axis_learned_q import (  # noqa: E402
    BURN_IN_DAYS,
    GROUP_NAMES,
    LOG_RHO_BOUNDS,
    N_GROUPS,
    TRAIN_DAYS,
    WINDOW_DAYS,
    GroupedProcessNoise,
    anchor_table,
)

# Frozen sigma-point constants (mirrors ScaledSigmaPoints(15, 0.6874, 2.0, -2.0)).
SIGMA_ALPHA = 0.6874
SIGMA_BETA = 2.0
SIGMA_KAPPA = -2.0
SIGMA_LAMBDA = SIGMA_ALPHA**2 * (N_STATE + SIGMA_KAPPA) - N_STATE
SIGMA_SCALE = N_STATE + SIGMA_LAMBDA
N_SIGMA = 2 * N_STATE + 1
STATE_EPS = 1e-5  # the frozen HBV-lite epsilon
SM_FLOOR = 1e-5  # the frozen projector soil floor

ADAM_LR = 0.05
START_NAMES = tuple(name for name, _ in anchor_table()) + ("cma_polish",)
N_STARTS = len(START_NAMES)
LOGIT_CLIP = 1e-6  # boundary starts are pulled this fraction into the open box
CHUNK_DAYS = 60  # gradient-checkpoint segment length (exact recompute, memory only)

_DTYPE = torch.float64


def sigma_weights() -> tuple[np.ndarray, np.ndarray]:
    """Mean and covariance weights, computed exactly as the frozen numpy class does."""
    mean = np.full(N_SIGMA, 1.0 / (2.0 * SIGMA_SCALE), dtype=np.float64)
    cov = mean.copy()
    mean[0] = SIGMA_LAMBDA / SIGMA_SCALE
    cov[0] = mean[0] + 1.0 - SIGMA_ALPHA**2 + SIGMA_BETA
    return mean, cov


def u_from_log_rho(log_rho: np.ndarray) -> np.ndarray:
    """Map log-rho inside the frozen box to the unbounded sigmoid coordinate."""
    low, high = LOG_RHO_BOUNDS
    fraction = (np.asarray(log_rho, dtype=np.float64) - low) / (high - low)
    fraction = np.clip(fraction, LOGIT_CLIP, 1.0 - LOGIT_CLIP)
    return np.log(fraction / (1.0 - fraction))


def log_rho_from_u(u: torch.Tensor) -> torch.Tensor:
    low, high = LOG_RHO_BOUNDS
    return low + (high - low) * torch.sigmoid(u)


@dataclass
class BasinBundle:
    """Everything torch needs, read off the frozen numpy construction (not re-derived)."""

    basin_id: str
    task: dict
    parameters: dict
    sigma_obs: float
    initial_state: np.ndarray
    initial_covariance: np.ndarray
    amplitudes: np.ndarray

    @classmethod
    def load(cls, basin: str, amplitudes: np.ndarray) -> "BasinBundle":
        task = load_stage3_control_task(basin)
        estimator, transitions = build_runtime(task, basin)
        filt = estimator.filters[0]
        return cls(
            basin_id=basin,
            task=task,
            parameters=dict(transitions[0].parameters),
            sigma_obs=float(task["sigma"]),
            initial_state=np.asarray(filt.state, dtype=np.float64).copy(),
            initial_covariance=np.asarray(filt.covariance, dtype=np.float64).copy(),
            amplitudes=np.asarray(amplitudes, dtype=np.float64).copy(),
        )


class TorchFilterConstants:
    """Per-basin frozen tensors shared by every lane of the batched filter."""

    def __init__(self, bundle: BasinBundle, n_days: int):
        if n_days > len(bundle.task["obs"]):
            raise ValueError("n_days exceeds the task window")
        p = bundle.parameters
        self.p = {key: float(value) for key, value in p.items()}
        lag = min(float(p["lag_time"]), 10.0)
        self.n_lag = max(int(math.ceil(lag)), 1)
        weights = np.arange(1, self.n_lag + 1, dtype=np.float64)
        self.lag_weights = torch.tensor(weights / weights.sum(), dtype=_DTYPE)
        self.rain = [float(v) for v in np.asarray(bundle.task["rain"])[:n_days]]
        self.pet = [float(v) for v in np.asarray(bundle.task["pet"])[:n_days]]
        self.temp = [float(v) for v in np.asarray(bundle.task["temp"])[:n_days]]
        self.obs = torch.tensor(
            np.asarray(bundle.task["obs"], dtype=np.float64)[:n_days], dtype=_DTYPE
        )
        self.n_days = int(n_days)
        self.r_var = float(bundle.sigma_obs) ** 2
        self.init_state = torch.tensor(bundle.initial_state, dtype=_DTYPE)
        self.init_cov = torch.tensor(bundle.initial_covariance, dtype=_DTYPE)
        mean_w, cov_w = sigma_weights()
        self.mean_w = torch.tensor(mean_w, dtype=_DTYPE)
        self.cov_w = torch.tensor(cov_w, dtype=_DTYPE)
        self.eye = torch.eye(N_STATE, dtype=_DTYPE)
        self.amplitudes = torch.tensor(bundle.amplitudes, dtype=_DTYPE)


def _project_conserving(points: torch.Tensor, p: dict) -> torch.Tensor:
    """Torch mirror of ``project_hbv_state_conserving_soil_excess`` (same op order)."""
    snow = points[..., 0]
    meltwater = points[..., 1]
    soil = points[..., 2]
    upper = points[..., 3]
    rest = points[..., 4:]
    fc = p["parFC"]
    soil_excess = torch.clamp(soil - fc, min=0.0)
    soil = soil - soil_excess
    upper = upper + soil_excess
    snow = torch.clamp(snow, min=0.0)
    meltwater = torch.minimum(torch.clamp(meltwater, min=0.0), p["parCWH"] * snow)
    soil = torch.minimum(torch.clamp(soil, min=SM_FLOOR), torch.as_tensor(fc, dtype=_DTYPE))
    upper = torch.clamp(upper, min=0.0)
    rest = torch.clamp(rest, min=0.0)
    return torch.cat(
        [snow.unsqueeze(-1), meltwater.unsqueeze(-1), soil.unsqueeze(-1), upper.unsqueeze(-1), rest],
        dim=-1,
    )


def _project_legacy(points: torch.Tensor, p: dict) -> torch.Tensor:
    """Torch mirror of the legacy ``project_hbv_state`` used on the observation side."""
    snow = torch.clamp(points[..., 0], min=0.0)
    meltwater = torch.minimum(torch.clamp(points[..., 1], min=0.0), p["parCWH"] * snow)
    soil = torch.minimum(
        torch.clamp(points[..., 2], min=SM_FLOOR), torch.as_tensor(p["parFC"], dtype=_DTYPE)
    )
    rest = torch.clamp(points[..., 3:], min=0.0)
    return torch.cat(
        [snow.unsqueeze(-1), meltwater.unsqueeze(-1), soil.unsqueeze(-1), rest], dim=-1
    )


def _advance(points: torch.Tensor, rain: float, pet: float, temp: float, p: dict) -> torch.Tensor:
    """Torch mirror of ``hbv_adapter.advance_state`` (identical elementwise op order)."""
    snowpack = points[..., 0]
    meltwater = points[..., 1]
    soil = points[..., 2]
    upper = points[..., 3]
    lower = points[..., 4]
    routing = points[..., 5:]

    if temp < p["parTT"]:
        snowfall, rainfall = rain, 0.0
    else:
        snowfall, rainfall = 0.0, rain

    snowpack = snowpack + snowfall
    melt_cap = max(p["parCFMAX"] * (temp - p["parTT"]), 0.0)
    melt = torch.clamp(snowpack, max=melt_cap)
    meltwater = meltwater + melt
    snowpack = snowpack - melt

    refreeze_cap = max(p["parCFR"] * p["parCFMAX"] * (p["parTT"] - temp), 0.0)
    refreeze = torch.clamp(meltwater, max=refreeze_cap)
    snowpack = snowpack + refreeze
    meltwater = meltwater - refreeze

    to_soil = torch.clamp(meltwater - p["parCWH"] * snowpack, min=0.0)
    meltwater = meltwater - to_soil

    ratio = torch.clamp(soil / (p["parFC"] + STATE_EPS), 0.0, 1.0)
    wetness = torch.clamp(ratio ** p["parBETA"], 0.0, 1.0)
    recharge = (rainfall + to_soil) * wetness
    soil = soil + rainfall + to_soil - recharge

    excess = torch.clamp(soil - p["parFC"], min=0.0)
    soil = soil - excess

    evaporation_factor = torch.clamp(soil / (p["parLP"] * p["parFC"] + STATE_EPS), 0.0, 1.0)
    actual_evaporation = torch.minimum(pet * evaporation_factor, soil)
    soil = torch.clamp(soil - actual_evaporation, min=STATE_EPS)

    upper = upper + recharge + excess
    percolation = torch.clamp(upper, max=p["parPERC"])
    upper = upper - percolation
    upper_excess = torch.clamp(upper - p["parUZL"], min=0.0)
    fast_runoff = p["parK0"] * upper_excess
    upper = upper - fast_runoff
    upper_runoff = p["parK1"] * upper
    upper = upper - upper_runoff
    lower = lower + percolation
    lower_runoff = p["parK2"] * lower
    lower = lower - lower_runoff

    raw_runoff = fast_runoff + upper_runoff + lower_runoff
    new_routing = torch.cat([raw_runoff.unsqueeze(-1), routing[..., :9]], dim=-1)
    return torch.cat(
        [
            snowpack.unsqueeze(-1),
            meltwater.unsqueeze(-1),
            soil.unsqueeze(-1),
            upper.unsqueeze(-1),
            lower.unsqueeze(-1),
            new_routing,
        ],
        dim=-1,
    )


def _sigma_points(mean: torch.Tensor, cov: torch.Tensor, const: TorchFilterConstants):
    """Batched mirror of ``ScaledSigmaPoints.sigma_points`` with bounded jitter repair.

    Lanes whose covariance is genuinely indefinite (numpy would raise) are flagged dead
    and given an identity root so the batch keeps computing; dead lanes are frozen by the
    caller and never contribute a candidate update.
    """
    sym = 0.5 * (cov + cov.transpose(-1, -2))
    scaled = SIGMA_SCALE * sym
    root, info = torch.linalg.cholesky_ex(scaled)
    dead = torch.zeros(mean.shape[0], dtype=torch.bool)
    if int(info.max().item()) > 0:
        with torch.no_grad():
            eigenvalues = torch.linalg.eigvalsh(sym.detach())
            minimum = eigenvalues[:, 0]
            spectral = torch.clamp(eigenvalues.abs().max(dim=1).values, min=1.0)
            tolerance = torch.clamp(
                torch.finfo(torch.float64).eps * N_STATE * spectral * 100.0, min=1e-12
            )
            failed = info > 0
            hard_bad = (minimum < -tolerance) & failed
            jitter = torch.where(
                failed, torch.maximum(tolerance, -minimum + tolerance), torch.zeros_like(tolerance)
            )
        repaired = SIGMA_SCALE * (sym + jitter[:, None, None] * const.eye)
        root2, info2 = torch.linalg.cholesky_ex(repaired)
        dead = hard_bad | (failed & (info2 > 0))
        root = torch.where(
            (info > 0)[:, None, None], torch.nan_to_num(root2), torch.nan_to_num(root)
        )
        root = torch.where(dead[:, None, None], const.eye.expand_as(root), root)
    offsets = root.transpose(-1, -2)  # row i is column i of the lower-triangular root
    center = mean[:, None, :]
    return torch.cat([center, center + offsets, center - offsets], dim=1), dead


def _observe(points: torch.Tensor, const: TorchFilterConstants) -> torch.Tensor:
    projected = _project_legacy(points, const.p)
    routing = projected[..., N_HYDRO:N_HYDRO + const.n_lag]
    return (routing * const.lag_weights).sum(dim=-1)


def _ukf_day(state, cov, diag_q, day: int, const: TorchFilterConstants):
    """One frozen-order filter day: predict (with Q), regenerate, observe, project."""
    rain, pet, temp = const.rain[day], const.pet[day], const.temp[day]
    points, dead_a = _sigma_points(state, cov, const)
    propagated = _project_conserving(
        _advance(_project_conserving(points, const.p), rain, pet, temp, const.p), const.p
    )
    prior_state = torch.einsum("i,bij->bj", const.mean_w, propagated)
    deviations = propagated - prior_state[:, None, :]
    prior_cov = torch.einsum("i,bij,bik->bjk", const.cov_w, deviations, deviations)
    prior_cov = prior_cov + torch.diag_embed(diag_q)
    prior_cov = 0.5 * (prior_cov + prior_cov.transpose(-1, -2))

    points2, dead_b = _sigma_points(prior_state, prior_cov, const)
    observed_sigmas = _observe(points2, const)
    prior_observation = torch.einsum("i,bi->b", const.mean_w, observed_sigmas)
    observation_dev = observed_sigmas - prior_observation[:, None]
    innovation_var = (
        torch.einsum("i,bi,bi->b", const.cov_w, observation_dev, observation_dev) + const.r_var
    )
    state_dev = points2 - prior_state[:, None, :]
    cross = torch.einsum("i,bij,bi->bj", const.cov_w, state_dev, observation_dev)
    gain = cross / innovation_var[:, None]
    innovation = const.obs[day] - prior_observation
    posterior = prior_state + gain * innovation[:, None]
    posterior = _project_conserving(posterior, const.p)
    posterior_cov = prior_cov - innovation_var[:, None, None] * (
        gain[:, None, :] * gain[:, :, None]
    )
    posterior_cov = 0.5 * (posterior_cov + posterior_cov.transpose(-1, -2))
    return posterior, posterior_cov, prior_observation, dead_a | dead_b


def diag_q_from_log_rho(log_rho: torch.Tensor, const: TorchFilterConstants) -> torch.Tensor:
    """(B, 6) log ratios -> (B, 15) constant diagonal Q, exactly as GroupedProcessNoise."""
    std = torch.exp(log_rho) * const.amplitudes
    hydro = std[:, :N_HYDRO] ** 2
    routing = (std[:, N_GROUPS - 1:N_GROUPS] ** 2).expand(-1, N_STATE - N_HYDRO)
    return torch.cat([hydro, routing], dim=1)


def _run_chunk(state, cov, diag_q, start_day: int, end_day: int, const: TorchFilterConstants):
    """Run days [start_day, end_day); accumulate burn-in-excluded squared error."""
    batch = state.shape[0]
    squared_error = torch.zeros(batch, dtype=_DTYPE)
    dead = torch.zeros(batch, dtype=torch.bool)
    for day in range(start_day, end_day):
        state, cov, forecast, day_dead = _ukf_day(state, cov, diag_q, day, const)
        dead = dead | day_dead
        if day >= BURN_IN_DAYS:
            squared_error = squared_error + (forecast - const.obs[day]) ** 2
    return state, cov, squared_error, dead.to(_DTYPE)


def training_loss_torch(
    u: torch.Tensor, const: TorchFilterConstants, chunk_days: int = CHUNK_DAYS
) -> tuple[torch.Tensor, torch.Tensor]:
    """Per-lane training MSE (days 61..840) with gradient checkpointing per chunk."""
    if const.n_days < TRAIN_DAYS:
        raise ValueError("training constants must cover the 840-day training segment")
    log_rho = log_rho_from_u(u)
    diag_q = diag_q_from_log_rho(log_rho, const)
    batch = u.shape[0]
    state = const.init_state[None, :].expand(batch, N_STATE).contiguous()
    cov = const.init_cov[None, :, :].expand(batch, N_STATE, N_STATE).contiguous()
    squared_total = torch.zeros(batch, dtype=_DTYPE)
    dead_total = torch.zeros(batch, dtype=_DTYPE)
    for start in range(0, TRAIN_DAYS, chunk_days):
        end = min(start + chunk_days, TRAIN_DAYS)

        def chunk_fn(s, c, q, a=start, b=end):
            return _run_chunk(s, c, q, a, b, const)

        state, cov, squared, dead = torch.utils.checkpoint.checkpoint(
            chunk_fn, state, cov, diag_q, use_reentrant=False
        )
        squared_total = squared_total + squared
        dead_total = torch.maximum(dead_total, dead)
    loss = squared_total / float(TRAIN_DAYS - BURN_IN_DAYS)
    loss = torch.where(dead_total > 0.0, torch.full_like(loss, float("inf")), loss)
    return loss, dead_total > 0.0


def run_filter_torch_full(bundle: BasinBundle, rho: np.ndarray, n_days: int) -> np.ndarray:
    """No-grad full-window torch run returning daily one-step forecasts (parity use)."""
    const = TorchFilterConstants(bundle, n_days)
    log_rho = torch.tensor(np.log(np.asarray(rho, dtype=np.float64))[None, :], dtype=_DTYPE)
    with torch.no_grad():
        diag_q = diag_q_from_log_rho(log_rho, const)
        state = const.init_state[None, :].clone()
        cov = const.init_cov[None, :, :].clone()
        forecasts = np.empty(n_days, dtype=np.float64)
        for day in range(n_days):
            state, cov, forecast, dead = _ukf_day(state, cov, diag_q, day, const)
            if bool(dead.any()):
                raise ValueError(f"torch filter lane died on day {day} (basin {bundle.basin_id})")
            forecasts[day] = float(forecast[0])
    return forecasts


@dataclass
class StartResult:
    name: str
    start_rho: np.ndarray
    best_log_rho: np.ndarray
    best_torch_loss: float
    dead: bool
    loss_curve: list


def start_rho_table(cma_winner_rho: np.ndarray) -> list[tuple[str, np.ndarray]]:
    """The nine frozen starts: step-2 anchors verbatim plus the CMA-winner polish start."""
    starts = [(name, rho.copy()) for name, rho in anchor_table()]
    starts.append(("cma_polish", np.asarray(cma_winner_rho, dtype=np.float64).copy()))
    return starts


def train_basin(
    bundle: BasinBundle,
    cma_winner_rho: np.ndarray,
    n_iter: int,
    lr: float = ADAM_LR,
    chunk_days: int = CHUNK_DAYS,
    curve_every: int = 10,
) -> dict:
    """Deterministic Adam descent from the nine frozen starts; returns all candidates."""
    torch.manual_seed(0)  # defensive only: the computation is deterministic, no sampling
    const = TorchFilterConstants(bundle, TRAIN_DAYS)
    starts = start_rho_table(cma_winner_rho)
    u0 = np.stack([u_from_log_rho(np.log(rho)) for _, rho in starts])
    u = torch.tensor(u0, dtype=_DTYPE, requires_grad=True)
    optimizer = torch.optim.Adam([u], lr=lr)

    best_loss = np.full(N_STARTS, np.inf)
    best_u = u0.copy()
    alive = np.ones(N_STARTS, dtype=bool)
    curves: list[list] = [[] for _ in range(N_STARTS)]
    wall_start = time.perf_counter()

    for iteration in range(n_iter + 1):
        loss, dead = training_loss_torch(u, const, chunk_days=chunk_days)
        loss_np = loss.detach().numpy()
        dead_np = dead.numpy()
        for lane in range(N_STARTS):
            finite = np.isfinite(loss_np[lane]) and not dead_np[lane]
            if alive[lane] and finite and loss_np[lane] < best_loss[lane]:
                best_loss[lane] = float(loss_np[lane])
                best_u[lane] = u.detach().numpy()[lane].copy()
            if alive[lane] and not finite:
                alive[lane] = False  # frozen at its best candidate from here on
            if iteration % curve_every == 0 or iteration == n_iter:
                curves[lane].append([iteration, float(loss_np[lane])])
        if iteration == n_iter:
            break
        alive_mask = torch.tensor(alive, dtype=torch.bool)
        finite_mask = torch.isfinite(loss) & alive_mask & ~dead
        if not bool(finite_mask.any()):
            break
        optimizer.zero_grad(set_to_none=True)
        loss[finite_mask].sum().backward()
        with torch.no_grad():
            if u.grad is not None:
                u.grad[~torch.tensor(alive, dtype=torch.bool)] = 0.0
                u.grad[torch.isnan(u.grad)] = 0.0
        optimizer.step()
        with torch.no_grad():
            frozen = torch.tensor(~alive, dtype=torch.bool)
            if bool(frozen.any()):
                u.data[frozen] = torch.tensor(best_u, dtype=_DTYPE)[frozen]

    elapsed = time.perf_counter() - wall_start
    results = []
    for lane, (name, rho0) in enumerate(starts):
        with torch.no_grad():
            best_log = log_rho_from_u(torch.tensor(best_u[lane][None, :], dtype=_DTYPE))
        results.append(
            StartResult(
                name=name,
                start_rho=rho0,
                best_log_rho=best_log.numpy()[0],
                best_torch_loss=float(best_loss[lane]),
                dead=not alive[lane],
                loss_curve=curves[lane],
            )
        )
    return {
        "basin_id": bundle.basin_id,
        "n_iter": int(n_iter),
        "lr": float(lr),
        "chunk_days": int(chunk_days),
        "starts": results,
        "wall_seconds": elapsed,
    }


def numpy_training_objective(bundle: BasinBundle, rho: np.ndarray) -> float:
    """Official score: the frozen numpy implementation, byte-identical to step 2."""
    from camels_switch_confirmation.noise_axis_learned_q import training_objective

    noise = GroupedProcessNoise(tuple(np.asarray(rho, dtype=np.float64)), tuple(bundle.amplitudes))
    return training_objective(bundle.task, bundle.basin_id, noise)


def numpy_full_evaluation(bundle: BasinBundle, rho: np.ndarray) -> dict:
    from camels_switch_confirmation.noise_axis_learned_q import evaluate_full_run

    noise = GroupedProcessNoise(tuple(np.asarray(rho, dtype=np.float64)), tuple(bundle.amplitudes))
    result = evaluate_full_run(bundle.task, bundle.basin_id, noise)
    return {
        "nse_holdout": float(result["nse_holdout"]),
        "nse_full": float(result["nse_full"]),
        "nse_train_after_burnin": float(result["nse_train_after_burnin"]),
    }


def select_winner(objectives: np.ndarray) -> int:
    """Winner by training objective, ties to the smaller start index (frozen rule)."""
    values = np.asarray(objectives, dtype=np.float64)
    finite = np.where(np.isfinite(values), values, np.inf)
    return int(np.argmin(finite))


def outer_5pct_count(log_rho: np.ndarray) -> int:
    """Boundary-proximity diagnostic in the step-2 comparable outer-5% convention."""
    low, high = LOG_RHO_BOUNDS
    span = high - low
    values = np.asarray(log_rho, dtype=np.float64)
    return int(np.sum((values < low + 0.05 * span) | (values > high - 0.05 * span)))


def training_nse_from_mse(mse: float, observations: np.ndarray) -> float:
    """Convert the frozen MSE objective to a training-segment NSE for readability."""
    observed = np.asarray(observations, dtype=np.float64)[BURN_IN_DAYS:TRAIN_DAYS]
    variance = float(np.mean(np.square(observed - observed.mean())))
    return 1.0 - float(mse) / variance


assert WINDOW_DAYS == 1260 and TRAIN_DAYS == 840 and BURN_IN_DAYS == 60
