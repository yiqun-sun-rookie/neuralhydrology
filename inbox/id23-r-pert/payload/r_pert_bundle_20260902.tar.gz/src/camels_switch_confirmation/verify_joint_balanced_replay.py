"""Independently verify balanced-replay raw evidence and scientific decisions.

The verifier deliberately does not import the production summarizer.  It
recreates the registered Williams design, raw-array checks, daily marginal
probabilities, event-to-cell-to-axis aggregation, basin-only bootstrap streams,
decision gates, state-error diagnostics, and artifact comparisons from the
frozen configuration and raw archives.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
from scipy.stats import beta

from camels_switch_confirmation.g1_precheck import PARAM_KEYS
from camels_switch_confirmation.joint_balanced_replay import (
    CONFIG_PATH,
    EXPERIMENT_ID,
    FORMAL_SEEDS,
    N_CELLS,
    N_NOISE,
    N_PARAMETER,
    PARAMETER_FACTORS,
    PROCESS_NOISE_MULTIPLIERS,
    WILLIAMS_BASE,
    load_registered_config,
    sha256_file,
)


REPO_ROOT = Path(__file__).resolve().parents[2]
ARM_MODES = {"C": "full", "P": "pairwise_path_postcollapse"}
KNOWLEDGE_MODES = ("joint_unknown", "param_known", "noise_known")
REPORT_WINDOWS = {
    "days_001_007": (0, 7),
    "days_008_030": (7, 30),
    "days_031_090": (30, 90),
    "days_091_180": (90, 180),
}
PRIMARY_WINDOW = "days_091_180"
EXPECTED_BASINS = 36
EXPECTED_TRUTH_BUNDLES = EXPECTED_BASINS * len(FORMAL_SEEDS)
EXPECTED_TASKS = EXPECTED_TRUTH_BUNDLES * len(ARM_MODES) * len(KNOWLEDGE_MODES)
EXPECTED_EVENTS = EXPECTED_TASKS * 5
PROBABILITY_TOLERANCE = 1e-12
FLOAT_COMPARISON_TOLERANCE = 1e-12
STATE_COUNT = 15

TRUTH_ARRAY_NAMES = (
    "rain",
    "pet",
    "temperature",
    "pre_states",
    "post_states",
    "truth_q",
    "observations",
    "observation_errors",
    "truth_param_indices",
    "truth_noise_indices",
    "truth_cell_indices",
    "truth_parfc",
    "sequence",
)


@dataclass(frozen=True, order=True)
class _Task:
    basin_id: str
    seed: int
    algorithm: str
    knowledge_mode: str

    @property
    def task_id(self) -> str:
        return (
            f"{self.basin_id}_s{self.seed}_{self.algorithm}_"
            f"{self.knowledge_mode}"
        )


def _cell_pair(cell: int) -> tuple[int, int]:
    value = int(cell)
    if value not in range(N_CELLS):
        raise AssertionError("cell index is outside the registered six cells")
    return value // N_NOISE, value % N_NOISE


def _cell_index(parameter: int, noise: int) -> int:
    parameter_value = int(parameter)
    noise_value = int(noise)
    if parameter_value not in range(N_PARAMETER):
        raise AssertionError("parameter index is outside the registered two levels")
    if noise_value not in range(N_NOISE):
        raise AssertionError("process-noise index is outside the registered three levels")
    return parameter_value * N_NOISE + noise_value


def _williams_sequence(index: int) -> tuple[int, ...]:
    value = int(index)
    if value not in range(N_CELLS):
        raise AssertionError("Williams sequence index must be 0 through 5")
    return tuple((cell + value) % N_CELLS for cell in WILLIAMS_BASE)


def _expected_sequence(index: int) -> np.ndarray:
    return np.asarray([_cell_pair(cell) for cell in _williams_sequence(index)])


def _expected_transition_type(
    source: Sequence[int], destination: Sequence[int]
) -> str:
    parameter_changed = int(source[0]) != int(destination[0])
    noise_changed = int(source[1]) != int(destination[1])
    if parameter_changed and noise_changed:
        return "joint"
    if parameter_changed:
        return "parameter_only"
    if noise_changed:
        return "noise_only"
    raise AssertionError("a replay edge does not change either registered axis")


def verify_basin_edge_coverage(sequences: Iterable[Sequence[int]]) -> None:
    """Require the six Williams rows and all 30 distinct directed switches."""

    rows = tuple(tuple(int(value) for value in sequence) for sequence in sequences)
    edges = [
        (source, destination)
        for sequence in rows
        for source, destination in zip(sequence, sequence[1:])
    ]
    expected = {
        (source, destination)
        for source in range(N_CELLS)
        for destination in range(N_CELLS)
        if source != destination
    }
    if (
        len(rows) != N_CELLS
        or any(len(row) != N_CELLS for row in rows)
        or len(edges) != 30
        or len(set(edges)) != 30
        or set(edges) != expected
    ):
        raise AssertionError("basin does not contain all 30 directed edges exactly once")


def _assert_array_equal(actual: Any, expected: Any, label: str) -> None:
    try:
        np.testing.assert_array_equal(actual, expected)
    except AssertionError as exception:
        raise AssertionError(f"{label} changed") from exception


def _assert_allclose(
    actual: Any,
    expected: Any,
    label: str,
    *,
    atol: float = PROBABILITY_TOLERANCE,
) -> None:
    try:
        np.testing.assert_allclose(actual, expected, rtol=0.0, atol=atol)
    except AssertionError as exception:
        raise AssertionError(f"{label} changed") from exception


def _candidate_pairs_for_event(
    knowledge_mode: str, destination: Sequence[int]
) -> tuple[tuple[int, int], ...]:
    parameter = int(destination[0])
    noise = int(destination[1])
    if knowledge_mode == "joint_unknown":
        return tuple(
            (parameter_index, noise_index)
            for parameter_index in range(N_PARAMETER)
            for noise_index in range(N_NOISE)
        )
    if knowledge_mode == "param_known":
        return tuple((parameter, noise_index) for noise_index in range(N_NOISE))
    if knowledge_mode == "noise_known":
        return tuple((parameter_index, noise) for parameter_index in range(N_PARAMETER))
    raise AssertionError(f"unknown knowledge mode: {knowledge_mode}")


def _verify_probability_arrays(arrays: Mapping[str, Any]) -> tuple[int, int, int]:
    probabilities = np.asarray(arrays["probabilities"], dtype=np.float64)
    priors = np.asarray(arrays["prior_probabilities"], dtype=np.float64)
    logs = np.asarray(arrays["log_probabilities"], dtype=np.float64)
    if probabilities.ndim != 3:
        raise AssertionError("posterior probabilities must have three dimensions")
    if priors.shape != probabilities.shape or logs.shape != probabilities.shape:
        raise AssertionError("probability arrays changed shape")
    if not np.all(np.isfinite(probabilities)) or np.any(probabilities < 0.0):
        raise AssertionError("posterior probabilities are not finite and nonnegative")
    if not np.all(np.isfinite(priors)) or np.any(priors < 0.0):
        raise AssertionError("prior probabilities are not finite and nonnegative")
    if np.any(np.isnan(logs)) or np.any(np.isposinf(logs)):
        raise AssertionError("log probabilities contain NaN or positive infinity")
    _assert_allclose(
        probabilities.sum(axis=2),
        1.0,
        "posterior probability sums",
    )
    _assert_allclose(priors.sum(axis=2), 1.0, "prior probability sums")
    with np.errstate(under="ignore"):
        reconstructed = np.exp(logs)
    try:
        np.testing.assert_allclose(
            reconstructed,
            probabilities,
            rtol=1e-12,
            atol=np.finfo(np.float64).tiny,
        )
    except AssertionError as exception:
        raise AssertionError("log probabilities disagree with posteriors") from exception
    event_count, replay_days, candidate_count = probabilities.shape
    return event_count, replay_days, candidate_count


def verify_replay_task_arrays(
    arrays: Mapping[str, Any],
    bundle: Any,
    knowledge_mode: str,
    expected_sequence_index: int,
) -> None:
    """Verify a raw replay task directly against its immutable truth bundle."""

    expected_count = {"joint_unknown": 6, "param_known": 3, "noise_known": 2}.get(
        str(knowledge_mode)
    )
    if expected_count is None:
        raise AssertionError(f"unknown knowledge mode: {knowledge_mode}")
    raw_probability_shape = np.asarray(arrays["probabilities"]).shape
    if len(raw_probability_shape) != 3:
        raise AssertionError("posterior probabilities must have three dimensions")
    event_count, replay_days, candidate_count = raw_probability_shape
    if candidate_count != expected_count:
        raise AssertionError(
            f"candidate count changed: {candidate_count} != {expected_count}"
        )
    if event_count != 5 or replay_days != 180:
        raise AssertionError("replay task must contain five 180-day events")

    priors = np.asarray(arrays["prior_probabilities"], dtype=np.float64)
    uniform = np.full(candidate_count, 1.0 / candidate_count)
    if priors.shape == raw_probability_shape and not np.allclose(
        priors[:, 0], uniform, rtol=0.0, atol=1e-15
    ):
        raise AssertionError("first prior is not the exact uniform distribution")
    _verify_probability_arrays(arrays)

    sequence = np.asarray(bundle.sequence, dtype=np.int64)
    expected_sequence = _expected_sequence(expected_sequence_index)
    if not np.array_equal(sequence, expected_sequence):
        raise AssertionError("truth bundle Williams sequence changed")
    stage_days = int(bundle.stage_days)
    if stage_days != 180:
        raise AssertionError("truth bundle stage length changed")
    switch_days = np.arange(1, 6, dtype=np.int64) * stage_days
    _assert_array_equal(arrays["switch_days"], switch_days, "switch days")
    _assert_array_equal(arrays["event_offsets"], np.arange(1, 181), "event offsets")
    _assert_array_equal(arrays["sequence_positions"], np.arange(1, 6), "sequence positions")

    probabilities = np.asarray(arrays["probabilities"], dtype=np.float64)
    priors = np.asarray(arrays["prior_probabilities"], dtype=np.float64)
    if not np.allclose(
        priors[:, 1:], probabilities[:, :-1], rtol=0.0, atol=1e-12
    ):
        raise AssertionError("within-event prior recursion changed")

    source_cells = sequence[:-1]
    destination_cells = sequence[1:]
    source_indices = source_cells[:, 0] * N_NOISE + source_cells[:, 1]
    destination_indices = destination_cells[:, 0] * N_NOISE + destination_cells[:, 1]
    _assert_array_equal(arrays["source_cells"], source_cells, "source cells")
    _assert_array_equal(arrays["destination_cells"], destination_cells, "destination cells")
    _assert_array_equal(arrays["source_cell_indices"], source_indices, "source cell indices")
    _assert_array_equal(
        arrays["destination_cell_indices"], destination_indices, "destination cell indices"
    )
    expected_types = np.asarray(
        [
            _expected_transition_type(source, destination)
            for source, destination in zip(source_cells, destination_cells)
        ]
    )
    _assert_array_equal(arrays["transition_types"], expected_types, "transition types")

    candidate_parameter = np.asarray(arrays["candidate_param_indices"])
    candidate_noise = np.asarray(arrays["candidate_noise_indices"])
    if (
        candidate_parameter.shape != probabilities.shape
        or candidate_noise.shape != probabilities.shape
    ):
        raise AssertionError("candidate coordinate arrays changed shape")
    for event_index, destination in enumerate(destination_cells):
        pairs = _candidate_pairs_for_event(knowledge_mode, destination)
        expected_parameter = np.asarray([pair[0] for pair in pairs])
        expected_noise = np.asarray([pair[1] for pair in pairs])
        _assert_array_equal(
            candidate_parameter[event_index],
            np.broadcast_to(expected_parameter, (replay_days, candidate_count)),
            "candidate parameter coordinates",
        )
        _assert_array_equal(
            candidate_noise[event_index],
            np.broadcast_to(expected_noise, (replay_days, candidate_count)),
            "candidate process-noise coordinates",
        )

    truth_slices = {
        "truth_pre_states": "pre_states",
        "truth_post_states": "post_states",
        "observations": "observations",
        "truth_q": "truth_q",
        "truth_param_indices": "truth_param_indices",
        "truth_noise_indices": "truth_noise_indices",
        "truth_cell_indices": "truth_cell_indices",
        "rain": "rain",
        "pet": "pet",
        "temperature": "temperature",
    }
    for raw_name, bundle_name in truth_slices.items():
        source_values = np.asarray(getattr(bundle, bundle_name))
        expected = np.stack(
            [source_values[day : day + replay_days] for day in switch_days]
        )
        label = "observations" if raw_name == "observations" else raw_name.replace("_", " ")
        _assert_array_equal(arrays[raw_name], expected, label)
    expected_calendar = np.stack(
        [np.arange(day, day + replay_days) for day in switch_days]
    )
    _assert_array_equal(
        arrays["calendar_day_indices"], expected_calendar, "calendar day indices"
    )
    _assert_array_equal(
        arrays["initial_truth_states"],
        np.asarray(bundle.pre_states)[switch_days],
        "true reset state",
    )

    state_shape = (event_count, replay_days, STATE_COUNT)
    for name in (
        "combined_states",
        "combined_covariance_diagonals",
        "truth_pre_states",
        "truth_post_states",
    ):
        values = np.asarray(arrays[name])
        if values.shape != state_shape or not np.all(np.isfinite(values)):
            raise AssertionError(f"{name.replace('_', ' ')} changed shape or finiteness")
    covariance = np.asarray(arrays["combined_covariance_diagonals"])
    if np.any(covariance < -PROBABILITY_TOLERANCE):
        raise AssertionError("combined covariance diagonal contains negative values")
    for name in ("initial_mapped_states", "initial_mapped_covariance_diagonals"):
        values = np.asarray(arrays[name])
        if values.shape != (event_count, candidate_count, STATE_COUNT):
            raise AssertionError(f"{name.replace('_', ' ')} changed shape")
        if not np.all(np.isfinite(values)):
            raise AssertionError(f"{name.replace('_', ' ')} contains non-finite values")
    if np.any(np.asarray(arrays["initial_mapped_covariance_diagonals"]) < -1e-12):
        raise AssertionError("initial mapped covariance diagonal contains negative values")


def _daily_identification_values(
    probabilities: np.ndarray,
    candidate_parameter: np.ndarray,
    candidate_noise: np.ndarray,
    *,
    truth_parameter: int | np.ndarray,
    truth_noise: int | np.ndarray,
    truth_cell: int | np.ndarray,
) -> dict[str, np.ndarray]:
    """Recompute daily truth mass and three independent argmax indicators."""

    posterior = np.asarray(probabilities, dtype=np.float64)
    parameters = np.asarray(candidate_parameter, dtype=np.int64)
    noises = np.asarray(candidate_noise, dtype=np.int64)
    if posterior.ndim != 2 or parameters.shape != posterior.shape or noises.shape != posterior.shape:
        raise AssertionError("daily candidate arrays changed shape")
    day_count = posterior.shape[0]
    truth_parameters = np.broadcast_to(
        np.asarray(truth_parameter, dtype=np.int64), (day_count,)
    )
    truth_noises = np.broadcast_to(np.asarray(truth_noise, dtype=np.int64), (day_count,))
    truth_cells = np.broadcast_to(np.asarray(truth_cell, dtype=np.int64), (day_count,))

    parameter_marginal = np.zeros((day_count, N_PARAMETER), dtype=np.float64)
    noise_marginal = np.zeros((day_count, N_NOISE), dtype=np.float64)
    for level in range(N_PARAMETER):
        parameter_marginal[:, level] = np.sum(
            np.where(parameters == level, posterior, 0.0), axis=1
        )
    for level in range(N_NOISE):
        noise_marginal[:, level] = np.sum(
            np.where(noises == level, posterior, 0.0), axis=1
        )
    rows = np.arange(day_count)
    true_pair_mask = (
        (parameters == truth_parameters[:, None])
        & (noises == truth_noises[:, None])
    )
    if not np.all(true_pair_mask.sum(axis=1) == 1):
        raise AssertionError("true candidate coordinate is not unique each day")
    joint_winner = np.argmax(posterior, axis=1)
    joint_winner_cells = (
        parameters[rows, joint_winner] * N_NOISE + noises[rows, joint_winner]
    )
    return {
        "parameter_true_probability": parameter_marginal[
            rows, truth_parameters
        ],
        "parameter_argmax_correct": (
            np.argmax(parameter_marginal, axis=1) == truth_parameters
        ),
        "process_noise_true_probability": noise_marginal[rows, truth_noises],
        "process_noise_argmax_correct": (
            np.argmax(noise_marginal, axis=1) == truth_noises
        ),
        "joint_cell_true_probability": np.sum(
            np.where(true_pair_mask, posterior, 0.0), axis=1
        ),
        "joint_cell_argmax_correct": joint_winner_cells == truth_cells,
    }


def _compare_json_values(actual: Any, expected: Any, label: str, path: str = "$") -> None:
    if isinstance(expected, Mapping):
        if not isinstance(actual, Mapping) or set(actual) != set(expected):
            raise AssertionError(f"{label} changed at {path}")
        for key in expected:
            _compare_json_values(actual[key], expected[key], label, f"{path}.{key}")
        return
    if isinstance(expected, list):
        if not isinstance(actual, list) or len(actual) != len(expected):
            raise AssertionError(f"{label} changed at {path}")
        for index, (left, right) in enumerate(zip(actual, expected)):
            _compare_json_values(left, right, label, f"{path}[{index}]")
        return
    if isinstance(expected, bool) or expected is None or isinstance(expected, str):
        if type(actual) is not type(expected) or actual != expected:
            raise AssertionError(f"{label} changed at {path}")
        return
    if isinstance(expected, (int, np.integer)):
        if isinstance(actual, bool) or int(actual) != int(expected):
            raise AssertionError(f"{label} changed at {path}")
        return
    if isinstance(expected, (float, np.floating)):
        if not isinstance(actual, (int, float)) or isinstance(actual, bool):
            raise AssertionError(f"{label} changed at {path}")
        if math.isnan(float(expected)):
            if not math.isnan(float(actual)):
                raise AssertionError(f"{label} changed at {path}")
        elif not math.isclose(
            float(actual),
            float(expected),
            rel_tol=0.0,
            abs_tol=FLOAT_COMPARISON_TOLERANCE,
        ):
            raise AssertionError(f"{label} changed at {path}")
        return
    if actual != expected:
        raise AssertionError(f"{label} changed at {path}")


def compare_json_artifact(path: Path, expected: Any, label: str) -> None:
    with Path(path).open(encoding="utf-8") as handle:
        observed = json.load(handle)
    _compare_json_values(observed, expected, label)


def compare_frame_artifact(
    path: Path,
    expected: pd.DataFrame,
    sort_columns: Sequence[str],
    label: str,
) -> None:
    observed = pd.read_csv(Path(path), dtype={"basin_id": str})
    target = expected.copy()
    if set(observed.columns) != set(target.columns):
        raise AssertionError(f"{label} columns changed")
    observed = observed[target.columns]
    for frame in (observed, target):
        if "basin_id" in frame.columns:
            frame["basin_id"] = frame["basin_id"].astype(str).str.zfill(8)
    observed = observed.sort_values(list(sort_columns), kind="stable").reset_index(drop=True)
    target = target.sort_values(list(sort_columns), kind="stable").reset_index(drop=True)
    try:
        pd.testing.assert_frame_equal(
            observed,
            target,
            check_dtype=False,
            check_exact=False,
            rtol=0.0,
            atol=FLOAT_COMPARISON_TOLERANCE,
        )
    except AssertionError as exception:
        raise AssertionError(f"{label} numeric or categorical values changed") from exception


def _state_window_metrics(
    estimated: np.ndarray, truth: np.ndarray
) -> dict[str, float]:
    estimate = np.asarray(estimated, dtype=np.float64)
    target = np.asarray(truth, dtype=np.float64)
    if estimate.shape != target.shape or estimate.ndim != 2 or estimate.shape[1] != STATE_COUNT:
        raise AssertionError("state metric inputs are not equal day-by-15 arrays")
    error = estimate - target
    rmse = np.sqrt(np.mean(error**2, axis=0))
    median_absolute_error = np.median(np.abs(error), axis=0)
    scales = np.maximum(np.std(target, axis=0, ddof=0), 1.0)
    normalized = rmse / scales
    row: dict[str, float] = {
        "state_mean_normalized_rmse": float(np.mean(normalized))
    }
    for index in range(STATE_COUNT):
        suffix = f"{index:02d}"
        row[f"state_rmse_{suffix}"] = float(rmse[index])
        row[f"state_median_absolute_error_{suffix}"] = float(
            median_absolute_error[index]
        )
        row[f"state_normalization_scale_{suffix}"] = float(scales[index])
        row[f"state_normalized_rmse_{suffix}"] = float(normalized[index])
    return row


def independent_event_metric_rows(
    arrays: Mapping[str, Any],
    *,
    basin_id: str,
    seed: int,
    algorithm: str,
    knowledge_mode: str,
) -> list[dict]:
    """Recompute all four nonoverlapping event-window rows from raw arrays."""

    rows: list[dict] = []
    probabilities = np.asarray(arrays["probabilities"], dtype=np.float64)
    candidate_parameter = np.asarray(arrays["candidate_param_indices"], dtype=np.int64)
    candidate_noise = np.asarray(arrays["candidate_noise_indices"], dtype=np.int64)
    combined_states = np.asarray(arrays["combined_states"], dtype=np.float64)
    truth_states = np.asarray(arrays["truth_post_states"], dtype=np.float64)
    source_cells = np.asarray(arrays["source_cell_indices"], dtype=np.int64)
    destination_cells = np.asarray(arrays["destination_cell_indices"], dtype=np.int64)
    sequence_positions = np.asarray(arrays["sequence_positions"], dtype=np.int64)
    transition_types = np.asarray(arrays["transition_types"]).astype(str)
    switch_days = np.asarray(arrays["switch_days"], dtype=np.int64)
    truth_parameter = np.asarray(arrays["truth_param_indices"], dtype=np.int64)
    truth_noise = np.asarray(arrays["truth_noise_indices"], dtype=np.int64)
    truth_cell = np.asarray(arrays["truth_cell_indices"], dtype=np.int64)
    offsets = np.asarray(arrays["event_offsets"], dtype=np.int64)
    if offsets.shape != (180,):
        raise AssertionError("event offsets changed shape")
    for event_index in range(5):
        destination_cell = int(destination_cells[event_index])
        destination_parameter, destination_noise = _cell_pair(destination_cell)
        values = _daily_identification_values(
            probabilities[event_index],
            candidate_parameter[event_index],
            candidate_noise[event_index],
            truth_parameter=truth_parameter[event_index],
            truth_noise=truth_noise[event_index],
            truth_cell=truth_cell[event_index],
        )
        source_cell = int(source_cells[event_index])
        source_parameter, source_noise = _cell_pair(source_cell)
        for window, (start, stop) in REPORT_WINDOWS.items():
            selected = np.flatnonzero((offsets > start) & (offsets <= stop))
            if len(selected) != stop - start:
                raise AssertionError(f"window {window} changed")
            rows.append({
                "basin_id": str(basin_id).zfill(8),
                "seed": int(seed),
                "algorithm": str(algorithm),
                "knowledge_mode": str(knowledge_mode),
                "event_index": int(event_index),
                "source_cell": source_cell,
                "destination_cell": destination_cell,
                "source_parameter": source_parameter,
                "source_process_noise": source_noise,
                "destination_parameter": destination_parameter,
                "destination_process_noise": destination_noise,
                "sequence_position": int(sequence_positions[event_index]),
                "transition_type": str(transition_types[event_index]),
                "switch_day": int(switch_days[event_index]),
                "window": window,
                "window_start_day": start + 1,
                "window_end_day": stop,
                "day_count": int(len(selected)),
                "parameter_true_probability": float(
                    np.mean(values["parameter_true_probability"][selected])
                ),
                "parameter_argmax_accuracy": float(
                    np.mean(values["parameter_argmax_correct"][selected])
                ),
                "process_noise_true_probability": float(
                    np.mean(values["process_noise_true_probability"][selected])
                ),
                "process_noise_argmax_accuracy": float(
                    np.mean(values["process_noise_argmax_correct"][selected])
                ),
                "joint_cell_true_probability": float(
                    np.mean(values["joint_cell_true_probability"][selected])
                ),
                "joint_cell_argmax_accuracy": float(
                    np.mean(values["joint_cell_argmax_correct"][selected])
                ),
                **_state_window_metrics(
                    combined_states[event_index, selected],
                    truth_states[event_index, selected],
                ),
            })
    return rows


def _validate_directed_event_block(frame: pd.DataFrame, label: str) -> pd.DataFrame:
    ordered = frame.sort_values(
        ["destination_cell", "source_cell", "seed", "event_index"], kind="stable"
    ).reset_index(drop=True)
    directed = list(
        zip(
            ordered["source_cell"].astype(int),
            ordered["destination_cell"].astype(int),
        )
    )
    expected = {
        (source, destination)
        for source in range(N_CELLS)
        for destination in range(N_CELLS)
        if source != destination
    }
    if len(ordered) != 30 or len(set(directed)) != 30 or set(directed) != expected:
        raise AssertionError(f"{label} has a missing or duplicated directed event")
    counts = ordered.groupby("destination_cell", sort=True).size()
    if set(counts.index.astype(int)) != set(range(N_CELLS)) or set(counts.astype(int)) != {5}:
        raise AssertionError(f"{label} does not contain five incoming events per target cell")
    return ordered


def independent_basin_metric_rows(event_rows: Sequence[dict]) -> list[dict]:
    """Recreate event-to-cell-to-axis aggregation in the registered order."""

    frame = pd.DataFrame(event_rows)
    primary = frame[frame["window"] == PRIMARY_WINDOW].copy()
    results: list[dict] = []
    for identity, group in primary.groupby(
        ["basin_id", "algorithm", "knowledge_mode"], sort=True, dropna=False
    ):
        basin, algorithm, knowledge_mode = identity
        ordered = _validate_directed_event_block(group, "/".join(map(str, identity)))
        cell_rows = []
        for destination_cell, incoming in ordered.groupby("destination_cell", sort=True):
            incoming = incoming.sort_values(
                ["source_cell", "seed", "event_index"], kind="stable"
            )
            parameter_level, noise_level = _cell_pair(int(destination_cell))
            cell_rows.append({
                "destination_cell": int(destination_cell),
                "parameter_level": parameter_level,
                "noise_level": noise_level,
                "parameter_true_probability": float(
                    np.mean(incoming["parameter_true_probability"].to_numpy(float))
                ),
                "parameter_argmax_accuracy": float(
                    np.mean(incoming["parameter_argmax_accuracy"].to_numpy(float))
                ),
                "process_noise_true_probability": float(
                    np.mean(incoming["process_noise_true_probability"].to_numpy(float))
                ),
                "process_noise_argmax_accuracy": float(
                    np.mean(incoming["process_noise_argmax_accuracy"].to_numpy(float))
                ),
                "joint_cell_true_probability": float(
                    np.mean(incoming["joint_cell_true_probability"].to_numpy(float))
                ),
                "joint_cell_argmax_accuracy": float(
                    np.mean(incoming["joint_cell_argmax_accuracy"].to_numpy(float))
                ),
                "state_mean_normalized_rmse": float(
                    np.mean(incoming["state_mean_normalized_rmse"].to_numpy(float))
                ),
                "event_count": int(len(incoming)),
            })
        cells = pd.DataFrame(cell_rows).sort_values("destination_cell", kind="stable")
        if len(cells) != N_CELLS or set(cells["event_count"]) != {5}:
            raise AssertionError("basin target-cell aggregation changed")
        base = {
            "basin_id": str(basin).zfill(8),
            "algorithm": str(algorithm),
            "knowledge_mode": str(knowledge_mode),
        }
        for cell in cells.itertuples(index=False):
            results.append({
                **base,
                "axis": "joint_cell",
                "level": int(cell.destination_cell),
                "true_probability": float(cell.joint_cell_true_probability),
                "argmax_accuracy": float(cell.joint_cell_argmax_accuracy),
                "state_mean_normalized_rmse": float(cell.state_mean_normalized_rmse),
                "event_count": int(cell.event_count),
                "target_cell_count": 1,
            })
        for (
            axis,
            level_column,
            probability_column,
            accuracy_column,
            level_count,
            target_cells,
        ) in (
            (
                "parameter",
                "parameter_level",
                "parameter_true_probability",
                "parameter_argmax_accuracy",
                N_PARAMETER,
                N_NOISE,
            ),
            (
                "process_noise",
                "noise_level",
                "process_noise_true_probability",
                "process_noise_argmax_accuracy",
                N_NOISE,
                N_PARAMETER,
            ),
        ):
            for level in range(level_count):
                selected = cells[cells[level_column] == level].sort_values(
                    "destination_cell", kind="stable"
                )
                if len(selected) != target_cells:
                    raise AssertionError(f"{axis} level target-cell count changed")
                results.append({
                    **base,
                    "axis": axis,
                    "level": int(level),
                    "true_probability": float(
                        np.mean(selected[probability_column].to_numpy(float))
                    ),
                    "argmax_accuracy": float(
                        np.mean(selected[accuracy_column].to_numpy(float))
                    ),
                    "state_mean_normalized_rmse": float(
                        np.mean(selected["state_mean_normalized_rmse"].to_numpy(float))
                    ),
                    "event_count": int(selected["event_count"].sum()),
                    "target_cell_count": int(len(selected)),
                })
    axis_order = {"parameter": 0, "process_noise": 1, "joint_cell": 2}
    results.sort(
        key=lambda row: (
            row["basin_id"],
            row["algorithm"],
            row["knowledge_mode"],
            axis_order[row["axis"]],
            row["level"],
        )
    )
    return results


def _primary_axis_daily_values(
    arrays: Mapping[str, Any], axis: str
) -> list[np.ndarray]:
    result: list[np.ndarray] = []
    for event_index in range(5):
        destination = np.asarray(arrays["destination_cells"])[event_index]
        destination_cell = _cell_index(int(destination[0]), int(destination[1]))
        daily = _daily_identification_values(
            np.asarray(arrays["probabilities"])[event_index],
            np.asarray(arrays["candidate_param_indices"])[event_index],
            np.asarray(arrays["candidate_noise_indices"])[event_index],
            truth_parameter=int(destination[0]),
            truth_noise=int(destination[1]),
            truth_cell=destination_cell,
        )
        name = (
            "parameter_true_probability"
            if axis == "parameter"
            else "process_noise_true_probability"
        )
        result.append(np.asarray(daily[name], dtype=np.float64)[90:180])
    return result


def independent_paired_event_rows(
    joint_arrays: Mapping[str, Any],
    reference_arrays: Mapping[str, Any],
    *,
    axis: str,
    basin_id: str,
    seed: int,
    algorithm: str,
) -> list[dict]:
    """Pair raw daily axis values before event or basin averaging."""

    if axis not in {"parameter", "process_noise"}:
        raise AssertionError("paired axis must be parameter or process_noise")
    reference_mode = "noise_known" if axis == "parameter" else "param_known"
    for name in (
        "source_cells",
        "destination_cells",
        "source_cell_indices",
        "destination_cell_indices",
        "sequence_positions",
        "transition_types",
        "switch_days",
        "event_offsets",
        "observations",
        "truth_post_states",
        "truth_param_indices",
        "truth_noise_indices",
        "truth_cell_indices",
    ):
        _assert_array_equal(
            reference_arrays[name], joint_arrays[name], f"paired {name.replace('_', ' ')}"
        )
    joint = _primary_axis_daily_values(joint_arrays, axis)
    reference = _primary_axis_daily_values(reference_arrays, axis)
    rows: list[dict] = []
    for event_index, (joint_values, reference_values) in enumerate(zip(joint, reference)):
        if joint_values.shape != (90,) or reference_values.shape != (90,):
            raise AssertionError("paired primary daily window changed")
        source_cell = int(np.asarray(joint_arrays["source_cell_indices"])[event_index])
        destination_cell = int(
            np.asarray(joint_arrays["destination_cell_indices"])[event_index]
        )
        destination_parameter, destination_noise = _cell_pair(destination_cell)
        level = destination_parameter if axis == "parameter" else destination_noise
        rows.append({
            "basin_id": str(basin_id).zfill(8),
            "seed": int(seed),
            "algorithm": str(algorithm),
            "axis": axis,
            "level": int(level),
            "source_cell": source_cell,
            "destination_cell": destination_cell,
            "event_index": int(event_index),
            "sequence_position": int(
                np.asarray(joint_arrays["sequence_positions"])[event_index]
            ),
            "transition_type": str(
                np.asarray(joint_arrays["transition_types"])[event_index]
            ),
            "reference_knowledge_mode": reference_mode,
            "day_count": 90,
            "paired_probability_loss": float(
                np.mean(joint_values - reference_values)
            ),
        })
    return rows


def independent_paired_basin_rows(paired_event_rows: Sequence[dict]) -> list[dict]:
    frame = pd.DataFrame(paired_event_rows)
    if not np.all(frame["day_count"].astype(int) == 90):
        raise AssertionError("paired event rows do not use exact primary days")
    results: list[dict] = []
    for identity, group in frame.groupby(
        ["basin_id", "algorithm", "axis"], sort=True, dropna=False
    ):
        basin, algorithm, axis = identity
        ordered = _validate_directed_event_block(group, "/".join(map(str, identity)))
        expected_reference = "noise_known" if axis == "parameter" else "param_known"
        if set(ordered["reference_knowledge_mode"].astype(str)) != {expected_reference}:
            raise AssertionError("paired rows use the wrong known-axis reference")
        cell_rows = []
        for destination_cell, incoming in ordered.groupby("destination_cell", sort=True):
            parameter_level, noise_level = _cell_pair(int(destination_cell))
            cell_rows.append({
                "destination_cell": int(destination_cell),
                "level": parameter_level if axis == "parameter" else noise_level,
                "paired_probability_loss": float(
                    np.mean(incoming["paired_probability_loss"].to_numpy(float))
                ),
                "event_count": int(len(incoming)),
            })
        cells = pd.DataFrame(cell_rows).sort_values("destination_cell", kind="stable")
        level_count = N_PARAMETER if axis == "parameter" else N_NOISE
        target_count = N_NOISE if axis == "parameter" else N_PARAMETER
        for level in range(level_count):
            selected = cells[cells["level"] == level]
            if len(selected) != target_count or set(selected["event_count"]) != {5}:
                raise AssertionError("paired axis cell or event count changed")
            results.append({
                "basin_id": str(basin).zfill(8),
                "algorithm": str(algorithm),
                "axis": str(axis),
                "level": int(level),
                "reference_knowledge_mode": expected_reference,
                "paired_probability_loss": float(
                    np.mean(selected["paired_probability_loss"].to_numpy(float))
                ),
                "event_count": int(selected["event_count"].sum()),
                "target_cell_count": int(len(selected)),
            })
    axis_code = {"parameter": 0, "process_noise": 1}
    results.sort(
        key=lambda row: (
            row["basin_id"], row["algorithm"], axis_code[row["axis"]], row["level"]
        )
    )
    return results


def _bootstrap_seed(
    algorithm: str,
    comparison: str,
    axis: str,
    level: int,
    metric: str,
    base_seed: int,
) -> np.random.SeedSequence:
    algorithm_codes = {"C": 0, "P": 1}
    comparison_codes = {
        "joint_unknown": 0,
        "param_known": 1,
        "noise_known": 2,
        "paired": 3,
    }
    axis_codes = {"parameter": 0, "process_noise": 1, "joint_cell": 2}
    metric_codes = {
        "true_probability": 0,
        "argmax_accuracy": 1,
        "paired_probability_loss": 2,
    }
    try:
        entropy = [
            int(base_seed),
            algorithm_codes[str(algorithm)],
            comparison_codes[str(comparison)],
            axis_codes[str(axis)],
            int(level),
            metric_codes[str(metric)],
        ]
    except KeyError as exception:
        raise AssertionError(f"unknown bootstrap code: {exception.args[0]}") from exception
    return np.random.SeedSequence(entropy)


def _bootstrap_median_interval(
    values: np.ndarray, seed: np.random.SeedSequence, replicates: int
) -> tuple[float, float]:
    array = np.asarray(values, dtype=np.float64)
    if array.ndim != 1 or len(array) != EXPECTED_BASINS or not np.all(np.isfinite(array)):
        raise AssertionError("bootstrap requires exactly 36 finite basin scores")
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, len(array), size=(int(replicates), len(array)))
    medians = np.median(array[indices], axis=1)
    lower, upper = np.quantile(medians, [0.025, 0.975], method="linear")
    return float(lower), float(upper)


def _clopper_pearson(successes: int, trials: int = EXPECTED_BASINS) -> tuple[float, float]:
    count = int(successes)
    total = int(trials)
    lower = 0.0 if count == 0 else float(beta.ppf(0.025, count, total - count + 1))
    upper = 1.0 if count == total else float(beta.ppf(0.975, count + 1, total - count))
    return lower, upper


def _ordered_basin_values(group: pd.DataFrame, column: str) -> np.ndarray:
    if len(group) != EXPECTED_BASINS or group["basin_id"].astype(str).nunique() != EXPECTED_BASINS:
        raise AssertionError("decision group does not contain exactly 36 basins")
    ordered = group.assign(
        _basin=group["basin_id"].astype(str).str.zfill(8)
    ).sort_values("_basin", kind="stable")
    values = ordered[column].to_numpy(dtype=np.float64)
    if not np.all(np.isfinite(values)):
        raise AssertionError("decision group contains non-finite basin scores")
    return values


def _absolute_thresholds(
    axis: str,
    probability_median: float,
    probability_lower: float,
    above_count: int,
    accuracy_median: float,
    accuracy_lower: float,
) -> dict:
    reference = {
        "parameter": 0.5,
        "process_noise": 1.0 / 3.0,
        "joint_cell": 1.0 / 6.0,
    }[axis]
    result = {
        "probability_reference": reference,
        "probability_median_pass": bool(probability_median > reference),
        "probability_bootstrap_lower_pass": bool(probability_lower > reference),
        "minimum_33_of_36_pass": bool(int(above_count) >= 33),
        "argmax_median_pass": bool(
            accuracy_median >= 0.60 if axis == "joint_cell" else accuracy_median > 0.50
        ),
        "argmax_bootstrap_lower_pass": bool(accuracy_lower > 0.50),
    }
    result["pass"] = bool(
        all(
            result[key]
            for key in (
                "probability_median_pass",
                "probability_bootstrap_lower_pass",
                "minimum_33_of_36_pass",
                "argmax_median_pass",
                "argmax_bootstrap_lower_pass",
            )
        )
    )
    return result


def independent_decision_summary(
    basin_rows: Sequence[dict],
    paired_rows: Sequence[dict],
    *,
    base_seed: int,
    replicates: int,
) -> dict:
    basin = pd.DataFrame(basin_rows)
    paired = pd.DataFrame(paired_rows)
    payload: dict[str, Any] = {
        "bootstrap_base_seed": int(base_seed),
        "bootstrap_replicates": int(replicates),
        "primary_window": PRIMARY_WINDOW,
        "algorithms": {},
    }
    contracts = (
        ("parameter", ("joint_unknown", "noise_known"), range(N_PARAMETER)),
        ("process_noise", ("joint_unknown", "param_known"), range(N_NOISE)),
        ("joint_cell", ("joint_unknown",), range(N_CELLS)),
    )
    for algorithm in ("C", "P"):
        absolute_gates = []
        for axis, modes, levels in contracts:
            for mode in modes:
                for level in levels:
                    selected = basin[
                        (basin["algorithm"].astype(str) == algorithm)
                        & (basin["knowledge_mode"].astype(str) == mode)
                        & (basin["axis"].astype(str) == axis)
                        & (basin["level"].astype(int) == int(level))
                    ]
                    probabilities = _ordered_basin_values(selected, "true_probability")
                    accuracies = _ordered_basin_values(selected, "argmax_accuracy")
                    probability_interval = _bootstrap_median_interval(
                        probabilities,
                        _bootstrap_seed(
                            algorithm, mode, axis, level, "true_probability", base_seed
                        ),
                        replicates,
                    )
                    accuracy_interval = _bootstrap_median_interval(
                        accuracies,
                        _bootstrap_seed(
                            algorithm, mode, axis, level, "argmax_accuracy", base_seed
                        ),
                        replicates,
                    )
                    probability_median = float(np.median(probabilities))
                    accuracy_median = float(np.median(accuracies))
                    reference = {
                        "parameter": 0.5,
                        "process_noise": 1.0 / 3.0,
                        "joint_cell": 1.0 / 6.0,
                    }[axis]
                    above = int(np.sum(probabilities > reference))
                    fraction_interval = _clopper_pearson(above)
                    absolute_gates.append({
                        "algorithm": algorithm,
                        "knowledge_mode": mode,
                        "axis": axis,
                        "level": int(level),
                        "basin_count": EXPECTED_BASINS,
                        "probability_median": probability_median,
                        "probability_bootstrap_lower": probability_interval[0],
                        "probability_bootstrap_upper": probability_interval[1],
                        "basins_strictly_above_reference": above,
                        "above_reference_fraction": above / EXPECTED_BASINS,
                        "above_reference_clopper_pearson_lower": fraction_interval[0],
                        "above_reference_clopper_pearson_upper": fraction_interval[1],
                        "argmax_accuracy_median": accuracy_median,
                        "argmax_accuracy_bootstrap_lower": accuracy_interval[0],
                        "argmax_accuracy_bootstrap_upper": accuracy_interval[1],
                        **_absolute_thresholds(
                            axis,
                            probability_median,
                            probability_interval[0],
                            above,
                            accuracy_median,
                            accuracy_interval[0],
                        ),
                    })
        paired_gates = []
        for axis, levels in (
            ("parameter", range(N_PARAMETER)),
            ("process_noise", range(N_NOISE)),
        ):
            for level in levels:
                selected = paired[
                    (paired["algorithm"].astype(str) == algorithm)
                    & (paired["axis"].astype(str) == axis)
                    & (paired["level"].astype(int) == int(level))
                ]
                values = _ordered_basin_values(selected, "paired_probability_loss")
                interval = _bootstrap_median_interval(
                    values,
                    _bootstrap_seed(
                        algorithm,
                        "paired",
                        axis,
                        level,
                        "paired_probability_loss",
                        base_seed,
                    ),
                    replicates,
                )
                median = float(np.median(values))
                median_pass = median >= -0.10
                lower_pass = interval[0] >= -0.10
                paired_gates.append({
                    "algorithm": algorithm,
                    "axis": axis,
                    "level": int(level),
                    "basin_count": EXPECTED_BASINS,
                    "median_paired_probability_loss": median,
                    "bootstrap_lower": interval[0],
                    "bootstrap_upper": interval[1],
                    "noninferiority_margin": -0.10,
                    "median_pass": bool(median_pass),
                    "bootstrap_lower_pass": bool(lower_pass),
                    "pass": bool(median_pass and lower_pass),
                })
        payload["algorithms"][algorithm] = {
            "absolute_gates": absolute_gates,
            "paired_gates": paired_gates,
            "absolute_gate_count": len(absolute_gates),
            "paired_gate_count": len(paired_gates),
            "overall_pass": bool(
                all(item["pass"] for item in absolute_gates)
                and all(item["pass"] for item in paired_gates)
            ),
        }
    return payload


def independent_descriptive_metric_rows(event_rows: Sequence[dict]) -> list[dict]:
    frame = pd.DataFrame(event_rows)
    primary = frame[frame["window"] == PRIMARY_WINDOW].copy()
    metrics = [
        "parameter_true_probability",
        "parameter_argmax_accuracy",
        "process_noise_true_probability",
        "process_noise_argmax_accuracy",
        "joint_cell_true_probability",
        "joint_cell_argmax_accuracy",
        "state_mean_normalized_rmse",
    ]
    rows: list[dict] = []
    for dimension, column in (
        ("source_cell", "source_cell"),
        ("destination_cell", "destination_cell"),
        ("sequence_position", "sequence_position"),
        ("transition_type", "transition_type"),
    ):
        per_basin = primary.groupby(
            ["algorithm", "knowledge_mode", "basin_id", column],
            sort=True,
            as_index=False,
        )[metrics].mean()
        for identity, group in per_basin.groupby(
            ["algorithm", "knowledge_mode", column], sort=True, dropna=False
        ):
            algorithm, knowledge_mode, level = identity
            row: dict[str, Any] = {
                "algorithm": str(algorithm),
                "knowledge_mode": str(knowledge_mode),
                "dimension": dimension,
                "dimension_value": str(level),
                "basin_count": int(group["basin_id"].astype(str).nunique()),
            }
            for metric in metrics:
                row[f"median_basin_{metric}"] = float(
                    np.median(group[metric].to_numpy(dtype=np.float64))
                )
            rows.append(row)
    rows.sort(
        key=lambda row: (
            row["algorithm"],
            row["knowledge_mode"],
            row["dimension"],
            row["dimension_value"],
        )
    )
    return rows


def _load_npz(path: Path) -> dict[str, np.ndarray]:
    with np.load(Path(path), allow_pickle=False) as archive:
        return {name: archive[name].copy() for name in archive.files}


def _truth_path(root: Path, basin_id: str, seed: int) -> Path:
    return Path(root) / "truth" / "bundles" / f"{str(basin_id).zfill(8)}_s{int(seed)}.npz"


def _task_path(root: Path, task: _Task) -> Path:
    return (
        Path(root)
        / "arms"
        / task.algorithm
        / task.knowledge_mode
        / f"{task.basin_id}_s{task.seed}.npz"
    )


def _canonical_registered_json(config: dict, key: str) -> str:
    return json.dumps(
        config.get(key, {}),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def _truth_content_sha256(arrays: Mapping[str, Any]) -> str:
    digest = hashlib.sha256()
    for name in TRUTH_ARRAY_NAMES:
        values = np.ascontiguousarray(arrays[name])
        digest.update(name.encode("utf-8"))
        digest.update(values.dtype.str.encode("ascii"))
        digest.update(np.asarray(values.shape, dtype=np.int64).tobytes())
        digest.update(values.tobytes())
    digest.update(
        np.asarray(
            [int(arrays["stage_days"]), int(arrays["clip_count"])],
            dtype=np.int64,
        ).tobytes()
    )
    return digest.hexdigest()


def _bundle_view(arrays: Mapping[str, Any]) -> Any:
    class _Bundle:
        pass

    bundle = _Bundle()
    for name in TRUTH_ARRAY_NAMES:
        setattr(bundle, name, np.asarray(arrays[name]))
    bundle.stage_days = int(arrays["stage_days"])
    bundle.clip_count = int(arrays["clip_count"])
    return bundle


def _read_csv_records(path: Path) -> list[dict[str, str]]:
    target = Path(path)
    if not target.is_file():
        raise FileNotFoundError(f"required CSV is missing: {target}")
    if target.stat().st_size == 0:
        return []
    with target.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _verify_registered_task_table(
    repo_root: Path, config: dict
) -> tuple[list[str], dict[str, int]]:
    path = Path(repo_root) / config["input_paths"]["formal_task_table"]
    rows = _read_csv_records(path)
    if len(rows) != EXPECTED_TRUTH_BUNDLES:
        raise AssertionError("registered task table does not contain 216 rows")
    basins = sorted({str(row["basin_id"]).zfill(8) for row in rows})
    if len(basins) != EXPECTED_BASINS:
        raise AssertionError("registered task table does not contain 36 basins")
    ranks = {basin: rank for rank, basin in enumerate(basins)}
    expected_rows = []
    for basin, rank in ranks.items():
        basin_sequences = []
        for seed_index, seed in enumerate(FORMAL_SEEDS):
            sequence_index = (rank + seed_index) % N_CELLS
            cells = _williams_sequence(sequence_index)
            basin_sequences.append(cells)
            expected_rows.append({
                "basin_id": basin,
                "basin_rank": str(rank),
                "seed": str(seed),
                "seed_index": str(seed_index),
                "sequence_index": str(sequence_index),
                "sequence_cells": "|".join(str(cell) for cell in cells),
                "sequence_pairs": "|".join(
                    f"{source}>{destination}"
                    for source, destination in zip(cells, cells[1:])
                ),
            })
        verify_basin_edge_coverage(basin_sequences)
    if rows != expected_rows:
        raise AssertionError("registered task table Williams mapping changed")
    for seed_index, seed in enumerate(FORMAL_SEEDS):
        assignments = [
            (rank + seed_index) % N_CELLS for rank in range(EXPECTED_BASINS)
        ]
        if sorted(assignments) != list(range(N_CELLS)) * 6:
            raise AssertionError(f"seed {seed} no longer assigns six basins per sequence")
    return basins, ranks


def _expected_tasks(basins: Sequence[str]) -> list[_Task]:
    tasks = [
        _Task(basin, seed, algorithm, knowledge_mode)
        for basin in basins
        for seed in FORMAL_SEEDS
        for algorithm in ("C", "P")
        for knowledge_mode in KNOWLEDGE_MODES
    ]
    if len(tasks) != EXPECTED_TASKS or len({task.task_id for task in tasks}) != EXPECTED_TASKS:
        raise AssertionError("independent task cross-product changed")
    return tasks


def _manifest_records(
    root: Path,
    config: dict,
    tasks: Sequence[_Task],
    *,
    config_hash: str,
) -> tuple[dict, dict[str, dict], dict[str, dict]]:
    manifest_path = root / "manifests" / "run_manifest.json"
    if not manifest_path.is_file():
        raise FileNotFoundError(f"formal run manifest is missing: {manifest_path}")
    with manifest_path.open(encoding="utf-8") as handle:
        manifest = json.load(handle)
    expected_counts = {
        "truth_bundles": EXPECTED_TRUTH_BUNDLES,
        "tasks": EXPECTED_TASKS,
        "events": EXPECTED_EVENTS,
        "failures": 0,
        "truth_clip_count": 0,
    }
    for name, expected in expected_counts.items():
        if int(manifest.get(name, -1)) != expected:
            raise AssertionError(f"formal manifest {name} changed")
    if manifest.get("experiment_id") != EXPERIMENT_ID:
        raise AssertionError("formal manifest experiment identity changed")
    if manifest.get("config_sha256") != config_hash:
        raise AssertionError("formal manifest configuration hash changed")
    if not isinstance(manifest.get("git_commit"), str) or len(manifest["git_commit"]) != 40:
        raise AssertionError("formal manifest frozen commit is missing")
    artifacts = config["artifact_paths"]
    truth_rows = _read_csv_records(root / artifacts["truth_manifest"])
    task_rows = _read_csv_records(root / artifacts["task_manifest"])
    failure_rows = _read_csv_records(root / artifacts["failure_manifest"])
    if failure_rows:
        raise AssertionError("formal failure manifest is not empty")
    if len(truth_rows) != EXPECTED_TRUTH_BUNDLES:
        raise AssertionError("truth manifest count changed")
    if len(task_rows) != EXPECTED_TASKS:
        raise AssertionError("task manifest count changed")
    truth_by_id = {str(row.get("task_id")): row for row in truth_rows}
    task_by_id = {str(row.get("task_id")): row for row in task_rows}
    if len(truth_by_id) != EXPECTED_TRUTH_BUNDLES:
        raise AssertionError("truth manifest has duplicate identities")
    expected_task_ids = {task.task_id for task in tasks}
    if len(task_by_id) != EXPECTED_TASKS or set(task_by_id) != expected_task_ids:
        raise AssertionError("task manifest identities changed")
    if any(row.get("run_status") != "success" for row in truth_rows + task_rows):
        raise AssertionError("formal manifest contains a non-success record")
    if sum(int(row.get("event_count", -1)) for row in task_rows) != EXPECTED_EVENTS:
        raise AssertionError("task manifest event count changed")
    return manifest, truth_by_id, task_by_id


def _verify_truth_archive(
    path: Path,
    arrays: Mapping[str, Any],
    *,
    basin_id: str,
    basin_rank: int,
    seed: int,
    config: dict,
    manifest_record: Mapping[str, str],
    config_hash: str,
) -> Any:
    sequence_index = (int(basin_rank) + FORMAL_SEEDS.index(int(seed))) % N_CELLS
    sequence = _expected_sequence(sequence_index)
    stage_days = 180
    day_count = 6 * stage_days
    for name in TRUTH_ARRAY_NAMES:
        if name not in arrays:
            raise AssertionError(f"truth bundle is missing array: {name}")
    expected_shapes = {
        "rain": (day_count,),
        "pet": (day_count,),
        "temperature": (day_count,),
        "pre_states": (day_count, STATE_COUNT),
        "post_states": (day_count, STATE_COUNT),
        "truth_q": (day_count,),
        "observations": (day_count,),
        "observation_errors": (day_count,),
        "truth_param_indices": (day_count,),
        "truth_noise_indices": (day_count,),
        "truth_cell_indices": (day_count,),
        "truth_parfc": (day_count,),
        "sequence": (N_CELLS, 2),
    }
    for name, shape in expected_shapes.items():
        values = np.asarray(arrays[name])
        if values.shape != shape:
            raise AssertionError(f"truth bundle {name} shape changed")
        if values.dtype.kind in "fc" and not np.all(np.isfinite(values)):
            raise AssertionError(f"truth bundle {name} contains non-finite values")
    _assert_array_equal(arrays["sequence"], sequence, "truth Williams sequence")
    if int(arrays["stage_days"]) != stage_days or int(arrays["clip_count"]) != 0:
        raise AssertionError("truth stage length or clip count changed")
    if str(arrays["basin_id"]) != str(basin_id).zfill(8):
        raise AssertionError("truth basin identity changed")
    if int(arrays["basin_rank"]) != int(basin_rank):
        raise AssertionError("truth basin rank changed")
    if int(arrays["seed"]) != int(seed) or int(arrays["sequence_index"]) != sequence_index:
        raise AssertionError("truth seed or sequence identity changed")
    switch_days = np.arange(1, N_CELLS, dtype=np.int64) * stage_days
    _assert_array_equal(arrays["switch_days"], switch_days, "truth switch days")
    _assert_array_equal(
        arrays["stage_indices"], np.repeat(np.arange(N_CELLS), stage_days), "truth stage indices"
    )
    expected_parameter = np.repeat(sequence[:, 0], stage_days)
    expected_noise = np.repeat(sequence[:, 1], stage_days)
    expected_cells = expected_parameter * N_NOISE + expected_noise
    _assert_array_equal(arrays["truth_param_indices"], expected_parameter, "truth parameter labels")
    _assert_array_equal(arrays["truth_noise_indices"], expected_noise, "truth process-noise labels")
    _assert_array_equal(arrays["truth_cell_indices"], expected_cells, "truth cell labels")
    _assert_array_equal(
        arrays["truth_rng_identity"],
        [
            int(config["random_streams"]["seed_entropy"]),
            int(basin_id),
            int(seed),
            int(config["random_streams"]["truth_process_noise_tag"]),
        ],
        "truth random stream identity",
    )
    _assert_array_equal(
        arrays["observation_rng_identity"],
        [
            int(config["random_streams"]["seed_entropy"]),
            int(basin_id),
            int(seed),
            int(config["random_streams"]["observation_error_tag"]),
        ],
        "observation random stream identity",
    )
    _assert_array_equal(arrays["candidate_parameter_keys"].astype(str), PARAM_KEYS, "parameter keys")
    parameter_values = np.asarray(arrays["candidate_parameter_values"], dtype=np.float64)
    if parameter_values.shape != (N_PARAMETER, len(PARAM_KEYS)):
        raise AssertionError("candidate parameter table shape changed")
    _assert_allclose(
        arrays["candidate_parameter_factors"], PARAMETER_FACTORS, "capacity factors"
    )
    _assert_allclose(
        arrays["candidate_process_noise_multipliers"],
        PROCESS_NOISE_MULTIPLIERS,
        "process-noise multipliers",
    )
    parfc_index = tuple(PARAM_KEYS).index("parFC")
    _assert_array_equal(
        arrays["truth_parfc"],
        parameter_values[expected_parameter, parfc_index],
        "truth field capacity",
    )
    _assert_array_equal(
        arrays["observations"],
        np.asarray(arrays["truth_q"]) + np.asarray(arrays["observation_errors"]),
        "truth observations",
    )
    if str(arrays["config_sha256"]) != config_hash:
        raise AssertionError("truth configuration hash changed")
    canonical_config = json.dumps(
        config, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    if str(arrays["config_json"]) != canonical_config:
        raise AssertionError("truth embedded configuration changed")
    registered_array_names = {
        "registered_input_hashes": "registered_inputs_json",
        "registered_implementation_hashes": "registered_implementation_json",
    }
    for key, array_name in registered_array_names.items():
        if str(arrays[array_name]) != _canonical_registered_json(config, key):
            raise AssertionError(f"truth embedded {key} changed")
    if not bool(arrays["round_trip_bitwise_verified"]):
        raise AssertionError("truth round-trip verification flag changed")
    content_hash = _truth_content_sha256(arrays)
    if str(arrays["truth_content_sha256"]) != content_hash:
        raise AssertionError("truth content hash changed")
    file_hash = sha256_file(path)
    if str(manifest_record.get("truth_sha256")) != file_hash:
        raise AssertionError("truth archive hash differs from manifest")
    if str(manifest_record.get("truth_content_sha256")) != content_hash:
        raise AssertionError("truth content hash differs from manifest")
    if int(manifest_record.get("clip_count", -1)) != 0:
        raise AssertionError("truth manifest clip count changed")
    return _bundle_view(arrays)


def _scalar_value(arrays: Mapping[str, Any], name: str) -> Any:
    value = np.asarray(arrays[name])
    if value.ndim != 0:
        raise AssertionError(f"task metadata {name} is not scalar")
    return value.item()


def _verify_task_metadata(
    path: Path,
    arrays: Mapping[str, Any],
    task: _Task,
    *,
    basin_rank: int,
    sequence_index: int,
    truth_path: Path,
    truth_content_hash: str,
    config: dict,
    manifest_record: Mapping[str, str],
    root: Path,
    config_hash: str,
) -> None:
    expected_scalars = {
        "task_id": task.task_id,
        "basin_id": task.basin_id,
        "basin_rank": int(basin_rank),
        "seed": int(task.seed),
        "arm_id": task.algorithm,
        "interaction_mode": ARM_MODES[task.algorithm],
        "knowledge_mode": task.knowledge_mode,
        "sequence_index": int(sequence_index),
    }
    for name, expected in expected_scalars.items():
        if _scalar_value(arrays, name) != expected:
            raise AssertionError(f"task metadata {name} changed")
    stored_truth_path = Path(str(_scalar_value(arrays, "truth_bundle_path")))
    if stored_truth_path != truth_path.relative_to(root):
        raise AssertionError("task truth-bundle path changed")
    truth_file_hash = sha256_file(truth_path)
    if str(_scalar_value(arrays, "truth_bundle_sha256")) != truth_file_hash:
        raise AssertionError("task truth-bundle hash changed")
    if str(_scalar_value(arrays, "truth_content_sha256")) != truth_content_hash:
        raise AssertionError("task truth-content hash changed")
    if str(_scalar_value(arrays, "config_sha256")) != config_hash:
        raise AssertionError("task configuration hash changed")
    registered_array_names = {
        "registered_input_hashes": "registered_inputs_json",
        "registered_implementation_hashes": "registered_implementation_json",
    }
    for key, raw_name in registered_array_names.items():
        if str(_scalar_value(arrays, raw_name)) != _canonical_registered_json(config, key):
            raise AssertionError(f"task embedded {key} changed")
    if not np.isfinite(float(_scalar_value(arrays, "observation_sigma"))) or float(
        _scalar_value(arrays, "observation_sigma")
    ) <= 0.0:
        raise AssertionError("task observation sigma changed")
    if not np.isfinite(float(_scalar_value(arrays, "compute_elapsed_seconds"))) or float(
        _scalar_value(arrays, "compute_elapsed_seconds")
    ) < 0.0:
        raise AssertionError("task compute duration changed")
    file_hash = sha256_file(path)
    if str(manifest_record.get("output_sha256")) != file_hash:
        raise AssertionError("raw task archive hash differs from manifest")
    if str(manifest_record.get("truth_bundle_sha256")) != truth_file_hash:
        raise AssertionError("task manifest truth hash changed")


def _expected_artifact_hash_rows(
    root: Path,
    config: dict,
    basins: Sequence[str],
    tasks: Sequence[_Task],
) -> list[dict]:
    artifacts = config["artifact_paths"]
    paths = [
        root / artifacts["truth_manifest"],
        root / artifacts["task_manifest"],
        root / artifacts["failure_manifest"],
        root / "manifests" / "run_manifest.json",
        *(_truth_path(root, basin, seed) for basin in basins for seed in FORMAL_SEEDS),
        *(_task_path(root, task) for task in tasks),
        root / artifacts["event_metrics"],
        root / artifacts["basin_metrics"],
        root / "verification" / "paired_event_metrics.csv",
        root / artifacts["paired_axis_metrics"],
        root / "verification" / "descriptive_metrics.csv",
        root / artifacts["decision_summary"],
    ]
    if len(paths) != 1522 or len(set(paths)) != len(paths):
        raise AssertionError("artifact hash path set changed")
    for path in paths:
        if not path.is_file():
            raise FileNotFoundError(f"registered evidence artifact is missing: {path}")
    return [
        {"path": path.relative_to(root).as_posix(), "sha256": sha256_file(path)}
        for path in sorted(paths, key=lambda value: value.as_posix())
    ]


def _write_json_new(path: Path, payload: dict) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")


def verify_formal_evidence(
    output_root: Path,
    *,
    repo_root: Path = REPO_ROOT,
    write: bool = True,
) -> dict:
    """Independently recompute and verify one complete formal result root."""

    root = Path(output_root).resolve()
    repository = Path(repo_root).resolve()
    config = load_registered_config(repository, verify_hashes=True)
    if config.get("experiment_id") != EXPERIMENT_ID:
        raise AssertionError("registered experiment identity changed")
    if tuple(config["balanced_sequence_contract"]["formal_seeds"]) != FORMAL_SEEDS:
        raise AssertionError("registered formal seeds changed")
    if dict(config["report_windows_zero_based_half_open"]) != {
        key: list(value) for key, value in REPORT_WINDOWS.items()
    }:
        raise AssertionError("registered report windows changed")
    if config.get("primary_window") != PRIMARY_WINDOW:
        raise AssertionError("registered primary window changed")
    if int(config["bootstrap_contract"]["replicates"]) != 20_000:
        raise AssertionError("registered bootstrap replicate count changed")
    if int(config["expected_counts"]["truth_bundles"]) != EXPECTED_TRUTH_BUNDLES:
        raise AssertionError("registered truth count changed")
    if int(config["expected_counts"]["tasks"]) != EXPECTED_TASKS:
        raise AssertionError("registered task count changed")
    if int(config["expected_counts"]["events"]) != EXPECTED_EVENTS:
        raise AssertionError("registered event count changed")

    basins, ranks = _verify_registered_task_table(repository, config)
    tasks = _expected_tasks(basins)
    config_hash = sha256_file(repository / CONFIG_PATH)
    run_manifest, truth_manifest, task_manifest = _manifest_records(
        root, config, tasks, config_hash=config_hash
    )
    event_rows: list[dict] = []
    paired_event_rows: list[dict] = []
    truth_archives_checked = 0
    raw_tasks_checked = 0
    for basin in basins:
        basin_sequences: list[tuple[int, ...]] = []
        for seed in FORMAL_SEEDS:
            truth_path = _truth_path(root, basin, seed)
            if not truth_path.is_file():
                raise FileNotFoundError(f"truth bundle is missing: {truth_path}")
            truth_arrays = _load_npz(truth_path)
            truth_identity = f"{basin}_s{seed}"
            if truth_identity not in truth_manifest:
                raise AssertionError("truth manifest identity is missing")
            bundle = _verify_truth_archive(
                truth_path,
                truth_arrays,
                basin_id=basin,
                basin_rank=ranks[basin],
                seed=seed,
                config=config,
                manifest_record=truth_manifest[truth_identity],
                config_hash=config_hash,
            )
            truth_archives_checked += 1
            sequence_index = (ranks[basin] + FORMAL_SEEDS.index(seed)) % N_CELLS
            basin_sequences.append(_williams_sequence(sequence_index))
            truth_content_hash = _truth_content_sha256(truth_arrays)
            for algorithm in ("C", "P"):
                arrays_by_mode: dict[str, dict[str, np.ndarray]] = {}
                for knowledge_mode in KNOWLEDGE_MODES:
                    task = _Task(basin, seed, algorithm, knowledge_mode)
                    path = _task_path(root, task)
                    if not path.is_file():
                        raise FileNotFoundError(f"raw replay task is missing: {path}")
                    arrays = _load_npz(path)
                    _verify_task_metadata(
                        path,
                        arrays,
                        task,
                        basin_rank=ranks[basin],
                        sequence_index=sequence_index,
                        truth_path=truth_path,
                        truth_content_hash=truth_content_hash,
                        config=config,
                        manifest_record=task_manifest[task.task_id],
                        root=root,
                        config_hash=config_hash,
                    )
                    verify_replay_task_arrays(
                        arrays,
                        bundle,
                        knowledge_mode=knowledge_mode,
                        expected_sequence_index=sequence_index,
                    )
                    arrays_by_mode[knowledge_mode] = arrays
                    event_rows.extend(
                        independent_event_metric_rows(
                            arrays,
                            basin_id=basin,
                            seed=seed,
                            algorithm=algorithm,
                            knowledge_mode=knowledge_mode,
                        )
                    )
                    raw_tasks_checked += 1
                paired_event_rows.extend(
                    independent_paired_event_rows(
                        arrays_by_mode["joint_unknown"],
                        arrays_by_mode["noise_known"],
                        axis="parameter",
                        basin_id=basin,
                        seed=seed,
                        algorithm=algorithm,
                    )
                )
                paired_event_rows.extend(
                    independent_paired_event_rows(
                        arrays_by_mode["joint_unknown"],
                        arrays_by_mode["param_known"],
                        axis="process_noise",
                        basin_id=basin,
                        seed=seed,
                        algorithm=algorithm,
                    )
                )
        verify_basin_edge_coverage(basin_sequences)

    if truth_archives_checked != EXPECTED_TRUTH_BUNDLES:
        raise AssertionError("independent truth archive count changed")
    if raw_tasks_checked != EXPECTED_TASKS:
        raise AssertionError("independent raw task count changed")
    if len(event_rows) != EXPECTED_EVENTS * len(REPORT_WINDOWS):
        raise AssertionError("independent event-metric row count changed")
    expected_paired_events = EXPECTED_BASINS * len(FORMAL_SEEDS) * len(ARM_MODES) * 5 * 2
    if len(paired_event_rows) != expected_paired_events:
        raise AssertionError("independent paired-event row count changed")

    basin_rows = independent_basin_metric_rows(event_rows)
    paired_basin_rows = independent_paired_basin_rows(paired_event_rows)
    descriptive_rows = independent_descriptive_metric_rows(event_rows)
    bootstrap = config["bootstrap_contract"]
    decisions = independent_decision_summary(
        basin_rows,
        paired_basin_rows,
        base_seed=int(bootstrap["base_seed"]),
        replicates=int(bootstrap["replicates"]),
    )
    decisions.update({
        "experiment_id": config["experiment_id"],
        "technical_complete": True,
        "truth_bundle_count": int(config["expected_counts"]["truth_bundles"]),
        "task_count": int(config["expected_counts"]["tasks"]),
        "event_count": int(config["expected_counts"]["events"]),
        "event_metric_row_count": len(event_rows),
        "basin_metric_row_count": len(basin_rows),
        "paired_event_metric_row_count": len(paired_event_rows),
        "paired_axis_metric_row_count": len(paired_basin_rows),
        "claim_boundary": (
            "36 admitted basins; synthetic truth and observations; known boundary; "
            "six registered continuous truth histories; true source parameter known for "
            "conservative mapping only; exact true pre-switch state reset; two capacity "
            "candidates; three process-noise "
            "candidates; destination days 91 through 180 only; no forecast or online claim"
        ),
    })

    artifacts = config["artifact_paths"]
    verification_root = root / "verification"
    compare_frame_artifact(
        root / artifacts["event_metrics"],
        pd.DataFrame(event_rows),
        ["basin_id", "seed", "algorithm", "knowledge_mode", "event_index", "window"],
        "event metrics",
    )
    compare_frame_artifact(
        root / artifacts["basin_metrics"],
        pd.DataFrame(basin_rows),
        ["basin_id", "algorithm", "knowledge_mode", "axis", "level"],
        "basin metrics",
    )
    compare_frame_artifact(
        verification_root / "paired_event_metrics.csv",
        pd.DataFrame(paired_event_rows),
        ["basin_id", "seed", "algorithm", "axis", "source_cell", "destination_cell"],
        "paired event metrics",
    )
    compare_frame_artifact(
        root / artifacts["paired_axis_metrics"],
        pd.DataFrame(paired_basin_rows),
        ["basin_id", "algorithm", "axis", "level"],
        "paired axis metrics",
    )
    compare_frame_artifact(
        verification_root / "descriptive_metrics.csv",
        pd.DataFrame(descriptive_rows),
        ["algorithm", "knowledge_mode", "dimension", "dimension_value"],
        "descriptive metrics",
    )
    compare_json_artifact(
        root / artifacts["decision_summary"], decisions, "decision summary"
    )
    hash_rows = _expected_artifact_hash_rows(root, config, basins, tasks)
    compare_frame_artifact(
        root / artifacts["artifact_hashes"],
        pd.DataFrame(hash_rows),
        ["path"],
        "artifact hashes",
    )

    payload = {
        "experiment_id": EXPERIMENT_ID,
        "status": "PASS",
        "technical_complete": True,
        "frozen_git_commit": run_manifest["git_commit"],
        "config_sha256": config_hash,
        "truth_bundles_verified": truth_archives_checked,
        "raw_tasks_verified": raw_tasks_checked,
        "events_verified": EXPECTED_EVENTS,
        "event_metric_rows_recomputed": len(event_rows),
        "basin_metric_rows_recomputed": len(basin_rows),
        "paired_event_rows_recomputed": len(paired_event_rows),
        "paired_axis_rows_recomputed": len(paired_basin_rows),
        "artifact_hashes_verified": len(hash_rows),
        "checks": {
            "williams_sequences_and_all_directed_edges": "PASS",
            "uniform_first_and_recursive_later_priors": "PASS",
            "same_truth_observations_and_true_state_resets": "PASS",
            "candidate_counts_coordinates_and_known_axes": "PASS",
            "four_report_windows_and_daily_marginal_argmax": "PASS",
            "event_cell_axis_basin_aggregation": "PASS",
            "twenty_thousand_basin_bootstrap_substreams": "PASS",
            "absolute_paired_and_overall_decisions": "PASS",
            "state_error_diagnostics": "PASS",
            "saved_artifact_values_and_hashes": "PASS",
        },
        "scientific_decisions": decisions["algorithms"],
    }
    if write:
        output_path = root / artifacts["independent_verification"]
        _write_json_new(output_path, payload)
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--route", choices=("local", "hpc"), default="local")
    parser.add_argument("--output-root", type=Path)
    arguments = parser.parse_args()
    config = load_registered_config(REPO_ROOT, verify_hashes=True)
    root = (
        arguments.output_root
        if arguments.output_root is not None
        else REPO_ROOT / config["output_roots"][arguments.route]
    )
    payload = verify_formal_evidence(root)
    print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
