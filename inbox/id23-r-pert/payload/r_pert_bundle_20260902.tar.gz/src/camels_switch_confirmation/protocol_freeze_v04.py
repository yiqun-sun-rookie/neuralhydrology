"""Fail-closed validation and recoverable registration for protocol v04.

The module deliberately imports neither basin-data loaders nor optimizers.  It
validates an explicitly supplied frozen credential and registers one canonical
configuration plus one byte-appended registry record under the registry file's
operating-system lock.
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import os
import re
import stat
import uuid
from collections.abc import Mapping, Sequence
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any


FROZEN_PROTOCOL_ID = "real_regime_parameter_domain_initialization_v04"
FROZEN_PROTOCOL_SCOPE = "parameter_axis_development_v04"
FROZEN_APPROVED_AT = "2026-08-24T16:27:22.7682204+08:00"
FROZEN_APPROVAL_EVIDENCE = (
    "The user replied 'go' after the complete six-item fourth-version contract was "
    "listed. This authorizes implementation, freezing, and registration, but does not "
    "authorize the full 27-restart calibration execution."
)
FROZEN_HUMAN_PROTOCOL_SHA256 = (
    "5cd95e5bfcdc8a9b12c9d8ea5f2ad940aaca7eeea15a4a55fe50c81d96d4fc35"
)
V04_EXPERIMENT_ID = "real_regime_parameter_calibration_development_screen_v04"
V04_CONFIG_RELATIVE_PATH = (
    "src/camels_switch_confirmation/configs/"
    "real_regime_parameter_calibration_development_screen_v04.json"
)
V04_PROTOCOL_RELATIVE_PATH = (
    "src/camels_switch_confirmation/protocols/"
    "real_regime_parameter_domain_initialization_v04.freeze.json"
)
V04_REGISTRY_COLUMNS = (
    "experiment_id",
    "classification",
    "hypothesis",
    "config_path",
    "config_sha256",
    "basin_manifest",
    "basin_manifest_sha256",
    "changed_factor",
    "fixed_factors",
    "restart_seeds",
    "status",
    "output_dir",
    "metrics_path",
    "paper_name",
    "notes",
    "updated_at",
    "error",
)
FROZEN_CHANGED_FACTORS = (
    "complete_first_version_parameter_domain",
    "fixed_ten_year_warmup_and_initialization_compatibility_gates",
)

V04_PARAMETER_DOMAIN = {
    "preset": "real_regime_physical_v04",
    "source": "complete_first_version_domain",
    "bounds": {
        "parTT": [-2.5, 2.5],
        "parCFMAX": [0.5, 10.0],
        "parCFR": [0.0, 0.1],
        "parCWH": [0.0, 0.2],
        "parFC": [50.0, 1000.0],
        "parBETA": [1.0, 6.0],
        "parLP": [0.2, 1.0],
        "parK0": [0.05, 0.9],
        "parK1": [0.01, 0.5],
        "parUZL": [0.0, 100.0],
        "parPERC": [0.0, 10.0],
        "parK2": [0.001, 0.2],
        "lag_time": [1.0, 10.0],
    },
    "post_run_expansion_allowed": False,
}

_COMMON_INITIAL_STATE = {
    "snowpack_mm": 0.0,
    "meltwater_mm": 0.0,
    "soil_moisture_fraction_of_parFC": 0.3,
    "upper_zone_storage_mm": 5.0,
}
V04_INITIALIZATION_COMPATIBILITY = {
    "warmup_days": 3652,
    "warmup_observations_use": "input_completeness_only",
    "analytical_memory": {
        "parameter": "parK2",
        "lower_bound": 0.001,
        "retained_fraction_formula": "(1 - parK2) ** warmup_days",
        "retained_fraction_max": 0.05,
        "worst_case_retained_fraction": 0.0258918452,
        "comparison_operator": "less_than_or_equal",
        "must_pass_before_data_access_or_optimizer": True,
    },
    "dry_initial_state": {**_COMMON_INITIAL_STATE, "lower_zone_storage_mm": 0.0},
    "wet_initial_state": {**_COMMON_INITIAL_STATE, "lower_zone_storage_mm": 100.0},
    "initial_state_convergence": {
        "first_fit_water_year": {"start": "1999-10-01", "end": "2000-09-30"},
        "lower_zone_difference_fraction_max": 0.05,
        "output_functional_distance_max": {
            "all_flow": 0.03,
            "low_flow": 0.03,
            "high_flow": 0.03,
        },
        "low_flow_log_offset_mm_day": 0.01,
        "may_select_or_promote_restart": False,
        "applies_to_selected_and_potential_support_restarts": True,
    },
    "validation_hydrograph_response": {
        "complete_water_years": [2006, 2007, 2008],
        "variability_ratio": [0.25, 4.0],
        "offset_mean_ratio": [0.25, 4.0],
        "total_daily_variation_ratio": [0.10, 10.0],
        "comparison_operator": "inclusive",
        "applies_to_selected_and_potential_support_restarts": True,
    },
}

V04_UNCHANGED_BASE_CONTRACT = {
    "rule": "all_base_fields_unchanged_except_listed_paths",
    "changed_paths": [
        "experiment_id",
        "parameter_bounds_preset",
        "periods.warmup",
        "protocol_id",
        "protocol_scope",
        "protocol_credential",
        "protocol_credential_sha256",
        "initialization_compatibility",
    ],
}
V04_EVIDENCE_CONTRACT = {
    "required_new_artifacts": [
        "parameter_domain_warmup_memory.json",
        "initial_state_convergence_hydrographs.csv",
        "initial_state_convergence_metrics.csv",
        "hydrograph_response_metrics.csv",
        "environment_capture.json",
    ],
    "independent_raw_recomputation_required": True,
    "validation_may_select_or_promote_restart": False,
}
V04_LIFECYCLE = {
    "code_and_tests_before_registration": True,
    "real_optimizer_calls_before_registration": 0,
    "registration_must_be_atomic_and_recoverable": True,
    "execution_requires_separate_user_authorization": True,
    "one_terminal_result_per_experiment_id": True,
}
V04_INTERPRETATION_PERMISSIONS = {
    "fixed_parameter_continuous_replay_development": True,
    "online_parameter_switching": False,
    "filter_state_mapping": False,
    "parameter_identification": False,
    "process_noise_axis": False,
    "joint_parameter_process_noise_axis": False,
    "formal_holdout_evaluation": False,
    "scientific_claim": False,
}

V04_REGISTRY_HYPOTHESIS = (
    "A complete upstream parameter domain and fixed ten-year warmup can produce "
    "initial-state-compatible responsive development hydrographs"
)
V04_REGISTRY_FIXED_FACTORS = (
    "basins; forcing; potential evapotranspiration; routing; fit and validation "
    "periods; flow groups; optimization threshold; seeds; fit-only selection; "
    "third-version stability and validation gates; boundary and cross-basin gates"
)
V04_REGISTRY_NOTES = (
    "Combined parameter-domain and initialization-compatibility correction on exposed "
    "development basins only; no noise axis, joint axis, formal evaluation, parameter "
    "identification, or scientific claim is authorized."
)
_PLACEHOLDER = re.compile(
    r"^(?:tbd|todo|pending|placeholder|not[_ -]?set|fill[_ -]?me|unknown)$",
    flags=re.IGNORECASE,
)
_WINDOWS_REPARSE_POINT = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)


class ProtocolNotFrozenError(ValueError):
    """Raised when a credential, configuration, row, or transaction is unsafe."""


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _byte_identity(value: bytes) -> dict[str, Any]:
    return {"size": len(value), "sha256": hashlib.sha256(value).hexdigest()}


def _reject_incomplete(value: Any, label: str) -> None:
    if value is None:
        raise ProtocolNotFrozenError(f"{label} must not be null")
    if type(value) is str:
        if not value.strip() or _PLACEHOLDER.fullmatch(value.strip()):
            raise ProtocolNotFrozenError(f"{label} contains a placeholder")
        return
    if type(value) is bool or type(value) is int:
        return
    if type(value) is float:
        if not math.isfinite(value):
            raise ProtocolNotFrozenError(f"{label} must be finite")
        return
    if type(value) is dict:
        for key, item in value.items():
            if type(key) is not str:
                raise ProtocolNotFrozenError(f"{label} keys must be strings")
            _reject_incomplete(item, f"{label}.{key}")
        return
    if type(value) is list:
        if not value:
            raise ProtocolNotFrozenError(f"{label} must not be empty")
        for index, item in enumerate(value):
            _reject_incomplete(item, f"{label}[{index}]")
        return
    raise ProtocolNotFrozenError(f"{label} has an unsupported type")


def _require_strict_tree(actual: Any, expected: Any, label: str) -> None:
    if type(actual) is not type(expected):
        raise ProtocolNotFrozenError(
            f"{label} type differs: expected {type(expected).__name__}"
        )
    if type(expected) is dict:
        if set(actual) != set(expected):
            raise ProtocolNotFrozenError(f"{label} fields differ")
        for key in expected:
            _require_strict_tree(actual[key], expected[key], f"{label}.{key}")
        return
    if type(expected) is list:
        if len(actual) != len(expected):
            raise ProtocolNotFrozenError(f"{label} length differs")
        for index, (item, expected_item) in enumerate(zip(actual, expected)):
            _require_strict_tree(item, expected_item, f"{label}[{index}]")
        return
    if type(expected) is float and not math.isfinite(actual):
        raise ProtocolNotFrozenError(f"{label} must be finite")
    if actual != expected:
        raise ProtocolNotFrozenError(f"{label} differs from the frozen value")


def _safe_repo_file(
    repo_root: Path,
    raw_path: Any,
    expected_digest: Any,
    label: str,
) -> Path:
    if type(raw_path) is not str:
        raise ProtocolNotFrozenError(f"{label} path must be a string")
    relative = Path(raw_path)
    if relative.is_absolute() or ".." in relative.parts:
        raise ProtocolNotFrozenError(f"{label} path is unsafe")
    path = (Path(repo_root).resolve() / relative).resolve()
    if not path.is_file():
        raise ProtocolNotFrozenError(f"{label} is missing: {path}")
    if (
        type(expected_digest) is not str
        or re.fullmatch(r"[0-9a-f]{64}", expected_digest) is None
        or _sha256(path) != expected_digest
    ):
        raise ProtocolNotFrozenError(f"{label} hash differs")
    return path


def validate_v04_protocol_document(
    repo_root: Path,
    document: Mapping[str, Any],
) -> dict[str, Any]:
    """Validate the complete approved fourth-version credential contract."""

    if type(document) is not dict:
        raise ProtocolNotFrozenError("protocol credential must be a plain object")
    expected_keys = {
        "schema_version",
        "protocol_id",
        "protocol_status",
        "protocol_scope",
        "approved_at",
        "approval_evidence",
        "human_protocol_path",
        "human_protocol_sha256",
        "base_experiment_id",
        "base_config_path",
        "base_config_sha256",
        "changed_factors",
        "parameter_domain",
        "initialization_compatibility",
        "unchanged_base_contract",
        "evidence_contract",
        "lifecycle",
        "interpretation_permissions",
    }
    if set(document) != expected_keys:
        raise ProtocolNotFrozenError("protocol credential fields differ from the contract")
    _reject_incomplete(document, "protocol credential")
    for field, expected in (
        ("schema_version", 1),
        ("protocol_id", FROZEN_PROTOCOL_ID),
        ("protocol_status", "frozen"),
        ("protocol_scope", FROZEN_PROTOCOL_SCOPE),
        ("approved_at", FROZEN_APPROVED_AT),
        ("approval_evidence", FROZEN_APPROVAL_EVIDENCE),
        ("human_protocol_path", (
            "docs/plans/"
            "2026-08-24-real-regime-parameter-domain-initialization-principle-v04.md"
        )),
        ("human_protocol_sha256", FROZEN_HUMAN_PROTOCOL_SHA256),
        ("base_experiment_id", "real_regime_parameter_calibration_development_screen_v03"),
        ("base_config_path", (
            "src/camels_switch_confirmation/configs/"
            "real_regime_parameter_calibration_development_screen_v03.json"
        )),
    ):
        _require_strict_tree(document[field], expected, f"protocol credential.{field}")
    try:
        approved = datetime.fromisoformat(document["approved_at"])
    except (TypeError, ValueError) as error:
        raise ProtocolNotFrozenError("approved_at must be ISO-8601") from error
    if approved.tzinfo is None or approved.utcoffset() is None:
        raise ProtocolNotFrozenError("approved_at must include a timezone offset")
    root = Path(repo_root).resolve()
    _safe_repo_file(
        root,
        document["human_protocol_path"],
        document["human_protocol_sha256"],
        "human protocol",
    )
    _safe_repo_file(
        root,
        document["base_config_path"],
        document["base_config_sha256"],
        "base configuration",
    )
    for field, expected in (
        ("changed_factors", list(FROZEN_CHANGED_FACTORS)),
        ("parameter_domain", V04_PARAMETER_DOMAIN),
        ("initialization_compatibility", V04_INITIALIZATION_COMPATIBILITY),
        ("unchanged_base_contract", V04_UNCHANGED_BASE_CONTRACT),
        ("evidence_contract", V04_EVIDENCE_CONTRACT),
        ("lifecycle", V04_LIFECYCLE),
        ("interpretation_permissions", V04_INTERPRETATION_PERMISSIONS),
    ):
        _require_strict_tree(document[field], expected, f"protocol credential.{field}")
    return json.loads(json.dumps(document, allow_nan=False))


def load_frozen_protocol(
    repo_root: Path,
    credential_path: Path,
    *,
    expected_sha256: str,
) -> dict[str, Any]:
    """Load a strict JSON credential bound to an explicit file digest."""

    path = Path(credential_path).resolve()
    if (
        type(expected_sha256) is not str
        or re.fullmatch(r"[0-9a-f]{64}", expected_sha256) is None
        or not path.is_file()
        or _sha256(path) != expected_sha256
    ):
        raise ProtocolNotFrozenError("protocol credential hash differs from the configuration")
    try:
        document = json.loads(
            path.read_text(encoding="utf-8"),
            parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)),
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
        raise ProtocolNotFrozenError("protocol credential is not strict finite JSON") from error
    return validate_v04_protocol_document(repo_root, document)


def _load_strict_json(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(
            path.read_text(encoding="utf-8"),
            parse_constant=lambda item: (_ for _ in ()).throw(ValueError(item)),
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
        raise ProtocolNotFrozenError(f"{label} is not strict finite JSON") from error
    if type(value) is not dict:
        raise ProtocolNotFrozenError(f"{label} must be a plain object")
    _reject_incomplete(value, label)
    return value


def validate_v04_registration_config(
    repo_root: Path,
    config: Mapping[str, Any],
) -> dict[str, Any]:
    """Require exactly the approved combined fourth-version configuration."""

    if type(config) is not dict:
        raise ProtocolNotFrozenError("fourth-version configuration must be a plain object")
    root = Path(repo_root).resolve()
    required = {
        "protocol_id",
        "protocol_scope",
        "protocol_credential",
        "protocol_credential_sha256",
    }
    if not required.issubset(config):
        raise ProtocolNotFrozenError("fourth-version configuration lacks protocol binding")
    if config["protocol_id"] != FROZEN_PROTOCOL_ID or config["protocol_scope"] != FROZEN_PROTOCOL_SCOPE:
        raise ProtocolNotFrozenError("fourth-version protocol identity differs")
    if type(config["protocol_credential"]) is not str:
        raise ProtocolNotFrozenError("fourth-version credential path must be a string")
    relative = Path(config["protocol_credential"])
    if relative.is_absolute() or ".." in relative.parts or relative.as_posix() != V04_PROTOCOL_RELATIVE_PATH:
        raise ProtocolNotFrozenError("fourth-version credential path is noncanonical")
    credential = load_frozen_protocol(
        root,
        root / relative,
        expected_sha256=config["protocol_credential_sha256"],
    )
    base_path = _safe_repo_file(
        root,
        credential["base_config_path"],
        credential["base_config_sha256"],
        "base configuration",
    )
    base = _load_strict_json(base_path, "base configuration")
    expected = json.loads(json.dumps(base, allow_nan=False))
    expected.update({
        "experiment_id": V04_EXPERIMENT_ID,
        "parameter_bounds_preset": "real_regime_physical_v04",
        "protocol_id": FROZEN_PROTOCOL_ID,
        "protocol_scope": FROZEN_PROTOCOL_SCOPE,
        "protocol_credential": V04_PROTOCOL_RELATIVE_PATH,
        "protocol_credential_sha256": config["protocol_credential_sha256"],
        "initialization_compatibility": V04_INITIALIZATION_COMPATIBILITY,
    })
    expected["periods"]["warmup"] = {
        "start": "1989-10-01",
        "end": "1999-09-30",
    }
    try:
        _require_strict_tree(config, expected, "fourth-version configuration")
    except ProtocolNotFrozenError as error:
        raise ProtocolNotFrozenError(
            f"fourth-version configuration differs outside the approved combined contract: {error}"
        ) from error
    return credential


def canonical_v04_config_payload(repo_root: Path, config: Mapping[str, Any]) -> bytes:
    """Return the sole canonical byte representation of a v04 configuration."""

    validate_v04_registration_config(repo_root, config)
    try:
        value = json.dumps(
            config,
            indent=2,
            sort_keys=True,
            ensure_ascii=False,
            allow_nan=False,
        ) + "\n"
    except (TypeError, ValueError) as error:
        raise ProtocolNotFrozenError("fourth-version configuration is not finite JSON") from error
    return value.encode("utf-8")


def _repo_relative(repo_root: Path, path: Path, label: str) -> str:
    root = Path(repo_root).resolve()
    resolved = Path(path).resolve()
    try:
        return resolved.relative_to(root).as_posix()
    except ValueError as error:
        raise ProtocolNotFrozenError(f"{label} path leaves the repository") from error


def _validated_timestamp(value: Any) -> str:
    if type(value) is not str:
        raise ProtocolNotFrozenError("registry updated_at must be a string")
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError as error:
        raise ProtocolNotFrozenError("registry updated_at must be ISO-8601") from error
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ProtocolNotFrozenError("registry updated_at must include a timezone offset")
    return value


def build_v04_registry_row(
    repo_root: Path,
    config: Mapping[str, Any],
    config_path: Path,
    *,
    updated_at: str | None = None,
) -> dict[str, str]:
    """Derive the complete registry row from the canonical v04 configuration."""

    root = Path(repo_root).resolve()
    validate_v04_registration_config(root, config)
    config_relative = _repo_relative(root, config_path, "configuration")
    if config_relative != V04_CONFIG_RELATIVE_PATH:
        raise ProtocolNotFrozenError(f"configuration path must remain {V04_CONFIG_RELATIVE_PATH}")
    manifest_relative = Path(str(config["basin_manifest"])).as_posix()
    manifest = root / manifest_relative
    if not manifest.is_file():
        raise ProtocolNotFrozenError("basin manifest is missing")
    output = root / str(config["results_root"]) / str(config["experiment_id"])
    payload = canonical_v04_config_payload(root, config)
    timestamp = _validated_timestamp(
        datetime.now().astimezone().isoformat() if updated_at is None else updated_at
    )
    row = {
        "experiment_id": V04_EXPERIMENT_ID,
        "classification": "development_screen",
        "hypothesis": V04_REGISTRY_HYPOTHESIS,
        "config_path": config_relative,
        "config_sha256": hashlib.sha256(payload).hexdigest(),
        "basin_manifest": manifest_relative,
        "basin_manifest_sha256": _sha256(manifest),
        "changed_factor": ";".join(FROZEN_CHANGED_FACTORS),
        "fixed_factors": V04_REGISTRY_FIXED_FACTORS,
        "restart_seeds": ";".join(str(seed) for seed in config["optimizer"]["restart_seeds"]),
        "status": "registered_not_run",
        "output_dir": _repo_relative(root, output, "output"),
        "metrics_path": "validation_metrics.csv",
        "paper_name": "development_only",
        "notes": V04_REGISTRY_NOTES,
        "updated_at": timestamp,
        "error": "",
    }
    return {column: row[column] for column in V04_REGISTRY_COLUMNS}


def _validate_registry_row(
    repo_root: Path,
    config: Mapping[str, Any],
    config_path: Path,
    row: Mapping[str, Any],
) -> dict[str, str]:
    if type(row) is not dict or set(row) != set(V04_REGISTRY_COLUMNS):
        raise ProtocolNotFrozenError("registry row fields differ from the contract")
    for field, value in row.items():
        if type(value) is not str or "\r" in value or "\n" in value:
            raise ProtocolNotFrozenError(f"registry row {field} must be a single-line string")
    expected = build_v04_registry_row(
        repo_root,
        config,
        config_path,
        updated_at=_validated_timestamp(row["updated_at"]),
    )
    _require_strict_tree(dict(row), expected, "registry row")
    return expected


def _parse_registry_exact(raw: bytes) -> tuple[bytes, list[dict[str, str]], str]:
    if not raw.endswith(b"\n"):
        raise ProtocolNotFrozenError(
            "registry must end with a line terminator before byte-preserving append"
        )
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ProtocolNotFrozenError("registry must be strict UTF-8") from error
    if b"\r\n" in raw:
        if b"\r" in raw.replace(b"\r\n", b"") or b"\n" in raw.replace(b"\r\n", b""):
            raise ProtocolNotFrozenError("registry uses mixed line terminators")
        terminator = "\r\n"
    else:
        if b"\r" in raw:
            raise ProtocolNotFrozenError("registry uses an unsupported line terminator")
        terminator = "\n"
    try:
        records = list(csv.reader(io.StringIO(text, newline=""), strict=True))
    except csv.Error as error:
        raise ProtocolNotFrozenError("registry is not strict comma-separated values") from error
    if not records or tuple(records[0]) != V04_REGISTRY_COLUMNS:
        raise ProtocolNotFrozenError("registry columns or order differ from the contract")
    rows: list[dict[str, str]] = []
    for index, values in enumerate(records[1:], start=2):
        if len(values) != len(V04_REGISTRY_COLUMNS):
            raise ProtocolNotFrozenError(f"registry row {index} has the wrong field count")
        if any("\r" in value or "\n" in value for value in values):
            raise ProtocolNotFrozenError(f"registry row {index} contains an embedded line break")
        rows.append(dict(zip(V04_REGISTRY_COLUMNS, values)))
    identifiers = [row["experiment_id"] for row in rows]
    if len(identifiers) != len(set(identifiers)):
        raise ProtocolNotFrozenError("registry contains duplicate experiment identifiers")
    return raw, rows, terminator


def _registry_append_bytes(row: Mapping[str, str], terminator: str) -> bytes:
    output = io.StringIO(newline="")
    csv.writer(output, lineterminator=terminator, quoting=csv.QUOTE_MINIMAL).writerow(
        [row[column] for column in V04_REGISTRY_COLUMNS]
    )
    value = output.getvalue().encode("utf-8")
    parsed = list(csv.reader(io.StringIO(value.decode("utf-8"), newline=""), strict=True))
    if parsed != [[row[column] for column in V04_REGISTRY_COLUMNS]]:
        raise ProtocolNotFrozenError("registry append must encode exactly one record")
    return value


def _is_link_or_reparse(metadata: os.stat_result) -> bool:
    return stat.S_ISLNK(metadata.st_mode) or bool(
        getattr(metadata, "st_file_attributes", 0) & _WINDOWS_REPARSE_POINT
    )


def _lexists(path: Path) -> bool:
    return os.path.lexists(os.fspath(path))


def _require_regular(path: Path, label: str, *, required: bool = True) -> os.stat_result | None:
    try:
        metadata = os.lstat(path)
    except FileNotFoundError:
        if required:
            raise FileNotFoundError(f"{label} is missing: {path}")
        return None
    if _is_link_or_reparse(metadata) or not stat.S_ISREG(metadata.st_mode):
        raise ProtocolNotFrozenError(f"{label} must be a regular non-link file")
    return metadata


def _assert_absent(path: Path, label: str) -> None:
    if _lexists(path):
        metadata = os.lstat(path)
        if _is_link_or_reparse(metadata):
            raise ProtocolNotFrozenError(f"{label} is an unsafe link")
        raise FileExistsError(f"{label} already exists: {path}")


def _read_regular(path: Path, label: str) -> bytes:
    _require_regular(path, label)
    return Path(path).read_bytes()


def _path_identity(path: Path, label: str) -> dict[str, Any] | None:
    if not _lexists(path):
        return None
    return _byte_identity(_read_regular(path, label))


def _write_durable(path: Path, value: bytes, *, exclusive: bool) -> None:
    flags = os.O_WRONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    if exclusive:
        _assert_absent(path, "transaction artifact")
        flags |= os.O_CREAT | os.O_EXCL
    else:
        _require_regular(path, "transaction artifact")
        flags |= os.O_TRUNC
    descriptor = os.open(path, flags, 0o600)
    try:
        view = memoryview(value)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise OSError("durable write made no progress")
            view = view[written:]
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _unlink_regular(path: Path, label: str) -> None:
    if not _lexists(path):
        return
    _require_regular(path, label)
    os.unlink(path)


@contextmanager
def _exclusive_registry_registration_lock(registry: Path):
    """Take the unique operating-system lock on the real registry file."""

    registry = Path(os.path.abspath(os.fspath(registry)))
    metadata = _require_regular(registry, "registry")
    descriptor = os.open(registry, os.O_RDWR | getattr(os, "O_BINARY", 0))
    handle = os.fdopen(descriptor, "r+b", buffering=0)
    locked = False
    try:
        if not os.path.samestat(metadata, os.fstat(handle.fileno())):
            raise ProtocolNotFrozenError("registry changed while opening the lock")
        try:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            locked = True
        except OSError as error:
            raise FileExistsError(f"registry registration lock is already held: {registry}") from error
        yield handle
    finally:
        try:
            if locked:
                handle.seek(0)
                if os.name == "nt":
                    import msvcrt

                    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        finally:
            handle.close()


def _transaction_paths(config: Path, registry: Path, transaction_id: str) -> dict[str, Path]:
    return {
        "journal": registry.with_name(registry.name + ".registration.journal.json"),
        "journal_temporary": registry.with_name(registry.name + ".registration.journal.json.tmp"),
        "config_stage": config.with_name(f".{config.name}.{transaction_id}.registration.stage"),
        "registry_stage": registry.with_name(f".{registry.name}.{transaction_id}.registration.stage"),
        "config_install": config.with_name(config.name + ".registration.install"),
    }


def _journal_payload(document: Mapping[str, Any]) -> bytes:
    return (
        json.dumps(document, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n"
    ).encode("utf-8")


def _create_journal(path: Path, document: Mapping[str, Any]) -> None:
    temporary = path.with_name(path.name + ".tmp")
    _assert_absent(path, "registration journal")
    _write_durable(temporary, _journal_payload(document), exclusive=True)
    try:
        os.link(temporary, path, follow_symlinks=False)
    finally:
        if _lexists(path):
            _unlink_regular(temporary, "journal temporary")


def _set_journal_phase(path: Path, document: dict[str, Any], phase: str) -> None:
    temporary = path.with_name(path.name + ".tmp")
    document["phase"] = phase
    _write_durable(temporary, _journal_payload(document), exclusive=True)
    os.replace(temporary, path)


def _cleanup_registration_transaction(journal: Path, paths: Mapping[str, Path]) -> None:
    for key in ("config_stage", "registry_stage", "config_install", "journal_temporary"):
        _unlink_regular(paths[key], f"registration {key}")
    _unlink_regular(journal, "registration journal")


def _publish_config_payload_exclusive(payload: bytes, destination: Path, install: Path) -> None:
    _assert_absent(destination, "configuration")
    _write_durable(install, payload, exclusive=True)
    os.link(install, destination, follow_symlinks=False)
    if _path_identity(destination, "published configuration") != _byte_identity(payload):
        raise ProtocolNotFrozenError("published configuration hash differs")
    _unlink_regular(install, "configuration install")


def _read_locked_registry(handle) -> bytes:
    handle.seek(0)
    return handle.read()


def _registry_state(current: bytes, before: bytes, append: bytes) -> str:
    if current == before:
        return "before"
    if current == before + append:
        return "after"
    if current.startswith(before):
        suffix = current[len(before):]
        if suffix and len(suffix) < len(append) and append.startswith(suffix):
            return "partial"
    return "unknown"


def _append_registry_suffix(handle, registry: Path, before: bytes, append: bytes) -> None:
    """Append only the missing bytes of the one canonical registry record."""

    current = _read_locked_registry(handle)
    state = _registry_state(current, before, append)
    if state == "after":
        return
    if state not in {"before", "partial"}:
        raise ProtocolNotFrozenError("registration found an unknown registry identity")
    remaining = append[len(current) - len(before):]
    handle.seek(0, os.SEEK_END)
    view = memoryview(remaining)
    while view:
        written = handle.write(view)
        if written is None or written <= 0:
            raise OSError("registry append made no progress")
        view = view[written:]
    handle.flush()
    os.fsync(handle.fileno())
    if _read_locked_registry(handle) != before + append:
        raise ProtocolNotFrozenError("registry is not the old bytes plus one record")


def _load_journal(
    root: Path,
    registry: Path,
    *,
    expected_experiment_id: str = V04_EXPERIMENT_ID,
    expected_config_relative_path: str = V04_CONFIG_RELATIVE_PATH,
) -> tuple[dict[str, Any], dict[str, Path]] | None:
    journal = registry.with_name(registry.name + ".registration.journal.json")
    temporary = journal.with_name(journal.name + ".tmp")
    if _lexists(temporary):
        if _lexists(journal):
            # A phase update writes and syncs this temporary before replacing
            # the already durable journal.  The filesystem identities, not the
            # advisory phase, decide recovery, so an interrupted newer phase
            # may be discarded deterministically.
            _require_regular(temporary, "journal temporary")
            _unlink_regular(temporary, "journal temporary")
        else:
            os.link(temporary, journal, follow_symlinks=False)
            _unlink_regular(temporary, "journal temporary")
    if not _lexists(journal):
        return None
    try:
        document = json.loads(
            _read_regular(journal, "journal").decode("utf-8"),
            parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)),
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
        raise ProtocolNotFrozenError("registration journal is not strict finite JSON") from error
    expected_keys = {
        "schema_version",
        "transaction_id",
        "phase",
        "experiment_id",
        "config_path",
        "registry_path",
        "config_stage_path",
        "registry_stage_path",
        "config_after",
        "registry_before",
        "registry_append",
        "registry_after",
    }
    if type(document) is not dict or set(document) != expected_keys:
        raise ProtocolNotFrozenError("registration journal fields differ")
    transaction_id = document["transaction_id"]
    if type(transaction_id) is not str or re.fullmatch(r"[0-9a-f]{32}", transaction_id) is None:
        raise ProtocolNotFrozenError("registration journal transaction identifier is invalid")
    if document["phase"] not in {"declared", "prepared", "config_visible", "committed"}:
        raise ProtocolNotFrozenError("registration journal phase is invalid")
    if (
        document["experiment_id"] != expected_experiment_id
        or document["config_path"] != expected_config_relative_path
    ):
        raise ProtocolNotFrozenError("registration journal target is noncanonical")
    config = root / document["config_path"]
    recorded_registry = root / document["registry_path"]
    if recorded_registry.resolve() != registry.resolve():
        raise ProtocolNotFrozenError("registration journal names another registry")
    paths = _transaction_paths(config, registry, transaction_id)
    if document["config_stage_path"] != _repo_relative(root, paths["config_stage"], "config stage"):
        raise ProtocolNotFrozenError("journal configuration stage is noncanonical")
    if document["registry_stage_path"] != _repo_relative(root, paths["registry_stage"], "registry stage"):
        raise ProtocolNotFrozenError("journal registry stage is noncanonical")
    for key in ("config_after", "registry_before", "registry_after"):
        identity = document[key]
        if (
            type(identity) is not dict
            or set(identity) != {"size", "sha256"}
            or type(identity["size"]) is not int
            or identity["size"] < 0
            or type(identity["sha256"]) is not str
            or re.fullmatch(r"[0-9a-f]{64}", identity["sha256"]) is None
        ):
            raise ProtocolNotFrozenError(f"journal {key} identity is invalid")
    append_identity = document["registry_append"]
    if (
        type(append_identity) is not dict
        or set(append_identity) != {"size", "sha256", "csv_record_count"}
        or type(append_identity["size"]) is not int
        or append_identity["size"] <= 0
        or type(append_identity["sha256"]) is not str
        or re.fullmatch(r"[0-9a-f]{64}", append_identity["sha256"]) is None
        or append_identity["csv_record_count"] != 1
    ):
        raise ProtocolNotFrozenError("journal registry append identity is invalid")
    if document["registry_after"]["size"] != (
        document["registry_before"]["size"] + append_identity["size"]
    ):
        raise ProtocolNotFrozenError("journal registry sizes do not form one append")
    paths.update({"journal": journal, "journal_temporary": temporary, "config": config})
    return document, paths


def _stage_bytes(path: Path, identity: Mapping[str, Any], label: str) -> bytes:
    value = _read_regular(path, f"{label} stage")
    if _byte_identity(value) != dict(identity):
        raise ProtocolNotFrozenError(f"{label} recovery stage hash differs")
    return value


def _verify_after(value: bytes, document: Mapping[str, Any]) -> None:
    split = document["registry_before"]["size"]
    prefix, suffix = value[:split], value[split:]
    if (
        _byte_identity(value) != document["registry_after"]
        or _byte_identity(prefix) != document["registry_before"]
        or _byte_identity(suffix)
        != {
            "size": document["registry_append"]["size"],
            "sha256": document["registry_append"]["sha256"],
        }
    ):
        raise ProtocolNotFrozenError("new registry violates the old-prefix plus one-record invariant")


def _recover_transaction(
    root: Path,
    registry: Path,
    handle,
    payload: bytes,
    row: Mapping[str, str],
    *,
    expected_experiment_id: str = V04_EXPERIMENT_ID,
    expected_config_relative_path: str = V04_CONFIG_RELATIVE_PATH,
) -> dict[str, Any] | None:
    loaded = _load_journal(
        root,
        registry,
        expected_experiment_id=expected_experiment_id,
        expected_config_relative_path=expected_config_relative_path,
    )
    if loaded is None:
        return None
    document, paths = loaded
    if document["config_after"] != _byte_identity(payload):
        raise ProtocolNotFrozenError("recovery configuration differs from caller; evidence retained")
    current = _read_locked_registry(handle)
    before_size = document["registry_before"]["size"]
    if len(current) < before_size:
        raise ProtocolNotFrozenError("recovery registry identity is unknown; evidence retained")
    before = current[:before_size]
    if _byte_identity(before) != document["registry_before"]:
        raise ProtocolNotFrozenError("recovery registry identity is unknown; evidence retained")
    _, _, terminator = _parse_registry_exact(before)
    append = _registry_append_bytes(row, terminator)
    if {
        **_byte_identity(append),
        "csv_record_count": 1,
    } != document["registry_append"]:
        raise ProtocolNotFrozenError("recovery append differs from caller; evidence retained")
    state = _registry_state(current, before, append)
    config_identity = _path_identity(paths["config"], "recovery configuration")
    config_state = "absent" if config_identity is None else "after" if config_identity == document["config_after"] else "unknown"
    if state == "unknown" or config_state == "unknown":
        raise ProtocolNotFrozenError("recovery found an unknown identity; evidence retained")
    if state == "before" and config_state == "absent":
        _cleanup_registration_transaction(paths["journal"], paths)
        return {"status": "rolled_back", **document}
    if state in {"before", "partial"} and config_state == "after":
        staged = _stage_bytes(
            paths["registry_stage"],
            {"size": document["registry_append"]["size"], "sha256": document["registry_append"]["sha256"]},
            "registry",
        )
        if staged != append:
            raise ProtocolNotFrozenError("registry recovery stage differs from caller")
        _append_registry_suffix(handle, registry, before, staged)
    elif state == "after" and config_state == "absent":
        staged = _stage_bytes(paths["config_stage"], document["config_after"], "configuration")
        if staged != payload:
            raise ProtocolNotFrozenError("configuration recovery stage differs from caller")
        _publish_config_payload_exclusive(staged, paths["config"], paths["config_install"])
    elif state == "after" and config_state == "after":
        pass
    else:
        raise ProtocolNotFrozenError("recovery state is unsupported; evidence retained")
    _verify_after(_read_locked_registry(handle), document)
    if _path_identity(paths["config"], "recovery configuration") != document["config_after"]:
        raise ProtocolNotFrozenError("recovery could not restore configuration")
    _set_journal_phase(paths["journal"], document, "committed")
    _cleanup_registration_transaction(paths["journal"], paths)
    return {"status": "committed", **document}


def _rollback_transaction(
    registry: Path,
    handle,
    document: Mapping[str, Any],
    paths: Mapping[str, Path],
    before: bytes,
    append: bytes,
    *,
    config_published: bool,
) -> bool:
    state = _registry_state(_read_locked_registry(handle), before, append)
    config_identity = _path_identity(paths["config"], "configuration")
    if state == "after" and config_identity == document["config_after"]:
        return True
    if state not in {"before", "partial"}:
        raise ProtocolNotFrozenError("rollback found an unknown registry identity; evidence retained")
    if config_published and config_identity != document["config_after"]:
        raise ProtocolNotFrozenError("rollback refuses an unknown configuration; evidence retained")
    if not config_published and config_identity is not None:
        raise ProtocolNotFrozenError("rollback found a concurrent configuration; evidence retained")
    if state == "partial":
        handle.truncate(len(before))
        handle.flush()
        os.fsync(handle.fileno())
    if config_published:
        _unlink_regular(paths["config"], "published configuration")
    _cleanup_registration_transaction(paths["journal"], paths)
    return False


def register_frozen_protocol_atomically(
    repo_root: Path,
    config: Mapping[str, Any],
    config_path: Path,
    registry_path: Path,
    registry_row: Mapping[str, Any],
) -> str:
    """Register the canonical v04 config and exactly one recoverable CSV row."""

    root = Path(repo_root).resolve()
    payload = canonical_v04_config_payload(root, config)
    target_config = Path(config_path).absolute()
    registry = Path(registry_path).absolute()
    if _repo_relative(root, target_config, "configuration") != V04_CONFIG_RELATIVE_PATH:
        raise ProtocolNotFrozenError("configuration path is noncanonical")
    _repo_relative(root, registry, "registry")
    _require_regular(registry, "registry")
    declared_registry = root / str(config["experiment_registry"])
    if declared_registry.resolve() != registry.resolve():
        raise ProtocolNotFrozenError("registry path differs from the configuration")
    row = _validate_registry_row(root, config, target_config, registry_row)
    output = root / row["output_dir"]
    incomplete = output.with_name(output.name + ".incomplete")

    with _exclusive_registry_registration_lock(registry) as handle:
        recovered = _recover_transaction(root, registry, handle, payload, row)
        if recovered is not None and recovered["status"] == "committed":
            return hashlib.sha256(payload).hexdigest()
        before, rows, terminator = _parse_registry_exact(_read_locked_registry(handle))
        _assert_absent(target_config, "configuration")
        if V04_EXPERIMENT_ID in {item["experiment_id"] for item in rows}:
            raise FileExistsError(f"experiment identifier already exists: {V04_EXPERIMENT_ID}")
        if _lexists(output) or _lexists(incomplete):
            raise FileExistsError("final or incomplete experiment output already exists")
        append = _registry_append_bytes(row, terminator)
        transaction_id = uuid.uuid4().hex
        paths = _transaction_paths(target_config, registry, transaction_id)
        for path in paths.values():
            _repo_relative(root, path, "registration artifact")
            _assert_absent(path, "registration artifact")
        document: dict[str, Any] = {
            "schema_version": 1,
            "transaction_id": transaction_id,
            "phase": "declared",
            "experiment_id": V04_EXPERIMENT_ID,
            "config_path": V04_CONFIG_RELATIVE_PATH,
            "registry_path": _repo_relative(root, registry, "registry"),
            "config_stage_path": _repo_relative(root, paths["config_stage"], "config stage"),
            "registry_stage_path": _repo_relative(root, paths["registry_stage"], "registry stage"),
            "config_after": _byte_identity(payload),
            "registry_before": _byte_identity(before),
            "registry_append": {**_byte_identity(append), "csv_record_count": 1},
            "registry_after": _byte_identity(before + append),
        }
        paths["config"] = target_config
        journal_written = False
        config_published = False
        try:
            _create_journal(paths["journal"], document)
            journal_written = True
            _write_durable(paths["config_stage"], payload, exclusive=True)
            _write_durable(paths["registry_stage"], append, exclusive=True)
            _set_journal_phase(paths["journal"], document, "prepared")
            staged_config = _stage_bytes(paths["config_stage"], document["config_after"], "configuration")
            staged_append = _stage_bytes(
                paths["registry_stage"],
                {"size": document["registry_append"]["size"], "sha256": document["registry_append"]["sha256"]},
                "registry",
            )
            _publish_config_payload_exclusive(staged_config, target_config, paths["config_install"])
            config_published = True
            _set_journal_phase(paths["journal"], document, "config_visible")
            _append_registry_suffix(handle, registry, before, staged_append)
            _verify_after(_read_locked_registry(handle), document)
            _set_journal_phase(paths["journal"], document, "committed")
            _cleanup_registration_transaction(paths["journal"], paths)
        except Exception:
            if not journal_written:
                raise
            if _rollback_transaction(
                registry,
                handle,
                document,
                paths,
                before,
                append,
                config_published=config_published,
            ):
                return document["config_after"]["sha256"]
            raise
    return hashlib.sha256(payload).hexdigest()
