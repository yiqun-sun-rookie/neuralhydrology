"""Independent structural verifier for registered same-observation evidence.

This module deliberately does not import the production summarizer.  It checks
raw task arrays, known-axis identities, truth-observation reuse, saved metrics,
and task completeness directly from registered files.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from camels_switch_confirmation.bank import build_bank
from camels_switch_confirmation.g1_precheck import (
    PARAM_KEYS,
    STATE_NAMES,
    WINDOW_START,
    _window_end,
)
from camels_switch_confirmation.g2_switch_confirmation import LAG_CAP
from camels_switch_confirmation.joint_same_observation import (
    BASE_CONFIG,
    CONTINUOUS_CONFIG,
    REPLAY_CONFIG,
    TruthObservationBundle,
    generate_truth_observation_bundle,
    load_registered_configs,
    sha256_file,
)
from camels_switch_confirmation.run_joint_same_observation import (
    ARM_MODES,
    DATA_ROOT,
    G1_CSV,
    REPO_ROOT,
    admitted_basins,
    build_task_table,
    load_truth_bundle,
    task_output_path,
    truth_bundle_path,
)
from camels_switch_confirmation.run_online_noise_pilot import PARAMETER_TABLE


EXPECTED_METRICS = {
    "axis_probability_median_min_exclusive": 0.5,
    "axis_probability_chance": 1.0 / 3.0,
    "axis_above_chance_fraction_min_inclusive": 0.9,
    "noninferiority_margin": -0.1,
    "noninferiority_bootstrap_lower_min_inclusive": -0.1,
    "cell_probability_chance": 1.0 / 9.0,
    "cell_above_chance_fraction_min_inclusive": 0.9,
    "cell_argmax_accuracy_median_min_exclusive": 0.5,
    "probability_sum_absolute_tolerance": 1e-12,
    "state_scale_floor": 1.0,
}


def _assert_array_equal(actual, expected, label) -> None:
    try:
        np.testing.assert_array_equal(actual, expected)
    except AssertionError as exception:
        raise AssertionError(f"{label} changed") from exception


def _verify_probabilities(probabilities, log_probabilities, axis) -> None:
    values = np.asarray(probabilities, dtype=np.float64)
    logs = np.asarray(log_probabilities, dtype=np.float64)
    if values.shape != logs.shape:
        raise AssertionError("probability and log-probability shapes differ")
    if not np.all(np.isfinite(values)) or np.any(values < 0.0):
        raise AssertionError("probabilities must be finite and nonnegative")
    if np.any(np.isnan(logs)) or np.any(np.isposinf(logs)):
        raise AssertionError("log probabilities contain NaN or positive infinity")
    if not np.allclose(values.sum(axis=axis), 1.0, rtol=0.0, atol=1e-12):
        raise AssertionError("probabilities do not sum to one")
    if np.any(np.isneginf(logs) & (values != 0.0)):
        raise AssertionError("negative-infinite log probabilities require zero probability")
    with np.errstate(under="ignore"):
        reconstructed = np.exp(logs)
    if not np.allclose(
        reconstructed, values, rtol=1e-12, atol=np.finfo(np.float64).tiny
    ):
        raise AssertionError("log probabilities disagree with probabilities")


def _verify_candidate_coordinates(
    param_coordinates,
    noise_coordinates,
    knowledge_mode,
) -> None:
    parameters = np.asarray(param_coordinates, dtype=np.int64)
    noises = np.asarray(noise_coordinates, dtype=np.int64)
    if parameters.shape != noises.shape or parameters.ndim < 2:
        raise AssertionError("candidate coordinates changed shape")
    flattened_parameters = parameters.reshape(-1, parameters.shape[-1])
    flattened_noises = noises.reshape(-1, noises.shape[-1])
    for parameter_row, noise_row in zip(
        flattened_parameters, flattened_noises
    ):
        coordinates = list(zip(parameter_row.tolist(), noise_row.tolist()))
        if knowledge_mode == "joint_unknown":
            expected = [(i, j) for i in range(3) for j in range(3)]
        elif knowledge_mode == "param_known":
            expected = [(int(parameter_row[0]), j) for j in range(3)]
        elif knowledge_mode == "noise_known":
            expected = [(i, int(noise_row[0])) for i in range(3)]
        else:
            raise AssertionError(f"unknown knowledge mode: {knowledge_mode}")
        if sorted(coordinates) != sorted(expected):
            raise AssertionError("candidate coordinates are incomplete or duplicated")


def _independent_axis_values(arrays):
    probabilities = np.asarray(arrays["probabilities"], dtype=np.float64)
    log_probabilities = np.asarray(
        arrays["log_probabilities"], dtype=np.float64
    )
    param_coordinates = np.asarray(
        arrays["candidate_param_indices"], dtype=np.int64
    )
    noise_coordinates = np.asarray(
        arrays["candidate_noise_indices"], dtype=np.int64
    )
    param = np.zeros((len(probabilities), 3), dtype=np.float64)
    noise = np.zeros_like(param)
    log_param = np.empty_like(param)
    log_noise = np.empty_like(param)
    for level, coordinates, marginal, log_marginal in (
        *(
            (level, param_coordinates, param, log_param)
            for level in range(3)
        ),
        *(
            (level, noise_coordinates, noise, log_noise)
            for level in range(3)
        ),
    ):
        mask = coordinates == level
        marginal[:, level] = np.sum(
            np.where(mask, probabilities, 0.0), axis=1
        )
        selected = np.where(mask, log_probabilities, -np.inf)
        maxima = np.max(selected, axis=1)
        log_marginal[:, level] = -np.inf
        finite = np.isfinite(maxima)
        if np.any(finite):
            log_marginal[finite, level] = maxima[finite] + np.log(
                np.sum(
                    np.exp(selected[finite] - maxima[finite, None]),
                    axis=1,
                )
            )
    return param, noise, log_param, log_noise


def _independent_true_cell(arrays):
    probabilities = np.asarray(arrays["probabilities"], dtype=np.float64)
    log_probabilities = np.asarray(
        arrays["log_probabilities"], dtype=np.float64
    )
    param_coordinates = np.asarray(
        arrays["candidate_param_indices"], dtype=np.int64
    )
    noise_coordinates = np.asarray(
        arrays["candidate_noise_indices"], dtype=np.int64
    )
    truth_param = np.asarray(arrays["truth_param_indices"], dtype=np.int64)
    truth_noise = np.asarray(arrays["truth_noise_indices"], dtype=np.int64)
    mask = (
        (param_coordinates == truth_param[:, None])
        & (noise_coordinates == truth_noise[:, None])
    )
    if not np.all(mask.sum(axis=1) == 1):
        raise AssertionError("true candidate coordinate is not unique")
    true_probability = np.sum(np.where(mask, probabilities, 0.0), axis=1)
    true_log_probability = np.sum(
        np.where(mask, log_probabilities, 0.0), axis=1
    )
    winners = np.argmax(probabilities, axis=1)
    days = np.arange(len(probabilities))
    winner_param = param_coordinates[days, winners]
    winner_noise = noise_coordinates[days, winners]
    return true_probability, true_log_probability, winner_param, winner_noise


def _independent_classification(
    winner_param,
    winner_noise,
    truth_param,
    truth_noise,
    days,
) -> dict:
    selected = np.asarray(days, dtype=np.int64)
    parameter_wrong = np.asarray(winner_param)[selected] != np.asarray(
        truth_param
    )[selected]
    noise_wrong = np.asarray(winner_noise)[selected] != np.asarray(truth_noise)[
        selected
    ]
    return {
        "correct_fraction": float(np.mean(~parameter_wrong & ~noise_wrong)),
        "param_only_wrong_fraction": float(
            np.mean(parameter_wrong & ~noise_wrong)
        ),
        "noise_only_wrong_fraction": float(
            np.mean(~parameter_wrong & noise_wrong)
        ),
        "both_wrong_fraction": float(np.mean(parameter_wrong & noise_wrong)),
    }


def _independent_state_metrics(estimated, truth):
    error = np.asarray(estimated, dtype=np.float64) - np.asarray(
        truth, dtype=np.float64
    )
    rmse = np.sqrt(np.mean(error**2, axis=0))
    median_absolute_error = np.median(np.abs(error), axis=0)
    scales = np.maximum(np.std(np.asarray(truth), axis=0), 1.0)
    normalized = rmse / scales
    return rmse, median_absolute_error, scales, normalized


def independent_continuous_metric_rows(
    arrays,
    basin_id,
    seed,
    arm_id,
    knowledge_mode,
    scoring_start_day,
):
    """Recompute continuous metric rows without importing the summarizer."""

    probabilities = np.asarray(arrays["probabilities"], dtype=np.float64)
    scoring = np.arange(int(scoring_start_day), len(probabilities))
    if len(scoring) == 0:
        raise AssertionError("continuous scoring window is empty")
    truth_param = np.asarray(arrays["truth_param_indices"], dtype=np.int64)
    truth_noise = np.asarray(arrays["truth_noise_indices"], dtype=np.int64)
    param, noise, log_param, log_noise = _independent_axis_values(arrays)
    cell, log_cell, winner_param, winner_noise = _independent_true_cell(arrays)
    identity = {
        "basin_id": str(basin_id),
        "seed": int(seed),
        "arm_id": str(arm_id),
        "knowledge_mode": str(knowledge_mode),
    }
    rmse, median_error, scales, normalized = _independent_state_metrics(
        np.asarray(arrays["combined_states"])[scoring],
        np.asarray(arrays["truth_post_states"])[scoring],
    )
    task_row = {
        **identity,
        "cell_mean_true_probability": float(np.mean(cell[scoring])),
        "cell_mean_true_log_probability": float(np.mean(log_cell[scoring])),
        "cell_argmax_accuracy": float(
            np.mean(
                (winner_param[scoring] == truth_param[scoring])
                & (winner_noise[scoring] == truth_noise[scoring])
            )
        ),
        **_independent_classification(
            winner_param,
            winner_noise,
            truth_param,
            truth_noise,
            scoring,
        ),
        "state_mean_normalized_rmse": float(np.mean(normalized)),
    }
    axis_rows = []
    for axis, truth, marginal, log_marginal in (
        ("param", truth_param, param, log_param),
        ("noise", truth_noise, noise, log_noise),
    ):
        for level in range(3):
            days = scoring[truth[scoring] == level]
            axis_rows.append({
                **identity,
                "axis": axis,
                "level": level,
                "n_days": int(len(days)),
                "mean_true_probability": (
                    float(np.mean(marginal[days, level]))
                    if len(days)
                    else float("nan")
                ),
                "mean_true_log_probability": (
                    float(np.mean(log_marginal[days, level]))
                    if len(days)
                    else float("nan")
                ),
                "argmax_accuracy": (
                    float(np.mean(np.argmax(marginal[days], axis=1) == level))
                    if len(days)
                    else float("nan")
                ),
            })
    state_rows = [{
        **identity,
        "state_index": index,
        "rmse": float(rmse[index]),
        "median_absolute_error": float(median_error[index]),
        "normalization_scale": float(scales[index]),
        "normalized_rmse": float(normalized[index]),
    } for index in range(len(rmse))]
    return task_row, axis_rows, state_rows


def verify_metric_frame(
    observed: pd.DataFrame,
    expected: pd.DataFrame,
    sort_columns,
    label,
) -> None:
    """Require saved metric values to equal an independent recomputation."""

    actual = observed.copy()
    target = expected.copy()
    if set(actual.columns) != set(target.columns):
        raise AssertionError(f"{label} columns changed")
    for frame in (actual, target):
        if "basin_id" in frame:
            frame["basin_id"] = frame["basin_id"].astype(str).str.zfill(8)
    actual = actual[target.columns].sort_values(list(sort_columns)).reset_index(
        drop=True
    )
    target = target.sort_values(list(sort_columns)).reset_index(drop=True)
    try:
        pd.testing.assert_frame_equal(
            actual,
            target,
            check_dtype=False,
            check_exact=False,
            rtol=1e-12,
            atol=1e-12,
        )
    except AssertionError as exception:
        raise AssertionError(f"{label} numeric values changed") from exception


def verify_continuous_task_arrays(
    arrays,
    bundle: TruthObservationBundle,
    knowledge_mode: str,
) -> None:
    """Verify one continuous task without trusting the runner's summary."""

    probabilities = np.asarray(arrays["probabilities"])
    _verify_probabilities(probabilities, arrays["log_probabilities"], axis=1)
    n_days, candidate_count = probabilities.shape
    expected_candidates = 9 if knowledge_mode == "joint_unknown" else 3
    if candidate_count != expected_candidates:
        raise AssertionError("continuous candidate count changed")
    if n_days != len(bundle.observations):
        raise AssertionError("continuous day count changed")
    _assert_array_equal(arrays["observations"], bundle.observations, "observations")
    _assert_array_equal(
        arrays["truth_post_states"], bundle.post_states, "truth post states"
    )
    _assert_array_equal(
        arrays["truth_param_indices"], bundle.truth_param_indices, "truth parameter"
    )
    _assert_array_equal(
        arrays["truth_noise_indices"], bundle.truth_noise_indices, "truth process noise"
    )
    param_coordinates = np.asarray(arrays["candidate_param_indices"])
    noise_coordinates = np.asarray(arrays["candidate_noise_indices"])
    if param_coordinates.shape != probabilities.shape:
        raise AssertionError("candidate parameter coordinates changed shape")
    if noise_coordinates.shape != probabilities.shape:
        raise AssertionError("candidate process-noise coordinates changed shape")
    if knowledge_mode == "param_known" and not np.array_equal(
        param_coordinates,
        np.broadcast_to(bundle.truth_param_indices[:, None], param_coordinates.shape),
    ):
        raise AssertionError("known parameter does not equal truth")
    if knowledge_mode == "noise_known" and not np.array_equal(
        noise_coordinates,
        np.broadcast_to(bundle.truth_noise_indices[:, None], noise_coordinates.shape),
    ):
        raise AssertionError("known process noise does not equal truth")
    _verify_candidate_coordinates(
        param_coordinates, noise_coordinates, knowledge_mode
    )
    if not np.all(np.isfinite(arrays["combined_states"])):
        raise AssertionError("combined states contain non-finite values")
    if not np.all(np.isfinite(arrays["combined_covariance_diagonals"])):
        raise AssertionError("combined covariance diagonals contain non-finite values")
    if np.any(np.asarray(arrays["combined_covariance_diagonals"]) < -1e-12):
        raise AssertionError("combined covariance diagonals contain negative values")


def verify_replay_task_arrays(
    arrays,
    bundle: TruthObservationBundle,
    knowledge_mode: str,
) -> None:
    """Verify reset timing, observations, known axes, and probabilities."""

    probabilities = np.asarray(arrays["probabilities"])
    _verify_probabilities(probabilities, arrays["log_probabilities"], axis=2)
    event_count, replay_days, candidate_count = probabilities.shape
    expected_candidates = 9 if knowledge_mode == "joint_unknown" else 3
    if candidate_count != expected_candidates:
        raise AssertionError("replay candidate count changed")
    switch_days = np.asarray(arrays["switch_days"], dtype=np.int64)
    if len(switch_days) != event_count:
        raise AssertionError("replay switch-day count changed")
    param_coordinates = np.asarray(arrays["candidate_param_indices"])
    noise_coordinates = np.asarray(arrays["candidate_noise_indices"])
    for event_index, switch_day in enumerate(switch_days):
        expected_initial = bundle.pre_states[int(switch_day)]
        if not np.array_equal(
            np.asarray(arrays["initial_truth_states"])[event_index],
            expected_initial,
        ):
            raise AssertionError("replay initial truth state changed")
        expected_observations = bundle.observations[
            int(switch_day):int(switch_day) + replay_days
        ]
        if not np.array_equal(
            np.asarray(arrays["observations"])[event_index],
            expected_observations,
        ):
            raise AssertionError("replay observations changed")
        expected_states = bundle.post_states[
            int(switch_day):int(switch_day) + replay_days
        ]
        if not np.array_equal(
            np.asarray(arrays["truth_post_states"])[event_index],
            expected_states,
        ):
            raise AssertionError("replay truth states changed")
        destination = np.asarray(arrays["destination_cells"])[event_index]
        if knowledge_mode == "param_known" and not np.all(
            param_coordinates[event_index] == int(destination[0])
        ):
            raise AssertionError("replay known parameter does not equal truth")
        if knowledge_mode == "noise_known" and not np.all(
            noise_coordinates[event_index] == int(destination[1])
        ):
            raise AssertionError("replay known process noise does not equal truth")
    _verify_candidate_coordinates(
        param_coordinates, noise_coordinates, knowledge_mode
    )
    if not np.all(np.isfinite(arrays["combined_states"])):
        raise AssertionError("replay combined states contain non-finite values")
    if not np.all(np.isfinite(arrays["combined_covariance_diagonals"])):
        raise AssertionError("replay covariance diagonals contain non-finite values")
    if np.any(np.asarray(arrays["combined_covariance_diagonals"]) < -1e-12):
        raise AssertionError("replay covariance diagonals contain negative values")


def _independent_transition_kind(source, destination):
    parameter_moved = int(source[0]) != int(destination[0])
    noise_moved = int(source[1]) != int(destination[1])
    if parameter_moved and noise_moved:
        return "both"
    if parameter_moved:
        return "param_only"
    if noise_moved:
        return "noise_only"
    raise AssertionError("replay event does not switch either axis")


def independent_replay_metric_rows(
    arrays,
    basin_id,
    seed,
    arm_id,
    knowledge_mode,
    report_windows,
):
    """Recompute every reset-event metric row from raw arrays."""

    rows = []
    probabilities = np.asarray(arrays["probabilities"])
    for event_index in range(probabilities.shape[0]):
        destination = np.asarray(arrays["destination_cells"])[event_index]
        source = np.asarray(arrays["source_cells"])[event_index]
        replay_days = probabilities.shape[1]
        event = {
            "probabilities": probabilities[event_index],
            "log_probabilities": np.asarray(
                arrays["log_probabilities"]
            )[event_index],
            "candidate_param_indices": np.asarray(
                arrays["candidate_param_indices"]
            )[event_index],
            "candidate_noise_indices": np.asarray(
                arrays["candidate_noise_indices"]
            )[event_index],
            "truth_param_indices": np.full(
                replay_days, int(destination[0]), dtype=np.int64
            ),
            "truth_noise_indices": np.full(
                replay_days, int(destination[1]), dtype=np.int64
            ),
        }
        param, noise, log_param, log_noise = _independent_axis_values(event)
        cell, log_cell, winner_param, winner_noise = _independent_true_cell(
            event
        )
        for window in report_windows:
            width = int(window)
            days = np.arange(width)
            rmse, _median_error, scales, _normalized = (
                _independent_state_metrics(
                    np.asarray(arrays["combined_states"])[event_index, days],
                    np.asarray(arrays["truth_post_states"])[event_index, days],
                )
            )
            rows.append({
                "basin_id": str(basin_id),
                "seed": int(seed),
                "arm_id": str(arm_id),
                "knowledge_mode": str(knowledge_mode),
                "event_index": event_index,
                "switch_day": int(
                    np.asarray(arrays["switch_days"])[event_index]
                ),
                "transition_kind": _independent_transition_kind(
                    source, destination
                ),
                "source_param": int(source[0]),
                "source_noise": int(source[1]),
                "destination_param": int(destination[0]),
                "destination_noise": int(destination[1]),
                "window_days": width,
                "param_mean_true_probability": float(
                    np.mean(param[days, int(destination[0])])
                ),
                "param_mean_true_log_probability": float(
                    np.mean(log_param[days, int(destination[0])])
                ),
                "noise_mean_true_probability": float(
                    np.mean(noise[days, int(destination[1])])
                ),
                "noise_mean_true_log_probability": float(
                    np.mean(log_noise[days, int(destination[1])])
                ),
                "cell_mean_true_probability": float(np.mean(cell[days])),
                "cell_mean_true_log_probability": float(
                    np.mean(log_cell[days])
                ),
                "param_argmax_accuracy": float(
                    np.mean(
                        np.argmax(param[days], axis=1)
                        == int(destination[0])
                    )
                ),
                "noise_argmax_accuracy": float(
                    np.mean(
                        np.argmax(noise[days], axis=1)
                        == int(destination[1])
                    )
                ),
                "cell_argmax_accuracy": float(
                    np.mean(
                        (winner_param[days] == int(destination[0]))
                        & (winner_noise[days] == int(destination[1]))
                    )
                ),
                **_independent_classification(
                    winner_param,
                    winner_noise,
                    event["truth_param_indices"],
                    event["truth_noise_indices"],
                    days,
                ),
                "state_mean_normalized_rmse": float(np.mean(rmse / scales)),
            })
    return rows


def independent_propagation_rows(
    continuous,
    replay,
    basin_id,
    seed,
    arm_id,
    knowledge_mode,
    report_windows,
):
    """Recompute continuous-minus-reset error propagation effects."""

    continuous_param, continuous_noise, _, _ = _independent_axis_values(
        continuous
    )
    continuous_cell, _, _, _ = _independent_true_cell(continuous)
    rows = []
    for event_index, switch_day in enumerate(
        np.asarray(replay["switch_days"])
    ):
        destination = np.asarray(replay["destination_cells"])[event_index]
        replay_days_total = np.asarray(replay["probabilities"]).shape[1]
        event = {
            "probabilities": np.asarray(replay["probabilities"])[event_index],
            "log_probabilities": np.asarray(
                replay["log_probabilities"]
            )[event_index],
            "candidate_param_indices": np.asarray(
                replay["candidate_param_indices"]
            )[event_index],
            "candidate_noise_indices": np.asarray(
                replay["candidate_noise_indices"]
            )[event_index],
            "truth_param_indices": np.full(
                replay_days_total, int(destination[0]), dtype=np.int64
            ),
            "truth_noise_indices": np.full(
                replay_days_total, int(destination[1]), dtype=np.int64
            ),
        }
        replay_param, replay_noise, _, _ = _independent_axis_values(event)
        replay_cell, _, _, _ = _independent_true_cell(event)
        for window in report_windows:
            width = int(window)
            continuous_days = np.arange(int(switch_day), int(switch_day) + width)
            replay_days = np.arange(width)
            continuous_state = _independent_state_metrics(
                np.asarray(continuous["combined_states"])[continuous_days],
                np.asarray(continuous["truth_post_states"])[continuous_days],
            )
            replay_state = _independent_state_metrics(
                np.asarray(replay["combined_states"])[event_index, replay_days],
                np.asarray(replay["truth_post_states"])[event_index, replay_days],
            )
            rows.append({
                "basin_id": str(basin_id),
                "seed": int(seed),
                "arm_id": str(arm_id),
                "knowledge_mode": str(knowledge_mode),
                "event_index": event_index,
                "switch_day": int(switch_day),
                "window_days": width,
                "param_error_propagation": float(
                    np.mean(replay_param[replay_days, int(destination[0])])
                    - np.mean(
                        continuous_param[
                            continuous_days, int(destination[0])
                        ]
                    )
                ),
                "noise_error_propagation": float(
                    np.mean(replay_noise[replay_days, int(destination[1])])
                    - np.mean(
                        continuous_noise[
                            continuous_days, int(destination[1])
                        ]
                    )
                ),
                "cell_error_propagation": float(
                    np.mean(replay_cell[replay_days])
                    - np.mean(continuous_cell[continuous_days])
                ),
                "state_error_propagation": float(
                    np.mean(continuous_state[0] / continuous_state[2])
                    - np.mean(replay_state[0] / replay_state[2])
                ),
            })
    return rows


def _independent_paired_axis(axis_frame):
    keys = ["basin_id", "seed", "arm_id", "axis", "level"]
    joint = axis_frame[axis_frame["knowledge_mode"] == "joint_unknown"][
        keys + ["mean_true_probability"]
    ].rename(columns={"mean_true_probability": "joint_probability"})
    references = []
    for axis, mode in (("param", "noise_known"), ("noise", "param_known")):
        references.append(
            axis_frame[
                (axis_frame["axis"] == axis)
                & (axis_frame["knowledge_mode"] == mode)
            ][keys + ["mean_true_probability"]].rename(
                columns={"mean_true_probability": "reference_probability"}
            )
        )
    paired = joint.merge(
        pd.concat(references, ignore_index=True),
        on=keys,
        how="inner",
        validate="one_to_one",
    )
    paired["paired_difference"] = (
        paired["joint_probability"] - paired["reference_probability"]
    )
    return paired


def _independent_paired_states(task_frame, state_frame):
    task_keys = ["basin_id", "seed", "arm_id"]
    state_keys = task_keys + ["state_index"]
    results = []
    for frame, keys, metric in (
        (task_frame, task_keys, "state_mean_normalized_rmse"),
        (state_frame, state_keys, "normalized_rmse"),
    ):
        joint = frame[frame["knowledge_mode"] == "joint_unknown"][
            keys + [metric]
        ].rename(columns={metric: "joint_normalized_rmse"})
        pairs = []
        for mode in ("param_known", "noise_known"):
            reference = frame[frame["knowledge_mode"] == mode][
                keys + [metric]
            ].rename(columns={metric: "reference_normalized_rmse"})
            paired = joint.merge(
                reference, on=keys, how="inner", validate="one_to_one"
            )
            paired["reference_knowledge_mode"] = mode
            paired["joint_minus_reference"] = (
                paired["joint_normalized_rmse"]
                - paired["reference_normalized_rmse"]
            )
            pairs.append(paired)
        results.append(pd.concat(pairs, ignore_index=True))
    return tuple(results)


def _independent_bootstrap_interval(values, seed, replicates):
    sample = np.asarray(values, dtype=np.float64)
    sample = sample[np.isfinite(sample)]
    if len(sample) == 0:
        raise AssertionError("bootstrap sample is empty")
    rng = np.random.default_rng(int(seed))
    medians = np.empty(int(replicates), dtype=np.float64)
    for start in range(0, int(replicates), 2000):
        stop = min(start + 2000, int(replicates))
        indices = rng.integers(
            0, len(sample), size=(stop - start, len(sample))
        )
        medians[start:stop] = np.median(sample[indices], axis=1)
    return tuple(float(value) for value in np.quantile(medians, [0.025, 0.975]))


def _independent_grouped_summary(
    frame,
    group_columns,
    metric_columns,
    seed,
    replicates,
):
    rows = []
    offset = 0
    for identity, selected in frame.groupby(
        list(group_columns), sort=True, dropna=False
    ):
        values_tuple = identity if isinstance(identity, tuple) else (identity,)
        common = dict(zip(group_columns, values_tuple))
        for metric in metric_columns:
            values = selected[metric].to_numpy(dtype=np.float64)
            finite = values[np.isfinite(values)]
            lower, upper = _independent_bootstrap_interval(
                values, int(seed) + offset, replicates
            )
            rows.append({
                **common,
                "metric": metric,
                "n_pairs": int(len(finite)),
                "median": float(np.median(finite)),
                "bootstrap_95_lower": lower,
                "bootstrap_95_upper": upper,
            })
            offset += 1
    return pd.DataFrame(rows)


def _independent_decisions(axis_frame, paired, task_frame, seed, replicates):
    decisions = {}
    for arm in ("C", "P"):
        axes = {"param": {}, "noise": {}}
        for axis in axes:
            reference_mode = "noise_known" if axis == "param" else "param_known"
            for level in range(3):
                joint = axis_frame[
                    (axis_frame["arm_id"] == arm)
                    & (axis_frame["axis"] == axis)
                    & (axis_frame["level"] == level)
                    & (axis_frame["knowledge_mode"] == "joint_unknown")
                ]["mean_true_probability"].dropna().to_numpy()
                reference = axis_frame[
                    (axis_frame["arm_id"] == arm)
                    & (axis_frame["axis"] == axis)
                    & (axis_frame["level"] == level)
                    & (axis_frame["knowledge_mode"] == reference_mode)
                ]["mean_true_probability"].dropna().to_numpy()
                differences = paired[
                    (paired["arm_id"] == arm)
                    & (paired["axis"] == axis)
                    & (paired["level"] == level)
                ]["paired_difference"].dropna().to_numpy()
                lower, upper = _independent_bootstrap_interval(
                    differences,
                    int(seed) + (0 if axis == "param" else 100) + level,
                    replicates,
                )
                joint_pass = (
                    float(np.median(joint)) > 0.5
                    and float(np.mean(joint > 1.0 / 3.0)) >= 0.9
                )
                reference_pass = (
                    float(np.median(reference)) > 0.5
                    and float(np.mean(reference > 1.0 / 3.0)) >= 0.9
                )
                noninferior = (
                    float(np.median(differences)) >= -0.1 and lower >= -0.1
                )
                axes[axis][str(level)] = {
                    "joint_median": float(np.median(joint)),
                    "joint_above_chance_fraction": float(
                        np.mean(joint > 1.0 / 3.0)
                    ),
                    "reference_median": float(np.median(reference)),
                    "reference_above_chance_fraction": float(
                        np.mean(reference > 1.0 / 3.0)
                    ),
                    "paired_difference_median": float(
                        np.median(differences)
                    ),
                    "paired_difference_bootstrap_95": [lower, upper],
                    "joint_absolute_pass": bool(joint_pass),
                    "reference_absolute_pass": bool(reference_pass),
                    "noninferiority_pass": bool(noninferior),
                    "level_pass": bool(
                        joint_pass and reference_pass and noninferior
                    ),
                }
        parameter_pass = all(
            row["level_pass"] for row in axes["param"].values()
        )
        noise_pass = all(
            row["level_pass"] for row in axes["noise"].values()
        )
        cells = task_frame[
            (task_frame["arm_id"] == arm)
            & (task_frame["knowledge_mode"] == "joint_unknown")
        ]
        probabilities = cells["cell_mean_true_probability"].to_numpy()
        accuracies = cells["cell_argmax_accuracy"].to_numpy()
        cell_pass = (
            float(np.median(probabilities)) > 1.0 / 9.0
            and float(np.mean(probabilities > 1.0 / 9.0)) >= 0.9
            and float(np.median(accuracies)) > 0.5
        )
        decisions[arm] = {
            "axes": axes,
            "parameter_axis_pass": bool(parameter_pass),
            "process_noise_axis_pass": bool(noise_pass),
            "whole_cell": {
                "median_true_probability": float(np.median(probabilities)),
                "above_chance_fraction": float(
                    np.mean(probabilities > 1.0 / 9.0)
                ),
                "median_argmax_accuracy": float(np.median(accuracies)),
                "pass": bool(cell_pass),
            },
            "whole_cell_pass": bool(cell_pass),
            "simultaneous_identification": bool(
                parameter_pass and noise_pass and cell_pass
            ),
        }
    return decisions


def _load_npz(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {name: archive[name].copy() for name in archive.files}


def _load_manifest(root: Path, expected_tasks: int) -> dict:
    path = root / "verification" / "run_manifest.json"
    with path.open(encoding="utf-8") as handle:
        manifest = json.load(handle)
    if (
        manifest.get("n_tasks") != expected_tasks
        or manifest.get("n_success") != expected_tasks
        or manifest.get("n_failed") != 0
    ):
        raise AssertionError("formal manifest is incomplete")
    records_path = root / "verification" / "task_records.json"
    failures_path = root / "verification" / "run_failures.json"
    with records_path.open(encoding="utf-8") as handle:
        records = json.load(handle)
    with failures_path.open(encoding="utf-8") as handle:
        failures = json.load(handle)
    identities = [record.get("task_id") for record in records]
    if (
        len(records) != expected_tasks
        or len(set(identities)) != expected_tasks
        or any(record.get("run_status") != "success" for record in records)
        or failures != []
    ):
        raise AssertionError("formal task records are incomplete or duplicated")
    return {**manifest, "task_records": records}


def _load_basin_case_independent(basin_id: str, window_days: int):
    """Rebuild registered inputs without calling the production runner loader."""

    from hydroagent.data_loading import load_camels_basin
    from scl_hydro.hbv_lite_numpy import resolve_hbv_bounds

    parameters = pd.read_csv(PARAMETER_TABLE, dtype={"basin_id": str})
    parameters["basin_id"] = parameters["basin_id"].str.zfill(8)
    selected = parameters[parameters["basin_id"] == str(basin_id).zfill(8)]
    if len(selected) != 1:
        raise AssertionError("independent parameter lookup is not unique")
    row = selected.iloc[0]
    center = {key: float(row[f"p_{key}"]) for key in PARAM_KEYS}
    center["lag_time"] = min(center["lag_time"], LAG_CAP)
    initial_hydrology = np.asarray(
        [float(row[f"state_{name}"]) for name in STATE_NAMES],
        dtype=np.float64,
    )
    bounds = resolve_hbv_bounds("v5")
    members, clipped = build_bank(center, bounds["parFC"])
    if any(clipped):
        raise AssertionError("independent candidate bank contains clipping")
    noise = pd.read_csv(G1_CSV, dtype={"basin_id": str})
    noise["basin_id"] = noise["basin_id"].str.zfill(8)
    noise_selected = noise[noise["basin_id"] == str(basin_id).zfill(8)]
    if len(noise_selected) != 1:
        raise AssertionError("independent observation-noise lookup is not unique")
    sigma_obs = float(noise_selected.iloc[0]["sigma_obs"])
    forcing, _observed, _area = load_camels_basin(
        str(basin_id).zfill(8),
        data_root=DATA_ROOT,
        start_date=WINDOW_START,
        end_date=_window_end(),
        forcing="maurer",
        pet_method="oudin",
        keep_obs_nan_days=True,
    )
    rain = forcing["prcp"].to_numpy(dtype=np.float64)[:int(window_days)]
    pet_column = "ep" if "ep" in forcing.columns else "pet"
    pet = forcing[pet_column].to_numpy(dtype=np.float64)[:int(window_days)]
    temperature = (
        forcing["tmean"].to_numpy(dtype=np.float64)
        if "tmean" in forcing.columns
        else np.zeros_like(rain)
    )[:int(window_days)]
    return {
        "members": members,
        "initial_hydrology": initial_hydrology,
        "bounds": bounds,
        "sigma_obs": sigma_obs,
        "rain": rain,
        "pet": pet,
        "temperature": temperature,
    }


def _verify_truth_replay(
    basin_id,
    seed,
    bundle_path,
    configs,
) -> None:
    bundle = load_truth_bundle(bundle_path)
    case = _load_basin_case_independent(
        basin_id, int(configs.base["window_days"])
    )
    base = configs.base
    truth_rng = np.random.default_rng(
        np.random.SeedSequence((
            int(base["seed_entropy"]), int(basin_id), int(seed),
            int(base["truth_stream_tag"]),
        ))
    )
    observation_rng = np.random.default_rng(
        np.random.SeedSequence((
            int(base["seed_entropy"]), int(basin_id), int(seed),
            int(base["observation_stream_tag"]),
        ))
    )
    replayed = generate_truth_observation_bundle(
        sequence=tuple(tuple(value) for value in base["sequence"]),
        members=case["members"],
        rain=case["rain"],
        pet=case["pet"],
        temperature=case["temperature"],
        init_hydro=case["initial_hydrology"],
        truth_rng=truth_rng,
        observation_rng=observation_rng,
        observation_sigma=case["sigma_obs"],
        bounds=case["bounds"],
        stage_days=int(base["stage_days"]),
    )
    for field in (
        "rain", "pet", "temperature", "pre_states", "post_states", "truth_q",
        "observations", "observation_errors", "truth_param_indices",
        "truth_noise_indices", "truth_cell_indices", "truth_parfc", "sequence",
    ):
        _assert_array_equal(getattr(bundle, field), getattr(replayed, field), f"truth {field}")
    if bundle.clip_count != replayed.clip_count or bundle.clip_count != 0:
        raise AssertionError("truth clip count changed or is nonzero")
    expected_arrays = {
        "candidate_parameter_keys": np.asarray(PARAM_KEYS),
        "candidate_parameter_values": np.asarray([
            [float(member[key]) for key in PARAM_KEYS]
            for member in case["members"]
        ]),
        "candidate_process_noise_multipliers": np.asarray(
            base["process_noise_multipliers"], dtype=np.float64
        ),
        "observation_sigma": np.array(case["sigma_obs"], dtype=np.float64),
        "switch_days": np.arange(
            1, len(base["sequence"]), dtype=np.int64
        ) * int(base["stage_days"]),
        "stage_indices": np.repeat(
            np.arange(len(base["sequence"]), dtype=np.int64),
            int(base["stage_days"]),
        )[:len(bundle.observations)],
        "truth_rng_identity": np.asarray([
            int(base["seed_entropy"]), int(basin_id), int(seed),
            int(base["truth_stream_tag"]),
        ], dtype=np.int64),
        "observation_rng_identity": np.asarray([
            int(base["seed_entropy"]), int(basin_id), int(seed),
            int(base["observation_stream_tag"]),
        ], dtype=np.int64),
        "registered_inputs_json": np.array(json.dumps(
            base["registered_inputs"],
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )),
        "registered_implementation_json": np.array(json.dumps(
            base["registered_implementation"],
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )),
        "base_config_sha256": np.array(sha256_file(REPO_ROOT / BASE_CONFIG)),
        "continuous_config_sha256": np.array(
            sha256_file(REPO_ROOT / CONTINUOUS_CONFIG)
        ),
        "replay_config_sha256": np.array(
            sha256_file(REPO_ROOT / REPLAY_CONFIG)
        ),
        "preregistration_sha256": np.array(
            base["registered_inputs"]["preregistration"]["sha256"]
        ),
        "basin_id": np.array(str(basin_id)),
        "seed": np.array(int(seed), dtype=np.int64),
    }
    with np.load(bundle_path, allow_pickle=False) as archive:
        for field, expected in expected_arrays.items():
            if field not in archive.files:
                raise AssertionError(f"truth metadata is missing: {field}")
            _assert_array_equal(archive[field], expected, f"truth metadata {field}")


def _write_json_new(path: Path, payload) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")


def verify_formal_evidence(repo_root=REPO_ROOT, route="local") -> dict:
    """Verify all registered task arrays and truth replays."""

    root = Path(repo_root).resolve()
    configs = load_registered_configs(root)
    if set(configs.continuous.get("metrics", {})) != set(EXPECTED_METRICS):
        raise AssertionError("registered metric threshold keys changed")
    for name, expected in EXPECTED_METRICS.items():
        if float(configs.continuous["metrics"][name]) != float(expected):
            raise AssertionError(f"registered metric threshold changed: {name}")
    if route not in {"local", "hpc"}:
        raise AssertionError(f"unknown evidence route: {route}")
    continuous_root = root / configs.continuous[f"output_root_{route}"]
    replay_root = root / configs.replay[f"output_root_{route}"]
    truth_root = root / configs.base["truth_output_root"]
    tasks = build_task_table(admitted_basins(), configs.base["formal_seeds"])
    if int(configs.continuous["task_count"]) != len(tasks):
        raise AssertionError("registered continuous task count changed")
    if int(configs.replay["task_count"]) != len(tasks):
        raise AssertionError("registered replay task count changed")
    truth_manifest = _load_manifest(
        truth_root,
        len(admitted_basins()) * len(configs.base["formal_seeds"]),
    )
    continuous_manifest = _load_manifest(continuous_root, len(tasks))
    replay_manifest = _load_manifest(replay_root, len(tasks))
    commits = {
        truth_manifest.get("git_commit"),
        continuous_manifest.get("git_commit"),
        replay_manifest.get("git_commit"),
    }
    if len(commits) != 1 or None in commits:
        raise AssertionError("formal evidence was not produced from one git commit")
    truth_records = {
        record["task_id"]: record
        for record in truth_manifest["task_records"]
    }
    continuous_records = {
        record["task_id"]: record
        for record in continuous_manifest["task_records"]
    }
    replay_records = {
        record["task_id"]: record
        for record in replay_manifest["task_records"]
    }
    truth_hashes = {}
    for basin_id in admitted_basins():
        for seed in configs.base["formal_seeds"]:
            path = truth_bundle_path(truth_root, basin_id, seed)
            _verify_truth_replay(basin_id, seed, path, configs)
            observed_hash = sha256_file(path)
            task_id = f"{basin_id}_s{int(seed)}"
            if truth_records[task_id].get("truth_sha256") != observed_hash:
                raise AssertionError("truth package hash differs from task record")
            truth_hashes[(basin_id, int(seed))] = observed_hash
    continuous_files = 0
    replay_files = 0
    task_rows = []
    axis_rows = []
    state_rows = []
    event_rows = []
    propagation = []
    for task in tasks:
        bundle_path = truth_bundle_path(truth_root, task.basin_id, task.seed)
        bundle = load_truth_bundle(bundle_path)
        expected_truth_hash = truth_hashes[(task.basin_id, task.seed)]
        continuous_path = task_output_path(continuous_root, task)
        replay_path = task_output_path(replay_root, task)
        if continuous_records[task.task_id].get("output_sha256") != sha256_file(
            continuous_path
        ):
            raise AssertionError("continuous output hash differs from task record")
        if replay_records[task.task_id].get("output_sha256") != sha256_file(
            replay_path
        ):
            raise AssertionError("replay output hash differs from task record")
        continuous = _load_npz(continuous_path)
        replay = _load_npz(replay_path)
        expected_task_metadata = {
            "basin_id": task.basin_id,
            "seed": task.seed,
            "arm_id": task.arm_id,
            "interaction_mode": ARM_MODES[task.arm_id],
            "knowledge_mode": task.knowledge_mode,
            "preregistration_sha256": configs.base["registered_inputs"][
                "preregistration"
            ]["sha256"],
        }
        for label, arrays in (("continuous", continuous), ("replay", replay)):
            for field, expected in expected_task_metadata.items():
                if field not in arrays:
                    raise AssertionError(f"{label} task metadata is missing: {field}")
                observed = np.asarray(arrays[field]).item()
                if observed != expected:
                    raise AssertionError(f"{label} task metadata changed: {field}")
            elapsed = float(np.asarray(arrays["compute_elapsed_seconds"]).item())
            if not np.isfinite(elapsed) or elapsed < 0.0:
                raise AssertionError(f"{label} task elapsed time is invalid")
        if str(np.asarray(continuous["truth_bundle_sha256"]).item()) != expected_truth_hash:
            raise AssertionError("continuous task truth hash changed")
        if str(np.asarray(replay["truth_bundle_sha256"]).item()) != expected_truth_hash:
            raise AssertionError("replay task truth hash changed")
        verify_continuous_task_arrays(continuous, bundle, task.knowledge_mode)
        verify_replay_task_arrays(replay, bundle, task.knowledge_mode)
        task_row, task_axis_rows, task_state_rows = (
            independent_continuous_metric_rows(
                continuous,
                task.basin_id,
                task.seed,
                task.arm_id,
                task.knowledge_mode,
                int(configs.base["stage_days"]),
            )
        )
        task_rows.append(task_row)
        axis_rows.extend(task_axis_rows)
        state_rows.extend(task_state_rows)
        event_rows.extend(
            independent_replay_metric_rows(
                replay,
                task.basin_id,
                task.seed,
                task.arm_id,
                task.knowledge_mode,
                configs.replay["report_windows_days"],
            )
        )
        propagation.extend(
            independent_propagation_rows(
                continuous,
                replay,
                task.basin_id,
                task.seed,
                task.arm_id,
                task.knowledge_mode,
                configs.replay["report_windows_days"],
            )
        )
        continuous_files += 1
        replay_files += 1
    task_frame = pd.DataFrame(task_rows)
    axis_frame = pd.DataFrame(axis_rows)
    state_frame = pd.DataFrame(state_rows)
    event_frame = pd.DataFrame(event_rows)
    propagation_frame = pd.DataFrame(propagation)
    paired_axis = _independent_paired_axis(axis_frame)
    paired_state_tasks, paired_states = _independent_paired_states(
        task_frame, state_frame
    )
    bootstrap_seed = int(configs.base["bootstrap_seed"])
    bootstrap_replicates = int(configs.base["bootstrap_replicates"])
    event_summary = _independent_grouped_summary(
        event_frame,
        [
            "arm_id",
            "knowledge_mode",
            "event_index",
            "switch_day",
            "transition_kind",
            "window_days",
        ],
        [
            "param_mean_true_probability",
            "noise_mean_true_probability",
            "cell_mean_true_probability",
            "param_argmax_accuracy",
            "noise_argmax_accuracy",
            "cell_argmax_accuracy",
            "state_mean_normalized_rmse",
        ],
        bootstrap_seed + 1000,
        bootstrap_replicates,
    )
    propagation_summary = _independent_grouped_summary(
        propagation_frame,
        [
            "arm_id",
            "knowledge_mode",
            "event_index",
            "switch_day",
            "window_days",
        ],
        [
            "param_error_propagation",
            "noise_error_propagation",
            "cell_error_propagation",
            "state_error_propagation",
        ],
        bootstrap_seed + 2000,
        bootstrap_replicates,
    )
    paired_state_task_summary = _independent_grouped_summary(
        paired_state_tasks,
        ["arm_id", "reference_knowledge_mode"],
        ["joint_minus_reference"],
        bootstrap_seed + 3000,
        bootstrap_replicates,
    )
    paired_state_summary = _independent_grouped_summary(
        paired_states,
        ["arm_id", "reference_knowledge_mode", "state_index"],
        ["joint_minus_reference"],
        bootstrap_seed + 4000,
        bootstrap_replicates,
    )
    continuous_verification = continuous_root / "verification"
    replay_verification = replay_root / "verification"
    artifacts = {
        "task metrics": (
            continuous_verification / "task_metrics.csv",
            task_frame,
            ["basin_id", "seed", "arm_id", "knowledge_mode"],
        ),
        "axis metrics": (
            continuous_verification / "axis_level_metrics.csv",
            axis_frame,
            [
                "basin_id", "seed", "arm_id", "knowledge_mode", "axis", "level"
            ],
        ),
        "state metrics": (
            continuous_verification / "state_metrics.csv",
            state_frame,
            [
                "basin_id", "seed", "arm_id", "knowledge_mode", "state_index"
            ],
        ),
        "paired axis metrics": (
            continuous_verification / "paired_axis_metrics.csv",
            paired_axis,
            ["basin_id", "seed", "arm_id", "axis", "level"],
        ),
        "paired state task metrics": (
            continuous_verification / "paired_state_task_metrics.csv",
            paired_state_tasks,
            [
                "basin_id", "seed", "arm_id", "reference_knowledge_mode"
            ],
        ),
        "paired state metrics": (
            continuous_verification / "paired_state_metrics.csv",
            paired_states,
            [
                "basin_id", "seed", "arm_id", "reference_knowledge_mode",
                "state_index",
            ],
        ),
        "paired state task summary": (
            continuous_verification / "paired_state_task_summary.csv",
            paired_state_task_summary,
            ["arm_id", "reference_knowledge_mode", "metric"],
        ),
        "paired state summary": (
            continuous_verification / "paired_state_summary.csv",
            paired_state_summary,
            ["arm_id", "reference_knowledge_mode", "state_index", "metric"],
        ),
        "event metrics": (
            replay_verification / "event_metrics.csv",
            event_frame,
            [
                "basin_id", "seed", "arm_id", "knowledge_mode", "event_index",
                "window_days",
            ],
        ),
        "propagation metrics": (
            replay_verification / "propagation_metrics.csv",
            propagation_frame,
            [
                "basin_id", "seed", "arm_id", "knowledge_mode", "event_index",
                "window_days",
            ],
        ),
        "event summary": (
            replay_verification / "event_summary.csv",
            event_summary,
            [
                "arm_id", "knowledge_mode", "event_index", "window_days", "metric"
            ],
        ),
        "propagation summary": (
            replay_verification / "propagation_summary.csv",
            propagation_summary,
            [
                "arm_id", "knowledge_mode", "event_index", "window_days", "metric"
            ],
        ),
    }
    summary_path = continuous_verification / "summary.json"
    required_metric_files = [
        *(path for path, _expected, _sort in artifacts.values()),
        summary_path,
    ]
    for path in required_metric_files:
        if not path.is_file() or path.stat().st_size == 0:
            raise AssertionError(f"required metric artifact is missing: {path}")
    for label, (path, expected, sort_columns) in artifacts.items():
        observed = pd.read_csv(path, dtype={"basin_id": str})
        verify_metric_frame(observed, expected, sort_columns, label)
    decisions = _independent_decisions(
        axis_frame,
        paired_axis,
        task_frame,
        bootstrap_seed,
        bootstrap_replicates,
    )
    with summary_path.open(encoding="utf-8") as handle:
        saved_summary = json.load(handle)
    if saved_summary.get("decisions") != decisions:
        raise AssertionError("saved scientific decisions changed")
    expected_counts = {
        "n_tasks": len(tasks),
        "replay_event_rows": len(event_frame),
        "propagation_rows": len(propagation_frame),
        "event_summary_rows": len(event_summary),
        "propagation_summary_rows": len(propagation_summary),
        "paired_state_task_rows": len(paired_state_tasks),
        "paired_state_rows": len(paired_states),
    }
    for name, expected in expected_counts.items():
        if int(saved_summary.get(name, -1)) != int(expected):
            raise AssertionError(f"saved summary count changed: {name}")
    verification = {
        "status": "PASS",
        "execution_route": route,
        "truth_packages_bitwise_replayed": len(truth_hashes),
        "continuous_tasks_verified": continuous_files,
        "replay_tasks_verified": replay_files,
        "known_axes_equal_truth": True,
        "same_observations_verified": True,
        "metric_values_independently_recomputed": True,
        "bootstrap_intervals_independently_recomputed": True,
        "scientific_decisions_independently_recomputed": True,
        "registered_input_hashes_verified": True,
    }
    _write_json_new(
        continuous_root / "verification" / "independent_verification.json",
        verification,
    )
    return verification


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--route", choices=("local", "hpc"), default="local")
    arguments = parser.parse_args()
    payload = verify_formal_evidence(route=arguments.route)
    print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
