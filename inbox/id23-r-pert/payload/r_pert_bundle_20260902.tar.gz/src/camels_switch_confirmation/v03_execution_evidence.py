"""Fail-closed lifecycle evidence for the third real-regime development run.

This module is deliberately independent of basin loading and optimization.  It
only parses already-written execution evidence and captures two local
environment commands.  The run manifest hashes every regular output file
except itself; the explicit self-exclusion avoids an impossible recursive
manifest hash.
"""

from __future__ import annotations

import csv
import hashlib
import importlib.metadata as importlib_metadata
import json
import math
import re
import subprocess
import sys
from collections.abc import Callable, Mapping, Sequence
from datetime import datetime, timedelta
from pathlib import Path, PurePosixPath
from typing import Any


RESTART_EXECUTION_COLUMNS = (
    "run_instance_id",
    "basin_id",
    "parameter_id",
    "restart_index",
    "seed",
    "declared_maxfevals_stop_threshold",
    "initial_mean_normalized",
    "initial_sigma_normalized",
    "parameter_bounds_preset",
    "objective_name",
    "objective_day_count",
    "objective_call_count",
    "optimizer_evaluation_count",
    "optimizer_iteration_count",
    "evaluation_counts_agree",
    "objective_exception_count",
    "objective_nonfinite_count",
    "objective_penalty_count",
    "stop_reasons_raw_json",
    "stop_reasons_normalized_json",
    "stop_reason_primary",
    "started_at",
    "ended_at",
    "elapsed_seconds",
    "status",
    "exception_type",
    "exception_message",
    "best_loss",
    "best_parameter_fingerprint",
    "selected",
)

REQUIRED_V03_ARTIFACTS = (
    "restart_parameter_vectors.csv",
    "fit_restart_hydrographs.csv",
    "validation_restart_hydrographs.csv",
    "functional_stability_metrics.csv",
    "restart_execution.csv",
    "run_manifest.json",
    "run_events.jsonl",
    "stdout.log",
    "stderr.log",
    "python_packages.txt",
    "conda_explicit.txt",
)

PARAMETER_OBJECTIVES = {
    "all_flow": "nse",
    "low_flow": "log_mse",
    "high_flow": "raw_mse",
}
EXPECTED_INITIAL_MEAN_NORMALIZED = 0.5
EXPECTED_INITIAL_SIGMA_NORMALIZED = 0.3
MANIFEST_SELF_HASH_POLICY = (
    "run_manifest.json excluded from artifacts_sha256 to avoid self-reference"
)
VERIFIER_IDENTITY = "camels_switch_confirmation.v03_execution_evidence"
PROHIBITED_INTERPRETATION_PERMISSIONS = (
    "online_parameter_switching",
    "filter_state_mapping",
    "parameter_identification",
    "process_noise_axis",
    "joint_parameter_process_noise_axis",
    "formal_holdout_evaluation",
    "scientific_claim",
)

_HEX_SHA256 = re.compile(r"[0-9a-f]{64}\Z")
_GIT_DIGEST = re.compile(r"(?:[0-9a-f]{40}|[0-9a-f]{64})\Z")
_BASIN_ID = re.compile(r"[0-9]{8}\Z")
_NONNEGATIVE_INTEGER = re.compile(r"(?:0|[1-9][0-9]*)\Z")
_FINITE_DECIMAL = re.compile(
    r"-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?\Z"
)


class ExecutionEvidenceError(ValueError):
    """Raised when execution evidence is incomplete, inconsistent, or unsafe."""


def _fail(message: str) -> None:
    raise ExecutionEvidenceError(message)


def _strict_mapping(value: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        _fail(f"{label} must be a mapping")
    if any(not isinstance(key, str) for key in value):
        _fail(f"{label} keys must be strings")
    return value


def _require_exact_keys(
    value: Mapping[str, Any], expected: Sequence[str], label: str
) -> None:
    actual = set(value)
    expected_set = set(expected)
    if actual != expected_set or len(value) != len(expected):
        missing = sorted(expected_set - actual)
        extra = sorted(actual - expected_set)
        _fail(f"{label} has wrong keys; missing={missing}, extra={extra}")


def _strict_string(value: Any, label: str, *, allow_empty: bool = False) -> str:
    if not isinstance(value, str):
        _fail(f"{label} must be a string")
    if not allow_empty and not value:
        _fail(f"{label} must be a nonempty string")
    if "\x00" in value:
        _fail(f"{label} must not contain a null byte")
    return value


def _strict_boolean(value: Any, label: str) -> bool:
    if type(value) is not bool:
        _fail(f"{label} must be a Boolean")
    return value


def _strict_integer(value: Any, label: str, *, minimum: int = 0) -> int:
    if type(value) is not int:
        _fail(f"{label} must be an integer")
    if value < minimum:
        _fail(f"{label} must be at least {minimum}")
    return value


def _strict_finite_number(
    value: Any,
    label: str,
    *,
    minimum: float | None = None,
    strict_minimum: bool = False,
) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        _fail(f"{label} must be a number")
    number = float(value)
    if not math.isfinite(number):
        _fail(f"{label} must be finite")
    if minimum is not None:
        invalid = number <= minimum if strict_minimum else number < minimum
        if invalid:
            operator = "greater than" if strict_minimum else "at least"
            _fail(f"{label} must be {operator} {minimum}")
    return number


def _strict_digest(value: Any, label: str) -> str:
    digest = _strict_string(value, label)
    if _HEX_SHA256.fullmatch(digest) is None:
        _fail(f"{label} must be a lowercase SHA-256 digest")
    return digest


def _safe_relative_path(value: Any, label: str) -> str:
    text = _strict_string(value, label)
    if "\\" in text:
        _fail(f"{label} must use forward slashes")
    path = PurePosixPath(text)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        _fail(f"{label} must be a safe relative path")
    return path.as_posix()


def _strict_timestamp(value: Any, label: str) -> datetime:
    text = _strict_string(value, label)
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError as error:
        raise ExecutionEvidenceError(f"{label} must be an ISO-8601 timestamp") from error
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        _fail(f"{label} must include a timezone")
    return parsed


def _reject_json_constant(value: str) -> None:
    raise ExecutionEvidenceError(f"JSON contains non-finite number {value}")


def _unique_json_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            _fail(f"JSON contains duplicate key {key!r}")
        result[key] = value
    return result


def _strict_json_loads(text: str, label: str) -> Any:
    try:
        return json.loads(
            text,
            parse_constant=_reject_json_constant,
            object_pairs_hook=_unique_json_object,
        )
    except ExecutionEvidenceError:
        raise
    except (TypeError, ValueError, json.JSONDecodeError) as error:
        raise ExecutionEvidenceError(f"{label} is not strict JSON") from error


def _read_strict_json(path: Path, label: str) -> Any:
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as error:
        raise ExecutionEvidenceError(f"cannot read {label}: {path}") from error
    return _strict_json_loads(text, label)


def _parse_csv_integer(
    value: Any,
    label: str,
    *,
    minimum: int = 0,
    allow_empty: bool = False,
) -> int | None:
    if not isinstance(value, str):
        _fail(f"{label} must be a CSV integer")
    if allow_empty and value == "":
        return None
    if _NONNEGATIVE_INTEGER.fullmatch(value) is None:
        _fail(f"{label} must use exact nonnegative integer syntax")
    parsed = int(value)
    if parsed < minimum:
        _fail(f"{label} must be at least {minimum}")
    return parsed


def _parse_csv_number(
    value: Any,
    label: str,
    *,
    minimum: float | None = None,
    strict_minimum: bool = False,
    allow_empty: bool = False,
) -> float | None:
    if not isinstance(value, str):
        _fail(f"{label} must be a CSV number")
    if allow_empty and value == "":
        return None
    if _FINITE_DECIMAL.fullmatch(value) is None:
        _fail(f"{label} must be a finite decimal number")
    parsed = float(value)
    if not math.isfinite(parsed):
        _fail(f"{label} must be finite")
    if minimum is not None:
        invalid = parsed <= minimum if strict_minimum else parsed < minimum
        if invalid:
            operator = "greater than" if strict_minimum else "at least"
            _fail(f"{label} must be {operator} {minimum}")
    return parsed


def _parse_csv_boolean(
    value: Any, label: str, *, allow_empty: bool = False
) -> bool | None:
    if allow_empty and value == "":
        return None
    if value not in {"true", "false"}:
        _fail(f"{label} must be a lowercase Boolean true or false")
    return value == "true"


def _load_freeze_credential(
    credential: str | Path | Mapping[str, Any],
) -> tuple[Mapping[str, Any], str | None]:
    if isinstance(credential, Mapping):
        document = credential
        digest = None
    else:
        path = Path(credential)
        document = _read_strict_json(path, "freeze credential")
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
    return _strict_mapping(document, "freeze credential"), digest


def _freeze_contract(credential: Mapping[str, Any]) -> dict[str, Any]:
    protocol_id = _strict_string(credential.get("protocol_id"), "freeze protocol_id")
    human_protocol_path = _safe_relative_path(
        credential.get("human_protocol_path"), "freeze human_protocol_path"
    )
    human_protocol_sha256 = _strict_digest(
        credential.get("human_protocol_sha256"), "freeze human_protocol_sha256"
    )
    fixed = _strict_mapping(credential.get("fixed_factors"), "freeze fixed_factors")
    basin_values = fixed.get("basin_ids")
    if not isinstance(basin_values, list) or not basin_values:
        _fail("freeze basin_ids must be a nonempty list")
    basin_ids = tuple(_strict_string(value, "freeze basin_id") for value in basin_values)
    if len(set(basin_ids)) != len(basin_ids) or any(
        _BASIN_ID.fullmatch(value) is None for value in basin_ids
    ):
        _fail("freeze basin_ids must be unique eight-digit identifiers")
    group_values = fixed.get("parameter_groups")
    if not isinstance(group_values, list):
        _fail("freeze parameter_groups must be a list")
    parameter_ids = tuple(
        _strict_string(value, "freeze parameter group") for value in group_values
    )
    if parameter_ids != tuple(PARAMETER_OBJECTIVES):
        _fail("freeze parameter groups differ from all-flow, low-flow, high-flow")
    bounds_preset = _strict_string(
        fixed.get("parameter_bounds_preset"), "freeze parameter bounds preset"
    )
    optimizer = _strict_mapping(fixed.get("optimizer"), "freeze optimizer")
    threshold = _strict_integer(
        optimizer.get("function_evaluations_per_restart"),
        "freeze maxfevals stop threshold",
        minimum=1,
    )
    budget_semantics = _strict_mapping(
        optimizer.get("evaluation_budget_semantics"),
        "freeze evaluation budget semantics",
    )
    expected_budget_keys = {
        "config_field",
        "pycma_option",
        "declared_stop_threshold",
        "stop_check_boundary",
        "actual_objective_calls_may_exceed_threshold",
        "actual_objective_call_count_authority",
    }
    if set(budget_semantics) != expected_budget_keys:
        _fail("freeze evaluation budget semantics has wrong keys")
    if _strict_string(
        budget_semantics.get("config_field"), "freeze budget config field"
    ) != "function_evaluations_per_restart":
        _fail("freeze budget config field is not the legacy maxfevals carrier")
    if _strict_string(
        budget_semantics.get("pycma_option"), "freeze budget pycma option"
    ) != "maxfevals":
        _fail("freeze budget pycma option is not maxfevals")
    semantic_threshold = _strict_integer(
        budget_semantics.get("declared_stop_threshold"),
        "freeze declared maxfevals stop threshold",
        minimum=1,
    )
    if semantic_threshold != threshold:
        _fail("freeze declared maxfevals threshold differs from the config carrier")
    if _strict_string(
        budget_semantics.get("stop_check_boundary"), "freeze budget stop-check boundary"
    ) != "after_complete_generation":
        _fail("freeze maxfevals stop check is not after a complete generation")
    if not _strict_boolean(
        budget_semantics.get("actual_objective_calls_may_exceed_threshold"),
        "freeze objective-call threshold exceedance permission",
    ):
        _fail("freeze must permit actual objective calls above the maxfevals threshold")
    if _strict_string(
        budget_semantics.get("actual_objective_call_count_authority"),
        "freeze actual objective-call count authority",
    ) != "restart_execution.csv:objective_call_count":
        _fail(
            "freeze actual objective-call authority is not the objective_call_count column"
        )
    seed_values = optimizer.get("restart_seeds")
    if not isinstance(seed_values, list) or not seed_values:
        _fail("freeze restart seeds must be a nonempty list")
    seeds = tuple(
        _strict_integer(value, "freeze restart seed", minimum=0)
        for value in seed_values
    )
    if len(set(seeds)) != len(seeds):
        _fail("freeze restart seeds must be unique")
    expected_restart_count = _strict_integer(
        optimizer.get("expected_restart_count"),
        "freeze expected restart count",
        minimum=1,
    )
    if expected_restart_count != len(basin_ids) * len(parameter_ids) * len(seeds):
        _fail("freeze expected restart count differs from the identity cross-product")
    evidence_contract = _strict_mapping(
        credential.get("evidence_contract"), "freeze evidence contract"
    )
    artifact_values = evidence_contract.get("required_artifacts")
    if not isinstance(artifact_values, list):
        _fail("freeze required artifacts must be a list")
    required_artifacts = tuple(
        _safe_relative_path(value, "freeze required artifact")
        for value in artifact_values
    )
    if required_artifacts != REQUIRED_V03_ARTIFACTS:
        _fail("freeze required artifacts differ from the eleven-file contract")
    permissions = _strict_mapping(
        credential.get("interpretation_permissions"),
        "freeze interpretation permissions",
    )
    for name in PROHIBITED_INTERPRETATION_PERMISSIONS:
        if _strict_boolean(permissions.get(name), f"freeze permission {name}"):
            _fail(f"freeze permission {name} must remain false")
    expected_inputs: dict[str, str] = {}
    for path_key, digest_key in (
        ("basin_manifest_path", "basin_manifest_sha256"),
        ("development_universe_path", "development_universe_sha256"),
        ("input_manifest_path", "input_manifest_sha256"),
        ("topography_path", "topography_sha256"),
    ):
        if path_key in fixed or digest_key in fixed:
            if path_key not in fixed or digest_key not in fixed:
                _fail(f"freeze input binding {path_key}/{digest_key} is incomplete")
            expected_inputs[_safe_relative_path(fixed[path_key], f"freeze {path_key}")] = (
                _strict_digest(fixed[digest_key], f"freeze {digest_key}")
            )
    return {
        "protocol_id": protocol_id,
        "human_protocol_path": human_protocol_path,
        "human_protocol_sha256": human_protocol_sha256,
        "basin_ids": basin_ids,
        "parameter_ids": parameter_ids,
        "bounds_preset": bounds_preset,
        "threshold": threshold,
        "seeds": seeds,
        "expected_restart_count": expected_restart_count,
        "required_artifacts": required_artifacts,
        "expected_inputs": expected_inputs,
    }


def _read_restart_rows(path: Path) -> list[dict[str, Any]]:
    try:
        with path.open(encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            if tuple(reader.fieldnames or ()) != RESTART_EXECUTION_COLUMNS:
                _fail("restart execution table has wrong columns or column order")
            raw_rows = list(reader)
    except (OSError, UnicodeError, csv.Error) as error:
        raise ExecutionEvidenceError("cannot read restart_execution.csv") from error
    parsed_rows: list[dict[str, Any]] = []
    for position, raw in enumerate(raw_rows):
        label = f"restart execution row {position}"
        status = _strict_string(raw["status"], f"{label} status")
        if status not in {"completed", "failed"}:
            _fail(f"{label} status must be completed or failed")
        optimizer_count = _parse_csv_integer(
            raw["optimizer_evaluation_count"],
            f"{label} optimizer evaluation count",
            allow_empty=status == "failed",
        )
        optimizer_iterations = _parse_csv_integer(
            raw["optimizer_iteration_count"],
            f"{label} optimizer iteration count",
            allow_empty=status == "failed",
        )
        counts_agree = _parse_csv_boolean(
            raw["evaluation_counts_agree"],
            f"{label} evaluation_counts_agree",
            allow_empty=status == "failed",
        )
        best_loss = _parse_csv_number(
            raw["best_loss"], f"{label} best loss", allow_empty=status == "failed"
        )
        row = {
            "run_instance_id": _strict_string(
                raw["run_instance_id"], f"{label} run instance"
            ),
            "basin_id": _strict_string(raw["basin_id"], f"{label} basin_id"),
            "parameter_id": _strict_string(
                raw["parameter_id"], f"{label} parameter_id"
            ),
            "restart_index": _parse_csv_integer(
                raw["restart_index"], f"{label} restart index"
            ),
            "seed": _parse_csv_integer(raw["seed"], f"{label} seed"),
            "declared_maxfevals_stop_threshold": _parse_csv_integer(
                raw["declared_maxfevals_stop_threshold"],
                f"{label} declared maxfevals stop threshold",
                minimum=1,
            ),
            "initial_mean_normalized": _parse_csv_number(
                raw["initial_mean_normalized"],
                f"{label} initial mean",
                minimum=0.0,
            ),
            "initial_sigma_normalized": _parse_csv_number(
                raw["initial_sigma_normalized"],
                f"{label} initial standard deviation",
                minimum=0.0,
                strict_minimum=True,
            ),
            "parameter_bounds_preset": _strict_string(
                raw["parameter_bounds_preset"], f"{label} parameter bounds preset"
            ),
            "objective_name": _strict_string(
                raw["objective_name"], f"{label} objective name"
            ),
            "objective_day_count": _parse_csv_integer(
                raw["objective_day_count"], f"{label} objective day count", minimum=1
            ),
            "objective_call_count": _parse_csv_integer(
                raw["objective_call_count"], f"{label} objective call count"
            ),
            "optimizer_evaluation_count": optimizer_count,
            "optimizer_iteration_count": optimizer_iterations,
            "evaluation_counts_agree": counts_agree,
            "objective_exception_count": _parse_csv_integer(
                raw["objective_exception_count"],
                f"{label} objective exception count",
            ),
            "objective_nonfinite_count": _parse_csv_integer(
                raw["objective_nonfinite_count"],
                f"{label} objective non-finite count",
            ),
            "objective_penalty_count": _parse_csv_integer(
                raw["objective_penalty_count"], f"{label} objective penalty count"
            ),
            "stop_reasons_raw": _strict_json_loads(
                raw["stop_reasons_raw_json"], f"{label} raw stop reasons"
            ),
            "stop_reasons_normalized": _strict_json_loads(
                raw["stop_reasons_normalized_json"],
                f"{label} normalized stop reasons",
            ),
            "stop_reason_primary": _strict_string(
                raw["stop_reason_primary"],
                f"{label} primary stop reason",
                allow_empty=status == "failed",
            ),
            "started_at_text": _strict_string(
                raw["started_at"], f"{label} started_at"
            ),
            "started_at": _strict_timestamp(raw["started_at"], f"{label} started_at"),
            "ended_at_text": _strict_string(raw["ended_at"], f"{label} ended_at"),
            "ended_at": _strict_timestamp(raw["ended_at"], f"{label} ended_at"),
            "elapsed_seconds": _parse_csv_number(
                raw["elapsed_seconds"], f"{label} elapsed seconds", minimum=0.0
            ),
            "status": status,
            "exception_type": _strict_string(
                raw["exception_type"],
                f"{label} exception type",
                allow_empty=status == "completed",
            ),
            "exception_message": _strict_string(
                raw["exception_message"],
                f"{label} exception message",
                allow_empty=status == "completed",
            ),
            "best_loss": best_loss,
            "best_parameter_fingerprint": _strict_string(
                raw["best_parameter_fingerprint"],
                f"{label} best parameter fingerprint",
                allow_empty=status == "failed",
            ),
            "selected": _parse_csv_boolean(raw["selected"], f"{label} selected"),
        }
        parsed_rows.append(row)
    return parsed_rows


def _expected_identities(contract: Mapping[str, Any]) -> list[tuple[str, str, int, int]]:
    return [
        (basin_id, parameter_id, restart_index, seed)
        for basin_id in contract["basin_ids"]
        for parameter_id in contract["parameter_ids"]
        for restart_index, seed in enumerate(contract["seeds"])
    ]


def _validate_restart_rows(
    rows: list[dict[str, Any]],
    contract: Mapping[str, Any],
    *,
    run_instance_id: str,
    allow_failed: bool,
    terminal_status: str | None,
    expected_selected_parameter_fingerprints: Mapping[str, str] | None,
) -> dict[str, Any]:
    expected = _expected_identities(contract)
    failed_rows = [row for row in rows if row["status"] == "failed"]
    if terminal_status is None:
        terminal_status = (
            "failed"
            if failed_rows or not rows or (allow_failed and len(rows) < len(expected))
            else "completed"
        )
    if terminal_status not in {"completed", "failed"}:
        _fail("restart execution terminal status must be completed or failed")
    if terminal_status == "failed":
        if not allow_failed:
            _fail("failed run evidence requires allow_failed=True")
        if failed_rows and (
            len(failed_rows) != 1 or not rows or rows[-1]["status"] != "failed"
        ):
            _fail("a real failed restart must be the unique final restart row")
        if len(rows) > len(expected):
            _fail("failed-run restart evidence exceeds the frozen identity count")
        expected_slice = expected[:len(rows)]
    else:
        if failed_rows:
            _fail("a completed run cannot contain a failed restart row")
        if len(rows) != contract["expected_restart_count"]:
            _fail("successful restart execution must contain exactly 27 rows")
        expected_slice = expected
    actual_identities = [
        (row["basin_id"], row["parameter_id"], row["restart_index"], row["seed"])
        for row in rows
    ]
    if actual_identities != expected_slice:
        _fail("restart execution identities are incomplete, duplicated, or out of order")

    for position, row in enumerate(rows):
        label = f"restart execution row {position}"
        if row["run_instance_id"] != run_instance_id:
            _fail(f"{label} run instance differs from the manifest")
        if row["declared_maxfevals_stop_threshold"] != contract["threshold"]:
            _fail(f"{label} declared maxfevals stop threshold differs from the freeze")
        if row["initial_mean_normalized"] != EXPECTED_INITIAL_MEAN_NORMALIZED:
            _fail(f"{label} initial mean differs from the frozen optimizer default")
        if row["initial_sigma_normalized"] != EXPECTED_INITIAL_SIGMA_NORMALIZED:
            _fail(
                f"{label} initial standard deviation differs from the frozen optimizer default"
            )
        if row["parameter_bounds_preset"] != contract["bounds_preset"]:
            _fail(f"{label} parameter bounds preset differs from the freeze")
        expected_objective = PARAMETER_OBJECTIVES[row["parameter_id"]]
        if row["objective_name"] != expected_objective:
            _fail(f"{label} objective name differs from the parameter-group contract")
        if row["ended_at"] < row["started_at"]:
            _fail(f"{label} ended before it started")
        if (
            row["objective_penalty_count"]
            != row["objective_exception_count"] + row["objective_nonfinite_count"]
        ):
            _fail(f"{label} objective penalty count is inconsistent")
        raw_stop = row["stop_reasons_raw"]
        normalized_stop = row["stop_reasons_normalized"]
        if not isinstance(raw_stop, Mapping) or any(
            not isinstance(key, str) for key in raw_stop
        ):
            _fail(f"{label} raw stop reasons must be a mapping")
        if not isinstance(normalized_stop, list) or any(
            not isinstance(reason, str) or not reason for reason in normalized_stop
        ):
            _fail(f"{label} normalized stop reasons must be a list of strings")
        if row["status"] == "completed":
            if not raw_stop or not normalized_stop:
                _fail(f"{label} completed restart must have nonempty stop reasons")
            if row["stop_reason_primary"] != normalized_stop[0]:
                _fail(f"{label} primary stop reason is inconsistent")
            if row["optimizer_evaluation_count"] is None:
                _fail(f"{label} completed restart lacks optimizer evaluation count")
            if row["optimizer_iteration_count"] is None:
                _fail(f"{label} completed restart lacks optimizer iteration count")
            if row["optimizer_iteration_count"] < 1:
                _fail(f"{label} completed restart must have at least one iteration")
            if (
                row["objective_call_count"] != row["optimizer_evaluation_count"]
                or row["evaluation_counts_agree"] is not True
            ):
                _fail(f"{label} objective and optimizer evaluation counts disagree")
            if row["best_loss"] is None:
                _fail(f"{label} completed restart lacks a finite best loss")
            if _HEX_SHA256.fullmatch(row["best_parameter_fingerprint"]) is None:
                _fail(f"{label} completed restart has an invalid parameter fingerprint")
            if row["exception_type"] or row["exception_message"]:
                _fail(f"{label} completed restart must not record an exception")
        else:
            if row["selected"]:
                _fail(f"{label} failed restart cannot be selected")
            if not row["exception_type"] or not row["exception_message"]:
                _fail(f"{label} failed restart must record its exception")
            if raw_stop or normalized_stop or row["stop_reason_primary"]:
                if not raw_stop or not normalized_stop:
                    _fail(f"{label} partial stop reasons are inconsistent")
                if row["stop_reason_primary"] != normalized_stop[0]:
                    _fail(f"{label} primary stop reason is inconsistent")
            if row["optimizer_evaluation_count"] is None:
                if row["evaluation_counts_agree"] is not None:
                    _fail(f"{label} count-agreement flag must be blank when count is unknown")
            else:
                actual_agreement = (
                    row["objective_call_count"] == row["optimizer_evaluation_count"]
                )
                if row["evaluation_counts_agree"] is not actual_agreement:
                    _fail(
                        f"{label} count-agreement flag does not reflect the known "
                        "objective and optimizer evaluation counts"
                    )
            if row["best_loss"] is None:
                if row["best_parameter_fingerprint"]:
                    _fail(f"{label} fingerprint exists without a best loss")
            elif _HEX_SHA256.fullmatch(row["best_parameter_fingerprint"]) is None:
                _fail(f"{label} failed restart has an invalid parameter fingerprint")

    selected_fingerprints: dict[str, str] = {}
    for basin_id in contract["basin_ids"]:
        for parameter_id in contract["parameter_ids"]:
            group = [
                row
                for row in rows
                if row["basin_id"] == basin_id and row["parameter_id"] == parameter_id
            ]
            key = f"{basin_id}/{parameter_id}"
            complete_group = (
                len(group) == len(contract["seeds"])
                and all(row["status"] == "completed" for row in group)
            )
            if not complete_group:
                if any(row["selected"] for row in group):
                    _fail(f"incomplete group {key} must not claim a selected restart")
                continue
            selected = [row for row in group if row["selected"]]
            if len(selected) != 1:
                _fail(f"completed group {key} must have exactly one selected restart")
            expected_selected = min(group, key=lambda row: row["best_loss"])
            if selected[0] is not expected_selected:
                _fail(f"completed group {key} selected restart is not the first strict minimum")
            selected_fingerprints[key] = selected[0]["best_parameter_fingerprint"]

    if expected_selected_parameter_fingerprints is not None:
        expected_fingerprints = _validate_digest_mapping(
            expected_selected_parameter_fingerprints,
            "expected selected fingerprints",
            safe_paths=True,
        )
        if expected_fingerprints != selected_fingerprints:
            _fail("selected parameter fingerprints differ from independent evidence")

    optimizer_counts_known = all(
        row["optimizer_evaluation_count"] is not None for row in rows
    )
    iteration_counts_known = all(row["optimizer_iteration_count"] is not None for row in rows)
    return {
        "rows": rows,
        "selected_fingerprints": selected_fingerprints,
        "restart_count": len(rows),
        "completed_restart_count": sum(row["status"] == "completed" for row in rows),
        "failed_restart_count": sum(row["status"] == "failed" for row in rows),
        "total_objective_calls": sum(row["objective_call_count"] for row in rows),
        "total_optimizer_evaluations": (
            sum(row["optimizer_evaluation_count"] for row in rows)
            if optimizer_counts_known
            else None
        ),
        "total_optimizer_iterations": (
            sum(row["optimizer_iteration_count"] for row in rows)
            if iteration_counts_known
            else None
        ),
        "terminal_status": terminal_status,
    }


def _validate_digest_mapping(
    value: Any,
    label: str,
    *,
    safe_paths: bool,
) -> dict[str, str]:
    mapping = _strict_mapping(value, label)
    result: dict[str, str] = {}
    for raw_path, raw_digest in mapping.items():
        path = _safe_relative_path(raw_path, f"{label} path") if safe_paths else raw_path
        result[path] = _strict_digest(raw_digest, f"{label} digest for {path}")
    return result


def _read_events(path: Path) -> list[Mapping[str, Any]]:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError) as error:
        raise ExecutionEvidenceError("cannot read run_events.jsonl") from error
    if not lines or any(not line for line in lines):
        _fail("run_events.jsonl must contain nonempty JSON lines")
    events: list[Mapping[str, Any]] = []
    for index, line in enumerate(lines):
        parsed = _strict_mapping(
            _strict_json_loads(line, f"run event {index}"), f"run event {index}"
        )
        _require_exact_keys(
            parsed,
            (
                "timestamp",
                "severity",
                "event",
                "experiment_id",
                "run_instance_id",
                "context",
            ),
            f"run event {index}",
        )
        events.append(parsed)
    return events


def _restart_context(row: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "basin_id": row["basin_id"],
        "parameter_id": row["parameter_id"],
        "restart_index": row["restart_index"],
        "seed": row["seed"],
    }


def _validate_events(
    events: list[Mapping[str, Any]],
    restart_summary: Mapping[str, Any],
    *,
    experiment_id: str,
    run_instance_id: str,
) -> dict[str, Any]:
    rows = restart_summary["rows"]
    actual_names = [event.get("event") for event in events]
    if restart_summary["terminal_status"] == "failed" and not rows:
        allowed_prefixes = {
            ("run_started", "config_verified"),
            ("run_started", "config_verified", "inputs_verified"),
            (
                "run_started",
                "config_verified",
                "inputs_verified",
                "preflight_completed",
            ),
        }
        actual_prefix = tuple(actual_names[:-1]) if actual_names else ()
        if not actual_names or actual_names[-1] != "run_failed" or actual_prefix not in allowed_prefixes:
            _fail(
                "zero-restart failure lifecycle is not a valid completed-stage prefix: "
                f"{actual_names}"
            )
        expected: list[tuple[str, str, dict[str, Any], datetime | None]] = [
            (name, "INFO", {}, None) for name in actual_prefix
        ]
    else:
        expected = [
            ("run_started", "INFO", {}, None),
            ("config_verified", "INFO", {}, None),
            ("inputs_verified", "INFO", {}, None),
            ("preflight_completed", "INFO", {}, None),
        ]
    for row in rows:
        context = _restart_context(row)
        expected.append(("restart_started", "INFO", context, row["started_at"]))
        if row["status"] == "completed":
            expected.append(("restart_completed", "INFO", context, row["ended_at"]))
        else:
            expected.append(("restart_failed", "ERROR", context, row["ended_at"]))
    if restart_summary["terminal_status"] == "completed":
        expected.extend([
            ("artifacts_written", "INFO", {}, None),
            ("artifact_verification_completed", "INFO", {}, None),
            ("run_completed", "INFO", {}, None),
        ])
    else:
        expected.append(("run_failed", "ERROR", {}, None))
    expected_names = [item[0] for item in expected]
    if actual_names != expected_names:
        _fail(
            "run lifecycle event order differs from the frozen contract; "
            f"expected={expected_names}, actual={actual_names}"
        )
    parsed_times: list[datetime] = []
    for index, (event, expected_event) in enumerate(zip(events, expected, strict=True)):
        name, severity, context, exact_time = expected_event
        if _strict_string(event["event"], f"run event {index} name") != name:
            _fail(f"run event {index} name is inconsistent")
        if _strict_string(event["severity"], f"run event {index} severity") != severity:
            _fail(f"run event {index} severity is inconsistent")
        if _strict_string(
            event["experiment_id"], f"run event {index} experiment_id"
        ) != experiment_id:
            _fail(f"run event {index} experiment identifier differs from the manifest")
        if _strict_string(
            event["run_instance_id"], f"run event {index} run_instance_id"
        ) != run_instance_id:
            _fail(f"run event {index} run instance differs from the manifest")
        actual_context = _strict_mapping(event["context"], f"run event {index} context")
        if actual_context != context:
            _fail(f"run event {index} restart context is inconsistent")
        if context:
            _strict_integer(actual_context["restart_index"], f"run event {index} restart")
            _strict_integer(actual_context["seed"], f"run event {index} seed")
        timestamp = _strict_timestamp(event["timestamp"], f"run event {index} timestamp")
        if exact_time is not None and timestamp != exact_time:
            _fail(f"run event {index} timestamp differs from restart telemetry")
        parsed_times.append(timestamp)
    if any(later < earlier for earlier, later in zip(parsed_times, parsed_times[1:])):
        _fail("run event timestamps are reordered")
    return {"started_at": parsed_times[0], "ended_at": parsed_times[-1]}


def _artifact_hashes(output: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    for path in sorted(output.rglob("*")):
        if path.is_symlink():
            _fail(f"execution evidence contains a symbolic link: {path}")
        if not path.is_file():
            continue
        relative = path.relative_to(output).as_posix()
        if relative == "run_manifest.json":
            continue
        result[relative] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def _format_utc_offset(value: timedelta) -> str:
    total_seconds = int(value.total_seconds())
    sign = "+" if total_seconds >= 0 else "-"
    absolute = abs(total_seconds)
    hours, remainder = divmod(absolute, 3600)
    minutes = remainder // 60
    return f"{sign}{hours:02d}:{minutes:02d}"


def _validate_manifest(
    manifest: Mapping[str, Any],
    output: Path,
    contract: Mapping[str, Any],
    freeze_digest: str | None,
    restart_summary: Mapping[str, Any],
    event_timing: Mapping[str, datetime],
    *,
    expected_experiment_id: str | None,
    expected_run_instance_id: str | None,
    expected_config_sha256: str | None,
) -> tuple[str, str]:
    _require_exact_keys(
        manifest,
        (
            "schema_version",
            "run",
            "protocol",
            "configuration",
            "inputs_sha256",
            "source_snapshot",
            "command",
            "working_directory",
            "python_executable",
            "timing",
            "environment",
            "work",
            "exit",
            "artifacts_sha256",
            "manifest_self_hash_policy",
            "verifier",
            "selected_parameter_fingerprints",
            "interpretation_permissions",
        ),
        "run manifest",
    )
    if _strict_integer(manifest["schema_version"], "manifest schema version", minimum=1) != 1:
        _fail("manifest schema version must equal 1")

    run = _strict_mapping(manifest["run"], "manifest run")
    _require_exact_keys(run, ("experiment_id", "run_instance_id"), "manifest run")
    experiment_id = _strict_string(run["experiment_id"], "manifest experiment_id")
    run_instance_id = _strict_string(run["run_instance_id"], "manifest run_instance_id")
    if expected_experiment_id is not None and experiment_id != expected_experiment_id:
        _fail("manifest experiment identifier differs from the expected experiment")
    if expected_run_instance_id is not None and run_instance_id != expected_run_instance_id:
        _fail("manifest run instance differs from the expected run instance")

    protocol = _strict_mapping(manifest["protocol"], "manifest protocol")
    _require_exact_keys(
        protocol,
        (
            "protocol_id",
            "credential_path",
            "credential_sha256",
            "human_protocol_path",
            "human_protocol_sha256",
        ),
        "manifest protocol",
    )
    if _strict_string(protocol["protocol_id"], "manifest protocol_id") != contract["protocol_id"]:
        _fail("manifest protocol identifier differs from the freeze credential")
    _safe_relative_path(protocol["credential_path"], "manifest protocol credential path")
    credential_sha = _strict_digest(
        protocol["credential_sha256"], "manifest protocol credential hash"
    )
    if freeze_digest is not None and credential_sha != freeze_digest:
        _fail("manifest protocol credential hash differs from the supplied freeze credential")
    if _safe_relative_path(
        protocol["human_protocol_path"], "manifest human protocol path"
    ) != contract["human_protocol_path"]:
        _fail("manifest human protocol path differs from the freeze credential")
    if _strict_digest(
        protocol["human_protocol_sha256"], "manifest human protocol hash"
    ) != contract["human_protocol_sha256"]:
        _fail("manifest human protocol hash differs from the freeze credential")

    configuration = _strict_mapping(manifest["configuration"], "manifest configuration")
    _require_exact_keys(configuration, ("path", "sha256"), "manifest configuration")
    _safe_relative_path(configuration["path"], "manifest configuration path")
    configuration_sha = _strict_digest(
        configuration["sha256"], "manifest configuration hash"
    )
    if expected_config_sha256 is not None:
        expected_sha = _strict_digest(expected_config_sha256, "expected configuration hash")
        if configuration_sha != expected_sha:
            _fail("manifest configuration hash differs from the expected configuration")

    input_hashes = _validate_digest_mapping(
        manifest["inputs_sha256"], "manifest input hashes", safe_paths=True
    )
    if not input_hashes:
        _fail("manifest input hashes must be nonempty")
    if contract["expected_inputs"] and input_hashes != contract["expected_inputs"]:
        _fail("manifest input hashes differ from the frozen input chain")

    source = _strict_mapping(manifest["source_snapshot"], "manifest source snapshot")
    _require_exact_keys(
        source,
        ("dirty_worktree", "git_commit", "path", "files_sha256"),
        "manifest source snapshot",
    )
    _strict_boolean(source["dirty_worktree"], "manifest dirty_worktree")
    git_commit = _strict_string(source["git_commit"], "manifest git commit")
    if _GIT_DIGEST.fullmatch(git_commit) is None:
        _fail("manifest git commit must be a lowercase Git digest")
    source_path = _safe_relative_path(source["path"], "manifest source snapshot path")
    if source_path != "source_snapshot":
        _fail("manifest source snapshot path must be source_snapshot")
    source_hashes = _validate_digest_mapping(
        source["files_sha256"], "manifest source hashes", safe_paths=True
    )
    if not source_hashes:
        _fail("manifest source hashes must be nonempty")
    if any(not path.startswith("source_snapshot/") for path in source_hashes):
        _fail("manifest source hashes contain a path outside source_snapshot")

    command = manifest["command"]
    if not isinstance(command, list) or not command:
        _fail("manifest command must be a nonempty list")
    for index, part in enumerate(command):
        _strict_string(part, f"manifest command part {index}")
    working_directory = Path(
        _strict_string(manifest["working_directory"], "manifest working directory")
    )
    executable = Path(
        _strict_string(manifest["python_executable"], "manifest Python executable")
    )
    if not working_directory.is_absolute() or not executable.is_absolute():
        _fail("manifest working directory and Python executable must be absolute")

    timing = _strict_mapping(manifest["timing"], "manifest timing")
    _require_exact_keys(
        timing,
        ("started_at", "ended_at", "utc_offset", "monotonic_elapsed_seconds"),
        "manifest timing",
    )
    started = _strict_timestamp(timing["started_at"], "manifest started_at")
    ended = _strict_timestamp(timing["ended_at"], "manifest ended_at")
    if started != event_timing["started_at"] or ended != event_timing["ended_at"]:
        _fail("manifest run timing differs from the lifecycle events")
    utc_offset = _strict_string(timing["utc_offset"], "manifest UTC offset")
    if utc_offset != _format_utc_offset(started.utcoffset()) or ended.utcoffset() != started.utcoffset():
        _fail("manifest UTC offset differs from the zoned run timestamps")
    monotonic_elapsed = _strict_finite_number(
        timing["monotonic_elapsed_seconds"],
        "manifest monotonic elapsed seconds",
        minimum=0.0,
    )
    wall_elapsed = (ended - started).total_seconds()
    if abs(monotonic_elapsed - wall_elapsed) > 1.0:
        _fail("manifest monotonic elapsed time differs materially from zoned timestamps")

    environment = _strict_mapping(manifest["environment"], "manifest environment")
    _require_exact_keys(
        environment,
        (
            "python_version",
            "operating_system",
            "architecture",
            "processor",
            "numpy_version",
            "numpy_configuration",
        ),
        "manifest environment",
    )
    for name in (
        "python_version",
        "operating_system",
        "architecture",
        "numpy_version",
        "numpy_configuration",
    ):
        _strict_string(environment[name], f"manifest environment {name}")
    _strict_string(
        environment["processor"], "manifest environment processor", allow_empty=True
    )

    work = _strict_mapping(manifest["work"], "manifest work")
    _require_exact_keys(
        work,
        (
            "declared_maxfevals_stop_threshold",
            "expected_restart_count",
            "observed_restart_count",
            "completed_restart_count",
            "failed_restart_count",
            "total_objective_calls",
            "total_optimizer_evaluations",
            "total_optimizer_iterations",
        ),
        "manifest work",
    )
    expected_values = {
        "declared_maxfevals_stop_threshold": contract["threshold"],
        "expected_restart_count": contract["expected_restart_count"],
        "observed_restart_count": restart_summary["restart_count"],
        "completed_restart_count": restart_summary["completed_restart_count"],
        "failed_restart_count": restart_summary["failed_restart_count"],
        "total_objective_calls": restart_summary["total_objective_calls"],
    }
    for name, expected_value in expected_values.items():
        if _strict_integer(work[name], f"manifest work {name}") != expected_value:
            _fail(f"manifest work {name} differs from restart evidence")
    for name in ("total_optimizer_evaluations", "total_optimizer_iterations"):
        expected_value = restart_summary[name]
        if expected_value is None:
            if work[name] is not None:
                _fail(f"manifest work {name} must be null when failed telemetry is unknown")
        elif _strict_integer(work[name], f"manifest work {name}") != expected_value:
            _fail(f"manifest work {name} differs from restart evidence")

    exit_record = _strict_mapping(manifest["exit"], "manifest exit")
    _require_exact_keys(exit_record, ("exit_code", "terminal_status"), "manifest exit")
    exit_code = _strict_integer(exit_record["exit_code"], "manifest exit code")
    terminal_status = _strict_string(
        exit_record["terminal_status"], "manifest terminal status"
    )
    if terminal_status != restart_summary["terminal_status"]:
        _fail("manifest terminal status differs from restart evidence")
    if (terminal_status == "completed" and exit_code != 0) or (
        terminal_status == "failed" and exit_code == 0
    ):
        _fail("manifest exit code differs from terminal status")

    artifact_hashes = _validate_digest_mapping(
        manifest["artifacts_sha256"], "manifest artifact map", safe_paths=True
    )
    actual_artifact_hashes = _artifact_hashes(output)
    if artifact_hashes != actual_artifact_hashes:
        differing = sorted(
            path
            for path in set(artifact_hashes) | set(actual_artifact_hashes)
            if artifact_hashes.get(path) != actual_artifact_hashes.get(path)
        )
        _fail(f"manifest artifact map is incomplete or altered: {differing}")
    if source_hashes != {
        path: digest
        for path, digest in actual_artifact_hashes.items()
        if path.startswith("source_snapshot/")
    }:
        _fail("manifest source hashes do not cover every source snapshot file")
    if manifest["manifest_self_hash_policy"] != MANIFEST_SELF_HASH_POLICY:
        _fail("manifest self-hash policy does not explicitly avoid self-reference")

    verifier = _strict_mapping(manifest["verifier"], "manifest verifier")
    _require_exact_keys(verifier, ("identity", "verified_at", "result"), "manifest verifier")
    if _strict_string(verifier["identity"], "manifest verifier identity") != VERIFIER_IDENTITY:
        _fail("manifest verifier identity is not the independent verifier")
    verified_at = _strict_timestamp(verifier["verified_at"], "manifest verifier time")
    if verified_at < started or verified_at > ended:
        _fail("manifest verifier time lies outside the run lifecycle")
    if _strict_string(verifier["result"], "manifest verifier result") != "passed":
        _fail("manifest verifier result must be passed")

    selected = _validate_digest_mapping(
        manifest["selected_parameter_fingerprints"],
        "manifest selected fingerprints",
        safe_paths=True,
    )
    if selected != restart_summary["selected_fingerprints"]:
        _fail("manifest selected parameter fingerprints differ from restart evidence")

    permissions = _strict_mapping(
        manifest["interpretation_permissions"], "manifest interpretation permissions"
    )
    _require_exact_keys(
        permissions,
        PROHIBITED_INTERPRETATION_PERMISSIONS,
        "manifest interpretation permissions",
    )
    for name in PROHIBITED_INTERPRETATION_PERMISSIONS:
        if _strict_boolean(permissions[name], f"manifest permission {name}"):
            _fail(f"manifest permission {name} must remain false")
    return experiment_id, run_instance_id


def validate_restart_execution(
    restart_execution_path: str | Path,
    freeze_credential: str | Path | Mapping[str, Any],
    *,
    run_instance_id: str,
    allow_failed: bool = False,
    terminal_status: str | None = None,
    expected_selected_parameter_fingerprints: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    """Validate the complete or failure-prefix restart execution table.

    ``terminal_status`` should be supplied when a run failed outside the
    optimizer, especially after all 27 restarts had completed.
    """

    credential, _ = _load_freeze_credential(freeze_credential)
    contract = _freeze_contract(credential)
    rows = _read_restart_rows(Path(restart_execution_path))
    return _validate_restart_rows(
        rows,
        contract,
        run_instance_id=_strict_string(run_instance_id, "expected run instance"),
        allow_failed=allow_failed,
        terminal_status=terminal_status,
        expected_selected_parameter_fingerprints=expected_selected_parameter_fingerprints,
    )


def verify_execution_evidence(
    output_directory: str | Path,
    freeze_credential: str | Path | Mapping[str, Any],
    *,
    expected_experiment_id: str | None = None,
    expected_run_instance_id: str | None = None,
    expected_config_sha256: str | None = None,
    expected_selected_parameter_fingerprints: Mapping[str, str] | None = None,
    allow_failed: bool = False,
) -> dict[str, Any]:
    """Verify lifecycle, telemetry, manifest, and every output-file hash.

    A successful package must contain all 27 frozen restart identities.  A
    failed package may retain zero rows, any canonical completed prefix, or a
    canonical prefix ending in one real failed restart.  It must live in a
    ``.incomplete`` directory and is accepted only when ``allow_failed`` is
    explicit.
    """

    output = Path(output_directory).resolve()
    if not output.is_dir():
        _fail("execution evidence output directory does not exist")
    credential, freeze_digest = _load_freeze_credential(freeze_credential)
    contract = _freeze_contract(credential)
    missing = [
        relative
        for relative in contract["required_artifacts"]
        if not (output / relative).is_file()
    ]
    if missing:
        _fail(f"execution evidence lacks frozen required artifacts: {missing}")
    manifest = _strict_mapping(
        _read_strict_json(output / "run_manifest.json", "run manifest"),
        "run manifest",
    )
    run = _strict_mapping(manifest.get("run"), "manifest run")
    run_instance_id = _strict_string(
        run.get("run_instance_id"), "manifest run instance"
    )
    exit_record = _strict_mapping(manifest.get("exit"), "manifest exit")
    manifest_terminal_status = _strict_string(
        exit_record.get("terminal_status"), "manifest terminal status"
    )
    rows = _read_restart_rows(output / "restart_execution.csv")
    restart_summary = _validate_restart_rows(
        rows,
        contract,
        run_instance_id=run_instance_id,
        allow_failed=allow_failed,
        terminal_status=manifest_terminal_status,
        expected_selected_parameter_fingerprints=expected_selected_parameter_fingerprints,
    )
    if restart_summary["terminal_status"] == "failed" and not output.name.endswith(
        ".incomplete"
    ):
        _fail("failed execution evidence must remain in a .incomplete directory")
    events = _read_events(output / "run_events.jsonl")
    experiment_id = _strict_string(
        run.get("experiment_id"), "manifest experiment identifier"
    )
    event_timing = _validate_events(
        events,
        restart_summary,
        experiment_id=experiment_id,
        run_instance_id=run_instance_id,
    )
    checked_experiment_id, checked_run_instance_id = _validate_manifest(
        manifest,
        output,
        contract,
        freeze_digest,
        restart_summary,
        event_timing,
        expected_experiment_id=expected_experiment_id,
        expected_run_instance_id=expected_run_instance_id,
        expected_config_sha256=expected_config_sha256,
    )
    return {
        "experiment_id": checked_experiment_id,
        "run_instance_id": checked_run_instance_id,
        "terminal_status": restart_summary["terminal_status"],
        "restart_count": restart_summary["restart_count"],
        "completed_restart_count": restart_summary["completed_restart_count"],
        "failed_restart_count": restart_summary["failed_restart_count"],
        "total_objective_calls": restart_summary["total_objective_calls"],
        "total_optimizer_evaluations": restart_summary["total_optimizer_evaluations"],
        "total_optimizer_iterations": restart_summary["total_optimizer_iterations"],
        "artifact_count_excluding_manifest": len(_artifact_hashes(output)),
    }


CommandRunner = Callable[[Sequence[str]], subprocess.CompletedProcess[str]]
PythonInventoryFallback = Callable[[], str]


def _default_command_runner(command: Sequence[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        list(command),
        check=False,
        capture_output=True,
        text=True,
    )


def _default_python_inventory_fallback() -> str:
    """Return a deterministic installed-distribution inventory without pip."""

    candidates: dict[str, set[str]] = {}
    for distribution in importlib_metadata.distributions():
        name = distribution.metadata.get("Name")
        version = distribution.version
        if not isinstance(name, str) or not name.strip():
            continue
        if not isinstance(version, str) or not version.strip():
            continue
        clean_name = name.strip()
        clean_version = version.strip()
        if any(character in clean_name or character in clean_version for character in "\r\n"):
            continue
        normalized_name = re.sub(r"[-_.]+", "-", clean_name).lower()
        candidates.setdefault(normalized_name, set()).add(
            f"{clean_name}=={clean_version}"
        )
    lines = [
        sorted(values, key=lambda value: (value.casefold(), value))[0]
        for _, values in sorted(candidates.items())
    ]
    if not lines:
        raise RuntimeError("importlib.metadata returned no named distributions")
    return "\n".join(lines) + "\n"


def _recoverable_command_record(
    command: Sequence[str],
    completed: Any,
    error: Exception | None,
) -> dict[str, Any]:
    record: dict[str, Any] = {
        "command": [str(part) for part in command],
        "status": "incomplete",
        "capture_method": "unavailable",
        "returncode": None,
        "stdout": "",
        "stderr": "",
        "error_type": "",
        "error_message": "",
        "fallback_error_type": "",
        "fallback_error_message": "",
        "saved_output_sha256": "",
    }
    if error is not None:
        record["error_type"] = type(error).__name__
        record["error_message"] = str(error)
        return record
    if completed is None:
        record["error_type"] = "MissingCommandResult"
        record["error_message"] = "environment command returned no result"
        return record

    try:
        returncode = completed.returncode
        stdout = completed.stdout
        stderr = completed.stderr
    except Exception as result_error:  # noqa: BLE001 - retain malformed runner diagnostics
        record["error_type"] = "InvalidCommandResult"
        record["error_message"] = f"{type(result_error).__name__}: {result_error}"
        return record
    record["returncode"] = returncode if type(returncode) is int else None
    record["stdout"] = stdout if isinstance(stdout, str) else repr(stdout)
    record["stderr"] = stderr if isinstance(stderr, str) else repr(stderr)
    if type(returncode) is not int:
        record["error_type"] = "InvalidCommandReturnCode"
        record["error_message"] = "environment command return code must be an integer"
    elif returncode != 0:
        record["error_type"] = "NonzeroCommandReturnCode"
        record["error_message"] = f"environment command returned status {returncode}"
    elif not isinstance(stdout, str):
        record["error_type"] = "InvalidCommandOutput"
        record["error_message"] = "environment command standard output must be text"
    elif not isinstance(stderr, str):
        record["error_type"] = "InvalidCommandErrorOutput"
        record["error_message"] = "environment command standard error must be text"
    return record


def _environment_failure_diagnostic(record: Mapping[str, Any]) -> str:
    lines = [
        "# environment inventory unavailable",
        "# command=" + json.dumps(record["command"], ensure_ascii=False, separators=(",", ":")),
        f"# returncode={record['returncode']}",
        f"# error_type={record['error_type']}",
        f"# error_message={record['error_message']}",
        f"# fallback_error_type={record['fallback_error_type']}",
        f"# fallback_error_message={record['fallback_error_message']}",
        "# stdout follows",
        str(record["stdout"]),
        "# stderr follows",
        str(record["stderr"]),
    ]
    return "\n".join(lines).rstrip("\n") + "\n"


def capture_environment_inventory(
    command_runner: CommandRunner | None = None,
    *,
    python_fallback: PythonInventoryFallback | None = None,
) -> dict[str, Any]:
    """Capture environment evidence without preventing failure-package creation.

    The legacy :func:`capture_environment_command_outputs` remains the strict
    third-version interface.  This recoverable interface records primary
    command failures, uses a deterministic in-process Python package fallback,
    and always returns text outputs plus a structured capture record.
    """

    runner = _default_command_runner if command_runner is None else command_runner
    fallback = (
        _default_python_inventory_fallback
        if python_fallback is None
        else python_fallback
    )
    commands = {
        "python_packages.txt": (sys.executable, "-m", "pip", "freeze", "--all"),
        "conda_explicit.txt": ("conda", "list", "--explicit"),
    }
    primary_methods = {
        "python_packages.txt": "pip_freeze_all",
        "conda_explicit.txt": "conda_list_explicit",
    }
    outputs: dict[str, str] = {}
    records: dict[str, dict[str, Any]] = {}

    for filename, command in commands.items():
        completed = None
        command_error = None
        try:
            completed = runner(command)
        except Exception as error:  # noqa: BLE001 - evidence must survive command-runner failure
            command_error = error
        record = _recoverable_command_record(command, completed, command_error)
        primary_succeeded = (
            command_error is None
            and record["error_type"] == ""
            and record["returncode"] == 0
        )
        if primary_succeeded:
            record["status"] = "primary_complete"
            record["capture_method"] = primary_methods[filename]
            outputs[filename] = record["stdout"]
        elif filename == "python_packages.txt":
            try:
                fallback_output = fallback()
                if not isinstance(fallback_output, str):
                    raise TypeError("Python inventory fallback output must be text")
                if not fallback_output.strip():
                    raise ValueError("Python inventory fallback output must be nonempty")
            except Exception as error:  # noqa: BLE001 - return diagnostics instead of masking run failure
                record["fallback_error_type"] = type(error).__name__
                record["fallback_error_message"] = str(error)
                outputs[filename] = _environment_failure_diagnostic(record)
            else:
                record["status"] = "fallback_complete"
                record["capture_method"] = "importlib_metadata"
                outputs[filename] = fallback_output
        else:
            outputs[filename] = _environment_failure_diagnostic(record)
        record["saved_output_sha256"] = hashlib.sha256(
            outputs[filename].encode("utf-8")
        ).hexdigest()
        records[filename] = record

    statuses = {record["status"] for record in records.values()}
    if statuses == {"primary_complete"}:
        overall_status = "primary_complete"
    elif statuses <= {"primary_complete", "fallback_complete"}:
        overall_status = "fallback_complete"
    else:
        overall_status = "incomplete"
    return {
        "outputs": outputs,
        "capture_record": {
            "schema_version": 1,
            "overall_status": overall_status,
            "commands": records,
        },
    }


def capture_environment_command_outputs(
    command_runner: CommandRunner | None = None,
) -> dict[str, str]:
    """Capture local package inventories through an injectable command runner.

    Both commands are local, read-only inventory operations.  Injection keeps
    unit tests independent of the host Python and conda installations.
    """

    runner = _default_command_runner if command_runner is None else command_runner
    commands = {
        "python_packages.txt": (sys.executable, "-m", "pip", "freeze", "--all"),
        "conda_explicit.txt": ("conda", "list", "--explicit"),
    }
    result: dict[str, str] = {}
    for filename, command in commands.items():
        try:
            completed = runner(command)
        except (OSError, subprocess.SubprocessError) as error:
            raise ExecutionEvidenceError(
                f"environment command failed before completion: {command[0]}"
            ) from error
        if type(completed.returncode) is not int or completed.returncode != 0:
            _fail(
                f"environment command returned nonzero status for {filename}: "
                f"{completed.returncode}"
            )
        if not isinstance(completed.stdout, str):
            _fail(f"environment command output for {filename} must be text")
        result[filename] = completed.stdout
    return result


__all__ = [
    "ExecutionEvidenceError",
    "MANIFEST_SELF_HASH_POLICY",
    "PROHIBITED_INTERPRETATION_PERMISSIONS",
    "REQUIRED_V03_ARTIFACTS",
    "RESTART_EXECUTION_COLUMNS",
    "VERIFIER_IDENTITY",
    "capture_environment_command_outputs",
    "capture_environment_inventory",
    "validate_restart_execution",
    "verify_execution_evidence",
]
