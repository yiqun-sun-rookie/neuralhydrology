"""Run the frozen balanced-replay verifier with one disclosed audit repair.

The registered version-01 verifier compares a sorted sequence-assignment list
with an unsorted expected list.  That makes every valid 36-basin task table
fail before any raw evidence is read.  This post-execution audit leaves every
registered file unchanged, replaces only that logically impossible comparison
in memory, and then runs the complete frozen independent recomputation.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

from camels_switch_confirmation import verify_joint_balanced_replay as frozen
from camels_switch_confirmation.joint_balanced_replay import (
    CONFIG_PATH,
    FORMAL_SEEDS,
    N_CELLS,
    load_registered_config,
    sha256_file,
)


REPO_ROOT = Path(__file__).resolve().parents[2]
REGISTERED_VERIFIER_PATH = Path(
    "src/camels_switch_confirmation/verify_joint_balanced_replay.py"
)
ORIGINAL_FAILURE = (
    "AssertionError: seed 8 no longer assigns six basins per sequence"
)


def corrected_verify_registered_task_table(
    repo_root: Path, config: dict
) -> tuple[list[str], dict[str, int]]:
    """Recreate the registered table check with the expected counts sorted."""

    path = Path(repo_root) / config["input_paths"]["formal_task_table"]
    rows = frozen._read_csv_records(path)
    if len(rows) != frozen.EXPECTED_TRUTH_BUNDLES:
        raise AssertionError("registered task table does not contain 216 rows")
    basins = sorted({str(row["basin_id"]).zfill(8) for row in rows})
    if len(basins) != frozen.EXPECTED_BASINS:
        raise AssertionError("registered task table does not contain 36 basins")
    ranks = {basin: rank for rank, basin in enumerate(basins)}
    expected_rows = []
    for basin, rank in ranks.items():
        basin_sequences = []
        for seed_index, seed in enumerate(FORMAL_SEEDS):
            sequence_index = (rank + seed_index) % N_CELLS
            cells = frozen._williams_sequence(sequence_index)
            basin_sequences.append(cells)
            expected_rows.append({
                "basin_id": basin,
                "basin_rank": str(rank),
                "seed": str(seed),
                "seed_index": str(seed_index),
                "sequence_index": str(sequence_index),
                "sequence_cells": "|".join(str(cell) for cell in cells),
                "sequence_pairs": "|".join(
                    f"{source}>{destination}"
                    for source, destination in zip(cells, cells[1:])
                ),
            })
        frozen.verify_basin_edge_coverage(basin_sequences)
    if rows != expected_rows:
        raise AssertionError("registered task table Williams mapping changed")

    required_counts = Counter({sequence: 6 for sequence in range(N_CELLS)})
    for seed_index, seed in enumerate(FORMAL_SEEDS):
        assignments = [
            (rank + seed_index) % N_CELLS
            for rank in range(frozen.EXPECTED_BASINS)
        ]
        if Counter(assignments) != required_counts:
            raise AssertionError(
                f"seed {seed} no longer assigns six basins per sequence"
            )
    return basins, ranks


def _registered_verifier_sha256(config: dict) -> str:
    matches = [
        record["sha256"]
        for record in config["registered_implementation_hashes"].values()
        if Path(record["path"]) == REGISTERED_VERIFIER_PATH
    ]
    if len(matches) != 1:
        raise AssertionError("registered verifier hash is not unique")
    actual = sha256_file(REPO_ROOT / REGISTERED_VERIFIER_PATH)
    if actual != matches[0]:
        raise AssertionError("registered verifier changed after formal execution")
    return actual


def verify_formal_evidence_with_disclosed_repair(output_root: Path) -> dict:
    """Execute every frozen check after repairing only the count comparison."""

    config = load_registered_config(REPO_ROOT, verify_hashes=True)
    registered_verifier_sha256 = _registered_verifier_sha256(config)
    original_table_verifier = frozen._verify_registered_task_table
    frozen._verify_registered_task_table = corrected_verify_registered_task_table
    try:
        payload = frozen.verify_formal_evidence(
            Path(output_root), repo_root=REPO_ROOT, write=False
        )
    finally:
        frozen._verify_registered_task_table = original_table_verifier

    payload["verification_execution"] = {
        "classification": "post_execution_verifier_only_repair",
        "original_failure": ORIGINAL_FAILURE,
        "registered_verifier_path": REGISTERED_VERIFIER_PATH.as_posix(),
        "registered_verifier_sha256": registered_verifier_sha256,
        "repair_path": Path(__file__).resolve().relative_to(REPO_ROOT).as_posix(),
        "repair_sha256": sha256_file(Path(__file__).resolve()),
        "runner_or_scientific_metric_code_changed": False,
        "repair_scope": (
            "replace the unsorted expected sequence multiplicity comparison "
            "with an exact Counter equality check"
        ),
        "sequence_count_per_seed": {
            str(seed): {str(sequence): 6 for sequence in range(N_CELLS)}
            for seed in FORMAL_SEEDS
        },
    }
    output_path = Path(output_root) / config["artifact_paths"]["independent_verification"]
    frozen._write_json_new(output_path, payload)
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--route", choices=("local", "hpc"), default="local")
    parser.add_argument("--output-root", type=Path)
    arguments = parser.parse_args()
    config = load_registered_config(REPO_ROOT, verify_hashes=True)
    root = (
        arguments.output_root
        if arguments.output_root is not None
        else REPO_ROOT / config["output_roots"][arguments.route]
    )
    payload = verify_formal_evidence_with_disclosed_repair(root)
    print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
