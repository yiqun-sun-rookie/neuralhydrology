"""Summarize the registered balanced independent-replay experiment.

The scientific unit is a basin.  Daily posterior values are first averaged
within an independently reset event, five incoming events are then averaged
within each destination cell, and axis levels are finally averaged across
their destination cells.  Population uncertainty resamples basin identifiers
only.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable, Mapping

import numpy as np
import pandas as pd
from scipy.stats import beta

from camels_switch_confirmation.joint_balanced_replay import (
    FORMAL_SEEDS,
    load_registered_config,
    sha256_file,
)
from camels_switch_confirmation.run_joint_balanced_replay import (
    ARM_MODES,
    CONFIG_PATH,
    KNOWLEDGE_MODES,
    REPO_ROOT,
    TaskIdentity,
    admitted_basins,
    build_task_table,
    task_output_path,
    truth_bundle_path,
)


REPORT_WINDOWS = {
    "days_001_007": (0, 7),
    "days_008_030": (7, 30),
    "days_031_090": (30, 90),
    "days_091_180": (90, 180),
}
PRIMARY_WINDOW = "days_091_180"
BOOTSTRAP_BASE_SEED = 20260821813
BOOTSTRAP_REPLICATES = 20_000
ALGORITHM_CODES = {"C": 0, "P": 1}
COMPARISON_TYPE_CODES = {
    "joint_unknown": 0,
    "param_known": 1,
    "noise_known": 2,
    "paired": 3,
}
AXIS_CODES = {"parameter": 0, "process_noise": 1, "joint_cell": 2}
METRIC_CODES = {
    "true_probability": 0,
    "argmax_accuracy": 1,
    "paired_probability_loss": 2,
}
AXIS_LEVEL_COUNT = {"parameter": 2, "process_noise": 3, "joint_cell": 6}
EXPECTED_CANDIDATES = {"joint_unknown": 6, "param_known": 3, "noise_known": 2}


def axis_marginals(
    probabilities,
    candidate_param_indices,
    candidate_noise_indices,
) -> tuple[np.ndarray, np.ndarray]:
    """Return daily two-level parameter and three-level noise marginals."""

    values = np.asarray(probabilities, dtype=np.float64)
    parameter_coordinates = np.asarray(candidate_param_indices, dtype=np.int64)
    noise_coordinates = np.asarray(candidate_noise_indices, dtype=np.int64)
    if values.ndim != 2:
        raise ValueError("probabilities must have shape (day, candidate)")
    if parameter_coordinates.shape != values.shape or noise_coordinates.shape != values.shape:
        raise ValueError("candidate coordinate arrays must match probabilities")
    if not np.all(np.isfinite(values)) or np.any(values < 0.0):
        raise ValueError("candidate probabilities must be finite and nonnegative")
    if not np.allclose(values.sum(axis=1), 1.0, rtol=0.0, atol=1e-12):
        raise ValueError("candidate probabilities do not sum to one")
    if np.any((parameter_coordinates < 0) | (parameter_coordinates >= 2)):
        raise ValueError("parameter candidate coordinate is outside 0 through 1")
    if np.any((noise_coordinates < 0) | (noise_coordinates >= 3)):
        raise ValueError("process-noise candidate coordinate is outside 0 through 2")

    parameter = np.zeros((len(values), 2), dtype=np.float64)
    process_noise = np.zeros((len(values), 3), dtype=np.float64)
    for level in range(2):
        parameter[:, level] = np.sum(
            np.where(parameter_coordinates == level, values, 0.0), axis=1
        )
    for level in range(3):
        process_noise[:, level] = np.sum(
            np.where(noise_coordinates == level, values, 0.0), axis=1
        )
    if not np.allclose(parameter.sum(axis=1), 1.0, rtol=0.0, atol=1e-12):
        raise ValueError("parameter marginals do not sum to one")
    if not np.allclose(process_noise.sum(axis=1), 1.0, rtol=0.0, atol=1e-12):
        raise ValueError("process-noise marginals do not sum to one")
    return parameter, process_noise


def _scalar(arrays: Mapping, name: str, supplied):
    if supplied is not None:
        return supplied
    if name not in arrays:
        raise ValueError(f"missing task identity: {name}")
    value = np.asarray(arrays[name])
    if value.ndim != 0:
        raise ValueError(f"task identity must be scalar: {name}")
    return value.item()


def _cell_pair(cell: int) -> tuple[int, int]:
    value = int(cell)
    if value not in range(6):
        raise ValueError("cell index must be 0 through 5")
    return divmod(value, 3)


def _registered_pairs(knowledge_mode: str, destination_cell: int) -> tuple[tuple[int, int], ...]:
    destination_parameter, destination_noise = _cell_pair(destination_cell)
    if knowledge_mode == "joint_unknown":
        return tuple((parameter, noise) for parameter in range(2) for noise in range(3))
    if knowledge_mode == "param_known":
        return tuple((destination_parameter, noise) for noise in range(3))
    if knowledge_mode == "noise_known":
        return tuple((parameter, destination_noise) for parameter in range(2))
    raise ValueError(f"unknown knowledge mode: {knowledge_mode}")


def _transition_type(source_cell: int, destination_cell: int) -> str:
    source_parameter, source_noise = _cell_pair(source_cell)
    destination_parameter, destination_noise = _cell_pair(destination_cell)
    parameter_changed = source_parameter != destination_parameter
    noise_changed = source_noise != destination_noise
    if parameter_changed and noise_changed:
        return "joint"
    if parameter_changed:
        return "parameter_only"
    if noise_changed:
        return "noise_only"
    raise ValueError("source and destination cells are identical")


def _event_offsets(arrays: Mapping, event_count: int, day_count: int) -> np.ndarray:
    offsets = np.asarray(arrays.get("event_offsets", np.arange(1, day_count + 1)), dtype=np.int64)
    if offsets.ndim == 1:
        if offsets.shape != (day_count,):
            raise ValueError("event offsets have the wrong day count")
        offsets = np.tile(offsets, (event_count, 1))
    if offsets.shape != (event_count, day_count):
        raise ValueError("event offsets must be one day vector or one vector per event")
    expected = np.arange(1, day_count + 1, dtype=np.int64)
    if any(not np.array_equal(np.sort(row), expected) for row in offsets):
        raise ValueError("each event must contain every offset exactly once")
    return offsets


def _validate_task_arrays(arrays: Mapping, knowledge_mode: str) -> dict:
    probabilities = np.asarray(arrays["probabilities"], dtype=np.float64)
    if probabilities.ndim != 3:
        raise ValueError("probabilities must have shape (event, day, candidate)")
    event_count, day_count, candidate_count = probabilities.shape
    if (event_count, day_count) != (5, 180):
        raise ValueError("formal task arrays must contain five 180-day events")
    expected_candidates = EXPECTED_CANDIDATES.get(str(knowledge_mode))
    if candidate_count != expected_candidates:
        raise ValueError("candidate count differs from the registered knowledge mode")
    parameter_coordinates = np.asarray(arrays["candidate_param_indices"], dtype=np.int64)
    noise_coordinates = np.asarray(arrays["candidate_noise_indices"], dtype=np.int64)
    if parameter_coordinates.shape != probabilities.shape or noise_coordinates.shape != probabilities.shape:
        raise ValueError("candidate coordinates do not match probabilities")
    source_cells = np.asarray(arrays["source_cell_indices"], dtype=np.int64)
    destination_cells = np.asarray(arrays["destination_cell_indices"], dtype=np.int64)
    sequence_positions = np.asarray(arrays["sequence_positions"], dtype=np.int64)
    transition_types = np.asarray(arrays["transition_types"]).astype(str)
    switch_days = np.asarray(arrays["switch_days"], dtype=np.int64)
    for values, label in (
        (source_cells, "source cells"),
        (destination_cells, "destination cells"),
        (sequence_positions, "sequence positions"),
        (transition_types, "transition types"),
        (switch_days, "switch days"),
    ):
        if values.shape != (event_count,):
            raise ValueError(f"{label} must contain one value per event")
    if set(int(value) for value in sequence_positions) != set(range(1, 6)):
        raise ValueError("a task must contain sequence positions 1 through 5")
    if len(set(zip(source_cells.tolist(), destination_cells.tolist()))) != event_count:
        raise ValueError("task contains a duplicate directed event")
    offsets = _event_offsets(arrays, event_count, day_count)
    truth_parameter = np.asarray(arrays["truth_param_indices"], dtype=np.int64)
    truth_noise = np.asarray(arrays["truth_noise_indices"], dtype=np.int64)
    truth_cell = np.asarray(arrays["truth_cell_indices"], dtype=np.int64)
    for values, label in (
        (truth_parameter, "truth parameter labels"),
        (truth_noise, "truth process-noise labels"),
        (truth_cell, "truth cell labels"),
    ):
        if values.shape != (event_count, day_count):
            raise ValueError(f"{label} do not match event-day shape")
    combined_states = np.asarray(arrays["combined_states"], dtype=np.float64)
    truth_states = np.asarray(arrays["truth_post_states"], dtype=np.float64)
    if combined_states.shape != (event_count, day_count, 15) or truth_states.shape != combined_states.shape:
        raise ValueError("state arrays must have shape (5, 180, 15)")
    if not np.all(np.isfinite(combined_states)) or not np.all(np.isfinite(truth_states)):
        raise ValueError("state arrays contain non-finite values")

    for event_index, (source_cell, destination_cell) in enumerate(zip(source_cells, destination_cells)):
        source_cell = int(source_cell)
        destination_cell = int(destination_cell)
        destination_parameter, destination_noise = _cell_pair(destination_cell)
        if source_cell == destination_cell:
            raise ValueError("event does not change cell")
        if transition_types[event_index] != _transition_type(source_cell, destination_cell):
            raise ValueError("saved transition type disagrees with source and destination")
        if not np.all(truth_parameter[event_index] == destination_parameter):
            raise ValueError("truth parameter label disagrees with destination cell")
        if not np.all(truth_noise[event_index] == destination_noise):
            raise ValueError("truth process-noise label disagrees with destination cell")
        if not np.all(truth_cell[event_index] == destination_cell):
            raise ValueError("truth cell label disagrees with destination cell")
        expected_pairs = _registered_pairs(str(knowledge_mode), destination_cell)
        observed_pairs = np.stack(
            [parameter_coordinates[event_index], noise_coordinates[event_index]], axis=2
        )
        expected = np.tile(np.asarray(expected_pairs, dtype=np.int64), (day_count, 1, 1))
        if not np.array_equal(observed_pairs, expected):
            raise ValueError("candidate order or coordinates differ from registration")
        axis_marginals(
            probabilities[event_index],
            parameter_coordinates[event_index],
            noise_coordinates[event_index],
        )
    return {
        "probabilities": probabilities,
        "candidate_parameter": parameter_coordinates,
        "candidate_noise": noise_coordinates,
        "source_cells": source_cells,
        "destination_cells": destination_cells,
        "sequence_positions": sequence_positions,
        "transition_types": transition_types,
        "switch_days": switch_days,
        "offsets": offsets,
        "combined_states": combined_states,
        "truth_states": truth_states,
    }


def _state_window_metrics(estimated: np.ndarray, truth: np.ndarray) -> dict[str, float]:
    if estimated.shape != truth.shape or estimated.ndim != 2 or estimated.shape[1] != 15:
        raise ValueError("state metric inputs must be equal day-by-15 arrays")
    error = estimated - truth
    rmse = np.sqrt(np.mean(error**2, axis=0))
    median_absolute_error = np.median(np.abs(error), axis=0)
    scales = np.maximum(np.std(truth, axis=0, ddof=0), 1.0)
    normalized = rmse / scales
    row: dict[str, float] = {
        "state_mean_normalized_rmse": float(np.mean(normalized))
    }
    for index in range(15):
        suffix = f"{index:02d}"
        row[f"state_rmse_{suffix}"] = float(rmse[index])
        row[f"state_median_absolute_error_{suffix}"] = float(median_absolute_error[index])
        row[f"state_normalization_scale_{suffix}"] = float(scales[index])
        row[f"state_normalized_rmse_{suffix}"] = float(normalized[index])
    return row


def event_metric_rows(
    arrays: Mapping,
    basin_id=None,
    seed=None,
    algorithm=None,
    knowledge_mode=None,
) -> list[dict]:
    """Compute all four nonoverlapping event windows for one raw task."""

    basin = str(_scalar(arrays, "basin_id", basin_id)).zfill(8)
    seed_value = int(_scalar(arrays, "seed", seed))
    algorithm_value = str(_scalar(arrays, "arm_id", algorithm))
    mode = str(_scalar(arrays, "knowledge_mode", knowledge_mode))
    if algorithm_value not in ALGORITHM_CODES:
        raise ValueError("unknown interaction algorithm")
    validated = _validate_task_arrays(arrays, mode)
    rows: list[dict] = []
    for event_index in range(5):
        order = np.argsort(validated["offsets"][event_index], kind="stable")
        offsets = validated["offsets"][event_index, order]
        probabilities = validated["probabilities"][event_index, order]
        parameter_coordinates = validated["candidate_parameter"][event_index, order]
        noise_coordinates = validated["candidate_noise"][event_index, order]
        parameter, process_noise = axis_marginals(
            probabilities, parameter_coordinates, noise_coordinates
        )
        destination_cell = int(validated["destination_cells"][event_index])
        destination_parameter, destination_noise = _cell_pair(destination_cell)
        true_candidate_mask = (
            (parameter_coordinates == destination_parameter)
            & (noise_coordinates == destination_noise)
        )
        if not np.all(true_candidate_mask.sum(axis=1) == 1):
            raise ValueError("each day must contain exactly one true joint candidate")
        true_cell_probability = np.sum(
            np.where(true_candidate_mask, probabilities, 0.0), axis=1
        )
        parameter_winner = np.argmax(parameter, axis=1)
        noise_winner = np.argmax(process_noise, axis=1)
        candidate_winner = np.argmax(probabilities, axis=1)
        day_indices = np.arange(len(probabilities))
        cell_winner_correct = (
            (parameter_coordinates[day_indices, candidate_winner] == destination_parameter)
            & (noise_coordinates[day_indices, candidate_winner] == destination_noise)
        )
        estimated_states = validated["combined_states"][event_index, order]
        truth_states = validated["truth_states"][event_index, order]
        source_cell = int(validated["source_cells"][event_index])
        source_parameter, source_noise = _cell_pair(source_cell)
        for window, (start, stop) in REPORT_WINDOWS.items():
            selected = np.flatnonzero((offsets > start) & (offsets <= stop))
            if len(selected) != stop - start:
                raise ValueError(f"window {window} does not contain its registered days")
            rows.append({
                "basin_id": basin,
                "seed": seed_value,
                "algorithm": algorithm_value,
                "knowledge_mode": mode,
                "event_index": int(event_index),
                "source_cell": source_cell,
                "destination_cell": destination_cell,
                "source_parameter": source_parameter,
                "source_process_noise": source_noise,
                "destination_parameter": destination_parameter,
                "destination_process_noise": destination_noise,
                "sequence_position": int(validated["sequence_positions"][event_index]),
                "transition_type": str(validated["transition_types"][event_index]),
                "switch_day": int(validated["switch_days"][event_index]),
                "window": window,
                "window_start_day": start + 1,
                "window_end_day": stop,
                "day_count": int(len(selected)),
                "parameter_true_probability": float(
                    np.mean(parameter[selected, destination_parameter])
                ),
                "parameter_argmax_accuracy": float(
                    np.mean(parameter_winner[selected] == destination_parameter)
                ),
                "process_noise_true_probability": float(
                    np.mean(process_noise[selected, destination_noise])
                ),
                "process_noise_argmax_accuracy": float(
                    np.mean(noise_winner[selected] == destination_noise)
                ),
                "joint_cell_true_probability": float(
                    np.mean(true_cell_probability[selected])
                ),
                "joint_cell_argmax_accuracy": float(
                    np.mean(cell_winner_correct[selected])
                ),
                **_state_window_metrics(
                    estimated_states[selected], truth_states[selected]
                ),
            })
    return rows


def _frame(rows: Iterable[dict] | pd.DataFrame) -> pd.DataFrame:
    return rows.copy() if isinstance(rows, pd.DataFrame) else pd.DataFrame(list(rows))


def _require_columns(frame: pd.DataFrame, columns: Iterable[str]) -> None:
    missing = sorted(set(columns) - set(frame.columns))
    if missing:
        raise ValueError(f"metric rows are missing columns: {missing}")


def _validate_directed_cell_block(frame: pd.DataFrame, identity: str) -> pd.DataFrame:
    ordered = frame.sort_values(
        ["destination_cell", "source_cell", "seed", "event_index"], kind="stable"
    ).reset_index(drop=True)
    if len(ordered) != 30:
        raise ValueError(f"{identity} must contain exactly 30 directed events")
    directed = list(zip(ordered["source_cell"].astype(int), ordered["destination_cell"].astype(int)))
    expected = {(source, destination) for source in range(6) for destination in range(6) if source != destination}
    if len(set(directed)) != 30 or set(directed) != expected:
        raise ValueError(f"{identity} contains a duplicate or missing directed event")
    counts = ordered.groupby("destination_cell", sort=True).size()
    if set(counts.index.astype(int)) != set(range(6)) or set(counts.astype(int)) != {5}:
        raise ValueError(f"{identity} must contain five incoming events per target cell")
    return ordered


def basin_metric_rows(event_rows: Iterable[dict] | pd.DataFrame) -> list[dict]:
    """Aggregate primary event metrics into registered basin-level scores."""

    frame = _frame(event_rows)
    required = (
        "basin_id", "seed", "algorithm", "knowledge_mode", "event_index",
        "source_cell", "destination_cell", "window",
        "parameter_true_probability", "parameter_argmax_accuracy",
        "process_noise_true_probability", "process_noise_argmax_accuracy",
        "joint_cell_true_probability", "joint_cell_argmax_accuracy",
        "state_mean_normalized_rmse",
    )
    _require_columns(frame, required)
    primary = frame[frame["window"] == PRIMARY_WINDOW].copy()
    if primary.empty:
        raise ValueError("primary days 91 through 180 are missing")
    results: list[dict] = []
    group_columns = ["basin_id", "algorithm", "knowledge_mode"]
    for identity, group in primary.groupby(group_columns, sort=True, dropna=False):
        basin, algorithm, knowledge_mode = identity
        ordered = _validate_directed_cell_block(group, "/".join(map(str, identity)))
        cell_rows: list[dict] = []
        for destination_cell, incoming in ordered.groupby("destination_cell", sort=True):
            incoming = incoming.sort_values(
                ["source_cell", "seed", "event_index"], kind="stable"
            )
            destination_cell = int(destination_cell)
            parameter_level, noise_level = _cell_pair(destination_cell)
            cell_rows.append({
                "destination_cell": destination_cell,
                "parameter_level": parameter_level,
                "noise_level": noise_level,
                "parameter_true_probability": float(
                    np.mean(incoming["parameter_true_probability"].to_numpy(dtype=np.float64))
                ),
                "parameter_argmax_accuracy": float(
                    np.mean(incoming["parameter_argmax_accuracy"].to_numpy(dtype=np.float64))
                ),
                "process_noise_true_probability": float(
                    np.mean(incoming["process_noise_true_probability"].to_numpy(dtype=np.float64))
                ),
                "process_noise_argmax_accuracy": float(
                    np.mean(incoming["process_noise_argmax_accuracy"].to_numpy(dtype=np.float64))
                ),
                "joint_cell_true_probability": float(
                    np.mean(incoming["joint_cell_true_probability"].to_numpy(dtype=np.float64))
                ),
                "joint_cell_argmax_accuracy": float(
                    np.mean(incoming["joint_cell_argmax_accuracy"].to_numpy(dtype=np.float64))
                ),
                "state_mean_normalized_rmse": float(
                    np.mean(incoming["state_mean_normalized_rmse"].to_numpy(dtype=np.float64))
                ),
                "event_count": int(len(incoming)),
            })
        cells = pd.DataFrame(cell_rows).sort_values("destination_cell", kind="stable")
        if len(cells) != 6 or set(cells["event_count"]) != {5}:
            raise ValueError("basin cell aggregation did not preserve five incoming events")
        base = {
            "basin_id": str(basin).zfill(8),
            "algorithm": str(algorithm),
            "knowledge_mode": str(knowledge_mode),
        }
        for cell in cells.itertuples(index=False):
            results.append({
                **base,
                "axis": "joint_cell",
                "level": int(cell.destination_cell),
                "true_probability": float(cell.joint_cell_true_probability),
                "argmax_accuracy": float(cell.joint_cell_argmax_accuracy),
                "state_mean_normalized_rmse": float(cell.state_mean_normalized_rmse),
                "event_count": int(cell.event_count),
                "target_cell_count": 1,
            })
        for axis, level_column, probability_column, accuracy_column, level_count, cell_count in (
            ("parameter", "parameter_level", "parameter_true_probability", "parameter_argmax_accuracy", 2, 3),
            ("process_noise", "noise_level", "process_noise_true_probability", "process_noise_argmax_accuracy", 3, 2),
        ):
            for level in range(level_count):
                selected = cells[cells[level_column] == level].sort_values(
                    "destination_cell", kind="stable"
                )
                if len(selected) != cell_count:
                    raise ValueError(f"{axis} level does not contain its registered target cells")
                results.append({
                    **base,
                    "axis": axis,
                    "level": level,
                    "true_probability": float(np.mean(selected[probability_column].to_numpy(dtype=np.float64))),
                    "argmax_accuracy": float(np.mean(selected[accuracy_column].to_numpy(dtype=np.float64))),
                    "state_mean_normalized_rmse": float(
                        np.mean(
                            selected["state_mean_normalized_rmse"].to_numpy(
                                dtype=np.float64
                            )
                        )
                    ),
                    "event_count": int(selected["event_count"].sum()),
                    "target_cell_count": int(len(selected)),
                })
    axis_order = {"parameter": 0, "process_noise": 1, "joint_cell": 2}
    results.sort(key=lambda row: (
        row["basin_id"], row["algorithm"], row["knowledge_mode"],
        axis_order[row["axis"]], row["level"],
    ))
    return results


def _daily_axis_frame(
    arrays: Mapping,
    *,
    axis: str,
    basin_id: str,
    seed: int,
    algorithm: str,
    knowledge_mode: str,
) -> pd.DataFrame:
    validated = _validate_task_arrays(arrays, knowledge_mode)
    if axis not in {"parameter", "process_noise"}:
        raise ValueError("paired axis must be parameter or process_noise")
    rows: list[dict] = []
    for event_index in range(5):
        order = np.argsort(validated["offsets"][event_index], kind="stable")
        offsets = validated["offsets"][event_index, order]
        selected = np.flatnonzero((offsets > 90) & (offsets <= 180))
        probabilities = validated["probabilities"][event_index, order]
        parameter, noise = axis_marginals(
            probabilities,
            validated["candidate_parameter"][event_index, order],
            validated["candidate_noise"][event_index, order],
        )
        destination_cell = int(validated["destination_cells"][event_index])
        destination_parameter, destination_noise = _cell_pair(destination_cell)
        level = destination_parameter if axis == "parameter" else destination_noise
        marginal = parameter if axis == "parameter" else noise
        for day in selected:
            rows.append({
                "basin_id": str(basin_id).zfill(8),
                "seed": int(seed),
                "algorithm": str(algorithm),
                "source_cell": int(validated["source_cells"][event_index]),
                "destination_cell": destination_cell,
                "event_offset": int(offsets[day]),
                "axis": axis,
                "level": int(level),
                "event_index": int(event_index),
                "sequence_position": int(validated["sequence_positions"][event_index]),
                "transition_type": str(validated["transition_types"][event_index]),
                "true_probability": float(marginal[day, level]),
                "knowledge_mode": knowledge_mode,
            })
    frame = pd.DataFrame(rows)
    keys = [
        "basin_id", "seed", "algorithm", "source_cell", "destination_cell",
        "event_offset", "axis",
    ]
    if len(frame) != 450 or frame.duplicated(keys).any():
        raise ValueError("paired daily keys are incomplete or duplicated")
    return frame.sort_values(keys, kind="stable").reset_index(drop=True)


def paired_axis_rows(
    joint_arrays: Mapping,
    reference_arrays: Mapping,
    *,
    axis: str,
    basin_id=None,
    seed=None,
    algorithm=None,
) -> list[dict]:
    """Pair daily joint and known-axis probabilities before any aggregation."""

    basin = str(_scalar(joint_arrays, "basin_id", basin_id)).zfill(8)
    seed_value = int(_scalar(joint_arrays, "seed", seed))
    algorithm_value = str(_scalar(joint_arrays, "arm_id", algorithm))
    reference_mode = "noise_known" if axis == "parameter" else "param_known"
    for arrays, expected_mode in (
        (joint_arrays, "joint_unknown"),
        (reference_arrays, reference_mode),
    ):
        expected_identity = {
            "basin_id": basin,
            "seed": seed_value,
            "arm_id": algorithm_value,
            "knowledge_mode": expected_mode,
        }
        for name, expected in expected_identity.items():
            if name not in arrays:
                continue
            observed = np.asarray(arrays[name])
            if observed.ndim != 0:
                raise ValueError(f"paired task identity must be scalar: {name}")
            value = observed.item()
            if name == "basin_id":
                value = str(value).zfill(8)
            elif name == "seed":
                value = int(value)
            else:
                value = str(value)
            if value != expected:
                raise ValueError(f"paired task identity disagrees: {name}")
    joint = _daily_axis_frame(
        joint_arrays,
        axis=axis,
        basin_id=basin,
        seed=seed_value,
        algorithm=algorithm_value,
        knowledge_mode="joint_unknown",
    )
    reference = _daily_axis_frame(
        reference_arrays,
        axis=axis,
        basin_id=basin,
        seed=seed_value,
        algorithm=algorithm_value,
        knowledge_mode=reference_mode,
    )
    keys = [
        "basin_id", "seed", "algorithm", "source_cell", "destination_cell",
        "event_offset", "axis",
    ]
    right = reference[keys + ["level", "true_probability"]].rename(columns={
        "level": "reference_level",
        "true_probability": "reference_true_probability",
    })
    merged = joint.merge(right, on=keys, how="outer", validate="one_to_one", indicator=True)
    if len(merged) != 450 or set(merged["_merge"]) != {"both"}:
        raise ValueError("joint and known-axis daily keys do not match exactly")
    if not np.array_equal(
        merged["level"].to_numpy(dtype=np.int64),
        merged["reference_level"].to_numpy(dtype=np.int64),
    ):
        raise ValueError("paired daily truth levels disagree")
    merged["paired_probability_loss"] = (
        merged["true_probability"] - merged["reference_true_probability"]
    )
    rows: list[dict] = []
    event_keys = [
        "basin_id", "seed", "algorithm", "axis", "level",
        "source_cell", "destination_cell",
    ]
    for identity, event in merged.groupby(event_keys, sort=True, dropna=False):
        event = event.sort_values("event_offset", kind="stable")
        if len(event) != 90 or not np.array_equal(
            event["event_offset"].to_numpy(dtype=np.int64), np.arange(91, 181)
        ):
            raise ValueError("paired event does not contain exact primary days")
        first = event.iloc[0]
        rows.append({
            **dict(zip(event_keys, identity)),
            "event_index": int(first["event_index"]),
            "sequence_position": int(first["sequence_position"]),
            "transition_type": str(first["transition_type"]),
            "reference_knowledge_mode": reference_mode,
            "day_count": int(len(event)),
            "paired_probability_loss": float(
                np.mean(event["paired_probability_loss"].to_numpy(dtype=np.float64))
            ),
        })
    if len(rows) != 5:
        raise ValueError("paired task must contain exactly five events")
    return rows


def aggregate_paired_basin_rows(paired_event_rows: Iterable[dict] | pd.DataFrame) -> list[dict]:
    """Aggregate paired daily-first event losses to basin-axis-level scores."""

    frame = _frame(paired_event_rows)
    required = (
        "basin_id", "seed", "algorithm", "axis", "level", "source_cell",
        "destination_cell", "paired_probability_loss", "reference_knowledge_mode",
        "day_count",
    )
    _require_columns(frame, required)
    if not np.all(frame["day_count"].astype(int) == 90):
        raise ValueError("paired event rows must use days 91 through 180")
    if "event_index" not in frame:
        frame["event_index"] = 0
    results: list[dict] = []
    for identity, group in frame.groupby(["basin_id", "algorithm", "axis"], sort=True, dropna=False):
        basin, algorithm, axis = identity
        if axis not in {"parameter", "process_noise"}:
            raise ValueError("paired rows contain an unregistered axis")
        ordered = _validate_directed_cell_block(group, "/".join(map(str, identity)))
        reference_modes = set(ordered["reference_knowledge_mode"].astype(str))
        expected_reference = "noise_known" if axis == "parameter" else "param_known"
        if reference_modes != {expected_reference}:
            raise ValueError("paired rows use the wrong known-axis reference")
        cell_scores = []
        for destination_cell, incoming in ordered.groupby("destination_cell", sort=True):
            incoming = incoming.sort_values(["source_cell", "seed"], kind="stable")
            cell_scores.append({
                "destination_cell": int(destination_cell),
                "level": _cell_pair(int(destination_cell))[0 if axis == "parameter" else 1],
                "paired_probability_loss": float(
                    np.mean(incoming["paired_probability_loss"].to_numpy(dtype=np.float64))
                ),
                "event_count": int(len(incoming)),
            })
        cells = pd.DataFrame(cell_scores).sort_values("destination_cell", kind="stable")
        expected_cells = 3 if axis == "parameter" else 2
        for level in range(AXIS_LEVEL_COUNT[axis]):
            selected = cells[cells["level"] == level].sort_values("destination_cell", kind="stable")
            if len(selected) != expected_cells or set(selected["event_count"]) != {5}:
                raise ValueError("paired axis level has the wrong cell or incoming-event count")
            results.append({
                "basin_id": str(basin).zfill(8),
                "algorithm": str(algorithm),
                "axis": str(axis),
                "level": int(level),
                "reference_knowledge_mode": expected_reference,
                "paired_probability_loss": float(
                    np.mean(selected["paired_probability_loss"].to_numpy(dtype=np.float64))
                ),
                "event_count": int(selected["event_count"].sum()),
                "target_cell_count": int(len(selected)),
            })
    results.sort(key=lambda row: (
        row["basin_id"], row["algorithm"], AXIS_CODES[row["axis"]], row["level"]
    ))
    return results


def bootstrap_substream_seed(
    algorithm: str,
    comparison_type: str,
    axis: str,
    level: int,
    metric: str,
    *,
    base_seed: int = BOOTSTRAP_BASE_SEED,
) -> np.random.SeedSequence:
    """Construct the preregistered traversal-order-independent substream."""

    try:
        entropy = [
            int(base_seed),
            ALGORITHM_CODES[str(algorithm)],
            COMPARISON_TYPE_CODES[str(comparison_type)],
            AXIS_CODES[str(axis)],
            int(level),
            METRIC_CODES[str(metric)],
        ]
    except KeyError as exception:
        raise ValueError(f"unknown bootstrap code: {exception.args[0]}") from exception
    if int(level) not in range(AXIS_LEVEL_COUNT[str(axis)]):
        raise ValueError("bootstrap level is outside its registered axis")
    return np.random.SeedSequence(entropy)


def cluster_bootstrap_interval(
    values,
    seed,
    replicates: int = BOOTSTRAP_REPLICATES,
) -> tuple[float, float]:
    """Bootstrap the median by resampling the supplied basin-score vector."""

    array = np.asarray(values, dtype=np.float64)
    if array.ndim != 1 or len(array) == 0 or not np.all(np.isfinite(array)):
        raise ValueError("bootstrap values must be a nonempty finite vector")
    count = int(replicates)
    if count <= 0:
        raise ValueError("bootstrap replicate count must be positive")
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, len(array), size=(count, len(array)))
    medians = np.median(array[indices], axis=1)
    lower, upper = np.quantile(medians, [0.025, 0.975], method="linear")
    return float(lower), float(upper)


def clopper_pearson_interval(successes: int, trials: int, alpha: float = 0.05) -> tuple[float, float]:
    """Return the two-sided exact binomial interval (descriptive only)."""

    k, n = int(successes), int(trials)
    if n <= 0 or k < 0 or k > n:
        raise ValueError("invalid binomial counts")
    lower = 0.0 if k == 0 else float(beta.ppf(alpha / 2.0, k, n - k + 1))
    upper = 1.0 if k == n else float(beta.ppf(1.0 - alpha / 2.0, k + 1, n - k))
    return lower, upper


def evaluate_absolute_thresholds(
    *,
    axis: str,
    probability_median: float,
    probability_lower: float,
    above_reference_count: int,
    argmax_median: float,
    argmax_lower: float,
) -> dict:
    """Apply the preregistered strict and inclusive boundary operators."""

    probability_reference = {
        "parameter": 0.5,
        "process_noise": 1.0 / 3.0,
        "joint_cell": 1.0 / 6.0,
    }.get(str(axis))
    if probability_reference is None:
        raise ValueError("unknown absolute-gate axis")
    probability_median_pass = float(probability_median) > probability_reference
    probability_lower_pass = float(probability_lower) > probability_reference
    count_pass = int(above_reference_count) >= 33
    if axis == "joint_cell":
        argmax_median_pass = float(argmax_median) >= 0.60
    else:
        argmax_median_pass = float(argmax_median) > 0.50
    argmax_lower_pass = float(argmax_lower) > 0.50
    result = {
        "probability_reference": probability_reference,
        "probability_median_pass": bool(probability_median_pass),
        "probability_bootstrap_lower_pass": bool(probability_lower_pass),
        "minimum_33_of_36_pass": bool(count_pass),
        "argmax_median_pass": bool(argmax_median_pass),
        "argmax_bootstrap_lower_pass": bool(argmax_lower_pass),
    }
    result["pass"] = bool(all(result[key] for key in (
        "probability_median_pass", "probability_bootstrap_lower_pass",
        "minimum_33_of_36_pass", "argmax_median_pass",
        "argmax_bootstrap_lower_pass",
    )))
    return result


def evaluate_paired_thresholds(median: float, bootstrap_lower: float) -> dict:
    """Apply the inclusive minus-0.10 paired noninferiority boundary."""

    median_pass = float(median) >= -0.10
    lower_pass = float(bootstrap_lower) >= -0.10
    return {
        "noninferiority_margin": -0.10,
        "median_pass": bool(median_pass),
        "bootstrap_lower_pass": bool(lower_pass),
        "pass": bool(median_pass and lower_pass),
    }


def _ordered_basin_values(group: pd.DataFrame, column: str) -> np.ndarray:
    if len(group) != 36 or group["basin_id"].astype(str).nunique() != 36:
        raise ValueError("every decision group must contain exactly 36 unique basins")
    ordered = group.assign(_basin=group["basin_id"].astype(str).str.zfill(8)).sort_values("_basin", kind="stable")
    values = ordered[column].to_numpy(dtype=np.float64)
    if not np.all(np.isfinite(values)):
        raise ValueError("decision group contains a non-finite basin score")
    return values


def _absolute_decision(
    group: pd.DataFrame,
    *,
    algorithm: str,
    knowledge_mode: str,
    axis: str,
    level: int,
    base_seed: int,
    replicates: int,
) -> dict:
    probabilities = _ordered_basin_values(group, "true_probability")
    accuracies = _ordered_basin_values(group, "argmax_accuracy")
    probability_interval = cluster_bootstrap_interval(
        probabilities,
        bootstrap_substream_seed(
            algorithm, knowledge_mode, axis, level, "true_probability", base_seed=base_seed
        ),
        replicates,
    )
    accuracy_interval = cluster_bootstrap_interval(
        accuracies,
        bootstrap_substream_seed(
            algorithm, knowledge_mode, axis, level, "argmax_accuracy", base_seed=base_seed
        ),
        replicates,
    )
    reference = {"parameter": 0.5, "process_noise": 1.0 / 3.0, "joint_cell": 1.0 / 6.0}[axis]
    above = int(np.sum(probabilities > reference))
    fraction_interval = clopper_pearson_interval(above, 36)
    thresholds = evaluate_absolute_thresholds(
        axis=axis,
        probability_median=float(np.median(probabilities)),
        probability_lower=probability_interval[0],
        above_reference_count=above,
        argmax_median=float(np.median(accuracies)),
        argmax_lower=accuracy_interval[0],
    )
    return {
        "algorithm": algorithm,
        "knowledge_mode": knowledge_mode,
        "axis": axis,
        "level": int(level),
        "basin_count": 36,
        "probability_median": float(np.median(probabilities)),
        "probability_bootstrap_lower": probability_interval[0],
        "probability_bootstrap_upper": probability_interval[1],
        "basins_strictly_above_reference": above,
        "above_reference_fraction": above / 36.0,
        "above_reference_clopper_pearson_lower": fraction_interval[0],
        "above_reference_clopper_pearson_upper": fraction_interval[1],
        "argmax_accuracy_median": float(np.median(accuracies)),
        "argmax_accuracy_bootstrap_lower": accuracy_interval[0],
        "argmax_accuracy_bootstrap_upper": accuracy_interval[1],
        **thresholds,
    }


def decision_summary(
    basin_rows: Iterable[dict] | pd.DataFrame,
    paired_rows: Iterable[dict] | pd.DataFrame,
    *,
    base_seed: int = BOOTSTRAP_BASE_SEED,
    replicates: int = BOOTSTRAP_REPLICATES,
) -> dict:
    """Compute every absolute, paired, and overall preregistered decision."""

    basin = _frame(basin_rows)
    paired = _frame(paired_rows)
    _require_columns(basin, (
        "basin_id", "algorithm", "knowledge_mode", "axis", "level",
        "true_probability", "argmax_accuracy",
    ))
    _require_columns(paired, (
        "basin_id", "algorithm", "axis", "level", "paired_probability_loss",
    ))
    algorithms = sorted(set(basin["algorithm"].astype(str)), key=lambda value: ALGORITHM_CODES.get(value, 99))
    if set(algorithms) != set(ALGORITHM_CODES):
        raise ValueError("decision input must contain algorithms C and P")
    payload = {
        "bootstrap_base_seed": int(base_seed),
        "bootstrap_replicates": int(replicates),
        "primary_window": PRIMARY_WINDOW,
        "algorithms": {},
    }
    for algorithm in algorithms:
        absolute_gates = []
        contracts = (
            ("parameter", ("joint_unknown", "noise_known"), range(2)),
            ("process_noise", ("joint_unknown", "param_known"), range(3)),
            ("joint_cell", ("joint_unknown",), range(6)),
        )
        for axis, modes, levels in contracts:
            for mode in modes:
                for level in levels:
                    selected = basin[
                        (basin["algorithm"].astype(str) == algorithm)
                        & (basin["knowledge_mode"].astype(str) == mode)
                        & (basin["axis"].astype(str) == axis)
                        & (basin["level"].astype(int) == int(level))
                    ]
                    absolute_gates.append(_absolute_decision(
                        selected,
                        algorithm=algorithm,
                        knowledge_mode=mode,
                        axis=axis,
                        level=int(level),
                        base_seed=int(base_seed),
                        replicates=int(replicates),
                    ))
        paired_gates = []
        for axis, levels in (("parameter", range(2)), ("process_noise", range(3))):
            for level in levels:
                selected = paired[
                    (paired["algorithm"].astype(str) == algorithm)
                    & (paired["axis"].astype(str) == axis)
                    & (paired["level"].astype(int) == int(level))
                ]
                values = _ordered_basin_values(selected, "paired_probability_loss")
                interval = cluster_bootstrap_interval(
                    values,
                    bootstrap_substream_seed(
                        algorithm, "paired", axis, int(level),
                        "paired_probability_loss", base_seed=int(base_seed),
                    ),
                    int(replicates),
                )
                median = float(np.median(values))
                paired_gates.append({
                    "algorithm": algorithm,
                    "axis": axis,
                    "level": int(level),
                    "basin_count": 36,
                    "median_paired_probability_loss": median,
                    "bootstrap_lower": interval[0],
                    "bootstrap_upper": interval[1],
                    **evaluate_paired_thresholds(median, interval[0]),
                })
        payload["algorithms"][algorithm] = {
            "absolute_gates": absolute_gates,
            "paired_gates": paired_gates,
            "absolute_gate_count": len(absolute_gates),
            "paired_gate_count": len(paired_gates),
            "overall_pass": bool(
                all(item["pass"] for item in absolute_gates)
                and all(item["pass"] for item in paired_gates)
            ),
        }
    return payload


def descriptive_metric_rows(event_rows: Iterable[dict] | pd.DataFrame) -> list[dict]:
    """Produce basin-balanced primary-window diagnostics by four switch facets."""

    frame = _frame(event_rows)
    primary = frame[frame["window"] == PRIMARY_WINDOW].copy()
    metrics = [
        "parameter_true_probability", "parameter_argmax_accuracy",
        "process_noise_true_probability", "process_noise_argmax_accuracy",
        "joint_cell_true_probability", "joint_cell_argmax_accuracy",
        "state_mean_normalized_rmse",
    ]
    rows = []
    for dimension, column in (
        ("source_cell", "source_cell"),
        ("destination_cell", "destination_cell"),
        ("sequence_position", "sequence_position"),
        ("transition_type", "transition_type"),
    ):
        basin_group_columns = ["algorithm", "knowledge_mode", "basin_id", column]
        per_basin = primary.groupby(basin_group_columns, sort=True, as_index=False)[metrics].mean()
        for identity, group in per_basin.groupby(["algorithm", "knowledge_mode", column], sort=True, dropna=False):
            algorithm, mode, level = identity
            row = {
                "algorithm": str(algorithm),
                "knowledge_mode": str(mode),
                "dimension": dimension,
                "dimension_value": str(level),
                "basin_count": int(group["basin_id"].astype(str).nunique()),
            }
            for metric in metrics:
                row[f"median_basin_{metric}"] = float(np.median(group[metric].to_numpy(dtype=np.float64)))
            rows.append(row)
    rows.sort(key=lambda row: (
        row["algorithm"], row["knowledge_mode"], row["dimension"], row["dimension_value"]
    ))
    return rows


def _load_npz(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {name: archive[name].copy() for name in archive.files}


def _verify_summary_config(config: dict) -> None:
    observed_windows = {
        str(name): tuple(int(value) for value in bounds)
        for name, bounds in config["report_windows_zero_based_half_open"].items()
    }
    if observed_windows != REPORT_WINDOWS or config.get("primary_window") != PRIMARY_WINDOW:
        raise ValueError("registered scoring windows changed")
    bootstrap = config["bootstrap_contract"]
    expected = {
        "base_seed": BOOTSTRAP_BASE_SEED,
        "replicates": BOOTSTRAP_REPLICATES,
        "algorithm_codes": ALGORITHM_CODES,
        "comparison_type_codes": COMPARISON_TYPE_CODES,
        "axis_codes": AXIS_CODES,
        "metric_codes": METRIC_CODES,
    }
    for name, value in expected.items():
        if bootstrap.get(name) != value:
            raise ValueError(f"registered bootstrap contract changed: {name}")
    if config["balanced_sequence_contract"].get(
        "required_incoming_events_per_target_cell_per_basin"
    ) != 5:
        raise ValueError("registered incoming-event count changed")


def _read_csv(path: Path) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(f"required manifest is missing: {path}")
    if path.stat().st_size == 0:
        return pd.DataFrame()
    try:
        return pd.read_csv(path, dtype={"basin_id": str, "task_id": str})
    except pd.errors.EmptyDataError:
        return pd.DataFrame()


def _verify_complete_root(
    root: Path,
    config: dict,
    tasks: list[TaskIdentity],
    repo_root: Path,
) -> None:
    manifest_path = root / "manifests" / "run_manifest.json"
    if not manifest_path.is_file():
        raise FileNotFoundError(f"formal run manifest is missing: {manifest_path}")
    with manifest_path.open(encoding="utf-8") as handle:
        manifest = json.load(handle)
    counts = config["expected_counts"]
    for key in ("truth_bundles", "tasks", "events"):
        if int(manifest.get(key, -1)) != int(counts[key]):
            raise ValueError(f"formal manifest {key} count is incomplete")
    if int(manifest.get("failures", -1)) != 0 or int(manifest.get("truth_clip_count", -1)) != 0:
        raise ValueError("formal manifest contains failures or clipped truth")
    if manifest.get("config_sha256") != sha256_file(Path(repo_root) / CONFIG_PATH):
        raise ValueError("formal manifest configuration hash changed")
    fairness = manifest.get("fairness", {})
    if (
        int(fairness.get("task_count", -1)) != int(counts["tasks"])
        or int(fairness.get("truth_identity_count", -1))
        != int(counts["truth_bundles"])
        or fairness.get("same_observations_across_all_six_tasks") is not True
        or fairness.get("same_truth_states_across_all_six_tasks") is not True
        or fairness.get("truth_hashes_agree") is not True
    ):
        raise ValueError("formal manifest fairness checks are incomplete")
    artifacts = config["artifact_paths"]
    truth_manifest = _read_csv(root / artifacts["truth_manifest"])
    task_manifest = _read_csv(root / artifacts["task_manifest"])
    failures = _read_csv(root / artifacts["failure_manifest"])
    if len(truth_manifest) != int(counts["truth_bundles"]):
        raise ValueError("truth manifest count is incomplete")
    if len(task_manifest) != int(counts["tasks"]):
        raise ValueError("task manifest count is incomplete")
    if not failures.empty:
        raise ValueError("failure manifest is not empty")
    if set(truth_manifest["run_status"].astype(str)) != {"success"}:
        raise ValueError("truth manifest contains a non-success bundle")
    if not np.all(truth_manifest["clip_count"].astype(int) == 0):
        raise ValueError("truth manifest contains a clipped bundle")
    if set(task_manifest["run_status"].astype(str)) != {"success"}:
        raise ValueError("task manifest contains a non-success task")
    if not np.all(task_manifest["event_count"].astype(int) == 5):
        raise ValueError("task manifest event count changed")
    expected_ids = {task.task_id for task in tasks}
    observed_ids = set(task_manifest["task_id"].astype(str))
    if len(observed_ids) != len(task_manifest) or observed_ids != expected_ids:
        raise ValueError("task manifest identities differ from registration")
    for task in tasks:
        path = task_output_path(root, task)
        if not path.is_file():
            raise FileNotFoundError(f"registered raw task is missing: {path}")
        record = task_manifest[task_manifest["task_id"].astype(str) == task.task_id]
        if len(record) != 1 or str(record.iloc[0]["output_sha256"]) != sha256_file(path):
            raise ValueError(f"raw task hash changed: {task.task_id}")
    truth_records = {str(row.task_id): row for row in truth_manifest.itertuples(index=False)}
    for basin in sorted(str(value).zfill(8) for value in admitted_basins()):
        for seed in FORMAL_SEEDS:
            identity = f"{basin}_s{seed}"
            path = truth_bundle_path(root, basin, seed)
            if identity not in truth_records or not path.is_file():
                raise FileNotFoundError(f"registered truth bundle is missing: {identity}")
            if str(getattr(truth_records[identity], "truth_sha256")) != sha256_file(path):
                raise ValueError(f"truth bundle hash changed: {identity}")


def _write_csv_new(path: Path, rows: list[dict]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rows)
    frame.to_csv(target, index=False, mode="x", lineterminator="\n")


def _write_json_new(path: Path, payload: dict) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")


def _artifact_hash_rows(root: Path, paths: list[Path]) -> list[dict]:
    return [
        {
            "path": path.relative_to(root).as_posix(),
            "sha256": sha256_file(path),
        }
        for path in sorted(paths, key=lambda value: value.as_posix())
    ]


def summarize_formal_evidence(
    output_root: Path,
    *,
    repo_root: Path = REPO_ROOT,
) -> dict:
    """Read a complete formal root and write new, non-overwriting artifacts."""

    root = Path(output_root)
    config = load_registered_config(Path(repo_root), verify_hashes=True)
    _verify_summary_config(config)
    basins = sorted(str(value).zfill(8) for value in admitted_basins())
    tasks = build_task_table(basins, FORMAL_SEEDS)
    _verify_complete_root(root, config, tasks, Path(repo_root))
    artifacts = config["artifact_paths"]
    paths = {
        "event": root / artifacts["event_metrics"],
        "basin": root / artifacts["basin_metrics"],
        "paired": root / artifacts["paired_axis_metrics"],
        "decision": root / artifacts["decision_summary"],
        "paired_event": root / "verification" / "paired_event_metrics.csv",
        "descriptive": root / "verification" / "descriptive_metrics.csv",
        "hashes": root / artifacts["artifact_hashes"],
    }
    collisions = [path for path in paths.values() if path.exists()]
    if collisions:
        raise FileExistsError(f"summary artifacts already exist: {collisions[0]}")

    event_rows: list[dict] = []
    paired_event_rows: list[dict] = []
    for basin in basins:
        for seed in FORMAL_SEEDS:
            for algorithm in sorted(ARM_MODES, key=ALGORITHM_CODES.get):
                arrays_by_mode = {}
                for mode in KNOWLEDGE_MODES:
                    task = TaskIdentity(basin, seed, algorithm, mode)
                    arrays = _load_npz(task_output_path(root, task))
                    arrays_by_mode[mode] = arrays
                    event_rows.extend(event_metric_rows(
                        arrays, basin, seed, algorithm, mode
                    ))
                paired_event_rows.extend(paired_axis_rows(
                    arrays_by_mode["joint_unknown"],
                    arrays_by_mode["noise_known"],
                    axis="parameter",
                    basin_id=basin,
                    seed=seed,
                    algorithm=algorithm,
                ))
                paired_event_rows.extend(paired_axis_rows(
                    arrays_by_mode["joint_unknown"],
                    arrays_by_mode["param_known"],
                    axis="process_noise",
                    basin_id=basin,
                    seed=seed,
                    algorithm=algorithm,
                ))
    expected_event_rows = int(config["expected_counts"]["events"]) * len(REPORT_WINDOWS)
    if len(event_rows) != expected_event_rows:
        raise ValueError("event metric row count differs from registration")
    expected_paired_events = len(basins) * len(FORMAL_SEEDS) * len(ARM_MODES) * 5 * 2
    if len(paired_event_rows) != expected_paired_events:
        raise ValueError("paired event metric row count differs from registration")
    basin_rows = basin_metric_rows(event_rows)
    paired_rows = aggregate_paired_basin_rows(paired_event_rows)
    if len(basin_rows) != len(basins) * len(ARM_MODES) * len(KNOWLEDGE_MODES) * 11:
        raise ValueError("basin metric row count differs from registration")
    if len(paired_rows) != len(basins) * len(ARM_MODES) * 5:
        raise ValueError("paired basin metric row count differs from registration")
    bootstrap = config["bootstrap_contract"]
    decisions = decision_summary(
        basin_rows,
        paired_rows,
        base_seed=int(bootstrap["base_seed"]),
        replicates=int(bootstrap["replicates"]),
    )
    decisions.update({
        "experiment_id": config["experiment_id"],
        "technical_complete": True,
        "truth_bundle_count": int(config["expected_counts"]["truth_bundles"]),
        "task_count": int(config["expected_counts"]["tasks"]),
        "event_count": int(config["expected_counts"]["events"]),
        "event_metric_row_count": len(event_rows),
        "basin_metric_row_count": len(basin_rows),
        "paired_event_metric_row_count": len(paired_event_rows),
        "paired_axis_metric_row_count": len(paired_rows),
        "claim_boundary": (
            "36 admitted basins; synthetic truth and observations; known boundary; "
            "six registered continuous truth histories; true source parameter known for "
            "conservative mapping only; exact true pre-switch state reset; two capacity "
            "candidates; three process-noise "
            "candidates; destination days 91 through 180 only; no forecast or online claim"
        ),
    })
    descriptive_rows = descriptive_metric_rows(event_rows)
    _write_csv_new(paths["event"], event_rows)
    _write_csv_new(paths["basin"], basin_rows)
    _write_csv_new(paths["paired_event"], paired_event_rows)
    _write_csv_new(paths["paired"], paired_rows)
    _write_csv_new(paths["descriptive"], descriptive_rows)
    _write_json_new(paths["decision"], decisions)
    hashed = [
        root / artifacts["truth_manifest"],
        root / artifacts["task_manifest"],
        root / artifacts["failure_manifest"],
        root / "manifests" / "run_manifest.json",
        *(
            truth_bundle_path(root, basin, seed)
            for basin in basins
            for seed in FORMAL_SEEDS
        ),
        *(task_output_path(root, task) for task in tasks),
        paths["event"],
        paths["basin"],
        paths["paired_event"],
        paths["paired"],
        paths["descriptive"],
        paths["decision"],
    ]
    _write_csv_new(paths["hashes"], _artifact_hash_rows(root, hashed))
    return decisions


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--route", choices=("local", "hpc"), default="local")
    parser.add_argument("--output-root", type=Path)
    arguments = parser.parse_args()
    config = load_registered_config(REPO_ROOT, verify_hashes=True)
    output_root = (
        arguments.output_root
        if arguments.output_root is not None
        else REPO_ROOT / config["output_roots"][arguments.route]
    )
    summary = summarize_formal_evidence(output_root)
    print(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
