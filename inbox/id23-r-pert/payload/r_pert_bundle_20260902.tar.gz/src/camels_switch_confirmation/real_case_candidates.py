"""3x3 perturbation candidate grid for the joint param-noise real-case line.

Implements Task 2 of docs/superpowers/plans/2026-08-25-joint-param-noise-real-case-runner.md.
The grid constants and member construction are reused verbatim from the committed synthetic
line (single source of truth): FC_FACTORS/NOISE_CANDIDATES/cell_index from
``joint_param_noise_precheck`` and ``build_bank`` from ``bank``.  This module adds only the
real-case bookkeeping required by prereg draft v02: post-clip actual multipliers and the
candidate-collapse flag (adjacent parFC spacing below 5% of the parameter range).
"""
from __future__ import annotations

from typing import Any, Mapping

from camels_switch_confirmation.bank import build_bank
from camels_switch_confirmation.joint_param_noise_precheck import (
    FC_FACTORS,
    NOISE_CANDIDATES,
    cell_index,
)

NOISE_MULTIPLIERS = NOISE_CANDIDATES
COLLAPSE_SPACING_FRACTION = 0.05


def build_candidate_grid(
    center_parameters: Mapping[str, float],
    *,
    fc_bounds: tuple[float, float],
) -> dict[str, Any]:
    """Build the 3x3 joint candidate grid around one calibrated center vector."""
    low, high = float(fc_bounds[0]), float(fc_bounds[1])
    center_fc = float(center_parameters["parFC"])
    if not (low <= center_fc <= high):
        raise ValueError(f"center parFC {center_fc} lies outside bounds [{low}, {high}]")

    members, clipped = build_bank(dict(center_parameters), (low, high))
    actual_multipliers = [float(member["parFC"]) / center_fc for member in members]

    fc_values = sorted(float(member["parFC"]) for member in members)
    minimum_spacing = min(b - a for a, b in zip(fc_values, fc_values[1:]))
    collapse = bool(minimum_spacing < COLLAPSE_SPACING_FRACTION * (high - low))

    cells = [
        {
            "cell": cell_index(param_index, noise_index),
            "param_index": param_index,
            "noise_index": noise_index,
            "parFC": float(members[param_index]["parFC"]),
            "fc_factor_nominal": FC_FACTORS[param_index],
            "fc_multiplier_actual": actual_multipliers[param_index],
            "noise_multiplier": NOISE_MULTIPLIERS[noise_index],
        }
        for param_index in range(len(FC_FACTORS))
        for noise_index in range(len(NOISE_MULTIPLIERS))
    ]
    return {
        "fc_factors": FC_FACTORS,
        "noise_multipliers": NOISE_MULTIPLIERS,
        "members": members,
        "clipped": [bool(flag) for flag in clipped],
        "actual_fc_multipliers": actual_multipliers,
        "candidate_collapse": collapse,
        "minimum_fc_spacing": float(minimum_spacing),
        "cells": cells,
    }
