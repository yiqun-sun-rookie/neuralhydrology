"""JOINT-X1 figures: read-only plots over the finished npz artifacts.

Purely descriptive.  Changes no preregistered gate and carries no claim beyond
what `joint_paired_contrast.py` and `joint_placebo_timecourse.py` already
computed; these panels only make those numbers visible.

Usage:  python -X utf8 -m camels_switch_confirmation.plot_joint_param_noise
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from camels_switch_confirmation.joint_param_noise_precheck import (
    NOISE_CANDIDATES,
    SEQUENCE,
    STAGE_DAYS,
)
from camels_switch_confirmation.joint_paired_contrast import marginals
from camels_switch_confirmation.run_joint_param_noise_switch import (
    FC_FACTORS,
    OUTPUT_ROOT,
)

plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 130

PARAM_LABELS = [f"容量 ×{factor:g}" for factor in FC_FACTORS]
NOISE_LABELS = [f"噪声 ×{multiplier:g}" for multiplier in NOISE_CANDIDATES]
COLOURS = ("#1b6ca8", "#c0392b", "#2e8b57")
PLACEBO_GATE = 0.05
UPLIFT_GATE = 0.10


def _stage_truth(axis_position):
    return np.repeat([cell[axis_position] for cell in SEQUENCE], STAGE_DAYS)


def _mark_stages(axis, n_days):
    for boundary in range(STAGE_DAYS, n_days, STAGE_DAYS):
        axis.axvline(boundary, color="0.55", linewidth=0.9, linestyle="--")


def _shade_truth(axis, axis_position, n_days):
    """Background of each stage takes the colour of the candidate that is true."""
    for position, cell in enumerate(SEQUENCE):
        start = position * STAGE_DAYS
        if start >= n_days:
            break
        axis.axvspan(start, min(start + STAGE_DAYS, n_days),
                     color=COLOURS[cell[axis_position]], alpha=0.13, linewidth=0)


def figure_timeseries(root: Path, basin: str, seed: int, arm: str, out_path: Path):
    """One task: both marginals against the truth, plus the paired cell trace."""
    with np.load(root / "arms" / arm / "switch" / "probs"
                 / f"{basin}_s{seed}.npz", allow_pickle=False) as archive:
        switch = archive["probabilities"]
        truth_cell = archive["truth_cell_indices"]
    with np.load(root / "arms" / arm / "null" / "probs"
                 / f"{basin}_s{seed}.npz", allow_pickle=False) as archive:
        null = archive["probabilities"]
    switch_param, switch_noise = marginals(switch)
    null_param, null_noise = marginals(null)
    n_days = switch.shape[0]
    days = np.arange(n_days)

    figure, axes = plt.subplots(3, 1, figsize=(11, 8.6), sharex=True)
    _shade_truth(axes[0], 0, n_days)
    _shade_truth(axes[1], 1, n_days)
    for index in range(3):
        axes[0].plot(days, switch_param[:, index], color=COLOURS[index],
                     linewidth=1.0, label=PARAM_LABELS[index])
        axes[1].plot(days, switch_noise[:, index], color=COLOURS[index],
                     linewidth=1.0, label=NOISE_LABELS[index])
    axes[2].plot(days, switch[days, truth_cell], color="#1b6ca8", linewidth=1.0,
                 label="切换情景：真格的把握")
    axes[2].plot(days, null[days, truth_cell], color="#c0392b", linewidth=1.0,
                 alpha=0.85, label="空对照：同一格的把握")

    titles = ("土壤存水量这一轴：背景色＝当前真值档，同色的线该在上面",
              "地下水扰动这一轴：背景色＝当前真值档，同色的线该在上面",
              "九格里“真的那一格”的把握：切换 vs 什么都不改")
    for axis, title in zip(axes, titles):
        _mark_stages(axis, n_days)
        axis.set_ylim(-0.02, 1.02)
        axis.set_ylabel("把握（0–1）")
        axis.set_title(title, fontsize=11)
        axis.legend(fontsize=8, ncol=3, loc="lower center", framealpha=0.92)
    axes[2].set_xlabel("天（每 180 天一段，虚线是真值发生变化的时刻）")
    figure.suptitle(f"流域 {basin}　种子 {seed}　{arm} 臂", fontsize=12)
    figure.tight_layout(rect=(0, 0, 1, 0.97))
    figure.savefig(out_path)
    plt.close(figure)


def figure_placebo(root: Path, out_path: Path):
    """The decisive panel: does the placebo gap close inside the stage?"""
    frame = pd.read_csv(root / "verification" / "placebo_timecourse.csv")
    figure, axis = plt.subplots(figsize=(9, 4.6))
    quarter_centres = np.array([22.5, 67.5, 112.5, 157.5])
    for axis_name, colour, label in (
            ("param", "#c0392b", "土壤存水量这一轴（真值其实没变）"),
            ("noise", "#1b6ca8", "地下水扰动这一轴（真值其实没变）")):
        subset = frame[frame["axis"] == axis_name]
        medians = subset.groupby("quarter")["gap"].median().reindex(range(4))
        axis.plot(quarter_centres, medians.values, marker="o", color=colour,
                  linewidth=2.0, label=label)
    axis.axhspan(-PLACEBO_GATE, PLACEBO_GATE, color="#2e8b57", alpha=0.12,
                 label=f"允许范围 ±{PLACEBO_GATE:g}")
    axis.axhline(0.0, color="0.4", linewidth=0.8)
    axis.set_xlabel("这一段里的第几天")
    axis.set_ylabel("读数偏差（应为 0）")
    axis.set_title("“真值没变的时候，读数动了多少”——参数轴的偏差在段内自己缩掉了",
                   fontsize=12)
    axis.legend(fontsize=9)
    figure.tight_layout()
    figure.savefig(out_path)
    plt.close(figure)


def figure_uplift(root: Path, out_path: Path):
    """Per-task paired uplift for every axis and level, against the two gates."""
    frame = pd.read_csv(root / "verification" / "joint_task_metrics.csv",
                        dtype={"basin_id": str})
    groups = [
        ("param_level1_uplift", "参数\n半容量"),
        ("param_level2_uplift", "参数\n倍容量"),
        ("param_placebo_uplift", "参数\n安慰剂"),
        ("noise_level1_uplift", "噪声\n很小"),
        ("noise_level2_uplift", "噪声\n很大"),
        ("noise_placebo_uplift", "噪声\n安慰剂"),
    ]
    figure, axes = plt.subplots(1, 2, figsize=(11, 4.8), sharey=True)
    for panel, arm in zip(axes, ("C", "P")):
        subset = frame[frame["arm"] == arm]
        for position, (column, label) in enumerate(groups):
            values = subset[column].values
            jitter = (np.random.default_rng(20260820 + position).normal(
                0.0, 0.055, size=len(values)))
            colour = "#7f8c8d" if "placebo" in column else (
                "#c0392b" if column.startswith("param") else "#1b6ca8")
            panel.scatter(position + jitter, values, s=11, alpha=0.55,
                          color=colour, edgecolors="none")
            panel.plot([position - 0.3, position + 0.3],
                       [np.median(values)] * 2, color="black", linewidth=2.0)
        panel.axhline(UPLIFT_GATE, color="#2e8b57", linestyle="--", linewidth=1.0)
        panel.axhline(0.0, color="0.4", linewidth=0.8)
        panel.axhspan(-PLACEBO_GATE, PLACEBO_GATE, color="#2e8b57", alpha=0.10)
        panel.set_xticks(range(len(groups)))
        panel.set_xticklabels([label for _, label in groups], fontsize=9)
        panel.set_title(f"{arm} 臂（每点＝一个流域×种子，共 {len(subset)} 个）",
                        fontsize=11)
    axes[0].set_ylabel("信号提升（切换 减 什么都不改）")
    figure.suptitle("绿虚线 0.10 ＝ 提升必须超过它；绿色带 ±0.05 ＝ 安慰剂必须待在里面",
                    fontsize=11)
    figure.tight_layout(rect=(0, 0, 1, 0.94))
    figure.savefig(out_path)
    plt.close(figure)


def figure_confusion(root: Path, out_path: Path):
    """Where the wrong days are wrong: noise axis, parameter axis, or both."""
    frame = pd.read_csv(root / "verification" / "joint_task_metrics.csv",
                        dtype={"basin_id": str})
    labels = ("九格全对", "只有噪声认错", "只有参数认错", "两样同时认错")
    columns = ("cell_correct_fraction", "noise_only_wrong_fraction",
               "param_only_wrong_fraction", "both_wrong_fraction")
    figure, axis = plt.subplots(figsize=(8.4, 4.4))
    width = 0.38
    for offset, arm, colour in ((-width / 2, "C", "#1b6ca8"),
                                (width / 2, "P", "#c0392b")):
        subset = frame[frame["arm"] == arm]
        medians = [float(subset[column].median()) for column in columns]
        positions = np.arange(len(columns)) + offset
        bars = axis.bar(positions, medians, width=width, color=colour,
                        alpha=0.85, label=f"{arm} 臂")
        for bar, value in zip(bars, medians):
            axis.text(bar.get_x() + bar.get_width() / 2, value + 0.012,
                      f"{value * 100:.1f}%", ha="center", fontsize=9)
    axis.set_xticks(range(len(columns)))
    axis.set_xticklabels(labels, fontsize=10)
    axis.set_ylabel("占计分天数的比例（中位）")
    axis.set_ylim(0, 0.8)
    axis.set_title("认错的时候错在哪一轴——两样同时认错只占 2% 出头", fontsize=12)
    axis.legend(fontsize=9)
    figure.tight_layout()
    figure.savefig(out_path)
    plt.close(figure)


def representative_task(root: Path, arm: str):
    """The task whose whole-cell accuracy sits closest to that arm's median."""
    frame = pd.read_csv(root / "verification" / "joint_task_metrics.csv",
                        dtype={"basin_id": str})
    subset = frame[frame["arm"] == arm].copy()
    target = subset["cell_correct_fraction"].median()
    subset["distance"] = (subset["cell_correct_fraction"] - target).abs()
    row = subset.sort_values(["distance", "basin_id"]).iloc[0]
    return str(row["basin_id"]).zfill(8), int(row["seed"])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=str(OUTPUT_ROOT))
    parser.add_argument("--arm", default="C")
    arguments = parser.parse_args()
    root = Path(arguments.root)
    out_dir = root / "figures"
    out_dir.mkdir(parents=True, exist_ok=True)

    basin, seed = representative_task(root, arguments.arm)
    figure_timeseries(root, basin, seed, arguments.arm,
                      out_dir / "joint_timeseries_representative.png")
    figure_placebo(root, out_dir / "joint_placebo_timecourse.png")
    figure_uplift(root, out_dir / "joint_uplift_distribution.png")
    figure_confusion(root, out_dir / "joint_confusion_structure.png")
    print(f"representative task: basin {basin} seed {seed} arm {arguments.arm}")
    for path in sorted(out_dir.glob("*.png")):
        print(path)


if __name__ == "__main__":
    main()
