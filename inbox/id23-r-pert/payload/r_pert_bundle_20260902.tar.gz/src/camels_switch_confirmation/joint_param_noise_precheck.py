"""NOISEPAR-G1: pre-run identifiability precheck for JOINT parameter x noise switching.

Specification: docs/plans/2026-08-20-joint-param-noise-precheck-spec-v01.md
(frozen before computation; hash recorded in the results summary)

ZERO filter runs.  The candidate space is the 3x3 grid

    parameter axis i : parFC x (1.0, 0.5, 2.0)          -- bank.build_bank
    noise     axis j : SLZ process multiplier (1.0, 0.1, 10.0)

so a candidate differs from another in predicted MEAN discharge (parameter axis),
in predicted VARIANCE (noise axis), or in both.  The per-day evidence rate is the
general Gaussian KL, which decomposes exactly into those two channels:

    KL[t] = 0.5 * ( ln(v_B/v_A) - 1 + v_A/v_B )      <- variance channel
          + (mu_A - mu_B)**2 / (2 * v_B)             <- mean channel
    t_lik = ln(19) / mean(KL)                        (days to 19:1 odds)

Equal variances reduce it to r**2/2 (the frozen parFC precheck); equal means
reduce it to the frozen noise precheck.  This is a strict generalisation of both
frozen criteria, not a new one.

The decomposition is what answers the design question that motivated this run:
if parameter-only pairs are separated mostly through the VARIANCE channel (or
noise-only pairs mostly through the MEAN channel), the two axes share a
fingerprint and the confusion is structural rather than methodological.

Usage:  python -X utf8 -m camels_switch_confirmation.joint_param_noise_precheck
"""

from __future__ import annotations

import json
import os
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

for _variable in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ.setdefault(_variable, "1")

import numpy as np
import pandas as pd

_SRC = Path(__file__).resolve().parents[1]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation.bank import build_bank  # noqa: E402
from camels_switch_confirmation.g1_precheck import (  # noqa: E402
    BOUNDS_PRESET,
    LAG_KERNEL,
    PARAM_KEYS,
    SLZ_LOGNORMAL_SIGMA,
    STATE_NAMES,
    WINDOW_START,
    _window_end,
)
from camels_switch_confirmation.run_online_noise_pilot import (  # noqa: E402
    PARAMETER_TABLE,
    RESULTS,
)
from camels_switch_confirmation.run_online_noise_real_obs import (  # noqa: E402
    design90_basins,
)

SPEC = "docs/plans/2026-08-20-joint-param-noise-precheck-spec-v01.md"
SPEC_SHA256 = "5471e746c016ddf144dc1072148d18fe5b432369c1d6143bbbf892a6287c0f4b"
OUTPUT_ROOT = RESULTS / "joint_param_noise_precheck_v01"
G1_CSV = RESULTS / "g1_precheck_v01" / "g1_precheck.csv"

FC_FACTORS = (1.0, 0.5, 2.0)          # index 0 = calibrated centre
NOISE_CANDIDATES = (1.0, 0.1, 10.0)   # index 0 = calibrated reference scale
N_PARAM = len(FC_FACTORS)
N_NOISE = len(NOISE_CANDIDATES)
N_CELLS = N_PARAM * N_NOISE

# 7 stages of (parameter index, noise index): 2 param-only, 2 noise-only,
# 2 joint transitions.  Frozen in the specification.
SEQUENCE = ((0, 0), (1, 0), (1, 2), (0, 1), (2, 1), (2, 0), (1, 2))
STAGE_DAYS = 180
WINDOW_DAYS = STAGE_DAYS * len(SEQUENCE)
ENSEMBLE_SIZE = 40
SEED_ENTROPY = 20260820
FIXED_C = 0.0

AXIS_GATE_DAYS = 90.0        # G-A, G-B
TRANSITION_GATE_DAYS = 180.0  # G-C
FINGERPRINT_GATE_SHARE = 0.5  # G-D
MIN_ADMITTED = 10
WORKERS = 10


def cell_index(param_index: int, noise_index: int) -> int:
    """Flat index of a grid cell; row = parameter axis, column = noise axis."""
    if not 0 <= param_index < N_PARAM or not 0 <= noise_index < N_NOISE:
        raise ValueError("cell indices out of range")
    return N_NOISE * int(param_index) + int(noise_index)


def cell_pair(index: int) -> tuple:
    """Inverse of cell_index."""
    if not 0 <= index < N_CELLS:
        raise ValueError("flat cell index out of range")
    return divmod(int(index), N_NOISE)


def injection_sigma(multiplier: float) -> float:
    """Truth-injection lognormal sigma for a noise multiplier (moment match)."""
    if not np.isfinite(multiplier) or multiplier <= 0.0:
        raise ValueError("noise multiplier must be finite and positive")
    return SLZ_LOGNORMAL_SIGMA * float(np.sqrt(multiplier))


def transition_kind(source: tuple, destination: tuple) -> str:
    """Which axes move across one stage boundary."""
    param_moved = source[0] != destination[0]
    noise_moved = source[1] != destination[1]
    if param_moved and noise_moved:
        return "both"
    if param_moved:
        return "param_only"
    if noise_moved:
        return "noise_only"
    return "none"


def realised_transitions(sequence=SEQUENCE) -> list:
    """Ordered (source cell, destination cell, kind) across stage boundaries."""
    transitions = []
    for position in range(1, len(sequence)):
        source = sequence[position - 1]
        destination = sequence[position]
        transitions.append((source, destination,
                            transition_kind(source, destination)))
    return transitions


def kl_components(mean_true, variance_true, mean_rival, variance_rival) -> tuple:
    """Per-day (variance channel, mean channel) of KL(true || rival).

    Their sum is the full Gaussian KL.  With equal variances the variance
    channel vanishes and the mean channel is r**2 / 2 (frozen parFC form); with
    equal means the mean channel vanishes and the variance channel is the frozen
    noise-precheck form.
    """
    v_true = np.asarray(variance_true, dtype=np.float64)
    v_rival = np.asarray(variance_rival, dtype=np.float64)
    if np.any(v_true <= 0.0) or np.any(v_rival <= 0.0):
        raise ValueError("variances must be strictly positive")
    ratio = v_true / v_rival
    variance_channel = 0.5 * (-np.log(ratio) - 1.0 + ratio)
    gap = np.asarray(mean_true, dtype=np.float64) - np.asarray(mean_rival,
                                                               dtype=np.float64)
    mean_channel = gap ** 2 / (2.0 * v_rival)
    return variance_channel, mean_channel


def days_to_odds(kl_rate: float, odds: float = 19.0) -> float:
    """ln(odds) / evidence rate; infinite when the rate vanishes."""
    if kl_rate <= 0.0:
        return float("inf")
    return float(np.log(odds) / kl_rate)


def _ensemble_moments(rain, pet, temp, params, initial_state,
                      multiplier, basin_id, index):
    """Daily ensemble mean and variance of simulated discharge for one cell."""
    from scl_hydro.hbv_lite_numpy import simulate_hbv_lite

    sigma = injection_sigma(multiplier)
    generator = np.random.default_rng(
        np.random.SeedSequence((SEED_ENTROPY, int(basin_id), int(index)))
    )
    n_days = len(rain)
    states = [dict(initial_state) for _ in range(ENSEMBLE_SIZE)]
    discharge = np.empty((ENSEMBLE_SIZE, n_days), dtype=np.float64)
    for day in range(n_days):
        for member in range(ENSEMBLE_SIZE):
            simulated, state = simulate_hbv_lite(
                rain[day:day + 1], pet[day:day + 1], temp[day:day + 1],
                params, initial_state=states[member], lag_kernel=LAG_KERNEL,
            )
            state = dict(state)
            state["SLZ"] = state["SLZ"] * float(
                np.exp(generator.normal(-0.5 * sigma ** 2, sigma))
            )
            states[member] = state
            discharge[member, day] = float(simulated[0])
    return discharge.mean(axis=0), discharge.var(axis=0)


def _precheck_one(basin: str) -> dict:
    from hydroagent.data_loading import load_camels_basin
    from scl_hydro.hbv_lite_numpy import resolve_hbv_bounds

    table = pd.read_csv(PARAMETER_TABLE, dtype={"basin_id": str})
    table["basin_id"] = table["basin_id"].str.zfill(8)
    row = table[table["basin_id"] == basin].iloc[0]
    params = {key: float(row[f"p_{key}"]) for key in PARAM_KEYS}
    initial_state = {name: float(row[f"state_{name}"]) for name in STATE_NAMES}
    members, clipped = build_bank(params, resolve_hbv_bounds(BOUNDS_PRESET)["parFC"])

    g1 = pd.read_csv(G1_CSV, dtype={"basin_id": str})
    g1["basin_id"] = g1["basin_id"].str.zfill(8)
    sigma_obs = float(g1.set_index("basin_id").loc[basin, "sigma_obs"])

    forcing, _, _ = load_camels_basin(
        basin, data_root="data/camels_us", start_date=WINDOW_START,
        end_date=_window_end(), forcing="maurer", pet_method="oudin",
        keep_obs_nan_days=True,
    )
    rain = forcing["prcp"].values.astype(np.float64)
    pet_column = "ep" if "ep" in forcing.columns else "pet"
    pet = forcing[pet_column].values.astype(np.float64)
    temp = (forcing["tmean"].values.astype(np.float64)
            if "tmean" in forcing.columns else np.zeros_like(rain))

    means, variances = {}, {}
    for param_index in range(N_PARAM):
        for noise_index in range(N_NOISE):
            index = cell_index(param_index, noise_index)
            mean_series, spread = _ensemble_moments(
                rain, pet, temp, members[param_index], initial_state,
                NOISE_CANDIDATES[noise_index], basin, index,
            )
            means[index] = mean_series
            variances[index] = spread + sigma_obs ** 2

    pairs = []
    for source in range(N_CELLS):
        for destination in range(N_CELLS):
            if source == destination:
                continue
            variance_channel, mean_channel = kl_components(
                means[destination], variances[destination],
                means[source], variances[source],
            )
            rate_variance = float(np.mean(variance_channel))
            rate_mean = float(np.mean(mean_channel))
            rate = rate_variance + rate_mean
            source_cell = cell_pair(source)
            destination_cell = cell_pair(destination)
            total = rate_variance + rate_mean
            pairs.append({
                "basin_id": basin,
                "source_param": source_cell[0], "source_noise": source_cell[1],
                "dest_param": destination_cell[0], "dest_noise": destination_cell[1],
                "kind": transition_kind(source_cell, destination_cell),
                "kl_var": rate_variance, "kl_mean": rate_mean, "kl_total": rate,
                "var_share": float(rate_variance / total) if total > 0 else float("nan"),
                "mean_share": float(rate_mean / total) if total > 0 else float("nan"),
                "t_lik": days_to_odds(rate),
            })
    pair_frame = pd.DataFrame(pairs)

    param_only = pair_frame[pair_frame["kind"] == "param_only"]
    noise_only = pair_frame[pair_frame["kind"] == "noise_only"]

    record = {
        "basin_id": basin, "sigma_obs": sigma_obs,
        "ensemble_size": ENSEMBLE_SIZE, "fixed_c": FIXED_C,
        "parfc_clipped_any": bool(any(clipped)),
        "t_lik_param_axis_max": float(param_only["t_lik"].max()),
        "t_lik_noise_axis_max": float(noise_only["t_lik"].max()),
        "t_lik_all_pairs_max": float(pair_frame["t_lik"].max()),
        "param_axis_var_share_median": float(param_only["var_share"].median()),
        "noise_axis_mean_share_median": float(noise_only["mean_share"].median()),
    }

    transition_liks = []
    for source_cell, destination_cell, kind in realised_transitions():
        selected = pair_frame[
            (pair_frame["source_param"] == source_cell[0])
            & (pair_frame["source_noise"] == source_cell[1])
            & (pair_frame["dest_param"] == destination_cell[0])
            & (pair_frame["dest_noise"] == destination_cell[1])
        ].iloc[0]
        label = (f"p{source_cell[0]}m{source_cell[1]}"
                 f"_to_p{destination_cell[0]}m{destination_cell[1]}")
        record[f"t_lik_{label}"] = float(selected["t_lik"])
        record[f"kind_{label}"] = kind
        transition_liks.append(float(selected["t_lik"]))
    record["t_lik_transitions_max"] = float(max(transition_liks))

    # nearest rival of each cell (descriptive: which axis gets confused first)
    nearest_kinds = {"param_only": 0, "noise_only": 0, "both": 0}
    for destination in range(N_CELLS):
        truth_cell = cell_pair(destination)
        subset = pair_frame[
            (pair_frame["dest_param"] == truth_cell[0])
            & (pair_frame["dest_noise"] == truth_cell[1])
        ]
        nearest = subset.loc[subset["kl_total"].idxmin()]
        nearest_kinds[str(nearest["kind"])] += 1
    for kind, count in nearest_kinds.items():
        record[f"nearest_rival_{kind}"] = int(count)

    record["gate_a_param_axis"] = bool(
        record["t_lik_param_axis_max"] <= AXIS_GATE_DAYS)
    record["gate_b_noise_axis"] = bool(
        record["t_lik_noise_axis_max"] <= AXIS_GATE_DAYS)
    record["gate_c_transitions"] = bool(
        record["t_lik_transitions_max"] <= TRANSITION_GATE_DAYS)
    record["gate_d_fingerprint"] = bool(
        record["param_axis_var_share_median"] <= FINGERPRINT_GATE_SHARE
        and record["noise_axis_mean_share_median"] <= FINGERPRINT_GATE_SHARE)
    record["admitted"] = bool(record["gate_a_param_axis"]
                              and record["gate_b_noise_axis"]
                              and record["gate_c_transitions"]
                              and record["gate_d_fingerprint"])
    record["_pairs"] = pair_frame
    return record


def main() -> None:
    basins = design90_basins()
    with ProcessPoolExecutor(max_workers=WORKERS) as pool:
        records = list(pool.map(_precheck_one, basins, chunksize=2))

    pair_frames = [record.pop("_pairs") for record in records]
    frame = pd.DataFrame(records)
    pair_table = pd.concat(pair_frames, ignore_index=True)

    out_dir = OUTPUT_ROOT
    out_dir.mkdir(parents=True, exist_ok=True)
    frame.to_csv(out_dir / "joint_precheck.csv", index=False)
    pair_table.to_csv(out_dir / "pair_table.csv", index=False)
    admitted = frame[frame["admitted"]]
    admitted.to_csv(out_dir / "admission.csv", index=False)

    def _median(column):
        values = frame[column]
        finite = values[np.isfinite(values)]
        return None if finite.empty else float(finite.median())

    summary = {
        "specification": SPEC,
        "specification_sha256": SPEC_SHA256,
        "fc_factors": list(FC_FACTORS),
        "candidates_m": list(NOISE_CANDIDATES),
        "sequence": [list(stage) for stage in SEQUENCE],
        "transition_kinds": [kind for _, _, kind in realised_transitions()],
        "stage_days": STAGE_DAYS,
        "window_days": WINDOW_DAYS,
        "ensemble_size": ENSEMBLE_SIZE,
        "seed_entropy": SEED_ENTROPY,
        "fixed_c": FIXED_C,
        "gates": {
            "axis_gate_days": AXIS_GATE_DAYS,
            "transition_gate_days": TRANSITION_GATE_DAYS,
            "fingerprint_gate_share": FINGERPRINT_GATE_SHARE,
        },
        "n_basins": int(len(frame)),
        "n_admitted": int(len(admitted)),
        "n_passing_each_gate": {
            gate: int(frame[gate].sum())
            for gate in ("gate_a_param_axis", "gate_b_noise_axis",
                         "gate_c_transitions", "gate_d_fingerprint")
        },
        "stop_condition_min_admitted": MIN_ADMITTED,
        "stop_condition_triggered": bool(len(admitted) < MIN_ADMITTED),
        "median_t_lik_param_axis_max": _median("t_lik_param_axis_max"),
        "median_t_lik_noise_axis_max": _median("t_lik_noise_axis_max"),
        "median_t_lik_transitions_max": _median("t_lik_transitions_max"),
        "median_param_axis_var_share": _median("param_axis_var_share_median"),
        "median_noise_axis_mean_share": _median("noise_axis_mean_share_median"),
        "median_t_lik_by_transition": {
            column.replace("t_lik_", ""): _median(column)
            for column in frame.columns
            if column.startswith("t_lik_p")
        },
        "nearest_rival_counts": {
            kind: int(frame[f"nearest_rival_{kind}"].sum())
            for kind in ("param_only", "noise_only", "both")
        },
        "n_parfc_clipped_basins": int(frame["parfc_clipped_any"].sum()),
    }
    (out_dir / "precheck_summary.json").write_text(
        json.dumps(summary, indent=1), encoding="utf-8"
    )
    print(json.dumps(summary, indent=1))


if __name__ == "__main__":
    main()
