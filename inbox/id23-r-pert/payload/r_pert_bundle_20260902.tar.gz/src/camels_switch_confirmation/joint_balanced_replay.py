"""Contracts for the six-cell balanced known-boundary replay experiment.

This experiment deliberately has a narrower candidate space than the frozen
nine-cell experiment: two field-capacity factors by three process-noise
multipliers.  Each replay starts from the same true pre-switch state, maps that
state conservatively into every active parameter candidate, and keeps model
identity fixed throughout the target stage.
"""

from __future__ import annotations

import csv
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np

from camels_switch_confirmation.g2_switch_confirmation import (
    N_STATE,
    RisingRoutedObservation,
    build_state_dependent_lower_groundwater_covariance,
)
from camels_switch_confirmation.joint_param_noise_precheck import (
    NOISE_CANDIDATES,
)


CONFIG_PATH = Path(
    "src/camels_switch_confirmation/configs/"
    "joint_param_noise_balanced_replay_v01.json"
)
EXPERIMENT_ID = "JOINT-X3-BALANCED-REPLAY"

PARAMETER_FACTORS = (1.0, 0.5)
PROCESS_NOISE_MULTIPLIERS = tuple(float(value) for value in NOISE_CANDIDATES)
FORMAL_SEEDS = (8, 9, 10, 11, 12, 13)
WILLIAMS_BASE = (0, 1, 5, 2, 4, 3)
N_PARAMETER = len(PARAMETER_FACTORS)
N_NOISE = len(PROCESS_NOISE_MULTIPLIERS)
N_CELLS = N_PARAMETER * N_NOISE
N_BASINS = 36


def _integer_index(value: int, *, name: str, stop: int) -> int:
    if not isinstance(value, (int, np.integer)) or isinstance(value, bool):
        raise ValueError(f"{name} must be an integer from 0 through {stop - 1}")
    result = int(value)
    if result not in range(stop):
        raise ValueError(f"{name} must be 0 through {stop - 1}")
    return result


def cell_pair(cell: int) -> tuple[int, int]:
    """Return ``(parameter_index, process_noise_index)`` for one cell."""

    value = _integer_index(cell, name="cell", stop=N_CELLS)
    return value // N_NOISE, value % N_NOISE


def cell_index(param_index: int, noise_index: int) -> int:
    """Return the row-major six-cell index for one candidate pair."""

    parameter = _integer_index(
        param_index, name="parameter index", stop=N_PARAMETER
    )
    noise = _integer_index(noise_index, name="process-noise index", stop=N_NOISE)
    return parameter * N_NOISE + noise


def williams_sequence(index: int) -> tuple[int, ...]:
    """Return one row of the registered even-six Williams design."""

    shift = _integer_index(index, name="Williams sequence index", stop=N_CELLS)
    return tuple((cell + shift) % N_CELLS for cell in WILLIAMS_BASE)


def sequence_index_for_basin_seed(basin_rank: int, seed: int) -> int:
    """Rotate sequence identity by sorted basin rank and formal-seed position."""

    rank = _integer_index(basin_rank, name="basin rank", stop=N_BASINS)
    if not isinstance(seed, (int, np.integer)) or isinstance(seed, bool):
        raise ValueError("formal seed must be 8 through 13")
    seed_value = int(seed)
    if seed_value not in FORMAL_SEEDS:
        raise ValueError("formal seed must be 8 through 13")
    return (rank + FORMAL_SEEDS.index(seed_value)) % N_CELLS


def sequence_for_basin_seed(
    basin_rank: int,
    seed: int,
) -> tuple[tuple[int, int], ...]:
    """Return the six registered parameter/noise stages for a basin and seed."""

    index = sequence_index_for_basin_seed(basin_rank, seed)
    return tuple(cell_pair(cell) for cell in williams_sequence(index))


def validate_balanced_design(sequences: Iterable[Sequence[int]]) -> None:
    """Reject any departure from the complete even-six Williams design.

    The six rows must each be a permutation of all cells, every position must
    contain all cells once, and the 30 adjacent edges must be the 30 distinct
    ordered pairs whose source and destination differ.
    """

    rows = tuple(tuple(row) for row in sequences)
    expected_cells = tuple(range(N_CELLS))
    if len(rows) != N_CELLS:
        raise ValueError(f"balanced design must contain exactly {N_CELLS} sequences")
    for position, row in enumerate(rows):
        if len(row) != N_CELLS or tuple(sorted(row)) != expected_cells:
            raise ValueError(
                f"Williams sequence {position} must be a permutation of all six cells"
            )
    for position in range(N_CELLS):
        if tuple(sorted(row[position] for row in rows)) != expected_cells:
            raise ValueError(f"Williams design position {position} is not balanced")
    edges = tuple(
        (source, destination)
        for row in rows
        for source, destination in zip(row, row[1:])
    )
    expected_edges = {
        (source, destination)
        for source in expected_cells
        for destination in expected_cells
        if source != destination
    }
    if len(edges) != len(expected_edges) or set(edges) != expected_edges:
        raise ValueError(
            "Williams design must contain every directed switch exactly once"
        )


def sha256_file(path: Path) -> str:
    """Return the lowercase SHA-256 digest of one file."""

    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _load_json(path: Path) -> dict:
    with path.open(encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError(f"configuration must be a JSON object: {path}")
    return payload


def _require_sha256(value: object, *, label: str) -> str:
    digest = str(value).lower()
    if len(digest) != 64 or any(character not in "0123456789abcdef" for character in digest):
        raise ValueError(f"{label} must be one lowercase 64-character SHA-256 digest")
    return digest


def _resolve_repository_path(
    repo_root: Path,
    registered_path: object,
    *,
    label: str,
) -> Path:
    if not isinstance(registered_path, str):
        raise ValueError(f"{label} must be a repository-relative string")
    raw_value = registered_path
    value = Path(raw_value)
    if value.is_absolute() or value.drive:
        raise ValueError(f"{label} must be repository-relative")
    root = Path(repo_root).resolve()
    lexical_parts = raw_value.replace("\\", "/").split("/")
    if any(part in {"", ".", ".."} for part in lexical_parts):
        raise ValueError(f"{label} path attempts to escape the repository")
    # Keep the logical repository path instead of resolving junction targets.
    # This worktree intentionally exposes the large ignored data directory via
    # a Windows junction, while the registered path remains repository-relative.
    return root / value


def _read_csv_rows(path: Path) -> tuple[tuple[str, ...], list[dict[str, str]]]:
    with Path(path).open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"CSV header is missing: {path}")
        fields = tuple(str(value) for value in reader.fieldnames)
        rows = list(reader)
    if any(None in row for row in rows):
        raise ValueError(f"CSV row has more values than its header: {path}")
    if any(value is None for row in rows for value in row.values()):
        raise ValueError(f"CSV row has fewer values than its header: {path}")
    return fields, rows


def registry_content_sha256(path: Path, *, experiment_id: str) -> str:
    """Hash registry semantics while excluding its self-referential config hash.

    The target row's ``base_config_sha256`` is replaced with an empty string
    before canonical JSON serialization.  Every other field and every other
    row remains covered by the digest.
    """

    fields, rows = _read_csv_rows(path)
    required = {"exp_id", "base_config", "base_config_sha256"}
    if not required.issubset(fields):
        raise ValueError("experiment registry is missing required config fields")
    matches = [row for row in rows if row["exp_id"] == str(experiment_id)]
    if len(matches) != 1:
        raise ValueError("experiment registry must contain exactly one target row")
    normalized = []
    for row in rows:
        values = {field: str(row.get(field, "")) for field in fields}
        if values["exp_id"] == str(experiment_id):
            values["base_config_sha256"] = ""
        normalized.append(values)
    payload = json.dumps(
        {"fieldnames": fields, "rows": normalized},
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _registered_basin_ids(repo_root: Path, config: dict) -> tuple[str, ...]:
    try:
        relative = config["input_paths"]["admitted_basins"]
    except KeyError as exception:
        raise ValueError("admitted_basins input path is required") from exception
    path = _resolve_repository_path(
        repo_root, relative, label="admitted_basins input"
    )
    fields, rows = _read_csv_rows(path)
    if "basin_id" not in fields:
        raise ValueError("admitted basin table is missing basin_id")
    basins = tuple(sorted(str(row["basin_id"]).zfill(8) for row in rows))
    if len(basins) != N_BASINS or len(set(basins)) != N_BASINS:
        raise ValueError("admitted basin table must contain 36 unique basins")
    return basins


def _resolve_loader_input(
    data_root: Path,
    subdirectory: Path,
    basin_id: str,
    filename: str,
) -> Path:
    direct = data_root / subdirectory / basin_id[:2] / filename
    if direct.is_file():
        return direct
    matches = sorted(
        path
        for path in (data_root / subdirectory).glob(f"*/{filename}")
        if path.is_file()
    )
    if len(matches) != 1:
        raise ValueError(
            f"CAMELS-US loader path is missing or ambiguous for {basin_id}/{filename}"
        )
    return matches[0]


def verify_camels_raw_input_manifest(
    repo_root: Path,
    config: dict,
    expected_basin_ids: Sequence[str] | None = None,
) -> dict[str, int]:
    """Verify every raw file read by the registered 36-basin CAMELS loader."""

    root = Path(repo_root).resolve()
    try:
        data_root_value = config["input_paths"]["camels_data_root"]
        manifest_value = config["input_paths"]["camels_raw_input_manifest"]
    except KeyError as exception:
        raise ValueError("CAMELS data root and raw-input manifest are required") from exception
    data_root = _resolve_repository_path(
        root, data_root_value, label="camels_data_root input"
    )
    if not data_root.is_dir():
        raise FileNotFoundError(f"CAMELS-US data root is missing: {data_root}")
    manifest_path = _resolve_repository_path(
        root, manifest_value, label="camels_raw_input_manifest input"
    )
    if not manifest_path.is_file():
        raise FileNotFoundError(f"CAMELS-US raw-input manifest is missing: {manifest_path}")
    if expected_basin_ids is None:
        basins = _registered_basin_ids(root, config)
    else:
        basins = tuple(sorted(str(value).zfill(8) for value in expected_basin_ids))
        if not basins or len(basins) != len(set(basins)):
            raise ValueError("expected basin identifiers must be unique and nonempty")

    fields, rows = _read_csv_rows(manifest_path)
    expected_fields = ("kind", "basin_id", "path", "size_bytes", "sha256")
    if fields != expected_fields:
        raise ValueError(
            "CAMELS-US raw-input manifest header must be " + ",".join(expected_fields)
        )
    expected_paths: dict[tuple[str, str], Path] = {
        (
            "camels_topo",
            "",
        ): data_root / "camels_attributes_v2.0" / "camels_topo.txt"
    }
    for basin in basins:
        expected_paths[("maurer_forcing", basin)] = _resolve_loader_input(
            data_root,
            Path("basin_mean_forcing") / "maurer",
            basin,
            f"{basin}_lump_maurer_forcing_leap.txt",
        )
        expected_paths[("usgs_streamflow", basin)] = _resolve_loader_input(
            data_root,
            Path("usgs_streamflow"),
            basin,
            f"{basin}_streamflow_qc.txt",
        )
    observed_keys = [(str(row["kind"]), str(row["basin_id"]).zfill(8) if row["basin_id"] else "") for row in rows]
    if len(observed_keys) != len(set(observed_keys)):
        raise ValueError("CAMELS-US raw-input manifest contains duplicate identities")
    if set(observed_keys) != set(expected_paths):
        raise ValueError("CAMELS-US raw-input manifest coverage differs from loader inputs")
    canonical_keys = [("camels_topo", "")]
    canonical_keys.extend(
        identity
        for basin in basins
        for identity in (("maurer_forcing", basin), ("usgs_streamflow", basin))
    )
    if observed_keys != canonical_keys:
        raise ValueError("CAMELS-US raw-input manifest row order is not canonical")

    for row, identity in zip(rows, observed_keys):
        raw_path = str(row["path"])
        if "\\" in raw_path or any(part in {"", ".", ".."} for part in raw_path.split("/")):
            raise ValueError("CAMELS-US raw-input manifest path attempts to escape or is noncanonical")
        path = _resolve_repository_path(
            root, raw_path, label="CAMELS-US raw-input manifest"
        )
        expected_path = expected_paths[identity]
        if path != expected_path:
            raise ValueError("CAMELS-US raw-input manifest path differs from loader resolution")
        try:
            path.relative_to(data_root)
        except ValueError as exception:
            raise ValueError("CAMELS-US raw-input manifest path escapes data root") from exception
        if not path.is_file():
            raise FileNotFoundError(f"CAMELS-US raw input is missing: {path}")
        try:
            registered_size = int(row["size_bytes"])
        except ValueError as exception:
            raise ValueError("CAMELS-US raw-input size is not an integer") from exception
        if str(registered_size) != str(row["size_bytes"]) or registered_size != path.stat().st_size:
            raise ValueError("CAMELS-US raw-input size changed")
        expected_digest = _require_sha256(
            row["sha256"], label="CAMELS-US raw-input SHA-256"
        )
        if sha256_file(path) != expected_digest:
            raise ValueError("CAMELS-US raw-input SHA-256 changed")
    return {
        "basin_count": len(basins),
        "file_count": len(rows),
        "maurer_forcing_count": sum(key[0] == "maurer_forcing" for key in observed_keys),
        "usgs_streamflow_count": sum(key[0] == "usgs_streamflow" for key in observed_keys),
        "camels_topo_count": sum(key[0] == "camels_topo" for key in observed_keys),
    }


def _verify_hash_collection(
    repo_root: Path,
    collection_name: str,
    records: dict,
    declared_paths: dict,
) -> None:
    if not isinstance(records, dict):
        raise ValueError(f"{collection_name} must be a JSON object")
    if set(records) != set(declared_paths):
        raise ValueError(
            f"{collection_name} hash coverage differs from declared paths"
        )
    for label, record in records.items():
        if not isinstance(record, dict) or set(record) != {"path", "sha256"}:
            raise ValueError(
                f"registered hash record must contain path and sha256 ({label})"
            )
        if str(record["path"]) != str(declared_paths[label]):
            raise ValueError(
                f"registered {collection_name} path differs from its declared path "
                f"({label})"
            )
        path = _resolve_repository_path(
            repo_root,
            record["path"],
            label=f"registered {collection_name}/{label}",
        )
        if not path.is_file():
            raise FileNotFoundError(
                f"registered file is missing ({collection_name}/{label}): {path}"
            )
        observed = sha256_file(path)
        expected = _require_sha256(
            record["sha256"], label=f"registered {collection_name}/{label}"
        )
        if observed != expected:
            raise ValueError(
                f"registered {collection_name} SHA-256 changed ({label}): "
                f"{observed} != {expected}"
            )


def _verify_registry_exemption(
    repo_root: Path,
    config: dict,
    label: str,
    record: dict,
) -> None:
    required_fields = {
        "kind",
        "experiment_id",
        "normalized_sha256",
        "config_path_field",
        "config_sha256_field",
    }
    if not isinstance(record, dict) or set(record) != required_fields:
        raise ValueError("self-referential registry exemption fields changed")
    if record["kind"] != "self_referential_config_registry":
        raise ValueError("experiment registry exemption kind changed")
    if record["experiment_id"] != EXPERIMENT_ID:
        raise ValueError("experiment registry exemption identity changed")
    if record["config_path_field"] != "base_config":
        raise ValueError("experiment registry config-path field changed")
    if record["config_sha256_field"] != "base_config_sha256":
        raise ValueError("experiment registry config-hash field changed")
    registry_path = _resolve_repository_path(
        repo_root,
        config["input_paths"][label],
        label="experiment_registry input",
    )
    expected_normalized = _require_sha256(
        record["normalized_sha256"],
        label="experiment registry normalized SHA-256",
    )
    observed_normalized = registry_content_sha256(
        registry_path, experiment_id=EXPERIMENT_ID
    )
    if observed_normalized != expected_normalized:
        raise ValueError("experiment registry normalized SHA-256 changed")
    _, rows = _read_csv_rows(registry_path)
    selected = [row for row in rows if row["exp_id"] == EXPERIMENT_ID]
    row = selected[0]
    if row[record["config_path_field"]] != CONFIG_PATH.as_posix():
        raise ValueError("experiment registry base config path changed")
    config_hash = sha256_file(Path(repo_root).resolve() / CONFIG_PATH)
    if row[record["config_sha256_field"]].lower() != config_hash:
        raise ValueError("experiment registry base config SHA-256 changed")


def _verify_hash_coverage(repo_root: Path, config: dict) -> None:
    inputs = config.get("input_paths")
    implementations = config.get("implementation_paths")
    if not isinstance(inputs, dict) or not inputs:
        raise ValueError("input_paths must be a nonempty JSON object")
    if not isinstance(implementations, dict) or not implementations:
        raise ValueError("implementation_paths must be a nonempty JSON object")
    exemptions = config.get("hash_coverage_exemptions", {})
    if not isinstance(exemptions, dict) or set(exemptions) != {"input_paths"}:
        raise ValueError("hash_coverage_exemptions must contain only input_paths")
    input_exemptions = exemptions["input_paths"]
    if not isinstance(input_exemptions, dict):
        raise ValueError("input path exemptions must be a JSON object")
    if not set(input_exemptions).issubset(inputs):
        raise ValueError("input path exemption refers to an undeclared input")
    registered_inputs = config.get("registered_input_hashes", {})
    registered_implementation = config.get(
        "registered_implementation_hashes", {}
    )
    expected_inputs = {
        label: path for label, path in inputs.items() if label not in input_exemptions
    }
    if set(registered_inputs) != set(expected_inputs):
        raise ValueError("input hash coverage differs from declared paths")
    if set(registered_implementation) != set(implementations):
        raise ValueError("implementation hash coverage differs from declared paths")
    _verify_hash_collection(
        repo_root, "input", registered_inputs, expected_inputs
    )
    _verify_hash_collection(
        repo_root,
        "implementation",
        registered_implementation,
        implementations,
    )

    for label, record in input_exemptions.items():
        kind = record.get("kind") if isinstance(record, dict) else None
        if kind == "self_referential_config_registry":
            if label != "experiment_registry":
                raise ValueError("self-referential registry exemption label changed")
            _verify_registry_exemption(repo_root, config, label, record)
        elif kind == "directory_replaced_by_manifest":
            required_fields = {"kind", "replacement_input_label"}
            if set(record) != required_fields:
                raise ValueError("directory replacement exemption fields changed")
            replacement = str(record["replacement_input_label"])
            if replacement not in expected_inputs:
                raise ValueError("directory replacement manifest is not hash registered")
            if replacement != "camels_raw_input_manifest" or label != "camels_data_root":
                raise ValueError("CAMELS directory replacement labels changed")
            verify_camels_raw_input_manifest(repo_root, config)
        else:
            raise ValueError(f"unsupported input path exemption kind: {kind}")


def load_registered_config(repo_root: Path, verify_hashes: bool = True) -> dict:
    """Load the registered configuration and optionally verify all hashes.

    Empty hash dictionaries are valid only while explicitly loading the design
    scaffold with ``verify_hashes=False``.  They cannot authorize execution.
    """

    root = Path(repo_root).resolve()
    config = _load_json(root / CONFIG_PATH)
    if config.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("balanced replay experiment identity changed")
    balanced_contract = config.get("balanced_sequence_contract", {})
    if tuple(balanced_contract.get("formal_seeds", ())) != FORMAL_SEEDS:
        raise ValueError("balanced replay formal seeds changed")
    if tuple(balanced_contract.get("williams_base", ())) != WILLIAMS_BASE:
        raise ValueError("balanced replay Williams base changed")
    candidate_contract = config.get("candidate_contract", {})
    if tuple(candidate_contract.get("parameter_factors", ())) != (
        PARAMETER_FACTORS
    ):
        raise ValueError("balanced replay parameter factors changed")
    if tuple(candidate_contract.get("process_noise_multipliers", ())) != (
        PROCESS_NOISE_MULTIPLIERS
    ):
        raise ValueError("balanced replay process-noise multipliers changed")
    if verify_hashes:
        registered_inputs = config.get("registered_input_hashes", {})
        registered_implementation = config.get(
            "registered_implementation_hashes", {}
        )
        if not registered_inputs and not registered_implementation:
            raise ValueError(
                "registered hashes are empty; the design scaffold cannot be executed"
            )
        _verify_hash_coverage(root, config)
    return config


def _mixture_moments(
    states: Sequence[np.ndarray],
    covariances: Sequence[np.ndarray],
    probabilities: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    state_values = np.asarray(states, dtype=np.float64)
    covariance_values = np.asarray(covariances, dtype=np.float64)
    weights = np.asarray(probabilities, dtype=np.float64)
    weights = weights / weights.sum()
    mean = np.sum(weights[:, None] * state_values, axis=0)
    covariance = np.zeros_like(covariance_values[0])
    for weight, state, candidate_covariance in zip(
        weights, state_values, covariance_values
    ):
        deviation = state - mean
        covariance += weight * (
            candidate_covariance + np.outer(deviation, deviation)
        )
    return mean, 0.5 * (covariance + covariance.T)


@dataclass
class EstimatorRuntime:
    """One fixed-stage estimator and its registered candidate coordinates."""

    knowledge_mode: str
    interaction_mode: str
    estimator: Any
    transitions: list[Any]
    candidate_pairs: tuple[tuple[int, int], ...]
    members: tuple[dict, ...]
    bounds: dict
    sigma_obs: float
    source_param_index: int
    destination_param_index: int
    destination_noise_index: int

    def set_forcing(self, rain: float, pet: float, temperature: float) -> None:
        for transition in self.transitions:
            transition.set_forcing(rain, pet, temperature)

    def assign_process_covariances(self, reference_slz: float) -> None:
        """Set each filter's covariance from its fixed active noise candidate."""

        level = max(float(reference_slz), 0.0)
        if not np.isfinite(level):
            raise ValueError("reference lower-groundwater state must be finite")
        for candidate, (_, noise_index) in zip(
            self.estimator.filters, self.candidate_pairs
        ):
            candidate.process_covariance = (
                build_state_dependent_lower_groundwater_covariance(
                    level,
                    PROCESS_NOISE_MULTIPLIERS[noise_index],
                )
            )


def _construct_estimator(
    filters: Sequence[Any],
    initial_probabilities: np.ndarray,
    interaction_mode: str,
    pairwise_moment_transform: Any,
) -> Any:
    from hbv_joint_uncertainty.imm import (
        InteractingMultipleModel,
        PairwisePathMultipleModel,
    )

    transition_matrix = np.eye(len(filters), dtype=np.float64)
    if interaction_mode == "full":
        estimator = InteractingMultipleModel(
            filters=filters,
            transition_matrix=transition_matrix,
            initial_probabilities=initial_probabilities,
            parameter_groups=list(range(len(filters))),
            pairwise_moment_transform=pairwise_moment_transform,
            model_evidence_scorer=None,
        )
    elif interaction_mode == "pairwise_path_postcollapse":
        estimator = PairwisePathMultipleModel(
            filters=filters,
            transition_matrix=transition_matrix,
            initial_probabilities=initial_probabilities,
            pairwise_moment_transform=pairwise_moment_transform,
            model_evidence_scorer=None,
        )
        estimator.recursive_probability_representation = "ordinary_float"
    else:
        raise ValueError(f"unknown interaction mode: {interaction_mode}")
    estimator.interaction_mode = interaction_mode
    estimator.parameter_state_mapping = "conservative_parfc"
    estimator.within_stage_transition = "identity"
    mean, covariance = _mixture_moments(
        [candidate.state for candidate in filters],
        [candidate.covariance for candidate in filters],
        initial_probabilities,
    )
    estimator.state = mean
    estimator.covariance = covariance
    return estimator


def _candidate_pairs(
    knowledge_mode: str,
    destination_param_index: int,
    destination_noise_index: int,
) -> tuple[tuple[int, int], ...]:
    if knowledge_mode == "joint_unknown":
        return tuple(
            (param_index, noise_index)
            for param_index in range(N_PARAMETER)
            for noise_index in range(N_NOISE)
        )
    if knowledge_mode == "param_known":
        return tuple(
            (destination_param_index, noise_index)
            for noise_index in range(N_NOISE)
        )
    if knowledge_mode == "noise_known":
        return tuple(
            (param_index, destination_noise_index)
            for param_index in range(N_PARAMETER)
        )
    raise ValueError(f"unknown knowledge mode: {knowledge_mode}")


def build_estimator_runtime(
    knowledge_mode: str,
    interaction_mode: str,
    members: Sequence[dict],
    initial_state: np.ndarray,
    initial_covariance: np.ndarray,
    initial_probabilities: np.ndarray | None,
    sigma_obs: float,
    bounds: dict,
    source_param_index: int,
    destination_param_index: int,
    destination_noise_index: int,
) -> EstimatorRuntime:
    """Build a fresh, fixed-identity runtime for one independent replay."""

    from hbv_joint_uncertainty.hbv_state_mapping import (
        project_hbv_state_conserving_soil_excess,
        remap_parfc_moments,
    )
    from hbv_joint_uncertainty.preflight import ForcingTransition
    from hbv_joint_uncertainty.sigma_filter import (
        ModifiedUnscentedFilter,
        ScaledSigmaPoints,
    )

    if len(members) != N_PARAMETER:
        raise ValueError("balanced replay requires exactly two parameter members")
    member_values = tuple(dict(member) for member in members)
    source_parameter = _integer_index(
        source_param_index, name="source parameter index", stop=N_PARAMETER
    )
    destination_parameter = _integer_index(
        destination_param_index,
        name="destination parameter index",
        stop=N_PARAMETER,
    )
    destination_noise = _integer_index(
        destination_noise_index, name="destination noise index", stop=N_NOISE
    )
    pairs = _candidate_pairs(
        knowledge_mode,
        destination_parameter,
        destination_noise,
    )
    if interaction_mode not in {"full", "pairwise_path_postcollapse"}:
        raise ValueError(f"unknown interaction mode: {interaction_mode}")

    state = np.asarray(initial_state, dtype=np.float64)
    covariance = np.asarray(initial_covariance, dtype=np.float64)
    if state.shape != (N_STATE,) or not np.all(np.isfinite(state)):
        raise ValueError(f"initial state must be finite with shape ({N_STATE},)")
    if covariance.shape != (N_STATE, N_STATE) or not np.all(
        np.isfinite(covariance)
    ):
        raise ValueError(
            f"initial covariance must be finite with shape ({N_STATE}, {N_STATE})"
        )
    if not np.allclose(covariance, covariance.T, rtol=0.0, atol=1e-12):
        raise ValueError("initial covariance must be symmetric")
    observation_sigma = float(sigma_obs)
    if not np.isfinite(observation_sigma) or observation_sigma <= 0.0:
        raise ValueError("observation sigma must be finite and positive")

    candidate_count = len(pairs)
    uniform = np.full(candidate_count, 1.0 / candidate_count, dtype=np.float64)
    if initial_probabilities is None:
        probabilities = uniform
    else:
        probabilities = np.asarray(initial_probabilities, dtype=np.float64)
        if probabilities.shape != (candidate_count,) or not np.allclose(
            probabilities, uniform, rtol=0.0, atol=1e-15
        ):
            raise ValueError(
                "initial probabilities must be the registered uniform distribution"
            )

    sigma_generator = ScaledSigmaPoints(
        N_STATE,
        alpha=0.6874,
        beta=2.0,
        kappa=-2.0,
    )
    mapped_states: list[np.ndarray] = []
    mapped_covariances: list[np.ndarray] = []
    for param_index, _ in pairs:
        mapped_state, mapped_covariance = remap_parfc_moments(
            state,
            covariance,
            member_values[source_parameter],
            member_values[param_index],
            sigma_generator,
        )
        mapped_states.append(mapped_state)
        mapped_covariances.append(mapped_covariance)

    filters: list[Any] = []
    transitions: list[Any] = []
    observation_covariance = np.array(
        [[observation_sigma**2]], dtype=np.float64
    )
    reference_level = max(float(state[4]), 0.0)
    for position, (param_index, noise_index) in enumerate(pairs):
        params = member_values[param_index]
        projector = (
            lambda values, p=params: project_hbv_state_conserving_soil_excess(
                values, p
            )
        )
        transition = ForcingTransition(
            params,
            parameter_bounds=bounds,
            state_projector=projector,
        )
        filters.append(
            ModifiedUnscentedFilter(
                state=np.asarray(mapped_states[position], dtype=np.float64),
                covariance=np.asarray(
                    mapped_covariances[position], dtype=np.float64
                ),
                transition=transition,
                observation=RisingRoutedObservation(params),
                process_covariance=(
                    build_state_dependent_lower_groundwater_covariance(
                        reference_level,
                        PROCESS_NOISE_MULTIPLIERS[noise_index],
                    )
                ),
                observation_covariance=observation_covariance.copy(),
                state_projector=projector,
                alpha=0.6874,
                beta=2.0,
                kappa=-2.0,
            )
        )
        transitions.append(transition)

    def pairwise_transform(source, destination, mean, pair_covariance):
        source_parameter_index = pairs[source][0]
        destination_parameter_index = pairs[destination][0]
        return remap_parfc_moments(
            mean,
            pair_covariance,
            member_values[source_parameter_index],
            member_values[destination_parameter_index],
            filters[source].sigma_generator,
        )

    estimator = _construct_estimator(
        filters=filters,
        initial_probabilities=probabilities,
        interaction_mode=interaction_mode,
        pairwise_moment_transform=pairwise_transform,
    )
    return EstimatorRuntime(
        knowledge_mode=knowledge_mode,
        interaction_mode=interaction_mode,
        estimator=estimator,
        transitions=transitions,
        candidate_pairs=pairs,
        members=member_values,
        bounds=bounds,
        sigma_obs=observation_sigma,
        source_param_index=source_parameter,
        destination_param_index=destination_parameter,
        destination_noise_index=destination_noise,
    )


# Fail fast if this module's immutable design constants are internally invalid.
validate_balanced_design([williams_sequence(index) for index in range(N_CELLS)])
