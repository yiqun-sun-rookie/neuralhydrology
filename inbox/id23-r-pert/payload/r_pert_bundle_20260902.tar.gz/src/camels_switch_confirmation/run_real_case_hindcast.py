"""Entry point and holdout access guard for the joint param-noise real-case line.

Implements Task 5 of docs/superpowers/plans/2026-08-25-joint-param-noise-real-case-runner.md.
Every data request must pass :func:`assert_data_request_allowed` before any loader call.
The formal unseal credential file does not exist yet by design; until the user authorizes the
formal evaluation and the credential is written, only design-universe basins on dates outside
1980-01-01..1989-09-30 can be loaded.

The development smoke run exercises center calibration, the 3x3 candidate grid, all four
arms, and the metric summaries on one exposed design basin with a small budget.  It is the
freeze-gate deliverable; it performs no formal evaluation.
"""
from __future__ import annotations

import csv
import json
import time
from pathlib import Path
from typing import Any, Callable, Iterable

import numpy as np
import pandas as pd

from camels_switch_confirmation.real_case_candidates import build_candidate_grid
from camels_switch_confirmation.real_case_center_calibration import (
    LOAD_END,
    LOAD_START,
    calibrate_center,
    load_center_bounds,
)
from camels_switch_confirmation.real_case_filtering import (
    FILTER_ARMS,
    build_real_case_runtime,
    run_filter_arm,
    run_open_loop_arm,
)
from camels_switch_confirmation.real_case_metrics import summarize_arm

REPO_ROOT = Path(__file__).resolve().parents[2]
DESIGN_COVERAGE_CSV = (
    REPO_ROOT / "docs/plans/2026-08-10-camels-parfc-state-interaction-design90-coverage-v01.csv"
)
UNSEAL_CREDENTIAL_PATH = (
    REPO_ROOT
    / "src/camels_switch_confirmation/protocols/joint_param_noise_real_case_unseal.credential.json"
)
FORBIDDEN_START = pd.Timestamp("1980-01-01")
FORBIDDEN_END = pd.Timestamp("1989-09-30")
UNSEAL_SCOPE = "joint_param_noise_real_case_formal_evaluation"
_REQUIRED_CREDENTIAL_FIELDS = (
    "schema_version",
    "unsealed",
    "authorized_by_user",
    "authorized_at",
    "scope",
)


class AccessGuardError(RuntimeError):
    """Raised when a data request would exceed the currently authorized exposure."""


def load_design_basins() -> frozenset[str]:
    """Basin identifiers of the 90-basin design universe (development exposure)."""
    with DESIGN_COVERAGE_CSV.open(encoding="utf-8-sig") as handle:
        return frozenset(row["basin_id"].zfill(8) for row in csv.DictReader(handle))


def _validate_credential(path: Path) -> None:
    try:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exception:
        raise AccessGuardError(f"unseal credential is unreadable: {exception}") from exception
    missing = [field for field in _REQUIRED_CREDENTIAL_FIELDS if field not in payload]
    if missing:
        raise AccessGuardError(f"unseal credential is missing required fields: {missing}")
    if payload["schema_version"] != 1 or payload["unsealed"] is not True:
        raise AccessGuardError("unseal credential must have schema_version 1 and unsealed true")
    if payload["authorized_by_user"] is not True:
        raise AccessGuardError("unseal credential must record explicit user authorization")
    if payload["scope"] != UNSEAL_SCOPE:
        raise AccessGuardError(f"unseal credential scope must be {UNSEAL_SCOPE!r}")


def assert_data_request_allowed(
    basin_id: str,
    start_date: str,
    end_date: str,
    *,
    design_basins: Iterable[str] | None = None,
    unseal_credential: str | Path | None = UNSEAL_CREDENTIAL_PATH,
) -> None:
    """Refuse any request beyond the exposed development universe without an unseal credential."""
    basin = str(basin_id).zfill(8)
    start = pd.Timestamp(start_date)
    end = pd.Timestamp(end_date)
    if end < start:
        raise ValueError("end_date must not precede start_date")
    design = frozenset(design_basins) if design_basins is not None else load_design_basins()
    touches_forbidden = start <= FORBIDDEN_END and end >= FORBIDDEN_START
    outside_design = basin not in design
    if not touches_forbidden and not outside_design:
        return
    credential = Path(unseal_credential) if unseal_credential is not None else None
    if credential is None or not credential.is_file():
        raise AccessGuardError(
            f"request for basin {basin} {start.date()}..{end.date()} requires the formal "
            f"unseal credential (forbidden holdout window 1980-01-01..1989-09-30 or basin "
            f"outside the design universe); the credential does not exist yet"
        )
    _validate_credential(credential)


def run_development_smoke(
    basin_id: str,
    *,
    data_root: str | Path,
    design_basins: Iterable[str] | None = None,
    loader: Callable[..., tuple[pd.DataFrame, pd.Series, float]] | None = None,
    calibrator: Callable[..., dict[str, Any]] | None = None,
    smoke_days: int = 120,
    n_trials: int = 200,
    restart_seeds: tuple[int, ...] = (42,),
    minimum_objective_days: int | None = None,
    sigma_obs: float = 0.2,
    unseal_credential: str | Path | None = None,
) -> dict[str, Any]:
    """Development smoke on one exposed design basin: calibrate, build grid, run four arms."""
    from hydroagent.data_loading import load_camels_basin
    from scl_hydro.hbv_lite_cma_calibrate import calibrate_hbv_lite_cma

    started = time.perf_counter()
    design = frozenset(design_basins) if design_basins is not None else load_design_basins()
    assert_data_request_allowed(
        basin_id, LOAD_START, LOAD_END, design_basins=design, unseal_credential=unseal_credential
    )
    loader_function = loader if loader is not None else load_camels_basin
    calibrator_function = calibrator if calibrator is not None else calibrate_hbv_lite_cma

    center_options: dict[str, Any] = {
        "data_root": data_root,
        "n_trials": int(n_trials),
        "restart_seeds": tuple(int(seed) for seed in restart_seeds),
        "loader": loader_function,
        "calibrator": calibrator_function,
    }
    if minimum_objective_days is not None:
        center_options["minimum_objective_days"] = int(minimum_objective_days)
    center = calibrate_center(str(basin_id).zfill(8), **center_options)

    bounds = load_center_bounds()
    grid = build_candidate_grid(center["parameters"], fc_bounds=bounds["parFC"])

    forcing, observations, _ = loader_function(
        str(basin_id).zfill(8),
        data_root=str(data_root),
        start_date=LOAD_START,
        end_date=LOAD_END,
        forcing="maurer",
        pet_method="oudin",
        keep_obs_nan_days=True,
        strict_streamflow_window=True,
    )
    dates = forcing.index
    rain = forcing["prcp"].to_numpy(float)
    pet = forcing["ep"].to_numpy(float)
    temperature = forcing["tmean"].to_numpy(float)
    observed = observations.reindex(dates).to_numpy(float)

    days = int(smoke_days)
    if days <= 0 or days >= len(dates):
        raise ValueError("smoke_days must be positive and shorter than the loaded window")
    split = len(dates) - days
    smoke_observed = observed[split:]
    if not np.all(np.isfinite(smoke_observed)):
        raise ValueError("smoke window requires finite observations on every day")

    warmup = run_open_loop_arm(
        center["parameters"], rain[:split], pet[:split], temperature[:split], bounds=bounds
    )
    warm_state = warmup["final_state"]

    arms: dict[str, dict[str, Any]] = {}
    open_loop = run_open_loop_arm(
        center["parameters"], rain[split:], pet[split:], temperature[split:],
        bounds=bounds, initial_state=warm_state,
    )
    arms["open_loop_center"] = summarize_arm(
        smoke_observed,
        open_loop["forecast_mean"][:, None],
        np.full((days, 1), float(sigma_obs) ** 2),
        np.ones((days, 1)),
    )
    for arm in FILTER_ARMS:
        runtime = build_real_case_runtime(
            arm, grid["members"], sigma_obs=float(sigma_obs), bounds=bounds,
            initial_state=warm_state,
        )
        output = run_filter_arm(runtime, rain[split:], pet[split:], temperature[split:], smoke_observed)
        arms[arm] = summarize_arm(
            smoke_observed,
            output["candidate_forecast_means"],
            output["candidate_forecast_variances"],
            output["prior_probabilities"],
        )

    return {
        "basin_id": str(basin_id).zfill(8),
        "center_fit_nse": center["fit_nse"],
        "candidate_grid": {
            "actual_fc_multipliers": grid["actual_fc_multipliers"],
            "clipped": grid["clipped"],
            "candidate_collapse": grid["candidate_collapse"],
        },
        "arms": arms,
        "smoke_days": days,
        "sigma_obs": float(sigma_obs),
        "elapsed_seconds": time.perf_counter() - started,
    }
