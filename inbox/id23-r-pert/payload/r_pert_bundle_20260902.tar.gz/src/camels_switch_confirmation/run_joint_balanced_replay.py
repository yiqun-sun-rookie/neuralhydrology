"""Run the registered balanced six-cell independent-replay experiment.

This runner deliberately has no continuous-estimation path.  Every switch is
replayed from the immutable truth state immediately before the registered
boundary, with a fresh uniform candidate prior and an identity within-stage
transition matrix.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import threading
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

THREAD_ENVIRONMENT_KEYS = (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
)
INITIAL_THREAD_ENVIRONMENT = {
    key: os.environ.get(key) for key in THREAD_ENVIRONMENT_KEYS
}

import numpy as np
import pandas as pd

from camels_switch_confirmation.bank import build_bank
from camels_switch_confirmation.g1_precheck import PARAM_KEYS, STATE_NAMES
from camels_switch_confirmation.g2_switch_confirmation import (
    LAG_CAP,
    N_STATE,
    _atomic_save_npz,
)
from camels_switch_confirmation.joint_balanced_replay import (
    FORMAL_SEEDS,
    PARAMETER_FACTORS,
    PROCESS_NOISE_MULTIPLIERS,
    build_estimator_runtime,
    cell_index,
    cell_pair,
    load_registered_config,
    sequence_for_basin_seed,
    sha256_file,
    validate_balanced_design,
    williams_sequence,
)
from camels_switch_confirmation.joint_same_observation import (
    TruthObservationBundle,
    generate_truth_observation_bundle,
)


REPO_ROOT = Path(__file__).resolve().parents[2]
CONFIG_PATH = Path(
    "src/camels_switch_confirmation/configs/"
    "joint_param_noise_balanced_replay_v01.json"
)
ARM_MODES = {"C": "full", "P": "pairwise_path_postcollapse"}
KNOWLEDGE_MODES = ("joint_unknown", "param_known", "noise_known")
EXPECTED_TRUTH_BUNDLES = 36 * len(FORMAL_SEEDS)
EXPECTED_TASKS = EXPECTED_TRUTH_BUNDLES * len(ARM_MODES) * len(KNOWLEDGE_MODES)
EXPECTED_EVENTS = EXPECTED_TASKS * 5


def _resolve_repo_input(config: dict, key: str, repo_root: Path = REPO_ROOT) -> Path:
    """Resolve one configured input while forbidding machine-specific paths."""

    try:
        registered = Path(config["input_paths"][key])
    except KeyError as exception:
        raise ValueError(f"configuration lacks input path: {key}") from exception
    if registered.is_absolute():
        raise ValueError(f"configured input path must be repo-relative: {key}")
    if any(part in {".", ".."} for part in registered.parts):
        raise ValueError(f"configured input path escapes the repository: {key}")
    root = Path(repo_root).absolute()
    resolved = (root / registered).absolute()
    try:
        resolved.relative_to(root)
    except ValueError as exception:
        raise ValueError(f"configured input path escapes the repository: {key}") from exception
    return resolved


def admitted_basins(
    config: dict | None = None,
    *,
    repo_root: Path = REPO_ROOT,
) -> list[str]:
    """Read and cross-check the two repo-relative admission records."""

    registered = (
        load_registered_config(repo_root, verify_hashes=False)
        if config is None
        else config
    )
    list_path = _resolve_repo_input(registered, "admitted_basins", repo_root)
    admission_path = _resolve_repo_input(registered, "admission_table", repo_root)
    listed = pd.read_csv(list_path, dtype={"basin_id": str})
    admission = pd.read_csv(admission_path, dtype={"basin_id": str})
    if "basin_id" not in listed or "basin_id" not in admission:
        raise ValueError("admission records must contain basin_id")
    listed_ids = listed["basin_id"].str.zfill(8).tolist()
    if "admitted" in admission:
        mask = admission["admitted"].astype(str).str.lower().isin(("true", "1"))
        admission = admission[mask]
    admitted_ids = admission["basin_id"].str.zfill(8).tolist()
    expected_count = int(registered.get("basin_contract", {}).get("count", 36))
    if len(listed_ids) != expected_count or len(set(listed_ids)) != expected_count:
        raise ValueError(
            f"admitted basin list must contain {expected_count} unique basins"
        )
    if len(admitted_ids) != expected_count or set(admitted_ids) != set(listed_ids):
        raise ValueError("admission table and admitted basin list disagree")
    return listed_ids


def _initial_covariance(state, fraction=0.001) -> np.ndarray:
    values = np.asarray(state, dtype=np.float64)
    if values.shape != (N_STATE,):
        raise ValueError(f"initial state must have shape ({N_STATE},)")
    scales = np.maximum(np.abs(values), 1.0)
    return np.diag((float(fraction) * scales)**2)


def _load_basin_case(
    basin_id: str,
    window_days: int,
    *,
    config: dict,
    repo_root: Path = REPO_ROOT,
) -> dict:
    """Load one case exclusively through repo-relative registered inputs."""

    from hydroagent.data_loading import load_camels_basin
    from scl_hydro.hbv_lite_numpy import resolve_hbv_bounds

    basin = str(basin_id).zfill(8)
    parameter_path = _resolve_repo_input(config, "parameter_table", repo_root)
    noise_path = _resolve_repo_input(config, "observation_noise_table", repo_root)
    data_root = _resolve_repo_input(config, "camels_data_root", repo_root)
    parameter_frame = pd.read_csv(parameter_path, dtype={"basin_id": str})
    parameter_frame["basin_id"] = parameter_frame["basin_id"].str.zfill(8)
    selected = parameter_frame[parameter_frame["basin_id"] == basin]
    if len(selected) != 1:
        raise ValueError(f"parameter table must contain one row for {basin}")
    row = selected.iloc[0]
    parameters = {key: float(row[f"p_{key}"]) for key in PARAM_KEYS}
    lag_capped = parameters["lag_time"] > LAG_CAP
    parameters["lag_time"] = min(parameters["lag_time"], LAG_CAP)
    initial_hydrology = np.asarray(
        [float(row[f"state_{name}"]) for name in STATE_NAMES], dtype=np.float64
    )
    bounds = resolve_hbv_bounds("v5")
    bank_members, clipped = build_bank(parameters, bounds["parFC"])
    if any(clipped[:2]):
        raise ValueError(f"registered admitted basin has a clipped candidate: {basin}")
    members = tuple(bank_members[:2])

    noise_frame = pd.read_csv(noise_path, dtype={"basin_id": str})
    noise_frame["basin_id"] = noise_frame["basin_id"].str.zfill(8)
    selected_noise = noise_frame[noise_frame["basin_id"] == basin]
    if len(selected_noise) != 1:
        raise ValueError(f"noise table must contain one row for {basin}")
    sigma_obs = float(selected_noise.iloc[0]["sigma_obs"])

    start = pd.Timestamp(config["time_contract"]["window_start"])
    end = start + pd.Timedelta(days=int(window_days) - 1)
    forcing, _observed, _area = load_camels_basin(
        basin,
        data_root=data_root,
        start_date=start.strftime("%Y-%m-%d"),
        end_date=end.strftime("%Y-%m-%d"),
        forcing="maurer",
        pet_method="oudin",
        keep_obs_nan_days=True,
    )
    if len(forcing) != int(window_days):
        raise ValueError(
            f"forcing must contain exactly {int(window_days)} days for {basin}"
        )
    required = {"prcp", "ep", "tmean"}
    if not required.issubset(forcing.columns):
        raise ValueError(f"forcing lacks required columns for {basin}: {required}")
    return {
        "members": members,
        "initial_hydrology": initial_hydrology,
        "bounds": bounds,
        "sigma_obs": sigma_obs,
        "rain": forcing["prcp"].to_numpy(dtype=np.float64),
        "pet": forcing["ep"].to_numpy(dtype=np.float64),
        "temperature": forcing["tmean"].to_numpy(dtype=np.float64),
        "lag_capped": bool(lag_capped),
    }


def _current_runtime_fingerprint() -> dict:
    import scipy

    return {
        "python_executable_local": Path(sys.executable).resolve().as_posix(),
        "python_executable_sha256": sha256_file(Path(sys.executable)),
        "python_version": platform.python_version(),
        "numpy_version": np.__version__,
        "pandas_version": pd.__version__,
        "scipy_version": scipy.__version__,
        "byteorder": sys.byteorder,
        "float_mantissa_bits": int(sys.float_info.mant_dig),
        "thread_environment": dict(INITIAL_THREAD_ENVIRONMENT),
    }


def _verify_runtime_contract(config: dict, *, route: str = "local") -> dict:
    """Reject runtime drift instead of silently changing thread settings."""

    if route == "hpc":
        expected = config.get("runtime_contract_hpc")
        if not isinstance(expected, dict) or not expected:
            raise RuntimeError(
                "HPC runtime is not registered; register and freeze the HPC "
                "environment before execution"
            )
    elif route == "local":
        expected = config.get("runtime_contract", {})
    else:
        raise ValueError(f"unknown runtime route: {route}")
    observed = _current_runtime_fingerprint()
    for key, value in observed.items():
        if expected.get(key) != value:
            if key == "thread_environment":
                for thread_key in THREAD_ENVIRONMENT_KEYS:
                    if expected.get(key, {}).get(thread_key) != value.get(thread_key):
                        raise RuntimeError(
                            f"runtime contract changed: {thread_key}="
                            f"{value.get(thread_key)!r} != "
                            f"{expected.get(key, {}).get(thread_key)!r}"
                        )
            raise RuntimeError(
                f"runtime contract changed: {key}={value!r} != {expected.get(key)!r}"
            )
    return observed


def _time_contract(config: dict) -> dict:
    return config.get("time_contract", {})


def _random_streams(config: dict) -> dict:
    return config.get("random_streams", {})


def _stage_days(config: dict) -> int:
    return int(_time_contract(config).get("stage_days", 180))


def _truth_stream_identity(config: dict, basin_id: str, seed: int) -> tuple[int, ...]:
    streams = _random_streams(config)
    return (
        int(streams.get("seed_entropy", 20260821)),
        int(basin_id),
        int(seed),
        int(streams.get("truth_process_noise_tag", 30)),
    )


def _observation_stream_identity(
    config: dict, basin_id: str, seed: int
) -> tuple[int, ...]:
    streams = _random_streams(config)
    return (
        int(streams.get("seed_entropy", 20260821)),
        int(basin_id),
        int(seed),
        int(streams.get("observation_error_tag", 31)),
    )


@dataclass(frozen=True, order=True)
class TaskIdentity:
    """One basin-seed-algorithm-knowledge-mode replay identity."""

    basin_id: str
    seed: int
    arm_id: str
    knowledge_mode: str

    @property
    def task_id(self) -> str:
        return (
            f"{self.basin_id}_s{self.seed}_{self.arm_id}_"
            f"{self.knowledge_mode}"
        )


def build_task_table(
    basins: Iterable[str],
    seeds: Iterable[int] = FORMAL_SEEDS,
    arms: Iterable[str] = tuple(ARM_MODES),
    knowledge_modes: Iterable[str] = KNOWLEDGE_MODES,
) -> list[TaskIdentity]:
    """Build the exact cross-product while rejecting ambiguous identities."""

    basin_values = tuple(str(value).zfill(8) for value in basins)
    seed_values = tuple(int(value) for value in seeds)
    arm_values = tuple(str(value) for value in arms)
    mode_values = tuple(str(value) for value in knowledge_modes)
    if len(set(basin_values)) != len(basin_values):
        raise ValueError("basin identifiers contain duplicates")
    if len(set(seed_values)) != len(seed_values):
        raise ValueError("seeds contain duplicates")
    if any(value not in ARM_MODES for value in arm_values):
        raise ValueError("task table contains an unknown interaction arm")
    if any(value not in KNOWLEDGE_MODES for value in mode_values):
        raise ValueError("task table contains an unknown knowledge mode")
    tasks = [
        TaskIdentity(basin, seed, arm, mode)
        for basin in basin_values
        for seed in seed_values
        for arm in arm_values
        for mode in mode_values
    ]
    if len({task.task_id for task in tasks}) != len(tasks):
        raise ValueError("task identity cross-product contains duplicates")
    return tasks


def truth_bundle_path(root: Path, basin_id: str, seed: int) -> Path:
    return Path(root) / "truth" / "bundles" / f"{str(basin_id).zfill(8)}_s{int(seed)}.npz"


def task_output_path(root: Path, task: TaskIdentity) -> Path:
    return (
        Path(root)
        / "arms"
        / task.arm_id
        / task.knowledge_mode
        / f"{task.basin_id}_s{task.seed}.npz"
    )


def _candidate_count(knowledge_mode: str) -> int:
    counts = {"joint_unknown": 6, "param_known": 3, "noise_known": 2}
    try:
        return counts[str(knowledge_mode)]
    except KeyError as exception:
        raise ValueError(f"unknown knowledge mode: {knowledge_mode}") from exception


def _transition_type(source: tuple[int, int], destination: tuple[int, int]) -> str:
    parameter_changed = source[0] != destination[0]
    noise_changed = source[1] != destination[1]
    if parameter_changed and noise_changed:
        return "joint"
    if parameter_changed:
        return "parameter_only"
    if noise_changed:
        return "noise_only"
    raise ValueError("source and destination cells are identical")


def _reference_transition_index(runtime) -> int:
    for index, (parameter_index, _) in enumerate(runtime.candidate_pairs):
        if parameter_index == 0:
            return index
    return 0


def _run_estimator_day(runtime, bundle: TruthObservationBundle, day: int):
    runtime.set_forcing(bundle.rain[day], bundle.pet[day], bundle.temperature[day])
    reference = _reference_transition_index(runtime)
    predicted_reference = runtime.transitions[reference](
        runtime.estimator.state.copy()
    )
    runtime.assign_process_covariances(float(predicted_reference[4]))
    return runtime.estimator.step(np.array([bundle.observations[day]]))


def run_replay_arrays(
    bundle: TruthObservationBundle,
    members,
    sigma_obs,
    bounds,
    knowledge_mode,
    interaction_mode,
    switch_days,
    replay_days,
    initial_covariance_fraction,
) -> dict[str, np.ndarray]:
    """Replay registered switches independently from exact true pre-states."""

    switch_values = tuple(int(value) for value in switch_days)
    replay_count = int(replay_days)
    if not switch_values:
        raise ValueError("at least one switch day is required")
    if replay_count <= 0:
        raise ValueError("replay days must be positive")
    if len(members) != 2:
        raise ValueError("balanced replay requires exactly two parameter members")
    candidate_count = _candidate_count(str(knowledge_mode))
    event_count = len(switch_values)

    probability_shape = (event_count, replay_count, candidate_count)
    state_shape = (event_count, replay_count, N_STATE)
    probabilities = np.empty(probability_shape, dtype=np.float64)
    prior_probabilities = np.empty_like(probabilities)
    log_probabilities = np.empty_like(probabilities)
    combined_states = np.empty(state_shape, dtype=np.float64)
    combined_covariance_diagonals = np.empty_like(combined_states)
    candidate_param_indices = np.empty(probability_shape, dtype=np.int64)
    candidate_noise_indices = np.empty_like(candidate_param_indices)
    initial_truth_states = np.empty((event_count, N_STATE), dtype=np.float64)
    initial_mapped_states = np.empty(
        (event_count, candidate_count, N_STATE), dtype=np.float64
    )
    initial_mapped_covariance_diagonals = np.empty_like(initial_mapped_states)
    source_cells = np.empty((event_count, 2), dtype=np.int64)
    destination_cells = np.empty_like(source_cells)
    source_cell_indices = np.empty(event_count, dtype=np.int64)
    destination_cell_indices = np.empty(event_count, dtype=np.int64)
    sequence_positions = np.empty(event_count, dtype=np.int64)
    transition_types = np.empty(event_count, dtype="<U14")
    truth_pre_states = np.empty_like(combined_states)
    truth_post_states = np.empty_like(combined_states)
    observations = np.empty((event_count, replay_count), dtype=np.float64)
    truth_q = np.empty_like(observations)
    truth_param_indices = np.empty((event_count, replay_count), dtype=np.int64)
    truth_noise_indices = np.empty_like(truth_param_indices)
    truth_cell_indices = np.empty_like(truth_param_indices)
    rain = np.empty_like(observations)
    pet = np.empty_like(observations)
    temperature = np.empty_like(observations)
    calendar_day_indices = np.empty_like(truth_param_indices)

    stage_days = int(bundle.stage_days)
    sequence = np.asarray(bundle.sequence, dtype=np.int64)
    for event_index, switch_day in enumerate(switch_values):
        if (
            switch_day <= 0
            or switch_day % stage_days != 0
            or switch_day + replay_count > len(bundle.observations)
        ):
            raise ValueError(f"switch day is outside a complete truth boundary: {switch_day}")
        sequence_position = switch_day // stage_days
        if sequence_position <= 0 or sequence_position >= len(sequence):
            raise ValueError(f"switch day has no registered sequence boundary: {switch_day}")
        source = (
            int(bundle.truth_param_indices[switch_day - 1]),
            int(bundle.truth_noise_indices[switch_day - 1]),
        )
        destination = (
            int(bundle.truth_param_indices[switch_day]),
            int(bundle.truth_noise_indices[switch_day]),
        )
        if tuple(sequence[sequence_position - 1]) != source:
            raise ValueError("truth source does not match its registered sequence")
        if tuple(sequence[sequence_position]) != destination:
            raise ValueError("truth destination does not match its registered sequence")
        if source == destination:
            raise ValueError(f"switch day does not change truth: {switch_day}")

        initial_state = bundle.pre_states[switch_day].copy()
        initial_covariance = _initial_covariance(
            initial_state, float(initial_covariance_fraction)
        )
        runtime = build_estimator_runtime(
            knowledge_mode=str(knowledge_mode),
            interaction_mode=str(interaction_mode),
            members=tuple(members),
            initial_state=initial_state,
            initial_covariance=initial_covariance,
            initial_probabilities=None,
            sigma_obs=float(sigma_obs),
            bounds=bounds,
            source_param_index=source[0],
            destination_param_index=destination[0],
            destination_noise_index=destination[1],
        )
        if len(runtime.candidate_pairs) != candidate_count:
            raise ValueError("runtime candidate count changed")

        initial_truth_states[event_index] = initial_state
        initial_mapped_states[event_index] = np.asarray(
            [candidate.state for candidate in runtime.estimator.filters]
        )
        initial_mapped_covariance_diagonals[event_index] = np.asarray(
            [np.diag(candidate.covariance) for candidate in runtime.estimator.filters]
        )
        source_cells[event_index] = source
        destination_cells[event_index] = destination
        source_cell_indices[event_index] = cell_index(*source)
        destination_cell_indices[event_index] = cell_index(*destination)
        sequence_positions[event_index] = sequence_position
        transition_types[event_index] = _transition_type(source, destination)

        for offset in range(replay_count):
            day = switch_day + offset
            if (
                int(bundle.truth_param_indices[day]) != destination[0]
                or int(bundle.truth_noise_indices[day]) != destination[1]
            ):
                raise ValueError("replay crosses out of its destination stage")
            result = _run_estimator_day(runtime, bundle, day)
            probabilities[event_index, offset] = result.posterior_probabilities
            prior_probabilities[event_index, offset] = result.prior_probabilities
            log_probabilities[event_index, offset] = result.posterior_log_probabilities
            combined_states[event_index, offset] = result.combined_state
            combined_covariance_diagonals[event_index, offset] = np.diag(
                result.combined_covariance
            )
            candidate_param_indices[event_index, offset] = [
                pair[0] for pair in runtime.candidate_pairs
            ]
            candidate_noise_indices[event_index, offset] = [
                pair[1] for pair in runtime.candidate_pairs
            ]
            truth_pre_states[event_index, offset] = bundle.pre_states[day]
            truth_post_states[event_index, offset] = bundle.post_states[day]
            observations[event_index, offset] = bundle.observations[day]
            truth_q[event_index, offset] = bundle.truth_q[day]
            truth_param_indices[event_index, offset] = bundle.truth_param_indices[day]
            truth_noise_indices[event_index, offset] = bundle.truth_noise_indices[day]
            truth_cell_indices[event_index, offset] = bundle.truth_cell_indices[day]
            rain[event_index, offset] = bundle.rain[day]
            pet[event_index, offset] = bundle.pet[day]
            temperature[event_index, offset] = bundle.temperature[day]
            calendar_day_indices[event_index, offset] = day

    uniform = np.full(candidate_count, 1.0 / candidate_count, dtype=np.float64)
    if not np.allclose(prior_probabilities[:, 0], uniform, rtol=0.0, atol=1e-15):
        raise ValueError("first replay prior is not uniform")
    if replay_count > 1 and not np.allclose(
        prior_probabilities[:, 1:], probabilities[:, :-1], rtol=0.0, atol=1e-12
    ):
        raise ValueError("identity-transition prior recursion changed")
    if not np.all(np.isfinite(probabilities)):
        raise ValueError("replay probabilities contain non-finite values")
    if np.any(np.isnan(log_probabilities)) or np.any(np.isposinf(log_probabilities)):
        raise ValueError("replay log probabilities contain NaN or positive infinity")
    if not np.allclose(probabilities.sum(axis=2), 1.0, rtol=0.0, atol=1e-12):
        raise ValueError("replay probabilities do not sum to one")
    finite_arrays = (
        combined_states,
        combined_covariance_diagonals,
        initial_truth_states,
        initial_mapped_states,
        initial_mapped_covariance_diagonals,
        truth_pre_states,
        truth_post_states,
        observations,
    )
    if any(not np.all(np.isfinite(values)) for values in finite_arrays):
        raise ValueError("replay state or observation arrays contain non-finite values")
    if np.any(combined_covariance_diagonals < -1e-12):
        raise ValueError("combined covariance diagonal is negative beyond tolerance")
    if np.any(initial_mapped_covariance_diagonals < -1e-12):
        raise ValueError("initial mapped covariance diagonal is negative beyond tolerance")
    if not np.array_equal(initial_truth_states, bundle.pre_states[list(switch_values)]):
        raise ValueError("replay did not reset to the exact true pre-switch state")

    return {
        "probabilities": probabilities,
        "prior_probabilities": prior_probabilities,
        "log_probabilities": log_probabilities,
        "candidate_param_indices": candidate_param_indices,
        "candidate_noise_indices": candidate_noise_indices,
        "combined_states": combined_states,
        "combined_covariance_diagonals": combined_covariance_diagonals,
        "initial_truth_states": initial_truth_states,
        "initial_mapped_states": initial_mapped_states,
        "initial_mapped_covariance_diagonals": initial_mapped_covariance_diagonals,
        "source_cells": source_cells,
        "destination_cells": destination_cells,
        "source_cell_indices": source_cell_indices,
        "destination_cell_indices": destination_cell_indices,
        "sequence_positions": sequence_positions,
        "transition_types": transition_types,
        "truth_pre_states": truth_pre_states,
        "truth_post_states": truth_post_states,
        "observations": observations,
        "truth_q": truth_q,
        "truth_param_indices": truth_param_indices,
        "truth_noise_indices": truth_noise_indices,
        "truth_cell_indices": truth_cell_indices,
        "rain": rain,
        "pet": pet,
        "temperature": temperature,
        "calendar_day_indices": calendar_day_indices,
        "event_offsets": np.arange(1, replay_count + 1, dtype=np.int64),
        "switch_days": np.asarray(switch_values, dtype=np.int64),
    }


def _bundle_array_names() -> tuple[str, ...]:
    return (
        "rain",
        "pet",
        "temperature",
        "pre_states",
        "post_states",
        "truth_q",
        "observations",
        "observation_errors",
        "truth_param_indices",
        "truth_noise_indices",
        "truth_cell_indices",
        "truth_parfc",
        "sequence",
    )


def _assert_bundles_bitwise_equal(
    observed: TruthObservationBundle,
    expected: TruthObservationBundle,
) -> None:
    for name in _bundle_array_names():
        if not np.array_equal(getattr(observed, name), getattr(expected, name)):
            raise ValueError(f"truth round-trip changed array: {name}")
    if observed.stage_days != expected.stage_days:
        raise ValueError("truth round-trip changed stage days")
    if observed.clip_count != expected.clip_count:
        raise ValueError("truth round-trip changed clip count")


def _bundle_content_sha256(bundle: TruthObservationBundle) -> str:
    digest = hashlib.sha256()
    for name in _bundle_array_names():
        values = np.ascontiguousarray(getattr(bundle, name))
        digest.update(name.encode("utf-8"))
        digest.update(values.dtype.str.encode("ascii"))
        digest.update(np.asarray(values.shape, dtype=np.int64).tobytes())
        digest.update(values.tobytes())
    digest.update(np.asarray([bundle.stage_days, bundle.clip_count], dtype=np.int64).tobytes())
    return digest.hexdigest()


def _truth_sequence(basin_rank: int, seed: int, development_sequence_index=None):
    if int(seed) in FORMAL_SEEDS:
        return sequence_for_basin_seed(int(basin_rank), int(seed))
    if development_sequence_index is None:
        raise ValueError("nonformal truth seeds require a development sequence index")
    index = int(development_sequence_index)
    return tuple(cell_pair(cell) for cell in williams_sequence(index))


def _truth_rng(config: dict, basin_id: str, seed: int) -> np.random.Generator:
    return np.random.default_rng(np.random.SeedSequence(_truth_stream_identity(config, basin_id, seed)))


def _observation_rng(config: dict, basin_id: str, seed: int) -> np.random.Generator:
    return np.random.default_rng(
        np.random.SeedSequence(_observation_stream_identity(config, basin_id, seed))
    )


def _generate_truth_bundle(
    case: dict,
    sequence,
    basin_id: str,
    seed: int,
    config: dict,
) -> TruthObservationBundle:
    stage_days = _stage_days(config)
    return generate_truth_observation_bundle(
        sequence=tuple(tuple(value) for value in sequence),
        members=tuple(case["members"][:2]),
        rain=case["rain"],
        pet=case["pet"],
        temperature=case["temperature"],
        init_hydro=case["initial_hydrology"],
        truth_rng=_truth_rng(config, basin_id, seed),
        observation_rng=_observation_rng(config, basin_id, seed),
        observation_sigma=case["sigma_obs"],
        bounds=case["bounds"],
        stage_days=stage_days,
    )


def _load_truth_bundle(path: Path) -> TruthObservationBundle:
    with np.load(path, allow_pickle=False) as archive:
        return TruthObservationBundle(
            rain=archive["rain"].copy(),
            pet=archive["pet"].copy(),
            temperature=archive["temperature"].copy(),
            pre_states=archive["pre_states"].copy(),
            post_states=archive["post_states"].copy(),
            truth_q=archive["truth_q"].copy(),
            observations=archive["observations"].copy(),
            observation_errors=archive["observation_errors"].copy(),
            truth_param_indices=archive["truth_param_indices"].copy(),
            truth_noise_indices=archive["truth_noise_indices"].copy(),
            truth_cell_indices=archive["truth_cell_indices"].copy(),
            truth_parfc=archive["truth_parfc"].copy(),
            sequence=archive["sequence"].copy(),
            stage_days=int(archive["stage_days"]),
            clip_count=int(archive["clip_count"]),
        )


def _registered_json(config: dict, key: str) -> np.ndarray:
    return np.array(
        json.dumps(
            config.get(key, {}),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    )


def _save_truth_bundle_new(
    target: Path,
    bundle: TruthObservationBundle,
    *,
    basin_id: str,
    basin_rank: int,
    seed: int,
    sequence_index: int,
    case: dict,
    config: dict,
    config_hash: str,
) -> None:
    members = tuple(case["members"][:2])
    parameter_values = np.asarray(
        [[float(member[key]) for key in PARAM_KEYS] for member in members],
        dtype=np.float64,
    )
    stage_days = int(bundle.stage_days)
    n_days = len(bundle.observations)
    _atomic_save_npz(
        target,
        **{name: getattr(bundle, name) for name in _bundle_array_names()},
        stage_days=np.array(stage_days, dtype=np.int64),
        clip_count=np.array(bundle.clip_count, dtype=np.int64),
        basin_id=np.array(str(basin_id)),
        basin_rank=np.array(int(basin_rank), dtype=np.int64),
        seed=np.array(int(seed), dtype=np.int64),
        sequence_index=np.array(int(sequence_index), dtype=np.int64),
        switch_days=np.arange(1, len(bundle.sequence), dtype=np.int64) * stage_days,
        stage_indices=np.repeat(
            np.arange(len(bundle.sequence), dtype=np.int64), stage_days
        )[:n_days],
        truth_rng_identity=np.asarray(
            _truth_stream_identity(config, basin_id, seed), dtype=np.int64
        ),
        observation_rng_identity=np.asarray(
            _observation_stream_identity(config, basin_id, seed), dtype=np.int64
        ),
        candidate_parameter_keys=np.asarray(PARAM_KEYS),
        candidate_parameter_values=parameter_values,
        candidate_parameter_factors=np.asarray(PARAMETER_FACTORS, dtype=np.float64),
        candidate_process_noise_multipliers=np.asarray(
            PROCESS_NOISE_MULTIPLIERS, dtype=np.float64
        ),
        observation_sigma=np.array(float(case["sigma_obs"]), dtype=np.float64),
        lag_capped=np.array(bool(case["lag_capped"])),
        config_json=np.array(
            json.dumps(config, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        ),
        config_sha256=np.array(config_hash),
        registered_inputs_json=_registered_json(config, "registered_input_hashes"),
        registered_implementation_json=_registered_json(
            config, "registered_implementation_hashes"
        ),
        truth_content_sha256=np.array(_bundle_content_sha256(bundle)),
        round_trip_bitwise_verified=np.array(True),
    )


def _truth_worker(arguments):
    (
        basin_id,
        basin_rank,
        seed,
        output_root,
        config,
        config_hash,
        development_sequence_index,
    ) = arguments
    started = time.time()
    target = truth_bundle_path(Path(output_root), basin_id, seed)
    try:
        stage_days = _stage_days(config)
        sequence = _truth_sequence(
            basin_rank, seed, development_sequence_index=development_sequence_index
        )
        case = _load_basin_case(
            str(basin_id),
            len(sequence) * stage_days,
            config=config,
            repo_root=REPO_ROOT,
        )
        members = tuple(case["members"][:2])
        if len(members) != 2:
            raise ValueError("parameter bank did not provide two balanced members")
        observed_factors = tuple(
            float(member["parFC"]) / float(members[0]["parFC"]) for member in members
        )
        if not np.allclose(observed_factors, PARAMETER_FACTORS, rtol=0.0, atol=1e-12):
            raise ValueError("parameter bank factors changed")
        bundle = _generate_truth_bundle(case, sequence, basin_id, seed, config)
        repeated = _generate_truth_bundle(case, sequence, basin_id, seed, config)
        _assert_bundles_bitwise_equal(bundle, repeated)
        if bundle.clip_count != 0:
            raise ValueError("truth generation produced a nonzero clip count")
        target.parent.mkdir(parents=True, exist_ok=True)
        sequence_index = (
            (int(basin_rank) + FORMAL_SEEDS.index(int(seed))) % 6
            if int(seed) in FORMAL_SEEDS
            else int(development_sequence_index)
        )
        _save_truth_bundle_new(
            target,
            bundle,
            basin_id=str(basin_id),
            basin_rank=int(basin_rank),
            seed=int(seed),
            sequence_index=sequence_index,
            case=case,
            config=config,
            config_hash=config_hash,
        )
        loaded = _load_truth_bundle(target)
        _assert_bundles_bitwise_equal(loaded, repeated)
        return {
            "task_id": f"{str(basin_id).zfill(8)}_s{int(seed)}",
            "run_status": "success",
            "clip_count": int(bundle.clip_count),
            "truth_sha256": sha256_file(target),
            "truth_content_sha256": _bundle_content_sha256(bundle),
            "elapsed_seconds": time.time() - started,
        }
    except Exception as exception:  # noqa: BLE001 - failure is preserved in evidence
        return {
            "task_id": f"{str(basin_id).zfill(8)}_s{int(seed)}",
            "run_status": "failed",
            "error_message": f"{type(exception).__name__}: {exception}",
            "target": str(target),
            "elapsed_seconds": time.time() - started,
        }


def _load_truth_runtime_inputs(path: Path):
    from scl_hydro.hbv_lite_numpy import resolve_hbv_bounds

    with np.load(path, allow_pickle=False) as archive:
        keys = tuple(str(value) for value in archive["candidate_parameter_keys"])
        values = archive["candidate_parameter_values"].copy()
        if keys != tuple(PARAM_KEYS) or values.shape != (2, len(PARAM_KEYS)):
            raise ValueError("truth bundle candidate parameter table changed")
        members = tuple(
            {key: float(value) for key, value in zip(keys, row)} for row in values
        )
        sigma_obs = float(archive["observation_sigma"])
        switch_days = tuple(int(value) for value in archive["switch_days"])
        stored_content_hash = str(archive["truth_content_sha256"])
        config_hash = str(archive["config_sha256"])
        basin_rank = int(archive["basin_rank"])
        sequence_index = int(archive["sequence_index"])
    bundle = _load_truth_bundle(path)
    if _bundle_content_sha256(bundle) != stored_content_hash:
        raise ValueError("truth bundle content hash disagrees with its arrays")
    return {
        "bundle": bundle,
        "members": members,
        "sigma_obs": sigma_obs,
        "bounds": resolve_hbv_bounds("v5"),
        "switch_days": switch_days,
        "config_hash": config_hash,
        "basin_rank": basin_rank,
        "sequence_index": sequence_index,
    }


def _task_worker(arguments):
    task, truth_root, output_root, config, config_hash, replay_days = arguments
    started = time.time()
    target = task_output_path(Path(output_root), task)
    try:
        truth_path = truth_bundle_path(Path(truth_root), task.basin_id, task.seed)
        if not truth_path.is_file():
            raise FileNotFoundError(f"truth bundle is missing: {truth_path}")
        truth_hash_before = sha256_file(truth_path)
        inputs = _load_truth_runtime_inputs(truth_path)
        if inputs["config_hash"] != config_hash:
            raise ValueError("truth bundle configuration hash changed")
        bundle = inputs["bundle"]
        if bundle.clip_count != 0:
            raise ValueError("truth bundle contains a nonzero clip count")
        arrays = run_replay_arrays(
            bundle=bundle,
            members=inputs["members"],
            sigma_obs=inputs["sigma_obs"],
            bounds=inputs["bounds"],
            knowledge_mode=task.knowledge_mode,
            interaction_mode=ARM_MODES[task.arm_id],
            switch_days=inputs["switch_days"],
            replay_days=int(replay_days),
            initial_covariance_fraction=float(
                config["replay_contract"]["initial_covariance_fraction"]
            ),
        )
        truth_hash_after = sha256_file(truth_path)
        if truth_hash_after != truth_hash_before:
            raise ValueError("truth bundle changed while a replay task was running")
        target.parent.mkdir(parents=True, exist_ok=True)
        compute_elapsed = time.time() - started
        _atomic_save_npz(
            target,
            **arrays,
            task_id=np.array(task.task_id),
            basin_id=np.array(task.basin_id),
            basin_rank=np.array(inputs["basin_rank"], dtype=np.int64),
            seed=np.array(task.seed, dtype=np.int64),
            arm_id=np.array(task.arm_id),
            interaction_mode=np.array(ARM_MODES[task.arm_id]),
            knowledge_mode=np.array(task.knowledge_mode),
            sequence_index=np.array(inputs["sequence_index"], dtype=np.int64),
            truth_bundle_path=np.array(str(truth_path.relative_to(output_root))),
            truth_bundle_sha256=np.array(truth_hash_before),
            truth_content_sha256=np.array(_bundle_content_sha256(bundle)),
            config_sha256=np.array(config_hash),
            registered_inputs_json=_registered_json(
                config, "registered_input_hashes"
            ),
            registered_implementation_json=_registered_json(
                config, "registered_implementation_hashes"
            ),
            observation_sigma=np.array(inputs["sigma_obs"], dtype=np.float64),
            compute_elapsed_seconds=np.array(compute_elapsed, dtype=np.float64),
        )
        return {
            "task_id": task.task_id,
            "basin_id": task.basin_id,
            "seed": int(task.seed),
            "arm_id": task.arm_id,
            "knowledge_mode": task.knowledge_mode,
            "run_status": "success",
            "event_count": len(inputs["switch_days"]),
            "output_sha256": sha256_file(target),
            "truth_bundle_sha256": truth_hash_before,
            "elapsed_seconds": time.time() - started,
        }
    except Exception as exception:  # noqa: BLE001 - failure is preserved in evidence
        return {
            "task_id": task.task_id,
            "basin_id": task.basin_id,
            "seed": int(task.seed),
            "arm_id": task.arm_id,
            "knowledge_mode": task.knowledge_mode,
            "run_status": "failed",
            "error_message": f"{type(exception).__name__}: {exception}",
            "target": str(target),
            "elapsed_seconds": time.time() - started,
        }


def _execute_workers(worker, work, workers):
    count = max(1, int(workers))
    total = len(work)
    progress_step = max(1, total // 20)

    def record_progress(records, result):
        records.append(result)
        completed = len(records)
        if completed == 1 or completed == total or completed % progress_step == 0:
            print(
                f"{worker.__name__}: {completed}/{total} completed",
                flush=True,
            )

    records = []
    if count > 1 and len(work) > 1:
        with ProcessPoolExecutor(max_workers=count) as pool:
            for result in pool.map(worker, work, chunksize=1):
                record_progress(records, result)
        return records
    for item in work:
        record_progress(records, worker(item))
    return records


def _basin_rank_map(
    config: dict,
    *,
    repo_root: Path = REPO_ROOT,
) -> dict[str, int]:
    values = sorted(
        str(value).zfill(8)
        for value in admitted_basins(config, repo_root=repo_root)
    )
    if len(values) != 36 or len(set(values)) != 36:
        raise ValueError("registered basin set must contain 36 unique identifiers")
    return {basin: rank for rank, basin in enumerate(values)}


def _verify_registered_task_table(config: dict, *, require_registered_hash: bool) -> int:
    """Verify every frozen basin-rank, seed, sequence, and directed-edge row."""

    import csv

    relative = Path(config["input_paths"]["formal_task_table"])
    path = REPO_ROOT / relative
    if not path.is_file():
        raise FileNotFoundError(f"formal task table is missing: {path}")
    if require_registered_hash:
        matching = [
            record
            for record in config.get("registered_input_hashes", {}).values()
            if Path(record.get("path", "")) == relative
        ]
        if len(matching) != 1:
            raise ValueError("formal task table must have one registered input hash")
        if sha256_file(path) != str(matching[0]["sha256"]).lower():
            raise ValueError("formal task table SHA-256 changed")
    with path.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    ranks = _basin_rank_map(config)
    expected = []
    for basin, basin_rank in ranks.items():
        for seed_index, seed in enumerate(FORMAL_SEEDS):
            sequence_index = (basin_rank + seed_index) % 6
            cells = williams_sequence(sequence_index)
            expected.append(
                {
                    "basin_id": basin,
                    "basin_rank": str(basin_rank),
                    "seed": str(seed),
                    "seed_index": str(seed_index),
                    "sequence_index": str(sequence_index),
                    "sequence_cells": "|".join(str(cell) for cell in cells),
                    "sequence_pairs": "|".join(
                        f"{source}>{destination}"
                        for source, destination in zip(cells, cells[1:])
                    ),
                }
            )
    if rows != expected:
        raise ValueError("formal task table does not match the sorted-basin Williams mapping")
    return len(rows)


def generate_truth_bundles(
    output_root: Path,
    basins: Iterable[str],
    seeds: Iterable[int],
    workers: int,
    config: dict,
    *,
    development_sequence_index=None,
) -> list[dict]:
    """Generate immutable truth bundles within an already-private result root."""

    root = Path(output_root)
    ranks = _basin_rank_map(config)
    basin_values = tuple(str(value).zfill(8) for value in basins)
    if any(value not in ranks for value in basin_values):
        raise ValueError("truth request contains a basin outside the admitted set")
    seed_values = tuple(int(value) for value in seeds)
    config_hash = sha256_file(REPO_ROOT / CONFIG_PATH)
    work = [
        (
            basin,
            ranks[basin],
            seed,
            str(root),
            config,
            config_hash,
            development_sequence_index,
        )
        for basin in basin_values
        for seed in seed_values
    ]
    if len({(item[0], item[2]) for item in work}) != len(work):
        raise ValueError("truth bundle identities contain duplicates")
    return _execute_workers(_truth_worker, work, workers)


def _run_tasks(
    output_root: Path,
    tasks: list[TaskIdentity],
    workers: int,
    config: dict,
    replay_days: int,
) -> list[dict]:
    config_hash = sha256_file(REPO_ROOT / CONFIG_PATH)
    work = [
        (
            task,
            str(output_root),
            str(output_root),
            config,
            config_hash,
            int(replay_days),
        )
        for task in tasks
    ]
    return _execute_workers(_task_worker, work, workers)


def _write_json_new(path: Path, payload) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")


def _write_records_csv_new(path: Path, records: list[dict]) -> None:
    import csv

    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for record in records for key in record})
    with target.open("x", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="raise")
        writer.writeheader()
        writer.writerows(records)


def _prepare_atomic_output_root(final_root: Path) -> Path:
    """Create a private incomplete root while keeping the formal root absent."""

    final = Path(final_root)
    final.parent.mkdir(parents=True, exist_ok=True)
    if final.exists():
        raise FileExistsError(f"formal output root already exists: {final}")
    abandoned = sorted(final.parent.glob(f"{final.name}.incomplete.*"))
    if abandoned:
        raise FileExistsError(
            "incomplete output identity already exists: "
            + ", ".join(str(path) for path in abandoned)
        )
    working = final.with_name(f"{final.name}.incomplete.{os.getpid()}")
    working.mkdir()
    return working


def _publish_atomic_output_root(working_root: Path, final_root: Path) -> None:
    working = Path(working_root)
    final = Path(final_root)
    if final.exists():
        raise FileExistsError(f"formal output root already exists: {final}")
    if not working.is_dir():
        raise FileNotFoundError(f"incomplete output root is missing: {working}")
    working.replace(final)


def _git_text(*arguments: str) -> str:
    completed = subprocess.run(
        ["git", *arguments],
        cwd=REPO_ROOT,
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def verify_frozen_worktree(config: dict) -> str:
    """Require a hashed, committed, clean implementation before formal execution."""

    if config.get("configuration_status") != "frozen_preexecution":
        raise RuntimeError("formal configuration is not frozen_preexecution")
    if not config.get("registered_input_hashes"):
        raise RuntimeError("registered input hashes are empty")
    if not config.get("registered_implementation_hashes"):
        raise RuntimeError("registered implementation hashes are empty")
    if _git_text("status", "--porcelain", "--untracked-files=all"):
        raise RuntimeError("formal execution requires a clean frozen worktree")
    return _git_text("rev-parse", "HEAD")


def _verify_shared_initial_moments(records: dict[str, dict[str, np.ndarray]]) -> None:
    """Match known-axis initial moments to the same joint candidate bit for bit."""

    if set(records) != set(KNOWLEDGE_MODES):
        raise ValueError("initial-moment audit requires all three knowledge modes")
    joint = records["joint_unknown"]
    for mode in ("param_known", "noise_known"):
        known = records[mode]
        if len(known["initial_mapped_states"]) != len(joint["initial_mapped_states"]):
            raise ValueError("initial-moment event counts disagree")
        for event in range(len(joint["initial_mapped_states"])):
            joint_pairs = [
                (int(parameter), int(noise))
                for parameter, noise in zip(
                    joint["candidate_param_indices"][event, 0],
                    joint["candidate_noise_indices"][event, 0],
                )
            ]
            known_pairs = [
                (int(parameter), int(noise))
                for parameter, noise in zip(
                    known["candidate_param_indices"][event, 0],
                    known["candidate_noise_indices"][event, 0],
                )
            ]
            for known_index, pair in enumerate(known_pairs):
                if pair not in joint_pairs:
                    raise ValueError(f"known-axis candidate is absent from joint mode: {pair}")
                joint_index = joint_pairs.index(pair)
                if not np.array_equal(
                    known["initial_mapped_states"][event, known_index],
                    joint["initial_mapped_states"][event, joint_index],
                ):
                    raise ValueError(
                        f"initial mapped state differs for {mode}, event {event}, {pair}"
                    )
                if not np.array_equal(
                    known["initial_mapped_covariance_diagonals"][event, known_index],
                    joint["initial_mapped_covariance_diagonals"][event, joint_index],
                ):
                    raise ValueError(
                        "initial mapped covariance diagonal differs for "
                        f"{mode}, event {event}, {pair}"
                    )


def _verify_task_observation_identity(
    root: Path,
    tasks: list[TaskIdentity],
    *,
    expected_replay_days: int,
) -> dict:
    reference: dict[tuple[str, int], dict[str, np.ndarray | str]] = {}
    moment_records: dict[
        tuple[str, int, str], dict[str, dict[str, np.ndarray]]
    ] = {}
    checked = 0
    for task in tasks:
        path = task_output_path(root, task)
        if not path.is_file():
            raise FileNotFoundError(f"task output is missing: {path}")
        with np.load(path, allow_pickle=False) as archive:
            candidate_count = _candidate_count(task.knowledge_mode)
            expected_probability_shape = (5, int(expected_replay_days), candidate_count)
            if archive["probabilities"].shape != expected_probability_shape:
                raise ValueError(f"task probability shape changed: {task.task_id}")
            if archive["prior_probabilities"].shape != expected_probability_shape:
                raise ValueError(f"task prior shape changed: {task.task_id}")
            if len(archive["switch_days"]) != 5:
                raise ValueError(f"task event count changed: {task.task_id}")
            uniform = np.full(candidate_count, 1.0 / candidate_count)
            if not np.allclose(
                archive["prior_probabilities"][:, 0],
                uniform,
                rtol=0.0,
                atol=1e-15,
            ):
                raise ValueError(f"task first prior is not uniform: {task.task_id}")
            if not np.allclose(
                archive["prior_probabilities"][:, 1:],
                archive["probabilities"][:, :-1],
                rtol=0.0,
                atol=1e-12,
            ):
                raise ValueError(f"task prior recursion changed: {task.task_id}")
            observed = {
                "observations": archive["observations"].copy(),
                "truth_pre_states": archive["truth_pre_states"].copy(),
                "truth_post_states": archive["truth_post_states"].copy(),
                "initial_truth_states": archive["initial_truth_states"].copy(),
                "truth_q": archive["truth_q"].copy(),
                "truth_param_indices": archive["truth_param_indices"].copy(),
                "truth_noise_indices": archive["truth_noise_indices"].copy(),
                "truth_cell_indices": archive["truth_cell_indices"].copy(),
                "rain": archive["rain"].copy(),
                "pet": archive["pet"].copy(),
                "temperature": archive["temperature"].copy(),
                "candidate_param_indices": archive[
                    "candidate_param_indices"
                ].copy(),
                "candidate_noise_indices": archive[
                    "candidate_noise_indices"
                ].copy(),
                "initial_mapped_states": archive["initial_mapped_states"].copy(),
                "initial_mapped_covariance_diagonals": archive[
                    "initial_mapped_covariance_diagonals"
                ].copy(),
                "source_cell_indices": archive["source_cell_indices"].copy(),
                "destination_cell_indices": archive["destination_cell_indices"].copy(),
                "truth_bundle_sha256": str(archive["truth_bundle_sha256"]),
            }
        identity = (task.basin_id, task.seed)
        if identity not in reference:
            reference[identity] = observed
        else:
            expected = reference[identity]
            for key in (
                "observations",
                "truth_pre_states",
                "truth_post_states",
                "initial_truth_states",
                "truth_q",
                "truth_param_indices",
                "truth_noise_indices",
                "truth_cell_indices",
                "rain",
                "pet",
                "temperature",
                "source_cell_indices",
                "destination_cell_indices",
            ):
                if not np.array_equal(observed[key], expected[key]):
                    raise ValueError(
                        f"tasks do not share exact {key}: {task.task_id}"
                    )
            if observed["truth_bundle_sha256"] != expected["truth_bundle_sha256"]:
                raise ValueError(f"truth hash disagreement: {task.task_id}")
        truth_path = truth_bundle_path(root, task.basin_id, task.seed)
        if observed["truth_bundle_sha256"] != sha256_file(truth_path):
            raise ValueError(f"task truth hash differs from bundle: {task.task_id}")
        moment_identity = (task.basin_id, task.seed, task.arm_id)
        moment_records.setdefault(moment_identity, {})[task.knowledge_mode] = {
            key: observed[key]
            for key in (
                "candidate_param_indices",
                "candidate_noise_indices",
                "initial_mapped_states",
                "initial_mapped_covariance_diagonals",
            )
        }
        checked += 1
    for records in moment_records.values():
        _verify_shared_initial_moments(records)
    return {
        "task_count": checked,
        "truth_identity_count": len(reference),
        "same_observations_across_all_six_tasks": True,
        "same_truth_states_across_all_six_tasks": True,
        "truth_hashes_agree": True,
        "known_axis_initial_moments_match_joint_candidates": True,
    }


def _formal_contract(config: dict) -> tuple[list[str], tuple[int, ...], int]:
    basins = sorted(
        str(value).zfill(8) for value in admitted_basins(config)
    )
    seeds = tuple(
        int(value)
        for value in config["balanced_sequence_contract"]["formal_seeds"]
    )
    replay_days = int(config["time_contract"]["replay_days_per_event"])
    counts = config["expected_counts"]
    if basins != sorted(set(basins)) or len(basins) != int(counts["basins"]):
        raise ValueError("formal basin set changed")
    if seeds != FORMAL_SEEDS:
        raise ValueError("formal seeds changed")
    if replay_days != 180:
        raise ValueError("formal replay length changed")
    if _verify_registered_task_table(config, require_registered_hash=True) != 216:
        raise ValueError("formal task table row count changed")
    return basins, seeds, replay_days


def _formal_route(config: dict, output_root: Path, requested_route=None) -> str:
    roots = {
        route: (REPO_ROOT / value).resolve()
        for route, value in config["output_roots"].items()
        if route in {"local", "hpc"}
    }
    matches = [
        route for route, root in roots.items() if root == Path(output_root).resolve()
    ]
    if len(matches) != 1:
        raise ValueError("formal output root is not one registered route")
    inferred = matches[0]
    if requested_route is not None and str(requested_route) != inferred:
        raise ValueError("formal route and output root disagree")
    return inferred


def _verify_smoke_evidence(
    config: dict,
    *,
    route: str,
    workers: int,
    repo_root: Path = REPO_ROOT,
    config_sha256: str | None = None,
) -> dict:
    """Verify the fixed smoke decision and every hashed smoke archive."""

    root = Path(repo_root).resolve()
    smoke_relative = Path(config["output_roots"]["smoke"])
    if smoke_relative.is_absolute():
        raise RuntimeError("smoke output root must be repo-relative")
    smoke_root = (root / smoke_relative).resolve()
    try:
        smoke_root.relative_to(root)
    except ValueError as exception:
        raise RuntimeError("smoke output root escapes the repository") from exception
    resource_path = smoke_root / "resource_estimate.json"
    seal_path = smoke_root / "resource_estimate.sha256"
    if not resource_path.is_file() or not seal_path.is_file():
        raise RuntimeError("fixed smoke resource evidence is missing")
    observed_resource_hash = sha256_file(resource_path)
    sealed_hash = seal_path.read_text(encoding="ascii").strip().lower()
    if sealed_hash != observed_resource_hash:
        raise RuntimeError("smoke resource estimate drifted from its SHA-256 seal")
    with resource_path.open(encoding="utf-8") as handle:
        payload = json.load(handle)
    expected_config_hash = config_sha256 or sha256_file(root / CONFIG_PATH)
    if payload.get("config_sha256") != expected_config_hash:
        raise RuntimeError("smoke configuration SHA-256 differs from formal config")
    expected_smoke_workers = int(config["resource_route"]["smoke_workers"])
    expected_formal_workers = int(config["resource_route"]["formal_workers_local"])
    if int(payload.get("workers", -1)) != expected_smoke_workers:
        raise RuntimeError("smoke worker count differs from the registered value")
    if int(payload.get("formal_workers_used_for_extrapolation", -1)) != int(
        workers
    ) or int(workers) != expected_formal_workers:
        raise RuntimeError("formal worker count differs from smoke extrapolation")
    if payload.get("runtime_fingerprint") != _current_runtime_fingerprint():
        raise RuntimeError("smoke runtime fingerprint differs from formal runtime")

    decision = payload.get("route_decision", {})
    expected_gate_names = {
        "free_memory",
        "free_disk",
        "cpu_load",
        "wall_time",
        "peak_memory",
    }
    gates = decision.get("gates", {})
    if set(gates) != expected_gate_names:
        raise RuntimeError("smoke resource evidence does not contain exactly five gates")
    gate_passes = all(gate.get("pass") is True for gate in gates.values())
    if decision.get("all_local_gates_pass") is not gate_passes:
        raise RuntimeError("smoke aggregate resource decision disagrees with its gates")
    selected = "local" if gate_passes else "hpc"
    if decision.get("selected_route") != selected or str(route) != selected:
        raise RuntimeError("formal route disagrees with the fixed smoke decision")

    registered_artifacts = payload.get("smoke_artifact_hashes", {})
    if not isinstance(registered_artifacts, dict) or not registered_artifacts:
        raise RuntimeError("smoke artifact hash collection is empty")
    observed_paths = {
        path.relative_to(smoke_root).as_posix()
        for path in smoke_root.rglob("*.npz")
        if path.is_file()
    }
    if set(registered_artifacts) != observed_paths:
        raise RuntimeError("smoke artifact set drifted")
    for relative, expected_hash in registered_artifacts.items():
        registered = Path(relative)
        if registered.is_absolute():
            raise RuntimeError("smoke artifact path must be relative")
        artifact = (smoke_root / registered).resolve()
        try:
            artifact.relative_to(smoke_root)
        except ValueError as exception:
            raise RuntimeError("smoke artifact path escapes its root") from exception
        if not artifact.is_file() or sha256_file(artifact) != expected_hash:
            raise RuntimeError(f"smoke artifact SHA-256 changed: {relative}")
    return {
        "smoke_root": str(smoke_root),
        "smoke_config_sha256": expected_config_hash,
        "resource_estimate_sha256": observed_resource_hash,
        "resource_estimate_seal_sha256": sha256_file(seal_path),
        "smoke_artifact_count": len(registered_artifacts),
        "selected_route": selected,
    }


def run_formal(
    output_root: Path,
    workers: int,
    *,
    config: dict | None = None,
    route: str | None = None,
) -> dict:
    """Generate and atomically publish the complete formal result tree."""

    registered = load_registered_config(REPO_ROOT, verify_hashes=True)
    if config is not None and config != registered:
        raise ValueError("supplied formal configuration differs from the registered file")
    formal_route = _formal_route(registered, output_root, route)
    runtime_fingerprint = _verify_runtime_contract(
        registered, route=formal_route
    )
    frozen_commit = verify_frozen_worktree(registered)
    if int(workers) <= 0:
        raise ValueError("formal worker count must be positive")
    config_hash = sha256_file(REPO_ROOT / CONFIG_PATH)
    smoke_evidence = _verify_smoke_evidence(
        registered,
        route=formal_route,
        workers=int(workers),
        config_sha256=config_hash,
    )
    basins, seeds, replay_days = _formal_contract(registered)
    tasks = build_task_table(basins, seeds)
    counts = registered["expected_counts"]
    if len(tasks) != int(counts["tasks"]) or len(tasks) != EXPECTED_TASKS:
        raise ValueError("formal task cross-product is incomplete")
    if len({task.task_id for task in tasks}) != len(tasks):
        raise ValueError("formal task identities are not unique")

    final_root = Path(output_root)
    working_root = _prepare_atomic_output_root(final_root)
    started = time.time()
    truth_records: list[dict] = []
    task_records: list[dict] = []
    try:
        truth_records = generate_truth_bundles(
            working_root, basins, seeds, workers, registered
        )
        truth_failures = [
            record for record in truth_records if record["run_status"] != "success"
        ]
        _write_records_csv_new(
            working_root / registered["artifact_paths"]["truth_manifest"],
            truth_records,
        )
        if len(truth_records) != int(counts["truth_bundles"]):
            raise RuntimeError("truth bundle count is incomplete")
        if truth_failures:
            raise RuntimeError(f"truth generation failed for {len(truth_failures)} bundles")
        if any(int(record["clip_count"]) != 0 for record in truth_records):
            raise RuntimeError("formal truth contains a nonzero clip count")

        task_records = _run_tasks(
            working_root, tasks, workers, registered, replay_days
        )
        _write_records_csv_new(
            working_root / registered["artifact_paths"]["task_manifest"],
            task_records,
        )
        failures = [
            record for record in task_records if record["run_status"] != "success"
        ]
        _write_records_csv_new(
            working_root / registered["artifact_paths"]["failure_manifest"],
            failures,
        )
        if len(task_records) != int(counts["tasks"]):
            raise RuntimeError("replay task count is incomplete")
        if failures:
            raise RuntimeError(f"replay execution failed for {len(failures)} tasks")
        event_count = sum(int(record["event_count"]) for record in task_records)
        if event_count != int(counts["events"]):
            raise RuntimeError("replay event count is incomplete")
        fairness = _verify_task_observation_identity(
            working_root, tasks, expected_replay_days=replay_days
        )
        manifest = {
            "experiment_id": registered["experiment_id"],
            "configuration_status": registered["configuration_status"],
            "git_commit": frozen_commit,
            "config_sha256": config_hash,
            "route": formal_route,
            "route_root": str(final_root),
            "workers": int(workers),
            "runtime_fingerprint": runtime_fingerprint,
            "smoke_config_sha256": smoke_evidence["smoke_config_sha256"],
            "smoke_resource_estimate_sha256": smoke_evidence[
                "resource_estimate_sha256"
            ],
            "smoke_resource_estimate_seal_sha256": smoke_evidence[
                "resource_estimate_seal_sha256"
            ],
            "smoke_artifact_count": smoke_evidence["smoke_artifact_count"],
            "truth_bundles": len(truth_records),
            "tasks": len(task_records),
            "events": event_count,
            "failures": 0,
            "truth_clip_count": int(
                sum(int(record["clip_count"]) for record in truth_records)
            ),
            "fairness": fairness,
            "elapsed_seconds": time.time() - started,
        }
        _write_json_new(working_root / "manifests" / "run_manifest.json", manifest)
        _publish_atomic_output_root(working_root, final_root)
        return manifest
    except Exception as exception:
        failure_records = [
            record
            for record in [*truth_records, *task_records]
            if record.get("run_status") != "success"
        ]
        failure_payload = {
            "error": f"{type(exception).__name__}: {exception}",
            "incomplete_root": str(working_root),
            "truth_records": len(truth_records),
            "task_records": len(task_records),
            "failure_records": failure_records,
            "elapsed_seconds": time.time() - started,
        }
        try:
            _write_json_new(
                working_root / "manifests" / "formal_failure.json", failure_payload
            )
        except FileExistsError:
            pass
        raise RuntimeError(
            f"formal replay did not publish; incomplete evidence retained at "
            f"{working_root}: {exception}"
        ) from exception


def evaluate_resource_route(measurements: dict, thresholds: dict) -> dict:
    """Apply every preregistered local-execution resource gate."""

    definitions = {
        "free_memory": (
            "free_memory_gb",
            "minimum_free_memory_gb",
            lambda value, limit: value >= limit,
        ),
        "free_disk": (
            "free_disk_gb",
            "minimum_free_disk_gb",
            lambda value, limit: value >= limit,
        ),
        "cpu_load": (
            "three_sample_mean_cpu_percent",
            "maximum_three_sample_mean_cpu_percent",
            lambda value, limit: value <= limit,
        ),
        "wall_time": (
            "estimated_local_total_hours",
            "maximum_extrapolated_wall_hours",
            lambda value, limit: value <= limit,
        ),
        "peak_memory": (
            "peak_additional_memory_gb",
            "maximum_peak_additional_memory_gb",
            lambda value, limit: value <= limit,
        ),
    }
    gates = {}
    for name, (measurement_key, threshold_key, predicate) in definitions.items():
        value = float(measurements[measurement_key])
        threshold = float(thresholds[threshold_key])
        gates[name] = {
            "measurement": value,
            "threshold": threshold,
            "pass": bool(predicate(value, threshold)),
        }
    all_pass = all(gate["pass"] for gate in gates.values())
    return {
        "gates": gates,
        "all_local_gates_pass": all_pass,
        "selected_route": "local" if all_pass else "hpc",
    }


def _process_tree_rss_bytes() -> int:
    import psutil

    process = psutil.Process(os.getpid())
    total = 0
    for candidate in (process, *process.children(recursive=True)):
        try:
            total += int(candidate.memory_info().rss)
        except (psutil.AccessDenied, psutil.NoSuchProcess):
            continue
    return total


def _local_resource_snapshot() -> dict:
    import psutil

    cpu_samples = [float(psutil.cpu_percent(interval=1.0)) for _ in range(3)]
    memory = psutil.virtual_memory()
    disk = shutil.disk_usage(REPO_ROOT)
    return {
        "logical_cpu_count": int(psutil.cpu_count(logical=True) or 0),
        "physical_cpu_count": int(psutil.cpu_count(logical=False) or 0),
        "cpu_percent_samples": cpu_samples,
        "three_sample_mean_cpu_percent": float(np.mean(cpu_samples)),
        "free_memory_gb": float(memory.available / 1024**3),
        "free_disk_gb": float(disk.free / 1024**3),
    }


def run_smoke(
    workers: int,
    *,
    config: dict | None = None,
    output_root: Path | None = None,
) -> dict:
    """Run one development bundle and all six 14-day replay tasks."""

    registered = load_registered_config(REPO_ROOT, verify_hashes=True)
    if config is not None and config != registered:
        raise ValueError("supplied smoke configuration differs from the registered file")
    runtime_fingerprint = _verify_runtime_contract(registered, route="local")
    expected_smoke_workers = int(registered["resource_route"]["smoke_workers"])
    if int(workers) != expected_smoke_workers:
        raise ValueError("smoke worker count differs from the registered value")
    basin = sorted(admitted_basins(registered))[0]
    seed = int(registered["random_streams"]["development_smoke_seed"])
    effective_workers = int(workers)
    if output_root is None:
        root = REPO_ROOT / registered["output_roots"]["smoke"]
    else:
        root = Path(output_root)
    expected_root = (REPO_ROOT / registered["output_roots"]["smoke"]).resolve()
    if root.resolve() != expected_root:
        raise ValueError("smoke output root differs from the registered fixed root")
    if root.exists():
        raise FileExistsError(f"smoke output root already exists: {root}")
    root.mkdir(parents=True)
    resources = _local_resource_snapshot()
    baseline_rss = _process_tree_rss_bytes()
    peak_rss = [baseline_rss]
    stop_sampling = threading.Event()

    def sample_memory():
        while not stop_sampling.wait(0.05):
            peak_rss[0] = max(peak_rss[0], _process_tree_rss_bytes())

    sampler = threading.Thread(target=sample_memory, daemon=True)
    sampler.start()
    started = time.time()
    try:
        truth_records = generate_truth_bundles(
            root,
            [basin],
            [seed],
            1,
            registered,
            development_sequence_index=0,
        )
        if len(truth_records) != 1 or truth_records[0]["run_status"] != "success":
            raise RuntimeError(f"smoke truth generation failed: {truth_records}")
        tasks = build_task_table([basin], [seed])
        task_records = _run_tasks(root, tasks, effective_workers, registered, 14)
        failures = [
            record for record in task_records if record["run_status"] != "success"
        ]
        if failures:
            raise RuntimeError(f"smoke replay failed for {len(failures)} tasks")
        fairness = _verify_task_observation_identity(
            root, tasks, expected_replay_days=14
        )
    finally:
        peak_rss[0] = max(peak_rss[0], _process_tree_rss_bytes())
        stop_sampling.set()
        sampler.join(timeout=5.0)
    elapsed = time.time() - started
    truth_seconds = float(sum(record["elapsed_seconds"] for record in truth_records))
    task_seconds = float(sum(record["elapsed_seconds"] for record in task_records))
    formal_workers = int(registered["resource_route"]["formal_workers_local"])
    truth_hours = truth_seconds * EXPECTED_TRUTH_BUNDLES / formal_workers / 3600.0
    replay_hours = (
        task_seconds
        / 6.0
        * (180.0 / 14.0)
        * EXPECTED_TASKS
        / formal_workers
        / 3600.0
    )
    measurements = {
        **resources,
        "estimated_truth_generation_hours": truth_hours,
        "estimated_replay_hours": replay_hours,
        "estimated_local_total_hours": truth_hours + replay_hours,
        "baseline_process_tree_memory_gb": float(baseline_rss / 1024**3),
        "peak_process_tree_memory_gb": float(peak_rss[0] / 1024**3),
        "peak_additional_memory_gb": float(
            max(peak_rss[0] - baseline_rss, 0) / 1024**3
        ),
    }
    decision = evaluate_resource_route(
        measurements, registered["resource_route"]
    )
    artifact_hashes = {
        path.relative_to(root).as_posix(): sha256_file(path)
        for path in sorted(root.rglob("*.npz"))
        if path.is_file()
    }
    payload = {
        "experiment_id": registered["experiment_id"],
        "scientific_status": "development_smoke_excluded_from_formal_evidence",
        "config_sha256": sha256_file(REPO_ROOT / CONFIG_PATH),
        "runtime_fingerprint": runtime_fingerprint,
        "basin_id": basin,
        "smoke_seed": seed,
        "development_sequence_index": 0,
        "workers": effective_workers,
        "formal_workers_used_for_extrapolation": formal_workers,
        "event_count": 5 * 6,
        "target_days_per_event": 14,
        "elapsed_seconds": elapsed,
        "smoke_root": str(root),
        "fairness": fairness,
        "measurements": measurements,
        "route_decision": decision,
        "smoke_artifact_hashes": artifact_hashes,
    }
    resource_path = root / "resource_estimate.json"
    _write_json_new(resource_path, payload)
    seal_path = root / "resource_estimate.sha256"
    with seal_path.open("x", encoding="ascii", newline="\n") as handle:
        handle.write(sha256_file(resource_path) + "\n")
    _verify_smoke_evidence(
        registered,
        route=decision["selected_route"],
        workers=formal_workers,
        config_sha256=payload["config_sha256"],
    )
    return payload


def _dry_run(config: dict) -> dict:
    basins = sorted(admitted_basins(config))
    seeds = tuple(
        int(value)
        for value in config["balanced_sequence_contract"]["formal_seeds"]
    )
    tasks = build_task_table(basins, seeds)
    sequences = [williams_sequence(index) for index in range(6)]
    validate_balanced_design(sequences)
    task_table_rows = _verify_registered_task_table(
        config, require_registered_hash=False
    )
    counts = config["expected_counts"]
    observed = {
        "truth_bundles": len(basins) * len(seeds),
        "tasks": len(tasks),
        "events": len(tasks) * 5,
    }
    for key, value in observed.items():
        if value != int(counts[key]):
            raise ValueError(f"dry-run {key} count changed: {value} != {counts[key]}")
    return {
        "experiment_id": config["experiment_id"],
        "configuration_status": config["configuration_status"],
        **observed,
        "unique_task_identities": len({task.task_id for task in tasks}),
        "all_thirty_directed_edges_per_basin": True,
        "registered_task_table_rows": task_table_rows,
        "formal_root_exists": {
            route: (REPO_ROOT / root).exists()
            for route, root in config["output_roots"].items()
            if route in {"local", "hpc"}
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("dry-run", "smoke", "run"))
    parser.add_argument("--workers", type=int, default=None)
    parser.add_argument("--route", choices=("local", "hpc"), default="local")
    parser.add_argument("--output-root", type=Path, default=None)
    arguments = parser.parse_args()
    verify_hashes = arguments.mode != "dry-run"
    config = load_registered_config(REPO_ROOT, verify_hashes=verify_hashes)
    if arguments.mode == "dry-run":
        payload = _dry_run(config)
    elif arguments.mode == "smoke":
        workers = arguments.workers or int(config["resource_route"]["smoke_workers"])
        smoke_root = arguments.output_root
        payload = run_smoke(workers, config=config, output_root=smoke_root)
    else:
        workers = arguments.workers or int(
            config["resource_route"]["formal_workers_local"]
        )
        root = arguments.output_root or REPO_ROOT / config["output_roots"][
            arguments.route
        ]
        payload = run_formal(
            root,
            workers,
            config=config,
            route=arguments.route,
        )
    print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
