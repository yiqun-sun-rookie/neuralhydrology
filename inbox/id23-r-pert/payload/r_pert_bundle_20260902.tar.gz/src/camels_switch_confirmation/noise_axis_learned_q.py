"""Step 2 of the noise axis: per-basin grouped-diagonal process noise, learned by CMA-ES.

Preregistration (frozen 2026-08-27, user-approved):
docs/plans/2026-08-27-noise-axis-step2-learned-noise-prereg-draft-v01.md

Six free parameters per basin, all on the process-noise side: one noise-to-amplitude ratio
for each of the five physical storages plus one shared by the ten routing-delay states.
Observation noise is NOT learned -- both arms use the frozen G1 constant sigma_obs, byte for
byte the same, so the single manipulated variable is the process-noise structure.

The per-day noise std of group g is ``rho_g * A_g`` with A_g the frozen open-loop RMS
amplitude of that group over the training segment (days 1..840), floored at 0.01 mm.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np

_SRC = Path(__file__).resolve().parents[1]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation.g2_switch_confirmation import N_HYDRO, N_STATE  # noqa: E402
from camels_switch_confirmation.noise_axis_filtering import run_noise_axis_filter  # noqa: E402

GROUP_NAMES = ("SNOWPACK", "MELTWATER", "SM", "SUZ", "SLZ", "ROUTING")
N_GROUPS = len(GROUP_NAMES)
AMPLITUDE_FLOOR_MM = 0.01
RHO_BOUNDS = (1e-4, 1.0)
LOG_RHO_BOUNDS = (float(np.log(RHO_BOUNDS[0])), float(np.log(RHO_BOUNDS[1])))
# m1_c0-equivalent SLZ ratio under the RMS-amplitude convention (exact, basin-independent):
# the m1_c0 SLZ noise variance is expm1(0.02**2)*SLZ_t**2, whose training-time average equals
# (RHO_SLZ_M1C0 * RMS(SLZ))**2 identically.
RHO_SLZ_M1C0 = float(np.sqrt(np.expm1(0.02**2)))

TRAIN_DAYS = 840
BURN_IN_DAYS = 60
WINDOW_DAYS = 1260
HOLDOUT_DAYS = WINDOW_DAYS - TRAIN_DAYS

CMA_SIGMA0 = 1.5
CMA_POPSIZE = 8
CMA_GENERATIONS = 12
ANCHOR_COUNT = 8
EVALS_PER_ANCHOR = CMA_POPSIZE * CMA_GENERATIONS

_RHO_OFF = 1e-3
_RHO_MID = 0.02
_RHO_HI = 0.2


def anchor_table() -> tuple[tuple[str, np.ndarray], ...]:
    """The eight frozen multi-start anchors (name, rho vector ordered as GROUP_NAMES)."""

    def rho(**overrides) -> np.ndarray:
        values = dict.fromkeys(GROUP_NAMES, overrides.pop("base"))
        values.update(overrides)
        return np.array([values[name] for name in GROUP_NAMES], dtype=np.float64)

    return (
        ("near_m1c0", rho(base=_RHO_OFF, SLZ=RHO_SLZ_M1C0)),
        ("uniform", rho(base=_RHO_MID)),
        ("sm_heavy", rho(base=_RHO_OFF, SM=_RHO_HI)),
        ("suz_heavy", rho(base=_RHO_OFF, SUZ=_RHO_HI)),
        ("routing_heavy", rho(base=_RHO_OFF, ROUTING=_RHO_HI)),
        ("snow_heavy", rho(base=_RHO_OFF, SNOWPACK=_RHO_HI, MELTWATER=_RHO_HI)),
        ("large_q", rho(base=_RHO_HI)),
        ("small_q", rho(base=_RHO_OFF)),
    )


def anchor_seed(basin: str, anchor_index: int) -> int:
    """Frozen seed formula: (basin_id * 100 + anchor) mod 2^31."""
    return (int(basin) * 100 + int(anchor_index)) % (2**31)


def open_loop_states(task: dict, basin: str) -> np.ndarray:
    """Deterministic center-model state trajectory with the exact filter construction.

    Mirrors ``g2_switch_confirmation._build_bank``: the same initial hydrology, the same
    conserving-soil-excess projection, the same ForcingTransition -- so the amplitudes are
    magnitudes of the very states the filter propagates, not of some sibling model.
    """
    from camels_switch_confirmation.run_online_noise_pilot import _initial_hydrology
    from hbv_joint_uncertainty.hbv_state_mapping import project_hbv_state_conserving_soil_excess
    from hbv_joint_uncertainty.preflight import ForcingTransition
    from scl_hydro.hbv_lite_numpy import resolve_hbv_bounds

    center = task["members"][0]
    projector = lambda values, p=center: project_hbv_state_conserving_soil_excess(values, p)
    shared = np.zeros(N_STATE, dtype=np.float64)
    shared[:N_HYDRO] = _initial_hydrology(basin)
    state = projector(shared)
    transition = ForcingTransition(
        center, parameter_bounds=resolve_hbv_bounds("v5"), state_projector=projector
    )
    n_days = len(task["obs"])
    states = np.empty((n_days, N_STATE), dtype=np.float64)
    for day in range(n_days):
        transition.set_forcing(task["rain"][day], task["pet"][day], task["temp"][day])
        state = transition(state)
        states[day] = state
    if not np.all(np.isfinite(states)):
        raise ValueError(f"basin {basin}: open-loop states contain nonfinite values")
    return states


def training_amplitudes(states: np.ndarray) -> np.ndarray:
    """Frozen per-group amplitudes: RMS over the training segment, floored at 0.01 mm."""
    segment = np.asarray(states, dtype=np.float64)[:TRAIN_DAYS]
    if segment.shape != (TRAIN_DAYS, N_STATE):
        raise ValueError(f"expected ({TRAIN_DAYS}, {N_STATE}) training states, got {segment.shape}")

    def rms(values: np.ndarray) -> float:
        return float(np.sqrt(np.mean(np.square(values))))

    amplitudes = np.array(
        [rms(segment[:, 0]), rms(segment[:, 1]), rms(segment[:, 2]), rms(segment[:, 3]),
         rms(segment[:, 4]), rms(segment[:, N_HYDRO:])],
        dtype=np.float64,
    )
    return np.maximum(amplitudes, AMPLITUDE_FLOOR_MM)


@dataclass(frozen=True)
class GroupedProcessNoise:
    """Constant grouped-diagonal Q; observation noise stays the frozen G1 constant."""

    rho: tuple
    amplitudes: tuple

    def __post_init__(self) -> None:
        rho = np.asarray(self.rho, dtype=np.float64)
        amplitudes = np.asarray(self.amplitudes, dtype=np.float64)
        if rho.shape != (N_GROUPS,) or amplitudes.shape != (N_GROUPS,):
            raise ValueError(f"rho and amplitudes must both have shape ({N_GROUPS},)")
        if not np.all(np.isfinite(rho)) or np.any(rho <= 0.0):
            raise ValueError("rho must be finite and positive")
        if not np.all(np.isfinite(amplitudes)) or np.any(amplitudes < AMPLITUDE_FLOOR_MM):
            raise ValueError(f"amplitudes must be finite and >= the {AMPLITUDE_FLOOR_MM} mm floor")

    def _covariance(self) -> np.ndarray:
        rho = np.asarray(self.rho, dtype=np.float64)
        amplitudes = np.asarray(self.amplitudes, dtype=np.float64)
        std = rho * amplitudes
        diagonal = np.empty(N_STATE, dtype=np.float64)
        diagonal[:N_HYDRO] = np.square(std[:N_HYDRO])
        diagonal[N_HYDRO:] = std[N_GROUPS - 1] ** 2
        return np.diag(diagonal)

    def build_process_covariance(self, predicted_state: np.ndarray, rain_today: float) -> np.ndarray:
        del predicted_state, rain_today  # constant by design; time variation is step 3's business
        return self._covariance()


def sliced_task(task: dict, n_days: int) -> dict:
    """The same task truncated to its first ``n_days`` (for training-segment evaluations)."""
    out = dict(task)
    for key in ("rain", "pet", "temp", "obs"):
        out[key] = np.asarray(task[key])[:n_days]
    return out


def training_objective(task: dict, basin: str, noise: GroupedProcessNoise, r_source=None) -> float:
    """Mean squared one-step-forecast error over days 61..840 (burn-in excluded).

    ``r_source`` (default ``None`` = the frozen constant R) is passed straight through to the
    filter; the objective's definition is unchanged by it, so the R-perturbation arms search
    the same quantity the frozen step-2 search did.
    """
    result = run_noise_axis_filter(sliced_task(task, TRAIN_DAYS), basin, noise, r_source)
    forecast = result["one_step_forecast"][BURN_IN_DAYS:]
    observed = result["observations"][BURN_IN_DAYS:]
    return float(np.mean(np.square(forecast - observed)))


def nse(forecast: np.ndarray, observed: np.ndarray) -> float:
    denominator = float(np.sum(np.square(observed - observed.mean())))
    return 1.0 - float(np.sum(np.square(forecast - observed))) / denominator


def evaluate_full_run(task: dict, basin: str, noise: GroupedProcessNoise, r_source=None) -> dict:
    """One continuous 1,260-day run; NSE on the holdout segment plus full outputs."""
    result = run_noise_axis_filter(task, basin, noise, r_source)
    forecast = result["one_step_forecast"]
    observed = result["observations"]
    return {
        "one_step_forecast": forecast,
        "forecast_variance": result["forecast_variance"],
        "observation_variance": result["observation_variance"],
        "observations": observed,
        "nse_holdout": nse(forecast[TRAIN_DAYS:], observed[TRAIN_DAYS:]),
        "nse_full": nse(forecast, observed),
        "nse_train_after_burnin": nse(
            forecast[BURN_IN_DAYS:TRAIN_DAYS], observed[BURN_IN_DAYS:TRAIN_DAYS]
        ),
    }


def boundary_diagnostics(log_rho: np.ndarray) -> dict:
    """Exact-boundary and outer-5% counts over the 6 log-parameters (TUKF06-comparable)."""
    low, high = LOG_RHO_BOUNDS
    values = np.asarray(log_rho, dtype=np.float64)
    span = high - low
    exact = int(np.sum((values == low) | (values == high)))
    outer = int(np.sum((values < low + 0.05 * span) | (values > high - 0.05 * span)))
    return {"exact_boundary": exact, "outer_5pct": outer}


def search_one_anchor(
    task: dict,
    basin: str,
    amplitudes: np.ndarray,
    anchor_index: int,
    anchor_rho: np.ndarray,
    r_source=None,
) -> dict:
    """CMA-ES from one anchor under the frozen budget; returns the anchor's best candidate.

    Out-of-bounds candidates are clipped to the box before evaluation (frozen choice:
    projection repair), so the reported parameters are always inside or exactly on the
    boundary -- which is what makes the exact-boundary count meaningful.
    """
    import cma

    low, high = LOG_RHO_BOUNDS
    start = np.log(np.asarray(anchor_rho, dtype=np.float64))
    options = {
        "popsize": CMA_POPSIZE,
        "maxiter": CMA_GENERATIONS,
        "seed": anchor_seed(basin, anchor_index),
        "verbose": -9,
        "verb_disp": 0,
        "verb_log": 0,
    }
    strategy = cma.CMAEvolutionStrategy(start, CMA_SIGMA0, options)
    strategy.inject([start])  # the anchor itself is evaluated within the frozen budget

    best_objective = np.inf
    best_log_rho = np.clip(start, low, high)
    evaluations = 0
    crashes = []
    while not strategy.stop() and evaluations < EVALS_PER_ANCHOR:
        candidates = strategy.ask()
        fitnesses = []
        for candidate in candidates:
            clipped = np.clip(np.asarray(candidate, dtype=np.float64), low, high)
            try:
                objective = training_objective(
                    task,
                    basin,
                    GroupedProcessNoise(tuple(np.exp(clipped)), tuple(amplitudes)),
                    r_source,
                )
            except Exception as exc:  # noqa: BLE001 - crashes are data, prelocked handling
                objective = float("inf")
                crashes.append({"log_rho": clipped.tolist(), "error": f"{type(exc).__name__}: {exc}"})
            evaluations += 1
            fitnesses.append(objective)
            if objective < best_objective:
                best_objective = objective
                best_log_rho = clipped
        strategy.tell(candidates, fitnesses)
    return {
        "anchor_index": anchor_index,
        "best_log_rho": np.asarray(best_log_rho, dtype=np.float64),
        "best_objective": float(best_objective),
        "n_evaluations": int(evaluations),
        "crashes": crashes,
        **boundary_diagnostics(best_log_rho),
    }
