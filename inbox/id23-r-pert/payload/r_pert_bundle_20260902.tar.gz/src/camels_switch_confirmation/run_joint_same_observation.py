"""Run registered same-observation continuous and independent-replay tasks."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import threading
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from pathlib import Path

for _thread_variable in (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
):
    os.environ.setdefault(_thread_variable, "1")

import numpy as np
import pandas as pd

from camels_switch_confirmation.bank import build_bank
from camels_switch_confirmation.g1_precheck import (
    PARAM_KEYS,
    STATE_NAMES,
    WINDOW_START,
    _window_end,
)
from camels_switch_confirmation.g2_switch_confirmation import (
    LAG_CAP,
    N_STATE,
    _atomic_save_npz,
)
from camels_switch_confirmation.joint_same_observation import (
    BASE_CONFIG,
    CONTINUOUS_CONFIG,
    REPLAY_CONFIG,
    TruthObservationBundle,
    build_estimator_runtime,
    generate_truth_observation_bundle,
    load_registered_configs,
    sha256_file,
)
from camels_switch_confirmation.run_online_noise_pilot import (
    PARAMETER_TABLE,
    RESULTS,
)


REPO_ROOT = Path(__file__).resolve().parents[2]
DATA_ROOT = "data/camels_us"
G1_CSV = RESULTS / "g1_precheck_v01" / "g1_precheck.csv"
ADMISSION_CSV = (
    RESULTS
    / "joint_param_noise_precheck_v01"
    / "admission.csv"
)
ARM_MODES = {"C": "full", "P": "pairwise_path_postcollapse"}
KNOWLEDGE_MODES = ("joint_unknown", "param_known", "noise_known")


@dataclass(frozen=True, order=True)
class TaskIdentity:
    basin_id: str
    seed: int
    arm_id: str
    knowledge_mode: str

    @property
    def task_id(self) -> str:
        return (
            f"{self.basin_id}_s{self.seed}_{self.arm_id}_"
            f"{self.knowledge_mode}"
        )


def admitted_basins() -> list[str]:
    frame = pd.read_csv(ADMISSION_CSV, dtype={"basin_id": str})
    frame["basin_id"] = frame["basin_id"].str.zfill(8)
    if "admitted" in frame.columns:
        frame = frame[frame["admitted"]]
    basins = frame["basin_id"].tolist()
    if len(basins) != 36 or len(set(basins)) != 36:
        raise ValueError("registered admission table must contain 36 unique basins")
    return basins


def build_task_table(
    basins,
    seeds=(6, 7),
    arms=tuple(ARM_MODES),
    knowledge_modes=KNOWLEDGE_MODES,
) -> list[TaskIdentity]:
    tasks = [
        TaskIdentity(str(basin).zfill(8), int(seed), str(arm), str(mode))
        for basin in basins
        for seed in seeds
        for arm in arms
        for mode in knowledge_modes
    ]
    identities = {task.task_id for task in tasks}
    if len(identities) != len(tasks):
        raise ValueError("task identity cross-product contains duplicates")
    return tasks


def truth_bundle_path(root: Path, basin_id: str, seed: int) -> Path:
    return Path(root) / "bundles" / f"{str(basin_id).zfill(8)}_s{int(seed)}.npz"


def task_output_path(root: Path, task: TaskIdentity) -> Path:
    return (
        Path(root)
        / "arms"
        / task.arm_id
        / task.knowledge_mode
        / f"{task.basin_id}_s{task.seed}.npz"
    )


def _initial_covariance(state, fraction=0.001) -> np.ndarray:
    values = np.asarray(state, dtype=np.float64)
    if values.shape != (N_STATE,):
        raise ValueError(f"initial state must have shape ({N_STATE},)")
    scales = np.maximum(np.abs(values), 1.0)
    return np.diag((float(fraction) * scales) ** 2)


def _reference_transition_index(runtime) -> int:
    for position, (param_index, _) in enumerate(runtime.candidate_pairs):
        if param_index == 0:
            return position
    return 0


def _run_estimator_day(runtime, bundle, day):
    true_param = int(bundle.truth_param_indices[day])
    true_noise = int(bundle.truth_noise_indices[day])
    runtime.apply_known_axes(true_param, true_noise)
    runtime.set_forcing(
        bundle.rain[day],
        bundle.pet[day],
        bundle.temperature[day],
    )
    reference_index = _reference_transition_index(runtime)
    predicted_reference = runtime.transitions[reference_index](
        runtime.estimator.state.copy()
    )
    runtime.assign_process_covariances(predicted_reference[4], true_noise)
    result = runtime.estimator.step(np.array([bundle.observations[day]]))
    return result, float(predicted_reference[4])


def run_continuous_arrays(
    bundle: TruthObservationBundle,
    members,
    sigma_obs,
    bounds,
    knowledge_mode,
    interaction_mode,
) -> dict[str, np.ndarray]:
    """Run one continuous estimator against an already generated bundle."""

    n_days = len(bundle.observations)
    initial_state = bundle.pre_states[0]
    runtime = build_estimator_runtime(
        knowledge_mode=knowledge_mode,
        interaction_mode=interaction_mode,
        members=members,
        initial_state=initial_state,
        initial_covariance=_initial_covariance(initial_state),
        initial_probabilities=None,
        sigma_obs=sigma_obs,
        bounds=bounds,
        true_param_index=int(bundle.truth_param_indices[0]),
        true_noise_index=int(bundle.truth_noise_indices[0]),
    )
    candidate_count = len(runtime.candidate_pairs)
    probabilities = np.empty((n_days, candidate_count), dtype=np.float64)
    log_probabilities = np.empty_like(probabilities)
    combined_states = np.empty((n_days, N_STATE), dtype=np.float64)
    combined_covariance_diagonals = np.empty_like(combined_states)
    reference_slz = np.empty(n_days, dtype=np.float64)
    candidate_param_indices = np.empty(
        (n_days, candidate_count), dtype=np.int64
    )
    candidate_noise_indices = np.empty_like(candidate_param_indices)
    for day in range(n_days):
        result, reference_slz[day] = _run_estimator_day(runtime, bundle, day)
        probabilities[day] = result.posterior_probabilities
        log_probabilities[day] = result.posterior_log_probabilities
        combined_states[day] = result.combined_state
        combined_covariance_diagonals[day] = np.diag(result.combined_covariance)
        candidate_param_indices[day] = [pair[0] for pair in runtime.candidate_pairs]
        candidate_noise_indices[day] = [pair[1] for pair in runtime.candidate_pairs]
    if not np.all(np.isfinite(probabilities)):
        raise ValueError("continuous probabilities contain non-finite values")
    if np.any(np.isnan(log_probabilities)) or np.any(np.isposinf(log_probabilities)):
        raise ValueError("continuous log probabilities contain NaN or positive infinity")
    if not np.allclose(
        probabilities.sum(axis=1), 1.0, rtol=0.0, atol=1e-12
    ):
        raise ValueError("continuous probabilities do not sum to one")
    if not np.all(np.isfinite(combined_states)):
        raise ValueError("continuous combined states contain non-finite values")
    return {
        "probabilities": probabilities,
        "log_probabilities": log_probabilities,
        "combined_states": combined_states,
        "combined_covariance_diagonals": combined_covariance_diagonals,
        "reference_slz_prediction": reference_slz,
        "candidate_param_indices": candidate_param_indices,
        "candidate_noise_indices": candidate_noise_indices,
        "observations": bundle.observations.copy(),
        "truth_post_states": bundle.post_states.copy(),
        "truth_param_indices": bundle.truth_param_indices.copy(),
        "truth_noise_indices": bundle.truth_noise_indices.copy(),
        "truth_cell_indices": bundle.truth_cell_indices.copy(),
    }


def _source_initial_probabilities(runtime, source_param, source_noise):
    probabilities = np.zeros(len(runtime.candidate_pairs), dtype=np.float64)
    if runtime.knowledge_mode == "joint_unknown":
        target = (int(source_param), int(source_noise))
    elif runtime.knowledge_mode == "param_known":
        target = (int(source_param), int(source_noise))
    else:
        target = (int(source_param), int(source_noise))
    try:
        probabilities[runtime.candidate_pairs.index(target)] = 1.0
    except ValueError as exception:
        raise ValueError(
            f"source truth candidate is absent from {runtime.knowledge_mode}: {target}"
        ) from exception
    return probabilities


def run_replay_arrays(
    bundle: TruthObservationBundle,
    members,
    sigma_obs,
    bounds,
    knowledge_mode,
    interaction_mode,
    switch_days,
    replay_days,
    initial_covariance_fraction,
) -> dict[str, np.ndarray]:
    """Run each registered switch from the same pre-transition truth state."""

    switch_values = tuple(int(value) for value in switch_days)
    if not switch_values:
        raise ValueError("at least one switch day is required")
    candidate_count = 9 if knowledge_mode == "joint_unknown" else 3
    event_count = len(switch_values)
    probabilities = np.empty(
        (event_count, int(replay_days), candidate_count), dtype=np.float64
    )
    log_probabilities = np.empty_like(probabilities)
    combined_states = np.empty(
        (event_count, int(replay_days), N_STATE), dtype=np.float64
    )
    combined_covariance_diagonals = np.empty_like(combined_states)
    candidate_param_indices = np.empty(
        (event_count, int(replay_days), candidate_count), dtype=np.int64
    )
    candidate_noise_indices = np.empty_like(candidate_param_indices)
    initial_truth_states = np.empty((event_count, N_STATE), dtype=np.float64)
    source_cells = np.empty((event_count, 2), dtype=np.int64)
    destination_cells = np.empty_like(source_cells)
    truth_post_states = np.empty_like(combined_states)
    observations = np.empty((event_count, int(replay_days)), dtype=np.float64)
    for event_index, switch_day in enumerate(switch_values):
        if switch_day <= 0 or switch_day + int(replay_days) > len(bundle.observations):
            raise ValueError(f"switch day is outside the truth bundle: {switch_day}")
        source = (
            int(bundle.truth_param_indices[switch_day - 1]),
            int(bundle.truth_noise_indices[switch_day - 1]),
        )
        destination = (
            int(bundle.truth_param_indices[switch_day]),
            int(bundle.truth_noise_indices[switch_day]),
        )
        if source == destination:
            raise ValueError(f"switch day does not change truth: {switch_day}")
        initial_state = bundle.pre_states[switch_day]
        initial_truth_states[event_index] = initial_state
        source_cells[event_index] = source
        destination_cells[event_index] = destination
        temporary = build_estimator_runtime(
            knowledge_mode=knowledge_mode,
            interaction_mode=interaction_mode,
            members=members,
            initial_state=initial_state,
            initial_covariance=_initial_covariance(
                initial_state, initial_covariance_fraction
            ),
            initial_probabilities=None,
            sigma_obs=sigma_obs,
            bounds=bounds,
            true_param_index=source[0],
            true_noise_index=source[1],
        )
        source_probabilities = _source_initial_probabilities(
            temporary, source[0], source[1]
        )
        runtime = build_estimator_runtime(
            knowledge_mode=knowledge_mode,
            interaction_mode=interaction_mode,
            members=members,
            initial_state=initial_state,
            initial_covariance=_initial_covariance(
                initial_state, initial_covariance_fraction
            ),
            initial_probabilities=source_probabilities,
            sigma_obs=sigma_obs,
            bounds=bounds,
            true_param_index=source[0],
            true_noise_index=source[1],
        )
        for offset in range(int(replay_days)):
            day = switch_day + offset
            result, _ = _run_estimator_day(runtime, bundle, day)
            probabilities[event_index, offset] = result.posterior_probabilities
            log_probabilities[event_index, offset] = (
                result.posterior_log_probabilities
            )
            combined_states[event_index, offset] = result.combined_state
            combined_covariance_diagonals[event_index, offset] = np.diag(
                result.combined_covariance
            )
            candidate_param_indices[event_index, offset] = [
                pair[0] for pair in runtime.candidate_pairs
            ]
            candidate_noise_indices[event_index, offset] = [
                pair[1] for pair in runtime.candidate_pairs
            ]
            truth_post_states[event_index, offset] = bundle.post_states[day]
            observations[event_index, offset] = bundle.observations[day]
    if not np.all(np.isfinite(probabilities)):
        raise ValueError("replay probabilities contain non-finite values")
    if np.any(np.isnan(log_probabilities)) or np.any(np.isposinf(log_probabilities)):
        raise ValueError("replay log probabilities contain NaN or positive infinity")
    if not np.allclose(
        probabilities.sum(axis=2), 1.0, rtol=0.0, atol=1e-12
    ):
        raise ValueError("replay probabilities do not sum to one")
    return {
        "probabilities": probabilities,
        "log_probabilities": log_probabilities,
        "combined_states": combined_states,
        "combined_covariance_diagonals": combined_covariance_diagonals,
        "candidate_param_indices": candidate_param_indices,
        "candidate_noise_indices": candidate_noise_indices,
        "initial_truth_states": initial_truth_states,
        "source_cells": source_cells,
        "destination_cells": destination_cells,
        "truth_post_states": truth_post_states,
        "observations": observations,
        "switch_days": np.asarray(switch_values, dtype=np.int64),
    }


def _load_basin_case(basin_id: str, window_days: int):
    from hydroagent.data_loading import load_camels_basin
    from scl_hydro.hbv_lite_numpy import resolve_hbv_bounds

    parameter_frame = pd.read_csv(PARAMETER_TABLE, dtype={"basin_id": str})
    parameter_frame["basin_id"] = parameter_frame["basin_id"].str.zfill(8)
    selected = parameter_frame[parameter_frame["basin_id"] == basin_id]
    if len(selected) != 1:
        raise ValueError(f"parameter table must contain one row for {basin_id}")
    row = selected.iloc[0]
    parameters = {key: float(row[f"p_{key}"]) for key in PARAM_KEYS}
    lag_capped = parameters["lag_time"] > LAG_CAP
    parameters["lag_time"] = min(parameters["lag_time"], LAG_CAP)
    initial_hydrology = np.asarray(
        [float(row[f"state_{name}"]) for name in STATE_NAMES],
        dtype=np.float64,
    )
    bounds = resolve_hbv_bounds("v5")
    members, clipped = build_bank(parameters, bounds["parFC"])
    if any(clipped):
        raise ValueError(f"registered admitted basin has clipped candidate: {basin_id}")
    noise_frame = pd.read_csv(G1_CSV, dtype={"basin_id": str})
    noise_frame["basin_id"] = noise_frame["basin_id"].str.zfill(8)
    sigma_obs = float(noise_frame.set_index("basin_id").loc[basin_id, "sigma_obs"])
    forcing, _observed, _area = load_camels_basin(
        basin_id,
        data_root=DATA_ROOT,
        start_date=WINDOW_START,
        end_date=_window_end(),
        forcing="maurer",
        pet_method="oudin",
        keep_obs_nan_days=True,
    )
    rain = forcing["prcp"].values.astype(np.float64)[:window_days]
    pet_column = "ep" if "ep" in forcing.columns else "pet"
    pet = forcing[pet_column].values.astype(np.float64)[:window_days]
    temperature = (
        forcing["tmean"].values.astype(np.float64)
        if "tmean" in forcing.columns
        else np.zeros_like(rain)
    )[:window_days]
    return {
        "members": members,
        "initial_hydrology": initial_hydrology,
        "bounds": bounds,
        "sigma_obs": sigma_obs,
        "rain": rain,
        "pet": pet,
        "temperature": temperature,
        "lag_capped": bool(lag_capped),
    }


def save_truth_bundle_new(
    target: Path,
    bundle: TruthObservationBundle,
    basin_id: str,
    seed: int,
    preregistration_sha256: str,
    registration_arrays: dict[str, np.ndarray],
) -> None:
    _atomic_save_npz(
        target,
        rain=bundle.rain,
        pet=bundle.pet,
        temperature=bundle.temperature,
        pre_states=bundle.pre_states,
        post_states=bundle.post_states,
        truth_q=bundle.truth_q,
        observations=bundle.observations,
        observation_errors=bundle.observation_errors,
        truth_param_indices=bundle.truth_param_indices,
        truth_noise_indices=bundle.truth_noise_indices,
        truth_cell_indices=bundle.truth_cell_indices,
        truth_parfc=bundle.truth_parfc,
        sequence=bundle.sequence,
        stage_days=np.array(bundle.stage_days, dtype=np.int64),
        clip_count=np.array(bundle.clip_count, dtype=np.int64),
        basin_id=np.array(str(basin_id)),
        seed=np.array(int(seed), dtype=np.int64),
        preregistration_sha256=np.array(preregistration_sha256),
        **registration_arrays,
    )


def build_truth_registration_arrays(
    base_config,
    members,
    sigma_obs,
    basin_id,
    seed,
    config_hashes,
    n_days=None,
) -> dict[str, np.ndarray]:
    """Encode every registered identity needed to audit one truth package."""

    sequence = np.asarray(base_config["sequence"], dtype=np.int64)
    stage_days = int(base_config["stage_days"])
    saved_days = (
        len(sequence) * stage_days if n_days is None else int(n_days)
    )
    parameter_values = np.asarray([
        [float(member[key]) for key in PARAM_KEYS] for member in members
    ], dtype=np.float64)
    return {
        "candidate_parameter_keys": np.asarray(PARAM_KEYS),
        "candidate_parameter_values": parameter_values,
        "candidate_process_noise_multipliers": np.asarray(
            base_config["process_noise_multipliers"], dtype=np.float64
        ),
        "observation_sigma": np.array(float(sigma_obs), dtype=np.float64),
        "switch_days": np.arange(1, len(sequence), dtype=np.int64) * stage_days,
        "stage_indices": np.repeat(
            np.arange(len(sequence), dtype=np.int64), stage_days
        )[:saved_days],
        "truth_rng_identity": np.asarray([
            int(base_config["seed_entropy"]),
            int(basin_id),
            int(seed),
            int(base_config["truth_stream_tag"]),
        ], dtype=np.int64),
        "observation_rng_identity": np.asarray([
            int(base_config["seed_entropy"]),
            int(basin_id),
            int(seed),
            int(base_config["observation_stream_tag"]),
        ], dtype=np.int64),
        "registered_inputs_json": np.array(json.dumps(
            base_config["registered_inputs"],
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )),
        "registered_implementation_json": np.array(json.dumps(
            base_config["registered_implementation"],
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )),
        "base_config_sha256": np.array(config_hashes["base"]),
        "continuous_config_sha256": np.array(config_hashes["continuous"]),
        "replay_config_sha256": np.array(config_hashes["replay"]),
    }


def load_truth_bundle(path: Path) -> TruthObservationBundle:
    with np.load(path, allow_pickle=False) as archive:
        return TruthObservationBundle(
            rain=archive["rain"].copy(),
            pet=archive["pet"].copy(),
            temperature=archive["temperature"].copy(),
            pre_states=archive["pre_states"].copy(),
            post_states=archive["post_states"].copy(),
            truth_q=archive["truth_q"].copy(),
            observations=archive["observations"].copy(),
            observation_errors=archive["observation_errors"].copy(),
            truth_param_indices=archive["truth_param_indices"].copy(),
            truth_noise_indices=archive["truth_noise_indices"].copy(),
            truth_cell_indices=archive["truth_cell_indices"].copy(),
            truth_parfc=archive["truth_parfc"].copy(),
            sequence=archive["sequence"].copy(),
            stage_days=int(archive["stage_days"]),
            clip_count=int(archive["clip_count"]),
        )


def _generate_truth_worker(args):
    basin_id, seed, root, window_days = args
    started = time.time()
    try:
        configs = load_registered_configs(REPO_ROOT)
        case = _load_basin_case(basin_id, window_days)
        base = configs.base
        truth_rng = np.random.default_rng(
            np.random.SeedSequence(
                (
                    int(base["seed_entropy"]),
                    int(basin_id),
                    int(seed),
                    int(base["truth_stream_tag"]),
                )
            )
        )
        observation_rng = np.random.default_rng(
            np.random.SeedSequence(
                (
                    int(base["seed_entropy"]),
                    int(basin_id),
                    int(seed),
                    int(base["observation_stream_tag"]),
                )
            )
        )
        bundle = generate_truth_observation_bundle(
            sequence=tuple(tuple(value) for value in base["sequence"]),
            members=case["members"],
            rain=case["rain"],
            pet=case["pet"],
            temperature=case["temperature"],
            init_hydro=case["initial_hydrology"],
            truth_rng=truth_rng,
            observation_rng=observation_rng,
            observation_sigma=case["sigma_obs"],
            bounds=case["bounds"],
            stage_days=int(base["stage_days"]),
        )
        prereg_hash = base["registered_inputs"]["preregistration"]["sha256"]
        target = truth_bundle_path(Path(root), basin_id, seed)
        target.parent.mkdir(parents=True, exist_ok=True)
        registration_arrays = build_truth_registration_arrays(
            base,
            case["members"],
            case["sigma_obs"],
            basin_id,
            seed,
            {
                "base": sha256_file(REPO_ROOT / BASE_CONFIG),
                "continuous": sha256_file(REPO_ROOT / CONTINUOUS_CONFIG),
                "replay": sha256_file(REPO_ROOT / REPLAY_CONFIG),
            },
            n_days=len(bundle.observations),
        )
        save_truth_bundle_new(
            target,
            bundle,
            basin_id,
            seed,
            prereg_hash,
            registration_arrays,
        )
        return {
            "task_id": f"{basin_id}_s{seed}",
            "run_status": "success",
            "clip_count": bundle.clip_count,
            "truth_sha256": sha256_file(target),
            "elapsed_seconds": time.time() - started,
        }
    except Exception as exception:  # noqa: BLE001 - preserved in manifest
        return {
            "task_id": f"{basin_id}_s{seed}",
            "run_status": "failed",
            "error_message": f"{type(exception).__name__}: {exception}",
            "elapsed_seconds": time.time() - started,
        }


def _task_worker(args):
    mode, task, truth_root, output_root = args
    started = time.time()
    try:
        configs = load_registered_configs(REPO_ROOT)
        case = _load_basin_case(task.basin_id, int(configs.base["window_days"]))
        truth_path = truth_bundle_path(Path(truth_root), task.basin_id, task.seed)
        bundle = load_truth_bundle(truth_path)
        if bundle.clip_count != 0:
            raise ValueError("formal truth bundle contains clips")
        if mode == "continuous":
            arrays = run_continuous_arrays(
                bundle=bundle,
                members=case["members"],
                sigma_obs=case["sigma_obs"],
                bounds=case["bounds"],
                knowledge_mode=task.knowledge_mode,
                interaction_mode=ARM_MODES[task.arm_id],
            )
        elif mode == "replay":
            replay = configs.replay
            arrays = run_replay_arrays(
                bundle=bundle,
                members=case["members"],
                sigma_obs=case["sigma_obs"],
                bounds=case["bounds"],
                knowledge_mode=task.knowledge_mode,
                interaction_mode=ARM_MODES[task.arm_id],
                switch_days=tuple(replay["switch_days"]),
                replay_days=int(replay["replay_days_per_event"]),
                initial_covariance_fraction=float(
                    replay["initial_covariance_fraction"]
                ),
            )
        else:
            raise ValueError(f"unknown run mode: {mode}")
        target = task_output_path(Path(output_root), task)
        target.parent.mkdir(parents=True, exist_ok=True)
        truth_hash = sha256_file(truth_path)
        compute_elapsed = time.time() - started
        _atomic_save_npz(
            target,
            **arrays,
            basin_id=np.array(task.basin_id),
            seed=np.array(task.seed, dtype=np.int64),
            arm_id=np.array(task.arm_id),
            interaction_mode=np.array(ARM_MODES[task.arm_id]),
            knowledge_mode=np.array(task.knowledge_mode),
            truth_bundle_sha256=np.array(truth_hash),
            preregistration_sha256=np.array(
                configs.base["registered_inputs"]["preregistration"]["sha256"]
            ),
            compute_elapsed_seconds=np.array(
                compute_elapsed, dtype=np.float64
            ),
            observation_sigma=np.array(case["sigma_obs"], dtype=np.float64),
            lag_capped=np.array(case["lag_capped"]),
        )
        return {
            "task_id": task.task_id,
            "run_status": "success",
            "elapsed_seconds": time.time() - started,
            "output_sha256": sha256_file(target),
            "truth_bundle_sha256": truth_hash,
        }
    except Exception as exception:  # noqa: BLE001 - preserved in manifest
        return {
            "task_id": task.task_id,
            "run_status": "failed",
            "error_message": f"{type(exception).__name__}: {exception}",
            "elapsed_seconds": time.time() - started,
        }


def _write_json_new(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")


def _git_text(*arguments) -> str:
    completed = subprocess.run(
        ["git", *arguments],
        cwd=REPO_ROOT,
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def verify_frozen_worktree(configs) -> str:
    """Refuse execution unless the frozen implementation is committed and clean."""

    statuses = {
        configs.base.get("configuration_status"),
        configs.continuous.get("configuration_status"),
        configs.replay.get("configuration_status"),
    }
    if statuses != {"frozen_preexecution"}:
        raise RuntimeError(f"experiment configuration is not frozen: {statuses}")
    dirty = _git_text("status", "--porcelain", "--untracked-files=all")
    if dirty:
        raise RuntimeError("formal execution requires a clean frozen worktree")
    return _git_text("rev-parse", "HEAD")


def _execution_metadata() -> dict:
    return {
        "git_commit": _git_text("rev-parse", "HEAD"),
        "base_config_sha256": sha256_file(REPO_ROOT / BASE_CONFIG),
        "continuous_config_sha256": sha256_file(
            REPO_ROOT / CONTINUOUS_CONFIG
        ),
        "replay_config_sha256": sha256_file(REPO_ROOT / REPLAY_CONFIG),
    }


def _execute_workers(worker, work, workers):
    if workers > 1 and len(work) > 1:
        with ProcessPoolExecutor(max_workers=workers) as pool:
            return list(pool.map(worker, work, chunksize=1))
    return [worker(item) for item in work]


def _finalize_manifest(root, records, metadata):
    failures = [item for item in records if item["run_status"] != "success"]
    elapsed = [item["elapsed_seconds"] for item in records if item["run_status"] == "success"]
    manifest = {
        **metadata,
        **_execution_metadata(),
        "n_tasks": len(records),
        "n_success": len(records) - len(failures),
        "n_failed": len(failures),
        "median_task_seconds": float(np.median(elapsed)) if elapsed else None,
        "total_success_task_seconds": float(np.sum(elapsed)) if elapsed else 0.0,
        "maximum_task_seconds": float(np.max(elapsed)) if elapsed else None,
    }
    _write_json_new(Path(root) / "verification" / "task_records.json", records)
    _write_json_new(Path(root) / "verification" / "run_failures.json", failures)
    _write_json_new(Path(root) / "verification" / "run_manifest.json", manifest)
    return manifest


def _prepare_atomic_output_root(final_root: Path) -> Path:
    """Create a private incomplete root while keeping the final identity absent."""

    final = Path(final_root)
    final.parent.mkdir(parents=True, exist_ok=True)
    if final.exists():
        raise FileExistsError(f"final output root already exists: {final}")
    abandoned = sorted(final.parent.glob(f"{final.name}.incomplete.*"))
    if abandoned:
        raise FileExistsError(
            "incomplete output identity already exists: "
            + ", ".join(str(path) for path in abandoned)
        )
    working = final.with_name(f"{final.name}.incomplete.{os.getpid()}")
    working.mkdir()
    return working


def _publish_atomic_output_root(working_root: Path, final_root: Path) -> None:
    """Publish one complete result tree with a same-volume atomic rename."""

    working = Path(working_root)
    final = Path(final_root)
    if final.exists():
        raise FileExistsError(f"final output root already exists: {final}")
    if not working.is_dir():
        raise FileNotFoundError(f"incomplete output root is missing: {working}")
    working.replace(final)


def generate_truth_packages(output_root, basins, seeds, workers, window_days):
    root = Path(output_root)
    working_root = _prepare_atomic_output_root(root)
    work = [
        (basin, int(seed), str(working_root), int(window_days))
        for basin in basins
        for seed in seeds
    ]
    records = _execute_workers(_generate_truth_worker, work, int(workers))
    manifest = _finalize_manifest(
        working_root,
        records,
        {"kind": "truth_observation", "basins": list(basins), "seeds": list(seeds)},
    )
    if manifest["n_failed"]:
        raise RuntimeError(
            f"truth generation failed for {manifest['n_failed']} tasks; "
            f"incomplete evidence retained at {working_root}"
        )
    _publish_atomic_output_root(working_root, root)
    return manifest


def run_formal_tasks(mode, output_root, truth_root, basins, seeds, workers):
    root = Path(output_root)
    working_root = _prepare_atomic_output_root(root)
    tasks = build_task_table(basins, seeds=seeds)
    work = [(mode, task, str(truth_root), str(working_root)) for task in tasks]
    records = _execute_workers(_task_worker, work, int(workers))
    manifest = _finalize_manifest(
        working_root,
        records,
        {
            "kind": mode,
            "basins": list(basins),
            "seeds": list(seeds),
            "arms": list(ARM_MODES),
            "knowledge_modes": list(KNOWLEDGE_MODES),
        },
    )
    if manifest["n_failed"]:
        raise RuntimeError(
            f"{mode} run failed for {manifest['n_failed']} tasks; "
            f"incomplete evidence retained at {working_root}"
        )
    _publish_atomic_output_root(working_root, root)
    return manifest


def evaluate_resource_route(measurements, thresholds) -> dict:
    """Apply every preregistered local-execution gate without discretion."""

    definitions = {
        "free_memory": (
            "free_memory_gb", "minimum_free_memory_gb", lambda value, limit: value >= limit
        ),
        "free_disk": (
            "free_disk_gb", "minimum_free_disk_gb", lambda value, limit: value >= limit
        ),
        "cpu_load": (
            "mean_cpu_percent", "maximum_mean_cpu_percent", lambda value, limit: value <= limit
        ),
        "wall_time": (
            "estimated_local_total_hours",
            "maximum_extrapolated_wall_hours",
            lambda value, limit: value <= limit,
        ),
        "peak_memory": (
            "peak_additional_memory_gb",
            "maximum_peak_additional_memory_gb",
            lambda value, limit: value <= limit,
        ),
    }
    gates = {}
    for name, (measurement_key, threshold_key, predicate) in definitions.items():
        value = float(measurements[measurement_key])
        threshold = float(thresholds[threshold_key])
        gates[name] = {
            "measurement": value,
            "threshold": threshold,
            "pass": bool(predicate(value, threshold)),
        }
    return {
        "gates": gates,
        "all_local_gates_pass": all(item["pass"] for item in gates.values()),
        "selected_route": (
            "local" if all(item["pass"] for item in gates.values()) else "hpc"
        ),
    }


def _process_tree_rss_bytes() -> int:
    import psutil

    process = psutil.Process(os.getpid())
    processes = [process, *process.children(recursive=True)]
    total = 0
    for candidate in processes:
        try:
            total += int(candidate.memory_info().rss)
        except (psutil.AccessDenied, psutil.NoSuchProcess):
            continue
    return total


def _local_resource_snapshot() -> dict:
    import psutil

    cpu_samples = [float(psutil.cpu_percent(interval=1.0)) for _ in range(3)]
    memory = psutil.virtual_memory()
    disk = shutil.disk_usage(REPO_ROOT)
    return {
        "logical_cpu_count": int(psutil.cpu_count(logical=True) or 0),
        "physical_cpu_count": int(psutil.cpu_count(logical=False) or 0),
        "cpu_percent_samples": cpu_samples,
        "mean_cpu_percent": float(np.mean(cpu_samples)),
        "free_memory_gb": float(memory.available / 1024**3),
        "free_disk_gb": float(disk.free / 1024**3),
    }


def _smoke(configs, workers):
    basin = admitted_basins()[0]
    seed = int(configs.base["smoke_seed"])
    stamp = f"{os.getpid()}_{int(time.time())}"
    smoke_parent = REPO_ROOT / "tmp" / f"joint_same_observation_smoke_{stamp}"
    truth_root = smoke_parent / "truth"
    task_root = smoke_parent / "continuous"
    resources = _local_resource_snapshot()
    baseline_rss = _process_tree_rss_bytes()
    peak_rss = [baseline_rss]
    stop_sampling = threading.Event()

    def sample_memory():
        while not stop_sampling.wait(0.05):
            peak_rss[0] = max(peak_rss[0], _process_tree_rss_bytes())

    sampler = threading.Thread(target=sample_memory, daemon=True)
    sampler.start()
    started = time.time()
    effective_workers = min(max(int(workers), 1), 6)
    try:
        truth_manifest = generate_truth_packages(
            truth_root, [basin], [seed], 1, 14
        )
        task_manifest = run_formal_tasks(
            "continuous",
            task_root,
            truth_root,
            [basin],
            [seed],
            effective_workers,
        )
    finally:
        peak_rss[0] = max(peak_rss[0], _process_tree_rss_bytes())
        stop_sampling.set()
        sampler.join(timeout=5.0)
    elapsed = time.time() - started
    truth_estimate_hours = (
        float(truth_manifest["total_success_task_seconds"])
        * (1260.0 / 14.0)
        * 72.0
        / effective_workers
        / 3600.0
    )
    filter_estimate_hours = (
        float(task_manifest["total_success_task_seconds"])
        * (1260.0 / 14.0)
        * 72.0
        * (1.0 + 1080.0 / 1260.0)
        / effective_workers
        / 3600.0
    )
    estimate_hours = truth_estimate_hours + filter_estimate_hours
    measurements = {
        **resources,
        "estimated_local_total_hours": estimate_hours,
        "estimated_truth_generation_hours": truth_estimate_hours,
        "estimated_filter_hours": filter_estimate_hours,
        "baseline_process_tree_memory_gb": float(baseline_rss / 1024**3),
        "peak_process_tree_memory_gb": float(peak_rss[0] / 1024**3),
        "peak_additional_memory_gb": float(
            max(peak_rss[0] - baseline_rss, 0) / 1024**3
        ),
    }
    route = evaluate_resource_route(
        measurements,
        configs.continuous["resource_route"],
    )
    payload = {
        "basin_id": basin,
        "smoke_seed": seed,
        "elapsed_seconds": elapsed,
        "six_mode_14_day_task_seconds": float(
            task_manifest["total_success_task_seconds"]
        ),
        "workers": effective_workers,
        "smoke_root": str(smoke_parent),
        "measurements": measurements,
        "route_decision": route,
    }
    _write_json_new(smoke_parent / "resource_estimate.json", payload)
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "mode", choices=("preflight", "truth", "smoke", "continuous", "replay")
    )
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--basins", nargs="*", default=None)
    parser.add_argument("--seeds", nargs="*", type=int, default=None)
    parser.add_argument("--output-root", type=Path, default=None)
    parser.add_argument("--route", choices=("local", "hpc"), default="local")
    arguments = parser.parse_args()
    configs = load_registered_configs(REPO_ROOT)
    frozen_commit = verify_frozen_worktree(configs)
    basins = [value.zfill(8) for value in (arguments.basins or admitted_basins())]
    seeds = arguments.seeds or list(configs.base["formal_seeds"])
    if arguments.mode == "preflight":
        payload = {
            "frozen_commit": frozen_commit,
            "basin_count": len(basins),
            "seeds": seeds,
            "formal_task_count": len(build_task_table(basins, seeds)),
            "truth_task_count": len(basins) * len(seeds),
        }
    elif arguments.mode == "smoke":
        payload = _smoke(configs, arguments.workers)
    elif arguments.mode == "truth":
        output = arguments.output_root or REPO_ROOT / configs.base["truth_output_root"]
        payload = generate_truth_packages(
            output,
            basins,
            seeds,
            arguments.workers,
            int(configs.base["window_days"]),
        )
    else:
        selected = configs.continuous if arguments.mode == "continuous" else configs.replay
        output = arguments.output_root or REPO_ROOT / selected[
            f"output_root_{arguments.route}"
        ]
        truth_root = REPO_ROOT / configs.base["truth_output_root"]
        payload = run_formal_tasks(
            arguments.mode,
            output,
            truth_root,
            basins,
            seeds,
            arguments.workers,
        )
    print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
