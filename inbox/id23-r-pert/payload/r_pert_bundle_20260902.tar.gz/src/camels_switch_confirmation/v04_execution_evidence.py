"""Fourth-version lifecycle evidence layered over the frozen restart verifier.

The fourth-version freeze credential intentionally records only its changes
from the third-version experiment.  Restart telemetry keeps the established
third-version schema, so this module constructs a verifier-only view of that
unchanged base contract while separately validating the real fourth-version
credential and its new environment evidence.
"""

from __future__ import annotations

import copy
import hashlib
import json
import re
from collections.abc import Mapping
from datetime import date
from pathlib import Path
from typing import Any

from camels_switch_confirmation import protocol_freeze_v04, v03_execution_evidence
from camels_switch_confirmation.real_regime_parameter_calibration import (
    warmup_memory_compatibility,
)
from scl_hydro.hbv_lite_numpy import resolve_hbv_bounds


REQUIRED_RUNTIME_DISTRIBUTIONS = ("numpy", "pandas", "cma", "numba")
_COMMAND_RECORD_FIELDS = {
    "command",
    "status",
    "capture_method",
    "returncode",
    "stdout",
    "stderr",
    "error_type",
    "error_message",
    "fallback_error_type",
    "fallback_error_message",
    "saved_output_sha256",
}


class V04ExecutionEvidenceError(ValueError):
    """Raised when fourth-version execution evidence is incomplete or altered."""


def _fail(message: str) -> None:
    raise V04ExecutionEvidenceError(message)


def _strict_json_file(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(
            Path(path).read_text(encoding="utf-8"),
            parse_constant=lambda item: (_ for _ in ()).throw(ValueError(item)),
        )
    except (OSError, UnicodeError, ValueError, json.JSONDecodeError) as error:
        raise V04ExecutionEvidenceError(f"{label} is not strict finite JSON") from error
    if type(value) is not dict:
        _fail(f"{label} must be a plain object")
    return value


def _sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def build_restart_evidence_credential(
    repo_root: Path,
    v04_credential: Mapping[str, Any],
) -> dict[str, Any]:
    """Build the exact verifier view for unchanged third-version restart evidence."""

    root = Path(repo_root).resolve()
    checked = protocol_freeze_v04.validate_v04_protocol_document(root, v04_credential)
    base_config_path = root / str(checked["base_config_path"])
    base_config = _strict_json_file(base_config_path, "third-version base configuration")
    if base_config.get("experiment_id") != checked["base_experiment_id"]:
        _fail("third-version base configuration experiment identity differs")
    raw_credential_path = base_config.get("protocol_credential")
    expected_digest = base_config.get("protocol_credential_sha256")
    if type(raw_credential_path) is not str or type(expected_digest) is not str:
        _fail("third-version base configuration lacks its protocol binding")
    relative = Path(raw_credential_path)
    if relative.is_absolute() or ".." in relative.parts:
        _fail("third-version base credential path is unsafe")
    base_credential_path = (root / relative).resolve()
    if not base_credential_path.is_file() or _sha256(base_credential_path) != expected_digest:
        _fail("third-version base credential identity differs")
    base_credential = _strict_json_file(base_credential_path, "third-version base credential")

    adapted = copy.deepcopy(base_credential)
    adapted["protocol_id"] = checked["protocol_id"]
    adapted["human_protocol_path"] = checked["human_protocol_path"]
    adapted["human_protocol_sha256"] = checked["human_protocol_sha256"]
    fixed = adapted.get("fixed_factors")
    if not isinstance(fixed, dict):
        _fail("third-version base credential lacks fixed factors")
    fixed["parameter_bounds_preset"] = protocol_freeze_v04.V04_PARAMETER_DOMAIN["preset"]
    # This call is the schema authority for the adapted mapping.  It fails if
    # any unchanged restart-evidence field drifts from the established format.
    v03_execution_evidence._freeze_contract(adapted)
    return adapted


def _validate_command_record(
    value: Any,
    *,
    filename: str,
) -> dict[str, Any]:
    if type(value) is not dict or set(value) != _COMMAND_RECORD_FIELDS:
        _fail(f"environment command record for {filename} has wrong fields")
    command = value["command"]
    if not isinstance(command, list) or not command or any(
        not isinstance(part, str) or not part for part in command
    ):
        _fail(f"environment command for {filename} is invalid")
    for field in (
        "status",
        "capture_method",
        "stdout",
        "stderr",
        "error_type",
        "error_message",
        "fallback_error_type",
        "fallback_error_message",
        "saved_output_sha256",
    ):
        if not isinstance(value[field], str):
            _fail(f"environment command {filename} {field} must be text")
    if value["returncode"] is not None and type(value["returncode"]) is not int:
        _fail(f"environment command {filename} return code is invalid")
    if value["status"] not in {"primary_complete", "fallback_complete", "incomplete"}:
        _fail(f"environment command {filename} status is invalid")
    if re.fullmatch(r"[0-9a-f]{64}", value["saved_output_sha256"]) is None:
        _fail(f"environment command {filename} saved output hash is invalid")
    return dict(value)


def _inventory_distribution_versions(text: str) -> dict[str, str]:
    """Parse deterministic ``name==version`` rows from a package inventory."""

    versions: dict[str, str] = {}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        match = re.fullmatch(r"([A-Za-z0-9][A-Za-z0-9._-]*)==([^\s]+)", line)
        if match is None:
            continue
        name = re.sub(r"[-_.]+", "-", match.group(1)).lower()
        version = match.group(2)
        if name in versions and versions[name] != version:
            _fail(f"Python package inventory contains conflicting versions for {name}")
        versions[name] = version
    return versions


def _validate_inventory_runtime_versions(
    inventory_text: str,
    environment_versions: Mapping[str, Any],
) -> dict[str, str]:
    inventory_versions = _inventory_distribution_versions(inventory_text)
    checked: dict[str, str] = {}
    for distribution in REQUIRED_RUNTIME_DISTRIBUTIONS:
        expected = environment_versions.get(distribution)
        actual = inventory_versions.get(distribution)
        if not isinstance(expected, str) or not expected:
            _fail(f"environment record lacks the {distribution} runtime version")
        if actual is None:
            _fail(f"Python package inventory lacks the {distribution} runtime version")
        if actual != expected:
            _fail(
                f"Python package inventory {distribution} version differs from "
                "the runtime environment"
            )
        checked[distribution] = actual
    return checked


def _validate_environment_payload(
    capture_record: Mapping[str, Any],
    environment: Mapping[str, Any],
    saved_outputs: Mapping[str, Any],
    *,
    allow_incomplete_python_inventory: bool,
) -> dict[str, Any]:
    """Apply the same environment contract before optimization and after saving."""

    if type(capture_record) is not dict or set(capture_record) != {
        "schema_version",
        "overall_status",
        "commands",
    }:
        _fail("environment capture record has wrong fields")
    if capture_record["schema_version"] != 1:
        _fail("environment capture schema version must equal one")
    if capture_record["overall_status"] not in {
        "primary_complete",
        "fallback_complete",
        "incomplete",
    }:
        _fail("environment capture overall status is invalid")
    commands = capture_record["commands"]
    if type(commands) is not dict or set(commands) != {
        "python_packages.txt",
        "conda_explicit.txt",
    }:
        _fail("environment capture commands are incomplete")
    python_record = _validate_command_record(
        commands["python_packages.txt"],
        filename="python_packages.txt",
    )
    conda_record = _validate_command_record(
        commands["conda_explicit.txt"],
        filename="conda_explicit.txt",
    )
    if python_record["command"][1:] != ["-m", "pip", "freeze", "--all"]:
        _fail("primary Python package inventory command differs from pip freeze --all")
    if conda_record["command"] != ["conda", "list", "--explicit"]:
        _fail("conda inventory command differs from the declared diagnostic")

    python_status = python_record["status"]
    if python_status == "primary_complete":
        if (
            python_record["capture_method"] != "pip_freeze_all"
            or python_record["returncode"] != 0
            or python_record["error_type"]
            or python_record["fallback_error_type"]
        ):
            _fail("primary Python package inventory status is internally inconsistent")
    elif python_status == "fallback_complete":
        if (
            python_record["capture_method"] != "importlib_metadata"
            or python_record["returncode"] == 0
            or not python_record["error_type"]
            or python_record["fallback_error_type"]
        ):
            _fail("Python package fallback is unlabelled or internally inconsistent")
    else:
        if (
            python_record["capture_method"] != "unavailable"
            or not python_record["error_type"]
            or not python_record["fallback_error_type"]
        ):
            _fail("incomplete Python package inventory is internally inconsistent")
        if not allow_incomplete_python_inventory:
            _fail("Python package inventory primary and fallback are both unavailable")

    conda_status = conda_record["status"]
    if conda_status == "primary_complete":
        if (
            conda_record["capture_method"] != "conda_list_explicit"
            or conda_record["returncode"] != 0
            or conda_record["error_type"]
            or conda_record["fallback_error_type"]
        ):
            _fail("primary conda inventory status is internally inconsistent")
    elif conda_status == "incomplete":
        if conda_record["capture_method"] != "unavailable" or not conda_record[
            "error_type"
        ]:
            _fail("incomplete conda inventory status is internally inconsistent")
    else:
        _fail("conda inventory cannot use the Python metadata fallback")

    statuses = {python_status, conda_status}
    if statuses == {"primary_complete"}:
        expected_overall_status = "primary_complete"
    elif statuses <= {"primary_complete", "fallback_complete"}:
        expected_overall_status = "fallback_complete"
    else:
        expected_overall_status = "incomplete"
    if capture_record["overall_status"] != expected_overall_status:
        _fail("environment capture overall status disagrees with command statuses")

    if type(saved_outputs) is not dict or set(saved_outputs) != {
        "python_packages.txt",
        "conda_explicit.txt",
    }:
        _fail("saved environment inventories have wrong fields")
    for filename in ("python_packages.txt", "conda_explicit.txt"):
        saved = saved_outputs[filename]
        if not isinstance(saved, str):
            _fail(f"saved environment inventory must be text: {filename}")
        if not saved.strip():
            _fail(f"saved environment inventory is empty: {filename}")
        record = python_record if filename == "python_packages.txt" else conda_record
        if hashlib.sha256(saved.encode("utf-8")).hexdigest() != record[
            "saved_output_sha256"
        ]:
            _fail(f"saved environment inventory hash differs: {filename}")
        if record["status"] == "primary_complete" and saved != record["stdout"]:
            _fail(f"saved {'Python' if filename.startswith('python') else 'conda'} inventory differs from command output")

    if not isinstance(environment, Mapping):
        _fail("environment record must be a mapping")
    for field in ("python", "python_executable", "platform"):
        if not isinstance(environment.get(field), str) or not environment[field]:
            _fail(f"environment record lacks {field}")
    versions = environment.get("package_versions")
    if not isinstance(versions, Mapping):
        _fail("environment record lacks package versions")
    missing_runtime_versions = [
        distribution
        for distribution in REQUIRED_RUNTIME_DISTRIBUTIONS
        if not isinstance(versions.get(distribution), str)
        or not versions.get(distribution)
    ]
    if missing_runtime_versions and not allow_incomplete_python_inventory:
        _fail(
            "environment record lacks the "
            f"{missing_runtime_versions[0]} runtime version"
        )
    verified_inventory_versions: dict[str, str] = {}
    inventory_runtime_error = ""
    if (
        python_status in {"primary_complete", "fallback_complete"}
        and not missing_runtime_versions
    ):
        try:
            verified_inventory_versions = _validate_inventory_runtime_versions(
                saved_outputs["python_packages.txt"],
                versions,
            )
        except V04ExecutionEvidenceError as error:
            if not allow_incomplete_python_inventory:
                raise
            inventory_runtime_error = str(error)
    return {
        "complete": (
            python_status in {"primary_complete", "fallback_complete"}
            and not missing_runtime_versions
            and not inventory_runtime_error
        ),
        "python_inventory_status": python_status,
        "conda_inventory_status": conda_record["status"],
        "required_runtime_versions": {
            name: versions.get(name) for name in REQUIRED_RUNTIME_DISTRIBUTIONS
        },
        "missing_runtime_versions": missing_runtime_versions,
        "verified_inventory_versions": verified_inventory_versions,
        "inventory_runtime_error": inventory_runtime_error,
    }


def validate_environment_capture(
    output_directory: Path,
    capture_record: Mapping[str, Any],
    environment: Mapping[str, Any],
    *,
    allow_incomplete_python_inventory: bool = False,
) -> dict[str, Any]:
    """Validate one cached inventory and the saved command diagnostics.

    A conda inventory is useful evidence but is not a completion condition.
    The frozen rule requires either the primary ``pip freeze --all`` output or
    the explicitly labelled in-process package-metadata fallback.
    """

    output = Path(output_directory).resolve()
    saved_outputs: dict[str, str] = {}
    for filename in ("python_packages.txt", "conda_explicit.txt"):
        path = output / filename
        if not path.is_file():
            _fail(f"saved environment inventory is missing: {filename}")
        try:
            saved_outputs[filename] = path.read_text(encoding="utf-8")
        except (OSError, UnicodeError) as error:
            raise V04ExecutionEvidenceError(
                f"saved environment inventory cannot be read: {filename}"
            ) from error
    return _validate_environment_payload(
        capture_record,
        environment,
        saved_outputs,
        allow_incomplete_python_inventory=allow_incomplete_python_inventory,
    )


def cached_python_inventory_complete(capture: Mapping[str, Any]) -> bool:
    """Return whether one pre-optimizer capture has an accepted Python inventory."""

    if not isinstance(capture, Mapping) or set(capture) != {"outputs", "capture_record"}:
        _fail("cached environment inventory has wrong fields")
    outputs = capture["outputs"]
    record = capture["capture_record"]
    if not isinstance(outputs, Mapping) or set(outputs) != {
        "python_packages.txt",
        "conda_explicit.txt",
    }:
        _fail("cached environment inventory outputs are incomplete")
    if not isinstance(record, Mapping):
        _fail("cached environment capture record is missing")
    commands = record.get("commands")
    if not isinstance(commands, Mapping):
        _fail("cached environment capture commands are missing")
    python_record = _validate_command_record(
        commands.get("python_packages.txt"),
        filename="python_packages.txt",
    )
    status = python_record["status"]
    if status == "primary_complete":
        if python_record["capture_method"] != "pip_freeze_all" or python_record["returncode"] != 0:
            _fail("cached primary Python inventory is inconsistent")
        if outputs["python_packages.txt"] != python_record["stdout"]:
            _fail("cached primary Python inventory output differs from its command record")
        return True
    if status == "fallback_complete":
        if (
            python_record["capture_method"] != "importlib_metadata"
            or python_record["returncode"] == 0
            or not python_record["error_type"]
        ):
            _fail("cached fallback Python inventory is inconsistent")
        if not isinstance(outputs["python_packages.txt"], str) or not outputs[
            "python_packages.txt"
        ].strip():
            _fail("cached fallback Python inventory output is empty")
        return True
    return False


def cached_runtime_environment_complete(environment: Mapping[str, Any]) -> bool:
    """Return whether the cached runtime identity is complete before optimization."""

    if not isinstance(environment, Mapping):
        _fail("cached runtime environment must be a mapping")
    for field in ("python", "python_executable", "platform"):
        if not isinstance(environment.get(field), str) or not environment[field]:
            _fail(f"cached runtime environment lacks {field}")
    versions = environment.get("package_versions")
    if not isinstance(versions, Mapping):
        _fail("cached runtime environment lacks package versions")
    return all(
        isinstance(versions.get(distribution), str)
        and bool(versions.get(distribution))
        for distribution in REQUIRED_RUNTIME_DISTRIBUTIONS
    )


def cached_environment_capture_complete(
    capture: Mapping[str, Any],
    environment: Mapping[str, Any],
) -> bool:
    """Validate the accepted cached inventory before any optimizer call."""

    if not isinstance(capture, Mapping) or set(capture) != {
        "outputs",
        "capture_record",
    }:
        _fail("cached environment inventory has wrong fields")
    result = _validate_environment_payload(
        capture["capture_record"],
        environment,
        capture["outputs"],
        allow_incomplete_python_inventory=False,
    )
    return bool(result["complete"])


def parameter_domain_warmup_memory_record(config: Mapping[str, Any]) -> dict[str, Any]:
    """Recompute the frozen parameter domain and analytical warmup-memory gate."""

    if not isinstance(config, Mapping):
        _fail("fourth-version configuration must be a mapping")
    if config.get("experiment_id") != protocol_freeze_v04.V04_EXPERIMENT_ID:
        _fail("parameter-domain record requires the exact fourth-version experiment")
    preset = config.get("parameter_bounds_preset")
    if preset != protocol_freeze_v04.V04_PARAMETER_DOMAIN["preset"]:
        _fail("parameter-domain preset differs from the fourth-version freeze")
    periods = config.get("periods")
    if not isinstance(periods, Mapping) or not isinstance(periods.get("warmup"), Mapping):
        _fail("fourth-version warmup period is missing")
    warmup = periods["warmup"]
    if set(warmup) != {"start", "end"}:
        _fail("fourth-version warmup period has wrong fields")
    try:
        start = date.fromisoformat(str(warmup["start"]))
        end = date.fromisoformat(str(warmup["end"]))
    except ValueError as error:
        raise V04ExecutionEvidenceError("fourth-version warmup dates are invalid") from error
    if (start.isoformat(), end.isoformat()) != ("1989-10-01", "1999-09-30"):
        _fail("fourth-version warmup dates differ from the freeze")
    days = (end - start).days + 1
    compatibility = config.get("initialization_compatibility")
    if compatibility != protocol_freeze_v04.V04_INITIALIZATION_COMPATIBILITY:
        _fail("fourth-version initialization compatibility differs from the freeze")
    threshold = float(
        protocol_freeze_v04.V04_INITIALIZATION_COMPATIBILITY["analytical_memory"][
            "retained_fraction_max"
        ]
    )
    bounds = resolve_hbv_bounds(str(preset))
    memory = warmup_memory_compatibility(
        bounds,
        days,
        retained_fraction_max=threshold,
    )
    return {
        "schema_version": 1,
        "parameter_bounds_preset": str(preset),
        "parameter_bounds": {
            name: [float(interval[0]), float(interval[1])]
            for name, interval in bounds.items()
        },
        "warmup": {
            "start": start.isoformat(),
            "end": end.isoformat(),
            "days": days,
            "observations_use": compatibility["warmup_observations_use"],
        },
        "analytical_memory": memory,
    }


def validate_parameter_domain_warmup_memory_record(
    record: Mapping[str, Any],
    config: Mapping[str, Any],
) -> dict[str, Any]:
    """Reject any saved parameter-domain record that differs from recomputation."""

    if type(record) is not dict:
        _fail("parameter-domain warmup-memory record must be a plain object")
    expected = parameter_domain_warmup_memory_record(config)
    if record != expected:
        _fail("parameter-domain warmup-memory record differs from recomputation")
    return copy.deepcopy(expected)


def verify_execution_evidence(
    output_directory: Path,
    credential_path: Path,
    *,
    repo_root: Path,
    expected_experiment_id: str | None = None,
    expected_run_instance_id: str | None = None,
    expected_config_sha256: str | None = None,
    expected_selected_parameter_fingerprints: Mapping[str, str] | None = None,
    allow_failed: bool = False,
) -> dict[str, Any]:
    """Verify shared restart evidence plus every fourth-version lifecycle addition."""

    output = Path(output_directory).resolve()
    root = Path(repo_root).resolve()
    config = _strict_json_file(output / "config_snapshot.json", "configuration snapshot")
    protocol_freeze_v04.validate_v04_registration_config(root, config)
    configured_credential = (root / str(config["protocol_credential"])).resolve()
    supplied_credential = Path(credential_path).resolve()
    if supplied_credential != configured_credential:
        _fail("supplied fourth-version credential path differs from the configuration")
    credential = protocol_freeze_v04.load_frozen_protocol(
        root,
        supplied_credential,
        expected_sha256=str(config["protocol_credential_sha256"]),
    )
    missing = [
        filename
        for filename in credential["evidence_contract"]["required_new_artifacts"]
        if not (output / filename).is_file()
    ]
    if missing:
        _fail(f"fourth-version execution evidence lacks required artifacts: {missing}")
    validate_parameter_domain_warmup_memory_record(
        _strict_json_file(
            output / "parameter_domain_warmup_memory.json",
            "parameter-domain warmup-memory record",
        ),
        config,
    )

    manifest = _strict_json_file(output / "run_manifest.json", "run manifest")
    protocol = manifest.get("protocol")
    if not isinstance(protocol, Mapping):
        _fail("run manifest lacks protocol identity")
    expected_protocol = {
        "protocol_id": credential["protocol_id"],
        "credential_path": str(config["protocol_credential"]).replace("\\", "/"),
        "credential_sha256": str(config["protocol_credential_sha256"]),
        "human_protocol_path": credential["human_protocol_path"],
        "human_protocol_sha256": credential["human_protocol_sha256"],
    }
    if dict(protocol) != expected_protocol:
        _fail("run manifest protocol identity differs from the fourth-version freeze")

    adapted = build_restart_evidence_credential(root, credential)
    shared = v03_execution_evidence.verify_execution_evidence(
        output,
        adapted,
        expected_experiment_id=expected_experiment_id,
        expected_run_instance_id=expected_run_instance_id,
        expected_config_sha256=expected_config_sha256,
        expected_selected_parameter_fingerprints=expected_selected_parameter_fingerprints,
        allow_failed=allow_failed,
    )
    capture_record = _strict_json_file(
        output / "environment_capture.json",
        "environment capture",
    )
    environment = _strict_json_file(output / "environment.json", "environment record")
    capture = validate_environment_capture(
        output,
        capture_record,
        environment,
        allow_incomplete_python_inventory=allow_failed,
    )
    if not capture["complete"] and (
        shared["terminal_status"] != "failed" or shared["restart_count"] != 0
    ):
        _fail("incomplete Python inventory is allowed only for a zero-restart failed package")
    return {**shared, "environment_capture": capture}


__all__ = [
    "REQUIRED_RUNTIME_DISTRIBUTIONS",
    "V04ExecutionEvidenceError",
    "build_restart_evidence_credential",
    "cached_environment_capture_complete",
    "cached_python_inventory_complete",
    "cached_runtime_environment_complete",
    "parameter_domain_warmup_memory_record",
    "validate_environment_capture",
    "validate_parameter_domain_warmup_memory_record",
    "verify_execution_evidence",
]
