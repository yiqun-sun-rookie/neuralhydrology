"""Create audited post-seal validation hydrographs for the fourth-version screen.

The plotting path is deliberately downstream of the public result verifier. It
uses only fit-selected identities already stored in the sealed result package,
does not choose or promote a restart, and refuses to write inside the package.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from pathlib import Path
from typing import Any, Mapping, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from camels_switch_confirmation.run_real_regime_parameter_calibration import (
    verify_result_directory,
)


EXPERIMENT_ID = "real_regime_parameter_calibration_development_screen_v04"
PARAMETER_IDS = ("all_flow", "low_flow", "high_flow")
FIGURE_FILENAME = "selected_validation_hydrographs_linear_log.png"
MANIFEST_FILENAME = "figure_manifest.json"
IDENTITY_COLUMNS = (
    "basin_id",
    "parameter_id",
    "restart_index",
    "seed",
    "parameter_sha256",
)
IDENTITY_WITHOUT_FINGERPRINT = IDENTITY_COLUMNS[:-1]
WIDE_COLUMNS = (
    "basin_id",
    "date",
    "observed_flow_mm_day",
    "general_parameter_flow_mm_day",
    "low_flow_parameter_flow_mm_day",
    "high_flow_parameter_flow_mm_day",
)
LONG_REQUIRED_COLUMNS = (
    *IDENTITY_COLUMNS,
    "date",
    "observed_flow_mm_day",
    "simulated_flow_mm_day",
    "selected",
)
PARAMETER_OUTPUT_COLUMNS = {
    "all_flow": "general_parameter_flow_mm_day",
    "low_flow": "low_flow_parameter_flow_mm_day",
    "high_flow": "high_flow_parameter_flow_mm_day",
}
INPUT_ARTIFACTS = (
    "config_snapshot.json",
    "validation_hydrographs.csv",
    "validation_restart_hydrographs.csv",
    "restart_parameter_vectors.csv",
    "initial_state_convergence_metrics.csv",
    "hydrograph_response_metrics.csv",
    "checksums.json",
    "run_manifest.json",
)
LINE_STYLES = {
    "observed": {"label": "Observed", "color": "#111111", "linestyle": "-", "linewidth": 1.35},
    "all_flow": {
        "label": "All-flow parameters",
        "color": "#0072B2",
        "linestyle": "-",
        "linewidth": 0.95,
    },
    "low_flow": {
        "label": "Low-flow parameters",
        "color": "#009E73",
        "linestyle": "--",
        "linewidth": 0.95,
    },
    "high_flow": {
        "label": "High-flow parameters",
        "color": "#D55E00",
        "linestyle": "-.",
        "linewidth": 0.95,
    },
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _sealed_package_hashes(directory: Path) -> dict[str, str]:
    return {
        path.relative_to(directory).as_posix(): _sha256(path)
        for path in sorted(directory.rglob("*"))
        if path.is_file()
    }


def _sealed_package_digest(hashes: Mapping[str, str]) -> str:
    payload = json.dumps(dict(hashes), sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _load_json(path: Path) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise ValueError(f"{path.name} must contain a JSON object")
    return value


def _require_columns(table: pd.DataFrame, columns: Sequence[str], label: str) -> None:
    missing = sorted(set(columns) - set(table.columns))
    if missing:
        raise ValueError(f"{label} lacks required columns: {missing}")


def _strict_boolean_column(table: pd.DataFrame, column: str, label: str) -> pd.Series:
    if column not in table:
        raise ValueError(f"{label} lacks {column}")
    raw = table[column]
    if raw.isna().any():
        raise ValueError(f"{label} {column} must contain only true or false")
    text = raw.astype(str)
    if not text.isin(("True", "False", "true", "false")).all():
        raise ValueError(f"{label} {column} must contain only true or false")
    return text.str.lower() == "true"


def _strict_numeric_column(table: pd.DataFrame, column: str, label: str) -> np.ndarray:
    if column not in table:
        raise ValueError(f"{label} lacks {column}")
    try:
        values = pd.to_numeric(table[column], errors="raise").to_numpy(dtype=float)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{label} {column} must be numeric") from error
    if not np.all(np.isfinite(values)):
        raise ValueError(f"{label} {column} must be finite")
    return values


def _normalize_identity_table(table: pd.DataFrame, label: str) -> pd.DataFrame:
    _require_columns(table, (*IDENTITY_COLUMNS, "selected"), label)
    normalized = table.copy()
    normalized["basin_id"] = normalized["basin_id"].astype(str).str.zfill(8)
    if not normalized["parameter_id"].isin(PARAMETER_IDS).all():
        raise ValueError(f"{label} contains an unknown parameter group")
    for column in ("restart_index", "seed"):
        values = _strict_numeric_column(normalized, column, label)
        if not np.equal(values, np.floor(values)).all():
            raise ValueError(f"{label} {column} must contain integers")
        normalized[column] = values.astype(np.int64)
    fingerprints = normalized["parameter_sha256"].astype(str)
    if not fingerprints.str.fullmatch(r"[0-9a-f]{64}").all():
        raise ValueError(f"{label} parameter_sha256 must contain lowercase SHA-256 values")
    normalized["parameter_sha256"] = fingerprints
    normalized["selected"] = _strict_boolean_column(normalized, "selected", label)
    return normalized


def _identity_records(table: pd.DataFrame) -> list[dict[str, Any]]:
    records = []
    for row in table.loc[:, (*IDENTITY_COLUMNS, "selected")].itertuples(index=False):
        records.append({
            "basin_id": str(row.basin_id),
            "parameter_id": str(row.parameter_id),
            "restart_index": int(row.restart_index),
            "seed": int(row.seed),
            "parameter_sha256": str(row.parameter_sha256),
            "selected": bool(row.selected),
        })
    return records


def _expected_restart_keys(
    basin_ids: Sequence[str], restart_seeds: Sequence[int]
) -> set[tuple[str, str, int, int]]:
    return {
        (basin_id, parameter_id, restart_index, int(seed))
        for basin_id in basin_ids
        for parameter_id in PARAMETER_IDS
        for restart_index, seed in enumerate(restart_seeds)
    }


def _validate_restart_identities(
    vectors: pd.DataFrame,
    long_table: pd.DataFrame,
    basin_ids: Sequence[str],
    restart_seeds: Sequence[int],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    vectors = _normalize_identity_table(vectors, "restart_parameter_vectors.csv")
    long_table = _normalize_identity_table(long_table, "validation_restart_hydrographs.csv")
    vector_keys = list(IDENTITY_WITHOUT_FINGERPRINT)
    if vectors.duplicated(vector_keys).any():
        raise ValueError("restart_parameter_vectors.csv contains duplicate restart identities")
    expected = _expected_restart_keys(basin_ids, restart_seeds)
    actual = set(vectors.loc[:, vector_keys].itertuples(index=False, name=None))
    if actual != expected:
        raise ValueError("restart parameter identities differ from the frozen basin-seed product")

    long_identity = long_table.loc[:, (*IDENTITY_COLUMNS, "selected")].drop_duplicates()
    if long_identity.duplicated(vector_keys).any():
        raise ValueError("validation restart hydrographs contain conflicting identity metadata")
    merged = long_identity.merge(
        vectors.loc[:, (*IDENTITY_COLUMNS, "selected")],
        on=vector_keys,
        how="outer",
        suffixes=("_long", "_vector"),
        indicator=True,
        validate="one_to_one",
    )
    if not (merged["_merge"] == "both").all():
        raise ValueError("validation restart identities differ from restart parameter vectors")
    if not (
        (merged["parameter_sha256_long"] == merged["parameter_sha256_vector"])
        & (merged["selected_long"] == merged["selected_vector"])
    ).all():
        raise ValueError("validation restart identity metadata differ from restart parameter vectors")

    selected_vectors = vectors[vectors["selected"]].copy()
    selected_long_identities = long_identity[long_identity["selected"]].copy()
    selected_counts = vectors.groupby(["basin_id", "parameter_id"], sort=False)[
        "selected"
    ].sum()
    if len(selected_counts) != len(basin_ids) * len(PARAMETER_IDS) or not (
        selected_counts == 1
    ).all():
        raise ValueError("each basin and parameter group must have exactly one selected identity")
    vector_selected = set(
        selected_vectors.loc[:, IDENTITY_COLUMNS].itertuples(index=False, name=None)
    )
    long_selected = set(
        selected_long_identities.loc[:, IDENTITY_COLUMNS].itertuples(index=False, name=None)
    )
    if vector_selected != long_selected:
        raise ValueError("selected identities differ between wide restart evidence tables")
    expected_selected = len(basin_ids) * len(PARAMETER_IDS)
    if len(selected_vectors) != expected_selected:
        raise ValueError("each basin and parameter group must have exactly one selected identity")
    return vectors, long_table


def _parse_dates(values: pd.Series, label: str) -> pd.DatetimeIndex:
    try:
        dates = pd.DatetimeIndex(pd.to_datetime(values, errors="raise"))
    except (TypeError, ValueError) as error:
        raise ValueError(f"{label} contains an invalid date") from error
    if not dates.is_unique or not dates.is_monotonic_increasing:
        raise ValueError(f"{label} dates must be unique and strictly increasing")
    return dates


def _validate_flow(values: pd.Series, label: str) -> np.ndarray:
    try:
        flow = pd.to_numeric(values, errors="raise").to_numpy(dtype=float)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{label} must be numeric") from error
    if not np.all(np.isfinite(flow)) or np.any(flow < 0.0):
        raise ValueError(f"{label} must be finite and nonnegative")
    return flow


def _validate_daily_hydrographs(
    wide: pd.DataFrame,
    long_table: pd.DataFrame,
    basin_ids: Sequence[str],
    expected_dates: pd.DatetimeIndex,
) -> dict[str, Any]:
    if tuple(wide.columns) != WIDE_COLUMNS:
        raise ValueError("validation_hydrographs.csv has the wrong columns or order")
    _require_columns(long_table, LONG_REQUIRED_COLUMNS, "validation_restart_hydrographs.csv")
    wide = wide.copy()
    wide["basin_id"] = wide["basin_id"].astype(str).str.zfill(8)
    if tuple(wide["basin_id"].drop_duplicates()) != tuple(basin_ids):
        raise ValueError("validation_hydrographs.csv basin order differs from the sealed summary")

    selected_long = long_table[long_table["selected"]].copy()
    compared_series = 0
    compared_rows = 0
    for basin_id in basin_ids:
        wide_basin = wide[wide["basin_id"] == basin_id].copy()
        dates = _parse_dates(wide_basin["date"], f"wide hydrograph {basin_id}")
        if not dates.equals(expected_dates):
            raise ValueError(f"wide hydrograph {basin_id} does not cover the exact validation period")
        wide_basin["date"] = dates
        observed = _validate_flow(
            wide_basin["observed_flow_mm_day"], f"wide observed flow {basin_id}"
        )
        for parameter_id, output_column in PARAMETER_OUTPUT_COLUMNS.items():
            simulated = _validate_flow(
                wide_basin[output_column], f"wide {parameter_id} flow {basin_id}"
            )
            selected = selected_long[
                (selected_long["basin_id"] == basin_id)
                & (selected_long["parameter_id"] == parameter_id)
            ].copy()
            selected_dates = _parse_dates(
                selected["date"], f"selected restart hydrograph {basin_id} {parameter_id}"
            )
            if not selected_dates.equals(expected_dates):
                raise ValueError(
                    f"selected restart hydrograph {basin_id} {parameter_id} lacks exact validation dates"
                )
            selected_observed = _validate_flow(
                selected["observed_flow_mm_day"],
                f"selected restart observed flow {basin_id} {parameter_id}",
            )
            selected_simulated = _validate_flow(
                selected["simulated_flow_mm_day"],
                f"selected restart simulated flow {basin_id} {parameter_id}",
            )
            if not np.array_equal(observed, selected_observed) or not np.array_equal(
                simulated, selected_simulated
            ):
                raise ValueError(
                    f"selected restart {basin_id} {parameter_id} differs from validation_hydrographs.csv"
                )
            compared_series += 1
            compared_rows += len(selected)
    return {
        "compared_selected_series": compared_series,
        "compared_selected_daily_rows": compared_rows,
        "wide_long_exact_match": True,
    }


def _validate_metric_identity_binding(
    table: pd.DataFrame, vectors: pd.DataFrame, label: str
) -> pd.DataFrame:
    table = _normalize_identity_table(table, label)
    vector_metadata = vectors.loc[:, (*IDENTITY_COLUMNS, "selected")].drop_duplicates()
    table_metadata = table.loc[:, (*IDENTITY_COLUMNS, "selected")].drop_duplicates()
    keys = list(IDENTITY_WITHOUT_FINGERPRINT)
    if table_metadata.duplicated(keys).any():
        raise ValueError(f"{label} contains conflicting restart identity metadata")
    merged = table_metadata.merge(
        vector_metadata,
        on=keys,
        how="outer",
        suffixes=("_metric", "_vector"),
        indicator=True,
        validate="one_to_one",
    )
    if not (merged["_merge"] == "both").all():
        raise ValueError(f"{label} restart identities differ from restart parameter vectors")
    if not (
        (merged["parameter_sha256_metric"] == merged["parameter_sha256_vector"])
        & (merged["selected_metric"] == merged["selected_vector"])
    ).all():
        raise ValueError(f"{label} restart identity metadata differ from restart parameter vectors")
    return table


def _recompute_initial_state_passes(table: pd.DataFrame) -> pd.DataFrame:
    label = "initial_state_convergence_metrics.csv"
    required_numeric = (
        "analytical_retained_fraction",
        "replayed_retained_fraction",
        "retained_fraction_max",
        "distance",
        "maximum_distance",
    )
    values = {column: _strict_numeric_column(table, column, label) for column in required_numeric}
    if (values["retained_fraction_max"] <= 0.0).any() or (
        values["maximum_distance"] < 0.0
    ).any():
        raise ValueError(f"{label} contains invalid thresholds")
    recorded_analytical = _strict_boolean_column(
        table, "analytical_retained_fraction_pass", label
    ).to_numpy()
    recorded_replayed = _strict_boolean_column(
        table, "replayed_retained_fraction_pass", label
    ).to_numpy()
    retained_match = _strict_boolean_column(
        table, "retained_fraction_matches_analytical", label
    ).to_numpy()
    recorded_distance = _strict_boolean_column(table, "distance_pass", label).to_numpy()
    recorded_overall = _strict_boolean_column(
        table, "initial_state_convergence_passes", label
    ).to_numpy()
    analytical = values["analytical_retained_fraction"] <= values["retained_fraction_max"]
    replayed = values["replayed_retained_fraction"] <= values["retained_fraction_max"]
    distance = values["distance"] <= values["maximum_distance"]
    if not (
        np.array_equal(analytical, recorded_analytical)
        and np.array_equal(replayed, recorded_replayed)
        and np.array_equal(distance, recorded_distance)
    ):
        raise ValueError(f"{label} component Boolean differs from its numeric values")
    recomputed_row = analytical & replayed & retained_match & distance
    working = table.copy()
    working["_recomputed_row_pass"] = recomputed_row
    working["_recorded_overall"] = recorded_overall
    rows = []
    for identity, group in working.groupby(list(IDENTITY_COLUMNS), sort=False):
        if set(group["day_set"].astype(str)) != set(PARAMETER_IDS) or len(group) != len(
            PARAMETER_IDS
        ):
            raise ValueError(f"{label} must contain exactly three day sets per restart")
        recomputed = bool(group["_recomputed_row_pass"].all())
        recorded = set(bool(value) for value in group["_recorded_overall"])
        if recorded != {recomputed}:
            raise ValueError(f"{label} aggregate Boolean differs from component rows")
        row = dict(zip(IDENTITY_COLUMNS, identity))
        row["initial_state_convergence_pass"] = recomputed
        rows.append(row)
    return pd.DataFrame(rows)


def _recompute_response_passes(
    table: pd.DataFrame, complete_water_years: Sequence[int]
) -> pd.DataFrame:
    label = "hydrograph_response_metrics.csv"
    ratio_specs = (
        ("variability_ratio", "variability_ratio_min", "variability_ratio_max", "variability_ratio_pass"),
        ("mean_ratio", "mean_ratio_min", "mean_ratio_max", "mean_ratio_pass"),
        (
            "total_variation_ratio",
            "total_variation_ratio_min",
            "total_variation_ratio_max",
            "total_variation_ratio_pass",
        ),
    )
    component_passes = []
    for value_name, minimum_name, maximum_name, pass_name in ratio_specs:
        values = _strict_numeric_column(table, value_name, label)
        minimum = _strict_numeric_column(table, minimum_name, label)
        maximum = _strict_numeric_column(table, maximum_name, label)
        if np.any(minimum > maximum):
            raise ValueError(f"{label} contains reversed ratio thresholds")
        recomputed = (values >= minimum) & (values <= maximum)
        recorded = _strict_boolean_column(table, pass_name, label).to_numpy()
        if not np.array_equal(recomputed, recorded):
            raise ValueError(f"{label} {pass_name} differs from its numeric values")
        component_passes.append(recomputed)
    recomputed_row = np.logical_and.reduce(component_passes)
    recorded_row = _strict_boolean_column(table, "passes", label).to_numpy()
    if not np.array_equal(recomputed_row, recorded_row):
        raise ValueError(f"{label} passes differs from its three component ratios")
    years = _strict_numeric_column(table, "water_year", label)
    if not np.equal(years, np.floor(years)).all():
        raise ValueError(f"{label} water_year must contain integers")
    working = table.copy()
    working["water_year"] = years.astype(np.int64)
    working["_recomputed_row_pass"] = recomputed_row
    expected_years = set(int(value) for value in complete_water_years)
    rows = []
    for identity, group in working.groupby(list(IDENTITY_COLUMNS), sort=False):
        if set(group["water_year"]) != expected_years or len(group) != len(expected_years):
            raise ValueError(f"{label} must contain every complete validation water year once")
        row = dict(zip(IDENTITY_COLUMNS, identity))
        row["hydrograph_response_pass"] = bool(group["_recomputed_row_pass"].all())
        rows.append(row)
    return pd.DataFrame(rows)


def _diagnostic_recomputation(
    vectors: pd.DataFrame,
    initial_metrics: pd.DataFrame,
    response_metrics: pd.DataFrame,
    complete_water_years: Sequence[int],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    initial_metrics = _validate_metric_identity_binding(
        initial_metrics, vectors, "initial_state_convergence_metrics.csv"
    )
    response_metrics = _validate_metric_identity_binding(
        response_metrics, vectors, "hydrograph_response_metrics.csv"
    )
    initial = _recompute_initial_state_passes(initial_metrics)
    response = _recompute_response_passes(response_metrics, complete_water_years)
    selected = vectors[vectors["selected"]].loc[:, IDENTITY_COLUMNS]
    combined = selected.merge(initial, on=list(IDENTITY_COLUMNS), validate="one_to_one")
    combined = combined.merge(response, on=list(IDENTITY_COLUMNS), validate="one_to_one")
    total = len(combined)
    counts = {
        "selected_initial_state_convergence": {
            "passed": int(combined["initial_state_convergence_pass"].sum()),
            "total": total,
        },
        "selected_hydrograph_response": {
            "passed": int(combined["hydrograph_response_pass"].sum()),
            "total": total,
        },
    }
    records = []
    for row in combined.itertuples(index=False):
        records.append({
            "basin_id": str(row.basin_id),
            "parameter_id": str(row.parameter_id),
            "restart_index": int(row.restart_index),
            "seed": int(row.seed),
            "parameter_sha256": str(row.parameter_sha256),
            "initial_state_convergence_pass": bool(row.initial_state_convergence_pass),
            "hydrograph_response_pass": bool(row.hydrograph_response_pass),
        })
    return counts, records


def _validated_summary(summary: Mapping[str, Any]) -> tuple[str, ...]:
    if summary.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("verified result is not the exact fourth-version experiment")
    if summary.get("classification") != "development_screen":
        raise ValueError("verified result is not an exposed development screen")
    if summary.get("technical_status") != "completed":
        raise ValueError("verified result package is not technically complete")
    basin_ids = summary.get("basin_ids")
    if not isinstance(basin_ids, list) or not basin_ids:
        raise ValueError("verified result summary lacks basin identities")
    normalized = tuple(str(value).zfill(8) for value in basin_ids)
    if len(set(normalized)) != len(normalized):
        raise ValueError("verified result summary contains duplicate basin identities")
    return normalized


def _read_plot_inputs(
    result_directory: Path, verified_summary: Mapping[str, Any]
) -> dict[str, Any]:
    basin_ids = _validated_summary(verified_summary)
    config = _load_json(result_directory / "config_snapshot.json")
    if config.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("config snapshot is not the exact fourth-version experiment")
    try:
        restart_seeds = tuple(config["optimizer"]["restart_seeds"])
        validation = config["periods"]["validation"]
        response_contract = config["initialization_compatibility"][
            "validation_hydrograph_response"
        ]
        complete_water_years = tuple(response_contract["complete_water_years"])
        log_offset = float(config["flow_log_offset_mm_day"])
    except (KeyError, TypeError, ValueError) as error:
        raise ValueError("config snapshot lacks the frozen plotting inputs") from error
    if (
        len(restart_seeds) != 3
        or any(isinstance(seed, bool) or not isinstance(seed, int) for seed in restart_seeds)
        or not np.isfinite(log_offset)
        or log_offset <= 0.0
    ):
        raise ValueError("config snapshot contains invalid restart seeds or log offset")
    try:
        expected_dates = pd.date_range(validation["start"], validation["end"], freq="D")
    except (KeyError, TypeError, ValueError) as error:
        raise ValueError("config snapshot contains an invalid validation period") from error
    if expected_dates.empty:
        raise ValueError("config snapshot validation period must be nonempty")

    wide = pd.read_csv(result_directory / "validation_hydrographs.csv", dtype={"basin_id": str})
    long_table = pd.read_csv(
        result_directory / "validation_restart_hydrographs.csv",
        dtype={"basin_id": str, "selected": str, "parameter_sha256": str},
    )
    vectors = pd.read_csv(
        result_directory / "restart_parameter_vectors.csv",
        dtype={"basin_id": str, "selected": str, "parameter_sha256": str},
    )
    initial_metrics = pd.read_csv(
        result_directory / "initial_state_convergence_metrics.csv",
        dtype={"basin_id": str, "selected": str, "parameter_sha256": str},
    )
    response_metrics = pd.read_csv(
        result_directory / "hydrograph_response_metrics.csv",
        dtype={"basin_id": str, "selected": str, "parameter_sha256": str},
    )
    vectors, long_table = _validate_restart_identities(
        vectors, long_table, basin_ids, restart_seeds
    )
    daily_audit = _validate_daily_hydrographs(wide, long_table, basin_ids, expected_dates)
    diagnostic_counts, selected_diagnostics = _diagnostic_recomputation(
        vectors, initial_metrics, response_metrics, complete_water_years
    )
    return {
        "basin_ids": basin_ids,
        "wide": wide,
        "vectors": vectors,
        "restart_seeds": restart_seeds,
        "expected_dates": expected_dates,
        "log_offset": log_offset,
        "daily_audit": daily_audit,
        "diagnostic_counts": diagnostic_counts,
        "selected_diagnostics": selected_diagnostics,
    }


def _paths_are_disjoint(result_directory: Path, output_directory: Path) -> bool:
    return not (
        result_directory == output_directory
        or result_directory in output_directory.parents
        or output_directory in result_directory.parents
    )


def _render_figure(
    wide: pd.DataFrame,
    basin_ids: Sequence[str],
    log_offset: float,
    output_path: Path,
) -> dict[str, Any]:
    figure, axes = plt.subplots(
        len(basin_ids),
        2,
        figsize=(18, 3.45 * len(basin_ids) + 1.4),
        sharex=True,
        squeeze=False,
    )
    for row_index, basin_id in enumerate(basin_ids):
        basin = wide[wide["basin_id"].astype(str).str.zfill(8) == basin_id].copy()
        dates = pd.DatetimeIndex(pd.to_datetime(basin["date"], errors="raise"))
        series = {
            "observed": basin["observed_flow_mm_day"].to_numpy(dtype=float),
            **{
                parameter_id: basin[column].to_numpy(dtype=float)
                for parameter_id, column in PARAMETER_OUTPUT_COLUMNS.items()
            },
        }
        maximum = max(float(np.max(values)) for values in series.values())
        for column_index, axis in enumerate(axes[row_index]):
            logarithmic = column_index == 1
            for series_id in ("all_flow", "low_flow", "high_flow", "observed"):
                values = series[series_id] + log_offset if logarithmic else series[series_id]
                axis.plot(dates, values, zorder=4 if series_id == "observed" else 2, **LINE_STYLES[series_id])
            if logarithmic:
                axis.set_yscale("log")
                axis.set_ylim(log_offset * 0.9, max((maximum + log_offset) * 1.08, log_offset * 10.0))
                axis.set_ylabel(f"Q + {log_offset:g} (mm day$^{{-1}}$)")
            else:
                axis.set_ylim(0.0, max(maximum * 1.08, 1.0))
                axis.set_ylabel("Q (mm day$^{-1}$)")
            locator = mdates.AutoDateLocator(minticks=4, maxticks=8)
            axis.xaxis.set_major_locator(locator)
            axis.xaxis.set_major_formatter(mdates.ConciseDateFormatter(locator))
            axis.grid(True, color="#D9D9D9", linewidth=0.55, alpha=0.75)
            axis.set_title(
                f"Basin {basin_id} — {'logarithmic Q + offset' if logarithmic else 'linear Q'}",
                loc="left",
                fontsize=10.5,
                fontweight="bold",
            )
    handles, labels = axes[0, 0].get_legend_handles_labels()
    order = [labels.index(LINE_STYLES[key]["label"]) for key in ("observed", *PARAMETER_IDS)]
    figure.legend(
        [handles[index] for index in order],
        [labels[index] for index in order],
        loc="upper center",
        ncol=4,
        frameon=False,
        bbox_to_anchor=(0.5, 0.955),
    )
    figure.suptitle(
        "Fourth-version fixed-parameter validation hydrographs",
        fontsize=14,
        fontweight="bold",
        y=0.995,
    )
    figure.text(
        0.5,
        0.018,
        (
            "Exposed-basin development diagnostic only. Fit-selected fixed parameter vectors are replayed "
            "continuously over validation; this post-seal figure does not select or promote parameters."
        ),
        ha="center",
        fontsize=9,
        color="#333333",
    )
    figure.tight_layout(rect=(0.025, 0.055, 0.995, 0.925))
    figure.savefig(
        output_path,
        dpi=180,
        bbox_inches="tight",
        metadata={
            "Title": "Fourth-version selected validation hydrographs",
            "Description": "Post-seal exposed-basin development diagnostic; no parameter selection.",
        },
    )
    plt.close(figure)
    return {
        "filename": FIGURE_FILENAME,
        "sha256": _sha256(output_path),
        "row_count": len(basin_ids),
        "column_count": 2,
        "scales": ["linear_q", f"log_q_plus_{log_offset:g}_mm_day"],
        "daily_values_plotted_without_smoothing_or_resampling": True,
        "dpi": 180,
    }


def create_validation_hydrograph_figure(
    result_directory: str | Path, output_directory: str | Path
) -> dict[str, Any]:
    """Verify one sealed fourth-version package and write external plot artifacts."""

    result = Path(result_directory).resolve()
    output = Path(output_directory).resolve()

    verified_summary = verify_result_directory(result)
    basin_ids = _validated_summary(verified_summary)
    if not _paths_are_disjoint(result, output):
        raise ValueError("result and visualization output directories must be disjoint")
    figure_path = output / FIGURE_FILENAME
    manifest_path = output / MANIFEST_FILENAME
    if figure_path.exists() or manifest_path.exists():
        raise FileExistsError("visualization output artifacts already exist")

    package_hashes_before = _sealed_package_hashes(result)
    package_digest_before = _sealed_package_digest(package_hashes_before)
    missing_inputs = sorted(name for name in INPUT_ARTIFACTS if name not in package_hashes_before)
    if missing_inputs:
        raise ValueError(f"sealed package lacks plotting audit artifacts: {missing_inputs}")
    inputs = _read_plot_inputs(result, verified_summary)
    if tuple(inputs["basin_ids"]) != basin_ids:
        raise ValueError("verified basin identities changed while reading plotting inputs")

    output.mkdir(parents=True, exist_ok=True)
    figure_record = _render_figure(
        inputs["wide"], inputs["basin_ids"], inputs["log_offset"], figure_path
    )

    verified_summary_after = verify_result_directory(result)
    if _validated_summary(verified_summary_after) != basin_ids:
        raise ValueError("verified basin identities changed after plotting")
    package_hashes_after = _sealed_package_hashes(result)
    package_digest_after = _sealed_package_digest(package_hashes_after)
    if package_hashes_before != package_hashes_after:
        differing = sorted(
            path
            for path in set(package_hashes_before) | set(package_hashes_after)
            if package_hashes_before.get(path) != package_hashes_after.get(path)
        )
        raise ValueError(f"sealed result package changed while plotting: {differing}")

    vectors = inputs["vectors"]
    selected_vectors = vectors[vectors["selected"]]
    manifest = {
        "schema_version": 1,
        "artifact_type": "post_seal_selected_validation_hydrograph_visualization",
        "experiment_id": EXPERIMENT_ID,
        "classification": "exposed_basin_development_diagnostic",
        "source_result_directory": result.as_posix(),
        "package_hash_algorithm": "sha256(canonical_json(relative_path_to_sha256))",
        "sealed_package_file_count": len(package_hashes_before),
        "sealed_package_sha256_before": package_digest_before,
        "sealed_package_sha256_after": package_digest_after,
        "sealed_package_unchanged": package_digest_before == package_digest_after,
        "input_artifacts_sha256": {
            name: package_hashes_before[name] for name in INPUT_ARTIFACTS
        },
        "verification": {
            "function": (
                "camels_switch_confirmation.run_real_regime_parameter_calibration."
                "verify_result_directory"
            ),
            "passed_before_reading_plot_inputs": True,
            "passed_after_writing_figure": True,
        },
        "identity_audit": {
            "restart_identity_count": len(vectors),
            "selected_identity_count": len(selected_vectors),
            "expected_restart_identity_count": len(inputs["basin_ids"])
            * len(PARAMETER_IDS)
            * len(inputs["restart_seeds"]),
            "expected_selected_identity_count": len(inputs["basin_ids"]) * len(PARAMETER_IDS),
            "selected_identities": _identity_records(selected_vectors),
        },
        "daily_hydrograph_audit": inputs["daily_audit"],
        "diagnostic_recomputation": inputs["diagnostic_counts"],
        "selected_identity_diagnostics": inputs["selected_diagnostics"],
        "validation_period": {
            "start": str(inputs["expected_dates"][0].date()),
            "end": str(inputs["expected_dates"][-1].date()),
            "days_per_basin": len(inputs["expected_dates"]),
            "basin_count": len(inputs["basin_ids"]),
        },
        "log_offset_mm_day": inputs["log_offset"],
        "selection_policy": {
            "uses_fit_selected_identifiers_from_sealed_tables_only": True,
            "validation_does_not_select_or_promote_restart": True,
            "unselected_restarts_plotted": False,
        },
        "figure": figure_record,
        "software": {
            "python": platform.python_version(),
            "matplotlib": matplotlib.__version__,
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "platform": platform.platform(),
            "executable": sys.executable,
        },
    }
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return manifest


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Plot audited fourth-version selected validation hydrographs outside the sealed package."
    )
    parser.add_argument("--result-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = _parse_args()
    manifest = create_validation_hydrograph_figure(args.result_dir, args.output_dir)
    print(Path(args.output_dir).resolve() / manifest["figure"]["filename"])


if __name__ == "__main__":
    main()
