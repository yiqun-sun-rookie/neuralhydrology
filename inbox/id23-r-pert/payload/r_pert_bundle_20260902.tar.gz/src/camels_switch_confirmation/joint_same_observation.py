"""Shared contracts for the registered same-observation joint experiment.

The historical JOINT-X1 runner remains frozen.  This module adds a single
truth-observation source and three estimator knowledge modes without changing
the production interacting multiple-model implementation.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from camels_switch_confirmation.g2_switch_confirmation import (
    N_HYDRO,
    N_STATE,
    RisingRoutedObservation,
    build_state_dependent_lower_groundwater_covariance,
    rising_routed_discharge,
)
from camels_switch_confirmation.joint_param_noise_precheck import (
    NOISE_CANDIDATES,
    N_NOISE,
    N_PARAM,
    cell_index,
    injection_sigma,
)


BASE_CONFIG = Path(
    "src/camels_switch_confirmation/configs/"
    "joint_param_noise_same_observation_base_v01.json"
)
CONTINUOUS_CONFIG = Path(
    "src/camels_switch_confirmation/configs/"
    "joint_param_noise_same_observation_continuous_v01.json"
)
REPLAY_CONFIG = Path(
    "src/camels_switch_confirmation/configs/"
    "joint_param_noise_same_state_replay_v01.json"
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _load_json(path: Path) -> dict:
    with path.open(encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError(f"configuration must be a JSON object: {path}")
    return payload


@dataclass
class RegisteredExperimentConfigs:
    """The three JSON configurations that define the experiment family."""

    base: dict
    continuous: dict
    replay: dict

    def verify_registered_inputs(self, repo_root: Path) -> None:
        root = Path(repo_root).resolve()
        collections = (
            ("input", self.base.get("registered_inputs", {})),
            ("implementation", self.base.get("registered_implementation", {})),
        )
        for kind, records in collections:
            for label, record in records.items():
                registered = Path(record["path"])
                path = registered if registered.is_absolute() else root / registered
                if not path.is_file():
                    raise FileNotFoundError(
                        f"registered {kind} is missing ({label}): {path}"
                    )
                observed = sha256_file(path)
                if observed != record["sha256"]:
                    raise ValueError(
                        f"registered {kind} SHA-256 changed ({label}): "
                        f"{observed} != {record['sha256']}"
                    )


def load_registered_configs(
    repo_root: Path,
    verify_hashes: bool = True,
) -> RegisteredExperimentConfigs:
    """Load registered configs and optionally verify every frozen input hash."""

    root = Path(repo_root).resolve()
    configs = RegisteredExperimentConfigs(
        base=_load_json(root / BASE_CONFIG),
        continuous=_load_json(root / CONTINUOUS_CONFIG),
        replay=_load_json(root / REPLAY_CONFIG),
    )
    if configs.base.get("experiment_family") != "JOINT-X2":
        raise ValueError("base configuration experiment family changed")
    if configs.continuous.get("experiment_id") != "JOINT-X2-CONTINUOUS":
        raise ValueError("continuous experiment identity changed")
    if configs.replay.get("experiment_id") != "JOINT-X2-REPLAY":
        raise ValueError("replay experiment identity changed")
    if verify_hashes:
        configs.verify_registered_inputs(root)
    return configs


@dataclass(frozen=True)
class TruthObservationBundle:
    """One immutable truth, state, forcing, and observation trajectory."""

    rain: np.ndarray
    pet: np.ndarray
    temperature: np.ndarray
    pre_states: np.ndarray
    post_states: np.ndarray
    truth_q: np.ndarray
    observations: np.ndarray
    observation_errors: np.ndarray
    truth_param_indices: np.ndarray
    truth_noise_indices: np.ndarray
    truth_cell_indices: np.ndarray
    truth_parfc: np.ndarray
    sequence: np.ndarray
    stage_days: int
    clip_count: int


def generate_truth_observation_bundle(
    sequence,
    members,
    rain,
    pet,
    temperature,
    init_hydro,
    truth_rng,
    observation_rng,
    observation_sigma,
    bounds,
    stage_days,
) -> TruthObservationBundle:
    """Generate one trajectory with the frozen JOINT-X1 update order."""

    from hbv_joint_uncertainty.hbv_adapter import advance_state

    rain_values = np.asarray(rain, dtype=np.float64)
    pet_values = np.asarray(pet, dtype=np.float64)
    temperature_values = np.asarray(temperature, dtype=np.float64)
    initial = np.asarray(init_hydro, dtype=np.float64)
    if initial.shape != (N_HYDRO,):
        raise ValueError(f"init_hydro must have shape ({N_HYDRO},)")
    if not np.isfinite(observation_sigma) or float(observation_sigma) <= 0.0:
        raise ValueError("observation sigma must be finite and positive")
    n_days = min(
        len(rain_values),
        len(pet_values),
        len(temperature_values),
        len(sequence) * int(stage_days),
    )
    state = np.zeros(N_STATE, dtype=np.float64)
    state[:N_HYDRO] = initial
    pre_states = np.zeros((n_days, N_STATE), dtype=np.float64)
    post_states = np.zeros_like(pre_states)
    truth_q = np.zeros(n_days, dtype=np.float64)
    truth_param = np.zeros(n_days, dtype=np.int64)
    truth_noise = np.zeros(n_days, dtype=np.int64)
    truth_cell = np.zeros(n_days, dtype=np.int64)
    truth_parfc = np.zeros(n_days, dtype=np.float64)
    clips = 0
    day = 0
    for param_index, noise_index in sequence:
        params = members[int(param_index)]
        sigma = injection_sigma(NOISE_CANDIDATES[int(noise_index)])
        for _ in range(int(stage_days)):
            if day >= n_days:
                break
            pre_states[day] = state
            truth_param[day] = int(param_index)
            truth_noise[day] = int(noise_index)
            truth_cell[day] = cell_index(int(param_index), int(noise_index))
            truth_parfc[day] = float(params["parFC"])
            state = advance_state(
                state,
                rain_values[day],
                pet_values[day],
                temperature_values[day],
                params,
                bounds=bounds,
            )
            noisy = state[4] * np.exp(truth_rng.normal(-0.5 * sigma**2, sigma))
            if not np.isfinite(noisy) or noisy < 0.0:
                clips += 1
                noisy = max(float(noisy), 0.0) if np.isfinite(noisy) else 0.0
            state[4] = noisy
            post_states[day] = state
            truth_q[day] = rising_routed_discharge(state, params["lag_time"])
            day += 1
    observation_errors = observation_rng.normal(
        0.0,
        float(observation_sigma),
        size=n_days,
    )
    observations = truth_q + observation_errors
    arrays = (
        rain_values[:n_days],
        pet_values[:n_days],
        temperature_values[:n_days],
        pre_states,
        post_states,
        truth_q,
        observations,
        observation_errors,
        truth_parfc,
    )
    if any(not np.all(np.isfinite(values)) for values in arrays):
        raise ValueError("truth-observation bundle contains non-finite values")
    return TruthObservationBundle(
        rain=rain_values[:n_days].copy(),
        pet=pet_values[:n_days].copy(),
        temperature=temperature_values[:n_days].copy(),
        pre_states=pre_states,
        post_states=post_states,
        truth_q=truth_q,
        observations=observations,
        observation_errors=observation_errors,
        truth_param_indices=truth_param,
        truth_noise_indices=truth_noise,
        truth_cell_indices=truth_cell,
        truth_parfc=truth_parfc,
        sequence=np.asarray(sequence, dtype=np.int64),
        stage_days=int(stage_days),
        clip_count=int(clips),
    )


def _mixture_moments(states, covariances, probabilities) -> tuple[np.ndarray, np.ndarray]:
    state_values = np.asarray(states, dtype=np.float64)
    covariance_values = np.asarray(covariances, dtype=np.float64)
    weights = np.asarray(probabilities, dtype=np.float64)
    weights = weights / weights.sum()
    mean = np.sum(weights[:, None] * state_values, axis=0)
    covariance = np.zeros_like(covariance_values[0])
    for weight, state, candidate_covariance in zip(
        weights, state_values, covariance_values
    ):
        deviation = state - mean
        covariance += weight * (candidate_covariance + np.outer(deviation, deviation))
    return mean, 0.5 * (covariance + covariance.T)


@dataclass
class EstimatorRuntime:
    """One estimator plus the candidate coordinates needed to update it."""

    knowledge_mode: str
    interaction_mode: str
    estimator: Any
    transitions: list
    candidate_pairs: tuple[tuple[int, int], ...]
    members: tuple[dict, ...]
    bounds: dict
    sigma_obs: float
    current_known_param: int | None
    current_known_noise: int | None

    def set_forcing(self, rain: float, pet: float, temperature: float) -> None:
        for transition in self.transitions:
            transition.set_forcing(rain, pet, temperature)

    def assign_process_covariances(
        self,
        reference_slz: float,
        true_noise_index: int,
    ) -> None:
        level = max(float(reference_slz), 0.0)
        for candidate, (_, candidate_noise) in zip(
            self.estimator.filters,
            self.candidate_pairs,
        ):
            noise_index = (
                int(true_noise_index)
                if self.knowledge_mode == "noise_known"
                else int(candidate_noise)
            )
            candidate.process_covariance = (
                build_state_dependent_lower_groundwater_covariance(
                    level,
                    NOISE_CANDIDATES[noise_index],
                )
            )

    def apply_known_axes(
        self,
        true_param_index: int,
        true_noise_index: int,
    ) -> None:
        if self.knowledge_mode == "param_known":
            self._switch_known_parameter(int(true_param_index))
        elif self.knowledge_mode == "noise_known":
            self.current_known_noise = int(true_noise_index)
            self.candidate_pairs = tuple(
                (param_index, int(true_noise_index))
                for param_index in range(N_PARAM)
            )

    def _switch_known_parameter(self, new_param_index: int) -> None:
        if self.current_known_param == new_param_index:
            return
        from hbv_joint_uncertainty.hbv_state_mapping import remap_parfc_moments

        if self.current_known_param is None:
            raise ValueError("known parameter runtime lacks its current parameter")
        old_param_index = int(self.current_known_param)
        states, covariances = [], []
        for candidate in self.estimator.filters:
            state, covariance = remap_parfc_moments(
                candidate.state,
                candidate.covariance,
                self.members[old_param_index],
                self.members[new_param_index],
                candidate.sigma_generator,
            )
            states.append(state)
            covariances.append(covariance)
        probabilities = self.estimator.probabilities.copy()
        rebuilt = _build_estimator_from_candidate_moments(
            knowledge_mode="param_known",
            interaction_mode=self.interaction_mode,
            members=self.members,
            candidate_pairs=tuple(
                (new_param_index, noise_index) for noise_index in range(N_NOISE)
            ),
            states=np.asarray(states),
            covariances=np.asarray(covariances),
            initial_probabilities=probabilities,
            sigma_obs=self.sigma_obs,
            bounds=self.bounds,
        )
        self.estimator = rebuilt.estimator
        self.transitions = rebuilt.transitions
        self.candidate_pairs = rebuilt.candidate_pairs
        self.current_known_param = new_param_index


def _construct_estimator(
    filters,
    transition_matrix,
    initial_probabilities,
    interaction_mode,
    pairwise_moment_transform,
):
    from hbv_joint_uncertainty.imm import (
        InteractingMultipleModel,
        PairwisePathMultipleModel,
    )

    if interaction_mode == "pairwise_path_postcollapse":
        estimator = PairwisePathMultipleModel(
            filters=filters,
            transition_matrix=transition_matrix,
            initial_probabilities=initial_probabilities,
            pairwise_moment_transform=pairwise_moment_transform,
            model_evidence_scorer=None,
        )
        estimator.recursive_probability_representation = "ordinary_float"
    elif interaction_mode == "full":
        estimator = InteractingMultipleModel(
            filters=filters,
            transition_matrix=transition_matrix,
            initial_probabilities=initial_probabilities,
            parameter_groups=list(range(len(filters))),
            pairwise_moment_transform=pairwise_moment_transform,
            model_evidence_scorer=None,
        )
    else:
        raise ValueError(f"unknown interaction mode: {interaction_mode}")
    estimator.interaction_mode = interaction_mode
    estimator.parameter_state_mapping = "conservative_parfc"
    mean, covariance = _mixture_moments(
        [candidate.state for candidate in filters],
        [candidate.covariance for candidate in filters],
        initial_probabilities,
    )
    estimator.state = mean
    estimator.covariance = covariance
    return estimator


def _build_estimator_from_candidate_moments(
    knowledge_mode,
    interaction_mode,
    members,
    candidate_pairs,
    states,
    covariances,
    initial_probabilities,
    sigma_obs,
    bounds,
) -> EstimatorRuntime:
    from hbv_joint_uncertainty.hbv_state_mapping import (
        project_hbv_state_conserving_soil_excess,
        remap_parfc_moments,
    )
    from hbv_joint_uncertainty.preflight import (
        ForcingTransition,
        build_transition_matrix,
    )
    from hbv_joint_uncertainty.sigma_filter import ModifiedUnscentedFilter

    filters, transitions = [], []
    common_r = np.array([[float(sigma_obs) ** 2]], dtype=np.float64)
    reference_level = max(float(np.asarray(states)[0, 4]), 0.0)
    for position, (param_index, noise_index) in enumerate(candidate_pairs):
        params = members[param_index]
        projector = (
            lambda values, p=params: project_hbv_state_conserving_soil_excess(
                values, p
            )
        )
        transition = ForcingTransition(
            params,
            parameter_bounds=bounds,
            state_projector=projector,
        )
        filters.append(
            ModifiedUnscentedFilter(
                state=np.asarray(states[position], dtype=np.float64),
                covariance=np.asarray(covariances[position], dtype=np.float64),
                transition=transition,
                observation=RisingRoutedObservation(params),
                process_covariance=(
                    build_state_dependent_lower_groundwater_covariance(
                        reference_level,
                        NOISE_CANDIDATES[noise_index],
                    )
                ),
                observation_covariance=common_r.copy(),
                state_projector=projector,
                alpha=0.6874,
                beta=2.0,
                kappa=-2.0,
            )
        )
        transitions.append(transition)

    def pairwise_transform(source, destination, mean, covariance):
        source_param = candidate_pairs[source][0]
        destination_param = candidate_pairs[destination][0]
        return remap_parfc_moments(
            mean,
            covariance,
            members[source_param],
            members[destination_param],
            filters[source].sigma_generator,
        )

    one_axis = build_transition_matrix(3, 0.98)
    transition_matrix = (
        np.kron(one_axis, one_axis)
        if knowledge_mode == "joint_unknown"
        else one_axis
    )
    estimator = _construct_estimator(
        filters,
        transition_matrix,
        initial_probabilities,
        interaction_mode,
        pairwise_transform,
    )
    known_param = candidate_pairs[0][0] if knowledge_mode == "param_known" else None
    known_noise = candidate_pairs[0][1] if knowledge_mode == "noise_known" else None
    return EstimatorRuntime(
        knowledge_mode=knowledge_mode,
        interaction_mode=interaction_mode,
        estimator=estimator,
        transitions=transitions,
        candidate_pairs=tuple(candidate_pairs),
        members=tuple(members),
        bounds=bounds,
        sigma_obs=float(sigma_obs),
        current_known_param=known_param,
        current_known_noise=known_noise,
    )


def build_estimator_runtime(
    knowledge_mode,
    interaction_mode,
    members,
    initial_state,
    initial_covariance,
    initial_probabilities,
    sigma_obs,
    bounds,
    true_param_index,
    true_noise_index,
) -> EstimatorRuntime:
    """Build one of the three registered estimator knowledge modes."""

    from hbv_joint_uncertainty.hbv_state_mapping import remap_parfc_moments
    from hbv_joint_uncertainty.sigma_filter import ScaledSigmaPoints

    if knowledge_mode == "joint_unknown":
        candidate_pairs = tuple(
            (param_index, noise_index)
            for param_index in range(N_PARAM)
            for noise_index in range(N_NOISE)
        )
    elif knowledge_mode == "param_known":
        candidate_pairs = tuple(
            (int(true_param_index), noise_index) for noise_index in range(N_NOISE)
        )
    elif knowledge_mode == "noise_known":
        candidate_pairs = tuple(
            (param_index, int(true_noise_index)) for param_index in range(N_PARAM)
        )
    else:
        raise ValueError(f"unknown knowledge mode: {knowledge_mode}")

    state = np.asarray(initial_state, dtype=np.float64)
    covariance = np.asarray(initial_covariance, dtype=np.float64)
    if state.shape != (N_STATE,):
        raise ValueError(f"initial state must have shape ({N_STATE},)")
    if covariance.shape != (N_STATE, N_STATE):
        raise ValueError(
            f"initial covariance must have shape ({N_STATE}, {N_STATE})"
        )
    sigma_generator = ScaledSigmaPoints(
        N_STATE,
        alpha=0.6874,
        beta=2.0,
        kappa=-2.0,
    )
    states, covariances = [], []
    for param_index, _ in candidate_pairs:
        mapped_state, mapped_covariance = remap_parfc_moments(
            state,
            covariance,
            members[int(true_param_index)],
            members[param_index],
            sigma_generator,
        )
        states.append(mapped_state)
        covariances.append(mapped_covariance)
    candidate_count = len(candidate_pairs)
    probabilities = (
        np.full(candidate_count, 1.0 / candidate_count, dtype=np.float64)
        if initial_probabilities is None
        else np.asarray(initial_probabilities, dtype=np.float64)
    )
    if probabilities.shape != (candidate_count,):
        raise ValueError(
            f"initial probabilities must have shape ({candidate_count},)"
        )
    return _build_estimator_from_candidate_moments(
        knowledge_mode=knowledge_mode,
        interaction_mode=interaction_mode,
        members=tuple(members),
        candidate_pairs=candidate_pairs,
        states=np.asarray(states),
        covariances=np.asarray(covariances),
        initial_probabilities=probabilities,
        sigma_obs=sigma_obs,
        bounds=bounds,
    )
