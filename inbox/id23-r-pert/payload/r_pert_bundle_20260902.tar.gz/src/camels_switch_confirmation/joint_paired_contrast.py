"""JOINT-X1 analysis: paired switch-vs-null contrast on the joint 3x3 posterior.

Preregistration: docs/plans/2026-08-20-joint-param-noise-switch-prereg-v01.md
(frozen before any filter run; hash below and in the summary).

The noise line proved the inherited binary event rule unusable at this
signal-to-noise ratio (88/88 false fires in the null control), so the criterion
here is the registered paired uplift: the mean posterior of the true level on
its own stages, minus the mean posterior of the SAME level on the SAME calendar
days of the null control.  Two marginals are read out --

    p_param[t, i] = sum_j p[t, 3i+j]        p_noise[t, j] = sum_i p[t, 3i+j]

-- plus the joint cell itself.  Stage 0 is excluded by preregistration: the two
scenarios are bit-identical there, so its uplift is identically zero.

The two placebos are the cross-axis contamination test.  On stage 3 the truth
parameter equals the null's while the noise does not, so a moving parameter
readout there means the parameter marginal is being dragged by the noise axis;
stages 1 and 5 are the mirror image.

Read-only over existing npz artifacts; runs no filter.

Usage:
    python -X utf8 -m camels_switch_confirmation.joint_paired_contrast
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from camels_switch_confirmation.joint_param_noise_precheck import (
    N_NOISE,
    N_PARAM,
    SEQUENCE,
    STAGE_DAYS,
    cell_index,
)
from camels_switch_confirmation.noise_switch_paired_contrast import rank_auc
from camels_switch_confirmation.run_joint_param_noise_switch import (
    ARM_MODES,
    OUTPUT_ROOT,
)

PREREGISTRATION = "docs/plans/2026-08-20-joint-param-noise-switch-prereg-v01.md"
PREREGISTRATION_SHA256 = (
    "257faf765a09a5c8cf16a90498e6ab23f03c533e4f654970829a2fe473dec83f")

# registered thresholds -- identical to the confirmed noise line (v02)
MEDIAN_UPLIFT_MIN = 0.10
POSITIVE_FRACTION_MIN = 0.90
PLACEBO_ABS_MEDIAN_MAX = 0.05
TESTED_LEVELS = (1, 2)
PLACEBO_LEVEL = 0
EXCLUDED_STAGE = 0          # switch and null are bit-identical there


def axis_truth_by_stage(axis: str, sequence=SEQUENCE) -> tuple:
    """Truth index of one axis for each stage position."""
    position = {"param": 0, "noise": 1}[axis]
    return tuple(cell[position] for cell in sequence)


def stage_days_for_axis_level(axis, level, sequence=SEQUENCE,
                              stage_days=STAGE_DAYS,
                              excluded_stage=EXCLUDED_STAGE):
    """Calendar days where `axis` truth equals `level`, excluding stage 0."""
    truths = axis_truth_by_stage(axis, sequence)
    blocks = [np.arange(position * stage_days, (position + 1) * stage_days)
              for position, truth in enumerate(truths)
              if truth == level and position != excluded_stage]
    if not blocks:
        raise ValueError(f"{axis} level {level} never active outside stage 0")
    return np.concatenate(blocks)


def marginals(probabilities: np.ndarray) -> tuple:
    """(parameter marginal, noise marginal) from the flat 9-cell posterior."""
    grid = np.asarray(probabilities, dtype=np.float64).reshape(
        -1, N_PARAM, N_NOISE)
    return grid.sum(axis=2), grid.sum(axis=1)


def paired_uplift(switch_marginal, null_marginal, days, level):
    """Mean posterior of `level` on `days`, minus the null on the same days."""
    n_days = min(switch_marginal.shape[0], null_marginal.shape[0])
    days = days[days < n_days]
    switch_mean = float(switch_marginal[days, level].mean())
    null_mean = float(null_marginal[days, level].mean())
    return switch_mean - null_mean, switch_mean, null_mean


def confusion_breakdown(probabilities, truth_param, truth_noise, days):
    """How wrong argmax days are wrong: noise axis only, parameter only, or both."""
    grid_argmax = np.asarray(probabilities)[days].argmax(axis=1)
    predicted_param, predicted_noise = np.divmod(grid_argmax, N_NOISE)
    param_wrong = predicted_param != np.asarray(truth_param)[days]
    noise_wrong = predicted_noise != np.asarray(truth_noise)[days]
    total = max(len(days), 1)
    return {
        "cell_correct_fraction": float((~param_wrong & ~noise_wrong).mean()),
        "noise_only_wrong_fraction": float((~param_wrong & noise_wrong).sum() / total),
        "param_only_wrong_fraction": float((param_wrong & ~noise_wrong).sum() / total),
        "both_wrong_fraction": float((param_wrong & noise_wrong).sum() / total),
    }


def _load(path):
    with np.load(path, allow_pickle=False) as archive:
        return {
            "probabilities": archive["probabilities"],
            "truth_param": archive["truth_param_indices"],
            "truth_noise": archive["truth_noise_indices"],
            "truth_cell": archive["truth_cell_indices"],
            "truth_clip_count": int(archive["truth_clip_count"]),
        }


def collect(root: Path, arms) -> pd.DataFrame:
    """One row per (basin, seed, arm) with every registered per-task quantity."""
    rows = []
    for arm in arms:
        switch_dir = root / "arms" / arm / "switch" / "probs"
        null_dir = root / "arms" / arm / "null" / "probs"
        for switch_path in sorted(switch_dir.glob("*.npz")):
            null_path = null_dir / switch_path.name
            if not null_path.exists():
                continue
            switch = _load(switch_path)
            null = _load(null_path)
            switch_param, switch_noise = marginals(switch["probabilities"])
            null_param, null_noise = marginals(null["probabilities"])
            basin, seed_tag = switch_path.stem.split("_s")
            record = {
                "basin_id": basin, "seed": int(seed_tag), "arm": arm,
                "n_days": int(switch["probabilities"].shape[0]),
                "truth_clip_count_switch": switch["truth_clip_count"],
                "truth_clip_count_null": null["truth_clip_count"],
            }
            for axis, switch_marginal, null_marginal in (
                    ("param", switch_param, null_param),
                    ("noise", switch_noise, null_noise)):
                for level in (*TESTED_LEVELS, PLACEBO_LEVEL):
                    days = stage_days_for_axis_level(axis, level)
                    uplift, switch_mean, null_mean = paired_uplift(
                        switch_marginal, null_marginal, days, level)
                    tag = "placebo" if level == PLACEBO_LEVEL else f"level{level}"
                    record[f"{axis}_{tag}_uplift"] = uplift
                    record[f"{axis}_{tag}_switch_mean"] = switch_mean
                    record[f"{axis}_{tag}_null_mean"] = null_mean
            scored_days = np.arange(STAGE_DAYS * (EXCLUDED_STAGE + 1),
                                    record["n_days"])
            true_cell_probability = switch["probabilities"][
                scored_days, switch["truth_cell"][scored_days]]
            null_same_cell = null["probabilities"][
                scored_days, switch["truth_cell"][scored_days]]
            record["cell_uplift"] = float(true_cell_probability.mean()
                                          - null_same_cell.mean())
            record["cell_zero_probability_days"] = int(
                (true_cell_probability == 0.0).sum())
            record.update(confusion_breakdown(
                switch["probabilities"], switch["truth_param"],
                switch["truth_noise"], scored_days))
            rows.append(record)
    return pd.DataFrame(rows)


def judge(frame: pd.DataFrame, arms) -> dict:
    """Apply the three frozen gates per arm and axis."""
    verdict = {
        "preregistration": PREREGISTRATION,
        "preregistration_sha256": PREREGISTRATION_SHA256,
        "thresholds": {
            "median_uplift_min": MEDIAN_UPLIFT_MIN,
            "positive_fraction_min": POSITIVE_FRACTION_MIN,
            "placebo_abs_median_max": PLACEBO_ABS_MEDIAN_MAX,
        },
        "excluded_stage": EXCLUDED_STAGE,
        "arms": {},
    }
    for arm in arms:
        subset = frame[frame["arm"] == arm]
        if subset.empty:
            continue
        arm_result = {"n_tasks": int(len(subset)), "axes": {}}
        for axis in ("param", "noise"):
            placebo = subset[f"{axis}_placebo_uplift"]
            placebo_median = float(placebo.median())
            placebo_clean = bool(abs(placebo_median) <= PLACEBO_ABS_MEDIAN_MAX)
            axis_result = {
                "placebo_median": placebo_median,
                "placebo_clean": placebo_clean,
                "levels": {},
            }
            level_passes = []
            for level in TESTED_LEVELS:
                values = subset[f"{axis}_level{level}_uplift"]
                median = float(values.median())
                positive_fraction = float((values > 0).mean())
                passed = bool(median > MEDIAN_UPLIFT_MIN
                              and positive_fraction >= POSITIVE_FRACTION_MIN
                              and placebo_clean)
                level_passes.append(passed)
                axis_result["levels"][str(level)] = {
                    "median_uplift": median,
                    "positive_fraction": positive_fraction,
                    "auc_vs_placebo": rank_auc(values.values, placebo.values),
                    "switch_mean_median": float(
                        subset[f"{axis}_level{level}_switch_mean"].median()),
                    "null_mean_median": float(
                        subset[f"{axis}_level{level}_null_mean"].median()),
                    "gate_pass": passed,
                }
            axis_result["axis_pass"] = bool(all(level_passes))
            arm_result["axes"][axis] = axis_result
        arm_result["cell_uplift_median"] = float(subset["cell_uplift"].median())
        arm_result["cell_correct_fraction_median"] = float(
            subset["cell_correct_fraction"].median())
        arm_result["confusion_median"] = {
            key: float(subset[key].median())
            for key in ("noise_only_wrong_fraction",
                        "param_only_wrong_fraction", "both_wrong_fraction")
        }
        arm_result["cell_zero_probability_days_total"] = int(
            subset["cell_zero_probability_days"].sum())
        parameter_pass = arm_result["axes"]["param"]["axis_pass"]
        noise_pass = arm_result["axes"]["noise"]["axis_pass"]
        if parameter_pass and noise_pass:
            arm_result["claim"] = "joint_identification_confirmed"
        elif parameter_pass:
            arm_result["claim"] = "parameter_axis_only"
        elif noise_pass:
            arm_result["claim"] = "noise_axis_only"
        else:
            arm_result["claim"] = "neither_axis"
        verdict["arms"][arm] = arm_result
    return verdict


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=str(OUTPUT_ROOT))
    parser.add_argument("--arms", nargs="*", default=list(ARM_MODES))
    arguments = parser.parse_args()
    root = Path(arguments.root)
    frame = collect(root, arguments.arms)
    if frame.empty:
        raise SystemExit(f"no paired tasks found under {root}")
    (root / "verification").mkdir(parents=True, exist_ok=True)
    frame.to_csv(root / "verification" / "joint_task_metrics.csv", index=False)
    verdict = judge(frame, arguments.arms)
    with open(root / "verification" / "joint_paired_contrast_summary.json", "w",
              encoding="utf-8") as handle:
        json.dump(verdict, handle, indent=2, ensure_ascii=False)
    print(json.dumps(verdict, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
