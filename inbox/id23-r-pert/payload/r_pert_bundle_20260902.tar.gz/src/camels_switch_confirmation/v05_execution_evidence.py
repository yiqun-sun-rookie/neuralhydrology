"""Fifth-version execution evidence with an independent protocol identity.

The fifth version changes only the lower bound of ``parK2``.  Its restart and
environment table schemas remain those of the verified fourth-version run, but
the credential chain, parameter-domain record, source snapshot, and manifest
identity are rebound here.  In particular, a fourth-version credential cannot
be supplied as authority for a fifth-version result.
"""

from __future__ import annotations

import copy
import hashlib
import json
from collections.abc import Callable, Mapping
from datetime import date
from pathlib import Path
from typing import Any, TypeVar

from camels_switch_confirmation import (
    protocol_freeze_v04,
    protocol_freeze_v05,
    v03_execution_evidence,
    v04_execution_evidence,
)
from camels_switch_confirmation.real_regime_parameter_calibration import (
    warmup_memory_compatibility,
)
from scl_hydro.hbv_lite_numpy import resolve_hbv_bounds


V05_PAR_K2_LOWER = 0.00817389622817033
ONE_YEAR_DAYS = 365
WARMUP_DAYS = 3652
RETAINED_FRACTION_MAX = 0.05
PARAMETER_DOMAIN_MEMORY_FILENAME = "parameter_domain_warmup_memory.json"
REQUIRED_RUNTIME_DISTRIBUTIONS = v04_execution_evidence.REQUIRED_RUNTIME_DISTRIBUTIONS

# The runner adds the actual fifth-version configuration, frozen credential,
# and credential-declared human protocol dynamically.  These fixed paths cover
# the direct v04 adapter chain and the v05 implementation itself.  The generic
# restart-evidence branch separately captures the v03 implementation chain.
V05_SOURCE_FILE_PATHS = (
    "docs/plans/2026-08-24-real-regime-parameter-domain-initialization-principle-v04.md",
    "src/camels_switch_confirmation/configs/"
    "real_regime_parameter_calibration_development_screen_v04.json",
    "src/camels_switch_confirmation/protocols/"
    "real_regime_parameter_domain_initialization_v04.freeze.json",
    "src/camels_switch_confirmation/protocol_freeze_v04.py",
    "src/camels_switch_confirmation/v04_execution_evidence.py",
    "docs/superpowers/plans/2026-08-24-real-regime-k2-lower-bound-v05.md",
    "src/camels_switch_confirmation/protocol_freeze_v05.py",
    "src/camels_switch_confirmation/v05_execution_evidence.py",
    "test/test_real_regime_v05_parameter_bounds.py",
    "test/test_real_regime_v05_protocol_registration.py",
    "test/test_real_regime_v05_execution_evidence.py",
    "test/test_real_regime_v05_entry_lifecycle.py",
)


class V05ExecutionEvidenceError(ValueError):
    """Raised when fifth-version execution evidence is incomplete or altered."""


def _fail(message: str) -> None:
    raise V05ExecutionEvidenceError(message)


def _strict_json_file(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(
            Path(path).read_text(encoding="utf-8"),
            parse_constant=lambda item: (_ for _ in ()).throw(ValueError(item)),
        )
    except (OSError, UnicodeError, ValueError, json.JSONDecodeError) as error:
        raise V05ExecutionEvidenceError(f"{label} is not strict finite JSON") from error
    if type(value) is not dict:
        _fail(f"{label} must be a plain object")
    return value


def _sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


T = TypeVar("T")


def _translate_v04_error(operation: Callable[[], T]) -> T:
    """Reuse v04 schema mechanics without leaking v04 as v05 authority."""

    try:
        return operation()
    except v04_execution_evidence.V04ExecutionEvidenceError as error:
        raise V05ExecutionEvidenceError(str(error)) from error


def _validated_v05_document(
    repo_root: Path,
    credential: Mapping[str, Any],
) -> dict[str, Any]:
    if type(credential) is not dict:
        _fail("fifth-version protocol credential must be a plain object")
    if credential.get("protocol_id") != protocol_freeze_v05.FROZEN_PROTOCOL_ID:
        _fail("fifth-version protocol credential identity differs")
    if credential.get("protocol_status") != "frozen":
        _fail("fifth-version protocol credential status must be frozen")
    try:
        return protocol_freeze_v05.validate_v05_protocol_document(
            Path(repo_root).resolve(),
            credential,
        )
    except ValueError as error:
        raise V05ExecutionEvidenceError(
            f"fifth-version protocol credential is invalid: {error}"
        ) from error


def build_restart_evidence_credential(
    repo_root: Path,
    v05_credential: Mapping[str, Any],
) -> dict[str, Any]:
    """Adapt the unchanged restart schema through v05 -> v04 -> v03.

    The supplied document must first pass the distinct fifth-version protocol
    validator.  Only then is its exact fourth-version base loaded, validated,
    and adapted.  Replacing the supplied document with the v04 credential thus
    fails before the base chain is consulted.
    """

    root = Path(repo_root).resolve()
    checked = _validated_v05_document(root, v05_credential)
    base_config_path = root / str(checked["base_config_path"])
    base_config = _strict_json_file(base_config_path, "fourth-version base configuration")
    if base_config.get("experiment_id") != checked["base_experiment_id"]:
        _fail("fourth-version base configuration experiment identity differs")
    try:
        protocol_freeze_v04.validate_v04_registration_config(root, base_config)
    except ValueError as error:
        raise V05ExecutionEvidenceError(
            f"fourth-version base configuration binding is invalid: {error}"
        ) from error

    raw_credential_path = base_config.get("protocol_credential")
    expected_digest = base_config.get("protocol_credential_sha256")
    if type(raw_credential_path) is not str or type(expected_digest) is not str:
        _fail("fourth-version base configuration lacks its protocol binding")
    relative = Path(raw_credential_path)
    if relative.is_absolute() or ".." in relative.parts:
        _fail("fourth-version base credential path is unsafe")
    base_credential_path = (root / relative).resolve()
    try:
        base_credential = protocol_freeze_v04.load_frozen_protocol(
            root,
            base_credential_path,
            expected_sha256=expected_digest,
        )
        adapted = v04_execution_evidence.build_restart_evidence_credential(
            root,
            base_credential,
        )
    except (
        protocol_freeze_v04.ProtocolNotFrozenError,
        v04_execution_evidence.V04ExecutionEvidenceError,
    ) as error:
        raise V05ExecutionEvidenceError(
            f"fourth-version restart-evidence base is invalid: {error}"
        ) from error

    result = copy.deepcopy(adapted)
    result["protocol_id"] = checked["protocol_id"]
    result["human_protocol_path"] = checked["human_protocol_path"]
    result["human_protocol_sha256"] = checked["human_protocol_sha256"]
    fixed = result.get("fixed_factors")
    if not isinstance(fixed, dict):
        _fail("restart-evidence base lacks fixed factors")
    fixed["parameter_bounds_preset"] = protocol_freeze_v05.V05_PARAMETER_DOMAIN[
        "preset"
    ]
    try:
        contract = v03_execution_evidence._freeze_contract(result)
    except v03_execution_evidence.ExecutionEvidenceError as error:
        raise V05ExecutionEvidenceError(
            f"fifth-version restart-evidence adaptation is invalid: {error}"
        ) from error
    if contract["protocol_id"] != protocol_freeze_v05.FROZEN_PROTOCOL_ID:
        _fail("restart evidence was not rebound to the fifth-version protocol")
    if contract["bounds_preset"] != protocol_freeze_v05.V05_PARAMETER_DOMAIN["preset"]:
        _fail("restart evidence was not rebound to the fifth-version parameter preset")
    return result


def validate_environment_capture(
    output_directory: Path,
    capture_record: Mapping[str, Any],
    environment: Mapping[str, Any],
    *,
    allow_incomplete_python_inventory: bool = False,
) -> dict[str, Any]:
    """Validate the unchanged environment schema under the v05 API."""

    return _translate_v04_error(
        lambda: v04_execution_evidence.validate_environment_capture(
            output_directory,
            capture_record,
            environment,
            allow_incomplete_python_inventory=allow_incomplete_python_inventory,
        )
    )


def cached_python_inventory_complete(capture: Mapping[str, Any]) -> bool:
    return _translate_v04_error(
        lambda: v04_execution_evidence.cached_python_inventory_complete(capture)
    )


def cached_runtime_environment_complete(environment: Mapping[str, Any]) -> bool:
    return _translate_v04_error(
        lambda: v04_execution_evidence.cached_runtime_environment_complete(environment)
    )


def cached_environment_capture_complete(
    capture: Mapping[str, Any],
    environment: Mapping[str, Any],
) -> bool:
    return _translate_v04_error(
        lambda: v04_execution_evidence.cached_environment_capture_complete(
            capture,
            environment,
        )
    )


def _memory_for_days(
    bounds: Mapping[str, Any],
    days: int,
    *,
    retained_fraction_max: float,
) -> dict[str, Any]:
    computed = warmup_memory_compatibility(
        bounds,
        days,
        retained_fraction_max=retained_fraction_max,
    )
    return {
        "parameter": "parK2",
        "days": int(computed["warmup_days"]),
        "parK2_lower_bound": float(computed["parK2_lower_bound"]),
        "retained_fraction_formula": "(1 - parK2_lower_bound) ** days",
        "retained_fraction": float(computed["retained_fraction"]),
        "half_life_days": float(computed["half_life_days"]),
        "minimum_days_required": int(computed["minimum_warmup_days_required"]),
        "retained_fraction_max": float(computed["retained_fraction_max"]),
        "passes": bool(computed["passes"]),
    }


def parameter_domain_memory_record(config: Mapping[str, Any]) -> dict[str, Any]:
    """Recompute both the one-year and 3,652-day v05 memory records."""

    if not isinstance(config, Mapping):
        _fail("fifth-version configuration must be a mapping")
    if config.get("experiment_id") != protocol_freeze_v05.V05_EXPERIMENT_ID:
        _fail("parameter-domain record requires the exact fifth-version experiment")
    if (
        config.get("protocol_id") != protocol_freeze_v05.FROZEN_PROTOCOL_ID
        or config.get("protocol_scope") != protocol_freeze_v05.FROZEN_PROTOCOL_SCOPE
    ):
        _fail("parameter-domain record requires the fifth-version protocol identity")
    preset = config.get("parameter_bounds_preset")
    if preset != protocol_freeze_v05.V05_PARAMETER_DOMAIN["preset"]:
        _fail("parameter-domain preset differs from the fifth-version contract")

    periods = config.get("periods")
    if not isinstance(periods, Mapping) or not isinstance(periods.get("warmup"), Mapping):
        _fail("fifth-version warmup period is missing")
    warmup = periods["warmup"]
    if set(warmup) != {"start", "end"}:
        _fail("fifth-version warmup period has wrong fields")
    try:
        start = date.fromisoformat(str(warmup["start"]))
        end = date.fromisoformat(str(warmup["end"]))
    except ValueError as error:
        raise V05ExecutionEvidenceError("fifth-version warmup dates are invalid") from error
    days = (end - start).days + 1
    if (start.isoformat(), end.isoformat(), days) != (
        "1989-10-01",
        "1999-09-30",
        WARMUP_DAYS,
    ):
        _fail("fifth-version warmup dates differ from the unchanged 3,652-day contract")

    compatibility = config.get("initialization_compatibility")
    if compatibility != protocol_freeze_v05.V05_INITIALIZATION_COMPATIBILITY:
        _fail("fifth-version initialization compatibility differs from the contract")
    bounds = resolve_hbv_bounds(str(preset))
    expected_bounds = protocol_freeze_v05.V05_PARAMETER_DOMAIN["bounds"]
    recorded_bounds = {
        name: [float(interval[0]), float(interval[1])]
        for name, interval in bounds.items()
    }
    if recorded_bounds != expected_bounds:
        _fail("resolved fifth-version parameter bounds differ from the protocol domain")
    if recorded_bounds["parK2"] != [V05_PAR_K2_LOWER, 0.2]:
        _fail("fifth-version parK2 bound differs from the analytical one-year limit")

    threshold = float(
        protocol_freeze_v05.V05_INITIALIZATION_COMPATIBILITY["analytical_memory"][
            "retained_fraction_max"
        ]
    )
    if threshold != RETAINED_FRACTION_MAX:
        _fail("fifth-version retained-memory threshold must equal 0.05")
    one_year = _memory_for_days(
        bounds,
        ONE_YEAR_DAYS,
        retained_fraction_max=RETAINED_FRACTION_MAX,
    )
    warmup_memory = _memory_for_days(
        bounds,
        days,
        retained_fraction_max=threshold,
    )
    return {
        "schema_version": 1,
        "experiment_id": protocol_freeze_v05.V05_EXPERIMENT_ID,
        "protocol_id": protocol_freeze_v05.FROZEN_PROTOCOL_ID,
        "protocol_scope": protocol_freeze_v05.FROZEN_PROTOCOL_SCOPE,
        "parameter_bounds_preset": str(preset),
        "parameter_bounds": recorded_bounds,
        "one_year_memory": one_year,
        "warmup": {
            "start": start.isoformat(),
            "end": end.isoformat(),
            "days": days,
            "observations_use": compatibility["warmup_observations_use"],
        },
        "warmup_memory": warmup_memory,
    }


def validate_parameter_domain_memory_record(
    record: Mapping[str, Any],
    config: Mapping[str, Any],
) -> dict[str, Any]:
    """Reject a saved v05 parameter-memory record that differs at any field."""

    if type(record) is not dict:
        _fail("fifth-version parameter-domain memory record must be a plain object")
    expected = parameter_domain_memory_record(config)
    if record != expected:
        _fail("fifth-version parameter-domain memory record differs from recomputation")
    return copy.deepcopy(expected)


# The artifact filename is deliberately unchanged from v04.  These aliases let
# shared runner code retain its filename-oriented terminology while the public
# v05 record name makes the added one-year check explicit.
parameter_domain_warmup_memory_record = parameter_domain_memory_record
validate_parameter_domain_warmup_memory_record = validate_parameter_domain_memory_record


def _validate_manifest_protocol_binding(
    manifest: Mapping[str, Any],
    config: Mapping[str, Any],
    credential: Mapping[str, Any],
) -> None:
    protocol = manifest.get("protocol")
    if not isinstance(protocol, Mapping):
        _fail("run manifest lacks fifth-version protocol identity")
    expected = {
        "protocol_id": credential["protocol_id"],
        "credential_path": str(config["protocol_credential"]).replace("\\", "/"),
        "credential_sha256": str(config["protocol_credential_sha256"]),
        "human_protocol_path": credential["human_protocol_path"],
        "human_protocol_sha256": credential["human_protocol_sha256"],
    }
    if dict(protocol) != expected:
        _fail("run manifest protocol identity differs from the fifth-version freeze")


def _validate_source_snapshot_identity(
    output: Path,
    config: Mapping[str, Any],
    credential: Mapping[str, Any],
) -> None:
    manifest = _strict_json_file(
        output / "source_snapshot" / "manifest.json",
        "source snapshot manifest",
    )
    entries = manifest.get("source_files")
    if not isinstance(entries, list) or not entries:
        _fail("source snapshot manifest must contain source_files")
    original_paths: list[str] = []
    for index, entry in enumerate(entries):
        if not isinstance(entry, Mapping) or type(entry.get("original_path")) is not str:
            _fail(f"source snapshot entry {index} lacks an original path")
        original_paths.append(str(entry["original_path"]).replace("\\", "/"))
    if len(original_paths) != len(set(original_paths)):
        _fail("source snapshot original paths must be unique")
    required = set(V05_SOURCE_FILE_PATHS)
    required.update({
        str(config["protocol_credential"]).replace("\\", "/"),
        str(credential["human_protocol_path"]).replace("\\", "/"),
    })
    missing = sorted(required - set(original_paths))
    if missing:
        _fail(f"source snapshot lacks fifth-version evidence sources: {missing}")


def verify_execution_evidence(
    output_directory: Path,
    credential_path: Path,
    *,
    repo_root: Path,
    expected_experiment_id: str | None = None,
    expected_run_instance_id: str | None = None,
    expected_config_sha256: str | None = None,
    expected_selected_parameter_fingerprints: Mapping[str, str] | None = None,
    allow_failed: bool = False,
) -> dict[str, Any]:
    """Verify restart, environment, memory, source, and v05 identity evidence."""

    output = Path(output_directory).resolve()
    root = Path(repo_root).resolve()
    config = _strict_json_file(output / "config_snapshot.json", "configuration snapshot")
    try:
        protocol_freeze_v05.validate_v05_registration_config(root, config)
    except ValueError as error:
        raise V05ExecutionEvidenceError(
            f"fifth-version configuration binding is invalid: {error}"
        ) from error
    configured_credential = (root / str(config["protocol_credential"])).resolve()
    supplied_credential = Path(credential_path).resolve()
    if supplied_credential != configured_credential:
        _fail("supplied fifth-version credential path differs from the configuration")
    try:
        credential = protocol_freeze_v05.load_frozen_protocol(
            root,
            supplied_credential,
            expected_sha256=str(config["protocol_credential_sha256"]),
        )
    except ValueError as error:
        raise V05ExecutionEvidenceError(
            f"fifth-version frozen credential binding is invalid: {error}"
        ) from error

    missing = [
        filename
        for filename in credential["evidence_contract"]["required_new_artifacts"]
        if not (output / filename).is_file()
    ]
    if missing:
        _fail(f"fifth-version execution evidence lacks required artifacts: {missing}")
    validate_parameter_domain_memory_record(
        _strict_json_file(
            output / PARAMETER_DOMAIN_MEMORY_FILENAME,
            "fifth-version parameter-domain memory record",
        ),
        config,
    )
    manifest = _strict_json_file(output / "run_manifest.json", "run manifest")
    _validate_manifest_protocol_binding(manifest, config, credential)

    adapted = build_restart_evidence_credential(root, credential)
    try:
        shared = v03_execution_evidence.verify_execution_evidence(
            output,
            adapted,
            expected_experiment_id=expected_experiment_id,
            expected_run_instance_id=expected_run_instance_id,
            expected_config_sha256=expected_config_sha256,
            expected_selected_parameter_fingerprints=(
                expected_selected_parameter_fingerprints
            ),
            allow_failed=allow_failed,
        )
    except v03_execution_evidence.ExecutionEvidenceError as error:
        raise V05ExecutionEvidenceError(
            f"fifth-version restart execution evidence is invalid: {error}"
        ) from error

    capture = validate_environment_capture(
        output,
        _strict_json_file(output / "environment_capture.json", "environment capture"),
        _strict_json_file(output / "environment.json", "environment record"),
        allow_incomplete_python_inventory=allow_failed,
    )
    if not capture["complete"] and (
        shared["terminal_status"] != "failed" or shared["restart_count"] != 0
    ):
        _fail("incomplete Python inventory is allowed only for a zero-restart failed package")
    _validate_source_snapshot_identity(output, config, credential)
    return {**shared, "environment_capture": capture}


__all__ = [
    "ONE_YEAR_DAYS",
    "PARAMETER_DOMAIN_MEMORY_FILENAME",
    "REQUIRED_RUNTIME_DISTRIBUTIONS",
    "RETAINED_FRACTION_MAX",
    "V05ExecutionEvidenceError",
    "V05_PAR_K2_LOWER",
    "V05_SOURCE_FILE_PATHS",
    "WARMUP_DAYS",
    "build_restart_evidence_credential",
    "cached_environment_capture_complete",
    "cached_python_inventory_complete",
    "cached_runtime_environment_complete",
    "parameter_domain_memory_record",
    "parameter_domain_warmup_memory_record",
    "validate_environment_capture",
    "validate_parameter_domain_memory_record",
    "validate_parameter_domain_warmup_memory_record",
    "verify_execution_evidence",
]
