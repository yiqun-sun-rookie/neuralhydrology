"""R-perturbation robustness: shared settings and the calibration diagnostic.

Preregistration: ``docs/plans/2026-09-01-noise-axis-r-perturbation-robustness-prereg-v01.md``
(sha256 ``c9773ba120960831d387c21a1168da9fb0f5e869b3ed801f648292c2232a2f5a``, frozen 2026-09-02).

This module owns the two things every arm of the line shares: the named R variants, and the
stratified calibration diagnostic.  It deliberately holds no gate logic -- the gates are
settled once, at the end, from the arms' per-basin tables.

Calibration diagnostic (prereg section 4).  z_t^2 = e_t^2 / u_t, where e_t is the one-step
forecast error and u_t is the filter's own innovation variance -- read straight off
``candidate_results[0].innovation_covariance``, which already contains that day's R.  The
motivating audit numbers (per-basin mean z^2 median ~206, high-flow tercile ~4400) were
*reverse-engineered* from frozen daily likelihoods and are not a registered artefact; prereg
change 0.7 requires this direct measurement to supersede them.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

_SRC = Path(__file__).resolve().parents[1]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation.noise_axis_filtering import (  # noqa: E402
    LegacyConstantR,
    MagnitudePerturbedR,
    ShapePerturbedR,
)

# The three preregistered R variants, by their prereg names.
R_VARIANTS = {
    "R-old": LegacyConstantR,
    "R-shape": ShapePerturbedR,
    "R-mag": MagnitudePerturbedR,
}

# Floor-domination bands (prereg section 4): share of days on which the frozen constant, not
# the flow-dependent term, sets sigma_t.
FLOOR_BANDS = ((0.0, 0.10, "lt10pct"), (0.10, 0.50, "10to50pct"), (0.50, 1.01, "gt50pct"))


def make_r_source(name: str):
    """Instantiate one preregistered R variant by name; unknown names are an error."""
    if name not in R_VARIANTS:
        raise ValueError(f"unknown R variant {name!r}; registered: {sorted(R_VARIANTS)}")
    return R_VARIANTS[name]()


def _tercile_labels(observations: np.ndarray) -> np.ndarray:
    """Low/mid/high flow terciles by the basin's own observed discharge distribution."""
    values = np.asarray(observations, dtype=np.float64)
    low, high = np.quantile(values, [1.0 / 3.0, 2.0 / 3.0])
    labels = np.full(len(values), 1, dtype=np.int64)
    labels[values <= low] = 0
    labels[values > high] = 2
    return labels


def calibration_diagnostic(
    forecast: np.ndarray,
    observations: np.ndarray,
    innovation_variance: np.ndarray,
    sigma_obs: float,
    observation_variance: np.ndarray | None = None,
    burn_in: int = 0,
) -> dict:
    """Per-basin z^2 statistics, overall and by flow tercile, plus floor domination.

    ``innovation_variance`` is the filter's own u_t (already includes R).  Days where u_t is
    not finite or not positive are excluded and counted, never silently coerced.
    """
    error = np.asarray(forecast, dtype=np.float64)[burn_in:] - np.asarray(
        observations, dtype=np.float64
    )[burn_in:]
    u = np.asarray(innovation_variance, dtype=np.float64)[burn_in:]
    observed = np.asarray(observations, dtype=np.float64)[burn_in:]

    usable = np.isfinite(u) & (u > 0.0) & np.isfinite(error)
    n_excluded = int(np.count_nonzero(~usable))
    z2 = np.full(len(u), np.nan, dtype=np.float64)
    z2[usable] = np.square(error[usable]) / u[usable]

    terciles = _tercile_labels(observed)
    record = {
        "n_days_scored": int(np.count_nonzero(usable)),
        "n_days_excluded": n_excluded,
        "z2_mean": float(np.nanmean(z2)) if n_excluded < len(z2) else float("nan"),
        "z2_median": float(np.nanmedian(z2)) if n_excluded < len(z2) else float("nan"),
        "abs_error_median_over_sigma": float(np.median(np.abs(error)) / float(sigma_obs)),
    }
    for index, name in enumerate(("low", "mid", "high")):
        band = z2[(terciles == index) & usable]
        record[f"z2_mean_{name}"] = float(np.mean(band)) if len(band) else float("nan")
        record[f"z2_median_{name}"] = float(np.median(band)) if len(band) else float("nan")

    if observation_variance is None:
        floor_share = float("nan")
    else:
        variance = np.asarray(observation_variance, dtype=np.float64)[burn_in:]
        scored = np.isfinite(variance)
        floor_share = (
            float(np.mean(np.isclose(variance[scored], float(sigma_obs) ** 2, rtol=0.0, atol=0.0)))
            if np.any(scored)
            else float("nan")
        )
    record["floor_share"] = floor_share
    record["floor_band"] = _floor_band(floor_share)
    return record


def _floor_band(share: float) -> str:
    if not np.isfinite(share):
        return "unknown"
    for low, high, name in FLOOR_BANDS:
        if low <= share < high:
            return name
    return "gt50pct"
