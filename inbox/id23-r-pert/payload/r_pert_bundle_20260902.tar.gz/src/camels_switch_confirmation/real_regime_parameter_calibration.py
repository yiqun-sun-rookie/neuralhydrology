"""Continuous real-flow regime parameter calibration contracts.

This module produces three fixed HBV-light parameter vectors.  Every vector is
run over the complete warmup, fit, and validation trajectory; ``low_flow`` and
``high_flow`` identify only the dates scored by an objective.  They never mean
that a parameter vector is activated only on those dates.

The functions here implement development-only calibration and validation.
They do not perform online filtering and do not read any candidate holdout.
"""

from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd

from scl_hydro.hbv_lite_cma_calibrate import calibrate_hbv_lite_cma
from scl_hydro.hbv_lite_numpy import PARAM_NAMES, simulate_hbv_lite


OBJECTIVES = {
    "all_flow": "nse",
    "low_flow": "log_mse",
    "high_flow": "raw_mse",
}

MINIMUM_METRIC_DAYS = 10
DEFAULT_TARGET_RELATIVE_IMPROVEMENT = 0.05
DEFAULT_MINIMUM_IMPROVED_WATER_YEARS = 2
DEFAULT_MAXIMUM_ALL_PERIOD_NSE_DROP = 0.03
DEFAULT_MAXIMUM_OPPOSITE_REGIME_LOSS_INCREASE = 0.20


@dataclass(frozen=True)
class FlowThresholds:
    """Absolute flow thresholds frozen from fit-period observations only."""

    low: float
    high: float
    fit_count: int
    low_quantile: float = 0.30
    high_quantile: float = 0.70
    quantile_method: str = "linear"

    def __post_init__(self) -> None:
        if not np.isfinite(self.low) or not np.isfinite(self.high):
            raise ValueError("flow thresholds must be finite")
        if self.low < 0.0 or self.high < 0.0:
            raise ValueError("flow thresholds must be nonnegative")
        if self.low >= self.high:
            raise ValueError("low and high flow thresholds must be distinct and ordered")
        if int(self.fit_count) < MINIMUM_METRIC_DAYS:
            raise ValueError(f"fit_count must be at least {MINIMUM_METRIC_DAYS}")
        if not (0.0 < float(self.low_quantile) < float(self.high_quantile) < 1.0):
            raise ValueError("flow quantiles must satisfy 0 < low < high < 1")
        if self.quantile_method != "linear":
            raise ValueError("only NumPy's linear quantile method is supported")


def _strict_real_scalar(value: Any, name: str) -> float:
    if isinstance(value, (bool, np.bool_)) or not isinstance(
        value,
        (int, float, np.integer, np.floating),
    ):
        raise ValueError(f"{name} must be a real numeric scalar")
    result = float(value)
    if not np.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def warmup_memory_compatibility(
    parameter_bounds: Mapping[str, Sequence[float]],
    warmup_days: int,
    *,
    retained_fraction_max: float,
) -> dict[str, Any]:
    """Check whether warmup removes enough lower-zone initial-state memory.

    The slowest allowed lower-zone reservoir is determined by the configured
    lower bound of ``parK2``.  Its retained initial-state fraction after
    ``warmup_days`` is exactly ``(1 - parK2_lower_bound) ** warmup_days``.
    This pure analytical check reads neither observations nor configuration
    globals.
    """

    if isinstance(warmup_days, (bool, np.bool_)) or not isinstance(
        warmup_days,
        (int, np.integer),
    ):
        raise ValueError("warmup_days must be a positive integer")
    checked_warmup_days = int(warmup_days)
    if checked_warmup_days <= 0:
        raise ValueError("warmup_days must be a positive integer")

    if not isinstance(parameter_bounds, Mapping) or "parK2" not in parameter_bounds:
        raise ValueError("parameter_bounds must contain parK2")
    raw_bound = parameter_bounds["parK2"]
    if (
        isinstance(raw_bound, (str, bytes, bool, np.bool_))
        or not isinstance(raw_bound, Sequence)
        or len(raw_bound) != 2
    ):
        raise ValueError("parK2 bounds must contain exactly two numeric values")
    lower = _strict_real_scalar(raw_bound[0], "parK2 lower bound")
    upper = _strict_real_scalar(raw_bound[1], "parK2 upper bound")
    if not (0.0 < lower < upper < 1.0):
        raise ValueError("parK2 bounds must satisfy 0 < lower < upper < 1")

    threshold = _strict_real_scalar(retained_fraction_max, "retained_fraction_max")
    if not 0.0 < threshold < 1.0:
        raise ValueError("retained_fraction_max must lie strictly between zero and one")

    daily_retention = 1.0 - lower
    retained_fraction = daily_retention**checked_warmup_days
    decay_log = math.log(daily_retention)
    half_life_days = math.log(0.5) / decay_log
    minimum_days = max(1, math.ceil(math.log(threshold) / decay_log))
    return {
        "parK2_lower_bound": lower,
        "warmup_days": checked_warmup_days,
        "retained_fraction": float(retained_fraction),
        "half_life_days": float(half_life_days),
        "minimum_warmup_days_required": int(minimum_days),
        "retained_fraction_max": threshold,
        "passes": bool(retained_fraction <= threshold),
    }


def _require_strict_recomputed_value(actual: Any, expected: Any, label: str) -> None:
    if isinstance(expected, Mapping):
        if not isinstance(actual, Mapping) or set(actual) != set(expected):
            raise ValueError(f"{label} fields differ from recomputation")
        for key, expected_value in expected.items():
            _require_strict_recomputed_value(actual[key], expected_value, f"{label}.{key}")
        return
    if isinstance(expected, list):
        if not isinstance(actual, list) or len(actual) != len(expected):
            raise ValueError(f"{label} items differ from recomputation")
        for index, (actual_value, expected_value) in enumerate(zip(actual, expected)):
            _require_strict_recomputed_value(
                actual_value,
                expected_value,
                f"{label}[{index}]",
            )
        return
    if isinstance(expected, bool):
        if type(actual) is not bool or actual is not expected:
            raise ValueError(f"{label} differs from recomputation")
        return
    if isinstance(expected, int):
        if isinstance(actual, (bool, np.bool_)) or not isinstance(actual, (int, np.integer)):
            raise ValueError(f"{label} differs from recomputation")
        if int(actual) != expected:
            raise ValueError(f"{label} differs from recomputation")
        return
    if isinstance(expected, float):
        checked = _strict_real_scalar(actual, label)
        if not np.isclose(checked, expected, rtol=0.0, atol=1e-12):
            raise ValueError(f"{label} differs from recomputation")
        return
    if type(actual) is not type(expected) or actual != expected:
        raise ValueError(f"{label} differs from recomputation")


def initial_state_convergence_diagnostics(
    dry_scenario: Mapping[str, Any],
    wet_scenario: Mapping[str, Any],
    output_functional_distances: Mapping[str, Mapping[str, Any]],
    *,
    par_k2: float,
    warmup_days: int,
    retained_fraction_max: float = 0.05,
    maximum_distance: float = 0.03,
    flow_log_offset: float = 0.01,
    recorded_summary: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Verify dry/wet lower-zone convergence and its three output distances."""

    required_scenario_fields = {
        "scenario_id",
        "parameter_sha256",
        "initial_slz_mm",
        "final_slz_mm",
    }

    def checked_scenario(value: Any, expected_id: str) -> dict[str, Any]:
        label = f"{expected_id} scenario"
        if not isinstance(value, Mapping) or set(value) != required_scenario_fields:
            raise ValueError(f"{label} must contain exactly {sorted(required_scenario_fields)}")
        if value["scenario_id"] != expected_id:
            raise ValueError(f"{label} scenario_id must be {expected_id!r}")
        fingerprint = value["parameter_sha256"]
        if (
            not isinstance(fingerprint, str)
            or len(fingerprint) != 64
            or any(character not in "0123456789abcdef" for character in fingerprint)
        ):
            raise ValueError(f"{label} parameter fingerprint must be a lowercase SHA-256 digest")
        initial_slz = _strict_real_scalar(value["initial_slz_mm"], f"{label} initial_slz_mm")
        final_slz = _strict_real_scalar(value["final_slz_mm"], f"{label} final_slz_mm")
        if initial_slz < 0.0 or final_slz < 0.0:
            raise ValueError(f"{label} initial_slz_mm and final_slz_mm must be nonnegative")
        return {
            "scenario_id": expected_id,
            "parameter_sha256": fingerprint,
            "initial_slz_mm": initial_slz,
            "final_slz_mm": final_slz,
        }

    dry = checked_scenario(dry_scenario, "dry")
    wet = checked_scenario(wet_scenario, "wet")
    if dry["parameter_sha256"] != wet["parameter_sha256"]:
        raise ValueError("dry and wet scenario parameter fingerprints must match")
    if dry["initial_slz_mm"] != 0.0 or wet["initial_slz_mm"] != 100.0:
        raise ValueError("dry and wet initial_slz_mm values must be exactly 0 and 100 mm")

    checked_par_k2 = _strict_real_scalar(par_k2, "par_k2")
    if not 0.0 < checked_par_k2 < 1.0:
        raise ValueError("par_k2 must lie strictly between zero and one")
    if isinstance(warmup_days, (bool, np.bool_)) or not isinstance(
        warmup_days,
        (int, np.integer),
    ):
        raise ValueError("warmup_days must be a positive integer")
    checked_warmup_days = int(warmup_days)
    if checked_warmup_days <= 0:
        raise ValueError("warmup_days must be a positive integer")
    threshold = _strict_real_scalar(retained_fraction_max, "retained_fraction_max")
    if not 0.0 < threshold < 1.0:
        raise ValueError("retained_fraction_max must lie strictly between zero and one")
    checked_maximum_distance = _strict_real_scalar(maximum_distance, "maximum_distance")
    if checked_maximum_distance < 0.0:
        raise ValueError("maximum_distance must be nonnegative")
    checked_log_offset = _strict_real_scalar(flow_log_offset, "flow_log_offset")
    if checked_log_offset <= 0.0:
        raise ValueError("flow_log_offset must be positive")

    initial_difference = wet["initial_slz_mm"] - dry["initial_slz_mm"]
    final_difference = wet["final_slz_mm"] - dry["final_slz_mm"]
    if final_difference < 0.0:
        raise ValueError("wet final_slz_mm must not be less than dry final_slz_mm")
    analytical_retained = (1.0 - checked_par_k2) ** checked_warmup_days
    replayed_retained = final_difference / initial_difference
    retained_matches = bool(
        np.isclose(
            replayed_retained,
            analytical_retained,
            rtol=1e-10,
            atol=1e-12,
        )
    )
    distance_gate = _validated_output_functional_distance_gate(
        {"output_functional_distances": output_functional_distances},
        maximum_distance=checked_maximum_distance,
        flow_log_offset_mm_day=checked_log_offset,
        label="initial-state convergence",
    )
    analytical_pass = bool(analytical_retained <= threshold)
    replayed_pass = bool(replayed_retained <= threshold)
    result = {
        "scenario_ids": ["dry", "wet"],
        "parameter_sha256": dry["parameter_sha256"],
        "par_k2": checked_par_k2,
        "warmup_days": checked_warmup_days,
        "initial_slz_difference_mm": initial_difference,
        "final_slz_difference_mm": final_difference,
        "analytical_retained_fraction": float(analytical_retained),
        "replayed_retained_fraction": float(replayed_retained),
        "retained_fraction_max": threshold,
        "analytical_retained_fraction_pass": analytical_pass,
        "replayed_retained_fraction_pass": replayed_pass,
        "retained_fraction_matches_analytical": retained_matches,
        "output_functional_distance_gate": distance_gate,
        "passes": bool(
            analytical_pass
            and replayed_pass
            and retained_matches
            and distance_gate["passes"]
        ),
    }
    if recorded_summary is not None:
        _require_strict_recomputed_value(recorded_summary, result, "recorded_summary")
    return result


def hydrograph_response_diagnostics(
    observations: Any,
    simulations: Any,
    dates: Any,
    *,
    variability_ratio_min: float = 0.25,
    variability_ratio_max: float = 4.0,
    mean_ratio_min: float = 0.25,
    mean_ratio_max: float = 4.0,
    total_variation_ratio_min: float = 0.10,
    total_variation_ratio_max: float = 10.0,
    mean_offset: float = 0.01,
    recorded_summary: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Check that simulated validation flow remains responsive each water year.

    The diagnostic deliberately uses three broad, separately reported ratios:
    standard-deviation ratio, offset mean ratio, and total daily-variation
    ratio.  It catches a slowly changing but nonconstant line without treating
    every smooth exponential recession as a plateau.
    """

    ratio_limits: dict[str, tuple[float, float]] = {}
    for label, raw_minimum, raw_maximum in (
        ("variability_ratio", variability_ratio_min, variability_ratio_max),
        ("mean_ratio", mean_ratio_min, mean_ratio_max),
        (
            "total_variation_ratio",
            total_variation_ratio_min,
            total_variation_ratio_max,
        ),
    ):
        minimum = _strict_real_scalar(raw_minimum, f"{label}_min threshold")
        maximum = _strict_real_scalar(raw_maximum, f"{label}_max threshold")
        if not (0.0 < minimum <= maximum):
            raise ValueError(f"{label} thresholds must satisfy 0 < minimum <= maximum")
        ratio_limits[label] = (minimum, maximum)
    offset = _strict_real_scalar(mean_offset, "mean_offset")
    if offset <= 0.0:
        raise ValueError("mean_offset must be positive")

    raw_observed = np.asarray(observations)
    raw_simulated = np.asarray(simulations)
    for label, raw in (("observations", raw_observed), ("simulations", raw_simulated)):
        if raw.dtype.kind not in "iufc" or raw.dtype.kind == "c":
            raise ValueError(f"{label} must contain real numeric values")
        if raw.ndim != 1:
            raise ValueError(f"{label} must be one-dimensional")
    observed = raw_observed.astype(np.float64, copy=False)
    simulated = raw_simulated.astype(np.float64, copy=False)
    if len(observed) == 0 or len(observed) != len(simulated):
        raise ValueError("observations and simulations must have the same positive length")
    if not np.all(np.isfinite(observed)) or not np.all(np.isfinite(simulated)):
        raise ValueError("observations and simulations must contain only finite values")
    if np.any(observed < 0.0) or np.any(simulated < 0.0):
        raise ValueError("observations and simulations must be nonnegative")

    date_index = pd.DatetimeIndex(dates)
    if len(date_index) != len(observed):
        raise ValueError("dates, observations, and simulations must have identical lengths")
    if date_index.hasnans:
        raise ValueError("dates must not contain missing values")
    if not date_index.is_unique:
        raise ValueError("dates must be unique")
    if not date_index.is_monotonic_increasing:
        raise ValueError("dates must be strictly increasing")
    if date_index.tz is not None:
        raise ValueError("dates must be timezone-naive daily dates")
    normalized_dates = date_index.normalize()
    if not normalized_dates.equals(date_index):
        raise ValueError("dates must be normalized daily dates")

    water_year_values = np.where(
        date_index.month >= 10,
        date_index.year + 1,
        date_index.year,
    ).astype(int)
    water_years = tuple(int(value) for value in np.unique(water_year_values))
    if any(current != previous + 1 for previous, current in zip(water_years, water_years[1:])):
        raise ValueError("dates must cover contiguous complete water years")

    records: list[dict[str, Any]] = []
    for water_year in water_years:
        membership = water_year_values == water_year
        selected_dates = date_index[membership]
        expected_dates = pd.date_range(
            f"{water_year - 1}-10-01",
            f"{water_year}-09-30",
            freq="D",
        )
        if not selected_dates.equals(expected_dates):
            raise ValueError(f"water year {water_year} must be a complete water year")

        observed_year = observed[membership]
        simulated_year = simulated[membership]
        observed_mean = float(np.mean(observed_year))
        simulated_mean = float(np.mean(simulated_year))
        observed_std = float(np.std(observed_year, ddof=0))
        simulated_std = float(np.std(simulated_year, ddof=0))
        if not np.isfinite(observed_std) or observed_std <= 0.0:
            raise ValueError(
                f"water year {water_year} observed standard deviation must be positive"
            )
        observed_variation = float(np.sum(np.abs(np.diff(observed_year))))
        simulated_variation = float(np.sum(np.abs(np.diff(simulated_year))))
        if not np.isfinite(observed_variation) or observed_variation <= 0.0:
            raise ValueError(
                f"water year {water_year} observed total variation must be positive"
            )

        variability_ratio = simulated_std / observed_std
        mean_ratio = (simulated_mean + offset) / (observed_mean + offset)
        total_variation_ratio = simulated_variation / observed_variation
        variability_minimum, variability_maximum = ratio_limits["variability_ratio"]
        mean_minimum, mean_maximum = ratio_limits["mean_ratio"]
        variation_minimum, variation_maximum = ratio_limits["total_variation_ratio"]
        variability_pass = variability_minimum <= variability_ratio <= variability_maximum
        mean_pass = mean_minimum <= mean_ratio <= mean_maximum
        variation_pass = variation_minimum <= total_variation_ratio <= variation_maximum
        records.append({
            "water_year": water_year,
            "day_count": int(membership.sum()),
            "observed_mean": observed_mean,
            "simulated_mean": simulated_mean,
            "observed_standard_deviation": observed_std,
            "simulated_standard_deviation": simulated_std,
            "variability_ratio": float(variability_ratio),
            "variability_ratio_min": variability_minimum,
            "variability_ratio_max": variability_maximum,
            "variability_ratio_pass": bool(variability_pass),
            "mean_offset": offset,
            "mean_ratio": float(mean_ratio),
            "mean_ratio_min": mean_minimum,
            "mean_ratio_max": mean_maximum,
            "mean_ratio_pass": bool(mean_pass),
            "observed_total_variation": observed_variation,
            "simulated_total_variation": simulated_variation,
            "total_variation_ratio": float(total_variation_ratio),
            "total_variation_ratio_min": variation_minimum,
            "total_variation_ratio_max": variation_maximum,
            "total_variation_ratio_pass": bool(variation_pass),
            "passes": bool(variability_pass and mean_pass and variation_pass),
        })
    result = {
        "thresholds": {
            "variability_ratio_min": ratio_limits["variability_ratio"][0],
            "variability_ratio_max": ratio_limits["variability_ratio"][1],
            "mean_ratio_min": ratio_limits["mean_ratio"][0],
            "mean_ratio_max": ratio_limits["mean_ratio"][1],
            "total_variation_ratio_min": ratio_limits["total_variation_ratio"][0],
            "total_variation_ratio_max": ratio_limits["total_variation_ratio"][1],
            "mean_offset": offset,
        },
        "water_years": records,
        "passes": bool(records and all(record["passes"] for record in records)),
    }
    if recorded_summary is not None:
        _require_strict_recomputed_value(recorded_summary, result, "recorded_summary")
    return result


def _as_one_dimensional_float(values: Any, name: str) -> np.ndarray:
    array = np.asarray(values, dtype=np.float64)
    if array.ndim != 1:
        raise ValueError(f"{name} must be one-dimensional")
    return array


def _as_boolean_mask(values: Any, length: int, name: str) -> np.ndarray:
    array = np.asarray(values)
    if array.dtype.kind != "b":
        raise ValueError(f"{name} must be a boolean array")
    if array.shape != (length,):
        raise ValueError(f"{name} must have shape ({length},)")
    return array.astype(bool, copy=True)


def _validate_observations(values: Any, name: str = "observations") -> np.ndarray:
    observations = _as_one_dimensional_float(values, name)
    if np.any(np.isinf(observations)):
        raise ValueError(f"{name} must not contain infinite values")
    finite = np.isfinite(observations)
    if np.any(observations[finite] < 0.0):
        raise ValueError(f"{name} must be nonnegative where finite")
    return observations


def fit_flow_thresholds(
    fit_observations: Any,
    low_quantile: float = 0.30,
    high_quantile: float = 0.70,
) -> FlowThresholds:
    """Fit absolute thresholds from the supplied fit observations.

    The function intentionally accepts no validation observations.  NaN
    observations are excluded, while infinities and negative finite discharge
    fail explicitly.
    """

    if not (0.0 < float(low_quantile) < float(high_quantile) < 1.0):
        raise ValueError("flow quantiles must satisfy 0 < low < high < 1")
    observations = _validate_observations(fit_observations, "fit_observations")
    finite = observations[np.isfinite(observations)]
    if len(finite) < MINIMUM_METRIC_DAYS:
        raise ValueError(f"fit observations must contain at least {MINIMUM_METRIC_DAYS} finite values")
    low, high = np.quantile(
        finite,
        [float(low_quantile), float(high_quantile)],
        method="linear",
    )
    return FlowThresholds(
        low=float(low),
        high=float(high),
        fit_count=int(len(finite)),
        low_quantile=float(low_quantile),
        high_quantile=float(high_quantile),
    )


def build_regime_masks(observations: Any, thresholds: FlowThresholds) -> dict[str, np.ndarray]:
    """Apply frozen absolute thresholds without recomputing quantiles."""

    if not isinstance(thresholds, FlowThresholds):
        raise TypeError("thresholds must be a FlowThresholds instance")
    values = _validate_observations(observations)
    finite = np.isfinite(values)
    return {
        "all_flow": finite,
        "low_flow": finite & (values <= thresholds.low),
        "high_flow": finite & (values >= thresholds.high),
    }


def _validate_continuous_inputs(
    rain: Any,
    pet: Any,
    temperature: Any,
    observations: Any,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    rain_values = _as_one_dimensional_float(rain, "rain")
    pet_values = _as_one_dimensional_float(pet, "pet")
    temperature_values = _as_one_dimensional_float(temperature, "temperature")
    observation_values = _validate_observations(observations)
    lengths = {
        len(rain_values),
        len(pet_values),
        len(temperature_values),
        len(observation_values),
    }
    if len(lengths) != 1:
        raise ValueError("forcing and observation arrays must have identical lengths")
    if len(observation_values) == 0:
        raise ValueError("continuous series must not be empty")
    for values, name in (
        (rain_values, "rain"),
        (pet_values, "pet"),
        (temperature_values, "temperature"),
    ):
        if not np.all(np.isfinite(values)):
            raise ValueError(f"{name} must contain only finite values")
    if np.any(rain_values < 0.0) or np.any(pet_values < 0.0):
        raise ValueError("rain and potential evapotranspiration must be nonnegative")
    return rain_values, pet_values, temperature_values, observation_values


def calibrate_parameter_sets(
    rain: Any,
    pet: Any,
    temperature: Any,
    observations: Any,
    fit_mask: Any,
    thresholds: FlowThresholds,
    *,
    n_trials: int = 5000,
    n_restarts: int = 3,
    restart_seeds: Sequence[int] | None = None,
    state_init: Mapping[str, float] | None = None,
    param_bounds: Mapping[str, tuple[float, float]] | None = None,
    lag_kernel: str = "rising",
    flow_log_offset_mm_day: float = 0.01,
    init_mean_norm: float | None = None,
    init_sigma: float = 0.3,
    telemetry_collectors: Mapping[str, list[dict[str, Any]]] | None = None,
) -> dict[str, dict[str, Any]]:
    """Calibrate all-flow, low-flow, and high-flow fixed parameter vectors.

    Every calibration receives the complete continuous warmup-plus-fit prefix.
    Dates after the final fit day are hard-truncated before the calibrator is
    called; within the retained prefix, the regime masks narrow which fit dates
    contribute to each objective.
    """

    rain_complete = _as_one_dimensional_float(rain, "rain")
    pet_complete = _as_one_dimensional_float(pet, "pet")
    temperature_complete = _as_one_dimensional_float(temperature, "temperature")
    observations_complete = _as_one_dimensional_float(observations, "observations")
    complete_lengths = {
        len(rain_complete),
        len(pet_complete),
        len(temperature_complete),
        len(observations_complete),
    }
    if len(complete_lengths) != 1:
        raise ValueError("forcing and observation arrays must have identical lengths")
    if len(observations_complete) == 0:
        raise ValueError("continuous series must not be empty")
    if not isinstance(thresholds, FlowThresholds):
        raise TypeError("thresholds must be a FlowThresholds instance")
    fit_complete = _as_boolean_mask(fit_mask, len(observations_complete), "fit_mask")
    if int(n_trials) <= 0:
        raise ValueError("n_trials must be positive")
    if int(n_restarts) <= 0:
        raise ValueError("n_restarts must be positive")
    if restart_seeds is not None:
        seeds = tuple(int(seed) for seed in restart_seeds)
        if len(seeds) != int(n_restarts):
            raise ValueError("restart_seeds length must equal n_restarts")
        if len(set(seeds)) != len(seeds):
            raise ValueError("restart_seeds must be unique")
    else:
        seeds = None
    if not np.isfinite(flow_log_offset_mm_day) or float(flow_log_offset_mm_day) <= 0.0:
        raise ValueError("flow_log_offset_mm_day must be finite and positive")
    if telemetry_collectors is not None:
        if (
            not isinstance(telemetry_collectors, Mapping)
            or set(telemetry_collectors) != set(OBJECTIVES)
            or any(not isinstance(telemetry_collectors[name], list) for name in OBJECTIVES)
        ):
            raise ValueError(
                "telemetry_collectors must map exactly all_flow, low_flow, and high_flow to lists"
            )

    fit_indices = np.flatnonzero(fit_complete)
    if len(fit_indices) == 0:
        raise ValueError("fit_mask must select at least one date")
    calibration_stop = int(fit_indices[-1]) + 1
    rain_values, pet_values, temperature_values, observation_values = _validate_continuous_inputs(
        rain_complete[:calibration_stop],
        pet_complete[:calibration_stop],
        temperature_complete[:calibration_stop],
        observations_complete[:calibration_stop],
    )
    fit = fit_complete[:calibration_stop]
    regime_masks = build_regime_masks(observation_values, thresholds)
    objective_masks = {name: fit & regime_masks[name] for name in OBJECTIVES}
    for name, mask in objective_masks.items():
        if int(mask.sum()) < MINIMUM_METRIC_DAYS:
            raise ValueError(
                f"{name} fit objective must contain at least {MINIMUM_METRIC_DAYS} finite observations"
            )

    # The optimizer receives only the continuous warmup-plus-fit prefix.  The
    # objective mask protects the warmup dates inside that prefix, while this
    # hard truncation prevents validation observations from entering the
    # calibration function at all.
    results: dict[str, dict[str, Any]] = {}
    for name, loss in OBJECTIVES.items():
        calibration_options = {
            "n_trials": int(n_trials),
            "n_restarts": int(n_restarts),
            "state_init": None if state_init is None else dict(state_init),
            "loss": loss,
            "init_mean_norm": init_mean_norm,
            "init_sigma": float(init_sigma),
            "param_bounds": None if param_bounds is None else dict(param_bounds),
            "lag_kernel": lag_kernel,
            "objective_mask": objective_masks[name],
            "flow_log_offset_mm_day": float(flow_log_offset_mm_day),
            "restart_seeds": seeds,
        }
        if telemetry_collectors is not None:
            calibration_options["telemetry_collector"] = telemetry_collectors[name]
        result = calibrate_hbv_lite_cma(
            rain_values,
            pet_values,
            temperature_values,
            observation_values,
            **calibration_options,
        )
        if not isinstance(result, Mapping):
            raise TypeError(f"{name} calibrator result must be a mapping")
        copied = dict(result)
        parameters = copied.get("optimized_params")
        if not isinstance(parameters, Mapping) or not parameters:
            raise ValueError(f"{name} calibration did not return optimized_params")
        copied["parameter_set"] = name
        copied["fit_loss"] = loss
        copied["fit_objective_days"] = int(objective_masks[name].sum())
        results[name] = copied
    return results


def _mapping_value(mapping: Mapping[str, Any], aliases: Sequence[str], label: str) -> Any:
    for alias in aliases:
        if alias in mapping:
            return mapping[alias]
    raise KeyError(f"forcing is missing {label}; expected one of {list(aliases)}")


def _coerce_dates(values: Any, length: int) -> pd.DatetimeIndex | None:
    if values is None:
        return None
    dates = pd.DatetimeIndex(pd.to_datetime(values))
    if len(dates) != length:
        raise ValueError(f"dates must have length {length}")
    if dates.hasnans:
        raise ValueError("dates must not contain missing values")
    if dates.has_duplicates:
        raise ValueError("dates must not contain duplicates")
    if not dates.is_monotonic_increasing:
        raise ValueError("dates must be monotonically increasing")
    return dates


def _coerce_forcing(
    forcing: Any,
    dates: Any = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, pd.DatetimeIndex | None]:
    inferred_dates = None
    if isinstance(forcing, pd.DataFrame):
        rain = _mapping_value(forcing, ("rain", "prcp", "precipitation"), "rain")
        pet = _mapping_value(
            forcing,
            ("pet", "ep", "potential_evapotranspiration", "potential_evaporation"),
            "potential evapotranspiration",
        )
        temperature = _mapping_value(forcing, ("temp", "temperature", "tmean"), "temperature")
        if isinstance(forcing.index, pd.DatetimeIndex):
            inferred_dates = forcing.index
    elif isinstance(forcing, Mapping):
        rain = _mapping_value(forcing, ("rain", "prcp", "precipitation"), "rain")
        pet = _mapping_value(
            forcing,
            ("pet", "ep", "potential_evapotranspiration", "potential_evaporation"),
            "potential evapotranspiration",
        )
        temperature = _mapping_value(forcing, ("temp", "temperature", "tmean"), "temperature")
        inferred_dates = forcing.get("dates", forcing.get("date"))
    else:
        array = np.asarray(forcing)
        if array.ndim == 2 and array.shape[1] == 3:
            rain, pet, temperature = array[:, 0], array[:, 1], array[:, 2]
        elif isinstance(forcing, Sequence) and len(forcing) == 3:
            rain, pet, temperature = forcing
        else:
            raise TypeError("forcing must be a DataFrame, mapping, three-array sequence, or n-by-3 array")
    rain_values = _as_one_dimensional_float(rain, "rain")
    pet_values = _as_one_dimensional_float(pet, "pet")
    temperature_values = _as_one_dimensional_float(temperature, "temperature")
    if len({len(rain_values), len(pet_values), len(temperature_values)}) != 1:
        raise ValueError("forcing arrays must have identical lengths")
    date_index = _coerce_dates(dates if dates is not None else inferred_dates, len(rain_values))
    return rain_values, pet_values, temperature_values, date_index


def _nash_sutcliffe_efficiency(observed: np.ndarray, simulated: np.ndarray, mask: np.ndarray) -> float:
    valid = mask & np.isfinite(observed) & np.isfinite(simulated)
    if int(valid.sum()) < MINIMUM_METRIC_DAYS:
        return float("nan")
    obs = observed[valid]
    sim = simulated[valid]
    denominator = float(np.sum(np.square(obs - np.mean(obs))))
    if denominator <= 0.0:
        return float("nan")
    return float(1.0 - np.sum(np.square(sim - obs)) / denominator)


def _mean_square_error(
    observed: np.ndarray,
    simulated: np.ndarray,
    mask: np.ndarray,
    minimum_days: int = MINIMUM_METRIC_DAYS,
) -> float:
    valid = mask & np.isfinite(observed) & np.isfinite(simulated)
    if int(valid.sum()) < int(minimum_days):
        return float("nan")
    return float(np.mean(np.square(simulated[valid] - observed[valid])))


def _log_mean_square_error(
    observed: np.ndarray,
    simulated: np.ndarray,
    mask: np.ndarray,
    offset: float,
    minimum_days: int = MINIMUM_METRIC_DAYS,
) -> float:
    valid = mask & np.isfinite(observed) & np.isfinite(simulated)
    if int(valid.sum()) < int(minimum_days):
        return float("nan")
    obs = observed[valid]
    sim = np.maximum(simulated[valid], 0.0)
    return float(np.mean(np.square(np.log(sim + offset) - np.log(obs + offset))))


def _water_years(dates: pd.DatetimeIndex) -> np.ndarray:
    return dates.year.to_numpy(dtype=np.int64) + (dates.month.to_numpy(dtype=np.int64) >= 10)


def regime_water_year_coverage(
    dates: Any,
    observations: Any,
    period_mask: Any,
    thresholds: FlowThresholds,
    minimum_days: int,
) -> dict[str, Any]:
    """Count low- and high-flow evidence in every represented water year.

    A water year is October through September and is labelled by its ending
    calendar year.  Every year touched by ``period_mask`` is retained even if
    all observations are missing or one regime has no target dates.
    """

    observation_values = _validate_observations(observations)
    date_index = _coerce_dates(dates, len(observation_values))
    if date_index is None:
        raise ValueError("dates are required for water-year coverage")
    period = _as_boolean_mask(period_mask, len(observation_values), "period_mask")
    if isinstance(minimum_days, (bool, np.bool_)) or not isinstance(minimum_days, (int, np.integer)):
        raise ValueError("minimum_days must be a positive integer")
    if int(minimum_days) < 1:
        raise ValueError("minimum_days must be a positive integer")
    if not isinstance(thresholds, FlowThresholds):
        raise TypeError("thresholds must be a FlowThresholds instance")

    regime_masks = build_regime_masks(observation_values, thresholds)
    finite = np.isfinite(observation_values)
    year_labels = _water_years(date_index)
    records = []
    for water_year in np.unique(year_labels[period]):
        year_mask = period & (year_labels == water_year)
        low_flow_days = int(np.sum(year_mask & regime_masks["low_flow"]))
        high_flow_days = int(np.sum(year_mask & regime_masks["high_flow"]))
        low_sufficient = low_flow_days >= int(minimum_days)
        high_sufficient = high_flow_days >= int(minimum_days)
        records.append({
            "water_year": int(water_year),
            "period_days": int(year_mask.sum()),
            "finite_observation_days": int(np.sum(year_mask & finite)),
            "low_flow_days": low_flow_days,
            "high_flow_days": high_flow_days,
            "low_flow_sufficient": bool(low_sufficient),
            "high_flow_sufficient": bool(high_sufficient),
            "evidence_sufficient": bool(low_sufficient and high_sufficient),
        })
    return {
        "minimum_days": int(minimum_days),
        "water_years": records,
        "evidence_sufficient": bool(records and all(record["evidence_sufficient"] for record in records)),
    }


def apply_regime_coverage_policy(
    coverage: Mapping[str, Any],
    *,
    minimum_total_target_days: int,
    minimum_qualifying_water_years: int,
    expected_water_years: int,
) -> dict[str, Any]:
    """Apply one aggregate-and-multi-year rule to both flow regimes.

    The input retains the original per-water-year counts.  Eligibility is
    recomputed independently for low and high flow; stored boolean summaries
    are never trusted as inputs to the decision.
    """

    if not isinstance(coverage, Mapping):
        raise TypeError("coverage must be a mapping")
    integer_values = {
        "minimum_total_target_days": minimum_total_target_days,
        "minimum_qualifying_water_years": minimum_qualifying_water_years,
        "expected_water_years": expected_water_years,
    }
    for name, value in integer_values.items():
        if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)):
            raise ValueError(f"{name} must be a positive integer")
        if int(value) < 1:
            raise ValueError(f"{name} must be a positive integer")
    minimum_days = coverage.get("minimum_days")
    if (
        isinstance(minimum_days, (bool, np.bool_))
        or not isinstance(minimum_days, (int, np.integer))
        or int(minimum_days) < 1
    ):
        raise ValueError("coverage minimum_days must be a positive integer")
    raw_records = coverage.get("water_years")
    if not isinstance(raw_records, Sequence) or isinstance(raw_records, (str, bytes)):
        raise ValueError("coverage water_years must be a sequence")
    if len(raw_records) != int(expected_water_years):
        raise ValueError("coverage water-year count differs from expected_water_years")

    normalized_records = []
    observed_years: set[int] = set()
    for position, raw_record in enumerate(raw_records):
        if not isinstance(raw_record, Mapping):
            raise ValueError(f"coverage water_years[{position}] must be a mapping")
        year = raw_record.get("water_year")
        if isinstance(year, (bool, np.bool_)) or not isinstance(year, (int, np.integer)):
            raise ValueError(f"coverage water_years[{position}] water_year must be an integer")
        year = int(year)
        if year in observed_years:
            raise ValueError("coverage water years must be unique")
        observed_years.add(year)
        counts: dict[str, int] = {}
        for name in ("low_flow_days", "high_flow_days"):
            value = raw_record.get(name)
            if (
                isinstance(value, (bool, np.bool_))
                or not isinstance(value, (int, np.integer))
                or int(value) < 0
            ):
                raise ValueError(f"coverage water_years[{position}] {name} must be a nonnegative integer")
            counts[name] = int(value)
        low_sufficient = counts["low_flow_days"] >= int(minimum_days)
        high_sufficient = counts["high_flow_days"] >= int(minimum_days)
        normalized = dict(raw_record)
        normalized.update({
            "water_year": year,
            **counts,
            "low_flow_sufficient": bool(low_sufficient),
            "high_flow_sufficient": bool(high_sufficient),
            "evidence_sufficient": bool(low_sufficient and high_sufficient),
        })
        normalized_records.append(normalized)

    low_total = sum(record["low_flow_days"] for record in normalized_records)
    high_total = sum(record["high_flow_days"] for record in normalized_records)
    low_qualifying_years = sum(int(record["low_flow_sufficient"]) for record in normalized_records)
    high_qualifying_years = sum(int(record["high_flow_sufficient"]) for record in normalized_records)
    low_sufficient = bool(
        low_total >= int(minimum_total_target_days)
        and low_qualifying_years >= int(minimum_qualifying_water_years)
    )
    high_sufficient = bool(
        high_total >= int(minimum_total_target_days)
        and high_qualifying_years >= int(minimum_qualifying_water_years)
    )
    return {
        **dict(coverage),
        "water_years": normalized_records,
        "coverage_policy": {
            "minimum_total_target_days": int(minimum_total_target_days),
            "minimum_qualifying_water_years": int(minimum_qualifying_water_years),
            "expected_water_years": int(expected_water_years),
        },
        "low_flow_total_days": int(low_total),
        "high_flow_total_days": int(high_total),
        "low_flow_qualifying_water_years": int(low_qualifying_years),
        "high_flow_qualifying_water_years": int(high_qualifying_years),
        "low_flow_evidence_sufficient": low_sufficient,
        "high_flow_evidence_sufficient": high_sufficient,
        "evidence_sufficient": bool(low_sufficient and high_sufficient),
    }


def _validated_parameter_values_and_bounds(
    parameters: Mapping[str, Any],
    parameter_bounds: Mapping[str, Sequence[float]],
    label: str,
) -> tuple[dict[str, float], dict[str, tuple[float, float]]]:
    if not isinstance(parameters, Mapping) or not parameters:
        raise ValueError(f"{label} must be a nonempty parameter mapping")
    if not isinstance(parameter_bounds, Mapping) or not parameter_bounds:
        raise ValueError("parameter_bounds must be a nonempty mapping")
    missing = [str(name) for name in parameter_bounds if name not in parameters]
    extra = [str(name) for name in parameters if name not in parameter_bounds]
    if missing or extra:
        raise ValueError(f"{label} and parameter_bounds must have identical keys; missing={missing}, extra={extra}")

    values: dict[str, float] = {}
    bounds: dict[str, tuple[float, float]] = {}
    for raw_name, raw_bound in parameter_bounds.items():
        name = str(raw_name)
        if isinstance(raw_bound, (str, bytes)) or not isinstance(raw_bound, Sequence) or len(raw_bound) != 2:
            raise ValueError(f"parameter bound for {name} must contain exactly two values")
        lower, upper = float(raw_bound[0]), float(raw_bound[1])
        value = float(parameters[raw_name])
        if not (np.isfinite(lower) and np.isfinite(upper) and lower < upper):
            raise ValueError(f"parameter bound for {name} must be finite and strictly ordered")
        if not np.isfinite(value):
            raise ValueError(f"{label} value for {name} must be finite")
        if value < lower or value > upper:
            raise ValueError(f"{label} value for {name} must lie inside its configured bounds")
        values[name] = value
        bounds[name] = (lower, upper)
    return values, bounds


def parameter_boundary_diagnostics(
    parameters: Mapping[str, Any],
    parameter_bounds: Mapping[str, Sequence[float]],
) -> dict[str, Any]:
    """Diagnose normalized proximity to the lower or upper parameter bound."""

    values, bounds = _validated_parameter_values_and_bounds(parameters, parameter_bounds, "parameters")
    diagnostics: dict[str, dict[str, Any]] = {}
    near_boundary_parameters = []
    strongly_saturated_parameters = []
    near_boundary_sides: dict[str, str] = {}
    for name, (lower, upper) in bounds.items():
        width = upper - lower
        lower_distance = (values[name] - lower) / width
        upper_distance = (upper - values[name]) / width
        nearest_boundary = "lower" if lower_distance <= upper_distance else "upper"
        normalized_distance = float(min(lower_distance, upper_distance))
        near_boundary = normalized_distance <= 0.01
        strongly_saturated = normalized_distance <= 0.001
        diagnostics[name] = {
            "value": values[name],
            "lower_bound": lower,
            "upper_bound": upper,
            "normalized_boundary_distance": normalized_distance,
            "nearest_boundary": nearest_boundary,
            "near_boundary": bool(near_boundary),
            "strongly_saturated": bool(strongly_saturated),
        }
        if near_boundary:
            near_boundary_parameters.append(name)
            near_boundary_sides[name] = nearest_boundary
        if strongly_saturated:
            strongly_saturated_parameters.append(name)
    return {
        "near_boundary_parameters": near_boundary_parameters,
        "near_boundary_count": len(near_boundary_parameters),
        "strongly_saturated_parameters": strongly_saturated_parameters,
        "strongly_saturated_count": len(strongly_saturated_parameters),
        "near_boundary_sides": near_boundary_sides,
        "parameter_diagnostics": diagnostics,
    }


def normalized_parameter_distance(
    first_parameters: Mapping[str, Any],
    second_parameters: Mapping[str, Any],
    parameter_bounds: Mapping[str, Sequence[float]],
) -> float:
    """Return root-mean-square parameter distance after bound-width scaling."""

    first, bounds = _validated_parameter_values_and_bounds(
        first_parameters,
        parameter_bounds,
        "first_parameters",
    )
    second, _ = _validated_parameter_values_and_bounds(
        second_parameters,
        parameter_bounds,
        "second_parameters",
    )
    squared = [((first[name] - second[name]) / (upper - lower)) ** 2 for name, (lower, upper) in bounds.items()]
    return float(np.sqrt(np.mean(squared)))


def output_functional_distance(
    selected: Any,
    restart: Any,
    observations: Any,
    fit_scale_mask: Any,
    validation_compare_mask: Any,
    *,
    transform: str,
    log_offset: float | None,
    maximum_distance: float,
) -> dict[str, Any]:
    """Compare two daily trajectories using a fit-scaled validation distance.

    The reducer deliberately has no access to parameter coordinates, dates or
    configuration globals.  Multi-water-year coverage is therefore an outer
    quality-gate responsibility rather than something inferred from masks.
    """

    selected_values = _as_one_dimensional_float(selected, "selected")
    restart_values = _as_one_dimensional_float(restart, "restart")
    observation_values = _validate_observations(observations)
    lengths = {len(selected_values), len(restart_values), len(observation_values)}
    if len(lengths) != 1:
        raise ValueError("selected, restart, and observations must have identical lengths")
    if not np.all(np.isfinite(selected_values)) or not np.all(np.isfinite(restart_values)):
        raise ValueError("selected and restart predictions must contain only finite values")
    if np.any(selected_values < 0.0) or np.any(restart_values < 0.0):
        raise ValueError("selected and restart predictions must be nonnegative")

    fit_scale = _as_boolean_mask(
        fit_scale_mask,
        len(observation_values),
        "fit_scale_mask",
    )
    validation_compare = _as_boolean_mask(
        validation_compare_mask,
        len(observation_values),
        "validation_compare_mask",
    )
    fit_count = int(fit_scale.sum())
    validation_count = int(validation_compare.sum())
    if fit_count == 0:
        raise ValueError("fit_scale_mask must select at least one date")
    if validation_count == 0:
        raise ValueError("validation_compare_mask must select at least one date")
    if not np.all(np.isfinite(observation_values[fit_scale])):
        raise ValueError("fit-scale observations must contain only finite values")

    if isinstance(maximum_distance, (bool, np.bool_)):
        raise ValueError("maximum_distance must be finite and nonnegative")
    maximum = float(maximum_distance)
    if not np.isfinite(maximum) or maximum < 0.0:
        raise ValueError("maximum_distance must be finite and nonnegative")

    if transform == "identity":
        if log_offset is not None:
            raise ValueError("log_offset must be None for the identity transform")

        def transform_values(values: np.ndarray) -> np.ndarray:
            return values

        recorded_offset = None
    elif transform == "log_q_plus_offset":
        if isinstance(log_offset, (bool, np.bool_)) or log_offset is None:
            raise ValueError("log_offset must be finite and positive for log_q_plus_offset")
        recorded_offset = float(log_offset)
        if not np.isfinite(recorded_offset) or recorded_offset <= 0.0:
            raise ValueError("log_offset must be finite and positive for log_q_plus_offset")

        def transform_values(values: np.ndarray) -> np.ndarray:
            return np.log(values + recorded_offset)

    else:
        raise ValueError("transform must be 'identity' or 'log_q_plus_offset'")

    transformed_fit_observations = transform_values(observation_values[fit_scale])
    transformed_selected = transform_values(selected_values[validation_compare])
    transformed_restart = transform_values(restart_values[validation_compare])
    denominator = float(np.var(transformed_fit_observations, ddof=0))
    if not np.isfinite(denominator) or denominator <= 0.0:
        raise ValueError("fit-scale transformed observation variance must be finite and positive")
    numerator = float(np.mean((transformed_restart - transformed_selected) ** 2))
    distance = float(numerator / denominator)
    if not np.isfinite(numerator) or numerator < 0.0 or not np.isfinite(distance):
        raise ValueError("output functional distance components must be finite and nonnegative")
    return {
        "numerator": numerator,
        "denominator": denominator,
        "distance": distance,
        "fit_scale_count": fit_count,
        "validation_compare_count": validation_count,
        "transform": transform,
        "log_offset": recorded_offset,
        "maximum_distance": maximum,
        "passes": bool(distance <= maximum),
    }


def _absolute_validation_metrics(
    observations: np.ndarray,
    simulated: np.ndarray,
    validation_mask: np.ndarray,
    regime_masks: Mapping[str, np.ndarray],
    thresholds: FlowThresholds,
    dates: pd.DatetimeIndex | None,
    flow_log_offset_mm_day: float,
    minimum_target_days_per_water_year: int,
    target_state_coverage_policy: Mapping[str, int] | None,
) -> dict[str, Any]:
    finite_simulation = np.isfinite(simulated)
    valid = validation_mask & np.isfinite(observations) & finite_simulation
    low = valid & regime_masks["low_flow"]
    high = valid & regime_masks["high_flow"]
    metrics: dict[str, Any] = {
        "validation_days": int(valid.sum()),
        "low_flow_days": int(low.sum()),
        "high_flow_days": int(high.sum()),
        "all_period_nse": _nash_sutcliffe_efficiency(observations, simulated, valid),
        "low_flow_log_mse": _log_mean_square_error(
            observations,
            simulated,
            low,
            flow_log_offset_mm_day,
        ),
        "high_flow_raw_mse": _mean_square_error(observations, simulated, high),
        "water_year_metrics": {},
    }
    if dates is not None:
        coverage = regime_water_year_coverage(
            dates,
            observations,
            validation_mask,
            thresholds,
            minimum_target_days_per_water_year,
        )
        if target_state_coverage_policy is not None:
            coverage = apply_regime_coverage_policy(
                coverage,
                **dict(target_state_coverage_policy),
            )
        metrics["regime_water_year_coverage"] = coverage
        metrics["evidence_sufficient"] = bool(coverage["evidence_sufficient"])
        year_labels = _water_years(dates)
        for water_year in np.unique(year_labels[validation_mask]):
            year_mask = validation_mask & (year_labels == water_year)
            year_low = year_mask & low
            year_high = year_mask & high
            metrics["water_year_metrics"][str(int(water_year))] = {
                "low_flow_days": int(year_low.sum()),
                "high_flow_days": int(year_high.sum()),
                "low_flow_log_mse": _log_mean_square_error(
                    observations,
                    simulated,
                    year_low,
                    flow_log_offset_mm_day,
                    minimum_target_days_per_water_year,
                ),
                "high_flow_raw_mse": _mean_square_error(
                    observations,
                    simulated,
                    year_high,
                    minimum_target_days_per_water_year,
                ),
            }
    else:
        metrics["regime_water_year_coverage"] = None
        metrics["evidence_sufficient"] = False
    return metrics


def _parameter_set_evidence_sufficient(
    metrics: Mapping[str, Any],
    parameter_set: str,
) -> bool:
    """Use state-specific coverage for specialists under the v02 policy."""

    coverage = metrics.get("regime_water_year_coverage")
    if not isinstance(coverage, Mapping) or "coverage_policy" not in coverage:
        return bool(metrics.get("evidence_sufficient", False))
    key = {
        "all_flow": "evidence_sufficient",
        "low_flow": "low_flow_evidence_sufficient",
        "high_flow": "high_flow_evidence_sufficient",
    }[parameter_set]
    value = coverage.get(key)
    if not isinstance(value, (bool, np.bool_)):
        raise ValueError(f"coverage {key} must be boolean")
    return bool(value)


def _extract_parameter_contract(
    record: Mapping[str, Any],
    name: str,
) -> tuple[dict[str, float], list[Mapping[str, Any]]]:
    if "optimized_params" in record:
        selected = record["optimized_params"]
        restart_records = record.get("restart_records", [])
    else:
        selected = record
        restart_records = []
    if not isinstance(selected, Mapping) or not selected:
        raise ValueError(f"{name} must contain a nonempty parameter mapping")
    parameters = {str(key): float(value) for key, value in selected.items()}
    if any(not np.isfinite(value) for value in parameters.values()):
        raise ValueError(f"{name} parameters must be finite")
    if not isinstance(restart_records, Sequence) or isinstance(restart_records, (str, bytes)):
        raise ValueError(f"{name} restart_records must be a sequence")
    return parameters, list(restart_records)


def _parameter_fingerprint(parameters: Mapping[str, float]) -> tuple[tuple[str, float], ...]:
    return tuple(sorted((str(name), float(value)) for name, value in parameters.items()))


def _relative_improvement(reference: float, candidate: float) -> float:
    if not np.isfinite(reference) or not np.isfinite(candidate):
        return float("nan")
    if reference == 0.0:
        return 0.0 if candidate == 0.0 else float("-inf")
    return float((reference - candidate) / abs(reference))


def _relative_increase(reference: float, candidate: float) -> float:
    if not np.isfinite(reference) or not np.isfinite(candidate):
        return float("nan")
    if reference == 0.0:
        return 0.0 if candidate == 0.0 else float("inf")
    return float((candidate - reference) / abs(reference))


def _add_specialist_comparison(
    specialist: dict[str, Any],
    general: Mapping[str, Any],
    other_specialist: Mapping[str, Any],
    target_key: str,
    opposite_key: str,
) -> None:
    """Attach generalist-relative metrics without selecting on validation."""

    specialist["target_metric"] = target_key
    specialist["opposite_regime_metric"] = opposite_key
    specialist["target_relative_improvement"] = _relative_improvement(
        float(general[target_key]),
        float(specialist[target_key]),
    )
    specialist["opposite_regime_loss_increase"] = _relative_increase(
        float(general[opposite_key]),
        float(specialist[opposite_key]),
    )
    specialist["all_period_nse_drop"] = float(
        general["all_period_nse"] - specialist["all_period_nse"]
    )
    specialist["opposite_regime_relative_degradation"] = specialist["opposite_regime_loss_increase"]
    specialist["all_flow_nse_drop"] = specialist["all_period_nse_drop"]
    specialist["target_loss_beats_other_specialist"] = bool(
        np.isfinite(specialist[target_key])
        and np.isfinite(other_specialist[target_key])
        and specialist[target_key] < other_specialist[target_key]
    )
    year_comparisons = []
    general_years = general["water_year_metrics"]
    specialist_years = specialist["water_year_metrics"]
    for water_year in sorted(set(general_years) & set(specialist_years)):
        general_loss = float(general_years[water_year][target_key])
        specialist_loss = float(specialist_years[water_year][target_key])
        if np.isfinite(general_loss) and np.isfinite(specialist_loss):
            year_comparisons.append({
                "water_year": int(water_year),
                "generalist_loss": general_loss,
                "specialist_loss": specialist_loss,
                "improved": bool(specialist_loss < general_loss),
            })
    specialist["water_year_target_comparison"] = year_comparisons
    specialist["valid_water_years"] = len(year_comparisons)
    specialist["improved_water_years"] = sum(record["improved"] for record in year_comparisons)


def evaluate_parameter_sets(
    forcing: Any,
    observations: Any,
    validation_mask: Any,
    thresholds: FlowThresholds,
    parameter_sets: Mapping[str, Mapping[str, Any]],
    *,
    dates: Any = None,
    initial_state: Mapping[str, float] | None = None,
    lag_kernel: str = "rising",
    flow_log_offset_mm_day: float = 0.01,
    minimum_target_days_per_water_year: int = MINIMUM_METRIC_DAYS,
    target_state_coverage_policy: Mapping[str, int] | None = None,
    fit_mask: Any = None,
    output_functional_distance_max: float | None = None,
    include_restart_simulations: bool = False,
) -> dict[str, dict[str, Any]]:
    """Continuously replay every fit-selected parameter set on validation.

    ``parameter_sets`` may be the direct output of
    :func:`calibrate_parameter_sets` or a mapping of names to plain parameter
    dictionaries.  If restart records are available, every restart is also
    replayed for audit, but validation never changes ``selected_params``.
    """

    rain, pet, temperature, date_index = _coerce_forcing(forcing, dates=dates)
    rain, pet, temperature, observation_values = _validate_continuous_inputs(
        rain,
        pet,
        temperature,
        observations,
    )
    validation = _as_boolean_mask(validation_mask, len(observation_values), "validation_mask")
    if int(validation.sum()) < MINIMUM_METRIC_DAYS:
        raise ValueError(f"validation_mask must select at least {MINIMUM_METRIC_DAYS} dates")
    if not np.isfinite(flow_log_offset_mm_day) or float(flow_log_offset_mm_day) <= 0.0:
        raise ValueError("flow_log_offset_mm_day must be finite and positive")
    if (
        isinstance(minimum_target_days_per_water_year, (bool, np.bool_))
        or not isinstance(minimum_target_days_per_water_year, (int, np.integer))
        or int(minimum_target_days_per_water_year) < 1
    ):
        raise ValueError("minimum_target_days_per_water_year must be a positive integer")
    if not isinstance(parameter_sets, Mapping):
        raise TypeError("parameter_sets must be a mapping")
    if not isinstance(include_restart_simulations, (bool, np.bool_)):
        raise ValueError("include_restart_simulations must be boolean")
    functional_distance_enabled = fit_mask is not None or output_functional_distance_max is not None
    if (fit_mask is None) != (output_functional_distance_max is None):
        raise ValueError(
            "fit_mask and output_functional_distance_max must be supplied together"
        )
    functional_fit_mask = None
    functional_distance_maximum = None
    if functional_distance_enabled:
        functional_fit_mask = _as_boolean_mask(
            fit_mask,
            len(observation_values),
            "fit_mask",
        )
        if isinstance(output_functional_distance_max, (bool, np.bool_)):
            raise ValueError("output_functional_distance_max must be finite and nonnegative")
        functional_distance_maximum = float(output_functional_distance_max)
        if not np.isfinite(functional_distance_maximum) or functional_distance_maximum < 0.0:
            raise ValueError("output_functional_distance_max must be finite and nonnegative")
    if target_state_coverage_policy is not None:
        required_policy_fields = {
            "minimum_total_target_days",
            "minimum_qualifying_water_years",
            "expected_water_years",
        }
        if (
            not isinstance(target_state_coverage_policy, Mapping)
            or set(target_state_coverage_policy) != required_policy_fields
        ):
            raise ValueError(
                "target_state_coverage_policy must contain exactly the aggregate coverage fields"
            )
    missing = [name for name in OBJECTIVES if name not in parameter_sets]
    if missing:
        raise ValueError(f"parameter_sets is missing required entries: {missing}")

    regime_masks = build_regime_masks(observation_values, thresholds)
    evaluations: dict[str, dict[str, Any]] = {}
    for name in OBJECTIVES:
        raw_record = parameter_sets[name]
        if not isinstance(raw_record, Mapping):
            raise TypeError(f"{name} parameter record must be a mapping")
        selected_params, restart_records = _extract_parameter_contract(raw_record, name)
        selected_fingerprint = _parameter_fingerprint(selected_params)
        cached_metrics: dict[tuple[tuple[str, float], ...], tuple[dict[str, Any], np.ndarray, Any]] = {}
        restart_metrics = []
        restart_simulations = []

        def replay(parameters: Mapping[str, float]) -> tuple[dict[str, Any], np.ndarray, Any]:
            fingerprint = _parameter_fingerprint(parameters)
            if fingerprint not in cached_metrics:
                simulated, final_state = simulate_hbv_lite(
                    rain,
                    pet,
                    temperature,
                    dict(parameters),
                    initial_state=None if initial_state is None else dict(initial_state),
                    lag_kernel=lag_kernel,
                )
                simulated_values = _as_one_dimensional_float(simulated, f"{name} simulated discharge")
                if simulated_values.shape != observation_values.shape:
                    raise ValueError(f"{name} simulation must preserve the complete trajectory length")
                if not np.all(np.isfinite(simulated_values)):
                    raise ValueError(f"{name} simulation must contain only finite values")
                absolute = _absolute_validation_metrics(
                    observation_values,
                    simulated_values,
                    validation,
                    regime_masks,
                    thresholds,
                    date_index,
                    float(flow_log_offset_mm_day),
                    int(minimum_target_days_per_water_year),
                    target_state_coverage_policy,
                )
                cached_metrics[fingerprint] = (absolute, simulated_values.copy(), final_state)
            return cached_metrics[fingerprint]

        for restart in restart_records:
            if not isinstance(restart, Mapping):
                raise ValueError(f"{name} restart record must be a mapping")
            restart_parameters = restart.get("optimized_params")
            if not isinstance(restart_parameters, Mapping) or not restart_parameters:
                raise ValueError(f"{name} restart record must contain optimized_params")
            numeric_parameters = {str(key): float(value) for key, value in restart_parameters.items()}
            absolute, restart_simulation, _ = replay(numeric_parameters)
            parameter_absolute = dict(absolute)
            parameter_absolute["evidence_sufficient"] = _parameter_set_evidence_sufficient(
                absolute,
                name,
            )
            restart_metric = {
                "restart_index": int(restart.get("restart_index", len(restart_metrics))),
                "seed": int(restart["seed"]) if restart.get("seed") is not None else None,
                "fit_objective_loss": float(restart.get("objective_loss", float("nan"))),
                "optimized_params": numeric_parameters,
                **parameter_absolute,
            }
            if include_restart_simulations:
                restart_metric["simulated_flow"] = restart_simulation.copy()
            restart_metrics.append(restart_metric)
            restart_simulations.append(restart_simulation)

        selected_absolute, selected_simulation, selected_final_state = replay(selected_params)
        parameter_absolute = dict(selected_absolute)
        parameter_absolute["evidence_sufficient"] = _parameter_set_evidence_sufficient(
            selected_absolute,
            name,
        )
        if functional_distance_enabled:
            transforms = {
                "all_flow": ("identity", None),
                "low_flow": ("log_q_plus_offset", float(flow_log_offset_mm_day)),
                "high_flow": ("identity", None),
            }
            for restart_metric, restart_simulation in zip(
                restart_metrics,
                restart_simulations,
                strict=True,
            ):
                restart_metric["output_functional_distances"] = {
                    day_set: output_functional_distance(
                        selected_simulation,
                        restart_simulation,
                        observation_values,
                        functional_fit_mask & regime_masks[day_set],
                        validation & regime_masks[day_set],
                        transform=transform,
                        log_offset=log_offset,
                        maximum_distance=functional_distance_maximum,
                    )
                    for day_set, (transform, log_offset) in transforms.items()
                }
        evaluations[name] = {
            "parameter_set": name,
            "selected_params": selected_params,
            "fit_objective_loss": float(raw_record.get("objective_loss", float("nan"))),
            **parameter_absolute,
            "qsim": selected_simulation,
            "final_state": selected_final_state,
            "restart_metrics": restart_metrics,
            "selected_restart_preserved_from_fit": True,
            "selected_parameter_fingerprint": selected_fingerprint,
        }

    general = evaluations["all_flow"]
    for specialist_name, other_name, target_key, opposite_key in (
        ("low_flow", "high_flow", "low_flow_log_mse", "high_flow_raw_mse"),
        ("high_flow", "low_flow", "high_flow_raw_mse", "low_flow_log_mse"),
    ):
        specialist = evaluations[specialist_name]
        other = evaluations[other_name]
        _add_specialist_comparison(specialist, general, other, target_key, opposite_key)
        for restart_metrics in specialist["restart_metrics"]:
            _add_specialist_comparison(
                restart_metrics,
                general,
                other,
                target_key,
                opposite_key,
            )
    return evaluations


def apply_validation_gates(
    evaluations: Mapping[str, Mapping[str, Any]],
    *,
    target_relative_improvement_min: float = DEFAULT_TARGET_RELATIVE_IMPROVEMENT,
    minimum_improved_water_years: int = DEFAULT_MINIMUM_IMPROVED_WATER_YEARS,
    all_flow_nse_drop_max: float = DEFAULT_MAXIMUM_ALL_PERIOD_NSE_DROP,
    opposite_regime_relative_degradation_max: float = DEFAULT_MAXIMUM_OPPOSITE_REGIME_LOSS_INCREASE,
    must_beat_other_specialist: bool = True,
) -> dict[str, Any]:
    """Apply frozen validation gates to fit-selected specialists."""

    if not isinstance(evaluations, Mapping):
        raise TypeError("evaluations must be a mapping")
    for name in OBJECTIVES:
        if name not in evaluations:
            raise ValueError(f"evaluations is missing required entry: {name}")
    if not np.isfinite(target_relative_improvement_min) or target_relative_improvement_min < 0.0:
        raise ValueError("target_relative_improvement_min must be finite and nonnegative")
    if int(minimum_improved_water_years) < 1:
        raise ValueError("minimum_improved_water_years must be positive")
    if not np.isfinite(all_flow_nse_drop_max) or all_flow_nse_drop_max < 0.0:
        raise ValueError("all_flow_nse_drop_max must be finite and nonnegative")
    if (
        not np.isfinite(opposite_regime_relative_degradation_max)
        or opposite_regime_relative_degradation_max < 0.0
    ):
        raise ValueError("opposite_regime_relative_degradation_max must be finite and nonnegative")
    if not isinstance(must_beat_other_specialist, (bool, np.bool_)):
        raise ValueError("must_beat_other_specialist must be boolean")

    gates: dict[str, Any] = {}
    for name in ("low_flow", "high_flow"):
        metrics = evaluations[name]
        target_improvement = float(metrics.get("target_relative_improvement", float("nan")))
        improved_years = int(metrics.get("improved_water_years", 0))
        nse_drop = float(metrics.get("all_period_nse_drop", float("nan")))
        opposite_increase = float(metrics.get("opposite_regime_loss_increase", float("nan")))
        beats_other = bool(metrics.get("target_loss_beats_other_specialist", False))
        checks = {
            "target_improvement_pass": bool(
                np.isfinite(target_improvement)
                and target_improvement >= float(target_relative_improvement_min)
            ),
            "water_year_direction_pass": bool(improved_years >= int(minimum_improved_water_years)),
            "all_period_nse_guardrail_pass": bool(
                np.isfinite(nse_drop) and nse_drop <= float(all_flow_nse_drop_max)
            ),
            "opposite_regime_guardrail_pass": bool(
                np.isfinite(opposite_increase)
                and opposite_increase <= float(opposite_regime_relative_degradation_max)
            ),
            "target_beats_other_specialist_pass": bool(beats_other or not must_beat_other_specialist),
        }
        gates[name] = {
            "target_relative_improvement": target_improvement,
            "target_relative_improvement_min": float(target_relative_improvement_min),
            "improved_water_years": improved_years,
            "minimum_improved_water_years": int(minimum_improved_water_years),
            "all_flow_nse_drop": nse_drop,
            "all_flow_nse_drop_max": float(all_flow_nse_drop_max),
            "opposite_regime_relative_degradation": opposite_increase,
            "opposite_regime_relative_degradation_max": float(opposite_regime_relative_degradation_max),
            "must_beat_other_specialist": bool(must_beat_other_specialist),
            "target_loss_beats_other_specialist": beats_other,
            **checks,
            "qualifies": bool(all(checks.values())),
        }
    gates["all_specialists_qualify"] = bool(gates["low_flow"]["qualifies"] and gates["high_flow"]["qualifies"])
    return gates


def _finite_threshold(value: Any, name: str, *, minimum: float = 0.0) -> float:
    numeric = float(value)
    if not np.isfinite(numeric) or numeric < minimum:
        raise ValueError(f"{name} must be finite and at least {minimum}")
    return numeric


def _nonnegative_integer(value: Any, name: str) -> int:
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)) or int(value) < 0:
        raise ValueError(f"{name} must be a nonnegative integer")
    return int(value)


def _selected_restart_position(
    restart_metrics: Sequence[Mapping[str, Any]],
    selected_parameters: Mapping[str, float],
    selected_fit_loss: float,
    name: str,
) -> int | None:
    selected_fingerprint = _parameter_fingerprint(selected_parameters)
    matching_positions = []
    finite_fit_losses = []
    for position, restart in enumerate(restart_metrics):
        if not isinstance(restart, Mapping):
            raise ValueError(f"{name} restart metric records must be mappings")
        restart_parameters = restart.get("optimized_params")
        if not isinstance(restart_parameters, Mapping):
            raise ValueError(f"{name} restart metric must contain optimized_params")
        restart_fit_loss = float(restart.get("fit_objective_loss", float("nan")))
        if np.isfinite(restart_fit_loss):
            finite_fit_losses.append(restart_fit_loss)
        if (
            _parameter_fingerprint(restart_parameters) == selected_fingerprint
            and np.isfinite(restart_fit_loss)
            and np.isclose(restart_fit_loss, selected_fit_loss, rtol=0.0, atol=1e-12)
        ):
            matching_positions.append(position)
    if not matching_positions or not finite_fit_losses:
        return None
    if selected_fit_loss > min(finite_fit_losses) + 1e-12:
        return None
    return min(matching_positions)


def _required_boolean_field(record: Mapping[str, Any], field: str, label: str) -> bool:
    if field not in record:
        raise ValueError(f"{label} must contain {field}")
    value = record[field]
    if not isinstance(value, (bool, np.bool_)):
        raise ValueError(f"{label} {field} must be boolean")
    return bool(value)


def _restart_identities(
    restart_metrics: Sequence[Mapping[str, Any]],
    name: str,
) -> list[tuple[int | None, int | None]]:
    identities = []
    for restart in restart_metrics:
        if not isinstance(restart, Mapping):
            raise ValueError(f"{name} restart metric records must be mappings")
        raw_index = restart.get("restart_index")
        raw_seed = restart.get("seed")
        if raw_index is not None and (
            isinstance(raw_index, (bool, np.bool_))
            or not isinstance(raw_index, (int, np.integer))
            or int(raw_index) < 0
        ):
            raise ValueError(f"{name} restart_index must be a nonnegative integer when present")
        if raw_seed is not None and (
            isinstance(raw_seed, (bool, np.bool_)) or not isinstance(raw_seed, (int, np.integer))
        ):
            raise ValueError(f"{name} seed must be an integer when present")
        identities.append(
            (
                None if raw_index is None else int(raw_index),
                None if raw_seed is None else int(raw_seed),
            )
        )
    return identities


def _independent_restart_identity(
    identities: Sequence[tuple[int | None, int | None]],
    selected_position: int | None,
    position: int,
) -> bool:
    if selected_position is None or position == selected_position:
        return False
    selected_index, selected_seed = identities[selected_position]
    restart_index, restart_seed = identities[position]
    if selected_index is None or selected_seed is None or restart_index is None or restart_seed is None:
        return False
    indices = [identity[0] for identity in identities]
    seeds = [identity[1] for identity in identities]
    return bool(
        restart_index != selected_index
        and restart_seed != selected_seed
        and indices.count(selected_index) == 1
        and seeds.count(selected_seed) == 1
        and indices.count(restart_index) == 1
        and seeds.count(restart_seed) == 1
    )


def apply_parameter_quality_gates(
    calibrations: Mapping[str, Mapping[str, Any]],
    evaluations: Mapping[str, Mapping[str, Any]],
    validation_gates: Mapping[str, Mapping[str, Any]],
    parameter_bounds: Mapping[str, Sequence[float]],
    *,
    generalist_nse_min: float = 0.30,
    support_fit_loss_ratio_max: float = 1.05,
    support_parameter_distance_max: float = 0.20,
    maximum_near_boundary_parameters: int = 2,
    maximum_strongly_saturated_parameters: int = 1,
    minimum_support_restarts: int = 1,
    support_target_relative_improvement_min: float = DEFAULT_TARGET_RELATIVE_IMPROVEMENT,
    support_minimum_improved_water_years: int = DEFAULT_MINIMUM_IMPROVED_WATER_YEARS,
    support_all_period_nse_drop_max: float = DEFAULT_MAXIMUM_ALL_PERIOD_NSE_DROP,
    support_opposite_regime_relative_degradation_max: float = DEFAULT_MAXIMUM_OPPOSITE_REGIME_LOSS_INCREASE,
    support_must_beat_other_specialist: bool = True,
) -> dict[str, Any]:
    """Require bounded fit-selected specialists with an independent support restart.

    The fit-selected restart remains fixed.  Other optimizer restarts are
    audited only as supporting evidence; validation never promotes one of them
    to become the selected parameter vector.
    """

    for mapping, label in (
        (calibrations, "calibrations"),
        (evaluations, "evaluations"),
        (validation_gates, "validation_gates"),
    ):
        if not isinstance(mapping, Mapping):
            raise TypeError(f"{label} must be a mapping")
    for name in OBJECTIVES:
        if name not in calibrations or name not in evaluations:
            raise ValueError(f"calibrations and evaluations must contain {name}")
    for name in ("low_flow", "high_flow"):
        if name not in validation_gates:
            raise ValueError(f"validation_gates must contain {name}")

    generalist_nse_min = _finite_threshold(generalist_nse_min, "generalist_nse_min")
    support_fit_loss_ratio_max = _finite_threshold(
        support_fit_loss_ratio_max,
        "support_fit_loss_ratio_max",
        minimum=1.0,
    )
    support_parameter_distance_max = _finite_threshold(
        support_parameter_distance_max,
        "support_parameter_distance_max",
    )
    maximum_near_boundary_parameters = _nonnegative_integer(
        maximum_near_boundary_parameters,
        "maximum_near_boundary_parameters",
    )
    maximum_strongly_saturated_parameters = _nonnegative_integer(
        maximum_strongly_saturated_parameters,
        "maximum_strongly_saturated_parameters",
    )
    minimum_support_restarts = _nonnegative_integer(minimum_support_restarts, "minimum_support_restarts")
    if minimum_support_restarts < 1:
        raise ValueError("minimum_support_restarts must be at least 1")
    support_target_relative_improvement_min = _finite_threshold(
        support_target_relative_improvement_min,
        "support_target_relative_improvement_min",
    )
    support_minimum_improved_water_years = _nonnegative_integer(
        support_minimum_improved_water_years,
        "support_minimum_improved_water_years",
    )
    support_all_period_nse_drop_max = _finite_threshold(
        support_all_period_nse_drop_max,
        "support_all_period_nse_drop_max",
    )
    support_opposite_regime_relative_degradation_max = _finite_threshold(
        support_opposite_regime_relative_degradation_max,
        "support_opposite_regime_relative_degradation_max",
    )
    if not isinstance(support_must_beat_other_specialist, (bool, np.bool_)):
        raise ValueError("support_must_beat_other_specialist must be boolean")

    generalist_nse = float(evaluations["all_flow"].get("all_period_nse", float("nan")))
    generalist_nse_pass = bool(np.isfinite(generalist_nse) and generalist_nse >= generalist_nse_min)
    result: dict[str, Any] = {
        "generalist_nse": generalist_nse,
        "generalist_nse_min": generalist_nse_min,
        "generalist_nse_pass": generalist_nse_pass,
    }

    generalist_calibration = calibrations["all_flow"]
    generalist_evaluation = evaluations["all_flow"]
    if not isinstance(generalist_calibration, Mapping) or not isinstance(generalist_evaluation, Mapping):
        raise TypeError("all_flow calibration and evaluation records must be mappings")
    generalist_selected_raw = generalist_calibration.get("optimized_params")
    if not isinstance(generalist_selected_raw, Mapping):
        raise ValueError("all_flow calibration must contain optimized_params")
    generalist_selected, _ = _validated_parameter_values_and_bounds(
        generalist_selected_raw,
        parameter_bounds,
        "all_flow selected parameters",
    )
    if "selected_params" not in generalist_evaluation:
        raise ValueError("all_flow evaluation must contain selected_params")
    evaluated_generalist = generalist_evaluation["selected_params"]
    if not isinstance(evaluated_generalist, Mapping):
        raise ValueError("all_flow evaluation selected_params must be a mapping")
    if _parameter_fingerprint(generalist_selected) != _parameter_fingerprint(evaluated_generalist):
        raise ValueError("all_flow evaluation selected parameters must match the fit-selected parameters")
    generalist_fit_loss = float(generalist_calibration.get("objective_loss", float("nan")))
    if not np.isfinite(generalist_fit_loss):
        raise ValueError("all_flow selected fit objective loss must be finite")
    generalist_boundary = parameter_boundary_diagnostics(generalist_selected, parameter_bounds)
    generalist_boundary_pass = bool(
        generalist_boundary["near_boundary_count"] <= maximum_near_boundary_parameters
        and generalist_boundary["strongly_saturated_count"] <= maximum_strongly_saturated_parameters
    )
    generalist_restarts = generalist_evaluation.get("restart_metrics", [])
    if not isinstance(generalist_restarts, Sequence) or isinstance(generalist_restarts, (str, bytes)):
        raise ValueError("all_flow restart_metrics must be a sequence")
    generalist_restart_identities = _restart_identities(generalist_restarts, "all_flow")
    generalist_selected_position = _selected_restart_position(
        generalist_restarts,
        generalist_selected,
        generalist_fit_loss,
        "all_flow",
    )
    generalist_restart_diagnostics = []
    generalist_support_restarts = []
    for position, restart in enumerate(generalist_restarts):
        restart_parameters = restart["optimized_params"]
        fit_loss = float(restart.get("fit_objective_loss", float("nan")))
        validation_nse = float(restart.get("all_period_nse", float("nan")))
        distance = normalized_parameter_distance(generalist_selected, restart_parameters, parameter_bounds)
        boundary = parameter_boundary_diagnostics(restart_parameters, parameter_bounds)
        evidence_sufficient = _required_boolean_field(
            restart,
            "evidence_sufficient",
            "all_flow restart metric",
        )
        checks = {
            "additional_restart_pass": bool(
                generalist_selected_position is not None and position != generalist_selected_position
            ),
            "independent_restart_identity_pass": _independent_restart_identity(
                generalist_restart_identities,
                generalist_selected_position,
                position,
            ),
            "fit_loss_pass": bool(
                np.isfinite(fit_loss) and fit_loss <= support_fit_loss_ratio_max * generalist_fit_loss
            ),
            "parameter_distance_pass": bool(distance <= support_parameter_distance_max),
            "validation_nse_pass": bool(
                np.isfinite(validation_nse) and validation_nse >= generalist_nse_min
            ),
            "boundary_pass": bool(
                boundary["near_boundary_count"] <= maximum_near_boundary_parameters
                and boundary["strongly_saturated_count"] <= maximum_strongly_saturated_parameters
            ),
            "evidence_sufficient_pass": evidence_sufficient,
        }
        restart_index, restart_seed = generalist_restart_identities[position]
        diagnostic = {
            "restart_index": position if restart_index is None else restart_index,
            "seed": restart_seed,
            "fit_objective_loss": fit_loss,
            "validation_nse": validation_nse,
            "fit_loss_ratio_to_selected": (
                float(fit_loss / generalist_fit_loss)
                if np.isfinite(fit_loss) and generalist_fit_loss != 0.0
                else (1.0 if fit_loss == generalist_fit_loss == 0.0 else float("inf"))
            ),
            "normalized_parameter_distance": distance,
            "boundary_diagnostics": boundary,
            **checks,
            "qualifies_as_support": bool(all(checks.values())),
        }
        generalist_restart_diagnostics.append(diagnostic)
        if diagnostic["qualifies_as_support"]:
            generalist_support_restarts.append(diagnostic)
    generalist_support_pass = len(generalist_support_restarts) >= minimum_support_restarts
    generalist_evidence_pass = _required_boolean_field(
        generalist_evaluation,
        "evidence_sufficient",
        "all_flow evaluation",
    )
    result["all_flow"] = {
        "selected_fit_objective_loss": generalist_fit_loss,
        "selected_boundary_diagnostics": generalist_boundary,
        "selected_boundary_pass": generalist_boundary_pass,
        "selected_validation_nse": generalist_nse,
        "selected_validation_nse_pass": generalist_nse_pass,
        "selected_evidence_sufficient_pass": generalist_evidence_pass,
        "selected_restart_record_found_pass": generalist_selected_position is not None,
        "support_restart_count": len(generalist_support_restarts),
        "minimum_support_restarts": minimum_support_restarts,
        "support_restart_pass": bool(generalist_support_pass),
        "support_restarts": generalist_support_restarts,
        "restart_diagnostics": generalist_restart_diagnostics,
        "qualifies": bool(
            generalist_nse_pass
            and generalist_boundary_pass
            and generalist_evidence_pass
            and generalist_selected_position is not None
            and generalist_support_pass
        ),
    }

    for name in ("low_flow", "high_flow"):
        calibration = calibrations[name]
        evaluation = evaluations[name]
        validation_gate = validation_gates[name]
        if not isinstance(calibration, Mapping) or not isinstance(evaluation, Mapping):
            raise TypeError(f"{name} calibration and evaluation records must be mappings")
        selected_raw = calibration.get("optimized_params")
        if not isinstance(selected_raw, Mapping):
            raise ValueError(f"{name} calibration must contain optimized_params")
        selected_params, _ = _validated_parameter_values_and_bounds(
            selected_raw,
            parameter_bounds,
            f"{name} selected parameters",
        )
        if "selected_params" not in evaluation:
            raise ValueError(f"{name} evaluation must contain selected_params")
        evaluated_selected = evaluation["selected_params"]
        if not isinstance(evaluated_selected, Mapping):
            raise ValueError(f"{name} evaluation selected_params must be a mapping")
        if _parameter_fingerprint(selected_params) != _parameter_fingerprint(evaluated_selected):
            raise ValueError(f"{name} evaluation selected parameters must match the fit-selected parameters")
        selected_fit_loss = float(calibration.get("objective_loss", float("nan")))
        if not np.isfinite(selected_fit_loss):
            raise ValueError(f"{name} selected fit objective loss must be finite")

        selected_boundary = parameter_boundary_diagnostics(selected_params, parameter_bounds)
        selected_boundary_pass = bool(
            selected_boundary["near_boundary_count"] <= maximum_near_boundary_parameters
            and selected_boundary["strongly_saturated_count"] <= maximum_strongly_saturated_parameters
        )
        validation_gate_pass = bool(validation_gate.get("qualifies", False))
        selected_evidence_sufficient_pass = _required_boolean_field(
            evaluation,
            "evidence_sufficient",
            f"{name} evaluation",
        )
        selected_validation_nse = float(evaluation.get("all_period_nse", float("nan")))
        selected_validation_nse_pass = bool(
            np.isfinite(selected_validation_nse) and selected_validation_nse >= generalist_nse_min
        )

        restart_metrics = evaluation.get("restart_metrics", [])
        if not isinstance(restart_metrics, Sequence) or isinstance(restart_metrics, (str, bytes)):
            raise ValueError(f"{name} restart_metrics must be a sequence")
        restart_identities = _restart_identities(restart_metrics, name)
        selected_restart_position = _selected_restart_position(
            restart_metrics,
            selected_params,
            selected_fit_loss,
            name,
        )

        restart_diagnostics = []
        support_restarts = []
        for position, restart in enumerate(restart_metrics):
            restart_parameters = restart.get("optimized_params")
            if not isinstance(restart_parameters, Mapping):
                raise ValueError(f"{name} restart metric must contain optimized_params")
            fit_loss = float(restart.get("fit_objective_loss", float("nan")))
            distance = normalized_parameter_distance(selected_params, restart_parameters, parameter_bounds)
            boundary = parameter_boundary_diagnostics(restart_parameters, parameter_bounds)
            is_selected_restart = position == selected_restart_position
            target_improvement = float(restart.get("target_relative_improvement", float("nan")))
            improved_water_years = int(restart.get("improved_water_years", 0))
            validation_nse = float(restart.get("all_period_nse", float("nan")))
            nse_drop = float(restart.get("all_period_nse_drop", float("nan")))
            opposite_degradation = float(
                restart.get(
                    "opposite_regime_relative_degradation",
                    restart.get("opposite_regime_loss_increase", float("nan")),
                )
            )
            evidence_sufficient = _required_boolean_field(
                restart,
                "evidence_sufficient",
                f"{name} restart metric",
            )
            checks = {
                "additional_restart_pass": bool(
                    selected_restart_position is not None and not is_selected_restart
                ),
                "independent_restart_identity_pass": _independent_restart_identity(
                    restart_identities,
                    selected_restart_position,
                    position,
                ),
                "fit_loss_pass": bool(
                    np.isfinite(fit_loss) and fit_loss <= support_fit_loss_ratio_max * selected_fit_loss
                ),
                "parameter_distance_pass": bool(distance <= support_parameter_distance_max),
                "target_improvement_pass": bool(
                    np.isfinite(target_improvement)
                    and target_improvement >= support_target_relative_improvement_min
                ),
                "water_year_direction_pass": bool(
                    improved_water_years >= support_minimum_improved_water_years
                ),
                "validation_nse_pass": bool(
                    np.isfinite(validation_nse) and validation_nse >= generalist_nse_min
                ),
                "all_period_nse_guardrail_pass": bool(
                    np.isfinite(nse_drop) and nse_drop <= support_all_period_nse_drop_max
                ),
                "opposite_regime_guardrail_pass": bool(
                    np.isfinite(opposite_degradation)
                    and opposite_degradation <= support_opposite_regime_relative_degradation_max
                ),
                "target_beats_other_specialist_pass": bool(
                    restart.get("target_loss_beats_other_specialist", False)
                    or not support_must_beat_other_specialist
                ),
                "boundary_pass": bool(
                    boundary["near_boundary_count"] <= maximum_near_boundary_parameters
                    and boundary["strongly_saturated_count"] <= maximum_strongly_saturated_parameters
                ),
                "evidence_sufficient_pass": evidence_sufficient,
            }
            restart_index, restart_seed = restart_identities[position]
            diagnostic = {
                "restart_index": position if restart_index is None else restart_index,
                "seed": restart_seed,
                "fit_objective_loss": fit_loss,
                "fit_loss_ratio_to_selected": (
                    float(fit_loss / selected_fit_loss)
                    if np.isfinite(fit_loss) and selected_fit_loss != 0.0
                    else (1.0 if fit_loss == selected_fit_loss == 0.0 else float("inf"))
                ),
                "normalized_parameter_distance": distance,
                "boundary_diagnostics": boundary,
                **checks,
                "qualifies_as_support": bool(all(checks.values())),
            }
            restart_diagnostics.append(diagnostic)
            if diagnostic["qualifies_as_support"]:
                support_restarts.append(diagnostic)

        support_restart_pass = len(support_restarts) >= minimum_support_restarts
        result[name] = {
            "selected_fit_objective_loss": selected_fit_loss,
            "selected_boundary_diagnostics": selected_boundary,
            "selected_boundary_pass": selected_boundary_pass,
            "validation_gate_pass": validation_gate_pass,
            "selected_evidence_sufficient_pass": selected_evidence_sufficient_pass,
            "selected_validation_nse": selected_validation_nse,
            "selected_validation_nse_pass": selected_validation_nse_pass,
            "selected_restart_record_found_pass": selected_restart_position is not None,
            "support_restart_count": len(support_restarts),
            "minimum_support_restarts": minimum_support_restarts,
            "support_restart_pass": bool(support_restart_pass),
            "support_restarts": support_restarts,
            "restart_diagnostics": restart_diagnostics,
            "qualifies": bool(
                generalist_nse_pass
                and validation_gate_pass
                and selected_boundary_pass
                and selected_evidence_sufficient_pass
                and selected_validation_nse_pass
                and selected_restart_position is not None
                and support_restart_pass
            ),
        }
    result["all_specialists_qualify"] = bool(
        result["low_flow"]["qualifies"] and result["high_flow"]["qualifies"]
    )
    result["all_parameter_sets_qualify"] = bool(
        result["all_flow"]["qualifies"] and result["all_specialists_qualify"]
    )
    return result


def _validated_output_functional_distance_gate(
    restart: Mapping[str, Any],
    *,
    maximum_distance: float,
    flow_log_offset_mm_day: float,
    label: str,
) -> dict[str, Any]:
    def strict_numeric_field(record: Mapping[str, Any], field: str, day_set: str) -> float:
        raw_value = record[field]
        if isinstance(raw_value, (bool, np.bool_)) or not isinstance(
            raw_value,
            (int, float, np.integer, np.floating),
        ):
            raise ValueError(f"{label} {day_set} {field} must be a numeric scalar")
        return float(raw_value)

    raw_distances = restart.get("output_functional_distances")
    if not isinstance(raw_distances, Mapping) or set(raw_distances) != set(OBJECTIVES):
        raise ValueError(
            f"{label} output_functional_distances must contain exactly all_flow, low_flow, and high_flow"
        )
    expected_transforms = {
        "all_flow": ("identity", None),
        "low_flow": ("log_q_plus_offset", flow_log_offset_mm_day),
        "high_flow": ("identity", None),
    }
    validated: dict[str, dict[str, Any]] = {}
    for day_set, (expected_transform, expected_offset) in expected_transforms.items():
        record = raw_distances[day_set]
        if not isinstance(record, Mapping):
            raise ValueError(f"{label} {day_set} output functional distance must be a mapping")
        required_fields = {
            "numerator",
            "denominator",
            "distance",
            "fit_scale_count",
            "validation_compare_count",
            "transform",
            "log_offset",
            "maximum_distance",
            "passes",
        }
        missing_fields = required_fields - set(record)
        if missing_fields:
            raise ValueError(
                f"{label} {day_set} output functional distance is missing {sorted(missing_fields)}"
            )
        numerator = strict_numeric_field(record, "numerator", day_set)
        denominator = strict_numeric_field(record, "denominator", day_set)
        distance = strict_numeric_field(record, "distance", day_set)
        recorded_maximum = strict_numeric_field(record, "maximum_distance", day_set)
        if not np.isfinite(numerator) or numerator < 0.0:
            raise ValueError(f"{label} {day_set} numerator must be finite and nonnegative")
        if not np.isfinite(denominator) or denominator <= 0.0:
            raise ValueError(f"{label} {day_set} denominator must be finite and positive")
        if not np.isfinite(distance) or distance < 0.0:
            raise ValueError(f"{label} {day_set} distance must be finite and nonnegative")
        if not np.isclose(distance, numerator / denominator, rtol=0.0, atol=1e-12):
            raise ValueError(f"{label} {day_set} distance must equal numerator divided by denominator")
        if recorded_maximum != maximum_distance:
            raise ValueError(f"{label} {day_set} maximum_distance does not match the v03 gate")
        if record["transform"] != expected_transform:
            raise ValueError(f"{label} {day_set} transform does not match the v03 contract")
        recorded_offset = record["log_offset"]
        if expected_offset is None:
            if recorded_offset is not None:
                raise ValueError(f"{label} {day_set} log_offset must be None")
        elif (
            isinstance(recorded_offset, (bool, np.bool_))
            or not isinstance(recorded_offset, (int, float, np.integer, np.floating))
            or not np.isfinite(recorded_offset)
            or float(recorded_offset) != expected_offset
        ):
            raise ValueError(f"{label} {day_set} log_offset does not match the v03 contract")
        for count_field in ("fit_scale_count", "validation_compare_count"):
            count = record[count_field]
            if (
                isinstance(count, (bool, np.bool_))
                or not isinstance(count, (int, np.integer))
                or int(count) < 1
            ):
                raise ValueError(f"{label} {day_set} {count_field} must be a positive integer")
        if not isinstance(record["passes"], (bool, np.bool_)):
            raise ValueError(f"{label} {day_set} passes must be boolean")
        expected_pass = bool(distance <= maximum_distance)
        if bool(record["passes"]) != expected_pass:
            raise ValueError(f"{label} {day_set} passes disagrees with its distance")
        validated[day_set] = {
            "numerator": numerator,
            "denominator": denominator,
            "distance": distance,
            "fit_scale_count": int(record["fit_scale_count"]),
            "validation_compare_count": int(record["validation_compare_count"]),
            "transform": expected_transform,
            "log_offset": expected_offset,
            "maximum_distance": maximum_distance,
            "passes": expected_pass,
        }
    return {
        "maximum_distance": maximum_distance,
        "all_three_day_sets_required": True,
        "day_sets": validated,
        "passes": bool(all(record["passes"] for record in validated.values())),
    }


def apply_parameter_quality_gates_v03(
    calibrations: Mapping[str, Mapping[str, Any]],
    evaluations: Mapping[str, Mapping[str, Any]],
    validation_gates: Mapping[str, Mapping[str, Any]],
    parameter_bounds: Mapping[str, Sequence[float]],
    *,
    generalist_nse_min: float = 0.30,
    support_fit_loss_ratio_max: float = 1.05,
    support_output_functional_distance_max: float = 0.03,
    diagnostic_parameter_distance_reference: float = 0.20,
    flow_log_offset_mm_day: float = 0.01,
    maximum_near_boundary_parameters: int = 2,
    maximum_strongly_saturated_parameters: int = 1,
    minimum_support_restarts: int = 1,
    support_target_relative_improvement_min: float = DEFAULT_TARGET_RELATIVE_IMPROVEMENT,
    support_minimum_improved_water_years: int = DEFAULT_MINIMUM_IMPROVED_WATER_YEARS,
    support_all_period_nse_drop_max: float = DEFAULT_MAXIMUM_ALL_PERIOD_NSE_DROP,
    support_opposite_regime_relative_degradation_max: float = DEFAULT_MAXIMUM_OPPOSITE_REGIME_LOSS_INCREASE,
    support_must_beat_other_specialist: bool = True,
) -> dict[str, Any]:
    """Apply the third-version support gate using daily output equivalence.

    The second-version reducer is used only to build its unchanged fit,
    validation, identity and boundary diagnostics.  Its parameter-distance
    check is made non-discriminating for bounded vectors, removed from every
    returned support conjunction, and replaced by all three functional
    distances.  Parameter distance remains a labelled diagnostic only.
    """

    for value, label in (
        (support_output_functional_distance_max, "support_output_functional_distance_max"),
        (diagnostic_parameter_distance_reference, "diagnostic_parameter_distance_reference"),
        (flow_log_offset_mm_day, "flow_log_offset_mm_day"),
    ):
        if isinstance(value, (bool, np.bool_)):
            raise ValueError(f"{label} must be numeric, not boolean")
    functional_maximum = _finite_threshold(
        support_output_functional_distance_max,
        "support_output_functional_distance_max",
    )
    diagnostic_reference = _finite_threshold(
        diagnostic_parameter_distance_reference,
        "diagnostic_parameter_distance_reference",
    )
    log_offset = _finite_threshold(
        flow_log_offset_mm_day,
        "flow_log_offset_mm_day",
        minimum=np.nextafter(0.0, 1.0),
    )
    result = apply_parameter_quality_gates(
        calibrations,
        evaluations,
        validation_gates,
        parameter_bounds,
        generalist_nse_min=generalist_nse_min,
        support_fit_loss_ratio_max=support_fit_loss_ratio_max,
        # Every valid bounded-vector root-mean-square distance is <= 1.0.
        # The v03 decisions below are rebuilt without this legacy field.
        support_parameter_distance_max=1.0,
        maximum_near_boundary_parameters=maximum_near_boundary_parameters,
        maximum_strongly_saturated_parameters=maximum_strongly_saturated_parameters,
        minimum_support_restarts=minimum_support_restarts,
        support_target_relative_improvement_min=support_target_relative_improvement_min,
        support_minimum_improved_water_years=support_minimum_improved_water_years,
        support_all_period_nse_drop_max=support_all_period_nse_drop_max,
        support_opposite_regime_relative_degradation_max=(
            support_opposite_regime_relative_degradation_max
        ),
        support_must_beat_other_specialist=support_must_beat_other_specialist,
    )
    result["quality_gate_version"] = "v03_output_functional_stability"
    result["support_output_functional_distance_max"] = functional_maximum
    result["diagnostic_parameter_distance_reference"] = diagnostic_reference
    result["parameter_distance_is_qualification_gate"] = False

    for name in OBJECTIVES:
        group = result[name]
        source_restarts = evaluations[name].get("restart_metrics", [])
        rebuilt_support = []
        functionally_stable_support_count = 0
        range_valid_stable_support_count = 0
        for position, diagnostic in enumerate(group["restart_diagnostics"]):
            source_restart = source_restarts[position]
            functional_gate = _validated_output_functional_distance_gate(
                source_restart,
                maximum_distance=functional_maximum,
                flow_log_offset_mm_day=log_offset,
                label=f"{name} restart {position}",
            )
            parameter_distance = float(diagnostic["normalized_parameter_distance"])
            diagnostic.pop("parameter_distance_pass", None)
            diagnostic["parameter_distance_diagnostic"] = {
                "normalized_parameter_distance": parameter_distance,
                "second_version_reference": diagnostic_reference,
                "exceeds_second_version_reference": bool(
                    parameter_distance > diagnostic_reference
                ),
                "qualification_gate": False,
            }
            diagnostic["functional_stability_gate"] = functional_gate
            diagnostic["parameter_range_gate"] = {
                "boundary_diagnostics": diagnostic["boundary_diagnostics"],
                "passes": bool(diagnostic["boundary_pass"]),
            }
            unchanged_support_checks_pass = all(
                bool(value)
                for key, value in diagnostic.items()
                if key.endswith("_pass") and key != "parameter_distance_pass"
            )
            diagnostic["qualifies_as_support"] = bool(
                unchanged_support_checks_pass and functional_gate["passes"]
            )
            functionally_stable_support = bool(
                diagnostic["additional_restart_pass"]
                and diagnostic["independent_restart_identity_pass"]
                and diagnostic["fit_loss_pass"]
                and functional_gate["passes"]
            )
            if functionally_stable_support:
                functionally_stable_support_count += 1
            if functionally_stable_support and diagnostic["boundary_pass"]:
                range_valid_stable_support_count += 1
            if diagnostic["qualifies_as_support"]:
                rebuilt_support.append(diagnostic)

        group["support_restarts"] = rebuilt_support
        group["support_restart_count"] = len(rebuilt_support)
        group["support_restart_pass"] = bool(
            len(rebuilt_support) >= int(group["minimum_support_restarts"])
        )
        group["functional_stability_gate"] = {
            "minimum_support_restarts": int(group["minimum_support_restarts"]),
            "support_restart_count": functionally_stable_support_count,
            "maximum_distance": functional_maximum,
            "all_three_day_sets_required": True,
            "passes": bool(
                functionally_stable_support_count >= int(group["minimum_support_restarts"])
            ),
        }
        group["parameter_range_gate"] = {
            "selected_boundary_diagnostics": group["selected_boundary_diagnostics"],
            "selected_boundary_pass": bool(group["selected_boundary_pass"]),
            "support_boundary_is_required": True,
            "range_valid_stable_support_count": range_valid_stable_support_count,
            "passes": bool(
                group["selected_boundary_pass"]
                and range_valid_stable_support_count >= int(group["minimum_support_restarts"])
            ),
        }
        if name == "all_flow":
            group["qualifies"] = bool(
                group["selected_validation_nse_pass"]
                and group["selected_boundary_pass"]
                and group["selected_evidence_sufficient_pass"]
                and group["selected_restart_record_found_pass"]
                and group["support_restart_pass"]
            )
        else:
            group["qualifies"] = bool(
                result["generalist_nse_pass"]
                and group["validation_gate_pass"]
                and group["selected_boundary_pass"]
                and group["selected_evidence_sufficient_pass"]
                and group["selected_validation_nse_pass"]
                and group["selected_restart_record_found_pass"]
                and group["support_restart_pass"]
            )

    result["all_specialists_qualify"] = bool(
        result["low_flow"]["qualifies"] and result["high_flow"]["qualifies"]
    )
    result["all_parameter_sets_qualify"] = bool(
        result["all_flow"]["qualifies"] and result["all_specialists_qualify"]
    )
    return result


_INITIAL_STATE_CONVERGENCE_RESULT_FIELDS = {
    "scenario_ids",
    "parameter_sha256",
    "par_k2",
    "warmup_days",
    "initial_slz_difference_mm",
    "final_slz_difference_mm",
    "analytical_retained_fraction",
    "replayed_retained_fraction",
    "retained_fraction_max",
    "analytical_retained_fraction_pass",
    "replayed_retained_fraction_pass",
    "retained_fraction_matches_analytical",
    "output_functional_distance_gate",
    "passes",
}
_HYDROGRAPH_RESPONSE_RESULT_FIELDS = {"thresholds", "water_years", "passes"}
_HYDROGRAPH_RESPONSE_THRESHOLD_FIELDS = {
    "variability_ratio_min",
    "variability_ratio_max",
    "mean_ratio_min",
    "mean_ratio_max",
    "total_variation_ratio_min",
    "total_variation_ratio_max",
    "mean_offset",
}
_HYDROGRAPH_RESPONSE_WATER_YEAR_FIELDS = {
    "water_year",
    "day_count",
    "observed_mean",
    "simulated_mean",
    "observed_standard_deviation",
    "simulated_standard_deviation",
    "variability_ratio",
    "variability_ratio_min",
    "variability_ratio_max",
    "variability_ratio_pass",
    "mean_offset",
    "mean_ratio",
    "mean_ratio_min",
    "mean_ratio_max",
    "mean_ratio_pass",
    "observed_total_variation",
    "simulated_total_variation",
    "total_variation_ratio",
    "total_variation_ratio_min",
    "total_variation_ratio_max",
    "total_variation_ratio_pass",
    "passes",
}


def _v04_exact_mapping(value: Any, fields: set[str], label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping) or set(value) != fields:
        raise ValueError(f"{label} must contain exactly {sorted(fields)}")
    return value


def _v04_required_integer(record: Mapping[str, Any], field: str, label: str) -> int:
    if field not in record:
        raise ValueError(f"{label} must contain {field}")
    value = record[field]
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)):
        raise ValueError(f"{label} {field} must be an integer")
    return int(value)


def _v04_parameter_sha256(parameters: Mapping[str, Any], label: str) -> str:
    if not isinstance(parameters, Mapping) or set(parameters) != set(PARAM_NAMES):
        raise ValueError(f"{label} must contain exactly the model parameter names")
    values = {name: _strict_real_scalar(parameters[name], f"{label} {name}") for name in PARAM_NAMES}
    payload = "\n".join(f"{name}={values[name].hex()}" for name in PARAM_NAMES)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _validated_v04_initial_state_gate(
    value: Any,
    *,
    expected_parameter_fingerprint: str,
    label: str,
) -> tuple[dict[str, Any], bool]:
    record = _v04_exact_mapping(
        value,
        _INITIAL_STATE_CONVERGENCE_RESULT_FIELDS,
        label,
    )
    if record["scenario_ids"] != ["dry", "wet"]:
        raise ValueError(f"{label} scenario_ids must be exactly ['dry', 'wet']")
    if record["parameter_sha256"] != expected_parameter_fingerprint:
        raise ValueError(f"{label} parameter fingerprint differs from the restart")

    par_k2 = _strict_real_scalar(record["par_k2"], f"{label} par_k2")
    if not 0.0 < par_k2 < 1.0:
        raise ValueError(f"{label} par_k2 must lie strictly between zero and one")
    warmup_days = _v04_required_integer(record, "warmup_days", label)
    if warmup_days <= 0:
        raise ValueError(f"{label} warmup_days must be positive")
    initial_difference = _strict_real_scalar(
        record["initial_slz_difference_mm"],
        f"{label} initial_slz_difference_mm",
    )
    final_difference = _strict_real_scalar(
        record["final_slz_difference_mm"],
        f"{label} final_slz_difference_mm",
    )
    analytical = _strict_real_scalar(
        record["analytical_retained_fraction"],
        f"{label} analytical_retained_fraction",
    )
    replayed = _strict_real_scalar(
        record["replayed_retained_fraction"],
        f"{label} replayed_retained_fraction",
    )
    retained_maximum = _strict_real_scalar(
        record["retained_fraction_max"],
        f"{label} retained_fraction_max",
    )
    if initial_difference != 100.0 or final_difference < 0.0:
        raise ValueError(f"{label} lower-zone storage differences are invalid")
    expected_analytical = (1.0 - par_k2) ** warmup_days
    if not np.isclose(analytical, expected_analytical, rtol=0.0, atol=1e-12):
        raise ValueError(f"{label} analytical retained fraction differs from recomputation")
    if not np.isclose(replayed, final_difference / initial_difference, rtol=0.0, atol=1e-12):
        raise ValueError(f"{label} replayed retained fraction differs from recomputation")
    if not 0.0 < retained_maximum < 1.0:
        raise ValueError(f"{label} retained_fraction_max must lie between zero and one")

    analytical_pass = _required_boolean_field(
        record,
        "analytical_retained_fraction_pass",
        label,
    )
    replayed_pass = _required_boolean_field(
        record,
        "replayed_retained_fraction_pass",
        label,
    )
    retained_matches = _required_boolean_field(
        record,
        "retained_fraction_matches_analytical",
        label,
    )
    if analytical_pass != (analytical <= retained_maximum):
        raise ValueError(f"{label} analytical retained-fraction boolean differs from its value")
    if replayed_pass != (replayed <= retained_maximum):
        raise ValueError(f"{label} replayed retained-fraction boolean differs from its value")
    expected_matches = bool(np.isclose(replayed, analytical, rtol=1e-10, atol=1e-12))
    if retained_matches != expected_matches:
        raise ValueError(f"{label} retained-fraction match boolean differs from recomputation")

    raw_output_gate = _v04_exact_mapping(
        record["output_functional_distance_gate"],
        {"maximum_distance", "all_three_day_sets_required", "day_sets", "passes"},
        f"{label} output functional distance gate",
    )
    maximum_distance = _strict_real_scalar(
        raw_output_gate["maximum_distance"],
        f"{label} output functional distance maximum",
    )
    day_sets = raw_output_gate["day_sets"]
    if not isinstance(day_sets, Mapping) or set(day_sets) != set(OBJECTIVES):
        raise ValueError(f"{label} output day sets must contain exactly {sorted(OBJECTIVES)}")
    low_record = day_sets["low_flow"]
    if not isinstance(low_record, Mapping):
        raise ValueError(f"{label} low-flow output distance must be a mapping")
    log_offset = _strict_real_scalar(
        low_record.get("log_offset"),
        f"{label} low-flow log offset",
    )
    recomputed_output_gate = _validated_output_functional_distance_gate(
        {"output_functional_distances": day_sets},
        maximum_distance=maximum_distance,
        flow_log_offset_mm_day=log_offset,
        label=label,
    )
    _require_strict_recomputed_value(
        raw_output_gate,
        recomputed_output_gate,
        f"{label}.output_functional_distance_gate",
    )
    passes = _required_boolean_field(record, "passes", label)
    expected_passes = bool(
        analytical_pass
        and replayed_pass
        and retained_matches
        and recomputed_output_gate["passes"]
    )
    if passes != expected_passes:
        raise ValueError(f"{label} passes differs from its component booleans")
    return dict(record), passes


def _validated_v04_hydrograph_gate(value: Any, *, label: str) -> tuple[dict[str, Any], bool]:
    record = _v04_exact_mapping(value, _HYDROGRAPH_RESPONSE_RESULT_FIELDS, label)
    thresholds = _v04_exact_mapping(
        record["thresholds"],
        _HYDROGRAPH_RESPONSE_THRESHOLD_FIELDS,
        f"{label} thresholds",
    )
    checked_thresholds = {
        name: _strict_real_scalar(raw, f"{label} threshold {name}")
        for name, raw in thresholds.items()
    }
    for prefix in ("variability_ratio", "mean_ratio", "total_variation_ratio"):
        if not 0.0 < checked_thresholds[f"{prefix}_min"] <= checked_thresholds[f"{prefix}_max"]:
            raise ValueError(f"{label} {prefix} thresholds are invalid")
    if checked_thresholds["mean_offset"] <= 0.0:
        raise ValueError(f"{label} mean_offset must be positive")

    water_years = record["water_years"]
    if not isinstance(water_years, list) or not water_years:
        raise ValueError(f"{label} water_years must be a nonempty list")
    checked_years = []
    water_year_passes = []
    for position, raw_year in enumerate(water_years):
        year_label = f"{label} water year {position}"
        year = _v04_exact_mapping(
            raw_year,
            _HYDROGRAPH_RESPONSE_WATER_YEAR_FIELDS,
            year_label,
        )
        water_year = _v04_required_integer(year, "water_year", year_label)
        day_count = _v04_required_integer(year, "day_count", year_label)
        if day_count not in (365, 366):
            raise ValueError(f"{year_label} day_count must describe a complete water year")
        checked_years.append(water_year)
        component_passes = []
        for prefix in ("variability_ratio", "mean_ratio", "total_variation_ratio"):
            ratio = _strict_real_scalar(year[prefix], f"{year_label} {prefix}")
            minimum = _strict_real_scalar(year[f"{prefix}_min"], f"{year_label} {prefix}_min")
            maximum = _strict_real_scalar(year[f"{prefix}_max"], f"{year_label} {prefix}_max")
            if minimum != checked_thresholds[f"{prefix}_min"]:
                raise ValueError(f"{year_label} {prefix}_min differs from the gate threshold")
            if maximum != checked_thresholds[f"{prefix}_max"]:
                raise ValueError(f"{year_label} {prefix}_max differs from the gate threshold")
            recorded_pass = _required_boolean_field(year, f"{prefix}_pass", year_label)
            expected_pass = minimum <= ratio <= maximum
            if recorded_pass != expected_pass:
                raise ValueError(f"{year_label} {prefix}_pass differs from its ratio")
            component_passes.append(recorded_pass)
        mean_offset = _strict_real_scalar(year["mean_offset"], f"{year_label} mean_offset")
        if mean_offset != checked_thresholds["mean_offset"]:
            raise ValueError(f"{year_label} mean_offset differs from the gate threshold")
        for field in (
            "observed_mean",
            "simulated_mean",
            "observed_standard_deviation",
            "simulated_standard_deviation",
            "observed_total_variation",
            "simulated_total_variation",
        ):
            _strict_real_scalar(year[field], f"{year_label} {field}")
        year_pass = _required_boolean_field(year, "passes", year_label)
        if year_pass != all(component_passes):
            raise ValueError(f"{year_label} passes differs from its component booleans")
        water_year_passes.append(year_pass)
    if checked_years != sorted(set(checked_years)):
        raise ValueError(f"{label} water-year identities must be unique and ordered")
    passes = _required_boolean_field(record, "passes", label)
    if passes != all(water_year_passes):
        raise ValueError(f"{label} passes differs from its water-year booleans")
    return dict(record), passes


def apply_parameter_quality_gates_v04(
    calibrations: Mapping[str, Mapping[str, Any]],
    evaluations: Mapping[str, Mapping[str, Any]],
    validation_gates: Mapping[str, Mapping[str, Any]],
    parameter_bounds: Mapping[str, Sequence[float]],
    *,
    generalist_nse_min: float = 0.30,
    support_fit_loss_ratio_max: float = 1.05,
    support_output_functional_distance_max: float = 0.03,
    diagnostic_parameter_distance_reference: float = 0.20,
    flow_log_offset_mm_day: float = 0.01,
    maximum_near_boundary_parameters: int = 2,
    maximum_strongly_saturated_parameters: int = 1,
    minimum_support_restarts: int = 1,
    support_target_relative_improvement_min: float = DEFAULT_TARGET_RELATIVE_IMPROVEMENT,
    support_minimum_improved_water_years: int = DEFAULT_MINIMUM_IMPROVED_WATER_YEARS,
    support_all_period_nse_drop_max: float = DEFAULT_MAXIMUM_ALL_PERIOD_NSE_DROP,
    support_opposite_regime_relative_degradation_max: float = DEFAULT_MAXIMUM_OPPOSITE_REGIME_LOSS_INCREASE,
    support_must_beat_other_specialist: bool = True,
) -> dict[str, Any]:
    """Add initial-state and hydrograph-response gates to unchanged v03 decisions."""

    result = apply_parameter_quality_gates_v03(
        calibrations,
        evaluations,
        validation_gates,
        parameter_bounds,
        generalist_nse_min=generalist_nse_min,
        support_fit_loss_ratio_max=support_fit_loss_ratio_max,
        support_output_functional_distance_max=support_output_functional_distance_max,
        diagnostic_parameter_distance_reference=diagnostic_parameter_distance_reference,
        flow_log_offset_mm_day=flow_log_offset_mm_day,
        maximum_near_boundary_parameters=maximum_near_boundary_parameters,
        maximum_strongly_saturated_parameters=maximum_strongly_saturated_parameters,
        minimum_support_restarts=minimum_support_restarts,
        support_target_relative_improvement_min=support_target_relative_improvement_min,
        support_minimum_improved_water_years=support_minimum_improved_water_years,
        support_all_period_nse_drop_max=support_all_period_nse_drop_max,
        support_opposite_regime_relative_degradation_max=(
            support_opposite_regime_relative_degradation_max
        ),
        support_must_beat_other_specialist=support_must_beat_other_specialist,
    )
    result["v03_quality_gate_version"] = result.get("quality_gate_version")
    result["quality_gate_version"] = "v04_initial_state_and_hydrograph_response"

    for name in OBJECTIVES:
        evaluation = evaluations[name]
        source_restarts = evaluation.get("restart_metrics", [])
        if not isinstance(source_restarts, Sequence) or isinstance(source_restarts, (str, bytes)):
            raise ValueError(f"{name} restart_metrics must be a sequence")
        group = result[name]
        restart_diagnostics = group.get("restart_diagnostics")
        if not isinstance(restart_diagnostics, list) or len(restart_diagnostics) != len(source_restarts):
            raise ValueError(f"{name} v03 restart diagnostics do not match restart_metrics")

        calibration = calibrations[name]
        selected_parameters = calibration.get("optimized_params")
        if not isinstance(selected_parameters, Mapping):
            raise ValueError(f"{name} calibration must contain optimized_params")
        selected_fit_loss = float(calibration.get("objective_loss", float("nan")))
        selected_position = _selected_restart_position(
            source_restarts,
            selected_parameters,
            selected_fit_loss,
            name,
        )
        selected_found = _required_boolean_field(
            group,
            "selected_restart_record_found_pass",
            f"{name} v03 group",
        )
        if selected_found != (selected_position is not None):
            raise ValueError(f"{name} selected restart identity differs from the v03 result")

        convergence_passes = []
        response_passes = []
        rebuilt_support = []
        for position, (source_restart, diagnostic) in enumerate(
            zip(source_restarts, restart_diagnostics, strict=True)
        ):
            if not isinstance(source_restart, Mapping) or not isinstance(diagnostic, Mapping):
                raise ValueError(f"{name} restart {position} evidence must be mappings")
            restart_index = _v04_required_integer(source_restart, "restart_index", f"{name} restart {position}")
            seed = _v04_required_integer(source_restart, "seed", f"{name} restart {position}")
            diagnostic_index = _v04_required_integer(
                diagnostic,
                "restart_index",
                f"{name} v03 restart {position}",
            )
            diagnostic_seed = _v04_required_integer(
                diagnostic,
                "seed",
                f"{name} v03 restart {position}",
            )
            if (restart_index, seed) != (diagnostic_index, diagnostic_seed):
                raise ValueError(f"{name} restart {position} identity differs from the v03 diagnostic")
            restart_parameters = source_restart.get("optimized_params")
            if not isinstance(restart_parameters, Mapping):
                raise ValueError(f"{name} restart {position} must contain optimized_params")
            fingerprint = _v04_parameter_sha256(
                restart_parameters,
                f"{name} restart {position} parameters",
            )
            if "initial_state_convergence_diagnostics" not in source_restart:
                raise ValueError(
                    f"{name} restart {position} must contain initial_state_convergence_diagnostics"
                )
            if "hydrograph_response_diagnostics" not in source_restart:
                raise ValueError(f"{name} restart {position} must contain hydrograph_response_diagnostics")
            convergence_gate, convergence_pass = _validated_v04_initial_state_gate(
                source_restart["initial_state_convergence_diagnostics"],
                expected_parameter_fingerprint=fingerprint,
                label=f"{name} restart {position} initial-state convergence diagnostics",
            )
            response_gate, response_pass = _validated_v04_hydrograph_gate(
                source_restart["hydrograph_response_diagnostics"],
                label=f"{name} restart {position} hydrograph response diagnostics",
            )
            v03_support = _required_boolean_field(
                diagnostic,
                "qualifies_as_support",
                f"{name} v03 restart {position}",
            )
            diagnostic["v03_qualifies_as_support"] = v03_support
            diagnostic["initial_state_convergence_gate"] = convergence_gate
            diagnostic["initial_state_convergence_pass"] = convergence_pass
            diagnostic["hydrograph_response_gate"] = response_gate
            diagnostic["hydrograph_response_pass"] = response_pass
            diagnostic["qualifies_as_support"] = bool(
                v03_support and convergence_pass and response_pass
            )
            convergence_passes.append(convergence_pass)
            response_passes.append(response_pass)
            if diagnostic["qualifies_as_support"]:
                rebuilt_support.append(diagnostic)

        required_support = _v04_required_integer(
            group,
            "minimum_support_restarts",
            f"{name} v03 group",
        )
        if required_support < 1:
            raise ValueError(f"{name} minimum_support_restarts must be at least one")
        v03_qualifies = _required_boolean_field(group, "qualifies", f"{name} v03 group")
        group["v03_qualifies"] = v03_qualifies
        group["v03_support_restart_count"] = group.get("support_restart_count")
        group["v03_support_restart_pass"] = group.get("support_restart_pass")
        group["support_restarts"] = rebuilt_support
        group["support_restart_count"] = len(rebuilt_support)
        group["support_restart_pass"] = bool(len(rebuilt_support) >= required_support)
        group["selected_initial_state_convergence_pass"] = bool(
            selected_position is not None and convergence_passes[selected_position]
        )
        group["selected_hydrograph_response_pass"] = bool(
            selected_position is not None and response_passes[selected_position]
        )
        group["qualifies"] = bool(
            v03_qualifies
            and group["selected_initial_state_convergence_pass"]
            and group["selected_hydrograph_response_pass"]
            and group["support_restart_pass"]
        )

    result["all_specialists_qualify"] = bool(
        result["low_flow"]["qualifies"] and result["high_flow"]["qualifies"]
    )
    result["all_parameter_sets_qualify"] = bool(
        result["all_flow"]["qualifies"] and result["all_specialists_qualify"]
    )
    return result


__all__ = [
    "OBJECTIVES",
    "FlowThresholds",
    "fit_flow_thresholds",
    "build_regime_masks",
    "regime_water_year_coverage",
    "apply_regime_coverage_policy",
    "parameter_boundary_diagnostics",
    "normalized_parameter_distance",
    "output_functional_distance",
    "calibrate_parameter_sets",
    "evaluate_parameter_sets",
    "apply_validation_gates",
    "apply_parameter_quality_gates",
    "apply_parameter_quality_gates_v03",
    "apply_parameter_quality_gates_v04",
    "initial_state_convergence_diagnostics",
    "hydrograph_response_diagnostics",
    "warmup_memory_compatibility",
]
