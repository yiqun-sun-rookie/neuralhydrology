"""Forecast metrics for the joint param-noise real-case line.

Implements Task 4 of docs/superpowers/plans/2026-08-25-joint-param-noise-real-case-runner.md:
point skill (Nash-Sutcliffe efficiency), probabilistic skill (continuous ranked probability
score of the daily Gaussian-mixture predictive distribution, closed form after
Grimit et al. 2006), and probabilistic calibration (probability integral transform with a
uniformity index).  All functions recompute from persisted daily arrays only, so they double
as the independent recomputation path required by the evidence contract.
"""
from __future__ import annotations

import numpy as np
from scipy.special import erf

_SQRT_2 = np.sqrt(2.0)
_SQRT_PI = np.sqrt(np.pi)


def nash_sutcliffe(observed: np.ndarray, forecast: np.ndarray) -> float:
    observed_values = np.asarray(observed, dtype=np.float64)
    forecast_values = np.asarray(forecast, dtype=np.float64)
    if observed_values.shape != forecast_values.shape or observed_values.ndim != 1:
        raise ValueError("observed and forecast must be one-dimensional and aligned")
    anomaly = observed_values - observed_values.mean()
    denominator = float(np.sum(anomaly**2))
    if denominator <= 0.0:
        return float("nan")
    return 1.0 - float(np.sum((observed_values - forecast_values) ** 2)) / denominator


def _validate_mixture(
    means: np.ndarray, variances: np.ndarray, weights: np.ndarray, observed: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    mean_values = np.asarray(means, dtype=np.float64)
    variance_values = np.asarray(variances, dtype=np.float64)
    weight_values = np.asarray(weights, dtype=np.float64)
    observed_values = np.asarray(observed, dtype=np.float64)
    if mean_values.ndim != 2:
        raise ValueError("means must have shape (n_days, n_components)")
    if variance_values.shape != mean_values.shape or weight_values.shape != mean_values.shape:
        raise ValueError("variances and weights must match the means shape")
    if observed_values.shape != (mean_values.shape[0],):
        raise ValueError("observed must have one value per day")
    if np.any(variance_values <= 0.0):
        raise ValueError("mixture variances must be positive")
    if not np.allclose(weight_values.sum(axis=1), 1.0, atol=1e-9) or np.any(weight_values < -1e-12):
        raise ValueError("mixture weights must be nonnegative and sum to one per day")
    return mean_values, variance_values, weight_values, observed_values


def _crps_kernel(delta: np.ndarray, variance: np.ndarray) -> np.ndarray:
    """A(delta, variance) = delta*(2*Phi(delta/sigma)-1) + 2*sigma*phi(delta/sigma)."""
    sigma = np.sqrt(variance)
    z = delta / sigma
    pdf = np.exp(-0.5 * z * z) / np.sqrt(2.0 * np.pi)
    cdf = 0.5 * (1.0 + erf(z / _SQRT_2))
    return delta * (2.0 * cdf - 1.0) + 2.0 * sigma * pdf


def mixture_crps(
    means: np.ndarray, variances: np.ndarray, weights: np.ndarray, observed: np.ndarray
) -> np.ndarray:
    """Daily CRPS of the Gaussian-mixture predictive distribution (closed form)."""
    mean_values, variance_values, weight_values, observed_values = _validate_mixture(
        means, variances, weights, observed
    )
    first = np.sum(
        weight_values * _crps_kernel(observed_values[:, None] - mean_values, variance_values),
        axis=1,
    )
    pair_delta = mean_values[:, :, None] - mean_values[:, None, :]
    pair_variance = variance_values[:, :, None] + variance_values[:, None, :]
    pair_weight = weight_values[:, :, None] * weight_values[:, None, :]
    second = np.sum(pair_weight * _crps_kernel(pair_delta, pair_variance), axis=(1, 2))
    return first - 0.5 * second


def mixture_pit(
    means: np.ndarray, variances: np.ndarray, weights: np.ndarray, observed: np.ndarray
) -> np.ndarray:
    """Daily probability integral transform of the observation under the mixture."""
    mean_values, variance_values, weight_values, observed_values = _validate_mixture(
        means, variances, weights, observed
    )
    z = (observed_values[:, None] - mean_values) / np.sqrt(variance_values)
    return np.sum(weight_values * 0.5 * (1.0 + erf(z / _SQRT_2)), axis=1)


def pit_calibration_index(pit_values: np.ndarray) -> float:
    """Mean absolute deviation of sorted PIT values from the uniform quantiles.

    Zero for a perfectly calibrated forecast; larger is worse.
    """
    values = np.sort(np.asarray(pit_values, dtype=np.float64))
    if values.ndim != 1 or len(values) == 0:
        raise ValueError("pit_values must be a nonempty one-dimensional array")
    uniform = (np.arange(1, len(values) + 1) - 0.5) / len(values)
    return float(np.mean(np.abs(values - uniform)))


def summarize_arm(
    observed: np.ndarray,
    candidate_means: np.ndarray,
    candidate_variances: np.ndarray,
    weights: np.ndarray,
) -> dict[str, float | int]:
    """Point, probabilistic, and calibration summary for one arm's scored days."""
    point_forecast = np.sum(np.asarray(weights) * np.asarray(candidate_means), axis=1)
    crps = mixture_crps(candidate_means, candidate_variances, weights, observed)
    pit = mixture_pit(candidate_means, candidate_variances, weights, observed)
    return {
        "nse": nash_sutcliffe(observed, point_forecast),
        "mean_crps": float(np.mean(crps)),
        "pit_calibration_index": pit_calibration_index(pit),
        "n_days": int(len(np.asarray(observed))),
    }
