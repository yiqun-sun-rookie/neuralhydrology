"""Create auditable probability figures for the balanced six-cell replay.

The script reads only the completed formal evidence.  It does not change any
registered metric, decision, or gate.  The late-window figure uses the exact
precomputed basin-bootstrap decision summary; the time-window and allocation
figures are explicitly descriptive transformations of verified raw evidence.

Usage:
    python -X utf8 -m camels_switch_confirmation.plot_joint_balanced_replay
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd

from camels_switch_confirmation.joint_balanced_replay import (
    CONFIG_PATH,
    load_registered_config,
    sha256_file,
)


REPO_ROOT = Path(__file__).resolve().parents[2]
WINDOW_ORDER = (
    "days_001_007",
    "days_008_030",
    "days_031_090",
    "days_091_180",
)
WINDOW_LABELS = ("第1–7天", "第8–30天", "第31–90天", "第91–180天")
PARAMETER_FACTORS = (1.0, 0.5)
PROCESS_NOISE_MULTIPLIERS = (1.0, 0.1, 10.0)
CELL_PAIRS = tuple(
    (parameter, noise)
    for parameter in range(len(PARAMETER_FACTORS))
    for noise in range(len(PROCESS_NOISE_MULTIPLIERS))
)
CELL_LABELS = tuple(
    f"格{cell}\n容量×{PARAMETER_FACTORS[parameter]:g}\n噪声×{PROCESS_NOISE_MULTIPLIERS[noise]:g}"
    for cell, (parameter, noise) in enumerate(CELL_PAIRS)
)
MODE_COLOURS = {
    "joint_unknown": "#0072B2",
    "noise_known": "#D55E00",
    "param_known": "#D55E00",
}
MODE_LABELS = {
    "joint_unknown": "两轴均未知",
    "noise_known": "过程噪声已知",
    "param_known": "参数已知",
}
ALGORITHM_MARKERS = {"C": "o", "P": "D"}
ALGORITHM_LABELS = {"C": "完整状态交互", "P": "成对路径交互后折叠"}
PLOT_FILENAMES = {
    "summary": "balanced_replay_probability_summary.png",
    "dynamics": "balanced_replay_probability_dynamics.png",
    "allocation": "balanced_replay_probability_allocation.png",
}

plt.rcParams.update({
    "font.sans-serif": ["Microsoft YaHei", "SimHei", "DejaVu Sans"],
    "axes.unicode_minus": False,
    "figure.dpi": 140,
    "savefig.dpi": 220,
    "axes.spines.top": False,
    "axes.spines.right": False,
})


def decision_gate_frame(decisions: dict) -> pd.DataFrame:
    """Flatten the registered absolute gates without recomputing decisions."""

    records = []
    for algorithm, payload in decisions["algorithms"].items():
        if not payload["overall_pass"]:
            raise ValueError(f"algorithm {algorithm} did not pass the registered decision")
        for record in payload["absolute_gates"]:
            row = dict(record)
            row["algorithm"] = algorithm
            records.append(row)
    frame = pd.DataFrame(records)
    required = {
        "algorithm",
        "axis",
        "knowledge_mode",
        "level",
        "probability_median",
        "probability_bootstrap_lower",
        "probability_bootstrap_upper",
        "pass",
    }
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"decision summary lacks columns: {sorted(missing)}")
    if not frame["pass"].all():
        raise ValueError("an absolute probability gate did not pass")
    return frame


def window_cell_summary(event_metrics: pd.DataFrame) -> pd.DataFrame:
    """Preserve event-to-cell-to-basin aggregation for descriptive windows."""

    metrics = ("joint_cell_true_probability", "joint_cell_argmax_accuracy")
    required = {
        "basin_id",
        "algorithm",
        "knowledge_mode",
        "window",
        "destination_cell",
        *metrics,
    }
    missing = required.difference(event_metrics.columns)
    if missing:
        raise ValueError(f"event metrics lack columns: {sorted(missing)}")
    selected = event_metrics[event_metrics["knowledge_mode"] == "joint_unknown"]
    basin_cell = (
        selected.groupby(
            [
                "basin_id",
                "algorithm",
                "window",
                "destination_cell",
            ],
            as_index=False,
        )[list(metrics)]
        .mean()
    )
    summary = (
        basin_cell.groupby(
            ["algorithm", "window", "destination_cell"], as_index=False
        )[list(metrics)]
        .median()
    )
    counts = (
        basin_cell.groupby(["algorithm", "window", "destination_cell"])[
            "basin_id"
        ]
        .nunique()
        .rename("basin_count")
        .reset_index()
    )
    return summary.merge(
        counts,
        on=["algorithm", "window", "destination_cell"],
        validate="one_to_one",
    )


def probability_allocation(
    paths: Iterable[Path], *, start_day: int = 90
) -> tuple[np.ndarray, np.ndarray]:
    """Average six posterior shares by true destination cell.

    Each returned row is an arithmetic mean over equally weighted event-days,
    so its six entries retain the defining probability-sum-to-one property.
    """

    sums = np.zeros((6, 6), dtype=np.float64)
    counts = np.zeros(6, dtype=np.int64)
    expected_parameter = np.asarray([0, 0, 0, 1, 1, 1])
    expected_noise = np.asarray([0, 1, 2, 0, 1, 2])
    for path in paths:
        with np.load(path, allow_pickle=False) as archive:
            probabilities = np.asarray(archive["probabilities"], dtype=np.float64)
            destination_cells = np.asarray(
                archive["destination_cell_indices"], dtype=np.int64
            )
            candidate_parameter = np.asarray(
                archive["candidate_param_indices"], dtype=np.int64
            )
            candidate_noise = np.asarray(
                archive["candidate_noise_indices"], dtype=np.int64
            )
        if probabilities.ndim != 3 or probabilities.shape[2] != 6:
            raise ValueError(f"unexpected probability shape in {path}: {probabilities.shape}")
        if start_day < 0 or start_day >= probabilities.shape[1]:
            raise ValueError("allocation start day is outside the replay window")
        if not np.allclose(probabilities.sum(axis=2), 1.0, rtol=0.0, atol=1e-12):
            raise ValueError(f"posterior probabilities do not sum to one in {path}")
        if not np.array_equal(candidate_parameter[:, 0], np.tile(expected_parameter, (len(destination_cells), 1))):
            raise ValueError(f"candidate parameter order changed in {path}")
        if not np.array_equal(candidate_noise[:, 0], np.tile(expected_noise, (len(destination_cells), 1))):
            raise ValueError(f"candidate process-noise order changed in {path}")
        for event_index, destination_cell in enumerate(destination_cells):
            values = probabilities[event_index, start_day:]
            sums[int(destination_cell)] += values.sum(axis=0)
            counts[int(destination_cell)] += len(values)
    if np.any(counts == 0):
        raise ValueError("at least one true destination cell has no allocation evidence")
    allocation = sums / counts[:, None]
    if not np.allclose(allocation.sum(axis=1), 1.0, rtol=0.0, atol=1e-12):
        raise ValueError("mean posterior-allocation rows do not sum to one")
    return allocation, counts


def _errorbar(axis, rows: pd.DataFrame, x_values: np.ndarray, *, colour: str, marker: str) -> None:
    values = rows["probability_median"].to_numpy(dtype=float)
    lower = rows["probability_bootstrap_lower"].to_numpy(dtype=float)
    upper = rows["probability_bootstrap_upper"].to_numpy(dtype=float)
    axis.errorbar(
        x_values,
        values,
        yerr=np.vstack([values - lower, upper - values]),
        fmt=marker,
        color=colour,
        markerfacecolor="white" if marker == "D" else colour,
        markeredgewidth=1.2,
        markersize=6.5,
        linewidth=1.3,
        capsize=3.5,
        zorder=3,
    )


def _plot_axis_probability(
    axis,
    gates: pd.DataFrame,
    *,
    probability_axis: str,
    modes: tuple[str, ...],
    levels: tuple[int, ...],
    level_labels: tuple[str, ...],
    chance: float,
    title: str,
    ylim: tuple[float, float],
) -> None:
    base = np.arange(len(levels), dtype=float)
    mode_offsets = np.linspace(-0.14, 0.14, len(modes)) if len(modes) > 1 else np.zeros(1)
    algorithm_offsets = {"C": -0.035, "P": 0.035}
    for mode, mode_offset in zip(modes, mode_offsets):
        for algorithm in ("C", "P"):
            rows = gates[
                (gates["axis"] == probability_axis)
                & (gates["knowledge_mode"] == mode)
                & (gates["algorithm"] == algorithm)
            ].set_index("level").loc[list(levels)]
            _errorbar(
                axis,
                rows,
                base + mode_offset + algorithm_offsets[algorithm],
                colour=MODE_COLOURS[mode],
                marker=ALGORITHM_MARKERS[algorithm],
            )
    axis.axhline(chance, color="#555555", linestyle="--", linewidth=1.2)
    axis.text(
        len(levels) - 0.55,
        chance + 0.015,
        f"随机概率 {chance:.3f}",
        color="#444444",
        fontsize=8.5,
        ha="right",
    )
    axis.set_xticks(base)
    axis.set_xticklabels(level_labels)
    axis.set_ylim(*ylim)
    axis.set_title(title, fontsize=12, fontweight="bold")
    axis.grid(axis="y", color="#dddddd", linewidth=0.7, alpha=0.7)


def plot_probability_summary(gates: pd.DataFrame, output_path: Path) -> None:
    """Plot exact late-window registered medians and bootstrap intervals."""

    figure, axes = plt.subplots(1, 3, figsize=(15.5, 5.5))
    _plot_axis_probability(
        axes[0],
        gates,
        probability_axis="parameter",
        modes=("joint_unknown", "noise_known"),
        levels=(0, 1),
        level_labels=("容量倍率 1.0", "容量倍率 0.5"),
        chance=0.5,
        title="A  真实参数候选的后验概率",
        ylim=(0.48, 1.025),
    )
    _plot_axis_probability(
        axes[1],
        gates,
        probability_axis="process_noise",
        modes=("joint_unknown", "param_known"),
        levels=(0, 1, 2),
        level_labels=("噪声倍率 1.0", "噪声倍率 0.1", "噪声倍率 10.0"),
        chance=1.0 / 3.0,
        title="B  真实过程噪声候选的后验概率",
        ylim=(0.29, 1.025),
    )
    _plot_axis_probability(
        axes[2],
        gates,
        probability_axis="joint_cell",
        modes=("joint_unknown",),
        levels=tuple(range(6)),
        level_labels=tuple(f"格{cell}\n({parameter:g}, {noise:g})" for cell, (parameter, noise) in enumerate(
            (
                (1.0, 1.0),
                (1.0, 0.1),
                (1.0, 10.0),
                (0.5, 1.0),
                (0.5, 0.1),
                (0.5, 10.0),
            )
        )),
        chance=1.0 / 6.0,
        title="C  真实联合格的后验概率",
        ylim=(0.12, 1.025),
    )
    axes[0].set_ylabel("真实候选获得的后验概率")
    colour_handles = [
        Line2D([0], [0], color=MODE_COLOURS[mode], linewidth=2.5, label=MODE_LABELS[mode])
        for mode in ("joint_unknown", "noise_known", "param_known")
    ]
    marker_handles = [
        Line2D(
            [0],
            [0],
            color="#333333",
            marker=ALGORITHM_MARKERS[algorithm],
            markerfacecolor="white" if algorithm == "P" else "#333333",
            linewidth=0,
            markersize=7,
            label=ALGORITHM_LABELS[algorithm],
        )
        for algorithm in ("C", "P")
    ]
    figure.legend(
        handles=colour_handles + marker_handles,
        loc="lower center",
        ncol=5,
        frameon=False,
        fontsize=9,
        bbox_to_anchor=(0.5, 0.005),
    )
    figure.suptitle(
        "切换后第91–180天：真实候选获得多少后验概率",
        fontsize=15,
        fontweight="bold",
    )
    figure.text(
        0.5,
        0.07,
        "点＝36个流域分数的中位数；竖线＝20,000次流域聚类自助抽样的两侧95%区间；虚线＝均匀随机概率",
        ha="center",
        fontsize=9,
        color="#444444",
    )
    figure.tight_layout(rect=(0, 0.14, 1, 0.93))
    figure.savefig(output_path, bbox_inches="tight")
    plt.close(figure)


def _annotated_heatmap(
    axis,
    values: np.ndarray,
    *,
    title: str,
    colorbar_label: str,
    vmin: float,
    vmax: float,
    xlabels: tuple[str, ...],
    ylabels: tuple[str, ...],
) -> None:
    image = axis.imshow(values, cmap="cividis", vmin=vmin, vmax=vmax, aspect="auto")
    for row in range(values.shape[0]):
        for column in range(values.shape[1]):
            value = float(values[row, column])
            colour = "white" if value < (vmin + vmax) / 2.0 else "black"
            axis.text(column, row, f"{value:.3f}", ha="center", va="center", color=colour, fontsize=9)
    axis.set_xticks(range(len(xlabels)))
    axis.set_xticklabels(xlabels)
    axis.set_yticks(range(len(ylabels)))
    axis.set_yticklabels(ylabels)
    axis.set_title(title, fontsize=12, fontweight="bold")
    colorbar = axis.figure.colorbar(image, ax=axis, fraction=0.046, pad=0.04)
    colorbar.set_label(colorbar_label)


def plot_probability_dynamics(summary: pd.DataFrame, output_path: Path) -> float:
    """Show probability and argmax accuracy as separate descriptive quantities."""

    complete = summary[summary["algorithm"] == "C"]
    pairwise = summary[summary["algorithm"] == "P"]
    if set(complete["basin_count"]) != {36} or set(pairwise["basin_count"]) != {36}:
        raise ValueError("descriptive time-window summaries do not contain all 36 basins")
    matrices = []
    for metric in ("joint_cell_true_probability", "joint_cell_argmax_accuracy"):
        pivot = (
            complete.pivot(index="destination_cell", columns="window", values=metric)
            .reindex(index=range(6), columns=WINDOW_ORDER)
        )
        if pivot.isna().any().any():
            raise ValueError(f"time-window matrix is incomplete for {metric}")
        matrices.append(pivot.to_numpy(dtype=float))
    merged = complete.merge(
        pairwise,
        on=["window", "destination_cell"],
        suffixes=("_C", "_P"),
        validate="one_to_one",
    )
    maximum_probability_difference = float(
        (
            merged["joint_cell_true_probability_C"]
            - merged["joint_cell_true_probability_P"]
        )
        .abs()
        .max()
    )

    figure, axes = plt.subplots(1, 2, figsize=(13.8, 6.5), sharey=True)
    _annotated_heatmap(
        axes[0],
        matrices[0],
        title="A  真实联合格获得的后验概率",
        colorbar_label="后验概率",
        vmin=1.0 / 6.0,
        vmax=1.0,
        xlabels=WINDOW_LABELS,
        ylabels=CELL_LABELS,
    )
    _annotated_heatmap(
        axes[1],
        matrices[1],
        title="B  真实联合格是最大概率候选的天数比例",
        colorbar_label="判断准确率",
        vmin=0.0,
        vmax=1.0,
        xlabels=WINDOW_LABELS,
        ylabels=CELL_LABELS,
    )
    figure.suptitle(
        "切换后的概率增长与最大概率判断是两件不同的事",
        fontsize=15,
        fontweight="bold",
    )
    figure.text(
        0.5,
        0.02,
        (
            "图示完整状态交互实现；每格先平均每流域的5条入边，再取36流域中位数。"
            f"成对路径实现的对应后验概率最大绝对差为 {maximum_probability_difference:.2e}。"
        ),
        ha="center",
        fontsize=9,
        color="#444444",
    )
    figure.tight_layout(rect=(0, 0.06, 1, 0.93))
    figure.savefig(output_path, bbox_inches="tight")
    plt.close(figure)
    return maximum_probability_difference


def plot_probability_allocation(
    allocation: np.ndarray, counts: np.ndarray, output_path: Path
) -> None:
    """Show where the probability not assigned to the true cell goes."""

    figure, axis = plt.subplots(figsize=(10.8, 8.2))
    image = axis.imshow(allocation, cmap="Blues", vmin=0.0, vmax=1.0, aspect="equal")
    for row in range(6):
        for column in range(6):
            value = float(allocation[row, column])
            axis.text(
                column,
                row,
                f"{value * 100:.1f}%",
                ha="center",
                va="center",
                color="white" if value > 0.52 else "#111111",
                fontsize=10,
                fontweight="bold" if row == column else "normal",
            )
        axis.add_patch(
            Rectangle(
                (row - 0.5, row - 0.5),
                1,
                1,
                fill=False,
                edgecolor="#D55E00",
                linewidth=2.2,
            )
        )
    axis.set_xticks(range(6))
    axis.set_xticklabels(CELL_LABELS)
    axis.set_yticks(range(6))
    axis.set_yticklabels(CELL_LABELS)
    axis.set_xlabel("概率被分配给哪个候选格")
    axis.set_ylabel("真实目标格")
    axis.set_title(
        "切换后第91–180天：六个候选怎样分走总计100%的概率",
        fontsize=14,
        fontweight="bold",
        pad=14,
    )
    colorbar = figure.colorbar(image, ax=axis, fraction=0.046, pad=0.04)
    colorbar.set_label("平均后验概率")
    figure.text(
        0.5,
        0.02,
        (
            "每一行加总为100%；橙框是正确候选。图示完整状态交互实现，"
            f"每个真实格包含 {int(counts.min()):,} 个等权事件日；该图是描述性算术平均，不是科学判门统计量。"
        ),
        ha="center",
        fontsize=9,
        color="#444444",
    )
    figure.tight_layout(rect=(0, 0.055, 1, 1))
    figure.savefig(output_path, bbox_inches="tight")
    plt.close(figure)


def _write_plot_tables(
    output_dir: Path,
    gates: pd.DataFrame,
    window_summary: pd.DataFrame,
    allocation: np.ndarray,
    counts: np.ndarray,
) -> list[Path]:
    probability_columns = [
        "algorithm",
        "axis",
        "knowledge_mode",
        "level",
        "probability_reference",
        "probability_median",
        "probability_bootstrap_lower",
        "probability_bootstrap_upper",
        "argmax_accuracy_median",
        "argmax_accuracy_bootstrap_lower",
        "argmax_accuracy_bootstrap_upper",
        "basin_count",
        "pass",
    ]
    paths = [
        output_dir / "probability_summary_plot_data.csv",
        output_dir / "probability_dynamics_plot_data.csv",
        output_dir / "probability_allocation_plot_data.csv",
    ]
    gates[probability_columns].sort_values(
        ["axis", "knowledge_mode", "level", "algorithm"]
    ).to_csv(paths[0], index=False, lineterminator="\n")
    window_summary.sort_values(
        ["algorithm", "window", "destination_cell"]
    ).to_csv(paths[1], index=False, lineterminator="\n")
    allocation_frame = pd.DataFrame(
        allocation,
        columns=[f"candidate_cell_{cell}" for cell in range(6)],
    )
    allocation_frame.insert(0, "event_day_count", counts)
    allocation_frame.insert(0, "true_destination_cell", range(6))
    allocation_frame.to_csv(paths[2], index=False, lineterminator="\n")
    return paths


def create_figures(root: Path) -> dict:
    """Create three figures, their exact plot tables, and a hash manifest."""

    result_root = Path(root).resolve()
    verification_root = result_root / "verification"
    decision_path = verification_root / "decision_summary.json"
    event_path = verification_root / "event_metrics.csv"
    independent_path = verification_root / "independent_verification.json"
    for path in (decision_path, event_path, independent_path):
        if not path.is_file():
            raise FileNotFoundError(f"verified plotting input is missing: {path}")
    independent = json.loads(independent_path.read_text(encoding="utf-8"))
    if independent.get("status") != "PASS":
        raise ValueError("independent verification did not pass")
    decisions = json.loads(decision_path.read_text(encoding="utf-8"))
    gates = decision_gate_frame(decisions)
    events = pd.read_csv(event_path, dtype={"basin_id": str})
    if len(events) != 25_920:
        raise ValueError(f"event-metric row count changed: {len(events)}")
    window_summary = window_cell_summary(events)
    task_paths = sorted((result_root / "arms" / "C" / "joint_unknown").glob("*.npz"))
    if len(task_paths) != 216:
        raise ValueError(f"joint-unknown task count changed: {len(task_paths)}")
    allocation, counts = probability_allocation(task_paths, start_day=90)
    if set(counts) != {16_200}:
        raise ValueError(f"late-window event-day balance changed: {counts.tolist()}")

    output_dir = result_root / "figures"
    output_dir.mkdir(parents=True, exist_ok=True)
    figure_paths = {key: output_dir / value for key, value in PLOT_FILENAMES.items()}
    plot_probability_summary(gates, figure_paths["summary"])
    maximum_probability_difference = plot_probability_dynamics(
        window_summary, figure_paths["dynamics"]
    )
    plot_probability_allocation(allocation, counts, figure_paths["allocation"])
    table_paths = _write_plot_tables(
        output_dir, gates, window_summary, allocation, counts
    )

    input_paths = {
        "decision_summary": decision_path,
        "event_metrics": event_path,
        "independent_verification": independent_path,
        "frozen_configuration": REPO_ROOT / CONFIG_PATH,
        "plot_script": Path(__file__).resolve(),
    }
    artifact_paths = list(figure_paths.values()) + table_paths
    manifest = {
        "experiment_id": decisions["experiment_id"],
        "scientific_status": "descriptive_figures_only_no_gate_changed",
        "primary_window": decisions["primary_window"],
        "truth_bundle_count": decisions["truth_bundle_count"],
        "task_count": decisions["task_count"],
        "event_count": decisions["event_count"],
        "independent_verification_status": independent["status"],
        "probability_dynamics_algorithm": "C",
        "probability_dynamics_maximum_C_P_probability_difference": maximum_probability_difference,
        "probability_allocation_event_day_count_per_true_cell": counts.tolist(),
        "input_sha256": {
            name: sha256_file(path) for name, path in input_paths.items()
        },
        "artifact_sha256": {
            path.name: sha256_file(path) for path in artifact_paths
        },
    }
    manifest_path = output_dir / "probability_figure_manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return {"root": result_root, "figures": figure_paths, "manifest": manifest_path}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path)
    arguments = parser.parse_args()
    config = load_registered_config(REPO_ROOT, verify_hashes=True)
    root = (
        arguments.root
        if arguments.root is not None
        else REPO_ROOT / config["output_roots"]["local"]
    )
    payload = create_figures(root)
    print(json.dumps({
        "root": str(payload["root"]),
        "figures": {key: str(path) for key, path in payload["figures"].items()},
        "manifest": str(payload["manifest"]),
    }, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
