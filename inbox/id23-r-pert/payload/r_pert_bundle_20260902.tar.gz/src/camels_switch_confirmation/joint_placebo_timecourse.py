"""JOINT-X1 post-hoc DESCRIPTIVE diagnostic: within-stage time course of the placebos.

This module changes NO preregistered gate and carries NO claim.  It exists to
separate two mechanisms that both make a placebo uplift negative:

  transient recovery -- the switch run is re-learning the level it just left, so
      the gap is large at the start of the stage and closes; the parFC line
      already measured this asymmetry (capacity DECREASE detectable same day,
      capacity INCREASE median 13-37 days), and the parameter placebo stage is
      an increase (FC/2 -> FC).

  cross-axis contamination -- the marginal is being dragged by the OTHER axis,
      in which case the gap is roughly flat across the whole stage and does not
      close.

Read-only over existing npz artifacts; runs no filter.

Usage:
    python -X utf8 -m camels_switch_confirmation.joint_placebo_timecourse
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from camels_switch_confirmation.joint_param_noise_precheck import STAGE_DAYS
from camels_switch_confirmation.joint_paired_contrast import (
    PLACEBO_LEVEL,
    axis_truth_by_stage,
    marginals,
)
from camels_switch_confirmation.run_joint_param_noise_switch import (
    ARM_MODES,
    OUTPUT_ROOT,
)

EXCLUDED_STAGE = 0
QUARTER_DAYS = STAGE_DAYS // 4


def placebo_stages(axis: str) -> tuple:
    """Stage positions used as that axis's placebo (level 0, outside stage 0)."""
    truths = axis_truth_by_stage(axis)
    return tuple(position for position, truth in enumerate(truths)
                 if truth == PLACEBO_LEVEL and position != EXCLUDED_STAGE)


def _load_marginals(path):
    with np.load(path, allow_pickle=False) as archive:
        return marginals(archive["probabilities"])


def collect(root: Path, arms) -> pd.DataFrame:
    """Per (task, axis, placebo stage, quarter): mean switch-minus-null gap."""
    rows = []
    for arm in arms:
        switch_dir = root / "arms" / arm / "switch" / "probs"
        null_dir = root / "arms" / arm / "null" / "probs"
        for switch_path in sorted(switch_dir.glob("*.npz")):
            null_path = null_dir / switch_path.name
            if not null_path.exists():
                continue
            switch_param, switch_noise = _load_marginals(switch_path)
            null_param, null_noise = _load_marginals(null_path)
            basin, seed_tag = switch_path.stem.split("_s")
            for axis, switch_marginal, null_marginal in (
                    ("param", switch_param, null_param),
                    ("noise", switch_noise, null_noise)):
                for stage in placebo_stages(axis):
                    start = stage * STAGE_DAYS
                    for quarter in range(4):
                        days = np.arange(start + quarter * QUARTER_DAYS,
                                         start + (quarter + 1) * QUARTER_DAYS)
                        days = days[days < switch_marginal.shape[0]]
                        if not len(days):
                            continue
                        rows.append({
                            "basin_id": basin, "seed": int(seed_tag), "arm": arm,
                            "axis": axis, "stage": stage, "quarter": quarter,
                            "gap": float(switch_marginal[days, PLACEBO_LEVEL].mean()
                                         - null_marginal[days, PLACEBO_LEVEL].mean()),
                        })
    return pd.DataFrame(rows)


def summarise(frame: pd.DataFrame) -> dict:
    """Median gap per axis and quarter, plus a plain closing/flat reading."""
    result = {"quarter_days": QUARTER_DAYS, "axes": {}}
    for axis in ("param", "noise"):
        subset = frame[frame["axis"] == axis]
        if subset.empty:
            continue
        by_quarter = subset.groupby("quarter")["gap"].median()
        first = float(by_quarter.loc[0])
        last = float(by_quarter.loc[by_quarter.index.max()])
        result["axes"][axis] = {
            "placebo_stages": list(placebo_stages(axis)),
            "median_gap_by_quarter": {str(quarter): float(value)
                                      for quarter, value in by_quarter.items()},
            "first_quarter_median": first,
            "last_quarter_median": last,
            "closed_fraction": (float(1.0 - abs(last) / abs(first))
                                if abs(first) > 0 else None),
            "median_gap_by_stage": {
                str(stage): float(values.median())
                for stage, values in subset.groupby("stage")["gap"]},
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=str(OUTPUT_ROOT))
    parser.add_argument("--arms", nargs="*", default=list(ARM_MODES))
    arguments = parser.parse_args()
    root = Path(arguments.root)
    frame = collect(root, arguments.arms)
    if frame.empty:
        raise SystemExit(f"no paired tasks found under {root}")
    (root / "verification").mkdir(parents=True, exist_ok=True)
    frame.to_csv(root / "verification" / "placebo_timecourse.csv", index=False)
    summary = summarise(frame)
    with open(root / "verification" / "placebo_timecourse_summary.json", "w",
              encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
