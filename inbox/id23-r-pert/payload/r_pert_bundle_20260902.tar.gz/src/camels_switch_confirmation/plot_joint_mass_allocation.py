"""JOINT-X1 figure: where ALL nine cells' probability mass sits, day by day.

Descriptive only; changes no gate and carries no claim.  The three-row panel
plots the two marginals and the true cell; this one answers the remaining
question -- when the true cell only holds ~0.4, where does the other ~0.6 go?

Task means (not medians) are stacked so the nine bands sum to exactly 1.

Usage:  python -X utf8 -m camels_switch_confirmation.plot_joint_mass_allocation
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from camels_switch_confirmation.joint_param_noise_precheck import (
    N_CELLS,
    N_NOISE,
    SEQUENCE,
    STAGE_DAYS,
    cell_index,
)
from camels_switch_confirmation.run_joint_param_noise_switch import OUTPUT_ROOT

plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 130

CAPACITY_LABELS = ("正常容量", "半容量", "倍容量")
NOISE_LABELS = ("正常噪声", "很小噪声", "很大噪声")
# one hue per capacity row, three shades per noise column
BAND_COLOURS = (
    ("#0b3d6b", "#1b6ca8", "#7fb3d5"),
    ("#7b241c", "#c0392b", "#e6a29b"),
    ("#145a32", "#2e8b57", "#a3d9b1"),
)


def mean_allocation(root: Path, arm: str, scenario: str) -> np.ndarray:
    """Task-mean posterior for every cell; rows sum to one on every day."""
    stack = []
    for path in sorted((root / "arms" / arm / scenario / "probs").glob("*.npz")):
        with np.load(path, allow_pickle=False) as archive:
            stack.append(archive["probabilities"])
    return np.mean(np.stack(stack), axis=0)


def figure_allocation(root: Path, arm: str, out_path: Path):
    allocation = mean_allocation(root, arm, "switch")
    n_days = allocation.shape[0]
    days = np.arange(n_days)

    order, colours, labels = [], [], []
    for capacity in range(3):
        for noise in range(N_NOISE):
            order.append(cell_index(capacity, noise))
            colours.append(BAND_COLOURS[capacity][noise])
            labels.append(f"{CAPACITY_LABELS[capacity]}+{NOISE_LABELS[noise]}")

    figure, axis = plt.subplots(figsize=(12, 6.4))
    axis.stackplot(days, *[allocation[:, index] for index in order],
                   colors=colours, labels=labels, linewidth=0)

    true_share = np.concatenate([
        np.full(min(STAGE_DAYS, n_days - position * STAGE_DAYS),
                cell_index(*SEQUENCE[position]))
        for position in range(len(SEQUENCE))
        if position * STAGE_DAYS < n_days])
    axis.plot(days, allocation[days, true_share.astype(int)], color="black",
              linewidth=2.0, label="押在真格上的那一份")

    for position, cell in enumerate(SEQUENCE):
        start = position * STAGE_DAYS
        if start >= n_days:
            break
        axis.axvline(start, color="white", linewidth=1.2)
        axis.text(start + STAGE_DAYS / 2, 1.035,
                  f"真相：{CAPACITY_LABELS[cell[0]]}\n＋{NOISE_LABELS[cell[1]]}",
                  ha="center", va="bottom", fontsize=8)

    axis.set_xlim(0, n_days)
    axis.set_ylim(0, 1.0)
    axis.set_xlabel("天")
    axis.set_ylabel("押注比例（九格加起来＝1）")
    axis.set_title(f"九个格子的钱分别押在哪里（{arm} 臂，{allocation.shape[0]} 天，"
                   f"72 个任务的平均）", fontsize=12, pad=34)
    handles, legend_labels = axis.get_legend_handles_labels()
    axis.legend(handles[::-1], legend_labels[::-1], fontsize=8, ncol=2,
                loc="center left", bbox_to_anchor=(1.005, 0.5), framealpha=0.95)
    figure.tight_layout()
    figure.savefig(out_path, bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=str(OUTPUT_ROOT))
    parser.add_argument("--arm", default="C")
    arguments = parser.parse_args()
    root = Path(arguments.root)
    out_dir = root / "figures"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "joint_mass_allocation.png"
    figure_allocation(root, arguments.arm, out_path)
    print(out_path)


if __name__ == "__main__":
    main()
