"""Protected development runner for real-flow-regime parameter calibration.

The access contract is checked before ``load_camels_basin`` can read
discharge.  Successful artifacts are assembled and verified in a sibling
``.incomplete`` directory, then atomically renamed to their immutable final
directory. The available profiles produce development evidence only.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.metadata
import io
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time
import traceback
import uuid
from collections.abc import Mapping, Sequence
from contextlib import ExitStack, redirect_stderr, redirect_stdout
from dataclasses import asdict, dataclass, is_dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from hydroagent.data_loading import load_camels_basin
from scl_hydro.hbv_lite_numpy import PARAM_NAMES, resolve_hbv_bounds, simulate_hbv_lite

from camels_switch_confirmation import v03_execution_evidence, v04_execution_evidence
from camels_switch_confirmation.real_regime_parameter_calibration import (
    hydrograph_response_diagnostics,
    initial_state_convergence_diagnostics,
    output_functional_distance,
    warmup_memory_compatibility,
)


REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CONFIG = (
    REPO_ROOT
    / "src/camels_switch_confirmation/configs/real_regime_parameter_calibration_smoke_v01.json"
)
FORBIDDEN_START = date(1980, 1, 1)
FORBIDDEN_END = date(1989, 9, 30)
PERIOD_NAMES = ("warmup", "fit", "validation")
PARAMETER_IDS = ("all_flow", "low_flow", "high_flow")
FIT_SELECTED_FINGERPRINT = "fit_selected_parameter_sha256"
RESTART_FINGERPRINT = "restart_parameter_sha256"
HYDROGRAPH_FILENAME = "validation_hydrographs.csv"
HYDROGRAPH_COLUMNS = (
    "basin_id",
    "date",
    "observed_flow_mm_day",
    "general_parameter_flow_mm_day",
    "low_flow_parameter_flow_mm_day",
    "high_flow_parameter_flow_mm_day",
)
V03_RESTART_PARAMETER_COLUMNS = (
    "parameter_id",
    "restart_index",
    "seed",
    "selected",
    "fit_objective_loss",
    "parameter_sha256",
    *PARAM_NAMES,
)
V03_FIT_HYDROGRAPH_COLUMNS = (
    "parameter_id",
    "restart_index",
    "seed",
    "date",
    "observed_flow_mm_day",
    "simulated_flow_mm_day",
    "all_flow_member",
    "low_flow_member",
    "high_flow_member",
    "objective_member",
    "selected",
    "parameter_sha256",
)
V03_VALIDATION_HYDROGRAPH_COLUMNS = (
    "parameter_id",
    "restart_index",
    "seed",
    "date",
    "observed_flow_mm_day",
    "simulated_flow_mm_day",
    "all_flow_member",
    "low_flow_member",
    "high_flow_member",
    "selected",
    "parameter_sha256",
)
V03_FUNCTIONAL_METRIC_COLUMNS = (
    "parameter_id",
    "restart_index",
    "seed",
    "selected_restart_index",
    "selected_seed",
    "selected_parameter_sha256",
    "restart_parameter_sha256",
    "day_set",
    "numerator",
    "denominator",
    "distance",
    "fit_scale_count",
    "validation_compare_count",
    "transform",
    "log_offset",
    "maximum_distance",
    "passes",
    "fit_objective_loss",
    "selected_fit_objective_loss",
    "fit_loss_ratio",
    "fit_loss_ratio_max",
    "fit_loss_ratio_pass",
    "parameter_distance_diagnostic",
)
V04_INITIAL_HYDROGRAPH_COLUMNS = (
    "parameter_id",
    "restart_index",
    "seed",
    "selected",
    "scenario_id",
    "date",
    "observed_flow_mm_day",
    "simulated_flow_mm_day",
    "all_flow_member",
    "low_flow_member",
    "high_flow_member",
    "parameter_sha256",
)
V04_INITIAL_METRIC_COLUMNS = (
    "parameter_id",
    "restart_index",
    "seed",
    "selected",
    "parameter_sha256",
    "dry_scenario_id",
    "wet_scenario_id",
    "dry_initial_slz_mm",
    "wet_initial_slz_mm",
    "dry_final_slz_mm",
    "wet_final_slz_mm",
    "par_k2",
    "warmup_days",
    "initial_slz_difference_mm",
    "final_slz_difference_mm",
    "analytical_retained_fraction",
    "replayed_retained_fraction",
    "retained_fraction_max",
    "analytical_retained_fraction_pass",
    "replayed_retained_fraction_pass",
    "retained_fraction_matches_analytical",
    "day_set",
    "numerator",
    "denominator",
    "distance",
    "fit_scale_count",
    "validation_compare_count",
    "transform",
    "log_offset",
    "maximum_distance",
    "distance_pass",
    "initial_state_convergence_passes",
)
V04_RESPONSE_METRIC_COLUMNS = (
    "parameter_id",
    "restart_index",
    "seed",
    "selected",
    "parameter_sha256",
    "water_year",
    "day_count",
    "observed_mean",
    "simulated_mean",
    "observed_standard_deviation",
    "simulated_standard_deviation",
    "variability_ratio",
    "variability_ratio_min",
    "variability_ratio_max",
    "variability_ratio_pass",
    "mean_offset",
    "mean_ratio",
    "mean_ratio_min",
    "mean_ratio_max",
    "mean_ratio_pass",
    "observed_total_variation",
    "simulated_total_variation",
    "total_variation_ratio",
    "total_variation_ratio_min",
    "total_variation_ratio_max",
    "total_variation_ratio_pass",
    "passes",
)
V03_RESTART_EXECUTION_COLUMNS = v03_execution_evidence.RESTART_EXECUTION_COLUMNS
V03_LOCAL_RESTART_EXECUTION_COLUMNS = tuple(
    column
    for column in V03_RESTART_EXECUTION_COLUMNS
    if column not in {"run_instance_id", "basin_id"}
)
V03_EVIDENCE_FILENAMES = {
    "restart_parameter_vectors": "restart_parameter_vectors.csv",
    "fit_restart_hydrographs": "fit_restart_hydrographs.csv",
    "validation_restart_hydrographs": "validation_restart_hydrographs.csv",
    "functional_stability_metrics": "functional_stability_metrics.csv",
}
V04_DIAGNOSTIC_FILENAMES = {
    "initial_state_convergence_hydrographs": "initial_state_convergence_hydrographs.csv",
    "initial_state_convergence_metrics": "initial_state_convergence_metrics.csv",
    "hydrograph_response_metrics": "hydrograph_response_metrics.csv",
}
V03_LIFECYCLE_FILENAMES = (
    "restart_execution.csv",
    "run_manifest.json",
    "run_events.jsonl",
    "stdout.log",
    "stderr.log",
    "python_packages.txt",
    "conda_explicit.txt",
)
RESULT_FILENAMES = frozenset(
    {
        "config_snapshot.json",
        "basin_manifest_snapshot.csv",
        "parameter_vectors.csv",
        "fit_metrics.csv",
        "validation_metrics.csv",
        "summary.json",
        "environment.json",
        "git_status.txt",
        "checksums.json",
    }
)
DISALLOWED_SUMMARY_TERMS = ("formal", "confirmation", "scientific_pass")
SCREEN_BASIN_IDS = ("04015330", "08109700", "11481200")
SCREEN_PERIODS = {
    "warmup": (date(1998, 10, 1), date(1999, 9, 30)),
    "fit": (date(1999, 10, 1), date(2005, 9, 30)),
    "validation": (date(2005, 10, 1), date(2008, 9, 30)),
}
SCREEN_INPUT_MANIFEST = (
    "docs/plans/2026-08-10-camels-parfc-state-interaction-design90-input-manifest-v01.csv"
)
SCREEN_INPUT_MANIFEST_SHA256 = "e9214738c64ba35800d06d4c6c07d1a3f31e5615cfefc9e1e55ae99ea3b3818b"
SCREEN_TOPOGRAPHY_FILE = "data/camels_us/camels_attributes_v2.0/camels_topo.txt"
SCREEN_TOPOGRAPHY_SHA256 = "b64ca9923bcaccf21dde33137903797919e8d6732edd7849f8534e0ddcbec8e8"
SCREEN_BASIN_AREAS_KM2 = {"04015330": 224.35, "08109700": 610.13, "11481200": 105.4}
SCREEN_V02_EXPERIMENT_ID = "real_regime_parameter_calibration_development_screen_v02"
SCREEN_V03_EXPERIMENT_ID = "real_regime_parameter_calibration_development_screen_v03"
SCREEN_V04_EXPERIMENT_ID = "real_regime_parameter_calibration_development_screen_v04"
SCREEN_V05_EXPERIMENT_ID = "real_regime_parameter_calibration_development_screen_v05"
SCREEN_V04_PERIODS = {
    "warmup": (date(1989, 10, 1), date(1999, 9, 30)),
    "fit": SCREEN_PERIODS["fit"],
    "validation": SCREEN_PERIODS["validation"],
}
V04_PARAMETER_BOUNDS_PRESET = "real_regime_physical_v04"
V05_PARAMETER_BOUNDS_PRESET = "real_regime_k2_memory_v05"
V04_WARMUP_DAYS = 3652
V04_RETAINED_FRACTION_MAX = 0.05
SCREEN_V02_COVERAGE_POLICY = {
    "policy": "aggregate_and_multi_year_support_v02",
    "fit": {
        "minimum_total_target_days": 180,
        "minimum_qualifying_water_years": 4,
        "expected_water_years": 6,
    },
    "validation": {
        "minimum_total_target_days": 90,
        "minimum_qualifying_water_years": 2,
        "expected_water_years": 3,
    },
}
EXECUTION_PROFILES: dict[str, dict[str, Any]] = {
    "development_smoke": {
        "scope": "technical_infrastructure_only",
        "basin_count": 1,
        "function_evaluations_per_restart": 64,
        "restart_seeds": (42, 1042),
        "forcing": "maurer",
        "pet_method": "priestley_taylor",
        "parameter_bounds_preset": "v1",
        "routing_kernel": "rising",
        "data_root": "data/camels_us",
        "terminal_status": "verified_technical",
        "strict_streamflow_window": True,
    },
    "development_screen": {
        "scope": "parameter_quality_development_only",
        "basin_count": 3,
        "function_evaluations_per_restart": 5000,
        "restart_seeds": (42, 1042, 2042),
        "forcing": "maurer",
        "pet_method": "oudin",
        "parameter_bounds_preset": "v5",
        "routing_kernel": "rising",
        "data_root": "data/camels_us",
        "terminal_status": "verified_development",
        "strict_streamflow_window": True,
    },
}


def _is_v03_config(config: Mapping[str, Any]) -> bool:
    identifier = str(config.get("experiment_id", ""))
    return identifier == SCREEN_V03_EXPERIMENT_ID or identifier.startswith(
        SCREEN_V03_EXPERIMENT_ID + "_"
    )


def _is_v04_config(config: Mapping[str, Any]) -> bool:
    identifier = str(config.get("experiment_id", ""))
    return identifier == SCREEN_V04_EXPERIMENT_ID or identifier.startswith(
        SCREEN_V04_EXPERIMENT_ID + "_"
    )


def _is_v05_config(config: Mapping[str, Any]) -> bool:
    identifier = str(config.get("experiment_id", ""))
    return identifier == SCREEN_V05_EXPERIMENT_ID or identifier.startswith(
        SCREEN_V05_EXPERIMENT_ID + "_"
    )


def _uses_restart_evidence(config: Mapping[str, Any]) -> bool:
    return _is_v03_config(config) or _is_v04_config(config) or _is_v05_config(config)


def _uses_initialization_response_diagnostics(config: Mapping[str, Any]) -> bool:
    return _is_v04_config(config) or _is_v05_config(config)


def _parameter_bounds_preset_for(config: Mapping[str, Any]) -> str:
    if _is_v05_config(config):
        return V05_PARAMETER_BOUNDS_PRESET
    if _is_v04_config(config):
        return V04_PARAMETER_BOUNDS_PRESET
    return str(config.get("parameter_bounds_preset", ""))


def _execution_evidence_for(config: Mapping[str, Any]) -> Any | None:
    if _is_v05_config(config):
        from camels_switch_confirmation import v05_execution_evidence

        return v05_execution_evidence
    if _is_v04_config(config):
        return v04_execution_evidence
    return None


def _validate_v04_warmup_memory_compatibility(
    config: Mapping[str, Any],
    periods: Mapping[str, tuple[date, date]],
) -> dict[str, Any]:
    """Fail closed unless the fourth-version fixed warmup clears memory."""

    if not _is_v04_config(config):
        raise ValueError("fourth-version warmup-memory validation requires a v04 experiment")
    if str(config.get("parameter_bounds_preset", "")) != V04_PARAMETER_BOUNDS_PRESET:
        raise ValueError(
            f"parameter_bounds_preset must remain {V04_PARAMETER_BOUNDS_PRESET!r}"
        )
    if dict(periods) != SCREEN_V04_PERIODS:
        raise ValueError(
            "fourth-version warmup, fit, and validation dates must remain frozen"
        )
    warmup_start, warmup_end = periods["warmup"]
    warmup_days = (warmup_end - warmup_start).days + 1
    if warmup_days != V04_WARMUP_DAYS:
        raise ValueError(f"fourth-version warmup must contain exactly {V04_WARMUP_DAYS} days")
    gate = warmup_memory_compatibility(
        resolve_hbv_bounds(V04_PARAMETER_BOUNDS_PRESET),
        warmup_days,
        retained_fraction_max=V04_RETAINED_FRACTION_MAX,
    )
    passes = gate.get("passes") if isinstance(gate, Mapping) else None
    if not isinstance(passes, (bool, np.bool_)) or not bool(passes):
        raise ValueError("fourth-version warmup memory compatibility gate failed")
    return dict(gate)


def _validate_initialization_response_warmup_memory_compatibility(
    config: Mapping[str, Any],
    periods: Mapping[str, tuple[date, date]],
) -> dict[str, Any]:
    """Validate the unchanged warmup-memory gate for v04/v05 diagnostics."""

    if _is_v04_config(config):
        return _validate_v04_warmup_memory_compatibility(config, periods)
    if not _is_v05_config(config):
        raise ValueError("initialization-response diagnostics require a v04 or v05 experiment")
    if str(config.get("parameter_bounds_preset", "")) != V05_PARAMETER_BOUNDS_PRESET:
        raise ValueError(
            f"parameter_bounds_preset must remain {V05_PARAMETER_BOUNDS_PRESET!r}"
        )
    if dict(periods) != SCREEN_V04_PERIODS:
        raise ValueError("fifth-version warmup, fit, and validation dates must remain frozen")
    warmup_start, warmup_end = periods["warmup"]
    warmup_days = (warmup_end - warmup_start).days + 1
    if warmup_days != V04_WARMUP_DAYS:
        raise ValueError(f"fifth-version warmup must contain exactly {V04_WARMUP_DAYS} days")
    gate = warmup_memory_compatibility(
        resolve_hbv_bounds(V05_PARAMETER_BOUNDS_PRESET),
        warmup_days,
        retained_fraction_max=V04_RETAINED_FRACTION_MAX,
    )
    passes = gate.get("passes") if isinstance(gate, Mapping) else None
    if not isinstance(passes, (bool, np.bool_)) or not bool(passes):
        raise ValueError("fifth-version warmup memory compatibility gate failed")
    return dict(gate)


@dataclass(frozen=True)
class AccessContract:
    """Validated paths and identifiers that may be used by the runner."""

    repo_root: Path
    profile_name: str
    profile: dict[str, Any]
    config: dict[str, Any]
    config_path: Path | None
    manifest_path: Path
    registry_path: Path
    development_universe_path: Path
    input_manifest_path: Path | None
    topography_path: Path | None
    expected_basin_areas_km2: dict[str, float]
    basin_ids: tuple[str, ...]
    periods: dict[str, tuple[date, date]]
    results_root: Path
    output_directory: Path
    incomplete_directory: Path


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _json_ready(value: Any) -> Any:
    if is_dataclass(value):
        return _json_ready(asdict(value))
    if isinstance(value, Mapping):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(item) for item in value]
    if isinstance(value, (Path, date, datetime, pd.Timestamp)):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def _write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(_json_ready(value), indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def _read_config(config: Mapping[str, Any] | str | Path) -> tuple[dict[str, Any], Path | None]:
    if isinstance(config, Mapping):
        return dict(config), None
    path = Path(config).resolve()
    if not path.is_file():
        raise FileNotFoundError(f"configuration file is missing: {path}")
    parsed = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(parsed, dict):
        raise ValueError("configuration must be a JSON object")
    return parsed, path


def _resolve_path(repo_root: Path, value: str | Path, label: str) -> Path:
    if not str(value).strip():
        raise ValueError(f"{label} path must not be empty")
    path = Path(value)
    return (path if path.is_absolute() else repo_root / path).resolve()


def _parse_date(value: Any, label: str) -> date:
    try:
        parsed = date.fromisoformat(str(value))
    except (TypeError, ValueError) as error:
        raise ValueError(f"{label} must be an ISO date") from error
    return parsed


def _normalize_basin_ids(values: Sequence[Any], label: str) -> tuple[str, ...]:
    result = tuple(str(value).strip().zfill(8) for value in values)
    if not result or any(re.fullmatch(r"\d{8}", value) is None for value in result):
        raise ValueError(f"{label} must contain one or more eight-digit basin identifiers")
    if len(result) != len(set(result)):
        raise ValueError(f"{label} contains duplicate basin identifiers")
    return result


def _active_periods(config: Mapping[str, Any]) -> dict[str, tuple[date, date]]:
    raw_periods = config.get("periods")
    if not isinstance(raw_periods, Mapping) or set(raw_periods) != set(PERIOD_NAMES):
        raise ValueError(f"periods must contain exactly {list(PERIOD_NAMES)}")
    periods: dict[str, tuple[date, date]] = {}
    for name in PERIOD_NAMES:
        raw = raw_periods[name]
        if not isinstance(raw, Mapping) or set(raw) != {"start", "end"}:
            raise ValueError(f"periods.{name} must contain exactly start and end")
        start = _parse_date(raw["start"], f"periods.{name}.start")
        end = _parse_date(raw["end"], f"periods.{name}.end")
        if start > end:
            raise ValueError(f"periods.{name} starts after it ends")
        if start <= FORBIDDEN_END and end >= FORBIDDEN_START:
            raise ValueError(
                f"periods.{name} overlaps the forbidden candidate holdout "
                f"{FORBIDDEN_START} through {FORBIDDEN_END}"
            )
        periods[name] = (start, end)
    if not (
        periods["warmup"][1] < periods["fit"][0]
        and periods["fit"][1] < periods["validation"][0]
    ):
        raise ValueError("warmup, fit, and validation periods must be ordered and disjoint")
    return periods


def _require_exact_mapping(
    config: Mapping[str, Any],
    key: str,
    expected: Mapping[str, Any],
) -> None:
    actual = config.get(key)
    if not isinstance(actual, Mapping) or dict(actual) != dict(expected):
        raise ValueError(f"{key} must remain {dict(expected)!r}")


def _validate_frozen_input_manifest(
    root: Path,
    config: Mapping[str, Any],
    basin_ids: tuple[str, ...],
) -> Path:
    expected_path = (root / SCREEN_INPUT_MANIFEST).resolve()
    manifest_path = _resolve_path(root, config.get("input_manifest", ""), "input_manifest")
    if manifest_path != expected_path:
        raise ValueError(f"input_manifest must remain {SCREEN_INPUT_MANIFEST}")
    if not manifest_path.is_file():
        raise FileNotFoundError(f"input manifest is missing: {manifest_path}")
    declared_hash = str(config.get("input_manifest_sha256", "")).lower()
    if declared_hash != SCREEN_INPUT_MANIFEST_SHA256 or _sha256(manifest_path) != declared_hash:
        raise ValueError("input manifest checksum does not match the frozen development screen")

    manifest = pd.read_csv(manifest_path, dtype={"basin_id": str, "relative_path": str})
    required = {"category", "basin_id", "relative_path", "bytes", "sha256"}
    missing = sorted(required - set(manifest.columns))
    if missing:
        raise ValueError(f"input manifest is missing columns: {missing}")
    manifest["basin_id"] = manifest["basin_id"].astype(str).str.zfill(8)
    for basin_id in basin_ids:
        selected = manifest[manifest["basin_id"] == basin_id]
        for category in ("maurer_forcing", "usgs_streamflow"):
            rows = selected[selected["category"] == category]
            if len(rows) != 1:
                raise ValueError(
                    f"input manifest must contain exactly one {category} row for basin {basin_id}"
                )
            row = rows.iloc[0]
            relative_source = Path(str(row["relative_path"]))
            if relative_source.is_absolute() or ".." in relative_source.parts:
                raise ValueError(
                    f"input manifest path leaves the repository: {relative_source}"
                )
            source = root / relative_source
            if not source.is_file():
                raise FileNotFoundError(f"frozen input file is missing: {source}")
            if source.stat().st_size != int(row["bytes"]):
                raise ValueError(f"frozen input byte count differs for {category} basin {basin_id}")
            recorded_hash = str(row["sha256"]).lower()
            if re.fullmatch(r"[0-9a-f]{64}", recorded_hash) is None or _sha256(source) != recorded_hash:
                raise ValueError(f"frozen input checksum differs for {category} basin {basin_id}")
    return manifest_path


def _validate_frozen_topography(root: Path, config: Mapping[str, Any]) -> Path:
    declared_path = Path(str(config.get("topography_file", ""))).as_posix()
    if declared_path != SCREEN_TOPOGRAPHY_FILE:
        raise ValueError(f"topography_file must remain {SCREEN_TOPOGRAPHY_FILE}")
    path = root / declared_path
    if not path.is_file():
        raise FileNotFoundError(f"topography file is missing: {path}")
    declared_hash = str(config.get("topography_file_sha256", "")).lower()
    if declared_hash != SCREEN_TOPOGRAPHY_SHA256 or _sha256(path) != declared_hash:
        raise ValueError("topography file checksum does not match the frozen development screen")
    return path


def _validate_development_screen_config(
    config: Mapping[str, Any],
    periods: Mapping[str, tuple[date, date]],
    manifest: pd.DataFrame,
) -> dict[str, float]:
    expected_periods = (
        SCREEN_V04_PERIODS
        if _uses_initialization_response_diagnostics(config)
        else SCREEN_PERIODS
    )
    if dict(periods) != expected_periods:
        raise ValueError("development-screen warmup, fit, and validation dates are frozen")
    if "selection_rule" not in manifest:
        raise ValueError("development-screen basin manifest must contain selection_rule")
    if set(manifest["selection_rule"].astype(str)) != {
        "pilot_six_intersection_frozen_design90"
    }:
        raise ValueError("development-screen basin selection rule is not frozen")
    if "expected_area_km2" not in manifest:
        raise ValueError("development-screen basin manifest must contain expected_area_km2")
    areas = {
        str(row["basin_id"]).zfill(8): float(row["expected_area_km2"])
        for _, row in manifest.iterrows()
    }
    if areas != SCREEN_BASIN_AREAS_KM2:
        raise ValueError("development-screen basin areas differ from the frozen manifest values")
    if int(config.get("minimum_target_days_per_water_year", -1)) != 30:
        raise ValueError("minimum_target_days_per_water_year must remain 30")
    identifier = str(config.get("experiment_id", ""))
    is_v02 = identifier == SCREEN_V02_EXPERIMENT_ID or identifier.startswith(
        SCREEN_V02_EXPERIMENT_ID + "_"
    )
    is_v03 = _is_v03_config(config)
    is_v04 = _is_v04_config(config)
    is_v05 = _is_v05_config(config)
    coverage_policy = config.get("target_state_coverage_policy")
    if is_v02 or is_v03 or is_v04 or is_v05:
        if not isinstance(coverage_policy, Mapping) or set(coverage_policy) != {
            "policy",
            "fit",
            "validation",
        }:
            raise ValueError("versioned target-state coverage policy has the wrong fields")
        if coverage_policy.get("policy") != SCREEN_V02_COVERAGE_POLICY["policy"]:
            raise ValueError("versioned target-state coverage policy differs from the frozen rule")
        for period_name in ("fit", "validation"):
            period_policy = coverage_policy.get(period_name)
            expected_policy = SCREEN_V02_COVERAGE_POLICY[period_name]
            if not isinstance(period_policy, Mapping) or set(period_policy) != set(expected_policy):
                raise ValueError("versioned target-state coverage policy has the wrong fields")
            for key, expected in expected_policy.items():
                value = period_policy.get(key)
                if isinstance(value, bool) or not isinstance(value, int) or value != expected:
                    raise ValueError(
                        "versioned target-state coverage policy differs from the frozen rule"
                    )
    elif coverage_policy is not None:
        raise ValueError("target_state_coverage_policy is reserved for the frozen second-version screen")
    _require_exact_mapping(
        config,
        "validation_gates",
        {
            "target_relative_improvement_min": 0.05,
            "minimum_improved_water_years": 2,
            "all_flow_nse_drop_max": 0.03,
            "opposite_regime_relative_degradation_max": 0.20,
            "must_beat_other_specialist": True,
        },
    )
    if is_v03 or is_v04 or is_v05:
        _require_exact_mapping(
            config,
            "parameter_quality_gates",
            {
                "generalist_nse_min": 0.30,
                "support_fit_loss_ratio_max": 1.05,
                "support_output_functional_distance_max": 0.03,
                "diagnostic_parameter_distance_reference": 0.20,
                "maximum_near_boundary_parameters": 2,
                "maximum_strongly_saturated_parameters": 1,
                "minimum_support_restarts": 1,
            },
        )
    else:
        _require_exact_mapping(
            config,
            "parameter_quality_gates",
            {
                "generalist_nse_min": 0.30,
                "support_fit_loss_ratio_max": 1.05,
                "support_parameter_distance_max": 0.20,
                "maximum_near_boundary_parameters": 2,
                "maximum_strongly_saturated_parameters": 1,
                "minimum_support_restarts": 1,
            },
        )
    _require_exact_mapping(
        config,
        "cross_basin_gates",
        {"minimum_complete_candidate_groups": 2, "boundary_fraction": 0.01},
    )
    return areas


def validate_access_contract(
    repo_root: Path,
    config: Mapping[str, Any] | str | Path,
) -> AccessContract:
    """Validate every basin/date access boundary without reading discharge."""

    root = Path(repo_root).resolve()
    parsed, config_path = _read_config(config)
    identifier = str(parsed.get("experiment_id", ""))
    if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", identifier) is None:
        raise ValueError("experiment_id must be a safe 1-128 character identifier")
    profile_name = str(parsed.get("classification", ""))
    if profile_name not in EXECUTION_PROFILES:
        raise ValueError(f"classification must be one of {sorted(EXECUTION_PROFILES)}")
    profile = dict(EXECUTION_PROFILES[profile_name])
    if parsed.get("scope") != profile["scope"]:
        raise ValueError(f"scope must be {profile['scope']}")
    protocol_fields = {
        "protocol_id",
        "protocol_scope",
        "protocol_credential",
        "protocol_credential_sha256",
    }
    if _is_v03_config(parsed):
        from camels_switch_confirmation.protocol_freeze import validate_config_binding

        if profile_name != "development_screen":
            raise ValueError("third-version protocol requires the development-screen profile")
        validate_config_binding(root, parsed)
    elif _is_v04_config(parsed):
        from camels_switch_confirmation.protocol_freeze_v04 import (
            validate_v04_registration_config,
        )

        if profile_name != "development_screen":
            raise ValueError("fourth-version protocol requires the development-screen profile")
        validate_v04_registration_config(root, parsed)
    elif _is_v05_config(parsed):
        from camels_switch_confirmation.protocol_freeze_v05 import (
            validate_v05_registration_config,
        )

        if profile_name != "development_screen":
            raise ValueError("fifth-version protocol requires the development-screen profile")
        validate_v05_registration_config(root, parsed)
    elif protocol_fields & set(parsed):
        raise ValueError("protocol binding fields are reserved for frozen versioned screens")

    declared_forbidden = parsed.get("forbidden_holdout")
    if not isinstance(declared_forbidden, Mapping):
        raise ValueError("forbidden_holdout must be declared")
    declared_start = _parse_date(declared_forbidden.get("start"), "forbidden_holdout.start")
    declared_end = _parse_date(declared_forbidden.get("end"), "forbidden_holdout.end")
    if (declared_start, declared_end) != (FORBIDDEN_START, FORBIDDEN_END):
        raise ValueError("forbidden holdout declaration must remain 1980-01-01 through 1989-09-30")
    periods = _active_periods(parsed)
    if _uses_initialization_response_diagnostics(parsed):
        _validate_initialization_response_warmup_memory_compatibility(parsed, periods)

    manifest_path = _resolve_path(root, parsed.get("basin_manifest", ""), "basin_manifest")
    universe_path = _resolve_path(
        root,
        parsed.get("development_universe", ""),
        "development_universe",
    )
    registry_path = _resolve_path(
        root,
        parsed.get("experiment_registry", ""),
        "experiment_registry",
    )
    results_root = _resolve_path(root, parsed.get("results_root", ""), "results_root")
    output = (results_root / identifier).resolve()
    if output.parent != results_root:
        raise ValueError("experiment output must be a direct child of results_root")
    incomplete = output.with_name(output.name + ".incomplete")
    if output.exists():
        raise FileExistsError(f"refusing existing final output: {output}")
    if incomplete.exists():
        raise FileExistsError(f"refusing existing .incomplete output: {incomplete}")
    if not manifest_path.is_file():
        raise FileNotFoundError(f"basin manifest is missing: {manifest_path}")
    if not universe_path.is_file():
        raise FileNotFoundError(f"development universe is missing: {universe_path}")
    expected_universe_hash = str(parsed.get("development_universe_sha256", "")).lower()
    if re.fullmatch(r"[0-9a-f]{64}", expected_universe_hash) is None:
        raise ValueError("development_universe_sha256 must be a SHA-256 digest")
    if _sha256(universe_path) != expected_universe_hash:
        raise ValueError("development universe checksum does not match the frozen configuration")

    manifest = pd.read_csv(manifest_path, dtype={"basin_id": str})
    universe = pd.read_csv(universe_path, dtype={"basin_id": str})
    if "basin_id" not in manifest or "basin_id" not in universe:
        raise ValueError("basin manifest and development universe must contain basin_id")
    basin_ids = _normalize_basin_ids(manifest["basin_id"].tolist(), "basin manifest")
    universe_ids = _normalize_basin_ids(universe["basin_id"].tolist(), "development universe")
    if len(universe_ids) != 90:
        raise ValueError("development universe must contain exactly 90 unique basins")
    outside = sorted(set(basin_ids) - set(universe_ids))
    if outside:
        raise ValueError(f"basins are outside the Design90 development universe: {outside}")

    basin_count = int(profile["basin_count"])
    if len(basin_ids) != basin_count:
        raise ValueError(f"{profile_name} requires exactly {basin_count} basins")
    if profile_name == "development_screen" and basin_ids != SCREEN_BASIN_IDS:
        raise ValueError(
            "development-screen basin order must remain 04015330, 08109700, 11481200"
        )

    for key in ("forcing", "pet_method", "parameter_bounds_preset", "routing_kernel"):
        expected = (
            _parameter_bounds_preset_for(parsed)
            if key == "parameter_bounds_preset"
            and _uses_initialization_response_diagnostics(parsed)
            else profile[key]
        )
        if parsed.get(key) != expected:
            raise ValueError(f"{key} must remain {expected!r}")
    declared_data_root = Path(str(parsed.get("data_root", ""))).as_posix()
    if declared_data_root != str(profile["data_root"]):
        raise ValueError(f"data_root must remain {profile['data_root']}")
    data_root = _resolve_path(root, declared_data_root, "data_root")
    expected_data_root = (root / str(profile["data_root"])).resolve()
    if data_root != expected_data_root:
        raise ValueError(f"data_root must remain {profile['data_root']}")
    quantiles = parsed.get("regime_quantiles")
    if not isinstance(quantiles, Mapping) or (
        float(quantiles.get("low", -1.0)),
        float(quantiles.get("high", -1.0)),
        str(quantiles.get("method", "")),
    ) != (0.30, 0.70, "linear"):
        raise ValueError("regime quantiles must remain 0.30 and 0.70 with the linear method")
    if float(parsed.get("flow_log_offset_mm_day", -1.0)) != 0.01:
        raise ValueError("flow_log_offset_mm_day must remain 0.01")
    optimizer = parsed.get("optimizer")
    if not isinstance(optimizer, Mapping):
        raise ValueError("optimizer configuration is missing")
    expected_evaluations = int(profile["function_evaluations_per_restart"])
    if int(optimizer.get("function_evaluations_per_restart", -1)) != expected_evaluations:
        raise ValueError(
            f"{profile_name} function-evaluation budget must remain {expected_evaluations} per restart"
        )
    expected_seeds = tuple(profile["restart_seeds"])
    if tuple(optimizer.get("restart_seeds", ())) != expected_seeds:
        raise ValueError(f"{profile_name} restart seeds must remain {expected_seeds}")

    input_manifest_path = None
    topography_path = None
    expected_basin_areas_km2: dict[str, float] = {}
    if profile_name == "development_screen":
        expected_basin_areas_km2 = _validate_development_screen_config(
            parsed,
            periods,
            manifest,
        )
        input_manifest_path = _validate_frozen_input_manifest(root, parsed, basin_ids)
        topography_path = _validate_frozen_topography(root, parsed)

    return AccessContract(
        repo_root=root,
        profile_name=profile_name,
        profile=profile,
        config=parsed,
        config_path=config_path,
        manifest_path=manifest_path,
        registry_path=registry_path,
        development_universe_path=universe_path,
        input_manifest_path=input_manifest_path,
        topography_path=topography_path,
        expected_basin_areas_km2=expected_basin_areas_km2,
        basin_ids=basin_ids,
        periods=periods,
        results_root=results_root,
        output_directory=output,
        incomplete_directory=incomplete,
    )


def _read_registry(contract: AccessContract) -> pd.DataFrame:
    if not contract.registry_path.is_file():
        raise FileNotFoundError(f"experiment registry is missing: {contract.registry_path}")
    registry = pd.read_csv(contract.registry_path, dtype=str, keep_default_na=False)
    required = {
        "experiment_id",
        "classification",
        "config_path",
        "config_sha256",
        "basin_manifest",
        "basin_manifest_sha256",
        "status",
        "output_dir",
        "updated_at",
        "error",
    }
    missing = sorted(required - set(registry.columns))
    if missing:
        raise ValueError(f"experiment registry is missing columns: {missing}")
    if registry["experiment_id"].duplicated().any():
        raise ValueError("experiment registry contains duplicate identifiers")
    return registry


def _registry_row(contract: AccessContract, registry: pd.DataFrame) -> int:
    matches = registry.index[registry["experiment_id"] == contract.config["experiment_id"]].tolist()
    if len(matches) != 1:
        raise ValueError("experiment identifier must have exactly one frozen registry row")
    index = int(matches[0])
    row = registry.loc[index]
    if row["classification"] != contract.profile_name:
        raise ValueError(f"registry classification must be {contract.profile_name}")
    if contract.config_path is None:
        raise ValueError("execution requires a file-backed frozen configuration")
    registered_config = _resolve_path(contract.repo_root, row["config_path"], "registry config_path")
    registered_manifest = _resolve_path(
        contract.repo_root,
        row["basin_manifest"],
        "registry basin_manifest",
    )
    if registered_config != contract.config_path or registered_manifest != contract.manifest_path:
        raise ValueError("registry paths do not match the supplied frozen configuration")
    if row["config_sha256"].lower() != _sha256(contract.config_path):
        raise ValueError("registry configuration checksum does not match")
    if row["basin_manifest_sha256"].lower() != _sha256(contract.manifest_path):
        raise ValueError("registry basin-manifest checksum does not match")
    registered_output = _resolve_path(contract.repo_root, row["output_dir"], "registry output_dir")
    if registered_output != contract.output_directory:
        raise ValueError("registry output directory does not match the configuration")
    return index


def _write_registry_atomic(contract: AccessContract, registry: pd.DataFrame) -> None:
    temporary = contract.registry_path.with_name(
        f".{contract.registry_path.stem}.{contract.config['experiment_id']}.incomplete.csv"
    )
    if temporary.exists():
        raise FileExistsError(f"refusing existing registry temporary file: {temporary}")
    contract.registry_path.parent.mkdir(parents=True, exist_ok=True)
    registry.to_csv(temporary, index=False)
    os.replace(temporary, contract.registry_path)


def _transition_registry(
    contract: AccessContract,
    expected_status: str,
    new_status: str,
    error: str = "",
) -> None:
    registry = _read_registry(contract)
    index = _registry_row(contract, registry)
    actual = registry.loc[index, "status"]
    if actual != expected_status:
        raise FileExistsError(
            f"experiment registry identifier {contract.config['experiment_id']!r} "
            f"has status {actual!r}; expected {expected_status!r}"
        )
    registry.loc[index, "status"] = new_status
    registry.loc[index, "updated_at"] = datetime.now().astimezone().isoformat()
    registry.loc[index, "error"] = error[:2000]
    _write_registry_atomic(contract, registry)


def _preflight_immutability(contract: AccessContract) -> None:
    if contract.output_directory.exists():
        raise FileExistsError(f"refusing existing final output: {contract.output_directory}")
    if contract.incomplete_directory.exists():
        raise FileExistsError(f"refusing existing .incomplete output: {contract.incomplete_directory}")
    registry = _read_registry(contract)
    index = _registry_row(contract, registry)
    if registry.loc[index, "status"] != "registered_not_run":
        raise FileExistsError(
            f"experiment registry identifier is already reserved or completed: "
            f"{contract.config['experiment_id']}"
        )


def _validate_loaded_basin(
    basin_id: str,
    forcing: pd.DataFrame,
    observations: pd.Series,
    area_km2: float,
    contract: AccessContract,
) -> tuple[pd.DataFrame, pd.Series]:
    if not isinstance(forcing, pd.DataFrame) or not isinstance(observations, pd.Series):
        raise ValueError("CAMELS loader must return a forcing DataFrame and observation Series")
    forcing = forcing.copy()
    observations = observations.copy()
    forcing.index = pd.DatetimeIndex(forcing.index)
    observations.index = pd.DatetimeIndex(observations.index)
    if not forcing.index.is_monotonic_increasing or not forcing.index.is_unique:
        raise ValueError("forcing dates must be unique and increasing")
    expected_dates = pd.date_range(
        contract.periods["warmup"][0],
        contract.periods["validation"][1],
        freq="D",
    )
    if not forcing.index.equals(expected_dates):
        raise ValueError("loaded forcing must cover every requested day continuously")
    if not observations.index.equals(forcing.index):
        raise ValueError("loaded observations must be aligned to the complete forcing sequence")
    required_columns = ("prcp", "ep", "tmean")
    if not set(required_columns) <= set(forcing.columns):
        raise ValueError(f"forcing must contain {required_columns}")
    forcing_values = forcing.loc[:, required_columns].to_numpy(dtype=float)
    if not np.all(np.isfinite(forcing_values)):
        raise ValueError("forcing must contain only finite values")
    if np.any(forcing.loc[:, ["prcp", "ep"]].to_numpy(dtype=float) < 0.0):
        raise ValueError("precipitation and potential evapotranspiration must be nonnegative")
    if not np.isfinite(float(area_km2)) or float(area_km2) <= 0.0:
        raise ValueError("basin area must be finite and positive")
    if contract.profile_name == "development_screen":
        expected_area = contract.expected_basin_areas_km2[basin_id]
        if not np.isclose(float(area_km2), expected_area, rtol=1e-12, atol=1e-12):
            raise ValueError(
                f"loaded area for basin {basin_id} differs from frozen value {expected_area} km2"
            )
    observed_values = observations.to_numpy(dtype=float)
    if contract.profile_name == "development_screen":
        expected_observation_days = (
            len(expected_dates)
            if _uses_initialization_response_diagnostics(contract.config)
            else 3653
        )
        if len(observed_values) != expected_observation_days:
            raise ValueError(
                "development-screen observations must contain exactly "
                f"{expected_observation_days} daily values"
            )
        if not np.all(np.isfinite(observed_values)):
            raise ValueError(
                "development-screen observations must be finite on all "
                f"{expected_observation_days} days"
            )
        if np.any(observed_values < 0.0):
            raise ValueError(
                "development-screen observations must be nonnegative on all "
                f"{expected_observation_days} days"
            )
    for name in ("fit", "validation"):
        start, end = contract.periods[name]
        mask = (forcing.index.date >= start) & (forcing.index.date <= end)
        if np.isfinite(observed_values[mask]).sum() < 10:
            raise ValueError(f"{name} period must contain at least ten finite observations")
    return forcing, observations


def _date_mask(index: pd.DatetimeIndex, bounds: tuple[date, date]) -> np.ndarray:
    return np.asarray((index.date >= bounds[0]) & (index.date <= bounds[1]), dtype=bool)


def _mapping_scalar_row(identifier: str, values: Mapping[str, Any]) -> dict[str, Any]:
    row: dict[str, Any] = {"parameter_id": identifier}
    for key, value in values.items():
        if isinstance(value, (str, bool, int, float, np.generic)) or value is None:
            row[str(key)] = _json_ready(value)
        elif is_dataclass(value):
            for nested_key, nested_value in asdict(value).items():
                if isinstance(nested_value, (str, bool, int, float, np.generic)) or nested_value is None:
                    row[f"{key}_{nested_key}"] = _json_ready(nested_value)
    return row


def _parameter_sha256(parameters: Mapping[str, Any], label: str) -> str:
    if not isinstance(parameters, Mapping) or set(parameters) != set(PARAM_NAMES):
        raise ValueError(f"{label} must contain exactly the frozen parameter names")
    values = {name: float(parameters[name]) for name in PARAM_NAMES}
    if any(not np.isfinite(value) for value in values.values()):
        raise ValueError(f"{label} must contain only finite parameter values")
    payload = "\n".join(f"{name}={values[name].hex()}" for name in PARAM_NAMES)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _parameter_vectors(calibrations: Mapping[str, Mapping[str, Any]]) -> pd.DataFrame:
    rows = []
    for parameter_id in PARAMETER_IDS:
        result = calibrations[parameter_id]
        parameters = result.get("optimized_params", result.get("parameters"))
        if not isinstance(parameters, Mapping):
            raise ValueError(f"calibration {parameter_id} lacks optimized parameters")
        if set(parameters) != set(PARAM_NAMES):
            raise ValueError(f"calibration {parameter_id} has the wrong parameter names")
        row = {
            "parameter_id": parameter_id,
            FIT_SELECTED_FINGERPRINT: _parameter_sha256(
                parameters,
                f"calibration {parameter_id} selected parameters",
            ),
        }
        row.update({name: float(parameters[name]) for name in PARAM_NAMES})
        rows.append(row)
    return pd.DataFrame(rows)


def _fit_metric_table(calibrations: Mapping[str, Mapping[str, Any]]) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for parameter_id in PARAMETER_IDS:
        result = calibrations[parameter_id]
        selected = _mapping_scalar_row(parameter_id, result)
        selected["record_type"] = "selected_fit_result"
        selected[FIT_SELECTED_FINGERPRINT] = _parameter_sha256(
            result.get("optimized_params"),
            f"calibration {parameter_id} selected parameters",
        )
        rows.append(selected)
        restart_records = result.get("restart_records", result.get("restarts", ()))
        if isinstance(restart_records, Sequence) and not isinstance(restart_records, (str, bytes)):
            for restart_index, record in enumerate(restart_records):
                if isinstance(record, Mapping):
                    row = _mapping_scalar_row(parameter_id, record)
                    row["record_type"] = "restart"
                    row.setdefault("restart_index", restart_index)
                    row[RESTART_FINGERPRINT] = _parameter_sha256(
                        record.get("optimized_params"),
                        f"calibration {parameter_id} restart {restart_index} parameters",
                    )
                    rows.append(row)
    return pd.DataFrame(rows)


def _validation_metric_table(
    evaluations: Mapping[str, Mapping[str, Any]],
    gates: Mapping[str, Any],
) -> pd.DataFrame:
    rows = []
    for parameter_id in PARAMETER_IDS:
        evaluation = evaluations[parameter_id]
        row = _mapping_scalar_row(parameter_id, evaluation)
        row["record_type"] = "selected_fit_result"
        row[FIT_SELECTED_FINGERPRINT] = _parameter_sha256(
            evaluation.get("selected_params"),
            f"validation {parameter_id} selected parameters",
        )
        gate = gates.get(parameter_id)
        if isinstance(gate, Mapping):
            for key, value in _mapping_scalar_row(parameter_id, gate).items():
                if key != "parameter_id":
                    row[f"gate_{key}"] = value
        rows.append(row)
        restart_records = evaluation.get("restart_metrics", ())
        if isinstance(restart_records, Sequence) and not isinstance(restart_records, (str, bytes)):
            for restart_index, record in enumerate(restart_records):
                if isinstance(record, Mapping):
                    restart_row = _mapping_scalar_row(parameter_id, record)
                    restart_row["record_type"] = "restart"
                    restart_row.setdefault("restart_index", restart_index)
                    restart_row[RESTART_FINGERPRINT] = _parameter_sha256(
                        record.get("optimized_params"),
                        f"validation {parameter_id} restart {restart_index} parameters",
                    )
                    rows.append(restart_row)
        water_year_records = evaluation.get("water_year_target_comparison", ())
        if isinstance(water_year_records, Sequence) and not isinstance(
            water_year_records,
            (str, bytes),
        ):
            for record in water_year_records:
                if isinstance(record, Mapping):
                    water_year_row = _mapping_scalar_row(parameter_id, record)
                    water_year_row["record_type"] = "water_year_target_direction"
                    rows.append(water_year_row)
    return pd.DataFrame(rows)


def _validation_hydrograph_table(
    dates: Any,
    observations: Any,
    validation_mask: Any,
    evaluations: Mapping[str, Mapping[str, Any]],
) -> pd.DataFrame:
    """Preserve selected fixed-parameter trajectories on validation dates."""

    date_index = pd.DatetimeIndex(dates)
    observed = np.asarray(observations, dtype=float)
    raw_mask = np.asarray(validation_mask)
    if raw_mask.dtype != np.bool_ or raw_mask.ndim != 1:
        raise ValueError("validation hydrograph mask must be one-dimensional and boolean")
    if len(date_index) != len(observed) or len(observed) != len(raw_mask):
        raise ValueError("validation hydrograph inputs must have identical lengths")
    if not date_index.is_unique or not date_index.is_monotonic_increasing:
        raise ValueError("validation hydrograph dates must be strictly increasing and unique")
    if not raw_mask.any():
        raise ValueError("validation hydrograph must contain at least one selected date")
    if not np.all(np.isfinite(observed[raw_mask])) or np.any(observed[raw_mask] < 0.0):
        raise ValueError("validation hydrograph observations must be finite and nonnegative")
    columns: dict[str, Any] = {
        "date": date_index[raw_mask],
        "observed_flow_mm_day": observed[raw_mask],
    }
    output_names = {
        "all_flow": "general_parameter_flow_mm_day",
        "low_flow": "low_flow_parameter_flow_mm_day",
        "high_flow": "high_flow_parameter_flow_mm_day",
    }
    for parameter_id, column_name in output_names.items():
        evaluation = evaluations.get(parameter_id)
        if not isinstance(evaluation, Mapping) or "qsim" not in evaluation:
            raise ValueError(f"validation hydrograph lacks {parameter_id} simulation")
        simulated = np.asarray(evaluation["qsim"], dtype=float)
        if simulated.ndim != 1 or len(simulated) != len(observed):
            raise ValueError(f"validation hydrograph {parameter_id} simulation has the wrong length")
        if not np.all(np.isfinite(simulated[raw_mask])) or np.any(simulated[raw_mask] < 0.0):
            raise ValueError(
                f"validation hydrograph {parameter_id} simulation must be finite and nonnegative"
            )
        columns[column_name] = simulated[raw_mask]
    return pd.DataFrame(columns)


def _strict_restart_identity(record: Mapping[str, Any], label: str) -> tuple[int, int]:
    """Return one finite integer restart identity without Boolean coercion."""

    values = []
    for key in ("restart_index", "seed"):
        value = record.get(key)
        if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)):
            raise ValueError(f"{label} {key} must be an integer")
        values.append(int(value))
    if values[0] < 0:
        raise ValueError(f"{label} restart_index must be nonnegative")
    return values[0], values[1]


def _as_artifact_mask(value: Any, length: int, label: str) -> np.ndarray:
    raw = np.asarray(value)
    if raw.ndim != 1 or raw.dtype != np.bool_ or len(raw) != length:
        raise ValueError(f"{label} must be a one-dimensional Boolean mask of length {length}")
    return raw.copy()


def _selected_restart(
    calibration: Mapping[str, Any],
    parameter_id: str,
) -> tuple[tuple[int, int], str, float]:
    selected_parameters = calibration.get("optimized_params")
    selected_fingerprint = _parameter_sha256(
        selected_parameters,
        f"{parameter_id} selected parameters",
    )
    selected_loss = float(calibration.get("objective_loss", float("nan")))
    if not np.isfinite(selected_loss):
        raise ValueError(f"{parameter_id} selected fit objective loss must be finite")
    restart_records = calibration.get("restart_records")
    if not isinstance(restart_records, Sequence) or isinstance(restart_records, (str, bytes)):
        raise ValueError(f"{parameter_id} restart_records must be a sequence")
    selected_index = calibration.get("selected_restart_index")
    selected_seed = calibration.get("selected_restart_seed")
    if (
        isinstance(selected_index, (bool, np.bool_))
        or not isinstance(selected_index, (int, np.integer))
        or isinstance(selected_seed, (bool, np.bool_))
        or not isinstance(selected_seed, (int, np.integer))
    ):
        raise ValueError(f"{parameter_id} calibration lacks an explicit selected restart identity")
    authoritative_identity = (int(selected_index), int(selected_seed))
    identities: list[tuple[int, int]] = []
    restart_losses: list[float] = []
    for position, record in enumerate(restart_records):
        if not isinstance(record, Mapping):
            raise ValueError(f"{parameter_id} restart {position} must be a mapping")
        identity = _strict_restart_identity(record, f"{parameter_id} restart {position}")
        identities.append(identity)
        restart_loss = float(record.get("objective_loss", float("nan")))
        if not np.isfinite(restart_loss):
            raise ValueError(f"{parameter_id} restart fit objective loss must be finite")
        restart_losses.append(restart_loss)
        fingerprint = _parameter_sha256(
            record.get("optimized_params"),
            f"{parameter_id} restart {position} parameters",
        )
        if identity == authoritative_identity and (
            fingerprint != selected_fingerprint
            or restart_loss != selected_loss
        ):
            raise ValueError(f"{parameter_id} explicit selected restart differs from the fit result")
        selected_flag = record.get("selected")
        if not isinstance(selected_flag, (bool, np.bool_)) or bool(selected_flag) != (
            identity == authoritative_identity
        ):
            raise ValueError(f"{parameter_id} restart selected flag is inconsistent")
    if authoritative_identity not in identities:
        raise ValueError(f"{parameter_id} explicit selected restart identity is absent")
    minimum_loss = min(restart_losses)
    first_minimum_identity = identities[next(
        index
        for index, loss in enumerate(restart_losses)
        if loss == minimum_loss
    )]
    if authoritative_identity != first_minimum_identity:
        raise ValueError(f"{parameter_id} selected restart is not the first fit-loss minimum")
    return authoritative_identity, selected_fingerprint, selected_loss


def _build_v03_restart_evidence(
    dates: Any,
    observations: Any,
    fit_mask: Any,
    validation_mask: Any,
    thresholds: Any,
    calibrations: Mapping[str, Mapping[str, Any]],
    evaluations: Mapping[str, Mapping[str, Any]],
    *,
    flow_log_offset_mm_day: float,
    maximum_distance: float,
    fit_loss_ratio_max: float,
    parameter_bounds: Mapping[str, tuple[float, float]],
) -> dict[str, pd.DataFrame]:
    """Build all v03 restart tables from the trajectories already replayed.

    The returned per-basin tables deliberately omit ``basin_id``; the existing
    multi-basin combiner inserts it exactly once.  No optimizer or simulation
    function is called here.
    """

    from camels_switch_confirmation.real_regime_parameter_calibration import (
        normalized_parameter_distance,
        output_functional_distance,
    )

    date_index = pd.DatetimeIndex(pd.to_datetime(dates))
    observed = np.asarray(observations, dtype=float)
    if date_index.hasnans or not date_index.is_unique or not date_index.is_monotonic_increasing:
        raise ValueError("v03 evidence dates must be finite, unique, and strictly increasing")
    if observed.ndim != 1 or len(observed) != len(date_index):
        raise ValueError("v03 evidence observations must match the daily date index")
    if not np.all(np.isfinite(observed)) or np.any(observed < 0.0):
        raise ValueError("v03 evidence observations must be finite and nonnegative")
    fit = _as_artifact_mask(fit_mask, len(observed), "fit_mask")
    validation = _as_artifact_mask(validation_mask, len(observed), "validation_mask")
    if np.any(fit & validation) or not fit.any() or not validation.any():
        raise ValueError("fit and validation evidence masks must be nonempty and disjoint")
    low_threshold = float(getattr(thresholds, "low"))
    high_threshold = float(getattr(thresholds, "high"))
    if not np.isfinite(low_threshold) or not np.isfinite(high_threshold) or low_threshold >= high_threshold:
        raise ValueError("v03 evidence requires finite ordered flow thresholds")
    log_offset = float(flow_log_offset_mm_day)
    distance_limit = float(maximum_distance)
    ratio_limit = float(fit_loss_ratio_max)
    if not np.isfinite(log_offset) or log_offset <= 0.0:
        raise ValueError("flow_log_offset_mm_day must be finite and positive")
    if not np.isfinite(distance_limit) or distance_limit < 0.0:
        raise ValueError("maximum_distance must be finite and nonnegative")
    if not np.isfinite(ratio_limit) or ratio_limit < 1.0:
        raise ValueError("fit_loss_ratio_max must be finite and at least one")
    if set(calibrations) != set(PARAMETER_IDS) or set(evaluations) != set(PARAMETER_IDS):
        raise ValueError("v03 evidence requires exactly all-flow, low-flow, and high-flow records")

    membership = {
        "all_flow": np.ones(len(observed), dtype=bool),
        "low_flow": observed <= low_threshold,
        "high_flow": observed >= high_threshold,
    }
    vector_rows: list[dict[str, Any]] = []
    fit_frames: list[pd.DataFrame] = []
    validation_frames: list[pd.DataFrame] = []
    metric_rows: list[dict[str, Any]] = []
    for parameter_id in PARAMETER_IDS:
        calibration = calibrations[parameter_id]
        evaluation = evaluations[parameter_id]
        if not isinstance(calibration, Mapping) or not isinstance(evaluation, Mapping):
            raise ValueError(f"v03 {parameter_id} calibration and evaluation must be mappings")
        selected_identity, selected_fingerprint, selected_loss = _selected_restart(
            calibration,
            parameter_id,
        )
        restart_records = calibration["restart_records"]
        restart_metrics = evaluation.get("restart_metrics")
        if not isinstance(restart_metrics, Sequence) or isinstance(restart_metrics, (str, bytes)):
            raise ValueError(f"v03 {parameter_id} restart metrics must be a sequence")
        calibration_by_identity: dict[tuple[int, int], Mapping[str, Any]] = {}
        for position, record in enumerate(restart_records):
            identity = _strict_restart_identity(record, f"{parameter_id} calibration restart {position}")
            if identity in calibration_by_identity:
                raise ValueError(f"v03 {parameter_id} contains duplicate calibration restart identity")
            calibration_by_identity[identity] = record
        metric_by_identity: dict[tuple[int, int], Mapping[str, Any]] = {}
        for position, record in enumerate(restart_metrics):
            if not isinstance(record, Mapping):
                raise ValueError(f"v03 {parameter_id} restart metric {position} must be a mapping")
            identity = _strict_restart_identity(record, f"{parameter_id} evaluation restart {position}")
            if identity in metric_by_identity:
                raise ValueError(f"v03 {parameter_id} contains duplicate evaluation restart identity")
            metric_by_identity[identity] = record
        if set(calibration_by_identity) != set(metric_by_identity):
            raise ValueError(f"v03 {parameter_id} restart identities differ across fit and replay")

        simulations: dict[tuple[int, int], np.ndarray] = {}
        fingerprints: dict[tuple[int, int], str] = {}
        losses: dict[tuple[int, int], float] = {}
        for identity in sorted(calibration_by_identity):
            restart_index, seed = identity
            calibration_record = calibration_by_identity[identity]
            metric_record = metric_by_identity[identity]
            parameters = calibration_record.get("optimized_params")
            fingerprint = _parameter_sha256(
                parameters,
                f"v03 {parameter_id} restart {restart_index} parameters",
            )
            replay_fingerprint = _parameter_sha256(
                metric_record.get("optimized_params"),
                f"v03 {parameter_id} replay restart {restart_index} parameters",
            )
            if fingerprint != replay_fingerprint:
                raise ValueError(f"v03 {parameter_id} restart parameter fingerprint differs across records")
            numeric_parameters = {name: float(parameters[name]) for name in PARAM_NAMES}
            for name, value in numeric_parameters.items():
                lower, upper = parameter_bounds[name]
                if not np.isfinite(value) or value < float(lower) or value > float(upper):
                    raise ValueError(f"v03 restart parameter {name} is nonfinite or out of bounds")
            fit_loss = float(calibration_record.get("objective_loss", float("nan")))
            replay_fit_loss = float(metric_record.get("fit_objective_loss", float("nan")))
            if not np.isfinite(fit_loss) or not np.isclose(
                fit_loss,
                replay_fit_loss,
                rtol=0.0,
                atol=1e-12,
            ):
                raise ValueError(f"v03 {parameter_id} restart fit loss differs across records")
            simulated = np.asarray(metric_record.get("simulated_flow"), dtype=float)
            if simulated.ndim != 1 or len(simulated) != len(observed):
                raise ValueError(f"v03 {parameter_id} restart simulation has the wrong length")
            if not np.all(np.isfinite(simulated)) or np.any(simulated < 0.0):
                raise ValueError(f"v03 {parameter_id} restart simulation must be finite and nonnegative")
            is_selected = identity == selected_identity
            vector_rows.append({
                "parameter_id": parameter_id,
                "restart_index": restart_index,
                "seed": seed,
                "selected": is_selected,
                "fit_objective_loss": fit_loss,
                "parameter_sha256": fingerprint,
                **numeric_parameters,
            })
            base = {
                "parameter_id": parameter_id,
                "restart_index": restart_index,
                "seed": seed,
                "observed_flow_mm_day": observed,
                "simulated_flow_mm_day": simulated,
                "all_flow_member": membership["all_flow"],
                "low_flow_member": membership["low_flow"],
                "high_flow_member": membership["high_flow"],
                "selected": is_selected,
                "parameter_sha256": fingerprint,
            }
            fit_frame = pd.DataFrame({**base, "date": date_index, "objective_member": membership[parameter_id]})
            fit_frames.append(fit_frame.loc[fit, V03_FIT_HYDROGRAPH_COLUMNS])
            validation_frame = pd.DataFrame({**base, "date": date_index})
            validation_frames.append(
                validation_frame.loc[validation, V03_VALIDATION_HYDROGRAPH_COLUMNS]
            )
            simulations[identity] = simulated
            fingerprints[identity] = fingerprint
            losses[identity] = fit_loss

        selected_simulation = simulations[selected_identity]
        selected_parameters = calibration_by_identity[selected_identity]["optimized_params"]
        for identity in sorted(calibration_by_identity):
            if identity == selected_identity:
                continue
            restart_index, seed = identity
            fit_loss = losses[identity]
            if selected_loss == 0.0:
                fit_loss_ratio = 1.0 if fit_loss == 0.0 else float("inf")
            else:
                fit_loss_ratio = fit_loss / selected_loss
            if not np.isfinite(fit_loss_ratio):
                raise ValueError("v03 support fit-loss ratio must be finite")
            parameter_distance = normalized_parameter_distance(
                selected_parameters,
                calibration_by_identity[identity]["optimized_params"],
                parameter_bounds,
            )
            for day_set in PARAMETER_IDS:
                transform = "log_q_plus_offset" if day_set == "low_flow" else "identity"
                record = output_functional_distance(
                    selected_simulation,
                    simulations[identity],
                    observed,
                    fit & membership[day_set],
                    validation & membership[day_set],
                    transform=transform,
                    log_offset=log_offset if day_set == "low_flow" else None,
                    maximum_distance=distance_limit,
                )
                stored = metric_by_identity[identity].get("output_functional_distances")
                if isinstance(stored, Mapping) and day_set in stored:
                    stored_record = stored[day_set]
                    if not isinstance(stored_record, Mapping) or _json_ready(
                        dict(stored_record)
                    ) != _json_ready(record):
                        raise ValueError("v03 stored output distance differs from raw restart trajectories")
                metric_rows.append({
                    "parameter_id": parameter_id,
                    "restart_index": restart_index,
                    "seed": seed,
                    "selected_restart_index": selected_identity[0],
                    "selected_seed": selected_identity[1],
                    "selected_parameter_sha256": selected_fingerprint,
                    "restart_parameter_sha256": fingerprints[identity],
                    "day_set": day_set,
                    **record,
                    "fit_objective_loss": fit_loss,
                    "selected_fit_objective_loss": selected_loss,
                    "fit_loss_ratio": fit_loss_ratio,
                    "fit_loss_ratio_max": ratio_limit,
                    "fit_loss_ratio_pass": bool(fit_loss_ratio <= ratio_limit),
                    "parameter_distance_diagnostic": parameter_distance,
                })

    result = {
        "restart_parameter_vectors": pd.DataFrame(vector_rows, columns=V03_RESTART_PARAMETER_COLUMNS),
        "fit_restart_hydrographs": pd.concat(fit_frames, ignore_index=True).loc[
            :, V03_FIT_HYDROGRAPH_COLUMNS
        ],
        "validation_restart_hydrographs": pd.concat(validation_frames, ignore_index=True).loc[
            :, V03_VALIDATION_HYDROGRAPH_COLUMNS
        ],
        "functional_stability_metrics": pd.DataFrame(
            metric_rows,
            columns=V03_FUNCTIONAL_METRIC_COLUMNS,
        ),
    }
    _verify_v03_restart_evidence(
        result,
        expected_restart_seeds=tuple(
            int(record["seed"])
            for record in calibrations[PARAMETER_IDS[0]]["restart_records"]
        ),
        fit_dates=date_index[fit],
        validation_dates=date_index[validation],
        maximum_distance=distance_limit,
        fit_loss_ratio_max=ratio_limit,
        parameter_bounds=parameter_bounds,
    )
    return result


def _build_v04_diagnostic_evidence(
    forcing: pd.DataFrame,
    observations: pd.Series,
    config: Mapping[str, Any],
    regime_preflight: Mapping[str, Any],
    calibrations: Mapping[str, Mapping[str, Any]],
    evaluations: Mapping[str, Mapping[str, Any]],
) -> dict[str, pd.DataFrame]:
    """Replay fixed v04/v05 restarts into the unchanged diagnostic schemas."""

    if not _uses_initialization_response_diagnostics(config):
        raise ValueError("initialization-response diagnostics require a v04 or v05 configuration")
    periods = _active_periods(config)
    _validate_initialization_response_warmup_memory_compatibility(config, periods)
    dates = pd.DatetimeIndex(regime_preflight.get("dates"))
    if dates.hasnans or not dates.is_unique or not dates.is_monotonic_increasing:
        raise ValueError("fourth-version diagnostic dates must be finite, unique, and increasing")
    if not isinstance(forcing, pd.DataFrame) or not pd.DatetimeIndex(forcing.index).equals(dates):
        raise ValueError("fourth-version diagnostic forcing must match the daily date index")
    required_forcing = ("prcp", "ep", "tmean")
    if not set(required_forcing) <= set(forcing.columns):
        raise ValueError(f"fourth-version forcing must contain {required_forcing}")
    forcing_values = forcing.loc[:, required_forcing].to_numpy(dtype=float)
    if not np.all(np.isfinite(forcing_values)):
        raise ValueError("fourth-version diagnostic forcing must be finite")
    observed = np.asarray(regime_preflight.get("values"), dtype=float)
    if observed.ndim != 1 or len(observed) != len(dates):
        raise ValueError("fourth-version observations must match the daily date index")
    if not np.all(np.isfinite(observed)) or np.any(observed < 0.0):
        raise ValueError("fourth-version observations must be finite and nonnegative")
    if not isinstance(observations, pd.Series) or not pd.DatetimeIndex(observations.index).equals(dates):
        raise ValueError("fourth-version observation Series must match the daily date index")
    if not np.array_equal(observations.to_numpy(dtype=float), observed):
        raise ValueError("fourth-version preflight observations differ from the supplied Series")

    fit_mask = _as_artifact_mask(regime_preflight.get("fit_mask"), len(dates), "fit_mask")
    validation_mask = _as_artifact_mask(
        regime_preflight.get("validation_mask"),
        len(dates),
        "validation_mask",
    )
    warmup_mask = _date_mask(dates, periods["warmup"])
    if int(warmup_mask.sum()) != V04_WARMUP_DAYS:
        raise ValueError("fourth-version replay must contain the exact 3652-day warmup")
    expected_fit_mask = _date_mask(dates, periods["fit"])
    expected_validation_mask = _date_mask(dates, periods["validation"])
    if not np.array_equal(fit_mask, expected_fit_mask) or not np.array_equal(
        validation_mask,
        expected_validation_mask,
    ):
        raise ValueError("fourth-version fit or validation mask differs from frozen periods")
    first_fit_date = dates[fit_mask][0]
    if (first_fit_date.month, first_fit_date.day) != (10, 1):
        raise ValueError("fourth-version fit must start on the first day of a water year")
    first_fit_end = pd.Timestamp(first_fit_date.year + 1, 9, 30)
    first_fit_mask = fit_mask & (dates <= first_fit_end)
    expected_first_fit_dates = pd.date_range(first_fit_date, first_fit_end, freq="D")
    if not dates[first_fit_mask].equals(expected_first_fit_dates):
        raise ValueError("fourth-version first fit water year must be complete")
    replay_mask = warmup_mask | fit_mask
    replay_dates = dates[replay_mask]
    first_fit_replay_mask = np.asarray(replay_dates >= first_fit_date, dtype=bool)
    first_fit_replay_mask &= np.asarray(replay_dates <= first_fit_end, dtype=bool)
    fit_replay_mask = fit_mask[replay_mask]

    thresholds = regime_preflight.get("thresholds")
    low_threshold = float(getattr(thresholds, "low"))
    high_threshold = float(getattr(thresholds, "high"))
    if not np.isfinite(low_threshold) or not np.isfinite(high_threshold) or low_threshold >= high_threshold:
        raise ValueError("fourth-version diagnostics require finite ordered flow thresholds")
    membership = {
        "all_flow": np.ones(len(dates), dtype=bool),
        "low_flow": observed <= low_threshold,
        "high_flow": observed >= high_threshold,
    }
    if set(calibrations) != set(PARAMETER_IDS) or set(evaluations) != set(PARAMETER_IDS):
        raise ValueError("fourth-version diagnostics require exactly three parameter groups")

    initial_hydrograph_frames: list[pd.DataFrame] = []
    initial_metric_rows: list[dict[str, Any]] = []
    response_metric_rows: list[dict[str, Any]] = []
    lag_kernel = str(config["routing_kernel"])
    log_offset = float(config["flow_log_offset_mm_day"])
    for parameter_id in PARAMETER_IDS:
        calibration = calibrations[parameter_id]
        evaluation = evaluations[parameter_id]
        if not isinstance(calibration, Mapping) or not isinstance(evaluation, Mapping):
            raise ValueError(f"fourth-version {parameter_id} records must be mappings")
        selected_identity, _, _ = _selected_restart(calibration, parameter_id)
        calibration_records = calibration.get("restart_records")
        evaluation_records = evaluation.get("restart_metrics")
        if (
            not isinstance(calibration_records, Sequence)
            or isinstance(calibration_records, (str, bytes))
            or not isinstance(evaluation_records, Sequence)
            or isinstance(evaluation_records, (str, bytes))
        ):
            raise ValueError(f"fourth-version {parameter_id} restart records must be sequences")
        calibration_by_identity = {
            _strict_restart_identity(record, f"{parameter_id} calibration restart {position}"): record
            for position, record in enumerate(calibration_records)
        }
        evaluation_by_identity = {
            _strict_restart_identity(record, f"{parameter_id} evaluation restart {position}"): record
            for position, record in enumerate(evaluation_records)
        }
        if (
            len(calibration_by_identity) != len(calibration_records)
            or len(evaluation_by_identity) != len(evaluation_records)
            or set(calibration_by_identity) != set(evaluation_by_identity)
        ):
            raise ValueError(
                f"fourth-version {parameter_id} restart identities differ across fit and replay"
            )

        for identity in sorted(calibration_by_identity):
            restart_index, seed = identity
            calibration_record = calibration_by_identity[identity]
            evaluation_record = evaluation_by_identity[identity]
            parameters = calibration_record.get("optimized_params")
            fingerprint = _parameter_sha256(
                parameters,
                f"fourth-version {parameter_id} restart {restart_index} parameters",
            )
            replay_fingerprint = _parameter_sha256(
                evaluation_record.get("optimized_params"),
                f"fourth-version {parameter_id} replay restart {restart_index} parameters",
            )
            if fingerprint != replay_fingerprint:
                raise ValueError("fourth-version diagnostic parameter fingerprints differ")
            selected = identity == selected_identity
            initial_states = {
                scenario_id: {
                    "SNOWPACK": 0.0,
                    "MELTWATER": 0.0,
                    "SM": 0.3 * float(parameters["parFC"]),
                    "SUZ": 5.0,
                    "SLZ": initial_slz,
                }
                for scenario_id, initial_slz in (("dry", 0.0), ("wet", 100.0))
            }
            final_states: dict[str, Mapping[str, Any]] = {}
            replay_flows: dict[str, np.ndarray] = {}
            for scenario_id, initial_state in initial_states.items():
                _, final_state = simulate_hbv_lite(
                    forcing.loc[warmup_mask, "prcp"].to_numpy(dtype=float),
                    forcing.loc[warmup_mask, "ep"].to_numpy(dtype=float),
                    forcing.loc[warmup_mask, "tmean"].to_numpy(dtype=float),
                    dict(parameters),
                    initial_state=initial_state,
                    lag_kernel=lag_kernel,
                )
                replay_flow, _ = simulate_hbv_lite(
                    forcing.loc[replay_mask, "prcp"].to_numpy(dtype=float),
                    forcing.loc[replay_mask, "ep"].to_numpy(dtype=float),
                    forcing.loc[replay_mask, "tmean"].to_numpy(dtype=float),
                    dict(parameters),
                    initial_state=initial_state,
                    lag_kernel=lag_kernel,
                )
                replay_flow = np.asarray(replay_flow, dtype=float)
                if replay_flow.shape != (int(replay_mask.sum()),):
                    raise ValueError("fourth-version initial-state replay has the wrong length")
                if not np.all(np.isfinite(replay_flow)) or np.any(replay_flow < 0.0):
                    raise ValueError("fourth-version initial-state replay flow must be finite and nonnegative")
                if not isinstance(final_state, Mapping) or "SLZ" not in final_state:
                    raise ValueError("fourth-version warmup replay lacks final SLZ")
                final_states[scenario_id] = final_state
                replay_flows[scenario_id] = replay_flow

            output_distances = {}
            replay_observed = observed[replay_mask]
            for day_set in PARAMETER_IDS:
                fit_scale_membership = membership[day_set][replay_mask] & fit_replay_mask
                selected_membership = membership[day_set][replay_mask] & first_fit_replay_mask
                output_distances[day_set] = output_functional_distance(
                    replay_flows["dry"],
                    replay_flows["wet"],
                    replay_observed,
                    fit_scale_membership,
                    selected_membership,
                    transform=("log_q_plus_offset" if day_set == "low_flow" else "identity"),
                    log_offset=log_offset if day_set == "low_flow" else None,
                    maximum_distance=0.03,
                )
            dry_scenario = {
                "scenario_id": "dry",
                "parameter_sha256": fingerprint,
                "initial_slz_mm": 0.0,
                "final_slz_mm": float(final_states["dry"]["SLZ"]),
            }
            wet_scenario = {
                "scenario_id": "wet",
                "parameter_sha256": fingerprint,
                "initial_slz_mm": 100.0,
                "final_slz_mm": float(final_states["wet"]["SLZ"]),
            }
            convergence = initial_state_convergence_diagnostics(
                dry_scenario,
                wet_scenario,
                output_distances,
                par_k2=float(parameters["parK2"]),
                warmup_days=V04_WARMUP_DAYS,
                retained_fraction_max=V04_RETAINED_FRACTION_MAX,
                maximum_distance=0.03,
                flow_log_offset=log_offset,
            )
            evaluation_record["initial_state_convergence_diagnostics"] = convergence
            first_fit_observed = observed[first_fit_mask]
            first_fit_membership = {
                day_set: values[first_fit_mask] for day_set, values in membership.items()
            }
            for scenario_id in ("dry", "wet"):
                initial_hydrograph_frames.append(
                    pd.DataFrame({
                        "parameter_id": parameter_id,
                        "restart_index": restart_index,
                        "seed": seed,
                        "selected": selected,
                        "scenario_id": scenario_id,
                        "date": dates[first_fit_mask],
                        "observed_flow_mm_day": first_fit_observed,
                        "simulated_flow_mm_day": replay_flows[scenario_id][first_fit_replay_mask],
                        "all_flow_member": first_fit_membership["all_flow"],
                        "low_flow_member": first_fit_membership["low_flow"],
                        "high_flow_member": first_fit_membership["high_flow"],
                        "parameter_sha256": fingerprint,
                    }).loc[:, V04_INITIAL_HYDROGRAPH_COLUMNS]
                )
            for day_set in PARAMETER_IDS:
                distance = convergence["output_functional_distance_gate"]["day_sets"][day_set]
                initial_metric_rows.append({
                    "parameter_id": parameter_id,
                    "restart_index": restart_index,
                    "seed": seed,
                    "selected": selected,
                    "parameter_sha256": fingerprint,
                    "dry_scenario_id": "dry",
                    "wet_scenario_id": "wet",
                    "dry_initial_slz_mm": 0.0,
                    "wet_initial_slz_mm": 100.0,
                    "dry_final_slz_mm": dry_scenario["final_slz_mm"],
                    "wet_final_slz_mm": wet_scenario["final_slz_mm"],
                    "par_k2": convergence["par_k2"],
                    "warmup_days": convergence["warmup_days"],
                    "initial_slz_difference_mm": convergence["initial_slz_difference_mm"],
                    "final_slz_difference_mm": convergence["final_slz_difference_mm"],
                    "analytical_retained_fraction": convergence["analytical_retained_fraction"],
                    "replayed_retained_fraction": convergence["replayed_retained_fraction"],
                    "retained_fraction_max": convergence["retained_fraction_max"],
                    "analytical_retained_fraction_pass": convergence[
                        "analytical_retained_fraction_pass"
                    ],
                    "replayed_retained_fraction_pass": convergence[
                        "replayed_retained_fraction_pass"
                    ],
                    "retained_fraction_matches_analytical": convergence[
                        "retained_fraction_matches_analytical"
                    ],
                    "day_set": day_set,
                    **{key: distance[key] for key in (
                        "numerator",
                        "denominator",
                        "distance",
                        "fit_scale_count",
                        "validation_compare_count",
                        "transform",
                        "log_offset",
                        "maximum_distance",
                    )},
                    "distance_pass": distance["passes"],
                    "initial_state_convergence_passes": convergence["passes"],
                })

            simulated = np.asarray(evaluation_record.get("simulated_flow"), dtype=float)
            if simulated.shape != observed.shape or not np.all(np.isfinite(simulated)) or np.any(
                simulated < 0.0
            ):
                raise ValueError("fourth-version validation replay flow is invalid")
            response = hydrograph_response_diagnostics(
                observed[validation_mask],
                simulated[validation_mask],
                dates[validation_mask],
                mean_offset=log_offset,
            )
            evaluation_record["hydrograph_response_diagnostics"] = response
            for record in response["water_years"]:
                response_metric_rows.append({
                    "parameter_id": parameter_id,
                    "restart_index": restart_index,
                    "seed": seed,
                    "selected": selected,
                    "parameter_sha256": fingerprint,
                    **record,
                })

    return {
        "initial_state_convergence_hydrographs": pd.concat(
            initial_hydrograph_frames,
            ignore_index=True,
        ).loc[:, V04_INITIAL_HYDROGRAPH_COLUMNS],
        "initial_state_convergence_metrics": pd.DataFrame(
            initial_metric_rows,
            columns=V04_INITIAL_METRIC_COLUMNS,
        ),
        "hydrograph_response_metrics": pd.DataFrame(
            response_metric_rows,
            columns=V04_RESPONSE_METRIC_COLUMNS,
        ),
    }


def _legacy_apply_parameter_quality_gates_v04_from_tables(
    v03_quality_gates: Mapping[str, Any],
    initial_state_metrics: pd.DataFrame,
    hydrograph_response_metrics: pd.DataFrame,
) -> dict[str, Any]:
    """Restrict v03-qualified fixed restarts with both v04 physical gates."""

    if not isinstance(v03_quality_gates, Mapping):
        raise ValueError("third-version quality gates must be a mapping")
    for table, columns, label in (
        (
            initial_state_metrics,
            V04_INITIAL_METRIC_COLUMNS,
            "initial-state convergence metrics",
        ),
        (
            hydrograph_response_metrics,
            V04_RESPONSE_METRIC_COLUMNS,
            "hydrograph response metrics",
        ),
    ):
        if not isinstance(table, pd.DataFrame) or table.empty or tuple(table.columns) != columns:
            raise ValueError(f"fourth-version {label} columns or rows are incomplete")

    initial = initial_state_metrics.copy()
    response = hydrograph_response_metrics.copy()
    for table, label in ((initial, "initial-state"), (response, "response")):
        table["selected"] = _coerce_artifact_booleans(
            table["selected"],
            f"fourth-version {label} selected",
        )
        for column in ("restart_index", "seed"):
            table[column] = [
                _strict_artifact_integer(
                    value,
                    f"fourth-version {label} {column}",
                    minimum=0,
                )
                for value in table[column]
            ]
    identity_columns = ["parameter_id", "restart_index", "seed"]
    initial_identities = set(map(tuple, initial[identity_columns].drop_duplicates().to_numpy()))
    response_identities = set(map(tuple, response[identity_columns].drop_duplicates().to_numpy()))
    if initial_identities != response_identities:
        raise ValueError("fourth-version diagnostic restart identities differ across tables")

    result = copy.deepcopy(dict(v03_quality_gates))
    result["quality_gate_version"] = "v04_initialization_and_response"
    for parameter_id in PARAMETER_IDS:
        group = result.get(parameter_id)
        if not isinstance(group, Mapping):
            raise ValueError(f"fourth-version quality gates lack {parameter_id}")
        group = dict(group)
        result[parameter_id] = group
        group_initial = initial[initial["parameter_id"] == parameter_id]
        group_response = response[response["parameter_id"] == parameter_id]
        identities = sorted(
            (int(row.restart_index), int(row.seed))
            for row in group_initial[["restart_index", "seed"]].drop_duplicates().itertuples(
                index=False
            )
        )
        selected_identities = {
            (int(row.restart_index), int(row.seed))
            for row in group_initial[group_initial["selected"]][["restart_index", "seed"]]
            .drop_duplicates()
            .itertuples(index=False)
        }
        response_selected = {
            (int(row.restart_index), int(row.seed))
            for row in group_response[group_response["selected"]][["restart_index", "seed"]]
            .drop_duplicates()
            .itertuples(index=False)
        }
        if len(selected_identities) != 1 or response_selected != selected_identities:
            raise ValueError(f"fourth-version {parameter_id} selected restart identity is inconsistent")
        selected_identity = next(iter(selected_identities))

        initial_pass_by_identity: dict[tuple[int, int], bool] = {}
        response_pass_by_identity: dict[tuple[int, int], bool] = {}
        for identity in identities:
            restart_initial = group_initial[
                (group_initial["restart_index"] == identity[0])
                & (group_initial["seed"] == identity[1])
            ]
            if set(restart_initial["day_set"]) != set(PARAMETER_IDS) or len(restart_initial) != 3:
                raise ValueError("fourth-version initial-state metrics must contain three day sets")
            distance_passes = _coerce_artifact_booleans(
                restart_initial["distance_pass"],
                "fourth-version initial-state distance pass",
            )
            summary_passes = _coerce_artifact_booleans(
                restart_initial["initial_state_convergence_passes"],
                "fourth-version initial-state summary pass",
            )
            analytical_passes = _coerce_artifact_booleans(
                restart_initial["analytical_retained_fraction_pass"],
                "fourth-version analytical memory pass",
            )
            replayed_passes = _coerce_artifact_booleans(
                restart_initial["replayed_retained_fraction_pass"],
                "fourth-version replayed memory pass",
            )
            matching_passes = _coerce_artifact_booleans(
                restart_initial["retained_fraction_matches_analytical"],
                "fourth-version retained-fraction identity pass",
            )
            expected_initial_pass = bool(
                distance_passes.all()
                and analytical_passes.all()
                and replayed_passes.all()
                and matching_passes.all()
            )
            if not np.all(summary_passes == expected_initial_pass):
                raise ValueError("fourth-version initial-state summary differs from component gates")
            initial_pass_by_identity[identity] = expected_initial_pass

            restart_response = group_response[
                (group_response["restart_index"] == identity[0])
                & (group_response["seed"] == identity[1])
            ]
            if restart_response.empty or restart_response["water_year"].duplicated().any():
                raise ValueError("fourth-version response metrics lack unique water years")
            year_passes: list[bool] = []
            for row in restart_response.itertuples(index=False):
                variability_pass = bool(
                    float(row.variability_ratio_min)
                    <= float(row.variability_ratio)
                    <= float(row.variability_ratio_max)
                )
                mean_pass = bool(
                    float(row.mean_ratio_min) <= float(row.mean_ratio) <= float(row.mean_ratio_max)
                )
                variation_pass = bool(
                    float(row.total_variation_ratio_min)
                    <= float(row.total_variation_ratio)
                    <= float(row.total_variation_ratio_max)
                )
                expected_year_pass = variability_pass and mean_pass and variation_pass
                if (
                    bool(row.variability_ratio_pass) != variability_pass
                    or bool(row.mean_ratio_pass) != mean_pass
                    or bool(row.total_variation_ratio_pass) != variation_pass
                    or bool(row.passes) != expected_year_pass
                ):
                    raise ValueError("fourth-version response summary differs from ratio gates")
                year_passes.append(expected_year_pass)
            response_pass_by_identity[identity] = bool(all(year_passes))

        diagnostics = group.get("restart_diagnostics")
        if not isinstance(diagnostics, list):
            raise ValueError(f"fourth-version {parameter_id} lacks restart diagnostics")
        diagnostic_by_identity = {
            (
                _strict_artifact_integer(
                    diagnostic.get("restart_index"),
                    "fourth-version quality restart_index",
                    minimum=0,
                ),
                _strict_artifact_integer(
                    diagnostic.get("seed"),
                    "fourth-version quality seed",
                    minimum=0,
                ),
            ): diagnostic
            for diagnostic in diagnostics
            if isinstance(diagnostic, Mapping)
        }
        if set(diagnostic_by_identity) != set(identities):
            raise ValueError("fourth-version quality and raw diagnostic identities differ")
        rebuilt_support = []
        for identity in identities:
            diagnostic = diagnostic_by_identity[identity]
            prior_support = diagnostic.get("qualifies_as_support")
            if not isinstance(prior_support, (bool, np.bool_)):
                raise ValueError("third-version support qualification must be boolean")
            diagnostic["v03_qualifies_as_support"] = bool(prior_support)
            diagnostic["initial_state_convergence_gate"] = {
                "passes": initial_pass_by_identity[identity]
            }
            diagnostic["hydrograph_response_gate"] = {
                "passes": response_pass_by_identity[identity]
            }
            diagnostic["qualifies_as_support"] = bool(
                identity != selected_identity
                and prior_support
                and initial_pass_by_identity[identity]
                and response_pass_by_identity[identity]
            )
            if diagnostic["qualifies_as_support"]:
                rebuilt_support.append(diagnostic)
        minimum_support = _strict_artifact_integer(
            group.get("minimum_support_restarts"),
            "fourth-version minimum support restarts",
            minimum=1,
        )
        selected_initial_pass = initial_pass_by_identity[selected_identity]
        selected_response_pass = response_pass_by_identity[selected_identity]
        prior_group_qualifies = group.get("qualifies")
        if not isinstance(prior_group_qualifies, (bool, np.bool_)):
            raise ValueError("third-version group qualification must be boolean")
        group["selected_restart_identity"] = {
            "restart_index": selected_identity[0],
            "seed": selected_identity[1],
        }
        group["selected_initial_state_convergence_pass"] = selected_initial_pass
        group["selected_hydrograph_response_pass"] = selected_response_pass
        group["v03_qualifies"] = bool(prior_group_qualifies)
        group["support_restarts"] = rebuilt_support
        group["support_restart_count"] = len(rebuilt_support)
        group["support_restart_pass"] = bool(len(rebuilt_support) >= minimum_support)
        group["qualifies"] = bool(
            prior_group_qualifies
            and selected_initial_pass
            and selected_response_pass
            and group["support_restart_pass"]
        )

    result["all_specialists_qualify"] = bool(
        result["low_flow"]["qualifies"] and result["high_flow"]["qualifies"]
    )
    result["all_parameter_sets_qualify"] = bool(
        result["all_flow"]["qualifies"] and result["all_specialists_qualify"]
    )
    return result


def _coerce_artifact_booleans(series: pd.Series, label: str) -> np.ndarray:
    result: list[bool] = []
    for value in series.tolist():
        if isinstance(value, (bool, np.bool_)):
            result.append(bool(value))
        elif isinstance(value, str) and value.strip().lower() in {"true", "false"}:
            result.append(value.strip().lower() == "true")
        else:
            raise ValueError(f"v03 {label} must contain only Boolean values")
    return np.asarray(result, dtype=bool)


def _restart_execution_table(
    calibrations: Mapping[str, Mapping[str, Any]],
    config: Mapping[str, Any],
) -> pd.DataFrame:
    """Normalize successful low-level optimizer telemetry for independent audit."""

    rows: list[dict[str, Any]] = []
    declared_threshold = int(config["optimizer"]["function_evaluations_per_restart"])
    bounds_preset = str(config["parameter_bounds_preset"])
    objective_names = {
        "all_flow": "nse",
        "low_flow": "log_mse",
        "high_flow": "raw_mse",
    }
    for parameter_id in PARAMETER_IDS:
        calibration = calibrations.get(parameter_id)
        if not isinstance(calibration, Mapping):
            raise ValueError(f"v03 telemetry lacks {parameter_id} calibration")
        objective_days = calibration.get("fit_objective_days")
        if (
            isinstance(objective_days, (bool, np.bool_))
            or not isinstance(objective_days, (int, np.integer))
            or int(objective_days) < 1
        ):
            raise ValueError(f"v03 telemetry {parameter_id} objective-day count is invalid")
        restart_records = calibration.get("restart_records")
        if not isinstance(restart_records, Sequence) or isinstance(restart_records, (str, bytes)):
            raise ValueError(f"v03 telemetry {parameter_id} restart_records must be a sequence")
        selected_index = calibration.get("selected_restart_index")
        selected_seed = calibration.get("selected_restart_seed")
        if isinstance(selected_index, bool) or not isinstance(selected_index, int):
            raise ValueError(f"v03 telemetry {parameter_id} selected restart index is missing")
        if isinstance(selected_seed, bool) or not isinstance(selected_seed, int):
            raise ValueError(f"v03 telemetry {parameter_id} selected restart seed is missing")
        for position, record in enumerate(restart_records):
            if not isinstance(record, Mapping):
                raise ValueError(f"v03 telemetry {parameter_id} restart {position} must be a mapping")
            restart_index, seed = _strict_restart_identity(
                record,
                f"v03 telemetry {parameter_id} restart {position}",
            )
            fingerprint = _parameter_sha256(
                record.get("optimized_params"),
                f"v03 telemetry {parameter_id} restart {position} parameters",
            )
            declared_field = (
                "declared_maxfevals_stop_threshold"
                if "declared_maxfevals_stop_threshold" in record
                else "declared_evaluation_ceiling"
            )
            if declared_field != "declared_maxfevals_stop_threshold":
                raise ValueError(
                    "v03 telemetry must call maxfevals a stop threshold, not an evaluation ceiling"
                )
            integer_fields = (
                declared_field,
                "objective_call_count",
                "optimizer_evaluation_count",
                "optimizer_iteration_count",
                "objective_exception_count",
                "objective_nonfinite_count",
                "objective_penalty_count",
            )
            counts: dict[str, int] = {}
            for field in integer_fields:
                value = record.get(field)
                if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)):
                    raise ValueError(f"v03 telemetry {field} must be an integer")
                if int(value) < 0:
                    raise ValueError(f"v03 telemetry {field} must be nonnegative")
                counts[field] = int(value)
            if counts[declared_field] != declared_threshold:
                raise ValueError("v03 telemetry declared maxfevals threshold differs from config")
            counts_agree = record.get("evaluation_counts_agree")
            if not isinstance(counts_agree, (bool, np.bool_)) or not bool(counts_agree):
                raise ValueError("v03 telemetry objective and optimizer evaluation counts disagree")
            if counts["objective_call_count"] != counts["optimizer_evaluation_count"]:
                raise ValueError("v03 telemetry evaluation count equality flag is inconsistent")
            status = str(record.get("status", ""))
            if status != "completed":
                raise ValueError("v03 successful telemetry row must have completed status")
            raw_stop = record.get("stop_reasons_raw")
            normalized_stop = record.get("stop_reasons_normalized")
            if not isinstance(raw_stop, Mapping) or not raw_stop:
                raise ValueError("v03 telemetry raw stop reasons must be a nonempty mapping")
            if (
                not isinstance(normalized_stop, Sequence)
                or isinstance(normalized_stop, (str, bytes))
                or not normalized_stop
            ):
                raise ValueError("v03 telemetry normalized stop reasons must be nonempty")
            primary = str(record.get("stop_reason_primary", ""))
            if primary != str(normalized_stop[0]):
                raise ValueError("v03 telemetry primary stop reason is inconsistent")
            for timestamp_field in ("started_at", "ended_at"):
                try:
                    parsed = datetime.fromisoformat(str(record.get(timestamp_field)))
                except ValueError as error:
                    raise ValueError(f"v03 telemetry {timestamp_field} must be ISO-8601") from error
                if parsed.tzinfo is None or parsed.utcoffset() is None:
                    raise ValueError(f"v03 telemetry {timestamp_field} must include a timezone")
            elapsed = float(record.get("elapsed_seconds", float("nan")))
            best_loss = float(record.get("best_loss", float("nan")))
            if not np.isfinite(elapsed) or elapsed < 0.0 or not np.isfinite(best_loss):
                raise ValueError("v03 telemetry elapsed time and best loss must be finite")
            if not np.isclose(
                best_loss,
                float(record.get("objective_loss", float("nan"))),
                rtol=0.0,
                atol=1e-12,
            ):
                raise ValueError("v03 telemetry best loss differs from the restart fit loss")
            if str(record.get("best_parameter_fingerprint", "")) != fingerprint:
                raise ValueError("v03 telemetry best parameter fingerprint is inconsistent")
            selected = record.get("selected")
            expected_selected = restart_index == selected_index and seed == selected_seed
            if not isinstance(selected, (bool, np.bool_)) or bool(selected) != expected_selected:
                raise ValueError("v03 telemetry selected restart identity is inconsistent")
            exception_type = record.get("exception_type")
            exception_message = record.get("exception_message")
            if exception_type not in (None, "") or exception_message not in (None, ""):
                raise ValueError("v03 completed telemetry must not contain an exception")
            rows.append({
                "parameter_id": parameter_id,
                "restart_index": restart_index,
                "seed": seed,
                "declared_maxfevals_stop_threshold": counts[declared_field],
                "initial_mean_normalized": 0.5,
                "initial_sigma_normalized": 0.3,
                "parameter_bounds_preset": bounds_preset,
                "objective_name": objective_names[parameter_id],
                "objective_day_count": int(objective_days),
                "objective_call_count": counts["objective_call_count"],
                "optimizer_evaluation_count": counts["optimizer_evaluation_count"],
                "optimizer_iteration_count": counts["optimizer_iteration_count"],
                "evaluation_counts_agree": True,
                "objective_exception_count": counts["objective_exception_count"],
                "objective_nonfinite_count": counts["objective_nonfinite_count"],
                "objective_penalty_count": counts["objective_penalty_count"],
                "stop_reasons_raw_json": json.dumps(
                    _json_ready(raw_stop),
                    sort_keys=True,
                    separators=(",", ":"),
                ),
                "stop_reasons_normalized_json": json.dumps(
                    _json_ready(list(normalized_stop)),
                    separators=(",", ":"),
                ),
                "stop_reason_primary": primary,
                "started_at": str(record["started_at"]),
                "ended_at": str(record["ended_at"]),
                "elapsed_seconds": elapsed,
                "status": status,
                "exception_type": "",
                "exception_message": "",
                "best_loss": best_loss,
                "best_parameter_fingerprint": fingerprint,
                "selected": bool(selected),
            })
    table = pd.DataFrame(rows, columns=V03_LOCAL_RESTART_EXECUTION_COLUMNS)
    if len(table) != len(PARAMETER_IDS) * 3:
        raise ValueError("v03 telemetry must contain three restarts for every parameter group")
    return table


def _verify_v03_restart_execution_links(
    restart_execution: pd.DataFrame,
    restart_vectors: pd.DataFrame,
    expected_basin_ids: Sequence[str],
) -> dict[str, str]:
    """Join optimizer telemetry to raw parameters without trusting either summary."""

    if tuple(restart_execution.columns) != V03_RESTART_EXECUTION_COLUMNS:
        raise ValueError("v03 restart execution columns or order differ from the contract")
    execution = restart_execution.copy()
    vectors = restart_vectors.copy()
    for table, label in ((execution, "execution"), (vectors, "parameter vector")):
        if "basin_id" not in table:
            raise ValueError(f"v03 restart {label} lacks basin_id")
        table["basin_id"] = table["basin_id"].astype(str).str.zfill(8)
    expected_basins = tuple(str(value).zfill(8) for value in expected_basin_ids)
    if tuple(execution["basin_id"].drop_duplicates()) != expected_basins:
        raise ValueError("v03 restart execution basin order differs from the manifest")
    for table_name, table in (("execution", execution), ("parameter vector", vectors)):
        for column in ("restart_index", "seed"):
            table[column] = [
                _strict_artifact_integer(
                    value,
                    f"v03 restart {table_name} {column}",
                    minimum=0,
                )
                for value in table[column]
            ]
    execution["selected"] = _coerce_artifact_booleans(
        execution["selected"], "restart execution selected"
    )
    vectors["selected"] = _coerce_artifact_booleans(
        vectors["selected"], "restart parameter selected"
    )
    identity = ["basin_id", "parameter_id", "restart_index", "seed"]
    if execution.duplicated(identity).any() or vectors.duplicated(identity).any():
        raise ValueError("v03 restart execution link contains duplicate identities")
    joined = execution.merge(
        vectors[
            [
                *identity,
                "selected",
                "fit_objective_loss",
                "parameter_sha256",
            ]
        ],
        on=identity,
        how="outer",
        validate="one_to_one",
        suffixes=("_execution", "_vector"),
        indicator=True,
    )
    if len(joined) != 27 or set(joined["_merge"]) != {"both"}:
        raise ValueError("v03 restart execution identities differ from raw parameter vectors")
    if not np.array_equal(
        joined["selected_execution"].to_numpy(dtype=bool),
        joined["selected_vector"].to_numpy(dtype=bool),
    ):
        raise ValueError("v03 restart execution selected flags differ from raw parameter vectors")
    if not np.allclose(
        pd.to_numeric(joined["best_loss"], errors="raise").to_numpy(dtype=float),
        pd.to_numeric(joined["fit_objective_loss"], errors="raise").to_numpy(dtype=float),
        rtol=0.0,
        atol=1e-12,
    ):
        raise ValueError("v03 restart execution best losses differ from raw fit losses")
    if not np.array_equal(
        joined["best_parameter_fingerprint"].astype(str).to_numpy(),
        joined["parameter_sha256"].astype(str).to_numpy(),
    ):
        raise ValueError("v03 restart execution fingerprints differ from raw parameter vectors")
    run_instances = set(execution["run_instance_id"].astype(str))
    if len(run_instances) != 1 or not next(iter(run_instances)):
        raise ValueError("v03 restart execution must contain one nonempty run instance")
    return {
        f"{row['basin_id']}/{row['parameter_id']}": str(row["parameter_sha256"])
        for _, row in joined[joined["selected_vector"]].iterrows()
    }


def _v03_objective_day_counts(preflight: Mapping[str, Any]) -> dict[str, int]:
    fit = np.asarray(preflight["fit_mask"], dtype=bool)
    values = np.asarray(preflight["values"], dtype=float)
    thresholds = preflight["thresholds"]
    if len(fit) != len(values):
        raise ValueError("v03 preflight masks and observations have different lengths")
    return {
        "all_flow": int(fit.sum()),
        "low_flow": int(np.sum(fit & (values <= float(thresholds.low)))),
        "high_flow": int(np.sum(fit & (values >= float(thresholds.high)))),
    }


def _partial_v03_restart_execution_table(
    contract: AccessContract,
    telemetry_by_basin: Mapping[str, Mapping[str, list[dict[str, Any]]]],
    regime_preflights: Mapping[str, Mapping[str, Any]],
    run_instance_id: str,
) -> pd.DataFrame:
    """Preserve the canonical telemetry prefix without inventing a failed restart."""

    rows: list[dict[str, Any]] = []
    objective_names = v03_execution_evidence.PARAMETER_OBJECTIVES
    threshold = int(contract.config["optimizer"]["function_evaluations_per_restart"])
    bounds_preset = str(contract.config["parameter_bounds_preset"])
    gap_seen = False
    for basin_id in contract.basin_ids:
        collectors = telemetry_by_basin.get(basin_id, {})
        day_counts: Mapping[str, int] | None = None
        for parameter_id in PARAMETER_IDS:
            records = collectors.get(parameter_id, ())
            if not isinstance(records, Sequence) or isinstance(records, (str, bytes)):
                raise ValueError("v03 partial telemetry collector has an invalid type")
            if len(records) > len(contract.config["optimizer"]["restart_seeds"]):
                raise ValueError("v03 partial telemetry contains too many restart rows")
            if gap_seen and records:
                raise ValueError("v03 partial telemetry is not a canonical execution prefix")
            if not records:
                gap_seen = True
                continue
            if day_counts is None:
                if basin_id not in regime_preflights:
                    raise ValueError("v03 restart telemetry lacks its regime preflight")
                day_counts = _v03_objective_day_counts(regime_preflights[basin_id])
            for position, record in enumerate(records):
                if not isinstance(record, Mapping):
                    raise ValueError("v03 partial telemetry record must be a mapping")
                restart_index = record.get("restart_index")
                seed = record.get("seed")
                expected_seed = int(contract.config["optimizer"]["restart_seeds"][position])
                if restart_index != position or seed != expected_seed:
                    raise ValueError("v03 partial telemetry identity is not canonical")
                raw_stop = record.get("stop_reasons_raw")
                normalized_stop = record.get("stop_reasons_normalized")
                rows.append({
                    "run_instance_id": run_instance_id,
                    "basin_id": basin_id,
                    "parameter_id": parameter_id,
                    "restart_index": int(restart_index),
                    "seed": int(seed),
                    "declared_maxfevals_stop_threshold": int(
                        record.get("declared_maxfevals_stop_threshold", threshold)
                    ),
                    "initial_mean_normalized": 0.5,
                    "initial_sigma_normalized": 0.3,
                    "parameter_bounds_preset": bounds_preset,
                    "objective_name": objective_names[parameter_id],
                    "objective_day_count": int(day_counts[parameter_id]),
                    "objective_call_count": int(record.get("objective_call_count", 0)),
                    "optimizer_evaluation_count": record.get("optimizer_evaluation_count"),
                    "optimizer_iteration_count": record.get("optimizer_iteration_count"),
                    "evaluation_counts_agree": record.get("evaluation_counts_agree"),
                    "objective_exception_count": int(
                        record.get("objective_exception_count", 0)
                    ),
                    "objective_nonfinite_count": int(
                        record.get("objective_nonfinite_count", 0)
                    ),
                    "objective_penalty_count": int(record.get("objective_penalty_count", 0)),
                    "stop_reasons_raw_json": json.dumps(
                        _json_ready({} if raw_stop is None else raw_stop),
                        sort_keys=True,
                        separators=(",", ":"),
                    ),
                    "stop_reasons_normalized_json": json.dumps(
                        _json_ready([] if normalized_stop is None else normalized_stop),
                        separators=(",", ":"),
                    ),
                    "stop_reason_primary": record.get("stop_reason_primary") or "",
                    "started_at": str(record.get("started_at", "")),
                    "ended_at": str(record.get("ended_at", "")),
                    "elapsed_seconds": record.get("elapsed_seconds"),
                    "status": str(record.get("status", "")),
                    "exception_type": record.get("exception_type") or "",
                    "exception_message": record.get("exception_message") or "",
                    "best_loss": record.get("best_loss"),
                    "best_parameter_fingerprint": (
                        record.get("best_parameter_fingerprint") or ""
                    ),
                    "selected": bool(record.get("selected", False)),
                })
            if len(records) < len(contract.config["optimizer"]["restart_seeds"]):
                gap_seen = True
    table = pd.DataFrame(rows, columns=V03_RESTART_EXECUTION_COLUMNS)
    failed_count = int((table["status"] == "failed").sum()) if not table.empty else 0
    if failed_count > 1 or (
        failed_count == 1 and table.iloc[-1]["status"] != "failed"
    ):
        raise ValueError("v03 partial evidence has a noncanonical failed restart")
    if not table.empty and not set(table["status"]) <= {"completed", "failed"}:
        raise ValueError("v03 partial evidence contains an unknown restart status")
    return table


def _independent_functional_distance_from_artifacts(
    selected: np.ndarray,
    restart: np.ndarray,
    observations: np.ndarray,
    fit_mask: np.ndarray,
    validation_mask: np.ndarray,
    *,
    transform: str,
    log_offset: float | None,
    maximum_distance: float,
) -> dict[str, Any]:
    """Independently recompute the frozen formula without the scoring helper."""

    if transform == "identity":
        transformed_observations = observations
        transformed_selected = selected
        transformed_restart = restart
        recorded_offset = None
    elif transform == "log_q_plus_offset":
        if log_offset is None or not np.isfinite(log_offset) or log_offset <= 0.0:
            raise ValueError("v03 independent verifier requires a positive log offset")
        transformed_observations = np.log(observations + float(log_offset))
        transformed_selected = np.log(selected + float(log_offset))
        transformed_restart = np.log(restart + float(log_offset))
        recorded_offset = float(log_offset)
    else:
        raise ValueError("v03 independent verifier encountered an unknown transform")
    denominator = float(np.var(transformed_observations[fit_mask], ddof=0))
    numerator = float(
        np.mean(
            np.square(
                transformed_restart[validation_mask]
                - transformed_selected[validation_mask]
            )
        )
    )
    distance = float(numerator / denominator)
    if (
        not np.isfinite(denominator)
        or denominator <= 0.0
        or not np.isfinite(numerator)
        or numerator < 0.0
        or not np.isfinite(distance)
    ):
        raise ValueError("v03 independent functional distance is invalid")
    return {
        "numerator": numerator,
        "denominator": denominator,
        "distance": distance,
        "fit_scale_count": int(fit_mask.sum()),
        "validation_compare_count": int(validation_mask.sum()),
        "transform": transform,
        "log_offset": recorded_offset,
        "maximum_distance": float(maximum_distance),
        "passes": bool(distance <= float(maximum_distance)),
    }


def _independent_parameter_distance_from_artifacts(
    selected: Mapping[str, float],
    restart: Mapping[str, float],
    parameter_bounds: Mapping[str, tuple[float, float]],
) -> float:
    squared = []
    for name, raw_bounds in parameter_bounds.items():
        lower, upper = (float(value) for value in raw_bounds)
        width = upper - lower
        if not np.isfinite(width) or width <= 0.0:
            raise ValueError("v03 independent verifier encountered invalid parameter bounds")
        squared.append(((float(selected[name]) - float(restart[name])) / width) ** 2)
    return float(np.sqrt(np.mean(squared)))


def _independent_nse(observed: np.ndarray, simulated: np.ndarray) -> float:
    denominator = float(np.sum(np.square(observed - observed.mean())))
    if not np.isfinite(denominator) or denominator <= 0.0:
        raise ValueError("v03 independent NSE denominator must be finite and positive")
    value = 1.0 - float(np.sum(np.square(simulated - observed))) / denominator
    if not np.isfinite(value):
        raise ValueError("v03 independent NSE must be finite")
    return value


def _independent_fit_objective(rows: pd.DataFrame, parameter_id: str) -> float:
    objective = rows["objective_member"].to_numpy(dtype=bool)
    observed = rows.loc[objective, "observed_flow_mm_day"].to_numpy(dtype=float)
    simulated = rows.loc[objective, "simulated_flow_mm_day"].to_numpy(dtype=float)
    if len(observed) == 0:
        raise ValueError("v03 fit objective has no stored days")
    if parameter_id == "all_flow":
        return 1.0 - _independent_nse(observed, simulated)
    if parameter_id == "low_flow":
        return float(
            np.mean(
                np.square(
                    np.log(simulated + 0.01) - np.log(observed + 0.01)
                )
            )
        )
    if parameter_id == "high_flow":
        return float(np.mean(np.square(simulated - observed)))
    raise ValueError("v03 fit objective has an unknown parameter group")


def _independent_validation_record(rows: pd.DataFrame) -> dict[str, Any]:
    observed = rows["observed_flow_mm_day"].to_numpy(dtype=float)
    simulated = rows["simulated_flow_mm_day"].to_numpy(dtype=float)
    low = rows["low_flow_member"].to_numpy(dtype=bool)
    high = rows["high_flow_member"].to_numpy(dtype=bool)
    dates = pd.DatetimeIndex(pd.to_datetime(rows["date"], errors="raise"))
    low_loss = float(
        np.mean(
            np.square(
                np.log(simulated[low] + 0.01) - np.log(observed[low] + 0.01)
            )
        )
    )
    high_loss = float(np.mean(np.square(simulated[high] - observed[high])))
    if not np.isfinite(low_loss) or not np.isfinite(high_loss):
        raise ValueError("v03 validation state loss is nonfinite")
    water_year = dates.year.to_numpy() + (dates.month.to_numpy() >= 10).astype(int)
    water_year_metrics: dict[str, dict[str, Any]] = {}
    for year in np.unique(water_year):
        year_mask = water_year == year
        year_low = year_mask & low
        year_high = year_mask & high
        water_year_metrics[str(int(year))] = {
            "low_flow_days": int(year_low.sum()),
            "high_flow_days": int(year_high.sum()),
            "low_flow_log_mse": (
                float(
                    np.mean(
                        np.square(
                            np.log(simulated[year_low] + 0.01)
                            - np.log(observed[year_low] + 0.01)
                        )
                    )
                )
                if int(year_low.sum()) >= 30
                else float("nan")
            ),
            "high_flow_raw_mse": (
                float(np.mean(np.square(simulated[year_high] - observed[year_high])))
                if int(year_high.sum()) >= 30
                else float("nan")
            ),
        }
    return {
        "validation_days": len(rows),
        "low_flow_days": int(low.sum()),
        "high_flow_days": int(high.sum()),
        "all_period_nse": _independent_nse(observed, simulated),
        "low_flow_log_mse": low_loss,
        "high_flow_raw_mse": high_loss,
        "water_year_metrics": water_year_metrics,
    }


def _independent_relative_improvement(reference: float, candidate: float) -> float:
    if reference == 0.0:
        return 0.0 if candidate == 0.0 else float("-inf")
    return float((reference - candidate) / abs(reference))


def _independent_relative_increase(reference: float, candidate: float) -> float:
    if reference == 0.0:
        return 0.0 if candidate == 0.0 else float("inf")
    return float((candidate - reference) / abs(reference))


def _independent_specialist_comparison(
    specialist: Mapping[str, Any],
    generalist: Mapping[str, Any],
    other_specialist: Mapping[str, Any],
    parameter_id: str,
) -> dict[str, Any]:
    target_key, opposite_key = {
        "low_flow": ("low_flow_log_mse", "high_flow_raw_mse"),
        "high_flow": ("high_flow_raw_mse", "low_flow_log_mse"),
    }[parameter_id]
    target_relative = _independent_relative_improvement(
        float(generalist[target_key]),
        float(specialist[target_key]),
    )
    opposite = _independent_relative_increase(
        float(generalist[opposite_key]),
        float(specialist[opposite_key]),
    )
    year_comparisons = []
    general_years = generalist["water_year_metrics"]
    specialist_years = specialist["water_year_metrics"]
    for year in sorted(set(general_years) & set(specialist_years), key=int):
        general_loss = float(general_years[year][target_key])
        specialist_loss = float(specialist_years[year][target_key])
        if np.isfinite(general_loss) and np.isfinite(specialist_loss):
            year_comparisons.append({
                "water_year": int(year),
                "generalist_loss": general_loss,
                "specialist_loss": specialist_loss,
                "improved": bool(specialist_loss < general_loss),
            })
    return {
        "target_metric": target_key,
        "opposite_regime_metric": opposite_key,
        "target_relative_improvement": target_relative,
        "opposite_regime_loss_increase": opposite,
        "all_period_nse_drop": float(
            generalist["all_period_nse"] - specialist["all_period_nse"]
        ),
        "opposite_regime_relative_degradation": opposite,
        "all_flow_nse_drop": float(
            generalist["all_period_nse"] - specialist["all_period_nse"]
        ),
        "target_loss_beats_other_specialist": bool(
            float(specialist[target_key]) < float(other_specialist[target_key])
        ),
        "water_year_target_comparison": year_comparisons,
        "valid_water_years": len(year_comparisons),
        "improved_water_years": sum(int(item["improved"]) for item in year_comparisons),
    }


def _artifact_float_matches(actual: Any, expected: float, *, tolerance: float = 1e-12) -> bool:
    try:
        actual_float = float(actual)
    except (TypeError, ValueError):
        return False
    if np.isnan(expected):
        return np.isnan(actual_float)
    return bool(np.isclose(actual_float, expected, rtol=0.0, atol=tolerance))


def _strict_artifact_integer(value: Any, label: str, *, minimum: int | None = None) -> int:
    """Read an integer-valued CSV scalar without truncating or parsing text."""

    if isinstance(value, (bool, np.bool_)) or not isinstance(
        value,
        (int, float, np.integer, np.floating),
    ):
        raise ValueError(f"{label} must be a finite integer")
    numeric = float(value)
    if not np.isfinite(numeric) or not numeric.is_integer():
        raise ValueError(f"{label} must be a finite integer")
    integer = int(numeric)
    if minimum is not None and integer < int(minimum):
        raise ValueError(f"{label} must be an integer of at least {minimum}")
    return integer


def _independent_validation_coverage(rows: pd.DataFrame) -> dict[str, Any]:
    """Rebuild the frozen three-water-year validation evidence from daily rows."""

    dates = pd.DatetimeIndex(pd.to_datetime(rows["date"], errors="raise"))
    low = rows["low_flow_member"].to_numpy(dtype=bool)
    high = rows["high_flow_member"].to_numpy(dtype=bool)
    water_years = dates.year.to_numpy() + (dates.month.to_numpy() >= 10).astype(int)
    unique_years = np.unique(water_years)
    if len(unique_years) != 3:
        raise ValueError("v03 validation evidence must span exactly three water years")
    records = []
    for raw_year in unique_years:
        year = int(raw_year)
        year_mask = water_years == year
        low_days = int(np.sum(year_mask & low))
        high_days = int(np.sum(year_mask & high))
        records.append({
            "water_year": year,
            "period_days": int(year_mask.sum()),
            "finite_observation_days": int(year_mask.sum()),
            "low_flow_days": low_days,
            "high_flow_days": high_days,
            "low_flow_sufficient": bool(low_days >= 30),
            "high_flow_sufficient": bool(high_days >= 30),
            "evidence_sufficient": bool(low_days >= 30 and high_days >= 30),
        })
    low_total = sum(record["low_flow_days"] for record in records)
    high_total = sum(record["high_flow_days"] for record in records)
    low_years = sum(int(record["low_flow_sufficient"]) for record in records)
    high_years = sum(int(record["high_flow_sufficient"]) for record in records)
    low_pass = bool(low_total >= 90 and low_years >= 2)
    high_pass = bool(high_total >= 90 and high_years >= 2)
    return {
        "minimum_days": 30,
        "water_years": records,
        "evidence_sufficient": bool(low_pass and high_pass),
        "coverage_policy": {
            "minimum_total_target_days": 90,
            "minimum_qualifying_water_years": 2,
            "expected_water_years": 3,
        },
        "low_flow_total_days": int(low_total),
        "high_flow_total_days": int(high_total),
        "low_flow_qualifying_water_years": int(low_years),
        "high_flow_qualifying_water_years": int(high_years),
        "low_flow_evidence_sufficient": low_pass,
        "high_flow_evidence_sufficient": high_pass,
    }


def _independent_parameter_evidence(
    coverage: Mapping[str, Any],
    parameter_id: str,
) -> bool:
    key = {
        "all_flow": "evidence_sufficient",
        "low_flow": "low_flow_evidence_sufficient",
        "high_flow": "high_flow_evidence_sufficient",
    }[parameter_id]
    return bool(coverage[key])


def _independent_boundary_diagnostics(
    parameters: Mapping[str, float],
    parameter_bounds: Mapping[str, tuple[float, float]],
) -> dict[str, Any]:
    """Rebuild boundary diagnostics without the production gate reducer."""

    near: list[str] = []
    strong: list[str] = []
    sides: dict[str, str] = {}
    diagnostics: dict[str, dict[str, Any]] = {}
    for name, raw_bounds in parameter_bounds.items():
        lower, upper = (float(value) for value in raw_bounds)
        value = float(parameters[name])
        width = upper - lower
        lower_distance = (value - lower) / width
        upper_distance = (upper - value) / width
        nearest = "lower" if lower_distance <= upper_distance else "upper"
        distance = float(min(lower_distance, upper_distance))
        is_near = bool(distance <= 0.01)
        is_strong = bool(distance <= 0.001)
        diagnostics[name] = {
            "value": value,
            "lower_bound": lower,
            "upper_bound": upper,
            "normalized_boundary_distance": distance,
            "nearest_boundary": nearest,
            "near_boundary": is_near,
            "strongly_saturated": is_strong,
        }
        if is_near:
            near.append(name)
            sides[name] = nearest
        if is_strong:
            strong.append(name)
    return {
        "near_boundary_parameters": near,
        "near_boundary_count": len(near),
        "strongly_saturated_parameters": strong,
        "strongly_saturated_count": len(strong),
        "near_boundary_sides": sides,
        "parameter_diagnostics": diagnostics,
    }


def _verify_v03_restart_evidence(
    tables: Mapping[str, pd.DataFrame],
    *,
    expected_restart_seeds: tuple[int, ...],
    fit_dates: Any,
    validation_dates: Any,
    maximum_distance: float,
    fit_loss_ratio_max: float,
    parameter_bounds: Mapping[str, tuple[float, float]],
    expected_basin_ids: tuple[str, ...] | None = None,
    validation_metrics: pd.DataFrame | None = None,
    summary: Mapping[str, Any] | None = None,
) -> None:
    """Independently recompute v03 restart identities and output distances."""

    if set(tables) != set(V03_EVIDENCE_FILENAMES):
        raise ValueError("v03 restart evidence table set is incomplete or expanded")
    copied = {name: value.copy() for name, value in tables.items() if isinstance(value, pd.DataFrame)}
    if set(copied) != set(tables) or any(table.empty for table in copied.values()):
        raise ValueError("v03 restart evidence tables must be nonempty DataFrames")
    has_basin = ["basin_id" in table.columns for table in copied.values()]
    if len(set(has_basin)) != 1:
        raise ValueError("v03 restart evidence basin identity is inconsistent across tables")
    prefix = ("basin_id",) if has_basin[0] else ()
    expected_columns = {
        "restart_parameter_vectors": prefix + V03_RESTART_PARAMETER_COLUMNS,
        "fit_restart_hydrographs": prefix + V03_FIT_HYDROGRAPH_COLUMNS,
        "validation_restart_hydrographs": prefix + V03_VALIDATION_HYDROGRAPH_COLUMNS,
        "functional_stability_metrics": prefix + V03_FUNCTIONAL_METRIC_COLUMNS,
    }
    for name, columns in expected_columns.items():
        if tuple(copied[name].columns) != columns:
            raise ValueError(f"v03 {name} has the wrong columns or column order")
    group_prefix = ["basin_id"] if prefix else []
    if prefix:
        for table in copied.values():
            table["basin_id"] = table["basin_id"].astype(str).str.zfill(8)
        basin_sets = {tuple(table["basin_id"].drop_duplicates()) for table in copied.values()}
        if len(basin_sets) != 1:
            raise ValueError("v03 restart evidence basin order differs across tables")
        actual_basin_ids = next(iter(basin_sets))
        if expected_basin_ids is not None and actual_basin_ids != tuple(expected_basin_ids):
            raise ValueError("v03 restart evidence basin identities differ from the frozen manifest")
    elif expected_basin_ids is not None:
        raise ValueError("v03 final restart evidence lacks frozen basin identities")
    for table_name, table in copied.items():
        for column in ("restart_index", "seed"):
            if column in table:
                table[column] = [
                    _strict_artifact_integer(
                        value,
                        f"v03 {table_name} {column}",
                        minimum=0 if column == "restart_index" else None,
                    )
                    for value in table[column]
                ]
    metrics_table = copied["functional_stability_metrics"]
    for column in ("selected_restart_index", "selected_seed"):
        metrics_table[column] = [
            _strict_artifact_integer(
                value,
                f"v03 functional_stability_metrics {column}",
                minimum=0 if column == "selected_restart_index" else None,
            )
            for value in metrics_table[column]
        ]
    vectors = copied["restart_parameter_vectors"]
    fit = copied["fit_restart_hydrographs"]
    validation = copied["validation_restart_hydrographs"]
    metrics = copied["functional_stability_metrics"]
    identity_columns = [*group_prefix, "parameter_id", "restart_index", "seed"]
    parameter_group_columns = [*group_prefix, "parameter_id"]
    expected_identity = set(enumerate(int(seed) for seed in expected_restart_seeds))
    if set(vectors["parameter_id"]) != set(PARAMETER_IDS):
        raise ValueError("v03 restart parameter table has the wrong parameter groups")
    if vectors.duplicated(identity_columns).any():
        raise ValueError("v03 restart parameter table contains duplicate identities")
    selected_vector_flags = _coerce_artifact_booleans(vectors["selected"], "selected flag")
    vectors["selected"] = selected_vector_flags
    vector_records: dict[tuple[Any, ...], pd.Series] = {}
    selected_records: dict[tuple[Any, ...], pd.Series] = {}
    for group_key, rows in vectors.groupby(parameter_group_columns, sort=False, dropna=False):
        group_tuple = group_key if isinstance(group_key, tuple) else (group_key,)
        identities = {
            (int(row["restart_index"]), int(row["seed"])) for _, row in rows.iterrows()
        }
        if identities != expected_identity:
            raise ValueError("v03 restart identities differ from the frozen seeds")
        if int(rows["selected"].sum()) != 1:
            raise ValueError("v03 each parameter group must contain exactly one selected restart")
        selected = rows[rows["selected"]].iloc[0]
        losses = pd.to_numeric(rows["fit_objective_loss"], errors="raise").to_numpy(float)
        if not np.all(np.isfinite(losses)):
            raise ValueError("v03 restart fit losses must be finite")
        if float(selected["fit_objective_loss"]) != float(losses.min()):
            raise ValueError("v03 selected restart is not the fit-loss minimum")
        ordered = rows.sort_values("restart_index", kind="stable")
        minimum_loss = float(losses.min())
        first_minimum = ordered[
            ordered["fit_objective_loss"].to_numpy(dtype=float) == minimum_loss
        ].iloc[0]
        if (
            int(selected["restart_index"]) != int(first_minimum["restart_index"])
            or int(selected["seed"]) != int(first_minimum["seed"])
        ):
            raise ValueError("v03 selected restart is not the first tied fit-loss minimum")
        selected_records[group_tuple] = selected
        for _, row in rows.iterrows():
            parameters = {name: float(row[name]) for name in PARAM_NAMES}
            for name, value in parameters.items():
                lower, upper = parameter_bounds[name]
                if not np.isfinite(value) or value < float(lower) or value > float(upper):
                    raise ValueError("v03 restart parameter vector is nonfinite or out of bounds")
            fingerprint = _parameter_sha256(parameters, "v03 restart parameter vector")
            if str(row["parameter_sha256"]) != fingerprint:
                raise ValueError("v03 restart parameter fingerprint is inconsistent")
            key = (*group_tuple, int(row["restart_index"]), int(row["seed"]))
            vector_records[key] = row

    expected_fit_dates = pd.DatetimeIndex(pd.to_datetime(fit_dates))
    expected_validation_dates = pd.DatetimeIndex(pd.to_datetime(validation_dates))
    hydrograph_specs = (
        (fit, expected_fit_dates, True, "fit restart hydrograph"),
        (validation, expected_validation_dates, False, "validation restart hydrograph"),
    )
    hydrograph_records: dict[str, dict[tuple[Any, ...], pd.DataFrame]] = {"fit": {}, "validation": {}}
    for table, expected_dates, has_objective, label in hydrograph_specs:
        bool_columns = ["all_flow_member", "low_flow_member", "high_flow_member", "selected"]
        if has_objective:
            bool_columns.append("objective_member")
        for column in bool_columns:
            table[column] = _coerce_artifact_booleans(table[column], f"{label} {column}")
        for flow_column in ("observed_flow_mm_day", "simulated_flow_mm_day"):
            values = pd.to_numeric(table[flow_column], errors="raise").to_numpy(float)
            if not np.all(np.isfinite(values)) or np.any(values < 0.0):
                raise ValueError(f"v03 {label} flow must be finite and nonnegative")
        if table.duplicated([*identity_columns, "date"]).any():
            raise ValueError(f"v03 {label} contains a duplicate date")
        store = hydrograph_records["fit" if has_objective else "validation"]
        for identity_key, rows in table.groupby(identity_columns, sort=False, dropna=False):
            key = identity_key if isinstance(identity_key, tuple) else (identity_key,)
            normalized = (*key[:-2], int(key[-2]), int(key[-1]))
            if normalized not in vector_records:
                raise ValueError(f"v03 {label} contains an unknown restart identity")
            parsed_dates = pd.DatetimeIndex(pd.to_datetime(rows["date"], errors="raise"))
            if not parsed_dates.equals(expected_dates):
                raise ValueError(f"v03 {label} dates differ from the frozen daily period")
            vector = vector_records[normalized]
            expected_selected = bool(vector["selected"])
            if not np.all(rows["selected"].to_numpy(dtype=bool) == expected_selected):
                raise ValueError(f"v03 {label} selected flag differs from the parameter vector")
            if set(rows["parameter_sha256"].astype(str)) != {str(vector["parameter_sha256"])}:
                raise ValueError(f"v03 {label} parameter fingerprint is inconsistent")
            if not rows["all_flow_member"].all():
                raise ValueError(f"v03 {label} all-flow membership must include every stored date")
            parameter_id = str(normalized[len(group_prefix)])
            if has_objective and not np.array_equal(
                rows["objective_member"].to_numpy(dtype=bool),
                rows[f"{parameter_id}_member"].to_numpy(dtype=bool),
            ):
                raise ValueError("v03 fit objective membership differs from the parameter group")
            store[normalized] = rows.reset_index(drop=True)
        if set(store) != set(vector_records):
            raise ValueError(f"v03 {label} lacks a complete restart identity")
        observation_key = [*group_prefix, "date"]
        for _, rows in table.groupby(observation_key, sort=False, dropna=False):
            if rows["observed_flow_mm_day"].nunique(dropna=False) != 1:
                raise ValueError(f"v03 {label} observation differs across restart evidence")
            for column in ("all_flow_member", "low_flow_member", "high_flow_member"):
                if rows[column].nunique(dropna=False) != 1:
                    raise ValueError(f"v03 {label} day-set membership is inconsistent")

    threshold_groups: dict[tuple[Any, ...], tuple[float, float]] = {}
    basin_group_columns = group_prefix
    if basin_group_columns:
        unique_groups = [(value,) for value in vectors["basin_id"].drop_duplicates()]
    else:
        unique_groups = [tuple()]
    for basin_key in unique_groups:
        selected_group = (*basin_key, "all_flow")
        selected = selected_records[selected_group]
        identity = (
            *selected_group,
            int(selected["restart_index"]),
            int(selected["seed"]),
        )
        fit_reference = hydrograph_records["fit"][identity]
        fit_observations = fit_reference["observed_flow_mm_day"].to_numpy(dtype=float)
        low_threshold = float(np.quantile(fit_observations, 0.30, method="linear"))
        high_threshold = float(np.quantile(fit_observations, 0.70, method="linear"))
        if not np.isfinite(low_threshold) or not np.isfinite(high_threshold) or low_threshold >= high_threshold:
            raise ValueError("v03 independently recomputed flow thresholds are invalid")
        threshold_groups[basin_key] = (low_threshold, high_threshold)
        if summary is not None:
            basin_id = basin_key[0] if basin_key else None
            per_basin = summary.get("per_basin") if isinstance(summary, Mapping) else None
            if basin_id is None or not isinstance(per_basin, Mapping):
                raise ValueError("v03 summary lacks per-basin fit-only flow thresholds")
            stored_thresholds = per_basin.get(str(basin_id), {}).get("flow_thresholds")
            if not isinstance(stored_thresholds, Mapping) or not (
                np.isclose(float(stored_thresholds.get("low", float("nan"))), low_threshold, rtol=0.0, atol=1e-12)
                and np.isclose(float(stored_thresholds.get("high", float("nan"))), high_threshold, rtol=0.0, atol=1e-12)
            ):
                raise ValueError("v03 summary fit-only flow thresholds differ from raw observations")
    for table, _, _, label in hydrograph_specs:
        if group_prefix:
            grouped = table.groupby("basin_id", sort=False, dropna=False)
        else:
            grouped = [(None, table)]
        for basin_id, rows in grouped:
            basin_key = (str(basin_id).zfill(8),) if group_prefix else tuple()
            low_threshold, high_threshold = threshold_groups[basin_key]
            observed_values = rows["observed_flow_mm_day"].to_numpy(dtype=float)
            expected_low = observed_values <= low_threshold
            expected_high = observed_values >= high_threshold
            if not np.array_equal(rows["low_flow_member"].to_numpy(dtype=bool), expected_low):
                raise ValueError(f"v03 {label} low-flow membership differs from fit-only observations")
            if not np.array_equal(rows["high_flow_member"].to_numpy(dtype=bool), expected_high):
                raise ValueError(f"v03 {label} high-flow membership differs from fit-only observations")

    recomputed_fit_losses: dict[tuple[Any, ...], float] = {}
    for identity, vector in vector_records.items():
        parameter_id = str(identity[len(group_prefix)])
        recomputed = _independent_fit_objective(
            hydrograph_records["fit"][identity],
            parameter_id,
        )
        stored = float(vector["fit_objective_loss"])
        if not np.isclose(recomputed, stored, rtol=0.0, atol=1e-12):
            raise ValueError("v03 fit objective loss differs from raw daily evidence")
        recomputed_fit_losses[identity] = recomputed
    for group_key, selected in selected_records.items():
        selected_identity = (
            *group_key,
            int(selected["restart_index"]),
            int(selected["seed"]),
        )
        group_losses = [
            loss
            for identity, loss in recomputed_fit_losses.items()
            if identity[:-2] == group_key
        ]
        if recomputed_fit_losses[selected_identity] != min(group_losses):
            raise ValueError("v03 selected restart is not the raw fit-loss minimum")

    if metrics.duplicated([*identity_columns, "day_set"]).any():
        raise ValueError("v03 functional distance table contains duplicate identities")
    for column in ("passes", "fit_loss_ratio_pass"):
        metrics[column] = _coerce_artifact_booleans(metrics[column], f"functional metric {column}")
    expected_metric_keys = set()
    for group_key, selected in selected_records.items():
        selected_identity = (
            *group_key,
            int(selected["restart_index"]),
            int(selected["seed"]),
        )
        selected_fit = hydrograph_records["fit"][selected_identity]
        selected_validation = hydrograph_records["validation"][selected_identity]
        observed_complete = np.concatenate([
            selected_fit["observed_flow_mm_day"].to_numpy(float),
            selected_validation["observed_flow_mm_day"].to_numpy(float),
        ])
        selected_complete = np.concatenate([
            selected_fit["simulated_flow_mm_day"].to_numpy(float),
            selected_validation["simulated_flow_mm_day"].to_numpy(float),
        ])
        for identity, vector in vector_records.items():
            if identity[:-2] != group_key or identity == selected_identity:
                continue
            restart_fit = hydrograph_records["fit"][identity]
            restart_validation = hydrograph_records["validation"][identity]
            restart_complete = np.concatenate([
                restart_fit["simulated_flow_mm_day"].to_numpy(float),
                restart_validation["simulated_flow_mm_day"].to_numpy(float),
            ])
            for day_set in PARAMETER_IDS:
                expected_metric_keys.add((*identity, day_set))
                selected_rows = metrics[
                    np.logical_and.reduce([
                        metrics[column].astype(str) == str(value)
                        for column, value in zip(identity_columns, identity, strict=True)
                    ])
                    & (metrics["day_set"] == day_set)
                ]
                if len(selected_rows) != 1:
                    raise ValueError("v03 functional distance table lacks an expected row")
                row = selected_rows.iloc[0]
                fit_membership = selected_fit[f"{day_set}_member"].to_numpy(dtype=bool)
                validation_membership = selected_validation[f"{day_set}_member"].to_numpy(dtype=bool)
                fit_scale_mask = np.concatenate([
                    fit_membership,
                    np.zeros(len(selected_validation), dtype=bool),
                ])
                validation_compare_mask = np.concatenate([
                    np.zeros(len(selected_fit), dtype=bool),
                    validation_membership,
                ])
                transform = "log_q_plus_offset" if day_set == "low_flow" else "identity"
                expected = _independent_functional_distance_from_artifacts(
                    selected_complete,
                    restart_complete,
                    observed_complete,
                    fit_scale_mask,
                    validation_compare_mask,
                    transform=transform,
                    log_offset=0.01 if day_set == "low_flow" else None,
                    maximum_distance=float(maximum_distance),
                )
                numeric_fields = (
                    "numerator",
                    "denominator",
                    "distance",
                    "maximum_distance",
                )
                for field in numeric_fields:
                    if not np.isclose(float(row[field]), float(expected[field]), rtol=0.0, atol=1e-12):
                        noun = "threshold" if field == "maximum_distance" else field
                        raise ValueError(f"v03 functional {noun} differs from raw daily evidence")
                for field in ("fit_scale_count", "validation_compare_count"):
                    if _strict_artifact_integer(
                        row[field],
                        f"v03 functional {field}",
                        minimum=1,
                    ) != int(expected[field]):
                        raise ValueError(f"v03 functional {field} differs from raw daily evidence")
                if str(row["transform"]) != expected["transform"]:
                    raise ValueError("v03 functional transform differs from the frozen rule")
                raw_offset = row["log_offset"]
                if expected["log_offset"] is None:
                    if not (pd.isna(raw_offset) or raw_offset in (None, "")):
                        raise ValueError("v03 functional log offset differs from the frozen rule")
                elif not np.isclose(float(raw_offset), float(expected["log_offset"]), rtol=0.0, atol=0.0):
                    raise ValueError("v03 functional log offset differs from the frozen rule")
                if bool(row["passes"]) != bool(expected["passes"]):
                    raise ValueError("v03 functional distance decision differs from raw evidence")
                selected_fingerprint = str(selected["parameter_sha256"])
                restart_fingerprint = str(vector["parameter_sha256"])
                if (
                    int(row["selected_restart_index"]) != int(selected["restart_index"])
                    or int(row["selected_seed"]) != int(selected["seed"])
                    or str(row["selected_parameter_sha256"]) != selected_fingerprint
                    or str(row["restart_parameter_sha256"]) != restart_fingerprint
                ):
                    raise ValueError("v03 functional metric restart fingerprint or identity is inconsistent")
                selected_loss = float(selected["fit_objective_loss"])
                restart_loss = float(vector["fit_objective_loss"])
                ratio = restart_loss / selected_loss if selected_loss != 0.0 else (
                    1.0 if restart_loss == 0.0 else float("inf")
                )
                if (
                    not np.isclose(float(row["fit_objective_loss"]), restart_loss, rtol=0.0, atol=1e-12)
                    or not np.isclose(float(row["selected_fit_objective_loss"]), selected_loss, rtol=0.0, atol=1e-12)
                    or not np.isclose(float(row["fit_loss_ratio"]), ratio, rtol=0.0, atol=1e-12)
                    or not np.isclose(float(row["fit_loss_ratio_max"]), float(fit_loss_ratio_max), rtol=0.0, atol=0.0)
                    or bool(row["fit_loss_ratio_pass"]) != bool(ratio <= float(fit_loss_ratio_max))
                ):
                    raise ValueError("v03 functional fit-loss ratio evidence is inconsistent")
                selected_parameters = {name: float(selected[name]) for name in PARAM_NAMES}
                restart_parameters = {name: float(vector[name]) for name in PARAM_NAMES}
                distance = _independent_parameter_distance_from_artifacts(
                    selected_parameters,
                    restart_parameters,
                    parameter_bounds,
                )
                if not np.isclose(
                    float(row["parameter_distance_diagnostic"]),
                    distance,
                    rtol=0.0,
                    atol=1e-12,
                ):
                    raise ValueError("v03 diagnostic parameter distance is inconsistent")
    actual_metric_keys = {
        tuple(row[column] for column in [*identity_columns, "day_set"])
        for _, row in metrics.iterrows()
    }
    normalized_actual = {
        (str(key[0]).zfill(8), str(key[1]), int(key[2]), int(key[3]), str(key[4]))
        if group_prefix
        else (
            str(key[0]), int(key[1]), int(key[2]), str(key[3])
        )
        for key in actual_metric_keys
    }
    if normalized_actual != expected_metric_keys:
        raise ValueError("v03 functional distance table has the wrong restart-day-set rows")
    if validation_metrics is not None:
        _verify_v03_validation_and_support_evidence(
            validation_metrics,
            summary,
            vectors,
            metrics,
            hydrograph_records["fit"],
            hydrograph_records["validation"],
            selected_records,
            vector_records,
            parameter_bounds,
            group_prefix,
            fit_loss_ratio_max=float(fit_loss_ratio_max),
            maximum_distance=float(maximum_distance),
        )


def _verify_v03_validation_and_support_evidence(
    validation_metrics: pd.DataFrame,
    summary: Mapping[str, Any] | None,
    vectors: pd.DataFrame,
    functional_metrics: pd.DataFrame,
    fit_hydrographs: Mapping[tuple[Any, ...], pd.DataFrame],
    validation_hydrographs: Mapping[tuple[Any, ...], pd.DataFrame],
    selected_records: Mapping[tuple[Any, ...], pd.Series],
    vector_records: Mapping[tuple[Any, ...], pd.Series],
    parameter_bounds: Mapping[str, tuple[float, float]],
    group_prefix: list[str],
    *,
    fit_loss_ratio_max: float,
    maximum_distance: float,
) -> None:
    """Recompute validation effects and every v03 support conjunction."""

    if not isinstance(validation_metrics, pd.DataFrame) or validation_metrics.empty:
        raise ValueError("v03 validation_metrics.csv must be a nonempty table")
    table = validation_metrics.copy()
    if group_prefix:
        if "basin_id" not in table:
            raise ValueError("v03 validation metrics lack basin identity")
        table["basin_id"] = table["basin_id"].astype(str).str.zfill(8)
    identity_columns = [*group_prefix, "parameter_id", "restart_index", "seed"]
    group_columns = [*group_prefix, "parameter_id"]
    selected_rows = table[table["record_type"] == "selected_fit_result"].copy()
    restart_rows = table[table["record_type"] == "restart"].copy()
    direction_rows = table[table["record_type"] == "water_year_target_direction"].copy()
    selected_by_group: dict[tuple[Any, ...], pd.Series] = {}
    for raw_key, rows in selected_rows.groupby(group_columns, sort=False, dropna=False):
        key = raw_key if isinstance(raw_key, tuple) else (raw_key,)
        if len(rows) != 1:
            raise ValueError("v03 validation metrics must contain one selected row per group")
        selected_by_group[key] = rows.iloc[0]
    restart_by_identity: dict[tuple[Any, ...], pd.Series] = {}
    for _, row in restart_rows.iterrows():
        key_values = [row[column] for column in identity_columns]
        key = tuple(key_values[:-2]) + (
            _strict_artifact_integer(
                key_values[-2],
                "v03 validation_metrics restart_index",
                minimum=0,
            ),
            _strict_artifact_integer(
                key_values[-1],
                "v03 validation_metrics seed",
            ),
        )
        if key in restart_by_identity:
            raise ValueError("v03 validation metrics contain duplicate restart identity")
        restart_by_identity[key] = row
    if set(restart_by_identity) != set(vector_records):
        raise ValueError("v03 validation metrics restart identities differ from raw hydrographs")
    if set(selected_by_group) != set(selected_records):
        raise ValueError("v03 validation metrics selected groups differ from raw hydrographs")

    absolute: dict[tuple[Any, ...], dict[str, Any]] = {
        identity: _independent_validation_record(rows)
        for identity, rows in validation_hydrographs.items()
    }
    coverage: dict[tuple[Any, ...], dict[str, Any]] = {
        identity: _independent_validation_coverage(rows)
        for identity, rows in validation_hydrographs.items()
    }
    selected_absolute: dict[tuple[Any, ...], dict[str, Any]] = {}
    for group_key, vector in selected_records.items():
        identity = (
            *group_key,
            int(vector["restart_index"]),
            int(vector["seed"]),
        )
        selected_absolute[group_key] = absolute[identity]

    comparisons: dict[tuple[Any, ...], dict[str, Any]] = {}
    for identity, metrics in absolute.items():
        group_key = identity[:-2]
        parameter_id = str(group_key[-1])
        if parameter_id == "all_flow":
            continue
        basin_prefix = group_key[:-1]
        general = selected_absolute[(*basin_prefix, "all_flow")]
        other_name = "high_flow" if parameter_id == "low_flow" else "low_flow"
        other = selected_absolute[(*basin_prefix, other_name)]
        comparisons[identity] = _independent_specialist_comparison(
            metrics,
            general,
            other,
            parameter_id,
        )

    absolute_fields = (
        "validation_days",
        "low_flow_days",
        "high_flow_days",
        "all_period_nse",
        "low_flow_log_mse",
        "high_flow_raw_mse",
    )

    def verify_metric_row(row: pd.Series, identity: tuple[Any, ...]) -> None:
        expected = absolute[identity]
        for field in absolute_fields:
            if field not in row or not _artifact_float_matches(row[field], float(expected[field])):
                raise ValueError(f"v03 validation {field} differs from raw daily evidence")
        parameter_id = str(identity[-3])
        expected_evidence = _independent_parameter_evidence(coverage[identity], parameter_id)
        if _table_boolean(
            row.get("evidence_sufficient"),
            "v03 validation evidence_sufficient",
        ) != expected_evidence:
            raise ValueError("v03 validation evidence eligibility differs from raw daily evidence")
        vector = vector_records[identity]
        fingerprint_column = (
            FIT_SELECTED_FINGERPRINT
            if str(row.get("record_type")) == "selected_fit_result"
            else RESTART_FINGERPRINT
        )
        if str(row.get(fingerprint_column, "")) != str(vector["parameter_sha256"]):
            raise ValueError("v03 validation parameter fingerprint differs from raw restart evidence")
        if not _artifact_float_matches(
            row.get("fit_objective_loss"),
            float(vector["fit_objective_loss"]),
        ):
            raise ValueError("v03 validation fit loss differs from raw fit hydrograph evidence")
        if parameter_id != "all_flow":
            comparison = comparisons[identity]
            for field in (
                "target_relative_improvement",
                "opposite_regime_loss_increase",
                "all_period_nse_drop",
                "opposite_regime_relative_degradation",
                "all_flow_nse_drop",
            ):
                if field not in row or not _artifact_float_matches(row[field], float(comparison[field])):
                    raise ValueError(f"v03 validation {field} differs from raw daily evidence")
            for field in ("valid_water_years", "improved_water_years"):
                if _strict_artifact_integer(
                    row.get(field),
                    f"v03 validation {field}",
                    minimum=0,
                ) != int(comparison[field]):
                    raise ValueError(f"v03 validation {field} differs from raw water-year evidence")
            if str(row.get("target_metric", "")) != comparison["target_metric"]:
                raise ValueError("v03 validation target metric differs from the frozen specialist")
            if str(row.get("opposite_regime_metric", "")) != comparison["opposite_regime_metric"]:
                raise ValueError("v03 validation opposite metric differs from the frozen specialist")
            if _table_boolean(
                row.get("target_loss_beats_other_specialist"),
                "v03 validation specialist comparison",
            ) != bool(comparison["target_loss_beats_other_specialist"]):
                raise ValueError("v03 validation specialist ranking differs from raw daily evidence")

    for identity, row in restart_by_identity.items():
        verify_metric_row(row, identity)
    for group_key, row in selected_by_group.items():
        selected = selected_records[group_key]
        identity = (
            *group_key,
            int(selected["restart_index"]),
            int(selected["seed"]),
        )
        verify_metric_row(row, identity)

    expected_direction_keys = set()
    if not direction_rows.empty:
        direction_rows["water_year"] = [
            _strict_artifact_integer(
                value,
                "v03 validation_metrics water_year",
                minimum=1,
            )
            for value in direction_rows["water_year"]
        ]
    for group_key, selected in selected_records.items():
        parameter_id = str(group_key[-1])
        if parameter_id == "all_flow":
            continue
        identity = (
            *group_key,
            int(selected["restart_index"]),
            int(selected["seed"]),
        )
        expected_rows = comparisons[identity]["water_year_target_comparison"]
        for expected in expected_rows:
            expected_direction_keys.add((*group_key, int(expected["water_year"])))
            filters = [
                direction_rows[column].astype(str) == str(value)
                for column, value in zip(group_columns, group_key, strict=True)
            ]
            rows = direction_rows[np.logical_and.reduce(filters)]
            rows = rows[rows["water_year"] == expected["water_year"]]
            if len(rows) != 1:
                raise ValueError("v03 validation water-year direction row is missing or duplicated")
            row = rows.iloc[0]
            if not (
                _artifact_float_matches(row.get("generalist_loss"), expected["generalist_loss"])
                and _artifact_float_matches(row.get("specialist_loss"), expected["specialist_loss"])
                and _table_boolean(row.get("improved"), "v03 water-year direction")
                == bool(expected["improved"])
            ):
                raise ValueError("v03 validation water-year direction differs from raw daily evidence")
    actual_direction_keys = {
        tuple(
            [
                *(
                    str(row[column]).zfill(8) if column == "basin_id" else str(row[column])
                    for column in group_columns
                ),
                _strict_artifact_integer(
                    row["water_year"],
                    "v03 validation_metrics water_year",
                    minimum=1,
                ),
            ]
        )
        for _, row in direction_rows.iterrows()
    }
    normalized_expected_direction_keys = {
        tuple(
            str(value).zfill(8) if index == 0 and group_prefix else str(value)
            for index, value in enumerate(key[:-1])
        )
        + (int(key[-1]),)
        for key in expected_direction_keys
    }
    if actual_direction_keys != normalized_expected_direction_keys:
        raise ValueError("v03 validation water-year direction table has unexpected rows")

    if summary is None or not group_prefix:
        return
    per_basin = summary.get("per_basin")
    if not isinstance(per_basin, Mapping):
        raise ValueError("v03 summary lacks per-basin quality evidence")
    maximum_near = 2
    maximum_strong = 1
    minimum_support = 1
    generalist_nse_min = 0.30
    validation_gate_by_group: dict[tuple[Any, ...], bool] = {}
    raw_group_qualifies: dict[tuple[Any, ...], bool] = {}

    def selected_identity_for(group_key: tuple[Any, ...]) -> tuple[Any, ...]:
        selected = selected_records[group_key]
        return (
            *group_key,
            int(selected["restart_index"]),
            int(selected["seed"]),
        )

    def verify_functional_gate(
        stored: Mapping[str, Any],
        expected: Mapping[str, Any],
        label: str,
    ) -> None:
        if set(stored) != {
            "maximum_distance",
            "all_three_day_sets_required",
            "day_sets",
            "passes",
        }:
            raise ValueError(f"{label} has the wrong functional-gate fields")
        if not _artifact_float_matches(stored["maximum_distance"], maximum_distance):
            raise ValueError(f"{label} maximum distance differs from raw evidence")
        if not _strict_boolean(
            stored,
            "all_three_day_sets_required",
            label,
        ):
            raise ValueError(f"{label} must require all three day sets")
        stored_day_sets = stored.get("day_sets")
        expected_day_sets = expected["day_sets"]
        if not isinstance(stored_day_sets, Mapping) or set(stored_day_sets) != set(PARAMETER_IDS):
            raise ValueError(f"{label} lacks exactly three functional day sets")
        for day_set in PARAMETER_IDS:
            stored_record = stored_day_sets[day_set]
            expected_record = expected_day_sets[day_set]
            if not isinstance(stored_record, Mapping) or set(stored_record) != set(expected_record):
                raise ValueError(f"{label} {day_set} fields differ from raw evidence")
            for field in ("numerator", "denominator", "distance", "maximum_distance"):
                if not _artifact_float_matches(stored_record[field], float(expected_record[field])):
                    raise ValueError(f"{label} {day_set} {field} differs from raw evidence")
            for field in ("fit_scale_count", "validation_compare_count"):
                if _strict_integer(stored_record, field, label, minimum=1) != int(
                    expected_record[field]
                ):
                    raise ValueError(f"{label} {day_set} {field} differs from raw evidence")
            if str(stored_record["transform"]) != str(expected_record["transform"]):
                raise ValueError(f"{label} {day_set} transform differs from raw evidence")
            stored_offset = stored_record["log_offset"]
            expected_offset = expected_record["log_offset"]
            if expected_offset is None:
                if stored_offset is not None:
                    raise ValueError(f"{label} {day_set} log offset differs from raw evidence")
            elif not _artifact_float_matches(stored_offset, float(expected_offset), tolerance=0.0):
                raise ValueError(f"{label} {day_set} log offset differs from raw evidence")
            if _strict_boolean(stored_record, "passes", label) != bool(expected_record["passes"]):
                raise ValueError(f"{label} {day_set} decision differs from raw evidence")
        expected_pass = bool(all(record["passes"] for record in expected_day_sets.values()))
        if (
            _strict_boolean(stored, "passes", label) != expected_pass
            or expected_pass != bool(expected["passes"])
        ):
            raise ValueError(f"{label} conjunction differs from raw evidence")

    def raw_functional_gate(
        identity: tuple[Any, ...],
        selected_identity: tuple[Any, ...],
    ) -> dict[str, Any]:
        selected_fit = fit_hydrographs[selected_identity]
        selected_validation = validation_hydrographs[selected_identity]
        restart_fit = fit_hydrographs[identity]
        restart_validation = validation_hydrographs[identity]
        observed = np.concatenate([
            selected_fit["observed_flow_mm_day"].to_numpy(dtype=float),
            selected_validation["observed_flow_mm_day"].to_numpy(dtype=float),
        ])
        selected_simulated = np.concatenate([
            selected_fit["simulated_flow_mm_day"].to_numpy(dtype=float),
            selected_validation["simulated_flow_mm_day"].to_numpy(dtype=float),
        ])
        restart_simulated = np.concatenate([
            restart_fit["simulated_flow_mm_day"].to_numpy(dtype=float),
            restart_validation["simulated_flow_mm_day"].to_numpy(dtype=float),
        ])
        day_sets = {}
        for day_set in PARAMETER_IDS:
            fit_membership = selected_fit[f"{day_set}_member"].to_numpy(dtype=bool)
            validation_membership = selected_validation[f"{day_set}_member"].to_numpy(dtype=bool)
            day_sets[day_set] = _independent_functional_distance_from_artifacts(
                selected_simulated,
                restart_simulated,
                observed,
                np.concatenate([
                    fit_membership,
                    np.zeros(len(selected_validation), dtype=bool),
                ]),
                np.concatenate([
                    np.zeros(len(selected_fit), dtype=bool),
                    validation_membership,
                ]),
                transform="log_q_plus_offset" if day_set == "low_flow" else "identity",
                log_offset=0.01 if day_set == "low_flow" else None,
                maximum_distance=maximum_distance,
            )
        return {
            "maximum_distance": float(maximum_distance),
            "all_three_day_sets_required": True,
            "day_sets": day_sets,
            "passes": bool(all(record["passes"] for record in day_sets.values())),
        }

    # The eligibility attached to every validation row and to the summary is
    # derived from the same daily membership, never from a stored Boolean.
    for basin_id in per_basin:
        basin_id = str(basin_id).zfill(8)
        basin_summary = per_basin.get(basin_id)
        if not isinstance(basin_summary, Mapping):
            raise ValueError(f"v03 summary basin {basin_id} must be a mapping")
        general_group = (basin_id, "all_flow")
        raw_coverage = coverage[selected_identity_for(general_group)]
        stored_coverage = basin_summary.get("regime_water_year_coverage")
        if (
            not isinstance(stored_coverage, Mapping)
            or _json_ready(stored_coverage.get("validation")) != _json_ready(raw_coverage)
        ):
            raise ValueError("v03 summary validation evidence differs from raw daily membership")

        stored_validation = basin_summary.get("development_validation_gates")
        if not isinstance(stored_validation, Mapping):
            raise ValueError("v03 summary lacks validation gates")
        specialist_passes = []
        for parameter_id in ("low_flow", "high_flow"):
            group_key = (basin_id, parameter_id)
            comparison = comparisons[selected_identity_for(group_key)]
            checks = {
                "target_improvement_pass": bool(
                    np.isfinite(comparison["target_relative_improvement"])
                    and comparison["target_relative_improvement"] >= 0.05
                ),
                "water_year_direction_pass": bool(comparison["improved_water_years"] >= 2),
                "all_period_nse_guardrail_pass": bool(
                    np.isfinite(comparison["all_flow_nse_drop"])
                    and comparison["all_flow_nse_drop"] <= 0.03
                ),
                "opposite_regime_guardrail_pass": bool(
                    np.isfinite(comparison["opposite_regime_relative_degradation"])
                    and comparison["opposite_regime_relative_degradation"] <= 0.20
                ),
                "target_beats_other_specialist_pass": bool(
                    comparison["target_loss_beats_other_specialist"]
                ),
            }
            qualifies = bool(all(checks.values()))
            validation_gate_by_group[group_key] = qualifies
            stored_gate = stored_validation.get(parameter_id)
            if not isinstance(stored_gate, Mapping):
                raise ValueError(f"v03 summary lacks {parameter_id} validation gate")
            expected_numbers = {
                "target_relative_improvement": comparison["target_relative_improvement"],
                "target_relative_improvement_min": 0.05,
                "improved_water_years": comparison["improved_water_years"],
                "minimum_improved_water_years": 2,
                "all_flow_nse_drop": comparison["all_flow_nse_drop"],
                "all_flow_nse_drop_max": 0.03,
                "opposite_regime_relative_degradation": comparison[
                    "opposite_regime_relative_degradation"
                ],
                "opposite_regime_relative_degradation_max": 0.20,
            }
            for field, expected in expected_numbers.items():
                if not _artifact_float_matches(stored_gate.get(field), float(expected)):
                    raise ValueError(
                        f"v03 {parameter_id} validation gate differs from raw daily evidence"
                    )
            if (
                not _strict_boolean(
                    stored_gate,
                    "must_beat_other_specialist",
                    "v03 validation gate",
                )
                or _strict_boolean(
                    stored_gate,
                    "target_loss_beats_other_specialist",
                    "v03 validation gate",
                )
                != bool(comparison["target_loss_beats_other_specialist"])
            ):
                raise ValueError("v03 specialist ranking rule differs from raw daily evidence")
            for field, expected in checks.items():
                if _strict_boolean(stored_gate, field, "v03 validation gate") != expected:
                    raise ValueError("v03 validation-gate decision differs from raw daily evidence")
            if _strict_boolean(stored_gate, "qualifies", "v03 validation gate") != qualifies:
                raise ValueError("v03 validation-gate conjunction differs from raw daily evidence")
            specialist_passes.append(qualifies)
        if _strict_boolean(
            stored_validation,
            "all_specialists_qualify",
            "v03 validation gates",
        ) != bool(all(specialist_passes)):
            raise ValueError("v03 validation specialist conjunction differs from raw daily evidence")

    for group_key, selected in selected_records.items():
        basin_id, parameter_id = str(group_key[0]), str(group_key[1])
        basin_summary = per_basin[basin_id]
        quality = basin_summary["parameter_quality_gates"]
        if quality.get("quality_gate_version") != "v03_output_functional_stability":
            raise ValueError("v03 summary has the wrong quality-gate version")
        if _strict_boolean(
            quality,
            "parameter_distance_is_qualification_gate",
            "v03 quality summary",
        ):
            raise ValueError("v03 summary must not use parameter distance as a qualification gate")
        group = quality[parameter_id]
        selected_identity = selected_identity_for(group_key)
        selected_parameters = {name: float(selected[name]) for name in PARAM_NAMES}
        selected_boundary = _independent_boundary_diagnostics(
            selected_parameters,
            parameter_bounds,
        )
        selected_boundary_pass = bool(
            selected_boundary["near_boundary_count"] <= maximum_near
            and selected_boundary["strongly_saturated_count"] <= maximum_strong
        )
        selected_nse = float(absolute[selected_identity]["all_period_nse"])
        selected_nse_pass = bool(selected_nse >= generalist_nse_min)
        selected_evidence_pass = _independent_parameter_evidence(
            coverage[selected_identity],
            parameter_id,
        )
        expected_support: list[tuple[Any, ...]] = []
        functionally_stable_count = 0
        range_valid_count = 0
        expected_by_identity: dict[tuple[Any, ...], dict[str, Any]] = {}
        group_identities = [identity for identity in vector_records if identity[:-2] == group_key]
        identity_indices = [identity[-2] for identity in group_identities]
        identity_seeds = [identity[-1] for identity in group_identities]
        for identity, vector in vector_records.items():
            if identity[:-2] != group_key:
                continue
            is_additional = identity != selected_identity
            functional_gate_expected = raw_functional_gate(identity, selected_identity)
            distance_bundle_pass = bool(functional_gate_expected["passes"])
            independent_identity = bool(
                is_additional
                and identity[-2] != selected_identity[-2]
                and identity[-1] != selected_identity[-1]
                and identity_indices.count(identity[-2]) == 1
                and identity_seeds.count(identity[-1]) == 1
                and identity_indices.count(selected_identity[-2]) == 1
                and identity_seeds.count(selected_identity[-1]) == 1
            )
            fit_pass = bool(
                float(vector["fit_objective_loss"])
                <= fit_loss_ratio_max * float(selected["fit_objective_loss"])
            )
            parameters = {name: float(vector[name]) for name in PARAM_NAMES}
            boundary = _independent_boundary_diagnostics(parameters, parameter_bounds)
            boundary_pass = bool(
                boundary["near_boundary_count"] <= maximum_near
                and boundary["strongly_saturated_count"] <= maximum_strong
            )
            validation_nse_pass = bool(absolute[identity]["all_period_nse"] >= 0.30)
            evidence_pass = _independent_parameter_evidence(
                coverage[identity],
                parameter_id,
            )
            checks = {
                "additional_restart_pass": is_additional,
                "independent_restart_identity_pass": independent_identity,
                "fit_loss_pass": fit_pass,
                "validation_nse_pass": validation_nse_pass,
                "boundary_pass": boundary_pass,
                "evidence_sufficient_pass": evidence_pass,
            }
            if parameter_id != "all_flow":
                comparison = comparisons[identity]
                checks.update({
                    "target_improvement_pass": bool(
                        np.isfinite(comparison["target_relative_improvement"])
                        and comparison["target_relative_improvement"] >= 0.05
                    ),
                    "water_year_direction_pass": bool(comparison["improved_water_years"] >= 2),
                    "all_period_nse_guardrail_pass": bool(
                        np.isfinite(comparison["all_period_nse_drop"])
                        and comparison["all_period_nse_drop"] <= 0.03
                    ),
                    "opposite_regime_guardrail_pass": bool(
                        np.isfinite(comparison["opposite_regime_relative_degradation"])
                        and comparison["opposite_regime_relative_degradation"] <= 0.20
                    ),
                    "target_beats_other_specialist_pass": bool(
                        comparison["target_loss_beats_other_specialist"]
                    ),
                })
            functional_support = bool(
                is_additional and independent_identity and fit_pass and distance_bundle_pass
            )
            range_support = bool(functional_support and boundary_pass)
            qualifies = bool(all(checks.values()) and distance_bundle_pass)
            if functional_support:
                functionally_stable_count += 1
            if range_support:
                range_valid_count += 1
            if qualifies:
                expected_support.append(identity)
            expected_by_identity[identity] = {
                "functional_pass": distance_bundle_pass,
                "boundary_pass": boundary_pass,
                "qualifies": qualifies,
                "checks": checks,
                "boundary": boundary,
                "functional_gate": functional_gate_expected,
            }
        diagnostics = group.get("restart_diagnostics")
        if not isinstance(diagnostics, list) or len(diagnostics) != 3:
            raise ValueError("v03 summary restart diagnostics are incomplete")
        diagnostic_by_identity: dict[tuple[Any, ...], Mapping[str, Any]] = {}
        for item in diagnostics:
            if not isinstance(item, Mapping):
                raise ValueError("v03 summary restart diagnostic must be a mapping")
            identity = (
                *group_key,
                _strict_integer(item, "restart_index", "v03 restart diagnostic"),
                _strict_integer(item, "seed", "v03 restart diagnostic", minimum=0),
            )
            if identity in diagnostic_by_identity:
                raise ValueError("v03 summary restart diagnostics contain duplicate identities")
            diagnostic_by_identity[identity] = item
        if set(diagnostic_by_identity) != {
            identity for identity in vector_records if identity[:-2] == group_key
        }:
            raise ValueError("v03 summary restart diagnostic identities are inconsistent")
        for identity, expected in expected_by_identity.items():
            diagnostic = diagnostic_by_identity[identity]
            if "parameter_distance_pass" in diagnostic:
                raise ValueError("v03 summary reintroduced the old parameter-distance gate")
            functional_gate = diagnostic.get("functional_stability_gate")
            range_gate = diagnostic.get("parameter_range_gate")
            if not isinstance(functional_gate, Mapping) or not isinstance(range_gate, Mapping):
                raise ValueError("v03 summary lacks separate functional and range gates")
            verify_functional_gate(
                functional_gate,
                expected["functional_gate"],
                "v03 restart functional gate",
            )
            for field, field_expected in expected["checks"].items():
                if _strict_boolean(diagnostic, field, "v03 restart diagnostic") != field_expected:
                    raise ValueError("v03 summary restart check differs from raw daily evidence")
            vector = vector_records[identity]
            selected_loss = float(selected["fit_objective_loss"])
            restart_loss = float(vector["fit_objective_loss"])
            ratio = restart_loss / selected_loss if selected_loss != 0.0 else (
                1.0 if restart_loss == 0.0 else float("inf")
            )
            parameter_distance = _independent_parameter_distance_from_artifacts(
                selected_parameters,
                {name: float(vector[name]) for name in PARAM_NAMES},
                parameter_bounds,
            )
            if not (
                _artifact_float_matches(diagnostic.get("fit_objective_loss"), restart_loss)
                and _artifact_float_matches(diagnostic.get("fit_loss_ratio_to_selected"), ratio)
                and _artifact_float_matches(
                    diagnostic.get("normalized_parameter_distance"),
                    parameter_distance,
                )
                and _json_ready(diagnostic.get("boundary_diagnostics"))
                == _json_ready(expected["boundary"])
            ):
                raise ValueError("v03 summary restart diagnostics differ from raw parameter evidence")
            distance_diagnostic = diagnostic.get("parameter_distance_diagnostic")
            if not isinstance(distance_diagnostic, Mapping) or not (
                _artifact_float_matches(
                    distance_diagnostic.get("normalized_parameter_distance"),
                    parameter_distance,
                )
                and _artifact_float_matches(
                    distance_diagnostic.get("second_version_reference"),
                    0.20,
                    tolerance=0.0,
                )
                and _strict_boolean(
                    distance_diagnostic,
                    "exceeds_second_version_reference",
                    "v03 parameter-distance diagnostic",
                )
                == bool(parameter_distance > 0.20)
                and not _strict_boolean(
                    distance_diagnostic,
                    "qualification_gate",
                    "v03 parameter-distance diagnostic",
                )
            ):
                raise ValueError("v03 parameter-distance diagnostic differs from raw vectors")
            if _json_ready(range_gate.get("boundary_diagnostics")) != _json_ready(
                expected["boundary"]
            ):
                raise ValueError("v03 restart parameter-range evidence differs from raw vector")
            if (
                _strict_boolean(range_gate, "passes", "v03 restart range gate")
                != expected["boundary_pass"]
                or _strict_boolean(diagnostic, "qualifies_as_support", "v03 restart diagnostic")
                != expected["qualifies"]
            ):
                raise ValueError("v03 summary support decision differs from raw daily evidence")
        support_restarts = group.get("support_restarts")
        if not isinstance(support_restarts, list):
            raise ValueError("v03 summary support restart list is missing")
        stored_support = set()
        for item in support_restarts:
            if not isinstance(item, Mapping):
                raise ValueError("v03 support restart must be a mapping")
            stored_support.add((
                *group_key,
                _strict_integer(item, "restart_index", "v03 support restart"),
                _strict_integer(item, "seed", "v03 support restart", minimum=0),
            ))
        if stored_support != set(expected_support):
            raise ValueError("v03 summary support restart set differs from raw daily evidence")
        if (
            _strict_integer(group, "support_restart_count", "v03 quality group")
            != len(expected_support)
            or _strict_integer(
                group["functional_stability_gate"],
                "support_restart_count",
                "v03 functional group gate",
            )
            != functionally_stable_count
            or _strict_integer(
                group["parameter_range_gate"],
                "range_valid_stable_support_count",
                "v03 parameter-range group gate",
            )
            != range_valid_count
        ):
            raise ValueError("v03 summary support counts differ from raw daily evidence")

        support_pass = len(expected_support) >= minimum_support
        functional_group_gate = group.get("functional_stability_gate")
        range_group_gate = group.get("parameter_range_gate")
        if not isinstance(functional_group_gate, Mapping) or not isinstance(
            range_group_gate,
            Mapping,
        ):
            raise ValueError("v03 summary lacks group functional and parameter-range gates")
        if not (
            _artifact_float_matches(
                group.get("selected_fit_objective_loss"),
                float(selected["fit_objective_loss"]),
            )
            and _json_ready(group.get("selected_boundary_diagnostics"))
            == _json_ready(selected_boundary)
            and _artifact_float_matches(group.get("selected_validation_nse"), selected_nse)
            and _strict_integer(
                group,
                "minimum_support_restarts",
                "v03 quality group",
                minimum=1,
            )
            == minimum_support
        ):
            raise ValueError("v03 selected quality evidence differs from raw artifacts")
        selected_checks = {
            "selected_boundary_pass": selected_boundary_pass,
            "selected_validation_nse_pass": selected_nse_pass,
            "selected_evidence_sufficient_pass": selected_evidence_pass,
            "selected_restart_record_found_pass": True,
            "support_restart_pass": support_pass,
        }
        for field, expected in selected_checks.items():
            if _strict_boolean(group, field, "v03 selected quality group") != expected:
                raise ValueError("v03 selected quality decision differs from raw artifacts")
        if (
            _strict_integer(
                functional_group_gate,
                "minimum_support_restarts",
                "v03 group functional gate",
                minimum=1,
            )
            != minimum_support
            or not _artifact_float_matches(
                functional_group_gate.get("maximum_distance"),
                maximum_distance,
                tolerance=0.0,
            )
            or not _strict_boolean(
                functional_group_gate,
                "all_three_day_sets_required",
                "v03 group functional gate",
            )
            or _strict_boolean(
                functional_group_gate,
                "passes",
                "v03 group functional gate",
            )
            != bool(functionally_stable_count >= minimum_support)
        ):
            raise ValueError("v03 group functional gate differs from raw restart evidence")
        if not (
            _json_ready(range_group_gate.get("selected_boundary_diagnostics"))
            == _json_ready(selected_boundary)
            and _strict_boolean(
                range_group_gate,
                "selected_boundary_pass",
                "v03 group range gate",
            )
            == selected_boundary_pass
            and _strict_boolean(
                range_group_gate,
                "support_boundary_is_required",
                "v03 group range gate",
            )
            and _strict_boolean(range_group_gate, "passes", "v03 group range gate")
            == bool(selected_boundary_pass and range_valid_count >= minimum_support)
        ):
            raise ValueError("v03 group parameter-range gate differs from raw parameter evidence")
        if parameter_id == "all_flow":
            expected_group_qualifies = bool(
                selected_nse_pass
                and selected_boundary_pass
                and selected_evidence_pass
                and support_pass
            )
        else:
            validation_pass = validation_gate_by_group[group_key]
            if _strict_boolean(
                group,
                "validation_gate_pass",
                "v03 specialist quality group",
            ) != validation_pass:
                raise ValueError("v03 specialist effect gate differs from raw validation evidence")
            general_identity = selected_identity_for((basin_id, "all_flow"))
            generalist_pass = bool(
                absolute[general_identity]["all_period_nse"] >= generalist_nse_min
            )
            expected_group_qualifies = bool(
                generalist_pass
                and validation_pass
                and selected_boundary_pass
                and selected_evidence_pass
                and selected_nse_pass
                and support_pass
            )
        if _strict_boolean(group, "qualifies", "v03 quality group") != expected_group_qualifies:
            raise ValueError("v03 parameter-group qualification differs from raw evidence")
        selected_table_row = selected_by_group[group_key]
        if _table_boolean(
            selected_table_row.get("gate_qualifies"),
            "v03 validation selected gate_qualifies",
        ) != expected_group_qualifies:
            raise ValueError("v03 validation table qualification differs from raw evidence")
        raw_group_qualifies[group_key] = expected_group_qualifies

    basin_ids = tuple(str(value).zfill(8) for value in per_basin)
    qualification_counts = {
        "qualified_low_flow_basin_count": sum(
            int(raw_group_qualifies[(basin_id, "low_flow")]) for basin_id in basin_ids
        ),
        "qualified_high_flow_basin_count": sum(
            int(raw_group_qualifies[(basin_id, "high_flow")]) for basin_id in basin_ids
        ),
        "qualified_generalist_basin_count": sum(
            int(raw_group_qualifies[(basin_id, "all_flow")]) for basin_id in basin_ids
        ),
    }
    complete_by_basin: dict[str, bool] = {}
    for basin_id in basin_ids:
        quality = per_basin[basin_id]["parameter_quality_gates"]
        specialists = bool(
            raw_group_qualifies[(basin_id, "low_flow")]
            and raw_group_qualifies[(basin_id, "high_flow")]
        )
        complete = bool(raw_group_qualifies[(basin_id, "all_flow")] and specialists)
        if (
            _strict_boolean(quality, "all_specialists_qualify", "v03 basin quality")
            != specialists
            or _strict_boolean(quality, "all_parameter_sets_qualify", "v03 basin quality")
            != complete
        ):
            raise ValueError("v03 basin qualification conjunction differs from raw evidence")
        complete_by_basin[basin_id] = complete
    complete_count = sum(int(value) for value in complete_by_basin.values())
    qualification_counts["complete_candidate_group_count"] = complete_count
    for field, expected in qualification_counts.items():
        if _strict_integer(summary, field, "v03 development summary") != expected:
            raise ValueError(f"v03 summary {field} differs from raw evidence")
    all_generalists = qualification_counts["qualified_generalist_basin_count"] == len(basin_ids)
    if _strict_boolean(summary, "all_generalists_pass", "v03 development summary") != all_generalists:
        raise ValueError("v03 all-generalists decision differs from raw evidence")

    offenders: list[dict[str, str]] = []
    for specialist in ("low_flow", "high_flow"):
        for name, (lower, upper) in parameter_bounds.items():
            width = float(upper) - float(lower)
            values = [
                float(selected_records[(basin_id, specialist)][name])
                for basin_id in basin_ids
            ]
            if all((value - float(lower)) / width <= 0.01 for value in values):
                offenders.append({"specialist": specialist, "parameter": name, "side": "lower"})
            elif all((float(upper) - value) / width <= 0.01 for value in values):
                offenders.append({"specialist": specialist, "parameter": name, "side": "upper"})
    expected_boundary = {
        "boundary_fraction": 0.01,
        "qualifies": not offenders,
        "offending_parameters": offenders,
    }
    if _json_ready(summary.get("cross_basin_boundary_consistency")) != _json_ready(
        expected_boundary
    ):
        raise ValueError("v03 cross-basin boundary decision differs from raw selected vectors")
    minimum_complete = 2
    if _strict_integer(
        summary,
        "cross_basin_complete_group_threshold",
        "v03 development summary",
    ) != minimum_complete:
        raise ValueError("v03 complete-group threshold differs from the frozen rule")
    expected_axis = {
        "minimum_complete_candidate_groups": minimum_complete,
        "complete_candidate_group_count": complete_count,
        "complete_group_count_pass": complete_count >= minimum_complete,
        "all_generalists_pass": all_generalists,
        "boundary_consistency_pass": bool(expected_boundary["qualifies"]),
        "qualifies": bool(
            complete_count >= minimum_complete
            and all_generalists
            and expected_boundary["qualifies"]
        ),
    }
    if _json_ready(summary.get("parameter_axis_development_gate")) != expected_axis:
        raise ValueError("v03 final parameter-axis gate differs from raw evidence")


def _cross_basin_boundary_consistency(
    parameter_vectors: pd.DataFrame,
    parameter_bounds: Mapping[str, tuple[float, float]],
    basin_ids: Sequence[str],
    *,
    boundary_fraction: float,
) -> dict[str, Any]:
    """Find specialist parameters saturated on one boundary in every basin."""

    if not 0.0 <= float(boundary_fraction) < 0.5:
        raise ValueError("boundary_fraction must be in [0, 0.5)")
    required = {"basin_id", "parameter_id", *parameter_bounds}
    missing = sorted(required - set(parameter_vectors.columns))
    if missing:
        raise ValueError(f"parameter vectors lack boundary-check columns: {missing}")
    expected_basins = tuple(str(value).zfill(8) for value in basin_ids)
    vectors = parameter_vectors.copy()
    vectors["basin_id"] = vectors["basin_id"].astype(str).str.zfill(8)
    offenders: list[dict[str, str]] = []
    for specialist in ("low_flow", "high_flow"):
        selected = vectors[vectors["parameter_id"] == specialist]
        if len(selected) != len(expected_basins) or tuple(selected["basin_id"]) != expected_basins:
            raise ValueError(f"{specialist} boundary check does not cover the ordered basin manifest")
        for parameter, raw_bounds in parameter_bounds.items():
            lower, upper = (float(value) for value in raw_bounds)
            width = upper - lower
            if not np.isfinite(width) or width <= 0.0:
                raise ValueError(f"invalid parameter bounds for {parameter}")
            values = selected[parameter].to_numpy(dtype=float)
            if not np.all(np.isfinite(values)):
                raise ValueError(f"non-finite selected parameter values for {specialist} {parameter}")
            normalized_lower = (values - lower) / width
            normalized_upper = (upper - values) / width
            if np.all(normalized_lower <= float(boundary_fraction)):
                offenders.append(
                    {"specialist": specialist, "parameter": parameter, "side": "lower"}
                )
            elif np.all(normalized_upper <= float(boundary_fraction)):
                offenders.append(
                    {"specialist": specialist, "parameter": parameter, "side": "upper"}
                )
    return {
        "boundary_fraction": float(boundary_fraction),
        "qualifies": not offenders,
        "offending_parameters": offenders,
    }


def _combine_development_screen_results(
    contract: AccessContract,
    basin_results: Sequence[tuple[str, Mapping[str, Any], float]],
) -> dict[str, Any]:
    """Combine three isolated basin executions without allowing row overwrite."""

    if tuple(item[0] for item in basin_results) != contract.basin_ids:
        raise ValueError("basin execution order differs from the frozen manifest")
    combined_tables: dict[str, list[pd.DataFrame]] = {
        "parameter_vectors": [],
        "fit_metrics": [],
        "validation_metrics": [],
    }
    if contract.config.get("target_state_coverage_policy") is not None:
        combined_tables["validation_hydrographs"] = []
    if _uses_restart_evidence(contract.config):
        for key in V03_EVIDENCE_FILENAMES:
            combined_tables[key] = []
        combined_tables["restart_execution"] = []
    if _uses_initialization_response_diagnostics(contract.config):
        for key in V04_DIAGNOSTIC_FILENAMES:
            combined_tables[key] = []
    per_basin: dict[str, Any] = {}
    basin_areas: dict[str, float] = {}
    low_count = 0
    high_count = 0
    generalist_count = 0
    complete_count = 0
    for basin_id, execution, area_km2 in basin_results:
        for key in combined_tables:
            table = execution.get(key)
            if not isinstance(table, pd.DataFrame) or table.empty:
                raise ValueError(f"basin {basin_id} execution result {key} must be nonempty")
            if "basin_id" in table.columns:
                raise ValueError(f"basin {basin_id} execution result {key} already contains basin_id")
            with_basin = table.copy()
            with_basin.insert(0, "basin_id", basin_id)
            combined_tables[key].append(with_basin)
        run_summary = execution.get("run_summary")
        if not isinstance(run_summary, Mapping):
            raise ValueError(f"basin {basin_id} execution lacks run_summary")
        quality = run_summary.get("parameter_quality_gates")
        if not isinstance(quality, Mapping):
            raise ValueError(f"basin {basin_id} execution lacks parameter-quality gates")
        all_flow = quality.get("all_flow")
        low = quality.get("low_flow")
        high = quality.get("high_flow")
        if not all(isinstance(item, Mapping) for item in (all_flow, low, high)):
            raise ValueError(f"basin {basin_id} parameter-quality gates lack all three parameter sets")
        low_qualifies = bool(low.get("qualifies", False))
        high_qualifies = bool(high.get("qualifies", False))
        generalist_qualifies = bool(all_flow.get("qualifies", False))
        all_parameter_sets_qualify = bool(quality.get("all_parameter_sets_qualify", False))
        expected_complete = generalist_qualifies and low_qualifies and high_qualifies
        if all_parameter_sets_qualify != expected_complete:
            raise ValueError(
                f"basin {basin_id} all_parameter_sets_qualify is inconsistent with its component gates"
            )
        low_count += int(low_qualifies)
        high_count += int(high_qualifies)
        generalist_count += int(generalist_qualifies)
        complete_count += int(all_parameter_sets_qualify)
        basin_areas[basin_id] = float(area_km2)
        per_basin[basin_id] = {
            "basin_area_km2": float(area_km2),
            **_json_ready(dict(run_summary)),
        }

    combined = {key: pd.concat(tables, ignore_index=True) for key, tables in combined_tables.items()}
    vectors = combined["parameter_vectors"]
    duplicates = vectors.duplicated(["basin_id", "parameter_id"])
    if len(vectors) != 9 or duplicates.any():
        raise ValueError("development-screen parameter table must contain nine unique basin-parameter rows")
    cross_config = contract.config["cross_basin_gates"]
    boundary = _cross_basin_boundary_consistency(
        vectors,
        resolve_hbv_bounds(str(contract.config["parameter_bounds_preset"])),
        contract.basin_ids,
        boundary_fraction=float(cross_config["boundary_fraction"]),
    )
    minimum_complete = int(cross_config["minimum_complete_candidate_groups"])
    all_generalists_pass = generalist_count == len(contract.basin_ids)
    screen_gate = {
        "minimum_complete_candidate_groups": minimum_complete,
        "complete_candidate_group_count": complete_count,
        "complete_group_count_pass": complete_count >= minimum_complete,
        "all_generalists_pass": all_generalists_pass,
        "boundary_consistency_pass": bool(boundary["qualifies"]),
        "qualifies": (
            complete_count >= minimum_complete
            and all_generalists_pass
            and bool(boundary["qualifies"])
        ),
    }
    return {
        **combined,
        "run_summary": {
            "basin_areas_km2": basin_areas,
            "per_basin": per_basin,
            "qualified_low_flow_basin_count": low_count,
            "qualified_high_flow_basin_count": high_count,
            "qualified_generalist_basin_count": generalist_count,
            "all_generalists_pass": all_generalists_pass,
            "complete_candidate_group_count": complete_count,
            "cross_basin_complete_group_threshold": minimum_complete,
            "cross_basin_boundary_consistency": boundary,
            "parameter_axis_development_gate": screen_gate,
            "authorizes_noise_axis": False,
            "authorizes_joint_axis": False,
            "authorizes_scientific_claim": False,
        },
    }


def _flow_regime_preflight(
    forcing: pd.DataFrame,
    observations: pd.Series,
    config: Mapping[str, Any],
) -> dict[str, Any]:
    """Compute fit-only thresholds and both water-year coverage records."""

    from camels_switch_confirmation.real_regime_parameter_calibration import (
        apply_regime_coverage_policy,
        fit_flow_thresholds,
        regime_water_year_coverage,
    )

    dates = pd.DatetimeIndex(forcing.index)
    periods = _active_periods(config)
    fit_mask = _date_mask(dates, periods["fit"])
    validation_mask = _date_mask(dates, periods["validation"])
    values = observations.to_numpy(dtype=float)
    quantiles = config["regime_quantiles"]
    thresholds = fit_flow_thresholds(
        values[fit_mask],
        float(quantiles["low"]),
        float(quantiles["high"]),
    )
    minimum_target_days = int(config.get("minimum_target_days_per_water_year", 10))
    coverage = {}
    policy = config.get("target_state_coverage_policy")
    for period_name, period_mask in (("fit", fit_mask), ("validation", validation_mask)):
        period_coverage = regime_water_year_coverage(
            dates,
            values,
            period_mask,
            thresholds,
            minimum_target_days,
        )
        if policy is not None:
            period_coverage = apply_regime_coverage_policy(
                period_coverage,
                **dict(policy[period_name]),
            )
        coverage[period_name] = period_coverage
    return {
        "dates": dates,
        "values": values,
        "fit_mask": fit_mask,
        "validation_mask": validation_mask,
        "thresholds": thresholds,
        "minimum_target_days": minimum_target_days,
        "coverage": coverage,
    }


def _compact_coverage_counts(coverage: Mapping[str, Any]) -> dict[str, Any]:
    compact: dict[str, Any] = {}
    for period_name in ("fit", "validation"):
        period = coverage[period_name]
        water_years = [
            [
                int(row["water_year"]),
                int(row["low_flow_days"]),
                int(row["high_flow_days"]),
                bool(row["evidence_sufficient"]),
            ]
            for row in period["water_years"]
        ]
        if "coverage_policy" not in period:
            compact[period_name] = water_years
            continue
        compact[period_name] = {
            "water_years": water_years,
            "minimum_days_per_qualifying_water_year": int(period["minimum_days"]),
            "coverage_policy": _json_ready(period["coverage_policy"]),
            "low_flow_total_days": int(period["low_flow_total_days"]),
            "high_flow_total_days": int(period["high_flow_total_days"]),
            "low_flow_qualifying_water_years": int(period["low_flow_qualifying_water_years"]),
            "high_flow_qualifying_water_years": int(period["high_flow_qualifying_water_years"]),
            "low_flow_evidence_sufficient": bool(period["low_flow_evidence_sufficient"]),
            "high_flow_evidence_sufficient": bool(period["high_flow_evidence_sufficient"]),
            "evidence_sufficient": bool(period["evidence_sufficient"]),
        }
    return compact


def _write_preflight_failure_audit(
    contract: AccessContract,
    coverage_payload: Mapping[str, Any],
    error_message: str,
) -> None:
    """Preserve evidence-insufficient counts without creating result tables."""

    incomplete = contract.incomplete_directory
    incomplete.mkdir(parents=True)
    _write_json(incomplete / "config_snapshot.json", contract.config)
    shutil.copy2(contract.manifest_path, incomplete / "basin_manifest_snapshot.csv")
    _write_json(incomplete / "preflight_coverage.json", coverage_payload)
    _write_json(
        incomplete / "error.json",
        {
            "classification": contract.profile_name,
            "status": "evidence_insufficient_before_optimization",
            "optimizer_calls": 0,
            "error": error_message,
        },
    )
    _write_json(incomplete / "environment.json", _environment_record())
    (incomplete / "git_status.txt").write_text(
        _git_status(contract.repo_root),
        encoding="utf-8",
    )
    _copy_source_snapshot(contract, incomplete / "source_snapshot")
    _write_json(incomplete / "checksums.json", _artifact_checksums(incomplete))


def _execute_calibration(
    forcing: pd.DataFrame,
    observations: pd.Series,
    config: Mapping[str, Any],
    regime_preflight: Mapping[str, Any] | None = None,
    telemetry_collectors: Mapping[str, list[dict[str, Any]]] | None = None,
) -> dict[str, Any]:
    """Execute the core calibration contract and normalize artifact tables."""

    from camels_switch_confirmation.real_regime_parameter_calibration import (
        apply_parameter_quality_gates,
        apply_parameter_quality_gates_v03,
        apply_parameter_quality_gates_v04,
        apply_validation_gates,
        calibrate_parameter_sets,
        evaluate_parameter_sets,
    )

    prepared = dict(regime_preflight or _flow_regime_preflight(forcing, observations, config))
    dates = pd.DatetimeIndex(prepared["dates"])
    values = np.asarray(prepared["values"], dtype=float)
    fit_mask = np.asarray(prepared["fit_mask"], dtype=bool)
    validation_mask = np.asarray(prepared["validation_mask"], dtype=bool)
    thresholds = prepared["thresholds"]
    minimum_target_days = int(prepared["minimum_target_days"])
    coverage = prepared["coverage"]
    if config.get("classification") == "development_screen" and not all(
        bool(record.get("evidence_sufficient")) for record in coverage.values()
    ):
        raise ValueError(
            "regime water-year evidence is insufficient before optimization: "
            + json.dumps(
                {
                    "columns": [
                        "water_year",
                        "low_flow_days",
                        "high_flow_days",
                        "evidence_sufficient",
                    ],
                    "coverage": _compact_coverage_counts(coverage),
                },
                sort_keys=True,
                separators=(",", ":"),
            )
        )
    optimizer = config["optimizer"]
    restart_seeds = tuple(int(seed) for seed in optimizer["restart_seeds"])
    uses_restart_evidence = _uses_restart_evidence(config)
    active_telemetry = telemetry_collectors
    if uses_restart_evidence and active_telemetry is None:
        active_telemetry = {parameter_id: [] for parameter_id in PARAMETER_IDS}
    calibrations = calibrate_parameter_sets(
        forcing["prcp"].to_numpy(dtype=float),
        forcing["ep"].to_numpy(dtype=float),
        forcing["tmean"].to_numpy(dtype=float),
        values,
        fit_mask,
        thresholds,
        n_trials=int(optimizer["function_evaluations_per_restart"]),
        n_restarts=len(restart_seeds),
        restart_seeds=restart_seeds,
        param_bounds=resolve_hbv_bounds(str(config["parameter_bounds_preset"])),
        lag_kernel=str(config["routing_kernel"]),
        flow_log_offset_mm_day=float(config["flow_log_offset_mm_day"]),
        telemetry_collectors=active_telemetry if uses_restart_evidence else None,
    )
    quality_gate_config = (
        dict(config["parameter_quality_gates"])
        if config.get("classification") == "development_screen"
        else {}
    )
    evaluations = evaluate_parameter_sets(
        forcing,
        values,
        validation_mask,
        thresholds,
        calibrations,
        dates=dates,
        lag_kernel=str(config["routing_kernel"]),
        flow_log_offset_mm_day=float(config["flow_log_offset_mm_day"]),
        minimum_target_days_per_water_year=minimum_target_days,
        target_state_coverage_policy=(
            dict(config["target_state_coverage_policy"]["validation"])
            if config.get("target_state_coverage_policy") is not None
            else None
        ),
        fit_mask=fit_mask if uses_restart_evidence else None,
        output_functional_distance_max=(
            float(quality_gate_config["support_output_functional_distance_max"])
            if uses_restart_evidence
            else None
        ),
        include_restart_simulations=uses_restart_evidence,
    )
    validation_gate_config = dict(config["validation_gates"])
    validation_gates = apply_validation_gates(evaluations, **validation_gate_config)
    v04_diagnostic_tables: dict[str, pd.DataFrame] = {}
    if _uses_initialization_response_diagnostics(config):
        # The builder attaches independently recomputable diagnostics to the
        # fixed restart records before the core wrapper evaluates them.
        v04_diagnostic_tables = _build_v04_diagnostic_evidence(
            forcing,
            observations,
            config,
            prepared,
            calibrations,
            evaluations,
        )
    if config.get("classification") == "development_screen":
        quality_gate_config.update({
            "support_target_relative_improvement_min": validation_gate_config[
                "target_relative_improvement_min"
            ],
            "support_minimum_improved_water_years": validation_gate_config[
                "minimum_improved_water_years"
            ],
            "support_all_period_nse_drop_max": validation_gate_config["all_flow_nse_drop_max"],
            "support_opposite_regime_relative_degradation_max": validation_gate_config[
                "opposite_regime_relative_degradation_max"
            ],
            "support_must_beat_other_specialist": validation_gate_config["must_beat_other_specialist"],
        })
        gate_function = (
            apply_parameter_quality_gates_v04
            if _uses_initialization_response_diagnostics(config)
            else apply_parameter_quality_gates_v03
            if uses_restart_evidence
            else apply_parameter_quality_gates
        )
        if uses_restart_evidence:
            quality_gate_config["flow_log_offset_mm_day"] = float(
                config["flow_log_offset_mm_day"]
            )
        quality_gates = gate_function(
            calibrations,
            evaluations,
            validation_gates,
            resolve_hbv_bounds(str(config["parameter_bounds_preset"])),
            **quality_gate_config,
        )
        artifact_gates = quality_gates
    else:
        quality_gates = None
        artifact_gates = validation_gates
    threshold_mapping = asdict(thresholds) if is_dataclass(thresholds) else dict(thresholds)
    result = {
        "parameter_vectors": _parameter_vectors(calibrations),
        "fit_metrics": _fit_metric_table(calibrations),
        "validation_metrics": _validation_metric_table(evaluations, artifact_gates),
        "run_summary": {
            "trajectory_length_days": int(len(dates)),
            "flow_thresholds": threshold_mapping,
            "regime_water_year_coverage": _json_ready(coverage),
            "development_validation_gates": _json_ready(validation_gates),
            "parameter_quality_gates": _json_ready(quality_gates),
        },
    }
    if config.get("target_state_coverage_policy") is not None:
        result["validation_hydrographs"] = _validation_hydrograph_table(
            dates,
            values,
            validation_mask,
            evaluations,
        )
    if uses_restart_evidence:
        result["restart_execution"] = _restart_execution_table(calibrations, config)
        result.update(
            _build_v03_restart_evidence(
                dates,
                values,
                fit_mask,
                validation_mask,
                thresholds,
                calibrations,
                evaluations,
                flow_log_offset_mm_day=float(config["flow_log_offset_mm_day"]),
                maximum_distance=float(
                    config["parameter_quality_gates"][
                        "support_output_functional_distance_max"
                    ]
                ),
                fit_loss_ratio_max=float(
                    config["parameter_quality_gates"]["support_fit_loss_ratio_max"]
                ),
                parameter_bounds=resolve_hbv_bounds(
                    str(config["parameter_bounds_preset"])
                ),
            )
        )
    result.update(v04_diagnostic_tables)
    return result


def _environment_record() -> dict[str, Any]:
    versions = {}
    for distribution in ("numpy", "pandas", "cma", "numba"):
        try:
            versions[distribution] = importlib.metadata.version(distribution)
        except importlib.metadata.PackageNotFoundError:
            versions[distribution] = None
    return {
        "python": sys.version,
        "python_executable": sys.executable,
        "platform": platform.platform(),
        "package_versions": versions,
    }


def _cached_v04_environment(
    lifecycle: Mapping[str, Any],
) -> tuple[dict[str, str], dict[str, Any], dict[str, Any]]:
    cached = lifecycle.get("environment_inventory")
    if not isinstance(cached, Mapping) or set(cached) != {"outputs", "capture_record"}:
        raise ValueError("fourth-version cached environment inventory is missing")
    outputs = cached["outputs"]
    capture_record = cached["capture_record"]
    environment = lifecycle.get("environment_record")
    if not isinstance(outputs, Mapping) or set(outputs) != {
        "python_packages.txt",
        "conda_explicit.txt",
    }:
        raise ValueError("fourth-version cached environment outputs are incomplete")
    if not isinstance(capture_record, Mapping):
        raise ValueError("fourth-version cached environment command record is missing")
    if not isinstance(environment, Mapping):
        raise ValueError("fourth-version cached runtime environment is missing")
    checked_outputs: dict[str, str] = {}
    for filename, value in outputs.items():
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"fourth-version cached environment output is empty: {filename}")
        checked_outputs[str(filename)] = value
    return checked_outputs, dict(capture_record), dict(environment)


def _write_cached_environment_with_evidence(
    directory: Path,
    lifecycle: Mapping[str, Any],
    execution_evidence: Any,
    *,
    allow_incomplete_python_inventory: bool,
) -> None:
    outputs, capture_record, environment = _cached_v04_environment(lifecycle)
    _write_json(directory / "environment_capture.json", capture_record)
    _write_json(directory / "environment.json", environment)
    for filename, value in outputs.items():
        (directory / filename).write_text(value, encoding="utf-8")
    execution_evidence.validate_environment_capture(
        directory,
        capture_record,
        environment,
        allow_incomplete_python_inventory=allow_incomplete_python_inventory,
    )


def _write_v04_cached_environment(
    directory: Path,
    lifecycle: Mapping[str, Any],
    *,
    allow_incomplete_python_inventory: bool,
) -> None:
    """Backward-compatible v04-only wrapper used by existing tests."""

    _write_cached_environment_with_evidence(
        directory,
        lifecycle,
        v04_execution_evidence,
        allow_incomplete_python_inventory=allow_incomplete_python_inventory,
    )


def _write_initialization_response_cached_environment(
    contract: AccessContract,
    directory: Path,
    lifecycle: Mapping[str, Any],
    *,
    allow_incomplete_python_inventory: bool,
) -> None:
    execution_evidence = _execution_evidence_for(contract.config)
    if execution_evidence is None:
        raise ValueError("initialization-response environment evidence requires v04 or v05")
    _write_cached_environment_with_evidence(
        directory,
        lifecycle,
        execution_evidence,
        allow_incomplete_python_inventory=allow_incomplete_python_inventory,
    )


def _write_initialization_response_parameter_domain_evidence(
    contract: AccessContract,
    directory: Path,
) -> None:
    execution_evidence = _execution_evidence_for(contract.config)
    if execution_evidence is None:
        raise ValueError("initialization-response parameter evidence requires v04 or v05")
    _write_json(
        directory / "parameter_domain_warmup_memory.json",
        execution_evidence.parameter_domain_warmup_memory_record(contract.config),
    )


def _write_v04_parameter_domain_evidence(
    contract: AccessContract,
    directory: Path,
) -> None:
    """Backward-compatible v04-only wrapper used by existing tests."""

    if not _is_v04_config(contract.config):
        raise ValueError("fourth-version parameter evidence requires a v04 configuration")
    _write_initialization_response_parameter_domain_evidence(contract, directory)


def _git_status(repo_root: Path) -> str:
    completed = subprocess.run(
        ["git", "status", "--short"],
        cwd=repo_root,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    return (
        f"exit_code={completed.returncode}\n"
        f"stdout:\n{completed.stdout}"
        f"stderr:\n{completed.stderr}"
    )


def _zoned_now() -> str:
    return datetime.now().astimezone().isoformat()


def _new_run_instance_id(started_at: str) -> str:
    parsed = datetime.fromisoformat(started_at)
    timestamp = parsed.strftime("%Y%m%dT%H%M%S%z")
    return f"run-{timestamp}-{uuid.uuid4().hex[:16]}"


def _git_source_identity(repo_root: Path) -> tuple[str, bool]:
    commit = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=repo_root,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    digest = commit.stdout.strip().lower()
    if commit.returncode != 0 or re.fullmatch(r"[0-9a-f]{40}|[0-9a-f]{64}", digest) is None:
        raise ValueError("v03 run manifest cannot identify the Git commit")
    status = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=repo_root,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if status.returncode != 0:
        raise ValueError("v03 run manifest cannot determine the worktree state")
    return digest, bool(status.stdout)


def _numpy_configuration_text() -> str:
    output = io.StringIO()
    with redirect_stdout(output):
        np.show_config()
    text = output.getvalue().strip()
    return text or "NumPy reported no build configuration."


def _v03_input_hashes(contract: AccessContract, credential: Mapping[str, Any]) -> dict[str, str]:
    fixed = credential.get("fixed_factors")
    if not isinstance(fixed, Mapping):
        raise ValueError("v03 protocol credential lacks fixed input identities")
    result: dict[str, str] = {}
    for path_key, digest_key in (
        ("basin_manifest_path", "basin_manifest_sha256"),
        ("development_universe_path", "development_universe_sha256"),
        ("input_manifest_path", "input_manifest_sha256"),
        ("topography_path", "topography_sha256"),
    ):
        relative = str(fixed.get(path_key, "")).replace("\\", "/")
        expected = str(fixed.get(digest_key, "")).lower()
        lexical = Path(relative)
        if lexical.is_absolute() or ".." in lexical.parts:
            raise ValueError(f"v03 frozen input path is unsafe: {relative}")
        path = (contract.repo_root / relative).resolve()
        if not path.is_file() or re.fullmatch(r"[0-9a-f]{64}", expected) is None:
            raise ValueError(f"v03 frozen input identity is incomplete: {relative}")
        actual = _sha256(path)
        if actual != expected:
            raise ValueError(f"v03 frozen input checksum differs: {relative}")
        result[relative] = actual
    return result


def _verify_versioned_execution_evidence(
    contract: AccessContract,
    output: Path,
    *,
    expected_run_instance_id: str,
    expected_selected_parameter_fingerprints: Mapping[str, str] | None = None,
    allow_failed: bool = False,
) -> dict[str, Any]:
    credential_path = (
        contract.repo_root / str(contract.config["protocol_credential"])
    ).resolve()
    common = {
        "expected_experiment_id": str(contract.config["experiment_id"]),
        "expected_run_instance_id": expected_run_instance_id,
        "expected_config_sha256": _sha256(output / "config_snapshot.json"),
        "expected_selected_parameter_fingerprints": (
            expected_selected_parameter_fingerprints
        ),
        "allow_failed": allow_failed,
    }
    execution_evidence = _execution_evidence_for(contract.config)
    if execution_evidence is not None:
        return execution_evidence.verify_execution_evidence(
            output,
            credential_path,
            repo_root=contract.repo_root,
            **common,
        )
    return v03_execution_evidence.verify_execution_evidence(
        output,
        credential_path,
        **common,
    )


def _v03_source_snapshot_hashes(output: Path) -> dict[str, str]:
    snapshot = output / "source_snapshot"
    if not snapshot.is_dir():
        raise ValueError("v03 source snapshot is missing")
    return {
        f"source_snapshot/{path.relative_to(snapshot).as_posix()}": _sha256(path)
        for path in sorted(snapshot.rglob("*"))
        if path.is_file()
    }


def _v03_selected_fingerprints(
    restart_execution: pd.DataFrame,
    *,
    require_complete: bool = True,
) -> dict[str, str]:
    selected = restart_execution[restart_execution["selected"].astype(bool)]
    result = {
        f"{str(row['basin_id']).zfill(8)}/{row['parameter_id']}": str(
            row["best_parameter_fingerprint"]
        )
        for _, row in selected.iterrows()
    }
    if require_complete and len(result) != len(SCREEN_BASIN_IDS) * len(PARAMETER_IDS):
        raise ValueError("v03 restart execution lacks one selected fingerprint per group")
    return result


def _v03_event(
    event: str,
    timestamp: str,
    experiment_id: str,
    run_instance_id: str,
    *,
    severity: str = "INFO",
    context: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "timestamp": timestamp,
        "severity": severity,
        "event": event,
        "experiment_id": experiment_id,
        "run_instance_id": run_instance_id,
        "context": {} if context is None else dict(context),
    }


def _v03_success_events(
    contract: AccessContract,
    restart_execution: pd.DataFrame,
    lifecycle: Mapping[str, Any],
    *,
    artifacts_written_at: str | None = None,
    artifact_verification_completed_at: str | None = None,
    run_completed_at: str | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    events = [
        _v03_event(name, str(lifecycle[name]), contract.config["experiment_id"], lifecycle["run_instance_id"])
        for name in (
            "run_started",
            "config_verified",
            "inputs_verified",
            "preflight_completed",
        )
    ]
    latest = datetime.fromisoformat(str(lifecycle["preflight_completed"]))
    for _, row in restart_execution.iterrows():
        context = {
            "basin_id": str(row["basin_id"]).zfill(8),
            "parameter_id": str(row["parameter_id"]),
            "restart_index": int(row["restart_index"]),
            "seed": int(row["seed"]),
        }
        started_at = str(row["started_at"])
        ended_at = str(row["ended_at"])
        started = datetime.fromisoformat(started_at)
        ended = datetime.fromisoformat(ended_at)
        if started < latest or ended < started:
            raise ValueError("v03 restart telemetry timestamps are not in execution order")
        events.append(
            _v03_event(
                "restart_started",
                started_at,
                contract.config["experiment_id"],
                lifecycle["run_instance_id"],
                context=context,
            )
        )
        events.append(
            _v03_event(
                "restart_completed",
                ended_at,
                contract.config["experiment_id"],
                lifecycle["run_instance_id"],
                context=context,
            )
        )
        latest = ended
    terminal: dict[str, Any] = {}
    supplied = {
        "artifacts_written": artifacts_written_at,
        "artifact_verification_completed": artifact_verification_completed_at,
        "run_completed": run_completed_at,
    }
    for name in ("artifacts_written", "artifact_verification_completed", "run_completed"):
        timestamp = (
            str(supplied[name])
            if supplied[name] is not None
            else _zoned_now()
        )
        parsed = datetime.fromisoformat(timestamp)
        if parsed < latest:
            timestamp = latest.isoformat()
            parsed = latest
        terminal[name] = timestamp
        events.append(
            _v03_event(
                name,
                timestamp,
                contract.config["experiment_id"],
                lifecycle["run_instance_id"],
            )
        )
        latest = parsed
    terminal["monotonic_elapsed_seconds"] = float(
        time.perf_counter() - float(lifecycle["monotonic_started"])
    )
    return events, terminal


def _v03_failure_events(
    contract: AccessContract,
    restart_execution: pd.DataFrame,
    lifecycle: Mapping[str, Any],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    lifecycle_names = tuple(
        name
        for name in (
            "run_started",
            "config_verified",
            "inputs_verified",
            "preflight_completed",
        )
        if name in lifecycle
    )
    events = [
        _v03_event(
            name,
            str(lifecycle[name]),
            contract.config["experiment_id"],
            lifecycle["run_instance_id"],
        )
        for name in lifecycle_names
    ]
    latest = datetime.fromisoformat(str(lifecycle[lifecycle_names[-1]]))
    for _, row in restart_execution.iterrows():
        context = {
            "basin_id": str(row["basin_id"]).zfill(8),
            "parameter_id": str(row["parameter_id"]),
            "restart_index": int(row["restart_index"]),
            "seed": int(row["seed"]),
        }
        started_at = str(row["started_at"])
        ended_at = str(row["ended_at"])
        started = datetime.fromisoformat(started_at)
        ended = datetime.fromisoformat(ended_at)
        if started < latest or ended < started:
            raise ValueError("v03 failed restart telemetry timestamps are not in execution order")
        events.append(
            _v03_event(
                "restart_started",
                started_at,
                contract.config["experiment_id"],
                lifecycle["run_instance_id"],
                context=context,
            )
        )
        status = str(row["status"])
        terminal_name = "restart_completed" if status == "completed" else "restart_failed"
        events.append(
            _v03_event(
                terminal_name,
                ended_at,
                contract.config["experiment_id"],
                lifecycle["run_instance_id"],
                severity="INFO" if status == "completed" else "ERROR",
                context=context,
            )
        )
        latest = ended
    failed_at = str(lifecycle["failure_detected_at"])
    failed_time = datetime.fromisoformat(failed_at)
    if failed_time < latest:
        raise ValueError("v03 run failure timestamp precedes completed lifecycle evidence")
    events.append(
        _v03_event(
            "run_failed",
            failed_at,
            contract.config["experiment_id"],
            lifecycle["run_instance_id"],
            severity="ERROR",
        )
    )
    return events, {
        "run_failed": failed_at,
        "monotonic_elapsed_seconds": float(
            lifecycle["failure_monotonic_elapsed_seconds"]
        ),
    }


def _write_json_lines(path: Path, records: Sequence[Mapping[str, Any]]) -> None:
    text = "".join(
        json.dumps(
            _json_ready(dict(record)),
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        )
        + "\n"
        for record in records
    )
    path.write_text(text, encoding="utf-8", newline="\n")


def _v03_run_manifest(
    contract: AccessContract,
    output: Path,
    restart_execution: pd.DataFrame,
    lifecycle: Mapping[str, Any],
    terminal: Mapping[str, Any],
    artifact_hashes: Mapping[str, str],
    *,
    terminal_status: str = "completed",
    exit_code: int = 0,
) -> dict[str, Any]:
    credential_path = (contract.repo_root / str(contract.config["protocol_credential"])).resolve()
    credential = json.loads(credential_path.read_text(encoding="utf-8"))
    execution_evidence = _execution_evidence_for(contract.config)
    restart_credential = (
        execution_evidence.build_restart_evidence_credential(
            contract.repo_root,
            credential,
        )
        if execution_evidence is not None
        else credential
    )
    human_relative = str(credential["human_protocol_path"]).replace("\\", "/")
    try:
        config_relative = contract.config_path.resolve().relative_to(contract.repo_root).as_posix()
    except ValueError:
        config_relative = f"external_test_config/{contract.config_path.name}"
    commit, dirty = _git_source_identity(contract.repo_root)
    source_hashes = _v03_source_snapshot_hashes(output)
    started_at = str(lifecycle["run_started"])
    terminal_event = "run_completed" if terminal_status == "completed" else "run_failed"
    ended_at = str(terminal[terminal_event])
    started = datetime.fromisoformat(started_at)
    ended = datetime.fromisoformat(ended_at)
    optimizer_evaluations = pd.to_numeric(
        restart_execution["optimizer_evaluation_count"], errors="coerce"
    )
    optimizer_iterations = pd.to_numeric(
        restart_execution["optimizer_iteration_count"], errors="coerce"
    )
    objective_calls = pd.to_numeric(
        restart_execution["objective_call_count"], errors="raise"
    ).astype(int)
    return {
        "schema_version": 1,
        "run": {
            "experiment_id": str(contract.config["experiment_id"]),
            "run_instance_id": str(lifecycle["run_instance_id"]),
        },
        "protocol": {
            "protocol_id": str(contract.config["protocol_id"]),
            "credential_path": str(contract.config["protocol_credential"]).replace("\\", "/"),
            "credential_sha256": _sha256(credential_path),
            "human_protocol_path": human_relative,
            "human_protocol_sha256": str(credential["human_protocol_sha256"]),
        },
        "configuration": {
            "path": config_relative,
            "sha256": _sha256(output / "config_snapshot.json"),
        },
        "inputs_sha256": _v03_input_hashes(contract, restart_credential),
        "source_snapshot": {
            "dirty_worktree": dirty,
            "git_commit": commit,
            "path": "source_snapshot",
            "files_sha256": source_hashes,
        },
        "command": [
            str(Path(sys.executable).resolve()),
            "-m",
            "camels_switch_confirmation.run_real_regime_parameter_calibration",
            "--config",
            str(contract.config_path.resolve()),
        ],
        "working_directory": str(contract.repo_root.resolve()),
        "python_executable": str(Path(sys.executable).resolve()),
        "timing": {
            "started_at": started_at,
            "ended_at": ended_at,
            "utc_offset": started.strftime("%z")[:3] + ":" + started.strftime("%z")[3:],
            "monotonic_elapsed_seconds": float(
                terminal["monotonic_elapsed_seconds"]
            ),
        },
        "environment": {
            "python_version": sys.version,
            "operating_system": platform.platform(),
            "architecture": platform.machine(),
            "processor": platform.processor(),
            "numpy_version": np.__version__,
            "numpy_configuration": _numpy_configuration_text(),
        },
        "work": {
            "declared_maxfevals_stop_threshold": int(
                contract.config["optimizer"]["function_evaluations_per_restart"]
            ),
            "expected_restart_count": 27,
            "observed_restart_count": len(restart_execution),
            "completed_restart_count": int((restart_execution["status"] == "completed").sum()),
            "failed_restart_count": int((restart_execution["status"] == "failed").sum()),
            "total_objective_calls": int(objective_calls.sum()),
            "total_optimizer_evaluations": (
                None
                if optimizer_evaluations.isna().any()
                else int(optimizer_evaluations.astype(int).sum())
            ),
            "total_optimizer_iterations": (
                None
                if optimizer_iterations.isna().any()
                else int(optimizer_iterations.astype(int).sum())
            ),
        },
        "exit": {"exit_code": int(exit_code), "terminal_status": terminal_status},
        "artifacts_sha256": dict(artifact_hashes),
        "manifest_self_hash_policy": v03_execution_evidence.MANIFEST_SELF_HASH_POLICY,
        "verifier": {
            "identity": v03_execution_evidence.VERIFIER_IDENTITY,
            "verified_at": str(
                terminal.get("artifact_verification_completed", terminal[terminal_event])
            ),
            "result": "passed",
        },
        "selected_parameter_fingerprints": _v03_selected_fingerprints(
            restart_execution,
            require_complete=terminal_status == "completed",
        ),
        "interpretation_permissions": {
            name: False
            for name in v03_execution_evidence.PROHIBITED_INTERPRETATION_PERMISSIONS
        },
    }


def _write_v03_restart_execution_csv(path: Path, table: pd.DataFrame) -> None:
    if tuple(table.columns) != V03_RESTART_EXECUTION_COLUMNS:
        raise ValueError("v03 restart execution columns or order differ from the contract")
    encoded = table.copy()
    for column in ("evaluation_counts_agree", "selected"):
        encoded[column] = [
            ""
            if value is None or (isinstance(value, float) and np.isnan(value))
            else "true"
            if bool(value)
            else "false"
            for value in encoded[column]
        ]
    encoded.to_csv(path, index=False, lineterminator="\n")


def _v03_captured_stream_text(lifecycle: Mapping[str, Any], name: str) -> str:
    stream = lifecycle.get(f"{name}_capture")
    if not isinstance(stream, io.StringIO):
        raise ValueError(f"v03 {name} capture is unavailable")
    return stream.getvalue()


def _write_v03_failure_package(
    contract: AccessContract,
    restart_execution: pd.DataFrame,
    telemetry_by_basin: Mapping[str, Mapping[str, list[dict[str, Any]]]],
    lifecycle: Mapping[str, Any],
    error: Exception,
    *,
    failure_phase: str,
    coverage_payload: Mapping[str, Any] | None = None,
    reuse_existing: bool = False,
) -> None:
    """Write auditable failure evidence without inventing unavailable simulations."""

    incomplete = contract.incomplete_directory
    if incomplete.exists() and not reuse_existing:
        raise FileExistsError("v03 failure evidence directory already exists")
    if not incomplete.exists():
        incomplete.mkdir(parents=True)
    if not incomplete.is_dir() or incomplete.is_symlink():
        raise ValueError("v03 failure evidence path is not a safe directory")
    _write_json(incomplete / "config_snapshot.json", contract.config)
    shutil.copy2(contract.manifest_path, incomplete / "basin_manifest_snapshot.csv")
    empty_tables = {
        "restart_parameter_vectors.csv": ("basin_id", *V03_RESTART_PARAMETER_COLUMNS),
        "fit_restart_hydrographs.csv": ("basin_id", *V03_FIT_HYDROGRAPH_COLUMNS),
        "validation_restart_hydrographs.csv": (
            "basin_id",
            *V03_VALIDATION_HYDROGRAPH_COLUMNS,
        ),
        "functional_stability_metrics.csv": (
            "basin_id",
            *V03_FUNCTIONAL_METRIC_COLUMNS,
        ),
    }
    if _uses_initialization_response_diagnostics(contract.config):
        empty_tables.update({
            "initial_state_convergence_hydrographs.csv": (
                "basin_id",
                *V04_INITIAL_HYDROGRAPH_COLUMNS,
            ),
            "initial_state_convergence_metrics.csv": (
                "basin_id",
                *V04_INITIAL_METRIC_COLUMNS,
            ),
            "hydrograph_response_metrics.csv": (
                "basin_id",
                *V04_RESPONSE_METRIC_COLUMNS,
            ),
        })
    for filename, columns in empty_tables.items():
        path = incomplete / filename
        if not path.exists():
            pd.DataFrame(columns=columns).to_csv(
                path,
                index=False,
                lineterminator="\n",
            )
    restart_path = incomplete / "restart_execution.csv"
    if not restart_path.exists():
        _write_v03_restart_execution_csv(restart_path, restart_execution)
    _write_json(
        incomplete / "restart_telemetry_partial.json",
        telemetry_by_basin,
    )
    if coverage_payload is not None:
        _write_json(incomplete / "preflight_coverage.json", coverage_payload)
    _write_json(
        incomplete / "error.json",
        {
            "classification": contract.profile_name,
            "status": "run_failed",
            "failure_phase": failure_phase,
            "error_type": type(error).__name__,
            "error_message": str(error),
            "observed_restart_rows": len(restart_execution),
            "raw_daily_evidence_complete": False,
        },
    )
    if _uses_initialization_response_diagnostics(contract.config):
        _write_initialization_response_parameter_domain_evidence(contract, incomplete)
        _write_initialization_response_cached_environment(
            contract,
            incomplete,
            lifecycle,
            allow_incomplete_python_inventory=True,
        )
    else:
        _write_json(incomplete / "environment.json", _environment_record())
    (incomplete / "git_status.txt").write_text(
        _git_status(contract.repo_root),
        encoding="utf-8",
    )
    source_snapshot = incomplete / "source_snapshot"
    if not source_snapshot.exists():
        _copy_source_snapshot(contract, source_snapshot)
    if not _uses_initialization_response_diagnostics(contract.config):
        environment_outputs = v03_execution_evidence.capture_environment_command_outputs()
        for filename in ("python_packages.txt", "conda_explicit.txt"):
            (incomplete / filename).write_text(environment_outputs[filename], encoding="utf-8")
    stdout_text = _v03_captured_stream_text(lifecycle, "stdout")
    stderr_text = _v03_captured_stream_text(lifecycle, "stderr")
    traceback_text = "".join(traceback.format_exception(type(error), error, error.__traceback__))
    (incomplete / "stdout.log").write_text(stdout_text, encoding="utf-8")
    (incomplete / "stderr.log").write_text(
        stderr_text + traceback_text,
        encoding="utf-8",
    )
    events, terminal = _v03_failure_events(contract, restart_execution, lifecycle)
    _write_json_lines(incomplete / "run_events.jsonl", events)
    _write_json(
        incomplete / "checksums.json",
        _artifact_checksums(
            incomplete,
            excluded_names=frozenset({"checksums.json", "run_manifest.json"}),
        ),
    )
    artifact_hashes = _artifact_checksums(
        incomplete,
        excluded_names=frozenset({"run_manifest.json"}),
    )
    manifest = _v03_run_manifest(
        contract,
        incomplete,
        restart_execution,
        lifecycle,
        terminal,
        artifact_hashes,
        terminal_status="failed",
        exit_code=1,
    )
    _write_json(incomplete / "run_manifest.json", manifest)
    _verify_versioned_execution_evidence(
        contract,
        incomplete,
        expected_run_instance_id=str(lifecycle["run_instance_id"]),
        allow_failed=True,
    )


def _source_files(contract: AccessContract) -> tuple[Path, ...]:
    required_items: list[Path | None] = [
        Path(__file__).resolve(),
        REPO_ROOT / "src/camels_switch_confirmation/real_regime_parameter_calibration.py",
        REPO_ROOT / "src/scl_hydro/hbv_lite_cma_calibrate.py",
        REPO_ROOT / "src/scl_hydro/hbv_lite_numpy.py",
        REPO_ROOT / "src/hydroagent/data_loading.py",
        contract.config_path,
        contract.manifest_path,
        contract.development_universe_path,
    ]
    if contract.input_manifest_path is not None:
        required_items.append(contract.input_manifest_path)
    if contract.topography_path is not None:
        required_items.append(contract.topography_path)
    if _uses_restart_evidence(contract.config):
        required_items.extend(
            [
                REPO_ROOT
                / "docs/plans/2026-08-24-real-regime-output-functional-stability-principle-v03.md",
                REPO_ROOT
                / "docs/superpowers/plans/2026-08-24-real-regime-output-functional-stability-v03.md",
                REPO_ROOT
                / "src/camels_switch_confirmation/protocols/"
                "real_regime_parameter_output_functional_stability_v03.freeze.json",
                REPO_ROOT / "src/camels_switch_confirmation/protocol_freeze.py",
                REPO_ROOT / "src/camels_switch_confirmation/v03_execution_evidence.py",
            ]
        )
    if _is_v04_config(contract.config):
        required_items.extend(
            [
                REPO_ROOT
                / "docs/plans/2026-08-24-real-regime-parameter-domain-initialization-principle-v04.md",
                REPO_ROOT
                / "docs/superpowers/plans/2026-08-24-real-regime-parameter-domain-initialization-v04.md",
                REPO_ROOT
                / "src/camels_switch_confirmation/protocols/"
                "real_regime_parameter_domain_initialization_v04.freeze.json",
                REPO_ROOT / "src/camels_switch_confirmation/protocol_freeze_v04.py",
                REPO_ROOT / "src/camels_switch_confirmation/v04_execution_evidence.py",
                REPO_ROOT / "test/test_real_regime_v04_diagnostics.py",
                REPO_ROOT / "test/test_real_regime_v04_protocol_registration.py",
                REPO_ROOT / "test/test_real_regime_v04_execution_evidence.py",
                REPO_ROOT / "test/test_real_regime_v04_entry_lifecycle.py",
            ]
        )
    if _is_v05_config(contract.config):
        execution_evidence = _execution_evidence_for(contract.config)
        required_items.extend(
            REPO_ROOT / relative_path
            for relative_path in execution_evidence.V05_SOURCE_FILE_PATHS
        )
        credential_path = (
            contract.repo_root / str(contract.config.get("protocol_credential", ""))
        ).resolve()
        required_items.append(credential_path)
        if credential_path.is_file():
            credential = json.loads(credential_path.read_text(encoding="utf-8"))
            human_path = (
                contract.repo_root / str(credential.get("human_protocol_path", ""))
            ).resolve()
            required_items.append(human_path)
    required = tuple(required_items)
    missing = [str(path) for path in required if path is None or not Path(path).is_file()]
    if missing:
        raise FileNotFoundError(f"required source snapshot files are missing: {missing}")
    optional = (
        REPO_ROOT / "docs/superpowers/plans/2026-08-23-real-flow-regime-parameter-development-screen.md",
        REPO_ROOT / "docs/superpowers/plans/2026-08-23-real-flow-regime-parameter-development-screen-v02.md",
        REPO_ROOT / "test/test_camels_strict_streamflow_window.py",
        REPO_ROOT / "test/test_hbv_lite_cma_regime_mask.py",
        REPO_ROOT / "test/test_real_regime_parameter_calibration_contract.py",
        REPO_ROOT / "test/test_real_regime_parameter_calibration_runner.py",
        REPO_ROOT / "test/test_real_regime_v03_protocol_registration.py",
        REPO_ROOT / "test/test_real_regime_v03_execution_evidence.py",
    )
    return tuple(Path(path).resolve() for path in required) + tuple(
        path.resolve() for path in optional if path.is_file()
    )


def _copy_source_snapshot(contract: AccessContract, destination: Path) -> None:
    destination.mkdir()
    entries = []
    for index, source in enumerate(_source_files(contract)):
        try:
            original_path = source.relative_to(REPO_ROOT).as_posix()
        except ValueError:
            original_path = str(source)
        # Keep snapshot names short because the immutable experiment identifier
        # can already make Windows test and result paths approach MAX_PATH.
        snapshot_name = f"{index:03d}{source.suffix.lower()}"
        target = destination / snapshot_name
        shutil.copy2(source, target)
        entries.append(
            {
                "original_path": original_path,
                "snapshot_path": snapshot_name,
                "sha256": _sha256(source),
            }
        )
    _write_json(destination / "manifest.json", {"source_files": entries})


def _artifact_checksums(
    directory: Path,
    *,
    excluded_names: frozenset[str] = frozenset({"checksums.json"}),
) -> dict[str, str]:
    return {
        path.relative_to(directory).as_posix(): _sha256(path)
        for path in sorted(directory.rglob("*"))
        if path.is_file() and path.name not in excluded_names
    }


def _summary_text(value: Any) -> str:
    return json.dumps(_json_ready(value), sort_keys=True, ensure_ascii=False).lower()


def _validate_summary(summary: Mapping[str, Any]) -> None:
    classification = str(summary.get("classification", ""))
    if classification not in EXECUTION_PROFILES:
        raise ValueError(f"summary classification must be one of {sorted(EXECUTION_PROFILES)}")
    if summary.get("technical_status") != "completed":
        raise ValueError("summary technical_status must be completed")
    text = _summary_text(summary)
    found = [term for term in DISALLOWED_SUMMARY_TERMS if term in text]
    if found:
        raise ValueError(f"summary contains disallowed claim language: {found}")


def _strict_boolean(record: Mapping[str, Any], key: str, label: str) -> bool:
    if key not in record or not isinstance(record[key], bool):
        raise ValueError(f"{label} {key} must be a JSON boolean")
    return bool(record[key])


def _strict_integer(record: Mapping[str, Any], key: str, label: str, *, minimum: int = 0) -> int:
    value = record.get(key)
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{label} {key} must be an integer of at least {minimum}")
    return int(value)


def _finite_number(record: Mapping[str, Any], key: str, label: str) -> float:
    value = record.get(key)
    if isinstance(value, bool):
        raise ValueError(f"{label} {key} must be a finite number")
    try:
        numeric = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{label} {key} must be a finite number") from error
    if not np.isfinite(numeric):
        raise ValueError(f"{label} {key} must be a finite number")
    return numeric


def _require_boolean_match(
    record: Mapping[str, Any],
    key: str,
    expected: bool,
    label: str,
) -> None:
    if _strict_boolean(record, key, label) != bool(expected):
        raise ValueError(f"development-screen {label} {key} is inconsistent")


def _table_boolean(value: Any, label: str) -> bool:
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    if isinstance(value, str) and value in {"True", "False"}:
        return value == "True"
    raise ValueError(f"{label} must be boolean")


def _verify_source_snapshot(
    output: Path,
    classification: str,
    config: Mapping[str, Any],
) -> None:
    directory = output / "source_snapshot"
    manifest_path = directory / "manifest.json"
    if not directory.is_dir() or not manifest_path.is_file():
        raise ValueError("source snapshot must contain manifest.json")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    entries = manifest.get("source_files") if isinstance(manifest, Mapping) else None
    if not isinstance(entries, list) or not entries:
        raise ValueError("source snapshot manifest must contain source_files")
    original_paths: set[str] = set()
    snapshot_paths: set[str] = set()
    for position, entry in enumerate(entries):
        if not isinstance(entry, Mapping):
            raise ValueError(f"source snapshot entry {position} must be a mapping")
        original_path = str(entry.get("original_path", ""))
        snapshot_path = str(entry.get("snapshot_path", ""))
        digest = str(entry.get("sha256", "")).lower()
        relative = Path(snapshot_path)
        if (
            not original_path
            or not snapshot_path
            or relative.is_absolute()
            or len(relative.parts) != 1
            or relative.name != snapshot_path
            or ".." in relative.parts
        ):
            raise ValueError(f"source snapshot entry {position} contains an unsafe path")
        if original_path in original_paths or snapshot_path in snapshot_paths:
            raise ValueError("source snapshot paths must be unique")
        if re.fullmatch(r"[0-9a-f]{64}", digest) is None:
            raise ValueError(f"source snapshot entry {position} has an invalid SHA-256 digest")
        snapshot_file = directory / relative
        if not snapshot_file.is_file() or _sha256(snapshot_file) != digest:
            raise ValueError(f"source snapshot entry {position} checksum differs")
        original_paths.add(original_path)
        snapshot_paths.add(snapshot_path)
    actual_files = {
        path.relative_to(directory).as_posix()
        for path in directory.rglob("*")
        if path.is_file()
    }
    if actual_files != snapshot_paths | {"manifest.json"}:
        raise ValueError("source snapshot file set differs from its manifest")
    if classification == "development_screen":
        required_sources = {
            "docs/superpowers/plans/2026-08-23-real-flow-regime-parameter-development-screen.md",
            "test/test_camels_strict_streamflow_window.py",
        }
        if config.get("target_state_coverage_policy") is not None:
            required_sources.add(
                "docs/superpowers/plans/2026-08-23-real-flow-regime-parameter-development-screen-v02.md"
            )
        if _is_v04_config(config):
            required_sources.update({
                "docs/plans/2026-08-24-real-regime-parameter-domain-initialization-principle-v04.md",
                "docs/superpowers/plans/2026-08-24-real-regime-parameter-domain-initialization-v04.md",
                "src/camels_switch_confirmation/protocols/real_regime_parameter_domain_initialization_v04.freeze.json",
                "src/camels_switch_confirmation/protocol_freeze_v04.py",
                "src/camels_switch_confirmation/v03_execution_evidence.py",
                "src/camels_switch_confirmation/v04_execution_evidence.py",
                "test/test_real_regime_v04_diagnostics.py",
                "test/test_real_regime_v04_protocol_registration.py",
                "test/test_real_regime_v04_execution_evidence.py",
                "test/test_real_regime_v04_entry_lifecycle.py",
            })
        if _is_v05_config(config):
            execution_evidence = _execution_evidence_for(config)
            required_sources.update(execution_evidence.V05_SOURCE_FILE_PATHS)
            credential_path = (REPO_ROOT / str(config.get("protocol_credential", ""))).resolve()
            try:
                credential_source = credential_path.relative_to(REPO_ROOT).as_posix()
            except ValueError:
                credential_source = str(credential_path)
            required_sources.add(credential_source)
            if credential_path.is_file():
                credential = json.loads(credential_path.read_text(encoding="utf-8"))
                human_path = (
                    REPO_ROOT / str(credential.get("human_protocol_path", ""))
                ).resolve()
                try:
                    human_source = human_path.relative_to(REPO_ROOT).as_posix()
                except ValueError:
                    human_source = str(human_path)
                required_sources.add(human_source)
        missing_sources = sorted(required_sources - original_paths)
        if missing_sources:
            raise ValueError(f"source snapshot lacks development-screen sources: {missing_sources}")


def _verify_metric_record_keys(
    table: pd.DataFrame,
    expected_keys: set[tuple[str, str]],
    filename: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    required = {"basin_id", "parameter_id", "record_type"}
    missing = sorted(required - set(table.columns))
    if missing:
        raise ValueError(f"{filename} is missing columns: {missing}")
    table = table.copy()
    table["basin_id"] = table["basin_id"].astype(str).str.zfill(8)
    if not set(table["parameter_id"]) <= set(PARAMETER_IDS):
        raise ValueError(f"{filename} contains an unknown parameter identifier")
    selected = table[table["record_type"] == "selected_fit_result"].copy()
    selected_keys = set(zip(selected["basin_id"], selected["parameter_id"], strict=True))
    if len(selected) != len(expected_keys) or selected_keys != expected_keys:
        raise ValueError(f"{filename} must contain one selected fit result per basin and parameter set")
    if selected.duplicated(["basin_id", "parameter_id"]).any():
        raise ValueError(f"{filename} contains duplicate selected fit results")
    restarts = table[table["record_type"] == "restart"].copy()
    allowed = {"selected_fit_result", "restart"}
    if filename == "validation_metrics.csv":
        allowed.add("water_year_target_direction")
    if not set(table["record_type"]) <= allowed:
        raise ValueError(f"{filename} contains an unknown record type")
    return selected, restarts


def _restart_keyed_records(
    table: pd.DataFrame,
    expected_keys: set[tuple[str, str]],
    restart_seeds: tuple[int, ...],
    filename: str,
) -> dict[tuple[str, str, int, int], pd.Series]:
    required = {"restart_index", "seed", RESTART_FINGERPRINT}
    missing = sorted(required - set(table.columns))
    if missing:
        raise ValueError(f"{filename} restart rows are missing columns: {missing}")
    expected_identity = set(enumerate(restart_seeds))
    keyed: dict[tuple[str, str, int, int], pd.Series] = {}
    for basin_id, parameter_id in sorted(expected_keys):
        selected = table[(table["basin_id"] == basin_id) & (table["parameter_id"] == parameter_id)]
        identities: set[tuple[int, int]] = set()
        for _, row in selected.iterrows():
            restart_index_value = float(row["restart_index"])
            seed_value = float(row["seed"])
            if (
                not np.isfinite(restart_index_value)
                or not np.isfinite(seed_value)
                or not restart_index_value.is_integer()
                or not seed_value.is_integer()
            ):
                raise ValueError(f"{filename} restart identity must contain finite integers")
            identity = (int(restart_index_value), int(seed_value))
            if identity in identities:
                raise ValueError(f"{filename} contains duplicate restart identities")
            identities.add(identity)
            keyed[(basin_id, parameter_id, *identity)] = row
        if identities != expected_identity:
            raise ValueError(f"{filename} restart identities differ from the frozen configuration")
    return keyed


def _verify_development_tables(
    config: Mapping[str, Any],
    basin_ids: tuple[str, ...],
    tables: Mapping[str, pd.DataFrame],
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    if basin_ids != SCREEN_BASIN_IDS:
        raise ValueError("development-screen basin order differs from the frozen three-basin screen")
    expected_keys = {(basin_id, parameter_id) for basin_id in basin_ids for parameter_id in PARAMETER_IDS}
    vectors = tables["parameter_vectors.csv"].copy()
    required_vector_columns = {"basin_id", "parameter_id", FIT_SELECTED_FINGERPRINT, *PARAM_NAMES}
    missing = sorted(required_vector_columns - set(vectors.columns))
    if missing:
        raise ValueError(f"parameter_vectors.csv is missing columns: {missing}")
    vectors["basin_id"] = vectors["basin_id"].astype(str).str.zfill(8)
    vector_keys = set(zip(vectors["basin_id"], vectors["parameter_id"], strict=True))
    if len(vectors) != len(expected_keys) or vector_keys != expected_keys:
        raise ValueError("parameter_vectors.csv must contain the frozen nine basin-parameter rows")
    if vectors.duplicated(["basin_id", "parameter_id"]).any():
        raise ValueError("parameter_vectors.csv contains duplicate basin-parameter rows")
    bounds = resolve_hbv_bounds(str(config["parameter_bounds_preset"]))
    vector_fingerprints: dict[tuple[str, str], str] = {}
    for _, row in vectors.iterrows():
        key = (str(row["basin_id"]), str(row["parameter_id"]))
        parameters = {name: float(row[name]) for name in PARAM_NAMES}
        for name, value in parameters.items():
            lower, upper = bounds[name]
            if not np.isfinite(value) or value < lower or value > upper:
                raise ValueError(f"development-screen parameter {name} is nonfinite or out of bounds")
        expected_fingerprint = _parameter_sha256(parameters, f"parameter vector {key}")
        stored_fingerprint = str(row[FIT_SELECTED_FINGERPRINT])
        if (
            re.fullmatch(r"[0-9a-f]{64}", stored_fingerprint) is None
            or stored_fingerprint != expected_fingerprint
        ):
            raise ValueError("development-screen selected parameter fingerprint differs from its vector")
        vector_fingerprints[key] = expected_fingerprint

    fit_selected, fit_restarts = _verify_metric_record_keys(
        tables["fit_metrics.csv"],
        expected_keys,
        "fit_metrics.csv",
    )
    validation_selected, validation_restarts = _verify_metric_record_keys(
        tables["validation_metrics.csv"],
        expected_keys,
        "validation_metrics.csv",
    )
    restart_seeds = tuple(int(seed) for seed in config["optimizer"]["restart_seeds"])
    fit_restart_records = _restart_keyed_records(
        fit_restarts,
        expected_keys,
        restart_seeds,
        "fit_metrics.csv",
    )
    validation_restart_records = _restart_keyed_records(
        validation_restarts,
        expected_keys,
        restart_seeds,
        "validation_metrics.csv",
    )
    if set(fit_restart_records) != set(validation_restart_records):
        raise ValueError("development-screen fit and validation restart identities differ")

    fit_selected_records = {
        (str(row["basin_id"]), str(row["parameter_id"])): row
        for _, row in fit_selected.iterrows()
    }
    validation_selected_records = {
        (str(row["basin_id"]), str(row["parameter_id"])): row
        for _, row in validation_selected.iterrows()
    }
    for key in sorted(expected_keys):
        vector_fingerprint = vector_fingerprints[key]
        fit_row = fit_selected_records[key]
        validation_row = validation_selected_records[key]
        fit_fingerprint = str(fit_row.get(FIT_SELECTED_FINGERPRINT, ""))
        validation_fingerprint = str(validation_row.get(FIT_SELECTED_FINGERPRINT, ""))
        if (
            re.fullmatch(r"[0-9a-f]{64}", fit_fingerprint) is None
            or re.fullmatch(r"[0-9a-f]{64}", validation_fingerprint) is None
            or fit_fingerprint != vector_fingerprint
            or validation_fingerprint != vector_fingerprint
        ):
            raise ValueError("development-screen selected parameter fingerprint differs across tables")
        fit_loss = float(fit_row.get("objective_loss", float("nan")))
        validation_fit_loss = float(validation_row.get("fit_objective_loss", float("nan")))
        if (
            not np.isfinite(fit_loss)
            or not np.isfinite(validation_fit_loss)
            or not np.isclose(fit_loss, validation_fit_loss, rtol=0.0, atol=1e-12)
        ):
            raise ValueError("development-screen selected fit objective loss differs across tables")
        matching_selected_restart = False
        restart_losses = []
        for restart_index, seed in enumerate(restart_seeds):
            restart_key = (*key, restart_index, seed)
            fit_restart = fit_restart_records[restart_key]
            validation_restart = validation_restart_records[restart_key]
            fit_restart_fingerprint = str(fit_restart[RESTART_FINGERPRINT])
            validation_restart_fingerprint = str(validation_restart[RESTART_FINGERPRINT])
            if (
                re.fullmatch(r"[0-9a-f]{64}", fit_restart_fingerprint) is None
                or re.fullmatch(r"[0-9a-f]{64}", validation_restart_fingerprint) is None
                or fit_restart_fingerprint != validation_restart_fingerprint
            ):
                raise ValueError("development-screen restart parameter fingerprint differs across tables")
            fit_restart_loss = float(fit_restart.get("objective_loss", float("nan")))
            validation_restart_loss = float(
                validation_restart.get("fit_objective_loss", float("nan"))
            )
            if (
                not np.isfinite(fit_restart_loss)
                or not np.isfinite(validation_restart_loss)
                or not np.isclose(
                    fit_restart_loss,
                    validation_restart_loss,
                    rtol=0.0,
                    atol=1e-12,
                )
            ):
                raise ValueError("development-screen restart fit objective loss differs across tables")
            restart_losses.append(fit_restart_loss)
            matching_selected_restart |= bool(
                fit_restart_fingerprint == vector_fingerprint
                and np.isclose(fit_restart_loss, fit_loss, rtol=0.0, atol=1e-12)
            )
        if not matching_selected_restart or fit_loss > min(restart_losses) + 1e-12:
            raise ValueError("development-screen selected fit result is not a fit-selected restart")
    return vectors, validation_selected, validation_restarts


def _verify_validation_gate(
    gate: Mapping[str, Any],
    config: Mapping[str, Any],
    label: str,
) -> bool:
    frozen = config["validation_gates"]
    improvement = _finite_number(gate, "target_relative_improvement", label)
    improved_years = _strict_integer(gate, "improved_water_years", label)
    nse_drop = _finite_number(gate, "all_flow_nse_drop", label)
    opposite = _finite_number(gate, "opposite_regime_relative_degradation", label)
    must_beat = _strict_boolean(gate, "must_beat_other_specialist", label)
    beats_other = _strict_boolean(gate, "target_loss_beats_other_specialist", label)
    frozen_numbers = {
        "target_relative_improvement_min": float(frozen["target_relative_improvement_min"]),
        "all_flow_nse_drop_max": float(frozen["all_flow_nse_drop_max"]),
        "opposite_regime_relative_degradation_max": float(
            frozen["opposite_regime_relative_degradation_max"]
        ),
    }
    for key, expected in frozen_numbers.items():
        if not np.isclose(_finite_number(gate, key, label), expected, rtol=0.0, atol=0.0):
            raise ValueError(f"development-screen {label} {key} differs from configuration")
    if (
        _strict_integer(gate, "minimum_improved_water_years", label, minimum=1)
        != int(frozen["minimum_improved_water_years"])
    ):
        raise ValueError(f"development-screen {label} water-year threshold differs")
    if must_beat != bool(frozen["must_beat_other_specialist"]):
        raise ValueError(f"development-screen {label} must-beat rule differs from configuration")
    checks = {
        "target_improvement_pass": improvement >= float(frozen["target_relative_improvement_min"]),
        "water_year_direction_pass": improved_years >= int(frozen["minimum_improved_water_years"]),
        "all_period_nse_guardrail_pass": nse_drop <= float(frozen["all_flow_nse_drop_max"]),
        "opposite_regime_guardrail_pass": (
            opposite <= float(frozen["opposite_regime_relative_degradation_max"])
        ),
        "target_beats_other_specialist_pass": beats_other or not must_beat,
    }
    for key, expected in checks.items():
        _require_boolean_match(gate, key, expected, label)
    qualifies = all(checks.values())
    _require_boolean_match(gate, "qualifies", qualifies, label)
    return qualifies


def _verify_v02_regime_coverage(
    per_basin: Mapping[str, Any],
    config: Mapping[str, Any],
    basin_id: str,
) -> dict[str, bool]:
    from camels_switch_confirmation.real_regime_parameter_calibration import (
        apply_regime_coverage_policy,
    )

    coverage = per_basin.get("regime_water_year_coverage")
    if not isinstance(coverage, Mapping) or set(coverage) != {"fit", "validation"}:
        raise ValueError(f"development-screen basin {basin_id} lacks exact regime coverage evidence")
    expected_period_keys = {
        "minimum_days",
        "water_years",
        "evidence_sufficient",
        "coverage_policy",
        "low_flow_total_days",
        "high_flow_total_days",
        "low_flow_qualifying_water_years",
        "high_flow_qualifying_water_years",
        "low_flow_evidence_sufficient",
        "high_flow_evidence_sufficient",
    }
    expected_record_keys = {
        "water_year",
        "period_days",
        "finite_observation_days",
        "low_flow_days",
        "high_flow_days",
        "low_flow_sufficient",
        "high_flow_sufficient",
        "evidence_sufficient",
    }
    expected_years = {
        "fit": list(range(2000, 2006)),
        "validation": list(range(2006, 2009)),
    }
    recomputed_periods: dict[str, Mapping[str, Any]] = {}
    for period_name in ("fit", "validation"):
        stored = coverage.get(period_name)
        if not isinstance(stored, Mapping) or set(stored) != expected_period_keys:
            raise ValueError(
                f"development-screen basin {basin_id} {period_name} coverage fields are inconsistent"
            )
        if _strict_integer(stored, "minimum_days", "regime coverage", minimum=1) != 30:
            raise ValueError("development-screen regime coverage per-year threshold differs")
        records = stored.get("water_years")
        if not isinstance(records, list) or any(
            not isinstance(record, Mapping) or set(record) != expected_record_keys for record in records
        ):
            raise ValueError(
                f"development-screen basin {basin_id} {period_name} water-year records are inconsistent"
            )
        years = [
            _strict_integer(record, "water_year", "regime coverage water year", minimum=1)
            for record in records
        ]
        if years != expected_years[period_name]:
            raise ValueError(
                f"development-screen basin {basin_id} {period_name} water years are inconsistent"
            )
        recomputed = apply_regime_coverage_policy(
            {
                "minimum_days": 30,
                "water_years": records,
                "evidence_sufficient": False,
            },
            **dict(config["target_state_coverage_policy"][period_name]),
        )
        if _json_ready(recomputed) != stored:
            raise ValueError(
                f"development-screen basin {basin_id} {period_name} coverage summary is inconsistent"
            )
        recomputed_periods[period_name] = recomputed
    validation = recomputed_periods["validation"]
    return {
        "all_flow": bool(validation["evidence_sufficient"]),
        "low_flow": bool(validation["low_flow_evidence_sufficient"]),
        "high_flow": bool(validation["high_flow_evidence_sufficient"]),
    }


def _verify_quality_gates(
    per_basin: Mapping[str, Any],
    config: Mapping[str, Any],
    basin_id: str,
    selected_parameters: Mapping[str, Mapping[str, float]],
    expected_evidence: Mapping[str, bool] | None = None,
) -> dict[str, bool]:
    from camels_switch_confirmation.real_regime_parameter_calibration import (
        parameter_boundary_diagnostics,
    )

    validation = per_basin.get("development_validation_gates")
    quality = per_basin.get("parameter_quality_gates")
    if not isinstance(validation, Mapping) or not isinstance(quality, Mapping):
        raise ValueError(f"development-screen basin {basin_id} lacks complete quality gates")
    validation_qualifies = {
        name: _verify_validation_gate(
            validation.get(name, {}),
            config,
            f"basin {basin_id} {name} validation gate",
        )
        for name in ("low_flow", "high_flow")
    }
    validation_all = validation_qualifies["low_flow"] and validation_qualifies["high_flow"]
    _require_boolean_match(
        validation,
        "all_specialists_qualify",
        validation_all,
        f"basin {basin_id} validation gates",
    )

    quality_config = config["parameter_quality_gates"]
    generalist_nse = _finite_number(quality, "generalist_nse", f"basin {basin_id} quality gates")
    stored_generalist_min = _finite_number(
        quality,
        "generalist_nse_min",
        f"basin {basin_id} quality gates",
    )
    if not np.isclose(
        stored_generalist_min,
        float(quality_config["generalist_nse_min"]),
        rtol=0.0,
        atol=0.0,
    ):
        raise ValueError(f"development-screen basin {basin_id} generalist threshold differs")
    generalist_nse_pass = generalist_nse >= float(quality_config["generalist_nse_min"])
    _require_boolean_match(
        quality,
        "generalist_nse_pass",
        generalist_nse_pass,
        f"basin {basin_id} quality gates",
    )
    qualifies: dict[str, bool] = {}
    for parameter_id in PARAMETER_IDS:
        gate = quality.get(parameter_id)
        if not isinstance(gate, Mapping):
            raise ValueError(f"development-screen basin {basin_id} lacks {parameter_id} quality gate")
        label = f"basin {basin_id} {parameter_id} quality gate"
        boundary = gate.get("selected_boundary_diagnostics")
        if not isinstance(boundary, Mapping):
            raise ValueError(f"development-screen {label} lacks boundary diagnostics")
        expected_boundary = parameter_boundary_diagnostics(
            selected_parameters[parameter_id],
            resolve_hbv_bounds(str(config["parameter_bounds_preset"])),
        )
        if boundary != _json_ready(expected_boundary):
            raise ValueError(f"development-screen {label} boundary diagnostics are inconsistent")
        near_count = _strict_integer(boundary, "near_boundary_count", label)
        saturated_count = _strict_integer(boundary, "strongly_saturated_count", label)
        boundary_pass = (
            near_count <= int(quality_config["maximum_near_boundary_parameters"])
            and saturated_count <= int(quality_config["maximum_strongly_saturated_parameters"])
        )
        _require_boolean_match(gate, "selected_boundary_pass", boundary_pass, label)
        selected_nse = _finite_number(gate, "selected_validation_nse", label)
        if parameter_id == "all_flow" and not np.isclose(
            selected_nse,
            generalist_nse,
            rtol=0.0,
            atol=1e-12,
        ):
            raise ValueError("development-screen all-flow validation efficiency is inconsistent")
        selected_nse_pass = selected_nse >= float(quality_config["generalist_nse_min"])
        _require_boolean_match(gate, "selected_validation_nse_pass", selected_nse_pass, label)
        evidence_pass = _strict_boolean(gate, "selected_evidence_sufficient_pass", label)
        if expected_evidence is not None and evidence_pass != bool(expected_evidence[parameter_id]):
            raise ValueError(f"development-screen {label} evidence eligibility is inconsistent")
        selected_restart_pass = _strict_boolean(gate, "selected_restart_record_found_pass", label)
        support_count = _strict_integer(gate, "support_restart_count", label)
        minimum_support = _strict_integer(gate, "minimum_support_restarts", label, minimum=1)
        if minimum_support != int(quality_config["minimum_support_restarts"]):
            raise ValueError(f"development-screen {label} support threshold differs from configuration")
        support_restarts = gate.get("support_restarts")
        if not isinstance(support_restarts, list) or len(support_restarts) != support_count:
            raise ValueError(f"development-screen {label} support restart count is inconsistent")
        for restart in support_restarts:
            if not isinstance(restart, Mapping) or not _strict_boolean(
                restart,
                "qualifies_as_support",
                label,
            ):
                raise ValueError(f"development-screen {label} contains invalid support evidence")
        support_pass = support_count >= minimum_support
        _require_boolean_match(gate, "support_restart_pass", support_pass, label)
        components = [
            generalist_nse_pass,
            boundary_pass,
            selected_nse_pass,
            evidence_pass,
            selected_restart_pass,
            support_pass,
        ]
        if parameter_id != "all_flow":
            validation_pass = validation_qualifies[parameter_id]
            _require_boolean_match(gate, "validation_gate_pass", validation_pass, label)
            components.append(validation_pass)
        expected = all(components)
        _require_boolean_match(gate, "qualifies", expected, label)
        qualifies[parameter_id] = expected
    all_specialists = qualifies["low_flow"] and qualifies["high_flow"]
    all_parameters = qualifies["all_flow"] and all_specialists
    _require_boolean_match(
        quality,
        "all_specialists_qualify",
        all_specialists,
        f"basin {basin_id} quality gates",
    )
    _require_boolean_match(
        quality,
        "all_parameter_sets_qualify",
        all_parameters,
        f"basin {basin_id} quality gates",
    )
    qualifies["complete"] = all_parameters
    return qualifies


def _verify_development_summary(
    summary: Mapping[str, Any],
    config: Mapping[str, Any],
    basin_ids: tuple[str, ...],
    vectors: pd.DataFrame,
    validation_selected: pd.DataFrame,
    validation_restarts: pd.DataFrame,
    expected_areas_km2: Mapping[str, float],
) -> None:
    required_summary = {
        "basin_areas_km2",
        "per_basin",
        "qualified_low_flow_basin_count",
        "qualified_high_flow_basin_count",
        "qualified_generalist_basin_count",
        "all_generalists_pass",
        "complete_candidate_group_count",
        "cross_basin_complete_group_threshold",
        "cross_basin_boundary_consistency",
        "parameter_axis_development_gate",
        "authorizes_noise_axis",
        "authorizes_joint_axis",
        "authorizes_scientific_claim",
    }
    missing = sorted(required_summary - set(summary))
    if missing:
        raise ValueError(f"development-screen summary is missing fields: {missing}")
    per_basin = summary["per_basin"]
    areas = summary["basin_areas_km2"]
    if not isinstance(per_basin, Mapping) or list(per_basin) != list(basin_ids):
        raise ValueError("development-screen per-basin summary order differs from the manifest")
    if not isinstance(areas, Mapping) or list(areas) != list(basin_ids):
        raise ValueError("development-screen basin-area summary order differs from the manifest")
    for basin_id in basin_ids:
        basin_summary = per_basin[basin_id]
        if not isinstance(basin_summary, Mapping):
            raise ValueError(f"development-screen basin {basin_id} summary must be a mapping")
        expected_area = float(expected_areas_km2[basin_id])
        summary_area = _finite_number(areas, basin_id, "development-screen basin areas")
        per_basin_area = _finite_number(
            basin_summary,
            "basin_area_km2",
            f"development-screen basin {basin_id} summary",
        )
        if not (
            np.isclose(summary_area, expected_area, rtol=0.0, atol=1e-12)
            and np.isclose(per_basin_area, expected_area, rtol=0.0, atol=1e-12)
        ):
            raise ValueError(f"development-screen basin {basin_id} area differs from the manifest")
    selected_parameters = {
        basin_id: {
            parameter_id: {
                name: float(
                    vectors.loc[
                        (vectors["basin_id"] == basin_id)
                        & (vectors["parameter_id"] == parameter_id),
                        name,
                    ].iloc[0]
                )
                for name in PARAM_NAMES
            }
            for parameter_id in PARAMETER_IDS
        }
        for basin_id in basin_ids
    }
    coverage_evidence = {
        basin_id: _verify_v02_regime_coverage(per_basin[basin_id], config, basin_id)
        for basin_id in basin_ids
    } if config.get("target_state_coverage_policy") is not None else {}
    qualification = {
        basin_id: _verify_quality_gates(
            per_basin[basin_id],
            config,
            basin_id,
            selected_parameters[basin_id],
            coverage_evidence.get(basin_id),
        )
        for basin_id in basin_ids
    }
    counts = {
        "qualified_low_flow_basin_count": sum(
            int(qualification[basin_id]["low_flow"]) for basin_id in basin_ids
        ),
        "qualified_high_flow_basin_count": sum(
            int(qualification[basin_id]["high_flow"]) for basin_id in basin_ids
        ),
        "qualified_generalist_basin_count": sum(
            int(qualification[basin_id]["all_flow"]) for basin_id in basin_ids
        ),
        "complete_candidate_group_count": sum(
            int(qualification[basin_id]["complete"]) for basin_id in basin_ids
        ),
    }
    for key, expected in counts.items():
        if _strict_integer(summary, key, "development-screen summary") != expected:
            raise ValueError(f"development-screen summary {key} is inconsistent")
    all_generalists = counts["qualified_generalist_basin_count"] == len(basin_ids)
    _require_boolean_match(
        summary,
        "all_generalists_pass",
        all_generalists,
        "summary",
    )
    selected_gate_rows = {
        (str(row["basin_id"]), str(row["parameter_id"])): row
        for _, row in validation_selected.iterrows()
    }
    for basin_id in basin_ids:
        for parameter_id in PARAMETER_IDS:
            selected_row = selected_gate_rows[(basin_id, parameter_id)]
            gate_value = selected_row.get("gate_qualifies")
            if _table_boolean(
                gate_value,
                f"validation_metrics.csv {basin_id} {parameter_id} gate_qualifies",
            ) != qualification[basin_id][parameter_id]:
                raise ValueError("development-screen validation table quality flag is inconsistent")
            if coverage_evidence and _table_boolean(
                selected_row.get("evidence_sufficient"),
                f"validation hydrograph evidence {basin_id} {parameter_id}",
            ) != coverage_evidence[basin_id][parameter_id]:
                raise ValueError("development-screen selected validation evidence is inconsistent")
    if coverage_evidence:
        for _, restart in validation_restarts.iterrows():
            basin_id = str(restart["basin_id"]).zfill(8)
            parameter_id = str(restart["parameter_id"])
            if _table_boolean(
                restart.get("evidence_sufficient"),
                f"validation restart evidence {basin_id} {parameter_id}",
            ) != coverage_evidence[basin_id][parameter_id]:
                raise ValueError("development-screen restart validation evidence is inconsistent")
    cross_config = config["cross_basin_gates"]
    expected_boundary = _cross_basin_boundary_consistency(
        vectors,
        resolve_hbv_bounds(str(config["parameter_bounds_preset"])),
        basin_ids,
        boundary_fraction=float(cross_config["boundary_fraction"]),
    )
    if summary["cross_basin_boundary_consistency"] != _json_ready(expected_boundary):
        raise ValueError("development-screen cross-basin boundary summary is inconsistent")
    minimum_complete = int(cross_config["minimum_complete_candidate_groups"])
    if (
        _strict_integer(
            summary,
            "cross_basin_complete_group_threshold",
            "development-screen summary",
        )
        != minimum_complete
    ):
        raise ValueError("development-screen complete-group threshold is inconsistent")
    expected_axis = {
        "minimum_complete_candidate_groups": minimum_complete,
        "complete_candidate_group_count": counts["complete_candidate_group_count"],
        "complete_group_count_pass": counts["complete_candidate_group_count"] >= minimum_complete,
        "all_generalists_pass": all_generalists,
        "boundary_consistency_pass": bool(expected_boundary["qualifies"]),
        "qualifies": bool(
            counts["complete_candidate_group_count"] >= minimum_complete
            and all_generalists
            and expected_boundary["qualifies"]
        ),
    }
    if summary["parameter_axis_development_gate"] != expected_axis:
        raise ValueError("development-screen parameter-axis gate is inconsistent")
    for key in ("authorizes_noise_axis", "authorizes_joint_axis", "authorizes_scientific_claim"):
        if _strict_boolean(summary, key, "development-screen summary"):
            raise ValueError(f"development-screen summary {key} must remain false")


def _verify_validation_hydrographs(
    table: pd.DataFrame,
    basin_ids: tuple[str, ...],
    validation_period: tuple[date, date],
) -> None:
    """Validate the stored daily observed and fixed-parameter process lines."""

    if tuple(table.columns) != HYDROGRAPH_COLUMNS:
        raise ValueError("validation hydrograph table has the wrong columns or column order")
    table = table.copy()
    table["basin_id"] = table["basin_id"].astype(str).str.zfill(8)
    if tuple(table["basin_id"].drop_duplicates()) != basin_ids:
        raise ValueError("validation hydrograph basin order differs from the frozen manifest")
    expected_dates = pd.date_range(validation_period[0], validation_period[1], freq="D")
    if len(table) != len(expected_dates) * len(basin_ids):
        raise ValueError("validation hydrograph table has the wrong daily row count")
    flow_columns = HYDROGRAPH_COLUMNS[2:]
    for basin_id in basin_ids:
        selected = table[table["basin_id"] == basin_id]
        try:
            dates = pd.DatetimeIndex(pd.to_datetime(selected["date"], errors="raise"))
        except (TypeError, ValueError) as error:
            raise ValueError("validation hydrograph contains an invalid date") from error
        if not dates.equals(expected_dates):
            raise ValueError(
                f"validation hydrograph dates for basin {basin_id} are not the exact daily validation period"
            )
        for column in flow_columns:
            try:
                values = pd.to_numeric(selected[column], errors="raise").to_numpy(dtype=float)
            except (TypeError, ValueError) as error:
                raise ValueError(f"validation hydrograph {column} must be numeric") from error
            if not np.all(np.isfinite(values)) or np.any(values < 0.0):
                raise ValueError(f"validation hydrograph {column} must be finite and nonnegative")


def _verify_v04_diagnostic_evidence(
    tables: Mapping[str, pd.DataFrame],
    restart_tables: Mapping[str, pd.DataFrame],
    *,
    expected_restart_seeds: tuple[int, ...],
    fit_dates: Any,
    validation_dates: Any,
    expected_basin_ids: tuple[str, ...],
) -> None:
    """Recompute every v04 diagnostic from saved daily restart evidence."""

    if set(tables) != set(V04_DIAGNOSTIC_FILENAMES):
        raise ValueError("fourth-version diagnostic table set is incomplete or expanded")
    expected_columns = {
        "initial_state_convergence_hydrographs": (
            "basin_id",
            *V04_INITIAL_HYDROGRAPH_COLUMNS,
        ),
        "initial_state_convergence_metrics": ("basin_id", *V04_INITIAL_METRIC_COLUMNS),
        "hydrograph_response_metrics": ("basin_id", *V04_RESPONSE_METRIC_COLUMNS),
    }
    copied: dict[str, pd.DataFrame] = {}
    for name, columns in expected_columns.items():
        table = tables.get(name)
        if not isinstance(table, pd.DataFrame) or table.empty:
            raise ValueError(f"fourth-version {name} must be a nonempty DataFrame")
        if tuple(table.columns) != columns:
            raise ValueError(f"fourth-version {name} has the wrong columns or column order")
        copied[name] = table.copy()
        copied[name]["basin_id"] = copied[name]["basin_id"].astype(str).str.zfill(8)
        if tuple(copied[name]["basin_id"].drop_duplicates()) != expected_basin_ids:
            raise ValueError(
                f"fourth-version {name} basin order differs from the frozen manifest"
            )
        for column in ("restart_index", "seed"):
            copied[name][column] = [
                _strict_artifact_integer(
                    value,
                    f"fourth-version {name} {column}",
                    minimum=0,
                )
                for value in copied[name][column]
            ]
        copied[name]["selected"] = _coerce_artifact_booleans(
            copied[name]["selected"],
            f"fourth-version {name} selected identity",
        )

    expected_identities = {
        (basin_id, parameter_id, restart_index, int(seed))
        for basin_id in expected_basin_ids
        for parameter_id in PARAMETER_IDS
        for restart_index, seed in enumerate(expected_restart_seeds)
    }
    if len(expected_identities) != len(expected_basin_ids) * 9:
        raise ValueError("fourth-version contract requires nine restart identities per basin")
    identity_columns = ["basin_id", "parameter_id", "restart_index", "seed"]
    for name, table in copied.items():
        identities = set(map(tuple, table[identity_columns].drop_duplicates().to_numpy()))
        if identities != expected_identities:
            raise ValueError(
                f"fourth-version {name} must contain exactly nine restart identities per basin"
            )

    vectors = restart_tables.get("restart_parameter_vectors")
    fit = restart_tables.get("fit_restart_hydrographs")
    validation = restart_tables.get("validation_restart_hydrographs")
    if not all(isinstance(value, pd.DataFrame) and not value.empty for value in (vectors, fit, validation)):
        raise ValueError("fourth-version verifier lacks complete shared restart evidence")
    vectors = vectors.copy()
    fit = fit.copy()
    validation = validation.copy()
    for table in (vectors, fit, validation):
        table["basin_id"] = table["basin_id"].astype(str).str.zfill(8)
        for column in ("restart_index", "seed"):
            table[column] = [
                _strict_artifact_integer(
                    value,
                    f"fourth-version shared restart {column}",
                    minimum=0,
                )
                for value in table[column]
            ]
    vectors["selected"] = _coerce_artifact_booleans(
        vectors["selected"],
        "fourth-version restart vector selected",
    )
    if vectors.duplicated(identity_columns).any() or set(
        map(tuple, vectors[identity_columns].to_numpy())
    ) != expected_identities:
        raise ValueError("fourth-version restart parameter identities are incomplete or duplicated")
    vector_by_identity = {
        tuple(row[column] for column in identity_columns): row
        for _, row in vectors.iterrows()
    }

    fit_date_index = pd.DatetimeIndex(pd.to_datetime(fit_dates))
    validation_date_index = pd.DatetimeIndex(pd.to_datetime(validation_dates))
    if fit_date_index.empty or (fit_date_index[0].month, fit_date_index[0].day) != (10, 1):
        raise ValueError("fourth-version fit dates must begin with a complete water year")
    first_fit_end = pd.Timestamp(fit_date_index[0].year + 1, 9, 30)
    first_fit_dates = pd.date_range(fit_date_index[0], first_fit_end, freq="D")
    expected_validation_years = tuple(
        int(value)
        for value in np.unique(
            np.where(
                validation_date_index.month >= 10,
                validation_date_index.year + 1,
                validation_date_index.year,
            )
        )
    )
    if len(expected_validation_years) != 3:
        raise ValueError("fourth-version validation must contain exactly three water years")

    fit_records: dict[tuple[Any, ...], pd.DataFrame] = {}
    validation_records: dict[tuple[Any, ...], pd.DataFrame] = {}
    for identity in sorted(expected_identities):
        fit_group = fit[
            np.logical_and.reduce(
                [fit[column] == value for column, value in zip(identity_columns, identity)]
            )
        ].copy()
        validation_group = validation[
            np.logical_and.reduce(
                [validation[column] == value for column, value in zip(identity_columns, identity)]
            )
        ].copy()
        fit_group_dates = pd.DatetimeIndex(pd.to_datetime(fit_group["date"], errors="raise"))
        validation_group_dates = pd.DatetimeIndex(
            pd.to_datetime(validation_group["date"], errors="raise")
        )
        if not fit_group_dates.equals(fit_date_index):
            raise ValueError("fourth-version shared fit hydrograph dates are incomplete")
        if not validation_group_dates.equals(validation_date_index):
            raise ValueError("fourth-version shared validation hydrograph dates are incomplete")
        fit_group.index = fit_group_dates
        validation_group.index = validation_group_dates
        for table, label in ((fit_group, "fit"), (validation_group, "validation")):
            for column in (
                "observed_flow_mm_day",
                "simulated_flow_mm_day",
            ):
                values = pd.to_numeric(table[column], errors="raise").to_numpy(dtype=float)
                if not np.all(np.isfinite(values)) or np.any(values < 0.0):
                    raise ValueError(
                        f"fourth-version shared {label} hydrograph flow must be finite and nonnegative"
                    )
        for column in ("all_flow_member", "low_flow_member", "high_flow_member"):
            fit_group[column] = _coerce_artifact_booleans(
                fit_group[column],
                f"fourth-version shared fit {column}",
            )
        fit_records[identity] = fit_group
        validation_records[identity] = validation_group

    initial_hydrographs = copied["initial_state_convergence_hydrographs"]
    initial_metrics = copied["initial_state_convergence_metrics"]
    response_metrics = copied["hydrograph_response_metrics"]
    scenario_flows: dict[tuple[Any, ...], dict[str, np.ndarray]] = {}
    for identity in sorted(expected_identities):
        vector = vector_by_identity[identity]
        fingerprint = str(vector["parameter_sha256"])
        selected = bool(vector["selected"])
        hydro_group = initial_hydrographs[
            np.logical_and.reduce(
                [
                    initial_hydrographs[column] == value
                    for column, value in zip(identity_columns, identity)
                ]
            )
        ].copy()
        if set(hydro_group["scenario_id"]) != {"dry", "wet"}:
            raise ValueError("fourth-version initial hydrographs require dry and wet scenarios")
        scenario_flows[identity] = {}
        fit_group = fit_records[identity]
        fit_first_year = fit_group.loc[first_fit_dates]
        for scenario_id in ("dry", "wet"):
            scenario = hydro_group[hydro_group["scenario_id"] == scenario_id].copy()
            try:
                scenario_dates = pd.DatetimeIndex(pd.to_datetime(scenario["date"], errors="raise"))
            except (TypeError, ValueError) as error:
                raise ValueError("fourth-version initial hydrograph has invalid dates") from error
            if not scenario_dates.is_unique or not scenario_dates.equals(first_fit_dates):
                raise ValueError(
                    "fourth-version initial hydrographs must have unique daily dates for the first fit water year"
                )
            if not scenario["parameter_sha256"].astype(str).eq(fingerprint).all():
                raise ValueError("fourth-version initial hydrograph fingerprint differs from restart")
            if not scenario["selected"].eq(selected).all():
                raise ValueError("fourth-version initial hydrograph selected identity is inconsistent")
            observed = pd.to_numeric(
                scenario["observed_flow_mm_day"], errors="raise"
            ).to_numpy(dtype=float)
            if not np.allclose(
                observed,
                fit_first_year["observed_flow_mm_day"].to_numpy(dtype=float),
                rtol=0.0,
                atol=1e-12,
            ):
                raise ValueError(
                    "fourth-version initial hydrograph observations differ from shared fit evidence"
                )
            for column in ("all_flow_member", "low_flow_member", "high_flow_member"):
                actual_membership = _coerce_artifact_booleans(
                    scenario[column],
                    f"fourth-version initial hydrograph {column}",
                )
                if not np.array_equal(
                    actual_membership,
                    fit_first_year[column].to_numpy(dtype=bool),
                ):
                    raise ValueError(
                        "fourth-version initial hydrograph day-set membership differs from fit evidence"
                    )
            flow = pd.to_numeric(
                scenario["simulated_flow_mm_day"], errors="raise"
            ).to_numpy(dtype=float)
            if not np.all(np.isfinite(flow)) or np.any(flow < 0.0):
                raise ValueError(
                    "fourth-version initial hydrograph flow must be finite and nonnegative"
                )
            scenario_flows[identity][scenario_id] = flow

        metric_group = initial_metrics[
            np.logical_and.reduce(
                [initial_metrics[column] == value for column, value in zip(identity_columns, identity)]
            )
        ].copy()
        if len(metric_group) != 3 or set(metric_group["day_set"]) != set(PARAMETER_IDS):
            raise ValueError(
                "fourth-version initial-state metrics require exactly three unique day sets"
            )
        if metric_group["day_set"].duplicated().any():
            raise ValueError("fourth-version initial-state metrics contain duplicate day sets")
        if not metric_group["parameter_sha256"].astype(str).eq(fingerprint).all():
            raise ValueError("fourth-version initial-state metric fingerprint differs from restart")
        if not metric_group["selected"].eq(selected).all():
            raise ValueError("fourth-version initial-state metric selected identity is inconsistent")
        if not (
            metric_group["dry_scenario_id"].eq("dry").all()
            and metric_group["wet_scenario_id"].eq("wet").all()
        ):
            raise ValueError("fourth-version initial-state metric scenario identities differ")

        first_row = metric_group.iloc[0]
        numeric = {
            field: float(first_row[field])
            for field in (
                "dry_initial_slz_mm",
                "wet_initial_slz_mm",
                "dry_final_slz_mm",
                "wet_final_slz_mm",
                "par_k2",
                "initial_slz_difference_mm",
                "final_slz_difference_mm",
                "analytical_retained_fraction",
                "replayed_retained_fraction",
                "retained_fraction_max",
            )
        }
        if any(not np.isfinite(value) for value in numeric.values()):
            raise ValueError("fourth-version initial-state metric contains nonfinite values")
        for field, value in numeric.items():
            if not np.allclose(
                pd.to_numeric(metric_group[field], errors="raise").to_numpy(dtype=float),
                value,
                rtol=0.0,
                atol=1e-12,
            ):
                raise ValueError("fourth-version initial-state summary differs across day sets")
        warmup_days = _strict_artifact_integer(
            first_row["warmup_days"],
            "fourth-version initial-state warmup_days",
            minimum=1,
        )
        if warmup_days != V04_WARMUP_DAYS:
            raise ValueError("fourth-version initial-state warmup length differs from the contract")
        if not (
            _artifact_float_matches(numeric["dry_initial_slz_mm"], 0.0)
            and _artifact_float_matches(numeric["wet_initial_slz_mm"], 100.0)
            and _artifact_float_matches(numeric["initial_slz_difference_mm"], 100.0)
        ):
            raise ValueError("fourth-version initial-state identities must preserve the 100 mm contrast")
        final_difference = numeric["wet_final_slz_mm"] - numeric["dry_final_slz_mm"]
        analytical = (1.0 - float(vector["parK2"])) ** V04_WARMUP_DAYS
        replayed = final_difference / 100.0
        if not (
            _artifact_float_matches(numeric["par_k2"], float(vector["parK2"]))
            and _artifact_float_matches(numeric["final_slz_difference_mm"], final_difference)
            and _artifact_float_matches(numeric["analytical_retained_fraction"], analytical)
            and _artifact_float_matches(numeric["replayed_retained_fraction"], replayed)
            and _artifact_float_matches(
                numeric["retained_fraction_max"],
                V04_RETAINED_FRACTION_MAX,
                tolerance=0.0,
            )
        ):
            raise ValueError("fourth-version initial-state retained fraction differs from replay")
        analytical_pass = bool(analytical <= V04_RETAINED_FRACTION_MAX)
        replayed_pass = bool(replayed <= V04_RETAINED_FRACTION_MAX)
        retained_matches = bool(np.isclose(replayed, analytical, rtol=1e-10, atol=1e-12))
        for field, expected in (
            ("analytical_retained_fraction_pass", analytical_pass),
            ("replayed_retained_fraction_pass", replayed_pass),
            ("retained_fraction_matches_analytical", retained_matches),
        ):
            if not all(
                _table_boolean(value, f"fourth-version {field}") == expected
                for value in metric_group[field]
            ):
                raise ValueError(f"fourth-version {field} differs from recomputation")

        distance_passes = []
        for day_set in PARAMETER_IDS:
            row = metric_group[metric_group["day_set"] == day_set].iloc[0]
            membership_column = f"{day_set}_member"
            compare_membership = fit_first_year[membership_column].to_numpy(dtype=bool)
            fit_membership = fit_group[membership_column].to_numpy(dtype=bool)
            dry_flow = scenario_flows[identity]["dry"]
            wet_flow = scenario_flows[identity]["wet"]
            if day_set == "low_flow":
                dry_values = np.log(dry_flow[compare_membership] + 0.01)
                wet_values = np.log(wet_flow[compare_membership] + 0.01)
                scale_values = np.log(
                    fit_group.loc[fit_membership, "observed_flow_mm_day"].to_numpy(dtype=float)
                    + 0.01
                )
                expected_transform = "log_q_plus_offset"
                expected_offset = 0.01
            else:
                dry_values = dry_flow[compare_membership]
                wet_values = wet_flow[compare_membership]
                scale_values = fit_group.loc[
                    fit_membership,
                    "observed_flow_mm_day",
                ].to_numpy(dtype=float)
                expected_transform = "identity"
                expected_offset = None
            numerator = float(np.mean(np.square(dry_values - wet_values)))
            denominator = float(np.var(scale_values, ddof=0))
            if not np.isfinite(denominator) or denominator <= 0.0:
                raise ValueError("fourth-version six-year fit variance must be positive")
            distance = numerator / denominator
            if not _artifact_float_matches(row["numerator"], numerator):
                raise ValueError(
                    "fourth-version initial-state numerator differs from first-year hydrographs"
                )
            if not _artifact_float_matches(row["denominator"], denominator):
                raise ValueError(
                    "fourth-version initial-state denominator differs from six-year fit variance"
                )
            if not _artifact_float_matches(row["distance"], distance):
                raise ValueError("fourth-version initial-state distance differs from recomputation")
            if _strict_artifact_integer(
                row["fit_scale_count"],
                "fourth-version fit_scale_count",
                minimum=1,
            ) != int(fit_membership.sum()):
                raise ValueError("fourth-version fit scale count differs from six-year fit evidence")
            if _strict_artifact_integer(
                row["validation_compare_count"],
                "fourth-version validation_compare_count",
                minimum=1,
            ) != int(compare_membership.sum()):
                raise ValueError("fourth-version initial compare count differs from first water year")
            if row["transform"] != expected_transform:
                raise ValueError("fourth-version initial-state transform differs from the contract")
            if expected_offset is None:
                if not pd.isna(row["log_offset"]):
                    raise ValueError("fourth-version identity transform must not have a log offset")
            elif not _artifact_float_matches(row["log_offset"], expected_offset, tolerance=0.0):
                raise ValueError("fourth-version low-flow log offset differs from the contract")
            if not _artifact_float_matches(row["maximum_distance"], 0.03, tolerance=0.0):
                raise ValueError("fourth-version initial-state distance threshold differs")
            distance_pass = bool(distance <= 0.03)
            if _table_boolean(row["distance_pass"], "fourth-version distance pass") != distance_pass:
                raise ValueError("fourth-version initial-state distance pass differs")
            distance_passes.append(distance_pass)
        convergence_pass = bool(
            analytical_pass and replayed_pass and retained_matches and all(distance_passes)
        )
        if not all(
            _table_boolean(value, "fourth-version convergence pass") == convergence_pass
            for value in metric_group["initial_state_convergence_passes"]
        ):
            raise ValueError("fourth-version initial-state convergence summary differs")

        response_group = response_metrics[
            np.logical_and.reduce(
                [response_metrics[column] == value for column, value in zip(identity_columns, identity)]
            )
        ].copy()
        response_group["water_year"] = [
            _strict_artifact_integer(
                value,
                "fourth-version response water_year",
                minimum=1,
            )
            for value in response_group["water_year"]
        ]
        if (
            len(response_group) != 3
            or tuple(response_group["water_year"]) != expected_validation_years
            or response_group["water_year"].duplicated().any()
        ):
            raise ValueError(
                "fourth-version hydrograph response must contain three unique validation water years"
            )
        if not response_group["parameter_sha256"].astype(str).eq(fingerprint).all():
            raise ValueError("fourth-version hydrograph response fingerprint differs from restart")
        if not response_group["selected"].eq(selected).all():
            raise ValueError("fourth-version hydrograph response selected identity is inconsistent")
        validation_group = validation_records[identity]
        recomputed_response = hydrograph_response_diagnostics(
            validation_group["observed_flow_mm_day"].to_numpy(dtype=float),
            validation_group["simulated_flow_mm_day"].to_numpy(dtype=float),
            validation_date_index,
            mean_offset=0.01,
        )
        recomputed_by_year = {
            int(record["water_year"]): record for record in recomputed_response["water_years"]
        }
        for _, row in response_group.iterrows():
            expected = recomputed_by_year[int(row["water_year"])]
            for field, expected_value in expected.items():
                if isinstance(expected_value, bool):
                    if _table_boolean(
                        row[field],
                        f"fourth-version hydrograph response {field}",
                    ) != expected_value:
                        raise ValueError(
                            "fourth-version hydrograph response Boolean differs from daily evidence"
                        )
                elif isinstance(expected_value, int):
                    if _strict_artifact_integer(
                        row[field],
                        f"fourth-version hydrograph response {field}",
                        minimum=1,
                    ) != expected_value:
                        raise ValueError(
                            "fourth-version hydrograph response count differs from daily evidence"
                        )
                elif not _artifact_float_matches(row[field], float(expected_value)):
                    raise ValueError(
                        "fourth-version hydrograph response metric differs from daily evidence"
                    )


def verify_result_directory(
    output_directory: Path,
    *,
    allow_incomplete: bool = False,
) -> dict[str, Any]:
    """Independently recompute artifact hashes and bounded package fields."""

    output = Path(output_directory).resolve()
    if output.name.endswith(".incomplete") and not allow_incomplete:
        raise ValueError("public result verification refuses a .incomplete directory")
    actual_entries = {path.name for path in output.iterdir()} if output.is_dir() else set()
    missing = sorted(RESULT_FILENAMES - actual_entries)
    if missing or "source_snapshot" not in actual_entries:
        raise ValueError(f"result package is missing required artifacts: {missing}")
    recorded = json.loads((output / "checksums.json").read_text(encoding="utf-8"))
    if not isinstance(recorded, Mapping):
        raise ValueError("result package checksums must be a mapping")
    for relative_path, digest in recorded.items():
        relative = Path(str(relative_path))
        if (
            relative.is_absolute()
            or ".." in relative.parts
            or re.fullmatch(r"[0-9a-f]{64}", str(digest).lower()) is None
        ):
            raise ValueError("result package checksums contain an unsafe path or invalid digest")
    checksum_exclusions = (
        frozenset({"checksums.json", "run_manifest.json"})
        if (output / "run_manifest.json").is_file()
        else frozenset({"checksums.json"})
    )
    actual = _artifact_checksums(output, excluded_names=checksum_exclusions)
    if recorded != actual:
        differing = sorted(
            key for key in set(recorded) | set(actual) if recorded.get(key) != actual.get(key)
        )
        raise ValueError(f"result package checksum verification failed: {differing}")
    summary = json.loads((output / "summary.json").read_text(encoding="utf-8"))
    _validate_summary(summary)
    config = json.loads((output / "config_snapshot.json").read_text(encoding="utf-8"))
    if config.get("experiment_id") != summary.get("experiment_id"):
        raise ValueError("configuration and summary experiment identifiers differ")
    if config.get("classification") != summary.get("classification"):
        raise ValueError("configuration and summary classifications differ")
    if _is_v03_config(config):
        from camels_switch_confirmation.protocol_freeze import validate_config_binding

        validate_config_binding(REPO_ROOT, config)
        missing_v03 = sorted(
            filename
            for filename in (*V03_EVIDENCE_FILENAMES.values(), *V03_LIFECYCLE_FILENAMES)
            if filename not in actual_entries
        )
        if missing_v03:
            raise ValueError(f"third-version result package lacks restart evidence: {missing_v03}")
    if _is_v04_config(config):
        from camels_switch_confirmation.protocol_freeze_v04 import (
            validate_v04_registration_config,
        )

        validate_v04_registration_config(REPO_ROOT, config)
        missing_v04 = sorted(
            filename
            for filename in (
                *V03_EVIDENCE_FILENAMES.values(),
                *V03_LIFECYCLE_FILENAMES,
                *V04_DIAGNOSTIC_FILENAMES.values(),
                "parameter_domain_warmup_memory.json",
                "environment_capture.json",
            )
            if filename not in actual_entries
        )
        if missing_v04:
            raise ValueError(
                f"fourth-version result package lacks diagnostic evidence: {missing_v04}"
            )
    if _is_v05_config(config):
        from camels_switch_confirmation.protocol_freeze_v05 import (
            validate_v05_registration_config,
        )

        validate_v05_registration_config(REPO_ROOT, config)
        missing_v05 = sorted(
            filename
            for filename in (
                *V03_EVIDENCE_FILENAMES.values(),
                *V03_LIFECYCLE_FILENAMES,
                *V04_DIAGNOSTIC_FILENAMES.values(),
                "parameter_domain_warmup_memory.json",
                "environment_capture.json",
            )
            if filename not in actual_entries
        )
        if missing_v05:
            raise ValueError(
                f"fifth-version result package lacks diagnostic evidence: {missing_v05}"
            )
    classification = str(summary["classification"])
    _verify_source_snapshot(output, classification, config)
    manifest = pd.read_csv(output / "basin_manifest_snapshot.csv", dtype={"basin_id": str})
    basin_ids = _normalize_basin_ids(manifest["basin_id"].tolist(), "snapshot basin manifest")
    if list(summary.get("basin_ids", ())) != list(basin_ids):
        raise ValueError("summary basin identifiers differ from the manifest snapshot")
    expected_count = int(EXECUTION_PROFILES[str(summary["classification"])]["basin_count"])
    if len(basin_ids) != expected_count:
        raise ValueError("snapshot basin count differs from the execution profile")
    tables: dict[str, pd.DataFrame] = {}
    for filename in ("parameter_vectors.csv", "fit_metrics.csv", "validation_metrics.csv"):
        table = pd.read_csv(
            output / filename,
            dtype={"basin_id": str},
            float_precision="round_trip",
        )
        tables[filename] = table
        if table.empty:
            raise ValueError(f"{filename} must be nonempty")
        if "basin_id" not in table:
            raise ValueError(f"{filename} must contain basin_id")
        table_basins = set(table["basin_id"].astype(str).str.zfill(8))
        if table_basins != set(basin_ids):
            raise ValueError(f"{filename} basin set differs from the manifest snapshot")
        if filename == "parameter_vectors.csv":
            if "parameter_id" not in table:
                raise ValueError("parameter_vectors.csv must contain parameter_id")
            if len(table) != 3 * len(basin_ids):
                raise ValueError("parameter_vectors.csv has the wrong basin-parameter row count")
            if table.duplicated(["basin_id", "parameter_id"]).any():
                raise ValueError("parameter_vectors.csv contains duplicate basin-parameter rows")
            if set(table["parameter_id"]) != set(PARAMETER_IDS):
                raise ValueError("parameter_vectors.csv has the wrong parameter identifiers")
    if classification == "development_screen":
        expected_areas = _validate_development_screen_config(
            config,
            _active_periods(config),
            manifest,
        )
        vectors, validation_selected, validation_restarts = _verify_development_tables(
            config,
            basin_ids,
            tables,
        )
        _verify_development_summary(
            summary,
            config,
            basin_ids,
            vectors,
            validation_selected,
            validation_restarts,
            expected_areas,
        )
        if _uses_restart_evidence(config):
            restart_tables = {
                key: pd.read_csv(
                    output / filename,
                    dtype={"basin_id": str},
                    float_precision="round_trip",
                )
                for key, filename in V03_EVIDENCE_FILENAMES.items()
            }
            periods = _active_periods(config)
            quality_config = config["parameter_quality_gates"]
            _verify_v03_restart_evidence(
                restart_tables,
                expected_restart_seeds=tuple(
                    int(seed) for seed in config["optimizer"]["restart_seeds"]
                ),
                fit_dates=pd.date_range(*periods["fit"], freq="D"),
                validation_dates=pd.date_range(*periods["validation"], freq="D"),
                maximum_distance=float(
                    quality_config["support_output_functional_distance_max"]
                ),
                fit_loss_ratio_max=float(quality_config["support_fit_loss_ratio_max"]),
                parameter_bounds=resolve_hbv_bounds(
                    str(config["parameter_bounds_preset"])
                ),
                expected_basin_ids=basin_ids,
                validation_metrics=(
                    tables["validation_metrics.csv"] if _is_v03_config(config) else None
                ),
                summary=summary if _is_v03_config(config) else None,
            )
        if _uses_initialization_response_diagnostics(config):
            v04_tables = {
                key: pd.read_csv(
                    output / filename,
                    dtype={"basin_id": str},
                    float_precision="round_trip",
                )
                for key, filename in V04_DIAGNOSTIC_FILENAMES.items()
            }
            _verify_v04_diagnostic_evidence(
                v04_tables,
                restart_tables,
                expected_restart_seeds=tuple(
                    int(seed) for seed in config["optimizer"]["restart_seeds"]
                ),
                fit_dates=pd.date_range(*periods["fit"], freq="D"),
                validation_dates=pd.date_range(*periods["validation"], freq="D"),
                expected_basin_ids=basin_ids,
            )
        if _uses_restart_evidence(config):
            restart_execution = pd.read_csv(
                output / "restart_execution.csv",
                dtype={"basin_id": str},
                float_precision="round_trip",
                keep_default_na=False,
            )
            selected_fingerprints = _verify_v03_restart_execution_links(
                restart_execution,
                restart_tables["restart_parameter_vectors"],
                basin_ids,
            )
            run_instance_values = set(restart_execution["run_instance_id"].astype(str))
            run_instance_id = next(iter(run_instance_values))
            credential_path = (
                REPO_ROOT / str(config["protocol_credential"])
            ).resolve()
            evidence_arguments = {
                "expected_experiment_id": str(config["experiment_id"]),
                "expected_run_instance_id": run_instance_id,
                "expected_config_sha256": _sha256(output / "config_snapshot.json"),
                "expected_selected_parameter_fingerprints": selected_fingerprints,
            }
            execution_evidence = _execution_evidence_for(config)
            if execution_evidence is not None:
                execution_evidence.verify_execution_evidence(
                    output,
                    credential_path,
                    repo_root=REPO_ROOT,
                    **evidence_arguments,
                )
            else:
                v03_execution_evidence.verify_execution_evidence(
                    output,
                    credential_path,
                    **evidence_arguments,
                )
        hydrograph_path = output / HYDROGRAPH_FILENAME
        if config.get("target_state_coverage_policy") is not None:
            if not hydrograph_path.is_file():
                raise ValueError("second-version result package lacks validation hydrograph evidence")
            hydrographs = pd.read_csv(hydrograph_path, dtype={"basin_id": str})
            _verify_validation_hydrographs(
                hydrographs,
                basin_ids,
                _active_periods(config)["validation"],
            )
        elif hydrograph_path.exists():
            raise ValueError("first-version result package must not contain second-version hydrographs")
    return summary


def _seal_v03_success_package(
    contract: AccessContract,
    temporary: Path,
    restart_execution: pd.DataFrame,
    lifecycle: Mapping[str, Any],
    *,
    artifacts_written_at: str | None = None,
    artifact_verification_completed_at: str | None = None,
    run_completed_at: str | None = None,
) -> dict[str, Any]:
    """Seal one self-consistent package generation for independent verification."""

    events, terminal = _v03_success_events(
        contract,
        restart_execution,
        lifecycle,
        artifacts_written_at=artifacts_written_at,
        artifact_verification_completed_at=artifact_verification_completed_at,
        run_completed_at=run_completed_at,
    )
    _write_json_lines(temporary / "run_events.jsonl", events)
    _write_json(
        temporary / "checksums.json",
        _artifact_checksums(
            temporary,
            excluded_names=frozenset({"checksums.json", "run_manifest.json"}),
        ),
    )
    artifact_hashes = _artifact_checksums(
        temporary,
        excluded_names=frozenset({"run_manifest.json"}),
    )
    manifest = _v03_run_manifest(
        contract,
        temporary,
        restart_execution,
        lifecycle,
        terminal,
        artifact_hashes,
    )
    _write_json(temporary / "run_manifest.json", manifest)
    return terminal


def _v03_preseal_hashes(directory: Path) -> dict[str, str]:
    """Hash all immutable substantive artifacts, excluding only final seal files."""

    return _artifact_checksums(
        directory,
        excluded_names=frozenset(
            {"run_events.jsonl", "checksums.json", "run_manifest.json"}
        ),
    )


def _verify_v03_success_preseal(
    contract: AccessContract,
    temporary: Path,
    restart_execution: pd.DataFrame,
    lifecycle: Mapping[str, Any],
) -> dict[str, Any]:
    """Verify a disposable full seal, then bind unchanged substantive bytes."""

    substantive_hashes = _v03_preseal_hashes(temporary)
    preseal = temporary.parent / f".v03-preseal-{uuid.uuid4().hex[:12]}"
    if preseal.exists() or preseal.is_symlink():
        raise FileExistsError("v03 preseal verification directory already exists")
    provisional_terminal: dict[str, Any] | None = None
    try:
        shutil.copytree(temporary, preseal)
        provisional_terminal = _seal_v03_success_package(
            contract,
            preseal,
            restart_execution,
            lifecycle,
        )
        verify_result_directory(preseal, allow_incomplete=True)
        verified_at = _zoned_now()
        if _v03_preseal_hashes(preseal) != substantive_hashes:
            raise ValueError("v03 preseal verification changed substantive artifacts")
    finally:
        if preseal.exists():
            resolved = preseal.resolve()
            if resolved.parent != temporary.parent.resolve() or preseal.is_symlink():
                raise ValueError("v03 preseal cleanup target is unsafe")
            shutil.rmtree(preseal)
    if provisional_terminal is None:
        raise ValueError("v03 preseal verification did not produce a terminal receipt")
    if _v03_preseal_hashes(temporary) != substantive_hashes:
        raise ValueError("v03 substantive artifacts changed after preseal verification")
    return {
        "artifacts_written_at": str(provisional_terminal["artifacts_written"]),
        "artifact_verification_completed_at": verified_at,
        "substantive_hashes": substantive_hashes,
    }


def _write_result_package(
    contract: AccessContract,
    execution: Mapping[str, Any],
    basin_areas_km2: Mapping[str, float],
    *,
    lifecycle: Mapping[str, Any] | None = None,
) -> None:
    temporary = contract.incomplete_directory
    temporary.mkdir(parents=True)
    _write_json(temporary / "config_snapshot.json", contract.config)
    shutil.copy2(contract.manifest_path, temporary / "basin_manifest_snapshot.csv")
    table_files = [
        ("parameter_vectors", "parameter_vectors.csv"),
        ("fit_metrics", "fit_metrics.csv"),
        ("validation_metrics", "validation_metrics.csv"),
    ]
    if contract.config.get("target_state_coverage_policy") is not None:
        table_files.append(("validation_hydrographs", HYDROGRAPH_FILENAME))
    if _uses_restart_evidence(contract.config):
        table_files.extend(V03_EVIDENCE_FILENAMES.items())
    if _uses_initialization_response_diagnostics(contract.config):
        table_files.extend(V04_DIAGNOSTIC_FILENAMES.items())
    if _uses_restart_evidence(contract.config):
        table_files.append(("restart_execution", "restart_execution.csv"))
    restart_execution_written: pd.DataFrame | None = None
    for key, filename in table_files:
        table = execution.get(key)
        if not isinstance(table, pd.DataFrame) or table.empty:
            raise ValueError(f"execution result {key} must be a nonempty DataFrame")
        written = table.copy()
        if "basin_id" not in written:
            if len(contract.basin_ids) != 1:
                raise ValueError(f"execution result {key} lacks basin_id for a multi-basin run")
            written.insert(0, "basin_id", contract.basin_ids[0])
        written["basin_id"] = written["basin_id"].astype(str).str.zfill(8)
        if key == "restart_execution":
            if lifecycle is None or "run_instance_id" not in lifecycle:
                raise ValueError("v03 result writing requires a run instance identifier")
            if "run_instance_id" in written:
                raise ValueError("v03 local restart execution already contains run_instance_id")
            written.insert(0, "run_instance_id", str(lifecycle["run_instance_id"]))
            if tuple(written.columns) != V03_RESTART_EXECUTION_COLUMNS:
                raise ValueError("v03 restart execution columns or order differ from the contract")
            restart_execution_written = written.copy()
            _write_v03_restart_execution_csv(temporary / filename, written)
        else:
            written.to_csv(temporary / filename, index=False)
    summary = {
        "experiment_id": contract.config["experiment_id"],
        "classification": contract.profile_name,
        "technical_status": "completed",
        "interpretation": contract.profile["scope"],
        "basin_ids": list(contract.basin_ids),
        "load_window": {
            "start": str(contract.periods["warmup"][0]),
            "end": str(contract.periods["validation"][1]),
        },
        **dict(execution.get("run_summary", {})),
    }
    if contract.profile_name == "development_smoke":
        summary["basin_area_km2"] = float(basin_areas_km2[contract.basin_ids[0]])
    _validate_summary(summary)
    _write_json(temporary / "summary.json", summary)
    if _uses_initialization_response_diagnostics(contract.config):
        if lifecycle is None:
            raise ValueError(
                "initialization-response result writing requires cached lifecycle evidence"
            )
        _write_initialization_response_parameter_domain_evidence(contract, temporary)
        _write_initialization_response_cached_environment(
            contract,
            temporary,
            lifecycle,
            allow_incomplete_python_inventory=False,
        )
    else:
        _write_json(temporary / "environment.json", _environment_record())
    (temporary / "git_status.txt").write_text(_git_status(REPO_ROOT), encoding="utf-8")
    _copy_source_snapshot(contract, temporary / "source_snapshot")
    if _uses_restart_evidence(contract.config):
        if lifecycle is None or restart_execution_written is None:
            raise ValueError("versioned lifecycle or restart execution evidence is missing")
        if not _uses_initialization_response_diagnostics(contract.config):
            environment_outputs = v03_execution_evidence.capture_environment_command_outputs()
            for filename in ("python_packages.txt", "conda_explicit.txt"):
                (temporary / filename).write_text(
                    environment_outputs[filename],
                    encoding="utf-8",
                )
        stdout_text = _v03_captured_stream_text(lifecycle, "stdout")
        stderr_text = _v03_captured_stream_text(lifecycle, "stderr")
        (temporary / "stdout.log").write_text(stdout_text, encoding="utf-8")
        (temporary / "stderr.log").write_text(stderr_text, encoding="utf-8")
        receipt = _verify_v03_success_preseal(
            contract,
            temporary,
            restart_execution_written,
            lifecycle,
        )
        _seal_v03_success_package(
            contract,
            temporary,
            restart_execution_written,
            lifecycle,
            artifacts_written_at=str(receipt["artifacts_written_at"]),
            artifact_verification_completed_at=str(
                receipt["artifact_verification_completed_at"]
            ),
            run_completed_at=_zoned_now(),
        )
    else:
        _write_json(temporary / "checksums.json", _artifact_checksums(temporary))
    verify_result_directory(temporary, allow_incomplete=True)
    if _uses_restart_evidence(contract.config) and lifecycle is not None:
        if (
            _v03_captured_stream_text(lifecycle, "stdout") != stdout_text
            or _v03_captured_stream_text(lifecycle, "stderr") != stderr_text
        ):
            raise ValueError("v03 standard streams changed after their sealed capture")


def run_real_regime_parameter_calibration(
    repo_root: Path,
    config_path: str | Path,
) -> Path:
    """Run one frozen development profile without reusing its identifier."""

    contract = validate_access_contract(repo_root, config_path)
    _preflight_immutability(contract)
    lifecycle: dict[str, Any] | None = None
    regime_preflights: dict[str, Mapping[str, Any]] = {}
    telemetry_by_basin: dict[str, Mapping[str, list[dict[str, Any]]]] = {}
    preflight_coverage_payload: Mapping[str, Any] | None = None
    if _uses_restart_evidence(contract.config):
        monotonic_started = time.perf_counter()
        run_started = _zoned_now()
        stdout_capture = io.StringIO()
        stderr_capture = io.StringIO()
        lifecycle = {
            "run_instance_id": _new_run_instance_id(run_started),
            "run_started": run_started,
            "config_verified": _zoned_now(),
            "monotonic_started": monotonic_started,
            "stdout_capture": stdout_capture,
            "stderr_capture": stderr_capture,
        }
    _transition_registry(contract, "registered_not_run", "running")
    stream_capture = ExitStack()
    if lifecycle is not None:
        stream_capture.enter_context(redirect_stdout(lifecycle["stdout_capture"]))
        stream_capture.enter_context(redirect_stderr(lifecycle["stderr_capture"]))
    try:
        if lifecycle is not None:
            lifecycle["active_phase"] = (
                "environment_capture"
                if _uses_initialization_response_diagnostics(contract.config)
                else "input_loading"
            )
        if _uses_initialization_response_diagnostics(contract.config):
            if lifecycle is None:
                raise ValueError(
                    "initialization-response execution requires lifecycle evidence"
                )
            environment_inventory = v03_execution_evidence.capture_environment_inventory()
            lifecycle["environment_inventory"] = environment_inventory
            lifecycle["environment_record"] = _environment_record()
            execution_evidence = _execution_evidence_for(contract.config)
            if execution_evidence is None:
                raise ValueError("initialization-response execution evidence is unavailable")
            if not execution_evidence.cached_environment_capture_complete(
                environment_inventory,
                lifecycle["environment_record"],
            ):
                raise ValueError(
                    "Python package inventory primary and fallback are both unavailable"
                )
            lifecycle["active_phase"] = "input_loading"
        contract.results_root.mkdir(parents=True, exist_ok=True)
        start = str(contract.periods["warmup"][0])
        end = str(contract.periods["validation"][1])
        if start <= str(FORBIDDEN_END) and end >= str(FORBIDDEN_START):
            raise ValueError("requested loader window overlaps the forbidden candidate holdout")
        data_root = _resolve_path(Path(repo_root).resolve(), contract.config["data_root"], "data_root")
        loaded_basins: list[tuple[str, pd.DataFrame, pd.Series, float]] = []
        for basin_id in contract.basin_ids:
            forcing, observations, area_km2 = load_camels_basin(
                basin_id,
                data_root=data_root,
                start_date=start,
                end_date=end,
                forcing=str(contract.config["forcing"]),
                pet_method=str(contract.config["pet_method"]),
                keep_obs_nan_days=True,
                strict_streamflow_window=bool(contract.profile["strict_streamflow_window"]),
            )
            forcing, observations = _validate_loaded_basin(
                basin_id,
                forcing,
                observations,
                area_km2,
                contract,
            )
            loaded_basins.append((basin_id, forcing, observations, float(area_km2)))
        if lifecycle is not None:
            lifecycle["inputs_verified"] = _zoned_now()
            lifecycle["active_phase"] = "preflight"

        if contract.profile_name == "development_screen":
            for basin_id, forcing, observations, _ in loaded_basins:
                regime_preflights[basin_id] = _flow_regime_preflight(
                    forcing,
                    observations,
                    contract.config,
                )
            all_coverage = {
                basin_id: _compact_coverage_counts(preflight["coverage"])
                for basin_id, preflight in regime_preflights.items()
            }
            fit_only_flow_thresholds = {
                basin_id: _json_ready(preflight["thresholds"])
                for basin_id, preflight in regime_preflights.items()
            }
            if not all(
                bool(period.get("evidence_sufficient"))
                for preflight in regime_preflights.values()
                for period in preflight["coverage"].values()
            ):
                coverage_payload = {
                    "columns": [
                        "water_year",
                        "low_flow_days",
                        "high_flow_days",
                        "evidence_sufficient",
                    ],
                    "basins": all_coverage,
                    "fit_only_flow_thresholds": fit_only_flow_thresholds,
                }
                preflight_coverage_payload = coverage_payload
                compact = json.dumps(
                    coverage_payload,
                    sort_keys=True,
                    separators=(",", ":"),
                )
                error_message = (
                    "development-screen water-year evidence is insufficient before any optimization: "
                    + compact
                )
                if lifecycle is None:
                    _write_preflight_failure_audit(
                        contract,
                        coverage_payload,
                        error_message,
                    )
                raise ValueError(error_message)
        if lifecycle is not None:
            lifecycle["preflight_completed"] = _zoned_now()
            lifecycle["active_phase"] = "optimizer_execution"

        basin_results = []
        for basin_id, forcing, observations, area_km2 in loaded_basins:
            telemetry_collectors = (
                {parameter_id: [] for parameter_id in PARAMETER_IDS}
                if lifecycle is not None
                else None
            )
            if telemetry_collectors is not None:
                telemetry_by_basin[basin_id] = telemetry_collectors
            execution = _execute_calibration(
                forcing,
                observations,
                contract.config,
                regime_preflights.get(basin_id),
                telemetry_collectors=telemetry_collectors,
            )
            basin_results.append((basin_id, execution, float(area_km2)))
        if len(basin_results) != int(contract.profile["basin_count"]):
            raise ValueError("completed basin count differs from the execution profile")
        if lifecycle is not None:
            lifecycle["active_phase"] = "postprocessing"
        basin_areas = {basin_id: area for basin_id, _, area in basin_results}
        if contract.profile_name == "development_screen":
            packaged_execution = _combine_development_screen_results(contract, basin_results)
        else:
            packaged_execution = basin_results[0][1]
        if lifecycle is not None:
            print(contract.output_directory)
            lifecycle["active_phase"] = "artifact_packaging"
        _write_result_package(
            contract,
            packaged_execution,
            basin_areas,
            lifecycle=lifecycle,
        )
        if lifecycle is not None:
            lifecycle["active_phase"] = "result_publication"
        os.replace(contract.incomplete_directory, contract.output_directory)
        try:
            if lifecycle is not None:
                lifecycle["active_phase"] = "registry_terminal_update"
            _transition_registry(contract, "running", str(contract.profile["terminal_status"]))
        except Exception:
            # A final directory must never survive without its matching
            # terminal registry update. Move it back to the recoverable
            # incomplete path before the outer failure transition runs.
            if contract.output_directory.exists() and not contract.incomplete_directory.exists():
                os.replace(contract.output_directory, contract.incomplete_directory)
            raise
    except Exception as error:
        if lifecycle is not None:
            lifecycle["failure_detected_at"] = _zoned_now()
            lifecycle["failure_monotonic_elapsed_seconds"] = float(
                time.perf_counter() - float(lifecycle["monotonic_started"])
            )
        if lifecycle is not None:
            try:
                partial_execution = _partial_v03_restart_execution_table(
                    contract,
                    telemetry_by_basin,
                    regime_preflights,
                    lifecycle["run_instance_id"],
                )
                _write_v03_failure_package(
                    contract,
                    partial_execution,
                    telemetry_by_basin,
                    lifecycle,
                    error,
                    failure_phase=str(lifecycle.get("active_phase", "run_execution")),
                    coverage_payload=preflight_coverage_payload,
                    reuse_existing=contract.incomplete_directory.exists(),
                )
            except Exception as evidence_error:
                error.add_note(f"v03 failure-evidence error: {evidence_error}")
        try:
            _transition_registry(
                contract,
                "running",
                "failed",
                f"{type(error).__name__}: {error}",
            )
        except Exception as registry_error:  # pragma: no cover - dual failure is platform-specific
            error.add_note(f"registry failure: {registry_error}")
        raise
    finally:
        stream_capture.close()
    return contract.output_directory


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the protected development-only real-flow-regime calibration smoke."
    )
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    return parser.parse_args()


def main() -> None:
    args = _parse_args()
    output = run_real_regime_parameter_calibration(REPO_ROOT, args.config)
    print(output)


if __name__ == "__main__":
    main()
