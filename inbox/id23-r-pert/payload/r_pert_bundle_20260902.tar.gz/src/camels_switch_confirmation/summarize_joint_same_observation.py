"""Summarize the registered same-observation continuous and replay evidence."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from camels_switch_confirmation.joint_same_observation import (
    load_registered_configs,
)
from camels_switch_confirmation.run_joint_same_observation import (
    ARM_MODES,
    KNOWLEDGE_MODES,
    REPO_ROOT,
    TaskIdentity,
    admitted_basins,
    build_task_table,
    task_output_path,
)


AXIS_MAJORITY_MIN = 0.50
AXIS_CHANCE = 1.0 / 3.0
ABOVE_CHANCE_FRACTION_MIN = 0.90
NONINFERIORITY_MARGIN = -0.10
CELL_CHANCE = 1.0 / 9.0
CELL_ARGMAX_MIN = 0.50


def axis_marginals(
    probabilities,
    candidate_param_indices,
    candidate_noise_indices,
) -> tuple[np.ndarray, np.ndarray]:
    """Map day-specific candidate coordinates to three-level marginals."""

    values = np.asarray(probabilities, dtype=np.float64)
    param_coordinates = np.asarray(candidate_param_indices, dtype=np.int64)
    noise_coordinates = np.asarray(candidate_noise_indices, dtype=np.int64)
    if values.ndim != 2:
        raise ValueError("probabilities must have shape (day, candidate)")
    if param_coordinates.shape != values.shape or noise_coordinates.shape != values.shape:
        raise ValueError("candidate coordinate arrays must match probabilities")
    param = np.zeros((len(values), 3), dtype=np.float64)
    noise = np.zeros_like(param)
    for level in range(3):
        param[:, level] = np.sum(
            np.where(param_coordinates == level, values, 0.0), axis=1
        )
        noise[:, level] = np.sum(
            np.where(noise_coordinates == level, values, 0.0), axis=1
        )
    if not np.allclose(param.sum(axis=1), 1.0, rtol=0.0, atol=1e-12):
        raise ValueError("parameter marginals do not sum to one")
    if not np.allclose(noise.sum(axis=1), 1.0, rtol=0.0, atol=1e-12):
        raise ValueError("process-noise marginals do not sum to one")
    return param, noise


def _masked_logsumexp(log_values, mask) -> np.ndarray:
    selected = np.where(mask, np.asarray(log_values, dtype=np.float64), -np.inf)
    maxima = np.max(selected, axis=1)
    result = np.full(len(selected), -np.inf, dtype=np.float64)
    finite = np.isfinite(maxima)
    if np.any(finite):
        shifted = selected[finite] - maxima[finite, None]
        result[finite] = maxima[finite] + np.log(
            np.sum(np.exp(shifted), axis=1)
        )
    return result


def log_axis_marginals(
    log_probabilities,
    candidate_param_indices,
    candidate_noise_indices,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute stable three-level log marginals from saved candidate logs."""

    values = np.asarray(log_probabilities, dtype=np.float64)
    param_coordinates = np.asarray(candidate_param_indices, dtype=np.int64)
    noise_coordinates = np.asarray(candidate_noise_indices, dtype=np.int64)
    if values.ndim != 2:
        raise ValueError("log probabilities must have shape (day, candidate)")
    if param_coordinates.shape != values.shape or noise_coordinates.shape != values.shape:
        raise ValueError("candidate coordinate arrays must match log probabilities")
    param = np.empty((len(values), 3), dtype=np.float64)
    noise = np.empty_like(param)
    for level in range(3):
        param[:, level] = _masked_logsumexp(
            values, param_coordinates == level
        )
        noise[:, level] = _masked_logsumexp(
            values, noise_coordinates == level
        )
    return param, noise


def _true_cell_probabilities(arrays) -> np.ndarray:
    probabilities = np.asarray(arrays["probabilities"], dtype=np.float64)
    param_coordinates = np.asarray(arrays["candidate_param_indices"], dtype=np.int64)
    noise_coordinates = np.asarray(arrays["candidate_noise_indices"], dtype=np.int64)
    truth_param = np.asarray(arrays["truth_param_indices"], dtype=np.int64)
    truth_noise = np.asarray(arrays["truth_noise_indices"], dtype=np.int64)
    mask = (
        (param_coordinates == truth_param[:, None])
        & (noise_coordinates == truth_noise[:, None])
    )
    if not np.all(mask.sum(axis=1) == 1):
        raise ValueError("each day must contain exactly one true candidate coordinate")
    return np.sum(np.where(mask, probabilities, 0.0), axis=1)


def _true_cell_log_probabilities(arrays) -> np.ndarray:
    log_probabilities = np.asarray(arrays["log_probabilities"], dtype=np.float64)
    param_coordinates = np.asarray(arrays["candidate_param_indices"], dtype=np.int64)
    noise_coordinates = np.asarray(arrays["candidate_noise_indices"], dtype=np.int64)
    truth_param = np.asarray(arrays["truth_param_indices"], dtype=np.int64)
    truth_noise = np.asarray(arrays["truth_noise_indices"], dtype=np.int64)
    mask = (
        (param_coordinates == truth_param[:, None])
        & (noise_coordinates == truth_noise[:, None])
    )
    if not np.all(mask.sum(axis=1) == 1):
        raise ValueError("each day must contain exactly one true candidate coordinate")
    return np.sum(np.where(mask, log_probabilities, 0.0), axis=1)


def _argmax_coordinates(arrays) -> tuple[np.ndarray, np.ndarray]:
    probabilities = np.asarray(arrays["probabilities"], dtype=np.float64)
    winners = np.argmax(probabilities, axis=1)
    days = np.arange(len(probabilities))
    return (
        np.asarray(arrays["candidate_param_indices"])[days, winners],
        np.asarray(arrays["candidate_noise_indices"])[days, winners],
    )


def classification_error_fractions(
    winner_param,
    winner_noise,
    truth_param,
    truth_noise,
    days,
) -> dict:
    """Partition decisions into correct, one-axis wrong, and two-axis wrong."""

    selected = np.asarray(days, dtype=np.int64)
    parameter_wrong = (
        np.asarray(winner_param, dtype=np.int64)[selected]
        != np.asarray(truth_param, dtype=np.int64)[selected]
    )
    noise_wrong = (
        np.asarray(winner_noise, dtype=np.int64)[selected]
        != np.asarray(truth_noise, dtype=np.int64)[selected]
    )
    if len(selected) == 0:
        raise ValueError("classification window is empty")
    return {
        "correct_fraction": float(np.mean(~parameter_wrong & ~noise_wrong)),
        "param_only_wrong_fraction": float(np.mean(parameter_wrong & ~noise_wrong)),
        "noise_only_wrong_fraction": float(np.mean(~parameter_wrong & noise_wrong)),
        "both_wrong_fraction": float(np.mean(parameter_wrong & noise_wrong)),
    }


def _state_metrics(estimated, truth) -> dict:
    estimated_values = np.asarray(estimated, dtype=np.float64)
    truth_values = np.asarray(truth, dtype=np.float64)
    if estimated_values.shape != truth_values.shape or estimated_values.ndim != 2:
        raise ValueError("estimated and truth states must be equal day-by-state arrays")
    error = estimated_values - truth_values
    rmse = np.sqrt(np.mean(error**2, axis=0))
    median_absolute_error = np.median(np.abs(error), axis=0)
    scales = np.maximum(np.std(truth_values, axis=0), 1.0)
    normalized_rmse = rmse / scales
    return {
        "rmse": rmse.tolist(),
        "median_absolute_error": median_absolute_error.tolist(),
        "normalization_scales": scales.tolist(),
        "normalized_rmse": normalized_rmse.tolist(),
        "mean_normalized_rmse": float(np.mean(normalized_rmse)),
    }


def summarize_continuous_task(
    arrays,
    basin_id,
    seed,
    arm_id,
    knowledge_mode,
    scoring_start_day,
) -> dict:
    """Compute one task's registered continuous metrics."""

    probabilities = np.asarray(arrays["probabilities"], dtype=np.float64)
    scoring = np.arange(int(scoring_start_day), len(probabilities), dtype=np.int64)
    if len(scoring) == 0:
        raise ValueError("continuous scoring window is empty")
    param, noise = axis_marginals(
        probabilities,
        arrays["candidate_param_indices"],
        arrays["candidate_noise_indices"],
    )
    log_param, log_noise = log_axis_marginals(
        arrays["log_probabilities"],
        arrays["candidate_param_indices"],
        arrays["candidate_noise_indices"],
    )
    truth_param = np.asarray(arrays["truth_param_indices"], dtype=np.int64)
    truth_noise = np.asarray(arrays["truth_noise_indices"], dtype=np.int64)
    param_true = param[np.arange(len(param)), truth_param]
    noise_true = noise[np.arange(len(noise)), truth_noise]
    param_true_log = log_param[np.arange(len(log_param)), truth_param]
    noise_true_log = log_noise[np.arange(len(log_noise)), truth_noise]
    axis_levels = {"param": {}, "noise": {}}
    for axis, truth, values, log_values, marginal in (
        ("param", truth_param, param_true, param_true_log, param),
        ("noise", truth_noise, noise_true, noise_true_log, noise),
    ):
        for level in range(3):
            days = scoring[truth[scoring] == level]
            if len(days) == 0:
                axis_levels[axis][level] = {
                    "n_days": 0,
                    "mean_true_probability": float("nan"),
                    "mean_true_log_probability": float("nan"),
                    "argmax_accuracy": float("nan"),
                }
            else:
                axis_levels[axis][level] = {
                    "n_days": int(len(days)),
                    "mean_true_probability": float(np.mean(values[days])),
                    "mean_true_log_probability": float(
                        np.mean(log_values[days])
                    ),
                    "argmax_accuracy": float(
                        np.mean(np.argmax(marginal[days], axis=1) == level)
                    ),
                }
    cell_true = _true_cell_probabilities(arrays)
    cell_true_log = _true_cell_log_probabilities(arrays)
    winner_param, winner_noise = _argmax_coordinates(arrays)
    cell_correct = (winner_param == truth_param) & (winner_noise == truth_noise)
    state = _state_metrics(
        np.asarray(arrays["combined_states"])[scoring],
        np.asarray(arrays["truth_post_states"])[scoring],
    )
    return {
        "basin_id": str(basin_id),
        "seed": int(seed),
        "arm_id": str(arm_id),
        "knowledge_mode": str(knowledge_mode),
        "axis_levels": axis_levels,
        "cell": {
            "mean_true_probability": float(np.mean(cell_true[scoring])),
            "mean_true_log_probability": float(
                np.mean(cell_true_log[scoring])
            ),
            "argmax_accuracy": float(np.mean(cell_correct[scoring])),
        },
        "classification": classification_error_fractions(
            winner_param,
            winner_noise,
            truth_param,
            truth_noise,
            scoring,
        ),
        "state": state,
    }


def task_summary_frames(summaries) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    task_rows, axis_rows, state_rows = [], [], []
    for summary in summaries:
        identity = {
            key: summary[key]
            for key in ("basin_id", "seed", "arm_id", "knowledge_mode")
        }
        task_rows.append({
            **identity,
            "cell_mean_true_probability": summary["cell"]["mean_true_probability"],
            "cell_mean_true_log_probability": summary["cell"][
                "mean_true_log_probability"
            ],
            "cell_argmax_accuracy": summary["cell"]["argmax_accuracy"],
            **summary["classification"],
            "state_mean_normalized_rmse": summary["state"]["mean_normalized_rmse"],
        })
        for axis in ("param", "noise"):
            for level in range(3):
                axis_rows.append({
                    **identity,
                    "axis": axis,
                    "level": level,
                    **summary["axis_levels"][axis][level],
                })
        for state_index in range(15):
            state_rows.append({
                **identity,
                "state_index": state_index,
                "rmse": summary["state"]["rmse"][state_index],
                "median_absolute_error": summary["state"]["median_absolute_error"][state_index],
                "normalization_scale": summary["state"]["normalization_scales"][state_index],
                "normalized_rmse": summary["state"]["normalized_rmse"][state_index],
            })
    return pd.DataFrame(task_rows), pd.DataFrame(axis_rows), pd.DataFrame(state_rows)


def _transition_kind(source, destination) -> str:
    parameter_moved = int(source[0]) != int(destination[0])
    noise_moved = int(source[1]) != int(destination[1])
    if parameter_moved and noise_moved:
        return "both"
    if parameter_moved:
        return "param_only"
    if noise_moved:
        return "noise_only"
    raise ValueError("registered replay event does not change either axis")


def summarize_replay_task(
    arrays,
    basin_id,
    seed,
    arm_id,
    knowledge_mode,
    report_windows,
) -> list[dict]:
    """Compute event-window metrics for one independently reset task."""

    rows = []
    event_count, replay_days, _ = np.asarray(arrays["probabilities"]).shape
    for event_index in range(event_count):
        source = np.asarray(arrays["source_cells"])[event_index]
        destination = np.asarray(arrays["destination_cells"])[event_index]
        event_arrays = {
            "probabilities": np.asarray(arrays["probabilities"])[event_index],
            "candidate_param_indices": np.asarray(
                arrays["candidate_param_indices"]
            )[event_index],
            "candidate_noise_indices": np.asarray(
                arrays["candidate_noise_indices"]
            )[event_index],
        }
        param, noise = axis_marginals(
            event_arrays["probabilities"],
            event_arrays["candidate_param_indices"],
            event_arrays["candidate_noise_indices"],
        )
        log_param, log_noise = log_axis_marginals(
            np.asarray(arrays["log_probabilities"])[event_index],
            event_arrays["candidate_param_indices"],
            event_arrays["candidate_noise_indices"],
        )
        truth_param = np.full(replay_days, int(destination[0]), dtype=np.int64)
        truth_noise = np.full(replay_days, int(destination[1]), dtype=np.int64)
        cell_arrays = {
            **event_arrays,
            "log_probabilities": np.asarray(
                arrays["log_probabilities"]
            )[event_index],
            "truth_param_indices": truth_param,
            "truth_noise_indices": truth_noise,
        }
        cell_true = _true_cell_probabilities(cell_arrays)
        cell_true_log = _true_cell_log_probabilities(cell_arrays)
        winner_param, winner_noise = _argmax_coordinates(cell_arrays)
        for window in report_windows:
            width = int(window)
            if width <= 0 or width > replay_days:
                raise ValueError(f"replay report window is invalid: {width}")
            days = np.arange(width)
            state = _state_metrics(
                np.asarray(arrays["combined_states"])[event_index, days],
                np.asarray(arrays["truth_post_states"])[event_index, days],
            )
            classification = classification_error_fractions(
                winner_param,
                winner_noise,
                truth_param,
                truth_noise,
                days,
            )
            rows.append({
                "basin_id": str(basin_id),
                "seed": int(seed),
                "arm_id": str(arm_id),
                "knowledge_mode": str(knowledge_mode),
                "event_index": event_index,
                "switch_day": int(np.asarray(arrays["switch_days"])[event_index]),
                "transition_kind": _transition_kind(source, destination),
                "source_param": int(source[0]),
                "source_noise": int(source[1]),
                "destination_param": int(destination[0]),
                "destination_noise": int(destination[1]),
                "window_days": width,
                "param_mean_true_probability": float(
                    np.mean(param[days, int(destination[0])])
                ),
                "param_mean_true_log_probability": float(
                    np.mean(log_param[days, int(destination[0])])
                ),
                "noise_mean_true_probability": float(
                    np.mean(noise[days, int(destination[1])])
                ),
                "noise_mean_true_log_probability": float(
                    np.mean(log_noise[days, int(destination[1])])
                ),
                "cell_mean_true_probability": float(np.mean(cell_true[days])),
                "cell_mean_true_log_probability": float(
                    np.mean(cell_true_log[days])
                ),
                "param_argmax_accuracy": float(
                    np.mean(np.argmax(param[days], axis=1) == int(destination[0]))
                ),
                "noise_argmax_accuracy": float(
                    np.mean(np.argmax(noise[days], axis=1) == int(destination[1]))
                ),
                "cell_argmax_accuracy": float(
                    np.mean(
                        (winner_param[days] == int(destination[0]))
                        & (winner_noise[days] == int(destination[1]))
                    )
                ),
                **classification,
                "state_mean_normalized_rmse": state["mean_normalized_rmse"],
            })
    return rows


def propagation_rows(
    continuous,
    replay,
    basin_id,
    seed,
    arm_id,
    knowledge_mode,
    report_windows,
) -> list[dict]:
    """Compare continuous and reset errors on identical event calendar days."""

    continuous_param, continuous_noise = axis_marginals(
        continuous["probabilities"],
        continuous["candidate_param_indices"],
        continuous["candidate_noise_indices"],
    )
    continuous_cell = _true_cell_probabilities(continuous)
    rows = []
    for event_index, switch_day in enumerate(np.asarray(replay["switch_days"])):
        destination = np.asarray(replay["destination_cells"])[event_index]
        replay_arrays = {
            "probabilities": np.asarray(replay["probabilities"])[event_index],
            "candidate_param_indices": np.asarray(
                replay["candidate_param_indices"]
            )[event_index],
            "candidate_noise_indices": np.asarray(
                replay["candidate_noise_indices"]
            )[event_index],
        }
        replay_param, replay_noise = axis_marginals(
            replay_arrays["probabilities"],
            replay_arrays["candidate_param_indices"],
            replay_arrays["candidate_noise_indices"],
        )
        replay_cell = _true_cell_probabilities({
            **replay_arrays,
            "truth_param_indices": np.full(len(replay_param), int(destination[0])),
            "truth_noise_indices": np.full(len(replay_noise), int(destination[1])),
        })
        for window in report_windows:
            width = int(window)
            continuous_days = np.arange(int(switch_day), int(switch_day) + width)
            replay_days = np.arange(width)
            continuous_state = _state_metrics(
                np.asarray(continuous["combined_states"])[continuous_days],
                np.asarray(continuous["truth_post_states"])[continuous_days],
            )["mean_normalized_rmse"]
            replay_state = _state_metrics(
                np.asarray(replay["combined_states"])[event_index, replay_days],
                np.asarray(replay["truth_post_states"])[event_index, replay_days],
            )["mean_normalized_rmse"]
            rows.append({
                "basin_id": str(basin_id),
                "seed": int(seed),
                "arm_id": str(arm_id),
                "knowledge_mode": str(knowledge_mode),
                "event_index": event_index,
                "switch_day": int(switch_day),
                "window_days": width,
                "param_error_propagation": float(
                    np.mean(replay_param[replay_days, int(destination[0])])
                    - np.mean(
                        continuous_param[
                            continuous_days, int(destination[0])
                        ]
                    )
                ),
                "noise_error_propagation": float(
                    np.mean(replay_noise[replay_days, int(destination[1])])
                    - np.mean(
                        continuous_noise[
                            continuous_days, int(destination[1])
                        ]
                    )
                ),
                "cell_error_propagation": float(
                    np.mean(replay_cell[replay_days])
                    - np.mean(continuous_cell[continuous_days])
                ),
                "state_error_propagation": float(
                    continuous_state - replay_state
                ),
            })
    return rows


def paired_axis_frame(axis_frame: pd.DataFrame) -> pd.DataFrame:
    """Pair joint and corresponding known-axis probabilities by exact identity."""

    key = ["basin_id", "seed", "arm_id", "axis", "level"]
    joint = axis_frame[axis_frame["knowledge_mode"] == "joint_unknown"][
        key + ["mean_true_probability"]
    ].rename(columns={"mean_true_probability": "joint_probability"})
    references = []
    for axis, mode in (("param", "noise_known"), ("noise", "param_known")):
        selected = axis_frame[
            (axis_frame["axis"] == axis)
            & (axis_frame["knowledge_mode"] == mode)
        ][key + ["mean_true_probability"]].rename(
            columns={"mean_true_probability": "reference_probability"}
        )
        references.append(selected)
    reference = pd.concat(references, ignore_index=True)
    paired = joint.merge(reference, on=key, how="inner", validate="one_to_one")
    expected = len(axis_frame[axis_frame["knowledge_mode"] == "joint_unknown"])
    if len(paired) != expected:
        raise ValueError(f"paired axis rows are incomplete: {len(paired)} != {expected}")
    paired["paired_difference"] = (
        paired["joint_probability"] - paired["reference_probability"]
    )
    return paired


def paired_state_frames(
    task_frame: pd.DataFrame,
    state_frame: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Pair joint-state errors with both single-axis references by identity."""

    task_key = ["basin_id", "seed", "arm_id"]
    joint_task = task_frame[task_frame["knowledge_mode"] == "joint_unknown"][
        task_key + ["state_mean_normalized_rmse"]
    ].rename(columns={"state_mean_normalized_rmse": "joint_normalized_rmse"})
    task_pairs = []
    for reference_mode in ("param_known", "noise_known"):
        reference = task_frame[task_frame["knowledge_mode"] == reference_mode][
            task_key + ["state_mean_normalized_rmse"]
        ].rename(
            columns={"state_mean_normalized_rmse": "reference_normalized_rmse"}
        )
        paired = joint_task.merge(
            reference, on=task_key, how="inner", validate="one_to_one"
        )
        paired["reference_knowledge_mode"] = reference_mode
        paired["joint_minus_reference"] = (
            paired["joint_normalized_rmse"]
            - paired["reference_normalized_rmse"]
        )
        task_pairs.append(paired)
    paired_tasks = pd.concat(task_pairs, ignore_index=True)
    if len(paired_tasks) != len(joint_task) * 2:
        raise ValueError("paired task-state rows are incomplete")

    state_key = task_key + ["state_index"]
    joint_state = state_frame[state_frame["knowledge_mode"] == "joint_unknown"][
        state_key + ["normalized_rmse"]
    ].rename(columns={"normalized_rmse": "joint_normalized_rmse"})
    state_pairs = []
    for reference_mode in ("param_known", "noise_known"):
        reference = state_frame[state_frame["knowledge_mode"] == reference_mode][
            state_key + ["normalized_rmse"]
        ].rename(columns={"normalized_rmse": "reference_normalized_rmse"})
        paired = joint_state.merge(
            reference, on=state_key, how="inner", validate="one_to_one"
        )
        paired["reference_knowledge_mode"] = reference_mode
        paired["joint_minus_reference"] = (
            paired["joint_normalized_rmse"]
            - paired["reference_normalized_rmse"]
        )
        state_pairs.append(paired)
    paired_states = pd.concat(state_pairs, ignore_index=True)
    if len(paired_states) != len(joint_state) * 2:
        raise ValueError("paired per-state rows are incomplete")
    return paired_tasks, paired_states


def bootstrap_median_interval(values, seed, replicates=20000) -> tuple[float, float]:
    sample = np.asarray(values, dtype=np.float64)
    sample = sample[np.isfinite(sample)]
    if len(sample) == 0:
        raise ValueError("bootstrap sample is empty")
    rng = np.random.default_rng(int(seed))
    medians = np.empty(int(replicates), dtype=np.float64)
    batch_size = 2000
    for start in range(0, int(replicates), batch_size):
        stop = min(start + batch_size, int(replicates))
        indices = rng.integers(
            0,
            len(sample),
            size=(stop - start, len(sample)),
        )
        medians[start:stop] = np.median(sample[indices], axis=1)
    lower, upper = np.quantile(medians, [0.025, 0.975])
    return float(lower), float(upper)


def grouped_bootstrap_summary(
    frame: pd.DataFrame,
    group_columns,
    metric_columns,
    seed,
    replicates,
) -> pd.DataFrame:
    """Report group medians and deterministic paired-unit bootstrap intervals."""

    rows = []
    grouped = frame.groupby(list(group_columns), sort=True, dropna=False)
    stream_offset = 0
    for identity, selected in grouped:
        identity_values = identity if isinstance(identity, tuple) else (identity,)
        common = dict(zip(group_columns, identity_values))
        for metric in metric_columns:
            values = selected[metric].to_numpy(dtype=np.float64)
            lower, upper = bootstrap_median_interval(
                values,
                seed=int(seed) + stream_offset,
                replicates=int(replicates),
            )
            rows.append({
                **common,
                "metric": str(metric),
                "n_pairs": int(np.sum(np.isfinite(values))),
                "median": float(np.median(values[np.isfinite(values)])),
                "bootstrap_95_lower": lower,
                "bootstrap_95_upper": upper,
            })
            stream_offset += 1
    return pd.DataFrame(rows)


def _axis_level_decision(
    arm_id,
    axis,
    level,
    axis_frame,
    paired,
    bootstrap_seed,
    bootstrap_replicates,
) -> dict:
    reference_mode = "noise_known" if axis == "param" else "param_known"
    joint = axis_frame[
        (axis_frame["arm_id"] == arm_id)
        & (axis_frame["axis"] == axis)
        & (axis_frame["level"] == level)
        & (axis_frame["knowledge_mode"] == "joint_unknown")
    ]["mean_true_probability"].dropna().to_numpy()
    reference = axis_frame[
        (axis_frame["arm_id"] == arm_id)
        & (axis_frame["axis"] == axis)
        & (axis_frame["level"] == level)
        & (axis_frame["knowledge_mode"] == reference_mode)
    ]["mean_true_probability"].dropna().to_numpy()
    differences = paired[
        (paired["arm_id"] == arm_id)
        & (paired["axis"] == axis)
        & (paired["level"] == level)
    ]["paired_difference"].dropna().to_numpy()
    if len(joint) == 0 or len(reference) == 0 or len(differences) == 0:
        raise ValueError(f"missing axis decision rows for {arm_id} {axis} {level}")
    lower, upper = bootstrap_median_interval(
        differences,
        seed=int(bootstrap_seed) + (0 if axis == "param" else 100) + int(level),
        replicates=bootstrap_replicates,
    )
    joint_absolute = (
        float(np.median(joint)) > AXIS_MAJORITY_MIN
        and float(np.mean(joint > AXIS_CHANCE)) >= ABOVE_CHANCE_FRACTION_MIN
    )
    reference_absolute = (
        float(np.median(reference)) > AXIS_MAJORITY_MIN
        and float(np.mean(reference > AXIS_CHANCE)) >= ABOVE_CHANCE_FRACTION_MIN
    )
    noninferior = (
        float(np.median(differences)) >= NONINFERIORITY_MARGIN
        and lower >= NONINFERIORITY_MARGIN
    )
    return {
        "joint_median": float(np.median(joint)),
        "joint_above_chance_fraction": float(np.mean(joint > AXIS_CHANCE)),
        "reference_median": float(np.median(reference)),
        "reference_above_chance_fraction": float(
            np.mean(reference > AXIS_CHANCE)
        ),
        "paired_difference_median": float(np.median(differences)),
        "paired_difference_bootstrap_95": [lower, upper],
        "joint_absolute_pass": bool(joint_absolute),
        "reference_absolute_pass": bool(reference_absolute),
        "noninferiority_pass": bool(noninferior),
        "level_pass": bool(joint_absolute and reference_absolute and noninferior),
    }


def decide_arm(
    arm_id,
    axis_frame,
    paired,
    task_frame,
    bootstrap_seed,
    bootstrap_replicates,
) -> dict:
    axes = {"param": {}, "noise": {}}
    for axis in axes:
        for level in range(3):
            axes[axis][str(level)] = _axis_level_decision(
                arm_id,
                axis,
                level,
                axis_frame,
                paired,
                bootstrap_seed,
                bootstrap_replicates,
            )
    parameter_pass = all(item["level_pass"] for item in axes["param"].values())
    noise_pass = all(item["level_pass"] for item in axes["noise"].values())
    cell = task_frame[
        (task_frame["arm_id"] == arm_id)
        & (task_frame["knowledge_mode"] == "joint_unknown")
    ]
    probabilities = cell["cell_mean_true_probability"].to_numpy()
    accuracies = cell["cell_argmax_accuracy"].to_numpy()
    whole_cell = (
        float(np.median(probabilities)) > CELL_CHANCE
        and float(np.mean(probabilities > CELL_CHANCE)) >= ABOVE_CHANCE_FRACTION_MIN
        and float(np.median(accuracies)) > CELL_ARGMAX_MIN
    )
    return {
        "axes": axes,
        "parameter_axis_pass": bool(parameter_pass),
        "process_noise_axis_pass": bool(noise_pass),
        "whole_cell": {
            "median_true_probability": float(np.median(probabilities)),
            "above_chance_fraction": float(np.mean(probabilities > CELL_CHANCE)),
            "median_argmax_accuracy": float(np.median(accuracies)),
            "pass": bool(whole_cell),
        },
        "whole_cell_pass": bool(whole_cell),
        "simultaneous_identification": bool(
            parameter_pass and noise_pass and whole_cell
        ),
    }


def _load_npz(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {name: archive[name].copy() for name in archive.files}


def _require_complete_manifest(root: Path, expected_tasks: int) -> dict:
    path = root / "verification" / "run_manifest.json"
    if not path.is_file():
        raise FileNotFoundError(f"run manifest is missing: {path}")
    with path.open(encoding="utf-8") as handle:
        manifest = json.load(handle)
    if manifest.get("n_tasks") != expected_tasks:
        raise ValueError("manifest task count differs from registration")
    if manifest.get("n_success") != expected_tasks or manifest.get("n_failed") != 0:
        raise ValueError("scientific summary requires every registered task")
    records_path = root / "verification" / "task_records.json"
    failures_path = root / "verification" / "run_failures.json"
    with records_path.open(encoding="utf-8") as handle:
        records = json.load(handle)
    with failures_path.open(encoding="utf-8") as handle:
        failures = json.load(handle)
    identities = [record.get("task_id") for record in records]
    if (
        len(records) != expected_tasks
        or len(set(identities)) != expected_tasks
        or any(record.get("run_status") != "success" for record in records)
        or failures != []
    ):
        raise ValueError("scientific summary requires unique successful task records")
    return manifest


def _write_json_new(path: Path, payload) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")


def _write_csv_new(path: Path, frame: pd.DataFrame) -> None:
    frame.to_csv(path, index=False, mode="x")


def summarize_formal_evidence(repo_root=REPO_ROOT, route="local") -> dict:
    configs = load_registered_configs(repo_root)
    if route not in {"local", "hpc"}:
        raise ValueError(f"unknown evidence route: {route}")
    continuous_root = Path(repo_root) / configs.continuous[
        f"output_root_{route}"
    ]
    replay_root = Path(repo_root) / configs.replay[f"output_root_{route}"]
    truth_root = Path(repo_root) / configs.base["truth_output_root"]
    tasks = build_task_table(admitted_basins(), configs.base["formal_seeds"])
    truth_manifest = _require_complete_manifest(
        truth_root,
        len(admitted_basins()) * len(configs.base["formal_seeds"]),
    )
    continuous_manifest = _require_complete_manifest(continuous_root, len(tasks))
    replay_manifest = _require_complete_manifest(replay_root, len(tasks))
    commits = {
        truth_manifest.get("git_commit"),
        continuous_manifest.get("git_commit"),
        replay_manifest.get("git_commit"),
    }
    if len(commits) != 1 or None in commits:
        raise ValueError("scientific summary requires one frozen git commit")
    summaries = []
    replay_rows = []
    propagation = []
    for task in tasks:
        arrays = _load_npz(task_output_path(continuous_root, task))
        replay_arrays = _load_npz(task_output_path(replay_root, task))
        summaries.append(
            summarize_continuous_task(
                arrays,
                task.basin_id,
                task.seed,
                task.arm_id,
                task.knowledge_mode,
                scoring_start_day=int(configs.base["stage_days"]),
            )
        )
        replay_rows.extend(
            summarize_replay_task(
                replay_arrays,
                task.basin_id,
                task.seed,
                task.arm_id,
                task.knowledge_mode,
                configs.replay["report_windows_days"],
            )
        )
        propagation.extend(
            propagation_rows(
                arrays,
                replay_arrays,
                task.basin_id,
                task.seed,
                task.arm_id,
                task.knowledge_mode,
                configs.replay["report_windows_days"],
            )
        )
    task_frame, axis_frame, state_frame = task_summary_frames(summaries)
    paired = paired_axis_frame(axis_frame)
    paired_state_tasks, paired_states = paired_state_frames(
        task_frame, state_frame
    )
    decisions = {
        arm: decide_arm(
            arm,
            axis_frame,
            paired,
            task_frame,
            bootstrap_seed=int(configs.base["bootstrap_seed"]),
            bootstrap_replicates=int(configs.base["bootstrap_replicates"]),
        )
        for arm in ARM_MODES
    }
    continuous_verification = continuous_root / "verification"
    _write_csv_new(
        continuous_verification / "task_metrics.csv", task_frame
    )
    _write_csv_new(
        continuous_verification / "axis_level_metrics.csv", axis_frame
    )
    _write_csv_new(
        continuous_verification / "state_metrics.csv", state_frame
    )
    _write_csv_new(
        continuous_verification / "paired_axis_metrics.csv", paired
    )
    _write_csv_new(
        continuous_verification / "paired_state_task_metrics.csv",
        paired_state_tasks,
    )
    _write_csv_new(
        continuous_verification / "paired_state_metrics.csv", paired_states
    )
    replay_frame = pd.DataFrame(replay_rows)
    propagation_frame = pd.DataFrame(propagation)
    replay_verification = replay_root / "verification"
    _write_csv_new(
        replay_verification / "event_metrics.csv", replay_frame
    )
    _write_csv_new(
        replay_verification / "propagation_metrics.csv", propagation_frame
    )
    event_summary = grouped_bootstrap_summary(
        replay_frame,
        group_columns=[
            "arm_id",
            "knowledge_mode",
            "event_index",
            "switch_day",
            "transition_kind",
            "window_days",
        ],
        metric_columns=[
            "param_mean_true_probability",
            "noise_mean_true_probability",
            "cell_mean_true_probability",
            "param_argmax_accuracy",
            "noise_argmax_accuracy",
            "cell_argmax_accuracy",
            "state_mean_normalized_rmse",
        ],
        seed=int(configs.base["bootstrap_seed"]) + 1000,
        replicates=int(configs.base["bootstrap_replicates"]),
    )
    _write_csv_new(
        replay_verification / "event_summary.csv", event_summary
    )
    propagation_summary_frame = grouped_bootstrap_summary(
        propagation_frame,
        group_columns=[
            "arm_id",
            "knowledge_mode",
            "event_index",
            "switch_day",
            "window_days",
        ],
        metric_columns=[
            "param_error_propagation",
            "noise_error_propagation",
            "cell_error_propagation",
            "state_error_propagation",
        ],
        seed=int(configs.base["bootstrap_seed"]) + 2000,
        replicates=int(configs.base["bootstrap_replicates"]),
    )
    _write_csv_new(
        replay_verification / "propagation_summary.csv",
        propagation_summary_frame,
    )
    paired_state_task_summary = grouped_bootstrap_summary(
        paired_state_tasks,
        group_columns=["arm_id", "reference_knowledge_mode"],
        metric_columns=["joint_minus_reference"],
        seed=int(configs.base["bootstrap_seed"]) + 3000,
        replicates=int(configs.base["bootstrap_replicates"]),
    )
    _write_csv_new(
        continuous_verification / "paired_state_task_summary.csv",
        paired_state_task_summary,
    )
    paired_state_summary = grouped_bootstrap_summary(
        paired_states,
        group_columns=[
            "arm_id", "reference_knowledge_mode", "state_index"
        ],
        metric_columns=["joint_minus_reference"],
        seed=int(configs.base["bootstrap_seed"]) + 4000,
        replicates=int(configs.base["bootstrap_replicates"]),
    )
    _write_csv_new(
        continuous_verification / "paired_state_summary.csv",
        paired_state_summary,
    )
    propagation_summary = {}
    for arm in ARM_MODES:
        selected = propagation_frame[
            (propagation_frame["arm_id"] == arm)
            & (propagation_frame["knowledge_mode"] == "joint_unknown")
            & (propagation_frame["window_days"] == 180)
        ]
        propagation_summary[arm] = {
            column: float(np.median(selected[column]))
            for column in (
                "param_error_propagation",
                "noise_error_propagation",
                "cell_error_propagation",
                "state_error_propagation",
            )
        }
    summary = {
        "experiment_id": configs.continuous["experiment_id"],
        "execution_route": route,
        "frozen_git_commit": next(iter(commits)),
        "n_tasks": len(tasks),
        "decisions": decisions,
        "replay_event_rows": int(len(replay_frame)),
        "propagation_rows": int(len(propagation_frame)),
        "event_summary_rows": int(len(event_summary)),
        "propagation_summary_rows": int(len(propagation_summary_frame)),
        "paired_state_task_rows": int(len(paired_state_tasks)),
        "paired_state_rows": int(len(paired_states)),
        "joint_unknown_180_day_propagation_medians": propagation_summary,
        "state_improvement_claim": "not_preregistered_descriptive_only",
        "technical_complete": True,
        "claim_boundary": (
            "synthetic same-observation identification and state estimation only; "
            "no forecast, real-observation, or 531-basin claim"
        ),
    }
    _write_json_new(continuous_verification / "summary.json", summary)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--route", choices=("local", "hpc"), default="local")
    arguments = parser.parse_args()
    payload = summarize_formal_evidence(route=arguments.route)
    print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
