"""CMA-ES calibration for NumPy HBV-lite.

Uses ``cma.CMAEvolutionStrategy`` (pycma) to optimize the 13 parameters
against an NSE-based objective. CMA-ES is derivative-free, so it sidesteps
the gradient-vanishing pathologies that hurt Adam on HBV-light's
many ``clamp`` / ``minimum`` operations (especially on arid basins where
``SUZ < UZL`` permanently zeros out K0/UZL gradients).

Mirrors the multi-restart pattern in
``src/xaj_global_pilot/xaj_model.py::_cmaes_multi_restart``.
"""
import hashlib
import re
import time
from datetime import datetime, timezone

import numpy as np
import cma

from .hbv_lite_numpy import (
    PARAM_NAMES,
    PARAM_BOUNDS,
    STATE_NAMES,
    simulate_hbv_lite,
)

WARMUP_DAYS = 365
VALID_LOSSES = frozenset({"nse", "kge", "hybrid", "log_mse", "raw_mse"})


class OptimizerTelemetryError(RuntimeError):
    """Raised when required observation-only optimizer evidence is unavailable."""


class OptimizerTelemetryMismatchError(OptimizerTelemetryError):
    """Raised when optimizer-reported work differs from objective calls."""


_STOP_REASON_NAMES = {
    "callback": "callback",
    "conditioncov": "covariance_condition_limit",
    "ftarget": "target_fitness",
    "maxfevals": "maximum_evaluations",
    "maxiter": "maximum_iterations",
    "noeffectaxis": "no_effect_axis",
    "noeffectcoord": "no_effect_coordinate",
    "timeout": "timeout",
    "tolflatfitness": "flat_fitness_tolerance",
    "tolfun": "fitness_tolerance",
    "tolfunhist": "fitness_history_tolerance",
    "tolstagnation": "stagnation_tolerance",
    "tolupsigma": "step_size_increase_limit",
    "tolx": "parameter_step_tolerance",
}


def _nse(obs: np.ndarray, sim: np.ndarray) -> float:
    mask = np.isfinite(obs) & np.isfinite(sim)
    if mask.sum() < 10:
        return float("nan")
    o = obs[mask]
    s = sim[mask]
    denom = np.sum((o - o.mean()) ** 2)
    if denom <= 0.0:
        return float("nan")
    return float(1.0 - np.sum((s - o) ** 2) / denom)


def _kge(obs: np.ndarray, sim: np.ndarray) -> float:
    """Kling-Gupta efficiency.

    KGE = 1 - sqrt((r-1)^2 + (alpha-1)^2 + (beta-1)^2)
    where r=corr, alpha=std(sim)/std(obs), beta=mean(sim)/mean(obs).
    Decomposes error into correlation + variance + bias components,
    often finds different optima than pure NSE.
    """
    mask = np.isfinite(obs) & np.isfinite(sim)
    if mask.sum() < 10:
        return float("nan")
    o = obs[mask]
    s = sim[mask]
    o_mean = o.mean()
    s_mean = s.mean()
    o_std = o.std()
    s_std = s.std()
    if o_std == 0 or o_mean == 0:
        return float("nan")
    r_num = np.sum((o - o_mean) * (s - s_mean))
    r_den = np.sqrt(np.sum((o - o_mean) ** 2) * np.sum((s - s_mean) ** 2))
    if r_den == 0:
        return float("nan")
    r = r_num / r_den
    alpha = s_std / o_std
    beta = s_mean / o_mean
    return float(1.0 - np.sqrt((r - 1) ** 2 + (alpha - 1) ** 2 + (beta - 1) ** 2))


def _objective_loss_with_penalty_status(
    obs: np.ndarray,
    sim: np.ndarray,
    loss: str,
    kge_weight: float,
    flow_log_offset_mm_day: float,
) -> tuple[float, bool]:
    """Return loss and whether a non-finite metric was replaced by a penalty."""
    if loss == "log_mse":
        return (
            float(
                np.mean(
                    np.square(
                        np.log(np.maximum(sim, 0.0) + flow_log_offset_mm_day)
                        - np.log(obs + flow_log_offset_mm_day)
                    )
                )
            ),
            False,
        )
    if loss == "raw_mse":
        return float(np.mean(np.square(sim - obs))), False
    if loss == "nse":
        nse = _nse(obs, sim)
        return (1.0 - nse, False) if np.isfinite(nse) else (2.0, True)
    if loss == "kge":
        kge = _kge(obs, sim)
        return (1.0 - kge, False) if np.isfinite(kge) else (2.0, True)
    if loss == "hybrid":
        nse = _nse(obs, sim)
        kge = _kge(obs, sim)
        if not (np.isfinite(nse) and np.isfinite(kge)):
            return 2.0, True
        return (1.0 - kge_weight) * (1.0 - nse) + kge_weight * (1.0 - kge), False
    raise ValueError(f"Unknown loss: {loss}")


def _objective_loss(
    obs: np.ndarray,
    sim: np.ndarray,
    loss: str,
    kge_weight: float,
    flow_log_offset_mm_day: float,
) -> float:
    """Return the minimized loss for an already-selected set of days."""
    value, _ = _objective_loss_with_penalty_status(
        obs,
        sim,
        loss,
        kge_weight,
        flow_log_offset_mm_day,
    )
    return value


def _timestamp_utc() -> str:
    """Return an unambiguous UTC timestamp suitable for evidence artifacts."""
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def _parameter_fingerprint(params: dict) -> str:
    """Fingerprint a complete parameter vector with exact binary float values."""
    payload = "\n".join(f"{name}={float(params[name]).hex()}" for name in PARAM_NAMES)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _json_safe_telemetry_value(value):
    """Convert optimizer stop metadata to JSON-safe built-in values."""
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        return value if np.isfinite(value) else str(value)
    if isinstance(value, np.generic):
        return _json_safe_telemetry_value(value.item())
    if isinstance(value, dict):
        return {str(key): _json_safe_telemetry_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe_telemetry_value(item) for item in value]
    if isinstance(value, np.ndarray):
        return [_json_safe_telemetry_value(item) for item in value.tolist()]
    return str(value)


def _optimizer_stop_evidence(es) -> tuple[dict, list[str]]:
    """Read raw pycma stop metadata and provide stable reason names."""
    try:
        raw = es.stop()
    except Exception as exc:
        raise OptimizerTelemetryError("optimizer stopping reasons are unavailable") from exc
    if raw is None:
        raw = {}
    if not isinstance(raw, dict):
        raw = {"optimizer_stop": raw}
    raw_safe = _json_safe_telemetry_value(raw)
    normalized = []
    for reason in raw_safe:
        compact = re.sub(r"[^a-z0-9]+", "_", str(reason).lower()).strip("_")
        normalized.append(_STOP_REASON_NAMES.get(compact, f"optimizer_{compact}"))
    if not normalized:
        normalized = ["optimizer_returned_without_stop_reason"]
    return raw_safe, sorted(set(normalized))


def _optimizer_nonnegative_count(es, result_name: str, strategy_name: str) -> int:
    """Read a required nonnegative integer count from pycma result or strategy."""
    value = getattr(es.result, result_name, None)
    if value is None:
        value = getattr(es, strategy_name, None)
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)):
        raise OptimizerTelemetryError(f"optimizer {result_name} count is unavailable")
    value = int(value)
    if value < 0:
        raise OptimizerTelemetryError(f"optimizer {result_name} count must be nonnegative")
    return value


def _finish_telemetry_record(record: dict, start_monotonic: float, status: str, error=None) -> None:
    """Finalize timing and terminal fields without touching optimizer state."""
    record["ended_at"] = _timestamp_utc()
    record["elapsed_seconds"] = float(time.perf_counter() - start_monotonic)
    record["status"] = status
    record["exception_type"] = type(error).__name__ if error is not None else None
    record["exception_message"] = str(error) if error is not None else None


def _validated_inputs(
    rain: np.ndarray,
    pet: np.ndarray,
    temp: np.ndarray,
    obs: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Validate and normalize the four complete daily input series."""
    arrays = {
        "rain": np.asarray(rain, dtype=float),
        "pet": np.asarray(pet, dtype=float),
        "temp": np.asarray(temp, dtype=float),
        "obs": np.asarray(obs, dtype=float),
    }
    for name, values in arrays.items():
        if values.ndim != 1:
            raise ValueError(f"{name} must be a one-dimensional array")
    lengths = {len(values) for values in arrays.values()}
    if len(lengths) != 1:
        raise ValueError("rain, pet, temp, and obs must have the same length")
    for name in ("rain", "pet", "temp"):
        if not np.all(np.isfinite(arrays[name])):
            raise ValueError(f"{name} forcing must contain only finite values")
    if np.any(arrays["rain"] < 0.0) or np.any(arrays["pet"] < 0.0):
        raise ValueError("rain and pet forcing must be nonnegative")
    return arrays["rain"], arrays["pet"], arrays["temp"], arrays["obs"]


def calibrate_hbv_lite_cma(
    rain: np.ndarray,
    pet: np.ndarray,
    temp: np.ndarray,
    obs: np.ndarray,
    n_trials: int = 5000,
    n_restarts: int = 3,
    state_init: dict | None = None,
    loss: str = "nse",
    kge_weight: float = 0.5,
    init_mean_norm: float | None = None,
    init_sigma: float = 0.3,
    param_bounds: dict | None = None,
    lag_kernel: str = "recession",
    objective_mask: np.ndarray | None = None,
    flow_log_offset_mm_day: float = 0.01,
    restart_seeds: list[int] | tuple[int, ...] | None = None,
    telemetry_collector: list[dict] | None = None,
) -> dict:
    """CMA-ES multi-restart calibration of HBV-light.

    Parameters
    ----------
    rain, pet, temp, obs : np.ndarray (1D)
        Daily forcing and observed Q (mm/d).
    n_trials : int
        Value passed to pycma's ``maxfevals`` stopping threshold. Because
        pycma evaluates complete populations, the actual count can exceed it.
    n_restarts : int
        Independent CMA-ES runs (different seeds), best retained.
    param_bounds : dict | None
        Per-parameter ``(lo, hi)`` bounds keyed by ``PARAM_NAMES``. When
        ``None`` (default) the module-level ``PARAM_BOUNDS`` is used, which
        preserves the historical import-time / ``HBV_BOUNDS``-env behaviour
        bit-for-bit. Pass ``resolve_hbv_bounds(preset)`` to select bounds at
        runtime (used by the ``--bounds-preset`` CLI).
    lag_kernel : str
        Routing-lag kernel passed through to ``simulate_hbv_lite`` —
        "recession" (default, canonical repro_v01) or "rising". The optimum
        is only valid under the kernel it was calibrated with.
    objective_mask : np.ndarray | None
        Optional full-series boolean mask selecting days that enter the
        calibration objective. The model is still simulated over the complete
        input series, and warmup days never enter the objective.
    flow_log_offset_mm_day : float
        Positive offset used by the ``log_mse`` objective.
    restart_seeds : list[int] | tuple[int, ...] | None
        Optional explicit seed for each restart. ``None`` preserves the legacy
        sequence ``42, 1042, 2042, ...``.
    telemetry_collector : list[dict] | None
        Optional caller-owned list receiving one observation-only execution
        record per restart. Enabling it adds the same evidence fields to each
        restart record and selected-restart metadata to the top-level result;
        it does not change the objective, candidates, CMA-ES options,
        selection, parameter vector, or simulation.

    Returns
    -------
    dict with the legacy ``nse``, ``optimized_params``, ``qsim``, and
    ``final_state`` keys plus objective metadata and ``restart_records``.
    """
    rain, pet, temp, obs = _validated_inputs(rain, pet, temp, obs)
    if loss not in VALID_LOSSES:
        raise ValueError(f"Unknown loss: {loss}; valid losses are {sorted(VALID_LOSSES)}")
    if isinstance(n_trials, (bool, np.bool_)) or not isinstance(n_trials, (int, np.integer)) or n_trials <= 0:
        raise ValueError("n_trials must be a positive integer")
    if (
        isinstance(n_restarts, (bool, np.bool_))
        or not isinstance(n_restarts, (int, np.integer))
        or n_restarts <= 0
    ):
        raise ValueError("n_restarts must be a positive integer")
    if not np.isfinite(flow_log_offset_mm_day) or flow_log_offset_mm_day <= 0.0:
        raise ValueError("flow_log_offset_mm_day must be finite and positive")
    if telemetry_collector is not None and not isinstance(telemetry_collector, list):
        raise ValueError("telemetry_collector must be a list or None")

    if objective_mask is None:
        score_mask = np.ones(len(obs), dtype=bool)
    else:
        score_mask = np.asarray(objective_mask)
        if score_mask.ndim != 1:
            raise ValueError("objective_mask must be a one-dimensional boolean array")
        if score_mask.dtype.kind != "b":
            raise ValueError("objective_mask must be a boolean array")
        if len(score_mask) != len(obs):
            raise ValueError("objective_mask must have the same length as obs")
        score_mask = score_mask.copy()

    if restart_seeds is None:
        seeds = [42 + restart * 1000 for restart in range(n_restarts)]
    else:
        seeds = list(restart_seeds)
        if len(seeds) != n_restarts:
            raise ValueError("restart_seeds length must equal n_restarts")
        if any(
            isinstance(seed, (bool, np.bool_)) or not isinstance(seed, (int, np.integer))
            for seed in seeds
        ):
            raise ValueError("restart_seeds must contain only integers")
        seeds = [int(seed) for seed in seeds]

    bounds = PARAM_BOUNDS if param_bounds is None else param_bounds
    lo = np.array([bounds[n][0] for n in PARAM_NAMES])
    hi = np.array([bounds[n][1] for n in PARAM_NAMES])
    ndim = len(PARAM_NAMES)
    warmup = min(WARMUP_DAYS, len(obs) // 4)
    obs_eval = obs[warmup:]
    score_mask[:warmup] = False
    score_mask &= np.isfinite(obs)
    n_objective_days = int(score_mask.sum())
    if n_objective_days < 10:
        raise ValueError("objective_mask must select at least 10 finite observations after warmup")
    if loss == "log_mse" and np.any(obs[score_mask] < 0.0):
        raise ValueError("log_mse objective observations must be nonnegative")
    objective_mask_fraction = float(n_objective_days / len(obs))

    def _make_params(x_norm: np.ndarray) -> dict:
        x = lo + np.clip(x_norm, 0.0, 1.0) * (hi - lo)
        return dict(zip(PARAM_NAMES, x.tolist()))

    active_telemetry_record: dict | None = None

    def objective(x_norm: np.ndarray) -> float:
        if active_telemetry_record is not None:
            active_telemetry_record["objective_call_count"] += 1
        params = _make_params(x_norm)
        try:
            q_sim, _ = simulate_hbv_lite(rain, pet, temp, params, initial_state=state_init, lag_kernel=lag_kernel)
            objective_value, penalty_substituted = _objective_loss_with_penalty_status(
                obs[score_mask],
                q_sim[score_mask],
                loss,
                kge_weight,
                flow_log_offset_mm_day,
            )
            if penalty_substituted or not np.isfinite(objective_value):
                if active_telemetry_record is not None:
                    active_telemetry_record["objective_nonfinite_count"] += 1
                    active_telemetry_record["objective_penalty_count"] += 1
                return 2.0
            return objective_value
        except Exception:
            if active_telemetry_record is not None:
                active_telemetry_record["objective_exception_count"] += 1
                active_telemetry_record["objective_penalty_count"] += 1
            return 2.0

    init_m = 0.5 if init_mean_norm is None else float(init_mean_norm)
    best_overall: tuple[np.ndarray, float] | None = None
    selected_restart_index: int | None = None
    restart_records = []
    call_telemetry_records = []
    for restart, seed in enumerate(seeds):
        telemetry_record = None
        start_monotonic = time.perf_counter()
        if telemetry_collector is not None:
            telemetry_record = {
                "restart_index": restart,
                "seed": seed,
                "declared_maxfevals_stop_threshold": int(n_trials),
                "objective_call_count": 0,
                "optimizer_evaluation_count": None,
                "optimizer_iteration_count": None,
                "evaluation_counts_agree": None,
                "objective_exception_count": 0,
                "objective_nonfinite_count": 0,
                "objective_penalty_count": 0,
                "stop_reasons_raw": None,
                "stop_reasons_normalized": None,
                "stop_reason_primary": None,
                "started_at": _timestamp_utc(),
                "ended_at": None,
                "elapsed_seconds": None,
                "status": "running",
                "exception_type": None,
                "exception_message": None,
                "best_loss": None,
                "best_normalized_parameters": None,
                "optimized_params": None,
                "best_parameter_fingerprint": None,
                "selected": False,
            }
            telemetry_collector.append(telemetry_record)
            call_telemetry_records.append(telemetry_record)
            active_telemetry_record = telemetry_record
        try:
            es = cma.CMAEvolutionStrategy(
                [init_m] * ndim,
                init_sigma,
                {
                    "bounds": [[0.0] * ndim, [1.0] * ndim],
                    "maxfevals": n_trials,
                    "seed": seed,
                    "verbose": -9,
                },
            )
            es.optimize(objective)
            restart_params = _make_params(es.result.xbest)
            if telemetry_record is not None:
                telemetry_record.update(
                    {
                        "best_loss": float(es.result.fbest),
                        "best_normalized_parameters": np.asarray(es.result.xbest, dtype=float).tolist(),
                        "optimized_params": restart_params.copy(),
                        "best_parameter_fingerprint": _parameter_fingerprint(restart_params),
                    }
                )
                optimizer_evaluations = _optimizer_nonnegative_count(es, "evaluations", "countevals")
                telemetry_record["optimizer_evaluation_count"] = optimizer_evaluations
                optimizer_iterations = _optimizer_nonnegative_count(es, "iterations", "countiter")
                telemetry_record["optimizer_iteration_count"] = optimizer_iterations
                telemetry_record["evaluation_counts_agree"] = bool(
                    telemetry_record["objective_call_count"] == optimizer_evaluations
                )
                if not telemetry_record["evaluation_counts_agree"]:
                    raise OptimizerTelemetryMismatchError(
                        "runner objective call count differs from optimizer evaluation count"
                    )
                raw_stop_reasons, normalized_stop_reasons = _optimizer_stop_evidence(es)
                telemetry_record.update(
                    {
                        "stop_reasons_raw": raw_stop_reasons,
                        "stop_reasons_normalized": normalized_stop_reasons,
                        "stop_reason_primary": normalized_stop_reasons[0],
                    }
                )
                _finish_telemetry_record(telemetry_record, start_monotonic, "completed")
        except Exception as exc:
            if telemetry_record is not None:
                _finish_telemetry_record(telemetry_record, start_monotonic, "failed", exc)
            raise
        finally:
            active_telemetry_record = None
        restart_records.append(
            {
                "restart_index": restart,
                "seed": seed,
                "objective_loss": float(es.result.fbest),
                "optimized_params": restart_params,
            }
        )
        if best_overall is None or es.result.fbest < best_overall[1]:
            best_overall = (es.result.xbest.copy(), float(es.result.fbest))
            selected_restart_index = restart

    for telemetry_record in call_telemetry_records:
        telemetry_record["selected"] = telemetry_record["restart_index"] == selected_restart_index
    if telemetry_collector is not None:
        for restart_record, telemetry_record in zip(restart_records, call_telemetry_records, strict=True):
            restart_record.update(telemetry_record)

    if best_overall is None:
        result = {
            "nse": -999.0,
            "optimized_params": {},
            "qsim": np.zeros(len(obs)),
            "final_state": None,
            "objective_loss": float("nan"),
            "n_objective_days": n_objective_days,
            "objective_mask_fraction": objective_mask_fraction,
            "restart_records": restart_records,
        }
        if telemetry_collector is not None:
            result["selected_restart_index"] = None
            result["selected_restart_seed"] = None
        return result

    best_params = _make_params(best_overall[0])
    try:
        best_q, final_state = simulate_hbv_lite(
            rain,
            pet,
            temp,
            best_params,
            initial_state=state_init,
            lag_kernel=lag_kernel,
        )
        best_nse = _nse(obs_eval, best_q[warmup:])
    except Exception:
        best_q = np.zeros(len(obs))
        final_state = None
        best_nse = -999.0

    result = {
        "nse": float(best_nse) if np.isfinite(best_nse) else -999.0,
        "optimized_params": best_params,
        "qsim": np.maximum(best_q, 0.0),
        "final_state": final_state,
        "objective_loss": float(best_overall[1]),
        "n_objective_days": n_objective_days,
        "objective_mask_fraction": objective_mask_fraction,
        "restart_records": restart_records,
    }
    if telemetry_collector is not None:
        result["selected_restart_index"] = selected_restart_index
        result["selected_restart_seed"] = seeds[selected_restart_index]
    return result
