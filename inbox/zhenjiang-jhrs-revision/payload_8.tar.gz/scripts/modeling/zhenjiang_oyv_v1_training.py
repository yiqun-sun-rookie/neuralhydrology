"""Train one leave-one-year-out task and emit its test-year prediction package.

One invocation is one registered task, identified by fold year, target station,
observation condition and seed. The loss, the inner-validation metric, the
history mask, the improvement comparison and the model constructor are imported
from the earlier frozen modules rather than restated, so the two experiments
cannot silently diverge in their numerics.

Order of operations, and why it is this order
---------------------------------------------
The runtime environment is checked before anything is loaded, so a task that
landed on a drifted node fails in seconds rather than after an epoch. The fold
isolation is then re-derived from the hour sets, not trusted from the partition
construction, and a single finding aborts the task. Only then is the model built.

The test-year prediction package is produced in the same process as the training
it belongs to. This avoids a second pass over 480 checkpoints, and the package
carries its own digest so that an independent audit can re-run inference from the
checkpoint and compare.

Inputs
------
--test-year     outer fold year, one of 2017 to 2024
--target        zhenjiang or jiangyin
--condition     hidden_target, hidden_target_both_nearest or endpoints_only
--seed          one of the ten registered seeds
--output-root   destination root; the task directory beneath it must not exist
--input-dir     six-station model input directory
--tide-model    frozen Wusongkou tide model json
--max-epochs    optional reduction of the epoch ceiling, for smoke tests only
--device        torch device string, defaults to cuda:0

Outputs
-------
Under ``<output-root>/<task_id>/``:
  best_state.pt              the retained checkpoint
  training_history.csv       one row per epoch
  test_predictions.npz       target-station predictions and targets in metres
  run_identity.json          environment, fold, isolation and counts
  completion_manifest.json   byte count and SHA-256 of every artifact

Usage
-----
python -u scripts/modeling/zhenjiang_oyv_v1_training.py \
    --test-year 2024 --target zhenjiang --condition hidden_target --seed 17 \
    --output-root results/modeling/zhenjiang_oyv_v1
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

PROJECT_ROOT = Path(__file__).resolve().parents[2]
for _relative in ("scripts/modeling", "scripts/astronomical_tide", "scripts/analysis"):
    _candidate = str(PROJECT_ROOT / _relative)
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)

from water_level_joint_encoder_decoder_v2 import (  # noqa: E402
    FORECAST_LENGTH_HOURS,
    STATION_ORDER,
)
from tidal_fluvial_hidden_gauge_v1_training import (  # noqa: E402
    create_model,
    evaluate_standardized,
    mask_history,
    metric_improved,
    target_loss_m,
    target_validation_mae_m,
)
from tidal_fluvial_hidden_gauge_v1_contract import (  # noqa: E402
    build_history_mask,
)

import zhenjiang_oyv_v1_contract as contract  # noqa: E402
import zhenjiang_oyv_v1_data as data_module  # noqa: E402

MINIMUM_FREE_DISK_BYTES = 20 * (1 << 30)
MINIMUM_FREE_HOST_MEMORY_BYTES = 4 * (1 << 30)
MINIMUM_FREE_DEVICE_MEMORY_BYTES = 4 * (1 << 30)


def resource_gate(output_root: Path, device: torch.device) -> dict[str, object]:
    """Refuse to start when the node cannot hold the task with margin.

    The frozen family used a Windows and psutil oriented probe. On the cluster the
    meaningful quantities are the free space of the parallel filesystem, the free
    host memory of the allocated node, and the free memory of the allocated card.
    """
    import shutil

    import psutil

    usage = shutil.disk_usage(str(output_root))
    virtual = psutil.virtual_memory()
    free_device, total_device = (0, 0)
    if device.type == "cuda":
        free_device, total_device = torch.cuda.mem_get_info(device.index or 0)
    report = {
        "disk_free_bytes": int(usage.free),
        "host_memory_available_bytes": int(virtual.available),
        "device_memory_free_bytes": int(free_device),
        "device_memory_total_bytes": int(total_device),
        "minimum_free_disk_bytes": MINIMUM_FREE_DISK_BYTES,
        "minimum_free_host_memory_bytes": MINIMUM_FREE_HOST_MEMORY_BYTES,
        "minimum_free_device_memory_bytes": MINIMUM_FREE_DEVICE_MEMORY_BYTES,
    }
    failures = []
    if usage.free < MINIMUM_FREE_DISK_BYTES:
        failures.append("disk")
    if virtual.available < MINIMUM_FREE_HOST_MEMORY_BYTES:
        failures.append("host_memory")
    if device.type == "cuda" and free_device < MINIMUM_FREE_DEVICE_MEMORY_BYTES:
        failures.append("device_memory")
    report["failures"] = failures
    report["passed"] = not failures
    return report


def sha256_of(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def train_one_task(
    test_year: int,
    target: str,
    condition: str,
    seed: int,
    output_root: Path,
    input_dir: Path,
    tide_model_path: Path,
    device_name: str,
    maximum_epochs_override: int | None,
) -> int:
    task_id = contract.task_id(test_year, target, condition, seed)
    task_directory = output_root / task_id
    if task_directory.exists():
        print("TASK_DIRECTORY_ALREADY_EXISTS: %s" % task_directory)
        return 1

    device = torch.device(device_name)
    runtime_environment = contract.require_frozen_runtime_environment()
    contract.apply_deterministic_settings(seed)

    output_root.mkdir(parents=True, exist_ok=True)
    gate = resource_gate(output_root, device)
    if not gate["passed"]:
        print("RESOURCE_GATE_FAILED: %s" % json.dumps(gate, sort_keys=True))
        return 1

    started = time.perf_counter()
    data = data_module.load_out_of_year_data(input_dir, tide_model_path)
    partition = data_module.build_fold_partition(data, test_year)
    isolation = data_module.assert_fold_isolation(data, partition)
    if isolation["finding_count"]:
        print("FOLD_ISOLATION_FAILED: %s" % json.dumps(isolation, sort_keys=True))
        return 1

    joint = data_module.build_joint_data(data, partition)
    training_dataset = data_module.build_dataset(joint, partition.training_positions)
    inner_loader = DataLoader(
        data_module.build_dataset(joint, partition.inner_validation_positions),
        batch_size=contract.FORMAL_BATCH_SIZE,
        shuffle=False,
        drop_last=False,
        num_workers=0,
    )
    test_loader = DataLoader(
        data_module.build_dataset(joint, partition.test_positions),
        batch_size=contract.FORMAL_BATCH_SIZE,
        shuffle=False,
        drop_last=False,
        num_workers=0,
    )

    target_index = STATION_ORDER.index(target)
    mask = build_history_mask(target, condition).to(device)
    model = create_model().to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=contract.FORMAL_LEARNING_RATE,
        betas=contract.FORMAL_ADAM_BETAS,
        eps=contract.FORMAL_ADAM_EPSILON,
        weight_decay=contract.FORMAL_WEIGHT_DECAY,
        amsgrad=contract.FORMAL_AMSGRAD,
        fused=contract.FORMAL_FUSED,
    )
    generator = torch.Generator(device="cpu")
    generator.manual_seed(seed)

    scales = np.asarray(
        joint.normalization.target_standard_deviation_m, dtype=np.float32
    )
    means = np.asarray(joint.normalization.target_mean_m, dtype=np.float32)

    maximum_epochs = contract.FORMAL_MAXIMUM_EPOCHS
    if maximum_epochs_override is not None:
        if not 0 < maximum_epochs_override <= contract.FORMAL_MAXIMUM_EPOCHS:
            raise ValueError("epoch override must lie inside the frozen ceiling")
        maximum_epochs = int(maximum_epochs_override)

    best_metric = float("inf")
    best_epoch = 0
    best_state: dict[str, torch.Tensor] | None = None
    epochs_without_improvement = 0
    history_rows: list[dict[str, object]] = []

    for epoch in range(1, maximum_epochs + 1):
        loader = DataLoader(
            training_dataset,
            batch_size=contract.FORMAL_BATCH_SIZE,
            shuffle=True,
            generator=generator,
            num_workers=0,
            drop_last=False,
        )
        model.train()
        loss_sum = 0.0
        sample_count = 0
        for history, future_tide, targets in loader:
            history = history.to(device, non_blocking=True)
            future_tide = future_tide.to(device, non_blocking=True)
            targets = targets.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            predictions = model(mask_history(history, mask), future_tide)
            loss = target_loss_m(predictions, targets, scales, target_index)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                model.parameters(), contract.FORMAL_GRADIENT_CLIP_NORM
            )
            optimizer.step()
            loss_sum += float(loss.detach()) * history.shape[0]
            sample_count += history.shape[0]

        inner_predictions, inner_targets = evaluate_standardized(
            model, inner_loader, mask, device
        )
        metric = target_validation_mae_m(
            inner_predictions, inner_targets, scales, target_index
        )
        improved = metric_improved(
            best_metric, metric, contract.FORMAL_MINIMUM_DELTA_M
        )
        if improved:
            best_metric = metric
            best_epoch = epoch
            best_state = {
                key: value.detach().cpu().clone()
                for key, value in model.state_dict().items()
            }
            epochs_without_improvement = 0
        else:
            epochs_without_improvement += 1
        history_rows.append(
            {
                "epoch": epoch,
                "training_loss_m": loss_sum / max(sample_count, 1),
                "inner_validation_1_10h_mean_absolute_error_m": metric,
                "improved": bool(improved),
                "epochs_without_improvement": epochs_without_improvement,
            }
        )
        if epochs_without_improvement >= contract.FORMAL_PATIENCE_EPOCHS:
            break

    if best_state is None:
        print("NO_EPOCH_IMPROVED_THE_INITIAL_METRIC")
        return 1
    model.load_state_dict(best_state)

    test_predictions, test_targets = evaluate_standardized(
        model, test_loader, mask, device
    )
    scale = float(scales[target_index])
    mean = float(means[target_index])
    prediction_m = (
        test_predictions[:, :, target_index].astype(np.float64) * scale + mean
    ).astype(np.float32)
    target_m = (
        test_targets[:, :, target_index].astype(np.float64) * scale + mean
    ).astype(np.float32)
    if prediction_m.shape != (
        partition.test_positions.size,
        FORECAST_LENGTH_HOURS,
    ):
        raise RuntimeError("test prediction shape does not match the test fold")

    task_directory.mkdir(parents=True, exist_ok=False)
    checkpoint_path = task_directory / "best_state.pt"
    torch.save(best_state, checkpoint_path)

    history_path = task_directory / "training_history.csv"
    header = (
        "epoch,training_loss_m,"
        "inner_validation_1_10h_mean_absolute_error_m,"
        "improved,epochs_without_improvement\n"
    )
    with history_path.open("w", encoding="utf-8", newline="") as handle:
        handle.write(header)
        for row in history_rows:
            handle.write(
                "%d,%.17g,%.17g,%s,%d\n"
                % (
                    row["epoch"],
                    row["training_loss_m"],
                    row["inner_validation_1_10h_mean_absolute_error_m"],
                    "true" if row["improved"] else "false",
                    row["epochs_without_improvement"],
                )
            )

    predictions_path = task_directory / "test_predictions.npz"
    np.savez(
        predictions_path,
        issue_positions=partition.test_positions.astype(np.int64),
        prediction_m=prediction_m,
        target_m=target_m,
        target_index=np.int64(target_index),
        target_mean_m=np.float64(mean),
        target_standard_deviation_m=np.float64(scale),
    )

    elapsed = time.perf_counter() - started
    identity = {
        "schema_version": contract.SCHEMA_VERSION,
        "experiment_id": contract.EXPERIMENT_ID,
        "task_id": task_id,
        "test_year": int(test_year),
        "inner_validation_year": partition.inner_validation_year,
        "training_years": list(partition.training_years),
        "target": target,
        "target_index": int(target_index),
        "condition": condition,
        "kept_stations": list(contract.kept_stations(target, condition)),
        "seed": int(seed),
        "device": str(device),
        "maximum_epochs": int(maximum_epochs),
        "completed_epochs": len(history_rows),
        "best_epoch": int(best_epoch),
        "best_inner_validation_1_10h_mean_absolute_error_m": float(best_metric),
        "normalization": {
            "input_mean_m": [float(v) for v in joint.normalization.input_mean_m],
            "input_standard_deviation_m": [
                float(v) for v in joint.normalization.input_standard_deviation_m
            ],
            "target_mean_m": [float(v) for v in joint.normalization.target_mean_m],
            "target_standard_deviation_m": [
                float(v) for v in joint.normalization.target_standard_deviation_m
            ],
            "tide_mean_m": float(joint.normalization.tide_mean_m),
            "tide_standard_deviation_m": float(
                joint.normalization.tide_standard_deviation_m
            ),
        },
        "training_sample_count": int(partition.training_positions.size),
        "inner_validation_sample_count": int(
            partition.inner_validation_positions.size
        ),
        "test_sample_count": int(partition.test_positions.size),
        "trainable_parameter_count": contract.EXPECTED_PARAMETER_COUNT,
        "elapsed_seconds": float(elapsed),
        "fold_isolation": isolation,
        "resource_gate": gate,
        "runtime_environment": runtime_environment,
        "input_identity": data.input_identity,
        "tide_model_sha256": contract.sha256_of(tide_model_path),
        "written_utc": datetime.now(timezone.utc).isoformat(),
    }
    identity_path = task_directory / "run_identity.json"
    identity_path.write_text(
        json.dumps(identity, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    artifacts = [
        checkpoint_path,
        history_path,
        predictions_path,
        identity_path,
    ]
    manifest = {
        "schema_version": contract.SCHEMA_VERSION,
        "experiment_id": contract.EXPERIMENT_ID,
        "task_id": task_id,
        "status": "completed",
        "artifacts": [
            {
                "relative_path": path.name,
                "byte_count": path.stat().st_size,
                "sha256": sha256_of(path),
            }
            for path in artifacts
        ],
    }
    (task_directory / "completion_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    print(
        json.dumps(
            {
                "task_id": task_id,
                "best_epoch": best_epoch,
                "completed_epochs": len(history_rows),
                "best_inner_validation_mae_m": best_metric,
                "test_sample_count": int(partition.test_positions.size),
                "elapsed_seconds": round(elapsed, 3),
                "node_name": runtime_environment.get("node_name"),
                "graphics_processor_unique_identifier": runtime_environment.get(
                    "graphics_processor_unique_identifier"
                ),
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task-index", type=int, default=-1)
    parser.add_argument("--test-year", type=int, default=0)
    parser.add_argument("--target", default="")
    parser.add_argument("--condition", default="")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--input-dir", default=str(data_module.DEFAULT_INPUT_DIR))
    parser.add_argument(
        "--tide-model", default=str(data_module.DEFAULT_TIDE_MODEL_PATH)
    )
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--max-epochs", type=int, default=0)
    arguments = parser.parse_args()

    # A SLURM array supplies one integer. Resolving it here, from the same
    # enumeration the registry uses, removes any chance of the array index and
    # the registry disagreeing about which task an index means.
    if arguments.task_index >= 0:
        tasks = contract.enumerate_tasks()
        if arguments.task_index >= len(tasks):
            print("TASK_INDEX_OUT_OF_RANGE: %d" % arguments.task_index)
            return 1
        selected = tasks[arguments.task_index]
        test_year = int(selected["test_year"])
        target = str(selected["target"])
        condition = str(selected["condition"])
        seed = int(selected["seed"])
    else:
        if not (
            arguments.test_year
            and arguments.target
            and arguments.condition
            and arguments.seed
        ):
            print("EITHER_TASK_INDEX_OR_ALL_FOUR_TASK_FLAGS_ARE_REQUIRED")
            return 1
        test_year = arguments.test_year
        target = arguments.target
        condition = arguments.condition
        seed = arguments.seed

    return train_one_task(
        test_year=test_year,
        target=target,
        condition=condition,
        seed=seed,
        output_root=Path(arguments.output_root),
        input_dir=Path(arguments.input_dir),
        tide_model_path=Path(arguments.tide_model),
        device_name=arguments.device,
        maximum_epochs_override=arguments.max_epochs or None,
    )


if __name__ == "__main__":
    sys.exit(main())
