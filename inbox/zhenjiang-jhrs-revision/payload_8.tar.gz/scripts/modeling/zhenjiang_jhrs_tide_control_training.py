"""Train one Transformer task of the JH:RS tide control (H1).

A copy of ``zhenjiang_oyv_n4_training.train_one_task`` with three changes and
nothing else:

1. The task list and the history masks come from the revision contract.
2. After the frozen loader returns, the astronomical tide is replaced by the
   registered array of this task's tide version and fold (frozen or fold). The
   frozen array is bit-for-bit the frozen loader's tide, so a frozen task trains
   exactly as the original family did on the same card.
3. The runtime environment is recorded, not required to equal the cluster's:
   this control runs on a local RTX 4070 Ti and compares the two tides on that
   one card. The platform-control precedent is
   scripts/analysis/platform_control_ladder_v1.py.

The training loop, improvement rule, loss, model, seeds and artefact layout are
the frozen ones.

Inputs
------
--task-index    index into the H1 task list
--output-root   destination; the task directory must not exist
--device        torch device, default cuda:0
--list-tasks    print the task ids as JSON and exit

Outputs
-------
<output-root>/<task_id>/ best_state.pt, training_history.csv,
test_predictions.npz, run_identity.json, completion_manifest.json

Usage
-----
python -X utf8 -B scripts/modeling/zhenjiang_jhrs_tide_control_training.py \
    --task-index 0 --output-root results/modeling/zhenjiang_jhrs_local_run_v1/h1_tasks
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

PROJECT_ROOT = Path(__file__).resolve().parents[2]
for _relative in ("scripts/modeling", "scripts/astronomical_tide", "scripts/analysis"):
    _candidate = str(PROJECT_ROOT / _relative)
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)

from water_level_joint_encoder_decoder_v2 import (  # noqa: E402
    FORECAST_LENGTH_HOURS,
    STATION_ORDER,
)
from tidal_fluvial_hidden_gauge_v1_training import (  # noqa: E402
    create_model,
    evaluate_standardized,
    mask_history,
    metric_improved,
    target_loss_m,
    target_validation_mae_m,
)
from zhenjiang_oyv_v1_training import resource_gate, sha256_of  # noqa: E402

import zhenjiang_jhrs_revision_contract as contract  # noqa: E402
import zhenjiang_oyv_v1_data as data_module  # noqa: E402


def train_one_task(
    task: dict,
    output_root: Path,
    input_dir: Path,
    tide_model_path: Path,
    device_name: str,
) -> int:
    test_year = int(task["test_year"])
    target = str(task["target"])
    condition = str(task["condition"])
    seed = int(task["seed"])
    tide_version = str(task["tide"])
    task_id = contract.h1_task_id(tide_version, test_year, target, condition, seed)
    task_directory = output_root / task_id
    if task_directory.exists():
        print("TASK_DIRECTORY_ALREADY_EXISTS: %s" % task_directory)
        return 1

    device = torch.device(device_name)
    runtime_environment = contract.runtime_identity()
    contract.apply_deterministic_settings(seed)

    output_root.mkdir(parents=True, exist_ok=True)
    gate = resource_gate(output_root, device)
    if not gate["passed"]:
        print("RESOURCE_GATE_FAILED: %s" % json.dumps(gate, sort_keys=True))
        return 1

    started = time.perf_counter()
    data = data_module.load_out_of_year_data(input_dir, tide_model_path)
    tide = contract.load_tide_array(tide_version, test_year, len(data.times_beijing))
    data = replace(data, astronomical_tide_m=tide)
    partition = data_module.build_fold_partition(data, test_year)
    isolation = data_module.assert_fold_isolation(data, partition)
    if isolation["finding_count"]:
        print("FOLD_ISOLATION_FAILED: %s" % json.dumps(isolation, sort_keys=True))
        return 1

    joint = data_module.build_joint_data(data, partition)
    training_dataset = data_module.build_dataset(joint, partition.training_positions)
    inner_loader = DataLoader(
        data_module.build_dataset(joint, partition.inner_validation_positions),
        batch_size=contract.FORMAL_BATCH_SIZE,
        shuffle=False,
        drop_last=False,
        num_workers=0,
    )
    test_loader = DataLoader(
        data_module.build_dataset(joint, partition.test_positions),
        batch_size=contract.FORMAL_BATCH_SIZE,
        shuffle=False,
        drop_last=False,
        num_workers=0,
    )

    target_index = STATION_ORDER.index(target)
    mask = contract.build_history_mask(target, condition).to(device)
    model = create_model().to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=contract.FORMAL_LEARNING_RATE,
        betas=contract.FORMAL_ADAM_BETAS,
        eps=contract.FORMAL_ADAM_EPSILON,
        weight_decay=contract.FORMAL_WEIGHT_DECAY,
        amsgrad=contract.FORMAL_AMSGRAD,
        fused=contract.FORMAL_FUSED,
    )
    generator = torch.Generator(device="cpu")
    generator.manual_seed(seed)

    scales = np.asarray(
        joint.normalization.target_standard_deviation_m, dtype=np.float32
    )
    means = np.asarray(joint.normalization.target_mean_m, dtype=np.float32)

    maximum_epochs = contract.FORMAL_MAXIMUM_EPOCHS
    best_metric = float("inf")
    best_epoch = 0
    best_state: dict[str, torch.Tensor] | None = None
    epochs_without_improvement = 0
    history_rows: list[dict[str, object]] = []

    for epoch in range(1, maximum_epochs + 1):
        loader = DataLoader(
            training_dataset,
            batch_size=contract.FORMAL_BATCH_SIZE,
            shuffle=True,
            generator=generator,
            num_workers=0,
            drop_last=False,
        )
        model.train()
        loss_sum = 0.0
        sample_count = 0
        for history, future_tide, targets in loader:
            history = history.to(device, non_blocking=True)
            future_tide = future_tide.to(device, non_blocking=True)
            targets = targets.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            predictions = model(mask_history(history, mask), future_tide)
            loss = target_loss_m(predictions, targets, scales, target_index)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                model.parameters(), contract.FORMAL_GRADIENT_CLIP_NORM
            )
            optimizer.step()
            loss_sum += float(loss.detach()) * history.shape[0]
            sample_count += history.shape[0]

        inner_predictions, inner_targets = evaluate_standardized(
            model, inner_loader, mask, device
        )
        metric = target_validation_mae_m(
            inner_predictions, inner_targets, scales, target_index
        )
        improved = metric_improved(
            best_metric, metric, contract.FORMAL_MINIMUM_DELTA_M
        )
        if improved:
            best_metric = metric
            best_epoch = epoch
            best_state = {
                key: value.detach().cpu().clone()
                for key, value in model.state_dict().items()
            }
            epochs_without_improvement = 0
        else:
            epochs_without_improvement += 1
        history_rows.append(
            {
                "epoch": epoch,
                "training_loss_m": loss_sum / max(sample_count, 1),
                "inner_validation_1_10h_mean_absolute_error_m": metric,
                "improved": bool(improved),
                "epochs_without_improvement": epochs_without_improvement,
            }
        )
        if epochs_without_improvement >= contract.FORMAL_PATIENCE_EPOCHS:
            break

    if best_state is None:
        print("NO_EPOCH_IMPROVED_THE_INITIAL_METRIC")
        return 1
    model.load_state_dict(best_state)

    test_predictions, test_targets = evaluate_standardized(
        model, test_loader, mask, device
    )
    scale = float(scales[target_index])
    mean = float(means[target_index])
    prediction_m = (
        test_predictions[:, :, target_index].astype(np.float64) * scale + mean
    ).astype(np.float32)
    target_m = (
        test_targets[:, :, target_index].astype(np.float64) * scale + mean
    ).astype(np.float32)
    if prediction_m.shape != (
        partition.test_positions.size,
        FORECAST_LENGTH_HOURS,
    ):
        raise RuntimeError("test prediction shape does not match the test fold")

    task_directory.mkdir(parents=True, exist_ok=False)
    checkpoint_path = task_directory / "best_state.pt"
    torch.save(best_state, checkpoint_path)

    history_path = task_directory / "training_history.csv"
    with history_path.open("w", encoding="utf-8", newline="") as handle:
        handle.write(
            "epoch,training_loss_m,"
            "inner_validation_1_10h_mean_absolute_error_m,"
            "improved,epochs_without_improvement\n"
        )
        for row in history_rows:
            handle.write(
                "%d,%.17g,%.17g,%s,%d\n"
                % (
                    row["epoch"],
                    row["training_loss_m"],
                    row["inner_validation_1_10h_mean_absolute_error_m"],
                    "true" if row["improved"] else "false",
                    row["epochs_without_improvement"],
                )
            )

    predictions_path = task_directory / "test_predictions.npz"
    np.savez(
        predictions_path,
        issue_positions=partition.test_positions.astype(np.int64),
        prediction_m=prediction_m,
        target_m=target_m,
        target_index=np.int64(target_index),
        target_mean_m=np.float64(mean),
        target_standard_deviation_m=np.float64(scale),
    )

    elapsed = time.perf_counter() - started
    identity = {
        "schema_version": contract.SCHEMA_VERSION,
        "experiment_id": contract.EXPERIMENT_ID,
        "family": "h1_tide_control",
        "task_id": task_id,
        "tide_version": tide_version,
        "tide_array_sha256": contract.sha256_of(contract.tide_file(tide_version, test_year)),
        "test_year": int(test_year),
        "inner_validation_year": partition.inner_validation_year,
        "training_years": list(partition.training_years),
        "target": target,
        "target_index": int(target_index),
        "condition": condition,
        "kept_stations": list(contract.kept_stations(target, condition)),
        "history_mask": [
            float(v) for v in contract.build_history_mask(target, condition).reshape(-1)
        ],
        "seed": int(seed),
        "device": str(device),
        "maximum_epochs": int(maximum_epochs),
        "completed_epochs": len(history_rows),
        "best_epoch": int(best_epoch),
        "best_inner_validation_1_10h_mean_absolute_error_m": float(best_metric),
        "normalization": {
            "input_mean_m": [float(v) for v in joint.normalization.input_mean_m],
            "input_standard_deviation_m": [
                float(v) for v in joint.normalization.input_standard_deviation_m
            ],
            "target_mean_m": [float(v) for v in joint.normalization.target_mean_m],
            "target_standard_deviation_m": [
                float(v) for v in joint.normalization.target_standard_deviation_m
            ],
            "tide_mean_m": float(joint.normalization.tide_mean_m),
            "tide_standard_deviation_m": float(
                joint.normalization.tide_standard_deviation_m
            ),
        },
        "training_sample_count": int(partition.training_positions.size),
        "inner_validation_sample_count": int(
            partition.inner_validation_positions.size
        ),
        "test_sample_count": int(partition.test_positions.size),
        "trainable_parameter_count": contract.EXPECTED_PARAMETER_COUNT,
        "elapsed_seconds": float(elapsed),
        "fold_isolation": isolation,
        "resource_gate": gate,
        "runtime_environment_recorded_not_required": runtime_environment,
        "input_identity": data.input_identity,
        "tide_model_sha256": contract.sha256_of(tide_model_path),
        "written_utc": datetime.now(timezone.utc).isoformat(),
    }
    identity_path = task_directory / "run_identity.json"
    identity_path.write_text(
        json.dumps(identity, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    artifacts = [checkpoint_path, history_path, predictions_path, identity_path]
    manifest = {
        "schema_version": contract.SCHEMA_VERSION,
        "experiment_id": contract.EXPERIMENT_ID,
        "task_id": task_id,
        "status": "completed",
        "artifacts": [
            {
                "relative_path": path.name,
                "byte_count": path.stat().st_size,
                "sha256": sha256_of(path),
            }
            for path in artifacts
        ],
    }
    (task_directory / "completion_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    print(
        json.dumps(
            {
                "task_id": task_id,
                "best_epoch": best_epoch,
                "completed_epochs": len(history_rows),
                "elapsed_seconds": round(elapsed, 3),
            },
            sort_keys=True,
        )
    )
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task-index", type=int, default=-1)
    parser.add_argument("--output-root", default="")
    parser.add_argument("--input-dir", default=str(data_module.DEFAULT_INPUT_DIR))
    parser.add_argument("--tide-model", default=str(data_module.DEFAULT_TIDE_MODEL_PATH))
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--list-tasks", action="store_true")
    arguments = parser.parse_args()

    tasks = contract.h1_tasks()
    if arguments.list_tasks:
        print(json.dumps([task["task_id"] for task in tasks]))
        return 0
    if not 0 <= arguments.task_index < len(tasks) or not arguments.output_root:
        print("TASK_INDEX_OUT_OF_RANGE_OR_NO_OUTPUT_ROOT")
        return 1
    return train_one_task(
        tasks[arguments.task_index],
        output_root=Path(arguments.output_root),
        input_dir=Path(arguments.input_dir),
        tide_model_path=Path(arguments.tide_model),
        device_name=arguments.device,
    )


if __name__ == "__main__":
    sys.exit(main())
