#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Train one registered target-specific hidden-gauge task.

Inputs:
    One immutable registry task and the frozen 2017–2023 data prefix.

Outputs:
    One exclusive run directory containing a checkpoint, history, validation
    predictions, validation metrics, run identity and a completion manifest.

Example:
    Imported by run_tidal_fluvial_hidden_gauge_v1_registry.py.
"""

from __future__ import annotations

import math
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import subprocess
import sys
import time
from decimal import Decimal
from typing import Mapping, Sequence

import numpy as np
import pandas as pd
import psutil
import scipy
import sklearn
import threadpoolctl
import torch
from torch.utils.data import DataLoader

from water_level_joint_encoder_decoder_v2 import (
    FORECAST_LENGTH_HOURS,
    JointWaterLevelDataset,
    RiverOrderTransformerEncoderDecoder,
    SMOOTH_ABSOLUTE_ERROR_TRANSITION_M,
    STATION_ORDER,
    trainable_parameter_count,
)


PROJECT_ROOT = Path(__file__).resolve().parents[2]
ANALYSIS_DIR = PROJECT_ROOT / "scripts" / "analysis"
if str(ANALYSIS_DIR) not in sys.path:
    sys.path.insert(0, str(ANALYSIS_DIR))

from tidal_fluvial_hidden_gauge_v1_contract import (  # noqa: E402
    EXPECTED_PARAMETER_COUNT,
    EXPECTED_RUNTIME_ENVIRONMENT,
    build_history_mask,
)


REPORT_HOUR_COUNT = 10
FORMAL_BATCH_SIZE = 128
FORMAL_MAXIMUM_EPOCHS = 36
FORMAL_PATIENCE_EPOCHS = 4
FORMAL_MINIMUM_DELTA_M = 0.0001
FORMAL_GRADIENT_CLIP_NORM = 1.0
FORMAL_LEARNING_RATE = 0.001
FORMAL_WEIGHT_DECAY = 0.0001
FORMAL_ADAM_BETAS = (0.9, 0.999)
FORMAL_ADAM_EPSILON = 1e-8


def runtime_environment_identity() -> dict[str, object]:
    """Capture the exact numerical software and graphics environment."""
    if not torch.cuda.is_available():
        raise RuntimeError("runtime environment requires cuda:0")
    properties = torch.cuda.get_device_properties(0)
    completed = subprocess.run(
        [
            "nvidia-smi",
            "--query-gpu=driver_version,uuid",
            "--format=csv,noheader,nounits",
            "--id=0",
        ],
        check=True,
        capture_output=True,
        text=True,
        timeout=15,
    )
    parts = [part.strip() for part in completed.stdout.strip().split(",")]
    if len(parts) != 2:
        raise RuntimeError("graphics driver identity could not be parsed")
    threadpool_rows = sorted(
        threadpoolctl.threadpool_info(),
        key=lambda row: (
            str(row.get("prefix")),
            str(row.get("filepath")),
        ),
    )
    threadpool_material = (
        json.dumps(
            threadpool_rows,
            sort_keys=True,
            separators=(",", ":"),
        )
        + "\n"
    ).encode("utf-8")
    return {
        "python_executable": str(Path(sys.executable).resolve()),
        "python_version": platform.python_version(),
        "operating_system": platform.platform(),
        "numpy_version": np.__version__,
        "pandas_version": pd.__version__,
        "scipy_version": scipy.__version__,
        "scikit_learn_version": sklearn.__version__,
        "psutil_version": psutil.__version__,
        "threadpoolctl_version": threadpoolctl.__version__,
        "threadpool_configuration_sha256": hashlib.sha256(
            threadpool_material
        ).hexdigest(),
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "cudnn_version": torch.backends.cudnn.version(),
        "graphics_processor_name": properties.name,
        "graphics_processor_capability": list(
            torch.cuda.get_device_capability(0)
        ),
        "graphics_processor_driver_version": parts[0],
        "graphics_processor_unique_identifier": parts[1],
    }


def require_frozen_runtime_environment() -> dict[str, object]:
    """Reject execution when any frozen numerical environment field drifts."""
    identity = runtime_environment_identity()
    if identity != EXPECTED_RUNTIME_ENVIRONMENT:
        raise RuntimeError(
            "runtime environment differs from preregistration: "
            + json.dumps(identity, sort_keys=True)
        )
    return identity


def _validate_prediction_tensors(
    predictions: torch.Tensor,
    targets: torch.Tensor,
    target_standard_deviations_m: np.ndarray | torch.Tensor,
    target_index: int,
) -> torch.Tensor:
    expected = (FORECAST_LENGTH_HOURS, len(STATION_ORDER))
    if (
        predictions.ndim != 3
        or predictions.shape[1:] != expected
        or targets.shape != predictions.shape
    ):
        raise ValueError("prediction shape must be [batch, 24, 6]")
    if predictions.shape[0] == 0:
        raise ValueError("prediction batch must not be empty")
    if predictions.dtype != torch.float32 or targets.dtype != torch.float32:
        raise ValueError("prediction and target must use float32")
    if predictions.device != targets.device:
        raise ValueError("prediction and target devices differ")
    if not 0 <= target_index < len(STATION_ORDER):
        raise ValueError("target index is outside station order")
    scales = torch.as_tensor(
        target_standard_deviations_m,
        dtype=torch.float32,
        device=predictions.device,
    )
    if scales.shape != (len(STATION_ORDER),):
        raise ValueError("target standard deviation shape must be [6]")
    if (
        not torch.isfinite(predictions).all()
        or not torch.isfinite(targets).all()
        or not torch.isfinite(scales).all()
        or torch.any(scales <= 0)
    ):
        raise ValueError("loss inputs must be finite with positive scales")
    return scales


def target_loss_m(
    predictions_standardized: torch.Tensor,
    targets_standardized: torch.Tensor,
    target_standard_deviations_m: np.ndarray | torch.Tensor,
    target_index: int,
) -> torch.Tensor:
    """Smooth absolute error for one target and forecast hours 1–10."""
    scales = _validate_prediction_tensors(
        predictions_standardized,
        targets_standardized,
        target_standard_deviations_m,
        target_index,
    )
    error_m = (
        predictions_standardized[:, :REPORT_HOUR_COUNT, target_index]
        - targets_standardized[:, :REPORT_HOUR_COUNT, target_index]
    ) * scales[target_index]
    absolute_error_m = torch.abs(error_m)
    transition = SMOOTH_ABSOLUTE_ERROR_TRANSITION_M
    element_loss = torch.where(
        absolute_error_m < transition,
        0.5 * absolute_error_m.square() / transition,
        absolute_error_m - 0.5 * transition,
    )
    return element_loss.mean()


def target_validation_mae_m(
    predictions_standardized: np.ndarray,
    targets_standardized: np.ndarray,
    target_standard_deviations_m: np.ndarray,
    target_index: int,
) -> float:
    """Mean absolute error in metres for one target and hours 1–10."""
    predictions = np.asarray(predictions_standardized, dtype=np.float64)
    targets = np.asarray(targets_standardized, dtype=np.float64)
    scales = np.asarray(target_standard_deviations_m, dtype=np.float64)
    expected = (FORECAST_LENGTH_HOURS, len(STATION_ORDER))
    if (
        predictions.ndim != 3
        or predictions.shape[1:] != expected
        or targets.shape != predictions.shape
    ):
        raise ValueError("prediction shape must be [sample, 24, 6]")
    if predictions.shape[0] == 0:
        raise ValueError("metric sample must not be empty")
    if scales.shape != (len(STATION_ORDER),) or np.any(scales <= 0):
        raise ValueError("target standard deviation shape must be [6]")
    if (
        not np.isfinite(predictions).all()
        or not np.isfinite(targets).all()
        or not np.isfinite(scales).all()
    ):
        raise ValueError("metric inputs must be finite")
    errors_m = (
        predictions[:, :REPORT_HOUR_COUNT, target_index]
        - targets[:, :REPORT_HOUR_COUNT, target_index]
    ) * scales[target_index]
    return float(np.mean(np.abs(errors_m)))


def mask_history(history: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    """Apply a standardized-history mask without mutating the source tensor."""
    if history.ndim != 3 or history.shape[1:] != (24, len(STATION_ORDER)):
        raise ValueError("history shape must be [batch, 24, 6]")
    if mask.shape != (1, 1, len(STATION_ORDER)):
        raise ValueError("mask shape must be [1, 1, 6]")
    if history.dtype != torch.float32 or mask.dtype != torch.float32:
        raise ValueError("history and mask must use float32")
    return history * mask.to(device=history.device)


def metric_improved(
    best_metric_m: float,
    current_metric_m: float,
    minimum_delta_m: float,
) -> bool:
    """Match the frozen Decimal minimum-delta comparison."""
    if not (
        math.isfinite(current_metric_m)
        and math.isfinite(minimum_delta_m)
        and minimum_delta_m > 0
    ):
        raise ValueError("current metric and minimum delta must be finite")
    if math.isinf(best_metric_m) and best_metric_m > 0:
        return True
    if not math.isfinite(best_metric_m):
        raise ValueError("best metric must be finite or positive infinity")
    return (
        Decimal(str(best_metric_m)) - Decimal(str(current_metric_m))
        >= Decimal(str(minimum_delta_m))
    )


def create_model() -> RiverOrderTransformerEncoderDecoder:
    """Create the unchanged frozen-core model structure."""
    model = RiverOrderTransformerEncoderDecoder()
    count = trainable_parameter_count(model)
    if count != EXPECTED_PARAMETER_COUNT:
        raise RuntimeError(
            f"model parameter count changed: {count} != "
            f"{EXPECTED_PARAMETER_COUNT}"
        )
    return model


def apply_deterministic_settings(seed: int) -> None:
    """Apply the frozen deterministic CUDA and random-number settings."""
    if type(seed) is not int or seed < 0:
        raise ValueError("seed must be a nonnegative integer")
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(True, warn_only=False)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    if hasattr(torch.backends.cuda.matmul, "allow_tf32"):
        torch.backends.cuda.matmul.allow_tf32 = False
    if hasattr(torch.backends.cudnn, "allow_tf32"):
        torch.backends.cudnn.allow_tf32 = False


@torch.no_grad()
def evaluate_standardized(
    model: torch.nn.Module,
    loader: DataLoader,
    mask: torch.Tensor,
    device: torch.device,
) -> tuple[np.ndarray, np.ndarray]:
    """Return full standardized prediction and target arrays."""
    model.eval()
    predictions: list[np.ndarray] = []
    targets: list[np.ndarray] = []
    for history, future_tide, batch_targets in loader:
        history = history.to(device, non_blocking=True)
        future_tide = future_tide.to(device, non_blocking=True)
        output = model(mask_history(history, mask), future_tide)
        predictions.append(output.detach().cpu().numpy())
        targets.append(batch_targets.numpy())
    if not predictions:
        raise RuntimeError("evaluation loader produced no batches")
    return np.concatenate(predictions), np.concatenate(targets)


def per_hour_metric_rows(
    targets_m: np.ndarray,
    predictions_m: np.ndarray,
) -> list[dict[str, float | int]]:
    """Calculate validation metrics separately for forecast hours 1–10."""
    actual = np.asarray(targets_m, dtype=np.float64)
    predicted = np.asarray(predictions_m, dtype=np.float64)
    if actual.shape != predicted.shape or actual.ndim != 2:
        raise ValueError("metric arrays must be equal two-dimensional arrays")
    if actual.shape[1] != REPORT_HOUR_COUNT or actual.shape[0] == 0:
        raise ValueError("metric arrays must have ten nonempty forecast hours")
    if not np.isfinite(actual).all() or not np.isfinite(predicted).all():
        raise ValueError("metric arrays contain a nonfinite value")
    rows: list[dict[str, float | int]] = []
    for hour_index in range(REPORT_HOUR_COUNT):
        targets = actual[:, hour_index]
        predictions = predicted[:, hour_index]
        errors = predictions - targets
        denominator = float(
            np.sum(np.square(targets - targets.mean()))
        )
        rows.append(
            {
                "forecast_hour": hour_index + 1,
                "sample_count": len(targets),
                "mean_absolute_error_m": float(
                    np.mean(np.abs(errors))
                ),
                "root_mean_squared_error_m": float(
                    np.sqrt(np.mean(np.square(errors)))
                ),
                "mean_error_m": float(np.mean(errors)),
                "nash_sutcliffe_efficiency": (
                    float("nan")
                    if denominator <= 0
                    else 1.0
                    - float(np.sum(np.square(errors))) / denominator
                ),
            }
        )
    return rows


def prepare_atomic_output(destination: str | Path) -> Path:
    """Create an exclusive incomplete sibling for one run."""
    destination = Path(destination)
    if destination.exists():
        raise FileExistsError(f"run destination already exists: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    incomplete = destination.parent / (
        f"{destination.name}.incomplete_pid_{os.getpid()}"
    )
    if incomplete.exists():
        raise FileExistsError(
            f"incomplete run directory already exists: {incomplete}"
        )
    incomplete.mkdir()
    return incomplete


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _write_json_exclusive(path: Path, payload: object) -> None:
    content = json.dumps(
        payload,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
    ) + "\n"
    with path.open("x", encoding="utf-8", newline="") as handle:
        handle.write(content)


def _resource_checkpoint(resource_monitor, checkpoint: str) -> None:
    if resource_monitor is not None:
        resource_monitor.raise_if_unsafe(checkpoint)


def _records_or_default(
    override: Sequence[object] | None,
    default: Sequence[object],
) -> tuple[object, ...]:
    return tuple(default if override is None else override)


def train_one_registered_task(
    task: Mapping[str, object],
    data,
    output_dir: str | Path,
    resource_monitor=None,
    training_records_override: Sequence[object] | None = None,
    validation_records_override: Sequence[object] | None = None,
    maximum_epochs_override: int | None = None,
) -> dict[str, object]:
    """Train, validate and atomically publish one registry task."""
    target = str(task["target"])
    condition = str(task["condition"])
    seed = int(task["seed"])
    target_index = int(task["target_index"])
    if STATION_ORDER[target_index] != target:
        raise ValueError("task target index does not match station order")
    output_dir = Path(output_dir)
    incomplete_dir = prepare_atomic_output(output_dir)
    training_records = _records_or_default(
        training_records_override,
        data.training_records,
    )
    validation_records = _records_or_default(
        validation_records_override,
        data.validation_records,
    )
    maximum_epochs = (
        FORMAL_MAXIMUM_EPOCHS
        if maximum_epochs_override is None
        else int(maximum_epochs_override)
    )
    if maximum_epochs <= 0 or maximum_epochs > FORMAL_MAXIMUM_EPOCHS:
        raise ValueError("maximum epoch override is outside 1 through 36")
    start_time = time.monotonic()
    apply_deterministic_settings(seed)
    device = torch.device(str(task.get("device", "cuda:0")))
    model = create_model().to(device)
    runtime_environment = require_frozen_runtime_environment()
    mask = build_history_mask(target, condition).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=FORMAL_LEARNING_RATE,
        betas=FORMAL_ADAM_BETAS,
        eps=FORMAL_ADAM_EPSILON,
        weight_decay=FORMAL_WEIGHT_DECAY,
        amsgrad=False,
        fused=False,
    )
    training_dataset = JointWaterLevelDataset(data, training_records)
    validation_loader = DataLoader(
        JointWaterLevelDataset(data, validation_records),
        batch_size=FORMAL_BATCH_SIZE,
        shuffle=False,
        drop_last=False,
        num_workers=0,
    )
    generator = torch.Generator(device="cpu")
    generator.manual_seed(seed)
    scales = np.asarray(
        data.normalization.target_standard_deviation_m,
        dtype=np.float32,
    )
    means = np.asarray(
        data.normalization.target_mean_m,
        dtype=np.float32,
    )
    best_metric = float("inf")
    best_epoch = 0
    best_state: dict[str, torch.Tensor] | None = None
    epochs_without_improvement = 0
    history_rows: list[dict[str, object]] = []
    _resource_checkpoint(resource_monitor, "after_model_creation")
    for epoch in range(1, maximum_epochs + 1):
        loader = DataLoader(
            training_dataset,
            batch_size=FORMAL_BATCH_SIZE,
            shuffle=True,
            generator=generator,
            num_workers=0,
            drop_last=False,
        )
        model.train()
        loss_sum = 0.0
        sample_count = 0
        for history, future_tide, targets in loader:
            history = history.to(device, non_blocking=True)
            future_tide = future_tide.to(device, non_blocking=True)
            targets = targets.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            predictions = model(mask_history(history, mask), future_tide)
            loss = target_loss_m(
                predictions,
                targets,
                scales,
                target_index,
            )
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                model.parameters(),
                FORMAL_GRADIENT_CLIP_NORM,
            )
            optimizer.step()
            loss_sum += float(loss.detach()) * history.shape[0]
            sample_count += history.shape[0]
        validation_predictions, validation_targets = evaluate_standardized(
            model,
            validation_loader,
            mask,
            device,
        )
        validation_metric = target_validation_mae_m(
            validation_predictions,
            validation_targets,
            scales,
            target_index,
        )
        improved = metric_improved(
            best_metric,
            validation_metric,
            FORMAL_MINIMUM_DELTA_M,
        )
        if improved:
            best_metric = validation_metric
            best_epoch = epoch
            best_state = {
                key: value.detach().cpu().clone()
                for key, value in model.state_dict().items()
            }
            epochs_without_improvement = 0
        else:
            epochs_without_improvement += 1
        history_rows.append(
            {
                "epoch": epoch,
                "training_target_smooth_absolute_error_m": (
                    loss_sum / sample_count
                ),
                "validation_target_1_10h_mean_absolute_error_m": (
                    validation_metric
                ),
                "improved": improved,
                "epochs_without_improvement": epochs_without_improvement,
                "elapsed_seconds": time.monotonic() - start_time,
            }
        )
        _resource_checkpoint(resource_monitor, f"epoch_{epoch}")
        if epochs_without_improvement >= FORMAL_PATIENCE_EPOCHS:
            break
    if best_state is None:
        raise RuntimeError("training produced no best checkpoint")
    model.load_state_dict(best_state)
    checkpoint_path = incomplete_dir / "best_state.pt"
    torch.save(best_state, checkpoint_path)
    validation_predictions, validation_targets = evaluate_standardized(
        model,
        validation_loader,
        mask,
        device,
    )
    predictions_m = (
        validation_predictions[:, :REPORT_HOUR_COUNT, target_index]
        * scales[target_index]
        + means[target_index]
    )
    targets_m = (
        validation_targets[:, :REPORT_HOUR_COUNT, target_index]
        * scales[target_index]
        + means[target_index]
    )
    prediction_path = incomplete_dir / "validation_predictions.npz"
    np.savez_compressed(
        prediction_path,
        issue_positions=np.asarray(
            [int(record.issue_position) for record in validation_records],
            dtype=np.int32,
        ),
        predictions_m=np.asarray(predictions_m, dtype=np.float32),
        targets_m=np.asarray(targets_m, dtype=np.float32),
    )
    metrics_path = incomplete_dir / "validation_metrics.csv"
    pd.DataFrame(
        per_hour_metric_rows(targets_m, predictions_m)
    ).to_csv(
        metrics_path,
        index=False,
        encoding="utf-8",
        lineterminator="\n",
    )
    history_path = incomplete_dir / "training_history.csv"
    pd.DataFrame(history_rows).to_csv(
        history_path,
        index=False,
        encoding="utf-8",
        lineterminator="\n",
    )
    run_identity_path = incomplete_dir / "run_identity.json"
    run_identity = {
        "schema_version": 1,
        "experiment_family": "tidal_fluvial_hidden_gauge_v1",
        "task_id": task["task_id"],
        "target": target,
        "target_index": target_index,
        "condition": condition,
        "kept_stations": task["kept_stations"],
        "seed": seed,
        "device": str(device),
        "model_structure": "RiverOrderTransformerEncoderDecoder",
        "trainable_parameter_count": trainable_parameter_count(model),
        "training_record_count": len(training_records),
        "validation_record_count": len(validation_records),
        "maximum_epochs": maximum_epochs,
        "completed_epochs": len(history_rows),
        "best_epoch": best_epoch,
        "best_validation_1_10h_mean_absolute_error_m": best_metric,
        "test_target_rows_read": int(data.test_target_rows_read),
        "test_target_values_loaded": int(data.test_target_values_loaded),
        "future_observation_input_count": int(
            data.future_observation_input_count
        ),
        "elapsed_seconds": time.monotonic() - start_time,
        "execution_bindings": dict(task.get("execution_bindings", {})),
        "runtime_environment": runtime_environment,
    }
    _write_json_exclusive(run_identity_path, run_identity)
    _resource_checkpoint(resource_monitor, "after_final_evaluation")
    artifacts = [
        checkpoint_path,
        history_path,
        prediction_path,
        metrics_path,
        run_identity_path,
    ]
    completion_manifest = {
        "schema_version": 1,
        "task_id": task["task_id"],
        "status": "completed",
        "artifacts": [
            {
                "relative_path": path.relative_to(incomplete_dir).as_posix(),
                "byte_count": path.stat().st_size,
                "sha256": _sha256(path),
            }
            for path in artifacts
        ],
    }
    completion_path = incomplete_dir / "completion_manifest.json"
    _write_json_exclusive(completion_path, completion_manifest)
    incomplete_dir.rename(output_dir)
    return {
        **run_identity,
        "completion_manifest_path": str(
            output_dir / completion_path.name
        ),
        "completion_manifest_sha256": _sha256(
            output_dir / completion_path.name
        ),
    }
