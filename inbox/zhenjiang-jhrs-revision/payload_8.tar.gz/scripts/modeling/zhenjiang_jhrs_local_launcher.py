"""Run the JH:RS revision's local work unattended on this machine.

Two queues share the machine with whatever else is running on it:
- H1, the Transformer tide control, on the GPU. A new task starts only while the
  host has at least --h1-min-free-gb of free memory, and at most
  --h1-max-concurrency run at once. A task refused by its own resource gate is
  put back at the front of the queue and retried after a pause; that is not a
  failure.
- The hybrid ladder on the CPU, as --hybrid-workers worker processes.

Restartable. H1 tasks with a completion manifest are skipped; an incomplete
task directory is moved to quarantine/ before the task is run again. Hybrid
workers skip finished units themselves. Creating <run-root>/STOP makes the
launcher start nothing new and exit once running work ends.

The launcher imports only the standard library, so it can be started detached
(for example through WMI) without the conda environment being activated; it
builds the environment of its child processes itself.

Inputs
------
--run-root               results root of this run
--python                 interpreter for the child processes
--h1-max-concurrency     default 3
--h1-min-free-gb         default 5.6
--hybrid-workers         default 1
--h1-attempts            attempts per task before it is recorded as failed

Outputs
-------
<run-root>/h1_tasks/<task_id>/   one directory per finished H1 task
<run-root>/hybrid/units/         hybrid unit files
<run-root>/logs/                 one log per H1 task and per hybrid worker
<run-root>/events.jsonl          start and finish of every child process
<run-root>/STATUS.json           progress, refreshed every minute

Usage
-----
python -X utf8 -B scripts/modeling/zhenjiang_jhrs_local_launcher.py \
    --run-root results/modeling/zhenjiang_jhrs_local_run_v1
"""

from __future__ import annotations

import argparse
import ctypes
import json
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
TRAINER = PROJECT_ROOT / "scripts" / "modeling" / "zhenjiang_jhrs_tide_control_training.py"
HYBRID = PROJECT_ROOT / "scripts" / "analysis" / "zhenjiang_jhrs_hybrid_ladder_v1.py"
CREATE_NO_WINDOW = 0x08000000
GATE_PAUSE_SECONDS = 180
START_SPACING_SECONDS = 45
POLL_SECONDS = 10


class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_ulong),
        ("dwMemoryLoad", ctypes.c_ulong),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


WINDOWS = os.name == "nt"
NO_WINDOW_FLAGS = CREATE_NO_WINDOW if WINDOWS else 0


def free_memory_gb() -> float:
    if WINDOWS:
        status = MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status))
        return status.ullAvailPhys / 1e9
    with open("/proc/meminfo", encoding="ascii") as handle:
        for line in handle:
            if line.startswith("MemAvailable:"):
                return int(line.split()[1]) * 1024 / 1e9
    return float("inf")


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def child_environment(python: Path, threads: int) -> dict:
    base = python.parent
    if WINDOWS:
        prefix = [base, base / "Library" / "mingw-w64" / "bin", base / "Library" / "usr" / "bin",
                  base / "Library" / "bin", base / "Scripts", base / "bin"]
    else:
        prefix = [base]
    environment = dict(os.environ)
    environment["PATH"] = os.pathsep.join(str(path) for path in prefix) + os.pathsep + environment.get("PATH", "")
    environment["CONDA_PREFIX"] = str(base)
    environment["PYTHONUNBUFFERED"] = "1"
    environment["PYTHONIOENCODING"] = "utf-8"
    environment["OMP_NUM_THREADS"] = str(threads)
    environment["MKL_NUM_THREADS"] = str(threads)
    return environment


class Launcher:
    def __init__(self, arguments):
        self.root = Path(arguments.run_root).resolve()
        self.python = Path(arguments.python)
        self.max_concurrency = arguments.h1_max_concurrency
        self.min_free_gb = arguments.h1_min_free_gb
        self.hybrid_workers = arguments.hybrid_workers
        self.attempt_limit = arguments.h1_attempts
        self.tasks_dir = self.root / "h1_tasks"
        self.hybrid_dir = self.root / "hybrid"
        self.logs = self.root / "logs"
        self.quarantine = self.root / "quarantine"
        for path in (self.tasks_dir, self.hybrid_dir / "units", self.logs / "h1",
                     self.logs / "hybrid", self.quarantine):
            path.mkdir(parents=True, exist_ok=True)
        self.events = (self.root / "events.jsonl").open("a", encoding="utf-8")
        self.task_ids: list[str] = []
        self.pending: list[int] = []
        self.running: dict[int, tuple[subprocess.Popen, float]] = {}
        self.attempts: dict[int, int] = {}
        self.failed: list[str] = []
        self.gate_refusals = 0
        self.hold_until = 0.0
        self.last_start = 0.0
        self.hybrid: dict[int, subprocess.Popen] = {}
        self.hybrid_restarts: dict[int, int] = {}
        self.hybrid_done: dict[int, int] = {}
        self.started = now()

    def event(self, **fields) -> None:
        fields["utc"] = now()
        self.events.write(json.dumps(fields, sort_keys=True) + "\n")
        self.events.flush()

    def complete(self, task_id: str) -> bool:
        return (self.tasks_dir / task_id / "completion_manifest.json").exists()

    def set_aside(self, task_id: str) -> None:
        path = self.tasks_dir / task_id
        if path.exists() and not self.complete(task_id):
            stamp = datetime.now().strftime("%Y%m%d%H%M%S")
            shutil.move(str(path), str(self.quarantine / ("%s__%s" % (task_id, stamp))))
            self.event(kind="quarantined", task=task_id)

    def load_tasks(self) -> None:
        output = subprocess.run(
            [str(self.python), "-X", "utf8", "-B", str(TRAINER), "--list-tasks"],
            capture_output=True, text=True, env=child_environment(self.python, 2),
            cwd=str(PROJECT_ROOT), creationflags=NO_WINDOW_FLAGS, check=True,
        )
        self.task_ids = json.loads(output.stdout.strip().splitlines()[-1])
        for index, task_id in enumerate(self.task_ids):
            if not self.complete(task_id):
                self.set_aside(task_id)
                self.pending.append(index)

    def start_hybrid(self, worker: int) -> None:
        log = (self.logs / "hybrid" / ("worker_%d.log" % worker)).open("a", encoding="utf-8")
        process = subprocess.Popen(
            [str(self.python), "-X", "utf8", "-B", str(HYBRID), "--output-root", str(self.hybrid_dir),
             "--worker", str(worker), "--workers", str(self.hybrid_workers)],
            stdout=log, stderr=subprocess.STDOUT, cwd=str(PROJECT_ROOT),
            env=child_environment(self.python, 4), creationflags=NO_WINDOW_FLAGS,
        )
        self.hybrid[worker] = process
        self.event(kind="hybrid_start", worker=worker, pid=process.pid)

    def start_task(self, index: int) -> None:
        task_id = self.task_ids[index]
        log = (self.logs / "h1" / (task_id + ".log")).open("a", encoding="utf-8")
        process = subprocess.Popen(
            [str(self.python), "-X", "utf8", "-B", str(TRAINER), "--task-index", str(index),
             "--output-root", str(self.tasks_dir)],
            stdout=log, stderr=subprocess.STDOUT, cwd=str(PROJECT_ROOT),
            env=child_environment(self.python, 4), creationflags=NO_WINDOW_FLAGS,
        )
        self.running[index] = (process, time.time())
        self.attempts[index] = self.attempts.get(index, 0) + 1
        self.last_start = time.time()
        self.event(kind="h1_start", task=task_id, index=index, pid=process.pid,
                   attempt=self.attempts[index], free_gb=round(free_memory_gb(), 2))

    def finish_task(self, index: int, code: int, elapsed: float) -> None:
        task_id = self.task_ids[index]
        log_text = (self.logs / "h1" / (task_id + ".log")).read_text(encoding="utf-8", errors="replace")
        tail = log_text[-4000:]
        if code == 0 and self.complete(task_id):
            self.event(kind="h1_done", task=task_id, seconds=round(elapsed, 1))
            return
        if "RESOURCE_GATE_FAILED" in tail and not (self.tasks_dir / task_id).exists():
            self.attempts[index] -= 1
            self.gate_refusals += 1
            self.pending.insert(0, index)
            self.hold_until = time.time() + GATE_PAUSE_SECONDS
            self.event(kind="h1_gate_refused", task=task_id)
            return
        self.set_aside(task_id)
        self.event(kind="h1_failed", task=task_id, code=code, attempt=self.attempts[index])
        if self.attempts[index] < self.attempt_limit:
            self.pending.append(index)
        else:
            self.failed.append(task_id)

    def write_status(self) -> None:
        done = sum(1 for task_id in self.task_ids if self.complete(task_id))
        units = len(list((self.hybrid_dir / "units").glob("*.json")))
        status = {
            "started_utc": self.started,
            "updated_utc": now(),
            "h1": {
                "total": len(self.task_ids),
                "complete": done,
                "running": [self.task_ids[index] for index in self.running],
                "pending": len(self.pending),
                "failed": self.failed,
                "gate_refusals": self.gate_refusals,
            },
            "hybrid": {
                "units_complete": units,
                "units_total": 1328,
                "workers_running": [worker for worker, process in self.hybrid.items()
                                    if process.poll() is None],
                "worker_exit_codes": {str(worker): code for worker, code in self.hybrid_done.items()},
            },
            "free_memory_gb": round(free_memory_gb(), 2),
            "stop_requested": (self.root / "STOP").exists(),
        }
        temporary = self.root / "STATUS.json.tmp"
        temporary.write_text(json.dumps(status, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, self.root / "STATUS.json")

    def run(self) -> int:
        self.event(kind="launcher_start", pid=os.getpid())
        self.load_tasks()
        for worker in range(self.hybrid_workers):
            self.start_hybrid(worker)
        last_status = 0.0
        while True:
            stop = (self.root / "STOP").exists()
            for worker, process in list(self.hybrid.items()):
                code = process.poll()
                if code is None or worker in self.hybrid_done:
                    continue
                if code == 0:
                    self.hybrid_done[worker] = 0
                    self.event(kind="hybrid_done", worker=worker)
                elif self.hybrid_restarts.get(worker, 0) < 3 and not stop:
                    self.hybrid_restarts[worker] = self.hybrid_restarts.get(worker, 0) + 1
                    self.event(kind="hybrid_restart", worker=worker, code=code)
                    self.start_hybrid(worker)
                else:
                    self.hybrid_done[worker] = code
                    self.event(kind="hybrid_gave_up", worker=worker, code=code)
            for index, (process, began) in list(self.running.items()):
                code = process.poll()
                if code is not None:
                    del self.running[index]
                    self.finish_task(index, code, time.time() - began)
            moment = time.time()
            if (not stop and self.pending and len(self.running) < self.max_concurrency
                    and moment >= self.hold_until
                    and moment - self.last_start >= START_SPACING_SECONDS
                    and free_memory_gb() >= self.min_free_gb):
                self.start_task(self.pending.pop(0))
            if moment - last_status >= 60:
                self.write_status()
                last_status = moment
            hybrid_active = any(process.poll() is None for process in self.hybrid.values())
            if not self.running and not hybrid_active and (stop or not self.pending):
                break
            time.sleep(POLL_SECONDS)
        self.write_status()
        self.event(kind="launcher_exit", failed=len(self.failed))
        return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-root", required=True)
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--h1-max-concurrency", type=int, default=3)
    parser.add_argument("--h1-min-free-gb", type=float, default=5.6)
    parser.add_argument("--hybrid-workers", type=int, default=1)
    parser.add_argument("--h1-attempts", type=int, default=3)
    arguments = parser.parse_args()
    return Launcher(arguments).run()


if __name__ == "__main__":
    sys.exit(main())
