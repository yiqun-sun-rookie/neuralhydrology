#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build the first auditable standalone Wusongkou astronomical-tide model.

The public interface is Beijing time. Only the internal astronomical clock is
converted to coordinated universal time. Training uses quality-controlled
2017-2022 targets; validation uses 2023 and never reads test target values.

Example:
python scripts/astronomical_tide/wusongkou_astronomical_tide_v1.py
"""

from __future__ import annotations

import argparse
import csv
from datetime import datetime, timedelta, timezone
import gzip
import hashlib
import io
from itertools import zip_longest
import json
import math
import os
from pathlib import Path
import platform
import shutil
import sys
from uuid import uuid4

import numpy as np
import scipy


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_PREPROCESSING_DIR = PROJECT_ROOT / "scripts" / "data_preprocessing"
THIRD_PARTY_DIR = PROJECT_ROOT / "third_party" / "pytides"
for dependency_path in [DATA_PREPROCESSING_DIR, THIRD_PARTY_DIR]:
    if str(dependency_path) not in sys.path:
        sys.path.insert(0, str(dependency_path))

from resource_monitor_v3 import ResourceMonitor  # noqa: E402
from tide import Tide  # noqa: E402


UTC = timezone.utc
BEIJING = timezone(timedelta(hours=8))
EXPERIMENT_VERSION = "wusongkou_astronomical_tide_v1_validation"
INPUT_DATASET_VERSION = "water_level_model_input_v7_beijing_realtime_verified"
STATION_SLUG = "wusongkou"
INPUT_LENGTH_HOURS = 24
FORECAST_LENGTH_HOURS = 24
KEY_HORIZONS = [1, 6, 12, 24]
TRAIN_START = datetime(2017, 1, 1, 0, tzinfo=BEIJING)
TRAIN_END = datetime(2022, 12, 31, 23, tzinfo=BEIJING)
VALIDATION_START = datetime(2023, 1, 1, 0, tzinfo=BEIJING)
VALIDATION_END = datetime(2023, 12, 31, 23, tzinfo=BEIJING)
EXPECTED_SOURCE_ROWS = 78888
EXPECTED_TRAIN_HOURS = 52584
EXPECTED_TRAIN_AVAILABLE = 51973
EXPECTED_TRAIN_MISSING = 611
EXPECTED_VALIDATION_HOURS = 8760
EXPECTED_CANDIDATE_ISSUES = 8713
EXPECTED_VALID_ISSUES = 8413
EXPECTED_PREDICTION_ROWS = 201912

FEATURE_FIELDS = [
    "TIME",
    "STAGE",
    "time_beijing",
    "time_utc",
    "is_missing_for_model",
]
TARGET_FIELDS = [
    "TIME",
    "TARGET_STAGE",
    "time_beijing",
    "time_utc",
    "is_missing_for_target",
]
PREDICTION_FIELDS = [
    "station_slug",
    "issue_time_beijing",
    "issue_time_utc",
    "maximum_realtime_input_time_beijing",
    "forecast_hour",
    "valid_time_beijing",
    "astronomical_calculation_time_utc",
    "target_stage_m",
    "astronomical_tide_prediction_m",
]
METRIC_FIELDS = [
    "station_slug",
    "forecast_hour",
    "sample_count",
    "mean_absolute_error_m",
    "root_mean_squared_error_m",
    "mean_error_m",
]
MANIFEST_FIELDS = ["root", "relative_path", "size_bytes", "sha256"]
OUTPUT_CORE_FILES = {
    "availability_summary.csv",
    "build_summary.json",
    "constituents.csv",
    "experiment_config.json",
    "experiment_registry.csv",
    "input_manifest.csv",
    "key_horizon_metrics.csv",
    "tide_model.json",
    "validation_metrics.csv",
    "validation_predictions.csv.gz",
}

DEFAULT_INPUT_DIR = Path(
    "data/processed/water_level_model_input_v7_beijing_realtime_verified"
)
DEFAULT_OUTPUT_DIR = Path(
    "results/modeling/wusongkou_astronomical_tide_v1_validation"
)
DEFAULT_ATTEMPT_ROOT = Path(
    "results/runtime/wusongkou_astronomical_tide_v1_validation/build_attempts"
)


def sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _parse_time(value: str, expected_offset: timedelta) -> datetime:
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None or parsed.utcoffset() != expected_offset:
        raise ValueError(f"time has wrong offset: {value}")
    return parsed


def beijing_to_astronomical_utc(value: datetime) -> datetime:
    """Convert a Beijing interface time to naive UTC for astronomy only."""
    if value.tzinfo is None or value.utcoffset() != timedelta(hours=8):
        raise ValueError("astronomical interface time must be Beijing +08:00")
    return value.astimezone(UTC).replace(tzinfo=None)


def _parse_optional_float(value: str, missing_flag: str) -> float | None:
    if missing_flag not in {"True", "False"}:
        raise ValueError("missing flag must be True or False")
    if missing_flag == "True":
        if value != "":
            raise ValueError("missing value must be empty")
        return None
    if value == "":
        raise ValueError("available value must be numeric")
    parsed = float(value)
    if not math.isfinite(parsed):
        raise ValueError("available value must be finite")
    return parsed


def candidate_issue_indices(row_count: int) -> range:
    return range(INPUT_LENGTH_HOURS - 1, row_count - FORECAST_LENGTH_HOURS)


def issue_is_complete(
    feature_values: list[float | None],
    target_values: list[float | None],
    issue_index: int,
) -> bool:
    return bool(
        all(
            value is not None
            for value in feature_values[
                issue_index - INPUT_LENGTH_HOURS + 1 : issue_index + 1
            ]
        )
        and all(
            value is not None
            for value in target_values[
                issue_index + 1 : issue_index + FORECAST_LENGTH_HOURS + 1
            ]
        )
    )


class MetricAccumulator:
    def __init__(self):
        self.count = 0
        self.absolute_error_sum = 0.0
        self.squared_error_sum = 0.0
        self.error_sum = 0.0

    def add(self, prediction: float, target: float) -> None:
        error = prediction - target
        self.count += 1
        self.absolute_error_sum += abs(error)
        self.squared_error_sum += error * error
        self.error_sum += error

    def result(self) -> dict:
        if self.count == 0:
            raise ValueError("metric accumulator is empty")
        return {
            "sample_count": self.count,
            "mean_absolute_error_m": self.absolute_error_sum / self.count,
            "root_mean_squared_error_m": math.sqrt(
                self.squared_error_sum / self.count
            ),
            "mean_error_m": self.error_sum / self.count,
        }


def _format_float(value: float) -> str:
    return format(value, ".12g")


def write_deterministic_gzip_csv(
    path: str | Path, fields: list[str], rows
) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix(path.suffix + ".partial")
    if path.exists() or partial.exists():
        raise FileExistsError(path)
    try:
        with partial.open("xb") as raw_handle:
            with gzip.GzipFile(
                filename="", fileobj=raw_handle, mode="wb", mtime=0
            ) as compressed_handle:
                with io.TextIOWrapper(
                    compressed_handle, encoding="utf-8", newline=""
                ) as text_handle:
                    writer = csv.DictWriter(
                        text_handle,
                        fieldnames=fields,
                        lineterminator="\n",
                    )
                    writer.writeheader()
                    writer.writerows(rows)
        os.replace(partial, path)
    except BaseException:
        if partial.exists():
            partial.unlink()
        raise


def _write_csv(path: Path, fields: list[str], rows) -> None:
    with path.open("x", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def _write_json(path: Path, value: dict) -> None:
    with path.open("x", encoding="utf-8", newline="") as handle:
        handle.write(
            json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)
            + "\n"
        )


def _file_identity(path: Path) -> dict:
    return {"size_bytes": path.stat().st_size, "sha256": sha256(path)}


def _expected_dataset_files() -> set[str]:
    stations = [
        "datong",
        "nanjing",
        "zhenjiang",
        "jiangyin",
        "xuliujing",
        "wusongkou",
    ]
    return {
        "dataset_config.json",
        *(f"realtime_features/{slug}_realtime_features.csv" for slug in stations),
        *(
            f"retrospective_targets/{slug}_retrospective_targets.csv"
            for slug in stations
        ),
    }


def _selected_input_paths() -> list[str]:
    return [
        "dataset_config.json",
        "realtime_features/wusongkou_realtime_features.csv",
        "retrospective_targets/wusongkou_retrospective_targets.csv",
    ]


def _input_manifest(input_dir: Path) -> list[dict]:
    actual = {
        path.relative_to(input_dir).as_posix()
        for path in input_dir.rglob("*")
        if path.is_file()
    }
    if actual != _expected_dataset_files():
        raise RuntimeError("seventh-version input file set changed")
    return [
        {
            "root": INPUT_DATASET_VERSION,
            "relative_path": relative,
            **_file_identity(input_dir / relative),
        }
        for relative in _selected_input_paths()
    ]


def _load_data(input_dir: Path) -> dict:
    feature_path = (
        input_dir
        / "realtime_features"
        / "wusongkou_realtime_features.csv"
    )
    target_path = (
        input_dir
        / "retrospective_targets"
        / "wusongkou_retrospective_targets.csv"
    )
    result = {
        "source_row_count": 0,
        "training_times_utc_naive": [],
        "training_values": [],
        "training_missing_count": 0,
        "validation_times_beijing": [],
        "validation_times_utc": [],
        "validation_features": [],
        "validation_targets": [],
    }
    with feature_path.open(
        "r", encoding="utf-8", newline=""
    ) as feature_handle, target_path.open(
        "r", encoding="utf-8", newline=""
    ) as target_handle:
        feature_reader = csv.DictReader(feature_handle)
        target_reader = csv.DictReader(target_handle)
        if feature_reader.fieldnames != FEATURE_FIELDS:
            raise RuntimeError("Wusongkou realtime feature fields changed")
        if target_reader.fieldnames != TARGET_FIELDS:
            raise RuntimeError("Wusongkou target fields changed")
        for feature, target in zip_longest(feature_reader, target_reader):
            result["source_row_count"] += 1
            if feature is None or target is None:
                raise RuntimeError("Wusongkou feature and target lengths differ")
            if (
                list(feature) != FEATURE_FIELDS
                or list(target) != TARGET_FIELDS
                or any(not isinstance(value, str) for value in feature.values())
                or any(not isinstance(value, str) for value in target.values())
            ):
                raise RuntimeError("Wusongkou row structure changed")
            beijing = _parse_time(feature["time_beijing"], timedelta(hours=8))
            utc = _parse_time(feature["time_utc"], timedelta(0))
            if (
                feature["TIME"] != feature["time_beijing"]
                or target["TIME"] != feature["TIME"]
                or target["time_beijing"] != feature["time_beijing"]
                or target["time_utc"] != feature["time_utc"]
                or beijing.astimezone(UTC) != utc
            ):
                raise RuntimeError("Wusongkou feature and target times changed")
            if TRAIN_START <= beijing <= TRAIN_END:
                training_target = _parse_optional_float(
                    target["TARGET_STAGE"], target["is_missing_for_target"]
                )
                if training_target is None:
                    result["training_missing_count"] += 1
                else:
                    result["training_times_utc_naive"].append(
                        beijing_to_astronomical_utc(beijing)
                    )
                    result["training_values"].append(training_target)
            elif VALIDATION_START <= beijing <= VALIDATION_END:
                result["validation_times_beijing"].append(beijing)
                result["validation_times_utc"].append(utc)
                result["validation_features"].append(
                    _parse_optional_float(
                        feature["STAGE"], feature["is_missing_for_model"]
                    )
                )
                result["validation_targets"].append(
                    _parse_optional_float(
                        target["TARGET_STAGE"],
                        target["is_missing_for_target"],
                    )
                )
    if result["source_row_count"] != EXPECTED_SOURCE_ROWS:
        raise RuntimeError("Wusongkou source row count changed")
    if (
        len(result["training_values"]) != EXPECTED_TRAIN_AVAILABLE
        or result["training_missing_count"] != EXPECTED_TRAIN_MISSING
        or len(result["training_values"]) + result["training_missing_count"]
        != EXPECTED_TRAIN_HOURS
    ):
        raise RuntimeError("Wusongkou training availability changed")
    expected_validation_times = [
        VALIDATION_START + timedelta(hours=index)
        for index in range(EXPECTED_VALIDATION_HOURS)
    ]
    if result["validation_times_beijing"] != expected_validation_times:
        raise RuntimeError("Wusongkou validation timeline changed")
    return result


def _dependency_identity() -> dict:
    script = Path(__file__).resolve()
    return {
        "builder_sha256": sha256(script),
        "verifier_sha256": sha256(
            script.with_name("verify_wusongkou_astronomical_tide_v1.py")
        ),
        "tide_utils_sha256": sha256(script.with_name("tide_utils.py")),
        "pytides_tide_sha256": sha256(THIRD_PARTY_DIR / "tide.py"),
        "pytides_astro_sha256": sha256(THIRD_PARTY_DIR / "astro.py"),
        "pytides_constituent_sha256": sha256(
            THIRD_PARTY_DIR / "constituent.py"
        ),
        "resource_monitor_v3_sha256": sha256(
            DATA_PREPROCESSING_DIR / "resource_monitor_v3.py"
        ),
        "resource_monitor_v2_sha256": sha256(
            DATA_PREPROCESSING_DIR / "resource_monitor_v2.py"
        ),
    }


def _experiment_config() -> dict:
    return {
        "experiment_version": EXPERIMENT_VERSION,
        "input_dataset_version": INPUT_DATASET_VERSION,
        "station_slug": STATION_SLUG,
        "model_type": "harmonic_astronomical_tide",
        "interface_time_basis": "beijing_time_with_utc_plus_08_00_offset",
        "astronomical_calculation_time_basis": (
            "coordinated_universal_time_derived_from_beijing_interface"
        ),
        "water_level_time_conversion": "none_core_water_level_time_remains_beijing",
        "training_start_beijing": TRAIN_START.isoformat(),
        "training_end_beijing": TRAIN_END.isoformat(),
        "validation_start_beijing": VALIDATION_START.isoformat(),
        "validation_end_beijing": VALIDATION_END.isoformat(),
        "test_start_beijing": datetime(2024, 1, 1, tzinfo=BEIJING).isoformat(),
        "input_length_hours_for_evaluation_gate": INPUT_LENGTH_HOURS,
        "forecast_length_hours": FORECAST_LENGTH_HOURS,
        "reported_forecast_hours": KEY_HORIZONS,
        "training_missing_value_rule": "exclude_without_filling",
        "validation_missing_value_rule": "exclude_issue_without_filling",
        "future_observation_inputs_used": False,
        "test_targets_used": False,
        "weather_data_used": False,
        "random_seed": "not_applicable_deterministic_linear_harmonic_fit",
        "dependency_identity": _dependency_identity(),
        "runtime_identity": {
            "python_implementation": platform.python_implementation(),
            "python_version": platform.python_version(),
            "numpy_version": np.__version__,
            "scipy_version": scipy.__version__,
        },
    }


def fit_tide_with_diagnostics(
    training_values: list[float], training_times: list[datetime]
) -> tuple[Tide, dict]:
    model, solver = Tide.decompose(
        np.asarray(training_values, dtype=float),
        training_times,
        full_output=True,
    )
    parameters, covariance, information, message, status = solver
    accepted = status in {1, 2, 3, 4}
    finite_parameters = bool(np.isfinite(parameters).all())
    finite_residuals = bool(np.isfinite(information["fvec"]).all())
    if not accepted:
        raise RuntimeError(
            f"harmonic least-squares solver did not converge: status={status}"
        )
    if not finite_parameters or not finite_residuals:
        raise RuntimeError("harmonic least-squares solver returned nonfinite values")
    diagnostics = {
        "accepted_status_codes": [1, 2, 3, 4],
        "termination_status": int(status),
        "termination_message": str(message),
        "function_evaluation_count": int(information["nfev"]),
        "residual_sum_squares_m2": float(
            np.dot(information["fvec"], information["fvec"])
        ),
        "covariance_available": covariance is not None,
        "finite_parameters": finite_parameters,
        "finite_residuals": finite_residuals,
    }
    return model, diagnostics


def _model_payload(model: Tide, solver_diagnostics: dict) -> dict:
    records = []
    for index, record in enumerate(model.model):
        records.append(
            {
                "index": index,
                "constituent": record["constituent"].name,
                "amplitude_m": float(record["amplitude"]),
                "phase_degrees": float(record["phase"]),
            }
        )
    return {
        "model_type": "harmonic_astronomical_tide",
        "station_slug": STATION_SLUG,
        "training_start_beijing": TRAIN_START.isoformat(),
        "training_end_beijing": TRAIN_END.isoformat(),
        "training_hour_count": EXPECTED_TRAIN_HOURS,
        "training_available_count": EXPECTED_TRAIN_AVAILABLE,
        "training_missing_count": EXPECTED_TRAIN_MISSING,
        "constituent_count": len(records),
        "constituents": records,
        "solver_diagnostics": solver_diagnostics,
    }


def _metric_rows(accumulators: dict[int, MetricAccumulator]) -> list[dict]:
    rows = []
    for forecast_hour in range(1, FORECAST_LENGTH_HOURS + 1):
        result = accumulators[forecast_hour].result()
        rows.append(
            {
                "station_slug": STATION_SLUG,
                "forecast_hour": forecast_hour,
                "sample_count": result["sample_count"],
                "mean_absolute_error_m": _format_float(
                    result["mean_absolute_error_m"]
                ),
                "root_mean_squared_error_m": _format_float(
                    result["root_mean_squared_error_m"]
                ),
                "mean_error_m": _format_float(result["mean_error_m"]),
            }
        )
    return rows


def run_experiment(
    input_dir: str | Path = DEFAULT_INPUT_DIR,
    output_dir: str | Path = DEFAULT_OUTPUT_DIR,
    resource_monitor=None,
    defer_publication: bool = False,
) -> dict | tuple[dict, Path]:
    input_dir = Path(input_dir).resolve()
    output_dir = Path(output_dir).resolve()
    if output_dir.exists():
        raise FileExistsError(output_dir)
    input_manifest = _input_manifest(input_dir)
    source_config = json.loads(
        (input_dir / "dataset_config.json").read_text(encoding="utf-8")
    )
    if source_config.get("dataset_version") != INPUT_DATASET_VERSION:
        raise RuntimeError("input dataset version changed")
    data = _load_data(input_dir)
    if resource_monitor is not None:
        resource_monitor.raise_if_unsafe("after_input")

    model, solver_diagnostics = fit_tide_with_diagnostics(
        data["training_values"],
        data["training_times_utc_naive"],
    )
    model_payload = _model_payload(model, solver_diagnostics)
    validation_astronomical_times = [
        beijing_to_astronomical_utc(value)
        for value in data["validation_times_beijing"]
    ]
    validation_predictions = np.asarray(
        model.at(validation_astronomical_times), dtype=float
    )
    if not np.isfinite(validation_predictions).all():
        raise RuntimeError("astronomical prediction contains a nonfinite value")
    if resource_monitor is not None:
        resource_monitor.raise_if_unsafe("after_fit_and_predict")

    candidates = list(candidate_issue_indices(EXPECTED_VALIDATION_HOURS))
    if len(candidates) != EXPECTED_CANDIDATE_ISSUES:
        raise AssertionError("candidate issue count changed")
    valid_issues = [
        issue_index
        for issue_index in candidates
        if issue_is_complete(
            data["validation_features"],
            data["validation_targets"],
            issue_index,
        )
    ]
    if len(valid_issues) != EXPECTED_VALID_ISSUES:
        raise RuntimeError("Wusongkou valid issue count changed")

    staging = output_dir.with_name(
        f".{output_dir.name}.partial_{uuid4().hex[:8]}"
    )
    staging.mkdir(parents=True, exist_ok=False)
    accumulators = {
        forecast_hour: MetricAccumulator()
        for forecast_hour in range(1, FORECAST_LENGTH_HOURS + 1)
    }
    prediction_count = 0

    def prediction_rows():
        nonlocal prediction_count
        for issue_index in valid_issues:
            issue_beijing = data["validation_times_beijing"][issue_index]
            issue_utc = data["validation_times_utc"][issue_index]
            for forecast_hour in range(1, FORECAST_LENGTH_HOURS + 1):
                valid_index = issue_index + forecast_hour
                valid_beijing = data["validation_times_beijing"][valid_index]
                target = data["validation_targets"][valid_index]
                prediction = float(validation_predictions[valid_index])
                if target is None:
                    raise AssertionError("complete issue has a missing target")
                accumulators[forecast_hour].add(prediction, target)
                prediction_count += 1
                if resource_monitor is not None and prediction_count % 100_000 == 0:
                    resource_monitor.raise_if_stop_requested()
                yield {
                    "station_slug": STATION_SLUG,
                    "issue_time_beijing": issue_beijing.isoformat(),
                    "issue_time_utc": issue_utc.isoformat(),
                    "maximum_realtime_input_time_beijing": issue_beijing.isoformat(),
                    "forecast_hour": str(forecast_hour),
                    "valid_time_beijing": valid_beijing.isoformat(),
                    "astronomical_calculation_time_utc": valid_beijing.astimezone(
                        UTC
                    ).isoformat(),
                    "target_stage_m": _format_float(target),
                    "astronomical_tide_prediction_m": _format_float(prediction),
                }

    try:
        _write_json(staging / "experiment_config.json", _experiment_config())
        _write_csv(
            staging / "input_manifest.csv",
            MANIFEST_FIELDS,
            input_manifest,
        )
        _write_json(staging / "tide_model.json", model_payload)
        _write_csv(
            staging / "constituents.csv",
            ["index", "constituent", "amplitude_m", "phase_degrees"],
            [
                {
                    "index": record["index"],
                    "constituent": record["constituent"],
                    "amplitude_m": _format_float(record["amplitude_m"]),
                    "phase_degrees": _format_float(record["phase_degrees"]),
                }
                for record in model_payload["constituents"]
            ],
        )
        write_deterministic_gzip_csv(
            staging / "validation_predictions.csv.gz",
            PREDICTION_FIELDS,
            prediction_rows(),
        )
        if prediction_count != EXPECTED_PREDICTION_ROWS:
            raise AssertionError("prediction row count changed")
        metrics = _metric_rows(accumulators)
        _write_csv(staging / "validation_metrics.csv", METRIC_FIELDS, metrics)
        key_rows = [
            row for row in metrics if int(row["forecast_hour"]) in KEY_HORIZONS
        ]
        _write_csv(
            staging / "key_horizon_metrics.csv", METRIC_FIELDS, key_rows
        )
        _write_csv(
            staging / "availability_summary.csv",
            [
                "station_slug",
                "candidate_issue_count",
                "valid_issue_count",
                "excluded_issue_count",
                "valid_issue_fraction",
                "training_hour_count",
                "training_available_count",
                "training_missing_count",
            ],
            [
                {
                    "station_slug": STATION_SLUG,
                    "candidate_issue_count": EXPECTED_CANDIDATE_ISSUES,
                    "valid_issue_count": len(valid_issues),
                    "excluded_issue_count": (
                        EXPECTED_CANDIDATE_ISSUES - len(valid_issues)
                    ),
                    "valid_issue_fraction": _format_float(
                        len(valid_issues) / EXPECTED_CANDIDATE_ISSUES
                    ),
                    "training_hour_count": EXPECTED_TRAIN_HOURS,
                    "training_available_count": EXPECTED_TRAIN_AVAILABLE,
                    "training_missing_count": EXPECTED_TRAIN_MISSING,
                }
            ],
        )
        _write_csv(
            staging / "experiment_registry.csv",
            [
                "experiment_id",
                "type",
                "hypothesis",
                "selection_split",
                "test_targets_used",
                "status",
                "run_dir",
                "metrics_path",
                "random_seed",
            ],
            [
                {
                    "experiment_id": EXPERIMENT_VERSION,
                    "type": "standalone_astronomical_tide_forecast",
                    "hypothesis": (
                        "training_only_harmonics_beat_simple_tidal_reference"
                    ),
                    "selection_split": "validation_2023_beijing",
                    "test_targets_used": "False",
                    "status": "completed_validation_only",
                    "run_dir": ".",
                    "metrics_path": "validation_metrics.csv",
                    "random_seed": (
                        "not_applicable_deterministic_linear_harmonic_fit"
                    ),
                }
            ],
        )
        summary = {
            "experiment_version": EXPERIMENT_VERSION,
            "station_slug": STATION_SLUG,
            "constituent_count": model_payload["constituent_count"],
            "solver_termination_status": solver_diagnostics[
                "termination_status"
            ],
            "training_hour_count": EXPECTED_TRAIN_HOURS,
            "training_available_count": EXPECTED_TRAIN_AVAILABLE,
            "training_missing_count": EXPECTED_TRAIN_MISSING,
            "candidate_issue_count": EXPECTED_CANDIDATE_ISSUES,
            "valid_issue_count": len(valid_issues),
            "forecast_hour_count": FORECAST_LENGTH_HOURS,
            "prediction_row_count": prediction_count,
            "metric_row_count": len(metrics),
            "key_metric_row_count": len(key_rows),
            "future_observation_input_count": 0,
            "test_targets_used": False,
            "test_prediction_row_count": 0,
        }
        _write_json(staging / "build_summary.json", summary)
        output_manifest = [
            {
                "root": EXPERIMENT_VERSION,
                "relative_path": relative,
                **_file_identity(staging / relative),
            }
            for relative in sorted(OUTPUT_CORE_FILES)
        ]
        _write_csv(
            staging / "output_manifest.csv", MANIFEST_FIELDS, output_manifest
        )
        if resource_monitor is not None:
            resource_monitor.raise_if_unsafe("before_publication")
        if defer_publication:
            return summary, staging
        os.replace(staging, output_dir)
        return summary
    except BaseException:
        if staging.exists():
            shutil.rmtree(staging)
        raise


def _new_attempt_dir(root: str | Path) -> Path:
    timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    return Path(root) / f"b_{timestamp}_{uuid4().hex[:8]}"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", default=str(DEFAULT_INPUT_DIR))
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    parser.add_argument("--attempt-root", default=str(DEFAULT_ATTEMPT_ROOT))
    parser.add_argument("--resource-interval-seconds", type=float, default=5.0)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    attempt_dir = _new_attempt_dir(args.attempt_root).resolve()
    attempt_dir.mkdir(parents=True, exist_ok=False)
    resource_log = attempt_dir / "resources.csv"
    _write_json(
        attempt_dir / "attempt_config.json",
        {
            "input_dir": str(Path(args.input_dir).resolve()),
            "output_dir": str(Path(args.output_dir).resolve()),
            "resource_interval_seconds": args.resource_interval_seconds,
            "estimated_peak_memory_bytes": 2 * 1024**3,
            "estimated_output_bytes": 100 * 1024**2,
            "execution_identity": {
                "dependency_identity": _dependency_identity(),
                "python_implementation": platform.python_implementation(),
                "python_version": platform.python_version(),
                "numpy_version": np.__version__,
                "scipy_version": scipy.__version__,
                "random_seed": (
                    "not_applicable_deterministic_linear_harmonic_fit"
                ),
            },
        },
    )
    result = None
    deferred_result = None
    captured_error = None
    try:
        with ResourceMonitor(
            log_path=resource_log,
            phase="wusongkou_astronomical_tide_v1_build",
            disk_path=args.output_dir,
            interval_seconds=args.resource_interval_seconds,
            estimated_remaining_output_bytes=100 * 1024**2,
            estimated_peak_memory_bytes=2 * 1024**3,
            estimated_peak_graphics_processor_memory_bytes=0,
            estimated_output_bytes=100 * 1024**2,
            monitor_graphics_processor=False,
        ) as monitor:
            deferred_result = run_experiment(
                input_dir=args.input_dir,
                output_dir=args.output_dir,
                resource_monitor=monitor,
                defer_publication=True,
            )
        result, staging = deferred_result
        os.replace(staging, Path(args.output_dir).resolve())
    except BaseException as error:
        captured_error = error
        if deferred_result is not None:
            _, staging = deferred_result
            if staging.exists():
                shutil.rmtree(staging)
    _write_json(
        attempt_dir / "attempt_summary.json",
        {
            "status": "failed" if captured_error else "completed",
            "exception_type": type(captured_error).__name__ if captured_error else "",
            "exception_message": str(captured_error) if captured_error else "",
            "resource_log_sha256": sha256(resource_log) if resource_log.is_file() else "",
            "result": result or {},
        },
    )
    if captured_error is not None:
        raise captured_error
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
