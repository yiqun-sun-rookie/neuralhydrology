"""Contract for the JH:RS revision experiments, fixed before any of them ran.

One module says what the revision runs and how it is judged:
- the scenarios, and the stations each one keeps, derived from rules;
- the hybrid model (ridge plus gradient-boosted trees on the ridge residual) and
  its frozen settings;
- the Transformer tide-control task list (H1);
- the registered predictions P1-P9 and gates G-A to G-C, with mechanical rules;
- the inference unit.

The plan it implements is
docs/plans/2026-11-07-zhenjiang-jhrs-revision-experiment-plan.md.

What existed when this was written
----------------------------------
The hybrid model had been fitted on the two baseline scenarios only
(complete_observation and hidden_target, test years 2020 and 2023; the
instrument pilot). It had never been fitted on a scenario that removes a
neighbouring gauge. No tide-control run existed. The Transformer and ridge
results of the submitted manuscript, and the exploratory arrival-time analysis
of those results, had been seen; the predictions below are therefore informed,
not blind, except where a scenario or a data cut is new.

Usage
-----
python -X utf8 -B scripts/analysis/zhenjiang_jhrs_revision_contract.py
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[2]
for _relative in ("scripts/analysis", "scripts/modeling", "scripts/astronomical_tide"):
    _candidate = str(PROJECT_ROOT / _relative)
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)

import zhenjiang_oyv_v1_contract as v1  # noqa: E402
from water_level_joint_encoder_decoder_v2 import STATION_ORDER  # noqa: E402

EXPERIMENT_ID = "zhenjiang_jhrs_revision_v1"
SCHEMA_VERSION = 1
PLAN_PATH = "docs/plans/2026-11-07-zhenjiang-jhrs-revision-experiment-plan.md"

# --- inherited unchanged ------------------------------------------------------

CANDIDATE_FOLD_YEARS = tuple(v1.CANDIDATE_FOLD_YEARS)
SEEDS = tuple(v1.SEEDS)
fold_assignment = v1.fold_assignment
apply_deterministic_settings = v1.apply_deterministic_settings
runtime_identity = v1.runtime_identity
sha256_of = v1.sha256_of
FORMAL_BATCH_SIZE = v1.FORMAL_BATCH_SIZE
FORMAL_MAXIMUM_EPOCHS = v1.FORMAL_MAXIMUM_EPOCHS
FORMAL_PATIENCE_EPOCHS = v1.FORMAL_PATIENCE_EPOCHS
FORMAL_MINIMUM_DELTA_M = v1.FORMAL_MINIMUM_DELTA_M
FORMAL_GRADIENT_CLIP_NORM = v1.FORMAL_GRADIENT_CLIP_NORM
FORMAL_LEARNING_RATE = v1.FORMAL_LEARNING_RATE
FORMAL_WEIGHT_DECAY = v1.FORMAL_WEIGHT_DECAY
FORMAL_ADAM_BETAS = v1.FORMAL_ADAM_BETAS
FORMAL_ADAM_EPSILON = v1.FORMAL_ADAM_EPSILON
FORMAL_AMSGRAD = v1.FORMAL_AMSGRAD
FORMAL_FUSED = v1.FORMAL_FUSED
EXPECTED_PARAMETER_COUNT = v1.EXPECTED_PARAMETER_COUNT

TARGETS = ("nanjing", "zhenjiang", "jiangyin", "xuliujing")
CONTROL_TYPE = {
    "nanjing": "fluvial",
    "zhenjiang": "fluvial",
    "jiangyin": "tidal",
    "xuliujing": "tidal",
}
ENDPOINT_STATIONS = (STATION_ORDER[0], STATION_ORDER[-1])
LEADS = tuple(range(1, 11))
REPORT_LEADS = (1, 3, 6)
EFFECT_FLOOR_M = 0.010

# --- tide ---------------------------------------------------------------------

FOLD_TIDE_ROOT = PROJECT_ROOT / "results" / "modeling" / "zhenjiang_jhrs_fold_tide_v1"
TIDE_VERSIONS = ("fold", "frozen")


def tide_file(version: str, test_year: int) -> Path:
    """The registered tide array a run of this fold reads."""
    if version == "frozen":
        return FOLD_TIDE_ROOT / "tide_frozen.npy"
    if version == "fold":
        if test_year not in CANDIDATE_FOLD_YEARS:
            raise ValueError("unknown fold year: %r" % test_year)
        return FOLD_TIDE_ROOT / ("tide_fold_%d.npy" % test_year)
    raise ValueError("unknown tide version: %r" % version)


def load_tide_array(version: str, test_year: int, expected_length: int) -> np.ndarray:
    """Load a tide array after checking it against the tide manifest."""
    path = tide_file(version, test_year)
    manifest = json.loads((FOLD_TIDE_ROOT / "manifest.json").read_text(encoding="utf-8"))
    label = "frozen" if version == "frozen" else "fold_%d" % test_year
    expected = manifest["files"][label]
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != expected["sha256"]:
        raise RuntimeError("tide array fingerprint changed: %s" % path.name)
    values = np.load(path)
    if values.dtype != np.float32 or values.shape != (expected_length,):
        raise RuntimeError("tide array has the wrong dtype or length: %s" % path.name)
    if not np.isfinite(values).all():
        raise RuntimeError("tide array contains a nonfinite value: %s" % path.name)
    return values


# --- stations and scenarios ---------------------------------------------------


def _position(target: str) -> int:
    if target not in TARGETS:
        raise ValueError("unknown target: %r" % target)
    return STATION_ORDER.index(target)


def other_stations(target: str) -> tuple[str, ...]:
    return tuple(name for name in STATION_ORDER if name != target)


def upstream_stations(target: str) -> tuple[str, ...]:
    """Stations above the target, nearest first."""
    return tuple(reversed(STATION_ORDER[: _position(target)]))


def downstream_stations(target: str) -> tuple[str, ...]:
    """Stations below the target, nearest first."""
    return tuple(STATION_ORDER[_position(target) + 1:])


def nearest_neighbours(target: str) -> tuple[str, str]:
    return upstream_stations(target)[0], downstream_stations(target)[0]


def screening_pairs(target: str) -> tuple[tuple[str, str], ...]:
    """(nearest, next) on each side that has at least two stations."""
    pairs = []
    for side in (upstream_stations(target), downstream_stations(target)):
        if len(side) >= 2:
            pairs.append((side[0], side[1]))
    return tuple(pairs)


#: Written out by hand as well, so a rule change cannot pass silently.
SCREENING_PAIRS_BY_HAND = {
    "nanjing": (("zhenjiang", "jiangyin"),),
    "zhenjiang": (("nanjing", "datong"), ("jiangyin", "xuliujing")),
    "jiangyin": (("zhenjiang", "nanjing"), ("xuliujing", "wusongkou")),
    "xuliujing": (("jiangyin", "zhenjiang"),),
}


def _removed_by_scenario(target: str) -> dict[str, frozenset]:
    """Scenario name -> stations whose history is withheld, in a fixed order."""
    table: dict[str, frozenset] = {}
    table["complete_observation"] = frozenset()
    table["hidden_target"] = frozenset({target})
    for name in other_stations(target):
        table["hidden_target_minus_%s" % name] = frozenset({target, name})
    table["hidden_target_both_nearest"] = frozenset({target, *nearest_neighbours(target)})
    table["endpoints_only"] = frozenset(
        name for name in STATION_ORDER if name not in ENDPOINT_STATIONS or name == target
    )
    for name in other_stations(target):
        table["complete_minus_%s" % name] = frozenset({name})
    for nearest, following in screening_pairs(target):
        table["hidden_target_minus_%s_and_%s" % (nearest, following)] = frozenset(
            {target, nearest, following}
        )
    existing = set(table.values())
    for side_name, side in (("upstream", upstream_stations(target)),
                            ("downstream", downstream_stations(target))):
        removed = frozenset({target, *side})
        if removed not in existing:
            table["hidden_target_minus_%s_side" % side_name] = removed
            existing.add(removed)
    return table


def scenarios(target: str) -> tuple[str, ...]:
    return tuple(_removed_by_scenario(target))


def removed_stations(target: str, scenario: str) -> frozenset:
    table = _removed_by_scenario(target)
    if scenario not in table:
        raise ValueError("unknown scenario %r for %r" % (scenario, target))
    return table[scenario]


def kept_stations(target: str, scenario: str) -> tuple[str, ...]:
    gone = removed_stations(target, scenario)
    return tuple(name for name in STATION_ORDER if name not in gone)


def side_scenario(target: str, side: str) -> str:
    """The scenario that withholds the target and one whole side."""
    stations = upstream_stations(target) if side == "upstream" else downstream_stations(target)
    wanted = frozenset({target, *stations})
    for name, removed in _removed_by_scenario(target).items():
        if removed == wanted:
            return name
    raise ValueError("no scenario removes the %s side of %s" % (side, target))


FROZEN_SCENARIOS = (
    "complete_observation",
    "hidden_target",
) + tuple("hidden_target_minus_%s" % name for name in STATION_ORDER) + (
    "hidden_target_both_nearest",
    "endpoints_only",
)


def existing_scenarios(target: str) -> tuple[str, ...]:
    """The nine scenarios of the submitted manuscript."""
    return tuple(name for name in scenarios(target) if name in FROZEN_SCENARIOS)


def single_removals(target: str, family: str) -> dict[str, str]:
    """Gauge -> scenario, for one baseline family ('unavailable' or 'visible')."""
    prefix = "hidden_target_minus_" if family == "unavailable" else "complete_minus_"
    return {name: prefix + name for name in other_stations(target)}


def baseline_scenario(family: str) -> str:
    return "hidden_target" if family == "unavailable" else "complete_observation"


# --- hybrid model -------------------------------------------------------------

RIDGE_ALPHA = 1.0
GBM_THREADS = 8
GBM_MAX_ROUNDS = 1500
GBM_EARLY_STOPPING_ROUNDS = 60
GBM_PRIMARY_SEED = 17
GBM_EXTRA_SEEDS = (29, 43)


def gbm_parameters(seed: int) -> dict[str, object]:
    """Fixed before the pilot; not tuned. Thread count fixed for reproducibility."""
    return {
        "objective": "l1",
        "learning_rate": 0.05,
        "num_leaves": 63,
        "min_data_in_leaf": 50,
        "feature_fraction": 0.5,
        "bagging_fraction": 0.7,
        "bagging_freq": 1,
        "lambda_l2": 1.0,
        "num_threads": GBM_THREADS,
        "verbose": -1,
        "seed": int(seed),
        "deterministic": True,
        "force_row_wise": True,
    }


NO_RETRAIN_BASELINES = ("complete_observation", "hidden_target")
NO_RETRAIN_FILLS = ("training_mean", "hold_first_hour")
FROZEN_TIDE_SCENARIOS = ("complete_observation", "hidden_target") + tuple(
    "hidden_target_minus_%s" % name for name in STATION_ORDER
)


def hybrid_units() -> tuple[dict[str, object], ...]:
    """Every hybrid fit, in a fixed order. L1-L4 first, then L6, then L7."""
    units = []

    def add(part, tide, year, target, scenario, seed, leads):
        units.append({
            "unit_id": "%s__%s__fold_%d__%s__%s__gbmseed_%d"
            % (part, tide, year, target, scenario, seed),
            "part": part,
            "tide": tide,
            "test_year": int(year),
            "target": target,
            "scenario": scenario,
            "gbm_seed": int(seed),
            "leads": tuple(leads),
            "no_retrain": part == "main" and scenario in NO_RETRAIN_BASELINES,
        })

    for year in CANDIDATE_FOLD_YEARS:
        for target in TARGETS:
            for scenario in scenarios(target):
                add("main", "fold", year, target, scenario, GBM_PRIMARY_SEED, LEADS)
    for year in CANDIDATE_FOLD_YEARS:
        for target in TARGETS:
            for scenario in scenarios(target):
                if scenario in FROZEN_TIDE_SCENARIOS:
                    add("frozen_tide", "frozen", year, target, scenario,
                        GBM_PRIMARY_SEED, REPORT_LEADS)
    for seed in GBM_EXTRA_SEEDS:
        for year in CANDIDATE_FOLD_YEARS:
            for target in TARGETS:
                for scenario in existing_scenarios(target):
                    add("seed", "fold", year, target, scenario, seed, REPORT_LEADS)
    return tuple(units)


# --- Transformer tide control (H1) --------------------------------------------

H1_YEARS = (2020, 2021)
H1_TIDES = ("frozen", "fold")


def h1_conditions(target: str) -> tuple[str, ...]:
    return ("hidden_target",) + tuple(
        "hidden_target_minus_%s" % name for name in other_stations(target)
    )


def h1_task_id(tide: str, year: int, target: str, condition: str, seed: int) -> str:
    if tide not in H1_TIDES or year not in H1_YEARS or seed not in SEEDS:
        raise ValueError("not an H1 task")
    if condition not in h1_conditions(target):
        raise ValueError("unknown H1 condition %r for %r" % (condition, target))
    return "jhrs_tide_control_v1__%s__fold_%d__%s__%s__seed_%d" % (
        tide, year, target, condition, seed)


def h1_tasks() -> tuple[dict[str, object], ...]:
    """Seed-major order, so an interrupted run leaves whole seeds behind it."""
    tasks = []
    for seed in SEEDS:
        for tide in H1_TIDES:
            for year in H1_YEARS:
                for target in TARGETS:
                    for condition in h1_conditions(target):
                        tasks.append({
                            "task_id": h1_task_id(tide, year, target, condition, seed),
                            "tide": tide,
                            "test_year": int(year),
                            "target": target,
                            "condition": condition,
                            "seed": int(seed),
                        })
    return tuple(tasks)


def build_history_mask(target: str, condition: str):
    """[1, 1, 6] float32 mask; 0 hides a station's standardized history."""
    import torch

    kept = set(kept_stations(target, condition))
    values = [1.0 if station in kept else 0.0 for station in STATION_ORDER]
    return torch.tensor(values, dtype=torch.float32).reshape(1, 1, len(STATION_ORDER))


# --- registered quantities ----------------------------------------------------

#: Hours for the tide to travel from the gauge to the target, measured from the
#: stage records (high-pass lag correlation; the M2 phase lag gives nearly the
#: same values). Keys are (target, seaward gauge). No forecast was used.
TRAVEL_TIME_HOURS = {
    ("xuliujing", "wusongkou"): 1.86,
    ("jiangyin", "xuliujing"): 2.07,
    ("jiangyin", "wusongkou"): 3.93,
    ("zhenjiang", "jiangyin"): 3.19,
    ("zhenjiang", "xuliujing"): 5.26,
    ("zhenjiang", "wusongkou"): 7.11,
    ("nanjing", "zhenjiang"): 1.90,
    ("nanjing", "jiangyin"): 5.09,
    ("nanjing", "xuliujing"): 7.17,
    ("nanjing", "wusongkou"): 9.03,
}


def arrival_window(target: str, gauge: str) -> tuple[tuple[int, ...], tuple[int, ...]]:
    """(window leads, pre-window leads) for an outer seaward gauge.

    The window holds the leads above the rounded travel time of the next gauge
    closer to the target and up to the rounded travel time of this gauge; the
    pre-window holds the leads up to the former.
    """
    seaward = downstream_stations(target)
    index = seaward.index(gauge)
    if index == 0:
        raise ValueError("the nearest seaward gauge has no inner gauge")
    inner = round(TRAVEL_TIME_HOURS[(target, seaward[index - 1])])
    outer = round(TRAVEL_TIME_HOURS[(target, gauge)])
    window = tuple(lead for lead in LEADS if inner < lead <= outer)
    pre = tuple(lead for lead in LEADS if lead <= inner)
    return window, pre


ARRIVAL_WINDOWS_BY_HAND = {
    ("jiangyin", "wusongkou"): ((3, 4), (1, 2)),
    ("zhenjiang", "xuliujing"): ((4, 5), (1, 2, 3)),
    ("zhenjiang", "wusongkou"): ((6, 7), (1, 2, 3, 4, 5)),
    ("nanjing", "jiangyin"): ((3, 4, 5), (1, 2)),
    ("nanjing", "xuliujing"): ((6, 7), (1, 2, 3, 4, 5)),
    ("nanjing", "wusongkou"): ((8, 9), (1, 2, 3, 4, 5, 6, 7)),
}
FALL_AFTER_ARRIVAL = {
    ("xuliujing", "wusongkou"): ((1, 2), (4, 5, 6)),
    ("jiangyin", "xuliujing"): ((1, 2), (4, 5, 6)),
}
DRY_MONTHS = (11, 12, 1, 2, 3, 4)
WET_MONTHS = (5, 6, 7, 8, 9, 10)

INFERENCE = {
    "cost": (
        "for one year: mean absolute error of the scenario minus that of its "
        "baseline (hidden_target for target-unavailable scenarios, "
        "complete_observation for target-visible ones), over the test-year issue "
        "times, at one lead. Transformer: per-seed paired difference, then the "
        "median over the ten seeds"
    ),
    "summary": "median over the eight test years",
    "bootstrap": {
        "replicates": 2000,
        "random_seed": 20261107,
        "levels": [
            "test years, with replacement",
            "ISO weeks of the issue time within each sampled year, with replacement",
            "seeds within each sampled year, with replacement (Transformer only)",
        ],
        "statistic": "median over the sampled years of the per-year cost or difference",
        "interval": "2.5th and 97.5th percentiles",
        "paired": "arm and baseline (and two arms) use the same resampled issue times",
    },
    "critical_gauge": (
        "called critical only if the lower bound of its cost interval is above "
        "zero and the point estimate is at least 0.010 m; 0.010 m is a practical "
        "floor near the centimetre resolution of stage records, not a "
        "statistical bound"
    ),
}

PREDICTIONS = {
    "P1": {
        "tier": "stop_loss",
        "model": "hybrid",
        "family": "unavailable",
        "checks": [
            {"target": "xuliujing", "gauge": "wusongkou", "leads": [1, 3]},
            {"target": "jiangyin", "gauge": "xuliujing", "leads": [1]},
        ],
        "rule": (
            "at each listed lead the gauge has the largest of the five "
            "single-removal costs, and the bootstrap interval of its paired "
            "difference to the second-largest has a lower bound above zero"
        ),
        "on_failure": "stop and reassess the manuscript before further analysis",
    },
    "P2": {
        "model": "hybrid",
        "family": "unavailable",
        "target": "nanjing",
        "leads": [1, 6],
        "rule": (
            "the smaller of the Datong and Zhenjiang single-removal costs exceeds "
            "the largest of the Jiangyin, Xuliujing and Wusongkou costs; which of "
            "Datong and Zhenjiang is larger is not predicted"
        ),
    },
    "P3a": {
        "model": "hybrid",
        "target": "nanjing",
        "leads": [1, 6],
        "rule": (
            "cost(hidden_target_both_nearest, i.e. Zhenjiang and Datong removed) "
            "exceeds cost(hidden_target_minus_zhenjiang_and_jiangyin)"
        ),
    },
    "P3b": {
        "model": "hybrid",
        "leads": [1],
        "rule": (
            "for each of the six screening pairs (nearest, next), the increment "
            "cost(nearest and next removed) - cost(nearest removed) exceeds "
            "cost(next removed alone); passes if this holds for at least 5 of 6"
        ),
        "minimum_count": 5,
    },
    "P4": {
        "model": "hybrid",
        "targets": ["nanjing", "zhenjiang"],
        "leads": [1, 6],
        "rule": (
            "cost(hidden_target_both_nearest) - cost(upstream nearest removed) - "
            "cost(downstream nearest removed) has a bootstrap lower bound above zero"
        ),
    },
    "P5": {
        "model": "hybrid",
        "family": "visible",
        "leads": [1],
        "rule": "all 20 single-removal point estimates are below 0.010 m",
    },
    "P6": {
        "models": ["hybrid", "ridge"],
        "family": "visible",
        "rule_a": (
            "per year, the mean over the six outer pairs of [mean cost over the "
            "window leads - mean cost over the pre-window leads] is positive in at "
            "least 7 of 8 years"
        ),
        "rule_b": (
            "for each of the two adjacent pairs, mean cost over the early leads "
            "minus mean cost over the late leads is positive in at least 7 of 8 "
            "years"
        ),
        "rule_c": (
            "for at least 7 of the 10 seaward pairs, the lead at which the "
            "eight-year median cost peaks lies within 1.5 h of the travel time"
        ),
        "minimum_years_a": 7,
        "minimum_years_b": 7,
        "minimum_pairs_c": 7,
        "peak_tolerance_hours": 1.5,
        "pass": "all three parts pass in both models",
    },
    "P7": {
        "model": "hybrid",
        "family": "unavailable",
        "pairs": [
            ["zhenjiang", "xuliujing"], ["zhenjiang", "wusongkou"],
            ["nanjing", "jiangyin"], ["nanjing", "xuliujing"], ["nanjing", "wusongkou"],
        ],
        "rule": (
            "per year, the mean window rise over the five pairs computed on "
            "dry-season issue times exceeds the same computed on wet-season issue "
            "times, in at least 6 of 8 years"
        ),
        "minimum_years": 6,
    },
    "P8": {
        "model": "hybrid",
        "family": "unavailable",
        "leads": [1, 6],
        "fill": "training_mean",
        "rule": (
            "for each target, take the gauge with the largest retrained cost at "
            "1 h; its no-retrain cost (model trained on hidden_target, gauge filled "
            "with its training mean) is at least its retrained cost at 1 h and 6 h; "
            "passes if this holds for all four targets"
        ),
    },
    "P9": {
        "models": ["hybrid", "ridge"],
        "family": "unavailable",
        "leads": [1, 3, 6],
        "rule": (
            "over 4 targets x 5 gauges x 3 leads x 8 years, the 95th percentile of "
            "|cost with frozen tide - cost with fold tide| is at most 0.002 m, and "
            "for every target and lead the two costliest gauges are the same under "
            "both tides"
        ),
        "maximum_p95_m": 0.002,
    },
}

GATES = {
    "statistic_definition": (
        "C(tide, year, target, gauge, lead) = median over the ten seeds of "
        "[MAE(hidden_target_minus_gauge) - MAE(hidden_target)] for that seed; "
        "both tides run on the same card"
    ),
    "G-A": {
        "rule": (
            "mean over the 20 target-gauge cells of |mean over 2020 and 2021 of "
            "(C_fold - C_frozen)| does not exceed the limit at each lead"
        ),
        "limits_m": {"1": 0.0037, "3": 0.0034, "6": 0.0034},
        "source": "95th percentile of a seed-resampling null; tide_gate_null_output.txt",
    },
    "G-B": {
        "rule": (
            "under the fold tide, in both 2020 and 2021: at Xuliujing, Wusongkou "
            "has the largest C at 1, 3 and 6 h; at Jiangyin, Xuliujing has the "
            "largest C at 1 h"
        ),
    },
    "G-C": {
        "rule": (
            "mean over 4 targets x 2 years of [median over seeds of MAE_fold "
            "(hidden_target) - the same with the frozen tide] does not exceed the "
            "limit at each lead"
        ),
        "limits_m": {"1": 0.0024, "3": 0.0024, "6": 0.0022},
        "source": "95th percentile of a seed-resampling null; tide_gate_margins_output.txt",
    },
    "decision": (
        "all three pass: the Transformer results stay in the main text with this "
        "control reported. Any fails: the Transformer results move to the "
        "supplement with the caveat; no full rerun"
    ),
}


# --- self-check ---------------------------------------------------------------


def validate_contract() -> dict[str, object]:
    findings: list[str] = []
    counts = {target: len(scenarios(target)) for target in TARGETS}
    if counts != {"nanjing": 16, "zhenjiang": 17, "jiangyin": 17, "xuliujing": 16}:
        findings.append("scenario counts differ from the plan: %s" % counts)
    for target in TARGETS:
        table = _removed_by_scenario(target)
        if len(set(table.values())) != len(table):
            findings.append("two scenarios of %s keep the same stations" % target)
        if set(screening_pairs(target)) != set(SCREENING_PAIRS_BY_HAND[target]):
            findings.append("screening rule disagrees with the hand table: %s" % target)
        for name in existing_scenarios(target):
            kept = set(kept_stations(target, name))
            if name == "complete_observation" and kept != set(STATION_ORDER):
                findings.append("complete_observation of %s is not all six" % target)
            if name != "complete_observation" and target in kept:
                findings.append("%s of %s keeps the target" % (name, target))
        for side in ("upstream", "downstream"):
            side_scenario(target, side)
        if len(existing_scenarios(target)) != 9:
            findings.append("%s does not carry the nine submitted scenarios" % target)
    for (target, gauge), (window, pre) in ARRIVAL_WINDOWS_BY_HAND.items():
        if arrival_window(target, gauge) != (window, pre):
            findings.append("window rule disagrees for %s<-%s" % (target, gauge))
    units = hybrid_units()
    parts = {}
    for unit in units:
        parts[unit["part"]] = parts.get(unit["part"], 0) + 1
    if parts != {"main": 528, "frozen_tide": 224, "seed": 576}:
        findings.append("hybrid unit counts differ from the plan: %s" % parts)
    if len({unit["unit_id"] for unit in units}) != len(units):
        findings.append("duplicate hybrid unit id")
    tasks = h1_tasks()
    if len(tasks) != 960 or len({task["task_id"] for task in tasks}) != 960:
        findings.append("H1 task list is not 960 distinct tasks")
    if len(SEEDS) != 10:
        findings.append("seed list is not ten")
    for year in CANDIDATE_FOLD_YEARS:
        assignment = fold_assignment(year)
        if year in assignment["training_years"]:
            findings.append("fold %d trains on its test year" % year)
    return {
        "experiment_id": EXPERIMENT_ID,
        "scenarios_per_target": counts,
        "hybrid_units": parts,
        "h1_tasks": len(tasks),
        "finding_count": len(findings),
        "findings": findings,
    }


def contract_snapshot() -> dict[str, object]:
    """Everything the registration freezes, as plain data."""
    return {
        "experiment_id": EXPERIMENT_ID,
        "plan": PLAN_PATH,
        "targets": list(TARGETS),
        "control_type": CONTROL_TYPE,
        "fold_years": list(CANDIDATE_FOLD_YEARS),
        "seeds": list(SEEDS),
        "leads": list(LEADS),
        "report_leads": list(REPORT_LEADS),
        "effect_floor_m": EFFECT_FLOOR_M,
        "scenarios": {
            target: {name: sorted(removed_stations(target, name)) for name in scenarios(target)}
            for target in TARGETS
        },
        "side_scenarios": {
            target: {side: side_scenario(target, side) for side in ("upstream", "downstream")}
            for target in TARGETS
        },
        "screening_pairs": {target: [list(pair) for pair in screening_pairs(target)]
                            for target in TARGETS},
        "hybrid": {
            "ridge_alpha": RIDGE_ALPHA,
            "gbm_parameters_without_seed": {
                key: value for key, value in gbm_parameters(0).items() if key != "seed"
            },
            "gbm_max_rounds": GBM_MAX_ROUNDS,
            "gbm_early_stopping_rounds": GBM_EARLY_STOPPING_ROUNDS,
            "gbm_primary_seed": GBM_PRIMARY_SEED,
            "gbm_extra_seeds": list(GBM_EXTRA_SEEDS),
            "target": "residual of the ridge prediction, one booster per lead",
            "early_stopping_data": "inner-validation year of the fold",
            "no_retrain_baselines": list(NO_RETRAIN_BASELINES),
            "no_retrain_fills": list(NO_RETRAIN_FILLS),
            "frozen_tide_scenarios": list(FROZEN_TIDE_SCENARIOS),
        },
        "h1": {
            "years": list(H1_YEARS),
            "tides": list(H1_TIDES),
            "conditions": {target: list(h1_conditions(target)) for target in TARGETS},
            "task_count": len(h1_tasks()),
        },
        "travel_time_hours": {"%s<-%s" % key: value for key, value in TRAVEL_TIME_HOURS.items()},
        "arrival_windows": {
            "%s<-%s" % key: {"window": list(value[0]), "pre": list(value[1])}
            for key, value in ARRIVAL_WINDOWS_BY_HAND.items()
        },
        "fall_after_arrival": {
            "%s<-%s" % key: {"early": list(value[0]), "late": list(value[1])}
            for key, value in FALL_AFTER_ARRIVAL.items()
        },
        "dry_months": list(DRY_MONTHS),
        "wet_months": list(WET_MONTHS),
        "inference": INFERENCE,
        "predictions": PREDICTIONS,
        "gates": GATES,
    }


if __name__ == "__main__":
    print(json.dumps(validate_contract(), ensure_ascii=False, indent=2))
