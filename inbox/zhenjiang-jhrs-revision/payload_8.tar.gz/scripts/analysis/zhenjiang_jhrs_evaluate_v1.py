"""Judge the JH:RS revision runs against the registered rules.

Written before any output of the run root had been read. Every rule is taken
from the registered contract (PREDICTIONS, GATES, INFERENCE); nothing here may
be changed after results are seen except to fix a crash, and any such fix is
recorded in the registration addendum.

What it computes
----------------
- Absolute errors per issue time from every hybrid unit (ridge and hybrid) and
  every H1 task (Transformer).
- Per-year costs, eight-year medians and hierarchical bootstrap intervals
  (years, then ISO weeks within year), paired across scenarios.
- The mechanical verdicts of P1-P9 and of the H1 gates G-A to G-C.
- Descriptive tables: all costs with intervals, side removals, no-retrain
  costs, and the spread of costs over the three tree seeds.

Inputs
------
--run-root   results root of the run (hybrid/units, h1_tasks)
--out-dir    destination; defaults to <run-root>/evaluation
--partial    evaluate whatever is complete instead of refusing (diagnostics
             only; verdicts are then marked partial)

Outputs
-------
<out-dir>/verdicts.json, cost_table.csv, seed_spread.csv, h1_cells.csv

Usage
-----
python -X utf8 -B scripts/analysis/zhenjiang_jhrs_evaluate_v1.py \
    --run-root results/modeling/zhenjiang_jhrs_local_run_v1
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[2]
for _relative in ("scripts/analysis", "scripts/modeling", "scripts/astronomical_tide"):
    _candidate = str(PROJECT_ROOT / _relative)
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)

import zhenjiang_jhrs_revision_contract as contract  # noqa: E402

MODELS = ("hybrid", "ridge")
YEARS = tuple(contract.CANDIDATE_FOLD_YEARS)


# --- loading --------------------------------------------------------------------


class Calendar:
    """Issue-time attributes on the model axis."""

    def __init__(self, times_beijing):
        self.year = np.asarray([value.year for value in times_beijing], dtype=np.int64)
        self.month = np.asarray([value.month for value in times_beijing], dtype=np.int64)
        iso = [value.isocalendar() for value in times_beijing]
        self.week = np.asarray([item[0] * 100 + item[1] for item in iso], dtype=np.int64)


class HybridStore:
    """Absolute errors of every hybrid unit, keyed by part/tide/year/target/scenario/seed."""

    def __init__(self, units_dir: Path, partial: bool):
        self.errors = {}
        self.positions = {}
        self.missing = []
        for unit in contract.hybrid_units():
            npz = units_dir / (unit["unit_id"] + ".npz")
            done = units_dir / (unit["unit_id"] + ".json")
            if not (npz.exists() and done.exists()):
                self.missing.append(unit["unit_id"])
                continue
            with np.load(npz) as payload:
                leads = [int(value) for value in payload["leads"]]
                observed = payload["observed_m"].astype(np.float64)
                positions = payload["issue_positions"].astype(np.int64)
                key = (unit["part"], unit["tide"], unit["test_year"], unit["target"],
                       unit["scenario"], unit["gbm_seed"])
                entry = {}
                for model in MODELS:
                    error = np.abs(payload["%s_m" % model].astype(np.float64) - observed)
                    entry[model] = {lead: error[:, j] for j, lead in enumerate(leads)}
                for name in payload.files:
                    if name.startswith("noretrain__"):
                        _, station, fill, model_tag = name.split("__")
                        model = model_tag[:-2]
                        error = np.abs(payload[name].astype(np.float64) - observed)
                        entry[("noretrain", station, fill, model)] = {
                            lead: error[:, j] for j, lead in enumerate(leads)}
                self.errors[key] = entry
            previous = self.positions.setdefault(unit["test_year"], positions)
            if not np.array_equal(previous, positions):
                raise RuntimeError("issue positions differ within test year %d" % unit["test_year"])
        if self.missing and not partial:
            raise RuntimeError("%d hybrid units are missing" % len(self.missing))

    def get(self, part, tide, year, target, scenario, seed, model, lead):
        return self.errors[(part, tide, year, target, scenario, seed)][model][lead]


# --- statistics -----------------------------------------------------------------


class Bootstrap:
    """Years with replacement, then ISO weeks within each drawn year."""

    def __init__(self, calendar: Calendar, positions_by_year: dict):
        settings = contract.INFERENCE["bootstrap"]
        self.replicates = int(settings["replicates"])
        self.rng = np.random.default_rng(int(settings["random_seed"]))
        self.years = [year for year in YEARS if year in positions_by_year]
        self.week_index = {}
        self.week_count = {}
        for year in self.years:
            weeks = calendar.week[positions_by_year[year]]
            _, inverse = np.unique(weeks, return_inverse=True)
            self.week_index[year] = inverse
            self.week_count[year] = int(inverse.max()) + 1
        draws = len(self.years)
        self.year_draws = self.rng.integers(0, draws, size=(self.replicates, draws))
        self.week_draws = {
            year: self.rng.integers(0, self.week_count[year],
                                    size=(self.replicates * draws, self.week_count[year]))
            for year in self.years
        }

    def interval(self, combination):
        """combination(year) -> list of (weight, error vector); returns point, low, high.

        The per-year statistic is sum(weight * mean(error vector)); the summary is
        the median over years.
        """
        per_year_point = []
        per_year_samples = {}
        for year in self.years:
            terms = combination(year)
            point = sum(weight * float(np.mean(vector)) for weight, vector in terms)
            per_year_point.append(point)
            index = self.week_index[year]
            count = np.bincount(index, minlength=self.week_count[year]).astype(np.float64)
            sums = np.zeros(self.week_count[year], dtype=np.float64)
            for weight, vector in terms:
                sums += weight * np.bincount(index, weights=vector, minlength=self.week_count[year])
            draws = self.week_draws[year]
            per_year_samples[year] = sums[draws].sum(axis=1) / count[draws].sum(axis=1)
        draws = len(self.years)
        samples = np.vstack([per_year_samples[year] for year in self.years])
        slots = np.arange(self.replicates)[:, None] * draws + np.arange(draws)[None, :]
        gathered = samples[self.year_draws, slots]
        medians = np.median(gathered, axis=1)
        return (float(np.median(per_year_point)), float(np.percentile(medians, 2.5)),
                float(np.percentile(medians, 97.5)))


def mae(vector) -> float:
    return float(np.mean(vector))


# --- the evaluator --------------------------------------------------------------


class Evaluator:
    def __init__(self, store: HybridStore, calendar: Calendar, bootstrap: Bootstrap):
        self.store = store
        self.calendar = calendar
        self.boot = bootstrap
        self.years = bootstrap.years

    def error(self, target, scenario, model, lead, year, part="main", tide="fold",
              seed=contract.GBM_PRIMARY_SEED):
        return self.store.get(part, tide, year, target, scenario, seed, model, lead)

    def year_cost(self, target, scenario, base, model, lead, year, mask=None, **kind):
        arm = self.error(target, scenario, model, lead, year, **kind)
        ref = self.error(target, base, model, lead, year, **kind)
        if mask is not None:
            arm, ref = arm[mask], ref[mask]
        return mae(arm) - mae(ref)

    def median_cost(self, target, scenario, base, model, lead, **kind):
        return float(np.median([self.year_cost(target, scenario, base, model, lead, year, **kind)
                                for year in self.years]))

    def cost_interval(self, target, scenario, base, model, lead):
        return self.boot.interval(lambda year: [
            (1.0, self.error(target, scenario, model, lead, year)),
            (-1.0, self.error(target, base, model, lead, year))])

    def single_costs(self, target, family, model, lead):
        base = contract.baseline_scenario(family)
        return {gauge: self.median_cost(target, scenario, base, model, lead)
                for gauge, scenario in contract.single_removals(target, family).items()}

    # P1 ---------------------------------------------------------------------
    def p1(self):
        rule = contract.PREDICTIONS["P1"]
        details, passed = [], True
        for check in rule["checks"]:
            target, gauge = check["target"], check["gauge"]
            scenarios = contract.single_removals(target, "unavailable")
            for lead in check["leads"]:
                costs = self.single_costs(target, "unavailable", "hybrid", lead)
                ranking = sorted(costs, key=costs.get, reverse=True)
                second = ranking[1] if ranking[0] == gauge else ranking[0]
                point, low, high = self.boot.interval(lambda year: [
                    (1.0, self.error(target, scenarios[gauge], "hybrid", lead, year)),
                    (-1.0, self.error(target, scenarios[second], "hybrid", lead, year))])
                ok = ranking[0] == gauge and low > 0
                passed &= ok
                details.append({"target": target, "gauge": gauge, "lead": lead,
                                "largest": ranking[0], "second": second,
                                "difference_m": point, "interval_m": [low, high], "pass": ok})
        return {"pass": passed, "details": details}

    # P2 ---------------------------------------------------------------------
    def p2(self):
        rule = contract.PREDICTIONS["P2"]
        details, passed = [], True
        for lead in rule["leads"]:
            costs = self.single_costs("nanjing", "unavailable", "hybrid", lead)
            river = min(costs["datong"], costs["zhenjiang"])
            tidal = max(costs["jiangyin"], costs["xuliujing"], costs["wusongkou"])
            ok = river > tidal
            passed &= ok
            details.append({"lead": lead, "costs_m": costs, "pass": ok})
        return {"pass": passed, "details": details}

    # P3 ---------------------------------------------------------------------
    def p3a(self):
        details, passed = [], True
        for lead in contract.PREDICTIONS["P3a"]["leads"]:
            both = self.median_cost("nanjing", "hidden_target_both_nearest", "hidden_target",
                                    "hybrid", lead)
            screened = self.median_cost("nanjing", "hidden_target_minus_zhenjiang_and_jiangyin",
                                        "hidden_target", "hybrid", lead)
            ok = both > screened
            passed &= ok
            details.append({"lead": lead, "zhenjiang_and_datong_m": both,
                            "zhenjiang_and_jiangyin_m": screened, "pass": ok})
        return {"pass": passed, "details": details}

    def p3b(self):
        rule = contract.PREDICTIONS["P3b"]
        lead = rule["leads"][0]
        details, count = [], 0
        for target in contract.TARGETS:
            for nearest, following in contract.screening_pairs(target):
                pair = "hidden_target_minus_%s_and_%s" % (nearest, following)
                joint = self.median_cost(target, pair, "hidden_target", "hybrid", lead)
                first = self.median_cost(target, "hidden_target_minus_%s" % nearest,
                                         "hidden_target", "hybrid", lead)
                alone = self.median_cost(target, "hidden_target_minus_%s" % following,
                                         "hidden_target", "hybrid", lead)
                ok = (joint - first) > alone
                count += ok
                details.append({"target": target, "nearest": nearest, "next": following,
                                "increment_m": joint - first, "next_alone_m": alone, "holds": ok})
        return {"pass": count >= rule["minimum_count"], "count": count, "details": details}

    # P4 ---------------------------------------------------------------------
    def p4(self):
        rule = contract.PREDICTIONS["P4"]
        details, passed = [], True
        for target in rule["targets"]:
            up, down = contract.nearest_neighbours(target)
            for lead in rule["leads"]:
                point, low, high = self.boot.interval(lambda year: [
                    (1.0, self.error(target, "hidden_target_both_nearest", "hybrid", lead, year)),
                    (-1.0, self.error(target, "hidden_target_minus_%s" % up, "hybrid", lead, year)),
                    (-1.0, self.error(target, "hidden_target_minus_%s" % down, "hybrid", lead, year)),
                    (1.0, self.error(target, "hidden_target", "hybrid", lead, year))])
                ok = low > 0
                passed &= ok
                details.append({"target": target, "lead": lead, "excess_m": point,
                                "interval_m": [low, high], "pass": ok})
        return {"pass": passed, "details": details}

    # P5 ---------------------------------------------------------------------
    def p5(self):
        lead = contract.PREDICTIONS["P5"]["leads"][0]
        costs = {target: self.single_costs(target, "visible", "hybrid", lead)
                 for target in contract.TARGETS}
        largest = max(value for table in costs.values() for value in table.values())
        return {"pass": largest < contract.EFFECT_FLOOR_M, "largest_m": largest, "costs_m": costs}

    # P6 ---------------------------------------------------------------------
    def window_rise(self, target, gauge, family, model, year, mask=None):
        window, pre = contract.arrival_window(target, gauge)
        base = contract.baseline_scenario(family)
        scenario = contract.single_removals(target, family)[gauge]
        cost = {lead: self.year_cost(target, scenario, base, model, lead, year, mask=mask)
                for lead in set(window) | set(pre)}
        return np.mean([cost[lead] for lead in window]) - np.mean([cost[lead] for lead in pre])

    def p6(self):
        rule = contract.PREDICTIONS["P6"]
        outer = list(contract.ARRIVAL_WINDOWS_BY_HAND)
        result = {}
        for model in rule["models"]:
            pooled = {year: float(np.mean([self.window_rise(t, g, "visible", model, year)
                                           for t, g in outer])) for year in self.years}
            part_a = sum(value > 0 for value in pooled.values())
            falls = {}
            for (target, gauge), (early, late) in contract.FALL_AFTER_ARRIVAL.items():
                scenario = contract.single_removals(target, "visible")[gauge]
                falls["%s<-%s" % (target, gauge)] = sum(
                    np.mean([self.year_cost(target, scenario, "complete_observation", model, lead, year)
                             for lead in early])
                    - np.mean([self.year_cost(target, scenario, "complete_observation", model, lead, year)
                               for lead in late]) > 0
                    for year in self.years)
            peaks = {}
            for (target, gauge), travel in contract.TRAVEL_TIME_HOURS.items():
                scenario = contract.single_removals(target, "visible")[gauge]
                curve = [self.median_cost(target, scenario, "complete_observation", model, lead)
                         for lead in contract.LEADS]
                peak = contract.LEADS[int(np.argmax(curve))]
                peaks["%s<-%s" % (target, gauge)] = {"peak_lead": peak, "travel_hours": travel,
                                                     "within": abs(peak - travel) <= rule["peak_tolerance_hours"]}
            part_c = sum(item["within"] for item in peaks.values())
            ok_a = part_a >= rule["minimum_years_a"]
            ok_b = all(count >= rule["minimum_years_b"] for count in falls.values())
            ok_c = part_c >= rule["minimum_pairs_c"]
            result[model] = {"pass": ok_a and ok_b and ok_c,
                             "a_years_positive": part_a, "a_pooled_rise_m": pooled,
                             "b_years_positive": falls, "c_pairs_within": part_c, "c_peaks": peaks}
        result["pass"] = all(result[model]["pass"] for model in rule["models"])
        return result

    # P7 ---------------------------------------------------------------------
    def p7(self):
        rule = contract.PREDICTIONS["P7"]
        by_year = {}
        for year in self.years:
            positions = self.store.positions[year]
            month = self.calendar.month[positions]
            dry = np.isin(month, contract.DRY_MONTHS)
            wet = np.isin(month, contract.WET_MONTHS)
            rise_dry = np.mean([self.window_rise(t, g, "unavailable", "hybrid", year, mask=dry)
                                for t, g in rule["pairs"]])
            rise_wet = np.mean([self.window_rise(t, g, "unavailable", "hybrid", year, mask=wet)
                                for t, g in rule["pairs"]])
            by_year[year] = float(rise_dry - rise_wet)
        count = sum(value > 0 for value in by_year.values())
        return {"pass": count >= rule["minimum_years"], "years_positive": count,
                "dry_minus_wet_m": by_year}

    # P8 ---------------------------------------------------------------------
    def p8(self):
        rule = contract.PREDICTIONS["P8"]
        details, passed = [], True
        for target in contract.TARGETS:
            costs = self.single_costs(target, "unavailable", "hybrid", 1)
            gauge = max(costs, key=costs.get)
            for lead in rule["leads"]:
                retrained = self.median_cost(target, "hidden_target_minus_%s" % gauge,
                                             "hidden_target", "hybrid", lead)
                key = ("noretrain", gauge, rule["fill"], "hybrid")
                sudden = float(np.median([
                    mae(self.store.errors[("main", "fold", year, target, "hidden_target",
                                           contract.GBM_PRIMARY_SEED)][key][lead])
                    - mae(self.error(target, "hidden_target", "hybrid", lead, year))
                    for year in self.years]))
                ok = sudden >= retrained
                passed &= ok
                details.append({"target": target, "gauge": gauge, "lead": lead,
                                "no_retrain_m": sudden, "retrained_m": retrained, "pass": ok})
        return {"pass": passed, "details": details}

    # P9 ---------------------------------------------------------------------
    def p9(self):
        rule = contract.PREDICTIONS["P9"]
        result = {}
        for model in rule["models"]:
            differences = []
            same_top_two = True
            for target in contract.TARGETS:
                for lead in rule["leads"]:
                    fold, frozen = {}, {}
                    for gauge, scenario in contract.single_removals(target, "unavailable").items():
                        per_fold, per_frozen = [], []
                        for year in self.years:
                            a = self.year_cost(target, scenario, "hidden_target", model, lead, year)
                            b = self.year_cost(target, scenario, "hidden_target", model, lead, year,
                                               part="frozen_tide", tide="frozen")
                            differences.append(abs(b - a))
                            per_fold.append(a)
                            per_frozen.append(b)
                        fold[gauge] = float(np.median(per_fold))
                        frozen[gauge] = float(np.median(per_frozen))
                    top_fold = sorted(fold, key=fold.get, reverse=True)[:2]
                    top_frozen = sorted(frozen, key=frozen.get, reverse=True)[:2]
                    same_top_two &= top_fold == top_frozen
            p95 = float(np.percentile(differences, 95))
            result[model] = {"pass": p95 <= rule["maximum_p95_m"] and same_top_two,
                             "p95_abs_difference_m": p95, "same_top_two": same_top_two}
        result["pass"] = all(result[model]["pass"] for model in rule["models"])
        return result

    # descriptive --------------------------------------------------------------
    def cost_rows(self):
        rows = []
        for target in contract.TARGETS:
            for scenario in contract.scenarios(target):
                if scenario in ("complete_observation", "hidden_target"):
                    continue
                base = "complete_observation" if scenario.startswith("complete_") else "hidden_target"
                for model in MODELS:
                    for lead in contract.REPORT_LEADS:
                        point, low, high = self.cost_interval(target, scenario, base, model, lead)
                        base_mae = float(np.median([mae(self.error(target, base, model, lead, year))
                                                    for year in self.years]))
                        rows.append({"target": target, "scenario": scenario, "baseline": base,
                                     "model": model, "lead": lead, "cost_m": point,
                                     "low_m": low, "high_m": high, "baseline_mae_m": base_mae})
        return rows

    def seed_rows(self):
        rows = []
        seeds = (contract.GBM_PRIMARY_SEED,) + contract.GBM_EXTRA_SEEDS
        for target in contract.TARGETS:
            for gauge, scenario in contract.single_removals(target, "unavailable").items():
                for lead in contract.REPORT_LEADS:
                    for year in self.years:
                        values = []
                        for seed in seeds:
                            part = "main" if seed == contract.GBM_PRIMARY_SEED else "seed"
                            values.append(self.year_cost(target, scenario, "hidden_target", "hybrid",
                                                         lead, year, part=part, seed=seed))
                        rows.append({"target": target, "gauge": gauge, "lead": lead, "year": year,
                                     "cost_seed_17_m": values[0], "seed_sd_m": float(np.std(values, ddof=1))})
        return rows


# --- H1 gates ---------------------------------------------------------------------


def h1_gates(tasks_dir: Path, partial: bool):
    errors = {}
    missing = []
    for task in contract.h1_tasks():
        path = tasks_dir / task["task_id"] / "test_predictions.npz"
        if not (tasks_dir / task["task_id"] / "completion_manifest.json").exists():
            missing.append(task["task_id"])
            continue
        with np.load(path) as payload:
            error = np.abs(payload["prediction_m"].astype(np.float64)
                           - payload["target_m"].astype(np.float64))
        errors[(task["tide"], task["test_year"], task["target"], task["condition"], task["seed"])] = {
            lead: float(np.mean(error[:, lead - 1])) for lead in contract.REPORT_LEADS}
    if missing and not partial:
        raise RuntimeError("%d H1 tasks are missing" % len(missing))

    def cell(tide, year, target, gauge, lead):
        values = []
        for seed in contract.SEEDS:
            arm = errors.get((tide, year, target, "hidden_target_minus_%s" % gauge, seed))
            ref = errors.get((tide, year, target, "hidden_target", seed))
            if arm is not None and ref is not None:
                values.append(arm[lead] - ref[lead])
        return float(np.median(values)) if values else float("nan")

    def baseline(tide, year, target, lead):
        values = [errors[(tide, year, target, "hidden_target", seed)][lead]
                  for seed in contract.SEEDS if (tide, year, target, "hidden_target", seed) in errors]
        return float(np.median(values)) if values else float("nan")

    gates = contract.GATES
    rows = []
    g_a, g_c = {}, {}
    for lead in contract.REPORT_LEADS:
        shifts = []
        for target in contract.TARGETS:
            for gauge in contract.other_stations(target):
                changes = [cell("fold", year, target, gauge, lead) - cell("frozen", year, target, gauge, lead)
                           for year in contract.H1_YEARS]
                shifts.append(abs(float(np.mean(changes))))
                for year in contract.H1_YEARS:
                    rows.append({"target": target, "gauge": gauge, "lead": lead, "year": year,
                                 "cost_frozen_m": cell("frozen", year, target, gauge, lead),
                                 "cost_fold_m": cell("fold", year, target, gauge, lead)})
        value = float(np.mean(shifts))
        g_a[str(lead)] = {"mean_abs_shift_m": value, "limit_m": gates["G-A"]["limits_m"][str(lead)],
                          "pass": value <= gates["G-A"]["limits_m"][str(lead)]}
        baseline_shift = float(np.mean([baseline("fold", year, target, lead) - baseline("frozen", year, target, lead)
                                        for target in contract.TARGETS for year in contract.H1_YEARS]))
        g_c[str(lead)] = {"mean_baseline_shift_m": baseline_shift,
                          "limit_m": gates["G-C"]["limits_m"][str(lead)],
                          "pass": baseline_shift <= gates["G-C"]["limits_m"][str(lead)]}
    g_b = []
    for target, gauge, leads in (("xuliujing", "wusongkou", (1, 3, 6)), ("jiangyin", "xuliujing", (1,))):
        for year in contract.H1_YEARS:
            for lead in leads:
                costs = {name: cell("fold", year, target, name, lead) for name in contract.other_stations(target)}
                g_b.append({"target": target, "year": year, "lead": lead,
                            "largest": max(costs, key=costs.get), "pass": max(costs, key=costs.get) == gauge})
    verdict = {
        "G-A": {"pass": all(item["pass"] for item in g_a.values()), "leads": g_a},
        "G-B": {"pass": all(item["pass"] for item in g_b), "checks": g_b},
        "G-C": {"pass": all(item["pass"] for item in g_c.values()), "leads": g_c},
        "missing_tasks": len(missing),
    }
    verdict["all_pass"] = verdict["G-A"]["pass"] and verdict["G-B"]["pass"] and verdict["G-C"]["pass"]
    verdict["decision"] = ("Transformer results stay in the main text" if verdict["all_pass"] else
                           "Transformer results move to the supplement with the caveat; no full rerun")
    return verdict, rows


def write_csv(path: Path, rows) -> None:
    if not rows:
        return
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-root", required=True)
    parser.add_argument("--out-dir", default="")
    parser.add_argument("--partial", action="store_true")
    arguments = parser.parse_args()

    import zhenjiang_oyv_v1_data as data_module

    run_root = Path(arguments.run_root)
    out_dir = Path(arguments.out_dir) if arguments.out_dir else run_root / "evaluation"
    out_dir.mkdir(parents=True, exist_ok=True)
    data = data_module.load_out_of_year_data()
    calendar = Calendar(data.times_beijing)
    store = HybridStore(run_root / "hybrid" / "units", arguments.partial)
    bootstrap = Bootstrap(calendar, store.positions)
    evaluator = Evaluator(store, calendar, bootstrap)

    verdicts = {"partial": bool(store.missing), "missing_hybrid_units": len(store.missing)}
    stop_loss = evaluator.p1()
    verdicts["P1"] = stop_loss
    if not stop_loss["pass"]:
        verdicts["stop"] = contract.PREDICTIONS["P1"]["on_failure"]
    for name, method in (("P2", evaluator.p2), ("P3a", evaluator.p3a), ("P3b", evaluator.p3b),
                         ("P4", evaluator.p4), ("P5", evaluator.p5), ("P6", evaluator.p6),
                         ("P7", evaluator.p7), ("P8", evaluator.p8), ("P9", evaluator.p9)):
        verdicts[name] = method()
    gates, h1_rows = h1_gates(run_root / "h1_tasks", arguments.partial)
    verdicts["H1"] = gates

    (out_dir / "verdicts.json").write_text(json.dumps(verdicts, indent=2, default=float) + "\n",
                                           encoding="utf-8")
    write_csv(out_dir / "cost_table.csv", evaluator.cost_rows())
    write_csv(out_dir / "seed_spread.csv", evaluator.seed_rows())
    write_csv(out_dir / "h1_cells.csv", h1_rows)
    print(json.dumps({key: (value.get("pass", value.get("all_pass")) if isinstance(value, dict) else value)
                      for key, value in verdicts.items()}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
