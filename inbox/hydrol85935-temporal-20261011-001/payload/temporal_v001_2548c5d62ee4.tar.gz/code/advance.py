"""Standard-library-only, idempotent HPC controller; waits only for parent model prerequisites."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import subprocess

IDENTITY = "hydrol85935_temporal_persistence_20261011_001"
SEEDS = (100, 200, 300)
STAGES = ("preflight", "main_s100", "main_s200", "main_s300", "report")
TERMINAL = {"COMPLETED", "FAILED", "CANCELLED", "TIMEOUT", "NODE_FAIL", "OUT_OF_MEMORY", "PREEMPTED", "BOOT_FAIL", "DEADLINE", "REVOKED"}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""): h.update(b)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, sort_keys=True, indent=2, allow_nan=False)
        f.write("\n"); f.flush(); os.fsync(f.fileno())


def training_probe(parent, version):
    execution = parent / "execution" / version
    markers = [execution / f"training/s{s}/complete.json" for s in SEEDS]
    missing = [s for s, p in zip(SEEDS, markers) if not p.is_file()]
    if missing:
        return dict(status="WAITING_FOR_TRAINING", missing_seeds=missing, parent_execution=str(execution))
    frozen = read(execution / "frozen/manifest.json")
    digest = hashlib.sha256(json.dumps(frozen, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()
    for seed, marker in zip(SEEDS, markers):
        m = read(marker)
        if (m != read(execution / f"frozen/training_assets/s{seed}.json") or m["seed"] != seed
                or m["status"] != "complete" or m["epoch"] != 30 or m["manifest_sha256"] != digest):
            raise ValueError("Incomplete or inconsistent trained-model registration")
        run = (execution / m["run_relative_path"]).resolve(strict=True)
        if not run.is_relative_to(execution.resolve()):
            raise ValueError("Escaping trained-model path")
        for item in m["assets"].values():
            path = (run / item["relative_path"]).resolve(strict=True)
            if not path.is_relative_to(run) or sha(path) != item["sha256"]:
                raise ValueError("Trained model artifact hash mismatch")
    return dict(status="TRAINING_ASSETS_AVAILABLE", parent_manifest_sha256=digest)


def scheduler(record):
    job = str(record["job_id"])
    result = subprocess.run(["sacct", "-j", job, "-n", "-P", "--format=JobID,State,ExitCode"],
                            text=True, capture_output=True, timeout=60, check=True)
    rows = [line.strip().split("|") for line in result.stdout.splitlines() if line.strip()]
    expected = {job} if record["array_tasks"] == 0 else {f"{job}_{i}" for i in range(record["array_tasks"])}
    matching = {r[0]: r[1:3] for r in rows if r[0] in expected and len(r) >= 3}
    failed = {k: v for k, v in matching.items() if v[0].split()[0] in TERMINAL and v != ["COMPLETED", "0:0"]}
    if failed:
        return dict(status="FAILED", jobs=failed)
    return dict(status="COMPLETE" if set(matching) == expected and all(v == ["COMPLETED", "0:0"] for v in matching.values()) else "WAITING",
                observed=len(matching), expected=len(expected))


def verify_bundle(root):
    inventory = read(root / "deployment_manifest.json")
    required = {"code/advance.py", "code/protocol.json"} | {
        "code/temporal_20261011/" + n for n in ("__init__.py", "core.py", "storage.py", "run.py")}
    if inventory.get("identity") != IDENTITY or not required.issubset(inventory.get("sha256", {})):
        raise ValueError("Incomplete deployment inventory")
    for relative, expected in inventory["sha256"].items():
        p = (root / relative).resolve(strict=True)
        if not p.is_relative_to(root.resolve()) or sha(p) != expected:
            raise ValueError("Additional code/config deployment changed: " + relative)
    return sha(root / "deployment_manifest.json")


def layout(root):
    evidence = read(root / "control/resource_pilot.json")
    verified = read(root / "control/new_models_verified.json")
    manifest = read(root / "frozen/manifest.json")
    digest = hashlib.sha256(json.dumps(manifest, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()
    if evidence["status"] != "PASS" or verified["status"] != "PASS" or evidence["manifest_sha256"] != digest or verified["manifest_sha256"] != digest:
        raise ValueError("Additional preflight/pilot identity mismatch")
    if evidence["allowance_factor"] != 2 or evidence["wall_limit_seconds"] != 21600:
        raise ValueError("Changed resource acceptance rule")
    if len(evidence["record_complete_sha256"]) != 3 or len(verified.get("checks", [])) != 12:
        raise ValueError("Incomplete three-model verification or pilot")
    for seed, h in zip(SEEDS, evidence["record_complete_sha256"]):
        if sha(root / f"pilot/single_temperature_s{seed}/01022500/complete.json") != h:
            raise ValueError("Pilot record identity changed")
    seconds = evidence["pair_seconds"]
    if len(seconds) != 3 or not all(math.isfinite(x) and x > 0 for x in seconds):
        raise ValueError("Invalid actual pilot timing")
    chunk = evidence["basin_chunk"]
    if chunk not in (10, 5, 1) or 2 * max(seconds) * chunk + 600 > 21600:
        raise ValueError("Unsafe resource layout")
    return chunk


def job_script(root, parent, version, stage, chunk=1):
    if stage not in STAGES or not re.fullmatch(r"v[0-9]{3}", version):
        raise ValueError("Unknown stage/version")
    root, parent = PurePosixPath(Path(root).as_posix()), PurePosixPath(Path(parent).as_posix())
    code = parent / "versions" / version / "code"
    execution = parent / "execution" / version
    quote = lambda value: shlex.quote(str(value))
    lines = ["#!/bin/bash", f"#SBATCH -J hydrol85935-temporal-{stage}", "#SBATCH -p hgpu2p",
             "#SBATCH -N 1", "#SBATCH -n 1", "#SBATCH --cpus-per-task=4", "#SBATCH --gres=gpu:1",
             "#SBATCH --exclude=ngu002", "#SBATCH -t 06:00:00", "#SBATCH --no-requeue",
             f"#SBATCH -o {root}/logs/{stage}-%A_%a.out", f"#SBATCH -e {root}/logs/{stage}-%A_%a.err"]
    if stage.startswith("main_s"):
        lines.append(f"#SBATCH --array=0-{math.ceil(531/chunk)-1}%1")
    lines += ["set -eo pipefail", "export PYTHONDONTWRITEBYTECODE=1",
              f"export TMPDIR={quote(root / 'tmp')}/job-$SLURM_JOB_ID", 'mkdir -p "$TMPDIR"',
              'export TMP="$TMPDIR" TEMP="$TMPDIR" XDG_CACHE_HOME="$TMPDIR/cache" MPLCONFIGDIR="$TMPDIR/matplotlib"',
              "source /data1/home/sunyiq/miniconda3/etc/profile.d/conda.sh", "conda activate nh_final",
              "export MKL_THREADING_LAYER=GNU MKL_SERVICE_FORCE_INTEL=1 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4",
              f"export PYTHONPATH={quote(str(parent / 'runtime_torch271cu118/site') + ':' + str(code) + ':' + str(root / 'code'))}",
              f"cd {quote(root)}",
              f"python {quote(parent / 'control' / ('full_' + version) / 'verify_preflight.py')} --root {quote(parent)} --version {version} --skip-scheduler",
              f"python {quote(parent / 'control' / ('full_' + version) / 'verify_isolated_runtime.py')} --root {quote(parent)} --version {version} --compute"]
    common = ["python", "-u", "-m", "temporal_20261011.run", "--parent-root", str(execution), "--parent-code", str(code),
              "--data-dir", str(parent / "inputs_v001"), "--data-manifest", str(parent / "versions" / version / "DATA.sha256"),
              "--original-models-root", str(parent / "original_models"), "--root", str(root),
              "--protocol", str(root / "code/protocol.json"), "--device", "cuda:0"]
    command = " ".join(map(quote, common))
    if stage == "preflight":
        lines += [command + " --mode preflight", command + " --mode pilot"]
    elif stage == "report":
        lines += [command + " --mode report"]
    else:
        seed = int(stage.split("s")[-1])
        lines += [f'start=$((SLURM_ARRAY_TASK_ID * {chunk}))', 'count=$((531 - start))',
                  f'if [ "$count" -gt {chunk} ]; then count={chunk}; fi',
                  command + f' --mode run --seed {seed} --basin-start "$start" --basin-count "$count"']
    return "\n".join(lines) + "\n"


def submit(root, parent, version, stage, chunk, deployment_sha):
    folder = root / "control/submissions"
    folder.mkdir(parents=True, exist_ok=True)
    attempt, receipt = folder / f"{stage}.attempt.json", folder / f"{stage}.json"
    if attempt.exists():
        raise RuntimeError("Submission already attempted; reconcile its actual outcome before any retry")
    script = folder / f"{stage}.sbatch"
    with script.open("x", encoding="utf-8", newline="\n") as f: f.write(job_script(root, parent, version, stage, chunk))
    item = dict(stage=stage, parent_version=version, script_sha256=sha(script), deployment_sha256=deployment_sha,
                array_tasks=math.ceil(531/chunk) if stage.startswith("main_s") else 0)
    write_new(attempt, item)
    result = subprocess.run(["sbatch", str(script)], text=True, capture_output=True, timeout=120)
    output = result.stdout + result.stderr
    (folder / f"{stage}.submission.txt").write_text(output, encoding="utf-8")
    ids = re.findall(r"(?m)^Submitted batch job ([0-9]+)$", output)
    if result.returncode or len(ids) != 1:
        raise RuntimeError("Submission was not confirmed; preserve attempt, do not resubmit")
    item.update(job_id=int(ids[0]), status="SUBMITTED")
    write_new(receipt, item)
    return item


def advance(root, parent, version, python):
    if root.name != IDENTITY or (root / "OWNER").read_text().strip() != IDENTITY:
        raise ValueError("Wrong additional-experiment owner")
    if parent.name != "hydrol85935_revision_20261008_001" or not re.fullmatch(r"v[0-9]{3}", version):
        raise ValueError("Wrong parent experiment/version")
    if root.is_relative_to(parent) or parent.is_relative_to(root):
        raise ValueError("Additional and parent output roots overlap")
    deployment = verify_bundle(root)
    ready = training_probe(parent, version)
    if ready["status"] != "TRAINING_ASSETS_AVAILABLE":
        return ready
    # Validate the parent's original-prediction/runtime gate, but do not inspect any parent attack result.
    subprocess.run([python, str(parent / "control" / ("full_" + version) / "verify_preflight.py"),
                    "--root", str(parent), "--version", version], check=True, timeout=300, capture_output=True, text=True)
    (root / "logs").mkdir(exist_ok=True)
    (root / "control").mkdir(exist_ok=True)
    lock = root / "control/advance.lock"
    with lock.open("x") as f: f.write(str(os.getpid()))
    try:
        for stage in STAGES:
            receipt = root / f"control/submissions/{stage}.json"
            if not receipt.exists():
                chunk = 1 if stage == "preflight" else layout(root)
                return submit(root, parent, version, stage, chunk, deployment)
            record = read(receipt)
            if record["deployment_sha256"] != deployment or record["parent_version"] != version:
                raise ValueError("Previously submitted stage used different code or parent version")
            state = scheduler(record)
            if state["status"] != "COMPLETE":
                return dict(stage=stage, job_id=record["job_id"], **state)
        report = read(root / "reports/coverage_and_summary.json")
        if (report["status"] not in ("COMPLETE", "COMPLETE_WITH_UNCOMPUTABLE")
                or report["complete_search_records"] + report.get("uncomputable_search_records", 0) != 3186):
            raise ValueError("All jobs ended but scientific coverage is incomplete")
        return dict(status=report["status"], search_records=report["complete_search_records"],
                    uncomputable_search_records=report.get("uncomputable_search_records", 0),
                    report=str(root / "reports/coverage_and_summary.json"))
    finally:
        lock.unlink()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", required=True, type=Path)
    p.add_argument("--parent", required=True, type=Path)
    p.add_argument("--version", default="v003")
    p.add_argument("--python", default="/data1/home/sunyiq/miniconda3/envs/nh_final/bin/python")
    a = p.parse_args()
    print(json.dumps(advance(a.root.resolve(), a.parent.resolve(), a.version, a.python)))


if __name__ == "__main__":
    main()
