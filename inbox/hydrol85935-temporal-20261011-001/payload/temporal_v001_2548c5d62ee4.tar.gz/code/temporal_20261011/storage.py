"""Append-only pair records with independent reconstruction and fail-closed reuse."""
from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np

from src.adversarial.scripts.revision_20261008.contracts import digest_json, sha256
from src.adversarial.scripts.revision_20261008.data import array_digest
from src.adversarial.scripts.revision_20261008.engine import physical_metrics, metric_changes
from .core import ARMS

IDENTITY = "hydrol85935_temporal_persistence_20261011_001"


def output_root(path, protected=()):
    raw = Path(path).absolute()
    if raw.name != IDENTITY:
        raise ValueError("Wrong additional-experiment output identity")
    for p in (raw, *raw.parents):
        if p.exists() and p.resolve() != p.absolute():
            raise ValueError("Symlink or junction output is forbidden")
    for p in map(lambda x: Path(x).resolve(), protected):
        if raw.resolve().is_relative_to(p) or p.is_relative_to(raw.resolve()):
            raise ValueError("Additional output overlaps protected parent/input")
    return raw.resolve()


def immutable_json(path, value):
    path = Path(path)
    if path.exists():
        if json.loads(path.read_text(encoding="utf-8")) != value:
            raise ValueError("Refusing to replace existing record: " + str(path))
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def validate_pair(arrays, details):
    a, d = arrays, details
    calendar = a["calendar_dates"].astype("datetime64[D]")
    dates = a["prediction_dates"].astype("datetime64[D]")
    if (np.isnat(calendar).any() or not np.all(np.diff(calendar) == np.timedelta64(1, "D"))
            or not np.array_equal(calendar[d["window_length"] - 1:], dates)):
        raise ValueError("Stored date alignment failed")
    n, length = len(dates), len(calendar)
    mask = a["scoring_mask"]
    if mask.dtype != bool or mask.shape != (n,) or mask.sum() < 2:
        raise ValueError("Invalid fixed scoring mask")
    for name in ("q_clean", "q_observed", "q_daily", "q_block7"):
        if a[name].shape != (n,) or not np.isfinite(a[name][mask] if name == "q_observed" else a[name]).all():
            raise ValueError("Stored predictions are incomplete or nonfinite")
    high = mask & (a["q_observed"] > np.quantile(a["q_observed"][mask], .9))
    if not np.array_equal(high, a["high_flow_mask"]):
        raise ValueError("Changed high-flow selection")
    mapping = d["mapping"]
    scale, center = np.array(mapping["signal_scale_physical"]), np.array(mapping["signal_center_physical"])
    budget = np.array(mapping["signal_budget_normalized"])
    lower = np.maximum(-budget, (np.array([0, -50, 0, 0]) - center) / scale - a["clean_calendar"])
    upper = np.minimum(budget, (np.array([500, 50, 1361, 10000]) - center) / scale - a["clean_calendar"])
    idx, starts = np.arange(length) // 7, np.arange(0, length, 7)
    if a["clean_calendar"].shape != (length, 4) or not np.isfinite(a["clean_calendar"]).all():
        raise ValueError("Invalid stored clean input")
    expected_lo = np.stack([lower[s:s + 7].max(0) for s in starts])
    expected_hi = np.stack([upper[s:s + 7].min(0) for s in starts])
    for name, expected in (("block_lower", expected_lo), ("block_upper", expected_hi)):
        if a[name].shape != expected.shape or not np.allclose(a[name], expected, atol=1e-6, rtol=0):
            raise ValueError("Stored feasible block interval disagrees")
    if (expected_lo > expected_hi + 1e-6).any():
        raise ValueError("Infeasible stored blocks")
    if array_digest(a["initial_delta"]) != d["initial_sha256"]:
        raise ValueError("Initial perturbation identity changed")
    for name in ("initial_delta", "delta_daily", "delta_block7"):
        delta = a[name]
        if delta.shape != (length, 4) or not np.isfinite(delta).all():
            raise ValueError("Invalid stored perturbation shape")
        if ((delta < lower - 1e-6) | (delta > upper + 1e-6)).any():
            raise ValueError("Stored physical/amplitude violation")
        if name != "delta_daily" and not np.array_equal(delta, delta[starts][idx]):
            raise ValueError("Stored seven-day persistence violation")
    if d["steps"] != 50 or d["block_days"] != 7 or d["moment_adjustment"] or not d["physical_range"]:
        raise ValueError("Stored experimental protocol changed")
    clean_metrics = physical_metrics(a["q_observed"], a["q_clean"], mask, high)
    if clean_metrics != d["clean_metrics"]:
        raise ValueError("Clean metrics do not reconstruct")
    for arm in ARMS:
        info = d["arms"][arm]
        trace = info["trajectory"]
        if len(trace) != 51 or [t["iteration"] for t in trace] != list(range(51)):
            raise ValueError("Incomplete search trajectory")
        scores = np.array([t["current_nse"] for t in trace])
        if not np.isfinite(scores).all() or not np.array_equal(np.minimum.accumulate(scores), [t["best_nse"] for t in trace]):
            raise ValueError("Invalid best-so-far trajectory")
        if info["selected_iteration"] != int(np.argmin(scores)) or info["selected_nse"] != float(scores.min()):
            raise ValueError("Selection differs from complete retained trajectory")
        rebuilt = metric_changes(clean_metrics, physical_metrics(a["q_observed"], a["q_" + arm], mask, high))
        if rebuilt != info["metrics"]:
            raise ValueError("Metrics do not reconstruct from the retained predictions")
    if d["arms"]["daily"]["trajectory"][0]["current_nse"] != d["arms"]["block7"]["trajectory"][0]["current_nse"]:
        raise ValueError("Paired initial score changed")


def save_pair(directory, identity, arrays, details):
    directory = Path(directory)
    validate_pair(arrays, details)
    directory.mkdir(parents=True, exist_ok=False)
    for a in arrays.values():
        if np.asarray(a).dtype.hasobject:
            raise ValueError("Object arrays are forbidden")
    np.savez_compressed(directory / "arrays.npz", **arrays)
    metadata = dict(identity=identity, details=details)
    immutable_json(directory / "metadata.json", metadata)
    immutable_json(directory / "complete.json", dict(status="complete", identity_sha256=digest_json(identity),
                   arrays_sha256=sha256(directory / "arrays.npz"), metadata_sha256=sha256(directory / "metadata.json")))


def load_pair(directory, identity=None):
    directory = Path(directory)
    if not directory.exists():
        return None
    marker = json.loads((directory / "complete.json").read_text(encoding="utf-8"))
    if (marker["status"] != "complete" or marker["arrays_sha256"] != sha256(directory / "arrays.npz")
            or marker["metadata_sha256"] != sha256(directory / "metadata.json")):
        raise ValueError("Pair record checksum mismatch")
    metadata = json.loads((directory / "metadata.json").read_text(encoding="utf-8"))
    if marker["identity_sha256"] != digest_json(metadata["identity"]) or (identity is not None and identity != metadata["identity"]):
        raise ValueError("Pair provenance mismatch")
    with np.load(directory / "arrays.npz", allow_pickle=False) as archive:
        arrays = {k: archive[k] for k in archive.files}
    validate_pair(arrays, metadata["details"])
    return arrays, metadata
