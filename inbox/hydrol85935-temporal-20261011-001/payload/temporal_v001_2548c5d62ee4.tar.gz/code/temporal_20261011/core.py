"""Paired daily and block-constant searches with identical feasible initial inputs."""
from __future__ import annotations

import numpy as np
import torch

from src.adversarial.scripts.revision_20261008.contracts import SCIENCE, stable_seed
from src.adversarial.scripts.revision_20261008.data import array_digest
from src.adversarial.scripts.revision_20261008.engine import denormalize, physical_metrics, metric_changes

ARMS = ("daily", "block7")


class BlockBounds:
    def __init__(self, engine, block_days=7):
        if block_days != 7:
            raise ValueError("Only the preregistered seven-day blocks are supported")
        self.length = len(engine.clean)
        if self.length < 1 or not torch.isfinite(engine.clean).all():
            raise ValueError("Invalid clean calendar")
        self.starts = list(range(0, self.length, block_days))
        self.lengths = [min(block_days, self.length - s) for s in self.starts]
        self.index = torch.arange(self.length, device=engine.clean.device) // block_days
        m = engine.map
        self.daily_lower = torch.maximum(-m.budget, (m.minimum - m.center) / m.scale - engine.clean)
        self.daily_upper = torch.minimum(m.budget, (m.maximum - m.center) / m.scale - engine.clean)
        self.lower = torch.stack([self.daily_lower[s:s + n].amax(0) for s, n in zip(self.starts, self.lengths)])
        self.upper = torch.stack([self.daily_upper[s:s + n].amin(0) for s, n in zip(self.starts, self.lengths)])
        if (self.lower > self.upper).any():
            raise ValueError("Seven-day physical/amplitude intersection is empty")

    def expand(self, blocks):
        if blocks.shape != self.lower.shape:
            raise ValueError("Block parameter shape mismatch")
        return blocks[self.index]

    def project(self, blocks):
        if blocks.shape != self.lower.shape or not torch.isfinite(blocks).all():
            raise ValueError("Invalid block parameters")
        return torch.maximum(torch.minimum(blocks, self.upper), self.lower).detach()

    def gradient_sum(self, daily_gradient):
        if daily_gradient.shape != self.daily_lower.shape or not torch.isfinite(daily_gradient).all():
            raise ValueError("Invalid daily gradient")
        result = torch.zeros_like(self.lower)
        return result.index_add_(0, self.index, daily_gradient)

    def initial(self, seed):
        generator = torch.Generator(device="cpu").manual_seed(seed)
        u = torch.rand(self.lower.shape, generator=generator, dtype=self.lower.dtype).to(self.lower.device)
        return self.project(self.lower + u * (self.upper - self.lower))

    def audit(self, delta, require_blocks):
        if delta.shape != self.daily_lower.shape or not torch.isfinite(delta).all():
            raise ValueError("Invalid final perturbation")
        tol = SCIENCE["amplitude_tolerance"]
        if ((delta < self.daily_lower - tol) | (delta > self.daily_upper + tol)).any():
            raise ValueError("Final physical/amplitude violation")
        residual = (delta - self.expand(delta[self.starts])).abs().amax().item()
        if require_blocks and residual > tol:
            raise ValueError("Seven-day persistence violation")
        return dict(block_max_abs_residual_normalized=residual,
                    zero_width_blocks_per_signal=(self.upper == self.lower).sum(0).cpu().tolist(),
                    one_sided_blocks_per_signal=((self.lower >= 0) | (self.upper <= 0)).sum(0).cpu().tolist(),
                    minimum_block_width_normalized=(self.upper - self.lower).amin(0).cpu().tolist())


def search(engine, bounds, initial, arm, steps=50):
    if arm not in ARMS or steps != 50:
        raise ValueError("Unregistered search arm or update count")
    d = initial.detach().clone()
    bounds.audit(d, True)
    alpha = 2 * engine.map.budget
    best_delta, best_score, best_iteration = None, float("inf"), None
    trajectory = []
    for iteration in range(steps + 1):
        bounds.audit(d, arm == "block7")
        current = engine.score(engine.predict(d))
        if current < best_score:
            best_score, best_delta, best_iteration = current, d.clone(), iteration
        trajectory.append(dict(iteration=iteration, current_nse=current, best_nse=best_score,
                               best_iteration=best_iteration, step_size_normalized=alpha.cpu().tolist()))
        if iteration == steps:
            break
        gradient = engine.gradient(d)
        if arm == "block7":
            blocks = bounds.project(d[bounds.starts] + alpha * bounds.gradient_sum(gradient).sign())
            d = bounds.expand(blocks)
        else:
            d = engine.project(d + alpha * gradient.sign(), "physical_range")
        if iteration + 1 in SCIENCE["halve_after_updates"]:
            alpha = alpha * .5
    prediction = engine.predict(best_delta)
    if abs(engine.score(prediction) - best_score) > 1e-6:
        raise ValueError("Retained input does not reproduce selected loss")
    audit = bounds.audit(best_delta, arm == "block7")
    audit.update(engine.check(best_delta, "physical_range"))
    if audit["amplitude_violations"] or audit["physical_violations"] or not audit["finite"]:
        raise ValueError("Retained input fails parent hard constraints")
    return best_delta, prediction, dict(trajectory=trajectory, selected_iteration=best_iteration,
                                       selected_nse=best_score, audit=audit)


def run_pair(engine, basin_id, physical_observations=None):
    bounds = BlockBounds(engine)
    seed = stable_seed(basin_id, "temporal_persistence_common_start", .1, -1)
    initial = bounds.expand(bounds.initial(seed))
    clean = denormalize(engine.clean_pred, engine.q_center, engine.q_scale)
    own_obs = denormalize(engine.y, engine.q_center, engine.q_scale)
    obs = own_obs if physical_observations is None else np.asarray(physical_observations, dtype=np.float64)
    if obs.shape != own_obs.shape or not np.allclose(obs, own_obs, atol=1e-5, rtol=1e-5, equal_nan=True):
        raise ValueError("Shared physical observations disagree")
    mask = engine.mask.cpu().numpy()
    high = mask & (obs > np.quantile(obs[mask], .9))
    original_metrics = physical_metrics(obs, clean, mask, high)
    arrays = dict(initial_delta=initial.cpu().numpy(), clean_calendar=engine.clean.cpu().numpy(),
                  block_lower=bounds.lower.cpu().numpy(), block_upper=bounds.upper.cpu().numpy(),
                  q_clean=clean, q_observed=obs, scoring_mask=mask, high_flow_mask=high,
                  calendar_dates=engine.data.calendar_dates.astype(str),
                  prediction_dates=engine.data.prediction_dates.astype(str))
    details = dict(seed=seed, initial_sha256=array_digest(initial), mapping=engine.map.metadata(),
                   snow_fraction=engine.data.snow_fraction, window_length=engine.data.window_length,
                   block_days=7, steps=50, physical_range=True, moment_adjustment=False,
                   clean_nse_search=engine.clean_nse, clean_metrics=original_metrics, arms={})
    for arm in ARMS:
        delta, prediction, info = search(engine, bounds, initial, arm)
        q = denormalize(prediction, engine.q_center, engine.q_scale)
        arrays["delta_" + arm], arrays["q_" + arm] = delta.cpu().numpy(), q
        info["metrics"] = metric_changes(original_metrics, physical_metrics(obs, q, mask, high))
        details["arms"][arm] = info
    if details["arms"]["daily"]["trajectory"][0]["current_nse"] != details["arms"]["block7"]["trajectory"][0]["current_nse"]:
        raise ValueError("Paired searches do not share the same initial score")
    return arrays, details
