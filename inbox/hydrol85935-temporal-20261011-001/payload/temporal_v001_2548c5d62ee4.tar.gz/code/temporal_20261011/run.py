"""Additional experiment CLI. The parent workspace is read-only in every mode."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import time

import numpy as np
import torch

from src.adversarial.scripts.revision_20261008.assets import frozen_manifest, verify_training_assets
from src.adversarial.scripts.revision_20261008.contracts import Workspace, SCIENCE, SEEDS, digest_json, sha256
from src.adversarial.scripts.revision_20261008.data import load_model, load_basin, scaler_fields, reference_std
from src.adversarial.scripts.revision_20261008.engine import BasinEngine, SignalMap, denormalize, UndefinedTarget
from src.adversarial.scripts.revision_20261008.run import runtime
from .core import ARMS, run_pair
from .storage import IDENTITY, immutable_json, output_root, save_pair, load_pair

PROTOCOL = dict(identity=IDENTITY, seeds=[100, 200, 300], arms=list(ARMS), basins=531, epsilon=.1,
                steps=50, block_days=7, condition="physical_range", moment_adjustment=False,
                initialization="shared_uniform_feasible_block_offsets", include_clean_candidate=False,
                halve_after_updates=[12, 26, 38], initial_step_budget_multiple=2,
                preflight_basins=["01022500", "01031500", "01047000", "01052500"],
                pilot_basin="01022500", pilot_seeds=[100, 200, 300],
                verification_nse_tolerance=1e-5, chunk=256)


def parent_ready(parent):
    missing = [s for s in SEEDS if not parent.output(f"training/s{s}/complete.json").is_file()
               or not parent.output(f"frozen/training_assets/s{s}.json").is_file()]
    if missing:
        return dict(status="WAITING_FOR_TRAINING", missing_seeds=missing)
    # Completion markers alone are not acceptance: verify configs, weights and scaler identities.
    models = {str(s): verify_training_assets(parent, s)[1] for s in SEEDS}
    return dict(status="TRAINING_ASSETS_VERIFIED", models=models)


def verify_parent(parent, protocol):
    if protocol != PROTOCOL:
        raise ValueError("Additional protocol differs from the reviewed fixed configuration")
    ready = parent_ready(parent)
    if ready["status"] != "TRAINING_ASSETS_VERIFIED":
        raise RuntimeError(json.dumps(ready))
    frozen, fingerprint = frozen_manifest(parent)
    actual = parent.manifest()
    if {k: v for k, v in frozen.items() if k != "runtime"} != actual or frozen["science"] != SCIENCE:
        raise ValueError("Parent source/config/data manifest no longer matches the trained models")
    current_runtime = {k: v for k, v in runtime().items() if k != "cuda_visible_devices"}
    if frozen["runtime"] != current_runtime:
        raise ValueError("Compute runtime differs from the verified parent training runtime")
    return dict(parent_manifest_sha256=fingerprint, parent_root=str(parent.root),
                models=ready["models"], runtime=current_runtime)


def freeze(parent, root, protocol, config_dir):
    evidence = verify_parent(parent, protocol)
    configs = {}
    for seed in SEEDS:
        for arm in ARMS:
            path = config_dir / f"s{seed}_{arm}.json"
            value = json.loads(path.read_text(encoding="utf-8"))
            expected = dict(exp_id=f"{IDENTITY}_s{seed}_{arm}", model_id=f"single_temperature_s{seed}",
                            seed=seed, arm=arm, protocol=protocol)
            if value != expected:
                raise ValueError("Registered seed/arm configuration changed")
            configs[path.name] = sha256(path)
    manifest = dict(protocol=protocol, parent=evidence,
                    configuration_sha256=configs,
                    source_sha256={p.name: sha256(p) for p in sorted(Path(__file__).parent.glob("*.py"))})
    immutable_json(root / "frozen/manifest.json", manifest)
    return manifest, digest_json(manifest)


def make_engine(parent, wrapper, basin, reference, device):
    data = load_basin(parent, wrapper, basin, device)
    center, scale, qc, qs = scaler_fields(wrapper)
    return BasinEngine(wrapper, data, SignalMap(wrapper.dynamic_features, center, scale, reference, .1, device),
                       qc, qs, 256)


def native_prediction_check(engine, require_nonzero=False):
    """Independently build the native NH feature-dictionary interface on all dated windows."""
    values, wrapper, data = [], engine.wrapper, engine.data
    with torch.no_grad():
        for start in range(0, len(data.observations), 256):
            stop = min(start + 256, len(data.observations))
            windows = data.calendar[start:stop + data.window_length - 1].unfold(0, data.window_length, 1).permute(0, 2, 1)
            native = {"x_d": {f: windows[:, :, i:i + 1] for i, f in enumerate(wrapper.dynamic_features)}}
            if data.static.numel():
                native["x_s"] = data.static.unsqueeze(0).expand(stop - start, -1)
            values.append(wrapper.model(native)["y_hat"][:, -1, 0])
    prediction = torch.cat(values)
    if not torch.isfinite(prediction).all():
        raise ValueError("Nonfinite canonical-interface prediction")
    difference = abs(engine.score(prediction) - engine.clean_nse)
    if difference > 1e-5:
        raise ValueError("New-model clean prediction verification failed")
    gradient = engine.gradient(engine.zero)
    if not torch.isfinite(gradient).all() or (require_nonzero and not bool(gradient.abs().max() > 0)):
        raise ValueError("Nonfinite or disconnected new-model input gradient")
    return dict(status="PASS", nse_difference=difference, tolerance=1e-5,
                max_prediction_difference_normalized=float((prediction - engine.clean_pred).abs().max()),
                gradient_max_abs=float(gradient.abs().max()), prediction_count=len(prediction))


def preflight(parent, root, fingerprint, device):
    path = root / "control/new_models_verified.json"
    if path.exists():
        old = json.loads(path.read_text())
        require_preflight(root, fingerprint)
        return old
    reference, checks = reference_std(parent), []
    basins, _ = parent.basins()
    if not set(PROTOCOL["preflight_basins"]).issubset(basins):
        raise ValueError("Predeclared verification basins missing")
    for seed in SEEDS:
        wrapper, _ = load_model(parent, f"single_temperature_s{seed}", device)
        for basin in PROTOCOL["preflight_basins"]:
            engine = make_engine(parent, wrapper, basin, reference, device)
            checks.append(dict(seed=seed, basin_id=basin, **native_prediction_check(engine, require_nonzero=True)))
    value = dict(status="PASS", manifest_sha256=fingerprint, checks=checks,
                 scheduler_job_id=os.environ.get("SLURM_JOB_ID"),
                 scope="native-interface clean prediction and input-gradient checks; not scientific success")
    immutable_json(path, value)
    return value


def require_preflight(root, fingerprint):
    value = json.loads((root / "control/new_models_verified.json").read_text())
    expected = {(s, b) for s in SEEDS for b in PROTOCOL["preflight_basins"]}
    checks = value["checks"]
    if (value["status"] != "PASS" or value["manifest_sha256"] != fingerprint or len(checks) != 12
            or {(c["seed"], c["basin_id"]) for c in checks} != expected
            or any(c["status"] != "PASS" or not np.isfinite(c["nse_difference"]) or c["nse_difference"] > 1e-5
                   or c["tolerance"] != 1e-5 or c["prediction_count"] != 3652
                   or not np.isfinite(c["gradient_max_abs"]) or c["gradient_max_abs"] <= 0 for c in checks)):
        raise ValueError("All three new models must pass the twelve fixed prediction checks")
    return value


def run_records(parent, root, fingerprint, seed, selected, device, pilot=False):
    require_preflight(root, fingerprint)
    model = f"single_temperature_s{seed}"
    wrapper, model_identity = load_model(parent, model, device)
    original, _ = load_model(parent, "original_s100", "cpu")
    reference = reference_std(parent)
    reports = []
    for basin in selected:
        identity = dict(manifest_sha256=fingerprint, seed=seed, basin_id=basin, model=model_identity)
        directory = root / ("pilot" if pilot else "records") / model / basin
        failure_path = root / "failures" / ("pilot" if pilot else "records") / model / (basin + ".json")
        if failure_path.exists():
            prior_failure = json.loads(failure_path.read_text())
            if prior_failure["identity"] == identity and prior_failure["status"] == "uncomputable" and not pilot:
                reports.append(dict(seed=seed, basin_id=basin, status="uncomputable", reason=prior_failure["reason"]))
                continue
            raise RuntimeError("Prior failure is preserved; use a reviewed new attempt rather than overwrite")
        prior = load_pair(directory, identity)
        if prior is not None:
            reports.append(dict(seed=seed, basin_id=basin, status="reused", pair_directory=str(directory)))
            continue
        started = time.perf_counter()
        try:
            engine = make_engine(parent, wrapper, basin, reference, device)
            # Canonical prediction verification is repeated before every scientific pair, not only the pilot.
            check = native_prediction_check(engine)
            original_data = load_basin(parent, original, basin, "cpu")
            _, _, qc, qs = scaler_fields(original)
            if (not np.array_equal(original_data.prediction_dates, engine.data.prediction_dates)
                    or not np.array_equal(original_data.calendar_dates, engine.data.calendar_dates)
                    or not torch.equal(original_data.scoring_mask.cpu(), engine.mask.cpu())):
                raise ValueError("Original/new-model observation dates or masks differ")
            obs = denormalize(original_data.observations, qc, qs)
            arrays, details = run_pair(engine, basin, obs)
            details.update(prediction_check=check, input_identity=engine.data.input_identity,
                           wall_seconds=time.perf_counter() - started,
                           peak_cuda_bytes=torch.cuda.max_memory_allocated() if device.startswith("cuda") else None)
            save_pair(directory, identity, arrays, details)
            load_pair(directory, identity)
            reports.append(dict(seed=seed, basin_id=basin, status="complete", pair_directory=str(directory),
                                wall_seconds=details["wall_seconds"]))
        except Exception as error:
            immutable_json(failure_path, dict(identity=identity,
                           status="uncomputable" if isinstance(error, UndefinedTarget) else "failed",
                           reason=f"{type(error).__name__}: {error}", wall_seconds=time.perf_counter() - started))
            if isinstance(error, UndefinedTarget) and not pilot:
                reports.append(dict(seed=seed, basin_id=basin, status="uncomputable", reason=str(error)))
                continue
            raise
    return reports


def pilot(parent, root, fingerprint, device):
    rows = []
    for seed in SEEDS:
        rows += run_records(parent, root, fingerprint, seed, [PROTOCOL["pilot_basin"]], device, True)
    timings = []
    hashes = []
    for seed in SEEDS:
        p = root / f"pilot/single_temperature_s{seed}/{PROTOCOL['pilot_basin']}"
        _, metadata = load_pair(p)
        timings.append(metadata["details"]["wall_seconds"])
        hashes.append(sha256(p / "complete.json"))
    worst = max(timings)
    chunk = next((n for n in (10, 5, 1) if 2 * worst * n + 600 <= 21600), None)
    if chunk is None:
        raise RuntimeError("One paired record exceeds six-hour budget with twofold allowance")
    value = dict(status="PASS", manifest_sha256=fingerprint, pair_seconds=timings, allowance_factor=2,
                 basin_chunk=chunk, wall_limit_seconds=21600, record_complete_sha256=hashes,
                 scheduler_job_id=os.environ.get("SLURM_JOB_ID"))
    immutable_json(root / "control/resource_pilot.json", value)
    return value


def report(parent, root, fingerprint):
    basins, _ = parent.basins()
    rows, issues, observed, uncomputable = [], [], {}, []
    for seed in SEEDS:
        for basin in basins:
            p = root / f"records/single_temperature_s{seed}/{basin}"
            try:
                value = load_pair(p)
                if value is None:
                    failure = root / f"failures/records/single_temperature_s{seed}/{basin}.json"
                    if failure.exists():
                        failure_value = json.loads(failure.read_text())
                        fi = failure_value["identity"]
                        if fi["manifest_sha256"] != fingerprint or fi["seed"] != seed or fi["basin_id"] != basin:
                            raise ValueError("Failure record identity mismatch")
                        if failure_value["status"] == "uncomputable":
                            uncomputable.append(dict(seed=seed, basin_id=basin, reason=failure_value["reason"]))
                            continue
                    issues.append(dict(seed=seed, basin_id=basin, status="failed" if failure.exists() else "missing"))
                    continue
                a, metadata = value
                ident = metadata["identity"]
                if ident["manifest_sha256"] != fingerprint or ident["seed"] != seed or ident["basin_id"] != basin:
                    raise ValueError("Pair is registered under a different seed/basin/manifest")
                if basin in observed and not np.array_equal(observed[basin], a["q_observed"], equal_nan=True):
                    raise ValueError("Shared observations differ across models")
                observed[basin] = a["q_observed"]
                details = metadata["details"]
                row = dict(seed=seed, basin_id=basin, snow_fraction=details["snow_fraction"], metrics={})
                for arm in ARMS:
                    row["metrics"][arm] = details["arms"][arm]["metrics"]
                rows.append(row)
            except Exception as error:
                issues.append(dict(seed=seed, basin_id=basin, status="invalid", reason=str(error)))
    summary = []
    for seed in SEEDS:
        for group in ("all", "snow", "low_snow"):
            subset = [r for r in rows if r["seed"] == seed and (group == "all" or (r["snow_fraction"] > .2) == (group == "snow"))]
            entry = dict(seed=seed, group=group, complete_pairs=len(subset), metrics={})
            for metric in ("nse", "kge", "rmse", "high_flow_rmse"):
                paired = [r for r in subset if all(r["metrics"][a][metric]["change"] is not None for a in ARMS)]
                daily = np.array([r["metrics"]["daily"][metric]["change"] for r in paired])
                block = np.array([r["metrics"]["block7"][metric]["change"] for r in paired])
                entry["metrics"][metric] = dict(evaluable_pairs=len(paired),
                    median_daily_loss=float(np.median(daily)) if len(paired) else None,
                    median_block7_loss=float(np.median(block)) if len(paired) else None,
                    median_paired_daily_minus_block7=float(np.median(daily - block)) if len(paired) else None,
                    paired_difference_quantiles=np.quantile(daily - block, [0, .25, .5, .75, 1]).tolist() if len(paired) else [],
                    block7_loss_exceeds_daily_count=int((block > daily).sum()))
            summary.append(entry)
    complete = len(rows) + len(uncomputable) == 1593 and not issues
    value = dict(status=("COMPLETE_WITH_UNCOMPUTABLE" if uncomputable else "COMPLETE") if complete else "INCOMPLETE", manifest_sha256=fingerprint,
                 expected_pairs=1593, complete_pairs=len(rows), expected_search_records=3186,
                 complete_search_records=2 * len(rows), uncomputable_search_records=2 * len(uncomputable),
                 uncomputable=uncomputable, issues=issues, summary=summary,
                 scientific_conclusion="Not inferred from technical completion; assess observed effects and exceptions")
    immutable_json(root / "reports/coverage_and_summary.json", value)
    immutable_json(root / "reports/basin_pairs.json", rows)
    return value


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("parent-root", "parent-code", "data-dir", "original-models-root", "data-manifest", "root", "protocol"):
        p.add_argument("--" + name, type=Path, required=True)
    p.add_argument("--mode", choices=("ready", "preflight", "pilot", "run", "report"), required=True)
    p.add_argument("--device", default="cuda:0")
    p.add_argument("--seed", type=int, choices=SEEDS)
    p.add_argument("--basin-start", type=int, default=0)
    p.add_argument("--basin-count", type=int, default=1)
    a = p.parse_args()
    parent = Workspace(a.parent_root, a.data_dir, a.parent_code, a.original_models_root, a.data_manifest)
    root = output_root(a.root, [parent.root, parent.data_dir, parent.original_models_root,
                               parent.repo / "src", parent.repo / "draft"])
    if a.mode == "ready":
        print(json.dumps(parent_ready(parent)))
        return
    protocol = json.loads(a.protocol.read_text(encoding="utf-8"))
    config_dir = a.protocol.parent / "configs" if (a.protocol.parent / "configs").is_dir() else a.protocol.parent
    _, fingerprint = freeze(parent, root, protocol, config_dir)
    if a.mode == "preflight":
        result = preflight(parent, root, fingerprint, a.device)
    elif a.mode == "pilot":
        result = pilot(parent, root, fingerprint, a.device)
    elif a.mode == "report":
        result = report(parent, root, fingerprint)
    else:
        if a.seed is None or a.basin_start < 0 or a.basin_count < 1 or a.basin_start + a.basin_count > 531:
            raise ValueError("Invalid registered basin slice")
        basins, _ = parent.basins()
        result = run_records(parent, root, fingerprint, a.seed, basins[a.basin_start:a.basin_start + a.basin_count], a.device)
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    if a.mode == "report" and result["status"] not in ("COMPLETE", "COMPLETE_WITH_UNCOMPUTABLE"):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
