"""Isolated seven-day persistence supplement; never writes parent experiment assets."""
