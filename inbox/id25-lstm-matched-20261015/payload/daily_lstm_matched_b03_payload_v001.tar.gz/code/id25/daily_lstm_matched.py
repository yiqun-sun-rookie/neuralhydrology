"""One shared daily LSTM using exactly RDS01's four dynamic and seven static inputs."""
import numpy as np
import torch
from torch import nn

DYNAMIC_NAMES = ['P_mm_day', 'mean_Tmax_Tmin_degC', 'downward_shortwave_W_m2', 'vapor_pressure_Pa']


def dynamic_inputs(forcing):
    """SWE is intentionally excluded; day extrema are used only through their mean."""
    values = np.asarray(forcing, dtype=np.float32)
    return np.stack([values[..., 0], .5 * (values[..., 3] + values[..., 4]),
                     values[..., 1], values[..., 5]], axis=-1)


def normalized_inputs(dynamic, statics, mean, scale, device):
    dynamic = torch.as_tensor(dynamic, dtype=torch.float32, device=device)
    static = torch.as_tensor(statics, dtype=torch.float32, device=device)
    dynamic = (dynamic - torch.as_tensor(mean, dtype=torch.float32, device=device)) / torch.as_tensor(
        scale, dtype=torch.float32, device=device)
    return torch.cat([dynamic, static.unsqueeze(0).expand(dynamic.shape[0], -1, -1)], dim=-1)


class DailyLSTMMatched(nn.Module):
    def __init__(self, input_size=11, hidden_size=32, dense_size=16):
        super().__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers=1, dropout=0., bidirectional=False)
        self.dense = nn.Linear(hidden_size, dense_size)
        self.output = nn.Linear(dense_size, 1)

    def forward(self, inputs, state=None):
        sequence, final = self.lstm(inputs, state)
        daily_cm = self.output(torch.tanh(self.dense(sequence))).squeeze(-1)
        return daily_cm, final
