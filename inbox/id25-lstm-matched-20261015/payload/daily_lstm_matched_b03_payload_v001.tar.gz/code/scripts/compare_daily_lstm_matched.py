"""Compare a frozen B03 model with saved RDS01 and the existing external B02 reference."""
import csv
import json
from pathlib import Path

import numpy as np


def number(value):
    return float(value) if np.isfinite(value) else None


def metrics(p, y, valid):
    e = np.where(valid, p-y, np.nan)
    rmse = np.sqrt(np.nanmean(e**2, axis=0))
    return dict(pooled_rmse_cm=number(np.sqrt(np.nanmean(e**2))),
                regional_median_rmse_cm=number(np.nanmedian(rmse)),
                residual_count=int(valid.sum()), valid_regions=int(np.isfinite(rmse).sum()))


def compare(root, output):
    root, output = Path(root), Path(output)
    if json.loads((output/'selection.json').read_text())['state'] != 'FROZEN':
        raise ValueError('Freeze selection before reading application reference targets')
    with np.load(output/'predictions.npz', allow_pickle=False) as z:
        candidate=z['application_anomaly_cm']; ids=z['support_ids'].astype(str); sids=z['solution_ids'].astype(str)
    with np.load(root/'comparison_reference/reference.npz', allow_pickle=False) as z:
        if not np.array_equal(z['support_ids'].astype(str),ids) or not np.array_equal(z['solution_ids'].astype(str),sids):
            raise ValueError('Stored RDS01 reference identity mismatch')
        baseline=z['rds_application_anomaly_cm']; observed=z['observed_application_anomaly_cm']
    with np.load(root/'comparison_reference/b02_predictions.npz',allow_pickle=False) as z:
        if not np.array_equal(z['support_ids'].astype(str),ids) or not np.array_equal(z['solution_ids'].astype(str),sids):
            raise ValueError('Stored B02 reference identity mismatch')
        b02=z['application_anomaly_cm']
    valid=np.isfinite(candidate)&np.isfinite(baseline)&np.isfinite(observed)
    if int(valid.sum())!=24*119:
        raise ValueError('Expected all 2856 fixed primary residuals')
    models={'rds01':baseline,'b03_daily_lstm':candidate,'b02_monthly_external_swe':b02}
    summaries={name:metrics(p,observed,valid&np.isfinite(p)) for name,p in models.items()}
    years=np.array([sid[-7:-3] for sid in sids[-24:]])
    rows=[]
    for col,rid in enumerate(ids):
        row={'region_id':rid,'common_windows':int(valid[:,col].sum())}
        for name,p in models.items():
            mask=valid[:,col]&np.isfinite(p[:,col]);e=p[mask,col]-observed[mask,col]
            row[name+'_rmse_cm']=number(np.sqrt(np.mean(e**2)))
            for year in ['2009','2010']:
                m=mask&(years==year);pp=p[m,col];yy=observed[m,col]
                ratio=np.std(pp)/np.std(yy) if len(yy)>1 and np.std(yy)>1e-8 else np.nan
                row[year+'_'+name+'_bias_cm']=number(np.mean(pp-yy))
                row[year+'_'+name+'_sd_ratio']=number(ratio)
        rows.append(row)
    rds_wins=sum(r['rds01_rmse_cm']<r['b03_daily_lstm_rmse_cm'] for r in rows)
    b03_wins=sum(r['b03_daily_lstm_rmse_cm']<r['rds01_rmse_cm'] for r in rows)
    cold=['lat+038_lon-108','lat+040_lon-108']
    summary=dict(period='2009-2010',matched_information_comparison=['RDS01_best_epoch078','B03_DAILY_LSTM_MATCHED_INFO'],
                 metrics=summaries,rds01_lower_rmse_regions=rds_wins,b03_lower_rmse_regions=b03_wins,
                 ties=119-rds_wins-b03_wins,cold_regions=[r for r in rows if r['region_id'] in cold],
                 interpretation='Fixed-setting developmental storage comparison; B02 is an external monthly/SWE reference only')
    dest=output/'comparison';dest.mkdir(exist_ok=True)
    with (dest/'regional_comparison.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (dest/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(5.5,4.8),constrained_layout=True)
    xx=[r['rds01_rmse_cm'] for r in rows];yy=[r['b03_daily_lstm_rmse_cm'] for r in rows]
    lim=max(xx+yy)*1.05
    ax.scatter(xx,yy,s=20,color='#168080',alpha=.8);ax.plot([0,lim],[0,lim],'--',color='.5')
    ax.set(xlabel='Fixed RDS01 RMSE (cm)',ylabel='Matched-information daily LSTM RMSE (cm)',
           xlim=(0,lim),ylim=(0,lim),title='119 regions | 2009-2010');ax.grid(alpha=.2)
    fig.savefig(dest/'regional_rmse.png',dpi=160);plt.close(fig)
    dates=np.array([s[-7:] for s in sids[-24:]],dtype='datetime64[M]')
    fig,axes=plt.subplots(2,1,figsize=(10,6),sharex=True,constrained_layout=True)
    for ax,rid in zip(axes,cold):
        col=ids.tolist().index(rid)
        ax.plot(dates,observed[:,col],'ko-',ms=3,label='Existing storage proxy')
        ax.plot(dates,baseline[:,col],color='#c1542d',label='Fixed RDS01')
        ax.plot(dates,candidate[:,col],color='#168080',label='B03 same-information daily LSTM')
        ax.plot(dates,b02[:,col],'--',color='#79859b',label='B02 external SWE/monthly reference')
        ax.set(title=rid,ylabel='Storage anomaly (cm)');ax.grid(alpha=.2)
    axes[0].legend(fontsize=8,ncol=2)
    fig.savefig(dest/'cold_regions.png',dpi=160);plt.close(fig)
    return summary
