"""Single shared daily LSTM fit, full historical BPTT, fixed split and budget."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import random
import sys
import time
import traceback

import numpy as np
import torch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from id25.daily_lstm_matched import DYNAMIC_NAMES, DailyLSTMMatched, dynamic_inputs, normalized_inputs
from id25.regional_storage_observation import center_on_fit_windows
from compare_daily_lstm_matched import compare


def now():return datetime.now(timezone.utc).isoformat()


def write_json(path,value):
    pending=path.with_suffix('.pending');pending.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8');pending.replace(path)


def save_checkpoint(path,value):
    pending=path.with_suffix('.pending');torch.save(value,pending);pending.replace(path)


def load_npz(path):
    with np.load(path,allow_pickle=False) as z:return {k:z[k] for k in z.files}


def network(config,device):
    m=config['model']
    return DailyLSTMMatched(m['input_size'],m['hidden_size'],m['dense_size']).to(device)


def run(root):
    if not os.environ.get('SLURM_JOB_ID'):raise RuntimeError('Training requires a Slurm compute node')
    out=root/'output';out.mkdir(exist_ok=True)
    if (out/'report.json').exists() and json.loads((out/'report.json').read_text())['state']=='COMPLETED':
        print('ALREADY_COMPLETED_NO_REFIT',flush=True);return
    config=json.loads((root/'config.json').read_text());training=config['training']
    if not torch.cuda.is_available():raise RuntimeError('Requested GPU is not available to PyTorch')
    device=torch.device('cuda:0');torch.set_num_threads(4);torch.set_num_interop_threads(1)
    torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    torch.use_deterministic_algorithms(True)
    seed=training['seed'];random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
    status=dict(state='RUNNING',phase='PREPARE',exp_id=config['exp_id'],job_id=os.environ['SLURM_JOB_ID'],
                model_count=1,region_count=119,optimizer_steps=0,training_started=False,updated_at=now())
    write_json(out/'status.json',status)
    data=load_npz(root/'inputs/inputs.npz')
    ids=data['support_ids'].astype(str).tolist();dates=data['dates'].astype('datetime64[D]');fit=data['fit_mask'].astype(bool)
    if len(ids)!=119 or len(set(ids))!=119 or int(fit.sum())!=66 or int((~fit).sum())!=12:
        raise ValueError('Frozen 119-region split differs')
    if str(dates[0])!='1998-08-01' or str(dates[-1])!='2008-12-31' or not np.all(np.diff(dates)==np.timedelta64(1,'D')):
        raise ValueError('History calendar differs')
    if data['static_features'].shape!=(119,7):raise ValueError('Exactly seven original statics required')
    dynamic=dynamic_inputs(data['forcing'])
    fit_days=(dates>=np.datetime64('2002-01-01'))&(dates<=np.datetime64('2007-12-31'))
    mean=dynamic[fit_days].astype(float).mean(axis=(0,1));scale=dynamic[fit_days].astype(float).std(axis=(0,1));scale[scale==0]=1
    if not np.isfinite(dynamic).all() or not np.isfinite(data['static_features']).all():raise ValueError('Nonfinite predictors')
    normalizer=dict(dynamic_names=DYNAMIC_NAMES,mean=mean.tolist(),scale=scale.tolist(),fit_period='2002-2007',static_features='original standardized seven columns')
    write_json(out/'normalizer.json',normalizer)
    x=normalized_inputs(dynamic,data['static_features'],mean,scale,device)
    if x.shape!=(len(dates),119,11):raise ValueError('The only network input must have 11 columns')
    train_end=int(np.count_nonzero(dates<=np.datetime64('2007-12-31')))
    if np.any(data['sampling_weights'][fit,train_end:]!=0):raise ValueError('Fit labels have support after 2007')
    weights=torch.as_tensor(data['sampling_weights'],device=device)
    targets=torch.as_tensor(data['targets_cm'],device=device)
    fit_t=torch.as_tensor(fit,device=device)
    train_weights=weights[fit_t,:train_end];train_targets=targets[fit_t]
    all_fit=torch.ones(int(fit.sum()),dtype=torch.bool,device=device)
    val_valid=(~fit_t)[:,None]&torch.isfinite(targets)
    data_hash=hashlib.sha256((root/'inputs/inputs.npz').read_bytes()).hexdigest()
    fingerprint=hashlib.sha256((root/'config.json').read_bytes()+(root/'source_manifest.json').read_bytes()+data_hash.encode()).hexdigest()
    model=network(config,device)
    optimizer=torch.optim.Adam(model.parameters(),lr=training['learning_rate'])
    epoch0=0;wait=0;best_score=None;best_epoch=0
    last=out/'last.pt'
    if last.exists():
        state=torch.load(last,map_location=device,weights_only=False)
        if state['fingerprint']!=fingerprint:raise ValueError('Resume requires unchanged input/config/source')
        model.load_state_dict(state['model']);optimizer.load_state_dict(state['optimizer'])
        epoch0=state['epoch'];wait=state['wait'];best_score=state['best_score'];best_epoch=state['best_epoch']
        torch.set_rng_state(state['rng_cpu'].cpu())
        torch.cuda.set_rng_state_all([v.cpu() for v in state['rng_cuda']])
        print(json.dumps(dict(event='RESUME',epoch=epoch0,wait=wait)),flush=True)
    else:
        # One combined check before the first real update, no separate trial fit.
        model.eval()
        with torch.no_grad():
            whole,_=model(x[:2]);first,hc=model(x[:1]);second,_=model(x[1:2],hc)
        torch.testing.assert_close(whole,torch.cat([first,second]),atol=1e-6,rtol=1e-5)
        np.testing.assert_allclose(dynamic[:,:,0],data['forcing'][:,:,0],atol=0,rtol=0)
        np.testing.assert_allclose(dynamic[:,:,1],.5*(data['forcing'][:,:,3]+data['forcing'][:,:,4]),atol=0,rtol=0)
        np.testing.assert_allclose(dynamic[:,:,2],data['forcing'][:,:,1],atol=0,rtol=0)
        np.testing.assert_allclose(dynamic[:,:,3],data['forcing'][:,:,5],atol=0,rtol=0)
        if not np.allclose(data['sampling_weights'].sum(1),1,atol=1e-6):raise ValueError('Incomplete observation windows')
        # Synthetic cm output must remain cm after projection, with no RDS mm conversion.
        torch.testing.assert_close(weights@torch.ones_like(x[:,:,0])*2,torch.full_like(targets,2),atol=1e-5,rtol=1e-5)
        write_json(out/'interface_check.json',dict(state='PASS',input_shape=list(x.shape),dynamic_names=DYNAMIC_NAMES,
            static_columns=7,external_swe_in_network=False,temporal_split='66 fit / 12 validation',
            projection_unit='cm, no 0.1 conversion',hidden_state_continuation='PASS',optimizer_steps=0,
            parameter_count=sum(p.numel() for p in model.parameters()),torch_version=torch.__version__,
            cuda_version=torch.version.cuda,gpu=torch.cuda.get_device_name(0),job_id=os.environ['SLURM_JOB_ID']))
    began=time.monotonic();completed_epoch=epoch0
    for epoch in range(epoch0+1,training['max_epochs']+1):
        if wait>=training['patience']:break
        start=time.monotonic();model.train();optimizer.zero_grad(set_to_none=True)
        # No state argument -> zero h/c. No detach or temporal truncation anywhere.
        daily_train,_=model(x[:train_end])
        fit_prediction=train_weights@daily_train
        pc,yc,_,_,valid=center_on_fit_windows(fit_prediction,train_targets,all_fit)
        loss=(pc-yc)[valid].square().mean()
        if not torch.isfinite(loss):raise FloatingPointError('Nonfinite fit loss')
        loss.backward()
        norm=torch.nn.utils.clip_grad_norm_(model.parameters(),training['gradient_clip_norm'],error_if_nonfinite=True)
        if not any(p.grad is not None and torch.count_nonzero(p.grad).item()>0 for p in model.parameters()):
            raise RuntimeError('Model disconnected from window supervision')
        loss_before=float(loss.detach());grad=float(norm);optimizer.step()
        del daily_train,fit_prediction,pc,yc,loss
        # Updated weights get their own complete history, reference and 2008 state.
        model.eval()
        with torch.no_grad():
            daily,hc=model(x)
            raw=weights@daily
            centered,observed,pref,yref,_=center_on_fit_windows(raw,targets,fit_t)
            val_mse=float((centered-observed)[val_valid].square().mean())
        if not np.isfinite(val_mse):raise FloatingPointError('Nonfinite updated-weight validation')
        improved=best_score is None or val_mse<best_score
        if improved:best_score=val_mse;best_epoch=epoch;wait=0
        else:wait+=1
        completed_epoch=epoch
        metrics=dict(epoch=epoch,optimizer_steps=epoch,fit_mse_cm2_before_update=loss_before,
            gradient_norm_before_clip=grad,validation_mse_cm2=val_mse,best_validation_mse_cm2=best_score,
            best_epoch=best_epoch,wait=wait,seconds=time.monotonic()-start,updated_at=now())
        common=dict(model=model.state_dict(),epoch=epoch,wait=wait,best_score=best_score,best_epoch=best_epoch,
            fingerprint=fingerprint,config=config,normalizer=normalizer,region_ids=ids,
            prediction_reference_cm=pref.cpu(),observation_reference_cm=yref.cpu(),
            h_2008=hc[0].cpu(),c_2008=hc[1].cpu(),metrics=metrics)
        if improved:save_checkpoint(out/'best.pt',common)
        save_checkpoint(last,dict(common,optimizer=optimizer.state_dict(),rng_cpu=torch.get_rng_state(),
                                  rng_cuda=torch.cuda.get_rng_state_all()))
        with (out/'metrics.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(metrics)+'\n')
        status.update(phase='FIT',epoch=epoch,optimizer_steps=epoch,training_started=True,wait=wait,
                      best_epoch=best_epoch,best_validation_mse_cm2=best_score,updated_at=now())
        write_json(out/'status.json',status)
        if epoch==1 or epoch%10==0 or wait>=training['patience']:
            print(json.dumps(dict(event='EPOCH_COMPLETED',**metrics)),flush=True)
        del daily,raw,centered,observed
    selected=torch.load(out/'best.pt',map_location=device,weights_only=False)
    model.load_state_dict(selected['model']);model.eval()
    with torch.no_grad():
        daily,hc=model(x)
        centered,observed,pref,yref,_=center_on_fit_windows(weights@daily,targets,fit_t)
    torch.testing.assert_close(pref,selected['prediction_reference_cm'].to(device),atol=1e-5,rtol=1e-6)
    torch.testing.assert_close(hc[0],selected['h_2008'].to(device),atol=1e-6,rtol=1e-5)
    torch.testing.assert_close(hc[1],selected['c_2008'].to(device),atol=1e-6,rtol=1e-5)
    current_epoch=completed_epoch
    selection=dict(state='FROZEN',exp_id=config['exp_id'],best_epoch=selected['epoch'],
                   best_validation_rmse_cm=best_score**.5,epochs_completed=current_epoch,
                   stop_reason='PATIENCE' if wait>=training['patience'] else 'MAX_EPOCHS',
                   seed=seed,attempt_count=1,weight_reference_state_consistent=True,
                   application_targets_read=False,selected_at=now())
    write_json(out/'selection.json',selection)
    mask=dates>=np.datetime64('2008-01-01')
    np.savez_compressed(out/'daily_storage_2008.npz',dates=dates[mask],support_ids=np.array(ids),
                        daily_anomaly_cm=(daily-pref).cpu().numpy()[mask])
    history=centered.cpu().numpy()
    # Application input is opened only after global model selection is frozen.
    app=load_npz(root/'application_inputs.npz')
    if app['region_ids'].astype(str).tolist()!=ids or str(app['dates'][0])!='2009-01-01' or str(app['dates'][-1])!='2010-12-31':
        raise ValueError('Application identity mismatch')
    xa=normalized_inputs(app['dynamic'],data['static_features'],mean,scale,device)
    with torch.no_grad():
        application,hc_end=model(xa,hc)
        app_predictions=torch.as_tensor(app['sampling_weights'],device=device)@application-pref
    if not torch.isfinite(app_predictions).all():raise FloatingPointError('Nonfinite frozen application')
    np.savez_compressed(out/'predictions.npz',support_ids=np.array(ids),
        solution_ids=np.concatenate([data['solution_ids'],app['solution_ids']]),history_anomaly_cm=history,
        application_anomaly_cm=app_predictions.cpu().numpy(),fit_mask=fit,
        prediction_reference_cm=pref.cpu().numpy(),observation_reference_cm=yref.cpu().numpy())
    np.savez_compressed(out/'daily_storage_2009_2010.npz',dates=app['dates'],support_ids=np.array(ids),
                        daily_anomaly_cm=(application-pref).cpu().numpy())
    for date,state in [('2008-12-31',hc),('2010-12-31',hc_end)]:
        np.savez_compressed(out/('state_'+date+'.npz'),h=state[0].cpu().numpy(),c=state[1].cpu().numpy(),
            support_ids=np.array(ids),model_id=np.array(config['exp_id']),last_forcing_date=np.array(date),
            prediction_reference_cm=pref.cpu().numpy())
    summary=compare(root,out)
    report=dict(state='COMPLETED',exp_id=config['exp_id'],job_id=os.environ['SLURM_JOB_ID'],
                model_count=1,region_count=119,attempt_count=1,seed=seed,epochs_completed=current_epoch,
                selected_epoch=selected['epoch'],stop_reason=selection['stop_reason'],
                optimizer_steps=current_epoch,selection=selection,comparison=summary,
                torch_version=torch.__version__,gpu=torch.cuda.get_device_name(0),
                elapsed_seconds_this_invocation=time.monotonic()-began,finished_at=now())
    write_json(out/'report.json',report);write_json(out/'status.json',report)
    print(json.dumps(dict(event='COMPLETED',selected_epoch=selected['epoch'],epochs_completed=current_epoch,
                          comparison=summary['metrics'])),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,required=True);args=parser.parse_args()
    try:run(args.root)
    except Exception as exc:
        (args.root/'output').mkdir(exist_ok=True)
        write_json(args.root/'output/status.json',dict(state='FAILED',error=str(exc),job_id=os.environ.get('SLURM_JOB_ID'),updated_at=now()))
        traceback.print_exc();sys.exit(1)
