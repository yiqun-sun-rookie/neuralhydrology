"""One bounded snow-water withdrawal coefficient around the frozen RDS01 model."""
from typing import List, Optional

import torch
from torch import Tensor, nn
from torch.nn import functional as F

from .regional_daily_storage import RegionalDailyStorage


@torch.jit.script
def snowloss_scan(precip: Tensor, temp: Tensor, demand: Tensor, params: Tensor,
                  initial: Tensor, snow_beta: Tensor, record: bool = False):
    snow, fast, slow = initial[:, 0], initial[:, 1], initial[:, 2]
    means = torch.jit.annotate(List[Tensor], [])
    states = torch.jit.annotate(List[Tensor], [])
    fluxes = torch.jit.annotate(List[Tensor], [])
    melt_c, kf, kr, kg, gamma = (params[:, 0], params[:, 1], params[:, 2],
                               params[:, 3], params[:, 4])
    partition = torch.sigmoid(-temp)
    potential_melt = torch.relu(temp) * melt_c
    beta = snow_beta.clamp(0.0, 1.0)
    for day in range(precip.size(0)):
        previous = snow + fast + slow
        ps = precip[day] * partition[day]
        available = snow + ps
        es = torch.minimum(available, beta * demand[day])
        remaining_demand = torch.relu(demand[day] - es)
        melt = torch.minimum(available - es, potential_melt[day])
        snow = available - es - melt
        u = fast + precip[day] - ps + melt
        ef = torch.minimum(u, remaining_demand)
        u1 = u - ef
        qf = kf * u1
        recharge = kr * (u1 - qf)
        fast = u1 - qf - recharge
        v = slow + recharge
        eg = torch.minimum(v, gamma * torch.relu(remaining_demand - ef))
        qg = kg * (v - eg)
        slow = v - eg - qg
        means.append((previous + snow + fast + slow) * 0.5)
        if record:
            states.append(torch.stack([snow, fast, slow], dim=-1))
            fluxes.append(torch.stack([melt, es + ef + eg, qf + qg, recharge, es], dim=-1))
    final = torch.stack([snow, fast, slow], dim=-1)
    if record:
        return torch.stack(means), final, torch.stack(states), torch.stack(fluxes)
    return torch.stack(means), final, initial.new_empty((0,)), initial.new_empty((0,))


class RegionalDailyStorageSnowLoss(RegionalDailyStorage):
    def __init__(self, static_size: int, dynamic_mean, dynamic_scale, snow_beta: float = 0.05):
        super().__init__(static_size, dynamic_mean, dynamic_scale)
        self.requires_grad_(False)
        self.snow_beta = nn.Parameter(torch.tensor(float(snow_beta), dtype=torch.float32))

    def forward(self, forcing: Tensor, statics: Tensor, initial: Optional[Tensor] = None,
                record: bool = False):
        temp = (forcing[:, :, 3] + forcing[:, :, 4]) * 0.5
        dynamic = torch.stack([temp, forcing[:, :, 1], forcing[:, :, 5]], dim=-1)
        dynamic = (dynamic - self.dynamic_mean) / self.dynamic_scale
        static_days = statics.unsqueeze(0).expand(forcing.size(0), -1, -1)
        demand = F.softplus(self.demand_net(torch.cat([dynamic, static_days], dim=-1))).squeeze(-1)
        params, configured_initial = self.initialize(statics)
        return snowloss_scan(forcing[:, :, 0], temp, demand, params,
                             configured_initial if initial is None else initial, self.snow_beta, record)
