"""Calibrate one shared coefficient; all RDS01 weights remain frozen."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import random
import sys
import time
import traceback

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from id25.regional_daily_storage_snowloss import RegionalDailyStorageSnowLoss
from id25.regional_storage_runtime import DailyState, StorageRuntime


def now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False), encoding='utf-8')
    os.replace(temporary, path)


def save_checkpoint(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    torch.save(value, temporary)
    os.replace(temporary, path)


def describe(prediction, observed, columns):
    p, y = prediction[:, columns].astype(float), observed[:, columns].astype(float)
    if not np.isfinite(p).all() or not np.isfinite(y).all():
        raise ValueError('The fixed complete evaluation windows must be finite')
    error = p - y
    ys, ps = y.std(0, ddof=0), p.std(0, ddof=0)
    if np.any(ys <= 1e-6) or np.any(ps <= 1e-6):
        raise ValueError('Storage amplitude metrics require nonconstant window series')
    ratio = ps / ys
    return {'pooled_rmse_cm': float(np.sqrt(np.mean(error ** 2))), 'residual_count': int(error.size),
            'regional_rmse_cm': np.sqrt(np.mean(error ** 2, axis=0)).tolist(),
            'regional_bias_cm': error.mean(0).tolist(), 'sd_ratio': ratio.tolist(),
            'amplitude_error': np.abs(np.log(ratio)).tolist()}


def gate(prediction, observed, cold, rest, baseline, config):
    cm = describe(prediction, observed, cold)
    rm = float(np.sqrt(np.mean((prediction[:, rest].astype(float) - observed[:, rest]) ** 2)))
    checks = {
        'cold_each_rmse_not_increased': bool(np.all(np.array(cm['regional_rmse_cm']) <=
                                                     np.array(baseline['cold']['regional_rmse_cm']))),
        'cold_pooled_rmse_reduced_10_percent': bool(cm['pooled_rmse_cm'] <=
             baseline['cold']['pooled_rmse_cm'] * (1 - config['cold_rmse_reduction_min'])),
        'cold_each_amplitude_error_reduced': bool(np.all(np.array(cm['amplitude_error']) <
                                                     np.array(baseline['cold']['amplitude_error']))),
        'rest_pooled_rmse_within_2_percent': bool(rm <= baseline['rest_pooled_rmse_cm'] *
                                                    (1 + config['rest_rmse_increase_max']))}
    return {'cold': cm, 'rest_pooled_rmse_cm': rm, 'rest_residual_count': int(len(rest) * len(prediction)),
            'checks': checks, 'eligible': all(checks.values())}


def run(args):
    config = json.loads(args.config.read_text())
    root = args.config.resolve().parent
    parent = root / 'parent'
    metadata = json.loads((parent / 'metadata.json').read_text())
    receipt = json.loads((root / 'inputs/input_receipt.json').read_text())
    scales = json.loads((root / 'fit_scales.json').read_text())
    parent_sha = hashlib.sha256((parent / 'weights.pt').read_bytes()).hexdigest()
    if metadata['model_id'] != config['parent_model_id']:
        raise ValueError('Unexpected parent model')
    args.output.mkdir(parents=True, exist_ok=True)
    if (args.output / 'last.pt').exists() and not args.resume:
        raise ValueError('Existing calibration requires explicit resume')
    torch.set_num_threads(config['cpu_threads'])
    torch.set_num_interop_threads(1)
    torch.manual_seed(config['seed'])
    random.seed(config['seed'])
    np.random.seed(config['seed'])
    with np.load(root / 'inputs/inputs.npz', allow_pickle=False) as z:
        data = {name: z[name] for name in z.files}
    with np.load(root / 'baseline_monthly.npz', allow_pickle=False) as z:
        original = {name: z[name] for name in z.files}
    with np.load(parent / 'references.npz', allow_pickle=False) as z:
        y_ref = torch.as_tensor(z['observation_reference_cm'].copy(), dtype=torch.float32)
    ids = data['support_ids'].astype(str).tolist()
    if (ids != metadata['region_ids'] or ids != original['support_ids'].astype(str).tolist()
            or not np.array_equal(data['solution_ids'], original['solution_ids'])
            or not np.array_equal(data['fit_mask'], original['fit_mask'])
            or str(data['dates'][0]) != '1998-08-01' or str(data['dates'][-1]) != '2008-12-31'):
        raise ValueError('Calibration input identity/calendar differs from frozen RDS01')
    cold = [ids.index(k) for k in config['cold_region_ids']]
    rest = [k for k in range(len(ids)) if k not in cold]
    fit, val = data['fit_mask'], ~data['fit_mask']
    if int(val.sum()) != 12 or not np.isfinite(data['targets_cm']).all():
        raise ValueError('Expected all 12 complete 2008 windows for every region')
    forcing, statics = torch.from_numpy(data['forcing']), torch.from_numpy(data['static_features'])
    weights = torch.from_numpy(data['sampling_weights'])
    fit_t = torch.from_numpy(fit)
    targets = torch.from_numpy(data['targets_cm']) - y_ref
    if not np.allclose(targets.numpy(), original['observed_anomaly_cm'], atol=1e-5, rtol=0):
        raise ValueError('Observation reference must remain fixed')
    baseline = {'cold': describe(original['prediction_anomaly_cm'][val],
                                original['observed_anomaly_cm'][val], cold),
                'rest_pooled_rmse_cm': float(np.sqrt(np.mean(
                    (original['prediction_anomaly_cm'][val][:, rest].astype(float) -
                     original['observed_anomaly_cm'][val][:, rest]) ** 2)))}
    transforms = metadata['transforms']
    model = RegionalDailyStorageSnowLoss(statics.shape[1], transforms['dynamic_mean'],
                                        transforms['dynamic_scale'], config['snow_beta_initial'])
    parent_weights = torch.load(parent / 'weights.pt', map_location='cpu', weights_only=True)
    loaded = model.load_state_dict(parent_weights, strict=False)
    if loaded.missing_keys != ['snow_beta'] or loaded.unexpected_keys:
        raise ValueError('Only the new scalar may be absent from the frozen parent')
    trainable = [name for name, p in model.named_parameters() if p.requires_grad]
    if trainable != ['snow_beta'] or model.snow_beta.numel() != 1:
        raise ValueError('Exactly one trainable scalar is permitted')
    optimizer = torch.optim.Adam([model.snow_beta], lr=config['learning_rate'])
    cold_scale = torch.tensor([scales[ids[k]] for k in cold], dtype=torch.float32)
    fit_forcing, fit_statics = forcing[:, cold], statics[cold]
    fit_weights = weights[fit_t]
    fit_y = targets[fit_t][:, cold]
    history, start, stale = [], 0, 0
    best_score, diagnostic_score, selected_epoch = None, None, None
    if args.resume:
        previous = torch.load(args.resume, map_location='cpu', weights_only=False)
        if (previous['config'] != config or previous['parent_sha256'] != parent_sha
                or previous['input_sha256'] != receipt['inputs_sha256']):
            raise ValueError('Resume must preserve config, inputs and parent')
        model.load_state_dict(previous['model'])
        optimizer.load_state_dict(previous['optimizer'])
        history, start, stale = previous['history'], previous['epoch'], previous['stale_epochs']
        best_score, diagnostic_score = previous['best_score'], previous['diagnostic_score']
        selected_epoch = previous['selected_epoch']
    write_json(args.output / 'baseline_metrics.json', baseline)
    print(json.dumps({'event': 'START', 'time': now(), 'exp_id': config['exp_id'],
                      'trainable_parameters': trainable, 'trainable_scalar_count': 1,
                      'parent_sha256': parent_sha, 'resume_epoch': start}), flush=True)
    started = time.monotonic()
    for epoch in range(start + 1, config['epochs'] + 1):
        if stale >= config['patience']:
            break
        began = time.monotonic()
        optimizer.zero_grad(set_to_none=True)
        # Gradients are required for the two fitting regions only. Evaluation still covers all 119.
        daily, _, _, _ = model(fit_forcing, fit_statics)
        pred = .1 * (fit_weights @ daily)
        pc = pred - pred.mean(0)
        loss = (((pc - fit_y) / cold_scale) ** 2).mean()
        if not torch.isfinite(loss):
            raise FloatingPointError('Nonfinite fit loss')
        loss.backward()
        grad = torch.nn.utils.clip_grad_norm_([model.snow_beta], config['gradient_clip'], error_if_nonfinite=True)
        if model.snow_beta.grad is None:
            raise RuntimeError('New coefficient is disconnected from the fit loss')
        signed_grad = float(model.snow_beta.grad)
        fit_loss = float(loss.detach())
        optimizer.step()
        with torch.no_grad():
            model.snow_beta.clamp_(0, 1)
        del daily, pred, pc, loss
        with torch.no_grad():
            daily, final_state, _, _ = model(forcing, statics)
            prediction = .1 * (weights @ daily)
            p_ref = prediction[fit_t].mean(0)
            centered = prediction - p_ref
            evaluation = gate(centered.numpy()[val], original['observed_anomaly_cm'][val],
                              cold, rest, baseline, config)
        score = evaluation['cold']['pooled_rmse_cm']
        improved = evaluation['eligible'] and (best_score is None or score < best_score)
        if improved:
            best_score, selected_epoch, stale = score, epoch, 0
        else:
            stale += 1
        best_trial = diagnostic_score is None or score < diagnostic_score
        if best_trial:
            diagnostic_score = score
        row = {'epoch': epoch, 'snow_beta': float(model.snow_beta), 'fit_loss_before_update': fit_loss,
               'gradient_before_update': signed_grad, 'gradient_norm': float(grad),
               'validation': evaluation, 'selected_best': bool(improved), 'stale_epochs': stale,
               'epoch_seconds': time.monotonic() - began, 'updated_at': now()}
        history.append(row)
        checkpoint = {'model': model.state_dict(), 'optimizer': optimizer.state_dict(),
                      'config': config, 'epoch': epoch, 'history': history, 'stale_epochs': stale,
                      'best_score': best_score, 'diagnostic_score': diagnostic_score,
                      'selected_epoch': selected_epoch, 'parent_sha256': parent_sha,
                      'input_sha256': receipt['inputs_sha256'], 'region_ids': ids,
                      'prediction_reference_cm': p_ref, 'observation_reference_cm': y_ref,
                      'state': final_state, 'state_date': '2008-12-31', 'saved_at': now()}
        if improved:
            save_checkpoint(args.output / 'best.pt', checkpoint)
        if best_trial:
            save_checkpoint(args.output / 'best_trial_diagnostic_only.pt', checkpoint)
        save_checkpoint(args.output / 'last.pt', checkpoint)
        write_json(args.output / 'metrics.json', history)
        status = {'state': 'RUNNING', 'exp_id': config['exp_id'], 'job_id': os.environ.get('SLURM_JOB_ID'),
                  'epoch': epoch, 'snow_beta': row['snow_beta'], 'cold_validation_rmse_cm': score,
                  'eligible': evaluation['eligible'], 'selected_epoch': selected_epoch,
                  'stale_epochs': stale, 'updated_at': now()}
        write_json(args.output / 'status.json', status)
        print(json.dumps(status), flush=True)
    if not history:
        raise RuntimeError('No calibration history')
    frozen_unchanged = all(torch.equal(model.state_dict()[k], v) for k, v in parent_weights.items())
    if not frozen_unchanged:
        raise RuntimeError('A frozen parent tensor changed')
    diagnostic = min(history, key=lambda row: row['validation']['cold']['pooled_rmse_cm'])
    report = {'state': 'COMPLETED', 'exp_id': config['exp_id'], 'job_id': os.environ.get('SLURM_JOB_ID'),
              'epochs_completed': history[-1]['epoch'], 'stop_reason':
                  'PATIENCE' if stale >= config['patience'] else 'MAX_EPOCHS',
              'trainable_scalar_count': 1, 'parent_weights_unchanged': frozen_unchanged,
              'parent_sha256': parent_sha, 'selected_epoch': selected_epoch,
              'decision': 'CONTINUE_SELECTED_CANDIDATE' if selected_epoch else 'RETAIN_RDS01',
              'selected_snow_beta': next((r['snow_beta'] for r in history if r['epoch'] == selected_epoch), None),
              'baseline_2008': baseline, 'best_trial_diagnostic_only': diagnostic,
              'best_trial_is_adopted': bool(selected_epoch == diagnostic['epoch']),
              'continuation_2009_2010_started': False, 'finished_at': now(),
              'elapsed_seconds_this_invocation': time.monotonic() - started}
    if selected_epoch:
        selected = torch.load(args.output / 'best.pt', map_location='cpu', weights_only=False)
        model.load_state_dict(selected['model'])
        model_id = config['exp_id'] + '_epoch' + str(selected_epoch).zfill(3)
        rt_metadata = dict(metadata, model_id=model_id)
        references = {'prediction_reference_cm': selected['prediction_reference_cm'].numpy(),
                      'observation_reference_cm': selected['observation_reference_cm'].numpy()}
        runtime = StorageRuntime(model, data['static_features'], rt_metadata, references, {})
        state = DailyState(model_id, tuple(ids), '2008-12-31', selected['state'].numpy())
        runtime.save_state(state, str(args.output / 'state_2008-12-31.npz'))
        report['selected_model_id'] = model_id
        report['selected_validation'] = next(r['validation'] for r in history if r['epoch'] == selected_epoch)
    write_json(args.output / 'selection.json', report)
    write_json(args.output / 'report.json', report)
    write_json(args.output / 'status.json', report)
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--resume', type=Path)
    args = parser.parse_args()
    try:
        run(args)
    except Exception as exc:
        args.output.mkdir(parents=True, exist_ok=True)
        write_json(args.output / 'status.json', {'state': 'FAILED', 'error': str(exc), 'updated_at': now(),
                   'job_id': os.environ.get('SLURM_JOB_ID')})
        traceback.print_exc()
        sys.exit(1)
