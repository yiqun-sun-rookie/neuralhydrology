"""One frozen first-proposal diagnostic. Called only inside a Slurm worker."""
def run_diagnostic(e):
    import json
    import math
    import numpy as np
    import torch
    from diagnostic_math import exact_projection, installed_float32
    from constrained_step import project_displacement
    C=e['C']; parity=e['parity']; runtime=e['runtime']; plan=e['plan']; basin=e['basin']
    put=e['put']; np_save=e['np_save']; pt_save=e['pt_save']; arr=e['arr']; emit=e['emit']
    state=e['arms']['state_constrained']; net=state['net']; coordinate=e['coordinate']
    vector=e['vector']; install=e['install']; before=vector(state)
    masks=e['load_np']('fixed_training_masks.npz')
    masks={int(k):v.astype(bool) for k,v in masks.items()}
    state_count=sum(int(x.sum()) for x in masks.values())
    assert state_count>0 and set(masks)==set(plan['base_starts'])
    cache={False:{},True:{}}
    evaluations=[]; counts=dict(evaluations=0,parameter_updates=0,optimizer_calls=0)
    old=json.loads(e['s'].read_checked(e['base']/'inputs'/basin/'old_first_step.json'))
    old_reference=json.loads(e['s'].read_checked(e['base']/'inputs'/basin/'old_training_reference.json'))
    def forbidden_step(*args,**kwargs):
        raise AssertionError('Optimizer step forbidden in zero-update diagnostic')
    for arm in e['arms'].values():arm['optimizer'].step=forbidden_step
    def capture():
        result={k:getattr(net,k).detach().clone() for k in C.probe.RECURRENCE_FIELDS}
        return dict(fields=result,rng=torch.get_rng_state().clone(),
            prefix=torch.stack(state['prefix']),batch_size=net.batch_size,device=str(net.device),
            scalars={k:getattr(net,k) for k in ['T','sequence_length']
                if hasattr(net,k) and isinstance(getattr(net,k),(int,float,str,bool))})
    def restore(saved):
        for k,v in saved['fields'].items():setattr(net,k,v.clone())
        net.batch_size=saved['batch_size'];net.device=torch.device(saved['device'])
        for k,v in saved['scalars'].items():setattr(net,k,v)
        torch.set_rng_state(saved['rng'].clone())
    def run(label, graph, path='full', gradients=False, save_cache=False):
        counts['evaluations']+=1
        emit('evaluation_started',label=label,graph=graph,path=path,optimizer_calls=0)
        torch.set_rng_state(state['rng'].clone());net.train()
        metrics=np.zeros(8);target_sum=0.;positive_sum=0.;gs=np.zeros((9,len(before))) if gradients else None
        pred_all=[];truth_all=[];trace_all=[];segment_metrics=[];segment_targets=[]
        for number,start in enumerate(plan['base_starts']):
            initial=runtime.context.initial_state.clone() if start==0 else e['states'][start-1].clone()
            context=parity._context_with_initial_state(runtime.context,initial)
            batch=parity.WindowBatch(purpose='training_segment',global_start=start,global_end_exclusive=start+800,
                context=context,forcing=runtime.forcing[start:start+800],observations=runtime.observations[start:start+800],
                dates=runtime.dates[start:start+800],initial_state=initial,issue_start_local=695,issue_end_local=797)
            state['trace']=[];state['prefix']=[];state['capture_prefix']=save_cache
            state['count']=0 if path=='full' else 650;state['record_after']=650
            with torch.set_grad_enabled(graph):
                if path=='full':
                    cuts=[0]
                    def detach(network):
                        C.probe.detach_recurrence(network);cuts[0]+=1
                        if save_cache:cache[graph][start]=capture()
                    with C.diag.analysis_observer(net,650,detach,{},start,batch.dates):
                        filtered=parity.run_knet_filter(net,batch,
                            previous_observation=parity.previous_observation_before_window(runtime,batch))
                    assert cuts[0]==1
                    posterior=filtered.posterior_states[:,0,:]
                else:
                    saved=cache[graph][start];restore(saved);posts=[]
                    # No filter initializer after restoring the exact pre-analysis-650 boundary.
                    for day in range(650,800):
                        controls=batch.forcing[day,0,:].reshape(1,3)
                        observation=batch.observations[day,0].reshape(1,1)
                        assert bool(torch.isfinite(observation).all())
                        post=net.analysis_step(observation,controls)
                        assert bool(torch.isfinite(net.m1x_prior).all()) and bool(torch.isfinite(post).all())
                        posts.append(post.clone())
                    posterior=torch.cat([saved['prefix'],torch.stack(posts)],dim=0)[:,0,:]
                assert len(state['trace'])==150 and state['count']==800
                raw=runtime.tukf06_module.multilead_torch(batch.context.plain_model,posterior,batch.forcing)
                predictions=torch.stack([raw[k][0][695:797] for k in (1,2,3)],dim=1)
                y=runtime.observations[start+torch.arange(695,797)[:,None]+torch.arange(1,4),0]
                error=predictions-y;losses=[]
                for group,denom in zip(e['groups'](arr(y)),e['training_counts']):
                    selected=error[torch.as_tensor(group)]
                    losses.extend([selected.square().sum()/int(denom),selected.abs().sum()/int(denom)])
                if save_cache:
                    np.testing.assert_array_equal(e['state_mask'](state['trace'],start+650),masks[start])
                target,positive,values=e['state_terms'](state['trace'],masks[start],start+650,state)
                vals=np.array([float(v.detach()) for v in losses]);metrics+=vals
                target_sum+=float(target.detach());positive_sum+=float(positive.detach())
                segment_metrics.append(vals);segment_targets.append(float(target.detach()))
                if gradients:
                    objectives=losses+[target/state_count]
                    for j,objective in enumerate(objectives):
                        g=torch.autograd.grad(objective,state['parameters'],retain_graph=j<8,allow_unused=True)
                        gs[j,:-1]+=0 if g[0] is None else arr(g[0][coordinate])
                        gs[j,-1]+=0 if g[1] is None else float(g[1][coordinate])
                trace_all.append({k:np.stack([arr(t[k]).reshape(-1) for t in state['trace']])
                    for k in ['prior','posterior','previous','requested','prior_flow']})
                pred_all.append(arr(predictions));truth_all.append(arr(y))
            state['trace']=None;state['prefix']=[];state['capture_prefix']=False
            if number in (4,9,14,19,24):emit('diagnostic_segments',label=label,completed=number+1,total=25,optimizer_calls=0)
        scores=np.concatenate([metrics,[target_sum/state_count]])
        assert np.isfinite(scores).all() and (gs is None or np.isfinite(gs).all())
        data=dict(prediction=np.stack(pred_all),target=np.stack(truth_all),
            segment_flow=np.stack(segment_metrics),segment_state_target_sum=np.array(segment_targets),
            state_mask=np.stack([masks[x] for x in plan['base_starts']]),state_count=np.array(state_count),
            scores=scores,positive_sum=np.array(positive_sum),installed_parameters=vector(state))
        for k in trace_all[0]:data[k]=np.stack([v[k] for v in trace_all])
        artifact=np_save('evaluations/'+label+'.npz',data)
        record=dict(label=label,graph=graph,path=path,scores=scores.tolist(),positive_sum=positive_sum,
            artifact=artifact,optimizer_calls=0)
        put('evaluations/'+label+'.json',record);evaluations.append(record)
        emit('evaluation_complete',label=label,scores=scores.tolist(),optimizer_calls=0)
        return scores,gs,data

    baseline={};baseline_data={}
    for graph in (False,True):
        key=('full',graph)
        scores,gs,data=run('baseline_full_'+str(int(graph)),graph,gradients=graph,save_cache=True)
        baseline[key]=scores;baseline_data[key]=data
        if graph:gradients=gs
    repeat,_,_=run('baseline_full_0_repeat',False)
    zero_checks=[]
    for graph in (False,True):
        scores,_,data=run('baseline_cache_'+str(int(graph)),graph,path='cache')
        baseline[('cache',graph)]=scores;baseline_data[('cache',graph)]=data
        differences={k:float(np.max(np.abs(data[k]-baseline_data[('full',graph)][k])))
            for k in ['prediction','prior','posterior','previous','requested','prior_flow','scores']}
        zero_checks.append(dict(graph=graph,same_mode_max_absolute_differences=differences,
            cache_identity_gate=all(v==0 for v in differences.values())))
    reference_scores=np.array(old_reference['flow_metrics']+[old_reference['state_target']])
    gradient_reference=np.array(old['flow_training_pre']['flow_metrics']+[old['flow_training_pre']['state_target']])
    path_record=dict(zero_checks=zero_checks,repeat_score_difference=(repeat-baseline[('full',False)]).tolist(),
        old_nograd_difference=(baseline[('full',False)]-reference_scores).tolist(),
        old_grad_difference=(baseline[('full',True)]-gradient_reference).tolist(),
        gradient_minus_nograd=(baseline[('full',True)]-baseline[('full',False)]).tolist(),
        interpretation='No history/cache causal attribution unless same-mode zero-displacement cache gates pass.')
    put('zero_displacement_controls.json',path_record)
    pt_save('boundary_caches.pt',dict(caches={'nograd':cache[False],'grad':cache[True]},
        recurrence_fields=list(C.probe.RECURRENCE_FIELDS),cut_before_local_index=650,
        contract_sha256=e['hashlib'].sha256(e['raw_plan']).hexdigest()))
    # Reproduce the first empty-state Adam update with tensor primitives, not optimizer.step.
    g=gradients[-1];grad_norm=float(np.linalg.norm(g));clipped=g*min(1.,10./max(grad_norm,1e-300))
    dtype=state['head'].weight.dtype;gt=torch.as_tensor(clipped,dtype=dtype)
    m=torch.zeros_like(gt);v=torch.zeros_like(gt)
    m.lerp_(gt,1-.9);v.mul_(.999).addcmul_(gt,gt,value=1-.999)
    denominator=v.sqrt().div_(math.sqrt(1-.999)).add_(1e-8)
    proposal_weights=torch.as_tensor(before,dtype=dtype).clone()
    proposal_weights.addcdiv_(m,denominator,value=-(.0005/(1-.9)))
    proposal=arr(proposal_weights).astype(np.float64)-before
    projected,solver=project_displacement(proposal,gradients,max_cycles=200,tolerance=1e-10)
    exact,exact_info=exact_projection(proposal,gradients,tolerance=1e-10)
    np_save('first_proposal.npz',dict(gradients=gradients,before=before,gradient_norms=np.linalg.norm(gradients,axis=1),
        clipped_state_gradient=clipped,cast_state_gradient=arr(gt),adam_first_moment=arr(m),adam_second_moment=arr(v),
        proposal_parameters=arr(proposal_weights),proposal=proposal,dykstra=projected,
        exact=np.empty(0) if exact is None else exact,reference_scores=reference_scores))
    proposal_record=dict(dtype=str(dtype),state_gradient_norm=grad_norm,
        state_gradient_norm_difference=grad_norm-old['state_gradient_norm'],dykstra=solver,
        old_dykstra=old['solver'],independent_projection=exact_info,optimizer_calls=0,
        raw_original_vector_comparison='UNAVAILABLE: vectors were not archived in previous study')
    put('projection_diagnostic.json',proposal_record)
    directions=[('dykstra',projected)]
    if exact is not None and not np.array_equal(installed_float32(before,exact),installed_float32(before,projected)):
        directions.append(('independent',exact))
    candidate_records=[];seen={}
    for name,direction in directions:
        for alpha in [1.,.5,.25,.125]:
            install(state,before+alpha*direction);actual=vector(state)-before
            proposal_key=vector(state).astype(np.float32).tobytes()
            record=dict(direction=name,factor=alpha,actual_displacement_norm=float(np.linalg.norm(actual)),
                linear_changes=(gradients@actual).tolist(),state_strict_first_order_descent=bool(gradients[-1]@actual<0),
                scores=[],optimizer_calls=0)
            if not np.any(actual):
                record['status']='ZERO_INSTALLED_DISPLACEMENT';record['uses_zero_controls']=True
            elif proposal_key in seen:
                record['status']='IDENTICAL_INSTALLED_PARAMETERS';record['same_as']=seen[proposal_key]
            else:
                record['status']='SCORED';seen[proposal_key]=dict(direction=name,factor=alpha)
                for graph in (False,True):
                    for path in ['full','cache']:
                        label=name+'_'+str(alpha).replace('.','p')+'_'+path+'_'+str(int(graph))
                        score,_,_=run(label,graph,path=path)
                        record['scores'].append(dict(label=label,path=path,graph=graph,scores=score.tolist(),
                            delta_from_same_path_zero=(score-baseline[(path,graph)]).tolist(),
                            delta_from_old_gate=(score-reference_scores).tolist(),
                            old_flow_gate_pass=bool(np.all(score[:8]<=reference_scores[:8]+1e-12)),
                            old_state_gate_pass=bool(score[8]<=baseline[('full',True)][8]+1e-12)))
            np_save('candidate_vectors/'+name+'_'+str(alpha).replace('.','p')+'.npz',
                dict(before=before,nominal=alpha*direction,installed=vector(state),actual_displacement=actual))
            candidate_records.append(record);install(state,before)
    assert np.array_equal(vector(state),before)
    assert all(torch.equal(v,state['frozen'][k]) for k,v in net.state_dict().items())
    assert all(not arm['optimizer'].state for arm in e['arms'].values())
    put('result.json',dict(status='COMPLETE',experiment_id=plan['experiment_id'],basin=basin,
        job_id=e['os'].environ['SLURM_JOB_ID'],array_job_id=e['os'].environ['SLURM_ARRAY_JOB_ID'],
        total_optimizer_calls=0,final_network_equals_initial=True,optimizer_states_empty=True,
        counts=counts,zero_displacement=path_record,projection=proposal_record,candidates=candidate_records,
        evaluations=evaluations,scope='Fixed snapshots and behavioral proxies; no trained model or state accuracy claim'))
    emit('diagnostic_complete',basin=basin,optimizer_calls=0,evaluations=len(evaluations))
