"""Small-vector diagnostics; no model, data access, optimizer or network imports."""
import itertools
import numpy as np


def exact_projection(displacement, gradients, tolerance=1e-10):
    d = np.asarray(displacement, dtype=np.float64)
    g = np.asarray(gradients, dtype=np.float64)
    norms = np.linalg.norm(g, axis=1)
    a = g[norms > 0] / norms[norms > 0, None]
    best = None
    examined = 0
    # At most 2**9 candidates. The objective is 0.5*||x-d||^2.
    for size in range(len(a) + 1):
        for active in itertools.combinations(range(len(a)), size):
            examined += 1
            if active:
                b = a[list(active)]
                gram = b @ b.T
                lam = np.linalg.lstsq(gram, b @ d, rcond=None)[0]
                x = d - b.T @ lam
                equality = float(np.max(np.abs(b @ x)))
                dual = max(float(-lam.min()), 0.)
                stationarity = float(np.linalg.norm(x-d+b.T@lam))
            else:
                lam = np.zeros(0); x = d.copy()
                equality = dual = stationarity = 0.
            primal = max(float(np.max(a @ x)), 0.) if len(a) else 0.
            if max(primal, dual, equality, stationarity) > tolerance:
                continue
            distance = float(np.sum((x-d)**2))
            if best is None or distance < best[0]:
                best = (distance, x, dict(active=list(active), multipliers=lam.tolist(),
                    primal_residual=primal, dual_residual=dual,
                    equality_residual=equality, stationarity_residual=stationarity))
    if best is None:
        return None, dict(status='UNRESOLVED', active_sets_examined=examined)
    distance, x, detail = best
    detail.update(status='KKT_VERIFIED', active_sets_examined=examined,
        squared_distance=distance, displacement_norm=float(np.linalg.norm(x)),
        state_directional_derivative=float(g[-1] @ x),
        linear_changes=(g@x).tolist())
    return x, detail


def installed_float32(before, displacement):
    before = np.asarray(before, dtype=np.float64)
    value = (before + np.asarray(displacement, dtype=np.float64)).astype(np.float32)
    return value.astype(np.float64) - before
