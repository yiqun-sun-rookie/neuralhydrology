"""One small CUDA/transfer check on each GPU allocated to an isolated audit job."""
import argparse
import datetime
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_name(path.name + ".pending")
    pending.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    pending.replace(path)


def command(args):
    return subprocess.run(args, capture_output=True, text=True, timeout=12, check=True).stdout


def run(root, node, expected):
    out = root / "nodes" / node
    report_path = out / "result.json"
    job_id = os.environ["SLURM_JOB_ID"]
    report = dict(node=node, expected_gpus=expected, job_id=job_id, state="STARTED", cards=[],
                  started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  platform=platform.platform(), libc=platform.libc_ver(),
                  scientific_model_preflight=False, other_processes_stopped=False)
    save(report_path, report)
    try:
        inventory = command(["nvidia-smi", "--query-gpu=index,uuid,name,pci.bus_id,memory.total,driver_version",
                             "--format=csv,noheader,nounits"])
        report["inventory"] = inventory
        report["inventory_gpu_count"] = len([line for line in inventory.splitlines() if line.strip()])
        save(report_path, report)
        assigned = [x.strip() for x in os.environ.get("SLURM_JOB_GPUS", "").split(",") if x.strip()]
        report["slurm_job_gpus"] = assigned
        if len(assigned) != expected or report["inventory_gpu_count"] != expected:
            report["state"] = "INVENTORY_OR_ALLOCATION_MISMATCH"
            save(report_path, report)
            return 2
        for gpu_id in assigned:
            row = command(["nvidia-smi", "-i", gpu_id,
                           "--query-gpu=uuid,name,memory.total,driver_version", "--format=csv,noheader,nounits"])
            uuid, name, memory, driver = [x.strip() for x in row.strip().split(",")]
            processes = command(["nvidia-smi", "-i", uuid, "--query-compute-apps=pid", "--format=csv,noheader"])
            card = dict(slurm_gpu_id=gpu_id, uuid=uuid, name=name, memory_MiB=float(memory),
                        driver=driver, active_compute_processes=bool(processes.strip()), state="NOT_TESTED")
            report["cards"].append(card)
        if any(card["active_compute_processes"] for card in report["cards"]):
            report["state"] = "SKIPPED_ACTIVE_COMPUTE_ON_ALLOCATED_GPU"
            save(report_path, report)
            return 3
        os.environ["CUDA_VISIBLE_DEVICES"] = ",".join(card["uuid"] for card in report["cards"])
        report["state"] = "IMPORTING_FRAMEWORK"
        save(report_path, report)
        try:
            import numpy as np
            import tensorflow as tf
        except Exception as error:
            report.update(state="SOFTWARE_ENVIRONMENT_ERROR", error=repr(error))
            save(report_path, report)
            return 4
        report["tensorflow_version"] = tf.__version__
        devices = tf.config.list_physical_devices("GPU")
        report["tensorflow_gpu_count"] = len(devices)
        if len(devices) != expected:
            report["state"] = "CUDA_DEVICE_COUNT_MISMATCH"
            save(report_path, report)
            return 2
        tf.config.set_soft_device_placement(False)
        tf.config.experimental.enable_tensor_float_32_execution(False)
        for device in devices:
            tf.config.set_logical_device_configuration(
                device, [tf.config.LogicalDeviceConfiguration(memory_limit=512)])
        host = (np.arange(256 * 256, dtype=np.float32).reshape(256, 256) % 17)
        for index, card in enumerate(report["cards"]):
            card["state"] = "CUDA_TEST_STARTED"
            report["state"] = "CHECKING_CUDA"
            save(report_path, report)
            started = time.perf_counter()
            try:
                with tf.device("/GPU:" + str(index)):
                    uploaded = tf.convert_to_tensor(host)
                    result = tf.linalg.matmul(tf.eye(256), uploaded)
                    actual_device = result.device
                    downloaded = result.numpy()
                if "GPU:" not in actual_device.upper() or not np.array_equal(downloaded, host):
                    raise RuntimeError("GPU placement or exact matrix/transfer result differs")
                card.update(state="PASS", elapsed_seconds=time.perf_counter() - started,
                            actual_device=actual_device, host_to_device=True,
                            matrix_operation=True, device_to_host=True, exact_result=True)
            except Exception as error:
                card.update(state="CUDA_CHECK_FAILED", error=repr(error),
                            elapsed_seconds=time.perf_counter() - started)
            save(report_path, report)
        report["state"] = "PASS_ALL_GPUS" if all(card["state"] == "PASS" for card in report["cards"]) else "PARTIAL_CUDA_FAILURE"
        report["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save(report_path, report)
        print(json.dumps(report), flush=True)
        return 0 if report["state"] == "PASS_ALL_GPUS" else 2
    except Exception as error:
        report.update(state="DRIVER_OR_DIAGNOSTIC_ERROR", error=repr(error))
        save(report_path, report)
        return 2


def finalize(root, node, exit_code):
    path = root / "nodes" / node / "result.json"
    report = json.loads(path.read_text()) if path.exists() else dict(node=node, state="NO_WORKER_REPORT")
    report["worker_exit_code"] = exit_code
    if exit_code in (124, 137) and report.get("state") != "PASS_ALL_GPUS":
        report["state_before_timeout"] = report.get("state")
        report["state"] = "DIAGNOSTIC_TIMEOUT"
    save(path, report)
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("run", "finalize"))
    parser.add_argument("root", type=Path)
    parser.add_argument("node")
    parser.add_argument("value", type=int)
    args = parser.parse_args()
    if args.mode == "run":
        sys.exit(run(args.root, args.node, args.value))
    finalize(args.root, args.node, args.value)
