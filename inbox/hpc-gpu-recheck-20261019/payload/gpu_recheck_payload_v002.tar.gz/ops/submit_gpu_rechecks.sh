#!/bin/bash
set -euo pipefail
root=/data1/home/sunyiq/hpc_gpu_recheck_20261019_001
exec 9>"$root/submission.lock"
flock -n 9 || { echo AUDIT_SUBMISSION_LOCKED; exit 70; }
for node in ngu001 ngu002 ngu101 ngu103 ngu201 ngu202 ngu203; do
    mkdir -p "$root/nodes/$node"
    state=$(timeout 25 sinfo -h -N -n "$node" -o '%t' | head -n 1)
    printf '%s\n' "$state" > "$root/nodes/$node/availability.txt"
    printf 'NODE=%s STATE=%s\n' "$node" "$state"
    case "$state" in idle|mix|alloc) ;; *) echo NODE_NOT_SCHEDULABLE_NO_SUBMISSION; continue;; esac
    if test -e "$root/nodes/$node/job_id.txt" || test -e "$root/nodes/$node/submission_intent.json"; then
        echo EXISTING_NODE_SUBMISSION_NO_REPLAY
        continue
    fi
    name="ghr_${node#ngu}_261019"
    queue=$(timeout 25 squeue -h -u sunyiq -n "$name" -o '%i|%j|%T')
    history=$(timeout 25 sacct -X -S 2026-10-19 -u sunyiq --name="$name" --format=JobIDRaw,JobName%24,State,ExitCode -n -P)
    if test -n "$queue" || test -n "$history"; then
        printf '%s\n%s\n' "$queue" "$history"
        echo EXISTING_AUDIT_JOB_REQUIRES_RECONCILIATION
        continue
    fi
    printf '{"node":"%s","created_utc":"%s","wall_seconds":180}\n' "$node" "$(date -u +%FT%TZ)" > "$root/nodes/$node/submission_intent.json"
    set +e
    sbatch --parsable "$root/hpc/$node.slurm" > "$root/nodes/$node/sbatch_reply.txt" 2> "$root/nodes/$node/sbatch_error.txt"
    code=$?
    set -e
    cat "$root/nodes/$node/sbatch_reply.txt"
    cat "$root/nodes/$node/sbatch_error.txt"
    if test "$code" -ne 0; then echo "SBATCH_FAILED=$code; intent retained"; continue; fi
    job_id=$(cut -d';' -f1 "$root/nodes/$node/sbatch_reply.txt" | tr -d '\r\n')
    case "$job_id" in ''|*[!0-9]*) echo AMBIGUOUS_REPLY_NO_REPLAY; continue;; esac
    printf '%s\n' "$job_id" > "$root/nodes/$node/job_id.txt"
    printf '%s\t%s\t%s\n' "$(date -u +%FT%TZ)" "$node" "$job_id" >> "$root/submissions.tsv"
    printf 'NODE_JOB=%s|%s\n' "$node" "$job_id"
done
echo AUDIT_SUBMISSION_PASS_FINISHED_EXISTING_EXPERIMENTS_UNTOUCHED
