"""Bound BLAS import threads for the untested ngu103 diagnostic recovery only."""
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys


ROOT = Path('/data1/home/sunyiq/hpc_gpu_recheck_20261019_001')
if len(sys.argv) != 5 or Path(sys.argv[2]) != ROOT or sys.argv[3] != 'ngu103':
    raise SystemExit('This recovery launcher is restricted to the ngu103 audit.')

limits = {key: '1' for key in (
    'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS',
    'VECLIB_MAXIMUM_THREADS', 'BLIS_NUM_THREADS', 'TF_NUM_INTRAOP_THREADS', 'TF_NUM_INTEROP_THREADS')}
os.environ.update(limits)
worker = ROOT / 'ops/gpu_health_recheck.py'
manifest = json.loads((ROOT / 'repair_import_v003/manifest.json').read_text())
fingerprint = hashlib.sha256(worker.read_bytes()).hexdigest()
if fingerprint != manifest['original_worker_sha256']:
    raise SystemExit('Original diagnostic changed; do not run this recovery.')
if sys.argv[1] == 'run':
    evidence = dict(job_id=os.environ['SLURM_JOB_ID'], thread_limits=limits,
                    original_worker_sha256=fingerprint, numerical_workload_unchanged=True)
    path = ROOT / 'repair_import_v003' / ('launcher_' + evidence['job_id'] + '.json')
    path.write_text(json.dumps(evidence, indent=2) + '\n')
runpy.run_path(str(worker), run_name='__main__')
