#!/bin/bash
set -euo pipefail
root=/data1/home/sunyiq/hpc_gpu_recheck_20261019_001
repair="$root/repair_import_v003"
old=/data1/home/sunyiq/id25_graice_author_matched_20261016_001
node=ngu103
name=ghr103r3_261024
exec 9>"$root/submission.lock"
flock -n 9 || { echo AUDIT_SUBMISSION_LOCKED; exit 70; }
test "$(tr -d '\r\n' < "$root/nodes/$node/job_id.txt")" = 246673
test ! -e "$repair/submission_intent.json"
queue=$(timeout 25 squeue -h -u sunyiq -n ghr_103_261019,ghr103r3_261024 -o '%i|%j|%T')
if test -n "$queue"; then printf '%s\n' "$queue"; echo NO_REPAIR_WHILE_AUDIT_JOB_ACTIVE; exit 71; fi
native=$(timeout 25 sacct -X -S 2026-10-23 -j 246673 --format=JobIDRaw,State,ExitCode -n -P)
printf '%s\n' "$native"
printf '%s\n' "$native" | grep -qx '246673|FAILED|124:0'
history=$(timeout 25 sacct -X -S 2026-10-24 -u sunyiq --name="$name" --format=JobIDRaw,State,ExitCode -n -P)
if test -n "$history"; then printf '%s\n' "$history"; echo EXISTING_REPAIR_HISTORY_NO_REPLAY; exit 72; fi
state=$(timeout 25 sinfo -h -N -n "$node" -o '%t' | head -n 1)
printf 'NODE=%s STATE=%s\n' "$node" "$state"
case "$state" in idle|mix|alloc) ;; *) echo NODE_NOT_SCHEDULABLE_KEEP_FAILURE; exit 73;; esac
"$old/venv/bin/python" -S - "$root" <<'PY'
import hashlib,json,shutil,sys
from pathlib import Path
root=Path(sys.argv[1]);assert str(root)=='/data1/home/sunyiq/hpc_gpu_recheck_20261019_001'
repair=root/'repair_import_v003';report=root/'nodes/ngu103/result.json';j=json.loads(report.read_text())
assert str(j['job_id'])=='246673' and j['state']=='DIAGNOSTIC_TIMEOUT' and j['state_before_timeout']=='IMPORTING_FRAMEWORK'
assert j['worker_exit_code']==124 and len(j['cards'])==4 and all(x['state']=='NOT_TESTED' for x in j['cards'])
m=json.loads((repair/'manifest.json').read_text());assert hashlib.sha256((root/'ops/gpu_health_recheck.py').read_bytes()).hexdigest()==m['original_worker_sha256']
dest=repair/'failed_attempt_246673';dest.mkdir()
for source in [report,root/'nodes/ngu103/job_id.txt',root/'nodes/ngu103/submission_intent.json',root/'nodes/ngu103/log_246673.out',root/'nodes/ngu103/log_246673.err',root/'hpc/ngu103.slurm',root/'ops/gpu_health_recheck.py']:
    assert source.is_file();shutil.copy2(source,dest/source.name)
checks={x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in dest.iterdir() if x.is_file()}
(dest/'sha256.json').write_text(json.dumps(checks,indent=2)+'\n')
print('FAILED_ATTEMPT_PRESERVED_NO_GPU_NUMERICAL_TEST_COMPLETED')
PY
printf '{"node":"ngu103","previous_job_id":"246673","reason":"IMPORTING_FRAMEWORK timeout; no GPU numerical test started","repair":"limit previously uncapped BLAS import threads to one; original numerical worker unchanged","created_utc":"%s"}\n' "$(date -u +%FT%TZ)" > "$repair/submission_intent.json"
set +e
sbatch --parsable "$repair/ngu103.slurm" > "$repair/sbatch_reply.txt" 2> "$repair/sbatch_error.txt"
code=$?
set -e
cat "$repair/sbatch_reply.txt"
cat "$repair/sbatch_error.txt"
if test "$code" -ne 0; then echo "SBATCH_FAILED=$code; intent retained"; exit "$code"; fi
job_id=$(cut -d';' -f1 "$repair/sbatch_reply.txt" | tr -d '\r\n')
case "$job_id" in ''|*[!0-9]*) echo AMBIGUOUS_REPLY_NO_REPLAY; exit 74;; esac
printf '%s\n' "$job_id" > "$repair/job_id.txt"
printf '%s\n' "$job_id" > "$root/nodes/$node/job_id.txt.pending"
mv "$root/nodes/$node/job_id.txt.pending" "$root/nodes/$node/job_id.txt"
printf '%s\t%s\t%s\n' "$(date -u +%FT%TZ)" "$node" "$job_id" >> "$root/submissions.tsv"
printf 'REPAIR_NODE_JOB=ngu103|%s\n' "$job_id"
printf 'FAILED_RESULT_JOB=246673; current result.json may still refer to old job until repaired worker starts; require matching job_id\n'
echo REPAIR_ONLY_NGU103_ORIGINAL_NUMERICAL_WORKER_AND_150_SECOND_LIMIT_UNCHANGED
