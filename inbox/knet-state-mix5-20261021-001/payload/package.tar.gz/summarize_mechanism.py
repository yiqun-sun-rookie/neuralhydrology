"""Interpret accepted saved outputs; no training, gradients, projection or gate changes."""
from pathlib import Path
import json
BASE=Path(__file__).resolve().parent
RUN=BASE/'hpc_results/runs/02092500/attempt_001'
def obj(path):return json.loads(path.read_bytes())
r=obj(BASE/'acceptance.json');comparison=obj(BASE/'两臂差异核对.json')
target=BASE/'机制判读.json'
if target.exists():
    record=obj(target);assert record['job_id']==r['job_id']
else:
    epochs={arm:[obj(p) for p in sorted((RUN/arm).glob('epoch_*.json'))] for arm in ['original','state_constrained']}
    rows=[]
    for row in epochs['state_constrained']:
        candidates=row['candidates'];paired=next((x for x in comparison['rows'] if x['step']==row['step']),None)
        rows.append(dict(step=row['step'],selected=row['accepted_label'],accepted=row['accepted'],
            parameter_changed=row['parameter_changed'],nine_gates_pass=row['post_gate']['accepted'],
            mix_entries=sum(x['kind']=='MIX' for x in candidates),
            mix_unique_real_replays=sum(x['kind']=='MIX' and 'scores' in x and 'reused_replay' not in x for x in candidates),
            mix_evaluated_entries=sum(x['kind']=='MIX' and 'scores' in x for x in candidates),
            mix_accepted=bool(row['accepted'] and row['accepted_label'].startswith('MIX_')),
            true_rejects=sum(x['status']=='TRUE_GATE_REJECT' for x in candidates),
            uncertified=sum(x['status']=='NOT_REPLAYED_UNCERTIFIED' for x in candidates),
            state_pre=row['training_pre'][8],state_post=row['training_post'][8],paired=paired))
    costs={arm:sum(x['update_wall_seconds'] for x in data) for arm,data in epochs.items()}
    record=dict(job_id=r['job_id'],technical_status=r['status'],classification=comparison['classification'],
        five_nonzero_gate_passing_steps=r['five_nonzero_gate_passing_steps'],rows=rows,
        update_wall_seconds=costs,update_wall_ratio=costs['state_constrained']/costs['original'] if costs['original'] else None,
        extra_model_calls=0,extra_qp_calls=0,scientific_gate_unchanged=True,
        state_metric_is_observed_state_error=False)
    with target.open('x',encoding='utf-8') as out:json.dump(record,out,ensure_ascii=False,indent=2)
rows=record['rows'];kind=record['classification']
complete=record['technical_status']=='ACCEPTED_CONTINUOUS_DIAGNOSTIC'
benefit=kind=='DETECTED_FINAL_STATE_IMPROVEMENT'
interpretation=('固定末步5的加雪惩罚相对同轮原版降低，且改善量超过原数值容差。' if benefit else
    '两臂全部5步参数完全相同，未显示额外状态代理收益。' if kind=='IDENTICAL_TO_ORIGINAL' else
    '固定末步5没有检测到超过原数值容差的额外加雪惩罚改善。' if complete else
    '证据未完整完成，不能作完整5步科学结论。')
lines=['## MIX实际使用与物理一致性判读','',interpretation,'',
    'S只是在预先固定的暖天、未训练原版先验无雪场景中，对归一化正向实际积雪修正的平方平均。它是一条物理一致性代理约束，没有实测雪量真值；不能把S下降写成真实状态精度提升。','',
    '| 步 | 所选候选 | MIX独立真实回放数 | MIX被接受 | 九门槛通过 | 未核证条目 | 真实拒绝条目 |',
    '|---|---|---:|:---:|:---:|---:|---:|']
for x in rows:lines.append(f'| {x["step"]} | {x["selected"] or "参数回退"} | {x["mix_unique_real_replays"]} | {x["mix_accepted"]} | {x["nine_gates_pass"]} | {x["uncertified"]} | {x["true_rejects"]} |')
if rows:
    initial=rows[0]['state_pre'];final=rows[-1]['state_post']
    increased=[x['step'] for x in rows if x['state_post']>x['state_pre']]
    lines+=['',f'新规则臂S：初始化{initial:.14g}，最后已完成步{final:.14g}；相对自身更新前上升的步骤为{increased}。这与相对同轮原版的比较分别报告。',
        f'累计MIX独立真实回放{sum(x["mix_unique_real_replays"] for x in rows)}次，MIX接受{sum(x["mix_accepted"] for x in rows)}步，回退{sum(not x["accepted"] for x in rows)}步；零位移{sum(not x["parameter_changed"] for x in rows)}步。']
costs=record['update_wall_seconds']
lines+=['',f'更新阶段原版{costs["original"]:.3f}秒，新规则{costs["state_constrained"]:.3f}秒；耗时比={record["update_wall_ratio"]}。此比值不含共同初始化及收尾；调用数相同不代表计算量相同。']
failures=[]
for path in sorted((BASE/'monitoring').glob('round_*_result.json')):
    x=obj(path)
    if x.get('status')=='MONITOR_FAILED':failures.append({k:v for k,v in x.items() if k!='current_status'})
lines+=['',f'全部监控异常窗口保留：{json.dumps(failures,ensure_ascii=False)}。','']
advice=('先核对收益发生的步骤、八项流量代价和MIX使用情况；仅在本流域/种子/5步训练范围报告物理一致性代理改善。后续如需延长或加入独立验证，另行冻结固定末轮、预算与数据使用规则。' if benefit else
    '利用已保存的候选、核证、真实门槛和参数差异，定位MIX未起作用、被拒绝或没有代理收益的原因；再提出一项明确修订。不要据此放宽九门槛、搜索比例或直接扩大训练。')
summary=('这次混合候选降低了所选场景的加雪惩罚；真实积雪是否更准仍需观测验证。' if benefit else
    '这次没有证明混合候选带来额外状态代理收益。完整保留结果，下一步先看清原因。')
report=BASE/'运行报告.md';body=report.read_text(encoding='utf-8')
if '## MIX实际使用与物理一致性判读' not in body:
    before,_=body.split('## 下一步建议\n',1)
    body=before+'\n'.join(lines)+'\n## 下一步建议\n\n'+advice+'\n\n后续实验未执行。\n\n白话总结：'+summary+'\n'
    heading,rest=body.split('\n',1)
    body=heading+'\n\n**额外收益判读：'+interpretation+'**\n'+rest
    report.write_text(body,encoding='utf-8')
    (BASE/'下一步建议.md').write_text('# 下一步建议\n\n'+advice+'\n\n后续实验未执行。\n',encoding='utf-8')
print(json.dumps(dict(status='MECHANISM_INTERPRETATION_COMPLETE',job_id=r['job_id'],classification=kind,mix_accepted_steps=sum(x['mix_accepted'] for x in rows))))
