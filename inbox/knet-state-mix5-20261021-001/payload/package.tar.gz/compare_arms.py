"""Post-acceptance interpretation only: distinguish feasibility from added benefit."""
from pathlib import Path
import json
import numpy as np
BASE=Path(__file__).resolve().parent
RUN=BASE/'hpc_results/runs/02092500/attempt_001'
r=json.loads((BASE/'acceptance.json').read_bytes())
target=BASE/'两臂差异核对.json'
if target.exists():
    record=json.loads(target.read_bytes());assert record['job_id']==r['job_id']
else:
    rows=[]
    if r['status']=='ACCEPTED_CONTINUOUS_DIAGNOSTIC':
        for step in range(1,6):
            with np.load(RUN/'original'/f'update_{step:03d}.npz',allow_pickle=False) as z:a=z['parameters'].copy()
            with np.load(RUN/'state_constrained'/f'update_{step:03d}.npz',allow_pickle=False) as z:b=z['parameters'].copy()
            old=next(x for x in r['steps'] if x['arm']=='original' and x['step']==step)
            new=next(x for x in r['steps'] if x['arm']=='state_constrained' and x['step']==step)
            tol=max(1e-10,1e-7*abs(old['scores'][8]))
            rows.append(dict(step=step,exact_same_parameters=bool(np.array_equal(a,b)),
                parameter_difference_norm=float(np.linalg.norm(b-a)),maximum_parameter_difference=float(np.max(np.abs(b-a))),
                original_state_proxy=old['scores'][8],new_state_proxy=new['scores'][8],
                state_improvement=old['scores'][8]-new['scores'][8],original_numerical_tolerance=tol,
                detected_state_improvement=bool(old['scores'][8]-new['scores'][8]>tol)))
    classification=('INCOMPLETE' if not rows else 'IDENTICAL_TO_ORIGINAL' if all(x['exact_same_parameters'] for x in rows)
                    else 'DETECTED_FINAL_STATE_IMPROVEMENT' if rows[-1]['detected_state_improvement']
                    else 'NO_DETECTED_FINAL_STATE_IMPROVEMENT')
    record=dict(job_id=r['job_id'],classification=classification,rows=rows,
        scientific_gate_unchanged=True,extra_model_calls=0,extra_qp_calls=0)
    with target.open('x',encoding='utf-8') as f:json.dump(record,f,ensure_ascii=False,indent=2)
section=['## 两臂差异与额外收益核对','',f'分类：`{record["classification"]}`。九项门槛与本轮科学验收判定均未改变。','',
    '| 步 | 与原版参数逐项相同 | 参数差L2范数 | 状态代理改善量(原版减新臂) | 改善超过原容差 |',
    '|---|:---:|---:|---:|:---:|']
for row in record['rows']:
    section.append(f'| {row["step"]} | {row["exact_same_parameters"]} | {row["parameter_difference_norm"]:.9g} | {row["state_improvement"]:.9g} | {row["detected_state_improvement"]} |')
if record['classification']=='IDENTICAL_TO_ORIGINAL':
    section+=['','两臂5步参数完全相同，因此这次连续更新可行性通过没有显示新规则的额外收益；不能将通过九门槛写成相对原版改进。']
    advice=['本轮两臂5步参数完全相同，先解释候选为何始终复制原版；仅延长相同短程不能作为新规则获益的依据。',
        '利用本轮已有梯度、候选与门槛余量，检查状态目标是否实际影响提议；若要修改候选生成机制，另行冻结一项明确修订并审核，继续保留原九门槛与失败回退。']
elif record['classification']=='NO_DETECTED_FINAL_STATE_IMPROVEMENT':
    section+=['','固定末步状态代理没有改善超过原数值容差；门槛可行性与状态改善是不同结论。']
    advice=['本轮没有检测到末步状态代理的额外改善，先利用保存轨迹分析新规则差异与额外计算成本。',
        '查清不利步骤、真实拒绝或状态目标未起作用的原因后，再冻结一项针对性候选修订；不把5步可行性直接升级成长训练成功。']
else:advice=None
text='\n'.join(section)+'\n\n'
md=BASE/'两臂差异核对.md'
if not md.exists():md.write_text(text,encoding='utf-8')
report=BASE/'运行报告.md';body=report.read_text(encoding='utf-8')
if '## 两臂差异与额外收益核对' not in body:
    before,after=body.split('## 下一步建议\n',1)
    if advice is None:body=before+text+'## 下一步建议\n'+after
    else:
        ending='\n'.join(f'{i}. {item}' for i,item in enumerate(advice,1))
        body=before+text+'## 下一步建议\n\n'+ending+'\n\n后续实验仅为建议，未执行。\n\n白话总结：这次可以连续更新，但还没有显示额外状态收益。下一步先找清原因，再决定改什么规则。\n'
        (BASE/'下一步建议.md').write_text('# 下一步建议\n\n'+ending+'\n\n后续实验未执行。\n',encoding='utf-8')
    report.write_text(body,encoding='utf-8')
print(json.dumps(dict(status='ARM_DIFFERENCE_CHECK_COMPLETE',classification=record['classification'],job_id=r['job_id'])))
