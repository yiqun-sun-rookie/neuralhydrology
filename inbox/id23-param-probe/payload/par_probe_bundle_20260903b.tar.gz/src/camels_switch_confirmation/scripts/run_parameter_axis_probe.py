"""Runner for the parameter-axis open-loop oracle kill gate (prereg section 0.5).

Pure open loop: three parFC candidates per basin are simulated with HBV-lite and
scored per segment. No filter, no assimilation, no R, no calibration, no
training. Writes only under a ``parameter_axis_probe_*`` result directory, per
prereg section 3.1.

Usage
-----
    python -m camels_switch_confirmation.scripts.run_parameter_axis_probe \
        --window main --data-root <camels_us> --out <results dir>

``--window main`` runs the 90 design basins over 1999-10-01..2008-09-30 with the
registered 1989-10-01..1999-09-30 warmup (identical to the center calibration
protocol). ``--window sub`` runs the 52 admitted basins over the development
window; because the reserved 1980-1989 record may not be touched, its warmup is
the first water year of the development window itself (registered 2026-09-02).
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import sys
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np
import pandas as pd

REPO_ROOT = Path(__file__).resolve().parents[3]
if str(REPO_ROOT / "src") not in sys.path:
    sys.path.insert(0, str(REPO_ROOT / "src"))

from camels_switch_confirmation import parameter_axis_openloop_probe as probe  # noqa: E402
from hydroagent.data_loading import load_camels_basin  # noqa: E402
from scl_hydro.hbv_lite_numpy import BOUNDS_PRESETS, simulate_hbv_lite  # noqa: E402

LAG_KERNEL = "rising"
FORCING = "maurer"
PET_METHOD = "oudin"
PARAM_NAMES = (
    "parTT", "parCFMAX", "parCFR", "parCWH", "parFC", "parBETA", "parLP",
    "parK0", "parK1", "parUZL", "parPERC", "parK2", "lag_time",
)

# Registered correction, 2026-09-02, before any run. The prereg text inherited
# "clip parFC to [50, 1000]" from the real-case protocol, whose center table is a
# *different* calibration. The center table this probe pins (531-repro,
# hbv_lite_cma_rising_local_full.csv) was calibrated in the v5 domain
# parFC in [50, 2500]: 23 of the 90 design basins have a center above 1000 and
# 11 sit at the 2500 ceiling, so clipping to [50, 1000] would clip the *center*
# and it would stop being the calibrated optimum the gate compares against.
# The candidate domain therefore follows the domain the pinned table was
# calibrated in. Clipping of the x2.0 member is still recorded per basin and
# still raises the frozen candidate_collapse flag.
FC_BOUNDS = tuple(float(x) for x in BOUNDS_PRESETS["v5"]["parFC"])

CENTER_TABLE = Path(
    "results/10_global_conceptual_model_benchmark/camels_us_531_repro_v01/"
    "summary/hbv_lite_cma_rising_local_full.csv"
)
CENTER_TABLE_SHA256 = "577b12fcb8e1a7a7a607995f0011dbda38a199ee68f3636732b80a3356c16be6"
DESIGN90_LIST = Path("docs/plans/2026-08-10-camels-parfc-state-interaction-design90-coverage-v01.csv")
ADMITTED52_LIST = Path(
    "results/23_camels_switch_confirmation/online_noise_real_obs_stage3_01_20260818_local/"
    "precheck/admission.csv"
)

# The pinned table's own calibration protocol, used as the pipeline correctness
# gate: simulate 1999-10-01..2008-09-30 from the default initial state and score
# after a 365-day internal warmup. Reproducing ``_cal_nse`` this way proves the
# HBV forward model, the Maurer/Oudin loader, the rising lag kernel and the NSE
# all match the table before any probe number is believed.
CENTER_PROTOCOL = {
    "start": "1999-10-01",
    "end": "2008-09-30",
    "internal_warmup_days": 365,
    "tolerance": 1e-3,
}

WINDOWS = {
    "main": {
        "load_start": "1989-10-01",
        "load_end": "2008-09-30",
        "score_start": "1999-10-01",
        "basins": "design90",
        "note": "in-window calibrated center; registered as a conservative (kill-leaning) bias",
    },
    "sub": {
        "load_start": "1989-10-01",
        "load_end": "1993-03-13",
        "score_start": "1990-10-01",
        "basins": "admitted52",
        "note": "out-of-window center; warmup is the first water year of the development window",
    },
}


def sha256_of(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_center_table(repo_root: Path, verify: bool = True) -> dict[str, dict]:
    path = repo_root / CENTER_TABLE
    if verify:
        actual = sha256_of(path)
        if actual != CENTER_TABLE_SHA256:
            raise SystemExit(f"center table sha256 mismatch: {actual} != {CENTER_TABLE_SHA256}")
    table: dict[str, dict] = {}
    with open(path, newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row.get("run_status") != "success":
                continue
            params = {name: float(row[f"p_{name}"]) for name in PARAM_NAMES}
            table[str(row["basin_id"]).zfill(8)] = {
                "params": params,
                "cal_nse": float(row["_cal_nse"]) if row.get("_cal_nse") else float("nan"),
            }
    return table


def load_basin_list(repo_root: Path, which: str) -> list[str]:
    if which == "design90":
        path, key = repo_root / DESIGN90_LIST, "basin_id"
        with open(path, newline="", encoding="utf-8") as handle:
            return [str(r[key]).zfill(8) for r in csv.DictReader(handle)]
    if which == "admitted52":
        path = repo_root / ADMITTED52_LIST
        with open(path, newline="", encoding="utf-8") as handle:
            return [str(r["basin_id"]).zfill(8) for r in csv.DictReader(handle)
                    if r.get("admitted", "True") == "True"]
    raise ValueError(f"unknown basin list {which!r}")


def simulate_basin(basin_id: str, data_root: Path, spec: dict, center_params: dict):
    """Open-loop simulate all three candidates; return scoring-window arrays."""
    forcing, observations, _area = load_camels_basin(
        basin_id,
        data_root=str(data_root),
        start_date=spec["load_start"],
        end_date=spec["load_end"],
        forcing=FORCING,
        pet_method=PET_METHOD,
        keep_obs_nan_days=True,
        strict_streamflow_window=True,
    )
    dates = forcing.index
    rain = forcing["prcp"].to_numpy(float)
    pet = forcing["ep"].to_numpy(float)
    temperature = forcing["tmean"].to_numpy(float)
    observed = observations.reindex(dates).to_numpy(float)

    built = probe.build_members(center_params, FC_BOUNDS)
    simulations = []
    for member in built["members"]:
        q_sim, _state = simulate_hbv_lite(rain, pet, temperature, member, lag_kernel=LAG_KERNEL)
        simulations.append(np.asarray(q_sim, dtype=float))

    score_from = int(np.searchsorted(dates.values, np.datetime64(spec["score_start"])))
    return {
        "dates": dates[score_from:],
        "observed": observed[score_from:],
        "simulations": [sim[score_from:] for sim in simulations],
        "built": built,
    }


def verify_center_protocol(basins: list[str], centers: dict, data_root: Path,
                           n_check: int = 8) -> dict:
    """Hard gate: reproduce the pinned table's own ``_cal_nse`` before trusting anything.

    Raises ``SystemExit`` if any checked basin misses by more than the registered
    tolerance, so a broken forward model or loader stops the run instead of
    quietly shifting every oracle number.
    """
    checked: list[dict] = []
    for basin_id in basins[:n_check]:
        record = centers.get(basin_id)
        if record is None or not np.isfinite(record["cal_nse"]):
            continue
        forcing, observations, _ = load_camels_basin(
            basin_id, data_root=str(data_root),
            start_date=CENTER_PROTOCOL["start"], end_date=CENTER_PROTOCOL["end"],
            forcing=FORCING, pet_method=PET_METHOD,
            keep_obs_nan_days=True, strict_streamflow_window=True,
        )
        observed = observations.reindex(forcing.index).to_numpy(float)
        q_sim, _ = simulate_hbv_lite(
            forcing["prcp"].to_numpy(float), forcing["ep"].to_numpy(float),
            forcing["tmean"].to_numpy(float), record["params"], lag_kernel=LAG_KERNEL,
        )
        warm = int(CENTER_PROTOCOL["internal_warmup_days"])
        recomputed = probe.nse(observed[warm:], np.asarray(q_sim, dtype=float)[warm:])
        checked.append({
            "basin_id": basin_id,
            "table_cal_nse": record["cal_nse"],
            "recomputed": recomputed,
            "abs_diff": abs(recomputed - record["cal_nse"]),
        })
    if not checked:
        raise SystemExit("center-protocol gate: no basin could be checked")
    worst = max(c["abs_diff"] for c in checked)
    if worst > float(CENTER_PROTOCOL["tolerance"]):
        raise SystemExit(
            f"center-protocol gate FAILED: max |diff| {worst:.6f} exceeds "
            f"{CENTER_PROTOCOL['tolerance']}; forward model or loader disagrees "
            f"with the pinned table, refusing to produce probe numbers"
        )
    return {"n_checked": len(checked), "max_abs_diff": float(worst), "detail": checked}


def run(window: str, data_root: Path, out_dir: Path, repo_root: Path,
        limit: int | None = None, verify_hash: bool = True) -> dict:
    spec = WINDOWS[window]
    centers = load_center_table(repo_root, verify=verify_hash)
    basins = load_basin_list(repo_root, spec["basins"])
    if limit:
        basins = basins[:limit]

    out_dir.mkdir(parents=True, exist_ok=True)
    gate = verify_center_protocol(basins, centers, data_root)
    print(f"[{window}] center-protocol gate PASSED: "
          f"max|diff|={gate['max_abs_diff']:.6f} over {gate['n_checked']} basins", flush=True)
    rows: list[dict] = []
    reproduction: list[dict] = []
    failures: list[dict] = []
    started = time.time()

    for index, basin_id in enumerate(basins, start=1):
        if basin_id not in centers:
            failures.append({"basin_id": basin_id, "reason": "absent from center table"})
            continue
        try:
            sim = simulate_basin(basin_id, data_root, spec, centers[basin_id]["params"])
        except Exception as error:  # noqa: BLE001 - recorded, not silently dropped
            failures.append({"basin_id": basin_id, "reason": f"{type(error).__name__}: {error}"})
            continue

        center_series = sim["simulations"][0]
        center_nse = probe.nse(sim["observed"], center_series)
        reproduction.append({
            "basin_id": basin_id,
            "window": window,
            "center_nse_recomputed": center_nse,
            "cal_nse_table": centers[basin_id]["cal_nse"],
            "abs_diff": abs(center_nse - centers[basin_id]["cal_nse"]),
            "n_days": int(len(sim["observed"])),
            "n_finite_obs": int(np.isfinite(sim["observed"]).sum()),
        })

        for scale in probe.SEGMENT_SCALES:
            for metric in ("nse", "log_nse"):
                result = probe.evaluate_basin(
                    basin_id, sim["observed"], sim["simulations"], sim["dates"],
                    window=window, scale=scale, metric=metric,
                    candidate_collapse=sim["built"]["candidate_collapse"],
                    clipped=sim["built"]["clipped"],
                    actual_fc_multipliers=sim["built"]["actual_fc_multipliers"],
                )
                rows.append(result.as_row())

        if index % 10 == 0:
            print(f"[{window}] {index}/{len(basins)} basins  "
                  f"elapsed={time.time() - started:.0f}s", flush=True)

    write_csv(out_dir / f"basin_results_{window}.csv", rows)
    write_csv(out_dir / f"calibration_reproduction_{window}.csv", reproduction)

    summary = summarize(rows, reproduction, failures, window, spec, time.time() - started)
    summary["center_protocol_gate"] = gate
    summary["fc_bounds"] = list(FC_BOUNDS)
    (out_dir / f"summary_{window}.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    return summary


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _stats(values: list[float]) -> dict:
    array = np.asarray([v for v in values if np.isfinite(v)], dtype=float)
    if array.size == 0:
        return {"n": 0}
    return {
        "n": int(array.size),
        "median": float(np.median(array)),
        "q25": float(np.percentile(array, 25)),
        "q75": float(np.percentile(array, 75)),
        "mean": float(array.mean()),
        "max": float(array.max()),
        "n_gt_0.01": int((array > 0.01).sum()),
        "n_gt_0": int((array > 0).sum()),
    }


def summarize(rows: list[dict], reproduction: list[dict], failures: list[dict],
              window: str, spec: dict, elapsed: float) -> dict:
    cells: dict[str, dict] = {}
    for scale in probe.SEGMENT_SCALES:
        for metric in ("nse", "log_nse"):
            subset = [r for r in rows if r["scale"] == scale and r["metric"] == metric]
            cells[f"{scale}|{metric}"] = {
                "oracle_gain": _stats([r["oracle_gain"] for r in subset]),
                "pick_one_gain": _stats([r["pick_one_gain"] for r in subset]),
                "switch_increment": _stats([r["switch_increment"] for r in subset]),
                "causal_regret": _stats([r["causal_regret"] for r in subset]),
                "basins_with_any_switch": int(sum(1 for r in subset if r["n_segments_switched"] > 0)),
                "n_basins": len(subset),
            }
    diffs = [r["abs_diff"] for r in reproduction if np.isfinite(r["abs_diff"])]
    return {
        "window": window,
        "spec": spec,
        "elapsed_seconds": round(elapsed, 1),
        "python": platform.python_version(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "n_basins_attempted": len(reproduction) + len(failures),
        "n_basins_scored": len(reproduction),
        "failures": failures,
        # Diagnostic only, NOT a correctness gate: the probe scores the center
        # after a long warmup from 1989-10-01, while the table's _cal_nse scores
        # after a 365-day warmup from 1999-10-01, so a small difference is
        # expected by construction. The correctness gate is center_protocol_gate.
        "probe_center_vs_table_cal_nse": {
            "n": len(diffs),
            "max_abs_diff": float(max(diffs)) if diffs else None,
            "median_abs_diff": float(np.median(diffs)) if diffs else None,
        },
        "cells": cells,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--window", choices=sorted(WINDOWS), required=True)
    parser.add_argument("--data-root", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--repo-root", default=str(REPO_ROOT))
    parser.add_argument("--limit", type=int, default=None, help="smoke-test subset size")
    parser.add_argument("--no-verify-hash", action="store_true",
                        help="skip the center-table sha256 gate (smoke tests only)")
    args = parser.parse_args(argv)

    summary = run(
        window=args.window,
        data_root=Path(args.data_root),
        out_dir=Path(args.out),
        repo_root=Path(args.repo_root),
        limit=args.limit,
        verify_hash=not args.no_verify_hash,
    )
    print(json.dumps(summary["probe_center_vs_table_cal_nse"], indent=2))
    for name, cell in summary["cells"].items():
        gain = cell["oracle_gain"]
        print(f"{name}: oracle_gain median={gain.get('median')} "
              f">0.01={gain.get('n_gt_0.01')}/{gain.get('n')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
