"""Open-loop oracle-space kill gate for the parameter-axis multicandidate probe.

Prereg: ``docs/plans/2026-09-01-parameter-axis-multicandidate-value-probe-prereg-draft-v01.md``
(section 0.5). Sections 3.1/3.2 of that plan make this file and its runner the
only writable code of this probe; the noise-axis filtering pipeline is owned by
the sister ``R perturbation`` line and is imported read-only at most.

What this module computes
-------------------------
Three candidate parameter vectors per basin (parFC scaled by 1.0 / 0.5 / 2.0,
clipped to the calibration bounds) are simulated **open loop** — plain HBV-lite,
no filter, no assimilation, no observation feedback. The scoring window is then
cut into segments (water years or 90-day blocks) and, for each segment, the
candidate with the best score on that segment is selected *with hindsight*.

That stitched series is an **upper bound**: any causal algorithm sees only the
past, so no online scheme (IMM, pruning, weighting, hard selection) can beat it.
The gate therefore reads "does switching parameters over time have any value at
all", not "does algorithm X find it".

The gain is reported in two pieces, per the prereg's anti-conflation clause:

    pick_one_gain    = best single candidate held all window - center
    switch_increment = oracle (per-segment hindsight) - best single candidate

so that "picking one better parameter" is never recorded as "switching helped".

Second readout (registered 2026-09-02 before any run): a **causal** pick-one that
may only use segments strictly before the current one, reported as regret against
the best fixed candidate. It measures "can a blind rule find the good candidate",
which is a different question from "is there anything to find".
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Iterable, Sequence

import numpy as np

# Candidate construction reuses the frozen, contract-tested ``build_bank`` rule
# (zero dependencies). It deliberately does NOT import ``real_case_candidates``:
# that module reaches ``joint_param_noise_precheck`` -> ``run_online_noise_pilot``,
# which prereg section 3.1 assigns to the sister R-perturbation line and which may
# be mid-edit in another session. ``test_parameter_axis_probe`` asserts this
# module's parameter-axis output equals ``real_case_candidates.build_candidate_grid``
# wherever that module can be imported, so the rule stays a single source of truth.
from camels_switch_confirmation.bank import build_bank

#: Adjacent-parFC spacing below this fraction of the parameter range flags a
#: collapsed candidate set. Mirrors ``real_case_candidates.COLLAPSE_SPACING_FRACTION``.
COLLAPSE_SPACING_FRACTION = 0.05

#: Minimum finite observation days for a segment to be scorable. Segments below
#: this fall back to the center candidate and are flagged, so a handful of dry
#: or gappy stretches cannot manufacture oracle gain out of 3-day NSEs.
MIN_SEGMENT_OBS_DAYS = 30

#: A trailing 90-day block shorter than this is dropped rather than scored.
MIN_TRAILING_BLOCK_DAYS = 45

BLOCK_DAYS = 90

SEGMENT_SCALES = ("water_year", "block90")


@dataclass(frozen=True)
class Segment:
    """One scoring segment: half-open index range into the scoring arrays."""

    label: str
    start: int
    stop: int

    @property
    def length(self) -> int:
        return self.stop - self.start


def build_segments(dates: Sequence, scale: str) -> list[Segment]:
    """Cut a date index into scoring segments.

    ``water_year`` segments run 1 Oct - 30 Sep and are labelled by the year they
    end in. ``block90`` segments are consecutive 90-day blocks counted from the
    first scoring day; a trailing block shorter than ``MIN_TRAILING_BLOCK_DAYS``
    is dropped so the last partial block cannot dominate the oracle.
    """
    if scale not in SEGMENT_SCALES:
        raise ValueError(f"Unknown segment scale {scale!r}; expected one of {list(SEGMENT_SCALES)}")
    n = len(dates)
    if n == 0:
        return []

    if scale == "block90":
        segments: list[Segment] = []
        for start in range(0, n, BLOCK_DAYS):
            stop = min(start + BLOCK_DAYS, n)
            if stop - start < MIN_TRAILING_BLOCK_DAYS:
                break
            segments.append(Segment(label=f"b{len(segments):03d}", start=start, stop=stop))
        return segments

    # Water years: a day belongs to the water year ending in the next calendar
    # year whenever its month is October or later.
    keys = []
    for stamp in dates:
        year = int(stamp.year) + (1 if int(stamp.month) >= 10 else 0)
        keys.append(year)
    keys_arr = np.asarray(keys)
    segments = []
    start = 0
    for i in range(1, n + 1):
        if i == n or keys_arr[i] != keys_arr[start]:
            segments.append(Segment(label=f"wy{int(keys_arr[start])}", start=start, stop=i))
            start = i
    return segments


def nse(observed: np.ndarray, simulated: np.ndarray, mask: np.ndarray | None = None) -> float:
    """Nash-Sutcliffe efficiency over the finite, masked days."""
    observed = np.asarray(observed, dtype=float)
    simulated = np.asarray(simulated, dtype=float)
    valid = np.isfinite(observed) & np.isfinite(simulated)
    if mask is not None:
        valid &= np.asarray(mask, dtype=bool)
    if int(valid.sum()) < 2:
        return float("nan")
    obs = observed[valid]
    sim = simulated[valid]
    denominator = float(np.sum((obs - obs.mean()) ** 2))
    if denominator <= 0.0:
        return float("nan")
    return float(1.0 - np.sum((obs - sim) ** 2) / denominator)


def log_nse(observed: np.ndarray, simulated: np.ndarray, mask: np.ndarray | None = None,
            epsilon: float | None = None) -> float:
    """NSE on log-transformed flows; the dry-segment companion metric.

    ``epsilon`` defaults to one hundredth of the mean finite observation, the
    common choice that keeps zero-flow days finite without dominating the sum.
    """
    observed = np.asarray(observed, dtype=float)
    simulated = np.asarray(simulated, dtype=float)
    valid = np.isfinite(observed) & np.isfinite(simulated)
    if mask is not None:
        valid &= np.asarray(mask, dtype=bool)
    if int(valid.sum()) < 2:
        return float("nan")
    obs = observed[valid]
    sim = simulated[valid]
    if epsilon is None:
        mean_obs = float(obs.mean())
        epsilon = mean_obs / 100.0 if mean_obs > 0 else 1e-3
    epsilon = max(float(epsilon), 1e-9)
    return nse(np.log(np.maximum(obs, 0.0) + epsilon), np.log(np.maximum(sim, 0.0) + epsilon))


METRICS: dict[str, Callable[..., float]] = {"nse": nse, "log_nse": log_nse}


def segment_scores(observed: np.ndarray, simulations: Sequence[np.ndarray],
                   segments: Iterable[Segment], metric: str = "nse") -> np.ndarray:
    """Score every candidate on every segment.

    Returns an array of shape ``(n_segments, n_candidates)``; a segment with
    fewer than ``MIN_SEGMENT_OBS_DAYS`` finite observations yields all-NaN.
    """
    scorer = METRICS[metric]
    segments = list(segments)
    out = np.full((len(segments), len(simulations)), np.nan, dtype=float)
    observed = np.asarray(observed, dtype=float)
    for row, seg in enumerate(segments):
        obs = observed[seg.start:seg.stop]
        if int(np.isfinite(obs).sum()) < MIN_SEGMENT_OBS_DAYS:
            continue
        for col, sim in enumerate(simulations):
            out[row, col] = scorer(obs, np.asarray(sim, dtype=float)[seg.start:seg.stop])
    return out


def choose_oracle(scores: np.ndarray, center_index: int = 0) -> np.ndarray:
    """Hindsight choice per segment: the argmax candidate, center on ties/NaN."""
    scores = np.asarray(scores, dtype=float)
    choices = np.full(scores.shape[0], int(center_index), dtype=int)
    for row in range(scores.shape[0]):
        finite = np.isfinite(scores[row])
        if not finite.any():
            continue
        best = int(np.nanargmax(scores[row]))
        # Only leave the center when the winner is strictly better, so numerical
        # ties never register as switching.
        if scores[row, best] > scores[row, int(center_index)] or not finite[int(center_index)]:
            choices[row] = best
    return choices


def choose_causal(scores: np.ndarray, center_index: int = 0) -> np.ndarray:
    """Blind choice per segment using only strictly earlier segments.

    The first segment necessarily takes the center. Later segments take the
    candidate with the best cumulative mean score so far. This is the open-loop
    stand-in for the prereg's arm (2) "causal pick-one".
    """
    scores = np.asarray(scores, dtype=float)
    n_seg, n_cand = scores.shape
    choices = np.full(n_seg, int(center_index), dtype=int)
    for row in range(1, n_seg):
        history = scores[:row]
        with np.errstate(invalid="ignore"):
            means = np.nanmean(history, axis=0) if np.isfinite(history).any() else np.full(n_cand, np.nan)
        if not np.isfinite(means).any():
            continue
        best = int(np.nanargmax(means))
        if np.isfinite(means[best]) and (not np.isfinite(means[int(center_index)])
                                         or means[best] > means[int(center_index)]):
            choices[row] = best
    return choices


def stitch(simulations: Sequence[np.ndarray], segments: Sequence[Segment],
           choices: Sequence[int], n_days: int) -> np.ndarray:
    """Splice per-segment candidate outputs into one series."""
    if len(segments) != len(choices):
        raise ValueError("segments and choices must have equal length")
    out = np.full(int(n_days), np.nan, dtype=float)
    for seg, pick in zip(segments, choices):
        out[seg.start:seg.stop] = np.asarray(simulations[int(pick)], dtype=float)[seg.start:seg.stop]
    return out


@dataclass
class BasinResult:
    """Everything one basin contributes to the gate, decomposed."""

    basin_id: str
    window: str
    scale: str
    metric: str
    n_days: int
    n_segments: int
    center: float
    pick_one: float
    pick_one_index: int
    oracle: float
    causal: float
    pick_one_gain: float
    switch_increment: float
    oracle_gain: float
    causal_regret: float
    n_segments_switched: int
    candidate_collapse: bool
    clipped_any: bool
    actual_fc_multipliers: list[float] = field(default_factory=list)
    whole_window_scores: list[float] = field(default_factory=list)
    segment_choice_counts: list[int] = field(default_factory=list)

    def as_row(self) -> dict:
        row = {k: v for k, v in self.__dict__.items() if not isinstance(v, list)}
        for i, value in enumerate(self.whole_window_scores):
            row[f"score_cand{i}"] = value
        for i, value in enumerate(self.actual_fc_multipliers):
            row[f"fc_mult{i}"] = value
        for i, value in enumerate(self.segment_choice_counts):
            row[f"oracle_picks_cand{i}"] = value
        return row


def evaluate_basin(basin_id: str, observed: np.ndarray, simulations: Sequence[np.ndarray],
                   dates: Sequence, *, window: str, scale: str, metric: str = "nse",
                   center_index: int = 0, candidate_collapse: bool = False,
                   clipped: Sequence[bool] = (), actual_fc_multipliers: Sequence[float] = ()
                   ) -> BasinResult:
    """Decompose one basin's oracle space into pick-one and switch components."""
    observed = np.asarray(observed, dtype=float)
    n_days = len(observed)
    segments = build_segments(dates, scale)
    scores = segment_scores(observed, simulations, segments, metric=metric)

    scorer = METRICS[metric]
    whole = [scorer(observed, np.asarray(sim, dtype=float)) for sim in simulations]
    center_score = float(whole[int(center_index)])
    best_fixed = int(np.nanargmax(whole)) if np.isfinite(whole).any() else int(center_index)
    pick_one_score = float(whole[best_fixed])

    oracle_choices = choose_oracle(scores, center_index=center_index)
    causal_choices = choose_causal(scores, center_index=center_index)
    oracle_score = scorer(observed, stitch(simulations, segments, oracle_choices, n_days))
    causal_score = scorer(observed, stitch(simulations, segments, causal_choices, n_days))

    counts = [int((oracle_choices == i).sum()) for i in range(len(simulations))]

    return BasinResult(
        basin_id=str(basin_id),
        window=str(window),
        scale=str(scale),
        metric=str(metric),
        n_days=int(n_days),
        n_segments=len(segments),
        center=center_score,
        pick_one=pick_one_score,
        pick_one_index=int(best_fixed),
        oracle=float(oracle_score),
        causal=float(causal_score),
        pick_one_gain=float(pick_one_score - center_score),
        switch_increment=float(oracle_score - pick_one_score),
        oracle_gain=float(oracle_score - center_score),
        causal_regret=float(pick_one_score - causal_score),
        n_segments_switched=int((oracle_choices != int(center_index)).sum()),
        candidate_collapse=bool(candidate_collapse),
        clipped_any=bool(any(clipped)),
        actual_fc_multipliers=[float(x) for x in actual_fc_multipliers],
        whole_window_scores=[float(x) for x in whole],
        segment_choice_counts=counts,
    )


def build_members(center_params: dict, fc_bounds: tuple[float, float]) -> dict:
    """Parameter-axis candidates around one calibrated center vector.

    Same rule as the frozen real-case grid, parameter axis only: members from
    ``build_bank``, post-clip actual multipliers, and the collapse flag raised
    when adjacent parFC values sit closer than 5% of the parameter range.
    """
    low, high = float(fc_bounds[0]), float(fc_bounds[1])
    center_fc = float(center_params["parFC"])
    if not (low <= center_fc <= high):
        raise ValueError(f"center parFC {center_fc} lies outside bounds [{low}, {high}]")

    members, clipped = build_bank(dict(center_params), (low, high))
    actual_multipliers = [float(member["parFC"]) / center_fc for member in members]
    fc_values = sorted(float(member["parFC"]) for member in members)
    minimum_spacing = min(b - a for a, b in zip(fc_values, fc_values[1:]))

    return {
        "members": members,
        "clipped": [bool(flag) for flag in clipped],
        "actual_fc_multipliers": actual_multipliers,
        "minimum_fc_spacing": float(minimum_spacing),
        "candidate_collapse": bool(minimum_spacing < COLLAPSE_SPACING_FRACTION * (high - low)),
    }
