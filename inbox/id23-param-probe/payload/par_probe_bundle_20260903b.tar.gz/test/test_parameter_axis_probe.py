"""Contract tests for the parameter-axis open-loop oracle probe (prereg section 0.5)."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from camels_switch_confirmation import parameter_axis_openloop_probe as probe  # noqa: E402


def _dates(start: str, days: int) -> pd.DatetimeIndex:
    return pd.date_range(start, periods=days, freq="D")


# ---------------------------------------------------------------- segmentation


def test_water_year_segments_split_on_october_first():
    dates = _dates("1999-10-01", 366 + 365)  # WY2000 (leap) + WY2001
    segments = probe.build_segments(dates, "water_year")
    assert [s.label for s in segments] == ["wy2000", "wy2001"]
    assert segments[0].start == 0
    assert dates[segments[1].start] == pd.Timestamp("2000-10-01")
    assert segments[-1].stop == len(dates)


def test_water_year_segments_cover_every_day_without_overlap():
    dates = _dates("1999-10-01", 3287)  # 1999-10-01 .. 2008-09-30
    segments = probe.build_segments(dates, "water_year")
    assert len(segments) == 9
    covered = np.zeros(len(dates), dtype=int)
    for seg in segments:
        covered[seg.start:seg.stop] += 1
    assert covered.min() == 1 and covered.max() == 1


def test_block90_drops_a_short_trailing_block():
    dates = _dates("1999-10-01", 90 * 3 + 10)
    segments = probe.build_segments(dates, "block90")
    assert len(segments) == 3
    assert all(s.length == 90 for s in segments)


def test_block90_keeps_a_long_enough_trailing_block():
    dates = _dates("1999-10-01", 90 * 2 + probe.MIN_TRAILING_BLOCK_DAYS)
    segments = probe.build_segments(dates, "block90")
    assert len(segments) == 3
    assert segments[-1].length == probe.MIN_TRAILING_BLOCK_DAYS


def test_unknown_scale_rejected():
    with pytest.raises(ValueError, match="Unknown segment scale"):
        probe.build_segments(_dates("1999-10-01", 10), "monthly")


# --------------------------------------------------------------------- metrics


def test_nse_of_a_perfect_simulation_is_one():
    obs = np.array([1.0, 5.0, 2.0, 9.0])
    assert probe.nse(obs, obs) == pytest.approx(1.0)


def test_nse_of_the_mean_is_zero():
    obs = np.array([1.0, 5.0, 2.0, 9.0])
    assert probe.nse(obs, np.full_like(obs, obs.mean())) == pytest.approx(0.0)


def test_nse_ignores_nan_observations():
    obs = np.array([1.0, np.nan, 2.0, 9.0])
    sim = np.array([1.0, 999.0, 2.0, 9.0])
    assert probe.nse(obs, sim) == pytest.approx(1.0)


def test_log_nse_is_finite_with_zero_flow_days():
    obs = np.array([0.0, 1.0, 4.0, 0.0, 2.0])
    sim = np.array([0.1, 1.1, 3.5, 0.0, 2.2])
    assert np.isfinite(probe.log_nse(obs, sim))


# ------------------------------------------------------------ oracle mechanics


def _three_candidates(n_days: int, obs: np.ndarray):
    """Candidate 0 = center, 1 wins the first half, 2 wins the second half."""
    half = n_days // 2
    center = obs + 1.0
    first = obs.copy()
    first[half:] += 5.0
    second = obs.copy()
    second[:half] += 5.0
    return [center, first, second]


def test_oracle_selects_the_segment_winner():
    dates = _dates("1999-10-01", 360)
    rng = np.random.default_rng(0)
    obs = rng.gamma(2.0, 1.0, size=360)
    sims = _three_candidates(360, obs)
    segments = probe.build_segments(dates, "block90")
    scores = probe.segment_scores(obs, sims, segments)
    choices = probe.choose_oracle(scores)
    assert list(choices) == [1, 1, 2, 2]


def test_stitch_takes_each_segment_from_its_chosen_candidate():
    dates = _dates("1999-10-01", 360)
    sims = [np.zeros(360), np.ones(360), np.full(360, 2.0)]
    segments = probe.build_segments(dates, "block90")
    out = probe.stitch(sims, segments, [0, 1, 2, 1], 360)
    assert out[0] == 0.0 and out[90] == 1.0 and out[180] == 2.0 and out[270] == 1.0
    assert np.isfinite(out).all()


def test_stitch_rejects_mismatched_lengths():
    segments = probe.build_segments(_dates("1999-10-01", 180), "block90")
    with pytest.raises(ValueError, match="equal length"):
        probe.stitch([np.zeros(180)], segments, [0], 180)


def test_gain_decomposition_is_an_identity():
    dates = _dates("1999-10-01", 360)
    rng = np.random.default_rng(1)
    obs = rng.gamma(2.0, 1.0, size=360)
    sims = _three_candidates(360, obs)
    result = probe.evaluate_basin("test", obs, sims, dates, window="w", scale="block90")
    assert result.oracle_gain == pytest.approx(result.pick_one_gain + result.switch_increment)


def test_oracle_is_an_upper_bound_on_pick_one_and_center():
    dates = _dates("1999-10-01", 720)
    rng = np.random.default_rng(2)
    obs = rng.gamma(2.0, 1.0, size=720)
    sims = _three_candidates(720, obs)
    result = probe.evaluate_basin("test", obs, sims, dates, window="w", scale="water_year")
    assert result.oracle >= result.pick_one - 1e-9
    assert result.oracle >= result.center - 1e-9
    assert result.causal <= result.oracle + 1e-9


def test_segment_with_too_few_observations_falls_back_to_center():
    dates = _dates("1999-10-01", 180)
    obs = np.full(180, np.nan)
    # Second block keeps only 20 finite days, below MIN_SEGMENT_OBS_DAYS.
    obs[:110] = np.linspace(1.0, 5.0, 110)
    sims = [np.full(180, 3.0), np.zeros(180), np.full(180, 99.0)]
    segments = probe.build_segments(dates, "block90")
    scores = probe.segment_scores(obs, sims, segments)
    assert np.isnan(scores[1]).all()
    assert probe.choose_oracle(scores)[1] == 0


# ------------------------------------------------------------- causal blindness


def test_causal_choice_never_looks_ahead():
    # Candidate 2 is terrible early and excellent late. A causal rule must not
    # pick it before it has any history of being good.
    scores = np.array([
        [0.5, 0.4, -9.0],
        [0.5, 0.4, -9.0],
        [0.5, 0.4, 9.0],
        [0.5, 0.4, 9.0],
    ])
    choices = probe.choose_causal(scores)
    assert choices[0] == 0  # first segment has no history at all
    assert choices[1] == 0
    assert choices[2] == 0  # history so far still says candidate 2 is bad
    assert choices[3] == 0  # cumulative mean of 2 is still below the center


def test_causal_choice_switches_once_history_supports_it():
    scores = np.array([
        [0.1, 0.9, 0.0],
        [0.1, 0.9, 0.0],
        [0.1, 0.9, 0.0],
    ])
    choices = probe.choose_causal(scores)
    assert choices[0] == 0
    assert list(choices[1:]) == [1, 1]


def test_causal_regret_is_non_negative_against_the_best_fixed_candidate():
    dates = _dates("1999-10-01", 720)
    rng = np.random.default_rng(3)
    obs = rng.gamma(2.0, 1.0, size=720)
    sims = _three_candidates(720, obs)
    result = probe.evaluate_basin("t", obs, sims, dates, window="w", scale="water_year")
    assert result.causal_regret >= -1e-9


# --------------------------------------------------------------- candidate grid


def test_members_reuse_the_frozen_candidate_rule():
    center = {
        "parTT": 0.0, "parCFMAX": 3.0, "parCFR": 0.05, "parCWH": 0.1,
        "parFC": 400.0, "parBETA": 2.0, "parLP": 0.6, "parK0": 0.3,
        "parK1": 0.1, "parUZL": 30.0, "parPERC": 2.0, "parK2": 0.05,
        "lag_time": 2.0,
    }
    built = probe.build_members(center, (50.0, 1000.0))
    assert [m["parFC"] for m in built["members"]] == [400.0, 200.0, 800.0]
    assert built["actual_fc_multipliers"] == pytest.approx([1.0, 0.5, 2.0])
    assert built["candidate_collapse"] is False
    for member in built["members"]:
        for name, value in center.items():
            if name != "parFC":
                assert member[name] == value


def test_members_match_the_real_case_grid_on_the_parameter_axis():
    """Equivalence with the frozen 3x3 builder, which this module must not import.

    ``real_case_candidates`` transitively imports the sister line's filtering
    pipeline, so the probe re-implements the parameter axis; this test is the
    guard that the two rules never diverge.
    """
    real_case = pytest.importorskip("camels_switch_confirmation.real_case_candidates")
    base = {
        "parTT": 0.0, "parCFMAX": 3.0, "parCFR": 0.05, "parCWH": 0.1,
        "parFC": 400.0, "parBETA": 2.0, "parLP": 0.6, "parK0": 0.3,
        "parK1": 0.1, "parUZL": 30.0, "parPERC": 2.0, "parK2": 0.05,
        "lag_time": 2.0,
    }
    for par_fc, bounds in ((400.0, (50.0, 1000.0)), (600.0, (50.0, 1000.0)),
                           (980.0, (50.0, 1000.0)), (60.0, (50.0, 1000.0)),
                           (1800.0, (50.0, 2500.0)), (2500.0, (50.0, 2500.0))):
        center = dict(base, parFC=par_fc)
        mine = probe.build_members(center, bounds)
        theirs = real_case.build_candidate_grid(center, fc_bounds=bounds)
        assert [m["parFC"] for m in mine["members"]] == [m["parFC"] for m in theirs["members"]]
        assert mine["clipped"] == theirs["clipped"]
        assert mine["actual_fc_multipliers"] == pytest.approx(theirs["actual_fc_multipliers"])
        assert mine["candidate_collapse"] == theirs["candidate_collapse"]
        assert mine["minimum_fc_spacing"] == pytest.approx(theirs["minimum_fc_spacing"])


def test_center_outside_bounds_is_rejected():
    center = {"parFC": 30.0}
    with pytest.raises(ValueError, match="center parFC"):
        probe.build_members(center, (50.0, 1000.0))
