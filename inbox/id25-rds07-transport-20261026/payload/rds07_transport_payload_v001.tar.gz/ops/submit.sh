#!/bin/bash
set -euo pipefail
root=/data1/home/sunyiq/id25_regional_transport_rds07_20261026_001
exec 9>"$root/submit.lock"
flock -n 9
active=$(timeout 30 squeue -h -u sunyiq -n id25_rds07_261026 -o '%i|%j|%T')
test -z "$active"
test ! -e "$root/submission_intent.initial"
test ! -e "$root/job_id.txt"
date -Is > "$root/submission_intent.initial"
submitted=$(sbatch --parsable "$root/hpc/train.slurm")
job=${submitted%%;*}
case "$job" in ''|*[!0-9]*) echo UNRESOLVED_SUBMISSION_RESPONSE; exit 1 ;; esac
printf '%s\n' "$job" > "$root/job_id.txt"
printf '%s\t%s\tinitial\n' "$(date -Is)" "$job" >> "$root/submissions.tsv"
printf 'SUBMITTED_JOB=%s\n' "$job"
