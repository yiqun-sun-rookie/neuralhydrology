# RDS07 transport-memory minimal implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. The existing isolated worktree is used; user instruction is to finish the authorized work without excessive testing. Independent novelty review is a separate reviewer responsibility.

**Goal:** 实现并在独立查新/设计审核允许时执行一次有界的真实TWS可行性比较，回答“通量携带的历史是否比同参数量自由历史更有用”。

**Architecture:** 原RDS01三水库负责水量；一个8单元LSTM生成4维入水编码，编码库存随同一水量通量更新，前一日三库平均编码调节三个时间尺度的有界相对倍率。匹配对照使用同一网络和读出头，但读取最近三个时刻的自由编码。

**Tech Stack:** 原PyTorch/NumPy环境、4 CPU、单个Slurm作业依次执行两臂；独立根及信箱。旧模型、环境、输入只读。

## Global constraints

- 原草案 `draft/2026-10-25-id25-flux-transported-memory-rds07-concept-v1.md` 保留；本计划明确其未定执行细节。
- 独立查新未通过前 `scientific_execution_allowed=false`。允许准备实现和人工数组正确性检查；训练必须满足审核门槛。
- 有限检索只能支持“在明确检索范围未找到同一机制”；绝不宣称证明全球无人做过。若有直接同一先例或关键证据不足，保留实现、停止科学提交并交付原因。
- 实验ID `RDS07_TRANSPORT_MEMORY_PILOT_20261026`；只有 `transport`、`direct_history` 两臂，一次seed、无搜索或负结果加码。
- 119区全保留，原1998-08-01至2008-12-31连续历史，原2002—2007拟合窗口，2008选择窗口。
- 只读取RDS01原 `inputs/inputs.npz`、`transforms.json`、`input_receipt.json`；不得打开2009—2010或流量。
- 原输入仍为 `legacy_proxy_development`，不能以新结构提升输入认证等级。
- 固定RDS01、C01(LSTM)为既有参照，不重新训练、推理或重计分；本次不报告119区开发应用胜区变化。
- 每臂20个完整历史反传更新，seed20261012，Adam0.02、clip10，float32，4 CPU，单作业上限2小时；没有早停择优延长或新增种子。
- 技术失败恢复只接续累计计数、同代码/配置/输入，不能把不改善解释成技术失败。

## Frozen mechanism and comparator

1. 原静态网络和需求网络先构造，参数及初值顺序保持；雪、快、慢初始水量来自原静态网络，初始编码库存为0。
2. 原始forcing顺序为P、辐射、SWE、Tmax、Tmin、蒸气压。LSTM输入仅 `[log1p(P)/3, standardized((Tmax+Tmin)/2), standardized(radiation), standardized(vapor_pressure), standardized_static_7]`。后三个气象标准化使用冻结RDS01转换器；固定P变换不估计新参数，不使用SWE。
3. 单层LSTM hidden8，初始h/c=0；`e=tanh(Linear(8,4)(h))`。输入4+7=11。
4. 两臂共用完全相同的初始化和可训练参数集合。`Linear(12,3)`读出权重/偏置置零；a=2*tanh(readout)。候选输入前一日三库z；对照输入最近三天自由e，缺失历史补0。对照也只能读截至前一天的编码，避免当天信息时序混淆。
5. 三时间尺度 `tf=1+softplus(raw_f)*exp(a_f)`、`tr=1+softplus(raw_r)*exp(a_r)`、`tg=tf+1+softplus(raw_g)*exp(a_g)`，率为 `-expm1(-1/tau)`。零读出嵌套RDS01前向映射。
6. 每子步骤以当时供水量求z；雪加P_s e后融雪携带雪z，液雨携带e入快库，快蒸发/快出流/补给依次携带快z，补给入慢库后慢蒸发/慢出流携带慢z。空库z=0。分母仅对空库替换为1避免0/0，正库存不加epsilon，避免人为稀释。
7. z前日读出避免代数循环。使用原日均总水量与GRACE投影；编码不加入TWS。
8. 两臂各1187参数：原440+LSTM672+编码36+读出39；实际实例化核对。自由三滞后对照和输运输入有不同归纳偏置，参数相同不代表所有有效函数空间完全相同。

## Outcome and selection

- 每步只用拟合窗口合并MSE反传。用固定观测mask，预测非有限直接失败，禁止删除区域。
- epoch0仅保存初始化诊断，不参加选轮；固定epoch20是主要比较终点；epoch1…20的best仅保存为选轮诊断，不据此排名。
- 每臂原子last保存当前model、optimizer、epoch、optimizer_steps、所有RNG、config/input/code身份及独立clone的best bundle。best丢失从last恢复。20轮完成后冻结selection，以固定epoch20权重导出截至2008的验证输出；冻结后禁止再次拟合。
- 技术可行：20次更新完整、loss/gradient/权重/库存有限，非零编码器梯度在首个零读出步之后出现，物理水量S>=-1e-5mm（代码库存M允许有符号）、日水量平衡残差<=1e-3mm、平均编码幅度<=1+1e-4，逐代码通道收支残差<=1e-3，原生Slurm COMPLETED/0:0。
- 开发集架构优势信号：候选2008合并RMSE低于匹配对照，且候选逐区RMSE严格改善至少60/119；同时完整列出改善/恶化区数与误差差值，阈值不是统计显著性。
- 固定参照：RDS01现存2008 RMSE4.485342502593994；C01现存best_val_mse_cm2=12.901087863337429，需先源代码确认同口径才展示sqrt值，否则标“不同选择口径，未比较”。只读取已存标量，不重计分。
- 必须标注候选20轮而RDS01原80轮、C01原114轮（best84），不称预算匹配胜出。小验证失败只说明本固定预算未见增益，不证明所有同类结构无效。
- 不报告2009—2010收益、不将日分量视作独立验证、不开展洪水预报。

## Task 1: scoped model and meaningful small-array checks

**Files:** Create `src/25_global_flood_hierarchy/id25/regional_transport_memory.py`; create `src/25_global_flood_hierarchy/scripts/check_regional_transport_memory.py`.

**Interfaces:** `RegionalTransportMemory(statics_size, dynamic_mean, dynamic_scale, mode)` returns `(daily_mean, final_state_dict, states, fluxes, codes, code_residuals)`; `mode` must be transport/direct_history. `initial` carries all water, inventory, LSTM and lag states for exact continuation.

- [ ] 实现上述逐日顺序和原供水限制，复用原RegionalDailyStorage两个网络定义。
- [ ] 一次人工小数组检查覆盖：(a)零读出与原模型状态/通量一致；(b)非零读出、空库和融雪下守恒、编码界、整段/分段继续一致；(c)非退化读出与编码器梯度通路、相同初值和1187参数。
- [ ] 仅失败才修复重跑；成功后不扩大测试面、不运行旧科学模型完整历史。

## Task 2: frozen pilot runner and delivery

**Files:** Create `src/25_global_flood_hierarchy/scripts/run_regional_transport_pilot.py`; config `src/25_global_flood_hierarchy/configs/regional_transport_rds07_pilot_20261026.json`; output root `results/25_global_flood_hierarchy/regional_transport_rds07_20261026_001`.

**Interfaces:** `--config PATH --inputs-dir PATH --output PATH`; runner rejects missing Slurm compute-node identity for real input. New output root contains per-arm checkpoint, metrics, selection, report and validation arrays; combined report and full119-row comparison. Runtime receipt includes hostname/job/native time and fingerprints.

- [ ] 每臂分别seed reset，按同mask和中心化拟合；确认数据区域和日期身份及原SHA。
- [ ] 严格20累计步、原子last/best束及冻结选择；导出固定epoch20终点，不触及2009—2010。
- [ ] 产生技术可行/初步信号/未改善三者分开的结论；固定基线预算差异明示。

## Task 3: one authorized execution and closeout

**Files:** New task-scoped helper `scripts/id25_transport_hpc_mailbox.py`; isolated local `mailbox/`, `staging_v001/`; HPC root `/data1/home/sunyiq/id25_regional_transport_rds07_20261026_001`; channel `id25-rds07-transport-20261026`.

- [ ] 等独立审核结论，修正具体P1/P2；记录审核文本和源代码指纹，不能自称审核者确认了未看的改动。
- [ ] 科学门槛满足时封装；既有输入只读链接，环境只读，单作业4CPU/2小时，分区hgpu2p,hcpu48y、无GPU申请。新根/意图/精确队列保护，禁止重复提交。
- [ ] snapshot核对该新信箱最新seq/上个完整exit；一次提交后只查询同号。排队不是失败，不进行硬件预检。
- [ ] 完成后验收原生Slurm和程序双完成、20+20更新、FROZEN选择；取回本新根结果与完整回执。若排队需下一轮接续，显式报告已提交与未开始，不冒称完成实验。
- [ ] 旧GPU复核的停止/取消单独按用户答复收尾，已有4节点12卡证据保留，与RDS07结果无关。

## Progress

原审阅版本保留；独立审核完成，R1至R4已落实。仅授权本协议一次20+20步开发试验。


## 2026-10-26 独立审核响应（R1–R4，执行版）

- R1：主比较固定第20步；best仅诊断，不重建best、不挑选结果。
- R2：结论仅为这两个架构的开发集优势信号。对照改变历史聚合方式，不是纯输运因果消融；2008已参与开发，不作独立泛化结论。
- R3：M允许正负；小数组已检查逐通道收支、排空M=0，另用两日人工例证明融雪携带旧雪编码，不能换成当天编码。实际运行检查水量与代码收支和有限性。
- R4：自由LSTM h/c仍保留历史；被水路径约束的是进入通量读出的编码库存。相对倍率有界，绝对可训练时间尺度不保证全局上界。
- 查新仅支持在已查近邻中未发现相同完整组合，不保证世界上无人做过。独立报告是设计审核，不冒称审过新增实现。
- 单作业2小时总预算，4CPU、16GiB、无GPU；到时未完成即报告预算内未完成，不无限延时。数据只在Slurm计算节点读取；不使用G15或AutoDL。
