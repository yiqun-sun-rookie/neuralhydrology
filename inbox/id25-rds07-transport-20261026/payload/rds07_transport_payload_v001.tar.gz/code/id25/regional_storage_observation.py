"""Saved GRACE-window projection and fit-reference anomaly convention."""
import torch


def project_storage(daily_mean_mm, sampling_weights, spatial_weights=None):
    spatial = daily_mean_mm if spatial_weights is None else daily_mean_mm @ spatial_weights.T
    return 0.1 * (sampling_weights @ spatial)


def center_on_fit_windows(prediction_cm, observation_cm, fit_mask):
    valid = fit_mask[:, None] & torch.isfinite(observation_cm)
    count = valid.sum(0)
    if torch.any(count == 0):
        raise ValueError("Every region requires a valid fit reference")
    p_ref = torch.where(valid, prediction_cm, 0).sum(0) / count
    y_ref = torch.where(valid, observation_cm, 0).sum(0) / count
    return prediction_cm - p_ref, observation_cm - y_ref, p_ref, y_ref, valid
