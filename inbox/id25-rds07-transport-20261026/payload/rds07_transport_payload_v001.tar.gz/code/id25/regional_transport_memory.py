"""RDS07: signed history inventories transported by conservative water fluxes."""
from typing import Dict, List, Optional

import torch
from torch import Tensor, nn
from torch.nn import functional as F

from id25.regional_daily_storage import RegionalDailyStorage


@torch.jit.script
def average_code(water: Tensor, inventory: Tensor):
    denominator = torch.where(water > 0, water, torch.ones_like(water))
    return torch.where((water > 0).unsqueeze(-1), inventory / denominator.unsqueeze(-1),
                       torch.zeros_like(inventory))


@torch.jit.script
def withdraw(water: Tensor, inventory: Tensor, amount: Tensor):
    carried = amount.unsqueeze(-1) * average_code(water, inventory)
    remaining = water - amount
    updated = torch.where((remaining > 0).unsqueeze(-1), inventory - carried,
                          torch.zeros_like(inventory))
    return remaining, updated, carried


@torch.jit.script
def transport_scan(precip: Tensor, temp: Tensor, demand: Tensor, raw: Tensor,
                   encodings: Tensor, water: Tensor, inventory: Tensor, lag: Tensor,
                   read_weight: Tensor, read_bias: Tensor, transported: bool, record: bool):
    means = torch.jit.annotate(List[Tensor], [])
    states = torch.jit.annotate(List[Tensor], [])
    fluxes = torch.jit.annotate(List[Tensor], [])
    codes = torch.jit.annotate(List[Tensor], [])
    code_residuals = torch.jit.annotate(List[Tensor], [])
    partition = torch.sigmoid(-temp)
    potential_melt = torch.relu(temp) * F.softplus(raw[:, 0])
    gamma = torch.sigmoid(raw[:, 4])
    for day in range(precip.size(0)):
        previous = water.sum(-1)
        previous_inventory = inventory.sum(1)
        feature = average_code(water, inventory) if transported else lag
        a = 2 * torch.tanh(F.linear(feature.flatten(1), read_weight, read_bias))
        tf = 1 + F.softplus(raw[:, 1]) * torch.exp(a[:, 0])
        tr = 1 + F.softplus(raw[:, 2]) * torch.exp(a[:, 1])
        tg = tf + 1 + F.softplus(raw[:, 3]) * torch.exp(a[:, 2])
        kf, kr, kg = -torch.expm1(-1 / tf), -torch.expm1(-1 / tr), -torch.expm1(-1 / tg)
        snow, fast, slow = water[:, 0], water[:, 1], water[:, 2]
        ms, mf, mg = inventory[:, 0], inventory[:, 1], inventory[:, 2]
        e = encodings[day]
        ps = precip[day] * partition[day]
        available = snow + ps
        ms = ms + ps.unsqueeze(-1) * e
        melt = torch.minimum(available, potential_melt[day])
        snow, ms, melt_code = withdraw(available, ms, melt)
        u = fast + precip[day] - ps + melt
        mf = mf + (precip[day] - ps).unsqueeze(-1) * e + melt_code
        ef = torch.minimum(u, demand[day])
        u1, mf, ef_code = withdraw(u, mf, ef)
        qf = kf * u1
        u2, mf, qf_code = withdraw(u1, mf, qf)
        recharge = kr * u2
        fast, mf, recharge_code = withdraw(u2, mf, recharge)
        v = slow + recharge
        mg = mg + recharge_code
        eg = torch.minimum(v, gamma * torch.relu(demand[day] - ef))
        v1, mg, eg_code = withdraw(v, mg, eg)
        qg = kg * v1
        slow, mg, qg_code = withdraw(v1, mg, qg)
        water = torch.stack([snow, fast, slow], dim=1)
        inventory = torch.stack([ms, mf, mg], dim=1)
        lag = torch.stack([e, lag[:, 0], lag[:, 1]], dim=1)
        means.append((previous + water.sum(-1)) * .5)
        if record:
            states.append(water)
            fluxes.append(torch.stack([melt, ef + eg, qf + qg, recharge], dim=-1))
            codes.append(average_code(water, inventory))
            code_residuals.append(inventory.sum(1) - previous_inventory - precip[day].unsqueeze(-1) * e
                                  + ef_code + qf_code + eg_code + qg_code)
    if record:
        return (torch.stack(means), water, inventory, lag, torch.stack(states), torch.stack(fluxes),
                torch.stack(codes), torch.stack(code_residuals))
    empty = water.new_empty((0,))
    return torch.stack(means), water, inventory, lag, empty, empty, empty, empty


class RegionalTransportMemory(RegionalDailyStorage):
    """Equal allocated capacity for transport and three-lag free-history arms."""

    def __init__(self, static_size, dynamic_mean, dynamic_scale, mode="transport"):
        super().__init__(static_size, dynamic_mean, dynamic_scale)
        if mode not in ("transport", "direct_history"):
            raise ValueError("Unknown history mode")
        self.mode = mode
        self.encoder = nn.LSTM(static_size + 4, 8)
        self.code_head = nn.Linear(8, 4)
        self.rate_head = nn.Linear(12, 3)
        with torch.no_grad():
            self.rate_head.weight.zero_()
            self.rate_head.bias.zero_()

    def forward(self, forcing: Tensor, statics: Tensor, initial: Optional[Dict[str, Tensor]] = None,
                record: bool = False):
        temp = (forcing[:, :, 3] + forcing[:, :, 4]) * .5
        dynamic = torch.stack([temp, forcing[:, :, 1], forcing[:, :, 5]], dim=-1)
        dynamic = (dynamic - self.dynamic_mean) / self.dynamic_scale
        static_days = statics.unsqueeze(0).expand(forcing.size(0), -1, -1)
        demand = F.softplus(self.demand_net(torch.cat([dynamic, static_days], dim=-1))).squeeze(-1)
        features = torch.cat([torch.log1p(forcing[:, :, :1]) / 3, dynamic, static_days], dim=-1)
        raw = self.static_net(statics)
        if initial is None:
            _, water = self.initialize(statics)
            inventory = water.new_zeros((water.size(0), 3, 4))
            lag = torch.zeros_like(inventory)
            hidden, cell = water.new_zeros((1, water.size(0), 8)), water.new_zeros((1, water.size(0), 8))
        else:
            water, inventory, lag = initial["water"], initial["inventory"], initial["lag"]
            hidden, cell = initial["hidden"], initial["cell"]
        encoded, (hidden, cell) = self.encoder(features, (hidden, cell))
        encodings = torch.tanh(self.code_head(encoded))
        daily, water, inventory, lag, states, fluxes, codes, residuals = transport_scan(
            forcing[:, :, 0], temp, demand, raw, encodings, water, inventory, lag,
            self.rate_head.weight, self.rate_head.bias, self.mode == "transport", record)
        final = {"water": water, "inventory": inventory, "lag": lag, "hidden": hidden, "cell": cell}
        return daily, final, states, fluxes, codes, residuals
