"""Daily conservative snow, fast-water and slow-water regional model (mm)."""
from typing import List, Optional

import torch
from torch import Tensor, nn
from torch.nn import functional as F


@torch.jit.script
def storage_scan(precip: Tensor, temp: Tensor, demand: Tensor, params: Tensor,
                 initial: Tensor, record: bool = False):
    snow, fast, slow = initial[:, 0], initial[:, 1], initial[:, 2]
    means = torch.jit.annotate(List[Tensor], [])
    states = torch.jit.annotate(List[Tensor], [])
    fluxes = torch.jit.annotate(List[Tensor], [])
    melt_c, kf, kr, kg, gamma = (params[:, 0], params[:, 1], params[:, 2],
                               params[:, 3], params[:, 4])
    partition = torch.sigmoid(-temp)
    potential_melt = torch.relu(temp) * melt_c
    for day in range(precip.size(0)):
        previous = snow + fast + slow
        ps = precip[day] * partition[day]
        available = snow + ps
        melt = torch.minimum(available, potential_melt[day])
        snow = available - melt
        u = fast + precip[day] - ps + melt
        ef = torch.minimum(u, demand[day])
        u1 = u - ef
        qf = kf * u1
        recharge = kr * (u1 - qf)
        fast = u1 - qf - recharge
        v = slow + recharge
        eg = torch.minimum(v, gamma * torch.relu(demand[day] - ef))
        qg = kg * (v - eg)
        slow = v - eg - qg
        means.append((previous + snow + fast + slow) * 0.5)
        if record:
            states.append(torch.stack([snow, fast, slow], dim=-1))
            fluxes.append(torch.stack([melt, ef + eg, qf + qg, recharge], dim=-1))
    final = torch.stack([snow, fast, slow], dim=-1)
    if record:
        return torch.stack(means), final, torch.stack(states), torch.stack(fluxes)
    return torch.stack(means), final, initial.new_empty((0,)), initial.new_empty((0,))


class RegionalDailyStorage(nn.Module):
    def __init__(self, static_size: int, dynamic_mean, dynamic_scale):
        super().__init__()
        self.static_net = nn.Sequential(nn.Linear(static_size, 16), nn.Tanh(), nn.Linear(16, 7))
        self.demand_net = nn.Sequential(nn.Linear(static_size + 3, 16), nn.Tanh(), nn.Linear(16, 1))
        self.register_buffer("dynamic_mean", torch.as_tensor(dynamic_mean, dtype=torch.float32))
        self.register_buffer("dynamic_scale", torch.as_tensor(dynamic_scale, dtype=torch.float32))
        # Day-scale initialization: melt=3, tau_f=10, tau_r=60, tau_g=130,
        # gamma=.3, initial fast=20 and slow=200 mm. These remain learnable.
        with torch.no_grad():
            self.static_net[-1].weight.zero_()
            self.static_net[-1].bias.copy_(torch.tensor([
                2.9489308, 9.0, 59.0, 119.0, -0.84729786, 20.0, 200.0]))
            self.demand_net[-1].weight.zero_()
            self.demand_net[-1].bias.fill_(1.8545865)

    def initialize(self, statics: Tensor):
        raw = self.static_net(statics)
        tf = 1 + F.softplus(raw[:, 1])
        tr = 1 + F.softplus(raw[:, 2])
        tg = tf + 1 + F.softplus(raw[:, 3])
        params = torch.stack([F.softplus(raw[:, 0]), -torch.expm1(-1 / tf),
                              -torch.expm1(-1 / tr), -torch.expm1(-1 / tg),
                              torch.sigmoid(raw[:, 4])], dim=-1)
        initial = torch.stack([torch.zeros_like(tf), F.softplus(raw[:, 5]),
                               F.softplus(raw[:, 6])], dim=-1)
        return params, initial

    def forward(self, forcing: Tensor, statics: Tensor, initial: Optional[Tensor] = None,
                record: bool = False):
        # Raw forcing order: precipitation, radiation, SWE, Tmax, Tmin, vapor pressure.
        temp = (forcing[:, :, 3] + forcing[:, :, 4]) * 0.5
        dynamic = torch.stack([temp, forcing[:, :, 1], forcing[:, :, 5]], dim=-1)
        dynamic = (dynamic - self.dynamic_mean) / self.dynamic_scale
        static_days = statics.unsqueeze(0).expand(forcing.size(0), -1, -1)
        demand = F.softplus(self.demand_net(torch.cat([dynamic, static_days], dim=-1))).squeeze(-1)
        params, configured_initial = self.initialize(statics)
        return storage_scan(forcing[:, :, 0], temp, demand, params,
                            configured_initial if initial is None else initial, record)
