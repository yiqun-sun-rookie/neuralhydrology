"""One bounded artificial-array correctness check; no scientific files read."""
import json
from pathlib import Path
import sys

import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from id25.regional_daily_storage import RegionalDailyStorage
from id25.regional_transport_memory import RegionalTransportMemory, average_code, withdraw, transport_scan


def main():
    torch.set_num_threads(1)
    torch.manual_seed(20261012)
    base = RegionalDailyStorage(7, [0., 0., 0.], [1., 1., 1.])
    torch.manual_seed(20261012)
    model = RegionalTransportMemory(7, [0., 0., 0.], [1., 1., 1.])
    torch.manual_seed(20261012)
    control = RegionalTransportMemory(7, [0., 0., 0.], [1., 1., 1.], "direct_history")
    assert sum(p.numel() for p in model.parameters()) == 1187
    for key, value in model.state_dict().items():
        assert torch.equal(value, control.state_dict()[key])
    for key, value in base.state_dict().items():
        assert torch.equal(value, model.state_dict()[key])
    forcing = torch.zeros(12, 3, 6)
    forcing[:, :, 0] = torch.tensor([0., 2., 5., 0., 8., 1., 4., 0., 3., 6., 2., 1.])[:, None]
    forcing[:, :, 3] = torch.linspace(-4, 6, 12)[:, None]
    forcing[:, :, 4] = forcing[:, :, 3] - 2
    forcing[:, :, 1] = .7
    forcing[:, :, 5] = .4
    statics = torch.arange(21, dtype=torch.float32).reshape(3, 7) / 21
    old = base(forcing, statics, record=True)
    new = model(forcing, statics, record=True)
    for left, right in [(old[0], new[0]), (old[1], new[1]["water"]), (old[2], new[2]), (old[3], new[3])]:
        torch.testing.assert_close(left, right, atol=2e-5, rtol=1e-6)
    with torch.no_grad():
        model.rate_head.weight.copy_(torch.linspace(-.2, .2, 36).reshape(3, 12))
    daily, final, states, fluxes, codes, residuals = model(forcing, statics, record=True)
    _, init = model.initialize(statics)
    previous = torch.cat([init.sum(-1)[None], states[:-1].sum(-1)])
    balance = states.sum(-1) - previous - forcing[:, :, 0] + fluxes[:, :, 1] + fluxes[:, :, 2]
    assert states.min() >= 0 and codes.abs().max() <= 1.0001
    assert balance.abs().max() <= 1e-3 and residuals.abs().max() <= 1e-3
    a = model(forcing[:5], statics, record=True)
    b = model(forcing[5:], statics, initial=a[1], record=True)
    torch.testing.assert_close(torch.cat([a[0], b[0]]), daily, atol=2e-5, rtol=1e-6)
    for key in final:
        torch.testing.assert_close(b[1][key], final[key], atol=2e-5, rtol=1e-6)
    water = torch.tensor([0., 2., 5.])
    inventory = torch.tensor([[0., 0., 0., 0.], [1., -1., .4, -.2], [-2., 3., -1., .7]])
    remain, saved, removed = withdraw(water, inventory, water)
    assert torch.count_nonzero(remain) == 0 and torch.count_nonzero(saved) == 0
    torch.testing.assert_close(saved + removed, inventory)
    assert torch.count_nonzero(average_code(remain, saved)) == 0
    # Independent donor oracle: day-two melt retains day-one snowfall's code,
    # even though today's encoder emits its opposite and there is no new rain.
    old_code = torch.tensor([.2, -.4, .6, -.8])
    snow_case = transport_scan(torch.tensor([[10.], [0.]]), torch.tensor([[-20.], [20.]]),
                              torch.zeros(2, 1), torch.zeros(1, 7),
                              torch.stack([old_code, -old_code])[:, None], torch.zeros(1, 3),
                              torch.zeros(1, 3, 4), torch.zeros(1, 3, 4),
                              torch.zeros(3, 12), torch.zeros(3), True, True)
    assert snow_case[5][1, 0, 0] > 9.9 and (snow_case[4][1, 0, 1:] > 0).all()
    torch.testing.assert_close(snow_case[6][1, 0, 1:], old_code.expand(2, -1), atol=1e-6, rtol=1e-6)
    daily[-1].square().mean().backward()
    norms = {name: float(param.grad.abs().sum()) for name, param in model.named_parameters()
             if name.startswith(("encoder", "code_head", "rate_head"))}
    assert all(torch.isfinite(param.grad).all() for param in model.parameters() if param.grad is not None)
    assert sum(v for k, v in norms.items() if k.startswith("encoder")) > 0
    assert sum(v for k, v in norms.items() if k.startswith("rate_head")) > 0
    print(json.dumps({"state": "PASS", "groups": 3, "parameters_per_arm": 1187,
                      "max_water_balance_mm": float(balance.abs().max().detach()),
                      "max_code_channel_balance": float(residuals.abs().max().detach()),
                      "encoder_gradient_nonzero": True, "scientific_arrays_read": False,
                      "snowmelt_donor_code_oracle": True,
                      "training_performed": False}))


if __name__ == "__main__":
    main()
