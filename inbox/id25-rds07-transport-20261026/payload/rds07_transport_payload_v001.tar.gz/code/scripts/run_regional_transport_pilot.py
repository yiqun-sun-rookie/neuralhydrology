"""One frozen 20+20 update RDS07 pilot. Real arrays are Slurm-compute-only."""
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import random
import socket
import sys
import time
import traceback

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from id25.regional_transport_memory import RegionalTransportMemory
from id25.regional_storage_observation import center_on_fit_windows, project_storage


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")
    os.replace(temporary, path)


def save(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(value, temporary)
    os.replace(temporary, path)


def score(model, forcing, statics, weights, targets, fit_mask, valid_fit, valid_val, record=False):
    daily, final, states, fluxes, codes, residuals = model(forcing, statics, record=record)
    if not torch.isfinite(daily).all() or not all(torch.isfinite(v).all() for v in final.values()):
        raise FloatingPointError("Nonfinite physical/hidden/code state")
    prediction = project_storage(daily, weights)
    pc, yc, p_ref, y_ref, mask = center_on_fit_windows(prediction, targets, fit_mask)
    if not torch.equal(mask, valid_fit) or not torch.isfinite(pc).all():
        raise FloatingPointError("Fixed observation mask or predictions invalid")
    fit = (pc[valid_fit] - yc[valid_fit]).square().mean()
    val = (pc[valid_val] - yc[valid_val]).square().mean()
    if not torch.isfinite(fit + val):
        raise FloatingPointError("Nonfinite fixed-mask score")
    return fit, val, pc, yc, p_ref, y_ref, final, states, fluxes, codes, residuals


def train_arm(mode, root, config, identity, data, transforms, tensors, resume):
    root.mkdir(parents=True, exist_ok=True)
    if (root / "report.json").exists():
        completed = json.loads((root / "report.json").read_text())
        if completed["identity"] != identity or completed["epoch"] != config["epochs"]:
            raise ValueError("Completed arm identity mismatch")
        return completed
    torch.manual_seed(config["seed"])
    np.random.seed(config["seed"])
    random.seed(config["seed"])
    model = RegionalTransportMemory(7, transforms["dynamic_mean"], transforms["dynamic_scale"], mode)
    assert sum(p.numel() for p in model.parameters()) == 1187
    optimizer = torch.optim.Adam(model.parameters(), lr=config["learning_rate"])
    start, best, encoder_learned, initial_fit = 0, None, False, None
    checkpoint_path = root / "last.pt"
    if checkpoint_path.exists():
        if not resume:
            raise ValueError("Existing checkpoint requires explicit --resume")
        ck = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        if ck["identity"] != identity or ck["mode"] != mode or ck["config"] != config:
            raise ValueError("Resume identity mismatch")
        model.load_state_dict(ck["model"], strict=True)
        optimizer.load_state_dict(ck["optimizer"])
        start, best = ck["epoch"], ck["best_bundle"]
        encoder_learned, initial_fit = ck["encoder_learned"], ck["initial_fit_mse"]
        torch.set_rng_state(ck["torch_rng"])
        np.random.set_state(ck["numpy_rng"])
        random.setstate(ck["python_rng"])
    elif (root / "selection.json").exists():
        raise ValueError("Frozen selection without checkpoint; never refit")
    if initial_fit is None:
        model.eval()
        with torch.no_grad():
            initial_fit = float(score(model, *tensors)[0])
        write_json(root / "initial.json", {"epoch": 0, "fit_mse_cm2": initial_fit, "not_selectable": True})
    for epoch in range(start + 1, config["epochs"] + 1):
        if (root / "selection.json").exists():
            raise ValueError("Selection already frozen; no more fitting")
        began = time.monotonic()
        model.train()
        optimizer.zero_grad(set_to_none=True)
        scored = score(model, *tensors)
        loss = scored[0]
        loss.backward()
        gradient = torch.nn.utils.clip_grad_norm_(model.parameters(), config["gradient_clip"], error_if_nonfinite=True)
        encoder_norm = sum(float(p.grad.abs().sum()) for p in model.encoder.parameters() if p.grad is not None)
        if not np.isfinite(encoder_norm):
            raise FloatingPointError("Nonfinite encoder gradient")
        encoder_learned |= encoder_norm > 0
        optimizer.step()
        if not all(torch.isfinite(p).all() for p in model.parameters()):
            raise FloatingPointError("Nonfinite update; prior checkpoint retained")
        del loss, scored
        model.eval()
        with torch.no_grad():
            fit, val, _, _, p_ref, y_ref, state, _, _, _, _ = score(model, *tensors)
        fit_value, val_value = float(fit), float(val)
        if best is None or val_value < best["validation_mse"]:
            best = {"epoch": epoch, "validation_mse": val_value, "model": copy.deepcopy(model.state_dict()),
                    "state": copy.deepcopy(state), "prediction_reference_cm": p_ref.clone(),
                    "observation_reference_cm": y_ref.clone()}
        ck = {"model": model.state_dict(), "optimizer": optimizer.state_dict(), "epoch": epoch,
              "optimizer_steps": epoch, "mode": mode, "config": config, "identity": identity,
              "best_bundle": best, "encoder_learned": encoder_learned, "initial_fit_mse": initial_fit,
              "torch_rng": torch.get_rng_state(), "numpy_rng": np.random.get_state(),
              "python_rng": random.getstate()}
        save(checkpoint_path, ck)
        status = {"state": "RUNNING", "arm": mode, "epoch": epoch, "optimizer_steps": epoch,
                  "fit_rmse_cm": fit_value ** .5, "validation_rmse_cm": val_value ** .5,
                  "gradient_norm": float(gradient), "encoder_gradient_l1": encoder_norm,
                  "epoch_seconds": time.monotonic() - began, "time": now(),
                  "job_id": os.environ["SLURM_JOB_ID"]}
        with (root / "metrics.jsonl").open("a", encoding="utf-8") as f:
            f.write(json.dumps(status, allow_nan=False) + "\n")
        write_json(root / "status.json", status)
        print(json.dumps(status), flush=True)
    selection = {"state": "FROZEN", "primary_endpoint_epoch": config["epochs"],
                 "best_epoch_diagnostic_only": best["epoch"],
                 "best_val_mse_diagnostic_only": best["validation_mse"], "identity": identity}
    write_json(root / "selection.json", selection)
    save(root / "best_diagnostic.pt", best)
    with torch.no_grad():
        fit, val, pc, yc, p_ref, y_ref, state, states, fluxes, codes, residuals = score(model, *tensors, record=True)
        _, initial = model.initialize(tensors[1])
        previous = torch.cat([initial.sum(-1)[None], states[:-1].sum(-1)])
        balance = states.sum(-1) - previous - tensors[0][:, :, 0] + fluxes[:, :, 1] + fluxes[:, :, 2]
        max_balance, min_stock = float(balance.abs().max()), float(states.min())
        max_code, code_balance = float(codes.abs().max()), float(residuals.abs().max())
        if (min_stock < -1e-5 or max_balance > 1e-3 or max_code > 1.0001 or code_balance > 1e-3
                or not torch.isfinite(states).all() or not torch.isfinite(codes).all()
                or not torch.isfinite(residuals).all() or not encoder_learned):
            raise ValueError("Endpoint technical acceptance failed; no refitting")
        diff = (pc.double() - yc.double())
        val_mask = tensors[-1]
        count = val_mask.sum(0)
        regional = (torch.where(val_mask, diff.square(), 0).sum(0) / count).sqrt()
        pooled64 = float(diff[val_mask].square().mean().sqrt())
    np.savez_compressed(root / "endpoint_validation.npz", support_ids=data["support_ids"],
                        solution_ids=data["solution_ids"], fit_mask=data["fit_mask"],
                        predictions_cm=pc.numpy(), observed_cm=yc.numpy(), regional_rmse_cm=regional.numpy(),
                        prediction_reference_cm=p_ref.numpy(), observation_reference_cm=y_ref.numpy())
    report = {"state": "COMPLETED", "arm": mode, "epoch": config["epochs"], "optimizer_steps": config["epochs"],
              "identity": identity, "parameters": 1187, "technical_feasible": True,
              "initial_fit_mse_cm2": initial_fit, "endpoint_fit_mse_cm2": float(fit),
              "fit_loss_decreased": float(fit) < initial_fit, "endpoint_val_rmse_cm": pooled64,
              "regional_val_rmse_cm": regional.tolist(), "minimum_water_stock_mm": min_stock,
              "maximum_daily_water_balance_mm": max_balance, "maximum_code_channel_balance": code_balance,
              "maximum_absolute_average_code": max_code, "encoder_learned": encoder_learned,
              "selection": selection, "job_id": os.environ["SLURM_JOB_ID"], "finished_at": now()}
    write_json(root / "report.json", report)
    write_json(root / "status.json", report)
    return report


def run(args):
    if not os.environ.get("SLURM_JOB_ID") or socket.gethostname().lower().startswith("login"):
        raise RuntimeError("Scientific inputs require a Slurm compute-node job")
    config = json.loads(args.config.read_text())
    assert config["epochs"] == 20 and config["region_count"] == 119
    args.output.mkdir(parents=True, exist_ok=True)
    if (args.output / "report.json").exists():
        raise ValueError("Completed pilot must not run again")
    torch.set_num_threads(4)
    torch.set_num_interop_threads(1)
    receipt = json.loads((args.inputs_dir / "input_receipt.json").read_text())
    transforms = json.loads((args.inputs_dir / "transforms.json").read_text())
    input_sha = sha(args.inputs_dir / "inputs.npz")
    if input_sha != receipt["inputs_sha256"] or input_sha != config["input_sha256"]:
        raise ValueError("Frozen input hash mismatch")
    if sha(args.inputs_dir / "transforms.json") != receipt["transforms_sha256"]:
        raise ValueError("Frozen transforms hash mismatch")
    module_dir = Path(__file__).resolve().parents[1] / "id25"
    identity = {"input_sha256": input_sha, "config_sha256": sha(args.config),
                "code_sha256": {p.name: sha(p) for p in [Path(__file__), module_dir / "regional_transport_memory.py",
                    module_dir / "regional_daily_storage.py", module_dir / "regional_storage_observation.py"]}}
    write_json(args.output / "runtime.json", {"host": socket.gethostname(), "job_id": os.environ["SLURM_JOB_ID"],
               "torch": torch.__version__, "device": "cpu", "started_at": now(), "identity": identity})
    with np.load(args.inputs_dir / "inputs.npz", allow_pickle=False) as z:
        names = ["forcing", "static_features", "targets_cm", "sampling_weights", "fit_mask", "dates", "support_ids", "solution_ids"]
        data = {name: z[name] for name in names}
    assert len(data["support_ids"]) == 119 and len(set(data["support_ids"].astype(str))) == 119
    assert str(data["dates"][0])[:10] == "1998-08-01" and str(data["dates"][-1])[:10] == "2008-12-31"
    forcing, statics, targets, weights = [torch.from_numpy(data[n]).to(torch.float32) for n in names[:4]]
    fit_mask = torch.from_numpy(data["fit_mask"]).bool()
    assert targets.shape == (78, 119) and int(fit_mask.sum()) == 66
    assert forcing.shape == (len(data["dates"]), 119, 6) and weights.shape == (78, len(data["dates"]))
    assert all(torch.isfinite(t).all() for t in [forcing, statics, weights]) and forcing[:, :, 0].min() >= 0
    valid_fit = fit_mask[:, None] & torch.isfinite(targets)
    valid_val = (~fit_mask[:, None]) & torch.isfinite(targets)
    assert (valid_fit.sum(0) > 0).all() and (valid_val.sum(0) > 0).all()
    tensors = forcing, statics, weights, targets, fit_mask, valid_fit, valid_val
    reports = {mode: train_arm(mode, args.output / mode, config, identity, data, transforms, tensors, args.resume)
               for mode in ["transport", "direct_history"]}
    t, d = reports["transport"], reports["direct_history"]
    delta = np.array(t["regional_val_rmse_cm"]) - np.array(d["regional_val_rmse_cm"])
    pooled_delta = t["endpoint_val_rmse_cm"] - d["endpoint_val_rmse_cm"]
    signal = pooled_delta < 0 and int((delta < 0).sum()) >= 60
    comparison = {"state": "COMPLETED", "experiment_id": config["exp_id"], "development_only": True,
                  "primary_endpoint": "fixed_epoch20_on_opened_2008", "region_count": 119,
                  "total_optimizer_steps": 40, "technical_feasible": all(v["technical_feasible"] for v in reports.values()),
                  "transport_fit_loss_decreased": t["fit_loss_decreased"],
                  "architecture_advantage_signal": signal, "scientific_success_proven": False,
                  "transport_minus_direct_pooled_rmse_cm": pooled_delta,
                  "transport_better_regions": int((delta < 0).sum()), "worse_regions": int((delta > 0).sum()),
                  "tied_regions": int((delta == 0).sum()), "near_tied_within_1e_5_cm": int((abs(delta) <= 1e-5).sum()),
                  "transport_rmse_cm": t["endpoint_val_rmse_cm"], "direct_rmse_cm": d["endpoint_val_rmse_cm"],
                  "fixed_baselines": config["fixed_baselines"], "identity": identity, "finished_at": now(),
                  "limitations": ["2008 already used for development; no independent generalization claim",
                      "equal parameter architecture comparison is not a pure transport causal ablation",
                      "fixed baselines have larger and different training budgets; no retraining",
                      "no 2009-2010 access; no daily-component or flood-forecast validation"]}
    lines = ["region_id,transport_rmse_cm,direct_history_rmse_cm,transport_minus_direct_cm"]
    lines += [f"{rid},{tv:.17g},{dv:.17g},{de:.17g}" for rid, tv, dv, de in zip(data["support_ids"],
              t["regional_val_rmse_cm"], d["regional_val_rmse_cm"], delta)]
    (args.output / "regional_comparison.csv").write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_json(args.output / "report.json", comparison)
    write_json(args.output / "status.json", comparison)
    print(json.dumps(comparison, allow_nan=False), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--inputs-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    try:
        run(args)
    except Exception as exc:
        args.output.mkdir(parents=True, exist_ok=True)
        write_json(args.output / "status.json", {"state": "FAILED", "error": str(exc), "time": now()})
        traceback.print_exc()
        sys.exit(1)
