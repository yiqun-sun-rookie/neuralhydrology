"""Isolated TESSERA/regional LSTM pilot. No core factories are changed."""
