"""Fill only missing import dependencies in this experiment's private directory."""
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parents[3]
private = root / "pysite"
private.mkdir(exist_ok=True)
allowed = {"sklearn": ["scikit-learn==1.7.2", "joblib==1.5.2", "threadpoolctl==3.6.0"],
           "joblib": ["joblib==1.5.2"], "threadpoolctl": ["threadpoolctl==3.6.0"],
           "ruamel": ["ruamel.yaml==0.18.16", "ruamel.yaml.clib==0.2.14"],
           "tensorboard": ["tensorboard==2.20.0", "absl-py==2.3.1", "grpcio==1.75.1", "markdown==3.9", "protobuf==6.32.1", "werkzeug==3.1.3", "markupsafe==3.0.3", "tensorboard-data-server==0.7.2"]}
installed = []
for attempt in range(5):
    check = subprocess.run([sys.executable, "-c", "import train_temporal_pilot"], text=True, capture_output=True)
    if check.returncode == 0:
        (root / "runtime_setup.json").write_text(json.dumps({"status": "IMPORT_READY", "installed_privately": installed}, indent=2))
        print("HPC_IMPORT_READY", flush=True)
        break
    print(check.stderr, flush=True)
    missing = re.findall(r"ModuleNotFoundError: No module named '([^']+)'", check.stderr)
    key = missing[-1].split(".")[0] if missing else None
    if key not in allowed:
        raise RuntimeError("Unanticipated environment error; shared environment left unchanged")
    packages = allowed.pop(key)
    subprocess.run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--no-deps", "--only-binary=:all:",
                    "--target", str(private)] + packages, check=True)
    installed.extend(packages)
else:
    raise RuntimeError("Private dependency setup did not complete")
