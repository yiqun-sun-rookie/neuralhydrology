"""Differentiable official PixelStudent -> weighted basin pool -> existing CudaLSTM."""
import importlib.util
from pathlib import Path

import torch
from torch import nn

from neuralhydrology.modelzoo.cudalstm import CudaLSTM
from neuralhydrology.utils.config import Config


def load_official(folder, device="cpu"):
    folder = Path(folder)
    spec = importlib.util.spec_from_file_location("tessera_official_small", folder / "model.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # Plain state_dict + args only; do not invoke the upstream unrestricted pickle loader.
    payload = torch.load(folder / "ckpt/student_small.pt", map_location="cpu", weights_only=True)
    cfg = payload["args"]
    dims = tuple(int(x) for x in str(cfg.get("matryoshka_dims", "16,32,64,128")).split(","))
    model = module.PixelStudent(repr_dim=int(cfg.get("repr_dim", 128)),
                                latent_dim=int(cfg.get("latent_dim", 64)),
                                num_layers=int(cfg.get("num_layers", 4)),
                                nhead=int(cfg.get("nhead", 4)),
                                dim_feedforward=int(cfg.get("dim_feedforward", 1024)),
                                dropout=0.0, max_seq_len=int(cfg.get("max_seq_len", 256)),
                                matryoshka_dims=dims,
                                enable_qk_norm=bool(cfg.get("enable_qk_norm", False)))
    model.load_state_dict(payload["model"], strict=True)
    return model.to(device), module, cfg


def load_regional(config, checkpoint=None, device="cpu"):
    cfg = Config(Path(config))
    model = CudaLSTM(cfg)
    if checkpoint is not None:
        model.load_state_dict(torch.load(checkpoint, map_location="cpu", weights_only=True), strict=True)
    return model.to(device)


def bin_indices(n, device):
    """Exact split-and-repeat/linspace rule of pinned official infer.py."""
    size = min(256, ((n + 7) // 8) * 8)
    if n >= size:
        return torch.linspace(0, n - 1, size, dtype=torch.float64, device=device).long()
    remain = size - n
    base = torch.arange(n, device=device)
    if remain <= n:
        groups = torch.tensor_split(base, remain)
        fill = torch.stack([g[len(g) // 2] for g in groups])
    else:
        fill = torch.arange(remain, device=device) % n
    return torch.cat([base, fill])


class SatelliteEncoder(nn.Module):
    """Raw model-native radiometry, times in UTC Unix seconds. No output detach/cache.

    Input arrays: s2/s1a/s1d [B,P,T,C], doy/mask/acquired/available [B,P,T],
    weights [B,P]. Acquired AND available must be <= context cutoff.
    S1 raw values must already match the author's preprocessing; dB is not accepted
    implicitly. Satellite decoding/georegistration can occur offline.
    """

    def __init__(self, official, module):
        super().__init__()
        self.encoder = official
        for key, value in {"s2_mean": module.S2_BAND_MEAN, "s2_std": module.S2_BAND_STD,
                           "s1a_mean": module.S1A_BAND_MEAN, "s1a_std": module.S1A_BAND_STD,
                           "s1d_mean": module.S1D_BAND_MEAN, "s1d_std": module.S1D_BAND_STD}.items():
            self.register_buffer(key, torch.as_tensor(value.copy()))

    def forward(self, satellite, cutoff):
        groups, valid_pixels = {}, []
        batch, pixels = satellite["s2"].shape[:2]
        for b in range(batch):
            for p in range(pixels):
                sources = {}
                for source in ["s2", "s1a", "s1d"]:
                    raw = satellite[source][b, p]
                    valid = satellite[source + "_mask"][b, p].bool()
                    valid = valid & torch.isfinite(raw).all(-1)
                    valid = valid & (satellite[source + "_acquired"][b, p] <= cutoff[b])
                    valid = valid & (satellite[source + "_available"][b, p] <= cutoff[b])
                    if source != "s2":
                        valid = valid & (raw != 0).any(-1)
                    bands = (raw[valid] - getattr(self, source + "_mean")) / (getattr(self, source + "_std") + 1e-9)
                    doys = satellite[source + "_doy"][b, p][valid].to(bands.dtype).unsqueeze(-1)
                    sources[source] = torch.cat([bands, doys], -1)
                s2, s1 = sources["s2"], torch.cat([sources["s1a"], sources["s1d"]], 0)
                if len(s2) + len(s1) == 0:
                    continue
                s2 = s2[bin_indices(len(s2), s2.device)] if len(s2) else s2.new_zeros(1, 11)
                s1 = s1[bin_indices(len(s1), s1.device)] if len(s1) else s1.new_zeros(1, 3)
                groups.setdefault((len(s2), len(s1)), []).append((b, p, s2, s1))
                valid_pixels.append((b, p))
        # Every sample must contain at least one real, timely satellite observation.
        if {b for b, _ in valid_pixels} != set(range(batch)):
            raise ValueError("A sample has no S1/S2 observations available at its recurrent context time.")
        results, indices = [], []
        for group in groups.values():
            s2 = torch.stack([x[2] for x in group])
            s1 = torch.stack([x[3] for x in group])
            results.append(self.encoder.encode(s2, s1))
            indices.extend([b * pixels + p for b, p, _, _ in group])
        encoded = torch.cat(results, 0)
        index = torch.tensor(indices, device=encoded.device)
        dense = encoded.new_zeros(batch * pixels, encoded.shape[-1]).index_copy(0, index, encoded)
        valid = encoded.new_zeros(batch * pixels).index_fill(0, index, 1).reshape(batch, pixels)
        weights = satellite["weights"].to(encoded.dtype)
        if not torch.isfinite(weights).all() or (weights < 0).any():
            raise ValueError("Spatial weights must be finite and nonnegative.")
        weights = weights * valid
        if (weights.sum(1) <= 0).any():
            raise ValueError("No positive sampled area weight remains.")
        weights = weights / weights.sum(1, keepdim=True)
        return (dense.reshape(batch, pixels, -1) * weights.unsqueeze(-1)).sum(1)


class JointRegional(nn.Module):
    """Append RS columns before recurrence; copy every original LSTM weight.

    context_index defines when the snapshot becomes available in the forcing
    sequence; satellite columns are zero before that index. The default dataset
    contract uses the issue-time final update, so no later snapshot contaminates
    earlier recurrent states. The scalar original head is retained for one lead.
    """

    def __init__(self, regional, satellite=None, rs_width=16):
        super().__init__()
        self.regional = regional
        self.satellite = satellite
        self.rs_width = rs_width
        if satellite is not None:
            self.mapping = nn.Sequential(nn.Linear(128, rs_width), nn.Tanh())
            old = regional.lstm
            new = nn.LSTM(old.input_size + rs_width, old.hidden_size).to(old.weight_ih_l0.device)
            with torch.no_grad():
                new.weight_ih_l0[:, :old.input_size].copy_(old.weight_ih_l0)
                new.weight_ih_l0[:, old.input_size:].zero_()
                for name in ["weight_hh_l0", "bias_ih_l0", "bias_hh_l0"]:
                    getattr(new, name).copy_(getattr(old, name))
            regional.lstm = new
        self.set_stage("frozen")

    def set_stage(self, stage, last_layers=1):
        self.stage = stage
        if self.satellite is None:
            return
        for param in self.satellite.parameters():
            param.requires_grad_(False)
        if stage == "partial":
            if not 1 <= last_layers <= 4:
                raise ValueError("Small partial tuning requires last_layers between 1 and 4")
            encoder = self.satellite.encoder
            modules = [encoder.dim_reducer]
            for backbone in [encoder.s2_backbone, encoder.s1_backbone]:
                layers = backbone.transformer_encoder
                layers = layers.layers if hasattr(layers, "layers") else layers
                modules += list(layers[-last_layers:]) + [backbone.attn_pool]
            for module in modules:
                for param in module.parameters():
                    param.requires_grad_(True)
        elif stage != "frozen":
            raise ValueError(stage)
        # Keep official dropout off in B and C, even while optimizing C.
        # eval() does not disable autograd; this isolates trainability from dropout.
        self.satellite.eval()

    def train(self, mode=True):
        super().train(mode)
        if self.satellite is not None:
            self.satellite.eval()
        return self

    def forward(self, data):
        x = self.regional.embedding_net(data)
        if self.satellite is not None:
            length, batch, _ = x.shape
            context_index = data["context_index"].long()
            cutoff = data["dynamic_times"].gather(1, context_index[:, None]).squeeze(1)
            emb = self.satellite(data["satellite"], cutoff)
            mapped = self.mapping(emb)
            active = torch.arange(length, device=x.device)[:, None] >= context_index[None, :]
            rs = mapped[None, :, :].expand(length, batch, -1) * active.unsqueeze(-1)
            x = torch.cat([x, rs], -1)
        output, (hidden, cell) = self.regional.lstm(x)
        output = output.transpose(0, 1)
        result = self.regional.head(self.regional.dropout(output))
        result.update({"h_n": hidden.transpose(0, 1), "c_n": cell.transpose(0, 1)})
        return result

    def optimizer(self, regional_lr=1e-4, encoder_lr=1e-6):
        parameters = [{"params": list(self.regional.parameters()) +
                                 (list(self.mapping.parameters()) if self.satellite else []),
                       "lr": regional_lr}]
        if self.satellite and self.stage == "partial":
            parameters.append({"params": [p for p in self.satellite.parameters() if p.requires_grad],
                               "lr": encoder_lr})
        return torch.optim.Adam(parameters)

    def pretrained_reference(self):
        return {name: p.detach().clone() for name, p in self.satellite.named_parameters() if p.requires_grad}

    def l2sp(self, reference):
        params = dict(self.satellite.named_parameters())
        return torch.stack([(params[k] - v).square().mean() for k, v in reference.items()]).sum()
