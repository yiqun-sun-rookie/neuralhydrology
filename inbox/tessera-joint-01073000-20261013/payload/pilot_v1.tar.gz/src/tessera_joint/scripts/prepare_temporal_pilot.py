"""Prepare a bounded one-basin real temporal pilot from the audited source conventions."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import requests
import xarray as xr
import yaml

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
from neuralhydrology.utils.config import Config
from tessera_joint.data import PreparedForecasts, load_target_transform, verify_target_periods

SOURCE = ROOT / "results/18_lstm_fair_531/lstm_cudalstm_maurer_s100_2026_0616_1513_ep30"
SNAPSHOT = ROOT / "results/TJ00_tessera_joint/20261013_real_01073000_minimal"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, data):
    with Path(path).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    settings = json.loads(args.config.read_text())
    write_json(out / "protocol.json", settings)
    cfg = Config(SOURCE / "config.yml")
    normalizer = SOURCE / "train_data/train_data_scaler.yml"
    scaler = yaml.safe_load(normalizer.read_text())
    transform = load_target_transform(normalizer, "QObs(mm/d)")
    old_meta = json.loads((SNAPSHOT / "real_sample.json").read_text())
    if old_meta["normalizer_sha256"] != sha(normalizer):
        raise ValueError("Audited normalizer changed")
    start = pd.Timestamp(settings["target_day_ranges"]["train"]["start"], tz="UTC")
    end = pd.Timestamp(settings["target_day_ranges"]["test"]["end_exclusive"], tz="UTC")
    history_start = (start - pd.Timedelta(days=cfg.seq_length)).tz_localize(None)
    met_end = (end - pd.Timedelta(days=1)).tz_localize(None)
    met_path = ROOT / "data/camelsh/time_series/01073000.nc"
    original = ROOT / "data/camelsh/timeseries/Data/CAMELSH/timeseries/01073000.nc"
    columns = ["Rainf", "Tair", "SWdown", "Qair", "PSurf"]
    with xr.open_dataset(met_path) as ds:
        met = ds[columns].sel(date=slice(history_start, met_end)).to_dataframe()
    with xr.open_dataset(original) as ds:
        raw = ds[columns].sel(DateTime=slice(history_start, met_end)).to_dataframe()
    if not np.array_equal(met.index.values, raw.index.values) or not np.array_equal(met.values, raw.values):
        raise ValueError("Renamed versus original meteorology mismatch")
    if not met.index.equals(pd.date_range(history_start, met_end, freq="h")) or not np.isfinite(met.values).all():
        raise ValueError("Incomplete or invalid hourly meteorology")
    if (met.Rainf < 0).any() or not met.Qair.between(0, 1, inclusive="neither").all():
        raise ValueError("Invalid meteorological values")
    rows = []
    for day in pd.date_range(history_start, met_end - pd.Timedelta(days=1), freq="D"):
        h = met.loc[day:day + pd.Timedelta(hours=23)]
        rain = met.Rainf.loc[day + pd.Timedelta(hours=1):day + pd.Timedelta(days=1)]
        if len(h) != 24 or len(rain) != 24:
            raise ValueError("Incomplete UTC meteorological day")
        vp = h.Qair * h.PSurf / (0.622 + 0.378 * h.Qair)
        rows.append([day, rain.sum(), h.Tair.min(), h.Tair.max(), h.SWdown.mean(), vp.mean()])
    daily = pd.DataFrame(rows, columns=["day_start_utc"] + list(cfg.dynamic_inputs)).set_index("day_start_utc")
    daily.to_csv(out / "meteorology_daily_physical.csv")
    met.to_csv(out / "meteorology_hourly_source.csv")
    params = {"format": "json", "sites": settings["basin"], "startDT": start.isoformat(),
              "endDT": end.isoformat(), "parameterCd": "00060", "siteStatus": "all"}
    response = requests.get("https://waterservices.usgs.gov/nwis/iv/", params=params, timeout=90)
    response.raise_for_status()
    (out / "usgs_source.json").write_bytes(response.content)
    payload = response.json()
    series = next(x for x in payload["value"]["timeSeries"] if x["variable"]["variableCode"][0]["value"] == "00060")
    if series["sourceInfo"]["siteCode"][0]["value"] != settings["basin"] or series["variable"]["unit"]["unitCode"] != "ft3/s":
        raise ValueError("USGS site or unit mismatch")
    records = series["values"][0]["value"]
    q = pd.DataFrame({"q_cfs": [float(r["value"]) for r in records],
                      "approved": ["A" in r.get("qualifiers", []) for r in records]},
                     index=pd.to_datetime([r["dateTime"] for r in records], utc=True)).sort_index()
    if q.index.has_duplicates:
        raise ValueError("Duplicate USGS timestamps")
    q.to_csv(out / "usgs_15min.csv")
    physical, excluded = {}, []
    for day in pd.date_range(start, end, freq="D", inclusive="left"):
        part = q.loc[(q.index >= day) & (q.index < day + pd.Timedelta(days=1))]
        ok = (part.index.equals(pd.date_range(day, periods=96, freq="15min")) and
              np.isfinite(part.q_cfs).all() and (part.q_cfs >= 0).all() and part.approved.all())
        if not ok:
            excluded.append({"day": day.date().isoformat(), "records": len(part), "reason": "incomplete_invalid_or_unapproved"})
            continue
        physical[day] = float(part.q_cfs.mean() * 0.028316846592 * 86400 * 1000 / old_meta["basin_area_m2"])
    pd.Series(physical, name="q_mm_d").to_csv(out / "flow_daily_physical.csv")
    with np.load(SNAPSHOT / "real_sample.npz", allow_pickle=False) as sample:
        static = sample["x_s"].copy()
    with np.load(SNAPSHOT / "satellite_native.npz", allow_pickle=False) as sat:
        satellite = {k: sat[k].copy() for k in sat.files}
    normalized = np.column_stack([(daily[k] - scaler["xarray_feature_center"]["data_vars"][k]["data"]) /
                                  scaler["xarray_feature_scale"]["data_vars"][k]["data"] for k in cfg.dynamic_inputs]).astype(np.float32)
    datasets, counts = {}, {}
    for name, bounds in settings["target_day_ranges"].items():
        days = [day for day in physical if pd.Timestamp(bounds["start"], tz="UTC") <= day < pd.Timestamp(bounds["end_exclusive"], tz="UTC")]
        if len(days) < 14:
            raise ValueError(f"Too few complete days for {name}")
        issues = np.array([int(day.timestamp()) for day in days], dtype=np.int64)
        offsets = [daily.index.get_loc(day.tz_localize(None) - pd.Timedelta(days=cfg.seq_length)) for day in days]
        arrays = {k: np.repeat(v, len(days), axis=0) for k, v in satellite.items()}
        arrays.update(x_d=np.stack([normalized[i:i + cfg.seq_length] for i in offsets]),
                      x_s=np.repeat(static, len(days), axis=0),
                      y=np.array([(physical[d] - transform["target_mean"]) / transform["target_std"] for d in days], dtype=np.float32).reshape(-1, 1, 1),
                      basins=np.full(len(days), settings["basin"]),
                      per_basin_target_stds=np.ones((len(days), 1, 1), dtype=np.float32),
                      dynamic_times=issues[:, None] - np.arange(cfg.seq_length - 1, -1, -1)[None, :] * 86400,
                      issue_times=issues, target_times=issues + 86400,
                      context_index=np.full(len(days), cfg.seq_length - 1, dtype=np.int64))
        np.savez_compressed(out / f"{name}.npz", **arrays)
        meta = {k: old_meta[k] for k in ["kind", "dynamic_features", "static_features", "lead_days", "meteorological_information",
                "normalizer_sha256", "target_mean", "target_std", "time_semantics_verified", "radiometry_verified",
                "training_only_normalization_verified", "operational_replay_verified", "satellite_availability_evidence",
                "historical_meteorology_product", "normalization_provenance", "basin_area_m2", "area_source", "conversion", "product_shift"]}
        meta.update(purpose=settings["track"], split=name, target_day_range=bounds, sample_count=len(days),
                    satellite_snapshot=settings["satellite_snapshot"], per_basin_target_stds="fixed 1 unused by normalized MSE",
                    source_snapshot_sha256=sha(SNAPSHOT / "satellite_manifest.json"))
        write_json(out / f"{name}.json", meta)
        datasets[name] = PreparedForecasts(out / f"{name}.npz", cfg)
        counts[name] = len(days)
    verify_target_periods(datasets, settings["target_day_ranges"])
    manifest = {"status": "REAL_TEMPORAL_DATA_READY", "basin": settings["basin"], "counts": counts,
                "excluded_days": excluded, "source_url": response.url, "limits": settings["limits"],
                "source_hashes": {str(p.relative_to(ROOT)).replace(chr(92), "/"): sha(p) for p in [
                    met_path, original, normalizer, SNAPSHOT / "real_sample.npz", SNAPSHOT / "satellite_native.npz", SNAPSHOT / "satellite_manifest.json"]},
                "files_sha256": {p.name: sha(p) for p in out.iterdir() if p.is_file()}}
    write_json(out / "manifest.json", manifest)
    print(json.dumps({"status": manifest["status"], "counts": counts, "excluded_days": excluded}))


if __name__ == "__main__":
    main()
