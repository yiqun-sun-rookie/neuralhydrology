"""One real sample, two frozen updates and one partial TESSERA update; no skill scoring."""
import argparse
import json
from pathlib import Path
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
from tessera_joint.data import PreparedForecasts, to_device, load_target_transform, verify_target_transform
from tessera_joint.model import JointRegional, SatelliteEncoder, load_official, load_regional
from tessera_joint.scripts.prepare_real_sample import SOURCE_RUN, sha


def flow_loss(output, data):
    pred, obs = output["y_hat"][:, -1:, :], data["y"]
    if not torch.isfinite(pred).all() or not torch.isfinite(obs).all():
        raise ValueError("Nonfinite single-sample prediction or target")
    return (pred - obs).square().mean()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    official = ROOT / "external/tessera_v2_small_9e1a725"
    scaler_file = SOURCE_RUN / "train_data/train_data_scaler.yml"
    seed = 20261013
    torch.manual_seed(seed)
    np.random.seed(seed)
    torch.set_num_threads(8)
    report = {"status": "RUNNING", "kind": "REAL_SINGLE_SAMPLE_ENGINEERING",
              "hydrological_skill": "NOT_EVALUATED", "operational_replay": False,
              "seed": seed, "torch": torch.__version__, "cuda": torch.version.cuda,
              "loss": "standardized target MSE, no L2-SP or other auxiliary loss",
              "planned_updates": {"frozen": 2, "partial": 1}, "updates": [],
              "source_sha256": {str(p.relative_to(ROOT)): sha(p) for p in [args.data.resolve(),
                  args.data.with_suffix('.json').resolve(), SOURCE_RUN / 'model_epoch030.pt', scaler_file,
                  official / 'ckpt/student_small.pt', Path(__file__), ROOT / 'src/tessera_joint/model.py',
                  ROOT / 'src/tessera_joint/data.py', ROOT / 'src/tessera_joint/scripts/prepare_real_sample.py']}}
    start = time.perf_counter()
    try:
        if not torch.cuda.is_available():
            raise RuntimeError("Requested local CUDA device unavailable")
        report["gpu"] = torch.cuda.get_device_name(0)
        torch.cuda.reset_peak_memory_stats()
        report["device_free_before_mib"] = torch.cuda.mem_get_info()[0] / 1024 ** 2
        regional = load_regional(SOURCE_RUN / "config.yml", SOURCE_RUN / "model_epoch030.pt", "cuda")
        dataset = PreparedForecasts(args.data, regional.cfg)
        if len(dataset) != 1 or dataset.meta["purpose"] != "single_sample_retrospective_engineering_only":
            raise ValueError("This probe accepts exactly one declared real engineering sample")
        if dataset.meta['normalizer_sha256'] != sha(scaler_file):
            raise ValueError("Sample normalizer does not match original checkpoint scaler")
        transform = load_target_transform(scaler_file, "QObs(mm/d)")
        verify_target_transform(dataset.meta, transform)
        data = to_device(next(iter(DataLoader(dataset, batch_size=1, shuffle=False))), "cuda")
        report['sample'] = {k: dataset.meta[k] for k in ['target_day_start_utc', 'target_day_end_utc',
            'observed_daily_flow_m3_s', 'observed_daily_flow_mm_d', 'basin_area_m2']}
        report['sample']['basin'] = dataset.arrays['basins'].tolist()
        report['satellite'] = {k: {'shape': list(data['satellite'][k].shape),
                                 'valid_observations': int(data['satellite'][k + '_mask'].sum())}
                               for k in ['s2', 's1a', 's1d']}
        encoder, module, _ = load_official(official, "cuda")
        model = JointRegional(regional, SatelliteEncoder(encoder, module)).cuda()
        initial = {k: p.detach().clone() for k, p in encoder.named_parameters()}
        amp = torch.cuda.amp.GradScaler(init_scale=1024)
        model.train()
        optimizer = model.optimizer(regional_lr=1e-4)

        def update(stage):
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast('cuda', dtype=torch.float16):
                loss = flow_loss(model(data), data)
            amp.scale(loss).backward()
            amp.unscale_(optimizer)
            gradients = {k: {'norm': float(p.grad.float().norm()),
                             'nonzero': int(torch.count_nonzero(p.grad)),
                             'finite': bool(torch.isfinite(p.grad).all())}
                         for k, p in encoder.named_parameters() if p.requires_grad and p.grad is not None}
            active = [p for p in model.parameters() if p.requires_grad]
            if any(p.grad is not None and not torch.isfinite(p.grad).all() for p in active):
                raise ValueError('Nonfinite gradient')
            torch.nn.utils.clip_grad_norm_(active, 1.0)
            scale_before = amp.get_scale()
            amp.step(optimizer)
            amp.update()
            skipped = amp.get_scale() < scale_before
            report['updates'].append({'stage': stage, 'loss_before_update': float(loss.detach()), 'amp_skipped': skipped})
            if skipped:
                raise ValueError('AMP skipped the required real update')
            return gradients

        for _ in range(2):
            update('frozen')
        report['frozen_stage_encoder_max_drift'] = max(float((p - initial[k]).abs().max())
                                                      for k, p in encoder.named_parameters())
        report['rs_input_weight_norm_after_frozen'] = float(regional.lstm.weight_ih_l0[:, -model.rs_width:].norm())
        if report['frozen_stage_encoder_max_drift'] != 0 or report['rs_input_weight_norm_after_frozen'] == 0:
            raise AssertionError('Frozen-stage pathway not correctly established')
        model.set_stage('partial', last_layers=1)
        optimizer = model.optimizer(regional_lr=1e-4, encoder_lr=1e-6)
        before = {k: p.detach().clone() for k, p in encoder.named_parameters()}
        gradients = update('partial')
        deltas = {k: float((p - before[k]).abs().max()) for k, p in encoder.named_parameters() if p.requires_grad}
        frozen_drift = max(float((p - before[k]).abs().max()) for k, p in encoder.named_parameters() if not p.requires_grad)
        for branch in ['s1_backbone.transformer_encoder', 's2_backbone.transformer_encoder']:
            if not any(v['finite'] and v['nonzero'] > 0 for k, v in gradients.items() if branch in k):
                raise AssertionError(f'No real flow gradient in {branch}')
            if not any(v > 0 for k, v in deltas.items() if branch in k):
                raise AssertionError(f'No actual real-sample parameter update in {branch}')
        if frozen_drift != 0:
            raise AssertionError('Frozen encoder parameters changed')
        model.eval()
        with torch.no_grad():
            output = model(data)
            after_loss = float(flow_loss(output, data))
            prediction = float(output['y_hat'][0, -1, 0]) * transform['target_std'] + transform['target_mean']
        torch.cuda.synchronize()
        report.update(status='PASS_REAL_SINGLE_SAMPLE_JOINT_BACKWARD', pure_flow_gradients=gradients,
                      partial_encoder_max_deltas=deltas, still_frozen_max_drift=frozen_drift,
                      trainable_encoder_parameters=sum(p.numel() for p in encoder.parameters() if p.requires_grad),
                      trainable_encoder_tensors=len(deltas),
                      finite_nonzero_gradient_tensors=sum(v['finite'] and v['nonzero'] > 0 for v in gradients.values()),
                      updated_encoder_tensors=sum(v > 0 for v in deltas.values()),
                      peak_allocated_mib=torch.cuda.max_memory_allocated() / 1024 ** 2,
                      peak_reserved_mib=torch.cuda.max_memory_reserved() / 1024 ** 2,
                      after_update_eval_mse=after_loss, after_update_prediction_mm_d=prediction,
                      numerical_output_scope='single training sample, not out-of-sample skill')
        torch.save(model.state_dict(), args.output / 'joint_after_three_updates.pt')
        print(json.dumps({k: report[k] for k in ['status', 'finite_nonzero_gradient_tensors',
            'updated_encoder_tensors', 'peak_allocated_mib', 'peak_reserved_mib']}, indent=2), flush=True)
    except Exception as exc:
        report.update(status='FAILED', error=repr(exc))
        raise
    finally:
        report['elapsed_seconds'] = time.perf_counter() - start
        (args.output / 'report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
