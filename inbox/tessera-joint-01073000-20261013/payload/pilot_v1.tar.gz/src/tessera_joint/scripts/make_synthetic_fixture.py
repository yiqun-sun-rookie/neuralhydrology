"""Create explicitly synthetic data for testing the A/B/C runner, never scientific metrics."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import torch
import yaml

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
from tessera_joint.model import load_official, load_regional
from tessera_joint.scripts.probe_backward import synthetic_batch


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    settings = json.loads((ROOT / "src/tessera_joint/configs/pilot.json").read_text())
    regional = load_regional(ROOT / settings["source_run"] / "config.yml")
    official, module, _ = load_official(ROOT / settings["official_folder"])
    torch.manual_seed(settings["seed"])
    normalizer = args.output.resolve() / "synthetic_target_scaler.yml"
    target = regional.cfg.target_variables[0]
    payload = {"kind": "synthetic_engineering"}
    for field, value in [("xarray_feature_center", 0.0), ("xarray_feature_scale", 1.0)]:
        payload[field] = {"coords": {}, "attrs": {}, "dims": {},
                          "data_vars": {target: {"dims": [], "attrs": {}, "data": value}}}
    normalizer.write_text(yaml.safe_dump(payload), encoding="utf-8")
    settings["normalizer_file"] = str(normalizer.relative_to(ROOT)).replace("\\", "/")
    normalizer_hash = hashlib.sha256(normalizer.read_bytes()).hexdigest()
    splits = {"train": (["01073000", "01078000", "01123000", "01162500"], -366 * 86400),
              "validation": (["01019000", "01019000"], 366 * 86400),
              "test": (["01042500", "01046500", "01042500", "01046500"], 731 * 86400)}
    for name, (basins, shift) in splits.items():
        batch = synthetic_batch(regional, module, batch=len(basins), pixels=8, observations=24, device="cpu")
        offsets = shift + torch.arange(len(basins)) * 86400
        arrays = {"x_d": torch.cat([batch["x_d"][k] for k in regional.cfg.dynamic_inputs], -1).numpy(),
                  "x_s": batch["x_s"].numpy(), "basins": np.array(basins)}
        for k in ["y", "per_basin_target_stds", "context_index"]:
            arrays[k] = batch[k].numpy()
        for k in ["dynamic_times", "issue_times", "target_times"]:
            value = batch[k] + (offsets[:, None] if k == "dynamic_times" else offsets)
            arrays[k] = value.numpy()
        for k, value in batch["satellite"].items():
            if k.endswith("_acquired") or k.endswith("_available"):
                value = value + offsets[:, None, None]
            arrays["sat_" + k] = value.numpy()
        path = args.output / f"{name}.npz"
        np.savez_compressed(path, **arrays)
        metadata = {"kind": "synthetic_engineering", "lead_days": 1,
                    "dynamic_features": list(regional.cfg.dynamic_inputs),
                    "static_features": list(regional.cfg.static_attributes),
                    "meteorological_information": "past_observed_only",
                    "normalizer_sha256": normalizer_hash, "target_mean": 0, "target_std": 1,
                    "note": "Random inputs/labels; dedicated 0/1 synthetic target scaler, not hydrological statistics."}
        path.with_suffix(".json").write_text(json.dumps(metadata, indent=2))
        settings[name + "_npz"] = str(path.resolve().relative_to(ROOT)).replace("\\", "/")
    settings.update({"data_status": "ready", "blockers": [], "batch_size": 1, "accumulation": 2,
                     "stage1_epochs": 1, "stage2_epochs": 1})
    (args.output / "synthetic_config.json").write_text(json.dumps(settings, indent=2))
    print(str(args.output / "synthetic_config.json"))


if __name__ == "__main__":
    main()
