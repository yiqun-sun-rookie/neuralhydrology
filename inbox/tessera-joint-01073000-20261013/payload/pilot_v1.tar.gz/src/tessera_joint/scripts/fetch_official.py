"""Fetch a pinned official Small release; never overwrite differing local bytes."""
import argparse
import hashlib
import json
from pathlib import Path
import urllib.request

HF_REVISION = "9e1a725f1ac1a3a8ab93fd85b08633754cacb508"
GITHUB_REVISION = "e368539f7c4711e5f16fdd09801573830e34baf9"
REPO = "geotessera/TESSERA-V-2.0-2B-S"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", type=Path, required=True)
    args = parser.parse_args()
    args.destination.mkdir(parents=True, exist_ok=True)
    records = []
    files = {name: f"https://huggingface.co/{REPO}/resolve/{HF_REVISION}/{name}?download=true"
             for name in ["model.py", "infer.py", "quantize.py", "requirements.txt", "README.md",
                          "__init__.py", "ckpt/student_small.pt"]}
    files.update({name: f"https://raw.githubusercontent.com/ucam-eo/tessera/{GITHUB_REVISION}/{name}"
                  for name in ["LICENSE", "aup.md"]})
    for name, url in files.items():
        path = args.destination / name
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp = path.with_suffix(path.suffix + ".partial")
            print(f"Downloading {name}", flush=True)
            with urllib.request.urlopen(url, timeout=45) as response, tmp.open("xb") as target:
                while chunk := response.read(1024 * 1024):
                    target.write(chunk)
            tmp.rename(path)
        records.append({"file": name, "url": url, "bytes": path.stat().st_size,
                        "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    manifest = {"hf_repo": REPO, "hf_revision": HF_REVISION, "github_revision": GITHUB_REVISION,
                "files": records}
    manifest_path = args.destination / "download_manifest.json"
    encoded = json.dumps(manifest, indent=2) + "\n"
    if manifest_path.exists() and manifest_path.read_text() != encoded:
        raise RuntimeError("Existing manifest differs; choose a new destination.")
    manifest_path.write_text(encoded)
    print(json.dumps({"status": "downloaded", "destination": str(args.destination),
                      "bytes": sum(x["bytes"] for x in records)}), flush=True)


if __name__ == "__main__":
    main()
