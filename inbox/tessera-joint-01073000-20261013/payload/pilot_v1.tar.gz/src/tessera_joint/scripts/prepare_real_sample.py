"""Prepare one real 01073000 sample; cache source pixels, never latent embeddings."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from email.utils import parsedate_to_datetime
import hashlib
import json
from pathlib import Path
import sys

import fiona
import numpy as np
import pandas as pd
from pyproj import Transformer
import rasterio
from rasterio.windows import Window
import requests
from shapely.geometry import Point, mapping, shape
from shapely.ops import transform
import xarray as xr
import yaml

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
BASIN = "01073000"
ISSUE = pd.Timestamp("2024-04-01T00:00:00Z")
S2_KEYS = ["red", "blue", "green", "nir", "nir08", "rededge1", "rededge2", "rededge3", "swir16", "swir22"]
SOURCE_RUN = ROOT / "results/18_lstm_fair_531/lstm_cudalstm_maurer_s100_2026_0616_1513_ep30"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def seconds(value):
    return int(pd.Timestamp(value).timestamp())


def dump(path, value, reuse_identical=False):
    path = Path(path)
    if path.exists():
        if reuse_identical and json.loads(path.read_text(encoding="utf-8")) == json.loads(json.dumps(value)):
            return
        raise FileExistsError(path)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")


def cached_json(path, url, params):
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    response = requests.get(url, params=params, timeout=35)
    response.raise_for_status()
    payload = response.json()
    dump(path, payload)
    return payload


def prepare_satellite(out):
    source = out / "sources"
    source.mkdir(parents=True, exist_ok=True)
    if (out / "satellite_raw.npz").exists():
        raise FileExistsError("Use a new output directory; satellite samples already exist")
    shp = ROOT / "data/camelsh/shapefiles/CAMELSH_shapefile.shp"
    with fiona.open(shp) as collection:
        row = next(x for x in collection if x["properties"]["GAGE_ID"] == BASIN)
        geometry = shape(row["geometry"])
        properties = dict(row["properties"])
    # CAMELSH paper explicitly standardizes basin geometries to WGS84;
    # this local shapefile lacks a .prj declaration, so record that source.
    to_utm = Transformer.from_crs(4326, 32619, always_xy=True)
    to_geo = Transformer.from_crs(32619, 4326, always_xy=True)
    polygon = transform(to_utm.transform, geometry)
    rng = np.random.default_rng(20261013)
    points = []
    while len(points) < 8:
        x = rng.uniform(polygon.bounds[0], polygon.bounds[2])
        y = rng.uniform(polygon.bounds[1], polygon.bounds[3])
        x, y = np.floor(x / 10) * 10 + 5, np.floor(y / 10) * 10 + 5
        if polygon.contains(Point(x, y)) and (x, y) not in points:
            points.append((x, y))
    xy = np.array(points)
    lon, lat = to_geo.transform(xy[:, 0], xy[:, 1])
    coordinates = np.column_stack([lon, lat])
    dump(out / "sample_geometry.json", {
        "basin": BASIN, "boundary": mapping(geometry), "properties": properties,
        "source_shp": str(shp.relative_to(ROOT)), "source_shp_sha256": sha(shp),
        "source_crs": "EPSG:4326 per CAMELSH paper; local .prj absent",
        "sampling_crs": "EPSG:32619", "seed": 20261013,
        "method": "uniform rejection within projected basin, snapped to 10m pixel centers",
        "coordinates_lon_lat": coordinates.tolist(), "equal_weights": [1 / 8] * 8,
        "scope": "8 sampled points, not a complete basin image"}, reuse_identical=True)
    params = {"bbox": ",".join(str(x) for x in geometry.bounds),
              "datetime": "2024-03-01T00:00:00Z/2024-03-31T23:59:59Z", "limit": 100}
    s2 = cached_json(source / "earth_s2_march2024.json", "https://earth-search.aws.element84.com/v1/search",
                     dict(params, collections="sentinel-2-l2a"))["features"]
    s1 = cached_json(source / "pc_s1_march2024.json", "https://planetarycomputer.microsoft.com/api/stac/v1/search",
                     dict(params, collections="sentinel-1-rtc"))["features"]
    # Cloud metadata and geometry only; selection never uses flow labels.
    s2 = [x for x in s2 if shape(x["geometry"]).covers(geometry)
          and seconds(x["properties"]["created"]) < seconds(ISSUE)]
    s2 = sorted(s2, key=lambda x: (x["properties"]["eo:cloud_cover"], x["id"]))[:2]
    s2 = sorted(s2, key=lambda x: x["properties"]["datetime"])
    chosen = {"s2": s2}
    for stream, orbit in [("s1a", "ascending"), ("s1d", "descending")]:
        candidates = [x for x in s1 if x["properties"]["sat:orbit_state"] == orbit
                      and any(shape(x["geometry"]).covers(Point(*pt)) for pt in coordinates)]
        chosen[stream] = sorted(candidates, key=lambda x: x["properties"]["datetime"])[-2:]
    if not chosen["s2"] or not (chosen["s1a"] or chosen["s1d"]):
        raise ValueError("Need actual S2 and S1 observations in this bounded sample")
    dump(out / "selected_items.json", chosen, reuse_identical=True)
    tasks = [(stream, i, item, band) for stream, items in chosen.items() for i, item in enumerate(items)
             for band in (S2_KEYS + ["scl"] if stream == "s2" else ["vv", "vh"])]

    def fetch_asset(task):
        stream, i, item, band = task
        href = item["assets"][band]["href"]
        url = href
        if stream != "s2":
            response = requests.get("https://planetarycomputer.microsoft.com/api/sas/v1/sign",
                                    params={"href": href}, timeout=25)
            response.raise_for_status()
            url = response.json()["href"]
        head = requests.head(url, timeout=25)
        head.raise_for_status()
        headers = {k: head.headers[k] for k in ["Last-Modified", "ETag", "Content-Length", "x-ms-creation-time"]
                   if k in head.headers}
        # Take the latest available product/asset time, not acquisition+assumed delay.
        evidence_times = [parsedate_to_datetime(head.headers["Last-Modified"])]
        if stream == "s2":
            evidence_times += [pd.Timestamp(item["properties"]["created"])]
            if item["properties"].get("earthsearch:boa_offset_applied") is not True:
                raise ValueError("Expected already harmonized Earth Search optical COG")
        available = max(seconds(x) for x in evidence_times)
        if available > seconds(ISSUE):
            raise ValueError(f"Current product was modified after issue: {item['id']} {band}")
        with rasterio.Env(GDAL_DISABLE_READDIR_ON_OPEN="EMPTY_DIR", GDAL_HTTP_TIMEOUT="25",
                          GDAL_HTTP_MAX_RETRY="0", CPL_VSIL_CURL_ALLOWED_EXTENSIONS=".tif,.tiff"):
            with rasterio.open(url) as ds:
                convert = Transformer.from_crs(4326, ds.crs, always_xy=True)
                px, py = convert.transform(lon, lat)
                values = []
                for x, y in zip(px, py):
                    row, col = ds.index(x, y)
                    value = ds.read(1, window=Window(col, row, 1, 1), masked=True)
                    values.append(float(value[0, 0]) if value.size and not np.ma.getmaskarray(value)[0, 0] else np.nan)
                meta = {"stream": stream, "item": item["id"], "band": band, "href": href,
                        "headers": headers, "crs": str(ds.crs), "resolution": list(ds.res),
                        "resampling": "nearest native pixel at fixed sample coordinate",
                        "available_utc": pd.Timestamp(available, unit="s", tz="UTC").isoformat(),
                        "values": [v if np.isfinite(v) else None for v in values]}
        return stream, i, band, np.asarray(values, dtype=np.float32), available, meta

    cache = out / "pixel_cache"
    cache.mkdir(exist_ok=True)

    def read_asset(task):
        stream, i, _, band = task
        path = cache / f"{stream}_{i}_{band}.json"
        if path.exists():
            meta = json.loads(path.read_text(encoding="utf-8"))
            return stream, i, band, np.array([np.nan if x is None else x for x in meta["values"]],
                                             dtype=np.float32), seconds(meta["available_utc"]), meta
        for attempt in range(2):
            try:
                result = fetch_asset(task)
                dump(path, result[-1])
                print(f"sampled {stream} {i} {band}", flush=True)
                return result
            except (requests.RequestException, rasterio.errors.RasterioError) as exc:
                dump(cache / f"{stream}_{i}_{band}_attempt{attempt}_error.json", {"error": str(exc)})
                if attempt:
                    raise

    with ThreadPoolExecutor(max_workers=4) as pool:
        sampled = list(pool.map(read_asset, tasks))
    raw, arrays, records = {}, {"sat_weights": np.ones((1, 8), dtype=np.float32)}, []
    for stream, items in chosen.items():
        bands = S2_KEYS if stream == "s2" else ["vv", "vh"]
        if not items:
            raw[stream] = np.zeros((8, 0, len(bands)), dtype=np.float32)
            arrays["sat_" + stream] = raw[stream][None]
            for key, dtype in [("mask", bool), ("acquired", np.int64), ("available", np.int64), ("doy", np.float32)]:
                arrays[f"sat_{stream}_{key}"] = np.zeros((1, 8, 0), dtype=dtype)
            continue
        raw[stream] = np.stack([np.stack([next(x[3] for x in sampled if x[:3] == (stream, i, band))
                                        for band in bands], axis=-1) for i in range(len(items))], axis=1)
        valid = np.isfinite(raw[stream]).all(-1)
        if stream == "s2":
            scl = np.stack([next(x[3] for x in sampled if x[:3] == (stream, i, "scl"))
                            for i in range(len(items))], axis=1)
            raw["scl"] = scl
            # Stricter than upstream: also remove cirrus and snow/ice for this first sample.
            valid &= np.isin(scl, [4, 5, 6]) & (raw[stream] > 0).all(-1)
            native = np.nan_to_num(raw[stream], nan=0)
        else:
            valid &= (raw[stream] > 0).all(-1)
            # Match the pinned author's MPC RTC processor exactly. MPC describes
            # raw values as gamma0 intensity; upstream names the argument 'amp'.
            # No extra sqrt/10log10 conversion: that would change the pretrained input scale.
            native = np.zeros_like(raw[stream])
            native[valid] = np.clip((20 * np.log10(raw[stream][valid]) + 50) * 200, 0, 32767).astype(np.int16)
        acquired = np.array([seconds(x["properties"]["datetime"]) for x in items], dtype=np.int64)
        available = np.array([max(x[4] for x in sampled if x[0] == stream and x[1] == i)
                              for i in range(len(items))], dtype=np.int64)
        doys = np.array([pd.Timestamp(x["properties"]["datetime"]).dayofyear for x in items], dtype=np.float32)
        arrays["sat_" + stream] = native[None].astype(np.float32)
        for key, value in [("mask", valid), ("acquired", np.broadcast_to(acquired, valid.shape)),
                           ("available", np.broadcast_to(available, valid.shape)),
                           ("doy", np.broadcast_to(doys, valid.shape))]:
            arrays[f"sat_{stream}_{key}"] = value[None].copy()
        if not valid.any():
            raise ValueError(f"No valid real pixels in {stream}")
    records = [x[5] for x in sampled]
    np.savez_compressed(out / "satellite_raw.npz", **raw, coordinates_lon_lat=coordinates)
    np.savez_compressed(out / "satellite_native.npz", **arrays)
    dump(out / "satellite_manifest.json", {"basin": BASIN, "issue": ISSUE.isoformat(), "assets": records,
         "counts": {k: {"scenes": len(v), "valid_pixel_observations": int(arrays[f"sat_{k}_mask"].sum())}
                    for k, v in chosen.items()},
         "availability_basis": "latest STAC creation and current asset Last-Modified, all before issue; no assumed lag",
         "historical_public_release_audit": "asset existence evidence; no historical access log available",
         "s1_native_transform": "pinned author formula (20log10(raw_MPC_RTC)+50)*200 clipped int16; upstream amp label differs from provider intensity terminology",
         "s2_native_transform": "Earth Search already applies BOA offset; use raw harmonized reflectance*10000, no second offset",
         "sha256": {x: sha(out / x) for x in ["satellite_raw.npz", "satellite_native.npz", "selected_items.json", "sample_geometry.json"]}})


def prepare_hydrology(out):
    """UTC daily historical forcing and one independently retrieved USGS target."""
    from neuralhydrology.datasetzoo.camelsus import load_camels_us_attributes
    from neuralhydrology.utils.config import Config
    from tessera_joint.data import load_target_transform

    if (out / "real_sample.npz").exists():
        raise FileExistsError("Prepared sample already exists; use a new output directory")
    cfg = Config(SOURCE_RUN / "config.yml")
    scaler_path = SOURCE_RUN / "train_data/train_data_scaler.yml"
    scaler = yaml.safe_load(scaler_path.read_text(encoding="utf-8"))
    target_transform = load_target_transform(scaler_path, "QObs(mm/d)")
    met_path = ROOT / f"data/camelsh/time_series/{BASIN}.nc"
    original_path = ROOT / f"data/camelsh/timeseries/Data/CAMELSH/timeseries/{BASIN}.nc"
    start = ISSUE.tz_localize(None) - pd.Timedelta(days=cfg.seq_length)
    end = ISSUE.tz_localize(None)
    met_columns = ["Rainf", "Tair", "SWdown", "Qair", "PSurf"]
    with xr.open_dataset(met_path) as ds:
        met = ds[met_columns].sel(date=slice(start, end)).to_dataframe()
    with xr.open_dataset(original_path) as ds:
        original = ds[met_columns].sel(DateTime=slice(start, end)).to_dataframe()
    if not np.array_equal(met.index.values, original.index.values) or not np.array_equal(met.values, original.values):
        raise ValueError("Local renamed meteorology differs from original CAMELSH NetCDF")
    expected = pd.date_range(start, end, freq="h")
    if not met.index.equals(expected) or not np.isfinite(met.values).all():
        raise ValueError("History must have a complete finite hourly grid")
    if (met.Rainf < 0).any() or not met.Qair.between(0, 1, inclusive="neither").all():
        raise ValueError("Invalid precipitation or specific humidity")
    rows = []
    for day in pd.date_range(start, periods=cfg.seq_length, freq="D"):
        hourly = met.loc[day:day + pd.Timedelta(hours=23)]
        # NASA NLDAS-2 Table 3/8: Rainf is previous-hour accumulation;
        # other required variables are instantaneous at the indicated UTC hour.
        rain = met.Rainf.loc[day + pd.Timedelta(hours=1):day + pd.Timedelta(days=1)]
        if len(hourly) != 24 or len(rain) != 24:
            raise ValueError("Incomplete UTC day")
        vapor = hourly.Qair * hourly.PSurf / (0.622 + 0.378 * hourly.Qair)
        rows.append({"day_start_utc": day, "PRCP(mm/day)": rain.sum(), "Tmin(C)": hourly.Tair.min(),
                     "Tmax(C)": hourly.Tair.max(), "SRAD(W/m2)": hourly.SWdown.mean(), "Vp(Pa)": vapor.mean()})
    daily = pd.DataFrame(rows).set_index("day_start_utc")
    area_path = ROOT / f"data/camels_us/basin_mean_forcing/maurer/01/{BASIN}_lump_maurer_forcing_leap.txt"
    with area_path.open() as f:
        area_m2 = float([next(f) for _ in range(3)][2])
    if not 1e6 < area_m2 < 1e10:
        raise ValueError("Unexpected basin area")
    source = out / "sources"
    usgs = cached_json(source / "usgs_20240401.json", "https://waterservices.usgs.gov/nwis/iv/", {
        "format": "json", "sites": BASIN, "startDT": ISSUE.isoformat(),
        "endDT": (ISSUE + pd.Timedelta(days=1)).isoformat(), "parameterCd": "00060", "siteStatus": "all"})
    series = next(x for x in usgs["value"]["timeSeries"] if x["variable"]["variableCode"][0]["value"] == "00060")
    if series["variable"]["unit"]["unitCode"] != "ft3/s" or series["sourceInfo"]["siteCode"][0]["value"] != BASIN:
        raise ValueError("Unexpected USGS site or flow unit")
    values = series["values"][0]["value"]
    q = pd.Series([float(x["value"]) for x in values], index=pd.to_datetime([x["dateTime"] for x in values], utc=True))
    q = q.loc[(q.index >= ISSUE) & (q.index < ISSUE + pd.Timedelta(days=1))]
    if not q.index.equals(pd.date_range(ISSUE, periods=96, freq="15min")) or not np.isfinite(q.values).all() or (q < 0).any():
        raise ValueError("Single daily target requires all 96 valid quarter-hour records")
    q_m3s = q * 0.028316846592
    q_hourly = q_m3s.resample("h").mean()
    q_daily_mm = float(q_hourly.mean() * 86400 * 1000 / area_m2)
    hourly_path = ROOT / f"data/camelsh/hourly2/Hourly2/{BASIN}_hourly.nc"
    with xr.open_dataset(hourly_path) as ds:
        local_q = ds.streamflow.sel(time=slice(end, end + pd.Timedelta(hours=23))).values
        local_unit = ds.streamflow.attrs.get("units")
    if local_unit != "m3 s-1":
        raise ValueError("Unexpected local flow units")
    local_q_difference = float(np.max(np.abs(local_q - q_hourly.values)))
    attributes = load_camels_us_attributes(ROOT / "data/camels_us", [BASIN], list(cfg.static_attributes)).loc[BASIN]
    x_s = np.array([(attributes[k] - scaler["attribute_means"][k]) / scaler["attribute_stds"][k]
                    for k in cfg.static_attributes], dtype=np.float32)[None]
    x_d = np.column_stack([(daily[k] - scaler["xarray_feature_center"]["data_vars"][k]["data"]) /
                           scaler["xarray_feature_scale"]["data_vars"][k]["data"] for k in cfg.dynamic_inputs])[None].astype(np.float32)
    y = np.array([[[(q_daily_mm - target_transform["target_mean"]) / target_transform["target_std"]]]], dtype=np.float32)
    dates = pd.date_range(ISSUE - pd.Timedelta(days=cfg.seq_length - 1), periods=cfg.seq_length, freq="D")
    with np.load(out / "satellite_native.npz", allow_pickle=False) as sat:
        arrays = {k: sat[k].copy() for k in sat.files}
    arrays.update(x_d=x_d, x_s=x_s, y=y, basins=np.array([BASIN]),
                  per_basin_target_stds=np.ones((1, 1, 1), dtype=np.float32),
                  dynamic_times=np.array([[seconds(x) for x in dates]], dtype=np.int64),
                  issue_times=np.array([seconds(ISSUE)], dtype=np.int64),
                  target_times=np.array([seconds(ISSUE + pd.Timedelta(days=1))], dtype=np.int64),
                  context_index=np.array([cfg.seq_length - 1], dtype=np.int64))
    np.savez_compressed(out / "real_sample.npz", **arrays)
    daily.to_csv(out / "meteorology_daily_physical.csv")
    met.to_csv(out / "meteorology_hourly_source.csv")
    q_m3s.rename("flow_m3_s").to_csv(out / "usgs_target_15min.csv")
    q_hourly.rename("flow_m3_s").to_csv(out / "usgs_target_hourly.csv")
    metadata = {"kind": "real_daily_forecast", "purpose": "single_sample_retrospective_engineering_only",
        "dynamic_features": list(cfg.dynamic_inputs), "static_features": list(cfg.static_attributes),
        "lead_days": 1, "meteorological_information": "past_observed_only", "normalizer_sha256": sha(scaler_path),
        **target_transform, "time_semantics_verified": True, "radiometry_verified": True,
        "training_only_normalization_verified": True, "operational_replay_verified": False,
        "satellite_availability_evidence": "provider STAC creation and blob Last-Modified before issue; no historical access log",
        "historical_meteorology_product": "CAMELSH NLDAS-2 retrospective; historical publication latency not replayed",
        "per_basin_target_stds": "fixed 1 placeholder; this single-sample probe uses normalized MSE, never NSE training loss",
        "normalization_provenance": "unchanged source LSTM 531-basin training scaler; no statistics fitted to target day",
        "target_day_start_utc": ISSUE.isoformat(), "target_day_end_utc": (ISSUE + pd.Timedelta(days=1)).isoformat(),
        "observed_daily_flow_m3_s": float(q_hourly.mean()), "observed_daily_flow_mm_d": q_daily_mm,
        "basin_area_m2": area_m2, "area_source": str(area_path.relative_to(ROOT)),
        "source_binding": {"local_original_and_renamed_meteorology_exact_match": True,
            "local_meteorology_public_archive_byte_match": "not independently established",
            "usgs_target_records": 96, "usgs_target_complete_hours": 24,
            "usgs_qualifiers": sorted({v for x in values for v in x.get("qualifiers", [])}),
            "local_vs_current_usgs_hourly_max_abs_m3_s": local_q_difference,
            "target_source_choice": "current retrieved USGS records; historical local discrepancy retained, not corrected by guessed offset"},
        "conversion": {"Rainf": "kg/m2 hourly total = mm; sum times day 01:00 through next 00:00 (backward intervals)",
            "Tair": "CAMELSH already Celsius; min/max of 00:00..23:00 instantaneous samples",
            "SWdown": "mean of 24 hourly instantaneous samples, W/m2",
            "Vp": "hourly q*P/(0.622+0.378*q), Pa; then daily mean",
            "Q": "USGS ft3/s * 0.028316846592; UTC hourly means -> 24h mean *86400*1000/area_m2"},
        "product_shift": "NLDAS-2 in old-model physical units, not Maurer-equivalent forcing; SRAD uses 24h sample mean; no performance equivalence claimed",
        "source_files_sha256": {str(x.relative_to(ROOT)): sha(x) for x in [met_path, original_path, hourly_path, area_path,
            scaler_path, source / "usgs_20240401.json"]}}
    dump(out / "real_sample.json", metadata)
    dump(out / "data_manifest.json", {"status": "REAL_SINGLE_SAMPLE_PREPARED", "basin": BASIN,
        "sample_count": 1, "target_day": "2024-04-01", "history_days": cfg.seq_length,
        "rule_adjustments": ["2018 retrospective reprocessed satellite products not used; 2024 assets predate issue",
            "1 origin rather than up to 32; 8 fixed pixels", "one-basin MSE backward probe; A/B/C and held-out tests not run"],
        "limits": ["retrospective meteorology, not an operational replay", "single sample is not a skill estimate"],
        "files_sha256": {x: sha(out / x) for x in ["real_sample.npz", "real_sample.json", "satellite_manifest.json",
            "meteorology_daily_physical.csv", "meteorology_hourly_source.csv", "usgs_target_15min.csv"]}})
    print(f"REAL_SAMPLE_READY basin={BASIN} Q={q_daily_mm:.6f} mm/d", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--phase", choices=["satellite", "hydrology", "all"], default="all")
    args = parser.parse_args()
    args.output = args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=True)
    if args.phase in ["satellite", "all"]:
        prepare_satellite(args.output)
    if args.phase in ["hydrology", "all"]:
        prepare_hydrology(args.output)


if __name__ == "__main__":
    main()
