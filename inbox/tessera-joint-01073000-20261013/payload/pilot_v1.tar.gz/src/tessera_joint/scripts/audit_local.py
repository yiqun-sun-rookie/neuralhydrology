"""Read-only local artifact and 2017+ data audit; saves only a new audit directory."""
import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys

import numpy as np
import pandas as pd
import torch
import xarray as xr
import yaml


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def longest_constant(values):
    valid = np.isfinite(values) & (values >= 0)
    same = (values[1:] == values[:-1]) & valid[1:] & valid[:-1]
    positions = np.flatnonzero(np.r_[True, ~same, True])
    lengths = np.diff(positions)
    return int(lengths.max()) if lengths.size else 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    root = Path(__file__).resolve().parents[3]
    runs = [root / "results/18_lstm_fair_531/lstm_cudalstm_maurer_s100_2026_0616_1513_ep30",
            root / "results/05_adversarial_robustness/full_training_nse_2025_1025_1821_ep50"]
    artifacts = []
    for run in runs:
        cfg = yaml.safe_load((run / "config.yml").read_text())
        ckpt = run / "model_epoch030.pt"
        weights = torch.load(ckpt, map_location="cpu", weights_only=True)
        basin_path = root / cfg["train_basin_file"].replace("\\", "/")
        artifacts.append({"run": str(run), "config": cfg, "checkpoint": str(ckpt),
                          "checkpoint_sha256": digest(ckpt),
                          "config_sha256": digest(run / "config.yml"),
                          "scaler_sha256": digest(run / "train_data/train_data_scaler.yml"),
                          "shapes": {k: list(v.shape) for k, v in weights.items()},
                          "source_basin_file_exists": basin_path.exists(),
                          "source_basin_count": len(basin_path.read_text().split()) if basin_path.exists() else None,
                          "basin_file_sha256": digest(basin_path) if basin_path.exists() else None})
    source_ids = set((root / "src/xaj_global_pilot/configs/conceptual_benchmark_camels_us_531_repro.txt").read_text().split())
    met_root = root / "data/camelsh/time_series"
    available_ids = {p.stem for p in met_root.glob("*.nc")}
    info = pd.read_csv(root / "data/camelsh/info.csv", dtype={"STAID": str})
    info["STAID"] = info.STAID.str.zfill(8)
    years = [str(y) for y in range(2017, 2025)]
    # Coverage only, never prediction skill, determines audit candidates.
    covered = set(info.loc[(info[years] > 7000).all(axis=1), "STAID"]) & available_ids
    seen = sorted(covered & source_ids)[:4]
    unseen = sorted(covered - source_ids)[:3]
    candidates = seen + unseen
    rows = []
    schemas = {}
    for basin in candidates:
        path = met_root / f"{basin}.nc"
        with xr.open_dataset(path) as ds:
            dates = pd.DatetimeIndex(ds.date.values)
            schemas[basin] = {"path": str(path), "bytes": path.stat().st_size,
                              "start": str(dates[0]), "end": str(dates[-1]),
                              "global_attributes": ds.attrs,
                              "variable_attributes": {k: ds[k].attrs for k in ds.variables},
                              "hourly_index_contiguous": bool((np.diff(dates.asi8) == 3600 * 10**9).all())}
            for year in range(2017, 2025):
                sub = ds.sel(date=slice(f"{year}-01-01", f"{year}-12-31T23:00:00"))
                q = sub.Streamflow.values
                required = ["Tair", "Qair", "PSurf", "Rainf", "SWdown"]
                met = np.column_stack([sub[k].values for k in required])
                q_valid = np.isfinite(q) & (q >= 0)
                m_valid = np.isfinite(met).all(axis=1)
                joint = q_valid & m_valid
                daily = pd.Series(joint, index=pd.DatetimeIndex(sub.date.values)).resample("D").sum()
                rows.append({"basin": basin, "year": year, "seen_by_source_lstm": basin in source_ids,
                             "hours": len(q), "q_valid_hours": int(q_valid.sum()),
                             "q_missing_fraction": float(1 - q_valid.mean()),
                             "negative_q_count": int((np.isfinite(q) & (q < 0)).sum()),
                             "zero_q_count": int((q == 0).sum()), "met_valid_hours": int(m_valid.sum()),
                             "joint_valid_hours": int(joint.sum()), "complete_24h_days": int((daily == 24).sum()),
                             "longest_exact_constant_q_hours": longest_constant(q)})
    pd.DataFrame(rows).to_csv(args.output / "candidate_coverage.csv", index=False)
    camels_examples = {}
    for name in ["usgs_streamflow/01/01013500_streamflow_qc.txt",
                 "basin_mean_forcing/daymet/01/01013500_lump_cida_forcing_leap.txt"]:
        p = root / "data/camels_us" / name
        lines = p.read_text().splitlines()
        camels_examples[name] = {"first_lines": lines[:5], "last_line": lines[-1]}
    packages = {}
    for name in ["torch", "numpy", "pandas", "xarray", "netCDF4", "PyYAML", "scipy", "pytest",
                 "rasterio", "huggingface-hub", "neuralhydrology"]:
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    audit = {"status": "LOCAL_AUDIT_COMPLETE_REAL_EXPERIMENT_BLOCKED", "repo": str(root),
             "git_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
             "python": sys.version, "executable": sys.executable, "platform": platform.platform(),
             "packages": packages, "torch_cuda": torch.version.cuda,
             "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
             "checkpoints": artifacts, "classic_camels_examples": camels_examples,
             "camelsh": {"local_met_files": len(available_ids),
                         "local_hourly2_files": len(list((root / "data/camelsh/hourly2/Hourly2").glob("*.nc"))),
                         "coverage_screen_years": years, "coverage_screen_min_hours_each_year": 7001,
                         "coverage_screen_eligible": len(covered),
                         "candidate_train": seen, "candidate_validation": unseen[:1],
                         "candidate_test": unseen[1:], "schemas": schemas},
             "satellite_files_name_search": "No Sentinel/TESSERA source arrays found under data/; not a full binary-content scan.",
             "blockers": ["No matched raw S1/S2 samples with acquisition and availability timestamps",
                          "CAMELSH local NetCDF variables have no unit/timezone metadata; source-to-file provenance unresolved",
                          "NLDAS-to-source-Maurer feature semantics/scaling need a declared harmonization recipe",
                          "No archived operational meteorological forecasts; future observed forcing is an oracle track only"]}
    (args.output / "audit.json").write_text(json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8")
    (args.output / "environment_versions.json").write_text(json.dumps(packages, indent=2), encoding="utf-8")
    print(json.dumps({"status": audit["status"], "candidate_train": seen,
                      "candidate_validation": unseen[:1], "candidate_test": unseen[1:],
                      "coverage_eligible": len(covered), "rows": len(rows)}))


if __name__ == "__main__":
    main()
