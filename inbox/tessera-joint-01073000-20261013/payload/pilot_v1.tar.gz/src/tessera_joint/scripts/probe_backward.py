"""Synthetic engineering probe using real official and existing regional checkpoints."""
import argparse
import copy
import gc
import importlib.util
import json
from pathlib import Path
import sys
import time

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
from neuralhydrology.training import get_loss_obj
from tessera_joint.model import JointRegional, SatelliteEncoder, load_official, load_regional


def synthetic_batch(regional, module, batch=1, pixels=8, observations=24, device="cuda"):
    cfg = regional.cfg
    length = cfg.seq_length
    end = 1577836800  # 2020-01-01 00:00 UTC; labels strictly after issue.
    times = end - torch.arange(length - 1, -1, -1, device=device)[None, :] * 86400
    times = times.expand(batch, -1)
    satellite = {"weights": torch.ones(batch, pixels, device=device)}
    for source, mean, std, count in [
        ("s2", module.S2_BAND_MEAN, module.S2_BAND_STD, observations),
        ("s1a", module.S1A_BAND_MEAN, module.S1A_BAND_STD, max(1, observations // 2)),
        ("s1d", module.S1D_BAND_MEAN, module.S1D_BAND_STD, max(1, observations // 2))]:
        shape = (batch, pixels, count)
        mean = torch.as_tensor(mean, device=device)
        std = torch.as_tensor(std, device=device)
        satellite[source] = mean + torch.randn(*shape, len(mean), device=device) * std * 0.2
        acquired = end - torch.arange(count, 0, -1, device=device)[None, None, :] * 86400
        satellite[source + "_acquired"] = acquired.expand(shape).clone()
        satellite[source + "_available"] = (acquired + 3600).expand(shape).clone()
        satellite[source + "_doy"] = (torch.arange(count, device=device)[None, None, :] + 300).expand(shape)
        satellite[source + "_mask"] = torch.ones(shape, dtype=torch.bool, device=device)
    return {"x_d": {k: torch.randn(batch, length, 1, device=device) for k in cfg.dynamic_inputs},
            "x_s": torch.zeros(batch, len(cfg.static_attributes), device=device),
            "satellite": satellite, "context_index": torch.full((batch,), length - 1, device=device),
            "dynamic_times": times, "issue_times": times[:, -1], "target_times": times[:, -1] + 86400,
            "y": torch.randn(batch, 1, 1, device=device),
            "per_basin_target_stds": torch.ones(batch, 1, 1, device=device)}


def verify_preprocessing(satellite_encoder, module, official_folder):
    spec = importlib.util.spec_from_file_location("official_tessera_infer", Path(official_folder) / "infer.py")
    infer = importlib.util.module_from_spec(spec)
    sys.modules["model"] = module
    spec.loader.exec_module(infer)
    regional = load_regional(SOURCE / "config.yml")
    data = synthetic_batch(regional, module, observations=13)
    sat = data["satellite"]
    # Check ragged valid observations and repeat/bin behavior, not just all-valid data.
    sat["s2_mask"][0, 1, ::2] = False
    sat["s1a"][0, 2] = 0
    sat["s1a_mask"][0, 2] = False
    with torch.no_grad():
        actual = satellite_encoder(sat, data["issue_times"])
    cpu = {k: v[0].cpu().numpy() for k, v in sat.items()}
    expected = infer.encode_pixels(satellite_encoder.encoder, cpu["s2"], cpu["s2_doy"],
                                   cpu["s1a"], cpu["s1a_doy"], cpu["s1d"], cpu["s1d_doy"],
                                   s2_masks=cpu["s2_mask"], device=torch.device("cuda"))
    parity_error = float(np.max(np.abs(expected.mean(0) - actual[0].cpu().numpy())))
    if parity_error > 1e-4:
        raise AssertionError(f"Official preprocessing mismatch: {parity_error}")
    # A frame acquired before issue but available afterwards must be excluded.
    modified = copy.deepcopy(sat)
    modified["s2_available"][:, :, -1] = data["issue_times"][:, None] + 1
    with torch.no_grad():
        before = satellite_encoder(modified, data["issue_times"])
        modified["s2"][:, :, -1] += 100000
        after = satellite_encoder(modified, data["issue_times"])
    causal_error = float((before - after).abs().max())
    if causal_error != 0:
        raise AssertionError("Post-cutoff availability affected encoding")
    missing = copy.deepcopy(sat)
    for source in ["s2", "s1a", "s1d"]:
        missing[source + "_mask"].zero_()
    try:
        satellite_encoder(missing, data["issue_times"])
    except ValueError:
        all_missing_rejected = True
    else:
        raise AssertionError("All-missing sample admitted")
    del regional, data
    return {"official_inference_parity_max_abs": parity_error,
            "late_available_frame_perturbation_max_abs": causal_error,
            "all_missing_sample_rejected": all_missing_rejected}


def probe(folder, batch, pixels, observations, amp=True):
    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    free_before, total = torch.cuda.mem_get_info()
    encoder, module, cfg = load_official(folder, "cuda")
    regional = load_regional(SOURCE / "config.yml", SOURCE / "model_epoch030.pt", "cuda")
    loss_fn = get_loss_obj(regional.cfg)
    data = synthetic_batch(regional, module, batch, pixels, observations)
    original = {k: v.clone() for k, v in regional.lstm.state_dict().items()}
    regional.eval()
    with torch.no_grad():
        prediction_before = regional(data)["y_hat"]
    model = JointRegional(regional, SatelliteEncoder(encoder, module)).cuda()
    model.eval()
    with torch.no_grad():
        prediction_after = model(data)["y_hat"]
    preservation = float((prediction_before - prediction_after).abs().max())
    assert torch.equal(original["weight_ih_l0"], model.regional.lstm.weight_ih_l0[:, :32])
    for key in ["weight_hh_l0", "bias_ih_l0", "bias_hh_l0"]:
        assert torch.equal(original[key], model.regional.lstm.state_dict()[key])
    assert preservation < 1e-5
    start = time.perf_counter()
    model.train()
    opt = model.optimizer()
    scaler = torch.cuda.amp.GradScaler(enabled=amp, init_scale=1024)
    frozen_before = {k: v.detach().clone() for k, v in encoder.named_parameters()}
    stage1_losses = []
    # Zero-init RS columns preserve the old model exactly; two updates establish
    # a nonzero RS-to-LSTM pathway before checking encoder gradients.
    for _ in range(2):
        opt.zero_grad(set_to_none=True)
        with torch.autocast("cuda", dtype=torch.float16, enabled=amp):
            loss, _ = loss_fn(model(data), data)
        scaler.scale(loss).backward()
        scaler.unscale_(opt)
        torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 1)
        scaler.step(opt)
        scaler.update()
        stage1_losses.append(float(loss.detach()))
    assert all(p.grad is None for p in encoder.parameters())
    frozen_drift = max(float((p - frozen_before[k]).abs().max()) for k, p in encoder.named_parameters())
    assert frozen_drift == 0
    rs_weight_norm = float(model.regional.lstm.weight_ih_l0[:, 32:].norm())
    if rs_weight_norm == 0:
        raise AssertionError(f"Stage1 did not update the RS pathway; AMP scale={scaler.get_scale()}")
    model.set_stage("partial", last_layers=1)
    opt = model.optimizer(regional_lr=1e-4, encoder_lr=1e-6)
    before = {k: p.detach().clone() for k, p in encoder.named_parameters()}
    opt.zero_grad(set_to_none=True)
    # Two equal microbatches explicitly exercise accumulation.
    for _ in range(2):
        with torch.autocast("cuda", dtype=torch.float16, enabled=amp):
            loss, _ = loss_fn(model(data), data)
        scaler.scale(loss / 2).backward()
    scaler.unscale_(opt)
    grads = {k: {"norm": float(p.grad.float().norm()), "nonzero": int(torch.count_nonzero(p.grad)),
                 "finite": bool(torch.isfinite(p.grad).all())}
             for k, p in encoder.named_parameters() if p.requires_grad and p.grad is not None}
    assert grads and all(v["finite"] for v in grads.values())
    assert any(v["nonzero"] > 0 for k, v in grads.items() if "s2_backbone.transformer_encoder" in k)
    assert any(v["nonzero"] > 0 for k, v in grads.items() if "s1_backbone.transformer_encoder" in k)
    torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 1)
    scaler.step(opt)
    scaler.update()
    delta = {k: float((p - before[k]).abs().max()) for k, p in encoder.named_parameters() if p.requires_grad}
    frozen_changes = {k: float((p - before[k]).abs().max()) for k, p in encoder.named_parameters() if not p.requires_grad}
    assert max(frozen_changes.values()) == 0
    assert any(v > 0 for k, v in delta.items() if "s2_backbone.transformer_encoder" in k)
    assert any(v > 0 for k, v in delta.items() if "s1_backbone.transformer_encoder" in k)
    torch.cuda.synchronize()
    result = {"kind": "SYNTHETIC_ENGINEERING_ONLY_NOT_HYDROLOGICAL_SKILL", "batch": batch,
              "pixels_per_basin": pixels, "s2_observations": observations,
              "s1_merged_observations": max(1, observations // 2) * 2, "lstm_sequence": 270,
              "amp_dtype": "float16" if amp else "float32", "gradient_accumulation": 2,
              "official_parameters": sum(p.numel() for p in encoder.parameters()),
              "trainable_encoder_parameters": sum(p.numel() for p in encoder.parameters() if p.requires_grad),
              "source_input_weight_preserved": True, "initial_prediction_max_abs_diff": preservation,
              "stage1_frozen_encoder_max_drift": frozen_drift,
              "stage1_rs_input_weight_norm": rs_weight_norm,
              "stage1_synthetic_losses": stage1_losses, "stage2_synthetic_loss": float(loss.detach()),
              "stage2_flow_only_gradients": grads, "stage2_encoder_parameter_max_deltas": delta,
              "still_frozen_max_drift": max(frozen_changes.values()),
              "peak_allocated_mib": torch.cuda.max_memory_allocated() / 1024**2,
              "peak_reserved_mib": torch.cuda.max_memory_reserved() / 1024**2,
              "device_free_before_mib": free_before / 1024**2, "device_total_mib": total / 1024**2,
              "elapsed_seconds_stage1_plus_stage2": time.perf_counter() - start}
    del model, encoder, opt, data, before, frozen_before
    return result


SOURCE = ROOT / "results/18_lstm_fair_531/lstm_cudalstm_maurer_s100_2026_0616_1513_ep30"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--official", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(8)
    torch.manual_seed(20261012)
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for the requested resource probe")
    result = {"gpu": torch.cuda.get_device_name(0), "torch": torch.__version__,
              "cuda": torch.version.cuda, "status": "RUNNING", "probes": []}
    try:
        encoder, module, _ = load_official(args.official, "cuda")
        satellite = SatelliteEncoder(encoder, module).cuda().eval()
        result["preprocessing"] = verify_preprocessing(satellite, module, args.official)
        del satellite, encoder
        for batch, pixels, observations in [(1, 8, 24), (2, 32, 64)]:
            report = probe(args.official, batch, pixels, observations)
            result["probes"].append(report)
            (args.output / "probe.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
            print(json.dumps({k: report[k] for k in ["batch", "pixels_per_basin", "peak_allocated_mib",
                                                    "peak_reserved_mib", "trainable_encoder_parameters"]}), flush=True)
        result["status"] = "PASS_SYNTHETIC_BACKWARD_REAL_PERFORMANCE_NOT_RUN"
    except Exception as exc:
        result["status"] = "FAILED"
        result["error"] = repr(exc)
        raise
    finally:
        (args.output / "probe.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(result["status"])


if __name__ == "__main__":
    main()
