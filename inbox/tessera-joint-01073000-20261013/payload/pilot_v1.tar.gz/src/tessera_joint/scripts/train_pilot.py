"""Paired A/B/C pilot: same batches/budgets; C and B fork from identical frozen-stage weights."""
import argparse
import copy
import csv
import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader
import xarray as xr

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
from neuralhydrology.evaluation.metrics import kge, nse
from neuralhydrology.training import get_loss_obj
from tessera_joint.data import (PreparedForecasts, checked_target_transform, load_target_transform,
                               to_device, verify_splits, verify_target_periods, verify_target_transform)
from tessera_joint.model import JointRegional, SatelliteEncoder, load_official, load_regional


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def evaluate(model, dataset, batch_size, loss_fn, device):
    model.eval()
    losses, weights, records = [], [], []
    with torch.no_grad():
        for data in DataLoader(dataset, batch_size=batch_size, shuffle=False):
            data = to_device(data, device)
            output = model(data)
            required = torch.isfinite(data["y"][:, -1, 0])
            bad = required & ~torch.isfinite(output["y_hat"][:, -1, 0])
            if bad.any():
                raise ValueError(f"Nonfinite prediction on {int(bad.sum())} required evaluation targets")
            loss, _ = loss_fn(output, data)
            losses.append(float(loss))
            weights.append(len(data["basin"]))
            pred = output["y_hat"][:, -1, 0].float().cpu().numpy()
            obs = data["y"][:, -1, 0].float().cpu().numpy()
            for i, basin in enumerate(data["basin"]):
                records.append({"basin": basin, "target_time": int(data["target_times"][i]),
                                "pred_normalized": float(pred[i]), "obs_normalized": float(obs[i])})
    return float(np.average(losses, weights=weights)), records


def verify_evaluation_targets(records, dataset):
    """Every arm must retain the dataset's same keys and observed target values."""
    a = dataset.arrays
    expected = {(str(b), int(t)): float(y) for b, t, y in
                zip(a["basins"], a["target_times"], a["y"][:, -1, 0].astype(np.float32))}
    actual = {(r["basin"], r["target_time"]): r["obs_normalized"] for r in records}
    if len(records) != len(expected) or set(actual) != set(expected):
        raise ValueError("Evaluation target keys differ from the common dataset")
    if any(not (actual[k] == v or (np.isnan(actual[k]) and np.isnan(v))) for k, v in expected.items()):
        raise ValueError("Evaluation observations differ from the common dataset")


def train_phase(model, train, validation, settings, phase, out, loss_fn, device):
    torch.manual_seed(settings["seed"] + phase)
    stage = "partial" if model.satellite is not None and model.stage == "partial" else "frozen"
    model.set_stage(stage, settings.get("last_layers", 1))
    optimizer = model.optimizer(settings["regional_lr"], settings["encoder_lr"])
    scaler = torch.cuda.amp.GradScaler(enabled=settings["amp"], init_scale=1024)
    reference = model.pretrained_reference() if stage == "partial" else {}
    best, best_state, history = float("inf"), None, []
    updates, skipped, stale = 0, 0, 0
    start = time.perf_counter()
    torch.cuda.reset_peak_memory_stats()
    for epoch in range(settings[f"stage{phase}_epochs"]):
        generator = torch.Generator().manual_seed(settings["seed"] + epoch)
        loader = DataLoader(train, batch_size=settings["batch_size"], shuffle=True, generator=generator, num_workers=0)
        model.train()
        optimizer.zero_grad(set_to_none=True)
        batches = len(loader)
        for i, data in enumerate(loader):
            data = to_device(data, device)
            accumulation = settings["accumulation"]
            group_size = min(accumulation, batches - (i // accumulation) * accumulation)
            with torch.autocast("cuda", dtype=torch.float16, enabled=settings["amp"]):
                flow_loss, _ = loss_fn(model(data), data)
                loss = flow_loss + (settings.get("l2sp", 0) * model.l2sp(reference) if reference else 0)
            if not torch.isfinite(loss):
                raise RuntimeError("Nonfinite training loss")
            scaler.scale(loss / group_size).backward()
            if (i + 1) % accumulation == 0 or i + 1 == batches:
                scaler.unscale_(optimizer)
                if stage == "partial" and updates == 0:
                    # Check the flow pathway even with L2-SP (its initial gradient is zero).
                    active = [p for name, p in model.satellite.named_parameters()
                              if "transformer_encoder" in name and p.requires_grad]
                    if not any(p.grad is not None and torch.isfinite(p.grad).all() and p.grad.abs().sum() > 0 for p in active):
                        raise RuntimeError("No finite nonzero flow gradient reached the unfrozen encoder")
                torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 1)
                old_scale = scaler.get_scale()
                scaler.step(optimizer)
                scaler.update()
                was_skipped = scaler.get_scale() < old_scale
                skipped += int(was_skipped)
                updates += int(not was_skipped)
                optimizer.zero_grad(set_to_none=True)
        val_loss, _ = evaluate(model, validation, settings["batch_size"], loss_fn, device)
        if not np.isfinite(val_loss):
            raise RuntimeError("Nonfinite validation loss")
        history.append({"epoch": epoch + 1, "validation_loss": val_loss, "updates": updates, "amp_skipped": skipped})
        if val_loss < best:
            best, stale = val_loss, 0
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else:
            stale += 1
        if settings.get("patience") and stale >= settings["patience"]:
            break
    if best_state is None:
        raise RuntimeError("No stage checkpoint was selected")
    model.load_state_dict(best_state)
    if phase == 1 and model.satellite is not None and model.regional.lstm.weight_ih_l0[:, -model.rs_width:].abs().sum() == 0:
        raise RuntimeError("Frozen stage never established an RS-to-recurrence pathway")
    torch.save({"model": best_state, "best_validation_loss": best, "phase": phase}, out / f"stage{phase}_best.pt")
    report = {"best_validation_loss": best, "epochs": len(history), "optimizer_updates": updates,
              "amp_skipped_updates": skipped, "seconds": time.perf_counter() - start,
              "peak_allocated_mib": torch.cuda.max_memory_allocated() / 1024**2,
              "peak_reserved_mib": torch.cuda.max_memory_reserved() / 1024**2, "history": history}
    (out / f"stage{phase}.json").write_text(json.dumps(report, indent=2))
    return report


def metrics(records, meta):
    transform = checked_target_transform(meta)
    result = []
    for basin in sorted({r["basin"] for r in records}):
        rows = sorted([r for r in records if r["basin"] == basin], key=lambda r: r["target_time"])
        times = np.array([r["target_time"] for r in rows])
        obs = np.array([r["obs_normalized"] for r in rows])
        pred = np.array([r["pred_normalized"] for r in rows])
        keep = np.isfinite(obs)
        bad = keep & ~np.isfinite(pred)
        if bad.any():
            raise ValueError(f"Nonfinite prediction on {int(bad.sum())} required evaluation targets in {basin}")
        obs, pred, times = obs[keep], pred[keep], times[keep]
        obs = obs * transform["target_std"] + transform["target_mean"]
        pred = pred * transform["target_std"] + transform["target_mean"]
        if not np.isfinite(obs).all() or not np.isfinite(pred).all():
            raise ValueError("Nonfinite physical target after inverse normalization")
        item = {"basin": basin, "lead_days": meta["lead_days"], "n_targets": len(obs),
                "n_missing_observations": int((~keep).sum()), "nonfinite_predictions": 0,
                "NSE": None, "KGE": None, "high_flow_bias_percent": None, "high_flow_rmse": None,
                "peak_timing_mae_days": None, "peak_amplitude_mape_percent": None, "n_peaks": 0,
                "n_peak_candidates": 0, "n_peaks_excluded_boundary": 0}
        if len(obs) >= 2 and np.std(obs) > 0:
            observed = xr.DataArray(obs, coords={"date": times.astype("datetime64[s]")}, dims=["date"])
            simulated = xr.DataArray(pred, coords=observed.coords, dims=observed.dims)
            item["NSE"] = nse(observed, simulated)
            item["KGE"] = kge(observed, simulated) if np.std(pred) > 0 and obs.mean() != 0 else None
            high = obs >= np.quantile(obs, 0.95)
            item["high_flow_rmse"] = float(np.sqrt(np.mean((pred[high] - obs[high])**2)))
            item["high_flow_bias_percent"] = float(100 * (pred[high] - obs[high]).sum() / obs[high].sum()) if obs[high].sum() else None
            # Gaps split the hydrograph; only complete seven-day event windows count.
            from scipy.signal import find_peaks
            if (np.diff(times) <= 0).any():
                raise ValueError("Duplicate or unordered target timestamps")
            segments = np.split(np.arange(len(times)), np.flatnonzero(np.diff(times) != 86400) + 1)
            errors, timing = [], []
            threshold = np.quantile(obs, 0.95)
            for segment in segments:
                peaks, _ = find_peaks(obs[segment], height=threshold, distance=7)
                candidates = [p for p in peaks if obs[segment[p]] > 0]
                eligible = [p for p in candidates if p >= 3 and p + 3 < len(segment)]
                item["n_peak_candidates"] += len(candidates)
                item["n_peaks_excluded_boundary"] += len(candidates) - len(eligible)
                for p in eligible:
                    window = pred[segment[p - 3:p + 4]]
                    errors.append(abs(window.max() - obs[segment[p]]) / obs[segment[p]])
                    timing.append(abs(int(np.argmax(window)) - 3))
            item["n_peaks"] = len(errors)
            item["peak_timing_mae_days"] = float(np.mean(timing)) if timing else None
            item["peak_amplitude_mape_percent"] = float(100 * np.mean(errors)) if errors else None
        result.append(item)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--synthetic-engineering", action="store_true")
    args = parser.parse_args()
    settings = json.loads(args.config.read_text())
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output / "config_snapshot.json").write_text(json.dumps(settings, indent=2))
    report = {"kind": "synthetic_engineering" if args.synthetic_engineering else "real_daily_forecast",
              "status": "RUNNING", "arms": {}}
    try:
        if settings.get("data_status") != "ready":
            report["status"] = "BLOCKED_DATA_PREPARATION"
            report["blockers"] = settings["blockers"]
            print(json.dumps(report))
            return
        device = "cuda"
        torch.set_num_threads(8)
        source = ROOT / settings["source_run"]
        checkpoint = source / settings["source_checkpoint"]
        official = ROOT / settings["official_folder"]
        regional = load_regional(source / "config.yml", checkpoint)
        train, validation, test = [PreparedForecasts(ROOT / settings[k], regional.cfg, args.synthetic_engineering)
                                   for k in ["train_npz", "validation_npz", "test_npz"]]
        source_basin_path = ROOT / str(regional.cfg.train_basin_file).replace("\\", "/")
        verify_splits(train, validation, test, source_basin_path.read_text().split())
        datasets = dict(zip(["train", "validation", "test"], [train, validation, test]))
        verify_target_periods(datasets, settings["target_day_ranges"])
        normalizer = ROOT / settings["normalizer_file"]
        if train.meta["normalizer_sha256"] != file_hash(normalizer):
            raise ValueError("Prepared dataset normalizer does not match the pinned normalizer file")
        if len(regional.cfg.target_variables) != 1:
            raise ValueError("This pilot requires a single scalar target")
        transform = load_target_transform(normalizer, regional.cfg.target_variables[0])
        for dataset in datasets.values():
            verify_target_transform(dataset.meta, transform)
        report["target_transform"] = transform
        report["target_day_ranges"] = settings["target_day_ranges"]
        report["input_hashes"] = {"checkpoint": file_hash(checkpoint),
                                  "source_config": file_hash(source / "config.yml"),
                                  "source_basins": file_hash(source_basin_path),
                                  "normalizer": file_hash(normalizer),
                                  "official_checkpoint": file_hash(official / "ckpt/student_small.pt"),
                                  **{k: file_hash(ROOT / settings[k]) for k in ["train_npz", "validation_npz", "test_npz"]},
                                  **{k.replace("_npz", "_metadata"): file_hash((ROOT / settings[k]).with_suffix(".json"))
                                     for k in ["train_npz", "validation_npz", "test_npz"]}}
        snapshots = args.output / "dataset_metadata"
        snapshots.mkdir()
        for name, dataset in datasets.items():
            (snapshots / f"{name}.json").write_text(json.dumps(dataset.meta, indent=2), encoding="utf-8")
        loss_fn = get_loss_obj(regional.cfg)
        arm_a = JointRegional(regional.to(device))
        torch.manual_seed(settings["seed"])
        encoder, module, _ = load_official(official, device)
        arm_b = JointRegional(load_regional(source / "config.yml", checkpoint, device),
                              SatelliteEncoder(encoder, module)).to(device)
        for name, model in [("A", arm_a), ("B", arm_b)]:
            out = args.output / name
            out.mkdir()
            report["arms"][name] = {"stage1": train_phase(model, train, validation, settings, 1, out, loss_fn, device)}
        arm_c = copy.deepcopy(arm_b).to(device)
        arm_c.set_stage("partial", settings["last_layers"])
        out_c = args.output / "C"
        out_c.mkdir()
        report["arms"]["C"] = {"stage1": report["arms"]["B"]["stage1"], "stage1_shared_with_B": True}
        # All selections are now on validation. Test is evaluated once per arm.
        for name, model in [("A", arm_a), ("B", arm_b), ("C", arm_c)]:
            out = args.output / name
            report["arms"][name]["stage2"] = train_phase(model, train, validation, settings, 2, out, loss_fn, device)
        for name, model in [("A", arm_a), ("B", arm_b), ("C", arm_c)]:
            _, records = evaluate(model, test, settings["batch_size"], loss_fn, device)
            verify_evaluation_targets(records, test)
            out = args.output / name
            if not args.synthetic_engineering:
                np.savez_compressed(out / "test_predictions.npz", **{k: np.array([r[k] for r in records]) for k in records[0]})
                report["arms"][name]["metrics"] = metrics(records, {"lead_days": test.meta["lead_days"], **transform})
            else:
                report["arms"][name]["metrics"] = "NOT_APPLICABLE_SYNTHETIC_DATA"
        report["status"] = "PASS_SYNTHETIC_ABC_RUNNER" if args.synthetic_engineering else "PILOT_COMPLETE_NO_WIN_CLAIM"
        print(report["status"])
    except Exception as exc:
        report["status"], report["error"] = "FAILED", repr(exc)
        raise
    finally:
        (args.output / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
        with (args.output / "registry.csv").open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["exp_id", "kind", "status", "run_dir"])
            writer.writeheader()
            for name in ["A", "B", "C"]:
                writer.writerow({"exp_id": f"TJ00-{name}-s{settings['seed']}", "kind": report["kind"],
                                 "status": report["status"], "run_dir": str(args.output / name)})


if __name__ == "__main__":
    main()
