"""Prepared raw-pixel forecast batches, with explicit issue times and basin provenance."""
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
import yaml
from torch.utils.data import Dataset


def checked_target_transform(values):
    """Validate the scalar affine target transform, without changing its values."""
    try:
        mean, std = float(values["target_mean"]), float(values["target_std"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("Missing or invalid scalar target transform") from exc
    if not np.isfinite(mean) or not np.isfinite(std) or std <= 0:
        raise ValueError("Target mean must be finite and target std must be finite and positive")
    return {"target_mean": mean, "target_std": std}


def load_target_transform(normalizer_file, target_name):
    """Read the authoritative target transform from a pinned NH scaler file."""
    payload = yaml.safe_load(Path(normalizer_file).read_text(encoding="utf-8"))
    try:
        values = []
        for field in ["xarray_feature_center", "xarray_feature_scale"]:
            entry = payload[field]["data_vars"][target_name]
            if entry["dims"] != [] or np.asarray(entry["data"]).ndim != 0:
                raise ValueError("Only scalar target normalization is supported")
            values.append(entry["data"])
    except (KeyError, TypeError) as exc:
        raise ValueError(f"Normalizer has no scalar transform for {target_name}") from exc
    return checked_target_transform(dict(zip(["target_mean", "target_std"], values)))


def verify_target_transform(metadata, transform):
    declared, fixed = checked_target_transform(metadata), checked_target_transform(transform)
    if any(not np.isclose(declared[k], fixed[k], rtol=1e-6, atol=1e-8) for k in fixed):
        raise ValueError("Dataset target transform differs from the pinned normalizer")


def verify_target_periods(datasets, target_day_ranges):
    """Check UTC target-day starts against ordered, left-closed/right-open ranges."""
    names = ["train", "validation", "test"]
    if set(datasets) != set(names) or set(target_day_ranges) != set(names):
        raise ValueError("Declare target day ranges for train, validation and test")
    previous_end = None
    for name in names:
        try:
            bounds = target_day_ranges[name]
            start, end = [int(datetime.strptime(bounds[k], "%Y-%m-%d").replace(
                tzinfo=timezone.utc).timestamp()) for k in ["start", "end_exclusive"]]
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"Invalid UTC target day range for {name}") from exc
        if start >= end or (previous_end is not None and start < previous_end):
            raise ValueError("Target day ranges must be ordered and nonoverlapping")
        previous_end = end
        targets = np.asarray(datasets[name].arrays["target_times"])
        if targets.ndim != 1 or not len(targets) or not np.issubdtype(targets.dtype, np.integer):
            raise ValueError(f"Invalid target timestamps for {name}")
        if (targets % 86400 != 0).any():
            raise ValueError("Daily targets must end at UTC midnight")
        # The target averaging day ends at target_times, rather than starts there.
        days = targets.astype(np.int64) - 86400
        outside = (days < start) | (days >= end)
        if outside.any():
            raise ValueError(f"{name}: {int(outside.sum())} target days outside the declared range")


class PreparedForecasts(Dataset):
    def __init__(self, path, cfg, allow_synthetic=False):
        path = Path(path)
        self.meta = json.loads(path.with_suffix(".json").read_text(encoding="utf-8"))
        if self.meta["kind"] == "synthetic_engineering":
            if not allow_synthetic:
                raise ValueError("Synthetic data cannot be admitted as a real experiment")
        elif self.meta["kind"] == "real_daily_forecast":
            for field in ["time_semantics_verified", "radiometry_verified", "training_only_normalization_verified"]:
                if self.meta.get(field) is not True:
                    raise ValueError(f"Data preparation is incomplete: {field}")
        else:
            raise ValueError("Unknown prepared dataset kind")
        checked_target_transform(self.meta)
        if self.meta["dynamic_features"] != list(cfg.dynamic_inputs):
            raise ValueError("Forcing columns/order differ from the regional checkpoint config")
        if self.meta["static_features"] != list(cfg.static_attributes):
            raise ValueError("Static columns/order differ from the regional checkpoint config")
        if self.meta["meteorological_information"] != "past_observed_only":
            raise ValueError("This minimal runner implements the past-forcing-only forecast track")
        with np.load(path, allow_pickle=False) as source:
            self.arrays = {k: source[k].copy() for k in source.files}
        a = self.arrays
        n, length, width = a["x_d"].shape
        if not n or length != cfg.seq_length or width != len(cfg.dynamic_inputs):
            raise ValueError("Unexpected forcing shape")
        if a["x_s"].shape != (n, len(cfg.static_attributes)) or a["y"].shape != (n, 1, 1):
            raise ValueError("Unexpected static/target shape")
        if not np.isfinite(a["x_d"]).all() or not np.isfinite(a["x_s"]).all():
            raise ValueError("Prepared forcings/statics must be finite")
        if a["dynamic_times"].shape != (n, length):
            raise ValueError("Missing forcing timestamps")
        for key in ["issue_times", "target_times", "context_index"]:
            if a[key].shape != (n,) or not np.issubdtype(a[key].dtype, np.integer):
                raise ValueError(f"Invalid integer sample field: {key}")
        if not np.issubdtype(a["dynamic_times"].dtype, np.integer):
            raise ValueError("Forcing timestamps must be integer UTC seconds")
        if (np.diff(a["dynamic_times"], axis=1) != 86400).any():
            raise ValueError("This runner requires a regular daily forcing sequence")
        if (a["dynamic_times"] > a["issue_times"][:, None]).any():
            raise ValueError("Future observed meteorology entered a forecast input")
        if not np.array_equal(a["dynamic_times"][:, -1], a["issue_times"]):
            raise ValueError("Last history timestamp must equal issue time")
        lead = int(self.meta["lead_days"])
        if lead <= 0 or not np.array_equal(a["target_times"] - a["issue_times"], np.full(n, lead * 86400)):
            raise ValueError("Target must occur strictly after issue, at the declared daily lead")
        if ((a["context_index"] < 0) | (a["context_index"] >= length)).any():
            raise ValueError("Invalid recurrent satellite context index")
        if not np.isfinite(a["per_basin_target_stds"]).all() or (a["per_basin_target_stds"] <= 0).any():
            raise ValueError("Target loss scales must be positive and fitted using training data only")
        if len(set(zip(a["basins"].tolist(), a["issue_times"].tolist()))) != n:
            raise ValueError("Duplicate forecast basin/issue pairs")
        self.features = list(cfg.dynamic_inputs)

    def __len__(self):
        return len(self.arrays["basins"])

    def __getitem__(self, i):
        a = self.arrays
        result = {"x_d": {name: torch.as_tensor(a["x_d"][i, :, j:j + 1], dtype=torch.float32)
                          for j, name in enumerate(self.features)},
                  "x_s": torch.as_tensor(a["x_s"][i], dtype=torch.float32),
                  "basin": str(a["basins"][i])}
        for key in ["y", "per_basin_target_stds", "dynamic_times", "issue_times", "target_times", "context_index"]:
            result[key] = torch.as_tensor(a[key][i])
        result["satellite"] = {key[4:]: torch.as_tensor(value[i]) for key, value in a.items() if key.startswith("sat_")}
        return result


def verify_splits(train, validation, test, source_basins):
    ids = [set(dataset.arrays["basins"].tolist()) for dataset in [train, validation, test]]
    if ids[0] & ids[1] or ids[0] & ids[2] or ids[1] & ids[2]:
        raise ValueError("Train/validation/test basins must be disjoint")
    if (ids[1] | ids[2]) & set(source_basins):
        raise ValueError("A validation/test basin was already used to train the old checkpoint")
    for field in ["normalizer_sha256", "lead_days", "meteorological_information", "kind"]:
        values = [d.meta[field] for d in [train, validation, test]]
        if any(x != values[0] for x in values):
            raise ValueError(f"Inconsistent shared dataset metadata: {field}")
    for dataset in [validation, test]:
        verify_target_transform(dataset.meta, train.meta)


def to_device(data, device):
    if isinstance(data, dict):
        return {k: to_device(v, device) for k, v in data.items()}
    return data.to(device) if isinstance(data, torch.Tensor) else data
