"""TESSERA pixel student — small (7.11M encoder), 128-d Matryoshka {16,32,64,128}.

Distilled from a TESSERA teacher.
"""
try:  # package import
    from . import model, infer, quantize  # noqa: F401
except ImportError:  # standalone folder
    import model, infer, quantize  # noqa: F401

load_model = model.load_model
encode_tile = infer.encode_tile
encode_pixels = infer.encode_pixels
quantize_int8 = quantize.quantize
