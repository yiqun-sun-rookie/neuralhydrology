"""Report every frozen comparison and limitation after array acceptance."""
from pathlib import Path
import json,csv,io
BASE=Path(__file__).resolve().parent
def obj(p):return json.loads(p.read_bytes())
def put(name,text):
    with (BASE/name).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
a=obj(BASE/'acceptance.json');c=obj(BASE/'replay_contract.json');d=obj(BASE/'lead3_diagnostic.json')['diagnostic'];old=obj(BASE/'old_multiseed_evidence.json')
lines=['# KNET-XPERIOD-01 运行报告','',f"技术状态：{a['status']}；唯一作业{a['job_id']}。",'']
s=d['UKF_sampling'];b=d['UKF_backprop'];g=s['groups']
lines+=['## 已有3日预报数组核查','',f"固定728个3日目标：KNet MSE={g['all']['knet_mse']:.12g}，采样UKF={g['all']['ukf_mse']:.12g}，差{s['relative_mse_change_percent']:+.6f}%；相对反传UKF为{b['relative_mse_change_percent']:+.6f}%。KNet MAE={g['all']['knet_mae']:.8g}，采样UKF MAE={g['all']['ukf_mae']:.8g}。",'', '| 固定分组 | 数量 | KNet MSE | 采样UKF MSE | 差值 |','|---|---:|---:|---:|---:|']
for name,v in g.items():lines.append(f"| {name} | {v['count']} | {v['knet_mse']:.8g} | {v['ukf_mse']:.8g} | {v['mse_delta']:+.8g} |")
lines+=['',f"逐日平方误差差的正贡献总和{s['positive_contribution']:.8g}、负贡献{s['negative_contribution']:.8g}，净差{s['groups']['all']['total_squared_error_delta']:.8g}。最大不利日期{s['top_harmful'][0]['target_date']}，观测{s['top_harmful'][0]['observation']:.6g}、KNet{s['top_harmful'][0]['knet_prediction']:.6g}、UKF{s['top_harmful'][0]['ukf_prediction']:.6g}。删除最大不利1日后的MSE差为{s['leave_harmful_dates']['1']['mse_delta']:+.8g}，只说明净差敏感，主结果仍保留全部日期。所有前10有利/不利日期、1/5/10日敏感性及输入SHA在lead3_diagnostic.json。不能将事后贡献解释写成因果机制或显著性。",'', '## 已有五种子证据边界','', '| 旧合同A种子 | 历史期平均NSE |','|---|---:|']
for seed,v in old['formal_scores'].items():
    if seed.startswith('knet_'):lines.append(f"| {seed} | {v['mean_nse']:.9g} |")
lines+=['','旧五种子均在开发期约0.90，但旧历史期3/5平均NSE为负。该旧配方是短片段训练；本轮仅当前800日前向/末150日导数的seed20260922、epoch81。旧失败完整保留，本轮不能证明当前配方多种子稳定。','']
if a['status']=='ACCEPTED_XPERIOD_ARTIFACTS':
    r=a['receipt'];n=a['native_status'];lines+=['## 原生状态、预算与完整性','',f"Slurm {n['State']}/{n['ExitCode']}，ElapsedRaw={n['ElapsedRaw']}秒；控制器上界{r['wall_seconds_upper']:.6f}秒/890秒（Slurm900秒）；RSS峰值{r['combined_rss_peak_bytes']}字节，可用内存最低{r['system_free_min_bytes']}字节，实际亲和性{r['affinity']}、数学线程1，无GPU。原生AllocCPUS={n.get('AllocCPUS','见原始回执')}。",f"实际计数：{json.dumps(a['result']['counters'],ensure_ascii=False)}。两次KNet运行全部网络张量与输入检查点完全相同；物理参数、UKF噪声与初始P不变。每条滤波包含预热日，子窗只重评分，新增训练/梯度/QP均0。",f"归档{a['archive']['files']}文件、{a['archive']['archive_bytes']}字节，SHA256={a['archive']['archive_sha256']}。完整manifest及逐文件SHA通过，12个必需科学文件包括8份模型数组、2份共享数组、2份运行后网络，全部已核验。前次漏模型数组的收档缺陷已在本轮部署前修为递归枚举。",'', '## 固定完整期及子窗结果','', '| 固定窗 | 模型 | 总体MSE | MAE | 1日MSE | 2日MSE | 3日MSE |','|---|---|---:|---:|---:|---:|---:|']
    tables={**a['computed'],**{name:v['metrics'] for name,v in a['subwindows'].items()}};rows=[]
    for case,metrics in tables.items():
        for arm,v in metrics.items():
            lead=v['by_lead'];lines.append(f"| {case} | {arm} | {v['scores'][0]:.9g} | {v['scores'][1]:.9g} | {lead['1']['mse']:.9g} | {lead['2']['mse']:.9g} | {lead['3']['mse']:.9g} |")
            for j in ['1','2','3']:rows.append(dict(window=case,arm=arm,lead=int(j),**lead[j]))
    stream=io.StringIO();writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows);put('全部逐提前量指标.csv',stream.getvalue())
    lines+=['','完整总体/低中高MSE、MAE、每提前量bias、NSE及全部水文年在acceptance.json（computed/subwindows/water_year_metrics），逐提前量另存CSV。以下逐项列出流量工程检查；它们属于原版基线研究，与旧雪代理研究九门槛分开。0.1%界限和原数值容差均未放宽。','', '| 窗口 | 对照 | MSE改善 | 八项是否通过（总体MSE/MAE、低、中、高） | KNet总体MSE变化% |','|---|---|---|---|---:|']
    for case,metrics in tables.items():
        paired=a['comparisons'][case] if case in a['comparisons'] else a['subwindows'][case]['comparisons']
        for ref,v in paired.items():lines.append(f"| {case} | {ref} | {v['overall_mse_improves']} | {','.join('通过' if p else '失败' for p in v['flow_passed'])} | {v['relative_change_percent'][0]:+.6f} |")
    lines+=['','## 连续运行、重新初始化与失稳','',f"完整运行MSE/HBV倍数：{json.dumps(a['mse_ratios_to_hbv'],ensure_ascii=False)}。严重失稳规则（非有限或总体MSE>100×HBV）检测={a['severe_instability_detected']}。低于100倍不自动代表稳定，仍须查看全部不利窗和逐年记录。",'', '| 模型 | 同后窗预报是否完全相同 | 最大预报绝对差 | 重启减连续MSE |','|---|---|---:|---:|']
    for arm,v in a['history_comparison'].items():lines.append(f"| {arm} | {v['exact_forecast_equality']} | {v['maximum_absolute_forecast_difference']:.9g} | {v['restart_minus_continuous_mse']:+.9g} |")
    for case,v in a['state_summaries'].items():lines.append(f"\n{case}：KNet全部{v['cap_denominator_all_days']}状态日分量的改正边界比例{v['cap_boundary_fraction_all_days']:.6%}，评分日边界比例{v['cap_boundary_fraction_score_days']:.6%}。这表示触及既有上限，未改上限；状态分位数仅作描述。")
    lines+=['','## 全部不利项与下一步','']
    adverse=[]
    for case,metrics in tables.items():
        k=metrics['KNet_selected']
        for ref in ['HBV','UKF_sampling','UKF_backprop']:
            for j in ['1','2','3']:
                if k['by_lead'][j]['mse']>metrics[ref]['by_lead'][j]['mse']:adverse.append(f"{case}：{j}日MSE高于{ref} {100*(k['by_lead'][j]['mse']/metrics[ref]['by_lead'][j]['mse']-1):.4f}%。")
    lines.extend(['- '+x for x in adverse] or ['本轮固定窗中未检测到KNet逐提前量MSE高于三类对照；逐年和分组仍详见完整数组重算。'])
    anybad=any(not v['all_flow_pass'] for case in tables for v in (a['comparisons'][case] if case in a['comparisons'] else a['subwindows'][case]['comparisons']).values())
    if a['severe_instability_detected']:recommend='当前模型在冻结历史期出现严重失稳，应先用本次保存状态和逐日误差定位失稳起点及改正饱和，核查训练分布与初始化；不要继续扩大训练或宣传总体优势。下一实验须另行冻结，不能修补本次负结果。'
    elif anybad:recommend='本轮未触发严重失稳不等于各窗口均占优。下一步先依据保存数组核查不利水文年和3日中高流量误差；若开展新实验，优先固定当前训练配方的多种子重复，并使用预先确定、未用于选模的评价期。当前只有一个种子，尚不能谈普遍稳定。'
    else:recommend='本轮固定窗表现支持当前单模型在这些已知时段可运行。下一步应做当前训练配方的多种子重复及事先锁定的未参与选模时段；旧五种子不能替代这一步，不据单流域单种子宣称普遍稳定。'
    lines+=['',recommend,'']
else:lines+=['科学输出未完整验收，不给效果结论；保留原生失败与已收档证据，不重复科学提交。','']
lines+=['## 适用范围','',c['scope'],'','已知未来气象强迫；1989—1999已在旧研究暴露，2006—2008为既有开发验证期且用于选模；历史训练/调参预算不同，不宣称等算力、统计显著或未见测试泛化。没有实测雪量真值，状态变化不是状态精度。两种初始化只比较已固定路径，不推断训练配方改善的因果效应。','', '白话总结：这次检查的是同一个已训练模型换年份、换运行起点后能否保持表现。跑完和技术验收通过，都不能代替跨种子的稳定性证据。','']
put('运行报告.md','\n'.join(lines));print(json.dumps(dict(status='REPORT_WRITTEN',path=str(BASE/'运行报告.md')),ensure_ascii=False))
