"""Exclusive saved-array diagnosis and frozen raw-data preparation; zero model calls."""
from pathlib import Path
import json,hashlib,io,csv,importlib.util,datetime
import numpy as np
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent;OLD=ROOT/'hpc_knet_baseline_20261021_001'
A=ROOT.parent/'v3_aligned_rematch_regional_20260916'
def obj(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(name,value):
    p=BASE/name;p.parent.mkdir(parents=True,exist_ok=True)
    raw=value if isinstance(value,bytes) else (value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
    with p.open('xb') as f:f.write(raw)
def binding(p):return dict(path=str(p.resolve()),sha256=sha(p),bytes=p.stat().st_size)
def load(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
put('diagnostic_rules.json',dict(status='FIXED_BEFORE_DIAGNOSIS',lead=3,comparators=['UKF_sampling','UKF_backprop'],groups=['all','water_year','season','training_q50_q90'],influence_top_k=[1,5,10],primary='all dates retained; paired squared-error difference',interpretation='posthoc descriptive attribution, no causal or significance claim',model_calls=0))
assert obj(OLD/'acceptance.json')['status']=='ACCEPTED_BASELINE_ARTIFACTS'
run=OLD/'hpc_results/runs/02092500/attempt_001';shared=load(run/'shared_arrays.npz');k=load(run/'KNet_selected/evaluation.npz')
dates=shared['dates_ns'][k['target_indices'][:,2]].astype('datetime64[ns]').astype('datetime64[D]');y=k['target'][:,2];ek=k['prediction'][:,2]-y
month=dates.astype('datetime64[M]').astype(int)%12+1;year=dates.astype('datetime64[Y]').astype(int)+1970;wy=year+(month>=10)
seasons=np.array(['DJF','MAM','JJA','SON'])[(month%12)//3];q50,q90=shared['thresholds'][:2]
groups={'all':np.ones(len(y),bool),**{f'WY{n}':wy==n for n in sorted(set(wy))},**{s:seasons==s for s in ['DJF','MAM','JJA','SON']},'low':y<=q50,'middle':(y>q50)&(y<=q90),'high':y>q90}
diagnostic={};sources=[binding(OLD/'acceptance.json'),binding(OLD/'collection/supplement_verified.json'),binding(run/'shared_arrays.npz'),binding(run/'KNet_selected/evaluation.npz')]
for label in ['UKF_sampling','UKF_backprop']:
    p=run/label/'evaluation.npz';u=load(p);sources.append(binding(p));np.testing.assert_array_equal(u['target_indices'],k['target_indices']);np.testing.assert_array_equal(u['target'],k['target'])
    eu=u['prediction'][:,2]-y;delta=ek**2-eu**2
    rows={name:dict(count=int(g.sum()),knet_mse=float(np.mean(ek[g]**2)),ukf_mse=float(np.mean(eu[g]**2)),mse_delta=float(delta[g].mean()),total_squared_error_delta=float(delta[g].sum()),knet_mae=float(np.mean(abs(ek[g]))),ukf_mae=float(np.mean(abs(eu[g]))),knet_bias=float(ek[g].mean()),ukf_bias=float(eu[g].mean())) for name,g in groups.items()}
    def event(i):return dict(target_date=str(dates[i]),issue_date=str(dates[i]-np.timedelta64(3,'D')),observation=float(y[i]),knet_prediction=float(k['prediction'][i,2]),ukf_prediction=float(u['prediction'][i,2]),squared_error_delta=float(delta[i]))
    order=np.argsort(-delta,kind='stable');sensitivity={}
    for n in [1,5,10]:
        keep=np.ones(len(y),bool);keep[order[:n]]=False
        sensitivity[str(n)]=dict(label='descriptive only; primary score unchanged',remaining_count=int(keep.sum()),mse_delta=float(delta[keep].mean()))
    diagnostic[label]=dict(groups=rows,relative_mse_change_percent=float(100*delta.mean()/np.mean(eu**2)),knet_squared_error_win_fraction=float(np.mean(delta<0)),positive_contribution=float(delta[delta>0].sum()),negative_contribution=float(delta[delta<0].sum()),top_harmful=[event(i) for i in order[:10]],top_helpful=[event(i) for i in np.argsort(delta,kind='stable')[:10]],leave_harmful_dates=sensitivity)
put('lead3_diagnostic.json',dict(status='SAVED_ARRAY_DIAGNOSIS_COMPLETE',diagnostic=diagnostic,sources=sources,model_calls=0))
formal_path=A/'phase_a_results/unseal_a_seq179/basin_02092500.json';formal=obj(formal_path);dev_path=A/'phase_a_results/summary_development_seq167.json';dev=obj(dev_path)
basin=next(b for b in dev['basins'] if b['basin_id']=='02092500')
put('old_multiseed_evidence.json',dict(status='HISTORICAL_DIFFERENT_RECIPE',basin='02092500',sources=[binding(formal_path),binding(dev_path)],development=basin,formal_scores=formal['scores'],formal_saturation=formal['knet_formal_saturation'],checkpoint_bindings=formal['checkpoints'],warning='old short-segment contract A; not five seeds of the current 800-forward/150-derivative epoch81 model; three of five KNet formal means are negative; formal period already exposed'))
for name in ['knet_selected.pt','ukf_selection.json','input_snapshot.npz']:put('inputs/'+name,(OLD/'inputs'/name).read_bytes())
loader=A/'launcher/deploy/unseal_a_seq179/payload_tree/shipped/vendor/hydroagent_data_loading.py';assert sha(loader)=='340b1a6d94c36ba5e278bca207c52c1dcd7bdc578a16b30bd3cd53da2027ee9c'
put('inputs/frozen_data_loader.py',loader.read_bytes());spec=importlib.util.spec_from_file_location('frozen_loader',loader);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
data=Path('G:/github/pycharm/projects/neuralhydrology/data/camels_us')
def read(start,end):
    f,q,area=m.load_camels_basin('02092500',data_root=data,start_date=start,end_date=end,forcing='maurer',pet_method='oudin',keep_obs_nan_days=True)
    return dict(forcing=np.stack([f['prcp'],f['tmean'],f['ep']],axis=-1).astype(np.float64)[:,None,:],observations=q.to_numpy(dtype=np.float64),dates_ns=np.asarray(f.index).astype('datetime64[ns]').astype('int64'))
check=read('1999-10-01','2008-09-30');snapshot=load(BASE/'inputs/input_snapshot.npz')
for key in check:np.testing.assert_array_equal(check[key],snapshot[key])
historical=read('1989-10-01','1999-09-30');assert historical['forcing'].shape==(3652,1,3) and np.isfinite(historical['observations']).all() and np.isfinite(historical['forcing']).all();assert np.all(np.diff(historical['dates_ns'])==86400*10**9)
stream=io.BytesIO();np.savez_compressed(stream,**historical);put('inputs/historical_period.npz',stream.getvalue())
raw_files=[data/'basin_mean_forcing/maurer/03/02092500_lump_maurer_forcing_leap.txt',data/'usgs_streamflow/03/02092500_streamflow_qc.txt',data/'camels_attributes_v2.0/camels_topo.txt']
put('data_provenance.json',dict(status='DEVELOPMENT_INPUTS_BIT_EXACT_AND_HISTORICAL_GEOMETRY_VERIFIED',sources=[binding(loader)]+[binding(p) for p in raw_files],development_bit_exact=True,historical_geometry=formal['geometry'],historical_array=binding(BASE/'inputs/historical_period.npz'),local_model_calls=0,loader_arguments=dict(forcing='maurer',pet_method='oudin',keep_obs_nan_days=True),warning='historical forcing/observations newly loaded from frozen raw source, not a newly unseen test; old formal output retained'))
put('checkpoint_bindings.json',dict(files=[dict(path=p.relative_to(BASE).as_posix(),sha256=sha(p),bytes=p.stat().st_size) for p in sorted((BASE/'inputs').iterdir())]));put('input_bindings.json',dict(files=[]))
print(json.dumps(dict(status='INPUTS_AND_DIAGNOSIS_READY',lead3={n:dict(delta=x['groups']['all']['mse_delta'],percent=x['relative_mse_change_percent'],harmful=x['top_harmful'][:3],groups=x['groups']) for n,x in diagnostic.items()},formal_seed_means={s:v['mean_nse'] for s,v in formal['scores'].items() if s.startswith('knet_')},historical_days=3652),ensure_ascii=False))
