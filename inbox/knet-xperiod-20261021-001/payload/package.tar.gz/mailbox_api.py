"""Own-channel mailbox transport. Keeps concurrent branch changes intact."""
import base64
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
spec = importlib.util.spec_from_file_location('safe_io', ROOT / 'safe_io.py')
s = importlib.util.module_from_spec(spec)
sys.modules['safe_io'] = s
spec.loader.exec_module(s)
CHANNEL = 'knet-xperiod-20261021-001'
BASE = 'https://api.github.com/repos/yiqun-sun-rookie/neuralhydrology'
cred = subprocess.run(['git', 'credential', 'fill'], input='protocol=https\nhost=github.com\n\n',
                      text=True, capture_output=True, timeout=25)
if cred.returncode:
    raise RuntimeError('GitHub credential helper unavailable')
fields = dict(line.split('=', 1) for line in cred.stdout.splitlines() if '=' in line)
TOKEN = fields.get('password')
if not TOKEN:
    raise RuntimeError('GitHub credential helper returned no token')


def api(path, data=None, method=None):
    body = None if data is None else json.dumps(data).encode()
    req = urllib.request.Request(BASE + path, data=body, method=method,
        headers={'Authorization': 'Bearer ' + TOKEN, 'Accept': 'application/vnd.github+json',
                 'X-GitHub-Api-Version': '2022-11-28', 'Content-Type': 'application/json'})
    # Retry only read-only metadata. A write with an uncertain response is never replayed.
    attempts = 3 if data is None and method in (None, 'GET') else 1
    for attempt in range(attempts):
        try:
            with urllib.request.urlopen(req, timeout=40) as response:
                chunks=[]
                while True:
                    part=response.read(8192)
                    if not part:break
                    chunks.append(part)
                raw=b''.join(chunks)
                declared=response.headers.get('Content-Length')
                if declared is not None and len(raw)!=int(declared):
                    raise RuntimeError('Incomplete metadata response')
                return json.loads(raw)
        except urllib.error.HTTPError as err:
            if err.code == 404:return None
            if attempt+1==attempts:raise
        except Exception:
            if attempt+1==attempts:raise
        time.sleep(.5)


def snapshot():
    # A mutable ref must be fresh; immutable commit/blob reads remain cacheable.
    ref = api('/git/ref/heads/hpc-mailbox?fresh=' + str(time.time_ns()))
    sha = ref['object']['sha']
    return sha, api('/git/commits/' + sha)


def content(path, sha):
    if path == 'CHANNELS.md':
        # The large base64 Contents response is repeatedly truncated in transit.
        # Resolve a small root-tree entry and verify bounded raw ranges instead.
        commit = api('/git/commits/' + sha)
        root_tree = api('/git/trees/' + commit['tree']['sha'])
        entry = next(x for x in root_tree['tree'] if x['path'] == path)
        size = entry['size']; parts=[]
        url = 'https://raw.githubusercontent.com/yiqun-sun-rookie/neuralhydrology/' + sha + '/CHANNELS.md'
        for start in range(0,size,8192):
            end=min(start+8192,size)-1
            for attempt in range(4):
                try:
                    req=urllib.request.Request(url+'?registry_start='+str(start)+'&registry_end='+str(end)+'&attempt='+str(attempt),
                        headers={'Range':f'bytes={start}-{end}','Accept-Encoding':'identity'})
                    with urllib.request.urlopen(req,timeout=45) as response:
                        assert response.status==206 and response.headers.get('Content-Range')==f'bytes {start}-{end}/{size}'
                        chunks=[]
                        while True:
                            chunk=response.read(4096)
                            if not chunk:break
                            chunks.append(chunk)
                        body=b''.join(chunks)
                    assert len(body)==end-start+1
                    parts.append(body);break
                except Exception:
                    if attempt==3:raise
        raw=b''.join(parts)
        assert len(raw)==size and hashlib.sha1(b'blob '+str(size).encode()+bytes([0])+raw).hexdigest()==entry['sha']
        return raw
    result = api('/contents/' + urllib.parse.quote(path, safe='/') + '?ref=' + sha)
    if result is None:
        return None
    # Reuse an immutable own receipt only after checking it against pinned Git metadata.
    prefix = f'outbox/{CHANNEL}/result_'
    if path.startswith(prefix) and path.endswith('.txt') and path[len(prefix):-4].isdigit():
        cached = HERE/'mailbox'/('result_'+str(int(path[len(prefix):-4])).zfill(3)+'.txt')
        if cached.exists():
            raw = s.read_checked(cached)
            actual = hashlib.sha1(b'blob '+str(len(raw)).encode()+bytes([0])+raw).hexdigest()
            if len(raw) != result['size'] or actual != result['sha']:
                raise RuntimeError('immutable own receipt cache differs from pinned Git object')
            return raw
    if result.get('encoding') != 'none' and result.get('content'):
        return base64.b64decode(result['content'])
    # Raw blob transfer avoids the second base64 layer for large receipts.
    # Streaming handles premature EOF explicitly; Git object identity is checked
    # before any received bytes are accepted or persisted.
    request = urllib.request.Request(BASE + '/git/blobs/' + result['sha'],
        headers={'Authorization':'Bearer '+TOKEN,'Accept':'application/vnd.github.raw+json','X-GitHub-Api-Version':'2022-11-28'})
    error = None
    for attempt in range(2):
        try:
            chunks=[]
            with urllib.request.urlopen(request,timeout=90) as response:
                kind=response.headers.get('Content-Type','')
                while True:
                    chunk=response.read(65536)
                    if not chunk:
                        break
                    chunks.append(chunk)
            raw=b''.join(chunks)
            if raw.lstrip().startswith(b'{'):
                document=json.loads(raw)
                if isinstance(document,dict) and 'content' in document:
                    raw=base64.b64decode(document['content'])
            actual=hashlib.sha1(b'blob '+str(len(raw)).encode()+bytes([0])+raw).hexdigest()
            if actual!=result['sha']:
                raise RuntimeError('streamed Git blob identity differs; expected='+result['sha']+' actual='+actual+' bytes='+str(len(raw))+' kind='+kind+' prefix='+repr(raw[:35]))
            return raw
        except Exception as failure:
            error=failure
    raise error


def save(name, obj):
    return s.create(str((HERE / name).relative_to(ROOT)), obj)


def publish(seq, command, extras=None):
    payload = {f'inbox/{CHANNEL}/cmd.sh': s.read_checked(command),
               f'inbox/{CHANNEL}/seq': str(seq).encode()}
    for remote, local in (extras or {}).items():
        if not remote.startswith(f'inbox/{CHANNEL}/payload/'):
            raise PermissionError('payload outside own channel')
        payload[remote] = s.read_checked(Path(local))
    digest = hashlib.sha256(payload[f'inbox/{CHANNEL}/cmd.sh']).hexdigest()
    for attempt in range(4):
        sha, commit = snapshot()
        previous = content(f'inbox/{CHANNEL}/seq', sha)
        if previous is not None and int(previous) == seq:
            live = content(f'inbox/{CHANNEL}/cmd.sh', sha)
            if hashlib.sha256(live).hexdigest() != digest:
                raise RuntimeError('sequence already holds a different command')
            return {'sequence': seq, 'branch_sha': sha, 'command_sha256': digest,
                    'status': 'PUBLISHED_ALREADY_VERIFIED'}
        expected = seq - 1
        if previous is None:
            if seq != 1:
                raise RuntimeError('new channel must start at sequence one')
            registry = content('CHANNELS.md', sha)
            if CHANNEL.encode() in registry:
                raise RuntimeError('channel name already registered')
            purpose = globals().get('CHANNEL_PURPOSE', 'Authorized KNET-XPERIOD-01 HBV/UKF/KNet frozen-model comparison')
            row = (f'\n| `{CHANNEL}` | {purpose} | '
                   f'2026-10-21 | Only knet_xperiod_20261021_001, one 020 four-arm frozen-model evaluation job, 900 second cap, zero training, no repeat submission; '
                   f'preserve shared receiver and all other tasks. |\n')
            payload['CHANNELS.md'] = registry + row.encode()
        else:
            if int(previous) != expected:
                raise RuntimeError('unexpected own-channel sequence')
            receipt = content(f'outbox/{CHANNEL}/result_{expected}.txt', sha)
            if receipt is None or b'### exit_code=' not in receipt:
                raise RuntimeError('previous command lacks a complete receipt')
        tree_rows = []
        for path, raw in payload.items():
            blob = api('/git/blobs', {'content': base64.b64encode(raw).decode(), 'encoding': 'base64'})
            tree_rows.append({'path': path, 'mode': '100644', 'type': 'blob', 'sha': blob['sha']})
        tree = api('/git/trees', {'base_tree': commit['tree']['sha'], 'tree': tree_rows})
        description = globals().get('COMMAND_DESCRIPTION', 'isolated frozen-selected-model temporal evaluation')
        new = api('/git/commits', {'message': f'mailbox[{CHANNEL}]: seq={seq} {description}',
                                 'tree': tree['sha'], 'parents': [sha]})
        try:
            api('/git/refs/heads/hpc-mailbox', {'sha': new['sha'], 'force': False}, 'PATCH')
        except urllib.error.HTTPError as err:
            if err.code not in (409, 422):
                raise
            continue
        current_sha, _ = snapshot()
        live_seq = content(f'inbox/{CHANNEL}/seq', current_sha)
        live_command = content(f'inbox/{CHANNEL}/cmd.sh', current_sha)
        if int(live_seq) != seq or hashlib.sha256(live_command).hexdigest() != digest:
            raise RuntimeError('published command verification differs')
        return {'sequence': seq, 'commit_sha': new['sha'], 'branch_sha_verified': current_sha,
                'command_sha256': digest, 'status': 'PUBLISHED_VERIFIED',
                'updated_paths': list(payload), 'concurrent_branch_rebases': attempt}
    raise RuntimeError('mailbox branch kept advancing; no force push attempted')


def main():
    mode, number = sys.argv[1], int(sys.argv[2])
    if mode == 'publish':
        extras = None if len(sys.argv) < 5 else json.loads(s.read_checked(Path(sys.argv[4])))
        result = publish(number, Path(sys.argv[3]), extras)
        result['published_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        print(json.dumps(dict(result, evidence=save(f'mailbox/published_{number:03}.json', result))))
    elif mode == 'read':
        sha, _ = snapshot()
        receipt = content(f'outbox/{CHANNEL}/result_{number}.txt', sha)
        if receipt is None:
            print(json.dumps({'sequence': number, 'status': 'NO_RECEIPT_YET', 'branch_sha': sha}))
            return
        path = HERE / f'mailbox/result_{number:03}.txt'
        if not path.exists():
            save(f'mailbox/result_{number:03}.txt', receipt)
        else:
            if s.read_checked(path) != receipt:
                raise RuntimeError('saved immutable receipt differs')
        print(receipt.decode('utf-8', errors='replace'))
    else:
        raise ValueError('unknown mode')


if __name__ == '__main__':
    main()
