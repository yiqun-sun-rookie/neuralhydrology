"""Only syntax, input identities, dates and metric boundaries; no model execution."""
from pathlib import Path
import json,hashlib,ast
import numpy as np
from evaluation_math import scores,forecast_indices,comparisons
BASE=Path(__file__).resolve().parent
def obj(p):return json.loads(p.read_bytes())
for p in BASE.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'),filename=str(p))
c=obj(BASE/'replay_contract.json')
for row in c['input_bindings']:assert hashlib.sha256((BASE/row['path']).read_bytes()).hexdigest()==row['sha256']
for row in obj(BASE/'transport_sources.json')['files']:
    assert hashlib.sha256(Path(row['source']).read_bytes()).hexdigest()==row['source_sha256'] and hashlib.sha256((BASE/row['path']).read_bytes()).hexdigest()==row['derived_sha256']
with np.load(BASE/'inputs/historical_period.npz',allow_pickle=False) as z:dates=z['dates_ns'].astype('datetime64[ns]').astype('datetime64[D]')
expected=[('1989-10-01','1990-10-01',3652,3284),('1994-10-01','1995-10-01',1826,1458)]
total_days=total_events=0
for case,(first,score,days,n) in zip(c['cases'],expected):
    start=case['filter_start'];s=case['score_start'];end=case['end'];issues,targets=forecast_indices(s,end)
    assert str(dates[start])==first and str(dates[s])==score and str(dates[end-1])=='1999-09-30' and end-start==days and len(issues)==n and targets.shape==(n,3) and targets.min()==s+1 and targets.max()==end-1
    total_days+=4*days;total_events+=4*targets.size
assert total_days==c['maximum_filter_days']==21912 and total_events==c['maximum_forecast_events']==56904
assert c['maximum_filter_trajectories']==8 and c['maximum_total_optimizer_calls']==c['maximum_autograd_calls']==c['maximum_qp_calls']==0
y=np.array([[0.,1.,3.],[2.,5.,6.]]);np.testing.assert_array_equal(scores(y+1,y,[1.,3.])['scores'],np.ones(8))
m={k:dict(scores=[1.]*8) for k in c['trajectory_order']};m['KNet_selected']=dict(scores=[1.001+1e-7]*8);assert comparisons(m)['HBV']['all_flow_pass'];m['KNet_selected']['scores'][0]+=1e-8;assert not comparisons(m)['HBV']['all_flow_pass']
collector=(BASE/'collect_terminal.py').read_text();assert "folder2.rglob('*')" in collector and '/original' not in collector and '/state_constrained' not in collector
slurm=(BASE/'replay.slurm').read_bytes();assert b'--mem' not in slurm and b'\r' not in slurm and b'00:15:00' in slurm
out=dict(status='STATIC_AND_SYNTHETIC_CHECKS_PASS',python_ast_files=len(list(BASE.glob('*.py'))),checks=['fixed_dates_and_indices','input_SHA','metric_boundaries','recursive_collector','zero_training_budget'],filter_days=total_days,forecast_events=total_events,local_model_calls=0,local_autograd_calls=0,local_qp_calls=0)
with (BASE/'static_checks.json').open('x',encoding='utf-8') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps(out))
