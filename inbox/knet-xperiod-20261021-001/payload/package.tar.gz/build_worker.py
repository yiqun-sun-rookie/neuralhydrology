"""Build bounded worker from the accepted native bootstrap and explicit new loop."""
from pathlib import Path
BASE=Path(__file__).resolve().parent;OLD=BASE.parent/'hpc_knet_baseline_20261021_001'
old=(OLD/'replay_worker.py').read_text(encoding='utf-8');prefix=old[:old.index("    start=contract['filter_start']")]
prefix=prefix.replace('Four bounded frozen-model trajectories','Eight bounded frozen-model trajectories')
loop=r'''
    with np.load(io.BytesIO(read_input('inputs/historical_period.npz')),allow_pickle=False) as z:historical={k:z[k].copy() for k in z.files}
    forcing=torch.as_tensor(historical['forcing'],dtype=runtime.context.dtype);observations=torch.as_tensor(historical['observations'],dtype=runtime.context.dtype).reshape(-1,1);dates=historical['dates_ns'].astype('datetime64[ns]')
    assert forcing.shape==(3652,1,3) and observations.shape==(3652,1) and torch.isfinite(forcing).all() and torch.isfinite(observations).all()
    physical_initial=runtime.context.initial_state.clone();initial_covariance=torch.eye(11,dtype=runtime.context.dtype).unsqueeze(0)*.001
    assert physical_initial.shape==(1,11) and physical_initial[0,:2].eq(0).all() and physical_initial[0,3].item()==5 and physical_initial[0,4].item()==10 and physical_initial[0,5:].eq(0).all()
    physics_hash=C.helpers.digest_tree(runtime.context.parameters);records={};metrics={}
    for case in contract['cases']:
        cname=case['name'];start=case['filter_start'];score_start=case['score_start'];end=case['end'];warm=score_start-start;days=end-start
        assert days==case['filter_days'] and warm==365
        issues,targets=forecast_indices(score_start,end);assert len(issues)==case['issue_count']
        shared=dict(filter_global_indices=np.arange(start,end),score_global_indices=np.arange(score_start,end),issue_indices=issues,target_indices=targets,target=historical['observations'][targets],**historical,thresholds=thresholds,initial_state=arr(physical_initial),previous_observation=np.full((1,1),np.nan),initial_covariance=arr(initial_covariance),physical_parameters=arr(runtime.context.parameters),base_observation_variance=np.asarray(float(runtime.context.base_observation_variance)))
        np_save(cname+'/shared_arrays.npz',shared);records[cname]={};metrics[cname]={}
        for label in contract['trajectory_order']:
            assert COUNTERS['filter_trajectories']<8
            context=parity._context_with_initial_state(runtime.context,physical_initial.clone());run_start=time.monotonic();arm=cname+'/'+label
            emit('phase_start',arm=arm,phase='frozen_evaluation')
            arrays=dict(initial_state=arr(physical_initial),previous_observation=np.full((1,1),np.nan),issue_indices=issues,target_indices=targets,target=shared['target'])
            proof=dict(physical_parameters_sha_before=physics_hash,initial_physical_state_shared=True,network_updates=0)
            if label=='HBV':
                state=physical_initial.clone();states=[]
                with torch.no_grad():
                    for day in range(days):
                        state=context.plain_model.f(state,forcing[start+day,0].reshape(1,3));assert torch.isfinite(state).all();states.append(state.clone());COUNTERS['filter_days']+=1
                posterior=torch.stack(states);prior=posterior.clone();arrays.update(valid_updates=np.zeros(days,dtype=bool),observations_assimilated=np.full((days,1),np.nan));proof.update(observation_updates=0)
            elif label.startswith('UKF_'):
                key='sampling_search' if label=='UKF_sampling' else 'backpropagation';params=selection[key]['selected']
                q=torch.tensor(params['q_diagonal'],dtype=context.dtype);rb=torch.tensor(params['r_b'],dtype=context.dtype)
                before=C.helpers.digest_tree(dict(q=q,r_b=rb,initial_covariance=initial_covariance))
                with torch.no_grad():trace=run_hbvlite_corrected_ukf(context.adapter,forcing[start:end],observations[start:end],physical_initial.clone(),initial_covariance.clone(),q,base_observation_variance=context.base_observation_variance,r_b=rb,project_mean=context.project_mean,alpha=.3,beta=2.,kappa=0.,covariance_floor=1e-12)
                prior=trace['prior_state'];posterior=trace['posterior_state'];assert prior.shape==posterior.shape==(days,1,11)
                after=C.helpers.digest_tree(dict(q=q,r_b=rb,initial_covariance=initial_covariance));assert before==after
                arrays.update(valid_updates=np.ones(days,dtype=bool),observations_assimilated=arr(observations[start:end]),innovation=arr(trace['innovation']),filter_prediction=arr(trace['prediction']),observation_variance=arr(trace['observation_variance']),process_diagonal=arr(q),r_b=arr(rb),initial_covariance=arr(initial_covariance))
                proof.update(observation_updates=days,noise_sha_before=before,noise_sha_after=after,selected_index=selection[key]['selected_index']);COUNTERS['filter_days']+=days
            else:
                assert label=='KNet_selected'
                net=per.build_exact_dimension_kalman_net(runtime,zero_gain=False,seed=20260922,gain_initialization='near_zero_fc2_head',hidden=24,input_multiplier=10,output_multiplier=10,feature_scale_floor=.1,normalized_feature_guard=10.,correction_cap_in_state_scale_units=3.)
                net.load_state_dict(cp['network'],strict=True);net.eval()
                for p in net.parameters():p.requires_grad_(False)
                before=C.helpers.digest_tree(net.state_dict());param_before=parity.parameter_sha256(net);assert param_before==contract['knet_parameter_sha256']
                batch=parity.WindowBatch(purpose='frozen_xperiod',global_start=start,global_end_exclusive=end,context=context,forcing=forcing[start:end],observations=observations[start:end],dates=dates[start:end],initial_state=physical_initial.clone(),issue_start_local=warm,issue_end_local=days-3)
                native=net.analysis_step;day=0
                def observed(y,u):
                    nonlocal day
                    assert not torch.is_grad_enabled() and all(not p.requires_grad for p in net.parameters())
                    if day==0:np.testing.assert_array_equal(arr(net.m1x_posterior),arr(physical_initial))
                    np.testing.assert_array_equal(arr(y).reshape(-1),historical['observations'][start+day:start+day+1])
                    post=native(y,u);day+=1;COUNTERS['filter_days']+=1
                    if day%128==0:emit('validation_day_progress',arm=arm,days=day,total=days,global_day=start+day-1)
                    return post
                net.analysis_step=observed
                with torch.no_grad():trace=parity.run_knet_filter(net,batch,previous_observation=None)
                assert day==days and trace.valid_updates.all();prior=trace.prior_states;posterior=trace.posterior_states
                after=C.helpers.digest_tree(net.state_dict());param_after=parity.parameter_sha256(net);assert before==after and param_before==param_after
                stream=io.BytesIO();torch.save({k:v.detach().cpu().clone() for k,v in net.state_dict().items()},stream);put(cname+'/KNet_selected_network_after.pt',stream.getvalue())
                arrays.update(valid_updates=arr(trace.valid_updates),observations_assimilated=arr(observations[start:end]),requested_corrections=arr(trace.requested_corrections),state_feature_scale=arr(net.state_feature_scale),correction_cap=arr(net.correction_cap_by_state_scale_units))
                proof.update(observation_updates=days,checkpoint_epoch=81,state_dict_sha_before=before,state_dict_sha_after=after,parameter_sha_before=param_before,parameter_sha_after=param_after,parameters_require_grad=False)
            assert torch.isfinite(prior).all() and torch.isfinite(posterior).all()
            arrays.update(prior_states=arr(prior),posterior_states=arr(posterior),corrections=arr(posterior-prior))
            with torch.no_grad():forecasts=runtime.tukf06_module.multilead_torch(context.plain_model,posterior[warm:,0,:],forcing[score_start:end])
            for lead in (1,2,3):np.testing.assert_array_equal(arr(forecasts[lead][1]),np.arange(lead,lead+len(issues)))
            prediction=np.stack([arr(forecasts[k][0]) for k in (1,2,3)],axis=1);metric=scores(prediction,shared['target'],thresholds);metrics[cname][label]=metric
            arrays.update(prediction=prediction,scores=np.asarray(metric['scores']));artifact=np_save(arm+'/evaluation.npz',arrays)
            COUNTERS['filter_trajectories']+=1;COUNTERS['forecast_batches']+=1;COUNTERS['forecast_events']+=prediction.size
            assert COUNTERS['filter_days']<=21912 and COUNTERS['forecast_events']<=56904
            proof.update(filter_days=days,score_days=case['score_days'],wall_seconds=time.monotonic()-run_start,arrays=artifact,physical_parameters_sha_after=C.helpers.digest_tree(runtime.context.parameters));assert proof['physical_parameters_sha_after']==physics_hash
            records[cname][label]=proof;put(arm+'/frozen_model.json',proof);emit('phase_complete',arm=arm,phase='frozen_evaluation',days=days)
    assert COUNTERS==dict(filter_trajectories=8,filter_days=21912,forecast_batches=8,forecast_events=56904,optimizer_calls=0,autograd_calls=0,qp_calls=0)
    for name,binding in bindings.items():s.read_checked(BASE/name,binding['sha256'])
    result=dict(status='XPERIOD_COMPLETE',family=contract['family'],job_id=os.environ['SLURM_JOB_ID'],basin='02092500',metrics=metrics,trajectories=records,counters=COUNTERS,total_optimizer_calls=0,total_effective_nonzero_steps=0,comparisons={c:comparisons(m) for c,m in metrics.items()},scope=contract['scope'],failure=None)
    put('result.json',result);print('XPERIOD_RESULT='+json.dumps(result),flush=True);return 0
'''
suffix=old[old.index("if __name__=='__main__':"):].replace('BASELINE','XPERIOD').replace('KNET-BASELINE-01','KNET-XPERIOD-01')
with (BASE/'replay_worker.py').open('x',encoding='utf-8',newline='\n') as f:f.write(prefix+loop+suffix)
print('WORKER_BUILT')
