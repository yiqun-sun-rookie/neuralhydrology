"""Derive isolated transport and fixed cross-period contract, no submission."""
from pathlib import Path
import json,hashlib,datetime
BASE=Path(__file__).resolve().parent;OLD=BASE.parent/'hpc_knet_baseline_20261021_001'
def obj(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(name,value):
    p=BASE/name;p.parent.mkdir(parents=True,exist_ok=True);raw=value if isinstance(value,bytes) else (value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
    with p.open('xb') as f:f.write(raw)
rows=[]
names=['safe_io.py','local_io.py','replay_protocol.py','replay_controller.py','query_replay.py','collect_terminal.py','assemble_archive.py','fetch_receipt.py','mailbox_api.py','publish.py','observe_probe.py','deploy.py','replay.slurm','evaluation_math.py']
for name in names:
    source=OLD/name;text=source.read_text(encoding='utf-8').replace('knet_baseline_20261021_001','knet_xperiod_20261021_001').replace('knet-base-20261021-001','knet-xperiod-20261021-001').replace('KNET-BASELINE-01','KNET-XPERIOD-01').replace('BASELINE_COMPLETE','XPERIOD_COMPLETE').replace('knet_base_020_c01','knet_xperiod_020_c01')
    if name=='collect_terminal.py':
        text=text.replace("for name in ['logs','monitor_exchange','runs/02092500/attempt_001','runs/02092500/attempt_001/original','runs/02092500/attempt_001/state_constrained']:","for name in ['logs','monitor_exchange','runs/02092500/attempt_001']:").replace('for f in folder2.iterdir():','for f in folder2.rglob(\'*\'):')
    if name=='evaluation_math.py':
        text=text.replace('def forecast_indices():\n    issues=np.arange(2557,3285,dtype=np.int64)','def forecast_indices(score_start=365,end=3652):\n    issues=np.arange(score_start,end-3,dtype=np.int64)')
    put(name,text);rows.append(dict(path=name,source=str(source),source_sha256=sha(source),derived_sha256=sha(BASE/name)))
put('transport_sources.json',dict(files=rows,collector_change='recursive bounded owned run tree, including all eight model arrays; required-array coverage checked at acceptance'))
c=obj(OLD/'replay_contract.json');c.update(family='KNET-XPERIOD-01',version=1,remote_root='/data1/home/sunyiq/knet_camels_hpc_20261012_001/attempts/knet_xperiod_20261021_001',channel='knet-xperiod-20261021-001',input_bindings=obj(BASE/'checkpoint_bindings.json')['files'],cases=[dict(name='full_history',filter_start=0,score_start=365,end=3652,filter_days=3652,score_days=3287,issue_count=3284),dict(name='restart_1994',filter_start=1826,score_start=2191,end=3652,filter_days=1826,score_days=1461,issue_count=1458)],maximum_filter_trajectories=8,maximum_filter_days=21912,maximum_forecast_batches=8,maximum_forecast_events=56904,subwindows=[dict(name='early_1990_1994',case='full_history',score_start=365,end=1826),dict(name='late_1995_1999_full',case='full_history',score_start=2191,end=3652),dict(name='late_1995_1999_restart',case='restart_1994',score_start=2191,end=3652)],scope='02092500 only, current epoch81 / seed20260922 only; reused historical 1989-1999 benchmark and known meteorology; old five seeds use different short-segment recipe, not a current-recipe seed replication; fixed comparisons, no retraining, no untouched-test/statistical-significance/true-state/equal-compute claim',stability_rules=dict(primary='all fixed cases and subwindows, pooled and each lead; no window selection',report_threshold_ratios_to_hbv=[2,10,100],catastrophe_rule='any nonfinite trajectory or overall MSE >100 times same-case HBV',negative_results='keep all metrics, gate failures and finite catastrophes; no repair, retry, checkpoint or window change',history_effect='same late dates and all three targets, full_history vs restart_1994; descriptive path dependence'))
for name in ['filter_start','score_start','score_end_exclusive','issue_end_exclusive','warmup_days','score_days','filter_days_per_trajectory','forecast_events_per_arm']:c.pop(name,None)
put('replay_contract.json',c)
put('user_authorization.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),request='先用已有数组核查3日预报与UKF的差距，再结合已有多种子记录制定跨时段稳定性复核计划。冻结评估窗口、规则和预算，独立审核一次，没问题就去HPC跑。用新的独立目录，不覆盖现有实验，跑完给我结果和下一步建议。'))
put('冻结方案.md','''# KNET-XPERIOD-01：3日差距诊断与跨时段稳定性复核

## 问题与已有证据
先只读已验收245934数组。3日KNet MSE为0.471865，采样UKF为0.470808（KNet差0.22448%），反传UKF为0.479121（KNet好1.51451%）。KNet低流量较好，中高流量较差；冬春差、夏秋好；2007水文年好、2008年差。固定全728日期为主结果，贡献日期及删除最差1/5/10日仅作事后敏感性描述，不能删日修成绩。

旧合同A五种子开发期NSE均约0.90，历史期有3/5个KNet平均NSE为负（-22.38、-3.17、-28.84），另两种子0.8335、0.7954。旧五种子是短片段训练配方，当前模型是800日前向、末150日反传、121次非零更新、epoch81选模。前者是失稳风险证据，不能说后者已有五种子稳定性证据，也不抹掉旧失败。

## 冻结对象和输入
当前epoch81检查点、同一HBV物理参数与TUKF06采样46/反传253两个UKF，均沿用245934的冻结文件。禁止重选检查点、噪声、种子、尺度、上限或状态规则。KNet仍使用原生完整11维状态、原生投影与3尺度改正上限，不增加雪约束。

固定1989-10-01至1999-09-30历史输入3652日。使用旧合同A SHA=340b1a...的冻结Maurer/Oudin数据读取器，原始文件SHA及派生NPZ SHA在data_provenance.json；同读取器重建1999—2008开发输入已与已验收快照逐元素完全一致。全部历史流量、气象有限且日期连续，观测不插补。该历史期已开封，是有针对性的复核，绝非从未使用测试。模型物理参数也不宣称完全未接触该历史期。

## 固定轨迹、窗口及因果规则
两种运行历史，每种HBV、采样UKF、反传UKF、KNet四臂，合计8条：

1. full_history：1989-10-01初始化至1999-09-30，共3652滤波日，前365日预热；评分状态期1990-10-01至1999-09-30，3287日、3284共同起报日、9852个提前量事件/臂。
2. restart_1994：1994-10-01重新初始化至1999-09-30，共1826滤波日，前365日预热；评分状态期1995-10-01至1999-09-30，1461日、1458共同起报日、4374事件/臂。

各臂在各自起点使用相同因果默认物理初态（雪/液态雪0、土壤0.3FC、上层5、下层10、路由0）、无起点之前观测，UKF P0=0.001I；KNet每条重新执行原生initialize_filter，保留检查点的训练尺度与原生初始化定义。初始化物理状态不能继承别臂。UKF按原生max(baseR,(r_b*max(predQ,currentObsQ,0))^2)构造R。第t日只同化当天观测，三个预报步只用未来已知气象，不读取未来流量；目标索引严格issue+1/2/3。预热观测可用于因果滤波。掩码仅由日期及观测确定；模型非有限值导致失败，不从共同样本删去。

预先固定三个补充评分子窗：full_history的1990-10-01至1994-09-30、full_history的1995-10-01至1999-09-30、restart_1994相同后窗；每窗共同起报范围剔除最后3个无法完整三步预报的状态日。两后窗起报和目标必须逐元素一致，比较历史路径依赖。各轨迹完整期及全部水文年也逐提前量报告，不能按结果选窗。2006—2008既有数组仅复用，不在HPC重跑。

## 规则及解释
同245934报告总体/低中高流量MSE和MAE八项，分组阈值只来自1999—2006训练流量，绝不按历史期重估；额外给1/2/3日MSE、MAE、bias、NSE。沿用原数值容差max(1e-10,1e-7*abs(reference))及0.1%允许回归的流量工程界限，对HBV/两UKF逐项列出；总体MSE改善另列。它们与旧雪代理研究九门槛不是同一研究，不使用S判断HBV优劣、不改变旧九门槛。

稳定性必须报告全部固定窗及水文年，不合并掩盖不利窗。描述相对同窗HBV的MSE倍数，明确>2、>10、>100；任一非有限轨迹或总体MSE>100倍HBV记严重失稳。另报告KNet改正上限边界比例、状态分布、同后窗连续/重启差异。上限比例及状态只作描述，无雪量真值，不声称真实状态精度。有限但巨大误差仍完成技术收档，科学失败照实报告。任何失败不补跑、不换检查点、不改窗口或放宽规则。

## 预算和隔离
唯一新科学sbatch，900秒Slurm/890秒控制器/810秒工作截止，CPU请求1、数学线程1、亲和性1、无GPU、nice10、合并RSS<=6GiB/系统可用>=2GiB。最多8条滤波轨迹、21912滤波日、8批预报、56904评分事件，新增训练/梯度/QP均0。已有数组诊断本地模型调用0。完整8条约为前次4条滤波日的3.84倍，15分钟预算充足但不保证队列速度。计数按所有运行含预热，子窗重评分不新增模型计算。

新目录hpc_knet_xperiod_20261021_001、新通道knet-xperiod-20261021-001、独立remote_root。原实验及共享receiver、旧自动化只读。部署seq1唯一发布，原生Submitted回执确认job_id；结果不明只查回执，禁止重发科学提交。

## 一次独立审核与验收
实现及冻结后仅一次独立审核，PASS且阻断0才打包和部署；发现阻断则不执行，不暗中改变门槛。审核包括完整输入hash、配方/种子边界、日期预算、因果索引、初态一致性、保存全部8数组、同后窗索引和无参数更新证据。

收档器递归枚举自有runs树，已修正前次硬编码目录导致漏4模型数组的缺陷。归档manifest必须覆盖8份evaluation.npz、两份shared_arrays.npz、两份网络运行后张量。收齐包及每文件SHA才读验收；独立从保存数组重算所有指标/容差/预算/掩码/R构造，逐张量核对两条KNet运行前后网络完全相同。技术完整、工程门槛、跨时段科学效果分开。报告全部负结果、原生状态/资源、旧五种子风险，给下一步而不自动扩种子或补训。

白话总结：先查小差距来自哪里，再让当前模型去旧时段跑长一些，检查换年份或重新初始化会不会变差。跑得完与效果稳定是两回事。
''')
print(json.dumps(dict(status='CONTRACT_AND_TRANSPORT_PREPARED',budget_seconds=900,trajectories=8,filter_days=21912,forecast_events=56904)))
