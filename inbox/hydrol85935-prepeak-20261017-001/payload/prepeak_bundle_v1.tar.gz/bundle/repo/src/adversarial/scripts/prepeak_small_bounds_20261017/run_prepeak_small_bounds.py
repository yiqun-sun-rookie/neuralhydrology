"""Pre-peak vs random nonpeak windows at smaller input-error limits (HYDROL85935, R2 comment 1).

Extends the original Exp4 (run_exp4.py, 0.1 only) to limits 0.01 and 0.05 for the 14-day window,
and reruns 0.1 on the same device/code as an identity-matched reference. Model, basins, peak and
window rules, PGD budget (50 updates) and seeds are those of the original Exp4; only the limit varies.

One JSON record per basin under <out>/records/. Resumable; never overwrites a finished record.

    python src/adversarial/scripts/prepeak_small_bounds_20261017/run_prepeak_small_bounds.py \
        --out results/05_adversarial_robustness/hydrol85935_prepeak_small_bounds_20261017_001 \
        --device cpu --threads 4 --offset 0 --stride 1
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import sys
import time
from pathlib import Path

import torch

_root = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(_root))
from src.adversarial.model_wrapper import CudaLSTMWrapper  # noqa: E402
from src.adversarial.data_loader import load_basin_data  # noqa: E402
from src.adversarial.scripts.coherent_attack import CoherentBasin  # noqa: E402

RUN_DIR = _root / "results/18_lstm_fair_531/lstm_cudalstm_maurer_s100_2026_0616_1513_ep30"
BASIN_FILE = _root / "src/adversarial/data/531_basins.txt"
WINDOW = 14
EPS_LIST = [0.01, 0.05, 0.1]
# code that produced exp4_causal.json (working copy, 2026-08-06); refuse to run on anything else
FROZEN = {
    "src/adversarial/scripts/coherent_attack.py": "7b338485dc6a2ea6e8fc88c5fce1a8e6e43ac6898eb4e257ab23cd6aa04f1d76",
    "src/adversarial/model_wrapper.py": "60fe138c9e8c411e0d1c605e93ef0cb37e536db1a2cce7cc73284cb2551dda64",
    "src/adversarial/data_loader.py": "1777af8300bafb051d16e2561a308749b9f2249a296e4d97d2e95935f7af0dbe",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_frozen() -> dict:
    got = {k: sha256(_root / k) for k in FROZEN}
    bad = {k: v for k, v in got.items() if v != FROZEN[k]}
    if bad:
        raise SystemExit(f"FROZEN_CODE_MISMATCH: {bad}")
    return got


def write_atomic(path: Path, obj) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(obj, indent=1), encoding="utf-8")
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--offset", type=int, default=0)
    ap.add_argument("--stride", type=int, default=1)
    ap.add_argument("--limit", type=int, default=0, help=">0 = only the first N basins of this shard")
    ap.add_argument("--eps", type=float, nargs="+", default=EPS_LIST)
    ap.add_argument("--chunk", type=int, default=64)
    ap.add_argument("--apgd-iters", type=int, default=50)
    args = ap.parse_args()

    torch.set_num_threads(args.threads)
    code = check_frozen()
    out = Path(args.out)
    rec_dir = out / "records"
    rec_dir.mkdir(parents=True, exist_ok=True)
    dev = args.device
    basins = [b.strip() for b in open(BASIN_FILE) if b.strip()][args.offset::args.stride]
    if args.limit > 0:
        basins = basins[: args.limit]
    env = dict(torch=torch.__version__, python=platform.python_version(), device=dev,
               threads=args.threads, host=platform.node(), chunk=args.chunk, code_sha256=code)
    wrapper = CudaLSTMWrapper(run_dir=RUN_DIR, device=dev)
    todo = [b for b in basins if not (rec_dir / f"{b}.json").exists()]
    print(f"shard offset={args.offset} stride={args.stride}: {len(basins)} basins, {len(todo)} todo, "
          f"eps={args.eps}, window={WINDOW}, device={dev}, threads={args.threads}", flush=True)
    t0 = time.time()
    for i, basin in enumerate(todo):
        tb = time.time()
        rec = dict(basin=basin, window=WINDOW, n_iter=args.apgd_iters, env=env, results={})
        try:
            x_d, x_s, y_obs = load_basin_data(run_dir=RUN_DIR, basin_id=basin, period="test", device=dev)
            cb = CoherentBasin(wrapper, x_d, x_s, y_obs, dev, chunk=args.chunk)
            rec["nse_clean"] = cb.nse_clean
            for eps in args.eps:
                r = cb.apgd_causal(eps, pre_window=WINDOW, n_iter=args.apgd_iters)
                rc = cb.apgd_causal_random(eps, pre_window=WINDOW, n_iter=args.apgd_iters)
                rec["results"][f"{eps:g}"] = dict(
                    D_peak=r["D_peak"], D_overall=r["D_overall"], n_peaks=r["n_peaks"],
                    D_peak_rand=rc["D_peak_rand"], D_overall_rand=rc["D_overall_rand"],
                    n_days_pre=rc["n_days_pre"], n_days_rand=rc["n_days_rand"])
            rec["status"] = "ok"
            del cb, x_d, x_s, y_obs
        except Exception as e:  # noqa: BLE001  keep the failure on record, never drop it
            rec["status"] = "error"
            rec["error"] = repr(e)
        rec["elapsed_s"] = round(time.time() - tb, 1)
        write_atomic(rec_dir / f"{basin}.json", rec)
        print(f"[{i + 1}/{len(todo)}] {basin} {rec['status']} {rec['elapsed_s']}s "
              f"(avg {(time.time() - t0) / (i + 1):.0f}s)", flush=True)
    print("DONE", flush=True)


if __name__ == "__main__":
    main()
