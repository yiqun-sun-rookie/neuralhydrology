"""Validation-only, cross-environment counter diagnosis for one frozen model.

This is deliberately separate from the local 21-field byte-parity admission.
Each invocation performs exactly one model inference and writes one new phase.
"""

import argparse
import hashlib
import json
import os
import platform
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

import neural_runtime as rt


ROOT = Path('/data1/home/sunyiq/kalmannet_wrr_counter_diagnosis_20260928_v1')
OLD = Path('/data1/home/sunyiq/kalmannet_hamid_weights_20260923_v1')
MODEL = Path('/data1/home/sunyiq/kalmannet_wrr_hp_extension_20260902/repo/experiments/optimize_hyper_parameters/wrr_hp_extension_20260902/runs/formal_seed42_gpu/idx0014_lr0p01_hs64_nl1_mult15')
PHASES = ('plain_a', 'counted_a', 'counted_b', 'plain_b')
ARRAYS = ('updated', 'outputs', 'forecast_states', 'predictions')
INPUTS = {
    'checkpoint': (MODEL / 'results/best_model.pt', '504b27123f3fcb51c97bcd18d531c652d7a8f3cb09ded47b252a40e04d94cfc3'),
    'config': (MODEL / 'config_used.yaml', 'f9ecc592a78c4ebb676a88d79bc285040960de8e473e1b7fe22ab133302cdcc6'),
    'validation': (OLD / 'data/val_win800_20070527_04-20090314_13.pt', '2e195fc974b5cc8cdb35df3cb7fd72a202af033ecc415acc03a87020b00bd403'),
    'plain_physics': (OLD / 'probe_package_v2/sources/walrus.py', '703adbb37c7bd3804f7f218664c9636f4a3c5a303687fdbb33fc6172b0daffd2'),
    'counted_physics': (OLD / 'probe_package_v2/sources/walrus_observed.py', 'b02a8c95175557997764280a281533fcbe5a534ad2f35c9df8b6ef674dc74537'),
}
ENGINE_HASHES = {
    'neural_runtime.py': '19c94fea3e9b6cca1741856fe6d061a010c7e84dbc8943a9622705bcd3d68785',
    'evaluate_neural.py': '001e1c543f3b84fe14dc6b18320c1d9544eeaffc0d7b51a415383a7af040cfb7',
    'diagnostic_capture.py': '08f1c04ff265d73e9eee91f02c0776f35157848c236e4577629dbf5792cd3fde',
}


def now():
    return datetime.now(timezone.utc).isoformat()


def verify_sources():
    bindings = {}
    for name, (path, digest) in INPUTS.items():
        bindings[name] = rt.verify(path, digest)
    for name, digest in ENGINE_HASHES.items():
        bindings[name] = rt.verify(ROOT / 'code' / name, digest)
    formal = OLD / 'formal_package_v3'
    manifest = rt.read_json(formal / 'manifest.json')
    for name, digest in manifest['files'].items():
        if name.startswith('sources/') and name.endswith('.py'):
            bindings[name] = rt.verify(formal / name, digest)
    protocol = rt.read_json(formal / 'protocol.json')
    val = protocol['data']['val']
    if (val['name'] != INPUTS['validation'][0].name or
            val['sha256'] != INPUTS['validation'][1] or val['rows'] != 15778):
        raise ValueError('Frozen validation protocol identity changed')
    return bindings, val


def setup_runtime(output):
    for key in ('TEMP', 'TMP', 'TORCH_HOME', 'TORCH_EXTENSIONS_DIR',
                'MPLCONFIGDIR', 'XDG_CACHE_HOME', 'NUMBA_CACHE_DIR'):
        path = output / 'cache' / key
        path.mkdir(parents=True)
        os.environ[key] = str(path)
    sys.dont_write_bytecode = True
    for key in ('KF_DEBUG_CHECKS', 'FORECAST_START_LEAD', 'FORECAST_INCLUDE_CURRENT'):
        os.environ.pop(key, None)
    import numpy as np
    import torch
    if (platform.python_version(), torch.__version__, np.__version__) != ('3.11.13', '2.4.0', '2.3.3'):
        raise ValueError('Shared HPC environment versions differ from preregistered guide')
    if not torch.cuda.is_available() or torch.get_default_dtype() != torch.float32:
        raise ValueError('One CUDA device and float32 are required')
    torch.manual_seed(42)
    torch.backends.cudnn.benchmark = False
    torch.set_grad_enabled(False)
    torch.cuda.reset_peak_memory_stats()
    def forbidden(*args, **kwargs):
        raise RuntimeError('Training, optimizer steps and backward are forbidden')
    torch.Tensor.backward = forbidden
    torch.autograd.backward = forbidden
    torch.optim.Optimizer.__init__ = forbidden
    for cls in vars(torch.optim).values():
        if isinstance(cls, type) and issubclass(cls, torch.optim.Optimizer):
            cls.step = forbidden
    return dict(python=platform.python_version(), executable=sys.executable,
                torch=str(torch.__version__), numpy=np.__version__, cuda=torch.version.cuda,
                cudnn=torch.backends.cudnn.version(), device=torch.cuda.get_device_name(0),
                batch_size=256, dtype=str(torch.get_default_dtype()).removeprefix('torch.'),
                seed=int(torch.initial_seed()), cudnn_benchmark=torch.backends.cudnn.benchmark,
                amp=False, compilation=False,
                matmul_precision=torch.get_float32_matmul_precision(),
                cudnn_enabled=torch.backends.cudnn.enabled,
                cudnn_deterministic=torch.backends.cudnn.deterministic,
                deterministic_algorithms=torch.are_deterministic_algorithms_enabled(),
                cuda_matmul_allow_tf32=torch.backends.cuda.matmul.allow_tf32,
                cudnn_allow_tf32=torch.backends.cudnn.allow_tf32,
                autocast_enabled=torch.is_autocast_enabled(),
                grad_enabled=torch.is_grad_enabled())


def save_arrays(result, output):
    import numpy as np
    import evaluate_neural as ev
    ev.finite_tensors(result)
    saved = {}
    for name in ARRAYS:
        tensor = result[name].detach().cpu().contiguous().clone()
        path = output / (name + '.npy')
        with path.open('xb') as handle:
            np.save(handle, tensor.numpy(), allow_pickle=False)
        saved[name] = dict(shape=list(tensor.shape), dtype=str(tensor.dtype),
                           file_sha256=rt.sha(path),
                           raw_sha256=hashlib.sha256(tensor.numpy().tobytes()).hexdigest(),
                           bytes=path.stat().st_size)
    return saved


def run(phase, output):
    import torch
    from torch.utils.data import default_collate
    import evaluate_neural as ev

    rt.ROOT = ROOT
    rt.FORMAL = OLD / 'formal_package_v3'
    rt.PROBE = OLD / 'probe_package_v2'
    rt.install_guard(output, [INPUTS['checkpoint'][0], INPUTS['validation'][0]])
    sources, validation_protocol = verify_sources()
    rt.write_json(output / 'source_bindings.json', sources)
    environment = setup_runtime(output)
    rt.write_json(output / 'environment.json', environment)
    dataset = rt.load_dataset(*INPUTS['validation'])
    indices = list(range(256))
    if len(dataset) < 256 or dataset.window_size != 800:
        raise ValueError('Validation window geometry changed')
    before_input = {name: ev.digest_tensor(getattr(dataset, name))
                    for name in ('p', 'etpot', 'qobs', 'tm_hours', 'states_all')}
    for name in ('p', 'etpot', 'qobs', 'tm_hours'):
        if before_input[name] != validation_protocol['columns_sha256'][name]:
            raise ValueError('Frozen validation column changed: ' + name)
    batch = default_collate([dataset[i] for i in indices])
    case = dict(case_id='main_seed42__original_outlet_original_states',
                family='main', seed=42, variant='original_outlet_original_states',
                checkpoint=str(INPUTS['checkpoint'][0]),
                checkpoint_sha256=INPUTS['checkpoint'][1],
                config=str(INPUTS['config'][0]), config_sha256=INPUTS['config'][1],
                epoch=44, parameters=185448)
    runtime = rt.build_model(case, output, instrumented=False,
                             plain_physics=phase.startswith('plain'))
    before_params = {name: ev.digest_tensor(value)
                     for name, value in runtime.model.named_parameters()}
    if not before_params:
        raise ValueError('No frozen learned parameters')
    counter_before = None
    if phase.startswith('counted'):
        rt.reset_counters(runtime.hydro)
        counter_before = rt.counter_snapshot(runtime.hydro)
        if any(counter_before.values()):
            raise ValueError('Counters did not reset to zero')
    elif hasattr(runtime.hydro, 'audit_q_calls'):
        raise ValueError('Plain physics unexpectedly contains counters')
    rt.write_json(output / 'model_start.json',
                  dict(utc=now(), phase=phase, case_id=case['case_id'],
                       input_sha256_before=before_input,
                       parameter_sha256_before=before_params,
                       counters_before=counter_before))
    result = rt.infer(runtime, batch, logging=False, forecast=True)
    torch.cuda.synchronize()
    ev.finite_tensors(result)
    mapping = ev.validate_preflight_time_mapping(
        runtime, result, dataset, indices,
        dict(path=str(INPUTS['validation'][0]), sha256=INPUTS['validation'][1]))
    rt.write_json(output / 'validation_time_mapping.json', mapping)
    counters = None
    if phase.startswith('counted'):
        rt.check_counters(result['assimilation_counters'],
                          rt.expected_counters(256, 800, False))
        rt.check_counters(result['counters'],
                          rt.expected_counters(256, 800, True))
        counters = dict(before=counter_before,
                        assimilation=result['assimilation_counters'],
                        total=result['counters'])
        rt.write_json(output / 'counter_coverage.json', counters)
    arrays = save_arrays(result, output)
    after_input = {name: ev.digest_tensor(getattr(dataset, name))
                   for name in before_input}
    after_params = {name: ev.digest_tensor(value)
                    for name, value in runtime.model.named_parameters()}
    if before_input != after_input or before_params != after_params:
        raise ValueError('Input or learned model changed during inference')
    for name, (path, digest) in INPUTS.items():
        rt.verify(path, digest)
    for name, digest in ENGINE_HASHES.items():
        rt.verify(ROOT / 'code' / name, digest)
    return dict(state='HPC_CROSS_ENV_VALIDATION_DIAGNOSTIC_COMPLETE_NOT_LOCAL_ADMISSION',
                phase=phase, case_id=case['case_id'], arrays=arrays,
                counters=counters, inputs_unchanged=True,
                parameters_unchanged=True, time_mapping_passed=True,
                validation_windows=256, window_hours=800,
                issues_per_window=753, forecast_positions=48,
                source_bindings=sources, numerical_environment=environment,
                model_inference_calls=1, training_calls=0,
                test_tensor_reads=0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=PHASES, required=True)
    args = parser.parse_args()
    phase = args.phase
    output = ROOT / 'runs' / phase
    if not ROOT.is_dir() or not (ROOT / 'code/hpc_driver.py').is_file():
        raise ValueError('Exclusive HPC deployment root missing')
    for earlier in PHASES[:PHASES.index(phase)]:
        previous = ROOT / 'runs' / earlier / 'completion.json'
        if not previous.is_file() or rt.read_json(previous).get('state') != 'HPC_CROSS_ENV_VALIDATION_DIAGNOSTIC_COMPLETE_NOT_LOCAL_ADMISSION':
            raise ValueError('Earlier phase incomplete: ' + earlier)
    output.mkdir(exist_ok=False)
    start = time.perf_counter()
    entry_hash = rt.sha(__file__)
    rt.write_json(output / 'running.json',
                  dict(state='RUNNING', utc=now(), phase=phase,
                       process_id=os.getpid(), job_id=os.environ.get('SLURM_JOB_ID'),
                       driver_sha256=entry_hash))
    try:
        completion = run(phase, output)
        rt.verify(__file__, entry_hash)
        completion.update(driver_sha256=entry_hash,
                          duration_seconds=time.perf_counter() - start,
                          finished_utc=now())
        rt.write_json(output / 'completion.json', completion)
        print(completion['state'], phase, flush=True)
    except BaseException as exc:
        rt.write_json(output / 'failure.json',
                      dict(state='FAILED', phase=phase, utc=now(),
                           error=repr(exc), traceback=traceback.format_exc(),
                           model_started=(output / 'model_start.json').exists(),
                           duration_seconds=time.perf_counter() - start))
        raise
    finally:
        rt.write_json(output / 'import_ledger.json', rt.IMPORT_LEDGER)
        rt.write_json(output / 'load_ledger.json', rt.LOAD_LEDGER)
        torch = sys.modules.get('torch')
        initialized = bool(torch is not None and torch.cuda.is_initialized())
        rt.write_json(output / 'resources_end.json',
                      dict(cuda_initialized=initialized,
                           peak_cuda_allocated=torch.cuda.max_memory_allocated() if initialized else 0,
                           peak_cuda_reserved=torch.cuda.max_memory_reserved() if initialized else 0,
                           duration_seconds=time.perf_counter() - start))


if __name__ == '__main__':
    main()
