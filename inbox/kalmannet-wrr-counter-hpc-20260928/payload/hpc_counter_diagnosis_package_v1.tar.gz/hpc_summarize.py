"""Independent raw-byte comparison of four completed HPC validation phases."""

import hashlib
import json
from pathlib import Path

import numpy as np


ROOT = Path('/data1/home/sunyiq/kalmannet_wrr_counter_diagnosis_20260928_v1')
PHASES = ('plain_a', 'counted_a', 'counted_b', 'plain_b')
ARRAYS = ('updated', 'outputs', 'forecast_states', 'predictions')
PAIRS = (('plain_a', 'plain_b'), ('counted_a', 'counted_b'),
         ('plain_a', 'counted_a'), ('plain_b', 'counted_b'))
STATE = 'HPC_CROSS_ENV_VALIDATION_DIAGNOSTIC_COMPLETE_NOT_LOCAL_ADMISSION'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def compare(left, right):
    left = np.load(left, mmap_mode='r', allow_pickle=False)
    right = np.load(right, mmap_mode='r', allow_pickle=False)
    if left.shape != right.shape or left.dtype != right.dtype or left.dtype != np.float32:
        raise ValueError('Exact comparison requires equal shape and original float32')
    x = left.reshape(-1)
    y = right.reshape(-1)
    bit_count = 0
    numeric_count = 0
    first_bit = None
    first_numeric = None
    maximum = 0.0
    for start in range(0, x.size, 1_000_000):
        a = x[start:start + 1_000_000]
        b = y[start:start + 1_000_000]
        bits = a.view(np.uint32) != b.view(np.uint32)
        numeric = a != b
        count = int(np.count_nonzero(bits))
        ncount = int(np.count_nonzero(numeric))
        if count and first_bit is None:
            first_bit = start + int(np.flatnonzero(bits)[0])
        if ncount and first_numeric is None:
            first_numeric = start + int(np.flatnonzero(numeric)[0])
        bit_count += count
        numeric_count += ncount
        if a.size:
            maximum = max(maximum, float(np.max(np.abs(a.astype(np.float64) - b))))
    return dict(shape=list(left.shape), dtype=str(left.dtype),
                different_bit_elements=bit_count,
                different_numeric_elements=numeric_count,
                first_bit_flat_index=first_bit,
                first_numeric_flat_index=first_numeric,
                max_absolute_difference=maximum,
                bitwise_equal=bit_count == 0)


def main():
    output = ROOT / 'comparison.json'
    if output.exists():
        raise FileExistsError(output)
    receipts = {}
    for phase in PHASES:
        path = ROOT / 'runs' / phase / 'completion.json'
        item = json.loads(path.read_text(encoding='utf-8'))
        if (item.get('state') != STATE or item.get('phase') != phase or
                item.get('model_inference_calls') != 1 or item.get('training_calls') != 0 or
                item.get('test_tensor_reads') != 0 or not item.get('time_mapping_passed') or
                not item.get('inputs_unchanged') or not item.get('parameters_unchanged')):
            raise ValueError('Incomplete phase: ' + phase)
        for name in ARRAYS:
            path = ROOT / 'runs' / phase / (name + '.npy')
            if sha(path) != item['arrays'][name]['file_sha256']:
                raise ValueError('Saved array file changed: ' + phase + '/' + name)
        receipts[phase] = item
    environment = receipts['plain_a']['numerical_environment']
    if any(receipts[p]['numerical_environment'] != environment for p in PHASES):
        raise ValueError('Numerical environment differs across phases')
    for phase in ('counted_a', 'counted_b'):
        counters = receipts[phase]['counters']
        if not counters or counters['total']['audit_q_calls'] != 847:
            raise ValueError('Counted propagation coverage missing')
    comparisons = {}
    for a, b in PAIRS:
        comparisons[a + '__vs__' + b] = {
            name: compare(ROOT / 'runs' / a / (name + '.npy'),
                          ROOT / 'runs' / b / (name + '.npy'))
            for name in ARRAYS}
    stable_plain = all(item['bitwise_equal'] for item in comparisons['plain_a__vs__plain_b'].values())
    stable_counted = all(item['bitwise_equal'] for item in comparisons['counted_a__vs__counted_b'].values())
    cross_different = any(not item['bitwise_equal'] for item in comparisons['plain_a__vs__counted_a'].values())
    state = ('REPEAT_STABLE_COUNTING_CHANGES_HPC_NUMBERS' if stable_plain and stable_counted and cross_different
             else 'REPEAT_STABLE_NO_COUNTER_EFFECT_DETECTED' if stable_plain and stable_counted
             else 'INCONCLUSIVE_REPEAT_INSTABILITY')
    result = dict(state=state, scope='HPC cross-environment validation only; not local raw-bit admission',
                  case_id='main_seed42__original_outlet_original_states',
                  phases=list(PHASES), numerical_environment=environment,
                  stable_plain=stable_plain, stable_counted=stable_counted,
                  cross_different=cross_different, comparisons=comparisons,
                  training_calls=0, test_tensor_reads=0,
                  local_historical_result_reliability_admitted=False)
    with output.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(state, flush=True)


if __name__ == '__main__':
    main()
