"""File-only terminal export in bounded Git-mailbox pieces; never submits work."""
import sys,json,datetime,hashlib,tarfile,io,base64,subprocess,os
from pathlib import Path
import safe_io as s
base=Path(sys.argv[1]);job=sys.argv[2];part=int(sys.argv[3])
assert job.isdigit() and base.name=='state_channel_scratch_20261017_001'
identity=json.loads(s.read_checked(base/'submission.json'));assert identity['job_id']==job
query=subprocess.run([sys.executable,'-u','-B',str(base/'query_monitor.py'),str(base),job,'terminal-export'],capture_output=True,text=True,check=True)
status=json.loads(next(x.split('=',1)[1] for x in query.stdout.splitlines() if x.startswith('JOB_STATUS_JSON=')))
print('JOB_STATUS_JSON='+json.dumps(status),flush=True)
assert status['all_array_elements_terminal'],'Export only after both native array elements are terminal'
folder=s.checked_path(base/'transport_archive',False);folder.mkdir(exist_ok=True)
index_path=folder/'index.json';archive=folder/'archive.tar.gz'
if not index_path.exists():
    assert not archive.exists(),'Incomplete export needs file-only diagnosis; do not rebuild ambiguously'
    files={base/'submission.json',base/'submission_started.json',base/'deployment_manifest.json',base/'execution_authorization.json'}
    auth=json.loads(s.read_checked(base/'execution_authorization.json'))
    for row in auth['files']:
        path=s.checked_path(base/row['path']);s.read_checked(path,row['sha256']);files.add(path)
    for element in status['elements']:
        i=element['index'];basin=element['basin']
        for ext in ['out','err']:
            p=base/'logs'/('diagnostic-'+job+'_'+str(i)+'.'+ext)
            if p.is_file():files.add(s.checked_path(p))
        run=base/'runs'/basin/'attempt_001'
        if run.is_dir():
            for p in run.iterdir():
                s.checked_path(p)
                if p.is_file():files.add(p)
            for arm in ['original','state_constrained']:
                d=run/arm
                if d.is_dir():
                    for p in d.iterdir():
                        s.checked_path(p)
                        assert p.is_file(),'Unexpected nested scientific output'
                        files.add(p)
    manifest=[];partial=folder/'archive_incomplete.tar.gz'
    with partial.open('xb') as handle:
        with tarfile.open(fileobj=handle,mode='w:gz') as tar:
            for path in sorted(files):
                raw=s.read_checked(path);name=path.relative_to(base).as_posix()
                item=tarfile.TarInfo(name);item.size=len(raw);item.mode=0o644;item.mtime=0
                tar.addfile(item,io.BytesIO(raw));manifest.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
            meta=dict(job_id=job,identity=identity,accounting=status['accounting'],files=manifest,captured_utc=status['queried_utc'])
            raw=(json.dumps(meta,indent=2)+'\n').encode();item=tarfile.TarInfo('collection_manifest_'+job+'.json');item.size=len(raw);item.mode=0o644;item.mtime=0;tar.addfile(item,io.BytesIO(raw))
        handle.flush();os.fsync(handle.fileno())
    partial.rename(archive)
    pieces=[];digest=hashlib.sha256();total=0;chunk_size=8*1024**2
    with archive.open('rb') as h:
        while True:
            raw=h.read(chunk_size)
            if not raw:break
            digest.update(raw);pieces.append(dict(part=len(pieces),offset=total,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()));total+=len(raw)
    index=dict(job_id=job,identity=identity,archive_bytes=total,archive_sha256=digest.hexdigest(),files=len(manifest)+1,chunk_size=chunk_size,parts=pieces)
    s.create('transport_archive/index.json',index)
index=json.loads(s.read_checked(index_path));assert index['identity']==identity
print('ARTIFACT_COLLECTION_INDEX='+json.dumps(index),flush=True)
if part>=0:
    meta=index['parts'][part];assert meta['part']==part
    with archive.open('rb') as h:h.seek(meta['offset']);raw=h.read(meta['bytes'])
    assert len(raw)==meta['bytes'] and hashlib.sha256(raw).hexdigest()==meta['sha256']
    print('ARTIFACT_PART_METADATA='+json.dumps(dict(meta,job_id=job,archive_sha256=index['archive_sha256'])),flush=True)
    print('ARTIFACT_PART_BASE64='+base64.b64encode(raw).decode(),flush=True)
