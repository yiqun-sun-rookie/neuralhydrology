"""Paired from-scratch full-network Adam and projected-Adam, on a compute allocation."""
import os, sys, io, json, hashlib, time, datetime, traceback
from pathlib import Path


def main():
    base = Path(__file__).resolve().parent
    import safe_io as s
    assert os.environ.get('SLURM_JOB_ID', '').isdigit()
    assert json.loads(sys.stdin.readline())['resources_configured']
    raw_plan = s.read_checked(base/'plan_contract.json'); plan = json.loads(raw_plan)
    auth = json.loads(s.read_checked(base/'execution_authorization.json'))
    assert auth['status']=='AUTHORIZED' and plan['optimizer_calls_per_arm']==121
    for row in auth['files']: s.read_checked(base/row['path'], row['sha256'])
    template = base.parents[1]/'template'
    manifest = json.loads(s.read_checked(template/'bundle_manifest.json', auth['template_manifest_sha256']))
    for row in manifest['files']: s.read_checked(template/row['path'], row['sha256'])
    import numpy as np
    import torch
    import random
    from training_math import project, guarded, candidate_gate, numerical_tolerance
    torch.set_num_threads(1); torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    random.seed(plan['seed']); np.random.seed(plan['seed']); torch.manual_seed(plan['seed'])
    basin = os.environ['HPC_BASIN']; conf = next(x for x in plan['basins'] if x['basin']==basin)
    coordinate = conf['output_row']; out = sys.argv[1]; began = time.monotonic()
    os.chdir(template); sys.path.insert(0,str(template/'recipe')); os.environ['KNET_BASIN']='04105700'
    import common as C
    # This is the already verified registry repair, not a new data product.
    if basin == '02092500':
        known={'basin_02092500.npz':'453d57eab87b0d774d5895f143d51c40644f9b92fd8702ce646a6f4841378eb6',
               'basin_02092500.json':'1d888ac7e396def5d6d435574ad4af91a8adb89bf17845c87f15c5a2f2f4b0a3'}
        registered={}
        for entry in json.loads(s.read_checked(template/'recipe/evaluation_sources.json'))['files']:
            source=Path(entry['path'])
            assert not source.is_absolute() and '..' not in source.parts
            path=(template/source).resolve();name=path.name
            if name not in known:continue
            assert path.is_relative_to(template/'recipe/workspace/results') and entry['sha256']==known[name]
            key=str(path).lower()
            if key in C.DIGESTS:assert C.DIGESTS[key]==entry['sha256']
            C.DIGESTS[key]=entry['sha256'];registered[name]=entry['sha256']
        assert registered==known
    from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
    from global_hydrology.experiments import daily_camels_ukf_knet_parity_runner as parity
    from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
    from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import AccessLedger, CAUSAL_SHARED_SPINUP_MODE
    def arr(x): return x.detach().cpu().numpy().copy()
    def plain(v):
        if isinstance(v,dict): return {str(k):plain(x) for k,x in v.items()}
        if isinstance(v,(list,tuple)): return [plain(x) for x in v]
        if isinstance(v,np.ndarray): return v.tolist()
        if isinstance(v,np.generic): return v.item()
        return v
    def put(name,value): return s.create(out+'/'+name,value if isinstance(value,bytes) else plain(value))
    def np_save(name,value):
        stream=io.BytesIO();np.savez_compressed(stream,**value);return put(name,stream.getvalue())
    def pt_save(name,value):
        stream=io.BytesIO();torch.save(value,stream);return put(name,stream.getvalue())
    def load_np(name):
        with np.load(io.BytesIO(s.read_checked(base/'inputs'/basin/name)),allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
    def emit(event,**values):
        entry=dict(event=event,basin=basin,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-began)
        entry.update(plain(values));print(json.dumps(entry,allow_nan=False),flush=True)
    digest=C.helpers.digest_tree
    cp=torch.load(io.BytesIO(s.read_checked(base/'inputs'/basin/'initial.pt',conf['initial_checkpoint_sha256'])),weights_only=True,map_location='cpu')
    assert cp['epoch']==cp['optimizer_steps']==0 and not cp['optimizer']['state']
    assert cp['seed']==plan['seed']
    runtime=per.load_per_basin_development_runtime(get_development_basin_specification(basin),ledger=AccessLedger(),initialization_mode=CAUSAL_SHARED_SPINUP_MODE,device='cpu')
    assert runtime.training_days==2557 and len(runtime.dates)==3288
    states=parity.training_open_loop_states(runtime)
    scales=parity.fit_training_feature_scales(runtime,floor=.1)
    per.fit_training_feature_scales=lambda r,*,floor=.1:scales
    advance=parity._advance_open_loop
    parity._advance_open_loop=lambda context,forcing,*,end_exclusive:states[-1].clone() if context is runtime.context and end_exclusive==2557 else advance(context,forcing,end_exclusive=end_exclusive)
    window=parity.select_window(runtime,'recovery');TT=float(runtime.context.plain_model.params['parTT'])
    observations=arr(runtime.observations).reshape(-1);forcing=arr(runtime.forcing)
    dates=runtime.dates.astype('datetime64[ns]').astype('int64');issues=np.arange(2557,3285)
    targets=observations[issues[:,None]+np.arange(1,4)]
    thresholds=np.quantile(observations[:2557],[.5,.9,.99],method='linear')
    ref=load_np('reference.npz' if basin=='02092500' else 'main.npz')
    assert np.array_equal(targets,ref['target']) and np.array_equal(issues,ref['issue_indices'])
    assert np.array_equal(dates[issues[:,None]+np.arange(1,4)],ref['target_dates_ns'])
    np_save('input_snapshot.npz',dict(observations=observations,forcing=forcing,dates_ns=dates,thresholds=thresholds,training_open_loop=arr(states),initial_validation_state=arr(window.initial_state)))
    def groups(y):return [np.ones(y.shape,dtype=bool),y<=thresholds[0],(y>thresholds[0])&(y<=thresholds[1]),y>thresholds[1]]
    training_counts=sum((np.array([m.sum() for m in groups(observations[start+np.arange(695,797)[:,None]+np.arange(1,4)])]) for start in plan['base_starts']),start=np.zeros(4,dtype=np.int64))
    assert training_counts[0]==7650 and np.all(training_counts>0)
    arms={};initial_hashes={};initial_snapshots={}
    for arm in plan['arms']:
        net=per.build_exact_dimension_kalman_net(runtime,zero_gain=False,seed=plan['seed'],gain_initialization='near_zero_fc2_head',hidden=24,input_multiplier=10,output_multiplier=10,feature_scale_floor=.1,normalized_feature_guard=10.,correction_cap_in_state_scale_units=3.)
        net.load_state_dict(cp['network'],strict=True)
        assert parity.parameter_sha256(net)==conf['initial_parameter_sha256']
        for p in net.parameters():p.requires_grad_(True)
        params=list(net.parameters());names=[n for n,p in net.named_parameters()]
        opt=torch.optim.Adam(params,lr=.0005,weight_decay=0.,betas=(.9,.999),eps=1e-8)
        opt.load_state_dict(cp['optimizer']);assert not opt.state
        state=dict(arm=arm,net=net,parameters=params,names=names,optimizer=opt,calls=0,effective=0,history=[],rng=cp['torch_rng_state'].clone(),trace=None,count=0,step=0,phase='initialization')
        native=net.analysis_step
        def wrapped(native,net,state):
            def update(y,u):
                previous=net.m1x_posterior;post=native(y,u);i=state['count'];state['count']+=1
                if i==650:
                    state['boundary']={k:bool(getattr(net,k).grad_fn is not None) for k in C.probe.RECURRENCE_FIELDS}
                if state['trace'] is not None and i>=state['record_after']:
                    state['trace'].append(dict(prior=net.m1x_prior,posterior=post,previous=previous,requested=net.last_correction,prior_flow=net.m1y.reshape(())))
                return post
            return update
        net.analysis_step=wrapped(native,net,state)
        snapshots=[]
        for start in [*plan['base_starts'],2557]:
            initial=runtime.context.initial_state.clone() if start==0 else states[start-1].clone()
            previous=None if start==0 else runtime.observations[start-1:start].clone()
            net.initialize_filter(initial,731 if start==2557 else 800,previous_observation=previous)
            snapshots.append({k:digest(getattr(net,k)) for k in C.probe.RECURRENCE_FIELDS})
        initial_snapshots[arm]=snapshots
        initial_hashes[arm]=dict(network=digest(net.state_dict()),optimizer=digest(opt.state_dict()),rng=digest(state['rng']))
        arms[arm]=state
    assert initial_hashes['original']==initial_hashes['state_constrained']
    assert initial_snapshots['original']==initial_snapshots['state_constrained']
    put('initialization_gate.json',dict(status='PASS',checkpoint_epoch=0,hashes=initial_hashes,initial_snapshots=initial_snapshots,trainable_names=names,trainable_parameter_count=sum(p.numel() for p in params),all_network_parameters_trainable=True))
    def vector(state):return np.concatenate([arr(p).reshape(-1) for p in state['parameters']]).astype(np.float64)
    def install(state,values):
        offset=0
        with torch.no_grad():
            for p in state['parameters']:
                size=p.numel();p.copy_(torch.as_tensor(values[offset:offset+size].reshape(tuple(p.shape)),dtype=p.dtype));offset+=size
        assert offset==len(values)
    def state_mask(trace,start):
        previous=np.stack([arr(r['previous']).reshape(-1) for r in trace]);prior=np.stack([arr(r['prior']).reshape(-1) for r in trace]);ix=np.arange(start,start+len(trace))
        if coordinate==0:return (forcing[ix,0,1]>=TT)&(prior[:,0]<=0)
        return (forcing[ix,0,0]==0)&(previous[:,0]<=0)&(previous[:,1]<=0)&(observations[ix]<=thresholds[0])&(observations[ix]<=observations[ix-1])
    def state_values(trace,start,state):
        if coordinate==0:
            values=torch.stack([torch.relu((r['posterior']-r['prior'])[0,0]) for r in trace]);scale=float(state['net'].state_feature_scale[0,0])
        else:
            pf=torch.stack([r['prior_flow'] for r in trace]);values=torch.relu(pf-torch.as_tensor(observations[start:start+len(trace)],dtype=pf.dtype));scale=float(state['net'].observation_feature_scale.reshape(()))
        return values/scale
    masks={};state_count=0;validation_mask=None
    def training(state,gradient=False,freeze_masks=False,label='training'):
        nonlocal state_count
        net=state['net'];net.train();scores=np.zeros(9);g=np.zeros((9,len(vector(state)))) if gradient else None
        predictions=[];proxy=[];segment_gradient_norms=[];history_graph=[]
        for number,start in enumerate(plan['base_starts']):
            initial=runtime.context.initial_state.clone() if start==0 else states[start-1].clone()
            context=parity._context_with_initial_state(runtime.context,initial)
            batch=parity.WindowBatch(purpose='training_segment',global_start=start,global_end_exclusive=start+800,context=context,forcing=runtime.forcing[start:start+800],observations=runtime.observations[start:start+800],dates=runtime.dates[start:start+800],initial_state=initial,issue_start_local=695,issue_end_local=797)
            state['trace']=[];state['count']=0;state['record_after']=650
            with torch.set_grad_enabled(gradient):
                filtered=parity.run_knet_filter(net,batch,previous_observation=parity.previous_observation_before_window(runtime,batch))
                assert state['count']==800 and len(state['trace'])==150
                if gradient:assert any(state['boundary'].values()),'Full historical graph was lost'
                history_graph.append(dict(start=start,gradient=gradient,day650=state['boundary']))
                raw=runtime.tukf06_module.multilead_torch(batch.context.plain_model,filtered.posterior_states[:,0,:],batch.forcing)
                pred=torch.stack([raw[k][0][695:797] for k in (1,2,3)],dim=1)
                y=runtime.observations[start+torch.arange(695,797)[:,None]+torch.arange(1,4),0];error=pred-y;losses=[]
                for group,denom in zip(groups(arr(y)),training_counts):
                    selected=error[torch.as_tensor(group)];losses.extend([selected.square().sum()/int(denom),selected.abs().sum()/int(denom)])
                if freeze_masks:masks[start]=state_mask(state['trace'],start+650);state_count+=int(masks[start].sum())
                values=state_values(state['trace'],start+650,state);mask=torch.as_tensor(masks[start],dtype=torch.bool)
                # Initial mask discovery uses a sum; it is divided after the total count is known.
                target=values[mask].square().sum()/(1 if freeze_masks else state_count)
                objectives=losses+[target];scores+=np.array([float(x.detach()) for x in objectives])
                predictions.append(arr(pred));proxy.append(arr(values))
                if gradient:
                    needed=list(range(9)) if state['arm']=='state_constrained' else [0]
                    local=[]
                    for j,index in enumerate(needed):
                        pieces=torch.autograd.grad(objectives[index],state['parameters'],retain_graph=j<len(needed)-1,allow_unused=True)
                        flat=np.concatenate([np.zeros(p.numel()) if q is None else arr(q).reshape(-1) for p,q in zip(state['parameters'],pieces)])
                        g[index]+=flat;local.append(float(np.linalg.norm(flat)))
                    segment_gradient_norms.append(local)
            state['trace']=None
            emit('training_segment_progress',arm=state['arm'],step=state['step'],label=label,segments=number+1,total=25,gradient=gradient,optimizer_calls=state['calls'])
        if freeze_masks:
            assert state_count>0,'No untrained-origin fixed proxy events';scores[8]/=state_count
        if not np.isfinite(scores).all() or gradient and not np.isfinite(g).all():raise FloatingPointError('nonfinite objective or gradient')
        arrays=dict(prediction=np.stack(predictions),state_proxy_values=np.stack(proxy),state_mask=np.stack([masks[x] for x in plan['base_starts']]),scores=scores)
        if segment_gradient_norms:arrays['segment_gradient_norms']=np.array(segment_gradient_norms)
        if gradient and state['step'] in (1,121):put(state['arm']+f'/history_graph_{state["step"]:03d}.json',history_graph)
        return scores,g,arrays
    def validation(state,freeze_mask=False):
        nonlocal validation_mask
        net=state['net'];net.eval();state['trace']=[];state['count']=0;state['record_after']=0
        with torch.no_grad():
            trace=parity.run_knet_filter(net,window,previous_observation=parity.previous_observation_before_window(runtime,window))
            fc=parity.aligned_forecasts_from_posterior(runtime,window,trace.posterior_states)
            pairs=parity.forecast_pairs(window.observations,fc,issue_start=0,issue_end=728,leads=(1,2,3))
            pred=np.stack([pairs.predictions[k] for k in (1,2,3)],axis=1)
            if freeze_mask:validation_mask=state_mask(state['trace'],2557)
            assert validation_mask is not None and validation_mask.any()
            values=arr(state_values(state['trace'],2557,state))
            scores=[];e=pred-targets
            for mask in groups(targets):scores.extend([float(np.mean(e[mask]**2)),float(np.mean(np.abs(e[mask])))])
            scores.append(float(np.mean(values[validation_mask]**2)))
            data={k:np.stack([arr(row[k]).reshape(-1) for row in state['trace']]) for k in state['trace'][0]}
        data.update(prediction=pred,target=targets,issue_indices=issues,target_dates_ns=dates[issues[:,None]+np.arange(1,4)],state_mask=validation_mask,state_proxy_values=values,scores=np.array(scores))
        state['trace']=None
        assert np.isfinite(pred).all() and np.isfinite(scores).all()
        return np.array(scores),data
    def checkpoint(state):
        return dict(basin=basin,arm=state['arm'],optimizer_calls=state['calls'],effective_nonzero_steps=state['effective'],network={k:v.detach().cpu().clone() for k,v in state['net'].state_dict().items()},optimizer=state['optimizer'].state_dict(),torch_rng_state=state['rng'].clone(),parameter_sha256=parity.parameter_sha256(state['net']),contract_sha256=hashlib.sha256(raw_plan).hexdigest(),initial_parameter_sha256=conf['initial_parameter_sha256'])
    failure=None;active_arm=None;active_step=0
    try:
        initial_train=None;initial_validation=None
        for arm,state in arms.items():
            active_arm=arm;torch.set_rng_state(state['rng']);state['phase']='initialization_baseline'
            train,_,data=training(state,freeze_masks=arm=='original',label='initialization')
            val,vd=validation(state,freeze_mask=arm=='original')
            if arm=='original':initial_train=train.copy();initial_validation=val.copy()
            else:np.testing.assert_array_equal(train,initial_train);np.testing.assert_array_equal(val,initial_validation)
            np_save(arm+'/training_000.npz',data);np_save(arm+'/validation_000.npz',vd);pt_save(arm+'/checkpoint_000.pt',checkpoint(state))
            state['history'].append(dict(step=0,optimizer_calls=0,effective_nonzero_steps=0,training_scores=train.tolist(),validation_scores=val.tolist()))
        np_save('fixed_training_masks.npz',{str(k):v for k,v in masks.items()});np_save('fixed_validation_mask.npz',dict(mask=validation_mask))
        put('state_mask_origin.json',dict(source='paired original untrained epoch0 trajectory, frozen before any update',training_mask_events=state_count,validation_mask_events=int(validation_mask.sum()),no_candidate_or_epoch_mask_reselection=True))
        emit('initialization_and_reference_complete',training_mask_events=state_count,validation_mask_events=int(validation_mask.sum()),optimizer_calls=0)
        for active_step in range(1,122):
            reference=None
            for active_arm,state in arms.items():
                state['step']=active_step;torch.set_rng_state(state['rng']);state['phase']='gradient'
                before=vector(state);moment_before=digest(state['optimizer'].state_dict())
                state['phase']='pre_update_replay'
                pre_nograd,_,pre_arrays=training(state,label='pre_update_nograd')
                train,g,training_arrays=training(state,gradient=True,label='gradient')
                opt=state['optimizer'];opt.zero_grad(set_to_none=True);offset=0
                for p in state['parameters']:
                    size=p.numel();p.grad=torch.as_tensor(g[0,offset:offset+size].reshape(tuple(p.shape)),dtype=p.dtype).clone();offset+=size
                norm=float(torch.nn.utils.clip_grad_norm_(state['parameters'],10.,error_if_nonfinite=True))
                if not np.isfinite(norm):raise FloatingPointError('nonfinite gradient norm')
                state['phase']='adam_proposal';opt.step();state['calls']+=1
                put(active_arm+f'/optimizer_call_{active_step:03d}.json',dict(step=active_step,optimizer_calls=state['calls'],effective_nonzero_steps_before_proposal=state['effective'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
                proposed=vector(state);proposal=proposed-before
                if not np.isfinite(proposed).all():raise FloatingPointError('nonfinite proposal')
                moment_after=digest(opt.state_dict());line=[];projection=None;accepted_factor=1.;accepted=True
                if active_arm=='original':
                    state['phase']='paired_reference';after,_,after_arrays=training(state,label='paired_reference');reference=after.copy()
                    np_save(active_arm+f'/training_{active_step:03d}.npz',after_arrays)
                else:
                    assert reference is not None
                    install(state,before);state['phase']='projection';exact,certificate=project(proposal,g,tolerance=plan['tolerances']['linear_normalized'])
                    projection=dict(certificate=certificate);accepted=False;accepted_factor=0.;after=pre_nograd.copy()
                    radius=2*float(np.linalg.norm(proposal))+float(np.finfo(np.float32).eps)
                    if exact is not None:
                        for alpha in plan['backtracking_factors']:
                            state['phase']='float32_guard';candidate,guard=guarded(before,alpha*exact,g,radius,tolerance=plan['tolerances']['linear_normalized'])
                            entry=dict(factor=alpha,guard=guard)
                            if candidate is None:line.append(entry);continue
                            install(state,before+candidate)
                            state['phase']='candidate_replay';score,_,data=training(state,label='candidate_'+str(alpha))
                            gate=candidate_gate(score,reference,relative_margin=plan['allowed_flow_relative_regression'],absolute=plan['tolerances']['metric_absolute'],relative=plan['tolerances']['metric_relative'])
                            entry.update(gate=gate,scores=score.tolist(),archive=np_save(active_arm+f'/candidate_{active_step:03d}_{str(alpha).replace(".","p")}.npz',data));line.append(entry)
                            if gate['accepted']:accepted=True;accepted_factor=alpha;after=score;break
                            install(state,before)
                    if not accepted:
                        install(state,before)
                        # Rejected calls still consume budget and retain Adam moments.
                        np_save(active_arm+f'/training_{active_step:03d}.npz',pre_arrays)
                actual=vector(state)-before;changed=bool(np.any(actual));state['effective']+=int(changed)
                # Full proof every call, so terminal acceptance can recompute actual products and KKT.
                proof=dict(before=before,proposal=proposal,gradients=g,actual=actual,reference=np.array([]) if reference is None else reference,pre_scores=pre_nograd,gradient_mode_scores=train)
                if active_arm=='state_constrained' and exact is not None:proof['exact']=exact
                if active_arm=='state_constrained' and accepted:proof['guarded']=candidate
                proof_id=np_save(active_arm+f'/proposal_{active_step:03d}.npz',proof)
                state['phase']='validation';val,vd=validation(state)
                trace_id=None
                state['rng']=torch.get_rng_state().clone()
                if active_step==121:
                    trace_id=np_save(active_arm+'/validation_121.npz',vd)
                    pt_save(active_arm+'/checkpoint_121.pt',checkpoint(state))
                row=dict(step=active_step,optimizer_calls=state['calls'],effective_nonzero_steps=state['effective'],parameter_changed=changed,gradient_norm_before_clip=norm,training_pre=pre_nograd.tolist(),training_pre_graph=train.tolist(),training_post=after.tolist(),training_paired_reference=None if reference is None else reference.tolist(),validation_scores=val.tolist(),projection=projection,candidates=line,accepted=accepted,accepted_factor=accepted_factor,optimizer_moments_before_sha256=moment_before,optimizer_moments_after_sha256=moment_after,actual_norm=float(np.linalg.norm(actual)),proposal_proof=proof_id,trace=trace_id)
                state['history'].append(row);put(active_arm+f'/epoch_{active_step:03d}.json',row)
                emit('epoch_complete',arm=active_arm,step=active_step,optimizer_calls=state['calls'],effective_nonzero_steps=state['effective'],parameter_changed=changed,validation_mse=val[0],state_proxy=val[8],accepted_factor=accepted_factor)
    except BaseException as error:
        failure=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc(),arm=active_arm,step=active_step,phase=None if active_arm is None else arms[active_arm]['phase'])
        put('failure.json',failure);emit('training_failure',**{k:failure[k] for k in ['type','message','arm','step','phase']})
        for state in arms.values():pt_save(state['arm']+'/failure_checkpoint.pt',checkpoint(state))
    results={}
    for arm,state in arms.items():
        put(arm+'/history.json',state['history'])
        results[arm]=dict(optimizer_calls=state['calls'],effective_nonzero_steps=state['effective'],initial=state['history'][0] if state['history'] else None,last=state['history'][-1] if state['history'] else None)
    complete=failure is None and all(state['calls']==121 for state in arms.values())
    put('result.json',dict(status='COMPLETE' if complete else 'FAILED',experiment_id=plan['experiment_id'],basin=basin,job_id=os.environ['SLURM_JOB_ID'],array_job_id=os.environ['SLURM_ARRAY_JOB_ID'],array_task_id=os.environ['SLURM_ARRAY_TASK_ID'],arms=results,total_optimizer_calls=sum(x['calls'] for x in arms.values()),failure=failure,training_counts=training_counts.tolist(),state_target_count=state_count,thresholds=thresholds.tolist(),proxy_coordinate=coordinate,scope=plan['scope']))
    if not complete:raise SystemExit(1)
    emit('basin_complete',total_optimizer_calls=242)


if __name__=='__main__':main()
