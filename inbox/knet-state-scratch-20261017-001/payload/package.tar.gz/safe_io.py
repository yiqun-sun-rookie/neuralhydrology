"""Linux port of the frozen file-access boundary; exclusive evidence writes."""
import hashlib
import json
import os
from pathlib import Path
import re

DENY = re.compile(r'formal[-_]evaluation|phase_a_results|unseal', re.I)
ROOT = Path(__file__).resolve().parent


def checked_path(path, exists=True):
    p = Path(path)
    if not p.is_absolute() or '..' in p.parts or DENY.search(str(p)):
        raise PermissionError('forbidden path')
    for item in (p, *p.parents):
        if item.is_symlink():
            raise PermissionError('linked path')
    if exists and p.resolve(strict=True) != p:
        raise PermissionError('target differs')
    return p


def read_checked(path, digest=None):
    p = checked_path(path)
    descriptor = os.open(p, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, 'rb') as handle:
        if os.readlink('/proc/self/fd/' + str(handle.fileno())) != str(p):
            raise PermissionError('opened target differs')
        before = os.fstat(handle.fileno())
        raw = handle.read()
        after = os.fstat(handle.fileno())
    if (before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns):
        raise RuntimeError('source changed')
    if digest and hashlib.sha256(raw).hexdigest() != digest:
        raise RuntimeError('hash differs')
    return raw


def create(relative, value):
    p = checked_path(ROOT / relative, False)
    if not p.is_relative_to(ROOT):
        raise PermissionError('output outside trial')
    p.parent.mkdir(parents=True, exist_ok=True)
    raw = value if isinstance(value, bytes) else (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()
    with p.open('xb') as handle:
        handle.write(raw)
    return {'path': relative, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
