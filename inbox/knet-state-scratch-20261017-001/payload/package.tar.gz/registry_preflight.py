"""Pure file registry check on the real packaged template; no model imports."""
import sys,json,ast,hashlib,types
from pathlib import Path
import safe_io as s
base=Path(__file__).resolve().parent
template=base.parents[1]/'template'
auth=json.loads(s.read_checked(base/'execution_authorization.json'))
manifest=json.loads(s.read_checked(template/'bundle_manifest.json',auth['template_manifest_sha256']))
for row in manifest['files']:s.read_checked(template/row['path'],row['sha256'])
scope=dict(basin='02092500',template=template,Path=Path,json=json,s=s,C=types.SimpleNamespace(DIGESTS={}))
worker=ast.parse(s.read_checked(base/'worker.py'))
main=next(n for n in worker.body if isinstance(n,ast.FunctionDef) and n.name=='main')
block=next(n for n in main.body if isinstance(n,ast.If) and isinstance(n.test,ast.Compare) and ast.unparse(n.test)=="basin == '02092500'")
exec(compile(ast.Module(body=[block],type_ignores=[]),'actual_worker_registry','exec'),scope)
assert len(scope['C'].DIGESTS)==2
verified=[]
for name in ['basin_02092500.npz','basin_02092500.json']:
    entries=[(p,h) for p,h in scope['C'].DIGESTS.items() if Path(p).name==name]
    assert len(entries)==1
    p,h=entries[0];data=s.read_checked(Path(p),h)
    verified.append(dict(path=p,sha256=h,bytes=len(data)))
print('STARTUP_REGISTRY_PREFLIGHT='+json.dumps(dict(status='PASS',actual_worker_block=True,model_imports=False,verified=verified)),flush=True)
