"""Paired from-scratch full-network Adam and projected-Adam, on a compute allocation."""
import os, sys, io, json, hashlib, time, datetime, traceback
from pathlib import Path


def main():
    base = Path(__file__).resolve().parent
    import safe_io as s
    assert os.environ.get('SLURM_JOB_ID', '').isdigit()
    assert json.loads(sys.stdin.readline())['resources_configured']
    raw_plan = s.read_checked(base/'replay_contract.json'); contract = json.loads(raw_plan); plan=contract['original_contract']
    auth = json.loads(s.read_checked(base/'execution_authorization.json'))
    assert auth['status']=='AUTHORIZED' and plan['optimizer_calls_per_arm']==5
    for row in auth['files']: s.read_checked(base/row['path'], row['sha256'])
    template = base.parents[1]/'template'
    manifest = json.loads(s.read_checked(template/'bundle_manifest.json', auth['template_manifest_sha256']))
    for row in manifest['files']: s.read_checked(template/row['path'], row['sha256'])
    import numpy as np
    import torch
    import random
    from training_math import candidate_gate
    from gap_math import project_gap,guard_gap
    from candidate_rules import FACTORS,ORDER,bounds,mix_installed
    torch.set_num_threads(1); torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    random.seed(plan['seed']); np.random.seed(plan['seed']); torch.manual_seed(plan['seed'])
    basin = '02092500'; conf = next(x for x in plan['basins'] if x['basin']==basin)
    coordinate = conf['output_row']; out = 'runs/02092500/attempt_001'; began = time.monotonic()
    counters=dict(completed_training_passes=0,completed_segments=0,filter_days=0,autograd_calls=0,qp_main=0,qp_guard=0,validation_replays=0)
    os.chdir(template); sys.path.insert(0,str(template/'recipe')); os.environ['KNET_BASIN']='04105700'
    import common as C
    # This is the already verified registry repair, not a new data product.
    if basin == '02092500':
        known={'basin_02092500.npz':'453d57eab87b0d774d5895f143d51c40644f9b92fd8702ce646a6f4841378eb6',
               'basin_02092500.json':'1d888ac7e396def5d6d435574ad4af91a8adb89bf17845c87f15c5a2f2f4b0a3'}
        registered={}
        for entry in json.loads(s.read_checked(template/'recipe/evaluation_sources.json'))['files']:
            source=Path(entry['path'])
            assert not source.is_absolute() and '..' not in source.parts
            path=(template/source).resolve();name=path.name
            if name not in known:continue
            assert path.is_relative_to(template/'recipe/workspace/results') and entry['sha256']==known[name]
            key=str(path).lower()
            if key in C.DIGESTS:assert C.DIGESTS[key]==entry['sha256']
            C.DIGESTS[key]=entry['sha256'];registered[name]=entry['sha256']
        assert registered==known
    from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
    from global_hydrology.experiments import daily_camels_ukf_knet_parity_runner as parity
    from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
    from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import AccessLedger, CAUSAL_SHARED_SPINUP_MODE
    def arr(x): return x.detach().cpu().numpy().copy()
    def plain(v):
        if isinstance(v,dict): return {str(k):plain(x) for k,x in v.items()}
        if isinstance(v,(list,tuple)): return [plain(x) for x in v]
        if isinstance(v,np.ndarray): return v.tolist()
        if isinstance(v,np.generic): return v.item()
        return v
    def put(name,value): return s.create(out+'/'+name,value if isinstance(value,bytes) else plain(value))
    def np_save(name,value):
        stream=io.BytesIO();np.savez_compressed(stream,**value);return put(name,stream.getvalue())
    def pt_save(name,value):
        stream=io.BytesIO();torch.save(value,stream);return put(name,stream.getvalue())
    def load_np(name):
        with np.load(io.BytesIO(s.read_checked(base/'inputs'/name)),allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
    def emit(event,**values):
        entry=dict(event=event,basin=basin,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-began)
        entry.update(total_optimizer_calls=sum(x['calls'] for x in arms.values()),total_effective_nonzero_steps=sum(x['effective'] for x in arms.values()))
        entry.update(plain(values));print(json.dumps(entry,allow_nan=False),flush=True)
    digest=C.helpers.digest_tree
    cp=torch.load(io.BytesIO(s.read_checked(base/'inputs/initial.pt',conf['initial_checkpoint_sha256'])),weights_only=True,map_location='cpu')
    assert cp['epoch']==cp['optimizer_steps']==0 and not cp['optimizer']['state']
    assert cp['seed']==plan['seed']
    runtime=per.load_per_basin_development_runtime(get_development_basin_specification(basin),ledger=AccessLedger(),initialization_mode=CAUSAL_SHARED_SPINUP_MODE,device='cpu')
    assert runtime.training_days==2557 and len(runtime.dates)==3288
    states=parity.training_open_loop_states(runtime)
    scales=parity.fit_training_feature_scales(runtime,floor=.1)
    per.fit_training_feature_scales=lambda r,*,floor=.1:scales
    TT=float(runtime.context.plain_model.params['parTT'])
    observations=arr(runtime.observations).reshape(-1);forcing=arr(runtime.forcing)
    dates=runtime.dates.astype('datetime64[ns]').astype('int64')
    thresholds=np.quantile(observations[:2557],[.5,.9,.99],method='linear')
    snapshot=load_np('input_snapshot.npz')
    for key,value in [('observations',observations),('forcing',forcing),('dates_ns',dates),('thresholds',thresholds),('training_open_loop',arr(states))]:
        np.testing.assert_array_equal(value,snapshot[key])
    np_save('input_snapshot.npz',snapshot)
    def groups(y):return [np.ones(y.shape,dtype=bool),y<=thresholds[0],(y>thresholds[0])&(y<=thresholds[1]),y>thresholds[1]]
    training_counts=sum((np.array([m.sum() for m in groups(observations[start+np.arange(695,797)[:,None]+np.arange(1,4)])]) for start in plan['base_starts']),start=np.zeros(4,dtype=np.int64))
    assert training_counts[0]==7650 and np.all(training_counts>0)
    arms={};initial_hashes={};initial_snapshots={}
    for arm in plan['arms']:
        net=per.build_exact_dimension_kalman_net(runtime,zero_gain=False,seed=plan['seed'],gain_initialization='near_zero_fc2_head',hidden=24,input_multiplier=10,output_multiplier=10,feature_scale_floor=.1,normalized_feature_guard=10.,correction_cap_in_state_scale_units=3.)
        net.load_state_dict(cp['network'],strict=True)
        assert parity.parameter_sha256(net)==conf['initial_parameter_sha256']
        for p in net.parameters():p.requires_grad_(True)
        params=list(net.parameters());names=[n for n,p in net.named_parameters()]
        opt=torch.optim.Adam(params,lr=.0005,weight_decay=0.,betas=(.9,.999),eps=1e-8)
        opt.load_state_dict(cp['optimizer']);assert not opt.state
        state=dict(arm=arm,net=net,parameters=params,names=names,optimizer=opt,calls=0,effective=0,history=[],rng=cp['torch_rng_state'].clone(),trace=None,count=0,step=0,phase='initialization')
        native=net.analysis_step
        def wrapped(native,net,state):
            def update(y,u):
                previous=net.m1x_posterior;post=native(y,u);i=state['count'];state['count']+=1
                if i==650:
                    state['boundary']={k:bool(getattr(net,k).grad_fn is not None) for k in C.probe.RECURRENCE_FIELDS}
                if state['trace'] is not None and i>=state['record_after']:
                    state['trace'].append(dict(prior=net.m1x_prior,posterior=post,previous=previous,requested=net.last_correction,prior_flow=net.m1y.reshape(())))
                return post
            return update
        net.analysis_step=wrapped(native,net,state)
        snapshots=[]
        for start in plan['base_starts']:
            initial=runtime.context.initial_state.clone() if start==0 else states[start-1].clone()
            previous=None if start==0 else runtime.observations[start-1:start].clone()
            net.initialize_filter(initial,800,previous_observation=previous)
            snapshots.append({k:digest(getattr(net,k)) for k in C.probe.RECURRENCE_FIELDS})
        initial_snapshots[arm]=snapshots
        initial_hashes[arm]=dict(network=digest(net.state_dict()),optimizer=digest(opt.state_dict()),rng=digest(state['rng']))
        state['buffer_sha']=digest(dict(net.named_buffers()))
        arms[arm]=state
    assert initial_hashes['original']==initial_hashes['state_constrained']
    assert initial_snapshots['original']==initial_snapshots['state_constrained']
    put('initialization_gate.json',dict(status='PASS',checkpoint_epoch=0,hashes=initial_hashes,initial_snapshots=initial_snapshots,trainable_names=names,trainable_parameter_count=sum(p.numel() for p in params),all_network_parameters_trainable=True))
    def vector(state):return np.concatenate([arr(p).reshape(-1) for p in state['parameters']]).astype(np.float64)
    def install(state,values):
        offset=0
        with torch.no_grad():
            for p in state['parameters']:
                size=p.numel();p.copy_(torch.as_tensor(values[offset:offset+size].reshape(tuple(p.shape)),dtype=p.dtype));offset+=size
        assert offset==len(values)
    def state_mask(trace,start):
        previous=np.stack([arr(r['previous']).reshape(-1) for r in trace]);prior=np.stack([arr(r['prior']).reshape(-1) for r in trace]);ix=np.arange(start,start+len(trace))
        if coordinate==0:return (forcing[ix,0,1]>=TT)&(prior[:,0]<=0)
        return (forcing[ix,0,0]==0)&(previous[:,0]<=0)&(previous[:,1]<=0)&(observations[ix]<=thresholds[0])&(observations[ix]<=observations[ix-1])
    def state_values(trace,start,state):
        if coordinate==0:
            values=torch.stack([torch.relu((r['posterior']-r['prior'])[0,0]) for r in trace]);scale=float(state['net'].state_feature_scale[0,0])
        else:
            pf=torch.stack([r['prior_flow'] for r in trace]);values=torch.relu(pf-torch.as_tensor(observations[start:start+len(trace)],dtype=pf.dtype));scale=float(state['net'].observation_feature_scale.reshape(()))
        return values/scale
    masks={};state_count=0;validation_mask=None
    def training(state,gradient=False,freeze_masks=False,label='training'):
        nonlocal state_count
        assert counters['completed_training_passes']<87
        rng_before=torch.get_rng_state().clone()
        net=state['net'];net.train();scores=np.zeros(9);g=np.zeros((9,len(vector(state)))) if gradient else None
        predictions=[];proxy=[];segment_gradient_norms=[];history_graph=[]
        for number,start in enumerate(plan['base_starts']):
            initial=runtime.context.initial_state.clone() if start==0 else states[start-1].clone()
            context=parity._context_with_initial_state(runtime.context,initial)
            batch=parity.WindowBatch(purpose='training_segment',global_start=start,global_end_exclusive=start+800,context=context,forcing=runtime.forcing[start:start+800],observations=runtime.observations[start:start+800],dates=runtime.dates[start:start+800],initial_state=initial,issue_start_local=695,issue_end_local=797)
            state['trace']=[];state['count']=0;state['record_after']=650
            with torch.set_grad_enabled(gradient):
                filtered=parity.run_knet_filter(net,batch,previous_observation=parity.previous_observation_before_window(runtime,batch))
                assert state['count']==800 and len(state['trace'])==150
                if gradient:assert any(state['boundary'].values()),'Full historical graph was lost'
                history_graph.append(dict(start=start,gradient=gradient,day650=state['boundary']))
                raw=runtime.tukf06_module.multilead_torch(batch.context.plain_model,filtered.posterior_states[:,0,:],batch.forcing)
                pred=torch.stack([raw[k][0][695:797] for k in (1,2,3)],dim=1)
                y=runtime.observations[start+torch.arange(695,797)[:,None]+torch.arange(1,4),0];error=pred-y;losses=[]
                for group,denom in zip(groups(arr(y)),training_counts):
                    selected=error[torch.as_tensor(group)];losses.extend([selected.square().sum()/int(denom),selected.abs().sum()/int(denom)])
                if freeze_masks:masks[start]=state_mask(state['trace'],start+650);state_count+=int(masks[start].sum())
                values=state_values(state['trace'],start+650,state);mask=torch.as_tensor(masks[start],dtype=torch.bool)
                # Initial mask discovery uses a sum; it is divided after the total count is known.
                target=values[mask].square().sum()/(1 if freeze_masks else state_count)
                objectives=losses+[target];scores+=np.array([float(x.detach()) for x in objectives])
                predictions.append(arr(pred));proxy.append(arr(values))
                if gradient:
                    needed=list(range(9)) if state['arm']=='state_constrained' else [0]
                    local=[]
                    for j,index in enumerate(needed):
                        assert counters['autograd_calls']<1250
                        pieces=torch.autograd.grad(objectives[index],state['parameters'],retain_graph=j<len(needed)-1,allow_unused=True)
                        counters['autograd_calls']+=1
                        flat=np.concatenate([np.zeros(p.numel()) if q is None else arr(q).reshape(-1) for p,q in zip(state['parameters'],pieces)])
                        g[index]+=flat;local.append(float(np.linalg.norm(flat)))
                    segment_gradient_norms.append(local)
            state['trace']=None
            counters['completed_segments']+=1;counters['filter_days']+=800
            emit('training_segment_progress',arm=state['arm'],step=state['step'],label=label,segments=number+1,total=25,gradient=gradient,optimizer_calls=state['calls'])
        if freeze_masks:
            assert state_count>0,'No untrained-origin fixed proxy events';scores[8]/=state_count
        if not np.isfinite(scores).all() or gradient and not np.isfinite(g).all():raise FloatingPointError('nonfinite objective or gradient')
        arrays=dict(prediction=np.stack(predictions),state_proxy_values=np.stack(proxy),state_mask=np.stack([masks[x] for x in plan['base_starts']]),scores=scores)
        if segment_gradient_norms:arrays['segment_gradient_norms']=np.array(segment_gradient_norms)
        if gradient and state['step'] in (1,5):put(state['arm']+f'/history_graph_{state["step"]:03d}.json',history_graph)
        counters['completed_training_passes']+=1
        assert torch.equal(rng_before,torch.get_rng_state())
        assert digest(dict(net.named_buffers()))==state['buffer_sha']
        return scores,g,arrays
    def checkpoint(state):
        return dict(basin=basin,arm=state['arm'],epoch=state['step'],optimizer_steps=state['calls'],
            optimizer_calls=state['calls'],effective_nonzero_steps=state['effective'],
            network={k:v.detach().cpu().clone() for k,v in state['net'].state_dict().items()},
            optimizer=state['optimizer'].state_dict(),torch_rng_state=state['rng'].clone(),
            python_rng_state=random.getstate(),numpy_rng_state=plain(np.random.get_state()),
            parameter_sha256=parity.parameter_sha256(state['net']),
            contract_sha256=hashlib.sha256(raw_plan).hexdigest(),
            initial_parameter_sha256=conf['initial_parameter_sha256'])
    def restore(state,values):
        install(state,values)
        np.testing.assert_array_equal(vector(state),values.astype(np.float32).astype(np.float64))
        assert digest(dict(state['net'].named_buffers()))==state['buffer_sha']
    def check_adam(state):
        assert state['optimizer'].state
        assert all(int(item['step'].item())==state['calls'] for item in state['optimizer'].state.values())

    failure=None;active_arm=None;active_step=0
    try:
        initial_arrays=None
        for active_arm,state in arms.items():
            torch.set_rng_state(state['rng']);state['phase']='initialization'
            _,_,data=training(state,freeze_masks=active_arm=='original',label='initialization')
            if active_arm=='original':
                initial_arrays=data
                saved_masks=load_np('fixed_training_masks.npz')
                for start in plan['base_starts']:np.testing.assert_array_equal(masks[start],saved_masks[str(start)])
            else:
                for key in ['prediction','state_proxy_values','state_mask','scores']:
                    np.testing.assert_array_equal(data[key],initial_arrays[key])
            np_save(active_arm+'/training_000.npz',data)
            pt_save(active_arm+'/checkpoint_000.pt',checkpoint(state))
            state['history'].append(dict(step=0,optimizer_calls=0,effective_nonzero_steps=0,training_scores=data['scores'].tolist()))
        np_save('fixed_training_masks.npz',{str(k):v for k,v in masks.items()})
        put('state_mask_origin.json',dict(source='this run original untrained epoch0; exact match to frozen initial mask',
            training_mask_events=state_count,no_candidate_or_epoch_mask_reselection=True))
        emit('initialization_and_reference_complete',training_mask_events=state_count)
        for active_step in range(1,6):
            reference=None
            for active_arm,state in arms.items():
                arm_began=time.monotonic()
                state['step']=active_step;torch.set_rng_state(state['rng'])
                before=vector(state);moment_before=digest(state['optimizer'].state_dict())
                state['phase']='pre_update_nograd'
                pre,_,pre_arrays=training(state,label='pre_update_nograd')
                state['phase']='gradient'
                graph_scores,g,_=training(state,gradient=True,label='gradient')
                opt=state['optimizer'];opt.zero_grad(set_to_none=True);offset=0
                for p in state['parameters']:
                    size=p.numel();p.grad=torch.as_tensor(g[0,offset:offset+size].reshape(tuple(p.shape)),dtype=p.dtype).clone();offset+=size
                norm=float(torch.nn.utils.clip_grad_norm_(state['parameters'],10.,error_if_nonfinite=True))
                assert np.isfinite(norm) and state['calls']<5
                state['phase']='adam_proposal';opt.step();state['calls']+=1;check_adam(state)
                proposed=vector(state);proposal=proposed-before
                if not np.isfinite(proposed).all():raise FloatingPointError('nonfinite proposal')
                moment_after=digest(opt.state_dict())
                put(active_arm+f'/optimizer_call_{active_step:03d}.json',dict(step=active_step,optimizer_calls=state['calls'],
                    moments_before=moment_before,moments_after=moment_after))
                pt_save(active_arm+f'/proposal_checkpoint_{active_step:03d}.pt',checkpoint(state))
                emit('optimizer_call',arm=active_arm,step=active_step,optimizer_calls=state['calls'])
                line=[];projection={};chosen=None
                if active_arm=='original':
                    state['phase']='paired_reference'
                    after,_,after_arrays=training(state,label='paired_reference');reference=after.copy()
                    accepted=True;accepted_label='raw_original_Adam'
                else:
                    assert reference is not None
                    restore(state,before)
                    np_save(active_arm+f'/proposal_{active_step:03d}.npz',dict(before=before,proposal=proposal,
                        gradients=g,reference=reference,pre_scores=pre,gradient_mode_scores=graph_scores))
                    gate_ref=candidate_gate(reference,reference)
                    limits=np.r_[gate_ref['flow_limits'],gate_ref['state_limit']]
                    raw={kind:bounds(limits,pre,kind) for kind in ('F','FS')}
                    radius=2*float(np.linalg.norm(proposal))+float(np.finfo(np.float32).eps)
                    main={};cache={}
                    for kind in ('F','FS'):
                        state['phase']='projection_'+kind
                        assert counters['qp_main']+counters['qp_guard']<50
                        counters['qp_main']+=1
                        d,cert=project_gap(proposal,g,raw[kind])
                        projection[kind]=cert;main[kind]=d
                        if d is not None:np_save(active_arm+f'/{kind}_main_{active_step:03d}.npz',dict(direction=d,raw_bounds=raw[kind]))
                    for alpha in FACTORS:
                        factor=str(alpha).replace('.','p');components={};guards={}
                        for kind in ('F','FS'):
                            if main[kind] is None:
                                guards[kind]=dict(status='MAIN_QP_UNRESOLVED',main_status=projection[kind]['status']);continue
                            state['phase']='guard_'+kind
                            assert counters['qp_main']+counters['qp_guard']<50
                            counters['qp_guard']+=1
                            x,cert=guard_gap(before,alpha*main[kind],g,raw[kind],radius)
                            guards[kind]=cert
                            if x is not None:
                                components[kind]=(before+x).astype(np.float32).astype(np.float64)
                                np_save(active_arm+f'/{kind}_guard_{active_step:03d}_{factor}.npz',dict(guarded=x))
                        put(active_arm+f'/guards_{active_step:03d}_{factor}.json',guards)
                        for kind in ORDER:
                            label=f'{kind}_{active_step:03d}_{factor}'
                            if kind=='MIX':
                                if all(k in components for k in ('F','FS')):
                                    values,cert=mix_installed(components['FS'],components['F'],before,g,raw['FS'],radius)
                                else:values=None;cert=dict(status='COMPONENT_UNAVAILABLE')
                            else:values=components.get(kind);cert=guards[kind]
                            entry=dict(kind=kind,factor=alpha,label=label,certificate=cert)
                            line.append(entry)
                            if values is None:
                                entry['status']='NOT_REPLAYED_UNCERTIFIED';continue
                            param_sha=hashlib.sha256(values.tobytes()).hexdigest()
                            restore(state,values);state['phase']='candidate_'+label
                            if param_sha in cache:
                                score,data,archive=cache[param_sha]
                                entry['reused_replay']=archive['path']
                            else:
                                score,_,data=training(state,label=label)
                                archive=np_save(active_arm+'/'+label+'_training.npz',data)
                                cache[param_sha]=(score,data,archive)
                            gate=candidate_gate(score,reference)
                            entry.update(status='TRUE_GATE_PASS' if gate['accepted'] else 'TRUE_GATE_REJECT',
                                parameter_sha256=param_sha,scores=score.tolist(),gate=gate,archive=archive)
                            if gate['accepted']:
                                chosen=(values,score,data,label);break
                            restore(state,before)
                        if chosen is not None:break
                    if chosen is None:
                        restore(state,before);after=pre.copy();after_arrays=pre_arrays
                        accepted=False;accepted_label=None
                    else:
                        values,after,after_arrays,accepted_label=chosen
                        restore(state,values);accepted=True
                actual=vector(state)-before;changed=bool(np.any(actual));state['effective']+=int(changed)
                assert digest(opt.state_dict())==moment_after
                check_adam(state)
                if active_arm=='original':
                    np_save(active_arm+f'/proposal_{active_step:03d}.npz',dict(before=before,proposal=proposal,
                        gradients=g,reference=reference,pre_scores=pre,gradient_mode_scores=graph_scores))
                np_save(active_arm+f'/update_{active_step:03d}.npz',dict(parameters=vector(state),actual=actual))
                np_save(active_arm+f'/training_{active_step:03d}.npz',after_arrays)
                post_gate=candidate_gate(after,reference)
                state['rng']=torch.get_rng_state().clone()
                pt_save(active_arm+f'/checkpoint_{active_step:03d}.pt',checkpoint(state))
                row=dict(step=active_step,optimizer_calls=state['calls'],effective_nonzero_steps=state['effective'],
                    update_wall_seconds=time.monotonic()-arm_began,
                    parameter_changed=changed,accepted=accepted,accepted_label=accepted_label,
                    training_pre=pre.tolist(),training_pre_graph=graph_scores.tolist(),training_post=after.tolist(),
                    training_paired_reference=reference.tolist(),post_gate=post_gate,candidates=line,projection=projection,
                    optimizer_moments_before_sha256=moment_before,optimizer_moments_after_sha256=moment_after,
                    gradient_norm_before_clip=norm,actual_norm=float(np.linalg.norm(actual)))
                state['history'].append(row);put(active_arm+f'/epoch_{active_step:03d}.json',row)
                emit('epoch_complete',arm=active_arm,step=active_step,optimizer_calls=state['calls'],
                    effective_nonzero_steps=state['effective'],parameter_changed=changed,
                    gate_pass=post_gate['accepted'],accepted_label=accepted_label)
        status='CONTINUOUS_COMPLETE'
    except BaseException as error:
        failure=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc(),
            arm=active_arm,step=active_step,phase=None if active_arm is None else arms[active_arm]['phase'])
        put('failure.json',failure);emit('training_failure',**{k:failure[k] for k in ['type','message','arm','step','phase']})
        for state in arms.values():pt_save(state['arm']+'/failure_checkpoint.pt',checkpoint(state))
        status='CONTINUOUS_FAILED'
    results={}
    for arm,state in arms.items():
        put(arm+'/history.json',state['history'])
        results[arm]=dict(optimizer_calls=state['calls'],effective_nonzero_steps=state['effective'],
            completed_steps=len(state['history'])-1,last=state['history'][-1] if state['history'] else None)
    complete=status=='CONTINUOUS_COMPLETE' and all(state['calls']==5 for state in arms.values())
    put('result.json',dict(status='CONTINUOUS_COMPLETE' if complete else 'CONTINUOUS_FAILED',
        family=contract['family'],basin=basin,job_id=os.environ['SLURM_JOB_ID'],arms=results,counters=counters,
        total_optimizer_calls=sum(x['calls'] for x in arms.values()),
        total_effective_nonzero_steps=sum(x['effective'] for x in arms.values()),failure=failure,
        training_counts=training_counts.tolist(),state_target_count=state_count,thresholds=thresholds.tolist(),
        validation_policy='shared input contains validation dates; no validation replay, metrics or selection'))
    emit('continuous_complete',status=status,counters=counters)
    return 0 if complete else 1

if __name__=='__main__':raise SystemExit(main())
