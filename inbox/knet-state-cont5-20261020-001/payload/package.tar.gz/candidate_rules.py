"""Frozen finite candidate list and installed-parameter mixture certificate."""
import numpy as np

FACTORS=(1.,.5,.25,.125)
ORDER=('FS','MIX','F')

def bounds(limits,pre,variant):
    raw=np.asarray(limits,dtype=np.float64)-np.asarray(pre,dtype=np.float64)
    if variant=='F':raw[8]=0.
    else:assert variant=='FS'
    return raw

def mix_installed(fs,f,before,gradients,raw,radius,tolerance=1e-10):
    theta=(.99*np.asarray(fs)+.01*np.asarray(f)).astype(np.float32).astype(np.float64)
    before=np.asarray(before);g=np.asarray(gradients);raw=np.asarray(raw)
    actual=theta-before;n=np.linalg.norm(g,axis=1);keep=n>0
    violation=max(0.,float(np.max((g[keep]@actual-raw[keep])/n[keep]))) if keep.any() else 0.
    zero_ok=bool(np.all(raw[~keep]>=0))
    inside=bool(np.max(np.abs(actual))<=radius)
    finite=bool(np.isfinite(theta).all() and np.isfinite(actual).all())
    passed=finite and inside and zero_ok and violation<=tolerance
    record=dict(status='CERTIFIED' if passed else 'REJECTED_INSTALLATION',
                maximum_normalized_violation=violation,inside_rounding_box=inside,
                zero_rows_feasible=zero_ok,finite=finite,FS_weight=.99,F_weight=.01,
                raw_target_bounds=raw.tolist(),radius=float(radius))
    return (theta if passed else None),record
