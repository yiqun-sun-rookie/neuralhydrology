"""Report the fixed five-call outcome, including adverse gates and compute cost."""
from pathlib import Path
import json,csv
BASE=Path(__file__).resolve().parent
def obj(p):return json.loads(p.read_bytes())
def write(name,text):
    with (BASE/name).open('x',encoding='utf-8',newline='') as f:f.write(text)
r=obj(BASE/'acceptance.json');run=BASE/'hpc_results/runs/02092500/attempt_001'
complete=r['status']=='ACCEPTED_CONTINUOUS_DIAGNOSTIC';science=r['five_nonzero_gate_passing_steps']
native=r['native_status'];receipt=r['receipt'];steps=r['steps']
rounds=[obj(p) for p in (BASE/'monitoring').glob('round_*_result.json')]
monitor_fail=sum(x.get('status')=='MONITOR_FAILED' for x in rounds)
running=sum(x.get('status')=='VERIFIED_REPLAY_PROGRESS' for x in rounds)
title=('**五步对照完整完成并验收：新规则5/5步均为通过原九门槛的有效非零更新。**' if science else
       '**五步对照完整完成并验收；新规则未达到5/5步有效非零且九门槛全通过，全部不利结果保留。**' if complete else
       '**执行未完整完成；仅报告已完成步骤和原生失败证据。**')
lines=['# 五步连续更新对照结果','',title,'',
    '## 固定范围与审核','',
    '02092500、seed20260922，两臂从完整未训练epoch0 initial.pt开始，空Adam、RNG、网络/buffer与窗口初态一致。',
    '本轮唯一一次[独立审核](independent_review.md)：PASS、0阻断；执行前按审阅文件SHA绑定。',
    '两臂各固定5次Adam调用；新规则在因子1/.5/.25/.125内按FS→MIX99:1→F检验。失败恢复参数、保留推进后的Adam、消耗调用。',
    '九门槛公式与数值容差沿用原值，每步锚定同轮原版；训练mask固定。未做验证回放或验证选择。',
    '该规则来自已有call3诊断，是一个组合算法的短程开发实验；不作为独立泛化或真实储量精度证据。','',
    '## HPC与预算','',
    f'- 作业{r["job_id"]}：{native["State"]} / {native["ExitCode"]}；原生ElapsedRaw={native["ElapsedRaw"]}秒。',
    f'- 同节点控制器墙钟上界={receipt.get("wall_seconds_upper")}秒；Slurm硬限10800秒，控制器10790秒，科学停止线10710秒。',
    f'- 申请1 CPU；原生AllocCPUS={native.get("AllocCPUS")}；实际affinity={receipt.get("affinity")}；数学线程1，无GPU申请。',
    f'- 采样RSS峰值={receipt["combined_rss_peak_bytes"]/1024**2:.2f} MiB。',
    f'- 新远端目录：`{r["remote_root"]}`。',
    '- 本轮只有一次科学提交；旧实验、共享receiver和其他作业未修改。','',
    '## 逐轮结果','',
    '| 实验臂 | 步 | 已接受 | 所选候选 | 实际非零更新 | 累计非零步 | 九门槛通过 | 不利指标 |',
    '|---|---:|:---:|---|:---:|---:|:---:|---|']
for s in steps:
    lines.append(f'| {s["arm"]} | {s["step"]} | {s["accepted"]} | {s["accepted_label"] or "参数回退"} | {s["parameter_changed"]} | {s["effective_nonzero_steps"]} | {s["gate_pass"]} | {", ".join(s["failed_metrics"]) or "无"} |')
if complete:
    for arm in ['original','state_constrained']:
        rows=[obj(run/arm/f'epoch_{i:03d}.json') for i in range(1,6)]
        elapsed=sum(x['update_wall_seconds'] for x in rows)
        unresolved=sum(e['status']=='NOT_REPLAYED_UNCERTIFIED' for x in rows for e in x['candidates'])
        evaluated=sum('scores' in e and 'reused_replay' not in e for x in rows for e in x['candidates'])
        lines+=['',f'{arm}：5次调用；更新阶段耗时合计{elapsed:.3f}秒；完成真实候选回放{evaluated}次；未核证而未回放的候选条目{unresolved}个。']
    original=next(s for s in steps if s['arm']=='original' and s['step']==5)
    new=next(s for s in steps if s['arm']=='state_constrained' and s['step']==5)
    names=['all_mse','all_mae','low_mse','low_mae','middle_mse','middle_mae','high_mse','high_mae','state_proxy']
    lines+=['','## 固定末步5九项对照','',
        '| 指标 | 同轮原版 | 新规则 | 原限制 | 新规则减限制 | 通过 |',
        '|---|---:|---:|---:|---:|:---:|']
    for i,name in enumerate(names):
        a,b,L=original['scores'][i],new['scores'][i],new['limits'][i]
        lines.append(f'| {name} | {a:.14g} | {b:.14g} | {L:.14g} | {b-L:.8g} | {b<=L} |')
    lines+=['','通过原门槛不等于每一项误差都下降：八项流量原工程容许值仍为0.1%加原数值容差；状态比较同轮原版，不要求相对新规则臂自身前一步单调下降。',
        'call4/5是本轮明确要观察的后续步骤，按逐轮表完整报告，不能只选call3。']
    lines+=['','## 实际计数与验收','',
        f'实际计数：`{json.dumps(r["result"]["counters"],ensure_ascii=False)}`。',
        '两臂调用数相同，但新规则有九目标梯度和额外候选成本；本结果不是等算力对比。',
        '验收逐项核对初始网络/空Adam/RNG、固定mask、每轮实际参数和前后检查点、Adam step连续及拒绝后moments保留；从保存轨迹独立float64重算每个真实候选及最终回退的九指标，分类与原记录一致。',
        '已保存QP与float32安装证书通过独立残差核算；验收过程没有调用模型、梯度或QP。']
else:
    lines+=['','实际已知调用数：'+json.dumps(r['known_optimizer_calls'])+'；中断后的未知计数不置零。',
        '失败详情见acceptance.json和完整归档；没有因失败追加科学提交。']
lines+=['',f'完整归档：{r["archive"]["files"]}文件、{r["archive"]["archive_bytes"]}字节；分片/总包/逐文件SHA核验通过。',
    f'归档SHA256：`{r["archive"]["archive_sha256"]}`。',
    f'收到有效运行中快照{running}次，通信/监控异常窗口{monitor_fail}次；原始证据保留。','',
    '## 下一步建议','']
if science:
    advice=['保留本轮规则与5步结果，先设计比本轮更长的固定调用对照，重点确认接受率、非零更新数和各流量组误差是否持续稳定。',
            '下一方案继续固定候选顺序、99:1比例、同轮参考和失败回退；明确额外梯度/候选开销，再独立审核，避免仅按同调用数宣称效率优势。',
            '在连续行为稳定后，才采用事先固定的末轮及验证协议评价；不使用验证结果重选候选比例或最好轮次。']
elif complete:
    bad=[str(s['step']) for s in steps if s['arm']=='state_constrained' and not(s['accepted'] and s['parameter_changed'] and s['gate_pass'])]
    advice=['本轮未达到5步持续有效接受，先聚焦步骤'+','.join(bad)+'，分析已保存的QP状态、真实门槛失败与回退是否导致停滞。',
            '用现有保存数组/轨迹区分数值未决、真实拒绝、零更新和回退后门槛失败；形成一项针对性修订后再冻结方案，不直接扩大到长训练或比例搜索。']
else:
    advice=['先解决已保存的具体执行问题，并以现有调用和耗时为账本制定显式后继方案；完整科学结果尚不可判定。']
lines.extend(f'{i}. {text}' for i,text in enumerate(advice,1))
lines+=['','上述后续实验仅为建议，本轮未提交。','',
    '白话总结：'+('这5步都实际更新了参数，也都守住了九项原门槛。下一步再检查更长训练是否仍稳定。' if science else
    '这次短程对照已完整跑完，但没有达到连续5步有效过关。下一步先看清失败发生在哪一步。' if complete else
    '本轮保留了实际执行和失败证据。下一步先解决明确的执行问题。')]
write('运行报告.md','\n'.join(lines)+'\n')
write('下一步建议.md','# 下一步建议\n\n'+'\n\n'.join(f'{i}. {a}' for i,a in enumerate(advice,1))+'\n\n后续实验未执行。\n')
with (BASE/'step_summary.csv').open('x',encoding='utf-8',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=['arm','step','accepted','accepted_label','parameter_changed','effective_nonzero_steps','gate_pass','failed_metrics','actual_norm'])
    writer.writeheader();writer.writerows({k:s[k] for k in writer.fieldnames} for s in steps)
registry=obj(BASE/'registry_frozen.json');registry.update(status=r['status'],job_id=r['job_id'],
    submission_count=1,five_nonzero_gate_passing_steps=science,report=str(BASE/'运行报告.md'))
write('registry_final.json',json.dumps(registry,ensure_ascii=False,indent=2)+'\n')
(BASE/'active_execution.json').write_text(json.dumps(dict(status='ACCEPTANCE_COMPLETE',job_id=r['job_id'],
    pending_queries=[],five_nonzero_gate_passing_steps=science,report=str(BASE/'运行报告.md')),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
write('START_HERE.md',f'# 本轮已收档\n\n先读运行报告.md和acceptance.json。\n\n作业{r["job_id"]}，原生{native["State"]}/{native["ExitCode"]}。完整结果验收状态{r["status"]}；5步持续有效过关={science}。\n\n本轮仅一次独立审核、一次科学提交；全部回执已收齐，无待执行后续实验。旧实验与不利结果全部保留。\n\n白话总结：本轮已收档。下一步建议尚未运行。\n')
print(json.dumps(dict(status='REPORT_WRITTEN',report=str(BASE/'运行报告.md'),five_nonzero_gate_passing_steps=science)))
