"""Accept saved arrays/checkpoints and numerical proofs; no model or QP calls."""
from pathlib import Path
import hashlib,json
import numpy as np
import torch

BASE=Path(__file__).resolve().parent
HPC=BASE/'hpc_results';RUN=HPC/'runs/02092500/attempt_001'
NAMES=['all_mse','all_mae','low_mse','low_mae','middle_mse','middle_mae','high_mse','high_mae','state_proxy']
def obj(p):return json.loads(p.read_bytes())
def arr(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
def cp(p):return torch.load(p,weights_only=True,map_location='cpu')
def equal(a,b):
    if isinstance(a,torch.Tensor):return isinstance(b,torch.Tensor) and torch.equal(a,b)
    if isinstance(a,dict):return a.keys()==b.keys() and all(equal(a[k],b[k]) for k in a)
    if isinstance(a,(list,tuple)):return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
    return a==b
def limits(reference):
    reference=np.asarray(reference)
    return np.r_[reference[:8]*1.001+np.maximum(1e-10,1e-7*np.abs(reference[:8])),
                 reference[8]+max(1e-10,1e-7*abs(reference[8]))]
def certify(nominal,direction,g,rhs,record):
    n=np.linalg.norm(g,axis=1);keep=n>0;A=np.zeros_like(g);A[keep]=g[keep]/n[keep,None]
    ix=record['active'];lam=np.asarray(record['multipliers'])
    stationarity=float(np.linalg.norm(direction-nominal+(A[ix].T@lam if ix else 0)))
    primal=max(0.,float(np.max(A[keep]@direction-rhs[keep]))) if keep.any() else 0.
    equality=float(np.max(np.abs(A[ix]@direction-rhs[ix]))) if ix else 0.
    dual=max(0.,float(-lam.min())) if ix else 0.
    comp=float(np.max(np.abs(lam*(A[ix]@direction-rhs[ix])))) if ix else 0.
    assert max(stationarity,primal,equality,dual,comp)<=1e-10
    return dict(stationarity=stationarity,primal=primal,equality=equality,dual=dual,complementarity=comp)

identity=obj(BASE/'execution_identity.json');archive=obj(BASE/'collection/verified.json')
manifest=obj(HPC/'collection_manifest.json');contract=obj(HPC/'replay_contract.json')
assert identity==manifest['identity'] and archive['job_id']==identity['job_id']
for row in obj(HPC/'deployment_manifest.json')['files']:
    raw=(HPC/row['path']).read_bytes()
    assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
native=manifest['native_status']['native_job_row']
assert len(native)==1 and native[0]['JobID']==identity['job_id'];native=native[0]
receipt=obj(RUN/'receipt.json')
result=obj(RUN/'result.json') if (RUN/'result.json').exists() else None
technical=bool(result and result['status']=='CONTINUOUS_COMPLETE')
steps=[];proof_checks=[];science=None;known_calls={}
if technical:
    assert native['State']=='COMPLETED' and native['ExitCode']=='0:0'
    assert receipt['status']=='COMPLETED' and receipt['exit_code']==0
    assert int(native['ElapsedRaw'])<=10800 and receipt['wall_seconds_upper']<=10790
    assert receipt['startup_admission_verified'] and len(receipt['affinity'])==1
    assert receipt['combined_rss_peak_bytes']<=6*1024**3 and receipt['system_free_min_bytes']>=2*1024**3
    counters=result['counters']
    assert result['total_optimizer_calls']==receipt['total_optimizer_calls']==10
    assert counters['autograd_calls']==1250 and counters['validation_replays']==0
    assert counters['qp_main']==10 and counters['qp_main']+counters['qp_guard']<=50
    assert counters['completed_training_passes']<=87
    assert counters['completed_segments']==25*counters['completed_training_passes']
    assert counters['filter_days']==800*counters['completed_segments']
    initial=cp(HPC/'inputs/initial.pt')
    assert initial['epoch']==initial['optimizer_steps']==0 and not initial['optimizer']['state']
    initial_gate=obj(RUN/'initialization_gate.json');names=initial_gate['trainable_names']
    assert initial_gate['trainable_parameter_count']==63217
    def vector(checkpoint):return np.concatenate([checkpoint['network'][n].numpy().reshape(-1) for n in names]).astype(np.float64)
    starts=contract['original_contract']['base_starts']
    mask_file=arr(RUN/'fixed_training_masks.npz');frozen=arr(HPC/'inputs/fixed_training_masks.npz')
    for key in mask_file:np.testing.assert_array_equal(mask_file[key],frozen[key])
    masks=np.stack([mask_file[str(s)] for s in starts]);assert int(masks.sum())==3641
    snapshot=arr(RUN/'input_snapshot.npz');obs=snapshot['observations'].reshape(-1)[:2557]
    truth=np.stack([obs[s+np.arange(695,797)[:,None]+np.arange(1,4)] for s in starts])
    q50,q90=np.quantile(obs,[.5,.9],method='linear')
    groups=[np.ones(truth.shape,dtype=bool),truth<=q50,(truth>q50)&(truth<=q90),truth>q90]
    checked_arrays={}
    def training_arrays(path):
        if path in checked_arrays:return checked_arrays[path]
        data=arr(path);np.testing.assert_array_equal(data['state_mask'],masks)
        assert data['prediction'].shape==(25,102,3)
        e=data['prediction'].astype(np.float64)-truth.astype(np.float64);score=[]
        for group in groups:
            x=e[group];score.extend([float(np.mean(x*x)),float(np.mean(np.abs(x)))])
        proxy=data['state_proxy_values'].astype(np.float64)[masks]
        score.append(float(np.mean(proxy*proxy)));score=np.asarray(score)
        assert np.isfinite(score).all() and np.isfinite(data['scores']).all()
        assert np.all(np.abs(score-data['scores'])<=np.maximum(1e-12,2e-6*np.abs(data['scores'])))
        checked_arrays[path]=(data,score);return data,score
    previous={};effective={arm:0 for arm in ['original','state_constrained']}
    for arm in effective:
        zero=cp(RUN/arm/'checkpoint_000.pt')
        assert zero['optimizer_calls']==0 and not zero['optimizer']['state']
        assert equal(zero['network'],initial['network']) and equal(zero['optimizer'],initial['optimizer'])
        assert torch.equal(zero['torch_rng_state'],initial['torch_rng_state'])
        previous[arm]=zero
        training_arrays(RUN/arm/'training_000.npz')
    zero0,_=training_arrays(RUN/'original/training_000.npz')
    zero1,_=training_arrays(RUN/'state_constrained/training_000.npz')
    for key in ['prediction','state_proxy_values','state_mask','scores']:np.testing.assert_array_equal(zero0[key],zero1[key])
    replay_count=0;guard_count=0
    for step in range(1,6):
        original_data,_=training_arrays(RUN/'original'/f'training_{step:03d}.npz')
        reference=original_data['scores'];L=limits(reference)
        for arm in ['original','state_constrained']:
            folder=RUN/arm;row=obj(folder/f'epoch_{step:03d}.json')
            proof=arr(folder/f'proposal_{step:03d}.npz');update=arr(folder/f'update_{step:03d}.npz')
            final=cp(folder/f'checkpoint_{step:03d}.pt');proposed_cp=cp(folder/f'proposal_checkpoint_{step:03d}.pt')
            np.testing.assert_array_equal(proof['before'],vector(previous[arm]))
            np.testing.assert_array_equal(update['parameters'],vector(final))
            np.testing.assert_array_equal(update['actual'],update['parameters']-proof['before'])
            np.testing.assert_array_equal(vector(proposed_cp)-proof['before'],proof['proposal'])
            assert equal(proposed_cp['optimizer'],final['optimizer'])
            assert all(int(v['step'].item())==step for v in final['optimizer']['state'].values())
            assert final['optimizer_calls']==row['optimizer_calls']==step
            for name,tensor in initial['network'].items():
                if name not in names:assert torch.equal(final['network'][name],tensor)
            changed=bool(np.any(update['actual']));effective[arm]+=int(changed)
            assert changed==row['parameter_changed'] and final['effective_nonzero_steps']==effective[arm]
            if step>1:
                prior_row=obj(folder/f'epoch_{step-1:03d}.json')
                assert row['optimizer_moments_before_sha256']==prior_row['optimizer_moments_after_sha256']
            data,recomputed=training_arrays(folder/f'training_{step:03d}.npz');scores=data['scores']
            np.testing.assert_array_equal(scores,row['training_post'])
            np.testing.assert_array_equal(reference,row['training_paired_reference'])
            np.testing.assert_array_equal(reference,proof['reference'])
            passed=scores<=L
            np.testing.assert_array_equal(recomputed<=L,passed)
            assert row['post_gate']['accepted']==bool(passed.all())
            if arm=='original':np.testing.assert_array_equal(update['actual'],proof['proposal'])
            else:
                before=proof['before'];g=proof['gradients'];n=np.linalg.norm(g,axis=1);keep=n>0
                rawFS=L-proof['pre_scores'];rawF=rawFS.copy();rawF[8]=0
                raw={'F':rawF,'FS':rawFS};radius=2*float(np.linalg.norm(proof['proposal']))+float(np.finfo(np.float32).eps)
                main={}
                for kind in ['F','FS']:
                    path=folder/f'{kind}_main_{step:03d}.npz'
                    if path.exists():
                        main[kind]=arr(path)['direction']
                        rhs=np.zeros(9);rhs[keep]=raw[kind][keep]/n[keep]
                        certify(proof['proposal'],main[kind],g,rhs,row['projection'][kind])
                component_by_factor={}
                for guard_path in sorted(folder.glob(f'guards_{step:03d}_*.json')):
                    factor=guard_path.stem.split('_')[-1];alpha=float(factor.replace('p','.'))
                    guards=obj(guard_path);components={}
                    for kind,cert in guards.items():
                        if cert['status']!='MAIN_QP_UNRESOLVED':guard_count+=1
                        path=folder/f'{kind}_guard_{step:03d}_{factor}.npz'
                        if path.exists():
                            x=arr(path)['guarded'];values=(before+x).astype(np.float32).astype(np.float64)
                            assert cert['status']=='CERTIFIED'
                            certify(alpha*main[kind],x,g,np.asarray(cert['normalized_bounds']),cert['certificate'])
                            violation=max(0.,float(np.max((g[keep]@(values-before)-raw[kind][keep])/n[keep]))) if keep.any() else 0.
                            assert violation<=1e-10 and np.max(np.abs(x))<=radius
                            components[kind]=values
                    component_by_factor[alpha]=components
                order=[(alpha,kind) for alpha in [1.,.5,.25,.125] for kind in ['FS','MIX','F']]
                assert [(x['factor'],x['kind']) for x in row['candidates']]==order[:len(row['candidates'])]
                accepted_entry=None
                for entry in row['candidates']:
                    if 'scores' not in entry:
                        assert entry['status']=='NOT_REPLAYED_UNCERTIFIED';continue
                    parts=component_by_factor[entry['factor']]
                    if entry['kind']=='MIX':
                        values=(.99*parts['FS']+.01*parts['F']).astype(np.float32).astype(np.float64)
                        violation=max(0.,float(np.max((g[keep]@(values-before)-rawFS[keep])/n[keep]))) if keep.any() else 0.
                        assert violation<=1e-10 and np.all(rawFS[~keep]>=0) and np.max(np.abs(values-before))<=radius
                    else:values=parts[entry['kind']]
                    assert hashlib.sha256(values.tobytes()).hexdigest()==entry['parameter_sha256']
                    path=HPC/entry['archive']['path']
                    candidate,recomputed_candidate=training_arrays(path)
                    np.testing.assert_array_equal(candidate['scores'],entry['scores'])
                    cp_pass=candidate['scores']<=L
                    np.testing.assert_array_equal(recomputed_candidate<=L,cp_pass)
                    assert entry['gate']['accepted']==bool(cp_pass.all())
                    if 'reused_replay' not in entry:replay_count+=1
                    if entry['gate']['accepted']:
                        assert accepted_entry is None;accepted_entry=entry
                        assert entry is row['candidates'][-1]
                        np.testing.assert_array_equal(values,update['parameters'])
                if row['accepted']:
                    assert accepted_entry and row['accepted_label']==accepted_entry['label']
                    assert bool(passed.all())
                else:
                    assert accepted_entry is None
                    np.testing.assert_array_equal(update['parameters'],before)
                    np.testing.assert_array_equal(scores,proof['pre_scores'])
            previous[arm]=final
            steps.append(dict(arm=arm,step=step,accepted=row['accepted'],accepted_label=row['accepted_label'],
                parameter_changed=changed,effective_nonzero_steps=effective[arm],gate_pass=bool(passed.all()),
                failed_metrics=[NAMES[i] for i in np.flatnonzero(~passed)],scores=scores.tolist(),limits=L.tolist(),
                actual_norm=float(np.linalg.norm(update['actual']))))
    assert counters['qp_guard']==guard_count
    assert counters['completed_training_passes']==27+replay_count
    for arm in effective:
        assert result['arms'][arm]['optimizer_calls']==5
        assert result['arms'][arm]['effective_nonzero_steps']==effective[arm]
        known_calls[arm]=5
    assert result['total_effective_nonzero_steps']==sum(effective.values())==receipt['total_effective_nonzero_steps']
    constrained=[x for x in steps if x['arm']=='state_constrained']
    science=all(x['gate_pass'] and x['parameter_changed'] and x['accepted'] for x in constrained)
else:
    for arm in ['original','state_constrained']:
        paths=sorted((RUN/arm).glob('optimizer_call_*.json'))
        known_calls[arm]=max([obj(p)['optimizer_calls'] for p in paths],default=0) if paths or receipt['worker_started'] is False else None
report=dict(status='ACCEPTED_CONTINUOUS_DIAGNOSTIC' if technical else 'FAILED_OR_INCOMPLETE_EVIDENCE_PRESERVED',
    family=contract['family'],job_id=identity['job_id'],remote_root=identity['remote_root'],
    five_nonzero_gate_passing_steps= science,steps=steps,known_optimizer_calls=known_calls,
    result=result,receipt=receipt,native_status=native,archive=archive,independent_review_rounds=1,
    acceptance_scientific_model_calls=0,acceptance_qp_calls=0,
    scope='One basin/seed, five training calls; no validation or physical storage truth')
with (BASE/'acceptance.json').open('x',encoding='utf-8') as f:json.dump(report,f,ensure_ascii=False,indent=2)
print(json.dumps({k:report[k] for k in ['status','job_id','five_nonzero_gate_passing_steps','known_optimizer_calls']}))
