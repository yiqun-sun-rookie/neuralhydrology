"""Daily-input adapter around the extracted GRAiCE author model_config function.

No recurrent cell or alternative LSTM is defined here. The trainable model
is the author's function plus the recorded compatibility/input-only patch.
"""
from types import SimpleNamespace

import numpy as np

from id25.graice_lstmnosif import (digest, inverse_y, save_npz, transform_y,
                                  centered_validation, write_json)

FEATURES = ["P_mm_day", "Tmean_C", "downward_shortwave_W_m2", "vp_Pa"]


def build_model(config):
    from id25.graice_author_model_config_b04 import model_config
    if config["model_type"] != "LSTM" or config["feature_count"] != 11:
        raise ValueError("Frozen author model contract changed")
    hp = SimpleNamespace(units_in=config["lstm_units"], units_lay1=config["dense_units"],
                         units_lay2=0, window=None, l_rate=config["learning_rate"])
    return model_config(hp, list(range(11)), pidx=0, model_type="LSTM",
                        padding_value=config["padding_value"])


def dynamic_inputs(forcing):
    values = np.asarray(forcing, dtype=np.float32)
    return np.stack([values[..., 0], .5 * (values[..., 3] + values[..., 4]),
                     values[..., 1], values[..., 5]], axis=-1)


def prefix_lengths(weights):
    weights = np.asarray(weights)
    if weights.ndim != 2 or not np.isfinite(weights).all() or np.any(weights < 0):
        raise ValueError("Invalid existing observation weights")
    ends = []
    for row in weights:
        used = np.flatnonzero(row > 0)
        if not len(used) or not np.isclose(row.sum(), 1., atol=1e-6):
            raise ValueError("Observation support is empty or not normalized")
        ends.append(int(used[-1]) + 1)
    if len(set(ends)) != len(ends):
        raise ValueError("Different supports with the same end cannot use this scalar interface")
    return np.array(ends, dtype=np.int64)


def load_history(root, config):
    with np.load(root / "inputs/inputs.npz", allow_pickle=False) as z:
        data = {k: z[k].copy() for k in ("dates", "support_ids", "static_features",
                                        "targets_cm", "fit_mask", "solution_ids")}
        data["dynamic"] = dynamic_inputs(z["forcing"])
        data["lengths"] = prefix_lengths(z["sampling_weights"])
    dates = np.asarray(data["dates"]).astype("datetime64[D]")
    data["dates"] = dates
    if str(dates[0]) != config["history_start"] or str(dates[-1]) != "2008-12-31":
        raise ValueError("Historical dates changed")
    if not np.all(np.diff(dates).astype(int) == 1):
        raise ValueError("Daily history is discontinuous")
    if data["dynamic"].shape != (3806, 119, 4) or data["static_features"].shape != (119, 7):
        raise ValueError("Fixed regional feature shape changed")
    if not np.isfinite(data["dynamic"]).all() or not np.isfinite(data["static_features"]).all():
        raise ValueError("Nonfinite allowed input")
    if len(set(data["support_ids"].astype(str))) != 119 or len(data["lengths"]) != 78:
        raise ValueError("Region/window identity changed")
    if data["targets_cm"].shape != (78, 119) or int(data["fit_mask"].sum()) != 66:
        raise ValueError("Target/split shape changed")
    ends = dates[data["lengths"] - 1]
    fit = data["fit_mask"].astype(bool)
    if not np.all((ends[fit] >= np.datetime64("2002-01-01")) & (ends[fit] < np.datetime64("2008-01-01"))):
        raise ValueError("Fit window outside frozen years")
    if not np.all((ends[~fit] >= np.datetime64("2008-01-01")) & (ends[~fit] < np.datetime64("2009-01-01"))):
        raise ValueError("Selection window outside 2008")
    data["scale_day_mask"] = (dates >= np.datetime64("2002-01-01")) & (dates < np.datetime64("2008-01-01"))
    return data


def fit_scalers(data, column, fit):
    from sklearn.preprocessing import RobustScaler
    unique_days = data["dynamic"][data["scale_day_mask"], column]
    sx = RobustScaler().fit(unique_days)
    target = data["targets_cm"][fit, column].astype(np.float64)
    y_ref = float(target.mean())
    sy = RobustScaler().fit((target - y_ref)[:, None])
    return {"x_center": sx.center_.tolist(), "x_scale": sx.scale_.tolist(),
            "y_center": float(sy.center_[0]), "y_scale": float(sy.scale_[0]),
            "observation_reference_cm": y_ref, "fit_sample_count": int(fit.sum()),
            "x_fit_unique_days": len(unique_days), "static_scaling": "RDS01_values_unchanged"}


def regional_features(dynamic, static, scaler, padding_value):
    normalized = (np.asarray(dynamic) - np.array(scaler["x_center"])) / np.array(scaler["x_scale"])
    x = np.concatenate([normalized, np.broadcast_to(static, (len(dynamic), 7))], axis=1).astype(np.float32)
    if not np.isfinite(x).all() or np.any(np.all(x == np.float32(padding_value), axis=1)):
        raise ValueError("Invalid effective daily row or padding sentinel collision")
    return x


def batch_prefixes(features, lengths, padding_value):
    lengths = np.asarray(lengths, dtype=int)
    if not len(lengths) or lengths.min() <= 0 or lengths.max() > len(features):
        raise ValueError("Prefix length outside supplied history")
    x = np.full((len(lengths), int(lengths.max()), 11), np.float32(padding_value), dtype=np.float32)
    for row, end in enumerate(lengths):
        x[row, :end] = features[:end]
    return x


def load_application(root, history):
    with np.load(root / "application_inputs.npz", allow_pickle=False) as z:
        app = {k: z[k].copy() for k in z.files}
    if not np.array_equal(app["region_ids"].astype(str), history["support_ids"].astype(str)):
        raise ValueError("Application region order mismatch")
    dates = app["dates"].astype("datetime64[D]")
    if str(dates[0]) != "2009-01-01" or str(dates[-1]) != "2010-12-31" or not np.all(np.diff(dates).astype(int) == 1):
        raise ValueError("Application dates changed")
    if app["dynamic"].shape != (730, 119, 4) or not np.isfinite(app["dynamic"]).all():
        raise ValueError("Application input shape/finiteness mismatch")
    return {"dynamic": np.concatenate([history["dynamic"], app["dynamic"]], axis=0),
            "lengths": len(history["dates"]) + prefix_lengths(app["sampling_weights"]),
            "solution_ids": app["solution_ids"]}
