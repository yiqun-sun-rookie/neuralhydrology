"""Compare frozen B04 predictions to the existing, centered RDS01 artifacts."""
import csv
import json
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from id25.graice_lstmnosif import write_json


def number(value):
    return float(value) if np.isfinite(value) else None


def correlation(p, y):
    valid = np.isfinite(p) & np.isfinite(y)
    if valid.sum() < 2 or np.std(p[valid]) < 1e-8 or np.std(y[valid]) < 1e-8:
        return None
    return float(np.corrcoef(p[valid], y[valid])[0, 1])


def summary_metrics(prediction, observation, common):
    residual = np.where(common, prediction - observation, np.nan)
    rmse = np.sqrt(np.nanmean(residual ** 2, axis=0))
    return {"pooled_rmse_cm": number(np.sqrt(np.nanmean(residual ** 2))),
            "regional_median_rmse_cm": number(np.nanmedian(rmse)),
            "residual_count": int(common.sum()), "valid_regions": int(np.isfinite(rmse).sum())}


def anomaly_series(values, fit, months):
    result = values.copy().astype(float)
    month_numbers = np.array([int(str(m)[5:7]) for m in months])
    for month in range(1, 13):
        used = fit & (month_numbers == month)
        mean = np.nanmean(values[used], axis=0) if used.any() else np.full(values.shape[1], np.nan)
        result[month_numbers == month] -= mean
    return result


def compare(root, data):
    root = Path(root)
    if json.loads((root / "selection.json").read_text())["state"] != "FROZEN":
        raise ValueError("Comparison requires frozen regional selections")
    with np.load(root / "predictions.npz", allow_pickle=False) as z:
        candidate_history = z["history_anomaly_cm"]
        candidate = z["application_anomaly_cm"]
        ids = z["support_ids"].astype(str)
        solutions = z["solution_ids"].astype(str)
    # This is the first access to 2009-2010 targets in the training entry point.
    with np.load(root / "comparison_reference/reference.npz", allow_pickle=False) as z:
        if not np.array_equal(z["support_ids"].astype(str), ids) or not np.array_equal(z["solution_ids"].astype(str), solutions):
            raise ValueError("Frozen comparator identity does not match")
        baseline_history = z["rds_history_anomaly_cm"]
        baseline = z["rds_application_anomaly_cm"]
        observation_history = z["observed_history_anomaly_cm"]
        observation = z["observed_application_anomaly_cm"]
    common = np.isfinite(candidate) & np.isfinite(baseline) & np.isfinite(observation)
    if common.sum() == 0:
        raise ValueError("No common application residuals")
    months = np.array([s.rsplit("_", 1)[-1] for s in solutions])
    fit = np.concatenate([data["fit_mask"].astype(bool), np.zeros(len(candidate), dtype=bool)])
    observations_all = np.concatenate([observation_history, observation])
    baseline_all = np.concatenate([baseline_history, baseline])
    candidate_all = np.concatenate([candidate_history, candidate])
    observation_anomaly = anomaly_series(observations_all, fit, months)[-len(candidate):]
    baseline_anomaly = anomaly_series(baseline_all, fit, months)[-len(candidate):]
    candidate_anomaly = anomaly_series(candidate_all, fit, months)[-len(candidate):]
    app_months = months[-len(candidate):]
    rows = []
    for col, region_id in enumerate(ids):
        mask = common[:, col]
        base_rmse = np.sqrt(np.mean((baseline[mask, col] - observation[mask, col]) ** 2)) if mask.any() else np.nan
        cand_rmse = np.sqrt(np.mean((candidate[mask, col] - observation[mask, col]) ** 2)) if mask.any() else np.nan
        row = {"region_id": region_id, "common_windows": int(mask.sum()),
               "rds01_rmse_cm": number(base_rmse), "lstmnosif_rmse_cm": number(cand_rmse),
               "lstm_minus_rds_rmse_cm": number(cand_rmse - base_rmse),
               "rds01_anomaly_correlation": correlation(baseline_anomaly[:, col], observation_anomaly[:, col]),
               "lstmnosif_anomaly_correlation": correlation(candidate_anomaly[:, col], observation_anomaly[:, col])}
        for year in ("2009", "2010"):
            year_mask = mask & np.array([m.startswith(year) for m in app_months])
            y = observation[year_mask, col]
            for name, values in (("rds01", baseline), ("lstmnosif", candidate)):
                p = values[year_mask, col]
                ratio = np.std(p) / np.std(y) if len(y) >= 2 and np.std(y) > 1e-8 else np.nan
                row[f"{year}_{name}_sd_ratio"] = number(ratio)
                row[f"{year}_{name}_abs_log_sd_ratio"] = number(abs(np.log(ratio))) if ratio > 0 else None
                row[f"{year}_{name}_bias_cm"] = number(np.mean(p - y)) if len(y) else None
        rows.append(row)
    destination = root / "comparison"
    destination.mkdir(exist_ok=True)
    with (destination / "regional_comparison.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    base_summary = summary_metrics(baseline, observation, common)
    cand_summary = summary_metrics(candidate, observation, common)
    rds_wins = sum(r["rds01_rmse_cm"] is not None and r["rds01_rmse_cm"] < r["lstmnosif_rmse_cm"] for r in rows)
    candidate_wins = sum(r["rds01_rmse_cm"] is not None and r["lstmnosif_rmse_cm"] < r["rds01_rmse_cm"] for r in rows)
    cold_ids = ["lat+040_lon-108", "lat+038_lon-108"]
    summary = {"period": "2009-2010", "fixed_comparator": "RDS01_best_epoch078", "rds01": base_summary,
               "graice_lstmnosif": cand_summary, "rds01_lower_rmse_regions": rds_wins,
               "lstmnosif_lower_rmse_regions": candidate_wins,
               "tie_or_unavailable_regions": len(ids) - rds_wins - candidate_wins,
               "cold_regions": [r for r in rows if r["region_id"] in cold_ids],
               "interpretation": "Developmental whole-model storage comparison; same raw daily inputs and history; author per-region sequence-to-one adaptation"}
    for name in ("rds01", "lstmnosif"):
        values = [r[name + "_anomaly_correlation"] for r in rows if r[name + "_anomaly_correlation"] is not None]
        summary[name + "_anomaly_correlation"] = {"median": number(np.median(values)) if values else None, "valid_regions": len(values)}
    write_json(destination / "summary.json", summary)
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(5.4, 4.6), constrained_layout=True)
    xx = [r["rds01_rmse_cm"] for r in rows]
    yy = [r["lstmnosif_rmse_cm"] for r in rows]
    ax.scatter(xx, yy, s=18, color="#2563eb", alpha=.75)
    limit = max(v for v in xx + yy if v is not None) * 1.05
    ax.plot([0, limit], [0, limit], color="#64748b", ls="--", lw=1)
    ax.set(xlabel="Fixed RDS01 window RMSE (cm)", ylabel="Author-derived LSTMnoSIF window RMSE (cm)",
           xlim=(0, limit), ylim=(0, limit), title="119 regions: 2009-2010")
    ax.grid(alpha=.2)
    fig.savefig(destination / "regional_rmse.png", dpi=160)
    plt.close(fig)
    dates = np.asarray(app_months, dtype="datetime64[M]")
    fig, axes = plt.subplots(2, 1, figsize=(10, 5.5), sharex=True, constrained_layout=True)
    for ax, region_id in zip(axes, cold_ids):
        col = ids.tolist().index(region_id)
        ax.plot(dates, observation[:, col], color="#111827", marker="o", ms=3, label="Existing GRACE-window proxy")
        ax.plot(dates, baseline[:, col], color="#d97706", label="Fixed RDS01")
        ax.plot(dates, candidate[:, col], color="#2563eb", label="GRAiCE author matched-input B04")
        ax.set(title=region_id, ylabel="TWS anomaly (cm)")
        ax.grid(alpha=.2)
    axes[0].legend(frameon=False, fontsize=8, ncol=3)
    fig.savefig(destination / "cold_regions.png", dpi=160)
    plt.close(fig)
    lines = ["# GRAiCE作者LSTMnoSIF与固定RDS01的储水比较", "",
             "119区各一次拟合，2002—2007训练、2008选轮，固定后比较2009—2010。", "",
             "| 指标 | 固定RDS01 | 作者LSTMnoSIF适配版 |", "|---|---:|---:|",
             f"| 区域RMSE中位数 cm | {base_summary['regional_median_rmse_cm']:.4f} | {cand_summary['regional_median_rmse_cm']:.4f} |",
             f"| 合并RMSE cm | {base_summary['pooled_rmse_cm']:.4f} | {cand_summary['pooled_rmse_cm']:.4f} |",
             f"| RMSE较低的区域数/119 | {rds_wins} | {candidate_wins} |", "",
             f"共同有效残差数：{int(common.sum())}。两个冷区、逐年幅度/偏差及去季节异常相关见regional_comparison.csv。", "",
             "模型使用作者函数派生的逐区LSTM结构；输入为同一4日气象、7静态和完整历史，无外部SWE。", 
             "该时段此前已查看，因此是开发性储水比较；整体差值不能单独归因于结构，也不验证日库存分量。", "",
             "![区域RMSE](regional_rmse.png)", "", "![两个冷区](cold_regions.png)", ""]
    (destination / "RESULTS.md").write_text("\n".join(lines), encoding="utf-8")
    return summary
