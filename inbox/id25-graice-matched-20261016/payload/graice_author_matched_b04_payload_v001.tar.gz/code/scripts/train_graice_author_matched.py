"""Run the reviewed B04 author-code adapter on a Slurm GPU node.

Per-region fitting/checkpoints derive from the completed B02 runner. Application
inputs and labels are opened only after all regional selections are frozen.
"""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import time

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from id25.graice_author_matched import (batch_prefixes, build_model, centered_validation, digest,
                                        fit_scalers, inverse_y, load_application, load_history,
                                        regional_features, save_npz, transform_y, write_json)
from train_graice_lstmnosif import restore_last, save_last


def now():
    return datetime.now(timezone.utc).isoformat()


def predict_windows(network, features, lengths, config):
    output = []
    for start in range(0, len(lengths), config["batch_size"]):
        batch = batch_prefixes(features, lengths[start:start + config["batch_size"]], config["padding_value"])
        output.append(network(batch, training=False).numpy())
    return np.concatenate(output).reshape(-1)


def interface_check(tf, data, config, root, fingerprint):
    path = root / "interface_check.json"
    if path.exists():
        receipt = json.loads(path.read_text())
        if receipt["state"] != "PASS" or receipt["fingerprint"] != fingerprint:
            raise ValueError("Interface receipt identity mismatch")
        return
    tf.keras.backend.clear_session()
    tf.keras.utils.set_random_seed(config["seed"])
    network = build_model(config)
    mask = data["fit_mask"].astype(bool) & np.isfinite(data["targets_cm"][:, 0])
    scaler = fit_scalers(data, 0, mask)
    features = regional_features(data["dynamic"][:, 0], data["static_features"][0], scaler, config["padding_value"])
    lengths = data["lengths"][:2]
    batch = batch_prefixes(features, lengths, config["padding_value"])
    actual = network.get_layer("input_padding").compute_mask(tf.convert_to_tensor(batch)).numpy()
    expected = np.arange(batch.shape[1])[None, :] < lengths[:, None]
    np.testing.assert_array_equal(actual, expected)
    predictions = network(batch, training=False).numpy()
    single = network(features[None, :lengths[0]], training=False).numpy()
    np.testing.assert_allclose(single, predictions[:1], atol=1e-5, rtol=1e-5)
    layer = network.get_layer("author_lstm")
    if type(layer).__name__ != "LSTM" or layer.go_backwards or layer.return_sequences or predictions.shape != (2, 1):
        raise AssertionError("Author sequence-to-one model changed")
    if network.count_params() != 6177 or not np.isfinite(predictions).all():
        raise AssertionError("Unexpected author parameter count or nonfinite output")
    saved = root / "interface_roundtrip.keras"
    network.save(saved)
    restored = tf.keras.models.load_model(saved, compile=False)
    np.testing.assert_allclose(restored(batch, training=False).numpy(), predictions, atol=1e-7, rtol=1e-6)
    target = data["targets_cm"][mask, 0]
    np.testing.assert_allclose(inverse_y(transform_y(target, scaler), scaler),
                               target - scaler["observation_reference_cm"], atol=1e-5)
    receipt = dict(state="PASS", fingerprint=fingerprint, training_started=False, optimizer_steps=0,
                   regions=119, dynamic_shape=list(data["dynamic"].shape), static_shape=[119, 7],
                   author_model="unidirectional_LSTM32_Dense16_Dense1_sequence_to_one", parameters=6177,
                   checks=["allowed_4_daily_plus_7_static", "window_cutoffs_and_split", "actual_mask_equals_length_mask",
                           "padding_prediction_invariance", "author_layer_structure", "save_load", "cm_scaler_roundtrip"],
                   tensorflow_version=tf.__version__, job_id=os.environ["SLURM_JOB_ID"], finished_at=now())
    write_json(path, receipt)
    print(json.dumps(dict(event="INTERFACE_CHECK_PASSED", **receipt)), flush=True)
    del restored, network
    tf.keras.backend.clear_session()


def fit_region(tf, config, data, column, root, fingerprint):
    region_id = str(data["support_ids"][column])
    run = root / "runs" / region_id
    run.mkdir(parents=True, exist_ok=True)
    report_path = run / "report.json"
    if report_path.exists():
        previous = json.loads(report_path.read_text())
        if previous["state"] in ("SELECTED", "COMPLETED") and previous["fingerprint"] == fingerprint:
            if not (run / "best.keras").exists() or not (run / "history_predictions.npz").exists():
                raise ValueError("Selected region lost artifacts")
            return previous
    targets = data["targets_cm"][:, column]
    fit = data["fit_mask"].astype(bool) & np.isfinite(targets)
    val = (~data["fit_mask"].astype(bool)) & np.isfinite(targets)
    if fit.sum() < 2 or val.sum() < 2:
        raise ValueError("Insufficient fixed regional labels")
    scaler = fit_scalers(data, column, fit)
    scaler_path = run / "scalers.json"
    if scaler_path.exists() and json.loads(scaler_path.read_text()) != scaler:
        raise ValueError("Regional scaler changed on resume")
    write_json(scaler_path, scaler)
    features = regional_features(data["dynamic"][:, column], data["static_features"][column], scaler, config["padding_value"])
    fit_lengths, val_lengths = data["lengths"][fit], data["lengths"][val]
    y_fit = transform_y(targets[fit], scaler)[:, None]
    tf.keras.backend.clear_session()
    tf.keras.utils.set_random_seed(config["seed"])
    network = build_model(config)
    optimizer = network.optimizer
    optimizer.build(network.trainable_variables)

    @tf.function(input_signature=[tf.TensorSpec([None, None, 11], tf.float32), tf.TensorSpec([None, 1], tf.float32)])
    def train_batch(x, y):
        with tf.GradientTape() as tape:
            loss = tf.reduce_mean(tf.square(network(x, training=True) - y))
        gradients = tape.gradient(loss, network.trainable_variables)
        tf.debugging.assert_all_finite(loss, "Nonfinite fit loss")
        for gradient in gradients:
            tf.debugging.assert_all_finite(gradient, "Nonfinite gradient")
        norm = tf.linalg.global_norm(gradients)
        optimizer.apply_gradients(zip(gradients, network.trainable_variables))
        return loss, norm

    last_path = run / "last.npz"
    if last_path.exists():
        state, best_weights = restore_last(last_path, network, optimizer, fingerprint, region_id)
        print(json.dumps(dict(event="RESUME_REGION", region_id=region_id, epoch=state["epoch"],
                              optimizer_steps=int(optimizer.iterations.numpy()))), flush=True)
    else:
        state = dict(region_id=region_id, fingerprint=fingerprint, epoch=0, active_epoch=None, next_batch=0,
                     partial_loss_sum=0., partial_count=0, best_epoch=0, best_mse_cm2=None,
                     best_prediction_reference_cm=None, wait=0, state="RUNNING", started_at=now())
        best_weights = network.get_weights()
    metrics_path = run / "metrics.jsonl"
    last_logged = 0
    if metrics_path.exists():
        lines = metrics_path.read_text().splitlines()
        if lines:
            last_logged = json.loads(lines[-1])["epoch"]
    if state["epoch"] > last_logged and "last_metrics" in state:
        with metrics_path.open("a") as f:
            f.write(json.dumps(state["last_metrics"], allow_nan=False) + "\n")
    while state["epoch"] < config["max_epochs"] and state["wait"] < config["patience"]:
        started = time.monotonic()
        epoch = state["epoch"] + 1
        if state["active_epoch"] is None:
            state.update(active_epoch=epoch, next_batch=0, partial_loss_sum=0., partial_count=0)
        if state["active_epoch"] != epoch:
            raise ValueError("Resume epoch counter mismatch")
        permutation = np.random.default_rng(np.random.SeedSequence([config["seed"], epoch])).permutation(len(y_fit))
        for start in range(state["next_batch"], len(permutation), config["batch_size"]):
            indices = permutation[start:start + config["batch_size"]]
            x = batch_prefixes(features, fit_lengths[indices], config["padding_value"])
            loss, norm = train_batch(x, y_fit[indices])
            state.update(next_batch=start + len(indices), partial_loss_sum=state["partial_loss_sum"] + float(loss) * len(indices),
                         partial_count=state["partial_count"] + len(indices), optimizer_steps=int(optimizer.iterations.numpy()),
                         last_gradient_norm=float(norm), job_id=os.environ["SLURM_JOB_ID"], updated_at=now())
            save_last(last_path, network, optimizer, best_weights, state)
            if state["optimizer_steps"] == 1:
                first = dict(state="RUNNING", phase="FIRST_OPTIMIZER_UPDATE", region_id=region_id,
                             region_number=column + 1, regions_completed=column, region_count=119,
                             train_scaled_mse=float(loss), gradient_norm=float(norm), optimizer_steps=1,
                             job_id=os.environ["SLURM_JOB_ID"], updated_at=now())
                write_json(root / "status.json", first)
                print(json.dumps(dict(event="FIRST_OPTIMIZER_UPDATE", **first)), flush=True)
        fit_output = predict_windows(network, features, fit_lengths, config)
        val_output = predict_windows(network, features, val_lengths, config)
        val_mse, p_ref = centered_validation(fit_output, val_output, targets[val], scaler)
        if not np.isfinite(val_mse) or not np.isfinite(p_ref):
            raise FloatingPointError("Nonfinite updated-weight selection metric")
        if state["best_mse_cm2"] is None or val_mse < state["best_mse_cm2"]:
            state.update(best_epoch=epoch, best_mse_cm2=val_mse, best_prediction_reference_cm=p_ref, wait=0)
            best_weights = network.get_weights()
        else:
            state["wait"] += 1
        metrics = dict(epoch=epoch, train_scaled_mse=state["partial_loss_sum"] / state["partial_count"],
                       val_ref_mse_cm2=val_mse, best_val_ref_mse_cm2=state["best_mse_cm2"], best_epoch=state["best_epoch"],
                       wait=state["wait"], optimizer_steps=int(optimizer.iterations.numpy()),
                       last_gradient_norm=state["last_gradient_norm"], epoch_seconds=time.monotonic() - started, updated_at=now())
        state.update(epoch=epoch, active_epoch=None, next_batch=0, partial_loss_sum=0., partial_count=0, last_metrics=metrics)
        save_last(last_path, network, optimizer, best_weights, state)
        with metrics_path.open("a") as f:
            f.write(json.dumps(metrics, allow_nan=False) + "\n")
        write_json(root / "status.json", dict(state="RUNNING", phase="FIT", region_id=region_id,
                   region_number=column + 1, regions_completed=column, region_count=119,
                   job_id=os.environ["SLURM_JOB_ID"], **metrics))
        if epoch == 1 or epoch % 10 == 0:
            print(json.dumps(dict(event="REGION_EPOCH", region_id=region_id, **metrics)), flush=True)
    network.set_weights(best_weights)
    raw_history = inverse_y(predict_windows(network, features, data["lengths"], config), scaler)
    p_ref = state["best_prediction_reference_cm"]
    np.testing.assert_allclose(raw_history[fit].mean(), p_ref, rtol=1e-5, atol=1e-5)
    network.save(run / "best.keras")
    save_npz(run / "history_predictions.npz", history_anomaly_cm=raw_history - p_ref)
    report = dict(state="SELECTED", region_id=region_id, fingerprint=fingerprint, epochs_completed=state["epoch"],
                  optimizer_steps=int(optimizer.iterations.numpy()), best_epoch=state["best_epoch"],
                  best_val_rmse_cm=state["best_mse_cm2"] ** .5, prediction_reference_cm=p_ref,
                  observation_reference_cm=scaler["observation_reference_cm"], wait=state["wait"],
                  stop_reason="PATIENCE" if state["wait"] >= config["patience"] else "MAX_EPOCHS",
                  seed=config["seed"], attempt_count=1, job_id=os.environ["SLURM_JOB_ID"], selected_at=now())
    write_json(report_path, report)
    print(json.dumps(dict(event="REGION_SELECTED", **report)), flush=True)
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    if not os.environ.get("SLURM_JOB_ID"):
        raise RuntimeError("Numerical execution requires a Slurm compute node")
    root = args.root.resolve()
    config = json.loads((root / "config.json").read_text())
    fingerprint = digest(root / "config.json") + ":" + digest(root / "inputs/inputs.npz")
    import tensorflow as tf
    if tf.__version__ != config["tensorflow_version"]:
        raise ValueError("TensorFlow version differs from frozen config")
    tf.config.threading.set_inter_op_parallelism_threads(1)
    tf.config.threading.set_intra_op_parallelism_threads(config["threads"])
    gpus = tf.config.list_physical_devices("GPU")
    if len(gpus) != 1:
        raise RuntimeError("B04 requires the one Slurm-allocated GPU; no silent CPU fallback")
    tf.config.experimental.set_memory_growth(gpus[0], True)
    tf.config.experimental.enable_op_determinism()
    tf.config.experimental.enable_tensor_float_32_execution(False)
    write_json(root / "runtime.json", dict(tensorflow=tf.__version__, build=tf.sysconfig.get_build_info(),
               gpu=str(gpus[0]), details=tf.config.experimental.get_device_details(gpus[0]), job_id=os.environ["SLURM_JOB_ID"]))
    data = load_history(root, config)
    interface_check(tf, data, config, root, fingerprint)
    reports = []
    for column in range(config["region_count"]):
        write_json(root / "status.json", dict(state="RUNNING", phase="REGION_START", region_id=str(data["support_ids"][column]),
                   regions_completed=len(reports), region_count=119, job_id=os.environ["SLURM_JOB_ID"], updated_at=now()))
        reports.append(fit_region(tf, config, data, column, root, fingerprint))
        write_json(root / "regional_completion.json", reports)
    write_json(root / "selection.json", dict(state="FROZEN", region_count=119, selection_year=2008,
               fingerprint=fingerprint, regions=reports, frozen_at=now()))
    app = load_application(root, data)
    history, application = [], []
    for column, report in enumerate(reports):
        run = root / "runs" / report["region_id"]
        scaler = json.loads((run / "scalers.json").read_text())
        tf.keras.backend.clear_session()
        network = tf.keras.models.load_model(run / "best.keras", compile=False)
        features = regional_features(app["dynamic"][:, column], data["static_features"][column], scaler, config["padding_value"])
        pred = inverse_y(predict_windows(network, features, app["lengths"], config), scaler) - report["prediction_reference_cm"]
        save_npz(run / "application_predictions.npz", application_anomaly_cm=pred)
        with np.load(run / "history_predictions.npz", allow_pickle=False) as z:
            history.append(z["history_anomaly_cm"])
        application.append(pred)
    save_npz(root / "predictions.npz", support_ids=data["support_ids"],
             solution_ids=np.concatenate([data["solution_ids"], app["solution_ids"]]),
             fit_mask=data["fit_mask"], history_anomaly_cm=np.stack(history, axis=1),
             application_anomaly_cm=np.stack(application, axis=1))
    from compare_graice_author_matched import compare
    comparison = compare(root, data)
    report = dict(state="COMPLETED", exp_id=config["exp_id"], fingerprint=fingerprint,
                  region_count=119, attempts_per_region=1, seed=config["seed"],
                  job_id=os.environ["SLURM_JOB_ID"], comparison=comparison, finished_at=now())
    write_json(root / "report.json", report)
    write_json(root / "status.json", report)
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        if "--root" in sys.argv:
            root = Path(sys.argv[sys.argv.index("--root") + 1])
            write_json(root / ("failure_" + os.environ.get("SLURM_JOB_ID", "local") + ".json"),
                       dict(state="TECHNICAL_FAILURE", error_type=type(error).__name__, message=str(error), updated_at=now()))
        raise
