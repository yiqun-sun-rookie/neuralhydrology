"""Single-interaction orchestration over frozen fifteen-state base operators.

Pure in-memory construction: no real-data loaders, training, output writes or job
submission. Historical fitted noise is not free of retrospective information.
"""
from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter

import numpy as np

from hbv_joint_uncertainty.hbv_adapter import PARAMETER_NAMES, _validated_parameters
from hbv_joint_uncertainty.hbv_state_mapping import (
    _finite_covariance, project_hbv_state_conserving_soil_excess, remap_parfc_moments,
)
from hbv_joint_uncertainty.imm import InteractingMultipleModel, interact_model_states
from hbv_joint_uncertainty.preflight import ForcingTransition
from hbv_joint_uncertainty.sigma_filter import ModifiedUnscentedFilter, ScaledSigmaPoints
from scl_hydro.hbv_lite_numpy import resolve_hbv_bounds

from .g2_switch_confirmation import RisingRoutedObservation
from .parameter_axis_adaptive_candidates import ARMS, initial_grid, propose_movement, switching_matrix
from .parameter_axis_input_contract import DAYS, PREPARATION_DAYS

OBSERVATION_MODES = ("previous_flow", "constant", "constant_2_5")


def leave_one_out_covariance(coefficients, recipient_index: int, amplitudes) -> np.ndarray:
    """Exclude exactly one recipient from 52 frozen six-group coefficient cards."""
    cards = np.asarray(coefficients, dtype=np.float64)
    scales = np.asarray(amplitudes, dtype=np.float64)
    if (cards.shape != (52, 6) or not np.all(np.isfinite(cards)) or np.any(cards <= 0)
            or type(recipient_index) is not int or not 0 <= recipient_index < 52):
        raise ValueError("expected 52 finite positive coefficient cards and one recipient")
    if scales.shape != (6,) or not np.all(np.isfinite(scales)) or np.any(scales < 0.01):
        raise ValueError("expected six frozen amplitudes at least 0.01")
    donors = np.delete(cards, recipient_index, axis=0)
    rho = np.exp(np.median(np.log(donors), axis=0))
    variances = (rho * scales) ** 2
    matrix = np.diag(np.r_[variances[:5], np.repeat(variances[5], 10)])
    return _finite_covariance(matrix, "shared process covariance")


def preparation_scale(observations) -> float:
    values = np.asarray(observations, dtype=np.float64)
    if values.shape != (PREPARATION_DAYS,) or not np.all(np.isfinite(values)) or np.any(values < 0):
        raise ValueError("scale requires exactly the 840 finite nonnegative preparation observations")
    return max(0.1 * float(np.median(values)), 0.02)


def observation_variance(scale: float, previous_flow: float | None, mode: str) -> float:
    if not np.isfinite(scale) or scale < 0.02 or mode not in OBSERVATION_MODES:
        raise ValueError("invalid frozen observation scale or mode")
    if previous_flow is not None and (not np.isfinite(previous_flow) or previous_flow < 0):
        raise ValueError("previous flow must be finite and nonnegative")
    if mode == "constant_2_5":
        return (2.5 * scale) ** 2
    if mode == "previous_flow" and previous_flow is not None:
        return max(0.1 * previous_flow, scale) ** 2
    return scale ** 2


@dataclass(frozen=True)
class DailyResult:
    day: int
    capacities: np.ndarray
    transport: np.ndarray
    transition: np.ndarray
    conditional_weights: np.ndarray
    prior_flow: float
    prior_probabilities: np.ndarray
    posterior_probabilities: np.ndarray
    observation_variance: float
    movement: object | None
    mappings: tuple[dict, ...]
    minimum_covariance_eigenvalue: float
    counts: dict
    seconds: dict


class AdaptiveCandidateFilter:
    """One basin and one frozen arm; step() consumes days in order without retry.

    Arrays passed here are already in memory. Real runs must enter through an
    independently audited input interface; this class is not a data authorization.
    """

    def __init__(self, center_parameters, initial_hydro, process_covariance, scale: float,
                 arm: str, observation_mode: str = "previous_flow"):
        if arm not in ARMS:
            raise ValueError("unknown frozen arm")
        if set(center_parameters) != set(PARAMETER_NAMES):
            raise ValueError("center must contain exactly the thirteen frozen parameters")
        self.bounds = resolve_hbv_bounds("v5")
        self.center = _validated_parameters(dict(center_parameters), self.bounds)
        self.arm, self.observation_mode = arm, observation_mode
        self.scale = float(scale)
        observation_variance(self.scale, None, observation_mode)
        self.q = _finite_covariance(process_covariance, "shared process covariance").copy()
        if not np.array_equal(self.q, np.diag(np.diag(self.q))) or np.any(np.diag(self.q) <= 0):
            raise ValueError("six-group process covariance must be positive diagonal")
        if not np.all(np.diag(self.q)[5:] == self.q[5, 5]):
            raise ValueError("ten routing states must share the sixth group variance")
        self.q.setflags(write=False)
        count = 1 if arm == "center_single" else 5 if arm == "fixed_five" else 3
        self.grid = initial_grid(self.center["parFC"], count)
        self.parameters = self._parameters(self.grid)
        hydro = np.asarray(initial_hydro, dtype=np.float64)
        if hydro.shape != (5,) or not np.all(np.isfinite(hydro)):
            raise ValueError("initial hydrologic state must contain five finite values")
        raw = np.r_[hydro, np.zeros(10)]
        self.center_state = project_hbv_state_conserving_soil_excess(raw, self.center)
        self.center_covariance = np.diag((0.001 * np.maximum(abs(self.center_state), 1)) ** 2)
        self.sigma = ScaledSigmaPoints(15, alpha=0.6874, beta=2, kappa=-2)
        self.transition_calls = 0
        filters = []
        for params in self.parameters:
            mean, covariance = remap_parfc_moments(self.center_state, self.center_covariance,
                                                 self.center, params, self.sigma)
            filters.append(self._filter(params, mean, covariance))
        self.switching = switching_matrix(count)
        self.bank = InteractingMultipleModel(filters, self.switching, np.full(count, 1 / count),
                                             tuple(range(count)), model_evidence_scorer=None)
        self.day = 0
        self.previous_flow = None
        self.pending = None
        self.failed = False

    def _parameters(self, grid):
        # The single-candidate reference keeps the ORIGINAL float exactly.
        if len(grid) == 1:
            return (dict(self.center),)
        values = np.exp(grid)
        # Restore exact physical endpoints, avoiding exp(log(2500)) > 2500.
        values[0] = max(50.0, self.center["parFC"] / 2)
        values[-1] = min(2500.0, self.center["parFC"] * 2)
        return tuple({**self.center, "parFC": float(value)} for value in values)

    def _filter(self, parameters, state, covariance):
        projector = lambda values: project_hbv_state_conserving_soil_excess(values, parameters)
        transition = ForcingTransition(parameters, self.bounds, projector)

        def counted_transition(values):
            self.transition_calls += 1
            return transition(values)

        candidate = ModifiedUnscentedFilter(
            state, covariance, counted_transition, RisingRoutedObservation(parameters),
            self.q, np.array([[self.scale ** 2]]), state_projector=projector,
            alpha=0.6874, beta=2, kappa=-2)
        candidate.forcing_transition = transition
        return candidate

    def step(self, rain: float, pet: float, temperature: float, observed_flow: float) -> DailyResult:
        if self.failed:
            raise RuntimeError("failed sequence is sealed; do not retry or reset it")
        if self.day >= DAYS:
            raise ValueError("sequence cannot extend beyond 1260 days")
        values = np.asarray([rain, pet, temperature, observed_flow], dtype=np.float64)
        if not np.all(np.isfinite(values)) or np.any(values[[0, 1, 3]] < 0):
            raise ValueError("daily forcing and observation must be finite; water inputs nonnegative")
        self.failed = True  # A partial numerical failure must never silently resume.
        total_start = perf_counter()
        count_before = self.transition_calls
        old_parameters = tuple(dict(x) for x in self.parameters)
        target_grid = self.grid.copy() if self.pending is None else self.pending.new_grid.copy()
        target_parameters = self._parameters(target_grid)
        count = len(self.parameters)
        transport = np.eye(count) if self.pending is None else self.pending.transport.copy()
        combined_transition = transport @ self.switching
        mappings = []
        mapping_points = 0

        def remap(source, destination, mean, covariance):
            nonlocal mapping_points
            src, dst = old_parameters[source], target_parameters[destination]
            before = _finite_covariance(covariance, "source covariance")
            mapped_mean, mapped_cov = remap_parfc_moments(mean, before, src, dst, self.sigma)
            if dst["parFC"] < src["parFC"]:
                mapping_points += self.sigma.count
            selector = np.zeros(15)
            selector[2:4] = 1
            mappings.append({"source": source, "destination": destination,
                             "old_capacity": src["parFC"], "new_capacity": dst["parFC"],
                             "water_before": float(selector @ mean), "water_after": float(selector @ mapped_mean),
                             "variance_before": float(selector @ before @ selector),
                             "variance_after": float(selector @ mapped_cov @ selector)})
            return mapped_mean, mapped_cov

        interaction_start = perf_counter()
        states = np.array([x.state for x in self.bank.filters])
        covariances = np.array([_finite_covariance(x.covariance, "source covariance") for x in self.bank.filters])
        if count == 1:
            prior, conditional, means, covs = np.ones(1), np.ones((1, 1)), states, covariances
        else:
            interaction = interact_model_states(states, covariances, combined_transition,
                                                self.bank.probabilities, tuple(range(count)),
                                                interaction_mode="full", pairwise_moment_transform=remap)
            prior, conditional = interaction.prior_probabilities, interaction.conditional_weights
            means, covs = interaction.mixed_states, interaction.mixed_covariances
        for j in range(count):
            _finite_covariance(covs[j], "mixed covariance")
            if target_parameters[j] != old_parameters[j]:
                # Rebind dynamics using the transported moments, NEVER the initial state/P0.
                self.bank.filters[j] = self._filter(target_parameters[j], means[j], covs[j])
            else:
                self.bank.filters[j].state = means[j].copy()
                self.bank.filters[j].covariance = covs[j].copy()
        interaction_seconds = perf_counter() - interaction_start
        variance = observation_variance(self.scale, self.previous_flow, self.observation_mode)
        for candidate in self.bank.filters:
            if not np.array_equal(candidate.process_covariance, self.q):
                raise ValueError("shared process covariance was modified")
            candidate.observation_covariance = np.array([[variance]])
            candidate.forcing_transition.set_forcing(rain, pet, temperature)
        filter_start = perf_counter()
        result = self.bank.update_after_interaction(np.array([observed_flow]), prior)
        filter_seconds = perf_counter() - filter_start
        smallest = min(float(np.linalg.eigvalsh(_finite_covariance(x.covariance, "posterior covariance")).min())
                       for x in self.bank.filters)
        prior_flow = float(result.combined_prior_observation[0])
        if not np.isfinite(prior_flow):
            raise ValueError("prior flow must be finite")
        self.grid, self.parameters = target_grid, target_parameters
        self.day += 1
        self.previous_flow = float(observed_flow)
        self.pending = (propose_movement(self.grid, self.bank.probabilities, self.day)
                        if self.arm == "moving_three" else None)
        self.failed = False
        return DailyResult(
            self.day, np.array([p["parFC"] for p in self.parameters]), transport, combined_transition,
            conditional, prior_flow, result.prior_probabilities, result.posterior_probabilities, variance,
            self.pending, tuple(mappings), smallest,
            {"filter_steps": count, "model_advances": self.transition_calls - count_before,
             "moment_mappings": len(mappings), "representative_point_mappings": mapping_points,
             "interaction_rounds": int(count > 1)},
            {"interaction": interaction_seconds, "filter": filter_seconds, "total": perf_counter() - total_start})
