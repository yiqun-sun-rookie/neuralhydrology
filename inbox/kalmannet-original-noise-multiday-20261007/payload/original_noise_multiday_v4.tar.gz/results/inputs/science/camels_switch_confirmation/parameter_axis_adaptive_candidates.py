"""Frozen log-capacity movement rule; no data access or filter execution.

Implements sections 4 and 5 of parameter_axis_adaptive_candidates_plan_20260907_v02.
Day numbers are one-based. A decision after day t applies only to day t + 1.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

ARMS = ("center_single", "fixed_three", "moving_three", "fixed_five")
MOVE_DAYS = tuple(range(840, 1231, 30))


def validate_grid(values) -> np.ndarray:
    grid = np.asarray(values, dtype=np.float64)
    if grid.ndim != 1 or len(grid) < 2 or not np.all(np.isfinite(grid)):
        raise ValueError("grid must be a finite vector with at least two nodes")
    if np.any(np.diff(grid) <= 0):
        raise ValueError("grid nodes must be strictly increasing")
    return grid.copy()


def initial_grid(center: float, count: int = 3) -> np.ndarray:
    if not np.isfinite(center) or not 50 <= center <= 2500:
        raise ValueError("center capacity must be within [50, 2500]")
    if count not in (1, 3, 5):
        raise ValueError("candidate count must be 1, 3, or 5")
    if count == 1:
        return np.array([np.log(center)])
    lower, upper = np.log([max(50, center / 2), min(2500, center * 2)])
    return validate_grid(np.linspace(lower, upper, count))


def switching_matrix(count: int) -> np.ndarray:
    if count not in (1, 3, 5):
        raise ValueError("candidate count must be 1, 3, or 5")
    if count == 1:
        return np.ones((1, 1))
    matrix = np.full((count, count), 0.01 if count == 3 else 0.005)
    np.fill_diagonal(matrix, 0.98)
    return matrix


def transport_matrix(old, new) -> np.ndarray:
    old, new = validate_grid(old), validate_grid(new)
    if old.shape != new.shape or old[0] != new[0] or old[-1] != new[-1]:
        raise ValueError("transport requires equal counts and fixed endpoints")
    if np.array_equal(old, new):
        return np.eye(len(old))
    matrix = np.zeros((len(old), len(new)))
    for i, node in enumerate(old):
        exact = np.flatnonzero(new == node)
        if exact.size:
            matrix[i, exact[0]] = 1.0
        else:
            right = int(np.searchsorted(new, node))
            fraction = (node - new[right - 1]) / (new[right] - new[right - 1])
            matrix[i, right - 1:right + 1] = (1 - fraction, fraction)
    if np.any(matrix < 0) or not np.allclose(matrix.sum(1), 1, rtol=0, atol=1e-14):
        raise ValueError("transport must preserve nonnegative probability mass")
    if not np.allclose(matrix @ new, old, rtol=0, atol=1e-14):
        raise ValueError("transport must preserve log-capacity means")
    return matrix


@dataclass(frozen=True)
class Movement:
    after_day: int
    opportunity: bool
    moved: bool
    old_grid: np.ndarray
    new_grid: np.ndarray
    transport: np.ndarray


def propose_movement(grid, probabilities, after_day: int) -> Movement:
    old = validate_grid(grid)
    weights = np.asarray(probabilities, dtype=np.float64)
    if old.shape != (3,) or weights.shape != (3,):
        raise ValueError("movement requires exactly three candidates")
    if (not np.all(np.isfinite(weights)) or np.any(weights < 0)
            or not np.isclose(weights.sum(), 1, rtol=0, atol=1e-12)):
        raise ValueError("probabilities must be finite, nonnegative and sum to one")
    if type(after_day) is not int or not 1 <= after_day <= 1260:
        raise ValueError("after_day must be an integer within [1, 1260]")
    new = old.copy()
    opportunity = after_day in MOVE_DAYS
    if opportunity:
        lower, center, upper = old
        width = upper - lower
        suggested = center + 0.25 * (float(weights @ old) - center)
        suggested = np.clip(suggested, lower + 0.10 * width, upper - 0.10 * width)
        delta = float(np.clip(suggested - center, -0.10 * width, 0.10 * width))
        # Strictly below the registered threshold is a no-op; equality moves.
        if abs(delta) >= 0.05 * width:
            new[1] = center + delta
    return Movement(after_day, opportunity, not np.array_equal(old, new), old, new,
                    transport_matrix(old, new))
