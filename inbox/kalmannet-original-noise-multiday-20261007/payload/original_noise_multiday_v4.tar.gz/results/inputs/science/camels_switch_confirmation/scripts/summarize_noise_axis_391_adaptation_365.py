"""Corrected post-run aggregation for the 365-day adaptation sensitivity.

The frozen run code is intentionally not edited after its hashes were checked.
Its first aggregation attempt stopped because the 391-policy extra-cell table
contains only fixed-arm columns.  This script verifies the original run hashes,
merges that table with the original core table, and then performs the planned
pairwise summaries without rerunning any basin.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

_SRC = Path(__file__).resolve().parents[2]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation import noise_axis_391_adaptation_365 as sensitivity  # noqa: E402
from camels_switch_confirmation import noise_axis_391_confirmation as original  # noqa: E402

import run_noise_axis_391_adaptation_365 as run  # noqa: E402


def load_original_nine_arm_table() -> pd.DataFrame:
    """Join the frozen core table to the separate 391-policy fixed-arm table."""
    core = pd.read_csv(sensitivity.ORIGINAL_MAIN_TABLE, dtype={"basin_id": str})
    fixed = pd.read_csv(sensitivity.ORIGINAL_EXTRA_POLICY_TABLE, dtype={"basin_id": str})
    core["basin_id"] = core["basin_id"].str.zfill(8)
    fixed["basin_id"] = fixed["basin_id"].str.zfill(8)
    overlap = core[["basin_id", "m1_c0_nse_score"]].merge(
        fixed[["basin_id", "m1_c0_nse_score"]],
        on="basin_id",
        suffixes=("_core", "_fixed"),
        validate="one_to_one",
    )
    worst = float(
        np.max(
            np.abs(
                overlap["m1_c0_nse_score_core"].to_numpy(dtype=float)
                - overlap["m1_c0_nse_score_fixed"].to_numpy(dtype=float)
            )
        )
    )
    if worst != 0.0:
        raise ValueError(f"old core and fixed tables disagree for m1_c0: {worst}")
    fixed = fixed.drop(columns=["m1_c0_nse_score"])
    merged = core.merge(fixed, on="basin_id", validate="one_to_one")
    if len(merged) != 391:
        raise ValueError(f"old nine-arm join must contain 391 basins, got {len(merged)}")
    return merged


def summarize() -> int:
    run._verify_preflight_and_hashes()
    basins = run._load_frozen_basins()
    table, failures = run._records_to_table(basins)
    table.to_csv(run.PER_BASIN_PATH, index=False)
    required_score_columns = [f"{arm}_nse_score" for arm in sensitivity.ALL_ARMS]
    core_score_columns = [f"{arm}_nse_score" for arm in original.ALL_ARMS]
    missing_columns = [column for column in required_score_columns if column not in table]
    if missing_columns:
        failures.append({"scope": "table", "error": f"missing columns: {missing_columns}"})
    complete_core = table.dropna(
        subset=[column for column in core_score_columns if column in table]
    )
    complete_all_nine = table.dropna(
        subset=[column for column in required_score_columns if column in table]
    )

    summary: dict[str, object] = {
        "experiment_id": sensitivity.EXPERIMENT_ID,
        "analysis_status": "post_hoc_after_391_scores_were_exposed",
        "contract": sensitivity.validate_contract(),
        "n_frozen": len(basins),
        "n_records": int(len(table)),
        "n_complete_core_five_arms": int(len(complete_core)),
        "n_complete_all_nine_arms": int(len(complete_all_nine)),
        "n_failures": len(failures),
        "failures": failures,
        "arms": {},
        "comparisons": {},
        "comparisons_complete_nine_arms": {},
        "change_from_1735_day_result": {},
        "gain_change_from_1735_day_result": {},
        "amplitude_change": {},
        "aggregation_repair": {
            "first_attempt_status": "stopped_before_summary_json",
            "first_attempt_error": (
                "The 391-policy fixed-arm table was incorrectly assumed to include core-arm columns."
            ),
            "repair": (
                "Joined the unchanged original core table and 391-policy fixed-arm table by basin_id; "
                "no basin was rerun and the frozen run code was not edited."
            ),
        },
        "record_status_semantics": (
            "A basin record's top-level status reports task construction only; arm-level status "
            "determines whether all nine arms completed."
        ),
        "interpretation_boundary": (
            "The 1,735-day result remains the prospective confirmation. This is an "
            "outcome-aware sensitivity analysis and cannot be called a second confirmation."
        ),
    }
    if complete_core.empty:
        run.SUMMARY_PATH.write_text(json.dumps(summary, indent=1), encoding="utf-8")
        return 1

    for arm in sensitivity.ALL_ARMS:
        column = f"{arm}_nse_score"
        if column in table:
            summary["arms"][arm] = run._describe(table[column])

    fixed_medians = {
        arm: float(table[f"{arm}_nse_score"].median())
        for arm in sensitivity.FIXED_ARMS
        if f"{arm}_nse_score" in table
    }
    best_single_fixed_arm = max(fixed_medians, key=fixed_medians.get)
    summary["fixed_arm_median_nse"] = fixed_medians
    summary["best_single_fixed_arm_by_median_nse"] = best_single_fixed_arm
    fixed_columns = [
        f"{arm}_nse_score"
        for arm in sensitivity.FIXED_ARMS
        if f"{arm}_nse_score" in table
    ]
    best_per_basin_fixed = table[fixed_columns].max(axis=1)

    comparisons: dict[str, object] = summary["comparisons"]
    paired_m1_open = table.dropna(subset=["m1_c0_nse_score", "open_loop_nse_score"])
    comparisons["m1_c0_vs_open_loop"] = run._describe(
        paired_m1_open["m1_c0_nse_score"] - paired_m1_open["open_loop_nse_score"]
    )
    for card in sensitivity.CARD_ARMS:
        paired_m1 = table.dropna(subset=[f"{card}_nse_score", "m1_c0_nse_score"])
        comparisons[f"{card}_vs_m1_c0"] = run._describe(
            paired_m1[f"{card}_nse_score"] - paired_m1["m1_c0_nse_score"]
        )
        paired_best_single = table.dropna(
            subset=[f"{card}_nse_score", f"{best_single_fixed_arm}_nse_score"]
        )
        comparisons[f"{card}_vs_best_single_fixed[{best_single_fixed_arm}]"] = run._describe(
            paired_best_single[f"{card}_nse_score"]
            - paired_best_single[f"{best_single_fixed_arm}_nse_score"]
        )
        oracle = table[["basin_id", f"{card}_nse_score"]].copy()
        oracle["best_per_basin_fixed"] = best_per_basin_fixed
        oracle = oracle.dropna(subset=[f"{card}_nse_score", "best_per_basin_fixed"])
        comparisons[f"{card}_vs_per_basin_oracle_best_fixed"] = run._describe(
            oracle[f"{card}_nse_score"] - oracle["best_per_basin_fixed"]
        )

    strict_comparisons: dict[str, object] = summary["comparisons_complete_nine_arms"]
    strict_best_per_basin_fixed = complete_all_nine[fixed_columns].max(axis=1)
    for card in sensitivity.CARD_ARMS:
        strict_comparisons[f"{card}_vs_per_basin_oracle_best_fixed"] = run._describe(
            complete_all_nine[f"{card}_nse_score"] - strict_best_per_basin_fixed
        )

    old = load_original_nine_arm_table()
    old_columns = ["basin_id"] + [f"{arm}_nse_score" for arm in sensitivity.ALL_ARMS]
    paired = table.merge(
        old[old_columns],
        on="basin_id",
        suffixes=("_365", "_1735"),
        validate="one_to_one",
    )
    for arm in sensitivity.ALL_ARMS:
        summary["change_from_1735_day_result"][arm] = run._describe(
            paired[f"{arm}_nse_score_365"] - paired[f"{arm}_nse_score_1735"]
        )
    for card in sensitivity.CARD_ARMS:
        gain_365 = paired[f"{card}_nse_score_365"] - paired["m1_c0_nse_score_365"]
        gain_1735 = paired[f"{card}_nse_score_1735"] - paired["m1_c0_nse_score_1735"]
        summary["gain_change_from_1735_day_result"][card] = run._describe(
            gain_365 - gain_1735
        )

    amplitude_paired = table.merge(
        run._old_amplitude_table(basins), on="basin_id", validate="one_to_one"
    )
    for group_name in original.GROUP_NAMES:
        new_values = amplitude_paired[f"amplitude_{group_name}"]
        old_values = amplitude_paired[f"amplitude_{group_name}_1735"]
        summary["amplitude_change"][group_name] = {
            "ratio_365_over_1735": run._describe(new_values / old_values),
            "n_at_floor_365": int(np.isclose(new_values, original.AMPLITUDE_FLOOR_MM).sum()),
            "n_at_floor_1735": int(np.isclose(old_values, original.AMPLITUDE_FLOOR_MM).sum()),
        }

    run.SUMMARY_PATH.write_text(json.dumps(summary, indent=1), encoding="utf-8")
    print(
        json.dumps(
            {
                "n_complete_core_five_arms": summary["n_complete_core_five_arms"],
                "n_complete_all_nine_arms": summary["n_complete_all_nine_arms"],
                "n_failures": summary["n_failures"],
                "fixed_arm_median_nse": fixed_medians,
                "best_single_fixed_arm": best_single_fixed_arm,
                "comparisons": comparisons,
                "comparisons_complete_nine_arms": strict_comparisons,
                "gain_change_from_1735_day_result": summary[
                    "gain_change_from_1735_day_result"
                ],
            },
            indent=1,
        )
    )
    return 0 if len(table) == len(basins) and len(complete_core) == len(basins) else 1


if __name__ == "__main__":
    sys.exit(summarize())
