"""Post-hoc 365-day adaptation sensitivity on the exposed 391-basin sample.

The prospective 1,735-day confirmation remains frozen in
``noise_axis_391_confirmation``.  This module changes only the amount of
receiver history available before the unchanged scoring window and writes to
an independent result root.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from camels_switch_confirmation import noise_axis_391_confirmation as original


EXPERIMENT_ID = "noise_axis_391_adaptation_365d_sensitivity_v01"
PROTOCOL = Path(
    "docs/plans/2026-09-04-noise-axis-391-365-day-adaptation-sensitivity-protocol-v01.md"
)

# The scoring dates are held fixed.  The new load start is derived by stepping
# back exactly 365 days from the first scored day; 1984 is a leap year, so the
# start is 1983-10-02 rather than 1983-10-01.
SCORE_START = "1984-10-01"
SCORE_END = "1989-09-30"
ADAPTATION_DAYS = 365
SCORE_DAYS = 1826
LOAD_START = str((pd.Timestamp(SCORE_START) - pd.Timedelta(days=ADAPTATION_DAYS)).date())
LOAD_DAYS = ADAPTATION_DAYS + SCORE_DAYS

ORIGINAL_OUTPUT_ROOT = original.OUTPUT_ROOT
ORIGINAL_FROZEN_LIST = ORIGINAL_OUTPUT_ROOT / "frozen_basin_list.csv"
ORIGINAL_MAIN_TABLE = ORIGINAL_OUTPUT_ROOT / "confirmation_per_basin.csv"
ORIGINAL_EXTRA_TABLE = ORIGINAL_OUTPUT_ROOT / "extra_cells_per_basin.csv"
ORIGINAL_EXTRA_POLICY_TABLE = ORIGINAL_OUTPUT_ROOT / "extra_cells_per_basin_policy391.csv"
OUTPUT_ROOT = (
    original.RESULTS / "noise_axis_391_adaptation_365d_sensitivity_20260904_local"
)

FIXED_MULTIPLIERS = (0.1, 0.3, 1.0, 3.0, 10.0)
FIXED_ARMS = tuple(f"m{multiplier:g}_c0" for multiplier in FIXED_MULTIPLIERS)
CARD_ARMS = original.CARD_ARMS
ALL_ARMS = ("open_loop",) + FIXED_ARMS + CARD_ARMS


def validate_contract() -> dict[str, object]:
    """Return the date contract after fail-closed calendar checks."""
    load_start = pd.Timestamp(LOAD_START)
    score_start = pd.Timestamp(SCORE_START)
    score_end = pd.Timestamp(SCORE_END)
    adaptation_end = score_start - pd.Timedelta(days=1)
    if LOAD_START != "1983-10-02":
        raise ValueError(f"365-day load start changed unexpectedly: {LOAD_START}")
    if original.window_end(LOAD_START, ADAPTATION_DAYS) != str(adaptation_end.date()):
        raise ValueError("adaptation window does not end immediately before scoring")
    if original.window_end(LOAD_START, LOAD_DAYS) != SCORE_END:
        raise ValueError("load window does not end on the frozen scoring end date")
    if (score_end - score_start).days + 1 != SCORE_DAYS:
        raise ValueError("frozen scoring window is not exactly 1,826 days")
    if (score_start - load_start).days != ADAPTATION_DAYS:
        raise ValueError("load window does not contain exactly 365 pre-score days")
    if LOAD_DAYS - ADAPTATION_DAYS != SCORE_DAYS:
        raise ValueError("score slice length changed")
    if OUTPUT_ROOT == ORIGINAL_OUTPUT_ROOT:
        raise ValueError("sensitivity output root must not equal the frozen result root")
    return {
        "experiment_id": EXPERIMENT_ID,
        "analysis_status": "post_hoc_after_391_scores_were_exposed",
        "load_start": LOAD_START,
        "adaptation_end": str(adaptation_end.date()),
        "adaptation_days": ADAPTATION_DAYS,
        "score_start": SCORE_START,
        "score_end": SCORE_END,
        "score_days": SCORE_DAYS,
        "load_days": LOAD_DAYS,
        "score_from_index_zero_based": ADAPTATION_DAYS,
        "original_adaptation_days": original.INIT_DAYS,
        "original_output_root": str(ORIGINAL_OUTPUT_ROOT),
        "output_root": str(OUTPUT_ROOT),
        "arms": list(ALL_ARMS),
    }


def load_cards() -> dict[str, np.ndarray]:
    """Load the same three frozen cards without learning or reselection."""
    return original.load_cards()


def run_basin_all_arms(
    basin: str,
    cards: dict[str, np.ndarray],
    *,
    load_start: str = LOAD_START,
    load_days: int = LOAD_DAYS,
    adaptation_days: int = ADAPTATION_DAYS,
) -> dict:
    """Run the existing nine comparison arms under one explicit history contract.

    The keyword arguments exist only for the run-before-run compatibility check,
    which replays the frozen 1,735-day contract through this new wrapper.
    """
    record: dict = {
        "experiment_id": EXPERIMENT_ID,
        "basin_id": basin,
        "status": "success",
        "load_start": load_start,
        "load_days": int(load_days),
        "adaptation_days": int(adaptation_days),
        "score_from_index_zero_based": int(adaptation_days),
        "arms": {},
    }
    try:
        task = original.build_task(basin, load_start, load_days)
        states = original.open_loop_states(task, basin)
        amplitudes = original.windowed_amplitudes(states, adaptation_days)
        record["sigma_obs"] = float(task["sigma"])
        record["amplitudes"] = [float(value) for value in amplitudes]
    except Exception as exc:  # noqa: BLE001 - failure is recorded per frozen rule
        record["status"] = "task_failed"
        record["error"] = f"{type(exc).__name__}: {exc}"
        return record

    fixed_noise = {
        f"m{multiplier:g}_c0": original.LegacyGridNoise(m=multiplier, c=0.0)
        for multiplier in FIXED_MULTIPLIERS
    }
    for arm in ALL_ARMS:
        try:
            if arm == "open_loop":
                outcome = original.open_loop_nse(task, basin, adaptation_days)
            elif arm in fixed_noise:
                outcome = original.filter_arm_nse(
                    task, basin, fixed_noise[arm], adaptation_days
                )
            else:
                noise = original.GroupedProcessNoise(
                    tuple(cards[arm]), tuple(record["amplitudes"])
                )
                outcome = original.filter_arm_nse(task, basin, noise, adaptation_days)
            record["arms"][arm] = {"status": "success", **outcome}
        except Exception as exc:  # noqa: BLE001 - failure is recorded per frozen rule
            record["arms"][arm] = {
                "status": "failed",
                "error": f"{type(exc).__name__}: {exc}",
            }
    return record


__all__ = [
    "ADAPTATION_DAYS",
    "ALL_ARMS",
    "CARD_ARMS",
    "EXPERIMENT_ID",
    "FIXED_ARMS",
    "FIXED_MULTIPLIERS",
    "LOAD_DAYS",
    "LOAD_START",
    "ORIGINAL_FROZEN_LIST",
    "ORIGINAL_EXTRA_POLICY_TABLE",
    "ORIGINAL_MAIN_TABLE",
    "ORIGINAL_OUTPUT_ROOT",
    "OUTPUT_ROOT",
    "PROTOCOL",
    "SCORE_DAYS",
    "SCORE_END",
    "SCORE_START",
    "load_cards",
    "run_basin_all_arms",
    "validate_contract",
]
