"""ID 29 (transferable filter noise) — main-text figures for the manuscript, from frozen artefacts only.

Every number drawn here is recomputed from a frozen results artefact and asserted against the
value registered in the corresponding results document (docs/plans/). A mismatch raises, so a
successful run is itself the receipt that the figures agree with the ledger
(draft/papers/29_transferable_filter_noise/claims_ledger.md).

Inputs (read-only)
    results/23_camels_switch_confirmation/noise_axis_step2_learned_q_20260827_local/{baselines,evaluation}_per_basin.csv
    results/23_camels_switch_confirmation/noise_axis_transfer_loo_20260828_local/{transfer_per_basin.csv, matrix/*.json}
    results/23_camels_switch_confirmation/noise_axis_denormalized_transfer_control_20260902_hpc/{receivers_per_basin.csv, absolute_matrix_nse_holdout.csv}
    results/23_camels_switch_confirmation/noise_axis_391_global_card_confirmation_20260901_local/{confirmation_per_basin.csv, extra_cells_per_basin_policy391.csv}
    data/camels_us/camels_attributes_v2.0/camels_topo.txt

Outputs
    draft/papers/29_transferable_filter_noise/figures/fig{1..5}_*.{png,pdf}
    draft/papers/29_transferable_filter_noise/figures/figure_data/fig{1..5}_*.csv   (the exact numbers plotted)
    draft/papers/29_transferable_filter_noise/figures/MANIFEST.sha256

Usage (repository root)
    python src/camels_switch_confirmation/scripts/make_id29_paper_figures.py

Decisions recorded in the ledger: the 52-basin panel of Figure 1 starts at m1_c0 (no frozen
open-loop holdout artefact exists; user decision 2026-09-03); the borrowed card shown for the
52 basins is the prospective (no-leak) selection; ORACLE is drawn only as a hindsight bound.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

ROOT = Path(__file__).resolve().parents[3]
RES = ROOT / "results/23_camels_switch_confirmation"
STEP2 = RES / "noise_axis_step2_learned_q_20260827_local"
LOO = RES / "noise_axis_transfer_loo_20260828_local"
DENORM = RES / "noise_axis_denormalized_transfer_control_20260902_hpc"
CONF = RES / "noise_axis_391_global_card_confirmation_20260901_local"
TOPO = ROOT / "data/camels_us/camels_attributes_v2.0/camels_topo.txt"
OUT = ROOT / "draft/papers/29_transferable_filter_noise/figures"
DATA = OUT / "figure_data"

M1C0_RHO_SLZ = 0.0200            # m1_c0 equivalent ratio (results doc 2026-08-27 §三)
M10_RHO_SLZ = 0.0200 * 10 ** 0.5  # old grid upper bound m=10 ⇔ ρ≈0.0633 (m multiplies variance)

# Okabe–Ito, colour-blind safe
C = {"open": "#999999", "m1c0": "#0072B2", "own": "#E69F00", "card": "#009E73",
     "card2": "#56B4E9", "oracle": "#CC79A7", "abs": "#D55E00", "ratio": "#009E73"}

plt.rcParams.update({
    "font.size": 8, "axes.titlesize": 9, "axes.labelsize": 8, "legend.fontsize": 7,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "figure.dpi": 120, "savefig.dpi": 300,
    "axes.spines.top": False, "axes.spines.right": False, "pdf.fonttype": 42,
})
CM = 1 / 2.54
CHECKS: list[tuple[str, float, float, bool]] = []


def check(name: str, got: float, registered: float, tol: float = 5e-5) -> None:
    """Assert a recomputed quantity equals its registered value; keep a receipt row."""
    ok = abs(got - registered) <= tol
    CHECKS.append((name, got, registered, ok))
    if not ok:
        raise AssertionError(f"{name}: recomputed {got!r} != registered {registered!r}")


def loo_select(gain: pd.DataFrame, receivers: list[str]) -> dict[str, str]:
    """Frozen leave-one-out rule: receiver i takes the donor j≠i whose median gain over k∉{i,j} is
    largest (ties → smaller id). `gain` is donor × receiver."""
    chosen = {}
    for i in receivers:
        best = None
        for j in receivers:
            if j == i:
                continue
            g = np.median([gain.loc[j, k] for k in receivers if k not in (i, j)])
            if best is None or g > best[0] or (g == best[0] and j < best[1]):
                best = (g, j)
        chosen[i] = best[1]
    return chosen


def save(fig: plt.Figure, stem: str) -> None:
    fig.savefig(OUT / f"{stem}.png", bbox_inches="tight")
    fig.savefig(OUT / f"{stem}.pdf", bbox_inches="tight")
    plt.close(fig)


def annotate_median(ax, x: float, med: float, text: str, dy: float = 0.012, color: str = "k") -> None:
    ax.text(x, med + dy, text, ha="center", va="bottom", fontsize=6.5, color=color)


# --------------------------------------------------------------------------------------------
# load frozen artefacts
# --------------------------------------------------------------------------------------------
def load() -> dict:
    d = {}
    d["base"] = pd.read_csv(STEP2 / "baselines_per_basin.csv", dtype={"basin_id": str}).set_index("basin_id")
    d["eval"] = pd.read_csv(STEP2 / "evaluation_per_basin.csv", dtype={"basin_id": str}).set_index("basin_id")
    d["tp"] = pd.read_csv(LOO / "transfer_per_basin.csv", dtype={"basin_id": str, "e2_donor": str,
                                                                    "oracle_donor": str}).set_index("basin_id")
    runs = {}
    for f in sorted((LOO / "matrix").glob("*.json")):
        j = json.load(open(f))
        runs[j["basin_id"]] = j["runs"]
    d["runs"] = runs
    d["recv"] = pd.read_csv(DENORM / "receivers_per_basin.csv", dtype={"basin_id": str}).set_index("basin_id")
    d["absm"] = pd.read_csv(DENORM / "absolute_matrix_nse_holdout.csv", dtype={"donor": str}).set_index("donor")
    d["conf"] = pd.read_csv(CONF / "confirmation_per_basin.csv", dtype={"basin_id": str}).set_index("basin_id")
    d["cells"] = pd.read_csv(CONF / "extra_cells_per_basin_policy391.csv", dtype={"basin_id": str}).set_index("basin_id")
    topo = pd.read_csv(TOPO, sep=";", dtype={"gauge_id": str}).set_index("gauge_id")
    d["topo"] = topo
    return d


# --------------------------------------------------------------------------------------------
# derived 52-basin arms (replayed from frozen artefacts, asserted against registered values)
# --------------------------------------------------------------------------------------------
def arms_52(d: dict) -> pd.DataFrame:
    base, tp, runs = d["base"], d["tp"], d["runs"]
    basins = sorted(runs)
    assert len(basins) == 52
    # prospective (no-leak) selection: criterion = training-segment gain, everything else frozen
    gain_train = pd.DataFrame({k: {j: (runs[k][j]["nse_train_after_burnin"] - base.loc[k, "m1c0_nse_train_after_burnin"])
                                   if j != k else np.nan for j in basins} for k in basins})   # donor × receiver, no diagonal
    donor_p = loo_select(gain_train, basins)
    out = pd.DataFrame(index=basins)
    out["m1c0"] = base.loc[basins, "m1c0_nse_holdout"]
    out["own"] = tp.loc[basins, "own_learned_nse"]
    out["card_retro"] = tp.loc[basins, "e2_nse"]
    out["card_retro_donor"] = tp.loc[basins, "e2_donor"]
    out["card_prosp_donor"] = [donor_p[i] for i in basins]
    out["card_prosp"] = [runs[i][donor_p[i]]["nse_holdout"] for i in basins]
    out["card_median"] = tp.loc[basins, "e1_nse"]
    out["oracle"] = tp.loc[basins, "oracle_nse"]
    for arm in ("own", "card_retro", "card_prosp", "card_median", "oracle"):
        out[f"gain_{arm}"] = out[arm] - out["m1c0"]

    # receipts (results doc 2026-08-27 §二, 2026-08-28 §一/§二, addendum 01 §三)
    check("52 m1_c0 holdout median NSE", out.m1c0.median(), 0.7027)
    check("52 own-learned holdout median NSE", out.own.median(), 0.7505)
    check("52 own gain median", out.gain_own.median(), 0.02131)
    check("52 own improved count", (out.gain_own > 0).sum(), 43, tol=0)
    check("52 card(retro) median NSE", out.card_retro.median(), 0.7733)
    check("52 card(retro) gain median", out.gain_card_retro.median(), 0.04093)
    check("52 card(retro) improved", (out.gain_card_retro > 0).sum(), 38, tol=0)
    check("52 card(median profile) gain median", out.gain_card_median.median(), 0.0316)
    check("52 card(median profile) improved", (out.gain_card_median > 0).sum(), 43, tol=0)
    check("52 ORACLE gain median", out.gain_oracle.median(), 0.05164)
    check("52 card(prospective) gain median", out.gain_card_prosp.median(), 0.03757)
    check("52 card(prospective) improved", (out.gain_card_prosp > 0).sum(), 39, tol=0)
    check("52 prospective donor 04233000 count", (out.card_prosp_donor == "04233000").sum(), 50, tol=0)
    check("52 own beats card(prosp)", (out.own > out.card_prosp).sum(), 24, tol=0)
    check("52 card(prosp) beats own", (out.card_prosp > out.own).sum(), 28, tol=0)
    # registered "25 : 27" reads card-wins : own-wins (addendum 01 §三/§四 fixes the direction via "28:24 leans to borrowing")
    check("52 card(retro) beats own", (out.card_retro > out.own).sum(), 25, tol=0)
    check("52 own beats card(retro)", (out.own > out.card_retro).sum(), 27, tol=0)
    return out


def absolute_arms_52(d: dict, arms: pd.DataFrame) -> pd.DataFrame:
    """Denormalised control: same frozen (retrospective) selection rule applied to the absolute matrix."""
    recv, absm = d["recv"], d["absm"]
    basins = list(arms.index)
    # frozen settlement convention (noise_axis_denormalized_transfer.settle): the baseline is the cluster-side
    # m1_c0 hold-out NSE carried in receivers_per_basin.csv, which differs from the registry value by up to
    # ~4e-4 on one basin (cross-platform floating point in the state-proportional noise path)
    m1 = recv.loc[basins, "m1c0_nse_holdout"]
    gain_abs = absm.loc[basins, basins].sub(m1, axis="columns").astype(float)   # donor × receiver holdout gain
    for b in basins:
        gain_abs.loc[b, b] = np.nan
    donor_a = loo_select(gain_abs, basins)
    out = pd.DataFrame(index=basins)
    out["abs_e1"] = recv.loc[basins, "absolute_e1_nse"]
    out["abs_e2"] = [absm.loc[donor_a[i], i] for i in basins]
    out["abs_e2_donor"] = [donor_a[i] for i in basins]
    out["abs_oracle"] = [max(absm.loc[j, i] for j in basins if j != i) for i in basins]
    for arm in ("abs_e1", "abs_e2", "abs_oracle"):
        out[f"gain_{arm}"] = out[arm] - m1
    # donor "net harmful" = median gain it delivers to the other 51 receivers < 0
    ratio_gain = pd.DataFrame({k: {j: (d["runs"][k][j]["nse_holdout"] - m1[k]) if j != k else np.nan
                                   for j in basins} for k in basins})
    harm_ratio = sum(np.median([ratio_gain.loc[j, k] for k in basins if k != j]) < 0 for j in basins)
    harm_abs = sum(np.median([gain_abs.loc[j, k] for k in basins if k != j]) < 0 for j in basins)
    out.attrs["harmful_donors_ratio"] = int(harm_ratio)
    out.attrs["harmful_donors_abs"] = int(harm_abs)

    # receipts: exact settled values from the frozen summary.json (results doc 2026-09-02 rounds them)
    S = json.load(open(DENORM / "summary.json"))
    check("52 absolute e2 gain median", out.gain_abs_e2.median(), S["absolute_e2_gain_median"], tol=1e-12)
    check("52 absolute e2 improved", (out.gain_abs_e2 > 0).sum(), S["absolute_e2_wins"], tol=0)
    check("52 absolute e1 gain median", out.gain_abs_e1.median(), S["absolute_e1_gain_median"], tol=1e-12)
    check("52 absolute e1 improved", (out.gain_abs_e1 > 0).sum(), S["absolute_e1_wins"], tol=0)
    check("52 absolute ORACLE gain median", out.gain_abs_oracle.median(), S["absolute_oracle_gain_median"], tol=1e-12)
    check("52 absolute donor 14306340 count", (out.abs_e2_donor == "14306340").sum(), 51, tol=0)
    check("52 absolute e2 worst", out.gain_abs_e2.min(), -3.42, tol=5e-3)
    check("52 harmful donors (ratio)", harm_ratio, 23, tol=0)
    check("52 harmful donors (absolute)", harm_abs, S["absolute_harmful_donors"], tol=0)
    check("52 cluster-vs-registry m1_c0 max |diff|", float((m1 - arms["m1c0"]).abs().max()), 4.33e-4, tol=1e-5)
    return out


def arms_391(d: dict) -> pd.DataFrame:
    conf, cells = d["conf"], d["cells"]
    out = pd.DataFrame(index=conf.index)
    out["open"] = conf["open_loop_nse_score"]
    out["m1c0"] = conf["m1_c0_nse_score"]
    out["card_median"] = conf["card_median52_nse_score"]
    out["card_sel"] = conf["card_selected_noleak_nse_score"]
    out["card_frozen"] = conf["card_selected_frozen_nse_score"]
    cellcols = [c for c in cells.columns if c.endswith("_nse_score")]
    out["best_cell"] = cells.loc[out.index, cellcols].max(axis=1)      # per-basin best hand-tuned cell (oracle-like)
    for arm in ("card_median", "card_sel", "card_frozen"):
        out[f"gain_{arm}"] = out[arm] - out["m1c0"]
        out[f"gain_{arm}_vs_best_cell"] = out[arm] - out["best_cell"]
    out["gain_m1c0_vs_open"] = out["m1c0"] - out["open"]

    # receipts (results docs 2026-09-01 §一/§二 and addendum 01 §三)
    check("391 open-loop median NSE", out.open.median(), 0.5829)
    check("391 m1_c0 median NSE", out.m1c0.median(), 0.7019)
    check("391 median-card median NSE", out.card_median.median(), 0.7467)
    check("391 selected-card median NSE", out.card_sel.median(), 0.7495)
    check("391 frozen-card median NSE", out.card_frozen.median(), 0.7384)
    check("391 median-card gain median", out.gain_card_median.median(), 0.0334)
    check("391 median-card improved", (out.gain_card_median > 0).sum(), 320, tol=0)
    check("391 selected-card gain median", out.gain_card_sel.median(), 0.0361)
    check("391 selected-card improved", (out.gain_card_sel > 0).sum(), 302, tol=0)
    check("391 frozen-card gain median", out.gain_card_frozen.median(), 0.0243)
    check("391 m1_c0 vs open-loop gain median", out.gain_m1c0_vs_open.median(), 0.0873)
    check("391 selected-card vs best cell median", out.gain_card_sel_vs_best_cell.median(), 0.0140)
    check("391 selected-card vs best cell improved", (out.gain_card_sel_vs_best_cell > 0).sum(), 255, tol=0)
    check("391 median-card vs best cell median", out.gain_card_median_vs_best_cell.median(), 0.0110)
    check("391 median-card vs best cell improved", (out.gain_card_median_vs_best_cell > 0).sum(), 259, tol=0)
    return out


# --------------------------------------------------------------------------------------------
# figures
# --------------------------------------------------------------------------------------------
def ecdf(ax, v, **kw):
    v = np.sort(np.asarray(v, dtype=float))
    ax.step(v, np.arange(1, len(v) + 1) / len(v), where="post", **kw)


def fig1_ladder(a52: pd.DataFrame, a391: pd.DataFrame) -> None:
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(17.8 * CM, 8.0 * CM))

    def ladder(ax, frame, arms, labels, colors, hatch_last=False, title=""):
        data = [frame[c].to_numpy() for c in arms]
        pos = np.arange(len(arms))
        bp = ax.boxplot(data, positions=pos, widths=0.55, showfliers=False, patch_artist=True,
                        medianprops={"color": "k", "lw": 1.2}, whiskerprops={"lw": 0.8}, capprops={"lw": 0.8})
        for patch, col in zip(bp["boxes"], colors):
            patch.set_facecolor(col); patch.set_alpha(0.45); patch.set_edgecolor(col)
        if hatch_last:
            bp["boxes"][-1].set_hatch("////"); bp["boxes"][-1].set_facecolor("white")
        meds = [np.median(x) for x in data]
        ax.plot(pos, meds, color="k", lw=0.8, ls=":", zorder=3)
        for p_, m in zip(pos, meds):
            ax.text(p_ + 0.30, m, f"{m:.3f}", ha="left", va="center", fontsize=6.5,
                    bbox={"boxstyle": "round,pad=0.15", "fc": "white", "ec": "none", "alpha": 0.8})
        ax.set_xticks(pos); ax.set_xticklabels(labels, fontsize=6.5)
        ax.set_ylabel("NSE"); ax.set_title(title, loc="left", fontsize=8)
        ax.set_ylim(0.1, 1.02); ax.set_xlim(-0.6, len(arms) - 0.3)

    ladder(ax1, a52, ["m1c0", "own", "card_prosp", "oracle"],
           ["hand-set\nm1_c0", "learned\nper basin", "borrowed\nglobal card", "oracle\n(hindsight)"],
           [C["m1c0"], C["own"], C["card"], C["oracle"]], hatch_last=True,
           title="(a) 52 development basins, 420-day hold-out")
    ladder(ax2, a391, ["open", "m1c0", "card_median", "card_sel"],
           ["open loop", "hand-set\nm1_c0", "median card\n(no validation)", "selected card\n(prospective)"],
           [C["open"], C["m1c0"], C["card2"], C["card"]],
           title="(b) 391 held-out basins, one prospective run")
    ax1.text(0.02, 0.02, "borrowed card = prospective (no-leak) selection;\noracle = best donor in hindsight, a bound not a result",
             transform=ax1.transAxes, fontsize=5.8, va="bottom")
    ax2.text(0.02, 0.02, "cards learned on the 52 development basins,\napplied unchanged", transform=ax2.transAxes, fontsize=5.8, va="bottom")
    fig.tight_layout(w_pad=2.5)
    save(fig, "fig1_ladder")
    pd.concat([a52.add_prefix("dev52_").describe().T.assign(panel="a"),
               a391.add_prefix("held391_").describe().T.assign(panel="b")]).to_csv(DATA / "fig1_ladder_summary.csv")
    a52.to_csv(DATA / "fig1a_dev52_per_basin.csv"); a391.to_csv(DATA / "fig1b_held391_per_basin.csv")


def fig2_mechanism(a52: pd.DataFrame, ab: pd.DataFrame) -> None:
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(17.8 * CM, 8.0 * CM), gridspec_kw={"width_ratios": [3, 4]})
    groups = ["median card\n(e1)", "selected card\n(e2)", "oracle\n(hindsight bound)"]
    ratio = [a52.gain_card_median.median(), a52.gain_card_retro.median(), a52.gain_oracle.median()]
    absol = [ab.gain_abs_e1.median(), ab.gain_abs_e2.median(), ab.gain_abs_oracle.median()]
    n_ratio = [(a52.gain_card_median > 0).sum(), (a52.gain_card_retro > 0).sum(), None]
    n_abs = [(ab.gain_abs_e1 > 0).sum(), (ab.gain_abs_e2 > 0).sum(), None]
    x = np.arange(3); w = 0.36
    b1 = ax1.bar(x - w / 2, ratio, w, color=C["ratio"], label="move the dimensionless ratio ρ")
    b2 = ax1.bar(x + w / 2, absol, w, color=C["abs"], label="move the absolute noise std")
    b1[2].set_hatch("////"); b2[2].set_hatch("////")
    for k, (xi, v, n) in enumerate(zip(x - w / 2, ratio, n_ratio)):
        ax1.text(xi, v + (0.0045 if k == 2 else 0.0008), f"{v:+.4f}", ha="center", va="bottom", fontsize=5.8, color=C["ratio"] if k == 2 else "k")
        if n is not None:
            ax1.text(xi, 0.0012, f"{n}/52", ha="center", va="bottom", fontsize=5.5, color="white")
    for k, (xi, v, n) in enumerate(zip(x + w / 2, absol, n_abs)):
        ax1.text(xi, v + 0.0008, f"{v:+.4f}", ha="center", va="bottom", fontsize=5.8, color=C["abs"] if k == 2 else "k")
        if n is not None:
            ax1.text(xi, 0.0012, f"{n}/52", ha="center", va="bottom", fontsize=5.5, color="white" if v > 0.008 else "k")
    ax1.set_xticks(x); ax1.set_xticklabels(groups, fontsize=6.5)
    ax1.set_ylabel("median paired NSE gain vs m1_c0")
    ax1.set_ylim(0, 0.082); ax1.axhline(0, color="k", lw=0.6)
    ax1.legend(loc="upper left", frameon=False, fontsize=6)
    ax1.set_title("(a) same 52 learned settings, two ways to move them", loc="left", fontsize=8)
    ax1.text(0.52, 0.62, f"net-harmful donors:\n{ab.attrs['harmful_donors_ratio']}/52 (ratio) → {ab.attrs['harmful_donors_abs']}/52 (absolute)",
             transform=ax1.transAxes, ha="center", va="bottom", fontsize=6)

    ecdf(ax2, a52.gain_card_retro, color=C["ratio"], lw=1.5, label="ratio: selected card (e2)")
    ecdf(ax2, ab.gain_abs_e2, color=C["abs"], lw=1.5, label="absolute: selected card (e2)")
    ecdf(ax2, a52.gain_oracle, color=C["oracle"], lw=1.0, ls="--", label="ratio: oracle")
    ecdf(ax2, ab.gain_abs_oracle, color=C["oracle"], lw=1.0, ls=":", label="absolute: oracle")
    ax2.axvline(0, color="k", lw=0.6)
    ax2.set_xlim(-0.5, 0.45); ax2.set_ylim(0, 1.02)
    ax2.set_xlabel("paired NSE gain vs m1_c0 (hold-out)"); ax2.set_ylabel("fraction of basins ≤ x")
    ax2.set_title("(b) per-basin gains: selection collapses, the oracle does not", loc="left", fontsize=8)
    ax2.legend(loc="lower right", frameon=False, fontsize=6)
    n_off = int((ab.gain_abs_e2 < -0.5).sum())
    ax2.text(0.02, 0.96, f"{n_off} absolute-e2 basin(s) below −0.5, off axis\n(worst {ab.gain_abs_e2.min():+.2f}, {ab.gain_abs_e2.idxmin()})",
             transform=ax2.transAxes, fontsize=5.8, va="top", color=C["abs"])
    fig.tight_layout(w_pad=2.5)
    save(fig, "fig2_normalization_mechanism")
    pd.DataFrame({"arm": ["e1", "e2", "oracle"], "ratio_gain_median": ratio, "absolute_gain_median": absol,
                  "ratio_improved": n_ratio, "absolute_improved": n_abs}).to_csv(DATA / "fig2_mechanism_summary.csv", index=False)
    ab.join(a52[["gain_card_median", "gain_card_retro", "gain_oracle"]]).to_csv(DATA / "fig2_per_basin.csv")


def fig3_confirmation(a391: pd.DataFrame) -> None:
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(17.8 * CM, 7.2 * CM))
    for ax, suffix, xlabel, title in (
            (ax1, "", "paired NSE gain vs m1_c0 (best single cell on the 391)", "(a) vs the best single hand-set cell"),
            (ax2, "_vs_best_cell", "paired NSE gain vs each basin's best cell (hindsight)", "(b) vs a per-basin hindsight choice among five cells")):
        s_ = a391[f"gain_card_sel{suffix}"]; m_ = a391[f"gain_card_median{suffix}"]
        ecdf(ax, s_, color=C["card"], lw=1.5, label=f"selected card: median {s_.median():+.4f}, {(s_ > 0).sum()}/391 > 0")
        ecdf(ax, m_, color=C["card2"], lw=1.5, label=f"median card: median {m_.median():+.4f}, {(m_ > 0).sum()}/391 > 0")
        ax.axvline(0, color="k", lw=0.6)
        ax.set_xlim(-0.25, 0.35); ax.set_ylim(0, 1.02)
        ax.set_xlabel(xlabel, fontsize=7); ax.set_ylabel("fraction of basins ≤ x")
        ax.set_title(title, loc="left", fontsize=8); ax.legend(loc="lower right", frameon=False, fontsize=6)
    ax1.axvline(0.0376, color=C["card"], lw=0.8, ls="--")
    ax1.text(0.0376 + 0.008, 0.30, "development-set estimate\n(52 basins, no-leak): +0.0376", fontsize=5.8, color=C["card"], va="center")
    fig.tight_layout(w_pad=2.5)
    save(fig, "fig3_391_confirmation")
    a391.to_csv(DATA / "fig3_held391_per_basin.csv")
    q = a391[["gain_card_sel", "gain_card_median", "gain_card_sel_vs_best_cell", "gain_card_median_vs_best_cell"]]
    q.quantile([0.05, 0.25, 0.5, 0.75, 0.95]).to_csv(DATA / "fig3_quantiles.csv")


def fig4_structure(d: dict) -> None:
    ev = d["eval"]
    groups = ["SNOWPACK", "MELTWATER", "SM", "SUZ", "SLZ", "ROUTING"]
    shares = ev[[f"share_{g}" for g in groups]]
    order = shares["share_SLZ"].sort_values(ascending=False).index
    rho_slz = ev.loc[order, "rho_SLZ"]; rho_sm = ev.loc[order, "rho_SM"]
    mult = rho_slz / M1C0_RHO_SLZ
    slz_dominant = (shares.idxmax(axis=1) == "share_SLZ").sum()
    sm_off = (ev["rho_SM"] <= 1e-4 * (1 + 1e-9)).sum()
    n_above_m1 = (ev["rho_SLZ"] > M1C0_RHO_SLZ).sum(); n_above_m10 = (ev["rho_SLZ"] > M10_RHO_SLZ).sum()

    # receipts (results doc 2026-08-27 §三)
    check("52 share_SLZ median", shares["share_SLZ"].median(), 0.946, tol=5e-4)
    check("52 SLZ-dominant basins", slz_dominant, 42, tol=0)
    check("52 SM switched off", sm_off, 30, tol=0)
    check("52 rho_SLZ median", ev["rho_SLZ"].median(), 0.0508, tol=5e-5)
    check("52 rho_SLZ / m1_c0-equivalent median", mult.median(), 2.54, tol=5e-3)
    check("52 basins above m1_c0 equivalent", n_above_m1, 37, tol=0)
    check("52 basins above m=10 bound", n_above_m10, 22, tol=0)
    check("52 rho_SLZ p10", ev["rho_SLZ"].quantile(0.10), 0.0012, tol=5e-5)
    check("52 rho_SLZ p90", ev["rho_SLZ"].quantile(0.90), 0.148, tol=5e-4)

    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(17.8 * CM, 7.4 * CM), gridspec_kw={"width_ratios": [5, 3.4, 2.8]})
    cols = ["#56B4E9", "#0072B2", "#E69F00", "#F0E442", "#009E73", "#CC79A7"]
    bottom = np.zeros(len(order))
    for g, col in zip(groups, cols):
        v = shares.loc[order, f"share_{g}"].to_numpy()
        ax1.bar(np.arange(len(order)), v, bottom=bottom, color=col, width=1.0, label=g, lw=0)
        bottom += v
    ax1.set_xlim(-0.5, len(order) - 0.5); ax1.set_ylim(0, 1)
    ax1.set_xlabel("52 basins, sorted by SLZ share"); ax1.set_ylabel("share of learned noise variance")
    ax1.set_title(f"(a) where the learned noise sits\nSLZ dominant in {slz_dominant}/52", loc="left", fontsize=8)
    ax1.legend(ncol=3, loc="lower center", bbox_to_anchor=(0.5, 1.18), frameon=False, fontsize=6, columnspacing=1.0)
    ax1.set_xticks([])

    x = np.arange(len(order))
    ax2.scatter(x, mult, s=9, color=C["own"], zorder=3)
    ax2.set_yscale("log"); ax2.set_ylim(0.03, 80); ax2.set_xticks([]); ax2.set_xlim(-1, len(order))
    for y, txt, col, ls in ((1.0, "m1_c0 equivalent ×1", C["m1c0"], "--"),
                            (M10_RHO_SLZ / M1C0_RHO_SLZ, "old grid ceiling ×3.16", "k", ":"),
                            (mult.median(), f"median ×{mult.median():.2f}", C["own"], "-")):
        ax2.axhline(y, color=col, lw=0.8, ls=ls)
        ax2.text(-0.5, y, txt, ha="left", va="bottom", fontsize=5.5, color=col,
                 bbox={"boxstyle": "round,pad=0.1", "fc": "white", "ec": "none", "alpha": 0.85})
    ax2.set_xlabel("same basin order"); ax2.set_ylabel("learned ρ_SLZ / m1_c0 equivalent")
    ax2.set_title(f"(b) magnitude: {n_above_m1}/52 above m1_c0,\n{n_above_m10}/52 above the old ceiling", loc="left", fontsize=8)

    ax3.scatter(x, rho_sm, s=9, color=cols[2], zorder=3)
    ax3.set_yscale("log"); ax3.set_ylim(5e-5, 2); ax3.set_xticks([]); ax3.set_xlim(-1, len(order))
    ax3.axhline(1e-4, color="k", lw=0.8, ls=":")
    ax3.text(len(order) - 0.5, 1.15e-4, "search floor 1e-4 = switched off", ha="right", va="bottom", fontsize=5.5,
             bbox={"boxstyle": "round,pad=0.1", "fc": "white", "ec": "none", "alpha": 0.85})
    ax3.set_xlabel("same basin order"); ax3.set_ylabel("learned ρ_SM")
    ax3.set_title(f"(c) soil-moisture noise\nswitched off in {sm_off}/52", loc="left", fontsize=8, pad=8)
    fig.tight_layout(w_pad=2.6)
    save(fig, "fig4_noise_structure")
    out = ev.loc[order, [f"rho_{g}" for g in groups] + [f"share_{g}" for g in groups]].copy()
    out["rho_SLZ_over_m1c0"] = mult; out["sm_switched_off"] = (out["rho_SM"] <= 1e-4 * (1 + 1e-9))
    out.to_csv(DATA / "fig4_noise_structure_per_basin.csv")


def fig5_attribute(d: dict) -> None:
    ev, topo = d["eval"], d["topo"]
    share = ev["share_SLZ"]; slope = topo.loc[share.index, "slope_mean"].astype(float)
    # scipy's p is t-based; the registered p (5.6e-11) is a normal approximation — neither is drawn, only rho
    rho, _p_t = spearmanr(share.to_numpy(), slope.to_numpy())
    check("52 Spearman(share_SLZ, slope_mean)", rho, -0.680, tol=5e-4)
    groups = ["SNOWPACK", "MELTWATER", "SM", "SUZ", "SLZ", "ROUTING"]
    dominant = ev[[f"share_{g}" for g in groups]].idxmax(axis=1).str.replace("share_", "")
    is_slz = dominant == "SLZ"
    minority = dominant[~is_slz].value_counts()
    fig, ax = plt.subplots(figsize=(8.4 * CM, 7.0 * CM))
    ax.scatter(slope[is_slz], share[is_slz], s=14, color=C["card"], label=f"SLZ-dominant ({is_slz.sum()})", zorder=3)
    ax.scatter(slope[~is_slz], share[~is_slz], s=18, color=C["abs"], marker="^", zorder=3,
               label=f"other group dominant ({(~is_slz).sum()})")
    ax.set_xscale("log"); ax.set_xlabel("mean slope (m km$^{-1}$, CAMELS slope_mean)"); ax.set_ylabel("SLZ share of learned noise variance")
    ax.set_ylim(-0.03, 1.05)
    ax.legend(loc="center left", bbox_to_anchor=(0.0, 0.44), frameon=False, fontsize=5.8)
    ax.text(0.02, 0.30, "other groups: " + ", ".join(f"{g} {n}" for g, n in minority.items()), transform=ax.transAxes, fontsize=5.8, color=C["abs"])
    ax.text(0.02, 0.22, f"Spearman ρ = {rho:.2f}, n = 52 (exploratory)", transform=ax.transAxes, fontsize=6)
    ax.set_title("Learned SLZ share vs terrain slope", loc="left", fontsize=8)
    fig.tight_layout()
    save(fig, "fig5_share_slz_vs_slope")
    pd.DataFrame({"share_SLZ": share, "slope_mean": slope, "dominant_group": dominant}).to_csv(DATA / "fig5_share_slz_vs_slope.csv")


def write_manifest_and_receipt() -> None:
    lines = []
    for f in sorted(OUT.rglob("*")):
        if f.is_file() and f.name != "MANIFEST.sha256":
            lines.append(f"{hashlib.sha256(f.read_bytes()).hexdigest()}  {f.relative_to(OUT).as_posix()}")
    (OUT / "MANIFEST.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    receipt = pd.DataFrame(CHECKS, columns=["quantity", "recomputed", "registered", "ok"])
    receipt.to_csv(DATA / "verification_receipt.csv", index=False)
    print(receipt.to_string(index=False))
    print(f"\n{len(receipt)} checks, all passed: {receipt.ok.all()}")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True); DATA.mkdir(parents=True, exist_ok=True)
    d = load()
    a52 = arms_52(d)
    ab = absolute_arms_52(d, a52)
    a391 = arms_391(d)
    fig1_ladder(a52, a391)
    fig2_mechanism(a52, ab)
    fig3_confirmation(a391)
    fig4_structure(d)
    fig5_attribute(d)
    write_manifest_and_receipt()


if __name__ == "__main__":
    main()
