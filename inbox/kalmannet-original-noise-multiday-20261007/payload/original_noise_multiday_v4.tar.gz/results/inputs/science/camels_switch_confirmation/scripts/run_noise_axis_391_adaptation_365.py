"""Run the post-hoc 365-day adaptation sensitivity on the exposed 391 basins.

Phases, in order::

    python src/camels_switch_confirmation/scripts/run_noise_axis_391_adaptation_365.py preflight
    python src/camels_switch_confirmation/scripts/run_noise_axis_391_adaptation_365.py run --workers 6
    python src/camels_switch_confirmation/scripts/run_noise_axis_391_adaptation_365.py summarize

The prospective 1,735-day artifacts are read-only inputs.  Every new artifact
is written below the independent 365-day result root.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import numpy as np
import pandas as pd

_SRC = Path(__file__).resolve().parents[2]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation import noise_axis_391_adaptation_365 as sensitivity  # noqa: E402
from camels_switch_confirmation import noise_axis_391_confirmation as original  # noqa: E402


BASINS_DIR = sensitivity.OUTPUT_ROOT / "basins"
CONTRACT_PATH = sensitivity.OUTPUT_ROOT / "run_contract.json"
PREFLIGHT_PATH = sensitivity.OUTPUT_ROOT / "preflight.json"
PER_BASIN_PATH = sensitivity.OUTPUT_ROOT / "adaptation_365_per_basin.csv"
SUMMARY_PATH = sensitivity.OUTPUT_ROOT / "summary.json"
COMPATIBILITY_BASINS = ("01022500", "01031500")
COMPATIBILITY_TOLERANCE = 1e-8


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _contract_files() -> dict[str, Path]:
    return {
        "protocol": sensitivity.PROTOCOL,
        "sensitivity_module": Path(sensitivity.__file__).resolve(),
        "runner": Path(__file__).resolve(),
        "original_confirmation_module": Path(original.__file__).resolve(),
        "frozen_basin_list": sensitivity.ORIGINAL_FROZEN_LIST,
        "original_main_table": sensitivity.ORIGINAL_MAIN_TABLE,
        "original_extra_cells_table": sensitivity.ORIGINAL_EXTRA_TABLE,
        "original_extra_cells_policy391_table": sensitivity.ORIGINAL_EXTRA_POLICY_TABLE,
        "frozen_card_registry": original.STEP2_EVALUATION_CSV,
    }


def _file_hashes() -> dict[str, dict[str, str]]:
    hashes: dict[str, dict[str, str]] = {}
    for label, path in _contract_files().items():
        if not path.is_file():
            raise FileNotFoundError(f"contract input missing: {label}: {path}")
        hashes[label] = {"path": str(path), "sha256": _sha256(path)}
    return hashes


def _load_frozen_basins() -> list[str]:
    frame = pd.read_csv(sensitivity.ORIGINAL_FROZEN_LIST, dtype={"basin_id": str})
    if "included" not in frame:
        raise ValueError("original frozen list lacks the included column")
    included = frame["included"]
    if included.dtype != bool:
        included = included.astype(str).str.lower().eq("true")
    basins = sorted(frame.loc[included, "basin_id"].str.zfill(8).tolist())
    if len(basins) != 391 or len(set(basins)) != 391:
        raise ValueError(f"expected 391 unique frozen basins, got {len(basins)}/{len(set(basins))}")
    return basins


def _worker_run(basin: str) -> dict:
    out_path = BASINS_DIR / f"{basin}.json"
    if out_path.exists():
        return {"basin_id": basin, "skipped": True}
    record = sensitivity.run_basin_all_arms(basin, sensitivity.load_cards())
    tmp = out_path.with_suffix(".tmp")
    tmp.write_text(json.dumps(record, indent=1), encoding="utf-8")
    tmp.replace(out_path)
    return {
        "basin_id": basin,
        "skipped": False,
        "status": record["status"],
    }


def _compatibility_check() -> dict[str, object]:
    """Replay two old basins through the wrapper under the old date contract."""
    old_main = pd.read_csv(sensitivity.ORIGINAL_MAIN_TABLE, dtype={"basin_id": str})
    old_extra = pd.read_csv(sensitivity.ORIGINAL_EXTRA_TABLE, dtype={"basin_id": str})
    old_main["basin_id"] = old_main["basin_id"].str.zfill(8)
    old_extra["basin_id"] = old_extra["basin_id"].str.zfill(8)
    old_main = old_main.set_index("basin_id")
    old_extra = old_extra.set_index("basin_id")
    rows = []
    worst = 0.0
    for basin in COMPATIBILITY_BASINS:
        record = sensitivity.run_basin_all_arms(
            basin,
            sensitivity.load_cards(),
            load_start=original.HOLDOUT_START,
            load_days=original.HOLDOUT_DAYS,
            adaptation_days=original.INIT_DAYS,
        )
        if record["status"] != "success":
            raise RuntimeError(f"compatibility replay task failed for {basin}: {record.get('error', '')}")
        old_record = json.loads(
            (sensitivity.ORIGINAL_OUTPUT_ROOT / "basins" / f"{basin}.json").read_text(
                encoding="utf-8"
            )
        )
        amplitude_difference = float(
            np.max(
                np.abs(
                    np.asarray(record["amplitudes"], dtype=float)
                    - np.asarray(old_record["amplitudes"], dtype=float)
                )
            )
        )
        arm_differences: dict[str, float] = {}
        for arm in sensitivity.ALL_ARMS:
            outcome = record["arms"].get(arm, {})
            if outcome.get("status") != "success":
                raise RuntimeError(f"compatibility replay arm failed for {basin}/{arm}")
            source = old_main if arm in original.ALL_ARMS else old_extra
            expected = float(source.loc[basin, f"{arm}_nse_score"])
            difference = abs(float(outcome["nse_score"]) - expected)
            arm_differences[arm] = difference
        core_differences = {
            arm: difference
            for arm, difference in arm_differences.items()
            if arm in original.ALL_ARMS
        }
        extra_differences = {
            arm: difference
            for arm, difference in arm_differences.items()
            if arm not in original.ALL_ARMS
        }
        basin_worst = max([amplitude_difference, *core_differences.values()])
        worst = max(worst, basin_worst)
        rows.append(
            {
                "basin_id": basin,
                "amplitude_worst_abs_diff": amplitude_difference,
                "core_arm_nse_abs_diff": core_differences,
                "extra_fixed_arm_cross_platform_abs_diff_report_only": extra_differences,
                "core_worst_abs_diff": basin_worst,
            }
        )
    return {
        "basins": list(COMPATIBILITY_BASINS),
        "rows": rows,
        "tolerance": COMPATIBILITY_TOLERANCE,
        "core_worst_abs_diff": worst,
        "passed": bool(worst <= COMPATIBILITY_TOLERANCE),
    }


def phase_preflight() -> int:
    contract = sensitivity.validate_contract()
    basins = _load_frozen_basins()
    cards_new = sensitivity.load_cards()
    cards_old = original.load_cards()
    cards_identical = set(cards_new) == set(cards_old) and all(
        np.array_equal(cards_new[name], cards_old[name]) for name in cards_old
    )
    if not cards_identical:
        raise ValueError("365-day runner does not reuse the frozen cards exactly")

    original_p0 = original.p0_check(tolerance=COMPATIBILITY_TOLERANCE)
    compatibility = _compatibility_check()
    passed = bool(original_p0["passed"] and compatibility["passed"])
    sensitivity.OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    contract.update(
        {
            "decision_time": "2026-09-04_after_original_results_were_known",
            "only_changed_factor": "pre_score_receiver_history_days_1735_to_365",
            "frozen_basin_count": len(basins),
            "frozen_cards_identical": cards_identical,
            "compatibility_tolerance": COMPATIBILITY_TOLERANCE,
            "files": _file_hashes(),
        }
    )
    CONTRACT_PATH.write_text(json.dumps(contract, indent=1), encoding="utf-8")
    report = {
        "passed": passed,
        "original_development_window_p0": original_p0,
        "old_contract_wrapper_compatibility": compatibility,
    }
    PREFLIGHT_PATH.write_text(json.dumps(report, indent=1), encoding="utf-8")
    print(json.dumps(report, indent=1))
    return 0 if passed else 1


def _verify_preflight_and_hashes() -> None:
    if not PREFLIGHT_PATH.is_file() or not CONTRACT_PATH.is_file():
        raise FileNotFoundError("run requires a completed preflight phase")
    preflight = json.loads(PREFLIGHT_PATH.read_text(encoding="utf-8"))
    if preflight.get("passed") is not True:
        raise ValueError("preflight did not pass")
    contract = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))
    expected = contract.get("files", {})
    actual = _file_hashes()
    if actual != expected:
        raise ValueError("a frozen protocol, code, or input file changed after preflight")


def phase_run(workers: int) -> int:
    if workers < 1 or workers > 6:
        raise ValueError("workers must be between 1 and 6")
    _verify_preflight_and_hashes()
    basins = _load_frozen_basins()
    BASINS_DIR.mkdir(parents=True, exist_ok=True)
    pending = [basin for basin in basins if not (BASINS_DIR / f"{basin}.json").exists()]
    print(
        f"frozen basins={len(basins)} pending={len(pending)} workers={workers} "
        f"arms={len(sensitivity.ALL_ARMS)}",
        flush=True,
    )
    if not pending:
        return 0
    started = time.perf_counter()
    completed = 0
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for _ in pool.map(_worker_run, pending, chunksize=1):
            completed += 1
            if completed % 20 == 0 or completed == len(pending):
                elapsed = time.perf_counter() - started
                remaining = elapsed / completed * (len(pending) - completed)
                print(
                    f"  {completed}/{len(pending)} elapsed={elapsed / 60:.1f} min "
                    f"eta={remaining / 60:.1f} min",
                    flush=True,
                )
    print(f"run complete in {(time.perf_counter() - started) / 60:.1f} min", flush=True)
    return 0


def _describe(values: pd.Series | np.ndarray) -> dict[str, float | int]:
    series = pd.Series(values, dtype=float).replace([np.inf, -np.inf], np.nan).dropna()
    quantiles = series.quantile([0.05, 0.25, 0.5, 0.75, 0.95])
    return {
        "n": int(series.size),
        "mean": float(series.mean()),
        "q05": float(quantiles.loc[0.05]),
        "q25": float(quantiles.loc[0.25]),
        "median": float(quantiles.loc[0.5]),
        "q75": float(quantiles.loc[0.75]),
        "q95": float(quantiles.loc[0.95]),
        "n_positive": int((series > 0.0).sum()),
        "n_negative": int((series < 0.0).sum()),
        "n_zero": int((series == 0.0).sum()),
    }


def _records_to_table(basins: list[str]) -> tuple[pd.DataFrame, list[dict]]:
    rows: list[dict] = []
    failures: list[dict] = []
    for basin in basins:
        path = BASINS_DIR / f"{basin}.json"
        if not path.is_file():
            failures.append({"basin_id": basin, "scope": "record", "error": "missing"})
            continue
        record = json.loads(path.read_text(encoding="utf-8"))
        if record.get("status") != "success":
            failures.append(
                {"basin_id": basin, "scope": "task", "error": record.get("error", "")}
            )
            continue
        row: dict[str, object] = {
            "basin_id": basin,
            "sigma_obs": record["sigma_obs"],
        }
        for group_name, amplitude in zip(original.GROUP_NAMES, record["amplitudes"]):
            row[f"amplitude_{group_name}"] = amplitude
        for arm in sensitivity.ALL_ARMS:
            outcome = record.get("arms", {}).get(arm)
            if outcome is None:
                failures.append({"basin_id": basin, "scope": arm, "error": "missing"})
                continue
            if outcome.get("status") != "success":
                failures.append(
                    {"basin_id": basin, "scope": arm, "error": outcome.get("error", "")}
                )
                continue
            row[f"{arm}_nse_score"] = outcome["nse_score"]
            row[f"{arm}_nse_full_2191d"] = outcome["nse_full"]
        rows.append(row)
    table = pd.DataFrame(rows)
    if not table.empty:
        table = table.sort_values("basin_id")
    return table, failures


def _old_amplitude_table(basins: list[str]) -> pd.DataFrame:
    rows = []
    for basin in basins:
        record = json.loads(
            (sensitivity.ORIGINAL_OUTPUT_ROOT / "basins" / f"{basin}.json").read_text(
                encoding="utf-8"
            )
        )
        row = {"basin_id": basin}
        for group_name, amplitude in zip(original.GROUP_NAMES, record["amplitudes"]):
            row[f"amplitude_{group_name}_1735"] = amplitude
        rows.append(row)
    return pd.DataFrame(rows)


def phase_summarize() -> int:
    _verify_preflight_and_hashes()
    basins = _load_frozen_basins()
    table, failures = _records_to_table(basins)
    table.to_csv(PER_BASIN_PATH, index=False)
    required_score_columns = [f"{arm}_nse_score" for arm in sensitivity.ALL_ARMS]
    core_score_columns = [f"{arm}_nse_score" for arm in original.ALL_ARMS]
    complete_all_nine = table.dropna(
        subset=[column for column in required_score_columns if column in table]
    )
    complete_core = table.dropna(
        subset=[column for column in core_score_columns if column in table]
    )
    missing_columns = [column for column in required_score_columns if column not in table]
    if missing_columns:
        failures.append({"scope": "table", "error": f"missing columns: {missing_columns}"})

    summary: dict[str, object] = {
        "experiment_id": sensitivity.EXPERIMENT_ID,
        "analysis_status": "post_hoc_after_391_scores_were_exposed",
        "contract": sensitivity.validate_contract(),
        "n_frozen": len(basins),
        "n_records": int(len(table)),
        "n_complete_core_five_arms": int(len(complete_core)),
        "n_complete_all_nine_arms": int(len(complete_all_nine)),
        "n_failures": len(failures),
        "failures": failures,
        "arms": {},
        "comparisons": {},
        "change_from_1735_day_result": {},
        "gain_change_from_1735_day_result": {},
        "amplitude_change": {},
        "interpretation_boundary": (
            "The 1,735-day result remains the prospective confirmation. This is an "
            "outcome-aware sensitivity analysis and cannot be called a second confirmation."
        ),
    }
    if complete_core.empty:
        SUMMARY_PATH.write_text(json.dumps(summary, indent=1), encoding="utf-8")
        print(json.dumps(summary, indent=1))
        return 1

    for arm in sensitivity.ALL_ARMS:
        column = f"{arm}_nse_score"
        if column in table:
            summary["arms"][arm] = _describe(table[column])

    fixed_medians = {
        arm: float(table[f"{arm}_nse_score"].median()) for arm in sensitivity.FIXED_ARMS
        if f"{arm}_nse_score" in table
    }
    best_single_fixed_arm = max(fixed_medians, key=fixed_medians.get)
    summary["fixed_arm_median_nse"] = fixed_medians
    summary["best_single_fixed_arm_by_median_nse"] = best_single_fixed_arm
    best_per_basin_fixed = table[
        [f"{arm}_nse_score" for arm in sensitivity.FIXED_ARMS]
    ].max(axis=1)

    comparisons: dict[str, object] = summary["comparisons"]
    paired_m1_open = table.dropna(subset=["m1_c0_nse_score", "open_loop_nse_score"])
    comparisons["m1_c0_vs_open_loop"] = _describe(
        paired_m1_open["m1_c0_nse_score"] - paired_m1_open["open_loop_nse_score"]
    )
    for card in sensitivity.CARD_ARMS:
        paired_m1 = table.dropna(subset=[f"{card}_nse_score", "m1_c0_nse_score"])
        comparisons[f"{card}_vs_m1_c0"] = _describe(
            paired_m1[f"{card}_nse_score"] - paired_m1["m1_c0_nse_score"]
        )
        paired_best_single = table.dropna(
            subset=[f"{card}_nse_score", f"{best_single_fixed_arm}_nse_score"]
        )
        comparisons[f"{card}_vs_best_single_fixed[{best_single_fixed_arm}]"] = _describe(
            paired_best_single[f"{card}_nse_score"]
            - paired_best_single[f"{best_single_fixed_arm}_nse_score"]
        )
        oracle_frame = table[["basin_id", f"{card}_nse_score"]].copy()
        oracle_frame["best_per_basin_fixed"] = best_per_basin_fixed
        oracle_frame = oracle_frame.dropna(
            subset=[f"{card}_nse_score", "best_per_basin_fixed"]
        )
        comparisons[f"{card}_vs_per_basin_oracle_best_fixed"] = _describe(
            oracle_frame[f"{card}_nse_score"] - oracle_frame["best_per_basin_fixed"]
        )

    old = pd.read_csv(sensitivity.ORIGINAL_EXTRA_POLICY_TABLE, dtype={"basin_id": str})
    old["basin_id"] = old["basin_id"].str.zfill(8)
    old_columns = ["basin_id"] + [
        f"{arm}_nse_score" for arm in sensitivity.ALL_ARMS
    ]
    old = old[old_columns]
    paired = table.merge(old, on="basin_id", suffixes=("_365", "_1735"), validate="one_to_one")
    for arm in sensitivity.ALL_ARMS:
        summary["change_from_1735_day_result"][arm] = _describe(
            paired[f"{arm}_nse_score_365"] - paired[f"{arm}_nse_score_1735"]
        )
    for card in sensitivity.CARD_ARMS:
        gain_365 = paired[f"{card}_nse_score_365"] - paired["m1_c0_nse_score_365"]
        gain_1735 = paired[f"{card}_nse_score_1735"] - paired["m1_c0_nse_score_1735"]
        summary["gain_change_from_1735_day_result"][card] = _describe(gain_365 - gain_1735)

    amplitude_paired = table.merge(
        _old_amplitude_table(basins), on="basin_id", validate="one_to_one"
    )
    for group_name in original.GROUP_NAMES:
        new_values = amplitude_paired[f"amplitude_{group_name}"]
        old_values = amplitude_paired[f"amplitude_{group_name}_1735"]
        summary["amplitude_change"][group_name] = {
            "ratio_365_over_1735": _describe(new_values / old_values),
            "n_at_floor_365": int(np.isclose(new_values, original.AMPLITUDE_FLOOR_MM).sum()),
            "n_at_floor_1735": int(np.isclose(old_values, original.AMPLITUDE_FLOOR_MM).sum()),
        }

    SUMMARY_PATH.write_text(json.dumps(summary, indent=1), encoding="utf-8")
    print(
        json.dumps(
            {
                "n_complete_all_nine_arms": summary["n_complete_all_nine_arms"],
                "n_complete_core_five_arms": summary["n_complete_core_five_arms"],
                "n_failures": summary["n_failures"],
                "fixed_arm_median_nse": fixed_medians,
                "best_single_fixed_arm": best_single_fixed_arm,
                "comparisons": comparisons,
                "gain_change_from_1735_day_result": summary[
                    "gain_change_from_1735_day_result"
                ],
            },
            indent=1,
        )
    )
    return 0 if len(table) == len(basins) and len(complete_core) == len(basins) else 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=("preflight", "run", "summarize"))
    parser.add_argument("--workers", type=int, default=6)
    arguments = parser.parse_args()
    if arguments.phase == "preflight":
        return phase_preflight()
    if arguments.phase == "run":
        return phase_run(arguments.workers)
    return phase_summarize()


if __name__ == "__main__":
    sys.exit(main())
