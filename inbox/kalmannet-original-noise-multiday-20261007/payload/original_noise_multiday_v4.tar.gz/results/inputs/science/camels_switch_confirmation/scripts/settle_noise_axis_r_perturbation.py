"""Settle gates G1-G4 of the R-perturbation robustness test from the arms' unit files.

Preregistration: ``docs/plans/2026-09-01-noise-axis-r-perturbation-robustness-prereg-v01.md``
(sha256 ``c9773ba120960831d387c21a1168da9fb0f5e869b3ed801f648292c2232a2f5a``), section 4.
Addenda: 01 (test contract migration), 02 (platform changed to local).

Every gate is settled on the per-basin *paired* difference in holdout NSE, median over the 52
basins.  Nothing here re-runs a filter; it reads what the arms wrote.

    G1 learning     (A2 - A1) median > 0.01 and >= 27/52 improved
    G2 parity       |(A3 - A2)| median <= 0.01 and wins in [20, 32], bootstrap CI reported
    G3 transfer     (A3 - A1) median > 0.01 and >= 27/52 improved
    G4 multi-cand   (A4 - A3) median <= +0.01

A3's donor selection is forward-looking by default (training-segment gain, erratum 01 of the
transfer line); the retrospective rule is reported alongside, never as the headline.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

_SRC = Path(__file__).resolve().parents[2]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation import noise_axis_learned_q as learned_q  # noqa: E402
from camels_switch_confirmation import stage4_skill_weighting as stage4  # noqa: E402
from camels_switch_confirmation.noise_axis_filtering import load_stage3_control_task  # noqa: E402
from camels_switch_confirmation.run_online_noise_pilot import RESULTS  # noqa: E402

PREREG_SHA256 = "c9773ba120960831d387c21a1168da9fb0f5e869b3ed801f648292c2232a2f5a"
OUTPUT_DIR = Path(
    os.environ.get("R_PERTURBATION_OUTPUT", RESULTS / "noise_axis_r_perturbation_20260904_local_full")
)
BOOTSTRAP_DRAWS = 20_000
BOOTSTRAP_SEED = 20260901
A4_TOP_K = 5


def _load_stage(stage: str) -> pd.DataFrame:
    paths = sorted((OUTPUT_DIR / stage).glob("*.json"))
    if not paths:
        raise FileNotFoundError(f"stage {stage} produced nothing under {OUTPUT_DIR / stage}")
    return pd.DataFrame([json.loads(p.read_text(encoding="utf-8")) for p in paths])


def _paired_block(difference: np.ndarray, label: str) -> dict:
    values = np.asarray(difference, dtype=np.float64)
    generator = np.random.default_rng(BOOTSTRAP_SEED)
    indices = generator.integers(0, len(values), size=(BOOTSTRAP_DRAWS, len(values)))
    medians = np.median(values[indices], axis=1)
    return {
        "comparison": label,
        "n": int(len(values)),
        "median": float(np.median(values)),
        "mean": float(np.mean(values)),
        "n_improved": int(np.count_nonzero(values > 0.0)),
        "n_worse": int(np.count_nonzero(values < 0.0)),
        "ci95_low": float(np.percentile(medians, 2.5)),
        "ci95_high": float(np.percentile(medians, 97.5)),
    }


# ---------------------------------------------------------------------------
# arm tables
# ---------------------------------------------------------------------------

def a1_table() -> pd.DataFrame:
    frame = _load_stage("a1").set_index("basin_id")
    return frame[["nse_holdout", "nse_train_after_burnin"]]


def a2_table() -> pd.DataFrame:
    """Per-basin winner across the 8 anchors, by lowest training objective."""
    frame = _load_stage("a2")
    winners = frame.loc[frame.groupby("basin_id")["best_objective"].idxmin()]
    return winners.set_index("basin_id")


def a3_tables(a1: pd.DataFrame) -> tuple[pd.Series, pd.Series, dict]:
    """Borrowed-donor holdout NSE per receiver, under both selection rules.

    Forward-looking (headline): the donor is chosen by median training-segment gain over the
    other receivers, so nothing from any basin's evaluation window enters the choice.
    Retrospective (reported alongside): the frozen rule, which uses other basins' holdout.
    """
    frame = _load_stage("a3")
    holdout = frame.pivot(index="donor", columns="receiver", values="nse_holdout")
    train = frame.pivot(index="donor", columns="receiver", values="nse_train_after_burnin")
    gain_train = train.sub(a1["nse_train_after_burnin"], axis=1)
    gain_holdout = holdout.sub(a1["nse_holdout"], axis=1)

    def select(gain: pd.DataFrame) -> dict:
        chosen = {}
        for receiver in gain.columns:
            scores = {}
            for donor in gain.index:
                if donor == receiver:
                    continue
                row = gain.loc[donor].drop(labels=[receiver, donor], errors="ignore")
                scores[donor] = float(np.median(row.to_numpy(dtype=np.float64)))
            best = max(scores.values())
            chosen[receiver] = sorted(d for d, v in scores.items() if v == best)[0]
        return chosen

    forward = select(gain_train)
    retrospective = select(gain_holdout)
    forward_nse = pd.Series(
        {r: holdout.loc[d, r] for r, d in forward.items()}, name="a3_forward"
    )
    retrospective_nse = pd.Series(
        {r: holdout.loc[d, r] for r, d in retrospective.items()}, name="a3_retrospective"
    )
    donors = {
        "forward_counts": pd.Series(forward).value_counts().to_dict(),
        "retrospective_counts": pd.Series(retrospective).value_counts().to_dict(),
    }
    return forward_nse, retrospective_nse, donors


def a4_table() -> pd.Series:
    """Causal top-5 pruning at day 840, then the frozen inverse-error mixture (lambda 0.99)."""
    frame = _load_stage("a4")
    results = {}
    for basin, group in frame.groupby("basin_id"):
        group = group.sort_values("cell_index")
        forecasts = np.array(group["one_step_forecast"].tolist(), dtype=np.float64)
        observations = np.asarray(
            load_stage3_control_task(basin)["obs"], dtype=np.float64
        )
        cumulative = np.sum(
            np.square(forecasts[:, : learned_q.TRAIN_DAYS] - observations[None, : learned_q.TRAIN_DAYS]),
            axis=1,
        )
        keep = np.argsort(cumulative)[:A4_TOP_K]
        mixture, _ = stage4.skill_mixture(forecasts[keep], observations)
        results[basin] = learned_q.nse(
            mixture[learned_q.TRAIN_DAYS:], observations[learned_q.TRAIN_DAYS:]
        )
    return pd.Series(results, name="a4")


# ---------------------------------------------------------------------------

def main() -> int:
    a1 = a1_table()
    a2 = a2_table()
    a3_forward, a3_retrospective, donors = a3_tables(a1)
    a4 = a4_table()

    basins = sorted(a1.index)
    table = pd.DataFrame({
        "a1_fixed_rshape": a1["nse_holdout"],
        "a2_learned": a2["nse_holdout"],
        "a3_borrowed_forward": a3_forward,
        "a3_borrowed_retrospective": a3_retrospective,
        "a4_pruned_weighted": a4,
    }).loc[basins]
    table.to_csv(OUTPUT_DIR / "gates_per_basin.csv")

    g1 = _paired_block(table["a2_learned"] - table["a1_fixed_rshape"], "A2-A1 (learning)")
    g2 = _paired_block(table["a3_borrowed_forward"] - table["a2_learned"], "A3-A2 (parity)")
    g2_retro = _paired_block(
        table["a3_borrowed_retrospective"] - table["a2_learned"], "A3-A2 retrospective"
    )
    g3 = _paired_block(table["a3_borrowed_forward"] - table["a1_fixed_rshape"], "A3-A1 (transfer)")
    g3_retro = _paired_block(
        table["a3_borrowed_retrospective"] - table["a1_fixed_rshape"], "A3-A1 retrospective"
    )
    g4 = _paired_block(table["a4_pruned_weighted"] - table["a3_borrowed_forward"], "A4-A3 (multi-cand)")

    verdicts = {
        "G1": bool(g1["median"] > 0.01 and g1["n_improved"] >= 27),
        "G2": bool(abs(g2["median"]) <= 0.01 and 20 <= g2["n_improved"] <= 32),
        "G3": bool(g3["median"] > 0.01 and g3["n_improved"] >= 27),
        "G4": bool(g4["median"] <= 0.01),
    }
    summary = {
        "preregistration_sha256": PREREG_SHA256,
        "addenda": ["01 test contract migration", "02 platform changed to local"],
        "n_basins": len(table),
        "gates": {
            "G1_learning": {**g1, "threshold": "median > 0.01 and improved >= 27/52",
                            "old_result": "+0.0213, 43/52", "pass": verdicts["G1"]},
            "G2_parity": {**g2, "threshold": "|median| <= 0.01 and wins in [20,32]",
                          "old_result": "forward +0.0019, 28:24", "pass": verdicts["G2"],
                          "retrospective": g2_retro},
            "G3_transfer": {**g3, "threshold": "median > 0.01 and improved >= 27/52",
                            "old_result": "forward +0.0376, 39/52", "pass": verdicts["G3"],
                            "retrospective": g3_retro},
            "G4_multicandidate": {**g4, "threshold": "median <= +0.01",
                                  "old_result": "+0.0089 << borrowing", "pass": verdicts["G4"]},
        },
        "donor_selection": donors,
        "bootstrap": {"draws": BOOTSTRAP_DRAWS, "seed": BOOTSTRAP_SEED,
                      "resample": "basins with replacement"},
        "all_gates_pass": all(verdicts.values()),
    }
    (OUTPUT_DIR / "gates_summary.json").write_text(
        json.dumps(summary, indent=1), encoding="utf-8"
    )

    print(f"settled on {len(table)} basins, output {OUTPUT_DIR}\n")
    for name, block in summary["gates"].items():
        mark = "PASS" if block["pass"] else "FAIL"
        print(f"  {name:20s} median={block['median']:+.4f} "
              f"[{block['ci95_low']:+.4f}, {block['ci95_high']:+.4f}] "
              f"{block['n_improved']}:{block['n_worse']}  {mark}   (old: {block['old_result']})")
    print(f"\nall gates pass: {summary['all_gates_pass']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
