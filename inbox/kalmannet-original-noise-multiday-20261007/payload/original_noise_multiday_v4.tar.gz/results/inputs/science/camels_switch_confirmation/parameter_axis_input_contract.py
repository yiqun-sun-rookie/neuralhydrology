"""Audited byte-range input contract, never a full-read-then-slice loader.

An independent input audit must pin the index digest and establish its provenance
before use on real data. A digest alone is integrity evidence, not authorization.
No cache builder is provided: building an index by scanning protected data is not
permitted. The CLI currently exposes metadata checks only, not real filtering.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
START, END, DAYS, PREPARATION_DAYS = "1989-10-01", "1993-03-13", 1260, 840
ADMISSION = ROOT / "results/23_camels_switch_confirmation/online_noise_real_obs_stage3_01_20260818_local/precheck/admission.csv"
ADMISSION_HASH = "427fdc0886e389b98f8fa8277bc3abab47a69ee94013f9f694a12c9959b77e9e"
FIELD_SIZES = {"rain": DAYS, "pet": DAYS, "temperature": DAYS, "observations": DAYS,
               "center_parameters": 13, "initial_hydro": 5}


def admitted_ids() -> tuple[str, ...]:
    payload = ADMISSION.read_bytes()  # This pinned file contains only the 52 admitted rows.
    if hashlib.sha256(payload).hexdigest() != ADMISSION_HASH:
        raise ValueError("admission digest mismatch; stop before reading any input")
    rows = list(csv.DictReader(io.StringIO(payload.decode("utf-8-sig"))))
    if any(row["admitted"] != "True" for row in rows):
        raise ValueError("admission contains a non-admitted row")
    return validate_ids(tuple(sorted(row["basin_id"] for row in rows)))


def validate_ids(values) -> tuple[str, ...]:
    ids = tuple(values)
    if (len(ids) != 52 or len(set(ids)) != 52 or tuple(sorted(ids)) != ids
            or any(not isinstance(x, str) or re.fullmatch(r"[0-9]{8}", x) is None for x in ids)):
        raise ValueError("whitelist must contain exactly 52 sorted unique eight-digit ids")
    return ids


def line_path(path: Path, root: Path = ROOT) -> Path:
    resolved = Path(path).resolve()
    if not resolved.is_relative_to(root.resolve()) or not resolved.name.startswith("parameter_axis_"):
        raise ValueError("path must be inside this worktree and use the parameter_axis_ prefix")
    return resolved


def output_directory(path: Path, root: Path = ROOT) -> Path:
    base = root.resolve() / "results/23_camels_switch_confirmation"
    resolved = line_path(path, root)
    if resolved.parent != base or not resolved.name.startswith("parameter_axis_probe_adaptive_candidates_"):
        raise ValueError("output must be a new isolated adaptive-candidates directory")
    if resolved.exists():
        raise FileExistsError("output already exists; never overwrite or resume it")
    return resolved


class IndexedWindowReader:
    """Read only registered f8 little-endian segments from an unbuffered stream.

    `allowed_ids` must come from admitted_ids() in production. Synthetic tests use
    an artificial list. The metadata index describes only permitted payload;
    unrelated bytes may exist in the container but are never hashed or read.
    """

    def __init__(self, index_path: Path, index_sha256: str, allowed_ids, *, root: Path = ROOT):
        self.root = root.resolve()
        self.allowed_ids = validate_ids(allowed_ids)
        path = line_path(index_path, self.root)
        metadata = path.read_bytes()
        if hashlib.sha256(metadata).hexdigest() != index_sha256:
            raise ValueError("index digest mismatch")
        index = json.loads(metadata)
        if (index.get("schema") != "parameter_axis_byte_ranges_v1"
                or index.get("basin_ids") != list(self.allowed_ids)
                or index.get("start") != START or index.get("end") != END
                or index.get("days") != DAYS or index.get("dtype") != "<f8"):
            raise ValueError("index does not match the approved 52 by 1260 contract")
        payload_name = Path(index["payload"])
        if payload_name.is_absolute():
            raise ValueError("payload path must be index-relative")
        self.payload = line_path(path.parent / payload_name, self.root)
        self.segments = {}
        for item in index["segments"]:
            key = (item["basin_id"], item["field"])
            offset, length = item["offset"], item["nbytes"]
            if (key in self.segments or key[0] not in self.allowed_ids or key[1] not in FIELD_SIZES
                    or type(offset) is not int or offset < 0 or type(length) is not int
                    or length != FIELD_SIZES[key[1]] * 8
                    or re.fullmatch(r"[0-9a-f]{64}", item["sha256"]) is None):
                raise ValueError("invalid or duplicate authorized byte range")
            self.segments[key] = dict(item)
        expected = {(basin, field) for basin in self.allowed_ids for field in FIELD_SIZES}
        if set(self.segments) != expected:
            raise ValueError("index must describe all and only the approved inputs")
        ranges = sorted((x["offset"], x["offset"] + x["nbytes"]) for x in self.segments.values())
        if any(left[1] > right[0] for left, right in zip(ranges, ranges[1:])):
            raise ValueError("authorized byte ranges overlap")
        if ranges[-1][1] > self.payload.stat().st_size:
            raise ValueError("authorized range exceeds payload size")
        self.read_log = []

    def read_basin(self, basin_id: str, start: str = START, end: str = END) -> dict[str, np.ndarray]:
        # Check the request and resolved path BEFORE opening any payload.
        if basin_id not in self.allowed_ids or start != START or end != END:
            raise ValueError("request is outside the approved basin/date window")
        if line_path(self.payload, self.root) != self.payload:
            raise ValueError("payload path changed since index verification")
        result = {}
        with self.payload.open("rb", buffering=0) as stream:
            for field, size in FIELD_SIZES.items():
                item = self.segments[(basin_id, field)]
                stream.seek(item["offset"])
                data = stream.read(item["nbytes"])
                self.read_log.append({"basin_id": basin_id, "field": field,
                                      "offset": item["offset"], "nbytes": len(data)})
                if len(data) != item["nbytes"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
                    raise ValueError("authorized payload digest/length mismatch; stop")
                values = np.frombuffer(data, dtype="<f8").copy()
                if values.shape != (size,) or not np.all(np.isfinite(values)):
                    raise ValueError("authorized payload is not finite")
                if field in ("rain", "pet", "observations") and np.any(values < 0):
                    raise ValueError("rain, pet and discharge must be nonnegative")
                result[field] = values
        return result
