"""Stage-one input-metadata gate. Real filtering/deployment remains unimplemented.

Run with python -B and PYTHONDONTWRITEBYTECODE=1. This entry point writes nothing.
Do not treat a valid index checksum as independent provenance/audit approval.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "src"))

from camels_switch_confirmation.parameter_axis_input_contract import IndexedWindowReader, admitted_ids


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("inspect-input-metadata",), required=True)
    parser.add_argument("--input-index", type=Path, required=True)
    parser.add_argument("--approved-index-sha256", required=True)
    args = parser.parse_args(argv)
    reader = IndexedWindowReader(args.input_index, args.approved_index_sha256, admitted_ids())
    print(json.dumps({"stage": args.stage, "basins": len(reader.allowed_ids), "days": 1260,
                      "payload_bytes_read": 0, "real_filtering_enabled": False,
                      "remaining_gates": ["independent_input_provenance_audit", "independent_code_audit",
                                          "legacy_daily_parity", "authorized_real_smoke"]}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
