"""Lightweight deployment verification, submission identity, and status; no login-node model runs."""
from __future__ import annotations
import argparse
import base64
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile
from common import digest, identity, read_json, utc, verify_items, write_json

PHASE = Path("/data1/home/sunyiq/kalmannet_original_noise_multiday_20261007_attempt1")
RESULT = PHASE / "results"


def check():
    manifest = read_json(PHASE / "package_manifest.json")
    verify_items(PHASE, manifest["files"])
    contract = read_json(RESULT / "control/contract_v4.json")
    verify_items(RESULT, contract["input_files"])
    admission = read_json(PHASE / "remote_admission.json")
    if admission["status"] != "PASS" or admission["manifest_sha256"] != digest(PHASE / "package_manifest.json"):
        raise RuntimeError("Remote package has no independent admission")
    if admission["contract_sha256"] != digest(RESULT / "control/contract_v4.json"):
        raise RuntimeError("Remote contract differs")
    if digest(RESULT / "review/source_admission.json") != digest(PHASE / "remote_admission.json"):
        raise RuntimeError("Canonical execution admission differs from reviewed remote admission")
    return manifest


def submit(start, stop):
    if [start, stop] not in ([0, 195], [195, 391]):
        raise RuntimeError("Not a frozen batch")
    check()
    label = f"batch_{start:03d}_{stop:03d}"
    path = PHASE / "submissions" / (label + ".json")
    intent = PHASE / "submissions" / (label + "_intent.json")
    if path.exists():
        print(json.dumps({"status": "EXISTING_SUBMISSION_NOT_REPEATED", **read_json(path)}))
        return
    if intent.exists():
        raise RuntimeError("Submission intent exists without confirmed identity; resolve read-only")
    active = subprocess.run(["squeue", "--user=sunyiq", "--name=original-noise-multiday", "--noheader", "--format=%i %t"],
                            check=True, capture_output=True, text=True, timeout=45).stdout.strip()
    if active:
        raise RuntimeError("A job for this experiment is already active: " + active)
    if start == 195:
        previous = read_json(RESULT / "control/batch_000_195_execution_receipt.json")
        if previous["exit_code"] != 0 or previous["stop_reason"] is not None:
            raise RuntimeError("First batch did not finish successfully")
        first_contract = read_json(RESULT / "control/contract_v4.json")
        for basin in first_contract["basins"][:195]:
            row = read_json(RESULT / f"basins/{basin}.json")
            if row["status"] != "COMPUTED_PENDING_INDEPENDENT_REVIEW" or digest(RESULT / row["arrays_identity"]["path"]) != row["arrays_identity"]["sha256"]:
                raise RuntimeError("First batch has incomplete or failed basin: " + basin)
    command = ["sbatch", "--parsable", str(PHASE / "code/forecast_batch.slurm"), str(start), str(stop)]
    write_json(intent, {"utc": utc(), "command": command, "contract_sha256": digest(RESULT / "control/contract_v4.json")})
    completed = subprocess.run(command, capture_output=True, text=True, timeout=60)
    answer = completed.stdout.strip().split(";")[0]
    if completed.returncode or not answer.isdigit():
        write_json(PHASE / "submissions" / (label + "_uncertain.json"), {
            "utc": utc(), "returncode": completed.returncode, "stdout": completed.stdout, "stderr": completed.stderr})
        raise RuntimeError("Scheduler identity unconfirmed; no automatic resubmission")
    record = {"utc": utc(), "job_id": answer, "batch": [start, stop], "command": command}
    write_json(path, record)
    print(json.dumps({"status": "SUBMITTED", **record}))


def status():
    contract = read_json(RESULT / "control/contract_v4.json")
    counts = {"computed": 0, "failed": 0, "missing": 0}
    for basin in contract["basins"]:
        path = RESULT / f"basins/{basin}.json"
        if path.exists():
            row = read_json(path)
            counts["computed" if row["status"] == "COMPUTED_PENDING_INDEPENDENT_REVIEW" else "failed"] += 1
        else:
            counts["failed" if (RESULT / f"basins/{basin}.failure.json").exists() else "missing"] += 1
    jobs = []
    for path in sorted((PHASE / "submissions").glob("batch_*.json")):
        row = read_json(path)
        if "job_id" not in row:
            continue
        job = row["job_id"]
        completed = subprocess.run(["sacct", "-X", "-n", "-P", "-j", job, "-o", "JobID,State,ExitCode,Elapsed,AllocCPUS,AllocTRES"],
                                   capture_output=True, text=True, timeout=45, check=True)
        start, stop = row["batch"]
        receipt_path = RESULT / f"control/batch_{start:03d}_{stop:03d}_execution_receipt.json"
        output_path = RESULT / f"control/batch_{start:03d}_{stop:03d}_stdout.log"
        error_path = RESULT / f"control/batch_{start:03d}_{stop:03d}_stderr.log"
        jobs.append({"job_id": job, "batch": row["batch"], "accounting": completed.stdout.strip(),
                     "receipt": read_json(receipt_path) if receipt_path.exists() else None,
                     "stdout_tail": output_path.read_text(encoding="utf-8").splitlines()[-8:] if output_path.exists() else [],
                     "stderr_tail": error_path.read_text(encoding="utf-8").splitlines()[-8:] if error_path.exists() else []})
    queue = subprocess.run(["squeue", "--user=sunyiq", "--name=original-noise-multiday", "--noheader", "--format=%i %t %M %R"],
                           capture_output=True, text=True, timeout=45, check=True).stdout.strip()
    print("STATUS_JSON=" + json.dumps({"utc": utc(), "counts": counts, "jobs": jobs, "queue": queue}))


def export(start, stop, chunk):
    label = f"batch_{start:03d}_{stop:03d}"
    submission = read_json(PHASE / "submissions" / (label + ".json"))
    receipt_path = RESULT / "control" / (label + "_execution_receipt.json")
    receipt = read_json(receipt_path) if receipt_path.exists() else None
    job = submission["job_id"]
    queued = subprocess.run(["squeue", "--noheader", "--jobs=" + job, "--format=%i %t"],
                            check=True, capture_output=True, text=True, timeout=45).stdout.strip()
    accounting = subprocess.run(["sacct", "-X", "-n", "-P", "-j", job, "-o", "JobID,State,ExitCode"],
                                check=True, capture_output=True, text=True, timeout=45).stdout.strip()
    rows = [line.split("|") for line in accounting.splitlines() if line.split("|")[0] == job]
    terminal = {"COMPLETED", "FAILED", "CANCELLED", "TIMEOUT", "OUT_OF_MEMORY", "NODE_FAIL", "PREEMPTED"}
    if queued or len(rows) != 1 or rows[0][1].split()[0] not in terminal:
        raise RuntimeError("Only an independently confirmed inactive terminal job may be exported")
    contract = read_json(RESULT / "control/contract_v4.json")
    paths = []
    complete = receipt is not None and receipt["exit_code"] == 0 and receipt["stop_reason"] is None and rows[0][1] == "COMPLETED" and rows[0][2] == "0:0"
    for basin in contract["basins"][start:stop]:
        row_path = RESULT / "basins" / (basin + ".json")
        if not row_path.exists() or read_json(row_path)["status"] != "COMPUTED_PENDING_INDEPENDENT_REVIEW":
            complete = False
        for suffix in (".json", ".npz", ".failure.json"):
            path = RESULT / "basins" / (basin + suffix)
            if path.exists():
                paths.append(path)
    paths.extend((RESULT / "control").glob(label + "_*"))
    paths.extend((PHASE / "submissions").glob(label + "*.json"))
    paths.extend((PHASE / "logs").glob("job-" + submission["job_id"] + ".*"))
    buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode="wb", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as archive:
            for path in sorted(paths):
                archive.add(path, arcname=path.relative_to(PHASE).as_posix(), recursive=False)
    data = buffer.getvalue()
    width = 8 * 1024 * 1024
    count = (len(data) + width - 1) // width
    if not 0 <= chunk < count:
        raise RuntimeError("Export chunk outside range")
    segment = data[chunk * width:(chunk + 1) * width]
    metadata = {"batch": [start, stop], "chunk": chunk, "chunks": count, "bytes": len(data),
                "batch_result_status": "COMPLETE" if complete else "FAILED_OR_PARTIAL", "accounting": accounting,
                "sha256": hashlib.sha256(data).hexdigest(), "chunk_bytes": len(segment),
                "chunk_sha256": hashlib.sha256(segment).hexdigest()}
    print("EXPORT_JSON=" + json.dumps(metadata), flush=True)
    print("EXPORT_BASE64=" + base64.b64encode(segment).decode("ascii"), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("check", "submit", "status", "export"))
    parser.add_argument("--start", type=int)
    parser.add_argument("--stop", type=int)
    parser.add_argument("--chunk", type=int, default=0)
    args = parser.parse_args()
    if args.mode == "check":
        check()
        print("REMOTE_PACKAGE_VERIFIED")
    elif args.mode == "submit":
        submit(args.start, args.stop)
    elif args.mode == "status":
        status()
    else:
        export(args.start, args.stop, args.chunk)
