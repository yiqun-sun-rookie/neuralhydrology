"""One-core, time/memory/output bounded evaluation; no automatic scientific retries."""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import subprocess
import sys
import time
from common import digest, read_json, utc, write_json


def main(args):
    import psutil
    root = args.contract.resolve().parent.parent
    contract = read_json(args.contract)
    label = "pilot" if args.pilot else f"batch_{args.start:03d}_{args.stop:03d}"
    receipt_path = root / "control" / (label + "_execution_receipt.json")
    if receipt_path.exists():
        raise RuntimeError("This execution identity already has a receipt")
    for item in contract["execution_sources"]:
        path = Path(__file__).resolve().parent / item["path"].replace("\\", "/").rsplit("/", 1)[-1]
        if digest(path) != item["sha256"]:
            raise RuntimeError("Frozen evaluation source changed")
    process = psutil.Process()
    affinity = process.cpu_affinity()
    process.cpu_affinity([affinity[0]])
    env = os.environ.copy()
    env.update({name: "1" for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS")})
    env.update(CUDA_VISIBLE_DEVICES="", PYTHONDONTWRITEBYTECODE="1")
    env.pop("CAMELS_SWITCH_RESULTS", None)
    command = [sys.executable, "-X", "utf8", "-B", str(Path(__file__).with_name("evaluate.py")), "--contract", str(args.contract.resolve())]
    command += ["--pilot"] if args.pilot else ["--start", str(args.start), "--stop", str(args.stop)]
    started = time.monotonic()
    memory_peak = output_peak = 0
    stop_reason = None
    launched = utc()
    owned_processes = {}

    def descendants():
        if owned.is_running():
            owned_processes[(owned.pid, owned.create_time())] = owned
            try:
                for descendant in owned.children(recursive=True):
                    owned_processes[(descendant.pid, descendant.create_time())] = descendant
            except psutil.NoSuchProcess:
                pass
        return [p for p in owned_processes.values() if p.is_running()]

    def terminate_owned():
        selected = descendants()
        for target in reversed(selected):
            try:
                target.terminate()
            except psutil.NoSuchProcess:
                pass
        _, alive = psutil.wait_procs(selected, timeout=5)
        for target in alive:
            if target.is_running():
                try:
                    target.kill()
                except psutil.NoSuchProcess:
                    pass
        psutil.wait_procs(alive, timeout=5)

    with (root / "control" / (label + "_stdout.log")).open("x", encoding="utf-8") as out, (root / "control" / (label + "_stderr.log")).open("x", encoding="utf-8") as err:
        child = subprocess.Popen(command, env=env, stdout=out, stderr=err, cwd=root)
        owned = psutil.Process(child.pid)
        owned_processes[(owned.pid, owned.create_time())] = owned
        owned.cpu_affinity([affinity[0]])
        write_json(root / "control" / (label + "_launch.json"), {"utc": launched, "supervisor_pid": os.getpid(),
                   "child_pid": child.pid, "child_create_time": owned.create_time(), "cpu_affinity": [affinity[0]],
                   "command": command, "contract_sha256": digest(args.contract)})
        while child.poll() is None:
            memory = process.memory_info().rss
            for target in descendants():
                try:
                    memory += target.memory_info().rss
                except psutil.NoSuchProcess:
                    pass
            size = sum(p.stat().st_size for p in root.rglob("*") if p.is_file())
            memory_peak, output_peak = max(memory_peak, memory), max(output_peak, size)
            limit = contract["limits"]["pilot_seconds" if args.pilot else "job_seconds"]
            if time.monotonic() - started >= limit:
                stop_reason = "TIME_LIMIT"
            elif memory >= contract["limits"]["memory_bytes"]:
                stop_reason = "MEMORY_LIMIT"
            elif size >= contract["limits"]["output_bytes"]:
                stop_reason = "OUTPUT_LIMIT"
            if stop_reason:
                terminate_owned()
                break
            time.sleep(0.5)
        exit_code = child.wait()
        if descendants():
            stop_reason = stop_reason or "SURVIVING_DESCENDANT"
            terminate_owned()
    final_size = sum(p.stat().st_size for p in root.rglob("*") if p.is_file())
    if final_size >= contract["limits"]["output_bytes"]:
        stop_reason = stop_reason or "OUTPUT_LIMIT"
    if time.monotonic() - started >= contract["limits"]["pilot_seconds" if args.pilot else "job_seconds"]:
        stop_reason = stop_reason or "TIME_LIMIT"
    receipt = {"utc_start": launched, "utc_finish": utc(), "seconds": time.monotonic() - started,
               "exit_code": exit_code, "stop_reason": stop_reason, "peak_process_tree_memory_bytes": memory_peak,
               "peak_output_bytes": max(output_peak, final_size), "final_output_bytes_before_receipt": final_size,
               "cpu_affinity": [affinity[0]], "gpu_count": 0, "command": command, "automatic_retry": False}
    write_json(receipt_path, receipt)
    print(receipt, flush=True)
    return 0 if exit_code == 0 and stop_reason is None else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", required=True, type=Path)
    parser.add_argument("--pilot", action="store_true")
    parser.add_argument("--start", type=int, default=0)
    parser.add_argument("--stop", type=int, default=391)
    raise SystemExit(main(parser.parse_args()))
