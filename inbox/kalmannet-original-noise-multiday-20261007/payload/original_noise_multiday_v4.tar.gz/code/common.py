"""Identity and output helpers for the original-noise forecast evaluation."""
from __future__ import annotations
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write_json(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def identity(path, root=None):
    path = Path(path).resolve()
    return {"path": path.relative_to(root.resolve()).as_posix() if root else str(path),
            "bytes": path.stat().st_size, "sha256": digest(path)}


def verify_items(root, items):
    root = Path(root).resolve()
    for item in items:
        path = (root / item["path"]).resolve()
        if not path.is_relative_to(root) or path.stat().st_size != item["bytes"] or digest(path) != item["sha256"]:
            raise RuntimeError("Input identity changed: " + str(path))


def source_manifest(root):
    import sys
    root = Path(root).resolve()
    result = {}
    for name, module in sorted(sys.modules.items()):
        filename = getattr(module, "__file__", None)
        if filename:
            path = Path(filename).resolve()
            if path.suffix == ".py" and path.is_relative_to(root):
                result[name] = identity(path, root)
    return result
