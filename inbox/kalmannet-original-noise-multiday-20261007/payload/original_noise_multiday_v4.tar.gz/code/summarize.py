"""Recompute paired metrics from saved original-model forecasts, retaining all basins."""
from __future__ import annotations
import argparse
import csv
from pathlib import Path
import numpy as np
from common import identity, read_json, utc, write_json


def metric(predicted, observed):
    residual = predicted - observed
    return {"nse": float(1 - np.dot(residual, residual) / np.dot(observed - observed.mean(), observed - observed.mean())),
            "rmse_mm_day": float(np.sqrt(np.mean(residual * residual))), "bias_mm_day": float(np.mean(residual))}


def main(args):
    root = args.contract.resolve().parent.parent
    contract = read_json(args.contract)
    basins = [contract["pilot_basin"]] if args.pilot else contract["basins"]
    label = "pilot" if args.pilot else "full"
    rows, missing, failures = [], [], []
    for basin in basins:
        path = root / "basins" / (basin + ".json")
        if not path.exists():
            failure_path = root / "basins" / (basin + ".failure.json")
            if failure_path.exists():
                failures.append({"basin_id": basin, "status": "FAILED", "failure_identity": identity(failure_path, root),
                                 "failure": read_json(failure_path)})
            else:
                missing.append(basin)
            continue
        record = read_json(path)
        if record["status"] != "COMPUTED_PENDING_INDEPENDENT_REVIEW":
            failures.append({"basin_id": basin, "status": record["status"]})
            continue
        if identity(root / record["arrays_identity"]["path"])["sha256"] != record["arrays_identity"]["sha256"]:
            raise RuntimeError("Output identity mismatch: " + basin)
        with np.load(root / record["arrays_identity"]["path"], allow_pickle=False) as archive:
            observed = archive["observed"]
            origins, targets = archive["origin_indices"], archive["target_indices"]
            for scope in ("same_origins", "same_targets"):
                for lead in (1, 2, 3):
                    mask = origins < 3558 if scope == "same_origins" else (targets[:, lead - 1] >= 1737) & (targets[:, lead - 1] < 3561)
                    if mask.sum() != 1824:
                        raise RuntimeError("Scoring population changed")
                    truth = observed[targets[mask, lead - 1]]
                    fixed = metric(archive["old_fixed_forecast"][mask, lead - 1], truth)
                    learned = metric(archive["old_transfer_forecast"][mask, lead - 1], truth)
                    for arm, recomputed in (("old_fixed", fixed), ("old_transfer", learned)):
                        for key, value in recomputed.items():
                            if abs(value - record["arms"][arm]["metrics"][scope][str(lead)][key]) > 1e-10:
                                raise RuntimeError("Saved summary differs from daily arrays")
                    rows.append({"basin_id": basin, "scope": scope, "lead_days": lead, "n": 1824,
                                 **{"fixed_" + key: value for key, value in fixed.items()},
                                 **{"learned_" + key: value for key, value in learned.items()},
                                 "paired_nse_difference": learned["nse"] - fixed["nse"]})
    aggregates = {}
    for scope in ("same_origins", "same_targets"):
        aggregates[scope] = {}
        for lead in (1, 2, 3):
            selected = [row for row in rows if row["scope"] == scope and row["lead_days"] == lead]
            differences = np.array([row["paired_nse_difference"] for row in selected])
            if not len(differences):
                continue
            aggregates[scope][str(lead)] = {"n_basins": len(differences),
                "fixed_nse_median": float(np.median([row["fixed_nse"] for row in selected])),
                "learned_nse_median": float(np.median([row["learned_nse"] for row in selected])),
                "paired_nse_difference_median": float(np.median(differences)),
                "paired_nse_difference_quantiles": np.quantile(differences, [0, .1, .25, .5, .75, .9, 1]).tolist(),
                "improved": int(np.sum(differences > 0)), "equal": int(np.sum(differences == 0)),
                "worsened": int(np.sum(differences < 0))}
    summary = {"utc": utc(), "scope": label, "expected_basins": len(basins), "computed_basins": len(set(row["basin_id"] for row in rows)),
               "missing_basins": missing, "failed_basins": failures, "aggregates": aggregates,
               "training_updates": 0, "noise_parameters_changed": False, "retrospective_known_weather": True,
               "complete_population": not missing and not failures, "summary_source": identity(Path(__file__)),
               "independent_review_status": "PENDING"}
    with (root / (label + "_metrics.csv")).open("x", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]) if rows else ["basin_id"])
        writer.writeheader()
        writer.writerows(rows)
    write_json(root / (label + "_summary.json"), summary)
    text = ["# 原噪声方案的未来一、二、三天评价", "",
            f"本次已完成{summary['computed_basins']}个流域；预定{len(basins)}个。未计算{len(missing)}个，失败{len(failures)}个。全部沿用旧模型和已学噪声，重新训练次数为0。", ""]
    if args.pilot and rows:
        text += ["这是一项单流域完整评价，不能代表391个流域的总体效果。站点编号02297310。", "",
                 "评分采用纳什—萨特克利夫效率系数，即预测相对于直接使用平均流量的改善，1表示完全吻合，越高越好。主比较使用同一1824个起报日。", "",
                 "| 提前时间 | 原固定噪声 | 原已学噪声 | 已学减固定 |", "| --- | ---: | ---: | ---: |"]
        for row in rows:
            if row["scope"] == "same_origins":
                text.append(f"| {row['lead_days']}天 | {row['fixed_nse']:.6f} | {row['learned_nse']:.6f} | {row['paired_nse_difference']:+.6f} |")
    elif rows:
        text += ["| 提前时间 | 改善流域数 | 下降流域数 | 配对效率差中位数 |", "| --- | ---: | ---: | ---: |"]
        for lead, values in aggregates["same_origins"].items():
            text.append(f"| {lead}天 | {values['improved']} | {values['worsened']} | {values['paired_nse_difference_median']:+.6f} |")
    text += ["", "同时保留同一目标日期的评分，见同名完整指标表和摘要；两种日期口径不混用。",
             "未来天气来自已保存的实际天气资料，起报后不使用新的流量观测修正。旧参数及初值的历史可用性未证明，因此这是回顾性比较。结果是本次新生成的多天评价，原历史逐日运行基准仍有缺失。",
             "实际结果的独立审核状态另见review目录；本报告生成时尚未记为审核通过。"]
    with (root / (label + "_report.md")).open("x", encoding="utf-8", newline="\n") as handle:
        handle.write("\n".join(text) + "\n")
    print({"scope": label, "computed": summary["computed_basins"], "aggregates": aggregates}, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", required=True, type=Path)
    parser.add_argument("--pilot", action="store_true")
    raise SystemExit(main(parser.parse_args()))
