"""Extend the frozen old noise experiment; never train, reselect, or read future flow in forecasts."""
from __future__ import annotations
import argparse
from pathlib import Path
import sys
import time
import traceback
from common import identity, read_json, source_manifest, utc, verify_items, write_json


def scores(prediction, observed):
    import numpy as np
    if prediction.shape != observed.shape or not np.isfinite(prediction).all() or not np.isfinite(observed).all():
        raise RuntimeError("Invalid fixed paired score cells")
    error = prediction - observed
    denominator = float(np.sum((observed - observed.mean()) ** 2))
    if denominator <= 0:
        raise RuntimeError("Nonpositive observed variance")
    return {"n": len(observed), "nse": float(1 - np.sum(error ** 2) / denominator),
            "rmse_mm_day": float(np.sqrt(np.mean(error ** 2))), "bias_mm_day": float(np.mean(error))}


def preserve(root, basin, arrays, report, status, started):
    import numpy as np
    report["status"] = status
    report["seconds"] = time.monotonic() - started
    path = root / "basins" / (basin + ".npz")
    with path.open("xb") as handle:
        np.savez_compressed(handle, **arrays)
    report["arrays_identity"] = identity(path, root)
    write_json(root / "basins" / (basin + ".json"), report)


def runtime(metadata):
    import numpy as np
    from camels_switch_confirmation.g2_switch_confirmation import _build_bank
    estimator, transitions = _build_bank(
        metadata["members"], np.asarray(metadata["initial_hydrology"], dtype=np.float64),
        metadata["sigma_obs"], metadata["parameter_bounds"],
        q_scale=np.nan, q_structure="lower_groundwater_state_only", q_mode="lower_groundwater_state_proportional",
        q_state_multiplier=1.0, filter_r_multiplier=1.0, interaction_mode="full",
        parameter_state_mapping="conservative_parfc")
    if len(estimator.filters) != 1:
        raise RuntimeError("Only the original single member is admitted")
    return estimator, transitions[0]


def native_trajectory(metadata, period, noise):
    import numpy as np
    from camels_switch_confirmation.g2_switch_confirmation import assign_common_process_covariance
    estimator, transition = runtime(metadata)
    days = len(period["observed"])
    prediction = np.empty(days)
    state = np.empty((days, 15))
    covariance = np.empty((days, 15, 15))
    for day in range(days):
        transition.set_forcing(period["rain"][day], period["pet"][day], period["temperature"][day])
        reference = transition(estimator.state.copy())
        assign_common_process_covariance(estimator, noise.build_process_covariance(reference, period["rain"][day]))
        result = estimator.step(np.array([period["observed"][day]]))
        prediction[day] = result.combined_prior_observation[0]
        state[day] = result.candidate_results[0].posterior_state
        covariance[day] = result.candidate_results[0].posterior_covariance
    return prediction, state, covariance


def forecast_rollout(metadata, weather, noise, states, covariances, first_origin, stop_origin):
    """No observation array or observation callback is accepted by this function."""
    import numpy as np
    from hbv_joint_uncertainty.sigma_filter import unscented_transform
    estimator, transition = runtime(metadata)
    candidate = estimator.filters[0]
    generator = candidate.sigma_generator
    output = np.full((stop_origin - first_origin, 3), np.nan)
    failed = []
    prediction_steps = 0
    for row, origin in enumerate(range(first_origin, stop_origin)):
        candidate.state = states[origin].copy()
        candidate.covariance = covariances[origin].copy()
        candidate._prior_state = candidate._prior_covariance = None
        for lead in (1, 2, 3):
            target = origin + lead
            if target >= len(weather["rain"]):
                break
            try:
                transition.set_forcing(weather["rain"][target], weather["pet"][target], weather["temperature"][target])
                reference = transition(candidate.state.copy())
                candidate.process_covariance = noise.build_process_covariance(reference, weather["rain"][target])
                mean, covariance = candidate.predict_without_observation()
                prediction_steps += 1
                sigmas = generator.sigma_points(mean, covariance)
                mapped = np.asarray([candidate.observation(point.copy()) for point in sigmas])
                forecast, _ = unscented_transform(mapped, generator.mean_weights, generator.covariance_weights,
                                                   candidate.observation_covariance)
                output[row, lead - 1] = float(forecast[0])
            except Exception as error:
                failed.append({"origin_index": origin, "lead_days": lead, "target_index": target,
                               "error_type": type(error).__name__, "error": str(error)})
                break
        if (row + 1) % 500 == 0:
            print(f"actual_forecast_origins {row + 1}/{stop_origin - first_origin}", flush=True)
    return output, failed, prediction_steps


def evaluate_basin(root, contract, basin, pilot):
    import numpy as np
    from camels_switch_confirmation.noise_axis_filtering import LegacyGridNoise
    from camels_switch_confirmation.noise_axis_learned_q import GroupedProcessNoise
    started = time.monotonic()
    metadata = read_json(root / "inputs/metadata" / (basin + ".json"))
    with np.load(root / "inputs/periods" / (basin + ".npz"), allow_pickle=False) as archive:
        period = {key: archive[key].copy() for key in archive.files}
    noises = {"old_fixed": LegacyGridNoise(m=1.0, c=0.0),
              "old_transfer": GroupedProcessNoise(tuple(metadata["rho"]), tuple(metadata["amplitudes"]))}
    first = contract["forecast_origins"]["all_start_index"]
    stop = contract["forecast_origins"]["all_stop_exclusive"]
    origins = np.arange(first, stop, dtype=np.int64)
    targets = origins[:, None] + np.arange(1, 4)
    weather = {key: period[key] for key in ("rain", "pet", "temperature")}
    arrays = {"dates": period["dates"], "observed": period["observed"], "origin_indices": origins,
              "target_indices": targets, "valid_window_cells": targets < contract["days"]}
    report = {"basin_id": basin, "started_utc": utc(), "pilot_saved_states": pilot, "arms": {},
              "training_updates": 0, "noise_parameters_changed": False}
    for arm, noise in noises.items():
        arm_start = time.monotonic()
        if pilot:
            fixture = next(item for item in contract["pilot_saved_fixtures"] if item["arm"] == arm)
            if identity(fixture["path"])["sha256"] != fixture["sha256"]:
                raise RuntimeError("Previously accepted trajectory identity changed")
            with np.load(fixture["path"], allow_pickle=False) as archive:
                native = archive["prior_forecast"].copy()
                state, covariance = archive["posterior_state"].copy(), archive["posterior_covariance"].copy()
                np.testing.assert_array_equal(archive["dates"], period["dates"])
                np.testing.assert_array_equal(archive["observed"], period["observed"])
            filter_seconds = 0.0
        else:
            filter_started = time.monotonic()
            native, state, covariance = native_trajectory(metadata, period, noise)
            filter_seconds = time.monotonic() - filter_started
        old = metadata["historical_record"]["arms"][contract["native_arm_mapping"][arm]]
        native_scores = {"nse_full": scores(native, period["observed"])["nse"],
                         "nse_score": scores(native[1735:], period["observed"][1735:])["nse"]}
        differences = {key: native_scores[key] - old[key] for key in native_scores}
        arrays[arm + "_native_one_day"] = native
        report["arms"][arm] = {"native_scores": native_scores, "native_score_differences": differences,
                              "filter_seconds": filter_seconds}
        if any(abs(value) > contract["score_atol"] for value in differences.values()):
            report["failed_arm"] = arm
            preserve(root, basin, arrays, report, "FAILED_ORIGINAL_ONE_DAY_REFERENCE_PRESERVED", started)
            raise RuntimeError("Original one-day score failed: " + basin + "/" + arm)
        forecasts, failures, steps = forecast_rollout(metadata, weather, noise, state, covariance, first, stop)
        arrays[arm + "_forecast"] = forecasts
        parity = float(np.max(np.abs(forecasts[:, 0] - native[origins + 1])))
        if not np.isfinite(parity) or parity > contract["daily_parity_atol_mm_day"]:
            report["arms"][arm].update(forecast_failures=failures, prediction_only_steps=steps,
                one_day_max_absolute_parity_difference=parity if np.isfinite(parity) else None)
            report["failed_arm"] = arm
            preserve(root, basin, arrays, report, "FAILED_NATIVE_ONE_DAY_PARITY_PRESERVED", started)
            raise RuntimeError("Native one-day forecast definition changed: " + basin + "/" + arm)
        arm_report = {"native_scores": native_scores, "native_score_differences": differences,
                      "one_day_max_absolute_parity_difference": parity, "forecast_failures": failures,
                      "prediction_only_steps": steps, "filter_seconds": filter_seconds,
                      "seconds": time.monotonic() - arm_start, "metrics": {}}
        for scope in ("same_origins", "same_targets"):
            scope_results = {}
            for lead in (1, 2, 3):
                mask = (origins < contract["forecast_origins"]["primary_stop_exclusive"]) if scope == "same_origins" else ((targets[:, lead - 1] >= contract["common_target_start_index"]) & (targets[:, lead - 1] < contract["days"]))
                if int(mask.sum()) != 1824:
                    raise RuntimeError("Fixed scoring dates differ from 1824")
                predicted, observed = forecasts[mask, lead - 1], period["observed"][targets[mask, lead - 1]]
                scope_results[str(lead)] = scores(predicted, observed) if np.isfinite(predicted).all() else {"n": 1824, "status": "FAILED_NONFINITE_PREDICTION"}
            arm_report["metrics"][scope] = scope_results
        report["arms"][arm] = arm_report
    status = "COMPUTED_PENDING_INDEPENDENT_REVIEW" if not any(a["forecast_failures"] for a in report["arms"].values()) else "MULTIDAY_FORECAST_FAILED_PRESERVED"
    preserve(root, basin, arrays, report, status, started)
    print(f"actual_basin_complete {basin} {report['status']} {report['seconds']:.3f}s", flush=True)
    return report


def main(args):
    import numpy as np
    root = args.contract.resolve().parent.parent
    contract = read_json(args.contract)
    verify_items(root, contract["input_files"])
    admission = read_json(root / "review/source_admission.json")
    if admission["status"] != "PASS" or admission["contract_sha256"] != identity(args.contract)["sha256"]:
        raise RuntimeError("Independent admission does not bind this contract")
    if not args.pilot:
        accepted = read_json(root / "review/pilot_result_review.json")
        decision = read_json(root / "control/resource_decision.json")
        pilot_path = root / "basins" / (contract["pilot_basin"] + ".npz")
        if accepted["status"] != "PASS" or accepted["arrays_sha256"] != identity(pilot_path)["sha256"]:
            raise RuntimeError("The actual pilot has not passed independent review")
        if decision["contract_sha256"] != identity(args.contract)["sha256"] or decision["pilot_arrays_sha256"] != accepted["arrays_sha256"] or not decision["full_execution_admitted"]:
            raise RuntimeError("Full population has no matching actual resource decision")
        if decision["location"] not in ("local", "hpc"):
            raise RuntimeError("Resource decision location is not local or hpc")
        if decision["location"] == "local" and decision["estimated_conservative_seconds"] > contract["hpc_threshold_seconds"]:
            raise RuntimeError("Full calculation must use HPC by the user's scale rule")
        if decision["location"] == "hpc" and not __import__("os").environ.get("SLURM_JOB_ID"):
            raise RuntimeError("An HPC calculation must run inside the registered scheduler job")
        if not 0 <= args.start < args.stop <= len(contract["basins"]):
            raise RuntimeError("Batch indices outside frozen population")
    sys.path.insert(0, str(root / "inputs/science"))
    basins = [contract["pilot_basin"]] if args.pilot else contract["basins"][args.start:args.stop]
    for basin in basins:
        existing = root / "basins" / (basin + ".json")
        if existing.exists():
            accepted = read_json(root / "review/pilot_result_review.json")
            saved = read_json(existing)
            if basin != contract["pilot_basin"] or accepted["status"] != "PASS" or accepted["arrays_sha256"] != saved["arrays_identity"]["sha256"] or identity(root / saved["arrays_identity"]["path"])["sha256"] != accepted["arrays_sha256"]:
                raise RuntimeError("Refusing to repeat or silently accept an existing basin")
            continue
        try:
            evaluate_basin(root, contract, basin, args.pilot)
        except Exception as error:
            write_json(root / "basins" / (basin + ".failure.json"), {"status": "FAILED", "utc": utc(),
                       "type": type(error).__name__, "error": str(error), "traceback": traceback.format_exc()})
            raise
    label = "pilot" if args.pilot else f"batch_{args.start:03d}_{args.stop:03d}"
    write_json(root / "control" / (label + "_loaded_sources.json"), source_manifest(root / "inputs/science"))
    verify_items(root, contract["input_files"])
    print("EVALUATION_STAGE_COMPLETE", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", required=True, type=Path)
    parser.add_argument("--pilot", action="store_true")
    parser.add_argument("--start", type=int, default=0)
    parser.add_argument("--stop", type=int, default=391)
    arguments = parser.parse_args()
    raise SystemExit(main(arguments))
