"""Freeze existing inputs and old sources; performs no hydrological calculation."""
from __future__ import annotations
import csv
import os
from pathlib import Path
import sys
import time

from common import digest, identity, read_json, utc, write_json

SOURCE = Path(__file__).resolve().parent
ROOT = SOURCE.parents[1]
OLD = Path("G:/wt/camels-rising")
OLD_RESULTS = OLD / "results/23_camels_switch_confirmation/noise_axis_391_global_card_confirmation_20260901_local"
RESULT = ROOT / "results" / SOURCE.name


def main():
    os.environ.update({name: "1" for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS")})
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    os.environ.pop("CAMELS_SWITCH_RESULTS", None)
    sys.path.insert(0, str(OLD / "src"))
    os.chdir(OLD)
    import numpy as np
    import pandas as pd
    import psutil
    from camels_switch_confirmation import noise_axis_391_confirmation as confirm
    from camels_switch_confirmation.noise_axis_learned_q import GROUP_NAMES
    from camels_switch_confirmation.run_online_noise_real_obs import _calibration_row, PARAM_KEYS, STATE_NAMES
    from scl_hydro.hbv_lite_numpy import resolve_hbv_bounds
    process = psutil.Process()
    process.cpu_affinity([process.cpu_affinity()[0]])
    started = time.monotonic()
    RESULT.mkdir(exist_ok=False)
    for name in ("control", "review", "inputs/periods", "inputs/metadata", "inputs/science", "basins"):
        (RESULT / name).mkdir(parents=True, exist_ok=False)
    with (OLD_RESULTS / "frozen_basin_list.csv").open(encoding="utf-8-sig", newline="") as handle:
        basins = [row["basin_id"].zfill(8) for row in csv.DictReader(handle) if row["included"].lower() == "true"]
    if len(basins) != 391 or len(set(basins)) != 391 or "02297310" not in basins:
        raise RuntimeError("Original frozen population differs from 391")
    rho = confirm.load_cards()["card_selected_noleak"]
    references = []
    for package in ("camels_switch_confirmation", "hbv_joint_uncertainty", "scl_hydro"):
        for path in sorted((OLD / "src" / package).rglob("*.py")):
            target = RESULT / "inputs/science" / path.relative_to(OLD / "src")
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as handle:
                handle.write(path.read_bytes())
            references.append(identity(path))
    artifacts = [OLD_RESULTS / name for name in ("summary.json", "confirmation_per_basin.csv", "frozen_basin_list.csv")]
    artifacts += [confirm.STEP2_EVALUATION_CSV,
                  OLD / "results/23_camels_switch_confirmation/g1_precheck_v01/g1_precheck.csv",
                  OLD / "results/10_global_conceptual_model_benchmark/camels_us_531_repro_v01/summary/hbv_lite_cma_rising_local_full.csv"]
    for path in artifacts:
        references.append(identity(path))
    for number, basin in enumerate(basins, 1):
        historical_path = OLD_RESULTS / "basins" / (basin + ".json")
        historical = read_json(historical_path)
        if historical["status"] != "success" or any(historical["arms"][key]["status"] != "success" for key in ("m1_c0", "card_selected_noleak")):
            raise RuntimeError("Historical arm was not successful: " + basin)
        task = confirm.build_task(basin, confirm.HOLDOUT_START, confirm.HOLDOUT_DAYS)
        row = _calibration_row(basin)
        np.testing.assert_array_equal(np.asarray(task["sigma"]), np.asarray(historical["sigma_obs"]))
        dates = np.arange(np.datetime64("1980-01-01"), np.datetime64("1989-10-01"), dtype="datetime64[D]")
        if len(dates) != 3561 or len(task["members"]) != 1:
            raise RuntimeError("Frozen task structure differs")
        period_path = RESULT / "inputs/periods" / (basin + ".npz")
        with period_path.open("xb") as handle:
            np.savez_compressed(handle, dates=dates, rain=task["rain"], pet=task["pet"],
                                temperature=task["temp"], observed=task["obs"])
        metadata = {"basin_id": basin, "members": task["members"],
                    "initial_hydrology": [float(row["state_" + key]) for key in STATE_NAMES],
                    "parameters": {key: float(row["p_" + key]) for key in PARAM_KEYS},
                    "parameter_bounds": resolve_hbv_bounds("v5"),
                    "sigma_obs": float(task["sigma"]), "amplitudes": historical["amplitudes"],
                    "rho": rho.tolist(), "group_names": list(GROUP_NAMES),
                    "historical_record": historical, "historical_identity": identity(historical_path),
                    "initialization_source": str(row["state_init_mode"]),
                    "data_source": task["source"]}
        write_json(RESULT / "inputs/metadata" / (basin + ".json"), metadata)
        references.append(identity(historical_path))
        if number % 50 == 0 or basin == "02297310":
            print(f"frozen_existing_inputs {number}/391 {basin}", flush=True)
    fixtures = []
    for arm in ("old_fixed", "old_transfer"):
        path = ROOT / "results/matched_basin_reproduction_20261006_attempt2/trajectories" / (arm + ".npz")
        fixtures.append({"arm": arm, **identity(path)})
    contract = {"schema": "original_noise_multiday_evaluation_v1", "created_utc": utc(),
                "experiment_id": SOURCE.name, "basins": basins, "pilot_basin": "02297310",
                "arms": ["old_fixed", "old_transfer"], "native_arm_mapping": {"old_fixed": "m1_c0", "old_transfer": "card_selected_noleak"},
                "noise_selection": "original donor 04233000, unchanged; zero new optimization",
                "days": 3561, "adaptation_days": 1735,
                "forecast_origins": {"all_start_index": 1734, "all_stop_exclusive": 3560,
                                     "primary_stop_exclusive": 3558, "count_primary": 1824},
                "common_target_start_index": 1737, "count_common_targets": 1824,
                "score_atol": 1e-8, "daily_parity_atol_mm_day": 1e-8,
                "forecast_definition": "native UKF prediction-only propagation of mean and covariance; native measurement sigma-point weighted mean each lead; no observation updates after origin",
                "limits": {"pilot_seconds": 1800, "job_seconds": 28800, "memory_bytes": 8589934592,
                           "output_bytes": 104857600, "cpu_cores": 1, "gpu_count": 0},
                "hpc_threshold_seconds": 21600,
                "retrospective_known_weather": True, "historically_available_initial_parameters_proven": False,
                "input_files": [identity(p, RESULT) for p in sorted((RESULT / "inputs").rglob("*")) if p.is_file()],
                "original_evidence": references, "pilot_saved_fixtures": fixtures,
                "execution_sources": [identity(p) for p in sorted(SOURCE.glob("*.py"))],
                "plan": identity(ROOT / "docs/plans/2026-10-07-original-noise-multiday-evaluation.md"),
                "scopes": {"pilot": "one previously verified basin only", "full": "all frozen 391; no exclusion for failed multiday predictions"}}
    write_json(RESULT / "control/contract.json", contract)
    write_json(RESULT / "control/preparation_receipt.json", {"utc": utc(), "seconds": time.monotonic() - started,
               "cpu_affinity": process.cpu_affinity(), "memory": process.memory_info()._asdict(),
               "output_bytes": sum(p.stat().st_size for p in RESULT.rglob("*") if p.is_file()),
               "basin_count": len(basins), "source_files": len(references), "hydrological_advancements": 0,
               "training_updates": 0, "hpc_operations": 0, "software": {"python": sys.version, "numpy": np.__version__, "pandas": pd.__version__}})
    print("PREPARATION_COMPLETE_NO_MODEL_CALCULATION", flush=True)


if __name__ == "__main__":
    main()
