#!/bin/bash
set -euo pipefail
root=/data1/home/sunyiq/id25_regional_regionmean_rds04_20261021_001
mode=${1:-initial}
exec 9>"$root/submit.lock"
flock -n 9
active=$(timeout 30 squeue -h -u sunyiq -n id25_rds04_261021 -o '%i|%j|%T')
if test -n "$active"; then printf '%s\n' "$active"; echo ACTIVE_JOB_NO_SUBMISSION; exit 1; fi
if test "$mode" = initial; then
    test ! -e "$root/submission_intent.initial"
    test ! -e "$root/job_id.txt"
    intent="$root/submission_intent.initial"
else
    test "$mode" = resume
    test -f "$root/output/last.pt"
    previous=$(cat "$root/job_id.txt")
    state=$(timeout 30 sacct -n -X -j "$previous" --format=State -P | head -1 | cut -d'|' -f1)
    case "$state" in FAILED|TIMEOUT|CANCELLED*|OUT_OF_MEMORY|NODE_FAIL|PREEMPTED|COMPLETED) ;; *) echo UNRESOLVED_OLD_JOB; exit 1 ;; esac
    if grep -q '"state": "COMPLETED"' "$root/output/status.json"; then echo ALREADY_COMPLETED; exit 0; fi
    intent="$root/submission_intent.resume_after_$previous"
    test ! -e "$intent"
fi
date -Is > "$intent"
submitted=$(sbatch --parsable "$root/hpc/train.slurm")
job=${submitted%%;*}
case "$job" in ''|*[!0-9]*) echo UNRESOLVED_SUBMISSION_RESPONSE; exit 1 ;; esac
printf '%s\n' "$job" > "$root/job_id.txt"
printf '%s\t%s\t%s\n' "$(date -Is)" "$job" "$mode" >> "$root/submissions.tsv"
printf 'SUBMITTED_JOB=%s\n' "$job"
