"""Only new objective/selection/recovery logic; no real model fitting."""
import copy
from pathlib import Path
import sys

import numpy as np
import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src/25_global_flood_hierarchy"))
from id25.regional_regionmean import (candidate_key, fixed_masks, regional_objective,
                                    restore_selected_best)


def test_objective_fixed_observation_mask_and_finite_gradients():
    target = torch.zeros(3, 2)
    predicted = torch.tensor([[1., 4.], [1., 4.], [999., 999.]], requires_grad=True)
    fit, validation = fixed_masks(target, ["x_2002-01", "x_2007-12", "x_2008-01"], np.array([True, True, False]))
    expected = (np.sqrt(1 + 1e-6) + np.sqrt(16 + 1e-6)) / 2 - .001
    loss = regional_objective(predicted, target, fit)
    assert float(loss.detach()) == pytest.approx(expected)
    assert float(regional_objective(predicted[:, [1, 0]], target, fit)) == pytest.approx(expected)
    target[2] = float("nan")
    assert float(regional_objective(predicted, target, fit)) == pytest.approx(expected)
    loss.backward()
    assert torch.isfinite(predicted.grad).all()
    assert torch.equal(predicted.grad[2], torch.zeros(2))
    zero = torch.zeros(3, 2, requires_grad=True)
    regional_objective(zero, torch.zeros_like(zero), fit).backward()
    assert torch.isfinite(zero.grad).all()
    bad = predicted.detach().clone()
    bad[0, 1] = float("nan")
    with pytest.raises(FloatingPointError):
        regional_objective(bad, target, fit)
    with pytest.raises(ValueError):
        fixed_masks(target, ["x_2002-01", "x_2007-12", "x_2008-01"], np.array([True, True, False]))


def test_guard_selection_and_actual_best_bundle_recovery(tmp_path):
    assert candidate_key(1, 2., 5.1, 5.) is None
    b = candidate_key(2, 3., 4.9, 5.)
    c = candidate_key(3, 2.8, 5., 5.)
    assert min(b, c) == c
    assert candidate_key(4, 1., 5.2, 5.) is None
    assert candidate_key(5, 2.8, 5., 5.) > c
    binding = {"config": {"seed": 20261012}, "input_sha256": "input", "code_fingerprint": "code"}
    best = dict(binding, epoch=3, selection_key=c, model={"weight": torch.tensor([3.])},
                state=torch.tensor([30.]), prediction_reference_cm=torch.tensor([300.]))
    last = dict(binding, epoch=4, best_epoch=3, selected_best_bundle=copy.deepcopy(best),
                model={"weight": torch.tensor([4.])})
    path = tmp_path / "best.pt"
    selected = restore_selected_best(last, path, lambda p, value: torch.save(value, p))
    assert selected["epoch"] == 3
    loaded = torch.load(path, weights_only=False)
    assert loaded["model"]["weight"].item() == 3.
    assert loaded["state"].item() == 30.
    assert loaded["prediction_reference_cm"].item() == 300.
    assert min(tuple(loaded["selection_key"]), b) == c
    assert restore_selected_best({"best_epoch": None, "selected_best_bundle": None}, path, torch.save) is None
    last["selected_best_bundle"]["input_sha256"] = "wrong"
    with pytest.raises(ValueError):
        restore_selected_best(last, path, torch.save)
