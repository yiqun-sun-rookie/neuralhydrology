"""Fixed-mask regional RMSE objective and recoverable checkpoint selection."""
import numpy as np
import torch


def fixed_masks(observation, solution_ids, original_fit_mask):
    years = np.array([int(str(s)[-7:-3]) for s in solution_ids])
    fit_rows = (years >= 2002) & (years <= 2007)
    val_rows = years == 2008
    if not np.array_equal(fit_rows, original_fit_mask) or not np.all(fit_rows | val_rows):
        raise ValueError("Training archive must contain only the frozen fit and 2008 windows")
    finite = torch.isfinite(observation)
    fit = torch.as_tensor(fit_rows)[:, None] & finite
    validation = torch.as_tensor(val_rows)[:, None] & finite
    if torch.any(fit.sum(0) == 0) or torch.any(validation.sum(0) == 0):
        raise ValueError("Every region requires a fit and a 2008 validation window")
    return fit, validation


def regional_scores(prediction, observation, mask):
    """Mask depends on observations only; a bad candidate must never shrink it."""
    counts = mask.sum(0)
    if torch.any(counts == 0):
        raise ValueError("Every fixed region must remain in the denominator")
    if not torch.isfinite(prediction[mask]).all() or not torch.isfinite(observation[mask]).all():
        raise FloatingPointError("Nonfinite value on a fixed valid observation cell")
    error = torch.where(mask, prediction, 0) - torch.where(mask, observation, 0)
    squared = error.square()
    if not torch.isfinite(squared).all():
        raise FloatingPointError("Nonfinite squared residual")
    mse = squared.sum(0) / counts
    rmse = mse.sqrt()
    pooled = (squared.sum() / counts.sum()).sqrt()
    return mse, rmse, pooled


def regional_objective(prediction, observation, mask, epsilon_cm=0.001):
    mse, _, _ = regional_scores(prediction, observation, mask)
    return (torch.sqrt(mse + epsilon_cm ** 2) - epsilon_cm).mean()


def candidate_key(epoch, mean_rmse, pooled_rmse, baseline_pooled_rmse, tolerance_cm=1e-5):
    if not np.isfinite([mean_rmse, pooled_rmse]).all():
        raise FloatingPointError("Nonfinite selection metric")
    if pooled_rmse > baseline_pooled_rmse + tolerance_cm:
        return None
    return (float(mean_rmse), float(pooled_rmse), int(epoch))


def restore_selected_best(last, path, save):
    """The atomic last checkpoint is authoritative, including actual best weights."""
    bundle = last.get("selected_best_bundle")
    if bundle is None:
        if last.get("best_epoch") is not None:
            raise ValueError("Best metric without its actual model bundle")
        return None
    for name in ["config", "input_sha256", "code_fingerprint"]:
        if bundle[name] != last[name]:
            raise ValueError("Selected bundle binding mismatch: " + name)
    if int(bundle["epoch"]) != int(last["best_epoch"]):
        raise ValueError("Selected bundle epoch differs from the saved selection cursor")
    save(path, bundle)
    return bundle
