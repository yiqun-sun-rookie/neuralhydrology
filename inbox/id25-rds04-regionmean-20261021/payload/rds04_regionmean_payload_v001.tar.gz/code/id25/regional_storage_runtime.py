"""Small portable daily interface around a fixed regional storage model."""
from dataclasses import dataclass
from datetime import date as Date, timedelta
import json
from pathlib import Path

import numpy as np
import torch

from .regional_daily_storage import RegionalDailyStorage


def _date(value: str) -> Date:
    parsed = Date.fromisoformat(value)
    if parsed.isoformat() != value:
        raise ValueError("Use an ISO UTC forcing date: YYYY-MM-DD")
    return parsed


@dataclass
class DailyState:
    model_id: str
    region_ids: tuple[str, ...]
    last_forcing_date: str
    stocks_mm: np.ndarray

    @property
    def state_at_utc(self) -> str:
        return (_date(self.last_forcing_date) + timedelta(days=1)).isoformat() + "T00:00:00Z"


class StorageRuntime:
    """Consumes physical daily forcing; static features are already standardized."""

    def __init__(self, model, static_features, metadata, references, windows):
        self.model = model.eval()
        self.static_features = torch.as_tensor(static_features, dtype=torch.float32)
        self.metadata = metadata
        self.model_id = metadata["model_id"]
        self.region_ids = tuple(metadata["region_ids"])
        self.prediction_reference_cm = np.asarray(references["prediction_reference_cm"], dtype=float)
        self.observation_reference_cm = np.asarray(references["observation_reference_cm"], dtype=float)
        self.windows = windows

    @classmethod
    def load(cls, package_dir: str) -> "StorageRuntime":
        package = Path(package_dir)
        metadata = json.loads((package / "metadata.json").read_text(encoding="utf-8"))
        transforms = metadata["transforms"]
        with np.load(package / "static_features.npz", allow_pickle=False) as z:
            if tuple(z["region_ids"].astype(str)) != tuple(metadata["region_ids"]):
                raise ValueError("Packaged static features and region IDs disagree")
            features = z["static_features"].copy()
        with np.load(package / "references.npz", allow_pickle=False) as z:
            references = {name: z[name].copy() for name in z.files}
        model = RegionalDailyStorage(features.shape[1], transforms["dynamic_mean"], transforms["dynamic_scale"])
        model.load_state_dict(torch.load(package / "weights.pt", map_location="cpu", weights_only=True))
        windows = json.loads((package / "saved_windows.json").read_text(encoding="utf-8"))
        return cls(model, features, metadata, references, windows)

    def _check_state(self, state):
        if state.model_id != self.model_id or tuple(state.region_ids) != self.region_ids:
            raise ValueError("State must belong to this model and its ordered region IDs")
        stocks = np.asarray(state.stocks_mm)
        if stocks.shape != (len(self.region_ids), 3) or not np.isfinite(stocks).all() or (stocks < 0).any():
            raise ValueError("State requires three finite nonnegative stocks per region")
        _date(state.last_forcing_date)

    def initialize(self, first_forcing_date: str) -> DailyState:
        """Configured initial stocks before the specified first forcing day; allow warmup."""
        previous = (_date(first_forcing_date) - timedelta(days=1)).isoformat()
        with torch.inference_mode():
            _, initial = self.model.initialize(self.static_features)
        return DailyState(self.model_id, self.region_ids, previous, initial.numpy().copy())

    def advance(self, state: DailyState, date: str, region_ids: tuple[str, ...], forcing: np.ndarray):
        self._check_state(state)
        if _date(date) != _date(state.last_forcing_date) + timedelta(days=1):
            raise ValueError("Next forcing date must immediately follow the saved state date")
        ids = tuple(region_ids)
        if len(ids) != len(set(ids)) or set(ids) != set(self.region_ids):
            raise ValueError("Forcing must contain exactly the model's unique region IDs")
        values = np.asarray(forcing, dtype=np.float32)
        if values.shape != (len(ids), 5) or not np.isfinite(values).all() or (values[:, 0] < 0).any():
            raise ValueError("Supply finite [P,Tmax,Tmin,shortwave,vapor-pressure] with nonnegative P")
        if ids != self.region_ids:
            index = {identifier: i for i, identifier in enumerate(ids)}
            values = values[[index[k] for k in self.region_ids]]
        native = np.zeros((1, len(ids), 6), dtype=np.float32)
        native[0, :, 0] = values[:, 0]
        native[0, :, 3] = values[:, 1]
        native[0, :, 4] = values[:, 2]
        native[0, :, 1] = values[:, 3]
        native[0, :, 5] = values[:, 4]
        with torch.inference_mode():
            mean, final, _, fluxes = self.model(torch.from_numpy(native), self.static_features,
                                               initial=torch.as_tensor(state.stocks_mm, dtype=torch.float32),
                                               record=True)
        stocks = final.numpy().copy()
        next_state = DailyState(self.model_id, self.region_ids, date, stocks)
        outputs = {"snow_mm": stocks[:, 0].copy(), "fast_mm": stocks[:, 1].copy(),
                   "slow_mm": stocks[:, 2].copy(), "total_end_mm": stocks.sum(1),
                   "daily_mean_total_mm": mean[0].numpy().copy()}
        for col, name in enumerate(["melt_mm_day", "evaporation_mm_day", "drainage_mm_day", "recharge_mm_day"]):
            outputs[name] = fluxes[0, :, col].numpy().copy()
        return next_state, outputs

    def save_state(self, state: DailyState, path: str) -> None:
        self._check_state(state)
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as handle:
            np.savez_compressed(handle, model_id=np.array(state.model_id), region_ids=np.array(state.region_ids),
                                last_forcing_date=np.array(state.last_forcing_date),
                                state_at_utc=np.array(state.state_at_utc), stocks_mm=state.stocks_mm)

    def load_state(self, path: str) -> DailyState:
        with np.load(path, allow_pickle=False) as z:
            state = DailyState(str(z["model_id"]), tuple(z["region_ids"].astype(str)),
                               str(z["last_forcing_date"]), z["stocks_mm"].copy())
        self._check_state(state)
        return state

    def project_window(self, solution_id: str, dates, daily_mean_mm: np.ndarray,
                       product_zero: bool = False) -> np.ndarray:
        """Use a saved actual window; missing support days are an error, never renormalized."""
        if solution_id not in self.windows:
            raise ValueError("No saved sampling window for this solution ID")
        supplied = tuple(str(x) for x in dates)
        if len(supplied) != len(set(supplied)):
            raise ValueError("Daily projection dates must be unique")
        values = np.asarray(daily_mean_mm)
        if values.shape != (len(supplied), len(self.region_ids)):
            raise ValueError("Daily means must follow packaged region order")
        index = {day: i for i, day in enumerate(supplied)}
        window = self.windows[solution_id]
        if any(day not in index for day in window["dates"]):
            raise ValueError("Sampling window is incomplete; do not renormalize missing days")
        chosen = values[[index[day] for day in window["dates"]]]
        if not np.isfinite(chosen).all():
            raise ValueError("Sampling window contains a missing daily inventory")
        prediction = .1 * (np.asarray(window["weights"], dtype=float) @ chosen)
        anomaly = prediction - self.prediction_reference_cm
        return anomaly + self.observation_reference_cm if product_zero else anomaly
