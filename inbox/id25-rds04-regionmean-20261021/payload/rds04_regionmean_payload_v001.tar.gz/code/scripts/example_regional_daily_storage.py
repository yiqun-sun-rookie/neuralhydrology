"""Run a daily replay with one save/reload, using existing inputs (no training)."""
import argparse
import json
from pathlib import Path
import sys

import numpy as np
import torch

if (Path(__file__).resolve().parent / "code").exists():
    sys.path.insert(0, str(Path(__file__).resolve().parent / "code"))
else:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from id25.regional_storage_runtime import StorageRuntime


def replay(package, inputs, output):
    torch.set_num_threads(1)
    runtime = StorageRuntime.load(str(package))
    with np.load(inputs, allow_pickle=False) as z:
        dates = z["dates"].astype(str)
        ids = tuple(z["support_ids"].astype(str))
        forcing = z["forcing"][:, :, [0, 3, 4, 1, 5]]
    output.mkdir(parents=True, exist_ok=False)
    state = runtime.initialize(str(dates[0]))
    means = np.empty((len(dates), len(ids)), dtype=np.float32)
    states = np.empty((len(dates), len(ids), 3), dtype=np.float32)
    reload_date = "2008-06-30" if "2008-06-30" in dates else str(dates[len(dates) // 2])
    for i, day in enumerate(dates):
        state, values = runtime.advance(state, str(day), ids, forcing[i])
        means[i] = values["daily_mean_total_mm"]
        states[i] = state.stocks_mm
        if str(day) == reload_date:
            saved = output / "midway_state.npz"
            runtime.save_state(state, str(saved))
            runtime = StorageRuntime.load(str(package))
            state = runtime.load_state(str(saved))
    runtime.save_state(state, str(output / "final_state.npz"))
    solution_ids = list(runtime.windows)
    prediction = np.stack([runtime.project_window(s, dates, means) for s in solution_ids])
    np.savez_compressed(output / "window_predictions.npz", solution_ids=np.array(solution_ids),
                        region_ids=np.array(runtime.region_ids), prediction_anomaly_cm=prediction)
    record = {"model_id": runtime.model_id, "region_count": len(ids), "days_replayed": len(dates),
              "reloaded_after_forcing_date": reload_date, "last_forcing_date": state.last_forcing_date,
              "state_at_utc": state.state_at_utc, "training_started": False}
    (output / "example_record.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
    return means, states, prediction, record


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--package", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    *_, record = replay(args.package, args.inputs, args.output)
    print(json.dumps(record))
