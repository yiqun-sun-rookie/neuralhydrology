"""One 80-epoch RDS04 run; original model and observation operators stay fixed."""
import copy
import hashlib
import json
import os
from pathlib import Path
import random
import sys
import time
from datetime import datetime, timezone

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from id25.regional_daily_storage import RegionalDailyStorage
from id25.regional_storage_observation import center_on_fit_windows, project_storage
from id25.regional_regionmean import (candidate_key, fixed_masks, regional_objective,
                                    regional_scores, restore_selected_best)


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")
    os.replace(temporary, path)


def save_checkpoint(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(value, temporary)
    os.replace(temporary, path)


def load_data(root):
    with np.load(root / "inputs/inputs.npz", allow_pickle=False) as z:
        return {k: z[k] for k in z.files}


def make_model(data, transforms):
    return RegionalDailyStorage(data["static_features"].shape[1],
                                transforms["dynamic_mean"], transforms["dynamic_scale"])


def train(root, resume=False):
    config = json.loads((root / "config.json").read_text())
    manifest = json.loads((root / "source_manifest.json").read_text())
    fingerprint = manifest["code_fingerprint"]
    for rel, expected in manifest["code_sha256"].items():
        if digest(root / rel) != expected:
            raise ValueError("Deployed code differs from its frozen manifest: " + rel)
    receipt = json.loads((root / "inputs/input_receipt.json").read_text())
    if digest(root / "inputs/inputs.npz") != receipt["inputs_sha256"]:
        raise ValueError("Original training input hash mismatch")
    transforms = json.loads((root / "inputs/transforms.json").read_text())
    if digest(root / "inputs/transforms.json") != receipt["transforms_sha256"]:
        raise ValueError("Original transform hash mismatch")
    data = load_data(root)
    if len(data["support_ids"]) != 119 or data["static_features"].shape != (119, 7):
        raise ValueError("The original ordered 119 regions and seven static fields are required")
    torch.set_num_threads(config["cpu_threads"])
    torch.set_num_interop_threads(1)
    torch.manual_seed(config["seed"])
    random.seed(config["seed"])
    np.random.seed(config["seed"])
    forcing = torch.from_numpy(data["forcing"])
    statics = torch.from_numpy(data["static_features"])
    targets = torch.from_numpy(data["targets_cm"])
    weights = torch.from_numpy(data["sampling_weights"])
    fit_rows = torch.from_numpy(data["fit_mask"])
    fit, validation = fixed_masks(targets, data["solution_ids"], data["fit_mask"])
    with np.load(root / "inputs/rds01_history.npz", allow_pickle=False) as z:
        if not np.array_equal(z["support_ids"], data["support_ids"]) or not np.array_equal(
                z["solution_ids"], data["solution_ids"]):
            raise ValueError("Saved RDS01 baseline identity mismatch")
        baseline = torch.from_numpy(z["prediction_anomaly_cm"].copy())
        baseline_y = torch.from_numpy(z["observed_anomaly_cm"].copy())
    baseline_pooled = float(regional_scores(baseline, baseline_y, validation)[2])
    model = make_model(data, transforms)
    optimizer = torch.optim.Adam(model.parameters(), lr=config["learning_rate"])
    output = root / "output"
    output.mkdir(exist_ok=True)
    last_path, best_path = output / "last.pt", output / "best.pt"
    if last_path.exists() and not resume:
        raise ValueError("Existing work requires explicit resume")
    start, best, best_key = 0, None, None
    if resume:
        last = torch.load(last_path, map_location="cpu", weights_only=False)
        if last["config"] != config or last["input_sha256"] != receipt["inputs_sha256"] or \
                last["code_fingerprint"] != fingerprint:
            raise ValueError("Resume requires frozen inputs, code and configuration")
        model.load_state_dict(last["model"])
        optimizer.load_state_dict(last["optimizer"])
        torch.set_rng_state(last["rng_state"])
        start = last["epoch"]
        best = restore_selected_best(last, best_path, save_checkpoint)
        best_key = None if best is None else tuple(best["selection_key"])
    write_json(root / "runtime.json", {"job_id": os.environ.get("SLURM_JOB_ID"),
               "node": os.uname().nodename, "torch": torch.__version__, "device": "cpu",
               "config": config, "code_fingerprint": fingerprint, "started_at": now(),
               "resume_epoch": start, "preflight_repeated": False,
               "baseline_2008_pooled_rmse_cm": baseline_pooled})
    for epoch in range(start + 1, config["epochs"] + 1):
        began = time.monotonic()
        model.train()
        optimizer.zero_grad(set_to_none=True)
        daily, _, _, _ = model(forcing, statics)
        prediction = project_storage(daily, weights)
        pc, yc, _, _, _ = center_on_fit_windows(prediction, targets, fit_rows)
        loss = regional_objective(pc, yc, fit, config["epsilon_cm"])
        loss.backward()
        grad = torch.nn.utils.clip_grad_norm_(model.parameters(), config["gradient_clip"], error_if_nonfinite=True)
        optimizer.step()
        loss_value = float(loss.detach())
        del daily, prediction, pc, yc, loss
        model.eval()
        with torch.no_grad():
            daily, state, _, _ = model(forcing, statics)
            prediction = project_storage(daily, weights)
            pc, yc, p_ref, y_ref, _ = center_on_fit_windows(prediction, targets, fit_rows)
            _, fit_rmse, fit_pooled = regional_scores(pc, yc, fit)
            _, val_rmse, val_pooled = regional_scores(pc, yc, validation)
        key = candidate_key(epoch, float(val_rmse.mean()), float(val_pooled), baseline_pooled,
                            config["tolerance_cm"])
        current = {"model": copy.deepcopy(model.state_dict()), "epoch": epoch, "config": config,
                   "input_sha256": receipt["inputs_sha256"], "code_fingerprint": fingerprint,
                   "transforms": transforms, "state": state.clone(), "state_date": str(data["dates"][-1]),
                   "prediction_reference_cm": p_ref.clone(), "observation_reference_cm": y_ref.clone(),
                   "region_ids": data["support_ids"].astype(str).tolist(),
                   "selection_key": key, "saved_at": now()}
        if key is not None and (best_key is None or key < best_key):
            best, best_key = copy.deepcopy(current), key
        last = dict(current, optimizer=optimizer.state_dict(), rng_state=torch.get_rng_state(),
                    selected_best_bundle=best, best_epoch=None if best is None else best["epoch"],
                    best_region_mean_rmse_cm=None if best is None else best_key[0],
                    best_pooled_rmse_cm=None if best is None else best_key[1], optimizer_steps=epoch)
        save_checkpoint(last_path, last)
        if best is not None:
            save_checkpoint(best_path, best)
        status = {"state": "TRAINING", "epoch": epoch, "epochs": config["epochs"],
                  "optimizer_steps": epoch, "fit_objective_cm": loss_value,
                  "fit_regional_mean_rmse_cm": float(fit_rmse.mean()),
                  "fit_pooled_rmse_cm": float(fit_pooled),
                  "validation_regional_mean_rmse_cm": float(val_rmse.mean()),
                  "validation_pooled_rmse_cm": float(val_pooled),
                  "validation_regional_rmse_cm": val_rmse.tolist(),
                  "eligible": key is not None, "best_epoch": last["best_epoch"],
                  "gradient_norm": float(grad), "epoch_seconds": time.monotonic() - began,
                  "updated_at": now(), "job_id": os.environ.get("SLURM_JOB_ID")}
        with (output / "metrics.jsonl").open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(status, allow_nan=False) + "\n")
        write_json(output / "status.json", status)
        print(json.dumps(status, allow_nan=False), flush=True)
    selection = {"state": "FROZEN", "experiment_id": config["exp_id"],
                 "selected_epoch": None if best is None else best["epoch"],
                 "selection_key": best_key, "epochs_completed": config["epochs"],
                 "optimizer_steps": config["epochs"], "code_fingerprint": fingerprint,
                 "baseline_2008_pooled_rmse_cm": baseline_pooled,
                 "decision": "RETAIN_RDS01" if best is None else "EVALUATE_SELECTED_DEVELOPMENT_CANDIDATE",
                 "frozen_at": now(), "development_only": True}
    write_json(output / "selection.json", selection)
    return selection
