"""Train once, freeze, then export/score RDS04 on a Slurm compute node."""
import argparse
import csv
import json
import os
from pathlib import Path
import shutil
import sys
import traceback

import numpy as np
import torch

from train_regional_regionmean import (digest, load_data, make_model, now, train, write_json)
from id25.regional_storage_observation import center_on_fit_windows, project_storage
from id25.regional_storage_runtime import DailyState, StorageRuntime


def save_npz(path, **values):
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as handle:
        np.savez_compressed(handle, **values)
    os.replace(temporary, path)


def array_file(path):
    with np.load(path, allow_pickle=False) as z:
        return {k: z[k].copy() for k in z.files}


def balance_check(states, fluxes, forcing, initial):
    previous = torch.cat([initial.sum(1)[None], states[:-1].sum(-1)], dim=0)
    residual = states.sum(-1) - previous - forcing[:, :, 0] + fluxes[:, :, 1] + fluxes[:, :, 2]
    minimum, maximum = float(states.min()), float(residual.abs().max())
    if not torch.isfinite(states).all() or not torch.isfinite(fluxes).all() or \
            minimum < -1e-5 or not np.isfinite(maximum) or maximum > 1e-3:
        raise ValueError("Export failed the original nonnegative-stock/water-balance limits")
    return {"minimum_stock_mm": minimum, "maximum_daily_balance_error_mm": maximum}


def export_candidate(root, selection):
    output = root / "output"
    best = torch.load(output / "best.pt", map_location="cpu", weights_only=False)
    config = best["config"]
    torch.set_num_threads(config["cpu_threads"])
    data = load_data(root)
    app = array_file(root / "inputs/application_inputs.npz")
    if not np.array_equal(data["support_ids"], app["region_ids"]):
        raise ValueError("Application region order must match the frozen 119-region order")
    if str(data["dates"][-1]) != "2008-12-31" or str(app["dates"][0]) != "2009-01-01" or \
            str(app["dates"][-1]) != "2010-12-31" or len(app["dates"]) != 730:
        raise ValueError("Daily continuation must use the frozen contiguous 2009-2010 calendar")
    if not np.all(np.diff(app["dates"]) == np.timedelta64(1, "D")) or not np.isfinite(app["dynamic"]).all():
        raise ValueError("Application forcing must be complete without interpolation")
    if app["sampling_weights"].shape != (24, 730) or not np.allclose(
            app["sampling_weights"].sum(1), 1, atol=1e-6):
        raise ValueError("Application observation windows must retain complete support")
    model = make_model(data, best["transforms"])
    model.load_state_dict(best["model"])
    model.eval()
    features = torch.from_numpy(data["static_features"])
    history_forcing = torch.from_numpy(data["forcing"])
    native = np.zeros((730, 119, 6), dtype=np.float32)
    native[:, :, 0] = app["dynamic"][:, :, 0]
    native[:, :, 3] = native[:, :, 4] = app["dynamic"][:, :, 1]
    native[:, :, 1] = app["dynamic"][:, :, 2]
    native[:, :, 5] = app["dynamic"][:, :, 3]
    with torch.no_grad():
        _, initial = model.initialize(features)
        historical_mean, historical_end, historical_stocks, historical_fluxes = model(
            history_forcing, features, record=True)
        prediction = project_storage(historical_mean, torch.from_numpy(data["sampling_weights"]))
        pc, _, pref, yref, _ = center_on_fit_windows(prediction, torch.from_numpy(data["targets_cm"]),
                                                  torch.from_numpy(data["fit_mask"]))
        mean, end, stocks, fluxes = model(torch.from_numpy(native), features,
                                        initial=historical_end, record=True)
        application_prediction = project_storage(mean, torch.from_numpy(app["sampling_weights"])) - pref
        physical = {"history": balance_check(historical_stocks, historical_fluxes, history_forcing, initial),
                    "application": balance_check(stocks, fluxes, torch.from_numpy(native), historical_end)}
    if not torch.isfinite(application_prediction).all():
        raise FloatingPointError("Nonfinite application prediction; fixed comparison cannot be reduced")
    save_npz(output / "predictions.npz", support_ids=data["support_ids"],
             history_solution_ids=data["solution_ids"], application_solution_ids=app["solution_ids"],
             history_anomaly_cm=pc.numpy(), application_anomaly_cm=application_prediction.numpy())
    save_npz(output / "daily_states_2009_2010.npz", dates=app["dates"], support_ids=data["support_ids"],
             daily_mean_total_mm=mean.numpy(), states_mm=stocks.numpy(), fluxes_mm_day=fluxes.numpy(),
             state_names=np.array(["snow", "fast", "slow"]),
             flux_names=np.array(["melt", "evaporation", "drainage", "recharge"]))
    package = output / "model_package"
    package.mkdir(exist_ok=True)
    torch.save(best["model"], package / "weights.pt")
    model_id = f"RDS04_regionmean_epoch{best['epoch']:03d}_{digest(package / 'weights.pt')[:12]}"
    windows = {}
    for dates, identifiers, weights in [(data["dates"], data["solution_ids"], data["sampling_weights"]),
                                        (app["dates"], app["solution_ids"], app["sampling_weights"])]:
        for identifier, row in zip(identifiers, weights):
            used = np.flatnonzero(row > 0)
            windows[str(identifier)] = {"dates": dates[used].astype(str).tolist(),
                                        "weights": row[used].astype(float).tolist()}
    metadata = {"schema": "id25_daily_storage_package_v1", "model_id": model_id,
                "checkpoint_epoch": best["epoch"], "region_ids": best["region_ids"], "region_count": 119,
                "transforms": best["transforms"], "static_features_already_standardized": True,
                "input_fields": ["P_mm", "Tmax_degC", "Tmin_degC", "shortwave_W_m2", "vapor_pressure_Pa"],
                "input_binding_sha256": best["input_sha256"], "code_fingerprint": best["code_fingerprint"],
                "state_names": ["snow", "fast", "slow"], "state_unit": "mm",
                "state_last_forcing_date": "2008-12-31", "first_existing_forcing_date": str(data["dates"][0]),
                "development_data_kind": "legacy_proxy_development", "region_extension_supported": False,
                "interpretation": "GRACE constrains total-storage anomalies; components not independently validated"}
    write_json(package / "metadata.json", metadata)
    write_json(package / "saved_windows.json", windows)
    save_npz(package / "static_features.npz", region_ids=data["support_ids"], static_features=data["static_features"])
    save_npz(package / "references.npz", prediction_reference_cm=pref.numpy(), observation_reference_cm=yref.numpy())
    code = package / "code/id25"
    code.mkdir(parents=True, exist_ok=True)
    (code / "__init__.py").write_text("", encoding="utf-8")
    for name in ["regional_daily_storage.py", "regional_storage_runtime.py"]:
        shutil.copy2(root / "code/id25" / name, code / name)
    shutil.copy2(root / "code/scripts/example_regional_daily_storage.py", package / "example_daily.py")
    runtime = StorageRuntime.load(str(package))
    for year, values in [(2008, historical_end), (2009, stocks[364]), (2010, end)]:
        path = package / f"state_{year}-12-31.npz"
        if path.exists():
            path.unlink()  # Own deterministic export only; no source/other experiment is writable here.
        runtime.save_state(DailyState(model_id, tuple(best["region_ids"]), f"{year}-12-31", values.numpy().copy()), str(path))
    write_json(output / "physical_export.json", physical)
    return physical


def score_candidate(root):
    """Called only after selection is FROZEN and predictions have been persisted."""
    output = root / "output"
    selection = json.loads((output / "selection.json").read_text())
    if selection["state"] != "FROZEN" or selection["selected_epoch"] is None:
        raise ValueError("Cannot score an unfrozen or unselected candidate")
    predictions = array_file(output / "predictions.npz")
    reference = array_file(root / "evaluation/reference.npz")
    c01 = array_file(root / "evaluation/c01_predictions.npz")
    for source in [reference, c01]:
        if not np.array_equal(predictions["support_ids"], source["support_ids"]) or not np.array_equal(
                predictions["application_solution_ids"], source["solution_ids"][-24:]):
            raise ValueError("Fixed application comparison identity mismatch")
    observed = reference["observed_application_anomaly_cm"].astype(float)
    mask = np.isfinite(observed)
    if observed.shape != (24, 119) or not np.all(mask):
        raise ValueError("The existing 119-region x 24-window comparison must remain complete")
    arms = {"RDS04": predictions["application_anomaly_cm"].astype(float),
            "RDS01": reference["rds_application_anomaly_cm"].astype(float),
            "C01": c01["application_anomaly_cm"].astype(float)}
    metrics = {}
    for name, value in arms.items():
        if value.shape != observed.shape or not np.isfinite(value[mask]).all():
            raise FloatingPointError("Nonfinite fixed comparison arm: " + name)
        error = value - observed
        per_region = np.sqrt(np.sum(np.where(mask, error, 0) ** 2, axis=0) / mask.sum(0))
        yoy = (value[12:] - value[:12]) - (observed[12:] - observed[:12])
        metrics[name] = {"pooled_rmse_cm": float(np.sqrt(np.mean(error[mask] ** 2))),
                         "regional_mean_rmse_cm": float(per_region.mean()),
                         "regional_median_rmse_cm": float(np.median(per_region)),
                         "year_on_year_rmse_cm": float(np.sqrt(np.mean(yoy ** 2))),
                         "regional_rmse_cm": per_region.tolist()}
    tolerance = json.loads((root / "config.json").read_text())["tolerance_cm"]
    base = np.array(metrics["RDS01"]["regional_rmse_cm"])
    new = np.array(metrics["RDS04"]["regional_rmse_cm"])
    control = np.array(metrics["C01"]["regional_rmse_cm"])
    old_wins, new_wins = base < control - tolerance, new < control - tolerance
    more = bool(new_wins.sum() > old_wins.sum())
    pooled_preserved = metrics["RDS04"]["pooled_rmse_cm"] <= metrics["RDS01"]["pooled_rmse_cm"] + tolerance
    result = {"state": "SCORED", "development_only": True, "regions": 119, "windows": 24,
              "metrics": metrics, "rds01_wins_vs_C01": int(old_wins.sum()),
              "rds04_wins_vs_C01": int(new_wins.sum()),
              "rds04_ties_vs_C01": int(np.sum(np.abs(new - control) <= tolerance)),
              "rds04_losses_vs_C01": int(np.sum(new > control + tolerance)),
              "more_winning_regions": more, "majority_regions": int(new_wins.sum()) >= 60,
              "pooled_error_preserved": bool(pooled_preserved),
              "original_advantage_regions_retained": int(np.sum(old_wins & new_wins)),
              "original_advantage_regions_lost": int(np.sum(old_wins & ~new_wins)),
              "improved_vs_RDS01_at_least_0p1cm": int(np.sum(new <= base - .1)),
              "worsened_vs_RDS01_at_least_0p1cm": int(np.sum(new >= base + .1)),
              "decision": "DEVELOPMENT_GOALS_MET" if more and pooled_preserved else "RETAIN_RDS01",
              "tolerance_cm": tolerance, "fixed_observation_counts": mask.sum(0).tolist()}
    with (output / "regional_comparison.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["region_id", "RDS04_RMSE_cm", "RDS01_RMSE_cm", "C01_RMSE_cm", "RDS04_minus_RDS01_cm"])
        for index, identifier in enumerate(predictions["support_ids"]):
            writer.writerow([str(identifier), new[index], base[index], control[index], new[index] - base[index]])
    write_json(output / "comparison.json", result)
    return result


def main(args):
    root = args.root.resolve()
    if not os.environ.get("SLURM_JOB_ID"):
        raise RuntimeError("Numerical execution requires a Slurm compute allocation")
    output = root / "output"
    output.mkdir(exist_ok=True)
    status_path = output / "status.json"
    if status_path.exists() and json.loads(status_path.read_text()).get("state") == "COMPLETED":
        print("ALREADY_COMPLETED_NO_REFIT", flush=True)
        return
    selected_path = output / "selection.json"
    if selected_path.exists():
        selection = json.loads(selected_path.read_text())
        if selection["state"] != "FROZEN":
            raise ValueError("Existing selection is not frozen")
        # A post-training repair must never enter the optimizer loop again.
        last = torch.load(output / "last.pt", map_location="cpu", weights_only=False)
        from id25.regional_regionmean import restore_selected_best
        from train_regional_regionmean import save_checkpoint
        restore_selected_best(last, output / "best.pt", save_checkpoint)
    else:
        selection = train(root, resume=args.resume)
    report = {"state": "COMPLETED", "experiment_id": "RDS04_REGION_MEAN_RMSE_20261021",
              "job_id": os.environ["SLURM_JOB_ID"], "selection": selection, "development_only": True,
              "epochs_completed": 80, "optimizer_steps": 80, "preflight_repeated": False}
    if selection["selected_epoch"] is not None:
        write_json(status_path, {"state": "EXPORTING", "optimizer_steps": 80, "selected_epoch": selection["selected_epoch"]})
        report["physical_export"] = export_candidate(root, selection)
        report["comparison"] = score_candidate(root)
        report["decision"] = report["comparison"]["decision"]
    else:
        report["decision"] = "RETAIN_RDS01"
        report["reason"] = "No epoch met the frozen 2008 pooled-error constraint"
    report["finished_at"] = now()
    write_json(root / "report.json", report)
    write_json(status_path, report)
    print(json.dumps(report, allow_nan=False), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    try:
        main(args)
    except Exception as error:
        output = args.root / "output"
        output.mkdir(parents=True, exist_ok=True)
        write_json(output / "status.json", {"state": "FAILED", "error": str(error),
                   "updated_at": now(), "job_id": os.environ.get("SLURM_JOB_ID")})
        traceback.print_exc()
        sys.exit(1)
