"""Fixed float64 forecast metrics; no model execution."""
import numpy as np
NAMES=['all_mse','all_mae','low_mse','low_mae','middle_mse','middle_mae','high_mse','high_mae']
def forecast_indices():
    issues=np.arange(2557,3285,dtype=np.int64)
    return issues,issues[:,None]+np.arange(1,4,dtype=np.int64)
def scores(prediction,target,thresholds):
    p=np.asarray(prediction,dtype=np.float64);y=np.asarray(target,dtype=np.float64)
    if p.shape!=y.shape or p.ndim!=2 or p.shape[1]!=3 or not np.isfinite(p).all() or not np.isfinite(y).all():raise ValueError('invalid forecasts')
    q50,q90=thresholds[:2];groups=[np.ones(y.shape,dtype=bool),y<=q50,(y>q50)&(y<=q90),y>q90];err=p-y
    if any(not g.any() for g in groups):raise ValueError('empty fixed flow group')
    values=[]
    for g in groups:values.extend([float(np.mean(err[g]**2)),float(np.mean(np.abs(err[g])))])
    by_lead={}
    for k in range(3):
        denom=np.sum((y[:,k]-y[:,k].mean())**2)
        if denom<=0:raise ValueError('undefined NSE')
        by_lead[str(k+1)]=dict(mse=float(np.mean(err[:,k]**2)),mae=float(np.mean(np.abs(err[:,k]))),bias=float(np.mean(err[:,k])),nse=float(1-np.sum(err[:,k]**2)/denom),count=len(y))
    return dict(scores=values,group_counts=[int(g.sum()) for g in groups],by_lead=by_lead)
def comparisons(metrics):
    candidate=np.asarray(metrics['KNet_selected']['scores']);result={}
    for label in ['HBV','UKF_sampling','UKF_backprop']:
        ref=np.asarray(metrics[label]['scores']);tol=np.maximum(1e-10,1e-7*np.abs(ref));limit=ref*1.001+tol
        result[label]=dict(difference=(candidate-ref).tolist(),relative_change_percent=(100*(candidate-ref)/ref).tolist(),numerical_tolerances=tol.tolist(),flow_limits=limit.tolist(),flow_passed=(candidate<=limit).tolist(),all_flow_pass=bool((candidate<=limit).all()),overall_mse_improves=bool(ref[0]-candidate[0]>tol[0]))
    return result
