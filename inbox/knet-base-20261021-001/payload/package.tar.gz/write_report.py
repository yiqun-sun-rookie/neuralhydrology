"""Report all frozen baselines and adverse outcomes without reselection."""
from pathlib import Path
import json,csv,io
BASE=Path(__file__).resolve().parent
def obj(p):return json.loads(p.read_bytes())
def create(name,value):
    raw=value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2)+'\n'
    with (BASE/name).open('x',encoding='utf-8') as f:f.write(raw)
a=obj(BASE/'acceptance.json');t=obj(BASE/'training_audit.json');n=a['native_status'] or {};r=a['result'];receipt=a['receipt'] or {};c=obj(BASE/'replay_contract.json');v=a['archive']
lines=['# 原版KNet、HBV与UKF同条件对照','',f"技术状态：**{a['status']}**；唯一作业{a['job_id']}，原生{n.get('State')} / {n.get('ExitCode')}，ElapsedRaw={n.get('ElapsedRaw')}秒，预算900秒。",'','## 原版训练核查','',f"已有训练最多200更新，实际121次非零更新；epoch81最优，之后40轮无新低早停。核验状态：{t['status']}。这符合原停止规则，不能称为全局最优。",f"历史验证MSE：epoch0={t['epoch0_validation_mse']:.12g}，epoch5={t['epoch5_validation_mse']:.12g}，选中epoch81={t['selected_validation_mse']:.12g}，末epoch121={t['terminal_validation_mse']:.12g}。本轮新增训练预算与实际更新均0。",'训练变体为800日前向、末150日反传的原版KNet，不含雪约束；它与近期全800日反传的5步诊断不同。逐轮检查见训练充分性核查.md、原版逐轮训练核查.csv和training_audit.json。','', '## 固定条件与证据边界','','流域02092500、KNet种子20260922；训练1999-10-01至2006-09-30，评分2006-10-01至2008-09-30。四臂从同一2004-11-05物理初态开始，695日历史预热加731评分日，评分边界不重置。每臂728个发行日、2184个lead1/2/3误差事件。','HBV不做流量同化；其余三臂同化当天观测，预报只从当日后验状态传播，不使用未来Q。气象使用已知未来强迫，因此不是实时气象条件的业务预报。','该评分期曾用于KNet选模和UKF调参，是开发期模型对照，不能视为独立未见测试。KNet历史最多200更新、实际121；两种UKF各256训练和256验证查询，反传UKF含248梯度更新；历史预算、训练方式不相等。本轮统一的是评估条件，不据此声称等算力或架构因果优势。','旧合同A的020多种子跨时段崩溃记录保持原样，本轮不重读其正式评价数组，也不以本轮结果推翻旧不利证据。','']
if a['status']=='ACCEPTED_BASELINE_ARTIFACTS':
    lines+=['## 总体和逐提前量结果','','| 模型 | 总体MSE | 总体MAE | lead1 NSE | lead2 NSE | lead3 NSE |','|---|---:|---:|---:|---:|---:|']
    for label,metric in a['computed'].items():
        ns=[metric['by_lead'][str(k)]['nse'] for k in (1,2,3)]
        lines.append(f"| {label} | {metric['scores'][0]:.12g} | {metric['scores'][1]:.12g} | {ns[0]:.9g} | {ns[1]:.9g} | {ns[2]:.9g} |")
    lead_rows=[]
    lines+=['','| 模型 | 提前量（日） | MSE | MAE | NSE | bias | 样本数 |','|---|---:|---:|---:|---:|---:|---:|']
    for label,metric in a['computed'].items():
        for lead,values in metric['by_lead'].items():
            lead_rows.append(dict(model=label,lead=int(lead),**values))
            lines.append(f"| {label} | {lead} | {values['mse']:.12g} | {values['mae']:.12g} | {values['nse']:.12g} | {values['bias']:+.12g} | {values['count']} |")
    stream=io.StringIO();w=csv.DictWriter(stream,fieldnames=list(lead_rows[0]));w.writeheader();w.writerows(lead_rows);create('逐提前量完整指标.csv',stream.getvalue())
    names=['all_mse','all_mae','low_mse','low_mae','middle_mse','middle_mae','high_mse','high_mae'];rows=[];bad={}
    lines+=['','## KNet逐项差异与工程检查','','负百分比表示KNet误差降低，正数为增加。八项上限均沿用reference*1.001+原数值容差；这不是旧物理约束实验的九门槛。','','| 对照 | 指标 | KNet误差 | 对照误差 | 相对变化 | 上限 | 通过 |','|---|---|---:|---:|---:|---:|:---:|']
    for label,comp in a['comparisons'].items():
        bad[label]=[names[i] for i,d in enumerate(comp['difference']) if d>0]
        for i,name in enumerate(names):
            x=a['computed']['KNet_selected']['scores'][i];ref=a['computed'][label]['scores'][i]
            row=dict(reference=label,metric=name,knet=x,reference_value=ref,difference=comp['difference'][i],relative_change_percent=comp['relative_change_percent'][i],limit=comp['flow_limits'][i],passed=comp['flow_passed'][i]);rows.append(row)
            lines.append(f"| {label} | {name} | {x:.10g} | {ref:.10g} | {comp['relative_change_percent'][i]:+.8g}% | {comp['flow_limits'][i]:.10g} | {comp['flow_passed'][i]} |")
    stream=io.StringIO();w=csv.DictWriter(stream,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows);create('全部基线流量对照.csv',stream.getvalue())
    lead_bad={};lead_differences={}
    for label in a['comparisons']:
        lead_bad[label]=[];lead_differences[label]={}
        for lead in ['1','2','3']:
            cand=a['computed']['KNet_selected']['by_lead'][lead];ref=a['computed'][label]['by_lead'][lead]
            delta={key:cand[key]-ref[key] for key in ['mse','mae','nse','bias']};delta['absolute_bias']=abs(cand['bias'])-abs(ref['bias']);lead_differences[label][lead]=delta
            lead_bad[label]+=[f'lead{lead}_{key}' for key in ['mse','mae','absolute_bias'] if delta[key]>0]
            if delta['nse']<0:lead_bad[label].append(f'lead{lead}_nse')
    create('逐提前量对照差异.json',dict(knet_minus_reference=lead_differences,adverse=lead_bad,bias_interpretation='signed bias is reported; larger absolute bias counts as adverse'))
    lines+=['',f"总体MSE是否超过原数值容差地优于全部三个参考：**{r['overall_mse_better_than_all_references']}**。数值改善不是统计显著。",f"八流量指标全部不利项：{json.dumps(bad,ensure_ascii=False)}。",f"逐提前量全部不利项：{json.dumps(lead_bad,ensure_ascii=False)}。逐lead MSE/MAE增加、NSE下降、绝对bias增加均列入；有符号bias差本身不代表改善方向，完整差值见逐提前量对照差异.json。",f"固定流量组分母：{a['evidence']['flow_group_counts']}。不删除空组/非有限样本；本轮四条轨迹全部完整。",'', '## 实际执行与核验','',f"计数：{json.dumps(r['counters'],ensure_ascii=False)}；原版网络参数全部张量前后完全相同、两个UKF噪声不变、物理参数不变，已保存全部逐日状态和逐项指标。",f"每臂耗时：{json.dumps({k:x['wall_seconds'] for k,x in r['trajectories'].items()})}。这只是评估成本，不含历史训练/搜索成本。"]
    create('状态描述摘要.json',a['evidence']['state_summaries'])
    advice='先根据全部分组和提前量判断KNet优势是否有实际量级；若只有总体小幅收益或高流量变差，先检查已保存误差日期。之后再冻结多种子或更独立时段复核。原版已满足既定停止规则，不因结果不理想而自动延长训练。'
else:
    lines+=['## 失败与未完成','',json.dumps(dict(receipt=receipt,result=r),ensure_ascii=False,indent=2)];advice='技术证据未完成，先定位失败原因；保留现状，不自动重提、补训或修改比较规则。'
failures=[]
for p in sorted((BASE/'monitoring').glob('*result.json')):
    d=obj(p)
    if d.get('status')=='MONITOR_FAILED':failures.append({k:v for k,v in d.items() if k!='current_status'})
lines+=['',f"请求1CPU；原生AllocCPUS={n.get('AllocCPUS')}，实际亲和性{receipt.get('affinity')}，数学线程{receipt.get('mathematical_threads')}。控制器墙钟上界{receipt.get('wall_seconds_upper')}秒，子进程CPU时间{receipt.get('child_cpu_seconds')}秒，RSS峰值{receipt.get('combined_rss_peak_bytes')}字节。",f"归档{v['files']}文件、{v['archive_bytes']}字节，分片/总包/逐文件SHA通过；SHA256=`{v['archive_sha256']}`。",f"监控异常记录完整保留：{json.dumps(failures,ensure_ascii=False)}。",'', '## 下一步建议','',advice,'','结论限于一个流域、一个KNet种子、已用开发验证期、已知未来气象和固定模型。没有真实储量观测，不评价真实内部状态精度；其他实验与共享receiver未改动。','','白话总结：原版已有按规则训练完的模型，本次固定它与HBV和两种UKF在同一条件下比效果；收益和代价以全部表格为准。','']
create('运行报告.md','\n'.join(lines));reg=obj(BASE/'registry_frozen.json');reg.update(status=a['status'],job_id=a['job_id'],report='运行报告.md',overall_mse_better_than_all=None if not r or r['status']!='BASELINE_COMPLETE' else r['overall_mse_better_than_all_references']);create('registry_final.json',reg)
(BASE/'active_execution.json').write_text(json.dumps(dict(status='ACCEPTANCE_COMPLETE',job_id=a['job_id'],pending_queries=[],report='运行报告.md'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
create('START_HERE.md','# KNET-BASELINE-01\n\n先读运行报告.md、acceptance.json、training_audit.json、registry_final.json；delivery.json存在则不重复交付。\n')
print(json.dumps(dict(status='REPORT_WRITTEN',report=str(BASE/'运行报告.md')),ensure_ascii=False))
