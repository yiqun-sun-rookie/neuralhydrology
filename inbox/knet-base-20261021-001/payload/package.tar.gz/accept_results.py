"""Independent saved-array/native-receipt acceptance without model execution."""
from pathlib import Path
import json,hashlib,datetime
import numpy as np
import torch
BASE=Path(__file__).resolve().parent;HPC=BASE/'hpc_results';RUN=HPC/'runs/02092500/attempt_001'
def obj(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def arr(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
identity=obj(BASE/'execution_identity.json');verified=obj(BASE/'collection/verified.json');manifest=obj(HPC/'collection_manifest.json');contract=obj(BASE/'replay_contract.json')
assert verified['status']=='FULL_ARCHIVE_HASH_VERIFIED' and verified['job_id']==identity['job_id'] and manifest['identity']==identity
assert sha(HPC/'replay_contract.json')==sha(BASE/'replay_contract.json')==identity['contract_sha256']
for row in manifest['files']:assert (HPC/row['path']).stat().st_size==row['bytes'] and sha(HPC/row['path'])==row['sha256']
for row in obj(HPC/'deployment_manifest.json')['files']:assert sha(HPC/row['path'])==row['sha256']
for row in contract['input_bindings']:assert sha(HPC/row['path'])==sha(BASE/row['path'])==row['sha256']
native_rows=manifest['native_status'].get('native_job_row',[]);native=native_rows[0] if len(native_rows)==1 else None
receipt=obj(RUN/'receipt.json') if (RUN/'receipt.json').exists() else None;result=obj(RUN/'result.json') if (RUN/'result.json').exists() else None
complete=bool(result and result['status']=='BASELINE_COMPLETE');computed={};comparisons={};evidence={}
if complete:
    assert native and native['JobID']==identity['job_id'] and native['State']=='COMPLETED' and native['ExitCode']=='0:0'
    assert receipt['status']=='COMPLETED' and receipt['exit_code']==0 and receipt['startup_admission_verified'] and receipt['budget_pass']
    assert int(native['ElapsedRaw'])<=900 and receipt['wall_seconds_upper']<=890
    assert receipt['combined_rss_peak_bytes']<=6*1024**3 and receipt['system_free_min_bytes']>=2*1024**3 and len(receipt['affinity'])==1 and receipt['mathematical_threads']==1
    assert result['total_optimizer_calls']==receipt['total_optimizer_calls']==result['total_effective_nonzero_steps']==0
    assert result['counters']==dict(filter_trajectories=4,filter_days=5704,forecast_batches=4,forecast_events=8736,optimizer_calls=0,autograd_calls=0,qp_calls=0)
    snapshot=arr(HPC/'inputs/input_snapshot.npz');shared=arr(RUN/'shared_arrays.npz');cp=torch.load(HPC/'inputs/knet_selected.pt',weights_only=True,map_location='cpu');selection=obj(HPC/'inputs/ukf_selection.json')
    assert cp['epoch']==cp['optimizer_steps']==81 and cp['parameter_sha256']==contract['knet_parameter_sha256']
    after=torch.load(RUN/'KNet_selected_network_after.pt',weights_only=True,map_location='cpu');assert after.keys()==cp['network'].keys() and all(torch.equal(after[k],v) for k,v in cp['network'].items())
    for key in ['observations','forcing','dates_ns','thresholds']:np.testing.assert_array_equal(shared[key],snapshot[key])
    np.testing.assert_array_equal(shared['initial_state'],snapshot['training_open_loop'][1861]);np.testing.assert_array_equal(shared['previous_observation'].reshape(-1),snapshot['observations'][1861:1862])
    np.testing.assert_array_equal(shared['filter_global_indices'],np.arange(1862,3288));np.testing.assert_array_equal(shared['score_global_indices'],np.arange(2557,3288))
    issues=np.arange(2557,3285);targets=issues[:,None]+np.arange(1,4);truth=snapshot['observations'][targets]
    for key,value in [('issue_indices',issues),('target_indices',targets),('target',truth)]:np.testing.assert_array_equal(shared[key],value)
    dates=shared['dates_ns'].astype('datetime64[ns]').astype('datetime64[D]');assert str(dates[1862])=='2004-11-05' and str(dates[2557])=='2006-10-01' and str(dates[-1])=='2008-09-30'
    thresholds=np.quantile(snapshot['observations'][:2557],[.5,.9,.99],method='linear');np.testing.assert_array_equal(shared['thresholds'],thresholds)
    q50,q90=thresholds[:2];groups=[np.ones(truth.shape,dtype=bool),truth<=q50,(truth>q50)&(truth<=q90),truth>q90];counts=[int(x.sum()) for x in groups];assert counts==[2184,1515,552,117]
    base=max((.05*np.std(snapshot['observations'][:2557],ddof=0))**2,1e-10);np.testing.assert_allclose(float(shared['base_observation_variance']),base,rtol=1e-14,atol=1e-16)
    np.testing.assert_array_equal(shared['initial_covariance'],np.eye(11)[None]*.001)
    state_summaries={}
    for label in ['HBV','UKF_sampling','UKF_backprop','KNet_selected']:
        data=arr(RUN/label/'evaluation.npz');prior=data['prior_states'];post=data['posterior_states'];pred=data['prediction'];proof=result['trajectories'][label]
        assert prior.shape==post.shape==(1426,1,11) and np.isfinite(prior).all() and np.isfinite(post).all() and pred.shape==(728,3) and np.isfinite(pred).all()
        np.testing.assert_array_equal(data['corrections'],post-prior)
        for key,value in [('issue_indices',issues),('target_indices',targets),('target',truth),('initial_state',shared['initial_state']),('previous_observation',shared['previous_observation'])]:np.testing.assert_array_equal(data[key],value)
        assert proof['physical_parameters_sha_before']==proof['physical_parameters_sha_after'] and proof['filter_days']==1426 and proof['score_days']==731 and proof['network_updates']==0
        if label=='HBV':
            assert proof['observation_updates']==0 and not data['valid_updates'].any() and np.isnan(data['observations_assimilated']).all();np.testing.assert_array_equal(prior,post)
        else:
            assert proof['observation_updates']==1426 and data['valid_updates'].all();np.testing.assert_array_equal(data['observations_assimilated'].reshape(-1),snapshot['observations'][1862:3288])
        if label.startswith('UKF_'):
            key='sampling_search' if label=='UKF_sampling' else 'backpropagation';params=selection[key]['selected']
            np.testing.assert_array_equal(data['process_diagonal'],params['q_diagonal']);assert float(data['r_b'])==params['r_b']
            np.testing.assert_array_equal(data['initial_covariance'],shared['initial_covariance']);assert proof['noise_sha_before']==proof['noise_sha_after'] and proof['selected_index']==selection[key]['selected_index']
            np.testing.assert_allclose(data['innovation'],data['observations_assimilated']-data['filter_prediction'],rtol=1e-13,atol=1e-14)
            level=np.maximum(np.maximum(data['filter_prediction'],data['observations_assimilated']),0);variance=np.maximum(float(shared['base_observation_variance']),(params['r_b']*level)**2)
            np.testing.assert_allclose(data['observation_variance'],variance,rtol=1e-13,atol=1e-14)
        if label=='KNet_selected':assert proof['checkpoint_epoch']==81 and proof['parameters_require_grad'] is False and proof['state_dict_sha_before']==proof['state_dict_sha_after'] and proof['parameter_sha_before']==proof['parameter_sha_after']==cp['parameter_sha256']
        err=pred.astype(np.float64)-truth;values=[]
        for group in groups:values.extend([float(np.mean(err[group]**2)),float(np.mean(np.abs(err[group])))])
        by_lead={}
        for k in range(3):
            v=err[:,k];y=truth[:,k];denom=float(np.sum((y-y.mean())**2));assert denom>0
            by_lead[str(k+1)]=dict(mse=float(np.mean(v*v)),mae=float(np.mean(np.abs(v))),bias=float(v.mean()),nse=float(1-np.sum(v*v)/denom),count=728)
        np.testing.assert_allclose(data['scores'],values,rtol=1e-12,atol=1e-14);reported=result['metrics'][label];np.testing.assert_allclose(reported['scores'],values,rtol=1e-12,atol=1e-14);assert reported['group_counts']==counts
        for lead,metrics in by_lead.items():
            for key,value in metrics.items():np.testing.assert_allclose(reported['by_lead'][lead][key],value,rtol=1e-12,atol=1e-14)
        computed[label]=dict(scores=values,group_counts=counts,by_lead=by_lead)
        states=post[695:,0,:];state_summaries[label]=dict(score_first=states[0].tolist(),score_last=states[-1].tolist(),quantile_probabilities=[.05,.5,.95],posterior_quantiles=np.quantile(states,[.05,.5,.95],axis=0).tolist())
    candidate=np.asarray(computed['KNet_selected']['scores'])
    for label in ['HBV','UKF_sampling','UKF_backprop']:
        ref=np.asarray(computed[label]['scores']);tol=np.maximum(1e-10,1e-7*np.abs(ref));limit=ref*1.001+tol
        comparisons[label]=dict(difference=(candidate-ref).tolist(),relative_change_percent=(100*(candidate-ref)/ref).tolist(),numerical_tolerances=tol.tolist(),flow_limits=limit.tolist(),flow_passed=(candidate<=limit).tolist(),all_flow_pass=bool((candidate<=limit).all()),overall_mse_improves=bool(ref[0]-candidate[0]>tol[0]))
        assert comparisons[label]==result['comparisons'][label]
    assert all(x['overall_mse_improves'] for x in comparisons.values())==result['overall_mse_better_than_all_references']
    evidence=dict(fixed_dates_and_targets_verified=True,training_only_thresholds=True,network_all_tensors_unchanged=True,ukf_noise_unchanged=True,physical_parameters_unchanged=True,causal_observation_array_verified=True,state_summaries=state_summaries,flow_group_counts=counts,all_four_trajectories_complete=True)
a=dict(status='ACCEPTED_BASELINE_ARTIFACTS' if complete else 'TECHNICALLY_INCOMPLETE',family=contract['family'],job_id=identity['job_id'],native_status=native,receipt=receipt,result=result,computed=computed,comparisons=comparisons,evidence=evidence,archive=verified,training_audit_status=obj(BASE/'training_audit.json')['status'],new_acceptance_model_calls=0,new_acceptance_gradient_calls=0,new_acceptance_qp_calls=0,scope=contract['scope'],accepted_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
with (BASE/'acceptance.json').open('x',encoding='utf-8') as f:json.dump(a,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(dict(status=a['status'],job_id=a['job_id'],overall_mse_better_than_all=None if not complete else result['overall_mse_better_than_all_references']),ensure_ascii=False))
