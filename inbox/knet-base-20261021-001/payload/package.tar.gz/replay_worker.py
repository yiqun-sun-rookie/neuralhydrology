"""Four bounded frozen-model trajectories; no new training or model selection."""
import os,sys,io,json,time,datetime,traceback
from pathlib import Path
BASE=Path(__file__).resolve().parent;OUT='runs/02092500/attempt_001'
COUNTERS=dict(filter_trajectories=0,filter_days=0,forecast_batches=0,forecast_events=0,optimizer_calls=0,autograd_calls=0,qp_calls=0)
def main():
    import safe_io as s
    assert os.environ.get('SLURM_JOB_ID','').isdigit() and json.loads(sys.stdin.readline())['resources_configured']
    contract=json.loads(s.read_checked(BASE/'replay_contract.json'));auth=json.loads(s.read_checked(BASE/'execution_authorization.json'));assert auth['status']=='AUTHORIZED'
    for row in auth['files']:s.read_checked(BASE/row['path'],row['sha256'])
    assert contract['maximum_total_optimizer_calls']==contract['maximum_autograd_calls']==contract['maximum_qp_calls']==0
    template=BASE.parents[1]/'template';manifest=json.loads(s.read_checked(template/'bundle_manifest.json',auth['template_manifest_sha256']))
    for row in manifest['files']:s.read_checked(template/row['path'],row['sha256'])
    import numpy as np
    import torch
    from evaluation_math import scores,forecast_indices,comparisons
    torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    began=time.monotonic();os.chdir(template);sys.path.insert(0,str(template/'recipe'));os.environ['KNET_BASIN']='04105700'
    import common as C
    known={'basin_02092500.npz':'453d57eab87b0d774d5895f143d51c40644f9b92fd8702ce646a6f4841378eb6','basin_02092500.json':'1d888ac7e396def5d6d435574ad4af91a8adb89bf17845c87f15c5a2f2f4b0a3'};registered={}
    for entry in json.loads(s.read_checked(template/'recipe/evaluation_sources.json'))['files']:
        source=Path(entry['path']);assert not source.is_absolute() and '..' not in source.parts
        path=(template/source).resolve();name=path.name
        if name not in known:continue
        assert path.is_relative_to(template/'recipe/workspace/results') and entry['sha256']==known[name]
        key=str(path).lower()
        if key in C.DIGESTS:assert C.DIGESTS[key]==entry['sha256']
        C.DIGESTS[key]=entry['sha256'];registered[name]=entry['sha256']
    assert registered==known
    from global_hydrology.experiments import daily_camels_knet_per_basin_runner as per
    from global_hydrology.experiments import daily_camels_ukf_knet_parity_runner as parity
    from global_hydrology.experiments.daily_camels_knet_per_basin_contract import get_development_basin_specification
    from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import AccessLedger,CAUSAL_SHARED_SPINUP_MODE
    from scripts.differentiable_ukf_hbvlite import run_hbvlite_corrected_ukf
    def arr(x):return x.detach().cpu().numpy().copy()
    def put(name,x):return s.create(OUT+'/'+name,x)
    def np_save(name,x):
        stream=io.BytesIO();np.savez_compressed(stream,**x);return put(name,stream.getvalue())
    def emit(event,**kwargs):print(json.dumps(dict(event=event,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-began,total_optimizer_calls=0,total_effective_nonzero_steps=0,**kwargs)),flush=True)
    bindings={r['path']:r for r in contract['input_bindings']}
    def read_input(name):return s.read_checked(BASE/name,bindings[name]['sha256'])
    cp=torch.load(io.BytesIO(read_input('inputs/knet_selected.pt')),weights_only=True,map_location='cpu')
    assert cp['epoch']==cp['optimizer_steps']==81 and cp['seed']==20260922 and cp['parameter_sha256']==contract['knet_parameter_sha256']
    selection=json.loads(read_input('inputs/ukf_selection.json'));assert selection['basin_id']=='02092500'
    with np.load(io.BytesIO(read_input('inputs/input_snapshot.npz')),allow_pickle=False) as z:snapshot={k:z[k].copy() for k in z.files}
    runtime=per.load_per_basin_development_runtime(get_development_basin_specification('02092500'),ledger=AccessLedger(),initialization_mode=CAUSAL_SHARED_SPINUP_MODE,device='cpu')
    assert runtime.training_days==2557 and len(runtime.dates)==3288 and runtime.context.dimension==11
    for key,value in [('observations',arr(runtime.observations).reshape(-1)),('forcing',arr(runtime.forcing)),('dates_ns',runtime.dates.astype('datetime64[ns]').astype('int64'))]:np.testing.assert_array_equal(value,snapshot[key])
    thresholds=snapshot['thresholds'];np.testing.assert_array_equal(thresholds,np.quantile(snapshot['observations'][:2557],[.5,.9,.99],method='linear'))
    assert float(runtime.context.base_observation_variance)==selection['base_observation_variance']
    scales=parity.FeatureScales(observation_feature_scale=cp['network']['observation_feature_scale'].clone(),state_feature_scale=cp['network']['state_feature_scale'].clone(),fit_start_index=0,fit_end_exclusive=2557,floor=.1)
    per.fit_training_feature_scales=lambda r,*,floor=.1:scales
    start=contract['filter_start'];score_start=contract['score_start'];end=contract['score_end_exclusive'];warm=score_start-start
    assert (start,score_start,end,warm)==(1862,2557,3288,695)
    physical_initial=torch.as_tensor(snapshot['training_open_loop'][1861],dtype=runtime.context.dtype).clone();previous=runtime.observations[1861:1862].clone()
    issues,targets=forecast_indices();assert targets.shape==(728,3)
    initial_covariance=torch.eye(11,dtype=runtime.context.dtype).unsqueeze(0)*.001
    physics_hash=C.helpers.digest_tree(runtime.context.parameters)
    shared=dict(filter_global_indices=np.arange(start,end),score_global_indices=np.arange(score_start,end),issue_indices=issues,target_indices=targets,target=snapshot['observations'][targets],dates_ns=snapshot['dates_ns'],observations=snapshot['observations'],forcing=snapshot['forcing'],thresholds=thresholds,initial_state=arr(physical_initial),previous_observation=arr(previous),initial_covariance=arr(initial_covariance),physical_parameters=arr(runtime.context.parameters),base_observation_variance=np.asarray(float(runtime.context.base_observation_variance)))
    np_save('shared_arrays.npz',shared);records={};metrics={}
    for label in contract['trajectory_order']:
        assert COUNTERS['filter_trajectories']<4
        context=parity._context_with_initial_state(runtime.context,physical_initial.clone());run_start=time.monotonic();days=end-start
        emit('phase_start',arm=label,phase='frozen_evaluation')
        arrays=dict(initial_state=arr(physical_initial),previous_observation=arr(previous),issue_indices=issues,target_indices=targets,target=shared['target'])
        proof=dict(physical_parameters_sha_before=physics_hash,initial_physical_state_shared=True,network_updates=0)
        if label=='HBV':
            state=physical_initial.clone();states=[]
            with torch.no_grad():
                for day in range(days):
                    state=context.plain_model.f(state,runtime.forcing[start+day,0].reshape(1,3));assert torch.isfinite(state).all();states.append(state.clone());COUNTERS['filter_days']+=1
            posterior=torch.stack(states);prior=posterior.clone();arrays.update(valid_updates=np.zeros(days,dtype=bool),observations_assimilated=np.full((days,1),np.nan));proof.update(observation_updates=0,filter_implementation='native HBV point-state open loop')
        elif label.startswith('UKF_'):
            key='sampling_search' if label=='UKF_sampling' else 'backpropagation';params=selection[key]['selected']
            q=torch.tensor(params['q_diagonal'],dtype=context.dtype);rb=torch.tensor(params['r_b'],dtype=context.dtype)
            before=C.helpers.digest_tree(dict(q=q,r_b=rb,initial_covariance=initial_covariance))
            with torch.no_grad():trace=run_hbvlite_corrected_ukf(context.adapter,runtime.forcing[start:end],runtime.observations[start:end],physical_initial.clone(),initial_covariance.clone(),q,base_observation_variance=context.base_observation_variance,r_b=rb,project_mean=context.project_mean,alpha=.3,beta=2.,kappa=0.,covariance_floor=1e-12)
            prior=trace['prior_state'];posterior=trace['posterior_state'];assert prior.shape==posterior.shape==(1426,1,11)
            after=C.helpers.digest_tree(dict(q=q,r_b=rb,initial_covariance=initial_covariance));assert before==after
            arrays.update(valid_updates=np.ones(days,dtype=bool),observations_assimilated=arr(runtime.observations[start:end]),innovation=arr(trace['innovation']),filter_prediction=arr(trace['prediction']),observation_variance=arr(trace['observation_variance']),process_diagonal=arr(q),r_b=arr(rb),initial_covariance=arr(initial_covariance))
            proof.update(observation_updates=days,filter_implementation='frozen corrected UKF',noise_sha_before=before,noise_sha_after=after,selected_index=selection[key]['selected_index'])
            COUNTERS['filter_days']+=days
        else:
            assert label=='KNet_selected'
            net=per.build_exact_dimension_kalman_net(runtime,zero_gain=False,seed=20260922,gain_initialization='near_zero_fc2_head',hidden=24,input_multiplier=10,output_multiplier=10,feature_scale_floor=.1,normalized_feature_guard=10.,correction_cap_in_state_scale_units=3.)
            net.load_state_dict(cp['network'],strict=True);net.eval()
            for p in net.parameters():p.requires_grad_(False)
            before=C.helpers.digest_tree(net.state_dict());param_before=parity.parameter_sha256(net);assert param_before==contract['knet_parameter_sha256']
            batch=parity.WindowBatch(purpose='frozen_baseline',global_start=start,global_end_exclusive=end,context=context,forcing=runtime.forcing[start:end],observations=runtime.observations[start:end],dates=runtime.dates[start:end],initial_state=physical_initial.clone(),issue_start_local=warm,issue_end_local=days-3)
            native=net.analysis_step;day=0
            def observed(y,u):
                nonlocal day
                assert not torch.is_grad_enabled() and all(not p.requires_grad for p in net.parameters())
                if day==0:np.testing.assert_array_equal(arr(net.m1x_posterior),arr(physical_initial))
                np.testing.assert_array_equal(arr(y).reshape(-1),snapshot['observations'][start+day:start+day+1])
                post=native(y,u);day+=1;COUNTERS['filter_days']+=1
                if day%128==0:emit('validation_day_progress',arm=label,days=day,total=days,global_day=start+day-1)
                return post
            net.analysis_step=observed
            with torch.no_grad():trace=parity.run_knet_filter(net,batch,previous_observation=previous.clone())
            assert day==days and trace.valid_updates.all();prior=trace.prior_states;posterior=trace.posterior_states
            after=C.helpers.digest_tree(net.state_dict());param_after=parity.parameter_sha256(net);assert before==after and param_before==param_after
            stream=io.BytesIO();torch.save({k:v.detach().cpu().clone() for k,v in net.state_dict().items()},stream);put('KNet_selected_network_after.pt',stream.getvalue())
            arrays.update(valid_updates=arr(trace.valid_updates),observations_assimilated=arr(runtime.observations[start:end]),requested_corrections=arr(trace.requested_corrections))
            proof.update(observation_updates=days,filter_implementation='native KNet with selected epoch81',checkpoint_epoch=81,state_dict_sha_before=before,state_dict_sha_after=after,parameter_sha_before=param_before,parameter_sha_after=param_after,parameters_require_grad=False)
        assert torch.isfinite(prior).all() and torch.isfinite(posterior).all()
        arrays.update(prior_states=arr(prior),posterior_states=arr(posterior),corrections=arr(posterior-prior))
        with torch.no_grad():forecasts=runtime.tukf06_module.multilead_torch(context.plain_model,posterior[warm:,0,:],runtime.forcing[score_start:end])
        for lead in (1,2,3):np.testing.assert_array_equal(arr(forecasts[lead][1]),np.arange(lead,lead+728))
        prediction=np.stack([arr(forecasts[k][0]) for k in (1,2,3)],axis=1);metric=scores(prediction,shared['target'],thresholds);metrics[label]=metric
        arrays.update(prediction=prediction,scores=np.asarray(metric['scores']));artifact=np_save(label+'/evaluation.npz',arrays)
        COUNTERS['filter_trajectories']+=1;COUNTERS['forecast_batches']+=1;COUNTERS['forecast_events']+=prediction.size
        assert COUNTERS['filter_days']<=5704 and COUNTERS['forecast_events']<=8736
        proof.update(filter_days=days,score_days=731,wall_seconds=time.monotonic()-run_start,arrays=artifact,physical_parameters_sha_after=C.helpers.digest_tree(runtime.context.parameters))
        assert proof['physical_parameters_sha_after']==physics_hash
        records[label]=proof;put(label+'_frozen_model.json',proof);emit('phase_complete',arm=label,phase='frozen_evaluation',days=days)
    assert COUNTERS==dict(filter_trajectories=4,filter_days=5704,forecast_batches=4,forecast_events=8736,optimizer_calls=0,autograd_calls=0,qp_calls=0)
    for name,binding in bindings.items():s.read_checked(BASE/name,binding['sha256'])
    paired=comparisons(metrics)
    result=dict(status='BASELINE_COMPLETE',family=contract['family'],job_id=os.environ['SLURM_JOB_ID'],basin='02092500',metrics=metrics,trajectories=records,counters=COUNTERS,total_optimizer_calls=0,total_effective_nonzero_steps=0,comparisons=paired,overall_mse_better_than_all_references=all(v['overall_mse_improves'] for v in paired.values()),scope=contract['scope'],failure=None)
    put('result.json',result);print('BASELINE_RESULT='+json.dumps(result),flush=True);return 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as exc:
        import safe_io as s
        failure=dict(status='BASELINE_FAILED',family='KNET-BASELINE-01',job_id=os.environ.get('SLURM_JOB_ID'),total_optimizer_calls=0,total_effective_nonzero_steps=0,counters=COUNTERS,error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc())
        if not (BASE/OUT/'result.json').exists():s.create(OUT+'/result.json',failure)
        print('BASELINE_FAILURE='+json.dumps(failure),flush=True);raise
