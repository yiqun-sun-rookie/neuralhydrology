"""Recover verified TUKF19 plotting and packaging without rerunning computation."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import shutil
import statistics
import sys
import traceback
from typing import Any, Mapping


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import build_tukf19_hpc_bundle as bundle_builder  # noqa: E402
from scripts import plot_tukf17_hbv_rolling_origin_state_hydrology_update as plot_engine  # noqa: E402
from scripts import plot_tukf19_hbv_rolling_origin_formal_execution as plot_adapter  # noqa: E402
from scripts import run_tukf19_hpc_formal_pipeline as hpc_pipeline  # noqa: E402
from scripts import tukf19_hbv_rolling_origin_formal_common as scientific  # noqa: E402
from scripts import tukf19_hpc_deployment_common as deployment_common  # noqa: E402


DEFAULT_CONFIG = deployment_common.RETRY4_CONFIG
RESULT_RELATIVE = Path("results/tukf19_hbv_rolling_origin_formal_execution_v1")
SOURCE_DEPLOYMENT_RELATIVE = Path("artifacts/tukf19_hpc_deployment_retry2_v1")
RECOVERY_PLAN_RELATIVE = Path(
    "docs/superpowers/plans/"
    "2026-08-23-tukf19-hpc-wrapped-error-recovery-retry4.md"
)
RECOVERY_SCRIPT_RELATIVE = Path("scripts/recover_tukf19_hpc_postprocessing.py")
RECOVERY_SLURM_RELATIVE = Path(
    "hpc/tukf19_hbv_rolling_origin_formal_execution/"
    "submit_postprocessing_recovery_cpu_retry4.slurm"
)


def select_display_pair_from_verified_rows(
    registry: Mapping[str, Any],
) -> dict[str, Any]:
    """Select a display pair from a derived, non-scientific direct ratio."""

    needed = {"no_update", "state_and_hydrology_update"}
    values: dict[tuple[int, str], dict[str, float]] = {}
    for row in registry.get("rows", ()):
        readout_id = str(row.get("readout_id", ""))
        if readout_id not in needed:
            continue
        pair = (int(row["truth_seed"]), str(row["start_id"]))
        pair_values = values.setdefault(pair, {})
        if readout_id in pair_values:
            raise ValueError(f"duplicate verified display readout: {pair}: {readout_id}")
        mse = float(row["primary_clean_mse"])
        if not math.isfinite(mse) or mse < 0.0:
            raise ValueError(f"invalid verified primary clean MSE: {pair}: {readout_id}")
        pair_values[readout_id] = mse

    incomplete = {
        pair: sorted(needed - set(pair_values))
        for pair, pair_values in values.items()
        if set(pair_values) != needed
    }
    if incomplete or not values:
        raise ValueError(f"incomplete verified display-pair rows: {incomplete}")

    ratios: list[dict[str, Any]] = []
    for (truth_seed, start_id), pair_values in sorted(values.items()):
        denominator = pair_values["no_update"]
        if denominator <= 0.0:
            raise ValueError(
                f"display-only ratio denominator is not positive: {truth_seed}: {start_id}"
            )
        ratios.append(
            {
                "truth_seed": truth_seed,
                "start_id": start_id,
                "ratio": pair_values["state_and_hydrology_update"] / denominator,
            }
        )

    median = float(statistics.median(row["ratio"] for row in ratios))
    selected = min(
        ratios,
        key=lambda row: (
            abs(float(row["ratio"]) - median),
            int(row["truth_seed"]),
            str(row["start_id"]),
        ),
    )
    return {
        "truth_seed": int(selected["truth_seed"]),
        "start_id": str(selected["start_id"]),
        "ratio": float(selected["ratio"]),
        "population_median_ratio": median,
        "pair_count": len(ratios),
        "selection_basis": (
            "display_only_state_and_hydrology_update_over_no_update_derived_from_"
            "verified_registry_rows"
        ),
    }


def _tree_hashes(root: Path) -> dict[str, str]:
    return {
        path.relative_to(root).as_posix(): deployment_common.sha256_file(path)
        for path in sorted(root.rglob("*"))
        if path.is_file()
    }


def _verify_result_tree(
    root: Path,
    *,
    repair_basis: Mapping[str, Any],
) -> dict[str, Any]:
    if not root.is_dir():
        raise FileNotFoundError(f"verified result root is missing: {root}")
    registry_path = root / "registry.json"
    verification_path = root / "independent_verification.json"
    manifest_path = root / "manifest.json"
    expected_hashes = {
        registry_path: repair_basis["source_registry_sha256"],
        verification_path: repair_basis["source_independent_verification_sha256"],
        manifest_path: repair_basis["source_result_manifest_sha256"],
    }
    for path, expected in expected_hashes.items():
        if not path.is_file() or deployment_common.sha256_file(path) != expected:
            raise ValueError(f"pinned verified-result file changed: {path}")

    hashes = _tree_hashes(root)
    total_bytes = sum((root / relative).stat().st_size for relative in hashes)
    if len(hashes) != int(repair_basis["source_result_file_count"]):
        raise ValueError("verified result file count changed")
    if total_bytes != int(repair_basis["source_result_total_bytes"]):
        raise ValueError("verified result byte count changed")

    registry = deployment_common.read_json(registry_path)
    verification = deployment_common.read_json(verification_path)
    manifest = deployment_common.read_json(manifest_path)
    manifest_hashes = {
        relative: digest
        for relative, digest in hashes.items()
        if Path(relative).name not in {"manifest.json", "independent_verification.json"}
    }
    checks = verification.get("checks", {})
    validity = {
        "registry_status": registry.get("status")
        == "FORMAL_COMPLETE_AWAITING_INDEPENDENT_VERIFICATION",
        "scientific_identity": registry.get("experiment_id")
        == scientific.EXPERIMENT_ID,
        "registry_rows": len(registry.get("rows", ())) == 162,
        "independent_verification_status": verification.get("status")
        == "FORMAL_VERIFIED",
        "independent_check_count": len(checks) == 12,
        "independent_checks_all_true": bool(checks)
        and all(bool(value) for value in checks.values()),
        "independent_readouts": int(
            verification.get("recomputed_test_readout_count", -1)
        )
        == 162,
        "independent_primary_clean_errors": int(
            verification.get("recomputed_primary_clean_error_count", -1)
        )
        == 20412,
        "internal_manifest": manifest.get("files") == manifest_hashes,
    }
    if not all(validity.values()):
        raise ValueError(f"verified result evidence changed: {validity}")
    return {
        "checks": validity,
        "hashes": hashes,
        "file_count": len(hashes),
        "total_bytes": total_bytes,
        "registry": registry,
        "verification": verification,
    }


def _source_paths(deployment: Mapping[str, Any]) -> dict[str, Path]:
    basis = deployment["repair_basis"]
    source = Path(str(basis["source_target_root"]))
    status = source / SOURCE_DEPLOYMENT_RELATIVE / "status"
    return {
        "target": source,
        "result": source / RESULT_RELATIVE,
        "smoke": source / SOURCE_DEPLOYMENT_RELATIVE / "smoke/smoke_report.json",
        "failure": status / "formal_failure_209845.json",
        "submission": status / "formal_submission.json",
        "started": status / "formal_started.json",
        "stdout": source / "logs/formal-209845.out",
        "stderr": source / "logs/formal-209845.err",
        "bundle_manifest": source / "_transport/bundle_manifest.sha256.json",
    }


def _verify_source_failure(
    deployment: Mapping[str, Any], paths: Mapping[str, Path]
) -> dict[str, Any]:
    basis = deployment["repair_basis"]
    for label in ("failure", "submission", "started", "stdout", "stderr", "bundle_manifest"):
        if not paths[label].is_file():
            raise FileNotFoundError(f"source formal evidence is missing: {paths[label]}")
    if deployment_common.sha256_file(paths["failure"]) != basis[
        "source_formal_failure_sha256"
    ]:
        raise ValueError("source formal-failure evidence changed")
    if deployment_common.sha256_file(paths["smoke"]) != basis[
        "source_smoke_report_sha256"
    ]:
        raise ValueError("source smoke evidence changed")
    stderr_sha256 = deployment_common.sha256_file(paths["stderr"])
    if stderr_sha256 != basis["source_formal_stderr_sha256"]:
        raise ValueError("source formal stderr evidence changed")
    failure = deployment_common.read_json(paths["failure"])
    started = deployment_common.read_json(paths["started"])
    source_bundle = deployment_common.read_json(paths["bundle_manifest"])
    stderr = paths["stderr"].read_text(encoding="utf-8")
    steps = failure.get("steps", ())
    checks = {
        "failure_status": failure.get("status") == "HPC_FORMAL_PIPELINE_FAILED",
        "wrapped_runtime_error": failure.get("error_type")
        == basis["source_pipeline_error_type"],
        "wrapped_plot_step": basis["source_pipeline_error_contains"]
        in str(failure.get("error", "")),
        "stderr_identity": stderr_sha256 == basis["source_formal_stderr_sha256"],
        "stderr_key_error": basis["source_nested_error_type"] in stderr,
        "stderr_missing_display_contrast": basis[
            "source_nested_missing_contrast"
        ]
        in stderr,
        "successful_preplot_steps": len(steps) == 2
        and [int(step.get("return_code", -1)) for step in steps] == [0, 0],
        "source_job_identity": str(started.get("slurm_job_id"))
        == str(basis["source_formal_job_id"]),
        "source_bundle_identity": source_bundle.get("archive_sha256")
        == basis["source_bundle_sha256"],
    }
    if not all(checks.values()):
        raise ValueError(f"source formal-failure boundary changed: {checks}")
    return checks


def _verify_bundle(
    deployment: Mapping[str, Any], bundle_manifest_path: Path
) -> dict[str, Any]:
    manifest = deployment_common.read_json(bundle_manifest_path)
    payload_path = ROOT / str(deployment["outputs"]["payload_manifest_name"])
    payload = deployment_common.read_json(payload_path)
    checks = {
        "deployment_identity": manifest.get("deployment_id")
        == deployment["deployment_id"],
        "scientific_identity": manifest.get("scientific_experiment_id")
        == deployment["scientific_experiment_id"],
        "payload_hash": deployment_common.sha256_file(payload_path)
        == manifest.get("payload_manifest_sha256"),
        "payload_member_map": payload.get("members") == manifest.get("members"),
        "payload_deployment_identity": payload.get("deployment_id")
        == deployment["deployment_id"],
    }
    member_checks = {
        name: (ROOT / name).is_file()
        and deployment_common.sha256_file(ROOT / name) == expected
        for name, expected in manifest.get("members", {}).items()
    }
    checks["all_payload_members"] = bool(member_checks) and all(member_checks.values())
    if not all(checks.values()):
        raise ValueError(f"recovery deployment bundle validation failed: {checks}")
    return {
        "checks": checks,
        "archive_sha256": manifest["archive_sha256"],
        "member_count": len(member_checks),
    }


def _copy_verified_result(
    source: Path,
    destination: Path,
    *,
    source_validation: Mapping[str, Any],
    repair_basis: Mapping[str, Any],
) -> dict[str, Any]:
    if destination.exists():
        raise FileExistsError(f"refusing to replace recovery result root: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source, destination, copy_function=shutil.copy2)
    copied = _verify_result_tree(destination, repair_basis=repair_basis)
    if copied["hashes"] != source_validation["hashes"]:
        raise ValueError("recovery result copy differs from verified source")
    return copied


def _package_recovery(
    deployment: Mapping[str, Any],
    validation: Mapping[str, Any],
    *,
    smoke_path: Path,
    started_path: Path,
    complete_path: Path,
    deployment_path: Path,
    bundle_manifest_path: Path,
    source_paths: Mapping[str, Path],
) -> dict[str, Any]:
    archive_path = deployment_common.resolve_root_relative(
        deployment["outputs"]["formal_result_archive"]
    )
    external_manifest_path = archive_path.with_suffix(
        archive_path.suffix + ".sha256.json"
    )
    if archive_path.exists() or external_manifest_path.exists():
        raise FileExistsError("refusing to replace postprocessing recovery package")

    members = hpc_pipeline._result_members(
        validation,
        smoke_path=smoke_path,
        complete_status_path=complete_path,
        deployment_path=deployment_path,
    )
    local_evidence = {
        "recovery/status/postprocessing_recovery_started.json": started_path,
        "recovery/deployment/bundle_manifest.sha256.json": bundle_manifest_path,
        "recovery/source/recovery_script.py": ROOT / RECOVERY_SCRIPT_RELATIVE,
        "recovery/source/recovery_plan.md": ROOT / RECOVERY_PLAN_RELATIVE,
        "recovery/source/recovery_job.slurm": ROOT / RECOVERY_SLURM_RELATIVE,
    }
    source_evidence = {
        "recovery/source_job/formal_failure_209845.json": source_paths["failure"],
        "recovery/source_job/formal_submission.json": source_paths["submission"],
        "recovery/source_job/formal_started.json": source_paths["started"],
        "recovery/source_job/formal-209845.out": source_paths["stdout"],
        "recovery/source_job/formal-209845.err": source_paths["stderr"],
        "recovery/source_job/bundle_manifest.sha256.json": source_paths[
            "bundle_manifest"
        ],
    }
    for name, path in {**local_evidence, **source_evidence}.items():
        if name in members:
            raise ValueError(f"duplicate recovery archive member: {name}")
        if not path.is_file():
            raise FileNotFoundError(f"recovery package evidence is missing: {path}")
        members[name] = path
    members = dict(sorted(members.items()))

    hashes = {
        name: deployment_common.sha256_file(path) for name, path in members.items()
    }
    payload_manifest = {
        "schema_version": "tukf19_hpc_postprocessing_recovery_payload_manifest_v1",
        "deployment_id": deployment["deployment_id"],
        "scientific_experiment_id": deployment["scientific_experiment_id"],
        "source_formal_job_id": deployment["repair_basis"]["source_formal_job_id"],
        "members": hashes,
    }
    virtual_name = "postprocessing_recovery_payload_manifest.json"
    virtual_bytes = deployment_common.canonical_json_bytes(payload_manifest)
    bundle_builder.write_deterministic_archive(
        archive_path,
        members,
        virtual_members={virtual_name: virtual_bytes},
    )
    external = {
        "schema_version": (
            "tukf19_hpc_postprocessing_recovery_result_bundle_manifest_v1"
        ),
        "deployment_id": deployment["deployment_id"],
        "scientific_experiment_id": deployment["scientific_experiment_id"],
        "source_formal_job_id": deployment["repair_basis"]["source_formal_job_id"],
        "archive_name": archive_path.name,
        "archive_sha256": deployment_common.sha256_file(archive_path),
        "archive_bytes": archive_path.stat().st_size,
        "member_count": len(hashes),
        "payload_manifest_name": virtual_name,
        "payload_manifest_sha256": deployment_common.sha256_bytes(virtual_bytes),
        "members": hashes,
    }
    deployment_common.write_new_json(external_manifest_path, external)
    return {
        **external,
        "archive_path": archive_path,
        "manifest_path": external_manifest_path,
    }


def run_recovery(
    *,
    deployment_path: Path = DEFAULT_CONFIG,
    bundle_manifest_path: Path,
) -> dict[str, Any]:
    deployment = deployment_common.load_deployment(deployment_path)
    if deployment["deployment_id"] != deployment_common.RETRY4_DEPLOYMENT_ID:
        raise PermissionError("postprocessing recovery requires the retry-4 deployment")
    if Path(deployment["hpc"]["target_root"]).resolve() != ROOT.resolve():
        raise ValueError("recovery bundle is not running from its registered target")

    status_root = deployment_common.resolve_root_relative(
        deployment["outputs"]["hpc_status_root"]
    )
    started_path = status_root / "postprocessing_recovery_started.json"
    complete_path = status_root / "postprocessing_recovery_complete.json"
    if started_path.exists() or complete_path.exists():
        raise FileExistsError("refusing to replace postprocessing recovery status")

    started_at = datetime.now(timezone.utc).isoformat()
    source_paths = _source_paths(deployment)
    try:
        bundle_validation = _verify_bundle(deployment, bundle_manifest_path)
        source_failure_checks = _verify_source_failure(deployment, source_paths)
        source_validation = _verify_result_tree(
            source_paths["result"], repair_basis=deployment["repair_basis"]
        )
        deployment_common.write_new_json(
            started_path,
            {
                "schema_version": "tukf19_hpc_postprocessing_recovery_start_v1",
                "deployment_id": deployment["deployment_id"],
                "scientific_experiment_id": deployment["scientific_experiment_id"],
                "source_formal_job_id": deployment["repair_basis"][
                    "source_formal_job_id"
                ],
                "recovery_bundle_sha256": bundle_validation["archive_sha256"],
                "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
                "node": os.environ.get("SLURMD_NODENAME"),
                "started_at_utc": started_at,
            },
        )

        destination_result = ROOT / RESULT_RELATIVE
        copied = _copy_verified_result(
            source_paths["result"],
            destination_result,
            source_validation=source_validation,
            repair_basis=deployment["repair_basis"],
        )
        smoke_path = deployment_common.resolve_root_relative(
            deployment["outputs"]["smoke_report"]
        )
        if smoke_path.exists():
            raise FileExistsError("refusing to replace copied smoke evidence")
        smoke_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_paths["smoke"], smoke_path)
        if deployment_common.sha256_file(smoke_path) != deployment["repair_basis"][
            "source_smoke_report_sha256"
        ]:
            raise ValueError("copied smoke evidence differs")

        contract = scientific.load_contract()
        plot_engine.select_display_pair = select_display_pair_from_verified_rows
        figure_result = plot_adapter.create_verified_figures(contract)
        selected_pair = figure_result["selected_pair"]
        if int(selected_pair.get("pair_count", -1)) != 27:
            raise ValueError("display-only selection did not cover all 27 pairs")
        validation = hpc_pipeline.validate_formal_outputs(deployment, contract)

        completion = {
            "schema_version": "tukf19_hpc_postprocessing_recovery_complete_v1",
            "deployment_id": deployment["deployment_id"],
            "scientific_experiment_id": deployment["scientific_experiment_id"],
            "status": "HPC_POSTPROCESSING_RECOVERY_VERIFIED",
            "source_formal_job_id": deployment["repair_basis"][
                "source_formal_job_id"
            ],
            "recovery_slurm_job_id": os.environ.get("SLURM_JOB_ID"),
            "recovery_bundle_sha256": bundle_validation["archive_sha256"],
            "source_failure_checks": source_failure_checks,
            "source_result_checks": source_validation["checks"],
            "copied_result_file_count": copied["file_count"],
            "copied_result_total_bytes": copied["total_bytes"],
            "selected_display_pair": selected_pair,
            "validation": {
                key: value
                for key, value in validation.items()
                if key not in {"result_root", "figure_root"}
            },
            "formal_training_rerun": False,
            "independent_verification_rerun": False,
            "finished_at_utc": datetime.now(timezone.utc).isoformat(),
        }
        deployment_common.write_new_json(complete_path, completion)
        package = _package_recovery(
            deployment,
            validation,
            smoke_path=smoke_path,
            started_path=started_path,
            complete_path=complete_path,
            deployment_path=deployment_path,
            bundle_manifest_path=bundle_manifest_path,
            source_paths=source_paths,
        )
        return {**completion, "package": package}
    except BaseException as error:
        failure_path = status_root / (
            "postprocessing_recovery_failure_"
            f"{os.environ.get('SLURM_JOB_ID', 'unknown')}.json"
        )
        if not failure_path.exists():
            deployment_common.write_new_json(
                failure_path,
                {
                    "schema_version": (
                        "tukf19_hpc_postprocessing_recovery_failure_v1"
                    ),
                    "deployment_id": deployment["deployment_id"],
                    "scientific_experiment_id": deployment[
                        "scientific_experiment_id"
                    ],
                    "status": "HPC_POSTPROCESSING_RECOVERY_FAILED",
                    "source_formal_job_id": deployment["repair_basis"][
                        "source_formal_job_id"
                    ],
                    "recovery_slurm_job_id": os.environ.get("SLURM_JOB_ID"),
                    "error_type": type(error).__name__,
                    "error": str(error),
                    "traceback": traceback.format_exc(),
                    "failed_at_utc": datetime.now(timezone.utc).isoformat(),
                },
            )
        raise


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--bundle-manifest", type=Path, required=True)
    parser.add_argument("--confirm-postprocessing-recovery", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    if not args.confirm_postprocessing_recovery:
        raise PermissionError("explicit postprocessing-recovery confirmation is required")
    report = run_recovery(
        deployment_path=args.config.resolve(),
        bundle_manifest_path=args.bundle_manifest.resolve(),
    )
    print(
        json.dumps(
            {
                "status": report["status"],
                "source_formal_job_id": report["source_formal_job_id"],
                "recovery_slurm_job_id": report["recovery_slurm_job_id"],
                "archive_sha256": report["package"]["archive_sha256"],
                "archive_bytes": report["package"]["archive_bytes"],
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
