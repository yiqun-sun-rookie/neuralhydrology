# TUKF19 HPC Wrapped-Error Recovery Retry 4 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Complete the postprocessing-only recovery after job 209938 stopped on an incorrect assumption about which evidence file contains the plotting `KeyError`.

**Architecture:** Retry 4 keeps the retry-2 verified numerical result as its immutable source and preserves the entire failed retry-3 directory. The sole behavioral change is to validate `RuntimeError` in the pipeline failure JSON and validate the nested `KeyError` plus missing display contrast in the pinned retry-2 stderr log; all copying, plotting, validation, packaging, and no-training protections remain unchanged.

**Tech Stack:** Python 3.11, pytest, NumPy, Matplotlib, deterministic gzip/tar packaging, Slurm `hcpu48y`, and Git mailbox channel `kalmannet-tukf19`.

## Global Constraints

- Formal training job 209845 is never rerun.
- Independent scientific verification is never rerun.
- Failed recovery job 209938 and `/data1/home/sunyiq/kalmannet_tukf19_20260823_retry3` remain immutable.
- Retry-4 target is exclusively `/data1/home/sunyiq/kalmannet_tukf19_20260823_retry4`.
- Retry-3 bundle SHA-256 is `497f3347134a0f19ecc6bbf1cbc2dc42e5a326aaf8c6cc52cda81c77265ee5c9`.
- Retry-3 submission SHA-256 is `af07f09972ba6438dd7cc29f3a2165576e388caa883433080073ef1265304898`.
- Retry-3 failure SHA-256 is `effec19c256e5bcff91bdf969b92fcff11701414f8a0967bbde14b98a4035e49`.
- Retry-3 stderr SHA-256 is `236b410d1a8291d86d300c1c9fee812dd84d33e94a6545807ac67293b1e79733`.
- Retry-2 source stderr SHA-256 is `b396a0bef8ab19203dafa7eddf67a34f30b005d57ae3cc19656aa4f8a8c33cb1`.
- Retry-3 result, figure, completion, and package paths were all absent after failure.
- Scientific settings, source closure, result hashes, random seeds, samples, metrics, gates, and stop rules remain unchanged.

---

### Task 1: Freeze retry-4 evidence and paths

**Files:**
- Create: `configs/tukf19_hpc_deployment_retry4_v1.json`
- Modify: `scripts/tukf19_hpc_deployment_common.py`
- Test: `tests/test_tukf19_hpc_migration.py`

**Interfaces:**
- Consumes: job 209938 accounting and the four retry-3 evidence hashes.
- Produces: `RETRY4_CONFIG`, `RETRY4_DEPLOYMENT_ID`, and an exact retry-4 repair basis.

- [ ] **Step 1: Add failing retry-4 contract tests**

Assert job 209938, state `FAILED`, exit `1:0`, elapsed five seconds, all pinned hashes, all absent output gates, retry-2 source stderr hash, and retry-4 target. Mutate job, failure hash, source stderr hash, and no-training gate independently and require rejection.

- [ ] **Step 2: Run the focused tests and confirm failure**

Run: `python -m pytest tests/test_tukf19_hpc_migration.py -k retry4 -q`

Expected: failure because retry-4 configuration is not registered.

- [ ] **Step 3: Implement the exact contract and rerun focused tests**

Preserve the retry-3 Slurm and smoke settings. Register status `HPC_WRAPPED_ERROR_POSTPROCESSING_RECOVERY_AUTHORIZED` and the new non-overwriting roots.

Expected: all retry-4 contract tests pass.

### Task 2: Correct only the evidence-layer distinction

**Files:**
- Modify: `scripts/recover_tukf19_hpc_postprocessing.py`
- Test: `tests/test_tukf19_hpc_migration.py`

**Interfaces:**
- Consumes: failure JSON with `RuntimeError` and stderr with `KeyError`.
- Produces: `_verify_source_failure(...)` checks named `wrapped_runtime_error`, `wrapped_plot_step`, `stderr_identity`, `stderr_key_error`, and `stderr_missing_display_contrast`.

- [ ] **Step 1: Add a failing unit test for layered error evidence**

Construct temporary source evidence where the JSON contains only the wrapper error and stderr contains the missing contrast. Assert validation passes only when both layers and the stderr hash match.

- [ ] **Step 2: Run the unit test and confirm failure**

Run: `python -m pytest tests/test_tukf19_hpc_migration.py -k wrapped_error -q`

Expected: failure because the implementation still searches the JSON for the nested cause.

- [ ] **Step 3: Implement the minimal correction**

Read stderr bytes, require its pinned SHA-256, decode UTF-8, and check `KeyError` plus `state_and_hydrology_update_over_no_update` there. Require the JSON error type `RuntimeError`, the phrase `formal HPC step failed`, two successful preceding steps, source job 209845, and retry-2 bundle identity.

- [ ] **Step 4: Point the runner and packaged evidence at retry 4**

Use retry-4 configuration, plan, Slurm file, target, and output names. Accept no retry-3 rerun. Keep the selector, result manifest validation, byte-for-byte copy, plotting, formal-output validation, and deterministic packaging logic unchanged.

- [ ] **Step 5: Run focused and complete regression tests**

Run the retry-4 and training-free tests, followed by the same seven-file regression suite used for retry 3.

Expected: every test passes and no experiment is executed.

### Task 3: Build, submit, retrieve, and audit one retry-4 job

**Files:**
- Create: `hpc/tukf19_hbv_rolling_origin_formal_execution/submit_postprocessing_recovery_cpu_retry4.slurm`
- Modify: `scripts/build_tukf19_hpc_bundle.py`
- Test: `tests/test_tukf19_hpc_migration.py`

**Interfaces:**
- Consumes: retry-4 contract and corrected recovery runner.
- Produces: one deterministic retry-4 bundle, one Slurm job, and one retrieved result archive.

- [ ] **Step 1: Build twice and compare**

Require identical SHA-256, member maps, sizes, and the presence of the retry-4 configuration, plan, runner, and Slurm file.

- [ ] **Step 2: Deploy with exact-once submission protection**

The mailbox command verifies retry-2 and retry-3 evidence, deploys only to the absent retry-4 target, writes the raw `sbatch` output before parsing it, recovers from that output if receipt writing is interrupted, and calls `sbatch` only when neither evidence file exists.

- [ ] **Step 3: Wait and retrieve**

Require Slurm `COMPLETED|0:0`, recovery completion status, result archive and external manifest, then copy them into a new mailbox retrieval path only after archive hash and size verification.

- [ ] **Step 4: Independently audit locally**

Require safe unique archive names, every embedded member hash, the five pinned retry-2 evidence hashes, job 209845 and recovery job identities, 162 readouts, 20,412 errors, 108 histories, 1,701 NumPy archives, all 12 verification checks, all figure-manifest hashes, and exact reconstruction of the display-only selected pair.

- [ ] **Step 5: Report bounded outcomes**

Report technical completion separately from the registered scientific contrast classifications. Do not equate technical recovery with scientific success.

## Self-Review

- Spec coverage: failed evidence, nonmutation, layered error source, unique retry, no training, retrieval, and independent audit are explicit.
- Placeholder scan: no deferred implementation placeholder remains.
- Type consistency: retry-4 identifiers, paths, hashes, functions, and outputs agree across all tasks.

## Execution Handoff

The user has already authorized inline recovery of in-scope technical faults. Execute in the isolated implementation worktree without subagents and stop before any scientific-contract change, publication, cleanup, or scope expansion.
