#!/usr/bin/env python3
"""Independent result and evidence verifier for the A31 causal daily smoke."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
import math
import os
from pathlib import Path, PurePosixPath
import sys

import numpy as np
import torch


EXPERIMENT_ID = (
    "DAILY_CAMELS_OFFICIAL_KALMANNET_TUKF06_CAUSAL_FAIR_"
    "RESOURCE_SMOKE_V3_20260825_A31"
)
BASIN_ID = "09035800"
LEADS = (1, 2, 3)
CONFIGURATION_RELATIVE_PATH = (
    "configs/daily_camels_official_kalmannet_tukf06_causal_fair_development_v3.json"
)
CONFIGURATION_SHA256 = "889e3f554a18b06f2611cb5dfebc8dd38b241d956295a79ede8dc401ce2bf50f"


def _load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"JSON root is not an object: {path}")
    return value


def _sha256(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _close(actual: object, expected: float, label: str, tolerance: float = 1e-10) -> None:
    value = float(actual)
    if not math.isfinite(value) or abs(value - expected) > tolerance:
        raise RuntimeError(f"{label} differs: {value} vs {expected}")


def _nse(target: np.ndarray, prediction: np.ndarray) -> tuple[float, int]:
    valid = np.isfinite(target) & np.isfinite(prediction)
    values = target[valid]
    estimates = prediction[valid]
    if len(values) < 2:
        raise RuntimeError("independent Nash-Sutcliffe efficiency has too few targets")
    denominator = float(np.sum((values - np.mean(values)) ** 2))
    if denominator <= 0.0:
        raise RuntimeError("independent Nash-Sutcliffe denominator is nonpositive")
    return 1.0 - float(np.sum((estimates - values) ** 2)) / denominator, int(valid.sum())


def _verify_smoke_training_contract(
    manifest: dict, diagnostics: dict, gate: dict
) -> dict:
    resolved = manifest.get("resolved_execution")
    family = manifest.get("family")
    command_line = manifest.get("command_line_arguments")
    if (
        manifest.get("seed") != 20260825
        or not isinstance(resolved, dict)
        or resolved.get("training_enabled") is not True
        or resolved.get("training_epochs") != 4
        or resolved.get("optimizer_steps_per_epoch") != 4
        or resolved.get("segment_days") != 60
        or resolved.get("filter_warmup_days") != 15
        or resolved.get("torch_threads") != 2
        or resolved.get("device") != "cuda"
        or not isinstance(resolved.get("cuda_device_name"), str)
        or not resolved["cuda_device_name"]
    ):
        raise RuntimeError("resolved A31 smoke execution contract differs")
    if (
        not isinstance(family, dict)
        or family.get("family_id") != "official_gru_tukf06_causal_fair_daily_base"
        or family.get("network_backend") != "upstream_official_kalmannet_tsp_gru"
        or family.get("training_loss_mode")
        != "training_period_variance_normalized_forecast_mse"
        or family.get("loss_lead_weights") != [1.0 / 3.0] * 3
        or family.get("initialization_mode") != "causal_parameter_only_default"
        or family.get("physical_model_dtype") != "float64"
        or family.get("gain_network_dtype") != "float32"
        or family.get("require_trained_checkpoint_after_epoch_zero") is not True
    ):
        raise RuntimeError("A31 model, loss, or initialization contract differs")
    if not isinstance(command_line, list) or "--family-id" in command_line:
        raise RuntimeError("A31 command-line family contract differs")
    required_arguments = {
        "--mode": "smoke",
        "--seed": "20260825",
        "--basins": BASIN_ID,
        "--epochs": "4",
        "--steps-per-epoch": "4",
        "--segment-days": "60",
        "--warmup-days": "15",
        "--threads": "2",
        "--device": "cuda",
        "--prepared-data-root": "inputs",
    }
    for flag, expected in required_arguments.items():
        if command_line.count(flag) != 1:
            raise RuntimeError(f"A31 command-line flag differs: {flag}")
        position = command_line.index(flag)
        if position + 1 >= len(command_line) or command_line[position + 1] != expected:
            raise RuntimeError(f"A31 command-line value differs: {flag}")

    history = diagnostics.get("history")
    if not isinstance(history, list) or len(history) != 5:
        raise RuntimeError("A31 history must contain epoch zero plus four epochs")
    expected_best_epoch = 0
    epoch_zero_score = float(history[0]["continuous_validation_selection"]["selection_score"])
    expected_best_score = epoch_zero_score
    validation_losses: list[float] = []
    total_optimizer_steps = 0
    for expected_epoch, record in enumerate(history):
        if record.get("epoch") != expected_epoch:
            raise RuntimeError("A31 epoch sequence differs")
        loss = float(record.get("validation_loss", float("nan")))
        score = float(
            record.get("continuous_validation_selection", {}).get(
                "selection_score", float("nan")
            )
        )
        if not math.isfinite(loss) or not math.isfinite(score):
            raise RuntimeError("A31 validation loss or selection score is nonfinite")
        validation_losses.append(loss)
        steps = int(record.get("optimizer_steps", -1))
        if steps != (0 if expected_epoch == 0 else 4):
            raise RuntimeError("A31 per-epoch optimizer step count differs")
        total_optimizer_steps += steps
        if expected_epoch > 0 and score > expected_best_score + 1.0e-6:
            expected_best_score = score
            expected_best_epoch = expected_epoch
        _close(
            record.get("best_selection_score"),
            expected_best_score,
            f"epoch {expected_epoch} cumulative best selection score",
        )
    if total_optimizer_steps != 16:
        raise RuntimeError("A31 total optimizer step count differs")

    final_attempts = history[-1].get("basin_sampling_attempt_counts_cumulative")
    final_steps = history[-1].get("basin_optimizer_step_counts_cumulative")
    if (
        final_attempts != {BASIN_ID: 16}
        or final_steps != {BASIN_ID: 16}
        or diagnostics.get("basin_sampling_attempt_counts") != final_attempts
        or diagnostics.get("basin_optimizer_step_counts") != final_steps
        or diagnostics.get("skipped_steps") != 0
        or int(diagnostics.get("nonzero_gradient_parameter_tensor_count", 0)) <= 0
        or diagnostics.get("epochs_completed") != 4
        or diagnostics.get("history_entry_count_including_epoch_zero") != 5
    ):
        raise RuntimeError("A31 sampling, gradient, or completion evidence differs")

    selection_improvement = expected_best_score - epoch_zero_score
    selected_validation_loss = validation_losses[expected_best_epoch]
    validation_loss_improvement = validation_losses[0] - selected_validation_loss
    if (
        diagnostics.get("seed") != 20260825
        or diagnostics.get("best_epoch") != expected_best_epoch
        or diagnostics.get("trained_checkpoint_selected")
        is not (expected_best_epoch > 0)
    ):
        raise RuntimeError("A31 selected epoch identity differs")
    _close(
        diagnostics.get("initial_selection_score"),
        epoch_zero_score,
        "epoch-zero selection score",
    )
    _close(
        diagnostics.get("best_selection_score"),
        expected_best_score,
        "recomputed best selection score",
    )
    _close(
        diagnostics.get("selection_score_improvement_over_epoch_zero"),
        selection_improvement,
        "recomputed selection score improvement",
    )
    _close(
        diagnostics.get("initial_validation_loss"),
        validation_losses[0],
        "epoch-zero validation loss",
    )
    _close(
        diagnostics.get("selected_validation_loss"),
        selected_validation_loss,
        "selected validation loss",
    )
    _close(
        diagnostics.get("best_validation_loss"),
        selected_validation_loss,
        "selected checkpoint validation loss",
    )
    _close(
        diagnostics.get("validation_loss_improvement_over_epoch_zero"),
        validation_loss_improvement,
        "recomputed validation loss improvement",
    )
    training_effect = bool(
        expected_best_epoch > 0
        and selection_improvement > 0.0
        and validation_loss_improvement > 0.0
    )
    gate_effect = gate.get("training_effect", {})
    if (
        gate_effect.get("passed") is not training_effect
        or gate_effect.get("selected_epoch") != expected_best_epoch
    ):
        raise RuntimeError("A31 reported training-effect gate differs")
    _close(
        gate_effect.get("selection_score_improvement_over_epoch_zero"),
        selection_improvement,
        "gate selection score improvement",
    )
    _close(
        gate_effect.get("validation_loss_improvement_over_epoch_zero"),
        validation_loss_improvement,
        "gate validation loss improvement",
    )
    return {
        "best_epoch": expected_best_epoch,
        "optimizer_steps": total_optimizer_steps,
        "selection_score_improvement_over_epoch_zero": selection_improvement,
        "validation_loss_improvement_over_epoch_zero": validation_loss_improvement,
        "training_effect_passed": training_effect,
    }


def verify(run_directory: Path, status_directory: Path, job_id: str) -> dict:
    run = run_directory.resolve()
    status = status_directory.resolve()
    required = (
        run / "manifest.json",
        run / "config.json",
        run / "training_diagnostics.json",
        run / "per_basin_metrics.json",
        run / "per_basin_metrics.csv",
        run / "predictions.npz",
        run / "best_model.pt",
        run / "validation_gate.json",
        run / ".run.lock",
        run / "source_snapshot" / "source_manifest.json",
        run / "prepared_data_snapshot" / "prepared_manifest.json",
        status / f"train-preflight-{job_id}.json",
    )
    if any(not path.is_file() or path.is_symlink() for path in required):
        raise RuntimeError("required run evidence is absent or symbolic")
    if any(path.is_symlink() for path in run.rglob("*")):
        raise RuntimeError("run evidence contains a symbolic link")

    manifest = _load_json(run / "manifest.json")
    configuration = _load_json(run / "config.json")
    diagnostics = _load_json(run / "training_diagnostics.json")
    rows = json.loads((run / "per_basin_metrics.json").read_text(encoding="utf-8"))
    gate = _load_json(run / "validation_gate.json")
    lock = _load_json(run / ".run.lock")
    source_snapshot = _load_json(run / "source_snapshot" / "source_manifest.json")
    prepared_snapshot = _load_json(
        run / "prepared_data_snapshot" / "prepared_manifest.json"
    )
    preflight = _load_json(status / f"train-preflight-{job_id}.json")

    if (
        manifest.get("schema_version") != "hbv_native_shortlead_recovery_v2"
        or manifest.get("experiment_id") != "HSR02"
        or manifest.get("run_id") != EXPERIMENT_ID
        or manifest.get("mode") != "smoke"
        or manifest.get("training_basin_ids") != [BASIN_ID]
        or manifest.get("evaluation_basin_ids") != [BASIN_ID]
        or manifest.get("scientific_claim_allowed") is not True
        or manifest.get("trusted_file_hash_mismatches") != {}
    ):
        raise RuntimeError("run identity or trusted-source contract differs")
    prepared = manifest.get("prepared_calibration_data", {})
    if (
        prepared.get("calibration_only") is not True
        or prepared.get("evaluation_data_included") is not False
        or prepared.get("reserved_data_member_count") != 0
        or prepared.get("future_derived_member_read_count") != 0
        or prepared.get("basin_count") != 1
    ):
        raise RuntimeError("run prepared-data isolation evidence differs")
    if (
        prepared_snapshot.get("evaluation_data_included") is not False
        or prepared_snapshot.get("future_derived_member_read_count") != 0
        or prepared_snapshot.get("basin_count") != 21
    ):
        raise RuntimeError("snapshotted prepared-data evidence differs")
    prepared_snapshot_path = run / "prepared_data_snapshot" / "prepared_manifest.json"
    if _sha256(prepared_snapshot_path) != prepared.get("producer_manifest_sha256"):
        raise RuntimeError("snapshotted prepared-data manifest hash differs")
    if lock.get("status") != "complete":
        raise RuntimeError("run owner lock does not prove clean completion")

    executable_hashes = manifest.get("executable_sha256", {})
    snapshot_rows = source_snapshot.get("files", [])
    if not isinstance(executable_hashes, dict) or not isinstance(snapshot_rows, list):
        raise RuntimeError("source snapshot inventory has the wrong type")
    if (
        source_snapshot.get("file_count") != len(snapshot_rows)
        or len(snapshot_rows) != len(executable_hashes)
    ):
        raise RuntimeError("source snapshot count differs")
    repository_root = Path(source_snapshot["repository_root_at_execution"]).resolve()
    configuration_source = str(
        repository_root.joinpath(*PurePosixPath(CONFIGURATION_RELATIVE_PATH).parts).resolve()
    )
    if executable_hashes.get(configuration_source) != CONFIGURATION_SHA256:
        raise RuntimeError("frozen A31 configuration source hash differs")
    if (
        configuration.get("experiment_id") != "HSR02"
        or configuration.get("family") != manifest.get("family")
        or configuration.get("forecast", {}).get("leads_days") != list(LEADS)
        or configuration.get("run_policy", {}).get("formal_evaluation_enabled")
        is not False
    ):
        raise RuntimeError("snapshotted A31 configuration content differs")
    seen_sources: set[str] = set()
    seen_relatives: set[str] = set()
    for record in snapshot_rows:
        relative_text = str(record.get("relative_path", ""))
        relative = PurePosixPath(relative_text)
        if (
            relative.is_absolute()
            or not relative.parts
            or ".." in relative.parts
            or "\\" in relative_text
            or relative_text in seen_relatives
        ):
            raise RuntimeError(f"unsafe or duplicate source snapshot path: {relative_text}")
        source_path = str(repository_root.joinpath(*relative.parts).resolve())
        copied_path = run.joinpath("source_snapshot", *relative.parts)
        expected_hash = executable_hashes.get(source_path)
        if (
            source_path in seen_sources
            or record.get("source_absolute_path") != source_path
            or expected_hash is None
            or record.get("sha256") != expected_hash
            or not copied_path.is_file()
            or copied_path.is_symlink()
            or copied_path.stat().st_size != int(record.get("size_bytes", -1))
            or _sha256(copied_path) != expected_hash
        ):
            raise RuntimeError(f"source snapshot identity differs: {relative_text}")
        seen_sources.add(source_path)
        seen_relatives.add(relative_text)
    if seen_sources != set(executable_hashes):
        raise RuntimeError("source snapshot exact source set differs")

    training_contract = _verify_smoke_training_contract(manifest, diagnostics, gate)
    best_epoch = int(training_contract["best_epoch"])
    optimizer_steps = int(training_contract["optimizer_steps"])
    improvement = float(
        training_contract["selection_score_improvement_over_epoch_zero"]
    )
    validation_loss_improvement = float(
        training_contract["validation_loss_improvement_over_epoch_zero"]
    )
    training_effect = bool(training_contract["training_effect_passed"])
    if gate.get("scientific_initialization", {}).get("passed") is not True:
        raise RuntimeError("causal initialization gate failed")

    try:
        checkpoint = torch.load(
            run / "best_model.pt", map_location="cpu", weights_only=True
        )
    except TypeError:
        checkpoint = torch.load(run / "best_model.pt", map_location="cpu")
    if (
        not isinstance(checkpoint, dict)
        or checkpoint.get("seed") != 20260825
        or checkpoint.get("family") != manifest.get("family")
        or checkpoint.get("training_basin_ids") != [BASIN_ID]
        or checkpoint.get("training_diagnostics") != diagnostics
        or not isinstance(checkpoint.get("state_dict"), dict)
        or not checkpoint["state_dict"]
    ):
        raise RuntimeError("best checkpoint is not bound to the selected epoch evidence")

    if not isinstance(rows, list) or len(rows) != 1 or rows[0].get("basin") != BASIN_ID:
        raise RuntimeError("per-basin metric population differs")
    row = rows[0]
    if (
        row.get("initialization_mode") != "causal_parameter_only_default"
        or row.get("physical_model_dtype") != "float64"
        or row.get("gain_network_dtype") != "float32"
        or row.get("metric_common_issue_count") != 712
        or row.get("numerical_failure") is not False
    ):
        raise RuntimeError("per-basin causal geometry or dtype evidence differs")

    with np.load(run / "predictions.npz", allow_pickle=False) as archive:
        target = np.asarray(archive[f"basin_{BASIN_ID}__target"], dtype=np.float64)
        open_loop = np.asarray(
            archive[f"basin_{BASIN_ID}__open_loop"], dtype=np.float64
        )
        recomputed = {}
        for lead in LEADS:
            prediction = np.asarray(
                archive[f"basin_{BASIN_ID}__prediction_lead_{lead}"],
                dtype=np.float64,
            )
            method_nse, method_count = _nse(target, prediction)
            baseline = np.where(np.isfinite(prediction), open_loop, np.nan)
            open_nse, open_count = _nse(target, baseline)
            if method_count != 712 or open_count != 712:
                raise RuntimeError(f"lead {lead} target count differs")
            _close(row["nse_method"][str(lead)], method_nse, f"lead {lead} method NSE")
            _close(row["nse_open_loop"][str(lead)], open_nse, f"lead {lead} open-loop NSE")
            _close(
                row["gain_over_open_loop"][str(lead)],
                method_nse - open_nse,
                f"lead {lead} gain",
            )
            recomputed[str(lead)] = {
                "method_nse": method_nse,
                "open_loop_nse": open_nse,
                "gain": method_nse - open_nse,
                "target_count": method_count,
            }

    resources = gate.get("resource_observation", {})
    host_peak = resources.get("process_peak_resident_memory_bytes")
    gpu_peak = resources.get("cuda_peak_allocated_bytes")
    gpu_reserved = resources.get("cuda_peak_reserved_bytes")
    if (
        not isinstance(host_peak, int)
        or host_peak <= 0
        or not isinstance(gpu_peak, int)
        or gpu_peak <= 0
        or not isinstance(gpu_reserved, int)
        or gpu_reserved < gpu_peak
        or preflight.get("status") != "PREFLIGHT_PASS"
        or preflight.get("experiment_id") != EXPERIMENT_ID
        or str(preflight.get("slurm_job_id")) != str(job_id)
        or preflight.get("strict_zero_probe_passed") is not True
        or preflight.get("physical_model_dtype") != "float64"
        or preflight.get("gain_network_dtype") != "float32"
        or preflight.get("prepared_archives_verified") != 21
        or preflight.get("run_directory_absent") is not True
        or int(preflight.get("available_host_memory_bytes", 0))
        < int(preflight.get("minimum_available_host_bytes", 1))
        or int(preflight.get("cuda_free_bytes", 0))
        < int(preflight.get("minimum_free_gpu_bytes", 1))
        or host_peak >= int(preflight["available_host_memory_bytes"])
        or gpu_reserved >= int(preflight["cuda_free_bytes"])
    ):
        raise RuntimeError("resource measurement or admission evidence differs")

    method_nse = {lead: recomputed[str(lead)]["method_nse"] for lead in LEADS}
    all_leads_above_point_six = all(value >= 0.60 for value in method_nse.values())
    report = {
        "schema_version": "daily_camels_official_kalmannet_a31_verification_v2",
        "status": "TECHNICAL_EVIDENCE_VERIFIED",
        "experiment_id": EXPERIMENT_ID,
        "job_id": str(job_id),
        "basin_id": BASIN_ID,
        "best_epoch": best_epoch,
        "optimizer_steps": optimizer_steps,
        "selection_score_improvement_over_epoch_zero": improvement,
        "validation_loss_improvement_over_epoch_zero": validation_loss_improvement,
        "training_effect_passed": training_effect,
        "all_leads_median_nse_at_least_0_60": all_leads_above_point_six,
        "reported_gate_passed": bool(gate.get("passed")),
        "recomputed_metrics": recomputed,
        "process_peak_resident_memory_bytes": host_peak,
        "cuda_peak_allocated_bytes": gpu_peak,
        "cuda_peak_reserved_bytes": gpu_reserved,
        "reserved_evaluation_data_accessed": False,
        "future_derived_state_member_read_count": 0,
        "best_model_sha256": _sha256(run / "best_model.pt"),
        "predictions_sha256": _sha256(run / "predictions.npz"),
        "manifest_sha256": _sha256(run / "manifest.json"),
    }
    return report


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-directory", type=Path, required=True)
    parser.add_argument("--status-directory", type=Path, required=True)
    parser.add_argument("--job-id", required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    try:
        report = verify(arguments.run_directory, arguments.status_directory, arguments.job_id)
    except Exception as error:
        print(
            json.dumps(
                {
                    "status": "VERIFICATION_FAIL",
                    "error_type": type(error).__name__,
                    "error": str(error),
                },
                sort_keys=True,
            ),
            flush=True,
        )
        return 1
    content = (json.dumps(report, sort_keys=True, separators=(",", ":")) + "\n").encode(
        "utf-8"
    )
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(
        arguments.output,
        os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
        0o600,
    )
    try:
        os.write(descriptor, content)
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    print(json.dumps(report, indent=2, sort_keys=True), flush=True)
    if report.get("training_effect_passed") is not True:
        print(
            json.dumps(
                {
                    "status": "POST_ZERO_TRAINING_EFFECT_HARD_STOP",
                    "best_epoch": report.get("best_epoch"),
                    "selection_score_improvement_over_epoch_zero": report.get(
                        "selection_score_improvement_over_epoch_zero"
                    ),
                },
                sort_keys=True,
            ),
            flush=True,
        )
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
