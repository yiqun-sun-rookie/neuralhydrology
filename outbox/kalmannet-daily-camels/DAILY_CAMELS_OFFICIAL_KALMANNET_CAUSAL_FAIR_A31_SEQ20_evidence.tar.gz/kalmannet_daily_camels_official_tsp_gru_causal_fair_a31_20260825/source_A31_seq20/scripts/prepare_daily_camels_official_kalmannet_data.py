"""Sanitize TUKF06 development inputs for causal daily KalmanNet training.

The source archives contain development-period inputs plus several stored filter
initial-state members. Those state members were produced for the historical
backward-time diagnostic and must never be materialized here. This producer
reads only dates, meteorological forcing, discharge observations, HBV
parameters, and the source state dimension. It then derives a parameter-only
causal storage state for 1999-10-01.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
from typing import Mapping

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from global_hydrology.experiments.hbv_shortlead_contract import (
    ShortLeadContract,
    sha256_file,
)
from global_hydrology.models.differentiable_hbv_lite import PARAM_NAMES


DEFAULT_CONFIG = (
    ROOT
    / "configs"
    / "daily_camels_official_kalmannet_tukf06_causal_fair_development_v3.json"
)
DEFAULT_TUKF06_CONFIG = (
    ROOT / "configs" / "tukf06_full_diagonal_search_head_to_head_v1.json"
)
DEFAULT_SELECTION_INPUT_ROOT = (
    ROOT
    / "results"
    / "tukf06_full_diagonal_search_head_to_head_v1"
    / "selection_inputs"
)
DEFAULT_SELECTION_MANIFEST = (
    ROOT
    / "results"
    / "tukf06_full_diagonal_search_head_to_head_v1"
    / "selection_manifest.sha256.json"
)
PREPARED_BASIN_SCHEMA = "daily_camels_official_kalmannet_prepared_basin_v1"
PREPARED_MANIFEST_SCHEMA = "daily_camels_official_kalmannet_prepared_manifest_v1"
INITIALIZATION_MODE = "causal_parameter_only_default"
SAFE_SOURCE_MEMBERS = (
    "dates_ns",
    "forcing",
    "observations",
    "parameters",
    "state_dimension",
)
FORBIDDEN_SOURCE_MEMBERS = (
    "initial_storage_state",
    "initial_state",
    "initial_covariance",
)
EXPECTED_SOURCE_MEMBERS = frozenset(
    SAFE_SOURCE_MEMBERS
    + FORBIDDEN_SOURCE_MEMBERS
    + ("base_observation_variance",)
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--tukf06-config", type=Path, default=DEFAULT_TUKF06_CONFIG)
    parser.add_argument(
        "--selection-input-root", type=Path, default=DEFAULT_SELECTION_INPUT_ROOT
    )
    parser.add_argument(
        "--selection-manifest", type=Path, default=DEFAULT_SELECTION_MANIFEST
    )
    parser.add_argument("--output-root", type=Path, required=True)
    return parser.parse_args()


def _semantic_sha256(arrays: Mapping[str, np.ndarray]) -> str:
    digest = hashlib.sha256()
    for name in sorted(arrays):
        value = np.ascontiguousarray(arrays[name])
        digest.update(name.encode("utf-8"))
        digest.update(str(value.dtype).encode("ascii"))
        digest.update(np.asarray(value.shape, dtype=np.int64).tobytes())
        digest.update(value.tobytes())
    return digest.hexdigest()


def _atomic_npz(path: Path, arrays: Mapping[str, np.ndarray]) -> None:
    if path.exists():
        raise FileExistsError(f"refusing to overwrite prepared archive: {path}")
    temporary = path.with_name(path.name + ".partial.npz")
    if temporary.exists():
        raise FileExistsError(f"partial prepared archive already exists: {temporary}")
    np.savez_compressed(temporary, **arrays)
    temporary.replace(path)


def _atomic_json(path: Path, payload: Mapping[str, object]) -> None:
    if path.exists():
        raise FileExistsError(f"refusing to overwrite manifest: {path}")
    temporary = path.with_name(path.name + ".partial")
    if temporary.exists():
        raise FileExistsError(f"partial manifest already exists: {temporary}")
    temporary.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def _expected_daily_dates(start: str, end: str) -> np.ndarray:
    return np.arange(
        np.datetime64(start, "D"),
        np.datetime64(end, "D") + np.timedelta64(1, "D"),
        dtype="datetime64[D]",
    )


def _validate_contracts(
    contract: ShortLeadContract,
    config_payload: Mapping[str, object],
    tukf06: Mapping[str, object],
) -> tuple[tuple[str, ...], dict[str, int], tuple[str, str]]:
    basins = tuple(str(value).zfill(8) for value in tukf06["basins"])
    if basins != tuple(contract.training_basins):
        raise ValueError("KalmanNet and TUKF06 basin order differs")
    if contract.holdout_basins:
        raise ValueError("causal development sanitizer rejects holdout basins")
    if contract.formal_evaluation_enabled:
        raise ValueError("causal development sanitizer rejects formal evaluation")

    periods = tukf06["periods"]
    training_period = tuple(str(value) for value in periods["training"])
    validation_period = tuple(str(value) for value in periods["validation"])
    calibration_period = tuple(contract.periods.calibration)
    if calibration_period != (training_period[0], validation_period[1]):
        raise ValueError("KalmanNet calibration period differs from TUKF06 development period")
    expected_validation_start = np.datetime64(training_period[1], "D") + np.timedelta64(1, "D")
    if np.datetime64(validation_period[0], "D") != expected_validation_start:
        raise ValueError("TUKF06 training and validation periods are not contiguous")
    validation_days = len(_expected_daily_dates(*validation_period))
    if validation_days != contract.periods.calibration_validation_days:
        raise ValueError("KalmanNet and TUKF06 validation geometry differs")

    data_contract = config_payload.get("data_contract")
    if not isinstance(data_contract, Mapping):
        raise ValueError("KalmanNet data contract is missing")
    if tuple(data_contract.get("portable_members", ())) != SAFE_SOURCE_MEMBERS:
        raise ValueError("portable source-member contract differs")
    if tuple(data_contract.get("forbidden_source_members", ())) != FORBIDDEN_SOURCE_MEMBERS:
        raise ValueError("forbidden source-member contract differs")
    if int(data_contract.get("reserved_evaluation_member_count", -1)) != 0:
        raise ValueError("KalmanNet data contract permits reserved evaluation members")
    family = config_payload.get("family")
    if not isinstance(family, Mapping) or family.get("initialization_mode") != INITIALIZATION_MODE:
        raise ValueError("KalmanNet initialization is not the causal parameter-only mode")

    state_dimensions = {
        str(key).zfill(8): int(value)
        for key, value in tukf06["expected_state_dimensions"].items()
    }
    if tuple(state_dimensions) != basins:
        raise ValueError("TUKF06 state-dimension table order differs from basin order")
    return basins, state_dimensions, calibration_period


def _read_safe_source_members(
    path: Path,
    *,
    basin_id: str,
    calibration_period: tuple[str, str],
    expected_state_dimension: int,
    expected_file_sha256: str,
) -> tuple[dict[str, np.ndarray], dict[str, object]]:
    if not path.is_file():
        raise FileNotFoundError(f"TUKF06 selection input does not exist: {path}")
    actual_file_sha256 = sha256_file(path)
    if actual_file_sha256 != expected_file_sha256:
        raise ValueError(f"TUKF06 selection input hash differs for {basin_id}")
    with np.load(path, allow_pickle=False) as stored:
        source_members = tuple(stored.files)
        if set(source_members) != set(EXPECTED_SOURCE_MEMBERS):
            raise ValueError(f"TUKF06 source-member set differs for {basin_id}")
        # Deliberately materialize only the five whitelisted development members.
        dates_ns = np.asarray(stored["dates_ns"]).copy()
        forcing = np.asarray(stored["forcing"]).copy()
        observations = np.asarray(stored["observations"]).copy()
        parameters = np.asarray(stored["parameters"]).copy()
        state_dimension_array = np.asarray(stored["state_dimension"]).copy()
    if sha256_file(path) != actual_file_sha256:
        raise RuntimeError(f"TUKF06 selection input changed while reading {basin_id}")

    expected_dates = _expected_daily_dates(*calibration_period)
    if dates_ns.shape != (len(expected_dates),) or dates_ns.dtype != np.dtype("int64"):
        raise ValueError(f"TUKF06 date geometry or dtype differs for {basin_id}")
    expected_dates_ns = expected_dates.astype("datetime64[ns]").astype(np.int64)
    if not np.array_equal(dates_ns, expected_dates_ns):
        raise ValueError(f"TUKF06 dates differ from the exact development calendar for {basin_id}")
    dates = dates_ns.astype("datetime64[ns]").astype("datetime64[D]")
    if forcing.shape != (len(expected_dates), 3) or forcing.dtype != np.dtype("float64"):
        raise ValueError(f"TUKF06 forcing geometry or dtype differs for {basin_id}")
    if observations.shape != (len(expected_dates),) or observations.dtype != np.dtype("float64"):
        raise ValueError(f"TUKF06 observations geometry or dtype differs for {basin_id}")
    if parameters.shape != (1, len(PARAM_NAMES)) or parameters.dtype != np.dtype("float64"):
        raise ValueError(f"TUKF06 parameter geometry or dtype differs for {basin_id}")
    if state_dimension_array.shape != (1,) or state_dimension_array.dtype != np.dtype("int64"):
        raise ValueError(f"TUKF06 state-dimension geometry or dtype differs for {basin_id}")
    if not np.isfinite(forcing).all() or not np.isfinite(parameters).all():
        raise ValueError(f"TUKF06 physical inputs are nonfinite for {basin_id}")
    if np.isinf(observations).any() or int(np.isfinite(observations).sum()) < 2:
        raise ValueError(f"TUKF06 observations are invalid for {basin_id}")

    state_dimension = int(state_dimension_array.item())
    if state_dimension != expected_state_dimension:
        raise ValueError(f"TUKF06 state dimension differs for {basin_id}")
    parameter_vector = parameters.reshape(-1)
    active_lag = max(
        1,
        int(math.ceil(float(parameter_vector[PARAM_NAMES.index("lag_time")]))),
    )
    if state_dimension != 5 + active_lag:
        raise ValueError(f"TUKF06 state dimension and routing lag differ for {basin_id}")

    field_capacity = float(parameter_vector[PARAM_NAMES.index("parFC")])
    initial_storage = np.asarray(
        [0.0, 0.0, 0.3 * field_capacity, 5.0, 10.0], dtype=np.float64
    )
    arrays = {
        "schema_version": np.asarray(PREPARED_BASIN_SCHEMA),
        "basin_id": np.asarray(basin_id),
        "calibration_start": np.asarray(calibration_period[0]),
        "calibration_end": np.asarray(calibration_period[1]),
        "initialization_mode": np.asarray(INITIALIZATION_MODE),
        "parameter_names": np.asarray(PARAM_NAMES),
        "params": parameter_vector.astype(np.float64, copy=True),
        "initial_storage": initial_storage,
        "source_state_dimension": np.asarray(state_dimension, dtype=np.int64),
        "forcing_calibration": forcing.astype(np.float64, copy=False),
        "observation_calibration": observations.astype(np.float64, copy=False),
        "dates_calibration": np.asarray([str(value) for value in dates], dtype="U10"),
    }
    source_record = {
        "basin_id": basin_id,
        "path": str(path),
        "sha256": actual_file_sha256,
        "size_bytes": int(path.stat().st_size),
        "members_present": list(source_members),
        "safe_members_materialized": list(SAFE_SOURCE_MEMBERS),
        "forbidden_members_materialized": [],
        "source_state_dimension": state_dimension,
    }
    return arrays, source_record


def main() -> None:
    args = parse_args()
    config_path = args.config.resolve()
    tukf06_config_path = args.tukf06_config.resolve()
    selection_input_root = args.selection_input_root.resolve()
    selection_manifest_path = args.selection_manifest.resolve()
    output_root = args.output_root.resolve()
    if output_root.exists():
        raise FileExistsError(f"prepared output directory already exists: {output_root}")

    config_payload = _load_json(config_path)
    contract = ShortLeadContract.from_dict(config_payload)
    trusted_mismatches = contract.verify_hashes(ROOT)
    if trusted_mismatches:
        raise ValueError(f"trusted source hash mismatch: {trusted_mismatches}")
    tukf06_payload = _load_json(tukf06_config_path)
    selection_manifest = _load_json(selection_manifest_path)
    basins, state_dimensions, calibration_period = _validate_contracts(
        contract, config_payload, tukf06_payload
    )
    if not selection_input_root.is_dir():
        raise FileNotFoundError(
            f"TUKF06 selection-input directory does not exist: {selection_input_root}"
        )
    if selection_manifest.get("status") != "SELECTION_COMPLETE":
        raise ValueError("TUKF06 selection evidence is incomplete")
    if selection_manifest.get("evaluation_period_read") is not False:
        raise ValueError("TUKF06 selection evidence accessed the evaluation period")
    if selection_manifest.get("experiment_id") != tukf06_payload.get("experiment_id"):
        raise ValueError("TUKF06 selection evidence experiment differs")
    if selection_manifest.get("contract_sha256") != sha256_file(tukf06_config_path):
        raise ValueError("TUKF06 selection evidence contract hash differs")
    data_contract = config_payload["data_contract"]
    expected_selection_manifest = (
        ROOT / str(data_contract["source_selection_manifest"])
    ).resolve()
    if selection_manifest_path != expected_selection_manifest:
        raise ValueError("TUKF06 selection manifest path differs from the frozen contract")
    if data_contract.get("source_selection_manifest_sha256") != sha256_file(
        selection_manifest_path
    ):
        raise ValueError("TUKF06 selection manifest hash differs from the frozen contract")
    selection_file_hashes = selection_manifest.get("files")
    if not isinstance(selection_file_hashes, dict):
        raise ValueError("TUKF06 selection evidence file hashes are missing")
    expected_names = {f"basin_{basin_id}.npz" for basin_id in basins}
    actual_names = {path.name for path in selection_input_root.glob("basin_*.npz")}
    if actual_names != expected_names:
        raise ValueError("TUKF06 selection-input file set differs from the exact 21 basins")

    output_root.mkdir(parents=True, exist_ok=False)
    prepared_records: list[dict[str, object]] = []
    source_records: list[dict[str, object]] = []
    for position, basin_id in enumerate(basins, start=1):
        source_path = selection_input_root / f"basin_{basin_id}.npz"
        arrays, source_record = _read_safe_source_members(
            source_path,
            basin_id=basin_id,
            calibration_period=calibration_period,
            expected_state_dimension=state_dimensions[basin_id],
            expected_file_sha256=str(
                selection_file_hashes.get(
                    f"selection_inputs/basin_{basin_id}.npz", ""
                )
            ),
        )
        destination = output_root / f"{basin_id}.npz"
        _atomic_npz(destination, arrays)
        prepared_records.append(
            {
                "basin_id": basin_id,
                "path": destination.name,
                "sha256": sha256_file(destination),
                "semantic_sha256": _semantic_sha256(arrays),
                "size_bytes": int(destination.stat().st_size),
                "day_count": int(len(arrays["dates_calibration"])),
                "finite_observation_count": int(
                    np.isfinite(arrays["observation_calibration"]).sum()
                ),
                "source_state_dimension": int(arrays["source_state_dimension"]),
            }
        )
        source_records.append(source_record)
        print(
            f"PREPARED {position:02d}/{len(basins):02d} basin={basin_id}",
            flush=True,
        )

    producer_path = Path(__file__).resolve()
    parameter_source = (
        ROOT / "src" / "global_hydrology" / "models" / "differentiable_hbv_lite.py"
    ).resolve()
    manifest = {
        "schema_version": PREPARED_MANIFEST_SCHEMA,
        "calibration_only": True,
        "evaluation_data_included": False,
        "reserved_data_member_count": 0,
        "future_derived_member_read_count": 0,
        "initialization_mode": INITIALIZATION_MODE,
        "basin_ids": list(basins),
        "basin_count": len(basins),
        "calibration_period": list(calibration_period),
        "safe_source_members_materialized": list(SAFE_SOURCE_MEMBERS),
        "forbidden_source_members_not_materialized": list(FORBIDDEN_SOURCE_MEMBERS),
        "files": prepared_records,
        "source_archives": source_records,
        "producer_sources": {
            "config": {"path": str(config_path), "sha256": sha256_file(config_path)},
            "tukf06_config": {
                "path": str(tukf06_config_path),
                "sha256": sha256_file(tukf06_config_path),
            },
            "tukf06_selection_manifest": {
                "path": str(selection_manifest_path),
                "sha256": sha256_file(selection_manifest_path),
            },
            "producer": {"path": str(producer_path), "sha256": sha256_file(producer_path)},
            "parameter_definition": {
                "path": str(parameter_source),
                "sha256": sha256_file(parameter_source),
            },
        },
    }
    _atomic_json(output_root / "prepared_manifest.json", manifest)


if __name__ == "__main__":
    main()
