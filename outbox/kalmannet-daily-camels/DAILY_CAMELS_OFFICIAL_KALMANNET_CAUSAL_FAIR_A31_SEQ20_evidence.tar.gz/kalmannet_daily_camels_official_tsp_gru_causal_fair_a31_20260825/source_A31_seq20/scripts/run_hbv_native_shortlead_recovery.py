"""Run the frozen HBV native-KalmanNet short-lead recovery experiment."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import socket
import sys
import time

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT / "src", Path("G:/github/pycharm/projects/neuralhydrology") / "src"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from global_hydrology.data.hbvlite_prior import load_hbvlite_prior
from global_hydrology.experiments.hbv_shortlead_contract import ShortLeadContract, sha256_file
from global_hydrology.experiments.hbv_shortlead_runner import (
    atomic_write_json,
    audit_archived_storage_only,
    build_shared_network,
    configure_runtime_device,
    evaluate_basin,
    evaluate_formal_gate,
    prepare_basin,
    train_shared_network,
    write_metric_csv,
)


DEFAULT_CONFIG = ROOT / "configs" / "hbv_native_shortlead_recovery_v1.json"
DEFAULT_ARCHIVE = ROOT / "results" / "iter_diag" / "knet_native_shared_holdout_lead14.json"
DEFAULT_ITERATIONS = ROOT / "configs" / "hbv_native_shortlead_recovery_iterations.json"
PREPARED_MANIFEST_SCHEMA = "daily_camels_official_kalmannet_prepared_manifest_v1"
CAUSAL_PARAMETER_ONLY_INITIALIZATION = "causal_parameter_only_default"
PREPARED_SAFE_SOURCE_MEMBERS = (
    "dates_ns",
    "forcing",
    "observations",
    "parameters",
    "state_dimension",
)
PREPARED_FORBIDDEN_SOURCE_MEMBERS = (
    "initial_storage_state",
    "initial_state",
    "initial_covariance",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mode",
        choices=("audit-archive", "smoke", "development", "transfer", "formal"),
        required=True,
    )
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--archive", type=Path, default=DEFAULT_ARCHIVE)
    parser.add_argument("--iteration-config", type=Path, default=DEFAULT_ITERATIONS)
    parser.add_argument("--family-id", type=str, default=None)
    parser.add_argument("--checkpoint", type=Path, default=None)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--basin-limit", type=int, default=4)
    parser.add_argument("--basin-offset", type=int, default=0)
    parser.add_argument("--basins", nargs="+", default=None, help="development modes only")
    parser.add_argument("--epochs", type=int, default=None, help="smoke/development only")
    parser.add_argument("--steps-per-epoch", type=int, default=None, help="smoke/development only")
    parser.add_argument("--segment-days", type=int, default=None, help="smoke/development only")
    parser.add_argument("--warmup-days", type=int, default=None, help="smoke/development only")
    parser.add_argument("--threads", type=int, default=6)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument(
        "--prepared-data-root",
        type=Path,
        default=None,
        help="portable calibration-only basin archives; formal evaluation is forbidden",
    )
    return parser.parse_args()


def _resolve_family(base_family: dict, iteration_payload: dict, family_id: str) -> dict:
    families = iteration_payload["families"]
    visiting: set[str] = set()

    def resolve(current_id: str) -> dict:
        if current_id == base_family["family_id"]:
            return dict(base_family)
        if current_id in visiting:
            raise SystemExit("cycle in iteration family ancestry")
        if current_id not in families:
            raise SystemExit(f"unknown family-id {current_id!r}")
        visiting.add(current_id)
        record = families[current_id]
        merged = resolve(record["parent_family"])
        merged.update(record["overrides"])
        merged["family_id"] = current_id
        merged["changed_factor"] = record["changed_factor"]
        merged["iteration_rationale"] = record["rationale"]
        visiting.remove(current_id)
        return merged

    return resolve(family_id)


def _validate_execution_contract(
    raw_config: dict,
    contract: ShortLeadContract,
    family: dict,
    *,
    mode: str,
    prepared_data_root: Path | None,
) -> None:
    lead_weights = tuple(float(value) for value in family["loss_lead_weights"])
    if len(lead_weights) != len(contract.leads):
        raise ValueError("loss lead weights and forecast leads differ")
    if any(not math.isfinite(value) or value <= 0.0 for value in lead_weights):
        raise ValueError("loss lead weights must be finite and positive")
    if not math.isclose(sum(lead_weights), 1.0, rel_tol=0.0, abs_tol=1e-12):
        raise ValueError("loss lead weights must sum to one")
    if str(
        family.get(
            "training_loss_mode",
            "training_period_variance_normalized_forecast_mse",
        )
    ) not in {
        "training_period_variance_normalized_forecast_mse",
        "training_period_per_lead_target_variance_normalized_forecast_mse",
    }:
        raise ValueError("training loss mode is outside the frozen one-factor comparison")

    if contract.schema_version != "hbv_native_shortlead_recovery_v2":
        return
    if mode != "audit-archive" and prepared_data_root is None:
        raise ValueError(
            "HSR02 requires sanitized calibration-only TUKF06 inputs; raw prior loading is forbidden"
        )
    required_family_values = {
        "network_backend": "upstream_official_kalmannet_tsp_gru",
        "physical_model_dtype": "float64",
        "gain_network_dtype": "float32",
        "initialization_mode": CAUSAL_PARAMETER_ONLY_INITIALIZATION,
        "maximum_routing_lag": 15,
        "residual_memory_order": 0,
        "metric_filter_warmup_days": 16,
    }
    for name, expected in required_family_values.items():
        if family.get(name) != expected:
            raise ValueError(f"HSR02 family contract differs: {name}")
    if tuple(int(value) for value in family["corrected_storage_indices"]) != tuple(
        range(5)
    ):
        raise ValueError("HSR02 must correct all five physical HBV storages")
    if float(family.get("minimum_median_method_nse_each_lead", float("nan"))) != 0.60:
        raise ValueError("HSR02 minimum median Nash-Sutcliffe efficiency must remain 0.60")
    if family.get("require_trained_checkpoint_after_epoch_zero") is not True:
        raise ValueError("HSR02 must prove improvement beyond epoch zero")

    data_contract = raw_config.get("data_contract")
    if not isinstance(data_contract, dict):
        raise ValueError("HSR02 data contract is missing")
    if tuple(data_contract.get("portable_members", ())) != PREPARED_SAFE_SOURCE_MEMBERS:
        raise ValueError("HSR02 portable data members differ")
    if tuple(data_contract.get("forbidden_source_members", ())) != (
        PREPARED_FORBIDDEN_SOURCE_MEMBERS
    ):
        raise ValueError("HSR02 forbidden data members differ")
    if data_contract.get("reserved_evaluation_member_count") != 0:
        raise ValueError("HSR02 data contract permits reserved evaluation data")

    geometry = raw_config.get("validation_geometry")
    if not isinstance(geometry, dict):
        raise ValueError("HSR02 validation geometry is missing")
    period_days = int(geometry.get("period_days", -1))
    warmup_days = int(geometry.get("filter_warmup_days", -1))
    issue_count = int(geometry.get("common_issue_count_per_lead", -1))
    if (
        period_days != contract.periods.calibration_validation_days
        or warmup_days != int(family["metric_filter_warmup_days"])
        or issue_count != period_days - warmup_days - max(contract.leads)
    ):
        raise ValueError("HSR02 continuous validation geometry differs")
    calibration_end = np.datetime64(contract.periods.calibration[1], "D")
    expected_validation_start = calibration_end - np.timedelta64(period_days - 1, "D")
    expected_period = (str(expected_validation_start), str(calibration_end))
    if tuple(geometry.get("period", ())) != expected_period:
        raise ValueError("HSR02 continuous validation period differs")
    last_common_issue = period_days - max(contract.leads) - 1
    expected_target_ranges = {
        str(lead): [warmup_days + lead, last_common_issue + lead]
        for lead in contract.leads
    }
    if geometry.get("target_index_ranges_zero_based") != expected_target_ranges:
        raise ValueError("HSR02 continuous validation target ranges differ")


def _save_prediction_bundle(path: Path, payloads: dict[str, dict[str, np.ndarray]]) -> None:
    arrays: dict[str, np.ndarray] = {}
    for basin_id, payload in payloads.items():
        for name, values in payload.items():
            arrays[f"basin_{basin_id}__{name}"] = values
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.stem + ".tmp.npz")
    np.savez_compressed(temporary, **arrays)
    temporary.replace(path)


def _acquire_run_lock(run_directory: Path, *, command_line_arguments: list[str]) -> Path:
    """Atomically claim one unique run directory and retain owner evidence."""

    lock_path = Path(run_directory) / ".run.lock"
    payload = {
        "schema_version": "hbv_native_shortlead_run_lock_v1",
        "status": "started",
        "process_id": os.getpid(),
        "host_name": socket.gethostname(),
        "started_unix_seconds": time.time(),
        "command_line_arguments": command_line_arguments,
    }
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    descriptor = os.open(lock_path, flags)
    try:
        os.write(
            descriptor,
            (json.dumps(payload, indent=2, ensure_ascii=False) + "\n").encode("utf-8"),
        )
    finally:
        os.close(descriptor)
    return lock_path


def _complete_run_lock(lock_path: Path) -> None:
    payload = json.loads(Path(lock_path).read_text(encoding="utf-8"))
    if payload.get("status") != "started" or payload.get("process_id") != os.getpid():
        raise RuntimeError("run lock ownership changed before completion")
    payload["status"] = "complete"
    payload["completed_unix_seconds"] = time.time()
    atomic_write_json(lock_path, payload)


def _atomic_torch_save(path: Path, payload: dict) -> None:
    if path.exists():
        raise FileExistsError(f"refusing to overwrite checkpoint: {path}")
    temporary = path.with_name(path.name + ".partial")
    if temporary.exists():
        raise FileExistsError(f"partial checkpoint already exists: {temporary}")
    torch.save(payload, temporary)
    temporary.replace(path)


def _process_peak_resident_memory_bytes() -> int | None:
    try:
        import resource
    except ImportError:
        return None
    value = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    # Linux reports KiB; macOS reports bytes.
    return value if sys.platform == "darwin" else value * 1024


def _prepare_unique_run_directory(path: Path) -> Path:
    """Create an output directory without ever reusing prior run evidence."""

    resolved = Path(path).resolve()
    if resolved.exists():
        if not resolved.is_dir():
            raise FileExistsError(f"run path exists and is not a directory: {resolved}")
        if any(resolved.iterdir()):
            raise FileExistsError(f"run directory is not empty: {resolved}")
    else:
        resolved.mkdir(parents=True, exist_ok=False)
    return resolved


def _executable_paths(args: argparse.Namespace, family: dict) -> list[Path]:
    """Return the complete repository-local source chain used by this entry point."""

    paths = [
        Path(args.config),
        ROOT / "scripts" / "run_hbv_native_shortlead_recovery.py",
        ROOT / "src" / "global_hydrology" / "data" / "hbvlite_prior.py",
        ROOT / "src" / "global_hydrology" / "experiments" / "hbv_shortlead_contract.py",
        ROOT / "src" / "global_hydrology" / "experiments" / "hbv_shortlead_runner.py",
        ROOT / "src" / "global_hydrology" / "experiments" / "hbv_shortlead_audit.py",
        ROOT / "src" / "global_hydrology" / "models" / "differentiable_hbv_lite.py",
        ROOT / "src" / "global_hydrology" / "models" / "hbvlite_system_model.py",
        ROOT / "src" / "global_hydrology" / "models" / "knet_native_hbvlite_full_state.py",
        # The full-state helper imports this legacy class at module import time,
        # even when the selected backend is the upstream official GRU network.
        ROOT / "knet" / "dl" / "nn_kalman_clamp_5.py",
    ]
    if family.get("network_backend") == "upstream_official_kalmannet_tsp_gru":
        paths.extend(
            [
                ROOT
                / "src"
                / "global_hydrology"
                / "models"
                / "official_kalmannet_tsp_hbvlite.py",
                ROOT
                / "third_party"
                / "KalmanNet_TSP_828a2cf"
                / "KNet"
                / "KalmanNet_nn.py",
            ]
        )
    if args.family_id is not None:
        paths.append(Path(args.iteration_config))
    if getattr(args, "prepared_data_root", None) is not None:
        paths.extend(
            [
                ROOT / "scripts" / "prepare_daily_camels_official_kalmannet_data.py",
                ROOT / "configs" / "tukf06_full_diagonal_search_head_to_head_v1.json",
                ROOT
                / "results"
                / "tukf06_full_diagonal_search_head_to_head_v1"
                / "selection_manifest.sha256.json",
            ]
        )

    resolved: list[Path] = []
    seen: set[Path] = set()
    for path in paths:
        candidate = path.resolve()
        try:
            candidate.relative_to(ROOT.resolve())
        except ValueError as error:
            raise ValueError(f"executable source is outside repository root: {candidate}") from error
        if not candidate.is_file():
            raise FileNotFoundError(f"executable source does not exist: {candidate}")
        if candidate not in seen:
            resolved.append(candidate)
            seen.add(candidate)
    return resolved


def _semantic_npz_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with np.load(path, allow_pickle=False) as stored:
        for name in sorted(stored.files):
            value = np.ascontiguousarray(stored[name])
            digest.update(name.encode("utf-8"))
            digest.update(str(value.dtype).encode("ascii"))
            digest.update(np.asarray(value.shape, dtype=np.int64).tobytes())
            digest.update(value.tobytes())
    return digest.hexdigest()


def _is_sha256(value: object) -> bool:
    return isinstance(value, str) and len(value) == 64 and all(
        character in "0123456789abcdef" for character in value
    )


def _prepared_input_manifest(
    root: Path,
    basin_ids: list[str],
    *,
    contract: ShortLeadContract,
    config_path: Path,
) -> dict:
    resolved_root = Path(root).resolve()
    if not resolved_root.is_dir():
        raise FileNotFoundError(f"prepared data root does not exist: {resolved_root}")
    producer_manifest = resolved_root / "prepared_manifest.json"
    if not producer_manifest.is_file():
        raise FileNotFoundError(f"prepared data manifest does not exist: {producer_manifest}")
    producer_payload = json.loads(producer_manifest.read_text(encoding="utf-8"))
    if producer_payload.get("schema_version") != PREPARED_MANIFEST_SCHEMA:
        raise ValueError("prepared data manifest schema differs")
    required_attestations = {
        "calibration_only": True,
        "evaluation_data_included": False,
        "reserved_data_member_count": 0,
        "future_derived_member_read_count": 0,
        "initialization_mode": CAUSAL_PARAMETER_ONLY_INITIALIZATION,
    }
    for name, expected in required_attestations.items():
        if producer_payload.get(name) != expected:
            raise ValueError(f"prepared data manifest attestation differs: {name}")
    if tuple(producer_payload.get("safe_source_members_materialized", ())) != (
        PREPARED_SAFE_SOURCE_MEMBERS
    ):
        raise ValueError("prepared data safe-source member declaration differs")
    if tuple(producer_payload.get("forbidden_source_members_not_materialized", ())) != (
        PREPARED_FORBIDDEN_SOURCE_MEMBERS
    ):
        raise ValueError("prepared data forbidden-source member declaration differs")
    requested = tuple(dict.fromkeys(str(value).zfill(8) for value in basin_ids))
    declared = tuple(str(value).zfill(8) for value in producer_payload.get("basin_ids", []))
    if declared != contract.training_basins:
        raise ValueError("prepared data manifest does not contain the exact contract population")
    if producer_payload.get("basin_count") != len(declared):
        raise ValueError("prepared data manifest basin count differs")
    if tuple(producer_payload.get("calibration_period", ())) != tuple(
        contract.periods.calibration
    ):
        raise ValueError("prepared data calibration period differs")
    missing = sorted(set(requested) - set(declared))
    if missing:
        raise ValueError(f"prepared data manifest lacks requested basins: {missing}")

    declared_file_rows = producer_payload.get("files")
    if not isinstance(declared_file_rows, list):
        raise ValueError("prepared data file records are missing")
    declared_file_ids = tuple(
        str(record.get("basin_id", "")).zfill(8)
        for record in declared_file_rows
        if isinstance(record, dict)
    )
    if declared_file_ids != declared:
        raise ValueError("prepared data file records differ from the declared basin order")
    declared_files = {
        str(record["basin_id"]).zfill(8): record for record in declared_file_rows
    }
    expected_archive_names = {f"{basin_id}.npz" for basin_id in declared}
    actual_archive_names = {path.name for path in resolved_root.glob("*.npz")}
    if actual_archive_names != expected_archive_names:
        raise ValueError("prepared archive file set differs from the exact contract population")

    source_rows = producer_payload.get("source_archives")
    if not isinstance(source_rows, list) or tuple(
        str(record.get("basin_id", "")).zfill(8)
        for record in source_rows
        if isinstance(record, dict)
    ) != declared:
        raise ValueError("prepared source-archive evidence differs from the contract population")
    frozen_selection_manifest_path = (
        ROOT
        / "results"
        / "tukf06_full_diagonal_search_head_to_head_v1"
        / "selection_manifest.sha256.json"
    ).resolve()
    frozen_selection_manifest = json.loads(
        frozen_selection_manifest_path.read_text(encoding="utf-8")
    )
    if (
        frozen_selection_manifest.get("status") != "SELECTION_COMPLETE"
        or frozen_selection_manifest.get("evaluation_period_read") is not False
    ):
        raise ValueError("frozen TUKF06 selection evidence is invalid")
    frozen_selection_hashes = frozen_selection_manifest.get("files")
    if not isinstance(frozen_selection_hashes, dict):
        raise ValueError("frozen TUKF06 selection file hashes are missing")
    for source_record in source_rows:
        if tuple(source_record.get("safe_members_materialized", ())) != (
            PREPARED_SAFE_SOURCE_MEMBERS
        ):
            raise ValueError("prepared source archive safe-member evidence differs")
        if source_record.get("forbidden_members_materialized") != []:
            raise ValueError("prepared source archive materialized a forbidden member")
        if not _is_sha256(source_record.get("sha256")):
            raise ValueError("prepared source archive hash evidence is invalid")
        source_basin_id = str(source_record["basin_id"]).zfill(8)
        if source_record.get("sha256") != frozen_selection_hashes.get(
            f"selection_inputs/basin_{source_basin_id}.npz"
        ):
            raise ValueError(
                f"prepared source archive differs from frozen TUKF06 evidence: {source_basin_id}"
            )

    producer_sources = producer_payload.get("producer_sources")
    if not isinstance(producer_sources, dict):
        raise ValueError("prepared producer-source evidence is missing")
    expected_producer_sources = {
        "config": Path(config_path).resolve(),
        "tukf06_config": (
            ROOT / "configs" / "tukf06_full_diagonal_search_head_to_head_v1.json"
        ).resolve(),
        "tukf06_selection_manifest": (
            ROOT
            / "results"
            / "tukf06_full_diagonal_search_head_to_head_v1"
            / "selection_manifest.sha256.json"
        ).resolve(),
        "producer": (
            ROOT / "scripts" / "prepare_daily_camels_official_kalmannet_data.py"
        ).resolve(),
        "parameter_definition": (
            ROOT / "src" / "global_hydrology" / "models" / "differentiable_hbv_lite.py"
        ).resolve(),
    }
    for role, expected_path in expected_producer_sources.items():
        record = producer_sources.get(role)
        if not isinstance(record, dict) or record.get("sha256") != sha256_file(expected_path):
            raise ValueError(f"prepared producer-source hash differs: {role}")

    records = []
    for basin_id in requested:
        path = resolved_root / f"{basin_id}.npz"
        if not path.is_file():
            raise FileNotFoundError(f"prepared basin archive does not exist: {path}")
        declared_record = declared_files[basin_id]
        if declared_record.get("path") != path.name:
            raise ValueError(f"prepared basin relative path differs for {basin_id}")
        actual_sha256 = sha256_file(path)
        if declared_record.get("sha256") != actual_sha256:
            raise ValueError(f"prepared basin file hash differs for {basin_id}")
        actual_semantic_sha256 = _semantic_npz_sha256(path)
        if declared_record.get("semantic_sha256") != actual_semantic_sha256:
            raise ValueError(f"prepared basin semantic hash differs for {basin_id}")
        records.append(
            {
                "basin_id": basin_id,
                "path": str(path),
                "sha256": actual_sha256,
                "semantic_sha256": actual_semantic_sha256,
                "size_bytes": int(path.stat().st_size),
            }
        )
    return {
        "root": str(resolved_root),
        "producer_manifest_path": str(producer_manifest),
        "producer_manifest_sha256": sha256_file(producer_manifest),
        "producer_manifest_snapshot_relative_path": (
            "prepared_data_snapshot/prepared_manifest.json"
        ),
        "basin_count": len(records),
        "calibration_only": True,
        "evaluation_data_included": False,
        "reserved_data_member_count": 0,
        "future_derived_member_read_count": 0,
        "files": records,
    }


def _save_prepared_manifest_snapshot(run_directory: Path, record: dict) -> None:
    snapshot_root = Path(run_directory) / "prepared_data_snapshot"
    if snapshot_root.exists():
        raise FileExistsError(f"prepared-data snapshot already exists: {snapshot_root}")
    snapshot_root.mkdir(parents=True, exist_ok=False)
    source = Path(record["producer_manifest_path"])
    destination = snapshot_root / "prepared_manifest.json"
    shutil.copy2(source, destination)
    expected_hash = str(record["producer_manifest_sha256"])
    if sha256_file(source) != expected_hash or sha256_file(destination) != expected_hash:
        raise RuntimeError("prepared manifest changed during evidence snapshot")


def _save_source_snapshot(
    run_directory: Path,
    executable_paths: list[Path],
    *,
    expected_hashes: dict[str, str] | None = None,
) -> dict:
    """Copy the exact executable source set into a new, immutable run subdirectory."""

    snapshot_root = Path(run_directory) / "source_snapshot"
    if snapshot_root.exists():
        raise FileExistsError(f"source snapshot already exists: {snapshot_root}")
    snapshot_root.mkdir(parents=True, exist_ok=False)
    repository_root = ROOT.resolve()
    records = []
    for source in executable_paths:
        source = Path(source).resolve()
        relative = source.relative_to(repository_root)
        destination = snapshot_root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        source_hash = sha256_file(source)
        if expected_hashes is not None and expected_hashes.get(str(source)) != source_hash:
            raise RuntimeError(f"executable source changed after manifest: {relative}")
        shutil.copy2(source, destination)
        copied_hash = sha256_file(destination)
        if copied_hash != source_hash:
            raise RuntimeError(f"source snapshot hash differs after copy: {relative}")
        records.append(
            {
                "relative_path": relative.as_posix(),
                "source_absolute_path": str(source),
                "sha256": source_hash,
                "size_bytes": int(destination.stat().st_size),
            }
        )
    payload = {
        "schema_version": "hbv_native_shortlead_source_snapshot_v1",
        "repository_root_at_execution": str(repository_root),
        "file_count": len(records),
        "files": records,
    }
    atomic_write_json(snapshot_root / "source_manifest.json", payload)
    return payload


def _manifest(
    args: argparse.Namespace,
    contract: ShortLeadContract,
    family: dict,
    training_ids: list[str],
    evaluation_ids: list[str],
    *,
    resolved_execution: dict,
    command_line_arguments: list[str],
) -> dict:
    run_directory = getattr(args, "run_dir", None)
    executable_paths = _executable_paths(args, family)
    manifest = {
        "schema_version": contract.schema_version,
        "experiment_id": contract.experiment_id,
        "run_id": None if run_directory is None else Path(run_directory).name,
        "run_directory": None if run_directory is None else str(run_directory),
        "mode": args.mode,
        "seed": args.seed,
        "training_basin_ids": training_ids,
        "evaluation_basin_ids": evaluation_ids,
        "family": family,
        "trusted_file_hash_mismatches": contract.verify_hashes(ROOT),
        "executable_sha256": {
            str(path): sha256_file(path) for path in executable_paths
        },
        "source_snapshot_relative_directory": "source_snapshot",
        "torch_version": torch.__version__,
        "numpy_version": np.__version__,
        "torch_threads": torch.get_num_threads(),
        "information_timing": contract.information_timing,
        "scientific_claim_allowed": (
            family.get("initialization_mode") == CAUSAL_PARAMETER_ONLY_INITIALIZATION
        ),
        "resolved_execution": resolved_execution,
        "command_line_arguments": command_line_arguments,
    }
    prepared_root = getattr(args, "prepared_data_root", None)
    if prepared_root is not None:
        manifest["prepared_calibration_data"] = _prepared_input_manifest(
            prepared_root,
            sorted(set(training_ids) | set(evaluation_ids)),
            contract=contract,
            config_path=Path(args.config),
        )
    if args.checkpoint is not None:
        manifest["source_checkpoint"] = str(args.checkpoint)
        manifest["source_checkpoint_sha256"] = sha256_file(args.checkpoint)
    return manifest


def _load_many(
    prior,
    ids,
    contract,
    family,
    *,
    load_evaluation,
    prepared_data_root: Path | None = None,
    prepared_file_sha256_by_basin: dict[str, str] | None = None,
):
    output = []
    for position, basin_id in enumerate(ids, start=1):
        print(
            f"LOAD {position:02d}/{len(ids):02d} basin={basin_id} "
            f"evaluation={load_evaluation}",
            flush=True,
        )
        output.append(
            prepare_basin(
                prior,
                basin_id,
                contract,
                family,
                load_evaluation=load_evaluation,
                prepared_data_root=prepared_data_root,
                prepared_input_expected_sha256=(
                    None
                    if prepared_file_sha256_by_basin is None
                    else prepared_file_sha256_by_basin[basin_id]
                ),
            )
        )
    return output


def main() -> None:
    args = parse_args()
    runtime_device = configure_runtime_device(args.device)
    if runtime_device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(runtime_device)
    if args.threads > 0:
        torch.set_num_threads(args.threads)
    raw_config = json.loads(args.config.read_text(encoding="utf-8"))
    contract = ShortLeadContract.from_dict(raw_config)
    family = dict(raw_config["family"])
    if args.family_id is not None:
        iteration_payload = json.loads(args.iteration_config.read_text(encoding="utf-8"))
        family = _resolve_family(family, iteration_payload, args.family_id)
    if args.prepared_data_root is not None:
        args.prepared_data_root = args.prepared_data_root.resolve()
        if args.mode == "formal":
            raise SystemExit("formal evaluation rejects calibration-only prepared data")
    _validate_execution_contract(
        raw_config,
        contract,
        family,
        mode=args.mode,
        prepared_data_root=args.prepared_data_root,
    )
    args.run_dir = _prepare_unique_run_directory(args.run_dir)
    run_lock_path = _acquire_run_lock(
        args.run_dir, command_line_arguments=list(sys.argv[1:])
    )
    contract.assert_run_directory_open(args.run_dir)

    checkpoint_payload = None
    if args.mode == "transfer":
        if args.checkpoint is None:
            raise SystemExit("transfer mode requires --checkpoint")
        args.checkpoint = args.checkpoint.resolve()
        if not args.checkpoint.is_file():
            raise SystemExit(f"checkpoint does not exist: {args.checkpoint}")
        checkpoint_payload = torch.load(args.checkpoint, map_location="cpu", weights_only=False)

    if args.mode == "audit-archive":
        audit = audit_archived_storage_only(args.archive, contract)
        atomic_write_json(args.run_dir / "audit.json", audit)
        print(json.dumps(audit, indent=2, ensure_ascii=False))
        _complete_run_lock(run_lock_path)
        return

    if args.mode == "formal" and any(
        value is not None
        for value in (args.epochs, args.steps_per_epoch, args.segment_days, args.warmup_days)
    ):
        raise SystemExit("formal mode rejects training-budget overrides")
    if args.mode == "formal" and not contract.formal_evaluation_enabled:
        raise SystemExit("this development-only contract forbids formal evaluation")
    seed = int(args.seed if args.seed is not None else contract.random_seeds[0])
    args.seed = seed
    if args.mode == "formal":
        training_ids = list(contract.training_basins)
        evaluation_ids = list(contract.holdout_basins)
        epochs = steps = segment = warmup = None
    elif args.mode == "transfer":
        if args.basins:
            evaluation_ids = [str(value).zfill(8) for value in args.basins]
        else:
            start = int(args.basin_offset)
            stop = start + int(args.basin_limit)
            if start < 0 or stop > len(contract.training_basins) or start >= stop:
                raise SystemExit("transfer basin slice is outside the frozen training set")
            evaluation_ids = list(contract.training_basins[start:stop])
        if len(set(evaluation_ids)) != len(evaluation_ids):
            raise SystemExit("transfer basin identifiers must be unique")
        outside = sorted(set(evaluation_ids) - set(contract.training_basins))
        if outside:
            raise SystemExit(f"transfer basins are outside frozen training set: {outside}")
        training_ids = [str(value).zfill(8) for value in checkpoint_payload["training_basin_ids"]]
        overlap = sorted(set(training_ids) & set(evaluation_ids))
        if overlap:
            raise SystemExit(f"transfer evaluation overlaps checkpoint training basins: {overlap}")
        epochs = steps = segment = warmup = None
    else:
        if args.basins:
            training_ids = [str(value).zfill(8) for value in args.basins]
            if len(set(training_ids)) != len(training_ids):
                raise SystemExit("development basin identifiers must be unique")
            outside = sorted(set(training_ids) - set(contract.training_basins))
            if outside:
                raise SystemExit(f"development basins are outside frozen training set: {outside}")
        else:
            if args.basin_limit < 1 or args.basin_limit > len(contract.training_basins):
                raise SystemExit("basin-limit is outside the frozen training set")
            training_ids = list(contract.training_basins[: args.basin_limit])
        evaluation_ids = training_ids
        defaults = {
            "smoke": (2, 4, 60, 15),
            "development": (
                int(family["training_epochs"]),
                int(family["steps_per_epoch"]),
                int(family["segment_days"]),
                int(family["filter_warmup_days"]),
            ),
        }
        default_epochs, default_steps, default_segment, default_warmup = defaults[args.mode]
        epochs = args.epochs if args.epochs is not None else default_epochs
        steps = args.steps_per_epoch if args.steps_per_epoch is not None else default_steps
        segment = args.segment_days if args.segment_days is not None else default_segment
        warmup = args.warmup_days if args.warmup_days is not None else default_warmup

    resolved_execution = {
        "training_enabled": epochs is not None,
        "training_epochs": epochs,
        "optimizer_steps_per_epoch": steps,
        "segment_days": segment,
        "filter_warmup_days": warmup,
        "torch_threads": torch.get_num_threads(),
        "device": str(runtime_device),
        "cuda_device_name": (
            torch.cuda.get_device_name(runtime_device)
            if runtime_device.type == "cuda"
            else None
        ),
    }
    manifest = _manifest(
        args,
        contract,
        family,
        training_ids,
        evaluation_ids,
        resolved_execution=resolved_execution,
        command_line_arguments=list(sys.argv[1:]),
    )
    if manifest["trusted_file_hash_mismatches"]:
        atomic_write_json(args.run_dir / "manifest.json", manifest)
        raise SystemExit("trusted file hash mismatch; refusing to train")
    atomic_write_json(args.run_dir / "manifest.json", manifest)
    atomic_write_json(args.run_dir / "config.json", raw_config)
    _save_source_snapshot(
        args.run_dir,
        _executable_paths(args, family),
        expected_hashes=manifest["executable_sha256"],
    )
    if "prepared_calibration_data" in manifest:
        _save_prepared_manifest_snapshot(
            args.run_dir, manifest["prepared_calibration_data"]
        )
        prepared_file_sha256_by_basin = {
            str(record["basin_id"]): str(record["sha256"])
            for record in manifest["prepared_calibration_data"]["files"]
        }
    else:
        prepared_file_sha256_by_basin = None

    prior = (
        None
        if args.prepared_data_root is not None
        else load_hbvlite_prior(dtype=torch.float64)
    )
    start_clock = time.perf_counter()
    training_diagnostics = None
    if args.mode == "transfer":
        evaluation_basins = _load_many(
            prior,
            evaluation_ids,
            contract,
            family,
            load_evaluation=False,
            prepared_data_root=args.prepared_data_root,
            prepared_file_sha256_by_basin=prepared_file_sha256_by_basin,
        )
        if checkpoint_payload.get("family") != family:
            raise SystemExit("checkpoint family does not exactly match requested transfer family")
        net = build_shared_network(evaluation_basins[0], family)
        net.load_state_dict(checkpoint_payload["state_dict"], strict=True)
        checkpoint_audit = {
            "source_checkpoint": str(args.checkpoint),
            "source_checkpoint_sha256": sha256_file(args.checkpoint),
            "family_exact_match": True,
            "source_training_basin_ids": training_ids,
            "transfer_evaluation_basin_ids": evaluation_ids,
            "basin_sets_disjoint": True,
            "source_nonzero_gradient_parameter_tensor_count": checkpoint_payload[
                "training_diagnostics"
            ]["nonzero_gradient_parameter_tensor_count"],
            "source_trainable_parameter_tensor_count": checkpoint_payload[
                "training_diagnostics"
            ]["trainable_parameter_tensor_count"],
        }
        atomic_write_json(args.run_dir / "checkpoint_audit.json", checkpoint_audit)
        print(
            f"TRANSFER checkpoint={args.checkpoint.name} basins={len(evaluation_basins)}",
            flush=True,
        )
        formal_evaluation = False
    else:
        training_basins = _load_many(
            prior,
            training_ids,
            contract,
            family,
            load_evaluation=False,
            prepared_data_root=args.prepared_data_root,
            prepared_file_sha256_by_basin=prepared_file_sha256_by_basin,
        )
        print(
            f"TRAIN KalmanNet basins={len(training_basins)} seed={seed} "
            f"epochs={epochs or family['training_epochs']} "
            f"steps={steps or family['steps_per_epoch']}",
            flush=True,
        )
        net, training_diagnostics = train_shared_network(
            training_basins,
            contract,
            family,
            seed=seed,
            epochs=epochs,
            steps_per_epoch=steps,
            segment_days=segment,
            warmup_days=warmup,
        )
        atomic_write_json(args.run_dir / "training_diagnostics.json", training_diagnostics)
        _atomic_torch_save(
            args.run_dir / "best_model.pt",
            {
                "state_dict": net.state_dict(),
                "seed": seed,
                "family": family,
                "training_basin_ids": training_ids,
                "training_diagnostics": training_diagnostics,
            },
        )
        print(
            f"TRAIN_DONE best_validation={training_diagnostics['best_validation_loss']:.6g} "
            f"gradient_tensors={training_diagnostics['nonzero_gradient_parameter_tensor_count']}/"
            f"{training_diagnostics['trainable_parameter_tensor_count']}",
            flush=True,
        )

        if args.mode == "formal":
            evaluation_basins = _load_many(
                prior,
                evaluation_ids,
                contract,
                family,
                load_evaluation=True,
                prepared_data_root=args.prepared_data_root,
                prepared_file_sha256_by_basin=prepared_file_sha256_by_basin,
            )
            formal_evaluation = True
        else:
            evaluation_basins = training_basins
            formal_evaluation = False

    rows = []
    prediction_payloads = {}
    for position, basin in enumerate(evaluation_basins, start=1):
        print(f"EVAL {position:02d}/{len(evaluation_basins):02d} basin={basin.basin_id}", flush=True)
        row, payload = evaluate_basin(
            net,
            basin,
            contract,
            family,
            formal_evaluation=formal_evaluation,
        )
        rows.append(row)
        prediction_payloads[basin.basin_id] = payload
        gains = row["gain_over_open_loop"]
        print(
            "  gains=" + "/".join(f"d{lead}:{gains[str(lead)]:+.4f}" for lead in contract.leads),
            flush=True,
        )

    gate = evaluate_formal_gate(
        rows,
        leads=contract.leads,
        median_gain_threshold=contract.thresholds.median_nse_gain_each_lead,
        catastrophic_decrement=contract.thresholds.catastrophic_decrement,
        maximum_degraded_fraction=contract.thresholds.maximum_degraded_fraction,
        minimum_median_method_nse=(
            None
            if family.get("minimum_median_method_nse_each_lead") is None
            else float(family["minimum_median_method_nse_each_lead"])
        ),
    )
    initialization_mode = str(family.get("initialization_mode", "unspecified"))
    scientific_initialization = {
        "passed": initialization_mode == CAUSAL_PARAMETER_ONLY_INITIALIZATION,
        "initialization_mode": initialization_mode,
        "criterion": (
            "scientific claims require the parameter-only causal state followed by "
            "forward-only meteorological spin-up"
        ),
    }
    gate["scientific_initialization"] = scientific_initialization
    gate["passed"] = bool(gate["passed"] and scientific_initialization["passed"])
    if bool(family.get("require_trained_checkpoint_after_epoch_zero", False)):
        if training_diagnostics is None:
            training_effect = {
                "passed": False,
                "reason": "this execution did not train a checkpoint",
            }
        else:
            score_improvement = float(
                training_diagnostics["selection_score_improvement_over_epoch_zero"]
            )
            loss_improvement = float(
                training_diagnostics["validation_loss_improvement_over_epoch_zero"]
            )
            selected_epoch = int(training_diagnostics["best_epoch"])
            training_effect = {
                "passed": bool(
                    selected_epoch > 0
                    and score_improvement > 0.0
                    and loss_improvement > 0.0
                ),
                "selected_epoch": selected_epoch,
                "selection_score_improvement_over_epoch_zero": score_improvement,
                "validation_loss_improvement_over_epoch_zero": loss_improvement,
                "criterion": (
                    "selected checkpoint must be after epoch zero, improve the fixed "
                    "continuous-validation Nash-Sutcliffe selection score, and reduce "
                    "the fixed validation value of the optimized forecast loss"
                ),
            }
        gate["training_effect"] = training_effect
        gate["passed"] = bool(gate["passed"] and training_effect["passed"])
    gate["formal"] = args.mode == "formal"
    gate["transfer"] = args.mode == "transfer"
    gate["seed"] = seed
    gate["elapsed_seconds"] = time.perf_counter() - start_clock
    atomic_write_json(args.run_dir / "per_basin_metrics.json", rows)
    write_metric_csv(args.run_dir / "per_basin_metrics.csv", rows, contract.leads)
    _save_prediction_bundle(args.run_dir / "predictions.npz", prediction_payloads)
    if runtime_device.type == "cuda":
        torch.cuda.synchronize(runtime_device)
        gpu_peak_allocated = int(torch.cuda.max_memory_allocated(runtime_device))
        gpu_peak_reserved = int(torch.cuda.max_memory_reserved(runtime_device))
    else:
        gpu_peak_allocated = None
        gpu_peak_reserved = None
    gate["resource_observation"] = {
        "process_peak_resident_memory_bytes": _process_peak_resident_memory_bytes(),
        "cuda_peak_allocated_bytes": gpu_peak_allocated,
        "cuda_peak_reserved_bytes": gpu_peak_reserved,
        "measurement_scope": "complete process through prediction bundle creation",
    }
    if args.mode == "formal":
        atomic_write_json(args.run_dir / "final_gate.json", gate)
    elif args.mode == "transfer":
        atomic_write_json(args.run_dir / "transfer_gate.json", gate)
    else:
        atomic_write_json(args.run_dir / "validation_gate.json", gate)
    print(json.dumps(gate, indent=2, ensure_ascii=False), flush=True)
    _complete_run_lock(run_lock_path)


if __name__ == "__main__":
    main()
