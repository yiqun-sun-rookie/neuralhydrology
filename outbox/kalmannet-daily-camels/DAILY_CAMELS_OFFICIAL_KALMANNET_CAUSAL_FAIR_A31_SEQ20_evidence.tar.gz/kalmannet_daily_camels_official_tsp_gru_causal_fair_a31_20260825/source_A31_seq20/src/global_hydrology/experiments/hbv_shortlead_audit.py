"""Independent timing, state-authority, and metric checks for short-lead forecasts."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable, Mapping

import numpy as np
import torch


@dataclass(frozen=True)
class CausalForecastResult:
    """Forecasts indexed by issue day, with explicit target-day indices."""

    leads: tuple[int, ...]
    analysis_states: torch.Tensor
    predictions_by_origin: torch.Tensor
    target_indices: torch.Tensor


def causal_filter_forecasts(
    *,
    initial_state: torch.Tensor,
    forcing: torch.Tensor,
    observations: torch.Tensor,
    valid: torch.Tensor,
    process_step: Callable[[torch.Tensor, torch.Tensor], torch.Tensor],
    update_step: Callable[[torch.Tensor, torch.Tensor], torch.Tensor],
    observation_step: Callable[[torch.Tensor], torch.Tensor],
    leads: Iterable[int],
) -> CausalForecastResult:
    """Run a filter and issue free-running forecasts without future observations.

    At issue day ``t`` the analysis calls ``update_step`` with only ``observation[t]``.
    The lead-``k`` forecast then calls the process model with forcings ``t+1`` through
    ``t+k`` and is stored at origin row ``t`` with target index ``t+k``.
    """

    leads = tuple(int(value) for value in leads)
    if not leads or tuple(sorted(set(leads))) != leads or min(leads) < 1:
        raise ValueError("leads must be unique, increasing positive integers")
    if len(forcing) != len(observations) or len(valid) != len(observations):
        raise ValueError("forcing, observations, and valid mask must have equal length")

    sequence_length = len(observations)
    prediction = torch.full(
        (sequence_length, len(leads)),
        torch.nan,
        dtype=initial_state.dtype,
        device=initial_state.device,
    )
    target_indices = torch.full(
        (sequence_length, len(leads)), -1, dtype=torch.long, device=initial_state.device
    )
    analysis_states = []
    posterior = initial_state.clone()

    for issue in range(sequence_length):
        prior = process_step(posterior, forcing[issue])
        if bool(valid[issue]) and bool(torch.isfinite(observations[issue]).all()):
            posterior = update_step(prior, observations[issue])
        else:
            posterior = prior
        analysis_states.append(posterior.clone())

        forecast_state = posterior
        for column, lead in enumerate(leads):
            # Advance only the steps not already traversed for the previous lead.
            previous_lead = 0 if column == 0 else leads[column - 1]
            for offset in range(previous_lead + 1, lead + 1):
                target = issue + offset
                if target >= sequence_length:
                    break
                forecast_state = process_step(forecast_state, forcing[target])
            target = issue + lead
            if target < sequence_length:
                value = observation_step(forecast_state).reshape(-1)[0]
                prediction[issue, column] = value
                target_indices[issue, column] = target

    return CausalForecastResult(
        leads=leads,
        analysis_states=torch.stack(analysis_states, dim=0),
        predictions_by_origin=prediction,
        target_indices=target_indices,
    )


def target_aligned_predictions(
    result: CausalForecastResult, sequence_length: int
) -> dict[int, np.ndarray]:
    """Convert origin-indexed forecasts to one target-indexed series per lead."""

    output = {lead: np.full(sequence_length, np.nan, dtype=float) for lead in result.leads}
    predictions = result.predictions_by_origin.detach().cpu().numpy()
    targets = result.target_indices.detach().cpu().numpy()
    for column, lead in enumerate(result.leads):
        for origin in range(predictions.shape[0]):
            target = int(targets[origin, column])
            if target >= 0:
                output[lead][target] = float(predictions[origin, column])
    return output


def nash_sutcliffe_efficiency(target: np.ndarray, prediction: np.ndarray) -> float:
    """Compute Nash-Sutcliffe efficiency on the pairwise finite mask."""

    target = np.asarray(target, dtype=float)
    prediction = np.asarray(prediction, dtype=float)
    if target.shape != prediction.shape:
        raise ValueError("target and prediction shapes differ")
    mask = np.isfinite(target) & np.isfinite(prediction)
    if int(mask.sum()) < 5:
        return float("nan")
    observed = target[mask]
    simulated = prediction[mask]
    denominator = float(np.sum((observed - observed.mean()) ** 2))
    if denominator <= 0.0:
        return float("nan")
    return float(1.0 - np.sum((observed - simulated) ** 2) / denominator)


def audit_reported_metrics(
    target: np.ndarray,
    open_loop_prediction: np.ndarray,
    method_prediction: np.ndarray,
    reported: Mapping[str, float],
    *,
    tolerance: float,
) -> dict[str, float | int | bool]:
    """Require identical comparison masks and recompute both reported metrics."""

    target = np.asarray(target, dtype=float)
    open_loop_prediction = np.asarray(open_loop_prediction, dtype=float)
    method_prediction = np.asarray(method_prediction, dtype=float)
    if not (target.shape == open_loop_prediction.shape == method_prediction.shape):
        raise ValueError("target and prediction shapes differ")
    open_mask = np.isfinite(target) & np.isfinite(open_loop_prediction)
    method_mask = np.isfinite(target) & np.isfinite(method_prediction)
    if not np.array_equal(open_mask, method_mask):
        raise ValueError("open-loop and method finite masks differ")
    recomputed_open = nash_sutcliffe_efficiency(target, open_loop_prediction)
    recomputed_method = nash_sutcliffe_efficiency(target, method_prediction)
    if not np.isfinite(recomputed_open) or not np.isfinite(recomputed_method):
        raise ValueError("metrics are not finite")
    if abs(float(reported["open_loop"]) - recomputed_open) > tolerance:
        raise ValueError("reported open-loop metric fails independent recomputation")
    if abs(float(reported["method"]) - recomputed_method) > tolerance:
        raise ValueError("reported method metric fails independent recomputation")
    return {
        "passed": True,
        "valid_count": int(open_mask.sum()),
        "open_loop": recomputed_open,
        "method": recomputed_method,
        "gain": recomputed_method - recomputed_open,
    }


def split_state_authority(
    *, state_dimension: int, active_dimensions: Iterable[int], storage_dimension: int = 5
) -> dict[str, tuple[int, ...]]:
    """Report which corrected dimensions are HBV stores and which are routing memory."""

    active = tuple(sorted(set(int(value) for value in active_dimensions)))
    if state_dimension < storage_dimension:
        raise ValueError("state dimension is smaller than the HBV storage dimension")
    if any(value < 0 or value >= state_dimension for value in active):
        raise ValueError("active state dimension is outside the state vector")
    active_set = set(active)
    return {
        "storage": tuple(value for value in active if value < storage_dimension),
        "routing": tuple(value for value in active if value >= storage_dimension),
        "inactive": tuple(value for value in range(state_dimension) if value not in active_set),
    }
