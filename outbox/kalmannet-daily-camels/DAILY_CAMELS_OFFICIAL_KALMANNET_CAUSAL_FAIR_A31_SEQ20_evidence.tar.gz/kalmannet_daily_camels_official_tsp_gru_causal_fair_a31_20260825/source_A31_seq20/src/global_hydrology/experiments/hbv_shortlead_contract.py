"""Frozen contract and provenance checks for HBV short-lead recovery experiments."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Mapping


TUKF06_DEVELOPMENT_BASINS = (
    "04105700",
    "08190500",
    "02102908",
    "12447390",
    "01487000",
    "02178400",
    "08070200",
    "09513780",
    "06803510",
    "03076600",
    "12175500",
    "09035800",
    "04027000",
    "08109700",
    "08086290",
    "01440400",
    "05503800",
    "03049000",
    "01435000",
    "02092500",
    "14185900",
)


def sha256_file(path: str | Path, chunk_size: int = 1024 * 1024) -> str:
    """Return the lowercase SHA-256 digest of a file without loading it into memory."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


@dataclass(frozen=True)
class Periods:
    calibration: tuple[str, str]
    evaluation: tuple[str, str]
    calibration_validation_days: int


@dataclass(frozen=True)
class Thresholds:
    median_nse_gain_each_lead: float
    catastrophic_decrement: float
    maximum_degraded_fraction: float
    metric_recompute_tolerance: float


@dataclass(frozen=True)
class TrustedFile:
    role: str
    path: str
    sha256: str


@dataclass(frozen=True)
class ShortLeadContract:
    schema_version: str
    experiment_id: str
    purpose: str
    leads: tuple[int, ...]
    information_timing: str
    periods: Periods
    training_basins: tuple[str, ...]
    holdout_basins: tuple[str, ...]
    thresholds: Thresholds
    random_seeds: tuple[int, ...]
    trusted_files: tuple[TrustedFile, ...]
    forbidden_existing_files: tuple[str, ...]
    holdout_may_select_hyperparameters: bool
    all_predictions_must_be_saved: bool
    formal_evaluation_enabled: bool

    @classmethod
    def from_json(cls, path: str | Path) -> "ShortLeadContract":
        return cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "ShortLeadContract":
        forecast = payload["forecast"]
        periods = payload["periods"]
        basins = payload["basins"]
        thresholds = payload["thresholds"]
        run_policy = payload["run_policy"]
        contract = cls(
            schema_version=str(payload["schema_version"]),
            experiment_id=str(payload["experiment_id"]),
            purpose=str(payload["purpose"]),
            leads=tuple(int(value) for value in forecast["leads_days"]),
            information_timing=str(forecast["information_timing"]),
            periods=Periods(
                calibration=tuple(str(value) for value in periods["calibration"]),
                evaluation=tuple(str(value) for value in periods["evaluation"]),
                calibration_validation_days=int(periods["calibration_validation_days"]),
            ),
            training_basins=tuple(str(value).zfill(8) for value in basins["training"]),
            holdout_basins=tuple(str(value).zfill(8) for value in basins["holdout"]),
            thresholds=Thresholds(**{key: float(value) for key, value in thresholds.items()}),
            random_seeds=tuple(int(value) for value in payload["random_seeds"]),
            trusted_files=tuple(TrustedFile(**record) for record in payload["trusted_files"]),
            forbidden_existing_files=tuple(str(value) for value in run_policy["forbidden_existing_files"]),
            holdout_may_select_hyperparameters=bool(run_policy["holdout_may_select_hyperparameters"]),
            all_predictions_must_be_saved=bool(run_policy["all_predictions_must_be_saved"]),
            formal_evaluation_enabled=bool(
                run_policy.get(
                    "formal_evaluation_enabled",
                    str(payload["schema_version"]) == "hbv_native_shortlead_recovery_v1",
                )
            ),
        )
        contract.validate()
        return contract

    def validate(self) -> None:
        if (self.schema_version, self.experiment_id) not in {
            ("hbv_native_shortlead_recovery_v1", "HSR01"),
            ("hbv_native_shortlead_recovery_v2", "HSR02"),
        }:
            raise ValueError("schema_version and experiment_id identify an unknown recovery contract")
        if self.leads != (1, 2, 3):
            raise ValueError("forecast leads must be exactly (1, 2, 3)")
        if len(self.periods.calibration) != 2 or len(self.periods.evaluation) != 2:
            raise ValueError("calibration and evaluation periods require start and end dates")
        if self.periods.calibration_validation_days < 30:
            raise ValueError("calibration validation period is too short")
        if len(set(self.training_basins)) != len(self.training_basins):
            raise ValueError("training basin identifiers must be unique")
        if len(set(self.holdout_basins)) != len(self.holdout_basins):
            raise ValueError("holdout basin identifiers must be unique")
        if not set(self.training_basins).isdisjoint(self.holdout_basins):
            raise ValueError("training and holdout basins must be disjoint")
        if self.schema_version == "hbv_native_shortlead_recovery_v1":
            if len(self.training_basins) != 40 or len(self.holdout_basins) != 16:
                raise ValueError("HSR01 requires exactly 40 training and 16 holdout basins")
            if not self.formal_evaluation_enabled:
                raise ValueError("HSR01 requires its frozen formal-evaluation capability")
        else:
            if self.training_basins != TUKF06_DEVELOPMENT_BASINS or self.holdout_basins:
                raise ValueError(
                    "HSR02 requires the exact 21 TUKF06 development basins and no holdout"
                )
            if self.formal_evaluation_enabled:
                raise ValueError("HSR02 is development-only and forbids formal evaluation")
        if not math.isclose(self.thresholds.median_nse_gain_each_lead, 0.10, abs_tol=1e-15):
            raise ValueError("median Nash-Sutcliffe efficiency gain gate must remain 0.10")
        if not (0.0 <= self.thresholds.maximum_degraded_fraction <= 1.0):
            raise ValueError("maximum degraded fraction must be between zero and one")
        if self.thresholds.catastrophic_decrement >= 0.0:
            raise ValueError("catastrophic decrement must be negative")
        if self.thresholds.metric_recompute_tolerance <= 0.0:
            raise ValueError("metric tolerance must be positive")
        if not self.random_seeds or len(set(self.random_seeds)) != len(self.random_seeds):
            raise ValueError("random seeds must be nonempty and unique")
        if self.holdout_may_select_hyperparameters:
            raise ValueError("holdout data may not select hyperparameters")
        if not self.all_predictions_must_be_saved:
            raise ValueError("raw predictions must be retained")
        if not self.trusted_files:
            raise ValueError("trusted file hashes are required")
        for record in self.trusted_files:
            if len(record.sha256) != 64 or any(c not in "0123456789abcdef" for c in record.sha256):
                raise ValueError(f"invalid SHA-256 digest for {record.path}")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "experiment_id": self.experiment_id,
            "purpose": self.purpose,
            "forecast": {
                "leads_days": list(self.leads),
                "information_timing": self.information_timing,
            },
            "periods": {
                "calibration": list(self.periods.calibration),
                "evaluation": list(self.periods.evaluation),
                "calibration_validation_days": self.periods.calibration_validation_days,
            },
            "basins": {
                "training": list(self.training_basins),
                "holdout": list(self.holdout_basins),
            },
            "thresholds": asdict(self.thresholds),
            "random_seeds": list(self.random_seeds),
            "trusted_files": [asdict(record) for record in self.trusted_files],
            "run_policy": {
                "forbidden_existing_files": list(self.forbidden_existing_files),
                "holdout_may_select_hyperparameters": self.holdout_may_select_hyperparameters,
                "all_predictions_must_be_saved": self.all_predictions_must_be_saved,
                "formal_evaluation_enabled": self.formal_evaluation_enabled,
            },
        }

    @staticmethod
    def resolve_path(path: str | Path, repository_root: str | Path) -> Path:
        candidate = Path(path)
        return candidate if candidate.is_absolute() else Path(repository_root) / candidate

    def verify_hashes(self, repository_root: str | Path) -> dict[str, dict[str, str]]:
        mismatches: dict[str, dict[str, str]] = {}
        for record in self.trusted_files:
            path = self.resolve_path(record.path, repository_root)
            if not path.is_file():
                mismatches[record.path] = {"expected": record.sha256, "actual": "MISSING"}
                continue
            actual = sha256_file(path)
            if actual != record.sha256:
                mismatches[record.path] = {"expected": record.sha256, "actual": actual}
        return mismatches

    def assert_run_directory_open(self, run_dir: str | Path) -> None:
        run_dir = Path(run_dir)
        for name in self.forbidden_existing_files:
            if (run_dir / name).exists():
                raise FileExistsError(f"run directory already contains forbidden final artifact {name}")
