"""Isolated training and evaluation for native KalmanNet with routed HBV state.

This module deliberately does not import the later shared-training scripts.  It
uses the frozen HBV parameter table, the verified HBV process/observation model,
and the original KalmanNet gain core through the narrow full-state adapter.
"""

from __future__ import annotations

from dataclasses import dataclass
import copy
import csv
import json
import math
from pathlib import Path
import statistics
import sys
import time
from typing import Any, Iterable, Mapping

import numpy as np
import torch

from global_hydrology.data.hbvlite_prior import HBVLitePrior
from global_hydrology.experiments.hbv_shortlead_audit import (
    audit_reported_metrics,
    nash_sutcliffe_efficiency,
)
from global_hydrology.experiments.hbv_shortlead_contract import ShortLeadContract, sha256_file
from global_hydrology.models.knet_native_hbvlite_full_state import (
    NativeHBVFullStateKalmanNet,
    ResidualMemoryHBVSystemModel,
    build_padded_routed_system,
    correction_mask_for_active_lag,
)
from global_hydrology.models.differentiable_hbv_lite import PARAM_NAMES
from global_hydrology.models.official_kalmannet_tsp_hbvlite import (
    SHARED_HYDROLOGY_FEATURE_MODE,
    OfficialKalmanNetTSPHBVAdapter,
)


DTYPE = torch.float32
GAIN_DTYPE = torch.float32
DEVICE = torch.device("cpu")
REPOSITORY_ROOT = Path(__file__).resolve().parents[3]
NEURALHYDROLOGY_ROOT = Path("G:/github/pycharm/projects/neuralhydrology")
CAPPED_UNIT_RESIDUAL_GAIN_INITIALIZATION = "capped_unit_residual_gain_initialization"
REPOSITORY_NATIVE_LSTM_BACKEND = "repository_native_hydrology_lstm"
UPSTREAM_OFFICIAL_GRU_BACKEND = "upstream_official_kalmannet_tsp_gru"
TRAINING_PERIOD_VARIANCE_FORECAST_MSE = (
    "training_period_variance_normalized_forecast_mse"
)
TRAINING_PERIOD_PER_LEAD_VARIANCE_FORECAST_MSE = (
    "training_period_per_lead_target_variance_normalized_forecast_mse"
)
SUPPORTED_TRAINING_LOSS_MODES = frozenset(
    {
        TRAINING_PERIOD_VARIANCE_FORECAST_MSE,
        TRAINING_PERIOD_PER_LEAD_VARIANCE_FORECAST_MSE,
    }
)
CAUSAL_PARAMETER_ONLY_INITIALIZATION = "causal_parameter_only_default"
FUTURE_PRIOR_DIAGNOSTIC_INITIALIZATION = "future_prior_state_diagnostic_only"
SUPPORTED_INITIALIZATION_MODES = frozenset(
    {CAUSAL_PARAMETER_ONLY_INITIALIZATION, FUTURE_PRIOR_DIAGNOSTIC_INITIALIZATION}
)
PREPARED_BASIN_SCHEMA = "daily_camels_official_kalmannet_prepared_basin_v1"
PREPARED_BASIN_KEYS = frozenset(
    {
        "schema_version",
        "basin_id",
        "calibration_start",
        "calibration_end",
        "initialization_mode",
        "parameter_names",
        "params",
        "initial_storage",
        "source_state_dimension",
        "forcing_calibration",
        "observation_calibration",
        "dates_calibration",
    }
)
KalmanNetBackend = NativeHBVFullStateKalmanNet | OfficialKalmanNetTSPHBVAdapter


def configure_runtime_device(device_name: str) -> torch.device:
    """Select the explicit process-local device before any basin is prepared."""

    global DEVICE
    candidate = torch.device(str(device_name))
    if candidate.type not in {"cpu", "cuda"}:
        raise ValueError("runtime device must be cpu or cuda")
    if candidate.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    DEVICE = candidate
    return DEVICE


@dataclass
class BasinSeries:
    basin_id: str
    system: Any
    active_lag: int
    initial_state: torch.Tensor
    forcing_calibration: torch.Tensor
    observation_calibration: torch.Tensor
    valid_calibration: torch.Tensor
    dates_calibration: tuple[str, ...]
    open_loop_calibration: torch.Tensor
    open_loop_states_calibration: torch.Tensor
    validation_start: int
    correction_mask: torch.Tensor
    state_lower_bound: torch.Tensor
    state_upper_bound: torch.Tensor
    observation_feature_scale: torch.Tensor
    state_feature_scale: torch.Tensor
    correction_cap_by_state_scale_units: torch.Tensor
    loss_variance: float
    loss_variance_by_lead: dict[int, float]
    initialization_mode: str
    source_state_dimension: int | None = None
    prepared_input_sha256: str | None = None
    residual_memory_coefficients: tuple[float, float] | None = None
    forcing_evaluation: torch.Tensor | None = None
    observation_evaluation: torch.Tensor | None = None
    valid_evaluation: torch.Tensor | None = None
    dates_evaluation: tuple[str, ...] | None = None
    open_loop_evaluation: torch.Tensor | None = None
    open_loop_states_evaluation: torch.Tensor | None = None


def physical_segment_initial_state(
    initial_state: torch.Tensor,
    open_loop_states: torch.Tensor,
    segment_start: int,
) -> torch.Tensor:
    """Use the physical state immediately before a randomly sampled segment."""

    if segment_start < 0 or segment_start > len(open_loop_states):
        raise ValueError("segment start is outside the physical trajectory")
    if segment_start == 0:
        return initial_state.clone()
    return open_loop_states[segment_start - 1].clone()


def _project_state(
    state: torch.Tensor, lower: torch.Tensor, upper: torch.Tensor
) -> torch.Tensor:
    return torch.maximum(torch.minimum(state, upper), lower)


def simulate_open_loop(
    system: Any,
    initial_state: torch.Tensor,
    forcing: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Return discharge ``[T]`` and post-process states ``[T,1,m]``."""

    discharge = []
    states = []
    state = initial_state.clone()
    with torch.no_grad():
        for index in range(len(forcing)):
            state = system.f(state, forcing[index : index + 1])
            if not bool(torch.isfinite(state).all()):
                raise FloatingPointError(f"nonfinite HBV open-loop state at step {index}")
            states.append(state.clone())
            discharge.append(system.h(state).reshape(()).clone())
    return torch.stack(discharge), torch.stack(states)


def _date_strings(index: Any) -> tuple[str, ...]:
    output = []
    for value in index:
        if hasattr(value, "date"):
            output.append(str(value.date()))
        else:
            output.append(str(value)[:10])
    return tuple(output)


def _physical_dtype(family: Mapping[str, Any]) -> torch.dtype:
    name = str(family.get("physical_model_dtype", "float32"))
    if name == "float32":
        return torch.float32
    if name == "float64":
        return torch.float64
    raise ValueError(f"unsupported physical model dtype: {name}")


def causal_default_storage(parameters: torch.Tensor) -> torch.Tensor:
    """Match the existing parity pipeline's parameter-only causal HBV start state."""

    parameters = parameters.reshape(-1, len(PARAM_NAMES))
    field_capacity = parameters[
        :, PARAM_NAMES.index("parFC") : PARAM_NAMES.index("parFC") + 1
    ]
    zeros = torch.zeros_like(field_capacity)
    return torch.cat(
        [
            zeros,
            zeros,
            0.3 * field_capacity,
            torch.full_like(zeros, 5.0),
            torch.full_like(zeros, 10.0),
        ],
        dim=-1,
    )


def _load_period(
    basin_id: str,
    period: tuple[str, str],
    *,
    dtype: torch.dtype = DTYPE,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, tuple[str, ...]]:
    neural_src = str(NEURALHYDROLOGY_ROOT / "src")
    if neural_src not in sys.path:
        sys.path.insert(0, neural_src)
    from hydroagent.data_loading import load_camels_basin

    forcing_frame, observation, _ = load_camels_basin(
        basin_id,
        data_root=str(NEURALHYDROLOGY_ROOT / "data" / "camels_us"),
        start_date=period[0],
        end_date=period[1],
        forcing="maurer",
        pet_method="oudin",
        keep_obs_nan_days=True,
    )
    forcing = torch.tensor(
        np.stack(
            [
                forcing_frame["prcp"].to_numpy(dtype=float),
                forcing_frame["tmean"].to_numpy(dtype=float),
                forcing_frame["ep"].to_numpy(dtype=float),
            ],
            axis=1,
        ),
        dtype=dtype,
        device=DEVICE,
    )
    observations = torch.tensor(
        observation.to_numpy(dtype=float), dtype=dtype, device=DEVICE
    )
    if not bool(torch.isfinite(forcing).all()):
        raise ValueError(f"forcing contains nonfinite values for basin {basin_id}")
    return forcing, observations, torch.isfinite(observations), _date_strings(forcing_frame.index)


def _scalar_string(archive: Mapping[str, np.ndarray], key: str) -> str:
    value = np.asarray(archive[key])
    if value.shape != ():
        raise ValueError(f"prepared basin field {key} must be a scalar string")
    return str(value.item())


def load_prepared_calibration_input(
    prepared_data_root: Path,
    basin_id: str,
    calibration_period: tuple[str, str],
    *,
    initialization_mode: str = CAUSAL_PARAMETER_ONLY_INITIALIZATION,
    dtype: torch.dtype = DTYPE,
    expected_sha256: str | None = None,
) -> tuple[
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    tuple[str, ...],
    int,
    str,
]:
    """Load one calibration-only, portable basin archive with strict geometry checks."""

    path = Path(prepared_data_root) / f"{basin_id}.npz"
    if not path.is_file():
        raise FileNotFoundError(f"prepared basin archive does not exist: {path}")
    input_sha256 = sha256_file(path)
    if expected_sha256 is not None and input_sha256 != expected_sha256:
        raise ValueError(f"prepared basin archive hash differs for {basin_id}")
    with np.load(path, allow_pickle=False) as stored:
        if set(stored.files) != set(PREPARED_BASIN_KEYS):
            raise ValueError(f"prepared basin archive keys differ for {basin_id}")
        archive = {name: np.asarray(stored[name]) for name in stored.files}
    if sha256_file(path) != input_sha256:
        raise RuntimeError(f"prepared basin archive changed while reading {basin_id}")
    if _scalar_string(archive, "schema_version") != PREPARED_BASIN_SCHEMA:
        raise ValueError(f"prepared basin schema differs for {basin_id}")
    if _scalar_string(archive, "basin_id") != basin_id:
        raise ValueError(f"prepared basin identity differs for {basin_id}")
    if (
        _scalar_string(archive, "calibration_start"),
        _scalar_string(archive, "calibration_end"),
    ) != tuple(calibration_period):
        raise ValueError(f"prepared calibration period differs for {basin_id}")
    if _scalar_string(archive, "initialization_mode") != initialization_mode:
        raise ValueError(f"prepared initialization mode differs for {basin_id}")
    parameter_names = tuple(str(value) for value in archive["parameter_names"].tolist())
    if parameter_names != tuple(PARAM_NAMES):
        raise ValueError(f"prepared parameter order differs for {basin_id}")

    params = np.asarray(archive["params"], dtype=np.float64)
    initial_storage = np.asarray(archive["initial_storage"], dtype=np.float64)
    source_state_dimension_array = np.asarray(archive["source_state_dimension"])
    forcing_array = np.asarray(archive["forcing_calibration"], dtype=np.float64)
    observation_array = np.asarray(archive["observation_calibration"], dtype=np.float64)
    date_array = np.asarray(archive["dates_calibration"])
    if params.shape != (len(PARAM_NAMES),) or initial_storage.shape != (5,):
        raise ValueError(f"prepared HBV parameter or state shape differs for {basin_id}")
    if source_state_dimension_array.shape != ():
        raise ValueError(f"prepared source state dimension shape differs for {basin_id}")
    source_state_dimension = int(source_state_dimension_array.item())
    if not 6 <= source_state_dimension <= 20:
        raise ValueError(f"prepared source state dimension differs for {basin_id}")
    if forcing_array.ndim != 2 or forcing_array.shape[1] != 3:
        raise ValueError(f"prepared forcing shape differs for {basin_id}")
    if observation_array.shape != (len(forcing_array),) or date_array.shape != (
        len(forcing_array),
    ):
        raise ValueError(f"prepared time-series lengths differ for {basin_id}")
    if not (
        np.isfinite(params).all()
        and np.isfinite(initial_storage).all()
        and np.isfinite(forcing_array).all()
    ):
        raise ValueError(f"prepared physical inputs are nonfinite for {basin_id}")
    if initialization_mode == CAUSAL_PARAMETER_ONLY_INITIALIZATION:
        expected_initial_storage = np.asarray(
            [0.0, 0.0, 0.3 * params[PARAM_NAMES.index("parFC")], 5.0, 10.0],
            dtype=np.float64,
        )
        if not np.allclose(
            initial_storage, expected_initial_storage, rtol=0.0, atol=1e-6
        ):
            raise ValueError(f"prepared causal initial storage differs for {basin_id}")
    if np.isinf(observation_array).any() or int(np.isfinite(observation_array).sum()) < 2:
        raise ValueError(f"prepared observations are invalid for {basin_id}")

    expected_dates = np.arange(
        np.datetime64(calibration_period[0], "D"),
        np.datetime64(calibration_period[1], "D") + np.timedelta64(1, "D"),
        dtype="datetime64[D]",
    )
    try:
        actual_dates = date_array.astype("datetime64[D]")
    except (TypeError, ValueError) as error:
        raise ValueError(f"prepared dates are invalid for {basin_id}") from error
    if not np.array_equal(actual_dates, expected_dates):
        raise ValueError(f"prepared dates are not the exact calibration calendar for {basin_id}")

    forcing = torch.tensor(forcing_array, dtype=dtype, device=DEVICE)
    observations = torch.tensor(observation_array, dtype=dtype, device=DEVICE)
    return (
        torch.tensor(params, dtype=dtype, device=DEVICE).reshape(1, -1),
        torch.tensor(initial_storage, dtype=dtype, device=DEVICE).reshape(1, -1),
        forcing,
        observations,
        torch.isfinite(observations),
        tuple(str(value)[:10] for value in actual_dates),
        source_state_dimension,
        input_sha256,
    )


def _difference_rms(values: torch.Tensor, *, floor: float) -> torch.Tensor:
    differences = values[1:] - values[:-1]
    if differences.ndim == 1:
        valid = torch.isfinite(differences)
        if not bool(valid.any()):
            return values.new_tensor(floor)
        scale = torch.sqrt(torch.mean(differences[valid].square()))
        return torch.clamp(scale, min=floor)
    valid = torch.isfinite(differences)
    squared = torch.where(valid, differences.square(), torch.zeros_like(differences))
    counts = valid.sum(dim=0).clamp(min=1)
    scale = torch.sqrt(squared.sum(dim=0) / counts)
    return torch.clamp(scale, min=floor)


def _fit_stable_residual_ar2(
    residual: torch.Tensor, *, maximum_root_magnitude: float
) -> torch.Tensor:
    if not 0.0 < maximum_root_magnitude < 1.0:
        raise ValueError("maximum_root_magnitude must be between zero and one")
    values = residual.detach().cpu().numpy().astype(float)
    target = values[2:]
    first = values[1:-1]
    second = values[:-2]
    valid = np.isfinite(target) & np.isfinite(first) & np.isfinite(second)
    if int(valid.sum()) < 30:
        raise ValueError("too few finite residuals to fit autoregressive memory")
    coefficients = np.linalg.lstsq(
        np.stack([first[valid], second[valid]], axis=1), target[valid], rcond=None
    )[0]
    roots = np.roots([1.0, -coefficients[0], -coefficients[1]])
    largest = float(np.max(np.abs(roots)))
    # Leave a small margin so conversion to the float32 experiment dtype cannot
    # round a characteristic root just outside the declared stability bound.
    stable_limit = maximum_root_magnitude * (1.0 - 1e-6)
    if largest > stable_limit:
        roots = roots * (stable_limit / largest)
        coefficients = np.asarray([np.sum(roots).real, -np.prod(roots).real])
    return torch.tensor(coefficients, dtype=residual.dtype, device=residual.device)


def prepare_basin(
    prior: HBVLitePrior | None,
    basin_id: str,
    contract: ShortLeadContract,
    family: Mapping[str, Any],
    *,
    load_evaluation: bool,
    prepared_data_root: Path | None = None,
    prepared_input_expected_sha256: str | None = None,
) -> BasinSeries:
    """Load one basin and derive every scale from calibration training data only."""

    physical_dtype = _physical_dtype(family)
    initialization_mode = str(
        family.get(
            "initialization_mode", FUTURE_PRIOR_DIAGNOSTIC_INITIALIZATION
        )
    )
    if initialization_mode not in SUPPORTED_INITIALIZATION_MODES:
        raise ValueError(f"unsupported initialization mode: {initialization_mode}")
    prepared_input_sha256 = None
    source_state_dimension = None
    cal = tuple(contract.periods.calibration)
    if prepared_data_root is None:
        if prior is None:
            raise ValueError("HBV prior is required without prepared calibration data")
        index = prior.id2idx[basin_id]
        params = prior.param_table[index : index + 1].to(
            device=DEVICE, dtype=physical_dtype
        )
        if initialization_mode == CAUSAL_PARAMETER_ONLY_INITIALIZATION:
            initial_storage = causal_default_storage(params)
        else:
            initial_storage = prior.x0_table[index : index + 1].to(
                device=DEVICE, dtype=physical_dtype
            )
        forcing_cal, obs_cal, valid_cal, dates_cal = _load_period(
            basin_id, cal, dtype=physical_dtype
        )
    else:
        if load_evaluation:
            raise ValueError("prepared calibration-only input cannot serve formal evaluation")
        (
            params,
            initial_storage,
            forcing_cal,
            obs_cal,
            valid_cal,
            dates_cal,
            source_state_dimension,
            prepared_input_sha256,
        ) = load_prepared_calibration_input(
            prepared_data_root,
            basin_id,
            cal,
            initialization_mode=initialization_mode,
            dtype=physical_dtype,
            expected_sha256=prepared_input_expected_sha256,
        )
    base_system, active_lag = build_padded_routed_system(
        params,
        maximum_lag=int(family["maximum_routing_lag"]),
        x0=initial_storage,
        dtype=physical_dtype,
        device=DEVICE,
    )
    if (
        source_state_dimension is not None
        and source_state_dimension != 5 + active_lag
    ):
        raise ValueError(
            f"prepared source state dimension and active routing lag differ for {basin_id}"
        )
    base_initial_state = base_system.get_default_initial_state()
    open_cal, base_states_cal = simulate_open_loop(
        base_system, base_initial_state, forcing_cal
    )
    validation_start = len(obs_cal) - contract.periods.calibration_validation_days
    if validation_start <= int(family["segment_days"]) + max(contract.leads):
        raise ValueError(f"calibration training period too short for basin {basin_id}")

    residual_coefficients = None
    residual_order = int(family.get("residual_memory_order", 0))
    if residual_order == 0:
        system = base_system
        initial_state = base_initial_state
        states_cal = base_states_cal
    elif residual_order == 2:
        coefficients = _fit_stable_residual_ar2(
            obs_cal[:validation_start] - open_cal[:validation_start],
            maximum_root_magnitude=float(family["residual_maximum_root_magnitude"]),
        )
        system = ResidualMemoryHBVSystemModel(base_system, coefficients)
        initial_state = system.get_default_initial_state()
        zeros = torch.zeros(
            len(base_states_cal), 1, 2, dtype=physical_dtype, device=DEVICE
        )
        states_cal = torch.cat([base_states_cal, zeros], dim=-1)
        residual_coefficients = (float(coefficients[0]), float(coefficients[1]))
    else:
        raise ValueError("residual_memory_order must be zero or two")

    training_obs = obs_cal[:validation_start]
    observation_scale = _difference_rms(training_obs, floor=0.1).reshape(1, 1)
    training_states = states_cal[:validation_start, 0, :]
    state_scale = _difference_rms(training_states, floor=0.1).reshape(1, system.m)
    # The padded routing tail is physically inactive and should stay a neutral unit feature.
    base_dimension = base_system.m
    state_scale[:, 5 + active_lag : base_dimension] = 1.0
    if residual_order == 2:
        state_scale[:, base_dimension:] = observation_scale
    if bool(family.get("use_state_upper_bound", False)):
        multiplier = float(family["state_upper_bound_multiplier"])
        state_upper = torch.clamp(training_states.max(dim=0).values * multiplier, min=1.0).reshape(1, system.m)
        state_upper[:, 5 + active_lag : base_dimension] = 1.0
    else:
        # A finite calibration-derived upper bound changes the physical model during
        # validation/evaluation even when the learned correction is exactly zero.
        # Infinity preserves exact HBV open-loop identity; correction caps provide stability.
        state_upper = torch.full(
            (1, system.m), torch.inf, dtype=physical_dtype, device=DEVICE
        )
    if bool(family.get("use_soil_field_capacity_upper_bound", False)):
        field_capacity = params[0, PARAM_NAMES.index("parFC")]
        state_upper[:, 2] = field_capacity
    state_lower = torch.zeros((1, system.m), dtype=physical_dtype, device=DEVICE)
    if residual_order == 2:
        state_lower[:, base_dimension:] = -torch.inf
    finite_training = training_obs[torch.isfinite(training_obs)]
    loss_variance = float(torch.var(finite_training, unbiased=False)) if finite_training.numel() else float("nan")
    if not math.isfinite(loss_variance) or loss_variance <= 1e-6:
        raise ValueError(f"invalid calibration training flow variance for basin {basin_id}")
    common_issue_stop = validation_start - max(contract.leads)
    loss_variance_by_lead: dict[int, float] = {}
    for lead in contract.leads:
        lead_targets = training_obs[lead : common_issue_stop + lead]
        finite_lead_targets = lead_targets[torch.isfinite(lead_targets)]
        variance = (
            float(torch.var(finite_lead_targets, unbiased=False))
            if finite_lead_targets.numel()
            else float("nan")
        )
        if not math.isfinite(variance) or variance <= 1e-6:
            raise ValueError(
                f"invalid calibration training target variance for basin {basin_id} lead {lead}"
            )
        loss_variance_by_lead[int(lead)] = variance
    mask = correction_mask_for_active_lag(
        system.m, active_lag, dtype=physical_dtype, device=DEVICE
    )
    corrected_storage_indices = tuple(int(value) for value in family["corrected_storage_indices"])
    if len(set(corrected_storage_indices)) != len(corrected_storage_indices) or any(
        value < 0 or value >= 5 for value in corrected_storage_indices
    ):
        raise ValueError("corrected_storage_indices must be unique HBV storage indices")
    mask[:, :5] = 0.0
    for storage_index in corrected_storage_indices:
        mask[:, storage_index] = 1.0
    configured_cap = family.get("correction_cap_in_state_scale_units")
    correction_cap = torch.inf if configured_cap is None else float(configured_cap)
    if correction_cap <= 0.0:
        raise ValueError("correction_cap_in_state_scale_units must be positive or null")
    correction_caps = torch.full(
        (1, system.m), correction_cap, dtype=physical_dtype, device=DEVICE
    )
    if residual_order == 2:
        mask[:, base_dimension:] = 1.0
        correction_caps[:, base_dimension:] = float(
            family["residual_correction_cap_in_state_scale_units"]
        )

    data = BasinSeries(
        basin_id=basin_id,
        system=system,
        active_lag=active_lag,
        initial_state=initial_state,
        forcing_calibration=forcing_cal,
        observation_calibration=obs_cal,
        valid_calibration=valid_cal,
        dates_calibration=dates_cal,
        open_loop_calibration=open_cal,
        open_loop_states_calibration=states_cal,
        validation_start=validation_start,
        correction_mask=mask,
        state_lower_bound=state_lower,
        state_upper_bound=state_upper,
        observation_feature_scale=observation_scale,
        state_feature_scale=state_scale,
        correction_cap_by_state_scale_units=correction_caps,
        loss_variance=loss_variance,
        loss_variance_by_lead=loss_variance_by_lead,
        initialization_mode=initialization_mode,
        source_state_dimension=source_state_dimension,
        prepared_input_sha256=prepared_input_sha256,
        residual_memory_coefficients=residual_coefficients,
    )
    if load_evaluation:
        evaluation = tuple(contract.periods.evaluation)
        forcing, observation, valid, dates = _load_period(
            basin_id, evaluation, dtype=physical_dtype
        )
        open_loop, states = simulate_open_loop(system, initial_state, forcing)
        data.forcing_evaluation = forcing
        data.observation_evaluation = observation
        data.valid_evaluation = valid
        data.dates_evaluation = dates
        data.open_loop_evaluation = open_loop
        data.open_loop_states_evaluation = states
    return data


def build_shared_network(reference: BasinSeries, family: Mapping[str, Any]) -> KalmanNetBackend:
    backend = str(family.get("network_backend", REPOSITORY_NATIVE_LSTM_BACKEND))
    configured_gain_dtype = str(family.get("gain_network_dtype", "float32"))
    configured_cap = family.get("correction_cap_in_state_scale_units")
    correction_cap = None if configured_cap is None else float(configured_cap)
    if backend == REPOSITORY_NATIVE_LSTM_BACKEND:
        net: KalmanNetBackend = NativeHBVFullStateKalmanNet(
            reference.system,
            correction_mask=reference.correction_mask,
            state_lower_bound=reference.state_lower_bound,
            state_upper_bound=reference.state_upper_bound,
            device=DEVICE,
            hidden=int(family["hidden_dimension"]),
            in_mult=int(family["input_multiplier"]),
            out_mult=int(family["output_multiplier"]),
            correction_cap_in_state_scale_units=correction_cap,
        ).to(device=DEVICE, dtype=reference.initial_state.dtype)
    elif backend == UPSTREAM_OFFICIAL_GRU_BACKEND:
        if configured_gain_dtype != "float32":
            raise ValueError("upstream official KalmanNet gain_network_dtype must be float32")
        net = OfficialKalmanNetTSPHBVAdapter(
            reference.system,
            correction_mask=reference.correction_mask,
            state_lower_bound=reference.state_lower_bound,
            state_upper_bound=reference.state_upper_bound,
            input_multiplier=int(family["input_multiplier"]),
            output_multiplier=int(family["output_multiplier"]),
            correction_cap_in_state_scale_units=correction_cap,
            feature_mode=str(
                family.get("feature_mode", SHARED_HYDROLOGY_FEATURE_MODE)
            ),
        ).to(device=DEVICE)
        if next(net.parameters()).dtype != GAIN_DTYPE:
            raise RuntimeError("upstream official KalmanNet gain core must remain float32")
    else:
        raise ValueError(f"unsupported network_backend: {backend}")
    if bool(family["zero_gain_initialization"]):
        if hasattr(net, "zero_gain_head"):
            net.zero_gain_head()
        else:
            with torch.no_grad():
                net.FC2[-1].weight.zero_()
                net.FC2[-1].bias.zero_()
    if hasattr(reference.system, "residual_current_index"):
        with torch.no_grad():
            net.FC2[-1].bias[int(reference.system.residual_current_index)] = float(
                family["residual_initial_current_gain"]
            )
    return net


def _adapt_network(net: KalmanNetBackend, basin: BasinSeries, family: Mapping[str, Any]) -> None:
    guard_value = family.get("normalized_feature_guard")
    net.set_basin_adaptation(
        system=basin.system,
        correction_mask=basin.correction_mask,
        state_lower_bound=basin.state_lower_bound,
        state_upper_bound=basin.state_upper_bound,
        observation_feature_scale=basin.observation_feature_scale,
        state_feature_scale=basin.state_feature_scale,
        correction_cap_by_state_scale_units=basin.correction_cap_by_state_scale_units,
        normalized_feature_guard=(None if guard_value is None else float(guard_value)),
    )


def filter_segment(
    net: KalmanNetBackend,
    basin: BasinSeries,
    forcing: torch.Tensor,
    observations: torch.Tensor,
    valid: torch.Tensor,
    *,
    start: int,
    end: int,
    initial_state: torch.Tensor,
) -> list[torch.Tensor]:
    if not (0 <= start < end <= len(observations)):
        raise ValueError("invalid filter segment")
    previous_observation = None
    if start > 0 and bool(valid[start - 1]):
        previous_observation = observations[start - 1 : start]
    net.initialize_filter(
        initial_state,
        sequence_length=end - start,
        previous_observation=previous_observation,
    )
    posterior_states = []
    for time_index in range(start, end):
        controls = forcing[time_index : time_index + 1]
        if bool(valid[time_index]):
            posterior = net.analysis_step(observations[time_index : time_index + 1], controls)
        else:
            posterior = net.predict_step(controls)
        if not bool(torch.isfinite(posterior).all()):
            raise FloatingPointError(f"nonfinite posterior at {basin.basin_id} day {time_index}")
        posterior_states.append(posterior)
    return posterior_states


def multilead_forecast_loss(
    basin: BasinSeries,
    posterior_states: list[torch.Tensor],
    forcing: torch.Tensor,
    observations: torch.Tensor,
    *,
    segment_start: int,
    warmup_days: int,
    leads: tuple[int, ...],
    lead_weights: tuple[float, ...],
    origin_stride: int,
    loss_mode: str = TRAINING_PERIOD_VARIANCE_FORECAST_MSE,
) -> torch.Tensor:
    if len(leads) != len(lead_weights) or origin_stride < 1:
        raise ValueError("invalid forecast-loss contract")
    if any(not math.isfinite(weight) or weight <= 0.0 for weight in lead_weights):
        raise ValueError("forecast lead weights must be finite and positive")
    if not math.isclose(sum(lead_weights), 1.0, rel_tol=0.0, abs_tol=1e-12):
        raise ValueError("forecast lead weights must sum to one")
    if loss_mode not in SUPPORTED_TRAINING_LOSS_MODES:
        raise ValueError(f"unsupported training loss mode: {loss_mode}")
    errors_by_lead: dict[int, list[torch.Tensor]] = {lead: [] for lead in leads}
    for local_index in range(warmup_days, len(posterior_states), origin_stride):
        issue = segment_start + local_index
        state = posterior_states[local_index]
        previous_lead = 0
        for lead, weight in zip(leads, lead_weights):
            for offset in range(previous_lead + 1, lead + 1):
                target = issue + offset
                if target >= len(observations):
                    break
                state = _project_state(
                    basin.system.f(state, forcing[target : target + 1]),
                    basin.state_lower_bound,
                    basin.state_upper_bound,
                )
            target = issue + lead
            if target < len(observations) and bool(torch.isfinite(observations[target])):
                prediction = basin.system.h(state).reshape(())
                error = prediction - observations[target]
                errors_by_lead[lead].append(error)
            previous_lead = lead

    total = torch.zeros(
        (),
        dtype=basin.observation_calibration.dtype,
        device=basin.observation_calibration.device,
    )
    for lead, weight in zip(leads, lead_weights):
        if not errors_by_lead[lead]:
            raise ValueError(f"forecast loss has no valid targets for lead {lead}")
        errors = torch.stack(errors_by_lead[lead])
        mean_squared_error = errors.square().mean()
        if loss_mode == TRAINING_PERIOD_VARIANCE_FORECAST_MSE:
            denominator = errors.new_tensor(basin.loss_variance)
        else:
            denominator = errors.new_tensor(basin.loss_variance_by_lead[int(lead)])
        total = total + float(weight) * mean_squared_error / denominator
    return total


def _fixed_validation_start(basin: BasinSeries, segment_days: int, max_lead: int) -> int:
    last = len(basin.observation_calibration) - segment_days - max_lead
    span = last - basin.validation_start
    if span < 0:
        raise ValueError(f"validation window does not fit for basin {basin.basin_id}")
    stable_number = sum((index + 1) * int(char) for index, char in enumerate(basin.basin_id))
    return basin.validation_start + (stable_number % (span + 1))


def train_shared_network(
    basins: list[BasinSeries],
    contract: ShortLeadContract,
    family: Mapping[str, Any],
    *,
    seed: int,
    epochs: int | None = None,
    steps_per_epoch: int | None = None,
    segment_days: int | None = None,
    warmup_days: int | None = None,
) -> tuple[KalmanNetBackend, dict[str, Any]]:
    if not basins:
        raise ValueError("training basins are empty")
    torch.manual_seed(int(seed))
    net = build_shared_network(basins[0], family)
    optimizer = torch.optim.Adam(
        net.parameters(),
        lr=float(family["learning_rate"]),
        weight_decay=float(family["weight_decay"]),
    )
    epochs = int(epochs if epochs is not None else family["training_epochs"])
    steps_per_epoch = int(
        steps_per_epoch if steps_per_epoch is not None else family["steps_per_epoch"]
    )
    segment_days = int(segment_days if segment_days is not None else family["segment_days"])
    warmup_days = int(warmup_days if warmup_days is not None else family["filter_warmup_days"])
    leads = contract.leads
    lead_weights = tuple(float(value) for value in family["loss_lead_weights"])
    loss_mode = str(
        family.get("training_loss_mode", TRAINING_PERIOD_VARIANCE_FORECAST_MSE)
    )
    if loss_mode not in SUPPORTED_TRAINING_LOSS_MODES:
        raise ValueError(f"unsupported training loss mode: {loss_mode}")
    origin_stride = int(family["forecast_origin_stride"])
    generator = torch.Generator().manual_seed(int(seed) + 1000)
    best_validation = float("inf")
    best_selection_score = float("-inf")
    best_selection_summary: dict[str, Any] | None = None
    best_state = copy.deepcopy(net.state_dict())
    no_improvement = 0
    patience = int(family["early_stopping_patience"])
    ever_nonzero_gradients: set[str] = set()
    history = []
    skipped_steps = 0
    basin_sampling_attempt_counts = {basin.basin_id: 0 for basin in basins}
    basin_optimizer_step_counts = {basin.basin_id: 0 for basin in basins}
    start_clock = time.perf_counter()

    def compute_validation_loss() -> float:
        net.eval()
        validation_losses = []
        with torch.no_grad():
            for validation_basin in basins:
                validation_start = _fixed_validation_start(
                    validation_basin, segment_days, max(leads)
                )
                validation_end = validation_start + segment_days
                validation_initial = physical_segment_initial_state(
                    validation_basin.initial_state,
                    validation_basin.open_loop_states_calibration,
                    validation_start,
                )
                _adapt_network(net, validation_basin, family)
                validation_posterior = filter_segment(
                    net,
                    validation_basin,
                    validation_basin.forcing_calibration,
                    validation_basin.observation_calibration,
                    validation_basin.valid_calibration,
                    start=validation_start,
                    end=validation_end,
                    initial_state=validation_initial,
                )
                validation_loss = multilead_forecast_loss(
                    validation_basin,
                    validation_posterior,
                    validation_basin.forcing_calibration,
                    validation_basin.observation_calibration,
                    segment_start=validation_start,
                    warmup_days=warmup_days,
                    leads=leads,
                    lead_weights=lead_weights,
                    origin_stride=origin_stride,
                    loss_mode=loss_mode,
                )
                if bool(torch.isfinite(validation_loss)):
                    validation_losses.append(float(validation_loss))
        if not validation_losses:
            raise RuntimeError("no finite validation losses")
        return float(np.mean(validation_losses))

    def compute_continuous_validation_selection() -> tuple[float, dict[str, Any]]:
        validation_rows = []
        for validation_basin in basins:
            validation_row, _ = evaluate_basin(
                net,
                validation_basin,
                contract,
                family,
                formal_evaluation=False,
            )
            validation_rows.append(validation_row)
        median_gains = {}
        median_method_nse = {}
        median_open_loop_nse = {}
        degraded_fractions = {}
        for lead in leads:
            values = np.asarray(
                [row["gain_over_open_loop"][str(lead)] for row in validation_rows],
                dtype=float,
            )
            method_values = np.asarray(
                [row["nse_method"][str(lead)] for row in validation_rows], dtype=float
            )
            open_values = np.asarray(
                [row["nse_open_loop"][str(lead)] for row in validation_rows], dtype=float
            )
            if not bool(
                np.isfinite(values).all()
                and np.isfinite(method_values).all()
                and np.isfinite(open_values).all()
            ):
                return float("-inf"), {
                    "passed_finite": False,
                    "median_gains": median_gains,
                    "median_method_nse": median_method_nse,
                    "median_open_loop_nse": median_open_loop_nse,
                    "degraded_fractions": degraded_fractions,
                }
            median_gains[str(lead)] = float(np.median(values))
            median_method_nse[str(lead)] = float(np.median(method_values))
            median_open_loop_nse[str(lead)] = float(np.median(open_values))
            degraded_fractions[str(lead)] = float(
                np.mean(values < contract.thresholds.catastrophic_decrement)
            )
        worst_median_gain = min(median_gains.values())
        worst_degraded_fraction = max(degraded_fractions.values())
        # Favor the weakest lead and penalize improvements bought through
        # catastrophic basin-level degradation.
        score = worst_median_gain - worst_degraded_fraction
        return score, {
            "passed_finite": True,
            "median_gains": median_gains,
            "median_method_nse": median_method_nse,
            "median_open_loop_nse": median_open_loop_nse,
            "degraded_fractions": degraded_fractions,
            "worst_median_gain": worst_median_gain,
            "worst_degraded_fraction": worst_degraded_fraction,
            "selection_score": score,
        }

    # Retain the exact open loop as a candidate even when residual-memory data
    # assimilation is initialized with a unit gain. This prevents a positive
    # control from silently displacing a safer baseline before training starts.
    initialization_states: list[tuple[str, dict[str, torch.Tensor]]] = []
    residual_index = getattr(basins[0].system, "residual_current_index", None)
    residual_initial_gain = float(family.get("residual_initial_current_gain", 0.0))
    if residual_index is not None and residual_initial_gain != 0.0:
        initialization_states.append(
            (CAPPED_UNIT_RESIDUAL_GAIN_INITIALIZATION, copy.deepcopy(net.state_dict()))
        )
        with torch.no_grad():
            net.FC2[-1].weight.zero_()
            net.FC2[-1].bias.zero_()
        initialization_states.append(("zero_gain_open_loop", copy.deepcopy(net.state_dict())))
    else:
        initialization_states.append(("zero_gain_open_loop", copy.deepcopy(net.state_dict())))

    initialization_results: list[dict[str, Any]] = []
    for label, candidate_state in initialization_states:
        net.load_state_dict(candidate_state)
        validation_loss = compute_validation_loss()
        selection_score, selection_summary = compute_continuous_validation_selection()
        initialization_results.append(
            {
                "label": label,
                "validation_loss": validation_loss,
                "selection_score": selection_score,
                "continuous_validation_selection": selection_summary,
                "state_dict": candidate_state,
            }
        )
    selected_initialization = max(
        initialization_results, key=lambda value: float(value["selection_score"])
    )
    best_validation = float(selected_initialization["validation_loss"])
    best_selection_score = float(selected_initialization["selection_score"])
    best_selection_summary = selected_initialization["continuous_validation_selection"]
    best_state = copy.deepcopy(selected_initialization["state_dict"])
    initial_selection_score = best_selection_score
    best_epoch = 0
    net.load_state_dict(best_state)
    initialization_diagnostics = [
        {key: value for key, value in result.items() if key != "state_dict"}
        for result in initialization_results
    ]
    history.append(
        {
            "epoch": 0,
            "initialization": selected_initialization["label"],
            "initialization_candidates": initialization_diagnostics,
            "training_loss": None,
            "validation_loss": best_validation,
            "best_validation_loss": best_validation,
            "continuous_validation_selection": best_selection_summary,
            "best_selection_score": best_selection_score,
            "optimizer_steps": 0,
            "basin_sampling_attempt_counts_cumulative": dict(
                basin_sampling_attempt_counts
            ),
            "basin_optimizer_step_counts_cumulative": dict(
                basin_optimizer_step_counts
            ),
            "skipped_steps_cumulative": 0,
            "nonzero_gradient_parameter_tensors_cumulative": 0,
            "elapsed_seconds": time.perf_counter() - start_clock,
        }
    )

    for epoch in range(epochs):
        net.train()
        training_losses = []
        for _ in range(steps_per_epoch):
            basin_index = int(torch.randint(0, len(basins), (1,), generator=generator).item())
            basin = basins[basin_index]
            basin_sampling_attempt_counts[basin.basin_id] += 1
            maximum_start = basin.validation_start - segment_days - max(leads)
            if maximum_start < 1:
                raise ValueError(f"training window does not fit for basin {basin.basin_id}")
            start = int(torch.randint(1, maximum_start + 1, (1,), generator=generator).item())
            end = start + segment_days
            initial = physical_segment_initial_state(
                basin.initial_state, basin.open_loop_states_calibration, start
            )
            _adapt_network(net, basin, family)
            optimizer.zero_grad(set_to_none=True)
            try:
                posterior = filter_segment(
                    net,
                    basin,
                    basin.forcing_calibration,
                    basin.observation_calibration,
                    basin.valid_calibration,
                    start=start,
                    end=end,
                    initial_state=initial,
                )
                loss = multilead_forecast_loss(
                    basin,
                    posterior,
                    basin.forcing_calibration,
                    basin.observation_calibration,
                    segment_start=start,
                    warmup_days=warmup_days,
                    leads=leads,
                    lead_weights=lead_weights,
                    origin_stride=origin_stride,
                    loss_mode=loss_mode,
                )
            except FloatingPointError:
                skipped_steps += 1
                continue
            if not bool(torch.isfinite(loss)):
                skipped_steps += 1
                continue
            loss.backward()
            for name, parameter in net.named_parameters():
                if parameter.grad is not None and bool(torch.isfinite(parameter.grad).all()) and bool(
                    torch.count_nonzero(parameter.grad)
                ):
                    ever_nonzero_gradients.add(name)
            gradient_norm = torch.nn.utils.clip_grad_norm_(
                net.parameters(), float(family["gradient_maximum_norm"])
            )
            if not bool(torch.isfinite(gradient_norm)):
                optimizer.zero_grad(set_to_none=True)
                skipped_steps += 1
                continue
            optimizer.step()
            basin_optimizer_step_counts[basin.basin_id] += 1
            training_losses.append(float(loss.detach()))

        if not training_losses:
            raise RuntimeError("no finite training losses")
        training_mean = float(np.mean(training_losses))
        validation_mean = compute_validation_loss()
        selection_score, selection_summary = compute_continuous_validation_selection()
        improved = selection_score > best_selection_score + 1e-6
        if improved:
            best_validation = validation_mean
            best_selection_score = selection_score
            best_selection_summary = selection_summary
            best_state = copy.deepcopy(net.state_dict())
            best_epoch = epoch + 1
            no_improvement = 0
        else:
            no_improvement += 1
        history.append(
            {
                "epoch": epoch + 1,
                "training_loss": training_mean,
                "validation_loss": validation_mean,
                "best_validation_loss": best_validation,
                "continuous_validation_selection": selection_summary,
                "best_selection_score": best_selection_score,
                "optimizer_steps": len(training_losses),
                "basin_sampling_attempt_counts_cumulative": dict(
                    basin_sampling_attempt_counts
                ),
                "basin_optimizer_step_counts_cumulative": dict(
                    basin_optimizer_step_counts
                ),
                "skipped_steps_cumulative": skipped_steps,
                "nonzero_gradient_parameter_tensors_cumulative": len(ever_nonzero_gradients),
                "elapsed_seconds": time.perf_counter() - start_clock,
            }
        )
        if no_improvement >= patience:
            break

    net.load_state_dict(best_state)
    initial_validation_loss = float(history[0]["validation_loss"])
    selected_validation_loss = float(history[best_epoch]["validation_loss"])
    trainable_names = [name for name, parameter in net.named_parameters() if parameter.requires_grad]
    diagnostics = {
        "seed": int(seed),
        "history": history,
        "selected_initialization": selected_initialization["label"],
        "initialization_candidates": initialization_diagnostics,
        "best_validation_loss": best_validation,
        "best_continuous_validation_selection": best_selection_summary,
        "best_selection_score": best_selection_score,
        "initial_selection_score": initial_selection_score,
        "best_epoch": best_epoch,
        "trained_checkpoint_selected": best_epoch > 0,
        "selection_score_improvement_over_epoch_zero": (
            best_selection_score - initial_selection_score
        ),
        "initial_validation_loss": initial_validation_loss,
        "selected_validation_loss": selected_validation_loss,
        "validation_loss_improvement_over_epoch_zero": (
            initial_validation_loss - selected_validation_loss
        ),
        "epochs_completed": max(0, len(history) - 1),
        "history_entry_count_including_epoch_zero": len(history),
        "skipped_steps": skipped_steps,
        "basin_sampling_attempt_counts": basin_sampling_attempt_counts,
        "basin_optimizer_step_counts": basin_optimizer_step_counts,
        "trainable_parameter_tensor_count": len(trainable_names),
        "nonzero_gradient_parameter_tensor_count": len(ever_nonzero_gradients),
        "nonzero_gradient_parameter_names": sorted(ever_nonzero_gradients),
        "parameters_without_observed_nonzero_gradient": sorted(
            set(trainable_names) - ever_nonzero_gradients
        ),
        "elapsed_seconds": time.perf_counter() - start_clock,
    }
    return net, diagnostics


def _evaluation_view(
    basin: BasinSeries, *, formal_evaluation: bool
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, tuple[str, ...], torch.Tensor, torch.Tensor, torch.Tensor | None]:
    if formal_evaluation:
        required = (
            basin.forcing_evaluation,
            basin.observation_evaluation,
            basin.valid_evaluation,
            basin.dates_evaluation,
            basin.open_loop_evaluation,
            basin.open_loop_states_evaluation,
        )
        if any(value is None for value in required):
            raise ValueError(f"formal evaluation data missing for basin {basin.basin_id}")
        return (
            basin.forcing_evaluation,
            basin.observation_evaluation,
            basin.valid_evaluation,
            basin.dates_evaluation,
            basin.open_loop_evaluation,
            basin.open_loop_states_evaluation,
            None,
        )
    start = basin.validation_start
    initial = physical_segment_initial_state(
        basin.initial_state, basin.open_loop_states_calibration, start
    )
    return (
        basin.forcing_calibration[start:],
        basin.observation_calibration[start:],
        basin.valid_calibration[start:],
        basin.dates_calibration[start:],
        basin.open_loop_calibration[start:],
        basin.open_loop_states_calibration[start:],
        initial,
    )


def common_forecast_metric_target_indices(
    period_days: int,
    *,
    leads: tuple[int, ...],
    filter_warmup_days: int,
) -> dict[int, np.ndarray]:
    """Return equal-count target indices from common valid forecast origins."""

    if period_days < 1 or not leads or tuple(sorted(set(leads))) != leads:
        raise ValueError("metric forecast geometry is invalid")
    if leads[0] < 1 or filter_warmup_days < 0:
        raise ValueError("forecast leads and filter warmup must be nonnegative")
    issue_stop = int(period_days) - max(leads)
    if filter_warmup_days >= issue_stop:
        raise ValueError("metric warmup leaves no common forecast origins")
    issues = np.arange(filter_warmup_days, issue_stop, dtype=np.int64)
    return {lead: issues + lead for lead in leads}


def evaluate_basin(
    net: KalmanNetBackend,
    basin: BasinSeries,
    contract: ShortLeadContract,
    family: Mapping[str, Any],
    *,
    formal_evaluation: bool,
) -> tuple[dict[str, Any], dict[str, np.ndarray]]:
    forcing, observations, valid, dates, open_loop, open_states, supplied_initial = _evaluation_view(
        basin, formal_evaluation=formal_evaluation
    )
    initial = basin.initial_state if supplied_initial is None else supplied_initial
    _adapt_network(net, basin, family)
    net.eval()
    net.initialize_filter(initial, len(observations))
    leads = contract.leads
    predictions = {lead: np.full(len(observations), np.nan, dtype=np.float64) for lead in leads}
    posterior_rows = []
    prior_rows = []
    correction_rows = []
    reset_days = int(family["hidden_reset_days_during_evaluation"])
    numerical_failure = False
    with torch.no_grad():
        for issue in range(len(observations)):
            if issue > 0 and reset_days > 0 and issue % reset_days == 0:
                net.init_hidden_KNet()
            controls = forcing[issue : issue + 1]
            if bool(valid[issue]):
                posterior = net.analysis_step(observations[issue : issue + 1], controls)
            else:
                posterior = net.predict_step(controls)
            prior_rows.append(net.m1x_prior.detach().cpu().numpy()[0])
            posterior_rows.append(posterior.detach().cpu().numpy()[0])
            correction_rows.append(net.last_correction.detach().cpu().numpy()[0])
            if not bool(torch.isfinite(posterior).all()):
                numerical_failure = True
                break
            forecast_state = posterior
            previous_lead = 0
            for lead in leads:
                for offset in range(previous_lead + 1, lead + 1):
                    target = issue + offset
                    if target >= len(observations):
                        break
                    forecast_state = _project_state(
                        basin.system.f(forecast_state, forcing[target : target + 1]),
                        basin.state_lower_bound,
                        basin.state_upper_bound,
                    )
                target = issue + lead
                if target < len(observations):
                    prediction = float(basin.system.h(forecast_state).reshape(()))
                    predictions[lead][target] = prediction
                    if not math.isfinite(prediction):
                        numerical_failure = True
                previous_lead = lead

    target = observations.detach().cpu().numpy().astype(np.float64)
    open_array = open_loop.detach().cpu().numpy().astype(np.float64)
    metric_warmup_days = int(family.get("metric_filter_warmup_days", 0))
    metric_target_indices = common_forecast_metric_target_indices(
        len(observations),
        leads=tuple(leads),
        filter_warmup_days=metric_warmup_days,
    )
    nse_open: dict[str, float] = {}
    nse_method: dict[str, float] = {}
    gains: dict[str, float] = {}
    audits: dict[str, Any] = {}
    for lead in leads:
        indices = metric_target_indices[lead]
        baseline = np.full(len(open_array), np.nan, dtype=np.float64)
        baseline[indices] = open_array[indices]
        method = np.full(len(open_array), np.nan, dtype=np.float64)
        method[indices] = predictions[lead][indices]
        predictions[lead] = method
        reported = {
            "open_loop": nash_sutcliffe_efficiency(target, baseline),
            "method": nash_sutcliffe_efficiency(target, method),
        }
        try:
            audit = audit_reported_metrics(
                target,
                baseline,
                method,
                reported,
                tolerance=contract.thresholds.metric_recompute_tolerance,
            )
        except (ValueError, KeyError) as error:
            numerical_failure = True
            audit = {"passed": False, "error": str(error)}
        audits[str(lead)] = audit
        nse_open[str(lead)] = float(reported["open_loop"])
        nse_method[str(lead)] = float(reported["method"])
        gains[str(lead)] = float(reported["method"] - reported["open_loop"])

    corrections = np.asarray(correction_rows, dtype=np.float64)
    row = {
        "basin": basin.basin_id,
        "active_routing_lag": basin.active_lag,
        "metric_filter_warmup_days": metric_warmup_days,
        "metric_common_issue_count": int(len(next(iter(metric_target_indices.values())))),
        "initialization_mode": basin.initialization_mode,
        "source_state_dimension": basin.source_state_dimension,
        "physical_model_dtype": str(basin.initial_state.dtype).replace("torch.", ""),
        "gain_network_dtype": str(next(net.parameters()).dtype).replace("torch.", ""),
        "prepared_input_sha256": basin.prepared_input_sha256,
        "residual_memory_coefficients": basin.residual_memory_coefficients,
        "nse_open_loop": nse_open,
        "nse_method": nse_method,
        "gain_over_open_loop": gains,
        "numerical_failure": bool(numerical_failure),
        "metric_audit": audits,
        "mean_absolute_correction_by_state": (
            np.nanmean(np.abs(corrections), axis=0).tolist() if corrections.size else []
        ),
    }
    payload: dict[str, np.ndarray] = {
        "dates": np.asarray(dates),
        "target": target,
        "open_loop": open_array,
        "open_loop_states": open_states.detach().cpu().numpy()[:, 0, :],
        "prior_states": np.asarray(prior_rows, dtype=np.float64),
        "posterior_states": np.asarray(posterior_rows, dtype=np.float64),
        "corrections": corrections,
    }
    for lead in leads:
        payload[f"prediction_lead_{lead}"] = predictions[lead]
    return row, payload


def evaluate_formal_gate(
    rows: list[Mapping[str, Any]],
    *,
    leads: Iterable[int],
    median_gain_threshold: float,
    catastrophic_decrement: float,
    maximum_degraded_fraction: float,
    minimum_median_method_nse: float | None = None,
) -> dict[str, Any]:
    lead_results: dict[str, Any] = {}
    passed = True
    for lead in leads:
        values = np.asarray(
            [float(row["gain_over_open_loop"].get(str(lead), float("nan"))) for row in rows],
            dtype=float,
        )
        finite = values[np.isfinite(values)]
        method_values = np.asarray(
            [
                float(row.get("nse_method", {}).get(str(lead), float("nan")))
                for row in rows
            ],
            dtype=float,
        )
        finite_method = method_values[np.isfinite(method_values)]
        median_gain = float(np.median(finite)) if finite.size else float("nan")
        median_method_nse = (
            float(np.median(finite_method)) if finite_method.size else float("nan")
        )
        degraded_fraction = float(np.mean(finite < catastrophic_decrement)) if finite.size else 1.0
        finite_passed = int(finite.size) == len(rows)
        median_passed = bool(math.isfinite(median_gain) and median_gain >= median_gain_threshold)
        absolute_nse_passed = bool(
            minimum_median_method_nse is None
            or (
                int(finite_method.size) == len(rows)
                and math.isfinite(median_method_nse)
                and median_method_nse >= minimum_median_method_nse
            )
        )
        degradation_passed = degraded_fraction <= maximum_degraded_fraction
        lead_passed = (
            finite_passed and median_passed and degradation_passed and absolute_nse_passed
        )
        lead_results[str(lead)] = {
            "median_gain": median_gain,
            "median_method_nse": median_method_nse,
            "minimum_median_method_nse": minimum_median_method_nse,
            "absolute_nse_passed": absolute_nse_passed,
            "finite_count": int(finite.size),
            "basin_count": len(rows),
            "degraded_count": int(np.sum(finite < catastrophic_decrement)),
            "degraded_fraction": degraded_fraction,
            "median_passed": median_passed,
            "degradation_passed": degradation_passed,
            "passed": lead_passed,
        }
        passed = passed and lead_passed
    numerical_failures = sum(bool(row.get("numerical_failure", False)) for row in rows)
    passed = passed and numerical_failures == 0
    return {
        "passed": bool(passed),
        "lead_results": lead_results,
        "numerical_failure_count": numerical_failures,
    }


def audit_archived_storage_only(
    archived_path: str | Path, contract: ShortLeadContract
) -> dict[str, Any]:
    """Audit what can and cannot be recovered from the old summary-only artifact."""

    path = Path(archived_path)
    payload = json.loads(path.read_text(encoding="utf-8"))
    holdout = payload.get("holdout", [])
    ids = tuple(str(row["basin"]).zfill(8) for row in holdout)
    gains = {}
    for lead in (1, 3):
        values = [float(row["gain_over_ol"][str(lead)]) for row in holdout]
        gains[str(lead)] = float(statistics.median(values))
    missing = []
    if not any(path.parent.glob(path.stem + "*.pt")):
        missing.append("checkpoint")
    if not any("prediction" in key.lower() for key in payload):
        missing.append("raw_predictions")
    if not all("2" in row.get("gain_over_ol", {}) for row in holdout):
        missing.append("lead_2_metric")
    return {
        "status": "INCOMPLETE" if missing else "COMPLETE",
        "source": str(path),
        "source_sha256": sha256_file(path),
        "holdout_ids_match_contract": ids == contract.holdout_basins,
        "holdout_count": len(holdout),
        "recoverable_median_gain_over_open_loop": gains,
        "missing_evidence": missing,
        "conclusion": (
            "The archived storage-only result cannot be independently reproduced or extended "
            "to day 2 because it retained summaries but no checkpoint or raw predictions."
        ),
    }


def atomic_write_json(path: str | Path, payload: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    temporary.replace(path)


def write_metric_csv(path: str | Path, rows: list[Mapping[str, Any]], leads: Iterable[int]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    fields = ["basin", "active_routing_lag", "numerical_failure"]
    for lead in leads:
        fields.extend([f"open_loop_nse_day_{lead}", f"method_nse_day_{lead}", f"gain_day_{lead}"])
    with temporary.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            output = {
                "basin": row["basin"],
                "active_routing_lag": row["active_routing_lag"],
                "numerical_failure": row["numerical_failure"],
            }
            for lead in leads:
                output[f"open_loop_nse_day_{lead}"] = row["nse_open_loop"][str(lead)]
                output[f"method_nse_day_{lead}"] = row["nse_method"][str(lead)]
                output[f"gain_day_{lead}"] = row["gain_over_open_loop"][str(lead)]
            writer.writerow(output)
    temporary.replace(path)
