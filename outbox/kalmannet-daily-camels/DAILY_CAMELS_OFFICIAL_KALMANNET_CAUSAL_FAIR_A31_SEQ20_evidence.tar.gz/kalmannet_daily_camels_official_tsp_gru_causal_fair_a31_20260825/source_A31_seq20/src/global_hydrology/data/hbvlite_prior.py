"""Frozen per-basin HBV-lite prior (v5) for large-scale DA.

Loads the neuralhydrology CMA-ES-calibrated **v5** (Oudin PET, median eval
NSE 0.5995) per-basin parameters + eval-init states from the benchmark summary
CSV, into frozen lookup tables indexed by ``basin_idx`` (order = the canonical
531-basin list). This REPLACES a learnable ``basin_embedding`` — params/states
are injected directly as physical values (no sigmoid/constrain).

CSV: ``camels_us_531_repro_v01_BEST/summary/hbv_lite_cma_local_full.csv``
  - 13 ``p_*`` columns  -> physical params (strip ``p_`` -> model keys)
  - 5  ``state_*`` cols -> eval-init state x0 (cal_final_2008-09-30)
  - ``nse`` column      -> published eval NSE (kept for the T4 cross-check)

See ``docs/plans/2026-06-05-hbv-lite-da-migration.md`` (T2).
"""
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Union

import torch

from ..models.differentiable_hbv_lite import PARAM_NAMES, STATE_NAMES

# External-repo dependency (like the `filters` PYTHONPATH). Override via args.
NH_ROOT = Path("G:/github/pycharm/projects/neuralhydrology")
_V5_CSV = (NH_ROOT / "results/10_global_conceptual_model_benchmark/"
           "camels_us_531_repro_v01_BEST/summary/hbv_lite_cma_local_full.csv")
_BASIN_LIST = (NH_ROOT / "src/xaj_global_pilot/configs/"
               "conceptual_benchmark_camels_us_531_repro.txt")


@dataclass
class HBVLitePrior:
    """Frozen v5 prior tables, indexed by basin_idx (canonical-list order)."""
    basin_ids: List[str]                # len B, zfill-8, canonical list order
    param_table: torch.Tensor           # [B, 13] physical params, PARAM_NAMES order
    x0_table: torch.Tensor              # [B, 5]  eval-init state, STATE_NAMES order
    csv_nse: torch.Tensor               # [B]     published eval NSE (cross-check)
    id2idx: Dict[str, int]

    @property
    def n_basins(self) -> int:
        return len(self.basin_ids)

    def params_dict(self, basin_idx: torch.Tensor,
                    device: Optional[torch.device] = None) -> Dict[str, torch.Tensor]:
        """Gather a batch of per-basin params as a {name: [B,1]} dict."""
        rows = self.param_table[basin_idx]                       # [B, 13]
        if device is not None:
            rows = rows.to(device)
        return {name: rows[:, i:i + 1] for i, name in enumerate(PARAM_NAMES)}

    def x0(self, basin_idx: torch.Tensor,
           device: Optional[torch.device] = None) -> torch.Tensor:
        """Gather a batch of per-basin eval-init states -> [B, 5]."""
        rows = self.x0_table[basin_idx]
        return rows.to(device) if device is not None else rows


def load_hbvlite_prior(
    csv_path: Union[str, Path, None] = None,
    basin_list_path: Union[str, Path, None] = None,
    dtype: torch.dtype = torch.float64,
) -> HBVLitePrior:
    """Build the frozen v5 prior from the nh benchmark CSV.

    Basin order follows the canonical 531-list (``basin_list_path``); the CSV is
    joined on ``basin_id``. Raises if any list basin is missing from the CSV.
    """
    import csv as _csv

    csv_path = Path(csv_path or _V5_CSV)
    basin_list_path = Path(basin_list_path or _BASIN_LIST)

    ids = [ln.strip().zfill(8) for ln in basin_list_path.read_text().splitlines()
           if ln.strip()]
    by_id = {}
    with open(csv_path, newline="") as fh:
        for r in _csv.DictReader(fh):
            by_id[r["basin_id"].zfill(8)] = r

    missing = [b for b in ids if b not in by_id]
    if missing:
        raise KeyError(f"{len(missing)} list basins absent from CSV, e.g. {missing[:3]}")

    params = torch.empty(len(ids), len(PARAM_NAMES), dtype=dtype)
    x0 = torch.empty(len(ids), len(STATE_NAMES), dtype=dtype)
    nse = torch.empty(len(ids), dtype=dtype)
    for i, b in enumerate(ids):
        row = by_id[b]
        for j, name in enumerate(PARAM_NAMES):
            params[i, j] = float(row["p_" + name])
        for j, name in enumerate(STATE_NAMES):
            x0[i, j] = float(row["state_" + name])
        nse[i] = float(row["nse"])

    return HBVLitePrior(
        basin_ids=ids, param_table=params, x0_table=x0, csv_nse=nse,
        id2idx={b: i for i, b in enumerate(ids)},
    )


if __name__ == "__main__":
    # T2 unit check: 3 basins' params/states/nse round-trip the CSV exactly.
    import csv as _csv
    prior = load_hbvlite_prior()
    print(f"loaded {prior.n_basins} basins; param_table {tuple(prior.param_table.shape)}, "
          f"x0_table {tuple(prior.x0_table.shape)}")
    raw = {r["basin_id"].zfill(8): r for r in _csv.DictReader(open(_V5_CSV))}
    ok = True
    for b in [prior.basin_ids[0], prior.basin_ids[265], prior.basin_ids[-1]]:
        idx = prior.id2idx[b]
        pd_ = prior.params_dict(torch.tensor([idx]))
        for name in PARAM_NAMES:
            exp = float(raw[b]["p_" + name]); got = float(pd_[name].item())
            if abs(exp - got) > 1e-12:
                ok = False; print(f"  MISMATCH {b} {name}: {exp} vs {got}")
        x0b = prior.x0(torch.tensor([idx]))[0]
        for j, name in enumerate(STATE_NAMES):
            exp = float(raw[b]["state_" + name])
            if abs(exp - float(x0b[j])) > 1e-12:
                ok = False; print(f"  MISMATCH {b} state_{name}")
        print(f"  basin {b} (idx {idx}): params+states match CSV, csv_nse={prior.csv_nse[idx]:.4f}")
    print("T2 CHECK:", "PASS" if ok else "FAIL")
