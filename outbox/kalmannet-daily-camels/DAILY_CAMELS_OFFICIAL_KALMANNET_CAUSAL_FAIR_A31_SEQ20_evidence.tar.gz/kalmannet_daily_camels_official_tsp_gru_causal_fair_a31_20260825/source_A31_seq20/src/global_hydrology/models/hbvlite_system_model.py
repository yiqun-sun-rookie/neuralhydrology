"""HBV-lite System Model adapter for KalmanNet DA.

Wraps :class:`DifferentiableHBVLite` (the verified torch port of the
neuralhydrology v5 HBV-lite, T1/T4 green) into the KalmanNet ``SystemModel``
contract — a **duck-typed clone of** ``m4_system_model.M4SystemModel`` so the
existing ``scripts/train_da_camels.py`` DA loop can drive it unchanged.

Per-basin CMA-ES-calibrated params + eval-init states are injected **directly as
frozen physical values** (no sigmoid/constrain, no StaticEncoder); see
``hbvlite_prior.load_hbvlite_prior``. Like ``M4SystemModel`` this is a **plain
class (not nn.Module)**, cheaply re-instantiated every batch.

State (m): ``[SNOWPACK, MELTWATER, SM, SUZ, SLZ]`` (+ ``q_raw`` if augmented).
Obs (n=1): discharge Q [mm/d].

The emission operator (h)
-------------------------
HBV-lite's per-step discharge ``q_raw = Q0+Q1+Q2`` is generated **inside**
``forward_step`` by sequentially subtracting Q0/Q1/Q2 from SUZ/SLZ, so it is NOT
a pure function of the *post-step* state ``state_next``. The M4 contract, by
contrast, requires ``h(x)`` to be a pure readout of state — and the DA loop calls
``h(x_posterior)`` on the **KalmanNet-corrected** state to form the assimilated
output. Two faithful, differentiable options (selectable via ``emission=``):

* ``"augmented"`` (m=6, **default, recommended**): carry ``q_raw`` as a 6th state
  channel that ``f`` writes each step; ``h(x) = x[..., 5]``. The prior emission is
  the *exact* ``q_raw`` (reproduces open-loop), and KalmanNet's correction to the
  discharge channel makes ``h(x_posterior)`` reflect the analysis immediately —
  the standard KF posterior ``y = h(x_post)``. The channel is write-only w.r.t.
  the dynamics (``f`` recomputes ``q_raw`` from the corrected *storages*), so no
  spurious feedback; the storage corrections (channels 0-4) still propagate.
* ``"storage"`` (m=5): pure post-step storage readout
  ``Q = K0·relu(SUZ-UZL) + K1·SUZ + K2·SLZ``. Stays at m=5 and is a strict
  state→obs map, but it is computed on *post-drainage* storages so it
  underestimates the fast peak flows (Q0 often clamps to 0). Kept as an ablation.
* ``"routed"`` (m = 5 + L, the FAITHFUL form): state augmented with a routing FIFO
  buffer ``[r_0 .. r_{L-1}]`` (``r_k`` = the runoff produced ``k`` days ago). ``f``
  prepends the new ``q_raw`` and shifts the buffer; ``h(x) = sum_k w_k r_k`` with
  fixed per-basin RECESSION-half weights (``recession_half_weights``) reproduces the
  triangular unit-hydrograph lag — i.e. ``h`` equals the gauge-observable *routed*
  discharge ``q_sim``, NOT the internal pre-lag ``q_raw``. This is the mode the UKF/
  KalmanNet DA assimilates against (open-loop routed-h reproduces the 0.5995
  benchmark). Requires ``lag_weights=[B,L]``.

In BOTH modes ``self.last_q_raw`` holds the faithful pre-lag ``q_raw`` of the most
recent ``f`` call, for open-loop drivers / diagnostics.

NOTE — forcing channel order: ``f(x, u)`` expects ``u = (P, T, PET)`` to match the
M4 contract and the kalmannet ``CAMELSDataset``. Internally remapped to
``forward_step(rain=P, pet=PET, temp=T)``. The T3 gate's loop-equivalence test
guards this remap.
"""
from typing import Dict, Optional, Union

import torch

from .differentiable_hbv_lite import DifferentiableHBVLite, PARAM_NAMES, N_STATES


class HBVLiteSystemModel:
    """Frozen-parameter HBV-lite process+observation model for KalmanNet DA."""

    n = 1  # observation dim: Q (mm/day)
    N_STORAGE = N_STATES  # 5 physical storages

    def __init__(
        self,
        params: Union[Dict[str, torch.Tensor], torch.Tensor],
        x0: Optional[torch.Tensor] = None,
        device: Optional[torch.device] = None,
        dtype: torch.dtype = torch.float32,
        emission: str = "augmented",
        lag_weights: Optional[torch.Tensor] = None,
    ):
        """
        Args:
            params: per-basin physical params, either a ``{name: [B,1]}`` dict
                (PARAM_NAMES keys) or a ``[B, 13]`` tensor in PARAM_NAMES order.
                Stored **detached** (frozen) — gradients never touch them.
            x0: ``[B, 5]`` eval-init storages (cal-final state). If None, uses the
                model's default warm state (FC·0.3 / 5 / 10).
            device: compute device (default: cuda if available else cpu).
            dtype: working dtype for params/state (float32 for DA training).
            emission: ``"augmented"`` (m=6, default), ``"storage"`` (m=5), or
                ``"routed"`` (m=5+L, faithful UH-lag form; requires ``lag_weights``).
            lag_weights: ``[B, L]`` RECESSION-half routing weights (from
                ``recession_half_weights``). Required for ``emission="routed"``;
                ignored otherwise. Stored **detached** (frozen).
        """
        if emission not in ("augmented", "storage", "routed"):
            raise ValueError(
                f"emission must be 'augmented', 'storage' or 'routed', got {emission!r}")
        self.emission = emission
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.dtype = dtype

        if emission == "routed":
            if lag_weights is None:
                raise ValueError("emission='routed' requires lag_weights=[B,L].")
            self.lag_weights = lag_weights.to(self.device, self.dtype).detach()  # [B,L]
            self.L = self.lag_weights.shape[-1]
            self.m = self.N_STORAGE + self.L
        elif emission == "augmented":
            self.lag_weights = None
            self.L = 0
            self.m = self.N_STORAGE + 1
        else:  # storage
            self.lag_weights = None
            self.L = 0
            self.m = self.N_STORAGE

        self.params = self._to_param_dict(params)          # frozen {name:[B,1]}
        self.batch_size = self.params[PARAM_NAMES[0]].shape[0]

        if emission == "routed":
            n_max = int(torch.clamp(torch.ceil(self.params["lag_time"]), min=1.0).max().item())
            if self.L < n_max:
                raise ValueError(
                    f"routed: lag_weights L={self.L} < max(ceil(lag_time))={n_max}; "
                    "FIFO too short, recession tail would be silently dropped.")

        self._model = DifferentiableHBVLite()

        # Injected eval-init storages (or default warm state).
        if x0 is not None:
            self._x0_storage = x0.to(self.device, self.dtype).detach()
        else:
            self._x0_storage = self._default_storage()

        self.last_q_raw: Optional[torch.Tensor] = None     # faithful pre-lag q_raw

        # Noise-covariance priors (only seed KalmanNet.init_hidden; values non-critical).
        eye_m = torch.eye(self.m, device=self.device, dtype=self.dtype)
        eye_n = torch.eye(self.n, device=self.device, dtype=self.dtype)
        self.q = eye_m * 0.1
        self.r = eye_n * 0.1
        self.prior_q = eye_m.clone()
        self.prior_state_cov = eye_m * 10.0
        self.prior_r = eye_n.clone()

        self._current_forcing: Optional[torch.Tensor] = None  # for set_forcing compat
        self.m1x_0 = None
        self.m2x_0 = None

    # ------------------------------------------------------------------ setup
    def _to_param_dict(self, params) -> Dict[str, torch.Tensor]:
        if isinstance(params, dict):
            out = {k: params[k].to(self.device, self.dtype).detach() for k in PARAM_NAMES}
        else:  # [B, 13] tensor
            p = params.to(self.device, self.dtype).detach()
            out = {name: p[:, i:i + 1] for i, name in enumerate(PARAM_NAMES)}
        return out

    def _default_storage(self) -> torch.Tensor:
        B = self.params[PARAM_NAMES[0]].shape[0]
        FC = self.params["parFC"]
        z = torch.zeros(B, 1, device=self.device, dtype=self.dtype)
        return torch.cat([
            z, z, FC * 0.3,
            torch.full((B, 1), 5.0, device=self.device, dtype=self.dtype),
            torch.full((B, 1), 10.0, device=self.device, dtype=self.dtype),
        ], dim=-1)

    # ------------------------------------------------------------- process f
    def f(self, x: torch.Tensor, u: torch.Tensor = None) -> torch.Tensor:
        """One HBV-lite step. ``x``: [B,m] or [m]; ``u``: [B,3]=(P,T,PET) or [3]."""
        if x.dim() == 1:
            x = x.unsqueeze(0)
        forcing = u if u is not None else self._current_forcing
        if forcing is None:
            raise ValueError("Provide u=(P,T,PET) or call set_forcing() before f().")
        if forcing.dim() == 1:
            forcing = forcing.unsqueeze(0)
        if forcing.shape[-1] != 3:
            raise ValueError(
                f"u must be (P, T, PET) with 3 channels; got shape {tuple(forcing.shape)}. "
                "Guards the silent channel-swap (e.g. nh-native (P,PET,T) order).")
        if forcing.shape[0] == 1 and x.shape[0] > 1:
            forcing = forcing.expand(x.shape[0], -1)

        storages = x[:, :self.N_STORAGE]
        rain = forcing[:, 0:1]   # P
        temp = forcing[:, 1:2]   # T
        pet = forcing[:, 2:3]    # PET
        state_next, q_raw = self._model.forward_step(storages, rain, pet, temp, self.params)
        self.last_q_raw = q_raw

        if self.emission == "augmented":
            return torch.cat([state_next, q_raw], dim=-1)
        if self.emission == "routed":
            # FIFO shift: newest runoff at index 0, drop the oldest slot.
            buffer = x[:, self.N_STORAGE:self.N_STORAGE + self.L]
            new_buffer = torch.cat([q_raw, buffer[:, :self.L - 1]], dim=-1)
            return torch.cat([state_next, new_buffer], dim=-1)
        return state_next

    # --------------------------------------------------------- observation h
    def h(self, x: torch.Tensor) -> torch.Tensor:
        """Map state -> discharge [B,1]. See module docstring for the two modes."""
        if x.dim() == 1:
            x = x.unsqueeze(0)
        if self.emission == "augmented":
            return x[:, self.N_STORAGE:self.N_STORAGE + 1]
        if self.emission == "routed":
            buffer = x[:, self.N_STORAGE:self.N_STORAGE + self.L]
            routed = (buffer * self.lag_weights).sum(dim=-1, keepdim=True)
            return torch.clamp(routed, min=0.0)
        return self._storage_readout(x)

    def _storage_readout(self, x: torch.Tensor) -> torch.Tensor:
        """Pure post-step storage discharge law (used by 'storage' emission + q_raw init)."""
        SUZ = x[:, 3:4]
        SLZ = x[:, 4:5]
        K0 = self.params["parK0"]
        K1 = self.params["parK1"]
        UZL = self.params["parUZL"]
        K2 = self.params["parK2"]
        return K0 * torch.clamp(SUZ - UZL, min=0.0) + K1 * SUZ + K2 * SLZ

    # ------------------------------------------------------------- init/state
    def get_default_initial_state(self) -> torch.Tensor:
        """Injected eval-init state [B,m] (storages [+ q_raw seed if augmented])."""
        storages = self._x0_storage
        if self.emission == "augmented":
            q0 = self._storage_readout(storages)   # sane non-zero first emission
            return torch.cat([storages, q0], dim=-1)
        if self.emission == "routed":
            # Empty FIFO (zeros) == the conv1d zero-padding of the past in forward();
            # reproduces forward()'s q_sim exactly from the first step.
            buffer = torch.zeros(storages.shape[0], self.L,
                                 device=self.device, dtype=self.dtype)
            return torch.cat([storages, buffer], dim=-1)
        return storages

    # ----------------------------------------------- M4-contract compat no-ops
    def set_forcing(self, forcing: torch.Tensor):
        self._current_forcing = forcing.to(self.device, self.dtype)

    def InitSequence(self, m1x_0: torch.Tensor, m2x_0: torch.Tensor):
        self.m1x_0 = m1x_0.to(self.device)
        self.m2x_0 = m2x_0.to(self.device)

    def Init_batched_sequence(self, m1x_0_batch: torch.Tensor, m2x_0_batch: torch.Tensor):
        self.m1x_0_batch = m1x_0_batch.to(self.device)
        self.x_prev = m1x_0_batch.to(self.device)
        self.m2x_0_batch = m2x_0_batch.to(self.device)

    def UpdateCovariance_Matrix(self, Q: torch.Tensor, R: torch.Tensor):
        self.Q = Q.to(self.device)
        self.R = R.to(self.device)
