"""Controlled routed-HBV adapter for the pinned upstream KalmanNet class.

The gain network is imported directly from the unmodified upstream source file
vendored at ``third_party/KalmanNet_TSP_828a2cf/KNet/KalmanNet_nn.py``.  This
module does not reimplement its three GRUs or FC1--FC7 graph.  It only supplies
the interfaces that a controlled, shared daily HBV experiment needs:
exogenous forcing, per-basin dynamics rebinding, active routed-state masks,
physical projection, and a training-only dimensionless unit conversion.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path
from typing import Any

import torch
from torch.nn import functional as F


UPSTREAM_REPOSITORY_URL = "https://github.com/KalmanNet/KalmanNet_TSP"
UPSTREAM_COMMIT = "828a2cf529bc84f43b37d543d916fe5858054457"
UPSTREAM_SOURCE_PATH = "KNet/KalmanNet_nn.py"
UPSTREAM_SOURCE_SHA256 = "0cad52635723eaf8c4bbfc331a2d0614520363c71953f650794b4794d7aab33d"

UPSTREAM_RAW_FEATURE_MODE = "upstream_raw_innovation"
SHARED_HYDROLOGY_FEATURE_MODE = "training_rms_dimensionless_innovation"
SUPPORTED_FEATURE_MODES = frozenset(
    {UPSTREAM_RAW_FEATURE_MODE, SHARED_HYDROLOGY_FEATURE_MODE}
)

_REPOSITORY_ROOT = Path(__file__).resolve().parents[3]
_VENDORED_SOURCE = (
    _REPOSITORY_ROOT
    / "third_party"
    / "KalmanNet_TSP_828a2cf"
    / "KNet"
    / "KalmanNet_nn.py"
)
_SPEC = importlib.util.spec_from_file_location(
    "upstream_kalmannet_tsp_828a2cf", _VENDORED_SOURCE
)
if _SPEC is None or _SPEC.loader is None:  # pragma: no cover - platform guard
    raise ImportError(f"cannot load pinned upstream KalmanNet from {_VENDORED_SOURCE}")
_MODULE = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_MODULE)
OfficialKalmanNetNN = _MODULE.KalmanNetNN


class _OfficialArguments:
    """Only the arguments read by upstream ``InitKGainNet``."""

    def __init__(self, *, input_multiplier: int, output_multiplier: int) -> None:
        self.n_batch = 1
        self.in_mult_KNet = int(input_multiplier)
        self.out_mult_KNet = int(output_multiplier)
        if self.in_mult_KNet < 1 or self.out_mult_KNet < 1:
            raise ValueError("KalmanNet dimension multipliers must be positive")


class OfficialKalmanNetTSPHBVAdapter(OfficialKalmanNetNN):
    """Use the pinned official architecture-2 gain network in routed daily HBV."""

    def __init__(
        self,
        system: Any,
        *,
        correction_mask: torch.Tensor,
        state_lower_bound: torch.Tensor | None = None,
        state_upper_bound: torch.Tensor | None = None,
        input_multiplier: int = 10,
        output_multiplier: int = 10,
        correction_cap_in_state_scale_units: float | None = None,
        feature_mode: str = SHARED_HYDROLOGY_FEATURE_MODE,
    ) -> None:
        super().__init__()
        if feature_mode not in SUPPORTED_FEATURE_MODES:
            raise ValueError(f"unsupported KalmanNet feature mode: {feature_mode}")
        self.feature_mode = feature_mode
        self.device = system.device
        self.InitSystemDynamics(system.f, system.h, int(system.m), int(system.n))
        self.InitKGainNet(
            system.prior_q,
            system.prior_state_cov,
            system.prior_r,
            _OfficialArguments(
                input_multiplier=input_multiplier,
                output_multiplier=output_multiplier,
            ),
        )
        # Upstream stores the priors as ordinary tensors.  Register the identical
        # tensors so device/dtype moves and checkpoints remain auditable.
        gain_parameter = next(self.parameters())
        prior_q = self.prior_Q.to(gain_parameter).clone()
        prior_sigma = self.prior_Sigma.to(gain_parameter).clone()
        prior_s = self.prior_S.to(gain_parameter).clone()
        del self.prior_Q, self.prior_Sigma, self.prior_S
        self.register_buffer("prior_Q", prior_q)
        self.register_buffer("prior_Sigma", prior_sigma)
        self.register_buffer("prior_S", prior_s)

        dtype = system.dtype
        device = system.device
        self.register_buffer(
            "correction_mask",
            correction_mask.to(device=device, dtype=dtype).reshape(1, self.m).clone(),
        )
        lower = (
            torch.zeros((1, self.m), device=device, dtype=dtype)
            if state_lower_bound is None
            else state_lower_bound.to(device=device, dtype=dtype).reshape(1, self.m).clone()
        )
        upper = (
            torch.full((1, self.m), torch.inf, device=device, dtype=dtype)
            if state_upper_bound is None
            else state_upper_bound.to(device=device, dtype=dtype).reshape(1, self.m).clone()
        )
        self.register_buffer("state_lower_bound", lower)
        self.register_buffer("state_upper_bound", upper)
        self.register_buffer(
            "observation_feature_scale",
            torch.ones((1, self.n), device=device, dtype=dtype),
        )
        self.register_buffer(
            "state_feature_scale",
            torch.ones((1, self.m), device=device, dtype=dtype),
        )
        initial_cap = (
            torch.inf
            if correction_cap_in_state_scale_units is None
            else float(correction_cap_in_state_scale_units)
        )
        if initial_cap <= 0.0:
            raise ValueError("correction cap must be positive")
        self.register_buffer(
            "correction_cap_by_state_scale_units",
            torch.full((1, self.m), initial_cap, device=device, dtype=dtype),
        )

        self.batch_size = 1
        self.m1x_posterior: torch.Tensor | None = None
        self.m1x_posterior_previous: torch.Tensor | None = None
        self.m1x_prior_previous: torch.Tensor | None = None
        self.m1x_prior: torch.Tensor | None = None
        self.m1y: torch.Tensor | None = None
        self.y_previous: torch.Tensor | None = None
        self.KGain: torch.Tensor | None = None
        self.last_gain: torch.Tensor | None = None
        self.last_correction: torch.Tensor | None = None

    @staticmethod
    def normalize_feature(value: torch.Tensor) -> torch.Tensor:
        """Match upstream ``torch.nn.functional.normalize`` exactly."""

        return F.normalize(value, p=2, dim=1, eps=1e-12)

    def zero_gain_head(self) -> None:
        with torch.no_grad():
            self.FC2[-1].weight.zero_()
            self.FC2[-1].bias.zero_()

    def forward(
        self, observation: torch.Tensor, controls: torch.Tensor | None = None
    ) -> torch.Tensor:
        """Run one controlled HBV analysis step through the standard module API."""

        if controls is None:
            raise TypeError("routed HBV KalmanNet forward requires meteorological controls")
        return self.analysis_step(observation, controls)

    def set_basin_adaptation(
        self,
        *,
        system: Any,
        correction_mask: torch.Tensor,
        state_lower_bound: torch.Tensor,
        state_upper_bound: torch.Tensor,
        observation_feature_scale: torch.Tensor,
        state_feature_scale: torch.Tensor,
        correction_cap_by_state_scale_units: torch.Tensor | None = None,
        normalized_feature_guard: float | None = None,
    ) -> None:
        if system.m != self.m or system.n != self.n:
            raise ValueError("basin system dimensions do not match the shared KalmanNet")
        if normalized_feature_guard is not None:
            raise ValueError(
                "the upstream gain core uses Euclidean normalization and no feature clamp"
            )
        self.f = system.f
        self.h = system.h
        mask = correction_mask.to(self.correction_mask).reshape(1, self.m)
        lower = state_lower_bound.to(self.state_lower_bound).reshape(1, self.m)
        upper = state_upper_bound.to(self.state_upper_bound).reshape(1, self.m)
        obs_scale = observation_feature_scale.to(self.observation_feature_scale).reshape(1, self.n)
        state_scale = state_feature_scale.to(self.state_feature_scale).reshape(1, self.m)
        cap = (
            self.correction_cap_by_state_scale_units
            if correction_cap_by_state_scale_units is None
            else correction_cap_by_state_scale_units.to(
                self.correction_cap_by_state_scale_units
            ).reshape(1, self.m)
        )
        if bool(torch.isnan(lower).any()) or bool(torch.isnan(upper).any()):
            raise ValueError("state bounds must not contain NaN")
        if bool((lower >= upper).any()):
            raise ValueError("every lower state bound must be smaller than its upper bound")
        if not bool(torch.isfinite(obs_scale).all()) or bool((obs_scale <= 0.0).any()):
            raise ValueError("observation feature scales must be positive and finite")
        if not bool(torch.isfinite(state_scale).all()) or bool((state_scale <= 0.0).any()):
            raise ValueError("state feature scales must be positive and finite")
        if bool(torch.isnan(cap).any()) or bool((cap <= 0.0).any()):
            raise ValueError("correction caps must be positive and not NaN")
        for target, source in (
            (self.prior_Q, system.prior_q),
            (self.prior_Sigma, system.prior_state_cov),
            (self.prior_S, system.prior_r),
        ):
            if target.shape != source.shape:
                raise ValueError("basin covariance prior dimensions changed")
            target.copy_(source.to(target))
        self.correction_mask.copy_(mask)
        self.state_lower_bound.copy_(lower)
        self.state_upper_bound.copy_(upper)
        self.observation_feature_scale.copy_(obs_scale)
        self.state_feature_scale.copy_(state_scale)
        self.correction_cap_by_state_scale_units.copy_(cap)

    def initialize_filter(
        self,
        initial_state: torch.Tensor,
        sequence_length: int,
        previous_observation: torch.Tensor | None = None,
    ) -> None:
        self.T = int(sequence_length)
        parameter = next(self.parameters())
        state = initial_state.reshape(-1, self.m).to(
            device=parameter.device, dtype=self.state_lower_bound.dtype
        )
        self.device = parameter.device
        self.batch_size = int(state.shape[0])
        self.init_hidden_KNet()
        self.m1x_posterior = state
        self.m1x_posterior_previous = state
        self.m1x_prior_previous = state
        self.y_previous = self.h(state).reshape(self.batch_size, self.n)
        if previous_observation is not None:
            supplied = previous_observation.reshape(self.batch_size, self.n).to(state)
            if not bool(torch.isfinite(supplied).all()):
                raise ValueError("previous observation must be finite when supplied")
            self.y_previous = supplied

    def _require_filter_state(self) -> None:
        if any(
            value is None
            for value in (
                self.m1x_posterior,
                self.m1x_posterior_previous,
                self.m1x_prior_previous,
                self.y_previous,
            )
        ):
            raise RuntimeError("KalmanNet filter has not been initialized")

    def _project_state(self, state: torch.Tensor) -> torch.Tensor:
        return torch.maximum(
            torch.minimum(state, self.state_upper_bound), self.state_lower_bound
        )

    def step_prior(self, controls: torch.Tensor) -> None:
        self._require_filter_state()
        assert self.m1x_posterior is not None
        self.m1x_prior = self._project_state(self.f(self.m1x_posterior, controls))
        self.m1y = self.h(self.m1x_prior).reshape(self.batch_size, self.n)

    def _gain_and_innovation(self, observation: torch.Tensor) -> torch.Tensor:
        assert self.y_previous is not None
        assert self.m1y is not None
        assert self.m1x_posterior is not None
        assert self.m1x_posterior_previous is not None
        assert self.m1x_prior_previous is not None
        if self.feature_mode == SHARED_HYDROLOGY_FEATURE_MODE:
            obs_difference = (observation - self.y_previous) / self.observation_feature_scale
            innovation = (observation - self.m1y) / self.observation_feature_scale
            forward_evolution = (
                self.m1x_posterior - self.m1x_posterior_previous
            ) / self.state_feature_scale
            forward_update = (
                self.m1x_posterior - self.m1x_prior_previous
            ) / self.state_feature_scale
        else:
            obs_difference = observation - self.y_previous
            innovation = observation - self.m1y
            forward_evolution = self.m1x_posterior - self.m1x_posterior_previous
            forward_update = self.m1x_posterior - self.m1x_prior_previous

        gain_parameter = next(self.parameters())
        gain_vector = self.KGain_step(
            self.normalize_feature(obs_difference).to(gain_parameter),
            self.normalize_feature(innovation).to(gain_parameter),
            self.normalize_feature(forward_evolution).to(gain_parameter),
            self.normalize_feature(forward_update).to(gain_parameter),
        )
        self.KGain = gain_vector.reshape(self.batch_size, self.m, self.n).to(innovation)
        return innovation

    def analysis_step(self, observation: torch.Tensor, controls: torch.Tensor) -> torch.Tensor:
        self.step_prior(controls)
        assert self.m1x_prior is not None
        assert self.m1x_posterior is not None
        observation = observation.reshape(self.batch_size, self.n).to(self.m1x_prior)
        innovation = self._gain_and_innovation(observation)
        correction = torch.bmm(self.KGain, innovation.unsqueeze(-1)).squeeze(-1)
        if self.feature_mode == SHARED_HYDROLOGY_FEATURE_MODE:
            cap = self.correction_cap_by_state_scale_units.to(correction)
            correction = torch.maximum(torch.minimum(correction, cap), -cap)
            correction = correction * self.state_feature_scale.to(correction)
        correction = correction.to(self.m1x_prior) * self.correction_mask
        posterior = self._project_state(self.m1x_prior + correction)

        self.m1x_posterior_previous = self.m1x_posterior
        self.m1x_posterior = posterior
        self.m1x_prior_previous = self.m1x_prior
        self.y_previous = observation
        self.last_gain = self.KGain
        self.last_correction = correction
        return posterior

    def predict_step(self, controls: torch.Tensor) -> torch.Tensor:
        self.step_prior(controls)
        assert self.m1x_prior is not None
        assert self.m1x_posterior is not None
        assert self.m1y is not None
        posterior = self.m1x_prior
        self.m1x_posterior_previous = self.m1x_posterior
        self.m1x_posterior = posterior
        self.m1x_prior_previous = self.m1x_prior
        self.y_previous = self.m1y
        self.last_gain = None
        self.last_correction = torch.zeros_like(posterior)
        return posterior
