"""Differentiable HBV-light in PyTorch — DA process-model port.

PORTED FROM neuralhydrology ``src/scl_hydro/hbv_lite.py`` (class
``DifferentiableHBVLite``) for the kalmannet large-scale DA migration
(see ``docs/plans/2026-06-05-hbv-lite-da-migration.md``).

Two deliberate FIXES relative to the nh source (everything else is bit-for-bit):
  1. ``_triangular_lag_batch`` is now **RECESSION-half** (largest weight on the
     CURRENT day) to match the NumPy production ``hbv_lite_numpy._half_triangular_lag``
     that produced the published 0.5995/0.6227 benchmark. The nh torch version was
     RISING-half (``kernel = weights.flip(0)``) and used only for a lag-bug diagnostic.
     The fix is simply dropping the ``.flip(0)``.
  2. A final ``clamp(min=0)`` is applied to the lagged ``q_sim`` to match numpy's
     ``np.maximum(q_sim, 0.0)``.

Provenance of the algorithm (unchanged): port of the standard HBV-light from
mhpi/hydroDL2 (src/hydrodl2/models/hbv/hbv.py::_PBM).

States (5): SNOWPACK, MELTWATER, SM, SUZ, SLZ
Parameters (12 phy + 1 lag = 13):
    parTT, parCFMAX, parCFR, parCWH         (snow 4)
    parFC, parBETA, parLP                   (soil 3)
    parK0, parK1, parUZL, parPERC           (UZ 4)
    parK2                                   (LZ 1)
    lag_time                                 (routing 1, half-triangular lag)

References
----------
Feng, D., Liu, J., Lawson, K., & Shen, C. (2022). Differentiable, learnable,
regionalized process-based models with multiphysical outputs can approach
state-of-the-art hydrologic prediction accuracy. WRR, 58, e2022WR032404.
Seibert, J. (2005). HBV-light Version 2 User's Manual. Stockholm University.
Beck, H. E. et al. (2020). Global Fully Distributed Parameter Regionalization. JGR.
"""
from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


PARAM_NAMES = [
    "parTT", "parCFMAX", "parCFR", "parCWH",
    "parFC", "parBETA", "parLP",
    "parK0", "parK1", "parUZL", "parPERC",
    "parK2",
    "lag_time",
]
N_PARAMS = len(PARAM_NAMES)

STATE_NAMES = ["SNOWPACK", "MELTWATER", "SM", "SUZ", "SLZ"]
N_STATES = len(STATE_NAMES)

# Bounds match hydroDL2 hbv.py defaults verbatim (Feng et al. 2022)
PARAM_BOUNDS = {
    # Snow (HBV-light standard)
    "parTT":    (-2.5,  2.5),   # snow/rain threshold temp [°C]
    "parCFMAX": ( 0.5, 10.0),   # degree-day melt factor [mm/°C/d]
    "parCFR":   ( 0.0,  0.1),   # refreeze coefficient [-]
    "parCWH":   ( 0.0,  0.2),   # water holding capacity in snowpack [-]
    # Soil
    "parFC":    (50.0, 1000.0), # field capacity [mm]
    "parBETA":  ( 1.0,  6.0),   # soil recharge curve exponent [-]
    "parLP":    ( 0.2,  1.0),   # soil moisture threshold for full ET [-]
    # Upper zone (with double outlet)
    "parK0":    (0.05,  0.9),   # UZ above-threshold rate [1/d]
    "parK1":    (0.01,  0.5),   # UZ baseline rate [1/d]
    "parUZL":   ( 0.0,  100.0), # UZ threshold [mm]
    "parPERC":  ( 0.0,  10.0),  # UZ→LZ percolation rate [mm/d]
    # Lower zone
    "parK2":    (0.001, 0.2),   # LZ baseflow rate [1/d]
    # Routing (simple triangular lag, hydroDL2 uses Gamma UH)
    "lag_time": ( 1.0,  10.0),  # triangular routing lag [d]
}


def recession_half_weights(lag_time: torch.Tensor, L: int) -> torch.Tensor:
    """Per-basin RECESSION-half triangular routing weights for a length-L FIFO buffer.

    Matches :meth:`DifferentiableHBVLite._triangular_lag_batch`: with
    ``n = max(ceil(lag), 1)``, ``w_k = (n-k)/S`` for ``k = 0..n-1`` (largest weight
    ``w_0`` on TODAY's runoff), ``0`` for ``k >= n``, and ``S = n(n+1)/2``. The routed
    discharge is ``q_sim[t] = sum_k w_k * q_raw[t-k]``; with a FIFO buffer ``r`` where
    ``r_k = q_raw[t-k]``, ``h(x) = sum_k w_k * r_k`` reproduces the triangular lag.

    Args:
        lag_time: ``[B,1]`` (or ``[B]``) per-basin lag in days.
        L: buffer length (must be ``>= max ceil(lag)`` so no weight is truncated).
    Returns:
        ``[B, L]`` weights, row-normalised to sum 1 over the active (``k<n``) slots.
    """
    lag = lag_time.reshape(-1, 1)                                   # [B,1]
    n = torch.clamp(torch.ceil(lag), min=1.0)                      # [B,1]
    n_max = int(n.max().item())
    if L < n_max:
        raise ValueError(
            f"L={L} truncates the routing kernel: need L >= max(ceil(lag))={n_max}. "
            "A too-short FIFO silently drops the recession tail and mis-routes Q.")
    k = torch.arange(L, device=lag.device, dtype=lag.dtype)        # [L]
    w = torch.clamp(n - k, min=0.0)                                # [B,L], (n-k) if k<n else 0
    return w / w.sum(dim=-1, keepdim=True)


class DifferentiableHBVLite(nn.Module):
    """Differentiable HBV-light, single-component, fixed parameters per basin.

    State naming matches HBV-light tradition (SNOWPACK = frozen,
    MELTWATER = liquid water held in pack via CWH, SM = soil moisture,
    SUZ = upper zone groundwater, SLZ = lower zone groundwater).
    """

    def __init__(self, eps: float = 1e-5):
        super().__init__()
        self.eps = eps
        self.N_PARAMS = N_PARAMS
        self.N_STATES = N_STATES

    # ------------------------------------------------------------------
    # Single-step interface (this IS the DA process model `f` + emission)
    # ------------------------------------------------------------------

    def forward_step(
        self,
        state: torch.Tensor,
        rain: torch.Tensor,
        pet: torch.Tensor,
        temp: torch.Tensor,
        params: Dict[str, torch.Tensor],
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """One daily timestep of HBV-light.

        Args:
            state:  [B, 5] — (SNOWPACK, MELTWATER, SM, SUZ, SLZ)
            rain:   [B, 1] — total precipitation [mm/d]
            pet:    [B, 1] — potential ET [mm/d]
            temp:   [B, 1] — mean temperature [°C]
            params: dict of [B, 1] tensors for each of the 13 parameters

        Returns:
            state_next: [B, 5]
            q_raw:      [B, 1] — total discharge before lag
        """
        SNOWPACK  = state[:, 0:1]
        MELTWATER = state[:, 1:2]
        SM        = state[:, 2:3]
        SUZ       = state[:, 3:4]
        SLZ       = state[:, 4:5]

        TT     = params["parTT"]
        CFMAX  = params["parCFMAX"]
        CFR    = params["parCFR"]
        CWH    = params["parCWH"]
        FC     = params["parFC"]
        BETA   = params["parBETA"]
        LP     = params["parLP"]
        K0     = params["parK0"]
        K1     = params["parK1"]
        UZL    = params["parUZL"]
        PERC   = params["parPERC"]
        K2     = params["parK2"]

        # --- Snow ---
        is_snow  = (temp < TT).float()
        SNOW     = rain * is_snow
        RAIN     = rain * (1.0 - is_snow)

        SNOWPACK = SNOWPACK + SNOW
        melt = CFMAX * (temp - TT)
        melt = torch.clamp(melt, min=0.0)
        melt = torch.minimum(melt, SNOWPACK)
        MELTWATER = MELTWATER + melt
        SNOWPACK  = SNOWPACK - melt

        refreezing = CFR * CFMAX * (TT - temp)
        refreezing = torch.clamp(refreezing, min=0.0)
        refreezing = torch.minimum(refreezing, MELTWATER)
        SNOWPACK   = SNOWPACK + refreezing
        MELTWATER  = MELTWATER - refreezing

        tosoil    = MELTWATER - CWH * SNOWPACK
        tosoil    = torch.clamp(tosoil, min=0.0)
        MELTWATER = MELTWATER - tosoil

        # --- Soil + ET ---
        # clamp(SM,min=0) inside pow only: guards pow(neg, non-int)=NaN when a UKF
        # sigma point arrives with SM<0. Identity for SM>=0 (always true open-loop),
        # so the T1/T3/T4 equivalence gates are unaffected; it lets fx drop the
        # symmetry-breaking per-sigma storage clamp (DA bias fix, 2026-06-07).
        soil_wetness = torch.pow(torch.clamp(SM, min=0.0) / (FC + self.eps), BETA)
        soil_wetness = torch.clamp(soil_wetness, min=0.0, max=1.0)
        recharge     = (RAIN + tosoil) * soil_wetness
        SM           = SM + RAIN + tosoil - recharge

        excess = torch.clamp(SM - FC, min=0.0)
        SM     = SM - excess

        evapfactor = SM / (LP * FC + self.eps)
        evapfactor = torch.clamp(evapfactor, min=0.0, max=1.0)
        ETact      = pet * evapfactor
        ETact      = torch.minimum(SM, ETact)
        SM         = torch.clamp(SM - ETact, min=self.eps)

        # --- Groundwater ---
        SUZ = SUZ + recharge + excess
        PERC_flux = torch.minimum(SUZ, PERC)  # capped at available
        SUZ = SUZ - PERC_flux
        Q0  = K0 * torch.clamp(SUZ - UZL, min=0.0)
        SUZ = SUZ - Q0
        Q1  = K1 * SUZ
        SUZ = SUZ - Q1
        SLZ = SLZ + PERC_flux
        Q2  = K2 * SLZ
        SLZ = SLZ - Q2

        q_raw = Q0 + Q1 + Q2

        state_next = torch.cat([SNOWPACK, MELTWATER, SM, SUZ, SLZ], dim=-1)
        return state_next, q_raw

    # ------------------------------------------------------------------
    # Full-sequence interface (faithful open-loop; used by the T4 truth gate)
    # ------------------------------------------------------------------

    def forward(
        self,
        forcing: torch.Tensor,
        params: Dict[str, torch.Tensor],
        state_init: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Run HBV-light over a full time series.

        Args:
            forcing:    [B, T, 3] — (rain, pet, temp) per daily timestep
            params:     dict of [B, 1] tensors
            state_init: [B, 5] or None

        Returns:
            q_sim:      [B, T, 1] after triangular lag (recession-half, clamped >=0)
            q_raw:      [B, T, 1] pre-lag
            states_all: [B, T, 5]
        """
        B, T, _ = forcing.shape
        device  = forcing.device

        if state_init is None:
            FC = params["parFC"]
            state = torch.cat([
                torch.zeros(B, 1, device=device),         # SNOWPACK
                torch.zeros(B, 1, device=device),         # MELTWATER
                FC * 0.3,                                  # SM ~ 30% of FC
                torch.full((B, 1), 5.0, device=device),    # SUZ
                torch.full((B, 1), 10.0, device=device),   # SLZ
            ], dim=-1)
        else:
            state = state_init

        q_raw_list = []
        states_list = []
        for t in range(T):
            rain = forcing[:, t, 0:1]
            pet  = forcing[:, t, 1:2]
            temp = forcing[:, t, 2:3]
            state, q_t = self.forward_step(state, rain, pet, temp, params)
            q_raw_list.append(q_t)
            states_list.append(state)

        q_raw = torch.stack(q_raw_list, dim=1)
        states_all = torch.stack(states_list, dim=1)

        lag_time = params["lag_time"]
        q_sim = self._triangular_lag_batch(q_raw, lag_time)
        return q_sim, q_raw, states_all

    def _triangular_lag_batch(self, q_raw: torch.Tensor, lag_time: torch.Tensor) -> torch.Tensor:
        """Apply RECESSION-half triangular routing lag (peak at the CURRENT day).

        With ``n = ceil(lag_time)`` and weights ``w_k = (n-k)/sum`` for
        ``k = 0..n-1``, the simulated discharge at day ``t`` is::

            q_sim[t] = w_0*q_raw[t] + w_1*q_raw[t-1] + ... + w_{n-1}*q_raw[t-n+1]

        where ``w_0`` (=n/sum) is the LARGEST weight on TODAY's raw runoff,
        decaying linearly into the past. Peak at t=0. This MATCHES the NumPy
        production ``hbv_lite_numpy._half_triangular_lag`` (the 0.5995/0.6227
        benchmark). FIX vs nh torch source: dropped the ``.flip(0)`` (which made
        it rising-half) and added the final ``clamp(min=0)``.
        """
        B, T, _ = q_raw.shape
        q_out = torch.zeros_like(q_raw)
        for b in range(B):
            lt = lag_time[b, 0].item()
            n = max(int(torch.ceil(torch.tensor(lt)).item()), 1)
            weights = torch.arange(1, n + 1, dtype=q_raw.dtype, device=q_raw.device)
            weights = weights / weights.sum()
            q_1d = q_raw[b, :, 0].unsqueeze(0).unsqueeze(0)
            # RECESSION-half: kernel = weights (NO flip). conv1d cross-correlation
            # with padding=n-1 then slice [:T] puts the largest weight (n/sum) on
            # the current day, matching _half_triangular_lag.
            kernel = weights.unsqueeze(0).unsqueeze(0)
            pad = n - 1
            q_conv = F.conv1d(q_1d, kernel, padding=pad)[:, :, :T]
            q_out[b, :, 0] = q_conv.squeeze()
        return torch.clamp(q_out, min=0.0)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def constrain_params(raw: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Map unconstrained [B, N_PARAMS] → physically bounded dict via sigmoid."""
        params = {}
        for i, name in enumerate(PARAM_NAMES):
            lo, hi = PARAM_BOUNDS[name]
            params[name] = torch.sigmoid(raw[:, i:i+1]) * (hi - lo) + lo
        return params

    @staticmethod
    def dict_from_values(values: Dict[str, float], batch_size: int = 1,
                         device: Optional[torch.device] = None) -> Dict[str, torch.Tensor]:
        if device is None:
            device = torch.device("cpu")
        return {k: torch.full((batch_size, 1), v, dtype=torch.float32, device=device)
                for k, v in values.items()}
