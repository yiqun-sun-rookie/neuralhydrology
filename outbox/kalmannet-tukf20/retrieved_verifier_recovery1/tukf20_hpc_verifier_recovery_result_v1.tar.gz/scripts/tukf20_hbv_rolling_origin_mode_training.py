"""Four-mode training and checkpoint sealing for the TUKF20 experiment.

Every mode uses the same daily state-update computation.  The only mode-owned
factors are whether the hydrologic coordinates and filter-noise coordinates
receive gradients.
"""

from __future__ import annotations

import copy
import hashlib
import importlib
import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import torch

try:  # Task 1 may be imported after this module in focused unit tests.
    from scripts import tukf20_hbv_rolling_origin_joint_learning_common as common
except ImportError:  # pragma: no cover - exercised only while Task 1 is absent.
    common = None  # type: ignore[assignment]


MODE_ORDER = ("all_frozen", "hydrology_only", "filter_only", "joint")
GROUP_KEYS = {
    "hydrology": ("hydrology", "physical_parameters"),
    "filter": (
        "log_process",
        "log_observation",
        "process_diagonal",
        "observation_ratio",
    ),
}
FIXED_STRUCTURE_KEYS = ("lag_time", "state_dimension")


def _common_module():
    global common
    if common is None:
        common = importlib.import_module(
            "scripts.tukf20_hbv_rolling_origin_joint_learning_common"
        )
    return common


def _jsonable(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, torch.Tensor):
        if value.numel() == 1:
            return value.detach().cpu().item()
        return value.detach().cpu().numpy().tolist()
    return value


def _write_new_json(path: Path | str, payload: Mapping[str, Any]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(
        _jsonable(payload), indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False
    )
    with target.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(text)
        handle.write("\n")


def _write_new_npz(path: Path | str, snapshot: Mapping[str, Any]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as handle:
        np.savez_compressed(
            handle,
            **{str(key): np.asarray(value) for key, value in snapshot.items()},
        )


def sha256_file(path: Path | str) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def snapshot_sha256(snapshot: Mapping[str, Any]) -> str:
    digest = hashlib.sha256()
    for name in sorted(str(key) for key in snapshot):
        value = np.ascontiguousarray(np.asarray(snapshot[name]))
        digest.update(name.encode("utf-8"))
        digest.update(str(value.dtype).encode("ascii"))
        digest.update(np.asarray(value.shape, dtype=np.int64).tobytes())
        digest.update(value.tobytes())
    return digest.hexdigest()


def _copy_snapshot(snapshot: Mapping[str, Any]) -> dict[str, Any]:
    module = _common_module()
    if hasattr(module, "copy_snapshot"):
        return module.copy_snapshot(snapshot)
    return {
        str(key): np.asarray(value).copy()
        if isinstance(value, (np.ndarray, np.generic))
        else copy.deepcopy(value)
        for key, value in snapshot.items()
    }


def _snapshot_model(model) -> dict[str, Any]:
    snapshot = _common_module().snapshot_model(model)
    return _copy_snapshot(snapshot)


def _restore_model(model, snapshot: Mapping[str, Any]) -> None:
    _common_module().restore_model_(model, snapshot)


def _mode_order(contract: Mapping[str, Any]) -> tuple[str, ...]:
    raw = contract.get("mode_order")
    if raw is None:
        module = _common_module()
        raw = getattr(module, "MODE_ORDER", getattr(module, "PIPELINE_ORDER", ()))
    order = tuple(str(value) for value in raw)
    if order != MODE_ORDER:
        raise ValueError(f"mode order must be exactly {MODE_ORDER}")
    return order


def _mode_mask(contract: Mapping[str, Any], mode: str) -> dict[str, bool]:
    if mode not in _mode_order(contract):
        raise ValueError(f"unknown TUKF20 mode: {mode}")
    values = contract["mode_masks"][mode]
    mask = {
        "hydrology": bool(values["hydrology"]),
        "filter": bool(values["filter"]),
    }
    if "state_update" in values and bool(values["state_update"]) is not True:
        raise ValueError(f"TUKF20 mode {mode} must keep daily state updating enabled")
    state_update = contract.get("mode_state_update", {}).get(mode)
    if state_update is not None and not all(
        bool(state_update.get(split, False))
        for split in ("training", "selection", "test")
    ):
        raise ValueError(
            f"TUKF20 mode {mode} must update state in training, selection, and test"
        )
    expected = {
        "all_frozen": {"hydrology": False, "filter": False},
        "hydrology_only": {"hydrology": True, "filter": False},
        "filter_only": {"hydrology": False, "filter": True},
        "joint": {"hydrology": True, "filter": True},
    }[mode]
    if mask != expected:
        raise ValueError(f"trainability mask changed for {mode}")
    return mask


def _parameter_groups(model) -> dict[str, list[torch.nn.Parameter]]:
    hydrology = model.hydrology_coordinates
    process = model.log_process_diagonal
    observation = model.log_observation_ratio
    if int(hydrology.numel()) != 12:
        raise RuntimeError("TUKF20 requires exactly twelve hydrologic coordinates")
    if int(process.numel()) != 8:
        raise RuntimeError("TUKF20 requires exactly eight process-noise diagonal values")
    if int(observation.numel()) != 1:
        raise RuntimeError("TUKF20 requires exactly one observation-noise ratio")
    return {
        "hydrology": [hydrology],
        "filter": [process, observation],
    }


def configure_mode_(model, mode: str, contract: Mapping[str, Any]) -> None:
    """Assign exact gradient ownership for one frozen four-mode cell."""

    mask = _mode_mask(contract, mode)
    for name, parameters in _parameter_groups(model).items():
        for parameter in parameters:
            parameter.grad = None
            parameter.requires_grad_(mask[name])


def build_optimizer(
    model, mode: str, contract: Mapping[str, Any]
) -> torch.optim.Adam | None:
    """Build independently named Adam groups for the active parameter families."""

    mask = _mode_mask(contract, mode)
    parameters = _parameter_groups(model)
    values = contract["optimizer"]
    groups: list[dict[str, Any]] = []
    if mask["hydrology"]:
        groups.append(
            {
                "params": parameters["hydrology"],
                "lr": float(values["hydrology_learning_rate"]),
                "group_name": "hydrology",
            }
        )
    if mask["filter"]:
        groups.append(
            {
                "params": parameters["filter"],
                "lr": float(values["filter_learning_rate"]),
                "group_name": "filter",
            }
        )
    if not groups:
        return None
    return torch.optim.Adam(
        groups,
        betas=tuple(float(value) for value in values["betas"]),
        eps=float(values["epsilon"]),
        weight_decay=float(values["weight_decay"]),
        amsgrad=bool(values["amsgrad"]),
    )


def clip_active_gradients_(
    model, mode: str, contract: Mapping[str, Any]
) -> dict[str, dict[str, float | int]]:
    """Validate and independently clip each active group.

    A frozen group must have no gradient object at all.  A zero but finite
    active gradient is recorded faithfully; it is not converted into a
    technical failure.
    """

    mask = _mode_mask(contract, mode)
    groups = _parameter_groups(model)
    limit = float(contract["optimizer"]["group_gradient_norm"])
    if not math.isfinite(limit) or limit <= 0.0:
        raise ValueError("group gradient norm limit must be finite and positive")
    result: dict[str, dict[str, float | int]] = {}
    for name, parameters in groups.items():
        if not mask[name]:
            if any(parameter.grad is not None for parameter in parameters):
                raise RuntimeError(f"frozen {name} group received a gradient")
            continue
        gradients = [parameter.grad for parameter in parameters]
        if any(
            value is None or not bool(torch.isfinite(value).all())
            for value in gradients
        ):
            raise FloatingPointError(
                f"active {name} gradient is missing or non-finite"
            )
        nonzero = sum(
            int(torch.count_nonzero(value).item())
            for value in gradients
            if value is not None
        )
        norm = float(torch.nn.utils.clip_grad_norm_(parameters, limit))
        if not math.isfinite(norm):
            raise FloatingPointError(f"active {name} gradient norm is non-finite")
        result[name] = {
            "nonzero_count": nonzero,
            "norm_before_clipping": norm,
        }
    return result


def assert_frozen_groups_unchanged(
    before: Mapping[str, Any],
    after: Mapping[str, Any],
    mode: str,
    contract: Mapping[str, Any],
) -> None:
    mask = _mode_mask(contract, mode)
    for name, keys in GROUP_KEYS.items():
        if mask[name]:
            continue
        for key in keys:
            if not _arrays_byte_equal(before[key], after[key]):
                raise RuntimeError(f"frozen {name} value changed: {key}")
    for key in FIXED_STRUCTURE_KEYS:
        if not _arrays_byte_equal(before[key], after[key]):
            raise RuntimeError(f"fixed model structure changed: {key}")


def _count_contacts(values: Any, bounds: Sequence[float] | None) -> int:
    if bounds is None or len(bounds) != 2:
        return 0
    array = np.asarray(values, dtype=np.float64)
    lower, upper = (float(value) for value in bounds)
    return int(np.count_nonzero((array <= lower) | (array >= upper)))


def boundary_contact_diagnostics(
    snapshot: Mapping[str, Any], contract: Mapping[str, Any]
) -> dict[str, int]:
    values = contract.get("truth_and_filter", {})
    hydrology = _count_contacts(snapshot["hydrology"], (0.0, 1.0))
    process = _count_contacts(
        snapshot["process_diagonal"], values.get("process_noise_bounds")
    )
    observation = _count_contacts(
        snapshot["observation_ratio"], values.get("observation_ratio_bounds")
    )
    return {
        "hydrology": hydrology,
        "process_noise": process,
        "observation_noise": observation,
        "total": hydrology + process + observation,
    }


def select_checkpoint(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    values = [
        {"update": int(row["update"]), "selection_loss": float(row["selection_loss"])}
        for row in rows
    ]
    if not values:
        raise ValueError("selection history is empty")
    if any(
        not math.isfinite(row["selection_loss"]) or row["selection_loss"] < 0.0
        for row in values
    ):
        raise ValueError("selection losses must be finite and nonnegative")
    return min(values, key=lambda row: (row["selection_loss"], row["update"]))


def _origin_indices(contract: Mapping[str, Any], split: str) -> tuple[int, ...]:
    module = _common_module()
    if hasattr(module, "origin_indices"):
        return tuple(int(value) for value in module.origin_indices(contract, split))
    row = contract["origins"][split]
    return tuple(range(int(row["start"]), int(row["end_inclusive"]) + 1))


def _leads(contract: Mapping[str, Any]) -> tuple[int, ...]:
    leads = tuple(int(value) for value in contract["objective"]["leads_days"])
    if leads != (1, 2, 3):
        raise ValueError("TUKF20 forecast leads must be exactly one, two, and three days")
    return leads


def _query_updates(contract: Mapping[str, Any]) -> tuple[int, ...]:
    updates = int(contract["optimizer"]["updates"])
    interval = int(contract["optimizer"]["selection_interval"])
    expected = tuple(range(0, updates + 1, interval))
    actual = tuple(int(value) for value in contract["selection"]["query_updates"])
    if actual != expected or expected != tuple(range(0, 97, 4)):
        raise ValueError("selection queries must be exactly 0,4,...,96")
    return actual


def _tensor_inputs(
    contract: Mapping[str, Any], model, forcing: np.ndarray, observations: np.ndarray
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    dtype = model.dtype
    device = model.device
    forcing_tensor = torch.as_tensor(forcing, dtype=dtype, device=device)
    observation_tensor = torch.as_tensor(
        observations, dtype=dtype, device=device
    ).reshape(-1)
    initial_state = torch.as_tensor(
        contract["truth_and_filter"]["initial_state"], dtype=dtype, device=device
    )
    dimension = int(initial_state.numel())
    if dimension != int(model.dim_x):
        raise ValueError("initial state dimension differs from the model")
    covariance = torch.eye(dimension, dtype=dtype, device=device) * float(
        contract["truth_and_filter"]["initial_covariance_diagonal"]
    )
    return forcing_tensor, observation_tensor, initial_state, covariance


def _rolling_objective(
    contract: Mapping[str, Any],
    model,
    forcing: torch.Tensor,
    observations: torch.Tensor,
    initial_state: torch.Tensor,
    covariance: torch.Tensor,
    split: str,
) -> tuple[torch.Tensor, Mapping[str, Any]]:
    # This literal is deliberately not mode-configurable.  All parameter
    # learning is mediated by the same daily state-update computation.
    return _common_module().rolling_origin_objective(
        model,
        forcing,
        observations,
        initial_state,
        covariance,
        _origin_indices(contract, split),
        state_update=True,
        targets=observations,
        base_observation_variance=float(
            contract["truth_and_filter"]["base_observation_variance"]
        ),
    )


def _arrays_byte_equal(left: Any, right: Any) -> bool:
    left_array = np.ascontiguousarray(np.asarray(left))
    right_array = np.ascontiguousarray(np.asarray(right))
    return (
        left_array.dtype == right_array.dtype
        and left_array.shape == right_array.shape
        and left_array.tobytes() == right_array.tobytes()
    )


def _snapshots_equal(left: Mapping[str, Any], right: Mapping[str, Any]) -> bool:
    return set(left) == set(right) and all(
        _arrays_byte_equal(left[key], right[key]) for key in left
    )


def run_mode_training(
    contract: Mapping[str, Any],
    model,
    mode: str,
    *,
    forcing: np.ndarray,
    observations: np.ndarray,
    directory: Path | None = None,
) -> dict[str, Any]:
    """Train and select one four-mode cell without reading any test target."""

    _mode_mask(contract, mode)
    query_updates = _query_updates(contract)
    leads = _leads(contract)
    configure_mode_(model, mode, contract)
    optimizer = build_optimizer(model, mode, contract)
    trainable = optimizer is not None

    selection_origins = _origin_indices(contract, "selection")
    supplied_end = max(selection_origins) + max(leads) + 1
    forcing_array = np.asarray(forcing, dtype=np.float64)
    observation_array = np.asarray(observations, dtype=np.float64).reshape(-1)
    if forcing_array.shape[0] < supplied_end or observation_array.shape[0] < supplied_end:
        raise ValueError("training inputs do not cover the complete selection targets")
    forcing_array = np.ascontiguousarray(forcing_array[:supplied_end])
    observation_array = np.ascontiguousarray(observation_array[:supplied_end])
    forcing_tensor, observation_tensor, initial_state, covariance = _tensor_inputs(
        contract, model, forcing_array, observation_array
    )

    output_directory = None if directory is None else Path(directory)
    checkpoint_directory: Path | None = None
    if output_directory is not None:
        if output_directory.exists():
            raise FileExistsError(f"refusing to replace mode directory: {output_directory}")
        output_directory.mkdir(parents=True, exist_ok=False)
        checkpoint_directory = output_directory / "selection_checkpoints"
        checkpoint_directory.mkdir()

    initial_snapshot = _snapshot_model(model)
    initial_hash = snapshot_sha256(initial_snapshot)
    snapshots: dict[int, dict[str, Any]] = {}
    selection_rows: list[dict[str, Any]] = []
    training_rows: list[dict[str, Any]] = []

    def register(update: int) -> None:
        with torch.no_grad():
            loss, details = _rolling_objective(
                contract,
                model,
                forcing_tensor,
                observation_tensor,
                initial_state,
                covariance,
                "selection",
            )
        value = float(loss)
        if not math.isfinite(value) or value < 0.0:
            raise FloatingPointError(
                f"non-finite or negative {mode} selection loss at update {update}"
            )
        snapshot = _snapshot_model(model)
        assert_frozen_groups_unchanged(initial_snapshot, snapshot, mode, contract)
        snapshot_hash = snapshot_sha256(snapshot)
        checkpoint_path: Path | None = None
        checkpoint_file: str | None = None
        checkpoint_file_hash: str | None = None
        if checkpoint_directory is not None:
            checkpoint_path = checkpoint_directory / f"update_{update:03d}.npz"
            _write_new_npz(checkpoint_path, snapshot)
            checkpoint_file = checkpoint_path.relative_to(output_directory).as_posix()
            checkpoint_file_hash = sha256_file(checkpoint_path)
        mse_by_lead = details.get("mse_by_lead", {})
        row = {
            "update": int(update),
            "selection_loss": value,
            "selection_mse_by_lead": {
                str(lead): float(mse_by_lead[lead]) for lead in leads
            },
            "snapshot_sha256": snapshot_hash,
            "checkpoint_file": checkpoint_file,
            "checkpoint_file_sha256": checkpoint_file_hash,
            "boundary_contacts": boundary_contact_diagnostics(snapshot, contract),
        }
        snapshots[int(update)] = _copy_snapshot(snapshot)
        selection_rows.append(row)

    register(0)
    optimizer_steps = 0
    if optimizer is not None:
        for update in range(1, int(contract["optimizer"]["updates"]) + 1):
            optimizer.zero_grad(set_to_none=True)
            loss, _ = _rolling_objective(
                contract,
                model,
                forcing_tensor,
                observation_tensor,
                initial_state,
                covariance,
                "train",
            )
            if not bool(torch.isfinite(loss)):
                raise FloatingPointError(f"non-finite {mode} loss at update {update}")
            loss.backward()
            gradient_statistics = clip_active_gradients_(model, mode, contract)
            optimizer.step()
            optimizer_steps += 1
            projector = getattr(model, "project_trainable_coordinates_", None)
            if not callable(projector):
                raise AttributeError("model lacks project_trainable_coordinates_")
            projector()
            current = _snapshot_model(model)
            assert_frozen_groups_unchanged(initial_snapshot, current, mode, contract)
            training_rows.append(
                {
                    "update": update,
                    "training_loss": float(loss.detach()),
                    "active_group_gradients": gradient_statistics,
                    "gradient_nonzero_counts": {
                        name: int(values["nonzero_count"])
                        for name, values in gradient_statistics.items()
                    },
                    "gradient_norms_before_clipping": {
                        name: float(values["norm_before_clipping"])
                        for name, values in gradient_statistics.items()
                    },
                    "boundary_contacts": boundary_contact_diagnostics(current, contract),
                }
            )
            if update in query_updates:
                register(update)

    expected_queries = len(query_updates) if trainable else 1
    if len(selection_rows) != expected_queries:
        raise RuntimeError("selection query count differs from the frozen mode budget")
    expected_steps = int(contract["optimizer"]["updates"]) if trainable else 0
    if optimizer_steps != expected_steps:
        raise RuntimeError("optimizer step count differs from the frozen mode budget")

    selected = select_checkpoint(selection_rows)
    selected_update = int(selected["update"])
    if not trainable and selected_update != 0:
        raise RuntimeError("the fully frozen mode must select update zero")
    selected_snapshot = _copy_snapshot(snapshots[selected_update])
    _restore_model(model, selected_snapshot)
    restored_snapshot = _snapshot_model(model)
    if not _snapshots_equal(selected_snapshot, restored_snapshot):
        raise RuntimeError("restored model differs from the selected checkpoint")
    assert_frozen_groups_unchanged(
        initial_snapshot, restored_snapshot, mode, contract
    )

    selected_path: Path | None = None
    selected_file_hash: str | None = None
    history_path: Path | None = None
    if output_directory is not None:
        selected_path = output_directory / "selected_checkpoint.npz"
        _write_new_npz(selected_path, selected_snapshot)
        selected_file_hash = sha256_file(selected_path)
        history = {
            "schema_version": "tukf20_mode_training_history_v1",
            "experiment_id": str(contract["experiment_id"]),
            "mode": mode,
            "state_update": True,
            "active_groups": [
                name for name, active in _mode_mask(contract, mode).items() if active
            ],
            "initial_snapshot_sha256": initial_hash,
            "optimizer_step_count": optimizer_steps,
            "real_optimizer_step_count": optimizer_steps,
            "selection_query_count": len(selection_rows),
            "training_rows": training_rows,
            "selection_rows": selection_rows,
            "selected": selected,
            "selected_snapshot_sha256": snapshot_sha256(selected_snapshot),
            "selected_checkpoint_sha256": selected_file_hash,
            "test_observation_input_count": 0,
            "clean_target_query_count": 0,
        }
        history_path = output_directory / "history.json"
        _write_new_json(history_path, history)

    return {
        "mode": mode,
        "state_update": True,
        "selected": selected,
        "selected_snapshot": selected_snapshot,
        "selected_snapshot_sha256": snapshot_sha256(selected_snapshot),
        "initial_snapshot_sha256": initial_hash,
        "optimizer_step_count": optimizer_steps,
        "real_optimizer_step_count": optimizer_steps,
        "selection_query_count": len(selection_rows),
        "training_rows": training_rows,
        "selection_rows": selection_rows,
        "checkpoint_path": selected_path,
        "checkpoint_file_sha256": selected_file_hash,
        "history_path": history_path,
        "history_file_sha256": None
        if history_path is None
        else sha256_file(history_path),
        "test_observation_input_count": 0,
        "clean_target_query_count": 0,
        "maximum_observation_index_supplied": supplied_end - 1,
    }


def _budget_value(contract: Mapping[str, Any], *names: str) -> int:
    for section_name in ("budget", "seals_and_budget", "expected_budget"):
        section = contract.get(section_name, {})
        for name in names:
            if name in section:
                return int(section[name])
    raise KeyError(f"missing frozen budget field: {names}")


def _resolve_checkpoint_path(root: Path, raw: Path | str) -> Path:
    path = Path(raw)
    if path.is_absolute() or path.is_file():
        return path
    rooted = root / path
    return rooted


def _relative_checkpoint_path(root: Path, checkpoint: Path) -> str:
    try:
        relative = checkpoint.resolve().relative_to(root.resolve())
    except ValueError as error:
        raise ValueError("selected checkpoint lies outside the formal result root") from error
    return relative.as_posix()


def _load_npz_snapshot(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as payload:
        return {str(name): np.asarray(payload[name]).copy() for name in payload.files}


def write_global_selection_seal(
    root: Path,
    contract: Mapping[str, Any],
    cells: Sequence[Mapping[str, Any]],
    *,
    source_sha256: Mapping[str, str],
) -> dict[str, Any]:
    """Seal all selected mode checkpoints before any formal test readout."""

    root = Path(root)
    modes = _mode_order(contract)
    expected_cells = _budget_value(
        contract, "selected_checkpoints", "sealed_mode_checkpoints", "mode_cells"
    )
    if len(cells) != expected_cells:
        raise RuntimeError(
            f"global selection requires exactly {expected_cells} mode checkpoints"
        )
    if any(
        int(row.get("test_observation_input_count", -1)) != 0
        or int(row.get("clean_target_query_count", -1)) != 0
        for row in cells
    ):
        raise PermissionError("test information was accessed before global selection")

    identities = {
        (int(row["truth_seed"]), str(row["start_id"]), str(row["mode"]))
        for row in cells
    }
    pairs = {(seed, start) for seed, start, _ in identities}
    if len(identities) != expected_cells:
        raise RuntimeError("global selection contains duplicate mode identities")
    if (
        len(pairs) * len(modes) != expected_cells
        or len({seed for seed, _ in pairs}) != len(pairs)
        or len({start for _, start in pairs}) != len(pairs)
        or {mode for _, _, mode in identities} != set(modes)
    ):
        raise RuntimeError("global selection identities are incomplete or non-independent")
    expected_identities = {
        (seed, start, mode) for seed, start in pairs for mode in modes
    }
    if identities != expected_identities:
        raise RuntimeError("each registered pair must contain all four modes")

    optimizer_steps = sum(int(row["optimizer_step_count"]) for row in cells)
    selection_queries = sum(int(row["selection_query_count"]) for row in cells)
    expected_steps = _budget_value(contract, "real_optimizer_updates")
    expected_queries = _budget_value(contract, "selection_queries")
    if optimizer_steps != expected_steps:
        raise RuntimeError("optimizer update count differs from the frozen budget")
    if selection_queries != expected_queries:
        raise RuntimeError("selection query count differs from the frozen budget")

    query_updates = set(_query_updates(contract))
    checkpoint_paths: list[Path] = []
    sealed_cells: list[dict[str, Any]] = []
    for row in cells:
        mode = str(row["mode"])
        mask = _mode_mask(contract, mode)
        trainable = mask["hydrology"] or mask["filter"]
        selected_update = int(row["selected"]["update"])
        if not trainable and selected_update != 0:
            raise RuntimeError("the fully frozen mode must seal update zero")
        if trainable and selected_update not in query_updates:
            raise RuntimeError("a trainable mode selected an unqueried update")
        checkpoint_path = _resolve_checkpoint_path(root, row["checkpoint_path"])
        if not checkpoint_path.is_file():
            raise FileNotFoundError(f"selected checkpoint is missing: {checkpoint_path}")
        relative_checkpoint = _relative_checkpoint_path(root, checkpoint_path)
        actual_file_hash = sha256_file(checkpoint_path)
        if actual_file_hash != str(row["checkpoint_file_sha256"]):
            raise ValueError("selected checkpoint file hash changed")
        snapshot = _load_npz_snapshot(checkpoint_path)
        if snapshot_sha256(snapshot) != str(row["selected_snapshot_sha256"]):
            raise ValueError("selected checkpoint snapshot hash changed")
        checkpoint_paths.append(checkpoint_path.resolve())
        sealed_cells.append(
            {
                "truth_seed": int(row["truth_seed"]),
                "start_id": str(row["start_id"]),
                "mode": mode,
                "state_update": True,
                "selected_update": selected_update,
                "selected_selection_loss": float(row["selected"]["selection_loss"]),
                "selected_snapshot_sha256": str(row["selected_snapshot_sha256"]),
                "checkpoint_path": relative_checkpoint,
                "checkpoint_file_sha256": actual_file_hash,
            }
        )
    if len(set(checkpoint_paths)) != expected_cells:
        raise RuntimeError("selected checkpoints must use unique files")

    seal = {
        "schema_version": "tukf20_global_selection_seal_v1",
        "experiment_id": str(contract["experiment_id"]),
        "status": "GLOBAL_SELECTION_SEALED",
        "completed_mode_checkpoints": len(cells),
        "completed_method_checkpoints": len(cells),
        "optimizer_step_count": optimizer_steps,
        "selection_query_count": selection_queries,
        "test_observation_inputs_before_seal": 0,
        "clean_target_queries_before_seal": 0,
        "source_sha256": dict(source_sha256),
        "cells": sealed_cells,
    }
    _write_new_json(root / "selection_seal.json", seal)
    return seal


def require_complete_selection_seal(
    root: Path, contract: Mapping[str, Any]
) -> dict[str, Any]:
    path = Path(root) / "selection_seal.json"
    if not path.is_file():
        raise PermissionError("test readout requires the global selection seal")
    with path.open("r", encoding="utf-8") as handle:
        seal = json.load(handle)
    expected = _budget_value(
        contract, "selected_checkpoints", "sealed_mode_checkpoints", "mode_cells"
    )
    if not (
        seal.get("status") == "GLOBAL_SELECTION_SEALED"
        and int(seal.get("completed_mode_checkpoints", -1)) == expected
        and int(seal.get("test_observation_inputs_before_seal", -1)) == 0
        and int(seal.get("clean_target_queries_before_seal", -1)) == 0
    ):
        raise PermissionError("global selection seal is incomplete")
    return seal
