"""Run the gated TUKF20 rolling-origin joint-learning experiment."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import sys
import time
from typing import Any, Mapping

import numpy as np
import psutil
import torch


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf20_hbv_rolling_origin_joint_learning_common as common  # noqa: E402
from scripts import tukf20_hbv_rolling_origin_mode_training as mode_training  # noqa: E402
from scripts import run_tukf17_hbv_rolling_origin_state_hydrology_update as readout_engine  # noqa: E402


DEFAULT_CONFIG = common.DEFAULT_CONFIG
EXPERIMENT_ID = common.EXPERIMENT_ID


def _patch_readout_engine() -> None:
    """Route inherited numerical helpers through the frozen TUKF20 contract."""

    readout_engine.common = common
    readout_engine.DEFAULT_CONFIG = DEFAULT_CONFIG
    readout_engine.EXPERIMENT_ID = EXPERIMENT_ID


def _same_experiment_controller_pids() -> list[int]:
    current = os.getpid()
    needle = Path(__file__).name.lower()
    pids: list[int] = []
    for process in psutil.process_iter(["pid", "name", "cmdline"]):
        try:
            pid = int(process.info["pid"])
            if pid == current:
                continue
            name = str(process.info.get("name") or "").lower()
            command = " ".join(process.info.get("cmdline") or []).lower()
        except (psutil.NoSuchProcess, psutil.AccessDenied, TypeError, ValueError):
            continue
        if name.startswith("python") and needle in command and "--stage formal" in command:
            pids.append(pid)
    return sorted(pids)


def resource_admission(contract: Mapping[str, Any]) -> dict[str, Any]:
    required = contract["resources"]
    available_memory = float(psutil.virtual_memory().available / (1024**3))
    free_storage = float(shutil.disk_usage(ROOT).free / (1024**3))
    other_controllers = _same_experiment_controller_pids()
    maximum = int(
        required.get(
            "maximum_same_experiment_other_controllers",
            required.get("maximum_other_active_formal_controllers", 0),
        )
    )
    checks = {
        "available_memory": available_memory
        >= float(required["minimum_available_memory_gib"]),
        "workspace_free_storage": free_storage
        >= float(required["minimum_workspace_free_storage_gib"]),
        "no_duplicate_formal_controller": len(other_controllers) <= maximum,
    }
    return {
        "status": "RESOURCE_ADMITTED" if all(checks.values()) else "RESOURCE_HOLD",
        "checks": checks,
        "available_memory_gib": available_memory,
        "workspace_free_storage_gib": free_storage,
        "same_experiment_other_controller_pids": other_controllers,
    }


def _balance_errors(
    contract: Mapping[str, Any], registry: Mapping[str, Any]
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Compute the registered training/selection balance arrays, never test metrics."""

    _patch_readout_engine()
    return readout_engine._balance_errors(contract, registry)


def run_preflight(
    contract: Mapping[str, Any], *, contract_path: Path = DEFAULT_CONFIG
) -> dict[str, Any]:
    validation = common.validate_contract(contract, configuration_path=contract_path)
    root = common.resolve_output_path(contract, contract["outputs"]["preflight_root"])
    result_root = common.resolve_output_path(contract, contract["outputs"]["result_root"])
    failed_root = common.resolve_output_path(
        contract, contract["outputs"]["failed_result_root"]
    )
    for path, label in (
        (root, "preflight"),
        (result_root, "formal result"),
        (failed_root, "failed-attempt"),
    ):
        if path.exists():
            raise FileExistsError(f"refusing an existing TUKF20 {label} root: {path}")
    root.mkdir(parents=True, exist_ok=False)
    seed_registry = common.freeze_seed_registry(
        contract,
        destination=root / "seed_registry.json",
        configuration_path=contract_path,
    )
    e00, e01, e10, e11 = _balance_errors(contract, seed_registry)
    common.write_new_npz(
        root / "balance_errors.npz",
        {"E00": e00, "E01": e01, "E10": e10, "E11": e11},
    )
    balance = common.classify_balance_arrays(e00, e01, e10, e11, contract)
    common.write_new_json(root / "balance_gate.json", balance)
    sources = common.source_hashes(contract, configuration_path=contract_path)
    resources = resource_admission(contract)
    report = {
        "schema_version": "tukf20_engineering_preflight_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": (
            "PREFLIGHT_ENGINEERING_PASS"
            if balance["status"] == "BALANCE_PASS"
            else "BALANCE_HOLD"
        ),
        "balance_status": balance["status"],
        "validation": validation,
        "resource_status": resources["status"],
        "resources": resources,
        "source_sha256": sources,
        "configuration_sha256": common.sha256_file(contract_path),
        "seed_registry_sha256": common.sha256_file(root / "seed_registry.json"),
        "balance_gate_sha256": common.sha256_file(root / "balance_gate.json"),
        "balance_errors_sha256": common.sha256_file(root / "balance_errors.npz"),
        "test_metric_queries": 0,
        "clean_test_target_queries": 0,
        "formal_optimizer_updates": 0,
        "formal_training_started": False,
    }
    common.write_new_json(root / "preflight.json", report)
    return report


def require_verified_preflight(
    contract: Mapping[str, Any], contract_path: Path
) -> tuple[dict[str, Any], dict[str, Any]]:
    root = common.resolve_output_path(contract, contract["outputs"]["preflight_root"])
    preflight = common.read_json(root / "preflight.json")
    verification = common.read_json(root / "independent_verification.json")
    if (
        preflight.get("status") != "PREFLIGHT_ENGINEERING_PASS"
        or preflight.get("balance_status") != "BALANCE_PASS"
        or int(preflight.get("test_metric_queries", -1)) != 0
        or int(preflight.get("clean_test_target_queries", -1)) != 0
        or int(preflight.get("formal_optimizer_updates", -1)) != 0
    ):
        raise PermissionError("formal training requires a clean TUKF20 balance pass")
    if (
        verification.get("status") != "PREFLIGHT_VERIFIED"
        or not verification.get("checks")
        or not all(bool(value) for value in verification["checks"].values())
        or int(verification.get("test_metric_queries", -1)) != 0
        or int(verification.get("formal_optimizer_updates", -1)) != 0
    ):
        raise PermissionError("formal training requires independent preflight verification")
    if preflight.get("source_sha256") != common.source_hashes(
        contract, configuration_path=contract_path
    ):
        raise RuntimeError("TUKF20 source files changed after preflight")
    if preflight.get("configuration_sha256") != common.sha256_file(contract_path):
        raise RuntimeError("TUKF20 configuration changed after preflight")
    return preflight, verification


def _root_manifest(root: Path) -> dict[str, Any]:
    return {
        "schema_version": "tukf20_root_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "files": {
            path.relative_to(root).as_posix(): common.sha256_file(path)
            for path in sorted(root.rglob("*"))
            if path.is_file() and path.name != "manifest.json"
        },
    }


def _freeze_model_for_test(model: Any) -> None:
    for parameter in (
        model.hydrology_coordinates,
        model.log_process_diagonal,
        model.log_observation_ratio,
    ):
        parameter.grad = None
        parameter.requires_grad_(False)


def archive_failed_formal_attempt(
    contract: Mapping[str, Any], error: BaseException
) -> Path | None:
    root = common.resolve_output_path(contract, contract["outputs"]["result_root"])
    identity_path = root / "attempt_identity.json"
    if not identity_path.is_file():
        return None
    identity = common.read_json(identity_path)
    if int(identity.get("controller_pid", -1)) != os.getpid():
        return None
    if (root / "registry.json").is_file() and (root / "manifest.json").is_file():
        return None
    failed_root = common.resolve_output_path(
        contract, contract["outputs"]["failed_result_root"]
    )
    failed_root.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    attempt_root = failed_root / f"attempt_{stamp}_pid_{os.getpid()}"
    attempt_root.mkdir(exist_ok=False)
    root.rename(attempt_root / "partial_result")
    common.write_new_json(
        attempt_root / "failure.json",
        {
            "schema_version": "tukf20_failed_formal_attempt_v1",
            "experiment_id": EXPERIMENT_ID,
            "status": "FORMAL_ATTEMPT_FAILED_TECHNICALLY",
            "formal_started_at_utc": identity.get("formal_started_at_utc"),
            "failed_at_utc": datetime.now(timezone.utc).isoformat(),
            "controller_pid": os.getpid(),
            "exception_type": type(error).__name__,
            "exception_message": str(error),
            "partial_result_directory": "partial_result",
            "scientific_contract_changed": False,
        },
    )
    return attempt_root


def run_formal(
    contract: Mapping[str, Any],
    *,
    contract_path: Path = DEFAULT_CONFIG,
    user_confirmed_formal_training: bool = False,
) -> dict[str, Any]:
    if not user_confirmed_formal_training:
        raise PermissionError("formal training requires explicit user confirmation")
    common.validate_contract(contract, configuration_path=contract_path)
    require_verified_preflight(contract, contract_path)
    admission = resource_admission(contract)
    if admission["status"] != "RESOURCE_ADMITTED":
        raise PermissionError("TUKF20 formal resource admission is on hold")
    preflight_root = common.resolve_output_path(
        contract, contract["outputs"]["preflight_root"]
    )
    pairs = common.registered_pairs(
        contract, common.read_json(preflight_root / "seed_registry.json")
    )
    root = common.resolve_output_path(contract, contract["outputs"]["result_root"])
    if root.exists():
        raise FileExistsError(f"refusing to replace TUKF20 result root: {root}")
    sources = common.source_hashes(contract, configuration_path=contract_path)
    torch.set_num_threads(int(contract["numerical_environment"]["torch_threads"]))
    root.mkdir(parents=True, exist_ok=False)
    started_at = datetime.now(timezone.utc).isoformat()
    common.write_new_json(
        root / "attempt_identity.json",
        {
            "schema_version": "tukf20_formal_attempt_identity_v1",
            "experiment_id": EXPERIMENT_ID,
            "controller_pid": os.getpid(),
            "formal_started_at_utc": started_at,
        },
    )
    started = time.time()
    completed: list[dict[str, Any]] = []
    truth_cache: dict[tuple[int, str], tuple[np.ndarray, dict[str, Any]]] = {}
    for seed, start_id in pairs:
        forcing, truth = common.generate_truth_for_seed(contract, seed)
        truth_cache[(seed, start_id)] = (forcing, truth)
        observations = np.asarray(truth["observations"], dtype=np.float64)
        pair_root = root / "repetitions" / f"truth_{seed}__{start_id}"
        for mode in common.PIPELINE_ORDER:
            model = common.build_model(contract, start_id)
            result = mode_training.run_mode_training(
                contract,
                model,
                mode,
                forcing=forcing,
                observations=observations,
                directory=pair_root / "modes" / mode,
            )
            completed.append(
                {"truth_seed": seed, "start_id": start_id, **result}
            )
    mode_training.write_global_selection_seal(
        root, contract, completed, source_sha256=sources
    )
    mode_training.require_complete_selection_seal(root, contract)
    cell_index = {
        (int(row["truth_seed"]), str(row["start_id"]), str(row["mode"])): row
        for row in completed
    }
    _patch_readout_engine()
    rows: list[dict[str, Any]] = []
    for seed, start_id in pairs:
        forcing, truth = truth_cache[(seed, start_id)]
        pair_root = root / "repetitions" / f"truth_{seed}__{start_id}"
        common.write_new_npz(
            pair_root / "truth_arrays.npz",
            {
                name: value
                for name, value in truth.items()
                if isinstance(value, np.ndarray)
            },
        )
        pair_rows: list[dict[str, Any]] = []
        for readout_id in common.READOUT_ORDER:
            specification = contract["readout_grid"][readout_id]
            source_mode = str(specification["parameter_source_pipeline"])
            snapshot = cell_index[(seed, start_id, source_mode)]["selected_snapshot"]
            model = common.build_model(contract, start_id)
            common.restore_model_(model, snapshot)
            _freeze_model_for_test(model)
            frozen_snapshot_hash = common.sha256_arrays(common.snapshot_model(model))
            arrays, metrics = readout_engine.evaluate_readout(
                contract,
                model,
                readout_id,
                forcing=forcing,
                truth=truth,
            )
            if int(metrics.get("online_parameter_update_count", -1)) != 0:
                raise RuntimeError("TUKF20 test readout changed a frozen parameter")
            if common.sha256_arrays(common.snapshot_model(model)) != frozen_snapshot_hash:
                raise RuntimeError("TUKF20 test readout mutated the frozen model")
            readout_root = pair_root / "readouts" / readout_id
            common.write_new_npz(readout_root / "arrays.npz", arrays)
            row = {
                "truth_seed": seed,
                "start_id": start_id,
                **metrics,
                "arrays_sha256": common.sha256_file(readout_root / "arrays.npz"),
                "parameter_snapshot_sha256": frozen_snapshot_hash,
            }
            common.write_new_json(readout_root / "metrics.json", row)
            rows.append(row)
            pair_rows.append(row)
        common.write_new_json(
            pair_root / "pair_metrics.json",
            {
                "schema_version": "tukf20_pair_metrics_v1",
                "truth_seed": seed,
                "start_id": start_id,
                "readouts": pair_rows,
            },
        )
    primary = common.aggregate_primary_pipelines(rows, contract)
    crossed = common.aggregate_crossed_readouts(rows, contract)
    aggregate = {"primary": primary, "crossed": crossed}
    scientific = common.classify_mechanisms(aggregate, contract)
    registry = {
        "schema_version": "tukf20_formal_registry_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FORMAL_COMPLETE_AWAITING_INDEPENDENT_VERIFICATION",
        "rows": rows,
        "aggregates": aggregate,
        "scientific_classification": scientific,
        "selection_seal_sha256": common.sha256_file(root / "selection_seal.json"),
        "source_sha256_start": sources,
        "source_sha256_end": common.source_hashes(
            contract, configuration_path=contract_path
        ),
        "resource_admission": admission,
        "formal_started_at_utc": started_at,
        "elapsed_seconds": time.time() - started,
        "claims_not_authorized": contract["claims_not_authorized"],
    }
    common.write_new_json(root / "registry.json", registry)
    common.write_new_json(root / "manifest.json", _root_manifest(root))
    return registry


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("preflight", "formal"), required=True)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--confirm-formal-training", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    contract_path = args.config.resolve()
    contract = common.load_contract(contract_path)
    if args.stage == "preflight":
        if args.confirm_formal_training:
            raise PermissionError("formal confirmation cannot be attached to preflight")
        report = run_preflight(contract, contract_path=contract_path)
    else:
        formal_root = common.resolve_output_path(
            contract, contract["outputs"]["result_root"]
        )
        existed = formal_root.exists()
        try:
            report = run_formal(
                contract,
                contract_path=contract_path,
                user_confirmed_formal_training=bool(args.confirm_formal_training),
            )
        except BaseException as error:
            if not existed:
                archive_failed_formal_attempt(contract, error)
            raise
    print(
        json.dumps(
            {
                "status": report["status"],
                "experiment_id": EXPERIMENT_ID,
                "balance_status": report.get("balance_status"),
                "resource_status": report.get("resource_status"),
            },
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
