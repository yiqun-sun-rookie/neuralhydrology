"""Gate, execute, verify, plot, and package the TUKF20 HPC formal run.

The paid Slurm job uses the ``execute`` stage.  The ``package`` stage is a
post-completion operation: it is allowed to create the immutable result archive
only after final Slurm ``COMPLETED``/``0:0`` accounting has been persisted.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import importlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import time
import traceback
from typing import Any, Mapping, MutableMapping


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import build_tukf20_hpc_bundle as bundle_builder  # noqa: E402
from scripts import smoke_tukf20_hpc_compatibility as smoke_runner  # noqa: E402
from scripts import tukf20_hpc_deployment_common as deployment_common  # noqa: E402


DEFAULT_CONFIG = deployment_common.DEFAULT_CONFIG


def _scientific_modules() -> tuple[Any, Any]:
    scientific = importlib.import_module(
        "scripts.tukf20_hbv_rolling_origin_joint_learning_common"
    )
    runner = importlib.import_module(
        "scripts.run_tukf20_hbv_rolling_origin_joint_learning"
    )
    return scientific, runner


def require_smoke_gate(
    smoke: Mapping[str, Any],
    completion: Mapping[str, Any],
    *,
    smoke_path: Path,
    deployment: Mapping[str, Any],
    expected_bundle_sha256: str,
    expected_deployment_config_sha256: str,
    expected_smoke_job_id: int,
    sacct_path: Path,
) -> bool:
    """Require a hash-bound smoke pass and final successful Slurm accounting."""

    if smoke.get("status") != "HPC_SMOKE_PASS":
        raise PermissionError("formal execution requires HPC_SMOKE_PASS")
    checks = smoke.get("checks")
    if not isinstance(checks, Mapping) or not checks or not all(
        bool(value) for value in checks.values()
    ):
        raise PermissionError("formal execution requires every smoke check true")
    expected_identity = (
        deployment["deployment_id"],
        deployment["scientific_experiment_id"],
    )
    if (
        smoke.get("deployment_id"),
        smoke.get("scientific_experiment_id"),
    ) != expected_identity:
        raise PermissionError("smoke identity differs from the deployment")
    if smoke.get("bundle_sha256") != expected_bundle_sha256:
        raise PermissionError("smoke report is bound to another deployment bundle")
    if (
        smoke.get("deployment_config_sha256")
        != expected_deployment_config_sha256
    ):
        raise PermissionError("smoke report is bound to another deployment config")

    if completion.get("schema_version") != "tukf20_hpc_smoke_completion_v1":
        raise PermissionError("smoke completion record schema differs")
    if (
        completion.get("deployment_id"),
        completion.get("scientific_experiment_id"),
    ) != expected_identity:
        raise PermissionError("smoke completion identity differs")
    if completion.get("bundle_sha256") != expected_bundle_sha256:
        raise PermissionError("smoke completion bundle binding differs")
    if (
        completion.get("deployment_config_sha256")
        != expected_deployment_config_sha256
    ):
        raise PermissionError("smoke completion config binding differs")
    if completion.get("smoke_report_sha256") != deployment_common.sha256_file(
        smoke_path
    ):
        raise PermissionError("smoke completion report hash differs")
    try:
        report_job_id = int(smoke.get("slurm_job_id", -1))
        completion_job_id = int(completion.get("smoke_job_id", -1))
    except (TypeError, ValueError) as error:
        raise PermissionError("smoke evidence has an invalid Slurm job identifier") from error
    if report_job_id != expected_smoke_job_id or completion_job_id != expected_smoke_job_id:
        raise PermissionError("smoke report, completion, and receipt job identifiers differ")
    if completion.get("slurm_state") != "COMPLETED":
        raise PermissionError("smoke Slurm job did not complete successfully")
    if completion.get("slurm_exit_code") != "0:0":
        raise PermissionError("smoke Slurm job exit code is not 0:0")
    if completion.get("status") != "HPC_SMOKE_SLURM_COMPLETED":
        raise PermissionError("smoke completion status differs")
    if completion.get("sacct_snapshot_sha256") != deployment_common.sha256_file(
        sacct_path
    ):
        raise PermissionError("smoke completion accounting hash differs")
    return True


def require_scientific_preflight(
    contract: Mapping[str, Any],
    *,
    contract_path: Path,
    scientific_runner: Any,
) -> dict[str, Any]:
    """Recheck the balance-only seal immediately before paid training."""

    preflight, verification = scientific_runner.require_verified_preflight(
        contract, contract_path
    )
    checks = {
        "engineering_pass": preflight.get("status")
        == "PREFLIGHT_ENGINEERING_PASS",
        "balance_pass": preflight.get("balance_status") == "BALANCE_PASS",
        "independent_verification": verification.get("status")
        == "PREFLIGHT_VERIFIED"
        and isinstance(verification.get("checks"), Mapping)
        and bool(verification["checks"])
        and all(bool(value) for value in verification["checks"].values()),
        "no_test_queries": int(preflight.get("test_metric_queries", -1)) == 0
        and int(preflight.get("clean_test_target_queries", -1)) == 0
        and int(verification.get("test_metric_queries", -1)) == 0,
        "no_formal_updates": int(preflight.get("formal_optimizer_updates", -1))
        == 0
        and int(verification.get("formal_optimizer_updates", -1)) == 0,
    }
    if not all(checks.values()):
        raise PermissionError(f"scientific preflight gate failed: {checks}")
    return {
        "checks": checks,
        "preflight_sha256": scientific_runner.common.sha256_file(
            scientific_runner.common.resolve_output_path(
                contract, contract["outputs"]["preflight_root"]
            )
            / "preflight.json"
        ),
        "verification_sha256": scientific_runner.common.sha256_file(
            scientific_runner.common.resolve_output_path(
                contract, contract["outputs"]["preflight_root"]
            )
            / "independent_verification.json"
        ),
    }


def _run_step(command: list[str]) -> dict[str, Any]:
    started = time.perf_counter()
    completed = subprocess.run(command, cwd=ROOT, check=False)
    row = {
        "command": command,
        "return_code": int(completed.returncode),
        "elapsed_seconds": time.perf_counter() - started,
    }
    if completed.returncode != 0:
        raise RuntimeError(f"formal HPC step failed: {row}")
    return row


def validate_formal_outputs(
    deployment: Mapping[str, Any], contract: Mapping[str, Any], *, scientific: Any
) -> dict[str, Any]:
    """Validate technical completeness without changing the scientific verdict."""

    expected = deployment["formal_expectations"]
    result_root = scientific.resolve_output_path(
        contract, contract["outputs"]["result_root"]
    )
    figure_root = scientific.resolve_output_path(
        contract, contract["outputs"]["figure_root"]
    )
    registry_path = result_root / "registry.json"
    verification_path = result_root / "independent_verification.json"
    figure_manifest_path = figure_root / "manifest.json"
    registry = scientific.read_json(registry_path)
    verification = scientific.read_json(verification_path)
    figure_manifest = scientific.read_json(figure_manifest_path)
    histories = tuple(
        result_root.glob("repetitions/*/modes/*/history.json")
    )
    figure_files = figure_manifest.get("files", {})
    figure_files_ok = isinstance(figure_files, Mapping) and bool(figure_files)
    if figure_files_ok:
        for name, registration in figure_files.items():
            path = figure_root / str(name)
            figure_files_ok = bool(
                path.is_file()
                and path.stat().st_size == int(registration.get("bytes", -1))
                and scientific.sha256_file(path) == registration.get("sha256")
            )
            if not figure_files_ok:
                break
    primary = verification.get("independent_aggregates", {}).get("primary", {})
    contrasts = primary.get("contrasts", {}) if isinstance(primary, Mapping) else {}
    checks = {
        "registry_status": registry.get("status") == expected["registry_status"],
        "scientific_identity": registry.get("experiment_id")
        == deployment["scientific_experiment_id"]
        and verification.get("experiment_id")
        == deployment["scientific_experiment_id"]
        and figure_manifest.get("experiment_id")
        == deployment["scientific_experiment_id"],
        "mode_history_count": len(histories)
        == int(expected["mode_history_count"]),
        "registry_readout_count": len(registry.get("rows", ()))
        == int(expected["test_readout_count"]),
        "independent_verification": verification.get("status")
        == expected["independent_verification_status"]
        and isinstance(verification.get("checks"), Mapping)
        and bool(verification["checks"])
        and all(bool(value) for value in verification["checks"].values()),
        "independent_readout_count": int(
            verification.get("test_readout_count", -1)
        )
        == int(expected["test_readout_count"]),
        "clean_error_budget": int(
            verification.get("primary_clean_error_count", -1)
        )
        == int(expected["primary_clean_error_count"]),
        "primary_contrast_set": set(contrasts)
        == set(expected["primary_contrasts"]),
        "verified_figures": figure_manifest.get("status")
        == expected["figure_manifest_status"]
        and figure_files_ok,
        "technical_boundary": bool(
            verification.get("technical_verification_is_not_scientific_success")
        )
        and bool(
            figure_manifest.get("technical_verification_is_not_scientific_success")
        ),
    }
    if not all(checks.values()):
        raise RuntimeError(f"formal HPC output validation failed: {checks}")
    return {
        "checks": checks,
        "result_root": result_root,
        "figure_root": figure_root,
        "registry_sha256": scientific.sha256_file(registry_path),
        "verification_sha256": scientific.sha256_file(verification_path),
        "figure_manifest_sha256": scientific.sha256_file(figure_manifest_path),
        "scientific_classification": verification["scientific_classification"],
    }


def _gate_context(
    deployment_path: Path, bundle_manifest_path: Path | None
) -> dict[str, Any]:
    deployment = deployment_common.load_deployment(
        deployment_path, validate_sources=True
    )
    external_path = bundle_manifest_path or (
        ROOT / "_transport" / deployment["outputs"]["bundle_manifest_name"]
    )
    package = smoke_runner.verify_extracted_payload(ROOT, external_path)
    smoke_path = deployment_common.resolve_root_relative(
        deployment["outputs"]["smoke_report"]
    )
    completion_path = deployment_common.resolve_root_relative(
        deployment["outputs"]["smoke_completion_record"]
    )
    smoke = deployment_common.read_json(smoke_path)
    completion = deployment_common.read_json(completion_path)
    status_root = deployment_common.resolve_root_relative(
        deployment["outputs"]["hpc_status_root"]
    )
    smoke_job_id = _validate_submission_evidence(
        status_root,
        stage="smoke",
        deployment=deployment,
        expected_bundle_sha256=package["bundle_sha256"],
        expected_deployment_config_sha256=package["deployment_config_sha256"],
        require_sacct=True,
    )
    smoke_sacct_path = deployment_common.submission_evidence_paths(
        status_root, stage="smoke"
    )["sacct"]
    require_smoke_gate(
        smoke,
        completion,
        smoke_path=smoke_path,
        deployment=deployment,
        expected_bundle_sha256=package["bundle_sha256"],
        expected_deployment_config_sha256=package["deployment_config_sha256"],
        expected_smoke_job_id=smoke_job_id,
        sacct_path=smoke_sacct_path,
    )
    return {
        "deployment": deployment,
        "external_path": external_path,
        "package": package,
        "smoke_path": smoke_path,
        "smoke_completion_path": completion_path,
        "smoke": smoke,
        "smoke_completion": completion,
    }


def run_execution(
    *,
    deployment_path: Path = DEFAULT_CONFIG,
    bundle_manifest_path: Path | None = None,
) -> dict[str, Any]:
    context = _gate_context(deployment_path, bundle_manifest_path)
    deployment = context["deployment"]
    scientific, scientific_runner = _scientific_modules()
    scientific_config_path = (
        ROOT / deployment["source_contract"]["scientific_config_path"]
    ).resolve()
    contract = scientific.load_contract(scientific_config_path)
    preflight = require_scientific_preflight(
        contract,
        contract_path=scientific_config_path,
        scientific_runner=scientific_runner,
    )

    status_root = deployment_common.resolve_root_relative(
        deployment["outputs"]["hpc_status_root"]
    )
    formal_submission_job_id = _validate_submission_evidence(
        status_root,
        stage="formal",
        deployment=deployment,
        expected_bundle_sha256=context["package"]["bundle_sha256"],
        expected_deployment_config_sha256=context["package"][
            "deployment_config_sha256"
        ],
        require_sacct=False,
    )
    start_path = status_root / "formal_pipeline_started.json"
    complete_path = status_root / "formal_pipeline_complete.json"
    prior_failures = tuple(status_root.glob("formal_pipeline_failure_*.json"))
    if start_path.exists() or complete_path.exists() or prior_failures:
        raise FileExistsError(
            "refusing to repeat formal execution in an already attempted target"
        )
    current_job_id = deployment_common.require_slurm_allocation(
        os.environ, deployment
    )
    if current_job_id == int(context["smoke_completion"]["smoke_job_id"]):
        raise PermissionError("smoke and formal execution cannot use the same job")
    if current_job_id != formal_submission_job_id:
        raise PermissionError("formal submission receipt belongs to another job")

    deployment_common.write_new_json(
        start_path,
        {
            "schema_version": "tukf20_hpc_formal_pipeline_start_v1",
            "deployment_id": deployment["deployment_id"],
            "scientific_experiment_id": deployment["scientific_experiment_id"],
            "bundle_sha256": context["package"]["bundle_sha256"],
            "deployment_config_sha256": context["package"][
                "deployment_config_sha256"
            ],
            "smoke_report_sha256": deployment_common.sha256_file(
                context["smoke_path"]
            ),
            "smoke_completion_sha256": deployment_common.sha256_file(
                context["smoke_completion_path"]
            ),
            "scientific_preflight": preflight,
            "slurm_job_id": current_job_id,
            "node": os.environ.get("SLURMD_NODENAME"),
            "started_at_utc": datetime.now(timezone.utc).isoformat(),
        },
    )
    commands = [
        [
            sys.executable,
            "-u",
            "-B",
            "scripts/run_tukf20_hbv_rolling_origin_joint_learning.py",
            "--stage",
            "formal",
            "--config",
            str(scientific_config_path),
            "--confirm-formal-training",
        ],
        [
            sys.executable,
            "-u",
            "-B",
            "scripts/verify_tukf20_hbv_rolling_origin_joint_learning.py",
            "--stage",
            "formal",
            "--config",
            str(scientific_config_path),
        ],
        [
            sys.executable,
            "-u",
            "-B",
            "scripts/plot_tukf20_hbv_rolling_origin_joint_learning.py",
            "--config",
            str(scientific_config_path),
        ],
    ]
    steps: list[dict[str, Any]] = []
    try:
        for command in commands:
            steps.append(_run_step(command))
        validation = validate_formal_outputs(
            deployment, contract, scientific=scientific
        )
        completion = {
            "schema_version": "tukf20_hpc_formal_pipeline_complete_v1",
            "deployment_id": deployment["deployment_id"],
            "scientific_experiment_id": deployment["scientific_experiment_id"],
            "status": (
                "HPC_FORMAL_OUTPUTS_VERIFIED_AWAITING_FINAL_SLURM_ACCOUNTING"
            ),
            "bundle_sha256": context["package"]["bundle_sha256"],
            "deployment_config_sha256": context["package"][
                "deployment_config_sha256"
            ],
            "smoke_report_sha256": deployment_common.sha256_file(
                context["smoke_path"]
            ),
            "slurm_job_id": current_job_id,
            "steps": steps,
            "validation": {
                key: value
                for key, value in validation.items()
                if key not in {"result_root", "figure_root"}
            },
            "technical_completion_is_not_scientific_success": True,
            "finished_at_utc": datetime.now(timezone.utc).isoformat(),
        }
        deployment_common.write_new_json(complete_path, completion)
        return completion
    except BaseException as error:
        job_label = current_job_id
        failure_path = status_root / f"formal_pipeline_failure_{job_label}.json"
        if not failure_path.exists():
            deployment_common.write_new_json(
                failure_path,
                {
                    "schema_version": "tukf20_hpc_formal_pipeline_failure_v1",
                    "deployment_id": deployment["deployment_id"],
                    "scientific_experiment_id": deployment[
                        "scientific_experiment_id"
                    ],
                    "status": "HPC_FORMAL_PIPELINE_FAILED_TECHNICALLY",
                    "steps": steps,
                    "error_type": type(error).__name__,
                    "error": str(error),
                    "traceback": traceback.format_exc(),
                    "scientific_contract_changed": False,
                    "failed_at_utc": datetime.now(timezone.utc).isoformat(),
                },
            )
        raise


def _register_result_member(
    members: MutableMapping[str, Path], name: str, path: Path
) -> None:
    canonical = bundle_builder.safe_member_name(name)
    if canonical in members:
        if members[canonical] == path.resolve():
            return
        raise ValueError(f"duplicate formal result member: {canonical}")
    if path.is_symlink():
        raise ValueError(f"formal result member cannot be a symlink: {canonical}")
    resolved = path.resolve()
    if not resolved.is_file():
        raise FileNotFoundError(f"formal result member is missing: {canonical}")
    members[canonical] = resolved


def _add_tree(members: MutableMapping[str, Path], root: Path) -> None:
    if not root.is_dir():
        raise FileNotFoundError(f"required formal result directory is missing: {root}")
    for path in sorted(root.rglob("*")):
        if path.is_file() or path.is_symlink():
            _register_result_member(
                members, path.relative_to(ROOT).as_posix(), path
            )


def _payload_member_path(name: str) -> Path:
    parts = PurePosixPath(bundle_builder.safe_member_name(name)).parts
    return ROOT.joinpath(*parts)


def _validate_submission_evidence(
    status_root: Path,
    *,
    stage: str,
    deployment: Mapping[str, Any],
    expected_bundle_sha256: str,
    expected_deployment_config_sha256: str,
    require_sacct: bool = True,
) -> int:
    evidence = deployment_common.submission_evidence_paths(status_root, stage=stage)
    required_names = tuple(
        name for name in evidence if require_sacct or name != "sacct"
    )
    missing = [name for name in required_names if not evidence[name].is_file()]
    if missing:
        raise FileNotFoundError(
            f"{stage} submission/accounting evidence is incomplete: {missing}"
        )
    empty = [
        name
        for name in required_names
        if evidence[name].stat().st_size <= 0
    ]
    if empty:
        raise ValueError(f"{stage} submission/accounting evidence is empty: {empty}")
    raw = evidence["raw_output"].read_text(encoding="utf-8")
    receipt = deployment_common.read_json(evidence["receipt"])
    if receipt.get("schema_version") != "tukf20_hpc_submission_receipt_v1":
        raise ValueError(f"{stage} submission receipt schema differs")
    if receipt.get("deployment_id") != deployment["deployment_id"] or receipt.get(
        "scientific_experiment_id"
    ) != deployment["scientific_experiment_id"]:
        raise ValueError(f"{stage} submission receipt identity differs")
    if receipt.get("bundle_sha256") != expected_bundle_sha256 or receipt.get(
        "deployment_config_sha256"
    ) != expected_deployment_config_sha256:
        raise ValueError(f"{stage} submission receipt source binding differs")
    job_id = deployment_common.validate_submission_receipt(
        receipt, raw, stage=stage
    )
    stored = evidence["job_id"].read_text(encoding="utf-8").strip()
    if stored != str(job_id):
        raise ValueError(f"{stage} stored job identifier differs")
    queue_tokens = evidence["squeue"].read_text(encoding="utf-8").replace(
        "|", " "
    ).split()
    if str(job_id) not in queue_tokens:
        raise ValueError(f"{stage} queue snapshot does not contain the submitted job")
    if receipt.get("squeue_snapshot_sha256") != deployment_common.sha256_file(
        evidence["squeue"]
    ):
        raise ValueError(f"{stage} submission receipt queue snapshot hash differs")
    if require_sacct:
        deployment_common.validate_completed_sacct(
            evidence["sacct"].read_text(encoding="utf-8"),
            job_id=job_id,
            deployment=deployment,
        )
    return job_id


def require_formal_slurm_completion(
    completion: Mapping[str, Any],
    *,
    deployment: Mapping[str, Any],
    pipeline_complete_path: Path,
    sacct_path: Path,
    expected_bundle_sha256: str,
    expected_deployment_config_sha256: str,
    expected_formal_job_id: int,
) -> bool:
    if completion.get("schema_version") != "tukf20_hpc_formal_completion_v1":
        raise PermissionError("formal Slurm completion schema differs")
    if completion.get("status") != "HPC_FORMAL_SLURM_COMPLETED":
        raise PermissionError("formal Slurm completion status differs")
    if completion.get("deployment_id") != deployment["deployment_id"] or completion.get(
        "scientific_experiment_id"
    ) != deployment["scientific_experiment_id"]:
        raise PermissionError("formal Slurm completion identity differs")
    if completion.get("bundle_sha256") != expected_bundle_sha256 or completion.get(
        "deployment_config_sha256"
    ) != expected_deployment_config_sha256:
        raise PermissionError("formal Slurm completion source binding differs")
    if completion.get(
        "formal_pipeline_complete_sha256"
    ) != deployment_common.sha256_file(pipeline_complete_path):
        raise PermissionError("formal pipeline completion hash differs")
    if int(completion.get("formal_job_id", -1)) != int(expected_formal_job_id):
        raise PermissionError("formal Slurm job identifier differs")
    if completion.get("slurm_state") != "COMPLETED" or completion.get(
        "slurm_exit_code"
    ) != "0:0":
        raise PermissionError("formal Slurm job did not finish COMPLETED/0:0")
    if completion.get("sacct_snapshot_sha256") != deployment_common.sha256_file(
        sacct_path
    ):
        raise PermissionError("formal Slurm accounting snapshot hash differs")
    return True


def _result_members(
    deployment: Mapping[str, Any],
    contract: Mapping[str, Any],
    *,
    scientific: Any,
    bundle_manifest_path: Path,
) -> dict[str, Path]:
    members: dict[str, Path] = {}
    payload_manifest_path = ROOT / deployment["outputs"]["payload_manifest_name"]
    payload_manifest = deployment_common.read_json(payload_manifest_path)
    for name, expected_hash in payload_manifest.get("members", {}).items():
        path = _payload_member_path(str(name))
        if deployment_common.sha256_file(path) != expected_hash:
            raise ValueError(f"formal source member hash changed: {name}")
        _register_result_member(members, str(name), path)
    _register_result_member(
        members,
        payload_manifest_path.relative_to(ROOT).as_posix(),
        payload_manifest_path,
    )
    _register_result_member(
        members,
        bundle_manifest_path.relative_to(ROOT).as_posix(),
        bundle_manifest_path,
    )
    for root in (
        scientific.resolve_output_path(contract, contract["outputs"]["preflight_root"]),
        scientific.resolve_output_path(contract, contract["outputs"]["result_root"]),
        scientific.resolve_output_path(contract, contract["outputs"]["figure_root"]),
        deployment_common.resolve_root_relative(
            deployment["outputs"]["hpc_status_root"]
        ),
        ROOT / "logs",
    ):
        _add_tree(members, root)
    smoke_path = deployment_common.resolve_root_relative(
        deployment["outputs"]["smoke_report"]
    )
    if smoke_path.relative_to(ROOT).as_posix() not in members:
        _register_result_member(
            members, smoke_path.relative_to(ROOT).as_posix(), smoke_path
        )
    return dict(sorted(members.items()))


def finalize_package(
    *,
    deployment_path: Path = DEFAULT_CONFIG,
    bundle_manifest_path: Path | None = None,
) -> dict[str, Any]:
    context = _gate_context(deployment_path, bundle_manifest_path)
    deployment = context["deployment"]
    scientific, _ = _scientific_modules()
    scientific_config_path = (
        ROOT / deployment["source_contract"]["scientific_config_path"]
    ).resolve()
    contract = scientific.load_contract(scientific_config_path)
    validation = validate_formal_outputs(
        deployment, contract, scientific=scientific
    )
    status_root = deployment_common.resolve_root_relative(
        deployment["outputs"]["hpc_status_root"]
    )
    smoke_job_id = _validate_submission_evidence(
        status_root,
        stage="smoke",
        deployment=deployment,
        expected_bundle_sha256=context["package"]["bundle_sha256"],
        expected_deployment_config_sha256=context["package"][
            "deployment_config_sha256"
        ],
        require_sacct=True,
    )
    formal_job_id = _validate_submission_evidence(
        status_root,
        stage="formal",
        deployment=deployment,
        expected_bundle_sha256=context["package"]["bundle_sha256"],
        expected_deployment_config_sha256=context["package"][
            "deployment_config_sha256"
        ],
        require_sacct=True,
    )
    if smoke_job_id == formal_job_id:
        raise PermissionError("smoke and formal jobs must have distinct identifiers")
    pipeline_complete_path = status_root / "formal_pipeline_complete.json"
    pipeline_complete = deployment_common.read_json(pipeline_complete_path)
    if pipeline_complete.get("status") != (
        "HPC_FORMAL_OUTPUTS_VERIFIED_AWAITING_FINAL_SLURM_ACCOUNTING"
    ):
        raise PermissionError("formal scientific pipeline is not complete")
    if int(pipeline_complete.get("slurm_job_id", -1)) != formal_job_id:
        raise PermissionError("formal pipeline ran under another Slurm job")
    formal_completion_path = deployment_common.resolve_root_relative(
        deployment["outputs"]["formal_completion_record"]
    )
    formal_completion = deployment_common.read_json(formal_completion_path)
    formal_sacct_path = deployment_common.submission_evidence_paths(
        status_root, stage="formal"
    )["sacct"]
    require_formal_slurm_completion(
        formal_completion,
        deployment=deployment,
        pipeline_complete_path=pipeline_complete_path,
        sacct_path=formal_sacct_path,
        expected_bundle_sha256=context["package"]["bundle_sha256"],
        expected_deployment_config_sha256=context["package"][
            "deployment_config_sha256"
        ],
        expected_formal_job_id=formal_job_id,
    )

    archive_path = deployment_common.resolve_root_relative(
        deployment["outputs"]["formal_result_archive"]
    )
    external_manifest_path = Path(str(archive_path) + ".sha256.json")
    if archive_path.exists() or external_manifest_path.exists():
        raise FileExistsError("refusing to replace formal HPC result package")
    members = _result_members(
        deployment,
        contract,
        scientific=scientific,
        bundle_manifest_path=context["external_path"],
    )
    member_hashes = {
        name: deployment_common.sha256_file(path) for name, path in members.items()
    }
    virtual_name = deployment["outputs"][
        "formal_result_payload_manifest_name"
    ]
    payload = {
        "schema_version": "tukf20_hpc_formal_result_payload_manifest_v1",
        "deployment_id": deployment["deployment_id"],
        "scientific_experiment_id": deployment["scientific_experiment_id"],
        "bundle_sha256": context["package"]["bundle_sha256"],
        "deployment_config_sha256": context["package"][
            "deployment_config_sha256"
        ],
        "smoke_job_id": smoke_job_id,
        "formal_job_id": formal_job_id,
        "validation": {
            key: value
            for key, value in validation.items()
            if key not in {"result_root", "figure_root"}
        },
        "members": member_hashes,
        "technical_completion_is_not_scientific_success": True,
    }
    payload_bytes = deployment_common.canonical_json_bytes(payload)
    bundle_builder.write_deterministic_archive(
        archive_path,
        members,
        virtual_members={virtual_name: payload_bytes},
    )
    external = {
        "schema_version": "tukf20_hpc_formal_result_bundle_manifest_v1",
        "deployment_id": deployment["deployment_id"],
        "scientific_experiment_id": deployment["scientific_experiment_id"],
        "archive_name": archive_path.name,
        "archive_sha256": deployment_common.sha256_file(archive_path),
        "archive_bytes": archive_path.stat().st_size,
        "payload_manifest_name": virtual_name,
        "payload_manifest_sha256": deployment_common.sha256_bytes(payload_bytes),
        "member_count": len(member_hashes),
        "members": member_hashes,
        "technical_completion_is_not_scientific_success": True,
    }
    deployment_common.write_new_json(external_manifest_path, external)
    bundle_builder.verify_archive_against_manifest(archive_path, external)
    return {
        **external,
        "archive_path": archive_path,
        "manifest_path": external_manifest_path,
    }


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("execute", "package"), default="execute")
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--bundle-manifest", type=Path)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    keywords = {
        "deployment_path": args.config.resolve(),
        "bundle_manifest_path": (
            args.bundle_manifest.resolve() if args.bundle_manifest else None
        ),
    }
    report = (
        run_execution(**keywords)
        if args.stage == "execute"
        else finalize_package(**keywords)
    )
    summary = {
        "status": report.get("status", "HPC_FORMAL_RESULT_PACKAGE_COMPLETE"),
        "archive_sha256": report.get("archive_sha256")
        or report.get("package", {}).get("archive_sha256"),
        "archive_bytes": report.get("archive_bytes")
        or report.get("package", {}).get("archive_bytes"),
    }
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
