"""Build the deterministic, self-contained TUKF20 HPC payload archive."""
from __future__ import annotations

import argparse
import gzip
import io
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile
from typing import Any, Mapping, MutableMapping


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf20_hpc_deployment_common as deployment_common


DEFAULT_CONFIG = deployment_common.DEFAULT_CONFIG
sha256_file = deployment_common.sha256_file

APPLICATION_FILES = (
    "configs/tukf20_hbv_rolling_origin_joint_learning_v1.json",
    "configs/tukf20_hpc_deployment_v1.json",
    "docs/superpowers/plans/2026-08-24-tukf20-rolling-origin-joint-learning.md",
    "scripts/tukf17_hbv_rolling_origin_state_hydrology_common.py",
    "scripts/tukf18_hbv_rolling_origin_balance_common.py",
    "scripts/run_tukf17_hbv_rolling_origin_state_hydrology_update.py",
    "scripts/verify_tukf17_hbv_rolling_origin_state_hydrology_update.py",
    "scripts/tukf20_hbv_rolling_origin_joint_learning_common.py",
    "scripts/tukf20_hbv_rolling_origin_mode_training.py",
    "scripts/run_tukf20_hbv_rolling_origin_joint_learning.py",
    "scripts/verify_tukf20_hbv_rolling_origin_joint_learning.py",
    "scripts/plot_tukf20_hbv_rolling_origin_joint_learning.py",
    "scripts/tukf20_hpc_deployment_common.py",
    "scripts/build_tukf20_hpc_bundle.py",
    "scripts/smoke_tukf20_hpc_compatibility.py",
    "scripts/run_tukf20_hpc_formal_pipeline.py",
    "hpc/tukf20_hbv_rolling_origin_joint_learning/submit_smoke_cpu.slurm",
    "hpc/tukf20_hbv_rolling_origin_joint_learning/submit_formal_cpu.slurm",
)

# These are the exact original, read-only numerical and import-closure files
# needed by the audited rolling-origin implementation.  They are mapped under
# their registered Windows-like names inside the Linux payload; those names are
# relative POSIX archive names (the first component is ``G:``), not absolute.
READONLY_KALMANNET_FILES = (
    "configs/tukf11_hbv_joint_parameter_synthetic_mechanism_gate_v1.json",
    "configs/tukf14_hbv_four_mode_randomised_start_ablation_v1.json",
    "configs/tukf16_hbv_balanced_error_four_mode_rerun_v1.json",
    "scripts/tukf11_hbv_joint_parameter_synthetic_common.py",
    "scripts/run_tukf11_hbv_joint_parameter_synthetic_mechanism_gate.py",
    "scripts/differentiable_ukf_hbvlite.py",
    "scripts/tukf10_joint_hbv_physical_filter_common.py",
    "scripts/tukf16_hbv_balanced_error_four_mode_common.py",
    "scripts/run_aligned_gr4j_da.py",
    "scripts/run_aligned_gr4j_differentiable_ukf.py",
    "src/global_hydrology/__init__.py",
    "src/global_hydrology/assimilation/__init__.py",
    "src/global_hydrology/assimilation/conventional_ukf.py",
    "src/global_hydrology/models/__init__.py",
    "src/global_hydrology/models/differentiable_m4.py",
    "src/global_hydrology/models/static_encoder.py",
    "src/global_hydrology/models/m4_system_model.py",
    "src/global_hydrology/models/dl_ssm.py",
    "src/global_hydrology/models/hydro_system.py",
    "src/global_hydrology/models/differentiable_walrus.py",
    "src/global_hydrology/models/walrus_system_model.py",
    "src/global_hydrology/models/differentiable_hbv_lite.py",
    "src/global_hydrology/models/trainable_hbvlite_ukf_adapter.py",
    "src/global_hydrology/data/__init__.py",
    "src/global_hydrology/data/caravan_dataset.py",
    "src/global_hydrology/data/multi_obs_caravan.py",
)

RUNTIME_VIRTUAL_FILES = {
    # Slurm opens stdout/stderr before the script body runs, so the directory
    # must already exist immediately after safe extraction.
    "logs/.keep": b"",
}


def safe_member_name(raw: str) -> str:
    if not isinstance(raw, str) or not raw or "\\" in raw:
        raise ValueError(f"unsafe archive member: {raw!r}")
    value = PurePosixPath(raw)
    if value.is_absolute() or ".." in value.parts or not value.parts:
        raise ValueError(f"unsafe archive member: {raw}")
    normalized = value.as_posix()
    if normalized != raw or raw.startswith("/"):
        raise ValueError(f"archive member is not canonical POSIX text: {raw}")
    if any(part in {".git", "draft"} for part in value.parts):
        raise ValueError(f"unrelated or repository-private archive member: {raw}")
    return normalized


def safe_runtime_member_name(raw: str) -> str:
    name = safe_member_name(raw)
    if any(part in {"artifacts", "results"} for part in PurePosixPath(name).parts):
        raise ValueError(f"runtime payload cannot contain generated output: {raw}")
    return name


def _validate_archive_source_file(member_name: str, path: Path | str) -> Path:
    safe_member_name(member_name)
    source = Path(path)
    if source.is_symlink():
        raise ValueError(f"archive source cannot be a symlink: {member_name}: {source}")
    resolved = source.resolve()
    if not resolved.is_file():
        raise FileNotFoundError(f"archive source is missing: {member_name}: {resolved}")
    return resolved


def validate_source_file(member_name: str, path: Path | str) -> Path:
    safe_runtime_member_name(member_name)
    return _validate_archive_source_file(member_name, path)


def register_member(
    members: MutableMapping[str, Path], member_name: str, path: Path | str
) -> None:
    name = safe_runtime_member_name(member_name)
    if name in members:
        raise ValueError(f"duplicate archive member: {name}")
    members[name] = validate_source_file(name, path)


def _candidate_sources(deployment: Mapping[str, Any]) -> tuple[tuple[str, Path], ...]:
    source = deployment["source_contract"]
    readonly_kalmannet = Path(source["readonly_kalmannet_root"])
    readonly_neuralhydrology = Path(source["readonly_neuralhydrology_root"])
    candidates: list[tuple[str, Path]] = [
        (relative, ROOT / relative) for relative in APPLICATION_FILES
    ]
    candidates.extend(
        (
            f"G:/github/pycharm/projects/kalmannet/{relative}",
            readonly_kalmannet / relative,
        )
        for relative in READONLY_KALMANNET_FILES
    )
    external_relative = "src/scl_hydro/hbv_lite_numpy.py"
    external_source = readonly_neuralhydrology / external_relative
    candidates.extend(
        (
            member,
            external_source,
        )
        for member in (
            "G:/github/pycharm/projects/neuralhydrology/" + external_relative,
            "G:/github/pycharm/projects/kalmannet/"
            "G:/github/pycharm/projects/neuralhydrology/"
            + external_relative,
        )
    )
    candidates.append(
        (
            "G:/github/pycharm/projects/neuralhydrology/src/scl_hydro/__init__.py",
            readonly_neuralhydrology / "src/scl_hydro/__init__.py",
        )
    )
    return tuple(candidates)


def missing_payload_sources(deployment: Mapping[str, Any]) -> tuple[str, ...]:
    deployment_common.validate_deployment(deployment, validate_sources=False)
    missing = [
        f"{member}: {path}"
        for member, path in _candidate_sources(deployment)
        if path.is_symlink() or not path.is_file()
    ]
    return tuple(missing)


def payload_members(deployment: Mapping[str, Any]) -> dict[str, Path]:
    deployment_common.validate_deployment(deployment, validate_sources=False)
    missing = missing_payload_sources(deployment)
    if missing:
        raise FileNotFoundError(
            "TUKF20 runtime closure is incomplete:\n" + "\n".join(missing)
        )
    deployment_common.validate_deployment(deployment, validate_sources=True)
    members: dict[str, Path] = {}
    for member, source in _candidate_sources(deployment):
        register_member(members, member, source)

    external_source = Path(deployment["source_contract"]["external_numpy_hbv_path"])
    if sha256_file(external_source) != deployment["source_contract"][
        "external_numpy_hbv_sha256"
    ]:
        raise ValueError("external NumPy HBV-light source hash changed")
    return dict(sorted(members.items()))


def _tar_info(name: str, size: int) -> tarfile.TarInfo:
    info = tarfile.TarInfo(name=name)
    info.size = int(size)
    info.mtime = 0
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    info.mode = 0o755 if name.endswith((".sh", ".slurm")) else 0o644
    return info


def write_deterministic_archive(
    destination: Path | str,
    members: Mapping[str, Path | str],
    *,
    virtual_members: Mapping[str, bytes] | None = None,
) -> None:
    target = Path(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise FileExistsError(f"refusing to replace archive: {target}")
    virtual = dict(virtual_members or {})
    overlap = set(members) & set(virtual)
    if overlap:
        raise ValueError(f"duplicate real and virtual archive members: {sorted(overlap)}")
    names = [safe_member_name(name) for name in (*members, *virtual)]
    if len(names) != len(set(names)):
        raise ValueError("duplicate archive member names")
    validated = {
        name: _validate_archive_source_file(name, path)
        for name, path in members.items()
    }

    with target.open("xb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as zipped:
            with tarfile.open(
                fileobj=zipped, mode="w", format=tarfile.PAX_FORMAT
            ) as archive:
                for name in sorted((*validated, *virtual)):
                    payload = (
                        virtual[name]
                        if name in virtual
                        else Path(validated[name]).read_bytes()
                    )
                    archive.addfile(_tar_info(name, len(payload)), io.BytesIO(payload))


def verify_archive_member_safety(archive_path: Path | str) -> tuple[str, ...]:
    names: list[str] = []
    with tarfile.open(archive_path, "r:gz") as archive:
        for member in archive.getmembers():
            name = safe_member_name(member.name)
            if name in names:
                raise ValueError(f"duplicate archive member: {name}")
            if not member.isfile():
                raise ValueError(f"archive contains a non-file member: {name}")
            names.append(name)
    return tuple(names)


def verify_archive_against_manifest(
    archive_path: Path | str, manifest: Mapping[str, Any]
) -> dict[str, bool]:
    archive_file = Path(archive_path)
    if archive_file.stat().st_size != int(manifest["archive_bytes"]):
        raise ValueError("bundle archive byte count changed")
    if sha256_file(archive_file) != manifest["archive_sha256"]:
        raise ValueError("bundle archive SHA-256 changed")
    names = verify_archive_member_safety(archive_file)
    expected_names = set(manifest["members"]) | {manifest["payload_manifest_name"]}
    if set(names) != expected_names:
        raise ValueError("bundle archive member set differs from manifest")
    with tarfile.open(archive_file, "r:gz") as archive:
        payload_bytes = archive.extractfile(manifest["payload_manifest_name"]).read()
        if deployment_common.sha256_bytes(payload_bytes) != manifest[
            "payload_manifest_sha256"
        ]:
            raise ValueError("embedded payload manifest SHA-256 changed")
        payload = json.loads(payload_bytes.decode("utf-8"))
        if payload.get("members") != manifest.get("members"):
            raise ValueError("embedded and external member maps differ")
        for name, expected in manifest["members"].items():
            handle = archive.extractfile(name)
            if handle is None:
                raise ValueError(f"bundle member is unreadable: {name}")
            if deployment_common.sha256_bytes(handle.read()) != expected:
                raise ValueError(f"bundle member hash differs: {name}")
    return {
        "outer_hash_verified": True,
        "embedded_manifest_verified": True,
        "all_member_hashes_verified": True,
    }


def build_bundle(
    output_root: Path | str | None = None,
    *,
    deployment_path: Path | str = DEFAULT_CONFIG,
) -> dict[str, Any]:
    deployment = deployment_common.load_deployment(
        deployment_path, validate_sources=True
    )
    output = (
        Path(output_root)
        if output_root is not None
        else deployment_common.resolve_root_relative(
            deployment["outputs"]["local_bundle_root"]
        )
    )
    output.mkdir(parents=True, exist_ok=True)
    archive_path = output / deployment["outputs"]["bundle_name"]
    external_manifest_path = output / deployment["outputs"]["bundle_manifest_name"]
    if archive_path.exists() or external_manifest_path.exists():
        raise FileExistsError("refusing to replace an existing HPC bundle or manifest")

    members = payload_members(deployment)
    runtime_virtual = {
        safe_runtime_member_name(name): payload
        for name, payload in RUNTIME_VIRTUAL_FILES.items()
    }
    if set(runtime_virtual) & set(members):
        raise ValueError("runtime virtual member duplicates a source member")
    member_hashes = {
        **{name: sha256_file(path) for name, path in members.items()},
        **{
            name: deployment_common.sha256_bytes(payload)
            for name, payload in runtime_virtual.items()
        },
    }
    payload_manifest = {
        "schema_version": "tukf20_hpc_payload_manifest_v1",
        "deployment_id": deployment["deployment_id"],
        "scientific_experiment_id": deployment["scientific_experiment_id"],
        "deployment_config_sha256": sha256_file(deployment_path),
        "scientific_source_hashes": deployment_common.validate_deployment(
            deployment, configuration_path=deployment_path, validate_sources=True
        )["source_hashes"],
        "members": member_hashes,
    }
    payload_manifest_bytes = deployment_common.canonical_json_bytes(payload_manifest)
    payload_manifest_name = deployment["outputs"]["payload_manifest_name"]
    write_deterministic_archive(
        archive_path,
        members,
        virtual_members={
            **runtime_virtual,
            payload_manifest_name: payload_manifest_bytes,
        },
    )
    external_manifest = {
        "schema_version": "tukf20_hpc_bundle_manifest_v1",
        "deployment_id": deployment["deployment_id"],
        "scientific_experiment_id": deployment["scientific_experiment_id"],
        "deployment_config_sha256": sha256_file(deployment_path),
        "archive_name": archive_path.name,
        "archive_sha256": sha256_file(archive_path),
        "archive_bytes": archive_path.stat().st_size,
        "payload_manifest_name": payload_manifest_name,
        "payload_manifest_sha256": deployment_common.sha256_bytes(
            payload_manifest_bytes
        ),
        "member_count": len(member_hashes),
        "members": member_hashes,
    }
    deployment_common.write_new_json(external_manifest_path, external_manifest)
    verify_archive_against_manifest(archive_path, external_manifest)
    return {
        **external_manifest,
        "archive_path": archive_path,
        "manifest_path": external_manifest_path,
    }


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--output-root", type=Path)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    result = build_bundle(args.output_root, deployment_path=args.config)
    print(
        json.dumps(
            {
                "status": "HPC_BUNDLE_COMPLETE",
                "archive": str(result["archive_path"]),
                "archive_sha256": result["archive_sha256"],
                "archive_bytes": result["archive_bytes"],
                "member_count": result["member_count"],
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
